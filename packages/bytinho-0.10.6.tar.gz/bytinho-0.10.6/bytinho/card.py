"""Render PNG card estilo "GitHub stats" do pet.

Usado pelo comando `bytinho card`. Saída padrão: ~/.cache/bytinho/card.png
(ou caminho dado via --out). Estética combina com o badge SVG e a página
pública /u/<nick> — mesmo accent color, mesmo BG escuro.

Pillow é dependência obrigatória do CLI agora (Fase 2).
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .cosmetics import render_hat
from .pet_logic import STAGE_LABEL, STAGE_THRESHOLD
from .sprites import render

# Mesma paleta do server (server/app/profile.py::_SOUL_HEX), pra ficar
# consistente com o badge SVG e com a página HTML pública.
SOUL_HEX: dict[str, str] = {
    "cyan":    "#22d3ee",
    "magenta": "#e879f9",
    "yellow":  "#fde047",
    "green":   "#86efac",
    "red":     "#fca5a5",
    "blue":    "#93c5fd",
    "white":   "#f5f5f4",
    "purple":  "#c4b5fd",
}

_BG_DEEP    = "#0b1220"
_BG_PANEL   = "#0f172a"
_BG_BORDER  = "#1f2937"
_TEXT_MAIN  = "#e5e7eb"
_TEXT_MUTED = "#94a3b8"
_TEXT_DIM   = "#64748b"

_FONT_CANDIDATES_MONO = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
    "/Library/Fonts/Menlo.ttc",
    "/System/Library/Fonts/Menlo.ttc",
    "C:/Windows/Fonts/consola.ttf",
]
_FONT_CANDIDATES_SANS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/Library/Fonts/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]


def _load_font(candidates: list[str], size: int):
    for p in candidates:
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size=size)
            except OSError:
                continue
    return ImageFont.load_default()


def _accent(soul: dict) -> str:
    return SOUL_HEX.get(soul.get("color", "cyan"), "#22d3ee")


def _xp_for_next(stage: str) -> int | None:
    """Próximo threshold após este estágio. None se já é legend."""
    keys = list(STAGE_THRESHOLD.keys())
    if stage not in keys:
        return None
    idx = keys.index(stage)
    if idx + 1 >= len(keys):
        return None
    return STAGE_THRESHOLD[keys[idx + 1]]


def render_card(profile: dict, output: Path) -> Path:
    """Renderiza profile completo (vindo de /api/u/<nick>) num PNG.

    Layout fixo 720×360. Lado esquerdo = sprite + hat; lado direito =
    nick, stage, XP, streak e top 3 achievements.
    """
    pet     = profile.get("pet") or {}
    nick    = profile.get("nick", "—")
    streak  = profile.get("streak") or {}
    achs    = profile.get("achievements") or []
    soul    = pet.get("soul") or {}
    color   = _accent(soul)
    stage   = pet.get("stage", "egg")
    variant = soul.get("variant", "a")

    W, H = 720, 360
    img  = Image.new("RGB", (W, H), _BG_DEEP)
    draw = ImageDraw.Draw(img)

    # painel central (com cantos discretos via outline simples)
    pad = 14
    draw.rectangle((pad, pad, W - pad, H - pad), fill=_BG_PANEL, outline=_BG_BORDER)
    # accent bar à esquerda (cor do soul)
    draw.rectangle((pad, pad, pad + 4, H - pad), fill=color)

    # ---------- sprite (esquerda, centralizado) ---------------------------
    # tick=1 garante olhos abertos (tick=0 pisca em alguns variants)
    sprite_text = render(stage, pet.get("mood", 80), pet.get("asleep", False),
                         variant, tick=1)
    hat_code = pet.get("hat")
    if hat_code and not pet.get("asleep"):
        hat_art = render_hat(hat_code)
        if hat_art:
            sprite_text = hat_art + "\n" + sprite_text

    # Zona esquerda: do painel (pad+4) até antes do texto direito (rx-12).
    left_x0 = pad + 6
    left_x1 = 320 - 12
    left_y0 = pad + 6
    left_y1 = H - pad - 30  # deixa espaço pro rodapé "bytinho.com"

    f_sprite = _load_font(_FONT_CANDIDATES_MONO, 34)
    bbox = draw.multiline_textbbox(
        (0, 0), sprite_text, font=f_sprite, spacing=4,
    )
    sw = bbox[2] - bbox[0]
    sh = bbox[3] - bbox[1]
    sprite_x = left_x0 + (left_x1 - left_x0 - sw) // 2 - bbox[0]
    sprite_y = left_y0 + (left_y1 - left_y0 - sh) // 2 - bbox[1]
    draw.multiline_text(
        (sprite_x, sprite_y), sprite_text, font=f_sprite,
        fill=color, spacing=4, align="center",
    )

    # ---------- texto (direita) -------------------------------------------
    rx = 320
    f_nick   = _load_font(_FONT_CANDIDATES_SANS, 30)
    f_label  = _load_font(_FONT_CANDIDATES_SANS, 16)
    f_meta   = _load_font(_FONT_CANDIDATES_SANS, 14)
    f_small  = _load_font(_FONT_CANDIDATES_SANS, 13)

    draw.text((rx, 38), f"@{nick}", font=f_nick, fill=_TEXT_MAIN)

    stage_label = STAGE_LABEL.get(stage, stage)
    level = int(pet.get("level", 1))
    xp    = int(pet.get("xp", 0))
    nxt   = _xp_for_next(stage)
    line2 = f"{stage_label}  ·  Lv.{level}"
    draw.text((rx, 80), line2, font=f_label, fill=color)

    if nxt:
        line3 = f"{xp} / {nxt} XP"
    else:
        line3 = f"{xp} XP  ·  endgame"
    draw.text((rx, 104), line3, font=f_meta, fill=_TEXT_MUTED)

    # mini-barra XP (se não for legend)
    bar_x, bar_y, bar_w, bar_h = rx, 128, 320, 8
    draw.rectangle((bar_x, bar_y, bar_x + bar_w, bar_y + bar_h),
                   fill=_BG_BORDER)
    if nxt:
        prev = STAGE_THRESHOLD.get(stage, 0)
        span = max(1, nxt - prev)
        frac = max(0.0, min(1.0, (xp - prev) / span))
        draw.rectangle(
            (bar_x, bar_y, bar_x + int(bar_w * frac), bar_y + bar_h),
            fill=color,
        )
    else:
        draw.rectangle((bar_x, bar_y, bar_x + bar_w, bar_y + bar_h), fill=color)

    days = int(streak.get("days", 0))
    if days > 0:
        draw.text((rx, 148), f"streak {days}d", font=f_meta, fill="#fb923c")

    # ---------- top 3 achievements ----------------------------------------
    top = achs[-3:] if len(achs) >= 3 else achs
    top = list(reversed(top))  # mais recente primeiro
    ay = 188
    draw.text((rx, ay), "conquistas recentes", font=f_small, fill=_TEXT_DIM)
    ay += 22
    if not top:
        draw.text((rx, ay), "(nenhuma ainda)", font=f_meta, fill=_TEXT_DIM)
    else:
        for a in top:
            title = a.get("title", a.get("code", "?"))
            desc  = (a.get("desc") or "")[:46]
            # caixinha
            draw.rectangle((rx, ay, rx + 320, ay + 38),
                           fill=_BG_DEEP, outline=_BG_BORDER)
            draw.text((rx + 10, ay + 4), f"★  {title}",
                      font=f_label, fill=_TEXT_MAIN)
            if desc:
                draw.text((rx + 10, ay + 22), desc,
                          font=f_small, fill=_TEXT_MUTED)
            ay += 44

    # rodapé
    draw.text((pad + 14, H - pad - 22),
              "bytinho.com", font=f_small, fill=_TEXT_DIM)

    output = Path(output).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    img.save(output, format="PNG", optimize=True)
    return output
