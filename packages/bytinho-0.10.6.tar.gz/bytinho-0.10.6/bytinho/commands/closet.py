"""Comando `bytinho closet`: lista hats e equipa/desequipa.

  bytinho closet                 # mostra tudo
  bytinho closet equip <code>    # equipa
  bytinho closet off             # tira o hat atual
"""
from __future__ import annotations

import typer
from rich.table import Table

from .. import client
from ..render import console, live_for, refresh


def _show(data: dict) -> None:
    eq = data.get("equipped")
    items = data.get("items") or []
    if not items:
        console.print("[dim]nenhum cosmético cadastrado.[/dim]")
        return
    title = f"closet ({'sem hat' if not eq else 'usando: ' + eq})"
    table = Table(title=title, show_lines=False, padding=(0, 1))
    table.add_column("", width=2)
    table.add_column("código")
    table.add_column("nome")
    table.add_column("regra")
    table.add_column("status")
    for it in items:
        marker = "★" if it["equipped"] else (" " if it["owned"] else "·")
        if it["equipped"]:
            status = "[bright_yellow]equipado[/bright_yellow]"
        elif it["owned"]:
            status = "[green]liberado[/green]"
        else:
            status = "[dim]bloqueado[/dim]"
        name = f"{it['emoji']}  {it['name']}"
        table.add_row(marker, it["code"], name, it["rule"], status)
    console.print(table)
    console.print(
        "[dim]uso:[/dim] [cyan]bytinho closet equip <código>[/cyan] "
        "[dim]·[/dim] [cyan]bytinho closet off[/cyan]"
    )


def register(app: typer.Typer) -> None:
    @app.command()
    def closet(
        action: str = typer.Argument(
            None, help="Vazio = mostra. 'equip <code>' = equipa. 'off' = tira."
        ),
        code: str = typer.Argument(None, help="Código do hat (quando 'equip')."),
    ):
        """Mostra teus hats / equipa um deles."""
        if action is None:
            data = client.closet()
            if data is None:
                console.print("[yellow]offline — não consegui ler o closet[/yellow]")
                return
            _show(data)
            return

        act = action.strip().lower()
        if act == "off":
            ok = client.unequip_hat()
            if not ok:
                console.print("[red]✗ falhou ao tirar o hat[/red]")
                return
            console.print("[green]✓ hat removido[/green]")
        elif act == "equip":
            if not code:
                console.print("[red]✗ uso: [cyan]bytinho closet equip <código>[/cyan][/red]")
                return
            ok, msg = client.equip_hat(code.strip().lower())
            if not ok:
                console.print(f"[red]✗ {msg}[/red]")
                return
            console.print(f"[green]✓ equipado: {msg}[/green]")
        else:
            console.print(
                "[red]✗ ação desconhecida.[/red] "
                "use [cyan]equip <code>[/cyan] ou [cyan]off[/cyan]."
            )
            return

        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)
