"""Comandos interativos: talk, live, chat (WebSocket)."""
import asyncio
import json
import time

import typer
from rich.live import Live

from .. import client
from ..render import console, refresh, show_static
from ..session import cache, load_cache
from ..ui import empty_pet, panel


def _fmt(m: dict) -> str:
    return (
        f"[cyan]{m.get('stage_emoji','👾')} {m.get('nick','anon')}[/cyan] "
        f"[dim]lv.{m.get('level',1)}[/dim]: {m.get('text','')}"
    )


async def _chat_loop():
    import websockets
    from rich.panel import Panel as RPanel
    from rich.text import Text as RText

    msgs: list[str] = []
    online = 0
    top_achs: list[dict] = []
    recent_unlocks: list[dict] = []  # feed global "ao vivo"

    def _fmt_unlock(u: dict) -> str:
        return (
            f"[bright_magenta]{u.get('icon','★')}[/bright_magenta] "
            f"[bold]@{u.get('nick','?')}[/bold] desbloqueou "
            f"[italic]{u.get('title','?')}[/italic]"
        )

    def render():
        body_lines = msgs[-20:]
        body = "\n".join(body_lines) or "[dim]ninguém falou ainda... seja o primeiro![/dim]"
        # Feed lateral de unlocks recentes (mostra só os 3 + recentes)
        if recent_unlocks:
            feed = "\n".join(_fmt_unlock(u) for u in recent_unlocks[:3])
            body = body + "\n\n[dim]── feed global ──[/dim]\n" + feed
        if top_achs:
            top_str = "  ".join(
                f"{a.get('icon','★')} [bold]{a.get('title','?')}[/bold] "
                f"[dim]({a.get('holders',0)})[/dim]"
                for a in top_achs[:3]
            )
            title = f"💬  Chat Global • {online} online  │  🏆 {top_str}"
        else:
            title = f"💬  Chat Global • {online} online"
        if online <= 1:
            subtitle = "[yellow]🌙 só você por aqui — mensagens ficam gravadas[/yellow] [dim]• Ctrl+C[/dim]"
            border = "yellow"
        else:
            subtitle = "[dim]digite e Enter • Ctrl+C pra sair[/dim]"
            border = "magenta"
        return RPanel(
            RText.from_markup(body),
            title=title,
            subtitle=subtitle,
            border_style=border, padding=(1, 2),
        )

    # --- reconnect com backoff exponencial -------------------------------
    backoff = 1.0
    BACKOFF_MAX = 30.0
    while True:
        try:
            async with websockets.connect(client.ws_url()) as ws:
                backoff = 1.0  # reset on success
                console.clear(); console.print(render())

                async def reader():
                    nonlocal online
                    async for raw in ws:
                        try: d = json.loads(raw)
                        except ValueError: continue
                        t = d.get("type")
                        if t == "history":
                            for m in d.get("messages", []): msgs.append(_fmt(m))
                        elif t == "msg":     msgs.append(_fmt(d["message"]))
                        elif t == "presence": online = d.get("online", 0)
                        elif t == "stats":
                            top_achs[:] = d.get("top_achievements", []) or []
                            recent_unlocks[:] = d.get("recent_unlocks", []) or []
                        elif t == "unlock_feed":
                            u = d.get("unlock") or {}
                            if u:
                                recent_unlocks.insert(0, u)
                                del recent_unlocks[5:]
                                msgs.append(
                                    f"[bright_magenta]✨ {_fmt_unlock(u)}[/bright_magenta]"
                                )
                        elif t == "system":   msgs.append(f"[yellow]· {d.get('text','')}[/yellow]")
                        elif t == "ping":
                            try: await ws.send(json.dumps({"type": "pong"}))
                            except Exception: return
                            continue
                        elif t == "pong":
                            continue
                        console.clear(); console.print(render())

                task = asyncio.create_task(reader())
                loop = asyncio.get_event_loop()
                try:
                    while True:
                        txt = (await loop.run_in_executor(None, input, "> ")).strip()
                        if not txt: continue
                        if txt in ("/quit", "/sair", "/exit"): return
                        await ws.send(json.dumps({"type": "msg", "text": txt}))
                finally:
                    task.cancel()
        except (KeyboardInterrupt, SystemExit):
            return
        except Exception as ex:
            console.print(
                f"[yellow]· conexão caiu ({type(ex).__name__}). "
                f"reconectando em {backoff:.0f}s... (Ctrl+C cancela)[/yellow]"
            )
            try:
                await asyncio.sleep(backoff)
            except (KeyboardInterrupt, asyncio.CancelledError):
                return
            backoff = min(backoff * 2, BACKOFF_MAX)


def register(app: typer.Typer) -> None:
    @app.command(
        "talk",
        # permite `bytinho talk -q oi mundo` sem confundir com options
        context_settings={"allow_interspersed_args": False},
    )
    def talk_cmd(
        words: list[str] = typer.Argument(
            None,
            metavar="MESSAGE",
            help="Mensagem livre, sem precisar de aspas.",
        ),
        quiet: bool = typer.Option(
            False, "--quiet", "-q",
            help="Sem header/footer — só a fala do Bytinho.",
        ),
    ):
        """Conversa com o Bytinho. Pode escrever sem aspas:

            bytinho talk hey passa aí
        """
        from . import _talk_ui

        # Junta as palavras OU lê do stdin (echo "oi" | bytinho talk)
        if words:
            message = " ".join(words).strip()
        else:
            import sys
            if not sys.stdin.isatty():
                message = sys.stdin.read().strip()
            else:
                message = ""

        if not message:
            console.print(
                "[yellow]·[/yellow] sem mensagem. exemplo: "
                "[cyan]bytinho talk oi tudo bem[/cyan]"
            )
            raise typer.Exit(1)

        res = client.talk(message)
        h = client.health()
        if res is None:
            cached = load_cache() or {}
            show_static(cached.get("pet", empty_pet()), h, cached.get("nick"),
                        msg="The Core offline.")
            return
        pet = res.get("pet") or (load_cache() or {}).get("pet") or empty_pet()
        cached = load_cache() or {}
        nick = cached.get("nick")
        streak = cached.get("streak") or {}
        cache({"pet": pet, "nick": nick, "streak": streak,
               "achievements": cached.get("achievements", [])})

        # Sempre usamos o reply plain como corpo. O server pode mandar
        # `reply_rich` (futuro), mas o layout é client-side pra ficar
        # consistente entre versões de server.
        reply = res.get("reply") or "..."

        if quiet:
            console.print(_talk_ui.render_talk_quiet(pet, reply))
        else:
            console.print(_talk_ui.render_talk(pet, reply, nick, streak, tick=0))

    @app.command(hidden=True)
    def live(fps: float = typer.Option(6.0, help="Frames por segundo.")):
        """Modo vivo permanente — Bytinho respira, pisca e pensa."""
        pet, h, nick_, streak, _toasts = refresh()
        tick = 0
        last_sync = time.time()
        last_whisper = time.time()
        WHISPER_INTERVAL = 60.0
        whisper_msg: str | None = None
        whisper_until: float = 0.0

        try:
            with Live(panel(pet, h, nick_, tick=tick, streak=streak), console=console,
                      refresh_per_second=fps, screen=False) as view:
                while True:
                    time.sleep(1.0 / max(fps, 1.0))
                    tick += 1

                    if time.time() - last_sync > 15:
                        pet, h, nick_, streak, _toasts = refresh()
                        last_sync = time.time()

                    # Whisper de iniciativa após silêncio
                    if time.time() - last_whisper > WHISPER_INTERVAL:
                        soul = (pet.get("soul") or {})
                        persona = soul.get("personality", "fofo")
                        from ..dialogue_client import idle_whisper_for
                        whisper_msg = idle_whisper_for(persona)
                        whisper_until = time.time() + 8.0
                        last_whisper = time.time()

                    # Limpa whisper após 8s
                    if whisper_msg and time.time() > whisper_until:
                        whisper_msg = None

                    view.update(panel(pet, h, nick_, tick=tick, streak=streak,
                                      message=whisper_msg))

        except KeyboardInterrupt:
            console.print("\n[dim]até mais 👋[/dim]")

    @app.command(
        "speak",
        context_settings={"allow_interspersed_args": False},
    )
    def speak_cmd(
        words: list[str] = typer.Argument(
            None,
            metavar="MESSAGE",
            help="Mensagem inicial (opcional). Sem aspas.",
        ),
    ):
        """Modo interativo split: Bytinho em cima, chat embaixo, input sempre visível.

            bytinho speak
            bytinho speak oi tudo bem
        """
        from ..speak_tui import SpeakTUI
        initial = " ".join(words).strip() if words else None
        SpeakTUI().run(initial_message=initial)

    @app.command(hidden=True)
    def chat():
        """[soft-launch: oculto] Chat Global — desabilitado para o lançamento."""
        console.print(
            "[yellow]chat global está desabilitado neste lançamento.[/yellow]\n"
            "[dim]use `bytinho speak` pra falar com seu pet ou "
            "`bytinho ranking` pra ver o top da semana.[/dim]"
        )
        raise typer.Exit(0)
