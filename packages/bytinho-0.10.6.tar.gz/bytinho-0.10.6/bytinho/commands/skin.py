"""Comando bytinho skin <cor>: muda a paleta visual do pet (local-only)."""
import typer

from ..prefs import (
    SKINS,
    get_catchphrase,
    get_skin,
    reset_catchphrase,
    reset_skin,
    set_catchphrase,
    set_skin,
)
from ..render import console, live_for, refresh


def _skin_impl(name: str | None) -> None:
    if name is None:
        current = get_skin() or "(default = cyan)"
        console.print(f"[bold]skin atual:[/bold] {current}")
        console.print(f"[dim]disponíveis:[/dim] {', '.join(SKINS)}")
        console.print("[dim]uso:[/dim] [cyan]bytinho skin <cor>[/cyan]")
        return

    if name.lower() == "reset":
        reset_skin()
        console.print("[green]✓ skin resetada (volta ao default)[/green]")
    else:
        ok, msg = set_skin(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ skin: [{msg}]{msg}[/{msg}][/green]")

    pet, h, nick_, streak, toasts = refresh()
    live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)


def register(app: typer.Typer) -> None:
    @app.command()
    def skin(
        name: str = typer.Argument(
            None,
            help=f"Nome da cor. Disponíveis: {', '.join(SKINS)}. Use 'reset' pra voltar ao default.",
        ),
    ):
        """Muda a cor do teu Bytinho. Sem argumento = mostra a atual."""
        _skin_impl(name)

    @app.command()
    def color(
        name: str = typer.Argument(
            None,
            help=f"Alias de 'skin'. Disponíveis: {', '.join(SKINS)}. Use 'reset' pra voltar.",
        ),
    ):
        """Alias de `skin`: muda a cor do teu Bytinho."""
        _skin_impl(name)

    @app.command()
    def catchphrase(
        phrase: str = typer.Argument(
            None,
            help="Bordão local. Use 'reset' pra voltar ao da soul. Sem arg = mostra atual.",
        ),
    ):
        """Define o bordão do teu Bytinho (local). Máx 30 chars."""
        if phrase is None:
            current = get_catchphrase() or "(default da soul)"
            console.print(f"[bold]bordão atual:[/bold] {current}")
            console.print(
                "[dim]uso:[/dim] [cyan]bytinho catchphrase \"<frase>\"[/cyan]"
            )
            return

        if phrase.lower() == "reset":
            reset_catchphrase()
            console.print("[green]✓ bordão resetado[/green]")
            return

        ok, msg = set_catchphrase(phrase)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ bordão:[/green] [italic]{msg}[/italic]")
