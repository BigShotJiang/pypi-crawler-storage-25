"""Comandos de identidade: nick, rename, export, import."""
import typer

from .. import client, prefs
from ..render import console, live_for, refresh
from ..session import set_user_id, user_id


def register(app: typer.Typer) -> None:
    @app.command()
    def nick(name: str = typer.Argument(...)):
        """Define teu nick global."""
        ok, msg = client.set_nick(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ nick: {name}[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)

    @app.command()
    def rename(name: str = typer.Argument(..., help="Novo nome do bichinho.")):
        """Dá um nome próprio pro teu Bytinho."""
        ok, msg = client.rename_pet(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ pet renomeado: {name}[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)

    @app.command("export")
    def export_cmd():
        """Mostra teu código de recuperação (use em outra máquina com `import`)."""
        uid = user_id()
        console.print()
        console.print("[bold magenta]🔑  Código de recuperação do Bytinho:[/bold magenta]")
        console.print()
        console.print(f"   [bold cyan]{uid}[/bold cyan]")
        console.print()
        console.print("[dim]Guarde isso em local seguro. Quem tiver esse código TEM o teu pet.[/dim]")
        console.print("[dim]Em outra máquina rode:[/dim]")
        console.print(f"[dim]   bytinho import {uid}[/dim]")
        console.print()

    @app.command("import")
    def import_cmd(code: str = typer.Argument(..., help="Código de recuperação (UUID).")):
        """Importa um pet de outra máquina usando o código de recuperação."""
        ok, msg = set_user_id(code)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ identidade restaurada: {msg[:8]}…[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, msg="bem-vindo de volta 💜", seconds=3.0, fps=6.0,
                 streak=streak, toasts=toasts)

    @app.command("persona")
    def persona_cmd(
        name: str = typer.Argument(
            None,
            help="Nome da persona. Vazio = mostra atual e opções.",
        ),
        reset: bool = typer.Option(False, "--reset", help="Volta pra persona do servidor."),
    ):
        """Escolhe o tom do Bytinho. Override 100% local — nunca vai pro servidor."""
        if reset:
            prefs.reset_persona()
            console.print("[green]✓ persona resetada — voltou pra do servidor[/green]")
            return
        if not name:
            current = prefs.get_persona()
            console.print()
            if current:
                console.print(f"[bold]persona atual (override local):[/bold] [cyan]{current}[/cyan]")
            else:
                console.print("[dim]nenhum override — usando a persona do servidor[/dim]")
            console.print()
            console.print("[bold]disponíveis:[/bold]")
            for p in prefs.PERSONAS:
                console.print(f"  · [cyan]{p}[/cyan]")
            console.print()
            console.print("[dim]uso:  bytinho persona minimalista[/dim]")
            return
        ok, msg = prefs.set_persona(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ persona: {msg}[/green]")
