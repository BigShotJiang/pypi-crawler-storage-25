"""bytinho standup — resumo dos commits do dia/semana.

Saída pronta pra colar no Slack/daily. 100% offline.

NOTA: a flag --ai existe mas está oculta até v0.10.1
(endpoint /v1/ai/duck ainda não existe no server).
"""
from __future__ import annotations

import subprocess

import typer
from rich.console import Console
from rich.panel import Panel

console = Console()


def _git(*args: str) -> str:
    return subprocess.run(["git", *args], capture_output=True, text=True, check=False).stdout


def _author() -> str:
    return _git("config", "user.email").strip() or _git("config", "user.name").strip() or "me"


def _commits(since: str, author: str | None) -> list[dict]:
    args = ["log", f"--since={since}", "--pretty=format:%h|%s|%ai|%ae", "--no-merges"]
    if author:
        args.append(f"--author={author}")
    out = _git(*args)
    res = []
    for line in out.splitlines():
        parts = line.split("|", 3)
        if len(parts) != 4:
            continue
        sha, subj, when, mail = parts
        res.append({"sha": sha, "subj": subj, "when": when, "author": mail})
    return res


def _classify(subj: str) -> str:
    s = subj.lower()
    for kind in ("feat", "fix", "refactor", "test", "docs", "perf", "chore", "ci"):
        if s.startswith(kind):
            return kind
    return "other"


def _files_touched(since: str) -> int:
    out = _git("log", f"--since={since}", "--name-only", "--pretty=format:", "--no-merges")
    return len({line for line in out.splitlines() if line.strip()})


def standup_cmd(
    period: str = typer.Option("day", "--period", help="day | week"),
    all_authors: bool = typer.Option(False, "--all-authors", help="Não filtra por autor."),
    ai: bool = typer.Option(
        False, "--ai",
        help="[em breve] resumo IA do standup.",
        hidden=True,  # endpoint /v1/ai/duck ainda não existe (v0.10.1)
    ),
) -> None:
    """Mostra commits do período, agrupados por tipo. Pronto pra daily."""
    if period not in ("day", "week"):
        raise typer.BadParameter("--period deve ser 'day' ou 'week'")
    since = "1 day ago" if period == "day" else "7 days ago"
    author = None if all_authors else _author()
    commits = _commits(since, author)

    if not commits:
        console.print(f"[dim]sem commits nas últimas {since}.[/dim]")
        return

    by_kind: dict[str, list[dict]] = {}
    for c in commits:
        by_kind.setdefault(_classify(c["subj"]), []).append(c)

    files = _files_touched(since)
    header = (
        f"[bold]{len(commits)}[/bold] commits · "
        f"[bold]{files}[/bold] arquivos tocados · "
        f"período: [cyan]{period}[/cyan]"
    )
    console.print(Panel(header, border_style="cyan"))

    order = ["feat", "fix", "refactor", "perf", "test", "docs", "chore", "ci", "other"]
    for kind in order:
        items = by_kind.get(kind)
        if not items:
            continue
        console.print(f"\n[bold]{kind}[/bold] ({len(items)}):")
        for c in items[:10]:
            console.print(f"  · [dim]{c['sha']}[/dim] {c['subj']}")
        if len(items) > 10:
            console.print(f"  [dim]… +{len(items) - 10}[/dim]")

    if ai:
        console.print(
            "[dim]--ai ainda em desenvolvimento. Vai chegar na v0.10.1.[/dim]"
        )


def register(app: typer.Typer) -> None:
    app.command("standup")(standup_cmd)


# Mantido para reuso quando o endpoint /v1/ai/duck existir.
def _ai_blurb(commits: list[dict],  # noqa: ARG001
              by_kind: dict[str, list[dict]]) -> None:  # noqa: ARG001
    """Stub: será reativado em v0.10.1 quando server tiver /v1/ai/duck."""
    return
