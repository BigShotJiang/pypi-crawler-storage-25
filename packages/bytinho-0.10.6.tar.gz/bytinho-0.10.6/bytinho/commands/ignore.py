"""`bytinho ignore` — opt-out de envio do hook (P0-4).

Subcomandos:
  bytinho ignore here       cria .bytinhoignore no repo atual
  bytinho ignore unhere     remove .bytinhoignore do repo atual
  bytinho ignore add PATH   adiciona path à skip-list global
  bytinho ignore rm PATH    remove path da skip-list global
  bytinho ignore list       mostra estado atual

Sem subcomando = `list`.
"""
from __future__ import annotations

import typer

from .. import privacy
from ..render import console


def register(app: typer.Typer) -> None:
    ignore = typer.Typer(
        help="Pula envio de commits do(s) repo(s) escolhidos.",
        invoke_without_command=True,
        no_args_is_help=False,
    )

    @ignore.callback()
    def _default(ctx: typer.Context):
        if ctx.invoked_subcommand is None:
            _list_impl()

    @ignore.command("here")
    def here():
        """Cria .bytinhoignore no repo atual (Bytinho ignora pra sempre)."""
        ok, msg = privacy.add_here()
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ pulando este repo:[/green] {msg}")
        console.print(
            "[dim]também pode usar [cyan]BYTINHO_SKIP=1 git commit[/cyan] "
            "pra pular um commit pontual.[/dim]"
        )

    @ignore.command("unhere")
    def unhere():
        """Remove .bytinhoignore do repo atual."""
        ok, msg = privacy.rm_here()
        if not ok:
            console.print(f"[yellow]· {msg}[/yellow]")
            return
        console.print(f"[green]✓ reativado:[/green] {msg}")

    @ignore.command("add")
    def add(path: str = typer.Argument(..., help="Caminho do repo a ignorar.")):
        """Adiciona um repo à skip-list global."""
        ok, msg = privacy.add_global(path)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ na skip-list global:[/green] {msg}")

    @ignore.command("rm")
    def rm(path: str = typer.Argument(..., help="Caminho a remover da skip-list.")):
        """Remove um repo da skip-list global."""
        ok, msg = privacy.rm_global(path)
        if not ok:
            console.print(f"[yellow]· {msg}[/yellow]")
            return
        console.print(f"[green]✓ removido:[/green] {msg}")

    @ignore.command("list")
    def list_cmd():
        """Mostra estado atual."""
        _list_impl()

    app.add_typer(ignore, name="ignore")


def _list_impl() -> None:
    items = privacy.list_global()
    skipped, reason = privacy.is_skipped()

    console.print()
    console.print("[bold]Bytinho privacy / opt-out[/bold]")
    if skipped:
        console.print(f"  [yellow]· cwd está sendo pulado: {reason}[/yellow]")
    else:
        console.print("  [dim]· cwd: enviando normalmente.[/dim]")

    console.print()
    if items:
        console.print("[bold]skip-list global:[/bold]")
        for p in items:
            console.print(f"  [dim]·[/dim] {p}")
    else:
        console.print("[dim]skip-list global vazia.[/dim]")

    console.print()
    console.print(
        "[dim italic]opt-outs:[/dim italic]\n"
        "[dim]  · [cyan]BYTINHO_SKIP=1 git commit[/cyan]   "
        "(pular um commit)\n"
        "  · [cyan]bytinho ignore here[/cyan]            "
        "(pular este repo pra sempre)\n"
        "  · [cyan]bytinho ignore add PATH[/cyan]        "
        "(skip-list global)[/dim]"
    )
