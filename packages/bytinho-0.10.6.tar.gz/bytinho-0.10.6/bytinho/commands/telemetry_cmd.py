"""Comando `bytinho telemetry` — status + direito ao esquecimento.

Telemetria anônima é sempre ON (zero PII, só eventos agregados).
Única saída: `--forget` apaga tudo do server e desliga local.
"""
import typer

from .. import telemetry
from ..render import console


def register(app: typer.Typer) -> None:
    @app.command("telemetry")
    def telemetry_cmd(
        forget: bool = typer.Option(
            False, "--forget",
            help="Apaga TODOS teus eventos do server e desliga. Irreversível.",
        ),
    ):
        """Mostra status da telemetria anônima.

        Sempre ligada por padrão. Use --forget pra apagar tudo do server.
        Zero PII — só eventos agregados (install, first_commit, etc).
        """
        if forget:
            if not typer.confirm(
                "apagar TODOS teus eventos do server e desligar?",
                default=False,
            ):
                return
            ok = telemetry.forget_remote()
            telemetry.set_enabled(False)
            if ok:
                console.print(
                    "[green]✓ apagado do server. telemetria off neste device.[/green]"
                )
            else:
                console.print(
                    "[yellow]⚠ não consegui falar com o server, "
                    "mas desliguei localmente.[/yellow]"
                )
            return

        # Sem flag: mostra status
        on_now = telemetry.is_enabled()
        if on_now:
            console.print(
                "[green]telemetria: ON[/green] [dim](anônima, agregada, zero PII)[/dim]"
            )
            console.print(
                "[dim]eventos coletados: install / first_commit / first_unlock / "
                "stage_up / daily_active[/dim]"
            )
            console.print(
                "[dim]apagar tudo do server?[/dim] "
                "[cyan]bytinho telemetry --forget[/cyan]"
            )
        else:
            console.print("[yellow]telemetria: OFF[/yellow] [dim](você desligou)[/dim]")
