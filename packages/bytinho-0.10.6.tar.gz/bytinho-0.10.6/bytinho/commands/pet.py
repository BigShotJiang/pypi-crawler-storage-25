"""Comandos básicos do pet: status (abre TUI).

Feed/play/sleep/wake foram removidos no MVP — o pet espelha a
atividade real do dev (commits + editor aberto). Sem cuidado manual.
"""
import typer


def register(app: typer.Typer) -> None:
    @app.command()
    def status():
        """Abre a TUI do Bytinho."""
        from ..speak_tui import SpeakTUI
        SpeakTUI().run()
