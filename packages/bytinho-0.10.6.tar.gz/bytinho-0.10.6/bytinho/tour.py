"""Tour interativo de 5 telas — onboarding rápido pós-lore.

Roda no primeiro `bytinho` e em qualquer execução até o usuário
marcar como visto. Pode ser pulado com Ctrl+C ou Esc.
"""
from __future__ import annotations

from rich.panel import Panel
from rich.text import Text

from . import prefs
from .render import console


def _press_enter(skip_label: str = "Esc/Ctrl+C pula") -> bool:
    """Espera Enter. Retorna False se user pular (Ctrl+C / EOF)."""
    try:
        console.print(f"[dim italic]Enter para continuar  ·  {skip_label}[/dim italic]")
        input()
        return True
    except (EOFError, KeyboardInterrupt):
        return False


def _screen(num: int, total: int, title: str, body: Text) -> None:
    console.clear()
    console.print()
    console.print(f"[dim]({num}/{total})[/dim]  [bold cyan]{title}[/bold cyan]")
    console.print()
    console.print(Panel(body, border_style="dim cyan", padding=(1, 3), width=72))
    console.print()


def run_tour() -> None:
    """Mostra o tour. Marca como visto ao final OU se user pular."""
    if prefs.has_seen_tour():
        return

    # P1-1: tour exige Enter interativo. Em non-tty/CI marca como visto sem
    # mostrar nada (next call no-ops) — evita travar scripts.
    from .tty import is_interactive
    if not is_interactive():
        prefs.mark_tour_seen()
        return

    total = 5

    # ── 1: o que é
    body = Text.from_markup(
        "[bold]Bytinho[/bold] é um pet de terminal que cresce com teus commits.\n\n"
        "Ele conversa contigo (IA), guarda streak, marca conquistas\n"
        "e mostra estado do teu workflow numa TUI.\n\n"
        "[dim]Sem login. Sem senha. Só um UUID local.[/dim]"
    )
    _screen(1, total, "o que é o Bytinho", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 2: conversar
    body = Text.from_markup(
        "Na TUI, [bold cyan]digite qualquer texto[/bold cyan] e dê Enter.\n"
        "O Bytinho responde via IA, com a persona dele.\n\n"
        "[dim]exemplo:[/dim]\n"
        "  [bold]> oi, terminei o feature X[/bold]\n"
        "  [cyan]→ boa. roda os testes antes do push.[/cyan]\n\n"
        "[dim]Para mudar o tom dele:[/dim]  [cyan]bytinho persona minimalista[/cyan]"
    )
    _screen(2, total, "conversar", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 3: navegar
    body = Text.from_markup(
        "Use [bold cyan]:letra[/bold cyan] pra trocar de seção:\n\n"
        "  [bold cyan]:s[/bold cyan]   stats          [bold cyan]:r[/bold cyan]   ranking\n"
        "  [bold cyan]:a[/bold cyan]   conquistas     [bold cyan]:n[/bold cyan]   próximas\n"
        "  [bold cyan]:c[/bold cyan]   chat global    [bold cyan]:m[/bold cyan]   missões\n"
        "  [bold cyan]:l[/bold cyan]   closet         [bold cyan]:?[/bold cyan]   ajuda completa\n\n"
        "[dim]Esc volta pro chat a qualquer momento.[/dim]"
    )
    _screen(3, total, "navegar", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 4: ações
    body = Text.from_markup(
        "Use [bold cyan]/comando[/bold cyan] pra cuidar do pet:\n\n"
        "  [bold cyan]/feed [/bold cyan]   alimenta (fome alta? usa isso)\n"
        "  [bold cyan]/play [/bold cyan]   brinca (sobe humor)\n"
        "  [bold cyan]/sleep[/bold cyan]   dorme (regenera energia)\n"
        "  [bold cyan]/wake [/bold cyan]   acorda\n"
        "  [bold cyan]/code [/bold cyan]   marca commit manual (sem hook)\n\n"
        "[dim]A TUI mostra status (fome/energia/humor) abaixo do sprite.[/dim]"
    )
    _screen(4, total, "cuidar do pet", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 5: commits = XP
    body = Text.from_markup(
        "O Bytinho cresce automático com cada [bold]git commit[/bold].\n\n"
        "Se aceitaste instalar o hook, tá pronto.\n"
        "Senão, dentro de qualquer repo git roda:\n\n"
        "  [bold cyan]bytinho install-hook[/bold cyan]\n\n"
        "[dim]Hook é não-bloqueante: se o servidor cair, teu commit passa igual.[/dim]\n\n"
        "[bold green]bora![/bold green]  abre a TUI com [bold cyan]bytinho[/bold cyan]\n"
        "[dim]rever este tour:[/dim]  [cyan]bytinho tour[/cyan]"
    )
    _screen(5, total, "commits = XP", body)
    _press_enter("Enter pra começar")

    prefs.mark_tour_seen()
    console.clear()
