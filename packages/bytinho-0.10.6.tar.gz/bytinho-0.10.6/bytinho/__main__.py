import time

import typer

from . import client
from .render import console

app = typer.Typer(
    add_completion=False,
    help="Bytinho — um pet digital que vive no teu terminal.",
    no_args_is_help=False,
    invoke_without_command=True,
)


@app.callback()
def _default(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        from .lore import show_lore
        from .session import is_first_run
        from .tour import run_tour
        from .tty import is_interactive

        # P1-1: non-tty / CI / piped → don't try to onboard. Print a tiny
        # status line and exit cleanly so scripts and CI don't hang.
        if not is_interactive():
            from . import __version__
            console.print(
                f"Bytinho {__version__} — non-interactive mode.\n"
                "Run [cyan]bytinho --help[/cyan] for commands, or set "
                "[dim]BYTINHO_NONINTERACTIVE=0[/dim] to force the TUI."
            )
            return

        if is_first_run():
            show_lore()
            _welcome()
            run_tour()
            # after onboarding → drop straight into speak TUI
            from .speak_tui import SpeakTUI
            SpeakTUI().run()
        else:
            # returning user → run tour if never seen, then speak
            run_tour()
            from .speak_tui import SpeakTUI
            SpeakTUI().run()


@app.command("tour", hidden=True)
def tour_cmd(
    reset: bool = typer.Option(False, "--reset", help="Mostra o tour de novo."),
):
    """Roda o tour interativo de 5 telas."""
    from . import prefs
    from .tour import run_tour
    if reset:
        # force re-run by clearing the seen flag
        data = prefs._load()
        data.pop("seen_tour", None)
        prefs._save(data)
    run_tour()


def _welcome() -> None:
    """Onboarding no primeiro `bytinho`.

    Fluxo:
      1) Pergunta nome do pet
      2) Mostra UUID (chave de recuperação) + explica como guardar
      3) Oferece importar pet existente (recuperação)
      4) Se cwd for repo git → oferece instalar o hook
    """
    import subprocess

    from rich.panel import Panel
    from rich.prompt import Confirm, Prompt
    from rich.rule import Rule
    from rich.text import Text

    from . import telemetry
    from .session import user_id

    console.print()
    console.print(Rule(style="magenta"))
    body = Text.from_markup(
        "\n[bold magenta]Hey, I'm Bytinho.[/bold magenta]\n\n"
        "I'll live in your terminal and grow with every [bold]git commit[/bold].\n"
        "No login, no password — just an anonymous UUID on this machine.\n"
    )
    console.print(Panel(body, border_style="magenta", padding=(0, 2)))

    # ── option to recover an existing pet ────────────────────────────────
    console.print()
    try:
        recover = Confirm.ask(
            "[dim]already have a Bytinho on another machine? [bold cyan]import it now?[/bold cyan][/dim]",
            default=False,
            console=console,
        )
    except (EOFError, KeyboardInterrupt):
        recover = False

    imported = False
    if recover:
        try:
            code = Prompt.ask(
                "[bold cyan]paste your recovery UUID[/bold cyan]",
                console=console,
            ).strip()
        except (EOFError, KeyboardInterrupt):
            code = ""
        if code:
            from .session import set_user_id
            ok, msg = set_user_id(code)
            if ok:
                console.print(f"[green]✓ Bytinho restored! ({msg[:8]}…)[/green]")
                imported = True
            else:
                console.print(f"[yellow]⚠ couldn't import ({msg}), creating a new one[/yellow]")

    # ── pet name ──────────────────────────────────────────────────────────
    # If we imported an existing pet, it already has a name — don't rename.
    if imported:
        pet_name = "Bytinho"  # sentinel: skip rename
    else:
        console.print()
        try:
            pet_name = Prompt.ask(
                "[bold cyan]what should I be called?[/bold cyan]",
                default="Bytinho",
                console=console,
            ).strip() or "Bytinho"
        except (EOFError, KeyboardInterrupt):
            pet_name = "Bytinho"

    if not imported and pet_name != "Bytinho":
        ok, msg = client.rename_pet(pet_name)
        if ok:
            console.print(f"[green]✓ Nice to meet you — I'm {pet_name}![/green]")
        else:
            console.print(f"[yellow]⚠ name not accepted ({msg}), staying as Bytinho[/yellow]")

    # ── show UUID / recovery key ──────────────────────────────────────────
    uid = user_id()
    console.print()
    console.print(Panel(
        Text.from_markup(
            "[bold]🔑  Save this recovery key:[/bold]\n\n"
            f"   [bold cyan]{uid}[/bold cyan]\n\n"
            "[dim]This key IS your Bytinho. Whoever has it, owns the pet.\n"
            "On another machine: [cyan]bytinho import <key>[/cyan][/dim]"
        ),
        border_style="dim cyan",
        padding=(0, 2),
    ))

    # ── README badge ─────────────────────────────────────────────────────
    console.print()
    console.print("[dim]bonus: paste this in your README to show your pet to the world:[/dim]")
    console.print(
        "  [dim cyan][![my bytinho](https://bytinho.com/u/YOUR-NICK.svg)](https://bytinho.com/u/YOUR-NICK)[/dim cyan]"
    )
    console.print("[dim](replace YOUR-NICK with your handle after running [cyan]bytinho nick <handle>[/cyan])[/dim]")

    # ── git hook ──────────────────────────────────────────────────────────
    in_repo = False
    try:
        subprocess.check_output(["git", "rev-parse", "--git-dir"],
                                 stderr=subprocess.DEVNULL)
        in_repo = True
    except Exception:
        pass

    console.print()
    if in_repo:
        console.print(
            "[dim]• each commit sends a tiny anonymous payload (kind, languages,\n"
            "  branch, lines added/removed, message ≤200 chars). NO source code,\n"
            "  NO file paths. Opt out anytime: [cyan]bytinho ignore here[/cyan][/dim]"
        )
        console.print("[dim]I noticed you're inside a git repo — I can plug in:[/dim]")
        try:
            yes = Confirm.ask(
                "[bold cyan]install the hook? every commit becomes XP automatically[/bold cyan]",
                default=True,
                console=console,
            )
        except (EOFError, KeyboardInterrupt):
            yes = False

        if yes:
            from .commands.dev import _install_hook_here
            ok, where = _install_hook_here()
            if ok:
                telemetry.track("hook_installed")
                console.print(f"[green]✓ connected at[/green] {where}")
            else:
                console.print(
                    f"[yellow]⚠ couldn't install ({where}).[/yellow] "
                    "Run later: [cyan]bytinho install-hook[/cyan]"
                )
    else:
        console.print(
            "[dim]when you're inside a git repo, run[/dim] "
            "[cyan]bytinho install-hook[/cyan] [dim]so every commit becomes XP[/dim]"
        )

    # ── global hook (covers ALL repos at once) ─────────────────────────────
    console.print()
    try:
        global_yes = Confirm.ask(
            "[bold cyan]plug Bytinho into ALL your git repos? (recommended)[/bold cyan]",
            default=True,
            console=console,
        )
    except (EOFError, KeyboardInterrupt):
        global_yes = False

    if global_yes:
        from .commands.dev import _install_global_hooks
        ok, where = _install_global_hooks()
        if ok:
            telemetry.track("hook_installed_global")
            console.print(f"[green]✓ global hooks active at[/green] {where}")
            console.print("[dim]every commit in any repo will now feed me.[/dim]")
        else:
            console.print(
                f"[yellow]⚠ couldn't set up globally ({where})[/yellow]\n"
                "[dim]run later: [cyan]bytinho install-hook --global[/cyan][/dim]"
            )

    telemetry.track("install")
    telemetry.track("welcome_complete")
    console.print()
    console.print("[dim]opening Bytinho…[/dim]")
    time.sleep(0.8)


# ── MVP commands (v0.10): siempre visibles ───────────────────────────────
from .commands.pet import register as _register_pet  # noqa: E402
from .commands.identity import register as _register_identity  # noqa: E402
from .commands.dev import register as _register_dev  # noqa: E402
from .commands.social import register as _register_social  # noqa: E402
from .commands.chat import register as _register_chat  # noqa: E402
from .commands.meta import register as _register_meta  # noqa: E402
from .commands.telemetry_cmd import register as _register_telemetry  # noqa: E402
from .commands.ignore import register as _register_ignore  # noqa: E402

_register_pet(app)
_register_identity(app)
_register_dev(app)
_register_social(app)
_register_chat(app)
_register_meta(app)
_register_telemetry(app)
_register_ignore(app)

# ── Experimental commands: ocultos detrás de BYTINHO_EXPERIMENTAL=1 ──────
# El código sigue existiendo (no borrado) — solo no aparece en --help para
# mantener el MVP enfocado. Llegan al README oficial en v0.11+.
import os as _os  # noqa: E402

if _os.environ.get("BYTINHO_EXPERIMENTAL") == "1":
    from .commands.card import register as _register_card  # noqa: E402
    from .commands.closet import register as _register_closet  # noqa: E402
    from .commands.hook_cmd import register as _register_hook  # noqa: E402
    from .commands.next_cmd import register as _register_next  # noqa: E402
    from .commands.review import register as _register_review  # noqa: E402
    from .commands.skin import register as _register_skin  # noqa: E402
    from .commands.stats import register as _register_stats  # noqa: E402
    from .commands.guard import register as _register_guard  # noqa: E402
    from .commands.diff_review import register as _register_diff_review  # noqa: E402
    from .commands.standup import register as _register_standup  # noqa: E402

    _register_card(app)
    _register_closet(app)
    _register_hook(app)
    _register_next(app)
    _register_review(app)
    _register_skin(app)
    _register_stats(app)
    _register_guard(app)
    _register_diff_review(app)
    _register_standup(app)


if __name__ == "__main__":
    app()
