from rich.align import Align
from rich.console import Group
from rich.panel import Panel
from rich.progress_bar import ProgressBar
from rich.table import Table
from rich.text import Text

from .config import e
from .cosmetics import render_hat
from .pet_logic import STAGE_AGE, STAGE_EMOJI, STAGE_LABEL, STAGE_THRESHOLD
from .prefs import get_skin
from .sprites import render, sway, thought_for

# STAGE_AGE / STAGE_LABEL / STAGE_THRESHOLD agora vivem em pet_logic.py.
# Re-exportados aqui pra retrocompatibilidade de imports antigos.


def _bar(v: float, color: str) -> ProgressBar:
    return ProgressBar(total=100, completed=max(0, min(100, v)),
                       complete_style=color, finished_style=color)


def _stage(pet: dict) -> str:
    """status agregado pro emoji ao lado da fome/energia."""
    if pet.get("asleep"):
        return "💤"
    if pet.get("hunger", 100) < 25:
        return "🍕?"
    if pet.get("mood", 100) < 25:
        return "😢"
    if pet.get("energy", 100) < 25:
        return "😪"
    return "😺"


def _xp_bar(xp: int, stage: str) -> ProgressBar:
    """Progresso pra próxima evolução."""
    idx = STAGE_AGE.index(stage) if stage in STAGE_AGE else 0
    base = STAGE_THRESHOLD[stage]
    nxt_idx = min(idx + 1, len(STAGE_AGE) - 1)
    nxt = STAGE_THRESHOLD[STAGE_AGE[nxt_idx]]
    if nxt <= base:
        return ProgressBar(total=100, completed=100, complete_style="bright_magenta")
    pct = max(0, min(100, (xp - base) * 100 / (nxt - base)))
    return ProgressBar(total=100, completed=pct, complete_style="bright_magenta")


def _xp_label(xp: int, stage: str) -> str:
    """Texto tipo 'Próx. 47/200' ou 'no topo' quando lenda."""
    idx = STAGE_AGE.index(stage) if stage in STAGE_AGE else 0
    base = STAGE_THRESHOLD[stage]
    nxt_idx = idx + 1
    if nxt_idx >= len(STAGE_AGE):
        return "🛸 lenda"
    nxt = STAGE_THRESHOLD[STAGE_AGE[nxt_idx]]
    cur = max(0, xp - base)
    need = nxt - base
    nxt_label = STAGE_LABEL.get(STAGE_AGE[nxt_idx], STAGE_AGE[nxt_idx])
    return f"→ {nxt_label} {cur}/{need}"


def _stage_progress_line(xp: int, stage: str, width: int = 18) -> Text:
    """Linha dedicada de progresso entre estágios.

    Formato: `🐣 Hatchling → 👶 Junior  ▓▓▓░░░░░░░░░  47/200 XP`
    Quando já é lenda: `👑 Lenda  ✦✦✦✦✦✦✦✦✦  50000+ XP`.
    """
    cur_em = STAGE_EMOJI.get(stage, "·")
    cur_lbl = STAGE_LABEL.get(stage, stage)
    idx = STAGE_AGE.index(stage) if stage in STAGE_AGE else 0
    nxt_idx = idx + 1
    if nxt_idx >= len(STAGE_AGE):
        bar = "✦" * width
        return Text.from_markup(
            f"  [bold yellow]{cur_em} {cur_lbl}[/bold yellow]   "
            f"[bright_magenta]{bar}[/bright_magenta]   "
            f"[dim]{xp}+ XP[/dim]"
        )
    nxt = STAGE_AGE[nxt_idx]
    nxt_em = STAGE_EMOJI.get(nxt, "·")
    nxt_lbl = STAGE_LABEL.get(nxt, nxt)
    base = STAGE_THRESHOLD[stage]
    target = STAGE_THRESHOLD[nxt]
    cur = max(0, xp - base)
    need = max(1, target - base)
    pct = max(0.0, min(1.0, cur / need))
    filled = int(round(pct * width))
    bar = "▓" * filled + "░" * (width - filled)
    return Text.from_markup(
        f"  [bold]{cur_em} {cur_lbl}[/bold] [dim]→[/dim] "
        f"[bold cyan]{nxt_em} {nxt_lbl}[/bold cyan]   "
        f"[bright_magenta]{bar}[/bright_magenta]   "
        f"[dim]{cur}/{need} XP[/dim]"
    )


def _streak_tag(streak: dict | None) -> str:
    if not streak:
        return ""
    days = int(streak.get("days") or 0)
    if days <= 0:
        return ""
    active = streak.get("active_today")
    color = "bright_red" if active else "yellow"
    suffix = "" if active else " [dim](commit hoje p/ manter)[/dim]"
    return f"   [{color}]🔥 {days}d streak[/{color}]{suffix}"


# Caixa fixa onde o pet mora. Sway acontece DENTRO dela, então o painel
# nunca desloca. Altura ajustada para caber em terminais 30 rows + GIFs.
STAGE_W = 24
STAGE_H = 8  # 5 linhas de sprite + 1 "ar" + 1 sombra + 1 chão


def _frame_sprite(sprite: str, sx: int, asleep: bool, tick: int,
                  stage: str = "egg", streak_days: int = 0,
                  jump: int = 0) -> str:
    lines = sprite.split("\n")
    sw = max(len(l) for l in lines)
    sh = len(lines)

    base_left = (STAGE_W - sw) // 2
    left = max(0, min(STAGE_W - sw, base_left + sx))

    # pet pousa no chão: última linha do pet bate na penúltima linha da caixa
    top = STAGE_H - 1 - sh - jump  # jump levanta o pet (rows pra cima)
    if top < 0:
        top = 0

    out = []
    for i in range(STAGE_H):
        if top <= i < top + sh:
            line = lines[i - top]
            row = " " * left + line + " " * (STAGE_W - left - len(line))
        else:
            row = " " * STAGE_W
        out.append(row)

    # chão animado: '~' pulsa pra dar sensação de gramado
    if asleep:
        floor = "_" * STAGE_W
    elif streak_days >= 7:
        # streak alto: chamas no chão
        a, b = ("^", "~") if tick % 2 == 0 else ("~", "^")
        floor = (a + b) * (STAGE_W // 2)
    else:
        a, b = ("~", "-") if tick % 2 == 0 else ("-", "~")
        floor = (a + b) * (STAGE_W // 2)
    out[-1] = floor[:STAGE_W]

    # sombrinha sob o pet (linha logo acima do chão se vazia)
    shadow_row = STAGE_H - 1 - 1
    if out[shadow_row].strip() == "":
        sw2 = sw // 2
        cx = left + sw // 2
        sh_line = list(" " * STAGE_W)
        for j in range(max(0, cx - sw2 // 2), min(STAGE_W, cx + sw2 // 2 + 1)):
            sh_line[j] = "."
        out[shadow_row] = "".join(sh_line)

    # AURA: overlays que escrevem APENAS em células vazias (preserva sprite).
    out = _apply_aura(out, stage, asleep, tick)
    return "\n".join(out)


def _apply_aura(rows: list[str], stage: str, asleep: bool, tick: int) -> list[str]:
    """Sobrepõe partículas no entorno do sprite. Só escreve em espaços.

    Não toca no sprite, no chão (última linha) e na sombra (penúltima).
    Garantia: largura de cada linha permanece exatamente STAGE_W.
    """
    if asleep:
        return rows

    overlays: list[tuple[int, int, str]] = []  # (row, col, char)

    if stage == "tenx":
        # 4 estrelinhas orbitando, alternando
        s = "✦" if tick % 2 == 0 else "✧"
        positions = [(1, 2), (2, STAGE_W - 3), (4, 4), (5, STAGE_W - 5)]
        for r, c in positions:
            overlays.append((r, c, s))
    elif stage == "legend":
        # raios + halo (caracteres de 1 célula pra não distorcer)
        s1 = "*" if tick % 4 < 2 else " "
        s2 = "*" if tick % 4 >= 2 else " "
        overlays.append((1, 2, s1))
        overlays.append((2, STAGE_W - 3, s2))
        # halo no topo
        for c in range(8, STAGE_W - 8):
            overlays.append((0, c, "°"))
    elif stage == "staff":
        # linhas verticais de energia subindo nos lados
        ch = ":" if tick % 2 == 0 else "."
        for r in range(2, STAGE_H - 2):
            overlays.append((r, 1, ch))
            overlays.append((r, STAGE_W - 2, ch))

    if not overlays:
        return rows

    # Aplica só onde for espaço — não destrói nem o sprite nem o chão.
    new_rows = list(rows)
    last_row = STAGE_H - 1
    shadow_row = STAGE_H - 2
    for r, c, ch in overlays:
        if r < 0 or r >= STAGE_H:
            continue
        if r in (last_row, shadow_row):
            continue
        if c < 0 or c >= STAGE_W:
            continue
        line = new_rows[r]
        if line[c] == " ":
            new_rows[r] = line[:c] + ch + line[c + 1:]
    return new_rows


def _sprite_block(pet: dict, tick: int, streak_days: int = 0) -> Text:
    soul = pet.get("soul") or {}
    # Skin local (prefs.json) tem prioridade sobre soul do server.
    color = get_skin() or soul.get("color", "cyan")
    variant = soul.get("variant", "a")
    sprite = render(pet["stage"], pet["mood"], pet["asleep"], variant, tick)

    # Hat equipado vai por cima do sprite (linha 0). Nunca é exibido se o
    # pet estiver dormindo, pra dar a sensação de "pousou o chapéu na mesa".
    hat_code = pet.get("hat")
    if hat_code and not pet.get("asleep"):
        hat_art = render_hat(hat_code)
        if hat_art:
            sprite = hat_art + "\n" + sprite

    # Movimentos: jitter de fome + pulo de alegria.
    sx = sway(tick, pet["asleep"])
    if not pet["asleep"]:
        if pet.get("hunger", 100) < 25:
            # tremidinha: ±1 a cada frame
            sx += 1 if tick % 2 == 0 else -1
        # pulo: 1 row pra cima por 1 frame a cada 8 ticks, se mood alto
    jump = 0
    if not pet["asleep"] and pet.get("mood", 0) >= 90 and tick % 8 == 0:
        jump = 1

    framed = _frame_sprite(sprite, sx, pet["asleep"], tick,
                           stage=pet["stage"], streak_days=streak_days,
                           jump=jump)

    # Balãozinho de pensamento aparece ACIMA da caixa, em 2 linhas próprias.
    # Para evitar "salto" visual do panel, todas as linhas do bloco têm
    # exatamente STAGE_W chars de largura — independente de ter ou não bubble.
    # O bubble fica centrado em STAGE_W e se ajusta caso seja maior que a área.
    bubble = thought_for(pet, tick)
    if bubble:
        text = f"( {bubble} )"
        if len(text) > STAGE_W:
            text = text[: STAGE_W - 2] + " )"
        indent = max(0, (STAGE_W - len(text)) // 2)
        bubble_line  = (" " * indent + text).ljust(STAGE_W)[:STAGE_W]
        arrow_col    = min(STAGE_W - 1, indent + max(1, len(text) // 2))
        bubble_arrow = (" " * arrow_col + "o").ljust(STAGE_W)[:STAGE_W]
        framed = bubble_line + "\n" + bubble_arrow + "\n" + framed
    else:
        framed = " " * STAGE_W + "\n" + " " * STAGE_W + "\n" + framed

    return Text(framed, style=f"bold {color}")


def panel(pet: dict, health: dict, nick: str | None,
          message: str | None = None, tick: int = 0,
          show_credits: bool = False,
          streak: dict | None = None) -> Panel:
    soul = pet.get("soul") or {}
    color = get_skin() or soul.get("color", "cyan")

    streak_days = int((streak or {}).get("days") or 0)
    sprite = _sprite_block(pet, tick, streak_days=streak_days)

    s = Table.grid(padding=(0, 1), expand=True)
    s.add_column(justify="right")
    s.add_column(ratio=1)
    s.add_column(justify="right", min_width=16, max_width=24)
    s.add_row(e("🍕", "F"), Text("Fome"),    _bar(pet["hunger"], "yellow"))
    s.add_row(e("🔋", "E"), Text("Energia"), _bar(pet["energy"], "blue"))
    s.add_row(e("😊", "H"), Text("Humor"),   _bar(pet["mood"], "magenta"))
    s.add_row(e("🧠", "M"), Text("Mente"),   _bar(pet["brain_energy"], "green"))
    s.add_row(e("🌟", "X"), Text(_xp_label(pet["xp"], pet["stage"])),
              _xp_bar(pet["xp"], pet["stage"]))

    is_up = health.get("status") == "ok"
    bstat = health.get("brain", "offline")
    chat  = health.get("chat_online", 0)
    if is_up and bstat == "online":
        dot = f"[green]{e('🟢','[ON]')} The Core online[/green]"
    elif is_up and bstat == "dreaming":
        dot = f"[yellow]{e('🟡','[ZZ]')} The Core sonhando[/yellow]"
    else:
        dot = f"[red]{e('🔴','[OFF]')} The Core offline[/red]"

    label = STAGE_LABEL.get(pet["stage"], pet["stage"])
    star  = " ⭐" if pet.get("patron") else ""
    persona = soul.get("personality")
    persona_tag = f" [dim]({persona})[/dim]" if persona else ""
    mood_em = _stage(pet)

    # Sempre exibimos como "Bytinho de @nick" — o nome do pet vira só
    # apelido interno (futuro). Sem nick: só "Bytinho".
    if nick:
        name_line = f"[bold]Bytinho[/bold] [dim]de[/dim] @{nick}{star}"
    else:
        name_line = f"[bold]Bytinho[/bold]{star}"

    head = Text.from_markup(
        f"{name_line}  {mood_em}  {label}{persona_tag}  "
        f"•  Lv.{pet['level']}  •  {pet['xp']} XP\n"
        f"{dot}   {e('💬','chat:')} {chat} online" + _streak_tag(streak)
    )

    parts = [head, Text(""), Align.center(sprite), Text(""),
             _stage_progress_line(pet["xp"], pet["stage"]),
             Text(""), s]
    if message:
        parts.append(Text(""))
        parts.append(Text.from_markup(f"[italic dim]{message}[/italic dim]"))
    if show_credits:
        parts.append(Text(""))
        parts.append(Text.from_markup(
            f"[dim]Bytinho • by Andryus • Qantara {e('💜','<3')}[/dim]"
        ))
    return Panel(Group(*parts), title="Bytinho", border_style=color, padding=(0, 2))


def empty_pet() -> dict:
    return {
        "name": "Bytinho", "hunger": 0, "energy": 0, "mood": 0, "brain_energy": 0,
        "asleep": False, "xp": 0, "level": 1, "stage": "egg",
        "stage_emoji": "📦", "patron": False, "soul": {},
    }
