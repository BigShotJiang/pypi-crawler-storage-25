"""Garante que efeitos visuais (auras, jump, jitter, streak) NÃO distorcem
a largura/altura da caixa do pet. Largura sempre == STAGE_W.
"""
from bytinho.ui import STAGE_H, STAGE_W, _frame_sprite
from bytinho.sprites import render

STAGES = ["egg", "hatchling", "junior", "pleno", "senior", "staff", "tenx", "legend"]


def _all_rows_uniform(framed: str) -> bool:
    rows = framed.split("\n")
    return len(rows) == STAGE_H and all(len(r) == STAGE_W for r in rows)


def test_frame_uniform_all_stages_basic():
    for stage in STAGES:
        sprite = render(stage, mood=70, asleep=False, variant="a", tick=0)
        framed = _frame_sprite(sprite, sx=0, asleep=False, tick=0, stage=stage)
        assert _all_rows_uniform(framed), f"stage={stage} basic"


def test_frame_uniform_with_aura_and_streak():
    for stage in STAGES:
        for tick in range(8):
            sprite = render(stage, mood=80, asleep=False, variant="a", tick=tick)
            framed = _frame_sprite(
                sprite, sx=0, asleep=False, tick=tick,
                stage=stage, streak_days=14, jump=0,
            )
            assert _all_rows_uniform(framed), f"stage={stage} aura tick={tick}"


def test_frame_uniform_with_jump_and_jitter():
    for stage in STAGES:
        for sx in (-2, -1, 0, 1, 2):
            for jump in (0, 1):
                sprite = render(stage, mood=95, asleep=False, variant="a", tick=0)
                framed = _frame_sprite(
                    sprite, sx=sx, asleep=False, tick=0,
                    stage=stage, streak_days=0, jump=jump,
                )
                assert _all_rows_uniform(framed), f"stage={stage} sx={sx} jump={jump}"


def test_frame_uniform_when_asleep():
    for stage in STAGES:
        sprite = render(stage, mood=50, asleep=True, variant="a", tick=0)
        framed = _frame_sprite(sprite, sx=0, asleep=True, tick=0, stage=stage)
        assert _all_rows_uniform(framed), f"stage={stage} asleep"


def test_aura_does_not_overwrite_sprite_chars():
    """Aura só pode escrever em espaços; sprite original deve continuar lá."""
    for stage in ("tenx", "legend", "staff"):
        sprite = render(stage, mood=80, asleep=False, variant="a", tick=0)
        plain = _frame_sprite(sprite, sx=0, asleep=False, tick=0, stage=stage)
        with_aura = _frame_sprite(sprite, sx=0, asleep=False, tick=0, stage=stage)
        # cada char não-espaço do sprite deve aparecer em with_aura também
        for r1, r2 in zip(plain.split("\n"), with_aura.split("\n")):
            for c1, c2 in zip(r1, r2):
                if c1 != " ":
                    assert c2 == c1, f"aura sobrescreveu char do sprite em {stage}"
