"""Smoke tests do CLI: garantem que cada comando não explode.

Não testam comportamento profundo , só:
- exit_code == 0 (ou exit_code esperado)
- ausência de tracebacks
- presença de strings-âncora na saída

Pré-mockados via conftest: client.* (HTTP) + DATA_DIR (filesystem).
"""
from unittest.mock import MagicMock

import pytest


# ---------- meta -----------------------------------------------------------

def test_version(cli):
    runner, app = cli
    r = runner.invoke(app, ["version"])
    assert r.exit_code == 0
    assert "Bytinho" in r.output


def test_credits(cli):
    runner, app = cli
    r = runner.invoke(app, ["credits"])
    assert r.exit_code == 0


def test_donate(cli):
    runner, app = cli
    r = runner.invoke(app, ["donate"])
    assert r.exit_code == 0


def test_doctor(cli):
    runner, app = cli
    r = runner.invoke(app, ["doctor"])
    # doctor pode retornar !=0 se algum check falhar; mínimo: não estoura.
    assert r.exit_code in (0, 1)
    assert "Traceback" not in r.output


# ---------- pet básico -----------------------------------------------------

def test_status_opens_tui_on_stats(cli, monkeypatch):
    """`bytinho status` abre a TUI no modo talk (MVP v0.10).

    Mockamos SpeakTUI pra evitar abrir prompt_toolkit em headless e
    só validamos que `run()` foi chamado.
    """
    runner, app = cli
    fake = MagicMock()
    monkeypatch.setattr("bytinho.speak_tui.SpeakTUI", lambda: fake)
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 0
    fake.run.assert_called_once_with()


def test_streak(cli):
    runner, app = cli
    r = runner.invoke(app, ["streak"])
    assert r.exit_code == 0


# ---------- pet ações ------------------------------------------------------
# MVP: feed/play/sleep/wake foram removidos — pet espelha atividade do dev.


# ---------- identity -------------------------------------------------------

def test_nick_valido(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["nick", "andryus"])
    assert r.exit_code == 0
    mock_client.set_nick.assert_called_once_with("andryus")


def test_nick_falha(cli, mock_client):
    runner, app = cli
    mock_client.set_nick.return_value = (False, "Nick inválido")
    r = runner.invoke(app, ["nick", "ab"])
    # CLI imprime erro mas não dá raise , exit_code 0
    assert "Nick inválido" in r.output or "✗" in r.output


def test_rename(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["rename", "Floquinho"])
    assert r.exit_code == 0
    mock_client.rename_pet.assert_called_once_with("Floquinho")


def test_export_imprime_uuid(cli, isolated_data_dir):
    runner, app = cli
    r = runner.invoke(app, ["export"])
    assert r.exit_code == 0
    # Deve imprimir o UUID fixo do fixture
    assert "11111111" in r.output


def test_import_uuid_invalido(cli):
    runner, app = cli
    r = runner.invoke(app, ["import", "not-a-uuid"])
    assert "inválid" in r.output.lower() or "✗" in r.output


# ---------- chat / talk ----------------------------------------------------

def test_talk(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["talk", "oi"])
    assert r.exit_code == 0
    mock_client.talk.assert_called_once()


# ---------- social ---------------------------------------------------------

def test_ranking(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["ranking"])
    assert r.exit_code == 0
    mock_client.ranking.assert_called_once()


def test_achievements_vazio(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["achievements"])
    assert r.exit_code == 0


def test_report(cli, mock_client):
    runner, app = cli
    r = runner.invoke(app, ["report", "spammer", "spam de cripto"])
    assert r.exit_code == 0
    mock_client.report_user.assert_called_once()


# ---------- offline / resiliência -----------------------------------------

def test_status_offline_nao_estoura(cli, mock_client, monkeypatch):
    """Mesmo offline, abrir a TUI via `status` não deve estourar antes de iniciar."""
    runner, app = cli
    mock_client.sync.return_value = None
    mock_client.health.return_value = {
        "status": "offline", "brain": "offline", "chat_online": 0,
    }
    fake = MagicMock()
    monkeypatch.setattr("bytinho.speak_tui.SpeakTUI", lambda: fake)
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 0
    assert "Traceback" not in r.output


# ---------- help -----------------------------------------------------------

@pytest.mark.parametrize("cmd", [
    "status",
    "nick", "rename", "talk", "ranking", "streak", "challenge",
    "achievements", "version", "doctor", "report",
    "export", "import",
])
def test_help_para_cada_comando(cli, cmd):
    """Cada comando deve responder a --help sem estourar."""
    runner, app = cli
    r = runner.invoke(app, [cmd, "--help"])
    assert r.exit_code == 0
    assert "Usage" in r.output or "Uso" in r.output or cmd in r.output.lower()


# ---------- challenge ------------------------------------------------------

def test_challenge_offline(cli, mock_client):
    runner, app = cli
    mock_client.sync.return_value = None
    r = runner.invoke(app, ["challenge"])
    assert r.exit_code == 0
    assert "Traceback" not in r.output


def test_challenge_em_progresso(cli, mock_client):
    runner, app = cli
    mock_client.sync.return_value = {
        "pet": {},
        "user": {
            "nick": "andryus",
            "challenge": {
                "code": "COMMITS_5", "label": "5 commits essa semana",
                "target": 5, "progress": 2, "done": False,
                "days_left": 4, "xp_reward": 50,
            },
        },
    }
    r = runner.invoke(app, ["challenge"])
    assert r.exit_code == 0
    assert "5 commits" in r.output
    assert "2/5" in r.output
