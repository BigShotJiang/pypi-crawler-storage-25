"""Testes do m\u00f3dulo notifications , detec\u00e7\u00e3o de progresso entre sessions."""
from __future__ import annotations

from bytinho.notifications import Toast, diff


def test_first_run_returns_no_toasts():
    """Sem cache anterior, n\u00e3o disparamos nada (evita avalanche de unlocks)."""
    curr = {
        "pet": {"level": 1, "stage": "egg"},
        "achievements": [{"code": "first_commit", "title": "x", "icon": "\ud83c\udf31"}],
    }
    assert diff(None, curr) == []


def test_no_changes_returns_empty():
    snap = {
        "pet": {"level": 2, "stage": "hatchling"},
        "achievements": [{"code": "first_commit", "title": "x", "icon": "\ud83c\udf31"}],
        "streak": {"days": 1},
    }
    assert diff(snap, snap) == []


def test_new_achievement_unlock():
    prev = {"pet": {}, "achievements": []}
    curr = {"pet": {}, "achievements": [
        {"code": "first_commit", "title": "Primeiro Commit",
         "icon": "\ud83c\udf31", "desc": "plantou a semente"},
    ]}
    out = diff(prev, curr)
    assert len(out) == 1
    assert out[0].kind == "unlock"
    assert "Primeiro Commit" in out[0].title
    assert out[0].icon == "\ud83c\udf31"


def test_stage_up_and_level_up_can_coexist():
    prev = {"pet": {"stage": "junior", "level": 3}, "achievements": []}
    curr = {"pet": {"stage": "pleno", "level": 4}, "achievements": []}
    out = diff(prev, curr)
    kinds = [t.kind for t in out]
    assert "stage_up" in kinds
    assert "level_up" in kinds
    stage_toast = next(t for t in out if t.kind == "stage_up")
    assert "Dev" in stage_toast.title
    assert "Spark" in stage_toast.detail


def test_level_up_alone_when_no_stage_change():
    prev = {"pet": {"stage": "junior", "level": 3}, "achievements": []}
    curr = {"pet": {"stage": "junior", "level": 4}, "achievements": []}
    out = diff(prev, curr)
    kinds = [t.kind for t in out]
    assert kinds == ["level_up"]


def test_streak_milestone_only_at_marked_day():
    """Day 5 n\u00e3o \u00e9 milestone, mas day 7 \u00e9."""
    prev = {"pet": {}, "streak": {"days": 4}, "achievements": []}
    curr = {"pet": {}, "streak": {"days": 5}, "achievements": []}
    assert diff(prev, curr) == []

    prev = {"pet": {}, "streak": {"days": 6}, "achievements": []}
    curr = {"pet": {}, "streak": {"days": 7}, "achievements": []}
    out = diff(prev, curr)
    assert any(t.kind == "streak_milestone" for t in out)


def test_streak_decrease_no_toast():
    """Quebrou a streak \u2192 nada de celebrar."""
    prev = {"pet": {}, "streak": {"days": 8}, "achievements": []}
    curr = {"pet": {}, "streak": {"days": 1}, "achievements": []}
    assert diff(prev, curr) == []


def test_toast_render_has_markup():
    t = Toast(kind="unlock", icon="\ud83c\udfc6", title="x", detail="y")
    out = t.render()
    assert "[bold bright_magenta]" in out
    assert "\ud83c\udfc6" in out
    assert "[dim]y[/dim]" in out


def test_toast_render_without_detail():
    t = Toast(kind="level_up", icon="\u2b06\ufe0f", title="Lv.5")
    out = t.render()
    assert "[dim]" not in out
    assert "Lv.5" in out


def test_priority_order():
    """unlock vem antes de stage_up, que vem antes de level_up, que vem antes de streak."""
    prev = {
        "pet": {"stage": "junior", "level": 3},
        "streak": {"days": 6},
        "achievements": [],
    }
    curr = {
        "pet": {"stage": "pleno", "level": 4},
        "streak": {"days": 7},
        "achievements": [{"code": "x", "title": "X", "icon": "X"}],
    }
    kinds = [t.kind for t in diff(prev, curr)]
    assert kinds == ["unlock", "stage_up", "level_up", "streak_milestone"]
