"""P0-4 privacy / opt-out tests."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def fake_repo(tmp_path: Path, monkeypatch) -> Path:
    """Cria um repo git de mentira em tmp e cwd para ele."""
    subprocess.check_call(
        ["git", "init", "-q", str(tmp_path)],
        stderr=subprocess.DEVNULL,
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("BYTINHO_SKIP", raising=False)
    return tmp_path


def test_not_skipped_by_default(fake_repo, isolated_data_dir):
    from bytinho import privacy
    skipped, _ = privacy.is_skipped()
    assert skipped is False


def test_env_var_skips(fake_repo, isolated_data_dir, monkeypatch):
    from bytinho import privacy
    monkeypatch.setenv("BYTINHO_SKIP", "1")
    skipped, reason = privacy.is_skipped()
    assert skipped is True
    assert "BYTINHO_SKIP" in reason


def test_bytinhoignore_file_skips(fake_repo, isolated_data_dir):
    from bytinho import privacy
    (fake_repo / ".bytinhoignore").write_text("# pula\n")
    skipped, reason = privacy.is_skipped()
    assert skipped is True
    assert ".bytinhoignore" in reason


def test_global_skip_list(fake_repo, isolated_data_dir):
    from bytinho import privacy
    ok, _ = privacy.add_global(str(fake_repo))
    assert ok
    skipped, reason = privacy.is_skipped()
    assert skipped is True
    assert "global" in reason

    ok2, _ = privacy.rm_global(str(fake_repo))
    assert ok2
    skipped2, _ = privacy.is_skipped()
    assert skipped2 is False


def test_add_here_creates_file(fake_repo, isolated_data_dir):
    from bytinho import privacy
    ok, path = privacy.add_here()
    assert ok
    assert (fake_repo / ".bytinhoignore").exists()
    assert str(fake_repo) in path

    ok2, _ = privacy.rm_here()
    assert ok2
    assert not (fake_repo / ".bytinhoignore").exists()


def test_outside_repo_returns_false(tmp_path: Path, monkeypatch, isolated_data_dir):
    """Sem repo git e sem env, não pula (mas também não há nada a enviar)."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("BYTINHO_SKIP", raising=False)
    from bytinho import privacy
    skipped, _ = privacy.is_skipped()
    assert skipped is False


def test_hook_body_has_opt_out_guards():
    """O shell hook embed checa BYTINHO_SKIP e .bytinhoignore antes do envio."""
    from bytinho.commands.dev import _HOOK_BODY
    assert "BYTINHO_SKIP" in _HOOK_BODY
    assert ".bytinhoignore" in _HOOK_BODY
    # guards aparecem ANTES da chamada efetiva
    body = _HOOK_BODY
    skip_pos = body.find("BYTINHO_SKIP")
    ignore_pos = body.find(".bytinhoignore")
    call_pos = body.find("code 1 --from-git")
    assert 0 < skip_pos < call_pos
    assert 0 < ignore_pos < call_pos
