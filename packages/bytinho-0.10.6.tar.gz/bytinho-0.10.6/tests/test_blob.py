"""Testes do ASCII Blob System.

Roda com:  python -m tests.test_blob
ou:        pytest cli/tests/test_blob.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# permite rodar standalone
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bytinho import blob as B  # noqa: E402


def test_grid_constants():
    assert B.WIDTH == 13
    assert B.HEIGHT == 8


def test_components_have_correct_widths():
    for name, v in B.EYES.items():
        assert len(v) == 3, f"EYES[{name}] = {v!r}"
    for name, v in B.MOUTHS.items():
        assert len(v) == 3, f"MOUTHS[{name}] = {v!r}"
    for name, v in B.FEET.items():
        assert len(v) == 3, f"FEET[{name}] = {v!r}"
    for name, v in B.HATS.items():
        assert len(v) == B.WIDTH, f"HATS[{name}] = {v!r} ({len(v)})"
    for name, v in B.EFFECTS.items():
        assert len(v) == B.WIDTH, f"EFFECTS[{name}] = {v!r} ({len(v)})"


def test_skin_format_produces_full_width():
    for name, skin in B.SKINS.items():
        assert len(skin.body_top) == B.WIDTH, name
        assert len(skin.body_bottom) == B.WIDTH, name
        assert len(skin.eye_line_fmt.format("X X")) == B.WIDTH, name
        assert len(skin.mouth_line_fmt.format("X X")) == B.WIDTH, name


def test_render_default_is_8x13():
    blob = B.render(B.BlobSpec())
    assert len(blob) == 8
    for line in blob:
        assert len(line) == 13


def test_all_presets_render():
    cat = B.validate_catalog()
    assert len(cat) == len(B.PRESETS)
    for name, blob in cat.items():
        assert len(blob) == 8, name
        for line in blob:
            assert len(line) == 13, f"{name}: {line!r}"


def test_validator_rejects_short_blob():
    try:
        B.validate(["short"])
    except B.BlobValidationError:
        pass
    else:
        raise AssertionError("validator não rejeitou blob curto")


def test_validator_rejects_wrong_width():
    bad = [" " * 13] * 7 + ["short"]
    try:
        B.validate(bad)
    except B.BlobValidationError as e:
        assert "largura" in str(e).lower() or "expected" in str(e).lower()
    else:
        raise AssertionError("validator não rejeitou linha curta")


def test_render_rejects_unknown_component():
    try:
        B.render(B.BlobSpec(eyes="laser-beam"))
    except B.BlobValidationError:
        pass
    else:
        raise AssertionError("render não rejeitou eyes desconhecido")


def test_unicode_skin_is_13_chars():
    """cyber skin usa box-drawing , len() em codepoints deve dar 13."""
    blob = B.render(B.BlobSpec(skin="cyber"))
    for line in blob:
        assert len(line) == 13, repr(line)


def _run_all():
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"  ✗ {t.__name__}: {e}")
        except Exception as e:
            failed += 1
            print(f"  ✗ {t.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(_run_all())
