"""Testes do módulo telemetry , opt-in, dedupe one-shot, fire-and-forget."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def isolated_data_dir(tmp_path, monkeypatch):
    """Aponta DATA_DIR pra tmp e re-importa telemetry pra usar o tmp."""
    import importlib

    from bytinho import config

    monkeypatch.setattr(config, "DATA_DIR", tmp_path)
    # Recarrega telemetry pra pegar DATA_DIR novo (módulo capturou no import).
    from bytinho import telemetry
    importlib.reload(telemetry)
    # Patch FLAG/SENT pro tmp_path real (reload re-resolve, mas garantimos):
    monkeypatch.setattr(telemetry, "_FLAG_FILE", tmp_path / "telemetry.json")
    monkeypatch.setattr(telemetry, "_SENT_FILE", tmp_path / "telemetry_sent.json")
    return telemetry


def test_enabled_by_default(isolated_data_dir):
    """Always-on , telemetria liga sem perguntar."""
    t = isolated_data_dir
    assert t.is_enabled() is True
    assert t.has_decided() is True  # compat: sem prompt


def test_set_enabled_persists(isolated_data_dir):
    t = isolated_data_dir
    t.set_enabled(False)
    assert t.is_enabled() is False  # opt-out explicito
    t.set_enabled(True)
    assert t.is_enabled() is True


def test_track_no_op_when_explicitly_off(isolated_data_dir):
    """Se user passou --forget (set_enabled(False)), track é no-op."""
    t = isolated_data_dir
    t.set_enabled(False)
    with patch.object(t, "_send_async") as mock_send:
        t.track("daily_active")
    mock_send.assert_not_called()


def test_track_sends_when_enabled(isolated_data_dir):
    t = isolated_data_dir
    # default é ON, não precisa set
    with patch.object(t, "_send_async") as mock_send:
        t.track("daily_active")
    mock_send.assert_called_once()
    payload = mock_send.call_args[0][0]
    assert payload["event"] == "daily_active"
    assert "cli_version" in payload
    assert payload["os"] in ("linux", "wsl", "darwin", "other")


def test_one_shot_dedup(isolated_data_dir):
    t = isolated_data_dir
    with patch.object(t, "_send_async") as mock_send:
        t.track("install")
        t.track("install")
        t.track("install")
    assert mock_send.call_count == 1


def test_non_one_shot_repeats(isolated_data_dir):
    t = isolated_data_dir
    with patch.object(t, "_send_async") as mock_send:
        t.track("daily_active")
        t.track("daily_active")
        t.track("stage_up")
    assert mock_send.call_count == 3


def test_forget_remote_disables_local(isolated_data_dir):
    t = isolated_data_dir

    fake_resp = MagicMock(status_code=204)
    fake_client = MagicMock()
    fake_client.__enter__.return_value.delete.return_value = fake_resp

    with patch("bytinho.telemetry.httpx.Client", return_value=fake_client):
        ok = t.forget_remote()
    assert ok is True


def test_forget_remote_handles_error(isolated_data_dir):
    t = isolated_data_dir
    import httpx
    with patch("bytinho.telemetry.httpx.Client",
               side_effect=httpx.ConnectError("nope")):
        ok = t.forget_remote()
    assert ok is False


def test_send_async_swallows_exceptions(isolated_data_dir):
    """Mesmo se httpx explodir, track() não levanta."""
    t = isolated_data_dir
    import httpx
    with patch("bytinho.telemetry.httpx.Client",
               side_effect=httpx.ConnectError("boom")):
        t.track("daily_active")
        import time
        time.sleep(0.1)
