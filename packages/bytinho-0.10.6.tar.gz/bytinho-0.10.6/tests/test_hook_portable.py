"""P0-2: hook scripts são portáveis (Linux/macOS/Git-Bash on Windows)."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest


def test_hooks_use_posix_sh_shebang():
    """Não deve usar bash (não está garantido em Git Bash for Windows)."""
    from bytinho.commands.dev import (
        _HOOK_BODY,
        _HOOK_INNER_POST,
        _HOOK_INNER_PREPUSH,
        _PREPUSH_BODY,
    )
    assert _HOOK_BODY.startswith("#!/usr/bin/env sh")
    assert _PREPUSH_BODY.startswith("#!/usr/bin/env sh")
    assert "bash" not in _HOOK_BODY.split("\n")[0]
    assert "bash" not in _PREPUSH_BODY.split("\n")[0]
    # inner blocks: usados dentro de hooks já existentes — sem shebang próprio,
    # mas também não podem assumir bashisms.
    for body in (_HOOK_INNER_POST, _HOOK_INNER_PREPUSH):
        assert "[[ " not in body
        assert "function " not in body


def test_hooks_have_timeout_fallback():
    """Git Bash não tem `timeout`. Hook deve cair pra exec direto."""
    from bytinho.commands.dev import (
        _HOOK_BODY,
        _HOOK_INNER_POST,
        _HOOK_INNER_PREPUSH,
        _PREPUSH_BODY,
    )
    for body in (_HOOK_BODY, _PREPUSH_BODY, _HOOK_INNER_POST, _HOOK_INNER_PREPUSH):
        assert "command -v timeout" in body


def test_hooks_resolve_bytinho_portably():
    """Resolver tenta PATH, ~/.local/bin, e %APPDATA% no Windows."""
    from bytinho.commands.dev import (
        _HOOK_BODY,
        _HOOK_INNER_POST,
        _HOOK_INNER_PREPUSH,
        _PREPUSH_BODY,
    )
    for body in (_HOOK_BODY, _PREPUSH_BODY, _HOOK_INNER_POST, _HOOK_INNER_PREPUSH):
        assert "command -v bytinho" in body
        assert "$HOME/.local/bin/bytinho" in body
        assert "bytinho.exe" in body
        assert "APPDATA" in body


@pytest.mark.skipif(shutil.which("sh") is None, reason="sh required")
def test_hook_passes_sh_n_syntax_check(tmp_path: Path):
    """Os scripts devem passar `sh -n` (parse-only)."""
    from bytinho.commands.dev import _HOOK_BODY, _PREPUSH_BODY
    for name, body in (("post-commit", _HOOK_BODY), ("pre-push", _PREPUSH_BODY)):
        f = tmp_path / name
        f.write_text(body)
        r = subprocess.run(
            ["sh", "-n", str(f)],
            capture_output=True, text=True,
        )
        assert r.returncode == 0, f"{name} sh -n failed: {r.stderr}"


@pytest.mark.skipif(shutil.which("sh") is None, reason="sh required")
def test_inner_blocks_pass_sh_n_syntax_check(tmp_path: Path):
    from bytinho.commands.dev import _HOOK_INNER_POST, _HOOK_INNER_PREPUSH
    for name, inner in (("post", _HOOK_INNER_POST), ("pre", _HOOK_INNER_PREPUSH)):
        f = tmp_path / f"hook-{name}"
        f.write_text("#!/usr/bin/env sh\n" + inner)
        r = subprocess.run(["sh", "-n", str(f)], capture_output=True, text=True)
        assert r.returncode == 0, f"{name} sh -n failed: {r.stderr}"


@pytest.mark.skipif(shutil.which("sh") is None, reason="sh required")
def test_hook_skip_env_short_circuits_at_runtime(tmp_path: Path):
    """Com BYTINHO_SKIP=1 o hook sai imediatamente (exit 0) sem tentar resolver bytinho."""
    from bytinho.commands.dev import _HOOK_BODY
    f = tmp_path / "post-commit"
    f.write_text(_HOOK_BODY)
    f.chmod(0o755)
    # Mantém PATH do sistema (precisamos de `git`, `command`, etc.) mas em
    # HOME isolado (não contém bytinho).
    env = {"BYTINHO_SKIP": "1", "PATH": "/usr/bin:/bin", "HOME": str(tmp_path)}
    r = subprocess.run(["sh", str(f)], env=env, capture_output=True, text=True)
    assert r.returncode == 0


@pytest.mark.skipif(shutil.which("sh") is None, reason="sh required")
def test_hook_no_bytinho_no_error(tmp_path: Path):
    """Sem bytinho instalado, hook sai limpo (exit 0)."""
    from bytinho.commands.dev import _HOOK_BODY
    repo = tmp_path / "repo"
    subprocess.check_call(["git", "init", "-q", str(repo)])
    f = repo / ".git" / "hooks" / "post-commit"
    f.write_text(_HOOK_BODY)
    f.chmod(0o755)
    # PATH com o básico mas sem bytinho; HOME isolado (sem ~/.local/bin/bytinho).
    env = {"PATH": "/usr/bin:/bin", "HOME": str(tmp_path)}
    r = subprocess.run(
        ["sh", str(f)], env=env, capture_output=True, text=True, cwd=str(repo),
    )
    assert r.returncode == 0
