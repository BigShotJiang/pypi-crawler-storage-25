"""P1-1: TTY / interactivity detection."""
from __future__ import annotations

import os

import pytest


@pytest.fixture
def clean_env(monkeypatch):
    """Remove all CI markers + override env to start from a clean state."""
    for k in (
        "BYTINHO_NONINTERACTIVE", "CI", "GITHUB_ACTIONS", "GITLAB_CI",
        "BUILDKITE", "CIRCLECI", "JENKINS_URL", "TF_BUILD",
        "TEAMCITY_VERSION", "BUILDER_OUTPUT", "DRONE",
    ):
        monkeypatch.delenv(k, raising=False)
    yield monkeypatch


def test_is_interactive_true_when_tty(clean_env, monkeypatch):
    from bytinho import tty as bt_tty

    class FakeTTY:
        def isatty(self) -> bool:
            return True

    monkeypatch.setattr(bt_tty.sys, "stdin", FakeTTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", FakeTTY())
    assert bt_tty.is_interactive() is True


def test_is_interactive_false_when_stdin_not_tty(clean_env, monkeypatch):
    from bytinho import tty as bt_tty

    class TTY:
        def isatty(self) -> bool:
            return True

    class NotTTY:
        def isatty(self) -> bool:
            return False

    monkeypatch.setattr(bt_tty.sys, "stdin", NotTTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", TTY())
    assert bt_tty.is_interactive() is False


def test_is_interactive_false_when_stdout_not_tty(clean_env, monkeypatch):
    from bytinho import tty as bt_tty

    class TTY:
        def isatty(self) -> bool:
            return True

    class NotTTY:
        def isatty(self) -> bool:
            return False

    monkeypatch.setattr(bt_tty.sys, "stdin", TTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", NotTTY())
    assert bt_tty.is_interactive() is False


@pytest.mark.parametrize("var", [
    "CI", "GITHUB_ACTIONS", "GITLAB_CI", "BUILDKITE",
    "CIRCLECI", "JENKINS_URL", "TF_BUILD",
])
def test_is_interactive_false_in_ci(clean_env, monkeypatch, var):
    from bytinho import tty as bt_tty

    class TTY:
        def isatty(self) -> bool:
            return True

    monkeypatch.setattr(bt_tty.sys, "stdin", TTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", TTY())
    monkeypatch.setenv(var, "true")
    assert bt_tty.is_interactive() is False
    assert bt_tty.is_ci() is True


def test_ci_var_false_value_does_not_count(clean_env, monkeypatch):
    """CI=false (alguns Buildkite agents settam assim) — tratamos como não-CI."""
    from bytinho import tty as bt_tty

    class TTY:
        def isatty(self) -> bool:
            return True

    monkeypatch.setattr(bt_tty.sys, "stdin", TTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", TTY())
    monkeypatch.setenv("CI", "false")
    assert bt_tty.is_interactive() is True


def test_explicit_override_wins(clean_env, monkeypatch):
    """BYTINHO_NONINTERACTIVE=1 força non-interactive mesmo em tty."""
    from bytinho import tty as bt_tty

    class TTY:
        def isatty(self) -> bool:
            return True

    monkeypatch.setattr(bt_tty.sys, "stdin", TTY())
    monkeypatch.setattr(bt_tty.sys, "stdout", TTY())
    monkeypatch.setenv("BYTINHO_NONINTERACTIVE", "1")
    assert bt_tty.is_interactive() is False


def test_run_tour_short_circuits_in_non_tty(isolated_data_dir, clean_env, monkeypatch):
    """run_tour() em non-tty marca como visto sem prompt."""
    from bytinho import prefs, tour
    # garante que ainda não viu
    data = prefs._load()
    data.pop("seen_tour", None)
    prefs._save(data)
    assert prefs.has_seen_tour() is False

    monkeypatch.setenv("BYTINHO_NONINTERACTIVE", "1")
    tour.run_tour()
    assert prefs.has_seen_tour() is True


def test_run_tour_no_op_when_already_seen(isolated_data_dir, clean_env, monkeypatch):
    from bytinho import prefs, tour
    prefs.mark_tour_seen()
    monkeypatch.setenv("BYTINHO_NONINTERACTIVE", "1")
    tour.run_tour()  # deve sair sem rodar nada
    assert prefs.has_seen_tour() is True
