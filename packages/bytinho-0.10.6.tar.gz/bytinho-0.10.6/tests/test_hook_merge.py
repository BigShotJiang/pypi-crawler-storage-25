"""P0-1: hook merge não-destrutivo (markers + chain into existing dirs)."""
from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def fake_repo(tmp_path: Path, monkeypatch) -> Path:
    subprocess.check_call(
        ["git", "init", "-q", str(tmp_path)],
        stderr=subprocess.DEVNULL,
    )
    monkeypatch.chdir(tmp_path)
    return tmp_path


def _hook(repo: Path, name: str) -> Path:
    return repo / ".git" / "hooks" / name


def test_install_creates_post_commit_with_marked_block(fake_repo):
    from bytinho.commands.dev import (
        _HOOK_MARK_END,
        _HOOK_MARK_START,
        _install_hook_here,
    )
    ok, path = _install_hook_here()
    assert ok
    body = Path(path).read_text()
    assert _HOOK_MARK_START in body
    assert _HOOK_MARK_END in body
    assert "code 1 --from-git" in body
    # exec bit
    assert os.stat(path).st_mode & stat.S_IXUSR


def test_install_is_idempotent(fake_repo):
    from bytinho.commands.dev import _HOOK_MARK_START, _install_hook_here
    _install_hook_here()
    _install_hook_here()
    _install_hook_here()
    body = _hook(fake_repo, "post-commit").read_text()
    # exatamente 1 marker, mesmo após 3 chamadas
    assert body.count(_HOOK_MARK_START) == 1


def test_install_preserves_existing_husky_hook(fake_repo):
    """Hook pré-existente (e.g. husky) NÃO é apagado, bloco bytinho é anexado."""
    from bytinho.commands.dev import _HOOK_MARK_START, _install_hook_here
    h = _hook(fake_repo, "post-commit")
    h.parent.mkdir(parents=True, exist_ok=True)
    husky = "#!/usr/bin/env sh\n. \"$(dirname \"$0\")/_/husky.sh\"\necho 'husky stuff'\n"
    h.write_text(husky)

    ok, _ = _install_hook_here()
    assert ok
    body = h.read_text()
    # husky preservado
    assert "husky.sh" in body
    assert "echo 'husky stuff'" in body
    # bytinho adicionado
    assert _HOOK_MARK_START in body
    assert "code 1 --from-git" in body


def test_uninstall_removes_only_bytinho_block(fake_repo):
    """--uninstall preserva o resto do hook do user."""
    from bytinho.commands.dev import (
        _HOOK_MARK_START,
        _install_hook_here,
        _remove_managed_block,
    )
    h = _hook(fake_repo, "post-commit")
    h.parent.mkdir(parents=True, exist_ok=True)
    h.write_text("#!/usr/bin/env sh\necho 'mine'\n")

    _install_hook_here()
    assert _remove_managed_block(h) is True

    body = h.read_text()
    assert _HOOK_MARK_START not in body
    assert "code 1 --from-git" not in body
    # original preservado
    assert "echo 'mine'" in body


def test_uninstall_deletes_hook_if_only_bytinho(fake_repo):
    """Se nós criamos o hook do zero, --uninstall apaga o arquivo."""
    from bytinho.commands.dev import _install_hook_here, _remove_managed_block
    _install_hook_here()
    h = _hook(fake_repo, "post-commit")
    assert h.exists()
    _remove_managed_block(h)
    assert not h.exists()


def test_block_re_renders_when_inner_changes(fake_repo):
    """Versão futura troca conteúdo entre markers, sem duplicar."""
    from bytinho.commands.dev import (
        _HOOK_MARK_END,
        _HOOK_MARK_START,
        _upsert_managed_block,
    )
    h = fake_repo / "fake-hook"
    block_v1 = f"\n{_HOOK_MARK_START}\necho v1\n{_HOOK_MARK_END}\n"
    block_v2 = f"\n{_HOOK_MARK_START}\necho v2\n{_HOOK_MARK_END}\n"
    _upsert_managed_block(h, block_v1)
    _upsert_managed_block(h, block_v2)
    body = h.read_text()
    assert "echo v2" in body
    assert "echo v1" not in body
    assert body.count(_HOOK_MARK_START) == 1


def test_install_global_chains_into_existing_hookspath(tmp_path: Path, monkeypatch):
    """Se já existe core.hooksPath (husky), encadeamos lá em vez de sobrescrever."""
    from bytinho.commands.dev import _HOOK_MARK_START, _install_global_hooks

    # Setup: HOME isolado + git config global isolado via GIT_CONFIG_GLOBAL
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    gitconfig = tmp_path / "gitconfig"
    gitconfig.write_text("")
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(gitconfig))

    # Aponta core.hooksPath pra dir falso de "husky"
    husky_dir = tmp_path / "husky-hooks"
    husky_dir.mkdir()
    existing_post = husky_dir / "post-commit"
    existing_post.write_text("#!/usr/bin/env sh\necho 'husky existing'\n")
    existing_post.chmod(0o755)
    subprocess.check_call(
        ["git", "config", "--global", "core.hooksPath", str(husky_dir)],
    )

    ok, msg = _install_global_hooks()
    assert ok, msg
    assert "encadeado" in msg

    body = existing_post.read_text()
    assert "echo 'husky existing'" in body
    assert _HOOK_MARK_START in body
    assert "code 1 --from-git" in body

    # core.hooksPath NÃO deve ter sido alterado
    out = subprocess.check_output(
        ["git", "config", "--global", "core.hooksPath"], text=True,
    ).strip()
    assert out == str(husky_dir)


def test_install_global_creates_dedicated_dir_when_unset(tmp_path: Path, monkeypatch):
    """Sem core.hooksPath, criamos ~/.bytinho-hooks e apontamos pra lá."""
    from bytinho.commands.dev import _install_global_hooks

    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    gitconfig = tmp_path / "gitconfig"
    gitconfig.write_text("")
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(gitconfig))

    ok, msg = _install_global_hooks()
    assert ok, msg
    target = home / ".bytinho-hooks"
    assert target.exists()
    assert (target / "post-commit").exists()
    assert (target / "pre-push").exists()
    assert "encadeado" not in msg

    out = subprocess.check_output(
        ["git", "config", "--global", "core.hooksPath"], text=True,
    ).strip()
    assert out == str(target)
