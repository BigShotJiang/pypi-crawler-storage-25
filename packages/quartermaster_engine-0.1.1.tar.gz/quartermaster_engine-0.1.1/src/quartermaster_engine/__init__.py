"""quartermaster-engine: Execution engine for AI agent graphs."""

from quartermaster_engine.context.execution_context import ExecutionContext
from quartermaster_engine.context.node_execution import NodeExecution, NodeStatus
from quartermaster_engine.events import (
    FlowError,
    FlowEvent,
    FlowFinished,
    NodeFinished,
    NodeStarted,
    TokenGenerated,
    UserInputRequired,
)
from quartermaster_engine.memory.flow_memory import FlowMemory
from quartermaster_engine.memory.persistent_memory import InMemoryPersistence, PersistentMemory
from quartermaster_engine.messaging.context_manager import ContextManager
from quartermaster_engine.messaging.message_router import MessageRouter
from quartermaster_engine.runner.flow_runner import FlowRunner
from quartermaster_engine.stores.base import ExecutionStore
from quartermaster_engine.example_runner import run_graph
from quartermaster_engine.stores.memory_store import InMemoryStore
from quartermaster_engine.types import (
    ErrorStrategy,
    GraphEdge,
    GraphNode,
    Message,
    MessageRole,
    MessageType,
    NodeType,
    ThoughtType,
    TraverseIn,
    TraverseOut,
)

__all__ = [
    # Context
    "ExecutionContext",
    "NodeExecution",
    "NodeStatus",
    # Types & Enums
    "NodeType",
    "TraverseIn",
    "TraverseOut",
    "ThoughtType",
    "MessageType",
    "ErrorStrategy",
    "GraphNode",
    "GraphEdge",
    "Message",
    "MessageRole",
    # Events
    "FlowEvent",
    "NodeStarted",
    "TokenGenerated",
    "NodeFinished",
    "FlowFinished",
    "UserInputRequired",
    "FlowError",
    # Stores
    "ExecutionStore",
    "InMemoryStore",
    # Runner
    "FlowRunner",
    # Memory
    "FlowMemory",
    "PersistentMemory",
    "InMemoryPersistence",
    # Messaging
    "MessageRouter",
    "ContextManager",
    # Example runner
    "run_graph",
]

__version__ = "0.1.0"
