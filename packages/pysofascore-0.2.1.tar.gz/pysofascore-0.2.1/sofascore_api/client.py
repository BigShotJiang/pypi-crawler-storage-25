"""Core HTTP client for SofaScore API.

Uses curl_cffi with Chrome TLS impersonation (the same engine that powers
scrapling's Fetcher) to bypass SofaScore anti-bot protection without needing
a full browser.
"""

from __future__ import annotations

import time
from datetime import date, timedelta
from typing import Any, Optional
from urllib.parse import quote

from curl_cffi import requests as curl_requests


class SofaScoreClient:
    """Synchronous client for SofaScore API.

    Uses curl_cffi with Chrome TLS fingerprint impersonation — the same
    engine that powers `scrapling.Fetcher`.  No browser binary required.

    Usage::

        client = SofaScoreClient()
        cats = client.get_categories("football")
        events = client.get_events_today("football")
        live = client.get_live_events("football")
        client.close()

    Or as a context manager::

        with SofaScoreClient() as client:
            events = client.get_events_today()
    """

    BASE_URL = "https://www.sofascore.com/api/v1"

    def __init__(
        self,
        proxy: Optional[str] = None,
        timeout: int = 15,
        retries: int = 3,
        retry_delay: float = 2.0,
    ):
        """
        Args:
            proxy: Proxy URL, e.g. ``"http://user:pass@host:port"``
                   or ``"socks5://host:port"``.
            timeout: Request timeout in seconds.
            retries: Number of retry attempts on 403 / network errors.
            retry_delay: Seconds to wait between retries (doubles each attempt).
        """
        self._retries = retries
        self._retry_delay = retry_delay

        session_kwargs: dict[str, Any] = {
            "impersonate": "chrome",
            "timeout": timeout,
            "headers": {
                "Referer": "https://www.sofascore.com/",
                "Origin": "https://www.sofascore.com",
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.9",
            },
        }
        if proxy:
            session_kwargs["proxies"] = {"http": proxy, "https": proxy}

        self._session = curl_requests.Session(**session_kwargs)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "SofaScoreClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    # ------------------------------------------------------------------
    # Low-level request
    # ------------------------------------------------------------------

    def _get(self, path: str) -> dict[str, Any]:
        """GET request with retry logic.

        Retries on 403 (anti-bot) and network errors with exponential backoff.
        """
        url = f"{self.BASE_URL}{path}"
        last_error: Optional[Exception] = None
        delay = self._retry_delay

        for attempt in range(self._retries):
            try:
                resp = self._session.get(url)
                if resp.status_code == 200:
                    return resp.json()
                if resp.status_code in (403, 429) and attempt < self._retries - 1:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise SofaScoreError(resp.status_code, url, resp.text)
            except SofaScoreError:
                raise
            except Exception as e:
                last_error = e
                if attempt < self._retries - 1:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise SofaScoreError(0, url, str(e)) from e

        raise SofaScoreError(0, url, str(last_error))

    # ------------------------------------------------------------------
    # Categories & Sports
    # ------------------------------------------------------------------

    def get_categories(self, sport: str = "football") -> list[dict]:
        """Get all categories (countries/regions) for a sport.

        Args:
            sport: Sport slug — ``football``, ``basketball``, ``tennis``,
                   ``ice-hockey``, ``table-tennis``, etc.
        """
        data = self._get(f"/sport/{sport}/categories")
        return data.get("categories", [])

    def get_all_categories(self, sport: str = "football") -> list[dict]:
        """Get extended list of all categories for a sport."""
        data = self._get(f"/sport/{sport}/categories/all")
        return data.get("categories", [])

    def get_category_tournaments(self, category_id: int) -> list[dict]:
        """Get all tournaments within a category (country).

        Args:
            category_id: Category ID (e.g. 1 for England).
        """
        data = self._get(f"/category/{category_id}/unique-tournaments")
        return data.get("groups", [])

    # ------------------------------------------------------------------
    # Events / Matches by date
    # ------------------------------------------------------------------

    def get_events_by_date(
        self,
        sport: str = "football",
        day: Optional[str] = None,
    ) -> list[dict]:
        """Get all events for a sport on a specific date.

        Args:
            sport: Sport slug.
            day: Date string ``YYYY-MM-DD``. Defaults to today.
        """
        if day is None:
            day = date.today().isoformat()
        data = self._get(f"/sport/{sport}/scheduled-events/{day}")
        return data.get("events", [])

    def get_events_today(self, sport: str = "football") -> list[dict]:
        """Shortcut: events for today."""
        return self.get_events_by_date(sport, date.today().isoformat())

    def get_events_range(
        self,
        sport: str = "football",
        start: Optional[str] = None,
        end: Optional[str] = None,
        days: Optional[int] = None,
    ) -> dict[str, list[dict]]:
        """Get events for a range of dates.

        Specify either ``start``/``end`` pair **or** ``days`` (from start).
        Returns ``{date_str: [events]}``.

        Args:
            sport: Sport slug.
            start: Start date ``YYYY-MM-DD`` (inclusive). Defaults to today.
            end: End date ``YYYY-MM-DD`` (inclusive).
            days: Number of days from start (alternative to end).
        """
        start_date = date.fromisoformat(start) if start else date.today()
        if days is not None:
            end_date = start_date + timedelta(days=days - 1)
        elif end is not None:
            end_date = date.fromisoformat(end)
        else:
            end_date = start_date

        result: dict[str, list[dict]] = {}
        current = start_date
        while current <= end_date:
            day_str = current.isoformat()
            result[day_str] = self.get_events_by_date(sport, day_str)
            current += timedelta(days=1)

        return result

    def get_events_week(self, sport: str = "football") -> dict[str, list[dict]]:
        """Shortcut: events for the next 7 days (including today)."""
        return self.get_events_range(sport, days=7)

    def get_events_month(self, sport: str = "football") -> dict[str, list[dict]]:
        """Shortcut: events for the next 30 days (including today)."""
        return self.get_events_range(sport, days=30)

    # ------------------------------------------------------------------
    # Live events
    # ------------------------------------------------------------------

    def get_live_events(self, sport: str = "football") -> list[dict]:
        """Get all currently live events for a sport."""
        data = self._get(f"/sport/{sport}/events/live")
        return data.get("events", [])

    def get_live_tournaments(self, sport: str = "football") -> dict:
        """Get live events grouped by tournament."""
        return self._get(f"/sport/{sport}/live-tournaments")

    # ------------------------------------------------------------------
    # Event details
    # ------------------------------------------------------------------

    def get_event(self, event_id: int) -> dict:
        """Get full event details (teams, score, venue, referee, etc.)."""
        data = self._get(f"/event/{event_id}")
        return data.get("event", data)

    def get_event_statistics(self, event_id: int) -> list[dict]:
        """Get match statistics (possession, shots, xG, corners, etc.)."""
        data = self._get(f"/event/{event_id}/statistics")
        return data.get("statistics", [])

    def get_event_incidents(self, event_id: int) -> list[dict]:
        """Get match incidents (goals, cards, substitutions, VAR decisions)."""
        data = self._get(f"/event/{event_id}/incidents")
        return data.get("incidents", [])

    def get_event_lineups(self, event_id: int) -> dict:
        """Get match lineups (formation, starting XI, substitutes)."""
        return self._get(f"/event/{event_id}/lineups")

    def get_event_shotmap(self, event_id: int) -> list[dict]:
        """Get shot map with per-shot xG and xGOT values.

        Each shot contains: ``player``, ``xg``, ``xgot``, ``shotType``,
        ``situation``, ``bodyPart``, ``playerCoordinates``, ``minute``.
        """
        data = self._get(f"/event/{event_id}/shotmap")
        return data.get("shotmap", [])

    def get_event_graph(self, event_id: int) -> dict:
        """Get match momentum / pressure graph data."""
        return self._get(f"/event/{event_id}/graph")

    def get_event_h2h(self, event_id: int) -> dict:
        """Get head-to-head stats for the event's two teams."""
        return self._get(f"/event/{event_id}/h2h")

    def get_event_best_players(self, event_id: int) -> dict:
        """Get best players of the match."""
        return self._get(f"/event/{event_id}/best-players/summary")

    def get_event_average_positions(self, event_id: int) -> dict:
        """Get average positions of players during the match."""
        return self._get(f"/event/{event_id}/average-positions")

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str) -> list[dict]:
        """Search across teams, players, and tournaments."""
        data = self._get(f"/search/all?q={quote(query)}")
        return data.get("results", [])

    # ------------------------------------------------------------------
    # Tournaments
    # ------------------------------------------------------------------

    def get_tournament_seasons(self, tournament_id: int) -> list[dict]:
        """Get all seasons for a tournament."""
        data = self._get(f"/unique-tournament/{tournament_id}/seasons")
        return data.get("seasons", [])

    def get_tournament_standings(
        self, tournament_id: int, season_id: int, kind: str = "total"
    ) -> dict:
        """Get tournament standings.

        Args:
            tournament_id: Unique tournament ID (e.g. 17 for Premier League).
            season_id: Season ID.
            kind: ``total``, ``home``, or ``away``.
        """
        return self._get(
            f"/unique-tournament/{tournament_id}/season/{season_id}/standings/{kind}"
        )

    def get_tournament_top_players(
        self, tournament_id: int, season_id: int, kind: str = "overall"
    ) -> dict:
        """Get top players for a tournament season.

        Args:
            kind: ``overall``, ``goals``, or ``assists``.
        """
        return self._get(
            f"/unique-tournament/{tournament_id}/season/{season_id}/top-players/{kind}"
        )

    # ------------------------------------------------------------------
    # Teams
    # ------------------------------------------------------------------

    def get_team(self, team_id: int) -> dict:
        """Get team info."""
        data = self._get(f"/team/{team_id}")
        return data.get("team", data)

    def get_team_players(self, team_id: int) -> list[dict]:
        """Get squad / player list."""
        data = self._get(f"/team/{team_id}/players")
        return data.get("players", [])

    def get_team_events(self, team_id: int, direction: str = "next", page: int = 0) -> list[dict]:
        """Get team's recent or upcoming matches.

        Args:
            direction: ``next`` for upcoming/recent, ``last`` for past results.
            page: Page number (0 = most recent).
        """
        data = self._get(f"/team/{team_id}/events/{direction}/{page}")
        return data.get("events", [])
    

    # ------------------------------------------------------------------
    # Players
    # ------------------------------------------------------------------

    def get_player(self, player_id: int) -> dict:
        """Get player info."""
        data = self._get(f"/player/{player_id}")
        return data.get("player", data)

    def get_player_statistics(
        self, player_id: int, tournament_id: int, season_id: int
    ) -> dict:
        """Get detailed player statistics for a specific tournament/season."""
        return self._get(
            f"/player/{player_id}/unique-tournament/{tournament_id}"
            f"/season/{season_id}/statistics/overall"
        )

    def get_player_heatmap(self, player_id: int, event_id: int) -> dict:
        """Get player heatmap for a specific match."""
        return self._get(f"/player/{player_id}/heatmap/{event_id}")

    def get_player_transfer_history(self, player_id: int) -> list[dict]:
        """Get player transfer history."""
        data = self._get(f"/player/{player_id}/transfer-history")
        return data.get("transferHistory", [])


# ------------------------------------------------------------------
# Exceptions
# ------------------------------------------------------------------


class SofaScoreError(Exception):
    """Raised when SofaScore API returns a non-200 response."""

    def __init__(self, status: int, url: str, body: str = ""):
        self.status = status
        self.url = url
        self.body = body
        super().__init__(f"HTTP {status} for {url}: {body[:200]}")
