"""
sofascore-api — Python library for SofaScore data extraction.

Built on top of scrapling's core engine (curl_cffi with Chrome TLS
fingerprint impersonation) to bypass SofaScore anti-bot protection.
No browser binary required.
"""

__version__ = "0.2.1"
__author__ = "kirill52300"

from sofascore_api.client import SofaScoreClient, SofaScoreError

__all__ = ["SofaScoreClient", "SofaScoreError"]
