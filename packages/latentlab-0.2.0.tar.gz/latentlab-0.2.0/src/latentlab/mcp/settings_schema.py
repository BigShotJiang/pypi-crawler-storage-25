"""Typed schema for per-user / per-call pipeline settings (ADR-056).

Single canonical Pydantic model that's the source of truth for:

  * ``settings`` field on the three upload bodies in
    ``app_server.main`` (Phase A — per-call override).
  * ``/v1/auth/me/settings`` GET/PATCH bodies (Phase B —
    per-user defaults).
  * MCP tool ``inputSchema.properties.settings`` for the three
    upload tools. The MCP submodule vendors a copy at
    ``python/src/latentlab/mcp/settings_schema.py`` to stay
    standalone-installable; the parity test in
    ``tests/test_mcp_settings_schema_parity.py`` asserts the
    two copies stay byte-equivalent.

Adding a new user-overridable setting is a one-line diff to
``PipelineSettings`` (and an immediate diff to the vendored MCP
copy until we factor a shared package). Global-only deploy-config
keys live in ``GLOBAL_ONLY_KEYS`` below and are *not* exposed on
this model — they can only be set via ``PATCH /system-settings``
(admin-only in Phase B).
"""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field


# Keys that may only ever be set in ``system_settings`` (or via env
# at deploy time). Listed here so the per-user / per-call validation
# layer can reject attempts to set them through the user-tier API.
# Not exposed on PipelineSettings — there is no Pydantic field for
# them. The set is here for resolver-side filtering / introspection.
GLOBAL_ONLY_KEYS: frozenset = frozenset({
    "OCR_PARSING",
    "GIT_REPOS_PATH",
    "LIVE_SOURCES_PATH",
    "PROCESSING_SERVER_URL",
    "PUBLIC_BASE_URL",
    "EMBED_FRAME_ANCESTORS",
    "AUTH_SECRET",
    "DB_LOCAL",
    "DB_CONNECTION_NAME",
    "DB_NAME",
    "STORAGE_NAME",
    "OBJECT_STORAGE_TYPE",
    "BOOTSTRAP_ADMIN_EMAIL",
})


class PipelineSettings(BaseModel):
    """Per-user / per-call pipeline settings.

    All fields optional — omitted keys fall through to the next
    tier in the resolution chain (request > dataset > user >
    tenant > system > env, per ADR-056).

    ``extra='forbid'`` means unknown keys raise a 422 on the wire,
    so a typo fails loud rather than silently no-op'ing.

    Secret-flagged fields (provider API keys) are accepted on
    write and redacted to prefix-only on read by the Phase B
    ``GET /v1/auth/me/settings`` handler.
    """

    model_config = {"extra": "forbid"}

    # ---- Providers ------------------------------------------------
    chat_provider: Optional[
        Literal["openai", "azure-openai", "anthropic", "gemini", "cohere", "ollama"]
    ] = None
    embedding_provider: Optional[
        Literal["openai", "azure-openai", "gemini", "cohere", "ollama", "huggingface"]
    ] = None
    vision_provider: Optional[Literal["openai", "ollama"]] = None
    image_provider: Optional[Literal["openai", "azure-openai"]] = None

    # ---- Models ---------------------------------------------------
    chat_model: Optional[str] = None
    embedding_model: Optional[str] = None
    vision_embedding_model: Optional[str] = None
    vlm_model: Optional[str] = None
    openai_image_model: Optional[str] = None
    azure_openai_image_model: Optional[str] = None

    # ---- Provider API keys (secret=True; redacted on GET) ---------
    openai_api_key: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )
    azure_openai_api_key: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )
    azure_openai_base_url: Optional[str] = None
    azure_openai_api_version: Optional[str] = None
    anthropic_api_key: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )
    gemini_api_key: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )
    cohere_api_key: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )
    huggingface_api_token: Optional[str] = Field(
        default=None, json_schema_extra={"secret": True}
    )

    # ---- Pipeline behavior ----------------------------------------
    topic_mode: Optional[Literal["bottom_up", "top_down"]] = None
    clustering_method: Optional[Literal["kmeans", "hdbscan"]] = None
    hdbscan_min_cluster_size_pct: Optional[float] = Field(
        default=None, ge=0.001, le=0.5
    )
    hdbscan_min_samples: Optional[int] = Field(default=None, ge=1, le=1000)
    cluster_selection_method: Optional[Literal["eom", "leaf"]] = None
    topdown_sample_size: Optional[int] = Field(default=None, ge=1, le=100)

    # ---- Image handling -------------------------------------------
    include_images: Optional[bool] = None
    image_embedding_method: Optional[Literal["caption", "vision"]] = None
    context_enriched_captions: Optional[bool] = None

    # ---- HuggingFace ----------------------------------------------
    # Required for 8B+ embedders served via dedicated endpoints.
    huggingface_endpoint_url: Optional[str] = None

    # ---- Multi-method pipeline (UI sends these as lists) ----------
    # The AISettingsModal lets a user pick multiple clustering /
    # topic methods to run in parallel. The singular variants above
    # (`clustering_method`, `topic_mode`) are kept for per-call
    # overrides where the agent picks exactly one.
    clustering_methods: Optional[List[Literal["kmeans", "hdbscan"]]] = None
    topic_methods: Optional[List[Literal["bottom_up", "top_down"]]] = None
    kmeans_k: Optional[str] = None  # "auto" or an integer-as-string
    topdown_hierarchy_depth: Optional[int] = Field(default=None, ge=1, le=10)
    topdown_min_subcluster_size: Optional[int] = Field(default=None, ge=2, le=1000)

    # ---- Concept seeding (LLM-pre-labeled clusters) ---------------
    concept_seeding_enabled: Optional[bool] = None
    concept_seeding_count: Optional[int] = Field(default=None, ge=1, le=500)


def secret_keys() -> set:
    """Field names flagged ``secret=True``.

    Used by Phase B's ``GET /v1/auth/me/settings`` handler to know
    which values to redact (return prefix-only) before sending
    settings back over the wire.
    """
    out: set = set()
    for name, field in PipelineSettings.model_fields.items():
        extra = field.json_schema_extra or {}
        if isinstance(extra, dict) and extra.get("secret"):
            out.add(name)
    return out
