"""MCP stdio server registering LatentLab tools.

The transport (stdio) is the standard one Claude Desktop / Claude
Code expect. The tool functions delegate to ``LatentLabClient``;
their docstrings + JSON schema are what the LLM sees, so we keep
them imperative and example-rich.
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Any, Dict, Optional

# The official MCP SDK. Soft-import so syntax checks still pass in
# environments where the dep isn't installed.
try:
    from mcp.server import Server                    # type: ignore
    from mcp.server.stdio import stdio_server        # type: ignore
    import mcp.types as mcp_types                    # type: ignore
    _MCP_AVAILABLE = True
except ImportError:  # pragma: no cover
    _MCP_AVAILABLE = False
    Server = object          # type: ignore[misc,assignment]
    stdio_server = None      # type: ignore[assignment]
    mcp_types = None         # type: ignore[assignment]

from .client import LatentLabClient
from .settings_schema import PipelineSettings


SERVER_NAME = "latentlab"


def _settings_property() -> dict:
    """JSON Schema for the per-call ``settings`` field, suitable for
    embedding in an MCP tool's ``inputSchema.properties.settings``
    (ADR-056 Phase A).

    Generated from the canonical ``PipelineSettings`` Pydantic model
    so the LLM sees the typed shape with enums, bounds, and
    descriptions. Strips Pydantic's ``title`` field at the top level
    since some MCP hosts render it noisily.
    """
    schema = PipelineSettings.model_json_schema()
    schema.pop("title", None)
    schema["description"] = (
        "Optional per-call pipeline override. Settings here win over "
        "the deployment defaults for this upload only; omitted fields "
        "fall through to the user's or deployment's defaults."
    )
    return schema


def _package_version() -> str:
    """Best-effort lookup of the installed latentlab version so
    the agent can self-report which build is actually running. Useful
    when an upgrade has been pulled but the MCP host hasn't restarted
    and is still holding the old module in memory."""
    try:
        from importlib.metadata import version
        return version("latentlab")
    except Exception:
        return "unknown"


def _build_server() -> "Server":
    if not _MCP_AVAILABLE:
        raise RuntimeError(
            "The 'mcp' package is not installed. Run: pip install latentlab"
        )
    server = Server(SERVER_NAME)
    client = LatentLabClient()

    # ---- Tool registrations -------------------------------------------
    # The MCP SDK uses decorators on the Server instance to register
    # tools. Each handler returns a list of TextContent / ImageContent
    # objects; we keep responses as plain JSON-as-text since LLMs
    # parse those readily.

    def _text(s: Any):
        return [mcp_types.TextContent(type="text", text=str(s))]

    @server.list_tools()
    async def list_tools() -> list:
        # Schemas are minimal but accurate; the docstrings are what
        # most LLMs read when planning a call.
        return [
            mcp_types.Tool(
                name="latentlab_login_start",
                description=(
                    "Step 1 of authentication. Calls /v1/auth/device/"
                    "start and returns a verification URL + short user "
                    "code. **Show both to the user verbatim** and tell "
                    "them to open the URL in their browser, sign in, "
                    "and enter the code. Then call latentlab_login_"
                    "finish to wait for their approval. Idempotent — "
                    "fails fast if a key is already cached."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_login_finish",
                description=(
                    "Step 2 of authentication. Polls the in-flight "
                    "device-code flow for up to max_wait_seconds "
                    "(default 60). Returns success once the user has "
                    "approved in their browser. If it returns "
                    "'still_pending', remind the user to approve and "
                    "call this tool again."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "max_wait_seconds": {
                            "type": "integer",
                            "default": 60,
                            "minimum": 5,
                            "maximum": 600,
                        }
                    },
                },
            ),
            mcp_types.Tool(
                name="latentlab_login",
                description=(
                    "Single-shot login. First call returns "
                    "{status: 'action_required', verification_url, "
                    "user_code} — **show both to the user verbatim** "
                    "and tell them to open the URL, sign in, and enter "
                    "the code. Internally polls for ~30s in case the "
                    "user approves quickly; otherwise returns "
                    "still_pending state and you should call this same "
                    "tool again to resume. Returns "
                    "{status: 'logged_in', user_email} when done. "
                    "Idempotent — returns 'already_logged_in' if a key "
                    "is cached."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_logout",
                description="Forget the cached API key for this deployment.",
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_version",
                description=(
                    "Report the installed latentlab package version + the "
                    "API URL the client is pointing at. Use this to "
                    "diagnose 'I pulled but nothing changed' issues — "
                    "if the version doesn't match what's on disk, the "
                    "MCP host needs to be restarted so a fresh Python "
                    "process loads the new module."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_whoami",
                description="Return the LatentLab user this API key belongs to.",
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_list_datasets",
                description="List the signed-in user's datasets (id, name, status, slug).",
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_get_dataset",
                description=(
                    "Get one dataset by integer id. Returns its current "
                    "status — useful for polling after upload."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"id": {"type": "integer"}},
                    "required": ["id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_upload_csv",
                description=(
                    "Upload a CSV file from a local path. Creates a new "
                    "dataset; the response includes its id. Use "
                    "latentlab_wait_for_processing to wait for "
                    "ingestion to finish before searching. Pass "
                    "settings to override pipeline knobs (model, "
                    "clustering, etc.) for this upload only."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Local file path."},
                        "name": {"type": "string"},
                        "description": {"type": "string"},
                        "settings": _settings_property(),
                    },
                    "required": ["path", "name"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_upload_folder",
                description=(
                    "Upload a folder of files (PDFs, text, code, "
                    "images) from a local path. Each file becomes one "
                    "Object. Returns the new dataset's id + slug; use "
                    "latentlab_wait_for_processing to wait for ingestion. "
                    "Set recursive=true to walk subdirectories. Pass "
                    "extensions=['.pdf', '.md'] to filter; otherwise "
                    "every non-dotfile in the directory is uploaded "
                    "and the server applies its own allowed-extension "
                    "list (broader when the deploy has OCR_PARSING=true)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Local folder path."},
                        "name": {"type": "string"},
                        "description": {"type": "string"},
                        "public": {"type": "boolean", "default": False},
                        "recursive": {"type": "boolean", "default": False},
                        "extensions": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Optional client-side extension filter, "
                                "e.g. ['.pdf', '.txt']. Leading dot optional."
                            ),
                        },
                        "settings": _settings_property(),
                    },
                    "required": ["path", "name"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_create_live_url_dataset",
                description=(
                    "Create a live URL dataset (today: git source). "
                    "Provide source_url + source_ref (branch). The "
                    "processor clones the repo and reflects upstream "
                    "changes incrementally."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "source_url": {"type": "string", "format": "uri"},
                        "source_ref": {"type": "string", "default": "main"},
                        "source_type": {"type": "string", "default": "git"},
                        "description": {"type": "string"},
                        "auth_secret_name": {"type": "string"},
                        "sync_interval_seconds": {"type": "integer"},
                        "public": {"type": "boolean", "default": False},
                        "settings": _settings_property(),
                    },
                    "required": ["name", "source_url"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_list_source_types",
                description=(
                    "List registered URL-source adapters (today: 'git'). "
                    "Use this to discover what `source_type` values "
                    "`latentlab_create_live_url_dataset` accepts on this "
                    "deployment and which support webhooks."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            mcp_types.Tool(
                name="latentlab_get_dataset_source",
                description=(
                    "Read a live-folder dataset's source config: "
                    "source_type, source_url, source_ref, last_synced_at, "
                    "last_synced_sha, sync_interval_seconds, "
                    "auth_secret_name, webhook_path. Webhook secret is "
                    "never returned — rotate to re-issue."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"dataset_id": {"type": "integer"}},
                    "required": ["dataset_id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_resync_dataset",
                description=(
                    "Trigger an immediate sync for a live-folder dataset "
                    "instead of waiting for its `sync_interval_seconds`. "
                    "Best-effort: the next periodic poll picks up changes "
                    "even if this call cannot reach the processing server."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"dataset_id": {"type": "integer"}},
                    "required": ["dataset_id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_patch_dataset_source",
                description=(
                    "Edit a live-folder dataset's source config. Accepts "
                    "any subset of `source_ref`, `sync_interval_seconds`, "
                    "`auth_secret_name`. Changing `source_ref` enqueues "
                    "an immediate resync. `source_type` and `source_url` "
                    "are immutable — recreate the dataset to change them."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dataset_id": {"type": "integer"},
                        "source_ref": {"type": "string"},
                        "sync_interval_seconds": {"type": "integer"},
                        "auth_secret_name": {"type": "string"},
                    },
                    "required": ["dataset_id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_rotate_webhook_secret",
                description=(
                    "Mint a fresh webhook HMAC secret for a live-folder "
                    "dataset and return it once. The old secret stops "
                    "verifying immediately — paste the new value into "
                    "the source's webhook config before the next push."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"dataset_id": {"type": "integer"}},
                    "required": ["dataset_id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_search",
                description="Semantic search inside a dataset.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dataset_id": {"type": "integer"},
                        "query": {"type": "string"},
                        "k": {"type": "integer", "default": 10},
                    },
                    "required": ["dataset_id", "query"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_wait_for_processing",
                description=(
                    "Poll GET /datasets/{id} every 5s until status == "
                    "'complete' or timeout_seconds elapses (default "
                    "600). Convenience wrapper around the polling loop."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "dataset_id": {"type": "integer"},
                        "timeout_seconds": {"type": "integer", "default": 600},
                    },
                    "required": ["dataset_id"],
                },
            ),
            mcp_types.Tool(
                name="latentlab_dataset_url",
                description=(
                    "Build the human-facing URL for a dataset, given "
                    "its id. Use this to tell the user where to view "
                    "the map after upload finishes."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {"dataset_id": {"type": "integer"}},
                    "required": ["dataset_id"],
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: Dict[str, Any]) -> list:
        # Light dispatch — each branch maps to LatentLabClient.
        try:
            if name == "latentlab_login_start":
                if client.cached_credential():
                    return _text({"status": "already_logged_in"})
                started = await client.device_login_start()
                return _text({
                    "status": "action_required",
                    "verification_url": started.verification_url,
                    "user_code": started.user_code,
                    "expires_in_seconds": started.expires_in,
                    "message": (
                        f"Open {started.verification_url} in your browser, "
                        f"sign in if needed, then enter the code "
                        f"{started.user_code} (expires in "
                        f"{started.expires_in}s). After approving, call "
                        f"latentlab_login_finish."
                    ),
                })

            if name == "latentlab_login_finish":
                max_wait = int(arguments.get("max_wait_seconds", 60))
                try:
                    cred = await client.device_login_finish(max_wait_seconds=max_wait)
                except RuntimeError as e:
                    msg = str(e)
                    if msg.startswith("still_pending"):
                        return _text({
                            "status": "still_pending",
                            "message": (
                                "User has not approved yet. Remind them to "
                                "approve in their browser, then call "
                                "latentlab_login_finish again."
                            ),
                        })
                    raise
                return _text({
                    "status": "logged_in",
                    "user_email": cred.user_email,
                    "api_key_prefix": cred.api_key_prefix,
                })

            if name == "latentlab_login":
                # Single-shot login that's safe under MCP transport
                # timeouts: returns the verification URL immediately
                # if no flow is in progress, polls briefly, and tells
                # the agent to re-call once the user has approved.
                # Internally a thin wrapper over the two-step flow.
                if client.cached_credential():
                    cred = client.cached_credential()
                    return _text({
                        "status": "already_logged_in",
                        "user_email": cred.user_email,
                        "api_key_prefix": cred.api_key_prefix,
                    })
                if client._pending_login is None:
                    started = await client.device_login_start()
                else:
                    started = client._pending_login
                try:
                    cred = await client.device_login_finish(max_wait_seconds=30)
                except RuntimeError as e:
                    if str(e).startswith("still_pending"):
                        return _text({
                            "status": "action_required",
                            "verification_url": started.verification_url,
                            "user_code": started.user_code,
                            "expires_in_seconds": started.expires_in,
                            "message": (
                                f"Open {started.verification_url} in your "
                                f"browser, sign in if needed, then enter "
                                f"the code {started.user_code}. After "
                                f"approving, call latentlab_login again "
                                f"to resume polling."
                            ),
                        })
                    raise
                return _text({
                    "status": "logged_in",
                    "user_email": cred.user_email,
                    "api_key_prefix": cred.api_key_prefix,
                })

            if name == "latentlab_logout":
                ok = client.logout()
                return _text("Logged out." if ok else "Was not logged in.")

            if name == "latentlab_version":
                return _text({
                    "version": _package_version(),
                    "api_url": client.api_url,
                    "logged_in": client.cached_credential() is not None,
                })

            if name == "latentlab_whoami":
                me = await client.whoami()
                return _text(me)

            if name == "latentlab_list_datasets":
                ds = await client.list_datasets()
                return _text(ds)

            if name == "latentlab_get_dataset":
                ds = await client.get_dataset(int(arguments["id"]))
                return _text(ds)

            if name == "latentlab_upload_csv":
                resp = await client.upload_csv(
                    path=arguments["path"],
                    name=arguments["name"],
                    description=arguments.get("description"),
                    settings=arguments.get("settings"),
                )
                return _text(resp)

            if name == "latentlab_upload_folder":
                resp = await client.upload_folder(
                    path=arguments["path"],
                    name=arguments["name"],
                    description=arguments.get("description"),
                    public=bool(arguments.get("public", False)),
                    recursive=bool(arguments.get("recursive", False)),
                    extensions=arguments.get("extensions"),
                    settings=arguments.get("settings"),
                )
                return _text(resp)

            if name == "latentlab_create_live_url_dataset":
                resp = await client.create_live_url_dataset(**arguments)
                return _text(resp)

            if name == "latentlab_list_source_types":
                resp = await client.list_source_types()
                return _text(resp)

            if name == "latentlab_get_dataset_source":
                resp = await client.get_dataset_source(int(arguments["dataset_id"]))
                return _text(resp)

            if name == "latentlab_resync_dataset":
                resp = await client.force_sync_dataset(int(arguments["dataset_id"]))
                return _text(resp)

            if name == "latentlab_patch_dataset_source":
                resp = await client.patch_dataset_source(
                    int(arguments["dataset_id"]),
                    source_ref=arguments.get("source_ref"),
                    sync_interval_seconds=arguments.get("sync_interval_seconds"),
                    auth_secret_name=arguments.get("auth_secret_name"),
                )
                return _text(resp)

            if name == "latentlab_rotate_webhook_secret":
                resp = await client.rotate_webhook_secret(int(arguments["dataset_id"]))
                return _text(resp)

            if name == "latentlab_search":
                resp = await client.search(
                    dataset_id=int(arguments["dataset_id"]),
                    query=arguments["query"],
                    k=int(arguments.get("k", 10)),
                )
                return _text(resp)

            if name == "latentlab_wait_for_processing":
                ds_id = int(arguments["dataset_id"])
                timeout = int(arguments.get("timeout_seconds", 600))
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    ds = await client.get_dataset(ds_id)
                    status = (ds or {}).get("status")
                    if status == "complete":
                        return _text({"dataset_id": ds_id, "status": status, "dataset": ds})
                    if status == "error":
                        return _text({"dataset_id": ds_id, "status": "error", "dataset": ds})
                    await asyncio.sleep(5)
                return _text({"dataset_id": ds_id, "status": "timeout"})

            if name == "latentlab_dataset_url":
                ds = await client.get_dataset(int(arguments["dataset_id"]))
                slug = (ds or {}).get("slug")
                base = client.api_url
                if base.endswith("/api"):
                    base = base[:-4]
                return _text(f"{base}/app/dataset/{slug}")

            return _text({"error": f"Unknown tool: {name}"})
        except Exception as e:                 # pragma: no cover
            return _text({"error": type(e).__name__, "detail": str(e)})

    return server


async def run_stdio_server() -> None:
    """Top-level entry — wire stdio transport to the Server instance."""
    if not _MCP_AVAILABLE:
        raise RuntimeError(
            "The 'mcp' package is not installed. Run: pip install latentlab"
        )
    server = _build_server()
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())
