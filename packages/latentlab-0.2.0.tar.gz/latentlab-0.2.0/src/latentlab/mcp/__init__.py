"""MCP server wrapping the LatentLab API as agent-friendly tools.

The MCP submodule of the ``latentlab`` package. Loadable as
``python -m latentlab.mcp`` from any MCP host config.

See ADR-055 in the parent repo for the design.
"""

from .. import __version__
from .client import LatentLabClient
from .storage import CredentialsStore

__all__ = ["LatentLabClient", "CredentialsStore", "__version__"]
