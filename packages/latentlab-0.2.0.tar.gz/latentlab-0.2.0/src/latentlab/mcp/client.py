"""Thin REST client used by MCP tools to talk to a LatentLab deployment.

Wraps the bare ``httpx`` interface with two ergonomic things:

  * Reads ``LATENTLAB_API_URL`` once, defaulting to a sensible value.
  * Carries the cached API key from ``CredentialsStore`` and attaches
    it as ``Authorization: Bearer …`` automatically.
  * Exposes split ``device_login_start`` / ``device_login_finish``
    helpers so an LLM-driven tool can show the verification URL to
    the user *before* blocking on poll. The convenience
    ``device_login`` blocks end-to-end (suitable for headless
    scripts / non-interactive callers).
"""

from __future__ import annotations

import asyncio
import csv as _csv
import io
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import httpx

from .storage import CredentialsStore, StoredCredential


DEFAULT_API_URL = "http://localhost:8000"   # dev; users override via env


def _validate_settings(settings):
    """Validate a per-call settings dict against the canonical
    PipelineSettings schema (ADR-056 Phase A).

    Returns the canonicalised dict (with omitted/None fields dropped)
    or ``None`` if input is ``None`` / empty. Raises ``ValueError``
    with a readable message on unknown keys, wrong types, or
    out-of-bounds values — surfaces in the MCP host as a clear tool
    error instead of an opaque 422 from the upload endpoint.
    """
    if not settings:
        return None
    from .settings_schema import PipelineSettings
    try:
        model = PipelineSettings.model_validate(settings)
    except Exception as e:
        raise ValueError(f"Invalid settings: {e}") from None
    return model.model_dump(exclude_none=True) or None


def _slugify(name: str) -> str:
    """Generate a stable URL slug from a human name.

    Lowercases, collapses non-alphanumeric runs to ``-``, trims, and
    appends a short timestamp so repeat uploads of the same name don't
    collide. Mirrors the convention `app_server` itself uses for
    dataset slugs."""
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "dataset"
    return f"{base}-{int(time.time())}"


@dataclass
class DeviceFlowStarted:
    device_code: str
    user_code: str
    verification_url: str
    expires_in: int
    interval: int


class LatentLabClient:
    def __init__(
        self,
        api_url: Optional[str] = None,
        store: Optional[CredentialsStore] = None,
        client_name: str = "latentlab.mcp",
    ) -> None:
        self.api_url = (api_url or os.environ.get("LATENTLAB_API_URL") or DEFAULT_API_URL).rstrip("/")
        self.store = store or CredentialsStore()
        self.client_name = client_name
        self._http = httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0))
        # In-process state for the split start/finish login flow.
        # Kept in-memory because stdio MCP holds one Python process per
        # session — perfect lifetime for an in-flight device code.
        self._pending_login: Optional[DeviceFlowStarted] = None

    # ---- Auth ---------------------------------------------------------

    def cached_credential(self) -> Optional[StoredCredential]:
        return self.store.get(self.api_url)

    def _auth_headers(self) -> Dict[str, str]:
        cred = self.cached_credential()
        if not cred:
            raise RuntimeError(
                "Not authenticated to LatentLab. Run latentlab_login first."
            )
        return {"Authorization": f"Bearer {cred.api_key}"}

    async def device_start(self) -> DeviceFlowStarted:
        r = await self._http.post(
            f"{self.api_url}/v1/auth/device/start",
            json={"client_name": self.client_name},
        )
        r.raise_for_status()
        d = r.json()
        return DeviceFlowStarted(
            device_code=d["device_code"],
            user_code=d["user_code"],
            verification_url=d["verification_url"],
            expires_in=d["expires_in"],
            interval=d["interval"],
        )

    async def device_poll_once(self, device_code: str) -> Dict[str, Any]:
        r = await self._http.post(
            f"{self.api_url}/v1/auth/device/poll",
            json={"device_code": device_code},
        )
        r.raise_for_status()
        return r.json()

    # ---- Two-step login (MCP-friendly) --------------------------------

    async def device_login_start(self) -> DeviceFlowStarted:
        """Kick off the device flow and stash the pending state.

        Returns the prompt the agent should relay to the user. After
        the user approves in their browser, the agent calls
        ``device_login_finish`` to consume the resulting API key.
        """
        if self.cached_credential() is not None:
            raise RuntimeError(
                "Already logged in — call latentlab_logout first if you want a fresh key."
            )
        started = await self.device_start()
        self._pending_login = started
        return started

    async def device_login_finish(self, *, max_wait_seconds: int = 60) -> StoredCredential:
        """Poll the in-flight device flow up to ``max_wait_seconds``.

        Returns the persisted credential on success. Raises
        ``RuntimeError`` with status ``still_pending`` if the user
        hasn't approved yet — the agent should re-call this tool, or
        prompt the user to retry.
        """
        if self._pending_login is None:
            raise RuntimeError(
                "No login in progress. Call latentlab_login_start first."
            )
        started = self._pending_login

        deadline = time.monotonic() + min(max_wait_seconds, started.expires_in)
        while time.monotonic() < deadline:
            try:
                resp = await self.device_poll_once(started.device_code)
            except httpx.HTTPError:
                await asyncio.sleep(started.interval)
                continue
            status = resp.get("status")
            if status == "approved":
                cred = StoredCredential(
                    api_url=self.api_url,
                    api_key=resp["api_key"],
                    api_key_prefix=resp.get("api_key_prefix"),
                )
                self.store.put(cred)
                self._pending_login = None
                # Best-effort enrichment with email — ignore failure.
                try:
                    me = await self._authed_get("/v1/auth/me")
                    cred.user_email = me.get("email")
                    self.store.put(cred)
                except Exception:
                    pass
                return cred
            if status in ("denied", "expired"):
                self._pending_login = None
                raise RuntimeError(f"Device login {status} — please retry.")
            await asyncio.sleep(started.interval)

        # Soft timeout — keep _pending_login set so the agent can
        # call finish again without restarting the flow.
        raise RuntimeError(
            "still_pending: user has not approved yet. Re-run latentlab_login_finish."
        )

    async def device_login(self, *, on_user_action_required=None) -> StoredCredential:
        """Convenience: run the device flow end-to-end (blocks until
        approved). Suitable for non-interactive scripts; the MCP tool
        path uses ``device_login_start`` + ``device_login_finish``
        instead so the LLM can relay the URL up front.
        """
        started = await self.device_start()
        if on_user_action_required:
            on_user_action_required(
                started.verification_url, started.user_code, started.expires_in
            )
        else:
            print(
                f"[latentlab.mcp] Open {started.verification_url} and enter "
                f"code: {started.user_code} (expires in {started.expires_in}s)",
                file=sys.stderr,
            )

        deadline = time.monotonic() + started.expires_in
        while time.monotonic() < deadline:
            await asyncio.sleep(started.interval)
            try:
                resp = await self.device_poll_once(started.device_code)
            except httpx.HTTPError:
                continue
            status = resp.get("status")
            if status == "approved":
                cred = StoredCredential(
                    api_url=self.api_url,
                    api_key=resp["api_key"],
                    api_key_prefix=resp.get("api_key_prefix"),
                )
                self.store.put(cred)
                try:
                    me = await self._authed_get("/v1/auth/me")
                    cred.user_email = me.get("email")
                    self.store.put(cred)
                except Exception:
                    pass
                return cred
            if status in ("denied", "expired"):
                raise RuntimeError(f"Device login {status} — please retry.")
            # else: pending; loop.

        raise TimeoutError("Device login timed out — please retry.")

    def logout(self) -> bool:
        self._pending_login = None
        return self.store.delete(self.api_url)

    # ---- Authenticated REST helpers -----------------------------------

    async def _authed_get(self, path: str, **kwargs) -> Any:
        r = await self._http.get(
            f"{self.api_url}{path}", headers=self._auth_headers(), **kwargs
        )
        r.raise_for_status()
        return r.json() if r.content else None

    async def _authed_post(self, path: str, **kwargs) -> Any:
        r = await self._http.post(
            f"{self.api_url}{path}", headers=self._auth_headers(), **kwargs
        )
        r.raise_for_status()
        return r.json() if r.content else None

    async def _authed_patch(self, path: str, **kwargs) -> Any:
        r = await self._http.patch(
            f"{self.api_url}{path}", headers=self._auth_headers(), **kwargs
        )
        r.raise_for_status()
        return r.json() if r.content else None

    async def whoami(self) -> Dict[str, Any]:
        return await self._authed_get("/v1/auth/me")

    async def list_datasets(self) -> Any:
        return await self._authed_get("/dataset")

    async def get_dataset(self, dataset_id: int) -> Any:
        return await self._authed_get(f"/dataset/{dataset_id}")

    async def get_dataset_by_slug(self, slug: str) -> Any:
        return await self._authed_get(f"/dataset/slug/{slug}")

    async def upload_csv(
        self,
        *,
        path: str,
        name: str,
        description: Optional[str] = None,
        public: bool = False,
        slug: Optional[str] = None,
        field_map: Optional[Dict[str, str]] = None,
        settings: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Upload a local CSV and create a dataset.

        Drives the existing ``POST /upload/sheet`` JSON endpoint:

          1. Read the file as text (``utf-8`` with BOM stripping).
          2. Sample the first ~5 rows and call ``/infer_columns`` to
             pick the best column for embedding/title/etc.
          3. POST the full body to ``/upload/sheet``.
          4. Look up the new dataset by slug to return its ``id``.

        The agent only needs to supply ``path`` + ``name``; the rest is
        inferred. ``field_map`` can be passed to override inference.
        """
        with open(path, "rb") as f:
            raw = f.read()
        # Strip UTF-8 BOM if present so DictReader doesn't fold it
        # into the first column name.
        text = raw.decode("utf-8-sig")

        reader = _csv.DictReader(io.StringIO(text))
        sample_rows: List[Dict[str, str]] = []
        for i, row in enumerate(reader):
            sample_rows.append({k: (v or "") for k, v in row.items()})
            if i >= 4:
                break
        columns = list(reader.fieldnames or [])
        if not columns:
            raise RuntimeError(f"CSV at {path} has no header row")

        if field_map is None:
            field_map = await self._infer_field_map(columns, sample_rows)

        # Inference can come back missing `text` (the embedding column)
        # if /infer_columns 500'd, returned an unrecognised concept,
        # or hallucinated a column name. Fall back to a heuristic so
        # uploads always produce a non-empty dataset rather than
        # KeyError-ing on every item downstream.
        field_map = self._ensure_required_fields(field_map, columns, sample_rows)

        slug = slug or _slugify(name)

        # Validate the settings dict against the canonical schema
        # before sending so a typo surfaces as a clear MCP tool error
        # ("Invalid settings: unknown field foo") rather than an
        # opaque server 422.
        validated_settings = _validate_settings(settings)

        body = {
            "name": name,
            "slug": slug,
            "description": description or "",
            "public": public,
            "topics": [],
            "csv_string": text,
            "field_map": field_map,
        }
        if validated_settings is not None:
            body["settings"] = validated_settings
        r = await self._http.post(
            f"{self.api_url}/upload/sheet",
            headers=self._auth_headers(),
            json=body,
            timeout=httpx.Timeout(300.0, connect=10.0),
        )
        r.raise_for_status()

        # /upload/sheet returns just `True` — look up the row to give
        # the agent a usable id + status.
        ds = await self.get_dataset_by_slug(slug)
        return {
            "id": (ds or {}).get("id"),
            "slug": slug,
            "name": name,
            "status": (ds or {}).get("status"),
            "field_map": field_map,
        }

    @staticmethod
    def _ensure_required_fields(
        field_map: Dict[str, str],
        columns: List[str],
        sample_rows: List[Dict[str, str]],
    ) -> Dict[str, str]:
        """Guarantee ``text`` and ``title`` are mapped.

        The downstream embedding step (``processing_server`` →
        ``utils/data.py:1442``) does ``item['text']`` per row and
        skips on KeyError. If the agent uploads a CSV and inference
        fails to pick an embedding column, every row is dropped —
        which is exactly how datasets 611 + 613 ended up empty.

        Heuristic when inference doesn't supply one: pick the column
        with the longest average value across the sampled rows as
        ``text``; pick a *different* column with the next-longest
        value as ``title``. Last resort is the first column.
        """
        out = dict(field_map)

        def _avg_len(col: str) -> float:
            vals = [str(r.get(col, "")) for r in sample_rows]
            if not vals:
                return 0.0
            return sum(len(v) for v in vals) / len(vals)

        # Rank columns by content length, descending.
        ranked = sorted(columns, key=_avg_len, reverse=True)

        if "text" not in out and ranked:
            out["text"] = ranked[0]
        if "title" not in out and ranked:
            # Prefer a column distinct from `text`; fall back to text
            # if there is only one column.
            for c in ranked:
                if c != out.get("text"):
                    out["title"] = c
                    break
            out.setdefault("title", out["text"])
        return out

    async def _infer_field_map(
        self, columns: List[str], sample_rows: List[Dict[str, str]]
    ) -> Dict[str, str]:
        """Best-effort: ask the server which CSV columns map to the
        canonical visualization fields. Returns a (possibly empty)
        ``{processor_field: csv_column}`` dict — never raises so an
        upload still goes through if inference is offline.

        ``/infer_columns`` returns keys named for the user-facing
        concept (``embedding``, ``color_assignment``, ``image_url``,
        ``link_url``); the upload pipeline expects keys named for the
        processor schema (``text``, ``group``, ``image``, ``link``).
        We translate here so the rest of the client doesn't have to
        know about the rename. Mirrors what the web UI does in
        ``useDatasetManager.ts``.
        """
        try:
            resp = await self._authed_post(
                "/infer_columns", json={"columns": columns, "rows": sample_rows}
            )
        except Exception:
            return {}
        raw = (resp or {}).get("column_mappings", {}) or {}

        # User-facing concept name → processor field name.
        TO_PROCESSOR = {
            "embedding": "text",
            "color_assignment": "group",
            "image_url": "image",
            "link_url": "link",
            "title": "title",
            "date": "date",
        }

        out: Dict[str, str] = {}
        for concept, src in raw.items():
            if not isinstance(src, str) or src not in columns:
                continue
            field = TO_PROCESSOR.get(concept)
            if field is None:
                continue
            out[field] = src
        return out

    async def create_live_url_dataset(self, **kwargs: Any) -> Any:
        # ADR-056 Phase A: validate the optional `settings` kwarg
        # client-side before sending so a typo surfaces as a clear
        # MCP tool error rather than an opaque 422.
        if "settings" in kwargs:
            validated = _validate_settings(kwargs.pop("settings"))
            if validated is not None:
                kwargs["settings"] = validated
        return await self._authed_post("/create-live-url-dataset", json=kwargs)

    async def list_source_types(self) -> Any:
        r = await self._http.get(f"{self.api_url}/live-source-types")
        r.raise_for_status()
        return r.json()

    async def get_dataset_source(self, dataset_id: int) -> Any:
        return await self._authed_get(f"/dataset/{dataset_id}/source")

    async def force_sync_dataset(self, dataset_id: int) -> Any:
        return await self._authed_post(f"/dataset/{dataset_id}/sync-now")

    async def patch_dataset_source(self, dataset_id: int, **kwargs: Any) -> Any:
        body = {k: v for k, v in kwargs.items() if v is not None}
        return await self._authed_patch(f"/dataset/{dataset_id}/source", json=body)

    async def rotate_webhook_secret(self, dataset_id: int) -> Any:
        return await self._authed_post(f"/dataset/{dataset_id}/source/rotate-webhook-secret")

    async def upload_folder(
        self,
        *,
        path: str,
        name: str,
        description: Optional[str] = None,
        public: bool = False,
        recursive: bool = False,
        extensions: Optional[List[str]] = None,
        slug: Optional[str] = None,
        settings: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Upload a folder of files and create a dataset.

        Drives ``POST /upload/folder`` (multipart). Each file becomes one
        Object. The server rejects the whole upload if any file's
        extension isn't on its allowed list — when ``OCR_PARSING=true``
        on the deployment, that list is broad (PDF, DOCX, code, images);
        when disabled, only PDF + TXT are accepted. Passing
        ``extensions=[...]`` filters client-side so a directory with a
        ``.DS_Store`` or stray file doesn't blow up the whole upload.

        ``recursive=False`` (default) — only files in ``path`` itself.
        ``recursive=True`` — walks subdirectories.
        """
        if not os.path.isdir(path):
            raise RuntimeError(f"Not a directory: {path}")

        ext_filter: Optional[set[str]] = None
        if extensions is not None:
            ext_filter = {e.lower() if e.startswith(".") else f".{e.lower()}" for e in extensions}

        # Collect (absolute path, mtime_ms) for each file we'll send.
        collected: List[tuple[str, int]] = []
        if recursive:
            for root, _dirs, files in os.walk(path):
                for fn in files:
                    fp = os.path.join(root, fn)
                    if ext_filter is not None and os.path.splitext(fn)[1].lower() not in ext_filter:
                        continue
                    if fn.startswith("."):
                        continue
                    collected.append((fp, int(os.path.getmtime(fp) * 1000)))
        else:
            for fn in sorted(os.listdir(path)):
                fp = os.path.join(path, fn)
                if not os.path.isfile(fp):
                    continue
                if fn.startswith("."):
                    continue
                if ext_filter is not None and os.path.splitext(fn)[1].lower() not in ext_filter:
                    continue
                collected.append((fp, int(os.path.getmtime(fp) * 1000)))

        if not collected:
            raise RuntimeError(
                f"No files found under {path!r}"
                + (f" matching extensions {sorted(ext_filter)}" if ext_filter else "")
            )

        slug = slug or _slugify(name)

        # Build multipart payload. IMPORTANT: every part must be passed
        # via ``files=`` rather than splitting between ``files=`` and
        # ``data=``. httpx 0.28.x builds a sync-only ``IteratorByteStream``
        # whenever ``data=`` is a list-of-tuples (which we need for the
        # repeated ``creation_dates`` field — a dict can't carry repeated
        # keys). ``AsyncClient.post()`` then rejects the body with
        # "Attempted to send an sync request with an AsyncClient instance."
        # Folding everything into ``files=`` (with ``(None, value)`` tuples
        # for non-file parts) yields a ``MultipartStream`` which is
        # ``AsyncByteStream``-compatible.
        #
        # Read bytes up front so we own them past file-handle scope.
        parts: List[tuple[str, tuple[Optional[str], Any, Optional[str]]]] = []
        for fp, _ in collected:
            with open(fp, "rb") as fh:
                parts.append(
                    ("files", (os.path.basename(fp), fh.read(), "application/octet-stream"))
                )
        for _, ms in collected:
            parts.append(("creation_dates", (None, str(ms), None)))
        parts.append(("slug", (None, slug, None)))
        parts.append(("name", (None, name, None)))
        parts.append(("description", (None, description or "", None)))
        parts.append(("public", (None, "true" if public else "false", None)))

        # ADR-056 Phase A: per-call settings as a JSON-string form
        # field. Validated against the canonical schema before send.
        validated_settings = _validate_settings(settings)
        if validated_settings is not None:
            import json as _json
            parts.append(("settings_json", (None, _json.dumps(validated_settings), None)))

        r = await self._http.post(
            f"{self.api_url}/upload/folder",
            headers=self._auth_headers(),
            files=parts,
            timeout=httpx.Timeout(600.0, connect=10.0),
        )
        r.raise_for_status()

        ds = await self.get_dataset_by_slug(slug)
        return {
            "id": (ds or {}).get("id"),
            "slug": slug,
            "name": name,
            "status": (ds or {}).get("status"),
            "file_count": len(collected),
        }

    async def search(self, *, dataset_id: int, query: str, k: int = 10) -> Any:
        # `k` is accepted for symmetry with future endpoints; today the
        # /qa-search route returns the top 10 hits unconditionally.
        del k
        return await self._authed_post(
            f"/dataset/{dataset_id}/qa-search", json={"query": query}
        )

    async def aclose(self) -> None:
        await self._http.aclose()
