"""Local credentials persistence for the MCP server (ADR-055).

The device-code flow returns an API key once; we cache it per
deployment URL so subsequent tool calls reuse it. Stored in
``~/.latentlab/credentials.json`` with mode 0600.
"""

from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional


def _credentials_path() -> Path:
    # Honour XDG_CONFIG_HOME if set; fall back to ~/.latentlab/.
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return Path(base) / "latentlab" / "credentials.json"


@dataclass
class StoredCredential:
    api_url: str
    api_key: str
    api_key_prefix: Optional[str] = None
    user_email: Optional[str] = None


class CredentialsStore:
    """Per-deployment-URL key cache. JSON-on-disk, mode 0600.

    Layout:
      { "<api_url>": { "api_key": "lk_live_...", "api_key_prefix": "lk_live_a1b2",
                        "user_email": "..." }, ... }
    """

    def __init__(self, path: Optional[Path] = None) -> None:
        self.path = path or _credentials_path()

    def _load(self) -> Dict[str, Dict[str, str]]:
        if not self.path.exists():
            return {}
        try:
            with self.path.open("r") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def _save(self, data: Dict[str, Dict[str, str]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Write to a tmp + rename so a partial write can't corrupt.
        tmp = self.path.with_suffix(".tmp")
        with tmp.open("w") as f:
            json.dump(data, f, indent=2)
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
        os.replace(tmp, self.path)

    def get(self, api_url: str) -> Optional[StoredCredential]:
        row = self._load().get(api_url.rstrip("/"))
        if not row or "api_key" not in row:
            return None
        return StoredCredential(
            api_url=api_url.rstrip("/"),
            api_key=row["api_key"],
            api_key_prefix=row.get("api_key_prefix"),
            user_email=row.get("user_email"),
        )

    def put(self, cred: StoredCredential) -> None:
        data = self._load()
        data[cred.api_url.rstrip("/")] = {
            "api_key": cred.api_key,
            **({"api_key_prefix": cred.api_key_prefix} if cred.api_key_prefix else {}),
            **({"user_email": cred.user_email} if cred.user_email else {}),
        }
        self._save(data)

    def delete(self, api_url: str) -> bool:
        data = self._load()
        key = api_url.rstrip("/")
        if key not in data:
            return False
        del data[key]
        self._save(data)
        return True
