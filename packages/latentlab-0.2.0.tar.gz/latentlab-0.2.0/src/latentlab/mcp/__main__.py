"""``python -m latentlab.mcp`` entry — runs the stdio MCP server."""

from __future__ import annotations

import asyncio
import sys

from .server import run_stdio_server


def main() -> int:
    try:
        asyncio.run(run_stdio_server())
        return 0
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
