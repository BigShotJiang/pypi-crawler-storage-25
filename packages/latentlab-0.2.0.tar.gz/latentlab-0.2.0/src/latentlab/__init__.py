"""LatentLab Python package.

Reserves the top-level ``latentlab`` namespace on PyPI. Currently
ships one user-facing surface, the MCP server submodule
(``latentlab.mcp``); a sync REST SDK (``latentlab.Client``) is
planned and will land under this same package without breaking
existing installs.

See ADR-055 for the agent-facing surface.
"""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("latentlab")
except PackageNotFoundError:
    __version__ = "0.0.0+local"

__all__ = ["__version__"]
