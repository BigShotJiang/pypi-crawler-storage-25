"""Comprehensive tests for the plugin-command importer.

Covers:
- Frontmatter extraction (happy path, missing, malformed)
- Title (H1) extraction
- Section classification (meta vs inputs vs content)
- config_schema generation from Inputs section
- Phase generation with review insertion
- Phase ID de-duplication
- Skill-ref extraction and filtering
- Full round-trip: markdown → YAML → TemplateEngine.load_template → validate
- CLI: ``orch import plugin-command``
- Error handling for malformed inputs
"""

import textwrap
from pathlib import Path
from typing import Any, Dict

import pytest
import yaml
from click.testing import CliRunner

# ---------------------------------------------------------------------------
# Module under test
# ---------------------------------------------------------------------------
from orchestration_engine.importers.plugin_command import (
    META_SECTIONS,
    _classify_section,
    _extract_frontmatter,
    _extract_h1,
    _extract_skill_refs,
    _make_unique_id,
    _parse_document,
    _parse_inputs_section,
    _split_by_h2,
    import_plugin_command,
    import_plugin_command_from_string,
    slugify,
    snake_case,
)
from orchestration_engine.cli import main
from orchestration_engine.templates import TemplateEngine


# ===========================================================================
# Helpers
# ===========================================================================


def _load_yaml(text: str) -> Dict[str, Any]:
    """Parse the generated YAML (strip leading comment lines first)."""
    lines = text.splitlines()
    # Skip leading comment lines
    data_lines = []
    started = False
    for line in lines:
        if not started and line.startswith("#"):
            continue
        started = True
        data_lines.append(line)
    return yaml.safe_load("\n".join(data_lines)) or {}


def _validate(tmp_path: Path, yaml_text: str):
    """Write YAML to a temp file, load it, and run validate_template."""
    p = tmp_path / "template.yaml"
    p.write_text(yaml_text)
    engine = TemplateEngine()
    template = engine.load_template(p)
    errors = engine.validate_template(template)
    return template, errors


# ===========================================================================
# Unit tests: slugify / snake_case
# ===========================================================================


class TestSlugify:
    def test_basic(self):
        assert slugify("Campaign Plan") == "campaign-plan"

    def test_special_chars(self):
        assert slugify("Brand Voice & Tone") == "brand-voice-tone"

    def test_numbers(self):
        assert slugify("Step 1 — Overview") == "step-1-overview"

    def test_leading_trailing(self):
        assert slugify("  --- hello ---  ") == "hello"

    def test_already_slug(self):
        assert slugify("my-pipeline") == "my-pipeline"

    def test_empty(self):
        assert slugify("") == ""


class TestSnakeCase:
    def test_basic(self):
        assert snake_case("Campaign goal") == "campaign_goal"

    def test_with_parens(self):
        # The full strip is done higher up; here we just verify the conversion
        assert snake_case("target audience optional") == "target_audience_optional"

    def test_numbers(self):
        assert snake_case("Field 1") == "field_1"


# ===========================================================================
# Unit tests: frontmatter extraction
# ===========================================================================


class TestExtractFrontmatter:
    def test_happy_path(self):
        doc = textwrap.dedent(
            """\
            ---
            description: Test description
            argument-hint: "<input>"
            tags:
              - marketing
            ---

            # My Title
            """
        )
        fm, body = _extract_frontmatter(doc)
        assert fm["description"] == "Test description"
        assert fm["argument-hint"] == "<input>"
        assert fm["tags"] == ["marketing"]
        assert "# My Title" in body

    def test_no_frontmatter(self):
        doc = "# Just a title\n\nSome body text."
        fm, body = _extract_frontmatter(doc)
        assert fm == {}
        assert body == doc

    def test_empty_frontmatter(self):
        doc = "---\n---\n\n# Title\n"
        fm, body = _extract_frontmatter(doc)
        assert fm == {}
        assert "# Title" in body

    def test_unclosed_frontmatter(self):
        """Without closing ---, treat as no frontmatter."""
        doc = "---\ndescription: test\n\n# Title\n"
        fm, body = _extract_frontmatter(doc)
        assert fm == {}
        assert body == doc

    def test_malformed_yaml(self):
        doc = "---\n: bad: yaml: [\n---\n\n# Title\n"
        with pytest.raises(ValueError, match="[Ff]rontmatter"):
            _extract_frontmatter(doc)


# ===========================================================================
# Unit tests: H1 extraction
# ===========================================================================


class TestExtractH1:
    def test_finds_first_h1(self):
        body = "## Intro\n\n# My Title\n\nSome text.\n"
        title, rest = _extract_h1(body)
        assert title == "My Title"
        assert "# My Title" not in rest

    def test_no_h1(self):
        body = "## Section\n\nSome text.\n"
        title, rest = _extract_h1(body)
        assert title == ""
        assert rest == body

    def test_h1_with_extra_spaces(self):
        body = "#  Padded Title  \n"
        title, _ = _extract_h1(body)
        assert title == "Padded Title"


# ===========================================================================
# Unit tests: H2 section splitting
# ===========================================================================


class TestSplitByH2:
    def test_basic_split(self):
        body = textwrap.dedent(
            """\
            ## Section One
            Body of one.
            More body.

            ## Section Two
            Body of two.
            """
        )
        sections = _split_by_h2(body)
        assert len(sections) == 2
        assert sections[0].heading == "Section One"
        assert "Body of one." in sections[0].body
        assert sections[1].heading == "Section Two"
        assert "Body of two." in sections[1].body

    def test_text_before_first_h2_is_ignored(self):
        body = "Intro text\n\n## Section\nContent.\n"
        sections = _split_by_h2(body)
        assert len(sections) == 1
        assert sections[0].heading == "Section"

    def test_no_sections(self):
        body = "Just some text without any H2.\n"
        assert _split_by_h2(body) == []

    def test_h3_inside_section_is_included_in_body(self):
        body = "## Phase One\n### Sub A\n- item\n"
        sections = _split_by_h2(body)
        assert "### Sub A" in sections[0].body
        assert "- item" in sections[0].body


# ===========================================================================
# Unit tests: section classification
# ===========================================================================


class TestClassifySection:
    @pytest.mark.parametrize(
        "heading,expected",
        [
            ("Trigger", "meta"),
            ("trigger", "meta"),
            ("TRIGGER", "meta"),
            ("Inputs", "inputs"),
            ("INPUTS", "inputs"),
            ("Output", "meta"),
            ("Outputs", "meta"),
            ("Notes", "meta"),
            ("Instructions", "meta"),
            ("Campaign Brief Structure", "content"),
            ("Brand Voice", "content"),
            ("Content Generation by Type", "content"),
            ("SEO Considerations", "content"),
            ("Review Process", "content"),
        ],
    )
    def test_classification(self, heading, expected):
        assert _classify_section(heading) == expected


# ===========================================================================
# Unit tests: config_schema parsing
# ===========================================================================


class TestParseInputsSection:
    def test_required_fields(self):
        body = textwrap.dedent(
            """\
            Gather the following:

            1. **Campaign goal** — the primary objective
            2. **Target audience** — who the campaign is aimed at
            """
        )
        schema = _parse_inputs_section(body)
        assert schema["type"] == "object"
        props = schema["properties"]
        assert "campaign_goal" in props
        assert "target_audience" in props
        assert props["campaign_goal"]["type"] == "string"
        assert "campaign_goal" in schema.get("required", [])
        assert "target_audience" in schema.get("required", [])

    def test_optional_field(self):
        body = textwrap.dedent(
            """\
            1. **Name** — your name
            2. **Budget range** (optional) — approximate budget
            """
        )
        schema = _parse_inputs_section(body)
        required = schema.get("required", [])
        assert "name" in required
        assert "budget_range" not in required
        assert "budget_range" in schema["properties"]

    def test_empty_inputs(self):
        """Empty Inputs section → synthetic fallback schema."""
        schema = _parse_inputs_section("Gather info from the user.")
        assert schema["type"] == "object"
        assert "properties" in schema
        assert len(schema["properties"]) >= 1

    def test_description_stripping(self):
        body = "1. **Topic** — main subject of the content\n"
        schema = _parse_inputs_section(body)
        assert schema["properties"]["topic"]["description"] == "main subject of the content"

    def test_em_dash_and_hyphen_variants(self):
        body = textwrap.dedent(
            """\
            1. **Field one** — em-dash variant
            2. **Field two** - hyphen variant
            """
        )
        schema = _parse_inputs_section(body)
        assert "field_one" in schema["properties"]
        assert "field_two" in schema["properties"]


# ===========================================================================
# Unit tests: phase ID de-duplication
# ===========================================================================


class TestMakeUniqueId:
    def test_first_use_unchanged(self):
        seen: Dict[str, int] = {}
        assert _make_unique_id("phase", seen) == "phase"
        assert seen["phase"] == 1

    def test_collision_gets_suffix(self):
        seen: Dict[str, int] = {}
        _make_unique_id("phase", seen)
        second = _make_unique_id("phase", seen)
        assert second == "phase-2"

    def test_multiple_collisions(self):
        seen: Dict[str, int] = {}
        ids = [_make_unique_id("phase", seen) for _ in range(4)]
        assert ids == ["phase", "phase-2", "phase-3", "phase-4"]

    def test_no_ugly_chained_suffix_when_literal_id_preexists(self):
        """Regression: if 'phase-2' is already in seen (from a literal heading
        named 'Phase 2'), a subsequent duplicate 'Phase' must produce 'phase-3'
        not the ugly 'phase-2-2'.
        """
        seen: Dict[str, int] = {}
        _make_unique_id("phase", seen)      # → 'phase'
        _make_unique_id("phase-2", seen)    # → 'phase-2'  (independent literal)
        third = _make_unique_id("phase", seen)
        assert third == "phase-3", (
            f"Expected 'phase-3' when 'phase-2' already exists, got {third!r}"
        )


# ===========================================================================
# Unit tests: skill-ref extraction
# ===========================================================================


class TestExtractSkillRefs:
    def test_no_base_dir_returns_empty(self):
        text = "[brand-voice skill](../skills/brand-voice/SKILL.md)"
        assert _extract_skill_refs(text, base_dir=None) == []

    def test_resolves_existing_skill(self, tmp_path):
        skill_file = tmp_path / "skills" / "brand-voice" / "SKILL.md"
        skill_file.parent.mkdir(parents=True)
        skill_file.write_text("# Brand Voice Skill")

        commands_dir = tmp_path / "commands"
        commands_dir.mkdir()

        text = "[brand-voice skill](../skills/brand-voice/SKILL.md)"
        refs = _extract_skill_refs(text, base_dir=commands_dir)
        assert len(refs) == 1
        assert refs[0] == str(skill_file.resolve())

    def test_missing_skill_not_included(self, tmp_path):
        text = "[missing skill](../skills/nonexistent/SKILL.md)"
        refs = _extract_skill_refs(text, base_dir=tmp_path)
        assert refs == []

    def test_deduplication(self, tmp_path):
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text("# Skill")
        text = "[a](./SKILL.md) and [b](./SKILL.md)"
        refs = _extract_skill_refs(text, base_dir=tmp_path)
        assert len(refs) == 1

    # ── AC-15: path traversal prevention ────────────────────────────────────

    def test_absolute_path_skill_ref_rejected(self, tmp_path):
        """AC-15: absolute path skill refs must be silently rejected.

        Even if the file exists on disk, an absolute path reference bypasses
        directory-tree confinement and must not be returned.  This prevents
        an untrusted markdown document from exfiltrating arbitrary file paths.
        """
        # Create a real SKILL.md at an absolute path unrelated to base_dir
        skill_file = tmp_path / "outside" / "SKILL.md"
        skill_file.parent.mkdir(parents=True)
        skill_file.write_text("# Outside skill")

        base_dir = tmp_path / "plugin_dir"
        base_dir.mkdir()

        # Absolute path link — points to an existing file, but should be rejected
        text = f"[skill]({str(skill_file)})"
        refs = _extract_skill_refs(text, base_dir=base_dir)
        assert refs == [], (
            "Absolute path skill refs must be rejected to prevent path traversal attacks"
        )

    def test_relative_traversal_within_project_allowed(self, tmp_path):
        """Relative paths that traverse upward within the project remain valid.

        A pattern like ``../skills/brand-voice/SKILL.md`` from a ``commands/``
        directory is the canonical usage and must continue to work.
        """
        skill_file = tmp_path / "skills" / "brand-voice" / "SKILL.md"
        skill_file.parent.mkdir(parents=True)
        skill_file.write_text("# Brand Voice Skill")

        commands_dir = tmp_path / "commands"
        commands_dir.mkdir()

        text = "[brand-voice skill](../skills/brand-voice/SKILL.md)"
        refs = _extract_skill_refs(text, base_dir=commands_dir)
        assert len(refs) == 1, "Relative upward traversal within project must be accepted"

    def test_relative_path_escaping_project_root_rejected(self, tmp_path):
        """AC-15: relative paths that resolve beyond the project root must be rejected.

        Given a command file in ``project/commands/``, the project root is
        ``project/`` (= base_dir.parent).  A reference like
        ``../../outside/SKILL.md`` resolves two levels above ``commands/``
        and exits the project tree — it must be silently dropped.
        """
        # Create a real SKILL.md two levels above base_dir
        outside_skill = tmp_path.parent / "outside" / "SKILL.md"
        outside_skill.parent.mkdir(parents=True, exist_ok=True)
        outside_skill.write_text("# Outside skill")

        base_dir = tmp_path / "commands"
        base_dir.mkdir()

        # ../../outside/SKILL.md from tmp_path/commands/ resolves to
        # tmp_path/../outside/SKILL.md — clearly outside the project root (tmp_path).
        text = "[skill](../../outside/SKILL.md)"
        refs = _extract_skill_refs(text, base_dir=base_dir)
        assert refs == [], (
            "Relative paths that escape the project root must be rejected "
            "to prevent directory-traversal exfiltration of skill file paths"
        )


# ===========================================================================
# Integration: parse_document
# ===========================================================================


class TestParseDocument:
    _SAMPLE = textwrap.dedent(
        """\
        ---
        description: Generate a campaign brief
        argument-hint: "<campaign objective>"
        tags:
          - marketing
        ---

        # Campaign Plan

        > Optional preamble.

        Intro text.

        ## Trigger

        User runs /campaign-plan.

        ## Inputs

        1. **Campaign goal** — the primary objective
        2. **Timeline** — campaign duration
        3. **Budget range** (optional) — approximate budget

        ## Campaign Brief Structure

        ### 1. Overview
        - Campaign name suggestion

        ### 2. Audience
        - Primary segment description

        ## Output

        Present the full campaign brief.
        """
    )

    def test_parses_title(self):
        parsed = _parse_document(self._SAMPLE)
        assert parsed.title == "Campaign Plan"

    def test_parses_frontmatter(self):
        parsed = _parse_document(self._SAMPLE)
        assert parsed.frontmatter["description"] == "Generate a campaign brief"
        assert "marketing" in parsed.frontmatter["tags"]

    def test_has_correct_sections(self):
        parsed = _parse_document(self._SAMPLE)
        headings = [s.heading for s in parsed.sections]
        assert "Trigger" in headings
        assert "Inputs" in headings
        assert "Campaign Brief Structure" in headings
        assert "Output" in headings

    def test_raises_on_missing_h1(self):
        bad = "## Section\n\nNo H1 here.\n"
        with pytest.raises(ValueError, match="H1"):
            _parse_document(bad)


# ===========================================================================
# Integration: full round-trip
# ===========================================================================


MINIMAL_COMMAND = textwrap.dedent(
    """\
    ---
    description: A minimal test command
    ---

    # Minimal Pipeline

    ## Trigger

    Run /minimal.

    ## Inputs

    1. **Topic** — the main subject

    ## Generate Content

    Write content about the topic.

    ## Output

    Present the content.
    """
)

MULTI_SECTION_COMMAND = textwrap.dedent(
    """\
    ---
    description: Multi-section test command
    argument-hint: "<subject>"
    tags:
      - test
    ---

    # Multi Phase Pipeline

    > Preamble.

    ## Trigger

    User runs /multi-phase.

    ## Inputs

    1. **Subject** — what to process
    2. **Tone** (optional) — the desired tone

    ## Research

    ### Gather Sources
    Find relevant sources for {subject}.
    - [ ] Check primary sources
    - [ ] Verify data

    ## Draft

    Write a first draft based on the research.

    ## Review and Polish

    Review the draft for quality.

    ## Output

    Deliver the final document.
    """
)


class TestRoundTrip:
    """Full markdown → YAML → load → validate cycle."""

    def test_minimal_generates_valid_yaml(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        template, errors = _validate(tmp_path, yaml_text)
        assert errors == [], f"Structural errors: {errors}"

    def test_minimal_template_id(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["id"] == "minimal-pipeline"

    def test_minimal_has_description(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["description"]

    def test_minimal_has_author(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["author"]

    def test_minimal_has_version(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["version"] == "1.0.0"

    def test_minimal_config_schema_type(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["config_schema"]["type"] == "object"
        assert "properties" in data["config_schema"]

    def test_minimal_config_schema_has_topic_field(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        props = data["config_schema"]["properties"]
        assert "topic" in props

    def test_minimal_phases(self):
        """Should have 2 phases: generate-content + its review."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert len(data["phases"]) == 2

    def test_minimal_review_phase_inserted(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        phase_ids = [p["id"] for p in data["phases"]]
        assert "generate-content" in phase_ids
        assert "generate-content-review" in phase_ids

    def test_review_phase_has_opus_tier(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review = next(p for p in data["phases"] if p["id"] == "generate-content-review")
        assert review["model_tier"] == "opus"

    def test_review_phase_thinking_medium(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review = next(p for p in data["phases"] if p["id"] == "generate-content-review")
        assert review["thinking_level"] == "medium"

    def test_review_phase_depends_on_content_phase(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review = next(p for p in data["phases"] if p["id"] == "generate-content-review")
        assert "generate-content" in review["depends_on"]

    def test_content_phase_has_sonnet_tier(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content = next(p for p in data["phases"] if p["id"] == "generate-content")
        assert content["model_tier"] == "sonnet"

    def test_multi_section_phase_count(self):
        """3 content sections → 6 phases (3 content + 3 review)."""
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        assert len(data["phases"]) == 6

    def test_multi_section_linear_deps(self):
        """Each phase depends on the previous one in a linear chain."""
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        phases = data["phases"]

        # First content phase has no deps
        assert phases[0]["depends_on"] == []

        # review-1 depends on content-1
        assert phases[0]["id"] in phases[1]["depends_on"]

        # content-2 depends on review-1
        assert phases[1]["id"] in phases[2]["depends_on"]

    def test_multi_section_no_duplicate_ids(self):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        ids = [p["id"] for p in data["phases"]]
        assert len(ids) == len(set(ids)), f"Duplicate IDs: {ids}"

    def test_multi_section_validates(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        template, errors = _validate(tmp_path, yaml_text)
        assert errors == [], f"Structural errors: {errors}"

    def test_optional_field_not_in_required(self):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        required = data["config_schema"].get("required", [])
        assert "tone" not in required
        assert "subject" in required

    def test_prompt_template_contains_input_placeholder(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content = next(p for p in data["phases"] if p["id"] == "generate-content")
        assert "{input}" in content["prompt_template"]

    def test_prompt_template_contains_previous_output_placeholder(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content = next(p for p in data["phases"] if p["id"] == "generate-content")
        assert "{previous_output}" in content["prompt_template"]

    def test_prompt_template_curly_braces_in_body_preserved_verbatim(self):
        """Regression: {word} tokens in the markdown body must not be mangled.

        Previously _build_phase_prompt used str.format(heading=..., body=...).
        Any {heading} or {body} in the section text would be silently replaced;
        other {tokens} would raise KeyError.  The fix uses f-string + concat,
        which passes all body content through unchanged.
        """
        doc = textwrap.dedent(
            """\
            ---
            description: Curly brace test
            ---

            # Jinja Pipeline

            ## Render Template

            Use `{{ variable }}` in Jinja.  Also {heading} and {body} must survive.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        phase = next(p for p in data["phases"] if "render" in p["id"])
        assert "{heading}" in phase["prompt_template"], (
            "{heading} in body was mangled by str.format()"
        )
        assert "{body}" in phase["prompt_template"], (
            "{body} in body was mangled by str.format()"
        )

    def test_tags_propagated_from_frontmatter(self):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        assert "test" in data["tags"]

    def test_use_cases_populated(self):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        data = _load_yaml(yaml_text)
        assert len(data["use_cases"]) >= 1

    def test_example_input_populated(self):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["example_input"]


# ===========================================================================
# Real plugin command files (parametrize if available)
# ===========================================================================


REAL_COMMANDS = [
    "/home/toscan/knowledge-work-plugins/marketing/commands/campaign-plan.md",
    "/home/toscan/knowledge-work-plugins/marketing/commands/draft-content.md",
    "/home/toscan/knowledge-work-plugins/marketing/commands/brand-review.md",
]


@pytest.mark.parametrize("filepath", REAL_COMMANDS)
def test_real_command_round_trip(filepath, tmp_path):
    """Each real plugin command file must produce a valid template."""
    p = Path(filepath)
    if not p.exists():
        pytest.skip(f"Real command file not found: {filepath}")

    yaml_text = import_plugin_command(p, author="test-suite")
    template, errors = _validate(tmp_path, yaml_text)
    assert errors == [], f"{filepath}: structural errors: {errors}"


@pytest.mark.parametrize("filepath", REAL_COMMANDS)
def test_real_command_has_review_phases(filepath):
    """Each real command must have at least one review phase."""
    p = Path(filepath)
    if not p.exists():
        pytest.skip(f"Real command file not found: {filepath}")

    yaml_text = import_plugin_command(p)
    data = _load_yaml(yaml_text)
    review_phases = [ph for ph in data["phases"] if ph.get("model_tier") == "opus"]
    assert len(review_phases) >= 1, "Expected at least one review phase"


@pytest.mark.parametrize("filepath", REAL_COMMANDS)
def test_real_command_model_tiers_valid(filepath):
    """All phases must have valid model_tier values."""
    p = Path(filepath)
    if not p.exists():
        pytest.skip(f"Real command file not found: {filepath}")

    yaml_text = import_plugin_command(p)
    data = _load_yaml(yaml_text)
    valid_tiers = {"haiku", "sonnet", "opus"}
    for phase in data["phases"]:
        assert phase["model_tier"] in valid_tiers, (
            f"Phase '{phase['id']}' has invalid model_tier '{phase['model_tier']}'"
        )


# ===========================================================================
# Error handling
# ===========================================================================


class TestErrorHandling:
    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            import_plugin_command(tmp_path / "does-not-exist.md")

    def test_no_h1_raises(self):
        bad = "## Section\n\nNo H1 here.\n"
        with pytest.raises(ValueError, match="H1"):
            import_plugin_command_from_string(bad)

    def test_malformed_frontmatter_raises(self):
        bad = "---\n: broken: yaml: [[\n---\n\n# Title\n## Section\n\nContent.\n"
        with pytest.raises(ValueError, match="[Ff]rontmatter"):
            import_plugin_command_from_string(bad)

    def test_no_content_sections_produces_minimal_schema(self):
        """Document with only meta sections → valid template with 0 phases."""
        doc = textwrap.dedent(
            """\
            ---
            description: No phases test
            ---

            # Empty Pipeline

            ## Trigger

            Run /empty.

            ## Inputs

            1. **Topic** — the subject

            ## Output

            Nothing.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        assert data["id"] == "empty-pipeline"
        assert data["config_schema"]["type"] == "object"
        # No content phases generated
        assert data["phases"] == []

    def test_duplicate_section_headings(self):
        """Duplicate H2 headings get de-duplicated IDs."""
        doc = textwrap.dedent(
            """\
            ---
            description: Dup test
            ---

            # Dup Pipeline

            ## Step One
            Content A.

            ## Step One
            Content B.

            ## Output
            Done.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        ids = [p["id"] for p in data["phases"]]
        assert len(ids) == len(set(ids)), f"Duplicate IDs found: {ids}"


# ===========================================================================
# CLI tests
# ===========================================================================


def _cli(*args):
    runner = CliRunner()
    return runner.invoke(main, list(args), catch_exceptions=False)


class TestCLI:
    def test_import_help(self):
        result = _cli("import", "--help")
        assert result.exit_code == 0
        assert "plugin-command" in result.output.lower() or "import" in result.output.lower()

    def test_plugin_command_help(self):
        result = _cli("import", "plugin-command", "--help")
        assert result.exit_code == 0
        assert "COMMAND_FILE" in result.output or "command_file" in result.output.lower()

    def test_dry_run_prints_yaml(self, tmp_path):
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        result = _cli("import", "plugin-command", str(cmd_file), "--dry-run")
        assert result.exit_code == 0
        assert "id:" in result.output
        assert "phases:" in result.output

    def test_writes_output_file(self, tmp_path):
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        out_file = tmp_path / "out.yaml"
        result = _cli("import", "plugin-command", str(cmd_file), "--output", str(out_file))
        assert result.exit_code == 0
        assert out_file.exists()
        data = yaml.safe_load(out_file.read_text())
        assert data["id"] == "minimal-pipeline"

    def test_default_output_filename(self, tmp_path, monkeypatch):
        """Without --output, file is written to <template-id>.yaml."""
        monkeypatch.chdir(tmp_path)
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        result = _cli("import", "plugin-command", str(cmd_file))
        assert result.exit_code == 0
        expected = tmp_path / "minimal-pipeline.yaml"
        assert expected.exists(), f"Expected {expected} to be created"

    def test_custom_author(self, tmp_path):
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        out_file = tmp_path / "out.yaml"
        _cli(
            "import", "plugin-command",
            str(cmd_file),
            "--output", str(out_file),
            "--author", "test-author",
        )
        data = yaml.safe_load(out_file.read_text())
        assert data["author"] == "test-author"

    def test_validate_flag_runs_validation(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        out_file = tmp_path / "out.yaml"
        result = _cli(
            "import", "plugin-command",
            str(cmd_file),
            "--output", str(out_file),
            "--validate",
        )
        # Should complete without error (valid template)
        assert result.exit_code == 0
        # Validate output should mention structural checks
        assert "Structural" in result.output or "valid" in result.output.lower()

    def test_missing_input_file_fails(self):
        result = CliRunner().invoke(
            main,
            ["import", "plugin-command", "/nonexistent/file.md"],
            catch_exceptions=False,
        )
        assert result.exit_code != 0

    def test_dry_run_does_not_write_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        _cli("import", "plugin-command", str(cmd_file), "--dry-run")
        yaml_files = list(tmp_path.glob("*.yaml"))
        assert yaml_files == [], "dry-run should not write any file"


# ===========================================================================
# Extended validation: generated YAML must pass orch validate --fix=False
# ===========================================================================


class TestExtendedValidation:
    """Ensure generated templates pass the extended linting checks in
    TemplateEngine.validate_template_extended()."""

    def _run_extended(self, yaml_text: str, tmp_path: Path):
        p = tmp_path / "tpl.yaml"
        p.write_text(yaml_text)
        engine = TemplateEngine()
        template = engine.load_template(p)
        import yaml as _yaml
        with open(p) as fh:
            raw = _yaml.safe_load(fh)
        errs, warns = engine.validate_template_extended(template, raw)
        return errs, warns

    def test_no_extended_errors_minimal(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        errs, _ = self._run_extended(yaml_text, tmp_path)
        assert errs == [], f"Extended errors: {errs}"

    def test_no_extended_errors_multi_section(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MULTI_SECTION_COMMAND)
        errs, _ = self._run_extended(yaml_text, tmp_path)
        assert errs == [], f"Extended errors: {errs}"

    def test_valid_model_tiers_no_warnings(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        _, warns = self._run_extended(yaml_text, tmp_path)
        tier_warnings = [w for w in warns if "model_tier" in w]
        assert tier_warnings == [], f"Unexpected model_tier warnings: {tier_warnings}"

    def test_valid_thinking_levels_no_warnings(self, tmp_path):
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        _, warns = self._run_extended(yaml_text, tmp_path)
        level_warnings = [w for w in warns if "thinking_level" in w]
        assert level_warnings == [], f"Unexpected thinking_level warnings: {level_warnings}"


# ===========================================================================
# AC-14: YAML Dumper isolation (must NOT mutate global yaml.Dumper)
# ===========================================================================


class TestYAMLDumperIsolation:
    """Verify that _dump_template_yaml uses a local Dumper subclass and never
    pollutes the global ``yaml.Dumper.yaml_representers`` dict.

    Before this fix, the code did:

        dumper = yaml.Dumper          # alias, not a copy
        dumper.add_representer(...)   # permanently mutates the class

    which caused silent, cumulative state build-up in long-running processes
    and test runners.
    """

    def test_no_global_yaml_dumper_mutation_single_call(self):
        """AC-14: one call must not add representers to the global yaml.Dumper."""
        before_count = len(yaml.Dumper.yaml_representers)

        import_plugin_command_from_string(MINIMAL_COMMAND)

        after_count = len(yaml.Dumper.yaml_representers)
        assert before_count == after_count, (
            f"yaml.Dumper was mutated after one call: "
            f"{before_count} → {after_count} representers"
        )

    def test_no_global_yaml_dumper_mutation_repeated_calls(self):
        """AC-14: repeated calls must not accumulate representers."""
        before_count = len(yaml.Dumper.yaml_representers)

        for _ in range(5):
            import_plugin_command_from_string(MINIMAL_COMMAND)

        after_count = len(yaml.Dumper.yaml_representers)
        assert before_count == after_count, (
            f"yaml.Dumper representers grew after repeated calls: "
            f"{before_count} → {after_count}"
        )

    def test_no_str_subtype_in_global_dumper_representers(self):
        """AC-14: _LiteralStr (internal str subtype) must never appear in global Dumper."""
        import_plugin_command_from_string(MULTI_SECTION_COMMAND)

        # Check that no new str subclasses leaked into the global representers
        str_subtypes = [
            t for t in yaml.Dumper.yaml_representers.keys()
            if isinstance(t, type) and issubclass(t, str) and t is not str
        ]
        assert str_subtypes == [], (
            f"Unexpected str subtypes leaked into yaml.Dumper.yaml_representers: "
            f"{str_subtypes}"
        )

    def test_global_yaml_dump_unaffected_after_import(self):
        """AC-14: standard yaml.dump still works correctly after the importer runs.

        Specifically, plain strings must serialise as unquoted scalars, not as
        literal blocks (the style the importer uses internally).
        """
        import_plugin_command_from_string(MINIMAL_COMMAND)

        # A plain string should still round-trip cleanly
        result = yaml.dump({"key": "short value"}, Dumper=yaml.Dumper).strip()
        assert result == "key: short value", (
            f"yaml.Dumper behaviour changed after importer call: {result!r}"
        )


# ===========================================================================
# CLI: template_id derivation edge cases
# ===========================================================================


class TestCLITemplateIdDerivation:
    """Ensure the CLI correctly derives the output filename from the generated
    YAML even when the comment header contains YAML-like content.

    The previous implementation used a fragile lstrip+concatenate approach
    that could produce duplicate-key YAML and was sensitive to header content.
    The fix strips comment lines before calling yaml.safe_load.
    """

    def test_output_filename_from_template_id(self, tmp_path, monkeypatch):
        """Output file is named <template-id>.yaml regardless of header noise."""
        monkeypatch.chdir(tmp_path)
        cmd_file = tmp_path / "test.md"
        cmd_file.write_text(MINIMAL_COMMAND)
        result = _cli("import", "plugin-command", str(cmd_file))
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        expected = tmp_path / "minimal-pipeline.yaml"
        assert expected.exists(), (
            f"Expected output file '{expected}' not created. "
            f"CLI output: {result.output}"
        )

    def test_output_filename_for_multi_word_title(self, tmp_path, monkeypatch):
        """Multi-word titles must be slugified into the output filename."""
        monkeypatch.chdir(tmp_path)
        doc = textwrap.dedent(
            """\
            ---
            description: Multi word title test
            ---

            # My Complex Pipeline Title

            ## Step One
            Do something.
            """
        )
        cmd_file = tmp_path / "complex.md"
        cmd_file.write_text(doc)
        result = _cli("import", "plugin-command", str(cmd_file))
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        expected = tmp_path / "my-complex-pipeline-title.yaml"
        assert expected.exists(), (
            f"Expected '{expected}' to be created. CLI output: {result.output}"
        )


# ===========================================================================
# Bug-fix regression tests and coverage gaps
# ===========================================================================


class TestMultipleParentheticals:
    """Regression tests for the _INPUT_FIELD_RE multi-parenthetical fix.

    Previously ``(?:\\([^)]*\\)\\s*)?`` (exactly-one-optional) caused any
    input field that carried *two* parentheticals before the separator to be
    silently dropped from the config_schema.  The fix uses ``*`` (zero-or-more).
    """

    def test_two_parentheticals_before_dash_parsed(self):
        """Field with (note) (optional) before dash must appear in properties."""
        body = textwrap.dedent(
            """\
            1. **Budget** (USD) (optional) — approximate budget in USD
            2. **Qty** (positive integer) (required) — item count
            3. **Topic** — main subject
            """
        )
        schema = _parse_inputs_section(body)
        props = schema["properties"]
        assert "budget" in props, (
            "Field 'Budget' with two parentheticals was silently dropped (multi-paren bug)"
        )
        assert "qty" in props, "Field 'Qty' with two parentheticals was silently dropped"
        assert "topic" in props

    def test_two_parentheticals_optional_detection(self):
        """(optional) in second parenthetical correctly marks field as non-required."""
        body = "1. **Budget** (USD) (optional) — approximate budget"
        schema = _parse_inputs_section(body)
        assert "budget" not in schema.get("required", []), (
            "Field marked (optional) in second parenthetical must not appear in required"
        )

    def test_two_parentheticals_required_detection(self):
        """Absence of (optional) in multi-paren field means it's still required."""
        body = "1. **Qty** (positive integer) (must be > 0) — item count"
        schema = _parse_inputs_section(body)
        assert "qty" in schema.get("required", []), (
            "Field without (optional) in any parenthetical must appear in required"
        )

    def test_description_clean_from_multi_paren(self):
        """Description text must not contain the parenthetical content."""
        body = "1. **Budget** (USD) (optional) — approximate budget in USD"
        schema = _parse_inputs_section(body)
        desc = schema["properties"]["budget"]["description"]
        assert desc == "approximate budget in USD"
        assert "(USD)" not in desc
        assert "(optional)" not in desc


class TestDescriptionOptionalStripping:
    """Regression tests for (optional) stripping from description text.

    Previously ``re.sub(r\"\\s*\\(optional\\)\\s*$\", ...)`` only stripped a
    *trailing* occurrence.  The fix strips all occurrences regardless of position.
    """

    def test_optional_stripped_from_start_of_description(self):
        """Leading (optional) in description must be removed from stored desc."""
        body = "1. **Extra** — (optional) extra context"
        schema = _parse_inputs_section(body)
        desc = schema["properties"]["extra"]["description"]
        assert "(optional)" not in desc.lower(), (
            f"Leading (optional) not stripped from description: {desc!r}"
        )
        assert "extra context" in desc

    def test_optional_stripped_from_middle_of_description(self):
        """Mid-sentence (optional) in description must be removed."""
        body = "1. **Note** — add (optional) notes here for context"
        schema = _parse_inputs_section(body)
        desc = schema["properties"]["note"]["description"]
        assert "(optional)" not in desc.lower(), (
            f"Mid-sentence (optional) not stripped from description: {desc!r}"
        )
        assert "add" in desc
        assert "notes here for context" in desc

    def test_optional_stripped_from_end_of_description(self):
        """Trailing (optional) is still stripped (regression guard)."""
        body = "1. **Comment** — supporting comment (optional)"
        schema = _parse_inputs_section(body)
        desc = schema["properties"]["comment"]["description"]
        assert "(optional)" not in desc.lower()
        assert "supporting comment" in desc

    def test_optional_case_insensitive_stripping(self):
        """(OPTIONAL) and (Optional) must also be stripped."""
        body = "1. **Note** — (OPTIONAL) extra note"
        schema = _parse_inputs_section(body)
        desc = schema["properties"]["note"]["description"]
        assert "optional" not in desc.lower()

    def test_optional_field_still_excluded_from_required_after_desc_fix(self):
        """After fixing description stripping, optional detection must still work."""
        body = textwrap.dedent(
            """\
            1. **Required field** — mandatory input
            2. **Optional field** — (optional) extra information
            """
        )
        schema = _parse_inputs_section(body)
        required = schema.get("required", [])
        assert "required_field" in required
        assert "optional_field" not in required


class TestTagsPreservation:
    """Regression tests for the tags: [] falsy-coercion fix.

    Previously ``tags or ['imported', 'plugin-command']`` replaced an
    explicitly empty ``tags: []`` with the hardcoded defaults.
    """

    def test_explicit_empty_tags_preserved(self):
        """tags: [] in frontmatter must produce an empty list, not defaults."""
        doc = textwrap.dedent(
            """\
            ---
            description: Empty tags test
            tags: []
            ---

            # Tags Test

            ## Step One
            Do something.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        assert data["tags"] == [], (
            f"tags: [] in frontmatter was coerced to defaults: {data['tags']!r}"
        )

    def test_absent_tags_produces_defaults(self):
        """When tags is absent from frontmatter, defaults are used."""
        doc = textwrap.dedent(
            """\
            ---
            description: No tags test
            ---

            # No Tags

            ## Step One
            Do something.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        assert "imported" in data["tags"] or "plugin-command" in data["tags"], (
            f"Absent tags should produce defaults, got: {data['tags']!r}"
        )

    def test_null_tags_produces_defaults(self):
        """tags: null (explicit null) should also produce defaults."""
        doc = textwrap.dedent(
            """\
            ---
            description: Null tags test
            tags: null
            ---

            # Null Tags

            ## Step One
            Do something.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        # null is treated same as absent: use defaults
        assert data["tags"] != [], (
            f"tags: null should fall through to defaults, got: {data['tags']!r}"
        )

    def test_explicit_tags_list_preserved(self):
        """Non-empty tags list from frontmatter is preserved exactly."""
        doc = textwrap.dedent(
            """\
            ---
            description: Has tags
            tags:
              - marketing
              - campaign
            ---

            # Tagged Pipeline

            ## Step One
            Do something.
            """
        )
        yaml_text = import_plugin_command_from_string(doc)
        data = _load_yaml(yaml_text)
        assert "marketing" in data["tags"]
        assert "campaign" in data["tags"]


class TestPhasePromptContent:
    """Coverage for _build_phase_prompt and _build_review_prompt internals."""

    def test_empty_body_uses_fallback_text(self):
        """_build_phase_prompt with empty body emits a sensible default."""
        from orchestration_engine.importers.plugin_command import _build_phase_prompt
        prompt = _build_phase_prompt("Analysis", "")
        # Falls back to completing the named step
        assert "Analysis" in prompt
        assert "Complete the" in prompt or "step" in prompt.lower()

    def test_prompt_contains_both_placeholders(self):
        """Content phase prompt always contains {input} and {previous_output}."""
        from orchestration_engine.importers.plugin_command import _build_phase_prompt
        prompt = _build_phase_prompt("Draft", "Write a draft about {subject}.")
        assert "{input}" in prompt, "Content phase prompt must contain {input}"
        assert "{previous_output}" in prompt, "Content phase prompt must contain {previous_output}"

    def test_body_tokens_survive_verbatim(self):
        """Curly-brace tokens in body text are passed through unchanged."""
        from orchestration_engine.importers.plugin_command import _build_phase_prompt
        prompt = _build_phase_prompt("Step", "Use {custom_var} and {another_var} here.")
        assert "{custom_var}" in prompt
        assert "{another_var}" in prompt

    def test_review_prompt_contains_phase_reference(self):
        """_build_review_prompt must embed a {previous_output[phase_id]} reference."""
        from orchestration_engine.importers.plugin_command import _build_review_prompt
        import re
        prompt = _build_review_prompt("draft", "Draft")
        match = re.search(r"\{previous_output\[draft\]\}", prompt)
        assert match is not None, (
            f"Review prompt does not contain {{previous_output[draft]}}: {prompt[:200]!r}"
        )

    def test_review_prompt_contains_criteria(self):
        """Auto-generated review prompt must include evaluation criteria."""
        from orchestration_engine.importers.plugin_command import _build_review_prompt
        prompt = _build_review_prompt("research", "Research")
        # The review prompt includes standard quality criteria
        assert "Completeness" in prompt or "completeness" in prompt
        assert "Quality" in prompt or "quality" in prompt

    def test_review_prompt_references_phase_name(self):
        """Review prompt must name the phase being reviewed."""
        from orchestration_engine.importers.plugin_command import _build_review_prompt
        prompt = _build_review_prompt("brand-voice", "Brand Voice")
        assert "Brand Voice" in prompt


class TestPhaseStructure:
    """Coverage gaps for phase-level fields not otherwise tested."""

    def test_content_phase_task_type_is_content(self):
        """Content phases must have task_type='content'."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content_phase = next(p for p in data["phases"] if "review" not in p["id"])
        assert content_phase["task_type"] == "content", (
            f"Content phase task_type should be 'content', got {content_phase['task_type']!r}"
        )

    def test_review_phase_task_type_is_review(self):
        """Auto-inserted review phases must have task_type='review'."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review_phase = next(p for p in data["phases"] if "review" in p["id"])
        assert review_phase["task_type"] == "review", (
            f"Review phase task_type should be 'review', got {review_phase['task_type']!r}"
        )

    def test_content_phase_timeout_minutes(self):
        """Content phases have timeout_minutes=30."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content_phase = next(p for p in data["phases"] if "review" not in p["id"])
        assert content_phase["timeout_minutes"] == 30

    def test_review_phase_timeout_minutes(self):
        """Review phases have timeout_minutes=20 (shorter than content)."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review_phase = next(p for p in data["phases"] if "review" in p["id"])
        assert review_phase["timeout_minutes"] == 20

    def test_review_phase_name_format(self):
        """Review phase name is '<content_phase_name> — Review'."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        review_phase = next(p for p in data["phases"] if p["task_type"] == "review")
        assert "Review" in review_phase["name"], (
            f"Review phase name should contain 'Review': {review_phase['name']!r}"
        )
        # Em-dash separator (—) is part of the format
        assert "—" in review_phase["name"], (
            f"Review phase name should use em-dash separator: {review_phase['name']!r}"
        )

    def test_content_phase_description_mentions_step(self):
        """Content phase description must mention the section/step name."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        content_phase = next(p for p in data["phases"] if p["task_type"] == "content")
        assert content_phase["description"], "Content phase must have a non-empty description"
        # Description should reference the phase name in some form
        phase_name_lower = content_phase["name"].lower()
        desc_lower = content_phase["description"].lower()
        # At least one word from the phase name should appear in the description
        words = [w for w in phase_name_lower.split() if len(w) > 3]
        assert any(w in desc_lower for w in words), (
            f"Content phase description {desc_lower!r} doesn't mention phase '{phase_name_lower}'"
        )

    def test_template_category_is_imported(self):
        """Generated templates always carry category='imported'."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data.get("category") == "imported", (
            f"Template category should be 'imported', got {data.get('category')!r}"
        )


class TestSkillRefSectionFilter:
    """Coverage for _skill_refs_for_section heuristic matching."""

    def test_skill_mentioned_in_section_is_included(self, tmp_path):
        """A skill whose directory name appears in a section body is assigned."""
        from orchestration_engine.importers.plugin_command import _skill_refs_for_section

        skill_file = tmp_path / "brand-voice" / "SKILL.md"
        skill_file.parent.mkdir(parents=True)
        skill_file.write_text("# Brand Voice Skill")

        body = "Apply brand voice guidelines when writing the copy."
        result = _skill_refs_for_section(body, [str(skill_file)])
        assert str(skill_file) in result, (
            "Skill whose name appears in the section body should be included"
        )

    def test_skill_not_mentioned_in_section_is_excluded(self, tmp_path):
        """A skill whose directory name does not appear in the section is excluded."""
        from orchestration_engine.importers.plugin_command import _skill_refs_for_section

        skill_file = tmp_path / "seo-guide" / "SKILL.md"
        skill_file.parent.mkdir(parents=True)
        skill_file.write_text("# SEO Guide")

        body = "Write a compelling brand story in the appropriate voice."
        result = _skill_refs_for_section(body, [str(skill_file)])
        assert str(skill_file) not in result, (
            "Skill not mentioned in section body must be excluded"
        )

    def test_empty_all_refs_returns_empty(self, tmp_path):
        """When all_refs is empty, result is always empty."""
        from orchestration_engine.importers.plugin_command import _skill_refs_for_section
        result = _skill_refs_for_section("some body text", [])
        assert result == []


class TestImportFromStringAuthor:
    """Coverage for import_plugin_command_from_string's author parameter."""

    def test_default_author_is_importer_name(self):
        """Without an explicit author, the author field identifies the importer."""
        yaml_text = import_plugin_command_from_string(MINIMAL_COMMAND)
        data = _load_yaml(yaml_text)
        assert data["author"] == "orch import plugin-command"

    def test_explicit_author_overrides_default(self):
        """Explicit author kwarg appears verbatim in the generated YAML."""
        yaml_text = import_plugin_command_from_string(
            MINIMAL_COMMAND, author="my-test-suite"
        )
        data = _load_yaml(yaml_text)
        assert data["author"] == "my-test-suite"
