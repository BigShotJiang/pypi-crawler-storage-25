from .detector import RojakFace, RojakFaceManager

__version__ = "0.3.0"
__all__ = ["RojakFace", "RojakFaceManager"]
