import cv2
import numpy as np
import os
import uuid
import importlib.resources
from PIL import Image
from imgbeddings import imgbeddings

class RojakFace:
    def __init__(self):
        """Core detection and embedding logic."""
        cascade_name = "haarcascade_frontalface_default.xml"
        
        try:
            # Modern way to access package resources (Python 3.9+)
            ref = importlib.resources.files(__name__).joinpath(cascade_name)
            with importlib.resources.as_file(ref) as path:
                self.cascade_path = str(path)
                self.face_cascade = cv2.CascadeClassifier(self.cascade_path)
        except Exception:
            # Fallback to direct file access
            self.cascade_path = os.path.join(os.path.dirname(__file__), cascade_name)
            if not os.path.exists(self.cascade_path):
                self.cascade_path = cascade_name
            self.face_cascade = cv2.CascadeClassifier(self.cascade_path)

        if self.face_cascade.empty():
            raise IOError(f"Could not load face cascade from {self.cascade_path}")
            
        self.ibed = imgbeddings()

    def extract_features(self, image_source):
        """Detects faces and returns 768-d embeddings."""
        if isinstance(image_source, str):
            img = cv2.imread(image_source)
        elif isinstance(image_source, bytes):
            nparr = np.frombuffer(image_source, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        elif isinstance(image_source, np.ndarray):
            img = image_source
        else:
            raise ValueError("Unsupported image source type")

        if img is None:
            return []

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )

        results = []
        for (x, y, w, h) in faces:
            face_img = img[y:y+h, x:x+w]
            face_pil = Image.fromarray(cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB))
            embedding = self.ibed.to_embeddings(face_pil)
            
            results.append({
                "box": [int(x), int(y), int(w), int(h)],
                "embedding": embedding[0].tolist(),
                "face_image": face_img
            })
            
        return results

class RojakFaceManager:
    def __init__(self, db_client=None, qdrant_client=None, table="faces", collection="faces"):
        """Manages storage, automatic learning, and recognition."""
        self.detector = RojakFace()
        self.pg_conn = None
        self.q_client = None
        
        for client in [db_client, qdrant_client]:
            if client is None: continue
            if hasattr(client, 'cursor'): self.pg_conn = client
            elif hasattr(client, 'upsert'): self.q_client = client

        self.table_name = table
        self.collection_name = collection

    def init_storage(self):
        """Initializes PostgreSQL table and Qdrant collection."""
        if self.pg_conn:
            cur = self.pg_conn.cursor()
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    id SERIAL PRIMARY KEY,
                    identity TEXT NOT NULL,
                    filename TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            self.pg_conn.commit()
            cur.close()

        if self.q_client:
            from qdrant_client.models import Distance, VectorParams
            if not self.q_client.collection_exists(self.collection_name):
                self.q_client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(size=768, distance=Distance.COSINE),
                )

    def auto_learn(self, image_source, threshold=0.96, filename=None):
        """
        Processes an image, recognizes known faces, and automatically 
        learns any 'new' faces it hasn't seen before.
        """
        if not self.q_client:
            raise RuntimeError("Qdrant client required for automatic learning (deduplication).")

        results = self.detector.extract_features(image_source)
        if not results:
            return {"new_faces": 0, "known_faces": 0, "details": []}

        stats = {"new_faces": 0, "known_faces": 0, "details": []}

        for face in results:
            # Check if this face exists in Qdrant
            if hasattr(self.q_client, 'query_points'):
                response = self.q_client.query_points(
                    collection_name=self.collection_name,
                    query=face['embedding'],
                    limit=1
                )
                search_result = response.points
            else:
                search_result = self.q_client.search(
                    collection_name=self.collection_name,
                    query_vector=face['embedding'],
                    limit=1
                )

            # If similarity is high, it's a known face
            if search_result and search_result[0].score >= threshold:
                identity = search_result[0].payload.get("identity", "Unknown")
                
                # Record the sighting in Postgres
                if self.pg_conn:
                    cur = self.pg_conn.cursor()
                    cur.execute(
                        f"INSERT INTO {self.table_name} (identity, filename) VALUES (%s, %s)", 
                        (identity, filename)
                    )
                    self.pg_conn.commit()
                    cur.close()

                stats["known_faces"] += 1
                stats["details"].append({"status": "known", "identity": identity, "confidence": float(search_result[0].score)})
            else:
                # It's a new face! Generate a unique identity
                new_identity = f"Person_{uuid.uuid4().hex[:8]}"
                internal_id = None
                
                if self.pg_conn:
                    cur = self.pg_conn.cursor()
                    cur.execute(
                        f"INSERT INTO {self.table_name} (identity, filename) VALUES (%s, %s) RETURNING id", 
                        (new_identity, filename)
                    )
                    internal_id = cur.fetchone()[0]
                    self.pg_conn.commit()
                    cur.close()

                from qdrant_client.models import PointStruct
                point_id = internal_id if internal_id is not None else np.random.randint(0, 10**9)
                self.q_client.upsert(
                    collection_name=self.collection_name,
                    points=[PointStruct(
                        id=point_id,
                        vector=face['embedding'],
                        payload={"identity": new_identity, "filename": filename}
                    )]
                )
                
                stats["new_faces"] += 1
                stats["details"].append({"status": "new", "identity": new_identity, "confidence": float(search_result[0].score) if search_result else 0.0})

        return stats

    def recognize(self, image_source, limit=1, threshold=0.7):
        """Recognizes faces in an image against the database."""
        if not self.q_client:
            raise RuntimeError("Qdrant client required for recognition.")
            
        import base64
        query_results = self.detector.extract_features(image_source)
        final_matches = []
        for face in query_results:
            if hasattr(self.q_client, 'query_points'):
                response = self.q_client.query_points(
                    collection_name=self.collection_name,
                    query=face['embedding'],
                    limit=limit
                )
                search_result = response.points
            else:
                search_result = self.q_client.search(
                    collection_name=self.collection_name,
                    query_vector=face['embedding'],
                    limit=limit
                )
            
            # Convert face_image to base64 for UI display
            _, buffer = cv2.imencode('.jpg', face['face_image'])
            face_base64 = base64.b64encode(buffer).decode('utf-8')

            if search_result and search_result[0].score >= threshold:
                match = search_result[0]
                final_matches.append({
                    "box": face['box'],
                    "identity": match.payload.get("identity", "Unknown"),
                    "confidence": float(match.score),
                    "face_image": f"data:image/jpeg;base64,{face_base64}"
                })
            else:
                final_matches.append({
                    "box": face['box'], 
                    "identity": "Unknown", 
                    "confidence": 0.0,
                    "face_image": f"data:image/jpeg;base64,{face_base64}"
                })
        
        return final_matches

    def update_identity(self, old_identity, new_identity):
        """Renames an identity in both Postgres and Qdrant."""
        if self.pg_conn:
            cur = self.pg_conn.cursor()
            cur.execute(f"UPDATE {self.table_name} SET identity = %s WHERE identity = %s", (new_identity, old_identity))
            self.pg_conn.commit()
            cur.close()
            
        if self.q_client:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            self.q_client.set_payload(
                collection_name=self.collection_name,
                payload={"identity": new_identity},
                points=Filter(
                    must=[
                        FieldCondition(key="identity", match=MatchValue(value=old_identity))
                    ]
                )
            )
        return True

    def process(self, image_source, mode="learn", threshold=0.96, filename=None):
        """
        Unified method to either learn or identify faces in an image.
        
        Args:
            image_source: Path to image, bytes, or numpy array.
            mode: 'learn' (default) to save new faces, or 'identify' to just recognize.
            threshold: Similarity threshold (default 0.96).
            filename: Original filename (used in learn mode).
        """
        if mode == "learn":
            return self.auto_learn(image_source, threshold=threshold, filename=filename)
        else:
            return self.recognize(image_source, threshold=threshold)
