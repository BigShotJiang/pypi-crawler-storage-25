# RojakFace

A powerful, manageable, and smart face recognition library for Python. 

RojakFace simplifies the entire pipeline: from detecting faces in group photos to automatically learning new identities and storing them in PostgreSQL and Qdrant for high-scale (1M+) searching.

## New in v0.3.3
- **Unified `process` Method**: Added a single `process(image, mode='learn'|'identify')` method to the `RojakFaceManager` for easier workflow switching.
- **Base64 Face Crops**: `recognize` method now returns cropped face images in base64 format, enabling direct display in web applications.

## New in v0.3.2
- **Sighting Tracking**: `auto_learn` now records every sighting of a known person in PostgreSQL, allowing for historical tracking of appearances.
- **Identity Renaming**: New `update_identity` method to rename individuals across both PostgreSQL metadata and Qdrant vectors.
- **AI-Ready**: Optimized for integration with LLMs (like Ollama) to build interactive face-recognition assistants.
- **Qdrant Compatibility**: Improved support for newer versions of `qdrant-client` using the `query_points` API.

## Features
- **Automatic Learning**: Discover new people from photos and automatically assign unique IDs.
- **Deduplication**: Automatically ignores faces that are already in your database (96%+ similarity).
- **Hybrid Storage**: PostgreSQL for metadata/facts and Qdrant for lightning-fast vector search.
- **Pluggable Architecture**: Easily custom your own database connections and table/collection names.
- **Production Ready**: Bundled Haar Cascades and optimized for modern Transformers/imgbeddings versions.

## Installation

```bash
pip install RojakFace
```

## Quick Start (Manageable & Smart)

```python
import RojakFace as RF
import psycopg2
from qdrant_client import QdrantClient

# 1. Setup your connections
pg_conn = psycopg2.connect(database="faces_db", user="dev", password="password")
q_client = QdrantClient("localhost", port=6333)

# 2. Initialize the Manager
manager = RF.RojakFaceManager(pg_conn, q_client)
manager.init_storage()

# 3. Automatic Discovery & Learning
# Detects all faces, recognizes known ones, and records sightings of both!
stats = manager.auto_learn("group_photo.jpg", filename="photo_1.jpg")
print(f"Stats: {stats}")

# 4. Renaming an Identity
# Changes name in both PostgreSQL and Qdrant
manager.update_identity("Person_123", "John Doe")

# 5. Identity Recognition
results = manager.recognize("unknown_face.jpg")
for face in results:
    print(f"Found: {face['identity']} (Confidence: {face['confidence']:.2f})")
```

## Low-level Usage (Detector only)

```python
from RojakFace import RojakFace

detector = RojakFace()
features = detector.extract_features("image.jpg")
# returns [{ 'box': [x,y,w,h], 'embedding': [768 floats], 'face_image': numpy_array }, ...]
```
