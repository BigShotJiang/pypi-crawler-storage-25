"""Language-specific symbol extractors."""
