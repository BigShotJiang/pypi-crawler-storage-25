"""Tests for token_goat.bash_parser."""
from __future__ import annotations

import pytest

from token_goat.bash_parser import parse

# ---------------------------------------------------------------------------
# 1. cat foo.py → read
# ---------------------------------------------------------------------------


def test_cat_simple():
    intent = parse("cat foo.py")
    assert intent.kind == "read"
    assert intent.target_path == "foo.py"
    assert intent.limit is None
    assert intent.offset is None


# ---------------------------------------------------------------------------
# 2. head -n 50 foo.py → read, limit=50
# ---------------------------------------------------------------------------


def test_head_n_flag_space():
    intent = parse("head -n 50 foo.py")
    assert intent.kind == "read"
    assert intent.target_path == "foo.py"
    assert intent.limit == 50


# ---------------------------------------------------------------------------
# 3. head -n50 foo.py → read, limit=50 (concatenated flag)
# ---------------------------------------------------------------------------


def test_head_n_flag_concat():
    intent = parse("head -n50 foo.py")
    assert intent.kind == "read"
    assert intent.target_path == "foo.py"
    assert intent.limit == 50


# ---------------------------------------------------------------------------
# 4. head --lines=50 foo.py → read, limit=50
# ---------------------------------------------------------------------------


def test_head_lines_eq():
    intent = parse("head --lines=50 foo.py")
    assert intent.kind == "read"
    assert intent.target_path == "foo.py"
    assert intent.limit == 50


# ---------------------------------------------------------------------------
# 5. rg pattern src/ → grep, pattern=pattern
# ---------------------------------------------------------------------------


def test_rg_simple():
    intent = parse("rg pattern src/")
    assert intent.kind == "grep"
    assert intent.pattern == "pattern"


# ---------------------------------------------------------------------------
# 6. grep -n 'foo bar' --color file.py → grep, pattern='foo bar'
# ---------------------------------------------------------------------------


def test_grep_quoted_pattern():
    intent = parse("grep -n 'foo bar' --color file.py")
    assert intent.kind == "grep"
    assert intent.pattern == "foo bar"


# ---------------------------------------------------------------------------
# 7. find . -name '*.py' → glob
# ---------------------------------------------------------------------------


def test_find_glob():
    intent = parse("find . -name '*.py'")
    assert intent.kind == "glob"


# ---------------------------------------------------------------------------
# 8. sudo cat /etc/passwd → read, target=/etc/passwd (strips sudo)
# ---------------------------------------------------------------------------


def test_sudo_prefix_stripped():
    intent = parse("sudo cat /etc/passwd")
    assert intent.kind == "read"
    assert intent.target_path == "/etc/passwd"


# ---------------------------------------------------------------------------
# 9. VAR=value cat foo → read, target=foo (strips env assignment)
# ---------------------------------------------------------------------------


def test_env_prefix_stripped():
    intent = parse("VAR=value cat foo")
    assert intent.kind == "read"
    assert intent.target_path == "foo"


# ---------------------------------------------------------------------------
# 10. unknown binary → unknown
# ---------------------------------------------------------------------------


def test_unknown_binary():
    intent = parse("garbage")
    assert intent.kind == "unknown"


# ---------------------------------------------------------------------------
# 11. pipe: only leading segment is inspected
# ---------------------------------------------------------------------------


def test_pipe_leading_command():
    intent = parse("cat README.md | grep foo")
    assert intent.kind == "read"
    assert intent.target_path == "README.md"


# ---------------------------------------------------------------------------
# 12. tail -n 20 file.txt → read, limit=20
# ---------------------------------------------------------------------------


def test_tail_n_flag():
    intent = parse("tail -n 20 file.txt")
    assert intent.kind == "read"
    assert intent.target_path == "file.txt"
    assert intent.limit == 20


# ---------------------------------------------------------------------------
# 13. bat src/main.rs → read
# ---------------------------------------------------------------------------


def test_bat_read():
    intent = parse("bat src/main.rs")
    assert intent.kind == "read"
    assert intent.target_path == "src/main.rs"


# ---------------------------------------------------------------------------
# 13b. other read-like commands → read
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command,target_path",
    [
        ("less README.md", "README.md"),
        ("more README.md", "README.md"),
        ("zless README.md", "README.md"),
        ("zmore README.md", "README.md"),
        ("batcat README.md", "README.md"),
        ("nl README.md", "README.md"),
        ("cat -n README.md", "README.md"),
        ("awk 'BEGIN { print }' src/main.py", "src/main.py"),
        ("perl -ne 'print' src/main.py", "src/main.py"),
    ],
)
def test_additional_read_like_commands(command, target_path):
    intent = parse(command)
    assert intent.kind == "read"
    assert intent.target_path == target_path


# ---------------------------------------------------------------------------
# 14a. zcat file.txt → read
# ---------------------------------------------------------------------------


def test_zcat_read():
    intent = parse("zcat docs/notes.txt")
    assert intent.kind == "read"
    assert intent.target_path == "docs/notes.txt"


# ---------------------------------------------------------------------------
# 14b. sed -n '1,20p' file.py → read
# ---------------------------------------------------------------------------


def test_sed_scripted_read():
    intent = parse("sed -n '1,20p' src/main.py")
    assert intent.kind == "read"
    assert intent.target_path == "src/main.py"


# ---------------------------------------------------------------------------
# 14c. sed / perl -i... 's/a/b/' file.py → unknown
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command",
    [
        "sed -i 's/a/b/' src/main.py",
        "sed --in-place 's/a/b/' src/main.py",
        "perl -i.bak -ne 'print' src/main.py",
    ],
)
def test_scripted_in_place_not_read(command):
    intent = parse(command)
    assert intent.kind == "unknown"
    assert intent.reason is not None
    assert "in place" in intent.reason


# ---------------------------------------------------------------------------
# 14. rg -e 'mypattern' → grep via -e flag
# ---------------------------------------------------------------------------


def test_rg_e_flag():
    intent = parse("rg -e 'mypattern' src/")
    assert intent.kind == "grep"
    assert intent.pattern == "mypattern"


# ---------------------------------------------------------------------------
# 15. fd -e ts → glob
# ---------------------------------------------------------------------------


def test_fd_glob():
    intent = parse("fd -e ts")
    assert intent.kind == "glob"


# ---------------------------------------------------------------------------
# 16. empty / whitespace → unknown
# ---------------------------------------------------------------------------


def test_empty_command():
    intent = parse("")
    assert intent.kind == "unknown"


def test_whitespace_only():
    intent = parse("   ")
    assert intent.kind == "unknown"


# ---------------------------------------------------------------------------
# 17. Additional read-equivalent binaries (xxd, od, wc, type)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command,target_path",
    [
        ("xxd binary.bin", "binary.bin"),
        ("od -c binary.bin", "binary.bin"),
        ("wc -l README.md", "README.md"),
        ("wc README.md", "README.md"),
        ("type foo.txt", "foo.txt"),
    ],
)
def test_binary_dump_and_count_readers(command, target_path):
    intent = parse(command)
    assert intent.kind == "read"
    assert intent.target_path == target_path


# ---------------------------------------------------------------------------
# 18. PowerShell Get-Content / gc — case-insensitive, -Path, -TotalCount/-Tail
# ---------------------------------------------------------------------------


def test_powershell_get_content_positional():
    intent = parse("Get-Content foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.limit is None


def test_powershell_get_content_case_insensitive():
    # PowerShell cmdlets are case-insensitive; both must be detected.
    intent = parse("GET-CONTENT foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_powershell_gc_alias():
    intent = parse("gc foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_powershell_get_content_path_flag():
    intent = parse("Get-Content -Path foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_powershell_get_content_literalpath_flag():
    intent = parse("Get-Content -LiteralPath foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_powershell_get_content_totalcount_offset():
    # -TotalCount maps to head -n N → offset=1, limit=N.
    intent = parse("Get-Content -Path foo.txt -TotalCount 50")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.offset == 1
    assert intent.limit == 50


def test_powershell_get_content_tail_no_offset():
    # -Tail N maps to tail -n N → limit only, no offset.
    intent = parse("Get-Content foo.txt -Tail 20")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.offset is None
    assert intent.limit == 20


def test_powershell_get_content_skip_encoding_arg():
    # ``-Encoding utf8`` must not be mistaken for the positional path.
    intent = parse("Get-Content -Encoding utf8 foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


# ---------------------------------------------------------------------------
# 19. Stdin redirection (cmd < FILE) — treated as read of FILE
# ---------------------------------------------------------------------------


def test_redirect_cat_lt_file():
    # ``cat < foo.txt`` is a read of foo.txt — same effect as ``cat foo.txt``.
    intent = parse("cat < foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_redirect_wc_lt_file():
    # ``wc -l < foo.txt`` — wc has no positional path, redirect supplies it.
    intent = parse("wc -l < foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_redirect_unknown_binary_lt_file():
    # Unknown leading binary but stdin redirected from a real file — still a
    # read of the file, since the agent will consume its contents.
    intent = parse("python_script.py < foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


def test_redirect_attached_form():
    # ``cat <foo.txt`` (no space between ``<`` and the path) is valid shell.
    intent = parse("cat <foo.txt")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"


# ---------------------------------------------------------------------------
# 20. Heredoc / here-string — must NOT be classified as a read
# ---------------------------------------------------------------------------


def test_heredoc_not_a_read():
    # ``cat << EOF ... EOF`` consumes the literal heredoc body, not a file.
    intent = parse("cat << EOF")
    assert intent.kind == "unknown"
    assert intent.reason is not None
    assert "heredoc" in intent.reason


def test_here_string_not_a_read():
    # ``grep foo <<< 'bar'`` is a here-string, not a file read.
    intent = parse("cat <<< 'foo bar'")
    assert intent.kind == "unknown"
    assert intent.reason is not None
    assert "heredoc" in intent.reason


# ---------------------------------------------------------------------------
# 21. head extracts offset=1 alongside limit
# ---------------------------------------------------------------------------


def test_head_records_offset_one():
    # head -n N is conceptually "read lines 1..N"; record the slice precisely
    # so session tracking knows the exact range consumed.
    intent = parse("head -n 50 foo.py")
    assert intent.kind == "read"
    assert intent.offset == 1
    assert intent.limit == 50


def test_tail_records_limit_only():
    # tail's starting line depends on the file's total length, which we don't
    # know at parse time — so we record limit only, not offset.
    intent = parse("tail -n 20 file.txt")
    assert intent.kind == "read"
    assert intent.offset is None
    assert intent.limit == 20


# ---------------------------------------------------------------------------
# 22. sed -n 'M,Np' line-range extraction
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command,offset,limit",
    [
        ("sed -n '10,20p' src/main.py", 10, 11),  # inclusive: 10..20 → 11 lines
        ("sed -n '5p' src/main.py", 5, 1),  # single line
        ("sed -n '1,100p' README.md", 1, 100),
    ],
)
def test_sed_line_range_extraction(command, offset, limit):
    intent = parse(command)
    assert intent.kind == "read"
    assert intent.offset == offset
    assert intent.limit == limit


def test_sed_inverted_range_falls_through():
    # End < start is nonsensical — fall back to whole-file semantics rather
    # than emitting negative line counts to the session tracker.
    intent = parse("sed -n '20,10p' src/main.py")
    assert intent.kind == "read"
    assert intent.offset is None
    assert intent.limit is None


def test_sed_unknown_script_no_range():
    # Substitution / other commands don't encode a slice → no offset/limit.
    intent = parse("sed -n '/foo/p' src/main.py")
    assert intent.kind == "read"
    assert intent.offset is None
    assert intent.limit is None


# ---------------------------------------------------------------------------
# 23. awk NR slice extraction
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command,offset,limit",
    [
        ("awk 'NR==5' src/main.py", 5, 1),
        ("awk 'NR>=10 && NR<=20' src/main.py", 10, 11),
        ("awk 'NR >= 10 && NR <= 20' src/main.py", 10, 11),
    ],
)
def test_awk_line_range_extraction(command, offset, limit):
    intent = parse(command)
    assert intent.kind == "read"
    assert intent.offset == offset
    assert intent.limit == limit


def test_awk_complex_script_no_range():
    # Anything beyond the recognised NR forms falls back to whole-file.
    intent = parse("awk '/foo/ { print }' src/main.py")
    assert intent.kind == "read"
    assert intent.offset is None
    assert intent.limit is None


# ---------------------------------------------------------------------------
# 24. Combined: pipe + redirect — leading segment still recognised
# ---------------------------------------------------------------------------


def test_pipe_with_head_offset():
    # ``head -n 30 foo.py | grep bar`` — only the leading read is parsed,
    # and the head offset/limit must survive.
    intent = parse("head -n 30 foo.py | grep bar")
    assert intent.kind == "read"
    assert intent.target_path == "foo.py"
    assert intent.offset == 1
    assert intent.limit == 30


# ---------------------------------------------------------------------------
# 25. PowerShell pipeline filter detection (iter 27)
# ---------------------------------------------------------------------------


def test_powershell_pipe_select_string_positional():
    # ``Get-Content foo | Select-String 'pat'`` — equivalent to ``grep pat foo``.
    # Source path is captured; filtered=True so dedup logic treats it as a
    # partial read, and the search pattern is recorded.
    intent = parse("Get-Content foo.txt | Select-String 'mypat'")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "mypat"


def test_powershell_pipe_select_string_pattern_flag():
    intent = parse("Get-Content foo.txt | Select-String -Pattern 'foo bar'")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "foo bar"


def test_powershell_pipe_sls_alias():
    # ``sls`` is the PowerShell alias for Select-String.
    intent = parse("gc foo.txt | sls 'needle'")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "needle"


def test_powershell_pipe_where_object_match():
    # ``Where-Object { $_ -match 'pat' }`` filters by regex; capture the pattern.
    intent = parse("Get-Content foo.txt | Where-Object { $_ -match 'needle' }")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "needle"


def test_powershell_pipe_where_alias_question_mark():
    # ``?`` is the canonical alias for Where-Object.
    intent = parse("gc foo.txt | ? { $_ -match 'pat' }")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "pat"


def test_powershell_pipe_select_object_first():
    # ``Select-Object -First N`` is head-N for a pipeline.  No upstream filter
    # so this stays an *unfiltered* head read: offset=1, limit=N, filtered=False.
    intent = parse("Get-Content foo.txt | Select-Object -First 10")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.offset == 1
    assert intent.limit == 10
    assert intent.filtered is False


def test_powershell_pipe_select_first_alias():
    # ``select`` is the PowerShell alias for Select-Object.
    intent = parse("gc foo.txt | select -First 5")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.offset == 1
    assert intent.limit == 5


def test_powershell_pipe_select_last():
    # ``Select-Object -Last N`` is tail-N — limit only, no offset.
    intent = parse("Get-Content foo.txt | Select-Object -Last 3")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.offset is None
    assert intent.limit == 3


def test_powershell_pipe_out_string_passthrough():
    # ``Out-String`` is a formatting stage; the source Get-Content is still a
    # full read (no filter, no limit narrowing).
    intent = parse("Get-Content foo.txt | Out-String -Width 200")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is False
    assert intent.limit is None


def test_powershell_pipe_combined_filter_and_limit():
    # ``gc foo | ? { $_ -match 'foo' } | select -First 5`` — both filter and
    # limit; filtered=True takes precedence, limit/offset recorded.
    intent = parse("gc foo.txt | ? { $_ -match 'foo' } | select -First 5")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is True
    assert intent.filter_pattern == "foo"
    assert intent.offset == 1
    assert intent.limit == 5


def test_powershell_pipe_does_not_override_source_totalcount():
    # When Get-Content already specifies -TotalCount, a downstream
    # Select-Object -First should not widen or override the slice.
    intent = parse("Get-Content foo.txt -TotalCount 20 | Select-Object -First 5")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    # Source flag wins: offset=1, limit=20 (the upstream slice is the tighter
    # bound on what was actually read off disk).
    assert intent.offset == 1
    assert intent.limit == 20


def test_powershell_pipe_unfiltered_passthrough_keeps_full_read():
    # Bare Get-Content with no tail must remain an unfiltered full read.
    intent = parse("Get-Content foo.txt")
    assert intent.kind == "read"
    assert intent.filtered is False
    assert intent.filter_pattern is None


def test_bash_pipe_unchanged_no_filtered_flag():
    # Backward compat: bash-style ``cat foo | grep bar`` pipelines retain
    # their historical whole-file-read semantics and never set filtered=True.
    intent = parse("cat foo.txt | grep bar")
    assert intent.kind == "read"
    assert intent.target_path == "foo.txt"
    assert intent.filtered is False
    assert intent.filter_pattern is None
