import time
from pathlib import Path
import yaml
import torch
from torch.utils.data import Dataset, DataLoader
from data_pipeline.data_process.data_fetch.data_fetch import DataFetchWorker
import numpy as np


class RemoteDataset(Dataset):
    def __init__(self, data_fetch_worker: DataFetchWorker, samples_count: int):
        self.data_fetch_worker = data_fetch_worker
        self.samples_count = samples_count
        self.get_idx = 0
        self.batch = None

    def __len__(self):
        return self.samples_count

    def __getitem__(self, index):
        if self.batch is None or self.get_idx >= len(self.batch):
            self.get_idx = 0
            while True:
                try:
                    batch = []
                    frames_info, _, _, _ = self.data_fetch_worker.fetch_data()
                    if frames_info is None:
                        continue
                    for frame_info in frames_info:
                        if frame_info[1] is False:
                            continue
                        frame = frame_info[0]
                        batch.append({
                            "state": frame["observation.state"],
                            "actions": frame["action"],
                            "cam_high": frame["observation.images.cam_high"],
                            "cam_left_wrist": frame["observation.images.cam_left_wrist"],
                            "cam_right_wrist": frame["observation.images.cam_right_wrist"],
                        })
                    if not batch:
                        continue
                    self.batch = batch
                    break
                except Exception as e:  # pylint: disable=broad-except
                    print(f"Error: {e}")
                    continue

        item = self.batch[self.get_idx]
        self.get_idx += 1
        return item


if __name__ == '__main__':
    # DataSet 参数
    config_path = Path(__file__).parent / "config.yaml"
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # DataLoader 参数
    BATCH_SIZE = 32
    NUM_WORKERS = 32
    # Worker多的情况下，prefetch不宜设置太大，否则容易到达系统上限
    PREFETCH_FACTOR = 3
    # Test 参数
    SAMPLES_COUNT = 50000

    data_fetch_worker = DataFetchWorker(config=config, batch_size=32)

    def worker_init_fn(worker_id):
        worker_seed = torch.initial_seed() % 2**32
        data_fetch_worker.set_rng(np.random.default_rng(seed=worker_seed))

    def test_remote_dataloader():
        remote_dataset = RemoteDataset(data_fetch_worker, SAMPLES_COUNT)
        remote_dataloader = DataLoader(remote_dataset, batch_size=BATCH_SIZE, num_workers=NUM_WORKERS,
                                       persistent_workers=True, prefetch_factor=PREFETCH_FACTOR, worker_init_fn=worker_init_fn)
        remote_iter = iter(remote_dataloader)
        t0 = time.time()
        count = 0
        while count < SAMPLES_COUNT:
            print("getting next batch")
            item = next(remote_iter)
            count += len(item['state'])

            if count % 32 == 0:
                print(f"Time: {time.time() - t0}, count: {count}, FPS: {count / (time.time() - t0)}")
        t1 = time.time()
        return t1 - t0, count

    time_remote_dataloader, count_remote_dataloader = test_remote_dataloader()
    print(f"remote dataloader: {time_remote_dataloader}, count: {count_remote_dataloader}")
