#!/usr/bin/env python3

import argparse
import traceback
import bisect
from typing import Any, Dict
from pathlib import Path
import signal
import json
from typing import List, Tuple, Dict, Any
from multiprocessing import Queue as MPQueue, Process, Event as MPEvent
import time
import requests
from loguru import logger
import yaml
import numpy as np
from data_pipeline.data_process.utils.frame_convert import convert_response_to_frame
from data_pipeline.py_api.api_utils import get_all_data_from_dataset_v2, batch_get_vla_training_info_by_query


class DataFetchWorker:
    def __init__(self, config: Dict[str, Any], batch_size: int = 32,
                 auto_sampling: bool = True, metadatas: List[Dict[str, Any]] = None) -> None:
        self.auto_sampling = auto_sampling
        self.batch_size = batch_size
        self.metadatas = metadatas
        self.weights = None
        self.extracted_infos = None
        self.all_recording_events_rel_ms = None
        self.started_secs = None
        self.config = config
        self.service_url = 'https://roboticsx-data.woa.com/trpc.data_pipeline.fetching.DataFetching/FetchV2'
        self.frame_structure = self.config.get("frame_structure")
        self.episode_state_frame_key = self._extract_episode_state_frame_key()
        if metadatas is None or len(metadatas) == 0:
            self.metadatas = self._load_metadatas()
        self.extracted_metadatas = self._extract_metadatas()
        self.extracted_infos, self.weights, self.all_recording_events_rel_ms = self._extract_file_info()
        self.topic_infos = self._extract_topic_infos()
        self._check_config()
        self.session = requests.Session()
        self.rng = None

    def set_rng(self, rng: np.random.Generator):
        self.rng = rng

    def get_extracted_metadatas(self) -> List[Dict[str, Any]]:
        return self.extracted_metadatas

    def __del__(self):
        self.session.close()

    def _check_config(self):
        can_auto_sampling = True
        for key, value in self.frame_structure.items():
            if 'episode_state' in value['values'] and len(value['values']) > 1:
                raise ValueError(f"frame_structure 中 {key} 的 values 包含 episode_state, 只能有一个元素")
            if 'episode_state' in value['values'] and value['count'] != 1:
                raise ValueError(f"frame_structure 中 {key} 的 values 包含 episode_state, count只能为1")
            if 'values' not in value or not isinstance(value['values'], list):
                raise ValueError(f"frame_structure 中 {key} 的 values 必须为列表")
            if 'count' not in value or not isinstance(value['count'], int):
                raise ValueError(f"frame_structure 中 {key} 的 count 必须为整数")
            if value['fps'] < 0:
                can_auto_sampling = False
        if can_auto_sampling is False and self.auto_sampling is True:
            raise ValueError("auto_sampling 模式下, 所有topic的fps必须大于等于0")

    def _extract_topic_infos(self) -> Dict[str, Dict[str, Any]]:
        topic_infos = {}
        for value in self.frame_structure.values():
            values = value.get("values")
            fps = value.get("fps")
            count = value.get("count")
            for value in values:
                if value in topic_infos:
                    raise ValueError(f"frame_structure values中 {value} 不允许重复出现")
                else:
                    topic_infos[value] = {
                        'fps': fps,
                        'count': count,
                    }
        return topic_infos

    def _extract_metadatas(self) -> List[Dict[str, Any]]:
        extracted_metadatas = []
        for metadata_item in self.metadatas:
            cos_storage = metadata_item.get("cos_storage", {})
            files = cos_storage.get("files", [])
            metadata = metadata_item.get("metadata", {})
            start_moving_relative_time = metadata.get("statistics", {}).get("start_moving_relative_time", None)
            bag_start_time = metadata.get("statistics", {}).get("bag_start_time", None)
            time_duration = metadata.get("statistics", {}).get("time_duration", None)
            recording_events = metadata.get("recording_events", [])
            if not files:
                logger.warning(f"skip invalid metadata: missing files: {cos_storage}")
                continue
            if start_moving_relative_time is None:
                logger.warning(f"skip invalid metadata: missing start_moving_relative_time: {cos_storage}")
                continue
            if time_duration is None:
                logger.warning(f"skip invalid metadata: missing time_duration: {cos_storage}")
                continue
            if bag_start_time is None:
                logger.warning(f"skip invalid metadata: missing bag_start_time: {cos_storage}")
                continue
            if self.episode_state_frame_key is not None and len(recording_events) == 0:
                logger.warning(f"skip invalid metadata: missing recording_events: {cos_storage}")
                continue
            extracted_metadatas.append(metadata_item)
        return extracted_metadatas

    def _extract_file_info(self) -> Tuple[List[Tuple[str, int, int]], np.array, List[List[Dict[str, Any]]]]:
        """
        Extract file info from metadatas (key, started_at and time_duration_sec).

        Args:
            metadatas: metadata list

        Returns:
            file info list, each element is (file_key, started_at, time_duration_sec)
            weights array
        """
        file_infos = []
        weights = []
        all_recording_events_rel_ms = []

        for metadata_item in self.extracted_metadatas:
            cos_storage = metadata_item.get("cos_storage", {})
            files = cos_storage.get("files", [])
            metadata = metadata_item.get("metadata", {})
            start_moving_relative_time = metadata.get("statistics", {}).get("start_moving_relative_time", None)
            bag_start_time = metadata.get("statistics", {}).get("bag_start_time", None)
            time_duration = metadata.get("statistics", {}).get("time_duration", None)
            recording_events = metadata.get("recording_events", [])
            relative_time_ms = int(start_moving_relative_time.get('sec') * 1000) + \
                int(start_moving_relative_time.get('nsec') / 1000000)
            time_duration_ms = int(time_duration.get("sec") * 1000) + int(time_duration.get("nsec") / 1000000)

            weights.append(time_duration_ms)
            # use the first file as the file key
            if len(files) > 1:
                logger.warning(f"metadata has {len(files)} files, use the first file as the file key")
            file_infos.append((files[0]['key'], relative_time_ms, time_duration_ms))

            started_at_ms = int(bag_start_time.get('sec') * 1000) + int(bag_start_time.get('nsec') / 1000000)

            recording_events_rel_ms = []
            for recording_event_rel_ms in recording_events:
                if recording_event_rel_ms['event_type'] != 'step_finished' and \
                        recording_event_rel_ms['event_type'] != 'step_started':
                    continue
                rel_ms = recording_event_rel_ms.copy()
                rel_ms['timestamp_ms'] = int(rel_ms['timestamp_ms']) - started_at_ms
                recording_events_rel_ms.append(rel_ms)
            recording_events_rel_ms = sorted(recording_events_rel_ms, key=lambda x: x['timestamp_ms'])
            all_recording_events_rel_ms.append(recording_events_rel_ms)

        weights = np.array(weights)
        weights = weights / weights.sum()

        return file_infos, weights, all_recording_events_rel_ms

    def _extract_episode_state_frame_key(self):
        for frame_key, frame_value in self.frame_structure.items():
            if 'episode_state' in frame_value.get("values", []):
                return frame_key
        return None

    def _load_metadatas(self):
        metadatas = []
        dataset_ids = self.config.get("data_filter").get("dataset_ids", None)
        if dataset_ids and isinstance(dataset_ids, list):
            for dataset_id in dataset_ids:
                metadatas.extend(get_all_data_from_dataset_v2(dataset_id))
            logger.info(f"Selected {len(metadatas)} data from datasets {dataset_ids}")
            return metadatas

        query = self.config.get("data_filter").get("query", None)
        if query is None:
            logger.error(f"No query or dataset ids specified")
            return
        metadatas = batch_get_vla_training_info_by_query(query)
        logger.info(f"Selected {len(metadatas)} data by query {query}")
        return metadatas

    def _get_event_detail(self, indices, all_offset_ms):
        event_details = []
        for index, offset_ms in zip(indices, all_offset_ms):
            recording_events = self.all_recording_events_rel_ms[index]
            timestamps = [int(event['timestamp_ms']) for event in recording_events]
            idx = bisect.bisect_right(timestamps, offset_ms)
            # In case the offset_ms is larger than the last timestamp_ms, use the last event_detail
            if idx >= len(recording_events):
                idx = len(recording_events) - 1
            # In case of step_finished, use the current event_detail
            elif recording_events[idx]['event_type'] == 'step_finished':
                idx = idx
            # In case of step_started, use the previous event_detail
            else:
                idx = max(0, idx - 1)
            event_details.append(recording_events[idx]['event_detail'])
        return event_details

    def fetch_data(self, metadata_indices=None, frame_rel_ts_ms_list=None):
        try:
            if metadata_indices is None or frame_rel_ts_ms_list is None:
                metadata_indices, frame_rel_ts_ms_list = self._auto_sampling()
            event_details = None
            if self.episode_state_frame_key is not None:
                episode_state_relative_timestamps_ms = [frame_rel_ts_ms[self.episode_state_frame_key][0]
                                                        for frame_rel_ts_ms in frame_rel_ts_ms_list]
                event_details = self._get_event_detail(metadata_indices, episode_state_relative_timestamps_ms)
            request_data = self._prepare_request(metadata_indices, frame_rel_ts_ms_list)
            if request_data is None:
                logger.error(f"Failed to prepare request, skipping")
                return None, None, None, None
            headers = {
                "Content-Type": "application/json"
            }
            start_time = time.time()
            response = self.session.post(self.service_url, json=request_data, headers=headers, verify=True, timeout=30)
            response_bytes = response.content
            if len(response_bytes) == 0:
                logger.error(f"Request error: {response.status_code}")
                return None, None, None, None
            if response.status_code != 200:
                logger.error(f"Request error: {response.status_code}")
                return None, None, None, None
            response_dict = json.loads(response_bytes)
            post_elapsed = time.time() - start_time
            start_time = time.time()
            frames_info = convert_response_to_frame(
                response_dict, self.frame_structure, self.topic_infos, event_details)
            convert_elapsed = time.time() - start_time

            invalid_count = 0
            discard_count = 0
            for frame_info in frames_info:
                if frame_info[1] is False:
                    invalid_count += 1
            # Performance metrics
            perf = {
                "frame_count": len(frames_info),
                "post_time": post_elapsed,
                "convert_time": convert_elapsed,
                "rsp_count": 1,
                "fetch_mb_count": float(len(response_bytes)) / 1024.0 / 1024.0,
                "invalid_count": invalid_count,
                "discard_count": discard_count,
            }
            return frames_info, perf, metadata_indices, frame_rel_ts_ms_list
        except Exception as e:  # pylint: disable=broad-except
            logger.error(f"fetch data error: {e}, traceback: {traceback.format_exc()}")
            return None, None, metadata_indices, frame_rel_ts_ms_list

    def _ms_to_secs_nsecs(self, ms: int) -> Tuple[int, int]:
        sec = int(ms // 1000)
        nsec = int(ms % 1000 * 1000000)
        return {'sec': sec, 'nsec': nsec}

    def _build_topic_specific_file_infos(self, frame_rel_ts_ms: Dict[str, List[int]]) -> Dict[str, List[int]]:
        topic_specific_file_infos = []
        # TODO(victorscsu): maintain same order as `topic_infos`
        for key, value in self.frame_structure.items():
            values = value.get("values", [])
            if self.episode_state_frame_key is not None and key == self.episode_state_frame_key:
                continue
            for value in values:
                ts_num = len(frame_rel_ts_ms[key])
                msg_num = self.topic_infos[value]['count']
                if self.topic_infos[value]['fps'] > 0 and ts_num != 1:
                    logger.error(f"Topic {value} has {ts_num} timestamps, but expected {msg_num}")
                    return None
                elif self.topic_infos[value]['fps'] <= 0 and ts_num != msg_num:
                    logger.error(f"Topic {value} has {ts_num} timestamps, but expected {msg_num}")
                    return None
                elif self.topic_infos[value]['fps'] > 0:
                    topic_specific_file_infos.append({
                        "name": value,
                        "fixed_rate_file_info": {
                            "relative_timestamp": self._ms_to_secs_nsecs(frame_rel_ts_ms[key][0]),
                        }
                    })
                    continue
                else:
                    topic_specific_file_infos.append({
                        "name": value,
                        "timestamps_file_info": {
                            "relative_timestamp": [
                                self._ms_to_secs_nsecs(timestamp_ms) for timestamp_ms in frame_rel_ts_ms[key]
                            ],
                        }
                    })
                    continue
        return topic_specific_file_infos

    def _auto_sampling(self) -> Tuple[List[int], List[Dict[str, List[int]]]]:
        metadata_indices = self.rng.choice(
            len(self.extracted_infos),
            size=self.batch_size,
            replace=True,
            p=self.weights
        )
        frame_rel_ts_ms_list = []
        frame_keys = self.frame_structure.keys()
        for metadata_index in metadata_indices:
            # makesure end_time is larger than begin_time and not too close to the end of the episode
            begin_timestamp_ms = self.extracted_infos[metadata_index][1]
            time_duration_ms = self.extracted_infos[metadata_index][2]
            end_timestamp_ms = max(begin_timestamp_ms + 1000, time_duration_ms - 1200)
            offset_ms = self.rng.integers(begin_timestamp_ms, end_timestamp_ms)

            frame_rel_ts_ms = {key: [offset_ms] for key in frame_keys}
            frame_rel_ts_ms_list.append(frame_rel_ts_ms)
        return metadata_indices, frame_rel_ts_ms_list

    def _prepare_request(self, metadata_indices: List[int],
                         frame_rel_ts_ms_list: List[Dict[str, List[int]]]) -> Dict[str, Any]:
        file_infos = []
        topic_infos = []
        # Prepare topic infos for each topic
        for topic_name, topic_info in self.topic_infos.items():
            if topic_name == 'episode_state':
                continue
            info = {
                "name": topic_name,
            }
            if topic_info['fps'] > 0:
                info['fixed_rate_topic_info'] = {
                    "fps": topic_info['fps'],
                    "number_of_messages": topic_info['count'],
                    "reverse_time_order": False,   # TODO(victorscsu): support reverse_time_order in config.yaml
                }
            else:
                info['timestamps_topic_info'] = {
                    "number_of_messages": topic_info['count'],
                }
            topic_infos.append(info)
        # Prepare file infos for each file
        for metadata_index, frame_rel_ts_ms in zip(metadata_indices, frame_rel_ts_ms_list):
            topic_specific_file_infos = self._build_topic_specific_file_infos(frame_rel_ts_ms)
            if topic_specific_file_infos is None:
                logger.error(f"Failed to build file info request")
                return None
            file_info = {
                "key": self.extracted_infos[metadata_index][0],
                "topic_specific_file_infos": topic_specific_file_infos,
            }
            file_infos.append(file_info)
        return {"topic_infos": topic_infos, "file_infos": file_infos}


class DataFetchManager:
    def __init__(self, config: Dict[str, Any], queue_size: int = 4096,
                 concurrency: int = 32, batch_size: int = 32, auto_sampling: bool = True) -> None:
        self.data_fetch_worker = DataFetchWorker(config, batch_size, auto_sampling)
        self.stop_event = MPEvent()
        self.frame_queue = MPQueue(maxsize=queue_size)
        self.input_queue = MPQueue()
        self.process_pool = []
        self.concurrency = concurrency
        self.auto_sampling = auto_sampling
        self.frame_queue.cancel_join_thread()

        from multiprocessing import Lock, Value
        self.perf_lock = Lock()
        self.rsp_count = Value('i', 0)
        self.frame_count = Value('i', 0)
        self.invalid_count = Value('i', 0)
        self.discard_count = Value('i', 0)
        self.post_time = Value('f', 0.0)
        self.convert_time = Value('f', 0.0)
        self.fetch_mb_count = Value('f', 0.0)

    def start(self):
        '''
        Start the data fetch manager with multiple processes.
        '''
        # Select various random seeds for each process
        seeds = np.random.choice(range(1000000), size=self.concurrency, replace=False)
        self.started_secs = time.time()
        for i in range(self.concurrency):
            self.process_pool.append(
                Process(
                    target=self._request_loop,
                    daemon=True,
                    name=f"RequestWorker-{i}",
                    args=(int(seeds[i]),)))

        for process in self.process_pool:
            process.start()

    def close(self):
        '''
        Close the data fetch manager and join all processes.
        '''
        if self.stop_event is not None:
            self.stop_event.set()
        if self.process_pool is not None:
            for process in self.process_pool:
                if process.is_alive():
                    process.terminate()
                    process.join()

    def __del__(self):
        self.close()

    def enqueue_input(self, metadata_indices: List[int], frame_rel_ts_ms_list: List[Dict[str, List[int]]]):
        if len(metadata_indices) != len(frame_rel_ts_ms_list):
            raise ValueError("metadata_indices and frame_rel_ts_ms_list must have the same length")
        self.input_queue.put((metadata_indices, frame_rel_ts_ms_list))

    def fetch_data(self) -> Tuple[Dict[str, Any], bool, Dict[str, Any], str]:
        return self.frame_queue.get()

    def _request_loop(self, rand_seed: int):
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        self.data_fetch_worker.set_rng(np.random.default_rng(seed=rand_seed))
        while not self.stop_event.is_set():
            metadata_indices = None
            frame_rel_ts_ms_list = None
            if self.auto_sampling is False:
                metadata_indices, frame_rel_ts_ms_list = self.input_queue.get()
            frames_info, perf, _, _ = self.data_fetch_worker.fetch_data(metadata_indices, frame_rel_ts_ms_list)
            if frames_info is None:
                continue
            for frame_info in frames_info:
                self.frame_queue.put(frame_info)
            with self.perf_lock:
                self.rsp_count.value += perf['rsp_count']
                self.frame_count.value += perf['frame_count']
                self.invalid_count.value += perf['invalid_count']
                self.discard_count.value += perf['discard_count']
                self.post_time.value += perf['post_time']
                self.convert_time.value += perf['convert_time']
                self.fetch_mb_count.value += perf['fetch_mb_count']

    def get_perf(self):
        '''
        Get the performance of the data fetch manager.
        '''
        elapsed_secs = time.time() - self.started_secs
        with self.perf_lock:
            return {
                "rsp_count": self.rsp_count.value,
                "frame_count": self.frame_count.value,
                "invalid_count": self.invalid_count.value,
                "discard_count": self.discard_count.value,
                "avg_fps": self.frame_count.value / elapsed_secs,
                "avg_post_sec": self.post_time.value / self.rsp_count.value,
                "avg_convert_sec": self.convert_time.value / self.rsp_count.value,
                "avg_fetch_rate_mbps": self.fetch_mb_count.value / elapsed_secs,
            }


def print_frame_summary(frame: Dict[str, Any]):
    print("*" * 5, "frame keys: ", list(frame.keys()), "*" * 5)
    for key, value in frame.items():
        print(f"frame: {key}, {len(value)} topics, type: ", type(value))
        if isinstance(value, np.ndarray):
            print(f"    shape: {value.shape}")
            print(f"    min: {value.min()}, max: {value.max()}")
            print(f"    mean: {value.mean()}, std: {value.std()}")
            print(f"    dtype: {value.dtype}")
            print(f"    itemsize: {value.itemsize}")
            print(f"    nbytes: {value.nbytes}")
            print(f"    ndim: {value.ndim}")
        elif isinstance(value, list):
            print(f"    list: {value}")
        elif isinstance(value, str):
            print(f"    str: {value}")
        else:
            print(f"    unknown: {value}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Test HTTP connection pool performance"
    )
    parser.add_argument(
        "-c", "--concurrency",
        type=int,
        default=32,
        help="Number of concurrent requests (default: 8)"
    )
    parser.add_argument(
        "-n", "--total-samples",
        type=int,
        default=10000,
        help="Number of total samples (default: 256)"
    )
    parser.add_argument(
        "-b", "--batch-size",
        type=int,
        default=32,
        help="Batch size (default: 32)"
    )
    parser.add_argument(
        "-d", "--disable-auto-sampling",
        action="store_true",
        help="Disable auto sampling of files and timestamps from metadata"
    )

    args = parser.parse_args()
    concurrency = args.concurrency
    total_samples = args.total_samples
    batch_size = args.batch_size
    auto_sampling = not args.disable_auto_sampling
    config_path = Path(__file__).parent / "config.yaml"
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    data_fetch_manager = DataFetchManager(config=config, concurrency=concurrency,
                                          batch_size=batch_size, auto_sampling=auto_sampling)
    data_fetch_manager.start()
    time_start = time.time()
    FRAME_GET = 0
    try:
        while FRAME_GET < total_samples:
            frame, valid, topic_to_data, error_str = data_fetch_manager.fetch_data()
            if frame is None or len(frame) == 0:
                logger.warning(f"Frame is None or empty, sleeping for 0.1 seconds,"
                               f"frame_get: {FRAME_GET}, total_samples: {total_samples}")
                continue
            if not valid:
                logger.error(f"Frame is not valid, error: {error_str}")
                continue
            if FRAME_GET % 1024 == 0:
                logger.info(f"Perf: {data_fetch_manager.get_perf()}")
            FRAME_GET += 1
    except Exception as e:  # pylint: disable=broad-except
        logger.error(f"Error: {e}")
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down gracefully...")
    finally:
        time_end = time.time()
        print(f"Time taken: {time_end - time_start} seconds")
        print(f"Total frames fetched: {FRAME_GET}")
        print(f"Total frames per second: {FRAME_GET / (time_end - time_start)}")

    data_fetch_manager.close()
    logger.info(f"Total frames downloaded: {data_fetch_manager.frame_count.value}")
