class ConfigManager:
    def __init__(self):
        self.config = None
        self.data_load_config = None

    def load_config(self, config: dict):
        self.config = config

    def load_data_load_config(self, config: dict):
        self.data_load_config = config


config_manager = ConfigManager()
