import base64
from io import BytesIO
from typing import Dict, Any, List
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
import msgpack
import numpy as np
from PIL import Image
from loguru import logger


def convert_compressed_image(message):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    return np.array(Image.open(BytesIO(unpacked_message["Data"])))


def convert_component_observation(message, type):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    if type == "pose":
        pose = unpacked_message["MultibodyPose"]["Pose"]
        return np.array([
            pose["Position"]["X"], pose["Position"]["Y"], pose["Position"]["Z"],
            pose["Orientation"]["X"], pose["Orientation"]["Y"], pose["Orientation"]["Z"], pose["Orientation"]["W"]
        ])
    if type == "joint":
        return np.array([state_msg["Q"] for state_msg in unpacked_message["MultibodyState"]["States"]])
    if type == "ft":
        wrench = unpacked_message["ForceTorques"][0]["Wrench"]
        return np.array([wrench["Force"]["X"], wrench["Force"]["Y"], wrench["Force"]["Z"],
                         wrench["Torque"]["X"], wrench["Torque"]["Y"], wrench["Torque"]["Z"]])
    raise ValueError(f"type {type} not supported")


def convert_component_action(message, type):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    if type == "pose":
        pose = unpacked_message["PoseCommand"]["Pose"]
        return np.array([
            pose["Position"]["X"], pose["Position"]["Y"], pose["Position"]["Z"],
            pose["Orientation"]["X"], pose["Orientation"]["Y"], pose["Orientation"]["Z"], pose["Orientation"]["W"],
        ])
    if type == "joint":
        joint_commands = unpacked_message["JointCommands"]
        if isinstance(joint_commands, list):
            return np.array(unpacked_message["JointCommands"])

        return None
    raise ValueError(f"type {type} not supported")


def convert_timestamped_messages(messages, topic_type, topic_name):
    data = []
    type = "pose"
    if "/joint" in topic_name:
        type = "joint"
    if "/ft" in topic_name:
        type = "ft"

    for message in messages:
        converted = None
        if topic_type == "sensor_msgs/CompressedImage":
            converted = convert_compressed_image(message)
        if topic_type == "data_msgs/ComponentObservation":
            converted = convert_component_observation(message, type)
        if topic_type == "data_msgs/ComponentAction":
            converted = convert_component_action(message, type)
            if converted is not None and type == "joint":
                assert len(converted) == 1, f"data should len 1 {len(converted)}"

        if converted is not None:
            if topic_name == "left_wrist/joint/command":
                print(converted, converted is None)
            data.append(converted)

    if len(data) == 0:
        return None
    return np.stack(data, axis=0)


def get_topic_to_data(file_content: Dict[str, Any]):
    topic_to_data = {}
    for topic_content in file_content["topic_contents"]:
        topic_to_data[topic_content["name"]] = convert_timestamped_messages(
            topic_content["timestamped_messages"], topic_content["type"], topic_content["name"])
    return topic_to_data


def get_frame_from_file_content(file_content: Dict[str, Any], frame_structure: Dict[str, Any],
                                topic_names_and_count: Dict[str, Dict[str, Any]], event_detail: str):
    frame = {}
    valid = True
    error_list = []
    # Get frame data
    try:
        topic_to_data = get_topic_to_data(file_content)
        if file_content['successful'] is False:
            return None, False, None, f"File {file_content['key']} invalid, error_msg: {file_content['error_message']}"

        # Check topic data validity
        for topic_name in topic_names_and_count:
            # episode state is present in event_detail
            if topic_name == 'episode_state' and event_detail is None:
                valid = False
                error_list.append(f"Episode state is present in event_detail, but event_detail is None")
            elif topic_name == 'episode_state':
                topic_to_data[topic_name] = [event_detail] * topic_names_and_count[topic_name]['count']
            elif topic_name not in topic_to_data or topic_to_data[topic_name] is None:
                valid = False
                error_list.append(f"Topic {topic_name} should has data, but has no data")
            elif len(topic_to_data[topic_name]) < topic_names_and_count[topic_name]['count']:
                valid = False
                error_list.append(f"Topic {topic_name} should has {topic_names_and_count[topic_name]['count']}"
                                  f"samples, but has {len(topic_to_data[topic_name])}")
        for frame_key, frame_value in frame_structure.items():
            if len(frame_value["values"]) == 1:
                frame[frame_key] = topic_to_data[frame_value["values"][0]][:frame_value["count"]]
            elif len(frame_value["values"]) > 1:
                data = []
                for v in frame_value["values"]:
                    if topic_to_data[v] is not None:
                        data.append(topic_to_data[v][:frame_value["count"]])
                if len(data) == 0:
                    continue
                frame[frame_key] = np.concatenate(data, axis=1)
    except Exception as e:  # pylint: disable=broad-except
        trace = traceback.format_exc()
        error_list.append(f"Error getting frame from file content: {e}, file: {file_content['key']}, trace: {trace}")
        return frame, False, topic_to_data, "\n".join(error_list)
    if not valid:
        error_list.append(f"File {file_content['key']} is invalid")
    return frame, valid, topic_to_data, "\n".join(error_list)


def convert_response_to_frame(response: Dict[str, Any], frame_structure: Dict[str, Any],
                              topic_names_and_count: Dict[str, Dict[str, Any]], event_details: List[str]):
    file_contents = response.get("file_contents", [])
    if not file_contents:
        return []
    frames_info = []
    for idx, file_content in enumerate(file_contents):
        frame, valid, topic_to_data, error_str = get_frame_from_file_content(file_content, frame_structure,
                                                                             topic_names_and_count, event_details[idx] if event_details is not None else None)
        frames_info.append((frame, valid, topic_to_data, error_str))
    return frames_info


def convert_response_to_frame_parallel(response: Dict[str, Any], frame_structure: Dict[str, Any],
                                       topic_names_and_count: Dict[str, Dict[str, Any]], event_details: List[str]):
    file_contents = response.get("file_contents", [])
    if not file_contents:
        return []

    frames_info = []
    # Use ThreadPoolExecutor to process each file_content in parallel
    max_workers = min(len(file_contents), 32)  # Limit max workers to avoid too many threads
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_file_content = {
            executor.submit(
                get_frame_from_file_content,
                file_content, frame_structure, topic_names_and_count,
                event_details[idx] if event_details is not None else None
            ): (idx, file_content)
            for idx, file_content in enumerate(file_contents)
        }

        # Collect results in order
        results = {}
        for future in as_completed(future_to_file_content):
            file_idx, file_content = future_to_file_content[future]
            try:
                frame, valid, topic_to_data, error_str = future.result()
                results[file_idx] = (frame, valid, topic_to_data, error_str)
            except Exception as e:  # pylint: disable=broad-except
                logger.error(f"转换 file_content {file_idx+1} (key: {file_content.get('key', 'unknown')}) 失败: {e}")
                raise e

        # Sort results by original index to maintain order
        frames_info = [(results[idx][0], results[idx][1],
                        results[idx][2], results[idx][3]) for idx in sorted(results.keys())]

    return frames_info
