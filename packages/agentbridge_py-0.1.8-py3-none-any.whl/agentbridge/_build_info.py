GIT_HASH = "unknown"
