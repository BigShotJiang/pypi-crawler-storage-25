"""
GPT-based NLP feature extraction (130+ questions incl. CNN/ConvNet signals) + semantic dangers;
used by default from ``netgreener run`` / ``netgreener analyze`` when LLM credentials exist.

Uses the standard openai package (not Azure) with OPENAI_API_KEY env var.
Falls back to the repo's config.yml Azure credentials if the env var is absent.
Returns the 130+ feature dict from nlp_features_questions.json, keyed by feature name.
"""

import json
import re
from pathlib import Path
from typing import Any

_QUESTIONS_PATH = Path(__file__).parent / "_codeanalyzer" / "nlp_features_questions.json"

_MAX_CODE_CHARS = 12_000  # keep prompt under token limits


def _load_questions() -> dict[str, str]:
    try:
        return json.loads(_QUESTIONS_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        raise RuntimeError(f"Could not load NLP questions file: {e}") from e


def _build_prompt(source: str, questions: dict[str, str]) -> str:
    numbered = "\n".join(f"{i + 1}. {q}" for i, q in enumerate(questions.values()) if q)
    return (
        "Analyze this Python code and answer the following questions. "
        "Respond ONLY with a valid JSON object where keys are question numbers "
        "(1, 2, 3, ...) and values are your answers.\n\n"
        f"CODE:\n{source[:_MAX_CODE_CHARS]}\n\n"
        f"QUESTIONS:\n{numbered}\n\n"
        "Respond with JSON only, no other text."
    )


def _parse_response(raw: str, questions: dict[str, str]) -> dict:
    cleaned = raw.replace("```json", "").replace("```", "").strip()
    m = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if m:
        cleaned = m.group(0)
    numbered_answers: dict = json.loads(cleaned)

    # Map numbered keys → feature names
    feature_names = list(questions.keys())
    result: dict = {}
    for str_idx, value in numbered_answers.items():
        try:
            idx = int(str_idx) - 1
            if 0 <= idx < len(feature_names):
                result[feature_names[idx]] = value
        except (ValueError, IndexError):
            pass
    return result


def _extract_json_object(raw: str) -> dict[str, Any]:
    cleaned = raw.replace("```json", "").replace("```", "").strip()
    m = re.search(r"\{[\s\S]*\}\s*$", cleaned)
    if m:
        cleaned = m.group(0)
    return json.loads(cleaned)


def _get_server_azure_credentials() -> dict | None:
    """Fetch AzureOpenAI credentials from the NetGreener API server."""
    try:
        from .api_client import NetGreenerClient

        client = NetGreenerClient.from_credentials()
        return client.get_llm_config()
    except Exception:
        return None


def _chat_completion(
    messages: list[dict[str, str]],
    *,
    max_tokens: int = 4000,
    tier: str = "large",
) -> str:
    """Run one chat completion, routing to the configured LLM provider.

    Priority:
      1. User BYOK: large + mini profiles (NETGREENER_LLM_* and NETGREENER_LLM_MINI_*)
        ; ``tier`` selects ``"large"`` (heavy NLP) or ``"mini"`` (semantic dangers).
      2. Server-provided Azure OpenAI credentials (requires netgreener login)
    """
    from .config import get_byok_llm_config_error, get_user_llm_profile

    err = get_byok_llm_config_error()
    if err:
        raise RuntimeError(err)

    large_u = get_user_llm_profile("large")
    mini_u = get_user_llm_profile("mini")
    if large_u and mini_u:
        cfg = mini_u if tier == "mini" else large_u
        return _chat_completion_user(messages, cfg, max_tokens=max_tokens)

    # Fall back to server Azure credentials
    creds = _get_server_azure_credentials()
    if not creds or not creds.get("api_key"):
        raise RuntimeError(
            "NLP analysis requires credentials. Run: netgreener login, "
            "or set both BYOK profiles (NETGREENER_LLM_* and NETGREENER_LLM_MINI_*)."
        )
    from openai import AzureOpenAI

    az_client = AzureOpenAI(
        api_key=creds["api_key"],
        azure_endpoint=creds["azure_endpoint"],
        api_version=creds["api_version"],
        timeout=60,
    )
    response = az_client.chat.completions.create(
        model=creds["model"],
        messages=messages,
        temperature=0,
        max_tokens=max_tokens,
    )
    return response.choices[0].message.content or ""


def _chat_completion_user(
    messages: list[dict[str, str]],
    cfg: dict,
    *,
    max_tokens: int = 4000,
) -> str:
    """Dispatch to the correct LLM client based on cfg['provider']."""
    provider = cfg["provider"].lower()
    key = cfg.get("key", "")
    endpoint = cfg.get("endpoint", "")
    model = cfg["model"]

    if provider == "azure_openai":
        if not endpoint:
            raise RuntimeError(
                "azure_openai provider requires NETGREENER_LLM_ENDPOINT (Azure endpoint URL)."
            )
        from openai import AzureOpenAI

        client = AzureOpenAI(
            api_key=key,
            azure_endpoint=endpoint,
            api_version="2024-12-01-preview",
            timeout=60,
        )
        response = client.chat.completions.create(
            model=model, messages=messages, temperature=0, max_tokens=max_tokens
        )
        return response.choices[0].message.content or ""

    if provider in ("openai", "ollama", "custom"):
        from openai import OpenAI

        kwargs: dict = {"api_key": key or "ollama", "timeout": 60}
        if endpoint:
            kwargs["base_url"] = endpoint
        client = OpenAI(**kwargs)
        response = client.chat.completions.create(
            model=model, messages=messages, temperature=0, max_tokens=max_tokens
        )
        return response.choices[0].message.content or ""

    if provider == "anthropic":
        try:
            import anthropic
        except ImportError as exc:
            raise RuntimeError(
                "anthropic provider requires the 'anthropic' package. " "Run: pip install anthropic"
            ) from exc
        client = anthropic.Anthropic(api_key=key, timeout=60)
        system_parts = [m["content"] for m in messages if m.get("role") == "system"]
        user_messages = [m for m in messages if m.get("role") != "system"]
        resp = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system="\n\n".join(system_parts) if system_parts else anthropic.NOT_GIVEN,
            messages=user_messages,
        )
        return resp.content[0].text

    raise RuntimeError(
        f"Unknown LLM provider '{provider}'. "
        f"Supported: azure_openai, openai, anthropic, ollama, custom."
    )


def run_nlp_analysis(script_path: str) -> dict:
    """
    Run GPT analysis on the given script via AzureOpenAI.
    Credentials are fetched from the NetGreener API (requires login).
    Falls back to OPENAI_API_KEY env var if set.
    Returns feature dict on success, {"error": "..."} on failure.
    """
    source = Path(script_path).read_text(encoding="utf-8", errors="replace")
    questions = _load_questions()
    prompt = _build_prompt(source, questions)

    try:
        raw = _chat_completion([{"role": "user", "content": prompt}], max_tokens=4000, tier="large")
    except ImportError:
        return {"error": "openai package not installed. Run: pip install openai"}
    except RuntimeError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"OpenAI call failed: {e}"}

    try:
        return _parse_response(raw, questions)
    except Exception as e:
        return {"error": f"Failed to parse GPT response: {e}"}


def run_combined_llm_analysis(
    *,
    script_path: str,
    language: str = "python",
    framework: str | None = None,
    ast_findings: list[dict[str, Any]] | None = None,
    file_features: dict[str, Any] | None = None,
    project_context_summaries: list[str] | None = None,
) -> dict[str, Any]:
    """
    Extract NLP features and semantic dangers together for one file context.
    Returns:
      {
        "nlp_features": dict,
        "semantic_dangers": dict,
        "errors": list[str]
      }
    """
    result: dict[str, Any] = {"nlp_features": {}, "semantic_dangers": {}, "errors": []}
    try:
        source = Path(script_path).read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        result["errors"].append(f"Could not read file {script_path}: {e}")
        return result

    # NLP features branch
    questions = _load_questions()
    nlp_prompt = _build_prompt(source, questions)
    try:
        raw_nlp = _chat_completion(
            [{"role": "user", "content": nlp_prompt}], max_tokens=4000, tier="large"
        )
        result["nlp_features"] = _parse_response(raw_nlp, questions)
    except ImportError:
        result["errors"].append("openai package not installed. Run: pip install openai")
    except Exception as e:
        result["errors"].append(f"NLP analysis failed: {e}")

    # Semantic dangers branch
    try:
        from .semantic_dangers import (
            ast_findings_from_detect_code_patterns,
            build_semantic_danger_user_payload,
            compose_chat_messages,
            enrich_payload_from_analyze_file_features,
            parse_semantic_danger_response,
        )

        findings = ast_findings or []
        if not findings and file_features:
            findings = ast_findings_from_detect_code_patterns(
                file_features, Path(script_path).name, project_id=0
            )

        sem_payload = build_semantic_danger_user_payload(
            source_code=source,
            language=language,
            framework=framework,
            file_path=Path(script_path).name,
            ast_findings=findings,
            ast_findings_source="netgreener_cli_metrics",
            project_context_summaries=project_context_summaries,
        )
        if file_features:
            sem_payload = enrich_payload_from_analyze_file_features(sem_payload, file_features)

        sem_messages = compose_chat_messages(sem_payload)
        raw_sem = _chat_completion(sem_messages, max_tokens=4000, tier="mini")
        result["semantic_dangers"] = parse_semantic_danger_response(raw_sem)
    except Exception as e:
        result["errors"].append(f"Semantic danger analysis failed: {e}")

    return result
