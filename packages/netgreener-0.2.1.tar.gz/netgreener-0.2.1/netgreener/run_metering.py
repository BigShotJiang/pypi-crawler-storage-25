"""
Shared hardware snapshot + TDP-based energy model for CLI runs (published wheel).

The IDE ships a **mirror** of this file at ``NetGreenerIDE/run_metering.py`` so the
desktop package stays small (no bundled ``netgreener_cli``). When changing formulas
or defaults, update **both** files together.

Energy model (v1)
-----------------
  E_total = E_cpu + E_gpu + E_ram + E_io

  E_cpu  = (TDP_cpu_W  × cpu_util_fraction  × duration_s) / 3_600_000
  E_gpu  = (TDP_gpu_W  × gpu_util_fraction  × duration_s) / 3_600_000
  E_ram  = (ram_gb_avg × RAM_POWER_W_PER_GB × duration_s) / 3_600_000
  E_io   =  io_total_gb × IO_ENERGY_KWH_PER_GB

cpu_util_fraction is normalized to the CPU *package* level (0–1):
  psutil cpu_percent is divided by logical cpu_count before being passed here,
  so 1.0 means the whole CPU package is running at TDP.
"""

from __future__ import annotations

import json
import platform
import subprocess
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------------------

CO2_KG_PER_KWH = 0.276  # EU average (same as legacy CLI constants)
DEFAULT_CPU_TDP_WATTS = 65.0
DEFAULT_GPU_TDP_WATTS = 250.0
RAM_POWER_W_PER_GB = 3.0  # ~3 W per GB of active RAM (industry heuristic)
IO_ENERGY_KWH_PER_GB = 0.00005  # 0.05 Wh per GB transferred (HDD/SSD blended)

# ---------------------------------------------------------------------------
# TDP lookup tables
# ---------------------------------------------------------------------------

_CPU_TDP_HINTS: List[Tuple[str, float]] = [
    ("Ryzen 9", 105.0),
    ("Ryzen 7", 65.0),
    ("Ryzen 5", 65.0),
    ("Xeon", 150.0),
    ("Intel Core Ultra 9", 65.0),
    ("Intel Core i9", 125.0),
    ("Intel Core i7", 65.0),
    ("Intel Core i5", 65.0),
    ("Apple M3 Max", 80.0),
    ("Apple M3 Pro", 50.0),
    ("Apple M3", 30.0),
    ("Apple M2", 30.0),
    ("Apple M1", 25.0),
]

_GPU_TDP_HINTS: List[Tuple[str, float]] = [
    ("RTX 4090", 450.0),
    ("RTX 4080", 320.0),
    ("RTX 4070", 200.0),
    ("RTX 4060", 115.0),
    ("RTX 3090", 350.0),
    ("RTX 3080", 320.0),
    ("RTX 3070", 220.0),
    ("RTX 3060", 170.0),
    ("A100", 400.0),
    ("H100", 700.0),
    ("V100", 300.0),
    ("TESLA T4", 70.0),
    ("T4", 70.0),
    # AMD
    ("RX 7900 XTX", 355.0),
    ("RX 7900 XT", 315.0),
    ("RX 7800 XT", 263.0),
    ("RX 6900 XT", 300.0),
    ("RX 6800 XT", 300.0),
    ("MI300X", 750.0),
    ("MI250X", 560.0),
    ("MI100", 300.0),
    ("RX 580", 185.0),
]


# ---------------------------------------------------------------------------
# Hardware snapshot
# ---------------------------------------------------------------------------


def _amd_gpu_info() -> List[Dict[str, Any]]:
    """
    Best-effort AMD GPU inventory via rocm-smi.
    Returns list of {name, memory_total_mib} dicts (empty list on failure).
    """
    try:
        result = subprocess.run(
            ["rocm-smi", "--showproductname", "--json"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []
        data = json.loads(result.stdout)
        gpus: List[Dict[str, Any]] = []
        for card_data in data.values():
            if not isinstance(card_data, dict):
                continue
            name = (
                card_data.get("Card Series")
                or card_data.get("Card Model")
                or card_data.get("Card SKU")
                or "AMD GPU"
            )
            gpus.append({"name": str(name), "memory_total_mib": None})
        return gpus
    except Exception:
        return []


def collect_hardware_snapshot() -> Dict[str, Any]:
    """
    Best-effort host inventory (no admin rights). Safe to call at run start/end.
    Probes NVIDIA via pynvml, then AMD via rocm-smi; Apple Silicon is a known gap.
    """
    snap: Dict[str, Any] = {
        "schema_version": 1,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "",
        "python_version": platform.python_version(),
    }

    # CPU model
    brand: Optional[str] = None
    try:
        import cpuinfo  # type: ignore[import-untyped]

        info = cpuinfo.get_cpu_info()
        brand = info.get("brand_raw") or info.get("arch")
    except Exception:
        pass
    if not brand and snap["processor"]:
        brand = str(snap["processor"])
    snap["cpu_model"] = brand or "unknown"

    # RAM
    try:
        import psutil

        snap["ram_total_gb"] = round(psutil.virtual_memory().total / (1024**3), 2)
    except Exception:
        snap["ram_total_gb"] = None

    # GPU; NVIDIA first, AMD fallback
    gpus: List[Dict[str, Any]] = []
    gpu_backend = "none"
    try:
        import pynvml

        pynvml.nvmlInit()
        n = pynvml.nvmlDeviceGetCount()
        for i in range(n):
            h = pynvml.nvmlDeviceGetHandleByIndex(i)
            raw = pynvml.nvmlDeviceGetName(h)
            name = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else str(raw)
            mem_mib: Optional[int] = None
            try:
                mem_mib = int(pynvml.nvmlDeviceGetMemoryInfo(h).total // (1024**2))
            except Exception:
                pass
            gpus.append({"name": name, "memory_total_mib": mem_mib})
        try:
            pynvml.nvmlShutdown()
        except Exception:
            pass
        if gpus:
            gpu_backend = "nvidia"
    except Exception:
        pass

    if not gpus:
        gpus = _amd_gpu_info()
        if gpus:
            gpu_backend = "amd"

    snap["gpus"] = gpus
    snap["num_gpus_detected"] = len(gpus)
    snap["gpu_backend"] = gpu_backend
    return snap


# ---------------------------------------------------------------------------
# TDP resolution
# ---------------------------------------------------------------------------


def resolve_tdp_watts(snap: Dict[str, Any]) -> Tuple[float, float]:
    """Return (cpu_tdp_w, gpu_tdp_w) using defaults + optional name hints."""
    cpu_tdp = DEFAULT_CPU_TDP_WATTS
    gpu_tdp = DEFAULT_GPU_TDP_WATTS
    cpu_model = str(snap.get("cpu_model") or "").upper()
    for needle, w in _CPU_TDP_HINTS:
        if needle.upper() in cpu_model:
            cpu_tdp = w
            break
    gpus = snap.get("gpus") or []
    if isinstance(gpus, list) and gpus:
        gname = str((gpus[0] or {}).get("name") or "").upper()
        for needle, w in _GPU_TDP_HINTS:
            if needle.upper() in gname:
                gpu_tdp = w
                break
    return float(cpu_tdp), float(gpu_tdp)


# ---------------------------------------------------------------------------
# Energy formula (v1)
# ---------------------------------------------------------------------------


def energy_kwh_tdp_utilization(
    cpu_avg_percent: float,  # package-normalized [0, 100]; divide raw psutil by cpu_count first
    gpu_avg_percent: float,
    duration_seconds: float,
    cpu_tdp_watts: Optional[float] = None,
    gpu_tdp_watts: Optional[float] = None,
    ram_gb_avg: float = 0.0,
    io_bytes_total: int = 0,
) -> float:
    """
    Total energy = CPU + GPU + RAM + IO contributions.

    CPU/GPU: TDP × utilization_fraction × duration
    RAM:     ram_gb_avg × 3 W/GB × duration
    IO:      total_gb_transferred × 0.00005 kWh/GB
    """
    cpu_tdp = float(cpu_tdp_watts if cpu_tdp_watts is not None else DEFAULT_CPU_TDP_WATTS)
    gpu_tdp = float(gpu_tdp_watts if gpu_tdp_watts is not None else DEFAULT_GPU_TDP_WATTS)
    duration = max(0.0, float(duration_seconds))
    cpu_pct = max(0.0, min(100.0, float(cpu_avg_percent)))
    gpu_pct = max(0.0, min(100.0, float(gpu_avg_percent)))
    ram_gb = max(0.0, float(ram_gb_avg))
    io_gb = max(0.0, int(io_bytes_total)) / (1024**3)

    cpu_kwh = (cpu_tdp * (cpu_pct / 100.0) * duration) / 3_600_000
    gpu_kwh = (gpu_tdp * (gpu_pct / 100.0) * duration) / 3_600_000
    ram_kwh = (RAM_POWER_W_PER_GB * ram_gb * duration) / 3_600_000
    io_kwh = io_gb * IO_ENERGY_KWH_PER_GB

    return round(cpu_kwh + gpu_kwh + ram_kwh + io_kwh, 6)
