"""
Headless code analysis; wraps CodeAnalyzer without any PyQt5 dependency.
Extracts AST features, Halstead metrics, raw Radon metrics, library domains,
and derives resource-risk Finding records for the supervisor dashboard.
"""

import re
from pathlib import Path
from typing import Any

_LIBRARY_DOMAINS: dict[str, str] = {
    # Computer vision
    "cv2": "computer_vision",
    "PIL": "computer_vision",
    "Pillow": "computer_vision",
    "skimage": "computer_vision",
    "torchvision": "computer_vision",
    "imageio": "computer_vision",
    "albumentations": "computer_vision",
    # Deep learning
    "tensorflow": "deep_learning",
    "tf": "deep_learning",
    "keras": "deep_learning",
    "torch": "deep_learning",
    "jax": "deep_learning",
    "flax": "deep_learning",
    "paddle": "deep_learning",
    "mxnet": "deep_learning",
    "fastai": "deep_learning",
    "lightning": "deep_learning",
    "pytorch_lightning": "deep_learning",
    # Classical ML
    "sklearn": "classical_ml",
    "xgboost": "classical_ml",
    "lightgbm": "classical_ml",
    "catboost": "classical_ml",
    "statsmodels": "classical_ml",
    # NLP
    "transformers": "nlp",
    "spacy": "nlp",
    "nltk": "nlp",
    "gensim": "nlp",
    "sentence_transformers": "nlp",
    # Data
    "pandas": "data",
    "numpy": "data",
    "scipy": "data",
    "polars": "data",
    "pyarrow": "data",
    # Visualization
    "matplotlib": "visualization",
    "seaborn": "visualization",
    "plotly": "visualization",
}

_SUSPECT_SECRET_NAME_RE = re.compile(
    r"(secret|api[_-]?key|access[_-]?key|private[_-]?key|token|password|passwd|credential)",
    re.IGNORECASE,
)
_PLACEHOLDER_SECRET_VALUE_RE = re.compile(
    r"^(example|sample|dummy|test|changeme|your[_-]?key|xxx+|<.*>)$",
    re.IGNORECASE,
)


def _detect_domains(imports_detail: list[tuple]) -> list[str]:
    domains: set[str] = set()
    for module, _ in imports_detail:
        if module:
            root = module.split(".")[0]
            if domain := _LIBRARY_DOMAINS.get(root):
                domains.add(domain)
    return sorted(domains)


def _scan_hardcoded_secret_candidates(source_code: str) -> tuple[int, list[str]]:
    """
    Detect likely hardcoded secret assignments from source text.
    Conservative heuristic: suspicious variable name + non-trivial string literal.
    """
    count = 0
    refs: list[str] = []
    assign_re = re.compile(
        r"""^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(['"])([^'"]+)\2""",
        re.MULTILINE,
    )
    for m in assign_re.finditer(source_code):
        name = m.group(1)
        value = m.group(3).strip()
        if not _SUSPECT_SECRET_NAME_RE.search(name):
            continue
        if len(value) < 8:
            continue
        if _PLACEHOLDER_SECRET_VALUE_RE.match(value):
            continue
        count += 1
        refs.append(name)
    # Keep payload small and deterministic.
    return count, refs[:5]


def _safe_halstead(h) -> dict[str, float]:
    """Extract scalar Halstead fields defensively; radon's return type varies by version."""
    try:
        # h_visit may return a namedtuple or an object with a .total attribute
        src = h.total if hasattr(h, "total") else h
        return {
            "halstead_vocabulary": int(getattr(src, "vocabulary", 0)),
            "halstead_length": int(getattr(src, "length", 0)),
            "halstead_volume": round(float(getattr(src, "volume", 0.0)), 2),
            "halstead_difficulty": round(float(getattr(src, "difficulty", 0.0)), 2),
            "halstead_effort": round(float(getattr(src, "effort", 0.0)), 2),
            "halstead_bugs": round(float(getattr(src, "bugs", 0.0)), 4),
        }
    except Exception:
        return {
            k: 0
            for k in (
                "halstead_vocabulary",
                "halstead_length",
                "halstead_volume",
                "halstead_difficulty",
                "halstead_effort",
                "halstead_bugs",
            )
        }


def analyze_file(source_code: str) -> dict[str, Any]:
    """
    Run full CodeAnalyzer pipeline on a source string.
    Returns a flat dict of 30+ features including Halstead, Radon raw, and library domains.
    Returns a dict with an 'error' key on failure.
    """
    try:
        from netgreener._codeanalyzer.ast_features.ast_base_analysis import AstBaseAnalyzer
        from netgreener._codeanalyzer.ast_features.node_counter import NodeCounter
        from netgreener._codeanalyzer.ast_features.node_detail_extractor import NodeDetailExtractor
        from netgreener._codeanalyzer.ast_features.metrics_calculator import MetricsCalculator
    except ImportError as e:
        return {"error": f"CodeAnalyzer not available: {e}"}

    try:
        base = AstBaseAnalyzer(source_code)
        counter = NodeCounter(base)
        detail = NodeDetailExtractor(base)
        metrics = MetricsCalculator(base)

        imports_detail = detail.import_nodes_detail()
        _, comment_count = base.extract_comments()
        node_count = counter.count_node()
        mi_result = metrics.calculate_maintainability_index_rank()

        # Cyclomatic complexity; returns list of (name, cc, rank) per function
        cc_list = metrics.calculate_cyclomatic_complexity()
        cc_values = [c for _, c, _ in cc_list] if cc_list else []
        avg_cc = sum(cc_values) / len(cc_values) if cc_values else 0.0
        max_cc = max(cc_values, default=0)

        # Halstead metrics
        halstead = _safe_halstead(metrics.calculate_halstead_metrics())

        # Raw Radon metrics (LLOC, SLOC, blank, multi-line strings)
        raw = metrics.calculate_raw_metrics()

        secret_count, secret_refs = _scan_hardcoded_secret_candidates(source_code)

        features: dict[str, Any] = {
            # AST node counts
            "lines_of_code": counter.count_lines_of_code(),
            "number_of_tokens": counter.count_tokens(),
            "depth_of_ast": counter.depth_of_ast(),
            "number_of_nodes": node_count,
            "number_of_edges": node_count - 1,
            "number_of_imports": counter.count_imports(),
            "imports_detail": imports_detail,
            "count_class_nodes": counter.count_class_nodes(),
            "count_function_nodes": counter.count_function_nodes(),
            "count_call_function_nodes": counter.count_call_function_nodes(),
            "count_control_flow_nodes": counter.count_control_flow_nodes(),
            "count_exception_handling_nodes": counter.count_exception_handling_nodes(),
            "count_expression_nodes": counter.count_expression_nodes(),
            "count_assignment_nodes": counter.count_assignment_nodes(),
            "count_binary_operations": counter.count_binary_operation_nodes(),
            "count_unary_operations": counter.count_unary_operation_nodes(),
            "count_lambda_function_nodes": counter.count_lambda_function_nodes(),
            "comments_count": comment_count,
            # Complexity / quality
            "avg_cyclomatic_complexity": round(avg_cc, 2),
            "max_cyclomatic_complexity": max_cc,
            "maintainability_index": mi_result[0],
            "maintainability_index_rank": mi_result[1],
            # Radon raw
            "lloc": raw.lloc,
            "sloc": raw.sloc,
            "blank_lines": raw.blank,
            "multi_line_strings": raw.multi,
            # Halstead
            **halstead,
            # Library domains
            "library_domains": _detect_domains(imports_detail),
            # Security heuristics
            "hardcoded_secret_candidate_count": secret_count,
            "hardcoded_secret_candidate_refs": secret_refs,
            # Raw source; sent to the server-side analyze endpoint for pattern detection
            "_source_code": source_code,
        }
        return features

    except SyntaxError as e:
        return {"error": f"SyntaxError: {e}"}
    except Exception as e:
        return {"error": str(e)}


def analyze_project(project_dir: str) -> dict[str, Any]:
    """
    Analyze all .py files in a project directory.
    Returns aggregated features, per-file feature cache, and errors.
    """
    root = Path(project_dir)
    _SKIP_DIRS = {
        ".venv",
        "venv",
        "env",
        ".env",
        "site-packages",
        "__pycache__",
        "node_modules",
        ".git",
        "dist",
        "build",
        ".eggs",
    }

    def _collect_py_files(directory: Path) -> list[Path]:
        files: list[Path] = []
        for entry in directory.iterdir():
            if entry.is_dir():
                if entry.name in _SKIP_DIRS or entry.name.endswith(".egg-info"):
                    continue
                files.extend(_collect_py_files(entry))
            elif entry.suffix == ".py":
                files.append(entry)
        return files

    py_files = _collect_py_files(root)

    all_domains: set[str] = set()
    total_loc = 0
    total_imports = 0
    total_tokens = 0
    total_nodes = 0
    total_class_nodes = 0
    total_function_nodes = 0
    total_call_function_nodes = 0
    total_control_flow_nodes = 0
    total_exception_handling_nodes = 0
    total_expression_nodes = 0
    total_assignment_nodes = 0
    total_binary_operations = 0
    total_unary_operations = 0
    total_lambda_function_nodes = 0
    total_comments = 0
    total_lloc = 0
    total_sloc = 0
    total_blank_lines = 0
    total_multi_line_strings = 0
    total_hardcoded_secret_candidates = 0
    total_avg_cc = 0.0
    total_max_cc = 0.0
    total_mi = 0.0
    total_depth_of_ast = 0.0
    total_halstead_volume = 0.0
    total_halstead_difficulty = 0.0
    total_halstead_bugs = 0.0
    total_halstead_vocabulary = 0.0
    total_halstead_length = 0
    total_halstead_effort = 0.0
    file_count = 0
    errors: list[str] = []
    per_file: list[dict] = []  # {"rel_path": str, "features": dict}

    for path in py_files:
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        result = analyze_file(source)
        if "error" in result:
            errors.append(f"{path.name}: {result['error']}")
            continue
        file_count += 1
        total_loc += result.get("lines_of_code", 0)
        total_imports += result.get("number_of_imports", 0)
        total_tokens += result.get("number_of_tokens", 0)
        total_nodes += result.get("number_of_nodes", 0)
        total_class_nodes += result.get("count_class_nodes", 0)
        total_function_nodes += result.get("count_function_nodes", 0)
        total_call_function_nodes += result.get("count_call_function_nodes", 0)
        total_control_flow_nodes += result.get("count_control_flow_nodes", 0)
        total_exception_handling_nodes += result.get("count_exception_handling_nodes", 0)
        total_expression_nodes += result.get("count_expression_nodes", 0)
        total_assignment_nodes += result.get("count_assignment_nodes", 0)
        total_binary_operations += result.get("count_binary_operations", 0)
        total_unary_operations += result.get("count_unary_operations", 0)
        total_lambda_function_nodes += result.get("count_lambda_function_nodes", 0)
        total_comments += result.get("comments_count", 0)
        total_lloc += result.get("lloc", 0)
        total_sloc += result.get("sloc", 0)
        total_blank_lines += result.get("blank_lines", 0)
        total_multi_line_strings += result.get("multi_line_strings", 0)
        total_hardcoded_secret_candidates += result.get("hardcoded_secret_candidate_count", 0)
        total_avg_cc += result.get("avg_cyclomatic_complexity", 0.0)
        total_max_cc += result.get("max_cyclomatic_complexity", 0.0)
        total_mi += result.get("maintainability_index", 0.0)
        total_depth_of_ast += result.get("depth_of_ast", 0.0)
        total_halstead_volume += result.get("halstead_volume", 0.0)
        total_halstead_difficulty += result.get("halstead_difficulty", 0.0)
        total_halstead_bugs += result.get("halstead_bugs", 0.0)
        total_halstead_vocabulary += result.get("halstead_vocabulary", 0.0)
        total_halstead_length += result.get("halstead_length", 0)
        total_halstead_effort += result.get("halstead_effort", 0.0)
        all_domains.update(result.get("library_domains", []))
        per_file.append({"rel_path": str(path.relative_to(root)), "features": result})

    def _avg(total: float) -> float:
        return round(total / file_count, 2) if file_count else 0.0

    return {
        "file_count": file_count,
        # Line / token counts
        "total_lines_of_code": total_loc,
        "total_tokens": total_tokens,
        "total_lloc": total_lloc,
        "total_sloc": total_sloc,
        "total_blank_lines": total_blank_lines,
        "total_multi_line_strings": total_multi_line_strings,
        # Import / library
        "total_imports": total_imports,
        "library_domains": sorted(all_domains),
        # AST structure
        "total_nodes": total_nodes,
        "avg_depth_of_ast": _avg(total_depth_of_ast),
        # Node-type counts
        "total_class_nodes": total_class_nodes,
        "total_function_nodes": total_function_nodes,
        "total_call_function_nodes": total_call_function_nodes,
        "total_control_flow_nodes": total_control_flow_nodes,
        "total_exception_handling_nodes": total_exception_handling_nodes,
        "total_expression_nodes": total_expression_nodes,
        "total_assignment_nodes": total_assignment_nodes,
        "total_binary_operations": total_binary_operations,
        "total_unary_operations": total_unary_operations,
        "total_lambda_function_nodes": total_lambda_function_nodes,
        # Comments
        "total_comments": total_comments,
        # Complexity / quality
        "avg_cyclomatic_complexity": _avg(total_avg_cc),
        "avg_max_cyclomatic_complexity": _avg(total_max_cc),
        "avg_maintainability_index": _avg(total_mi),
        # Halstead
        "avg_halstead_vocabulary": _avg(total_halstead_vocabulary),
        "total_halstead_length": total_halstead_length,
        "avg_halstead_volume": _avg(total_halstead_volume),
        "avg_halstead_difficulty": _avg(total_halstead_difficulty),
        "avg_halstead_effort": _avg(total_halstead_effort),
        "total_halstead_bugs": round(total_halstead_bugs, 3),
        # Security
        "total_hardcoded_secret_candidates": total_hardcoded_secret_candidates,
        # Internal; not sent to surrogate API
        "per_file": per_file,
        "errors": errors,
    }
