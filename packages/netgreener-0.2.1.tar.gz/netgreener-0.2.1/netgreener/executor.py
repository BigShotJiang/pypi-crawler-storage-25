"""
Runs a user script as a subprocess, streams output to the real terminal,
and collects CPU/RAM/GPU/IO metrics throughout execution.

Metrics model
-------------
- CPU  : process + recursive children, normalized to package-level [0, 100%]
         (psutil returns multi-core %, so we divide by logical cpu_count so
          that 100% always means the full CPU TDP is being consumed).
- RAM  : process + children RSS, tracked as both peak and running average
         (average is used for energy; peak is reported for context).
- GPU  : NVIDIA via pynvml first; AMD via rocm-smi subprocess fallback.
         Apple Silicon is a known gap (powermetrics requires sudo).
- IO   : cumulative process io_counters delta (read + write bytes).
         Used only for energy; not uploaded as a separate KPI yet.
"""

import json
import os
import subprocess
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Tuple

import psutil

from .run_metering import (
    collect_hardware_snapshot,
    energy_kwh_tdp_utilization,
    resolve_tdp_watts,
)

_CPU_COUNT: int = psutil.cpu_count(logical=True) or 1


@dataclass
class RunResult:
    exit_code: int
    duration_seconds: float
    cpu_percent_avg: float  # package-level [0, 100]
    ram_gb_peak: float
    ram_gb_avg: float  # used for energy calculation
    gpu_utilization_avg: float
    gpu_memory_peak_gb: float
    io_bytes_total: int  # read + write bytes over the run
    energy_kwh: float
    interrupted: bool = False
    accuracy_metrics: dict = field(default_factory=dict)
    hardware_snapshot: Dict[str, Any] = field(default_factory=dict)
    stdout_tail: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# GPU sampling helpers
# ---------------------------------------------------------------------------


def _sample_nvidia() -> Tuple[float, float] | None:
    """Return (util_pct, mem_gb) averaged across all NVIDIA GPUs, or None."""
    try:
        import pynvml

        pynvml.nvmlInit()
        n = pynvml.nvmlDeviceGetCount()
        if n == 0:
            return None
        util = (
            sum(
                pynvml.nvmlDeviceGetUtilizationRates(pynvml.nvmlDeviceGetHandleByIndex(i)).gpu
                for i in range(n)
            )
            / n
        )
        mem_gb = (
            sum(
                pynvml.nvmlDeviceGetMemoryInfo(pynvml.nvmlDeviceGetHandleByIndex(i)).used
                for i in range(n)
            )
            / n
            / (1024**3)
        )
        return (util, mem_gb)
    except Exception:
        return None


def _sample_amd() -> Tuple[float, float] | None:
    """
    Return (util_pct, 0.0) from AMD rocm-smi, or None.
    rocm-smi --showuse --json emits {"card0": {"GPU use (%)": "42"}, ...}
    Memory-used is not in --showuse; we return 0.0 for mem_gb.
    """
    try:
        proc = subprocess.run(
            ["rocm-smi", "--showuse", "--json"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if proc.returncode != 0:
            return None
        data = json.loads(proc.stdout)
        utils: List[float] = []
        for card_data in data.values():
            if isinstance(card_data, dict):
                raw = card_data.get("GPU use (%)") or card_data.get("GPU Use (%)")
                if raw is not None:
                    utils.append(float(str(raw).strip().rstrip("%")))
        if not utils:
            return None
        return (sum(utils) / len(utils), 0.0)
    except Exception:
        return None


def _collect_gpu_metrics(
    samples: list,
    stop_event: threading.Event,
    backend: str,  # "nvidia" | "amd" | "none"
) -> None:
    """Append (util_pct, mem_gb) tuples to samples every second."""
    if backend == "none":
        return

    sampler = _sample_nvidia if backend == "nvidia" else _sample_amd

    # Prime NVML (first call initialises driver counters)
    if backend == "nvidia":
        try:
            import pynvml

            pynvml.nvmlInit()
        except Exception:
            return

    while not stop_event.is_set():
        result = sampler()
        if result is not None:
            samples.append(result)
        stop_event.wait(1.0)

    if backend == "nvidia":
        try:
            import pynvml

            pynvml.nvmlShutdown()
        except Exception:
            pass


def _detect_gpu_backend() -> str:
    """Probe available GPU libraries and return 'nvidia', 'amd', or 'none'."""
    if _sample_nvidia() is not None:
        return "nvidia"
    if _sample_amd() is not None:
        return "amd"
    return "none"


# ---------------------------------------------------------------------------
# Main executor
# ---------------------------------------------------------------------------


def run_script(
    script_path: str,
    project_dir: str,
    metrics_port: int | None = None,
    extra_env: dict | None = None,
) -> RunResult:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    if metrics_port:
        env["NETGREENER_METRICS_PORT"] = str(metrics_port)
    if extra_env:
        env.update(extra_env)

    proc = subprocess.Popen(
        [sys.executable, str(Path(script_path).resolve())],
        cwd=str(Path(project_dir).resolve()),
        env=env,
        stdout=subprocess.PIPE,
        stderr=sys.stderr,
    )

    hardware_snapshot = collect_hardware_snapshot()
    gpu_backend = _detect_gpu_backend()

    # Tee stdout: stream to terminal while keeping the last 500 lines for accuracy extraction.
    _stdout_buf: deque[str] = deque(maxlen=500)

    def _tee_stdout() -> None:
        assert proc.stdout is not None
        for raw in proc.stdout:
            line = raw.decode("utf-8", errors="replace")
            sys.stdout.write(line)
            sys.stdout.flush()
            _stdout_buf.append(line.rstrip("\n"))

    tee_thread = threading.Thread(target=_tee_stdout, daemon=True)
    tee_thread.start()

    # Running accumulators; safe for multi-hour training runs.
    cpu_sum = 0.0
    cpu_count = 0
    ram_peak = 0.0
    ram_sum = 0.0
    ram_count = 0
    io_bytes_start: int | None = None
    io_bytes_end: int = 0
    gpu_samples: list[tuple[float, float]] = []
    stop_event = threading.Event()

    def _collect_cpu_ram() -> None:
        nonlocal cpu_sum, cpu_count, ram_peak, ram_sum, ram_count
        nonlocal io_bytes_start, io_bytes_end
        try:
            ps = psutil.Process(proc.pid)
        except psutil.NoSuchProcess:
            return
        # Prime the counter; first call always returns 0.0.
        ps.cpu_percent(interval=None)
        stop_event.wait(1.0)

        while not stop_event.is_set():
            try:
                # --- CPU: main process + recursive children ---
                raw_cpu = ps.cpu_percent(interval=None)
                try:
                    children = ps.children(recursive=True)
                    for child in children:
                        try:
                            raw_cpu += child.cpu_percent(interval=None)
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                # Normalize to package-level [0, 100]
                cpu_norm = min(raw_cpu / _CPU_COUNT, 100.0)
                cpu_sum += cpu_norm
                cpu_count += 1

                # --- RAM: main process + children RSS ---
                rss = ps.memory_info().rss
                try:
                    for child in ps.children(recursive=True):
                        try:
                            rss += child.memory_info().rss
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                ram_gb = rss / (1024**3)
                ram_sum += ram_gb
                ram_count += 1
                if ram_gb > ram_peak:
                    ram_peak = ram_gb

                # --- IO: cumulative counters ---
                try:
                    io = ps.io_counters()
                    total_bytes = io.read_bytes + io.write_bytes
                    nonlocal io_bytes_start
                    if io_bytes_start is None:
                        io_bytes_start = total_bytes
                    io_bytes_end = total_bytes
                except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError):
                    pass

            except psutil.NoSuchProcess:
                break
            stop_event.wait(1.0)

    cpu_ram_thread = threading.Thread(target=_collect_cpu_ram, daemon=True)
    gpu_thread = threading.Thread(
        target=_collect_gpu_metrics,
        args=(gpu_samples, stop_event, gpu_backend),
        daemon=True,
    )
    cpu_ram_thread.start()
    gpu_thread.start()

    interrupted = False
    exit_code = -2
    start = time.monotonic()
    try:
        exit_code = proc.wait()
    except KeyboardInterrupt:
        interrupted = True
        try:
            proc.terminate()
            exit_code = proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            exit_code = -2
    finally:
        duration = time.monotonic() - start
        stop_event.set()
        cpu_ram_thread.join(timeout=2)
        gpu_thread.join(timeout=2)
        tee_thread.join(timeout=5)

    cpu_avg = cpu_sum / cpu_count if cpu_count else 0.0
    ram_avg = ram_sum / ram_count if ram_count else 0.0
    gpu_util_avg = sum(s[0] for s in gpu_samples) / len(gpu_samples) if gpu_samples else 0.0
    gpu_mem_peak = max(s[1] for s in gpu_samples) if gpu_samples else 0.0
    io_delta = max(0, io_bytes_end - (io_bytes_start or io_bytes_end))

    cpu_tdp, gpu_tdp = resolve_tdp_watts(hardware_snapshot)
    energy_kwh = energy_kwh_tdp_utilization(
        cpu_avg_percent=cpu_avg,
        gpu_avg_percent=gpu_util_avg,
        duration_seconds=duration,
        cpu_tdp_watts=cpu_tdp,
        gpu_tdp_watts=gpu_tdp,
        ram_gb_avg=ram_avg,
        io_bytes_total=io_delta,
    )
    hardware_snapshot["tdp_cpu_watts_resolved"] = cpu_tdp
    hardware_snapshot["tdp_gpu_watts_resolved"] = gpu_tdp
    hardware_snapshot["gpu_backend"] = gpu_backend

    return RunResult(
        exit_code=exit_code,
        duration_seconds=round(duration, 2),
        cpu_percent_avg=round(cpu_avg, 1),
        ram_gb_peak=round(ram_peak, 3),
        ram_gb_avg=round(ram_avg, 3),
        gpu_utilization_avg=round(gpu_util_avg, 1),
        gpu_memory_peak_gb=round(gpu_mem_peak, 3),
        io_bytes_total=io_delta,
        energy_kwh=energy_kwh,
        interrupted=interrupted,
        hardware_snapshot=hardware_snapshot,
        stdout_tail=list(_stdout_buf),
    )
