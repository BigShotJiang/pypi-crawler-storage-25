"""
Dataset feature extraction for surrogate training data.

Extracts signals from CSV files:
  - General dataset statistics (Table 12)
  - Baseline ML model metrics (Table 13)
  - CNN features via VGG16 block3_conv3 + GlobalAveragePooling2D (stored in DB,
    excluded from estimation payloads)

Requires: pandas, numpy, scikit-learn  (install with: pip install netgreener[data])
CNN extraction additionally requires TensorFlow/Keras.
Degrades gracefully if dependencies are missing.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SAMPLE_ROWS = 50_000  # cap for ML estimation to stay fast on large datasets

try:
    import numpy as np
    import pandas as pd
    from sklearn.linear_model import LinearRegression, LogisticRegression
    from sklearn.metrics import (
        accuracy_score,
        f1_score,
        mean_absolute_error,
        mean_squared_error,
        r2_score,
    )
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

    _DEPS_OK = True
except ImportError:
    _DEPS_OK = False

try:
    from tensorflow.keras.applications import VGG16
    from tensorflow.keras.layers import GlobalAveragePooling2D
    from tensorflow.keras.models import Model

    _TF_OK = True
except ImportError:
    _TF_OK = False


def _extract_cnn_features(df: "pd.DataFrame") -> dict[str, Any]:
    """Extract CNN features using VGG16 block3_conv3 + GlobalAveragePooling2D.

    Converts tabular data statistics into a 224x224x3 array and passes it
    through VGG16 to produce a ~256-dimensional float feature vector.
    Only called when TensorFlow is available (_TF_OK is True).
    """
    if not _TF_OK:
        return {"error": "TensorFlow/Keras not installed. Run: pip install tensorflow"}

    try:
        numeric_df = df.select_dtypes(include=[np.number])
        if len(numeric_df.columns) == 0:
            return {"error": "No numeric columns available for CNN feature extraction"}

        df_norm = (numeric_df - numeric_df.min()) / (numeric_df.max() - numeric_df.min())
        df_desc = df_norm.describe().loc[["mean", "std", "25%", "50%", "75%"], :]

        pct_unique = df.nunique() / df.count()
        freq_most_common = df.apply(lambda x: x.value_counts().max() / x.count()) * 100
        pct_null = df.isnull().sum() / df.count()
        df_general = pd.concat([pct_unique, freq_most_common, pct_null], axis=1).T

        df_all = pd.concat([df_general, df_desc], axis=0).fillna(-1)

        data_array = np.full((1, 224, 224, 3), -1.0)
        r, c = df_all.shape
        data_array[0, :r, :c, 0] = df_all.values
        for ch in range(1, 3):
            data_array[:, :, :, ch] = data_array[:, :, :, 0]
        data_array = np.round(data_array, 2)

        base = VGG16(weights="imagenet", include_top=False)
        layer_output = base.get_layer("block3_conv3").output
        pooled = GlobalAveragePooling2D()(layer_output)
        model = Model(inputs=base.input, outputs=pooled)

        features = model.predict(data_array, verbose=0)[0].tolist()
        feature_names = [f"cnn_feature_{i + 1}" for i in range(len(features))]

        return {
            "feature_count": len(features),
            "model_layer": "block3_conv3",
            "input_shape": list(data_array.shape),
            "features": {name: round(v, 6) for name, v in zip(feature_names, features)},
        }

    except Exception as exc:
        return {"error": f"CNN feature extraction failed: {exc}"}


def extract_dataset_features(file_path: str) -> dict[str, Any]:
    """Return a JSON-serialisable feature dict for a CSV dataset file.

    Returns {"error": ...} when dependencies are missing or the file cannot
    be read; callers should check for this key before using the result.
    CNN features are extracted when TensorFlow is available and stored under
    the "cnn_features" key; they are not used by the estimation pipeline.
    """
    if not _DEPS_OK:
        return {
            "error": (
                "pandas, numpy and scikit-learn are required for dataset feature extraction. "
                "Install with: pip install netgreener[data]"
            )
        }

    path = Path(file_path)
    if not path.exists():
        return {"error": f"Dataset file not found: {file_path}"}

    try:
        try:
            df = pd.read_csv(file_path, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, encoding="latin-1")
    except Exception as exc:
        logger.warning("dataset_features: could not read %s: %s", file_path, exc)
        return {"error": f"Could not read dataset: {exc}"}

    if df.empty or len(df.columns) == 0:
        return {"error": "Dataset is empty"}

    stat = path.stat()

    result: dict[str, Any] = {
        "file_info": {
            "file_name": path.name,
            "file_size_mb": round(stat.st_size / (1024 * 1024), 4),
            "file_extension": path.suffix.lower(),
        },
        "dataset_overview": _overview(df),
        "statistical_features": _statistical(df),
        "data_quality": _quality(df),
        "ml_readiness": _ml_readiness(df),
        "advanced_statistics": _advanced(df),
        "ml_estimation": _ml_estimation(df),
    }

    if _TF_OK:
        logger.info("Extracting CNN features via VGG16 (this may take ~30s on first run) ...")
        result["cnn_features"] = _extract_cnn_features(df)
    else:
        logger.debug("TensorFlow not available; skipping CNN feature extraction.")

    return result


def _overview(df: "pd.DataFrame") -> dict[str, Any]:
    return {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "memory_usage_mb": round(float(df.memory_usage(deep=True).sum()) / (1024 * 1024), 4),
        "column_names": list(df.columns),
        "data_types": {col: str(dtype) for col, dtype in df.dtypes.items()},
    }


def _statistical(df: "pd.DataFrame") -> dict[str, Any]:
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) == 0:
        return {
            "numeric_columns_count": 0,
            "categorical_columns_count": int(len(df.columns)),
        }

    numeric_df = df[numeric_cols]
    result: dict[str, Any] = {
        "numeric_columns_count": int(len(numeric_cols)),
        "categorical_columns_count": int(len(df.columns) - len(numeric_cols)),
        "skewness": {k: round(float(v), 4) for k, v in numeric_df.skew().items()},
        "kurtosis": {k: round(float(v), 4) for k, v in numeric_df.kurtosis().items()},
    }
    if len(numeric_cols) > 1:
        corr = numeric_df.corr()
        result["correlation_matrix"] = {
            col: {c: round(float(v), 4) for c, v in row.items()}
            for col, row in corr.to_dict().items()
        }
    return result


def _quality(df: "pd.DataFrame") -> dict[str, Any]:
    total_cells = int(len(df) * len(df.columns))
    null_cells = int(df.isnull().sum().sum())
    duplicate_rows = int(df.duplicated().sum())
    return {
        "total_cells": total_cells,
        "null_cells": null_cells,
        "null_percentage": round((null_cells / total_cells) * 100, 2) if total_cells else 0.0,
        "duplicate_rows": duplicate_rows,
        "duplicate_percentage": round((duplicate_rows / len(df)) * 100, 2) if len(df) else 0.0,
        "columns_with_nulls": df.columns[df.isnull().any()].tolist(),
    }


def _ml_readiness(df: "pd.DataFrame") -> dict[str, Any]:
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns
    potential_targets = [col for col in numeric_cols if df[col].nunique() <= 10]
    return {
        "numeric_features_count": int(len(numeric_cols)),
        "categorical_features_count": int(len(categorical_cols)),
        "binary_features_count": int(sum(1 for col in df.columns if df[col].nunique() == 2)),
        "high_cardinality_features": int(
            sum(1 for col in categorical_cols if df[col].nunique() > 10)
        ),
        "potential_target_variables": potential_targets,
    }


def _advanced(df: "pd.DataFrame") -> dict[str, Any]:
    """Advanced statistics matching the naming convention in Table 12."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    stats: dict[str, Any] = {}

    stats["numeric_features_ratio"] = (
        round(len(numeric_cols) / len(df.columns), 4) if len(df.columns) else 0.0
    )

    if len(numeric_cols) > 1:
        corr_vals = df[numeric_cols].corr().values
        upper = corr_vals[np.triu_indices_from(corr_vals, k=1)]
        stats["mean_correlation_numeric_features"] = round(float(upper.mean()), 4)
    else:
        stats["mean_correlation_numeric_features"] = 0.0

    total_elements = int(df.count().sum())
    null_count = int(df.isnull().sum().sum())
    stats["null_to_total_percentage"] = (
        round((null_count / total_elements) * 100, 2) if total_elements else 0.0
    )

    dup_per_col = sum(int(df[col].duplicated().sum()) for col in df.columns)
    stats["percent_duplicates"] = (
        round((dup_per_col / total_elements) * 100, 2) if total_elements else 0.0
    )

    if len(numeric_cols) > 0:
        cv = (df[numeric_cols].std() / df[numeric_cols].mean()) * 100
        stats["mean_coefficient_variation"] = round(float(cv.mean()), 2)

    string_cols = df.select_dtypes(include=["object"]).columns
    if len(string_cols) > 0:
        max_lengths = [int(df[col].astype(str).str.len().max()) for col in string_cols]
        stats["max_largest_length_per_column"] = max(max_lengths) if max_lengths else 0

    return stats


def _ml_estimation(df: "pd.DataFrame") -> dict[str, Any]:
    """Train lightweight baseline models and return their metrics (Table 13)."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) < 2:
        return {"error": "Insufficient numeric columns for ML estimation"}

    df_work = df.sample(_SAMPLE_ROWS, random_state=42) if len(df) > _SAMPLE_ROWS else df
    candidates = [col for col in numeric_cols if df_work[col].nunique() <= 10] or [numeric_cols[-1]]

    results: dict[str, Any] = {}
    for target in candidates[:2]:
        try:
            df_clean = df_work.dropna()
            if len(df_clean) < 10:
                continue

            X = df_clean.drop(columns=[target])
            y = df_clean[target]

            text_cols = X.select_dtypes(include=["object"]).columns
            if len(text_cols) > 0:
                X = pd.concat(
                    [
                        pd.get_dummies(X[text_cols], drop_first=True).astype(int),
                        X.select_dtypes(exclude=["object"]),
                    ],
                    axis=1,
                )

            num_cols = X.select_dtypes(include=[np.number]).columns
            col_range = (X[num_cols].max() - X[num_cols].min()).replace(0, 1)
            X = X.copy()
            X[num_cols] = (X[num_cols] - X[num_cols].min()) / col_range

            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )

            unique_vals = int(y.nunique())
            problem_type = "classification" if unique_vals <= 10 else "regression"
            entry: dict[str, Any] = {
                "problem_type": problem_type,
                "unique_target_values": unique_vals,
            }

            if problem_type == "regression":
                lr = LinearRegression().fit(X_train, y_train)
                lr_pred = lr.predict(X_test)
                entry["linear_regression"] = {
                    "mse": round(float(mean_squared_error(y_test, lr_pred)), 4),
                    "r2": round(float(r2_score(y_test, lr_pred)), 4),
                    "mae": round(float(mean_absolute_error(y_test, lr_pred)), 4),
                    "rmse": round(float(np.sqrt(mean_squared_error(y_test, lr_pred))), 4),
                }
                dt = DecisionTreeRegressor(random_state=42).fit(X_train, y_train)
                dt_pred = dt.predict(X_test)
                entry["decision_tree_regression"] = {
                    "mse": round(float(mean_squared_error(y_test, dt_pred)), 4),
                    "r2": round(float(r2_score(y_test, dt_pred)), 4),
                    "mae": round(float(mean_absolute_error(y_test, dt_pred)), 4),
                    "rmse": round(float(np.sqrt(mean_squared_error(y_test, dt_pred))), 4),
                }
            else:
                le = LabelEncoder()
                y_tr_enc = le.fit_transform(y_train)
                y_te_enc = le.transform(y_test)

                lr = LogisticRegression(random_state=42, max_iter=1000).fit(X_train, y_tr_enc)
                lr_pred = lr.predict(X_test)
                entry["logistic_regression"] = {
                    "accuracy": round(float(accuracy_score(y_te_enc, lr_pred)), 4),
                    "f1_score": round(float(f1_score(y_te_enc, lr_pred, average="weighted")), 4),
                }
                dt = DecisionTreeClassifier(random_state=42).fit(X_train, y_tr_enc)
                dt_pred = dt.predict(X_test)
                entry["decision_tree_classification"] = {
                    "accuracy": round(float(accuracy_score(y_te_enc, dt_pred)), 4),
                    "f1_score": round(float(f1_score(y_te_enc, dt_pred, average="weighted")), 4),
                }

            results[str(target)] = entry

        except Exception as exc:
            results[str(target)] = {"error": str(exc)}

    return results
