"""
Reads CLI configuration from ~/.netgreener/config.json or environment variables.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Literal

_CONFIG_DIR = Path.home() / ".netgreener"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_CREDENTIALS_FILE = _CONFIG_DIR / "credentials.json"
_API_URL_KEY = "api_url"
_ORG_ID_KEY = "organization_id"
_ENV_KEY = "environment"
_DEFAULT_API_URL = "https://netgreener.eastus2.cloudapp.azure.com"
DASHBOARD_URL = "https://dashboard.netgreener.com"

# Legacy flat keys (large profile only)
_LLM_PROVIDER_KEY = "llm_provider"
_LLM_KEY_KEY = "llm_key"
_LLM_ENDPOINT_KEY = "llm_endpoint"
_LLM_MODEL_KEY = "llm_model"

_LLM_LARGE_BLOCK = "llm_large"
_LLM_MINI_BLOCK = "llm_mini"

SUPPORTED_LLM_PROVIDERS = ("azure_openai", "openai", "anthropic", "ollama", "custom")

LLMProfileName = Literal["large", "mini"]


def _ensure_dir() -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _read_config() -> dict:
    try:
        return json.loads(_CONFIG_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _write_config(data: dict) -> None:
    _ensure_dir()
    tmp = _CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(_CONFIG_FILE)


def get_api_url() -> str:
    if url := os.environ.get("NETGREENER_API_URL"):
        return url.rstrip("/")
    return _read_config().get(_API_URL_KEY, _DEFAULT_API_URL).rstrip("/")


def save_api_url(url: str) -> None:
    data = _read_config()
    data[_API_URL_KEY] = url
    _write_config(data)


def get_organization_id() -> int | None:
    env_value = os.environ.get("NETGREENER_ORG_ID")
    if env_value:
        try:
            return int(env_value)
        except ValueError:
            return None
    value = _read_config().get(_ORG_ID_KEY)
    return (
        int(value)
        if isinstance(value, int) or (isinstance(value, str) and value.isdigit())
        else None
    )


def get_environment() -> str:
    env_value = os.environ.get("NETGREENER_ENV")
    if env_value in {"dev", "staging", "prod"}:
        return env_value
    value = _read_config().get(_ENV_KEY, "dev")
    return value if value in {"dev", "staging", "prod"} else "dev"


def save_org_context(organization_id: int | None, environment: str = "dev") -> None:
    data = _read_config()
    if organization_id is None:
        data.pop(_ORG_ID_KEY, None)
    else:
        data[_ORG_ID_KEY] = organization_id
    data[_ENV_KEY] = environment if environment in {"dev", "staging", "prod"} else "dev"
    _write_config(data)


def load_credentials() -> dict | None:
    if token := os.environ.get("NETGREENER_TOKEN"):
        return {"access_token": token, "user": {}}
    try:
        return json.loads(_CREDENTIALS_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def save_credentials(token: str, user: dict) -> None:
    _ensure_dir()
    _CREDENTIALS_FILE.write_text(json.dumps({"access_token": token, "user": user}, indent=2))
    try:
        _CREDENTIALS_FILE.chmod(0o600)
    except NotImplementedError:
        pass  # Windows does not support POSIX permissions


def clear_credentials() -> None:
    try:
        _CREDENTIALS_FILE.unlink()
    except FileNotFoundError:
        pass


# ---------------------------------------------------------------------------
# User LLM config; large + mini (BYOK). Server default when unset.
# ---------------------------------------------------------------------------


def _normalize_profile_dict(raw: Any) -> dict[str, str]:
    if not isinstance(raw, dict):
        return {"provider": "", "key": "", "endpoint": "", "model": ""}
    return {
        "provider": str(raw.get("provider", "") or ""),
        "key": str(raw.get("key", "") or ""),
        "endpoint": str(raw.get("endpoint", "") or ""),
        "model": str(raw.get("model", "") or ""),
    }


def _profile_from_file(cfg: dict, which: LLMProfileName) -> dict[str, str]:
    if which == "large":
        block = cfg.get(_LLM_LARGE_BLOCK)
        if isinstance(block, dict):
            return _normalize_profile_dict(block)
        if cfg.get(_LLM_PROVIDER_KEY):
            return _normalize_profile_dict(
                {
                    "provider": cfg.get(_LLM_PROVIDER_KEY, ""),
                    "key": cfg.get(_LLM_KEY_KEY, ""),
                    "endpoint": cfg.get(_LLM_ENDPOINT_KEY, ""),
                    "model": cfg.get(_LLM_MODEL_KEY, ""),
                }
            )
        return _normalize_profile_dict({})
    block = cfg.get(_LLM_MINI_BLOCK)
    return _normalize_profile_dict(block if isinstance(block, dict) else {})


def _overlay_large_env(base: dict[str, str]) -> dict[str, str]:
    return {
        "provider": os.environ.get("NETGREENER_LLM_PROVIDER", "").strip()
        or base["provider"].strip(),
        "key": os.environ.get("NETGREENER_LLM_KEY", "").strip() or base["key"].strip(),
        "endpoint": os.environ.get("NETGREENER_LLM_ENDPOINT", "").strip()
        or base["endpoint"].strip(),
        "model": os.environ.get("NETGREENER_LLM_MODEL", "").strip() or base["model"].strip(),
    }


def _overlay_mini_env(base: dict[str, str]) -> dict[str, str]:
    return {
        "provider": os.environ.get("NETGREENER_LLM_MINI_PROVIDER", "").strip()
        or base["provider"].strip(),
        "key": os.environ.get("NETGREENER_LLM_MINI_KEY", "").strip() or base["key"].strip(),
        "endpoint": os.environ.get("NETGREENER_LLM_MINI_ENDPOINT", "").strip()
        or base["endpoint"].strip(),
        "model": os.environ.get("NETGREENER_LLM_MINI_MODEL", "").strip() or base["model"].strip(),
    }


def get_merged_llm_profile(which: LLMProfileName) -> dict[str, str]:
    """Merged file + env values for one profile (may be incomplete)."""
    cfg = _read_config()
    base = _profile_from_file(cfg, which)
    return _overlay_large_env(base) if which == "large" else _overlay_mini_env(base)


def _profile_any_field_touched(p: dict[str, str]) -> bool:
    return any((p.get(k) or "").strip() for k in ("provider", "key", "endpoint", "model"))


def _profile_is_complete(p: dict[str, str]) -> bool:
    provider = (p.get("provider") or "").strip()
    model = (p.get("model") or "").strip()
    if not provider or not model:
        return False
    if provider.lower() not in SUPPORTED_LLM_PROVIDERS:
        return False
    endpoint = (p.get("endpoint") or "").strip()
    if provider.lower() == "azure_openai" and not endpoint:
        return False
    return True


def get_byok_llm_config_error() -> str | None:
    """If the user started BYOK (any LLM field set), require both profiles complete."""
    large = get_merged_llm_profile("large")
    mini = get_merged_llm_profile("mini")
    large_touched = _profile_any_field_touched(large)
    mini_touched = _profile_any_field_touched(mini)
    if not large_touched and not mini_touched:
        return None
    large_ok = _profile_is_complete(large)
    mini_ok = _profile_is_complete(mini)
    if large_ok and mini_ok:
        return None
    if not large_touched and mini_touched:
        return (
            "BYOK requires both LLM profiles (large + mini). Mini is set but large is missing. "
            "Configure large via NETGREENER_LLM_* or `netgreener llm-config --profile large ...`."
        )
    if large_touched and not mini_touched:
        return (
            "BYOK requires both LLM profiles (large + mini). Large is set but mini is missing. "
            "Configure mini via NETGREENER_LLM_MINI_* or `netgreener llm-config --profile mini ...`."
        )
    problems: list[str] = []
    if large_touched and not large_ok:
        problems.append(
            "large profile is incomplete (need provider, model, and endpoint for azure_openai)"
        )
    if mini_touched and not mini_ok:
        problems.append(
            "mini profile is incomplete (need provider, model, and endpoint for azure_openai)"
        )
    return "Invalid BYOK LLM configuration: " + "; ".join(problems) + "."


def user_byok_llm_ready() -> bool:
    """Both BYOK profiles fully configured (no error and both complete)."""
    if get_byok_llm_config_error() is not None:
        return False
    return _profile_is_complete(get_merged_llm_profile("large")) and _profile_is_complete(
        get_merged_llm_profile("mini")
    )


def get_user_llm_profile(which: LLMProfileName) -> dict | None:
    """Return one profile dict for BYOK, or None if that profile is not fully configured."""
    p = get_merged_llm_profile(which)
    if not _profile_is_complete(p):
        return None
    return {
        "provider": p["provider"].strip(),
        "key": p["key"].strip(),
        "endpoint": p["endpoint"].strip(),
        "model": p["model"].strip(),
    }


def get_user_llm_config() -> dict | None:
    """Backward-compatible: large profile dict only when BYOK is valid (both profiles complete)."""
    if get_byok_llm_config_error():
        return None
    return get_user_llm_profile("large")


def save_user_llm_config(
    *,
    profile: LLMProfileName,
    provider: str,
    key: str = "",
    endpoint: str = "",
    model: str = "",
) -> None:
    data = _read_config()
    block_key = _LLM_LARGE_BLOCK if profile == "large" else _LLM_MINI_BLOCK
    data[block_key] = {
        "provider": provider,
        "key": key,
        "endpoint": endpoint,
        "model": model,
    }
    if profile == "large":
        for k in (_LLM_PROVIDER_KEY, _LLM_KEY_KEY, _LLM_ENDPOINT_KEY, _LLM_MODEL_KEY):
            data.pop(k, None)
    _write_config(data)


def clear_user_llm_config(profile: LLMProfileName | None = None) -> None:
    data = _read_config()
    if profile is None or profile == "large":
        data.pop(_LLM_LARGE_BLOCK, None)
        for k in (_LLM_PROVIDER_KEY, _LLM_KEY_KEY, _LLM_ENDPOINT_KEY, _LLM_MODEL_KEY):
            data.pop(k, None)
    if profile is None or profile == "mini":
        data.pop(_LLM_MINI_BLOCK, None)
    _write_config(data)
