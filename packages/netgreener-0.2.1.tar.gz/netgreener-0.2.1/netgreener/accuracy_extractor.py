"""Auto-detect accuracy metrics from script stdout and common ML framework outputs.

Supported detection methods (applied in order, later overrides earlier):
  1. Stdout regex ; any framework that prints metrics to stdout
  2. MLflow       ; mlruns/ directory metric files
  3. W&B          ; wandb/latest-run/files/wandb-summary.json
"""

import json
import re
from pathlib import Path

# Each tuple: (metric_key, compiled_pattern).
# Patterns are applied to every captured stdout line; the *last* match wins
# so final-epoch values overwrite intermediate ones.
_STDOUT_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("model_accuracy", re.compile(r"\baccuracy\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("val_accuracy", re.compile(r"\bval_?accuracy\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("f1_score", re.compile(r"\bf1[_\-]?score\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("precision", re.compile(r"\bprecision\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("recall", re.compile(r"\brecall\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("loss", re.compile(r"\b(?:val_)?loss\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("mae", re.compile(r"\bmae\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("rmse", re.compile(r"\brmse\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("r2_score", re.compile(r"\br2[_\-]?score\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("auc", re.compile(r"\bauc\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
    ("mse", re.compile(r"\bmse\s*[=:]\s*([0-9]*\.?[0-9]+)", re.I)),
]

# Values > 1 for these keys are assumed to be percentages; normalise to [0, 1].
_PERCENT_KEYS = {"model_accuracy", "val_accuracy", "f1_score", "precision", "recall", "auc"}


def extract_from_stdout(lines: list[str]) -> dict:
    """Scan captured stdout lines and return last value seen per metric."""
    found: dict[str, float] = {}
    for line in lines:
        for key, pattern in _STDOUT_PATTERNS:
            m = pattern.search(line)
            if m:
                try:
                    v = float(m.group(1))
                    if key in _PERCENT_KEYS and v > 1.0:
                        v = v / 100.0
                    found[key] = round(v, 6)
                except ValueError:
                    pass
    return found


def scan_mlflow_dir(project_dir: str, since_time: float) -> dict:
    """Return final metric values from MLflow mlruns/ files written after since_time."""
    mlruns = Path(project_dir) / "mlruns"
    if not mlruns.exists():
        return {}
    metrics: dict[str, float] = {}
    for metric_file in mlruns.rglob("metrics/*"):
        if not metric_file.is_file():
            continue
        try:
            if metric_file.stat().st_mtime < since_time:
                continue
            lines = metric_file.read_text(encoding="utf-8").strip().splitlines()
            if lines:
                # MLflow format: "<timestamp_ms> <value> <step>"
                parts = lines[-1].split()
                if len(parts) >= 2:
                    metrics[metric_file.name] = float(parts[1])
        except Exception:
            pass
    return metrics


def scan_wandb_dir(project_dir: str, since_time: float) -> dict:
    """Return numeric summary values from W&B wandb/latest-run/files/wandb-summary.json."""
    summary = Path(project_dir) / "wandb" / "latest-run" / "files" / "wandb-summary.json"
    if not summary.exists():
        return {}
    try:
        if summary.stat().st_mtime < since_time:
            return {}
        data = json.loads(summary.read_text(encoding="utf-8"))
        return {k: float(v) for k, v in data.items() if isinstance(v, (int, float))}
    except Exception:
        return {}


def auto_extract(stdout_lines: list[str], project_dir: str, since_time: float) -> dict:
    """Combine all extraction methods. Framework files override stdout regex."""
    result: dict = {}
    result.update(extract_from_stdout(stdout_lines))
    result.update(scan_mlflow_dir(project_dir, since_time))
    result.update(scan_wandb_dir(project_dir, since_time))
    return result
