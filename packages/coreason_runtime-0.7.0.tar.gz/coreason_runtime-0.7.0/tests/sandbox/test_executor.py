# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for WasmSandboxExecutor.

Tests the WASM sandbox boundary: path traversal attack detection,
missing plugin file handling, intent hash determinism, and error propagation.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: MCPClientIntent constructed from coreason_manifest models.
"""

from pathlib import Path
from typing import Any

import pytest
from coreason_manifest import MCPClientIntent

from coreason_runtime.sandbox.executor import WasmSandboxExecutor

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_intent(
    params: dict[str, Any] | None = None,
    request_id: str = "test-req-1",
) -> MCPClientIntent:
    """Construct a physically validated MCPClientIntent from the manifest.

    Uses model_construct() because the MCPClientIntent model has a
    model_validator requiring holographic_projection for standard __init__.
    """
    return MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        params=params or {"tool_name": "test-tool"},
        id=request_id,
        holographic_projection=None,  # type: ignore[arg-type]
    )


# ── WasmSandboxExecutor Tests ─────────────────────────────────────────


class TestWasmSandboxExecutor:
    """Physical tests for the WASM sandbox boundary enforcement."""

    def test_initializes_with_default_plugins_dir(self) -> None:
        """Executor initializes with default plugins directory."""
        executor = WasmSandboxExecutor()
        assert executor.plugins_dir.is_absolute()

    def test_initializes_with_custom_plugins_dir(self, tmp_path: Path) -> None:
        """Executor uses custom plugins directory when provided."""
        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path))
        assert executor.plugins_dir == tmp_path

    @pytest.mark.asyncio
    async def test_intent_hash_is_deterministic(self, tmp_path: Path) -> None:
        """Same intent produces the same SHA-256 hash using physical objects."""

        # Instantiate a real registry client pointing to a dead port to ensure localized execution
        # that naturally terminates deterministically with a ManifestConformanceError
        # without needing any unittest.mock patches.
        import httpx

        from coreason_runtime.sandbox.registry_client import EcosystemRegistryClient

        transport = httpx.AsyncHTTPTransport(local_address="127.0.0.1")
        # Physical instantiation
        registry = EcosystemRegistryClient(transport=transport)
        registry.base_url = "http://127.0.0.1:54321"  # guaranteed closed port

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path), registry_client=registry)
        intent = _build_intent(params={"key": "value"}, request_id="hash-test")

        # Natively execute the physical paths twice
        r1 = await executor.execute_actuator("missing_tool", intent)
        r2 = await executor.execute_actuator("missing_tool", intent)

        assert r1["intent_hash"] == r2["intent_hash"]
        assert len(r1["intent_hash"]) == 64
        # Even though they trap physically on the network level, the deterministic hashes are correctly generated

    @pytest.mark.asyncio
    async def test_different_intents_produce_different_hashes(self, tmp_path: Path) -> None:
        """Different intents produce different hashes gracefully without mocking."""

        import httpx

        from coreason_runtime.sandbox.registry_client import EcosystemRegistryClient

        transport = httpx.AsyncHTTPTransport(local_address="127.0.0.1")
        registry = EcosystemRegistryClient(transport=transport)
        registry.base_url = "http://127.0.0.1:54321"

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path), registry_client=registry)
        intent_a = _build_intent(params={"input": "alpha"}, request_id="a1")
        intent_b = _build_intent(params={"input": "beta"}, request_id="b1")

        r1 = await executor.execute_actuator("missing_a", intent_a)
        r2 = await executor.execute_actuator("missing_b", intent_b)

        assert r1["intent_hash"] != r2["intent_hash"]

    @pytest.mark.asyncio
    async def test_executor_catchall_exception(self, tmp_path: Path) -> None:
        """Exceptions natively resolve into robust execution dictionary objects through natural Python faults."""

        # Pass a completely invalid object as the registry client.
        # It natively raises an AttributeError exactly simulating extreme host virtualization faults.
        class _InvalidStructuralRegistry:
            pass

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path), registry_client=_InvalidStructuralRegistry())
        intent = _build_intent(params={"input": "test"}, request_id="catchall-test")

        res = await executor.execute_actuator("failing_tool", intent)

        assert res["success"] is False
        assert "Internal Sandbox Error" in res["error"]
        assert "has no attribute 'fetch_capability_binary'" in res["error"]

    @pytest.mark.asyncio
    async def test_executor_fallback_registry(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """Physical test triggering the else branch where EcosystemRegistryClient is instantiated."""
        monkeypatch.setenv("COREASON_ECOSYSTEM_URL", "http://127.0.0.1:54321")

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path), registry_client=None)
        intent = _build_intent(params={"input": "test"}, request_id="fallback-test")

        res = await executor.execute_actuator("missing_tool", intent)

        assert res["success"] is False
