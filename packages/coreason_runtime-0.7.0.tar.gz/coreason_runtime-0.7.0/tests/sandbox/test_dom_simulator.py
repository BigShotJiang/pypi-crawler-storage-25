from coreason_runtime.sandbox.dom_simulator import BrowserStateDict


def test_dom_simulator_import() -> None:
    d: BrowserStateDict = {"navigation_depth": 1}
    assert d["navigation_depth"] == 1
