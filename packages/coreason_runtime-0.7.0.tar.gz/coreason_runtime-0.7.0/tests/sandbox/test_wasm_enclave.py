# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import extism  # type: ignore[import-untyped]
import pytest

from coreason_runtime.sandbox.wasm_enclave import ExtismWasmEnclave  # pyre-ignore[21]
from coreason_runtime.utils.exceptions import ManifestConformanceError, SecurityViolationError  # pyre-ignore[21]


@pytest.fixture
def test_wasm_path(tmp_path: Path) -> Path:
    p = tmp_path / "test.wasm"
    p.write_bytes(b"\x00asm\x01\x00\x00\x00")
    return p


@pytest.fixture
def mock_mcp_intent() -> dict[str, Any]:
    """Returns a mock strict intent payload conforming to Manifest."""
    return {
        "jsonrpc": "2.0",
        "method": "mcp.ui.emit_intent",
        "params": {},
        "id": "request-id-123",
        "holographic_projection": None,
        "state_vector": {"clearance": "PUBLIC"},
    }


@pytest.fixture
def mock_receipt() -> dict[str, Any]:
    return {
        "request_cid": "cid1",
        "parent_request_cid": "cid2",
        "root_request_cid": "cid3",
        "inputs": {},
        "outputs": {},
        "parent_hashes": [],
        "node_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    }


def test_initialize_plugin(test_wasm_path: Path) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        enclave.initialize_plugin(test_wasm_path)
        mock_plugin.assert_called_once()
        assert enclave.plugin is not None


@pytest.mark.asyncio
async def test_execute_intent_success(
    test_wasm_path: Path, mock_mcp_intent: dict[str, Any], mock_receipt: dict[str, Any]
) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Mock Extism to return raw JSON byte dump for Receipt
        mock_plugin_instance.call.return_value = json.dumps(mock_receipt).encode("utf-8")

        enclave.initialize_plugin(test_wasm_path)

        # Test Execution
        receipt = enclave.execute_intent("invoke_agent", mock_mcp_intent)
        assert isinstance(receipt, dict)
        assert receipt["request_cid"] == "cid1"
        mock_plugin_instance.call.assert_called_once_with("invoke_agent", json.dumps(mock_mcp_intent).encode("utf-8"))


@pytest.mark.asyncio
async def test_execute_intent_volumetric_trap(test_wasm_path: Path, mock_mcp_intent: dict[str, Any]) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Mock Extism to return memory bomb > 10MB
        mock_plugin_instance.call.return_value = b"\x00" * 10485761

        enclave.initialize_plugin(test_wasm_path)

        with pytest.raises(ManifestConformanceError, match="Memory Trap"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)


@pytest.mark.asyncio
async def test_execute_intent_write_down_violation(test_wasm_path: Path, mock_mcp_intent: dict[str, Any]) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Does not matter what plugin returns because LBAC Reference Monitor is checked after,
        # Wait, the Memory Trap happens before Reference Monitor, and then Reference Monitor.
        # Does it decode? No, Reference Monitor is checked before decoding!
        mock_plugin_instance.call.return_value = b'{"valid": "json"}'

        # Native dictionary modification
        mock_mcp_intent["state_vector"] = {"clearance": "TOP_SECRET"}

        enclave.initialize_plugin(test_wasm_path)

        # By default the sink clearance is PUBLIC, so TOP_SECRET into PUBLIC will Trap.
        with pytest.raises(SecurityViolationError, match="Security Clearance Violation"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)


@pytest.mark.asyncio
async def test_execute_intent_extism_trap(test_wasm_path: Path, mock_mcp_intent: dict[str, Any]) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Trigger Extism trap
        mock_plugin_instance.call.side_effect = extism.Error("memory access out of bounds")

        enclave.initialize_plugin(test_wasm_path)

        # Test Catching
        with pytest.raises(ManifestConformanceError, match="Extism execution trap"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)


@pytest.mark.asyncio
async def test_execute_intent_json_decode_error(test_wasm_path: Path, mock_mcp_intent: dict[str, Any]) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        mock_plugin_instance.call.return_value = b"invalid json"
        enclave.initialize_plugin(test_wasm_path)
        with pytest.raises(ManifestConformanceError, match="JSON violation returning from Wasm"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)


@pytest.mark.asyncio
async def test_execute_intent_generic_exception(test_wasm_path: Path, mock_mcp_intent: dict[str, Any]) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        mock_plugin_instance.call.side_effect = RuntimeError("Panic")
        enclave.initialize_plugin(test_wasm_path)
        with pytest.raises(ManifestConformanceError, match="Execution wrapped failure"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)
