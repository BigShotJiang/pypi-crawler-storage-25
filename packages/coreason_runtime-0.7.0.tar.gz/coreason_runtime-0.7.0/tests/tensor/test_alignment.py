# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>


from coreason_runtime.tensor.alignment import verify_ontological_isometry


def test_identical_embeddings_alignment() -> None:
    """AGENTS.md: Validate Vector Space Isometry without mocks.
    Identical vectors must pass min_cosine and max_emd checks."""
    local_vectors = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
    remote_vectors = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
    policy = {"min_cosine_similarity": 0.9, "max_earth_mover_distance": 0.1, "enable_dimensional_projection": False}

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)
    assert receipt["status"] == "aligned"
    assert receipt["measured_cosine_similarity"] > 0.99
    assert receipt["measured_emd"] < 0.01
    assert receipt["dimensional_projection_attempted"] is False


def test_orthogonal_vectors_failure() -> None:
    """AGENTS.md: Orthogonal vectors should fail the cosine check triggering incommensurable state."""
    local_vectors = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
    remote_vectors = [[0.0, 0.0, 1.0], [0.0, 0.0, -1.0]]
    policy = {"min_cosine_similarity": 0.5, "max_earth_mover_distance": 2.0, "enable_dimensional_projection": False}

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)
    assert receipt["status"] == "incommensurable"
    assert receipt["measured_cosine_similarity"] < 0.1
    assert receipt["dimensional_projection_attempted"] is False


def test_dimensional_projection_fallback_success() -> None:
    """AGENTS.md: Validate Procrustes Analysis mathematical fallback without mock abstractions."""
    # Orthogonal spaces, but perfectly projectable via 90-degree rotation
    local_vectors = [[1.0, 0.0], [0.0, 1.0]]
    remote_vectors = [[0.0, 1.0], [-1.0, 0.0]]  # 90 degree rotated

    policy = {
        "min_cosine_similarity": 0.9,  # It will fail initially
        "max_earth_mover_distance": 5.0,
        "enable_dimensional_projection": True,
        "projection_tolerance": 0.9,
    }

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)

    # Must mathematically rotate back to align
    assert receipt["status"] == "aligned_via_projection"
    assert receipt["dimensional_projection_attempted"] is True
    assert "projected_cosine_similarity" in receipt
    assert receipt["projected_cosine_similarity"] > 0.9


def test_mismatched_dimensions_projection() -> None:
    """AGENTS.md: Check that dimensional projections handle 0-padding across shapes natively."""
    local_vectors = [[1.0, 0.0], [0.0, 1.0]]
    remote_vectors = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0]]  # Extra dimension

    policy = {"min_cosine_similarity": 0.9, "enable_dimensional_projection": True, "projection_tolerance": 0.99}

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)
    assert receipt["status"] == "aligned_via_projection"
    assert receipt["dimensional_projection_attempted"] is True


def test_empty_vectors_short_circuit() -> None:
    """Empty vectors immediately short circuit to incommensurable."""
    receipt = verify_ontological_isometry([], [], {})
    assert receipt["status"] == "incommensurable"
    assert receipt["reason"] == "Empty vector set(s) provided"


def test_mismatched_row_counts() -> None:
    """Different row counts flatten matrix."""
    local_vectors = [[1.0, 0.0], [0.0, 1.0]]
    remote_vectors = [[1.0, 0.0]]  # fewer vectors
    policy = {"min_cosine_similarity": 0.9, "enable_dimensional_projection": False}

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)
    # Cosine check averages the flattened pairwise matches
    assert "measured_cosine_similarity" in receipt


def test_mismatched_dimensions_remote_smaller_projection() -> None:
    """AGENTS.md: Check that dimensional projections handle 0-padding when remote is smaller natively."""
    local_vectors = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0]]  # Extra dimension
    remote_vectors = [[1.0, 0.0], [0.0, 1.0]]

    policy = {"min_cosine_similarity": 0.9, "enable_dimensional_projection": True, "projection_tolerance": 0.99}

    receipt = verify_ontological_isometry(local_vectors, remote_vectors, policy)
    assert receipt["status"] == "aligned_via_projection"
    assert receipt["dimensional_projection_attempted"] is True
