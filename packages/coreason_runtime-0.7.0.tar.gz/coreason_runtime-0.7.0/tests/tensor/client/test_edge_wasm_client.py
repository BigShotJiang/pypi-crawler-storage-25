# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for EdgeKineticClient.

Tests the offline-capable WASM inference client: initialization,
local SQLite CRDT buffer, offline event buffering, and local
inference execution with timeout-triggered buffering.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: TokenBurnReceipt and ObservationEvent payloads
constructed from coreason_manifest models and serialized via .model_dump(mode="json").
"""

import json
import sqlite3
import time
from contextlib import closing
from pathlib import Path
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ObservationEvent,
    TokenBurnReceipt,
)

from coreason_runtime.tensor.client.edge_wasm_client import EdgeKineticClient

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_token_burn_receipt(
    tokens: int = 120,
    tool_cid: str = "did:coreason:edge-wasm-tool",
) -> TokenBurnReceipt:
    """Construct a physically validated TokenBurnReceipt from the manifest."""
    return TokenBurnReceipt(
        event_cid=f"did:coreason:burn-{int(time.time_ns())}",
        timestamp=time.time(),
        tool_invocation_cid=tool_cid,
        input_tokens=tokens,
        output_tokens=0,
        burn_magnitude=tokens,
    )


def _build_observation_event(
    payload: dict[str, Any] | None = None,
) -> ObservationEvent:
    """Construct a physically validated ObservationEvent from the manifest."""
    return ObservationEvent(
        event_cid=f"did:coreason:obs-{int(time.time_ns())}",
        timestamp=time.time(),
        payload=payload or {"status": "success", "text": "edge_native_response"},
    )


# ── Helper: Create EdgeKineticClient with isolated tmp db ──────────────


def _create_client(tmp_path: Path, model_uri: str = "test-model.gguf") -> EdgeKineticClient:
    """Create an EdgeKineticClient with a tmp SQLite path to avoid filesystem collisions."""
    client = EdgeKineticClient(model_uri=model_uri)
    # Override the default /tmp path with a test-isolated path
    client._local_db_path = str(tmp_path / "edge_buffer.sqlite")
    client._init_local_buffer()
    return client


# ── Initialization Tests ───────────────────────────────────────────────


class TestEdgeKineticClientInit:
    """Physical tests for EdgeKineticClient initialization."""

    def test_creates_with_defaults(self, tmp_path: Path) -> None:
        client = _create_client(tmp_path)
        assert client.model_uri == "test-model.gguf"
        assert client.max_vram_buffer_bytes == 4 * 1024**3

    def test_creates_with_custom_vram(self, tmp_path: Path) -> None:
        client = EdgeKineticClient(model_uri="custom.gguf", max_vram_buffer_bytes=2 * 1024**3)
        client._local_db_path = str(tmp_path / "edge_buffer.sqlite")
        client._init_local_buffer()
        assert client.max_vram_buffer_bytes == 2 * 1024**3

    def test_sqlite_buffer_initialized(self, tmp_path: Path) -> None:
        """Verify the local SQLite CRDT buffer table is created."""
        client = _create_client(tmp_path)
        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='local_ledger'")
            tables = cursor.fetchall()
        assert len(tables) == 1


# ── Offline Event Buffering Tests ──────────────────────────────────────


class TestEdgeOfflineBuffering:
    """Physical tests for the CRDT offline event buffer with manifest-typed payloads."""

    @pytest.mark.asyncio
    async def test_buffer_token_burn_receipt(self, tmp_path: Path) -> None:
        """Buffer a manifest-validated TokenBurnReceipt."""
        client = _create_client(tmp_path)
        burn_receipt = _build_token_burn_receipt(tokens=100)
        payload = burn_receipt.model_dump(mode="json")

        await client.buffer_offline_event("TokenBurnReceipt", payload)

        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT event_type, payload, synced FROM local_ledger")
            rows = cursor.fetchall()

        assert len(rows) == 1
        assert rows[0][0] == "TokenBurnReceipt"
        stored_payload = json.loads(rows[0][1])
        assert stored_payload["input_tokens"] == 100
        assert stored_payload["burn_magnitude"] == 100
        assert stored_payload["event_cid"].startswith("did:coreason:")
        assert rows[0][2] == 0  # Not yet synced

    @pytest.mark.asyncio
    async def test_buffer_observation_event(self, tmp_path: Path) -> None:
        """Buffer a manifest-validated ObservationEvent."""
        client = _create_client(tmp_path)
        obs_event = _build_observation_event(payload={"result": "test"})
        payload = obs_event.model_dump(mode="json")

        await client.buffer_offline_event("ObservationEvent", payload)

        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT payload FROM local_ledger")
            stored = json.loads(cursor.fetchone()[0])

        assert stored["topology_class"] == "observation"
        assert stored["event_cid"].startswith("did:coreason:")

    @pytest.mark.asyncio
    async def test_buffer_multiple_events(self, tmp_path: Path) -> None:
        client = _create_client(tmp_path)

        for i in range(5):
            burn = _build_token_burn_receipt(tokens=i * 10)
            await client.buffer_offline_event(f"TokenBurn-{i}", burn.model_dump(mode="json"))

        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT COUNT(*) FROM local_ledger")
            count = cursor.fetchone()[0]

        assert count == 5

    @pytest.mark.asyncio
    async def test_buffer_preserves_timestamp(self, tmp_path: Path) -> None:
        client = _create_client(tmp_path)
        burn = _build_token_burn_receipt()
        await client.buffer_offline_event("TestEvent", burn.model_dump(mode="json"))

        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT timestamp FROM local_ledger")
            ts = cursor.fetchone()[0]

        assert ts > 0


# ── Local Inference Execution Tests ────────────────────────────────────


class TestEdgeLocalInference:
    """Physical tests for offline local inference execution."""

    @pytest.mark.asyncio
    async def test_execute_local_inference_returns_result(self, tmp_path: Path) -> None:
        client = _create_client(tmp_path)

        result = await client.execute_local_inference("What is 2+2?")

        assert result["status"] == "success"
        assert result["text"] == "edge_native_response"
        assert "reasoning_steps" in result

    @pytest.mark.asyncio
    async def test_execute_local_inference_buffers_events(self, tmp_path: Path) -> None:
        """Execution triggers offline buffering due to simulated timeout."""
        client = _create_client(tmp_path)

        await client.execute_local_inference("test prompt")

        with closing(sqlite3.connect(client._local_db_path)) as conn:
            cursor = conn.execute("SELECT event_type FROM local_ledger ORDER BY id")
            events = [row[0] for row in cursor.fetchall()]

        assert "TokenBurnReceipt" in events
        assert "ObservationEvent" in events

    @pytest.mark.asyncio
    async def test_execute_with_schema_requirement(self, tmp_path: Path) -> None:
        """Local inference accepts optional schema_requirement parameter."""
        client = _create_client(tmp_path)

        # Use a manifest-validated observation event's payload as the schema requirement
        obs = _build_observation_event()
        schema = obs.model_dump(mode="json")
        result = await client.execute_local_inference("test", schema)

        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_execute_local_inference_fatal_fault(self, tmp_path: Path) -> None:
        """Trigger the generic exception block by inducing a physical storage fault."""
        client = _create_client(tmp_path)
        # Induce a physical filesystem fault during sqlite connection
        client._local_db_path = "/dev/null/impossible.sqlite"

        with pytest.raises(Exception):  # noqa: B017
            await client.execute_local_inference("test")
