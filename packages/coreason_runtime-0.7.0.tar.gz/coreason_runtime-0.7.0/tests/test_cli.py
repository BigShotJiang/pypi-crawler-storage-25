# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

"""
Tests for the unified CLI daemon.
Zero unittest.mock or virtual state manipulation. All topological parameters are physically tested natively.
"""

import tempfile
from pathlib import Path

from typer.testing import CliRunner

from coreason_runtime.cli import app

runner = CliRunner()


def test_cli_help() -> None:
    """
    Verify the main CLI help menu renders successfully without errors natively.
    """
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Coreason Runtime CLI daemon." in result.stdout
    assert "start" in result.stdout
    assert "execute" in result.stdout


def test_cli_start_node() -> None:
    """
    Verify the start node command parses parameters securely directly passing the dry-run barrier.
    """
    result = runner.invoke(app, ["start", "node", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api() -> None:
    """
    Verify the start api command directly constructs API barriers parsing custom dry-run triggers.
    """
    result = runner.invoke(app, ["start", "api", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api_custom_port() -> None:
    """
    Verify passing a custom port cleanly executes the structural CLI paths.
    """
    result = runner.invoke(app, ["start", "api", "--port", "9090", "--dry-run"])
    assert result.exit_code == 0


def test_cli_start_api_invalid_port() -> None:
    """
    Verify typer natively rejects invalid non-integer port assignments.
    """
    result = runner.invoke(app, ["start", "api", "--port", "invalid_string", "--dry-run"])
    assert result.exit_code != 0
    import re

    clean_output = re.sub(r"\x1b\[[0-9;]*m", "", result.output)
    assert "Invalid value for '--port'" in clean_output


def test_cli_execute() -> None:
    """
    Verify the execute command aggressively declines fake files while propagating valid structures cleanly.
    """
    # Test with non-existent file
    result_invalid = runner.invoke(app, ["execute", "non_existent_file.json", "--dry-run"])
    assert result_invalid.exit_code != 0

    # Test with valid temporary file
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w") as tmp:
        tmp.write("{}")
        tmp.flush()

        tmp_path = Path(tmp.name)
        result_valid = runner.invoke(app, ["execute", str(tmp_path), "--dry-run"])
        assert result_valid.exit_code == 0


def test_cli_execute_with_query() -> None:
    """
    Verify exogenous perturbation bounds natively inject via the dry-run CLI boundary.
    """
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w") as tmp:
        tmp.write("{}")
        tmp.flush()
        result = runner.invoke(app, ["execute", str(Path(tmp.name)), "--query", "Hello Oracle", "--dry-run"])
        assert result.exit_code == 0


def test_create_app_incorporates_routers_idempotently() -> None:
    """
    Verify coreason_runtime.cli.create_app natively aggregates routes
    and performs prefix deduplication on hot reload natively.
    """
    from coreason_runtime.cli import create_app

    app_instance1 = create_app()
    app_instance2 = create_app()

    # Assert routes were natively included (e.g. oracle, predict, sandbox)
    routes = [getattr(r, "prefix", getattr(r, "path", "")) for r in app_instance2.router.routes]
    assert any("/api/v1/sandbox" in r for r in routes)
    assert app_instance1 is app_instance2
