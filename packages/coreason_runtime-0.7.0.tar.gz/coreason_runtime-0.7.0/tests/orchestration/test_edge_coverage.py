from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from coreason_manifest import PredictionMarketState
from pydantic import ValidationError

from coreason_runtime.orchestration.engine import CoreasonRuntime, _get_manifest_key
from coreason_runtime.orchestration.markets import settle_market


def test_engine_get_manifest_key() -> None:
    cls = MagicMock()
    cls.model_fields = {"topology_class": MagicMock(default="evaluator_optimizer")}
    assert _get_manifest_key(cls) == "evaluator_optimizer"


@pytest.mark.asyncio
async def test_engine_validation_error() -> None:
    engine = CoreasonRuntime()
    with patch(
        "coreason_runtime.orchestration.engine.WorkflowManifest.model_validate",
        side_effect=ValidationError.from_exception_data(title="", line_errors=[]),
    ):
        from coreason_runtime.utils.exceptions import ManifestConformanceError

        with pytest.raises(ManifestConformanceError):
            await engine.execute_from_dict({})


@pytest.mark.asyncio
async def test_engine_value_error_manifest() -> None:
    engine = CoreasonRuntime()
    with patch("coreason_runtime.orchestration.engine.WorkflowManifest.model_validate", side_effect=ValueError("bad")):
        with pytest.raises(ValueError, match="bad"):
            await engine.execute_from_dict({})


@pytest.mark.asyncio
async def test_engine_execute_null_return() -> None:
    engine = CoreasonRuntime()
    mock_manifest = MagicMock()
    mock_manifest.topology.compile_to_base_topology = None
    mock_manifest.topology.model_dump.return_value = {"type": "linear"}
    mock_manifest.genesis_provenance.model_dump.return_value = {}
    mock_manifest.pq_signature = MagicMock()
    mock_manifest.pq_signature.model_dump.return_value = {}
    mock_manifest.allowed_semantic_classifications = ["system_2"]
    mock_manifest.governance.model_dump.return_value = {"max_budget_magnitude": 500}
    mock_manifest.governance.max_budget_magnitude = 500

    with patch("temporalio.client.Client.connect", new_callable=AsyncMock) as mock_connect:
        client_mock = AsyncMock()
        mock_connect.return_value = client_mock
        handle_mock = AsyncMock()
        handle_mock.result.return_value = None
        client_mock.start_workflow.return_value = handle_mock
        with patch("coreason_runtime.orchestration.engine.WorkflowManifest.model_validate", return_value=mock_manifest):
            with patch("coreason_runtime.orchestration.engine.verify_genesis_provenance", return_value=True):
                with patch("coreason_runtime.orchestration.engine.verify_pq_signature", return_value=True):
                    with patch(
                        "coreason_runtime.orchestration.engine._WORKFLOW_REGISTRY", {"linear": "some_func_mock"}
                    ):
                        res = await engine.execute_from_dict({})
                        assert res == {}


@pytest.mark.asyncio
async def test_engine_execute_string_or_list_return() -> None:
    engine = CoreasonRuntime()
    mock_manifest = MagicMock()
    mock_manifest.topology.compile_to_base_topology = None
    mock_manifest.topology.model_dump.return_value = {"type": "linear"}
    mock_manifest.genesis_provenance.model_dump.return_value = {}
    mock_manifest.pq_signature = MagicMock()
    mock_manifest.pq_signature.model_dump.return_value = {}
    mock_manifest.allowed_semantic_classifications = ["system_2"]
    mock_manifest.governance.model_dump.return_value = {"max_budget_magnitude": 500}
    mock_manifest.governance.max_budget_magnitude = 500

    with patch("temporalio.client.Client.connect", new_callable=AsyncMock) as mock_connect:
        client_mock = AsyncMock()
        mock_connect.return_value = client_mock
        handle_mock = AsyncMock()
        handle_mock.result.return_value = "hello_world_not_dumpable_nor_dict"
        client_mock.start_workflow.return_value = handle_mock
        with patch("coreason_runtime.orchestration.engine.WorkflowManifest.model_validate", return_value=mock_manifest):
            with patch("coreason_runtime.orchestration.engine.verify_genesis_provenance", return_value=True):
                with patch("coreason_runtime.orchestration.engine.verify_pq_signature", return_value=True):
                    with patch(
                        "coreason_runtime.orchestration.engine._WORKFLOW_REGISTRY", {"linear": "some_func_mock"}
                    ):
                        res = await engine.execute_from_dict({})
                        assert res == {}


def test_settle_market_prediction_mode_fractional() -> None:
    mock_stake1 = MagicMock()
    mock_stake1.agent_cid = "agent1"
    mock_stake1.target_hypothesis_cid = "h1"
    mock_stake1.staked_magnitude = 1
    mock_stake2 = MagicMock()
    mock_stake2.agent_cid = "agent2"
    mock_stake2.target_hypothesis_cid = "h1"
    mock_stake2.staked_magnitude = 2
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="1.0",
        order_book=[mock_stake1, mock_stake2],
        current_market_probabilities={},
    )
    receipt = settle_market(state, "h1")
    assert receipt is not None


def test_settle_market_prediction_mode_agent_zero_stake() -> None:
    mock_stake1 = MagicMock()
    mock_stake1.agent_cid = "agent1"
    mock_stake1.target_hypothesis_cid = "h1"
    mock_stake1.staked_magnitude = 0
    mock_stake2 = MagicMock()
    mock_stake2.agent_cid = "agent2"
    mock_stake2.target_hypothesis_cid = "h1"
    mock_stake2.staked_magnitude = 1
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="1.0",
        order_book=[mock_stake1, mock_stake2],
        current_market_probabilities={"h1": "1.0"},
    )
    receipt = settle_market(state, "h1")
    assert receipt is not None
