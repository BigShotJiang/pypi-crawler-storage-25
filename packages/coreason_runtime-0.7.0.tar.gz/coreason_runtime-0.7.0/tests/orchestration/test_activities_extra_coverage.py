from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.orchestration.activities import (
    KineticActivities,
    execute_gaze_tracking_io_activity,
    execute_verify_hardware_enclave_activity,
    execute_verify_wetware_attestation_activity,
)


@pytest.fixture
def base_activities() -> KineticActivities:
    with (
        patch("coreason_runtime.orchestration.activities.MedallionStateEngine"),
        patch("coreason_runtime.orchestration.activities.EpistemicLedgerManager"),
        patch("coreason_runtime.orchestration.activities.LatentMemoryManager"),
        patch("coreason_runtime.orchestration.activities.WasmSandboxExecutor"),
        patch("coreason_runtime.orchestration.activities.TelemetryEmitter"),
        patch("coreason_runtime.orchestration.activities.MCPClientManager"),
        patch("coreason_runtime.orchestration.activities.TensorRouter"),
    ):
        return KineticActivities("dummy", "dummy", "dummy", "dummy")


@pytest.mark.asyncio
async def test_request_oracle_intervention_io_activity(base_activities: KineticActivities) -> None:
    res = await base_activities.request_oracle_intervention_io_activity("w1", "n1", {"a": 1})
    assert res["status"] == "oracle_requested"


@pytest.mark.asyncio
async def test_broadcast_state_echo_io_activity(base_activities: KineticActivities) -> None:
    res = await base_activities.broadcast_state_echo_io_activity("w1", {"a": 1})
    assert res["status"] == "echoed"


@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity_crystallize_failure(base_activities: KineticActivities) -> None:
    base_activities.ledger.crystallize_gold_state = AsyncMock(side_effect=Exception("Failed explicitly"))  # type: ignore[method-assign]
    res = await base_activities.store_epistemic_state_io_activity("w1", "intent1", True, {"error": "nope"})
    assert res["status"] == "crystallization_failed"


@pytest.mark.asyncio
async def test_store_epistemic_state_io_activity_bronze_committed(base_activities: KineticActivities) -> None:
    base_activities.ledger.commit_bronze_entropy = AsyncMock()  # type: ignore[method-assign]
    res = await base_activities.store_epistemic_state_io_activity("w1", "intent1", False, {"error": "nope"})
    assert res["status"] == "bronze_committed"


@pytest.mark.asyncio
async def test_execute_verify_wetware_attestation_activity() -> None:
    with (
        patch("coreason_runtime.orchestration.activities.Fido2Verifier"),
        patch("coreason_runtime.utils.security.resolve_did_public_key") as mock_resolve,
    ):
        mock_resolve.return_value = "pk"
        res = await execute_verify_wetware_attestation_activity(
            {"cryptographic_payload": "cp", "did_subject": "did", "liveness_challenge_hash": "hash"}
        )
        assert res["verification_status"] == "verified"


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity() -> None:
    with (
        patch("coreason_runtime.orchestration.activities.validate_normalized_vector"),
        patch("coreason_runtime.utils.security.verify_pq_signature", return_value=True),
        patch("coreason_runtime.orchestration.activities.intersect_ray_with_nodes", return_value=["node1"]),
    ):
        res = await execute_gaze_tracking_io_activity(
            {
                "origin": [0.0, 0.0, 0.0],
                "direction_unit_vector": [1.0, 0.0, 0.0],
                "hardware_signature": "sig",
                "active_bounding_boxes": [],
            }
        )
        assert res["trusted_hardware"] is True


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity_bad_direction() -> None:
    with pytest.raises(ValueError):
        await execute_gaze_tracking_io_activity(
            {
                "origin": [0.0, 0.0, 0.0],
                "direction_unit_vector": [1.0, 0.0],
                "hardware_signature": "sig",
                "active_bounding_boxes": [],
            }
        )


@pytest.mark.asyncio
async def test_execute_gaze_tracking_io_activity_bad_signature() -> None:
    with (
        patch("coreason_runtime.orchestration.activities.validate_normalized_vector"),
        patch("coreason_runtime.utils.security.verify_pq_signature", return_value=False),
    ):
        with pytest.raises(ValueError, match="Hardware gaze signature cleanly invalidated"):
            await execute_gaze_tracking_io_activity(
                {
                    "origin": [0.0, 0.0, 0.0],
                    "direction_unit_vector": [1.0, 0.0, 0.0],
                    "hardware_signature": "sig",
                    "active_bounding_boxes": [],
                }
            )


@pytest.mark.asyncio
async def test_execute_verify_hardware_enclave_activity() -> None:
    with patch("coreason_runtime.orchestration.activities.TEEVerifier"):
        res = await execute_verify_hardware_enclave_activity({})
        assert res["status"] == "HardwareEnclaveReceipt verified thoroughly"


@pytest.mark.asyncio
async def test_execute_rollback_io_activity(base_activities: KineticActivities) -> None:
    base_activities.ledger.execute_rollback = AsyncMock()  # type: ignore[method-assign]
    await base_activities.execute_rollback_io_activity("w1", {})
    base_activities.ledger.execute_rollback.assert_called_once()


@pytest.mark.asyncio
async def test_execute_tensor_inference_domain_and_shock_coverage(base_activities: KineticActivities) -> None:
    base_activities.tensor_router.route_inference = AsyncMock(  # type: ignore[method-assign]
        return_value=(
            MagicMock(model_dump=MagicMock(return_value={"custom": "val"})),
            {"usage": 1},
            0.5,
            10,
            "sig",
        )
    )
    res = await base_activities.execute_tensor_inference_compute_activity(
        "w1",
        {
            "node_profile": {
                "domain_extensions": {"CustomSchema": {"field1": "boolean flag", "field2": "string description"}},
                "runtime_context": {"latest_exogenous_shock": {"source_node": "a", "target_node": "b"}},
            },
            "immutable_matrix": {},
        },
        "CustomSchema",
    )
    assert res["outputs"] == {"custom": "val"}


@pytest.mark.asyncio
async def test_execute_tensor_inference_exceptions(base_activities: KineticActivities) -> None:
    from coreason_runtime.tensor.router import BudgetExceededError

    base_activities.tensor_router.route_inference = AsyncMock(side_effect=BudgetExceededError("budget"))  # type: ignore[method-assign]
    res = await base_activities.execute_tensor_inference_compute_activity(
        "1", {"immutable_matrix": {"upstream_dependencies": []}}, "AgentResponse"
    )
    assert res["reason"] == "budget_exceeded"

    base_activities.tensor_router.route_inference = AsyncMock(side_effect=Exception("panic"))  # type: ignore[method-assign]
    res2 = await base_activities.execute_tensor_inference_compute_activity(
        "1", {"immutable_matrix": {"upstream_dependencies": []}}, "AgentResponse"
    )
    assert res2["reason"] == "execution_panic"


@pytest.mark.asyncio
async def test_execute_mcp_tool_action_space_colon(base_activities: KineticActivities) -> None:
    base_activities.sandbox.execute_actuator = AsyncMock(return_value={"success": True})  # type: ignore[method-assign]
    base_activities.ledger.fetch_action_space_manifest = AsyncMock(return_value=None)  # type: ignore[method-assign]
    res = await base_activities.execute_mcp_tool_io_activity("t1", {}, {"action_space_cid": "custom:tool"})
    assert res["receipt"]["success"] is True


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.activities.MCPClientIntent")
async def test_execute_mcp_tool_intent_conformance_error(mock_intent: Any, base_activities: KineticActivities) -> None:
    from coreason_runtime.utils.exceptions import ManifestConformanceError

    mock_intent.model_construct.side_effect = Exception("Intentionally fail")
    with pytest.raises(ManifestConformanceError):
        await base_activities.execute_mcp_tool_io_activity("t1", {"valid": "payload"}, None)


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.activities.LatentProjectionIntent")
async def test_store_epistemic_state_io_activity_gold_commit(
    mock_latent: Any, base_activities: KineticActivities
) -> None:
    base_activities.ledger.crystallize_gold_state = AsyncMock()  # type: ignore[method-assign]
    base_activities._generate_dense_vector = AsyncMock(return_value=[0.1])  # type: ignore[method-assign]
    base_activities.latent.upsert_projection = AsyncMock()  # type: ignore[method-assign]

    mock_intent = MagicMock()
    mock_intent.model_dump_json.return_value = "{}"
    mock_latent.model_validate.return_value = mock_intent

    payload = {"request_cid": "cid1", "inputs": {}, "outputs": {}}
    await base_activities.store_epistemic_state_io_activity("w1", "intent1", True, payload, latent_payload={"dummy": 1})
    base_activities.ledger.crystallize_gold_state.assert_called_once()
    base_activities.latent.upsert_projection.assert_called_once()


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.activities.LatentProjectionIntent")
async def test_store_epistemic_state_latent_and_scrub(mock_latent: Any, base_activities: KineticActivities) -> None:
    base_activities._generate_dense_vector = AsyncMock(return_value=[0.1])  # type: ignore[method-assign]
    base_activities.latent.upsert_projection = AsyncMock()  # type: ignore[method-assign]
    base_activities.ledger.crystallize_gold_state = AsyncMock()  # type: ignore[method-assign]

    mock_intent = MagicMock()
    mock_intent.model_dump_json.return_value = "{}"
    mock_latent.model_validate.return_value = mock_intent

    await base_activities.store_epistemic_state_io_activity(
        "w1",
        "intent",
        True,
        {
            "float_val": float("inf"),
            "request_cid": "cid2",
            "inputs": {},
            "outputs": {},
            "nested": [float("-inf"), {"x": float("inf")}],
        },
        {"dummy": "latent"},
    )
