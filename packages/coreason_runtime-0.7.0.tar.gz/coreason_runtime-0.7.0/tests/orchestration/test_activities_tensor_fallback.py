from pathlib import Path

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.fixture
def test_activities(tmp_path: Path) -> KineticActivities:
    return KineticActivities(
        sglang_url="http://localhost:30000",
        memory_path=str(tmp_path / "lancedb_test"),
        plugins_dir="/tmp/plugins",
        telemetry_url="http://localhost:4317",
    )


@pytest.mark.asyncio
async def test_execute_tensor_inference_scalar_fallback(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    async def mock_route_inference(*args: object, **kwargs: object) -> tuple[str, dict[str, int], float, int, bytes]:
        # Return a scalar string to trigger `if not isinstance(result_json, dict): result_json = {"raw": result_json}`
        return ("NonDictString", {"total_tokens": 10}, 0.0, 10, b"")

    monkeypatch.setattr(test_activities.tensor_router, "route_inference", mock_route_inference)

    result = await test_activities.execute_tensor_inference_compute_activity(
        workflow_id="test-wf",
        payload={"immutable_matrix": {"test": "data"}},
        schema_type_name="AgentResponse",
    )

    assert result["outputs"] == {"raw": "NonDictString"}
    assert result["usage"] == {"total_tokens": 10}
