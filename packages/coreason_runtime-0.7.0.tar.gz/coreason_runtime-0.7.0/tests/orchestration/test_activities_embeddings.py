from pathlib import Path

import httpx
import pytest

from coreason_runtime.orchestration.activities import KineticActivities
from coreason_runtime.tensor.router import EpistemicYieldError


class MockResponse:
    def __init__(self, json_data: dict[str, object], status_code: int = 200) -> None:
        self._json = json_data
        self.status_code = status_code

    def json(self) -> dict[str, object]:
        return self._json

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            request = httpx.Request("POST", "http://test")
            response = httpx.Response(self.status_code, request=request)
            raise httpx.HTTPStatusError("Error", request=request, response=response)


@pytest.fixture
def test_activities(tmp_path: Path) -> KineticActivities:
    return KineticActivities(
        sglang_url="http://localhost:30000",
        memory_path=str(tmp_path / "lancedb_test"),
        plugins_dir="/tmp/plugins",
        telemetry_url="http://localhost:4317",
    )


@pytest.mark.asyncio
async def test_generate_dense_vector_success(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key")
    monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://test-oracle")
    monkeypatch.setenv("CLOUD_ORACLE_EMBEDDING_MODEL", "test-model")

    async def mock_post(*args: object, **kwargs: object) -> MockResponse:
        return MockResponse({"data": [{"embedding": [0.1, 0.2, 0.3]}]})

    monkeypatch.setattr("httpx.AsyncClient.post", mock_post)

    vector = await test_activities._generate_dense_vector("test text")
    assert vector == [0.1, 0.2, 0.3]


@pytest.mark.asyncio
async def test_generate_dense_vector_missing_env(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("CLOUD_ORACLE_API_KEY", raising=False)
    monkeypatch.delenv("CLOUD_ORACLE_BASE_URL", raising=False)

    with pytest.raises(EpistemicYieldError, match="Embedding API failure"):
        await test_activities._generate_dense_vector("test text")


@pytest.mark.asyncio
async def test_generate_dense_vector_httpx_failure(
    test_activities: KineticActivities, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key")
    monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://test-oracle")
    monkeypatch.setenv("CLOUD_ORACLE_EMBEDDING_MODEL", "test-model")

    async def mock_post_fail(*args: object, **kwargs: object) -> MockResponse:
        raise httpx.ConnectError("Connection failed")

    monkeypatch.setattr("httpx.AsyncClient.post", mock_post_fail)

    with pytest.raises(EpistemicYieldError, match="Embedding API failure"):
        await test_activities._generate_dense_vector("test text")
