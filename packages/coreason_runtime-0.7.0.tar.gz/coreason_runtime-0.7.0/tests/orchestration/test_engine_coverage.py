# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License") # pragma: no cover
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import concurrent.futures
import json
from typing import Any

import httpx
import pytest
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    DAGTopologyManifest,
    DerivationModeProfile,
    EpistemicProvenanceReceipt,
    WorkflowManifest,
)
from temporalio import activity, workflow
from temporalio.client import WorkflowFailureError
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.engine import CoreasonRuntime
from coreason_runtime.orchestration.worker import TASK_QUEUE
from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any) -> None:
    pass


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def stub_execute_tensor(*args: Any) -> dict[str, Any]:
    return {
        "status": "success",
        "outputs": {"result": "ok"},
        "intent_hash": "hash1",
        "usage": {"total_tokens": 10},
        "cost": 0.5,
        "success": True,
    }


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_burn(*args: Any) -> None:
    pass


@activity.defn(name="ApplyDefeasibleCascadeComputeActivity")
async def stub_cascade(*args: Any) -> None:
    pass


@activity.defn(name="ExecuteRollbackIOActivity")
async def stub_rollback(*args: Any) -> None:
    pass


@activity.defn(name="FetchMemoizedStateIOActivity")
async def stub_memo(*args: Any) -> dict[str, Any] | None:
    return None


@activity.defn(name="ExecuteSystemFunctionComputeActivity")
async def stub_sys_func(*args: Any) -> dict[str, Any]:
    return {"status": "success"}


@workflow.defn
class DummyNoneWorkflow:
    @workflow.run
    async def run(self, _envelope: dict[str, Any]) -> Any:
        return None


@workflow.defn
class DummyStringWorkflow:
    @workflow.run
    async def run(self, _envelope: dict[str, Any]) -> Any:
        return "not_a_dict"


ALL_STUBS = [
    stub_store_epistemic,
    stub_execute_tensor,
    stub_record_burn,
    stub_cascade,
    stub_rollback,
    stub_memo,
    stub_sys_func,
]


async def asgi_app(scope: Any, receive: Any, send: Any) -> None:
    assert scope["type"] == "http"
    if scope["method"] == "POST":
        body = b""
        more_body = True
        while more_body:
            message = await receive()
            body += message.get("body", b"")
            more_body = message.get("more_body", False)

        path = scope["path"]
        response_body: dict[str, Any] = {}
        if "transmute" in path:
            response_body = {"success": True, "rust_efficiency_multiplier": 2.0}
        elif "publish" in path:
            response_body = {"urn": "urn:did:coreason:mcp:test"}
        else:
            response_body = {"status": "unknown"}

        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [(b"content-type", b"application/json")],
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": json.dumps(response_body).encode("utf-8"),
            }
        )


@pytest.fixture
def mock_transport() -> httpx.ASGITransport:
    return httpx.ASGITransport(app=asgi_app)


@pytest.fixture
def failing_transport() -> httpx.AsyncHTTPTransport:
    # Closed port to trigger httpx.RequestError naturally
    return httpx.AsyncHTTPTransport(local_address="127.0.0.1")


def _build_valid_manifest_dict(topology_class: str = "dag") -> dict[str, Any]:
    """Build a minimal valid WorkflowManifest dictionary."""

    provenance = EpistemicProvenanceReceipt(
        extracted_by="did:coreason:test-user",
        source_event_cid="test-session-001",
        derivation_mode=DerivationModeProfile.DIRECT_TRANSLATION,
    )

    if topology_class == "dag":
        topo = DAGTopologyManifest(
            topology_class="dag",
            max_depth=10,
            max_fan_out=5,
            nodes={
                "did:coreason:node-alpha": CognitiveAgentNodeProfile(
                    topology_class="agent",
                    description="Test agent node.",
                ),
            },
            edges=[],
        )
    else:
        from coreason_manifest.spec.ontology import SwarmTopologyManifest

        topo = SwarmTopologyManifest(
            topology_class="swarm",  # type: ignore
            spawning_threshold=1,
            nodes={},
        )

    manifest = WorkflowManifest(
        manifest_version="1.0.0",
        tenant_cid="test-tenant",
        session_cid="test-session",
        topology=topo,
        genesis_provenance=provenance,
    )

    payload = manifest.model_dump(mode="json")
    if "nodes" in payload["topology"]:
        for n_data in payload["topology"]["nodes"].values():
            n_data.pop("type", None)

    # Natively inject previously unreached logic boundaries
    payload["allowed_semantic_classifications"] = ["public"]
    payload["governance"] = {
        "mandatory_license_rule": {
            "rule_cid": "rule-1",
            "description": "desc",
            "severity": "critical",
            "forbidden_intents": [],
        },
        "max_budget_magnitude": 1000,
        "max_global_tokens": 1000,
        "global_timeout_seconds": 100,
    }

    if topology_class == "composite":
        # Force composite AFTER dumping so swarm dump succeeds, composite tests fallback to lanceDB natively
        payload["topology"]["topology_class"] = "composite"
    elif topology_class == "UNKNOWN_SYS":
        payload["topology"]["topology_class"] = "UNKNOWN_SYS"

    return payload


from temporalio import workflow


@workflow.defn(name="DummySwarmWorkflow")
class DummySwarmWorkflow:
    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        _ = payload
        return {"status": "success", "success": True, "manifest": {"server_cid": "crystalline_test-session"}}


@pytest.mark.asyncio
async def test_engine_execute_full_coverage(mock_transport: httpx.ASGITransport) -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime(network_transport=mock_transport)
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("dag")
            res = await engine.execute_from_dict(payload, exogenous_perturbation_vector="PERTURB")
            assert res.get("status") == "success"


from temporalio import workflow


@pytest.mark.asyncio
async def test_engine_execute_swarm_ecosystem_publish(mock_transport: httpx.ASGITransport) -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime(network_transport=mock_transport)
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DummySwarmWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("swarm")
            from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY

            _WORKFLOW_REGISTRY["swarm"] = DummySwarmWorkflow.run

            try:
                res = await engine.execute_from_dict(payload)
                assert "_crystalized_promotion" in res
                assert res["_crystalized_promotion"]["crystallized_semantic_node_cid"] == "crystalline_test-session"
            finally:
                del _WORKFLOW_REGISTRY["swarm"]


@pytest.mark.asyncio
async def test_engine_execute_swarm_ecosystem_connection_error(
    failing_transport: httpx.AsyncHTTPTransport, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("ECOSYSTEM_REGISTRY_URL", "http://127.0.0.1:44445")
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime(network_transport=failing_transport)
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DummySwarmWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("swarm")
            from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY

            _WORKFLOW_REGISTRY["swarm"] = DummySwarmWorkflow.run

            try:
                res = await engine.execute_from_dict(payload)
                assert "_crystalized_promotion" in res
            finally:
                del _WORKFLOW_REGISTRY["swarm"]


@pytest.mark.asyncio
async def test_engine_execute_fails_workflow_registry() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime()
        engine._client = env.client
        payload = _build_valid_manifest_dict("dag")

        from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY

        orig = _WORKFLOW_REGISTRY.pop("dag", None)
        try:
            with pytest.raises(ValueError, match="Unknown or missing manifest type: dag"):
                await engine.execute_from_dict(payload)
        finally:
            if orig:
                _WORKFLOW_REGISTRY["dag"] = orig


@pytest.mark.asyncio
async def test_engine_execute_temporal_failure() -> None:
    # Physically test temporal failure by invoking a failing workflow

    @activity.defn(name="StoreEpistemicStateIOActivity")
    async def bad_store(*args: Any) -> None:
        raise RuntimeError("BudgetExhaustion")

    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime()
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=[a for a in ALL_STUBS if getattr(a, "__name__", "") != "stub_store_epistemic"] + [bad_store],
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            payload = _build_valid_manifest_dict("dag")

            with pytest.raises(WorkflowFailureError):
                await engine.execute_from_dict(payload)


@pytest.mark.asyncio
async def test_engine_empty_dict_fallback() -> None:
    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime()
        engine._client = env.client
        payload = _build_valid_manifest_dict("dag")

        from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY

        orig_dag = _WORKFLOW_REGISTRY.get("dag")

        try:
            _WORKFLOW_REGISTRY["dag"] = DummyNoneWorkflow.run

            async with Worker(
                env.client,
                task_queue="coreason-kinetic-queue",
                workflows=[DummyNoneWorkflow],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                res = await engine.execute_from_dict(payload)
                assert res == {}

            _WORKFLOW_REGISTRY["dag"] = DummyStringWorkflow.run

            async with Worker(
                env.client,
                task_queue="coreason-kinetic-queue",
                workflows=[DummyStringWorkflow],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                res2 = await engine.execute_from_dict(payload)
                assert res2 == {}

        finally:
            if orig_dag:
                _WORKFLOW_REGISTRY["dag"] = orig_dag


@pytest.mark.asyncio
async def test_engine_execute_file(tmp_path: Any) -> None:
    p = tmp_path / "manifest.json"
    data = _build_valid_manifest_dict("dag")
    p.write_text(json.dumps(data))

    async with await WorkflowEnvironment.start_time_skipping() as env:
        engine = CoreasonRuntime()
        engine._client = env.client

        async with Worker(
            env.client,
            task_queue=TASK_QUEUE,
            workflows=[DAGExecutionWorkflow],
            activities=ALL_STUBS,
            workflow_runner=UnsandboxedWorkflowRunner(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(),
        ):
            res = await engine.execute(str(p))
            assert res.get("status") == "success"


@pytest.mark.asyncio
async def test_engine_execute_file_not_found() -> None:
    engine = CoreasonRuntime()
    with pytest.raises(FileNotFoundError):
        await engine.execute("/tmp/missing_manifest_123.json")
