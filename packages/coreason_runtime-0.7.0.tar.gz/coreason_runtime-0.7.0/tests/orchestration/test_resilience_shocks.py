# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import asyncio
from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.activities import (
    KineticActivities,
)
from coreason_runtime.orchestration.workflows.dag_execution_workflow import DAGExecutionWorkflow
from coreason_runtime.orchestration.workflows.digital_twin_execution_workflow import DigitalTwinExecutionWorkflow


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Mock the ledger state storage."""
    return {"status": "success"}


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def mock_execute_tensor(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Mock tensor execution."""
    await asyncio.sleep(0.5)
    return {"status": "success", "cost": 0.0, "usage": {}}


@activity.defn(name="RecordTokenBurnIOActivity")
async def mock_record_token_burn(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Mock token burn receipt recording."""
    return {"status": "success"}


@activity.defn(name="BroadcastStateEchoIOActivity")
async def mock_broadcast_echo(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Mock broadcast state."""
    return {"status": "success"}


@activity.defn(name="ResolveGenerativeSchemaComputeActivity")
async def mock_resolve_schema(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    """Mock schema resolution."""
    return {"status": "success", "rendered_schema": {}}


@pytest.mark.asyncio
async def test_barge_in_interrupt_cancels_execution() -> None:
    """Test that Barge-In signal structurally halts sequences writing Epistemic Rejections."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="test-barge-in-queue",
            workflows=[DAGExecutionWorkflow],
            activities=[
                mock_store_epistemic_state,
                mock_execute_tensor,
                mock_record_token_burn,
                mock_broadcast_echo,
                mock_resolve_schema,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            payload = {
                "trace_context": {
                    "trace_cid": "01HGR5XZ5YZZXW32B2T54MQP7Y",
                    "span_cid": "01HGR5Y05ZZZXW32B2T54MQP7Z",
                },
                "state_vector": {"immutable_matrix": {}, "mutable_matrix": {}},
                "payload": {
                    "topology_class": "dag",
                    "max_depth": 1,
                    "max_fan_out": 1,
                    "nodes": {
                        "did:test:node123": {
                            "topology_class": "agent",
                            "description": "mock description",
                            "action_space_cid": "action123",
                        }
                    },
                },
            }

            workflow_handle = await env.client.start_workflow(
                DAGExecutionWorkflow.run,
                payload,
                id="test-barge-in",
                task_queue="test-barge-in-queue",
            )

            interrupt_payload = {
                "event_cid": "interrupt-test",
                "topology_class": "barge_in",
                "target_event_cid": "did:test:node123",
                "timestamp": 1234567890.0,
                "epistemic_disposition": "discard",
            }

            await asyncio.sleep(0.1)
            await workflow_handle.signal("barge_in_interrupt", interrupt_payload)

            is_interrupted = await workflow_handle.query("is_interrupted")
            assert is_interrupted is True


@pytest.mark.asyncio
async def test_exogenous_shock_digital_twin_pivots() -> None:
    """Ensure exogenous shocks natively trigger ExecuteExogenousShockComputeActivity."""
    shock_activity = KineticActivities(
        sglang_url="http://mock", memory_path="/tmp", plugins_dir="/tmp", telemetry_url="http://mock"
    )

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="test-shock-queue",
            workflows=[DigitalTwinExecutionWorkflow],
            activities=[
                mock_store_epistemic_state,
                mock_execute_tensor,
                mock_record_token_burn,
                mock_broadcast_echo,
                shock_activity.execute_exogenous_shock_compute_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            payload = {
                "trace_context": {
                    "trace_cid": "01HGR5XZ5YZZXW32B2T54MQP7Y",
                    "span_cid": "01HGR5Y05ZZZXW32B2T54MQP7Z",
                },
                "state_vector": {"immutable_matrix": {}, "mutable_matrix": {}},
                "payload": {
                    "topology_class": "digital_twin",
                    "target_topology_cid": "twin-cid123",
                    "convergence_sla": {"max_monte_carlo_rollouts": 2, "variance_tolerance": 0.05},
                    "enforce_no_side_effects": True,
                    "nodes": {
                        "did:test:node456": {
                            "topology_class": "agent",
                            "description": "simulation target",
                            "action_space_cid": "simulation_space",
                        }
                    },
                },
            }

            workflow_handle = await env.client.start_workflow(
                DigitalTwinExecutionWorkflow.run,
                payload,
                id="test-digital-twin-shock",
                task_queue="test-shock-queue",
            )

            shock_payload = {
                "event_cid": "swan-event-001",
                "timestamp": 1234567890.0,
                "shock_cid": "swan-001",
                "target_node_hash": "a" * 64,
                "bayesian_surprise_score": 0.9,
                "synthetic_payload": {"chaos": True},
                "escrow": {"locked_magnitude": 500},
            }

            shock_payload_rejected = {
                "event_cid": "swan-event-002",
                "timestamp": 1234567891.0,
                "shock_cid": "swan-002",
                "target_node_hash": "b" * 64,
                "bayesian_surprise_score": 0.01,
                "synthetic_payload": {"chaos": False},
                "escrow": {"locked_magnitude": 100},
            }

            await workflow_handle.signal("inject_exogenous_shock", shock_payload)
            await workflow_handle.signal("inject_exogenous_shock", shock_payload_rejected)

            result = await workflow_handle.result()
            assert result["status"] == "success"
