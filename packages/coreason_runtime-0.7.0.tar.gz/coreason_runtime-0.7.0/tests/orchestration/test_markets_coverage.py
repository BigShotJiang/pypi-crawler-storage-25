from unittest.mock import MagicMock, patch

import pytest
from coreason_manifest import PredictionMarketState

from coreason_runtime.orchestration.markets import (
    calculate_lmsr_price,
    resolve_auction,
    settle_market,
    settle_prediction_market,
)


def test_settle_prediction_market_invalid_lmsr_b() -> None:
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="not_a_float",
        order_book=[],
        current_market_probabilities={"h1": "1.0"},
    )
    res = settle_prediction_market(state)
    assert res.lmsr_b_parameter == "not_a_float"


def test_settle_prediction_market_negative_b() -> None:
    mock_stake = MagicMock()
    mock_stake.target_hypothesis_cid = "h1"
    mock_stake.staked_magnitude = 10
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="-5.0",
        order_book=[mock_stake],
        current_market_probabilities={"h1": "0.1", "h2": "0.9"},
    )
    res = settle_prediction_market(state)
    assert float(res.current_market_probabilities["h1"]) > 0


def test_settle_prediction_market_no_stakes_no_probs() -> None:
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={},
    )
    res = settle_prediction_market(state)
    assert res.current_market_probabilities == {}


def test_settle_prediction_market_empty_orderbook_has_probs() -> None:
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={"h1": "0.5", "h2": "0.5"},
    )
    res = settle_prediction_market(state)
    assert res.current_market_probabilities["h1"] == "0.5"


def test_calculate_lmsr_price_zero_exp() -> None:
    with patch("math.exp", return_value=0.0):
        val = calculate_lmsr_price(100.0, {"h1": 1}, "h1")
        assert val == 0.0


def test_calculate_lmsr_price_negative_b() -> None:
    val = calculate_lmsr_price(-5.0, {"h1": 10}, "h1")
    assert val > 0.0


def test_calculate_lmsr_price_missing_target() -> None:
    val = calculate_lmsr_price(10.0, {"h1": 10}, "h2")
    assert val < 1.0


def test_settle_market_prediction_mode() -> None:
    mock_stake = MagicMock()
    mock_stake.agent_cid = "agent1"
    mock_stake.target_hypothesis_cid = "h1"
    mock_stake.staked_magnitude = 100
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[mock_stake],
        current_market_probabilities={"h1": "0.5"},
    )
    receipt = settle_market(state, "h1")
    assert receipt.awarded_syndicate.get("agent1") is not None


def test_settle_market_prediction_mode_zero_stake() -> None:
    state = PredictionMarketState.model_construct(
        market_cid="m1",
        resolution_oracle_condition_cid="or1",
        lmsr_b_parameter="5.0",
        order_book=[],
        current_market_probabilities={"h1": "0.5"},
    )
    # Target target is evaluated, but no stakes exist
    with pytest.raises(ValueError, match="Cannot settle market: No participants in the order book."):
        settle_market(state, "h1")


def test_settle_auction_no_bids() -> None:
    state = MagicMock()
    state.announcement.max_budget_magnitude = 100
    state.bids = []
    policy = MagicMock(auction_type="vickrey")
    with pytest.raises(ValueError, match="Cannot resolve auction: No bids available."):
        resolve_auction(state, policy)


def test_settle_auction_no_valid_bids() -> None:
    state = MagicMock()
    state.announcement.max_budget_magnitude = 100
    state.bids = [MagicMock(agent_cid="a1", estimated_cost_magnitude=200, confidence_score=0.9)]
    policy = MagicMock(auction_type="vickrey")
    with pytest.raises(ValueError, match="Cannot resolve auction: No bids satisfy the constraints."):
        resolve_auction(state, policy)


def test_settle_auction_vickrey_mode() -> None:
    state = MagicMock()
    state.announcement.max_budget_magnitude = 100
    state.announcement.task_cid = "task1"
    state.bids = [
        MagicMock(agent_cid="a1", estimated_cost_magnitude=50, confidence_score=0.9),
        MagicMock(agent_cid="a2", estimated_cost_magnitude=60, confidence_score=0.9),
    ]
    policy = MagicMock(auction_type="vickrey")
    receipt = resolve_auction(state, policy)
    assert receipt.cleared_price_magnitude == 60
    assert "a1" in receipt.awarded_syndicate


def test_settle_auction_first_price_mode() -> None:
    state = MagicMock()
    state.announcement.max_budget_magnitude = 100
    state.announcement.task_cid = "task1"
    state.bids = [
        MagicMock(agent_cid="a1", estimated_cost_magnitude=50, confidence_score=0.9),
        MagicMock(agent_cid="a2", estimated_cost_magnitude=60, confidence_score=0.9),
    ]
    policy = MagicMock(auction_type="first_price")
    receipt = resolve_auction(state, policy)
    assert receipt.cleared_price_magnitude == 50
