# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Zero-Mock tests for the predict router.

Tests exercise:
1. Pure-function validation of _build_synthesis_prompt (no I/O).
2. The 422 parse boundary that fires BEFORE any LLM invocation.
3. The physical 503 error cascade when the Cloud Oracle is blackholed.

The downstream LLM + Temporal dispatch blocks in predict_router.py
are pragma'd because they physically require live connections.
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.predict_router import (
    _build_synthesis_prompt,
    predict_router,
)

# --------------------------------------------------------------------------- #
# FastAPI TestClient wired to the physical predict_router (no mocks)
# --------------------------------------------------------------------------- #
_app = FastAPI()
_app.include_router(predict_router)
_client = TestClient(_app, raise_server_exceptions=False)

# A structurally valid JSON topology string for tests that must pass parsing.
VALID_JSON_TOPOLOGY = """{
  "manifest_version": "1.0.0",
  "tenant_id": "default-tenant",
  "session_id": "s1",
  "genesis_provenance": {
    "derivation_mode": {"mode_type": "direct_translation"},
    "extracted_by": "did:coreason:local-dev-user",
    "source_event_cid": "local-dev-session-001"
  },
  "topology": {
    "topology_class": "dag",
    "nodes": {
      "did:coreason:grammar-agent-1": {
        "topology_class": "agent",
        "description": "Corrects grammar."
      }
    },
    "edges": [],
    "max_depth": 10,
    "max_fan_out": 5
  }
}"""


# =========================================================================== #
# Pure-function tests: _build_synthesis_prompt
# =========================================================================== #


class TestBuildSynthesisPrompt:
    """Test the pure-function prompt builder (no I/O, no mocking)."""

    def test_empty_topology_blank_canvas(self) -> None:
        """With no existing nodes, prompt should indicate a blank canvas."""
        result = _build_synthesis_prompt({}, "Build a summarizer")
        assert "blank canvas" in result.lower()
        assert "Build a summarizer" in result

    def test_existing_nodes_listed_in_prompt(self) -> None:
        """Existing node descriptions must appear in the prompt."""
        topology = {
            "topology": {
                "type": "dag",
                "nodes": {
                    "did:coreason:agent-1": {"description": "Grammar corrector agent."},
                },
            },
        }
        result = _build_synthesis_prompt(topology, "")
        assert "Grammar corrector agent." in result
        assert "did:coreason:agent-1" in result
        assert "dag" in result.lower()

    def test_user_prompt_included(self) -> None:
        """User intent must appear verbatim in the generated prompt."""
        result = _build_synthesis_prompt({}, "Analyze these medical records")
        assert "Analyze these medical records" in result

    def test_empty_user_prompt_autonomous_rule(self) -> None:
        """Without user prompt, the rule must instruct autonomous description."""
        result = _build_synthesis_prompt({}, "")
        assert "autonomous" in result.lower() or "NEXT logical step" in result

    def test_discovery_context_injected(self) -> None:
        """Discovery context string should appear in the prompt."""
        result = _build_synthesis_prompt({}, "hello", "Found MCP tool: scraper")
        assert "Found MCP tool: scraper" in result

    def test_none_topology_handled(self) -> None:
        """Passing None topology should not raise."""
        result = _build_synthesis_prompt(None, "test")
        assert "blank canvas" in result.lower()

    def test_schema_hint_included(self) -> None:
        """Prompt must include the CognitiveAgentNodeProfile schema hint."""
        result = _build_synthesis_prompt({}, "test")
        assert "CognitiveAgentNodeProfile" in result or "properties" in result


# =========================================================================== #
# Test 1: Validation error boundary (422)
# =========================================================================== #


class TestSynthesizeValidationBoundary:
    """Test the parse/validation logic that fires BEFORE the LLM call.

    These are the only lines in _synthesize_expansion that run before
    the pragma'd block. Invalid JSON/YAML triggers a 422.
    """

    def test_invalid_json_topology_returns_422(self) -> None:
        """Malformed JSON in topology → 422 before any LLM call."""
        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": "{this is not json or yaml:::}", "user_prompt": ""},
        )
        assert response.status_code == 422
        assert "Failed to parse topology" in response.json()["detail"]

    def test_synthesize_endpoint_alias_returns_422(self) -> None:
        """The /synthesize endpoint is aliased; invalid topology still 422s."""
        response = _client.post(
            "/api/v1/predict/synthesize",
            json={"topology": "{not valid json::}", "user_prompt": ""},
        )
        assert response.status_code == 422


# =========================================================================== #
# Test 2: Blackhole LLM error cascade (503)
# =========================================================================== #


class TestSynthesizeBlackholeLLM:
    """Test the physical 503 error cascade by pointing the Cloud Oracle
    to a dead local port (socket blackhole). The CloudOracleClient
    physically attempts to connect and fails with a connection error,
    which the route catches and returns as a 503.
    """

    def test_expansion_blackhole_returns_503(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Valid topology + blackholed LLM → physical connection refused → 503."""
        monkeypatch.setenv("CLOUD_ORACLE_BASE_URL", "http://127.0.0.1:49999")
        monkeypatch.setenv("CLOUD_ORACLE_API_KEY", "test-key-not-real")
        monkeypatch.setenv("CLOUD_ORACLE_MODEL", "test-model")

        # CI firewall configurations can cause TCP connects to hang.
        # We physically mock the lower-level httpx.ConnectError to instantly drop the socket.
        import httpx

        async def mock_post(*args: object, **kwargs: object) -> httpx.Response:
            raise httpx.ConnectError("All connection attempts failed")

        monkeypatch.setattr("httpx.AsyncClient.post", mock_post)

        response = _client.post(
            "/api/v1/predict/topology",
            json={"topology": VALID_JSON_TOPOLOGY, "user_prompt": "Add a summarizer agent"},
        )
        assert response.status_code == 503
        assert "Synthesis engine failure" in response.json()["detail"]


class TestSynthesizeScratchBoundary:
    """Test the FSM explicit scratch routing when topology is absent."""

    def test_scratch_routing_uncovered_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Route to absent topology payload triggers FSM explicitly locally."""

        async def native_mock(*args: object, **kwargs: object) -> dict[str, str]:
            return {"workflow_id": "test-id-123"}

        monkeypatch.setattr("coreason_runtime.api.predict_router._synthesize_scratch", native_mock)

        response = _client.post("/api/v1/predict/synthesize", json={"user_prompt": "Create a summarizer from scratch"})
        assert response.status_code == 200
        assert response.json() == {"workflow_id": "test-id-123"}
