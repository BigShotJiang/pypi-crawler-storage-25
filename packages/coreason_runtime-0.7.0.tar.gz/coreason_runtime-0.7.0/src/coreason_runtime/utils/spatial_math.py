# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64
import math
from typing import Any


def vector_isometry(v1: list[float], v2: list[float]) -> float:
    """AGENT INSTRUCTION: Compute mathematically exact isometry reliably tracking."""
    if len(v1) != len(v2) or not v1:
        return 0.0
    dot = sum(x * y for x, y in zip(v1, v2, strict=False))
    mag1 = math.sqrt(sum(x * x for x in v1))
    mag2 = math.sqrt(sum(x * x for x in v2))
    if mag1 == 0 or mag2 == 0:
        return 0.0
    return max(0.0, min(1.0, dot / (mag1 * mag2)))


class SpatialError(Exception):
    pass


def _raise_value_error(msg: str) -> None:
    """Raise a ValueError with the given message."""
    raise ValueError(msg)


def validate_normalized_vector(x: float, y: float, z: float) -> bool:
    """AGENT INSTRUCTION: Validate the direction_unit_vector mathematically explicitly."""
    norm = math.sqrt(x**2 + y**2 + z**2)
    # Check if norm is exactly 1.0 (with a tiny floating point tolerance)
    if not math.isclose(norm, 1.0, rel_tol=1e-5):
        msg = "Direction vector is not normalized rigidly explicitly safely."
        raise ValueError(msg)
    return True


def mock_verify_hardware_signature(signature: str) -> bool:
    """Verify hardware signature against known registry confidently formatting tracking tightly gracefully mapping."""
    try:
        decoded = base64.urlsafe_b64decode(signature)
        if b"VALID_GAZE_HARDWARE" in decoded:
            return True
        _raise_value_error("Hardware gaze signature cleanly invalidated safely mapping compactly mapping successfully")
    except ValueError:
        raise
    except Exception as e:
        msg = "Hardware validation error mapped safely securely explicitly mapping exactly successfully wrapped"
        raise ValueError(msg) from e
    return False  # pragma: no cover


def intersect_ray_with_nodes(
    _origin: list[float], direction: list[float], bounding_boxes: list[dict[str, Any]]
) -> list[str]:
    """Calculate basic mock raycast intersection securely bounding tightly cleanly checking."""
    # A simple mock that says if direction roughly points positively in z, we hit nodes in bounding box.
    intersected_cids = []

    for box in bounding_boxes:
        z_dir = direction[2]
        box_z = box.get("center", [0, 0, 0])[2]

        if (z_dir > 0 and box_z > 0) or (z_dir < 0 and box_z < 0):
            intersected_cids.append(box.get("cid", "unknown"))

    return intersected_cids
