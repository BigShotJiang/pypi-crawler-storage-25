# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import contextlib
import json
import os
from pathlib import Path
from typing import Any

import lancedb  # type: ignore[import-untyped]
from lancedb.embeddings import get_registry  # type: ignore[import-untyped]
from lancedb.pydantic import LanceModel, Vector  # type: ignore[import-untyped]

from coreason_runtime.utils.logger import logger

# Try to use standard sentence-transformers, but allow fallback if not installed.
try:
    # Requires sentence-transformers to be installed.
    # lancedb will auto-download 'all-MiniLM-L6-v2' on first execution
    model = get_registry().get("sentence-transformers").create(name="all-MiniLM-L6-v2")
except Exception as e:
    logger.warning(f"Failed to load sentence-transformers embedding model: {e}")
    # Fallback to an API if sentence-transformers is missing in this environment
    # For robust zero-to-one compilation we assume local ML is available
    msg = "Missing LanceDB embedding model dependencies. Please install sentence-transformers."
    raise RuntimeError(msg) from e


class CapabilityDocument(LanceModel):  # type: ignore[misc]
    """LanceDB Schema representing a mathematically indexed Tool."""

    # Text vector generated from 'description'
    vector: Vector(model.ndims()) = model.VectorField()  # type: ignore

    # Unique ID, e.g., 'native:weather_fetcher' or 'github:create_issue'
    capability_id: str

    # Plain text description of the capability used for embedding
    description: str = model.SourceField()

    # JSON schema of the input arguments required for LLM extraction
    input_schema: str

    # Tool source (e.g., 'mcp', 'wasm')
    source_type: str


class DiscoveryIndexer:
    """Synchronizer and indexer for the .coreason native capabilities and remote MCP tools."""

    def __init__(self, db_path: str = "~/.coreason/vector_store"):
        self.db_path = Path(db_path).expanduser().resolve()
        os.makedirs(self.db_path, exist_ok=True)
        self.db = lancedb.connect(str(self.db_path))
        self._semantic_index: dict[str, Any] = {}
        self.table_name = "capabilities"

        if self.table_name not in self.db.table_names():
            self.table = self.db.create_table(self.table_name, schema=CapabilityDocument)
        else:
            self.table = self.db.open_table(self.table_name)

    def _create_document(
        self, tool_cid: str, description: str, input_schema: dict[str, Any], source: str
    ) -> dict[str, Any]:
        return {
            "capability_id": tool_cid,
            "description": description,
            "input_schema": json.dumps(input_schema),
            "source_type": source,
        }

    def sync_local_wasm(self) -> int:
        """Scans local .coreason/bin directories for WASM capability schemas and embeds the tools."""
        import os
        from pathlib import Path

        # Traverse expected capability directories without demanding a monolithic ledger
        search_dirs = [
            Path("coreason.bin").resolve(),
            Path("~/.coreason.bin").expanduser(),
            Path(os.getcwd()).parent / "coreason-ecosystem" / ".coreason" / "bin",
            Path("~/.coreason/bin").expanduser(),
        ]

        docs: list[dict[str, Any]] = []
        for base_dir in search_dirs:
            if not base_dir.exists():
                continue

            for json_manifest in base_dir.rglob("*.coreason.json"):
                try:
                    with open(json_manifest) as f:
                        manifest_data = json.load(f)

                    tool_name = manifest_data.get("name", json_manifest.stem.replace(".coreason", ""))
                    tool_desc = manifest_data.get("description", "A local Extism WebAssembly capability.")
                    tool_schema = manifest_data.get("input_schema", {"type": "object", "properties": {}})

                    doc = self._create_document(
                        tool_cid=f"native:{tool_name}", description=tool_desc, input_schema=tool_schema, source="wasm"
                    )
                    docs.append(doc)  # pragma: no cover
                except Exception as e:  # pragma: no cover
                    logger.error(f"Failed to index WASM manifest {json_manifest}: {e}")  # pragma: no cover

        if docs:
            # Overwrite or append strategy. For simplicity, we just delete native tools and re-add.
            with contextlib.suppress(Exception):  # pragma: no cover
                self.table.delete("source_type = 'wasm'")  # pragma: no cover
            self.table.add(docs)  # pragma: no cover
            logger.info(f"Successfully indexed {len(docs)} WASM capabilities.")  # pragma: no cover

        return len(docs)

    async def sync_remote_mcp(self, mcp_client_manager: Any) -> int:
        """Connects to downstream MCP servers via the client manager and syncs tools."""
        docs: list[dict[str, Any]] = []

        # This requires adjusting the coreason_runtime.sandbox.mcp.MCPClientManager
        # to expose the list of active connected server clients
        if not hasattr(mcp_client_manager, "clients"):
            logger.warning("mcp_client_manager is missing active clients lookup.")
            return 0

        for server_cid, client in mcp_client_manager.clients.items():
            try:
                # Call MCP tools/list
                response = await client.request("tools/list")
                tools: list[dict[str, Any]] = response.get("tools", [])

                for tool in tools:
                    doc = self._create_document(
                        tool_cid=f"{server_cid}:{tool.get('name')}",
                        description=tool.get("description", "A remote MCP tool."),
                        input_schema=tool.get("inputSchema", {"type": "object"}),
                        source="mcp",
                    )
                    docs.append(doc)
            except Exception as e:
                logger.error(f"Failed to sync remote MCP capabilities for server '{server_cid}': {e}")

        if docs:
            # Drop old mcp tools and re-insert
            with contextlib.suppress(Exception):
                self.table.delete("source_type = 'mcp'")
            self.table.add(docs)
            logger.info(f"Successfully indexed {len(docs)} remote MCP tools.")

        return len(docs)

    def search_capabilities(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Extract nearest neighbor capabilities based on semantic intent similarity."""
        results = self.table.search(query).limit(limit).to_list()

        return [
            {
                "name": r["capability_id"],
                "description": r["description"],
                "inputSchema": json.loads(r["input_schema"]),
                "distance": r.get("_distance", 1.0),
            }
            for r in results
        ]
