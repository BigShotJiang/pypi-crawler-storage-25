"""Git reference, branch, and tag handling."""

from datetime import datetime
from typing import Dict, Any, List, cast, TYPE_CHECKING

if TYPE_CHECKING:
    import pygit2


def get_ref_structure(
    repo: 'pygit2.Repository',
    ref: str,
    query: Dict[str, str],
    query_filters: list,
    result_control,
    format_commit_func,
    matches_all_filters_func,
    get_commit_history_func
) -> Dict[str, Any]:
    """Get structure for specific ref (commit/branch/tag)."""
    try:
        import pygit2

        obj = repo.revparse_single(ref)

        # If it's a tag, peel to the commit
        while hasattr(obj, 'peel') and not isinstance(obj, pygit2.Commit):
            obj = obj.peel(pygit2.Commit)  # type: ignore[assignment]

        if isinstance(obj, pygit2.Commit):
            commit_obj = cast('pygit2.Commit', obj)
            # Get commit history from this point
            limit = int(query.get('limit', 20))
            commits = get_commit_history_func(repo, commit_obj, limit=limit)

            return {
                'contract_version': '1.0',
                'type': 'git_ref',
                'source': f"{repo.workdir or repo.path}@{ref}",
                'source_type': 'directory',
                'ref': ref,
                'commit': format_commit_func(commit_obj, detailed=True),
                'history': commits,
                'filter_applied': bool(query_filters),
            }
        else:
            raise ValueError(f"Cannot resolve ref to commit: {ref}")

    except (KeyError, pygit2.GitError) as e:
        raise ValueError(f"Invalid ref: {ref}") from e


def get_head_info(repo: 'pygit2.Repository') -> Dict[str, Any]:
    """Get HEAD information."""
    if repo.is_empty or repo.head_is_unborn:
        return {'branch': None, 'commit': None, 'detached': False}

    try:
        return {
            'branch': repo.head.shorthand if not repo.head_is_detached else None,
            'commit': str(repo.head.target)[:7],
            'detached': repo.head_is_detached,
        }
    except Exception:
        return {'branch': None, 'commit': None, 'detached': False}


def _get_branch_info(repo, branch_name) -> 'Dict[str, Any] | None':
    """Return branch info dict for branch_name, or None on error."""
    import pygit2
    try:
        branch = repo.branches.get(branch_name)
        if not branch or not branch.target:
            return None
        commit = cast('pygit2.Commit', repo[branch.target])
        return {
            'name': branch_name,
            'commit': str(commit.id)[:7],
            'message': commit.message.split('\n')[0][:80],
            'author': commit.author.name,
            'date': datetime.fromtimestamp(commit.commit_time).strftime('%Y-%m-%d'),
            'timestamp': commit.commit_time,
        }
    except (KeyError, pygit2.GitError):
        return None


def list_branches(repo: 'pygit2.Repository', limit: int = 20) -> List[Dict[str, Any]]:
    """List repository branches."""
    branches = []
    try:
        for branch_name in repo.branches.local:
            info = _get_branch_info(repo, branch_name)
            if info:
                branches.append(info)
    except Exception:  # pygit2 errors vary — return partial results collected so far
        pass
    return sorted(branches, key=lambda b: cast(int, b.get('timestamp', 0)), reverse=True)[:limit]


def _get_tag_info(repo, ref_name) -> 'Dict[str, Any] | None':
    """Return tag info dict for ref_name, or None on error."""
    import pygit2
    try:
        ref = repo.references.get(ref_name)
        if not ref:
            return None
        tag_name = ref_name.replace('refs/tags/', '')
        target = repo[ref.target]
        while hasattr(target, 'peel') and not isinstance(target, pygit2.Commit):
            target = target.peel(pygit2.Commit)  # type: ignore[assignment]
        if not isinstance(target, pygit2.Commit):
            return None
        commit_target = cast('pygit2.Commit', target)
        return {
            'name': tag_name,
            'commit': str(commit_target.id)[:7],
            'message': commit_target.message.split('\n')[0][:80],
            'date': datetime.fromtimestamp(commit_target.commit_time).strftime('%Y-%m-%d'),
            'timestamp': commit_target.commit_time,
        }
    except (KeyError, pygit2.GitError, AttributeError):
        return None


def list_tags(repo: 'pygit2.Repository', limit: int = 20) -> List[Dict[str, Any]]:
    """List repository tags."""
    tags = []
    try:
        for ref_name in repo.references:
            if not ref_name.startswith('refs/tags/'):
                continue
            info = _get_tag_info(repo, ref_name)
            if info:
                tags.append(info)
    except Exception:  # pygit2 errors vary — return partial results collected so far
        pass
    return sorted(tags, key=lambda t: cast(int, t.get('timestamp', 0)), reverse=True)[:limit]
