"""Multi-signal importance ranking for repository files."""

from __future__ import annotations

import json
import logging
import math
import os
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from qwen3_repo.ingester import FileRole, RepoFile, discover_files

logger = logging.getLogger(__name__)

# Weights tuned by hand on 10 Python repos (flask, fastapi, etc).
# Centrality dominates because DeltaNet layers accumulate definitions
# sequentially -- files imported by many others must appear early.
SIGNAL_WEIGHTS = {
    "centrality": 3.0,
    "recency": 1.5,
    "coverage": 1.0,
    "role_weight": 2.0,
    "structural": 0.8,
    "size_efficiency": 0.5,
}


def compute_centrality(files: List[RepoFile]) -> Dict[str, float]:
    scores: Dict[str, float] = {}
    max_imported_by = max((len(f.imported_by) for f in files), default=0) or 1

    for rf in files:
        count = len(rf.imported_by)
        if count == 0:
            scores[rf.path] = 0.0
        else:
            scores[rf.path] = math.log1p(count) / math.log1p(max_imported_by)
    return scores


# 30 days: roughly one release cycle. Files untouched for 2+ months score < 0.25.
def compute_recency(files: List[RepoFile], half_life_days: float = 30.0) -> Dict[str, float]:
    return {rf.path: 0.5 ** (rf.last_modified_days / half_life_days) for rf in files}


def compute_coverage_proximity(files: List[RepoFile]) -> Dict[str, float]:
    test_paths = {rf.path for rf in files if rf.role == FileRole.TEST}
    source_to_tests: Dict[str, Set[str]] = defaultdict(set)

    for rf in files:
        if rf.role == FileRole.TEST:
            continue

        base = Path(rf.path)
        stem = base.stem
        parent = str(base.parent)

        test_candidates = [
            f"tests/test_{stem}.py",
            f"tests/{stem}_test.py",
            f"test/test_{stem}.py",
            f"test/{stem}_test.py",
            f"{parent}/test_{stem}.py",
            f"{parent}/{stem}_test.py",
            f"{parent}/{stem}.test.ts",
            f"{parent}/{stem}.test.tsx",
            f"{parent}/{stem}.spec.ts",
            f"{parent}/{stem}.spec.tsx",
            f"{parent}/__tests__/{stem}.test.ts",
            f"{parent}/__tests__/{stem}.test.tsx",
        ]

        for candidate in test_candidates:
            if candidate in test_paths:
                source_to_tests[rf.path].add(candidate)

    scores: Dict[str, float] = {}
    for rf in files:
        tests = source_to_tests.get(rf.path, set())
        if tests:
            rf.test_coverage = min(1.0, len(tests) * 0.3)
            scores[rf.path] = 1.0
        else:
            scores[rf.path] = 0.0
    return scores


_ROLE_WEIGHT_MAP = {
    FileRole.CONFIG: 2.0,
    FileRole.TYPE_DEF: 2.5,
    FileRole.CORE_LIB: 2.0,
    FileRole.UTILITY: 1.5,
    FileRole.FEATURE: 1.0,
    FileRole.TEST: 0.7,
    FileRole.DOC: 0.5,
    FileRole.ASSET: 0.3,
    FileRole.BUILD: 0.6,
    FileRole.OTHER: 0.8,
}


def compute_role_weights(files: List[RepoFile]) -> Dict[str, float]:
    return {rf.path: _ROLE_WEIGHT_MAP.get(rf.role, 1.0) for rf in files}


def compute_structural_importance(files: List[RepoFile]) -> Dict[str, float]:
    scores: Dict[str, float] = {}
    for rf in files:
        depth = rf.path.replace("\\", "/").count("/")
        if depth == 0:
            scores[rf.path] = 1.0
        elif any(kw in rf.path.lower() for kw in ["src/lib", "/lib/", "/core/", "/engine/"]):
            scores[rf.path] = 0.9
        elif depth == 1:
            scores[rf.path] = 0.7
        else:
            scores[rf.path] = max(0.3, 1.0 - depth * 0.1)
    return scores


def compute_size_efficiency(files: List[RepoFile]) -> Dict[str, float]:
    if not files:
        return {}

    efficiencies: Dict[str, float] = {}
    for rf in files:
        if rf.size_bytes > 0 and rf.is_text:
            efficiencies[rf.path] = rf.estimated_tokens / rf.size_bytes
        else:
            efficiencies[rf.path] = 0.0

    max_eff = max(efficiencies.values(), default=1) or 1
    return {k: v / max_eff for k, v in efficiencies.items()}


@dataclass
class RankedFile:
    path: str
    score: float
    signals: Dict[str, float] = field(default_factory=dict)


def rank_files(
    files: List[RepoFile],
    custom_weights: Optional[Dict[str, float]] = None,
) -> List[RankedFile]:
    weights = {**SIGNAL_WEIGHTS, **(custom_weights or {})}

    signals = {
        "centrality": compute_centrality(files),
        "recency": compute_recency(files),
        "coverage": compute_coverage_proximity(files),
        "role_weight": compute_role_weights(files),
        "structural": compute_structural_importance(files),
        "size_efficiency": compute_size_efficiency(files),
    }

    ranked: List[RankedFile] = []
    for rf in files:
        file_signals: Dict[str, float] = {}
        composite = 0.0
        for signal_name, signal_scores in signals.items():
            value = signal_scores.get(rf.path, 0.0)
            weight = weights.get(signal_name, 1.0)
            file_signals[signal_name] = value
            composite += value * weight

        ranked.append(RankedFile(path=rf.path, score=composite, signals=file_signals))

    ranked.sort(key=lambda r: r.score, reverse=True)
    return ranked


def select_files_for_budget(
    ranked: List[RankedFile],
    file_index: Dict[str, RepoFile],
    token_budget: int,
    mandatory_roles: Optional[Set[FileRole]] = None,
) -> List[str]:
    mandatory_roles = mandatory_roles or {FileRole.CONFIG, FileRole.TYPE_DEF}
    selected: List[str] = []
    total_tokens = 0

    for rf in ranked:
        repo_file = file_index.get(rf.path)
        if repo_file and repo_file.role in mandatory_roles:
            if total_tokens + repo_file.estimated_tokens <= token_budget:
                selected.append(rf.path)
                total_tokens += repo_file.estimated_tokens

    for rf in ranked:
        if rf.path in selected:
            continue
        repo_file = file_index.get(rf.path)
        if repo_file and total_tokens + repo_file.estimated_tokens <= token_budget:
            selected.append(rf.path)
            total_tokens += repo_file.estimated_tokens

    logger.info(
        "Selected %d/%d files (%s tokens / %s budget)",
        len(selected), len(ranked), f"{total_tokens:,}", f"{token_budget:,}",
    )
    return selected


def main():
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Rank repository files by importance for Qwen3 and Qwen3.6 context packs"
    )
    parser.add_argument("repo_path")
    parser.add_argument("--top-n", type=int, default=50)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(message)s",
    )

    repo_root = Path(args.repo_path)
    if not repo_root.is_dir():
        print(f"Error: {args.repo_path} is not a directory", file=sys.stderr)
        return

    files = discover_files(repo_root)
    ranked = rank_files(files)

    if args.json:
        output = [
            {
                "path": r.path,
                "score": round(r.score, 4),
                "signals": {k: round(v, 4) for k, v in r.signals.items()},
            }
            for r in ranked[: args.top_n]
        ]
        print(json.dumps(output, indent=2))
    else:
        print(f"{'Rank':<6} {'Score':<10} {'Path':<60} {'Signals'}")
        print("-" * 120)
        for i, r in enumerate(ranked[: args.top_n], 1):
            top_signals = sorted(r.signals.items(), key=lambda x: -x[1])[:3]
            signal_str = ", ".join(f"{k}={v:.2f}" for k, v in top_signals)
            print(f"{i:<6} {r.score:<10.4f} {r.path:<60} {signal_str}")


if __name__ == "__main__":
    main()
