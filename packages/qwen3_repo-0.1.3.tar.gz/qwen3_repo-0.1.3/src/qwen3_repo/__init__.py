"""Architecture-aware repo-to-context scaffold for Qwen3 and Qwen3.6."""

__version__ = "0.1.3"

from qwen3_repo.ingester import ingest_repo, estimate_tokens, ContextBudget
from qwen3_repo.ranker import rank_files, RankedFile
from qwen3_repo.vision_detect import detect_vision_needs, detect_ollama_vision_capability, VisionConfig
from qwen3_repo.scaffold import OpenAIClient, run_agent, AgentRunResult

__all__ = [
    "ingest_repo",
    "estimate_tokens",
    "ContextBudget",
    "rank_files",
    "RankedFile",
    "detect_vision_needs",
    "detect_ollama_vision_capability",
    "VisionConfig",
    "OpenAIClient",
    "run_agent",
    "AgentRunResult",
]
