"""Side-by-side comparison of Claude Code vs qwen3-repo context formatting.

Runs the same tasks through both formatting strategies on the same model
and endpoint, so the only variable is context ordering.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from qwen3_repo.ingester import (
    ContextBudget,
    build_dependency_graph,
    compute_ordering,
    discover_files,
    format_context_pack,
)
from qwen3_repo.scaffold import BACKEND_DEFAULTS, OpenAIClient, run_agent

logger = logging.getLogger(__name__)


@dataclass
class ComparisonConfig:
    model: str = "Qwen/Qwen3.6-27B"
    api_url: str = "http://localhost:8000/v1"
    api_key: str = "EMPTY"
    max_turns: int = 900
    temperature: float = 1.0
    top_p: float = 0.95
    output_dir: str = "bench_compare_results"


@dataclass
class ComparisonResult:
    task_id: str
    claude_code_success: bool = False
    qwen3_repo_success: bool = False
    claude_code_turns: int = 0
    qwen3_repo_turns: int = 0
    claude_code_tokens: int = 0
    qwen3_repo_tokens: int = 0
    claude_code_time: float = 0.0
    qwen3_repo_time: float = 0.0
    winner: str = "tie"


def format_claude_code_context(repo_root: Path) -> str:
    """Alphabetical file ordering -- emulates Claude Code's generic approach."""
    parts: List[str] = []
    files: List[tuple] = []

    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [
            d for d in dirnames
            if not d.startswith(".") and d not in {
                "node_modules", "__pycache__", "venv", ".venv",
                "dist", "build", "target", ".git",
            }
        ]
        for filename in sorted(filenames):
            abs_path = Path(dirpath) / filename
            rel_path = str(abs_path.relative_to(repo_root))
            try:
                if abs_path.stat().st_size > 1_000_000:
                    continue
                with open(abs_path, "rb") as f:
                    chunk = f.read(8192)
                if b"\x00" in chunk:
                    continue
                with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                files.append((rel_path, content))
            except (OSError, UnicodeDecodeError):
                continue

    files.sort(key=lambda x: x[0])

    parts.append("Here is the repository you're working with:\n")
    for path, content in files:
        parts.append(f"File: {path}")
        parts.append("```")
        parts.append(content)
        parts.append("```\n")

    return "\n".join(parts)


def format_qwen3_repo_context(
    repo_root: Path,
    model: str = "Qwen3.6-27B",
    language_model_only: bool = True,
) -> str:
    """Dependency-ordered, importance-ranked context for Qwen3.6."""
    files = discover_files(repo_root)
    dep_graph = build_dependency_graph(files)
    budget = ContextBudget(model, language_model_only=language_model_only)
    ordered = compute_ordering(files, dep_graph, budget)
    return format_context_pack(ordered)


def run_comparison_task(
    task_id: str,
    task_description: str,
    repo_path: str,
    client: OpenAIClient,
    max_turns: int = 900,
    temperature: float = 1.0,
    top_p: float = 0.95,
) -> ComparisonResult:
    result = ComparisonResult(task_id=task_id)
    repo_root = Path(repo_path)

    # Run 1: Claude Code emulation
    logger.info("[%s] Running with Claude Code context format...", task_id)
    claude_context = format_claude_code_context(repo_root)

    try:
        subprocess.run(["git", "checkout", "."], cwd=repo_path, capture_output=True, timeout=10)
        subprocess.run(["git", "clean", "-fd"], cwd=repo_path, capture_output=True, timeout=10)
    except (subprocess.TimeoutExpired, OSError):
        pass

    claude_result = run_agent(
        task_description=task_description,
        repo_path=repo_path,
        context_pack=claude_context,
        client=client,
        max_turns=max_turns,
        temperature=temperature,
        top_p=top_p,
        task_id=f"{task_id}_claude_code",
    )

    result.claude_code_success = claude_result.success
    result.claude_code_turns = claude_result.total_turns
    result.claude_code_tokens = claude_result.total_tokens
    result.claude_code_time = claude_result.total_time

    # Run 2: qwen3-repo optimized
    logger.info("[%s] Running with qwen3-repo context format...", task_id)
    qwen_context = format_qwen3_repo_context(repo_root, client.model)

    try:
        subprocess.run(["git", "checkout", "."], cwd=repo_path, capture_output=True, timeout=10)
        subprocess.run(["git", "clean", "-fd"], cwd=repo_path, capture_output=True, timeout=10)
    except (subprocess.TimeoutExpired, OSError):
        pass

    qwen_result = run_agent(
        task_description=task_description,
        repo_path=repo_path,
        context_pack=qwen_context,
        client=client,
        max_turns=max_turns,
        temperature=temperature,
        top_p=top_p,
        task_id=f"{task_id}_qwen3_repo",
    )

    result.qwen3_repo_success = qwen_result.success
    result.qwen3_repo_turns = qwen_result.total_turns
    result.qwen3_repo_tokens = qwen_result.total_tokens
    result.qwen3_repo_time = qwen_result.total_time

    if result.qwen3_repo_success and not result.claude_code_success:
        result.winner = "qwen3_repo"
    elif result.claude_code_success and not result.qwen3_repo_success:
        result.winner = "claude_code"
    elif result.qwen3_repo_success and result.claude_code_success:
        if result.qwen3_repo_turns < result.claude_code_turns:
            result.winner = "qwen3_repo"
        elif result.claude_code_turns < result.qwen3_repo_turns:
            result.winner = "claude_code"
        else:
            result.winner = "tie"
    else:
        result.winner = "neither"

    return result


def generate_comparison_report(
    results: List[ComparisonResult], config: ComparisonConfig,
) -> Dict:
    total = len(results)
    if total == 0:
        return {"error": "No comparison results"}

    qwen_wins = sum(1 for r in results if r.winner == "qwen3_repo")
    claude_wins = sum(1 for r in results if r.winner == "claude_code")
    ties = sum(1 for r in results if r.winner == "tie")
    neither = sum(1 for r in results if r.winner == "neither")

    qwen_successes = sum(1 for r in results if r.qwen3_repo_success)
    claude_successes = sum(1 for r in results if r.claude_code_success)

    report = {
        "title": "Claude Code vs qwen3-repo Benchmark Comparison",
        "model": config.model,
        "config": {
            "max_turns": config.max_turns,
            "temperature": config.temperature,
            "top_p": config.top_p,
        },
        "summary": {
            "total_tasks": total,
            "qwen3_repo_wins": qwen_wins,
            "claude_code_wins": claude_wins,
            "ties": ties,
            "neither": neither,
            "qwen3_repo_success_rate": round(qwen_successes / total * 100, 1),
            "claude_code_success_rate": round(claude_successes / total * 100, 1),
        },
        "averages": {
            "qwen3_repo": {
                "turns": round(sum(r.qwen3_repo_turns for r in results) / total, 1),
                "tokens": round(sum(r.qwen3_repo_tokens for r in results) / total, 0),
                "time_seconds": round(sum(r.qwen3_repo_time for r in results) / total, 1),
            },
            "claude_code": {
                "turns": round(sum(r.claude_code_turns for r in results) / total, 1),
                "tokens": round(sum(r.claude_code_tokens for r in results) / total, 0),
                "time_seconds": round(sum(r.claude_code_time for r in results) / total, 1),
            },
        },
        "per_task": [
            {
                "task_id": r.task_id,
                "winner": r.winner,
                "claude_code_success": r.claude_code_success,
                "qwen3_repo_success": r.qwen3_repo_success,
                "claude_code_turns": r.claude_code_turns,
                "qwen3_repo_turns": r.qwen3_repo_turns,
            }
            for r in results
        ],
    }

    return report


def format_report_markdown(report: Dict) -> str:
    lines: List[str] = []
    lines.append(f"# {report['title']}")
    lines.append("")
    lines.append(f"**Model**: {report['model']}")
    lines.append(
        f"**Configuration**: temp={report['config']['temperature']}, "
        f"top_p={report['config']['top_p']}, "
        f"max_turns={report['config']['max_turns']}"
    )
    lines.append("")

    summary = report["summary"]
    lines.append("## Summary")
    lines.append("")
    lines.append("| Metric | Claude Code | qwen3-repo |")
    lines.append("|--------|-------------|-----------|")
    lines.append(
        f"| Success Rate | {summary['claude_code_success_rate']}% | "
        f"{summary['qwen3_repo_success_rate']}% |"
    )
    lines.append(
        f"| Direct Wins | {summary['claude_code_wins']} | {summary['qwen3_repo_wins']} |"
    )
    lines.append("")
    lines.append(f"Ties: {summary['ties']}, Neither: {summary['neither']}")
    lines.append("")

    avgs = report["averages"]
    lines.append("## Averages")
    lines.append("")
    lines.append("| Metric | Claude Code | qwen3-repo |")
    lines.append("|--------|-------------|-----------|")
    lines.append(
        f"| Turns | {avgs['claude_code']['turns']} | {avgs['qwen3_repo']['turns']} |"
    )
    lines.append(
        f"| Tokens | {avgs['claude_code']['tokens']:,.0f} | {avgs['qwen3_repo']['tokens']:,.0f} |"
    )
    lines.append(
        f"| Time (s) | {avgs['claude_code']['time_seconds']} | "
        f"{avgs['qwen3_repo']['time_seconds']} |"
    )
    lines.append("")

    lines.append("## Per-Task Results")
    lines.append("")
    lines.append("| Task | Winner | CC | QR | Turns (CC/QR) |")
    lines.append("|------|--------|----|----|---------------|")
    for task in report["per_task"]:
        cc = "PASS" if task["claude_code_success"] else "FAIL"
        qr = "PASS" if task["qwen3_repo_success"] else "FAIL"
        lines.append(
            f"| {task['task_id']} | {task['winner']} | {cc} | {qr} | "
            f"{task['claude_code_turns']}/{task['qwen3_repo_turns']} |"
        )

    return "\n".join(lines)


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Compare Claude Code vs qwen3-repo scaffolding"
    )
    parser.add_argument("--tasks", required=True)
    parser.add_argument("--repo-path")
    parser.add_argument("--backend", choices=list(BACKEND_DEFAULTS), default="vllm")
    parser.add_argument("--api-url", default=None)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", default="Qwen/Qwen3.6-27B")
    parser.add_argument("--max-turns", type=int, default=900)
    parser.add_argument("--temperature", type=float, default=1.0)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--output-dir", default="bench_compare_results")
    parser.add_argument("--markdown", action="store_true")
    parser.add_argument("--verbose", "-v", action="store_true")

    args = parser.parse_args()

    if args.api_url is None:
        args.api_url = BACKEND_DEFAULTS[args.backend]

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(message)s",
    )

    with open(args.tasks, "r") as f:
        task_data = json.load(f)

    config = ComparisonConfig(
        model=args.model,
        api_url=args.api_url,
        api_key=args.api_key,
        max_turns=args.max_turns,
        temperature=args.temperature,
        top_p=args.top_p,
        output_dir=args.output_dir,
    )

    client = OpenAIClient(base_url=config.api_url, api_key=config.api_key, model=config.model)

    results: List[ComparisonResult] = []
    for i, task in enumerate(task_data):
        task_id = task.get("task_id", f"task-{i + 1}")
        task_desc = task.get("description", task.get("task", ""))
        repo_path = task.get("repo_path", args.repo_path)

        if not repo_path:
            logger.error("No repo path for task %s, skipping", task_id)
            continue

        logger.info("Comparing task %d/%d: %s", i + 1, len(task_data), task_id)

        result = run_comparison_task(
            task_id=task_id,
            task_description=task_desc,
            repo_path=repo_path,
            client=client,
            max_turns=config.max_turns,
            temperature=config.temperature,
            top_p=config.top_p,
        )
        results.append(result)

    report = generate_comparison_report(results, config)

    os.makedirs(config.output_dir, exist_ok=True)
    with open(os.path.join(config.output_dir, "comparison_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    if args.markdown:
        md = format_report_markdown(report)
        with open(os.path.join(config.output_dir, "comparison_report.md"), "w") as f:
            f.write(md)

    summary = report.get("summary", {})
    print(f"\nqwen3-repo wins: {summary.get('qwen3_repo_wins', 0)}")
    print(f"Claude Code wins: {summary.get('claude_code_wins', 0)}")
    print(f"Ties: {summary.get('ties', 0)}")


if __name__ == "__main__":
    main()
