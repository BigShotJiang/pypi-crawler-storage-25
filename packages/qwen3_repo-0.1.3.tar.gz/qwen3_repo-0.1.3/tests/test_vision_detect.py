import os
from pathlib import Path

from qwen3_repo.vision_detect import (
    AssetType,
    VisionConfig,
    VisualAsset,
    decide_vision_config,
    detect_canvas_webgl,
    detect_css_animations,
    detect_diagram_files,
    detect_image_assets,
    detect_ollama_vision_capability,
    detect_video_assets,
    detect_vision_needs,
)


class TestDetectImageAssets:
    def test_finds_png(self, tmp_path):
        (tmp_path / "logo.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        assets = detect_image_assets(tmp_path)
        assert len(assets) == 1
        assert assets[0].asset_type == AssetType.RASTER_IMAGE

    def test_finds_svg(self, tmp_path):
        (tmp_path / "icon.svg").write_text("<svg></svg>")
        assets = detect_image_assets(tmp_path)
        assert len(assets) == 1
        assert assets[0].asset_type == AssetType.VECTOR_IMAGE

    def test_skips_git_dir(self, tmp_path):
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "logo.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        assets = detect_image_assets(tmp_path)
        assert len(assets) == 0

    def test_design_pattern_boost(self, tmp_path):
        (tmp_path / "mockup_v2.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        assets = detect_image_assets(tmp_path)
        assert assets[0].relevance_score >= 0.8


class TestDetectVideoAssets:
    def test_finds_mp4(self, tmp_path):
        (tmp_path / "demo.mp4").write_bytes(b"\x00" * 100)
        assets = detect_video_assets(tmp_path)
        assert len(assets) == 1
        assert assets[0].asset_type == AssetType.VIDEO

    def test_empty_repo(self, tmp_path):
        assert detect_video_assets(tmp_path) == []


class TestDetectCssAnimations:
    def test_finds_keyframes(self, tmp_path):
        (tmp_path / "style.css").write_text("@keyframes fadeIn { from { opacity: 0; } }")
        assert detect_css_animations(tmp_path) is True

    def test_no_animations(self, tmp_path):
        (tmp_path / "style.css").write_text("body { color: red; }")
        assert detect_css_animations(tmp_path) is False

    def test_finds_transitions(self, tmp_path):
        (tmp_path / "style.css").write_text(".btn { transition: all 0.3s; }")
        assert detect_css_animations(tmp_path) is True


class TestDetectCanvasWebgl:
    def test_finds_canvas_2d(self, tmp_path):
        (tmp_path / "draw.js").write_text("ctx = canvas.getContext('2d')")
        assert detect_canvas_webgl(tmp_path) is True

    def test_finds_three_js(self, tmp_path):
        (tmp_path / "scene.ts").write_text("const scene = new THREE.Scene()")
        assert detect_canvas_webgl(tmp_path) is True

    def test_no_canvas(self, tmp_path):
        (tmp_path / "app.js").write_text("console.log('hello')")
        assert detect_canvas_webgl(tmp_path) is False


class TestDetectDiagramFiles:
    def test_finds_mermaid(self, tmp_path):
        (tmp_path / "arch.mmd").write_text("graph TD; A-->B;")
        assets = detect_diagram_files(tmp_path)
        assert len(assets) == 1
        assert assets[0].asset_type == AssetType.DIAGRAM

    def test_finds_plantuml(self, tmp_path):
        (tmp_path / "seq.puml").write_text("@startuml\nA -> B\n@enduml")
        assets = detect_diagram_files(tmp_path)
        assert len(assets) == 1


class TestDecideVisionConfig:
    def test_no_assets_disables_vision(self):
        config = decide_vision_config([], False, False)
        assert config.use_vision is False
        assert config.language_model_only is True
        assert config.kv_cache_savings_gb == 6.0
        assert "Consider" in config.recommendation

    def test_design_files_enable_vision(self):
        assets = [VisualAsset(path="design/mockup.png", asset_type=AssetType.DESIGN_FILE, relevance_score=0.9)]
        config = decide_vision_config(assets, False, False)
        assert config.use_vision is True

    def test_canvas_enables_vision(self):
        config = decide_vision_config([], False, True)
        assert config.use_vision is True

    def test_high_relevance_svgs_enable(self):
        assets = [VisualAsset(path="docs/arch.svg", asset_type=AssetType.VECTOR_IMAGE, relevance_score=0.6)]
        config = decide_vision_config(assets, False, False)
        assert config.use_vision is True

    def test_low_relevance_only_disables(self):
        assets = [VisualAsset(path="favicon.ico", asset_type=AssetType.RASTER_IMAGE, relevance_score=0.2)]
        config = decide_vision_config(assets, False, False)
        assert config.use_vision is False

    def test_videos_enable_vision(self):
        assets = [VisualAsset(path="demo.mp4", asset_type=AssetType.VIDEO, relevance_score=0.7)]
        config = decide_vision_config(assets, False, False)
        assert config.use_vision is True


class TestDetectVisionNeeds:
    def test_empty_repo(self, tmp_path):
        config = detect_vision_needs(tmp_path)
        assert config.use_vision is False
        assert config.language_model_only is True
        assert config.image_count == 0

    def test_repo_with_images(self, tmp_path):
        design = tmp_path / "design"
        design.mkdir()
        (design / "mockup.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        (design / "wireframe.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        (design / "screenshot.png").write_bytes(b"\x89PNG" + b"\x00" * 100)
        config = detect_vision_needs(tmp_path)
        assert config.image_count == 3


class TestOllamaVisionCapability:
    def test_known_qwen36_pattern(self):
        result = detect_ollama_vision_capability("qwen3.6-27b")
        assert result["supports_vision"] is True

    def test_unknown_model(self):
        result = detect_ollama_vision_capability("totally-unknown-model-xyz")
        assert result["supports_vision"] is False
        assert result["detection_method"] in ("unknown", "modelfile_keyword", "known_pattern", "api_families")
