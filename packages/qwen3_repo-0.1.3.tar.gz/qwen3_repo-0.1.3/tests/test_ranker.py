from qwen3_repo.ingester import FileRole, RepoFile
from qwen3_repo.ranker import (
    SIGNAL_WEIGHTS,
    RankedFile,
    compute_centrality,
    compute_coverage_proximity,
    compute_recency,
    compute_role_weights,
    compute_size_efficiency,
    compute_structural_importance,
    rank_files,
    select_files_for_budget,
)


def _make_file(path, role=FileRole.OTHER, imported_by=None, days=0.0, tokens=100, size=350):
    return RepoFile(
        path=path,
        abs_path="",
        role=role,
        imported_by=imported_by or set(),
        last_modified_days=days,
        estimated_tokens=tokens,
        size_bytes=size,
        is_text=True,
    )


class TestComputeCentrality:
    def test_zero_imports(self):
        files = [_make_file("a.py")]
        scores = compute_centrality(files)
        assert scores["a.py"] == 0.0

    def test_high_imports(self):
        files = [
            _make_file("a.py", imported_by={"b.py", "c.py", "d.py"}),
            _make_file("b.py"),
        ]
        scores = compute_centrality(files)
        assert scores["a.py"] > scores["b.py"]

    def test_normalized_range(self):
        files = [_make_file("a.py", imported_by={"b.py", "c.py"})]
        scores = compute_centrality(files)
        assert 0.0 <= scores["a.py"] <= 1.0


class TestComputeRecency:
    def test_recent_file_higher(self):
        files = [
            _make_file("new.py", days=1.0),
            _make_file("old.py", days=365.0),
        ]
        scores = compute_recency(files)
        assert scores["new.py"] > scores["old.py"]

    def test_custom_half_life(self):
        files = [_make_file("a.py", days=10.0)]
        scores_30d = compute_recency(files, half_life_days=30.0)
        scores_5d = compute_recency(files, half_life_days=5.0)
        assert scores_30d["a.py"] > scores_5d["a.py"]


class TestComputeRoleWeights:
    def test_type_def_highest(self):
        files = [
            _make_file("types.py", role=FileRole.TYPE_DEF),
            _make_file("app.py", role=FileRole.FEATURE),
            _make_file("test.py", role=FileRole.TEST),
        ]
        scores = compute_role_weights(files)
        assert scores["types.py"] > scores["app.py"]
        assert scores["app.py"] > scores["test.py"]


class TestComputeStructuralImportance:
    def test_root_highest(self):
        files = [
            _make_file("setup.py"),
            _make_file("src/deep/nested/file.py"),
        ]
        scores = compute_structural_importance(files)
        assert scores["setup.py"] > scores["src/deep/nested/file.py"]


class TestComputeSizeEfficiency:
    def test_dense_file_higher(self):
        dense = _make_file("a.py", tokens=500, size=500)
        sparse = _make_file("b.py", tokens=100, size=5000)
        scores = compute_size_efficiency([dense, sparse])
        assert scores["a.py"] > scores["b.py"]

    def test_empty_list(self):
        assert compute_size_efficiency([]) == {}


class TestComputeCoverageProximity:
    def test_file_with_test(self):
        src = _make_file("src/utils.py", role=FileRole.UTILITY)
        test = _make_file("tests/test_utils.py", role=FileRole.TEST)
        scores = compute_coverage_proximity([src, test])
        assert scores["src/utils.py"] == 1.0

    def test_file_without_test(self):
        src = _make_file("src/orphan.py", role=FileRole.FEATURE)
        scores = compute_coverage_proximity([src])
        assert scores["src/orphan.py"] == 0.0


class TestRankFiles:
    def test_returns_sorted(self):
        files = [
            _make_file("low.py", role=FileRole.OTHER, days=365.0),
            _make_file("high.py", role=FileRole.TYPE_DEF, imported_by={"a", "b"}, days=1.0),
        ]
        ranked = rank_files(files)
        assert ranked[0].path == "high.py"
        assert ranked[1].path == "low.py"

    def test_custom_weights(self):
        files = [_make_file("a.py")]
        ranked_default = rank_files(files)
        ranked_custom = rank_files(files, custom_weights={"centrality": 0.0})
        assert ranked_default[0].score >= ranked_custom[0].score

    def test_all_signals_present(self):
        files = [_make_file("a.py")]
        ranked = rank_files(files)
        for signal_name in SIGNAL_WEIGHTS:
            assert signal_name in ranked[0].signals


class TestSelectFilesForBudget:
    def test_fits_within_budget(self):
        files = [_make_file(f"f{i}.py", tokens=100) for i in range(10)]
        ranked = rank_files(files)
        file_index = {f.path: f for f in files}
        selected = select_files_for_budget(ranked, file_index, token_budget=500)
        total = sum(file_index[p].estimated_tokens for p in selected)
        assert total <= 500
        assert len(selected) == 5

    def test_mandatory_roles_included(self):
        config = _make_file("pyproject.toml", role=FileRole.CONFIG, tokens=50)
        feature = _make_file("app.py", role=FileRole.FEATURE, tokens=50)
        files = [config, feature]
        ranked = rank_files(files)
        file_index = {f.path: f for f in files}
        selected = select_files_for_budget(ranked, file_index, token_budget=60)
        assert "pyproject.toml" in selected
