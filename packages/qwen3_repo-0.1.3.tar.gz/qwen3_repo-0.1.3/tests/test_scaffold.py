import os
import tempfile
from pathlib import Path

from qwen3_repo.scaffold import (
    SYSTEM_PROMPT_TEMPLATE,
    TOOL_DEFINITIONS,
    AgentRunResult,
    OpenAIClient,
    ToolResult,
    _assess_completion,
    execute_bash,
    execute_file_edit,
    execute_file_read,
    execute_tool,
)


class TestToolDefinitions:
    def test_three_tools(self):
        assert len(TOOL_DEFINITIONS) == 3

    def test_tool_names(self):
        names = {t["function"]["name"] for t in TOOL_DEFINITIONS}
        assert names == {"bash", "file_edit", "file_read"}


class TestSystemPrompt:
    def test_context_pack_placeholder(self):
        prompt = SYSTEM_PROMPT_TEMPLATE.format(context_pack="[repo content here]")
        assert "[repo content here]" in prompt
        assert "bash" in prompt
        assert "file_edit" in prompt


class TestExecuteBash:
    def test_echo(self, tmp_path):
        result = execute_bash("echo hello", str(tmp_path))
        assert result.success
        assert "hello" in result.output

    def test_failing_command(self, tmp_path):
        result = execute_bash("exit 1", str(tmp_path))
        assert not result.success

    def test_timeout(self, tmp_path):
        result = execute_bash("sleep 10", str(tmp_path), timeout=1)
        assert not result.success
        assert "timed out" in result.output

    def test_captures_stderr(self, tmp_path):
        result = execute_bash("echo err >&2", str(tmp_path))
        assert "err" in result.output


class TestExecuteFileEdit:
    def test_create_file(self, tmp_path):
        result = execute_file_edit("new.py", "print(1)", str(tmp_path))
        assert result.success
        assert (tmp_path / "new.py").read_text() == "print(1)"

    def test_overwrite_file(self, tmp_path):
        (tmp_path / "exist.py").write_text("old")
        result = execute_file_edit("exist.py", "new", str(tmp_path))
        assert result.success
        assert (tmp_path / "exist.py").read_text() == "new"

    def test_create_nested(self, tmp_path):
        result = execute_file_edit("a/b/c.py", "x=1", str(tmp_path))
        assert result.success
        assert (tmp_path / "a" / "b" / "c.py").read_text() == "x=1"

    def test_no_create(self, tmp_path):
        result = execute_file_edit("missing.py", "x", str(tmp_path), create_if_missing=False)
        assert not result.success

    def test_path_traversal(self, tmp_path):
        result = execute_file_edit("../../etc/passwd", "x", str(tmp_path))
        assert not result.success
        assert "escapes working directory" in result.output


class TestExecuteFileRead:
    def test_read_file(self, tmp_path):
        (tmp_path / "test.py").write_text("line1\nline2\nline3\n")
        result = execute_file_read("test.py", str(tmp_path))
        assert result.success
        assert "line1" in result.output
        assert "line3" in result.output

    def test_line_range(self, tmp_path):
        (tmp_path / "test.py").write_text("a\nb\nc\nd\ne\n")
        result = execute_file_read("test.py", str(tmp_path), start_line=2, end_line=4)
        assert result.success
        assert "b" in result.output
        assert "d" in result.output

    def test_missing_file(self, tmp_path):
        result = execute_file_read("nope.py", str(tmp_path))
        assert not result.success

    def test_path_traversal(self, tmp_path):
        result = execute_file_read("../../etc/passwd", str(tmp_path))
        assert not result.success
        assert "escapes working directory" in result.output


class TestExecuteTool:
    def test_dispatch_bash(self, tmp_path):
        result = execute_tool("bash", {"command": "echo hi"}, str(tmp_path))
        assert result.success
        assert "hi" in result.output

    def test_dispatch_file_edit(self, tmp_path):
        result = execute_tool("file_edit", {"path": "f.py", "content": "x"}, str(tmp_path))
        assert result.success

    def test_dispatch_file_read(self, tmp_path):
        (tmp_path / "f.py").write_text("data")
        result = execute_tool("file_read", {"path": "f.py"}, str(tmp_path))
        assert result.success

    def test_unknown_tool(self, tmp_path):
        result = execute_tool("nonexistent", {}, str(tmp_path))
        assert not result.success


class TestAssessCompletion:
    def test_task_complete(self):
        assert _assess_completion("The task is complete.")

    def test_all_tests_pass(self):
        assert _assess_completion("All tests pass after the change.")

    def test_not_complete(self):
        assert not _assess_completion("I'm still working on it.")

    def test_empty(self):
        assert not _assess_completion("")

    def test_negation_not(self):
        assert not _assess_completion("I have not successfully implemented the feature")

    def test_negation_havent(self):
        assert not _assess_completion("I haven't completed the task successfully")


class TestOpenAIClient:
    def test_init(self):
        client = OpenAIClient(base_url="http://example.com/v1", model="test-model")
        assert client.base_url == "http://example.com/v1"
        assert client.model == "test-model"

    def test_strips_trailing_slash(self):
        client = OpenAIClient(base_url="http://example.com/v1/")
        assert client.base_url == "http://example.com/v1"


class TestAgentRunResult:
    def test_defaults(self):
        result = AgentRunResult(task_id="t1", task_description="test", success=False, total_turns=0)
        assert result.tool_calls == 0
        assert result.error is None
        assert result.conversation == []
