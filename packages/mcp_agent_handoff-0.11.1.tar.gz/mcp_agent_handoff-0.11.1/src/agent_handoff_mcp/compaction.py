"""Compaction helpers."""

from __future__ import annotations

import json
import logging
import os
import re
import sqlite3
from collections import OrderedDict
from collections.abc import Mapping
from datetime import UTC, datetime
from json import JSONDecodeError
from pathlib import Path
from typing import Literal, cast

from agentic_protocol import StructuredSummary, TurnRange
from pydantic import BaseModel, Field, field_validator

from .review_findings import list_review_findings
from .shared_primitives import _resolve_task_ref
from .shared_schema import _get_db_connection
from .touched_files import get_touched_files
from .verified_tests import get_verified_tests

_log = logging.getLogger("agent_handoff_mcp")

CompactionHarness = Literal["claude-code", "codex", "cursor", "manual"]
COMPACTION_HARNESS_CHOICES: tuple[str, ...] = ("claude-code", "codex", "cursor", "manual")
PROSE_RESIDUAL_SOFT_LIMIT_CHARS = 4096
PROSE_RESIDUAL_HARD_LIMIT_CHARS = 16384
TRANSCRIPT_PRE_READ_HARD_LIMIT_BYTES = PROSE_RESIDUAL_HARD_LIMIT_CHARS * 10
TURN_NUMBER_RE = re.compile(r"\bturn\s+(\d+)\b", re.IGNORECASE)

DEFAULT_MIN_NEW_TURNS = 1
DEFAULT_MIN_NEW_TOKENS = 0

_COMPACTION_ENV_ALIASES: tuple[tuple[str, str, str], ...] = (
    ("disabled", "AGENT_HANDOFF_COMPACTION_DISABLED", "AHMCP_COMPACTION_DISABLED"),
    (
        "min_new_turns",
        "AGENT_HANDOFF_COMPACTION_MIN_NEW_TURNS",
        "AHMCP_COMPACTION_MIN_NEW_TURNS",
    ),
    (
        "min_new_tokens",
        "AGENT_HANDOFF_COMPACTION_MIN_NEW_TOKENS",
        "AHMCP_COMPACTION_MIN_NEW_TOKENS",
    ),
)

_FALSY_DISABLED_VALUES: frozenset[str] = frozenset({"", "0", "false", "no", "off"})


def _coerce_disabled(value: str) -> bool:
    return value.strip().lower() not in _FALSY_DISABLED_VALUES


class CompactionSettings(BaseModel):
    """Typed config surface for the compaction hook and library.

    Reads ``AGENT_HANDOFF_COMPACTION_*`` env vars at the boundary; falls
    back to the legacy ``AHMCP_COMPACTION_*`` names with a captured
    deprecation warning per resolved field. Bad values raise
    ``pydantic.ValidationError`` so typos become loud failures rather
    than silent default fallbacks.
    """

    disabled: bool = False
    min_new_turns: int = Field(default=DEFAULT_MIN_NEW_TURNS, ge=0)
    min_new_tokens: int = Field(default=DEFAULT_MIN_NEW_TOKENS, ge=0)
    legacy_warnings: tuple[str, ...] = ()

    @field_validator("min_new_turns", "min_new_tokens", mode="before")
    @classmethod
    def _strip_int_strings(cls, value: object) -> object:
        if isinstance(value, str):
            return value.strip()
        return value

    @classmethod
    def from_env(
        cls, env: Mapping[str, str] | None = None
    ) -> "CompactionSettings":
        source = env if env is not None else os.environ
        warnings: list[str] = []
        fields: dict[str, object] = {}
        for field_name, canonical, legacy in _COMPACTION_ENV_ALIASES:
            raw = source.get(canonical, "")
            if raw == "":
                legacy_raw = source.get(legacy, "")
                if legacy_raw == "":
                    continue
                warnings.append(f"{legacy} is deprecated; rename to {canonical}")
                raw = legacy_raw
            if field_name == "disabled":
                fields[field_name] = _coerce_disabled(raw)
            else:
                fields[field_name] = raw
        return cls(legacy_warnings=tuple(warnings), **fields)


def _parse_changed_files_json(raw_value: object) -> list[str]:
    if not isinstance(raw_value, str) or raw_value.strip() == "":
        return []
    try:
        decoded = json.loads(raw_value)
    except JSONDecodeError:
        return []
    if not isinstance(decoded, list):
        return []
    return [item for item in decoded if isinstance(item, str) and item]


def _load_task_decisions(conn: sqlite3.Connection, *, task_ref: str) -> list[dict[str, object]]:
    rows = conn.execute(
        "SELECT decision, changed_files_json FROM decisions WHERE task_ref = ? ORDER BY created_at ASC, id ASC",
        (task_ref,),
    ).fetchall()
    decisions: list[dict[str, object]] = []
    for row in rows:
        decisions.append(
            {
                "decision_id": str(row["decision"]),
                "slug": str(row["decision"]),
                "changed_files": _parse_changed_files_json(row["changed_files_json"]),
            }
        )
    return decisions


def _ordered_unique(items: list[str]) -> list[str]:
    return list(OrderedDict.fromkeys(items))


def _validate_harness(harness: str) -> CompactionHarness:
    normalized = harness.strip()
    if normalized not in COMPACTION_HARNESS_CHOICES:
        allowed = ", ".join(COMPACTION_HARNESS_CHOICES)
        raise ValueError(f"Invalid harness: {normalized!r}. Valid values: {allowed}")
    return normalized  # type: ignore[return-value]


def _derive_turn_range(transcript: str) -> TurnRange:
    turn_numbers = [int(match.group(1)) for match in TURN_NUMBER_RE.finditer(transcript)]
    if turn_numbers:
        return TurnRange(start_turn=min(turn_numbers), end_turn=max(turn_numbers))
    non_empty_lines = [line for line in transcript.splitlines() if line.strip()]
    line_count = max(1, len(non_empty_lines))
    return TurnRange(start_turn=1, end_turn=line_count)


def _split_transcript_lines(transcript: str) -> list[str]:
    return [line.strip() for line in transcript.splitlines() if line.strip()]


def _truncate_residual(residual: str | None) -> str | None:
    if residual is None:
        return None
    if len(residual) > PROSE_RESIDUAL_HARD_LIMIT_CHARS:
        raise ValueError(f"prose_residual exceeds hard limit of {PROSE_RESIDUAL_HARD_LIMIT_CHARS} chars")
    if len(residual) <= PROSE_RESIDUAL_SOFT_LIMIT_CHARS:
        return residual
    omitted = len(residual) - PROSE_RESIDUAL_SOFT_LIMIT_CHARS
    _log.warning("Compaction prose_residual exceeded soft limit; truncating %s chars", omitted)
    return residual[:PROSE_RESIDUAL_SOFT_LIMIT_CHARS] + f"... [truncated; {omitted} chars omitted]"


def _read_transcript(transcript_path: str | Path) -> str:
    path = Path(transcript_path)
    if path.stat().st_size > TRANSCRIPT_PRE_READ_HARD_LIMIT_BYTES:
        raise ValueError(f"Transcript exceeds pre-read hard limit of {TRANSCRIPT_PRE_READ_HARD_LIMIT_BYTES} bytes")
    return path.read_text()


def _extract_summary_fields(conn: sqlite3.Connection, *, task_ref: str, transcript: str) -> dict[str, object]:
    raw_nonempty_lines = [line for line in transcript.splitlines(keepends=True) if line.strip()]
    transcript_lines = [line.strip() for line in raw_nonempty_lines]

    findings_payload = list_review_findings(task_ref=task_ref, status="all", limit=500, detail="full")
    finding_rows = findings_payload.get("data", {}).get("findings", [])
    findings_fixed: list[str] = []
    findings_opened: list[str] = []
    resolved_line_indexes: set[int] = set()
    for index, line in enumerate(transcript_lines):
        line_lower = line.lower()
        for finding in finding_rows:
            finding_id = str(finding.get("finding_id", ""))
            if not finding_id or finding_id.lower() not in line_lower:
                continue
            if any(word in line_lower for word in ("fixed", "fix", "resolved")):
                findings_fixed.append(finding_id)
                resolved_line_indexes.add(index)
            if any(word in line_lower for word in ("opened", "open", "reopened")):
                findings_opened.append(finding_id)
                resolved_line_indexes.add(index)

    tests_payload = get_verified_tests(task_ref=task_ref, limit=500)
    test_rows = tests_payload.get("data", {}).get("tests", [])
    tests_verified: list[str] = []
    for index, line in enumerate(transcript_lines):
        for test_row in test_rows:
            command = str(test_row.get("command", ""))
            if command and command in line:
                tests_verified.append(command)
                resolved_line_indexes.add(index)

    touches_payload = get_touched_files(task_ref=task_ref, limit=500)
    touch_rows = touches_payload.get("data", {}).get("touches", [])
    files_touched: list[str] = []
    for index, line in enumerate(transcript_lines):
        for touch_row in touch_rows:
            file_path = str(touch_row.get("file_path", ""))
            if file_path and file_path in line:
                files_touched.append(file_path)
                resolved_line_indexes.add(index)

    decisions = _load_task_decisions(conn, task_ref=task_ref)
    resolved_decisions: list[dict[str, str]] = []
    for index, line in enumerate(transcript_lines):
        for decision in decisions:
            decision_id = str(decision["decision_id"])
            if decision_id and decision_id in line:
                resolved_decisions.append({"decision_id": decision_id, "slug": str(decision["slug"])})
                resolved_line_indexes.add(index)
        for decision in decisions:
            changed_files = decision["changed_files"]
            if not isinstance(changed_files, list):
                continue
            for changed_file in changed_files:
                if changed_file in line:
                    files_touched.append(changed_file)
                    resolved_line_indexes.add(index)

    if not resolved_line_indexes:
        prose_residual = transcript if transcript else None
    else:
        residual_lines = [line for index, line in enumerate(raw_nonempty_lines) if index not in resolved_line_indexes]
        prose_residual = "".join(residual_lines).rstrip("\n") if residual_lines else None

    return {
        "turn_range": _derive_turn_range(transcript),
        "decisions": _ordered_unique([json.dumps(item, sort_keys=True) for item in resolved_decisions]),
        "findings_fixed": _ordered_unique(findings_fixed),
        "findings_opened": _ordered_unique(findings_opened),
        "tests_verified": _ordered_unique(tests_verified),
        "files_touched": _ordered_unique(files_touched),
        "prose_residual": _truncate_residual(prose_residual),
    }


def _next_compaction_id(conn, *, task_ref: str) -> str:
    # MAX(compaction_id) is safe because the suffix is fixed-width zero-padded;
    # if that invariant changes, this query must change with it.
    row = conn.execute(
        "SELECT MAX(compaction_id) AS compaction_id FROM session_compactions WHERE task_ref = ?",
        (task_ref,),
    ).fetchone()
    if row is None or row["compaction_id"] is None:
        next_suffix = 1
    else:
        raw_compaction_id = str(row["compaction_id"])
        suffix_text = raw_compaction_id.rsplit("-", 1)[-1]
        try:
            next_suffix = int(suffix_text) + 1
        except ValueError as exc:
            raise ValueError(f"Malformed compaction_id stored for task {task_ref}: {raw_compaction_id}") from exc
    if next_suffix > 9999:
        raise ValueError(f"compaction_id suffix overflow for task {task_ref}")
    return f"C-{task_ref}-{next_suffix:04d}"


def compact_session(
    transcript_path: str | Path,
    task_ref: str,
    harness: CompactionHarness,
    session_id: str,
) -> str:
    normalized_harness = _validate_harness(harness)
    transcript = _read_transcript(transcript_path)
    now = datetime.now(UTC)

    with _get_db_connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        resolved_task_ref = _resolve_task_ref(conn, task_ref)
        compaction_id = _next_compaction_id(conn, task_ref=resolved_task_ref)
        extracted = _extract_summary_fields(conn, task_ref=resolved_task_ref, transcript=transcript)
        summary = StructuredSummary(
            compaction_id=compaction_id,
            session_id=session_id,
            harness=normalized_harness,
            task_ref=resolved_task_ref,
            turn_range=cast(TurnRange, extracted["turn_range"]),
            decisions=[json.loads(item) for item in cast(list[str], extracted["decisions"])],
            findings_fixed=cast(list[str], extracted["findings_fixed"]),
            findings_opened=cast(list[str], extracted["findings_opened"]),
            tests_verified=cast(list[str], extracted["tests_verified"]),
            files_touched=cast(list[str], extracted["files_touched"]),
            prose_residual=cast("str | None", extracted["prose_residual"]),
            created_at=now,
        )
        conn.execute(
            """
            INSERT INTO session_compactions (
                compaction_id, session_id, harness, task_ref, turn_range,
                structured_summary_json, prose_residual, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                summary.compaction_id,
                summary.session_id,
                summary.harness,
                summary.task_ref,
                summary.turn_range.model_dump_json(),
                summary.model_dump_json(),
                summary.prose_residual,
                now.strftime("%Y-%m-%d %H:%M:%S"),
            ),
        )
        conn.commit()
    return compaction_id


def get_compaction(compaction_id: str) -> StructuredSummary:
    normalized_compaction_id = compaction_id.strip()
    if not normalized_compaction_id:
        raise ValueError("compaction_id is required")

    with _get_db_connection() as conn:
        row = conn.execute(
            "SELECT structured_summary_json FROM session_compactions WHERE compaction_id = ?",
            (normalized_compaction_id,),
        ).fetchone()
        if row is None:
            raise ValueError(f"Unknown compaction_id: {normalized_compaction_id}")
        return StructuredSummary.model_validate_json(str(row["structured_summary_json"]))


def _count_decisions_after(conn: sqlite3.Connection, *, task_ref: str, after: datetime) -> int:
    # Stored compaction created_at is ISO with 'T'/'Z'; decisions.created_at is
    # the SQLite default 'YYYY-MM-DD HH:MM:SS'. Compare as ISO strings after
    # normalizing the compaction value to the same shape.
    cutoff = after.strftime("%Y-%m-%d %H:%M:%S")
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM decisions WHERE task_ref = ? AND created_at > ?",
        (task_ref, cutoff),
    ).fetchone()
    return int(row["n"]) if row is not None else 0


def render_cold_start_compaction(task_ref: str | None = None) -> str | None:
    """Render the latest compaction as an ID-only cold-start block.

    Returns ``None`` when no compaction row exists for the resolved task,
    so cold-start callers can fall back to the pre-AHMCP-34 baseline
    without emitting any extra bytes.
    """
    with _get_db_connection() as conn:
        resolved_task_ref = _resolve_task_ref(conn, task_ref)
        row = conn.execute(
            """
            SELECT structured_summary_json, created_at
            FROM session_compactions
            WHERE task_ref = ?
            ORDER BY created_at DESC, compaction_id DESC
            LIMIT 1
            """,
            (resolved_task_ref,),
        ).fetchone()
        if row is None:
            return None
        latest = StructuredSummary.model_validate_json(str(row["structured_summary_json"]))
        # Use the row's stored created_at (string) so the comparison is
        # against the same column the row was written with.
        stored_created_at = datetime.strptime(str(row["created_at"]), "%Y-%m-%d %H:%M:%S").replace(tzinfo=UTC)
        newer_decisions = _count_decisions_after(conn, task_ref=resolved_task_ref, after=stored_created_at)

    lines: list[str] = []
    lines.append(f"Latest compaction: {latest.compaction_id}")
    lines.append(f"Turns {latest.turn_range.start_turn}–{latest.turn_range.end_turn}")
    decision_ids = [decision.decision_id for decision in latest.decisions]
    lines.append(f"Decisions: {', '.join(decision_ids) if decision_ids else '(none)'}")
    lines.append(f"Findings fixed: {', '.join(latest.findings_fixed) if latest.findings_fixed else '(none)'}")
    lines.append(f"Tests verified: {', '.join(latest.tests_verified) if latest.tests_verified else '(none)'}")
    lines.append(f"Files touched: {', '.join(latest.files_touched) if latest.files_touched else '(none)'}")
    if newer_decisions > 0:
        lines.append(f"(compaction stale; {newer_decisions} decisions newer)")
    return "\n".join(lines)


def get_latest_compaction(task_ref: str | None = None) -> StructuredSummary | None:
    with _get_db_connection() as conn:
        resolved_task_ref = _resolve_task_ref(conn, task_ref)
        row = conn.execute(
            """
            SELECT structured_summary_json
            FROM session_compactions
            WHERE task_ref = ?
            ORDER BY created_at DESC, compaction_id DESC
            LIMIT 1
            """,
            (resolved_task_ref,),
        ).fetchone()
        if row is None:
            return None
        return StructuredSummary.model_validate_json(str(row["structured_summary_json"]))
