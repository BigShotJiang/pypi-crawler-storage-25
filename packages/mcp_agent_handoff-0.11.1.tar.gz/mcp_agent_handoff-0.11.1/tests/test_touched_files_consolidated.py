"""AHMCP-45 Slice 3: touched_files(operation=...) merge.

Asserts the merged ``touched_files`` MCP tool dispatches to ``record``
and ``list`` operations with the same envelopes the legacy
``record_file_touch`` and ``get_touched_files`` tools produced, and
that the legacy registrations have been removed in favor of the
consolidated entry.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agent_handoff_mcp import api as mcp_server
from agent_handoff_mcp.config import RuntimeConfig


@pytest.fixture()
def isolated_runtime(tmp_path: Path) -> RuntimeConfig:
    state_dir = tmp_path / ".task-state"
    state_dir.mkdir(parents=True, exist_ok=True)
    runtime = RuntimeConfig.for_workspace(
        tmp_path,
        state_dir=state_dir,
        current_task_path=tmp_path / "CURRENT_TASK.json",
    )
    mcp_server.configure_runtime(runtime)
    mcp_server.set_handoff_state(
        task_ref="AHMCP-DEMO",
        objective="exercise touched_files",
        status="in_progress",
    )
    return runtime


def test_touched_files_operation_record_returns_envelope(isolated_runtime: RuntimeConfig) -> None:
    from agent_handoff_mcp.api import touched_files

    result = touched_files(
        {
            "operation": "record",
            "file_path": "packages/foo/bar.py",
            "change_kind": "edit",
            "task_ref": "AHMCP-DEMO",
        }
    )

    assert result["ok"] is True
    assert result["tool"] == "touched_files"
    assert result["data"]["touch"]["file_path"] == "packages/foo/bar.py"
    assert result["data"]["touch"]["change_kind"] == "edit"


def test_touched_files_operation_list_returns_recorded_rows(isolated_runtime: RuntimeConfig) -> None:
    from agent_handoff_mcp.api import touched_files

    touched_files(
        {
            "operation": "record",
            "file_path": "packages/foo/a.py",
            "change_kind": "edit",
            "task_ref": "AHMCP-DEMO",
        }
    )
    touched_files(
        {
            "operation": "record",
            "file_path": "packages/foo/b.py",
            "change_kind": "add",
            "task_ref": "AHMCP-DEMO",
        }
    )

    listed = touched_files({"operation": "list", "task_ref": "AHMCP-DEMO"})

    assert listed["ok"] is True
    assert listed["tool"] == "touched_files"
    paths = {row["file_path"] for row in listed["data"]["touches"]}
    assert paths == {"packages/foo/a.py", "packages/foo/b.py"}
    assert listed["data"]["total_matching"] == 2


def test_touched_files_record_rejects_invalid_change_kind(isolated_runtime: RuntimeConfig) -> None:
    from agent_handoff_mcp.api import touched_files

    result = touched_files(
        {
            "operation": "record",
            "file_path": "packages/foo/bar.py",
            "change_kind": "bogus",
            "task_ref": "AHMCP-DEMO",
        }
    )
    assert result["ok"] is False
    assert "change_kind" in result["data"]["error"].lower() or "Invalid" in result["data"]["error"]


def test_registry_replaces_touched_files_split_with_consolidated_tool() -> None:
    from agent_handoff_mcp.api import _build_tool_registry

    registry = _build_tool_registry()
    names = {entry.name for entry in registry}

    assert "touched_files" in names, "consolidated touched_files tool must be registered"
    assert "record_file_touch" not in names, (
        "legacy record_file_touch must be removed in favor of touched_files(operation='record')"
    )
    assert "get_touched_files" not in names, (
        "legacy get_touched_files must be removed in favor of touched_files(operation='list')"
    )


def test_expected_handoff_tool_count_decremented_for_slice_3() -> None:
    """Slice 3 dropped the count by exactly 1 (record_file_touch + get_touched_files -> touched_files).

    The live invariant is asserted in the per-slice test file for the most recent
    slice, so this test only enforces a ceiling of 26 (the post-slice-3 value).
    """
    from agent_handoff_mcp.invariants import EXPECTED_HANDOFF_TOOL_COUNT

    assert EXPECTED_HANDOFF_TOOL_COUNT <= 26
