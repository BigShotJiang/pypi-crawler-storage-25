from __future__ import annotations

from agent_handoff_mcp.api import TOOL_DESCRIPTIONS, _build_tool_registry
from agent_handoff_mcp.invariants import EXPECTED_HANDOFF_TOOL_COUNT


def test_search_handoff_description_advertises_decision_fields() -> None:
    """MCP clients discover the decision projection through the tool description."""
    desc = TOOL_DESCRIPTIONS["search_handoff"]
    assert "decision_fields" in desc, (
        "search_handoff description must advertise the decision_fields projection so "
        "MCP clients can discover it without reading the contract doc"
    )


def test_get_handoff_state_description_advertises_decision_filters() -> None:
    """MCP clients discover the exact-read decision filters through the tool description."""
    desc = TOOL_DESCRIPTIONS["get_handoff_state"]
    for token in ("decision_fields", "decision_branch", "decision_id_prefix"):
        assert token in desc, f"get_handoff_state description must mention {token}"


def test_tool_registry_matches_named_invariant() -> None:
    """The live tool registry size must equal the named cross-transport invariant.

    Adding or removing a tool requires updating EXPECTED_HANDOFF_TOOL_COUNT in
    one place; this test ensures the registry never drifts away from it.
    """
    registry = _build_tool_registry()
    tool_names = {entry.name for entry in registry}
    assert len(tool_names) == len(registry), "duplicate tool names in registry"
    assert len(registry) == EXPECTED_HANDOFF_TOOL_COUNT
