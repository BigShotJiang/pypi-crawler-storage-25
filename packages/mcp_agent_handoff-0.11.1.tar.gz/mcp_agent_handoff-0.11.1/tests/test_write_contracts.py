"""Plan 0010 Slice 4 — write-contract registry."""

from __future__ import annotations


def test_registry_has_top_level_rows_for_known_mcp_write_tools() -> None:
    from agent_handoff_mcp.write_contracts import REGISTRY, get_write_contract

    expected_top_level = {
        "set_handoff_state",
        "record_event",
        "review_runs",
        "review_findings",
        "next_actions",
        "close_slice",
        "archive",
        "update_task_status",
        "record_file_touch",
        "artifacts",
        "compact_session",
        "import_handoff_state",
        "export_handoff_state",
    }
    assert expected_top_level <= set(REGISTRY)
    contract = get_write_contract("close_slice")
    assert contract is not None
    assert contract.tool_name == "close_slice"
    assert isinstance(contract.required, list)


def test_record_event_carries_typed_subgrammar_variants() -> None:
    from agent_handoff_mcp.write_contracts import get_write_contract

    contract = get_write_contract("record_event")
    assert contract is not None
    variants = contract.variants
    assert {"decision", "test_result", "blocker"} <= set(variants)
    decision_variant = variants["decision"]
    assert "decision" in decision_variant.field_grammars


def test_validate_write_rejects_missing_required_field() -> None:
    from agent_handoff_mcp.write_contracts import validate_write

    result = validate_write("close_slice", {})
    assert result["ok"] is False
    assert any("required" in err.lower() or "missing" in err.lower() for err in result["errors"])


def test_validate_write_accepts_minimum_valid_payload() -> None:
    from agent_handoff_mcp.write_contracts import validate_write

    result = validate_write(
        "close_slice",
        {
            "task_ref": "AHMCP-EXAMPLE",
            "author_tag": "claude",
            "work_ref": "plan0010",
            "slug": "demo",
            "rationale": "## Changes\n- a\n\n## Verification\n- b\n\n## Schema / Contract Changes\n- none\n\n## Open Threads\n- none",
            "session": "session-1",
            "expected_revision": 1,
        },
    )
    assert result["ok"] is True, result


def test_validate_write_unknown_tool_reports_missing_registry_row() -> None:
    from agent_handoff_mcp.write_contracts import validate_write

    result = validate_write("totally_made_up_tool", {})
    assert result["ok"] is False
    assert any("registry" in err.lower() or "unknown" in err.lower() for err in result["errors"])


def test_record_event_decision_accepts_optional_plan_revision() -> None:
    from agent_handoff_mcp.write_contracts import get_write_contract

    contract = get_write_contract("record_event")
    assert contract is not None
    decision_variant = contract.variants["decision"]
    assert "plan_revision" in decision_variant.optional
    assert "plan_revision" in decision_variant.field_grammars


def test_validate_write_rejects_malformed_plan_revision() -> None:
    from agent_handoff_mcp.write_contracts import validate_write

    result = validate_write(
        "record_event",
        {
            "event": {
                "event_kind": "decision",
                "decision": "claude_demo_decision",
                "rationale": "demo",
                "plan_revision": "not-a-revision-name",
            }
        },
    )
    assert result["ok"] is False
    assert any("plan_revision" in err for err in result["errors"])


def test_validate_write_accepts_valid_plan_revision() -> None:
    from agent_handoff_mcp.write_contracts import validate_write

    result = validate_write(
        "record_event",
        {
            "event": {
                "event_kind": "decision",
                "decision": "claude_demo_decision",
                "rationale": "demo",
                "plan_revision": "0010-frictionless-receipts-r2.md",
            }
        },
    )
    assert result["ok"] is True, result
