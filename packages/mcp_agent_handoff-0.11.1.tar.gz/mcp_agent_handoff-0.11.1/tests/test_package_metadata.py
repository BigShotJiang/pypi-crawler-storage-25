from __future__ import annotations

import re
import tomllib
from pathlib import Path

from packaging.version import Version

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def _load_pyproject() -> dict:
    with (PACKAGE_ROOT / "pyproject.toml").open("rb") as handle:
        return tomllib.load(handle)


def test_pyproject_declares_hoisted_install_metadata() -> None:
    pyproject = _load_pyproject()

    hoisted = pyproject["tool"]["hoisted"]
    assert hoisted["repository"] == "darce/mcp-agent-handoff"
    assert hoisted["install_url"] == "git+ssh://git@github.com/darce/mcp-agent-handoff.git@v{version}"


def test_changelog_records_hoist_mvp_metadata_entry() -> None:
    changelog = (PACKAGE_ROOT / "CHANGELOG.md").read_text()

    assert "Hoist Agentic System MVP" in changelog
    assert "git+ssh://git@github.com/darce/mcp-agent-handoff.git@v{version}" in changelog


def test_pyproject_pins_agentic_protocol_lower_bound_at_branch_naming_release() -> None:
    # `agent_handoff_mcp.__init__` re-exports `agentic_protocol.branch_naming`
    # at import time (Plan 0006 Slice 1). If a `uvx mcp-agent-handoff` env
    # resolves an `agentic-protocol` older than 0.1.2 (the first release
    # carrying `branch_naming`), the package crashes on import before the
    # CLI / MCP server / init-state / hook helpers can run. Pin the floor
    # here so the dep declaration cannot silently drift below the contract.
    pyproject = _load_pyproject()
    deps = pyproject["project"]["dependencies"]
    protocol_dep = next((d for d in deps if d.startswith("agentic-protocol")), None)
    assert protocol_dep is not None, "agentic-protocol must be declared as a runtime dep"
    floor_match = re.search(r">=\s*([0-9]+(?:\.[0-9]+)*)", protocol_dep)
    assert floor_match, f"agentic-protocol pin must declare a >= lower bound, got {protocol_dep!r}"
    assert Version(floor_match.group(1)) >= Version("0.1.2"), (
        f"agentic-protocol lower bound must be >=0.1.2 (the first release containing "
        f"branch_naming), got {protocol_dep!r}"
    )
    assert "<0.2.0" in protocol_dep, (
        f"agentic-protocol upper bound must remain <0.2.0 (single major hard pin), got {protocol_dep!r}"
    )
