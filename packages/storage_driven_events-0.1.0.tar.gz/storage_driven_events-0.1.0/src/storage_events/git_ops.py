"""Git subprocess helpers for change detection."""

import subprocess
from pathlib import Path

LAST_PROCESSED_REF = "refs/storage-events/last-processed"


def _run(args: list[str], cwd: Path | str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True, cwd=cwd)


def is_repo(path: Path | str) -> bool:
    result = _run(["git", "rev-parse", "--git-dir"], cwd=path)
    return result.returncode == 0


def clone(url: str, path: Path | str, branch: str | None = None) -> None:
    cmd = ["git", "clone", url, str(path)]
    if branch:
        cmd += ["--branch", branch]
    result = _run(cmd)
    if result.returncode != 0:
        raise RuntimeError(f"git clone failed: {result.stderr.strip()}")


def pull(path: Path | str) -> str:
    result = _run(["git", "pull"], cwd=path)
    if result.returncode != 0:
        raise RuntimeError(f"git pull failed: {result.stderr.strip()}")
    return result.stdout.strip()


def head(path: Path | str) -> str:
    result = _run(["git", "rev-parse", "HEAD"], cwd=path)
    if result.returncode != 0:
        raise RuntimeError(f"git rev-parse HEAD failed: {result.stderr.strip()}")
    return result.stdout.strip()


def rev_parse(path: Path | str, ref: str) -> str | None:
    result = _run(["git", "rev-parse", "--verify", ref], cwd=path)
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def update_ref(path: Path | str, ref: str, target: str) -> None:
    result = _run(["git", "update-ref", ref, target], cwd=path)
    if result.returncode != 0:
        raise RuntimeError(f"git update-ref failed: {result.stderr.strip()}")


def diff_tree(path: Path | str, from_ref: str, to_ref: str) -> list[tuple[str, str]]:
    """Return list of (status, filepath) tuples for changes between two refs.

    Status codes: A (added), M (modified), D (deleted), R (renamed), C (copied).
    For renames, filepath is the new path.
    """
    result = _run(
        ["git", "diff-tree", "-r", "--name-status", "--no-commit-id", from_ref, to_ref],
        cwd=path,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git diff-tree failed: {result.stderr.strip()}")

    changes = []
    for line in result.stdout.strip().splitlines():
        if not line:
            continue
        parts = line.split("\t")
        status = parts[0][0]  # First char handles R100, C100 etc.
        filepath = parts[-1]  # Last path is the new name for renames
        changes.append((status, filepath))
    return changes
