from storage_events.cli import main

main()
