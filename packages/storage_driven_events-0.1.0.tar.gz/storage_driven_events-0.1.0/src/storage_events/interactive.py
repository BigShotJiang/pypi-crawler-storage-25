"""Interactive prompt helpers."""


def prompt(message: str, default: str | None = None) -> str | None:
    suffix = f" [{default}]" if default else ""
    value = input(f"{message}{suffix}: ").strip()
    return value or default


def confirm(message: str, default: bool = True) -> bool:
    hint = "Y/n" if default else "y/N"
    value = input(f"{message} [{hint}]: ").strip().lower()
    if not value:
        return default
    return value in ("y", "yes")
