"""CLI entry point with setup and scan subcommands."""

import argparse
import sys

from storage_events import __version__


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="storage-events",
        description="Git-based change detection for folders.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    # scan subcommand
    scan_parser = subparsers.add_parser("scan", help="Detect changes and dispatch to handler")
    scan_parser.add_argument("repo_path", nargs="?", default=".", help="Path to git repository (default: .)")
    scan_parser.add_argument("--handler", help="Path to handler executable")
    scan_parser.add_argument("--pull", action="store_true", help="Run git pull before scanning")
    scan_parser.add_argument("--dry-run", action="store_true", help="Print changes without advancing ref")

    # setup subcommand
    setup_parser = subparsers.add_parser("setup", help="Set up change detection on a repository")
    setup_parser.add_argument("--repo", help="Git repository URL (triggers non-interactive mode)")
    setup_parser.add_argument("--path", default=None, help="Local clone path (default: ./<repo-name>)")
    setup_parser.add_argument("--branch", default="main", help="Branch to track (default: main)")
    setup_parser.add_argument("--handler", help="Path to handler script")
    setup_parser.add_argument("--cron", type=int, metavar="MINUTES", help="Set up cron polling at this interval")
    setup_parser.add_argument("--no-hook", action="store_true", help="Skip post-merge hook installation")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "scan":
        from storage_events.scan import run_scan

        sys.exit(run_scan(args.repo_path, args.handler, args.pull, args.dry_run))

    if args.command == "setup":
        from storage_events.setup_cmd import run_setup

        sys.exit(run_setup(args))
