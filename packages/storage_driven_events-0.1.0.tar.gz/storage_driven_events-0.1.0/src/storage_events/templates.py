"""Templates for generated files."""

DEFAULT_HANDLER = '''\
#!/usr/bin/env python3
"""Default handler: pretty-print git changes and diffs to the console."""

import os
import subprocess
import sys

STATUS_LABELS = {
    "A": "ADDED",
    "M": "MODIFIED",
    "D": "DELETED",
    "R": "RENAMED",
    "C": "COPIED",
}


def get_diff(filepath, status):
    """Get the diff for a file using env vars set by storage-events scan."""
    repo = os.environ.get("STORAGE_EVENTS_REPO")
    from_ref = os.environ.get("STORAGE_EVENTS_FROM_REF")
    to_ref = os.environ.get("STORAGE_EVENTS_TO_REF")
    if not (repo and from_ref and to_ref):
        return None
    if status == "D":
        # Show content of deleted file
        result = subprocess.run(
            ["git", "diff", from_ref, to_ref, "--", filepath],
            capture_output=True, text=True, cwd=repo,
        )
    else:
        result = subprocess.run(
            ["git", "diff", from_ref, to_ref, "--", filepath],
            capture_output=True, text=True, cwd=repo,
        )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    return None


def main():
    for line in sys.stdin:
        line = line.rstrip("\\n")
        if not line:
            continue
        parts = line.split("\\t")
        status_code = parts[0][0]
        filepath = parts[-1]
        label = STATUS_LABELS.get(status_code, status_code)
        print(f"{label:<10} {filepath}")
        diff = get_diff(filepath, status_code)
        if diff:
            for diff_line in diff.splitlines():
                print(f"  {diff_line}")
            print()


if __name__ == "__main__":
    main()
'''

POST_MERGE_HOOK = '''\
#!/usr/bin/env bash
# Installed by storage-driven-events.
# Fires after git pull merges new commits.
# ORIG_HEAD = HEAD before pull, HEAD = HEAD after pull.

HANDLER="${STORAGE_EVENTS_HANDLER:-}"

changes=$(git diff-tree -r --name-status --no-commit-id ORIG_HEAD HEAD)

if [ -z "$changes" ]; then
    exit 0
fi

if [ -n "$HANDLER" ]; then
    echo "$changes" | "$HANDLER"
else
    echo "$changes"
fi
'''
