"""Scan subcommand: detect changes and dispatch to handler."""

import os
import subprocess
import sys
from pathlib import Path

from storage_events import git_ops


def run_scan(repo_path: str, handler: str | None, pull: bool, dry_run: bool) -> int:
    path = Path(repo_path).resolve()

    if not git_ops.is_repo(path):
        print(f"Error: {path} is not a git repository.", file=sys.stderr)
        return 1

    if pull:
        try:
            output = git_ops.pull(path)
            if output:
                print(output, file=sys.stderr)
        except RuntimeError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    # Check if the last-processed ref exists
    last_ref = git_ops.rev_parse(path, git_ops.LAST_PROCESSED_REF)
    if last_ref is None:
        current_head = git_ops.head(path)
        git_ops.update_ref(path, git_ops.LAST_PROCESSED_REF, current_head)
        print(f"Initialized last-processed ref to {current_head[:8]}. Future changes will be detected.")
        return 0

    current_head = git_ops.head(path)
    if last_ref == current_head:
        return 0

    changes = git_ops.diff_tree(path, last_ref, current_head)
    if not changes:
        return 0

    # Format as tab-separated lines (matching git diff-tree output)
    change_text = "\n".join(f"{status}\t{filepath}" for status, filepath in changes) + "\n"

    # Auto-detect default handler if none specified
    if not handler:
        default_handler = path / "default-handler.py"
        if default_handler.exists():
            handler = str(default_handler)

    if handler:
        env = {
            **os.environ,
            "STORAGE_EVENTS_REPO": str(path),
            "STORAGE_EVENTS_FROM_REF": last_ref,
            "STORAGE_EVENTS_TO_REF": current_head,
        }
        try:
            result = subprocess.run(
                [handler],
                input=change_text,
                text=True,
                env=env,
            )
        except FileNotFoundError:
            print(f"Error: handler not found: {handler}", file=sys.stderr)
            return 1
        if result.returncode != 0:
            print(f"Handler exited with code {result.returncode}.", file=sys.stderr)
            return result.returncode
    else:
        sys.stdout.write(change_text)

    if not dry_run:
        git_ops.update_ref(path, git_ops.LAST_PROCESSED_REF, current_head)

    return 0
