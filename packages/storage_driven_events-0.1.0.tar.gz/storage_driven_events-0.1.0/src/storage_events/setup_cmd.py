"""Setup subcommand: clone, init ref, install handler and hook."""

import os
import subprocess
import sys
from argparse import Namespace
from pathlib import Path

from storage_events import git_ops
from storage_events.hooks import hook_exists, install_hook
from storage_events.interactive import confirm, prompt
from storage_events.templates import DEFAULT_HANDLER


def _repo_name_from_url(url: str) -> str:
    """Derive a directory name from a git repo URL."""
    name = url.rstrip("/").rsplit("/", 1)[-1]
    if name.endswith(".git"):
        name = name[:-4]
    return name


def _write_default_handler(repo_path: Path) -> Path:
    handler_path = repo_path / "default-handler.py"
    handler_path.write_text(DEFAULT_HANDLER)
    handler_path.chmod(handler_path.stat().st_mode | 0o111)
    return handler_path


def _init_ref(repo_path: Path) -> None:
    existing = git_ops.rev_parse(repo_path, git_ops.LAST_PROCESSED_REF)
    if existing:
        print("Last-processed ref already exists, skipping.")
        return
    current_head = git_ops.head(repo_path)
    git_ops.update_ref(repo_path, git_ops.LAST_PROCESSED_REF, current_head)
    print(f"Initialized last-processed ref to {current_head[:8]}.")


def _clone_or_reuse(url: str, path: Path, branch: str | None) -> Path:
    path = path.resolve()
    if path.exists() and git_ops.is_repo(path):
        print(f"Using existing repo at {path}")
        return path
    if path.exists() and any(path.iterdir()):
        print(f"Error: {path} exists and is not empty.", file=sys.stderr)
        sys.exit(1)
    print(f"Cloning {url} into {path}...")
    git_ops.clone(url, path, branch)
    print("Clone complete.")
    return path


def _setup_cron(repo_path: Path, interval: int, handler: str | None) -> None:
    handler_arg = f" --handler {handler}" if handler else ""
    cron_line = (
        f"*/{interval} * * * * "
        f"cd {repo_path} && git pull -q && storage-events scan{handler_arg}"
    )
    result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    existing = result.stdout if result.returncode == 0 else ""
    if str(repo_path) in existing and "storage-events scan" in existing:
        print("Cron entry already exists, skipping.")
        return
    new_crontab = existing.rstrip("\n") + "\n" + cron_line + "\n"
    proc = subprocess.run(["crontab", "-"], input=new_crontab, capture_output=True, text=True)
    if proc.returncode != 0:
        print(f"Failed to install cron: {proc.stderr}", file=sys.stderr)
        return
    print(f"Installed cron job (every {interval} min):")
    print(f"  {cron_line}")


def _interactive_setup() -> int:
    print("=== Storage Events Setup ===\n")

    repo_url = prompt("Git repository URL")
    if not repo_url:
        print("Repository URL is required.", file=sys.stderr)
        return 1

    default_path = f"./{_repo_name_from_url(repo_url)}"
    local_path = prompt("Local path", default=default_path)
    branch = prompt("Branch", default="main")
    handler = prompt("Handler script (leave blank for default)", default=None)
    install_hook_yn = confirm("Install post-merge hook?", default=True)
    setup_cron_yn = confirm("Set up cron job?", default=False)
    cron_interval = None
    if setup_cron_yn:
        interval_str = prompt("Poll interval in minutes", default="15")
        cron_interval = int(interval_str) if interval_str else 15

    print()

    repo_path = _clone_or_reuse(repo_url, Path(local_path).expanduser(), branch)
    _init_ref(repo_path)

    if not handler:
        handler_path = _write_default_handler(repo_path)
        print(f"Installed default handler at {handler_path}")

    if install_hook_yn:
        if hook_exists(repo_path):
            if confirm("Post-merge hook already exists. Overwrite?", default=False):
                install_hook(repo_path)
                print("Installed post-merge hook.")
            else:
                print("Skipped hook installation.")
        else:
            install_hook(repo_path)
            print("Installed post-merge hook.")

    if setup_cron_yn and cron_interval:
        _setup_cron(repo_path, cron_interval, handler)

    _print_done(repo_path, handler)
    return 0


def _non_interactive_setup(args: Namespace) -> int:
    path = args.path if args.path else f"./{_repo_name_from_url(args.repo)}"
    repo_path = _clone_or_reuse(args.repo, Path(path).expanduser(), args.branch)
    _init_ref(repo_path)

    if not args.handler:
        handler_path = _write_default_handler(repo_path)
        print(f"Installed default handler at {handler_path}")

    if not args.no_hook:
        if hook_exists(repo_path):
            print("Post-merge hook already exists, skipping.")
        else:
            install_hook(repo_path)
            print("Installed post-merge hook.")

    if args.cron:
        _setup_cron(repo_path, args.cron, args.handler)

    _print_done(repo_path, args.handler)
    return 0


def _print_done(repo_path: Path, handler: str | None) -> None:
    handler_hint = f" --handler {handler}" if handler else ""
    print(f"\nDone. To scan manually:")
    print(f"  storage-events scan {repo_path} --pull{handler_hint}")


def run_setup(args: Namespace) -> int:
    if args.repo:
        return _non_interactive_setup(args)
    return _interactive_setup()
