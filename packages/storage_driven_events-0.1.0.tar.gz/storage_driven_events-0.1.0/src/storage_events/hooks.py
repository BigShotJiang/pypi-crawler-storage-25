"""Post-merge hook installation and management."""

import os
from pathlib import Path

from storage_events.templates import POST_MERGE_HOOK


def hook_exists(repo_path: Path | str) -> bool:
    return (Path(repo_path) / ".git" / "hooks" / "post-merge").exists()


def install_hook(repo_path: Path | str) -> None:
    hook_path = Path(repo_path) / ".git" / "hooks" / "post-merge"
    hook_path.parent.mkdir(parents=True, exist_ok=True)
    hook_path.write_text(POST_MERGE_HOOK)
    hook_path.chmod(hook_path.stat().st_mode | 0o111)


def uninstall_hook(repo_path: Path | str) -> None:
    hook_path = Path(repo_path) / ".git" / "hooks" / "post-merge"
    if hook_path.exists():
        os.remove(hook_path)
