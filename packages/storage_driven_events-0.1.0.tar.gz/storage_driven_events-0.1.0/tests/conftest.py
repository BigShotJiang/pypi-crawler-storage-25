import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """Create a temporary git repo with an initial commit."""
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(tmp_path), "config", "user.name", "Test"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(tmp_path), "commit", "--allow-empty", "-m", "init"],
        check=True, capture_output=True,
    )
    return tmp_path


@pytest.fixture
def tmp_repo_with_remote(tmp_path: Path) -> tuple[Path, Path]:
    """Create a bare remote and a clone of it, both with an initial commit."""
    remote = tmp_path / "remote.git"
    clone = tmp_path / "clone"

    # Create bare remote
    subprocess.run(["git", "init", "--bare", str(remote)], check=True, capture_output=True)

    # Clone it
    subprocess.run(["git", "clone", str(remote), str(clone)], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(clone), "config", "user.email", "test@test.com"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(clone), "config", "user.name", "Test"],
        check=True, capture_output=True,
    )

    # Initial commit
    (clone / "README.md").write_text("init")
    subprocess.run(["git", "-C", str(clone), "add", "."], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(clone), "commit", "-m", "init"],
        check=True, capture_output=True,
    )
    subprocess.run(["git", "-C", str(clone), "push"], check=True, capture_output=True)

    return clone, remote
