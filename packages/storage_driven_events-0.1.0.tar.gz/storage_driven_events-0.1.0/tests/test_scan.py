import subprocess
from pathlib import Path

from storage_events import git_ops
from storage_events.scan import run_scan


def test_scan_init_ref(tmp_repo: Path):
    """First scan should initialize the ref and exit 0."""
    result = run_scan(str(tmp_repo), handler=None, pull=False, dry_run=False)
    assert result == 0
    assert git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF) is not None


def test_scan_no_changes(tmp_repo: Path):
    """Scan with no new commits should exit 0."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))
    result = run_scan(str(tmp_repo), handler=None, pull=False, dry_run=False)
    assert result == 0


def test_scan_detects_changes(tmp_repo: Path, capsys):
    """Scan should print changes to stdout."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add"],
        check=True, capture_output=True,
    )

    result = run_scan(str(tmp_repo), handler=None, pull=False, dry_run=False)
    assert result == 0

    captured = capsys.readouterr()
    assert "A\tnew.txt" in captured.out


def test_scan_advances_ref(tmp_repo: Path):
    """Ref should advance after successful scan."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))
    old_ref = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add"],
        check=True, capture_output=True,
    )

    run_scan(str(tmp_repo), handler=None, pull=False, dry_run=False)
    new_ref = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)
    assert new_ref != old_ref
    assert new_ref == git_ops.head(tmp_repo)


def test_scan_dry_run_does_not_advance_ref(tmp_repo: Path):
    """Dry run should not advance the ref."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))
    old_ref = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add"],
        check=True, capture_output=True,
    )

    run_scan(str(tmp_repo), handler=None, pull=False, dry_run=True)
    assert git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF) == old_ref


def test_scan_with_handler(tmp_repo: Path, tmp_path: Path):
    """Handler should receive changes on stdin."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add"],
        check=True, capture_output=True,
    )

    # Create a handler that writes stdin to a file
    output_file = tmp_path / "handler_output.txt"
    handler = tmp_path / "handler.sh"
    handler.write_text(f"#!/usr/bin/env bash\ncat > {output_file}\n")
    handler.chmod(0o755)

    result = run_scan(str(tmp_repo), handler=str(handler), pull=False, dry_run=False)
    assert result == 0
    assert "A\tnew.txt" in output_file.read_text()


def test_scan_handler_failure_does_not_advance_ref(tmp_repo: Path, tmp_path: Path):
    """Failed handler should leave the ref unchanged."""
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, git_ops.head(tmp_repo))
    old_ref = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add"],
        check=True, capture_output=True,
    )

    handler = tmp_path / "bad_handler.sh"
    handler.write_text("#!/usr/bin/env bash\nexit 1\n")
    handler.chmod(0o755)

    result = run_scan(str(tmp_repo), handler=str(handler), pull=False, dry_run=False)
    assert result != 0
    assert git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF) == old_ref


def test_scan_not_a_repo(tmp_path: Path):
    """Scanning a non-repo should return error."""
    result = run_scan(str(tmp_path), handler=None, pull=False, dry_run=False)
    assert result == 1
