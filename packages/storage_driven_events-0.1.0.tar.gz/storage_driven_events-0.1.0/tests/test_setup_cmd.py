import subprocess
from pathlib import Path

from storage_events import git_ops
from storage_events.hooks import hook_exists
from storage_events.setup_cmd import _clone_or_reuse, _init_ref, _write_default_handler


def test_clone_or_reuse_existing(tmp_repo: Path):
    result = _clone_or_reuse("unused", tmp_repo, None)
    assert result == tmp_repo


def test_clone_or_reuse_clone(tmp_repo: Path, tmp_path: Path):
    dest = tmp_path / "new_clone"
    result = _clone_or_reuse(str(tmp_repo), dest, None)
    assert result == dest.resolve()
    assert git_ops.is_repo(result)


def test_init_ref(tmp_repo: Path):
    _init_ref(tmp_repo)
    ref = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)
    assert ref == git_ops.head(tmp_repo)


def test_init_ref_idempotent(tmp_repo: Path):
    _init_ref(tmp_repo)
    first = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)

    # Make a new commit
    (tmp_repo / "file.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "."], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "new"],
        check=True, capture_output=True,
    )

    # Second init should not change the ref
    _init_ref(tmp_repo)
    second = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)
    assert first == second


def test_write_default_handler(tmp_repo: Path):
    handler_path = _write_default_handler(tmp_repo)
    assert handler_path.exists()
    assert "STATUS_LABELS" in handler_path.read_text()
    # Check executable
    import os
    assert os.access(handler_path, os.X_OK)


def test_non_interactive_setup(tmp_repo: Path, tmp_path: Path):
    """Full non-interactive setup against a local repo."""
    from argparse import Namespace

    from storage_events.setup_cmd import run_setup

    dest = tmp_path / "setup_target"
    args = Namespace(
        repo=str(tmp_repo),
        path=str(dest),
        branch=None,
        handler=None,
        cron=None,
        no_hook=False,
    )
    result = run_setup(args)
    assert result == 0
    assert git_ops.is_repo(dest)
    assert git_ops.rev_parse(dest, git_ops.LAST_PROCESSED_REF) is not None
    assert (dest / "default-handler.py").exists()
    assert hook_exists(dest)
