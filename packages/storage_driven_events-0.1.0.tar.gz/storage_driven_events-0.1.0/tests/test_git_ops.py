import subprocess
from pathlib import Path

from storage_events import git_ops


def test_is_repo(tmp_repo: Path):
    assert git_ops.is_repo(tmp_repo)


def test_is_repo_false(tmp_path: Path):
    assert not git_ops.is_repo(tmp_path)


def test_head(tmp_repo: Path):
    result = git_ops.head(tmp_repo)
    assert len(result) == 40  # full SHA


def test_rev_parse_existing(tmp_repo: Path):
    result = git_ops.rev_parse(tmp_repo, "HEAD")
    assert result is not None
    assert len(result) == 40


def test_rev_parse_missing(tmp_repo: Path):
    result = git_ops.rev_parse(tmp_repo, "refs/nonexistent")
    assert result is None


def test_update_ref_and_rev_parse(tmp_repo: Path):
    current = git_ops.head(tmp_repo)
    git_ops.update_ref(tmp_repo, git_ops.LAST_PROCESSED_REF, current)
    result = git_ops.rev_parse(tmp_repo, git_ops.LAST_PROCESSED_REF)
    assert result == current


def test_diff_tree_added(tmp_repo: Path):
    before = git_ops.head(tmp_repo)

    (tmp_repo / "new.txt").write_text("hello")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "new.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add new.txt"],
        check=True, capture_output=True,
    )

    after = git_ops.head(tmp_repo)
    changes = git_ops.diff_tree(tmp_repo, before, after)
    assert changes == [("A", "new.txt")]


def test_diff_tree_modified(tmp_repo: Path):
    (tmp_repo / "file.txt").write_text("v1")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "file.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add file"],
        check=True, capture_output=True,
    )
    before = git_ops.head(tmp_repo)

    (tmp_repo / "file.txt").write_text("v2")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "file.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "modify file"],
        check=True, capture_output=True,
    )
    after = git_ops.head(tmp_repo)

    changes = git_ops.diff_tree(tmp_repo, before, after)
    assert changes == [("M", "file.txt")]


def test_diff_tree_deleted(tmp_repo: Path):
    (tmp_repo / "file.txt").write_text("v1")
    subprocess.run(["git", "-C", str(tmp_repo), "add", "file.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "add file"],
        check=True, capture_output=True,
    )
    before = git_ops.head(tmp_repo)

    (tmp_repo / "file.txt").unlink()
    subprocess.run(["git", "-C", str(tmp_repo), "add", "file.txt"], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(tmp_repo), "commit", "-m", "delete file"],
        check=True, capture_output=True,
    )
    after = git_ops.head(tmp_repo)

    changes = git_ops.diff_tree(tmp_repo, before, after)
    assert changes == [("D", "file.txt")]


def test_diff_tree_no_changes(tmp_repo: Path):
    current = git_ops.head(tmp_repo)
    changes = git_ops.diff_tree(tmp_repo, current, current)
    assert changes == []


def test_clone(tmp_repo: Path, tmp_path: Path):
    clone_path = tmp_path / "cloned"
    git_ops.clone(str(tmp_repo), clone_path)
    assert git_ops.is_repo(clone_path)
