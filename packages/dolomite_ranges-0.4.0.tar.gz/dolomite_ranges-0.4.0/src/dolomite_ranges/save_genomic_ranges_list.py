from typing import Optional

import dolomite_base as dl
from genomicranges import CompressedGenomicRangesList

from .save_atomic_vector_list import _save_compressed_list


@dl.save_object.register
@dl.validate_saves
def save_compressed_genomic_ranges_list(
    x: CompressedGenomicRangesList, path: str, data_frame_args: Optional[dict] = None, **kwargs
):
    """Method for saving :py:class:`~genomicranges.grangeslist.CompressedGenomicRangesList`
    objects to their corresponding file representations, see
    :py:meth:`~dolomite_base.save_object.save_object` for details.

    Args:
        x:
            Object to be staged.

        path:
            Path to a directory in which to save ``x``.

        data_frame_args:
            Further arguments to pass to the ``save_object`` method for
            ``mcols``.

        kwargs:
            Further arguments to be passed to individual methods.

    Returns:
        `x` is saved to `path`.
    """
    return _save_compressed_list(x, path=path, name="genomic_ranges_list", **kwargs)
