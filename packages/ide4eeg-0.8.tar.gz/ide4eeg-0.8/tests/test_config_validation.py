"""Tests for config validation and clamping (_validate_config)."""

import pytest

from ide4eeg.input.input import _validate_config


class TestAmplitudeThresholds:
    """Amplitude thresholding parameter validation."""

    def test_negative_max_threshold_clamped(self):
        cfg = {"amplitude_max_threshold": -1e-6}
        _validate_config(cfg)
        assert cfg["amplitude_max_threshold"] == 0

    def test_excessive_max_threshold_clamped(self):
        cfg = {"amplitude_max_threshold": 0.5}  # 500,000 µV
        _validate_config(cfg)
        assert cfg["amplitude_max_threshold"] == 0.01

    def test_valid_max_threshold_unchanged(self):
        cfg = {"amplitude_max_threshold": 150e-6}
        _validate_config(cfg)
        assert cfg["amplitude_max_threshold"] == 150e-6

    def test_nchan_threshold_above_one_clamped(self):
        cfg = {"amplitude_nchan_threshold": 10}
        _validate_config(cfg)
        assert cfg["amplitude_nchan_threshold"] == 1.0

    def test_nchan_threshold_negative_clamped(self):
        cfg = {"amplitude_nchan_threshold": -0.5}
        _validate_config(cfg)
        assert cfg["amplitude_nchan_threshold"] == 0

    def test_valid_nchan_threshold_unchanged(self):
        cfg = {"amplitude_nchan_threshold": 0.33}
        _validate_config(cfg)
        assert cfg["amplitude_nchan_threshold"] == 0.33

    def test_time_threshold_negative_clamped(self):
        cfg = {"amplitude_time_threshold": -1}
        _validate_config(cfg)
        assert cfg["amplitude_time_threshold"] == 0

    def test_non_numeric_max_threshold_replaced(self):
        cfg = {"amplitude_max_threshold": "invalid"}
        _validate_config(cfg)
        assert cfg["amplitude_max_threshold"] == 150e-6

    def test_amplitude_band_reversed_reset(self):
        cfg = {"amplitude_l_freq": 50, "amplitude_h_freq": 10}
        _validate_config(cfg)
        assert cfg["amplitude_l_freq"] == 1
        assert cfg["amplitude_h_freq"] == 40

    def test_amplitude_band_equal_reset(self):
        cfg = {"amplitude_l_freq": 30, "amplitude_h_freq": 30}
        _validate_config(cfg)
        assert cfg["amplitude_l_freq"] == 1
        assert cfg["amplitude_h_freq"] == 40

    def test_amplitude_band_valid_unchanged(self):
        cfg = {"amplitude_l_freq": 1, "amplitude_h_freq": 40}
        _validate_config(cfg)
        assert cfg["amplitude_l_freq"] == 1
        assert cfg["amplitude_h_freq"] == 40


class TestArtifactThreshold:
    """Artifact threshold fraction validation."""

    def test_above_one_clamped(self):
        cfg = {"artifacts": {"artifact_threshold": 2.0}}
        _validate_config(cfg)
        assert cfg["artifacts"]["artifact_threshold"] == 1.0

    def test_negative_clamped(self):
        cfg = {"artifacts": {"artifact_threshold": -0.5}}
        _validate_config(cfg)
        assert cfg["artifacts"]["artifact_threshold"] == 0

    def test_valid_unchanged(self):
        cfg = {"artifacts": {"artifact_threshold": 0.3}}
        _validate_config(cfg)
        assert cfg["artifacts"]["artifact_threshold"] == 0.3


class TestFilterFrequencies:
    """Filter frequency validation."""

    def test_negative_highpass_set_to_zero(self):
        cfg = {"filters": {"highpass_freq": -5, "lowpass_freq": 30}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 0

    def test_negative_lowpass_set_to_zero(self):
        cfg = {"filters": {"highpass_freq": 0.5, "lowpass_freq": -10}}
        _validate_config(cfg)
        assert cfg["filters"]["lowpass_freq"] == 0

    def test_highpass_exceeds_lowpass_both_disabled(self):
        cfg = {"filters": {"highpass_freq": 50, "lowpass_freq": 30}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 0
        assert cfg["filters"]["lowpass_freq"] == 0

    def test_highpass_equals_lowpass_both_disabled(self):
        cfg = {"filters": {"highpass_freq": 30, "lowpass_freq": 30}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 0
        assert cfg["filters"]["lowpass_freq"] == 0

    def test_valid_filters_unchanged(self):
        cfg = {"filters": {"highpass_freq": 0.5, "lowpass_freq": 30}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 0.5
        assert cfg["filters"]["lowpass_freq"] == 30

    def test_zero_filters_ok(self):
        """Zero means disabled — should not trigger hp >= lp warning."""
        cfg = {"filters": {"highpass_freq": 0, "lowpass_freq": 0}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 0
        assert cfg["filters"]["lowpass_freq"] == 0

    def test_only_highpass_set(self):
        cfg = {"filters": {"highpass_freq": 1.0, "lowpass_freq": 0}}
        _validate_config(cfg)
        assert cfg["filters"]["highpass_freq"] == 1.0

    def test_negative_notch_set_to_zero(self):
        cfg = {"filters": {"notch_freq": -50}}
        _validate_config(cfg)
        assert cfg["filters"]["notch_freq"] == 0


class TestTrimValues:
    """Trim start/end validation."""

    def test_start_exceeds_end_reset(self):
        cfg = {"trim_start": 10, "trim_end": 5}
        _validate_config(cfg)
        assert cfg["trim_start"] == 0.0

    def test_start_equals_end_reset(self):
        cfg = {"trim_start": 5, "trim_end": 5}
        _validate_config(cfg)
        assert cfg["trim_start"] == 0.0

    def test_valid_trim_unchanged(self):
        cfg = {"trim_start": 2, "trim_end": 80}
        _validate_config(cfg)
        assert cfg["trim_start"] == 2
        assert cfg["trim_end"] == 80

    def test_trim_end_none_ok(self):
        """trim_end = None means keep to end of signal."""
        cfg = {"trim_start": 5, "trim_end": None}
        _validate_config(cfg)
        assert cfg["trim_start"] == 5
        assert cfg["trim_end"] is None


class TestRestWindow:
    """Rest window_length validation."""

    def test_zero_window_set_to_default(self):
        cfg = {"rest": {"window_length": 0}}
        _validate_config(cfg)
        assert cfg["rest"]["window_length"] == 5

    def test_negative_window_set_to_default(self):
        cfg = {"rest": {"window_length": -3}}
        _validate_config(cfg)
        assert cfg["rest"]["window_length"] == 5

    def test_valid_window_unchanged(self):
        cfg = {"rest": {"window_length": 10}}
        _validate_config(cfg)
        assert cfg["rest"]["window_length"] == 10


class TestEpochOffsets:
    """Epoch start/stop offset validation."""

    def test_start_exceeds_stop_reset(self):
        cfg = {"epochs": {"start_offset": 0.5, "stop_offset": 0.2}}
        _validate_config(cfg)
        assert cfg["epochs"]["start_offset"] == -0.3
        assert cfg["epochs"]["stop_offset"] == 0.7

    def test_start_equals_stop_reset(self):
        cfg = {"epochs": {"start_offset": 0.5, "stop_offset": 0.5}}
        _validate_config(cfg)
        assert cfg["epochs"]["start_offset"] == -0.3
        assert cfg["epochs"]["stop_offset"] == 0.7

    def test_valid_offsets_unchanged(self):
        cfg = {"epochs": {"start_offset": -0.2, "stop_offset": 0.8}}
        _validate_config(cfg)
        assert cfg["epochs"]["start_offset"] == -0.2
        assert cfg["epochs"]["stop_offset"] == 0.8

    def test_negative_offsets_ok(self):
        """Negative start is normal (pre-stimulus baseline)."""
        cfg = {"epochs": {"start_offset": -1.0, "stop_offset": 2.0}}
        _validate_config(cfg)
        assert cfg["epochs"]["start_offset"] == -1.0
        assert cfg["epochs"]["stop_offset"] == 2.0


class TestTFStatistics:
    """Time-frequency statistics parameter validation."""

    def test_dt_zero_set_to_default(self):
        cfg = {"tf_statistics": {"dt": 0}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["dt"] == 0.5

    def test_dt_negative_set_to_default(self):
        cfg = {"tf_statistics": {"dt": -1}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["dt"] == 0.5

    def test_df_zero_set_to_default(self):
        cfg = {"tf_statistics": {"df": 0}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["df"] == 1.0

    def test_df_non_numeric_set_to_default(self):
        cfg = {"tf_statistics": {"df": "bad"}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["df"] == 1.0

    def test_fmin_exceeds_fmax_reset(self):
        cfg = {"tf_statistics": {"f_min": 50, "f_max": 10}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["f_min"] == 0
        assert cfg["tf_statistics"]["f_max"] == 0

    def test_valid_tf_stats_unchanged(self):
        cfg = {"tf_statistics": {"dt": 0.5, "df": 1.0,
                                  "f_min": 8, "f_max": 30}}
        _validate_config(cfg)
        assert cfg["tf_statistics"]["dt"] == 0.5
        assert cfg["tf_statistics"]["df"] == 1.0
        assert cfg["tf_statistics"]["f_min"] == 8
        assert cfg["tf_statistics"]["f_max"] == 30


class TestEmptyConfig:
    """Validation on empty or minimal configs should not crash."""

    def test_empty_config(self):
        cfg = {}
        _validate_config(cfg)

    def test_config_with_only_paths(self):
        cfg = {"input_path": "/tmp/test.fif", "output_path": "/tmp/out"}
        _validate_config(cfg)

    def test_missing_subsections(self):
        """All subsection accesses use .get() and should not crash."""
        cfg = {"prepare_connectivity_analysis": True}
        _validate_config(cfg)
