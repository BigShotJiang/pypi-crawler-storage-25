"""Integration and coverage tests.

Covers:
- End-to-end pipeline on simulated data
- GUI _vars completeness (all _collect_config keys exist)
- FIELD_TOOLTIPS coverage
- Artifact detection on synthetic signals
- Dipole atom filtering logic
- Sleep staging feature detection
- BookViewer on_accept callback
- convert_strings round-trip
"""

import copy
import os
import sys
import tempfile

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# 1. End-to-end pipeline on simulated data
# ---------------------------------------------------------------------------

class TestEndToEnd:
    """Run the actual pipeline on example simulated data."""

    def test_rest_pipeline_simulated(self, tmp_path):
        """Full rest-mode pipeline on simulated data produces output."""
        from ide4eeg.gui_config import load_toml
        from ide4eeg.input.input import check_and_prepare_config

        cfg_path = os.path.join(
            REPO_ROOT, "examples", "simulated_data",
            "config_simulated_data_rest.toml")
        if not os.path.isfile(cfg_path):
            pytest.skip("Example data not available")

        cfg = load_toml(cfg_path)
        # Resolve paths relative to repo root
        cfg["input_path"] = os.path.join(REPO_ROOT, cfg["input_path"])
        cfg["output_path"] = str(tmp_path)
        cfg["overwrite_output"] = True
        # Minimal analysis for speed
        cfg["prepare_eeg_artifacts"] = False
        # Disable interactive windows that block in tests
        cfg.setdefault("rest", {})["check_rest"] = False
        cfg.setdefault("epochs", {})["check_epochs"] = False

        if not os.path.isfile(cfg["input_path"]):
            pytest.skip("Simulated data file not found")

        # Save config to temp TOML for pipeline
        from ide4eeg.gui_config import dump_toml
        cfg_tmp = str(tmp_path / "test_config.toml")
        dump_toml(cfg, cfg_tmp)

        from ide4eeg.main import main as run_pipeline
        run_pipeline(cfg_tmp)

        # Check output exists
        out_dirs = [d for d in os.listdir(str(tmp_path))
                    if d.startswith("IDE4EEG_OUT")]
        assert len(out_dirs) >= 1, "No output directory created"


# ---------------------------------------------------------------------------
# 2. GUI _vars completeness
# ---------------------------------------------------------------------------

class TestVarsCompleteness:
    """Verify _collect_config doesn't access missing _vars keys.

    The actual test is test_collect_config_no_crash in test_gui_qt_config.py.
    """

    def test_placeholder(self):
        """See test_gui_qt_config.py::TestQtGuiConstruction for GUI tests."""
        pass


# ---------------------------------------------------------------------------
# 3. FIELD_TOOLTIPS coverage
# ---------------------------------------------------------------------------

class TestTooltipCoverage:
    """Check that important config keys have tooltip text."""

    def test_key_config_keys_have_tooltips(self):
        from ide4eeg.gui_config import FIELD_TOOLTIPS
        important_keys = [
            "input_path", "output_path", "prepare_eeg_artifacts",
            "prepare_ica", "prepare_video_artifacts",
            "resample_freq", "overwrite_output",
            "matching_pursuit.empi_path",
            "matching_pursuit.algorithm",
        ]
        missing = [k for k in important_keys if k not in FIELD_TOOLTIPS]
        assert not missing, f"Missing tooltips for: {missing}"

    def test_tooltips_are_nonempty_strings(self):
        from ide4eeg.gui_config import FIELD_TOOLTIPS
        for key, text in FIELD_TOOLTIPS.items():
            assert isinstance(text, str) and len(text) > 5, \
                f"FIELD_TOOLTIPS[{key!r}] is empty or too short: {text!r}"

    def test_tooltips_fit_66_char_line_width(self):
        """Qt doesn't auto-wrap — enforce the ≤66-char-per-line rule
        established by commit e6cd9f8."""
        from ide4eeg.gui_config import FIELD_TOOLTIPS
        overflowing = []
        for key, text in FIELD_TOOLTIPS.items():
            for i, line in enumerate(text.split("\n")):
                if len(line) > 66:
                    overflowing.append((key, i, len(line), line))
        assert not overflowing, (
            "Tooltip lines must be <=66 chars (see CLAUDE.md). "
            "Overflowing entries: "
            + "\n".join(f"  {k}[{i}]={w} chars: {line!r}"
                        for k, i, w, line in overflowing))


# ---------------------------------------------------------------------------
# 4. Artifact detection on synthetic data
# ---------------------------------------------------------------------------

class TestArtifactDetection:
    """Test artifact detection with known synthetic signals."""

    def test_amplitude_artifact_detects_spike(self):
        """A large spike should be detected as an amplitude artifact."""
        import mne
        from ide4eeg.preprocessing.artifacts import amplitude_artifacts

        sfreq = 256
        n_samples = sfreq * 10  # 10 seconds
        n_channels = 3
        data = np.random.randn(n_channels, n_samples) * 1e-6  # ~1 µV

        # Insert a huge spike at 5 seconds
        spike_start = 5 * sfreq
        data[:, spike_start:spike_start + 10] = 500e-6  # 500 µV

        info = mne.create_info(
            ch_names=[f"EEG{i}" for i in range(n_channels)] + ["STIM"],
            sfreq=sfreq, ch_types=["eeg"] * n_channels + ["stim"])
        stim_data = np.zeros((1, n_samples))
        stim_data[0, 0] = 1  # one rest segment
        raw = mne.io.RawArray(
            np.vstack([data, stim_data]), info, verbose=False)

        config = {
            "amplitude_max_threshold": 150e-6,  # 150 µV
            "amplitude_time_threshold": 0.02,
            "amplitude_nchan_threshold": 0.5,
            "amplitude_l_freq": 1,
            "amplitude_h_freq": 40,
            "segmentation": {"mode": "rest"},
            "rest": {"rest_duration": [0, ""], "window_length": 10},
        }

        desc, occ = amplitude_artifacts(raw, config)
        assert "amplitude" in occ, "Amplitude artifact not detected"
        # The spike region should be flagged
        mask = occ["amplitude"]
        assert np.any(mask[:, spike_start:spike_start + 10]), \
            "Spike region not flagged"


# ---------------------------------------------------------------------------
# 5. Dipole atom filtering
# ---------------------------------------------------------------------------

class TestDipoleAtomFiltering:
    """Test the atom filtering logic in fit_all_dipoles."""

    def test_dominant_channel(self):
        """_dominant extracts frequency and scale from strongest channel."""
        from ide4eeg.analysis.dipole.fitting import fit_all_dipoles

        # Create a mock macroatom with channels
        ma = {
            "segment_id": 0, "iteration": 0,
            "channels": [
                {"amplitude": 1.0, "f_Hz": 10.0, "scale_s": 0.5},
                {"amplitude": 5.0, "f_Hz": 12.0, "scale_s": 1.0},
                {"amplitude": 2.0, "f_Hz": 8.0, "scale_s": 0.3},
            ]
        }
        # The strongest channel (amplitude=5.0) has f=12, scale=1.0
        best = max(ma["channels"], key=lambda c: abs(c.get("amplitude", 0)))
        assert best["f_Hz"] == 12.0
        assert best["scale_s"] == 1.0


# ---------------------------------------------------------------------------
# 6. Sleep staging feature detection
# ---------------------------------------------------------------------------

# TestSleepStagingFeatures moved to _unreleased/tests/test_sleep_staging.py


# ---------------------------------------------------------------------------
# 7. BookViewer on_accept injects segment_id
# ---------------------------------------------------------------------------

class TestBookViewerAccept:
    """Verify _accept_selection injects segment_id into atoms."""

    def test_segment_id_injected(self):
        """Selected atoms should include the current segment_id."""
        # Test the injection logic without Tk (no GUI needed)
        filtered_atoms = [
            {"iteration": 0, "f_Hz": 10.0, "amplitude": 1.0},
            {"iteration": 1, "f_Hz": 12.0, "amplitude": 2.0},
            {"iteration": 2, "f_Hz": 8.0, "amplitude": 0.5},
        ]
        selected_iters = {0, 2}
        segment_id = 7

        # This is the logic from BookViewer._accept_selection
        selected = [dict(a, segment_id=segment_id)
                    for a in filtered_atoms
                    if a["iteration"] in selected_iters]

        assert len(selected) == 2
        assert all(a["segment_id"] == 7 for a in selected)
        assert selected[0]["iteration"] == 0
        assert selected[1]["iteration"] == 2


# ---------------------------------------------------------------------------
# 8. convert_strings round-trip
# ---------------------------------------------------------------------------

class TestTomlTypes:
    """Verify TOML load returns correct Python types."""

    def test_toml_load_preserves_types(self, tmp_path):
        """dump_toml → load_toml preserves int, float, bool, string, list."""
        from ide4eeg.gui_config import dump_toml, load_toml  # noqa: F811
        cfg = {
            "an_int": 42,
            "a_float": 3.14,
            "a_bool": True,
            "a_false": False,
            "a_string": "hello world",
            "a_list": [1, 2, 3],
        }
        path = str(tmp_path / "types.toml")
        dump_toml(cfg, path)
        loaded = load_toml(path)

        assert loaded["an_int"] == 42
        assert isinstance(loaded["an_int"], int)
        assert loaded["a_float"] == pytest.approx(3.14)
        assert isinstance(loaded["a_float"], float)
        assert loaded["a_bool"] is True
        assert loaded["a_false"] is False
        assert loaded["a_string"] == "hello world"
        assert loaded["a_list"] == [1, 2, 3]

    def test_nested_types(self, tmp_path):
        """Nested dicts and inline tables preserve types."""
        from ide4eeg.gui_config import dump_toml, load_toml  # noqa: F811
        cfg = {
            "section": {
                "value": 123,
                "flag": True,
                "sub": {"x": 1.5, "y": 2.5},
            }
        }
        path = str(tmp_path / "nested_types.toml")
        dump_toml(cfg, path)
        loaded = load_toml(path)

        assert loaded["section"]["value"] == 123
        assert loaded["section"]["flag"] is True
        assert loaded["section"]["sub"]["x"] == pytest.approx(1.5)
