"""Regression tests for ``_dirty_segment_ids`` / ``_remove_bad_segments``
event-position contract.

Bug surfaced 2026-04-25: a user pipeline crashed with::

    IndexError: Epoch index 249 is out of bounds

because ``_dirty_segment_ids`` returned segment indices using its own
counter, which got out of sync with ``mne.Epochs`` whenever MNE
silently dropped events at construction (out-of-bounds tmin/tmax,
baseline issues, …).  The fix moved both helpers to a
sample-position contract: ``_dirty_segment_ids`` returns the sample
positions of bad events (matching ``Epochs.events[:, 0]``), and
``_remove_bad_segments`` looks them up there to derive epoch
indices.  Events filtered out by MNE simply don't appear in
``Epochs.events`` and are transparently excluded.

These tests build synthetic signals with various edge-event
configurations and confirm:

1. ``_dirty_segment_ids`` returns sample positions, not segment
   indices.
2. ``_remove_bad_segments`` correctly drops the right epochs even
   when MNE filtered out some events.
3. The end-to-end pipeline doesn't crash on the user-reported case.
"""

import numpy as np
import mne
import pytest

from ide4eeg.preprocessing.rest_and_epochs import (
    _dirty_segment_ids, _cut_segments, _remove_bad_segments)


# ── Builders ──────────────────────────────────────────────────────────


def _build_signal(sfreq=128, n_seconds=10, event_times=None):
    """Synthetic Raw with EEG + STIM channels and events at given times."""
    n = int(sfreq * n_seconds)
    rng = np.random.default_rng(0)
    eeg_data = rng.standard_normal((3, n)) * 1e-6
    stim = np.zeros((1, n))
    for t_sec in event_times or ():
        idx = int(t_sec * sfreq)
        if 0 <= idx < n:
            stim[0, idx] = 1
    data = np.vstack([eeg_data, stim])
    info = mne.create_info(
        ch_names=["C3", "C4", "Cz", "STIM"],
        sfreq=sfreq,
        ch_types=["eeg"] * 3 + ["stim"])
    return mne.io.RawArray(data, info, verbose=False)


def _build_config(tmin=-0.2, tmax=0.5):
    """Minimal config dict the pipeline helpers need."""
    return {
        "segmentation": {"mode": "epochs"},
        "epochs": {
            "start_offset": tmin,
            "stop_offset": tmax,
            "epochs_baseline": "None",
            "tags": {"selected": ["evt"]},
        },
        "artifacts": {"artifact_threshold": 0.0},
    }


# ── Tests ─────────────────────────────────────────────────────────────


def test_returns_sample_positions_not_indices():
    """The helper now returns sample positions (matching
    Epochs.events[:, 0]), not segment indices.
    """
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    event_times = [1.0, 3.0, 5.0, 7.0, 8.5]
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10, event_times=event_times)
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    expected_positions = [int(t * sfreq) for t in event_times]
    assert positions == expected_positions, (
        f"Expected sample positions {expected_positions}, "
        f"got {positions}.  The contract is sample-position-based, "
        f"NOT segment-index-based.")


def test_remove_bad_segments_maps_positions_to_indices(monkeypatch):
    """``_remove_bad_segments`` translates positions → epoch indices
    via ``segments.events[:, 0]`` regardless of which segments were
    flagged bad."""
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    event_times = [1.0, 3.0, 5.0, 7.0, 8.5]
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10, event_times=event_times)
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 5

    # Mark the 1st and 4th events bad (positions matching the
    # original event_times list).
    bad_positions = [int(1.0 * sfreq), int(7.0 * sfreq)]
    cleaned, _ = _remove_bad_segments(
        segments, bad_positions, cfg)

    # Should have dropped 2 of the 5 epochs.
    assert len(cleaned) == 3
    # And the remaining epochs should be the ones at t=3, 5, 8.5
    remaining_positions = [int(ev[0]) for ev in cleaned.events]
    expected_remaining = [int(3.0 * sfreq), int(5.0 * sfreq),
                          int(8.5 * sfreq)]
    assert remaining_positions == expected_remaining


def test_pipeline_survives_leading_out_of_bounds_events():
    """End-to-end check on the bug class that crashed the user
    pipeline: MNE drops some events at Epochs construction; the
    artifact-bad list still resolves correctly without IndexError."""
    sfreq = 128
    cfg = _build_config(tmin=-0.5, tmax=0.5)
    # First event at t=0.1 with tmin=-0.5 → window starts at -51
    # samples → MNE drops it. Other events (t=1, 2, 3) are in-bounds.
    raw = _build_signal(
        sfreq=sfreq, n_seconds=5,
        event_times=[0.1, 1.0, 2.0, 3.0])
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 3, (
        f"MNE should keep the 3 in-bounds events; got {len(segments)}")

    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    # The leading out-of-bounds event (at t=0.1) is correctly
    # excluded because its window extends before sample 0.
    expected = [int(t * sfreq) for t in (1.0, 2.0, 3.0)]
    assert positions == expected

    # And _remove_bad_segments handles it gracefully.
    cleaned, _ = _remove_bad_segments(
        segments, positions, cfg)
    assert len(cleaned) == 0  # all in-bounds epochs dropped


def test_pipeline_survives_trailing_out_of_bounds_events():
    """Same robustness check, but with trailing out-of-bounds events.
    MNE drops the last few; positions list must still resolve."""
    sfreq = 128
    tmax = 0.5
    n_seconds = 10
    cfg = _build_config(tmin=-0.2, tmax=tmax)
    edge = n_seconds - tmax + 0.01
    raw = _build_signal(
        sfreq=sfreq, n_seconds=n_seconds,
        event_times=[1.0, 3.0, 5.0, 6.0, 7.0,
                     edge, edge + 0.05, edge + 0.1])
    tags_desc_id = {"evt": 1}

    segments, _ = _cut_segments(raw, cfg, tags_desc_id)
    assert len(segments) == 5

    art_mask = np.ones((3, raw.n_times))
    positions = _dirty_segment_ids(
        raw, cfg, {"all_artifact": art_mask}, tags_desc_id)

    # Out-of-bounds events at the tail are excluded.
    expected = [int(t * sfreq) for t in (1.0, 3.0, 5.0, 6.0, 7.0)]
    assert positions == expected

    cleaned, _ = _remove_bad_segments(
        segments, positions, cfg)
    assert len(cleaned) == 0


def test_unmatched_positions_silently_skipped():
    """Defensive check: a position not in segments.events[:, 0] (e.g.
    upstream re-cropping changed which events became epochs) is
    silently skipped — no IndexError, no crash."""
    sfreq = 128
    cfg = _build_config(tmin=-0.2, tmax=0.5)
    raw = _build_signal(
        sfreq=sfreq, n_seconds=10,
        event_times=[1.0, 3.0, 5.0])
    tags_desc_id = {"evt": 1}
    segments, _ = _cut_segments(raw, cfg, tags_desc_id)

    # Mix valid + invalid sample positions.
    bad_positions = [int(1.0 * sfreq),     # valid
                     int(99.9 * sfreq),    # not in events → skipped
                     int(5.0 * sfreq)]     # valid
    cleaned, _ = _remove_bad_segments(
        segments, bad_positions, cfg)

    # Should drop 2 of 3 (the matched ones); the non-matching
    # position is silently ignored.
    assert len(cleaned) == 1
    assert int(cleaned.events[0][0]) == int(3.0 * sfreq)
