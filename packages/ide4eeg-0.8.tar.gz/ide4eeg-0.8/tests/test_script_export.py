"""Tests for script export, CLI arguments, and config TOML round-trip.

Covers:
- generate_script() produces valid, importable Python
- The generated script has correct structure and all non-default params
- CLI argument parsing (ide4eeg.cli, exposed via ``python -m ide4eeg``)
- TOML save → load round-trip preserves values
- check_and_prepare_config handles missing sections gracefully
"""

import ast
import copy
import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ide4eeg.gui_config import DEFAULT_CONFIG, _toml_value


# ---------------------------------------------------------------------------
# Script export
# ---------------------------------------------------------------------------

class TestGenerateScript:
    """Verify generate_script() produces valid Python scripts."""

    def _generate(self, **overrides):
        """Helper: generate a script with config overrides."""
        from ide4eeg.api import generate_script
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test_signal.vhdr"
        cfg["output_path"] = "/tmp/output/"
        cfg.update(overrides)
        return generate_script(cfg, DEFAULT_CONFIG, repo_path="/fake/path")

    def test_produces_string(self):
        script = self._generate()
        assert isinstance(script, str)
        assert len(script) > 100

    def test_valid_python_syntax(self):
        """The generated script must parse without SyntaxError."""
        script = self._generate()
        try:
            ast.parse(script)
        except SyntaxError as e:
            pytest.fail(f"Generated script has syntax error: {e}\n"
                        f"Script:\n{script[:500]}")

    def test_contains_run_file_call(self):
        script = self._generate()
        assert "from ide4eeg.api import run_file" in script
        assert "run_file(" in script

    def test_contains_input_path(self):
        script = self._generate(input_path="/data/recording.vhdr")
        assert "/data/recording.vhdr" in script

    def test_non_default_params_included(self):
        """Parameters that differ from defaults should appear."""
        script = self._generate(
            resample_freq=256,
            prepare_eeg_artifacts=True,
            prepare_eeg_profiles=True,
        )
        assert "resample_freq=256" in script
        assert "prepare_eeg_artifacts=True" in script
        assert "prepare_eeg_profiles=True" in script

    def test_default_params_excluded(self):
        """Parameters equal to defaults should NOT appear."""
        script = self._generate()
        # rest.window_length defaults to 20, so shouldn't appear
        # unless the user changed it
        assert "window_length" not in script or "window_length=20" not in script

    def test_disabled_features_pruned(self):
        """When a feature gate is off, its sub-config is omitted."""
        script = self._generate(
            prepare_eeg_artifacts=False,
            prepare_video_artifacts=False,
        )
        # artifacts section should not appear
        assert "rejection_parameters" not in script
        # facetag params should not appear
        assert "facetag_frame_skip" not in script

    def test_with_matching_pursuit(self):
        """MP decomposition config appears when enabled via step_order."""
        script = self._generate(
            preprocessing={"step_order": [
                "trim", "chosen_channels", "bad_channels", "montage",
                "filtering", "mp_decomposition"]},
            matching_pursuit={
                "empi_path": "/usr/bin/empi",
                "algorithm": "smp",
                "iterations": 50,
                "channels": "Cz",
            },
        )
        # MP enable lives in step_order now (no top-level flag).
        assert "mp_decomposition" in script
        assert "matching_pursuit" in script

    def test_with_epochs_mode(self):
        """Epochs mode and parameters included."""
        script = self._generate(
            segmentation={"mode": "epochs"},
        )
        assert "segmentation" in script

    def test_overwrite_flag(self):
        script = self._generate(overwrite_output=True)
        assert "overwrite=True" in script

    def test_script_has_shebang(self):
        script = self._generate()
        assert script.startswith("#!/usr/bin/env python3")

    def test_script_has_docstring(self):
        script = self._generate()
        assert '"""IDE4EEG analysis script' in script

    def test_script_importable(self):
        """The script should be importable (parseable) by Python."""
        script = self._generate()
        # Write to temp file and compile
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False) as f:
            f.write(script)
            f.flush()
            try:
                compile(open(f.name).read(), f.name, "exec")
            finally:
                os.unlink(f.name)

    @staticmethod
    def _run_generated_script(cfg, tmp_path, name="test_pipeline.py"):
        """Helper: generate script, execute, verify output."""
        import subprocess
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        signal_path = os.path.join(
            repo, "examples", "simulated_data",
            "example_simulated_data-raw.fif")
        if not os.path.isfile(signal_path):
            pytest.skip("Simulated data not available")

        from ide4eeg.api import generate_script
        cfg["input_path"] = signal_path
        cfg["output_path"] = str(tmp_path)
        cfg["overwrite_output"] = True

        script = generate_script(cfg, DEFAULT_CONFIG, repo_path=repo)
        script_path = str(tmp_path / name)
        with open(script_path, "w") as f:
            f.write(script)

        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True, text=True, timeout=120,
            cwd=repo)
        assert result.returncode == 0, \
            f"Script {name} failed:\nstderr: {result.stderr[-500:]}"

        out_dirs = [d for d in os.listdir(str(tmp_path))
                    if d.startswith("IDE4EEG_OUT")]
        assert len(out_dirs) >= 1, f"No output from {name}"
        return result

    def test_script_rest_smoke(self, tmp_path):
        """Rest mode minimal pipeline (no analysis enabled)."""
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["segmentation"] = {"mode": "rest"}

        cfg["rest"]["check_rest"] = False
        cfg["rest"]["window_length"] = 20
        self._run_generated_script(cfg, tmp_path, "rest_smoke.py")

    def test_script_epochs_erp(self, tmp_path):
        """Epochs mode + time analysis (ERP + cluster)."""
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["segmentation"] = {"mode": "epochs"}
        cfg["prepare_time_analysis"] = True

        cfg["epochs"]["check_epochs"] = False
        cfg["epochs"]["start_offset"] = -0.2
        cfg["epochs"]["stop_offset"] = 0.8
        cfg["epochs"]["tags"] = {"AUTO": True}
        self._run_generated_script(cfg, tmp_path, "epochs_erp.py")

    def test_script_rest_with_preprocessing(self, tmp_path):
        """Rest mode + EEG preprocessing (filtering only, no artifacts)."""
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["segmentation"] = {"mode": "rest"}
        cfg["prepare_eeg_artifacts"] = True
        cfg["prepare_ica"] = False

        cfg["rest"]["check_rest"] = False
        cfg["rest"]["window_length"] = 20
        cfg["filters"] = {
            "highpass_freq": 0.5,
            "lowpass_freq": 30.0,
            "notch_freq": 0,
            "method": "fir",
        }
        # Disable artifact detection to avoid dropping all segments
        # on the small simulated signal
        cfg["artifacts"] = cfg.get("artifacts", {})
        cfg["artifacts"]["enable_slopes"] = False
        cfg["artifacts"]["enable_outliers"] = False
        cfg["artifacts"]["enable_muscles"] = False
        cfg["artifacts"]["enable_amplitude"] = False
        self._run_generated_script(cfg, tmp_path, "rest_preproc.py")


# ---------------------------------------------------------------------------
# CLI argument parsing
# ---------------------------------------------------------------------------

class TestCLIParsing:
    """Test ``python -m ide4eeg`` argument parsing and CLI execution.

    Equivalent to invoking the installed ``ide4eeg`` console script;
    we exercise the module form so the test runs without a pip-install
    step.
    """

    def test_import_cli(self):
        """ide4eeg.cli can be imported without side effects."""
        import ide4eeg.cli
        assert ide4eeg.cli.main is not None

    def test_version_flag(self):
        """``python -m ide4eeg --version`` prints version and exits 0."""
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "ide4eeg", "--version"],
            capture_output=True, text=True, timeout=10)
        assert result.returncode == 0
        assert "ide4eeg" in result.stdout.lower()

    def test_missing_config_exits_nonzero(self):
        """``--run nonexistent.toml`` exits with error."""
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "ide4eeg",
             "--run", "/tmp/nonexistent_xyz.toml"],
            capture_output=True, text=True, timeout=10)
        assert result.returncode != 0

    def test_cli_pipeline_simulated(self, tmp_path):
        """``--run config.toml`` runs the pipeline on simulated data."""
        import subprocess
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        signal_path = os.path.join(
            repo, "examples", "simulated_data",
            "example_simulated_data-raw.fif")
        if not os.path.isfile(signal_path):
            pytest.skip("Simulated data not available")

        # Write a minimal config
        from ide4eeg.gui_config import dump_toml
        cfg = {
            "input_path": signal_path,
            "output_path": str(tmp_path),
            "segmentation": {"mode": "rest"},
            "overwrite_output": True,
            "prepare_eeg_artifacts": False,
            "rest": {"check_rest": False, "window_length": 20,
                     "rest_duration": [0, ""]},
        }
        cfg_path = str(tmp_path / "test_cli.toml")
        dump_toml(cfg, cfg_path)

        result = subprocess.run(
            [sys.executable, "-m", "ide4eeg", "--run", cfg_path],
            capture_output=True, text=True, timeout=120,
            cwd=repo)
        assert result.returncode == 0, \
            f"CLI pipeline failed:\nstdout: {result.stdout[-500:]}\n" \
            f"stderr: {result.stderr[-500:]}"

        # Check output was created
        out_dirs = [d for d in os.listdir(str(tmp_path))
                    if d.startswith("IDE4EEG_OUT")]
        assert len(out_dirs) >= 1, "No output directory created by CLI"


# ---------------------------------------------------------------------------
# Per-step save toggles (round-trip + end-to-end)
# ---------------------------------------------------------------------------

class TestSaveToggles:
    """Verify the per-step save toggle system works end-to-end."""

    def test_save_flag_in_generated_script(self):
        """When a step's save flag differs from the default, the
        generated script must include it (verifies _diff_config picks
        it up).  ``trim`` defaults to save=True so we toggle it to
        False here to drive a diff; ``filters`` / ``bad_channels``
        default to save=False so True drives a diff for them."""
        from ide4eeg.api import generate_script
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test.vhdr"
        cfg["filters"]["save"] = True
        cfg["bad_channels"]["save"] = True
        cfg["trim"]["save"] = False
        script = generate_script(cfg, DEFAULT_CONFIG, repo_path="/fake")
        # Each section that diverges from default should appear
        assert '"save": True' in script or "'save': True" in script
        assert '"save": False' in script or "'save': False" in script
        for sec in ("filters", "bad_channels", "trim"):
            assert sec in script, f"{sec} missing from generated script"

    def test_cli_with_save_toggles_creates_saved_steps(self, tmp_path):
        """CLI run with per-step save toggles enabled creates the
        saved_steps/ folder with the expected snapshot files."""
        import subprocess
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        signal_path = os.path.join(
            repo, "examples", "simulated_data",
            "example_simulated_data-raw.fif")
        if not os.path.isfile(signal_path):
            pytest.skip("Simulated data not available")
        from ide4eeg.gui_config import dump_toml
        cfg = {
            "input_path": signal_path,
            "output_path": str(tmp_path),
            "segmentation": {"mode": "rest"},
            "overwrite_output": True,
            "prepare_eeg_artifacts": False,
            "rest": {"check_rest": False, "window_length": 20,
                     "rest_duration": [0, ""]},
            "trim": {"save": True},
            "filters": {"save": True, "lowpass_freq": 30},
            "preprocessing": {
                # After the Phase 2 refactor trim is itself a reorderable
                # step, so it must appear explicitly in step_order for
                # the save flag to fire.
                "step_order": ["trim", "filtering"],
            },
        }
        cfg_path = str(tmp_path / "save_toggle.toml")
        dump_toml(cfg, cfg_path)
        result = subprocess.run(
            [sys.executable, "-m", "ide4eeg", "--run", cfg_path],
            capture_output=True, text=True, timeout=120, cwd=repo)
        assert result.returncode == 0, \
            f"CLI failed:\n{result.stderr[-500:]}"
        # With overwrite_output=True, preprocessing/ sits directly
        # under IDE4EEG_OUT_<file>/ (no timestamp subfolder).
        out_dirs = [d for d in os.listdir(str(tmp_path))
                    if d.startswith("IDE4EEG_OUT")]
        assert out_dirs, "No output directory"
        out_root = os.path.join(str(tmp_path), out_dirs[0])
        saved_steps = os.path.join(out_root, "preprocessing", "saved_steps")
        assert os.path.isdir(saved_steps), \
            f"preprocessing/saved_steps/ not created at {saved_steps}"
        files = os.listdir(saved_steps)
        # Trim and filtering both have save=True
        assert any("trimmed" in f for f in files), \
            f"trimmed snapshot missing in {files}"
        assert any("filtered" in f for f in files), \
            f"filtered snapshot missing in {files}"

    def test_cli_without_save_toggles_skips_saved_steps(self, tmp_path):
        """When no per-step save flag is set, no saved_steps/ folder
        should be created (the always-saved final epochs go to
        saved_signals/, but saved_steps/ should be absent)."""
        import subprocess
        repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        signal_path = os.path.join(
            repo, "examples", "simulated_data",
            "example_simulated_data-raw.fif")
        if not os.path.isfile(signal_path):
            pytest.skip("Simulated data not available")
        from ide4eeg.gui_config import dump_toml
        cfg = {
            "input_path": signal_path,
            "output_path": str(tmp_path),
            "segmentation": {"mode": "rest"},
            "overwrite_output": True,
            "prepare_eeg_artifacts": False,
            "rest": {"check_rest": False, "window_length": 20,
                     "rest_duration": [0, ""]},
        }
        cfg_path = str(tmp_path / "no_save.toml")
        dump_toml(cfg, cfg_path)
        subprocess.run(
            [sys.executable, "-m", "ide4eeg", "--run", cfg_path],
            capture_output=True, text=True, timeout=120, cwd=repo, check=True)
        out_dirs = [d for d in os.listdir(str(tmp_path))
                    if d.startswith("IDE4EEG_OUT")]
        out_root = os.path.join(str(tmp_path), out_dirs[0])
        # overwrite_output=True → no timestamp subfolder
        saved_steps = os.path.join(out_root, "preprocessing", "saved_steps")
        assert not os.path.isdir(saved_steps), \
            f"saved_steps/ created without any save flag: {saved_steps}"
        # But saved_signals/ (always-on) MUST exist
        saved_signals = os.path.join(out_root, "preprocessing",
                                     "saved_signals")
        assert os.path.isdir(saved_signals), \
            "saved_signals/ (always-on) missing"

    def test_epochs_tags_selected_format_in_script(self):
        """The new event-selection format epochs.tags.selected = [...]
        round-trips through generate_script."""
        from ide4eeg.api import generate_script
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test.vhdr"
        cfg["segmentation"] = {"mode": "epochs"}
        cfg["epochs"]["tags"] = {"selected": ["target", "nontarget"]}
        script = generate_script(cfg, DEFAULT_CONFIG, repo_path="/fake")
        assert "selected" in script
        assert "target" in script
        assert "nontarget" in script
        # Script must be valid Python
        ast.parse(script)


# ---------------------------------------------------------------------------
# TOML save/load round-trip
# ---------------------------------------------------------------------------

class TestTomlRoundTrip:
    """Test config serialization to TOML and back."""

    def _save_toml(self, cfg, path):
        """Save config dict as TOML (matching gui_config.py's dump_toml)."""
        lines = []
        for key, val in sorted(cfg.items()):
            if isinstance(val, dict):
                lines.append(f"\n[{key}]")
                for k2, v2 in sorted(val.items()):
                    if isinstance(v2, dict):
                        lines.append(f"\n[{key}.{k2}]")
                        for k3, v3 in sorted(v2.items()):
                            lines.append(f"{k3} = {_toml_value(v3)}")
                    else:
                        lines.append(f"{k2} = {_toml_value(v2)}")
            elif not key.startswith("_"):
                lines.append(f"{key} = {_toml_value(val)}")
        with open(path, "w") as f:
            f.write("\n".join(lines) + "\n")

    def _load_toml(self, path):
        import tomllib
        with open(path, "rb") as f:
            return tomllib.load(f)

    def test_basic_round_trip(self, tmp_path):
        """Simple config survives save→load."""
        cfg = {
            "input_path": "/data/test.vhdr",
            "resample_freq": 256,
            "prepare_eeg_artifacts": True,
            "overwrite_output": False,
        }
        path = str(tmp_path / "test.toml")
        self._save_toml(cfg, path)
        loaded = self._load_toml(path)

        assert loaded["input_path"] == cfg["input_path"]
        assert loaded["resample_freq"] == cfg["resample_freq"]
        assert loaded["prepare_eeg_artifacts"] == cfg["prepare_eeg_artifacts"]
        assert loaded["overwrite_output"] == cfg["overwrite_output"]

    def test_nested_dict_round_trip(self, tmp_path):
        """Nested config sections survive save→load."""
        cfg = {
            "rest": {
                "window_length": 20,
                "whole_signal": False,
            },
            "artifacts": {
                "artifact_threshold": 0.3,
                "rejection_parameters": {
                    "SlopesAbsThr": 150,
                    "OutliersAbsThr": 150,
                },
            },
        }
        path = str(tmp_path / "nested.toml")
        self._save_toml(cfg, path)
        loaded = self._load_toml(path)

        assert loaded["rest"]["window_length"] == 20
        assert loaded["rest"]["whole_signal"] is False
        assert loaded["artifacts"]["artifact_threshold"] == pytest.approx(0.3)

    def test_list_round_trip(self, tmp_path):
        """Lists survive save→load."""
        cfg = {
            "test_section": {
                "freq_range": [11.8, 14.8],
                "scale_range": [0.5, 1.5],
            },
        }
        path = str(tmp_path / "lists.toml")
        self._save_toml(cfg, path)
        loaded = self._load_toml(path)

        assert loaded["test_section"]["freq_range"] == \
            pytest.approx([11.8, 14.8])


# ---------------------------------------------------------------------------
# TOML save/load using the REAL dump_toml/load_toml from gui_config.py
# ---------------------------------------------------------------------------

class TestRealTomlRoundTrip:
    """Test using the actual dump_toml/load_toml functions from gui_config.py."""

    def test_full_default_config_round_trip(self, tmp_path):
        """DEFAULT_CONFIG survives dump_toml → load_toml."""
        from ide4eeg.gui_config import dump_toml, load_toml
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        # Remove internal keys that aren't TOML-serializable
        cfg = {k: v for k, v in cfg.items() if not k.startswith("_")}
        path = str(tmp_path / "full_defaults.toml")
        dump_toml(cfg, path)
        loaded = load_toml(path)

        # Key sections should survive
        assert "rest" in loaded
        assert "epochs" in loaded
        assert "matching_pursuit" in loaded

        # Scalar values
        assert loaded.get("resample_freq") == cfg["resample_freq"]
        assert loaded.get("overwrite_output") == cfg["overwrite_output"]

        # Nested dicts
        assert loaded["rest"]["window_length"] == cfg["rest"]["window_length"]

        # Nested values
        assert loaded["epochs"]["start_offset"] == cfg["epochs"]["start_offset"]

    def test_pipeline_can_load_saved_config(self, tmp_path):
        """A saved TOML can be loaded by check_and_prepare_config."""
        from ide4eeg.gui_config import dump_toml
        from ide4eeg.input.input import check_and_prepare_config

        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test.vhdr"
        cfg = {k: v for k, v in cfg.items() if not k.startswith("_")}
        path = str(tmp_path / "pipeline.toml")
        dump_toml(cfg, path)

        # Load and prepare — should not crash
        import tomllib
        with open(path, "rb") as f:
            loaded = tomllib.load(f)
        check_and_prepare_config(loaded)

        assert "choosing_channels" in loaded
        assert "artifacts" in loaded

    def test_generated_script_uses_correct_api(self):
        """The generated script imports run_file from the correct module."""
        from ide4eeg.api import generate_script
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/tmp/test.vhdr"
        cfg["output_path"] = "/tmp/out/"
        cfg["prepare_eeg_profiles"] = True

        script = generate_script(cfg, DEFAULT_CONFIG, repo_path="/fake")

        # Must import from ide4eeg.api
        assert "from ide4eeg.api import run_file" in script
        # Must call run_file with input path
        assert "run_file(" in script
        assert "/tmp/test.vhdr" in script
        # Non-default analysis flag should appear
        assert "prepare_eeg_profiles=True" in script

    def test_generated_script_with_all_features(self):
        """Script with many features enabled produces valid Python."""
        from ide4eeg.api import generate_script
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["input_path"] = "/data/subject01.vhdr"
        cfg["output_path"] = "/results/"
        cfg["prepare_eeg_artifacts"] = True
        cfg["prepare_ica"] = True
        cfg["preprocessing"] = {"step_order": [
            "trim", "chosen_channels", "bad_channels", "montage",
            "filtering", "ica", "mp_decomposition"]}
        cfg["prepare_eeg_profiles"] = True
        cfg["matching_pursuit"]["empi_path"] = "/usr/bin/empi"
        cfg["matching_pursuit"]["iterations"] = 50

        script = generate_script(cfg, DEFAULT_CONFIG, repo_path="/fake")

        # Valid Python
        ast.parse(script)
        # Key features present
        assert "prepare_eeg_artifacts=True" in script
        assert "mp_decomposition" in script  # in step_order
        assert "matching_pursuit" in script


# ---------------------------------------------------------------------------
# check_and_prepare_config robustness
# ---------------------------------------------------------------------------

class TestConfigDefaults:
    """Verify check_and_prepare_config handles missing sections."""

    def test_minimal_config(self):
        """A near-empty config should not crash."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {
            "input_path": "/tmp/test.vhdr",
            "segmentation": {"mode": "rest"},
        }
        # Should not raise
        check_and_prepare_config(cfg)

        # Critical defaults should be populated
        assert "choosing_channels" in cfg
        assert "artifacts" in cfg
        assert "ICA_EOG" in cfg
        assert "epochs" in cfg
        assert cfg["artifacts"]["artifact_threshold"] == pytest.approx(0.3)

    def test_missing_choosing_channels(self):
        """Missing [choosing_channels] should be auto-created."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {"input_path": "/tmp/test.vhdr"}
        check_and_prepare_config(cfg)
        assert "badchs_params" in cfg["choosing_channels"]
        assert "correlation_window" in cfg["choosing_channels"]

    def test_missing_artifacts(self):
        """Missing [artifacts] should be auto-created."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {"input_path": "/tmp/test.vhdr"}
        check_and_prepare_config(cfg)
        assert "rejection_parameters" in cfg["artifacts"]
        assert "artifact_threshold" in cfg["artifacts"]

    def test_missing_ica(self):
        """Missing [ICA_EOG] should be auto-created with Phase 4 keys."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {"input_path": "/tmp/test.vhdr"}
        check_and_prepare_config(cfg)
        assert cfg["ICA_EOG"]["method"] == "picard"
        assert cfg["ICA_EOG"]["n_components"] == "rank"
        assert cfg["ICA_EOG"]["selector"] == "iclabel"
        assert cfg["ICA_EOG"]["random_state"] == 42

    def test_missing_epochs(self):
        """Missing [epochs] should be auto-created."""
        from ide4eeg.input.input import check_and_prepare_config
        cfg = {"input_path": "/tmp/test.vhdr"}
        check_and_prepare_config(cfg)
        assert "reject_dict" in cfg["epochs"]
        assert "flat_dict" in cfg["epochs"]
