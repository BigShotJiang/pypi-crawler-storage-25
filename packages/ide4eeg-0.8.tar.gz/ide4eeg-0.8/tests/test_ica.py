"""Tests for the Phase 4 ICA redesign — fit_and_apply_ica.

The fixture is a synthetic 19-channel 10-20 EEG built from
ground-truth sources with a known mixing matrix:

- an **alpha brain source**: 10 Hz sine with a posterior (O1/O2/Oz)
  topography — ICA should find it and ICLabel should label it
  ``brain``;
- an **ocular source**: Poisson-triggered blink transients with a
  frontal (Fp1/Fp2/Fpz) topography — ICA should find it and ICLabel
  should label it ``eye``;
- Gaussian background noise.

The fixture is deterministic (fixed numpy seed) and lives in this
file so regression tests have no external data dependency.
``examples/tfstat_data/dataset_I.obci.raw`` is one channel only and
``wake_EEG.raw`` has no EOG; neither is fit for ICA testing.
"""

import os

import mne
import numpy as np
import pytest

from ide4eeg.preprocessing.ica import (
    fit_and_apply_ica,
    ICAFailureError,
    _fit_ica,
    _prepare_fit_signal,
    _resolve_n_components,
    _resolve_reject,
)


# ── Fixture ──────────────────────────────────────────────────────────


def _make_10_20_fixture(duration=60.0, sfreq=250.0, seed=2026):
    """Return a synthetic 19-channel 10-20 EEG with brain + ocular sources."""
    rng = np.random.default_rng(seed)
    n_samples = int(round(duration * sfreq))
    ch_names = [
        "Fp1", "Fp2", "F7", "F3", "Fz", "F4", "F8",
        "T3", "C3", "Cz", "C4", "T4",
        "T5", "P3", "Pz", "P4", "T6",
        "O1", "O2",
    ]
    n_ch = len(ch_names)

    t = np.arange(n_samples) / sfreq

    # Source 1: 10 Hz alpha, posterior topography
    alpha = np.sin(2 * np.pi * 10.0 * t) * 25e-6  # ~25 µV amplitude
    posterior_map = np.zeros(n_ch)
    for ch in ("O1", "O2", "Pz", "P3", "P4"):
        posterior_map[ch_names.index(ch)] = 1.0
    posterior_map[ch_names.index("Cz")] = 0.3
    posterior_map /= np.linalg.norm(posterior_map)

    # Source 2: simulated blinks — Poisson-triggered ~200 ms transients
    blink_rate_hz = 0.3
    n_blinks = rng.poisson(blink_rate_hz * duration)
    blink = np.zeros(n_samples)
    blink_width = int(0.2 * sfreq)
    blink_kernel = np.hanning(blink_width) * 150e-6  # 150 µV amplitude
    for _ in range(n_blinks):
        start = rng.integers(0, n_samples - blink_width)
        blink[start:start + blink_width] += blink_kernel
    frontal_map = np.zeros(n_ch)
    for ch in ("Fp1", "Fp2"):
        frontal_map[ch_names.index(ch)] = 1.0
    frontal_map[ch_names.index("F3")] = 0.5
    frontal_map[ch_names.index("F4")] = 0.5
    frontal_map /= np.linalg.norm(frontal_map)

    # Background noise (Gaussian, channel-independent)
    noise = rng.standard_normal((n_ch, n_samples)) * 3e-6

    data = np.outer(posterior_map, alpha) + np.outer(frontal_map, blink) + noise

    info = mne.create_info(ch_names, sfreq=sfreq, ch_types="eeg")
    raw = mne.io.RawArray(data, info, verbose=False)
    raw.set_montage("standard_1020", match_case=False)
    return raw


@pytest.fixture
def fixture_raw():
    """Stable cached fixture — same signal for every test."""
    return _make_10_20_fixture()


# ── Core fit / configuration ─────────────────────────────────────────


class TestResolveNComponents:

    def test_rank_default_after_avg_ref(self, fixture_raw):
        raw = fixture_raw.copy().set_eeg_reference("average", verbose=False)
        fit_copy = _prepare_fit_signal(raw, {"fit_highpass_hz": 1.0})
        n = _resolve_n_components(fit_copy, {"n_components": "rank"})
        # Average reference drops rank by one.
        assert n == len(fit_copy.ch_names) - 1

    def test_fixed_integer(self, fixture_raw):
        fit_copy = _prepare_fit_signal(fixture_raw, {})
        n = _resolve_n_components(fit_copy, {"n_components": 10})
        assert n == 10

    def test_float_fraction(self, fixture_raw):
        fit_copy = _prepare_fit_signal(fixture_raw, {})
        n = _resolve_n_components(fit_copy, {"n_components": 0.5})
        assert n == round(len(fit_copy.ch_names) * 0.5)


class TestResolveReject:

    def test_default_500uv(self):
        reject = _resolve_reject({"reject_uv": 500})
        assert reject == {"eeg": 500e-6}

    def test_zero_disables(self):
        assert _resolve_reject({"reject_uv": 0}) is None

    def test_missing_uses_default(self):
        reject = _resolve_reject({})
        assert reject == {"eeg": 500e-6}


class TestPrepareFitSignal:

    def test_winkler_highpass_applied(self, fixture_raw):
        fit_copy = _prepare_fit_signal(
            fixture_raw, {"fit_highpass_hz": 1.0})
        assert fit_copy.info["highpass"] >= 0.5
        # Original signal must not be mutated.
        assert fixture_raw.info["highpass"] == 0.0

    def test_highpass_zero_disables(self, fixture_raw):
        fit_copy = _prepare_fit_signal(
            fixture_raw, {"fit_highpass_hz": 0})
        assert fit_copy.info["highpass"] == 0.0

    def test_eeg_only(self, fixture_raw):
        fit_copy = _prepare_fit_signal(fixture_raw, {})
        types = set(fit_copy.get_channel_types())
        assert types == {"eeg"}


# ── Default stack end-to-end (Picard + find_bads fallback) ───────────


class TestDefaultStackRecoversSources:
    """With the default Picard fit, ICA should find the two planted
    sources.  We verify that (a) the fit converges, (b) at least one
    component has a frontal topography (ocular), and (c) the cleaned
    signal retains alpha power at posterior electrodes."""

    def test_picard_fit_converges(self, fixture_raw):
        fit_copy = _prepare_fit_signal(
            fixture_raw, {"fit_highpass_hz": 1.0})
        cfg = {
            "method": "picard",
            "n_components": "rank",
            "random_state": 42,
            "max_iter": "auto",
            "decim": 1,
            "reject_uv": 500.0,
        }
        ica = _fit_ica(fit_copy, cfg)
        assert ica.n_components_ > 0

    def test_find_bads_eog_flags_frontal_component(
            self, fixture_raw, tmp_path):
        """Using the find_bads selector (no ICLabel dependency) we
        expect ``find_bads_eog`` to flag at least one component."""
        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": "rank",
            "selector": "find_bads",
            "find_bads_eog_ch": ["Fp1", "Fp2"],
            "find_bads_ecg": False,
            "find_bads_muscle": False,
            "save": False,
        }}
        cleaned = fit_and_apply_ica(
            fixture_raw, cfg, str(tmp_path), "synthetic")
        bads = cfg["ICA_EOG"]["bad_sources"]
        assert len(bads) >= 1, \
            f"Expected ≥1 ocular component flagged, got {bads}"
        # Cleaned signal must differ from the original at frontal channels.
        orig_fp = fixture_raw.get_data(picks=["Fp1", "Fp2"])
        clean_fp = cleaned.get_data(picks=["Fp1", "Fp2"])
        diff_rms = float(np.sqrt(np.mean((orig_fp - clean_fp) ** 2)))
        assert diff_rms > 1e-7, \
            f"Cleaning produced no change at frontal channels (RMS={diff_rms})"


# ── Reproducibility ──────────────────────────────────────────────────


class TestReproducibility:

    def test_random_state_42_stable(self, fixture_raw):
        fit_copy = _prepare_fit_signal(
            fixture_raw, {"fit_highpass_hz": 1.0})
        cfg = {
            "method": "picard",
            "n_components": 10,
            "random_state": 42,
            "max_iter": "auto",
            "decim": 1,
            "reject_uv": 0,
        }
        ica_a = _fit_ica(fit_copy, cfg)
        ica_b = _fit_ica(fit_copy, cfg)
        np.testing.assert_allclose(
            ica_a.mixing_matrix_, ica_b.mixing_matrix_,
            rtol=1e-10, atol=1e-12)

    def test_different_seed_gives_different_mixing(self, fixture_raw):
        fit_copy = _prepare_fit_signal(
            fixture_raw, {"fit_highpass_hz": 1.0})
        base = {
            "method": "picard",
            "n_components": 10,
            "max_iter": "auto",
            "decim": 1,
            "reject_uv": 0,
        }
        ica_a = _fit_ica(fit_copy, {**base, "random_state": 42})
        ica_b = _fit_ica(fit_copy, {**base, "random_state": 43})
        # Component order can differ but the mixing matrices should
        # not be bit-identical.
        assert not np.allclose(
            ica_a.mixing_matrix_, ica_b.mixing_matrix_,
            rtol=1e-10, atol=1e-12)


# ── Reject mechanism ────────────────────────────────────────────────


class TestRejectDropsCrazySegments:

    def test_spike_rejected_from_fit(self, fixture_raw):
        """Inject a 5 mV transient into one channel and verify the
        fit still converges — i.e. the reject gate kept it out."""
        raw = fixture_raw.copy()
        raw.load_data()
        data = raw.get_data()
        # 100 ms spike at t=20s on Fp1
        sfreq = raw.info["sfreq"]
        spike_start = int(20 * sfreq)
        spike_len = int(0.1 * sfreq)
        fp1_idx = raw.ch_names.index("Fp1")
        data[fp1_idx, spike_start:spike_start + spike_len] += 5e-3  # 5 mV
        raw._data = data

        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 8,
            "selector": "find_bads",
            "find_bads_eog_ch": ["Fp1"],
            "find_bads_ecg": False,
            "find_bads_muscle": False,
            "save": False,
        }}
        # Should complete — if the spike leaked into the fit Picard
        # would still converge on synthetic data, but the real test is
        # that no exception is raised here.
        cleaned = fit_and_apply_ica(
            raw, cfg, "/tmp", "spike_test")
        assert cleaned is not raw


# ── Failure modes ────────────────────────────────────────────────────


class TestFailureModes:

    def test_iclabel_flags_everything_raises(
            self, fixture_raw, tmp_path, monkeypatch):
        """Monkeypatch ICLabel to return every component as 'other'
        with the keep list only containing 'brain' — every component
        gets flagged, and the step must raise ICAFailureError."""
        import ide4eeg.preprocessing.ica as ica_mod

        def fake_label(raw, ica, method="iclabel"):
            n = ica.n_components_
            return {
                "labels": ["eye"] * n,
                "y_pred_proba": np.ones((n, 7)) * 0.9,
            }

        monkeypatch.setattr(
            ica_mod, "_iclabel_label_components", fake_label)
        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 5,
            "selector": "iclabel",
            "iclabel_keep": ["brain"],
            "save": False,
        }}
        with pytest.raises(ICAFailureError, match="every component"):
            fit_and_apply_ica(
                fixture_raw, cfg, str(tmp_path), "synthetic")

    def test_iclabel_missing_raises(
            self, fixture_raw, tmp_path, monkeypatch):
        """When mne_icalabel is unavailable and selector=iclabel, the
        step must raise a clear error rather than silently falling
        through."""
        import ide4eeg.preprocessing.ica as ica_mod

        monkeypatch.setattr(ica_mod, "_iclabel_label_components", None)
        monkeypatch.setattr(
            ica_mod, "_ICLABEL_IMPORT_ERROR",
            ImportError("simulated missing mne_icalabel"))

        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 5,
            "selector": "iclabel",
            "save": False,
        }}
        with pytest.raises(ICAFailureError, match="mne_icalabel"):
            fit_and_apply_ica(
                fixture_raw, cfg, str(tmp_path), "synthetic")


# ── Audit tree ───────────────────────────────────────────────────────


class TestAuditTree:

    def test_save_writes_expected_files(
            self, fixture_raw, tmp_path):
        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 8,
            "selector": "find_bads",
            "find_bads_eog_ch": ["Fp1", "Fp2"],
            "find_bads_ecg": False,
            "find_bads_muscle": False,
            "save_components_audit": True,
        }}
        fit_and_apply_ica(
            fixture_raw, cfg, str(tmp_path), "synthetic")

        out_dir = tmp_path / "artifacts_detection" / "ICA_EOG"
        assert out_dir.is_dir()

        files = sorted(p.name for p in out_dir.iterdir())
        assert any(f.endswith("-ica.fif") for f in files), \
            f"missing .fif in {files}"
        assert any("classification.csv" in f for f in files), \
            f"missing classification CSV in {files}"

    def test_property_plots_saved_with_rejected_segment(
            self, fixture_raw, tmp_path):
        """Regression: pre-fix, plot_properties(reject='auto') crashed
        every component with an OOB on data with rejected 2-sec
        windows. The spike must land in the LAST window so
        max(dropped_indices) exceeds the post-rejection epoch count;
        a mid-signal spike doesn't trigger the bug.
        """
        raw = fixture_raw.copy()
        raw.load_data()
        data = raw.get_data()
        sfreq = raw.info["sfreq"]
        # 5 mV transient in the LAST 2-sec window — guarantees
        # max(dropped_indices) > len(epoch_var).
        last_start = int(data.shape[1] - 1.5 * sfreq)
        spike_len = int(0.1 * sfreq)
        fp1_idx = raw.ch_names.index("Fp1")
        data[fp1_idx, last_start:last_start + spike_len] += 5e-3
        raw._data = data

        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 5,
            "selector": "find_bads",
            "find_bads_eog_ch": ["Fp1", "Fp2"],
            "find_bads_ecg": False,
            "find_bads_muscle": False,
            "save_components_audit": True,
        }}
        fit_and_apply_ica(raw, cfg, str(tmp_path), "spike_audit")

        out_dir = tmp_path / "artifacts_detection" / "ICA_EOG"
        prop_files = sorted(
            p.name for p in out_dir.iterdir()
            if "_ICA_properties_" in p.name and p.name.endswith(".png"))
        assert len(prop_files) > 0, (
            f"No property plots saved — MNE OOB bug regressed. "
            f"Files in {out_dir}: {sorted(p.name for p in out_dir.iterdir())}")

    def test_no_save_produces_no_dir(
            self, fixture_raw, tmp_path):
        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 8,
            "selector": "find_bads",
            "find_bads_eog_ch": ["Fp1", "Fp2"],
            "find_bads_ecg": False,
            "find_bads_muscle": False,
            "save_components_audit": False,
        }}
        fit_and_apply_ica(
            fixture_raw, cfg, str(tmp_path), "synthetic")
        out_dir = tmp_path / "artifacts_detection" / "ICA_EOG"
        assert not out_dir.exists()

    def test_classification_csv_label_and_prob_populated(
            self, fixture_raw, tmp_path):
        """Regression: _select_iclabel used to discard labels/probs
        after computing them, so _write_classification_csv saw None
        via getattr() and emitted blank 'label' / 'max_prob' columns.
        """
        pytest.importorskip("mne_icalabel")
        cfg = {"ICA_EOG": {
            "method": "picard",
            "random_state": 42,
            "fit_highpass_hz": 1.0,
            "decim": 1,
            "reject_uv": 500.0,
            "n_components": 8,
            "selector": "iclabel",
            "iclabel_keep": ["brain", "other"],
            "save_components_audit": True,
        }}
        fit_and_apply_ica(
            fixture_raw, cfg, str(tmp_path), "synthetic")

        import csv
        out_dir = tmp_path / "artifacts_detection" / "ICA_EOG"
        csv_path = next(out_dir.glob("*classification.csv"))
        with open(csv_path) as f:
            rows = list(csv.DictReader(f))
        assert rows, "classification CSV is empty"
        for r in rows:
            assert r["label"], (
                f"label column blank for component {r['component']}")
            assert r["max_prob"], (
                f"max_prob column blank for component {r['component']}")
            assert 0.0 <= float(r["max_prob"]) <= 1.0
