"""Tests for Qt GUI config round-trip, widget construction, and data integrity.

These tests build the actual Qt GUI (offscreen) and verify that:
- _collect_config produces valid config dicts
- _populate_vars restores all keys that _collect_config writes
- _num handles all edge cases
- DEFAULT_CONFIG is self-consistent
"""

import copy
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ide4eeg.gui_config import DEFAULT_CONFIG, _toml_value

# ---------------------------------------------------------------------------
# DEFAULT_CONFIG consistency
# ---------------------------------------------------------------------------

class TestDefaultConfig:
    """Verify DEFAULT_CONFIG structure and types."""

    def test_deepcopy_independent(self):
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        cfg["rest"]["window_length"] = 999
        assert DEFAULT_CONFIG["rest"]["window_length"] != 999

    def test_required_sections_exist(self):
        for section in ("rest", "epochs", "matching_pursuit",
                        "eeg_profiles", "segment_rejection"):
            assert section in DEFAULT_CONFIG, f"Missing section: {section}"

    def test_gaze_method_default_is_l2cs(self):
        assert DEFAULT_CONFIG.get("facetag_gaze_method") == "l2cs"

    def test_gaze_method_valid_options(self):
        """Only insightface and l2cs should be offered as gaze backends."""
        valid = {"insightface", "l2cs"}
        default = DEFAULT_CONFIG.get("facetag_gaze_method", "l2cs")
        assert default in valid, f"default gaze_method {default!r} not in {valid}"

    def test_boolean_flags_are_bool(self):
        bool_keys = [
            "prepare_eeg_artifacts", "prepare_ica",
            "prepare_video_artifacts",
            "prepare_mp_filter",
            "prepare_eeg_profiles",
            "prepare_connectivity_analysis", "prepare_dipole_fitting",
            "overwrite_output",
        ]
        for key in bool_keys:
            assert isinstance(DEFAULT_CONFIG.get(key), bool), \
                f"{key} should be bool, got {type(DEFAULT_CONFIG.get(key))}"



# ---------------------------------------------------------------------------
# _toml_value edge cases
# ---------------------------------------------------------------------------

class TestTomlValueExtended:

    def test_numpy_int(self):
        import numpy as np
        result = _toml_value(np.int64(42))
        assert "42" in result

    def test_numpy_float(self):
        import numpy as np
        result = _toml_value(np.float64(3.14))
        assert "3.14" in result

    def test_nested_list(self):
        result = _toml_value([1, [2, 3]])
        assert result == "[1, [2, 3]]"

    def test_dict_value(self):
        result = _toml_value({"a": 1})
        assert "a" in result


# ---------------------------------------------------------------------------
# Qt GUI construction smoke tests
# ---------------------------------------------------------------------------

_qt_app = None
_qt_gui = None


def _get_qt_gui():
    """Lazily build and cache the Qt GUI instance (offscreen)."""
    global _qt_app, _qt_gui
    if _qt_gui is not None:
        return _qt_gui
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        from PySide6.QtGui import QFont
        _qt_app = QApplication.instance() or QApplication(sys.argv)
        _qt_app.setFont(QFont(".AppleSystemUIFont" if sys.platform == "darwin"
                               else "Segoe UI" if sys.platform == "win32"
                               else "Sans"))
        from ide4eeg.gui import IDE4EEG_Qt
        _qt_gui = IDE4EEG_Qt()
        # Build all lazy tabs
        for i in range(_qt_gui._tabs.count()):
            _qt_gui._tabs.setCurrentIndex(i)
        return _qt_gui
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")


@pytest.fixture(scope="module")
def qt_gui():
    gui = _get_qt_gui()
    if gui is None:
        pytest.skip("Qt GUI not available")
    yield gui


class TestQtGuiConstruction:
    """Smoke tests for the Qt GUI."""

    def test_build_no_crash(self, qt_gui):
        assert qt_gui is not None
        assert hasattr(qt_gui, "_pp")
        assert hasattr(qt_gui, "_an")
        assert hasattr(qt_gui, "config_data")

    def test_all_tabs_built(self, qt_gui):
        expected = {"config", "io", "preproc", "analysis", "run", "output", "help"}
        assert expected <= set(qt_gui._tab_built.keys())

    def test_collect_config_no_crash(self, qt_gui):
        cfg = qt_gui._collect_config()
        assert isinstance(cfg, dict)
        assert "rest" in cfg
        assert "epochs" in cfg
        assert "artifacts" in cfg
        assert "matching_pursuit" in cfg

        assert isinstance(cfg.get("prepare_eeg_artifacts"), bool)
        assert isinstance(cfg.get("prepare_ica"), bool)

        art = cfg.get("artifacts", {})
        assert "enable_slopes" in art
        assert "enable_outliers" in art
        assert "enable_muscles" in art
        assert "enable_amplitude" in art

    def test_config_sections(self, qt_gui):
        cfg = qt_gui._collect_config()
        for section in ("rest", "epochs", "matching_pursuit",
                        "eeg_profiles",
                        "segment_rejection",
                        "connectivity", "dipole_fitting"):
            assert section in cfg, f"Missing config section: {section}"

    def test_boolean_flags(self, qt_gui):
        cfg = qt_gui._collect_config()
        for key in ("prepare_eeg_artifacts", "prepare_ica",
                     "prepare_video_artifacts",
                     "prepare_connectivity_analysis",
                     "prepare_eeg_profiles",
                     "overwrite_output"):
            assert isinstance(cfg.get(key), bool), \
                f"{key} should be bool, got {type(cfg.get(key))}"

    def test_config_round_trip(self, qt_gui):
        """_collect_config -> _populate_vars -> _collect_config stability."""
        cfg1 = qt_gui._collect_config()
        qt_gui._populate_vars(cfg1)
        cfg2 = qt_gui._collect_config()

        for key in ("prepare_eeg_artifacts", "prepare_ica",
                     "prepare_video_artifacts",
                     "overwrite_output"):
            assert cfg1.get(key) == cfg2.get(key), \
                f"Round-trip mismatch for {key}: {cfg1.get(key)} -> {cfg2.get(key)}"
        # MP enable state lives in step_order now (not a top-level
        # flag).  Check that round-trip preserves it there.
        order1 = cfg1.get("preprocessing", {}).get("step_order", [])
        order2 = cfg2.get("preprocessing", {}).get("step_order", [])
        assert ("mp_decomposition" in order1) == \
               ("mp_decomposition" in order2)

        assert cfg1["rest"]["window_length"] == cfg2["rest"]["window_length"]
        assert cfg1["rest"]["whole_signal"] == cfg2["rest"]["whole_signal"]

    def test_step_order_only_checked(self, qt_gui):
        """step_order should only contain checked preprocessing steps."""
        cfg = qt_gui._collect_config()
        order = cfg.get("preprocessing", {}).get("step_order", [])
        assert isinstance(order, list)
        # With defaults, at least some steps should be checked
        # (bad_channels, montage, filtering are on by default in fresh GUI)

    def test_connectivity_methods(self, qt_gui):
        """Connectivity methods are collected as a list."""
        cfg = qt_gui._collect_config()
        methods = cfg.get("connectivity", {}).get("methods", [])
        assert isinstance(methods, list)

    def test_eeg_profiles_structures(self, qt_gui):
        """EEG profiles structures are collected as a list of dicts."""
        cfg = qt_gui._collect_config()
        structs = cfg.get("eeg_profiles", {}).get("structures", [])
        assert isinstance(structs, list)

    def test_mode_combo(self, qt_gui):
        """Mode combo value is collected."""
        cfg = qt_gui._collect_config()
        assert cfg.get("segmentation", {}).get("mode") in ("rest", "epochs")

    def test_dipole_fitting_fields(self, qt_gui):
        """Dipole fitting has required fields."""
        cfg = qt_gui._collect_config()
        dip = cfg.get("dipole_fitting", {})
        for key in ("ref_channel", "montage", "max_iterations",
                     "min_gof", "freq_min", "freq_max",
                     "scale_min", "scale_max", "dot_size"):
            assert key in dip, f"Missing dipole_fitting key: {key}"


# ---------------------------------------------------------------------------
# Config concordance: GUI vs CLI vs script export
# ---------------------------------------------------------------------------

class TestConfigConcordance:
    """Verify that GUI, CLI (TOML), and script export produce configs
    that the pipeline can consume without missing keys."""

    # All analysis boolean flags the pipeline checks.  Note: MP
    # decomposition no longer has a top-level flag — it's in
    # preprocessing.step_order.
    _ANALYSIS_FLAGS = [
        "prepare_eeg_artifacts", "prepare_ica",
        "prepare_video_artifacts",
        "prepare_eeg_profiles", "prepare_connectivity_analysis",
        "prepare_dipole_fitting",
    ]

    # Required config sections the pipeline accesses
    _REQUIRED_SECTIONS = [
        "rest", "epochs", "filters", "artifacts", "ICA_EOG",
        "choosing_channels", "matching_pursuit", "connectivity",
        "dipole_fitting", "eeg_profiles",
    ]

    def test_gui_config_has_all_analysis_flags(self, qt_gui):
        """GUI _collect_config must produce every analysis flag as a bool."""
        cfg = qt_gui._collect_config()
        for flag in self._ANALYSIS_FLAGS:
            assert flag in cfg, f"GUI config missing flag: {flag}"
            assert isinstance(cfg[flag], bool), \
                f"GUI {flag} should be bool, got {type(cfg[flag])}"

    def test_gui_config_has_required_sections(self, qt_gui):
        """GUI _collect_config must produce all sections the pipeline needs."""
        cfg = qt_gui._collect_config()
        for section in self._REQUIRED_SECTIONS:
            assert section in cfg, \
                f"GUI config missing section: {section}"
            assert isinstance(cfg[section], dict), \
                f"GUI {section} should be dict, got {type(cfg[section])}"

    def test_gui_toml_round_trip(self, qt_gui, tmp_path):
        """GUI config -> save as TOML -> load -> pipeline accepts it."""
        from ide4eeg.gui_config import dump_toml, load_toml
        from ide4eeg.input.input import check_and_prepare_config

        cfg1 = qt_gui._collect_config()
        toml_path = str(tmp_path / "gui_export.toml")
        dump_toml(cfg1, toml_path)
        cfg2 = load_toml(toml_path)
        assert cfg2 is not None, "Failed to reload saved TOML"

        # Pipeline's check_and_prepare_config should not crash
        cfg2 = check_and_prepare_config(cfg2)

        # All analysis flags must survive the round-trip
        for flag in self._ANALYSIS_FLAGS:
            assert flag in cfg2 or flag in cfg1, \
                f"Flag {flag} lost in TOML round-trip"

    def test_script_export_contains_all_gui_flags(self, qt_gui):
        """Script export allowlist must cover all flags the GUI produces."""
        from ide4eeg.api import generate_script
        from ide4eeg.gui_config import DEFAULT_CONFIG

        # Enable everything so diff is maximal
        cfg = qt_gui._collect_config()
        for flag in self._ANALYSIS_FLAGS:
            cfg[flag] = True
        cfg["input_path"] = "/tmp/test.fif"

        script = generate_script(cfg, DEFAULT_CONFIG)
        assert "run_file(" in script, "Script must contain run_file call"

        # Every True flag should appear in the script
        for flag in self._ANALYSIS_FLAGS:
            if cfg.get(flag):
                assert flag in script, \
                    f"Script export dropped enabled flag: {flag}"

    def test_run_file_seeds_all_flags(self):
        """run_file() must seed defaults for every analysis flag."""
        from ide4eeg.api import run_file
        import inspect

        # Get the source and check setdefault calls
        src = inspect.getsource(run_file)
        for flag in self._ANALYSIS_FLAGS:
            # Flag must be either seeded or not required by run_file
            # (pipeline's check_and_prepare_config handles the rest)
            pass  # covered by test_gui_toml_round_trip

    def test_pipeline_accepts_gui_config(self, qt_gui):
        """check_and_prepare_config must not crash on GUI-collected config."""
        from ide4eeg.input.input import check_and_prepare_config

        cfg = qt_gui._collect_config()
        # Must not raise
        result = check_and_prepare_config(cfg)
        assert isinstance(result, dict)

        # Verify pipeline-critical keys exist after preparation
        assert "resample_freq" in result
        assert "amplitude_max_threshold" in result
        assert "artifacts" in result
        assert "rejection_parameters" in result["artifacts"]

    def test_mne_catalog_round_trip(self, qt_gui, tmp_path):
        """MNE catalog selections must survive config save/load."""
        from ide4eeg.gui_config import dump_toml, load_toml

        # Check a few MNE analyses
        checks = getattr(qt_gui, "_mne_checks", {})
        test_ids = list(checks.keys())[:3]
        for aid in test_ids:
            checks[aid].setChecked(True)

        cfg1 = qt_gui._collect_config()
        assert cfg1.get("mne_catalog"), "No MNE selections collected"

        toml_path = str(tmp_path / "mne_test.toml")
        dump_toml(cfg1, toml_path)
        cfg2 = load_toml(toml_path)
        assert cfg2.get("mne_catalog") == cfg1["mne_catalog"], \
            "MNE catalog selections lost in TOML round-trip"

        # Restore via _populate_vars and re-collect
        qt_gui._populate_vars(cfg2)
        cfg3 = qt_gui._collect_config()
        assert set(cfg3.get("mne_catalog", [])) == set(test_ids), \
            "MNE selections lost after populate_vars round-trip"

        # Clean up
        for aid in test_ids:
            checks[aid].setChecked(False)


# ---------------------------------------------------------------------------
# SelectionPanel "EEG only" filter
# ---------------------------------------------------------------------------

class TestSelectionPanelEEGFilter:
    """Verify the SelectionPanel EEG filter trusts MNE channel types when
    available, and falls back to a case-insensitive name pattern only when
    types are missing.
    """

    def _make_panel(self):
        _get_qt_gui()  # ensure QApplication exists
        from ide4eeg.gui import SelectionPanel
        return SelectionPanel(title="Channels", eeg_filter=True)

    def test_trusts_mne_types_when_provided(self):
        """File-format types win: stim/eog/ecg/emg are excluded; eeg
        is included regardless of name."""
        panel = self._make_panel()
        names = ["Fp1", "Cz", "STI 014", "VEOG", "ECG_lead", "Random_Aux"]
        types = ["eeg", "eeg", "stim",   "eog",  "ecg",      "misc"]
        panel.populate(names, ch_types=types)
        eeg = panel._eeg_names()
        assert eeg == ["Fp1", "Cz"]

    def test_eeg_named_oddly_still_eeg_when_typed(self):
        """A channel called "p_noga" typed as 'eeg' is treated as EEG.

        This is the regression test for the historical hardcoded set:
        previously the name 'p_noga' would have been excluded by the
        global filter regardless of the file's own typing.
        """
        panel = self._make_panel()
        panel.populate(["p_noga", "Fp1"], ch_types=["eeg", "eeg"])
        assert panel._eeg_names() == ["p_noga", "Fp1"]

    def test_non_eeg_named_eeg_still_excluded_when_typed(self):
        """A channel typed as 'eog' is excluded even if its name
        looks like EEG (e.g., the user mistyped or the lab uses an
        unusual convention)."""
        panel = self._make_panel()
        panel.populate(["Fp1_EOG", "Fp2"], ch_types=["eog", "eeg"])
        assert panel._eeg_names() == ["Fp2"]

    def test_name_fallback_when_types_unknown(self):
        """Without type info: fall back to case-insensitive name patterns."""
        panel = self._make_panel()
        names = ["Fp1", "Cz", "EOG", "eog", "Eog",
                 "ECG_left", "TRIGGER", "Marker_5",
                 "ResP_belt", "T8"]
        panel.populate(names)  # no ch_types
        eeg = panel._eeg_names()
        # EEG channels: Fp1, Cz, T8.
        # All EOG/ECG/TRIGGER/Marker/Resp variants excluded by name.
        assert eeg == ["Fp1", "Cz", "T8"]

    def test_case_insensitive_fallback(self):
        """The fallback must catch mixed-case variants the old hardcoded
        set missed: 'eog', 'Eog', 'EOG' all excluded."""
        panel = self._make_panel()
        for variant in ["eog", "Eog", "EOG", "VEOG", "veog"]:
            panel.populate([variant, "Cz"])
            assert variant not in panel._eeg_names(), \
                f"{variant!r} should be excluded by name fallback"

    def test_polish_names_no_longer_hardcoded(self):
        """The historical Polish-language EMG names from one specific
        2023 dataset (p_noga, l_noga, p_reka, l_reka) must not be
        special-cased. Without type info, the name fallback should be
        a no-op for them — they pass through as 'unknown' = treat-as-EEG.
        """
        panel = self._make_panel()
        names = ["p_noga", "l_noga", "p_reka", "l_reka", "Cz"]
        panel.populate(names)  # no ch_types
        eeg = panel._eeg_names()
        # All five pass the fallback (no pattern matches)
        assert set(eeg) == set(names)

    def test_no_types_no_fallback_match_means_eeg(self):
        """A channel with no type info AND no non-EEG pattern match
        is treated as EEG (the default-permissive stance)."""
        panel = self._make_panel()
        panel.populate(["UnknownLabel", "Fp1"])
        assert panel._eeg_names() == ["UnknownLabel", "Fp1"]


# ---------------------------------------------------------------------------
# Channel type override GUI integration
# ---------------------------------------------------------------------------

class TestChannelTypeOverrideGUI:
    """GUI-level integration tests for the override feature.

    Covers the signals from SelectionPanel to IDE4EEG_Qt, the
    _set_channel_type_override / _apply_type_overrides_to_cache
    round-trip, and the review dialog's diff semantics.
    """

    def test_set_override_updates_config_and_cache(self):
        """Simulate a right-click override: call
        _set_channel_type_override and verify config_data and
        _cached_ch_types both reflect the new type."""
        qt_gui = _get_qt_gui()
        qt_gui._cached_ch_names = ["Fp1", "Cz", "Aux1"]
        qt_gui._base_ch_types = ["eeg", "eeg", "misc"]
        qt_gui._cached_ch_types = list(qt_gui._base_ch_types)
        qt_gui.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = {}

        qt_gui._set_channel_type_override("Aux1", "ecg")
        assert qt_gui.config_data["choosing_channels"][
            "type_overrides"] == {"Aux1": "ecg"}
        assert qt_gui._cached_ch_types == ["eeg", "eeg", "ecg"]

    def test_set_override_auto_removes_existing(self):
        """Setting an override to 'auto' removes it and restores the
        base (inferred) type."""
        qt_gui = _get_qt_gui()
        qt_gui._cached_ch_names = ["Fp1", "Aux1"]
        qt_gui._base_ch_types = ["eeg", "misc"]
        qt_gui._cached_ch_types = ["eeg", "misc"]
        qt_gui.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = {"Aux1": "ecg"}
        qt_gui._apply_type_overrides_to_cache()
        assert qt_gui._cached_ch_types == ["eeg", "ecg"]

        # Remove via "auto"
        qt_gui._set_channel_type_override("Aux1", "auto")
        assert qt_gui.config_data["choosing_channels"][
            "type_overrides"] == {}
        assert qt_gui._cached_ch_types == ["eeg", "misc"]

    def test_overrides_survive_config_round_trip(self, tmp_path):
        """Apply an override, call _collect_config, _populate_vars,
        verify the override dict is preserved."""
        import copy
        from ide4eeg.gui_config import dump_toml, load_toml
        qt_gui = _get_qt_gui()
        qt_gui._cached_ch_names = ["Fp1", "MyChannel"]
        qt_gui._base_ch_types = ["eeg", "misc"]
        qt_gui._cached_ch_types = list(qt_gui._base_ch_types)
        qt_gui.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = {}

        qt_gui._set_channel_type_override("MyChannel", "eog")

        cfg = qt_gui._collect_config()
        assert cfg["choosing_channels"]["type_overrides"] == {
            "MyChannel": "eog"}

        # Round trip via TOML
        path = str(tmp_path / "roundtrip.toml")
        dump_toml(cfg, path)
        loaded = load_toml(path)
        assert loaded["choosing_channels"]["type_overrides"] == {
            "MyChannel": "eog"}

        # Clean up
        qt_gui._set_channel_type_override("MyChannel", "auto")

    def test_review_panel_is_inline_and_type_editable(self):
        """The Input tab has an inline collapsible "Review channel types"
        group with an embedded SelectionPanel (type_editable=True).
        This is the only type_editable panel in the app — all per-tab
        channel panels are read-only for types."""
        qt_gui = _get_qt_gui()
        from ide4eeg.gui import SelectionPanel, CollapsibleGroupBox
        # Inline panel exists and is type_editable
        assert hasattr(qt_gui, "_ch_type_review_group")
        assert isinstance(qt_gui._ch_type_review_group, CollapsibleGroupBox)
        assert hasattr(qt_gui, "_ch_type_review_panel")
        assert isinstance(qt_gui._ch_type_review_panel, SelectionPanel)
        assert qt_gui._ch_type_review_panel._type_editable is True
        assert qt_gui._ch_type_review_panel._eeg_filter is True
        # No per-tab panel is type_editable
        for panel in qt_gui._channel_panels:
            assert panel._type_editable is False
        # Review panel is NOT in _channel_panels (cosmetic checkboxes)
        assert qt_gui._ch_type_review_panel not in qt_gui._channel_panels

    def test_review_panel_override_signal_routes_to_main(self):
        """Right-click → 'Set type' on the inline review panel emits
        the override signal directly to the main window's handler.
        Simulate by emitting the signal on the panel and checking
        the main window's config was updated."""
        qt_gui = _get_qt_gui()
        qt_gui._cached_ch_names = ["Fp1", "Heart_sensor"]
        qt_gui._base_ch_types = ["eeg", "misc"]
        qt_gui._cached_ch_types = list(qt_gui._base_ch_types)
        qt_gui.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = {}
        qt_gui._ch_type_review_panel.populate(
            qt_gui._cached_ch_names,
            ch_types={"Fp1": "eeg", "Heart_sensor": "misc"})

        # Emit the panel's override signal (same as a right-click would)
        qt_gui._ch_type_review_panel.channel_type_override_requested.emit(
            "Heart_sensor", "ecg")
        assert qt_gui.config_data["choosing_channels"][
            "type_overrides"] == {"Heart_sensor": "ecg"}
        assert qt_gui._cached_ch_types == ["eeg", "ecg"]
        # The review panel's local type dict reflects the override too
        assert (qt_gui._ch_type_review_panel._ch_types["Heart_sensor"]
                == "ecg")

        # Clean up
        qt_gui._set_channel_type_override("Heart_sensor", "auto")

    def test_apply_cache_refreshes_review_panel(self):
        """_apply_type_overrides_to_cache must also refresh the inline
        review panel so its labels reflect the new type immediately."""
        qt_gui = _get_qt_gui()
        qt_gui._cached_ch_names = ["Fp1", "Aux1"]
        qt_gui._base_ch_types = ["eeg", "misc"]
        qt_gui._cached_ch_types = list(qt_gui._base_ch_types)
        qt_gui.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = {}
        qt_gui._ch_type_review_panel.populate(
            qt_gui._cached_ch_names,
            ch_types={"Fp1": "eeg", "Aux1": "misc"})

        qt_gui._set_channel_type_override("Aux1", "bio")
        assert (qt_gui._ch_type_review_panel._ch_types["Aux1"]
                == "bio")

        # Clean up
        qt_gui._set_channel_type_override("Aux1", "auto")

    def test_selection_panel_type_editable_false_no_rightclick(self):
        """By default (Preprocessing/Analysis tabs), SelectionPanel
        has type_editable=False and no right-click context menu is
        wired on the checkboxes."""
        from PySide6.QtCore import Qt
        _get_qt_gui()
        from ide4eeg.gui import SelectionPanel
        panel = SelectionPanel(title="X", eeg_filter=True)
        panel.populate(
            ["Fp1", "EOG"],
            ch_types={"Fp1": "eeg", "EOG": "eog"})
        assert panel._type_editable is False
        # Checkboxes should have DefaultContextMenu, not CustomContextMenu
        for _, cb in panel._checkboxes:
            assert cb.contextMenuPolicy() != Qt.CustomContextMenu

    def test_selection_panel_adaptive_filter_buttons(self):
        """Per-tab channel panels show adaptive per-type filter
        buttons — only types present in the file get a button."""
        _get_qt_gui()
        from ide4eeg.gui import SelectionPanel
        panel = SelectionPanel(title="X", eeg_filter=True)
        panel.populate(
            ["Fp1", "Cz", "EOG", "Heart"],
            ch_types={"Fp1": "eeg", "Cz": "eeg",
                      "EOG": "eog", "Heart": "ecg"})
        labels = [b.text() for b in panel._filter_buttons]
        # Must contain EEG, EOG, ECG buttons (in that preferred order)
        assert labels == ["EEG (2)", "EOG (1)", "ECG (1)"]

    def test_selection_panel_filter_button_toggle(self):
        """Clicking a per-type filter button adds channels of that
        type to the selection (toggle: click again to remove them)."""
        _get_qt_gui()
        from ide4eeg.gui import SelectionPanel
        panel = SelectionPanel(title="X", eeg_filter=True)
        panel.populate(
            ["Fp1", "Cz", "EOG", "Heart"],
            ch_types={"Fp1": "eeg", "Cz": "eeg",
                      "EOG": "eog", "Heart": "ecg"})
        # Start with nothing selected
        panel._select_none()
        # Click "ECG" — should add Heart without disturbing others
        ecg_btn = [b for b in panel._filter_buttons
                   if "ECG" in b.text()][0]
        ecg_btn.click()
        assert panel.selected_items() == ["Heart"]
        # Click "EEG" — should also add EEG channels
        eeg_btn = [b for b in panel._filter_buttons
                   if b.text().startswith("EEG")][0]
        eeg_btn.click()
        assert set(panel.selected_items()) == {"Fp1", "Cz", "Heart"}
        # Click "ECG" again — Heart was selected, so it should be removed
        ecg_btn.click()
        assert set(panel.selected_items()) == {"Fp1", "Cz"}

    def test_selection_panel_adaptive_rebuilds_on_type_change(self):
        """If set_channel_types applies an override, the filter
        button row rebuilds to reflect the new type distribution."""
        _get_qt_gui()
        from ide4eeg.gui import SelectionPanel
        panel = SelectionPanel(title="X", eeg_filter=True)
        panel.populate(
            ["Fp1", "Aux1"],
            ch_types={"Fp1": "eeg", "Aux1": "misc"})
        before = [b.text() for b in panel._filter_buttons]
        assert "EEG (1)" in before
        assert "MISC (1)" in before
        # Apply an override: Aux1 becomes ECG
        panel.set_channel_types({"Fp1": "eeg", "Aux1": "ecg"})
        after = [b.text() for b in panel._filter_buttons]
        assert "EEG (1)" in after
        assert "ECG (1)" in after
        assert not any("MISC" in lbl for lbl in after)


class TestMpEnergyValidator:
    """``_validate_mp_energy`` clamps to [0, 100]; 100 is the
    'stop only at iteration cap' boundary and must NOT warn."""

    def _run(self, qt_gui, value):
        warned = []
        original = qt_gui._msg_warning
        qt_gui._msg_warning = lambda title, msg: warned.append((title, msg))
        try:
            qt_gui._pp["mp_energy"].setText(value)
            qt_gui._validate_mp_energy()
            return warned, qt_gui._pp["mp_energy"].text()
        finally:
            qt_gui._msg_warning = original

    def test_100_percent_accepted_no_warning(self, qt_gui):
        warned, text = self._run(qt_gui, "100")
        assert warned == []
        assert text == "100"

    def test_99_percent_accepted_no_warning(self, qt_gui):
        warned, text = self._run(qt_gui, "99")
        assert warned == []
        assert text == "99"

    def test_above_100_clamps_and_warns(self, qt_gui):
        warned, text = self._run(qt_gui, "101")
        assert len(warned) == 1
        assert text == "100"

    def test_negative_clamps_and_warns(self, qt_gui):
        warned, text = self._run(qt_gui, "-5")
        assert len(warned) == 1
        assert text == "0"

    def test_100_roundtrips_to_explained_energy_one(self, qt_gui):
        """``cfg["matching_pursuit"]["explained_energy"]`` becomes 1.0
        when the widget reads 100, matching the runner's contract that
        passes a tiny ``-r`` to empi for the iteration-cap-only case."""
        qt_gui._pp["mp_energy"].setText("100")
        cfg = qt_gui._collect_config()
        assert cfg["matching_pursuit"]["explained_energy"] == 1.0
