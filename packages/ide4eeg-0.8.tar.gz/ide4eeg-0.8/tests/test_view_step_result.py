"""Tests for the generic _view_step_result feature (Phase 5).

Each preprocessing step with a ``_STEP_SAVE_MAP`` entry gets a
header eye-icon button that opens the before/after snapshot pair
— either as a Svarog split view (when the jar is known) or as two
MNE interactive windows.  These tests run against the real Qt GUI
offscreen and exercise:

- **Header wiring**: every GUI step in ``_STEP_SAVE_MAP`` (via
  ``_GUI_TO_PIPELINE_STEPS``) has a ``_view_btn`` on its
  ``CollapsibleStep``, and steps outside the map don't.
- **Happy path**: when both snapshot files exist, dispatch picks
  Svarog when the jar is present, MNE otherwise.
- **Auto-remediate**: when snapshots don't exist, the save
  checkboxes for the target step and its preceding step are
  flipped on and the panel expands.
- **First-step case**: when the target is the first enabled step,
  the "before" snapshot is the input file itself.
- **Sample rate mismatch**: when ``_sample_rates_match`` returns
  False, dispatch falls back to MNE even if a Svarog jar exists.
"""

import os
import sys

import io
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ── GUI fixture (shared offscreen instance) ──────────────────────────

_qt_app = None
_qt_gui = None


def _get_qt_gui():
    global _qt_app, _qt_gui
    if _qt_gui is not None:
        return _qt_gui
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        _qt_app = QApplication.instance() or QApplication(sys.argv)
        from ide4eeg.gui import IDE4EEG_Qt
        _qt_gui = IDE4EEG_Qt()
    except Exception as e:
        pytest.skip(f"Cannot create Qt GUI: {e}")
    return _qt_gui


@pytest.fixture(scope="module")
def qt_gui():
    gui = _get_qt_gui()
    if gui is None:
        pytest.skip("Qt GUI not available")
    # Headless / offscreen safety: replace modal _msg_* with no-ops
    # that record their args.  Per project memory
    # (feedback_offscreen_qt_dialogs.md), QMessageBox.exec() blocks
    # the test thread on the offscreen platform.  Tests that want to
    # assert on dialog content can read gui._test_msgs.
    gui._test_msgs = []
    for name in ("_msg_info", "_msg_warning", "_msg_error"):
        def _record(title, text, _name=name, _gui=gui):
            _gui._test_msgs.append((_name, title, text))
        setattr(gui, name, _record)
    yield gui


# ── Header wiring ────────────────────────────────────────────────────


SAVEABLE_GUI_STEPS = [
    "trim", "select", "bad_channels", "montage",
    "ica", "artifacts", "mp_filter",
    # Gaze shares the artifacts step with the EEG-artifacts panel,
    # so its eye opens the same artifacts-marked snapshot.
    "gaze",
    # mp_decomposition has no -raw.fif snapshot (it writes a .db
    # book), but its eye still exists — it routes to the MP Book
    # Viewer instead of the generic before/after Svarog split.
    "mp_decomposition",
]


@pytest.mark.parametrize("step_key", SAVEABLE_GUI_STEPS)
def test_saveable_step_has_view_button(qt_gui, step_key):
    grp = dict(qt_gui._step_widgets)[step_key]
    assert grp._view_btn is not None, \
        f"step {step_key!r} has no view button"


def test_filtering_panel_has_view_button(qt_gui):
    """Phase 2 multi-instance: the filter panel's GUI key is now
    "filtering:<id>" rather than bare "filtering".  Look up the
    first filter panel by prefix and verify its view button."""
    matches = [(k, g) for k, g in qt_gui._step_widgets
               if k.startswith("filtering:")]
    assert matches, "no filtering panel in _step_widgets"
    _, grp = matches[0]
    assert grp._view_btn is not None, \
        "first filtering panel has no view button"


# ── _view_step_result dispatch ───────────────────────────────────────


def _fake_snapshot_tree(tmp_path, input_basename, suffixes,
                        monkeypatch=None):
    """Create a preprocessing/saved_steps tree with empty .fif files.

    Returns ``(preproc_dir, saved_dir)``.  Files are empty so they
    pass ``os.path.isfile`` but can't be read by MNE — so when
    *monkeypatch* is provided we also stub
    ``IDE4EEG_Qt._fif_matches_hash`` to always return True,
    short-circuiting the staleness check in ``_view_step_result``
    that would otherwise force an auto-run.
    """
    preproc = tmp_path / "preproc"
    saved = preproc / "saved_steps"
    saved.mkdir(parents=True)
    for suffix in suffixes:
        (saved / f"{input_basename}-{suffix}-raw.fif").write_bytes(b"")
    if monkeypatch is not None:
        from ide4eeg.gui import IDE4EEG_Qt
        monkeypatch.setattr(
            IDE4EEG_Qt, "_fif_matches_hash",
            staticmethod(lambda _path, _hash: True))
    return str(preproc), str(saved)


def _wire_fake_input(gui, tmp_path):
    """Give the GUI a dummy input file + a mocked preproc dir."""
    inp = tmp_path / "signal.raw"
    inp.write_bytes(b"")
    gui._input_edit.setText(str(inp))
    return str(inp)


def _filter_key(gui):
    """Phase 2: filtering panel keys are now ``"filtering:<id>"``.
    Return the first one in _step_widgets so tests stay portable
    across uuid changes."""
    return next(
        k for k, _ in gui._step_widgets if k.startswith("filtering:"))


def test_happy_path_dispatches_svarog_when_jar_present(
        qt_gui, tmp_path, monkeypatch):
    """With a Svarog jar and matching sample rates, dispatch picks Svarog."""
    inp = _wire_fake_input(qt_gui, tmp_path)
    basename = os.path.basename(inp)
    while "." in basename:
        basename = os.path.splitext(basename)[0]
    fkey = _filter_key(qt_gui)
    fid = fkey.partition(":")[2]
    preproc, saved = _fake_snapshot_tree(
        tmp_path, basename, ["trimmed", f"filtered-{fid}"], monkeypatch)

    # Enable trim + filtering, disable intermediate steps so
    # "trim" is the nearest preceding enabled save step.
    for k, _ in qt_gui._step_widgets:
        grp = dict(qt_gui._step_widgets)[k]
        if hasattr(grp, "setChecked"):
            grp.setChecked(k in ("trim", fkey))
    qt_gui._pp["save_trim"].setChecked(True)
    qt_gui._pp[f"save_{fkey}"].setChecked(True)

    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: preproc)
    from ide4eeg import gui as gui_mod
    monkeypatch.setattr(gui_mod, "_sample_rates_match",
                        lambda a, b: True)
    # Pretend a Svarog jar exists.
    fake_jar = tmp_path / "svarog.jar"
    fake_jar.write_bytes(b"")
    monkeypatch.setattr(qt_gui, "_svarog_jar", str(fake_jar))

    calls = {}

    def fake_launch(path, **kwargs):
        calls["svarog"] = (path, kwargs)

    def fake_mne(path, title=None):
        calls.setdefault("mne", []).append(path)

    monkeypatch.setattr(qt_gui, "_launch_svarog", fake_launch)
    monkeypatch.setattr(qt_gui, "_open_signal_file_in_mne", fake_mne)

    qt_gui._view_step_result(fkey)

    assert "svarog" in calls, f"expected Svarog dispatch, got {calls}"
    master, kwargs = calls["svarog"]
    assert master.endswith("-raw.fif") and "filtered" in master
    assert kwargs.get("split_signal", "").endswith("-trimmed-raw.fif")
    assert "mne" not in calls


def test_happy_path_falls_back_to_mne_when_no_jar(
        qt_gui, tmp_path, monkeypatch):
    inp = _wire_fake_input(qt_gui, tmp_path)
    basename = os.path.basename(inp)
    while "." in basename:
        basename = os.path.splitext(basename)[0]
    fkey = _filter_key(qt_gui)
    fid = fkey.partition(":")[2]
    preproc, _saved = _fake_snapshot_tree(
        tmp_path, basename, ["trimmed", f"filtered-{fid}"], monkeypatch)

    for k in ("trim", fkey):
        dict(qt_gui._step_widgets)[k].setChecked(True)
        qt_gui._pp[f"save_{k}"].setChecked(True)

    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: preproc)
    monkeypatch.setattr(qt_gui, "_svarog_jar", None)

    calls = {"mne": []}
    monkeypatch.setattr(
        qt_gui, "_open_signal_file_in_mne",
        lambda p, title=None: calls["mne"].append(p))
    monkeypatch.setattr(
        qt_gui, "_launch_svarog",
        lambda *a, **k: calls.setdefault("svarog", True))

    qt_gui._view_step_result(fkey)

    assert len(calls["mne"]) == 2
    assert calls["mne"][0].endswith("-trimmed-raw.fif")
    assert "filtered" in calls["mne"][1] and calls["mne"][1].endswith("-raw.fif")
    assert "svarog" not in calls


def test_sample_rate_mismatch_forces_mne(qt_gui, tmp_path, monkeypatch):
    inp = _wire_fake_input(qt_gui, tmp_path)
    basename = os.path.basename(inp)
    while "." in basename:
        basename = os.path.splitext(basename)[0]
    fkey = _filter_key(qt_gui)
    fid = fkey.partition(":")[2]
    preproc, _saved = _fake_snapshot_tree(
        tmp_path, basename, ["trimmed", f"filtered-{fid}"], monkeypatch)

    for k in ("trim", fkey):
        dict(qt_gui._step_widgets)[k].setChecked(True)
        qt_gui._pp[f"save_{k}"].setChecked(True)

    fake_jar = tmp_path / "svarog.jar"
    fake_jar.write_bytes(b"")
    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: preproc)
    monkeypatch.setattr(qt_gui, "_svarog_jar", str(fake_jar))
    from ide4eeg import gui as gui_mod
    monkeypatch.setattr(gui_mod, "_sample_rates_match",
                        lambda a, b: False)

    calls = {"mne": [], "svarog": []}
    monkeypatch.setattr(
        qt_gui, "_open_signal_file_in_mne",
        lambda p, title=None: calls["mne"].append(p))
    monkeypatch.setattr(
        qt_gui, "_launch_svarog",
        lambda *a, **k: calls["svarog"].append((a, k)))

    qt_gui._view_step_result(fkey)

    assert len(calls["mne"]) == 2
    assert not calls["svarog"], \
        "sample rate mismatch should bypass Svarog"


def test_mp_filter_skips_mp_decomposition_for_before(
        qt_gui, tmp_path, monkeypatch):
    """Regression: mp_decomposition has a forced ``save`` toggle in
    ``_pp`` (the MP book is mandatory), so a naive preceding-step
    walk would pick it up — but mp_decomposition has no ``-raw.fif``
    snapshot (it writes a ``.db`` book).  ``_suffix`` then returned
    ``None``, ``before_path`` was ``None``, and the freshness check
    failed every time → infinite eye-click loop on mp_filter.

    Now: the preceding-step walk filters out steps whose pipeline
    mapping has no ``_STEP_SAVE_MAP`` entry, so when only trim +
    mp_decomposition + mp_filter are enabled, the BEFORE pane
    correctly resolves to the trim snapshot.
    """
    inp = _wire_fake_input(qt_gui, tmp_path)
    basename = os.path.basename(inp)
    while "." in basename:
        basename = os.path.splitext(basename)[0]
    preproc, _saved = _fake_snapshot_tree(
        tmp_path, basename, ["trimmed", "mp-filtered"], monkeypatch)

    # Only trim + mp_decomposition + mp_filter enabled.
    for k, _ in qt_gui._step_widgets:
        grp = dict(qt_gui._step_widgets)[k]
        if hasattr(grp, "setChecked"):
            grp.setChecked(k in ("trim", "mp_decomposition", "mp_filter"))
    qt_gui._pp["save_trim"].setChecked(True)
    qt_gui._pp["save_mp_filter"].setChecked(True)

    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: preproc)
    monkeypatch.setattr(qt_gui, "_svarog_jar", None)

    calls = []
    monkeypatch.setattr(
        qt_gui, "_open_signal_file_in_mne",
        lambda p, title=None: calls.append(p))
    # If the bug regressed, the dispatch would be skipped and a
    # truncated run would be triggered instead — fail the test loudly.
    monkeypatch.setattr(
        qt_gui, "_run_and_view_step",
        lambda *a, **k: pytest.fail(
            "preceding-step walk picked an invalid step "
            "(probably mp_decomposition), forcing a re-run instead "
            "of opening the trim/mp-filter pair"))

    qt_gui._view_step_result("mp_filter")

    assert len(calls) == 2
    assert calls[0].endswith("-trimmed-raw.fif"), \
        f"BEFORE should be trim snapshot, got {calls[0]}"
    assert calls[1].endswith("-mp-filtered-raw.fif")


def test_first_step_uses_input_file_as_before(
        qt_gui, tmp_path, monkeypatch):
    """When the target is the first enabled step, 'before' is the input."""
    inp = _wire_fake_input(qt_gui, tmp_path)
    basename = os.path.basename(inp)
    while "." in basename:
        basename = os.path.splitext(basename)[0]
    preproc, _saved = _fake_snapshot_tree(
        tmp_path, basename, ["ica-cleaned"], monkeypatch)

    # Disable every step that comes before ICA so ICA is "first".
    # Phase 2: filter panels carry an ":<id>" suffix; match them by
    # prefix.
    pre_ica = ("trim", "select", "bad_channels", "montage", "resample")
    keys_before_ica = [
        k for k, _ in qt_gui._step_widgets
        if k in pre_ica or k.startswith("filtering:")
    ]
    for k in keys_before_ica:
        dict(qt_gui._step_widgets)[k].setChecked(False)
    dict(qt_gui._step_widgets)["ica"].setChecked(True)
    qt_gui._pp["save_ica"].setChecked(True)

    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: preproc)
    monkeypatch.setattr(qt_gui, "_svarog_jar", None)

    calls = []
    monkeypatch.setattr(
        qt_gui, "_open_signal_file_in_mne",
        lambda p, title=None: calls.append(p))

    qt_gui._view_step_result("ica")

    assert len(calls) == 2
    assert calls[0] == inp, \
        "first enabled step should use the input file as 'before'"
    assert calls[1].endswith("-ica-cleaned-raw.fif")


# ── Phase 6: run-to-step dispatch ────────────────────────────────────


def test_missing_snapshots_triggers_run_and_view(
        qt_gui, tmp_path, monkeypatch):
    """Clicking the eye with no snapshots routes into _run_and_view_step."""
    _wire_fake_input(qt_gui, tmp_path)
    preproc = tmp_path / "empty_preproc"
    (preproc / "saved_steps").mkdir(parents=True)
    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: str(preproc))
    qt_gui._polling_active = False

    captured = {}
    monkeypatch.setattr(
        qt_gui, "_run_and_view_step",
        lambda step_key, step_label: captured.setdefault(
            "args", (step_key, step_label)))

    qt_gui._view_step_result("ica")

    assert captured.get("args") == ("ica", "ICA")


def test_eye_click_bails_when_pipeline_running(
        qt_gui, tmp_path, monkeypatch):
    """An in-progress run blocks the eye click with a clear message."""
    _wire_fake_input(qt_gui, tmp_path)
    preproc = tmp_path / "empty_preproc"
    (preproc / "saved_steps").mkdir(parents=True)
    monkeypatch.setattr(qt_gui, "_fallback_preproc_path", lambda: str(preproc))
    qt_gui._polling_active = True

    called = {"run_and_view": 0}
    monkeypatch.setattr(
        qt_gui, "_run_and_view_step",
        lambda *a, **k: called.__setitem__("run_and_view",
                                           called["run_and_view"] + 1))

    shown = {}
    monkeypatch.setattr(
        qt_gui, "_msg_info",
        lambda title, msg: shown.setdefault("title", title))

    qt_gui._view_step_result("ica")

    qt_gui._polling_active = False
    assert called["run_and_view"] == 0
    assert "running" in shown.get("title", "").lower()


def test_run_and_view_always_uses_truncated_pipeline(
        qt_gui, tmp_path, monkeypatch):
    """Every eye click routes to the truncated pipeline, regardless
    of whether _cached_signal is populated (the old fast path was
    removed — unified on the pipeline for correctness)."""
    _wire_fake_input(qt_gui, tmp_path)
    calls = {"n": 0, "args": None}
    monkeypatch.setattr(
        qt_gui, "_run_truncated_pipeline",
        lambda sk, sl: (calls.__setitem__("n", calls["n"] + 1)
                        or calls.__setitem__("args", (sk, sl))))

    qt_gui._cached_signal = None
    qt_gui._run_and_view_step("ica", "ICA")
    assert calls["n"] == 1
    assert calls["args"] == ("ica", "ICA")

    qt_gui._cached_signal = object()  # populated cache no longer changes routing
    qt_gui._run_and_view_step("filtering", "Filters")
    assert calls["n"] == 2
    assert calls["args"] == ("filtering", "Filters")
    qt_gui._cached_signal = None


def test_slow_path_artifacts_truncates_and_launches(
        qt_gui, tmp_path, monkeypatch):
    """artifacts (not in preview chain) takes the slow path."""
    _wire_fake_input(qt_gui, tmp_path)
    for k in ("trim", "ica", "artifacts"):
        dict(qt_gui._step_widgets)[k].setChecked(True)

    captured_cfg = {}

    def fake_launch(cfg):
        captured_cfg.update(cfg)
        return True

    monkeypatch.setattr(qt_gui, "_launch_pipeline", fake_launch)

    qt_gui._pending_view_step_key = None
    qt_gui._run_truncated_pipeline("artifacts", "EEG artifacts")

    assert qt_gui._pending_view_step_key == "artifacts"
    step_order = captured_cfg.get("preprocessing", {}).get("step_order", [])
    assert step_order, "step_order must be non-empty"
    # GUI key "artifacts" maps to pipeline step "eeg_artifacts".
    assert step_order[-1] == "eeg_artifacts", \
        f"step_order should end at 'eeg_artifacts', got {step_order}"
    # Every analysis flag disabled
    for flag in qt_gui._ANALYSIS_FLAGS:
        assert captured_cfg.get(flag) is False, \
            f"{flag} must be disabled on slow path"
    # artifacts + preceding step save flags forced on
    assert captured_cfg.get("artifacts", {}).get("save") is True
    qt_gui._pending_view_step_key = None


def test_slow_path_launch_failure_clears_pending(qt_gui, tmp_path, monkeypatch):
    """If _launch_pipeline returns False, the pending flag is cleared."""
    _wire_fake_input(qt_gui, tmp_path)
    monkeypatch.setattr(qt_gui, "_launch_pipeline", lambda cfg: False)
    qt_gui._pending_view_step_key = None
    qt_gui._run_truncated_pipeline("artifacts", "EEG artifacts")
    assert qt_gui._pending_view_step_key is None


def test_slow_path_does_not_mutate_user_save_flags(
        qt_gui, tmp_path, monkeypatch):
    """Slow path works on a deepcopy; user GUI state is untouched."""
    _wire_fake_input(qt_gui, tmp_path)
    qt_gui._pp["save_artifacts"].setChecked(False)
    before = qt_gui._pp["save_artifacts"].isChecked()
    monkeypatch.setattr(qt_gui, "_launch_pipeline", lambda cfg: True)
    qt_gui._pending_view_step_key = None
    qt_gui._run_truncated_pipeline("artifacts", "EEG artifacts")
    assert qt_gui._pp["save_artifacts"].isChecked() == before
    qt_gui._pending_view_step_key = None


def test_truncate_step_order_unit():
    from ide4eeg.gui import IDE4EEG_Qt
    assert IDE4EEG_Qt._truncate_step_order(
        ["trim", "ica", "eeg_artifacts", "mp_filter"], "ica"
    ) == ["trim", "ica"]
    assert IDE4EEG_Qt._truncate_step_order(
        ["trim", "ica"], "eeg_artifacts") == []
    assert IDE4EEG_Qt._truncate_step_order([], "trim") == []


def test_on_pipeline_finished_consumes_pending_view(
        qt_gui, tmp_path, monkeypatch):
    """On success, pending_view_step_key re-enters _view_step_result."""
    qt_gui._pending_view_step_key = "ica"
    qt_gui._polling_active = True  # _on_pipeline_finished sets it False

    reentered = {}
    monkeypatch.setattr(
        qt_gui, "_view_step_result",
        lambda k, *, is_reentry=False: reentered.update(
            key=k, is_reentry=is_reentry))
    # Avoid side effects the finish handler normally takes:
    monkeypatch.setattr(qt_gui, "_refresh_output_tree", lambda: None)
    monkeypatch.setattr(qt_gui, "_auto_focus_latest_output", lambda: None)
    monkeypatch.setattr(qt_gui, "_poll_log_queue", lambda: None)

    qt_gui._on_pipeline_finished(True)
    # QTimer.singleShot(0, ...) requires processing the event loop.
    from PySide6.QtWidgets import QApplication
    for _ in range(5):
        QApplication.processEvents()

    assert reentered.get("key") == "ica"
    assert reentered.get("is_reentry") is True, \
        "loop guard should be armed when re-entering from finish"
    assert qt_gui._pending_view_step_key is None


def test_on_pipeline_finished_failure_clears_pending(
        qt_gui, tmp_path, monkeypatch):
    """On failure, the flag is cleared and the viewer is NOT re-entered."""
    qt_gui._pending_view_step_key = "ica"
    qt_gui._polling_active = True

    reentered = {"count": 0}
    monkeypatch.setattr(
        qt_gui, "_view_step_result",
        lambda k: reentered.__setitem__("count", reentered["count"] + 1))
    monkeypatch.setattr(qt_gui, "_show_pipeline_error", lambda e: None)
    monkeypatch.setattr(qt_gui, "_poll_log_queue", lambda: None)

    qt_gui._on_pipeline_finished(False)

    assert reentered["count"] == 0
    assert qt_gui._pending_view_step_key is None


def test_launch_svarog_appends_split_signal_flag(
        qt_gui, tmp_path, monkeypatch):
    """``_launch_svarog(split_signal=...)`` appends --split-signal."""
    import subprocess

    fake_jar = tmp_path / "svarog.jar"
    fake_jar.write_bytes(b"")
    master = tmp_path / "master.fif"
    master.write_bytes(b"")
    slave = tmp_path / "slave.fif"
    slave.write_bytes(b"")

    monkeypatch.setattr(qt_gui, "_svarog_jar", str(fake_jar))
    monkeypatch.setattr(qt_gui, "_detect_java_major", lambda: 17)

    captured = {}

    class _FakePopen:
        def __init__(self, cmd, **kwargs):
            captured["cmd"] = list(cmd)
            self.stderr = io.BytesIO(b"")
        def poll(self):
            return 0

    monkeypatch.setattr(subprocess, "Popen", _FakePopen)

    qt_gui._launch_svarog(str(master), split_signal=str(slave))

    cmd = captured["cmd"]
    assert "--split-signal" in cmd
    assert cmd[cmd.index("--split-signal") + 1] == str(slave)
    assert cmd[-1] == str(master), "master must be the final positional arg"


def test_output_double_click_routes_to_svarog_by_default(
        qt_gui, tmp_path, monkeypatch):
    """Double-click on a raw-type .fif in the Output tree opens
    Svarog when a jar is configured; MNE is the fallback.  Special
    FIF serializations (-epo.fif, -ica.fif) always go to MNE."""
    fake_jar = tmp_path / "svarog.jar"
    fake_jar.write_bytes(b"")
    monkeypatch.setattr(qt_gui, "_svarog_jar", str(fake_jar))

    calls = {"svarog": [], "mne": []}
    monkeypatch.setattr(
        qt_gui, "_launch_svarog",
        lambda path, **kw: calls["svarog"].append(path))
    monkeypatch.setattr(
        qt_gui, "_open_mne_raw",
        lambda path, title=None: calls["mne"].append(path))

    raw_fif = tmp_path / "signal-raw.fif"
    raw_fif.write_bytes(b"")
    epo_fif = tmp_path / "signal-epo.fif"
    epo_fif.write_bytes(b"")
    ica_fif = tmp_path / "signal-ica.fif"
    ica_fif.write_bytes(b"")

    def _dispatch(path):
        from PySide6.QtWidgets import QTreeWidgetItem
        item = QTreeWidgetItem([os.path.basename(path)])
        # _output_item_path reads item.toolTip(0) as the absolute path.
        item.setToolTip(0, str(path))
        qt_gui._output_tree.addTopLevelItem(item)
        qt_gui._output_tree.setCurrentItem(item)
        qt_gui._open_selected_output()
        qt_gui._output_tree.takeTopLevelItem(
            qt_gui._output_tree.indexOfTopLevelItem(item))

    _dispatch(raw_fif)
    assert calls["svarog"] == [str(raw_fif)], \
        "raw .fif with jar configured should go to Svarog"
    assert calls["mne"] == []

    _dispatch(epo_fif)
    assert calls["svarog"] == [str(raw_fif)], \
        "-epo.fif must not go to Svarog (Epochs serialization)"
    assert calls["mne"] == [str(epo_fif)]

    _dispatch(ica_fif)
    assert calls["svarog"] == [str(raw_fif)], \
        "-ica.fif must not go to Svarog (ICA serialization)"
    assert calls["mne"] == [str(epo_fif), str(ica_fif)]

    # Jar missing → raw .fif falls back to MNE.
    monkeypatch.setattr(qt_gui, "_svarog_jar", None)
    _dispatch(raw_fif)
    assert calls["svarog"] == [str(raw_fif)], \
        "Svarog should not be called when jar is missing"
    assert calls["mne"] == [str(epo_fif), str(ica_fif), str(raw_fif)]


def test_save_toggle_independent_of_step_enable(qt_gui):
    """The 🗄️ save toggle is strictly user-driven: toggling the
    step's enable checkbox must NOT cascade into the save toggle.

    Earlier (commit 9523d70 / 2026-04-24) save did follow step-enable,
    but that auto-sync leaked: ``_toggle_details`` auto-checks the
    step on click-to-expand, which then silently activated snapshot
    saves users hadn't asked for, leading to runs writing
    multi-gigabyte snapshot trees on disk.  Removed in 8682039 /
    2026-05-03 — see the comment in ``_add_save_checkbox`` at
    gui.py around the ``# NB:`` block, plus the
    ``feedback_save_toggle_meaning`` auto-memory.  This test locks
    that decision in: if anyone re-wires the auto-sync, this test
    fires.
    """
    widgets = dict(qt_gui._step_widgets)
    # bad_channels is a representative saveable + checkable step.
    grp = widgets["bad_channels"]
    if not grp.isCheckable():
        pytest.skip("bad_channels group isn't checkable in this build")
    save_btn = qt_gui._pp["save_bad_channels"]

    # Step OFF, save OFF: enabling step must NOT auto-flip save.
    grp.setChecked(False)
    save_btn.setChecked(False)
    grp.setChecked(True)
    assert not save_btn.isChecked(), \
        "enabling step must not auto-enable save (regression of 8682039)"

    # Step ON, save ON: disabling step must NOT clear save.
    save_btn.setChecked(True)
    grp.setChecked(False)
    assert save_btn.isChecked(), \
        "disabling step must not clear save (user-driven only)"

    # Independent direction: unchecking save must not touch step.
    grp.setChecked(True)
    save_btn.setChecked(False)
    assert grp.isChecked(), \
        "unchecking save must not affect step-enable state"
    assert not save_btn.isChecked()
