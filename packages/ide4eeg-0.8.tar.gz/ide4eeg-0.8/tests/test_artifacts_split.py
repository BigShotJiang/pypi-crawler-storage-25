"""Behaviour-lock tests for the artifacts-step split.

The unified ``artifacts`` pipeline step bundled two conceptually
independent detectors (EEG-based amplitude/slopes/outliers/muscles vs
video-based not-looking) and required a save-flag aliasing workaround
in the GUI to keep both panels' eye buttons resolving to the same
snapshot.  Commit ``ae83707`` split it into two pipeline steps:
``eeg_artifacts`` and ``gaze_artifacts``.

These tests lock in the invariants that justify the split:

* Both steps are first-class pipeline citizens.
* Each writes its own snapshot with a distinct suffix.
* Hash invalidation is per-step (a config edit only invalidates the
  step that consumes it and everything downstream).
* The cumulative state shape (``artifacts_occurrence`` /
  ``bad_event_positions``) is consistent regardless of which step
  ran last, so the postamble reads a single coherent dict.
* The GUI panels each drive their own pipeline step (no aliasing).
"""

import os
import sys
from unittest.mock import patch

import pytest

# Headless Qt for the GUI-side imports below.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ide4eeg.preprocessing.preprocessing import (  # noqa: E402
    STEP_REGISTRY,
    DEFAULT_STEP_ORDER,
    _STEP_SAVE_MAP,
    _STEP_CONFIG_DEPS,
    _STATE_POPULATING_STEPS,
    _step_eeg_artifacts,
    _step_gaze_artifacts,
    _compute_step_hash,
    effective_step_order,
)


# ────────────────────────────────────────────────────────────────────
# Registry / save-map / state shape
# ────────────────────────────────────────────────────────────────────

class TestRegistry:
    def test_both_steps_registered(self):
        assert "eeg_artifacts" in STEP_REGISTRY
        assert "gaze_artifacts" in STEP_REGISTRY

    def test_legacy_step_removed(self):
        assert "artifacts" not in STEP_REGISTRY, (
            "legacy unified `artifacts` step must be gone after the "
            "split — old TOML configs with that name should error out")

    def test_default_order_includes_both(self):
        assert "eeg_artifacts" in DEFAULT_STEP_ORDER
        assert "gaze_artifacts" in DEFAULT_STEP_ORDER

    def test_save_map_distinct_suffixes(self):
        # Each step writes to its own .fif so the eye buttons on both
        # GUI panels resolve to different files (no more aliasing).
        assert _STEP_SAVE_MAP["eeg_artifacts"] == (
            "artifacts", "eeg-artifacts-marked")
        assert _STEP_SAVE_MAP["gaze_artifacts"] == (
            "gaze", "gaze-marked")

    def test_state_populating_steps(self):
        # Resume-from-snapshot must NOT skip past either artifact step
        # (each populates state["artifacts_occurrence"] and
        # state["bad_event_positions"], not recoverable from a saved
        # FIF alone).
        assert "eeg_artifacts" in _STATE_POPULATING_STEPS
        assert "gaze_artifacts" in _STATE_POPULATING_STEPS


# ────────────────────────────────────────────────────────────────────
# Hash chain isolation — the whole point of per-step hashes
# ────────────────────────────────────────────────────────────────────

def _hash_cfg(step_order, **overrides):
    """Minimal config covering the deps of trim/eeg/gaze, plus
    whatever overrides the test wants to wedge in."""
    cfg = {
        "preprocessing": {"step_order": list(step_order)},
        "trim_start": 0,
        "trim_end": "",
        "artifacts": {
            "save": False,
            "artifact_threshold": 0.3,
            "rejection_parameters": {},
        },
        "amplitude_max_threshold": 0.0001,
        "amplitude_time_threshold": 0.02,
        "amplitude_nchan_threshold": 0.33,
        "gaze": {"save": False},
        "video_path": "",
        "video_reference_dir": "",
        "video_exclude_dir": "",
        "facetag_frame_skip": 3,
        "facetag_detection_skip": 3,
        "facetag_downscale": 1.0,
        "facetag_max_angle": 20.0,
        "facetag_ref_use_roi": False,
        "facetag_face_tolerance": 0.6,
        "facetag_min_interval": 0.0,
        "facetag_no_face_is_artifact": True,
        "facetag_tracking_adapt_rate": 0.5,
        "facetag_position_weight": 0.4,
        "facetag_size_weight": 0.2,
        "facetag_switch_resistance": 0.25,
        "facetag_backend": "insightface",
        "facetag_gaze_method": "l2cs",
        "facetag_gaze_smoothing": 0.0,
        "facetag_det_size": 0,
    }
    for k, v in overrides.items():
        cfg[k] = v
    return cfg


class TestHashIsolation:
    """Editing a step's deps invalidates that step + everything
    downstream — but never an upstream step's snapshot."""

    def test_eeg_dep_change_does_not_affect_upstream_trim(self):
        order = ["trim", "eeg_artifacts", "gaze_artifacts"]
        cfg_a = _hash_cfg(order)
        cfg_b = _hash_cfg(order)
        cfg_b["artifacts"]["artifact_threshold"] = 0.99
        assert (_compute_step_hash("trim", cfg_a, order)
                == _compute_step_hash("trim", cfg_b, order))

    def test_eeg_dep_change_propagates_downstream_to_gaze(self):
        # eeg before gaze in this order → gaze's chain hash includes
        # eeg's contribution, so editing eeg's deps changes gaze's
        # snapshot hash too (downstream invalidation by design).
        order = ["trim", "eeg_artifacts", "gaze_artifacts"]
        cfg_a = _hash_cfg(order)
        cfg_b = _hash_cfg(order)
        cfg_b["artifacts"]["artifact_threshold"] = 0.99
        assert (_compute_step_hash("eeg_artifacts", cfg_a, order)
                != _compute_step_hash("eeg_artifacts", cfg_b, order))
        assert (_compute_step_hash("gaze_artifacts", cfg_a, order)
                != _compute_step_hash("gaze_artifacts", cfg_b, order))

    def test_gaze_dep_change_does_not_invalidate_eeg(self):
        # gaze is downstream of eeg in this order → editing gaze's
        # deps must NOT touch eeg's hash (the whole point of the
        # split is independent invalidation).
        order = ["trim", "eeg_artifacts", "gaze_artifacts"]
        cfg_a = _hash_cfg(order)
        cfg_b = _hash_cfg(order, facetag_max_angle=999.0)
        assert (_compute_step_hash("eeg_artifacts", cfg_a, order)
                == _compute_step_hash("eeg_artifacts", cfg_b, order))
        assert (_compute_step_hash("gaze_artifacts", cfg_a, order)
                != _compute_step_hash("gaze_artifacts", cfg_b, order))

    def test_reorder_swaps_invalidation_relationship(self):
        # With gaze BEFORE eeg, editing eeg's deps no longer touches
        # gaze (eeg is now downstream of gaze).
        order = ["trim", "gaze_artifacts", "eeg_artifacts"]
        cfg_a = _hash_cfg(order)
        cfg_b = _hash_cfg(order)
        cfg_b["artifacts"]["artifact_threshold"] = 0.99
        assert (_compute_step_hash("gaze_artifacts", cfg_a, order)
                == _compute_step_hash("gaze_artifacts", cfg_b, order))
        assert (_compute_step_hash("eeg_artifacts", cfg_a, order)
                != _compute_step_hash("eeg_artifacts", cfg_b, order))


# ────────────────────────────────────────────────────────────────────
# Step wrappers populate cumulative state correctly
# ────────────────────────────────────────────────────────────────────

@pytest.fixture
def fake_state():
    """Bare-minimum pipeline state.

    Detectors are mocked, so signal/path/file_name need only be the
    types the wrappers pass through.
    """
    return {
        "signal": object(),  # mocked detector ignores it
        "config": _hash_cfg(["eeg_artifacts", "gaze_artifacts"]),
        "tags_desc_id": {"rest": 99},
        "path": "/tmp/no_such",
        "file_name": "fake",
        "ica": None,
        "artifacts_occurrence": {},
        "artifacts_description": [],
        "bad_event_positions": None,
        "_cancel_event": None,
    }


class TestStepWrappersCumulative:
    """Each wrapper merges into a cumulative dict and reruns
    ``_dirty_segment_ids`` so the postamble reads a coherent state."""

    def test_eeg_step_populates_only_eeg_keys(self, fake_state):
        with patch("ide4eeg.preprocessing.preprocessing._detect_eeg_artifacts",
                   return_value=({"outliers": "MASK_OUT",
                                  "slopes": "MASK_SLOPE"},
                                 [{"name": "outlier", "start_timestamp": 1.0,
                                   "end_timestamp": 1.5}])), \
             patch("ide4eeg.preprocessing.preprocessing._dirty_segment_ids",
                   return_value=[100, 200]):
            _step_eeg_artifacts(fake_state)
        assert set(fake_state["artifacts_occurrence"].keys()) == {
            "outliers", "slopes"}
        assert len(fake_state["artifacts_description"]) == 1
        assert fake_state["bad_event_positions"] == [100, 200]

    def test_gaze_step_appends_without_clobbering_eeg(self, fake_state):
        # Pre-seed as if eeg already ran.
        fake_state["artifacts_occurrence"] = {"outliers": "MASK_OUT"}
        fake_state["artifacts_description"] = [
            {"name": "outlier", "start_timestamp": 1.0,
             "end_timestamp": 1.5}]
        with patch("ide4eeg.preprocessing.preprocessing._detect_gaze_artifacts",
                   return_value=({"not_looking": "MASK_NL"},
                                 [{"name": "not_looking",
                                   "start_timestamp": 5.0,
                                   "end_timestamp": 6.0}])), \
             patch("ide4eeg.preprocessing.preprocessing._dirty_segment_ids",
                   return_value=[300]):
            _step_gaze_artifacts(fake_state)
        # Both detectors' results live in the same dict.
        assert set(fake_state["artifacts_occurrence"].keys()) == {
            "outliers", "not_looking"}
        # And the descriptions are appended, not overwritten.
        assert len(fake_state["artifacts_description"]) == 2
        # bad_event_positions is recomputed (no last-step coupling).
        assert fake_state["bad_event_positions"] == [300]

    def test_dirty_segment_ids_reruns_on_each_step(self, fake_state):
        """Per-step invariant: bad_event_positions reflects the
        cumulative state, regardless of which artifact step ran last.

        Counter the temptation to optimise away the second
        ``_dirty_segment_ids`` call — see
        ``project_artifacts_split.md`` design notes (option 1A)."""
        call_log = []

        def _record_call(*args, **kwargs):
            # Snapshot the dict — the same object is mutated by the
            # second step, so a bare reference would show the final
            # cumulative state on both calls.
            call_log.append(dict(args[2]))
            return [len(args[2])]  # one fake bad-id per detector key

        with patch("ide4eeg.preprocessing.preprocessing._detect_eeg_artifacts",
                   return_value=({"outliers": "M"}, [])), \
             patch("ide4eeg.preprocessing.preprocessing._detect_gaze_artifacts",
                   return_value=({"not_looking": "M"}, [])), \
             patch("ide4eeg.preprocessing.preprocessing._dirty_segment_ids",
                   side_effect=_record_call):
            _step_eeg_artifacts(fake_state)
            _step_gaze_artifacts(fake_state)

        assert len(call_log) == 2, "_dirty_segment_ids must rerun"
        # First call sees only EEG keys; second sees both.
        assert set(call_log[0].keys()) == {"outliers"}
        assert set(call_log[1].keys()) == {"outliers", "not_looking"}


# ────────────────────────────────────────────────────────────────────
# GUI mapping — both panels independently drive their own step
# ────────────────────────────────────────────────────────────────────

class TestGuiMapping:
    """The save-flag aliasing workaround (``_apply_save_aliases``) was
    deleted as part of the split.  Lock that in: each panel's GUI
    key now maps to its own pipeline step."""

    def test_gui_key_to_pipeline(self):
        from ide4eeg.gui import IDE4EEG_Qt
        assert IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS["gaze"] == [
            "gaze_artifacts"]
        assert IDE4EEG_Qt._GUI_TO_PIPELINE_STEPS["artifacts"] == [
            "eeg_artifacts"]

    def test_apply_save_aliases_is_gone(self):
        # The class-method lived on IDE4EEG_Qt; if anyone re-introduces
        # it, the split has effectively regressed.
        from ide4eeg.gui import IDE4EEG_Qt
        assert not hasattr(IDE4EEG_Qt, "_apply_save_aliases")


# ────────────────────────────────────────────────────────────────────
# effective_step_order no longer hides artifact steps via legacy flags
# ────────────────────────────────────────────────────────────────────

class TestEffectiveOrder:
    """``prepare_eeg_artifacts`` / ``prepare_video_artifacts`` no
    longer gate inclusion — step membership in ``step_order`` is
    authoritative.  Without this, the GUI-driven step_order would be
    silently filtered when those legacy flags weren't toggled."""

    def test_prepare_flags_do_not_drop_steps(self):
        cfg = _hash_cfg(
            ["trim", "eeg_artifacts", "gaze_artifacts"],
            prepare_eeg_artifacts=False,
            prepare_video_artifacts=False)
        order = effective_step_order(cfg)
        assert "eeg_artifacts" in order
        assert "gaze_artifacts" in order
