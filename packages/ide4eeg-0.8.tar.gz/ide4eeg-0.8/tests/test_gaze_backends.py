"""Tests for gaze estimation backends (InsightFace and L2CS-Net).

Verifies:
- L2CS-Net angle-to-vector conversion (pure geometry, no model)
- Vector normalization and edge cases
- API compatibility between backends
- Reference data gaze module dispatch
"""

import importlib.util

import numpy as np
import pytest

l2cs_available = importlib.util.find_spec("l2cs") is not None
if l2cs_available:
    try:
        import torch
        torch.from_numpy(np.array([1.0]))  # check NumPy bridge works
    except Exception:
        l2cs_available = False

insightface_available = (
    importlib.util.find_spec("insightface") is not None
    and importlib.util.find_spec("onnxruntime") is not None)


# ---------------------------------------------------------------------------
# Angle-to-vector conversion (l2cs_gaze._angles_to_vector)
# ---------------------------------------------------------------------------

class TestAnglesToVector:
    """Test the L2CS-Net yaw/pitch → 3D unit vector conversion."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from ide4eeg.preprocessing.facetag.l2cs_gaze import _angles_to_vector
        self.angles_to_vector = _angles_to_vector

    def test_looking_straight(self):
        """Yaw=0, pitch=0 should give a forward-pointing vector."""
        vec = self.angles_to_vector(0, 0)
        assert vec is not None
        # Z component should dominate (looking forward)
        assert vec[2] > 0.99
        # X and Y should be near zero
        assert abs(vec[0]) < 0.01
        assert abs(vec[1]) < 0.01

    def test_unit_length(self):
        """All outputs should be unit vectors."""
        for yaw in [-45, -20, 0, 20, 45]:
            for pitch in [-30, -10, 0, 10, 30]:
                vec = self.angles_to_vector(yaw, pitch)
                assert vec is not None
                np.testing.assert_almost_equal(np.linalg.norm(vec), 1.0, decimal=6)

    def test_yaw_right(self):
        """Positive yaw should point left (negative X in our convention)."""
        vec = self.angles_to_vector(30, 0)
        assert vec[0] < -0.3  # pointing left

    def test_yaw_left(self):
        """Negative yaw should point right (positive X)."""
        vec = self.angles_to_vector(-30, 0)
        assert vec[0] > 0.3

    def test_pitch_down(self):
        """Positive pitch should point up (negative Y in our convention)."""
        vec = self.angles_to_vector(0, 30)
        assert vec[1] < -0.3

    def test_pitch_up(self):
        """Negative pitch should point down (positive Y)."""
        vec = self.angles_to_vector(0, -30)
        assert vec[1] > 0.3

    def test_symmetry(self):
        """Opposite yaw/pitch should produce opposite X/Y components."""
        v1 = self.angles_to_vector(20, 10)
        v2 = self.angles_to_vector(-20, -10)
        np.testing.assert_almost_equal(v1[0], -v2[0], decimal=6)
        np.testing.assert_almost_equal(v1[1], -v2[1], decimal=6)
        np.testing.assert_almost_equal(v1[2], v2[2], decimal=6)

    def test_angle_recovery(self):
        """A small angular deviation should produce the expected angle."""
        ref = self.angles_to_vector(0, 0)
        dev = self.angles_to_vector(10, 0)
        angle = np.degrees(np.arccos(np.clip(np.dot(ref, dev), -1, 1)))
        assert abs(angle - 10) < 0.5  # within 0.5 degrees


# ---------------------------------------------------------------------------
# API compatibility between gaze backends
# ---------------------------------------------------------------------------

class TestGazeModuleAPI:
    """Verify all gaze backends expose the required interface."""

    _REQUIRED_ATTRS = ('analyze_gaze', 'nose_eyes_vector', 'reset_video_state')

    def test_insightface_module_api(self):
        from ide4eeg.preprocessing.facetag import insightface_gaze
        for attr in self._REQUIRED_ATTRS:
            assert hasattr(insightface_gaze, attr), f"missing {attr}"

    def test_l2cs_module_api(self):
        from ide4eeg.preprocessing.facetag import l2cs_gaze
        for attr in self._REQUIRED_ATTRS:
            assert hasattr(l2cs_gaze, attr), f"missing {attr}"

    def test_insightface_reset_is_noop(self):
        from ide4eeg.preprocessing.facetag.insightface_gaze import reset_video_state
        reset_video_state()  # should not raise

    def test_l2cs_reset_is_noop(self):
        from ide4eeg.preprocessing.facetag.l2cs_gaze import reset_video_state
        reset_video_state()  # should not raise


# ---------------------------------------------------------------------------
# analyze_gaze return contract
# ---------------------------------------------------------------------------

class TestAnalyzeGazeContract:
    """Both backends must return (vector_or_None, bool) from analyze_gaze."""

    def _check_return(self, mod):
        blank = np.zeros((224, 224, 3), dtype=np.uint8)
        result = mod.analyze_gaze(blank, timestamp_ms=0)
        assert isinstance(result, tuple) and len(result) == 2
        vec, eyes_closed = result
        assert vec is None or (hasattr(vec, 'shape') and vec.shape == (3,))
        assert isinstance(eyes_closed, bool)

    @pytest.mark.skipif(not insightface_available,
                        reason="insightface / onnxruntime not installed")
    def test_insightface_contract(self):
        """InsightFace analyze_gaze returns (vec|None, bool)."""
        from ide4eeg.preprocessing.facetag import insightface_gaze
        self._check_return(insightface_gaze)

    @pytest.mark.skipif(not l2cs_available,
                        reason="l2cs not installed or PyTorch/NumPy incompatible")
    def test_l2cs_contract(self):
        """L2CS analyze_gaze returns (vec|None, bool)."""
        from ide4eeg.preprocessing.facetag import l2cs_gaze
        self._check_return(l2cs_gaze)


# ---------------------------------------------------------------------------
# Gaze module dispatch in reference.py
# ---------------------------------------------------------------------------

class TestGazeDispatch:
    """Test that _get_gaze_module returns the correct backend."""

    def test_default_is_insightface(self):
        from ide4eeg.preprocessing.facetag.reference import _get_gaze_module
        from ide4eeg.preprocessing.facetag import insightface_gaze
        mod = _get_gaze_module("insightface")
        assert mod is insightface_gaze

    @pytest.mark.skipif(not l2cs_available,
                        reason="l2cs / torch not installed")
    def test_l2cs_dispatch(self):
        from ide4eeg.preprocessing.facetag.reference import _get_gaze_module
        from ide4eeg.preprocessing.facetag import l2cs_gaze
        mod = _get_gaze_module("l2cs")
        assert mod is l2cs_gaze

    def test_unknown_falls_back_to_insightface(self):
        from ide4eeg.preprocessing.facetag.reference import _get_gaze_module
        from ide4eeg.preprocessing.facetag import insightface_gaze
        mod = _get_gaze_module("unknown")
        assert mod is insightface_gaze


# ---------------------------------------------------------------------------
# Backend defaults (dlib removed)
# ---------------------------------------------------------------------------

class TestBackendDefaults:
    """Verify dlib is no longer in BACKEND_DEFAULTS."""

    def test_only_insightface(self):
        from ide4eeg.preprocessing.facetag.reference import BACKEND_DEFAULTS
        assert "insightface" in BACKEND_DEFAULTS
        assert "dlib" not in BACKEND_DEFAULTS

    def test_insightface_tolerance(self):
        from ide4eeg.preprocessing.facetag.reference import BACKEND_DEFAULTS
        assert BACKEND_DEFAULTS["insightface"]["face_tolerance"] == 0.4


# ---------------------------------------------------------------------------
# L2CS-Net model integration (only runs if l2cs is installed)
# ---------------------------------------------------------------------------

@pytest.mark.skipif(not l2cs_available, reason="l2cs not installed or PyTorch/NumPy incompatible")
class TestL2CSIntegration:
    """Integration tests that require the l2cs package."""

    def test_analyze_gaze_on_blank_image(self):
        """A blank image should return None (no face)."""
        from ide4eeg.preprocessing.facetag.l2cs_gaze import analyze_gaze
        blank = np.zeros((224, 224, 3), dtype=np.uint8)
        vec, eyes_closed = analyze_gaze(blank)
        # Either None (no face) or a vector — both are acceptable
        assert eyes_closed is False

    def test_nose_eyes_vector_on_blank(self):
        from ide4eeg.preprocessing.facetag.l2cs_gaze import nose_eyes_vector
        blank = np.zeros((224, 224, 3), dtype=np.uint8)
        result = nose_eyes_vector(blank)
        # May return None or a vector — should not crash
        if result is not None:
            assert result.shape == (3,)


# ---------------------------------------------------------------------------
# InsightFace gaze: pure geometry tests (no model needed)
# ---------------------------------------------------------------------------

class TestInsightFaceGazeVector:
    """Test _extract_vector_from_kps geometry (no InsightFace model)."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from ide4eeg.preprocessing.facetag.insightface_gaze import (
            _extract_vector_from_kps)
        self.extract = _extract_vector_from_kps

    def _make_kps(self, left_eye, right_eye, nose):
        """Build a (5, 2) array from eye and nose positions."""
        return np.array([
            left_eye, right_eye, nose,
            [0, 0], [0, 0],  # mouth corners (unused)
        ], dtype=np.float32)

    def test_frontal_face(self):
        """Symmetric frontal face: vector should point roughly up-forward."""
        kps = self._make_kps([80, 60], [120, 60], [100, 90])
        vec = self.extract(kps, (200, 200))
        assert vec is not None
        assert vec.shape == (3,)
        assert abs(np.linalg.norm(vec) - 1.0) < 1e-6
        # Nose is below eyes → y component should be negative (eyes above nose)
        assert vec[1] < 0

    def test_turned_right(self):
        """Eyes shifted right relative to nose → positive x."""
        kps = self._make_kps([90, 60], [130, 60], [100, 80])
        vec = self.extract(kps, (200, 200))
        assert vec is not None
        assert vec[0] > 0

    def test_turned_left(self):
        """Eyes shifted left relative to nose → negative x."""
        kps = self._make_kps([70, 60], [110, 60], [100, 80])
        vec = self.extract(kps, (200, 200))
        assert vec is not None
        assert vec[0] < 0

    def test_unit_length(self):
        """All outputs should be unit vectors."""
        for offset in [(0, 0), (20, 0), (-20, 0), (0, -10)]:
            kps = self._make_kps(
                [80 + offset[0], 60 + offset[1]],
                [120 + offset[0], 60 + offset[1]],
                [100, 90])
            vec = self.extract(kps, (200, 200))
            if vec is not None:
                assert abs(np.linalg.norm(vec) - 1.0) < 1e-6

    def test_degenerate_eyes_same_position(self):
        """Eyes at same position → inter-eye distance ~0 → None."""
        kps = self._make_kps([100, 60], [100, 60], [100, 90])
        vec = self.extract(kps, (200, 200))
        assert vec is None

    def test_extreme_angle_returns_none(self):
        """Very large displacement (r2 >= 1) → None."""
        # Nose at origin, eyes very far away
        kps = self._make_kps([10, 10], [20, 10], [100, 200])
        vec = self.extract(kps, (200, 200))
        # With inter-eye dist of 10 and displacement >> 10, r2 >= 1
        # (may or may not be None depending on exact geometry)
        if vec is not None:
            assert abs(np.linalg.norm(vec) - 1.0) < 1e-6

    def test_z_component_positive(self):
        """Forward-facing head should have positive z."""
        kps = self._make_kps([80, 60], [120, 60], [100, 90])
        vec = self.extract(kps, (200, 200))
        assert vec is not None
        assert vec[2] > 0


class TestInsightFaceGazeAPI:
    """Verify the InsightFace gaze module has the required interface."""

    def test_module_api(self):
        from ide4eeg.preprocessing.facetag import insightface_gaze
        assert hasattr(insightface_gaze, 'analyze_gaze')
        assert hasattr(insightface_gaze, 'nose_eyes_vector')
        assert hasattr(insightface_gaze, 'reset_video_state')

    def test_reset_is_noop(self):
        from ide4eeg.preprocessing.facetag.insightface_gaze import (
            reset_video_state)
        reset_video_state()  # should not raise

    def test_dispatch(self):
        from ide4eeg.preprocessing.facetag.reference import _get_gaze_module
        from ide4eeg.preprocessing.facetag import insightface_gaze
        mod = _get_gaze_module("insightface")
        assert mod is insightface_gaze
