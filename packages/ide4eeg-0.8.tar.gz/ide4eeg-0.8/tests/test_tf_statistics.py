"""Tests for time-frequency statistics pure functions.

Covers:
- erds_map(): ERD/ERS baseline normalization
- _ref_indices(): reference period to column indices
- _test_columns(): test region column indices
- fdr_correction(): FDR multiple comparison correction
- bh_correction(): Bonferroni-Holmes correction
- bonferroni_correction(): Bonferroni correction
- box_cox_transform(): Box-Cox normalizing transformation
- parametric_ttest(): parametric t-test
- welch_ttest(): Welch's t-test with Satterthwaite df
- check_normality(): Lilliefors normality test
"""

import numpy as np
import pytest

from ide4eeg.analysis.tf_statistics import (
    erds_map,
    _ref_indices,
    _test_columns,
    fdr_correction,
    bh_correction,
    bonferroni_correction,
    box_cox_transform,
    parametric_ttest,
    welch_ttest,
    check_normality,
    bootstrap_pseudo_t,
    permutation_test,
)


# ---------------------------------------------------------------------------
# _ref_indices
# ---------------------------------------------------------------------------

class TestRefIndices:
    def test_basic(self):
        t = np.array([0.0, 0.5, 1.0, 1.5, 2.0, 2.5])
        idx = _ref_indices(t, 0.0, 1.5)
        np.testing.assert_array_equal(idx, [0, 1, 2])

    def test_no_match(self):
        t = np.array([0.0, 0.5, 1.0])
        idx = _ref_indices(t, 5.0, 6.0)
        assert len(idx) == 0

    def test_single_point(self):
        t = np.array([0.0, 1.0, 2.0])
        idx = _ref_indices(t, 1.0, 1.5)
        np.testing.assert_array_equal(idx, [1])

    def test_end_exclusive(self):
        t = np.array([0.0, 1.0, 2.0, 3.0])
        idx = _ref_indices(t, 0.0, 2.0)
        # t=2.0 should NOT be included (< not <=)
        np.testing.assert_array_equal(idx, [0, 1])


# ---------------------------------------------------------------------------
# _test_columns
# ---------------------------------------------------------------------------

class TestTestColumns:
    def test_basic(self):
        # 10 time columns, ref=[0,1,2], no margin
        cols = _test_columns(10, np.array([0, 1, 2]), 0)
        assert cols == list(range(3, 10))

    def test_with_margin(self):
        cols = _test_columns(10, np.array([0, 1, 2]), 2)
        assert cols == list(range(3, 8))

    def test_empty_ref(self):
        cols = _test_columns(10, np.array([]), 0)
        assert cols == list(range(0, 10))


# ---------------------------------------------------------------------------
# erds_map
# ---------------------------------------------------------------------------

class TestErdsMap:
    def test_shape(self):
        # 5 trials, 3 freq, 8 time
        maps = np.ones((5, 3, 8))
        ref_idx = np.array([0, 1, 2])
        result = erds_map(maps, ref_idx)
        assert result.shape == (3, 8)

    def test_uniform_signal_gives_zero_erds(self):
        """If all energy is the same, ERDS should be 0 everywhere."""
        maps = np.ones((5, 3, 8)) * 2.0
        ref_idx = np.array([0, 1, 2])
        result = erds_map(maps, ref_idx)
        # Post-reference columns should be 0 (no change from baseline)
        np.testing.assert_allclose(result[:, 3:], 0.0, atol=1e-10)

    def test_reference_columns_zero(self):
        """Reference and pre-reference columns should always be 0."""
        maps = np.random.rand(5, 3, 8)
        ref_idx = np.array([0, 1, 2])
        result = erds_map(maps, ref_idx)
        np.testing.assert_array_equal(result[:, :3], 0.0)

    def test_erd_is_negative(self):
        """Power decrease should give negative ERDS (desynchronization)."""
        maps = np.ones((5, 3, 8)) * 10.0
        # Make post-reference energy lower
        maps[:, :, 3:] = 5.0
        ref_idx = np.array([0, 1, 2])
        result = erds_map(maps, ref_idx)
        assert np.all(result[:, 3:] < 0)

    def test_ers_is_positive(self):
        """Power increase should give positive ERDS (synchronization)."""
        maps = np.ones((5, 3, 8)) * 5.0
        maps[:, :, 3:] = 10.0
        ref_idx = np.array([0, 1, 2])
        result = erds_map(maps, ref_idx)
        assert np.all(result[:, 3:] > 0)


# ---------------------------------------------------------------------------
# fdr_correction
# ---------------------------------------------------------------------------

class TestFDRCorrection:
    def test_all_nonsignificant(self):
        """All p=1 → nothing accepted."""
        p = np.ones((3, 8))
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = fdr_correction(p, q=0.05, ref_idx=ref_idx)
        assert not np.any(accepted)

    def test_returns_correct_shape(self):
        p = np.random.rand(4, 10) * 0.5
        ref_idx = np.array([0, 1])
        accepted, adj_p = fdr_correction(p, q=0.05, ref_idx=ref_idx)
        assert accepted.shape == (4, 10)
        assert adj_p.shape == (4, 10)

    def test_very_small_p_accepted(self):
        """Very small p-values should be accepted."""
        p = np.ones((3, 8))
        p[1, 5] = 1e-10  # one very significant cell
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = fdr_correction(p, q=0.05, ref_idx=ref_idx)
        assert accepted[1, 5]

    def test_no_test_columns(self):
        """If ref covers everything, no tests → nothing accepted."""
        p = np.ones((3, 4))
        ref_idx = np.array([0, 1, 2, 3])
        accepted, adj_p = fdr_correction(p, q=0.05, ref_idx=ref_idx)
        assert not np.any(accepted)


# ---------------------------------------------------------------------------
# bh_correction
# ---------------------------------------------------------------------------

class TestBHCorrection:
    def test_all_nonsignificant(self):
        p = np.ones((3, 8))
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = bh_correction(p, alpha=0.05, ref_idx=ref_idx)
        assert not np.any(accepted)

    def test_very_small_p_accepted(self):
        p = np.ones((3, 8))
        p[1, 5] = 1e-10
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = bh_correction(p, alpha=0.05, ref_idx=ref_idx)
        assert accepted[1, 5]


# ---------------------------------------------------------------------------
# bonferroni_correction
# ---------------------------------------------------------------------------

class TestBonferroniCorrection:
    def test_all_nonsignificant(self):
        p = np.ones((3, 8))
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = bonferroni_correction(
            p, alpha=0.05, ref_idx=ref_idx)
        assert not np.any(accepted)

    def test_very_small_p_accepted(self):
        p = np.ones((3, 8))
        p[1, 5] = 1e-10
        ref_idx = np.array([0, 1, 2])
        accepted, adj_p = bonferroni_correction(
            p, alpha=0.05, ref_idx=ref_idx)
        assert accepted[1, 5]

    def test_bonferroni_is_most_conservative(self):
        """Bonferroni should accept fewer or equal resels compared to FDR."""
        rng = np.random.default_rng(42)
        p = rng.uniform(0, 0.1, (5, 20))
        ref_idx = np.array([0, 1, 2])
        acc_fdr, _ = fdr_correction(p, q=0.05, ref_idx=ref_idx)
        acc_bonf, _ = bonferroni_correction(
            p, alpha=0.05, ref_idx=ref_idx)
        assert np.sum(acc_bonf) <= np.sum(acc_fdr)


# ---------------------------------------------------------------------------
# Box-Cox transformation
# ---------------------------------------------------------------------------

class TestBoxCox:
    """Tests for box_cox_transform (Żygierewicz et al. 2005)."""

    def test_output_shape(self):
        """Transformed data has the same shape as input."""
        rng = np.random.default_rng(42)
        data = rng.exponential(1.0, (10, 4, 20))
        ref_idx = np.array([0, 1, 2, 3])
        transformed, lambdas = box_cox_transform(data, ref_idx)
        assert transformed.shape == data.shape
        assert lambdas.shape == (4,)

    def test_lambda_per_frequency(self):
        """Each frequency bin gets its own λ."""
        rng = np.random.default_rng(42)
        data = rng.exponential(1.0, (20, 3, 15))
        ref_idx = np.array([0, 1, 2])
        _, lambdas = box_cox_transform(data, ref_idx)
        assert len(lambdas) == 3
        # Lambdas should be finite
        assert np.all(np.isfinite(lambdas))

    def test_normalization_improves(self):
        """Box-Cox should make exponential data closer to normal."""
        from scipy.stats import kstest
        rng = np.random.default_rng(42)
        # Exponential data (highly non-normal)
        data = rng.exponential(2.0, (30, 1, 10))
        ref_idx = np.array([0, 1, 2, 3, 4])

        # Before transform
        raw = data[:, 0, ref_idx].ravel()
        _, p_raw = kstest(raw, "norm",
                          args=(np.mean(raw), np.std(raw, ddof=1)))

        # After transform
        transformed, _ = box_cox_transform(data, ref_idx)
        bc = transformed[:, 0, ref_idx].ravel()
        _, p_bc = kstest(bc, "norm",
                         args=(np.mean(bc), np.std(bc, ddof=1)))

        # Box-Cox p-value should be higher (more normal)
        assert p_bc >= p_raw


# ---------------------------------------------------------------------------
# Parametric t-test
# ---------------------------------------------------------------------------

class TestParametricTtest:
    """Tests for parametric_ttest."""

    def test_output_shape(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (15, 5, 20))
        ref_idx = np.array([0, 1, 2, 3])
        p_map = parametric_ttest(data, ref_idx)
        assert p_map.shape == (5, 20)

    def test_reference_columns_are_one(self):
        """p-values in reference period should remain 1.0 (not tested)."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (15, 3, 10))
        ref_idx = np.array([0, 1, 2])
        p_map = parametric_ttest(data, ref_idx)
        # Parametric test only fills post-reference
        np.testing.assert_array_equal(p_map[:, ref_idx], 1.0)

    def test_detects_large_shift(self):
        """A large mean shift should produce small p-values."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (30, 1, 10))
        # Add large shift to column 8
        data[:, 0, 8] += 5.0
        ref_idx = np.array([0, 1, 2, 3])
        p_map = parametric_ttest(data, ref_idx)
        assert p_map[0, 8] < 0.001

    def test_no_shift_gives_high_p(self):
        """No shift should produce high p-values."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (30, 1, 10))
        ref_idx = np.array([0, 1, 2, 3])
        p_map = parametric_ttest(data, ref_idx)
        # Most post-reference p-values should be > 0.05
        post = p_map[0, 4:]
        assert np.mean(post > 0.05) >= 0.5


# ---------------------------------------------------------------------------
# Welch's t-test
# ---------------------------------------------------------------------------

class TestWelchTtest:
    """Tests for welch_ttest."""

    def test_output_shape(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (15, 5, 20))
        ref_idx = np.array([0, 1, 2, 3])
        p_map = welch_ttest(data, ref_idx)
        assert p_map.shape == (5, 20)

    def test_detects_shift_with_unequal_variance(self):
        """Should detect shifts even when variances differ."""
        rng = np.random.default_rng(42)
        # Reference: low variance; test: high variance + shift
        data = rng.normal(0, 0.5, (30, 1, 10))
        data[:, 0, 8] = rng.normal(3.0, 2.0, 30)
        ref_idx = np.array([0, 1, 2, 3])
        p_map = welch_ttest(data, ref_idx)
        assert p_map[0, 8] < 0.01

    def test_consistent_with_parametric(self):
        """With equal variances, Welch ≈ standard t-test."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (30, 2, 10))
        data[:, :, 7] += 3.0
        ref_idx = np.array([0, 1, 2])
        p_param = parametric_ttest(data, ref_idx)
        p_welch = welch_ttest(data, ref_idx)
        # Should be close (not identical due to df correction)
        np.testing.assert_allclose(p_param[0, 7], p_welch[0, 7],
                                   atol=0.01)


# ---------------------------------------------------------------------------
# Normality testing
# ---------------------------------------------------------------------------

class TestNormality:
    """Tests for check_normality."""

    def test_normal_data_passes(self):
        """Normal data should pass the Lilliefors test."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (50, 3, 10))
        ref_idx = np.array([0, 1, 2, 3])
        pass_map = check_normality(data, ref_idx)
        # Most frequency bins should pass
        assert np.sum(pass_map) >= 2

    def test_exponential_data_fails(self):
        """Exponential data should fail the normality test."""
        rng = np.random.default_rng(42)
        data = rng.exponential(1.0, (50, 3, 10))
        ref_idx = np.array([0, 1, 2, 3])
        pass_map = check_normality(data, ref_idx)
        # Most frequency bins should fail
        assert np.sum(~pass_map) >= 2


class TestJoblibParallelPaths:
    """Smoke tests for the joblib-backed stat paths.

    These functions were migrated from a custom ProcessPoolExecutor
    to joblib.Parallel on 2026-04-14. The rewrite uses joblib's
    auto-memmap and inherits n_jobs / inner_max_num_threads from the
    global parallel_config set up by ide4eeg.main._configure_parallelism.

    The tests here run the full parallel path with tiny n_rep so the
    suite stays fast, but they exercise the joblib dispatch, the
    worker function signature, and the per-frequency-row seeding.
    They are the regression tests for the thread-oversubscription
    bug that hung a 16-core machine before the joblib migration.

    **Backend override:** these tests wrap each call in
    ``parallel_config(backend="threading", n_jobs=2)``. In the full
    test suite, a prior test may have already called
    ``ide4eeg.main._configure_parallelism`` (leaving a global loky
    pool around), and sharing that persistent pool across pytest
    test functions is brittle on macOS (BrokenProcessPool from
    worker inheritance / Qt state). Threading backend avoids that
    entirely and still exercises the joblib.Parallel dispatch and
    the worker signature, which is what we want to regression-test.
    Production code always goes through loky via the global
    parallel_config set by the pipeline; that path is covered by
    the integration tests, not here.
    """

    def _make_data(self, n_trials=30, n_freq=4, n_time=10, seed=0):
        rng = np.random.default_rng(seed)
        data = rng.normal(0.0, 1.0, (n_trials, n_freq, n_time))
        ref_idx = np.array([0, 1, 2, 3])
        return data, ref_idx

    @staticmethod
    def _parallel_ctx():
        import joblib
        # Threading backend can't accept inner_max_num_threads (it
        # shares the parent's thread pool). For bit-exact results we
        # rely on threadpoolctl pinning BLAS in the parent process.
        import threadpoolctl
        threadpoolctl.threadpool_limits(1, user_api="blas")
        return joblib.parallel_config(backend="threading", n_jobs=2)

    def test_bootstrap_pseudo_t_shape_and_ranges(self):
        data, ref_idx = self._make_data()
        with self._parallel_ctx():
            p_map = bootstrap_pseudo_t(data, ref_idx, n_rep=500)
        assert p_map.shape == (data.shape[1], data.shape[2])
        assert np.all(p_map >= 1.0 / 500 - 1e-12)
        assert np.all(p_map <= 1.0)
        # Reference columns are floored at 1 by construction
        assert np.all(p_map[:, ref_idx] >= p_map[:, ref_idx[0]])

    def test_bootstrap_pseudo_t_determinism(self):
        """Same input + master seed 42 → bit-exact p_map across runs."""
        data, ref_idx = self._make_data()
        with self._parallel_ctx():
            p1 = bootstrap_pseudo_t(data, ref_idx, n_rep=500)
        with self._parallel_ctx():
            p2 = bootstrap_pseudo_t(data, ref_idx, n_rep=500)
        np.testing.assert_array_equal(p1, p2)

    def test_permutation_test_shape_and_ranges(self):
        data, ref_idx = self._make_data(n_time=8)
        with self._parallel_ctx():
            p_map = permutation_test(data, ref_idx, n_rep=200)
        assert p_map.shape == (data.shape[1], data.shape[2])
        assert np.all(p_map >= 1.0 / 200 - 1e-12)
        assert np.all(p_map <= 1.0)

    def test_permutation_test_determinism(self):
        data, ref_idx = self._make_data(n_time=8)
        with self._parallel_ctx():
            p1 = permutation_test(data, ref_idx, n_rep=200)
        with self._parallel_ctx():
            p2 = permutation_test(data, ref_idx, n_rep=200)
        np.testing.assert_array_equal(p1, p2)
