"""Contract tests for readmanager's lazy MNE-bridge API.

These tests pin the surface that IDE4EEG depends on for memory-bounded
loading of long ``.raw`` recordings.  They skip cleanly when running
against an older readmanager that doesn't expose the lazy bridge yet,
so they're safe to land before the readmanager 1.5+ release.

When readmanager 1.5+ is the minimum dependency, drop the skip
guards and the suite becomes a hard contract.

Spec lives in ``../readmanager/LAZY_BRIDGE_SPEC.md`` (forwarded to the
readmanager maintainer).  Anything below that fails on a future
readmanager release means the bridge regressed and our trim widget
will silently fall back to eager loading on long recordings.
"""

import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _has_lazy_bridge():
    """True iff readmanager exposes ``get_mne_raw(preload=False)``
    returning a real ``mne.io.BaseRaw`` subclass."""
    try:
        from obci_readmanager.signal_processing.read_manager import ReadManager
        import inspect
        sig = inspect.signature(ReadManager.get_mne_raw)
        return "preload" in sig.parameters
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _has_lazy_bridge(),
    reason="readmanager < 1.5 — no get_mne_raw(preload=False)")


def _example_raw_files():
    """Return (xml_path, raw_path, tag_path) for an example .raw file
    from the bundled examples, or skip if none available."""
    repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        os.path.join(repo, "examples", "tfstat_data", "dataset_I.obci"),
        os.path.join(repo, "examples", "dipole_spindles",
                     "dipoles_example"),
    ]
    for base in candidates:
        if (os.path.isfile(base + ".xml")
                and os.path.isfile(base + ".raw")):
            tag = base + ".tag" if os.path.isfile(base + ".tag") else ""
            return base + ".xml", base + ".raw", tag
    pytest.skip("no example .obci.raw + .xml available in repo")


# ── Lazy construction ──────────────────────────────────────────────

def test_get_mne_raw_preload_false_returns_baseraw_subclass():
    """The lazy path must return a real MNE BaseRaw subclass — not a
    RawArray (which holds the entire materialised array in memory).
    """
    import mne
    from obci_readmanager.signal_processing.read_manager import ReadManager
    xml, raw, tag = _example_raw_files()
    mgr = ReadManager(xml, raw, tag)
    rmne = mgr.get_mne_raw(preload=False)
    assert isinstance(rmne, mne.io.BaseRaw), \
        f"expected BaseRaw subclass, got {type(rmne)}"
    assert not rmne.preload, \
        "raw.preload should be False for the lazy bridge"


def test_get_data_partial_does_not_materialise_full_signal():
    """Slicing the lazy Raw must not pull the entire signal into
    memory.  We can't directly observe RAM usage, but we can verify
    the Raw object's internal _data buffer stays None / unset."""
    from obci_readmanager.signal_processing.read_manager import ReadManager
    xml, raw, tag = _example_raw_files()
    mgr = ReadManager(xml, raw, tag)
    rmne = mgr.get_mne_raw(preload=False)
    # MNE's BaseRaw stores a NoneType _data when preload=False.
    assert getattr(rmne, "_data", None) is None or not rmne.preload
    # Slicing should work without changing preload state.
    n = rmne.n_times
    sl = rmne.get_data(start=0, stop=min(500, n))
    assert sl.shape[1] == min(500, n), \
        f"expected {min(500, n)} samples, got {sl.shape}"
    assert sl.shape[0] == len(rmne.ch_names), \
        f"channel count mismatch"


def test_get_data_returns_correct_slice_data():
    """Compare a small slice from the lazy Raw against the same slice
    pulled via the eager path — they must be byte-identical (modulo
    units conversion: MNE wants Volts; readmanager's microvolt path
    multiplies by 1e-6 internally)."""
    from obci_readmanager.signal_processing.read_manager import ReadManager
    xml, raw, tag = _example_raw_files()
    mgr_lazy = ReadManager(xml, raw, tag)
    rmne_lazy = mgr_lazy.get_mne_raw(preload=False)
    n = min(500, rmne_lazy.n_times)
    sl_lazy = rmne_lazy.get_data(start=0, stop=n)

    mgr_eager = ReadManager(xml, raw, tag)
    rmne_eager = mgr_eager.get_mne_raw()  # default = eager
    sl_eager = rmne_eager.get_data(start=0, stop=n)

    np.testing.assert_allclose(
        sl_lazy, sl_eager, rtol=1e-6,
        err_msg="lazy slice differs from eager slice — bridge mis-applies "
                "gain/offset or reads the wrong samples")


def test_get_data_with_picks_returns_correct_slice():
    """``get_data(picks=..., start=..., stop=...)`` must agree with
    the eager path channel-for-channel.  The trim viewer hits this code
    path on every paint (it queries ~16 EEG picks for a 20-second
    window), so a broadcasting bug here makes the GUI crash.

    Regression: an earlier bridge applied ``cals`` to the full unsliced
    block before the pick, which broadcasted fine when no picks were
    supplied (cals length matched block channels) but failed loudly
    when picks shrank the cals array — the GUI saw
    ``ValueError: operands could not be broadcast together with shapes
    (32,5120) (16,1) (32,5120)``.
    """
    from obci_readmanager.signal_processing.read_manager import ReadManager
    import mne
    xml, raw, tag = _example_raw_files()
    mgr_lazy = ReadManager(xml, raw, tag)
    rmne_lazy = mgr_lazy.get_mne_raw(preload=False)
    if len(rmne_lazy.ch_names) < 2:
        pytest.skip("example file too small to subset")
    # Pick the first EEG channel only — guarantees cals length (1)
    # differs from total channel count, which is what triggers the
    # broadcast bug.  Falls back to the first channel of any type
    # if no EEG is present (still differs from total ≥ 2).
    eeg_picks = mne.pick_types(rmne_lazy.info, eeg=True)
    picks = [int(eeg_picks[0])] if len(eeg_picks) else [0]
    n = min(500, rmne_lazy.n_times)
    sl_lazy = rmne_lazy.get_data(picks=picks, start=0, stop=n)

    mgr_eager = ReadManager(xml, raw, tag)
    rmne_eager = mgr_eager.get_mne_raw()
    sl_eager = rmne_eager.get_data(picks=picks, start=0, stop=n)

    assert sl_lazy.shape == sl_eager.shape, \
        f"shape mismatch: lazy {sl_lazy.shape} vs eager {sl_eager.shape}"
    np.testing.assert_allclose(
        sl_lazy, sl_eager, rtol=1e-6,
        err_msg="lazy picks-slice differs from eager — bridge mis-applies "
                "cals/picks ordering")


# ── Annotation propagation through MNE's crop ──────────────────────

def test_crop_shifts_annotations_relative_to_new_start():
    """After ``raw.crop(tmin, tmax)``, every annotation onset should
    be in ``[0, tmax-tmin]`` — MNE's standard behaviour, which works
    automatically iff the bridge populated ``annotations=`` on the
    BaseRaw subclass.

    This is the test that catches "lazy bridge constructed wrongly,
    annotations stored separately, MNE's crop can't see them."
    """
    from obci_readmanager.signal_processing.read_manager import ReadManager
    xml, raw, tag = _example_raw_files()
    mgr = ReadManager(xml, raw, tag)
    rmne = mgr.get_mne_raw(preload=False)
    if len(rmne.annotations) == 0:
        pytest.skip("example file has no tags/annotations")
    dur = rmne.times[-1]
    if dur < 5.0:
        pytest.skip("example file too short to crop meaningfully")
    tmin, tmax = 0.0, min(dur, 5.0)
    rmne.crop(tmin=tmin, tmax=tmax)
    assert len(rmne.annotations) > 0, \
        "all annotations dropped by crop — should keep ones in window"
    for onset, duration, desc in zip(
            rmne.annotations.onset,
            rmne.annotations.duration,
            rmne.annotations.description):
        assert -1e-6 <= onset <= (tmax - tmin) + 1e-6, \
            f"annotation '{desc}' onset {onset} not in [0, {tmax-tmin}] " \
            f"after crop — bridge didn't hand annotations to MNE properly"


# ── Deep-copy preserves laziness (mne.io.Raw.copy regression) ──────


def test_copy_preserves_lazy_data_source():
    """``mne.io.Raw.copy()`` deep-copies the BaseRaw including its
    backing readmanager.  The default ``DataSource.__deepcopy__``
    calls ``get_samples()`` with no args — a full file read — which
    silently materialises the entire signal on every ``raw.copy()``.

    Regression: on a multi-hour ``.raw`` recording the trim widget's
    ``signal.copy().crop(tmin, tmax)`` triggered a ~3.7 GB load before
    the crop even ran, defeating lazy I/O and thrashing on low-RAM
    machines.  ``FileDataSource`` now overrides ``__deepcopy__`` to
    rebuild a fresh lazy source pointing at the same file path.

    This test verifies the override is in place.
    """
    from obci_readmanager.signal_processing.read_manager import ReadManager
    from obci_readmanager.signal_processing.signal.read_data_source \
        import FileDataSource, MemoryDataSource
    import copy as _copy

    xml, raw_path, tag = _example_raw_files()
    mgr = ReadManager(xml, raw_path, tag)
    rmne = mgr.get_mne_raw(preload=False)
    assert isinstance(mgr.data_source, FileDataSource)
    assert mgr.data_source._mem_source is None, \
        "fresh FileDataSource should not have cached samples yet"

    # The critical operation: deep-copy the lazy Raw.
    rmne_copy = rmne.copy()

    # Original must remain lazy.
    src_orig = rmne._raw_extras[0]['mgr'].data_source
    assert isinstance(src_orig, FileDataSource), \
        "original data_source converted away from FileDataSource"
    assert src_orig._mem_source is None, \
        "original data_source materialised by deepcopy — bug regressed"

    # Copy must also remain lazy and point at the same file.
    src_copy = rmne_copy._raw_extras[0]['mgr'].data_source
    assert isinstance(src_copy, FileDataSource), \
        f"copied data_source converted to {type(src_copy).__name__} — " \
        f"deepcopy materialised the file"
    assert src_copy._mem_source is None, \
        "copied data_source materialised by deepcopy — bug regressed"
    assert src_copy.file_path == src_orig.file_path, \
        "copied data_source points at a different file"

    # And it serves slice reads correctly.
    sl = rmne_copy.get_data(start=0, stop=min(500, rmne_copy.n_times))
    assert sl.shape[1] == min(500, rmne_copy.n_times)


# ── Sanity: the eager path still works (backward compat) ───────────

def test_eager_path_unchanged():
    """``get_mne_raw()`` (no preload arg) must still return a working
    MNE Raw.  This protects existing IDE4EEG callers that haven't
    migrated to the lazy path yet."""
    from obci_readmanager.signal_processing.read_manager import ReadManager
    xml, raw, tag = _example_raw_files()
    mgr = ReadManager(xml, raw, tag)
    rmne = mgr.get_mne_raw()
    n = min(500, rmne.n_times)
    sl = rmne.get_data(start=0, stop=n)
    assert sl.shape[1] == n
