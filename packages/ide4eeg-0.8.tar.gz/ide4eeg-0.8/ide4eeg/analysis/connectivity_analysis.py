### Maciej Kamiński

"""Brain connectivity analysis for IDE4EEG.

Computes and plots directed and undirected connectivity measures between
EEG channels using MVAR (Multivariate Autoregressive) models and
spectral methods.

Based on ConnectiviPy by Dominik Krzemiński and Maciej Kamiński
(University of Warsaw), developed during Google Summer of Code 2015
under the International Neuroinformatics Coordinating Facility (INCF).
https://github.com/dokato/connectivipy
Integrated into IDE4EEG.

Original ConnectiviPy input formats: numpy arrays (k×N single-trial or
k×N×trials multi-trial), SignalML .raw files, and MATLAB .mat files.
In IDE4EEG the input is MNE Epochs objects converted to numpy arrays.

References:

  Kamiński M, Blinowska KJ (1991) "A new method of the description of
  the information flow in the brain structures." Biol Cybern 65:203–210.
  https://doi.org/10.1007/BF00198091

  Baccalá LA, Sameshima K (2001) "Partial directed coherence: a new
  concept in neural structure determination." Biol Cybern 84:463–474.
  https://doi.org/10.1007/PL00007990

  Blinowska KJ, Kuś R, Kamiński M (2004) "Granger causality and
  information flow in multivariate processes." Phys Rev E 70:050902.
  https://doi.org/10.1103/PhysRevE.70.050902
"""

# first integration into ide4eeg: Claude, 2026

import logging
import os

import matplotlib.pyplot as plt
import numpy as np

from .connectivity import Mvar, conn_estim_dc
from .connectivity.conn import ConnectAR

from . import _safe_tag


# Methods that require MVAR fitting
_AR_METHODS = {"dtf", "gdtf", "ffdtf", "ddtf", "pdc", "gpdc",
               "ipdc", "idtf", "pcoh"}
_SIGNAL_METHODS = {"coh", "psi", "gci", "aec"}

METHOD_LABELS = {
    "dtf": "DTF", "gdtf": "gDTF", "ffdtf": "ffDTF", "ddtf": "dDTF",
    "idtf": "iDTF",
    "pdc": "PDC", "gpdc": "gPDC", "ipdc": "iPDC",
    "pcoh": "Partial Coherence",
    "coh": "Coherency", "psi": "PSI", "gci": "GCI", "aec": "AEC",
}

# Frequency bands for ConnectiVIS .dat export — one .dat per
# (method × band) pair so the user can scrub through bands in 3D.
# Defined locally rather than reusing aec/utils.py:FQ_BANDS so AEC
# behaviour stays untouched (delta isn't in the AEC band list).
# "fullband" uses an infinite upper bound so the export averages
# every bin up to Nyquist — handy as a summary alongside the
# per-band slices.
# Edit here to change the export bands without affecting AEC.
_CONNECTIVIS_BANDS = {
    "fullband":   (0,  float("inf")),
    "delta":      (1,  4),
    "theta":      (6,  7),
    "alpha":      (8,  13),
    "beta":       (15, 25),
    "low-gamma":  (30, 45),
    "high-gamma": (55, 70),
}


def connectivity_analysis(rest, epochs, config, path, file_name):
    """Run connectivity analysis on preprocessed data.

    Parameters
    ----------
    rest : mne.Epochs or None
        Clean rest segments.
    epochs : mne.Epochs or None
        Clean event-related epochs.
    config : dict
        Pipeline configuration.
    path : str
        Output directory.
    file_name : str
        Base file name for output files.
    """
    conn_cfg = config.get("connectivity", {})
    raw_methods = conn_cfg.get("methods", "gdtf")
    if isinstance(raw_methods, str):
        raw_methods = raw_methods.split(",")
    methods = [m.strip().lower() for m in raw_methods if m.strip()]
    mvar_method = conn_cfg.get("mvar_method", "yw").lower()
    mvar_order = int(conn_cfg.get("mvar_order", 0))
    resolution = int(conn_cfg.get("resolution", 100))

    # Short-time connectivity options
    short_time = conn_cfg.get("short_time", False)
    st_window = conn_cfg.get("st_window", 0)    # 0 = auto (N/5)
    st_overlap = conn_cfg.get("st_overlap", 0)   # 0 = auto (N/10)

    # Significance testing options
    significance = conn_cfg.get("significance", False)
    sig_reps = int(conn_cfg.get("sig_reps", 100))
    sig_alpha = float(conn_cfg.get("sig_alpha", 0.05))

    # Channel selection: "all", comma-separated string, or list of names
    ch_sel = conn_cfg.get("channels", "all")
    if isinstance(ch_sel, str):
        if ch_sel.strip().lower() == "all":
            pick_channels = None  # use all
        else:
            pick_channels = [c.strip() for c in ch_sel.split(",") if c.strip()]
    elif isinstance(ch_sel, list):
        pick_channels = [str(c).strip() for c in ch_sel if str(c).strip()]
        if not pick_channels:
            pick_channels = None
    else:
        pick_channels = None

    out_dir = os.path.join(path, "connectivity_analysis")
    os.makedirs(out_dir, exist_ok=True)

    base = os.path.splitext(file_name)[0]

    # Count total work units for progress reporting
    tasks = []
    for data_obj, label in [(rest, "rest"), (epochs, "epochs")]:
        if data_obj is None:
            continue
        for tag in data_obj.event_id:
            tag_epochs = data_obj[tag]
            # Pick selected channels
            if pick_channels is not None:
                avail = tag_epochs.info["ch_names"]
                valid = [ch for ch in pick_channels if ch in avail]
                if not valid:
                    logging.warning(
                        "Connectivity: none of the selected channels found "
                        "in data for tag '%s'. Available: %s. Skipping.",
                        tag, ", ".join(avail[:20]))
                    continue
                dropped = [ch for ch in pick_channels if ch not in avail]
                if dropped:
                    logging.warning(
                        "Connectivity: channels not in data (ignored): %s",
                        ", ".join(dropped))
                tag_epochs = tag_epochs.pick(valid, verbose=False)
                logging.info(
                    "Connectivity: using %d/%d channels for tag '%s'",
                    len(valid), len(avail), tag)
            tasks.append((tag_epochs, tag, label))

    # Each task produces: standard methods + optional short-time + optional significance
    steps_per_task = len(methods)
    if short_time:
        steps_per_task += len(methods)
    if significance:
        steps_per_task += len(methods)
    total = len(tasks) * steps_per_task
    done = 0

    for tag_epochs, tag, label in tasks:
        done = _run_connectivity(
            tag_epochs, tag, label, methods,
            mvar_method, mvar_order, resolution,
            short_time, st_window, st_overlap,
            significance, sig_reps, sig_alpha,
            out_dir, base,
            done, total)

    # Electrode positions for ConnectiVIS (MNI mm)
    try:
        signal_info = (rest.info if rest is not None
                       else epochs.info if epochs is not None
                       else None)
        if signal_info is not None:
            elec_path = os.path.join(
                out_dir, f"{base}___electrodes.dat")
            if not os.path.isfile(elec_path):
                from .dipole.visualize import export_electrodes_dat
                export_electrodes_dat(signal_info, elec_path)
    except Exception as exc:
        logging.warning("Electrode export failed: %s", exc)


def _run_connectivity(tag_epochs, tag, data_label, methods,
                      mvar_method, mvar_order, resolution,
                      short_time, st_window, st_overlap,
                      significance, sig_reps, sig_alpha,
                      out_dir, base,
                      done=0, total=0):
    """Compute connectivity for one tag's epochs.

    Returns updated *done* counter for progress tracking.
    """
    ch_names = tag_epochs.info["ch_names"]
    sfreq = tag_epochs.info["sfreq"]
    n_channels = len(ch_names)

    logging.info("Connectivity: loading data for tag '%s' (%s), %d channels",
                 tag, data_label, n_channels)
    data_3d = tag_epochs.get_data()
    n_epochs, k, n_times = data_3d.shape

    n_methods = len(methods)
    steps = n_methods
    if short_time:
        steps += n_methods
    if significance:
        steps += n_methods

    if n_epochs == 0:
        logging.warning("Connectivity: no epochs for tag '%s'.", tag)
        return done + steps

    if n_epochs == 1:
        signal = data_3d[0]
    else:
        signal = np.transpose(data_3d, (1, 2, 0))

    order = mvar_order
    if order == 0:
        logging.info("Connectivity: estimating MVAR order (AIC)...")
        p_max = min(10, max(1, n_times // k - 1))
        order, _ = Mvar.order_akaike(signal, p_max=p_max,
                                     method=mvar_method)
        logging.info("Connectivity: auto MVAR order = %d (AIC)", order)

    if n_times <= k * order:
        logging.warning(
            "Connectivity: insufficient data points (%d) for %d channels "
            "× order %d. Skipping tag '%s'.",
            n_times, k, order, tag)
        return done + steps

    ar_needed = any(m in _AR_METHODS for m in methods)
    acoef = vcoef = None
    mvar_fit_failed = False
    if ar_needed:
        logging.info("Connectivity: fitting MVAR(%d) for '%s' (%s), "
                     "%d ch × %d pts...",
                     order, tag, data_label, k, n_times)
        # Wrap the fit so a singular / ill-conditioned signal (rank-
        # deficient after avg-reference + dead channels, all-zero
        # segment, etc.) doesn't abort the whole tag — only the
        # AR-needing methods get skipped; signal-based methods (coh,
        # psi, gci, aec) can still run.
        try:
            acoef, vcoef = Mvar.fit(signal, order=order, method=mvar_method)
            logging.info("Connectivity: MVAR fitted.")
        except (np.linalg.LinAlgError, ValueError, RuntimeError) as exc:
            logging.error(
                "Connectivity: MVAR fit failed for '%s' (%s): %s. "
                "AR-based methods (DTF/PDC/etc.) will be skipped for "
                "this tag; signal-based methods will still run.",
                tag, data_label, exc)
            mvar_fit_failed = True

    # Short-time window parameters (0 = auto)
    nfft = int(st_window * sfreq) if st_window > 0 else None
    no = int(st_overlap * sfreq) if st_overlap > 0 else None

    # Capture every successful method's result so we can emit one
    # ConnectiVIS .dat per (method × band) at the end of this scope.
    computed_results = []  # list of (method_key, result)

    # ── Standard connectivity ────────────────────────────────────────
    for method_key in methods:
        if method_key not in conn_estim_dc:
            logging.warning("Connectivity: unknown method '%s'.", method_key)
            done += 1
            continue
        if mvar_fit_failed and method_key in _AR_METHODS:
            done += 1
            continue

        done += 1
        label = METHOD_LABELS.get(method_key, method_key.upper())
        pct = done * 100 // total if total else 0
        logging.info("Connectivity: %d/%d (%d%%) computing %s for '%s'...",
                     done, total, pct, label, tag)

        try:
            result = _compute_method(method_key, signal, acoef, vcoef,
                                     sfreq, resolution)
            computed_results.append((method_key, result))

            logging.info("Connectivity: plotting %s for '%s'...", label, tag)
            _plot_connectivity(
                result, method_key, ch_names, sfreq, resolution,
                tag, data_label, out_dir, base)

        except Exception as exc:
            logging.error(
                "Connectivity: %s failed for '%s': %s",
                method_key.upper(), tag, exc, exc_info=True)

    # ── Significance testing ─────────────────────────────────────────
    if significance:
        for method_key in methods:
            if method_key not in conn_estim_dc:
                done += 1
                continue
            if mvar_fit_failed and method_key in _AR_METHODS:
                done += 1
                continue

            done += 1
            label = METHOD_LABELS.get(method_key, method_key.upper())
            pct = done * 100 // total if total else 0
            logging.info(
                "Connectivity: %d/%d (%d%%) significance %s for '%s' "
                "(%d reps, α=%.2f)...",
                done, total, pct, label, tag, sig_reps, sig_alpha)

            try:
                sig_values = _compute_significance(
                    method_key, signal, mvar_method, order,
                    sfreq, resolution, sig_reps, sig_alpha)

                _plot_significance(
                    sig_values, method_key, ch_names,
                    tag, data_label, out_dir, base)

            except Exception as exc:
                logging.error(
                    "Connectivity: significance %s failed for '%s': %s",
                    method_key.upper(), tag, exc, exc_info=True)

    # ── Short-time connectivity ──────────────────────────────────────
    if short_time:
        for method_key in methods:
            if method_key not in conn_estim_dc:
                done += 1
                continue
            if mvar_fit_failed and method_key in _AR_METHODS:
                done += 1
                continue

            done += 1
            label = METHOD_LABELS.get(method_key, method_key.upper())
            pct = done * 100 // total if total else 0
            logging.info(
                "Connectivity: %d/%d (%d%%) short-time %s for '%s'...",
                done, total, pct, label, tag)

            try:
                st_result = _compute_short_time(
                    method_key, signal, mvar_method, order,
                    sfreq, resolution, nfft, no)

                _plot_short_time(
                    st_result, method_key, ch_names, sfreq, n_times,
                    tag, data_label, out_dir, base)

            except Exception as exc:
                logging.error(
                    "Connectivity: short-time %s failed for '%s': %s",
                    method_key.upper(), tag, exc, exc_info=True)

    # ── Export ConnectiVIS .dat per (method × band) ─────────────────
    # Standard connectivity only — significance and short-time results
    # have different shapes (CI matrices, k×k×T tensors) and need a
    # separate export scheme; left as PNG-only for now.
    # TODO(connectivity export): also emit .dat for significance-
    #     thresholded matrices and short-time series so ConnectiVIS
    #     can show only-significant arrows + animate over time.
    for method_key, result in computed_results:
        # AEC's result axis 0 is already band-organized (n_AEC_bands,
        # k, k) — averaging across that axis with a Hz-based mask
        # would mis-label the output (the rows aren't frequency bins).
        # Skip AEC from this loop; AEC users read the PNG plots
        # directly.  TODO: per-AEC-band .dat export with the correct
        # row→band mapping from FQ_BANDS in aec/utils.py.
        if method_key == "aec":
            logging.info(
                "Connectivity: %s result for '%s' is band-organized, "
                "not frequency-resolved — skipping per-band .dat "
                "export (PNG plots still produced).",
                method_key.upper(), tag)
            continue
        if result.ndim != 3:
            logging.warning(
                "Connectivity: %s result for '%s' is not "
                "frequency-resolved (ndim=%d) — skipping ConnectiVIS "
                "band export.",
                method_key.upper(), tag, result.ndim)
            continue
        n_freqs = result.shape[0]
        freqs = np.linspace(0, sfreq / 2, n_freqs)
        for band_name, (lo, hi) in _CONNECTIVIS_BANDS.items():
            # Skip bands whose upper bound exceeds Nyquist — except
            # the fullband sentinel (hi = inf), where the mask just
            # naturally caps at the highest available bin.
            if not np.isinf(hi) and hi > sfreq / 2:
                logging.info(
                    "Connectivity: skipping %s band [%g–%g Hz] for "
                    "'%s' — exceeds Nyquist (%g Hz).",
                    band_name, lo, hi, tag, sfreq / 2)
                continue
            try:
                _export_connectivis(
                    result, method_key, ch_names, freqs,
                    band_name, (lo, hi),
                    tag, data_label, out_dir, base)
            except Exception as exc:
                logging.error(
                    "Connectivity: ConnectiVIS export %s/%s failed "
                    "for '%s': %s",
                    method_key.upper(), band_name, tag, exc,
                    exc_info=True)

    return done


def _export_connectivis(result, method_key, ch_names, freqs,
                        band_name, band_range,
                        tag, data_label, out_dir, base):
    """Export a band-averaged connectivity matrix to ConnectiVIS .dat.

    ``result`` is the (n_freqs, k, k) frequency-resolved matrix.
    ``freqs`` is the matching frequency axis (length n_freqs).
    ``band_range`` is ``(lo_hz, hi_hz)``; the matrix is averaged over
    frequency bins falling in that range.  Empty bands are skipped
    by the caller.
    """
    label = METHOD_LABELS.get(method_key, method_key.upper())
    lo, hi = band_range
    mask = (freqs >= lo) & (freqs <= hi)
    if not mask.any():
        logging.info(
            "Connectivity: %s band [%g–%g Hz] has no frequency bins "
            "at this resolution — skipping export.",
            band_name, lo, hi)
        return
    mean_conn = np.mean(np.abs(result[mask]), axis=0)

    if np.isinf(hi):
        band_descr = f"{band_name} (whole spectrum, {lo:g} Hz to Nyquist)"
    else:
        band_descr = f"{band_name} [{lo:g}-{hi:g} Hz]"

    # Self-describing title for ConnectiVIS to display in its
    # window/legend — combines method, band, and analysis tag.
    # TODO: needs ConnectiVIS reader support to actually surface
    #       the ;title line in the UI; until then it's harmless
    #       metadata.  Coordinate with the ConnectiVIS author.
    title = f"{label} · {band_descr} · {tag} · {data_label}"

    k = len(ch_names)
    lines = [
        f";title = {title}",
        ";electrodes = " + " ".join(ch_names),
        f";band = {band_descr}",
        ";start = 0.000000",
        ";samplerate = 1",
        "",
    ]
    for i in range(k):
        row = "  " + "   ".join(f"{mean_conn[i, j]:.4f}" for j in range(k))
        lines.append(row)

    fname = (f"{base}___{_safe_tag(tag)}_{data_label}_"
             f"{method_key}_{band_name}.dat")
    fpath = os.path.join(out_dir, fname)
    with open(fpath, "w") as f:
        f.write("\r\n".join(lines) + "\r\n")
    logging.info("Connectivity: exported ConnectiVIS file %s (%s, %s)",
                 fname, label, band_name)


def _compute_method(method_key, signal, acoef, vcoef, sfreq, resolution):
    """Compute a single connectivity method, returning the result array."""
    estimator = conn_estim_dc[method_key]()

    # Signal-based methods expect 2D (channels, samples).
    # Multi-epoch data is 3D (channels, samples, epochs) — concatenate.
    sig2d = signal
    if signal.ndim == 3:
        sig2d = signal.reshape(signal.shape[0], -1)

    if method_key in _AR_METHODS:
        return estimator.calculate(acoef, vcoef, sfreq,
                                   resolution=resolution)
    elif method_key == "coh":
        return estimator.calculate(sig2d, cnfft=resolution * 2,
                                   cno=resolution // 2)
    elif method_key == "psi":
        return estimator.calculate(sig2d, psinfft=resolution * 2,
                                   psino=resolution // 2)
    elif method_key == "gci":
        return estimator.calculate(sig2d)
    elif method_key == "aec":
        return estimator.calculate(sig2d, sfreq)
    else:
        raise ValueError(f"Unknown method '{method_key}'")


def _compute_significance(method_key, signal, mvar_method, order,
                          sfreq, resolution, n_reps, alpha):
    """Run surrogate/bootstrap significance testing for a method.

    Returns the significance threshold array (k, k) or (2, k, k).
    """
    estimator = conn_estim_dc[method_key]()

    if isinstance(estimator, ConnectAR):
        return estimator.significance(
            signal, method=mvar_method, order=order,
            resolution=resolution, Nrep=n_reps, alpha=alpha,
            fs=sfreq, verbose=False)
    else:
        # Signal-based: surrogate for single-trial, bootstrap for
        # multi-trial.  AEC.calculate requires fs as a positional
        # arg; forward it as a kwarg so Connect.bootstrap/surrogate
        # passes it through **params.
        kwargs = {"fs": sfreq} if method_key == "aec" else {}
        if signal.ndim > 2:
            return estimator.bootstrap(
                signal, Nrep=n_reps, alpha=alpha, verbose=False, **kwargs)
        else:
            return estimator.surrogate(
                signal, Nrep=n_reps, alpha=alpha, verbose=False, **kwargs)


def _compute_short_time(method_key, signal, mvar_method, order,
                        sfreq, resolution, nfft, no):
    """Compute short-time (sliding window) connectivity.

    Returns array of shape (time_points, frequencies, k, k).
    """
    estimator = conn_estim_dc[method_key]()

    if isinstance(estimator, ConnectAR):
        return estimator.short_time(
            signal, nfft=nfft, no=no, mvarmethod=mvar_method,
            order=order, resol=resolution, fs=sfreq)
    else:
        # Signal-based short-time
        kwargs = {}
        if method_key == "coh":
            kwargs = {"cnfft": resolution * 2, "cno": resolution // 2}
        elif method_key == "psi":
            kwargs = {"psinfft": resolution * 2, "psino": resolution // 2}
        elif method_key == "aec":
            kwargs = {"fs": sfreq}
        return estimator.short_time(signal, nfft=nfft, no=no, **kwargs)


# ══════════════════════════════════════════════════════════════════════
#  Plotting
# ══════════════════════════════════════════════════════════════════════

def _plot_connectivity(result, method_key, ch_names, sfreq, resolution,
                       tag, data_label, out_dir, base):
    """Plot connectivity matrix and save to file."""
    label = METHOD_LABELS.get(method_key, method_key.upper())
    k = len(ch_names)

    if method_key == "aec":
        mean_conn = np.mean(np.abs(result), axis=0)
        _plot_matrix(mean_conn, ch_names, f"{label} (mean bands)",
                     tag, data_label, out_dir, base, method_key)
    elif method_key == "gci":
        _plot_matrix(np.abs(result[0]), ch_names, label,
                     tag, data_label, out_dir, base, method_key)
    else:
        mean_conn = np.mean(np.abs(result), axis=0)
        _plot_matrix(mean_conn, ch_names, f"{label} (mean freq)",
                     tag, data_label, out_dir, base, method_key)

        _plot_frequency(result, ch_names, sfreq, label,
                        tag, data_label, out_dir, base, method_key)


def _plot_matrix(matrix, ch_names, title, tag, data_label,
                 out_dir, base, method_key):
    """Plot a k×k connectivity matrix as a heatmap."""
    k = len(ch_names)
    fig, ax = plt.subplots(figsize=(max(6, k * 0.6), max(5, k * 0.5)))
    im = ax.imshow(matrix, cmap="hot_r", aspect="equal",
                   vmin=0, vmax=np.max(matrix) if np.max(matrix) > 0 else 1)
    ax.set_xticks(range(k))
    ax.set_yticks(range(k))
    ax.set_xticklabels(ch_names, rotation=45, ha="right", fontsize=7)
    ax.set_yticklabels(ch_names, fontsize=7)
    ax.set_xlabel("From")
    ax.set_ylabel("To")
    ax.set_title(f"{title} — {tag} ({data_label})")
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout()

    fname = f"{base}___{_safe_tag(tag)}_{data_label}_{method_key}_matrix.png"
    fig.savefig(os.path.join(out_dir, fname), dpi=150)
    plt.close(fig)


def _plot_frequency(result, ch_names, sfreq, title, tag, data_label,
                    out_dir, base, method_key):
    """Plot frequency-resolved connectivity for all channel pairs."""
    res, k, _ = result.shape
    freqs = np.linspace(0, sfreq / 2, res)

    fig, axes = plt.subplots(k, k, figsize=(max(10, k * 2), max(8, k * 1.5)),
                             squeeze=False)
    for i in range(k):
        for j in range(k):
            ax = axes[i, j]
            ax.plot(freqs, np.abs(result[:, i, j]), linewidth=0.8)
            ax.set_ylim(0, None)
            if i == k - 1:
                ax.set_xlabel("Hz", fontsize=6)
            else:
                ax.set_xticklabels([])
            if j == 0:
                ax.set_ylabel(ch_names[i], fontsize=6)
            if i == 0:
                ax.set_title(ch_names[j], fontsize=6)
            ax.tick_params(labelsize=5)

    fig.suptitle(f"{title} — {tag} ({data_label})", fontsize=10)
    fig.tight_layout()

    fname = f"{base}___{_safe_tag(tag)}_{data_label}_{method_key}_freq.png"
    fig.savefig(os.path.join(out_dir, fname), dpi=150)
    plt.close(fig)


def _plot_significance(sig_values, method_key, ch_names,
                       tag, data_label, out_dir, base):
    """Plot significance threshold matrix as a heatmap."""
    label = METHOD_LABELS.get(method_key, method_key.upper())
    k = len(ch_names)

    # sig_values is (k, k) for one-sided or (2, k, k) for two-sided
    if sig_values.ndim == 3:
        # Two-sided: plot upper threshold
        matrix = sig_values[1]
        title_suffix = "upper threshold"
    else:
        matrix = sig_values
        title_suffix = "threshold"

    fig, ax = plt.subplots(figsize=(max(6, k * 0.6), max(5, k * 0.5)))
    vmax = np.max(matrix) if np.max(matrix) > 0 else 1
    im = ax.imshow(matrix, cmap="YlOrRd", aspect="equal",
                   vmin=0, vmax=vmax)
    ax.set_xticks(range(k))
    ax.set_yticks(range(k))
    ax.set_xticklabels(ch_names, rotation=45, ha="right", fontsize=7)
    ax.set_yticklabels(ch_names, fontsize=7)
    ax.set_xlabel("From")
    ax.set_ylabel("To")
    ax.set_title(f"{label} significance {title_suffix} — {tag} ({data_label})")
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout()

    fname = f"{base}___{_safe_tag(tag)}_{data_label}_{method_key}_significance.png"
    fig.savefig(os.path.join(out_dir, fname), dpi=150)
    plt.close(fig)


def _plot_short_time(st_result, method_key, ch_names, sfreq, n_times,
                     tag, data_label, out_dir, base):
    """Plot short-time connectivity as time-frequency image grids."""
    label = METHOD_LABELS.get(method_key, method_key.upper())
    k = len(ch_names)

    # st_result: (time_points, frequencies, k, k)
    n_win, n_freq = st_result.shape[:2]

    fig, axes = plt.subplots(k, k,
                             figsize=(max(10, k * 2), max(8, k * 1.5)),
                             squeeze=False)

    # Compute vmax from off-diagonal elements only
    abs_result = np.abs(st_result)
    diag_mask = np.eye(k, dtype=bool)
    off_diag = abs_result[:, :, ~diag_mask]
    vmax = np.max(off_diag) * 0.8 if off_diag.size and np.max(off_diag) > 0 else 1
    cmap = plt.get_cmap("hot_r")

    time_extent = n_times / sfreq  # total signal duration in seconds

    for i in range(k):
        for j in range(k):
            ax = axes[i, j]
            img = ax.imshow(
                np.abs(st_result[:, :, i, j]).T,
                aspect="auto", origin="lower", cmap=cmap,
                extent=[0, time_extent, 0, sfreq / 2],
                vmin=0, vmax=vmax, interpolation="none")
            if i == k - 1:
                ax.set_xlabel("t [s]", fontsize=6)
            else:
                ax.set_xticklabels([])
            if j == 0:
                ax.set_ylabel(ch_names[i], fontsize=6)
            if i == 0:
                ax.set_title(ch_names[j], fontsize=6)
            ax.tick_params(labelsize=5)

    fig.suptitle(f"{label} (short-time) — {tag} ({data_label})", fontsize=10)
    fig.tight_layout()
    fig.subplots_adjust(right=0.92)
    cbar_ax = fig.add_axes([0.93, 0.1, 0.02, 0.7])
    fig.colorbar(img, cax=cbar_ax)

    fname = f"{base}___{_safe_tag(tag)}_{data_label}_{method_key}_shorttime.png"
    fig.savefig(os.path.join(out_dir, fname), dpi=150)
    plt.close(fig)
