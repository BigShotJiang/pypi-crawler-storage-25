### Piotr Durka

"""MP Book Viewer (Qt6) -- interactive time-frequency map for empi decompositions.

PySide6 port of the Tkinter BookViewer.  Displays Wigner time-frequency
energy maps, original/reconstructed signals, and atom parameter tables
for Matching Pursuit results stored in empi SQLite databases.

Usage
-----
    python -m ide4eeg.analysis.mp_bookviewer_qt              # file dialog
    python -m ide4eeg.analysis.mp_bookviewer_qt path/to.db   # open directly

From code::

    from ide4eeg.analysis.mp_bookviewer_qt import BookViewerQt
    BookViewerQt(db_path="result.db")
"""
# Author: Piotr Durka, 2026

import os, sqlite3, sys, threading
from typing import Optional
import numpy as np

try:
    from PySide6.QtCore import Qt, QTimer, QRectF, Signal, QObject, Slot
    from PySide6.QtGui import (QPainter, QPen, QColor, QFont, QPainterPath,
                                QImage)
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QComboBox, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
        QAbstractItemView, QFileDialog, QMessageBox, QSplitter, QSizePolicy,
        QApplication, QFrame)
    _HAS_QT = True
except ImportError:
    _HAS_QT = False

try:
    from . import mp_analysis
except ImportError:
    from ide4eeg.analysis import mp_analysis

# -- Theme-aware colour helpers ------------------------------------------------
# Accent colours stay fixed (they work on both light and dark backgrounds).
_BLUE, _GREEN, _PINK = "#89b4fa", "#a6e3a1", "#f38ba8"


def _theme_colors():
    """Derive theme colours from the current app palette.

    Returns dict with keys: base, text, subtext, mantle,
    surface0, surface1, surface2.  Works for any light/dark theme.
    """
    from PySide6.QtWidgets import QApplication
    pal = QApplication.instance().palette()
    bc = pal.window().color()
    mc = pal.mid().color()

    def _mix(a, b, t):
        return QColor(
            int(a.red() * (1 - t) + b.red() * t),
            int(a.green() * (1 - t) + b.green() * t),
            int(a.blue() * (1 - t) + b.blue() * t)).name()

    text_c = pal.windowText().color()
    return {
        "base": bc.name(),
        "text": text_c.name(),
        "subtext": _mix(text_c, bc, 0.3),
        "mantle": _mix(bc, QColor("#000000"), 0.12),
        "surface0": _mix(bc, mc, 0.3),
        "surface1": _mix(bc, mc, 0.5),
        "surface2": _mix(bc, mc, 0.7),
    }
PALETTES = ["jet", "hot", "viridis", "inferno", "gray"]
SCALES = ["linear", "log", "sqrt"]

# -- Vectorised colour-map LUT ------------------------------------------------

def _build_lut(name, n=256):
    """Return (n, 3) uint8 RGB array for palette *name*."""
    v = np.linspace(0, 1, n)
    if name == "jet":
        r, g, b = (np.clip(1.5 - np.abs(4*v - 3), 0, 1),
                    np.clip(1.5 - np.abs(4*v - 2), 0, 1),
                    np.clip(1.5 - np.abs(4*v - 1), 0, 1))
    elif name == "hot":
        r, g, b = np.clip(3*v, 0, 1), np.clip(3*v-1, 0, 1), np.clip(3*v-2, 0, 1)
    elif name == "viridis":
        r = np.clip(0.267 + 0.004*v + v*v*0.329, 0, 1)
        g = np.clip(0.004 + v*0.874, 0, 1)
        b = np.clip(0.329 + v*0.422 - v*v*0.641, 0, 1)
    elif name == "inferno":
        r, g = np.clip(v*2.5-0.15, 0, 1), np.clip(v*v*2.0, 0, 1)
        b = np.clip(0.5 + 0.5*np.sin(3.14*v), 0, 1)
    else:
        r = g = b = v
    return np.column_stack([r, g, b]) * 255

_LUT_CACHE = {}

def _get_lut(name):
    if name not in _LUT_CACHE:
        _LUT_CACHE[name] = _build_lut(name).astype(np.uint8)
    return _LUT_CACHE[name]

# -- Background loader signal bridge -------------------------------------------

class _LoadSignals(QObject):
    finished = Signal(str, dict)
    error = Signal(str)

# -- Wigner Canvas (QPainter) -------------------------------------------------

class WignerCanvasQt(QWidget):
    """Custom widget painting the Wigner time-frequency energy map."""
    atom_clicked = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._c = _theme_colors()
        self.setMinimumSize(400, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.wigner = self.t_bins = self.f_bins = None
        self.atoms, self.filtered_iters, self.selected_iters = [], set(), set()
        self.palette, self.scale = "jet", "linear"
        self._zoom_xlim = self._zoom_ylim = None
        self._img_cache: Optional[QImage] = None

    def _t_range(self):
        return (self.t_bins[0], self.t_bins[-1]) if self.t_bins is not None and len(self.t_bins) > 1 else (0., 1.)

    def _f_range(self):
        return (self.f_bins[0], self.f_bins[-1]) if self.f_bins is not None and len(self.f_bins) > 1 else (0., 1.)

    def _xlim(self): return self._zoom_xlim or self._t_range()
    def _ylim(self): return self._zoom_ylim or self._f_range()

    def _tx(self, t):
        x0, x1 = self._xlim(); return (t - x0) / max(x1 - x0, 1e-12) * self.width()

    def _fy(self, f):
        y0, y1 = self._ylim(); return self.height() - (f - y0) / max(y1 - y0, 1e-12) * self.height()

    def set_palette(self, name):
        self.palette = name; self._img_cache = None; self.update()

    def set_scale(self, name):
        self.scale = name; self._img_cache = None; self.update()

    def invalidate(self):
        self._img_cache = None; self.update()

    def _render_wigner_image(self):
        if self.wigner is None or self.wigner.max() == 0:
            self._img_cache = None; return
        data = self.wigner.copy()
        if self.scale == "log": data = np.log10(1 + data)
        elif self.scale == "sqrt": data = np.sqrt(data)
        mx = data.max()
        if mx > 0: data /= mx
        h, w = data.shape
        lut = _get_lut(self.palette)
        idx = np.clip((data[::-1, :] * 255).astype(int), 0, 255)
        rgb = lut[idx]  # (h, w, 3)
        buf = np.zeros((h, w, 4), dtype=np.uint8)
        buf[:, :, 0] = rgb[:, :, 2]  # B
        buf[:, :, 1] = rgb[:, :, 1]  # G
        buf[:, :, 2] = rgb[:, :, 0]  # R
        buf[:, :, 3] = 255
        self._img_cache = QImage(buf.data, w, h, w * 4, QImage.Format_RGB32).copy()

    def paintEvent(self, event):  # noqa: N802
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        c = self._c
        p.fillRect(0, 0, w, h, QColor(c["mantle"]))
        if self._img_cache is None: self._render_wigner_image()
        if self._img_cache is not None:
            tr, fr, xl, yl = self._t_range(), self._f_range(), self._xlim(), self._ylim()
            iw, ih = self._img_cache.width(), self._img_cache.height()
            tw, fh = max(tr[1]-tr[0], 1e-12), max(fr[1]-fr[0], 1e-12)
            sx0 = (xl[0]-tr[0])/tw*iw; sx1 = (xl[1]-tr[0])/tw*iw
            sy0 = (1-(yl[1]-fr[0])/fh)*ih; sy1 = (1-(yl[0]-fr[0])/fh)*ih
            p.drawImage(QRectF(0, 0, w, h), self._img_cache, QRectF(sx0, sy0, sx1-sx0, sy1-sy0))
        # Atom crosses
        for a in self.atoms:
            it = a["iteration"]; t, f = a.get("t0_s", 0), a.get("f_Hz", 0)
            if t is None or f is None: continue
            x, y = int(self._tx(t)), int(self._fy(f))
            if not (-10 < x < w+10 and -10 < y < h+10): continue
            if it not in self.filtered_iters:
                p.setPen(QPen(QColor(c["surface2"]), 0.5))
                p.drawLine(x-2, y, x+2, y)
                p.drawLine(x, y-2, x, y+2)
            else:
                p.setPen(QPen(QColor(255, 255, 255, 200), 0.75))
                p.drawLine(x-4, y, x+4, y)
                p.drawLine(x, y-4, x, y+4)
            if it in self.selected_iters and it in self.filtered_iters:
                p.setPen(QPen(QColor(_PINK), 2)); p.setBrush(Qt.NoBrush)
                p.drawEllipse(x-7, y-7, 14, 14)
        p.end()

    def mousePressEvent(self, ev):  # noqa: N802
        if ev.button() == Qt.LeftButton:
            xl, yl = self._xlim(), self._ylim()
            t = xl[0] + ev.position().x()/max(self.width(), 1)*(xl[1]-xl[0])
            f = yl[1] - ev.position().y()/max(self.height(), 1)*(yl[1]-yl[0])
            nearest = self._find_nearest(t, f)
            if nearest is not None: self.atom_clicked.emit(nearest)

    def mouseDoubleClickEvent(self, ev):  # noqa: N802
        self._zoom_xlim = self._zoom_ylim = None; self._img_cache = None; self.update()

    def wheelEvent(self, ev):  # noqa: N802
        factor = 0.75 if ev.angleDelta().y() > 0 else 1.0/0.75
        xl, yl, pos = self._xlim(), self._ylim(), ev.position()
        fx = pos.x()/max(self.width(), 1); fy = 1.0 - pos.y()/max(self.height(), 1)
        def _zoom(lim, frac, full):
            c = lim[0] + frac*(lim[1]-lim[0]); d = (lim[1]-lim[0])*factor
            lo = c - frac*d; hi = lo + d
            if lo < full[0]: lo, hi = full[0], min(full[1], full[0]+d)
            if hi > full[1]: hi, lo = full[1], max(full[0], full[1]-d)
            return (lo, hi)
        self._zoom_xlim = _zoom(xl, fx, self._t_range())
        self._zoom_ylim = _zoom(yl, fy, self._f_range())
        self.update()

    def _find_nearest(self, t, f):
        xl, yl = self._xlim(), self._ylim()
        tr, fr = max(xl[1]-xl[0], 1e-9), max(yl[1]-yl[0], 1e-9)
        best, best_d = None, float("inf")
        for a in self.atoms:
            if a["iteration"] not in self.filtered_iters: continue
            at, af = a.get("t0_s", 0), a.get("f_Hz", 0)
            if at is None or af is None: continue
            d = ((at-t)/tr)**2 + ((af-f)/fr)**2
            if d < best_d: best_d, best = d, a["iteration"]
        return best


# -- Signal Canvas (QPainter) -------------------------------------------------

class SignalCanvasQt(QWidget):
    """Paints signal traces: original, reconstruction, selected-atom reconstruction."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._c = _theme_colors()
        self.setMinimumHeight(50)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.sig_data = self.recon_data = self.sel_data = None
        self.sfreq, self._zoom_xlim = 512.0, None
        self.labels = ("Signal", "Recon", "Selected")
        self.colors = (_BLUE, _GREEN, _PINK)

    def paintEvent(self, event):  # noqa: N802
        c = self._c
        p = QPainter(self); w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(c["mantle"]))
        traces = [self.sig_data, self.recon_data, self.sel_data]
        n_vis = sum(t is not None for t in traces)
        if not n_vis:
            p.setPen(QColor(c["subtext"])); p.setFont(QFont("Helvetica", 11))
            p.drawText(w//2-40, h//2, "No signal"); p.end(); return
        ymax = max(1.0, *(np.max(np.abs(a)) for a in traces if a is not None and len(a))) * 1.05
        row_h, row_i = h / n_vis, 0
        for idx, arr in enumerate(traces):
            if arr is None: continue
            y_off, ns = row_i * row_h, len(arr)
            dur = ns / self.sfreq; xl = self._zoom_xlim or (0.0, dur)
            s0, s1 = max(0, int(xl[0]*self.sfreq)), min(ns, int(xl[1]*self.sfreq))
            if s1 > s0:
                step = max(1, (s1-s0)//w); ia = np.arange(s0, s1, step)
                xs = (ia/self.sfreq - xl[0]) / max(xl[1]-xl[0], 1e-12) * w
                ys = y_off + row_h/2 - arr[ia]/ymax*(row_h*0.4)
                p.setPen(QPen(QColor(c["surface2"]), 1, Qt.DotLine))
                p.drawLine(0, int(y_off+row_h/2), w, int(y_off+row_h/2))
                if len(xs) > 1:
                    path = QPainterPath(); path.moveTo(float(xs[0]), float(ys[0]))
                    for j in range(1, len(xs)): path.lineTo(float(xs[j]), float(ys[j]))
                    p.setPen(QPen(QColor(self.colors[idx]), 1)); p.setBrush(Qt.NoBrush); p.drawPath(path)
            p.setPen(QColor(self.colors[idx])); p.setFont(QFont("Menlo", 8))
            p.drawText(4, int(y_off+12), f"{self.labels[idx]} [\u00b5V]"); row_i += 1
        # Time ticks
        ns_any = next((len(a) for a in traces if a is not None), 0)
        dur = ns_any / self.sfreq if self.sfreq else 1; xl = self._zoom_xlim or (0., dur)
        p.setPen(QColor(c["subtext"])); p.setFont(QFont("Menlo", 7))
        span = xl[1]-xl[0]; st = span/6
        for nice in (0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5):
            if nice >= st: st = nice; break
        t = int(xl[0]/st)*st
        while t <= xl[1]:
            if t >= xl[0]: p.drawText(int((t-xl[0])/max(span, 1e-12)*w)-15, h-2, f"{t:.2f}s")
            t += st
        p.end()


# -- BookViewerQt (QMainWindow) -----------------------------------------------

class BookViewerQt(QMainWindow):
    """Interactive Qt6 viewer for empi MP decomposition results."""

    def __init__(self, parent=None, db_path=None, on_accept=None,
                 hide_open=False):
        super().__init__(parent)
        self._on_accept = on_accept
        self._hide_open = hide_open
        self._c = _theme_colors()  # snapshot current theme
        self.setWindowTitle("MP Book Viewer"); self.resize(1100, 850); self.setMinimumSize(640, 480)
        self.setStyleSheet(f"background-color:{self._c['base']}; color:{self._c['text']};")
        # State
        self.db_path: Optional[str] = None
        self.sfreq, self.n_segments, self.n_channels = 512.0, 0, 0
        self.segment_id = self.channel_id = 0
        self.atoms, self._filtered_atoms, self._selected_iters = [], [], set()
        self.signal = None
        self._segments, self._n_samples = {}, 0
        self._meta_scale, self._channel_names, self._algorithm = None, [], ""
        self._recon_cache = self._recon_atoms_key = None
        self._load_sig = _LoadSignals()
        self._load_sig.finished.connect(self._on_db_loaded)
        self._load_sig.error.connect(lambda m: self.statusBar().showMessage(m))
        self._build_ui()
        if db_path: self._load_db(db_path)

    @property
    def _scale(self):
        return self._meta_scale if self._meta_scale is not None else 1.0

    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        ml = QVBoxLayout(cw); ml.setContentsMargins(4,4,4,4); ml.setSpacing(2)
        # Create canvases first (toolbar references them)
        self.wigner_canvas = WignerCanvasQt(); self.wigner_canvas.atom_clicked.connect(self._on_atom_clicked)
        self.signal_canvas = SignalCanvasQt()
        self._build_toolbar(ml); self._build_filter_bar(ml)
        sp = QSplitter(Qt.Vertical)
        sp.addWidget(self.wigner_canvas)
        sp.addWidget(self.signal_canvas)
        sp.setStretchFactor(0, 3); sp.setStretchFactor(1, 1); ml.addWidget(sp, stretch=1)
        self._build_atom_table(ml)
        self._info = QLabel("Open an empi .db file to begin.")
        self._info.setStyleSheet(f"background:{self._c["surface0"]}; color:{self._c["text"]}; padding:2px 8px;")
        self._info.setFont(QFont("Menlo", 9)); ml.addWidget(self._info)
        self.statusBar().showMessage("Ready")

    def _btn(self, text, tip="", width=0):
        b = QPushButton(text)
        css = (f"QPushButton{{background:{self._c["surface1"]};color:{self._c["text"]};border:none;padding:4px 8px;}}"
               f"QPushButton:hover{{background:{self._c["surface2"]};}}")
        b.setStyleSheet(css)
        if tip: b.setToolTip(tip)
        if width: b.setFixedWidth(width)
        return b

    def _lbl(self, text):
        lb = QLabel(text); lb.setStyleSheet(f"color:{self._c["text"]};background:transparent;"); lb.setFont(QFont("Helvetica", 10)); return lb

    def _build_toolbar(self, layout):
        tb = QFrame(); tb.setStyleSheet(f"background:{self._c["surface0"]};padding:2px;")
        hl = QHBoxLayout(tb); hl.setContentsMargins(4,2,4,2); hl.setSpacing(6)
        self._open_btn = self._btn("Open", "Open an empi .db file")
        self._open_btn.clicked.connect(self._open_file)
        if self._hide_open:
            self._open_btn.hide()
        hl.addWidget(self._open_btn); hl.addSpacing(4)

        # -- Navigation: ◀ 1/N ▶   Ch ▲ 1/N name ▼ ----------------
        b = self._btn("\u25C0", "Previous epoch (\u2190)", 24); b.clicked.connect(self._prev_segment); hl.addWidget(b)
        self._seg_lbl = QLabel("\u2013"); self._seg_lbl.setFixedWidth(38)
        self._seg_lbl.setAlignment(Qt.AlignCenter); hl.addWidget(self._seg_lbl)
        b = self._btn("\u25B6", "Next epoch (\u2192)", 24); b.clicked.connect(self._next_segment); hl.addWidget(b)
        hl.addSpacing(4)
        hl.addWidget(self._lbl("Ch"))
        b = self._btn("\u25B2", "Previous channel (\u2191)", 24); b.clicked.connect(self._prev_channel); hl.addWidget(b)
        self._ch_lbl = QLabel("\u2013"); self._ch_lbl.setFixedWidth(70)
        self._ch_lbl.setAlignment(Qt.AlignCenter); hl.addWidget(self._ch_lbl)
        b = self._btn("\u25BC", "Next channel (\u2193)", 24); b.clicked.connect(self._next_channel); hl.addWidget(b)
        hl.addSpacing(4)

        # -- Palette & scale with labels -----------------------------------
        hl.addWidget(self._lbl("Palette:"))
        self._palette_combo = QComboBox(); self._palette_combo.addItems(PALETTES)
        self._palette_combo.setMinimumWidth(80)
        self._palette_combo.setToolTip("Colour map")
        self._palette_combo.currentTextChanged.connect(self.wigner_canvas.set_palette)
        hl.addWidget(self._palette_combo)
        hl.addWidget(self._lbl("Scale:"))
        self._scale_combo = QComboBox(); self._scale_combo.addItems(SCALES)
        self._scale_combo.setMinimumWidth(70)
        self._scale_combo.setToolTip("Energy scale")
        self._scale_combo.currentTextChanged.connect(self.wigner_canvas.set_scale)
        hl.addWidget(self._scale_combo); hl.addSpacing(2)

        # -- Freq max ------------------------------------------------------
        hl.addWidget(self._lbl("Fmax"))
        self._freq_max_edit = QLineEdit(); self._freq_max_edit.setFixedWidth(36)
        self._freq_max_edit.setStyleSheet(f"background:{self._c["surface1"]};color:{self._c["text"]};border:none;padding:2px;font-family:Menlo;")
        self._freq_max_edit.setToolTip("Max display frequency [Hz]")
        self._freq_max_edit.returnPressed.connect(self._apply_freq_max)
        hl.addWidget(self._freq_max_edit)
        b = self._btn("+", width=22); b.clicked.connect(self._freq_max_up); hl.addWidget(b)
        b = self._btn("\u2212", width=22); b.clicked.connect(self._freq_max_down); hl.addWidget(b)
        hl.addSpacing(6)

        # -- Toggle buttons ------------------------------------------------
        _toggle_css = (f"QPushButton{{background:{self._c["surface1"]};color:{self._c["text"]};"
                       f"border:none;padding:4px 8px;}}"
                       f"QPushButton:hover{{background:{self._c["surface2"]};}}")
        self._filter_btn = QPushButton("Filter"); self._filter_btn.setCheckable(True)
        self._filter_btn.setStyleSheet(_toggle_css)
        self._filter_btn.setToolTip("Show/hide atom filter bar")
        self._filter_btn.toggled.connect(self._toggle_filter); hl.addWidget(self._filter_btn)
        self._table_btn = QPushButton("Table"); self._table_btn.setCheckable(True)
        self._table_btn.setStyleSheet(_toggle_css)
        self._table_btn.setToolTip("Show/hide atom table")
        self._table_btn.toggled.connect(self._toggle_table); hl.addWidget(self._table_btn)
        b = self._btn("Clear", "Deselect all atoms"); b.clicked.connect(self._clear_selection); hl.addWidget(b)
        b = self._btn("Info", "Show book metadata"); b.clicked.connect(self._show_metadata); hl.addWidget(b)
        hl.addStretch()
        if self._on_accept is not None:
            ab = QPushButton("\u2714  Use selected atoms")
            ab.setStyleSheet(f"QPushButton{{background:{_BLUE};color:{self._c["base"]};font-weight:bold;padding:6px 16px;border:none;}}QPushButton:hover{{background:{_GREEN};}}")
            ab.setToolTip("Accept selected atoms"); ab.clicked.connect(self._accept_selection); hl.addWidget(ab)
        layout.addWidget(tb)

    def _build_filter_bar(self, layout):
        self._filter_frame = QFrame(); self._filter_frame.setStyleSheet(f"background:{self._c["surface0"]};")
        fl = QHBoxLayout(self._filter_frame); fl.setContentsMargins(8,4,8,4); fl.setSpacing(4)
        ent_css = f"background:{self._c["surface1"]};color:{self._c["text"]};border:none;padding:2px;font-family:Menlo;"
        def _field(label, tip):
            if label: fl.addWidget(self._lbl(label))
            e = QLineEdit(); e.setFixedWidth(60); e.setStyleSheet(ent_css); e.setToolTip(tip)
            e.returnPressed.connect(self._apply_filter); fl.addWidget(e); return e
        self._filt_freq_min = _field("Freq:", "Min frequency (Hz)")
        fl.addWidget(self._lbl("\u2013")); self._filt_freq_max = _field("", "Max frequency (Hz)")
        fl.addWidget(self._lbl("Hz")); fl.addSpacing(8)
        self._filt_time_min = _field("Time:", "Min time (s)")
        fl.addWidget(self._lbl("\u2013")); self._filt_time_max = _field("", "Max time (s)")
        fl.addWidget(self._lbl("s")); fl.addSpacing(8)
        self._filt_energy = _field("Energy\u2265", "Min atom energy"); fl.addSpacing(8)
        self._filt_iter = _field("Iter\u2264", "Max iteration number"); fl.addSpacing(12)
        b = self._btn("Apply"); b.clicked.connect(self._apply_filter); fl.addWidget(b)
        b = self._btn("Reset"); b.clicked.connect(self._reset_filter); fl.addWidget(b)
        fl.addStretch(); self._filter_frame.setVisible(False); layout.addWidget(self._filter_frame)

    def _build_atom_table(self, layout):
        self._table_frame = QFrame(); self._table_frame.setStyleSheet(f"background:{self._c["surface0"]};")
        self._table_updating = False
        cols = ["#", "Freq [Hz]", "t\u2080 [s]", "Scale [s]", "Amp [\u00b5V]", "Energy [\u00b5V\u00b2]", "Phase [rad]"]
        self._atom_table = QTableWidget(0, len(cols)); self._atom_table.setHorizontalHeaderLabels(cols)
        self._atom_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._atom_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._atom_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._atom_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._atom_table.setStyleSheet(
            f"QTableWidget{{background:{self._c["mantle"]};color:{self._c["text"]};gridline-color:{self._c["surface1"]};}}"
            f"QHeaderView::section{{background:{self._c["surface1"]};color:{self._c["text"]};font-weight:bold;padding:2px;}}"
            f"QTableWidget::item:selected{{background:{self._c["surface2"]};}}")
        self._atom_table.itemSelectionChanged.connect(self._on_table_select)
        self._atom_table.setMaximumHeight(200)
        vl = QVBoxLayout(self._table_frame); vl.setContentsMargins(4,2,4,2); vl.addWidget(self._atom_table)
        self._table_frame.setVisible(False); layout.addWidget(self._table_frame)

    # -- Key bindings ----------------------------------------------------------

    def keyPressEvent(self, ev):  # noqa: N802
        k = ev.key()
        if k == Qt.Key_Left: self._prev_segment()
        elif k == Qt.Key_Right: self._next_segment()
        elif k == Qt.Key_Up: self._prev_channel()
        elif k == Qt.Key_Down: self._next_channel()
        elif k == Qt.Key_Escape: self._reset_view()
        else: super().keyPressEvent(ev)

    # -- File I/O --------------------------------------------------------------

    def _open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open empi .db file", "", "empi SQLite (*.db);;All files (*)")
        if path: self._load_db(path)

    def _load_db(self, path):
        if not os.path.isfile(path): self._info.setText(f"File not found: {path}"); return
        self.statusBar().showMessage(f"Loading {os.path.basename(path)}...")
        def _worker():
            try:
                with sqlite3.connect(path) as conn:
                    cur = conn.cursor()
                    meta = dict(cur.execute("SELECT param, value FROM metadata"))
                    segs = {}
                    for r in cur.execute("SELECT segment_id, sample_count, segment_length_s, segment_offset_s FROM segments"):
                        segs[r[0]] = {"sample_count": r[1], "length_s": r[2], "offset_s": r[3]}
                self._load_sig.finished.emit(path, {"meta": meta, "segments": segs})
            except Exception as e: self._load_sig.error.emit(f"Database error: {e}")
        threading.Thread(target=_worker, daemon=True).start()

    @Slot(str, dict)
    def _on_db_loaded(self, path, result):
        meta = result["meta"]
        self.sfreq = float(meta.get("sampling_frequency_Hz", 512))
        self._freq_max_edit.setText(f"{self.sfreq/2:.0f}")
        self.n_channels = int(meta.get("channel_count", 1))
        self.n_segments = int(meta.get("segment_count", 1))
        scale_str = meta.get("scale_to_uV")
        self._meta_scale = float(scale_str) if scale_str else None
        self._algorithm = meta.get("algorithm", "")
        ch_str = meta.get("channel_names", "")
        self._channel_names = [c for c in ch_str.split(",") if c] if ch_str else []
        self._segments = result["segments"]
        self.db_path = path; self.segment_id = self.channel_id = 0
        algo = f" [{self._algorithm}]" if self._algorithm else ""
        self.setWindowTitle(f"MP Book Viewer{algo} \u2014 {os.path.basename(path)}")
        # Show metadata summary as tooltip on the info bar
        ch_list = ", ".join(self._channel_names) if self._channel_names else "(unnamed)"
        meta_lines = [
            f"File: {os.path.basename(path)}",
            f"Algorithm: {self._algorithm or '?'}",
            f"Channels: {self.n_channels} — {ch_list}",
            f"Segments: {self.n_segments}",
            f"Sampling: {self.sfreq:.0f} Hz",
        ]
        src = meta.get("source_file", "")
        if src:
            meta_lines.append(f"Source: {src}")
        mode = meta.get("analysis_mode", "")
        if mode:
            meta_lines.append(f"Mode: {mode}")
        seg0 = self._segments.get(0, {})
        if seg0:
            meta_lines.append(
                f"Segment duration: {seg0.get('length_s', '?')} s")
        scale = meta.get("scale_to_uV")
        if scale:
            meta_lines.append(f"Scale: {scale} (to \u00b5V)")
        self._info.setToolTip("\n".join(meta_lines))
        self._load_current()

    def _read_signal(self, seg_id, ch_id):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.cursor()
                cur.execute("SELECT samples_float32 FROM samples WHERE segment_id=? AND channel_id=?", [seg_id, ch_id])
                row = cur.fetchone()
            return np.frombuffer(row[0], dtype=">f4").astype(np.float64) if row else None
        except sqlite3.Error: return None

    # -- Filtering -------------------------------------------------------------

    def _get_display_freq_max(self):
        try:
            v = float(self._freq_max_edit.text())
            if v > 0: return min(v, self.sfreq/2)
        except (ValueError, TypeError): pass
        return self.sfreq / 2

    def _apply_freq_max(self):
        self.wigner_canvas._zoom_ylim = None; self._recompute_wigner(); self._redraw()

    def _freq_max_up(self):
        self._freq_max_edit.setText(f"{min(self._get_display_freq_max()+10, self.sfreq/2):.0f}"); self._apply_freq_max()

    def _freq_max_down(self):
        self._freq_max_edit.setText(f"{max(self._get_display_freq_max()-10, 10):.0f}"); self._apply_freq_max()

    @staticmethod
    def _entry_float(w):
        txt = w.text().strip()
        if not txt: return 0
        try: return float(txt)
        except ValueError: return 0

    def _apply_filter(self):
        c = {k: self._entry_float(w) for k, w in zip(
            ("freq_min","freq_max","time_min","time_max","min_energy","max_iterations"),
            (self._filt_freq_min, self._filt_freq_max, self._filt_time_min, self._filt_time_max, self._filt_energy, self._filt_iter))}
        self._filtered_atoms = mp_analysis.filter_atoms(self.atoms, c) if any(c.values()) else list(self.atoms)
        self._recompute_wigner()
        if self._table_frame.isVisible(): self._populate_table()
        self._redraw()

    def _reset_filter(self):
        for w in (self._filt_freq_min, self._filt_freq_max, self._filt_time_min, self._filt_time_max, self._filt_energy, self._filt_iter):
            w.clear()
        self._filtered_atoms = list(self.atoms); self._recompute_wigner()
        if self._table_frame.isVisible(): self._populate_table()
        self._redraw()

    def _toggle_filter(self, checked): self._filter_frame.setVisible(checked)
    def _toggle_table(self, checked):
        self._table_frame.setVisible(checked)
        if checked: self._populate_table()

    # -- Data loading ----------------------------------------------------------

    def _load_current(self):
        if not self.db_path: return
        self._seg_lbl.setText(f"{self.segment_id+1}/{self.n_segments}")
        ch = f"{self.channel_id+1}/{self.n_channels}"
        if self._channel_names and self.channel_id < len(self._channel_names): ch += f" {self._channel_names[self.channel_id]}"
        self._ch_lbl.setText(ch)
        self.atoms = mp_analysis.read_mp_results(self.db_path, self.segment_id, self.channel_id)
        seg = self._segments.get(self.segment_id, {})
        self._n_samples = seg.get("sample_count", 0) or int(seg.get("length_s", 1)*self.sfreq)
        self.signal = self._read_signal(self.segment_id, self.channel_id)
        self._filtered_atoms = list(self.atoms)
        self._recon_cache = self._recon_atoms_key = None
        self._recompute_wigner()
        self._info.setText(f"{len(self.atoms)} atoms   \u2191\u2193 channels  \u2190\u2192 epochs  scroll=zoom  dblclick/Esc=reset")
        if self._table_frame.isVisible(): self._populate_table()
        self._redraw()

    def _recompute_wigner(self):
        freq_max = self._get_display_freq_max()
        nt, nf = min(512, max(self._n_samples, 64)), 256
        if self._filtered_atoms:
            s2 = self._scale**2
            scaled = [dict(a, energy=a.get("energy", a["amplitude"]**2)*s2) for a in self._filtered_atoms]
            w, tb, fb = mp_analysis.compute_wigner_map(scaled, self._n_samples, self.sfreq, n_time_bins=nt, n_freq_bins=nf, time_offset=0.0, freq_max=freq_max)
        else:
            dur = self._n_samples / self.sfreq if self.sfreq else 1
            tb, fb, w = np.linspace(0, dur, nt), np.linspace(0, freq_max, nf), np.zeros((nf, nt))
        self.wigner_canvas.wigner, self.wigner_canvas.t_bins, self.wigner_canvas.f_bins = w, tb, fb
        self.wigner_canvas._img_cache = None; self._recon_cache = self._recon_atoms_key = None

    def _get_recon(self, atoms, ns):
        key = tuple(a["iteration"] for a in atoms)
        if self._recon_cache is not None and self._recon_atoms_key == key: return self._recon_cache
        r = mp_analysis.reconstruct_signal(atoms, ns, self.sfreq)
        self._recon_cache, self._recon_atoms_key = r, key; return r

    # -- Drawing ---------------------------------------------------------------

    def _redraw(self):
        ns = len(self.signal) if self.signal is not None else self._n_samples
        filt_set = {a["iteration"] for a in self._filtered_atoms}
        sel_atoms = [a for a in self._filtered_atoms if a["iteration"] in self._selected_iters]
        self.wigner_canvas.atoms = self.atoms
        self.wigner_canvas.filtered_iters = filt_set
        self.wigner_canvas.selected_iters = self._selected_iters
        self.wigner_canvas.invalidate()
        sc = self._scale
        if self.signal is not None and len(self.signal):
            ss = self._meta_scale if self._meta_scale is not None else (1e6 if 0 < np.max(np.abs(self.signal)) < 1.0 else 1.0)
            self.signal_canvas.sig_data = self.signal * ss
        else: self.signal_canvas.sig_data = None
        self.signal_canvas.recon_data = self._get_recon(self._filtered_atoms, ns)*sc if self._filtered_atoms else None
        self.signal_canvas.sel_data = mp_analysis.reconstruct_signal(sel_atoms, ns, self.sfreq)*sc if sel_atoms else None
        self.signal_canvas.sfreq = self.sfreq
        self.signal_canvas._zoom_xlim = self.wigner_canvas._zoom_xlim
        self.signal_canvas.update()

    # -- Navigation ------------------------------------------------------------

    def _prev_segment(self):
        if self.segment_id > 0: self.segment_id -= 1; self._load_current()
    def _next_segment(self):
        if self.segment_id < self.n_segments-1: self.segment_id += 1; self._load_current()
    def _prev_channel(self):
        if self.channel_id > 0: self.channel_id -= 1; self._load_current()
    def _next_channel(self):
        if self.channel_id < self.n_channels-1: self.channel_id += 1; self._load_current()

    # -- Atom interaction ------------------------------------------------------

    @Slot(int)
    def _on_atom_clicked(self, iteration):
        if iteration in self._selected_iters: self._selected_iters.discard(iteration); action = "deselected"
        else: self._selected_iters.add(iteration); action = "SELECTED"
        atom = next((a for a in self.atoms if a["iteration"] == iteration), None)
        if atom:
            self._info.setText(f"[{action}] Atom #{atom['iteration']+1}:  f={atom['f_Hz']:.2f}Hz  t\u2080={atom['t0_s']:.4f}s  "
                               f"scale={atom['scale_s']:.4f}s  amp={atom['amplitude']:.4g}  energy={atom.get('energy',0):.4g}  phase={atom['phase']:.3f}rad")
        self._sync_table_selection(); self._redraw()

    def _clear_selection(self):
        if self._selected_iters: self._selected_iters.clear(); self._info.setText("Selection cleared."); self._sync_table_selection(); self._redraw()

    def _show_metadata(self):
        """Show book metadata in a dialog."""
        if not self.db_path:
            return
        try:
            with sqlite3.connect(self.db_path) as conn:
                meta = dict(conn.execute(
                    "SELECT param, value FROM metadata"))
        except sqlite3.Error:
            meta = {}
        ch_str = meta.get("channel_names", "")
        ch_list = [c for c in ch_str.split(",") if c] if ch_str else []
        lines = []
        lines.append(f"<b>File:</b> {os.path.basename(self.db_path)}")
        lines.append(f"<b>Algorithm:</b> {meta.get('algorithm', '?')}")
        lines.append(f"<b>Channels ({meta.get('channel_count', '?')}):</b>"
                      f" {', '.join(ch_list) if ch_list else '(unnamed)'}")
        lines.append(f"<b>Segments:</b> {meta.get('segment_count', '?')}")
        lines.append(
            f"<b>Sampling:</b> {meta.get('sampling_frequency_Hz', '?')} Hz")
        if meta.get("source_file"):
            lines.append(f"<b>Source:</b> {meta['source_file']}")
        if meta.get("analysis_mode"):
            lines.append(f"<b>Mode:</b> {meta['analysis_mode']}")
        seg0 = self._segments.get(0, {})
        if seg0.get("length_s"):
            lines.append(
                f"<b>Segment duration:</b> {seg0['length_s']} s")
        if meta.get("scale_to_uV"):
            lines.append(
                f"<b>Scale:</b> {meta['scale_to_uV']} (to \u00b5V)")
        if meta.get("signal_unit"):
            lines.append(f"<b>Signal unit:</b> {meta['signal_unit']}")
        if meta.get("version"):
            lines.append(f"<b>empi version:</b> {meta['version']}")
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QTextBrowser
        dlg = QDialog(self)
        dlg.setWindowTitle("Book Metadata")
        dlg.resize(420, 300)
        lay = QVBoxLayout(dlg)
        browser = QTextBrowser()
        browser.setHtml(
            '<div style="font-size:13px;line-height:1.6;">'
            + "<br>".join(lines) + '</div>')
        lay.addWidget(browser)
        dlg.show()

    def _reset_view(self):
        self.wigner_canvas._zoom_xlim = self.wigner_canvas._zoom_ylim = None
        self.wigner_canvas._img_cache = None; self._redraw()

    # -- Atom table ------------------------------------------------------------

    def _populate_table(self):
        self._table_updating = True; tbl = self._atom_table; tbl.setRowCount(len(self.atoms))
        filt_set = {a["iteration"] for a in self._filtered_atoms}; sc, sc2 = self._scale, self._scale**2
        for i, a in enumerate(self.atoms):
            it = a["iteration"]
            for col, v in enumerate([str(it+1), f"{a['f_Hz']:.2f}", f"{a['t0_s']:.4f}", f"{a['scale_s']:.4f}",
                                     f"{a['amplitude']*sc:.4g}", f"{a.get('energy',a['amplitude']**2)*sc2:.4g}", f"{a['phase']:.3f}"]):
                item = QTableWidgetItem(v); item.setData(Qt.UserRole, it)
                if it in self._selected_iters: item.setBackground(QColor("#5c3a4a")); item.setForeground(QColor(_PINK))
                elif it not in filt_set: item.setForeground(QColor(self._c["surface2"]))
                tbl.setItem(i, col, item)
        self._table_updating = False

    def _sync_table_selection(self):
        if not self._table_frame.isVisible(): return
        self._table_updating = True; tbl = self._atom_table; tbl.clearSelection()
        for r in range(tbl.rowCount()):
            item = tbl.item(r, 0)
            if item and item.data(Qt.UserRole) in self._selected_iters: tbl.selectRow(r)
        self._populate_table(); self._table_updating = False

    def _on_table_select(self):
        if self._table_updating: return
        self._table_updating = True; tbl = self._atom_table
        filt_set = {a["iteration"] for a in self._filtered_atoms}
        new = set()
        for idx in tbl.selectionModel().selectedRows():
            item = tbl.item(idx.row(), 0)
            if item:
                it = item.data(Qt.UserRole)
                if it in filt_set: new.add(it)
        self._selected_iters = new; self._table_updating = False
        QTimer.singleShot(50, self._redraw)

    # -- Accept / close --------------------------------------------------------

    def _accept_selection(self):
        sel = [dict(a, segment_id=self.segment_id) for a in self._filtered_atoms if a["iteration"] in self._selected_iters]
        if not sel: self._info.setText("No atoms selected. Click atoms to select."); return
        if self._on_accept: self._on_accept(sel)
        self.close()

    def closeEvent(self, ev):  # noqa: N802
        if self._on_accept and self._selected_iters:
            ans = QMessageBox.question(self, "Use selected atoms?",
                f"{len(self._selected_iters)} atom(s) selected.\nYes = use them\nNo = discard and close",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
            if ans == QMessageBox.Yes: self._accept_selection(); return
            elif ans == QMessageBox.Cancel: ev.ignore(); return
        super().closeEvent(ev)


# -- Module entry points -------------------------------------------------------

def open_viewer(parent=None, db_path=None, on_accept=None):
    """Convenience function to launch the Qt BookViewer."""
    return BookViewerQt(parent=parent, db_path=db_path, on_accept=on_accept)

if __name__ == "__main__":
    app = QApplication.instance() or QApplication(sys.argv)
    path = sys.argv[1] if len(sys.argv) > 1 else None
    win = BookViewerQt(db_path=path); win.show(); sys.exit(app.exec())
