### Piotr Durka

"""EEG Profiles — time-evolution of EEG structures from MP decomposition.

Post-processes Matching Pursuit atoms to detect and count EEG structures
(sleep spindles, alpha/delta/theta/beta waves, K-complexes, SWA, …) by
filtering atoms on Frequency, Amplitude, Scale, Phase (FASP) thresholds.

Produces multi-panel time-evolution charts (count per interval, time
percentage, or single-occurrence markers) and a CSV detection table.

Based on the BookReporter plugin from SVAROG4:

  Malinowska U, Chatelle C, Bruno MA, Noirhomme Q, Laureys S, Durka PJ
  (2013) "Electroencephalographic profiles for differentiation of
  disorders of consciousness." BioMedical Engineering OnLine 12:109.
  https://doi.org/10.1186/1475-925X-12-109
"""

# Author: Piotr Durka / Claude, 2026

import logging
import os
import sqlite3

import numpy as np
# matplotlib and pandas are imported lazily inside the functions that
# use them — top-level imports would add ~650 ms to GUI startup since
# this module is transitively loaded for its PRESETS constant.


# ── Preset EEG structure definitions (FASP ranges) ──────────────────

PRESETS = [
    {
        "name": "Sleep spindles",
        "freq_min": 11, "freq_max": 16,
        "amp_min": 12, "amp_max": 0,
        "scale_min": 0.5, "scale_max": 2.5,
        "phase_min": 0, "phase_max": 0,
    },
    {
        "name": "Alpha waves",
        "freq_min": 8, "freq_max": 12,
        "amp_min": 5, "amp_max": 0,
        "scale_min": 0, "scale_max": 0,
        "phase_min": 0, "phase_max": 0,
    },
    {
        "name": "Delta waves",
        "freq_min": 0.2, "freq_max": 4,
        "amp_min": 65, "amp_max": 0,
        "scale_min": 0.5, "scale_max": 6,
        "phase_min": 0, "phase_max": 0,
    },
    {
        "name": "Beta waves",
        "freq_min": 15, "freq_max": 25,
        "amp_min": 5, "amp_max": 0,
        "scale_min": 0, "scale_max": 0.5,
        "phase_min": 0, "phase_max": 0,
    },
    {
        "name": "Theta waves",
        "freq_min": 4, "freq_max": 8,
        "amp_min": 15, "amp_max": 0,
        "scale_min": 1.0, "scale_max": 0,
        "phase_min": 0, "phase_max": 0,
    },
]


# ── Core detection logic ─────────────────────────────────────────────

def _matches(atom, struct, scale_uV):
    """Check whether *atom* satisfies the FASP thresholds of *struct*.

    Parameters
    ----------
    atom : dict
        Atom from ``read_mp_results`` (keys: f_Hz, amplitude, scale_s, phase).
    struct : dict
        Structure definition with optional keys: freq_min/max, amp_min/max,
        scale_min/max, phase_min/max.  A value of 0 (or absent) means
        "no constraint" for that bound.
    scale_uV : float
        Multiplier to convert atom amplitude to µV (e.g. 1e6 for Volts).

    Returns
    -------
    bool
    """
    f = atom.get("f_Hz") or 0.0
    amp = abs(atom.get("amplitude") or 0.0) * scale_uV
    s = atom.get("scale_s") or 0.0
    ph = atom.get("phase") or 0.0

    fmin = struct.get("freq_min", 0)
    fmax = struct.get("freq_max", 0)
    if fmin and f < fmin:
        return False
    if fmax and f > fmax:
        return False

    amin = struct.get("amp_min", 0)
    amax = struct.get("amp_max", 0)
    if amin and amp < amin:
        return False
    if amax and amp > amax:
        return False

    smin = struct.get("scale_min", 0)
    smax = struct.get("scale_max", 0)
    if smin and s < smin:
        return False
    if smax and s > smax:
        return False

    pmin = struct.get("phase_min", 0)
    pmax = struct.get("phase_max", 0)
    if pmin and pmax and pmin != pmax:
        if ph < pmin or ph > pmax:
            return False

    return True


def detect_structures(atoms, structures, scale_uV=1.0):
    """Classify atoms into named EEG structures.

    Parameters
    ----------
    atoms : list of dict
        Atoms from one segment/channel.
    structures : list of dict
        Structure definitions (each with ``name`` and FASP bounds).
    scale_uV : float
        Amplitude conversion factor (V → µV).

    Returns
    -------
    detections : list of dict
        Each has keys: name, t0_s, scale_s, f_Hz, amplitude_uV,
        energy_uV2, phase.
    """
    detections = []
    scale2 = scale_uV ** 2
    for atom in atoms:
        for struct in structures:
            if _matches(atom, struct, scale_uV):
                amp = atom.get("amplitude") or 0.0
                # Rescale energy V² → µV² (matching amplitude_uV and
                # the "Energy [µV²]" plot axis); otherwise CSV %.6f
                # rounds typical EEG energies (~1e-10 V²) to 0.
                raw_energy = atom.get("energy") or amp ** 2
                detections.append({
                    "name": struct["name"],
                    "t0_s": atom.get("t0_s") or 0.0,
                    "scale_s": atom.get("scale_s") or 0.0,
                    "f_Hz": atom.get("f_Hz") or 0.0,
                    "amplitude_uV": abs(amp) * scale_uV,
                    "energy_uV2": raw_energy * scale2,
                    "phase": atom.get("phase") or 0.0,
                })
                break  # each atom matches at most one structure
    return detections


# ── Binning and metrics ──────────────────────────────────────────────

def _bin_count(detections, name, interval, total_dur):
    """Count detections of *name* per time bin."""
    n_bins = max(1, int(np.ceil(total_dur / interval)))
    counts = np.zeros(n_bins)
    for d in detections:
        if d["name"] != name:
            continue
        idx = min(int(d["t0_s"] / interval), n_bins - 1)
        counts[idx] += 1
    return counts


def _bin_percentage(detections, name, interval, total_dur):
    """Fraction of each bin occupied by detected structures."""
    n_bins = max(1, int(np.ceil(total_dur / interval)))
    occupied = np.zeros(n_bins)
    for d in detections:
        if d["name"] != name:
            continue
        idx = min(int(d["t0_s"] / interval), n_bins - 1)
        occupied[idx] += d["scale_s"]
    return np.clip(occupied / interval * 100, 0, 100)


def _occurrence_times(detections, name):
    """Return sorted array of detection times for *name*."""
    return np.array(sorted(d["t0_s"] for d in detections
                           if d["name"] == name))


def _occurrence_data(detections, name, value_key="amplitude_uV"):
    """Return (times, values) arrays for *name*, sorted by time.

    Parameters
    ----------
    value_key : str
        Detection key for the line height: ``"amplitude_uV"`` or ``"energy_uV2"``.
    """
    pairs = sorted(((d["t0_s"], d.get(value_key, 0))
                    for d in detections if d["name"] == name),
                   key=lambda p: p[0])
    if not pairs:
        return np.array([]), np.array([])
    t, v = zip(*pairs)
    return np.array(t), np.array(v, dtype=float)


# ── Tag export ────────────────────────────────────────────────────────

# Structure name → (fillColor, outlineColor) for SVAROG tags
_STRUCTURE_COLORS = {
    "Sleep spindles": ("dc143c", "8b0000"),
    "Alpha waves":    ("4169e1", "1a3a8a"),
    "Delta waves":    ("228b22", "145214"),
    "Beta waves":     ("ff8c00", "b36200"),
    "Theta waves":    ("9370db", "6a3d9a"),
    "K-complexes":    ("daa520", "8b6914"),
    "SWA":            ("2e8b57", "1a5c37"),
    "Gamma waves":    ("ff69b4", "c71585"),
}
_DEFAULT_COLOR = ("808080", "404040")


def _save_detection_tags(detections, structures, channel_name,
                         file_name, output_dir, channel_number=0,
                         interval=20.0):
    """Write detected EEG structures as a SVAROG .tag file.

    Parameters
    ----------
    detections : list of dict
        Detection dicts with keys: name, t0_s, scale_s, f_Hz,
        amplitude_uV, energy_uV2, phase.
    structures : list of dict
        Structure definitions (for names/order).
    channel_name : str
        Name of the analysed channel.
    file_name : str
        Base file name (without extension).
    output_dir : str
        Directory to save the .tag file in.
    """
    from xml.dom.minidom import getDOMImplementation

    tag_path = os.path.join(
        output_dir, f"{file_name}_profiles_{channel_name}.tag")

    impl = getDOMImplementation()
    doc = impl.createDocument(None, "tagFile", None)
    root = doc.documentElement
    root.setAttribute("formatVersion", "1.0")

    # Paging — use the profile interval as page size
    paging = doc.createElement("paging")
    paging.setAttribute("pageSize", f"{interval:.1f}")
    root.appendChild(paging)

    # Tag definitions
    tag_defs = doc.createElement("tagDefinitions")
    root.appendChild(tag_defs)
    ch_group = doc.createElement("defGroup")
    ch_group.setAttribute("name", "channelTags")
    tag_defs.appendChild(ch_group)

    struct_names = list(dict.fromkeys(s["name"] for s in structures))
    for name in struct_names:
        fill, outline = _STRUCTURE_COLORS.get(name, _DEFAULT_COLOR)
        item = doc.createElement("tagItem")
        item.setAttribute("name", name)
        item.setAttribute("description", name)
        item.setAttribute("fillColor", fill)
        item.setAttribute("outlineColor", outline)
        item.setAttribute("outlineWidth", "1.0")
        item.setAttribute("outlineDash", "")
        item.setAttribute("keyShortcut", "")
        item.setAttribute("marker", "0")
        item.setAttribute("visible", "1")
        ch_group.appendChild(item)

    # Profile definitions (for SVAROG profile panel)
    profiles_el = doc.createElement("profiles")
    profiles_el.setAttribute("interval", f"{interval:.1f}")
    profiles_el.setAttribute("channel", channel_name)
    profiles_el.setAttribute("channelNumber", str(channel_number))
    for s in structures:
        p = doc.createElement("structure")
        p.setAttribute("name", s.get("name", ""))
        p.setAttribute("mode", s.get("mode", "count"))
        for key in ("freq_min", "freq_max", "amp_min", "amp_max",
                    "scale_min", "scale_max", "phase_min", "phase_max"):
            p.setAttribute(key, str(s.get(key, 0)))
        fill, _ = _STRUCTURE_COLORS.get(s.get("name", ""), _DEFAULT_COLOR)
        p.setAttribute("color", fill)
        profiles_el.appendChild(p)
    root.appendChild(profiles_el)

    # Tag data
    tag_data = doc.createElement("tagData")
    root.appendChild(tag_data)
    tags_el = doc.createElement("tags")
    tag_data.appendChild(tags_el)

    for d in detections:
        s = d.get("scale_s", 0) or 0
        start = max(0.0, d["t0_s"] - s)
        length = 2 * s

        tag = doc.createElement("tag")
        tag.setAttribute("type", "CHANNEL")
        tag.setAttribute("name", d["name"])
        tag.setAttribute("channelNumber", str(channel_number))
        tag.setAttribute("position", f"{start:.4f}")
        tag.setAttribute("length", f"{length:.4f}")

        ann = doc.createElement("annotation")
        ann.appendChild(doc.createTextNode(
            f"{d['name']}  {d.get('f_Hz', 0):.1f} Hz  "
            f"{d.get('amplitude_uV', 0):.0f} \u00b5V"))
        tag.appendChild(ann)
        tags_el.appendChild(tag)

    with open(tag_path, "wb") as f:
        f.write(doc.toprettyxml(encoding="utf-8"))

    logging.info("EEG profile tags saved to %s", tag_path)
    return tag_path


# ── Plotting ─────────────────────────────────────────────────────────

def _plot_profiles(detections, structures, mode, interval, total_dur,
                   channel_name, file_name, output_path):
    """Generate the multi-panel time-evolution chart.

    Parameters
    ----------
    detections : list of dict
    structures : list of dict
    mode : str
        ``"count"``, ``"percentage"``, ``"amplitudes"``, or ``"power"``.
    interval : float
        Bin width in seconds (for count/percentage modes).
    total_dur : float
        Total signal duration in seconds.
    channel_name : str
    file_name : str
    output_path : str
    """
    import matplotlib.pyplot as plt
    names = [s["name"] for s in structures]
    n_panels = len(names)
    if n_panels == 0:
        return

    fig, axes = plt.subplots(n_panels, 1, figsize=(14, 2.5 * n_panels),
                             sharex=True, squeeze=False)
    axes = axes.flatten()

    n_bins = max(1, int(np.ceil(total_dur / interval)))
    t_edges = np.arange(n_bins + 1) * interval
    t_centers = (t_edges[:-1] + t_edges[1:]) / 2

    for ax, struct in zip(axes, structures):
        name = struct["name"]
        s_mode = struct.get("mode", mode)
        if s_mode == "count":
            vals = _bin_count(detections, name, interval, total_dur)
            ax.bar(t_centers, vals, width=interval * 0.9,
                   color="#89b4fa", edgecolor="#585b70", linewidth=0.5)
            ax.set_ylabel("Count")
        elif s_mode == "percentage":
            vals = _bin_percentage(detections, name, interval, total_dur)
            ax.bar(t_centers, vals, width=interval * 0.9,
                   color="#a6e3a1", edgecolor="#585b70", linewidth=0.5)
            ax.set_ylabel("Time %")
            ax.set_ylim(0, 105)
        elif s_mode in ("occurrences", "amplitudes"):
            times, amps = _occurrence_data(detections, name, "amplitude_uV")
            if len(times) > 0:
                ax.vlines(times, 0, amps, colors="#4a90d9", linewidth=0.8)
                ax.set_ylim(0, np.max(amps) * 1.1)
            ax.set_ylabel("Amplitude [\u00b5V]")
        else:  # power
            times, pwr = _occurrence_data(detections, name, "energy_uV2")
            if len(times) > 0:
                ax.vlines(times, 0, pwr, colors="#6baed6", linewidth=0.8)
                ax.set_ylim(0, np.max(pwr) * 1.1)
            ax.set_ylabel("Energy [\u00b5V\u00b2]")

        n_det = sum(1 for d in detections if d["name"] == name)
        ax.set_title(f"{name}  [{s_mode}]  (n={n_det})",
                     loc="left", fontsize=10)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    # Long recordings (≥ 1 h) read more naturally with the time
    # axis in hours.  Tick labels are rescaled via FuncFormatter so
    # the underlying data — bin centers, vline positions — stays in
    # seconds and the rest of the plotting code is unchanged.
    axes[-1].set_xlim(0, total_dur)
    if total_dur >= 3600:
        from matplotlib.ticker import FuncFormatter
        axes[-1].xaxis.set_major_formatter(
            FuncFormatter(lambda x, _pos: f"{x / 3600:g}"))
        axes[-1].set_xlabel("Time [h]")
    else:
        axes[-1].set_xlabel("Time [s]")

    fig.suptitle(f"EEG Profiles — {channel_name}  ({file_name})",
                 fontsize=12, y=1.01)
    fig.tight_layout()

    safe_ch = channel_name.replace(" ", "_").replace("/", "-")
    modes_used = set(s.get("mode", mode) for s in structures)
    mode_tag = modes_used.pop() if len(modes_used) == 1 else "mixed"
    fname = f"{file_name}_profiles_{safe_ch}_{mode_tag}.png"
    fig.savefig(os.path.join(output_path, fname), dpi=150,
                bbox_inches="tight")
    plt.close(fig)
    logging.info("Saved EEG profiles chart: %s", fname)


# ── Book metadata helpers ────────────────────────────────────────────

def _read_book_metadata(db_path):
    """Read metadata from an empi .db book.

    Returns
    -------
    meta : dict
        Keys like ``scale_to_uV``, ``channel_names``, ``segment_tmin``,
        ``segment_tmax``, etc.
    """
    meta = {}
    try:
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            cur.execute("SELECT param, value FROM metadata")
            for param, value in cur:
                meta[param] = value
    except sqlite3.Error as e:
        logging.warning("Could not read book metadata: %s", e)
    return meta


def _segment_count(db_path):
    """Return (n_segments, n_channels) from the atoms table."""
    try:
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            cur.execute("SELECT MAX(segment_id), MAX(channel_id) FROM atoms")
            row = cur.fetchone()
            if row and row[0] is not None:
                return row[0] + 1, row[1] + 1
    except sqlite3.Error as e:
        logging.warning("EEG Profiles: could not read atom counts: %s", e)
    return 0, 0


# ── Main entry point ─────────────────────────────────────────────────

def eeg_profiles(rest, epochs, config, path, file_name):
    """Run EEG profile analysis on MP decomposition results.

    Parameters
    ----------
    rest : mne.Epochs or None
    epochs : mne.Epochs or None
    config : dict
    path : str
        Output directory root.
    file_name : str
    """
    from .mp_analysis import read_mp_results

    prof_cfg = config.get("eeg_profiles", {})
    structures = prof_cfg.get("structures", PRESETS[:2])
    if not structures:
        logging.warning("EEG profiles: no structures defined, skipping.")
        return

    mode = prof_cfg.get("mode", "count")
    channel_raw = prof_cfg.get("channel", 0)
    try:
        channel = int(channel_raw)
    except (ValueError, TypeError):
        channel = channel_raw  # resolve after reading book metadata

    # Locate the MP book
    book_path = config.get("_mp_book_path", "")
    if not book_path or not os.path.isfile(book_path):
        search_dirs = [path]
        preproc_path = config.get("_preproc_output_path", "")
        if preproc_path:
            search_dirs.append(preproc_path)
        for base_dir in search_dirs:
            mp_dir = os.path.join(base_dir, "mp_decomposition")
            if os.path.isdir(mp_dir):
                dbs = [f for f in os.listdir(mp_dir) if f.endswith(".db")]
                if dbs:
                    book_path = os.path.join(mp_dir, sorted(dbs)[-1])
                    break

    if not book_path or not os.path.isfile(book_path):
        raise FileNotFoundError(
            "EEG profiles require an MP decomposition book (.db). "
            "Run MP decomposition first.")

    meta = _read_book_metadata(book_path)
    scale_uV = float(meta.get("scale_to_uV", "1.0"))
    ch_names_str = meta.get("channel_names", "")
    ch_names = ch_names_str.split(",") if ch_names_str else []

    n_segments, n_channels = _segment_count(book_path)
    if n_segments == 0:
        logging.warning("EEG profiles: book has no atoms.")
        return

    # Segment timing
    tmin = float(meta.get("segment_tmin", "0"))
    tmax = float(meta.get("segment_tmax", "0"))
    seg_dur = tmax - tmin if tmax > tmin else 0
    total_dur = seg_dur * n_segments if seg_dur > 0 else 0

    # Bin width = MP segment length (always).  Fall back to 20 s
    # only if the book has no segment timing metadata.
    interval = seg_dur if seg_dur > 0 else 20.0

    # Fall back: compute from epoch offsets + segment duration
    if total_dur <= 0:
        epoch_offsets = meta.get("epoch_offsets", "")
        if epoch_offsets and seg_dur > 0:
            offsets = [float(x) for x in epoch_offsets.split(",")]
            total_dur = max(offsets) + seg_dur if offsets else 0
        elif epoch_offsets:
            offsets = [float(x) for x in epoch_offsets.split(",")]
            if len(offsets) >= 2:
                # Estimate segment duration from offset spacing
                seg_dur = offsets[1] - offsets[0]
                total_dur = max(offsets) + seg_dur

    # Fall back to signal duration from MNE data
    if total_dur <= 0:
        data = epochs if epochs is not None else rest
        if data is not None:
            total_dur = len(data) * (data.times[-1] - data.times[0])
    if total_dur <= 0:
        logging.warning("EEG profiles: cannot determine signal duration. "
                        "Book metadata: segment_tmin=%s, segment_tmax=%s, "
                        "n_segments=%d, epoch_offsets=%s",
                        meta.get("segment_tmin"), meta.get("segment_tmax"),
                        n_segments, meta.get("epoch_offsets", "")[:100])
        return

    out_dir = os.path.join(path, "eeg_profiles")
    os.makedirs(out_dir, exist_ok=True)

    # Resolve channel name to index if given as string
    if isinstance(channel, str):
        if ch_names and channel in ch_names:
            channel = ch_names.index(channel)
        else:
            raise ValueError(
                f"Channel '{channel}' not found in MP book channels: "
                f"{ch_names}.\n"
                f"Either:\n"
                f"  • Set eeg_profiles.channel to one of: "
                f"{', '.join(ch_names)}, OR\n"
                f"  • Re-run with MP Decomposition checked AND\n"
                f"    matching_pursuit.channels set to include "
                f"'{channel}'\n"
                f"    (or 'all' for all EEG channels) — this will "
                f"rewrite the book.")
    # Validate integer index against the book's actual channel count
    if ch_names and channel >= len(ch_names):
        logging.warning(
            "EEG profiles: channel index %d is out of range "
            "(book has %d channel(s): %s). Using channel 0.",
            channel, len(ch_names), ", ".join(ch_names))
        channel = 0
    channel_name = ch_names[channel] if channel < len(ch_names) else \
        f"ch{channel}"
    logging.info("EEG profiles: channel=%s, %d structures, mode=%s, "
                 "interval=%.1fs, %d segments",
                 channel_name, len(structures), mode, interval, n_segments)

    # Collect atoms from all segments for the selected channel
    all_detections = []
    for seg_id in range(n_segments):
        atoms = read_mp_results(book_path, segment_id=seg_id,
                                channel_id=channel)
        # Offset atom times by segment position
        epoch_offsets = meta.get("epoch_offsets", "")
        if epoch_offsets:
            offsets = [float(x) for x in epoch_offsets.split(",")]
            t_offset = offsets[seg_id] if seg_id < len(offsets) else \
                seg_id * seg_dur
        else:
            t_offset = seg_id * seg_dur

        for a in atoms:
            a["t0_s"] = a["t0_s"] + t_offset

        dets = detect_structures(atoms, structures, scale_uV)
        all_detections.extend(dets)

    logging.info("EEG profiles: %d total detections across %d segments.",
                 len(all_detections), n_segments)

    # Save detection table as CSV
    if all_detections:
        import pandas as pd
        df = pd.DataFrame(all_detections)
        csv_path = os.path.join(
            out_dir, f"{file_name}_profiles_{channel_name}.csv")
        df.to_csv(csv_path, index=False, float_format="%.6f")
        logging.info("Saved detection table: %s", csv_path)

    # Export SVAROG .tag file with detected structures
    if all_detections:
        _save_detection_tags(all_detections, structures,
                             channel_name, file_name, out_dir,
                             channel_number=channel,
                             interval=interval)

    # Generate chart
    _plot_profiles(all_detections, structures, mode, interval, total_dur,
                   channel_name, file_name, out_dir)
