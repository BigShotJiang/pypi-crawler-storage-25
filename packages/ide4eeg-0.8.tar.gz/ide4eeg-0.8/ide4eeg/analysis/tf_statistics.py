### Piotr Durka

"""Time-frequency statistics for ERD/ERS significance testing.

Implements the methodology from Durka et al. (2004) "Time-frequency
microstructure and statistical significance of ERD/ERS", IEEE Trans.
Biomed. Eng., extended by Żygierewicz et al. (2005) "Computationally
efficient approaches to calculating significant ERD/ERS changes",
J. Neurosci. Methods.

Computes per-trial energy maps from MP books (SMP), STFT spectrograms,
or CWT scalograms (wavelet), tests each resolution element (resel)
against a reference baseline, and applies multiple-comparison
corrections (FDR, Bonferroni-Holmes, full Bonferroni).

Statistical tests available:
- ``pseudo_t``    — bootstrap pseudo-t (Durka et al. 2004), resampling
- ``permutation`` — direct permutation test on mean differences
- ``t_test``      — parametric t-test on Box-Cox transformed data
                    (Żygierewicz et al. 2005), no resampling needed
- ``welch_t``     — Welch's t-test with Satterthwaite degrees of freedom
                    for unequal variances (Żygierewicz et al. 2005)

Epochs-only analysis — rest data is ignored.
"""

# Author: Piotr Durka, 2026

import logging
import os
import sqlite3

import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erf

from . import _safe_tag


# =====================================================================
#  Public orchestrator
# =====================================================================

def tf_statistics_analysis(rest, epochs, config, path, file_name):
    """Run ERD/ERS significance analysis on epoch data.

    Parameters
    ----------
    rest : mne.Epochs or None
        Ignored (requires event-locked epochs).
    epochs : mne.Epochs or None
        Clean epochs.
    config : dict
        Full configuration dictionary.
    path : str
        Analysis output directory.
    file_name : str
        Input file name (for plot titles / output naming).
    """
    if epochs is None or len(epochs) == 0:
        logging.warning(
            "TF Statistics: skipped — no event-locked epochs available. "
            "This analysis requires epochs with a defined baseline.")
        return

    tf_path = os.path.join(path, "tf_statistics")
    os.makedirs(tf_path, exist_ok=True)

    cfg = config.get("tf_statistics", {})
    source = cfg.get("source", "MP").upper()
    sfreq = config["sfreq"]

    dt = float(cfg.get("dt", 0.5))
    df = float(cfg.get("df", 1.0))
    f_min = float(cfg.get("f_min", 0))
    f_max = float(cfg.get("f_max", 0)) or sfreq / 2
    # Clamp to Nyquist — STFT/wavelet at f > sfreq/2 is meaningless
    # and downstream code may produce NaN columns or overflow.
    if f_max > sfreq / 2:
        logging.warning(
            "tf_statistics: f_max=%.1f Hz exceeds Nyquist (%.1f Hz); "
            "clamping to Nyquist.",
            f_max, sfreq / 2)
        f_max = sfreq / 2
    ref_start = float(cfg.get("ref_period_start", 0))
    ref_end = float(cfg.get("ref_period_end", 0))
    test_method = cfg.get("test", "t_test")
    n_rep = int(cfg.get("n_repetitions", 1_000_000))
    correction = cfg.get("correction", "fdr")
    p_level = float(cfg.get("p_level", 0.05))
    # Floor to 100 reps — anything lower produces meaningless null
    # distributions for permutation / bootstrap tests (e.g. n_rep=10
    # at p_level=0.05 gives at most 20 distinguishable p-values).
    if n_rep < 100 and test_method in ("pseudo_t", "permutation"):
        logging.warning(
            "tf_statistics: n_repetitions=%d is too low for %s; "
            "raising to 100 (the practical floor for resolving "
            "p<%.3g).",
            n_rep, test_method, p_level)
        n_rep = 100
    fdr_q = float(cfg.get("fdr_q", 0.05))
    energy_scale = cfg.get("energy_scale", "sqrt")
    scale_min = float(cfg.get("filter_scale_min", 0))
    scale_max = float(cfg.get("filter_scale_max", 0))
    freq_min_filter = float(cfg.get("filter_freq_min", 0))
    freq_max_filter = float(cfg.get("filter_freq_max", 0))
    amp_min_filter = float(cfg.get("filter_amp_min", 0))
    amp_max_filter = float(cfg.get("filter_amp_max", 0))
    max_iter_filter = int(cfg.get("filter_max_iterations", 0))
    if "cpu_workers" in cfg:
        logging.warning(
            "tf_statistics.cpu_workers is ignored — parallelism is now "
            "controlled globally by parallelism.n_jobs (Config tab → "
            "'Parallel jobs'). See CONTRIBUTING.md §Parallelism.")
    cancel_event = config.get("_cancel_event")
    stft_window = float(cfg.get("stft_window", 0))
    wavelet_name = cfg.get("wavelet_name", "morlet2")
    wavelet_w = float(cfg.get("wavelet_w", 6.0))
    margin = float(cfg.get("time_margin", 0))
    event_time = cfg.get("event_time", None)
    if event_time is not None and event_time != "" and event_time != 0:
        event_time = float(event_time)
    else:
        event_time = None
    plot_significance = cfg.get("plot_significance", True)
    plot_erds = cfg.get("plot_erds", True)
    plot_energy = cfg.get("plot_energy", True)
    event_name = cfg.get("event_name", "event") or "event"
    colormap = cfg.get("colormap", "jet")
    transform = cfg.get("transform", "boxcox")
    normality_test = cfg.get("normality_test", False)
    plot_histograms = cfg.get("plot_histograms", False)

    base = os.path.splitext(file_name)[0]

    # Validate MP books exist before proceeding
    if source == "MP":
        eeg_chs = [ch for ch, ct in zip(epochs.ch_names,
                    epochs.get_channel_types()) if ct == "eeg"]
        missing = [ch for ch in eeg_chs if not _find_smp_book(config, ch)]
        if missing:
            msg = (f"TF Statistics: MP source selected but no SMP books found "
                   f"for {len(missing)}/{len(eeg_chs)} channels. "
                   f"Run MP decomposition first.")
            if len(missing) == len(eeg_chs):
                logging.error(msg + " Aborting TF statistics.")
                raise RuntimeError(msg)
            else:
                logging.warning(msg + " Channels without books will be skipped.")

    # Epoch timing
    t_offset = config.get("epochs", {}).get("start_offset", 0.0)
    if isinstance(t_offset, str):
        t_offset = float(t_offset) if t_offset else 0.0

    epochs.load_data()

    for tag in epochs.event_id.keys():
        subset = epochs[tag]
        if len(subset) == 0:
            logging.warning("TF Statistics: no epochs for tag '%s'", tag)
            continue

        ch_types = subset.get_channel_types()
        data_picks = [ch for ch, ct in zip(subset.info["ch_names"], ch_types)
                      if ct not in ("stim", "misc", "eog", "emg")]
        if not data_picks:
            data_picks = subset.info["ch_names"]
        signals = subset.get_data(picks=data_picks)
        n_ep, n_ch, n_samples = signals.shape

        for ch_idx, ch_name in enumerate(data_picks):
            logging.info("TF Statistics: %s / %s (%d epochs)",
                         tag, ch_name, n_ep)

            # -- Compute per-trial resel maps -------------------------
            hires_map = None  # high-res average map (MP / WT)
            t_hi = f_hi = None
            if source == "MP":
                book_path = _find_smp_book(config, ch_name)
                if not book_path:
                    logging.error(
                        "TF Statistics: SMP book not found for '%s'. "
                        "Run MP decomposition first.", ch_name)
                    continue
                resel_maps, t_axis, f_axis = compute_resel_maps_mp(
                    book_path, ch_name, n_samples, sfreq,
                    dt, df, f_min, f_max, t_offset,
                    scale_min, scale_max,
                    freq_min_filter, freq_max_filter,
                    amp_min_filter, amp_max_filter,
                    max_iter_filter)
                # High-res map for display (1-sample time, 1 Hz freq)
                logging.info("  Computing high-resolution Wigner map...")
                hires_map, t_hi, f_hi = compute_hires_map_mp(
                    book_path, ch_name, n_samples, sfreq,
                    f_min, f_max, t_offset,
                    scale_min, scale_max,
                    freq_min_filter, freq_max_filter,
                    amp_min_filter, amp_max_filter,
                    max_iter_filter)
            elif source == "WT":
                resel_maps, t_axis, f_axis = compute_resel_maps_wt(
                    signals[:, ch_idx, :], sfreq,
                    dt, df, f_min, f_max, t_offset,
                    wavelet_name, wavelet_w)
                logging.info("  Computing high-resolution CWT map...")
                hires_map, t_hi, f_hi = compute_hires_map_wt(
                    signals[:, ch_idx, :], sfreq,
                    f_min, f_max, t_offset,
                    wavelet_name, wavelet_w)
            else:
                resel_maps, t_axis, f_axis = compute_resel_maps_stft(
                    signals[:, ch_idx, :], sfreq,
                    dt, df, f_min, f_max, t_offset,
                    stft_window)

            if resel_maps is None or resel_maps.shape[0] == 0:
                logging.warning(
                    "TF Statistics: no data for %s / %s", tag, ch_name)
                continue

            n_trials, n_freq, n_time = resel_maps.shape
            logging.info("  Resel grid: %d freq x %d time, %d trials",
                         n_freq, n_time, n_trials)

            # Keep raw maps for energy plot (before scale transform)
            raw_resel_maps = resel_maps.copy()

            # -- Energy scale transform --------------------------------
            if energy_scale == "log":
                resel_maps = np.log1p(resel_maps)
            elif energy_scale == "sqrt":
                resel_maps = np.sqrt(resel_maps)

            # -- Reference period → column indices --------------------
            ref_idx = _ref_indices(t_axis, ref_start, ref_end)
            if len(ref_idx) == 0:
                logging.error(
                    "  Reference period [%.1f, %.1f]s yields no resels "
                    "(time axis: %.2f – %.2f s). Skipping.",
                    ref_start, ref_end, t_axis[0], t_axis[-1])
                continue
            logging.info("  Reference: columns %d–%d (%.2f–%.2f s)",
                         ref_idx[0], ref_idx[-1],
                         t_axis[ref_idx[0]], t_axis[ref_idx[-1]])

            # -- Margin columns to exclude ----------------------------
            margin_cols = int(round(margin / dt)) if margin > 0 else 0

            # -- ERD/ERS map -------------------------------------------
            erds = erds_map(resel_maps, ref_idx)

            # -- Box-Cox transformation (for parametric tests) ----------
            if test_method in ("t_test", "welch_t") and transform == "boxcox":
                resel_maps, bc_lambdas = box_cox_transform(
                    resel_maps, ref_idx)
                logging.info("  Box-Cox transform applied (λ per freq bin)")
            elif test_method in ("t_test", "welch_t") and transform == "none":
                logging.info("  Parametric test without transform — "
                             "data assumed approximately normal")
                bc_lambdas = None
            else:
                bc_lambdas = None

            # -- Normality test (optional) -----------------------------
            if normality_test and test_method in ("t_test", "welch_t"):
                norm_pass = check_normality(resel_maps, ref_idx)
                n_pass = np.sum(norm_pass)
                logging.info("  Normality (Lilliefors): %d/%d freq bins "
                             "pass at α=0.05", n_pass, n_freq)

            # -- Distribution histograms (optional) --------------------
            if plot_histograms:
                _plot_histograms(
                    resel_maps, ref_idx, f_axis,
                    tag, ch_name, tf_path, base,
                    transform_name=transform if bc_lambdas is not None
                    else "none")

            # -- Statistical test --------------------------------------
            if test_method == "pseudo_t":
                p_map = bootstrap_pseudo_t(
                    resel_maps, ref_idx, n_rep, cancel_event=cancel_event)
            elif test_method == "permutation":
                p_map = permutation_test(
                    resel_maps, ref_idx, n_rep, cancel_event=cancel_event)
            elif test_method == "t_test":
                p_map = parametric_ttest(resel_maps, ref_idx)
            elif test_method == "welch_t":
                p_map = welch_ttest(resel_maps, ref_idx)
            else:
                logging.warning("Unknown test method '%s', using pseudo_t",
                                test_method)
                p_map = bootstrap_pseudo_t(
                    resel_maps, ref_idx, n_rep, cancel_event=cancel_event)

            # Set reference and margin columns to p=1
            p_map[:, ref_idx] = 1.0
            if margin_cols > 0:
                p_map[:, -margin_cols:] = 1.0

            # -- Multiple comparison correction -----------------------
            test_cols = _test_columns(n_time, ref_idx, margin_cols)
            corr_lc = correction.lower().replace("-", "")
            if corr_lc in ("fdr",):
                accepted, adj_p = fdr_correction(
                    p_map, fdr_q, ref_idx, margin_cols)
            elif corr_lc in ("bh", "holmbonferroni"):
                accepted, adj_p = bh_correction(
                    p_map, p_level, ref_idx, margin_cols)
            elif corr_lc in ("bonferroni",):
                accepted, adj_p = bonferroni_correction(
                    p_map, p_level, ref_idx, margin_cols)
            else:
                accepted = p_map < p_level
            # Zero out reference + margin in accepted
            accepted[:, ref_idx] = False
            if margin_cols > 0:
                accepted[:, -margin_cols:] = False

            n_sig = int(np.sum(accepted))
            n_tested = len(test_cols) * n_freq

            # Effective p-threshold (largest p among accepted resels)
            if n_sig > 0:
                eff_p = float(np.max(p_map[accepted]))
            else:
                eff_p = 0.0

            logging.info("  %s: %d / %d resels significant",
                         correction.upper(), n_sig, n_tested)

            # -- Plots ------------------------------------------------
            src_label = {"MP": "MP", "WT": "WT"}.get(source, "FT")
            prefix = os.path.join(tf_path,
                                  f"{base}_ERDS_{src_label}_{_safe_tag(tag)}_{ch_name}")
            if plot_significance:
                _plot_erds_significance(
                    erds, accepted, t_axis, f_axis, ref_idx,
                    margin_cols, tag, ch_name, n_ep,
                    test_method, correction, n_rep, eff_p,
                    src_label,
                    prefix + "_significance.png",
                    trigger_t=event_time,
                    event_label=event_name,
                    hires_map=hires_map, t_hi=t_hi, f_hi=f_hi,
                    ref_start=ref_start, ref_end=ref_end,
                    cmap=colormap)

            if plot_erds:
                _plot_erds_raw(
                    erds, t_axis, f_axis, ref_idx, margin_cols,
                    tag, ch_name, n_ep, src_label,
                    prefix + "_erds.png",
                    trigger_t=event_time,
                    event_label=event_name,
                    hires_map=hires_map, t_hi=t_hi, f_hi=f_hi,
                    ref_start=ref_start, ref_end=ref_end,
                    cmap=colormap)

            if plot_energy:
                _plot_energy_map(
                    raw_resel_maps, t_axis, f_axis,
                    tag, ch_name, n_ep, src_label,
                    prefix + "_energy.png",
                    trigger_t=event_time,
                    event_label=event_name,
                    hires_map=hires_map, t_hi=t_hi, f_hi=f_hi,
                    ref_start=ref_start, ref_end=ref_end)

    logging.info("TF Statistics outputs saved to %s", tf_path)


# =====================================================================
#  Per-trial energy maps — MP (SMP book)
# =====================================================================

def compute_resel_maps_mp(book_path, ch_name, n_samples, sfreq,
                          dt, df, f_min, f_max, t_offset,
                          scale_min=0, scale_max=0,
                          freq_min_filter=0, freq_max_filter=0,
                          amp_min=0, amp_max=0,
                          max_iterations=0):
    """Compute per-trial Wigner energy maps from an SMP book.

    Uses integral (erf-based) resel binning from Durka et al. (2004),
    not point-sampled Gaussians.

    Returns
    -------
    maps : ndarray (n_segments, n_freq, n_time) or None
    t_axis : ndarray — resel center times (s)
    f_axis : ndarray — resel center frequencies (Hz)
    """
    # Use a context manager so the SQLite connection is closed even
    # if a numpy / Wigner exception aborts the loop below — leaks
    # were possible on Windows where the .db file would stay locked
    # against subsequent runs.
    try:
        conn = sqlite3.connect(book_path)
    except sqlite3.Error as e:
        logging.error("Cannot open book at %s: %s", book_path, e)
        return None, None, None
    try:
        try:
            meta = dict(conn.execute("SELECT param, value FROM metadata"))
            n_segments = int(meta.get("segment_count", 1))
            n_book_ch = int(meta.get("channel_count", 1))
            book_ch_names = meta.get("channel_names", "").split(",")
            if len(book_ch_names) != n_book_ch:
                book_ch_names = [f"Ch{i}" for i in range(n_book_ch)]
        except sqlite3.Error as e:
            logging.error("Cannot read book metadata: %s", e)
            return None, None, None

        # Find channel index
        if ch_name in book_ch_names:
            ch_idx = book_ch_names.index(ch_name)
        else:
            logging.warning("Channel '%s' not in book channels %s, using 0",
                            ch_name, book_ch_names)
            ch_idx = 0

        # Build resel grid
        duration = n_samples / sfreq
        n_time = int(round(duration / dt))
        n_freq = int(round((f_max - f_min) / df))
        if n_time < 1 or n_freq < 1:
            return None, None, None

        # Resel edges and centers (in seconds / Hz)
        t_edges = np.linspace(t_offset, t_offset + duration, n_time + 1)
        f_edges = np.linspace(f_min, f_max, n_freq + 1)
        t_axis = 0.5 * (t_edges[:-1] + t_edges[1:])
        f_axis = 0.5 * (f_edges[:-1] + f_edges[1:])

        # Signal support boundaries (in seconds / Hz) for normalization
        sig_t_min = t_offset
        sig_t_max = t_offset + duration
        sig_f_min = 0.0
        sig_f_max = sfreq / 2

        maps = np.zeros((n_segments, n_freq, n_time))

        for seg in range(n_segments):
            try:
                rows = conn.execute(
                    "SELECT iteration, amplitude, energy, f_Hz, scale_s, "
                    "t0_s, envelope "
                    "FROM atoms WHERE segment_id=? AND channel_id=? "
                    "ORDER BY iteration",
                    [seg, ch_idx]).fetchall()
            except sqlite3.Error as e:
                logging.warning("Error reading segment %d: %s", seg, e)
                continue

            for iteration, amp, energy, f_hz, scale_s, t0_s, envelope in rows:
                if envelope != "gauss" or scale_s <= 0:
                    continue
                if energy <= 0:
                    continue
                # Atom filters
                if scale_min > 0 and scale_s < scale_min:
                    continue
                if scale_max > 0 and scale_s > scale_max:
                    continue
                if freq_min_filter > 0 and f_hz < freq_min_filter:
                    continue
                if freq_max_filter > 0 and f_hz > freq_max_filter:
                    continue
                if amp_min > 0 and abs(amp) < amp_min:
                    continue
                if amp_max > 0 and abs(amp) > amp_max:
                    continue
                if max_iterations > 0 and iteration >= max_iterations:
                    continue

                # Wigner weight: use the empi 'energy' field, which is
                # proportional to modulus² (= MATLAB's book(:,4).^2).
                # Empirically: energy = amp² × scale / (2√2), so energy
                # tracks modulus² regardless of atom parameterization.
                # Using amp² directly is wrong because (a) it lacks the
                # scale factor, and (b) near-DC/Dirac-like atoms have
                # pathological amplitude values.
                atom_weight = energy

                maps[seg] += _wigner_resel_integral(
                    atom_weight, t0_s, f_hz, scale_s,
                    t_edges, f_edges,
                    sig_t_min, sig_t_max, sig_f_min, sig_f_max)

        return maps, t_axis, f_axis
    finally:
        conn.close()


def _wigner_resel_integral(energy, t0, f0, scale,
                           t_edges, f_edges,
                           sig_t_min, sig_t_max,
                           sig_f_min, sig_f_max):
    """Integrate Wigner-Ville auto-term of a Gabor atom over resels.

    Uses error-function integration (Durka et al. 2003, wignermap.m):
    the integral of exp(-a*x^2) over [lo,hi] is proportional to
    erf(sqrt(a)*hi) - erf(sqrt(a)*lo).

    Returns (n_freq, n_time) contribution array.
    """
    SQRT_PI = np.sqrt(np.pi)
    TWO_SQRT_PI = 2.0 * SQRT_PI

    # Time dimension: erf((2*sqrt(pi)/scale) * (t - t0))
    t_lo = t_edges[:-1]
    t_hi = t_edges[1:]
    gt_lo = (TWO_SQRT_PI / scale) * (t_lo - t0)
    gt_hi = (TWO_SQRT_PI / scale) * (t_hi - t0)
    h_t = erf(gt_hi) - erf(gt_lo)  # (n_time,)

    # Frequency dimension: erf((sqrt(pi)*scale) * (f - f0))
    # Note: the MATLAB code uses scale/dimBase * (f_points - freq_points).
    # Converting to Hz: scale_s * (f_Hz - f0_Hz) is the same thing
    # because scale_s = scale_pts / Fsamp and f_Hz = f_pts * Fsamp / dimBase.
    f_lo = f_edges[:-1]
    f_hi = f_edges[1:]
    gf_lo = (SQRT_PI * scale) * (f_lo - f0)
    gf_hi = (SQRT_PI * scale) * (f_hi - f0)
    h_f = erf(gf_hi) - erf(gf_lo)  # (n_freq,)

    # Normalization: integral over full signal support
    norm_t = erf((TWO_SQRT_PI / scale) * (sig_t_max - t0)) \
           - erf((TWO_SQRT_PI / scale) * (sig_t_min - t0))
    norm_f = erf((SQRT_PI * scale) * (sig_f_max - f0)) \
           - erf((SQRT_PI * scale) * (sig_f_min - f0))
    norm = norm_t * norm_f

    if abs(norm) < 1e-30:
        return np.zeros((len(f_lo), len(t_lo)))

    return energy * np.outer(h_f, h_t) / norm


# =====================================================================
#  High-resolution average Wigner map (MP only, for display)
# =====================================================================

def compute_hires_map_mp(book_path, ch_name, n_samples, sfreq,
                         f_min, f_max, t_offset,
                         scale_min=0, scale_max=0,
                         freq_min_filter=0, freq_max_filter=0,
                         amp_min=0, amp_max=0,
                         max_iterations=0):
    """Compute the trial-averaged high-resolution Wigner map.

    Reuses the same ``compute_wigner_map`` from ``mp_analysis`` that
    powers the interactive Book Viewer, ensuring identical rendering.
    Energy is scaled to µV².

    Returns
    -------
    avg_map : ndarray (n_freq_hi, n_time_hi) — average energy density
    t_hi : ndarray — time axis
    f_hi : ndarray — frequency axis
    """
    from .mp_analysis import compute_wigner_map

    try:
        conn = sqlite3.connect(book_path)
    except sqlite3.Error as e:
        logging.error("Cannot open book at %s: %s", book_path, e)
        return None, None, None
    try:
        try:
            meta = dict(conn.execute("SELECT param, value FROM metadata"))
            n_segments = int(meta.get("segment_count", 1))
            n_book_ch = int(meta.get("channel_count", 1))
            book_ch_names = meta.get("channel_names", "").split(",")
            if len(book_ch_names) != n_book_ch:
                book_ch_names = [f"Ch{i}" for i in range(n_book_ch)]
        except sqlite3.Error as e:
            logging.error("Cannot read book metadata: %s", e)
            return None, None, None

        ch_idx = (book_ch_names.index(ch_name)
                  if ch_name in book_ch_names else 0)
        scale_uv = float(meta.get("scale_to_uV", 1.0))
        scale2 = scale_uv ** 2

        # Resolution: cap at 512 bins per axis for speed
        n_tbins = min(n_samples, 512)
        n_fbins = min(int(round((f_max - f_min) * 4)), 512)  # ~0.25 Hz

        avg_map = None

        for seg in range(n_segments):
            try:
                rows = conn.execute(
                    "SELECT iteration, amplitude, energy, envelope, "
                    "f_Hz, phase, scale_s, t0_s, t0_abs_s "
                    "FROM atoms WHERE segment_id=? AND channel_id=? "
                    "ORDER BY iteration",
                    [seg, ch_idx]).fetchall()
            except sqlite3.Error:
                continue

            # Convert to list-of-dicts (same format as read_mp_results)
            atoms = []
            for row in rows:
                a = {"iteration": row[0], "amplitude": row[1],
                     "energy": row[2], "envelope": row[3],
                     "f_Hz": row[4], "phase": row[5],
                     "scale_s": row[6], "t0_s": row[7]}
                # Scale energy to µV²
                a["energy"] = a.get("energy", a["amplitude"] ** 2) * scale2
                # Apply atom filters
                if a["envelope"] != "gauss" or a["scale_s"] is None \
                        or a["scale_s"] <= 0:
                    continue
                if a["f_Hz"] is None or a["t0_s"] is None:
                    continue
                if scale_min > 0 and a["scale_s"] < scale_min:
                    continue
                if scale_max > 0 and a["scale_s"] > scale_max:
                    continue
                if freq_min_filter > 0 and a["f_Hz"] < freq_min_filter:
                    continue
                if freq_max_filter > 0 and a["f_Hz"] > freq_max_filter:
                    continue
                if amp_min > 0 and abs(a["amplitude"]) < amp_min:
                    continue
                if amp_max > 0 and abs(a["amplitude"]) > amp_max:
                    continue
                if max_iterations > 0 and a["iteration"] >= max_iterations:
                    continue
                atoms.append(a)

            wigner, t_bins, f_bins = compute_wigner_map(
                atoms, n_samples, sfreq,
                n_time_bins=n_tbins, n_freq_bins=n_fbins,
                time_offset=t_offset, freq_max=f_max)

            if avg_map is None:
                avg_map = wigner
            else:
                avg_map += wigner
    finally:
        conn.close()

    if avg_map is None:
        return None, None, None

    avg_map /= n_segments

    # Trim to f_min (compute_wigner_map always starts at 0)
    if f_min > 0:
        f_mask = f_bins >= f_min
        avg_map = avg_map[f_mask, :]
        f_bins = f_bins[f_mask]

    return avg_map, t_bins, f_bins


# =====================================================================
#  Per-trial energy maps — STFT
# =====================================================================

def compute_resel_maps_stft(signals, sfreq, dt, df, f_min, f_max,
                            t_offset, stft_window=0):
    """Compute per-trial spectrograms binned into resels.

    Parameters
    ----------
    signals : ndarray (n_trials, n_samples)
    sfreq : float
    dt, df : float — resel dimensions
    f_min, f_max : float
    t_offset : float — epoch start time
    stft_window : float — STFT window length in seconds (0 = auto: 2*dt)

    Returns
    -------
    maps : ndarray (n_trials, n_freq, n_time) or None
    t_axis, f_axis : ndarray
    """
    from scipy.signal import spectrogram

    n_trials, n_samples = signals.shape
    duration = n_samples / sfreq

    # STFT window: explicit or auto (2*dt with 50% overlap → dt spacing)
    win_s = stft_window if stft_window > 0 else 2 * dt
    nperseg = int(round(win_s * sfreq))
    if nperseg < 4:
        nperseg = 4
    noverlap = nperseg // 2
    nfft = max(nperseg, int(round(sfreq / df)))  # ensure df resolution

    n_time = int(round(duration / dt))
    n_freq = int(round((f_max - f_min) / df))
    if n_time < 1 or n_freq < 1:
        return None, None, None

    t_centers = np.linspace(t_offset + dt / 2,
                            t_offset + duration - dt / 2, n_time)
    f_centers = np.linspace(f_min + df / 2,
                            f_max - df / 2, n_freq)

    maps = np.zeros((n_trials, n_freq, n_time))

    for trial in range(n_trials):
        f_stft, t_stft, Sxx = spectrogram(
            signals[trial], fs=sfreq,
            nperseg=nperseg, noverlap=noverlap, nfft=nfft,
            window="hann", mode="psd")

        t_stft += t_offset  # shift to epoch time

        # Bin into resel grid
        for fi in range(n_freq):
            f_lo = f_centers[fi] - df / 2
            f_hi = f_centers[fi] + df / 2
            f_mask = (f_stft >= f_lo) & (f_stft < f_hi)
            if not np.any(f_mask):
                continue
            for ti in range(n_time):
                t_lo = t_centers[ti] - dt / 2
                t_hi = t_centers[ti] + dt / 2
                t_mask = (t_stft >= t_lo) & (t_stft < t_hi)
                if not np.any(t_mask):
                    continue
                maps[trial, fi, ti] = np.mean(
                    Sxx[np.ix_(f_mask, t_mask)])

    return maps, t_centers, f_centers


# =====================================================================
#  Per-trial energy maps — Wavelet (CWT)
# =====================================================================

def _cwt(signal, freqs, sfreq, wavelet_name, wavelet_w=6.0):
    """Compute CWT power using FFT-based convolution.

    Replaces scipy.signal.cwt + morlet2/ricker which were removed in
    scipy 1.15.  Faithfully reproduces the old scipy implementation.

    Returns
    -------
    power : ndarray (n_freqs, n_samples) — |CWT|²
    """
    from scipy.signal import fftconvolve

    n = len(signal)
    power = np.empty((len(freqs), n))

    for i, freq in enumerate(freqs):
        if wavelet_name == "morlet2":
            width = wavelet_w * sfreq / (2 * np.pi * freq)
        else:  # ricker
            width = sfreq / (np.sqrt(2.0 / 3.0) * np.pi * freq)

        M = int(min(10 * width, n))
        if M < 1:
            M = 1
        x = (np.arange(0, M) - (M - 1.0) / 2) / width

        if wavelet_name == "morlet2":
            psi = (np.pi ** -0.25) * np.exp(
                1j * wavelet_w * x) * np.exp(-0.5 * x ** 2)
        else:  # ricker
            A = 2.0 / (np.sqrt(3 * width) * np.pi ** 0.25)
            psi = A * (1 - x ** 2) * np.exp(-x ** 2 / 2)

        coef = fftconvolve(signal, np.conj(psi)[::-1], mode="same")
        power[i] = np.abs(coef) ** 2

    return power


def compute_resel_maps_wt(signals, sfreq, dt, df, f_min, f_max,
                          t_offset, wavelet_name="morlet2", wavelet_w=6.0):
    """Compute per-trial CWT scalograms binned into resels.

    Parameters
    ----------
    signals : ndarray (n_trials, n_samples)
    sfreq : float
    dt, df : float — resel dimensions
    f_min, f_max : float
    t_offset : float — epoch start time
    wavelet_name : str — "morlet2" or "ricker"
    wavelet_w : float — Morlet w parameter (ignored for ricker)

    Returns
    -------
    maps : ndarray (n_trials, n_freq, n_time) or None
    t_axis, f_axis : ndarray
    """
    n_trials, n_samples = signals.shape
    duration = n_samples / sfreq

    n_time = int(round(duration / dt))
    n_freq = int(round((f_max - f_min) / df))
    if n_time < 1 or n_freq < 1:
        return None, None, None

    t_centers = np.linspace(t_offset + dt / 2,
                            t_offset + duration - dt / 2, n_time)
    f_centers = np.linspace(f_min + df / 2,
                            f_max - df / 2, n_freq)

    # CWT frequency grid — finer than resel grid for accurate binning
    n_cwt_freqs = max(n_freq * 4, 128)
    cwt_freqs = np.linspace(max(f_min, 0.1), f_max, n_cwt_freqs)

    t_cwt = np.linspace(t_offset, t_offset + duration, n_samples)

    maps = np.zeros((n_trials, n_freq, n_time))

    for trial in range(n_trials):
        power = _cwt(signals[trial], cwt_freqs, sfreq,
                     wavelet_name, wavelet_w)

        # Bin into resel grid
        for fi in range(n_freq):
            f_lo = f_centers[fi] - df / 2
            f_hi_b = f_centers[fi] + df / 2
            f_mask = (cwt_freqs >= f_lo) & (cwt_freqs < f_hi_b)
            if not np.any(f_mask):
                continue
            for ti in range(n_time):
                t_lo = t_centers[ti] - dt / 2
                t_hi_b = t_centers[ti] + dt / 2
                t_mask = (t_cwt >= t_lo) & (t_cwt < t_hi_b)
                if not np.any(t_mask):
                    continue
                maps[trial, fi, ti] = np.mean(
                    power[np.ix_(f_mask, t_mask)])

    return maps, t_centers, f_centers


def compute_hires_map_wt(signals, sfreq, f_min, f_max, t_offset,
                         wavelet_name="morlet2", wavelet_w=6.0):
    """Compute trial-averaged high-resolution CWT scalogram.

    Returns
    -------
    avg_map : ndarray (n_freq, n_time) — average power density
    t_hi : ndarray — time axis
    f_hi : ndarray — frequency axis
    """
    n_trials, n_samples = signals.shape
    duration = n_samples / sfreq

    n_fbins = min(int(round((f_max - f_min) * 4)), 512)
    cwt_freqs = np.linspace(max(f_min, 0.1), f_max, n_fbins)

    avg_map = None

    for trial in range(n_trials):
        power = _cwt(signals[trial], cwt_freqs, sfreq,
                     wavelet_name, wavelet_w)

        if avg_map is None:
            avg_map = power.copy()
        else:
            avg_map += power

    avg_map /= n_trials

    # Downsample time axis if needed
    n_tbins = min(n_samples, 512)
    if n_samples > n_tbins:
        step = n_samples // n_tbins
        usable = n_tbins * step
        avg_map = avg_map[:, :usable].reshape(
            avg_map.shape[0], n_tbins, step).mean(axis=2)

    t_hi = np.linspace(t_offset, t_offset + duration, avg_map.shape[1])
    f_hi = cwt_freqs

    return avg_map, t_hi, f_hi


# =====================================================================
#  ERD/ERS map
# =====================================================================

def erds_map(resel_maps, ref_idx):
    """Compute ERD/ERS as relative change from baseline.

    Only computed for columns *after* the reference period
    (Durka et al. 2003 convention).  Reference and pre-reference
    columns are set to zero.

    Returns (n_freq, n_time) array: (E - E_ref) / E_ref.
    Negative = ERD (desynchronization), positive = ERS (synchronization).
    """
    mean_map = np.mean(resel_maps, axis=0)  # (n_freq, n_time)
    baseline = np.mean(mean_map[:, ref_idx], axis=1, keepdims=True)
    baseline = np.where(np.abs(baseline) < 1e-30, 1e-30, baseline)
    erds = np.zeros_like(mean_map)
    # Only compute for columns after the reference period
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
    erds[:, post_ref:] = (mean_map[:, post_ref:] - baseline) / baseline
    return erds


# =====================================================================
#  Bootstrap pseudo-t test
# =====================================================================
#
# Parallelism, Stop-button cancellation, and elapsed-time logging
# are handled by the shared helpers in :mod:`ide4eeg.utils.parallel`.
# Each joblib.Parallel call is wrapped in
# :func:`timed_parallel_block`, which emits "<label>: starting" /
# "<label>: finished in X.XXs" and logs a WARNING as soon as the
# cancel_event fires (so Stop is visibly acknowledged even while
# workers finish their current frequency row).
#
# Stop-button latency note: cancel_event is only *checked* between
# yielded results from joblib.Parallel(return_as="generator"),
# meaning Stop takes effect up to one row's compute time after
# clicking. For pseudo-t that's sub-second (vectorised numpy).
# For permutation_test with n_rep=1_000_000 a single row can be
# 30–60 s on one core — use pseudo_t for a snappy Stop response.
# Cooperative in-worker cancel via multiprocessing.Event is the
# right long-term fix and is deferred as a TODO.

from ide4eeg.utils.parallel import timed_parallel_block

def _pseudo_t_freq_row(resel_maps, f, ref_idx, n_rep, N, N1, T_DF,
                       n_time, seed):
    """Worker: bootstrap pseudo-t for a single frequency row.

    Runs in a joblib worker. ``resel_maps`` is passed as a whole
    array — joblib auto-memmaps it for sharing between workers
    (``max_nbytes='1M'`` default), so this is NOT a per-row copy.
    We take a view ``resel_maps[:, f, :]`` locally.

    Each worker gets its own deterministic RNG seed so results are
    reproducible across runs.
    """
    freq_data = resel_maps[:, f, :]
    rng = np.random.default_rng(seed)
    chunk = min(n_rep, 200_000)

    rr = freq_data[:, ref_idx].ravel()

    h = np.empty(n_rep)
    for c0 in range(0, n_rep, chunk):
        c1 = min(c0 + chunk, n_rep)
        csz = c1 - c0
        pp1 = rr[rng.integers(0, N1, size=(csz, N1))]
        pp2 = rr[rng.integers(0, N1, size=(csz, N))]
        m1 = pp1.mean(axis=1)
        m2 = pp2.mean(axis=1)
        v1 = np.sum((pp1 - m1[:, None]) ** 2, axis=1)
        v2 = np.sum((pp2 - m2[:, None]) ** 2, axis=1)
        d = np.sqrt(T_DF * (v1 + v2))
        d = np.where(d < 1e-30, 1e-30, d)
        h[c0:c1] = (m2 - m1) / d

    mean_rr = np.mean(rr)
    var_rr = np.var(rr, ddof=0) * N1

    p_row = np.ones(n_time)
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
    for i in range(post_ref, n_time):
        point = freq_data[:, i]
        mean_pt = np.mean(point)
        var_pt = np.sum((point - mean_pt) ** 2)
        denom2 = T_DF * (var_rr + var_pt)
        point_t = ((mean_pt - mean_rr) / np.sqrt(denom2)
                   if denom2 > 0 else 0.0)
        if point_t > 0:
            p_row[i] = np.sum(h >= point_t) / n_rep
        else:
            p_row[i] = np.sum(h <= point_t) / n_rep
    return f, p_row


def bootstrap_pseudo_t(resel_maps, ref_idx, n_rep=200_000,
                       cancel_event=None):
    """Bootstrap pseudo-t test (Durka et al. 2003).

    For each frequency row, estimate the null distribution of the
    t-statistic from bootstrap resampling of the reference period,
    then compute p-values for each test resel.

    Parallelism is delegated to ``joblib.Parallel``, which inherits
    ``n_jobs`` and ``inner_max_num_threads`` from the global
    ``joblib.parallel_config(...)`` call in
    :func:`ide4eeg.main._configure_parallelism`. See
    ``CONTRIBUTING.md §"Parallelism"`` for the rationale.

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int — columns forming the reference period
    n_rep : int — number of bootstrap repetitions
    cancel_event : threading.Event or None
        If set between row completions, the remaining joblib workers
        are cancelled and ``InterruptedError`` is raised.

    Returns
    -------
    p_map : ndarray (n_freq, n_time)
    """
    from joblib import Parallel, delayed

    n_trials, n_freq, n_time = resel_maps.shape
    N = n_trials
    N1 = N * len(ref_idx)
    T_DF = (1.0 / N1 + 1.0 / N) / (N1 + N - 2)
    ref_idx_arr = np.asarray(ref_idx)

    # Deterministic per-row seeds from a master RNG — each worker
    # runs with an independent but reproducible random stream.
    master_rng = np.random.default_rng(42)
    seeds = master_rng.integers(0, 2**63, size=n_freq)

    logging.info("  pseudo-t: %d freq rows × %d reps", n_freq, n_rep)

    # verbose=0: joblib's built-in progress printer writes to stderr
    # directly, which bypasses the GUI's logging-handler queue — the
    # user sees no progress in the Run tab. We emit our own progress
    # line via logging.info from the consumer loop instead, so it
    # flows through the same logger as everything else.
    p_map = np.ones((n_freq, n_time))
    log_every = max(1, n_freq // 10)
    done = 0
    with timed_parallel_block("pseudo-t", cancel_event):
        parallel_gen = Parallel(return_as="generator", verbose=0)(
            delayed(_pseudo_t_freq_row)(
                resel_maps, f, ref_idx_arr, n_rep, N, N1, T_DF,
                n_time, int(seeds[f]),
            )
            for f in range(n_freq)
        )
        try:
            for f, p_row in parallel_gen:
                if cancel_event is not None and cancel_event.is_set():
                    raise InterruptedError(
                        "bootstrap_pseudo_t cancelled by user")
                p_map[f] = p_row
                done += 1
                if done % log_every == 0 or done == n_freq:
                    logging.info(
                        "  pseudo-t: %d/%d freq rows done",
                        done, n_freq)
        finally:
            try:
                parallel_gen.close()
            except Exception:
                pass

    # Floor at 1/n_rep (can't observe p=0 from finite samples)
    p_map = np.maximum(p_map, 1.0 / n_rep)

    return p_map


# =====================================================================
#  Permutation test
# =====================================================================

def _perm_freq_row(resel_maps, f, ref_idx, n_rep, N, n_time, seed):
    """Worker: permutation test for a single frequency row.

    See ``_pseudo_t_freq_row`` for notes on how ``resel_maps`` is
    shared across workers via joblib's auto-memmap.
    """
    freq_data = resel_maps[:, f, :]
    rng = np.random.default_rng(seed)
    rr = freq_data[:, ref_idx].ravel()
    mean_rr = np.mean(rr)

    p_row = np.ones(n_time)
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
    for i in range(post_ref, n_time):
        point = freq_data[:, i]
        real_diff = np.mean(point) - mean_rr
        pooled = np.concatenate([point, rr])
        s = len(pooled)
        s_a = N
        diffs = np.empty(n_rep)
        for k in range(n_rep):
            perm = rng.permutation(s)
            diffs[k] = (np.mean(pooled[perm[:s_a]])
                        - np.mean(pooled[perm[s_a:]]))
        if real_diff > 0:
            p_row[i] = np.sum(diffs >= real_diff) / n_rep
        else:
            p_row[i] = np.sum(diffs <= real_diff) / n_rep
    return f, p_row


def permutation_test(resel_maps, ref_idx, n_rep=1_000_000,
                     cancel_event=None):
    """Direct permutation test on mean differences.

    For each resel, pool reference and test data, permute labels,
    compute mean difference under permutation. Parallelism is
    delegated to ``joblib.Parallel`` — see ``bootstrap_pseudo_t`` and
    ``CONTRIBUTING.md §"Parallelism"``.

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int
    n_rep : int
    cancel_event : threading.Event or None
        If set between row completions, the remaining joblib workers
        are cancelled and ``InterruptedError`` is raised.

    Returns
    -------
    p_map : ndarray (n_freq, n_time)
    """
    from joblib import Parallel, delayed

    n_trials, n_freq, n_time = resel_maps.shape
    N = n_trials
    ref_idx_arr = np.asarray(ref_idx)

    master_rng = np.random.default_rng(42)
    seeds = master_rng.integers(0, 2**63, size=n_freq)

    logging.info("  perm test: %d freq rows × %d reps", n_freq, n_rep)
    if n_rep >= 100_000:
        logging.info(
            "  note: each row is a Python-level loop over %d reps × "
            "n_time points. Stop response will be delayed by up to "
            "one row's compute time. Use pseudo_t for faster Stop "
            "response.", n_rep)

    p_map = np.ones((n_freq, n_time))
    log_every = max(1, n_freq // 10)
    done = 0
    with timed_parallel_block("perm test", cancel_event):
        # verbose=0: see note in bootstrap_pseudo_t — we emit our
        # own progress via logging.info so it reaches the GUI log.
        parallel_gen = Parallel(return_as="generator", verbose=0)(
            delayed(_perm_freq_row)(
                resel_maps, f, ref_idx_arr, n_rep, N, n_time,
                int(seeds[f]),
            )
            for f in range(n_freq)
        )
        try:
            for f, p_row in parallel_gen:
                if cancel_event is not None and cancel_event.is_set():
                    raise InterruptedError(
                        "permutation_test cancelled by user")
                p_map[f] = p_row
                done += 1
                if done % log_every == 0 or done == n_freq:
                    logging.info(
                        "  perm test: %d/%d freq rows done",
                        done, n_freq)
        finally:
            try:
                parallel_gen.close()
            except Exception:
                pass

    # Floor at 1/n_rep
    p_map = np.maximum(p_map, 1.0 / n_rep)

    return p_map


# =====================================================================
#  Box-Cox transformation (Żygierewicz et al. 2005, Eq. 14-15)
# =====================================================================

def box_cox_transform(resel_maps, ref_idx):
    """Apply Box-Cox normalizing transformation per frequency bin.

    For each frequency row, the optimal λ is found by maximum likelihood
    on the reference period data (pooled across trials).  The transform
    is then applied to all time bins at that frequency.

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
        Energy values (must be > 0).
    ref_idx : array of int
        Column indices of the reference period.

    Returns
    -------
    transformed : ndarray (n_trials, n_freq, n_time)
        Box-Cox transformed data.
    lambdas : ndarray (n_freq,)
        Optimal λ per frequency bin.
    """
    from scipy.stats import boxcox_normmax
    from scipy.special import boxcox as _bc

    n_trials, n_freq, n_time = resel_maps.shape
    transformed = resel_maps.copy()
    lambdas = np.zeros(n_freq)

    for f in range(n_freq):
        # Pool reference values across trials for λ estimation
        ref_data = resel_maps[:, f, ref_idx].ravel()

        # Skip transform for all-zero frequency bins (no energy →
        # Box-Cox would produce numerically unstable values)
        if not np.any(ref_data > 0):
            lambdas[f] = np.nan
            continue

        # Box-Cox requires strictly positive data
        floor = np.min(ref_data[ref_data > 0]) * 0.01
        ref_data_pos = np.maximum(ref_data, floor)

        try:
            lam = boxcox_normmax(ref_data_pos, method="mle")
        except Exception:
            lam = 0.0  # fall back to log transform

        lambdas[f] = lam

        # Apply transform to all data at this frequency
        all_data = np.maximum(resel_maps[:, f, :], floor)
        transformed[:, f, :] = _bc(all_data, lam)

    return transformed, lambdas


# =====================================================================
#  Parametric t-test (Żygierewicz et al. 2005, Sec. 2.3.2)
# =====================================================================

def parametric_ttest(resel_maps, ref_idx):
    """Standard parametric t-test on (optionally transformed) data.

    Assumes the data has been normalized (e.g. via Box-Cox) before
    calling.  Uses the pooled-variance t-test (Eq. 20 in Żygierewicz
    et al. 2005).

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int

    Returns
    -------
    p_map : ndarray (n_freq, n_time)
    """
    from scipy.stats import t as t_dist

    n_trials, n_freq, n_time = resel_maps.shape
    N = n_trials
    N_ref = N * len(ref_idx)

    p_map = np.ones((n_freq, n_time))
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
    degrees_of_freedom = N + N_ref - 2

    for f in range(n_freq):
        # Reference: pool all trials × reference columns
        rr = resel_maps[:, f, ref_idx].ravel()
        mean_rr = np.mean(rr)
        var_rr = np.var(rr, ddof=1)

        for i in range(post_ref, n_time):
            point = resel_maps[:, f, i]
            mean_pt = np.mean(point)
            var_pt = np.var(point, ddof=1)

            # Pooled variance
            sp2 = ((N_ref - 1) * var_rr + (N - 1) * var_pt) / degrees_of_freedom
            denom = np.sqrt(sp2 * (1.0 / N_ref + 1.0 / N))

            if denom > 1e-30:
                t_val = (mean_pt - mean_rr) / denom
                p_map[f, i] = 2.0 * t_dist.sf(abs(t_val), degrees_of_freedom)
            # else: p stays 1.0

        if (f + 1) % max(1, n_freq // 10) == 0:
            logging.info("  t-test: %d/%d freq rows", f + 1, n_freq)

    return p_map


# =====================================================================
#  Welch's t-test (Żygierewicz et al. 2005, Sec. 2.3.3, Eq. 23)
# =====================================================================

def welch_ttest(resel_maps, ref_idx):
    """Welch's t-test with Satterthwaite degrees of freedom.

    Does not assume equal variances between reference and event periods.
    Useful when the reference period is much longer than the event
    period (Żygierewicz et al. 2005, Sec. 2.3.3).

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int

    Returns
    -------
    p_map : ndarray (n_freq, n_time)
    """
    from scipy.stats import t as t_dist

    n_trials, n_freq, n_time = resel_maps.shape
    N = n_trials
    N_ref = N * len(ref_idx)

    p_map = np.ones((n_freq, n_time))
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0

    for f in range(n_freq):
        rr = resel_maps[:, f, ref_idx].ravel()
        mean_rr = np.mean(rr)
        var_rr = np.var(rr, ddof=1)

        for i in range(post_ref, n_time):
            point = resel_maps[:, f, i]
            mean_pt = np.mean(point)
            var_pt = np.var(point, ddof=1)

            # Welch's t-statistic
            denom = np.sqrt(var_rr / N_ref + var_pt / N)
            if denom < 1e-30:
                continue

            t_val = (mean_pt - mean_rr) / denom

            # Welch-Satterthwaite degrees of freedom (Eq. 23)
            a = var_rr / N_ref
            b = var_pt / N
            if a + b < 1e-30:
                continue
            df = (a + b) ** 2 / (
                a ** 2 / max(N_ref - 1, 1) + b ** 2 / max(N - 1, 1))

            p_map[f, i] = 2.0 * t_dist.sf(abs(t_val), df)

        if (f + 1) % max(1, n_freq // 10) == 0:
            logging.info("  Welch t-test: %d/%d freq rows", f + 1, n_freq)

    return p_map


# =====================================================================
#  Normality testing (Lilliefors test)
# =====================================================================

def check_normality(resel_maps, ref_idx, alpha=0.05):
    """Test normality of (transformed) reference data per frequency bin.

    Uses the Lilliefors variant of the Kolmogorov-Smirnov test, which
    adjusts for estimated parameters (mean and variance).

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int
    alpha : float

    Returns
    -------
    pass_map : ndarray (n_freq,) of bool
        True where the null hypothesis of normality is NOT rejected.
    """
    from scipy.stats import kstest

    n_trials, n_freq, n_time = resel_maps.shape
    pass_map = np.ones(n_freq, dtype=bool)

    for f in range(n_freq):
        ref_data = resel_maps[:, f, ref_idx].ravel()
        if len(ref_data) < 8:
            continue
        # Lilliefors: KS test against normal with estimated params
        stat, p = kstest(ref_data, "norm",
                         args=(np.mean(ref_data), np.std(ref_data, ddof=1)))
        pass_map[f] = p >= alpha

    return pass_map


# =====================================================================
#  Distribution histograms (optional diagnostic output)
# =====================================================================

def _plot_histograms(resel_maps, ref_idx, f_axis,
                     tag, ch_name, save_dir, base,
                     transform_name="none", n_bins_to_show=6):
    """Plot histograms of energy distributions at selected frequency bins.

    Shows raw reference period distributions with a normal fit overlay.
    Useful for validating that Box-Cox normalization achieved normality.

    Parameters
    ----------
    resel_maps : ndarray (n_trials, n_freq, n_time)
    ref_idx : array of int
    f_axis : ndarray — frequency bin centres
    tag, ch_name : str — for labelling
    save_dir : str — output directory
    base : str — filename base
    transform_name : str — "none" or "boxcox" for title
    n_bins_to_show : int — number of frequency bins to plot
    """
    import matplotlib.pyplot as plt
    from scipy.stats import norm

    n_freq = resel_maps.shape[1]
    # Select evenly spaced frequency bins
    indices = np.linspace(0, n_freq - 1, n_bins_to_show, dtype=int)

    fig, axes = plt.subplots(2, (n_bins_to_show + 1) // 2,
                             figsize=(14, 8))
    axes = axes.ravel()
    fig.suptitle(f"Energy distributions — {tag} / {ch_name} "
                 f"(transform: {transform_name})", fontsize=13)

    for ax_i, f_i in enumerate(indices):
        if ax_i >= len(axes):
            break
        ax = axes[ax_i]
        ref_data = resel_maps[:, f_i, ref_idx].ravel()

        ax.hist(ref_data, bins=40, density=True, alpha=0.7,
                color="#4c78a8", edgecolor="white", linewidth=0.5)

        # Normal fit overlay
        mu, sigma = np.mean(ref_data), np.std(ref_data, ddof=1)
        if sigma > 1e-10:
            x = np.linspace(mu - 4 * sigma, mu + 4 * sigma, 200)
            ax.plot(x, norm.pdf(x, mu, sigma), "r-", lw=2,
                    label=f"N({mu:.2g}, {sigma:.2g})")

        # Lilliefors p-value
        from scipy.stats import kstest
        if len(ref_data) >= 8:
            _, ks_p = kstest(ref_data, "norm", args=(mu, sigma))
            ax.set_title(f"{f_axis[f_i]:.1f} Hz  (normality p={ks_p:.3f})",
                         fontsize=10)
        else:
            ax.set_title(f"{f_axis[f_i]:.1f} Hz", fontsize=10)

        ax.legend(fontsize=8)
        ax.set_xlabel("Energy")
        ax.set_ylabel("Density")

    # Hide unused axes
    for ax_i in range(len(indices), len(axes)):
        axes[ax_i].set_visible(False)

    plt.tight_layout()
    fname = f"{base}_{_safe_tag(tag)}_{ch_name}_histograms.png"
    fig.savefig(os.path.join(save_dir, fname), dpi=150)
    plt.close(fig)
    logging.info("  Histograms saved: %s", fname)


# =====================================================================
#  Multiple comparison corrections
# =====================================================================

def _test_columns(n_time, ref_idx, margin_cols):
    """Return column indices that are actually tested (post-reference)."""
    post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
    end = n_time - margin_cols if margin_cols > 0 else n_time
    return list(range(post_ref, end))


def fdr_correction(p_map, q=0.05, ref_idx=None, margin_cols=0):
    """Benjamini-Yekutieli (2001) FDR correction for correlated tests.

    Returns (accepted, adjusted_p) — same shape as p_map.
    """
    n_freq, n_time = p_map.shape
    test_cols = _test_columns(n_time, ref_idx, margin_cols)
    N_tests = n_freq * len(test_cols)

    accepted = np.zeros_like(p_map, dtype=bool)
    adjusted_p = np.ones_like(p_map)

    if N_tests == 0:
        return accepted, adjusted_p

    # Extract test region
    p_vec = p_map[:, test_cols].ravel()
    sort_idx = np.argsort(p_vec)
    p_sorted = p_vec[sort_idx]

    j = np.arange(1, N_tests + 1)
    C_N = np.sum(1.0 / j)

    # Adjusted p-values
    adj = np.minimum(p_sorted * N_tests * C_N / j, 1.0)
    # Monotonize (ensure adjusted p non-decreasing)
    for k in range(N_tests - 2, -1, -1):
        adj[k] = min(adj[k], adj[k + 1])
    adj_unsorted = np.empty_like(adj)
    adj_unsorted[sort_idx] = adj

    # FDR threshold
    B = j * q / (C_N * N_tests)
    below = np.where(p_sorted < B)[0]
    cutoff = p_sorted[below[-1]] if len(below) > 0 else 0.0

    # Apply
    adj_2d = adj_unsorted.reshape(n_freq, len(test_cols))
    adjusted_p[:, test_cols] = adj_2d
    accepted[:, test_cols] = p_map[:, test_cols] <= cutoff

    return accepted, adjusted_p


def bh_correction(p_map, alpha=0.05, ref_idx=None, margin_cols=0):
    """Stepdown Bonferroni-Holmes correction.

    Returns (accepted, adjusted_p).
    """
    n_freq, n_time = p_map.shape
    test_cols = _test_columns(n_time, ref_idx, margin_cols)
    N_tests = n_freq * len(test_cols)

    accepted = np.zeros_like(p_map, dtype=bool)
    adjusted_p = np.ones_like(p_map)

    if N_tests == 0:
        return accepted, adjusted_p

    p_vec = p_map[:, test_cols].ravel()
    sort_idx = np.argsort(p_vec)
    p_sorted = p_vec[sort_idx]

    # Adjusted: p * (N - rank + 1), capped at 1
    ranks = np.arange(N_tests)  # 0-based
    adj = np.minimum(p_sorted * (N_tests - ranks), 1.0)
    # Monotonize
    for k in range(1, N_tests):
        adj[k] = max(adj[k], adj[k - 1])
    adj_unsorted = np.empty_like(adj)
    adj_unsorted[sort_idx] = adj

    # Threshold: alpha / (N - rank + 1)
    thresh = alpha / (N_tests - ranks)
    ok = p_sorted < thresh

    adj_2d = adj_unsorted.reshape(n_freq, len(test_cols))
    adjusted_p[:, test_cols] = adj_2d

    # Stepdown: reject all up to the last rejection
    ok_idx = np.where(ok)[0]
    if len(ok_idx) > 0:
        p_eff = p_sorted[ok_idx[-1]]
        accepted[:, test_cols] = p_map[:, test_cols] <= p_eff

    return accepted, adjusted_p


def bonferroni_correction(p_map, alpha=0.05, ref_idx=None,
                          margin_cols=0):
    """Full Bonferroni correction.

    Returns (accepted, adjusted_p).
    """
    n_freq, n_time = p_map.shape
    test_cols = _test_columns(n_time, ref_idx, margin_cols)
    N_tests = n_freq * len(test_cols)

    adjusted_p = np.ones_like(p_map)
    if N_tests > 0:
        adjusted_p[:, test_cols] = np.minimum(
            p_map[:, test_cols] * N_tests, 1.0)
    accepted = adjusted_p < alpha
    accepted[:, ref_idx] = False
    if margin_cols > 0:
        accepted[:, -margin_cols:] = False

    return accepted, adjusted_p


# =====================================================================
#  Helpers
# =====================================================================

def _find_smp_book(config, ch_name):
    """Find an SMP book for a given channel.

    Search order:
    1. ``_mp_book_path`` in config (set by MP decomposition step).
    2. Per-channel book ``book_*_{ch_name}.db`` in the same directory.
    3. Scan ``mp_decomposition/`` under the preprocessing output path.
    """
    import glob

    # -- 1. Book path from current pipeline run --------------------------
    book_path = config.get("_mp_book_path", "")
    if book_path and os.path.isfile(book_path):
        try:
            conn = sqlite3.connect(book_path)
            try:
                meta = dict(conn.execute(
                    "SELECT param, value FROM metadata"))
            finally:
                conn.close()
            book_ch = meta.get("channel_names", "").split(",")
            if ch_name in book_ch:
                return book_path
        except sqlite3.Error:
            pass

        # Per-channel book in same directory
        book_dir = os.path.dirname(book_path)
        for pat in (f"*_{ch_name}.db", f"*_smp_{ch_name}.db"):
            matches = glob.glob(os.path.join(book_dir, pat))
            if matches:
                return matches[0]

        # Fallback: the given book (warning logged by caller)
        return book_path

    # -- 2. Search mp_decomposition/ in the output tree ------------------
    # The analysis path is …/analysis/ ; books live in …/preprocessing/
    preproc_path = config.get("_preproc_output_path", "")
    if not preproc_path:
        # Infer from analysis path (sibling directory)
        analysis_path = config.get("_analysis_output_path", "")
        if analysis_path:
            preproc_path = os.path.join(
                os.path.dirname(analysis_path), "preprocessing")

    if preproc_path:
        mp_dir = os.path.join(preproc_path, "mp_decomposition")
        for pat in (f"*_{ch_name}.db", f"*_smp_{ch_name}.db"):
            matches = glob.glob(os.path.join(mp_dir, pat))
            if matches:
                return matches[0]

    return None


def _ref_indices(t_axis, ref_start, ref_end):
    """Convert reference period [start, end] to column indices."""
    return np.where((t_axis >= ref_start) & (t_axis < ref_end))[0]


# =====================================================================
#  Plotting
# =====================================================================

def _hires_erds(hires_map, t_hi, f_hi, ref_start, ref_end):
    """Compute ERD/ERS from a high-resolution average Wigner map.

    Only computed for time points after ref_end (Durka et al. 2003).
    """
    ref_mask = (t_hi >= ref_start) & (t_hi < ref_end)
    if not np.any(ref_mask):
        return hires_map
    baseline = np.mean(hires_map[:, ref_mask], axis=1, keepdims=True)
    baseline = np.where(np.abs(baseline) < 1e-30, 1e-30, baseline)
    erds = np.zeros_like(hires_map)
    post_ref = t_hi >= ref_end
    erds[:, post_ref] = (hires_map[:, post_ref] - baseline) / baseline
    return erds


def _scale_erds_symmetric(erds):
    """Scale ERD/ERS to [-100, +100] with separate ERD and ERS extremes.

    Follows the MATLAB TFSTAT convention: positive values are scaled
    by their maximum (ERS_extr), negative by abs(min) (ERD_extr).
    The colorbar ticks then show the actual ERD/ERS percentages.

    Returns (scaled_map, ERD_extr, ERS_extr) where extremes are in
    the original ERD/ERS fraction (not percentage).
    """
    ers_extr = max(np.max(erds), 0.01)
    erd_extr = min(np.min(erds), -0.01)
    scaled = np.zeros_like(erds)
    pos = erds > 0
    neg = erds <= 0
    scaled[pos] = erds[pos] / ers_extr * 100
    scaled[neg] = erds[neg] / abs(erd_extr) * 100
    return scaled, erd_extr, ers_extr


def _upscale_mask(accepted, t_axis, f_axis, t_hi, f_hi):
    """Upscale resel-level boolean mask to high-res grid.

    Each high-res pixel inherits the value of the nearest resel.
    """
    f_idx = np.clip(np.searchsorted(f_axis, f_hi, side="right") - 1,
                    0, len(f_axis) - 1)
    t_idx = np.clip(np.searchsorted(t_axis, t_hi, side="right") - 1,
                    0, len(t_axis) - 1)
    return accepted[np.ix_(f_idx, t_idx)]


def _plot_erds_significance(erds, accepted, t_axis, f_axis,
                            ref_idx, margin_cols, tag, ch_name, n_ep,
                            test_method, correction, n_rep, eff_p,
                            src_label, save_path, trigger_t=None,
                            event_label="event",
                            hires_map=None, t_hi=None, f_hi=None,
                            ref_start=0, ref_end=0,
                            cmap="jet"):
    """Plot ERD/ERS map with significance masking.

    When *hires_map* is provided (MP source), the top panel shows
    the high-resolution average Wigner ERD/ERS, and the bottom panel
    masks it by resel-level significance — revealing fine
    time-frequency microstructure within significant resels.
    """
    fig, axes = plt.subplots(2, 1, figsize=(12, 8),
                             gridspec_kw={"height_ratios": [1, 1]})

    use_hires = (hires_map is not None and t_hi is not None
                 and f_hi is not None)

    if use_hires:
        hi_erds = _hires_erds(hires_map, t_hi, f_hi,
                              ref_start, ref_end)
        # Crop to post-reference region
        post = t_hi >= ref_end
        hi_erds = hi_erds[:, post]
        t_plot, f_plot = t_hi[post], f_hi
        scaled, erd_extr, ers_extr = _scale_erds_symmetric(hi_erds)
        # Upscale mask and crop to same region
        mask_hi = _upscale_mask(accepted, t_axis, f_axis, t_hi, f_hi)
        mask_crop = mask_hi[:, post]
    else:
        # Crop resel-level to post-reference columns
        post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
        erds_crop = erds[:, post_ref:]
        t_plot = t_axis[post_ref:]
        f_plot = f_axis
        scaled, erd_extr, ers_extr = _scale_erds_symmetric(erds_crop)
        mask_crop = accepted[:, post_ref:]

    CLIM = (-100, 100)

    def _erds_colorbar(im, ax, erd_e, ers_e):
        cb = plt.colorbar(im, ax=ax)
        cb.set_ticks([-100, -50, 0, 50, 100])
        cb.set_ticklabels([
            f"{erd_e*100:.0f}%", f"{erd_e*50:.0f}%", "0%",
            f"{ers_e*50:.0f}%", f"{ers_e*100:.0f}%"])
        cb.set_label("ERD/ERS")

    # Top: ERD/ERS map (post-reference only)
    im0 = axes[0].pcolormesh(
        t_plot, f_plot, scaled, shading="nearest",
        cmap=cmap, vmin=CLIM[0], vmax=CLIM[1])
    axes[0].set_ylabel("Frequency [Hz]")
    axes[0].set_title(
        f"ERD/ERS ({src_label}): {tag} / {ch_name} "
        f"({n_ep} epochs)")
    _erds_colorbar(im0, axes[0], erd_extr, ers_extr)
    _mark_trigger(axes[0], trigger_t, t_plot, event_label)

    # Bottom: significance-masked
    # Title follows MATLAB TFSTAT format: TEST#N; CORRECTION:p<eff_p
    masked = np.where(mask_crop, scaled, 0.0)

    im1 = axes[1].pcolormesh(
        t_plot, f_plot, masked, shading="nearest",
        cmap=cmap, vmin=CLIM[0], vmax=CLIM[1])
    axes[1].set_xlabel("Time [s]")
    axes[1].set_ylabel("Frequency [Hz]")
    test_label = test_method.upper()
    corr_label = correction.upper()
    if eff_p > 0:
        axes[1].set_title(
            f"{src_label}: {test_label}#{n_rep:.0e}; "
            f"{corr_label}:p<{eff_p:.2g}")
    else:
        axes[1].set_title(
            f"{src_label}: {test_label}#{n_rep:.0e}; "
            f"{corr_label} (none significant)")
    _erds_colorbar(im1, axes[1], erd_extr, ers_extr)
    _mark_trigger(axes[1], trigger_t, t_plot, event_label)

    n_sig = int(np.sum(accepted))
    n_total = accepted.size
    fig.text(0.01, 0.01,
             f"{n_sig}/{n_total} resels significant "
             f"(dt={t_axis[1]-t_axis[0]:.2f}s, "
             f"df={f_axis[1]-f_axis[0]:.1f}Hz)",
             fontsize=8, color="gray")

    plt.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)


def _plot_erds_raw(erds, t_axis, f_axis, ref_idx, margin_cols,
                   tag, ch_name, n_ep, src_label, save_path,
                   trigger_t=None, event_label="event",
                   hires_map=None, t_hi=None, f_hi=None,
                   ref_start=0, ref_end=0,
                   cmap="jet"):
    """Plot raw ERD/ERS map (high-res if available).

    Uses symmetric scaling: ERD and ERS normalized separately
    to [-100, +100], colorbar shows actual percentages.
    """
    fig, ax = plt.subplots(figsize=(12, 5))

    use_hires = (hires_map is not None and t_hi is not None
                 and f_hi is not None)

    if use_hires:
        hi_erds = _hires_erds(hires_map, t_hi, f_hi,
                              ref_start, ref_end)
        post = t_hi >= ref_end
        hi_erds = hi_erds[:, post]
        t_plot, f_plot = t_hi[post], f_hi
    else:
        post_ref = ref_idx[-1] + 1 if len(ref_idx) > 0 else 0
        hi_erds = erds[:, post_ref:]
        t_plot, f_plot = t_axis[post_ref:], f_axis

    scaled, erd_extr, ers_extr = _scale_erds_symmetric(hi_erds)

    im = ax.pcolormesh(
        t_plot, f_plot, scaled, shading="nearest",
        cmap=cmap, vmin=-100, vmax=100)
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Frequency [Hz]")
    ax.set_title(f"ERD/ERS ({src_label}): {tag} / {ch_name} "
                 f"({n_ep} epochs)")
    cb = plt.colorbar(im, ax=ax)
    cb.set_ticks([-100, -50, 0, 50, 100])
    cb.set_ticklabels([
        f"{erd_extr*100:.0f}%", f"{erd_extr*50:.0f}%", "0%",
        f"{ers_extr*50:.0f}%", f"{ers_extr*100:.0f}%"])
    cb.set_label("ERD/ERS")
    _mark_trigger(ax, trigger_t, t_plot, event_label)

    plt.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)


def _plot_energy_map(resel_maps, t_axis, f_axis,
                     tag, ch_name, n_ep, src_label, save_path,
                     trigger_t=None, event_label="event",
                     hires_map=None, t_hi=None, f_hi=None,
                     ref_start=0, ref_end=0):
    """Plot average time-frequency energy density in log scale.

    For MP with high-res map: shows the detailed Wigner energy
    (like Durka et al. 2004, Fig. 2a).  For STFT: average spectrogram.
    """
    fig, ax = plt.subplots(figsize=(12, 5))

    use_hires = (hires_map is not None and t_hi is not None
                 and f_hi is not None)

    if use_hires:
        # High-res average Wigner energy in µV² (log scale)
        energy = np.log1p(hires_map)
        t_plot, f_plot = t_hi, f_hi
        cb_label = "log(1 + energy) [\u00b5V\u00b2]"
    else:
        # Average across trials (resel level).
        # MNE stores signals in V, so STFT/WT PSD is in V².
        # Scale to µV² (×1e12) so log1p produces visible structure.
        avg = np.mean(resel_maps, axis=0)
        if avg.max() > 0 and avg.max() < 1e-3:
            avg = avg * 1e12  # V² → µV²
            cb_label = "log(1 + energy) [\u00b5V\u00b2]"
        else:
            cb_label = "log(1 + energy)"
        energy = np.log1p(avg)
        t_plot, f_plot = t_axis, f_axis

    im = ax.pcolormesh(
        t_plot, f_plot, energy, shading="nearest",
        cmap="jet")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Frequency [Hz]")
    ax.set_title(
        f"av. energy (log) ({src_label}): {tag} / {ch_name} "
        f"({n_ep} epochs)")
    cb = plt.colorbar(im, ax=ax)
    cb.set_label(cb_label)
    _mark_ref_times(ax, ref_start, ref_end)
    _mark_trigger(ax, trigger_t, t_plot, event_label)

    plt.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)


def _mark_ref_times(ax, ref_start, ref_end):
    """Draw vertical lines and label marking the reference period."""
    if ref_start >= ref_end:
        return
    ax.axvline(ref_start, color="k", lw=1, ls="--", alpha=0.7)
    ax.axvline(ref_end, color="k", lw=1, ls="--", alpha=0.7)
    y_top = ax.get_ylim()[1]
    t_mid = (ref_start + ref_end) / 2
    ax.text(t_mid, y_top, "ref", ha="center", va="bottom",
            fontsize=8, color="k", alpha=0.7,
            bbox=dict(boxstyle="round,pad=0.15", fc="white",
                      ec="gray", alpha=0.7))


def _mark_ref(ax, t_axis, ref_idx):
    """Draw vertical lines marking reference period (from resel indices)."""
    if len(ref_idx) == 0:
        return
    dt = t_axis[1] - t_axis[0] if len(t_axis) > 1 else 0.5
    t_start = t_axis[ref_idx[0]] - dt / 2
    t_end = t_axis[ref_idx[-1]] + dt / 2
    _mark_ref_times(ax, t_start, t_end)


def _mark_trigger(ax, trigger_t, t_axis, event_label="event"):
    """Draw a vertical line and label at the event onset."""
    if trigger_t is None:
        return
    dt = t_axis[1] - t_axis[0] if len(t_axis) > 1 else 0.5
    t_lo = t_axis[0] - dt
    t_hi = t_axis[-1] + dt
    if t_lo <= trigger_t <= t_hi:
        ax.axvline(trigger_t, color="#00ff00", lw=2, ls="-", alpha=0.9)
        y_top = ax.get_ylim()[1]
        ax.plot(trigger_t, y_top, marker="v", color="#00ff00",
                markersize=9, clip_on=False, zorder=10)
        ax.text(trigger_t, y_top, f" {event_label}", ha="left",
                va="bottom", fontsize=7, color="#00cc00",
                fontweight="bold")
