#!/usr/bin/env python3
"""
PySide6 (Qt6) GUI for IDE4EEG.
  - Fast startup (lazy tab building, deferred imports)
  - Instant tab switching
  - Modern native look with dark/light theme support
Reuses the existing pipeline backend and config infrastructure from gui_config.py.
Usage:
    python run.py                       # GUI, blank state (default)
    python run.py myconfig.toml         # GUI with config preloaded
    python gui.py                       # GUI directly (dev shortcut)
"""

import sys

if sys.version_info < (3, 11):
    sys.stderr.write(
        f"IDE4EEG requires Python 3.11 or newer (you have "
        f"{sys.version_info.major}.{sys.version_info.minor}."
        f"{sys.version_info.micro}).\n"
        f"The pipeline uses the stdlib `tomllib` module, added in "
        f"Python 3.11. Please install a newer Python and recreate "
        f"the virtual environment.\n"
    )
    sys.exit(1)

import copy
import hashlib
import json as _json_mod
import logging
import os
import queue
import re
import subprocess
import tempfile
import threading
from pathlib import Path

# Pre-import matplotlib BEFORE PySide6, so shiboken's signature loader
# doesn't try to introspect six.moves' built-in module proxies later (which
# crashes with AttributeError: '_SixMetaPathImporter' object has no attribute
# '_path').  Matplotlib transitively imports dateutil.parser, dateutil.rrule
# and several `from six.moves import ...` lines — all must happen before
# PySide6's shiboken hooks are installed on sys.meta_path.
#
# First-time matplotlib import scans all system fonts and builds
# ~/.matplotlib/fontlist-*.json which can take 20-30 s.  Show a console
# spinner with elapsed time so the user knows the app isn't frozen
# (we can't show a Qt window yet — PySide6 is imported below).
try:
    import glob as _glob
    import time as _time
    _mpl_cache = os.path.expanduser("~/.matplotlib")
    _mpl_first_run = not _glob.glob(
        os.path.join(_mpl_cache, "fontlist-*.json"))

    if _mpl_first_run:
        import threading as _threading
        # Silence matplotlib's own "building font cache" message
        # so it doesn't clash with our spinner.
        logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)

        _spin_stop = _threading.Event()

        def _spin():
            chars = "|/-\\"
            t0 = _time.monotonic()
            i = 0
            while not _spin_stop.is_set():
                elapsed = int(_time.monotonic() - t0)
                sys.stdout.write(
                    f"\rIDE4EEG: building matplotlib font cache "
                    f"{chars[i % 4]} {elapsed}s ")
                sys.stdout.flush()
                i += 1
                _spin_stop.wait(0.1)
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()

        _spin_thread = _threading.Thread(target=_spin, daemon=True)
        _spin_thread.start()

    try:
        import matplotlib  # noqa: F401
        import matplotlib.dates  # noqa: F401
        import matplotlib.pyplot  # noqa: F401
    finally:
        if _mpl_first_run:
            _spin_stop.set()
            _spin_thread.join(timeout=1.0)
            print("IDE4EEG: matplotlib font cache ready.", flush=True)
except ImportError:
    pass

from PySide6.QtCore import (Qt, QTimer, Signal, QObject, Slot, QRect, QSize,
                            QPoint, QSettings)
from PySide6.QtGui import (QFont, QColor, QKeySequence, QPalette, QPixmap,
                           QShortcut, QTextCursor, QTextDocument)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout,
    QHBoxLayout, QGridLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QGroupBox, QCheckBox, QComboBox, QTextEdit,
    QPlainTextEdit, QProgressBar, QSplitter, QTreeWidget,
    QTreeWidgetItem, QStatusBar, QFrame, QDialog,
    QSizePolicy, QScrollArea, QTableWidget, QTableWidgetItem,
    QTextBrowser, QHeaderView, QAbstractItemView, QStackedWidget,
    QListWidget, QListWidgetItem,
    QGraphicsOpacityEffect,
)

# Shared TOML I/O, defaults, and config utilities
from ide4eeg.gui_config import (
    load_toml, dump_toml, DEFAULT_CONFIG, FIELD_TOOLTIPS,
    _find_svarog_jar, _find_connectivis_jar, _find_empi)

# Verbose console logging — startup progress messages and SVAROG launch
# command.  Default True; toggled by the Config-tab checkbox and persisted
# in QSettings.  Set early in main() before any prints happen.
_VERBOSE_LOGGING = True


class _FlowLayout(QVBoxLayout):
    """Layout that wraps widgets into rows, flowing to the next line."""

    # Minimal QLayout subclass for wrapping button rows.
    # Defined at module level to avoid re-creating the class per call.

    from PySide6.QtWidgets import QLayout as _QLayout

    class _Impl(_QLayout):
        def __init__(self, parent=None, hs=6, vs=4):
            super().__init__(parent)
            self._items, self._hs, self._vs = [], hs, vs

        def addItem(self, item): self._items.append(item)
        def count(self): return len(self._items)

        def itemAt(self, i):
            return self._items[i] if 0 <= i < len(self._items) else None

        def takeAt(self, i):
            return self._items.pop(i) if 0 <= i < len(self._items) else None

        def sizeHint(self): return self.minimumSize()

        def minimumSize(self):
            s = QSize(0, 0)
            for it in self._items:
                s = s.expandedTo(it.minimumSize())
            m = self.contentsMargins()
            return QSize(s.width() + m.left() + m.right(),
                         self._layout(QRect(0, 0, s.width(), 0), True)
                         + m.top() + m.bottom())

        def setGeometry(self, r):
            super().setGeometry(r); self._layout(r, False)

        def hasHeightForWidth(self): return True

        def heightForWidth(self, w):
            return self._layout(QRect(0, 0, w, 0), True)

        def _layout(self, rect, test):
            m = self.contentsMargins()
            r = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
            x, y, rh = r.x(), r.y(), 0
            for it in self._items:
                sz = it.sizeHint()
                if x + sz.width() > r.right() and x > r.x():
                    x, y, rh = r.x(), y + rh + self._vs, 0
                if not test:
                    it.setGeometry(QRect(QPoint(x, y), sz))
                x += sz.width() + self._hs
                rh = max(rh, sz.height())
            return y + rh - rect.y() + m.bottom()


def _flow_widget(widgets, spacing=6, vspacing=4):
    """Return a QWidget containing *widgets* in a wrapping row layout.

    If *widgets* contains (QLabel, QLineEdit/QComboBox/QCheckBox) pairs,
    consider using ``_flow_pairs`` instead to keep labels tied to their
    inputs.
    """
    w = QWidget()
    w.setContentsMargins(0, 0, 0, 0)
    lay = _FlowLayout._Impl(w, spacing, vspacing)
    lay.setContentsMargins(0, 0, 0, 0)
    for widget in widgets:
        lay.addWidget(widget)
    return w


def _flow_pairs(pairs, spacing=6):
    """Return a flow widget where each (label, input) pair stays together.

    Parameters
    ----------
    pairs : list of QWidget or (QWidget, QWidget)
        Each element is either a single widget (added as-is, e.g. a
        QCheckBox) or a 2-tuple (label, input) that are grouped into
        a single unit so they never split across lines.
    """
    units = []
    for item in pairs:
        if isinstance(item, (list, tuple)):
            pair_w = QWidget()
            h = QHBoxLayout(pair_w)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(3)
            for child in item:
                h.addWidget(child)
            units.append(pair_w)
        else:
            units.append(item)
    return _flow_widget(units, spacing)


def _deep_merge(base, overlay):
    """Recursively merge *overlay* dict into *base*, mutating *base*."""
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = copy.deepcopy(v)


def _sample_rates_match(path_a, path_b):
    """Return True if two signal files share the same sample rate.

    Used to gate Svarog ``--split-signal``, which requires matching
    sfreq.  Delegates to :func:`ide4eeg.input.input.read_file_info`,
    which reads metadata only (no sample loading) for every
    supported format, so this is safe to call on a click path even
    for large recordings.
    """
    from ide4eeg.input.input import read_file_info
    try:
        info_a = read_file_info(path_a)
        info_b = read_file_info(path_b)
        if info_a is None or info_b is None:
            return False
        return abs(float(info_a["sfreq"]) - float(info_b["sfreq"])) < 1e-6
    except Exception:
        return False

# Step labels for the constraints editor (lightweight copy, no MNE import)
_STEP_LABELS = {
    "trim":             "Trim signal",
    "resample":         "Resample",
    "bad_channels":     "Bad Channels",
    "montage":          "Montage",
    "reference":        "Reference",
    "filtering":        "Filters",
    "ica":              "ICA",
    "chosen_channels":  "Drop Channels",
    "mp_decomposition": "MP Decomposition",
    "mp_filter":        "MP Filter",
    # Map below is intentionally absent its own export — the Qt class
    # owns _STEP_PYINFO since it depends on which Python paths are
    # canonical for each step.
    "artifacts":        "EEG artifacts",
}

import ide4eeg
from ide4eeg import OUTPUT_DIR_PREFIX, NATIVE_POSITIONS_SENTINEL

#: Subdirectory names for reference / exclude face photos.  By
#: convention, these live under ``<output>/IDE4EEG_OUT_<base>/
#: preprocessing/`` (the per-recording results dir).  The picker
#: in :meth:`IDE4EEG_Qt._open_face_picker` creates them on first
#: use; the auto-discovery walk in
#: :meth:`IDE4EEG_Qt._auto_fill_face_dirs` looks for them in the
#: same place.  Photos at the legacy ``<video>/reference_faces/``
#: location are no longer auto-discovered — users must move them
#: under the per-recording results dir or repoint via the
#: **Change folder** button.
_REFERENCE_FACES_DIRNAME = "reference_faces"
_EXCLUDE_FACES_DIRNAME = "exclude_faces"

#: QSS for QLabels that flag a non-fatal warning to the user
#: (Config-tab parallelism caveat, MP cpu_workers caveat, gaze
#: missing-deps badge).  Solarized-yellow #b58900 is reused across
#: the GUI for "you should look at this" labels.
_WARN_LABEL_QSS = "color: #b58900; font-weight: bold;"

#: Status colors reused across the GUI: green for "✓ ok / installed",
#: red for "✗ missing / failed", dark goldenrod for "[--] not yet
#: installed" (recoverable: user can install).  Keep all three as
#: plain hex strings so they slot into both inline HTML
#: (color:#...) and Qt stylesheets.
_OK_COLOR = "#4a9d4a"
_ERR_COLOR = "#c0392b"
_MISSING_COLOR = "#b8860b"

#: Prominent green status label used by the install-completion
#: dialogs to make a one-shot "installed successfully" message
#: hard to miss next to a stream of pip output.
_SUCCESS_LABEL_QSS = (
    f"QLabel {{ color: {_OK_COLOR}; font-size: 13pt; "
    f"font-weight: bold; padding: 4px; }}")
from ide4eeg._appcds import appcds_flags
from ide4eeg.analysis.mp_analysis import (
    mp_algorithm_choices,
    mp_multichannel_algorithm_names,
    parse_mp_algorithm_label,
)
from ide4eeg.input.input import SIGNAL_EXTENSIONS, UNNAMED_CODE_LABEL
from ide4eeg.preprocessing.channels_and_signal import get_segmentation_mode
from ide4eeg.preprocessing.preprocessing import (
    _STEP_SAVE_MAP, _compute_preprocessing_hash,
    _compute_step_hashes, _compute_step_hash,
    effective_step_order)


_IDE4EEG_LOGO = "\n".join([
    r" ___  ____  _____  _   _____  _____   ____ ",
    r"|_ _||  _ \| ____|/ \ | ____|| ____| / ___|",
    r" | | | | | |  _| / _ \|  _|  |  _|  | |  _ ",
    r" | | | |_| | |__|_/ |_| |___ | |__  | |_| |",
    r"|___||____/|_____|  |_|_____||_____| \____|",
])

# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Collapsible group box                                               ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class CollapsibleGroupBox(QWidget):
    """Collapsible, optionally checkable group box.

    Header: optional QCheckBox + clickable title with ▶/▼ indicator.
    Clicking the title toggles content visibility.
    """

    def __init__(self, title="", checkable=False, checked=True,
                 collapsed=True, parent=None):
        super().__init__(parent)
        self._title = title
        self._checkable = checkable
        self._collapsed = collapsed
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        # Header
        header = QWidget()
        header.setStyleSheet(
            "QWidget { border-bottom: 1px solid palette(mid); }")
        h = QHBoxLayout(header)
        h.setContentsMargins(4, 2, 4, 2)
        h.setSpacing(4)
        if checkable:
            self._checkbox = QCheckBox()
            self._checkbox.setChecked(checked)
            self._checkbox.stateChanged.connect(self._on_check_changed)
            h.addWidget(self._checkbox)
        else:
            self._checkbox = None
        self._title_label = QLabel(self._indicator() + " " + title)
        self._title_label.setStyleSheet(
            "QLabel { font-weight: bold; color: #999999; "
            "border: none; }")
        self._title_label.setCursor(Qt.PointingHandCursor)
        self._title_label.mousePressEvent = self._on_title_click
        h.addWidget(self._title_label)
        h.addStretch()
        self._header_layout = h
        outer.addWidget(header)
        # Content area
        self._content = QWidget()
        self._content.setContentsMargins(0, 0, 0, 0)
        self._content.setVisible(not self._collapsed)
        outer.addWidget(self._content)

    def _indicator(self):
        return "\u25b6" if self._collapsed else "\u25bc"

    def _on_title_click(self, event):
        self._collapsed = not self._collapsed
        self._content.setVisible(not self._collapsed)
        self._title_label.setText(self._indicator() + " " + self._title)

    def expand(self):
        """Expand the content area."""
        self._collapsed = False
        self._content.setVisible(True)
        self._title_label.setText(self._indicator() + " " + self._title)

    def collapse(self):
        """Collapse the content area."""
        self._collapsed = True
        self._content.setVisible(False)
        self._title_label.setText(self._indicator() + " " + self._title)

    def _on_check_changed(self, state):
        """Auto-expand when checked, auto-collapse when unchecked."""
        if state:
            self.expand()
        else:
            self.collapse()

    # ── Public API matching QGroupBox interface ───────────────────

    def isCheckable(self):
        return self._checkable

    def isChecked(self):
        if self._checkbox is not None:
            return self._checkbox.isChecked()
        return True

    def setChecked(self, state):
        if self._checkbox is not None:
            self._checkbox.setChecked(bool(state))

    def setCheckable(self, checkable):
        self._checkable = checkable

    def contentWidget(self):
        """Return the content QWidget (use for QGridLayout creation)."""
        return self._content

    def contentLayout(self):
        """Return the layout of the content area."""
        return self._content.layout()

    def addHeaderWidget(self, widget):
        """Add a widget to the header row, before View/Run/? buttons."""
        for ref in (self._run_btn, self._help_btn):
            if ref is not None:
                idx = self._header_layout.indexOf(ref)
                if idx >= 0:
                    import logging
                    logging.debug("addHeaderWidget: inserting at %d (before %s)", idx, ref.text())
                    self._header_layout.insertWidget(idx, widget)
                    return
        self._header_layout.addWidget(widget)


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Compact collapsible step row (Preprocessing / Analysis)             ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class CollapsibleStep(QWidget):
    """Compact step row: [check] [▲▼] [Title ▸] (sub)  status  [Run][?]"""

    def __init__(self, title, subtitle="", checkable=False, checked=True,
                 reorderable=False, has_help=False, help_key="",
                 has_run=False, parent=None):
        super().__init__(parent)
        self._checkable = checkable
        self._collapsed = True
        self._title = title
        # Top-margin 0 + bottom-margin 9 + 9 px spacing after the
        # separator centers the HLine between consecutive step
        # headers (9 above, 9 below).  Color follows the system
        # `palette(Mid)` role (light grey in light mode, dark grey in
        # dark mode) — set via `setBackgroundRole` + autoFillBackground
        # rather than QSS, because the QSS `palette()` function is
        # inconsistent across Qt styles (notably broken on macOS).
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 9); outer.setSpacing(0)
        self._separator = QFrame()
        self._separator.setFrameShape(QFrame.NoFrame)
        self._separator.setAutoFillBackground(True)
        self._separator.setBackgroundRole(QPalette.Mid)
        self._separator.setFixedHeight(1)
        outer.addWidget(self._separator)
        outer.addSpacing(9)
        header = QWidget(); h = QHBoxLayout(header); h.setContentsMargins(4, 2, 4, 2); h.setSpacing(4)
        if checkable:
            self._checkbox = QCheckBox(); self._checkbox.setChecked(checked)
            self._checkbox.stateChanged.connect(self._on_check_changed); h.addWidget(self._checkbox); h.addSpacing(8)
        else:
            self._checkbox = None; h.addSpacing(28)  # align with rows that have checkboxes
        # Details button shows the step title — uniform width, left-aligned
        self._details_btn = QPushButton(title); self._details_btn.setFixedWidth(210)
        self._details_btn.setStyleSheet("QPushButton { text-align: left; padding-left: 8px; }")
        self._details_btn.setCursor(Qt.PointingHandCursor); self._details_btn.clicked.connect(self._toggle_details)
        h.addWidget(self._details_btn)
        self._title_label = None
        self._subtitle_label = None
        if subtitle:
            self._subtitle_label = QLabel(f"({subtitle})"); h.addWidget(self._subtitle_label)
        self._status_label = QLabel(""); self._status_label.setStyleSheet("color: gray;"); h.addWidget(self._status_label)
        h.addStretch()
        self._help_btn = self._run_btn = None
        self._view_btn = None
        self._save_btn = None
        if has_run:
            self._run_btn = QPushButton("Run"); self._run_btn.setFixedWidth(50)
            self._run_btn.setToolTip(f"Run {title} on preprocessed data"); h.addWidget(self._run_btn)
        # ↑↓ reorder buttons on the right, just before the help button
        if reorderable:
            # setFixedWidth (not setFixedSize) so macOS Aqua picks
            # the natural-height rounded bezel \u2014 clamping both axes
            # forces the squared "small button" bezel that doesn't
            # match the rounded Run / 3D / +/- buttons in the same
            # row.  Same trick applied to ?, eye, and \u00b1 below.
            self._up_btn = QPushButton("\u2191"); self._up_btn.setFixedWidth(24); self._up_btn.setToolTip("Move step up"); h.addWidget(self._up_btn)
            self._dn_btn = QPushButton("\u2193"); self._dn_btn.setFixedWidth(24); self._dn_btn.setToolTip("Move step down"); h.addWidget(self._dn_btn)
        else:
            self._up_btn = self._dn_btn = None
        if has_help and help_key:
            self._help_btn = QPushButton("?"); self._help_btn.setFixedWidth(30)
            self._help_btn.setToolTip(f"Help: {title}"); h.addWidget(self._help_btn)
        self._header_layout = h; outer.addWidget(header)
        self._content = QWidget(); cml = QVBoxLayout(self._content); cml.setContentsMargins(20, 2, 0, 4); cml.setSpacing(2)
        self._content.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        self._content.setVisible(False); outer.addWidget(self._content)
        self._update_title_color()

    def _toggle_details(self):
        if self._collapsed:
            self.expand()
            if self._checkbox and not self._checkbox.isChecked(): self._checkbox.setChecked(True)
        else: self.collapse()

    def expand(self):
        self._collapsed = False
        self._content.setVisible(True)
        self._details_btn.setText(self._title)

    def collapse(self):
        self._collapsed = True
        self._content.setVisible(False)
        self._details_btn.setText(self._title)

    def _on_check_changed(self, state):
        self._update_title_color()
        if state: self.expand()
        else: self.collapse()

    def _update_title_color(self):
        c = "#4caf50" if self.isChecked() else "#999999"
        self._details_btn.setStyleSheet(f"color: {c};")
        if self._subtitle_label: self._subtitle_label.setStyleSheet(f"color: {c};")

    def isCheckable(self): return self._checkable
    def isChecked(self): return self._checkbox.isChecked() if self._checkbox else True
    def setChecked(self, s):
        if self._checkbox: self._checkbox.setChecked(bool(s)); self._update_title_color()
    def contentWidget(self): return self._content
    def contentLayout(self): return self._content.layout()
    def addHeaderWidget(self, w):
        # Insert before Run/? buttons
        for ref in (self._run_btn, self._help_btn):
            if ref is not None:
                idx = self._header_layout.indexOf(ref)
                if idx >= 0:
                    self._header_layout.insertWidget(idx, w)
                    return
        self._header_layout.addWidget(w)

    def enable_view_button(self, tooltip="", callback=None):
        """Add an eye-icon 'View result' button to the header.

        Sits just before the up/down reorder arrows, or before the
        help button when the step is not reorderable.  Compact so the
        save toggle can sit next to it without crowding the header.
        """
        if self._view_btn is not None:
            return
        btn = QPushButton("\U0001f441")
        # Width fixed to give the eye emoji horizontal room (narrower
        # settings clip the colour-emoji glyph on macOS — Aqua's
        # native button padding is asymmetric for the rounded bezel
        # used at natural height); height left natural so the bezel
        # stays rounded and matches Run / +/- / ↑↓ in the same row.
        btn.setFixedWidth(44)
        btn.setToolTip(
            tooltip
            or "View this step's before/after signal snapshots")
        # Insert before [Run] so the visual order reads
        # "preview → run → reorder → help" — clicking the eye is
        # often a precursor to deciding whether to run.
        for ref in (self._run_btn, self._up_btn, self._help_btn):
            if ref is not None:
                idx = self._header_layout.indexOf(ref)
                if idx >= 0:
                    self._header_layout.insertWidget(idx, btn)
                    break
        else:
            self._header_layout.addWidget(btn)
        if callback is not None:
            btn.clicked.connect(lambda _=False: callback())
        self._view_btn = btn

    def enable_save_toggle(self, tooltip="", checked=False):
        """Add a bare-icon save toggle to the header (🗄️).

        Sits between the step's enable-checkbox and its title button,
        so the save control lives with the step's other "state"
        widgets (enabled on/off, saved on/off) instead of with the
        action buttons (view, run, help).  Rendered as a plain
        clickable glyph — no button border or background chrome — so
        it doesn't visually masquerade as a regular push button.
        Opacity encodes state: 1.0 when save is on, 0.25 when off.
        """
        if self._save_btn is not None:
            return self._save_btn
        btn = QPushButton("\U0001F5C4️")  # 🗄️ file cabinet
        btn.setCheckable(True)
        btn.setChecked(checked)
        btn.setFixedSize(34, 24)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setToolTip(tooltip or "Save this step's output")
        # Strip the push-button chrome so the glyph reads as a bare
        # icon-toggle rather than "just another button".
        btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 0;
            }
            QPushButton:hover {
                background: rgba(128, 128, 128, 40);
            }
        """)
        # QGraphicsOpacityEffect dims the whole widget (including the
        # emoji glyph) — plain stylesheet color alphas don't reliably
        # affect colour-emoji rendering.
        effect = QGraphicsOpacityEffect(btn)
        effect.setOpacity(1.0 if checked else 0.25)
        btn.setGraphicsEffect(effect)
        btn.toggled.connect(
            lambda state, eff=effect: eff.setOpacity(
                1.0 if state else 0.25))
        # Insert just before the title button (after the step's
        # enable-checkbox, or the leading spacer for non-checkable steps).
        idx = self._header_layout.indexOf(self._details_btn)
        if idx >= 0:
            self._header_layout.insertWidget(idx, btn)
        else:
            self._header_layout.addWidget(btn)
        self._save_btn = btn
        return btn
    def setStatusText(self, t):
        self._status_label.setText(t)
        if "\u26a0" in t:
            self._status_label.setStyleSheet("color: #a0a070;")
        elif "\u2713" in t:
            self._status_label.setStyleSheet("color: #4caf50;")
        else:
            self._status_label.setStyleSheet("color: gray;")

    def _ensure_status_badges(self):
        """Lazily build the [\u2699][\u26a0] badge slot next to the status label.

        Placed right after ``_status_label`` (before the layout's
        addStretch absorbs slack), in a tight inner ``QHBoxLayout``
        with zero margins/spacing \u2014 so when both badges are hidden
        the slot collapses to zero width and the right-anchored
        action buttons (Run / view / reorder / help) keep their
        position pixel-for-pixel.
        """
        if getattr(self, "_badges_widget", None) is not None:
            return
        badges = QWidget()
        badges_lay = QHBoxLayout(badges)
        badges_lay.setContentsMargins(0, 0, 0, 0)
        badges_lay.setSpacing(2)
        # \u2699  U+2699 GEAR \u2014 already text-style in most system fonts.
        self._badge_extras = QLabel("\u2699")
        self._badge_extras.setStyleSheet(
            "color: #a0a070; padding: 0 2px;")
        self._badge_extras.hide()
        badges_lay.addWidget(self._badge_extras)
        # \u26a0\ufe0e  U+26A0 + U+FE0E \u2014 variation-selector forces monochrome
        # so the badge doesn't render as a yellow emoji on platforms
        # that auto-promote U+26A0 to color (iOS / some Linux fonts).
        self._badge_manual = QLabel("\u26a0\ufe0e")
        self._badge_manual.setStyleSheet(
            "color: #a0a070; padding: 0 2px;")
        self._badge_manual.hide()
        badges_lay.addWidget(self._badge_manual)
        idx = self._header_layout.indexOf(self._status_label)
        if idx >= 0:
            self._header_layout.insertWidget(idx + 1, badges)
        else:
            self._header_layout.addWidget(badges)
        self._badges_widget = badges

    def set_extras_badge(self, visible, tooltip=""):
        """Show/hide the \u2699 "step writes extra outputs" badge."""
        self._ensure_status_badges()
        if visible:
            self._badge_extras.setToolTip(tooltip)
            self._badge_extras.show()
        else:
            self._badge_extras.hide()

    def set_manual_badge(self, visible, tooltip=""):
        """Show/hide the \u26a0 "step has interactive review" badge."""
        self._ensure_status_badges()
        if visible:
            self._badge_manual.setToolTip(tooltip)
            self._badge_manual.show()
        else:
            self._badge_manual.hide()
    def hideSeparator(self): self._separator.hide()
    def setReorderVisible(self, visible):
        """Show/hide the up/down reorder arrows.  No-op on non-reorderable steps."""
        if self._up_btn is not None:
            self._up_btn.setVisible(visible)
        if self._dn_btn is not None:
            self._dn_btn.setVisible(visible)


def _is_disclosure_open(w):
    """Read open/closed state from any disclosure widget.  Handles
    CollapsibleGroupBox / CollapsibleStep (which both expose
    ``_collapsed``) and any QAbstractButton-like ``isChecked()``
    widget for backward compat."""
    if hasattr(w, "_collapsed"):
        return not w._collapsed
    return bool(w.isChecked())


def _set_disclosure_open(w, open_):
    """Mirror image of `_is_disclosure_open`."""
    if hasattr(w, "_collapsed"):
        (w.expand if open_ else w.collapse)()
    else:
        w.setChecked(bool(open_))


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Logging bridge                                                      ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class QueueLogHandler(logging.Handler):
    """Route log records to a thread-safe queue for the GUI to drain.

    The queue is bounded — heavy producers (ICLabel, empi) can emit
    >10 k lines/s, much faster than the 500/s GUI drain.  Without a
    bound the queue would grow monotonically on long runs.  When
    full, drop the oldest record (ring-buffer semantics) so the
    most-recent log lines always make it to the UI.
    """
    def __init__(self, log_queue):
        super().__init__()
        self._queue = log_queue
        self._dropped = 0

    def emit(self, record):
        try:
            self._queue.put_nowait(record)
        except queue.Full:
            # Drop oldest, then enqueue the new record.
            try:
                self._queue.get_nowait()
                self._dropped += 1
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(record)
            except queue.Full:
                pass


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Signal bridge (thread → main thread)                                ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class _Signals(QObject):
    """Qt signals emitted from background threads."""
    signal_info_ready = Signal(dict)
    signal_info_error = Signal(str)
    pipeline_finished = Signal(bool)   # True = success
    pipeline_log = Signal(str, str)    # (message, level)
    drop_selection_from_svarog = Signal(list)  # channel names to drop
    step_finished = Signal(str, str, str)  # (step_name, fif_path, error)
    mp_decomp_progress = Signal(int)              # MP decomposition pct 0-100, drives _run_progress
    examples_dl_done = Signal(object)             # True or error string
    mne_sample_done = Signal(str, str)            # (raw_path, cfg_path) or ("", error)
    # Manual bad-channels review: emitted from the pipeline worker
    # thread; handled on the GUI main thread where signal.plot(block=True)
    # is safe. Args: (signal, overlay_events, tags_desc_id, scalings,
    # result_dict, done_event). Worker blocks on done_event; slot
    # populates result_dict["bads"] (or result_dict["error"]) before
    # setting the event.
    manual_bad_channels_requested = Signal(
        object, object, object, object, object, object)
    # Manual ICA component review: same threading pattern as bad-
    # channels. Args: (raw, ica, result_dict, done_event). The slot
    # opens ica.plot_sources on the main thread; result_dict["exclude"]
    # holds the user's final component selection.
    manual_ica_requested = Signal(object, object, object, object)
    # ICA topomap PNG rendering for the Svarog review path: matplotlib
    # from a worker thread segfaults on macOS even with Agg backend
    # (Qt owns NSApp's main loop; Cocoa asserts when mixed).  Route
    # ica.plot_components calls through this signal so rendering runs
    # on the GUI main thread.  Args: (ica, out_dir, result_dict,
    # done_event); slot writes comp_<idx>.png files under out_dir.
    ica_topomaps_requested = Signal(object, object, object, object)
    # Manual bad-epoch review fallback (MNE epochs.plot) on the main
    # thread when Svarog isn't available.  Args: (epochs, result_dict,
    # done_event).  Slot opens MNE's interactive plot; on close
    # populates result_dict["reject_idxs"] with a set of epoch indices
    # the user marked for rejection.
    manual_segments_requested = Signal(object, object, object)
    # Java helper launches (SVAROG, ConnectiVIS): feedback about JVM
    # cold-start lag.  Emitted from a daemon watchdog thread; the main-
    # thread slot updates the status bar and (when a button was passed
    # at launch time) restores its original text + enabled state.
    # Args: (label, exit_code, err_tail, button_or_None). exit_code=0
    # means the child is still alive past the "assume ready" threshold;
    # non-zero means it crashed before that.
    java_launch_done = Signal(str, int, str, object)


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Reusable selection panel (channels, events, etc.)                    ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class SelectionPanel(QGroupBox):
    """Flow-grid of checkboxes with All/None/filter buttons.

    Used for channel selection (with per-type filter buttons) and event
    selection (with occurrence counts). Read state via ``selected_items()``.

    When ``eeg_filter=True``, the panel's button row includes adaptive
    per-type filter buttons (``EEG only``, ``EOG only``, ``EMG only``,
    etc.) that only appear when the corresponding MNE type is present
    in the loaded signal — so a recording with no EOG channels won't
    show an "EOG only" button.

    When ``type_editable=True`` (only the dedicated "Review channel
    types" dialog on the Input tab uses this), each checkbox exposes a
    right-click context menu for editing the channel's MNE type. The
    override request is emitted via
    ``channel_type_override_requested(name, new_type)`` and should be
    routed to the main window's type-override handler. Per-tab panels
    on Preprocessing / Analysis use the default ``type_editable=False``
    — they only CONSUME type info (via the filter buttons) without
    letting the user edit it, so the editing surface stays in one
    place on the Input tab.
    """

    #: Emitted when the user right-clicks a channel and picks a new
    #: type (only fires when ``type_editable=True``). Arguments:
    #: (channel_name, new_type_or_"auto"). Routes to the main window,
    #: which owns the shared type_overrides dict and propagates updates
    #: to every channel panel.
    channel_type_override_requested = Signal(str, str)
    selection_changed = Signal()

    def __init__(self, title="Items", parent=None,
                 eeg_filter=False, type_editable=False,
                 count_in_title=True, named_filter=False):
        super().__init__(parent)
        # objectName lets the light-theme stylesheet target our child
        # QCheckBoxes specifically (subtle bg tint for unchecked-box
        # visibility) without leaking that rule to every checkbox in
        # the app.
        self.setObjectName("SelectionPanel")
        self._checkboxes = []  # list of (item_name, QCheckBox)
        self._all_names = []
        self._ch_types = {}  # name → MNE channel type, when known
        self._eeg_filter = eeg_filter
        self._type_editable = type_editable
        self._named_filter = named_filter
        self._title = title
        # When False, the GroupBox title stays at the bare ``title``
        # and the panel exposes the running count via ``count_text()``
        # for an external label to display elsewhere (e.g. the
        # CollapsibleStep header on the Drop Channels panel).
        self._count_in_title = count_in_title
        self._filter_buttons = []  # adaptive per-type filter buttons
        self._bulk_toggle = False
        self._build_ui()

    def _build_ui(self):
        self._layout = QVBoxLayout(self)
        # Top 14 leaves room for the QGroupBox title (rendered in the
        # box's top edge) — system theme places the title a few pixels
        # lower than dark/light, so 10 wasn't enough.  Bottom 16
        # over-reserves on purpose: Qt sizes QCheckBox to the label
        # baseline, not the descender bottom, so letters like g/p/y/]
        # extend beyond the checkbox's own widget rect — only a
        # generous panel-level margin reliably clears them in every
        # theme.  Outer spacing 6 visually separates title / filter
        # buttons / channel grid.
        self._layout.setContentsMargins(6, 14, 6, 16)
        self._layout.setSpacing(6)
        if self._count_in_title:
            self.setTitle(f"0/0 {self._title.lower()} selected")
        else:
            self.setTitle(self._title)
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self._btn_all = QPushButton("All")
        self._btn_all.setFixedWidth(40)
        self._btn_all.clicked.connect(self._select_all)
        btn_row.addWidget(self._btn_all)
        self._btn_none = QPushButton("None")
        self._btn_none.setFixedWidth(55)
        self._btn_none.clicked.connect(self._select_none)
        btn_row.addWidget(self._btn_none)
        # Optional "Named" button (events panel only): selects exactly
        # the symbolically-named entries, leaving "(code N)" raw STIM
        # codes unchecked.  Built only when ``named_filter=True``.
        self._btn_named = None
        self._named_items = set()
        if self._named_filter:
            self._btn_named = QPushButton("Named")
            self._btn_named.setFixedWidth(70)
            self._btn_named.setToolTip(
                "Check only named events.\n"
                "Un-checks raw integer pulses ('(code N)' entries)\n"
                "that aren't bound to symbolic OBCI tag names —\n"
                "typically button-box codes, sync markers, or raw\n"
                "experimental sequence codes.")
            self._btn_named.clicked.connect(self._select_named)
            btn_row.addWidget(self._btn_named)
        # Placeholder container for adaptive per-type filter buttons.
        # Populated by _rebuild_filter_buttons() whenever channel types
        # change, so recordings without EOG don't show a button for a
        # type not present in the file.
        self._filter_btn_container = QHBoxLayout()
        self._filter_btn_container.setSpacing(6)
        btn_row.addLayout(self._filter_btn_container)
        btn_row.addStretch()
        self._layout.addLayout(btn_row)
        # Grid placeholder.  Horizontal 10 px keeps a label from
        # running into the next checkbox's indicator — light theme with
        # a tighter system font collapses smaller gaps to zero visual
        # space.  Vertical 4 px keeps channel rows legible.
        self._grid_widget = QWidget()
        self._grid = QGridLayout(self._grid_widget)
        self._grid.setContentsMargins(0, 0, 0, 0)
        self._grid.setHorizontalSpacing(10)
        self._grid.setVerticalSpacing(4)
        self._layout.addWidget(self._grid_widget)

    def populate(self, names, selected=None, counts=None, ch_types=None,
                 named_items=None):
        """Fill with item names.

        Parameters
        ----------
        names : list of str
            Item names.
        selected : set of str or None
            Names to check.  ``None`` → all checked (or EEG-only for
            channel panels).
        counts : dict or None
            Optional ``{name: count}`` to display as ``"name (count)"``.
        ch_types : dict or list or None
            For channel panels with ``eeg_filter=True``: per-channel MNE
            type info, used by the "EEG only" filter to trust the file's
            own typing instead of falling back to name patterns. Accepts
            a ``{name: type}`` dict, or a parallel list aligned with
            ``names``. ``None`` (default) → no type info; the filter
            falls back to name pattern matching.
        named_items : iterable of str or None
            For events panels with ``named_filter=True``: which names
            are considered "named" (symbolic) — the [Named] button
            checks exactly these and un-checks the rest.  ``None`` →
            all names are treated as named (button equivalent to All).
        """
        try:
            self._grid.count()
        except RuntimeError:
            return
        # Remove old checkboxes and flow widget
        for _, cb in self._checkboxes:
            cb.setParent(None)
        self._checkboxes.clear()
        while self._grid.count():
            item = self._grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._all_names = list(names)
        # Track which names are "named" (symbolic) for the [Named]
        # button.  When the caller doesn't distinguish, all names
        # are treated as named — button becomes equivalent to All.
        self._named_items = (set(named_items) if named_items is not None
                             else set(self._all_names))
        if ch_types is None:
            self._ch_types = {}
        elif isinstance(ch_types, dict):
            self._ch_types = dict(ch_types)
        else:
            # Parallel list aligned with names
            self._ch_types = dict(zip(names, ch_types))
        if selected is None:
            if self._eeg_filter:
                eeg = self._eeg_names()
                selected = set(eeg) if eeg else set(names)
            else:
                selected = set(names)
        cbs = []
        for name in names:
            label = self._checkbox_label(name, counts)
            cb = QCheckBox(label)
            # 22 px guarantees the widget rect includes the label's
            # descender (g/p/q/y/]).  Qt sizes QCheckBox to the label
            # baseline by default, so letters with descenders clip
            # against the checkbox's own paint clip-rect.  This is a
            # widget-level fix that doesn't disturb indicator
            # rendering (the macOS-fragile QCheckBox::indicator path).
            cb.setMinimumHeight(22)
            cb.setChecked(name in selected)
            cb.stateChanged.connect(self._update_count)
            if self._eeg_filter:
                self._apply_cb_style(cb, name)
            if self._type_editable:
                # Right-click context menu for channel type overrides
                # — only wired on panels where type editing is the
                # point (currently just the Input tab review dialog).
                cb.setContextMenuPolicy(Qt.CustomContextMenu)
                cb.customContextMenuRequested.connect(
                    lambda pos, n=name, c=cb:
                    self._show_channel_type_menu(n, c, pos))
            self._checkboxes.append((name, cb))
            cbs.append(cb)
        flow = _flow_widget(cbs, spacing=10, vspacing=8)
        flow.setMinimumHeight(28)
        self._grid.addWidget(flow, 0, 0)
        self._update_count()
        self._rebuild_filter_buttons()

    def _checkbox_label(self, name, counts=None):
        """Build the display text for a channel/item checkbox.

        For EEG-filter panels, channels whose current type is not 'eeg'
        get a trailing type badge so the user can see at a glance what
        kind of signal is on each row.
        """
        base = f"{name}  ({counts[name]})" if counts and name in counts else name
        if self._eeg_filter and self._ch_types:
            t = self._ch_types.get(name)
            if t and t != "eeg":
                base = f"{name} [{t}]"
        return base

    def _apply_cb_style(self, cb, name):
        """Dim channels that are not currently typed as EEG."""
        if self._ch_types:
            t = self._ch_types.get(name)
            if t and t != "eeg":
                cb.setStyleSheet("color: gray;")
            else:
                cb.setStyleSheet("")

    def set_channel_types(self, ch_types):
        """Replace the type dict without destroying checkboxes.

        Refreshes the visible label, the gray styling on every
        checkbox, and the adaptive filter button row. Preserves the
        user's current selection. Used when an override is applied
        via the Review channel types dialog so the panel reflects
        the new types immediately without losing the checked state.
        """
        if isinstance(ch_types, dict):
            self._ch_types = dict(ch_types)
        else:
            self._ch_types = dict(zip(self._all_names, ch_types))
        for name, cb in self._checkboxes:
            # Preserve label after any optional "(count)" suffix
            cb.setText(self._checkbox_label(name))
            if self._eeg_filter:
                self._apply_cb_style(cb, name)
        self._rebuild_filter_buttons()

    def _show_channel_type_menu(self, name, cb, pos):
        """Show a right-click menu with MNE channel type options for
        ``name``. The ``auto`` entry removes any existing override."""
        from PySide6.QtWidgets import QMenu
        menu = QMenu(cb)
        current = self._ch_types.get(name, "?")
        header = menu.addAction(f"{name}  (current: {current})")
        header.setEnabled(False)
        menu.addSeparator()
        # MNE channel types the user can pick from (matches
        # readmanager.chtype_heuristic vocabulary plus rarer MNE
        # natives).  "auto" is the UI sentinel for "drop the override
        # and let the auto-inferred type win".
        for choice in ("auto", "eeg", "eog", "emg", "ecg",
                       "bio", "stim", "misc",
                       "ref_meg", "seeg", "ecog", "dbs", "fnirs"):
            label = "use auto-inferred" if choice == "auto" else choice
            action = menu.addAction(label)
            if choice == current:
                action.setEnabled(False)
            action.triggered.connect(
                lambda _=False, n=name, c=choice:
                self.channel_type_override_requested.emit(n, c))
        menu.exec(cb.mapToGlobal(pos))

    def selected_items(self):
        """Return list of checked item names."""
        return [name for name, cb in self._checkboxes if cb.isChecked()]

    # Backward compat alias
    selected_channels = selected_items

    def _update_count(self):
        if self._count_in_title:
            n = sum(1 for _, cb in self._checkboxes if cb.isChecked())
            self.setTitle(
                f"{n}/{len(self._checkboxes)} "
                f"{self._title.lower()} selected")
        if not self._bulk_toggle:
            self.selection_changed.emit()

    def count_text(self):
        """Return "{n}/{total} {item_type} selected" for an external
        label.  Used when ``count_in_title=False`` and the count
        belongs somewhere other than the GroupBox title."""
        n = sum(1 for _, cb in self._checkboxes if cb.isChecked())
        return (f"{n}/{len(self._checkboxes)} "
                f"{self._title.lower()} selected")

    def _select_all(self):
        self._bulk_toggle = True
        for _, cb in self._checkboxes:
            cb.setChecked(True)
        self._bulk_toggle = False
        self._update_count()

    def _select_none(self):
        self._bulk_toggle = True
        for _, cb in self._checkboxes:
            cb.setChecked(False)
        self._bulk_toggle = False
        self._update_count()

    def _select_named(self):
        """Check exactly the entries in ``self._named_items``.

        Used by the events panel's "Named" button — selects symbolic
        OBCI tags and unchecks raw "(code N)" pulses.
        """
        self._bulk_toggle = True
        for name, cb in self._checkboxes:
            cb.setChecked(name in self._named_items)
        self._bulk_toggle = False
        self._update_count()
        self.selection_changed.emit()

    # ── EEG channel filtering (only when eeg_filter=True) ───────────

    # Generic non-EEG channel name patterns, case-insensitive substring
    # match. Only used as a fallback when MNE channel types are unknown
    # or generic — when types come from the file (the common case),
    # they take precedence and this list is never consulted.
    _NON_EEG_PATTERNS = (
        "eog", "eogl", "eogr", "eogv", "eogh", "eogp",
        "emg", "ecg", "ekg",
        "resp", "res ", "gsr", "temp", "spo2", "hr",
        "stim", "trig", "trigger", "status", "marker", "sync",
        "ref", "mast", "a1", "a2", "m1", "m2",
        "ecog", "seeg", "dbs", "fnirs",
        "audio", "photo", "phones", "haptic", "eyetrack",
    )

    def _is_eeg(self, name):
        """Decide whether ``name`` is an EEG channel.

        Trusts MNE channel types when available (set by the file-format
        reader at load time). Falls back to a case-insensitive substring
        match against ``_NON_EEG_PATTERNS`` only when no type info exists
        for this channel — e.g. before a file is loaded, or for files
        whose reader doesn't propagate per-channel types.
        """
        ch_type = self._ch_types.get(name) if self._ch_types else None
        if ch_type:
            return ch_type == "eeg"
        lname = name.lower()
        return not any(p in lname for p in self._NON_EEG_PATTERNS)

    def _eeg_names(self):
        return [name for name in self._all_names if self._is_eeg(name)]

    def _select_eeg(self):
        """Backward-compat shortcut used by the main window's
        "default MP channels to EEG only" logic and other callers."""
        self._select_by_type("eeg")

    def _select_by_type(self, ch_type):
        """Check only the channels whose current MNE type matches
        ``ch_type``. Handles both typed channels (via ``_ch_types``)
        and the name-fallback for ``ch_type == "eeg"``."""
        if ch_type == "eeg" and not self._ch_types:
            # No type info — use the name-substring fallback
            for name, cb in self._checkboxes:
                cb.setChecked(self._is_eeg(name))
            return
        for name, cb in self._checkboxes:
            t = self._ch_types.get(name)
            cb.setChecked(t == ch_type)

    def _toggle_type(self, ch_type):
        """Add or remove all channels of ``ch_type`` from the selection.

        If every channel of that type is already checked, uncheck them
        all; otherwise check all of them without touching the other
        channels.  This is the action wired to the type filter buttons
        (as opposed to :meth:`_select_by_type`, which replaces the
        whole selection).
        """
        if ch_type == "eeg" and not self._ch_types:
            # No type info — use the name-fallback
            targets = [cb for name, cb in self._checkboxes
                       if self._is_eeg(name)]
        else:
            targets = [cb for name, cb in self._checkboxes
                       if self._ch_types and
                       self._ch_types.get(name) == ch_type]
        if not targets:
            return
        self._bulk_toggle = True
        if all(cb.isChecked() for cb in targets):
            for cb in targets:
                cb.setChecked(False)
        else:
            for cb in targets:
                cb.setChecked(True)
        self._bulk_toggle = False
        self._update_count()

    # Display-friendly labels for type filter buttons. Falls back to
    # the raw MNE type name for types not listed here.
    _TYPE_LABELS = {
        "eeg": "EEG", "eog": "EOG", "emg": "EMG", "ecg": "ECG",
        "bio": "BIO", "stim": "STIM", "misc": "MISC",
        "ref_meg": "REF", "seeg": "sEEG", "ecog": "ECoG",
        "dbs": "DBS", "fnirs": "fNIRS",
    }

    def _rebuild_filter_buttons(self):
        """Rebuild the adaptive per-type filter buttons in the button
        row, based on which MNE types are currently present in the
        panel's type dict. Called whenever types change (populate,
        set_channel_types, or an override applied)."""
        if not self._eeg_filter:
            return
        # Clear existing filter buttons
        for btn in self._filter_buttons:
            btn.setParent(None)
            btn.deleteLater()
        self._filter_buttons = []
        # Count types present in the loaded signal
        if not self._ch_types:
            # No type info — show a single "EEG" name-fallback
            # button so the panel isn't bare before a file is loaded.
            btn = QPushButton("EEG")
            btn.setFixedWidth(50)
            btn.clicked.connect(lambda: self._toggle_type("eeg"))
            self._filter_btn_container.addWidget(btn)
            self._filter_buttons.append(btn)
            return
        from collections import Counter
        counts = Counter(self._ch_types.get(n)
                         for n in self._all_names)
        # Stable display order: eeg first, then everything else in
        # MNE's canonical order, then any unknown types.
        preferred_order = ("eeg", "eog", "emg", "ecg", "bio", "stim",
                           "misc", "ref_meg", "seeg", "ecog", "dbs",
                           "fnirs")
        seen_types = [t for t in preferred_order if counts.get(t, 0) > 0]
        for t in sorted(counts):
            if t and t not in preferred_order:
                seen_types.append(t)
        for t in seen_types:
            if not t:
                continue
            label = self._TYPE_LABELS.get(t, t)
            count = counts[t]
            btn = QPushButton(f"{label} ({count})")
            btn.setToolTip(
                f"Add/remove all '{t}' channels ({count} in this file) "
                f"from selection")
            btn.clicked.connect(
                lambda _=False, ct=t: self._toggle_type(ct))
            self._filter_btn_container.addWidget(btn)
            self._filter_buttons.append(btn)


# Backward compat alias
ChannelPanel = SelectionPanel


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Reusable MP atom parameter table                                    ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class AtomFilterTable(QGroupBox):
    """Reusable single- or multi-row table for MP atom selection by parameter ranges.

    Base columns (always present):
        f_min, f_max, a_min, a_max, s_min, s_max, max_iter

    Optional extra columns prepended when ``show_name=True`` / ``show_mode=True``
    (used by EEG Profiles, which also allows multiple rows).

    Presets come from ``ide4eeg.analysis.eeg_profiles.PRESETS``.

    Parameters
    ----------
    title : str
        GroupBox title.
    multi_row : bool
        If True, show Add / Remove / ▲ / ▼ buttons and allow multiple rows.
    show_name : bool
        Prepend a "Name" text column.
    show_mode : bool
        Prepend a "Mode" combo column (count / percentage / amplitudes / power).
    show_preset : bool
        Show a Preset dropdown above the table.
    """

    # Base columns: key, header, tooltip
    _BASE_COLS = [
        ("freq_min",  "f_min",    "Minimum frequency [Hz].\n0 = no lower bound."),
        ("freq_max",  "f_max",    "Maximum frequency [Hz].\n0 = no upper bound (Nyquist)."),
        ("amp_min",   "a_min",    "Minimum amplitude [\u00b5V].\n0 = no lower bound."),
        ("amp_max",   "a_max",    "Maximum amplitude [\u00b5V].\n0 = no upper bound."),
        ("scale_min", "s_min",    "Minimum atom scale (duration) [s].\n0 = no lower bound."),
        ("scale_max", "s_max",    "Maximum atom scale (duration) [s].\n0 = no upper bound."),
        ("max_iterations", "max_iter",
         "Include only atoms from the first N MP iterations.\n0 = all iterations."),
    ]

    MODES = ["count", "percentage", "amplitudes", "power"]

    def __init__(self, title="Atom filter", parent=None, *,
                 multi_row=False, show_name=False, show_mode=False,
                 show_preset=True):
        super().__init__(title, parent)
        self._multi_row = multi_row
        self._show_name = show_name
        self._show_mode = show_mode
        self._show_preset = show_preset

        # Build column map: list of (config_key, header, tooltip, kind)
        # kind: "text", "mode", or "num"
        self._columns = []
        if show_name:
            self._columns.append(("name", "Name", "Structure name.", "text"))
        if show_mode:
            self._columns.append(
                ("mode", "Mode",
                 "Display mode for structure counts:\n"
                 "\u2022 count \u2014 number of matching atoms per bin\n"
                 "\u2022 percentage \u2014 fraction of total atoms\n"
                 "\u2022 amplitudes \u2014 sum of atom amplitudes\n"
                 "\u2022 power \u2014 sum of atom energy",
                 "mode"))
        for key, hdr, tip in self._BASE_COLS:
            self._columns.append((key, hdr, tip, "num"))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 8, 4, 4)
        layout.setSpacing(2)

        # ── Preset row ──────────────────────────────────────────────
        if show_preset:
            from ide4eeg.analysis.eeg_profiles import PRESETS as _P
            self._presets = _P
            pr = QHBoxLayout()
            pr.addWidget(QLabel("Preset:"))
            self._preset_combo = QComboBox()
            names = (["(Custom)"] + [p["name"] for p in _P])
            self._preset_combo.addItems(names)
            self._preset_combo.setToolTip(
                "Select a predefined atom filter.\n"
                "Choose (Custom) to set all fields manually.")
            pr.addWidget(self._preset_combo)
            if multi_row:
                add_btn = QPushButton("Add")
                add_btn.setFixedWidth(55)
                add_btn.setToolTip("Add preset as a new row")
                add_btn.clicked.connect(self._add_preset_row)
                rm_btn = QPushButton("Remove")
                rm_btn.setFixedWidth(75)
                rm_btn.setToolTip("Remove selected row(s)")
                rm_btn.clicked.connect(self._remove_selected)
                up_btn = QPushButton("\u25b2"); up_btn.setFixedSize(24, 24)
                up_btn.setToolTip("Move row up")
                up_btn.clicked.connect(lambda: self._move_row(-1))
                dn_btn = QPushButton("\u25bc"); dn_btn.setFixedSize(24, 24)
                dn_btn.setToolTip("Move row down")
                dn_btn.clicked.connect(lambda: self._move_row(1))
                pr.addWidget(add_btn); pr.addSpacing(4)
                pr.addWidget(rm_btn); pr.addSpacing(8)
                pr.addWidget(up_btn); pr.addWidget(dn_btn)
            else:
                self._preset_combo.currentTextChanged.connect(
                    self._apply_preset)
                add_btn = QPushButton("Add")
                add_btn.setFixedWidth(55)
                add_btn.setToolTip("Add a new filter row from the\nselected preset")
                add_btn.clicked.connect(self._add_preset_row)
                rm_btn = QPushButton("Remove")
                rm_btn.setFixedWidth(75)
                rm_btn.setToolTip("Remove selected row(s)")
                rm_btn.clicked.connect(self._remove_selected)
                clr_btn = QPushButton("Clear")
                clr_btn.setFixedWidth(55)
                clr_btn.setToolTip("Reset all filter fields to 0\n(no constraint)")
                clr_btn.clicked.connect(self._clear_single_row)
                pr.addWidget(add_btn); pr.addSpacing(4)
                pr.addWidget(rm_btn); pr.addSpacing(4)
                pr.addWidget(clr_btn)
            pr.addStretch()
            layout.addLayout(pr)
        else:
            self._presets = []
            self._preset_combo = None

        # ── Table ───────────────────────────────────────────────────
        ncols = len(self._columns)
        self._table = QTableWidget(0, ncols)
        self._table.setHorizontalHeaderLabels(
            [hdr for _, hdr, _, _ in self._columns])
        for c, (_, _, tip, _) in enumerate(self._columns):
            self._table.horizontalHeaderItem(c).setToolTip(tip)
        self._table.verticalHeader().hide()
        self._table.horizontalHeader().setDefaultSectionSize(55)
        if show_name:
            self._table.horizontalHeader().setSectionResizeMode(
                0, QHeaderView.Stretch)
        if show_mode:
            mc = 1 if show_name else 0
            self._table.setColumnWidth(mc, 90)
        # Lock min == max so parent layouts don't stretch the table;
        # past 2 rows the user gets a scrollbar instead of padding.
        two_row_h = (
            self._table.horizontalHeader().sizeHint().height()
            + 2 * self._table.verticalHeader().defaultSectionSize()
            + 2 * self._table.frameWidth())
        self._table.setMinimumHeight(two_row_h)
        self._table.setMaximumHeight(two_row_h)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        if not multi_row:
            self._init_single_row()

        layout.addWidget(self._table)
        if not multi_row:
            hint = QLabel("(0 = no constraint)")
            hint.setStyleSheet("color: gray;")
            layout.addWidget(hint)

    # ── Public API ──────────────────────────────────────────────────

    def populate(self, rows):
        """Fill the table from a list of dicts.

        Each dict should have keys matching the config keys in ``_columns``
        (e.g. ``freq_min``, ``name``, ``mode``).
        """
        self._table.setRowCount(0)
        for d in rows:
            self._append_row(d)

    def collect(self):
        """Read all rows into a list of dicts."""
        result = []
        for row in range(self._table.rowCount()):
            d = {}
            for col, (key, _, _, kind) in enumerate(self._columns):
                if kind == "mode":
                    w = self._table.cellWidget(row, col)
                    d[key] = w.currentText() if w else "count"
                elif kind == "text":
                    item = self._table.item(row, col)
                    d[key] = item.text().strip() if item else ""
                else:
                    item = self._table.item(row, col)
                    try:
                        d[key] = float(item.text()) if item else 0
                    except (ValueError, TypeError):
                        d[key] = 0
            result.append(d)
        return result

    def collect_single(self):
        """Return the first row as a flat dict (convenience for single-row mode)."""
        rows = self.collect()
        return rows[0] if rows else {k: 0 for k, _, _, _ in self._columns}

    def set_single(self, d):
        """Populate the single row from a dict (convenience for single-row mode)."""
        if self._table.rowCount() == 0:
            self._init_single_row()
        for col, (key, _, _, kind) in enumerate(self._columns):
            val = d.get(key, 0 if kind == "num" else "")
            if kind == "mode":
                w = self._table.cellWidget(0, col)
                if w:
                    w.setCurrentText(str(val))
            else:
                item = self._table.item(0, col)
                if item:
                    item.setText(str(val))

    def set_freq_max_nyquist(self, nyq):
        """Set freq_max to *nyq* in every row where it is 0."""
        col = self._col_index("freq_max")
        if col is None:
            return
        for row in range(self._table.rowCount()):
            item = self._table.item(row, col)
            if item and item.text().strip() in ("0", "0.0", ""):
                item.setText(str(nyq))

    # ── Internal helpers ────────────────────────────────────────────

    def _col_index(self, key):
        for i, (k, _, _, _) in enumerate(self._columns):
            if k == key:
                return i
        return None

    def _init_single_row(self):
        """Ensure one blank row exists in single-row mode."""
        if self._table.rowCount() == 0:
            self._append_row({})

    def _append_row(self, d):
        row = self._table.rowCount()
        self._table.insertRow(row)
        for col, (key, _, _, kind) in enumerate(self._columns):
            val = d.get(key, "")
            if kind == "mode":
                combo = QComboBox()
                combo.addItems(self.MODES)
                combo.setCurrentText(
                    str(val) if str(val) in self.MODES else "amplitudes")
                self._table.setCellWidget(row, col, combo)
            else:
                default = "" if kind == "text" else "0"
                self._table.setItem(row, col,
                                    QTableWidgetItem(str(val) if val != "" else default))

    def _apply_preset(self, text):
        """Single-row mode: fill the row from a preset."""
        if text == "(Custom)":
            d = {}
        else:
            d = next((p for p in self._presets if p["name"] == text), {})
        if self._table.rowCount() == 0:
            self._init_single_row()
        for col, (key, _, _, kind) in enumerate(self._columns):
            if kind == "mode":
                continue  # don't overwrite mode from preset
            val = d.get(key, 0 if kind == "num" else "")
            item = self._table.item(0, col)
            if item:
                item.setText(str(val))

    def _clear_single_row(self):
        """Single-row mode: reset all numeric fields to 0."""
        if self._table.rowCount() == 0:
            return
        for col, (_, _, _, kind) in enumerate(self._columns):
            if kind == "num":
                item = self._table.item(0, col)
                if item:
                    item.setText("0")
        if self._preset_combo:
            self._preset_combo.setCurrentText("(Custom)")

    def _add_preset_row(self):
        """Multi-row mode: add a new row from the selected preset."""
        if not self._preset_combo:
            return
        text = self._preset_combo.currentText()
        if text == "(Custom)":
            d = {"name": "(edit name)"} if self._show_name else {}
        else:
            d = next((p for p in self._presets if p["name"] == text), {})
        self._append_row(d)

    def _remove_selected(self):
        rows = sorted({idx.row() for idx in self._table.selectedIndexes()},
                      reverse=True)
        for row in rows:
            self._table.removeRow(row)

    def _move_row(self, direction):
        row = self._table.currentRow()
        if row < 0:
            return
        new_row = row + direction
        if new_row < 0 or new_row >= self._table.rowCount():
            return
        ncols = self._table.columnCount()
        def _rdata(r):
            out = []
            for c in range(ncols):
                w = self._table.cellWidget(r, c)
                if isinstance(w, QComboBox):
                    out.append(("combo", w.currentText()))
                else:
                    item = self._table.item(r, c)
                    out.append(("item", item.text() if item else ""))
            return out
        src, dst = _rdata(row), _rdata(new_row)
        def _sdata(r, data):
            for c, (kind, val) in enumerate(data):
                if kind == "combo":
                    w = self._table.cellWidget(r, c)
                    if isinstance(w, QComboBox):
                        w.setCurrentText(val)
                else:
                    self._table.setItem(r, c, QTableWidgetItem(val))
        _sdata(row, dst); _sdata(new_row, src)
        self._table.setCurrentCell(new_row, 0)


ChannelPanel = SelectionPanel  # alias used by some panels


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Reusable MP Book + Channel selector panel                           ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class BookChannelPanel(QGroupBox):
    """Reusable 'MP Book' panel: book pulldown (full width), then
    [Refresh] + Channel combo + 'no book' warning on the second row.

    Used by EEG Profiles and Dipole.
    Call ``refresh(book_paths)`` to populate the Book combo.
    Channel combo is populated from book metadata when a book is selected.
    """

    def __init__(self, parent=None, title="MP Book",
                 no_book_msg="No book found. Run MP decomposition first.",
                 mmp_only=False, show_channel=True,
                 pipeline_info_fn=None,
                 pipeline_channels_fn=None):
        super().__init__(title, parent)
        self._mmp_only = mmp_only
        self._mmp1_only = mmp_only  # dipole fitting: MMP1 only
        self._pipeline_info_fn = pipeline_info_fn
        self._pipeline_channels_fn = pipeline_channels_fn
        v = QVBoxLayout(self)
        v.setSpacing(4)
        # Row 1: book combo + Channel + Refresh (single line)
        h = QHBoxLayout()
        h.setSpacing(8)
        self._book_combo = QComboBox()
        self._book_combo.setMaximumWidth(250)
        self._book_combo.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._book_combo.currentIndexChanged.connect(self._on_book_changed)
        h.addWidget(self._book_combo)
        self._ch_label = QLabel("Channel:")
        self._ch_combo = QComboBox()
        self._ch_combo.setMinimumWidth(80)
        if show_channel:
            h.addWidget(self._ch_label)
            h.addWidget(self._ch_combo)
        else:
            self._ch_label.hide()
            self._ch_combo.hide()
        ref_btn = QPushButton("Refresh")
        ref_btn.setFixedWidth(68)
        ref_btn.setToolTip("Re-scan output directories for MP books")
        ref_btn.clicked.connect(lambda: self.request_refresh.emit())
        h.addWidget(ref_btn)
        self._no_book_label = QLabel(no_book_msg)
        self._no_book_label.setStyleSheet("color: gray;")
        h.addWidget(self._no_book_label)
        h.addStretch()
        v.addLayout(h)
        # Row 3: book info (path + metadata)
        self._book_info = QLabel("")
        self._book_info.setWordWrap(True)
        self._book_info.setStyleSheet("color: gray; font-size: 11px;")
        v.addWidget(self._book_info)
        self._book_paths = []  # parallel to combo items
        self._update_no_book_msg()

    def _update_no_book_msg(self):
        has_book = self.selected_book() or self._is_pipeline_selected()
        self._no_book_label.setVisible(not has_book)

    request_refresh = Signal()

    _PIPELINE_SENTINEL = "_pipeline_"

    def _is_pipeline_selected(self):
        """True if the current combo item is the pipeline entry."""
        idx = self._book_combo.currentIndex()
        return (idx >= 0
                and self._book_combo.itemData(idx, Qt.UserRole)
                == self._PIPELINE_SENTINEL)

    def refresh(self, book_paths, mp_enabled=False):
        """Populate the Book combo from a list of .db file paths.

        Parameters
        ----------
        book_paths : list of str
        mp_enabled : bool
            If True, show the current MP decomposition settings as
            the first option.
        """
        self._book_paths = list(book_paths)
        prev = self._book_combo.currentText()
        self._book_combo.blockSignals(True)
        self._book_combo.clear()
        if mp_enabled:
            label = self._pipeline_info_fn() if self._pipeline_info_fn else ""
            label = label or "MP decomposition (configure in Preprocessing tab)"
            self._book_combo.addItem(label)
            self._book_combo.setItemData(
                0, self._PIPELINE_SENTINEL, Qt.UserRole)
            self._book_combo.setItemData(
                0, "Uses the book produced by the MP decomposition\n"
                "step in the current pipeline run.", Qt.ToolTipRole)
        for bp in self._book_paths:
            self._book_combo.addItem(os.path.basename(bp))
            self._book_combo.setItemData(
                self._book_combo.count() - 1, bp, Qt.ToolTipRole)
        # Restore previous selection if still available
        idx = self._book_combo.findText(prev)
        if idx >= 0:
            self._book_combo.setCurrentIndex(idx)
        self._book_combo.blockSignals(False)
        self._on_book_changed(self._book_combo.currentIndex())
        self._update_no_book_msg()

    def selected_book(self):
        """Return the currently selected book path, or ''."""
        if self._is_pipeline_selected():
            return ""
        # Find offset: skip the pipeline entry if present
        offset = 1 if (self._book_combo.count() > 0
                       and self._book_combo.itemData(0, Qt.UserRole)
                       == self._PIPELINE_SENTINEL) else 0
        idx = self._book_combo.currentIndex() - offset
        if 0 <= idx < len(self._book_paths):
            return self._book_paths[idx]
        return ""

    def selected_channel(self):
        """Return the currently selected channel name, or ''."""
        return self._ch_combo.currentText()

    def _on_book_changed(self, index):
        """Read channel names and metadata from the selected book."""
        self._ch_combo.clear()
        self._book_info.setText("")
        if self._is_pipeline_selected():
            self._book_info.setText("")
            if self._pipeline_channels_fn:
                channels = self._pipeline_channels_fn()
                if channels:
                    self._ch_combo.addItems(channels)
            self._update_no_book_msg()
            return
        bp = self.selected_book()
        if not bp or not os.path.isfile(bp):
            return
        try:
            import sqlite3
            with sqlite3.connect(bp) as conn:
                meta = dict(conn.execute(
                    "SELECT param, value FROM metadata").fetchall())
            ch_names_raw = meta.get("channel_names", "")
            if ch_names_raw:
                channels = [c.strip() for c in ch_names_raw.split(",")
                            if c.strip()]
                self._ch_combo.addItems(channels)
            elif "channels_count" in meta:
                n = int(meta["channels_count"])
                self._ch_combo.addItems([str(i) for i in range(n)])
            if self._ch_combo.count() == 0:
                name = os.path.splitext(os.path.basename(bp))[0]
                parts = name.split("_")
                if len(parts) >= 2:
                    self._ch_combo.addItem(parts[-1])
            # Build info string
            parts = [bp]
            algo = meta.get("algorithm", "")
            if algo:
                parts.append(f"algorithm: {algo}")
            n_ch = meta.get("channel_count", meta.get("channels_count", ""))
            n_seg = meta.get("segment_count", "")
            if n_ch or n_seg:
                parts.append(
                    f"{n_ch} ch × {n_seg} segments" if n_ch and n_seg
                    else f"{n_ch} channels" if n_ch
                    else f"{n_seg} segments")
            src = meta.get("source_file", "")
            if src:
                parts.append(f"source: {src}")
            mode = meta.get("analysis_mode", "")
            if mode:
                parts.append(f"mode: {mode}")
            sz = os.path.getsize(bp)
            parts.append(f"size: {sz / 2**20:.1f} MB" if sz > 2**20
                         else f"size: {sz / 2**10:.0f} KB")
            self._book_info.setText("  |  ".join(parts))
        except Exception:
            self._book_info.setText(bp)
        self._update_no_book_msg()


class _ToolPathLabel(QLabel):
    """Inline path display with a ✓ / ✗ marker.

    Mirrors enough of the QLineEdit interface (``text()`` /
    ``setText()``) that it drops in for the path-edit widgets
    used by :meth:`IDE4EEG_Qt._tool_path_block` without forcing
    every read site (~20 of them) to switch APIs.  The raw path
    is stored as a plain string; the rendered text shows either
    ``✓ /path``, ``✗ /path (not found)``, or ``not configured``
    depending on whether the file exists on disk.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._raw_path = ""
        self.setTextInteractionFlags(
            Qt.TextSelectableByMouse
            | Qt.TextSelectableByKeyboard)
        self.setStyleSheet("QLabel { color: gray; }")
        self._update_display()

    def text(self):
        return self._raw_path

    def setText(self, value):
        self._raw_path = (value or "").strip()
        self._update_display()

    def _update_display(self):
        path = self._raw_path
        if not path:
            super().setText(
                "<span style='color:#888'>not configured</span>")
            return
        # Show full path inline; tooltip duplicates it so the row
        # stays informative even if the layout truncates.
        if os.path.isfile(path):
            super().setText(
                f"<span style='color:{_OK_COLOR}'>✓</span> {path}")
        else:
            super().setText(
                f"<span style='color:{_ERR_COLOR}'>✗</span> {path} "
                "<span style='color:#888'>(not found)</span>")
        # Refresh tooltip with the path so a hover shows the
        # full text even when the row's allocated width is small.
        self.setToolTip(path)


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Main window                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════╝

class IDE4EEG_Qt(QMainWindow):
    """Qt6 main window for IDE4EEG."""

    # Display ↔ config mapping for the segment mode combo
    _MODE_DISPLAY = {"rest": "timed windows", "epochs": "event-locked"}
    _MODE_CONFIG = {"timed windows": "rest", "event-locked": "epochs"}

    # Preprocessing step key (GUI widget tag) → pipeline step names.
    # Used both by reorder-time constraint validation and by
    # ``_collect_config`` when serialising ``step_order`` to TOML.
    # ``segment_rejection`` maps to an empty list — it's a GUI-only
    # row not present in ``STEP_REGISTRY`` and never participates
    # in ``validate_step_order``.  ``gaze`` and ``artifacts`` both
    # map to the same pipeline ``artifacts`` step (one panel
    # configures EEG-side detectors, the other the video-side
    # gaze detector); the dedup in ``_step_widgets_to_pipeline_order``
    # collapses them to a single entry whose position follows
    # whichever widget comes first in ``_step_widgets``.
    _GUI_TO_PIPELINE_STEPS = {
        "trim":              ["trim"],
        "select":            ["chosen_channels"],
        "bad_channels":      ["bad_channels"],
        "montage":           ["montage"],
        "reference":         ["reference"],
        "resample":          ["resample"],
        "filtering":         ["filtering"],
        "ica":               ["ica"],
        "gaze":              ["gaze_artifacts"],
        "artifacts":         ["eeg_artifacts"],
        "mp_decomposition":  ["mp_decomposition"],
        "mp_filter":         ["mp_filter"],
        "segment_rejection": [],
    }

    # Per-panel "what does this actually call?" info, surfaced as a
    # small gray label at the top of each panel's content (replacing
    # the old parenthesised subtitle in the header).  Tuple is
    # ``(callable_path, config_section_string)``.  ``None`` for
    # callable_path on grouping panels (segmentation_setup, gaze)
    # that drive multiple pipeline steps.
    _STEP_PYINFO = {
        "trim":               ("channels_and_signal._trim_signal",
                                "[trim], trim_start, trim_end"),
        "select":             ("channels_and_signal._select_channels",
                                "[choosing_channels]"),
        "bad_channels":       ("channels_and_signal._find_bad_channels",
                                "[bad_channels], [choosing_channels]"),
        "montage":            ("channels_and_signal._set_montage",
                                "[montage], electrodes_layout"),
        "reference":          ("channels_and_signal._set_reference",
                                "[reference], re_reference"),
        "resample":           ("channels_and_signal._resample_signal",
                                "[resample], resample_freq"),
        "ica":                ("ica.fit_and_apply_ica", "[ICA_EOG]"),
        "artifacts":          ("artifacts._detect_eeg_artifacts",
                                "[artifacts]"),
        "mp_decomposition":   ("mp_preprocessing.mp_decompose",
                                "[matching_pursuit]"),
        "mp_filter":          ("mp_preprocessing.mp_filter",
                                "[mp_filter]"),
        "segment_rejection":  ("rest_and_epochs._remove_bad_segments",
                                "[segment_rejection]"),
        # Segmentation setup also documents the always-runs
        # cut_segments postamble step (rest_and_epochs._cut_segments)
        # since cut params live in the same config blocks.
        "segmentation_setup": (None,
                                "[segmentation], [rest], [epochs], "
                                "events_desc_id"),
        # Gaze drives several functions inside the facetag/ submodule
        # (identity matching, gaze estimation, video artifact scoring),
        # so a single "function:" pointer would be misleading.  We
        # surface the source folder instead — third tuple slot is the
        # optional module/folder path, rendered before "config:".
        "gaze":               (None, "[gaze]",
                                "ide4eeg/preprocessing/facetag/"),
    }

    def _step_info_label(self, step_key, filter_id=None):
        """Tiny gray label showing the actual Python function called
        and the TOML config section(s) consumed by this panel.

        Caller inserts at the top of the panel's content layout (see
        ``_add_step_info_row``).  Replaces the old parenthesised
        subtitle in the header so the header stays uncluttered.

        For multi-instance "filtering" panels, the supplied
        ``filter_id`` is rendered in the config string as
        ``[filters.<id>]`` so each panel shows its own slot.
        """
        folder = None
        if step_key == "filtering":
            fn = "channels_and_signal._filter_signal"
            cfg = (f"[filters.{filter_id}]" if filter_id
                   else "[filters]")
        else:
            entry = self._STEP_PYINFO.get(step_key)
            if entry is None:
                return None
            if len(entry) == 3:
                fn, cfg, folder = entry
            else:
                fn, cfg = entry
        parts = []
        if fn:
            parts.append(
                f"function: <code>ide4eeg.preprocessing.{fn}</code>")
        if folder:
            parts.append(f"module: <code>{folder}</code>")
        if cfg:
            parts.append(f"config: <code>{cfg}</code>")
        if not parts:
            return None
        text = "&nbsp;&nbsp;|&nbsp;&nbsp;".join(parts)
        lbl = QLabel(
            f"<span style='color: #888; font-size: 10px;'>"
            f"{text}</span>")
        lbl.setTextFormat(Qt.TextFormat.RichText)
        lbl.setStyleSheet("padding: 2px 0;")
        lbl.setWordWrap(True)
        return lbl

    def _add_step_info_row(self, grp, step_key, filter_id=None):
        """Insert the small function/config info row at the top of a
        panel's content layout.  No-op if the step has no entry in
        ``_STEP_PYINFO`` (or the step_key is unknown).

        Tracked in ``self._pyinfo_labels`` so the Config-tab
        "Display functions and config names in panels" toggle can
        flip visibility on every panel at once.  Visibility is
        applied immediately to match the current toggle state.
        """
        info = self._step_info_label(step_key, filter_id)
        if info is None:
            return
        layout = grp.contentWidget().layout()
        # All current panel contents use a vertical layout (with
        # other layouts nested inside).  insertWidget keeps the info
        # row at the very top regardless of what comes after.
        try:
            layout.insertWidget(0, info)
        except (AttributeError, TypeError):
            layout.addWidget(info)
        if not hasattr(self, "_pyinfo_labels"):
            self._pyinfo_labels = []
        self._pyinfo_labels.append(info)
        info.setVisible(
            getattr(self, "_show_pyinfo_check", None) is not None
            and self._show_pyinfo_check.isChecked())

    def _on_show_pyinfo_toggled(self, checked):
        """Show/hide the function/config info row on every panel."""
        for lbl in getattr(self, "_pyinfo_labels", []):
            lbl.setVisible(bool(checked))

    @property
    def _mode(self):
        """Current mode as config value ('rest' or 'epochs')."""
        return self._MODE_CONFIG.get(
            self._mode_combo.currentText(), "rest")

    @staticmethod
    def _startup_msg(text):
        """Print startup progress message to console (if verbose)."""
        if _VERBOSE_LOGGING:
            print(f"  {text}", flush=True)

    def _on_verbose_log_toggled(self, checked):
        """Persist verbose-logging preference to QSettings."""
        global _VERBOSE_LOGGING
        _VERBOSE_LOGGING = bool(checked)
        self._settings().setValue("verbose_logging", _VERBOSE_LOGGING)

    def _svarog_select_mode_supported(self, mode=None):
        """Lazy-check whether the installed Svarog jar supports --select-mode.

        Result is cached per GUI session.  We parse ``java -jar
        svarog.jar --help`` once; the feature is supported iff
        ``--select-mode`` appears in the output.

        When *mode* is given (e.g. ``"bad_channels"``, ``"bad_epochs"``,
        ``"ica_components"``), additionally verify that specific mode
        value appears in the help text — older jars may have
        ``--select-mode`` but only accept a subset of mode values.
        """
        if not hasattr(self, "_svarog_select_mode_help"):
            help_text = ""
            jar = getattr(self, "_svarog_jar", None)
            if jar and os.path.isfile(jar):
                try:
                    result = subprocess.run(
                        ["java", "-jar", jar, "--help"],
                        capture_output=True, text=True, timeout=10,
                        check=False)
                    output = (result.stdout or "") + (result.stderr or "")
                    if "--select-mode" in output:
                        help_text = output
                except (subprocess.TimeoutExpired, OSError, FileNotFoundError):
                    pass
            self._svarog_select_mode_help = help_text
        if not self._svarog_select_mode_help:
            return False
        if mode is None:
            return True
        return mode in self._svarog_select_mode_help

    def _review_bad_channels(self, signal, overlay_events,
                             tags_desc_id, scalings):
        """Manual bad-channel review dispatcher: Svarog first, MNE fallback.

        If the installed Svarog jar advertises ``--select-mode`` in
        its ``--help``, launch Svarog as a subprocess with the
        current signal + the auto-detected bad channels as
        preselection.  Return the user's selection (possibly empty)
        on save, or the preselection list unchanged on cancel.

        Otherwise fall back to the existing Qt-signal flow that
        routes to ``_on_manual_bad_channels_requested`` on the main
        thread and opens MNE's interactive browser.
        """
        preselected = list(signal.info.get("bads", []))
        jar = getattr(self, "_svarog_jar", None)
        if (jar and os.path.isfile(jar)
                and self._svarog_select_mode_supported()):
            try:
                from ide4eeg.preprocessing.svarog_review import (
                    review_bad_channels_via_svarog)
                result = review_bad_channels_via_svarog(
                    signal, jar, preselected_bads=preselected)
                if result is not None:
                    return result
                # Cancel — keep the auto-detected list untouched.
                return preselected
            except Exception:
                logging.warning(
                    "Svarog bad-channel review failed, falling back "
                    "to MNE", exc_info=True)
        # MNE fallback — main-thread plot via Qt signal.
        result = {"bads": [], "error": None}
        done = threading.Event()
        self._signals.manual_bad_channels_requested.emit(
            signal, overlay_events, tags_desc_id, scalings,
            result, done)
        done.wait()
        if result["error"] is not None:
            raise result["error"]
        return result["bads"]

    def _review_ica_components(self, raw, ica):
        """Manual ICA-exclusion review dispatcher: Svarog first, MNE fallback.

        When the installed Svarog jar advertises ``ica_components``
        in its ``--select-mode`` help, launches Svarog as a
        subprocess showing component sources + pre-rendered topomap
        PNGs, seeded with ``ica.exclude`` as preselection.  Returns
        the user's final exclusion list.  On cancel keeps the
        preselected set; on subprocess failure falls back to the
        MNE viewer for this invocation only.

        Fallback path uses a Qt signal to open MNE's
        ``ica.plot_sources`` on the GUI main thread (NSWindow on
        macOS must be main-thread), identical to the pre-Svarog flow.
        """
        preselected = list(ica.exclude)
        jar = getattr(self, "_svarog_jar", None)
        if (jar and os.path.isfile(jar)
                and self._svarog_select_mode_supported("ica_components")):
            try:
                from ide4eeg.preprocessing.svarog_review import (
                    review_ica_via_svarog)

                # Route topomap rendering to the main thread — see
                # _on_ica_topomaps_requested for the rationale.
                def _main_thread_renderer(ica_obj, out_dir):
                    render_result = {"error": None}
                    render_done = threading.Event()
                    self._signals.ica_topomaps_requested.emit(
                        ica_obj, out_dir, render_result, render_done)
                    render_done.wait()
                    if render_result["error"] is not None:
                        raise render_result["error"]

                result = review_ica_via_svarog(
                    raw, ica, jar, preselected=preselected,
                    topomap_renderer=_main_thread_renderer)
                if result is not None:
                    return result
                # Cancel — keep preselection.
                return preselected
            except Exception:
                logging.warning(
                    "Svarog ICA review failed, falling back to MNE",
                    exc_info=True)
        # MNE fallback — main-thread plot via Qt signal.
        result = {"exclude": list(ica.exclude), "error": None}
        done = threading.Event()
        self._signals.manual_ica_requested.emit(raw, ica, result, done)
        done.wait()
        if result["error"] is not None:
            raise result["error"]
        return result["exclude"]

    def _manual_segment_review(self):
        """Launch a preprocessing-only run that stops at segment review.

        Forces ``check_rest`` / ``check_epochs`` on (so the hook fires
        regardless of checkbox state), disables every analysis, and
        pins the user-level config hash before the mutations so
        snapshot filenames stay consistent with a future Run.  The
        actual review dispatches to Svarog or MNE via
        ``_segments_hook`` / ``_review_bad_epochs``.
        """
        if self._polling_active:
            self._msg_info(
                "Pipeline running",
                "A pipeline is already running. Wait for it to "
                "finish, or click Stop first.")
            return
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info(
                "No input file",
                "Select an input signal on the Input tab first.")
            return
        import copy
        try:
            cfg = copy.deepcopy(self._collect_config())
        except Exception as e:
            self._msg_error("Configuration error", str(e))
            return
        # Pin user-level hashes BEFORE the force-enable / disable-
        # analyses mutations — step-snapshot filenames and the
        # viewer's staleness check both depend on these values.
        cfg["_pipeline_config_hash"] = _compute_preprocessing_hash(cfg)
        cfg["_pipeline_step_hashes"] = _compute_step_hashes(
            cfg, effective_step_order(cfg))
        mode = get_segmentation_mode(cfg)
        if mode == "rest":
            cfg.setdefault("rest", {})["check_rest"] = True
        else:
            cfg.setdefault("epochs", {})["check_epochs"] = True
        self._disable_all_analyses(cfg)
        self._launch_pipeline(cfg)

    def _review_bad_epochs(self, epochs, preselected_rejections=()):
        """Manual bad-epoch review dispatcher: Svarog first, MNE fallback.

        Replace-semantics contract (2026-05-02): caller passes the
        *original* (pre-rejection) Epochs plus the set of indices the
        pipeline already flagged for PTP rejection.  Returned set is
        the user's *final* decision in original-event indices —
        including any PTP rejections the user un-marked.

        * **Svarog path** — spawn the jar with
          ``--select-mode bad_epochs --preselect ...``, parse the
          output tag's ``<idx>`` children.  Svarog shows every cut
          epoch with the preselected ones pre-marked; the user can
          confirm/undo/add.
        * **MNE fallback** — drops the preselected indices first
          (since MNE's interactive plot has no preselect mechanism),
          plots the survivors, the user marks more, and we union the
          result back onto the preselect set.  This degrades to
          add-only semantics on the MNE path — the user can't
          un-mark a PTP rejection unless Svarog is available.

        Parameters
        ----------
        epochs : mne.Epochs
            Original pre-rejection Epochs (full set).
        preselected_rejections : iterable[int]
            Indices the pipeline (or upstream review) already flagged.
            Shown pre-marked in Svarog; pre-dropped from the MNE
            fallback view.

        Returns
        -------
        set[int]
            Final rejection indices (into ``epochs.events``).  Empty
            set on cancel / subprocess error (no rejections applied).
        """
        preselected = set(preselected_rejections or [])
        jar = getattr(self, "_svarog_jar", None)
        if (jar and os.path.isfile(jar)
                and self._svarog_select_mode_supported("bad_epochs")):
            try:
                from ide4eeg.preprocessing.svarog_review import (
                    review_bad_epochs_via_svarog)
                result = review_bad_epochs_via_svarog(
                    epochs, jar,
                    preselected_rejections=preselected)
                if result is not None:
                    return set(result)
                # Cancel — leave whatever the pipeline already flagged.
                return preselected
            except Exception:
                logging.warning(
                    "Svarog bad-epoch review failed, falling back to MNE",
                    exc_info=True)
        # MNE fallback — drop the preselect from view, plot survivors,
        # union the user's marks back on top.  The user can't un-mark
        # a PTP rejection from this path (MNE plot has no preselect),
        # so the semantics degrade to add-only here.
        viewable = epochs.copy()
        if preselected:
            viewable.drop(sorted(preselected), reason="USER")
        result = {"reject_idxs": set(), "error": None}
        done = threading.Event()
        self._signals.manual_segments_requested.emit(viewable, result, done)
        done.wait()
        if result["error"] is not None:
            raise result["error"]
        # MNE returns indices into the post-drop drop_log, which is
        # parallel to ``epochs.events`` (drop_log is preserved across
        # ``copy()``).  Just take whatever's marked — that's already
        # the union of preselect + user marks in original indices.
        final = {
            i for i in range(len(viewable.drop_log))
            if viewable.drop_log[i] != ()
        }
        return final

    def _on_allow_reorder_toggled(self, checked):
        """Show/hide up/down arrows on all preprocessing steps and the
        constraints editor on the Config tab.  Idempotent; safe to call
        before the Preprocess tab is built (the step-widget loop no-ops
        on an empty list).  Also toggles the [+] add-filter button
        on every Filters panel — Phase 2 multi-block UX."""
        for _, step_widget in getattr(self, "_step_widgets", []):
            if hasattr(step_widget, "setReorderVisible"):
                step_widget.setReorderVisible(bool(checked))
        # The [+] button is added by _build_filter_panel only on
        # Filters panels; toggle it in lockstep with the arrows.
        # [-] visibility additionally depends on panel position;
        # delegate to the dedicated helper.
        for _fid, grp in getattr(self, "_filter_widgets", []):
            plus = getattr(grp, "_plus_btn", None)
            if plus is not None:
                plus.setVisible(bool(checked))
        self._refresh_filter_minus_visibility()
        grp = getattr(self, "_constraints_group", None)
        if grp is not None:
            grp.setVisible(bool(checked))

    def _resolve_n_jobs_value(self, raw):
        """Resolve a raw n_jobs value to its effective worker count.

        0 or empty = auto (``default_n_jobs``): uses
        ``min(physical_cores - 2, available_ram_gb // 2)``, floored
        at 1 — leaves 2 cores free for the OS.
        """
        try:
            val = int(raw)
        except (TypeError, ValueError):
            val = 0
        if val <= 0:
            from ide4eeg.main import default_n_jobs
            val = default_n_jobs()
        return max(1, val)

    def _update_n_jobs_readout(self, *_):
        """Refresh the Parallel jobs primary label + warning block."""
        if not hasattr(self, "_n_jobs_primary_label"):
            return
        from ide4eeg.main import _detect_system
        phys, logical, ram_gb = _detect_system()
        raw = self._n_jobs_edit.text().strip()
        eff = self._resolve_n_jobs_value(raw)

        # Primary label next to the field.
        is_auto = not raw or raw == "0"
        auto_tag = " (auto, usually conservative)" if is_auto else ""
        if eff == 1:
            primary = f"\u2192 sequential{auto_tag}"
            self._n_jobs_primary_label.setStyleSheet("color: gray;")
        else:
            primary = f"\u2192 {eff} parallel workers{auto_tag}"
            self._n_jobs_primary_label.setStyleSheet("color: #268bd2;")
        self._n_jobs_primary_label.setText(primary)

        # Warnings. We build a list and concatenate so multiple can
        # appear at once — the user sees everything that's out of
        # range, not just the first trigger.
        warnings = []

        # CPU: half of physical cores is a soft cap (leaves room for
        # GUI, browser, and the parent process' own BLAS).
        soft_cpu_cap = max(1, phys // 2)
        if eff > logical:
            warnings.append(
                f"\u26a0 {eff} exceeds {logical} logical cores "
                f"\u2014 guaranteed contention")
        elif eff > phys:
            warnings.append(
                f"\u26a0 {eff} exceeds {phys} physical cores "
                f"\u2014 hyperthreads give at most ~30% extra, "
                f"not a second worker's worth of compute")
        elif eff > soft_cpu_cap:
            warnings.append(
                f"\u26a0 {eff} leaves fewer than {phys - eff} "
                f"physical cores for the GUI and parent process "
                f"\u2014 interface may become sluggish during runs")

        # RAM: each worker needs ~250 MB baseline (fresh Python
        # interpreter + numpy/scipy/joblib imports) plus working
        # memory. Warn when baseline alone exceeds 1/3 of total RAM.
        baseline_per_worker_gb = 0.25
        est_baseline_gb = eff * baseline_per_worker_gb
        ram_third = ram_gb / 3.0
        if est_baseline_gb > ram_gb * 0.6:
            warnings.append(
                f"\u26a0 {eff} workers \u00d7 ~250 MB baseline "
                f"\u2248 {est_baseline_gb:.1f} GB \u2014 likely to "
                f"push a {ram_gb:.0f} GB machine into swap thrashing")
        elif est_baseline_gb > ram_third:
            warnings.append(
                f"\u26a0 {eff} workers \u00d7 ~250 MB baseline "
                f"\u2248 {est_baseline_gb:.1f} GB \u2014 this is "
                f">1/3 of {ram_gb:.0f} GB total RAM, watch for swap")

        self._n_jobs_warning_label.setText("\n".join(warnings))
        self._n_jobs_warning_label.setVisible(bool(warnings))

        # System info line (always shown, informational).
        self._n_jobs_system_label.setText(
            f"System: {phys} physical / {logical} logical cores, "
            f"{ram_gb:.0f} GB RAM. Each worker \u2248 250 MB baseline "
            f"+ working memory.")

        # Keep the MP decomposition "use X cores" readout in sync —
        # it inherits its default from this field, so changing here
        # must refresh its label.
        self._update_mp_workers_readout()

    def _update_mp_workers_readout(self, *_):
        """Refresh the MP decomposition cpu_workers readout + warning.

        The MP field's text() means:
          ""  or "0"  → inherit the effective Config-tab
                         ``parallelism.n_jobs``. The placeholder on
                         the QLineEdit shows that inherited value in
                         grey italic so the user sees "the number
                         empi will use" right in the field without
                         it becoming a stored override.
          N > 0        → explicit override, use N empi worker
                         threads regardless of the Config tab
                         setting. Power-user escape hatch.

        Unlike the Config tab's joblib field this has no RAM warning:
        empi runs all workers as threads inside a single C++ process,
        so adding a worker does not spawn a new Python interpreter.
        The cost is almost entirely CPU contention.
        """
        if not hasattr(self, "_pp") or "mp_workers_readout" not in self._pp:
            return
        from ide4eeg.main import _detect_system
        phys, logical, _ram = _detect_system()

        raw = self._pp["mp_workers"].text().strip()
        try:
            val = int(raw) if raw else 0
        except (TypeError, ValueError):
            val = 0
        is_inherit = val <= 0
        if is_inherit:
            # Inherit from the Config tab's resolved n_jobs.
            if hasattr(self, "_n_jobs_edit"):
                eff = self._resolve_n_jobs_value(
                    self._n_jobs_edit.text().strip())
            else:
                eff = 1
            # Show the inherited value as the field's placeholder so
            # the user reads "N empi workers" directly in the box
            # without it becoming an override if they don't touch it.
            self._pp["mp_workers"].setPlaceholderText(str(eff))
        else:
            eff = val
            # When there's an explicit override, a stale placeholder
            # (from before the override) is fine — it's invisible while
            # the text field is non-empty. No update needed.

        # Readout label next to the field.
        if is_inherit:
            text = (f"/ {phys} physical cores  "
                    f"\u2192 inherited from parallelism.n_jobs")
        else:
            text = (f"/ {phys} physical cores  "
                    f"\u2192 {eff} (override)")
        self._pp["mp_workers_readout"].setText(text)

        # Warnings: CPU-only, analogous to parallelism.n_jobs but without
        # the RAM row (empi's shared-memory model makes RAM a non-issue).
        warnings = []
        soft_cpu_cap = max(1, phys // 2)
        if eff > logical:
            warnings.append(
                f"\u26a0 {eff} exceeds {logical} logical cores "
                f"\u2014 guaranteed thread contention inside empi")
        elif eff > phys:
            warnings.append(
                f"\u26a0 {eff} exceeds {phys} physical cores "
                f"\u2014 hyperthreads give at most ~30% extra, "
                f"past {phys} workers empi just contends for cores")
        elif eff > soft_cpu_cap:
            warnings.append(
                f"\u26a0 {eff} leaves fewer than {phys - eff} "
                f"physical cores for the GUI and parent process "
                f"\u2014 interface may become sluggish during MP runs")

        warn_label = self._pp["mp_workers_warn"]
        warn_label.setText("\n".join(warnings))
        warn_label.setVisible(bool(warnings))

    def _update_dip_workers_readout(self, *_):
        """Refresh the dipole fitting cpu_workers readout.

        Same semantics as MP workers: empty/0 = inherit from
        Config tab parallelism.n_jobs, N > 0 = explicit override.
        """
        if not hasattr(self, "_an") or "dip_workers_readout" not in self._an:
            return
        from ide4eeg.main import _detect_system
        phys, _, _ = _detect_system()

        raw = self._an["dip_workers"].text().strip()
        try:
            val = int(raw) if raw else 0
        except (TypeError, ValueError):
            val = 0
        is_inherit = val <= 0
        if is_inherit:
            if hasattr(self, "_n_jobs_edit"):
                eff = self._resolve_n_jobs_value(
                    self._n_jobs_edit.text().strip())
            else:
                eff = 1
            self._an["dip_workers"].setPlaceholderText(str(eff))
        else:
            eff = val

        if is_inherit:
            text = (f"/ {phys} physical cores  "
                    f"\u2192 inherited from parallelism.n_jobs")
        else:
            text = (f"/ {phys} physical cores  "
                    f"\u2192 {eff} (override)")
        self._an["dip_workers_readout"].setText(text)

    def __init__(self):
        super().__init__()
        self._startup_msg("loading configuration...")
        self.setWindowTitle(f"IDE4EEG {ide4eeg.__version__}")
        self.resize(680, 900) #preprocess najszerszy

        self.config_data = copy.deepcopy(DEFAULT_CONFIG)
        self.config_path = None
        self._signals = _Signals()
        self._cached_signal = None
        self._cached_events = None
        self._cached_unnamed_codes = {}
        self._pending_event_selection = None  # for config loaded before file
        # Bounded so heavy producers can't OOM on long runs.  See
        # QueueLogHandler.emit for the drop-oldest semantics.  At
        # ~500/s drain the buffer holds ~30 s of bursty output before
        # the oldest record falls off; the QTextEdit's block cap
        # (set in the log-tab builder below) provides the second
        # backstop for accumulated UI memory.
        self.log_queue = queue.Queue(maxsize=20000)
        self._polling_active = False
        self._svarog_jar = _find_svarog_jar()
        self._connectivis_jar = _find_connectivis_jar()
        self._empi_path = _find_empi(self._svarog_jar)
        self._step_fif_paths = {}   # step_name -> last saved .fif path
        self._step_widgets = []     # (step_key, CollapsibleStep) for reorder
        self._channel_panels = []   # list of SelectionPanel for signal_info
        self._book_panels = []     # list of BookChannelPanel instances

        self._pipeline_data = {}   # cached pipeline results
        self._auto_scroll = True   # log auto-scroll toggle

        # Phase 6: GUI step key whose viewer should open on the next
        # pipeline_finished signal.  Set by _run_truncated_pipeline,
        # consumed in _on_pipeline_finished.  ``_view_step_result``
        # derives single-vs-split dispatch from the step key itself
        # so no companion flag is needed.
        self._pending_view_step_key = None
        # Post-pipeline action (set by buttons that route through the
        # unified runner but want different post-completion UX than the
        # eye buttons).  Values currently in use:
        #   "open_viewer"        — reopen _view_step_result for the
        #                          step that triggered the run (eye
        #                          button default; equivalent to
        #                          having ``_pending_view_step_key``
        #                          set).
        #   "bad_channels_label" — emit BAD_CHANNELS:... log line from
        #                          the cached config so the Bad
        #                          Channels panel's body label and
        #                          header readout update.
        # ``None`` (default) — no post-action; the standard "show
        # Output tab" path runs.  Consumed-and-cleared in
        # ``_on_pipeline_finished`` regardless of success.
        self._pending_post_action = None
        # One-shot override consumed in _on_pipeline_finished's EEG-
        # Profiles branch: forces the post-run Svarog open even when
        # the panel's "Auto open results in SVAROG" checkbox is off.
        # Set by the prof_grp eye button.
        self._force_profile_svarog_open = False
        self._stage_state = {}     # sid -> "pending"|"active"|"done"
        self._stage_enabled = {}   # sid -> bool
        self._active_stage_id = None
        # Fractional progress within the currently-active MP stage
        # (0–100%, fed by _on_mp_decomp_progress).  Folded into
        # _update_overall_progress so the Run-tab bar advances
        # smoothly during MP iteration instead of fighting the
        # coarser stage-transition writes.
        self._mp_decomp_pct = 0

        # Segmentation mode combo — created here so other tabs can wire
        # their currentTextChanged handlers during their (lazy) build,
        # even though the combo is only added to a layout later, in
        # the Preprocessing tab's "Segmentation setup" panel.
        self._mode_combo = QComboBox()
        self._mode_combo.addItems(["timed windows", "event-locked"])
        self._mode_combo.setFixedWidth(130)
        self._mode_combo.setToolTip(
            "Segmentation mode for downstream analysis:\n"
            "\u2022 timed windows (rest) \u2014 split the continuous\n"
            "  signal into fixed-length non-overlapping windows.\n"
            "  Use for resting-state, sleep, long continuous\n"
            "  recordings.\n"
            "\u2022 event-locked (epochs) \u2014 extract epochs around\n"
            "  trigger events from the STIM channel. Use for\n"
            "  ERP / ERD / task paradigms.")
        _mode_cfg = get_segmentation_mode(self.config_data)
        self._mode_combo.setCurrentText(
            "event-locked" if _mode_cfg == "epochs" else "timed windows")

        # Connect signals
        self._signals.signal_info_ready.connect(self._on_signal_info_ready)
        self._signals.signal_info_error.connect(self._on_signal_info_error)
        self._signals.pipeline_finished.connect(self._on_pipeline_finished)
        self._signals.pipeline_log.connect(self._on_pipeline_log)
        self._signals.drop_selection_from_svarog.connect(
            self._apply_drop_selection)
        self._signals.step_finished.connect(self._on_step_finished)
        self._signals.mp_decomp_progress.connect(self._on_mp_decomp_progress)
        self._signals.manual_bad_channels_requested.connect(
            self._on_manual_bad_channels_requested)
        self._signals.manual_ica_requested.connect(
            self._on_manual_ica_requested)
        self._signals.ica_topomaps_requested.connect(
            self._on_ica_topomaps_requested)
        self._signals.manual_segments_requested.connect(
            self._on_manual_segments_requested)
        self._signals.java_launch_done.connect(
            self._on_java_launch_done)

        self._pipeline_cancel = threading.Event()

        # Central widget: tabs + persistent bottom bar
        central = QWidget()
        central_layout = QVBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)
        self._tabs = QTabWidget()
        self._tabs.setDocumentMode(True)
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border-top: 1px solid palette(mid); "
            "padding-top: 12px; }")
        central_layout.addWidget(self._tabs, 1)
        self.setCentralWidget(central)

        # Lazy-loading: track which tabs are built
        self._tab_built = {}

        # Build only the first tab eagerly; others on first click
        self._tab_io = QWidget()
        self._tab_config = QWidget()
        self._tab_preproc = QWidget()
        self._tab_analysis = QWidget()
        self._tab_run = QWidget()
        self._tab_output = QWidget()
        self._tab_help = QWidget()

        self._tabs.addTab(self._tab_config,   " Config ")
        self._tabs.addTab(self._tab_io,       " Input ")
        self._tabs.addTab(self._tab_preproc,  " Preprocess ")
        self._tabs.addTab(self._tab_analysis, " Analysis ")
        self._tabs.addTab(self._tab_run,      " Run ")
        self._tabs.addTab(self._tab_output,   " Output ")
        self._tabs.addTab(self._tab_help,     " Help ")

        # Init tab titles before building tabs (builders wire signals
        # that call _update_tab_indicators which reads _tab_base_titles)
        self._tab_base_titles = {
            i: self._tabs.tabText(i)
            for i in range(self._tabs.count())
        }

        self._startup_msg("building Config tab")
        self._build_config_tab()
        self._tab_built["config"] = True
        self._startup_msg("building Input tab")
        self._build_io_tab()
        self._tab_built["io"] = True
        self._startup_msg("building Preprocessing tab")
        self._build_preproc_tab()
        self._tab_built["preproc"] = True
        self._startup_msg("building Analysis tab")
        self._build_analysis_tab()
        self._tab_built["analysis"] = True
        self._startup_msg("building Run tab")
        self._build_run_tab()
        self._tab_built["run"] = True
        self._startup_msg("building Output tab")
        self._build_output_tab()
        self._tab_built["output"] = True
        self._startup_msg("loading user manual")
        self._build_help_tab()
        self._tab_built["help"] = True
        self._update_prof_epoch_hint()

        self._wire_tab_indicators()

        self._tabs.currentChanged.connect(self._on_tab_changed)

        # Floating watermark overlay (stays at bottom of tab area)
        self._watermark = QLabel(_IDE4EEG_LOGO, self._tabs)
        self._watermark.setStyleSheet(
            "color: rgba(128, 128, 128, 20); "
            "font-family: 'Courier New', Courier, monospace; "
            "font-size: 22px; font-weight: bold; "
            "background: transparent;")
        self._watermark.setAlignment(Qt.AlignLeft | Qt.AlignBottom)
        self._watermark.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._watermark.adjustSize()
        self._tabs.installEventFilter(self)

        # Status bar
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Ready")

        # Menu bar
        self._build_menu()

        # Log poll timer (active only during pipeline runs)
        self._log_timer = QTimer(self)
        self._log_timer.timeout.connect(self._poll_log_queue)

        # Keyboard shortcuts (feature 6)
        QShortcut(QKeySequence("Ctrl+L"), self, self._on_load_config)
        QShortcut(QKeySequence("Ctrl+S"), self, self._on_save_config)
        QShortcut(QKeySequence("Ctrl+R"), self, self._run_pipeline_safe)
        for i in range(7):
            QShortcut(QKeySequence(f"Ctrl+{i + 1}"), self,
                      lambda idx=i: self._tabs.setCurrentIndex(idx))

        # Start on Input tab (Config is index 0, Input is index 1)
        self._tabs.setCurrentIndex(1)

        # Auto-load config.toml if present
        default_cfg = Path.cwd() / "config.toml"
        if default_cfg.exists():
            QTimer.singleShot(100, lambda: self._load_config(str(default_cfg)))

        # Check for missing companion tools after window is shown.
        # Two staggered checks: external EEG tools first, then the
        # video stack -- so a user with neither installed sees one
        # prompt at a time, not two stacked dialogs.
        QTimer.singleShot(500, self._check_tools_on_startup)
        QTimer.singleShot(900, self._check_video_stack_onboarding)

    # ── Watermark overlay ────────────────────────────────────────────

    def eventFilter(self, obj, event):
        if obj is self._tabs and event.type() in (
                event.Type.Resize, event.Type.Show):
            self._position_watermark()
        return super().eventFilter(obj, event)

    def _position_watermark(self):
        """Keep the watermark pinned at the bottom-left of the tab area."""
        wm = self._watermark
        wm.adjustSize()
        # Offset for bottom bars outside the tab area (e.g. examples buttons)
        y = self._tabs.height() - wm.height() - 40
        wm.move(20, max(y, 10))
        wm.raise_()

    def _toggle_watermark(self, checked):
        _first4 = (self._tab_config, self._tab_io,
                    self._tab_preproc, self._tab_analysis)
        self._watermark.setVisible(
            checked and self._tabs.currentWidget() in _first4)

    # ── Menu bar ──────────────────────────────────────────────────────

    def _build_menu(self):
        menu = self.menuBar()

        file_menu = menu.addMenu("&File")
        file_menu.addAction(
            "&Load pipeline settings .toml\tCtrl+L",
            self._on_load_config)
        file_menu.addAction(
            "&Save pipeline settings .toml\tCtrl+S",
            self._on_save_config)
        file_menu.addAction(
            "&Export Python script...", self._export_script)
        file_menu.addSeparator()
        file_menu.addAction("&Reset to Defaults", self._reset_to_defaults)
        file_menu.addSeparator()
        quit_act = file_menu.addAction("&Quit")
        quit_act.setShortcut(QKeySequence("Ctrl+Q"))
        quit_act.triggered.connect(self.close)

        # ── Go menu (tab navigation) ────────────────────────────
        go_menu = menu.addMenu("&Go")
        _tab_names = [
            ("Config", 0), ("Input", 1), ("Preprocess", 2),
            ("Analysis", 3), ("Run", 4), ("Output", 5), ("Help", 6),
        ]
        for name, idx in _tab_names:
            go_menu.addAction(
                name,
                lambda i=idx: self._tabs.setCurrentIndex(i))

        # ── View menu ────────────────────────────────────────────
        view_menu = menu.addMenu("&View")
        view_menu.addAction("Collapse all sections",
                            self._collapse_all_sections)
        view_menu.addAction("Expand all sections",
                            self._expand_all_sections)
        view_menu.addSeparator()
        from PySide6.QtGui import QActionGroup
        # Restore the saved theme choice (default: system).  Persisted
        # by ``_set_theme`` to QSettings("IDE4EEG", "IDE4EEG").theme.
        saved_theme = QSettings("IDE4EEG", "IDE4EEG").value(
            "theme", "system")
        theme_group = QActionGroup(self)
        theme_group.setExclusive(True)
        for label, key in [("Light theme", "light"), ("Dark theme", "dark"),
                           ("System theme", "system")]:
            act = view_menu.addAction(label)
            act.setCheckable(True)
            act.setChecked(key == saved_theme)
            act.triggered.connect(lambda checked, k=key: self._set_theme(k))
            theme_group.addAction(act)
        if saved_theme != "system":
            # Apply the persisted override now.  "system" is the Qt
            # default — no need to touch palette/stylesheet for it.
            self._set_theme(saved_theme)
        view_menu.addSeparator()
        self._watermark_action = view_menu.addAction("IDE4EEG watermark")
        self._watermark_action.setCheckable(True)
        self._watermark_action.setChecked(True)
        self._watermark_action.toggled.connect(self._toggle_watermark)

        # ── Help menu ────────────────────────────────────────────
        help_menu = menu.addMenu("&Help")
        help_menu.addAction("&About IDE4EEG...", self._show_about)

    # ── About dialog ────────────────────────────────────────────────

    def _show_about(self):
        self._msg_info("About IDE4EEG",
            f"<h2>IDE4EEG {ide4eeg.__version__}</h2>"
            "<p>Integrated Development Environment for EEG</p>"
            "<p>License: GPL-3.0</p><p>University of Warsaw</p>")

    # ── View menu actions ────────────────────────────────────────────

    def _collapse_all_sections(self):
        """Collapse all CollapsibleGroupBox widgets in the current tab."""
        for w in self._find_collapsible_groups():
            w.collapse()

    def _expand_all_sections(self):
        """Expand all CollapsibleGroupBox widgets in the current tab."""
        for w in self._find_collapsible_groups():
            w.expand()

    def _set_theme(self, theme):
        """Switch between light, dark, and system themes.

        Updates FOUR app-wide handles in lockstep:
          1. ``app.setStyle(...)`` — Light/Dark switch to ``Fusion`` so
             theming is uniform across macOS / Windows / Linux (the
             native styles diverge: faint unchecked checkboxes on
             macOS Aqua light mode, different layout metrics, etc.).
             ``System`` restores the captured platform-default style
             so the user gets their OS-native look.
          2. ``app.setStyleSheet(...)`` — drives most widget rendering.
          3. ``app.setPalette(...)`` — what custom-painted widgets read
             via ``palette().window().color().lightness()``.  Without
             this, a Light-OS user who picks "Dark theme" would still
             have ``palette()`` reporting Light, breaking widgets like
             the trim overview that read it directly.
          4. ``QSettings("IDE4EEG", "IDE4EEG").theme`` — persists the
             choice so a fresh GUI launch restores it.
        """
        from PySide6.QtGui import QPalette
        from PySide6.QtWidgets import QStyleFactory
        app = QApplication.instance()
        # Capture the OS-supplied palette + style on first call so
        # "system" later restores them instead of whatever a previous
        # Dark/Light call overwrote them with.
        if not hasattr(self, "_system_palette"):
            self._system_palette = QPalette(app.palette())
        if not hasattr(self, "_system_style"):
            self._system_style = app.style().objectName()
        if theme == "dark":
            app.setStyle("Fusion")
            pal = QPalette()
            pal.setColor(QPalette.Window, QColor("#1e1e2e"))
            pal.setColor(QPalette.WindowText, QColor("#cdd6f4"))
            pal.setColor(QPalette.Base, QColor("#313244"))
            pal.setColor(QPalette.Text, QColor("#cdd6f4"))
            # Mid is used for separator lines (CollapsibleStep,
            # MNE section divider).  Empty QPalette() defaults
            # this to black, which is invisible on a dark
            # background — set it to the same subtle grey as the
            # stylesheet borders below.
            pal.setColor(QPalette.Mid, QColor("#45475a"))
            app.setPalette(pal)
        elif theme == "light":
            app.setStyle("Fusion")
            # Fusion-canonical light palette: Window=#efefef (panels)
            # and Base=#ffffff (input widgets, checkbox indicator
            # fill).  Fusion's checkbox border is computed as
            # ``Window.darker(140)``, so Window MUST be off-white —
            # using #ffffff produces a #b6b6b6 border against a
            # similarly-light Base fill, making the box invisible.
            # Cf. qfusionstyle.cpp:568-629 (PE_IndicatorCheckBox).
            pal = QPalette()
            pal.setColor(QPalette.Window, QColor("#efefef"))
            pal.setColor(QPalette.WindowText, QColor("#1e1e2e"))
            pal.setColor(QPalette.Base, QColor("#ffffff"))
            pal.setColor(QPalette.Text, QColor("#1e1e2e"))
            # Mid is used for separator lines (CollapsibleStep,
            # MNE section divider).  Empty QPalette() defaults
            # this to black, which is too contrasting against a
            # light panel — set it to a lighter grey than the
            # stylesheet borders (#cccccc) so separators read as
            # delicate rather than structural.
            pal.setColor(QPalette.Mid, QColor("#dddddd"))
            app.setPalette(pal)
        else:  # system — restore captured OS default style + palette
            sysstyle = QStyleFactory.create(self._system_style)
            if sysstyle is not None:
                app.setStyle(sysstyle)
            app.setPalette(self._system_palette)
            # Clear any previous Dark/Light QSS — without this, a
            # Dark→System switch would leave dark colours stuck.
            app.setStyleSheet("")
        QSettings("IDE4EEG", "IDE4EEG").setValue("theme", theme)
        if theme == "dark":
            app.setStyleSheet("""
                QWidget { background-color: #1e1e2e; color: #cdd6f4; }
                QGroupBox { border: 1px solid #45475a; margin-top: 6px; padding-top: 8px; }
                QGroupBox::title { color: #cdd6f4; }
                QLineEdit, QComboBox, QTextEdit, QTextBrowser, QSpinBox {
                    background-color: #313244; color: #cdd6f4; border: 1px solid #45475a; }
                QComboBox { padding-left: 12px; }
                QPushButton { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #3b3c50, stop:1 #2e2f42);
                    color: #cdd6f4; border: 1px solid #50526a;
                    border-radius: 4px; padding: 3px 8px; }
                QPushButton:hover { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #585a75, stop:1 #3b3c50); }
                QPushButton:pressed { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #252636, stop:1 #313244);
                    border: 1px solid #45475a; }
                QTabBar::tab { background: #313244; color: #cdd6f4;
                    padding: 6px 12px; border: 1px solid #45475a; }
                QTabBar::tab:selected { background: #45475a; }
                QProgressBar { background: #313244; border: 1px solid #45475a; }
                QProgressBar::chunk { background: #89b4fa; }
                QTreeWidget { background: #1e1e2e; color: #cdd6f4; }
                QHeaderView::section { background: #313244; color: #cdd6f4; }
                QScrollBar { background: #1e1e2e; }
            """)
        elif theme == "light":
            # No ``QWidget { background-color: ... }`` rule — that
            # universal selector forces every widget's effective
            # Window role to the same colour, breaking Fusion's
            # checkbox indicator (border becomes invisible).  The
            # palette set above already establishes the right
            # backgrounds; specific widgets that need a different
            # bg are styled by name below.
            app.setStyleSheet("""
                QGroupBox { border: 1px solid #cccccc; margin-top: 6px; padding-top: 8px; }
                QLineEdit, QComboBox, QTextEdit, QTextBrowser, QSpinBox {
                    background-color: #ffffff; color: #1e1e2e; border: 1px solid #cccccc; }
                QComboBox { padding-left: 12px; }
                QPushButton { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #fafafa, stop:1 #e8e8e8);
                    color: #1e1e2e; border: 1px solid #c0c0c0;
                    border-radius: 4px; padding: 3px 8px; }
                QPushButton:hover { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #ffffff, stop:1 #d0d0d0); }
                QPushButton:pressed { background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1, stop:0 #d8d8d8, stop:1 #e8e8e8);
                    border: 1px solid #b0b0b0; }
                QTabBar::tab { background: #f0f0f0; padding: 6px 12px; border: 1px solid #cccccc; }
                QTabBar::tab:selected { background: #ffffff; }
            """)
        else:  # system
            # Just the QComboBox padding — keep the rest native so
            # macOS / Windows / Linux render in their default style.
            app.setStyleSheet("QComboBox { padding-left: 12px; }")

    def _find_collapsible_groups(self):
        """Return all CollapsibleGroupBox and CollapsibleStep widgets in the current tab."""
        tab = self._tabs.currentWidget()
        if not tab:
            return []
        return (tab.findChildren(CollapsibleGroupBox)
                + tab.findChildren(CollapsibleStep))

    def _reset_to_defaults(self):
        """Reset all config values to DEFAULT_CONFIG."""
        if not self._msg_confirm(
                "Reset to defaults?",
                "This will discard all current pipeline settings\n"
                "(input/output paths, preprocessing steps, analyses,\n"
                "tool paths, options) and restore the factory\n"
                "defaults.\n\n"
                "Save your pipeline config first if you want to\n"
                "keep it.\n\n"
                "Continue?"):
            return
        self.config_data = copy.deepcopy(DEFAULT_CONFIG)
        self._populate_vars(self.config_data)
        # Re-run face-folder auto-discovery so reset picks up the
        # current convention (per-recording results dir) rather than
        # leaving stale paths from a previous session.  Without this,
        # `_populate_vars` clears the LineEdit but the auto-fill walk
        # — which would now prefer
        # ``<output>/IDE4EEG_OUT_<base>/preprocessing/reference_faces/``
        # — never runs again until the user reloads a config or
        # browses for an input file.
        self._auto_fill_face_dirs()
        self._update_face_counts()
        self._status.showMessage("Reset to defaults", 5000)

    def _run_pipeline_safe(self):
        """Safe wrapper for Ctrl+R shortcut."""
        self._run_pipeline()

    # ── Export Script ────────────────────────────────────────────────

    def _export_script(self):
        """Export current GUI config as a standalone Python script."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Python Script", "ide4eeg_analysis.py",
            "Python files (*.py);;All (*)")
        if not path:
            return
        try:
            from ide4eeg.api import generate_script
            cfg = self._collect_config()
            repo_path = os.path.dirname(os.path.abspath(__file__))
            script = generate_script(cfg, DEFAULT_CONFIG, repo_path)
            with open(path, "w", encoding="utf-8") as f:
                f.write(script)
            self._status.showMessage(f"Script exported: {path}", 5000)
        except Exception as e:
            self._msg_error("Error exporting script", str(e))

    # ── Lazy tab building ─────────────────────────────────────────────

    # ── Tab activity indicators ────────────────────────────────────

    _TAB_BULLET = " \u2022"  # bullet character appended to tab title

    def _wire_tab_indicators(self):
        """Connect checkbox signals to tab title updates."""
        # Preprocessing: any checkable step toggled
        for key in ("_trim_grp", "_sel_grp", "_bad_grp", "_mont_grp",
                     "_filt_grp", "_ica_grp", "_art_grp", "_mp_grp",
                     "_mpf_grp", "_gaze_grp", "_seg_grp"):
            grp = self._pp.get(key)
            if grp and hasattr(grp, "_checkbox") and grp._checkbox:
                grp._checkbox.stateChanged.connect(
                    self._update_tab_indicators)
        # Analysis: any checkable step toggled
        for key in ("_conn_grp", "_dip_grp",
                     "_prof_grp"):
            grp = self._an.get(key)
            if grp and hasattr(grp, "_checkbox") and grp._checkbox:
                grp._checkbox.stateChanged.connect(
                    self._update_tab_indicators)
        # External analyses: any checkbox toggled (in Analysis tab)
        for cb in getattr(self, "_mne_checks", {}).values():
            cb.stateChanged.connect(self._update_tab_indicators)

    def _update_tab_indicators(self, _=None):
        """Update tab titles: append bullet when tab has active content."""
        tabs = self._tabs
        base = self._tab_base_titles

        for i in range(tabs.count()):
            active = False
            w = tabs.widget(i)

            if w is self._tab_io:
                # Active when an input file is loaded
                active = bool(getattr(self, "_input_edit", None)
                              and self._input_edit.text().strip())

            elif w is self._tab_preproc:
                # Active when any preprocessing step is checked
                for key in ("_trim_grp", "_sel_grp", "_bad_grp",
                             "_mont_grp", "_filt_grp", "_ica_grp",
                             "_art_grp", "_mp_grp", "_mpf_grp",
                             "_gaze_grp", "_seg_grp"):
                    grp = self._pp.get(key)
                    if grp and grp.isChecked():
                        active = True
                        break

            elif w is self._tab_analysis:
                for key in ("_conn_grp",
                             "_dip_grp", "_prof_grp"):
                    grp = self._an.get(key)
                    if grp and grp.isChecked():
                        active = True
                        break

            elif w is self._tab_output:
                tree = getattr(self, "_output_tree", None)
                active = tree is not None and tree.topLevelItemCount() > 0

            else:
                continue  # no indicator for Config, Run, Help

            title = base.get(i, tabs.tabText(i))
            if active:
                if not title.endswith(self._TAB_BULLET):
                    tabs.setTabText(i, title + self._TAB_BULLET)
            else:
                if title.endswith(self._TAB_BULLET):
                    tabs.setTabText(
                        i, title[:-len(self._TAB_BULLET)])
                else:
                    tabs.setTabText(i, title)

    def _on_tab_changed(self, index):
        tab = self._tabs.widget(index)
        tab_map = {
            self._tab_config:   ("config",   self._build_config_tab),
            self._tab_preproc:  ("preproc",  self._build_preproc_tab),
            self._tab_analysis: ("analysis", self._build_analysis_tab),
            self._tab_run:      ("run",      self._build_run_tab),
            self._tab_output:   ("output",   self._build_output_tab),
            self._tab_help:     ("help",     self._build_help_tab),
        }
        if tab in tab_map:
            key, builder = tab_map[tab]
            if key not in self._tab_built:
                builder()
                self._tab_built[key] = True
        # Refresh the video stack section when the user lands on
        # Config — picks up packages installed in another terminal
        # since the GUI started.  Call order: per-row refreshers
        # first (each updates its own widgets), then the section-
        # level [Install all video tools] button which depends on
        # all three states.
        if tab is self._tab_config:
            if hasattr(self, "_video_stack_rows"):
                self._refresh_video_stack_panel()
            if hasattr(self, "_mpv_status_label"):
                self._refresh_mpv_status()
            if hasattr(self, "_dl_l2cs_btn"):
                self._refresh_l2cs_button()
            if hasattr(self, "_video_install_all_btn"):
                self._refresh_video_install_all_btn()
        # Watermark only on the first four tabs
        _first4 = (self._tab_config, self._tab_io,
                    self._tab_preproc, self._tab_analysis)
        self._watermark.setVisible(
            tab in _first4 and self._watermark_action.isChecked())

    # ── Tab 1: Input ────────────────────────────────────────────────

    def _build_io_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content = QWidget()
        layout = QVBoxLayout(content)
        scroll.setWidget(content)
        tab_layout = QVBoxLayout(self._tab_io)
        tab_layout.setContentsMargins(0, 0, 0, 0)
        tab_layout.setSpacing(0)
        tab_layout.addWidget(scroll)

        # --- Paths group ---
        paths = QGroupBox("Paths")
        gl = QGridLayout(paths)
        gl.setColumnStretch(1, 1)
        self._input_edit = self._path_row(
            gl, 0, "Input signal", "input_path",
            self.config_data.get("input_path", ""),
            self._browse_input, label_as_button=True)
        # View row: "View in: [SVAROG] [MNE]   ...stretch...   [Recent files]"
        # The "View in:" label + SVAROG + MNE buttons live in their
        # own inner container (``view_btns``) so ``_toggle_recent_list``
        # can hide them as a group while leaving the Recent-files
        # button clickable (the user needs it to close the list).
        view_row = QWidget()
        view_row_l = QHBoxLayout(view_row)
        view_row_l.setContentsMargins(0, 0, 0, 0); view_row_l.setSpacing(6)
        view_btns = QWidget()
        view_btns_l = QHBoxLayout(view_btns)
        view_btns_l.setContentsMargins(0, 0, 0, 0)
        view_btns_l.setSpacing(6)
        view_btns_l.addWidget(QLabel("View in:"))
        self._view_svarog_btn = QPushButton("SVAROG")
        self._view_svarog_btn.setToolTip("Open the input signal in SVAROG")
        self._view_svarog_btn.clicked.connect(self._view_input_signal_svarog)
        self._view_mne_btn = QPushButton("MNE")
        self._view_mne_btn.setToolTip("Open the input signal in MNE interactive plot")
        self._view_mne_btn.clicked.connect(self._view_input_signal_mne)
        self._view_svarog_btn.setEnabled(False)
        self._view_mne_btn.setEnabled(False)
        self._input_edit.textChanged.connect(self._update_view_input_btns)
        view_btns_l.addWidget(self._view_svarog_btn)
        view_btns_l.addWidget(self._view_mne_btn)
        view_row_l.addWidget(view_btns)
        view_row_l.addStretch()
        self._recent_btn = QPushButton("Recent files")
        self._recent_btn.setToolTip("Show recently opened signal files")
        self._recent_btn.clicked.connect(self._toggle_recent_list)
        view_row_l.addWidget(self._recent_btn)
        self._clear_recent_btn = QPushButton("Clear")
        self._clear_recent_btn.setFixedWidth(55)
        self._clear_recent_btn.setToolTip("Clear the recent files list")
        self._clear_recent_btn.clicked.connect(self._clear_recent)
        view_row_l.addWidget(self._clear_recent_btn)
        gl.addWidget(view_row, 1, 0, 1, 2)
        # Hide/show the whole viewer-buttons group (label + both
        # buttons) as a unit when the Recent list is toggled.
        self._view_btn_ref = view_btns
        # Recent list (hidden, appears below button row)
        self._recent_list = QListWidget()
        self._recent_list.setToolTip("Click to load a recent file")
        self._recent_list.itemClicked.connect(self._on_recent_clicked)
        self._recent_list.hide()
        gl.addWidget(self._recent_list, 2, 0, 1, 2)
        self._populate_recent_list()
        self._video_edit = self._path_row(
            gl, 3, "Video (optional)", "video_path",
            self.config_data.get("video_path", ""),
            self._browse_video, label_as_button=True)
        self._output_edit = self._path_row(
            gl, 4, "Output root", "output_path",
            self.config_data.get("output_path", ""),
            self._browse_output, label_as_button=True)
        self._preproc_edit = self._path_row(
            gl, 5, "Preprocessing output:", "preprocessing_output_path",
            self.config_data.get("preprocessing_output_path", ""))
        self._analysis_edit = self._path_row(
            gl, 6, "Analysis output:", "analysis_output_path",
            self.config_data.get("analysis_output_path", ""))
        # Equalize all column-0 button widths in the Paths grid
        _col0_btns = [gl.itemAtPosition(r, 0).widget()
                      for r in range(gl.rowCount())
                      if gl.itemAtPosition(r, 0)
                      and isinstance(gl.itemAtPosition(r, 0).widget(),
                                     QPushButton)]
        _col0_btns.append(self._recent_btn)
        _btn_w = max(b.sizeHint().width() for b in _col0_btns)
        for b in _col0_btns:
            b.setFixedWidth(_btn_w)
        layout.addWidget(paths)

        # --- Signal Info group ---
        sig_group = QGroupBox("Signal Info")
        sig_layout = QVBoxLayout(sig_group)
        self._sig_info_label = QLabel("No signal loaded.")
        self._sig_info_label.setWordWrap(True)
        sig_layout.addWidget(self._sig_info_label)
        self._sig_channels_label = QLabel("")
        self._sig_channels_label.setWordWrap(True)
        sig_layout.addWidget(self._sig_channels_label)
        # Collapsible "Review channel types" section. Contains an
        # embedded SelectionPanel (type_editable=True) showing every
        # channel in the loaded signal, with right-click menus for
        # changing the MNE type. Collapsed by default; expand to
        # review or edit. Stays hidden until a signal is loaded.
        self._ch_type_review_group = CollapsibleGroupBox(
            title="Review channel types",
            checkable=False, collapsed=True)
        self._ch_type_review_group.setVisible(False)
        self._ch_type_review_panel = SelectionPanel(
            title="Channels",
            eeg_filter=True,
            type_editable=True,
        )
        self._ch_type_review_panel.channel_type_override_requested.connect(
            self._set_channel_type_override)
        _info = QLabel(
            "<i>Right-click a channel to change its MNE type. "
            "Changes apply immediately to every channel panel and to "
            "the per-type filter buttons. Pick <b>auto</b> to remove "
            "an override and restore the automatically inferred type. "
            "Overrides persist in the config under "
            "<code>[choosing_channels.type_overrides]</code>.</i>")
        _info.setWordWrap(True)
        _review_layout = self._ch_type_review_group.contentWidget().layout()
        if _review_layout is None:
            _review_layout = QVBoxLayout(
                self._ch_type_review_group.contentWidget())
            _review_layout.setContentsMargins(6, 4, 6, 6)
            _review_layout.setSpacing(4)
        _review_layout.addWidget(_info)
        _review_layout.addWidget(self._ch_type_review_panel)
        sig_layout.addWidget(self._ch_type_review_group)
        self._sig_events_label = QLabel("")
        self._sig_events_label.setWordWrap(True)
        sig_layout.addWidget(self._sig_events_label)
        self._sig_events_detail = QTextEdit()
        self._sig_events_detail.setReadOnly(True)
        self._sig_events_detail.setMaximumHeight(120)
        self._sig_events_detail.hide()
        sig_layout.addWidget(self._sig_events_detail)
        self._sig_events_toggle = QPushButton("Show event details")
        self._sig_events_toggle.setFixedWidth(150)
        self._sig_events_toggle.hide()
        self._sig_events_toggle.clicked.connect(self._toggle_event_details)
        sig_layout.addWidget(self._sig_events_toggle)
        self._sig_progress = QProgressBar()
        self._sig_progress.setRange(0, 0)
        self._sig_progress.hide()
        sig_layout.addWidget(self._sig_progress)
        layout.addWidget(sig_group)

        # --- Examples body (inside scroll) ---
        self._ex_body = QWidget()
        self._ex_body_lay = QVBoxLayout(self._ex_body)
        self._ex_body_lay.setContentsMargins(0, 30, 0, 0)
        self._ex_body_lay.setSpacing(12)
        self._ex_body.hide()
        layout.addWidget(self._ex_body)

        layout.addStretch()

        # --- Examples buttons (pinned below scroll area) ---
        self._build_examples_buttons(tab_layout)

        # Auto-trigger on input path change (Enter or focus-out)
        self._input_edit.editingFinished.connect(self._on_input_path_changed)

        # Trigger signal reading if input path is set
        inp = self.config_data.get("input_path", "")
        if inp and os.path.isfile(inp):
            self._read_signal_info(inp)

    # ── Tab 2: Config ────────────────────────────────────────────────

    def _build_config_tab(self):
        layout = QVBoxLayout(self._tab_config)

        # --- Tool Paths group ---
        # Each helper-app row is two stacked rows: a header with the
        # title and two action buttons (browse for a local file,
        # download the latest from GitLab CI), then a full-width path
        # edit below.  The L2CS-Net eye-gaze backend gets its own
        # button at the bottom — different concern (Python packages
        # via pip, not GitLab artifacts).
        tools_group = QGroupBox("Tool Paths")
        tools_lay = QVBoxLayout(tools_group)

        # ===== EEG tools subsection =====
        eeg_header = QLabel("<b>EEG tools</b>")
        eeg_header.setStyleSheet("QLabel { padding-top: 2px; }")
        tools_lay.addWidget(eeg_header)
        self._svarog_edit = self._tool_path_block(
            tools_lay,
            title="SVAROG",
            tooltip_key="svarog_jar",
            current_value=self._svarog_jar or "",
            browse_fn=self._browse_svarog_jar,
            download_fn=self._download_svarog_only,
        )
        self._connectivis_edit = self._tool_path_block(
            tools_lay,
            title="3D view",
            tooltip_key="connectivis_jar",
            current_value=self._connectivis_jar or "",
            browse_fn=self._browse_connectivis_jar,
            download_fn=self._download_connectivis_only,
        )
        self._empi_edit = self._tool_path_block(
            tools_lay,
            title="empi",
            tooltip_key="empi_path",
            current_value=self._empi_path or "",
            browse_fn=self._browse_empi,
            download_fn=self._download_empi_only,
        )

        # ===== Video stack subsection =====
        # mpv + the Python core packages + L2CS-Net.  All three
        # are needed for the facetag pipeline (face detection +
        # eye-gaze tracking + EEG-synchronised video review).
        # Video makes sense only when the whole stack works, so
        # the section has its own [Install all video tools]
        # bulk-install action plus per-row install actions for
        # users who want to manage a single component.
        self._build_video_stack_section(tools_lay)
        # Tool Paths is added to the parent layout further down —
        # after Options — so the Config tab reads top-down as
        # Parallelism → Options → Tool Paths → Constraints editor.
        # Construction stays here so the rest of `__init__` can
        # rely on ``self._svarog_edit`` etc. existing.

        # --- Parallelism group ---
        par_group = QGroupBox("Parallelism")
        par_lay = QVBoxLayout(par_group)

        n_jobs_row = QHBoxLayout()
        _nj_label = QLabel("Parallel jobs:")
        n_jobs_row.addWidget(_nj_label)
        self._n_jobs_edit = QLineEdit()
        self._n_jobs_edit.setFixedWidth(48)
        self._n_jobs_edit.setToolTip(
            FIELD_TOOLTIPS.get("parallelism.n_jobs", ""))
        _cfg_n = self.config_data.get("parallelism", {}).get("n_jobs", 0)
        self._n_jobs_edit.setText(
            str(self._resolve_n_jobs_value(_cfg_n)))
        n_jobs_row.addWidget(self._n_jobs_edit)
        self._n_jobs_primary_label = QLabel("")
        n_jobs_row.addWidget(self._n_jobs_primary_label)
        n_jobs_row.addStretch()
        par_lay.addLayout(n_jobs_row)

        self._n_jobs_system_label = QLabel("")
        self._n_jobs_system_label.setStyleSheet("color: gray;")
        self._n_jobs_system_label.setWordWrap(True)
        par_lay.addWidget(self._n_jobs_system_label)

        self._n_jobs_warning_label = QLabel("")
        self._n_jobs_warning_label.setStyleSheet(_WARN_LABEL_QSS)
        self._n_jobs_warning_label.setWordWrap(True)
        self._n_jobs_warning_label.setVisible(False)
        par_lay.addWidget(self._n_jobs_warning_label)

        self._n_jobs_edit.textChanged.connect(self._update_n_jobs_readout)
        self._update_n_jobs_readout()
        layout.addWidget(par_group)

        # --- Options group ---
        opt_group = QGroupBox("Options")
        opt_lay = QVBoxLayout(opt_group)
        self._overwrite_check = QCheckBox("Overwrite output")
        self._overwrite_check.setToolTip(
            FIELD_TOOLTIPS.get("overwrite_output", ""))
        self._overwrite_check.setChecked(
            self.config_data.get("overwrite_output", False))
        opt_lay.addWidget(self._overwrite_check)
        self._verbose_log_check = QCheckBox("Verbose console logging")
        self._verbose_log_check.setToolTip(
            "When checked, IDE4EEG prints startup progress messages\n"
            "and the SVAROG launch command to the terminal.\n"
            "When unchecked, only errors and warnings are printed.")
        self._verbose_log_check.setChecked(_VERBOSE_LOGGING)
        self._verbose_log_check.toggled.connect(self._on_verbose_log_toggled)
        opt_lay.addWidget(self._verbose_log_check)
        # Reveal per-step reorder arrows + the constraints editor.  Off
        # by default: the standard pipeline order is correct for most
        # workflows, so hiding the controls keeps the Preprocess tab
        # uncluttered for typical users.
        self._allow_reorder_check = QCheckBox(
            "Allow changing the order of preprocessing steps and adding new filters")
        self._allow_reorder_check.setToolTip(
            "When checked, each preprocessing step shows ↑/↓ arrows\n"
            "for reordering, and the constraints editor below becomes\n"
            "visible.  Off by default — the standard pipeline order\n"
            "is correct for most workflows.")
        self._allow_reorder_check.setChecked(
            self.config_data.get("preprocessing", {}).get(
                "allow_reorder", False))
        self._allow_reorder_check.toggled.connect(
            self._on_allow_reorder_toggled)
        opt_lay.addWidget(self._allow_reorder_check)
        self._use_mne_viewer_check = QCheckBox(
            "Use MNE viewer instead of Svarog")
        self._use_mne_viewer_check.setToolTip(
            "When checked, signal viewers (the eye 👁 button on\n"
            "preprocessing steps and the Output tab double-click)\n"
            "open files in MNE windows instead of Svarog.\n\n"
            "Off by default — Svarog is preferred when its jar is\n"
            "installed because it streams long recordings lazily and\n"
            "supports synchronised before/after split view.  Tick\n"
            "this if you don't have Svarog installed, or if you\n"
            "prefer MNE's interactive plot.\n\n"
            "Independent of the explicit \"Open in MNE\" / \"Open\n"
            "in Svarog\" buttons on the Input tab.")
        self._use_mne_viewer_check.setChecked(
            self.config_data.get("use_mne_viewer", False))
        opt_lay.addWidget(self._use_mne_viewer_check)
        self._show_pyinfo_check = QCheckBox(
            "Display functions and config names in panels")
        self._show_pyinfo_check.setToolTip(
            "Show a small gray row at the top of each preprocessing\n"
            "panel listing the actual Python function it calls and\n"
            "the TOML config sections it reads.\n\n"
            "Useful for debugging, scripting, and matching the GUI\n"
            "step to its CLI equivalent.  Off by default; affects\n"
            "every Preprocessing-tab panel.")
        self._show_pyinfo_check.setChecked(
            self.config_data.get("show_pyinfo", False))
        self._show_pyinfo_check.toggled.connect(
            self._on_show_pyinfo_toggled)
        opt_lay.addWidget(self._show_pyinfo_check)
        layout.addWidget(opt_group)

        # Tool Paths sits below Options (constructed earlier; just
        # being placed in visual order here).
        layout.addWidget(tools_group)

        # --- Constraints editor ---
        self._build_constraints_section(layout)
        # Apply initial visibility (Preprocess tab may not yet be built;
        # the step-widget loop is a no-op in that case — the Preprocess
        # tab builder re-applies this state once the steps exist).
        self._on_allow_reorder_toggled(
            self._allow_reorder_check.isChecked())

        # --- Config buttons ---
        _cfg_btn_tips = {
            "Load pipeline settings .toml":
                "Load pipeline settings from a TOML file (Ctrl+L)",
            "Save pipeline settings .toml":
                "Save current pipeline settings to a TOML file "
                "(Ctrl+S)",
            "Export Python script...":
                "Export a standalone Python script reproducing the "
                "current pipeline",
            "Reset Defaults": "Reset all settings to factory defaults",
        }
        layout.addStretch()

        cfg_btns = QHBoxLayout()
        for label, fn in [
            ("Load pipeline settings .toml", self._on_load_config),
            ("Save pipeline settings .toml", self._on_save_config),
            ("Export Python script...", self._export_script),
            ("Reset Defaults", self._reset_to_defaults),
        ]:
            b = QPushButton(label)
            b.setToolTip(_cfg_btn_tips.get(label, ""))
            b.clicked.connect(fn)
            cfg_btns.addWidget(b)
        cfg_btns.addStretch()
        layout.addLayout(cfg_btns)

    def _path_row(self, grid, row, label_text, key, value, browse_fn=None,
                  label_as_button=False):
        """Add a label + line edit + optional Browse button to a grid."""
        tip = FIELD_TOOLTIPS.get(key, "")
        if label_as_button and browse_fn:
            lbl = QPushButton(label_text)
            lbl.setToolTip(tip)
            lbl.clicked.connect(browse_fn)
            grid.addWidget(lbl, row, 0)
        else:
            grid.addWidget(QLabel(label_text), row, 0)
        edit = QLineEdit(value)
        edit.setToolTip(tip)
        grid.addWidget(edit, row, 1)
        if browse_fn and not label_as_button:
            btn = QPushButton("Browse...")
            btn.clicked.connect(browse_fn)
            grid.addWidget(btn, row, 2)
        return edit

    def _tool_path_block(self, parent_layout, *, title, tooltip_key,
                         current_value, browse_fn, download_fn):
        """Single-line tool row: title + inline path + Local path +
        Download recent.

        Returns a :class:`_ToolPathLabel`, a QLabel subclass that
        mirrors the QLineEdit ``.text()`` / ``.setText()`` interface
        used throughout the rest of the codebase — it stores the
        raw path string and renders a ✓/✗ marker based on whether
        the file currently exists on disk.

        For configurable EEG tools (Svarog / 3D view / empi) the
        ``[Local path]`` button still opens a file picker so users
        can point at a custom build; that's the only loss vs the
        old typed-path QLineEdit (typing a path is no longer
        possible from the GUI; users can edit the TOML directly
        if they need to script that).
        """
        tip = FIELD_TOOLTIPS.get(tooltip_key, "")
        row = QHBoxLayout()
        title_label = QLabel(f"<b>{title}</b>")
        title_label.setToolTip(tip)
        row.addWidget(title_label)
        edit = _ToolPathLabel()
        edit.setToolTip(tip)
        edit.setText(current_value)
        row.addWidget(edit, 1)
        browse_btn = QPushButton("Local path")
        browse_btn.setToolTip(
            f"Pick an existing {title} binary on disk")
        browse_btn.clicked.connect(browse_fn)
        row.addWidget(browse_btn)
        dl_btn = QPushButton("Download recent")
        dl_btn.setToolTip(
            f"Download the latest {title} from GitLab CI")
        dl_btn.clicked.connect(download_fn)
        row.addWidget(dl_btn)
        parent_layout.addLayout(row)
        return edit

    # ── Browse handlers ──────────────────────────────────────────────

    def _auto_fill_output_paths(self, input_path):
        """Derive output paths from *input_path* if output fields are empty."""
        if not input_path or not os.path.isfile(input_path):
            return
        if not self._output_edit.text().strip():
            parent = os.path.dirname(os.path.abspath(input_path))
            self._output_edit.setText(parent)
        # Strip dots from basename for clean output folder names
        base = os.path.splitext(os.path.basename(input_path))[0]
        base = base.replace(".", "")
        out_root = os.path.join(self._output_edit.text().strip(),
                                f"{OUTPUT_DIR_PREFIX}{base}")
        if not self._preproc_edit.text().strip():
            self._preproc_edit.setText(
                os.path.join(out_root, "preprocessing"))
        if not self._analysis_edit.text().strip():
            self._analysis_edit.setText(
                os.path.join(out_root, "analysis"))
        # Keep config_data in sync with UI
        self.config_data["output_path"] = self._output_edit.text()
        self.config_data["preprocessing_output_path"] = self._preproc_edit.text()
        self.config_data["analysis_output_path"] = self._analysis_edit.text()

    @staticmethod
    def _find_video_for_input(input_path):
        """Find a video file matching the signal file stem."""
        if not input_path:
            return None
        if os.path.isdir(input_path):
            for f in os.listdir(input_path):
                if os.path.splitext(f)[1].lower() in SIGNAL_EXTENSIONS:
                    input_path = os.path.join(input_path, f)
                    break
            else:
                return None
        stem = os.path.splitext(input_path)[0]
        parent = os.path.dirname(input_path)
        base_stem = os.path.splitext(os.path.basename(input_path))[0]
        for ext in (".mp4", ".mkv", ".avi", ".mov", ".wmv"):
            candidate = stem + ext
            if os.path.exists(candidate):
                return candidate
            if "." in base_stem:
                short_stem = base_stem.split(".")[0]
                candidate = os.path.join(parent, short_stem + ext)
                if os.path.exists(candidate):
                    return candidate
        return None

    def _reset_per_file_state(self):
        """Clear GUI state bound to a specific file's contents.

        Called from both ``_browse_input`` and
        ``_on_input_path_changed`` whenever the input file changes.
        Resets:

        - ``trim_start`` / ``trim_end`` edits — stale values from a
          different recording would silently chop the new file's data.
        - The Bad Channels result label — old-file channel names
          would mislead the user about the new file.
        - ``config_data["choosing_channels"]["bad_channels"]`` — the
          persistent name list; the pipeline silently filters
          non-matching names but ``bad_mode = "both" | "manual"``
          would still apply leftover names on the next Run.

        Channel-name-bound state that's safe to leave alone:
        ``type_overrides`` (intentionally cross-file), the channel
        panels themselves (repopulated on signal load), and
        ``signal.info["bads"]`` (lives on the cached signal, which is
        dropped at the top of ``_read_signal_info``).
        """
        pp = getattr(self, "_pp", {})
        # Trim edits
        if "trim_start" in pp:
            pp["trim_start"].setText("0.0")
        if "trim_end" in pp:
            pp["trim_end"].setText("")
        # Bad-channels result label (panel body + header mirror)
        if "bad_result" in pp:
            pp["bad_result"].setText("")
            pp["bad_result"].setStyleSheet("")
        if "bad_header_info" in pp:
            pp["bad_header_info"].setText("")
            pp["bad_header_info"].setStyleSheet("")
        # Persistent bad-channels name list
        cc = self.config_data.setdefault("choosing_channels", {})
        if cc.get("bad_channels"):
            cc["bad_channels"] = []

    def _browse_input(self):
        glob_filter = " ".join(f"*{ext}" for ext in SIGNAL_EXTENSIONS)
        path, _ = QFileDialog.getOpenFileName(
            self, "Select input signal",
            os.path.dirname(self._input_edit.text()),
            f"EEG files ({glob_filter});;All (*)")
        if path:
            self._input_edit.setText(path)
            self.config_data["input_path"] = path  # keep in sync
            # Auto-fill video path (clear if no companion found)
            video = self._find_video_for_input(path)
            self._video_edit.setText(video or "")
            self.config_data["video_path"] = video or ""
            # Force-fill output paths
            self._output_edit.clear()
            self._preproc_edit.clear()
            self._analysis_edit.clear()
            self._auto_fill_output_paths(path)
            self._clear_face_dirs()
            self._auto_fill_face_dirs()
            self._update_face_counts()
            self._reset_per_file_state()
            self._read_signal_info(path)

    def _on_input_path_changed(self):
        """Triggered when user finishes editing the input path field."""
        path = self._input_edit.text().strip()
        if not path or not os.path.exists(path):
            return
        self.config_data["input_path"] = path  # keep in sync
        self._mp_books_cache_time = 0  # invalidate book cache on file change
        # Auto-detect companion video (clear if none found)
        video = self._find_video_for_input(path)
        self._video_edit.setText(video or "")
        self.config_data["video_path"] = video or ""
        # Clear output paths so they're re-derived from the new input
        self._output_edit.clear()
        self._preproc_edit.clear()
        self._analysis_edit.clear()
        self._auto_fill_output_paths(path)
        # Re-discover face directories for the new input
        self._clear_face_dirs()
        self._auto_fill_face_dirs()
        self._update_face_counts()
        self._reset_per_file_state()
        # Load signal info
        if os.path.isfile(path):
            self._read_signal_info(path)

    def _clear_face_dirs(self):
        """Reset reference/exclude face-dir edits so auto-fill can repopulate."""
        pp = getattr(self, "_pp", {})
        for key in ("ref_dir", "excl_dir"):
            edit = pp.get(key)
            if edit is not None:
                edit.clear()

    def _auto_fill_face_dirs(self):
        """Look for previously saved reference/exclude face directories.

        The canonical save location is
        ``<output>/IDE4EEG_OUT_<base>/preprocessing/reference_faces/``
        (and ``.../exclude_faces/``) — that's what the **Reference
        faces** picker writes to and what this walk searches.  Users
        with photos at the pre-2026-05-02 ``<video_dir>/reference_faces/``
        location need to ``mv`` them under the per-recording results
        dir or repoint via the **Change folder** button; the legacy
        fallback was removed in c3f6438+ so the GUI never advertises
        the old location automatically.
        """
        pp = getattr(self, "_pp", {})
        if not pp:
            return
        # Candidates: per-recording IDE4EEG_OUT_*/preprocessing/ paths
        # ONLY.  Bare parent dirs (e.g. the user's [output_path]
        # pointing at ``~/CLAUDE/data/gaze/`` instead of a specific
        # ``IDE4EEG_OUT_*`` subdir) are deliberately excluded — that
        # would re-introduce the legacy video-dir fallback through
        # the back door (a parent's ``reference_faces/`` is the same
        # directory as ``<video_dir>/reference_faces/``).
        candidates = []

        def _is_per_recording(path):
            """True iff *path* sits inside an ``IDE4EEG_OUT_*`` dir.
            That's the only shape we trust for face-folder discovery
            after the 2026-05-02 layout switch."""
            return f"{os.sep}{OUTPUT_DIR_PREFIX}" in os.sep + path

        # 1. The fallback preprocessing path — derived from the input
        # file when [preprocessing_output_path] is unset.  By
        # construction this always lives inside IDE4EEG_OUT_*.
        preproc = self._fallback_preproc_path()
        if preproc and _is_per_recording(preproc):
            candidates.append(preproc)

        # 2. The user's explicit Config-tab paths IF they're already
        # under an IDE4EEG_OUT_* dir (rejected otherwise — bare parent
        # dirs would let the walk find legacy photos sitting next to
        # the video).
        for edit in [self._preproc_edit, self._output_edit]:
            p = edit.text().strip()
            if (p and _is_per_recording(p)
                    and p not in candidates):
                candidates.append(p)

        # 3. IDE4EEG_OUT_* subdirectories of every plausible parent
        # dir (input directory, configured output paths) — needed so
        # users with multiple recordings sharing one parent get all
        # their per-recording results dirs in scope.
        parent_seeds = []
        inp = self._input_edit.text().strip()
        if inp:
            parent_seeds.append(
                os.path.dirname(inp) if os.path.isfile(inp) else inp)
        for edit in [self._preproc_edit, self._output_edit]:
            p = edit.text().strip()
            if p and not _is_per_recording(p):
                parent_seeds.append(p)
        for base in parent_seeds:
            if not os.path.isdir(base):
                continue
            for entry in os.listdir(base):
                if not entry.startswith(OUTPUT_DIR_PREFIX):
                    continue
                full = os.path.join(base, entry)
                pp_sub = os.path.join(full, "preprocessing")
                if (os.path.isdir(pp_sub)
                        and pp_sub not in candidates):
                    candidates.append(pp_sub)

        ref_edit = pp.get("ref_dir")
        excl_edit = pp.get("excl_dir")
        if ref_edit and not ref_edit.text().strip():
            for base in candidates:
                d = os.path.join(base, _REFERENCE_FACES_DIRNAME)
                if os.path.isdir(d) and os.listdir(d):
                    ref_edit.setText(d)
                    break
        if excl_edit and not excl_edit.text().strip():
            for base in candidates:
                d = os.path.join(base, _EXCLUDE_FACES_DIRNAME)
                if os.path.isdir(d) and os.listdir(d):
                    excl_edit.setText(d)
                    break

    def _browse_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select video file",
            os.path.dirname(self._video_edit.text()),
            "Video files (*.mp4 *.avi *.mkv *.mov);;All (*)")
        if path:
            self._video_edit.setText(path)

    def _browse_output(self):
        path = QFileDialog.getExistingDirectory(
            self, "Select output directory",
            self._output_edit.text())
        if path:
            self._output_edit.setText(path)

    def _browse_dir(self, edit_widget, title="Select directory"):
        """Browse for a directory and set the result in *edit_widget*."""
        path = QFileDialog.getExistingDirectory(
            self, title, edit_widget.text())
        if path:
            edit_widget.setText(path)

    def _browse_svarog_jar(self):
        path, _ = QFileDialog.getOpenFileName(self, "Locate SVAROG JAR", "", "JAR files (*.jar);;All (*)")
        if path:
            self._svarog_edit.setText(path); self._svarog_jar = path
            empi = _find_empi(path)
            if empi: self._empi_edit.setText(empi); self._empi_path = empi

    def _browse_connectivis_jar(self):
        path, _ = QFileDialog.getOpenFileName(self, "Locate connectivis JAR", "", "JAR files (*.jar);;All (*)")
        if path: self._connectivis_edit.setText(path); self._connectivis_jar = path

    def _browse_empi(self):
        path, _ = QFileDialog.getOpenFileName(self, "Locate EMPI binary", "", "All (*)")
        if path: self._empi_edit.setText(path); self._empi_path = path

    # ── Tool download handlers ───────────────────────────────────────

    def _java_preflight(self, plan):
        """Run the platform-appropriate Java consent / install-hint
        dialog and return a consent thunk for the worker.

        Returns ``() -> True`` (always-True lambda) when the user
        agreed to auto-install on macOS+brew or Windows+winget;
        ``None`` otherwise (already installed, manual install, or
        user declined). The thunk shape matches
        :func:`download_tools.install_java`'s ``confirm_callback``.
        """
        plan_name, detail = plan
        if plan_name == "ok":
            return None
        if plan_name == "auto-mac":
            _brew, java_cmd = detail
            consented = self._java_install_consent(
                "Homebrew", java_cmd, restart_note=False)
            return (lambda: True) if consented else None
        if plan_name == "auto-windows":
            _winget, java_cmd = detail
            consented = self._java_install_consent(
                "winget", java_cmd, restart_note=True)
            return (lambda: True) if consented else None
        # Manual paths: tell the user what to do, no worker action.
        if plan_name == "manual-linux":
            pkg_mgr, install_cmd = detail
            msg = (f"Java was not detected on PATH.\n"
                   f"IDE4EEG needs Java for Svarog and ConnectiVIS — "
                   f"see the README.\n\n"
                   f"To install on your distro ({pkg_mgr}), run:\n"
                   f"    {install_cmd}\n\n"
                   f"Then restart the GUI. The download below will "
                   f"still fetch Svarog/ConnectiVIS jars; they just "
                   f"won't run until Java is installed.")
        else:
            # manual-mac, manual-windows, manual-linux-unknown: detail
            # is the adoptium URL.
            msg = (f"Java was not detected on PATH and no auto-"
                   f"installer is available on this system.\n"
                   f"IDE4EEG needs Java for Svarog and ConnectiVIS.\n\n"
                   f"Install Eclipse Temurin 17 from:\n    {detail}\n\n"
                   f"Then restart the GUI.")
        self._msg_warning("Java required", msg)
        return None

    def _java_install_consent(self, tool_name, install_cmd, *,
                              restart_note):
        """Ask the user whether to run the given install command.

        Shared body for the macOS+brew and Windows+winget consent
        dialogs — they only differ in tool name, command, and the
        Windows-only "GUI restart needed" tail.
        """
        body = (
            f"IDE4EEG needs Java to run Svarog (signal viewer, "
            f"MP Book Viewer) and ConnectiVIS (3D dipole / "
            f"connectivity viewer).\n"
            f"{tool_name} is available; install Eclipse Temurin 17 "
            f"now?\n\n"
            f"This will run:  {install_cmd}\n"
            f"(downloads ~200 MB; one-time")
        if restart_note:
            body += (". The GUI will need to be restarted afterwards "
                     "so Python's PATH picks up the new install.)")
        else:
            body += ".)"
        return self._msg_confirm("Install Java?", body)

    def _run_single_download(self, *, title, worker_fn,
                              on_success_msg, on_error=None):
        """Generic helper for per-tool [Download recent] buttons.

        Parameters
        ----------
        title : str
            Window title and dialog heading (e.g. ``"SVAROG"``).
        worker_fn : callable
            Runs in the background thread; takes a ``progress`` callable
            with signature ``(done_bytes, total_bytes)``; returns the
            value to stash in ``result["ok"]``.  Wrap any path-edit
            updates inside this function via the GUI's edit attributes.
        on_success_msg : callable
            ``result_dict -> str`` — called on the main thread after
            the worker succeeds; the returned message goes into the
            success info dialog.
        on_error : callable, optional
            ``error_msg -> None`` — called on the main thread instead
            of the default ``_msg_error`` when the worker raises.
            Use this to show a copy-friendly dialog for errors whose
            text the user needs to extract (URLs, paths, commands).
        """
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Downloading {title}")
        dlg.setMinimumWidth(380)
        dlg_layout = QVBoxLayout(dlg)
        status_label = QLabel(f"Downloading {title}...")
        dlg_layout.addWidget(status_label)
        pbar = QProgressBar()
        pbar.setRange(0, 0)
        dlg_layout.addWidget(pbar)
        dlg.setModal(True)
        dlg.show()

        result = {}
        _prog = {"done": 0, "total": 0}

        def progress(done, total):
            _prog["done"] = done
            _prog["total"] = total

        def worker():
            try:
                result["ok"] = worker_fn(progress)
            except Exception as exc:
                result["err"] = f"{exc.__class__.__name__}: {exc}"

        def finished():
            dlg.close()
            if "err" in result:
                if on_error is not None:
                    on_error(result["err"])
                else:
                    self._msg_error(f"{title} download failed", result["err"])
            else:
                self._msg_info(f"{title} downloaded",
                               on_success_msg(result))

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        timer = QTimer(dlg)
        timer.setInterval(200)
        def check():
            if _prog["total"] > 0:
                pbar.setRange(0, _prog["total"])
                pbar.setValue(_prog["done"])
            else:
                pbar.setRange(0, 0)
            if not thread.is_alive():
                timer.stop()
                finished()
        timer.timeout.connect(check)
        timer.start()

    def _download_svarog_only(self):
        """[Download recent] handler for the SVAROG row.  Pulls the
        latest Svarog artifact from GitLab CI; the empi binary
        bundled inside the same artifact is also extracted, so the
        empi path edit gets refreshed too."""
        from ide4eeg.download_tools import download_svarog
        # Worker runs on a background thread — must NOT touch Qt
        # widgets directly (unsafe on macOS).  GUI state updates
        # happen inside msg() which _run_single_download invokes on
        # the main thread.
        def worker(progress):
            jar_path, empi_path = download_svarog(progress_callback=progress)
            return (jar_path, empi_path)

        def msg(result):
            jar, empi = result["ok"]
            self._svarog_jar = jar
            self._svarog_edit.setText(jar)
            if empi:
                self._empi_path = empi
                self._empi_edit.setText(empi)
            text = f"Installed:\n  {jar}"
            if empi:
                text += f"\n\nempi (bundled):\n  {empi}"
            return text

        self._run_single_download(
            title="SVAROG", worker_fn=worker, on_success_msg=msg)

    def _download_connectivis_only(self):
        """[Download recent] handler for the 3D view row."""
        from ide4eeg.download_tools import download_connectivis
        def worker(progress):
            return download_connectivis(progress_callback=progress)

        def msg(result):
            jar_path = result["ok"]
            self._connectivis_jar = jar_path
            self._connectivis_edit.setText(jar_path)
            return f"Installed:\n  {jar_path}"

        self._run_single_download(
            title="3D view", worker_fn=worker, on_success_msg=msg)

    def _download_empi_only(self):
        """[Download recent] handler for the empi row.  empi is
        bundled inside the Svarog artifact zip — there is no
        separate empi-only artifact — so this calls
        ``download_svarog`` and extracts both."""
        from ide4eeg.download_tools import download_svarog
        def worker(progress):
            return download_svarog(progress_callback=progress)

        def msg(result):
            jar, empi = result["ok"]
            self._svarog_jar = jar
            self._svarog_edit.setText(jar)
            if empi:
                self._empi_path = empi
                self._empi_edit.setText(empi)
            if not empi:
                return ("empi binary not found in the latest Svarog "
                        "artifact — the artifact layout may have "
                        "changed.")
            text = f"Installed empi:\n  {empi}"
            text += f"\n\nSvarog (bundled):\n  {jar}"
            return text

        self._run_single_download(
            title="empi", worker_fn=worker, on_success_msg=msg)

    def _build_mpv_row(self, parent_layout):
        """Single-line row for mpv (Svarog's preferred video
        backend).  No editable path field — Svarog auto-discovers
        via PATH and the canonical bundled location, so the title
        + status detection live in one line beside the Download
        button.
        """
        header = QHBoxLayout()
        title = QLabel(
            "<b>mpv</b> "
            "<span style='color:gray'>(Svarog video backend)</span>")
        title.setToolTip(
            "mpv is Svarog's preferred video backend, used when\n"
            "reviewing recordings with synchronised video.\n"
            "Without mpv, Svarog falls back to JavaFX which only\n"
            "plays MP4 — not MKV / WebM / AVI.  Install mpv to\n"
            "enable video sync for non-MP4 recordings.")
        header.addWidget(title)
        self._mpv_status_label = QLabel("")
        self._mpv_status_label.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        header.addWidget(self._mpv_status_label, 1)
        self._mpv_dl_btn = QPushButton("Download recent")
        self._mpv_dl_btn.setToolTip(
            "Download mpv into ~/.obci/svarog/mpv/ (Linux/Win)\n"
            "or run 'brew install mpv' on macOS with consent.")
        self._mpv_dl_btn.clicked.connect(self._download_mpv_only)
        header.addWidget(self._mpv_dl_btn)
        parent_layout.addLayout(header)
        self._refresh_mpv_status()

    def _refresh_mpv_status(self):
        """Re-detect mpv and update the inline status label.
        Called on Config-tab focus + after a successful download."""
        if not hasattr(self, "_mpv_status_label"):
            return
        from ide4eeg.download_tools import find_installed_mpv
        path = find_installed_mpv()
        if path:
            self._mpv_status_label.setText(
                f"<span style='color:{_OK_COLOR}'>✓</span>"
                f" <span style='color:gray'>{path}</span>")
            self._mpv_status_label.setToolTip(path)
        else:
            self._mpv_status_label.setText(
                f"<span style='color:{_ERR_COLOR}'>✗</span>"
                " <span style='color:gray'>not installed</span>")
            self._mpv_status_label.setToolTip(
                "mpv not found — Svarog will fall back to JavaFX\n"
                "(MP4-only).  Click 'Download recent' to enable\n"
                "MKV / WebM / AVI playback.")

    def _download_mpv_only(self):
        """[Download recent] handler for the mpv row.

        macOS path: ``download_mpv`` delegates to Homebrew when
        available; we collect consent on the main thread before
        the worker thread spawns (background threads can't pop
        Qt dialogs).
        """
        from ide4eeg.download_tools import (
            download_mpv, macos_mpv_status)
        # Main-thread consent for macOS brew install.
        mpv_brew_consent = None
        macos_status, macos_detail = macos_mpv_status()
        if macos_status == "brew-available":
            if self._msg_confirm(
                    "Install mpv via Homebrew?",
                    "Svarog uses mpv for video playback synchronised\n"
                    "with EEG.  Homebrew is installed; install mpv\n"
                    "now?\n\n"
                    f"This will run:  {macos_detail} install mpv\n"
                    "(downloads ~30 MB; one-time)."):
                mpv_brew_consent = lambda _brew: True
            else:
                return  # user declined
        elif macos_status == "no-brew":
            self._msg_warning(
                "Cannot install mpv automatically",
                "mpv is not installed and Homebrew is not\n"
                "detected on this Mac.  Install Homebrew first\n"
                "(https://brew.sh), then return and click\n"
                "Download recent.\n\n"
                "Alternatively install mpv via any other method —\n"
                "if it lands on PATH, Svarog will pick it up.")
            return

        def worker(progress):
            return download_mpv(
                progress_callback=progress,
                confirm_brew_install=mpv_brew_consent)

        def msg(result):
            self._refresh_mpv_status()
            path = result.get("ok")
            if path:
                return f"mpv installed at:\n  {path}"
            return ("mpv install reported no error but no binary "
                    "was registered.  See log for details.")

        self._run_single_download(
            title="mpv", worker_fn=worker, on_success_msg=msg)

    def _download_all_tools(self):
        """Download latest Svarog + empi, connectivis, and mpv (video backend)."""
        from ide4eeg.download_tools import (
            download_svarog, download_connectivis, download_mpv,
            install_java, java_install_plan, macos_mpv_status,
        )

        # All consent dialogs must run on the main thread BEFORE the
        # worker starts — background threads can't pop Qt dialogs.

        java_plan = java_install_plan()
        java_consent = self._java_preflight(java_plan)

        # macOS: detect mpv state and ask about brew install on main
        # thread, same constraint as Java above.
        mpv_brew_consent = None
        macos_status, macos_detail = macos_mpv_status()
        if macos_status == "brew-available":
            if self._msg_confirm(
                    "Install mpv?",
                    "Svarog uses mpv for video playback synchronized with EEG.\n"
                    "Homebrew is installed; install mpv now?\n\n"
                    f"This will run:  {macos_detail} install mpv\n"
                    "(downloads ~30 MB; one-time)."):
                mpv_brew_consent = lambda _brew: True

        dlg = QDialog(self)
        dlg.setWindowTitle("Downloading tools")
        dlg.setMinimumWidth(380)
        dlg_layout = QVBoxLayout(dlg)
        status_label = QLabel("Downloading Svarog + empi...")
        dlg_layout.addWidget(status_label)
        pbar = QProgressBar()
        pbar.setRange(0, 0)
        dlg_layout.addWidget(pbar)
        dlg.setModal(True)
        dlg.show()

        result = {}
        # Track progress state to apply on main thread
        _prog = {"done": 0, "total": 0, "phase": 0}

        def progress(done, total):
            _prog["done"] = done
            _prog["total"] = total

        def worker():
            try:
                result["svarog"] = download_svarog(progress_callback=progress)
            except Exception as exc:
                result["svarog_err"] = str(exc)
            _prog["phase"] = 1
            _prog["done"] = 0
            _prog["total"] = 0
            try:
                result["cvis"] = download_connectivis(progress_callback=progress)
            except Exception as exc:
                result["cvis_err"] = str(exc)
            # mpv is a soft step — auto-install only on Linux/Windows;
            # macOS returns None and Svarog falls back to PATH. Failures
            # are not fatal because Svarog runs without video.
            _prog["phase"] = 2
            _prog["done"] = 0
            _prog["total"] = 0
            try:
                result["mpv"] = download_mpv(
                    progress_callback=progress,
                    confirm_brew_install=mpv_brew_consent,
                )
            except Exception as exc:
                result["mpv_err"] = str(exc)
            # Java auto-install (if user consented above on
            # mac+brew or windows+winget). Pure no-op when
            # java_plan was "ok" or any "manual-*" path.
            _prog["phase"] = 3
            _prog["done"] = 0
            _prog["total"] = 0
            try:
                result["java"] = install_java(
                    confirm_callback=java_consent,
                    plan=java_plan)
            except Exception as exc:
                result["java_err"] = str(exc)

        def finished():
            dlg.close()
            errors = []
            warnings = []
            if "svarog" in result:
                jar_path, empi_path = result["svarog"]
                self._svarog_jar = jar_path
                self._svarog_edit.setText(jar_path)
                if empi_path:
                    self._empi_path = empi_path
                    self._empi_edit.setText(empi_path)
            else:
                errors.append(f"Svarog: {result.get('svarog_err', '?')}")
            if "cvis" in result:
                self._connectivis_jar = result["cvis"]
                self._connectivis_edit.setText(result["cvis"])
            else:
                errors.append(f"connectivis: {result.get('cvis_err', '?')}")
            # mpv is non-fatal: surface as a warning, don't block.
            if "mpv_err" in result:
                warnings.append(f"mpv: {result['mpv_err']}")
            if errors:
                msg = "\n".join(errors)
                if warnings:
                    msg += "\n\nWarnings:\n" + "\n".join(warnings)
                self._msg_error("Download failed", msg)
            else:
                msg = "Svarog, empi and connectivis installed."
                if result.get("mpv"):
                    msg += "\nVideo backend (mpv): %s" % result["mpv"]
                elif "mpv_err" not in result:
                    # No mpv available: macOS user declined brew, or no
                    # brew, or non-x64 Linux/Windows. Svarog will run
                    # but video playback falls back to JavaFX (or fails
                    # gracefully if JavaFX is unavailable).
                    if macos_status == "no-brew":
                        msg += ("\nVideo backend: mpv not installed and "
                                "Homebrew not detected. Install mpv "
                                "manually for video playback.")
                    elif macos_status == "brew-available":
                        msg += ("\nVideo backend: mpv install skipped. "
                                "Run 'brew install mpv' to enable video.")
                    else:
                        msg += ("\nVideo backend: mpv not installed; "
                                "video playback will fall back to JavaFX.")
                # Java state line (always show — silent only when
                # Java was already installed AND user didn't trigger
                # an auto-install).
                java_result = result.get("java")
                if java_result is not None:
                    j_status, j_detail = java_result
                    if j_status == "ok":
                        msg += f"\nJava: already installed ({j_detail})."
                    elif j_status == "installed":
                        msg += f"\nJava: installed — {j_detail}"
                    elif j_status == "declined":
                        msg += ("\nJava: not installed (skipped). "
                                "Svarog/ConnectiVIS will not run until "
                                "Java is installed.")
                    elif j_status == "failed":
                        msg += f"\nJava: install failed — {j_detail}"
                if "java_err" in result:
                    warnings.append(f"Java: {result['java_err']}")
                if warnings:
                    msg += "\n\nWarnings:\n" + "\n".join(warnings)
                self._msg_info("Download complete", msg)

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        timer = QTimer(dlg)
        timer.setInterval(200)
        def check():
            # Update widgets on main thread from progress state
            if _prog["phase"] == 1:
                status_label.setText("Downloading connectivis...")
            elif _prog["phase"] == 2:
                status_label.setText("Downloading mpv (video backend)...")
            if _prog["total"] > 0:
                pbar.setRange(0, _prog["total"])
                pbar.setValue(_prog["done"])
            else:
                pbar.setRange(0, 0)
            if not thread.is_alive():
                timer.stop()
                finished()
        timer.timeout.connect(check)
        timer.start()

    def _refresh_l2cs_button(self):
        """Update the unified L2CS button label / enabled state and
        the install-footprint path label.

        Three components must all be present for L2CS gaze to work:
        torch + torchvision, the l2cs Python package, and the
        Gaze360 weights checkpoint.  The Download button stays a
        single action ("Download L2CS for gaze detection") until
        all three are in place; once they are, it locks to a green
        "✓ installed" state.  Uninstall is enabled iff at least one
        component is present.  The grey sub-label shows the on-disk
        paths + measured sizes so users can `du -sh` or move the
        blobs.  No "~2 GB" estimate on the button itself — actual
        install size varies 5x between macOS-CPU and Linux-CUDA.
        """
        import sysconfig
        from ide4eeg.download_tools import (
            is_l2cs_stack_installed, canonical_l2cs_weights_path)
        torch_ok, pkg_ok, weights_ok = is_l2cs_stack_installed()
        all_installed = torch_ok and pkg_ok and weights_ok
        # Status label is always visible; flips between green ✓ and
        # dark-orange "N missing" depending on state.  Button is
        # hidden when there's nothing to install so the row doesn't
        # display a disabled button-shaped control.
        self._dl_l2cs_btn.setVisible(not all_installed)
        self._l2cs_status_label.setVisible(True)
        if all_installed:
            self._l2cs_status_label.setText(
                f"<span style='color:{_OK_COLOR}'>✓</span>"
                " <span style='color:gray'>installed</span>")
        else:
            missing = []
            if not torch_ok:
                missing.append(
                    "PyTorch + torchvision (~500 MB CPU / ~2 GB CUDA)")
            if not pkg_ok:
                missing.append("l2cs (GitHub fork)")
            if not weights_ok:
                missing.append("Gaze360 weights (~96 MB)")
            self._l2cs_status_label.setText(
                f"<span style='color:{_MISSING_COLOR}'>"
                f"{len(missing)} component(s) missing</span>")
            self._l2cs_status_label.setToolTip(
                "Missing:\n  • " + "\n  • ".join(missing))
            self._dl_l2cs_btn.setText(
                "Download L2CS for gaze detection")
            self._dl_l2cs_btn.setEnabled(True)
            self._dl_l2cs_btn.setToolTip(
                "Will install / fetch:\n  • " + "\n  • ".join(missing))
        # Path info — only the parts that actually exist on disk.
        # Label the site-packages line as "Python packages (...)" so
        # it's clear which components the size measures (the L2CS
        # row's pip deps), not "site-packages" as a free-floating
        # directory path.
        wpath = canonical_l2cs_weights_path()
        site_packages = sysconfig.get_paths().get("purelib", "")
        lines = []
        if weights_ok:
            try:
                size_mb = os.path.getsize(wpath) / (1024 * 1024)
                lines.append(f"Weights: {wpath} ({size_mb:.0f} MB)")
            except OSError:
                lines.append(f"Weights: {wpath}")
        if torch_ok or pkg_ok:
            sz = self._l2cs_install_size_bytes(site_packages)
            sz_str = self._fmt_size(sz) if sz else ""
            prefix = (f"Python packages (torch, torchvision, l2cs): "
                      f"~{sz_str} in " if sz_str
                      else "Python packages (torch, torchvision, "
                      "l2cs) in ")
            lines.append(f"{prefix}{site_packages}")
        self._l2cs_path_info.setText("\n".join(lines))

    @staticmethod
    def _l2cs_install_size_bytes(site_packages):
        """Approximate disk footprint of the core L2CS pip packages.

        Walks ``torch/``, ``torchvision/``, ``l2cs/`` under the active
        venv's site-packages.  Excludes torch's transitive deps
        (sympy, networkx, ...) — they survive a pip-uninstall of
        torch and aren't really "L2CS install" from the user's
        point of view.  Empty / missing dirs contribute 0; the
        function stays cheap-enough for sync calls (~0.3s for ~15k
        files on warm cache, ~1s cold).
        """
        if not site_packages or not os.path.isdir(site_packages):
            return 0
        total = 0
        for pkg in ("torch", "torchvision", "l2cs"):
            d = os.path.join(site_packages, pkg)
            if not os.path.isdir(d):
                continue
            for root, _, files in os.walk(d):
                for f in files:
                    try:
                        total += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        pass
        return total

    @staticmethod
    def _fmt_size(nbytes):
        """Human-readable byte count: MB up to 1024, GB above."""
        mb = nbytes / (1024 * 1024)
        if mb < 1024:
            return f"{mb:.0f} MB"
        return f"{mb / 1024:.1f} GB"

    def _download_l2cs_all(self):
        """Install L2CS-Net components (torch + l2cs + Gaze360 weights).

        Uses the same streaming-log dialog as the bulk
        ``_install_video_stack`` flow — pip output appears in a
        monospace text view as it arrives, so a slow torch download
        no longer looks frozen.  Three steps run sequentially in a
        worker thread:

          1. ``pip install torch torchvision`` (skipped if torch is
             already importable).
          2. ``pip install <l2cs git url>`` (skipped if l2cs is
             present).
          3. Download the 91 MB Gaze360 weights file from GitLab
             Releases via ``download_l2cs_weights``.

        On pip failure, the captured output is surfaced via
        :meth:`_show_l2cs_error` with the platform-specific hint
        (Intel Mac + Py3.14 etc.).  On weights failure, the
        copy-friendly help dialog with URL + save path.
        """
        from ide4eeg.download_tools import (
            L2CS_GIT_URL, canonical_l2cs_weights_path,
            download_l2cs_weights, is_l2cs_stack_installed)
        from ide4eeg.install_runner import (
            install_specs, pip_failure_hint)
        from ide4eeg.preprocessing.facetag.l2cs_gaze import _WEIGHTS_URL

        torch_ok, pkg_ok, weights_ok = is_l2cs_stack_installed()
        plan = []
        if not torch_ok:
            plan.append(
                "PyTorch + torchvision (~500 MB on macOS / "
                "Linux-CPU, up to ~2 GB on Linux with CUDA wheels)")
        if not pkg_ok:
            plan.append("l2cs Python package")
        if not weights_ok:
            plan.append("Gaze360 weights (~91 MB)")
        if not plan:
            self._refresh_l2cs_button()
            return
        if not self._msg_confirm(
                "Download L2CS for gaze detection?",
                "This will install / fetch:\n  • "
                + "\n  • ".join(plan)
                + "\n\nContinue?"):
            return

        # Disable the button immediately so a fast double-click
        # cannot spawn a second pip install (corrupts venv metadata).
        self._dl_l2cs_btn.setEnabled(False)

        # Streaming-log dialog (same shape as _install_video_stack).
        from ide4eeg.install_runner import CancellationToken
        cancel_token = CancellationToken()
        log_dlg = QDialog(self)
        log_dlg.setWindowTitle("Installing L2CS-Net")
        log_dlg.setMinimumSize(640, 360)
        ll = QVBoxLayout(log_dlg)
        status = QLabel("Starting pip install...")
        ll.addWidget(status)
        log_view = QPlainTextEdit()
        log_view.setReadOnly(True)
        log_view.setStyleSheet(
            "QPlainTextEdit { font-family: monospace; }")
        ll.addWidget(log_view, 1)
        close_btn, mark_finished = self._make_cancel_close_button(
            log_dlg, cancel_token, status,
            confirm_title="Cancel L2CS install?")
        ll.addWidget(close_btn)
        log_dlg.setModal(True)

        import queue
        line_queue: "queue.Queue[str]" = queue.Queue()
        result: dict = {}

        def log_callback(line: str) -> None:
            line_queue.put(line)

        def worker():
            # Step 1: torch + torchvision (single subprocess).
            if not torch_ok:
                if cancel_token.is_cancelled:
                    result["cancelled"] = True
                    return
                ok, output = install_specs(
                    ["torch", "torchvision"],
                    label="PyTorch + torchvision",
                    log_callback=log_callback,
                    cancel=cancel_token)
                if cancel_token.is_cancelled:
                    result["cancelled"] = True
                    return
                if not ok:
                    result["pip_err"] = (
                        f"pip install torch torchvision failed.\n\n"
                        f"Full output:\n{output.strip()}"
                        + pip_failure_hint(output))
                    return
            # Step 2: l2cs from GitHub.
            if not pkg_ok:
                if cancel_token.is_cancelled:
                    result["cancelled"] = True
                    return
                ok, output = install_specs(
                    [L2CS_GIT_URL],
                    label="l2cs (git URL)",
                    log_callback=log_callback,
                    cancel=cancel_token)
                if cancel_token.is_cancelled:
                    result["cancelled"] = True
                    return
                if not ok:
                    result["pip_err"] = (
                        f"pip install l2cs failed.\n\n"
                        f"Full output:\n{output.strip()}"
                        + pip_failure_hint(output))
                    return
            # Step 3: Gaze360 weights file.  No subprocess to
            # terminate — urlretrieve doesn't support cancellation
            # cleanly, so we let it complete unless already
            # cancelled before it starts.
            if cancel_token.is_cancelled:
                result["cancelled"] = True
                return
            log_callback("")
            log_callback(">>> Downloading Gaze360 weights (~91 MB)")
            try:
                result["weights_path"] = download_l2cs_weights()
                log_callback(f"OK: {result['weights_path']}")
            except FileNotFoundError as exc:
                result["weights_err"] = str(exc)
                log_callback(f"FAIL: {exc}")
            except Exception as exc:
                result["weights_err"] = (
                    f"{exc.__class__.__name__}: {exc}")
                log_callback(f"FAIL: {result['weights_err']}")

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        timer = QTimer(log_dlg)
        timer.setInterval(50)

        def drain():
            while True:
                try:
                    line = line_queue.get_nowait()
                except queue.Empty:
                    break
                log_view.appendPlainText(line)
            if not thread.is_alive():
                while True:
                    try:
                        line = line_queue.get_nowait()
                    except queue.Empty:
                        break
                    log_view.appendPlainText(line)
                timer.stop()
                mark_finished()
                self._refresh_l2cs_button()
                if hasattr(self, "_video_install_all_btn"):
                    self._refresh_video_install_all_btn()
                if result.get("cancelled"):
                    status.setText(
                        "<b>Cancelled.</b>  Whatever pip finished "
                        "before stop is preserved.")
                elif "pip_err" in result:
                    status.setText("Install failed (see log).")
                    QTimer.singleShot(
                        0, lambda: self._show_l2cs_error(
                            result["pip_err"]))
                elif "weights_err" in result:
                    status.setText(
                        "Packages installed but weights download "
                        "failed.")
                    QTimer.singleShot(
                        0, lambda: self._show_download_help_dialog(
                            title="L2CS weights download failed",
                            body=result["weights_err"],
                            copy_items=[
                                ("URL", _WEIGHTS_URL),
                                ("save path",
                                 canonical_l2cs_weights_path()),
                            ]))
                else:
                    self._show_install_success(
                        log_view=log_view,
                        status_label=status,
                        status_text=(
                            "✓ L2CS-Net installed successfully — "
                            "gaze detection is ready to use."),
                        banner_lines=[
                            "L2CS-Net installed successfully.",
                            "Gaze detection is ready to use.",
                        ])
                    self._refresh_gaze_method_badge()

        timer.timeout.connect(drain)
        timer.start()
        log_dlg.exec()

    def _show_download_help_dialog(self, *, title, body, copy_items):
        """Copy-friendly error dialog for failed downloads.

        Parameters
        ----------
        title : str
            Window + heading text.
        body : str
            Full error message — shown in a read-only QPlainTextEdit
            so the user can select / copy any portion.
        copy_items : list of (label, value) tuples
            One ``[Copy {label}]`` button per entry; clicking writes
            ``value`` to the system clipboard.  Used for the URL the
            user has to open in a browser, the path they need to save
            into, etc.
        """
        from PySide6.QtGui import QGuiApplication
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.setMinimumWidth(700)
        dlg.setMinimumHeight(360)
        lay = QVBoxLayout(dlg)
        header = QHBoxLayout()
        icon = QLabel()
        icon.setPixmap(self.style().standardPixmap(
            self.style().StandardPixmap.SP_MessageBoxCritical
        ).scaled(40, 40))
        header.addWidget(icon)
        header.addWidget(QLabel(f"<h3>{title}</h3>"), 1)
        lay.addLayout(header)
        edit = QPlainTextEdit()
        edit.setReadOnly(True)
        edit.setPlainText(body)
        lay.addWidget(edit, 1)
        for label, value in copy_items:
            row = QHBoxLayout()
            val_lbl = QLabel(value)
            val_lbl.setTextInteractionFlags(
                Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
            val_lbl.setStyleSheet(
                "font-family: monospace; color: #1565c0;")
            val_lbl.setWordWrap(True)
            row.addWidget(val_lbl, 1)
            btn = QPushButton(f"Copy {label}")
            btn.setFixedWidth(140)
            def _copy(_=None, v=value, b=btn, lbl=label):
                QGuiApplication.clipboard().setText(v)
                b.setText("Copied ✓")
                QTimer.singleShot(
                    1200, lambda b=b, lbl=lbl: b.setText(f"Copy {lbl}"))
            btn.clicked.connect(_copy)
            row.addWidget(btn)
            lay.addLayout(row)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        ok = QPushButton("OK")
        ok.clicked.connect(dlg.accept)
        ok.setDefault(True)
        btn_row.addWidget(ok)
        lay.addLayout(btn_row)
        dlg.exec()

    def _show_l2cs_error(self, text):
        """Error dialog with a scrollable read-only text area.

        Pip output for a failed wheel-resolution can run dozens of
        lines (one entry per attempted index URL); the standard
        QLabel-based ``_msg_error`` would either elide or stretch
        the dialog off-screen.  Using a QPlainTextEdit gives the
        user a fixed-size scrolling box they can also copy from.
        """
        dlg = QDialog(self)
        dlg.setWindowTitle("L2CS-Net install failed")
        dlg.setMinimumWidth(640)
        dlg.setMinimumHeight(380)
        lay = QVBoxLayout(dlg)
        icon = QLabel()
        icon.setPixmap(self.style().standardPixmap(
            self.style().StandardPixmap.SP_MessageBoxCritical
        ).scaled(40, 40))
        header = QHBoxLayout()
        header.addWidget(icon)
        header.addWidget(
            QLabel("<h3>L2CS-Net install failed</h3>"), 1)
        lay.addLayout(header)
        edit = QPlainTextEdit()
        edit.setReadOnly(True)
        edit.setPlainText(text)
        lay.addWidget(edit, 1)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        ok = QPushButton("OK")
        ok.clicked.connect(dlg.accept)
        ok.setDefault(True)
        btn_row.addWidget(ok)
        lay.addLayout(btn_row)
        dlg.exec()

    def _check_tools_on_startup(self):
        """Show a suggestion if any companion tools are missing."""
        missing = []
        if not self._svarog_jar:
            missing.append("Svarog")
        if not self._empi_path:
            missing.append("empi")
        if not self._connectivis_jar:
            missing.append("connectivis (3D view)")
        if not missing:
            return
        names = ", ".join(missing)
        if self._msg_confirm(
                "Companion tools not found",
                f"{names} not found.\n\n"
                "Download from GitLab now?"):
            self._download_all_tools()

    _VIDEO_ONBOARD_DISMISSED_KEY = "video_install_prompt_dismissed"

    def _check_video_stack_onboarding(self):
        """First-launch prompt: offer to install missing video tools.

        Shown once-per-machine.  Skipped when:
          - the user clicked 'Don't ask again' on a previous run
            (persisted in QSettings under
            ``video_install_prompt_dismissed``),
          - or every video tool is already installed.

        Dialog buttons:
          [Install all]   -> chain into _install_all_video_tools
          [Skip for now]  -> close, ask again next launch
          [Don't ask again] -> persist flag, never prompt again
        """
        settings = QSettings("IDE4EEG", "IDE4EEG")
        if settings.value(
                self._VIDEO_ONBOARD_DISMISSED_KEY,
                False, type=bool):
            return
        from ide4eeg.download_tools import (
            find_installed_mpv, is_l2cs_stack_installed)
        from ide4eeg.install_diagnostics import plan_install
        plan = plan_install()
        core_missing = [p for p in plan.missing if not p.optional]
        torch_ok, pkg_ok, weights_ok = is_l2cs_stack_installed()
        l2cs_missing = not (torch_ok and pkg_ok and weights_ok)
        mpv_missing = find_installed_mpv() is None
        if not (core_missing or l2cs_missing or mpv_missing):
            return  # nothing to install

        # Build a per-component checklist for the dialog body.
        items = []
        if mpv_missing:
            items.append("• mpv (Svarog video sync — optional)")
        if core_missing:
            items.append(
                "• "
                + str(len(core_missing))
                + " core Python package(s) "
                "(face detection, video decoding)")
        if l2cs_missing:
            items.append(
                "• L2CS-Net + PyTorch + Gaze360 weights "
                "(default eye-gaze backend)")

        role = self._styled_dialog(
            "Install video processing tools?",
            "Video stack not fully installed",
            "<p>The video pipeline (face detection, gaze tracking, "
            "EEG-synchronised video review) needs:</p>"
            "<p>" + "<br>".join(items) + "</p>"
            "<p>You can install everything in one click now, or "
            "install components individually later from the "
            "<b>Config tab → Tool Paths → Video stack</b> "
            "section.</p>",
            self.style().StandardPixmap.SP_MessageBoxQuestion,
            [("Install all", "install"),
             ("Skip for now", "skip"),
             ("Don't ask again", "dismiss")])
        if role == "install":
            self._install_all_video_tools()
        elif role == "dismiss":
            settings.setValue(
                self._VIDEO_ONBOARD_DISMISSED_KEY, True)

    # ── Signal info reading (background thread) ──────────────────────

    def _read_signal_info(self, path):
        self._sig_info_label.setText("Reading signal info...")
        self._sig_progress.show()

        # Release previous data before loading new file
        self._cached_signal = None
        self._cached_events = None
        self._cached_unnamed_codes = {}
        self._has_native_positions = False
        self._montage_hint = None
        self._pipeline_data = {}
        import gc; gc.collect()

        def worker():
            try:
                from ide4eeg.input.input import read_file_info
                info = read_file_info(path)
                if info is None:
                    self._signals.signal_info_error.emit(
                        "Could not read the input file.")
                    return
                # Cache signal only if BrainTech already loaded it
                sig = info.pop("_signal", None)
                self._cached_signal = sig
                self._cached_events = info.get("events")
                self._cached_unnamed_codes = info.get("unnamed_codes") or {}
                self._signals.signal_info_ready.emit(info)
            except Exception as e:
                self._signals.signal_info_error.emit(str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _toggle_event_details(self):
        """Toggle visibility of the event detail text area."""
        vis = self._sig_events_detail.isVisible()
        self._sig_events_detail.setVisible(not vis)
        self._sig_events_toggle.setText(
            "Hide event details" if not vis else "Show event details")

    @Slot(dict)
    def _on_signal_info_ready(self, info):
        self._sig_progress.hide()
        dur = info["duration"]
        mm, ss = int(dur // 60), int(dur % 60)
        _ev = info["events"]
        n_ev = (sum(_ev.values()) if _ev and isinstance(
            next(iter(_ev.values()), None), int) else len(_ev))
        _unnamed = info.get("unnamed_codes") or {}
        n_ev += sum(_unnamed.values())
        # Estimate peak RAM during processing (~3x raw data for copies)
        raw_bytes = info.get("raw_bytes") or (
            info["n_channels"] * info["sfreq"] * dur * 8)
        peak_bytes = raw_bytes * 3
        def _fmt_bytes(b):
            if b > 2**30: return f"{b / 2**30:.1f} GB"
            if b > 2**20: return f"{b / 2**20:.0f} MB"
            return f"{b / 2**10:.0f} KB"
        ram_str = _fmt_bytes(peak_bytes)
        # Check available RAM (try multiple methods)
        avail = None
        for _try_ram in [
            lambda: __import__('psutil').virtual_memory().available,
            lambda: os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_AVPHYS_PAGES'),
            lambda: (int(subprocess.check_output(
                ['sysctl', '-n', 'hw.memsize']).strip())
                if sys.platform == 'darwin' else None),
        ]:
            try:
                avail = _try_ram()
                if avail and avail > 0:
                    break
            except Exception:
                continue
        if avail and peak_bytes > avail * 0.8:
            ram_str += (f" \u26a0 (system RAM: {_fmt_bytes(avail)}"
                        f" \u2014 consider trimming)")
        hh = int(dur // 3600)
        dur_str = f"{hh}h {mm % 60:02d}:{ss:02d}" if hh else f"{mm}:{ss:02d}"
        tag_warn = ""
        if info.get("tag_error"):
            tag_warn = f"   |   \u26a0 tag file unreadable"
        self._sig_info_label.setText(
            f"Duration: {dur_str}   |   "
            f"Sampling: {info['sfreq']:.0f} Hz   |   "
            f"Channels: {info['n_channels']}   |   "
            f"Events: {n_ev}   |   "
            f"est. RAM: ~{ram_str}{tag_warn}")
        # Channel summary: type counts on line 1 (high-density), name
        # list on line 2 (identification). Type counts are derived
        # from the effective type list (base + user overrides if any,
        # merged in _on_signal_info_ready below).
        ch_types = info.get("ch_types", [])
        n_total = info["n_channels"]
        if ch_types:
            from collections import Counter
            type_counts = Counter(ch_types)
            type_str = ", ".join(
                f"{c} {t}" for t, c in type_counts.most_common())
            header = f"Channels ({n_total}): {type_str}"
        else:
            header = f"Channels ({n_total})"
        ch_str = ", ".join(info["ch_names"])
        if len(ch_str) > 150:
            ch_str = ch_str[:150] + "..."
        self._sig_channels_label.setText(f"{header}\n  {ch_str}")

        # ── Parse events (BrainTech JSON tags supported) ─────────
        import json as _json
        from collections import OrderedDict, Counter
        ev_groups = OrderedDict()
        raw_events = info.get("events", {})
        for k in raw_events:
            # BrainTech path returns {name: count} — use the count
            count = raw_events[k] if isinstance(raw_events[k], int) else 1
            if k.startswith("{"):
                try:
                    d = _json.loads(k)
                    name = d.get("name", k[:40])
                    desc = d.get("desc", {})
                    if isinstance(desc, dict):
                        parts = [f"{dk}={dv}" for dk, dv in desc.items()
                                 if dv not in ("", None)]
                        desc_str = ", ".join(parts) if parts else ""
                    else:
                        desc_str = str(desc)
                except (_json.JSONDecodeError, TypeError):
                    name = k[:40]
                    desc_str = ""
            else:
                name = k
                desc_str = ""
            ev_groups.setdefault(name, Counter())[desc_str] += count

        # Summary line: "45x1, 45x2, 45xpryma"
        if ev_groups:
            parts = []
            for name, descs in ev_groups.items():
                cnt = sum(descs.values())
                parts.append(f"{cnt}\u00d7{name}")
            ev_str = ", ".join(parts)
        else:
            ev_str = "none"
        unnamed_codes = info.get("unnamed_codes") or {}
        if unnamed_codes:
            n_unnamed = len(unnamed_codes)
            lo, hi = min(unnamed_codes), max(unnamed_codes)
            if ev_str == "none":
                ev_str = f"{n_unnamed} unnamed codes ({lo}\u2013{hi})"
            else:
                ev_str += f"   + {n_unnamed} unnamed codes ({lo}\u2013{hi})"
        self._sig_events_label.setText(f"Events: {ev_str}")

        # Detail text
        detail_lines = []
        for name, descs in ev_groups.items():
            cnt = sum(descs.values())
            detail_lines.append(f"  {name} ({cnt}):")
            if len(descs) == 1:
                desc_str = list(descs.keys())[0]
                detail_lines.append(
                    f"    {desc_str}" if desc_str else "    (no description)")
            else:
                for desc_str, dcnt in descs.items():
                    label = desc_str if desc_str else "(no description)"
                    detail_lines.append(f"    {dcnt}\u00d7 {label}")
        if unnamed_codes:
            detail_lines.append(
                f"  unnamed codes ({len(unnamed_codes)} distinct, "
                f"{sum(unnamed_codes.values())} occurrences):")
            ranked = sorted(
                unnamed_codes.items(), key=lambda kv: (-kv[1], kv[0]))
            top_n = 20
            for code, cnt in ranked[:top_n]:
                detail_lines.append(f"    {cnt}\u00d7 (code {code})")
            if len(ranked) > top_n:
                detail_lines.append(f"    (+ {len(ranked) - top_n} more)")

        if detail_lines:
            self._sig_events_detail.setPlainText("\n".join(detail_lines))
            self._sig_events_toggle.show()
        else:
            self._sig_events_detail.hide()
            self._sig_events_toggle.hide()

        # Feature 16: show video metadata if video path is set
        video_path = self._video_edit.text().strip()
        if video_path and os.path.isfile(video_path):
            try:
                import cv2
                from ide4eeg.preprocessing.facetag.video_reader import (
                    _suppress_stderr)
                with _suppress_stderr():
                    cap = cv2.VideoCapture(video_path)
                if cap.isOpened():
                    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    nf = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                    vdur = nf / fps if fps > 0 else 0
                    vm, vs = int(vdur // 60), int(vdur % 60)
                    self._sig_channels_label.setText(
                        self._sig_channels_label.text()
                        + f"\nVideo: {w}x{h} @ {fps:.1f} FPS, "
                        f"{vm}:{vs:02d}, {nf} frames")
                cap.release()
            except ImportError:
                pass
            except Exception:
                pass

        self._status.showMessage(
            f"Loaded: {self._input_edit.text()}", 5000)
        self._add_recent(self._input_edit.text().strip())
        # Cache channel names + types for lazy-built tabs.
        # _base_ch_types is the immutable auto-inferred typing from the
        # file reader + overlay. _cached_ch_types = base + user
        # type_overrides from config. Both are refreshed whenever the
        # user edits an override via _set_channel_type_override.
        self._cached_ch_names = info["ch_names"]
        self._base_ch_types = list(info.get("ch_types", []) or [])
        # Apply any user overrides saved in the config on top
        overrides = self.config_data.get("choosing_channels", {}).get(
            "type_overrides", {}) or {}
        self._cached_ch_types = list(self._base_ch_types)
        for i, name in enumerate(self._cached_ch_names):
            if name in overrides:
                self._cached_ch_types[i] = overrides[name]
        # Populate channel panels
        for panel in self._channel_panels:
            panel.populate(info["ch_names"], ch_types=self._cached_ch_types)
        # Reveal + populate the collapsible "Review channel types"
        # section on the Input tab. This is the editable view; the
        # per-tab panels above are read-only for types.
        if hasattr(self, "_ch_type_review_group"):
            self._ch_type_review_group.setVisible(True)
            self._ch_type_review_panel.populate(
                self._cached_ch_names,
                selected=set(self._cached_ch_names),
                ch_types=dict(zip(
                    self._cached_ch_names, self._cached_ch_types)),
            )
        # Apply dropped_channels from config to the Drop Channels panel
        pp = getattr(self, "_pp", {})
        sel_panel = pp.get("sel_channel_panel")
        if sel_panel and sel_panel._checkboxes:
            dropped = set(self.config_data.get(
                "choosing_channels", {}).get("dropped_channels", []))
            for name, cb in sel_panel._checkboxes:
                cb.setChecked(name not in dropped)
        # Default MP channels to EEG only
        mp_panel = pp.get("mp_channels")
        if mp_panel and mp_panel._checkboxes:
            mp_panel._select_eeg()
        # Auto-select mode based on file content:
        # events found → event-locked, no events → timed windows
        has_epoch_events = bool(ev_groups)
        if has_epoch_events:
            self._mode_combo.setCurrentText(self._MODE_DISPLAY["epochs"])
        else:
            self._mode_combo.setCurrentText(self._MODE_DISPLAY["rest"])
        # Enable/disable event-locked option in the combo
        idx_epochs = self._mode_combo.findText(self._MODE_DISPLAY["epochs"])
        if idx_epochs >= 0:
            model = self._mode_combo.model()
            item = model.item(idx_epochs)
            if has_epoch_events:
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEnabled)
            else:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
        # Update analysis availability based on data properties
        if hasattr(self, "_update_mne_availability"):
            self._update_mne_availability()

        # Populate event selection widget in epochs frame
        self._sync_unnamed_toggle(self._cached_unnamed_codes)
        self._populate_event_list(
            self._cached_events or {},
            unnamed_codes=self._cached_unnamed_codes)

        # Feature 18: start STIM channel preparation in background
        self._prepare_stim_channel()

        # Update dynamic labels that depend on signal info
        self._cached_sfreq = info["sfreq"]
        self._cached_duration = info["duration"]
        self._has_native_positions = bool(info.get("has_native_positions"))
        self._montage_hint = info.get("montage_hint") or None
        pp = getattr(self, "_pp", {})
        # Item 3: original sampling frequency — drives the resample
        # panel header summary.
        self._update_resample_header_info()
        # Item 4: trim duration
        self._update_trim_duration()
        # Item 1: montage match + description
        self._apply_native_positions_lock()
        self._update_montage_match()
        self._update_montage_availability()
        self._update_montage_desc()
        # Item 2: re-reference validation
        self._update_reref_status()
        # Item 13: MP dict size + profile page hint
        self._update_mp_dict_size()
        self._update_prof_epoch_hint()
        # Show signal duration as placeholder in timed-windows "end" field
        pp = getattr(self, "_pp", {})
        dur = info["duration"]
        w = pp.get("rest_dur_end")
        if w:
            w.setPlaceholderText(f"{dur:.1f}")
        # Prefill Nyquist in freq-max fields
        an = getattr(self, "_an", {})
        pp = getattr(self, "_pp", {})
        nyq = int(info["sfreq"] / 2)
        for _aft in (an.get("dip_atom_table"),
                     pp.get("mpf_atom_table"),
                     an.get("prof_atom_table")):
            if _aft:
                _aft.set_freq_max_nyquist(nyq)
        # Auto-detect 10-20 montage for dipole fitting
        _dip_mont = an.get("dip_montage")
        if _dip_mont and _dip_mont.currentText() == "standard_1005":
            eeg_names = set(info.get("ch_names", []))
            if eeg_names & self._CLASSIC_1020:
                _dip_mont.setCurrentText("standard_1020")
        if hasattr(self, "_update_mne_availability"):
            self._update_mne_availability()
        self._update_tab_indicators()
        # Scan for existing MP books from previous pipeline runs on this
        # file.  Invalidate the 5-second cache so the walk is fresh, then
        # refresh all book panels.  _refresh_book_panels already applies
        # the right filter per panel:
        #   • prof_book_panel (mmp_only=False) → populated by any book
        #     (SMP or MMP), so its "no book" warning disappears if SMP
        #     books are present
        #   • dip_book_panel  (mmp_only=True)  → populated only by MMP
        #     books, so its warning stays until an MMP book is found
        if hasattr(self, "_mp_books_cache_time"):
            del self._mp_books_cache_time  # force fresh scan
        self._refresh_book_panels()

    # ── Channel type overrides ────────────────────────────────────────

    def _register_channel_panel(self, panel):
        """Track a SelectionPanel as a pipeline channel-selection
        panel (i.e. its checkbox state becomes part of
        ``dropped_channels``/``selected_channels`` in the saved
        config).

        Per-tab panels on Preprocessing and Analysis should register
        via this helper. The Input tab's "Review channel types" panel
        does NOT register — its checkbox state is cosmetic and doesn't
        feed into pipeline config. That panel is type_editable=True
        and connects its own override signal directly in the Input tab
        construction code.
        """
        self._channel_panels.append(panel)
        try:
            panel.channel_type_override_requested.connect(
                self._set_channel_type_override)
        except AttributeError:
            # Older panel type without the override signal — safe to skip
            pass
        return panel

    def _apply_type_overrides_to_cache(self):
        """Re-derive ``self._cached_ch_types`` by starting from the
        last-known auto-inferred types and overlaying the current
        ``config_data["choosing_channels"]["type_overrides"]`` dict.

        Called after any override change (from the right-click menu,
        the review dialog, or a config load) to push the new types
        through to all SelectionPanels.
        """
        if not getattr(self, "_cached_ch_names", None):
            return
        # We need the "auto" types to fall back to. Cache them when
        # the file is first loaded (_base_ch_types), so the override
        # dict is always computed on top of the pristine inference.
        base_types = getattr(self, "_base_ch_types", None)
        if base_types is None:
            # Legacy path: no base cached — treat the current cache
            # as the base. One-time migration.
            base_types = list(self._cached_ch_types)
            self._base_ch_types = base_types
        overrides = self.config_data.get("choosing_channels", {}).get(
            "type_overrides", {}) or {}
        new_types = list(base_types)
        for i, name in enumerate(self._cached_ch_names):
            if name in overrides:
                new_types[i] = overrides[name]
        self._cached_ch_types = new_types
        ch_types_dict = dict(
            zip(self._cached_ch_names, self._cached_ch_types))
        # Re-populate every pipeline-level channel panel with the
        # refreshed types (so their adaptive filter buttons rebuild)
        for panel in self._channel_panels:
            if panel._checkboxes:
                panel.set_channel_types(ch_types_dict)
        # Also refresh the inline "Review channel types" panel on the
        # Input tab so its labels reflect the new type after a right-
        # click menu action. It's not in _channel_panels because its
        # checkbox state is cosmetic and doesn't feed pipeline config.
        review_panel = getattr(self, "_ch_type_review_panel", None)
        if review_panel is not None and review_panel._checkboxes:
            review_panel.set_channel_types(ch_types_dict)
        # Also refresh the Signal Info type-count line
        self._update_signal_info_type_counts()

    def _set_channel_type_override(self, name, new_type):
        """Set or remove a single channel type override.

        Parameters
        ----------
        name : str
            Channel name.
        new_type : str
            Target MNE channel type, or the sentinel ``"auto"`` to
            remove any existing override for this channel (restoring
            the auto-inferred type).
        """
        cc = self.config_data.setdefault("choosing_channels", {})
        overrides = cc.setdefault("type_overrides", {})
        if new_type == "auto":
            overrides.pop(name, None)
        else:
            overrides[name] = new_type
        self._apply_type_overrides_to_cache()

    def _update_signal_info_type_counts(self):
        """Refresh the type-count summary in the Signal Info panel."""
        if not hasattr(self, "_sig_channels_label"):
            return
        if not getattr(self, "_cached_ch_names", None):
            return
        from collections import Counter
        counts = Counter(self._cached_ch_types or [])
        type_str = ", ".join(
            f"{v} {k}" for k, v in counts.most_common())
        n_total = len(self._cached_ch_names)
        ch_str = ", ".join(self._cached_ch_names)
        if len(ch_str) > 150:
            ch_str = ch_str[:150] + "..."
        self._sig_channels_label.setText(
            f"Channels ({n_total}): {type_str}\n  {ch_str}")

    @Slot(str)
    def _on_signal_info_error(self, error):
        self._sig_progress.hide()
        self._sig_info_label.setText(f"Error: {error}")
        self._sig_channels_label.setText("")
        self._sig_events_label.setText("")
        self._sig_events_detail.hide()
        self._sig_events_toggle.hide()
        # Hide the Review channel types panel when no signal is loaded
        if hasattr(self, "_ch_type_review_group"):
            self._ch_type_review_group.setVisible(False)

    @Slot(object, object, object, object)
    def _on_ica_topomaps_requested(self, ica, out_dir, result, done):
        """Render ICA component topomap PNGs on the GUI main thread.

        Worker-thread matplotlib segfaults on macOS even with Agg —
        Qt's Cocoa main loop asserts when plot_components touches
        NSWindow-adjacent state off-thread.  Signalling the render
        to this slot makes the drawing run on the main thread; the
        worker blocks on ``done`` and then continues to launch
        Svarog with the PNGs on disk.
        """
        try:
            from ide4eeg.preprocessing.svarog_review import (
                _render_topomaps_inline)
            _render_topomaps_inline(ica, out_dir)
        except Exception as e:
            result["error"] = e
        done.set()

    @Slot(object, object, object)
    def _on_manual_segments_requested(self, epochs, result, done):
        """Show MNE's Epochs.plot on the GUI main thread for rejection.

        Worker-thread matplotlib.plot(block=True) crashes on macOS
        (NSWindow from off-main-thread).  The pipeline emits this
        signal when Svarog isn't available; the slot opens the plot
        non-blocking, hooks close_event, and returns the indices the
        user dropped.
        """
        import matplotlib
        prior_backend = matplotlib.get_backend()
        needs_restore = (sys.platform == "darwin"
                         and prior_backend.lower() == "agg")
        if needs_restore:
            matplotlib.use("QtAgg", force=True)
        try:
            # Match the CLI path's scaling heuristic so the interactive
            # plot opens at a sensible amplitude for both paths.
            eeg_data = (epochs.copy().load_data()
                        .pick("eeg", exclude=epochs.info["bads"])
                        .get_data())
            import numpy as _np
            scale = (float(_np.round(_np.quantile(eeg_data, 0.995), 5))
                     if eeg_data.size > 0 else 100e-6)
            fig = epochs.plot(
                block=False, show=True,
                event_id=epochs.event_id,
                events=epochs.events, n_epochs=10,
                scalings=dict(eeg=scale))

            def on_close(_evt=None):
                # After the user closes the browser, drop_log holds
                # the user's rejections — collect indices of any
                # entry with a non-empty tuple.
                reject_idxs = {
                    i for i in range(len(epochs.drop_log))
                    if epochs.drop_log[i] != ()}
                result["reject_idxs"] = reject_idxs
                if needs_restore:
                    try:
                        matplotlib.use(prior_backend, force=True)
                    except Exception:
                        pass
                done.set()

            canvas = getattr(fig, "canvas", None)
            if canvas is not None and hasattr(canvas, "mpl_connect"):
                canvas.mpl_connect("close_event", on_close)
            else:
                on_close()
        except Exception as e:
            if needs_restore:
                try:
                    matplotlib.use(prior_backend, force=True)
                except Exception:
                    pass
            result["error"] = e
            done.set()

    @Slot(object, object, object, object)
    def _on_manual_ica_requested(self, raw, ica, result, done):
        """Show MNE's ICA plot_sources picker on the GUI main thread.

        Mirror of ``_on_manual_bad_channels_requested``: the pipeline
        worker emits this signal so the window opens on the correct
        thread (NSWindow must be main-thread on macOS). We open non-
        blocking and hook ``close_event`` — when the user closes the
        window, ``ica.exclude`` holds the final selection.
        """
        # On macOS the worker globally switches matplotlib to Agg to
        # avoid NSWindow crashes. Restore an interactive backend here
        # so the window actually opens, then restore after close.
        import matplotlib
        prior_backend = matplotlib.get_backend()
        needs_restore = (sys.platform == "darwin"
                         and prior_backend.lower() == "agg")
        if needs_restore:
            matplotlib.use("QtAgg", force=True)
        try:
            fig = ica.plot_sources(raw, block=False, show=True)

            def on_close(_evt=None):
                result["exclude"] = list(ica.exclude)
                if needs_restore:
                    try:
                        matplotlib.use(prior_backend, force=True)
                    except Exception:
                        pass
                done.set()

            canvas = getattr(fig, "canvas", None)
            if canvas is not None and hasattr(canvas, "mpl_connect"):
                canvas.mpl_connect("close_event", on_close)
            else:
                on_close()
        except Exception as e:
            if needs_restore:
                try:
                    matplotlib.use(prior_backend, force=True)
                except Exception:
                    pass
            result["error"] = e
            done.set()

    @Slot(object, object, object, object, object, object)
    def _on_manual_bad_channels_requested(
            self, signal, overlay_events, tags_desc_id, scalings,
            result, done):
        """Show MNE's interactive bad-channel picker on the GUI thread.

        Called via a queued signal from the pipeline worker thread
        (see ``_launch_pipeline``). Opening an NSWindow from a worker
        crashes the whole process on macOS; this slot runs on the
        main thread so the plot is safe.

        The worker is blocked on a ``threading.Event``. Using
        ``block=True`` inside an already-running Qt event loop is
        unreliable (on macOS it often returns immediately without
        waiting), so we open the plot non-blocking and hook the
        figure's ``close_event`` — when the user closes the window
        we read ``info["bads"]`` and wake the worker.
        """
        # On macOS the worker globally switches matplotlib to Agg to
        # avoid NSWindow crashes. Restore an interactive backend here
        # so the window actually opens, then restore after close.
        import matplotlib
        prior_backend = matplotlib.get_backend()
        needs_restore = (sys.platform == "darwin"
                         and prior_backend.lower() == "agg")
        if needs_restore:
            matplotlib.use("QtAgg", force=True)
        try:
            fig = signal.plot(events=overlay_events,
                              event_id=tags_desc_id, block=False,
                              show=True, highpass=1, lowpass=40,
                              scalings=scalings)

            def on_close(_evt=None):
                result["bads"] = list(signal.info.get("bads", []))
                if needs_restore:
                    try:
                        matplotlib.use(prior_backend, force=True)
                    except Exception:
                        pass
                done.set()

            # MNE's matplotlib browser exposes the canvas directly.
            # If a future refactor swaps in a Qt-native browser the
            # attribute lookup will fail — fall back to an immediate
            # set so the worker doesn't hang forever.
            canvas = getattr(fig, "canvas", None)
            if canvas is not None and hasattr(canvas, "mpl_connect"):
                canvas.mpl_connect("close_event", on_close)
            else:
                on_close()
        except Exception as e:
            if needs_restore:
                try:
                    matplotlib.use(prior_backend, force=True)
                except Exception:
                    pass
            result["error"] = e
            done.set()

    @Slot(str, str)
    def _on_pipeline_log(self, message, level):
        """Handle special log messages from background threads."""
        if message.startswith("BAD_CHANNELS:"):
            text = message[len("BAD_CHANNELS:"):]
            self._status.showMessage("Bad channels detected", 5000)
            # Item 12: show result in the Bad Channels section label
            pp = getattr(self, "_pp", {})
            lbl = pp.get("bad_result")
            if lbl:
                lbl.setStyleSheet("color: #1565c0;")
                lbl.setText(text)
            hdr = pp.get("bad_header_info")
            if hdr:
                hdr.setText(text)
                hdr.setStyleSheet("color: gray;")
            self._msg_info("Bad Channels", text)
        elif message.startswith("BAD_CHANNELS_ERROR:"):
            text = message[len("BAD_CHANNELS_ERROR:"):]
            self._status.showMessage("Bad channel detection failed", 5000)
            pp = getattr(self, "_pp", {})
            lbl = pp.get("bad_result")
            if lbl:
                lbl.setStyleSheet("color: #c62828;")
                lbl.setText(f"Error: {text}")
            hdr = pp.get("bad_header_info")
            if hdr:
                hdr.setText("")
                hdr.setStyleSheet("")
            self._msg_warning("Error", str(text))
        elif message == "STIM channel ready":
            self._status.showMessage("STIM channel ready", 3000)
        elif message.startswith("STIM prep failed:"):
            self._status.showMessage(message, 5000)

    # ── STIM channel preparation (feature 18) ────────────────────────

    def _prepare_stim_channel(self):
        """Smoke-test event selection for the currently loaded signal.

        ``_build_event_dict`` is a pure config operation so this runs
        synchronously on the GUI thread — no background worker needed.
        """
        signal = self._cached_signal
        events = self._cached_events
        if signal is None:
            return
        try:
            from ide4eeg.preprocessing.channels_and_signal import (
                _build_event_dict)
            cfg = self._collect_config()
            cfg["sfreq"] = signal.info["sfreq"]
            _build_event_dict(cfg, events)
            self._signals.pipeline_log.emit("STIM channel ready", "INFO")
        except Exception as e:
            self._signals.pipeline_log.emit(
                f"STIM prep failed: {e}", "WARNING")

    # ── Event selection helpers ────────────────────────────────────────

    def _populate_event_list(self, events_dict, unnamed_codes=None,
                             *, show_unnamed=None):
        """Fill the event SelectionPanel from discovered events.

        ``unnamed_codes`` is ``{int_code: count}`` for codes present
        in the STIM channel that aren't bound to a named OBCI tag.
        When ``show_unnamed`` is True they become "(code N)" entries
        following the named tags; when False (default), they are
        omitted entirely.  ``show_unnamed=None`` reads the current
        toggle state.  Default selection is named-only.
        """
        panel = self._pp.get("ev_panel")
        if panel is None:
            return
        events_dict = events_dict or {}
        unnamed_codes = unnamed_codes or {}
        if show_unnamed is None:
            toggle = self._pp.get("ev_show_unnamed")
            show_unnamed = bool(toggle and toggle.isChecked())
        named_names = list(events_dict.keys())
        unnamed_names = (
            [UNNAMED_CODE_LABEL.format(c)
             for c in sorted(unnamed_codes.keys())]
            if show_unnamed else [])
        all_names = named_names + unnamed_names
        counts = dict(events_dict)
        if show_unnamed:
            for code, cnt in unnamed_codes.items():
                counts[UNNAMED_CODE_LABEL.format(code)] = cnt
        pending = getattr(self, "_pending_event_selection", None)
        if pending is None:
            pending = set(named_names) if named_names else set()
        panel.populate(all_names, selected=pending, counts=counts,
                       named_items=set(named_names))
        self._pending_event_selection = None

    def _sync_unnamed_toggle(self, unnamed_codes):
        """Refresh the show-unnamed checkbox label + visibility for
        the given ``{code: count}`` map.  Hidden when no unnamed
        codes are present.
        """
        toggle = self._pp.get("ev_show_unnamed")
        if toggle is None:
            return
        toggle.setVisible(bool(unnamed_codes))
        toggle.setText(
            f"Show {len(unnamed_codes or {})} unnamed code(s)")

    def _on_show_unnamed_toggled(self, _checked):
        panel = self._pp.get("ev_panel")
        if panel is None:
            return
        self._pending_event_selection = set(panel.selected_items())
        self._populate_event_list(
            self._cached_events,
            unnamed_codes=self._cached_unnamed_codes)

    @staticmethod
    def _all_event_labels(events_dict, unnamed_codes):
        """Return the full set of event labels the picker can offer.

        Single source for the named-events ∪ unnamed-code-labels
        union: same convention used to populate the SelectionPanel
        (named keys plus ``UNNAMED_CODE_LABEL.format(code)``).  Both
        the picker build and the preflight name-existence check
        consume this so the unnamed-label format only lives here.
        """
        labels = set(events_dict or ())
        for code in (unnamed_codes or ()):
            labels.add(UNNAMED_CODE_LABEL.format(code))
        return labels

    def _get_selected_events(self):
        """Return list of checked event names."""
        panel = self._pp.get("ev_panel")
        return panel.selected_items() if panel else []

    def _update_seg_mode_label(self):
        """Refresh the Segmentation-setup header label.

        Event-locked mode shows ``"{n}/{total} event selected"`` where
        *total* is the count of discovered events in the file; timed-
        windows mode shows the configured window length (e.g.
        ``"20-s long"``).  The combo right after the label completes
        the sentence with "event-locked" / "timed windows".
        """
        lbl = getattr(self, "_seg_mode_label", None)
        if lbl is None:
            return
        if self._mode == "epochs":
            n = len(self._get_selected_events())
            panel = self._pp.get("ev_panel")
            total = len(panel._checkboxes) if panel else 0
            lbl.setText(f"{n}/{total} event selected")
        else:
            wl = self._pp["rest_window"].text().strip()
            lbl.setText(f"{wl}-s long" if wl else "long")
        self._update_seg_preview_label()

    def _update_seg_preview_label(self):
        """Refresh the body-line preview of cut_segments output.

        Best-effort summary of what the always-runs ``cut_segments``
        postamble step will produce, derivable from current GUI state
        without reading the input file.  Rest mode predicts the count
        only when both trim ends are finite; event mode shows the
        epoch width (per-event count needs the file's STIM channel,
        not available here).
        """
        lbl = self._pp.get("seg_preview_lbl")
        if lbl is None:
            return
        if self._mode == "epochs":
            n = len(self._get_selected_events())
            try:
                t0 = float(self._pp["ep_start"].text() or 0)
                t1 = float(self._pp["ep_stop"].text() or 0)
                width = max(0.0, t1 - t0)
            except (KeyError, ValueError):
                width = 0.0
            if n == 0:
                lbl.setText(
                    "→ no epochs (select at least one event above)")
            else:
                lbl.setText(
                    f"→ epochs of {width:.2f} s "
                    f"around each occurrence of the {n} selected "
                    f"event(s) in the file")
            return
        # Rest mode
        try:
            wl = float(self._pp["rest_window"].text().strip() or 0)
        except ValueError:
            wl = 0.0
        if wl <= 0:
            lbl.setText("→ enter a window length to preview")
            return
        try:
            t_start = float(self._pp["rest_dur_start"].text() or 0)
            t_end_raw = self._pp["rest_dur_end"].text().strip()
            t_end = float(t_end_raw) if t_end_raw else None
        except (KeyError, ValueError):
            t_end = None
            t_start = 0.0
        whole = self._pp.get("rest_whole")
        if whole is not None and whole.isChecked():
            lbl.setText(
                f"→ {wl:.0f}-s rest windows spanning the whole "
                "trimmed signal")
            return
        if t_end is not None and t_end > t_start:
            n = max(0, int((t_end - t_start) // wl))
            lbl.setText(
                f"→ ≈ {n} rest window(s) of {wl:.0f} s in "
                f"[{t_start:g}, {t_end:g}] s")
        else:
            lbl.setText(
                f"→ {wl:.0f}-s rest windows starting at "
                f"{t_start:g} s")

    # ── Viewer launchers ─────────────────────────────────────────────
    #
    def _update_view_input_btns(self, text=""):
        """Enable/disable View-in buttons based on input path.

        Debounced: schedules the actual check 300 ms after the last
        keystroke to avoid per-character stat calls (costly on
        network mounts).
        """
        timer = getattr(self, "_view_btn_timer", None)
        if timer is None:
            from PySide6.QtCore import QTimer
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._do_update_view_input_btns)
            self._view_btn_timer = timer
        timer.start(300)

    def _do_update_view_input_btns(self):
        text = self._input_edit.text().strip()
        ok = bool(text) and os.path.isfile(text)
        self._view_svarog_btn.setEnabled(ok)
        self._view_mne_btn.setEnabled(ok)

    def _view_input_signal_svarog(self):
        """Open the input signal in SVAROG."""
        path = self._input_edit.text().strip()
        if not path or not os.path.isfile(path):
            self._msg_info("No file", "Select a valid input file first.")
            return
        self._launch_svarog(path, button=self._view_svarog_btn)

    def _view_input_signal_mne(self):
        """Open the input signal in MNE's interactive plot."""
        path = self._input_edit.text().strip()
        if not path or not os.path.isfile(path):
            self._msg_info("No file", "Select a valid input file first.")
            return
        self._open_signal_file_in_mne(path, title=os.path.basename(path))

    def _open_signal_file_in_mne(self, path, title=None):
        """Open any supported signal file in MNE, dispatching on type.

        ``.fif`` goes through :meth:`_open_mne_raw`.  Everything else
        (.raw, .vhdr, .set, .edf, .bdf) is routed through
        ``ide4eeg.input.input.read_file`` in a subprocess so the Qt
        event loop stays free and the user's signal readers are
        honoured.
        """
        if not path or not os.path.isfile(path):
            return
        if title is None:
            title = os.path.basename(path)
        if path.endswith(".fif"):
            self._open_mne_raw(path, title=title)
            return
        script = (
            "import matplotlib; matplotlib.use('QtAgg'); "
            f"import sys; sys.path.insert(0, {str(Path(__file__).parent)!r}); "
            "from ide4eeg.input.input import read_file; "
            f"r, _ = read_file({path!r}); "
            f"r.plot(title={title!r}, block=True)"
        )
        try:
            subprocess.Popen([sys.executable, "-c", script])
        except Exception as e:
            self._msg_error("Error", str(e))

    def _open_mne_raw(self, fif_path, title=None):
        """Open a .fif file in MNE's interactive plot (subprocess).

        Uses matplotlib's ``QtAgg`` backend, which comes from PySide6
        (already a hard dependency).  The older ``TkAgg`` choice
        required Tcl/Tk to be present in the system Python, which is
        NOT the case on Homebrew Python 3.13 builds on macOS.
        """
        if not fif_path or not os.path.isfile(fif_path):
            return
        if title is None:
            title = os.path.basename(fif_path)
        lower = fif_path.lower()
        is_epo = "-epo.fif" in lower
        is_ica = "-ica.fif" in lower
        if is_epo:
            script = (
                "import matplotlib; matplotlib.use('QtAgg'); "
                "import mne; "
                f"e = mne.read_epochs({fif_path!r}, "
                "preload=True, verbose=False); "
                f"e.plot(title={title!r}, block=True)"
            )
        elif is_ica:
            # -ica.fif is an mne.preprocessing.ICA serialization,
            # not a Raw.  read_raw_fif would fail with "No raw data
            # in ...".  Show the component topomaps — the most
            # useful default overview of a saved ICA.
            script = (
                "import matplotlib; matplotlib.use('QtAgg'); "
                "import matplotlib.pyplot as plt; "
                "from mne.preprocessing import read_ica; "
                f"ica = read_ica({fif_path!r}, verbose=False); "
                f"ica.plot_components(title={title!r}, show=False); "
                "plt.show(block=True)"
            )
        else:
            script = (
                "import matplotlib; matplotlib.use('QtAgg'); "
                "import mne; "
                f"r = mne.io.read_raw_fif({fif_path!r}, "
                "preload=True, verbose=False); "
                f"r.plot(title={title!r}, block=True)"
            )
        try:
            subprocess.Popen([sys.executable, "-c", script])
        except Exception as e:
            self._msg_error("Error", str(e))

    def _detect_java_major(self):
        """Return the installed Java major version (e.g. 11, 17, 21), or None.

        Cached on the instance after the first call.  ``java -version``
        prints to stderr in a format like ``openjdk version "17.0.9"``
        or (Java 8) ``java version "1.8.0_392"``.
        """
        cached = getattr(self, "_java_major_cache", "unset")
        if cached != "unset":
            return cached
        major = None
        try:
            out = subprocess.run(
                ["java", "-version"],
                capture_output=True, text=True, timeout=5)
            text = (out.stderr or "") + (out.stdout or "")
            m = re.search(r'version "(\d+)(?:\.(\d+))?', text)
            if m:
                first = int(m.group(1))
                # Java 8 reports as "1.8.0_..." → real major is 8
                major = int(m.group(2)) if first == 1 and m.group(2) else first
        except Exception:
            pass
        self._java_major_cache = major
        if major is not None:
            logging.info("Detected Java version: %d", major)
        return major

    #: Seconds the Java child must stay alive before we assume its
    #: window has actually drawn.  3 s comfortably covers the JVM
    #: cold-start on a laptop-class machine; anything shorter risks
    #: a false "started" on a slow SSD / cold JIT cache.
    _JAVA_READY_AFTER_S = 3.0

    def _launch_java_app(self, cmd, label, button=None):
        """Launch a Java helper (SVAROG / ConnectiVIS) with startup feedback.

        The JVM takes 3-8s to draw a window on a cold start, and
        ``subprocess.Popen`` returns immediately — users see nothing
        happen and click the button again.  This wrapper shows a
        status-bar message for the duration, and emits
        ``java_launch_done`` once the child has been alive long
        enough to assume the window is up (or exited early with an
        error).

        When *button* is supplied, its text is swapped for
        ``"Starting {label}…"`` and the button is disabled; the slot
        restores both on completion.  Callers that don't have a
        button reference (e.g. the 👁 step-view path) get the status-
        bar feedback only.

        Parameters
        ----------
        cmd : list[str]
            Full argv for ``Popen``.
        label : str
            Short human name used in feedback text ("SVAROG",
            "ConnectiVIS").
        button : QPushButton, optional
            Button that triggered the launch.  Disabled and re-
            labelled while the JVM starts.

        Raises
        ------
        FileNotFoundError
            If ``java`` isn't on PATH.  Caller handles the user-
            facing message so the install-hint copy stays local.
        """
        import time as _time
        self._status.showMessage(f"Starting {label}\u2026", 0)
        if button is not None:
            # Stash the original text as a dynamic property so the
            # slot can restore it regardless of which button it is.
            button.setProperty("_orig_text", button.text())
            button.setText(f"Starting {label}\u2026")
            button.setEnabled(False)
        proc = subprocess.Popen(
            cmd, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL)

        def watchdog():
            deadline = _time.monotonic() + self._JAVA_READY_AFTER_S
            while _time.monotonic() < deadline:
                rc = proc.poll()
                if rc is not None:
                    # Early exit — child crashed or printed a usage
                    # error and quit.  Grab stderr tail for the dialog.
                    err = ""
                    try:
                        err_bytes = proc.stderr.read() or b""
                        err = err_bytes.decode(
                            "utf-8", errors="replace").strip()
                    except Exception:
                        pass
                    self._signals.java_launch_done.emit(
                        label, rc, err, button)
                    return
                _time.sleep(0.1)
            # Still alive → assume window is up.  Drain stderr in the
            # background so the pipe buffer can't fill and block the
            # child; we don't need the output any more.
            self._signals.java_launch_done.emit(label, 0, "", button)
            try:
                proc.stderr.read()
            except Exception:
                pass

        threading.Thread(target=watchdog, daemon=True).start()
        return proc

    @Slot(str, int, str, object)
    def _on_java_launch_done(self, label, rc, err, button):
        """Clear status/button state; on early-exit, show the error."""
        self._status.clearMessage()
        if button is not None:
            orig = button.property("_orig_text")
            if orig:
                button.setText(orig)
            button.setEnabled(True)
        if rc != 0:
            tail = f"\n\n{err[-500:]}" if err else ""
            self._msg_error(
                f"{label} failed to start",
                f"{label} exited with code {rc} before its window "
                f"appeared.{tail}")
        else:
            self._status.showMessage(f"{label} started.", 3000)

    def _launch_svarog(self, path, tag=None, channel=None, book=None,
                       book_signals=None, split_signal=None,
                       button=None):
        """Launch SVAROG viewer for a signal file.

        Parameters
        ----------
        path : str
            Path to the signal file (.bdf, .edf, .fif, .raw, ...).
        tag : str, optional
            Tag (.tag) file path.
        channel : str, optional
            Show only this channel.
        book : str, optional
            MP book (.db) to display synchronized below the signal.
        book_signals : str, optional
            Signals to show in the book view: ``"original"``, ``"full"``,
            ``"original,full"`` (default), or ``"none"`` to hide signal
            traces and show only the time-frequency atom tiles.
        split_signal : str, optional
            Path to a second signal file to open as a synchronized
            slave plot below ``path`` (Svarog ``--split-signal``).  The
            two files must share sample rate.
        """
        if self._svarog_jar is None:
            self._svarog_jar = _find_svarog_jar()
        if self._svarog_jar is None:
            jar, _ = QFileDialog.getOpenFileName(
                self, "Locate SVAROG JAR", "",
                "JAR files (*.jar);;All (*)")
            if not jar:
                return
            self._svarog_jar = jar
        if not os.path.isfile(self._svarog_jar):
            self._msg_error("Error",
                                 f"SVAROG JAR not found:\n{self._svarog_jar}")
            self._svarog_jar = None
            return
        cmd = ["java"]
        # Java 16+ enforces strong encapsulation of JDK internals by default.
        # SVAROG is an older Swing app that reflects into java.base/java.desktop;
        # add --add-opens defensively so it doesn't crash with InaccessibleObjectException.
        java_major = self._detect_java_major()
        if java_major is not None and java_major >= 16:
            cmd.extend([
                "--add-opens", "java.base/java.lang=ALL-UNNAMED",
                "--add-opens", "java.base/java.util=ALL-UNNAMED",
                "--add-opens", "java.base/java.lang.reflect=ALL-UNNAMED",
                "--add-opens", "java.desktop/javax.swing=ALL-UNNAMED",
                "--add-opens", "java.desktop/java.awt=ALL-UNNAMED",
            ])
        cmd.extend(appcds_flags(self._svarog_jar))
        cmd.extend(["-jar", self._svarog_jar, "--nosplash"])
        if tag and os.path.isfile(tag):
            cmd.extend(["--tag", tag])
        if channel:
            cmd.extend(["--channel", channel])
        if book and os.path.isfile(book):
            cmd.extend(["--book", book])
            if book_signals:
                cmd.extend(["--book-signals", book_signals])
        if split_signal and os.path.isfile(split_signal):
            cmd.extend(["--split-signal", split_signal])
        cmd.append(path)
        # Print to stdout so the user can copy the exact command line.
        # logging.info() can be silently dropped if no handler is set.
        if _VERBOSE_LOGGING:
            print("SVAROG:", " ".join(cmd), flush=True)
        logging.info("SVAROG: %s", " ".join(cmd))
        try:
            self._launch_java_app(cmd, "SVAROG", button=button)
        except FileNotFoundError:
            self._status.clearMessage()
            self._msg_error(
                "Java not found",
                "Java is required to run SVAROG.\n\n"
                "Install Java 17 (recommended for best compatibility):\n"
                "  macOS:  brew install openjdk@17\n"
                "  Linux:  sudo apt install openjdk-17-jdk\n"
                "  Or download from https://adoptium.net")
        except Exception as e:
            self._status.clearMessage()
            self._msg_error("Error",
                                 f"Could not launch SVAROG:\n{e}")

    def _launch_connectivis(self, dat_files=None, button=None):
        """Launch connectivis viewer with optional .dat / .csv files."""
        jar = self._connectivis_jar
        if not jar:
            je = getattr(self, '_connectivis_edit', None)
            if je: jar = je.text().strip()
            if not jar: self._connectivis_jar = _find_connectivis_jar(); jar = self._connectivis_jar
        if not jar or not os.path.isfile(jar):
            self._msg_info("3D viewer not found",
                                    "Set the connectivis JAR path in the Config tab."); return
        # AppCDS class-data archive: ~0.5–1 s off cold start. Helper
        # builds flags using the same scheme as _launch_svarog and the
        # standalone-package-files/svarog launcher so all four launch
        # paths can share a .jsa file when the same JVM + jar is used.
        java_flags = list(appcds_flags(jar))
        # Deferred-renderer mode: window paints at ~1.5 s with an
        # "Initializing 3D viewer..." placeholder, EDT then blocks for
        # ~3.5 s while the renderer builds. Trade: faster perceived
        # start, beach-ball cursor while frozen. ON by default for
        # IDE4EEG launches (users have grown used to a "loading" cue
        # from the rest of the pipeline); set CVIS_SHOW_WINDOW_FIRST=0
        # to fall back to the old "no window until ready" behavior.
        if os.environ.get("CVIS_SHOW_WINDOW_FIRST", "1").lower() not in ("0", "false"):
            java_flags.append("-Dcvis.showWindowFirst=true")
        cmd = ["java",
               "--add-opens", "java.desktop/sun.awt=ALL-UNNAMED",
               *java_flags,
               "-jar", jar, "--nosplash"]
        if dat_files:
            from ide4eeg.analysis.dipole.visualize import (
                _CONNECTIVIS_DIR)
            # Per-run PLYs (subject-specific) override cached
            # fsaverage PLYs.  For fsaverage, only the brain PLY
            # is used; the head is left to ConnectiVIS's built-in
            # AC3D model (fsaverage's head is featureless).
            for dat in dat_files:
                base = (dat.replace("___erp_dipoles.csv", "___")
                            .replace("___dipoles.dat", "___")
                            .replace("___dipoles.csv", "___"))
                subj_brain = base + "brain.ply"
                subj_head = base + "head.ply"
                if os.path.isfile(subj_brain):
                    cmd.extend(["--brain-model", subj_brain])
                    if os.path.isfile(subj_head):
                        cmd.extend(["--head-model", subj_head])
                    break
            else:
                brain = os.path.join(_CONNECTIVIS_DIR,
                                     "fsaverage_brain_aparc.ply")
                if os.path.isfile(brain):
                    cmd.extend(["--brain-model", brain])
            import re as _re
            for dat in dat_files:
                stem = _re.sub(r"___.+\.(dat|csv)$", "", dat)
                cand = f"{stem}___electrodes.dat"
                if cand != dat and os.path.isfile(cand):
                    cmd.extend(["--electrodes", cand])
                    break
            cmd.extend(dat_files)
        try:
            self._launch_java_app(cmd, "ConnectiVIS", button=button)
        except FileNotFoundError:
            self._status.clearMessage()
            self._msg_error("Error", "Java not found.")
        except Exception as e:
            self._status.clearMessage()
            self._msg_error("Error", f"Could not launch connectivis:\n{e}")

    def _view_mp_book(self):
        """Eye-button handler for the MP Decomposition panel.

        Opens whatever MP book is on disk for the current input.
        The book filename pattern
        (``book_<base>_<algorithm>.db``, or
        ``book_<base>_<channel>.db`` for single-channel SMP) already
        encodes algorithm + channel info, so a name match is enough
        to confirm the book is the right shape for viewing.

        Hash-check intentionally skipped: drift between the runner's
        pinned hash and a fresh recompute would false-positive
        "stale" right after a successful run.  Real changes to MP
        params (iterations, explained_energy, etc.) require running
        decomposition again — the user knows that without us telling
        them; the eye button is for "let me look at what's there".
        """
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info(
                "No input file",
                "Select a valid input signal on the Input tab first.")
            return
        # Prefer the book produced by the most recent in-process run;
        # fall through to a name-based disk scan otherwise.
        book_path = getattr(self, "_mp_book_path", None)
        if not (book_path and os.path.isfile(book_path)):
            book_path = self._find_mp_book()
        if not (book_path and os.path.isfile(book_path)):
            self._msg_info(
                "No MP book",
                "No MP book (.db) found on disk yet.\n"
                "Click 'Run decomposition' in the MP Decomposition "
                "panel first.")
            return
        self._open_book_viewer(book_path)

    def _open_book_viewer(self, db_path):
        """Open an MP book (.db) in SVAROG or the built-in BookViewer."""
        if not db_path or not os.path.isfile(db_path):
            self._msg_info("No book", "No book file found.")
            return
        # Try SVAROG with --book flag if a nearby .fif exists
        if self._svarog_jar and os.path.isfile(self._svarog_jar):
            sig_dir = os.path.dirname(os.path.dirname(db_path))
            for sub in ("", "trimmed_signal", "filtered_signal", "resampled_signal"):
                d = os.path.join(sig_dir, sub) if sub else sig_dir
                if os.path.isdir(d):
                    for f in sorted(os.listdir(d)):
                        if f.endswith(".fif"):
                            self._launch_svarog(os.path.join(d, f), book=db_path)
                            return
        # Fallback: built-in BookViewer (Qt)
        try:
            from ide4eeg.analysis.mp_bookviewer_qt import BookViewerQt
            win = BookViewerQt(parent=self, db_path=db_path)
            win.show()
        except Exception as e:
            self._msg_error("Error", f"Could not open BookViewer:\n{e}")

    def _find_signal_for_book(self, book_path):
        """Find the signal file for SVAROG — prefer original input."""
        # Prefer the original input file (BDF/EDF/RAW etc.)
        inp = self._input_edit.text().strip()
        if inp and os.path.isfile(inp):
            return inp
        # Fallback: preprocessed .fif near the book
        if not book_path:
            return ""
        sig_dir = os.path.dirname(os.path.dirname(book_path))
        for sub in ("", "trimmed_signal", "filtered_signal",
                    "resampled_signal"):
            d = os.path.join(sig_dir, sub) if sub else sig_dir
            if os.path.isdir(d):
                for f in sorted(os.listdir(d)):
                    if f.endswith(".fif"):
                        return os.path.join(d, f)
        return ""

    def _find_profile_tag(self, book_path, channel_name):
        """Find the .tag file produced by EEG profiles."""
        candidates = []
        # Search near the book
        out_base = os.path.dirname(os.path.dirname(book_path))
        candidates.append(os.path.join(out_base, "eeg_profiles"))
        # Search in analysis output
        analysis_out = self._analysis_edit.text().strip()
        if analysis_out:
            candidates.append(os.path.join(analysis_out, "eeg_profiles"))
        # Search in output root (IDE4EEG_OUT_*)
        out_root = self._output_edit.text().strip()
        if out_root:
            for entry in os.listdir(out_root) if os.path.isdir(out_root) else []:
                d = os.path.join(out_root, entry)
                if entry.startswith(OUTPUT_DIR_PREFIX) and os.path.isdir(d):
                    for sub in os.listdir(d):
                        candidates.append(
                            os.path.join(d, sub, "eeg_profiles"))
        for tag_dir in candidates:
            if os.path.isdir(tag_dir):
                for f in sorted(os.listdir(tag_dir), reverse=True):
                    if f.endswith(".tag"):
                        if not channel_name or channel_name in f:
                            return os.path.join(tag_dir, f)
        return ""

    # Classic 21 channel names for the 10-20 filter
    _CLASSIC_1020 = {
        "Fp1", "Fp2", "F7", "F3", "Fz", "F4", "F8",
        "T3", "C3", "Cz", "C4", "T4",
        "T5", "P3", "Pz", "P4", "T6",
        "O1", "Oz", "O2",
        "T7", "T8", "P7", "P8",
        "A1", "A2",
    }
    _MONTAGE_ALIASES = {"10-20": "standard_1020",
                        "10-10": "standard_1005",
                        "10-05": "standard_1005"}

    def _view_montage(self):
        """Show a head diagram with montage electrode positions.

        Matched channels from the loaded file are shown in blue,
        unmatched montage positions in grey.
        """
        pp = getattr(self, "_pp", {})
        montage_key = self._cmb(pp, "montage", "10-20") if pp else "10-20"
        if montage_key == NATIVE_POSITIONS_SENTINEL:
            self._msg_info(
                "Native positions",
                "This file provides its own 3D electrode positions "
                "— they will be used as-is during preprocessing. A "
                "standard-montage preview is not applicable here.")
            return
        montage_name = self._MONTAGE_ALIASES.get(montage_key, montage_key)
        classic_filter = self._CLASSIC_1020 if montage_key == "10-20" else None

        try:
            import mne
            montage = mne.channels.make_standard_montage(montage_name)
        except Exception as e:
            self._msg_error("Montage error",
                                 f"Cannot load montage '{montage_name}':\n{e}")
            return

        # Channel names from loaded signal
        file_ch_names = set()
        cached = getattr(self, "_cached_signal", None)
        if cached is not None:
            file_ch_names = set(cached.ch_names)
        else:
            inp = self._input_edit.text().strip()
            if inp and os.path.isfile(inp):
                try:
                    from ide4eeg.input.input import read_file
                    sig, _ = read_file(inp)
                    file_ch_names = set(sig.ch_names)
                except Exception:
                    pass

        montage_names_set = set(montage.ch_names)
        matched = file_ch_names & montage_names_set
        unmatched_montage = montage_names_set - file_ch_names
        unmatched_file = file_ch_names - montage_names_set

        pos_3d = montage.get_positions()["ch_pos"]

        import numpy as np
        import matplotlib
        matplotlib.use("QtAgg")
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg

        fig, ax = plt.subplots(figsize=(7, 7))

        # Head outline
        theta = np.linspace(0, 2 * np.pi, 100)
        r = 0.095
        ax.plot(r * np.cos(theta), r * np.sin(theta), "k-", linewidth=1.5)
        ax.plot([-.015, 0, .015], [r, r + .015, r], "k-", linewidth=1.5)
        for sign in (-1, 1):
            ax.plot([sign * r, sign * (r + .008), sign * (r + .008),
                     sign * r],
                    [.015, .01, -.01, -.015], "k-", linewidth=1.0)

        if classic_filter:
            pos_3d = {k: v for k, v in pos_3d.items() if k in classic_filter}
            montage_names_set = montage_names_set & classic_filter
            matched = file_ch_names & montage_names_set
            unmatched_montage = montage_names_set - file_ch_names

        matched_positions = set()
        for ch_name in matched:
            if ch_name in pos_3d:
                p = pos_3d[ch_name]
                matched_positions.add((round(p[0], 5), round(p[1], 5)))

        for ch_name, pos in pos_3d.items():
            x, y = pos[0], pos[1]
            if ch_name in matched:
                ax.plot(x, y, "o", color="#2196F3", markersize=9, zorder=3)
                ax.annotate(ch_name, (x, y), fontsize=9, fontweight="bold",
                            ha="center", va="bottom",
                            xytext=(0, 5), textcoords="offset points",
                            color="#1565C0", zorder=4)
            elif ch_name in unmatched_montage:
                pos_key = (round(x, 5), round(y, 5))
                if pos_key in matched_positions:
                    continue
                ax.plot(x, y, "o", color="#9E9E9E", markersize=7,
                        markeredgecolor="#757575", markeredgewidth=0.5,
                        zorder=2)
                ax.annotate(ch_name, (x, y), fontsize=8,
                            ha="center", va="bottom",
                            xytext=(0, 4), textcoords="offset points",
                            color="#757575", zorder=2)

        ax.set_aspect("equal")
        ax.set_xlim(-0.13, 0.13)
        ax.set_ylim(-0.13, 0.13)
        ax.axis("off")

        from ide4eeg.gui_config import MONTAGE_INFO
        info = MONTAGE_INFO.get(montage_key, ("", 0, ""))
        title = montage_key
        if montage_key != montage_name:
            title += f" (MNE: {montage_name})"
        if info[0]:
            title += f" \u2014 {info[0]}"
        visible_grey = 0
        for ch in unmatched_montage:
            if ch in pos_3d:
                p = pos_3d[ch]
                if (round(p[0], 5), round(p[1], 5)) not in matched_positions:
                    visible_grey += 1
        lines = [title]
        parts = []
        if matched:
            parts.append(f"{len(matched)} matched (blue)")
        if visible_grey:
            parts.append(f"{visible_grey} montage-only (grey)")
        if parts:
            lines.append(" | ".join(parts))
        if unmatched_file:
            fl = ", ".join(sorted(unmatched_file)[:15])
            if len(unmatched_file) > 15:
                fl += "\u2026"
            lines.append(f"{len(unmatched_file)} file-only: {fl}")
        ax.set_title("\n".join(lines), fontsize=9, pad=12, linespacing=1.4)
        fig.tight_layout()

        # Embed in Qt dialog
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Montage: {montage_key}")
        dlg.resize(700, 780)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(0, 0, 0, 0)
        canvas = FigureCanvasQTAgg(fig)
        lay.addWidget(canvas)
        canvas.draw()
        dlg.finished.connect(lambda: plt.close(fig))
        dlg.show()

    def _preview_segments(self):
        """Open Svarog with a .tag file reflecting the current segmentation.

        Writes a temporary ``.tag`` file whose entries correspond to the
        segment windows that the preprocessing pipeline would cut out
        given the current config.  Launches Svarog on the RAW input
        signal with ``--tag <tmp>``, so the user sees where segments
        would fall before running the pipeline.

        Both a point tag (at the start of each segment) and a duration
        block (spanning the segment) are emitted — the point is what
        ``cut_segments`` uses as the event anchor, the block shows the
        actual signal window.

        Rest-mode segment positions are specified relative to the
        trimmed signal; to render them on the raw signal we add
        ``trim_start`` as an offset.  Epoch-mode events are already
        in raw-signal time (they come from the STIM channel of the
        raw file), so no offset is needed for them.
        """
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info(
                "No input file",
                "Select an input signal on the Input tab first.")
            return

        try:
            cfg = self._collect_config()
        except Exception as e:
            self._msg_error(
                "Configuration error",
                f"Could not read current configuration:\n{e}")
            return

        mode = get_segmentation_mode(cfg)
        trim_start = 0.0
        _ts = cfg.get("trim_start", 0)
        try:
            trim_start = float(_ts) if _ts not in ("", None) else 0.0
        except (TypeError, ValueError):
            trim_start = 0.0

        tags = []
        try:
            if mode == "rest":
                rest = cfg.get("rest", {})
                window_length = float(rest.get("window_length", 20) or 20)
                dur = rest.get("rest_duration", [0, ""])
                start0 = float(dur[0] or 0) if len(dur) > 0 else 0.0
                end0 = dur[1] if len(dur) > 1 else None
                if rest.get("whole_signal") or end0 in ("", None):
                    total = getattr(self, "_cached_duration", None)
                    if total is None:
                        self._msg_info(
                            "Signal duration unknown",
                            "Load the signal on the Input tab first so the\n"
                            "preview can compute the rest windows.")
                        return
                    end = float(total)
                else:
                    end = float(end0) + trim_start
                start = start0 + trim_start
                if window_length <= 0 or end <= start:
                    self._msg_info(
                        "No windows",
                        "Current rest settings produce zero windows.")
                    return
                t = start
                idx = 0
                while t + window_length <= end + 1e-9:
                    tags.append({
                        "channelNumber": -1,
                        "start_timestamp": t,
                        "end_timestamp": t,
                        "name": f"window_{idx}_start",
                        "desc": {"typ": "rest_window_start"},
                    })
                    tags.append({
                        "channelNumber": -1,
                        "start_timestamp": t,
                        "end_timestamp": t + window_length,
                        "name": f"window_{idx}",
                        "desc": {"typ": "rest_window"},
                    })
                    t += window_length
                    idx += 1
            else:
                # Epochs mode: read events from the RAW input and place
                # a window around each selected event.
                import mne
                from ide4eeg.input.input import read_file
                signal, _events_desc = read_file(inp)
                if signal is None:
                    self._msg_error(
                        "Read error",
                        "Could not read the input signal.")
                    return
                stim_channel = (
                    "STIM" if "STIM" in signal.info["ch_names"] else None)
                if stim_channel is None:
                    self._msg_info(
                        "No STIM channel",
                        "This file has no STIM channel — event-locked "
                        "segmentation can't be previewed.")
                    return
                events = mne.find_events(
                    signal, stim_channel=stim_channel,
                    shortest_event=1, verbose=False)
                sfreq = signal.info["sfreq"]
                epochs_cfg = cfg.get("epochs", {})
                start_offset = float(epochs_cfg.get("start_offset", 0) or 0)
                stop_offset = float(epochs_cfg.get("stop_offset", 0) or 0)
                if stop_offset <= start_offset:
                    self._msg_info(
                        "Zero-length epochs",
                        "stop_offset must be greater than start_offset.")
                    return
                # Event-ID filter: selected labels → numeric codes
                evd = cfg.get("events_desc_id", {}) or {}
                id_map = evd.get("dict") or evd
                selected = evd.get("selected") or []
                allowed_codes = None
                if selected:
                    allowed_codes = {
                        id_map[lbl] for lbl in selected if lbl in id_map}
                label_by_code = {v: k for k, v in id_map.items()
                                 if isinstance(v, int)}
                for sample, _zero, eid in events:
                    if allowed_codes is not None and eid not in allowed_codes:
                        continue
                    t_event = float(sample) / sfreq
                    lbl = label_by_code.get(eid, str(eid))
                    tags.append({
                        "channelNumber": -1,
                        "start_timestamp": t_event,
                        "end_timestamp": t_event,
                        "name": f"{lbl}_event",
                        "desc": {"typ": "epoch_event"},
                    })
                    tags.append({
                        "channelNumber": -1,
                        "start_timestamp": t_event + start_offset,
                        "end_timestamp": t_event + stop_offset,
                        "name": lbl,
                        "desc": {"typ": "epoch_window"},
                    })
        except Exception as e:
            self._msg_error(
                "Segment preview failed",
                f"Could not build segment tags:\n{e}")
            return

        if not tags:
            self._msg_info(
                "No segments",
                "No segments would be produced with the current "
                "configuration.")
            return

        # Write tag file and launch Svarog
        import tempfile
        try:
            from obci_readmanager.signal_processing.tags.tags_file_writer \
                import TagsFileWriter
        except ImportError:
            self._msg_error(
                "Missing dependency",
                "obci_readmanager is required for segment preview.")
            return
        tmp = tempfile.NamedTemporaryFile(
            suffix=".tag", delete=False, mode="w")
        tag_path = tmp.name
        tmp.close()
        writer = TagsFileWriter(tag_path)
        for tag in tags:
            writer.tag_received(tag)
        writer.finish_saving(0.0)
        self._launch_svarog(inp, tag=tag_path)

    # ── Preprocessing step actions (Save / View) ─────────────────────

    def _fallback_preproc_path(self):
        """Return preprocessing output dir, deriving from input if needed.

        Matches the runner's iterative stem-strip
        (:func:`ide4eeg.main.main`) for the ``IDE4EEG_OUT_<base>``
        directory so filenames with internal dots resolve to the same
        prefix the runner writes under: "subj.with.dots.bdf" → "subj",
        not "subjwithdots".  Older callers used
        ``.replace(".", "")``, which silently diverged from the
        runner whenever the input filename had internal dots — fixed
        in the 2026-05-02 audit pass.
        """
        p = self._preproc_edit.text().strip()
        if p:
            return p
        inp = self._input_edit.text().strip()
        if inp:
            d = os.path.dirname(inp) if os.path.isfile(inp) else inp
            base = os.path.basename(inp)
            while "." in base:
                base = os.path.splitext(base)[0]
            return os.path.join(
                d, f"{OUTPUT_DIR_PREFIX}{base}", "preprocessing")
        return ""

    def _resolve_preproc_dirs(self):
        """Return candidate on-disk preprocessing dirs, best-first.

        Mirrors the runner's path-derivation in
        :func:`ide4eeg.main.main` so GUI reads find runner-produced
        files regardless of where the runner actually wrote them.
        Layout candidates (highest priority first):

        1. The user's explicit ``preprocessing_output_path`` —
           runner uses this verbatim.
        2. ``<output_path>/IDE4EEG_OUT_<base>/preprocessing/`` —
           non-explicit + ``overwrite_output=True``.
        3. ``<output_path>/IDE4EEG_OUT_<base>/<timestamp>_<mode>/preprocessing/``
           sorted newest-first — non-explicit + ``overwrite_output=False``.
        4. Same as 2-3 but rooted at the input file's directory
           (legacy fallback for runs without an explicit
           ``output_path``).

        Only directories that exist on disk are returned.  The list
        may be empty (no input set, or no run has happened yet).

        Why disk-walking + listdir rather than computing the single
        "right" path: the GUI doesn't know whether the prior run was
        overwrite or non-overwrite, and timestamps can't be predicted.
        Returning all plausible dirs lets read sites pick the first
        one where their target file lives — same pattern as
        :meth:`_find_all_mp_books`.
        """
        dirs = []
        seen = set()

        def _add(d):
            if d and d not in seen and os.path.isdir(d):
                seen.add(d)
                dirs.append(d)

        explicit = self._preproc_edit.text().strip()
        if explicit:
            _add(explicit)

        inp = self._input_edit.text().strip()
        if not inp:
            return dirs
        # Match the runner's iterative stem-stripping
        # (``ide4eeg/main.py``): "subj.with.dots.bdf" → "subj", not
        # "subjwithdots".  Only the legacy ``_fallback_preproc_path``
        # uses the ``.replace(".", "")`` form.
        base = os.path.basename(inp)
        while "." in base:
            base = os.path.splitext(base)[0]

        roots = []
        out = self._output_edit.text().strip() if hasattr(
            self, "_output_edit") else ""
        if out:
            roots.append(out)
        in_dir = os.path.dirname(inp) if os.path.isfile(inp) else inp
        if in_dir:
            roots.append(in_dir)

        for root in roots:
            out_dir = os.path.join(
                root, f"{OUTPUT_DIR_PREFIX}{base}")
            # Overwrite-mode layout: directly under IDE4EEG_OUT_<base>/.
            _add(os.path.join(out_dir, "preprocessing"))
            # Non-overwrite layout: each timestamped subdir holds its
            # own preprocessing/.  Walk newest-first so a freshly
            # produced snapshot wins over a stale older one.
            if os.path.isdir(out_dir):
                try:
                    subs = sorted(
                        (s for s in os.listdir(out_dir)
                         if os.path.isdir(os.path.join(out_dir, s))),
                        reverse=True)
                except OSError:
                    subs = []
                for sub in subs:
                    _add(os.path.join(
                        out_dir, sub, "preprocessing"))

        return dirs

    def _find_in_preproc_dirs(self, rel_path):
        """First existing match for ``<dir>/<rel_path>`` across
        :meth:`_resolve_preproc_dirs`, or ``None``."""
        for d in self._resolve_preproc_dirs():
            candidate = os.path.join(d, rel_path)
            if os.path.isfile(candidate):
                return candidate
        return None


    def _build_filter_panel(self, filter_id, filter_cfg):
        """Build one Filters CollapsibleStep + register it for collect.

        Phase 2 factory shared by initial construction and the [+]
        add-button.  Each panel owns a unique ``filter_id`` (8-char
        hex; auto-generated when None is passed) and stores its
        widgets at id-suffixed keys (e.g. ``_pp[f"hp_{id}"]``).  The
        panel's GUI step key is ``f"filtering:{filter_id}"`` so the
        reorder machinery treats multiple filter panels as distinct
        entries.

        Returns
        -------
        (CollapsibleStep, str)
            The constructed panel and its step key.
        """
        import uuid as _uuid
        from ide4eeg.gui_config import FIELD_TOOLTIPS as _TT
        if not filter_id:
            filter_id = _uuid.uuid4().hex[:8]
        step_key = f"filtering:{filter_id}"
        grp = CollapsibleStep(
            "Filters",
            checkable=True, checked=False, reorderable=True,
            has_help=True, help_key="filtering")
        grp._filter_id = filter_id
        self._add_step_info_row(grp, "filtering", filter_id=filter_id)
        # "+" header button → duplicate this panel.  "−" header
        # button → remove this panel.  Both visible only when
        # allow_reorder is on (advanced mode); "−" is additionally
        # hidden on the first filter panel so the user can never
        # delete the canonical anchor (refresh in
        # ``_refresh_filter_minus_visibility``).
        minus_btn = QPushButton("−")  # U+2212 minus sign
        minus_btn.setFixedWidth(24)
        minus_btn.setToolTip(
            "Remove this Filters block.\n"
            "Hidden on the first Filters panel — there's always at\n"
            "least one filter slot.")
        minus_btn.clicked.connect(
            lambda _=False, src=filter_id: self._remove_filter_panel(src))
        grp._minus_btn = minus_btn

        plus_btn = QPushButton("+")
        plus_btn.setFixedWidth(24)
        plus_btn.setToolTip(
            "Add another Filters block right after this one.\n"
            "Visible only when 'Allow changing the order of\n"
            "preprocessing steps' is enabled in the Config tab.")
        plus_btn.clicked.connect(
            lambda _=False, src=filter_id: self._duplicate_filter_panel(src))
        grp._plus_btn = plus_btn
        # Header insertion is deferred until after enable_view_button
        # below so [- +] land immediately to the left of the eye —
        # they belong with the panel's structural controls, not the
        # action cluster (eye / ↑ / ↓ / ?).
        # Match initial visibility to the current allow_reorder state.
        reorder_on = (
            getattr(self, "_allow_reorder_check", None) is not None
            and self._allow_reorder_check.isChecked())
        plus_btn.setVisible(reorder_on)
        # Minus visibility is refreshed once the panel is registered
        # in self._filter_widgets (below); keep it hidden until then.
        minus_btn.setVisible(False)

        fv = grp.contentWidget().layout()
        fv.setContentsMargins(8, 4, 8, 4)
        pp = self._pp
        # Missing key in cfg => empty field => 0 in pipeline => filter
        # off, matching ``_filter_signal``'s contract.  A non-zero
        # default here would silently apply HP/LP that aren't in the
        # user's config.
        fr1 = QHBoxLayout()
        fr1.addWidget(QLabel("Highpass [Hz]:"))
        pp[f"hp_{filter_id}"] = QLineEdit(
            self._filter_cutoff_text(
                filter_cfg.get("highpass_freq", 0)))
        pp[f"hp_{filter_id}"].setFixedWidth(50)
        pp[f"hp_{filter_id}"].setToolTip(
            _TT.get("filters.highpass_freq", ""))
        fr1.addWidget(pp[f"hp_{filter_id}"])
        fr1.addSpacing(12)
        fr1.addWidget(QLabel("Lowpass [Hz]:"))
        pp[f"lp_{filter_id}"] = QLineEdit(
            self._filter_cutoff_text(
                filter_cfg.get("lowpass_freq", 0)))
        pp[f"lp_{filter_id}"].setFixedWidth(50)
        pp[f"lp_{filter_id}"].setToolTip(
            _TT.get("filters.lowpass_freq", ""))
        fr1.addWidget(pp[f"lp_{filter_id}"])
        fr1.addSpacing(12)
        fr1.addWidget(QLabel("Notch:"))
        pp[f"notch_{filter_id}"] = QComboBox()
        pp[f"notch_{filter_id}"].addItems(["None", "50 Hz", "60 Hz"])
        notch_freq = filter_cfg.get("notch_freq", 50)
        pp[f"notch_{filter_id}"].setCurrentText(
            f"{int(notch_freq)} Hz" if notch_freq > 0 else "None")
        pp[f"notch_{filter_id}"].setFixedWidth(70)
        pp[f"notch_{filter_id}"].setToolTip(
            _TT.get("filters.notch_freq", ""))
        fr1.addWidget(pp[f"notch_{filter_id}"])
        fr1.addSpacing(12)
        fr1.addWidget(QLabel("Method:"))
        pp[f"filt_method_{filter_id}"] = QComboBox()
        pp[f"filt_method_{filter_id}"].addItems(
            ["IIR (Butterworth)", "FIR (MNE)"])
        pp[f"filt_method_{filter_id}"].setCurrentText(
            "FIR (MNE)" if filter_cfg.get("method", "iir") == "fir"
            else "IIR (Butterworth)")
        pp[f"filt_method_{filter_id}"].setFixedWidth(130)
        pp[f"filt_method_{filter_id}"].setToolTip(
            _TT.get("filters.method", ""))
        fr1.addWidget(pp[f"filt_method_{filter_id}"])
        fr1.addStretch()
        fv.addLayout(fr1)
        # Options row.  "Show filter plots" used to be a checkbox that
        # caused MNE to pop up frequency-response figures during the
        # pipeline run; users wanted it to act on click instead, so it's
        # now a button (with adjacent magnitude-scale dropdown) that
        # designs and displays the response right then for the current
        # settings.  "Save filter plots" stays a checkbox — that one
        # still controls write-to-disk behavior of the pipeline.
        fr2 = QHBoxLayout()
        show_filt_btn = QPushButton("Show filter plots")
        show_filt_btn.setFixedWidth(140)
        show_filt_btn.setToolTip(
            "Design and display the filter frequency response\n"
            "for the current settings and sampling rate.\n"
            "\n"
            "Note: the FIR notch preview is approximate. The\n"
            "pipeline calls MNE's notch_filter, which uses a\n"
            "very narrow stopband (~0.25 Hz at 50 Hz) that the\n"
            "preview path can't redesign exactly — the visible\n"
            "notch here is wider (~2 Hz) so the dip is legible.\n"
            "The frequency is correct; the shape is qualitative.")
        pp[f"filt_show_scale_{filter_id}"] = QComboBox()
        pp[f"filt_show_scale_{filter_id}"].addItems(["dB", "linear"])
        pp[f"filt_show_scale_{filter_id}"].setFixedWidth(80)
        pp[f"filt_show_scale_{filter_id}"].setToolTip(
            "Magnitude axis scale on the filter-response plot:\n"
            "  dB     — log power (20·log10|H|), MNE default\n"
            "  linear — raw |H|")
        show_filt_btn.clicked.connect(
            lambda _=False, fid=filter_id:
                self._plot_filter_response(
                    fid,
                    scale=pp[f"filt_show_scale_{fid}"].currentText()))
        fr2.addWidget(show_filt_btn)
        fr2.addSpacing(8)
        fr2.addWidget(QLabel("Scale:"))
        fr2.addWidget(pp[f"filt_show_scale_{filter_id}"])
        fr2.addSpacing(20)
        pp[f"save_filt_{filter_id}"] = QCheckBox("Save filter plots")
        pp[f"save_filt_{filter_id}"].setChecked(
            filter_cfg.get("plot_filt", False))
        pp[f"save_filt_{filter_id}"].setToolTip(
            _TT.get("filters.plot_filt", ""))
        pp[f"save_filt_{filter_id}"].toggled.connect(
            lambda *_: self._refresh_review_badges())
        fr2.addWidget(pp[f"save_filt_{filter_id}"])
        fr2.addStretch()
        fv.addLayout(fr2)
        pp[f"_filt_grp_{filter_id}"] = grp
        # Save toggle: per-instance step key so multiple filter
        # panels don't collide on _pp["save_filtering"].  Passing
        # label/tooltip explicitly bypasses the _SAVE_CHECKBOX_MAP
        # lookup that would mismatch on the suffixed key.
        self._add_save_checkbox(
            grp, step_key,
            label="Save filtered signal",
            tooltip=("Save the signal after this filter block as\n"
                     "  <filename>-filtered-{id}-raw.fif."),
            default=bool(filter_cfg.get("save", False)))
        self._add_step_actions(grp, step_key)
        self._make_reorder_buttons(grp, step_key)
        _wire_help = self._wire_step_help
        _wire_help(grp, "filtering", "Filters")
        # Wire the eye / view-step button on every filter panel.
        # The build_preprocess_tab loop only runs once at startup,
        # so panels added later via the [+] button would otherwise
        # come up without an eye.
        step_label = self._STEP_LABELS.get("filtering", "Filters")
        grp.enable_view_button(
            tooltip=(
                f"View the before/after signal around the "
                f"{step_label} step.\n"
                f"Runs preprocessing up to this step if needed, "
                f"then opens\n"
                f"  Svarog split view (installed) or MNE "
                f"two-window (fallback)."),
            callback=lambda k=step_key: self._view_step_result(k))
        # Brief filter summary in the header — "0.5–30 Hz, notch
        # 50 Hz, IIR" — so the user sees the design at a glance
        # even when the panel is collapsed.
        filt_info = QLabel("")
        filt_info.setStyleSheet("color: gray;")
        pp[f"filt_header_info_{filter_id}"] = filt_info

        def _update_filt_info(*_a, fid=filter_id, lbl=filt_info):
            hp = pp[f"hp_{fid}"].text().strip()
            lp = pp[f"lp_{fid}"].text().strip()
            notch = pp[f"notch_{fid}"].currentText()
            method = pp[f"filt_method_{fid}"].currentText()
            method_short = "FIR" if "FIR" in method else "IIR"

            def _to_num(s):
                try:
                    return float(s) if s else 0.0
                except ValueError:
                    return 0.0

            bits = []
            # Skip the band piece entirely when neither bound is
            # set (or both are 0) — "0–0 Hz" / "—–— Hz" carries no
            # information.
            if _to_num(hp) > 0 or _to_num(lp) > 0:
                bits.append(f"{hp or '—'}–{lp or '—'} Hz")
            if notch and notch != "None":
                bits.append(f"notch {notch}")
            bits.append(method_short)
            lbl.setText(", ".join(bits))

        pp[f"hp_{filter_id}"].textChanged.connect(_update_filt_info)
        pp[f"lp_{filter_id}"].textChanged.connect(_update_filt_info)
        pp[f"notch_{filter_id}"].currentTextChanged.connect(
            _update_filt_info)
        pp[f"filt_method_{filter_id}"].currentTextChanged.connect(
            _update_filt_info)
        _update_filt_info()
        # Now that the eye button exists, drop the summary label and
        # [- +] in just before it (header reads
        # "... <summary> − + 👁 ↑ ↓ ?").
        hdr = grp._header_layout
        hdr.insertWidget(hdr.indexOf(grp._view_btn), filt_info)
        hdr.insertWidget(hdr.indexOf(grp._view_btn), minus_btn)
        hdr.insertWidget(hdr.indexOf(grp._view_btn), plus_btn)
        # Track in the per-id list so collect/populate/[+] can find
        # every active filter panel.
        if not hasattr(self, "_filter_widgets"):
            self._filter_widgets = []
        self._filter_widgets.append((filter_id, grp))
        # Refresh minus-button visibility now that the panel is
        # registered (the first panel keeps its [-] hidden, others
        # follow the reorder toggle).
        self._refresh_filter_minus_visibility()
        return grp, step_key

    def _refresh_filter_minus_visibility(self):
        """Show [-] on every Filters panel except the first one,
        gated on the Config-tab reorder toggle.  Called whenever
        ``_filter_widgets`` changes (add / remove) and from
        ``_on_allow_reorder_toggled``."""
        reorder_on = (
            getattr(self, "_allow_reorder_check", None) is not None
            and self._allow_reorder_check.isChecked())
        for idx, (_fid, grp) in enumerate(
                getattr(self, "_filter_widgets", [])):
            minus = getattr(grp, "_minus_btn", None)
            if minus is None:
                continue
            minus.setVisible(reorder_on and idx > 0)

    def _remove_filter_panel(self, filter_id):
        """[-] handler — drop *filter_id*'s panel from the GUI.

        Removes the panel from ``_filter_widgets`` and
        ``_step_widgets``, deletes the per-id widget keys from
        ``_pp``, marks the CollapsibleStep for deletion, and
        repacks the layout.  Refuses to remove the first panel
        (there's always at least one filter slot).
        """
        widgets = getattr(self, "_filter_widgets", [])
        if not widgets or widgets[0][0] == filter_id:
            return  # First panel — protected.
        idx = next(
            (i for i, (fid, _) in enumerate(widgets) if fid == filter_id),
            None)
        if idx is None:
            return
        _fid, grp = widgets.pop(idx)
        # Drop from _step_widgets.
        step_key = f"filtering:{filter_id}"
        self._step_widgets = [
            (k, w) for k, w in self._step_widgets if k != step_key]
        # Clear per-id widget refs from _pp so collect/populate
        # don't see ghost entries.
        suffix = f"_{filter_id}"
        save_key = f"save_filtering:{filter_id}"
        keys_to_drop = [
            k for k in list(self._pp.keys())
            if k.endswith(suffix) or k == save_key
            or k == f"_filt_grp_{filter_id}"]
        for k in keys_to_drop:
            self._pp.pop(k, None)
        # Detach the panel widget and schedule it for deletion.
        grp.setParent(None)
        grp.deleteLater()
        # Repack the layout in the new order and refresh [-]
        # visibility (the new "first" panel — if the deleted one
        # was second — should now hide its [-]).
        self._repack_preproc_steps()
        self._refresh_filter_minus_visibility()

    def _duplicate_filter_panel(self, source_filter_id):
        """[+] handler — clone *source_filter_id* into a new panel.

        New panel is inserted right after the source in the layout
        and in ``_step_widgets``, with a freshly-generated id and a
        copy of the source's current widget values.  Visible from
        the source's [+] button when reorder mode is on.
        """
        # Capture current values from the source panel so the clone
        # starts with the same settings (one user click → ready-to-edit
        # duplicate, not a defaulted blank).
        src_cfg = self._collect_filter_block_cfg(source_filter_id)
        new_grp, new_step_key = self._build_filter_panel(None, src_cfg)
        # Find the source's position in _step_widgets and insert
        # the new entry right after it.
        src_step_key = f"filtering:{source_filter_id}"
        idx = next(
            (i for i, (k, _) in enumerate(self._step_widgets)
             if k == src_step_key), None)
        if idx is None:
            self._step_widgets.append((new_step_key, new_grp))
        else:
            self._step_widgets.insert(idx + 1, (new_step_key, new_grp))
        # Repack the layout so widgets appear in the new order.
        self._repack_preproc_steps()
        # Apply current allow_reorder visibility to the new arrows /
        # constraints + ensure save toggles are visible if relevant.
        self._on_allow_reorder_toggled(
            self._allow_reorder_check.isChecked())

    def _collect_filter_block_cfg(self, filter_id):
        """Read the current widget values for one filter panel into
        a config dict (HP, LP, notch, method, show_filt, plot_filt,
        save)."""
        pp = self._pp
        notch_str = self._cmb(pp, f"notch_{filter_id}", "None")
        notch_freq = (50 if "50" in notch_str
                      else 60 if "60" in notch_str else 0)
        method_str = self._cmb(pp, f"filt_method_{filter_id}",
                               "IIR (Butterworth)")
        # Save toggle is registered by _add_save_checkbox at
        # _pp[f"save_{step_key}"]; for filters step_key is
        # "filtering:<id>".
        save_btn = pp.get(f"save_filtering:{filter_id}")
        save_flag = save_btn.isChecked() if save_btn is not None else False
        # 0 = filter off (per channels_and_signal._filter_signal
        # contract); fallback default must be 0 so an empty field
        # disables the filter rather than falling through to e.g. 0.5.
        return {
            "highpass_freq": self._num(pp, f"hp_{filter_id}", 0),
            "lowpass_freq":  self._num(pp, f"lp_{filter_id}", 0),
            "notch_freq":    notch_freq,
            "method":        "fir" if "FIR" in method_str else "iir",
            "show_filt":     self._chk(pp, f"show_filt_{filter_id}", False),
            "plot_filt":     self._chk(pp, f"save_filt_{filter_id}", False),
            "save":          save_flag,
        }

    def _add_step_actions(self, group_widget, step_name):
        """Cache the step's status label in self._pp[f'_{step}_status'].

        Was previously also wiring View buttons; those were removed.
        """
        w = group_widget
        status = w._status_label if isinstance(w, CollapsibleStep) else None
        self._pp[f"_{step_name}_status"] = status

    def _add_save_checkbox(self, step_widget, step_key, cfg=None,
                           label=None, tooltip=None, default=None,
                           forced=False):
        """Add a 🗄️ drawer 'Save' toggle to a preprocessing step's header.

        For standard steps in ``_SAVE_CHECKBOX_MAP`` the call is just
        ``self._add_save_checkbox(panel, "trim", cfg=cfg)`` — the label,
        tooltip, and default are looked up from the map.  For special
        steps pass label/tooltip/default explicitly.  Pass
        ``forced=True`` for a checked, disabled toggle (MP
        decomposition).

        The widget is a checkable QPushButton (with a file-cabinet
        / drawer icon, U+1F5C4) sitting in the step's header row next
        to the eye button, not a QCheckBox in the body.  Its
        ``.isChecked()`` / ``.setChecked()`` API is identical, so
        ``_collect_config`` and ``_populate_vars`` don't need to
        change.
        """
        meta = self._SAVE_CHECKBOX_MAP.get(step_key)
        if meta is not None:
            section, def_label, def_tooltip = meta
            label = label or def_label
            tooltip = tooltip or def_tooltip
            if default is None and cfg is not None:
                default = cfg.get(section, {}).get("save", False)
        if default is None:
            default = False
        initial = True if forced else default
        # Two-line tooltip: short label + full description, so hovering
        # the icon reveals both the "what" and the file-path "how".
        tip_parts = [label or "Save step output"]
        if tooltip:
            tip_parts.append(tooltip)
        btn = step_widget.enable_save_toggle(
            tooltip="\n\n".join(tip_parts), checked=initial)
        if forced:
            btn.setEnabled(False)
        self._pp[f"save_{step_key}"] = btn
        # NB: the save toggle is intentionally NOT auto-synced to
        # the step's enable checkbox.  Earlier the auto-sync would
        # cascade through `_toggle_details` (which checks the
        # enable box on click-to-expand) and silently activate
        # snapshot saving just from peeking inside a panel.  Save
        # is now strictly user-driven on the GUI side; the eye-
        # click force-save still works on its own (the truncated-
        # pipeline runner sets cfg[section]["save"] = True
        # directly).
        return btn

    @Slot(str, str, str)
    def _on_step_finished(self, step_name, fif_path, error):
        """Handle background step completion."""
        status = self._pp.get(f"_{step_name}_status")
        if error:
            if status:
                status.setText(f"Error: {error}")
        else:
            self._step_fif_paths[step_name] = fif_path
            if status:
                status.setText("Done")

    # ── Per-step save checkbox map ───────────────────────────────────
    #
    # Single source of truth for the per-step Save checkboxes.
    # Drives _add_save_checkbox(), _collect_config(), and _populate_vars().
    # The flag is stored as ``cfg[section]["save"]``.
    _SAVE_CHECKBOX_MAP = {
        "trim": (
            "trim", "Save trimmed signal",
            "Save the trimmed continuous signal as "
            "<filename>-trimmed-raw.fif."),
        "select": (
            "choosing_channels", "Save signal after channel drop",
            "Save the signal with dropped channels removed as\n"
            "  <filename>-selected-raw.fif."),
        "bad_channels": (
            "bad_channels", "Save bad-channel-marked signal",
            "Save the bad-channel-marked continuous signal as\n"
            "  <filename>-bad-marked-raw.fif.\n"
            "Per-channel detection plots (band-power,\n"
            "correlation) are controlled separately by the\n"
            "'Save detection plots' checkbox in the panel body."),
        # "montage" intentionally omitted — _STEP_SAVE_MAP excludes
        # montage (set_montage is metadata-only), so a save toggle
        # would write nothing.  Build site for the Montage panel
        # also skips _add_save_checkbox.
        "reference": (
            "reference", "Save signal after re-referencing",
            "Save the signal after re-referencing as\n"
            "  <filename>-rereferenced-raw.fif."),
        "resample": (
            "resample", "Save resampled signal",
            "Save the signal after resampling as\n"
            "  <filename>-resampled-raw.fif."),
        "filtering": (
            "filters", "Save filtered signal",
            "Save the signal after filtering as\n"
            "  <filename>-filtered-raw.fif."),
        "ica": (
            "ICA_EOG", "Save ICA-cleaned signal",
            "Save the cleaned continuous signal as\n"
            "  <filename>-ica-cleaned-raw.fif.\n"
            "Component topomaps, the classification table, the\n"
            "fitted ICA model, and the audit report are controlled\n"
            "separately by the 'Save components plot and table'\n"
            "checkbox in the ICA panel body."),
        "artifacts": (
            "artifacts", "Save EEG-artifact-marked signal",
            "Save the EEG-artifact-marked continuous signal as\n"
            "  <file>-eeg-artifacts-marked-raw.fif.\n"
            "Per-channel detection plots (amplitude / slope /\n"
            "outlier / muscle) are controlled separately by the\n"
            "'Save detection plots' checkbox in the panel body."),
        "gaze": (
            "gaze", "Save gaze-marked signal",
            "Save the gaze-marked continuous signal as\n"
            "  <file>-gaze-marked-raw.fif.\n"
            "The BrainTech .tag file for Svarog viewing is\n"
            "controlled separately by the 'Save Svarog .tag\n"
            "file' checkbox in the panel body.  The review-\n"
            "window JSON is always written regardless of\n"
            "either flag."),
        "mp_filter": (
            "mp_filter", "Save MP-filtered signal",
            "Save the signal after MP nonlinear filtering as\n"
            "  <filename>-mp_filter-raw.fif."),
    }

    # ── MP Decomposition (standalone run) ──────────────────────────────

    def _run_mp_decomposition(self):
        """Run the pipeline truncated at MP decomposition.

        Thin wrapper around the unified runner: validates empi, builds
        a scratch config, force-enables ``mp_decomposition`` in the
        truncated step_order (so the button works even if MP isn't in
        the user's permanent pipeline), and dispatches to
        ``_run_truncated_pipeline`` with ``post_action="mp_decomp_done"``
        so the post-success handler in ``_on_pipeline_finished`` updates
        the panel's ``mp_run_status`` label, refreshes the book panels,
        and caches the resulting book path.

        Inherits everything the One True Path provides: preflight,
        parallelism, hash pinning, cancel event, manual-review hooks,
        output-dir routing, log queue.  Cancel is via the standard
        Run-tab Stop button (the in-panel Cancel was removed when
        the dedicated MP UI consolidated to the Run tab).
        """
        empi = getattr(self, "_empi_edit", None)
        empi_path = empi.text().strip() if empi else ""
        if not empi_path or not os.path.isfile(empi_path):
            self._msg_info(
                "empi not found",
                "Set the empi executable path in the Config tab.")
            return
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info("No input",
                           "Select a valid input file first.")
            return

        # Build the scratch config and force-enable mp_decomposition.
        # Mirrors the bad_channels Run-and-check pattern so the button
        # works even when the user has the panel disabled.
        import copy
        cfg = copy.deepcopy(self._collect_config())
        preproc_cfg = cfg.setdefault("preprocessing", {})
        step_order = list(preproc_cfg.get("step_order", []))
        if "mp_decomposition" not in step_order:
            step_order.append("mp_decomposition")
            preproc_cfg["step_order"] = step_order

        # Indicator in the panel itself ("Running...") so the user has a
        # visible "I clicked it" cue even before they look at the Run tab.
        pp = self._pp
        if "mp_run_status" in pp:
            pp["mp_run_status"].setText("Running...")

        self._run_truncated_pipeline(
            "mp_decomposition", "MP Decomposition",
            post_action="mp_decomp_done",
            cfg_override=cfg)

    @Slot(int)
    def _on_mp_decomp_progress(self, pct):
        """Forward MP per-iteration progress to the Run-tab bar.

        Wired by ``_launch_pipeline`` via the ``mp_progress`` manual
        hook — ``_step_mp_decomposition`` reads it from
        ``manual_hooks["mp_progress"]`` and passes it as
        ``progress_callback`` to ``mp_decompose``.  MP is the only
        step with fine-grained progress; for everything else the bar
        stays at the stage-indicator granularity.

        Stash the percent on ``self`` and re-run
        ``_update_overall_progress`` so the value is folded into the
        coarse stage-transition arithmetic (avoids the bar fighting
        between the two writers and the resulting "flashing around
        50%" the user reported).
        """
        self._mp_decomp_pct = int(pct)
        self._update_overall_progress()

    # ── Step worker functions ─────────────────────────────────────────

    def _read_and_mark(self, input_path, prepare_config=False,
                       require_events=True):
        """Read *input_path* and build the event_id dict (no signal touch).

        Step workers that need a trimmed / rest-marked signal must
        call ``_trim_signal`` and ``_maybe_add_rest_markers`` themselves
        in the same order as the main pipeline preamble.

        Parameters
        ----------
        require_events : bool, default True
            When False, ``_build_event_dict`` failures (e.g. no events
            selected in epochs mode) yield an empty ``tags`` dict
            instead of raising.  Bad-channel detection and other
            steps that don't actually use events should pass False so
            the user can run them on a file before deciding which
            events to analyse.
        """
        from ide4eeg.input.input import read_file
        from ide4eeg.preprocessing.channels_and_signal import _build_event_dict
        cfg = self._collect_config()
        if prepare_config:
            from ide4eeg.input.input import check_and_prepare_config
            cfg = check_and_prepare_config(cfg)
        signal, events = read_file(input_path)
        if signal is None:
            raise RuntimeError("Could not read the input file.")
        cfg["sfreq"] = signal.info["sfreq"]
        try:
            tags = _build_event_dict(cfg, events)
        except ValueError:
            if require_events:
                raise
            tags = {}
        return signal, tags, cfg

    def _trimmed_input_for_svarog(self):
        """Return a (path, cleanup) pair for launching Svarog on the
        TRIMMED input segment instead of the full raw file.

        Two paths, both write inside the project output directory
        (no system-temp leakage):

        * **Hot path** — when ``saved_steps/<base>-trimmed-raw.fif``
          already exists with a matching ``[cfg:<hash>]`` stamp,
          reuse it directly.

        * **Cold path** — read the input (reusing
          ``self._cached_signal`` when available), crop to
          ``[trim_start, trim_end]``, stamp with the trim hash, and
          save to the same canonical snapshot path.  Subsequent
          Svarog clicks then hit the hot path automatically.

        When trim is disabled, the panel isn't built, no input is
        set, or the crop fails, returns the original input path with
        a no-op cleanup.  Channel names are preserved verbatim so any
        ``.tag`` files Svarog writes back translate unchanged.

        Returns
        -------
        (str, callable)
            ``(svarog_input_path, cleanup_fn)``.  ``cleanup_fn`` is a
            no-op in every branch — kept for API symmetry with
            earlier signature; safe to call exactly once.
        """
        inp = self._input_edit.text().strip()
        noop = lambda: None  # noqa: E731 — readable inline default
        if not inp or not os.path.isfile(inp):
            return inp, noop

        trim_on, trim_start, trim_end = self._trim_state()
        if not trim_on or (trim_start <= 0 and trim_end is None):
            return inp, noop

        # Reuse the on-disk trim snapshot when it matches the current
        # trim config (same ``[cfg:<hash>]`` marker the eye-button
        # uses), saving a redundant read+crop+save on every Svarog
        # launch.  Walk every plausible preproc dir — the runner can
        # write to a timestamped subdir (overwrite_output=False) or
        # under a custom output_path — so a fixed ``_fallback`` lookup
        # would silently miss reusable snapshots (audit finding #7,
        # 2026-05-02).
        fname = os.path.basename(inp)
        while "." in fname:
            fname = os.path.splitext(fname)[0]
        snap_rel = os.path.join(
            "saved_steps", f"{fname}-trimmed-raw.fif")
        snap = self._find_in_preproc_dirs(snap_rel)
        if snap:
            live_cfg = self._collect_config()
            expected = _compute_step_hash(
                "trim", live_cfg, effective_step_order(live_cfg))
            if expected and self._fif_matches_hash(snap, expected):
                logging.info(
                    "Svarog: reusing existing trim snapshot %s", snap)
                return snap, noop
        # Cold-path write target — keep using `_fallback_preproc_path`
        # since the cold-path snapshot is a Svarog-launch cache, not a
        # runner-produced artefact; the hot-path probe above will pick
        # it up on subsequent clicks.
        snap = os.path.join(
            self._fallback_preproc_path(),
            "saved_steps", f"{fname}-trimmed-raw.fif")

        # Build the cropped snapshot.  Reuse the cached signal when
        # available (BrainTech path); otherwise read from disk.  Write
        # to the same canonical path the hot path checks for above
        # (``saved_steps/<base>-trimmed-raw.fif``) so that subsequent
        # Svarog clicks pick it up directly.  Stamp the description
        # with ``[cfg:<hash>]`` so that hot-path freshness check sees
        # a hash match.  No cleanup needed — the file lives in the
        # project output directory alongside the rest of the
        # snapshots and is GC'd by the same eventual mechanism.
        try:
            cached = getattr(self, "_cached_signal", None)
            if cached is not None:
                raw = cached.copy()
            else:
                from ide4eeg.input.input import read_file
                raw, _events = read_file(inp)
                if raw is None:
                    raise RuntimeError(
                        "read_file returned no signal")
            duration = raw.times[-1] if len(raw.times) else 0.0
            tmin = max(0.0, float(trim_start))
            tmax = (min(float(trim_end), duration)
                    if trim_end is not None else None)
            if tmax is not None and tmax <= tmin:
                raise ValueError(
                    f"trim_end ({tmax}) must be > trim_start ({tmin})")
            cropped = raw.copy().crop(tmin=tmin, tmax=tmax)
            # Stamp with the trim hash so the next hot-path check
            # picks it up (avoids a redundant re-crop on every click).
            from ide4eeg.preprocessing.preprocessing import (
                _stamp_signal_description)
            live_cfg = self._collect_config()
            stamp_hash = _compute_step_hash(
                "trim", live_cfg, effective_step_order(live_cfg))
            if stamp_hash:
                _stamp_signal_description(cropped, "trim", stamp_hash)
            os.makedirs(os.path.dirname(snap), exist_ok=True)
            cropped.save(snap, overwrite=True, verbose=False)
        except Exception as e:
            logging.warning(
                "Svarog: trim crop failed (%s) — falling back to "
                "untrimmed input", e)
            return inp, noop

        te_disp = (f"{tmax:.1f}" if tmax is not None else "end")
        logging.info(
            "Svarog: wrote trimmed segment [%.1f, %s] s to %s",
            tmin, te_disp, snap)

        return snap, noop

    def _mark_dropped_in_svarog(self):
        """Open the input signal in Svarog so the user can mark channels
        to drop, then sync the result back into the Drop Channels panel.

        Opens Svarog with ``--select-mode bad_channels``, preselecting
        channels currently unchecked in the panel.  When the user
        saves, reads the output tag file and updates the panel:
        channels in the tag are unchecked (= will be dropped),
        everything else stays checked.  Cancel leaves the panel
        untouched.
        """
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info("No input file",
                           "Select a valid input signal first.")
            return
        panel = self._pp.get("sel_channel_panel")
        if panel is None or not panel._checkboxes:
            self._msg_info(
                "No channels",
                "Channel list isn't loaded yet — open a signal "
                "and let it scan the channels first.")
            return
        if self._svarog_jar is None:
            self._svarog_jar = _find_svarog_jar()
        jar = self._svarog_jar
        if not jar or not os.path.isfile(jar):
            self._msg_info(
                "Svarog not found",
                "Locate a Svarog jar via the Input tab's "
                "\"Open in Svarog\" button first.")
            return
        if not self._svarog_select_mode_supported("bad_channels"):
            self._msg_info(
                "Svarog too old",
                "This Svarog jar doesn't support "
                "--select-mode bad_channels.\n"
                "Install a newer Svarog jar.")
            return

        all_chs = [name for name, _ in panel._checkboxes]
        dropped = [name for name, cb in panel._checkboxes
                   if not cb.isChecked()]

        # Trim-aware: show Svarog the same segment the pipeline will
        # process.  cleanup() removes the temp FIF after Svarog exits;
        # falls back to the raw input + no-op cleanup when trim is off
        # or cropping fails.  Channel names are preserved by crop, so
        # the .tag round-trip stays consistent.
        svarog_input, cleanup = self._trimmed_input_for_svarog()

        self._status.showMessage("Launching Svarog...", 0)

        def worker():
            import shutil
            from ide4eeg.preprocessing.svarog_review import (
                _write_channel_tag_file, _read_channel_tag_file)
            from ide4eeg._appcds import appcds_flags
            work_dir = tempfile.mkdtemp(prefix="svarog_drop_")
            try:
                output_path = os.path.join(work_dir, "selected-drops.tag")
                cmd = ["java", *appcds_flags(jar),
                       "-jar", jar, svarog_input,
                       "--select-mode", "bad_channels",
                       "--output", output_path,
                       "--nosplash"]
                if dropped:
                    preselect_path = os.path.join(work_dir, "preselect.tag")
                    _write_channel_tag_file(preselect_path, dropped, all_chs)
                    cmd.extend(["--preselect", preselect_path])
                self._signals.pipeline_log.emit(
                    f"Svarog drop-channel review: launching with "
                    f"{len(dropped)} preselected", "INFO")
                try:
                    result = subprocess.run(cmd, timeout=3600, check=False)
                except (subprocess.TimeoutExpired, OSError) as e:
                    self._signals.pipeline_log.emit(
                        f"Svarog launch failed: {e}", "WARNING")
                    return
                if result.returncode != 0:
                    self._signals.pipeline_log.emit(
                        f"Svarog returned code {result.returncode} — "
                        f"treating as cancel; drop channels unchanged",
                        "INFO")
                    return
                if not os.path.isfile(output_path):
                    self._signals.pipeline_log.emit(
                        f"Svarog wrote no output tag at {output_path}",
                        "WARNING")
                    return
                try:
                    new_drops = _read_channel_tag_file(output_path)
                except Exception as e:
                    self._signals.pipeline_log.emit(
                        f"Failed to parse Svarog output: {e}",
                        "WARNING")
                    return
                # Filter to channels that actually exist in the panel
                # (defence against Svarog writing names that drift).
                known = set(all_chs)
                kept = [d for d in new_drops if d in known]
                dropped_unknown = [d for d in new_drops if d not in known]
                if dropped_unknown:
                    self._signals.pipeline_log.emit(
                        f"Svarog returned unknown channel names "
                        f"(ignored): {dropped_unknown}", "WARNING")
                self._signals.pipeline_log.emit(
                    f"Svarog drop-channel review returned "
                    f"{len(kept)} channel(s) to drop: "
                    f"{kept if kept else '(none)'}", "INFO")
                # Marshal to GUI thread via Qt signal — QTimer.singleShot
                # from a worker thread schedules on the calling thread's
                # event loop (which doesn't exist), so it never fires.
                self._signals.drop_selection_from_svarog.emit(kept)
            finally:
                shutil.rmtree(work_dir, ignore_errors=True)
                cleanup()

        threading.Thread(target=worker, daemon=True).start()

    def _apply_drop_selection(self, dropped_channels):
        """Update the Drop Channels panel to match a list of dropped
        channel names.  Listed channels are unchecked (dropped);
        everything else is checked (kept).  Runs on the GUI thread.
        """
        panel = self._pp.get("sel_channel_panel")
        if panel is None:
            return
        dropped_set = set(dropped_channels)
        panel._bulk_toggle = True
        try:
            for name, cb in panel._checkboxes:
                cb.setChecked(name not in dropped_set)
        finally:
            panel._bulk_toggle = False
        panel._update_count()
        self._status.showMessage(
            f"Drop channels updated from Svarog: "
            f"{len(dropped_channels)} marked for drop", 4000)

    def _view_bad_channels(self):
        """Run preprocessing through the bad-channels step and show results.

        Thin wrapper around the unified runner: build a scratch
        config, force the ``bad_channels`` step into ``step_order``
        if it's currently disabled (the panel might be off but the
        user still wants to preview detected bads), and dispatch to
        ``_run_truncated_pipeline`` with ``post_action="bad_channels_label"``
        so the result lands in the panel's body label + header
        readout instead of opening the before/after viewer.

        Inherits everything the One True Path provides: preflight
        checks, parallelism config, hash pinning, cancel event,
        manual-review hook plumbing, output-dir routing, log queue.
        """
        # Cached short-circuit — when a previous run has already
        # populated ``info["bads"]``, just surface those names
        # without re-running the pipeline.
        signal = self._cached_signal
        if signal is not None and signal.info.get("bads"):
            self._msg_info(
                "Bad Channels",
                f"Bad channels: {', '.join(signal.info['bads'])}")
            return
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info(
                "No results",
                "Load a signal and run detection first.")
            return
        self._status.showMessage("Detecting bad channels...", 0)

        # Build the scratch config and force-enable bad_channels.
        # _run_truncated_pipeline rejects targets that aren't in
        # step_order, but "Run and check" should work even when the
        # user has the Bad Channels panel disabled — they're asking
        # for a preview, not committing the step to the pipeline.
        import copy
        cfg = copy.deepcopy(self._collect_config())
        preproc_cfg = cfg.setdefault("preprocessing", {})
        step_order = list(preproc_cfg.get("step_order", []))
        if "bad_channels" not in step_order:
            # Insert before the first step that depends on
            # ``info["bads"]`` (montage / reference / filter / ICA);
            # falls back to "after preamble" by appending if none of
            # those are present in the order.
            insert_at = len(step_order)
            for i, name in enumerate(step_order):
                if name in ("montage", "reference", "filtering", "ica"):
                    insert_at = i
                    break
            step_order.insert(insert_at, "bad_channels")
            preproc_cfg["step_order"] = step_order
        # Make sure the unified runner doesn't filter the step back
        # out via the Preprocessing-tab enable flags (the panel
        # checkbox state).
        preproc_cfg.setdefault("enabled_steps", {})["bad_channels"] = True

        self._run_truncated_pipeline(
            "bad_channels", "Bad Channels",
            post_action="bad_channels_label",
            cfg_override=cfg)

    _STEP_LABELS = {
        "trim": "Trim signal",
        "select": "Drop channels",
        "bad_channels": "Bad channels",
        "montage": "Montage",
        "reference": "Reference",
        "resample": "Resample",
        "filtering": "Filters",
        "ica": "ICA",
        "artifacts": "EEG artifacts",
        "mp_decomposition": "MP decomposition",
        "mp_filter": "MP filter",
        "gaze": "Gaze",
    }

    def _view_step_result(self, step_key, *, is_reentry=False):
        """Open the before / after snapshots for a preprocessing step.

        The "after" file is ``<base>-<suffix>-raw.fif`` written by
        the step's per-step Save checkbox (suffix comes from
        ``_STEP_SAVE_MAP``).  The "before" file is the nearest
        enabled preceding step with a save checkbox — or, when this
        step is the first enabled step in the pipeline, the user's
        original input signal.

        Clicking the eye always flips the 🗄️ save toggles on for
        this step and its preceding step — so the snapshots persist
        across runs and the user's next manual Run also saves them.
        Then:

          - If both snapshots already exist on disk, open them in the
            Svarog split view (``--split-signal``) or two MNE windows
            as a fallback.
          - Otherwise, auto-run a truncated pipeline to produce the
            snapshots and open the viewer once they land on disk.

        The EEG-artifacts step skips the before/after split (the
        pre-detection signal isn't useful — the user wants to see
        what the detectors flagged) — single window with annotations
        colored by type instead.
        """
        gui_to_pipeline = self._GUI_TO_PIPELINE_STEPS
        # Phase 2 multi-instance: split the ":<id>" suffix off so
        # _STEP_LABELS / _GUI_TO_PIPELINE_STEPS / _STEP_SAVE_MAP
        # lookups (all keyed by base step name) succeed.  The id
        # is reattached to pipeline names so the eventual snapshot
        # filename includes it.
        base_key, step_id = step_key.partition(":")[0], step_key.partition(":")[2]
        single_view = base_key == "artifacts"
        step_label = (self._STEP_LABELS.get(step_key)
                      or self._STEP_LABELS.get(base_key, step_key))

        # Resolve the target step's pipeline save-map entry.  The
        # GUI key may map to several pipeline names (e.g. "filtering"
        # → ["filtering"]); pick the last one that has a
        # _STEP_SAVE_MAP entry since that's the final saved output.
        pipeline_names = (gui_to_pipeline.get(step_key)
                          or gui_to_pipeline.get(base_key, [step_key]))
        target_pipeline = next(
            (p for p in reversed(pipeline_names)
             if p.partition(":")[0] in _STEP_SAVE_MAP),
            None)
        if target_pipeline is None:
            self._msg_info(
                "No snapshot for this step",
                f"'{step_label}' doesn't produce a saveable snapshot.")
            return

        keys_and_grps = list(self._step_widgets)
        keys = [k for k, _ in keys_and_grps]
        if step_key not in keys:
            self._msg_info(
                f"{step_label} not in pipeline",
                f"The {step_label} step isn't in your current step order.")
            return
        step_idx = keys.index(step_key)

        def _is_step_enabled(grp):
            """True if the CollapsibleStep will actually run."""
            try:
                return bool(grp.isChecked())
            except Exception:
                return True  # non-checkable steps are always on

        # Disabled steps, GUI-only rows (gaze, segment_rejection),
        # and steps whose snapshot doesn't produce a Raw FIF
        # (mp_decomposition writes a .db book, montage is metadata-only)
        # are all skipped — the eye view needs a -raw.fif on disk for
        # the BEFORE pane.  Picking mp_decomposition here used to land
        # before_path=None and trigger an infinite truncated-pipeline
        # loop on every eye click for mp_filter.
        preceding_key = None
        for i in range(step_idx - 1, -1, -1):
            k, grp = keys_and_grps[i]
            if f"save_{k}" not in self._pp:
                continue
            if not _is_step_enabled(grp):
                continue
            base_k = k.partition(":")[0]
            pipe_names = (self._GUI_TO_PIPELINE_STEPS.get(k)
                          or self._GUI_TO_PIPELINE_STEPS.get(base_k, []))
            if not any(p.partition(":")[0] in _STEP_SAVE_MAP
                       for p in pipe_names):
                continue
            preceding_key = k
            break

        # Clicking the eye commits the user to saving the pair — flip
        # the 🗄️ toggles on for this step and its preceding step, so
        # whenever the pipeline next runs (either via the auto-run
        # path below or a future manual Run), the snapshots persist.
        # Visible to the user: the icons light up.
        for k in (step_key, preceding_key):
            if k is None:
                continue
            btn = self._pp.get(f"save_{k}")
            if btn is not None and not btn.isChecked():
                btn.setChecked(True)
        # Single-view artifacts via Svarog needs a .tag on disk —
        # without the flip the dispatcher silently falls back to the
        # MNE viewer because no .tag was ever produced.  Don't flip
        # when Svarog won't be used: the .tag would be wasted.
        if single_view and self._svarog_available():
            tag_btn = self._pp.get("art_save_tag")
            if tag_btn is not None and not tag_btn.isChecked():
                tag_btn.setChecked(True)
        # Also enable the step itself when the user has its checkbox
        # off — otherwise _run_truncated_pipeline pins a hash with the
        # step in step_order, but the re-entry hash recompute uses the
        # live GUI state (step still excluded), which mismatches the
        # stamped snapshot and trips the loop-guard "still stale"
        # warning. Flipping the checkbox keeps the two hashes aligned.
        target_grp = next(
            (g for k, g in keys_and_grps if k == step_key), None)
        if target_grp is not None:
            try:
                if not target_grp.isChecked():
                    target_grp.setChecked(True)
            except AttributeError:
                pass  # non-checkable step

        def _suffix(gui_key):
            """GUI key → save-file suffix via _GUI_TO_PIPELINE_STEPS.

            Phase 2: ``"filtering:<id>"`` keys produce
            ``"filtered-<id>"`` suffixes so the snapshot filename
            matches what ``_save_step_signal_if_requested`` writes
            on the pipeline side.
            """
            base, _, sid = gui_key.partition(":")
            pipeline_names = (gui_to_pipeline.get(gui_key)
                              or gui_to_pipeline.get(base, [gui_key]))
            for pipe_name in reversed(pipeline_names):
                pipe_base = pipe_name.partition(":")[0]
                entry = _STEP_SAVE_MAP.get(pipe_base)
                if entry is not None:
                    base_suffix = entry[1]
                    return f"{base_suffix}-{sid}" if sid else base_suffix
            return None

        # Input-file basename (strip all extensions — matches the
        # pipeline's naming convention).
        inp = self._input_edit.text().strip()
        if not inp or not os.path.isfile(inp):
            self._msg_info(
                "No input file",
                "Select an input signal on the Input tab first.")
            return
        fname = os.path.basename(inp)
        while "." in fname:
            fname = os.path.splitext(fname)[0]

        # Find the preproc dir where the after-snapshot lives.  Falls
        # back to the legacy `_fallback_preproc_path` so the
        # truncated-pipeline branch below has a directory to log /
        # validate against when the snapshot doesn't exist yet.  See
        # `_resolve_preproc_dirs` for the multi-root walk that handles
        # output_path / non-overwrite-timestamp layouts.
        after_suffix = _suffix(step_key)
        after_rel = (
            os.path.join("saved_steps", f"{fname}-{after_suffix}-raw.fif")
            if after_suffix else None)
        after_path = (
            self._find_in_preproc_dirs(after_rel)
            if after_rel else None) or os.path.join(
                self._fallback_preproc_path(), after_rel or "")
        # Pin `saved` to whichever dir produced after_path so before
        # comes from the same run — avoids cross-mixing snapshots from
        # different timestamped runs.
        saved = os.path.dirname(after_path) if after_path else ""

        before_is_input = preceding_key is None
        if before_is_input:
            before_path = inp
        else:
            before_suffix = _suffix(preceding_key)
            before_path = (
                os.path.join(saved, f"{fname}-{before_suffix}-raw.fif")
                if before_suffix and saved else None)

        # Freshness check: if both files exist AND each one's
        # embedded per-step hash matches the corresponding step's
        # current cumulative hash, just open the viewer.  Otherwise
        # (missing OR stale) fall through to the auto-run path
        # below.  The "before" file is the user's input itself when
        # ``before_is_input`` — never stale.
        #
        # Per-step hashes mean a downstream config edit (say,
        # ``epochs.start_offset`` consumed only by cut_segments)
        # leaves earlier-step snapshots fresh — the eye-button view
        # opens immediately instead of triggering a full rerun.
        try:
            cfg_for_hash = self._collect_config()
            step_order_for_hash = effective_step_order(cfg_for_hash)
        except Exception:
            cfg_for_hash = None
            step_order_for_hash = []
        # Whole-config hash (legacy fallback) — used when the
        # per-step computation can't produce a digest, so existing
        # snapshots stamped under that regime still match.
        whole_cfg_hash = None
        if cfg_for_hash is not None:
            try:
                whole_cfg_hash = _compute_preprocessing_hash(
                    cfg_for_hash)
            except Exception:
                whole_cfg_hash = None

        # Pipeline tokens for the after / before snapshots — same
        # discovery logic as ``_suffix`` above but returning the
        # full ``base[:id]`` form ``_compute_step_hash`` expects.
        def _pipeline_token(gui_key):
            base, _, sid = gui_key.partition(":")
            names = (gui_to_pipeline.get(gui_key)
                     or gui_to_pipeline.get(base, [gui_key]))
            for pipe_name in reversed(names):
                pipe_base = pipe_name.partition(":")[0]
                if pipe_base in _STEP_SAVE_MAP:
                    return f"{pipe_base}:{sid}" if sid else pipe_base
            return None

        after_token = _pipeline_token(step_key)
        before_token = (None if before_is_input
                        else _pipeline_token(preceding_key))

        def _step_hash(token):
            """Per-step hash; falls back to whole-config hash when
            per-step computation isn't applicable (e.g. token isn't
            in the current step_order)."""
            if cfg_for_hash is None:
                return None
            if token is not None:
                try:
                    h = _compute_step_hash(
                        token, cfg_for_hash, step_order_for_hash)
                    if h:
                        return h
                except Exception:
                    pass
            return whole_cfg_hash

        after_hash = _step_hash(after_token)
        before_hash = (None if before_is_input
                       else _step_hash(before_token))

        after_fresh = (
            os.path.isfile(after_path)
            and after_hash is not None
            and self._fif_matches_hash(after_path, after_hash))
        before_fresh = (
            before_is_input
            or (before_path
                and os.path.isfile(before_path)
                and before_hash is not None
                and self._fif_matches_hash(before_path, before_hash)))
        if single_view:
            if after_fresh:
                self._dispatch_single_view(
                    after_path, step_label,
                    tag_path=self._artifacts_tag_path(fname))
                return
        elif before_path and after_fresh and before_fresh:
            self._dispatch_split_view(
                before_path, after_path, step_label)
            return

        # Loop guard.  A truncated pipeline run just completed and
        # ``_on_pipeline_finished`` re-entered us via the
        # ``_pending_view_step_key`` hook — yet the snapshot still
        # doesn't match the live hash.  Spawning another run would
        # spin forever, so log the mismatch (so the cause can be
        # traced) and stop.
        if is_reentry:
            stamped_after = self._read_snapshot_hash(after_path)
            stamped_before = (None if before_is_input
                              else self._read_snapshot_hash(before_path))
            logging.error(
                "Eye-button loop guard: snapshot still stale after a "
                "truncated pipeline run for step '%s'. Bailing out "
                "instead of looping.\n"
                "  preceding_key=%r  before_token=%r\n"
                "  after_path=%s\n"
                "    expected hash=%r  stamped=%r  fresh=%s\n"
                "  before_path=%s (input=%s)\n"
                "    expected hash=%r  stamped=%r  fresh=%s",
                step_key, preceding_key, before_token,
                after_path, after_hash, stamped_after,
                after_fresh, before_path, before_is_input,
                before_hash, stamped_before, before_fresh)
            self._msg_warning(
                "Snapshot still stale",
                "The pipeline finished but the saved snapshot still "
                "doesn't match the current GUI state. The Run-tab log "
                "has the hash mismatch details. Try toggling "
                "<i>Save</i> on this step explicitly and running the "
                "pipeline once via the Run button.")
            return

        # First-time visit (not a re-entry) and the snapshot is stale
        # / missing.  Also surface a diagnostic at debug level so a
        # pre-existing-snapshot mismatch is visible in the log without
        # having to hit the loop-guard path twice.
        if not after_fresh and os.path.isfile(after_path):
            stamped = self._read_snapshot_hash(after_path)
            logging.info(
                "Step '%s' snapshot stale: stamped=%r expected=%r — "
                "running truncated pipeline to refresh.",
                step_key, stamped, after_hash)

        # Drive the run ourselves instead of asking the user to click
        # Run manually.  Collision with an in-progress run → bail with
        # a clear message; otherwise launch the truncated pipeline.
        if self._polling_active:
            self._msg_info(
                "Pipeline running",
                "A pipeline is already running. Wait for it to "
                "finish, or click Stop on the Run tab first.")
            return
        self._run_and_view_step(step_key, step_label)

    @staticmethod
    def _fif_matches_hash(fif_path, expected_hash):
        """True iff *fif_path*'s info['description'] carries *expected_hash*.

        Read metadata-only (no signal data).  Used by ``_view_step_result``
        to detect snapshot staleness: a hash embedded by
        ``_save_step_signal_if_requested`` like ``[cfg:abc123...]`` is
        compared against the current GUI config's hash.  Absent or
        differing hashes → stale, trigger re-run.
        """
        return (IDE4EEG_Qt._read_snapshot_hash(fif_path) == expected_hash
                and expected_hash is not None)

    @staticmethod
    def _read_snapshot_hash(fif_path):
        """Read just the ``[cfg:<hash>]`` marker from a snapshot FIF.

        Returns the stamped hash string, or ``None`` if the file is
        unreadable or has no marker.  Split out from
        ``_fif_matches_hash`` so the loop-guard diagnostic in
        ``_view_step_result`` can log the actual stamped value when
        a freshness check fails.
        """
        if not fif_path:
            return None
        import re
        try:
            import mne
            info = mne.io.read_info(fif_path, verbose=False)
        except Exception:
            return None
        desc = info.get("description") or ""
        m = re.search(r"\[cfg:([0-9a-f]+)\]", desc)
        return m.group(1) if m else None

    def _artifacts_tag_path(self, fname):
        """Resolve the EEG-artifacts ``.tag`` for the eye-view dispatcher.

        ``ArtTagsSaver`` writes ``<file>___artifacts.tag`` into
        ``<recording_dir>/artifacts_detection/`` (sibling of
        ``saved_steps/``, where the post-step FIF lives).  Walks
        the same preproc-dir candidate list as every other GUI
        snapshot lookup so the timestamped + non-overwrite layouts
        are handled uniformly.
        """
        return self._find_in_preproc_dirs(
            os.path.join("artifacts_detection",
                         f"{fname}___artifacts.tag"))

    def _svarog_available(self):
        """``True`` when Svarog should drive an eye-button view.

        Captures the predicate shared by ``_dispatch_single_view``,
        ``_dispatch_split_view``, and the eye-button save_tag flip
        in ``_view_step_result``: an installed jar + the user not
        having flipped the Config-tab "Use MNE viewer" preference.
        Per-dispatcher additional gates (matching sample rates;
        ``.tag`` file present) layer on top of this base predicate.
        """
        prefer_mne = (hasattr(self, "_use_mne_viewer_check")
                      and self._use_mne_viewer_check.isChecked())
        return (not prefer_mne
                and self._svarog_jar is not None
                and os.path.isfile(self._svarog_jar))

    def _dispatch_single_view(self, after_path, step_label, tag_path=None):
        """Open *after_path* in a single window with annotations marked.

        Mirrors the Svarog/MNE selection of ``_dispatch_split_view``
        but skips the before pane: when Svarog is available and a
        ``.tag`` file exists, launch with ``--tag`` so each artifact
        type renders with its own label/color; otherwise fall back
        to the MNE viewer, which already colors the BAD_* annotations
        embedded in the snapshot by description.
        """
        if (self._svarog_available()
                and tag_path and os.path.isfile(tag_path)):
            self._launch_svarog(after_path, tag=tag_path)
            return
        self._open_signal_file_in_mne(
            after_path,
            title=f"{step_label}: {os.path.basename(after_path)}")

    def _dispatch_split_view(self, before_path, after_path, step_label):
        """Open before/after in Svarog split view or MNE fallback.

        Svarog's ``--split-signal`` requires matching sample rates.
        When rates differ (typically because the step sits after
        Resample), or when no Svarog jar is installed, or when the
        Config-tab "Use MNE viewer instead of Svarog" toggle is on,
        we fall back to two independent MNE windows — the user still
        gets the comparison, just without scroll-lock.
        """
        if (self._svarog_available()
                and _sample_rates_match(before_path, after_path)):
            self._launch_svarog(after_path, split_signal=before_path)
            return
        self._open_signal_file_in_mne(
            before_path,
            title=f"Before {step_label}: {os.path.basename(before_path)}")
        self._open_signal_file_in_mne(
            after_path,
            title=f"After {step_label}: {os.path.basename(after_path)}")

    # ── Phase 6: run-to-step-then-view ───────────────────────────────

    def _resolve_pipeline_step_names(self, gui_step_key):
        """Return pipeline step names for *gui_step_key* with the
        multi-instance ``:<id>`` suffix reattached.

        ``_GUI_TO_PIPELINE_STEPS`` keys on bare base names (e.g. the
        entry for ``filtering`` returns ``["filtering"]`` even when
        the GUI key is ``filtering:561cd476``); callers building
        snapshot paths or step_order tokens need the id back on.
        """
        base, _, sid = gui_step_key.partition(":")
        raw = (self._GUI_TO_PIPELINE_STEPS.get(gui_step_key)
               or self._GUI_TO_PIPELINE_STEPS.get(base, []))
        return [f"{p}:{sid}" if sid and p == base else p for p in raw]

    def _run_and_view_step(self, step_key, step_label):
        """Test seam; routes to ``_run_truncated_pipeline``."""
        self._run_truncated_pipeline(step_key, step_label)

    #: Valid ``post_action`` values for :meth:`_run_truncated_pipeline`.
    #: Each entry has a matching branch in :meth:`_on_pipeline_finished`'s
    #: success-case dispatch.  Adding a new entry here without a branch
    #: there silently no-ops; updating the branch without listing here
    #: defeats the assert below.
    _VALID_POST_ACTIONS = frozenset({
        "open_viewer",
        "open_gaze_after_run",
        "bad_channels_label",
        "mp_decomp_done",
    })

    def _run_truncated_pipeline(self, step_key, step_label,
                                 post_action="open_viewer",
                                 cfg_override=None):
        """Launch a full pipeline truncated at *step_key*.

        A scratch deepcopy of the current config is built (or
        ``cfg_override`` is used directly) so the user's GUI state
        is untouched.  ``step_order`` is sliced to end at the
        target, every analysis flag is forced off, and every
        enabled saveable step up to and including the target gets
        its ``save=True`` flag forced so the viewer can find the
        before/after pair AND so subsequent eye clicks on earlier
        steps can reuse the snapshots.

        Parameters
        ----------
        step_key : str
            GUI step key (e.g. ``"bad_channels"``, ``"trim"``).
        step_label : str
            Human label for error dialogs (e.g. ``"Bad Channels"``).
        post_action : str
            What should happen on the next ``pipeline_finished``
            signal.  ``"open_viewer"`` (default — eye-button UX) sets
            ``_pending_view_step_key`` so ``_on_pipeline_finished``
            re-enters ``_view_step_result``.  ``"bad_channels_label"``
            instead emits a ``BAD_CHANNELS:...`` log line so the
            panel's body label and header readout update without
            opening the before/after viewer.
        cfg_override : dict or None
            Pre-built config (deepcopied externally).  When ``None``
            this method calls ``_collect_config()`` and deepcopies
            internally.  Callers that need to flip checkboxes or
            inject step_order entries before truncation pass their
            already-prepared config here.
        """
        import copy
        cfg = (cfg_override
               if cfg_override is not None
               else copy.deepcopy(self._collect_config()))

        # Pin USER-LEVEL hashes BEFORE the truncation/forced-save
        # mutations below — step snapshots stamp these markers and
        # ``_view_step_result`` recomputes from the user's GUI cfg, so
        # the pin is what keeps the staleness check from thrashing.
        cfg["_pipeline_config_hash"] = _compute_preprocessing_hash(cfg)
        cfg["_pipeline_step_hashes"] = _compute_step_hashes(
            cfg, effective_step_order(cfg))
        from ide4eeg.preprocessing.mp_preprocessing import pin_mp_book_hash
        pin_mp_book_hash(cfg, force=True)

        # Truncate step_order at the target pipeline name.
        pipeline_names = self._resolve_pipeline_step_names(step_key)
        assert post_action in self._VALID_POST_ACTIONS, (
            f"Unknown post_action {post_action!r} -- add it to "
            f"_VALID_POST_ACTIONS and dispatch in _on_pipeline_finished")
        if post_action == "open_viewer":
            # Eye-button path needs a -raw.fif snapshot to populate
            # the before/after viewer; require the target step to be
            # in _STEP_SAVE_MAP.
            target_pipeline = next(
                (p for p in reversed(pipeline_names)
                 if p.partition(":")[0] in _STEP_SAVE_MAP),
                None)
            if target_pipeline is None:
                self._msg_error(
                    "No snapshot for this step",
                    f"'{step_label}' doesn't produce a saveable "
                    f"snapshot.")
                return
        else:
            # Other post-actions (Run-and-check, MP run) only need
            # the truncation point — they don't depend on a
            # before/after snapshot.  Steps like ``mp_decomposition``
            # produce a .db book instead of a .fif and aren't in
            # _STEP_SAVE_MAP, but are still legitimate truncation
            # targets.
            target_pipeline = pipeline_names[-1] if pipeline_names else None
            if target_pipeline is None:
                self._msg_error(
                    f"{step_label} unknown",
                    f"Cannot resolve a pipeline step name for "
                    f"'{step_key}'.")
                return
        preproc_cfg = cfg.setdefault("preprocessing", {})
        full_order = list(preproc_cfg.get("step_order", []))
        if target_pipeline not in full_order:
            # Step isn't currently in the user's pipeline — eye-click
            # / Run-and-check should still work as a one-off preview.
            # Insert at the position implied by GUI display order
            # (`_step_widgets`): for each preceding GUI widget whose
            # pipeline name(s) appear in full_order, push the
            # insertion point just past it.  No preceding match →
            # prepend.  Mirrors the pattern in `_view_bad_channels`.
            keys_in_order = [k for k, _ in self._step_widgets]
            insert_at = 0
            if step_key in keys_in_order:
                target_idx = keys_in_order.index(step_key)
                for k in keys_in_order[:target_idx]:
                    for p in self._resolve_pipeline_step_names(k):
                        if p in full_order:
                            insert_at = max(
                                insert_at, full_order.index(p) + 1)
            full_order.insert(insert_at, target_pipeline)
            # Mark the step as enabled so the runner doesn't filter it
            # back out via the per-step enable flags.
            preproc_cfg.setdefault(
                "enabled_steps", {})[target_pipeline] = True
        truncated = self._truncate_step_order(full_order, target_pipeline)
        if not truncated:
            self._msg_error(
                f"{step_label} not in step order",
                f"The step '{target_pipeline}' could not be inserted "
                f"into the configured preprocessing step order.")
            return
        preproc_cfg["step_order"] = truncated

        # Force save=True on every enabled saveable step in the
        # truncated range (target inclusive).  The target + its
        # preceding enabled save step are needed for the viewer's
        # before/after panes; the others are a cheap cache — future
        # eye clicks on any earlier step hit the happy path without
        # re-running the pipeline.
        keys_and_grps = list(self._step_widgets)
        keys = [k for k, _ in keys_and_grps]
        step_idx = keys.index(step_key) if step_key in keys else -1
        for i in range(step_idx + 1):
            k, grp = keys_and_grps[i]
            if f"save_{k}" not in self._pp:
                continue
            try:
                enabled = grp.isChecked()
            except AttributeError:
                enabled = True  # non-checkable steps are always on
            if not enabled:
                continue
            # Multi-instance steps carry a ":<id>" suffix on the GUI
            # key (e.g. "filtering:abc").  _SAVE_CHECKBOX_MAP is keyed
            # by base name only, so split the suffix off for lookup.
            base, _, sid = k.partition(":")
            meta = (self._SAVE_CHECKBOX_MAP.get(k)
                    or self._SAVE_CHECKBOX_MAP.get(base))
            if meta is None:
                continue
            section = meta[0]
            if sid:
                # Per-instance save flag (e.g. cfg["filters"][<id>]["save"])
                # — the save logic in preprocessing.py reads the per-block
                # save flag for multi-instance sections, so a top-level
                # save would miss.
                section_cfg = cfg.setdefault(section, {})
                section_cfg.setdefault(sid, {})["save"] = True
            else:
                cfg.setdefault(section, {})["save"] = True

        # Disable every analysis — we only want preprocessing.
        # Includes the mne_catalog list (ERP butterfly / joint /
        # topomap / dipole_fit etc.) which would otherwise fire
        # before Svarog opens on the eye-button path.
        self._disable_all_analyses(cfg)

        # Arm the post-run hook before launching.  Cleared by
        # _on_pipeline_finished whether the run succeeds or not.
        if post_action == "open_viewer":
            self._pending_view_step_key = step_key
            self._pending_post_action = None
        else:
            # Don't open the eye viewer; let _on_pipeline_finished
            # dispatch on _pending_post_action instead.
            self._pending_view_step_key = None
            self._pending_post_action = post_action
        if not self._launch_pipeline(cfg):
            self._pending_view_step_key = None
            self._pending_post_action = None

    @staticmethod
    def _truncate_step_order(full_order, target_pipeline_name):
        """Return ``full_order`` sliced at the first occurrence of
        *target_pipeline_name* (inclusive).  Empty list if not found.
        """
        try:
            idx = full_order.index(target_pipeline_name)
        except ValueError:
            return []
        return list(full_order[:idx + 1])

    # ── Step helpers ────────────────────────────────────────────────

    def _wire_step_help(self, step, key, title):
        """Connect a CollapsibleStep's [?] button to the help dialog."""
        if step._help_btn:
            step._help_btn.clicked.connect(
                lambda _=False, k=key, t=title: self._show_step_help(k, t))

    def _make_reorder_buttons(self, group, step_key):
        """Wire up/down arrow buttons on a CollapsibleStep for reordering."""
        if group._up_btn:
            group._up_btn.clicked.connect(
                lambda: self._move_step(step_key, -1))
        if group._dn_btn:
            group._dn_btn.clicked.connect(
                lambda: self._move_step(step_key, 1))

    # ── Reorder-time constraint validation ──────────────────────────
    #
    # Every user-initiated move through the up/down arrow buttons is
    # routed through ``_move_step``.  Before the swap is applied we:
    #
    #   1. Project the current ``_step_widgets`` list into a pipeline
    #      step order (``_step_widgets_to_pipeline_order``), using the
    #      class-level ``_GUI_TO_PIPELINE_STEPS`` mapping to drop the
    #      GUI-only entries (``gaze``, ``segment_rejection``) and
    #      expand ``filtering`` → ``resample, filtering``.
    #   2. Run ``validate_step_order`` on both the pre-move and the
    #      hypothetical post-move pipeline orders.
    #   3. Diff the two results.  Only *newly created* hard/soft
    #      violations are surfaced — pre-existing violations that the
    #      user already accepted when loading the config are silent.
    #   4. Hard violation → move is rejected, red tint for 5 s, modal
    #      error.  Soft violation → move is accepted, yellow tint for
    #      5 s, modal warning.  Clean → silent apply.
    #
    # The computation itself lives in ``_preview_step_move`` so that
    # unit tests can exercise the logic without instantiating a
    # QApplication / main window.

    @staticmethod
    def _step_widgets_to_pipeline_order(step_keys, gui_to_pipeline):
        """Flatten a list of GUI step keys to a pipeline step_order.

        Parameters
        ----------
        step_keys : list[str]
            Ordered GUI widget keys (e.g. ``["trim", "select",
            "bad_channels", ...]``).
        gui_to_pipeline : dict[str, list[str]]
            ``_GUI_TO_PIPELINE_STEPS`` or a test double with the same
            shape.  GUI keys mapping to an empty list are skipped.

        Returns
        -------
        list[str]
            Pipeline step names in order, with duplicates dropped.
            Safe to pass directly to ``validate_step_order``.
        """
        order = []
        for key in step_keys:
            for pname in gui_to_pipeline.get(key, []):
                if pname not in order:
                    order.append(pname)
        return order

    @classmethod
    def _preview_step_move(cls, step_keys, step_key, direction,
                           gui_to_pipeline=None):
        """Compute the effect of moving *step_key* by *direction*.

        Pure-Python core of ``_move_step`` — no Qt, no dialogs, no
        tinting.  Given the current GUI step-key list and a desired
        move, it returns everything the caller needs to decide whether
        to accept the move and which widgets to tint.

        Parameters
        ----------
        step_keys : list[str]
            Current GUI step-key order (from ``self._step_widgets``).
        step_key : str
            Key of the step the user clicked ▲ or ▼ on.
        direction : int
            ``-1`` for up, ``+1`` for down.
        gui_to_pipeline : dict[str, list[str]] or None
            Overrides ``cls._GUI_TO_PIPELINE_STEPS`` for tests.

        Returns
        -------
        result : dict
            Dictionary with keys:

            * ``ok`` (bool): ``True`` if the swap is in bounds.
              ``False`` when the step is already at the edge or not
              found; the caller should return early and do nothing.
            * ``new_step_keys`` (list[str]): Proposed post-move GUI
              key order.  Empty when ``ok`` is ``False``.
            * ``new_hard_violations`` (list[ConstraintViolation]):
              Hard violations present after the move but not before.
            * ``new_soft_violations`` (list[ConstraintViolation]):
              Soft violations present after the move but not before.
        """
        from ide4eeg.preprocessing.preprocessing import validate_step_order

        if gui_to_pipeline is None:
            gui_to_pipeline = cls._GUI_TO_PIPELINE_STEPS

        empty = {"ok": False, "new_step_keys": [],
                 "new_hard_violations": [],
                 "new_soft_violations": []}
        idx = next((i for i, k in enumerate(step_keys)
                    if k == step_key), None)
        if idx is None:
            return empty
        new_idx = idx + direction
        if new_idx < 0 or new_idx >= len(step_keys):
            return empty

        new_keys = list(step_keys)
        new_keys[idx], new_keys[new_idx] = new_keys[new_idx], new_keys[idx]

        old_order = cls._step_widgets_to_pipeline_order(
            step_keys, gui_to_pipeline)
        new_order = cls._step_widgets_to_pipeline_order(
            new_keys, gui_to_pipeline)

        _, old_errors, old_warnings = validate_step_order(old_order)
        _, new_errors, new_warnings = validate_step_order(new_order)

        # Pre-existing violations are keyed by (before, after) so the
        # set-difference picks out only freshly-created ones.
        old_err_keys = {(e.before, e.after) for e in old_errors}
        old_warn_keys = {(w.before, w.after) for w in old_warnings}
        new_hard = [e for e in new_errors
                    if (e.before, e.after) not in old_err_keys]
        new_soft = [w for w in new_warnings
                    if (w.before, w.after) not in old_warn_keys]

        return {"ok": True, "new_step_keys": new_keys,
                "new_hard_violations": new_hard,
                "new_soft_violations": new_soft}

    def _pipeline_step_to_widget(self, pipeline_name):
        """Return the ``CollapsibleStep`` that owns *pipeline_name*.

        ``validate_step_order`` returns pipeline step names
        (``filtering``, ``ica``, …), but the GUI tracks widgets by
        GUI-side keys that sometimes aggregate multiple pipeline steps
        (the ``filtering`` widget backs both ``resample`` and
        ``filtering``).  This helper walks the mapping in reverse and
        returns the owning widget, or ``None`` when the step has no
        widget.
        """
        for gui_key, pipeline_names in self._GUI_TO_PIPELINE_STEPS.items():
            if pipeline_name in pipeline_names:
                for key, widget in self._step_widgets:
                    if key == gui_key:
                        return widget
        return None

    def _tint_step_widget(self, widget, qcolor, duration_ms=5000):
        """Briefly tint *widget*'s background to flag a violation.

        Scoped to the ``CollapsibleStep`` row via a
        ``QWidget#<objectName>`` selector so only the offending row
        gets the highlight.  After *duration_ms* the stylesheet is
        cleared.  The ``QColor`` argument is turned into a
        ``#AARRGGBB`` string so the alpha channel survives.
        """
        if widget is None:
            return
        name = widget.objectName()
        if not name:
            name = f"reorderStep_{id(widget)}"
            widget.setObjectName(name)
        widget.setAutoFillBackground(True)
        hex_argb = qcolor.name(QColor.HexArgb)
        widget.setStyleSheet(
            f"QWidget#{name} {{ background-color: {hex_argb}; "
            f"border-radius: 4px; }}")

        def _clear():
            try:
                widget.setStyleSheet("")
            except RuntimeError:
                pass  # widget was deleted while the timer was armed

        QTimer.singleShot(duration_ms, _clear)

    def _move_step(self, step_key, direction):
        """Move a preprocessing step group up or down in the layout.

        Validates the proposed move against
        ``validate_step_order``.  Freshly-created *hard* violations
        abort the move and tint the offending pair red; freshly-
        created *soft* violations let the move through but tint
        yellow and raise a modal "scientific note".  Violations that
        already existed before the move are silent (the user has
        already accepted them when loading the config).
        """
        keys = [k for k, _ in self._step_widgets]
        preview = self._preview_step_move(keys, step_key, direction)
        if not preview["ok"]:
            return

        new_hard = preview["new_hard_violations"]
        new_soft = preview["new_soft_violations"]

        # Hard violations block the move entirely.
        if new_hard:
            self._show_violations(
                new_hard, QColor(255, 80, 80, 110),
                title="Cannot reorder", modal=self._msg_error)
            return

        # No hard violations — apply the swap, then advise on any new
        # soft violations.
        idx = next(i for i, (k, _) in enumerate(self._step_widgets)
                   if k == step_key)
        new_idx = idx + direction
        self._step_widgets[idx], self._step_widgets[new_idx] = (
            self._step_widgets[new_idx], self._step_widgets[idx])
        self._repack_preproc_steps()

        if new_soft:
            self._show_violations(
                new_soft, QColor(255, 220, 80, 110),
                title="Scientific note", modal=self._msg_warning)

    def _show_violations(self, violations, color, *, title, modal):
        """Tint every offending step row and pop a single modal.

        Shared by the hard and soft branches of ``_move_step``.  The
        caller picks the colour (red for hard, yellow for soft), the
        modal function (error vs. warning), and the dialog title.
        """
        tinted = set()
        for v in violations:
            for pname in (v.before, v.after):
                w = self._pipeline_step_to_widget(pname)
                if w is not None and id(w) not in tinted:
                    self._tint_step_widget(w, color)
                    tinted.add(id(w))
        body = "<br><br>".join(
            f"<b>{v}</b><br>{v.rationale}" for v in violations)
        modal(title, body)

    def _repack_preproc_steps(self):
        """Remove and re-add all reorderable step group widgets.

        The fixed header (Segmentation setup panel) stays at the top
        and the fixed postamble (Cut Segments, Segment Rejection) at
        the bottom.  Everything in between is re-inserted from
        ``self._step_widgets`` in its current order.
        """
        layout = self._preproc_scroll_layout
        reorder_set = {id(grp) for _, grp in self._step_widgets}
        # Record the count of fixed header items (layouts + widgets before
        # the first reorderable step)
        fixed_count = 0
        for i in range(layout.count()):
            item = layout.itemAt(i)
            w = item.widget() if item else None
            if w and id(w) in reorder_set:
                break
            fixed_count += 1
        # Collect non-reorderable tail widgets (after the header)
        tail_widgets = []
        for i in range(fixed_count, layout.count()):
            item = layout.itemAt(i)
            w = item.widget() if item else None
            if w and id(w) not in reorder_set:
                tail_widgets.append(w)
        # Remove everything after the fixed header
        while layout.count() > fixed_count:
            layout.takeAt(layout.count() - 1)
        # Re-add reorderable steps in new order
        for _, grp in self._step_widgets:
            layout.addWidget(grp)
        # Re-add non-reorderable tail widgets
        for w in tail_widgets:
            layout.addWidget(w)
        layout.addStretch()

    # ── Tab 3: Preprocessing (lazy) ──────────────────────────────────

    # Helpers for building form rows
    def _entry_row(self, grid, row, label, key, default, width=80,
                   col_offset=0):
        """Add label + QLineEdit to *grid* and return the edit widget."""
        lbl = QLabel(label)
        grid.addWidget(lbl, row, col_offset, Qt.AlignRight | Qt.AlignVCenter)
        edit = QLineEdit(str(default))
        edit.setFixedWidth(width)
        edit.setToolTip(FIELD_TOOLTIPS.get(key, ""))
        grid.addWidget(edit, row, col_offset + 1)
        return edit

    def _combo_row(self, grid, row, label, key, items, current,
                   col_offset=0):
        """Add label + QComboBox to *grid* and return the combo."""
        lbl = QLabel(label)
        grid.addWidget(lbl, row, col_offset, Qt.AlignRight | Qt.AlignVCenter)
        combo = QComboBox()
        combo.addItems(items)
        combo.setCurrentText(str(current))
        combo.setToolTip(FIELD_TOOLTIPS.get(key, ""))
        grid.addWidget(combo, row, col_offset + 1)
        return combo

    def _build_preproc_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(2)
        # Trim the default 11 px top margin so the first CollapsibleStep
        # sits flush with the tab; hideSeparator() on that step (below)
        # additionally suppresses the leading HLine.
        layout.setContentsMargins(11, 0, 11, 11)

        cfg = self.config_data
        cc = cfg.get("choosing_channels", {})
        filt = cfg.get("filters", {})
        art = cfg.get("artifacts", {})
        rp = art.get("rejection_parameters", {})
        rest = cfg.get("rest", {})
        ep = cfg.get("epochs", {})
        mp = cfg.get("matching_pursuit", {})
        mp_flt = mp.get("filter", {})
        sr = cfg.get("segment_rejection", {})

        # Store all preproc widgets for later _collect_config
        self._pp = {}

        # ── Segmentation setup (event dict + rest markers) ─────────────────
        mode_grp = CollapsibleStep(
            "Segmentation setup",
            checkable=True,
            checked=True, has_help=True, help_key="segmentation_setup")
        if mode_grp._checkbox:
            mode_grp._checkbox.setEnabled(False)
        # Drop a transparent cabinet-sized spacer so the title button
        # aligns with cabinet-having panels — Segmentation setup is
        # a config-only step (no save toggle).
        _seg_setup_spacer = QWidget()
        _seg_setup_spacer.setFixedSize(34, 24)
        _seg_setup_idx = mode_grp._header_layout.indexOf(
            mode_grp._details_btn)
        if _seg_setup_idx >= 0:
            mode_grp._header_layout.insertWidget(
                _seg_setup_idx, _seg_setup_spacer)
        mv = mode_grp.contentWidget().layout()
        mv.setContentsMargins(8, 4, 8, 8)
        self._add_step_info_row(mode_grp, "segmentation_setup")

        # Mode combo lives in the CollapsibleStep HEADER so it stays
        # visible even when the Segmentation setup panel is collapsed
        # — the mode choice is load-bearing for every downstream step
        # and has to be seen at a glance.  The "Save signal with
        # STIM channel" checkbox stays in the panel body where the
        # other per-step save toggles live.
        _mode_hdr = QWidget()
        _mode_hdr_l = QHBoxLayout(_mode_hdr)
        _mode_hdr_l.setContentsMargins(0, 0, 0, 0)
        _mode_hdr_l.setSpacing(6)
        self._seg_mode_label = QLabel("")
        self._seg_mode_label.setStyleSheet("color: gray;")
        _mode_hdr_l.addWidget(self._seg_mode_label)
        _mode_hdr_l.addWidget(self._mode_combo)
        _mode_hdr_l.addSpacing(12)
        self._seg_view_btn = QPushButton("\U0001f441")
        self._seg_view_btn.setFixedWidth(44)
        self._seg_view_btn.setToolTip(
            "Preview segmentation in Svarog\n\n"
            "Writes a .tag file reflecting the current segmentation\n"
            "config and opens it on the raw input signal, so you can\n"
            "verify where segments would fall before running the\n"
            "pipeline.\n\n"
            "Rest mode: one tag per window, every window_length\n"
            "seconds from rest_duration[0] to [1] (or the end of\n"
            "the signal if whole_signal is checked).  Positions are\n"
            "offset by trim_start so windows land on the raw signal\n"
            "even when trim is configured.\n\n"
            "Epochs mode: one tag per selected event, spanning\n"
            "[start_offset, stop_offset] around each event read\n"
            "from the STIM channel.\n\n"
            "Both point markers (segment starts) and duration blocks\n"
            "(full windows) are written, so Svarog shows both the\n"
            "anchors and the actual signal ranges.")
        self._seg_view_btn.clicked.connect(self._preview_segments)
        _mode_hdr_l.addWidget(self._seg_view_btn)
        mode_grp.addHeaderWidget(_mode_hdr)

        # -- Rest parameters (visible when mode=rest) --
        self._pp["_rest_frame"] = QWidget()
        rl = QVBoxLayout(self._pp["_rest_frame"])
        rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(4)

        self._pp["rest_dur_start"] = QLineEdit(
            str(rest.get("rest_duration", [0, ""])[0]))
        self._pp["rest_dur_start"].setFixedWidth(60)
        self._pp["rest_dur_start"].setToolTip(
            FIELD_TOOLTIPS.get("rest.rest_duration_start", ""))
        self._pp["rest_dur_end"] = QLineEdit(
            str(rest.get("rest_duration", [0, ""])[1]))
        self._pp["rest_dur_end"].setFixedWidth(60)
        self._pp["rest_dur_end"].setToolTip(
            FIELD_TOOLTIPS.get("rest.rest_duration_end", ""))
        self._pp["rest_window"] = QLineEdit(
            str(rest.get("window_length", 20)))
        self._pp["rest_window"].setFixedWidth(60)
        self._pp["rest_window"].setToolTip(
            FIELD_TOOLTIPS.get("rest.window_length", ""))
        self._pp["rest_whole"] = QCheckBox("whole signal")
        self._pp["rest_whole"].setChecked(rest.get("whole_signal", False))
        self._pp["rest_whole"].setToolTip(
            FIELD_TOOLTIPS.get("rest.whole_signal", ""))
        # Fixed-width spacer labels — Qt collapses multiple spaces in
        # a QLabel's text, so we need actual zero-text widgets with a
        # setFixedWidth to visually separate adjacent flow units.
        def _spc(w):
            lbl = QLabel(""); lbl.setFixedWidth(w); return lbl
        rl.addWidget(_flow_pairs([
            (QLabel("Start:"), self._pp["rest_dur_start"]),
            (QLabel("end:"), self._pp["rest_dur_end"]),
            _spc(8),
            QLabel("s,"),
            _spc(12),
            (QLabel("window:"), self._pp["rest_window"]),
            QLabel("s"),
            _spc(16),
            self._pp["rest_whole"],
        ]))
        # "whole signal" fills window with signal duration
        def _on_whole_toggled(checked):
            if checked:
                dur = getattr(self, "_cached_duration", None)
                if dur and dur > 0:
                    self._pp["rest_window"].setText(f"{dur:.2f}")
        self._pp["rest_whole"].toggled.connect(_on_whole_toggled)
        mv.addWidget(self._pp["_rest_frame"])

        # -- Event-locked parameters (visible when mode=epochs) --
        self._pp["_epochs_frame"] = QWidget()
        el = QVBoxLayout(self._pp["_epochs_frame"])
        el.setContentsMargins(0, 0, 0, 0); el.setSpacing(4)

        self._pp["ep_start"] = QLineEdit(
            str(ep.get("start_offset", -0.3)))
        self._pp["ep_start"].setFixedWidth(60)
        self._pp["ep_start"].setToolTip(
            FIELD_TOOLTIPS.get("epochs.start_offset", ""))
        self._pp["ep_stop"] = QLineEdit(
            str(ep.get("stop_offset", 0.7)))
        self._pp["ep_stop"].setFixedWidth(60)
        self._pp["ep_stop"].setToolTip(
            FIELD_TOOLTIPS.get("epochs.stop_offset", ""))
        self._pp["ep_baseline"] = QComboBox()
        self._pp["ep_baseline"].addItems(
            ["None", "(start, 0)", "(None, 0)", "(0, stop)", "Custom"])
        self._pp["ep_baseline"].setFixedWidth(100)
        self._pp["ep_baseline"].setToolTip(
            FIELD_TOOLTIPS.get("epochs.epochs_baseline", ""))
        # Custom-baseline fields, visible only when combo == "Custom".
        # Empty edit → None (MNE shorthand for "from epoch start" or
        # "to epoch end" depending on which side it's on).
        self._pp["_ep_baseline_custom"] = QWidget()
        _cb_l = QHBoxLayout(self._pp["_ep_baseline_custom"])
        _cb_l.setContentsMargins(0, 0, 0, 0)
        _cb_l.setSpacing(4)
        self._pp["ep_baseline_start"] = QLineEdit()
        self._pp["ep_baseline_start"].setFixedWidth(50)
        self._pp["ep_baseline_start"].setPlaceholderText("start")
        self._pp["ep_baseline_start"].setToolTip(
            "Custom baseline start [s], relative to event onset.\n"
            "Leave blank for 'from start of epoch'.")
        self._pp["ep_baseline_end"] = QLineEdit()
        self._pp["ep_baseline_end"].setFixedWidth(50)
        self._pp["ep_baseline_end"].setPlaceholderText("end")
        self._pp["ep_baseline_end"].setToolTip(
            "Custom baseline end [s], relative to event onset.\n"
            "Leave blank for 'to end of epoch'.")
        _cb_l.addWidget(QLabel("("))
        _cb_l.addWidget(self._pp["ep_baseline_start"])
        _cb_l.addWidget(QLabel(","))
        _cb_l.addWidget(self._pp["ep_baseline_end"])
        _cb_l.addWidget(QLabel(") [s]"))
        # Map TOML value → combo text + possibly populated custom edits.
        _bl_raw = ep.get("epochs_baseline", "None")
        _bl_disp = self._baseline_to_combo_text(_bl_raw)
        self._pp["ep_baseline"].setCurrentText(_bl_disp)
        if _bl_disp == "Custom" and isinstance(_bl_raw, (list, tuple)):
            s, e = (_bl_raw + [None, None])[:2]
            self._pp["ep_baseline_start"].setText(
                "" if s is None else str(s))
            self._pp["ep_baseline_end"].setText(
                "" if e is None else str(e))
        self._pp["_ep_baseline_custom"].setVisible(_bl_disp == "Custom")
        self._pp["ep_baseline"].currentTextChanged.connect(
            lambda t: self._pp["_ep_baseline_custom"].setVisible(t == "Custom"))
        # Hide unnamed STIM codes by default — parameter-rich
        # PsychoPy recordings can produce 100+ raw integer codes
        # that swamp the picker.  Toggle reveals them on demand.
        self._pp["ev_show_unnamed"] = QCheckBox(
            "Show unnamed codes")
        self._pp["ev_show_unnamed"].setToolTip(
            "Reveal raw STIM pulses that aren't bound to a\n"
            "named OBCI tag (e.g. PsychoPy tag_parameter\n"
            "combinations or button-box codes).  Hidden by\n"
            "default since trial segregation should normally\n"
            "happen on tag names alone.")
        self._pp["ev_show_unnamed"].setVisible(False)
        self._pp["ev_show_unnamed"].toggled.connect(
            self._on_show_unnamed_toggled)
        el.addWidget(_flow_pairs([
            (QLabel("Start offset [s]:"), self._pp["ep_start"]),
            (QLabel("stop:"), self._pp["ep_stop"]),
            (QLabel("Baseline:"), self._pp["ep_baseline"]),
            (QWidget(), self._pp["_ep_baseline_custom"]),
            self._pp["ev_show_unnamed"],
        ]))

        # Event selection panel (populated when file loads)
        self._pp["ev_panel"] = SelectionPanel(
            title="Events", named_filter=True)
        self._pp["ev_panel"].setToolTip(
            "Check event types to include in epoch analysis.\n"
            "Events are discovered from the loaded file.")
        el.addWidget(self._pp["ev_panel"])

        mv.addWidget(self._pp["_epochs_frame"])

        # Live preview of the cut_segments postamble output: predicted
        # epoch count + width.  Updated by `_update_seg_preview_label`
        # whenever any input that drives segmentation changes (mode,
        # window length, trim, event selection, epoch offsets).
        self._pp["seg_preview_lbl"] = QLabel("")
        self._pp["seg_preview_lbl"].setStyleSheet(
            "color: gray; font-style: italic; padding-top: 4px;")
        self._pp["seg_preview_lbl"].setWordWrap(True)
        mv.addWidget(self._pp["seg_preview_lbl"])

        # No bottom separator inside Segmentation setup — the next
        # CollapsibleStep (Trim signal) provides its own top
        # separator, centered between the two headers via
        # CollapsibleStep's outer-margin / addSpacing pattern.
        # The previous in-step bottom separator was redundant AND
        # shifted the visible line up by ~9 px (it sat directly under
        # Segmentation's content while Trim's properly-centered top
        # line sat 9 px below it, but only the upper black QSS line
        # was easily visible).

        # Wire the [?] help button to the segmentation_setup help entry
        self._wire_step_help(mode_grp, "segmentation_setup",
                             "Segmentation setup")
        mode_grp.hideSeparator()
        layout.addWidget(mode_grp)

        # Mode switching: show/hide timed windows vs event-locked parameters
        def _on_mode_switch(_display_text=None):
            m = self._mode  # config value: "rest" or "epochs"
            self._pp["_rest_frame"].setVisible(m == "rest")
            self._pp["_epochs_frame"].setVisible(m == "epochs")
            self._update_seg_mode_label()
        self._mode_combo.currentTextChanged.connect(_on_mode_switch)
        self._pp["ev_panel"].selection_changed.connect(
            self._update_seg_mode_label)
        self._pp["rest_window"].textChanged.connect(
            lambda _=None: self._update_seg_mode_label())
        # Preview line at the body bottom — depends on a wider set of
        # fields than the header label, so wire the rest-bound and
        # epoch-bound edits independently.
        for _wk in ("rest_dur_start", "rest_dur_end",
                    "ep_start", "ep_stop"):
            _w = self._pp.get(_wk)
            if _w is not None:
                _w.textChanged.connect(
                    lambda _=None: self._update_seg_preview_label())
        _whole = self._pp.get("rest_whole")
        if _whole is not None:
            _whole.toggled.connect(
                lambda _=False: self._update_seg_preview_label())
        _on_mode_switch()

        _wire_help = self._wire_step_help  # shorthand

        # ── Trim signal (trim_signal) ────────────────────────────────
        trim_grp = CollapsibleStep(
            "Trim signal", checkable=True,
            checked=bool(cfg.get("trim_start", 0)),
            reorderable=True,
            has_help=True, help_key="trim")
        tv = trim_grp.contentWidget().layout()
        tv.setContentsMargins(8, 4, 8, 4)
        self._add_step_info_row(trim_grp, "trim")

        tr = QHBoxLayout()
        tr.addWidget(QLabel("Start [s]:"))
        self._pp["trim_start"] = QLineEdit(str(cfg.get("trim_start", 0.0)))
        self._pp["trim_start"].setFixedWidth(70)
        self._pp["trim_start"].setToolTip(FIELD_TOOLTIPS.get("trim_start", ""))
        tr.addWidget(self._pp["trim_start"])
        self._pp["trim_start_info"] = QLabel("")
        self._pp["trim_start_info"].setStyleSheet("color: gray;")
        tr.addWidget(self._pp["trim_start_info"])
        tr.addSpacing(16)
        tr.addWidget(QLabel("End [s]:"))
        self._pp["trim_end"] = QLineEdit(str(cfg.get("trim_end", "")))
        self._pp["trim_end"].setFixedWidth(70)
        self._pp["trim_end"].setToolTip(FIELD_TOOLTIPS.get("trim_end", ""))
        tr.addWidget(self._pp["trim_end"])
        self._pp["trim_end_info"] = QLabel("")
        self._pp["trim_end_info"].setStyleSheet("color: gray;")
        tr.addWidget(self._pp["trim_end_info"])
        tr.addStretch()
        tv.addLayout(tr)

        # "X total[, Y after trim]" line in the panel header — the
        # only visible duration readout (the body-level label was
        # removed when the Preview & Trim button moved to the
        # header eye).  Updated by _update_trim_duration; inserted
        # into the header just before the eye button further below,
        # after enable_view_button has run.
        self._pp["trim_header_info"] = QLabel("")
        self._pp["trim_header_info"].setStyleSheet("color: gray;")

        self._pp["trim_start"].textChanged.connect(self._update_trim_duration)
        self._pp["trim_end"].textChanged.connect(self._update_trim_duration)

        self._pp["_trim_grp"] = trim_grp
        self._add_step_actions(trim_grp, "trim")
        self._make_reorder_buttons(trim_grp, "trim")
        _wire_help(trim_grp, "trim", "Trim signal")
        self._add_save_checkbox(trim_grp, "trim", cfg=cfg)
        # (No hideSeparator() — Trim signal is no longer the first
        # step; Segmentation setup precedes it.  Trim's top separator
        # provides the centered line between the two headers.)
        layout.addWidget(trim_grp)

        # ── Drop Channels (select_channels) ──────────────────────────
        sel_grp = CollapsibleStep(
            "Drop Channels", checkable=True,
            checked=False, reorderable=True,
            has_help=True, help_key="chosen_channels")
        sv = sel_grp.contentWidget().layout()
        sv.setContentsMargins(8, 4, 8, 4)
        self._add_step_info_row(sel_grp, "select")

        drop_hint = QLabel("Checked channels remain; uncheck channels to drop.")
        drop_hint.setStyleSheet("color: gray;")
        sv.addWidget(drop_hint)
        # Channel checkbox panel (SelectionPanel with All/None/EEG-only).
        # count_in_title=False keeps the inner GroupBox title bare
        # ("Channels"); the running count is mirrored to the panel
        # header label (created below, parked left of the eye further
        # down in the eye-button loop).
        self._pp["sel_channel_panel"] = ChannelPanel(
            title="Channels", eeg_filter=True, count_in_title=False)
        sv.addWidget(self._pp["sel_channel_panel"])
        self._register_channel_panel(self._pp["sel_channel_panel"])
        self._pp["sel_channel_count"] = QLabel("")
        self._pp["sel_channel_count"].setStyleSheet("color: gray;")
        self._pp["sel_channel_panel"].selection_changed.connect(
            lambda: self._pp["sel_channel_count"].setText(
                self._pp["sel_channel_panel"].count_text()))
        self._pp["_sel_grp"] = sel_grp
        self._add_step_actions(sel_grp, "select")
        self._make_reorder_buttons(sel_grp, "select")
        _wire_help(sel_grp, "chosen_channels", "Drop Channels")
        self._add_save_checkbox(sel_grp, "select", cfg=cfg)
        layout.addWidget(sel_grp)

        # ── Bad Channels (find_bad_channels) ─────────────────────────
        bad_grp = CollapsibleStep(
            "Bad Channels", checkable=True,
            checked=False, reorderable=True,
            has_help=True, help_key="bad_channels")
        bv = bad_grp.contentWidget().layout()
        bv.setContentsMargins(8, 4, 8, 4)
        bv.setSpacing(2)
        self._add_step_info_row(bad_grp, "bad_channels")
        br1 = QHBoxLayout()
        br1.addWidget(QLabel("Mode:"))
        self._pp["bad_mode"] = QComboBox()
        self._pp["bad_mode"].addItems(["auto", "manual", "both"])
        self._pp["bad_mode"].setCurrentText(cc.get("choose_bad_channels", "auto"))
        self._pp["bad_mode"].setFixedWidth(80)
        self._pp["bad_mode"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.choose_bad_channels", ""))
        br1.addWidget(self._pp["bad_mode"])
        br1.addSpacing(12)
        self._pp["bad_result"] = QLabel("")
        self._pp["bad_result"].setWordWrap(True)
        br1.addWidget(self._pp["bad_result"])
        br1.addStretch()
        bv.addLayout(br1)
        # Mirror the detected-channels list to the panel header so
        # the names stay visible when the panel is collapsed.
        # Inserted into the header just before the eye button by
        # the eye-button loop further below.
        self._pp["bad_header_info"] = QLabel("")
        self._pp["bad_header_info"].setStyleSheet("color: gray;")
        # Advanced parameters (collapsible, compact)
        bcp = cc.get("badchs_params", {})
        adv_box = CollapsibleGroupBox("Advanced parameters", collapsed=True)
        adv_v = QVBoxLayout(adv_box.contentWidget())
        adv_v.setSpacing(4)
        # -- Slow oscillation --
        slow = bcp.get("slow_oscillations", [1, [2, 10], "-", [1e3, 1e4, 1e5]])
        sr1 = QHBoxLayout()
        self._pp["enable_slow"] = QCheckBox("Slow oscillation")
        self._pp["enable_slow"].setChecked(True)
        self._pp["enable_slow"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.enable_slow_osc", ""))
        sr1.addWidget(self._pp["enable_slow"])
        sr1.addSpacing(8)
        sr1.addWidget(QLabel("Window [s]:"))
        self._pp["slow_window"] = QLineEdit(str(slow[0]))
        self._pp["slow_window"].setFixedWidth(40)
        self._pp["slow_window"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.noise_window", ""))
        sr1.addWidget(self._pp["slow_window"])
        sr1.addSpacing(8)
        sr1.addWidget(QLabel("Band [Hz]:"))
        self._pp["slow_band"] = QLineEdit(f"{slow[1][0]}, {slow[1][1]}")
        self._pp["slow_band"].setFixedWidth(80)
        self._pp["slow_band"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.noise_slow_band", ""))
        sr1.addWidget(self._pp["slow_band"])
        sr1.addSpacing(8)
        sr1.addWidget(QLabel("Thresholds:"))
        self._pp["slow_thr"] = QLineEdit(", ".join(str(int(t)) for t in slow[3]))
        self._pp["slow_thr"].setFixedWidth(145)
        self._pp["slow_thr"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.noise_slow_thresholds", ""))
        sr1.addWidget(self._pp["slow_thr"])
        sr1.addStretch()
        adv_v.addLayout(sr1)
        adv_v.addSpacing(6)
        # -- High-frequency noise --
        noise = bcp.get("noise_power", [1, [52, 98], "-", [20, 200, 2000]])
        nr1 = QHBoxLayout()
        self._pp["enable_noise"] = QCheckBox("HF noise")
        self._pp["enable_noise"].setChecked(True)
        self._pp["enable_noise"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.enable_noise_power", ""))
        nr1.addWidget(self._pp["enable_noise"])
        nr1.addSpacing(8)
        nr1.addWidget(QLabel("Band [Hz]:"))
        self._pp["noise_band"] = QLineEdit(f"{noise[1][0]}, {noise[1][1]}")
        self._pp["noise_band"].setFixedWidth(80)
        self._pp["noise_band"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.noise_power_band", ""))
        nr1.addWidget(self._pp["noise_band"])
        nr1.addSpacing(8)
        nr1.addWidget(QLabel("Thresholds:"))
        self._pp["noise_thr"] = QLineEdit(", ".join(str(int(t)) for t in noise[3]))
        self._pp["noise_thr"].setFixedWidth(145)
        self._pp["noise_thr"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.noise_power_thresholds", ""))
        nr1.addWidget(self._pp["noise_thr"])
        nr1.addStretch()
        adv_v.addLayout(nr1)
        adv_v.addSpacing(6)
        # -- Correlation --
        cw = cc.get("correlation_window", [0.75, 0.975])
        cr1 = QHBoxLayout()
        self._pp["enable_corr"] = QCheckBox("Correlation")
        self._pp["enable_corr"].setChecked(False)
        self._pp["enable_corr"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.enable_correlation", ""))
        cr1.addWidget(self._pp["enable_corr"])
        cr1.addSpacing(8)
        cr1.addWidget(QLabel("Window:"))
        self._pp["corr_window"] = QLineEdit(f"{cw[0]}, {cw[1]}")
        self._pp["corr_window"].setFixedWidth(80)
        self._pp["corr_window"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.correlation_window", ""))
        cr1.addWidget(self._pp["corr_window"])
        cr1.addSpacing(8)
        cr1.addWidget(QLabel("Bad ch. thr:"))
        self._pp["corr_thr"] = QLineEdit(str(cc.get("correlation_badch_threshold", 0.95)))
        self._pp["corr_thr"].setFixedWidth(50)
        self._pp["corr_thr"].setToolTip(
            FIELD_TOOLTIPS.get("choosing_channels.correlation_badch_threshold", ""))
        cr1.addWidget(self._pp["corr_thr"])
        cr1.addStretch()
        adv_v.addLayout(cr1)
        bv.addWidget(adv_box)
        bch_cfg = cfg.get("bad_channels", {}) or {}
        self._pp["bch_save_plots"] = QCheckBox(
            "Save detection plots")
        self._pp["bch_save_plots"].setChecked(
            bch_cfg.get("save_plots", False))
        self._pp["bch_save_plots"].setToolTip(
            FIELD_TOOLTIPS.get("bad_channels.save_plots", ""))
        bv.addWidget(self._pp["bch_save_plots"])
        self._pp["_bad_grp"] = bad_grp
        self._add_step_actions(bad_grp, "bad_channels")
        self._make_reorder_buttons(bad_grp, "bad_channels")
        _wire_help(bad_grp, "bad_channels", "Bad Channels")
        self._add_save_checkbox(bad_grp, "bad_channels", cfg=cfg)
        layout.addWidget(bad_grp)

        # ── Montage (set_montage) ────────────────────────────────────
        # Phase 1 split (2026-04-28): re-reference moved to its own
        # CollapsibleStep below so the user can reorder it
        # independently (e.g. reference before vs. after ICA).
        mont_grp = CollapsibleStep(
            "Montage", checkable=True,
            checked=False, reorderable=True,
            has_help=True, help_key="montage")
        self._add_step_info_row(mont_grp, "montage")
        mog = QGridLayout()
        mont_grp.contentWidget().layout().addLayout(mog)
        # The layout combo lives in the panel header — see the
        # eye-button loop below where it's inserted left of the eye
        # so the current selection stays visible when the panel is
        # collapsed.
        self._pp["montage"] = QComboBox()
        self._pp["montage"].addItems([
            NATIVE_POSITIONS_SENTINEL,
            "10-20", "10-10", "10-05", "biosemi16", "biosemi32",
            "biosemi64", "biosemi128", "biosemi256",
            "easycap-M1", "GSN-HydroCel-32", "GSN-HydroCel-64",
            "GSN-HydroCel-128", "GSN-HydroCel-256", "mgh60", "mgh70"])
        self._pp["montage"].setCurrentText(
            cfg.get("electrodes_layout", NATIVE_POSITIONS_SENTINEL))
        self._pp["montage"].setToolTip(
            FIELD_TOOLTIPS.get("electrodes_layout", ""))
        # Montage description
        self._pp["montage_desc"] = QLabel("")
        self._pp["montage_desc"].setStyleSheet("color: gray;")
        self._pp["montage_desc"].setWordWrap(True)
        mog.addWidget(self._pp["montage_desc"], 0, 0, 1, 4)
        # In-panel "👁 montage" button removed — the head diagram is
        # now opened by the eye in the panel header (wired in the
        # post-loop block far below).
        self._pp["montage_match"] = QLabel("")
        self._pp["montage_match"].setStyleSheet("color: #1565c0;")
        self._pp["montage_match"].setWordWrap(True)
        mog.addWidget(self._pp["montage_match"], 1, 0, 1, 4)
        self._pp["montage"].currentTextChanged.connect(
            self._update_montage_match)
        self._pp["montage"].currentTextChanged.connect(
            self._update_montage_desc)
        self._update_montage_desc()
        self._pp["_mont_grp"] = mont_grp
        self._add_step_actions(mont_grp, "montage")
        self._make_reorder_buttons(mont_grp, "montage")
        _wire_help(mont_grp, "montage", "Montage")
        # No save checkbox — montage is metadata-only (see
        # _STEP_SAVE_MAP / _SAVE_CHECKBOX_MAP comments).  Drop a
        # transparent spacer the size of the cabinet glyph
        # (matches enable_save_toggle's setFixedSize(34, 24)) so
        # the Montage title button stays vertically aligned with
        # the title buttons of every other panel.
        _mont_spacer = QWidget()
        _mont_spacer.setFixedSize(34, 24)
        idx = mont_grp._header_layout.indexOf(mont_grp._details_btn)
        if idx >= 0:
            mont_grp._header_layout.insertWidget(idx, _mont_spacer)
        layout.addWidget(mont_grp)

        # ── Reference (set_reference) ────────────────────────────────
        # Was bundled with Montage until Phase 1 split.  Save flag
        # lives in cfg["reference"]["save"] (sibling of the
        # top-level ``re_reference`` scalar).
        ref_grp = CollapsibleStep(
            "Reference", checkable=True,
            checked=False, reorderable=True,
            has_help=True, help_key="reference")
        rv = ref_grp.contentWidget().layout()
        rv.setContentsMargins(8, 4, 8, 4)
        self._add_step_info_row(ref_grp, "reference")
        _REREF_PRESETS = [
            ("Raw signal (no re-referencing)", ""),
            ("Common average reference (CAR)", "average"),
            ("Linked mastoids (M1+M2)", "M1, M2"),
            ("Linked ears (A1+A2)", "A1, A2"),
            ("REST \u2014 infinity reference (Yao 2001)", "REST"),
            ("Custom derivation\u2026", "_custom"),
        ]
        # Default to "Raw signal (no re-referencing)" when the
        # config is silent on this — re-referencing is an opt-in
        # decision, and silently picking M1/M2 (legacy default)
        # was misleading on recordings that don't have those
        # channels.
        rr = cfg.get("re_reference", "")
        rr_str = (", ".join(rr) if isinstance(rr, list)
                  else str(rr) if rr else "")
        # Stash on the instance so _populate_vars (which runs in a
        # different scope when reloading configs) can use the same
        # display→value table for matching.
        self._reref_presets = list(_REREF_PRESETS)
        preset_names = [p[0] for p in _REREF_PRESETS]
        preset_map = {p[0]: p[1] for p in _REREF_PRESETS}
        init_preset = preset_names[0]
        for disp, val in _REREF_PRESETS:
            if rr_str.lower() == val.lower():
                init_preset = disp
                break
        else:
            if rr_str:
                init_preset = "Custom derivation\u2026"
        # The re-reference scheme combo lives in the panel header \u2014
        # see the eye-button loop below where it's inserted left of
        # the eye so the current selection stays visible when the
        # panel is collapsed.
        self._pp["reref_method"] = QComboBox()
        self._pp["reref_method"].addItems(preset_names)
        self._pp["reref_method"].setCurrentText(init_preset)
        self._pp["reref_method"].setMinimumWidth(250)
        self._pp["reref_method"].setToolTip(
            "Re-reference scheme:\n"
            "\u2022 Raw signal \u2014 keep the recording's native\n"
            "  reference\n"
            "\u2022 Common average (CAR) \u2014 subtract the mean\n"
            "  across all good EEG channels\n"
            "\u2022 Linked mastoids / linked ears \u2014 subtract the\n"
            "  average of the two named reference channels\n"
            "\u2022 REST (Yao 2001) \u2014 approximate infinity\n"
            "  reference via source localisation\n"
            "\u2022 Custom \u2014 enter a comma-separated list of\n"
            "  channels to average as the reference")
        # Header info label — mirrors the custom-channels validation
        # so the user sees the chosen electrodes (and any "not found"
        # warnings) at a glance even when the panel is collapsed.
        # Inserted into the header after the combo, in the post-loop
        # block far below.
        self._pp["reref_header_info"] = QLabel("")
        self._pp["reref_header_info"].setStyleSheet("color: gray;")
        # Custom channels entry (shown only for Custom)
        cust_row = QHBoxLayout()
        cust_row.addWidget(QLabel("Channels:"))
        self._pp["reref"] = QLineEdit(
            rr_str if init_preset == "Custom derivation\u2026" else "")
        self._pp["reref"].setToolTip(
            "Comma-separated channel names for custom re-reference")
        cust_row.addWidget(self._pp["reref"])
        self._pp["reref_status"] = QLabel("")
        cust_row.addWidget(self._pp["reref_status"])
        self._pp["_reref_cust_row"] = QWidget()
        self._pp["_reref_cust_row"].setLayout(cust_row)
        rv.addWidget(self._pp["_reref_cust_row"])
        self._pp["reref"].textChanged.connect(self._update_reref_status)
        # Wire preset changes
        def _on_reref_preset_changed(text):
            val = preset_map.get(text, "")
            is_custom = (val == "_custom")
            self._pp["_reref_cust_row"].setVisible(is_custom)
            if not is_custom:
                self._pp["reref"].setText(val)
        self._pp["reref_method"].currentTextChanged.connect(
            _on_reref_preset_changed)
        # Re-run the validator on preset switches too — switching
        # *into* Custom doesn't change the LineEdit text, so the
        # textChanged path wouldn't otherwise fire.
        self._pp["reref_method"].currentTextChanged.connect(
            lambda _: self._update_reref_status())
        _on_reref_preset_changed(init_preset)
        self._pp["_ref_grp"] = ref_grp
        self._add_step_actions(ref_grp, "reference")
        self._make_reorder_buttons(ref_grp, "reference")
        _wire_help(ref_grp, "reference", "Reference")
        self._add_save_checkbox(ref_grp, "reference", cfg=cfg)
        layout.addWidget(ref_grp)

        # ── Resample (resample) ─────────────────────────────────────
        # Was bundled with Filters until Phase 1 (2026-04-28); split
        # so the user can reorder resampling independently of filter
        # design.  Default order still puts Resample before Filters.
        resample_grp = CollapsibleStep(
            "Resample",
            checkable=True, checked=False, reorderable=True,
            has_help=True, help_key="resample")
        rv = resample_grp.contentWidget().layout()
        rv.setContentsMargins(8, 4, 8, 4)
        self._add_step_info_row(resample_grp, "resample")
        rf = cfg.get("resample_freq", 0)
        fr0 = QHBoxLayout()
        fr0.addWidget(QLabel("Resample to:"))
        self._pp["resample_freq"] = QLineEdit(str(rf) if rf else "")
        self._pp["resample_freq"].setFixedWidth(60)
        self._pp["resample_freq"].setPlaceholderText("off")
        self._pp["resample_freq"].setToolTip(
            "Target sample rate in Hz. Leave blank (or 0) to keep\n"
            "the original rate. Downsampling speeds up later\n"
            "analyses at the cost of losing frequency content\n"
            "above the new Nyquist.")
        fr0.addWidget(self._pp["resample_freq"])
        fr0.addWidget(QLabel("Hz"))
        fr0.addStretch()
        rv.addLayout(fr0)
        # Header summary: "original sampling: NNN Hz" when no
        # resampling, "NNN Hz, resampled to MMM Hz" otherwise.
        # Inserted into the panel header by the eye-button loop.
        self._pp["resample_header_info"] = QLabel(
            "(load a file to see sampling rate)")
        self._pp["resample_header_info"].setStyleSheet("color: gray;")
        self._pp["resample_freq"].textChanged.connect(
            self._update_resample_header_info)
        self._pp["_resample_grp"] = resample_grp
        self._add_step_actions(resample_grp, "resample")
        self._make_reorder_buttons(resample_grp, "resample")
        _wire_help(resample_grp, "resample", "Resample")
        self._add_save_checkbox(resample_grp, "resample", cfg=cfg)
        layout.addWidget(resample_grp)

        # ── Filters (filter_signal) ─────────────────────────────────
        # Phase 2 multi-instance: each filter panel has a unique
        # 8-char ID; widgets and step_order tokens use the id as
        # suffix.  TOML schema is {id: cfg_dict} under [filters];
        # legacy flat [filters] auto-migrates to one entry.
        # _build_filter_panel is the per-id factory; the [+] button
        # on each panel duplicates it (visible when reorder mode is
        # on, see _on_allow_reorder_toggled).
        self._filter_widgets = []  # [(filter_id, CollapsibleStep), ...]
        # Detect schema:  legacy = flat dict with HP/LP keys at top
        # level; new = {id: subdict}.
        filt_root = cfg.get("filters", {}) or {}
        is_legacy_flat = any(
            k in filt_root for k in
            ("highpass_freq", "lowpass_freq", "notch_freq", "method",
             "show_filt", "plot_filt", "save"))
        if is_legacy_flat:
            initial_filter_blocks = [(None, dict(filt_root))]
        else:
            # Filter id keys are strings; sort for deterministic order.
            initial_filter_blocks = [
                (fid, dict(fcfg))
                for fid, fcfg in sorted(filt_root.items())
                if isinstance(fcfg, dict)]
        if not initial_filter_blocks:
            initial_filter_blocks = [(None, {})]
        # First filter panel sits in the canonical "filtering" slot
        # of _step_widgets.  Extras (Phase 2 multi-block) come right
        # after it; once allow_reorder is on, ↑↓ + the [+] header
        # button let the user grow / move them.
        first_id, first_cfg = initial_filter_blocks[0]
        filt_grp, _ = self._build_filter_panel(first_id, first_cfg)
        layout.addWidget(filt_grp)
        for extra_id, extra_cfg in initial_filter_blocks[1:]:
            extra_grp, _ = self._build_filter_panel(extra_id, extra_cfg)
            layout.addWidget(extra_grp)

        # ── ICA (Phase 4: Picard + ICLabel) ──────────────────────────
        ica_grp = CollapsibleStep(
            "ICA", checkable=True,
            checked=cfg.get("prepare_ica", False), reorderable=True,
            has_help=True, help_key="ica")
        self._add_step_info_row(ica_grp, "ica")
        ica_lay = ica_grp.contentWidget().layout()
        ica_cfg = cfg.get("ICA_EOG", {})

        # Top-level visible fields
        ig = QGridLayout()
        ica_lay.addLayout(ig)
        self._pp["ica_method"] = self._combo_row(
            ig, 0, "Algorithm:", "ICA_EOG.method",
            ["picard", "infomax", "fastica"],
            ica_cfg.get("method", "picard"))
        self._pp["ica_selector"] = self._combo_row(
            ig, 1, "Component selection:", "ICA_EOG.selector",
            ["iclabel", "find_bads", "manual", "both"],
            ica_cfg.get("selector", "iclabel"))
        self._pp["ica_fit_hp"] = self._entry_row(
            ig, 2, "Fit high-pass [Hz]:", "ICA_EOG.fit_highpass_hz",
            ica_cfg.get("fit_highpass_hz", 1.0), width=60)
        self._pp["ica_reject"] = self._entry_row(
            ig, 2, "Reject [\u00b5V PTP]:", "ICA_EOG.reject_uv",
            ica_cfg.get("reject_uv", 500), width=60, col_offset=2)
        self._pp["ica_eog_ch"] = self._entry_row(
            ig, 3, "EOG reference channels:",
            "ICA_EOG.find_bads_eog_ch",
            ", ".join(ica_cfg.get("find_bads_eog_ch", ["Fp1", "Fp2", "Fpz"])),
            width=200)

        # ICLabel keep-list: 7-way class checkboxes
        iclabel_box = CollapsibleGroupBox(
            "ICLabel — classes to keep", collapsed=True)
        iclabel_box.setToolTip(
            "Check which ICLabel classes stay in the signal.\n"
            "Unchecked classes are removed via ica.apply(). The\n"
            "'other' class covers low-confidence components the\n"
            "classifier isn't sure about — keeping it by default\n"
            "is conservative (don't remove things you're unsure\n"
            "about). See Pion-Tonachini 2019.")
        icl_lay = QHBoxLayout(iclabel_box.contentWidget())
        icl_lay.setSpacing(6)
        keep_set = set(ica_cfg.get("iclabel_keep", ["brain", "other"]))
        _ICLABEL_TIPS = {
            "brain":
                "Brain activity — the signal you want to keep.\n"
                "Unchecking this removes literally the brain\n"
                "sources from the signal; don't do that.",
            "muscle":
                "EMG / muscle artifacts — high-frequency bursts\n"
                "from face, jaw, neck. Usually safe to remove.",
            "eye":
                "EOG / ocular artifacts — blinks and eye\n"
                "movements, typically frontal topography.\n"
                "Usually safe to remove.",
            "heart":
                "ECG / cardiac artifacts — QRS-shaped spikes\n"
                "from heartbeat pickup. Usually safe to remove.",
            "line_noise":
                "Power-line noise at 50 or 60 Hz. Usually safe\n"
                "to remove; notch filtering catches it too.",
            "channel_noise":
                "Single-channel discontinuities and dropouts —\n"
                "components dominated by one flaky electrode.\n"
                "Usually safe to remove.",
            "other":
                "Catch-all for components the classifier isn't\n"
                "confident about (max probability below the\n"
                "other classes). Kept by default as a safety net\n"
                "— removing 'other' can accidentally strip real\n"
                "brain activity the classifier missed.",
        }
        self._pp["iclabel_keep_checks"] = {}
        for cls_name in (
                "brain", "muscle", "eye", "heart",
                "line_noise", "channel_noise", "other"):
            cb = QCheckBox(cls_name)
            cb.setChecked(cls_name in keep_set)
            cb.setToolTip(_ICLABEL_TIPS[cls_name])
            icl_lay.addWidget(cb)
            self._pp["iclabel_keep_checks"][cls_name] = cb
        icl_lay.addStretch()
        ica_lay.addWidget(iclabel_box)

        # Advanced collapsed section
        adv_box = CollapsibleGroupBox("Advanced", collapsed=True)
        adv_grid = QGridLayout(adv_box.contentWidget())
        self._pp["ica_n_components"] = self._entry_row(
            adv_grid, 0, "n_components:", "ICA_EOG.n_components",
            ica_cfg.get("n_components", "rank"), width=80)
        self._pp["ica_decim"] = self._entry_row(
            adv_grid, 0, "decim:", "ICA_EOG.decim",
            ica_cfg.get("decim", 1), width=50, col_offset=2)
        self._pp["ica_random_state"] = self._entry_row(
            adv_grid, 1, "random_state:", "ICA_EOG.random_state",
            ica_cfg.get("random_state", 42), width=80)
        self._pp["ica_iclabel_min_prob"] = self._entry_row(
            adv_grid, 1, "ICLabel min prob:",
            "ICA_EOG.iclabel_min_prob",
            ica_cfg.get("iclabel_min_prob", 0.0), width=50, col_offset=2)
        self._pp["ica_find_bads_ecg"] = QCheckBox("find_bads_ecg")
        self._pp["ica_find_bads_ecg"].setChecked(
            ica_cfg.get("find_bads_ecg", True))
        self._pp["ica_find_bads_ecg"].setToolTip(
            FIELD_TOOLTIPS.get("ICA_EOG.find_bads_ecg", ""))
        adv_grid.addWidget(self._pp["ica_find_bads_ecg"], 2, 0, 1, 2)
        self._pp["ica_find_bads_muscle"] = QCheckBox("find_bads_muscle")
        self._pp["ica_find_bads_muscle"].setChecked(
            ica_cfg.get("find_bads_muscle", True))
        self._pp["ica_find_bads_muscle"].setToolTip(
            FIELD_TOOLTIPS.get("ICA_EOG.find_bads_muscle", ""))
        adv_grid.addWidget(self._pp["ica_find_bads_muscle"], 2, 2, 1, 2)
        ica_lay.addWidget(adv_box)

        self._pp["ica_save_components_audit"] = QCheckBox(
            "Save components plot and table")
        self._pp["ica_save_components_audit"].setChecked(
            ica_cfg.get("save_components_audit", False))
        self._pp["ica_save_components_audit"].setToolTip(
            FIELD_TOOLTIPS.get("ICA_EOG.save_components_audit", ""))
        ica_lay.addWidget(self._pp["ica_save_components_audit"])

        self._pp["_ica_grp"] = ica_grp
        self._add_step_actions(ica_grp, "ica")
        self._make_reorder_buttons(ica_grp, "ica")
        _wire_help(ica_grp, "ica", "ICA")
        self._add_save_checkbox(ica_grp, "ica", cfg=cfg)

        # Header info: "picard, iclabel (keep brain+other)" — algorithm,
        # selector mode, and (when ICLabel is in use) the kept classes.
        ica_info = QLabel("")
        ica_info.setStyleSheet("color: gray;")
        self._pp["ica_header_info"] = ica_info

        def _update_ica_info(*_a, lbl=ica_info):
            pp = self._pp
            algo = pp["ica_method"].currentText()
            selector = pp["ica_selector"].currentText()
            bits = [algo, selector]
            if selector in ("iclabel", "both"):
                kept = [
                    name for name, cb in pp["iclabel_keep_checks"].items()
                    if cb.isChecked()]
                if kept:
                    bits.append(f"keep {'+'.join(kept)}")
            lbl.setText(", ".join(bits))

        self._pp["ica_method"].currentTextChanged.connect(_update_ica_info)
        self._pp["ica_selector"].currentTextChanged.connect(_update_ica_info)
        for _cb in self._pp["iclabel_keep_checks"].values():
            _cb.stateChanged.connect(_update_ica_info)
        _update_ica_info()

        layout.addWidget(ica_grp)

        # ── EEG artifacts (artifacts) ────────────────────────────────
        art_grp = CollapsibleStep(
            "EEG artifacts", checkable=True,
            checked=cfg.get("prepare_eeg_artifacts", False),
            reorderable=True,
            has_help=True, help_key="artifacts")
        self._add_step_info_row(art_grp, "artifacts")
        art_lay = art_grp.contentWidget().layout()
        ag_top = QGridLayout()
        art_lay.addLayout(ag_top)
        self._pp["art_thr"] = self._entry_row(
            ag_top, 0, "Max artifact fraction:", "artifacts.artifact_threshold",
            art.get("artifact_threshold", 0.3))
        # -- Slope detection (P2P) --
        slope_box = CollapsibleGroupBox(
            "Slope detection  (P2P)", checkable=True, checked=art.get("enable_slopes", True), collapsed=True)
        sg = QGridLayout(slope_box.contentWidget())
        self._pp["en_slopes"] = slope_box  # use the group's check state
        self._pp["slope_win"] = self._entry_row(
            sg, 0, "Window [s]:", "artifacts.SlopeWindow",
            rp.get("SlopeWindow", 0.0704))
        self._pp["slope_abs"] = self._entry_row(
            sg, 0, "Abs threshold:", "artifacts.SlopesAbsThr",
            rp.get("SlopesAbsThr", 150), col_offset=2)
        self._pp["slope_std"] = self._entry_row(
            sg, 1, "Std\u00d7:", "artifacts.SlopesStdThr",
            rp.get("SlopesStdThr", 7))
        self._pp["slope_med"] = self._entry_row(
            sg, 1, "Med\u00d7:", "artifacts.SlopesMedThr",
            rp.get("SlopesMedThr", 6), col_offset=2)
        art_lay.addWidget(slope_box)
        # -- Outlier detection (outliers) --
        outl_box = CollapsibleGroupBox(
            "Outlier detection  (outliers)", checkable=True, checked=art.get("enable_outliers", True), collapsed=True)
        og = QGridLayout(outl_box.contentWidget())
        self._pp["en_outliers"] = outl_box
        self._pp["out_merge"] = self._entry_row(
            og, 0, "Merge window:", "artifacts.OutliersMergeWin",
            rp.get("OutliersMergeWin", 0.1))
        self._pp["out_abs"] = self._entry_row(
            og, 0, "Abs threshold:", "artifacts.OutliersAbsThr",
            rp.get("OutliersAbsThr", 150), col_offset=2)
        self._pp["out_std"] = self._entry_row(
            og, 1, "Std\u00d7:", "artifacts.OutliersStdThr",
            rp.get("OutliersStdThr", 7))
        self._pp["out_med"] = self._entry_row(
            og, 1, "Med\u00d7:", "artifacts.OutliersMedThr",
            rp.get("OutliersMedThr", 13), col_offset=2)
        art_lay.addWidget(outl_box)
        # -- Muscle detection (muscles) --
        musc_box = CollapsibleGroupBox(
            "Muscle detection  (muscles)", checkable=True, checked=art.get("enable_muscles", True), collapsed=True)
        mg2 = QGridLayout(musc_box.contentWidget())
        self._pp["en_muscles"] = musc_box
        self._pp["musc_win"] = self._entry_row(
            mg2, 0, "Window [s]:", "artifacts.MusclesWindow",
            rp.get("MusclesWindow", 0.5))
        self._pp["musc_freq"] = self._entry_row(
            mg2, 0, "Freq range:", "artifacts.MusclesFreqRange",
            f"{rp.get('MusclesFreqRange', [40, 90])[0]}, "
            f"{rp.get('MusclesFreqRange', [40, 90])[1]}", col_offset=2)
        self._pp["musc_abs"] = self._entry_row(
            mg2, 1, "Abs threshold:", "artifacts.MusclesAbsThr",
            rp.get("MusclesAbsThr", 0.15))
        self._pp["musc_std"] = self._entry_row(
            mg2, 1, "Std\u00d7:", "artifacts.MusclesStdThr",
            rp.get("MusclesStdThr", 7), col_offset=2)
        self._pp["musc_med"] = self._entry_row(
            mg2, 2, "Med\u00d7:", "artifacts.MusclesMedThr",
            rp.get("MusclesMedThr", 5))
        art_lay.addWidget(musc_box)
        # -- Amplitude thresholding (amplitude_artifacts) --
        amp_box = CollapsibleGroupBox(
            "Amplitude thresholding  (amplitude_artifacts)", checkable=True, checked=art.get("enable_amplitude", True), collapsed=True)
        ampg = QGridLayout(amp_box.contentWidget())
        self._pp["en_amp"] = amp_box
        # Defaults must match ide4eeg/input/input.py check_and_prepare_config()
        # so the GUI and CLI paths agree on thresholds.
        self._pp["amp_max"] = self._entry_row(
            ampg, 0, "Max [\u00b5V]:", "amplitude_max_threshold",
            cfg.get("amplitude_max_threshold", 150e-6) * 1e6)
        self._pp["amp_time"] = self._entry_row(
            ampg, 0, "Time [s]:", "amplitude_time_threshold",
            cfg.get("amplitude_time_threshold", 0.02), col_offset=2)
        self._pp["amp_nchan"] = self._entry_row(
            ampg, 1, "Chan fraction:", "amplitude_nchan_threshold",
            cfg.get("amplitude_nchan_threshold", 0.33))
        art_lay.addWidget(amp_box)
        self._pp["art_save_plots"] = QCheckBox(
            "Save detection plots")
        self._pp["art_save_plots"].setChecked(
            art.get("save_plots", False))
        self._pp["art_save_plots"].setToolTip(
            FIELD_TOOLTIPS.get("artifacts.save_plots", ""))
        art_lay.addWidget(self._pp["art_save_plots"])
        self._pp["art_save_tag"] = QCheckBox(
            "Save Svarog .tag file")
        self._pp["art_save_tag"].setChecked(
            art.get("save_tag", False))
        self._pp["art_save_tag"].setToolTip(
            FIELD_TOOLTIPS.get("artifacts.save_tag", ""))
        art_lay.addWidget(self._pp["art_save_tag"])
        self._pp["_art_grp"] = art_grp
        self._add_step_actions(art_grp, "artifacts")
        self._make_reorder_buttons(art_grp, "artifacts")
        _wire_help(art_grp, "artifacts", "EEG artifacts")
        self._add_save_checkbox(art_grp, "artifacts", cfg=cfg)

        # Header info: "slopes+outliers+muscles+amp, thr 30%" —
        # which sub-detectors are enabled and the artifact_threshold.
        art_info = QLabel("")
        art_info.setStyleSheet("color: gray;")
        self._pp["art_header_info"] = art_info

        def _update_art_info(*_a, lbl=art_info):
            pp = self._pp
            detectors = [
                ("slopes", "en_slopes"),
                ("outliers", "en_outliers"),
                ("muscles", "en_muscles"),
                ("amp", "en_amp"),
            ]
            on = [name for name, key in detectors if pp[key].isChecked()]
            bits = []
            if on:
                bits.append("+".join(on))
            else:
                bits.append("no detectors")
            try:
                thr = float(pp["art_thr"].text() or 0)
                if thr > 0:
                    bits.append(f"thr {thr * 100:g}%")
            except ValueError:
                pass
            lbl.setText(", ".join(bits))

        # CollapsibleGroupBox wraps a QCheckBox internally; the public
        # API has isChecked() but no toggled signal — connect to the
        # inner checkbox's stateChanged.
        for _k in ("en_slopes", "en_outliers", "en_muscles", "en_amp"):
            _box = self._pp[_k]
            if _box._checkbox is not None:
                _box._checkbox.stateChanged.connect(_update_art_info)
        self._pp["art_thr"].textChanged.connect(_update_art_info)
        _update_art_info()

        layout.addWidget(art_grp)

        # ── MP Decomposition (mp_decomposition) ──────────────────────
        from ide4eeg.main import mp_decomposition_enabled
        mp_grp = CollapsibleStep(
            "MP Decomposition",
            checkable=True,
            checked=mp_decomposition_enabled(cfg),
            reorderable=True,
            has_help=True, help_key="mp_decomposition")
        self._add_step_info_row(mp_grp, "mp_decomposition")
        # Tooltip on the checkbox: explain reuse semantics introduced
        # by the MP-book-reuse change — uncheck = reuse cached book if
        # hash matches; check = force recompute (overwrites .db).
        if mp_grp._checkbox is not None:
            mp_grp._checkbox.setToolTip(
                "Unchecked: reuse existing book on disk if its\n"
                "hash matches the current config (fast).\n"
                "Check to recompute — required after changing\n"
                "channels, segments, or MP parameters.")
        mp_lay = mp_grp.contentWidget().layout()
        mp_lay.setSpacing(0)
        pw = 40
        # Algorithm combo (on top, no label).
        # Labels and order come from MP_ALGORITHMS — single source of truth.
        algo = mp.get("algorithm", "smp")
        _algo_choices = mp_algorithm_choices()  # [(name, label), ...]
        _algo_labels = [label for _, label in _algo_choices]
        self._pp["mp_algo"] = QComboBox()
        self._pp["mp_algo"].setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self._pp["mp_algo"].setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._pp["mp_algo"].setToolTip(
            FIELD_TOOLTIPS.get("matching_pursuit.algorithm", ""))
        self._pp["mp_algo"].addItems(_algo_labels)
        # Restore the selected algorithm; fall back to the first if unknown
        self._pp["mp_algo"].setCurrentText(
            next((label for name, label in _algo_choices if name == algo),
                 _algo_labels[0]))
        # Parameters (flow_pairs, same line as algorithm combo)
        self._pp["mp_iter"] = QLineEdit(str(mp.get("iterations", 30)))
        self._pp["mp_iter"].setFixedWidth(pw)
        self._pp["mp_iter"].setToolTip(
            FIELD_TOOLTIPS.get("matching_pursuit.iterations", ""))
        re_pct = mp.get("explained_energy", 0.99) * 100
        self._pp["mp_energy"] = QLineEdit(f"{re_pct:.0f}")
        self._pp["mp_energy"].setFixedWidth(pw)
        self._pp["mp_energy"].setToolTip(
            FIELD_TOOLTIPS.get("matching_pursuit.explained_energy", ""))
        self._pp["mp_energy"].editingFinished.connect(
            self._validate_mp_energy)
        self._pp["mp_dict_size"] = QLabel("")
        self._pp["mp_dict_size"].setStyleSheet("color: gray;")
        self._pp["mp_iter"].textChanged.connect(self._update_mp_dict_size)
        self._pp["mp_algo"].currentTextChanged.connect(
            self._update_mp_dict_size)
        # Value semantics for matching_pursuit.cpu_workers:
        #   0  → inherit from Config tab's "Parallel jobs" (parallelism.n_jobs).
        #        The QLineEdit text is empty and the *placeholder* shows
        #        the currently effective inherited value as grey italic —
        #        so the user sees "the number MP will use" at a glance
        #        without accidentally turning it into an override. The
        #        placeholder refreshes live when the Config tab field
        #        changes.
        #   >0 → explicit override. The QLineEdit holds the real string
        #        "5", "8", etc. empi runs with this many workers
        #        regardless of parallelism.n_jobs. Power-user escape
        #        hatch because empi's shared-memory cost model is
        #        cheaper on RAM than joblib's per-worker Python
        #        processes — somebody might reasonably want MORE empi
        #        workers than joblib workers.
        _cfg_workers = int(mp.get("cpu_workers", 0) or 0)
        self._pp["mp_workers"] = QLineEdit()
        if _cfg_workers > 0:
            self._pp["mp_workers"].setText(str(_cfg_workers))
        self._pp["mp_workers"].setFixedWidth(28)
        self._pp["mp_workers"].setToolTip(
            FIELD_TOOLTIPS.get("matching_pursuit.cpu_workers", ""))
        mp_lay.addWidget(_flow_pairs([
            self._pp["mp_algo"],
            (QLabel("Max iter."), self._pp["mp_iter"]),
            (QLabel("Energy %"), self._pp["mp_energy"]),
            self._pp["mp_dict_size"],
        ]))
        _cores_row = QHBoxLayout()
        _cl1 = QLabel("use"); _cl1.setStyleSheet("color: gray;")
        _cores_row.addWidget(_cl1)
        _cores_row.addWidget(self._pp["mp_workers"])
        self._pp["mp_workers_readout"] = QLabel("")
        self._pp["mp_workers_readout"].setStyleSheet("color: gray;")
        _cores_row.addWidget(self._pp["mp_workers_readout"])
        _cores_row.addStretch()
        mp_lay.addLayout(_cores_row)
        self._pp["mp_workers_warn"] = QLabel("")
        self._pp["mp_workers_warn"].setStyleSheet(
            _WARN_LABEL_QSS + " margin-left: 12px;")
        self._pp["mp_workers_warn"].setWordWrap(True)
        self._pp["mp_workers_warn"].setVisible(False)
        mp_lay.addWidget(self._pp["mp_workers_warn"])
        self._pp["mp_workers"].textChanged.connect(
            self._update_mp_workers_readout)
        self._update_mp_workers_readout()
        # Channels subpanel
        self._pp["mp_channels"] = ChannelPanel(title="Channels", eeg_filter=True)
        mp_lay.addWidget(self._pp["mp_channels"])
        self._register_channel_panel(self._pp["mp_channels"])
        # Run + atom output checkboxes in one row
        self._pp["mp_csv"] = QCheckBox("Atom stats CSV")
        self._pp["mp_csv"].setChecked(
            mp.get("outputs", {}).get("atom_stats_csv", False))
        self._pp["mp_csv"].setToolTip(
            "Write a CSV table of all decomposition atoms\n"
            "(frequency, time, width, amplitude, phase, energy)\n"
            "per channel and per epoch. Useful for custom\n"
            "downstream statistics and for exporting atoms to\n"
            "external tools.")
        self._pp["mp_hist"] = QCheckBox("Atom histograms")
        self._pp["mp_hist"].setChecked(
            mp.get("outputs", {}).get("atom_histograms", False))
        self._pp["mp_hist"].setToolTip(
            "Save per-channel histograms of atom parameters\n"
            "(frequency, time, width, amplitude) as PNG plots.\n"
            "Useful for quickly inspecting the shape of the\n"
            "decomposition.")
        # Run row: kicks off a truncated pipeline through MP via the
        # unified runner.  Progress + cancel live on the Run tab now;
        # ``mp_run_status`` stays as a glanceable post-run indicator
        # (Running... / Done / Error) for when the user comes back to
        # the MP panel after the run.
        mp_run_row = QWidget()
        mprh = QHBoxLayout(mp_run_row)
        mprh.setContentsMargins(0, 4, 0, 0)
        self._pp["mp_run_btn"] = QPushButton("Run decomposition")
        self._pp["mp_run_btn"].setStyleSheet(
            "QPushButton { padding: 6px 16px; font-weight: bold; }")
        self._pp["mp_run_btn"].clicked.connect(self._run_mp_decomposition)
        mprh.addWidget(self._pp["mp_run_btn"])
        self._pp["mp_run_status"] = QLabel("")
        mprh.addWidget(self._pp["mp_run_status"])
        mprh.addWidget(self._pp["mp_csv"])
        mprh.addWidget(self._pp["mp_hist"])
        mprh.addStretch()
        mp_lay.addWidget(mp_run_row)
        self._pp["_mp_grp"] = mp_grp
        if mp_grp._checkbox:
            mp_grp._checkbox.stateChanged.connect(
                lambda _: self._refresh_book_panels())
        self._pp["mp_algo"].currentTextChanged.connect(
            lambda _: self._refresh_book_panels())
        self._pp["mp_channels"].selection_changed.connect(
            self._refresh_book_panels)
        # The "(from pipeline)" entry in book panels (Profiles, Dipole)
        # embeds max-iter and residual-energy in its label via
        # ``_mp_pipeline_info``.  Use editingFinished (focus-loss /
        # Enter) rather than textChanged so we don't rebuild every
        # combo + reread SQLite metadata on every keystroke.
        self._pp["mp_iter"].editingFinished.connect(
            self._refresh_book_panels)
        self._pp["mp_energy"].editingFinished.connect(
            self._refresh_book_panels)
        self._make_reorder_buttons(mp_grp, "mp_decomposition")
        _wire_help(mp_grp, "mp_decomposition", "MP Decomposition")
        self._add_save_checkbox(
            mp_grp, "mp_decomposition",
            label="Save MP book (.db)",
            tooltip="MP decomposition always saves the atom book as "
                    "a .db file. The\n"
                    "  book IS the output of this step.",
            forced=True)

        # Header info, two modes:
        #   • Book on disk for current input → show its symbol:
        #       all-EEG SMP    → "smp"
        #       SMP subset     → "Cz, C3"
        #       all-EEG MMP1   → "mmp1"
        #       MMP1 subset    → "mmp1: Cz, C3"
        #   • No book yet → show what an auto/manual run would use:
        #       "{algo}, {chs}, {iter}, {energy}%"
        # _refresh_book_panels (file load, MP run end) calls back in
        # so the line flips from "params" to "book symbol" as soon as
        # the .db lands on disk.
        mp_info = QLabel("")
        mp_info.setStyleSheet("color: gray;")
        self._pp["mp_header_info"] = mp_info

        def _update_mp_info(*_a, lbl=mp_info):
            pp = self._pp
            symbol = self._recent_mp_book_symbol()
            if symbol:
                lbl.setText(symbol)
                return
            # Combo's currentText is the long display form
            # ("mmp1 — multivariate, constant phase"); the header
            # only wants the short algo name.
            algo = parse_mp_algorithm_label(
                pp["mp_algo"].currentText())
            chs = self._mp_pipeline_channels()
            n = len(chs)
            n_eeg = self._cached_eeg_channel_count()
            if n == 0:
                ch_str = "no chs"
            elif n_eeg and n == n_eeg:
                ch_str = "all chs"
            elif n <= 5:
                ch_str = ", ".join(chs)
            else:
                ch_str = f"{n} chs"
            it = pp["mp_iter"].text().strip()
            en = pp["mp_energy"].text().strip()
            bits = [algo, ch_str]
            if it:
                bits.append(f"{it} iter")
            if en:
                bits.append(f"{en}% energy")
            lbl.setText(", ".join(bits))

        self._update_mp_header_info = _update_mp_info
        self._pp["mp_algo"].currentTextChanged.connect(_update_mp_info)
        self._pp["mp_iter"].textChanged.connect(_update_mp_info)
        self._pp["mp_energy"].textChanged.connect(_update_mp_info)
        self._pp["mp_channels"].selection_changed.connect(_update_mp_info)
        _update_mp_info()

        layout.addWidget(mp_grp)

        # ── MP Filter (mp_filter) ────────────────────────────────────
        mpf_grp = CollapsibleStep(
            "MP Filter",
            checkable=True,
            checked=cfg.get("prepare_mp_filter", False),
            reorderable=True,
            has_help=True, help_key="mp_filter")
        self._add_step_info_row(mpf_grp, "mp_filter")
        mpf_lay = mpf_grp.contentWidget().layout()
        mpf_desc = QLabel("MP Nonlinear Filter  (reconstruct from atom subset)")
        mpf_desc.setStyleSheet("color: gray;")
        mpf_lay.addWidget(mpf_desc)
        mfg = QGridLayout()
        mpf_lay.addLayout(mfg)
        self._pp["mpf_mode"] = self._combo_row(
            mfg, 0, "Mode:", "matching_pursuit.filter.mode",
            ["remove", "keep"], mp_flt.get("mode", "keep"))
        mpf_hint = QLabel("keep = matching atoms, remove = non-matching")
        mpf_hint.setStyleSheet("color: gray;")
        mfg.addWidget(mpf_hint, 0, 2, 1, 2)

        self._pp["mpf_atom_table"] = AtomFilterTable("Atom filter criteria")
        self._pp["mpf_atom_table"].set_single(mp_flt)
        _sf = getattr(self, "_cached_sfreq", None)
        if _sf:
            self._pp["mpf_atom_table"].set_freq_max_nyquist(int(_sf / 2))
        mfg.addWidget(self._pp["mpf_atom_table"], 1, 0, 1, 4)

        # Extra MP filter fields not in the atom table
        self._pp["mpf_tmin"] = self._entry_row(
            mfg, 2, "Time min [s]:", "matching_pursuit.filter.time_min",
            mp_flt.get("time_min", 0))
        self._pp["mpf_tmax"] = self._entry_row(
            mfg, 2, "Time max [s]:", "matching_pursuit.filter.time_max",
            mp_flt.get("time_max", 0), col_offset=2)
        self._pp["mpf_energy"] = self._entry_row(
            mfg, 3, "Min energy:", "matching_pursuit.filter.min_energy",
            mp_flt.get("min_energy", 0))
        self._pp["_mpf_grp"] = mpf_grp
        self._make_reorder_buttons(mpf_grp, "mp_filter")
        _wire_help(mpf_grp, "mp_filter", "MP Nonlinear Filter")
        self._add_save_checkbox(mpf_grp, "mp_filter", cfg=cfg)

        # Header info: "remove, 3 criteria" / "keep" — the filter mode
        # plus a row count for the atom-criteria table when non-empty.
        mpf_info = QLabel("")
        mpf_info.setStyleSheet("color: gray;")
        self._pp["mpf_header_info"] = mpf_info

        def _update_mpf_info(*_a, lbl=mpf_info):
            pp = self._pp
            mode = pp["mpf_mode"].currentText()
            bits = [mode]
            tbl = pp.get("mpf_atom_table")
            try:
                n = tbl.rowCount() if tbl is not None else 0
            except (AttributeError, TypeError):
                n = 0
            if n > 0:
                bits.append(f"{n} criteria")
            lbl.setText(", ".join(bits))

        self._pp["mpf_mode"].currentTextChanged.connect(_update_mpf_info)
        _update_mpf_info()

        layout.addWidget(mpf_grp)

        # ── Gaze (video_artifacts) ────────────────────────────────────
        gaze_grp = CollapsibleStep(
            "Gaze",
            checkable=True,
            checked=cfg.get("prepare_video_artifacts", False),
            reorderable=True,
            has_help=True, help_key="gaze")
        self._add_step_info_row(gaze_grp, "gaze")
        gaze_lay = gaze_grp.contentWidget().layout()
        # Group 1: Face detection
        id_box = QGroupBox("Face detection")
        id_vl = QVBoxLayout(id_box)
        # Hidden path fields (still needed for config collect/apply)
        self._pp["ref_dir"] = QLineEdit(cfg.get("video_reference_dir", ""))
        self._pp["ref_dir"].hide()
        self._pp["excl_dir"] = QLineEdit(cfg.get("video_exclude_dir", ""))
        self._pp["excl_dir"].hide()
        id_vl.addWidget(self._pp["ref_dir"])
        id_vl.addWidget(self._pp["excl_dir"])
        # Reference faces: pick button + count/path label + folder button
        ref_row = QHBoxLayout()
        btn_ref = QPushButton("Reference faces")
        btn_ref.setFixedWidth(130)
        btn_ref.setToolTip(
            "Select reference photos of the subject looking at the camera")
        btn_ref.clicked.connect(lambda: self._open_face_picker("reference"))
        ref_row.addWidget(btn_ref)
        self._pp["ref_count_lbl"] = QLabel(
            "subject looking at the screen, 0 selected")
        self._pp["ref_count_lbl"].setStyleSheet("color: gray;")
        self._pp["ref_count_lbl"].setWordWrap(True)
        ref_row.addWidget(self._pp["ref_count_lbl"], 1)
        btn_ref_dir = QPushButton("Change folder")
        btn_ref_dir.setFixedWidth(110)
        btn_ref_dir.setToolTip(
            "Point to a different folder of reference face images")
        btn_ref_dir.clicked.connect(
            lambda: self._change_face_folder("reference"))
        ref_row.addWidget(btn_ref_dir)
        id_vl.addLayout(ref_row)
        # Exclude faces: pick button + count/path label + folder button
        excl_row = QHBoxLayout()
        btn_excl = QPushButton("Exclude faces")
        btn_excl.setFixedWidth(130)
        btn_excl.setToolTip(
            "Select photos of non-subjects to exclude from detection")
        btn_excl.clicked.connect(lambda: self._open_face_picker("exclude"))
        excl_row.addWidget(btn_excl)
        self._pp["excl_count_lbl"] = QLabel(
            "non-subject(s), 0 selected")
        self._pp["excl_count_lbl"].setStyleSheet("color: gray;")
        self._pp["excl_count_lbl"].setWordWrap(True)
        excl_row.addWidget(self._pp["excl_count_lbl"], 1)
        btn_excl_dir = QPushButton("Change folder")
        btn_excl_dir.setFixedWidth(110)
        btn_excl_dir.setToolTip(
            "Point to a different folder of non-subject face images")
        btn_excl_dir.clicked.connect(
            lambda: self._change_face_folder("exclude"))
        excl_row.addWidget(btn_excl_dir)
        id_vl.addLayout(excl_row)
        # Keep old label for compatibility (hidden, updated by _update_face_counts)
        self._pp["face_count_lbl"] = QLabel("")
        self._pp["face_count_lbl"].hide()
        id_vl.addWidget(self._pp["face_count_lbl"])
        # Parameters live under a collapsible "Advanced parameters"
        # sub-box (parallel to the Bad channels tab) — most users stay
        # on the defaults, so we hide the knobs unless explicitly opened.
        pw = 40
        _fd_pairs = []
        for lbl_text, key, cfg_key, default in [
            ("Resize frame:", "det_size", "facetag_det_size", 0),
            ("Tolerance:", "face_tol", "facetag_face_tolerance", 0.6),
            ("Adapt rate:", "adapt", "facetag_tracking_adapt_rate", 0.5),
            ("Position lock:", "pos_w", "facetag_position_weight", 0.4),
            ("Size lock:", "size_w", "facetag_size_weight", 0.2),
            ("Switch resistance:", "switch_r",
             "facetag_switch_resistance", 0.25),
        ]:
            self._pp[key] = QLineEdit(str(cfg.get(cfg_key, default)))
            self._pp[key].setFixedWidth(pw)
            self._pp[key].setToolTip(FIELD_TOOLTIPS.get(cfg_key, ""))
            _fd_pairs.append((QLabel(lbl_text), self._pp[key]))
        fd_adv_box = CollapsibleGroupBox(
            "Advanced parameters", collapsed=True)
        fd_adv_v = QVBoxLayout(fd_adv_box.contentWidget())
        fd_adv_v.setSpacing(4)
        fd_adv_v.addWidget(_flow_pairs(_fd_pairs))
        id_vl.addWidget(fd_adv_box)
        gaze_lay.addWidget(id_box)
        # Group 2: Gaze estimation
        pw = 40
        gaze_est_box = QGroupBox("Gaze estimation")
        ge_vl = QVBoxLayout(gaze_est_box)
        self._pp["gaze_method"] = QComboBox()
        self._pp["gaze_method"].addItems(
            ["l2cs", "insightface"])
        self._pp["gaze_method"].setCurrentText(
            cfg.get("facetag_gaze_method", "l2cs"))
        self._pp["gaze_method"].setToolTip(
            FIELD_TOOLTIPS.get("facetag_gaze_method", ""))
        self._pp["gaze_method"].currentTextChanged.connect(
            self._check_gaze_deps)
        self._pp["gaze_method"].currentTextChanged.connect(
            self._refresh_gaze_method_badge)
        self._pp["gaze_method_badge"] = QLabel("")
        self._pp["gaze_method_badge"].setStyleSheet(_WARN_LABEL_QSS)
        self._pp["gaze_method_badge"].setToolTip(
            "L2CS-Net selected but a required package is not\n"
            "installed (torch and/or l2cs).\n"
            "Click 'Download recent' next to 'L2CS-Net (gaze\n"
            "detection)' on the Config tab, or switch the\n"
            "Method dropdown to 'insightface'.")
        self._pp["max_angle"] = QLineEdit(
            str(cfg.get("facetag_max_angle", 20.0)))
        self._pp["max_angle"].setFixedWidth(pw)
        self._pp["max_angle"].setToolTip(
            FIELD_TOOLTIPS.get("facetag_max_angle", ""))
        self._pp["gaze_smooth"] = QLineEdit(
            str(cfg.get("facetag_gaze_smoothing", 0.0)))
        self._pp["gaze_smooth"].setFixedWidth(pw)
        self._pp["gaze_smooth"].setToolTip(
            FIELD_TOOLTIPS.get("facetag_gaze_smoothing", ""))
        self._pp["ref_roi"] = QCheckBox("Use cropped face images")
        self._pp["ref_roi"].setChecked(cfg.get("facetag_ref_use_roi", False))
        self._pp["ref_roi"].setToolTip(
            FIELD_TOOLTIPS.get("facetag_ref_use_roi", ""))
        _ge_roi_spacer = QWidget()
        _ge_roi_spacer.setFixedWidth(20)
        ge_vl.addWidget(_flow_pairs([
            (QLabel("Method:"), self._pp["gaze_method"]),
            self._pp["gaze_method_badge"],
            (QLabel("Max angle:"), self._pp["max_angle"]),
            (QLabel("Smoothing:"), self._pp["gaze_smooth"]),
            (_ge_roi_spacer, self._pp["ref_roi"]),
        ]))
        self._refresh_gaze_method_badge()
        gaze_lay.addWidget(gaze_est_box)
        # Group 3: Processing
        proc_box = QGroupBox("Processing")
        pr_vl = QVBoxLayout(proc_box)
        _pr_pairs = []
        for lbl_text, key, cfg_key, default in [
            ("Frame skip:", "frame_skip", "facetag_frame_skip", 3),
            ("Detection skip:", "det_skip", "facetag_detection_skip", 3),
            ("Downscale:", "downscale", "facetag_downscale", 1.0),
            ("Min interval:", "min_iv", "facetag_min_interval", 0.0),
        ]:
            self._pp[key] = QLineEdit(str(cfg.get(cfg_key, default)))
            self._pp[key].setFixedWidth(pw)
            self._pp[key].setToolTip(FIELD_TOOLTIPS.get(cfg_key, ""))
            _pr_pairs.append((QLabel(lbl_text), self._pp[key]))
        self._pp["no_face"] = QCheckBox("No face = not looking")
        self._pp["no_face"].setChecked(
            cfg.get("facetag_no_face_is_artifact", True))
        self._pp["no_face"].setToolTip(
            FIELD_TOOLTIPS.get("facetag_no_face_is_artifact", ""))
        _pr_noface_spacer = QWidget()
        _pr_noface_spacer.setFixedWidth(20)
        _pr_pairs.append((_pr_noface_spacer, self._pp["no_face"]))
        pr_vl.addWidget(_flow_pairs(_pr_pairs))
        gaze_lay.addWidget(proc_box)
        # Detection is driven entirely by the panel-header 👁 (eye)
        # button now: it opens the review window with auto_run=True,
        # which auto-loads any prior review.json (no re-detection)
        # or kicks off detection if there are no prior results.  The
        # in-window [Run Detection] button covers manual re-runs.
        # The previous in-panel [Detect gaze] / [Detect gaze in
        # background] buttons + their progress row have been removed
        # — pipeline detection during Run All shows progress in the
        # Run-tab progress bar via the "video" _PROGRESS_PATTERNS row.
        gaze_cfg = cfg.get("gaze", {}) or {}
        self._pp["gaze_save_tag"] = QCheckBox(
            "Save Svarog .tag file")
        self._pp["gaze_save_tag"].setChecked(
            gaze_cfg.get("save_tag", False))
        self._pp["gaze_save_tag"].setToolTip(
            FIELD_TOOLTIPS.get("gaze.save_tag", ""))
        gaze_lay.addWidget(self._pp["gaze_save_tag"])
        self._pp["_gaze_grp"] = gaze_grp
        self._make_reorder_buttons(gaze_grp, "gaze")
        _wire_help(gaze_grp, "gaze", "Gaze")
        self._add_save_checkbox(gaze_grp, "gaze", cfg=cfg)

        # Header info: "ref 8, excl 0" — counts of selected reference
        # / exclude face images.  Refreshed by ``_update_face_counts``
        # alongside the body labels.
        gaze_info = QLabel("")
        gaze_info.setStyleSheet("color: gray;")
        self._pp["gaze_header_info"] = gaze_info

        layout.addWidget(gaze_grp)

        # Wire face count updates to directory edits
        self._pp["ref_dir"].textChanged.connect(self._update_face_counts)
        self._pp["excl_dir"].textChanged.connect(self._update_face_counts)
        self._update_face_counts()

        # ── Drop Segments (remove_bad_segments) ──────────────────────
        # Non-reorderable postamble step: PTP thresholds applied after
        # cut_segments. Placed visually after Cut Segments below.
        seg_grp = CollapsibleStep(
            "Drop Segments",
            checkable=True, checked=sr.get("enabled", False),
            has_help=True, help_key="segment_rejection")
        self._add_step_info_row(seg_grp, "segment_rejection")
        segrg = QGridLayout()
        seg_grp.contentWidget().layout().addLayout(segrg)
        self._pp["seg_reject"] = self._entry_row(
            segrg, 0, "Reject threshold [\u00b5V]:",
            "segment_rejection.reject_threshold",
            sr.get("reject_threshold", 0))
        seg_reject_hint = QLabel("(0 = auto-detect from data)")
        seg_reject_hint.setStyleSheet("color: gray;")
        segrg.addWidget(seg_reject_hint, 0, 2)
        self._pp["seg_flat"] = self._entry_row(
            segrg, 1, "Flat threshold [\u00b5V]:",
            "segment_rejection.flat_threshold",
            sr.get("flat_threshold", 0))
        seg_flat_hint = QLabel("(0 = disabled)")
        seg_flat_hint.setStyleSheet("color: gray;")
        segrg.addWidget(seg_flat_hint, 1, 2)
        self._pp["seg_pct"] = self._entry_row(
            segrg, 2, "Auto percentile:",
            "segment_rejection.auto_percentile",
            sr.get("auto_percentile", 95.0))
        seg_pct_hint = QLabel("(used when reject = 0; e.g. 95 = reject top 5%)")
        seg_pct_hint.setStyleSheet("color: gray;")
        segrg.addWidget(seg_pct_hint, 2, 2)
        # Interactive review (Svarog when jar supports bad_epochs,
        # MNE interactive plot otherwise).  Checkboxes gate review
        # on every Run; the "Review now" button kicks off a one-off
        # preprocessing run terminating at the review (no analyses).
        _rev_row = QHBoxLayout()
        # Segmentation mode is exclusive (rest OR epochs); rather
        # than expose both per-mode review flags in the UI, we drive
        # one unified checkbox that writes the same boolean to both
        # config keys.  On load we take the OR of the two so
        # CLI-authored configs that only set one still initialize
        # the unified widget.
        self._pp["check_segments"] = QCheckBox("Review segments manually")
        self._pp["check_segments"].setChecked(
            bool(rest.get("check_rest", False))
            or bool(ep.get("check_epochs", False)))
        self._pp["check_segments"].setToolTip(
            "Pause the pipeline at segmentation to open the review\n"
            "  UI (Svarog's bad-epochs panel when the jar supports\n"
            "  it; MNE's interactive browser otherwise).\n"
            "Applies to whichever segmentation mode is active above.")
        _rev_row.addWidget(self._pp["check_segments"])
        _rev_row.addStretch()
        _rev_btn = QPushButton("Review now")
        _rev_btn.setFixedWidth(110)
        _rev_btn.setToolTip(
            "Run preprocessing up to segmentation and open the\n"
            "segment-review UI (Svarog or MNE).  Analyses are skipped;\n"
            "the review uses the segmentation mode active above.")
        _rev_btn.clicked.connect(self._manual_segment_review)
        self._pp["seg_review_btn"] = _rev_btn
        _rev_row.addWidget(_rev_btn)
        seg_grp.contentWidget().layout().addLayout(_rev_row)
        self._pp["_seg_grp"] = seg_grp

        # Brief PTP-rejection summary in the header — "reject 100 µV,
        # flat 1 µV, review" / "auto p95, review" — so the current
        # parameters are visible at a glance even when the panel is
        # collapsed.  Format mirrors the filtering panel's header info.
        seg_info = QLabel("")
        seg_info.setStyleSheet("color: gray;")
        self._pp["seg_header_info"] = seg_info

        def _update_seg_info(*_a, lbl=seg_info):
            pp = self._pp

            def _to_num(s, default=0.0):
                try:
                    return float(s) if s else default
                except ValueError:
                    return default

            rj = _to_num(pp["seg_reject"].text())
            fl = _to_num(pp["seg_flat"].text())
            pct = _to_num(pp["seg_pct"].text(), 95.0)
            bits = []
            if rj > 0:
                bits.append(f"reject {rj:g} µV")
            else:
                bits.append(f"auto p{pct:g}")
            if fl > 0:
                bits.append(f"flat {fl:g} µV")
            rev = pp.get("check_segments")
            if rev is not None and rev.isChecked():
                bits.append("review")
            lbl.setText(", ".join(bits))

        for _k in ("seg_reject", "seg_flat", "seg_pct"):
            self._pp[_k].textChanged.connect(_update_seg_info)
        self._pp["check_segments"].stateChanged.connect(_update_seg_info)
        _update_seg_info()

        _wire_help(seg_grp, "segment_rejection", "Drop Segments")

        # ── Postamble divider ────────────────────────────────────────
        # Marks the visual transition from reorderable steps above to
        # the always-runs postamble (cut_segments → drop_segments →
        # save_segments).  Cut Segments has no user-facing knobs of
        # its own — params come from segmentation_setup / [rest] /
        # [epochs] — so it gets no panel; this divider stands in as
        # the "you've crossed into postamble territory" cue.
        _postamble_lbl = QLabel("──  Postamble  ──")
        _postamble_lbl.setStyleSheet(
            "color: #888; font-style: italic; "
            "padding: 10px 0 4px 0;")
        _postamble_lbl.setAlignment(Qt.AlignCenter)
        _postamble_lbl.setToolTip(
            "After your reorderable steps, the pipeline always\n"
            "cuts segments using [segmentation] / [rest] / [epochs]\n"
            "(see the Segmentation setup panel above), then drops\n"
            "bad ones via the Drop Segments panel below, then saves\n"
            "the cleaned epochs as <base>_clean_<mode>-epo.fif.")
        layout.addWidget(_postamble_lbl)
        # Drop Segments sits after Cut Segments (postamble order).
        # Wire the cabinet (forced — _save_segments runs every time)
        # and the eye (opens the saved Epochs in MNE) here, since
        # this is the panel whose output the saved file represents.
        self._add_save_checkbox(
            seg_grp, "segment_rejection",
            label="Save cleaned Epochs (-epo.fif)",
            tooltip="The pipeline always writes the post-rejection "
                    "Epochs as\n  <base>_clean_<mode>-epo.fif — the "
                    "cleaned Epochs IS the\n  output of preprocessing.",
            forced=True)
        # Eye and the panel-body "Review now" button share the same
        # callback — both run preprocessing through segmentation,
        # then open Svarog's bad-epochs panel (or MNE's interactive
        # browser as a fallback).
        seg_grp.enable_view_button(
            tooltip=("Run preprocessing up to segmentation and open\n"
                     "the segment-review UI (Svarog or MNE\n"
                     "fallback) — same as the 'Review now' button\n"
                     "in the panel body."),
            callback=self._manual_segment_review)
        # Park the PTP summary label immediately to the left of the
        # eye, mirroring the trim / resample / filtering panels.
        _seg_hdr = seg_grp._header_layout
        _seg_hdr.insertWidget(
            _seg_hdr.indexOf(seg_grp._view_btn),
            self._pp["seg_header_info"])
        layout.addWidget(seg_grp)

        # Store step widgets for reorder.  Order must match the
        # construction order above (i.e. the initial layout order) so
        # that the very first call to ``_repack_preproc_steps`` — which
        # reinserts widgets in ``_step_widgets`` order — is a no-op
        # rather than a surprise rearrangement.
        # Filter panels live in self._filter_widgets keyed by id.
        # Splice each into the step list as ("filtering:<id>", grp).
        _filter_entries = [
            (f"filtering:{fid}", grp)
            for fid, grp in self._filter_widgets]
        self._step_widgets = [
            ("trim", trim_grp),
            ("select", sel_grp),
            ("bad_channels", bad_grp),
            ("montage", mont_grp),
            ("reference", ref_grp),
            ("resample", resample_grp),
            *_filter_entries,
            ("ica", ica_grp),
            ("artifacts", art_grp),
            ("mp_decomposition", mp_grp),
            ("mp_filter", mpf_grp),
            ("gaze", gaze_grp),
        ]
        self._preproc_scroll_layout = layout

        # Only steps whose pipeline names have a _STEP_SAVE_MAP entry
        # can produce a before/after snapshot; the rest (mp_decomposition,
        # segment_rejection) are intentionally skipped.  ``gaze`` shares
        # the artifacts step with the EEG-artifacts panel, so it gets
        # an eye that views the same artifacts-marked snapshot.
        _viewable_gui_keys = {
            gui_key
            for gui_key, pipe_names in self._GUI_TO_PIPELINE_STEPS.items()
            if any(p in _STEP_SAVE_MAP for p in pipe_names)
        }
        for gui_key, grp in self._step_widgets:
            # Multi-instance keys ("filtering:<id>") are viewable iff
            # the base ("filtering") is.  Strip the suffix when
            # checking, but pass the full id-suffixed key into the
            # _view_step_result callback so the snapshot lookup
            # targets the right per-instance file.
            base_key = gui_key.partition(":")[0]
            if base_key not in _viewable_gui_keys:
                continue
            step_label = self._STEP_LABELS.get(gui_key) \
                or self._STEP_LABELS.get(base_key, gui_key)
            if base_key == "trim":
                # The generic before/after Svarog split view aligns
                # the cropped signal by sample index, which makes
                # the time labels mismatch and obscures what was
                # actually trimmed.  The dedicated Preview & Trim
                # window shows the full recording with shaded trim
                # regions and is far easier to read, so we route
                # the eye there directly.
                grp.enable_view_button(
                    tooltip=(
                        "Open the Preview & Trim window — full\n"
                        "recording overview with the trim region\n"
                        "shaded; click on the canvas to set start /\n"
                        "end, or type values directly."),
                    callback=self._open_trim_preview)
            elif base_key == "bad_channels":
                # Bad Channels has its own truncated-run flow that
                # surfaces detected bads in the panel header / body
                # label rather than opening a before/after viewer.
                # Wire the eye to that flow (replaces the old in-panel
                # "Run and check" button).
                grp.enable_view_button(
                    tooltip=(
                        "Run all steps up to this stage and detect\n"
                        "bad channels.  Detected names appear in the\n"
                        "panel header and body label."),
                    callback=self._view_bad_channels)
            elif base_key == "select":
                # Drop Channels has no "before/after" worth showing —
                # the panel itself *is* the editable view.  Wire the
                # eye to the Svarog round-trip flow that the old
                # in-panel "Mark in Svarog" button used: opens the
                # signal in Svarog with currently-dropped channels
                # preselected, syncs the result back to the panel.
                grp.enable_view_button(
                    tooltip=(
                        "Open the input signal in Svarog with the\n"
                        "channels currently marked-for-drop\n"
                        "preselected.  Add or remove channels in\n"
                        "Svarog and save — the panel will update with\n"
                        "your selection."),
                    callback=self._mark_dropped_in_svarog)
            elif base_key == "artifacts":
                # The post-detection signal carries BAD_* annotations
                # already (one per artifact, prefixed by detector type).
                # A before/after split would just show the same trace
                # with and without those annotations — so we route the
                # eye to a single window: Svarog with the .tag (when
                # save_tag is on) or the MNE viewer (annotations are
                # colored by description there too).
                grp.enable_view_button(
                    tooltip=(
                        f"View the {step_label}-marked signal with "
                        f"each artifact\n"
                        f"colored by detector type "
                        f"(slopes / outliers / muscles / amplitude).\n"
                        f"Runs preprocessing up to this step if needed."),
                    callback=lambda k=gui_key: self._view_step_result(k))
            elif base_key == "gaze":
                # The gaze step's natural "before/after" view is the
                # video-synced review window — it shows the same
                # video frames the detector saw, the EEG canvas, and
                # the detected intervals with confirm/dismiss
                # actions.  The generic Svarog split view of the
                # post-artifacts FIF would be confusing here (the
                # artifact tags don't carry the video context), so
                # route the eye to the review window directly.  This
                # replaces the old [Review results] button.
                grp.enable_view_button(
                    tooltip=(
                        "Open the gaze-detection review window —\n"
                        "video, EEG canvas, and interval list with\n"
                        "Confirm / Dismiss / Save Changes actions.\n"
                        "Auto-loads previous results if available;\n"
                        "otherwise auto-starts detection. Click\n"
                        "[Run Detection] inside the window to re-run\n"
                        "with different parameters."),
                    callback=lambda: self._open_gaze_window(
                        auto_run=True))
            else:
                grp.enable_view_button(
                    tooltip=(
                        f"View the before/after signal around the "
                        f"{step_label} step.\n"
                        f"Runs preprocessing up to this step if needed, "
                        f"then opens\n"
                        f"  Svarog split view (installed) or MNE "
                        f"two-window (fallback)."),
                    callback=lambda k=gui_key: self._view_step_result(k))
            # Park the panel's header-line widget immediately to
            # the left of the eye — keeps key info / controls
            # visible even when the panel is collapsed.
            _hdr_info_key = {
                "trim": "trim_header_info",
                "select": "sel_channel_count",
                "bad_channels": "bad_header_info",
                "reference": "reref_method",
                "resample": "resample_header_info",
                "ica": "ica_header_info",
                "artifacts": "art_header_info",
                "mp_decomposition": "mp_header_info",
                "mp_filter": "mpf_header_info",
                "gaze": "gaze_header_info",
            }.get(gui_key)
            if _hdr_info_key is not None:
                info_lbl = self._pp.get(_hdr_info_key)
                if info_lbl is not None:
                    hdr = grp._header_layout
                    hdr.insertWidget(hdr.indexOf(grp._view_btn), info_lbl)

        # Reference panel: park the custom-channels validation label
        # immediately to the left of the eye, just after the
        # reref_method combo (which the eye-loop above placed there).
        # Inserting at idx_of(view_btn) lands the new widget there
        # and pushes the eye further right, so the visual order
        # becomes [..., reref_method, reref_header_info, eye, ...].
        ref_info = self._pp.get("reref_header_info")
        if ref_info is not None:
            ref_hdr = ref_grp._header_layout
            ref_hdr.insertWidget(
                ref_hdr.indexOf(ref_grp._view_btn), ref_info)

        # Montage panel is intentionally absent from _STEP_SAVE_MAP
        # (set_montage is metadata-only — a before/after time-domain
        # view would be identical), so the generic eye-loop above
        # skips it.  Wire its eye to the head-diagram view directly,
        # then park the layout combo just left of the eye to mirror
        # the other panels.
        mont_grp.enable_view_button(
            tooltip=("Show head diagram of the current electrode "
                     "layout.\nMatched channels are blue, "
                     "unmatched montage positions gray."),
            callback=lambda: self._view_montage())
        _mont_hdr = mont_grp._header_layout
        _mont_hdr.insertWidget(
            _mont_hdr.indexOf(mont_grp._view_btn), self._pp["montage"])

        # MP Decomposition panel is intentionally absent from
        # _STEP_SAVE_MAP (it writes a .db book, not a -raw.fif), so the
        # generic eye-loop above skips it.  Wire its eye to the MP Book
        # Viewer directly — opens Svarog (with synced signal) or the
        # built-in BookViewerQt as fallback.
        mp_grp.enable_view_button(
            tooltip=("Open the MP book (.db) in the Book Viewer —\n"
                     "Svarog (with synced signal) if installed, or\n"
                     "the built-in BookViewer as fallback. Requires\n"
                     "an existing book on disk; click 'Run\n"
                     "decomposition' first if there isn't one."),
            callback=lambda: self._view_mp_book())
        # The generic eye-loop above (which skipped this panel) is
        # also where header-info widgets get parked next to the eye.
        # Do that inline here so the "book symbol / auto-decomp
        # params" line is actually visible.
        _mp_hdr = mp_grp._header_layout
        _mp_hdr.insertWidget(
            _mp_hdr.indexOf(mp_grp._view_btn),
            self._pp["mp_header_info"])

        # Apply the "Allow reordering" Config-tab state to the newly
        # built steps (arrows start hidden when the feature is off).
        if hasattr(self, "_allow_reorder_check"):
            self._on_allow_reorder_toggled(
                self._allow_reorder_check.isChecked())

        layout.addStretch()
        scroll.setWidget(content)
        box = QVBoxLayout(self._tab_preproc)
        box.setContentsMargins(0, 0, 0, 0)
        box.addWidget(scroll)

        # Populate channel panels if signal info was already loaded
        ch_names = getattr(self, "_cached_ch_names", None)
        ch_types = getattr(self, "_cached_ch_types", None)
        if ch_names:
            for panel in self._channel_panels:
                if not panel._checkboxes:
                    panel.populate(ch_names, ch_types=ch_types)

        # Wire epoch/rest fields to MP dict size + profile page hint
        self._mode_combo.currentTextChanged.connect(self._update_mp_dict_size)
        self._mode_combo.currentTextChanged.connect(self._update_prof_epoch_hint)
        for k in ("ep_start", "ep_stop", "rest_window"):
            w = self._pp.get(k)
            if w and hasattr(w, "textChanged"):
                w.textChanged.connect(self._update_mp_dict_size)
                w.textChanged.connect(self._update_prof_epoch_hint)
        w = self._pp.get("rest_whole")
        if w:
            w.toggled.connect(self._update_mp_dict_size)
            w.toggled.connect(self._update_prof_epoch_hint)

        # Re-apply loaded config to newly built widgets
        self._populate_vars(self.config_data)
        self._auto_fill_face_dirs()

        # Live wiring for the ⚙ / ⚠ status badges.  Each toggle that
        # flips an extras-write or interactive-review flag refreshes
        # all four panels' badges (cheap — just reads widget state).
        for key, sig in (
                ("bch_save_plots", "toggled"),
                ("ica_save_components_audit", "toggled"),
                ("art_save_plots", "toggled"),
                ("art_save_tag", "toggled"),
                ("check_segments", "toggled"),
                ("bad_mode", "currentTextChanged"),
                ("ica_selector", "currentTextChanged")):
            w = self._pp.get(key)
            if w is not None and hasattr(w, sig):
                getattr(w, sig).connect(
                    lambda *_: self._refresh_review_badges())
        self._refresh_review_badges()

    # ── Tab 4: Analysis (lazy) ───────────────────────────────────────

    def _build_analysis_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(2)
        # Trim the default 11 px top margin so the first
        # CollapsibleStep sits flush with the tab; hideSeparator()
        # on that step (below) suppresses its leading HLine.
        layout.setContentsMargins(11, 0, 11, 11)

        cfg = self.config_data
        sfreq = getattr(self, "_cached_sfreq", None)
        nyq = int(sfreq / 2) if sfreq else 0
        conn = cfg.get("connectivity", {})
        dip = cfg.get("dipole_fitting", {})
        prof = cfg.get("eeg_profiles", {})
        # stg = cfg.get("sleep_staging", {})  # deferred to _unreleased/

        self._an = {}  # analysis widgets dict

        # Mode + Viewer bar (synced labels)
        _wire_help = self._wire_step_help  # shorthand

        # ERP + cluster mass in the external analyses section below

        # ── Connectivity ──────────────────────────────────────────────
        conn_grp = CollapsibleStep(
            "Connectivity", subtitle="connectivipy",
            checkable=True,
            checked=cfg.get("prepare_connectivity_analysis", False),
            has_run=True, has_help=True, help_key="connectivity_analysis")
        conn_grp.hideSeparator()  # first step in the Analysis tab
        cg = QGridLayout()
        conn_grp.contentWidget().layout().addLayout(cg)
        # Methods grouped by type
        methods_box = QGroupBox("Methods")
        mg = QGridLayout(methods_box)
        _ar_methods = [
            ("dtf", "DTF"), ("gdtf", "gDTF"), ("ffdtf", "ffDTF"),
            ("ddtf", "dDTF"), ("idtf", "iDTF"),
            ("pdc", "PDC"), ("gpdc", "gPDC"), ("ipdc", "iPDC"),
            ("pcoh", "Partial Coherence"),
        ]
        _sig_methods = [
            ("coh", "Coherency"), ("psi", "PSI"), ("gci", "GCI"),
            ("aec", "AEC"),
        ]
        raw_methods = conn.get("methods", ["dtf", "coh"])
        if isinstance(raw_methods, str):
            sel_methods = {m.strip().lower() for m in raw_methods.split(",")}
        else:
            sel_methods = set(raw_methods)
        self._an["_conn_methods"] = {}
        ar_lbl = QLabel("AR-based:")
        ar_lbl.setStyleSheet("font-weight: bold;")
        mg.addWidget(ar_lbl, 0, 0)
        for i, (key, label) in enumerate(_ar_methods):
            cb = QCheckBox(label)
            cb.setChecked(key in sel_methods)
            mg.addWidget(cb, i // 3, 1 + i % 3)
            self._an["_conn_methods"][key] = cb
        ar_rows = (len(_ar_methods) + 2) // 3
        sig_lbl = QLabel("Signal-based:")
        sig_lbl.setStyleSheet("font-weight: bold;")
        mg.addWidget(sig_lbl, ar_rows, 0)
        for i, (key, label) in enumerate(_sig_methods):
            cb = QCheckBox(label)
            cb.setChecked(key in sel_methods)
            mg.addWidget(cb, ar_rows + i // 3, 1 + i % 3)
            self._an["_conn_methods"][key] = cb
        cg.addWidget(methods_box, 0, 0, 1, 4)
        base_row = 1
        _mvar_labels = {"yw": "Yule-Walker", "ns": "Nuttall-Strand",
                        "vm": "Vieira-Morf"}
        self._an["conn_mvar"] = self._combo_row(
            cg, base_row, "MVAR method:", "connectivity.mvar_method",
            list(_mvar_labels.values()),
            _mvar_labels.get(conn.get("mvar_method", "yw"), "Yule-Walker"))
        self._an["conn_order"] = self._entry_row(
            cg, base_row, "Order (0=auto):", "connectivity.mvar_order",
            conn.get("mvar_order", 0), col_offset=2)
        self._an["conn_res"] = self._entry_row(
            cg, base_row + 1, "Freq. resolution:", "connectivity.resolution",
            conn.get("resolution", 100))
        self._an["conn_st"] = QCheckBox("Short-time")
        self._an["conn_st"].setChecked(conn.get("short_time", False))
        self._an["conn_st"].setToolTip(
            FIELD_TOOLTIPS.get("connectivity.short_time", ""))
        cg.addWidget(self._an["conn_st"], base_row + 2, 0)
        self._an["conn_st_win"] = self._entry_row(
            cg, base_row + 2, "win:", "connectivity.st_window",
            conn.get("st_window", 0), col_offset=1)
        self._an["conn_st_ovl"] = self._entry_row(
            cg, base_row + 2, "ovl:", "connectivity.st_overlap",
            conn.get("st_overlap", 0), col_offset=3)
        self._an["conn_sig"] = QCheckBox("Significance")
        self._an["conn_sig"].setChecked(conn.get("significance", False))
        self._an["conn_sig"].setToolTip(
            FIELD_TOOLTIPS.get("connectivity.significance", ""))
        cg.addWidget(self._an["conn_sig"], base_row + 3, 0)
        self._an["conn_sig_reps"] = self._entry_row(
            cg, base_row + 3, "reps:", "connectivity.sig_reps",
            conn.get("sig_reps", 100), col_offset=1)
        self._an["conn_sig_alpha"] = self._entry_row(
            cg, base_row + 3, "\u03b1:", "connectivity.sig_alpha",
            conn.get("sig_alpha", 0.05), col_offset=3)
        self._an["conn_channels"] = ChannelPanel(title="Channels", eeg_filter=True)
        cg.addWidget(self._an["conn_channels"], base_row + 4, 0, 1, 5)
        self._register_channel_panel(self._an["conn_channels"])
        cvis_btn = QPushButton("\U0001f441 3D")
        cvis_btn.setFixedWidth(105)
        cvis_btn.setToolTip("Open connectivity results in 3D viewer (connectivis)")
        cvis_btn.clicked.connect(self._view_connectivity_in_connectivis)
        _ch = QHBoxLayout(); _ch.addStretch(); _ch.addWidget(cvis_btn); _ch.addStretch()
        conn_grp.contentWidget().layout().addLayout(_ch)
        self._an["_conn_grp"] = conn_grp
        _wire_help(conn_grp, "connectivity_analysis", "Connectivity")
        # Visual order on the Analysis tab is MMP→dip / EEG Profiles /
        # Connectivity; ``conn_grp`` is added to the layout further
        # down (after prof_grp) so users see the book-driven analyses
        # first.  Construction stays here to keep the diff small.

        # ── MMP dipole src est ────────────────────────────────────────
        dip_grp = CollapsibleStep(
            "MMP \u2192 dipole sources", subtitle="",
            checkable=True,
            checked=cfg.get("prepare_dipole_fitting", False),
            has_run=True, has_help=True, help_key="dipole_fitting")
        dip_lay = dip_grp.contentWidget().layout()

        self._an["dip_book_panel"] = BookChannelPanel(
            title="MMP1 Book", mmp_only=True, show_channel=False,
            no_book_msg="No MMP1 book. Run MP decomposition with MMP1 algorithm first.",
            pipeline_info_fn=self._mp_pipeline_info)
        self._an["dip_book_panel"].request_refresh.connect(
            self._refresh_book_panels)
        self._book_panels.append(self._an["dip_book_panel"])
        dip_lay.addWidget(self._an["dip_book_panel"])

        # -- Atom selection sub-panel --
        self._an["dip_atom_table"] = AtomFilterTable("Atom selection")
        _dip_info = QLabel(
            "Currently only f_min, f_max, s_min, s_max, max_iter are used by "
            "fit_all_dipoles. Other columns stored for future use.")
        _dip_info.setStyleSheet("color: gray;")
        _dip_info.setWordWrap(True)
        self._an["dip_atom_table"].layout().addWidget(_dip_info)
        # Populate from config
        self._an["dip_atom_table"].set_single(dip)
        if nyq > 0:
            self._an["dip_atom_table"].set_freq_max_nyquist(nyq)

        # Min GOF row
        _gof_row = QHBoxLayout()
        _gof_row.addWidget(QLabel("Min GOF [%]:"))
        self._an["dip_gof"] = QLineEdit(str(dip.get("min_gof", 0)))
        self._an["dip_gof"].setFixedWidth(50)
        self._an["dip_gof"].setToolTip(
            "Minimum goodness-of-fit to include in results.\n"
            "0 = keep all, 80\u201390 = high-quality only.")
        _gof_row.addWidget(self._an["dip_gof"])
        _gof_row.addStretch()
        self._an["dip_atom_table"].layout().addLayout(_gof_row)

        # Pick atoms from Book Viewer + pick mode
        ar3 = QHBoxLayout()
        pick_btn = QPushButton("Pick atoms from Book Viewer")
        pick_btn.setFixedWidth(200)
        pick_btn.setToolTip(
            "Open Book Viewer to select atoms for dipole fitting")
        pick_btn.clicked.connect(self._dipole_pick_atoms)
        ar3.addWidget(pick_btn)
        self._an["dip_picked_atoms"] = []
        self._an["dip_picked_label"] = QLabel("(no manual selection)")
        self._an["dip_picked_label"].setStyleSheet("color: gray;")
        ar3.addWidget(self._an["dip_picked_label"])
        ar3.addStretch()
        self._an["dip_atom_table"].layout().addLayout(ar3)


        dip_lay.addWidget(self._an["dip_atom_table"])

        # -- Fitting parameters sub-panel --
        _MONTAGES = [
            "standard_1005", "standard_1020", "standard_alphabetic",
            "standard_postfixed", "standard_prefixed", "standard_primed",
            "biosemi16", "biosemi32", "biosemi64", "biosemi128",
            "biosemi160", "biosemi256", "easycap-M1", "easycap-M10",
            "GSN-HydroCel-32", "GSN-HydroCel-64_1.0",
            "GSN-HydroCel-128", "GSN-HydroCel-256",
            "mgh60", "mgh70",
        ]
        fit_box = QGroupBox("Fitting parameters")
        fg = QGridLayout(fit_box)
        self._an["dip_ref"] = self._combo_row(
            fg, 0, "Reference:", "dipole_fitting.ref_channel",
            ["average", "Cz", "Fz"], dip.get("ref_channel", "average"))
        _mont_btn = QPushButton("Montage")
        _mont_btn.setToolTip("View montage electrode positions")
        _mont_btn.clicked.connect(self._dip_view_montage)
        fg.addWidget(_mont_btn, 1, 0)
        self._an["dip_montage"] = QComboBox()
        self._an["dip_montage"].addItems(_MONTAGES)
        self._an["dip_montage"].setCurrentText(
            dip.get("montage", "standard_1005"))
        self._an["dip_montage"].setToolTip(
            FIELD_TOOLTIPS.get("dipole_fitting.montage", ""))
        fg.addWidget(self._an["dip_montage"], 1, 1)
        self._an["dip_dot"] = self._entry_row(
            fg, 2, "Dot size (0=auto):", "dipole_fitting.dot_size",
            dip.get("dot_size", 0), width=40)
        self._an["dip_cortical"] = QCheckBox(
            "Compute cortical distance (nibabel)")
        self._an["dip_cortical"].setChecked(
            dip.get("cortical_distance", False))
        self._an["dip_cortical"].setToolTip(
            FIELD_TOOLTIPS.get("dipole_fitting.cortical_distance", ""))
        fg.addWidget(self._an["dip_cortical"], 3, 0, 1, 2)
        _fsavg_btn = QPushButton("fsaverage dir")
        _fsavg_btn.setToolTip("Browse for fsaverage directory")
        _fsavg_btn.clicked.connect(lambda: self._browse_dir(
            self._an["dip_fsavg"], "Select fsaverage directory"))
        fg.addWidget(_fsavg_btn, 4, 0)
        self._an["dip_fsavg"] = QLineEdit(
            dip.get("fsaverage_dir", ""))
        self._an["dip_fsavg"].setToolTip(
            FIELD_TOOLTIPS.get("dipole_fitting.fsaverage_dir", ""))
        fg.addWidget(self._an["dip_fsavg"], 4, 1)
        # CPU cores for dipole fitting — same semantics as MP workers:
        #   empty / 0  → inherit from Config tab parallelism.n_jobs
        #   N > 0      → explicit override
        from ide4eeg.main import _detect_system
        _phys, _, _ = _detect_system()
        _dip_cfg_cores = int(dip.get("cpu_workers", 0) or 0)
        self._an["dip_workers"] = QLineEdit()
        if _dip_cfg_cores > 0:
            self._an["dip_workers"].setText(str(_dip_cfg_cores))
        self._an["dip_workers"].setFixedWidth(28)
        self._an["dip_workers"].setToolTip(
            FIELD_TOOLTIPS.get("dipole_fitting.cpu_workers", ""))
        self._an["dip_workers_readout"] = QLabel("")
        self._an["dip_workers_readout"].setStyleSheet("color: gray;")
        _dc_row = QHBoxLayout()
        _dc_row.addWidget(QLabel("CPU cores:"))
        _dc_row.addWidget(self._an["dip_workers"])
        _dc_row.addWidget(self._an["dip_workers_readout"])
        _dc_row.addStretch()
        fg.addLayout(_dc_row, 5, 0, 1, 2)
        self._an["dip_workers"].textChanged.connect(
            self._update_dip_workers_readout)
        # Wire to parallelism.n_jobs changes too
        if hasattr(self, "_n_jobs_edit"):
            self._n_jobs_edit.textChanged.connect(
                self._update_dip_workers_readout)
        dip_lay.addWidget(fit_box)

        # -- Channel panel --
        # NOT registered in _channel_panels: populated from the selected
        # book via _on_dip_book_changed, not from the raw signal channel list.
        self._an["dip_channels"] = ChannelPanel(title="Channels", eeg_filter=True)
        dip_lay.addWidget(self._an["dip_channels"])
        self._an["dip_book_panel"]._book_combo.currentIndexChanged.connect(
            self._on_dip_book_changed)

        # Insert 3D view button in the header, before Run
        dip_3d_btn = QPushButton("3D")
        dip_3d_btn.setToolTip(
            "Run dipole analysis and open results in connectivis 3D viewer")
        dip_3d_btn.clicked.connect(
            lambda: self._run_analysis_from_button(
                "prepare_dipole_fitting", dip_grp))
        _hdr = dip_grp._header_layout
        # Find the Run button index and insert before it
        _run_idx = _hdr.indexOf(dip_grp._run_btn) if dip_grp._run_btn else _hdr.count()
        _hdr.insertWidget(_run_idx, dip_3d_btn)
        self._an["_dip_grp"] = dip_grp
        _wire_help(dip_grp, "dipole_fitting", "MMP \u2192 dipole sources")
        layout.addWidget(dip_grp)

        # ── EEG Profiles ─────────────────────────────────────────────
        prof_grp = CollapsibleStep(
            "EEG Profiles", subtitle="",
            checkable=True,
            checked=cfg.get("prepare_eeg_profiles", False),
            has_run=True, has_help=True, help_key="eeg_profiles")
        self._an["prof_book_panel"] = BookChannelPanel(
            pipeline_info_fn=self._mp_pipeline_info,
            pipeline_channels_fn=self._mp_pipeline_channels)
        self._an["prof_book_panel"].request_refresh.connect(
            self._refresh_book_panels)
        self._book_panels.append(self._an["prof_book_panel"])
        prof_grp.contentWidget().layout().addWidget(self._an["prof_book_panel"])

        # -- Structures --
        self._an["prof_atom_table"] = AtomFilterTable(
            "Structures", multi_row=True, show_name=True, show_mode=True)
        prof_grp.contentWidget().layout().addWidget(
            self._an["prof_atom_table"])
        structs = prof.get("structures", [])
        if structs:
            self._an["prof_atom_table"].populate(structs)
        # Profile bin width is always equal to the MP segment length
        # (read from book metadata at runtime). No user override.
        self._an["prof_epoch_hint"] = QLabel("")
        self._an["prof_epoch_hint"].setStyleSheet("color: gray;")
        prof_grp.contentWidget().layout().addWidget(
            self._an["prof_epoch_hint"])

        self._an["prof_auto_svarog"] = QCheckBox("Auto open results in SVAROG")
        _ph = QHBoxLayout(); _ph.addStretch()
        _ph.addWidget(self._an["prof_auto_svarog"])
        _ph.addStretch()
        prof_grp.contentWidget().layout().addLayout(_ph)
        self._an["_prof_grp"] = prof_grp
        _wire_help(prof_grp, "eeg_profiles", "EEG Profiles")
        prof_grp.enable_view_button(
            tooltip=(
                "Run EEG profiles, then open the resulting tag\n"
                "+ signal + MP book together in SVAROG for an\n"
                "interactive review.  Forces the Svarog launch\n"
                "regardless of the 'Auto open' checkbox state.\n"
                "If a matching MP book is on disk, profile\n"
                "detection runs without re-doing preprocessing."),
            callback=self._view_profiles_in_svarog)
        layout.addWidget(prof_grp)
        # Connectivity, last of the IDE4EEG-native analysis trio.
        # Construction is up at the top of this method; only the
        # addWidget call lives here so the layout reads MMP→dip,
        # EEG Profiles, Connectivity.
        layout.addWidget(conn_grp)

        # ── Analyses from external packages ───────────────────────────
        # MNE-Python analyses, below the IDE4EEG-native steps.  10 px
        # of breathing room separates the IDE4EEG block from the MNE
        # section header.
        layout.addSpacing(10)
        _mne_sep = QFrame()
        _mne_sep.setFrameShape(QFrame.NoFrame)
        _mne_sep.setAutoFillBackground(True)
        _mne_sep.setBackgroundRole(QPalette.Mid)
        _mne_sep.setFixedHeight(1)
        layout.addWidget(_mne_sep)
        self._build_mne_section(layout)

        # Wire Run buttons for all analysis steps
        _AN_RUN_MAP = [
            ("_conn_grp", "prepare_connectivity_analysis"),
            ("_dip_grp",  "prepare_dipole_fitting"),
            ("_prof_grp", "prepare_eeg_profiles"),
        ]
        # Tooltip pattern: state the narrowing first ("only this
        # analysis"), then the preprocessing situation honestly.
        # Book-only analyses (Profiles, Dipole) skip preprocessing
        # only when a matching book is on disk — otherwise they fall
        # through to the full pipeline.  Non-book-only analyses
        # always run preprocessing; their [Run] button just skips
        # the OTHER enabled analyses, which only saves time when
        # several are enabled.
        _AN_RUN_TOOLTIPS = {
            "_conn_grp": (
                "Run only connectivity analysis (MVAR / DTF /\n"
                "  PDC).  Other enabled analyses are skipped.\n"
                "Preprocessing runs in full — no faster than\n"
                "  Run Pipeline if connectivity is your only\n"
                "  enabled analysis."),
            "_dip_grp": (
                "Run only dipole fitting.  Other enabled analyses\n"
                "  are skipped.\n"
                "If a matching MMP book is on disk, reads atoms\n"
                "  directly — no signal loading or preprocessing.\n"
                "Otherwise: full preprocessing then dipole fitting.\n"
                "Opens result in ConnectiVIS when done."),
            "_prof_grp": (
                "Run only EEG profiles.  Other enabled analyses\n"
                "  are skipped.\n"
                "If a matching MP book is on disk, reads atoms\n"
                "  directly — no signal loading or preprocessing.\n"
                "Otherwise: full preprocessing then profiles\n"
                "  detection.\n"
                "If 'Auto open results in SVAROG' is checked,\n"
                "  opens the tag automatically."),
        }
        for grp_key, analysis_key in _AN_RUN_MAP:
            grp = self._an.get(grp_key)
            if grp and grp._run_btn:
                grp._run_btn.clicked.connect(
                    lambda _=False, k=analysis_key, g=grp:
                        self._run_analysis_from_button(k, g))
                tip = _AN_RUN_TOOLTIPS.get(grp_key)
                if tip:
                    grp._run_btn.setToolTip(tip)

        # Analysis availability based on data properties, not mode string
        def _update_analysis_warnings():
            has_events = bool(getattr(self, "_cached_events", None))
            mp_on = False
            mp_grp = self._pp.get("_mp_grp")
            if mp_grp:
                mp_on = mp_grp.isChecked()

            # EEG Profiles: any MP book selected in panel
            prof_bp = self._an.get("prof_book_panel")
            has_prof_book = bool(
                prof_bp and prof_bp.selected_book()
                and os.path.isfile(prof_bp.selected_book()))
            prof_grp = self._an.get("_prof_grp")
            if prof_grp:
                if not has_prof_book and not mp_on:
                    prof_grp.setStatusText("\u26a0 needs MP book")
                else:
                    prof_grp.setStatusText("")

            # Dipole fitting: MMP book specifically
            dip_bp = self._an.get("dip_book_panel")
            has_mmp_book = bool(
                dip_bp and dip_bp.selected_book()
                and os.path.isfile(dip_bp.selected_book()))
            dip_grp = self._an.get("_dip_grp")
            if dip_grp:
                if not has_mmp_book and not mp_on:
                    dip_grp.setStatusText("\u26a0 needs MMP1 book")
                else:
                    dip_grp.setStatusText("")

        self._update_analysis_warnings = _update_analysis_warnings
        self._mode_combo.currentTextChanged.connect(
            lambda _: _update_analysis_warnings())
        # Also update when MP checkbox changes
        mp_grp = self._pp.get("_mp_grp")
        if mp_grp and mp_grp._checkbox:
            mp_grp._checkbox.stateChanged.connect(
                lambda _: _update_analysis_warnings())
        # Update when book panels change
        for _bp_key in ("prof_book_panel", "dip_book_panel"):
            _bp = self._an.get(_bp_key)
            if _bp:
                _bp._book_combo.currentIndexChanged.connect(
                    lambda _: _update_analysis_warnings())
        _update_analysis_warnings()

        layout.addStretch()
        scroll.setWidget(content)
        box = QVBoxLayout(self._tab_analysis)
        box.setContentsMargins(0, 0, 0, 0)
        box.addWidget(scroll)

        # Populate channel panels if signal info already loaded
        ch_names = getattr(self, "_cached_ch_names", None)
        ch_types = getattr(self, "_cached_ch_types", None)
        if ch_names:
            for panel in self._channel_panels:
                if not panel._checkboxes:
                    panel.populate(ch_names, ch_types=ch_types)

        # Populate book panels
        self._refresh_book_panels()

        # Re-apply loaded config to newly built widgets
        self._populate_vars(self.config_data)

    # ── Step help [?] buttons ────────────────────────────────────────
    # Each entry: (description, [ref_keys], "Manual heading text")
    # The heading text must match the ## heading in USER_MANUAL.md exactly.
    _STEP_HELP = {
        "resample": (
            "Downsample the signal to a lower sampling frequency.\n"
            "Uses MNE's resample() with anti-aliasing filter.",
            ["gramfort2014_mne"],
            "5.R1 Resampling"),
        "bad_channels": (
            "Automatic detection of bad channels using band-power\n"
            "thresholding and inter-channel correlation analysis.",
            ["klekowicz2009_artifacts", "gramfort2014_mne"],
            "5.R2 Bad channel detection"),
        "montage": (
            "Register electrode positions (10-20 / 10-05 system).\n"
            "Reordering note: re-referencing is now its own step\n"
            "and can be moved independently — see the Reference\n"
            "panel below.",
            ["gramfort2014_mne"],
            "5.R3 Montage and re-reference"),
        "reference": (
            "Re-reference EEG channels (CAR, REST, linked mastoids,\n"
            "or a custom channel list).  Used to live inside the\n"
            "Montage step; split out so it can be reordered\n"
            "independently (e.g. before vs. after ICA).",
            ["gramfort2014_mne"],
            "5.R3 Montage and re-reference"),
        "filtering": (
            "Frequency-domain filtering.\n\n"
            "Two methods available (both produce zero-phase output):\n"
            " - IIR (Butterworth / Chebyshev II) -- fast, sharp rolloff.\n"
            "   SOS format, zero-phase via sosfiltfilt (forward+backward\n"
            "   pass squares the magnitude response and doubles the\n"
            "   effective order).\n"
            " - FIR (MNE) -- always stable, linear phase by design\n"
            "   (symmetric windowed sinc, no second pass needed).\n\n"
            "Notch filter: Chebyshev II bandstop (50 or 60 Hz).\n"
            "Use 'Plot filter response' to preview before running\n"
            "(plots show the single-pass design, not the doubled IIR\n"
            "response).",
            ["gramfort2014_mne"],
            "5.R4 Filtering"),
        "ica": (
            "Independent Component Analysis for ocular artifact\n"
            "removal. Components correlated with EOG are excluded.",
            ["gramfort2014_mne"],
            "5.R5 ICA -- ocular artifact removal"),
        "chosen_channels": (
            "Select or drop channels by name. Channels not in the\n"
            "selected list are excluded from further processing.",
            [],
            "5.R6 Channel selection"),
        "mp_decomposition": (
            "Matching Pursuit: decompose the signal into a sum of\n"
            "Gabor atoms (time-frequency waveforms) using the empi\n"
            "algorithm. Produces a persistent .db book file.",
            ["mallat1993_mp", "kus2013_mmp",
             "rozanski2024_empi", "rozanski2024_thesis"],
            "5.R7 Matching Pursuit decomposition"),
        "mp_filter": (
            "Nonlinear filter: reconstruct the signal from a subset\n"
            "of MP atoms, keeping or removing atoms that match\n"
            "frequency/time/energy criteria.",
            ["mallat1993_mp", "rozanski2024_empi"],
            "5.R8 MP Filter (nonlinear filtering)"),
        "segmentation_setup": (
            "Configure how the signal is cut into segments.\n\n"
            "Event-locked mode: reads events from the file's STIM\n"
            "channel and uses the events you select in the Events\n"
            "panel. The original STIM channel is never modified.\n\n"
            "Timed-windows (rest) mode: attaches REST annotations\n"
            "marking synthetic window onsets at regular\n"
            "window_length intervals. No channel data is touched\n"
            "(annotations are pure metadata, so the preamble stays\n"
            "lazy on multi-hour recordings). Any hardware event\n"
            "markers the file carried remain available in the\n"
            "STIM channel for later inspection.\n\n"
            "No step in the pipeline ever overwrites the original\n"
            "STIM channel — this is a hard non-destruction invariant.\n\n"
            "Cut segments (postamble): the parameters here drive\n"
            "the always-runs ``cut_segments`` postamble step, which\n"
            "slices the continuous preprocessed signal into Epochs.\n"
            "Timed windows: fixed-length windows from the rest\n"
            "period.  Event-locked: windows around each event tag.\n"
            "This step has no panel of its own — it cannot be\n"
            "disabled or reordered.",
            [],
            "5.P1 Segmentation setup"),
        "trim": (
            "Trim / crop the signal to [trim_start, trim_end].\n\n"
            "Reorderable step — defaults to the front of the chain,\n"
            "but you can move it later if you want bad-channel\n"
            "detection to see the full (untrimmed) recording.",
            [],
            "5.P2 Trim signal"),
        "gaze": (
            "Video-based artifact detection -- marks intervals where\n"
            "the subject is not looking at the screen.\n\n"
            "Pipeline (per frame):\n"
            "1. Detect faces -- InsightFace RetinaFace.\n"
            "2. Encode faces -- 512-d ArcFace identity vector.\n"
            "3. Match to subject: encoding distance, exclude gate,\n"
            "   tolerance, adaptive encoding, spatial continuity,\n"
            "   size consistency, switch resistance.\n"
            "4. Gaze check (InsightFace or L2CS-Net):\n"
            "   InsightFace: 5-point landmarks, nose-to-eyes vector.\n"
            "   L2CS-Net: ResNet50 eye gaze (3.92 deg on MPIIGaze).\n"
            "5. Output: per-frame boolean, aggregated into intervals.",
            [],
            "5.R10 Gaze -- video artifact detection"),
        "segment_rejection": (
            "Peak-to-peak segment rejection.\n\n"
            "Reject threshold [uV]: segments with PTP > threshold\n"
            "are dropped. Set to 0 for automatic detection.\n\n"
            "Flat threshold [uV]: segments where PTP < threshold\n"
            "are dropped (detects dead channels). 0 = disabled.\n\n"
            "Auto percentile: when reject = 0, the threshold is\n"
            "set at this percentile of the PTP distribution\n"
            "(e.g. 95 = reject top 5%).",
            ["gramfort2014_mne"],
            "5.R11 Segment rejection (peak-to-peak)"),
        "artifacts": (
            "Multi-method EEG artifact detection:\n"
            "- Outliers: amplitude peaks exceeding adaptive threshold\n"
            "- Slopes: peak-to-peak spikes in windowed analysis\n"
            "- Muscles: high-frequency EMG power detection\n"
            "Each method uses iterative standard deviation thresholding.",
            ["klekowicz2009_artifacts"],
            "5.R9 EEG artifact detection"),
        "eeg_profiles": (
            "Detect and count EEG structures (spindles, alpha, delta,\n"
            "theta, beta) by filtering MP atoms on Frequency,\n"
            "Amplitude, Scale, Phase (FASP) thresholds.\n"
            "Produces time-evolution charts and detection tables.\n\n"
            "Per-analysis [Run]: book-only fast path — if a matching\n"
            "MP book is on disk, skips signal loading and\n"
            "preprocessing entirely (see manual § 3.4).\n\n"
            "Internal: ide4eeg.analysis.eeg_profiles",
            ["malinowska2013_profiles"],
            "6.6 EEG profiles (structure detection)"),
        "connectivity_analysis": (
            "Directed and undirected connectivity between EEG channels\n"
            "using Multivariate Autoregressive (MVAR) models.\n"
            "12 measures: DTF, gDTF, ffDTF, dDTF, PDC, gPDC, iPDC,\n"
            "Partial Coherence, Coherency, PSI, GCI, AEC.\n\n"
            "MVAR fitting: Yule-Walker, Nuttall-Strand, or Vieira-Morf.\n"
            "Auto order selection via Akaike criterion.\n\n"
            "Based on ConnectiviPy by D. Krzemiński and M. Kamiński\n"
            "(University of Warsaw, GSoC 2015 / INCF).\n"
            "https://github.com/dokato/connectivipy\n\n"
            "Per-analysis [Run]: runs full preprocessing then only\n"
            "this analysis — no faster than Run Pipeline if\n"
            "connectivity is your only enabled analysis (see manual\n"
            "§ 3.4).\n\n"
            "Internal: ide4eeg.analysis.connectivity_analysis",
            ["kaminski1991_mvar", "baccala2001_pdc", "blinowska2004_info"],
            "6.4 Connectivity analysis"),
        "dipole_fitting": (
            "Fits equivalent current dipoles to Multivariate Matching\n"
            "Pursuit (MMP) macroatoms using the fsaverage template brain.\n\n"
            "Each macroatom groups all channels for one MP iteration.\n"
            "Amplitude signs determined via circular mean of phases.\n"
            "An MNE EvokedArray is fitted with mne.fit_dipole using\n"
            "the fsaverage BEM model.\n\n"
            "Requires an MMP book (.db) from the preprocessing step.\n"
            "Optionally computes distance to nearest cortical voxel.\n\n"
            "Per-analysis [Run]: book-only fast path — if a matching\n"
            "MMP book is on disk, skips signal loading and\n"
            "preprocessing entirely (see manual § 3.4).\n\n"
            "Internal: ide4eeg.analysis.dipole_analysis,\n"
            "  ide4eeg.analysis.dipole.fitting",
            ["durka2018_mpdip", "scherg1990_dipole",
             "kus2013_mmp", "gramfort2014_mne"],
            "6.5 MMP dipole source estimation"),
    }

    @staticmethod
    def _heading_anchor(h):
        """Convert a heading string to an HTML anchor id."""
        return re.sub(r"[^a-z0-9]+", "-", h.lower()).strip("-")

    def _show_step_help(self, step_key, title):
        from ide4eeg.references import REFERENCES, format_citation
        import html as _html
        desc, ref_keys, manual_heading = self._STEP_HELP.get(
            step_key, ("No description available.", [], ""))

        # Build HTML: double newline = paragraph, single newline = space
        paragraphs = desc.split("\n\n")
        body = "".join(
            f"<p>{_html.escape(p).replace(chr(10), ' ')}</p>"
            for p in paragraphs)
        if ref_keys:
            body += "<hr><p><b>References</b></p><ul>"
            for rk in ref_keys:
                ref = REFERENCES.get(rk)
                if ref:
                    cite = _html.escape(format_citation(ref))
                    url = ref.get("url", "")
                    if url:
                        body += (f'<li>{cite}<br>'
                                 f'<a href="{_html.escape(url)}">'
                                 f'{_html.escape(url)}</a></li>')
                    else:
                        body += f"<li>{cite}</li>"
            body += "</ul>"
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Help: {title}")
        dlg.resize(520, 340)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(12, 12, 12, 12)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(
            f'<div style="'
            f'font-size: 13px; line-height: 1.5;">{body}</div>')
        lay.addWidget(browser)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        if manual_heading:
            manual_btn = QPushButton(
                f"Open in Manual: {manual_heading}")
            manual_btn.setStyleSheet(
                "QPushButton{color:#1a6faa;text-decoration:underline;"
                "border:none;padding:4px 8px;font-size:13px}"
                "QPushButton:hover{color:#0d4f7a}")
            anchor = self._heading_anchor(manual_heading)
            manual_btn.clicked.connect(
                lambda _, a=anchor, d=dlg: (
                    d.accept(), self._jump_to_manual(a)))
            btn_row.addWidget(manual_btn)
        close_btn = QPushButton("Close")
        close_btn.setFixedWidth(80)
        close_btn.clicked.connect(dlg.accept)
        btn_row.addWidget(close_btn)
        lay.addLayout(btn_row)
        dlg.show()

    def _jump_to_manual(self, anchor):
        """Switch to the Help tab and scroll to *anchor*."""
        # setCurrentWidget triggers _on_tab_changed which lazy-builds
        # the help tab if needed, so _help_browser is guaranteed to exist.
        self._tabs.setCurrentWidget(self._tab_help)
        self._help_browser.scrollToAnchor(anchor)

    # _prof_* methods moved to AtomFilterTable class (multi_row=True, show_name/show_mode=True)

    # ── Tab 5: Run (lazy) ────────────────────────────────────────────

    # Pipeline stage definitions: (id, log_pattern, label, config_key)
    _PIPELINE_STAGES = [
        ("load",    "Loading pipeline modules",               "Loading",                  None),
        ("read",    "Starting work with",                     "Reading signal",           None),
        ("preproc", "Preparing preprocessing",                "Preprocessing",            None),
        ("mp",      "MP decomposition:",                      "MP decomposition",         "_mp_step"),
        ("video",   "Loading reference data",                 "Video artifacts",          "prepare_video_artifacts"),
        ("prof",    "Preparing EEG profiles",                 "EEG Profiles",             "prepare_eeg_profiles"),
        ("conn",    "Preparing connectivity analysis",        "Connectivity",             "prepare_connectivity_analysis"),
        ("dip",     "Preparing dipole fitting",               "Dipole fitting",           "prepare_dipole_fitting"),
        ("dip_fit", "Fitting dipoles to",                     "Fitting dipoles",          "prepare_dipole_fitting"),
    ]

    # ── Tab: MNE ─────────────────────────────────────────────────────

    def _build_mne_section(self, layout):
        """Build the external analysis catalog panels into *layout*."""
        from ide4eeg.analysis.mne_catalog import MNE_CATALOG

        # Header — 10 px breathing room separates the MNE block from
        # the IDE4EEG-native steps above.
        layout.addSpacing(10)
        header = QLabel(
            "<i>Analyses from MNE:</i>")
        header.setWordWrap(True)
        header.setStyleSheet("padding: 4px 8px; color: gray;")
        layout.addWidget(header)

        # Group by category
        from collections import OrderedDict
        categories = OrderedDict()
        for entry in MNE_CATALOG:
            cat = entry["category"]
            categories.setdefault(cat, []).append(entry)

        self._mne_checks = {}       # {id: QCheckBox}
        self._mne_params = {}       # {id: {key: QLineEdit}}
        self._mne_advanced_groupboxes = {}  # {id: QGroupBox}
        self._mne_warn_labels = {}  # {id: QLabel}
        self._mne_cat_steps = {}    # {category: CollapsibleStep}
        self._mne_cat_ids = {}      # {category: [id, ...]}
        first = True

        _cat_help = {
            "ERP": (
                "Event-Related Potentials — averaged brain responses\n"
                "to stimulus events. Butterfly plots, topographic\n"
                "maps, joint plots, GFP, and cluster permutation\n"
                "tests. Requires event-locked epochs (≥2 event\n"
                "types for cluster tests).\n\n"
                "Each entry's [?] links to the MNE documentation."),
            "Spectra": (
                "Power Spectral Density — frequency content of the\n"
                "signal. Multitaper PSD and topographic PSD maps\n"
                "across standard frequency bands.\n\n"
                "Each entry's [?] links to the MNE documentation."),
            "Time-frequency": (
                "Time-frequency decompositions — how spectral power\n"
                "changes over time. Morlet wavelet TFR, multitaper\n"
                "TFR, and ERD/S topographic maps.\n\n"
                "Each entry's [?] links to the MNE documentation."),
            "Spatial": (
                "Spatial visualizations — topographic map animations\n"
                "and electrode montage plots.\n\n"
                "Each entry's [?] links to the MNE documentation."),
            "Comparison": (
                "Cross-condition comparisons — overlay evokeds from\n"
                "different conditions, epoch drop logs, and PSD\n"
                "band topomaps.\n\n"
                "Each entry's [?] links to the MNE documentation."),
            "Source estimation": (
                "ERP dipole fit — classical equivalent current dipole\n"
                "fitting (Scherg 1990) via mne.fit_dipole. Fits\n"
                "dipoles to averaged evoked responses per condition.\n"
                "No MP decomposition needed.\n\n"
                "Each entry's [?] links to the MNE documentation."),
        }

        for cat, entries in categories.items():
            _cat_subtitles = {
                "Source estimation": "MNE + connectivis",
            }
            step = CollapsibleStep(
                cat, subtitle=_cat_subtitles.get(
                    cat, entries[0].get("optional_pkg") or "MNE"),
                checkable=True, checked=False,
                has_run=True, has_help=True,
                help_key=f"mne_cat_{cat}")
            # Wire the [?] button to show a tooltip popup
            help_text = _cat_help.get(cat, "")
            if help_text and step._help_btn is not None:
                step._help_btn.setToolTip(help_text)
                step._help_btn.clicked.connect(
                    lambda _, t=cat, h=help_text: self._msg_info(
                        t, h))
            if first:
                step.hideSeparator()
                first = False

            # Checkboxes with [?] doc links + inline param fields
            for entry in entries:
                row = QHBoxLayout()
                row.setSpacing(4)
                cb = QCheckBox(entry["name"])
                cb.setToolTip(entry.get("description", ""))
                cb.setChecked(False)
                row.addWidget(cb)
                row.addSpacing(6)
                doc_url = entry.get("doc_url", "")
                if doc_url:
                    doc_btn = QPushButton("?")
                    doc_btn.setFixedSize(28, 22)
                    doc_btn.setToolTip(
                        f"Open MNE documentation:\n{doc_url}")
                    doc_btn.clicked.connect(
                        lambda _, u=doc_url: __import__(
                            "webbrowser").open(u))
                    row.addWidget(doc_btn)
                warn_lbl = QLabel("")
                warn_lbl.setStyleSheet("color: #a0a070; font-size: 11px;")
                row.addWidget(warn_lbl)
                row.addStretch()
                step.contentWidget().layout().addLayout(row)
                self._mne_checks[entry["id"]] = cb
                self._mne_warn_labels[entry["id"]] = warn_lbl

                # Parameter fields (shown/hidden with checkbox).  Simple
                # params render in a horizontal row; advanced params hide
                # behind a collapsed "Advanced parameters" CollapsibleStep
                # — same widget Bad Channels uses, with checkable=False
                # since the disclosure isn't an enable/disable toggle.
                # Disclosure state round-trips through TOML via the
                # `_is_disclosure_open` / `_set_disclosure_open` helpers.
                entry_params = entry.get("params", [])
                if entry_params:
                    simple_params = [p for p in entry_params
                                     if not p.get("advanced", False)]
                    advanced_params = [p for p in entry_params
                                       if p.get("advanced", False)]
                    pw = QWidget()
                    pw_layout = QVBoxLayout(pw)
                    pw_layout.setContentsMargins(24, 0, 0, 0)
                    pw_layout.setSpacing(2)
                    param_widgets = {}
                    if simple_params:
                        pw_layout.addLayout(
                            self._build_mne_param_row(
                                simple_params, param_widgets))
                    if advanced_params:
                        adv_step = CollapsibleGroupBox(
                            "Advanced parameters", collapsed=True)
                        adv_v = QVBoxLayout(adv_step.contentWidget())
                        adv_v.setContentsMargins(0, 2, 0, 2)
                        adv_v.setSpacing(4)
                        adv_v.addLayout(
                            self._build_mne_param_row(
                                advanced_params, param_widgets))
                        pw_layout.addWidget(adv_step)
                        self._mne_advanced_groupboxes[entry["id"]] = adv_step
                    pw.setVisible(cb.isChecked())
                    cb.toggled.connect(pw.setVisible)
                    step.contentWidget().layout().addWidget(pw)
                    self._mne_params[entry["id"]] = param_widgets

            # [Run] button runs only this category's checked items
            if step._run_btn:
                cat_ids = [e["id"] for e in entries]
                step._run_btn.clicked.connect(
                    lambda _, ids=cat_ids, s=step:
                        self._run_mne_category(ids, s))

            # Category checkbox toggles all items
            if step._checkbox:
                _cat_cbs = [self._mne_checks[e["id"]] for e in entries]
                step._checkbox.stateChanged.connect(
                    lambda state, cbs=_cat_cbs:
                        [c.setChecked(bool(state)) for c in cbs])

            # [3D] button for Source estimation (ConnectiVIS viewer)
            if cat == "Source estimation":
                _3d_btn = QPushButton("3D")
                _3d_btn.setToolTip(
                    "Open ERP dipole results in connectivis\n"
                    "3D viewer")
                _3d_btn.clicked.connect(
                    self._view_connectivity_in_connectivis)
                step.addHeaderWidget(_3d_btn)

            layout.addWidget(step)
            self._mne_cat_steps[cat] = step
            self._mne_cat_ids[cat] = [e["id"] for e in entries]

        # Track requirements per entry for enable/disable
        self._mne_entries = {e["id"]: e for e in MNE_CATALOG}

        # Check optional packages once at startup
        from ide4eeg.analysis.mne_catalog import _check_optional_pkg
        _pkg_cache = {}
        for entry in MNE_CATALOG:
            pkg = entry.get("optional_pkg")
            if pkg and pkg not in _pkg_cache:
                _pkg_cache[pkg] = _check_optional_pkg(pkg)

        def _update_mne_availability():
            has_events = bool(getattr(self, "_cached_events", None))
            n_tags = len(getattr(self, "_cached_events", {}) or {})
            for aid, cb in self._mne_checks.items():
                entry = self._mne_entries.get(aid, {})
                inp = entry.get("input", "both")
                reqs = entry.get("requires", [])
                available = True
                reasons = []
                # Check optional package
                pkg = entry.get("optional_pkg")
                if pkg and not _pkg_cache.get(pkg, True):
                    available = False
                    reasons.append(f"install: pip install {pkg}")
                # Check input mode
                if inp == "epochs" and not has_events:
                    available = False
                    reasons.append("requires event markers")
                # Check multi-tag requirement
                if "multi_tag" in reqs and n_tags < 2:
                    available = False
                    reasons.append("needs 2+ event types")
                cb.setEnabled(available)
                # Update tooltip + inline warning
                desc = entry.get("description", "")
                warn_lbl = self._mne_warn_labels.get(aid)
                if reasons:
                    cb.setToolTip(
                        f"{desc}\n\u26a0 Unavailable: {', '.join(reasons)}")
                    if warn_lbl:
                        warn_lbl.setText(
                            f"\u26a0 {', '.join(reasons)}")
                else:
                    cb.setToolTip(desc)
                    if warn_lbl:
                        warn_lbl.setText("")
                # Disable param widgets too.  Gate on availability only —
                # the checkbox's `toggled` signal hides the params via
                # `pw.setVisible`, so we don't also need to disable them
                # when unchecked (and historically didn't recompute on
                # toggle, which left them stuck disabled).
                pw = self._mne_params.get(aid)
                if pw:
                    for w in pw.values():
                        w.setEnabled(available)

            # Update category header status
            for cat, step in self._mne_cat_steps.items():
                ids = self._mne_cat_ids[cat]
                # Collect unique reasons across all entries in category
                cat_reasons = set()
                all_disabled = True
                for aid in ids:
                    cb = self._mne_checks.get(aid)
                    if cb and cb.isEnabled():
                        all_disabled = False
                    entry = self._mne_entries.get(aid, {})
                    pkg = entry.get("optional_pkg")
                    if pkg and not _pkg_cache.get(pkg, True):
                        cat_reasons.add(f"pip install {pkg}")
                    inp = entry.get("input", "both")
                    if inp == "epochs" and not has_events:
                        cat_reasons.add("requires event markers")
                if all_disabled and cat_reasons:
                    step.setStatusText(
                        "\u26a0 " + ", ".join(sorted(cat_reasons)))
                else:
                    step.setStatusText("")

        self._mode_combo.currentTextChanged.connect(
            lambda _: _update_mne_availability())
        self._update_mne_availability = _update_mne_availability
        _update_mne_availability()

    def _run_mne_category(self, cat_ids, grp_widget):
        """Run checked MNE analyses from a single category."""
        checked = [aid for aid in cat_ids
                   if self._mne_checks.get(aid, None)
                   and self._mne_checks[aid].isChecked()]
        if not checked:
            self._msg_info("Nothing selected",
                           "Check at least one analysis to run.")
            return
        cfg = self._collect_config()
        cfg["mne_catalog"] = checked
        # Disable all other analyses — only run MNE catalog
        for k in self._ANALYSIS_FLAGS:
            cfg[k] = False
        if not self._launch_pipeline(cfg):
            if grp_widget and grp_widget._run_btn:
                grp_widget._run_btn.setEnabled(True)

    def _build_mne_param_row(self, params, param_widgets):
        """Build a horizontal row of widgets for catalog params,
        dispatched on `p["type"]`.  Mutates *param_widgets* in place
        keyed by ``p["key"]``.

        - ``"bool"``    → QCheckBox (label is the checkbox label).
        - ``"choice"``  → QLabel + QComboBox (items from p["choices"]).
        - everything else → QLabel + QLineEdit (str/int/float).
        """
        row = QHBoxLayout()
        row.setSpacing(4)
        for p in params:
            ptype = p.get("type", "")
            tip = p.get("tooltip", "")
            if ptype == "bool":
                w = QCheckBox(p["label"])
                w.setChecked(bool(p.get("default", False)))
                w.setToolTip(tip)
                row.addWidget(w)
            elif ptype == "choice":
                row.addWidget(QLabel(p["label"] + ":"))
                w = QComboBox()
                w.addItems([str(c) for c in p.get("choices", [])])
                idx = w.findText(str(p.get("default", "")))
                if idx >= 0:
                    w.setCurrentIndex(idx)
                w.setToolTip(tip)
                row.addWidget(w)
            else:
                row.addWidget(QLabel(p["label"] + ":"))
                w = QLineEdit(str(p.get("default", "")))
                w.setFixedWidth(60)
                w.setToolTip(tip)
                row.addWidget(w)
            param_widgets[p["key"]] = w
        row.addStretch()
        return row

    def _collect_mne_selections(self):
        """Return list of checked MNE catalog IDs."""
        checks = getattr(self, "_mne_checks", {})
        return [aid for aid, cb in checks.items() if cb.isChecked()]

    def _collect_mne_params(self):
        """Return {id: {key: value}} for checked MNE entries with params.

        Reads each widget by its concrete type — QCheckBox → bool,
        QComboBox → str (current text), QLineEdit → float-if-parseable
        else str.
        """
        result = {}
        for aid, widgets in getattr(self, "_mne_params", {}).items():
            cb = self._mne_checks.get(aid)
            if cb and cb.isChecked():
                params = {}
                for key, w in widgets.items():
                    if isinstance(w, QCheckBox):
                        params[key] = bool(w.isChecked())
                    elif isinstance(w, QComboBox):
                        params[key] = w.currentText()
                    else:  # QLineEdit
                        try:
                            params[key] = float(w.text())
                        except ValueError:
                            params[key] = w.text()
                result[aid] = params
        return result

    def _collect_mne_advanced_open(self):
        """Return {id: bool} of Advanced disclosure open state per entry.

        Reads disclosure state from each registered widget; supports both
        the legacy QGroupBox/QPushButton (isChecked) and the current
        CollapsibleStep (content visibility).
        """
        boxes = getattr(self, "_mne_advanced_groupboxes", {})
        return {aid: _is_disclosure_open(w) for aid, w in boxes.items()}

    @staticmethod
    def _migrate_legacy_psd_bands_topomap(cfg):
        """Rewrite legacy `psd_bands_topomap` references to live under the
        unified `psd_topomap` entry (collapsed in 2026-05-01)."""
        mne_ids = cfg.get("mne_catalog", []) or []
        if "psd_bands_topomap" in mne_ids:
            mne_ids = [aid if aid != "psd_bands_topomap" else "psd_topomap"
                       for aid in mne_ids]
            # de-dup while preserving order
            seen = set()
            cfg["mne_catalog"] = [a for a in mne_ids
                                  if not (a in seen or seen.add(a))]
        mne_par = cfg.get("mne_params", {}) or {}
        legacy = mne_par.pop("psd_bands_topomap", None)
        if legacy and "bands" in legacy:
            mne_par.setdefault("psd_topomap", {})["bands"] = legacy["bands"]
        cfg["mne_params"] = mne_par

    # ── Tab: Run ─────────────────────────────────────────────────────

    def _build_run_tab(self):
        layout = QVBoxLayout(self._tab_run)

        # Config path row
        cfg_row = QHBoxLayout()
        cfg_row.addWidget(QLabel("Config:"))
        self._run_config_edit = QLineEdit(
            str(self.config_path or ""))
        cfg_row.addWidget(self._run_config_edit)
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse_run_config)
        cfg_row.addWidget(browse_btn)
        layout.addLayout(cfg_row)

        # Run / Stop buttons
        btn_row = QHBoxLayout()
        self._run_btn = QPushButton("\u25b6  Run Pipeline")
        self._run_btn.setStyleSheet(
            "QPushButton { padding: 8px 24px; font-weight: bold; }")
        self._run_btn.setToolTip(
            "Run the full pipeline: all enabled preprocessing steps followed by\n"
            "all enabled analysis steps.\n"
            "Use the [Run] buttons in the Analysis tab to re-run a single\n"
            "analysis without repeating preprocessing.")
        self._run_btn.clicked.connect(self._run_pipeline)
        btn_row.addWidget(self._run_btn)
        self._stop_btn = QPushButton("\u25a0  Stop")
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop_pipeline)
        btn_row.addWidget(self._stop_btn)
        self._clear_log_btn = QPushButton("Clear")
        self._clear_log_btn.setToolTip("Clear the log output")
        self._clear_log_btn.clicked.connect(lambda: self._log_text.clear())
        btn_row.addWidget(self._clear_log_btn)
        self._auto_scroll_check = QCheckBox("Auto-scroll")
        self._auto_scroll_check.setChecked(True)
        self._auto_scroll_check.stateChanged.connect(
            lambda s: setattr(self, "_auto_scroll", bool(s)))
        btn_row.addWidget(self._auto_scroll_check)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        # Feature 11: per-file progress label
        self._file_progress_label = QLabel("")
        self._file_progress_label.setStyleSheet("color: gray;")
        layout.addWidget(self._file_progress_label)

        # Progress bar
        self._run_progress = QProgressBar()
        self._run_progress.setRange(0, 100)
        self._run_progress.setValue(0)
        layout.addWidget(self._run_progress)

        # ── Pipeline stage status (compact text) ──────────────────────
        self._stages_label = QLabel("")
        self._stages_label.setWordWrap(True)
        self._stages_label.setStyleSheet("padding: 4px; line-height: 1.6;")
        layout.addWidget(self._stages_label)
        self._stage_state = {}  # sid -> "pending"|"active"|"done"
        self._stage_enabled = {}  # sid -> bool



        # Log output splitter
        self._log_text = QTextEdit()
        self._log_text.setReadOnly(True)
        self._log_text.setFont(QFont("Menlo", 11))
        # Cap accumulated UI memory — without this, long pipelines
        # that emit tens of thousands of log lines (ICLabel, empi)
        # would push QTextEdit's document into the multi-GB range.
        # 50 000 blocks ≈ a few MB, plenty for review while bounded.
        self._log_text.document().setMaximumBlockCount(50000)
        layout.addWidget(self._log_text)

    def _browse_run_config(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select config file", "",
            "TOML files (*.toml);;All (*)")
        if path:
            self._run_config_edit.setText(path)

    def _run_pipeline(self):
        """Collect config and run the pipeline in a background thread."""
        if not self._mp_preflight_gui():
            return
        cfg = self._collect_config()
        self._launch_pipeline(cfg)

    def _launch_pipeline(self, cfg):
        """Validate, configure, and launch the pipeline in a background thread.

        Shared by both the Run Pipeline button and per-analysis Run buttons.
        """
        # Prevent concurrent pipeline runs
        if self._polling_active:
            self._msg_warning("Pipeline running",
                "A pipeline is already running. Wait for it to finish, "
                "or click Stop first.")
            return False
        # Interactive channel-review prompt still blocks the worker
        # thread — force off for GUI runs.  Segment review
        # (check_rest / check_epochs) now has a manual-hook path
        # (`_review_bad_epochs` below) that dispatches to Svarog or
        # to MNE on the main thread, so we leave those flags alone
        # and honour the user's config.
        cfg.setdefault("choosing_channels", {})["check_final_channels"] = False
        # Freeze the config hashes NOW, before pipeline side effects
        # mutate hashed sections (e.g. auto-detection appends to
        # choosing_channels.bad_channels during the bad_channels
        # step, and ICA populates ICA_EOG.bad_sources).  Step-save
        # snapshots use these values as their [cfg:...] marker so the
        # staleness check in _view_step_result sees a hash that
        # matches the GUI-time hash on a subsequent invocation.
        #
        # ``setdefault`` so a pre-pin from ``_run_truncated_pipeline``
        # (computed against the user-level cfg, before its scratch
        # truncation) survives into the runner.
        cfg.setdefault("_pipeline_config_hash",
                       _compute_preprocessing_hash(cfg))
        cfg.setdefault("_pipeline_step_hashes",
                       _compute_step_hashes(
                           cfg, effective_step_order(cfg)))
        from ide4eeg.preprocessing.mp_preprocessing import pin_mp_book_hash
        pin_mp_book_hash(cfg)

        inp = cfg.get("input_path", "")
        if not inp or not os.path.isfile(inp):
            self._msg_warning("No input",
                                "Select a valid input file first.")
            return False

        # Pre-flight checks
        fatal, warnings = self._preflight_check(cfg)
        if (fatal or warnings) and not self._show_preflight_warnings(
                fatal, warnings):
            return False

        self._last_run_cfg = cfg
        self._save_config_to_output(cfg)

        self._tabs.setCurrentIndex(self._tabs.indexOf(self._tab_run))

        self._pipeline_cancel.clear()
        self._run_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        # Drain stale log messages and clear display
        while not self.log_queue.empty():
            try: self.log_queue.get_nowait()
            except Exception: break
        self._log_text.clear()
        self._run_progress.setRange(0, 100)
        self._run_progress.setValue(0)
        self._polling_active = True
        self._active_stage_id = None
        self._mp_decomp_pct = 0  # reset MP fine-grained progress
        self._preproc_seen = set()

        # Reset stage status
        self._stage_state = {}
        from ide4eeg.main import mp_decomposition_enabled
        self._stage_enabled = {}
        for sid, _pat, _label, cfg_key in self._PIPELINE_STAGES:
            if cfg_key is None:
                enabled = True
            elif cfg_key == "_mp_step":
                # MP decomposition has no top-level flag any more;
                # enable state is "is mp_decomposition in step_order?".
                enabled = mp_decomposition_enabled(cfg)
            else:
                enabled = cfg.get(cfg_key, False)
            self._stage_enabled[sid] = enabled
        self._render_stages()

        # Set up queue-based logging
        handler = QueueLogHandler(self.log_queue)
        handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
        handler.setLevel(logging.INFO)
        root = logging.getLogger()
        if root.level > logging.INFO:
            root.setLevel(logging.INFO)
        root.addHandler(handler)
        self._queue_handler = handler
        self._log_timer.start(100)

        result_holder = {}
        self._pending_result_holder = result_holder

        # Hooks for interactive review steps.  Both dispatch to
        # Svarog when the installed jar supports the relevant
        # --select-mode value, falling back to the MNE viewer on
        # the main thread via a Qt signal.
        # Closures (not bound methods) so the config dict remains
        # deepcopy-safe — copy.deepcopy on a bound method would try
        # to deepcopy self (the whole QMainWindow), which fails on
        # Qt's C++ state.
        def _bad_channels_hook(signal, overlay_events,
                               tags_desc_id, scalings):
            return self._review_bad_channels(
                signal, overlay_events, tags_desc_id, scalings)

        def _manual_ica_hook(raw, ica):
            return self._review_ica_components(raw, ica)

        def _segments_hook(epochs, preselected_rejections=()):
            return self._review_bad_epochs(
                epochs, preselected_rejections)

        # MP decomposition is the only step with fine-grained per-iteration
        # progress; route its percent into _run_progress so the Run-tab
        # bar moves smoothly during the slowest single step.  Other
        # steps continue to advance the stage indicators only.
        def _mp_progress(pct):
            self._signals.mp_decomp_progress.emit(int(pct))

        manual_hooks = {
            "bad_channels": _bad_channels_hook,
            "ica": _manual_ica_hook,
            "segments": _segments_hook,
            "mp_progress": _mp_progress,
        }

        def worker():
            # On macOS, Qt widgets from a background thread crash
            # ("NSWindow should only be instantiated on the main
            # thread").  Switch to headless Agg so save-only pipeline
            # plots stay safe.  Linux/Windows have no such restriction
            # and keep Qt — otherwise interactive manual-review
            # handlers on the main thread would also be forced to Agg
            # (the backend is process-global) and hang.
            if sys.platform == "darwin":
                import matplotlib.pyplot as _plt
                _plt.switch_backend("Agg")
            tmp_path = None
            try:
                from ide4eeg.main import main as run_pipeline
                tmp = tempfile.NamedTemporaryFile(
                    suffix=".toml", delete=False, mode="w")
                tmp_path = tmp.name
                dump_toml(cfg, tmp_path); tmp.close()
                run_pipeline(tmp_path, result_holder=result_holder,
                             cancel_event=self._pipeline_cancel,
                             manual_hooks=manual_hooks)
                self._signals.pipeline_finished.emit(True)
            except Exception as e:
                import traceback
                logging.error("Pipeline failed: %s\n%s",
                              e, traceback.format_exc())
                self._signals.pipeline_finished.emit(False)
            finally:
                logging.getLogger().removeHandler(handler)
                if tmp_path:
                    try: os.unlink(tmp_path)
                    except OSError: pass

        threading.Thread(target=worker, daemon=True).start()
        return True

    def _save_config_to_output(self, cfg):
        """Save config.toml to the output directory before running."""
        pp_out = cfg.get("preprocessing_output_path", "")
        out_dir = os.path.dirname(pp_out) if pp_out else (cfg.get("output_path") or os.path.dirname(cfg.get("input_path", "")) or ".")
        try:
            os.makedirs(out_dir, exist_ok=True); cp = os.path.join(out_dir, "config.toml"); dump_toml(cfg, cp)
            if hasattr(self, "_run_config_edit"): self._run_config_edit.setText(cp)
            self.config_path = cp; self._status.showMessage(f"Saved config: {cp}", 3000)
        except Exception as e: self._msg_warning("Warning", f"Could not save config:\n{e}")

    def _stop_pipeline(self):
        self._pipeline_cancel.set()
        self._stop_btn.setEnabled(False)
        self._status.showMessage("Cancelling pipeline...", 5000)

    @Slot(bool)
    def _on_pipeline_finished(self, success):
        self._polling_active = False
        self._log_timer.stop()
        self._poll_log_queue()  # drain remaining
        self._run_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        # Phase 6: if the run was triggered by an eye click, auto-open
        # the viewer on success.  Consume the flag regardless so a
        # failed or cancelled run doesn't leak into the next run.
        pending_view = self._pending_view_step_key
        self._pending_view_step_key = None
        # Generic post-action (e.g. Bad Channels "Run and check"):
        # carries info about what the GUI should do once the unified
        # runner reports success.  Consumed-and-cleared even on
        # failure so it doesn't bleed into the next run.
        pending_post_action = self._pending_post_action
        self._pending_post_action = None
        self._run_progress.setRange(0, 100)
        self._run_progress.setValue(100)
        # Mark remaining active stage as done
        if self._active_stage_id:
            self._set_stage_done(self._active_stage_id)
            self._active_stage_id = None
        # Cache pipeline results for analysis Run buttons
        holder = getattr(self, "_pending_result_holder", None)
        if success and holder: self._pipeline_data = dict(holder)
        if success:
            self._status.showMessage("Pipeline finished", 10000)
            # Append completion message to log
            self._log_text.setTextColor(QColor("#4caf50"))
            self._log_text.append("\n✓ Pipeline finished successfully.\n")
            self._refresh_output_tree()
            self._auto_focus_latest_output()
            # Phase 6: if the run was triggered by an eye click, skip
            # the auto-switch to the Output tab and re-dispatch the
            # viewer instead (happy path now that snapshots exist).
            if pending_view:
                # ``is_reentry=True`` arms the loop guard inside
                # ``_view_step_result`` — if the snapshot still looks
                # stale after a just-finished truncated run, bail out
                # with a logged diagnostic instead of spawning another.
                QTimer.singleShot(
                    0,
                    lambda k=pending_view: self._view_step_result(
                        k, is_reentry=True))
            elif pending_post_action == "open_gaze_after_run":
                QTimer.singleShot(
                    0,
                    lambda: self._open_gaze_window(is_reentry=True))
            elif pending_post_action == "bad_channels_label":
                # Bad Channels "Run and check" routed through the
                # unified runner; pipeline state's bad_channels list
                # is what the panel's body label + header should show.
                final_cfg = (holder or {}).get("config", {})
                bads = final_cfg.get("choosing_channels", {}).get(
                    "bad_channels", [])
                msg = ", ".join(bads) if bads else (
                    "No bad channels detected.")
                self._on_pipeline_log(f"BAD_CHANNELS:{msg}", "INFO")
            elif pending_post_action == "mp_decomp_done":
                # MP "Run decomposition" routed through the unified
                # runner; refresh the book panels so the new .db
                # appears in their dropdowns, cache the path so the
                # MP panel's eye reuses it, and update the panel's
                # status indicator.
                final_cfg = (holder or {}).get("config", {})
                book = final_cfg.get("_mp_book_path", "")
                if book and os.path.isfile(book):
                    self._mp_book_path = book
                    self._status.showMessage(
                        f"MP book saved: {os.path.basename(book)}",
                        5000)
                self._refresh_book_panels()
                if "mp_run_status" in self._pp:
                    self._pp["mp_run_status"].setText("Done")
                self._tabs.setCurrentWidget(self._tab_output)
            else:
                self._tabs.setCurrentWidget(self._tab_output)
            # Restore analysis Run button if triggered from Analysis tab
            grp = getattr(self, "_pending_analysis_grp", None)
            if grp:
                if grp._run_btn: grp._run_btn.setEnabled(True)
                grp.setStatusText("\u2713 done")
                self._pending_analysis_grp = None
            # Auto-launch connectivis for dipole / connectivity
            cfg = getattr(self, "_last_run_cfg", {})
            ak = getattr(self, "_pending_analysis_key", "")
            out = cfg.get("_analysis_output_path") or cfg.get("analysis_output_path") or cfg.get("output_path", "")
            if out:
                self._auto_launch_connectivis(cfg, out)
            # Auto-open in SVAROG for EEG profiles if checkbox checked
            # OR if the eye-button forced it for this run.
            if ak == "prepare_eeg_profiles":
                bp = self._an.get("prof_book_panel")
                book = bp.selected_book() if bp else ""
                ch_name = bp.selected_channel() if bp else ""
                tag = self._find_profile_tag(book, ch_name)
                auto_cb = self._an.get("prof_auto_svarog")
                forced = self._force_profile_svarog_open
                self._force_profile_svarog_open = False
                if tag and (forced
                            or (auto_cb and auto_cb.isChecked())):
                    self._open_profile_tag_in_svarog(
                        tag, book=book, channel=ch_name)
            self._pending_analysis_key = ""
        else:
            grp = getattr(self, "_pending_analysis_grp", None)
            if grp:
                if grp._run_btn: grp._run_btn.setEnabled(True)
                grp.setStatusText("\u2717 error")
                self._pending_analysis_grp = None
            self._pending_analysis_key = ""
            # Mirror the failure on the MP panel's status indicator
            # when the run was kicked off via "Run decomposition".
            # Cancellation goes through the same failure branch
            # (worker raises InterruptedError) so we can't distinguish
            # error-vs-cancel here without parsing the log.
            if (pending_post_action == "mp_decomp_done"
                    and "mp_run_status" in self._pp):
                self._pp["mp_run_status"].setText("Cancelled / Error")
            self._status.showMessage("Pipeline failed -- see Run tab", 10000)
            self._tabs.setCurrentWidget(self._tab_run)
            # Extract last error from log for the dialog
            log_text = self._log_text.toPlainText()
            err_lines = [l for l in log_text.splitlines()
                         if l.startswith("ERROR:")]
            last_err = err_lines[-1][7:] if err_lines else ""
            self._show_pipeline_error(last_err)

    def _poll_log_queue(self):
        """Drain queued log records into the Run tab text widget.

        Writes through a dedicated end-of-document cursor rather than
        the widget's visible cursor — otherwise clicking the log to
        select / copy text moves the visible cursor, and the next
        ``insertPlainText`` lands at the click point, scrambling the
        log mid-stream (lines appearing to disappear, content shifting
        on click).
        """
        from PySide6.QtGui import QTextCharFormat
        default_color = self._log_text.palette().text().color()
        write_cursor = QTextCursor(self._log_text.document())
        write_cursor.movePosition(QTextCursor.End)
        count = 0
        while count < 50:
            try:
                record = self.log_queue.get_nowait()
            except queue.Empty:
                break
            if record is None:
                continue
            try:
                msg = self._queue_handler.format(record) + "\n"
            except Exception:
                msg = f"{record.levelname}: {record.msg}\n"

            # Track pipeline stage from log messages
            self._match_stage(msg)

            color = {"ERROR": "#e53935", "WARNING": "#f9a825",
                     "DEBUG": "#78909c", "INFO": "#4ec9b0",
                     "CRITICAL": "#c586c0"}.get(record.levelname, None)
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(color) if color else default_color)
            write_cursor.insertText(msg, fmt)
            count += 1

        if count and self._auto_scroll:
            self._log_text.verticalScrollBar().setValue(
                self._log_text.verticalScrollBar().maximum())

    # Preprocessing substep patterns (matched while "preproc" stage is active)
    _PREPROC_SUBSTEPS = [
        ("Data with sampling frequency", "Resampling"),
        ("will be not resample",         "Resampling"),
        ("Channels with too much noise", "Bad channels"),
        ("Picked electrodes layout",     "Montage"),
        ("Filters for provided data",    "Filtering"),
        ("No filters applied",           "Filtering"),
        ("Baseline",                     "Baseline"),
        ("ICA",                          "ICA"),
        ("Chosen Channels",              "Channels"),
    ]

    # Progress patterns: (stage_id, regex, cur_group, tot_group, detail_fmt)
    _PROGRESS_PATTERNS = [
        ("preproc", r"MP decomposition:\s*(\d+)%",                       1, 0, "MP decomposition {0}%"),
        ("video",   r"FaceTag:\s*(\d+)/(\d+)\s+frames",                  1, 2, "{0}/{1} frames"),
        ("conn",    r"Connectivity:\s*(\d+)/(\d+)\s+\(\d+%\)\s+computing\s+(.+?)\s+for", 1, 2, "({0}/{1}) {2}"),
        ("dip",     r"Dipole fitting:\s*(\d+)/(\d+)\s+\(\d+%\)",         1, 2, "({0}/{1})"),
    ]

    def _match_stage(self, msg):
        """Check if a log message signals a new pipeline stage or progress."""
        # Track total file count from "Signals found:" log
        if "Signals found:" in msg:
            self._total_files = max(1, msg.count("* "))
            self._current_file = 0

        # Per-file progress label
        if "Starting work with" in msg:
            parts = msg.split("Starting work with", 1)
            if len(parts) > 1:
                fname = parts[1].split("\n")[0].strip().rstrip(". ")
                self._current_file = getattr(self, "_current_file", 0) + 1
                total = getattr(self, "_total_files", 0)
                lbl = getattr(self, "_file_progress_label", None)
                if lbl:
                    if total > 0:
                        lbl.setText(f"File {self._current_file}/{total}: "
                                    f"{os.path.basename(fname)}")
                    else:
                        lbl.setText(f"Processing: {os.path.basename(fname)}")

        # File done — mark all stages complete
        if "Ending work with" in msg:
            if self._active_stage_id:
                self._set_stage_done(self._active_stage_id)
                self._active_stage_id = None
            self._update_overall_progress()
            return

        # Stage activation
        for sid, pattern, _label, _cfg_key in self._PIPELINE_STAGES:
            if pattern in msg:
                if self._active_stage_id and self._active_stage_id != sid:
                    self._set_stage_done(self._active_stage_id)
                self._active_stage_id = sid
                self._set_stage_active(sid)
                self._update_overall_progress()
                break

        # Preprocessing substep tracking (advance determinate bar)
        if self._active_stage_id == "preproc":
            for pattern, substep in self._PREPROC_SUBSTEPS:
                if pattern in msg:
                    self._update_stage_detail("preproc", substep)
                    if not hasattr(self, "_preproc_seen"):
                        self._preproc_seen = set()
                    if substep not in self._preproc_seen:
                        self._preproc_seen.add(substep)
                        self._set_stage_determinate(
                            "preproc", len(self._preproc_seen), 7)
                    break

        # Detailed progress patterns (MP%, video frames, connectivity, etc.)
        for sid, pattern, cur_g, tot_g, detail_fmt in self._PROGRESS_PATTERNS:
            if self._active_stage_id != sid:
                continue
            m = re.search(pattern, msg)
            if m:
                g = m.groups()
                self._update_stage_detail(sid, detail_fmt.format(*g))
                if tot_g > 0:
                    cur = int(g[cur_g - 1])
                    tot = int(g[tot_g - 1])
                    self._set_stage_determinate(sid, cur, tot)
                elif cur_g > 0:
                    # Percentage only (e.g., MP decomposition)
                    pct = int(g[cur_g - 1])
                    self._set_stage_determinate(sid, pct, 100)
                break

        # Video total frames setup
        if self._active_stage_id == "video" and "Processing video:" in msg:
            m = re.search(r"Processing video:\s*(\d+)\s+frames", msg)
            if m:
                self._set_stage_determinate("video", 0, int(m.group(1)))

    def _render_stages(self):
        """Redraw the compact stage status label."""
        parts = []
        for sid, _pat, label, _cfg_key in self._PIPELINE_STAGES:
            if not self._stage_enabled.get(sid, False):
                continue
            st = self._stage_state.get(sid, "pending")
            if st == "done":
                parts.append(f'<span style="color:#2e7d32;">\u2713 {label}</span>')
            elif st == "active":
                parts.append(f'<span style="color:#1565c0;font-weight:bold;">\u25b6 {label}\u2026</span>')
            else:
                parts.append(f'<span style="color:gray;">\u2610 {label}</span>')
        self._stages_label.setText("&nbsp;&nbsp;".join(parts))

    def _set_stage_active(self, stage_id):
        self._stage_state[stage_id] = "active"
        self._render_stages()

    def _set_stage_done(self, stage_id):
        self._stage_state[stage_id] = "done"
        self._render_stages()

    def _set_stage_determinate(self, stage_id, value, maximum):
        pass  # progress shown in main bar

    def _update_stage_detail(self, stage_id, detail):
        pass  # detail shown in log

    def _update_overall_progress(self):
        enabled = [s for s in self._stage_enabled if self._stage_enabled[s]]
        if not enabled:
            return
        done = sum(1 for s in enabled if self._stage_state.get(s) == "done")
        # Fold fine-grained per-iteration progress for the active stage
        # into the bar so it advances smoothly within that stage rather
        # than just on stage-boundary transitions.  Currently only MP
        # decomposition emits sub-stage progress.
        fractional = 0.0
        if (self._active_stage_id == "mp"
                and self._active_stage_id in enabled
                and self._stage_state.get(self._active_stage_id) == "active"):
            fractional = max(0, min(100, self._mp_decomp_pct)) / 100.0
        pct = int((done + fractional) / len(enabled) * 100)
        self._run_progress.setRange(0, 100)
        self._run_progress.setValue(pct)

    # ── Gaze detection ─────────────────────────────────────────────────

    # ── Dynamic info labels ──────────────────────────────────────────

    _MONTAGE_ALIAS = {"10-20": "standard_1020", "10-10": "standard_1005",
                       "10-05": "standard_1005"}

    def _apply_native_positions_lock(self):
        """Prefill & lock the montage combo when the file provides
        its own 3D electrode positions.

        Matches the pipeline behaviour in
        preprocessing.channels_and_signal._set_montage: if every EEG
        channel already has valid coordinates (MNE sample FIF, some
        BrainVision / SET files), applying a standard montage would
        blank them out.  The combo is set to the native sentinel
        and disabled so the GUI shows exactly what the pipeline
        will do.  Re-enabled automatically when a file without
        native positions is loaded.
        """
        pp = getattr(self, "_pp", {})
        combo = pp.get("montage")
        if combo is None:
            return
        has_native = bool(getattr(self, "_has_native_positions", False))
        hint = getattr(self, "_montage_hint", None)
        if has_native:
            combo.blockSignals(True)
            combo.setCurrentText(NATIVE_POSITIONS_SENTINEL)
            combo.blockSignals(False)
            combo.setEnabled(False)
            combo.setToolTip(
                "File already provides real 3D electrode positions\n"
                "for every EEG channel — they will be used as-is.\n"
                "Standard montages would blank these out and are\n"
                "disabled for this file.")
        elif hint is not None:
            combo.setEnabled(True)
            combo.blockSignals(True)
            combo.setCurrentText(hint)
            combo.blockSignals(False)
            combo.setToolTip(
                f"Prefilled from the file's eegSystemSymbol "
                f"metadata ({hint}). Change if your cap differs.")
        else:
            combo.setEnabled(True)
            combo.setToolTip("")
            # File lacks native positions and there's no eegSystemSymbol
            # hint.  If the combo is still parked on the sentinel
            # (default), switch it to "10-20" — that's what _set_montage
            # falls back to anyway, and showing it here keeps the panel
            # honest (the eye preview, montage_match summary, and the
            # generated config all match what the pipeline will run).
            if combo.currentText() == NATIVE_POSITIONS_SENTINEL:
                combo.blockSignals(True)
                combo.setCurrentText("10-20")
                combo.blockSignals(False)

    def _update_montage_availability(self):
        """Disable montage combo items that have zero matching channels."""
        pp = getattr(self, "_pp", {})
        combo = pp.get("montage")
        sig = self._cached_signal
        if not combo or sig is None:
            return
        import mne
        file_chs = set(sig.ch_names)
        model = combo.model()
        has_native = bool(getattr(self, "_has_native_positions", False))
        for i in range(combo.count()):
            name = combo.itemText(i)
            if name == NATIVE_POSITIONS_SENTINEL:
                n_match = len(file_chs) if has_native else 0
            else:
                mne_name = self._MONTAGE_ALIAS.get(
                    name, name.replace("-", "_"))
                try:
                    m = mne.channels.make_standard_montage(mne_name)
                    n_match = len(file_chs & set(m.ch_names))
                except Exception:
                    n_match = 0
            # Disable items with no matches (gray out)
            item = model.item(i)
            if item:
                item.setEnabled(n_match > 0)

    def _update_montage_match(self, *_a):
        """Update montage match summary."""
        pp = getattr(self, "_pp", {}); lbl = pp.get("montage_match")
        if not lbl: return
        raw = self._cmb(pp, "montage", "10-20")
        # Native-positions case: check BEFORE the sig-is-None guard,
        # because MNE readers (FIF/EDF/...) don't eagerly populate
        # _cached_signal — only BrainTech does.  The
        # _has_native_positions flag comes from read_file_info and
        # is available even without a cached signal.
        if raw == NATIVE_POSITIONS_SENTINEL:
            lbl.setText("Electrode positions will be used from the file.")
            return
        sig = self._cached_signal
        if sig is None: lbl.setText(""); return
        file_chs = set(sig.ch_names)
        mne_name = self._MONTAGE_ALIAS.get(raw, raw.replace("-", "_"))
        try:
            import mne; m = mne.channels.make_standard_montage(mne_name)
            montage_chs = set(m.ch_names)
        except Exception: lbl.setText(f"Cannot load montage '{mne_name}'"); return
        matched = file_chs & montage_chs; miss = file_chs - montage_chs
        parts = [f"{len(matched)}/{len(file_chs)} channels matched"]
        if miss:
            ul = ", ".join(sorted(miss)[:12]) + ("\u2026" if len(miss) > 12 else "")
            parts.append(f"{len(miss)} not in montage: {ul}")
        lbl.setText(" | ".join(parts))

    def _update_reref_status(self, *_a):
        """Update re-reference validation label (body always; header
        mirror only for the Custom preset).

        The Linked-mastoids / Linked-ears presets already name their
        channels in the combo title, so duplicating those names in
        the header would be noise.  Body validation still runs for
        every channel-list rr value.
        """
        pp = getattr(self, "_pp", {})
        lbl = pp.get("reref_status")
        hdr = pp.get("reref_header_info")
        if not lbl:
            return
        sig = self._cached_signal
        rr = self._txt(pp, "reref", "")
        cust_row = pp.get("_reref_cust_row")
        is_custom = bool(cust_row and cust_row.isVisible())

        def _set_hdr(text="", color="gray"):
            if hdr:
                hdr.setStyleSheet(f"color: {color};")
                hdr.setText(text)

        if not rr or not sig or rr.lower() in ("average", "rest", "none"):
            lbl.setText("")
            _set_hdr()
            return
        refs = [s.strip() for s in rr.split(",") if s.strip()]
        ch_set = set(sig.ch_names)
        missing = [r for r in refs if r not in ch_set]
        if not missing:
            lbl.setStyleSheet("color: #2e7d32;")
            lbl.setText(f"\u2713 {', '.join(refs)} found in signal")
            if is_custom:
                _set_hdr(f"\u2713 {', '.join(refs)}", "gray")
            else:
                _set_hdr()
        else:
            lbl.setStyleSheet("color: #c62828;")
            lbl.setText(f"\u26a0 {', '.join(missing)} not found")
            if is_custom:
                _set_hdr(f"\u26a0 {', '.join(missing)} not found", "#c62828")
            else:
                _set_hdr()

    @staticmethod
    def _parse_optional_float(text):
        """Parse a baseline-edit string → float, or None for blank /
        explicit 'None'.  Used for the Custom baseline (start, end)
        fields; an empty side means 'from epoch start' or 'to epoch
        end' per MNE's baseline tuple convention."""
        s = (text or "").strip()
        if not s or s.lower() == "none":
            return None
        try:
            return float(s)
        except ValueError:
            return None

    @staticmethod
    def _baseline_to_combo_text(value):
        """Map an ``epochs_baseline`` config value → combo display text.

        Recognised presets round-trip to their fixed combo entries;
        anything else falls back to 'Custom' (which then drives the
        custom (start, end) edits).
        """
        if value is None or value == "None":
            return "None"
        if isinstance(value, str):
            stripped = value.strip()
            if stripped in {"None", "(start, 0)", "(None, 0)", "(0, stop)"}:
                return stripped
            return "Custom"
        if isinstance(value, (list, tuple)):
            pair = list(value) + [None, None]
            s, e = pair[0], pair[1]
            if s is None and (e == 0 or e == 0.0):
                return "(start, 0)"
            if (s == 0 or s == 0.0) and e is None:
                return "(0, stop)"
            return "Custom"
        return "Custom"

    @staticmethod
    def _fmt_time(s):
        """Format seconds as 'Xh Ym Zs' or 'Ym Zs' or 'Zs'."""
        if s < 0:
            return "0s"
        h = int(s // 3600)
        m = int((s % 3600) // 60)
        sec = s % 60
        if h:
            return f"{h}h {m:02d}m {sec:04.1f}s"
        if m:
            return f"{m}m {sec:04.1f}s"
        return f"{sec:.1f}s"

    def _update_trim_duration(self, *_a):
        """Update trim duration and per-field info labels."""
        pp = getattr(self, "_pp", {})
        hdr = pp.get("trim_header_info")
        if hdr is None:
            return
        sfreq = getattr(self, "_cached_sfreq", None)
        total = getattr(self, "_cached_duration", None)
        if total is None:
            hdr.setText("")
            hdr.setStyleSheet("color: gray;")
            for k in ("trim_start_info", "trim_end_info"):
                info = pp.get(k)
                if info:
                    info.setText("")
                    info.setStyleSheet("color: gray;")
            return

        try:
            t0 = float(self._txt(pp, "trim_start", "0") or "0")
        except ValueError:
            t0 = 0.0
        te = self._txt(pp, "trim_end", "")
        try:
            t1 = float(te) if te else total
        except ValueError:
            t1 = total

        # Per-field info: points + time, plus out-of-range warnings.
        # The pipeline silently clamps trim_start/trim_end to the
        # signal bounds (channels_and_signal._trim_signal); without a
        # warning, a typo like "trim_end=10000" on a 9 905 s signal
        # would produce no error and be invisible until you compare
        # the configured vs. actual duration.
        info_pairs = ((t0, "trim_start_info", t0 > total),
                      (t1 if te else None, "trim_end_info",
                       bool(te) and t1 > total))
        for val, key, oor in info_pairs:
            info = pp.get(key)
            if not info:
                continue
            if val is None:
                info.setText("(end)")
                info.setStyleSheet("color: gray;")
                continue
            if sfreq:
                pts = int(val * sfreq)
                base = f"= {pts} pts, {self._fmt_time(val)}"
            else:
                base = f"= {self._fmt_time(val)}"
            if oor:
                info.setText(
                    f"{base} — exceeds signal length "
                    f"{self._fmt_time(total)} (will be clamped)")
                info.setStyleSheet("color: #c62828;")
            else:
                info.setText(base)
                info.setStyleSheet("color: gray;")

        # Cross-field check: start must precede end.
        bad_order = bool(te) and t0 > t1
        # Compute the duration the pipeline will actually produce
        # (after clamping), so the user sees ground-truth.
        t0_eff = max(0.0, min(t0, total))
        t1_eff = max(t0_eff, min(t1, total))
        after = max(0.0, t1_eff - t0_eff)
        # Suppress the "after trim" half when nothing is actually
        # trimmed — full signal is in use, the bare total is enough.
        is_trimmed = (t0 > 0) or bool(te)
        if is_trimmed:
            text = (f"{self._fmt_time(total)} total, "
                    f"{self._fmt_time(after)} after trim")
        else:
            text = f"{self._fmt_time(total)} total"
        if bad_order:
            text += "  — trim start > end (empty signal)"
        hdr.setText(text)
        hdr.setStyleSheet(
            "color: #c62828;" if bad_order else "color: gray;")

    def _update_resample_header_info(self, *_a):
        """Refresh the Resample panel header summary.

        Shows "original sampling: NNN Hz" when no resampling is
        configured, "NNN Hz, resampled to MMM Hz" otherwise.  Falls
        back to a placeholder when no signal is loaded yet.
        """
        pp = getattr(self, "_pp", {})
        hdr = pp.get("resample_header_info")
        if not hdr:
            return
        sf = getattr(self, "_cached_sfreq", None)
        if not sf:
            hdr.setText("(load a file to see sampling rate)")
            hdr.setStyleSheet("color: gray;")
            return
        sf_int = int(round(sf))
        rf_text = self._txt(pp, "resample_freq", "").strip()
        try:
            rf = int(float(rf_text)) if rf_text else 0
        except ValueError:
            rf = 0
        if rf > 0 and rf != sf_int:
            hdr.setText(f"{sf_int} Hz, resampled to {rf} Hz")
        else:
            hdr.setText(f"original sampling: {sf_int} Hz")
        hdr.setStyleSheet("color: gray;")

    @staticmethod
    def _gabor_dict_size(eps2, n_samples, n_channels=1):
        """Approximate number of Gabor atoms in the dictionary."""
        import math
        if eps2 <= 0 or eps2 >= 1 or n_samples <= 1: return 0
        eps = math.sqrt(eps2)
        a = (1 + eps * math.sqrt((2 - eps2) * (eps2**2 - 2*eps2 + 2))) / (1 - eps2)**2
        if a <= 1: return 0
        return math.ceil(0.5 * math.pi * n_samples * math.log(n_samples)
                         / math.log(a) / abs(math.log(1 - eps2))) * n_channels

    def _validate_mp_energy(self):
        """Clamp the MP energy % field into ``[0, 100]``.

        100 is allowed and equivalent to "stop only when the iteration
        cap is hit" — that's how Svarog drives empi too; the runner
        passes a tiny residual so empi doesn't reject ``-r 0``.
        """
        pp = getattr(self, "_pp", {})
        try:
            pct = float(self._txt(pp, "mp_energy", "95") or "95")
        except ValueError:
            return
        if pct < 0 or pct > 100:
            self._msg_warning("Invalid energy %",
                "MP energy % must be between 0 and 100. "
                "100 means 'stop only at the iteration cap'.")
            pp["mp_energy"].setText("100" if pct > 100 else "0")

    def _update_mp_dict_size(self, *_a):
        """Update MP dictionary size estimate based on segment size."""
        pp = getattr(self, "_pp", {}); lbl = pp.get("mp_dict_size")
        if not lbl: return
        sfreq = getattr(self, "_cached_sfreq", None)
        if sfreq is None: lbl.setText(""); return
        # Segment duration depends on mode
        mode = self._mode
        if mode == "epochs":
            t0 = self._num(pp, "ep_start", -0.3)
            t1 = self._num(pp, "ep_stop", 0.7)
            seg_dur = abs(t1 - t0)
        else:
            whole = self._chk(pp, "rest_whole")
            wl = self._num(pp, "rest_window", 20)
            if whole or wl <= 0:
                seg_dur = getattr(self, "_cached_duration", 20) or 20
            else:
                seg_dur = wl
        n_samples = max(1, int(sfreq * seg_dur))
        eps2 = 0.01
        algo = self._cmb(pp, "mp_algo", "smp"); n_ch = 1
        if "mmp" in algo.lower():
            sig = self._cached_signal; n_ch = len(sig.ch_names) if sig else 1
        count = self._gabor_dict_size(eps2, n_samples, n_ch)
        lbl.setText(f"~{count:,} dict. atoms" if count > 0 else "")

    def _update_face_counts(self):
        """Count image files in reference/exclude directories."""
        pp = getattr(self, "_pp", {})
        lbl = pp.get("face_count_lbl")
        if not lbl:
            return
        ref_dir = self._txt(pp, "ref_dir", "")
        excl_dir = self._txt(pp, "excl_dir", "")

        def _count(d):
            if not d or not os.path.isdir(d):
                return 0
            exts = (".jpg", ".jpeg", ".png", ".bmp")
            return sum(1 for f in os.listdir(d)
                       if os.path.splitext(f)[1].lower() in exts)

        n_ref = _count(ref_dir)
        n_excl = _count(excl_dir)

        def _fmt_path(d):
            """Display-friendly path: collapse $HOME to ~."""
            if not d:
                return ""
            home = os.path.expanduser("~")
            return (f"~{d[len(home):]}" if d.startswith(home + os.sep)
                    else d)

        # Update per-button labels
        ref_lbl = pp.get("ref_count_lbl")
        if ref_lbl:
            ref_suffix = f" in {_fmt_path(ref_dir)}" if ref_dir else ""
            ref_lbl.setText(
                f"subject looking at the screen, "
                f"{n_ref} selected{ref_suffix}")
            ref_lbl.setStyleSheet("color: gray;")
        excl_lbl = pp.get("excl_count_lbl")
        if excl_lbl:
            excl_suffix = f" in {_fmt_path(excl_dir)}" if excl_dir else ""
            excl_lbl.setText(
                f"non-subject(s), {n_excl} selected{excl_suffix}")
            excl_lbl.setStyleSheet("color: gray;")
        # Legacy label (hidden)
        lbl.setText(
            f"Reference faces: {n_ref}  |  Exclude faces: {n_excl}")
        # Compact header summary parked left of the eye button.
        gaze_info = pp.get("gaze_header_info")
        if gaze_info is not None:
            gaze_info.setText(f"ref {n_ref}, excl {n_excl}")

    def _change_face_folder(self, mode):
        """Point the reference/exclude face list at a different folder.

        Opens a directory picker; on confirm, updates the hidden
        ``ref_dir`` / ``excl_dir`` QLineEdit whose ``textChanged``
        signal refreshes the count label via ``_update_face_counts``.
        Cancel is a no-op.
        """
        pp = getattr(self, "_pp", {})
        dir_key = "ref_dir" if mode == "reference" else "excl_dir"
        title = ("Choose reference faces folder" if mode == "reference"
                 else "Choose exclude faces folder")
        current = self._txt(pp, dir_key, "")
        chosen = QFileDialog.getExistingDirectory(self, title, current)
        if chosen:
            self._pp[dir_key].setText(chosen)

    def _update_montage_desc(self, *_a):
        """Update montage description text from _MONTAGE_INFO."""
        pp = getattr(self, "_pp", {})
        lbl = pp.get("montage_desc")
        if not lbl:
            return
        from ide4eeg.gui_config import MONTAGE_INFO as info_dict
        raw = self._cmb(pp, "montage", "10-20")
        _alias = {"10-20": "10-20", "10-10": "standard_1020",
                  "10-05": "standard_1005"}
        key = _alias.get(raw, raw)
        info = info_dict.get(key)
        if info:
            lbl.setText(info[2])
        else:
            lbl.setText("")

    def _open_trim_preview(self):
        """Open the Qt trim preview window."""
        pp = getattr(self, "_pp", {})
        eeg_path = self._input_edit.text().strip()
        if not eeg_path or not os.path.isfile(eeg_path):
            self._msg_warning("No input",
                                "Select a valid input file first.")
            return
        video_path = self._video_edit.text().strip() or None
        try:
            from ide4eeg.preprocessing.facetag.trim_window_qt import TrimWindowQt
            ts = self._pn(self._txt(pp, "trim_start", "0"), 0.0)
            te_str = self._txt(pp, "trim_end", "")
            te = self._pn(te_str, None) if te_str else None

            def on_apply(start, end):
                self._set_edit(pp, "trim_start", start)
                self._set_edit(pp, "trim_end",
                               end if end is not None else "")

            win = TrimWindowQt(
                parent=self, eeg_path=eeg_path,
                video_path=video_path,
                trim_start=ts, trim_end=te,
                on_apply=on_apply)
            win.show()
            if not hasattr(self, "_trim_windows"):
                self._trim_windows = []
            self._trim_windows.append(win)
        except Exception as e:
            self._msg_error("Error", str(e))

    def _open_face_picker(self, mode="reference"):
        """Open the Qt face picker to select reference or exclude faces.

        Parameters
        ----------
        mode : str
            ``"reference"`` or ``"exclude"``.
        """
        pp = getattr(self, "_pp", {})
        video_path = self._video_edit.text().strip()
        if not video_path:
            self._msg_error("Error",
                "No video file set.\nSet a video path in the Paths section.")
            return

        if mode == "exclude":
            save_dir = self._txt(pp, "excl_dir", "")
            title = "Select exclude faces"
            dir_key = "excl_dir"
        else:
            save_dir = self._txt(pp, "ref_dir", "")
            title = "Select reference faces"
            dir_key = "ref_dir"

        # Default save_dir under the preprocessing output directory
        # (e.g. <output>/IDE4EEG_OUT_<base>/preprocessing/reference_faces/)
        # so reference photos travel with the per-recording results
        # rather than polluting the input/video directory.  Refuse
        # when the preprocessing path can't be resolved — falling back
        # to the video directory would re-introduce the legacy layout
        # we just removed; better to nudge the user to set an input
        # file first.
        if not save_dir:
            preproc = self._fallback_preproc_path()
            if not preproc:
                self._msg_error(
                    "No output directory",
                    "Reference / exclude photos are saved under the "
                    "per-recording results directory "
                    "(IDE4EEG_OUT_<base>/preprocessing/).  Set the "
                    "Input or Output path in the Paths section "
                    "before picking faces.")
                return
            base = preproc
            save_dir = os.path.join(
                base, _EXCLUDE_FACES_DIRNAME if mode == "exclude"
                else _REFERENCE_FACES_DIRNAME)
            os.makedirs(save_dir, exist_ok=True)
            # Set path in GUI so face count updates immediately
            pp[dir_key].setText(save_dir)
            self._update_face_counts()

        backend = self._cmb(pp, "gaze_method", "l2cs")
        det_size = int(self._num(pp, "det_size", 0))
        face_tol = self._num(pp, "face_tol", 0.6)

        # Check for existing files using styled dialog
        keep_existing = False
        if os.path.isdir(save_dir):
            from ide4eeg.preprocessing.facetag.auto_detect_qt import (
                IMAGE_EXTENSIONS)
            existing = [f for f in os.listdir(save_dir)
                        if os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS]
            if existing:
                answer = self._styled_dialog(
                    "Existing files", "Existing files",
                    f"The save directory already contains "
                    f"{len(existing)} image(s):\n{save_dir}",
                    self.style().StandardPixmap.SP_MessageBoxQuestion,
                    [("Delete && start fresh", "delete"),
                     ("Keep && add more", "keep"),
                     ("Cancel", "reject")])
                if answer == "delete":
                    for f in existing:
                        os.remove(os.path.join(save_dir, f))
                    self._update_face_counts()
                elif answer == "keep":
                    keep_existing = True
                else:
                    return  # Cancel

        def _on_done(d):
            pp[dir_key].setText(d)
            self._update_face_counts()

        try:
            from ide4eeg.preprocessing.facetag.auto_detect_qt import (
                AutoDetectWindowQt)
            ts = self._pn(self._txt(pp, "trim_start", "0"), 0.0)
            te_str = self._txt(pp, "trim_end", "")
            te = self._pn(te_str, None) if te_str else None
            win = AutoDetectWindowQt(
                self, video_path, save_dir=save_dir, title=title,
                backend_name=backend, det_size=det_size,
                face_tolerance=face_tol, on_done=_on_done,
                keep_existing=keep_existing,
                trim_start=ts, trim_end=te)
            win.show()
            if not hasattr(self, "_face_picker_windows"):
                self._face_picker_windows = []
            self._face_picker_windows.append(win)
        except Exception as e:
            self._msg_error("Error", str(e))

    def _refresh_gaze_method_badge(self, *_args):
        """Update the gaze Method badge based on backend availability.

        Two layers of missing-deps warnings:

        1. **Core video stack incomplete** (cv2 / av / imageio /
           insightface / onnxruntime).  Fires regardless of which
           gaze backend is selected — the facetag pipeline can't
           run at all without these.  Pointer to the Config-tab
           diagnostic, which has the full per-package status +
           Install button.
        2. **L2CS extras missing** (torch / l2cs) only when the
           dropdown is on ``l2cs``.  Existing behaviour: list the
           specific missing names so the user knows what the
           Download button will fetch.

        Badge tooltip points at the diagnostic for full context.
        """
        badge = self._pp.get("gaze_method_badge")
        combo = self._pp.get("gaze_method")
        if badge is None or combo is None:
            return
        from ide4eeg.install_diagnostics import plan_install
        plan = plan_install()
        core_missing = [p for p in plan.missing if not p.optional]
        if core_missing:
            badge.setText("⚠ video stack incomplete")
            badge.setToolTip(
                "Required video packages are not installed.\n"
                "Open Config → Tool Paths → Video processing\n"
                "for status + Install missing button.")
            badge.setVisible(True)
            return
        if combo.currentText() == "l2cs":
            l2cs_missing = [p.import_name for p in plan.missing
                            if p.optional]
            if l2cs_missing:
                badge.setText(
                    "⚠ install " + " + ".join(l2cs_missing))
                badge.setToolTip(
                    "L2CS-Net (default eye-gaze backend) needs\n"
                    "these packages.  Click 'Download recent'\n"
                    "next to L2CS-Net on the Config tab.")
                badge.setVisible(True)
                return
        badge.setText("")
        badge.setToolTip("")
        badge.setVisible(False)

    def _check_gaze_deps(self, method):
        """Show an info dialog the moment the user changes the gaze
        backend dropdown — the two backends are categorically
        different (eye gaze vs head pose) and each has a "before
        you commit" caveat that the dropdown's tooltip alone can't
        force the user to read."""
        if not self.isVisible():
            return  # don't check during GUI construction
        if method == "l2cs":
            from ide4eeg.download_tools import l2cs_missing_deps
            missing = l2cs_missing_deps()
            if missing:
                self._msg_info(
                    "Missing dependency",
                    "L2CS requires " + " + ".join(missing)
                    + " (not installed).\n\n"
                    "Click 'Download recent' next to\n"
                    "'L2CS-Net (gaze detection)' on the Config\n"
                    "tab to install torch + l2cs + the Gaze360\n"
                    "weights in one shot.\n\n"
                    "Or switch to 'insightface' (no extra deps,\n"
                    "reuses the face-detection landmarks — note:\n"
                    "head-pose only, not true eye gaze).\n"
                    "Hover over the Method dropdown for details.")
        elif method == "insightface":
            self._msg_info(
                "InsightFace = head pose, not eye gaze",
                "InsightFace measures where the subject's HEAD is\n"
                "pointing, not where their EYES are looking.  A\n"
                "subject staring sideways at the screen with a\n"
                "forward-facing head is classified as 'looking at\n"
                "the camera' here.\n\n"
                "Pick this only as a fallback — when PyTorch\n"
                "isn't installed, or when L2CS-Net fails on a\n"
                "particular video.\n\n"
                "The default L2CS-Net is the actual eye-gaze\n"
                "backend.  Hover over the Method dropdown for\n"
                "the install commands.")

    def _iter_enabled_preceding_savable(self, target_gui_key):
        """Yield ``(gui_key, target_pipe)`` for enabled preceding steps
        that map to a :data:`_STEP_SAVE_MAP` pipeline, latest-first.

        Shared walk used by :meth:`_latest_fresh_snapshot_before`
        (which adds the disk + hash freshness check) and
        :meth:`_latest_enabled_preceding_savable_step` (which just
        wants the first candidate).  ``_view_step_result``'s
        preceding-step lookup applies the same filter inline; if it
        ever needs the same shape it can consume this generator too.
        """
        keys_and_grps = list(self._step_widgets)
        keys = [k for k, _ in keys_and_grps]
        if target_gui_key not in keys:
            return
        target_idx = keys.index(target_gui_key)
        for i in range(target_idx - 1, -1, -1):
            k, grp = keys_and_grps[i]
            try:
                if not grp.isChecked():
                    continue
            except AttributeError:
                pass  # non-checkable step is always on
            pipe_names = self._resolve_pipeline_step_names(k)
            target_pipe = next(
                (p for p in reversed(pipe_names)
                 if p.partition(":")[0] in _STEP_SAVE_MAP),
                None)
            if target_pipe is not None:
                yield k, target_pipe

    def _latest_fresh_snapshot_before(self, target_gui_key):
        """Find the latest upstream step's fresh on-disk snapshot, or
        ``None`` when no fresh snapshot is found (caller falls back
        to the raw input).
        """
        cfg = self._collect_config()
        step_order = effective_step_order(cfg)
        preproc_dirs = self._resolve_preproc_dirs()
        if not preproc_dirs:
            return None
        base = self._input_basename_for_snapshots()
        if not base:
            return None
        for k, target_pipe in self._iter_enabled_preceding_savable(
                target_gui_key):
            pipe_base, _, pipe_id = target_pipe.partition(":")
            _, suffix = _STEP_SAVE_MAP[pipe_base]
            file_suffix = f"{suffix}-{pipe_id}" if pipe_id else suffix
            snap_rel = os.path.join(
                "saved_steps", f"{base}-{file_suffix}-raw.fif")
            snap = self._find_in_preproc_dirs(snap_rel)
            if not snap:
                logging.info(
                    "Upstream walk: %s snapshot not on disk in any "
                    "candidate preproc dir (%s) — skip", k, snap_rel)
                continue
            expected = _compute_step_hash(target_pipe, cfg, step_order)
            stored = self._read_snapshot_hash(snap)
            if expected and stored == expected:
                return snap
            logging.info(
                "Upstream walk: %s snapshot exists but is stale "
                "(expected hash %s, file has %s) — skip",
                k, expected or "<empty>", stored or "<missing>")
        logging.info(
            "Upstream walk: no fresh upstream snapshot found for "
            "%r — review window will show the raw input.",
            target_gui_key)
        return None

    def _latest_enabled_preceding_savable_step(self, target_gui_key):
        """GUI key of the latest enabled preceding step that produces a
        ``-raw.fif`` snapshot, or ``None`` if no such step exists.
        """
        return next(
            (k for k, _ in self._iter_enabled_preceding_savable(
                target_gui_key)),
            None)

    def _input_basename_for_snapshots(self):
        """Return the snapshot base name (input filename with all
        extensions stripped — same convention as the runner uses).
        Empty string if no input is set."""
        inp = self._input_edit.text().strip()
        if not inp:
            return ""
        fname = os.path.basename(inp)
        while "." in fname:
            fname = os.path.splitext(fname)[0]
        return fname

    def _open_gaze_window(self, auto_run=True, is_reentry=False):
        """Open the Qt-native ReviewVideoArtifactsWindowQt.

        When no fresh upstream snapshot is on disk and at least one
        enabled saveable preceding step exists, the eye click drives
        a truncated pipeline up to that step (mirroring every other
        eye button's UX) and re-opens this window once it lands.
        ``is_reentry`` arms the loop guard: if the truncated run
        finished but the snapshot is still missing, fall through
        to the raw-input fallback instead of spawning another run.
        """
        pp = getattr(self, "_pp", {})
        video_path = self._video_edit.text().strip()
        if not video_path:
            self._msg_error("Error",
                "No video file set.\nSet a video path in the Paths section.")
            return
        ref_dir = self._txt(pp, "ref_dir", "")
        if auto_run and (not ref_dir or not os.path.isdir(ref_dir)):
            self._msg_error("Error",
                "Reference directory not set or not found.")
            return
        input_path = self._input_edit.text().strip()
        eeg_path = input_path
        if os.path.isdir(input_path):
            for f in sorted(os.listdir(input_path)):
                if os.path.splitext(f)[1].lower() in SIGNAL_EXTENSIONS:
                    eeg_path = os.path.join(input_path, f)
                    break

        # Substitute the latest fresh upstream snapshot (filtered /
        # ICA-cleaned / etc.) when one exists — the user expects the
        # gaze review window to show the same signal the gaze
        # detector actually saw, not the raw input.  Falls back to
        # the input file when no fresh snapshot is available
        # (haven't run preprocessing yet, or no upstream save flag
        # is set).
        upstream = self._latest_fresh_snapshot_before("gaze")
        if upstream is not None:
            # WARNING level so the substitution is visible without
            # the "Verbose console logging" toggle — needed for
            # diagnosing user-reported correlations between filter
            # state and detection behaviour.  EEG canvas only — gaze
            # detection runs on the video and is unaffected.
            logging.warning(
                "Gaze review: eeg canvas will show upstream "
                "snapshot %s (detection itself runs on video, "
                "unaffected)",
                os.path.basename(upstream))
            eeg_path = upstream
        elif not is_reentry:
            # No fresh snapshot — drive a truncated run up to the
            # latest enabled saveable preceding step so the EEG
            # canvas reflects what the gaze detector actually sees,
            # then re-enter this method to pick the snapshot up.
            target = self._latest_enabled_preceding_savable_step("gaze")
            if target and not self._polling_active:
                target_label = (self._STEP_LABELS.get(target)
                                or self._STEP_LABELS.get(
                                    target.partition(":")[0], target))
                self._run_truncated_pipeline(
                    target, target_label,
                    post_action="open_gaze_after_run")
                return
            logging.warning(
                "Gaze review: no fresh upstream snapshot and no "
                "saveable preceding step to auto-run — eeg canvas "
                "will show the raw input file %s",
                os.path.basename(eeg_path))
        else:
            logging.warning(
                "Gaze review: snapshot still missing after "
                "truncated run — eeg canvas will show the raw "
                "input file %s", os.path.basename(eeg_path))
        excl_dir = self._txt(pp, "excl_dir", "") or None
        # Build results_json path for review mode — canonical
        # location is the per-recording preproc dir, with legacy
        # video-dir fallbacks for old runs.
        results_json = None
        backend = self._cmb(pp, "gaze_method", "l2cs")
        if not auto_run:
            from ide4eeg.preprocessing.facetag.review_window import (
                find_review_json)
            # Walk every plausible preproc dir — the runner may have
            # written the JSON under a timestamped subdir or under an
            # output_path that differs from the input dir.  First hit
            # (newest-first ordering in `_resolve_preproc_dirs`) wins.
            for _preproc in self._resolve_preproc_dirs():
                results_json = find_review_json(
                    _preproc, video_path, backend)
                if results_json:
                    break
        # Early check: verify gaze backend dependencies are installed
        if backend == "l2cs":
            from ide4eeg.download_tools import l2cs_missing_deps
            missing = l2cs_missing_deps()
            if missing:
                self._msg_error(
                    "Missing dependency",
                    "L2CS gaze backend requires "
                    + " + ".join(missing) + ".\n\n"
                    "Click 'Download recent' next to\n"
                    "'L2CS-Net (gaze detection)' on the Config\n"
                    "tab, or switch to 'insightface' backend.")
                return

        te_str = self._txt(pp, "trim_end", "")
        trim_end_val = None
        if te_str:
            try:
                trim_end_val = float(te_str)
            except ValueError:
                pass
        kw = {
            "eeg_path": eeg_path,
            "ignore_before": self._num(pp, "trim_start", 0.0),
            "trim_end": trim_end_val,
            "frame_skip": int(self._num(pp, "frame_skip", 3)),
            "downscale": self._num(pp, "downscale", 1.0),
            "max_angle": self._num(pp, "max_angle", 20.0),
            "ref_use_roi": self._chk(pp, "ref_roi"),
            "face_tolerance": self._num(pp, "face_tol", 0.6),
            "min_interval": self._num(pp, "min_iv", 0.0),
            "no_face_is_artifact": self._chk(pp, "no_face", True),
            "backend_name": backend,
            "tracking_adapt_rate": self._num(pp, "adapt", 0.5),
            "position_weight": self._num(pp, "pos_w", 0.4),
            "size_weight": self._num(pp, "size_w", 0.2),
            "switch_resistance": self._num(pp, "switch_r", 0.25),
            "insightface_det_size": int(self._num(pp, "det_size", 0)),
            "auto_run": auto_run,
            "exclude_dir": excl_dir,
            "gaze_method": self._cmb(pp, "gaze_method", "l2cs"),
            "gaze_smoothing": self._num(pp, "gaze_smooth", 0.0),
            "results_json": results_json,
            # Pass the per-recording preproc dir so the review
            # window saves its _facetag_<backend>_review.json under
            # ``IDE4EEG_OUT_<base>/preprocessing/`` (matching the
            # pipeline's gaze_artifacts step) instead of writing
            # the JSON next to the video file.
            "output_dir": self._fallback_preproc_path() or "",
        }
        try:
            from ide4eeg.preprocessing.facetag.review_window_qt import (
                ReviewVideoArtifactsWindowQt)
            win = ReviewVideoArtifactsWindowQt(
                self, video_path, ref_dir, **kw)
            win.show()
            # Keep a reference so it is not garbage-collected
            if not hasattr(self, "_gaze_windows"):
                self._gaze_windows = []
            self._gaze_windows.append(win)
        except Exception as e:
            self._msg_error("Error", str(e))

    # ── Filter response plot ─────────────────────────────────────────

    def _plot_filter_response(self, filter_id=None, scale="dB"):
        """Design filters and show their frequency response in a subprocess.

        Phase 2: ``filter_id`` selects which filter block's settings
        to plot (one per filter panel).  When omitted, falls back to
        the first filter panel — keeps callers that don't yet pass
        an id (CLI smoke tests, scripts) working.

        ``scale`` is either ``"dB"`` (default — uses MNE's
        :func:`mne.viz.plot_filter` with its 3-panel time / magnitude /
        delay layout) or ``"linear"`` (custom matplotlib plot of
        ``|H|`` from ``scipy.signal.sosfreqz`` / ``freqz``).
        """
        pp = getattr(self, "_pp", {})
        # Determine sampling rate.  Prefer _cached_sfreq (set for every
        # loaded file by _read_signal_info) over _cached_signal, which
        # is only populated on the BrainTech reader path — FIF / EDF /
        # BrainVision leave it None even after a successful info load.
        rf = self._num(pp, "resample_freq", 0)
        cached_sfreq = getattr(self, "_cached_sfreq", None)
        if rf and rf > 0:
            fs = rf
        elif cached_sfreq:
            fs = cached_sfreq
        else:
            self._msg_info("No signal",
                "Load a signal or set a resample frequency\n"
                "to determine the sampling rate.")
            return
        # Resolve which filter panel's settings to plot.
        if filter_id is None and getattr(self, "_filter_widgets", None):
            filter_id = self._filter_widgets[0][0]
        if filter_id is None:
            self._msg_info("No filter panel",
                "No Filters block is configured.")
            return
        hp = self._num(pp, f"hp_{filter_id}", 0)
        lp = self._num(pp, f"lp_{filter_id}", 0)
        notch_str = self._cmb(pp, f"notch_{filter_id}", "None")
        notch = 50 if "50" in notch_str else 60 if "60" in notch_str else 0
        method_str = self._cmb(pp, f"filt_method_{filter_id}", "IIR")
        if hp <= 0 and lp <= 0 and notch <= 0:
            self._msg_info("No filters",
                "All filter cutoffs are 0 (off).\n"
                "Set a highpass, lowpass, or notch frequency.")
            return
        repo = str(Path(__file__).parent)
        hdr = (f"import sys; sys.path.insert(0, {repo!r})\n"
               "import matplotlib; matplotlib.use('QtAgg')\n"
               "import mne; import matplotlib.pyplot as plt\n"
               f"fs = {fs}\n")
        linear = (scale == "linear")
        if "FIR" in method_str:
            l = hp if hp > 0 else None
            h = lp if lp > 0 else None
            # FIR notch: build a narrow bandstop FIR (l_freq > h_freq
            # tells `mne.filter.create_filter` to design a stopband).
            # Width is 2 Hz total (notch ± 1 Hz) — chosen for plot
            # readability rather than to mirror the pipeline's
            # `notch_filter` design exactly, which can use a much
            # narrower transition.
            if linear:
                script = hdr + (
                    "import numpy as np, scipy.signal as ss\n"
                    f"l_freq = {l!r}; h_freq = {h!r}; notch = {notch}\n"
                    "def _show_linear(fir, title):\n"
                    "    w, H = ss.freqz(fir, worN=4096, fs=fs)\n"
                    "    fig, ax = plt.subplots()\n"
                    "    ax.plot(w, np.abs(H))\n"
                    "    ax.set_xlabel('Frequency [Hz]')\n"
                    "    ax.set_ylabel('|H| (linear)')\n"
                    "    ax.set_title(title)\n"
                    "    ax.grid(True, alpha=0.3)\n"
                    "if l_freq or h_freq:\n"
                    "    fir = mne.filter.create_filter(None, fs, l_freq, h_freq,\n"
                    "        method='fir', fir_design='firwin', phase='zero', verbose=False)\n"
                    "    _show_linear(fir,\n"
                    "        f'FIR: HP={l_freq or \"off\"}, LP={h_freq or \"off\"} (fs={fs})')\n"
                    "if notch > 0:\n"
                    "    fir_n = mne.filter.create_filter(None, fs,\n"
                    "        l_freq=notch + 1.0, h_freq=notch - 1.0,\n"
                    "        l_trans_bandwidth=0.5, h_trans_bandwidth=0.5,\n"
                    "        method='fir', fir_design='firwin', phase='zero', verbose=False)\n"
                    "    _show_linear(fir_n, f'FIR notch: {notch} Hz (fs={fs})')\n"
                    "plt.show()\n")
            else:
                script = hdr + (
                    f"l_freq = {l!r}; h_freq = {h!r}; notch = {notch}\n"
                    "if l_freq or h_freq:\n"
                    "    fir = mne.filter.create_filter(None, fs, l_freq, h_freq,\n"
                    "        method='fir', fir_design='firwin', phase='zero', verbose=False)\n"
                    "    mne.viz.plot_filter(fir, fs, show=False,\n"
                    "        title=f'FIR: HP={l_freq or \"off\"}, LP={h_freq or \"off\"} (fs={fs})').show()\n"
                    "if notch > 0:\n"
                    "    fir_n = mne.filter.create_filter(None, fs,\n"
                    "        l_freq=notch + 1.0, h_freq=notch - 1.0,\n"
                    "        l_trans_bandwidth=0.5, h_trans_bandwidth=0.5,\n"
                    "        method='fir', fir_design='firwin', phase='zero', verbose=False)\n"
                    "    mne.viz.plot_filter(fir_n, fs, show=False,\n"
                    "        title=f'FIR notch: {notch} Hz (fs={fs})').show()\n"
                    "plt.show()\n")
        else:
            if linear:
                script = hdr + (
                    "import numpy as np, scipy.signal as ss\n"
                    "from ide4eeg.preprocessing.channels_and_signal import design_iir_filter\n"
                    f"for ft, fq in [('highpass',{hp}),('lowpass',{lp}),('notch',{notch})]:\n"
                    "    if fq <= 0: continue\n"
                    "    sos, info = design_iir_filter(ft, fq, fs)\n"
                    "    if sos is None: continue\n"
                    "    w, H = ss.sosfreqz(sos, worN=4096, fs=fs)\n"
                    "    fig, ax = plt.subplots()\n"
                    "    ax.plot(w, np.abs(H))\n"
                    "    ax.set_xlabel('Frequency [Hz]')\n"
                    "    ax.set_ylabel('|H| (linear)')\n"
                    "    ax.set_title(f'IIR {ft}: {fq} Hz (order {info[\"order\"]}, fs={fs})')\n"
                    "    ax.grid(True, alpha=0.3)\n"
                    "plt.show()\n")
            else:
                script = hdr + (
                    "from ide4eeg.preprocessing.channels_and_signal import design_iir_filter\n"
                    f"for ft, fq in [('highpass',{hp}),('lowpass',{lp}),('notch',{notch})]:\n"
                    "    if fq <= 0: continue\n"
                    "    sos, info = design_iir_filter(ft, fq, fs)\n"
                    "    if sos is None: continue\n"
                    "    mne.viz.plot_filter(dict(sos=sos), fs, show=False,\n"
                    "        title=f'IIR {ft}: {fq} Hz (order {info[\"order\"]}, fs={fs})').show()\n"
                    "plt.show()\n")
        try:
            subprocess.Popen([sys.executable, "-c", script])
        except Exception as e:
            self._msg_error("Error", str(e))

    # ── Standalone analyses ──────────────────────────────────────────

    def _find_mp_book(self):
        """Find an MP book (.db) on disk in output directories."""
        books = self._find_all_mp_books()
        return books[0] if books else None

    def _cached_eeg_channel_count(self):
        """Return EEG channel count from the cached file scan, or 0."""
        names = getattr(self, "_cached_ch_names", None)
        types = getattr(self, "_cached_ch_types", None)
        if names and types and len(names) == len(types):
            return sum(1 for t in types if t == "eeg")
        return 0

    def _recent_mp_book_symbol(self):
        """Return a compact symbol describing the on-disk MP book for
        the current input, or "" when no book is found / readable.

        Forms returned:
          "smp" / "mmp1" / "mmp3"  — book covers every EEG channel
          "Cz, C3"                 — SMP book over a small subset
          "mmp1: Cz, C3"           — MMP book over a small subset
          "{algo}, {n} chs"        — book with a larger subset
        """
        if not self._input_edit.text().strip():
            return ""
        book = self._find_mp_book()
        if not (book and os.path.isfile(book)):
            return ""
        import sqlite3
        algo = ""
        chs = []
        try:
            with sqlite3.connect(book) as c:
                row = c.execute(
                    "SELECT value FROM metadata "
                    "WHERE param='algorithm'").fetchone()
                algo = (row[0] if row else "").strip().lower()
                row = c.execute(
                    "SELECT value FROM metadata "
                    "WHERE param='channel_names'").fetchone()
                if row and row[0]:
                    chs = [s.strip() for s in row[0].split(",") if s.strip()]
        except sqlite3.Error:
            return ""
        n = len(chs)
        n_eeg = self._cached_eeg_channel_count()
        is_smp = algo.startswith("smp")
        if n == 0 or (n_eeg and n == n_eeg):
            return algo or "book"
        if n <= 5:
            names = ", ".join(chs)
            return names if is_smp else f"{algo}: {names}"
        return f"{algo}, {n} chs"

    def _find_all_mp_books(self):
        """Return all .db book paths found in output directories (cached 5s)."""
        import time as _time
        now = _time.monotonic()
        if hasattr(self, "_mp_books_cache_time") and now - self._mp_books_cache_time < 5.0:
            return self._mp_books_cache
        results, roots = [], set()
        inp = self._input_edit.text().strip()
        base = os.path.splitext(os.path.basename(inp))[0] if inp else ""
        prefix = f"book_{base}_" if base else "book_"
        for p in [self._preproc_edit.text().strip(), self._output_edit.text().strip()]:
            if p and os.path.isdir(p): roots.add(p)
        if inp:
            d = os.path.dirname(inp) if os.path.isfile(inp) else inp
            if d and os.path.isdir(d): roots.add(d)
        for root in list(roots):
            for dp, dn, _ in os.walk(root):
                if dp[len(root):].count(os.sep) > 3: dn.clear(); continue
                mp = os.path.join(dp, "mp_decomposition")
                if os.path.isdir(mp):
                    try: results.extend(
                        os.path.join(mp, f) for f in sorted(os.listdir(mp))
                        if f.endswith(".db") and f.startswith(prefix))
                    except OSError: pass
        seen, unique = set(), []
        for p in results:
            rp = os.path.realpath(p)
            if rp not in seen: seen.add(rp); unique.append(p)
        self._mp_books_cache = unique; self._mp_books_cache_time = now
        return unique

    def _find_mmp_books(self, mmp1_only=False):
        """Return only MMP books from all found books.

        Parameters
        ----------
        mmp1_only : bool
            If True, return only MMP1 books (dipole fitting
            requires constant-phase multivariate decomposition).
            If False, return both MMP1 and MMP3.
        """
        import sqlite3
        accept = {"mmp1"} if mmp1_only else mp_multichannel_algorithm_names()
        mmp = []
        for bp in self._find_all_mp_books():
            try:
                with sqlite3.connect(bp) as c:
                    r = c.execute(
                        "SELECT value FROM metadata "
                        "WHERE param='algorithm'").fetchone()
                    if r and r[0].lower() in accept:
                        mmp.append(bp)
            except Exception:
                pass
        return mmp

    def _mp_pipeline_info(self):
        """Return a summary of the current MP decomposition settings."""
        pp = getattr(self, "_pp", {})
        mp_grp = pp.get("_mp_grp")
        if not mp_grp or not mp_grp.isChecked():
            return ""
        algo = parse_mp_algorithm_label(self._cmb(pp, "mp_algo", "smp"))
        iters = self._txt(pp, "mp_iter", "0")
        energy = self._txt(pp, "mp_energy", "99")
        chs = self._mp_pipeline_channels()
        n = len(chs)
        if n <= 5:
            ch_str = ", ".join(chs) if chs else "none"
        else:
            ch_str = f"{n} channels"
        return (f"{algo.upper()}, {ch_str}, "
                f"max iter. {iters}, energy {energy}%")

    def _mp_pipeline_channels(self):
        """Return the channel list that the MP decomposition will produce.

        This is read from the MP panel's channel selection widget.
        When no channels are explicitly selected, falls back to all
        cached EEG channel names (which is what empi defaults to
        for both SMP and MMP when ``matching_pursuit.channels`` is
        empty).  Used by :class:`BookChannelPanel` to populate the
        channel combo when ``(from pipeline)`` is selected, so
        downstream consumers (Profiles, etc.) can pick a channel from
        the forthcoming book.
        """
        pp = getattr(self, "_pp", {})
        ch_panel = pp.get("mp_channels")
        if ch_panel:
            chs = ch_panel.selected_channels()
            if chs:
                return chs
        cached_names = getattr(self, "_cached_ch_names", None)
        cached_types = getattr(self, "_cached_ch_types", None)
        if cached_names and cached_types:
            return [n for n, t in zip(cached_names, cached_types)
                    if t == "eeg"]
        return list(cached_names or [])

    def _mp_segment_duration(self):
        """Return the MP segment duration in seconds, or 0 if unknown."""
        pp = getattr(self, "_pp", {})
        mode = self._mode
        if mode == "epochs":
            t0 = self._num(pp, "ep_start", -0.3)
            t1 = self._num(pp, "ep_stop", 0.7)
            return abs(t1 - t0)
        else:
            whole = self._chk(pp, "rest_whole")
            wl = self._num(pp, "rest_window", 20)
            if whole or wl <= 0:
                return getattr(self, "_cached_duration", 0) or 0
            return wl

    def _update_prof_epoch_hint(self, *_a):
        """Update the EEG profiles bin-width hint label.

        Bin width is always equal to the MP segment length (from book
        metadata).  No user-configurable interval anymore.
        """
        an = getattr(self, "_an", {})
        hint = an.get("prof_epoch_hint")
        if not hint:
            return
        dur = self._mp_segment_duration()
        if dur > 0:
            hint.setText(f"Bin width = {dur:g} s (MP segment length)")
        else:
            hint.setText("Bin width = MP segment length (run MP first)")

    def _refresh_book_panels(self):
        """Re-scan books and update all BookChannelPanel instances."""
        all_books = self._find_all_mp_books()
        pp = getattr(self, "_pp", {})
        mp_grp = pp.get("_mp_grp")
        mp_on = mp_grp.isChecked() if mp_grp else False
        algo = parse_mp_algorithm_label(
            self._cmb(pp, "mp_algo", "smp")) if mp_on else "smp"
        mmp1_books = mmp_books = None
        for panel in getattr(self, "_book_panels", []):
            if panel._mmp1_only:
                if mmp1_books is None:
                    mmp1_books = self._find_mmp_books(mmp1_only=True)
                panel.refresh(mmp1_books, mp_enabled=mp_on and algo == "mmp1")
            elif panel._mmp_only:
                if mmp_books is None:
                    mmp_books = self._find_mmp_books(mmp1_only=False)
                panel.refresh(mmp_books, mp_enabled=mp_on and algo in ("mmp1", "mmp3"))
            else:
                panel.refresh(all_books, mp_enabled=mp_on)
        # dip_channels is populated from the book, not from signal channels
        self._on_dip_book_changed()
        # Refresh the MP panel header line so it flips between
        # "book symbol" (when a .db is on disk for the current input)
        # and "auto-decomp params" (when there's no book yet).
        fn = getattr(self, "_update_mp_header_info", None)
        if fn:
            fn()
        # Re-evaluate warnings now that panels are populated
        fn = getattr(self, "_update_analysis_warnings", None)
        if fn:
            fn()

    def _on_dip_book_changed(self, _index=None):
        """Repopulate the dip_channels panel from the selected MMP book.

        When a book is selected in the dipole book panel, restrict the
        channel list to exactly the EEG channels that were decomposed.
        Non-EEG channels (EOG, EMG, ECG, etc.) are excluded — dipole
        fitting only makes sense for EEG.  Falls back to all cached
        EEG channels when no book is available.
        """
        from ide4eeg.analysis.mp_analysis import read_book_channel_names
        bp = self._an.get("dip_book_panel")
        panel = self._an.get("dip_channels")
        if not bp or not panel:
            return
        book = bp.selected_book()
        if book and os.path.isfile(book):
            ch_names = read_book_channel_names(book)
        else:
            ch_names = []
        if not ch_names:
            ch_names = list(getattr(self, "_cached_ch_names", None) or [])
        if not ch_names:
            return
        # Build type map and keep only EEG channels
        cached_types = getattr(self, "_cached_ch_types", None)
        if cached_types:
            cached_names = list(getattr(self, "_cached_ch_names", []))
            ct_map = dict(zip(cached_names, cached_types))
        else:
            ct_map = {}
        eeg_names = [c for c in ch_names
                     if ct_map.get(c, "eeg") == "eeg"]
        if not eeg_names:
            eeg_names = ch_names  # fallback: show all if no types known
        eeg_ct = {c: "eeg" for c in eeg_names}
        panel.populate(eeg_names, ch_types=eeg_ct)


    # ── Analysis Run buttons ─────────────────────────────────────────

    def _view_profiles_in_svarog(self):
        """Eye-button on EEG Profiles: run, then open Svarog automatically.

        Equivalent to ticking "Auto open results in SVAROG" + clicking
        Run, but as a single click — and idempotent against the user
        having the panel checkbox off (auto-enables it first).  The
        Svarog open in ``_on_pipeline_finished`` is gated by the
        ``_force_profile_svarog_open`` one-shot flag so the user's
        explicit Auto-open preference is preserved across runs.
        """
        prof_grp = self._an.get("_prof_grp")
        if prof_grp is None:
            return
        if not prof_grp.isChecked():
            prof_grp.setChecked(True)
        self._force_profile_svarog_open = True
        self._run_analysis_from_button("prepare_eeg_profiles", prof_grp)

    def _run_analysis_from_button(self, analysis_key, grp_widget):
        """Run a single analysis via the full pipeline, showing progress on Run tab."""
        if grp_widget and grp_widget._run_btn:
            grp_widget._run_btn.setEnabled(False)
            grp_widget.setStatusText("running...")
        self._pending_analysis_grp = grp_widget
        self._pending_analysis_key = analysis_key
        self._run_pipeline_for_analysis(analysis_key, grp_widget)

    # ── Styled message dialogs ─────────────────────────────────────

    def _styled_dialog(self, title, heading, body, icon_sp, buttons):
        """Create and show a styled message dialog.

        Parameters
        ----------
        title : str       Window title.
        heading : str     Bold heading (HTML ok).
        body : str        Body text (HTML ok, word-wrapped).
        icon_sp : StandardPixmap   Icon enum value.
        buttons : list of (label, role) where role is 'accept'|'reject'.

        Returns the role string of the clicked button, or ``"reject"``
        if the dialog is closed.  For backward compatibility, returns
        True/False when all roles are ``"accept"``/``"reject"``.
        """
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.setMinimumWidth(400)
        lay = QVBoxLayout(dlg)
        icon_label = QLabel()
        icon_label.setPixmap(
            self.style().standardPixmap(icon_sp).scaled(40, 40))
        header = QHBoxLayout()
        header.addWidget(icon_label)
        header.addWidget(QLabel(f"<h3>{heading}</h3>"), 1)
        lay.addLayout(header)
        if body:
            lbl = QLabel(body)
            lbl.setWordWrap(True)
            lay.addWidget(lbl)
        lay.addSpacing(8)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        _result = ["reject"]
        first = True
        for label, role in buttons:
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, r=role: (
                _result.__setitem__(0, r), dlg.accept()))
            if first:
                b.setDefault(True); first = False
            btn_row.addWidget(b)
        lay.addLayout(btn_row)
        dlg.exec()
        r = _result[0]
        # Backward compat: if only accept/reject roles, return bool
        roles = {role for _, role in buttons}
        if roles <= {"accept", "reject"}:
            return r == "accept"
        return r

    def _msg_info(self, title, text):
        """Styled informational dialog (OK button)."""
        self._styled_dialog(
            title, title, text,
            self.style().StandardPixmap.SP_MessageBoxInformation,
            [("OK", "accept")])

    def _build_video_stack_section(self, parent_layout):
        """Build the Video stack subsection of Tool Paths.

        Contains three sibling tools that together power the
        facetag pipeline: mpv (Svarog video backend), the core
        Python video packages, and L2CS-Net (default eye-gaze
        backend).  Section header carries a single
        [Install all video tools] button that bulk-installs
        everything missing across all three rows.
        """
        # Section header: title + bulk install button.  Visual
        # break from the EEG tools above; the Tool Paths
        # QGroupBox is shared so we don't nest a second QGroupBox
        # for the section.
        header = QHBoxLayout()
        header.setContentsMargins(0, 12, 0, 4)
        title = QLabel("<b>Video stack</b>")
        title.setToolTip(
            "Tools needed for facetag: face detection, eye-gaze\n"
            "tracking, and EEG-synchronised video review.\n"
            "Components install separately; the bulk button to\n"
            "the right runs all the missing ones in sequence.")
        header.addWidget(title)
        # Inline status text shown when nothing is missing — replaces
        # the redundant "✓ All video tools installed" button so the
        # row doesn't display a clickable-looking control in the
        # nothing-to-do state.
        self._video_status_label = QLabel("")
        self._video_status_label.setVisible(False)
        header.addWidget(self._video_status_label)
        header.addStretch()
        self._video_install_all_btn = QPushButton(
            "Install all video tools")
        self._video_install_all_btn.setToolTip(
            "Install whatever's missing across mpv, the Python\n"
            "core video stack, and L2CS-Net (in that order).\n"
            "Each component reuses its existing per-row install\n"
            "flow — same prompts, same streaming pip log.")
        self._video_install_all_btn.clicked.connect(
            self._install_all_video_tools)
        header.addWidget(self._video_install_all_btn)
        self._video_uninstall_all_btn = QPushButton(
            "Uninstall video tools")
        self._video_uninstall_all_btn.setToolTip(
            "Remove the Python video stack (cv2, av, imageio,\n"
            "insightface, onnxruntime, torch, torchvision, l2cs,\n"
            "gdown), the L2CS-Net Gaze360 weights, and the\n"
            "InsightFace model cache.  Frees up to ~700 MB.\n"
            "mpv is left alone since Svarog uses it independently.")
        self._video_uninstall_all_btn.clicked.connect(
            self._uninstall_all_video_tools)
        header.addWidget(self._video_uninstall_all_btn)
        parent_layout.addLayout(header)

        # Row 1: mpv (Svarog video backend).
        self._build_mpv_row(parent_layout)

        # Row 2: Python core packages (5).  Builds the per-package
        # status rows + section-level [Install missing] button.
        self._build_video_stack_panel(parent_layout)

        # Row 3: L2CS-Net.
        self._build_l2cs_row(parent_layout)

        # Refresh the bulk button's enabled state based on the
        # current install state.
        self._refresh_video_install_all_btn()

    def _build_l2cs_row(self, parent_layout):
        """L2CS-Net row: title + Install button + on-disk paths.

        No Uninstall button — the only per-row uninstall in the
        whole panel was awkward.  Users who need to reclaim disk
        can `pip uninstall torch torchvision l2cs` and delete the
        weights file directly.
        """
        l2cs_row = QHBoxLayout()
        l2cs_title = QLabel(
            "<b>L2CS-Net</b> "
            "<span style='color:gray'>"
            "(default eye-gaze backend)</span>")
        l2cs_title.setToolTip(
            "Per-eye yaw/pitch gaze estimation — PyTorch +\n"
            "torchvision, the l2cs Python package, and the\n"
            "Gaze360 weights checkpoint (~96 MB, MIT-mirrored\n"
            "from Ahmednull/L2CS-Net).  Total install ~500 MB on\n"
            "macOS / Linux-CPU, up to ~2 GB on Linux with CUDA\n"
            "wheels.  Without L2CS, the gaze panel falls back to\n"
            "InsightFace head-pose, which measures only where the\n"
            "head is pointing — not where the eyes look.")
        l2cs_row.addWidget(l2cs_title)
        # Inline status (visible only when fully installed) — keeps
        # the row symmetrical with mpv / Python core and avoids a
        # disabled "✓ installed" button in the nothing-to-do state.
        self._l2cs_status_label = QLabel("")
        self._l2cs_status_label.setVisible(False)
        l2cs_row.addWidget(self._l2cs_status_label)
        l2cs_row.addStretch()
        self._dl_l2cs_btn = QPushButton()
        self._dl_l2cs_btn.clicked.connect(self._download_l2cs_all)
        l2cs_row.addWidget(self._dl_l2cs_btn)
        parent_layout.addLayout(l2cs_row)
        # Sub-row: install footprint paths.
        self._l2cs_path_info = QLabel("")
        self._l2cs_path_info.setStyleSheet(
            "color: gray; font-size: 10pt;")
        self._l2cs_path_info.setWordWrap(True)
        self._l2cs_path_info.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        parent_layout.addWidget(self._l2cs_path_info)
        self._refresh_l2cs_button()

    def _build_video_stack_panel(self, parent_layout):
        """Build the per-package status rows for the core Python
        video stack (cv2 / av / imageio / insightface /
        onnxruntime), plus an [Install missing] button.

        L2CS-Net + PyTorch are owned by :meth:`_build_l2cs_row`
        — listing them here too would be duplicate UI.
        """
        from ide4eeg.install_diagnostics import VIDEO_STACK
        core_pkgs = [p for p in VIDEO_STACK if not p.optional]
        # Inline header.  In the all-installed (collapsed) case
        # this shows: title + ✓ comma-list + size + (no install
        # button).  When anything is missing or blocked, the
        # detail container below expands to show per-package
        # status, the summary text switches to "N missing" /
        # "N blocked", and [Install missing] appears on the right.
        head = QHBoxLayout()
        head_title = QLabel("<b>Python core</b>")
        head_title.setToolTip(
            "Live status of the core Python packages facetag\n"
            "imports.  Collapses to a single line when all\n"
            "installed; expands to per-package detail with\n"
            "platform-specific blocker text when something\n"
            "needs attention.")
        head.addWidget(head_title)
        self._video_stack_summary = QLabel("")
        self._video_stack_summary.setStyleSheet(
            "QLabel { color: gray; }")
        self._video_stack_summary.setWordWrap(False)
        head.addWidget(self._video_stack_summary, 1)
        self._video_install_btn = QPushButton("Install missing")
        self._video_install_btn.clicked.connect(
            self._install_video_stack_from_panel)
        self._video_install_btn.setVisible(False)
        head.addWidget(self._video_install_btn)
        parent_layout.addLayout(head)

        # Per-package detail rows live in a container that gets
        # hidden in the all-installed case (collapsed view).  When
        # any package is missing or platform-blocked, the
        # container is shown so the user can see exactly which.
        self._video_stack_details = QWidget()
        gl = QVBoxLayout(self._video_stack_details)
        gl.setContentsMargins(16, 0, 0, 0)
        gl.setSpacing(2)
        self._video_stack_rows: dict[str, dict] = {}
        for pkg in core_pkgs:
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            marker = QLabel("[…]")
            marker.setFixedWidth(34)
            marker.setStyleSheet(
                "QLabel { font-family: monospace; }")
            desc = QLabel(pkg.purpose)
            desc.setWordWrap(False)
            row.addWidget(marker)
            row.addWidget(desc, 1)
            gl.addLayout(row)
            blocker = QLabel("")
            blocker.setStyleSheet(
                "QLabel { color: #b3603a; padding-left: 38px; "
                "font-size: 10pt; }")
            blocker.setWordWrap(True)
            blocker.setVisible(False)
            gl.addWidget(blocker)
            self._video_stack_rows[pkg.import_name] = {
                "marker": marker,
                "desc": desc,
                "blocker": blocker,
            }
        parent_layout.addWidget(self._video_stack_details)
        self._refresh_video_stack_panel()

    def _refresh_video_stack_panel(self):
        """Re-run plan_install and update the per-package rows +
        action button visibility.  Filters to core (non-optional)
        packages so the panel + summary + button only reflect
        what the panel actually displays.  L2CS extras are owned
        by the L2CS row, not this panel."""
        if not hasattr(self, "_video_stack_rows"):
            return
        from ide4eeg.install_diagnostics import (
            VIDEO_STACK, plan_install)
        plan = plan_install()
        core_pkgs = [p for p in VIDEO_STACK if not p.optional]
        have_names = {p.import_name for p in plan.have
                      if not p.optional}
        missing_names = {p.import_name for p in plan.missing
                         if not p.optional}
        blocked_by_name = {p.import_name: i
                           for p, i in plan.blocked
                           if not p.optional}
        for pkg in core_pkgs:
            row = self._video_stack_rows[pkg.import_name]
            marker, blocker = row["marker"], row["blocker"]
            if pkg.import_name in have_names:
                marker.setText("[ok]")
                marker.setStyleSheet(
                    f"QLabel {{ font-family: monospace; "
                    f"color: {_OK_COLOR}; }}")
                blocker.setVisible(False)
            elif pkg.import_name in blocked_by_name:
                issue = blocked_by_name[pkg.import_name]
                marker.setText("[!!]")
                marker.setStyleSheet(
                    f"QLabel {{ font-family: monospace; "
                    f"color: {_ERR_COLOR}; }}")
                blocker.setText(issue.blocker)
                blocker.setVisible(True)
            elif pkg.import_name in missing_names:
                marker.setText("[--]")
                marker.setStyleSheet(
                    f"QLabel {{ font-family: monospace; "
                    f"color: {_MISSING_COLOR}; }}")
                blocker.setVisible(False)
            else:
                marker.setText("[?]")
                marker.setStyleSheet(
                    "QLabel { font-family: monospace; }")
                blocker.setVisible(False)
        n_missing = len(missing_names)
        n_blocked = len(blocked_by_name)
        all_clear = not missing_names and not blocked_by_name
        # Collapse / expand the per-package detail rows.  All-clear
        # is one line in the header; anything else expands the
        # detail container so the user can see exactly what's wrong.
        self._video_stack_details.setVisible(not all_clear)
        self._video_install_btn.setVisible(bool(missing_names))
        if all_clear:
            # Compact summary: green ✓ + gray comma-list + gray size.
            # Mixed colors so the indicator stands out but the
            # package list / size match the surrounding paths.
            short = [p.purpose.split(" — ")[0] for p in core_pkgs]
            sz = self._core_video_stack_size_bytes()
            sz_str = (f" — ~{self._fmt_size(sz)}"
                      if sz else "")
            self._video_stack_summary.setStyleSheet("")
            self._video_stack_summary.setText(
                f"<span style='color:{_OK_COLOR}'>✓</span>"
                " <span style='color:gray'>"
                + ", ".join(short) + sz_str + "</span>")
        elif missing_names and blocked_by_name:
            self._video_stack_summary.setStyleSheet(
                f"QLabel {{ color: {_MISSING_COLOR}; }}")
            self._video_stack_summary.setText(
                f"{n_missing} missing, {n_blocked} blocked")
        elif missing_names:
            self._video_stack_summary.setStyleSheet(
                f"QLabel {{ color: {_MISSING_COLOR}; }}")
            self._video_stack_summary.setText(
                f"{n_missing} package(s) missing")
        else:
            self._video_stack_summary.setStyleSheet(
                f"QLabel {{ color: {_ERR_COLOR}; }}")
            self._video_stack_summary.setText(
                f"{n_blocked} package(s) platform-blocked")

    def _install_video_stack_from_panel(self):
        """Install button handler for the persistent panel.

        Restricts the install plan to **core** packages — L2CS
        extras (torch + l2cs) have their own dedicated installer
        in the L2CS row above (which also handles the Gaze360
        weights file in one shot).
        """
        from ide4eeg.install_diagnostics import (
            ActionPlan, plan_install)
        plan = plan_install()
        core_plan = ActionPlan(
            have=tuple(p for p in plan.have if not p.optional),
            missing=tuple(p for p in plan.missing if not p.optional),
            blocked=tuple((p, i) for p, i in plan.blocked
                          if not p.optional),
        )
        self._install_video_stack(core_plan)

    @staticmethod
    def _core_video_stack_size_bytes():
        """Approximate disk footprint of the five core video pip
        packages (cv2 / av / imageio / insightface / onnxruntime).

        Walks only those specific dirs under the active venv's
        site-packages — fast (a few k files each) and avoids
        attributing transitive deps to the "video stack" line.
        Returns 0 when nothing's importable yet.
        """
        import sysconfig
        sp = sysconfig.get_paths().get("purelib", "")
        if not sp or not os.path.isdir(sp):
            return 0
        # Distribution-name -> site-packages directory mapping.
        # The pip distribution name and the import name diverge for
        # opencv-contrib-python-headless (-> cv2) and the av wheel
        # (which ships its dir as "av"); be explicit.
        candidates = ("cv2", "av", "imageio", "insightface",
                      "onnxruntime")
        total = 0
        for name in candidates:
            d = os.path.join(sp, name)
            if not os.path.isdir(d):
                continue
            for root, _, files in os.walk(d):
                for f in files:
                    try:
                        total += os.path.getsize(
                            os.path.join(root, f))
                    except OSError:
                        pass
        return total

    def _refresh_video_install_all_btn(self):
        """Enabled-state refresh for both bulk buttons in the
        Video stack header.

        Install button: enabled when any video tool has work to do.
        Uninstall button: enabled when any pip-removable component
        is detected installed (mpv excluded — Svarog owns it).
        """
        if not hasattr(self, "_video_install_all_btn"):
            return
        from ide4eeg.download_tools import (
            INSIGHTFACE_ROOT,
            find_installed_mpv,
            is_l2cs_stack_installed,
        )
        from ide4eeg.install_diagnostics import plan_install
        plan = plan_install()
        core_missing = any(
            not p.optional for p in plan.missing)
        core_present = any(
            not p.optional for p in plan.have)
        torch_ok, pkg_ok, weights_ok = is_l2cs_stack_installed()
        l2cs_missing = not (torch_ok and pkg_ok and weights_ok)
        l2cs_present = torch_ok or pkg_ok or weights_ok
        mpv_missing = find_installed_mpv() is None
        if_present = (INSIGHTFACE_ROOT / "models").exists()
        any_missing = core_missing or l2cs_missing or mpv_missing
        any_present = core_present or l2cs_present or if_present
        # Hide the Install button entirely when nothing is missing —
        # show plain inline status instead so the row doesn't display
        # a button-shaped control with no real action.
        self._video_install_all_btn.setVisible(any_missing)
        self._video_install_all_btn.setText("Install all video tools")
        self._video_status_label.setVisible(not any_missing)
        if not any_missing:
            self._video_status_label.setText(
                f"<span style='color:{_OK_COLOR}'>✓</span>"
                " <span style='color:gray'>all installed</span>")
        self._video_uninstall_all_btn.setEnabled(any_present)

    def _install_all_video_tools(self):
        """Bulk-install everything missing across the video stack.

        Sequence:
          1. mpv (if missing) — handles brew consent on macOS.
          2. Python core packages (if any missing) — pip subprocess
             via VideoStackInstaller.
          3. L2CS-Net bundle (if any of torch/l2cs/weights missing)
             — reuses the existing _download_l2cs_all flow.

        Each step reuses its existing per-row entry point, so the
        UX (confirm dialogs, brew consent, streaming logs, restart
        prompts) stays consistent with the per-row buttons.
        """
        from ide4eeg.download_tools import (
            find_installed_mpv, is_l2cs_stack_installed)
        from ide4eeg.install_diagnostics import plan_install
        # 1. mpv first (smallest, fastest, no Python restart needed).
        if find_installed_mpv() is None:
            self._download_mpv_only()
        # 2. Python core.  Reuse the panel-install path which
        # already filters to non-optional and uses the streaming
        # pip dialog.
        plan = plan_install()
        if any(not p.optional for p in plan.missing):
            self._install_video_stack_from_panel()
        # 3. L2CS bundle (largest, last so an early failure doesn't
        # block the smaller installs).
        torch_ok, pkg_ok, weights_ok = is_l2cs_stack_installed()
        if not (torch_ok and pkg_ok and weights_ok):
            self._download_l2cs_all()

    def _uninstall_all_video_tools(self):
        """Bulk-remove the video stack — pip packages + weights +
        InsightFace cache.  mpv is preserved (Svarog uses it).

        Confirms with a measured-size dialog, then runs pip uninstall
        in a worker thread with progress streamed to a monospace log
        dialog (same pattern as _install_video_stack).
        """
        from ide4eeg.download_tools import (
            INSIGHTFACE_ROOT, canonical_l2cs_weights_path,
            is_l2cs_stack_installed)
        from ide4eeg.install_runner import VideoStackUninstaller

        # Estimate disk to be freed.  Three components:
        #   1. core video packages (cv2/av/imageio/insightface/onnxruntime)
        #   2. L2CS extras (torch + torchvision + l2cs + weights)
        #   3. InsightFace model cache
        core_bytes = self._core_video_stack_size_bytes()
        import sysconfig
        sp = sysconfig.get_paths().get("purelib", "")
        l2cs_bytes = (
            self._l2cs_install_size_bytes(sp) if sp else 0)
        weights = canonical_l2cs_weights_path()
        if os.path.isfile(weights):
            try:
                l2cs_bytes += os.path.getsize(weights)
            except OSError:
                pass
        if_models = INSIGHTFACE_ROOT / "models"
        if_bytes = 0
        if if_models.exists():
            for root, _, files in os.walk(if_models):
                for f in files:
                    try:
                        if_bytes += os.path.getsize(
                            os.path.join(root, f))
                    except OSError:
                        pass
        total_bytes = core_bytes + l2cs_bytes + if_bytes
        if total_bytes == 0:
            self._msg_info(
                "Nothing to uninstall",
                "No video-stack components are installed.")
            return

        plan_lines = []
        if core_bytes:
            plan_lines.append(
                f"  • Python core packages "
                f"(~{self._fmt_size(core_bytes)})")
        if l2cs_bytes:
            plan_lines.append(
                f"  • L2CS-Net bundle (PyTorch + l2cs + Gaze360 "
                f"weights, ~{self._fmt_size(l2cs_bytes)})")
        if if_bytes:
            plan_lines.append(
                f"  • InsightFace model cache "
                f"(~{self._fmt_size(if_bytes)})")
        if not self._msg_confirm(
                "Uninstall video tools?",
                "This will remove:\n" + "\n".join(plan_lines)
                + f"\n\nTotal disk freed: ~{self._fmt_size(total_bytes)}.\n"
                "mpv is preserved (Svarog uses it independently).\n\n"
                "Continue?"):
            return

        # Streaming-log dialog (same pattern as _install_video_stack).
        from ide4eeg.install_runner import CancellationToken
        cancel_token = CancellationToken()
        log_dlg = QDialog(self)
        log_dlg.setWindowTitle("Uninstalling video tools")
        log_dlg.setMinimumSize(640, 360)
        ll = QVBoxLayout(log_dlg)
        status = QLabel("Starting pip uninstall...")
        ll.addWidget(status)
        log_view = QPlainTextEdit()
        log_view.setReadOnly(True)
        log_view.setStyleSheet(
            "QPlainTextEdit { font-family: monospace; }")
        ll.addWidget(log_view, 1)
        close_btn, mark_finished = self._make_cancel_close_button(
            log_dlg, cancel_token, status,
            confirm_title="Cancel uninstall?")
        ll.addWidget(close_btn)
        log_dlg.setModal(True)

        import queue
        line_queue: "queue.Queue[str]" = queue.Queue()
        result_holder: dict = {}

        def log_callback(line: str) -> None:
            line_queue.put(line)

        def worker():
            try:
                u = VideoStackUninstaller(
                    log_callback=log_callback,
                    cancel=cancel_token)
                result_holder["summary"] = u.uninstall_all()
            except Exception as exc:
                result_holder["error"] = (
                    f"{type(exc).__name__}: {exc}")

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        timer = QTimer(log_dlg)
        timer.setInterval(50)

        def drain():
            while True:
                try:
                    line = line_queue.get_nowait()
                except queue.Empty:
                    break
                log_view.appendPlainText(line)
            if not thread.is_alive():
                while True:
                    try:
                        line = line_queue.get_nowait()
                    except queue.Empty:
                        break
                    log_view.appendPlainText(line)
                timer.stop()
                mark_finished()
                self._on_video_uninstall_finished(
                    log_dlg, status, close_btn, result_holder)

        timer.timeout.connect(drain)
        timer.start()
        log_dlg.exec()

    def _on_video_uninstall_finished(self, log_dlg, status_label,
                                     close_btn, result_holder):
        """Worker-completion handler for bulk uninstall."""
        if hasattr(self, "_video_stack_rows"):
            self._refresh_video_stack_panel()
        if hasattr(self, "_dl_l2cs_btn"):
            self._refresh_l2cs_button()
        if hasattr(self, "_video_install_all_btn"):
            self._refresh_video_install_all_btn()
        if "error" in result_holder:
            status_label.setText(
                "Uninstall failed: " + result_holder["error"])
            return
        summary = result_holder.get("summary")
        if summary is None:
            status_label.setText(
                "Uninstall ended without a summary.")
            return
        ok = sum(1 for r in summary.pip_results if r.success)
        fail = len(summary.failures)
        files_n = len(summary.files_removed)
        if summary.cancelled:
            status_label.setText(
                f"<b>Cancelled.</b>  {ok} package(s) removed before "
                "stop; data-file cleanup skipped.")
        elif summary.all_succeeded:
            status_label.setText(
                f"<b>Uninstall complete.</b>  {ok} package(s) "
                f"removed, {files_n} data file(s) deleted.")
        else:
            failed = ", ".join(r.dist for r in summary.failures)
            status_label.setText(
                f"<b>Partial uninstall:</b> {ok} succeeded, "
                f"{fail} failed ({failed}).  See log for details.")

    def _make_cancel_close_button(
            self, log_dlg, cancel_token, status_label, *,
            confirm_title="Cancel?", confirm_body=None):
        """Build a Cancel/Close toggle button for a streaming-log
        dialog.  Returns ``(button, mark_finished_callback)``.

        Initial state: button text "Cancel", enabled, clicking
        confirms then cancels the token + flips status to
        "Cancelling…".  After ``mark_finished()`` is called from
        the drain timer's worker-done branch, button text becomes
        "Close" and clicking it closes the dialog.
        """
        btn = QPushButton("Cancel")
        state = {"finished": False}

        def on_click():
            if state["finished"]:
                log_dlg.close()
                return
            body = confirm_body or (
                "Stop the running pip subprocess?\n\n"
                "Anything pip already finished stays as-is; the\n"
                "current operation is sent SIGTERM, which pip\n"
                "rolls back cleanly.")
            if not self._msg_confirm(confirm_title, body):
                return
            cancel_token.cancel()
            btn.setText("Cancelling...")
            btn.setEnabled(False)
            status_label.setText(
                "<b>Cancelling…</b>  Waiting for pip to exit.")

        btn.clicked.connect(on_click)

        def mark_finished():
            state["finished"] = True
            btn.setText("Close")
            btn.setEnabled(True)

        return btn, mark_finished

    @staticmethod
    def _show_install_success(*, log_view, status_label, status_text,
                              banner_lines):
        """Surface a successful install in the streaming-log dialog:
        a high-visibility banner appended at the bottom of the log
        (where pip's auto-scroll leaves the cursor) plus a green
        bold status label above.  ``log_view`` may be ``None`` in
        callers that only have the status label — banner is then
        skipped silently.
        """
        if log_view is not None:
            log_view.appendPlainText("")
            log_view.appendPlainText("=" * 60)
            for line in banner_lines:
                log_view.appendPlainText(line)
            log_view.appendPlainText("=" * 60)
        status_label.setStyleSheet(_SUCCESS_LABEL_QSS)
        status_label.setText(status_text)

    def _install_video_stack(self, plan):
        """Run pip install for plan.missing in a worker thread,
        streaming pip output into a modal log dialog.

        Cell-blocked packages are skipped — they need user-side
        remediation the runner cannot perform.  After installs
        complete, prompts for a process restart when any
        hot-import-incompatible package landed (cv2 / av /
        insightface / onnxruntime / torch).
        """
        from ide4eeg.install_runner import VideoStackInstaller

        # L2CS extras (torch + l2cs) are large.  Offer an opt-out
        # checkbox in the confirm dialog so users can install just
        # the core stack and stay on the InsightFace head-pose
        # fallback.
        any_optional = any(p.optional for p in plan.missing)
        consent_dlg = QDialog(self)
        consent_dlg.setWindowTitle("Install missing video packages")
        consent_dlg.setMinimumWidth(440)
        cl = QVBoxLayout(consent_dlg)
        pkgs_list = "\n".join(
            f"  • {p.purpose}" for p in plan.missing)
        cl.addWidget(QLabel(
            f"<b>{len(plan.missing)} package(s) will be installed:"
            f"</b><br><pre>{pkgs_list}</pre>"))
        opt_cb = QCheckBox(
            "Include L2CS-Net + PyTorch (default eye-gaze backend, "
            "~500 MB CPU / up to ~2 GB CUDA)")
        opt_cb.setChecked(True)
        if any_optional:
            cl.addWidget(opt_cb)
        else:
            opt_cb.setChecked(False)  # nothing optional in plan
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        ok_btn = QPushButton("Install")
        cancel_btn = QPushButton("Cancel")
        ok_btn.setDefault(True)
        btn_row.addWidget(ok_btn)
        btn_row.addWidget(cancel_btn)
        cl.addLayout(btn_row)
        consent = {"go": False}
        ok_btn.clicked.connect(
            lambda: (consent.__setitem__("go", True),
                     consent_dlg.accept()))
        cancel_btn.clicked.connect(consent_dlg.reject)
        consent_dlg.exec()
        if not consent["go"]:
            return
        include_optional = opt_cb.isChecked()

        # Build the streaming-log dialog.
        from ide4eeg.install_runner import CancellationToken
        cancel_token = CancellationToken()
        log_dlg = QDialog(self)
        log_dlg.setWindowTitle("Installing video packages")
        log_dlg.setMinimumSize(640, 360)
        ll = QVBoxLayout(log_dlg)
        status = QLabel("Starting pip install...")
        ll.addWidget(status)
        log_view = QPlainTextEdit()
        log_view.setReadOnly(True)
        log_view.setStyleSheet(
            "QPlainTextEdit { font-family: monospace; }")
        ll.addWidget(log_view, 1)
        close_btn, mark_finished = self._make_cancel_close_button(
            log_dlg, cancel_token, status,
            confirm_title="Cancel install?")
        ll.addWidget(close_btn)
        log_dlg.setModal(True)

        # Cross-thread channel: the worker thread emits each pip
        # line into a queue; a 50 ms polling timer drains it on the
        # main thread (Qt UI is single-threaded — direct widget
        # manipulation from the worker would race or crash).
        import queue
        line_queue: "queue.Queue[str]" = queue.Queue()
        result_holder: dict = {}

        def log_callback(line: str) -> None:
            line_queue.put(line)

        def worker():
            try:
                installer = VideoStackInstaller(
                    log_callback=log_callback,
                    cancel=cancel_token)
                summary = installer.install_plan(
                    plan, include_optional=include_optional)
                result_holder["summary"] = summary
            except Exception as exc:
                result_holder["error"] = (
                    f"{type(exc).__name__}: {exc}")

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        timer = QTimer(log_dlg)
        timer.setInterval(50)

        def drain():
            while True:
                try:
                    line = line_queue.get_nowait()
                except queue.Empty:
                    break
                log_view.appendPlainText(line)
            if not thread.is_alive():
                # Final drain in case the worker finished between
                # the loop and is_alive() check.
                while True:
                    try:
                        line = line_queue.get_nowait()
                    except queue.Empty:
                        break
                    log_view.appendPlainText(line)
                timer.stop()
                mark_finished()
                self._on_video_install_finished(
                    log_dlg, status, close_btn, result_holder,
                    log_view=log_view)

        timer.timeout.connect(drain)
        timer.start()
        log_dlg.exec()

    def _on_video_install_finished(self, log_dlg, status_label,
                                   close_btn, result_holder,
                                   *, log_view=None):
        """Worker-completion handler: surface success / failure /
        cancellation + restart-required prompt + refresh the
        persistent panel so newly installed packages flip from
        [--] to [ok]."""
        if hasattr(self, "_video_stack_rows"):
            self._refresh_video_stack_panel()
        if hasattr(self, "_video_install_all_btn"):
            self._refresh_video_install_all_btn()
        if "error" in result_holder:
            status_label.setText(
                "Install failed: " + result_holder["error"])
            return
        summary = result_holder.get("summary")
        if summary is None:
            status_label.setText("Install ended without a summary.")
            return
        ok = sum(1 for r in summary.results if r.success)
        fail = len(summary.results) - ok
        if summary.cancelled:
            status_label.setText(
                f"<b>Cancelled.</b>  {ok} package(s) installed "
                "before stop; remaining were skipped.")
        elif summary.all_succeeded and not summary.skipped_blocked:
            self._show_install_success(
                log_view=log_view,
                status_label=status_label,
                status_text=(
                    f"✓ All {ok} package(s) installed successfully."),
                banner_lines=[
                    f"All {ok} package(s) installed successfully."])
        elif summary.failures:
            failed_names = ", ".join(
                r.pkg.import_name for r in summary.failures)
            status_label.setText(
                f"<b>Partial install:</b> {ok} succeeded, "
                f"{fail} failed ({failed_names}).  Scroll the log "
                "for pip output.")
        elif summary.skipped_blocked:
            blocked_names = ", ".join(
                p.import_name for p in summary.skipped_blocked)
            status_label.setText(
                f"<b>{ok} package(s) installed.</b>  "
                f"{len(summary.skipped_blocked)} platform-blocked "
                f"({blocked_names}) — see diagnostic for fix steps.")
        if summary.needs_restart and not summary.cancelled:
            QTimer.singleShot(
                0, lambda: self._maybe_restart_after_install(summary))

    def _maybe_restart_after_install(self, summary):
        """Offer a process restart after installing C-extension or
        native-loader packages that can't be hot-imported."""
        from ide4eeg.install_runner import _RESTART_REQUIRED_PKGS
        installed_native = [
            r.pkg.import_name for r in summary.results
            if r.success and r.pkg.import_name in _RESTART_REQUIRED_PKGS]
        if not installed_native:
            return
        if self._msg_confirm(
                "Restart IDE4EEG?",
                "Installed packages that need a clean Python\n"
                "process to load reliably:\n  • "
                + "\n  • ".join(installed_native)
                + "\n\nRestart now?"):
            self._restart_application()

    def _restart_application(self):
        """Re-exec the current process to pick up freshly installed
        C extensions / native modules.  Unsaved GUI state is lost
        — the restart confirm dialog warns about this implicitly
        ("Restart now?") so the user can save first if they care.
        """
        import os
        os.execv(sys.executable, [sys.executable] + sys.argv)

    def _msg_warning(self, title, text):
        """Styled warning dialog (OK button)."""
        self._styled_dialog(
            title, title, text,
            self.style().StandardPixmap.SP_MessageBoxWarning,
            [("OK", "accept")])

    def _msg_error(self, title, text):
        """Styled error dialog (OK button)."""
        self._styled_dialog(
            title, title, text,
            self.style().StandardPixmap.SP_MessageBoxCritical,
            [("OK", "accept")])

    def _msg_confirm(self, title, text):
        """Styled yes/no confirmation dialog. Returns True if confirmed."""
        return self._styled_dialog(
            title, title, text,
            self.style().StandardPixmap.SP_MessageBoxQuestion,
            [("Yes", "accept"), ("No", "reject")])

    # ── Preflight checks ─────────────────────────────────────────

    def _mp_preflight_gui(self):
        """MP decomposition preflight — runs BEFORE _collect_config.

        Checks the GUI widgets directly and auto-remediates by
        switching combos / enabling checkboxes / expanding panels.
        Returns True if the pipeline should proceed, False if the
        user cancelled or a fatal conflict is unresolvable.

        Rules (see mp-preflight-rules.md):
          R3  auto-enable MP decomposition when consumers need it
          R1  force MMP1 when Dipole Fitting is checked
          R2  require channel selection for TF-MP / Profiles
        """
        # Ensure both tabs are built so we can manipulate their widgets
        for key, builder in [("preproc", self._build_preproc_tab),
                             ("analysis", self._build_analysis_tab)]:
            if key not in self._tab_built:
                builder()
                self._tab_built[key] = True
        pp = getattr(self, "_pp", {})
        an = getattr(self, "_an", {})

        # ── Which consumers are checked? ──────────────────────────
        dipoles_on = (an.get("_dip_grp")
                      and an["_dip_grp"].isChecked())
        profiles_on = (an.get("_prof_grp")
                       and an["_prof_grp"].isChecked())
        mp_filter_on = (pp.get("_mpf_grp")
                        and pp["_mpf_grp"].isChecked())

        needs_mp = (dipoles_on or profiles_on or mp_filter_on)
        if not needs_mp:
            return True

        mp_grp = pp.get("_mp_grp")
        mp_on = mp_grp.isChecked() if mp_grp else False

        # ── R3 + R1: auto-enable MP and/or force MMP1 ────────────
        # Coalesced so the user sees a single dialog covering both
        # issues instead of being bounced back twice.
        remediated = []
        if not mp_on and not self._find_mp_book():
            if mp_grp:
                mp_grp.setChecked(True)
                mp_grp.expand()
            remediated.append("Enabled MP decomposition.")

        if dipoles_on:
            algo_combo = pp.get("mp_algo")
            if algo_combo:
                current_algo = parse_mp_algorithm_label(
                    algo_combo.currentText())
                if current_algo != "mmp1":
                    mmp1_label = next(
                        (label for name, label in mp_algorithm_choices()
                         if name == "mmp1"), None)
                    if mmp1_label is None:
                        self._msg_error(
                            "MMP1 not available",
                            "Dipole Fitting requires MMP1 but it's not "
                            "in the algorithm list.")
                        return False
                    algo_combo.setCurrentText(mmp1_label)
                    if mp_grp:
                        mp_grp.expand()
                    remediated.append(
                        f"Switched algorithm from {current_algo} "
                        f"to MMP1 (required by Dipole Fitting).")

        if remediated:
            self._msg_info(
                "MP settings adjusted",
                "\n".join(remediated) + "\n\n"
                "Review the MP decomposition settings in the\n"
                "Preprocessing tab, then click Run again.")
            if hasattr(self, "_tabs") and hasattr(self, "_tab_preproc"):
                self._tabs.setCurrentWidget(self._tab_preproc)
            return False

        # ── R2: channel selection required ─────────────────────────
        missing_ch = []
        if profiles_on:
            bp = an.get("prof_book_panel")
            if bp and not bp.selected_channel():
                missing_ch.append(("EEG Profiles", "_prof_grp"))
        if missing_ch:
            names = ", ".join(n for n, _ in missing_ch)
            self._msg_info(
                "Channel selection required",
                f"The following analyses need an explicit channel\n"
                f"selection from the MP book:\n"
                f"{names}\n\n"
                f"Select a channel in the book panel, then click\n"
                f"Run again.")
            # Expand the first offending panel
            key = missing_ch[0][1]
            grp = an.get(key)
            if grp and hasattr(grp, "expand"):
                grp.expand()
            if hasattr(self, "_tabs") and hasattr(self, "_tab_analysis"):
                self._tabs.setCurrentWidget(self._tab_analysis)
            return False

        return True

    def _preflight_check(self, cfg):
        """Check config for issues before running.

        Returns (fatal, warnings) where fatal is a list of blocking issues
        and warnings is a list of non-blocking issues.
        """
        fatal, warnings = [], []
        mode = get_segmentation_mode(cfg)

        # MP book checks — consumer list built by the shared helper
        # so the detection logic isn't duplicated across GUI / CLI.
        from ide4eeg.main import (
            mp_consumers_from_cfg, mp_decomposition_enabled)
        needs_mp = mp_consumers_from_cfg(cfg)
        if needs_mp and not self._find_mp_book() \
                and not mp_decomposition_enabled(cfg):
            empi = (cfg.get("matching_pursuit", {}).get("empi_path", "")
                    or self._empi_path or "")
            if not empi or not os.path.isfile(empi):
                fatal.append(
                    f"<b>MP decomposition required</b><br>"
                    f"The following need MP books: "
                    f"{', '.join(needs_mp)}<br>"
                    f"No books found and empi binary is not configured.<br>"
                    f"Set the empi path in Config tab, or run MP "
                    f"decomposition first.")
            else:
                # empi available — auto-enable MP decomposition by
                # appending to step_order, then warn the user.
                preproc = cfg.setdefault("preprocessing", {})
                step_order = preproc.setdefault("step_order", [])
                if "mp_decomposition" not in step_order:
                    step_order.append("mp_decomposition")
                warnings.append(
                    f"<b>MP decomposition will run first</b><br>"
                    f"The following need MP books: "
                    f"{', '.join(needs_mp)}<br>"
                    f"No existing books found — MP decomposition will be "
                    f"added to preprocessing (this may take a while).")

        # Event-locked mode: check that events are selected
        if mode == "epochs":
            selected = cfg.get("epochs", {}).get("tags", {}).get("selected", [])
            if isinstance(selected, list) and not selected:
                fatal.append(
                    "<b>No events selected</b><br>"
                    "Event-locked mode requires at least one event. "
                    "Check events in the Events panel (Segmentation setup).")
            else:
                # Trim-aware coverage check.  Resolves selected event
                # names → STIM codes, then samples the cached signal's
                # STIM channel inside the configured trim window.  If
                # the intersection is empty, ``_cut_segments`` would
                # later raise "zero epochs" — catch it before the
                # pipeline starts so the user gets actionable feedback.
                self._check_events_in_trim(cfg, fatal)
            # EEG profiles assumes a continuous time axis.  Event-locked
            # epochs are scattered across the recording at event times,
            # so the profile chart's x-axis underestimates the span and
            # detections past the contiguous-segments duration fall off
            # the canvas — switch to timed windows for profiles.
            if cfg.get("prepare_eeg_profiles", False):
                warnings.append(
                    "<b>EEG profiles + event-locked mode</b><br>"
                    "EEG profiles is designed for continuous timed-"
                    "windows analysis. With event-locked epochs the "
                    "profile chart's x-axis covers only the total "
                    "epoch duration (n_epochs × epoch length), so "
                    "detections that fall in gaps between events "
                    "won't be visible. Switch to timed windows in "
                    "Segmentation Setup before running profiles.")

        # Re-reference: when the user lists explicit channel names
        # (e.g. ["A1", "A2"]) but none match the signal's channels,
        # ``_set_reference`` silently leaves the reference unchanged
        # and the pipeline runs with raw recording reference --
        # surprising and easy to miss in the run log.  Catch it here.
        # ``_cached_ch_names`` is populated by every reader path, so
        # this works regardless of format (unlike ``_cached_signal``,
        # which only the legacy in-memory preload path produced).
        rr = cfg.get("re_reference")
        ch_names = getattr(self, "_cached_ch_names", None)
        if (isinstance(rr, list) and rr
                and ch_names
                and "reference" in effective_step_order(cfg)):
            available = set(ch_names)
            requested = [str(c) for c in rr]
            matched = [c for c in requested if c in available]
            if not matched:
                fatal.append(
                    "<b>Re-reference channels not found</b><br>"
                    f"Requested: {', '.join(requested)}<br>"
                    f"Signal has {len(available)} channels -- none "
                    "of the requested names match.  Either fix the "
                    "Reference panel's channel list or remove the "
                    "Reference step from preprocessing.")

        # Video-stack preflight.  Three classes of failure caught here:
        #   (1) core stack (cv2/av/imageio/insightface/onnxruntime)
        #       missing — user is on a no-video install
        #   (2) a package is platform-blocked on this cell (e.g.
        #       onnxruntime on Intel Mac + Py3.14) — needs cell-aware
        #       remediation
        #   (3) L2CS extras (torch / l2cs) missing when gaze_method
        #       = "l2cs" — keeps the existing pointer-to-Download-button
        #       message because the install path is a single GUI button
        # All three share install_diagnostics.plan_install; we slice
        # the plan by what this run actually needs.
        if cfg.get("prepare_video_artifacts", False):
            from ide4eeg.install_diagnostics import plan_install
            plan = plan_install()
            needs_l2cs = (
                cfg.get("facetag_gaze_method", "l2cs") == "l2cs")
            core_missing = [p for p in plan.missing if not p.optional]
            core_blocked = [(p, i) for p, i in plan.blocked
                            if not p.optional]
            if core_missing or core_blocked:
                import html as _html
                from ide4eeg.install_diagnostics import format_diagnostic
                fatal.append(
                    "<b>Video stack not ready</b><br>"
                    f"<pre>{_html.escape(format_diagnostic(plan))}"
                    "</pre>"
                    "<i>Open the Config tab → Video processing "
                    "panel for live status and an Install missing "
                    "button.</i>")
            elif needs_l2cs:
                from ide4eeg.download_tools import l2cs_missing_deps
                missing = l2cs_missing_deps()
                if missing:
                    fatal.append(
                        "<b>L2CS gaze backend requires "
                        + " + ".join(missing) + "</b><br>"
                        "Click <b>Download recent</b> next to "
                        "<i>L2CS-Net (gaze detection)</i> on the "
                        "Config tab to install torch + l2cs + the "
                        "Gaze360 weights in one shot, or switch the "
                        "Method dropdown on the Gaze panel to "
                        "<i>insightface</i> (head-pose only).")

        return fatal, warnings

    def _check_events_in_trim(self, cfg, fatal):
        """Append a fatal entry when selected events don't exist in the
        file.

        Cheap pure-metadata check: every name in
        ``epochs.tags.selected`` must appear among the events the
        reader discovered (named via ``_cached_events`` plus
        ``UNNAMED_CODE_LABEL`` renderings of ``_cached_unnamed_codes``,
        the same union the picker offers).

        TODO(events-in-trim): the actual "selected events trimmed
        away" check needs the full signal handle to scan STIM within
        ``[trim_start, trim_end]``; no reader exposes one via the
        metadata API today.  Pipeline still catches the disjoint case
        later, just with a less specific error.
        """
        try:
            selected_names = list(
                cfg.get("epochs", {}).get("tags", {}).get("selected", []))
            if not selected_names:
                return
            available = self._all_event_labels(
                getattr(self, "_cached_events", None),
                getattr(self, "_cached_unnamed_codes", None))
            if not available:
                # Reader didn't report any events — the pipeline will
                # surface its own "no events" error with full context.
                return
            missing = [n for n in selected_names if n not in available]
            if not missing:
                return
            avail_preview = ", ".join(sorted(available)[:10])
            if len(available) > 10:
                avail_preview += f", ... ({len(available)} total)"
            fatal.append(
                "<b>Selected events not present in the file</b><br>"
                f"Missing: {', '.join(missing)}<br>"
                f"Available: {avail_preview}<br>"
                "Update the event selection on the Input tab, or "
                "switch to a recording that contains these events.")
        except Exception:
            # Preflight must never block a run on its own bug — the
            # pipeline still has its own validation.
            return

    def _show_preflight_warnings(self, fatal, warnings):
        """Show a styled pre-flight dialog. Returns True if user wants to proceed.

        Fatal issues block execution (no 'Run anyway' button).
        Warnings allow the user to proceed.
        """
        if not fatal and not warnings:
            return True
        dlg = QDialog(self)
        dlg.setMinimumWidth(450)
        lay = QVBoxLayout(dlg)

        if fatal:
            dlg.setWindowTitle("Cannot run")
            icon_sp = self.style().StandardPixmap.SP_MessageBoxCritical
            header_text = "<h3>Blocking issues found</h3>"
        else:
            dlg.setWindowTitle("Pre-flight check")
            icon_sp = self.style().StandardPixmap.SP_MessageBoxWarning
            header_text = "<h3>Issues found before running</h3>"

        icon_label = QLabel()
        icon_label.setPixmap(
            self.style().standardPixmap(icon_sp).scaled(48, 48))
        header = QHBoxLayout()
        header.addWidget(icon_label)
        header.addWidget(QLabel(header_text), 1)
        lay.addLayout(header)

        for items, color in [(fatal, "#d32f2f"), (warnings, None)]:
            for w in items:
                frame = QFrame()
                frame.setFrameShape(QFrame.StyledPanel)
                style = ("QFrame { background: palette(alternate-base); "
                         "border-radius: 6px; padding: 8px;")
                if color:
                    style += f" border-left: 4px solid {color};"
                style += " }"
                frame.setStyleSheet(style)
                fl = QVBoxLayout(frame)
                fl.setContentsMargins(10, 8, 10, 8)
                lbl = QLabel(w)
                lbl.setWordWrap(True)
                fl.addWidget(lbl)
                lay.addWidget(frame)

        lay.addSpacing(8)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        if fatal:
            ok_btn = QPushButton("OK")
            ok_btn.setDefault(True)
            ok_btn.clicked.connect(dlg.reject)
            btn_row.addWidget(ok_btn)
        else:
            run_btn = QPushButton("Run anyway")
            cancel_btn = QPushButton("Cancel")
            cancel_btn.setDefault(True)
            run_btn.clicked.connect(dlg.accept)
            cancel_btn.clicked.connect(dlg.reject)
            btn_row.addWidget(run_btn)
            btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)
        return dlg.exec() == QDialog.Accepted

    def _show_pipeline_error(self, detail=""):
        """Show a styled pipeline error dialog."""
        body = ""
        if detail:
            body += detail + "<br><br>"
        body += "See the Run tab log for the full traceback."
        self._msg_error("Pipeline failed", body)

    # All analysis flags that per-step Run must zero out
    _ANALYSIS_FLAGS = [
        "prepare_eeg_profiles",
        "prepare_connectivity_analysis",
        "prepare_dipole_fitting",
        "prepare_tf_statistics",
    ]

    def _disable_all_analyses(self, cfg):
        """Zero every analysis flag + clear ``cfg['mne_catalog']``.

        ``_ANALYSIS_FLAGS`` covers the four ``prepare_*`` toggles
        consumed by ``ide4eeg.analysis.analysis.analysis_main``.
        ``cfg['mne_catalog']`` is a separate channel — a list of
        MNE-catalog IDs (``erp_butterfly``, ``erp_joint``,
        ``erp_topomap``, ``erp_dipole_fit``, ...) that the runner
        loops over independently of any flag.  Both surfaces need
        to be neutralised when a path wants "preprocessing only"
        (eye-button viewer, manual bad-epoch review, etc.).
        """
        for flag in self._ANALYSIS_FLAGS:
            cfg[flag] = False
        cfg["mne_catalog"] = []

    # Analyses that only need the MP book, not the signal
    _BOOK_ONLY_ANALYSES = {
        "prepare_eeg_profiles",
        "prepare_dipole_fitting",
    }

    def _run_pipeline_for_analysis(self, analysis_key, grp_widget):
        """Run full pipeline with only one analysis enabled."""
        # Fast path: book-only analyses skip signal loading/preprocessing
        if analysis_key in self._BOOK_ONLY_ANALYSES:
            book = self._find_mp_book()
            if book:
                self._run_book_only_analysis(
                    analysis_key, grp_widget, book)
                return
        if not self._mp_preflight_gui():
            if grp_widget and grp_widget._run_btn:
                grp_widget._run_btn.setEnabled(True)
                grp_widget.setStatusText("")
            return
        cfg = self._collect_config()
        # Disable everything (every prepare_* flag + the mne_catalog
        # list), then re-enable just the requested analysis.  Without
        # the catalog clear, any MNE-catalog items the user has
        # checked on the Analysis tab would also fire on a single-
        # analysis Run click — surprising side effect.
        self._disable_all_analyses(cfg)
        cfg[analysis_key] = True
        # Respect the user's MP checkbox: if it's checked, MP recomputes
        # (force-recompute lever); if it's unchecked, the auto-discovery
        # preamble in preprocessing() reuses an existing book on hash
        # match.  Two paths, one rule.
        if not self._launch_pipeline(cfg):
            # Validation failed — re-enable the Run button
            if grp_widget and grp_widget._run_btn:
                grp_widget._run_btn.setEnabled(True)
                grp_widget.setStatusText("")

    def _run_book_only_analysis(self, analysis_key, grp_widget, book_path):
        """Run a book-only analysis directly, skipping preprocessing.

        Mirrors :mod:`ide4eeg.main`'s analysis-path layout so a
        book-only invocation lands next to a regular runner output
        (audit finding #5, 2026-05-02): honour
        ``analysis_output_path`` when explicit, else build
        ``<output_path>/IDE4EEG_OUT_<base>[/<timestamp>_<mode>]/analysis/``
        with the same iterative-stem-strip rule the runner uses.
        """
        from datetime import datetime
        cfg = self._collect_config()
        cfg["_mp_book_path"] = book_path
        inp = cfg.get("input_path", "")
        # Iterative stem strip — same convention as
        # ``ide4eeg/main.py``.  "subj.with.dots.bdf" → "subj".
        file_name = os.path.basename(inp) if inp else ""
        while "." in file_name:
            file_name = os.path.splitext(file_name)[0]
        if not file_name:
            file_name = "signal"

        explicit_analysis = cfg.get("analysis_output_path", "").strip()
        out = self._output_edit.text().strip()
        if explicit_analysis:
            analysis_path = explicit_analysis
        elif out and inp:
            run_root = os.path.join(
                out, f"{OUTPUT_DIR_PREFIX}{file_name}")
            if not cfg.get("overwrite_output", False):
                mode = get_segmentation_mode(cfg)
                run_root = os.path.join(
                    run_root,
                    f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{mode}")
            analysis_path = os.path.join(run_root, "analysis")
        elif out:
            analysis_path = out
        else:
            analysis_path = os.path.dirname(book_path)
        os.makedirs(analysis_path, exist_ok=True)

        if grp_widget and grp_widget._run_btn:
            grp_widget._run_btn.setEnabled(False)
            grp_widget.setStatusText("running...")

        self._pending_analysis_grp = grp_widget
        import threading

        def worker():
            try:
                # Headless backend on macOS only (Qt off the main thread
                # crashes on macOS; Linux/Windows handle it fine).
                if sys.platform == "darwin":
                    import matplotlib.pyplot as _plt
                    _plt.switch_backend("Agg")
                _dispatch = {
                    "prepare_eeg_profiles": lambda: (
                        __import__("ide4eeg.analysis.eeg_profiles",
                                   fromlist=["eeg_profiles"]).eeg_profiles(
                            None, None, cfg, analysis_path, file_name)),
                    "prepare_dipole_fitting": lambda: (
                        __import__("ide4eeg.analysis.dipole_analysis",
                                   fromlist=["dipole_analysis"]).dipole_analysis(
                            None, None, cfg, analysis_path, file_name)),
                }
                fn = _dispatch.get(analysis_key)
                if fn:
                    fn()
                self._signals.pipeline_finished.emit(True)
            except Exception as e:
                logging.error("Book-only analysis failed: %s", e)
                self._signals.pipeline_finished.emit(False)

        t = threading.Thread(target=worker, daemon=True)
        t.start()


    def _dip_view_montage(self):
        """Show the montage selected in the dipole fitting panel."""
        an = getattr(self, "_an", {})
        montage_name = self._cmb(an, "dip_montage", "standard_1005")
        try:
            import mne
            montage = mne.channels.make_standard_montage(montage_name)
        except Exception as e:
            self._msg_error("Montage error",
                            f"Cannot load montage '{montage_name}':\n{e}")
            return
        file_ch_names = set()
        cached = getattr(self, "_cached_signal", None)
        if cached is not None:
            file_ch_names = set(cached.ch_names)
        pos_3d = montage.get_positions()["ch_pos"]
        matched = file_ch_names & set(montage.ch_names)
        title = f"{montage_name}  ({len(matched)} matched)" if matched else montage_name
        fig = montage.plot(show=False)
        fig.suptitle(title)
        fig.show()



    def _dipole_pick_atoms(self):
        """Open BookViewer for picking atoms for dipole fitting."""
        bp = self._an.get("dip_book_panel")
        book = bp.selected_book() if bp else ""
        if not book or not os.path.isfile(book):
            self._msg_info("No book", "Select an MMP book first."); return
        def _on_accept(atoms):
            self._an["dip_picked_atoms"] = atoms
            n = len(atoms)
            self._an["dip_picked_label"].setText(f"{n} atom(s) selected")
            self._status.showMessage(f"Picked {n} atom(s) for dipole fitting", 5000)
        try:
            from ide4eeg.analysis.mp_bookviewer_qt import BookViewerQt
            win = BookViewerQt(parent=self, db_path=book,
                               on_accept=_on_accept, hide_open=True)
            win.show()
            self._status.showMessage("BookViewer opened -- select atoms and Accept", 10000)
        except Exception as e: self._msg_error("Error", str(e))

    def _view_connectivity_in_connectivis(self):
        """Find analysis output files and launch 3D viewer. For
        dipoles, prefer ``___dipoles.csv`` (MNI-mm + full attributes)
        over the legacy ``.dat``; the viewer reads both but only the
        CSV aligns with the brain PLY."""
        import glob as _glob
        out = self._analysis_edit.text().strip() or self._output_edit.text().strip()
        if not out:
            self._msg_info("No output", "Set output path first."); return
        files = []
        files.extend(sorted(_glob.glob(
            os.path.join(out, "**", "connectivity_analysis", "*.dat"),
            recursive=True)))
        dip_csv = sorted(_glob.glob(
            os.path.join(out, "**", "dipole_analysis", "*___dipoles.csv"),
            recursive=True))
        if dip_csv:
            files.extend(dip_csv)
        else:
            files.extend(sorted(_glob.glob(
                os.path.join(out, "**", "dipole_analysis", "*.dat"),
                recursive=True)))
        # ERP dipole CSV (Analysis tab, external section)
        files.extend(sorted(_glob.glob(
            os.path.join(out, "**", "erp_dipole_fit",
                         "*___erp_dipoles.csv"),
            recursive=True)))
        if not files:
            self._msg_info("No results", "No analysis output files found."); return
        self._launch_connectivis(files)

    # ── connectivis auto-launch ──────────────────────────────────────

    def _auto_launch_connectivis(self, cfg, output_path):
        """Launch connectivis if connectivity/dipole results exist.

        For dipoles we pass the ``___dipoles.csv`` (MNI-mm columns +
        moment/GoF/frequency) rather than the legacy ``___dipoles.dat``
        — the viewer consumes both but only the CSV aligns with the
        brain PLY and drives the size-mode combo.
        """
        import glob as _glob
        files = []
        if cfg.get("prepare_connectivity_analysis", False):
            files.extend(sorted(_glob.glob(
                os.path.join(output_path, "connectivity_analysis", "*.dat"))))
        if cfg.get("prepare_dipole_fitting", False):
            dip_csv = sorted(_glob.glob(
                os.path.join(output_path, "dipole_analysis", "*___dipoles.csv")))
            if dip_csv:
                files.extend(dip_csv)
            else:
                files.extend(sorted(_glob.glob(
                    os.path.join(output_path, "dipole_analysis", "*.dat"))))
        if files:
            self._launch_connectivis(files)

    # ── Tab 6: Output (lazy) ─────────────────────────────────────────

    def _build_output_tab(self):
        layout = QVBoxLayout(self._tab_output)
        layout.setContentsMargins(4, 4, 4, 4)

        # Output path label (compact)
        self._output_path_label = QLabel("")
        self._output_path_label.setStyleSheet(
            "color: gray; padding: 2px; font-size: 11px;")
        layout.addWidget(self._output_path_label)
        # Item 10: auto-update output path label when edit changes
        self._output_edit.textChanged.connect(
            lambda t: self._output_path_label.setText(
                f"Output: {t}" if t else ""))

        splitter = QSplitter(Qt.Horizontal)

        # File tree
        self._output_tree = QTreeWidget()
        self._output_tree.setHeaderLabels(["File", "Size"])
        self._output_tree.setMinimumWidth(350)
        self._output_tree.header().setStretchLastSection(False)
        self._output_tree.header().setSectionResizeMode(
            0, self._output_tree.header().ResizeMode.Stretch)
        self._output_tree.header().setSectionResizeMode(
            1, self._output_tree.header().ResizeMode.ResizeToContents)
        self._output_tree.currentItemChanged.connect(
            self._on_output_item_clicked)
        self._output_tree.itemDoubleClicked.connect(
            self._on_output_double_click)
        splitter.addWidget(self._output_tree)

        # Preview pane (stacked: placeholder, image, text, table, fif info)
        self._preview_stack = QStackedWidget()
        # 0: placeholder
        self._preview_placeholder = QLabel("Select a file to preview")
        self._preview_placeholder.setAlignment(Qt.AlignCenter)
        self._preview_stack.addWidget(self._preview_placeholder)
        # 1: image preview
        self._preview_image = QLabel()
        self._preview_image.setAlignment(Qt.AlignCenter)
        self._preview_image.setScaledContents(False)
        self._preview_image.mouseDoubleClickEvent = (
            lambda ev: self._open_selected_output())
        scroll_img = QScrollArea()
        scroll_img.setWidget(self._preview_image)
        scroll_img.setWidgetResizable(True)
        self._preview_stack.addWidget(scroll_img)
        # 2: text preview
        self._preview_text = QTextEdit()
        self._preview_text.setReadOnly(True)
        self._preview_text.setFont(QFont("Menlo", 11))
        self._preview_stack.addWidget(self._preview_text)
        # 3: CSV table preview
        self._preview_table = QTableWidget()
        self._preview_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._preview_stack.addWidget(self._preview_table)
        # 4: FIF info preview
        fif_widget = QWidget()
        fif_layout = QVBoxLayout(fif_widget)
        self._preview_fif_info = QTextEdit()
        self._preview_fif_info.setReadOnly(True)
        self._preview_fif_info.setFont(QFont("Menlo", 11))
        fif_layout.addWidget(self._preview_fif_info)
        self._preview_stack.addWidget(fif_widget)

        self._preview_fif_path = ""
        # 5: MP book (.db) info preview
        db_widget = QWidget()
        db_layout = QVBoxLayout(db_widget)
        self._preview_db_info = QTextEdit()
        self._preview_db_info.setReadOnly(True)
        self._preview_db_info.setFont(QFont("Menlo", 11))
        db_layout.addWidget(self._preview_db_info)
        db_btn_row = QHBoxLayout()
        self._preview_db_viewer = QPushButton("Open in Book Viewer")
        self._preview_db_viewer.setFixedWidth(160)
        self._preview_db_viewer.clicked.connect(
            lambda: self._open_book_viewer(self._preview_db_path)
            if getattr(self, "_preview_db_path", "") else None)
        db_btn_row.addWidget(self._preview_db_viewer)
        db_btn_row.addStretch()
        db_layout.addLayout(db_btn_row)
        self._preview_stack.addWidget(db_widget)
        self._preview_db_path = ""
        # 6: .tag file preview (text + action buttons)
        tag_widget = QWidget()
        tag_layout = QVBoxLayout(tag_widget)
        self._preview_tag_text = QTextEdit()
        self._preview_tag_text.setReadOnly(True)
        self._preview_tag_text.setFont(QFont("Menlo", 11))
        tag_layout.addWidget(self._preview_tag_text)
        self._preview_stack.addWidget(tag_widget)

        splitter.addWidget(self._preview_stack)

        splitter.setSizes([500, 500])

        # Navigation row (above tree)
        nav_row = QHBoxLayout()
        current_btn = QPushButton("Current file")
        current_btn.setToolTip("Show results for the currently loaded file")
        current_btn.clicked.connect(self._refresh_output_tree)
        nav_row.addWidget(current_btn)
        up_btn = QPushButton("\u2191 level up")
        up_btn.setToolTip(
            "Search for IDE4EEG_OUT_* in parent directories")
        up_btn.clicked.connect(self._rescan_output_broader)
        nav_row.addWidget(up_btn)
        open_folder_btn = QPushButton("Open\u2026")
        open_folder_btn.setToolTip("Browse for a folder with results")
        open_folder_btn.clicked.connect(self._browse_output_folder)
        nav_row.addWidget(open_folder_btn)
        delete_btn = QPushButton("Delete selected")
        delete_btn.clicked.connect(self._delete_selected_output)
        nav_row.addWidget(delete_btn)
        nav_row.addStretch()
        layout.addLayout(nav_row)

        layout.addWidget(splitter, 1)  # stretch factor 1 = fill available space

        # View row (below tree).  Double-click in the tree routes to
        # the same per-ext dispatch as these buttons, so we no longer
        # expose a generic "Open" button — it was redundant.
        view_row = QHBoxLayout()
        self._output_mne_btn = QPushButton("\U0001f441 in MNE")
        self._output_mne_btn.setToolTip(
            "Open the selected .fif file in MNE's interactive browser")
        self._output_mne_btn.setEnabled(False)
        self._output_mne_btn.clicked.connect(self._view_output_in_mne)
        view_row.addWidget(self._output_mne_btn)
        self._output_svarog_btn = QPushButton("\U0001f441 in SVAROG")
        self._output_svarog_btn.setToolTip(
            "Open the selected file in SVAROG (auto-detects nearby .tag and .db\n"
            "files)")
        self._output_svarog_btn.setEnabled(False)
        self._output_svarog_btn.clicked.connect(self._view_output_in_svarog)
        view_row.addWidget(self._output_svarog_btn)
        self._output_3d_btn = QPushButton("\U0001f441 3D")
        self._output_3d_btn.setToolTip(
            "Open the selected .dat or dipoles .csv file\n"
            "in ConnectiVIS 3D viewer")
        self._output_3d_btn.setEnabled(False)
        self._output_3d_btn.clicked.connect(self._view_output_in_connectivis)
        view_row.addWidget(self._output_3d_btn)
        self._output_3d_all_btn = QPushButton("\U0001f441 all 3D")
        self._output_3d_all_btn.setToolTip(
            "Open ALL .dat results (dipoles + connectivity)\n"
            "together in one ConnectiVIS 3D scene")
        self._output_3d_all_btn.clicked.connect(
            self._view_all_output_in_connectivis)
        view_row.addWidget(self._output_3d_all_btn)
        view_row.addStretch()
        layout.addLayout(view_row)

        # Show pre-existing results immediately
        self._refresh_output_tree()

    def _refresh_output_tree(self):
        """Scan output directory for result files."""
        self._output_tree.clear()
        out = self._output_edit.text().strip()
        if hasattr(self, "_output_path_label"):
            self._output_path_label.setText(f"Output: {out}" if out else "")
        if not out or not os.path.isdir(out):
            self._update_tab_indicators()
            return
        # Find IDE4EEG_OUT_* directories
        for entry in sorted(os.listdir(out)):
            if entry.startswith(OUTPUT_DIR_PREFIX):
                full = os.path.join(out, entry)
                if os.path.isdir(full):
                    item = QTreeWidgetItem([entry, ""])
                    item.setToolTip(0, full)
                    self._output_tree.addTopLevelItem(item)
                    self._populate_tree(item, full)
        self._update_tab_indicators()

    _HIDDEN_FILES = {".DS_Store", "Thumbs.db", "desktop.ini", ".gitkeep"}
    _HIDDEN_SUFFIXES = ("___electrodes.dat", "___head.ply",
                        "___brain.ply")

    def _populate_tree(self, parent_item, dirpath):
        for entry in sorted(os.listdir(dirpath)):
            if entry in self._HIDDEN_FILES or entry.startswith("._"):
                continue
            if any(entry.endswith(s) for s in self._HIDDEN_SUFFIXES):
                continue
            full = os.path.join(dirpath, entry)
            if os.path.isdir(full):
                child = QTreeWidgetItem([entry, ""])
                child.setToolTip(0, full)
                parent_item.addChild(child)
                self._populate_tree(child, full)
            else:
                try:
                    size = os.path.getsize(full)
                except OSError:
                    size = 0
                if size > 1_000_000:
                    sz_str = f"{size / 1_000_000:.1f} MB"
                elif size > 1000:
                    sz_str = f"{size / 1000:.0f} KB"
                else:
                    sz_str = f"{size} B"
                child = QTreeWidgetItem([entry, sz_str])
                child.setToolTip(0, full)
                parent_item.addChild(child)

    def _output_item_path(self, item):
        """Build the full filesystem path from a tree item hierarchy.

        Prefers the tooltip (absolute path set by _populate_tree and
        _browse_output_folder) when available.  Falls back to walking
        the hierarchy and joining with the output directory.
        """
        tip = item.toolTip(0)
        if tip:
            return tip
        parts = []
        while item is not None:
            parts.append(item.text(0))
            item = item.parent()
        parts.reverse()
        out = self._output_edit.text().strip()
        return os.path.join(out, *parts) if out else ""

    _SVAROG_EXTS = {".fif", ".edf", ".bdf", ".raw", ".vhdr", ".set",
                     ".tag", ".db"}

    def _on_output_item_clicked(self, current, previous):
        """Preview the selected file in the output tree."""
        if current is None:
            self._preview_stack.setCurrentIndex(0)
            self._output_mne_btn.setEnabled(False)
            self._output_svarog_btn.setEnabled(False)
            self._output_3d_btn.setEnabled(False)
            return
        path = self._output_item_path(current)
        if not path or not os.path.isfile(path):
            self._preview_stack.setCurrentIndex(0)
            self._output_mne_btn.setEnabled(False)
            self._output_svarog_btn.setEnabled(False)
            self._output_3d_btn.setEnabled(False)
            return
        ext = os.path.splitext(path)[1].lower()
        self._output_mne_btn.setEnabled(ext == ".fif")
        self._output_svarog_btn.setEnabled(ext in self._SVAROG_EXTS)
        is_3d = (ext == ".dat"
                 or (ext == ".csv"
                     and os.path.basename(path).endswith("dipoles.csv")))
        self._output_3d_btn.setEnabled(is_3d)

        if ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp"):
            pixmap = QPixmap(path)
            if not pixmap.isNull():
                self._preview_pixmap = pixmap  # store for resize
                self._fit_preview_image()
            else:
                self._preview_image.setText("Could not load image")
            self._preview_stack.setCurrentIndex(1)

        elif ext == ".tag":
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    text = f.read(500_000)
                self._preview_tag_text.setPlainText(text)
            except Exception as e:
                self._preview_tag_text.setPlainText(
                    f"Error reading file: {e}")
            self._preview_stack.setCurrentIndex(6)

        elif ext in (".txt", ".log", ".toml", ".xml", ".json"):
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    text = f.read(500_000)  # limit to 500 KB
                self._preview_text.setPlainText(text)
            except Exception as e:
                self._preview_text.setPlainText(f"Error reading file: {e}")
            self._preview_stack.setCurrentIndex(2)

        elif ext == ".csv":
            import csv
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    reader = csv.reader(f)
                    rows = list(reader)
                if rows:
                    headers = rows[0]
                    self._preview_table.setColumnCount(len(headers))
                    self._preview_table.setHorizontalHeaderLabels(headers)
                    self._preview_table.setRowCount(
                        min(len(rows) - 1, 500))  # limit rows
                    for r, row in enumerate(rows[1:501]):
                        for c, val in enumerate(row):
                            if c < len(headers):
                                self._preview_table.setItem(
                                    r, c, QTableWidgetItem(val))
                    self._preview_table.resizeColumnsToContents()
                else:
                    self._preview_table.setRowCount(0)
                    self._preview_table.setColumnCount(0)
            except Exception as e:
                self._preview_table.setRowCount(0)
                self._preview_table.setColumnCount(1)
                self._preview_table.setItem(
                    0, 0, QTableWidgetItem(f"Error: {e}"))
            self._preview_stack.setCurrentIndex(3)

        elif ext == ".fif":
            self._preview_fif_path = path
            lower = path.lower()
            is_epo = "-epo.fif" in lower
            # Saved ICA decompositions live as ``<base>-ica.fif`` next
            # to a regular -raw.fif.  read_raw_fif on them works but
            # spams MNE's "does not conform to naming conventions"
            # warning and surfaces the wrong shape — open with
            # mne.preprocessing.read_ica instead.
            is_ica = "-ica.fif" in lower
            obj = None
            try:
                import mne
                if is_ica:
                    obj = mne.preprocessing.read_ica(path, verbose=False)
                    info_lines = [
                        f"ICA file: {os.path.basename(path)}",
                        f"Method: {obj.method}",
                        f"Components: {obj.n_components_}",
                        f"Excluded: {len(obj.exclude)} / "
                        f"{obj.n_components_}"
                        + (f" ({', '.join(map(str, obj.exclude))})"
                           if obj.exclude else ""),
                        f"Channels fit on: {len(obj.ch_names)}",
                        f"Channel names: {', '.join(obj.ch_names[:30])}"
                        + ("..." if len(obj.ch_names) > 30 else ""),
                    ]
                elif is_epo:
                    obj = mne.read_epochs(path, preload=False,
                                          verbose=False)
                    n_epo = len(obj)
                    info_lines = [
                        f"Epochs file: {os.path.basename(path)}",
                        f"Epochs: {n_epo}",
                        f"Time: [{obj.tmin:.3f}, {obj.tmax:.3f}] s",
                        f"Sampling: {obj.info['sfreq']:.0f} Hz",
                        f"Channels: {len(obj.ch_names)}",
                        f"Event IDs: {obj.event_id}",
                        f"Channel names: {', '.join(obj.ch_names[:30])}"
                        + ("..." if len(obj.ch_names) > 30 else ""),
                    ]
                else:
                    obj = mne.io.read_raw_fif(path, preload=False,
                                              verbose=False)
                    info_lines = [
                        f"Raw file: {os.path.basename(path)}",
                        f"Duration: {obj.times[-1]:.1f} s",
                        f"Sampling: {obj.info['sfreq']:.0f} Hz",
                        f"Channels: {len(obj.ch_names)}",
                        f"Channel names: {', '.join(obj.ch_names[:30])}"
                        + ("..." if len(obj.ch_names) > 30 else ""),
                    ]
                self._preview_fif_info.setPlainText("\n".join(info_lines))
            except Exception as e:
                self._preview_fif_info.setPlainText(
                    f"FIF file: {os.path.basename(path)}\n\n"
                    f"Could not read info: {e}")
            finally:
                # MNE's preload=False keeps the underlying file handle
                # open for lazy reads.  Clicking around the Output tab
                # would otherwise leak one handle per click and (on
                # Windows) prevent overwriting/deleting the FIF.  We
                # only need the metadata here; close before discarding.
                if obj is not None:
                    try:
                        obj.close()
                    except Exception:
                        pass
            self._preview_stack.setCurrentIndex(4)

        elif ext == ".db":
            self._preview_db_path = path
            try:
                import sqlite3
                with sqlite3.connect(path) as conn:
                    meta = dict(conn.execute(
                        "SELECT param, value FROM metadata"))
                ch_str = meta.get("channel_names", "")
                ch_list = [c for c in ch_str.split(",") if c]
                lines = [
                    f"MP Book: {os.path.basename(path)}",
                    f"Algorithm: {meta.get('algorithm', '?')}",
                    f"Channels ({meta.get('channel_count', '?')}): "
                    f"{', '.join(ch_list) if ch_list else '(unnamed)'}",
                    f"Segments: {meta.get('segment_count', '?')}",
                    f"Sampling: {meta.get('sampling_frequency_Hz', '?')} Hz",
                ]
                if meta.get("source_file"):
                    lines.append(f"Source: {meta['source_file']}")
                if meta.get("analysis_mode"):
                    lines.append(f"Mode: {meta['analysis_mode']}")
                if meta.get("version"):
                    lines.append(f"empi: {meta['version']}")
                self._preview_db_info.setPlainText("\n".join(lines))
                self._preview_db_viewer.setEnabled(True)
            except Exception as e:
                self._preview_db_info.setPlainText(
                    f"DB file: {os.path.basename(path)}\n\n"
                    f"Could not read metadata: {e}")
                self._preview_db_viewer.setEnabled(False)
            self._preview_stack.setCurrentIndex(5)

        elif ext == ".dat" and "___dipoles" in os.path.basename(path):
            try:
                with open(path) as f:
                    lines = f.readlines()
                n_dip = max(0, len(lines) - 1)
                self._preview_text.setPlainText(
                    f"Dipole positions: {n_dip} fitted dipoles\n"
                    f"Coordinates: MNI mm (surface RAS)\n\n"
                    f"These positions are shown on the brain\n"
                    f"cross-sections in the ___dipole_brain_*.png\n"
                    f"plots (axial / coronal / sagittal views).\n\n"
                    f"For interactive 3D exploration, click the\n"
                    f"[3D view] button below or double-click this\n"
                    f"file to open ConnectiVIS.")
            except Exception:
                self._preview_text.setPlainText(
                    os.path.basename(path))
            self._preview_stack.setCurrentIndex(2)

        elif ext == ".dat" and "connectivity" in path:
            fname = os.path.basename(path)
            # Filename: base___tag_label_method.dat
            after_sep = fname.split("___")[-1] if "___" in fname else fname
            parts = after_sep.replace(".dat", "").split("_")
            method = parts[-1] if parts else "?"
            method_names = {
                "dtf": "Directed Transfer Function",
                "gdtf": "Generalized DTF",
                "pdc": "Partial Directed Coherence",
                "gpdc": "Generalized PDC",
                "coh": "Coherence",
                "pcoh": "Partial Coherence",
                "ffpdc": "Full-frequency PDC",
                "ffdtf": "Full-frequency DTF",
            }
            label = method_names.get(method, method.upper())
            try:
                with open(path) as f:
                    header = []
                    for line in f:
                        if line.startswith(";"):
                            header.append(line.strip())
                        else:
                            break
                electrodes = ""
                for h in header:
                    if "electrodes" in h:
                        electrodes = h.split("=", 1)[1].strip()
                n_ch = len(electrodes.split()) if electrodes else "?"
                self._preview_text.setPlainText(
                    f"Connectivity: {label}\n"
                    f"Channels: {n_ch}\n"
                    f"Electrodes: {electrodes}\n\n"
                    f"Inter-electrode directed information flow\n"
                    f"matrix (frequency-averaged). Each row/column\n"
                    f"is one electrode; values represent the\n"
                    f"strength of directed influence.\n\n"
                    f"Double-click or click [3D view] to open in\n"
                    f"ConnectiVIS for interactive 3D visualization\n"
                    f"with arrows between electrodes.")
            except Exception:
                self._preview_text.setPlainText(fname)
            self._preview_stack.setCurrentIndex(2)

        elif ext in (".html", ".htm"):
            # QTextBrowser only renders HTML 3.2 + limited CSS, which
            # makes MNE's JS-heavy reports look broken — hand the file
            # off to the OS browser instead.
            self._preview_placeholder.setText(
                f"{os.path.basename(path)}\n\n"
                "Double-click to open in your default browser.")
            self._preview_stack.setCurrentIndex(0)

        else:
            # Unsupported format — show placeholder
            self._preview_placeholder.setText(
                f"No preview for {ext} files\n{os.path.basename(path)}")
            self._preview_stack.setCurrentIndex(0)

    def _fit_preview_image(self):
        """Scale the stored pixmap to fit the preview area."""
        pixmap = getattr(self, "_preview_pixmap", None)
        if pixmap is None or pixmap.isNull():
            return
        # Use the stacked widget's size as the available area
        avail = self._preview_stack.size()
        scaled = pixmap.scaled(
            avail.width() - 10, avail.height() - 10,
            Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._preview_image.setPixmap(scaled)

    def resizeEvent(self, event):
        """Re-scale preview image when window is resized."""
        super().resizeEvent(event)
        if (hasattr(self, "_preview_stack")
                and self._preview_stack.currentIndex() == 1):
            self._fit_preview_image()

    def _delete_selected_output(self):
        """Delete the selected file/directory in the output tree."""
        item = self._output_tree.currentItem()
        if not item:
            self._msg_info("No selection", "Select a file or folder to delete.")
            return
        path = self._output_item_path(item)
        if not path or not os.path.exists(path): return
        name = os.path.basename(path)
        if not self._msg_confirm("Confirm delete", f"Delete '{name}'?\n\n{path}"):
            return
        try:
            if os.path.isdir(path):
                import shutil; shutil.rmtree(path)
            else: os.remove(path)
            parent = item.parent()
            if parent: parent.removeChild(item)
            else: self._output_tree.takeTopLevelItem(self._output_tree.indexOfTopLevelItem(item))
            self._status.showMessage(f"Deleted: {name}", 5000)
        except Exception as e:
            self._msg_error("Error", f"Could not delete:\n{e}")

    def _auto_focus_latest_output(self):
        """Expand tree and select the first previewable result file."""
        tree = self._output_tree
        if tree.topLevelItemCount() == 0:
            return
        last = tree.topLevelItem(tree.topLevelItemCount() - 1)
        last.setExpanded(True)
        # Walk depth-first to find the first previewable file
        _preview_exts = {".png", ".jpg", ".csv", ".tag", ".txt", ".fif"}
        def _find_first_file(item):
            path = self._output_item_path(item)
            if os.path.isfile(path):
                ext = os.path.splitext(path)[1].lower()
                if ext in _preview_exts:
                    return item
            for i in range(item.childCount()):
                item.setExpanded(True)
                found = _find_first_file(item.child(i))
                if found:
                    return found
            return None
        target = _find_first_file(last)
        if target:
            tree.setCurrentItem(target)
            tree.scrollToItem(target)

    def _rescan_output_broader(self):
        """Search for IDE4EEG_OUT_* in parent directories too."""
        self._output_tree.clear()
        roots = set()
        candidates = [self._output_edit.text().strip(),
                       self._input_edit.text().strip()]
        browsed = getattr(self, "_last_browsed_output", "")
        if browsed:
            candidates.append(browsed)
        for p in candidates:
            if not p: continue
            d = p if os.path.isdir(p) else os.path.dirname(p)
            if d and os.path.isdir(d):
                roots.add(d)
                parent = os.path.dirname(d)
                if parent and os.path.isdir(parent): roots.add(parent)
        base = self._output_edit.text().strip()
        seen = set()
        for root in sorted(roots):
            try:
                for entry in sorted(os.listdir(root)):
                    full = os.path.join(root, entry)
                    nfull = os.path.normpath(full)
                    if entry.startswith(OUTPUT_DIR_PREFIX) and os.path.isdir(full):
                        if nfull in seen:
                            continue
                        seen.add(nfull)
                        label = os.path.relpath(full, base or root)
                        item = QTreeWidgetItem([label, ""])
                        item.setToolTip(0, full)
                        self._output_tree.addTopLevelItem(item)
                        self._populate_tree(item, full)
            except OSError: pass

    def _existing_top_level_paths(self):
        """Return set of absolute paths already shown as top-level items."""
        paths = set()
        for i in range(self._output_tree.topLevelItemCount()):
            tip = self._output_tree.topLevelItem(i).toolTip(0)
            if tip:
                paths.add(os.path.normpath(tip))
        return paths

    def _browse_output_folder(self):
        """Let the user pick any folder and show its results in the tree."""
        start = self._output_edit.text().strip() or os.path.expanduser("~")
        folder = QFileDialog.getExistingDirectory(
            self, "Open results folder", start)
        if not folder:
            return
        self._last_browsed_output = folder
        existing = self._existing_top_level_paths()
        norm = os.path.normpath(folder)
        basename = os.path.basename(folder)
        select = None  # item to highlight after insertion
        if basename.startswith(OUTPUT_DIR_PREFIX):
            # The folder itself is an IDE4EEG_OUT_* directory
            if norm not in existing:
                select = QTreeWidgetItem([basename, ""])
                select.setToolTip(0, folder)
                self._output_tree.insertTopLevelItem(0, select)
                self._populate_tree(select, folder)
                select.setExpanded(True)
            else:
                # Already in tree — find and select it
                select = self._find_top_item_by_path(norm)
        else:
            # Scan for IDE4EEG_OUT_* children (skip non-result files)
            added = 0
            try:
                for entry in sorted(os.listdir(folder)):
                    full = os.path.join(folder, entry)
                    if (entry.startswith(OUTPUT_DIR_PREFIX)
                            and os.path.isdir(full)
                            and os.path.normpath(full) not in existing):
                        item = QTreeWidgetItem([entry, ""])
                        item.setToolTip(0, full)
                        self._output_tree.insertTopLevelItem(added, item)
                        self._populate_tree(item, full)
                        item.setExpanded(True)
                        if select is None:
                            select = item
                        added += 1
            except OSError:
                pass
            if added == 0 and not any(
                    p.startswith(norm + os.sep) for p in existing):
                self._msg_info(
                    "No results found",
                    f"No IDE4EEG output folders found in:\n{folder}")
        if select is not None:
            self._output_tree.setCurrentItem(select)

    def _find_top_item_by_path(self, norm_path):
        """Return the top-level tree item whose tooltip matches *norm_path*."""
        for i in range(self._output_tree.topLevelItemCount()):
            item = self._output_tree.topLevelItem(i)
            if os.path.normpath(item.toolTip(0)) == norm_path:
                return item
        return None

    # Signal-file extensions Svarog can display natively.  Double-click
    # on these routes to Svarog when the jar is configured; otherwise
    # falls back to MNE (for .fif) or the OS default handler.
    _SVAROG_SIGNAL_EXTS = frozenset({
        ".fif", ".raw", ".edf", ".bdf", ".vhdr"})

    def _open_selected_output(self):
        """Open the selected output file with an appropriate viewer.

        Dispatch rules:
        - Signal files (``_SVAROG_SIGNAL_EXTS``): Svarog if a jar is
          configured, else MNE (for ``.fif``) or OS default.
        - ``-epo.fif`` / ``-ica.fif``: MNE-only serializations —
          always routed through ``_open_mne_raw`` (Svarog can't
          display these).
        - ``.db`` book: internal MP book viewer.
        - ``.dat``: ConnectiVIS.
        - Anything else: OS default handler.
        """
        item = self._output_tree.currentItem()
        if not item: return
        path = self._output_item_path(item)
        if not path or not os.path.isfile(path): return
        ext = os.path.splitext(path)[1].lower()
        lower = path.lower()
        # MNE-only FIF serializations (Epochs, ICA) bypass Svarog.
        is_mne_only_fif = (
            ext == ".fif" and
            ("-epo.fif" in lower or "-ica.fif" in lower))
        if not is_mne_only_fif and ext in self._SVAROG_SIGNAL_EXTS:
            prefer_mne = (hasattr(self, "_use_mne_viewer_check")
                          and self._use_mne_viewer_check.isChecked())
            jar = getattr(self, "_svarog_jar", None)
            if not prefer_mne and jar and os.path.isfile(jar):
                self._launch_svarog(path)
                return
            # No Svarog available (or user prefers MNE) — MNE can
            # handle .fif and routes other formats through read_file
            # in a subprocess; everything else falls through below.
            if ext == ".fif":
                self._open_mne_raw(path, title=os.path.basename(path))
                return
            if prefer_mne:
                self._open_signal_file_in_mne(
                    path, title=os.path.basename(path))
                return
        if ext == ".fif":
            # Reached only when is_mne_only_fif is True (Epochs / ICA).
            self._open_mne_raw(path, title=os.path.basename(path))
        elif ext == ".db":
            self._open_book_viewer(path)
        elif ext == ".dat":
            self._launch_connectivis([path])
        else:
            # Hand off to the OS default handler.  Windows doesn't have
            # a command-line opener equivalent to `open` / `xdg-open`;
            # `os.startfile` is the stdlib route and accepts any path
            # Explorer would handle (HTML in browser, PNG in photo
            # viewer, etc.).
            try:
                if sys.platform == "win32":
                    os.startfile(path)  # type: ignore[attr-defined]
                else:
                    opener = ("open" if sys.platform == "darwin"
                              else "xdg-open")
                    subprocess.Popen([opener, path])
            except Exception:
                self._msg_info("No viewer",
                                        f"No viewer configured for {ext}")

    @staticmethod
    def _channel_from_profile_tag(tag_path):
        """Extract channel name from a profile .tag filename.

        Profile tags are named ``{file_name}_profiles_{channel_name}.tag``.
        Returns the channel name, or ``None`` if the file doesn't match.
        """
        name = os.path.splitext(os.path.basename(tag_path))[0]
        idx = name.find("_profiles_")
        if idx >= 0:
            return name[idx + len("_profiles_"):]
        return None

    def _open_profile_tag_in_svarog(self, tag_path, book=None,
                                    channel=None, button=None):
        """Open a profile .tag file in SVAROG with associated book + channel.

        Shared by the Profiles tab 'View in SVAROG' button and the Output
        panel 'View in SVAROG' button, so both open Svarog identically.

        Parameters
        ----------
        tag_path : str
            Path to the ``*_profiles_<channel>.tag`` file.
        book : str or None
            Book path, if already known (e.g. from the Profiles panel).
            If None, discovered from ``_find_mmp_books()`` by filename
            prefix, with ``_find_book_near_tag`` as fallback.
        channel : str or None
            Channel name.  If None, extracted from the tag filename.
        """
        if channel is None:
            channel = self._channel_from_profile_tag(tag_path)

        if book is None:
            # Primary: match against the known-book pool (same set the
            # Profiles tab book panel uses).
            stem = os.path.splitext(os.path.basename(tag_path))[0]
            prefix = stem[:stem.find("_profiles_")] if "_profiles_" in stem else ""
            if prefix:
                for b in reversed(sorted(self._find_all_mp_books())):
                    if prefix in os.path.basename(b):
                        book = b
                        break
            # Fallback: walk the directory tree from the tag.
            if not book:
                book = self._find_book_near_tag(tag_path)

        # Use the same signal-finding logic as the Profiles tab.
        signal = self._find_signal_for_book(book) if book else None
        if not signal:
            signal = self._find_source_signal(tag_path)
        if not signal:
            self._msg_info("No signal",
                           "Could not find the original signal file.\n"
                           "Set an input signal in the Input tab.")
            return
        self._launch_svarog(signal, tag=tag_path, book=book or None,
                            channel=channel, book_signals="none",
                            button=button)

    @staticmethod
    def _find_book_near_tag(tag_path):
        """Find an MP book (.db) near a profile .tag file.

        Walks up from the tag's directory (up to 5 levels) looking for an
        ``mp_decomposition/`` directory — at each level checks:

        * ``{dir}/mp_decomposition/``  (tag and book at same level)
        * ``{dir}/preprocessing/mp_decomposition/``  (standard pipeline layout:
          tag lives in ``analysis/eeg_profiles/``, book in
          ``preprocessing/mp_decomposition/``, both under the same
          ``IDE4EEG_OUT_*`` root)

        Returns the alphabetically-last book path, or ``None``.
        """
        d = os.path.dirname(tag_path)
        for _ in range(5):
            for candidate in (
                os.path.join(d, "mp_decomposition"),
                os.path.join(d, "preprocessing", "mp_decomposition"),
            ):
                if os.path.isdir(candidate):
                    books = sorted(
                        f for f in os.listdir(candidate) if f.endswith(".db"))
                    if books:
                        return os.path.join(candidate, books[-1])
            parent = os.path.dirname(d)
            if not parent or parent == d:
                break
            d = parent
        return None

    def _view_output_in_mne(self):
        """Open the currently selected .fif file in MNE's interactive browser."""
        item = self._output_tree.currentItem()
        if not item:
            return
        path = self._output_item_path(item)
        if not path or not os.path.isfile(path):
            return
        if os.path.splitext(path)[1].lower() != ".fif":
            return
        self._open_mne_raw(path, title=os.path.basename(path))

    def _view_output_in_svarog(self):
        """Open the selected output file in SVAROG with the matching signal."""
        item = self._output_tree.currentItem()
        if not item:
            self._msg_info("No selection", "Select a file first.")
            return
        path = self._output_item_path(item)
        if not path or not os.path.isfile(path):
            self._msg_info("Not a file", "Select a file, not a directory.")
            return
        ext = os.path.splitext(path)[1].lower()

        # Signal files (.fif, .edf, etc.) → open directly as the signal
        # Non-signal files (.tag, .db) → find the original input signal
        tag = book = channel = None
        signal = None

        if ext in SIGNAL_EXTENSIONS:
            # User wants to see THIS file — open it as the signal
            signal = path
        elif ext == ".tag":
            # Profile tags: delegate to the shared helper (same logic as
            # the Profiles tab 'View in SVAROG' button).
            if self._channel_from_profile_tag(path):
                self._open_profile_tag_in_svarog(
                    path, button=self._output_svarog_btn)
                return
            tag = path
        elif ext == ".db":
            book = path

        # For non-profile .tag and .db, find the original signal
        if not signal:
            signal = self._find_source_signal(path)

        # Auto-discover a .tag in the same directory (for signal/book)
        if not tag:
            d = os.path.dirname(path)
            for f in os.listdir(d):
                if f.lower().endswith(".tag"):
                    tag = os.path.join(d, f)
                    break

        if not signal:
            self._msg_info("No signal",
                           "Could not find the original signal file.\n"
                           "Set an input signal in the Input tab.")
            return
        self._launch_svarog(signal, tag=tag, book=book, channel=channel,
                            button=self._output_svarog_btn)

    def _view_output_in_connectivis(self):
        """Open the selected .dat or dipoles .csv in ConnectiVIS 3D viewer."""
        item = self._output_tree.currentItem()
        if not item:
            self._msg_info("No selection",
                           "Select a .dat or dipoles .csv file first.")
            return
        path = self._output_item_path(item)
        if not path or not os.path.isfile(path):
            self._msg_info("Not a file", "Select a file, not a directory.")
            return
        self._launch_connectivis([path], button=self._output_3d_btn)

    def _view_all_output_in_connectivis(self):
        """Open ALL .dat/.csv results in one ConnectiVIS scene."""
        out = self._output_edit.text().strip()
        if not out or not os.path.isdir(out):
            self._msg_info("No output", "No output directory found.")
            return
        import glob
        files = []
        for sub in ("connectivity_analysis", "dipole_analysis",
                     "MNE/erp_dipole_fit"):
            for ext in ("*.dat", "*.csv"):
                pattern = os.path.join(out, "**", sub, ext)
                files.extend(sorted(
                    glob.glob(pattern, recursive=True)))
        # Filter out infrastructure files
        files = [f for f in files if "___electrodes" not in f]
        # Prefer CSV over DAT for dipoles when both exist
        csv_stems = {f.replace("___dipoles.csv", "")
                     for f in files if f.endswith("___dipoles.csv")}
        files = [f for f in files
                 if not (f.endswith("___dipoles.dat")
                         and f.replace("___dipoles.dat", "") in csv_stems)]
        if not files:
            self._msg_info(
                "No results",
                "No dipole or connectivity results found in the "
                "output directory.")
            return
        self._launch_connectivis(files, button=self._output_3d_all_btn)

    def _find_source_signal(self, output_path):
        """Find the original input signal for a file in an output directory.

        Walks up to the IDE4EEG_OUT_* dir, extracts the source name,
        and looks for a matching signal file next to it.  Falls back
        to the Input tab input path.
        """
        p = output_path
        while p and p != os.path.dirname(p):
            dirname = os.path.basename(p)
            if dirname.startswith(OUTPUT_DIR_PREFIX):
                src_name = dirname[len(OUTPUT_DIR_PREFIX):]
                parent = os.path.dirname(p)
                for f in sorted(os.listdir(parent)):
                    fp = os.path.join(parent, f)
                    if not os.path.isfile(fp):
                        continue
                    fn_base = f.lower().replace(".", "").replace("_", "")
                    src_clean = src_name.lower().replace(".", "").replace("_", "")
                    if (fn_base.startswith(src_clean)
                            and os.path.splitext(f)[1].lower()
                                in SIGNAL_EXTENSIONS):
                        return fp
                break
            p = os.path.dirname(p)
        # Fallback: Input tab
        inp = self._input_edit.text().strip()
        if inp and os.path.isfile(inp):
            return inp
        return None

    def _on_output_double_click(self, item, column):
        """Double-click in output tree: open files; directories expand natively."""
        path = self._output_item_path(item)
        if not path:
            return
        if os.path.isfile(path):
            self._open_selected_output()
        # Directories: let QTreeWidget handle expand/collapse natively

    # ── Tab 7: Help (lazy) ───────────────────────────────────────────

    def _build_help_tab(self):
        layout = QVBoxLayout(self._tab_help)
        splitter = QSplitter(Qt.Horizontal)

        # ── Left pane: TOC search + list ─────────────────────────────
        left = QWidget()
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(0, 0, 0, 0)
        left_lay.setSpacing(2)
        self._help_toc_search = QLineEdit()
        self._help_toc_search.setPlaceholderText("Filter TOC...")
        self._help_toc_search.setClearButtonEnabled(True)
        left_lay.addWidget(self._help_toc_search)
        self._help_toc = QListWidget()
        left_lay.addWidget(self._help_toc)
        left.setMaximumWidth(250)
        left.setMinimumWidth(140)
        splitter.addWidget(left)

        # ── Right pane: text search + browser ────────────────────────
        right = QWidget()
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(0, 0, 0, 0)
        right_lay.setSpacing(2)
        search_row = QHBoxLayout()
        search_row.setSpacing(4)
        self._help_text_search = QLineEdit()
        self._help_text_search.setPlaceholderText(
            "Search manual text...")
        self._help_text_search.setClearButtonEnabled(True)
        search_row.addWidget(self._help_text_search)
        self._help_search_prev = QPushButton("\u25b2")
        self._help_search_prev.setFixedWidth(28)
        self._help_search_prev.setToolTip("Previous match")
        search_row.addWidget(self._help_search_prev)
        self._help_search_next = QPushButton("\u25bc")
        self._help_search_next.setFixedWidth(28)
        self._help_search_next.setToolTip("Next match")
        search_row.addWidget(self._help_search_next)
        self._help_match_label = QLabel("")
        self._help_match_label.setStyleSheet("color: gray;")
        search_row.addWidget(self._help_match_label)
        right_lay.addLayout(search_row)
        self._help_browser = QTextBrowser()
        self._help_browser.setOpenExternalLinks(True)
        right_lay.addWidget(self._help_browser)
        splitter.addWidget(right)
        splitter.setSizes([200, 800])
        layout.addWidget(splitter)

        # ── Load HTML and populate TOC ───────────────────────────────
        html = self._generate_help_html()
        self._help_browser.setHtml(html)
        self._help_toc_entries = []  # [(title, anchor), ...]
        self._help_anchors = []
        for m in re.finditer(r'<h[12] id="([^"]+)">([^<]+)</h[12]>',
                             html):
            anchor, title = m.group(1), m.group(2)
            self._help_toc_entries.append((title, anchor))
            self._help_anchors.append(anchor)
            item = QListWidgetItem(title)
            item.setData(Qt.UserRole, anchor)
            self._help_toc.addItem(item)
        self._help_toc.currentRowChanged.connect(self._on_help_toc_click)

        # ── Wire search signals ──────────────────────────────────────
        self._help_toc_search.textChanged.connect(self._on_help_toc_filter)
        self._help_text_search.returnPressed.connect(
            lambda: self._on_help_text_find(forward=True))
        self._help_search_next.clicked.connect(
            lambda: self._on_help_text_find(forward=True))
        self._help_search_prev.clicked.connect(
            lambda: self._on_help_text_find(forward=False))
        self._help_text_search.textChanged.connect(
            self._on_help_text_changed)

    def _on_help_toc_click(self, row):
        """Scroll the help browser to the selected TOC entry."""
        # Map visible row back to the actual anchor
        item = self._help_toc.item(row)
        if item:
            anchor = item.data(Qt.UserRole)
            if anchor:
                self._help_browser.scrollToAnchor(anchor)
            elif 0 <= row < len(self._help_anchors):
                self._help_browser.scrollToAnchor(
                    self._help_anchors[row])

    def _on_help_toc_filter(self, text):
        """Filter TOC entries by search text."""
        needle = text.strip().lower()
        self._help_toc.clear()
        for title, anchor in self._help_toc_entries:
            if not needle or needle in title.lower():
                item = QListWidgetItem(title)
                item.setData(Qt.UserRole, anchor)
                self._help_toc.addItem(item)

    _HELP_SEARCH_MIN_WIDTH = 900

    def _on_help_text_changed(self, text):
        """Highlight all matches when search text changes."""
        self._help_highlight_all(text.strip())
        if text.strip():
            # Widen window if too narrow for reliable scroll-to-match
            if self.width() < self._HELP_SEARCH_MIN_WIDTH:
                self.resize(self._HELP_SEARCH_MIN_WIDTH, self.height())
            # Jump to first match
            cursor = self._help_browser.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            self._help_browser.setTextCursor(cursor)
            self._on_help_text_find(forward=True)
        else:
            self._help_match_label.setText("")

    def _help_highlight_all(self, text):
        """Highlight all occurrences of text with yellow background."""
        from PySide6.QtGui import QTextCharFormat
        extras = []
        if text:
            doc = self._help_browser.document()
            highlight_fmt = QTextCharFormat()
            highlight_fmt.setBackground(QColor("#ffff00"))
            highlight_fmt.setForeground(QColor("#000000"))
            cursor = QTextCursor(doc)
            while True:
                cursor = doc.find(text, cursor)
                if cursor.isNull():
                    break
                sel = QTextEdit.ExtraSelection()
                sel.cursor = cursor
                sel.format = highlight_fmt
                extras.append(sel)
        self._help_browser.setExtraSelections(extras)
        if text:
            n = len(extras)
            self._help_match_label.setText(
                f"{n} match{'es' if n != 1 else ''}" if n else
                "not found")

    def _on_help_text_find(self, forward=True):
        """Jump to next/previous match in the manual."""
        text = self._help_text_search.text().strip()
        if not text:
            return
        flags = QTextDocument.FindFlag(0)
        if not forward:
            flags |= QTextDocument.FindBackward
        found = self._help_browser.find(text, flags)
        if not found:
            # Wrap around
            cursor = self._help_browser.textCursor()
            if forward:
                cursor.movePosition(cursor.MoveOperation.Start)
            else:
                cursor.movePosition(cursor.MoveOperation.End)
            self._help_browser.setTextCursor(cursor)
            found = self._help_browser.find(text, flags)
        # Scroll viewport to the match — ensureCursorVisible() is
        # unreliable in QTextBrowser, so compute exact Y from the
        # block rect + line offset within the block, deferred to let
        # the document layout settle after find().
        if found:
            from PySide6.QtCore import QTimer
            def _scroll_to_match():
                cursor = self._help_browser.textCursor()
                block = cursor.block()
                doc_layout = self._help_browser.document().documentLayout()
                block_rect = doc_layout.blockBoundingRect(block)
                abs_y = block_rect.top()
                # Add line offset within the block for long paragraphs
                blk_layout = block.layout()
                if blk_layout:
                    line = blk_layout.lineForTextPosition(
                        cursor.positionInBlock())
                    if line.isValid():
                        abs_y += line.y()
                vbar = self._help_browser.verticalScrollBar()
                visible_h = self._help_browser.viewport().height()
                vbar.setValue(int(abs_y - visible_h // 3))
            QTimer.singleShot(0, _scroll_to_match)

    @staticmethod
    def _generate_help_html():
        """Convert USER_MANUAL.md to HTML, or return a fallback guide.

        Reads ``USER_MANUAL.md`` from the same directory as this script,
        converts Markdown to HTML (headings, bold, code, links, lists,
        tables, code blocks, horizontal rules), and wraps it in a
        stylesheet that works in both light and dark system themes.
        """
        import html as _html

        manual_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "USER_MANUAL.md")
        try:
            with open(manual_path, encoding="utf-8") as f:
                md = f.read()
        except FileNotFoundError:
            md = None

        if md is None:
            v = ide4eeg.__version__
            return (f'<html><body style="font-family:.AppleSystemUIFont,sans-serif;'
                f'max-width:800px;margin:0 auto;padding:16px;">'
                f'<h1>IDE4EEG {v}</h1><p><b>Integrated Development Environment '
                f'for EEG</b><br>University of Warsaw</p><hr>'
                f'<h2>Quick Start</h2><ol><li>Set the <b>Input signal</b> path.</li>'
                f'<li>Configure <b>Preprocessing</b>.</li><li>Enable <b>Analysis</b>.</li>'
                f'<li>Click <b>Run Pipeline</b>.</li><li>Browse <b>Output</b>.</li></ol>'
                f'<p><i>Manual not found at:</i><br>'
                f'<code>{_html.escape(manual_path)}</code></p></body></html>')

        css = ('body{font-family:.AppleSystemUIFont,Helvetica,sans-serif;'
            'max-width:900px;margin:20px auto;padding:0 20px;line-height:1.4}'
            'h1{border-bottom:2px solid;padding-bottom:4px;margin:20px 0 8px}'
            'h2{border-bottom:1px solid;padding-bottom:3px;margin:20px 0 6px}'
            'h3{margin:14px 0 4px}'
            'table{border-collapse:collapse;width:100%;margin:12px 0}'
            'th,td{border:1px solid;padding:6px 10px;text-align:left}'
            'code{padding:1px 4px;border-radius:3px}'
            'pre{padding:4px 10px;margin:4px 0;border-radius:3px;overflow-x:auto}'
            'pre code{padding:0}hr{border:none;border-top:1px solid;margin:14px 0}'
            'p{margin:4px 0}li{margin:2px 0}')

        out = [
            '<html><head><meta charset="utf-8">',
            '<style>', css, '</style>',
            '</head><body>',
        ]

        def _inl(text):
            text = _html.escape(text)
            text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", text)
            text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
            return re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)

        _anchor = IDE4EEG_Qt._heading_anchor
        # Bold field-header pattern (e.g. ``**GUI panel:** ...``) —
        # these are labeled metadata fields, each on its own source
        # line; treat as standalone paragraphs even when stacked
        # without blank-line separation, so the field-list visual
        # structure survives the prose-accumulation pass below.
        _field_re = re.compile(r"^\*\*[^*\n]+:\*\*")

        # Accumulate consecutive prose lines into a single ``<p>``.
        # Without this, hand-wrapped Markdown paragraphs render with a
        # hard break at every source line — the historical behavior
        # was one ``<p>`` per non-blank source line, which broke
        # paragraph flow whenever a contributor wrapped at 70 cols.
        prose_buf = []

        def _flush_prose():
            if prose_buf:
                out.append(f"<p>{_inl(' '.join(prose_buf))}</p>")
                prose_buf.clear()

        ic = it = il = False  # in_code, in_table, in_list
        for line in md.splitlines():
            if line.startswith("```"):
                _flush_prose()
                if ic: out.append("</code></pre>")
                else:
                    if it: out.append("</table>"); it = False
                    if il: out.append("</ul>"); il = False
                    out.append("<pre><code>")
                ic = not ic; continue
            if ic:
                if line.strip(): out.append(_html.escape(line))
                continue
            if line.lstrip().startswith("|"):
                _flush_prose()
                if il: out.append("</ul>"); il = False
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                if all(set(c.strip()) <= set("-: ") for c in cells): continue
                tag = "th" if not it else "td"
                if not it: it = True; out.append("<table>")
                out.append("<tr>" + "".join(f"<{tag}>{_inl(c)}</{tag}>" for c in cells) + "</tr>")
                continue
            if it: _flush_prose(); out.append("</table>"); it = False
            for lvl in (3, 2, 1):
                pfx = "#" * lvl + " "
                if line.startswith(pfx):
                    _flush_prose()
                    if il: out.append("</ul>"); il = False
                    h = line[lvl + 1:]
                    out.append(f'<h{lvl} id="{_anchor(h)}">{_html.escape(h)}</h{lvl}>')
                    break
            else:
                if line.strip() == "---":
                    _flush_prose()
                    if il: out.append("</ul>"); il = False
                    out.append("<hr>")
                elif line.strip() == "":
                    _flush_prose()
                    if il: out.append("</ul>"); il = False
                elif line.lstrip().startswith("- "):
                    _flush_prose()
                    if not il: out.append("<ul>"); il = True
                    out.append(f"<li>{_inl(line.lstrip()[2:])}</li>")
                elif re.match(r"^\d+\. ", line.lstrip()):
                    _flush_prose()
                    if not il: out.append("<ul>"); il = True
                    out.append(f"<li>{_inl(re.sub(r'^[0-9]+[.] ', '', line.lstrip()))}</li>")
                elif _field_re.match(line):
                    _flush_prose()
                    if il: out.append("</ul>"); il = False
                    out.append(f"<p>{_inl(line)}</p>")
                else:
                    if il:
                        _flush_prose()
                        out.append("</ul>"); il = False
                    prose_buf.append(line.strip())
        _flush_prose()
        if it: out.append("</table>")
        if il: out.append("</ul>")
        out.append("</body></html>")
        return "\n".join(out)

    # ── Constraints editor (feature 24) ─────────────────────────────

    def _build_constraints_section(self, parent_layout):
        """Build a collapsible constraints editor for step ordering rules."""
        grp = CollapsibleGroupBox("Constraints on relative ordering of preprocessing steps", collapsed=True)
        self._constraints_group = grp
        layout = QVBoxLayout(grp.contentWidget())
        for kind, label in [("hard", "Hard constraints (must):"),
                            ("soft", "Soft constraints (recommended):")]:
            lbl = QLabel(label); lbl.setStyleSheet("font-weight: bold;")
            layout.addWidget(lbl)
            w = QWidget(); vl = QVBoxLayout(w)
            vl.setContentsMargins(0, 0, 0, 0); vl.setSpacing(2)
            setattr(self, f"_{kind}_constraints_layout", vl)
            layout.addWidget(w)
            self._build_add_constraint_row(layout, kind)
        rb = QPushButton("Reset constraints to defaults"); rb.setFixedWidth(220)
        rb.clicked.connect(self._reset_constraints_defaults); layout.addWidget(rb)
        parent_layout.addWidget(grp)
        self._constraints_populated = False
        orig_expand = grp.expand
        def _deferred_expand():
            if not self._constraints_populated:
                self._constraints_populated = True; self._refresh_constraint_rows()
            orig_expand()
        grp.expand = _deferred_expand

    def _build_add_constraint_row(self, parent_layout, kind):
        """Add 'From -> To [Add]' row for creating a new constraint."""
        row = QHBoxLayout(); labels = sorted(_STEP_LABELS.values())
        fc = QComboBox(); fc.addItems([""] + labels); fc.setFixedWidth(160)
        tc = QComboBox(); tc.addItems([""] + labels); tc.setFixedWidth(160)
        ab = QPushButton("Add"); ab.setFixedWidth(50)
        ab.clicked.connect(lambda: self._add_constraint(kind, fc, tc))
        row.addWidget(fc); row.addWidget(QLabel("\u2192"))
        row.addWidget(tc); row.addWidget(ab); row.addStretch()
        parent_layout.addLayout(row)

    def _refresh_constraint_rows(self):
        """Rebuild constraint display from config_data."""
        preproc = self.config_data.get("preprocessing", {})
        for kind, cl in [("hard", self._hard_constraints_layout),
                         ("soft", self._soft_constraints_layout)]:
            while cl.count():
                it = cl.takeAt(0)
                if it.widget(): it.widget().deleteLater()
            constraints = preproc.get(f"{kind}_constraints", [])
            if not constraints:
                lbl = QLabel("(none)"); lbl.setStyleSheet("color: gray;")
                cl.addWidget(lbl)
            for i, pair in enumerate(constraints):
                if len(pair) < 2: continue
                la, lb = _STEP_LABELS.get(pair[0], pair[0]), _STEP_LABELS.get(pair[1], pair[1])
                row_w = QWidget(); rh = QHBoxLayout(row_w)
                rh.setContentsMargins(0, 0, 0, 0)
                rh.addWidget(QLabel(f"{la}  \u2192  {lb}")); rh.addStretch()
                db = QPushButton("\u00d7"); db.setFixedSize(24, 20)
                db.clicked.connect(lambda _=False, k=kind, idx=i: self._delete_constraint(k, idx))
                rh.addWidget(db); cl.addWidget(row_w)

    def _add_constraint(self, kind, from_combo, to_combo):
        """Add a new ordering constraint."""
        l2k = {v: k for k, v in _STEP_LABELS.items()}
        fl, tl = from_combo.currentText(), to_combo.currentText()
        if not fl or not tl: return
        if fl == tl:
            self._msg_warning("Invalid", "From and To must differ."); return
        ka, kb = l2k.get(fl), l2k.get(tl)
        if not ka or not kb: return
        clist = self.config_data.setdefault("preprocessing", {}).setdefault(
            f"{kind}_constraints", [])
        if [ka, kb] in clist:
            self._msg_info("Duplicate", "Already exists."); return
        clist.append([ka, kb])
        from_combo.setCurrentIndex(0); to_combo.setCurrentIndex(0)
        self._refresh_constraint_rows()

    def _delete_constraint(self, kind, index):
        clist = self.config_data.get("preprocessing", {}).get(f"{kind}_constraints", [])
        if 0 <= index < len(clist): clist.pop(index)
        self._refresh_constraint_rows()

    def _reset_constraints_defaults(self):
        preproc = self.config_data.setdefault("preprocessing", {})
        for k in ("hard_constraints", "soft_constraints"):
            preproc[k] = copy.deepcopy(DEFAULT_CONFIG["preprocessing"][k])
        self._refresh_constraint_rows()

    # ── Examples section ─────────────────────────────────────────────
    def _build_examples_buttons(self, parent_layout):
        """Build the examples buttons bar, pinned below the scroll area."""
        bar = QFrame()
        bar.setFrameShape(QFrame.NoFrame)
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(8, 4, 8, 4)
        self._ex_toggle = QPushButton("Show examples")
        self._ex_toggle.setFixedWidth(130)
        self._ex_toggle.clicked.connect(self._toggle_examples)
        bl.addWidget(self._ex_toggle)
        self._ex_action = QPushButton("Download examples")
        self._ex_action.setFixedWidth(180)
        self._ex_action.clicked.connect(self._download_examples)
        bl.addWidget(self._ex_action)
        self._ex_status = QLabel("")
        self._ex_status.setStyleSheet("color: gray;")
        bl.addWidget(self._ex_status)
        # MNE sample dataset button
        self._mne_sample_btn = QPushButton("Download MNE example (1.5 GB)")
        self._mne_sample_btn.setToolTip(
            "Download the MNE sample dataset — a single-subject\n"
            "auditory/visual EEG+MEG recording (59 EEG channels,\n"
            "600 Hz, 278 s, 4 conditions). Auto-configures the\n"
            "classical ERP analysis path: filter → epoch →\n"
            "butterfly / joint / topomap / GFP / cluster test.")
        self._mne_sample_btn.clicked.connect(self._download_mne_sample)
        self._signals.mne_sample_done.connect(self._on_mne_dl_done)
        mne_dir = os.path.expanduser("~/mne_data/MNE-sample-data")
        if os.path.isdir(mne_dir):
            self._mne_sample_btn.setText("Load MNE example")
        bl.addWidget(self._mne_sample_btn)
        bl.addStretch()
        parent_layout.addWidget(bar)
        self._ex_expanded = False
        self._refresh_examples()

    def _toggle_examples(self):
        self._ex_expanded = not self._ex_expanded; self._ex_body.setVisible(self._ex_expanded)
        self._ex_toggle.setText("Hide examples" if self._ex_expanded else "Show examples")

    def _examples_disk_size(self):
        from ide4eeg.download_examples import _EXAMPLES_DIR
        total = 0
        for dp, _, fns in os.walk(_EXAMPLES_DIR):
            for f in fns:
                try: total += os.path.getsize(os.path.join(dp, f))
                except OSError: pass
        return total

    def _refresh_examples(self):
        from ide4eeg.download_examples import find_examples
        examples = find_examples()
        any_dl = any(ok for _, _, ok in examples)
        while self._ex_body_lay.count():
            item = self._ex_body_lay.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        if not any_dl:
            self._ex_action.setText("Download examples")
            try: self._ex_action.clicked.disconnect()
            except RuntimeError: pass
            self._ex_action.clicked.connect(self._download_examples)
            self._ex_toggle.setEnabled(False)
            self._ex_status.setText("")
            return
        self._ex_toggle.setEnabled(True)
        mb = self._examples_disk_size() / 1_048_576
        self._ex_action.setText(f"Delete examples ({mb:.0f} MB)")
        try: self._ex_action.clicked.disconnect()
        except RuntimeError: pass
        self._ex_action.clicked.connect(self._delete_examples)
        # Re-add instruction text
        instr = QLabel(
            "Examples: Click [article] to read the paper, click on "
            "[Figure (\u2026)] to load respective data, explore the "
            "parameters and go to the Run tab to run the pipeline.")
        instr.setWordWrap(True)
        instr.setStyleSheet("color: gray; font-style: italic;")
        instr.setMinimumWidth(100)
        self._ex_body_lay.addWidget(instr)
        for d, m, ok in examples:
            if ok: self._build_example_panel(d, m)

    def _build_example_panel(self, ex_dir, meta):
        frame = QGroupBox("")
        fl = QVBoxLayout(frame)
        docs = meta.get("docs", [])

        # Build description with inline [Article] links
        inline = meta.get("inline_text", "")
        if not inline:
            # Auto-generate from reference
            ref_key = meta.get("reference", "")
            ref = None
            if ref_key:
                from ide4eeg.references import REFERENCES
                ref = REFERENCES.get(ref_key)
            if ref and docs:
                inline = ("Data from {0} <i>" + ref["title"]
                          + f"</i> ({ref['year']}):")
            else:
                inline = meta.get("description", "")

        # Replace {N} placeholders with clickable links
        import re as _re
        # Store doc paths for link handling
        doc_paths = {}
        html = inline
        for i, de in enumerate(docs):
            if "file" not in de:
                continue
            label = de.get("label", de["file"])
            link = f'<a href="doc:{i}" style="color: #4fc3f7; '  \
                   f'text-decoration: underline;">[{label}]</a>'
            html = html.replace(f"{{{i}}}", link)
            doc_paths[f"doc:{i}"] = os.path.join(ex_dir, de["file"])

        lbl = QLabel(html)
        lbl.setWordWrap(True)
        lbl.setTextFormat(Qt.RichText)
        lbl.setOpenExternalLinks(False)
        lbl.linkActivated.connect(
            lambda link: self._open_file(doc_paths.get(link, "")))
        fl.addWidget(lbl)
        # Config load buttons (wrapping flow layout)
        btns = []
        for ce in meta.get("configs", []):
            lbl = ce.get('label', ce['file']).replace('&', '&&')
            btn = QPushButton(lbl)
            btn.clicked.connect(lambda _=False, d=ex_dir, c=ce: self._load_example_config(d, c))
            btns.append(btn)
        if btns:
            brow = QHBoxLayout()
            brow.setContentsMargins(0, 0, 0, 0)
            for b in btns:
                brow.addWidget(b)
            brow.addStretch()
            fl.addLayout(brow)
        self._ex_body_lay.addWidget(frame)

    def _open_file(self, path):
        """Open a file with the system default application."""
        if not os.path.isfile(path):
            self._msg_error("Not found", f"File not found: {path}")
            return
        import subprocess, sys
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif sys.platform == "win32":
            os.startfile(path)
        else:
            subprocess.Popen(["xdg-open", path])

    def _load_example_config(self, ex_dir, cfg_entry):
        p = os.path.join(ex_dir, cfg_entry["file"])
        if not os.path.isfile(p):
            self._msg_error("Error", f"Config not found: {p}"); return
        self._load_config(p)
        root = os.path.dirname(os.path.abspath(__file__))
        # Resolve input path relative to repo root
        inp = self._input_edit.text()
        if inp and not os.path.isabs(inp):
            c = os.path.join(root, inp)
            if os.path.isfile(c): self._input_edit.setText(c)
        # Always set output to the example directory
        self._output_edit.setText(ex_dir)
        self._preproc_edit.setText("")
        self._analysis_edit.setText("")

    def _download_examples(self):
        self._ex_action.setEnabled(False); self._ex_status.setText("Downloading...")
        sig = self._signals
        try:
            sig.examples_dl_done.disconnect()
        except RuntimeError:
            pass
        sig.examples_dl_done.connect(self._on_ex_dl_done)
        def _fn():
            try:
                from ide4eeg.download_examples import download_examples
                download_examples(); r = True
            except Exception as e: r = str(e)
            sig.examples_dl_done.emit(r)
        threading.Thread(target=_fn, daemon=True).start()

    def _download_mne_sample(self):
        """Download MNE sample dataset (if needed) + load ERP config."""
        self._mne_sample_btn.setEnabled(False)
        self._mne_sample_btn.setText("Loading...")

        def _fn():
            try:
                import mne
                path = mne.datasets.sample.data_path(verbose=False)
                # Create a config for classical ERP analysis
                # (MNE tutorial standard: filter, epoch, average,
                # butterfly + joint + topomap + GFP + cluster test)
                raw_path = os.path.join(
                    str(path), "MEG", "sample",
                    "sample_audvis_raw.fif")
                subj_dir = os.path.join(
                    str(path), "subjects", "sample")
                cfg_path = os.path.join(
                    str(path), "config_eeg_erp.toml")
                cfg = (
                    "# MNE sample dataset — classical ERP analysis\n"
                    "# Auditory + visual evoked potentials, EEG only.\n"
                    "# Reproduces the standard MNE ERP tutorial path:\n"
                    "#   filter → epoch → baseline → reject → average\n"
                    "#   → butterfly / joint / topomap / GFP / cluster\n\n"
                    f'input_path = "{raw_path}"\n'
                    'output_path = ""\n\n'
                    'segmentation = { mode = "epochs" }\n'
                    'overwrite_output = true\n'
                    'electrodes_layout = "standard_1020"\n'
                    're_reference = "average"\n\n'
                    'prepare_eeg_artifacts = false\n'
                    'prepare_ica = false\n'
                    'prepare_video_artifacts = false\n'
                    'prepare_mp_filter = false\n'
                    'prepare_dipole_fitting = false\n'
                    'prepare_eeg_profiles = false\n'
                    'prepare_connectivity_analysis = false\n\n'
                    '# MNE catalog: classical ERP analyses\n'
                    'mne_catalog = [\n'
                    '    "erp_butterfly",\n'
                    '    "erp_joint",\n'
                    '    "erp_topomap",\n'
                    '    "gfp",\n'
                    '    "cluster_permutation",\n'
                    '    "erp_dipole_fit",\n'
                    ']\n\n'
                    '[dipole_fitting]\n'
                    f'fsaverage_dir = "{subj_dir}"\n\n'
                    '[filters]\n'
                    'method = "iir"\n'
                    'highpass_freq = 0.1\n'
                    'lowpass_freq = 40\n'
                    'notch_freq = 0\n\n'
                    '[epochs]\n'
                    'start_offset = -0.2\n'
                    'stop_offset = 0.5\n'
                    'epochs_baseline = [-0.2, 0]\n'
                    'check_epochs = false\n'
                    'reject_dict = { eeg = 150e-6 }\n\n'
                    '[epochs.tags]\n'
                    'selected = ["1", "2", "3", "4"]\n\n'
                    '[choosing_channels]\n'
                    'dropped_channels = []\n\n'
                    '[preprocessing]\n'
                    'step_order = ["trim", "montage", "filtering"]\n'
                )
                with open(cfg_path, "w") as f:
                    f.write(cfg)
                self._signals.mne_sample_done.emit(raw_path, cfg_path)
            except Exception as e:
                self._signals.mne_sample_done.emit("", str(e))

        threading.Thread(target=_fn, daemon=True).start()

    @Slot(str, str)
    def _on_mne_dl_done(self, raw_path, cfg_or_error):
        if raw_path:
            self._mne_sample_btn.setText("Load MNE example")
            self._mne_sample_btn.setEnabled(True)
            self._input_edit.setText(raw_path)
            self._load_config(cfg_or_error)
            self._status.showMessage(
                "MNE sample dataset loaded — ready to run", 5000)
        else:
            self._mne_sample_btn.setText("Download MNE example (1.5 GB)")
            self._mne_sample_btn.setEnabled(True)
            self._msg_error("Download failed", cfg_or_error)

    def _on_ex_dl_done(self, result):
        self._ex_action.setEnabled(True)
        if result is True:
            try:
                self._refresh_examples()
                if not self._ex_expanded:
                    self._toggle_examples()
                self._ex_status.setText("Done.")
            except Exception as e:
                logging.error("Example refresh failed: %s", e, exc_info=True)
                self._ex_status.setText(f"Downloaded, but display error: {e}")
        else:
            self._ex_status.setText(f"Error: {result}")

    def _delete_examples(self):
        from ide4eeg.download_examples import find_examples, _EXAMPLES_DIR
        mb = self._examples_disk_size() / 1_048_576
        if not self._msg_confirm("Delete Examples",
                f"Delete example files ({mb:.0f} MB) under:\n  {_EXAMPLES_DIR}\n\nProceed?"): return
        import shutil
        # Wipe everything inside each example directory EXCEPT
        # example.toml — that's the manifest find_examples() uses to
        # keep listing the example as "not downloaded" after a delete.
        # Don't skip incomplete installs: leftover configs (e.g.
        # config_*.toml) and stray output dirs from a partial run
        # should be cleaned up too.  Re-download reseeds everything
        # from the zip.
        for d, _m, _ok in find_examples():
            for it in os.listdir(d):
                if it == "example.toml":
                    continue
                ip = os.path.join(d, it)
                if os.path.isdir(ip) and not os.path.islink(ip):
                    shutil.rmtree(ip, ignore_errors=True)
                else:
                    try:
                        os.remove(ip)
                    except OSError:
                        pass
        self._ex_status.setText("Deleted."); self._refresh_examples()
        if self._ex_expanded: self._toggle_examples()

    # ── Config collect / load / save ─────────────────────────────────

    @staticmethod
    def _pn(s, default):
        """Parse a string as number; return *default* on failure."""
        try:
            s = str(s).strip()
            f = float(s)
            return int(f) if f == int(f) and "." not in s else f
        except (ValueError, TypeError, OverflowError):
            return default

    def _txt(self, d, key, default=""):
        """Get text from a QLineEdit stored in dict *d*."""
        w = d.get(key)
        return w.text().strip() if w else str(default)

    def _num(self, d, key, default=0):
        """Get a number from a QLineEdit stored in dict *d*."""
        return self._pn(self._txt(d, key, default), default)

    @staticmethod
    def _filter_cutoff_text(v):
        """Render a HP/LP cutoff for a QLineEdit.

        Falsy (0, None, "") => empty string: 0 means "filter off"
        in the pipeline, and the cleared field is the canonical UI
        for that.  Any non-zero value renders as ``str(v)``.  Used
        on both the panel-build write and the cfg-reload paths so
        save->reload preserves an empty field.
        """
        return "" if not v else str(v)

    def _chk(self, d, key, default=False):
        """Get checked state from a QCheckBox stored in dict *d*."""
        w = d.get(key)
        return w.isChecked() if w else default

    def _cmb(self, d, key, default=""):
        """Get current text from a QComboBox stored in dict *d*."""
        w = d.get(key)
        return w.currentText() if w else default

    def _trim_state(self):
        """Read the trim panel's live state.

        Returns ``(enabled, start, end_or_none)`` where *start* is a
        float (clamped at 0.0 on parse failure) and *end_or_none* is
        a float or ``None`` for "to end of signal".  The widgets are
        the canonical source — used by ``_collect_config``,
        ``_trimmed_input_for_svarog``, and the bad-channel review
        worker so they all interpret trim identically.
        """
        pp = getattr(self, "_pp", {}) or {}
        grp = pp.get("_trim_grp")
        enabled = grp.isChecked() if grp is not None else False
        try:
            start = max(0.0, float(self._txt(pp, "trim_start", "0") or "0"))
        except (TypeError, ValueError):
            start = 0.0
        te_str = self._txt(pp, "trim_end", "")
        end = None
        if te_str not in ("", None):
            try:
                end = float(te_str)
            except (TypeError, ValueError):
                end = None
        return enabled, start, end

    def _collect_config(self):
        """Build a config dict from current GUI state.

        Starts from *config_data* (last loaded config) so that keys from
        unbuilt lazy tabs are preserved.  Widget values override.
        """
        # Start from DEFAULT_CONFIG, then overlay loaded config so that
        # keys from unbuilt lazy tabs are preserved with their loaded values.
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        _deep_merge(cfg, self.config_data)
        pp = getattr(self, "_pp", {})
        an = getattr(self, "_an", {})

        # ── Input tab ───────────────────────────────────────────────────
        cfg["input_path"] = self._input_edit.text()
        cfg["output_path"] = self._output_edit.text()
        cfg["video_path"] = self._video_edit.text()
        cfg["preprocessing_output_path"] = self._preproc_edit.text()
        cfg["analysis_output_path"] = self._analysis_edit.text()
        if hasattr(self, "_mode_combo"):
            cfg.setdefault("segmentation", {})["mode"] = self._mode
        if hasattr(self, "_overwrite_check"):
            cfg["overwrite_output"] = self._overwrite_check.isChecked()
        if hasattr(self, "_use_mne_viewer_check"):
            cfg["use_mne_viewer"] = self._use_mne_viewer_check.isChecked()
        if hasattr(self, "_show_pyinfo_check"):
            cfg["show_pyinfo"] = self._show_pyinfo_check.isChecked()
        if hasattr(self, "_n_jobs_edit"):
            try:
                _n = int(self._n_jobs_edit.text().strip() or "0")
            except ValueError:
                _n = 0
            cfg.setdefault("parallelism", {})["n_jobs"] = max(1, _n) if _n > 0 else 0
        # Per-step save toggles via the _SAVE_CHECKBOX_MAP table.
        # matching_pursuit.save is forced True (book IS the output).
        _pp = getattr(self, "_pp", {})
        for widget_key, (section, _, _) in self._SAVE_CHECKBOX_MAP.items():
            # "filtering" is multi-instance (Phase 2): the per-id
            # save flag is written by the filters loop above into
            # cfg["filters"][<id>]["save"].  Skip the flat slot.
            if widget_key == "filtering":
                continue
            cfg.setdefault(section, {})["save"] = self._chk(
                _pp, f"save_{widget_key}")
        cfg.setdefault("matching_pursuit", {})["save"] = True

        if not pp:
            # Preproc tab not built — config_data already merged above.
            # Ensure critical derived keys are set.
            if "resample_freq" not in self.config_data:
                cfg["resample_freq"] = 0
            # Never prompt for interactive channel review in pipeline
            cfg.setdefault("choosing_channels", {})["check_final_channels"] = False
            # Don't add badchs_params if loaded config didn't have them
            if "badchs_params" not in self.config_data.get("choosing_channels", {}):
                cfg.get("choosing_channels", {}).pop("badchs_params", None)
                cfg.get("choosing_channels", {}).pop("correlation_window", None)
                cfg.get("choosing_channels", {}).pop("correlation_badch_threshold", None)
            # Preproc tab not built — skip to analysis section.
            # We must still read analysis tab widgets (if built) so that
            # GUI changes override loaded config values.
            return self._collect_config_analysis(cfg)

        # ── Preprocessing tab ─────────────────────────────────────────
        # Resample: positive number in the field = target Hz,
        # blank/0 = keep original rate.  No separate enable checkbox.
        rf = self._num(pp, "resample_freq", 0)
        cfg["resample_freq"] = rf if rf > 0 else 0

        # Trim
        trim_on = pp.get("_trim_grp")
        if trim_on and trim_on.isChecked():
            cfg["trim_start"] = self._num(pp, "trim_start", 0.0)
            te = self._txt(pp, "trim_end", "")
            cfg["trim_end"] = self._pn(te, "") if te else ""
        else:
            cfg["trim_start"] = 0.0
            cfg["trim_end"] = ""

        # Bad channels
        cfg["choosing_channels"]["choose_bad_channels"] = self._cmb(
            pp, "bad_mode", "auto")
        cfg.setdefault("bad_channels", {})["save_plots"] = self._chk(
            pp, "bch_save_plots")
        sel_panel = pp.get("sel_channel_panel")
        if sel_panel and sel_panel._checkboxes:
            all_names = [n for n, _ in sel_panel._checkboxes]
            selected = sel_panel.selected_channels()
            dropped = [n for n in all_names if n not in set(selected)]
            cfg["choosing_channels"]["dropped_channels"] = dropped
            cfg["choosing_channels"]["selected_channels"] = (
                "all" if len(selected) == len(all_names) else selected)
        else:
            cfg["choosing_channels"]["dropped_channels"] = []
            cfg["choosing_channels"]["selected_channels"] = "all"
        # Channel type overrides — stored in self.config_data by
        # _set_channel_type_override when the user edits them via
        # the SelectionPanel right-click menu or the review dialog.
        # Round-trip through TOML unchanged.
        cfg["choosing_channels"]["type_overrides"] = dict(
            self.config_data.get("choosing_channels", {}).get(
                "type_overrides", {}) or {})
        cfg["choosing_channels"]["check_final_channels"] = False
        cfg["choosing_channels"]["badchs_params"] = {}
        try:
            win = float(self._txt(pp, "slow_window", "1"))
        except (ValueError, TypeError):
            win = 1
        if self._chk(pp, "enable_slow", True):
            try:
                band = [float(x) for x in self._txt(pp, "slow_band").split(",")]
                thr = [int(float(x)) for x in self._txt(pp, "slow_thr").split(",")]
                if band and thr:
                    cfg["choosing_channels"]["badchs_params"]["slow_oscillations"] = [
                        win, band, "-", thr]
            except (ValueError, TypeError):
                pass
        if self._chk(pp, "enable_noise", True):
            try:
                band = [float(x) for x in self._txt(pp, "noise_band").split(",")]
                thr = [int(float(x)) for x in self._txt(pp, "noise_thr").split(",")]
                if band and thr:
                    cfg["choosing_channels"]["badchs_params"]["noise_power"] = [
                        win, band, "-", thr]
            except (ValueError, TypeError):
                pass
        if self._chk(pp, "enable_corr"):
            try:
                cw = [float(x) for x in self._txt(pp, "corr_window").split(",")]
                if len(cw) == 2:
                    cfg["choosing_channels"]["correlation_window"] = cw
                cfg["choosing_channels"]["correlation_badch_threshold"] = float(
                    self._txt(pp, "corr_thr", "0.95"))
            except (ValueError, TypeError):
                pass

        # Montage & reference — resolve aliases to MNE names
        _MONTAGE_TO_MNE = {
            "10-20": "standard_1020",
            "10-10": "standard_1005",
            "10-05": "standard_1005",
        }
        montage_raw = self._cmb(pp, "montage", NATIVE_POSITIONS_SENTINEL)
        cfg["electrodes_layout"] = _MONTAGE_TO_MNE.get(
            montage_raw, montage_raw)
        rr = self._txt(pp, "reref", "")
        if not rr or rr.lower() == "none":
            cfg["re_reference"] = []
        elif rr.lower() == "average":
            cfg["re_reference"] = "average"
        elif rr.lower() == "rest":
            cfg["re_reference"] = "REST"
        else:
            cfg["re_reference"] = [s.strip() for s in rr.split(",") if s.strip()]

        # Filtering — Phase 2 multi-block.  Schema is
        # ``cfg["filters"] = {id: {hp, lp, notch, method, ...}}``.
        # Iterate every panel registered in self._filter_widgets and
        # write one entry per filter id.
        cfg["filters"] = {}
        for fid, _ in getattr(self, "_filter_widgets", []):
            cfg["filters"][fid] = self._collect_filter_block_cfg(fid)

        # ICA (Phase 4)
        ica_grp = pp.get("_ica_grp")
        cfg["prepare_ica"] = ica_grp.isChecked() if ica_grp else False
        ica_cfg = cfg.setdefault("ICA_EOG", {})
        ica_cfg["method"] = self._cmb(pp, "ica_method", "picard")
        ica_cfg["selector"] = self._cmb(pp, "ica_selector", "iclabel")
        ica_cfg["fit_highpass_hz"] = self._num(pp, "ica_fit_hp", 1.0)
        ica_cfg["reject_uv"] = self._num(pp, "ica_reject", 500.0)
        eog_ch_raw = self._txt(pp, "ica_eog_ch", "Fp1, Fp2, Fpz")
        ica_cfg["find_bads_eog_ch"] = [
            c.strip() for c in eog_ch_raw.split(",") if c.strip()]
        # n_components: try int, then float, else keep as-is (e.g. "rank")
        nc_raw = str(self._txt(pp, "ica_n_components", "rank")).strip()
        try:
            ica_cfg["n_components"] = int(nc_raw)
        except ValueError:
            try:
                ica_cfg["n_components"] = float(nc_raw)
            except ValueError:
                ica_cfg["n_components"] = nc_raw or "rank"
        ica_cfg["decim"] = int(self._num(pp, "ica_decim", 1))
        ica_cfg["random_state"] = int(self._num(pp, "ica_random_state", 42))
        ica_cfg["iclabel_min_prob"] = self._num(pp, "ica_iclabel_min_prob", 0.0)
        ica_cfg["find_bads_ecg"] = self._chk(pp, "ica_find_bads_ecg")
        ica_cfg["find_bads_muscle"] = self._chk(pp, "ica_find_bads_muscle")
        ica_cfg["save_components_audit"] = self._chk(
            pp, "ica_save_components_audit")
        keep_checks = pp.get("iclabel_keep_checks", {})
        ica_cfg["iclabel_keep"] = [
            cls for cls, cb in keep_checks.items() if cb.isChecked()]

        # Artifacts
        art_grp = pp.get("_art_grp")
        cfg["prepare_eeg_artifacts"] = art_grp.isChecked() if art_grp else False
        cfg["artifacts"]["artifact_threshold"] = self._num(pp, "art_thr", 0.3)
        cfg["artifacts"]["save_plots"] = self._chk(pp, "art_save_plots")
        cfg["artifacts"]["save_tag"] = self._chk(pp, "art_save_tag")
        rp = {}
        rp["SlopeWindow"] = self._num(pp, "slope_win", 0.0704)
        rp["SlopesAbsThr"] = self._num(pp, "slope_abs", 150)
        rp["SlopesStdThr"] = self._num(pp, "slope_std", 7)
        rp["SlopesMedThr"] = self._num(pp, "slope_med", 6)
        rp["OutliersMergeWin"] = self._num(pp, "out_merge", 0.1)
        rp["OutliersAbsThr"] = self._num(pp, "out_abs", 150)
        rp["OutliersStdThr"] = self._num(pp, "out_std", 7)
        rp["OutliersMedThr"] = self._num(pp, "out_med", 13)
        rp["MusclesWindow"] = self._num(pp, "musc_win", 0.5)
        rp["MusclesAbsThr"] = self._num(pp, "musc_abs", 0.15)
        rp["MusclesStdThr"] = self._num(pp, "musc_std", 7)
        rp["MusclesMedThr"] = self._num(pp, "musc_med", 5)
        try:
            mfr = [float(x) for x in self._txt(pp, "musc_freq", "40, 90").split(",")]
            rp["MusclesFreqRange"] = mfr if len(mfr) == 2 else [40, 90]
        except (ValueError, TypeError):
            rp["MusclesFreqRange"] = [40, 90]
        cfg["artifacts"]["rejection_parameters"] = rp
        cfg["artifacts"]["enable_slopes"] = self._chk(pp, "en_slopes", True)
        cfg["artifacts"]["enable_outliers"] = self._chk(pp, "en_outliers", True)
        cfg["artifacts"]["enable_muscles"] = self._chk(pp, "en_muscles", True)
        cfg["artifacts"]["enable_amplitude"] = self._chk(pp, "en_amp", True)
        cfg["amplitude_max_threshold"] = self._num(pp, "amp_max", 150) * 1e-6
        cfg["amplitude_time_threshold"] = self._num(pp, "amp_time", 0.1)
        cfg["amplitude_nchan_threshold"] = self._num(pp, "amp_nchan", 0.5)

        # Segment rejection
        seg_grp = pp.get("_seg_grp")
        sr = cfg.setdefault("segment_rejection", {})
        sr["enabled"] = seg_grp.isChecked() if seg_grp else False
        sr["reject_threshold"] = self._num(pp, "seg_reject", 0)
        sr["flat_threshold"] = self._num(pp, "seg_flat", 0)
        sr["auto_percentile"] = self._num(pp, "seg_pct", 95.0)

        # MP decomposition: enable state lives in preprocessing.step_order
        # (built below from self._step_widgets).  No top-level flag.
        mp = cfg.setdefault("matching_pursuit", {})
        mp["iterations"] = self._num(pp, "mp_iter", 30)
        # Widget is percent-only (validator clamps to [0, 100]); cfg
        # stores the explained-energy fraction.  ``0.01`` floor keeps
        # empi happy (it rejects ``-r >= 1.0``).
        pct = self._num(pp, "mp_energy", 95)
        mp["explained_energy"] = max(0.01, min(pct / 100, 1.0))
        mp["energy_error"] = mp.get("energy_error", 0.01)
        mp["algorithm"] = parse_mp_algorithm_label(
            self._cmb(pp, "mp_algo", "smp"))
        # cpu_workers semantics on save:
        #   empty field or "0" → save 0 (inherit from parallelism.n_jobs)
        #   N > 0              → save N (explicit override)
        # The resolution happens at pipeline run time in _build_empi_cmd.
        _raw_mpw = pp["mp_workers"].text().strip() if pp.get("mp_workers") else ""
        try:
            _mpw = int(_raw_mpw) if _raw_mpw else 0
        except ValueError:
            _mpw = 0
        mp["cpu_workers"] = max(0, _mpw)
        mp["optimization"] = mp.get("optimization", "global")
        mp["include_delta"] = mp.get("include_delta", True)
        mp["full_atoms_in_signal"] = mp.get("full_atoms_in_signal", False)
        # Feature 9: wire EMPI path from Config tab
        empi = getattr(self, "_empi_edit", None)
        if empi and empi.text().strip():
            mp["empi_path"] = empi.text().strip()
        else:
            mp["empi_path"] = self.config_data.get(
                "matching_pursuit", {}).get("empi_path", "")
        mp["outputs"] = {
            "atom_stats_csv": self._chk(pp, "mp_csv"),
            "atom_histograms": self._chk(pp, "mp_hist"),
        }
        mp_panel = pp.get("mp_channels")
        if mp_panel and mp_panel._checkboxes:
            mp["channels"] = mp_panel.selected_channels()

        # MP filter
        mpf_grp = pp.get("_mpf_grp")
        cfg["prepare_mp_filter"] = mpf_grp.isChecked() if mpf_grp else False
        flt = mp.setdefault("filter", {})
        flt["mode"] = self._cmb(pp, "mpf_mode", "remove")
        _mat = pp.get("mpf_atom_table")
        if _mat:
            flt.update(_mat.collect_single())
        flt["time_min"] = self._num(pp, "mpf_tmin", 0)
        flt["time_max"] = self._num(pp, "mpf_tmax", 0)
        flt["min_energy"] = self._num(pp, "mpf_energy", 0)

        # Gaze / video artifacts
        gaze_grp = pp.get("_gaze_grp")
        cfg["prepare_video_artifacts"] = gaze_grp.isChecked() if gaze_grp else False
        cfg.setdefault("gaze", {})["save_tag"] = self._chk(
            pp, "gaze_save_tag")
        cfg["video_reference_dir"] = self._txt(pp, "ref_dir")
        cfg["video_exclude_dir"] = self._txt(pp, "excl_dir")
        cfg["facetag_face_tolerance"] = self._num(pp, "face_tol", 0.6)
        cfg["facetag_det_size"] = int(self._num(pp, "det_size", 0))
        cfg["facetag_tracking_adapt_rate"] = self._num(pp, "adapt", 0.5)
        cfg["facetag_position_weight"] = self._num(pp, "pos_w", 0.4)
        cfg["facetag_size_weight"] = self._num(pp, "size_w", 0.2)
        cfg["facetag_switch_resistance"] = self._num(pp, "switch_r", 0.25)
        cfg["facetag_gaze_method"] = self._cmb(pp, "gaze_method", "l2cs")
        cfg["facetag_max_angle"] = self._num(pp, "max_angle", 20.0)
        cfg["facetag_gaze_smoothing"] = self._num(pp, "gaze_smooth", 0.0)
        cfg["facetag_ref_use_roi"] = self._chk(pp, "ref_roi")
        cfg["facetag_frame_skip"] = self._num(pp, "frame_skip", 3)
        cfg["facetag_detection_skip"] = int(self._num(pp, "det_skip", 3))
        cfg["facetag_downscale"] = self._num(pp, "downscale", 1.0)
        cfg["facetag_min_interval"] = self._num(pp, "min_iv", 0.0)
        cfg["facetag_no_face_is_artifact"] = self._chk(pp, "no_face", True)

        # Rest / Epochs
        cfg["rest"]["rest_duration"] = [
            self._num(pp, "rest_dur_start", 0),
            self._pn(self._txt(pp, "rest_dur_end", ""), ""),
        ]
        whole = self._chk(pp, "rest_whole")
        cfg["rest"]["whole_signal"] = whole
        cfg["rest"]["window_length"] = self._num(pp, "rest_window", 20)
        # Unified GUI flag drives both per-mode config keys — only
        # the one matching segmentation.mode fires at runtime.
        _review = self._chk(pp, "check_segments", True)
        cfg["rest"]["check_rest"] = _review
        cfg["epochs"]["start_offset"] = self._num(pp, "ep_start", -0.3)
        cfg["epochs"]["stop_offset"] = self._num(pp, "ep_stop", 0.7)
        eb = self._cmb(pp, "ep_baseline", "None")
        _bl_to_cfg = {"(None, 0)": [None, 0], "(start, 0)": [None, 0], "(0, stop)": [0, None]}
        if eb == "Custom":
            cfg["epochs"]["epochs_baseline"] = [
                self._parse_optional_float(
                    self._txt(pp, "ep_baseline_start", "")),
                self._parse_optional_float(
                    self._txt(pp, "ep_baseline_end", "")),
            ]
        else:
            cfg["epochs"]["epochs_baseline"] = _bl_to_cfg.get(eb, eb)
        cfg["epochs"]["check_epochs"] = _review
        panel = pp.get("ev_panel")
        if panel and panel._checkboxes:
            # Panel populated — use exactly what the user checked
            cfg["epochs"]["tags"] = {"selected": self._get_selected_events()}
        else:
            # No file loaded — preserve loaded config for CLI/TOML compat
            loaded_tags = self.config_data.get("epochs", {}).get("tags", {})
            cfg["epochs"]["tags"] = dict(loaded_tags) if loaded_tags else {"selected": []}

        # Preprocessing step order — only include checked steps.
        # Multi-instance keys ("filtering:<id>") are pushed through
        # to the pipeline as id-tagged step_order tokens.
        preproc = cfg.setdefault("preprocessing", {})
        if self._step_widgets:
            order = []
            for key, widget in self._step_widgets:
                if not widget.isChecked():
                    continue
                base, _, sid = key.partition(":")
                raw_names = (self._GUI_TO_PIPELINE_STEPS.get(key)
                             or self._GUI_TO_PIPELINE_STEPS.get(base, []))
                for pname in raw_names:
                    # Reattach the id when the pipeline name matches
                    # the GUI base — keeps multiple filter instances
                    # as distinct entries.
                    if sid and pname == base:
                        pname = f"{pname}:{sid}"
                    # "resample" only if a positive target rate is set
                    # (blank/0 in the field = keep original rate).
                    if pname == "resample" and cfg.get("resample_freq", 0) <= 0:
                        continue
                    if pname not in order:
                        order.append(pname)
            preproc["step_order"] = order

        if hasattr(self, "_allow_reorder_check"):
            preproc["allow_reorder"] = (
                self._allow_reorder_check.isChecked())

        # Preserve hard/soft constraints from loaded config
        if "preprocessing" in self.config_data:
            src = self.config_data["preprocessing"]
            if "hard_constraints" in src:
                preproc["hard_constraints"] = src["hard_constraints"]
            if "soft_constraints" in src:
                preproc["soft_constraints"] = src["soft_constraints"]

        return self._collect_config_analysis(cfg)

    def _collect_config_analysis(self, cfg):
        """Collect analysis tab widget values into *cfg*."""
        an = getattr(self, "_an", {})
        if not an:
            return cfg  # analysis tab not built yet

        # Connectivity
        conn_grp = an.get("_conn_grp")
        cfg["prepare_connectivity_analysis"] = conn_grp.isChecked() if conn_grp else False
        c = cfg.setdefault("connectivity", {})
        conn_meths = an.get("_conn_methods", {})
        c["methods"] = [k for k, cb in conn_meths.items() if cb.isChecked()]
        _mvar_to_code = {"Yule-Walker": "yw", "Nuttall-Strand": "ns",
                         "Vieira-Morf": "vm"}
        mvar_raw = self._cmb(an, "conn_mvar", "Yule-Walker")
        c["mvar_method"] = _mvar_to_code.get(mvar_raw, mvar_raw)
        c["mvar_order"] = self._num(an, "conn_order", 0)
        c["resolution"] = self._num(an, "conn_res", 100)
        c["short_time"] = self._chk(an, "conn_st")
        c["st_window"] = self._num(an, "conn_st_win", 0)
        c["st_overlap"] = self._num(an, "conn_st_ovl", 0)
        c["significance"] = self._chk(an, "conn_sig")
        c["sig_reps"] = self._num(an, "conn_sig_reps", 100)
        c["sig_alpha"] = self._num(an, "conn_sig_alpha", 0.05)
        conn_panel = an.get("conn_channels")
        if conn_panel and conn_panel._checkboxes:
            sel = conn_panel.selected_channels()
            if len(sel) == len(conn_panel._checkboxes):
                c["channels"] = "all"
            else:
                c["channels"] = sel
        else:
            c["channels"] = "all"

        # Dipole
        dip_grp = an.get("_dip_grp")
        cfg["prepare_dipole_fitting"] = dip_grp.isChecked() if dip_grp else False
        d = cfg.setdefault("dipole_fitting", {})
        d["ref_channel"] = self._cmb(an, "dip_ref", "average")
        d["montage"] = self._cmb(an, "dip_montage", "standard_1005")
        d["max_iterations"] = self._num(an, "dip_maxit", 0)
        d["min_gof"] = self._num(an, "dip_gof", 0)
        # Read atom filter from AtomFilterTable
        _dat = an.get("dip_atom_table")
        if _dat:
            d.update(_dat.collect_single())
        d["dot_size"] = int(self._num(an, "dip_dot", 0))
        d["cortical_distance"] = self._chk(an, "dip_cortical")
        d["fsaverage_dir"] = self._txt(an, "dip_fsavg", "")
        # cpu_workers: empty/0 = inherit from parallelism.n_jobs
        _raw_dw = self._an.get("dip_workers")
        _dw_text = _raw_dw.text().strip() if _raw_dw else ""
        try:
            _dw = int(_dw_text) if _dw_text else 0
        except ValueError:
            _dw = 0
        d["cpu_workers"] = max(0, _dw)
        dip_panel = an.get("dip_channels")
        if dip_panel and dip_panel._checkboxes:
            ignored = [n for n, cb in dip_panel._checkboxes
                       if not cb.isChecked()]
            d["ignored_channels"] = ",".join(ignored) if ignored else ""
        else:
            d["ignored_channels"] = ""
        picked = an.get("dip_picked_atoms", [])
        if picked:
            d["_picked_atoms"] = picked
        bp = an.get("dip_book_panel")
        if bp:
            book = bp.selected_book()
            if book:
                cfg["_mp_book_path"] = book

        # EEG Profiles
        prof_grp = an.get("_prof_grp")
        cfg["prepare_eeg_profiles"] = prof_grp.isChecked() if prof_grp else False
        ep = cfg.setdefault("eeg_profiles", {})
        _pat = an.get("prof_atom_table")
        ep["structures"] = _pat.collect() if _pat else []
        bp = an.get("prof_book_panel")
        if bp:
            book = bp.selected_book()
            if book:
                cfg["_mp_book_path"] = book
            ch = bp.selected_channel()
            if ch:
                ep["channel"] = ch
        auto_cb = an.get("prof_auto_svarog")
        ep["auto_open_svarog"] = bool(auto_cb.isChecked()) if auto_cb else False

        # EEG Profiles mode (backward compat)
        cfg.setdefault("eeg_profiles", {})["mode"] = "count"

        # MNE catalog selections + params + advanced-disclosure state
        cfg["mne_catalog"] = self._collect_mne_selections()
        cfg["mne_params"] = self._collect_mne_params()
        cfg["mne_advanced_open"] = self._collect_mne_advanced_open()

        return cfg

    # ── Populate widgets from config ─────────────────────────────────

    def _set_edit(self, d, key, value):
        w = d.get(key)
        if w and isinstance(w, QLineEdit):
            # Avoid floating-point display artifacts like "150.00000000000003"
            try:
                if isinstance(value, float) and value == int(value):
                    value = int(value)
            except (OverflowError, ValueError):
                pass
            w.setText(str(value))

    def _set_combo(self, d, key, value):
        w = d.get(key)
        if w and isinstance(w, QComboBox): w.setCurrentText(str(value))

    def _set_check(self, d, key, value):
        w = d.get(key)
        if w and hasattr(w, "setChecked"): w.setChecked(bool(value))

    def _set_grp(self, d, key, value):
        w = d.get(key)
        if w and hasattr(w, 'isCheckable') and w.isCheckable(): w.setChecked(bool(value))

    #: Boilerplate appended to every ⚠ tooltip — explains why a
    #: configured-but-unattended interactive review breaks batch runs.
    _BATCH_HANG_WARNING = (
        "In CLI / exported-script runs there is no GUI to\n"
        "drive it — the run will hang.")

    def _refresh_review_badges(self):
        """Sync the ⚙ / ⚠ status badges on each preprocessing step.

        ⚙ — step writes auxiliary outputs alongside the signal
        snapshot (plots, audit files, JSON).  Visible only when the
        step's "save extras" toggle is on.

        ⚠ — step is configured to open an interactive review window.
        Pauses the GUI run; **hangs or crashes a CLI / exported-script
        run** because the worker thread can't drive a Qt window.

        Idempotent — recomputes from current widget state, so it can
        be called from any toggle handler or after a config reload.
        """
        pp = getattr(self, "_pp", None) or {}
        warn = self._BATCH_HANG_WARNING

        # ── bad_channels ───────────────────────────────────────────
        bad_grp = pp.get("_bad_grp")
        if bad_grp is not None:
            sp = pp.get("bch_save_plots")
            extras_on = bool(sp.isChecked()) if sp else False
            bad_grp.set_extras_badge(
                extras_on,
                "Bad-channel detection plots will be saved\n"
                "(bad_channels.save_plots). The 🗄️ snapshot icon\n"
                "to the left controls the cleaned-signal save\n"
                "separately.")
            bm = pp.get("bad_mode")
            mode = bm.currentText() if bm else "auto"
            manual_on = mode in ("manual", "both")
            bad_grp.set_manual_badge(
                manual_on,
                "Bad-channel review will open an interactive\n"
                f"window (signal.plot, blocking).\n{warn}\n"
                "Set Mode=auto before exporting.")

        # ── ICA_EOG ────────────────────────────────────────────────
        ica_grp = pp.get("_ica_grp")
        if ica_grp is not None:
            ic = pp.get("ica_save_components_audit")
            extras_on = bool(ic.isChecked()) if ic else False
            ica_grp.set_extras_badge(
                extras_on,
                "ICA component audit will be written\n"
                "(topomap PNGs, classification CSV, ica.fif,\n"
                "mne.Report HTML).  Controlled by\n"
                "ICA_EOG.save_components_audit.")
            sel = pp.get("ica_selector")
            mode = sel.currentText() if sel else "iclabel"
            manual_on = mode in ("manual", "both")
            ica_grp.set_manual_badge(
                manual_on,
                "ICA component review will open an interactive\n"
                f"window (ica.plot_sources, blocking).\n{warn}\n"
                "Set Selector=iclabel/find_bads before exporting.")

        # ── filtering (per-filter; one panel per block) ────────────
        for fid, fgrp in getattr(self, "_filter_widgets", []) or []:
            sf = pp.get(f"save_filt_{fid}")
            extras_on = bool(sf.isChecked()) if sf else False
            fgrp.set_extras_badge(
                extras_on,
                "Filter response plots will be saved\n"
                "(filters[*].plot_filt). The 🗄️ snapshot icon\n"
                "to the left controls the filtered-signal save\n"
                "separately.")
            # Filtering has no manual review.
            fgrp.set_manual_badge(False)

        # ── artifacts ──────────────────────────────────────────────
        art_grp = pp.get("_art_grp")
        if art_grp is not None:
            ap = pp.get("art_save_plots")
            at = pp.get("art_save_tag")
            plots_on = bool(ap.isChecked()) if ap else False
            tag_on = bool(at.isChecked()) if at else False
            extras_on = plots_on or tag_on
            extras_msg_bits = []
            if plots_on:
                extras_msg_bits.append("plots (artifacts.save_plots)")
            if tag_on:
                extras_msg_bits.append("Svarog .tag (artifacts.save_tag)")
            art_grp.set_extras_badge(
                extras_on,
                "Will be saved: " + " + ".join(extras_msg_bits) + "."
                if extras_msg_bits else "")
            # No manual review for artifacts — leave ⚠ off.
            art_grp.set_manual_badge(False)

        # ── Drop Segments ──────────────────────────────────────────
        seg_grp = pp.get("_seg_grp")
        if seg_grp is not None:
            cs = pp.get("check_segments")
            review_on = bool(cs.isChecked()) if cs else False
            seg_grp.set_manual_badge(
                review_on,
                "Segment review will open an interactive window\n"
                "(Svarog when supported, MNE epochs.plot otherwise).\n"
                f"{warn}\n"
                "Uncheck \"Review segments manually\" before exporting.")

    def _populate_vars(self, cfg):
        """Push values from *cfg* into all Qt widgets."""
        pp = getattr(self, "_pp", {}); an = getattr(self, "_an", {})
        # ── Input tab (always built) ────────────────────────────────────
        # Only overwrite Input-tab fields if cfg provides a value;
        # never blank out a field the user already filled via Browse.
        inp = cfg.get("input_path", "")
        if inp:
            self._input_edit.setText(inp)
        for k, w in [("output_path", self._output_edit), ("video_path", self._video_edit),
                      ("preprocessing_output_path", self._preproc_edit),
                      ("analysis_output_path", self._analysis_edit)]:
            v = cfg.get(k, "")
            # "None" is a documented sentinel for "derive from input"
            # (see main.py:392). Don't push it into the GUI, or
            # _auto_fill_output_paths builds "None/IDE4EEG_OUT_.../..."
            # paths on top of it.
            if v and v != "None": w.setText(v)
        self._auto_fill_output_paths(
            inp or self._input_edit.text().strip())
        # Auto-detect companion video if not set
        if not self._video_edit.text().strip():
            video = self._find_video_for_input(cfg.get("input_path", ""))
            if video:
                self._video_edit.setText(video)
        if hasattr(self, "_mode_combo"):
            _m = get_segmentation_mode(cfg)
            self._mode_combo.setCurrentText(
                self._MODE_DISPLAY.get(_m, _m))
        if hasattr(self, "_overwrite_check"):
            self._overwrite_check.setChecked(
                cfg.get("overwrite_output", False))
        if hasattr(self, "_allow_reorder_check"):
            self._allow_reorder_check.setChecked(
                cfg.get("preprocessing", {}).get("allow_reorder", False))
        if hasattr(self, "_n_jobs_edit"):
            _nj_raw = cfg.get("parallelism", {}).get("n_jobs", 0)
            self._n_jobs_edit.setText(
                str(self._resolve_n_jobs_value(_nj_raw)))
            self._update_n_jobs_readout()
        empi = cfg.get("matching_pursuit", {}).get("empi_path", "")
        if empi and hasattr(self, "_empi_edit"):
            self._empi_edit.setText(empi); self._empi_path = empi
        if not pp: return
        # ── Preprocessing ─────────────────────────────────────────────
        cc = cfg.get("choosing_channels", {}); filt = cfg.get("filters", {})
        art = cfg.get("artifacts", {}); rp = art.get("rejection_parameters", {})
        rest = cfg.get("rest", {}); ep = cfg.get("epochs", {})
        mp = cfg.get("matching_pursuit", {}); mp_flt = mp.get("filter", {})
        sr = cfg.get("segment_rejection", {}); bcp = cc.get("badchs_params", {})
        # Resample: field-only, blank/0 means "keep original rate".
        rf = cfg.get("resample_freq", 0)
        self._set_edit(pp, "resample_freq", str(rf) if rf else "")
        # Trim
        self._set_grp(pp, "_trim_grp", bool(cfg.get("trim_start", 0)))
        self._set_edit(pp, "trim_start", cfg.get("trim_start", 0.0))
        te = cfg.get("trim_end"); self._set_edit(pp, "trim_end", te if te is not None else "")
        # Drop channels — apply to panel when signal is loaded
        # (stored in config_data, applied in _on_signal_info_ready)
        # Channel type overrides — copy into config_data so they're
        # picked up by _on_signal_info_ready the next time a file is
        # loaded. If a file is already loaded, also re-refresh the
        # cached types + panels so the override takes immediate effect.
        loaded_overrides = cc.get("type_overrides", {}) or {}
        self.config_data.setdefault(
            "choosing_channels", {})["type_overrides"] = dict(loaded_overrides)
        if getattr(self, "_cached_ch_names", None):
            self._apply_type_overrides_to_cache()
        # Bad channels
        self._set_combo(pp, "bad_mode", cc.get("choose_bad_channels", "auto"))
        self._set_check(pp, "bch_save_plots",
                        cfg.get("bad_channels", {}).get("save_plots", False))
        slow = bcp.get("slow_oscillations", [1, [2, 10], "-", [1e3, 1e4, 1e5]])
        self._set_edit(pp, "slow_window", slow[0])
        self._set_edit(pp, "slow_band", f"{slow[1][0]}, {slow[1][1]}")
        self._set_edit(pp, "slow_thr", ", ".join(str(int(t)) for t in slow[3]))
        noise = bcp.get("noise_power", [1, [52, 98], "-", [20, 200, 2000]])
        self._set_edit(pp, "noise_band", f"{noise[1][0]}, {noise[1][1]}")
        self._set_edit(pp, "noise_thr", ", ".join(str(int(t)) for t in noise[3]))
        cw = cc.get("correlation_window", [0.75, 0.975])
        self._set_edit(pp, "corr_window", f"{cw[0]}, {cw[1]}")
        self._set_edit(pp, "corr_thr", cc.get("correlation_badch_threshold", 0.95))
        # Montage & reference
        _MNE2D = {"standard_1020": "10-20", "standard_1005": "10-10"}
        _layout = cfg.get("electrodes_layout", NATIVE_POSITIONS_SENTINEL)
        self._set_combo(pp, "montage", _MNE2D.get(_layout, _layout))
        # Default to "" (Raw signal) when the config is silent;
        # populate uses self._reref_presets stashed by
        # _build_preproc_tab so the match is consistent.
        rr = cfg.get("re_reference", "")
        rr_str = (", ".join(rr) if isinstance(rr, list) else str(rr) if rr else "")
        presets = getattr(self, "_reref_presets", [])
        matched_preset = None
        for disp, val in presets:
            if rr_str.lower() == val.lower():
                matched_preset = disp; break
        if matched_preset is None and rr_str:
            matched_preset = "Custom derivation\u2026"
        if matched_preset is None and presets:
            matched_preset = presets[0][0]  # "Raw signal (no re-referencing)"
        if matched_preset:
            self._set_combo(pp, "reref_method", matched_preset)
        self._set_edit(pp, "reref", rr_str if (matched_preset and "Custom" in matched_preset) else "")
        # Filtering — Phase 2 multi-block.  filt is either a flat
        # dict (legacy single block) or a {id: subdict} mapping.
        # Iterate registered filter panels and apply matching cfg
        # by id; for legacy flat layout, apply to the first panel.
        is_flat = any(
            k in filt for k in
            ("highpass_freq", "lowpass_freq", "notch_freq", "method"))
        for fid, _grp in getattr(self, "_filter_widgets", []):
            if is_flat:
                fcfg = filt
            else:
                fcfg = filt.get(fid) or {}
            self._set_edit(pp, f"hp_{fid}", self._filter_cutoff_text(
                fcfg.get("highpass_freq", 0)))
            self._set_edit(pp, f"lp_{fid}", self._filter_cutoff_text(
                fcfg.get("lowpass_freq", 0)))
            notch = fcfg.get("notch_freq", 50)
            self._set_combo(pp, f"notch_{fid}",
                            f"{int(notch)} Hz" if notch and notch > 0
                            else "None")
            self._set_combo(pp, f"filt_method_{fid}",
                            "FIR (MNE)"
                            if fcfg.get("method", "iir") == "fir"
                            else "IIR (Butterworth)")
            self._set_check(pp, f"show_filt_{fid}",
                            fcfg.get("show_filt", False))
            self._set_check(pp, f"save_filt_{fid}",
                            fcfg.get("plot_filt", False))
            # Per-instance save flag → save_filtering:<id> button.
            save_btn = pp.get(f"save_filtering:{fid}")
            if save_btn is not None:
                save_btn.setChecked(bool(fcfg.get("save", False)))
            if is_flat:
                # Apply only to the first panel.
                break
        # ICA (Phase 4)
        self._set_grp(pp, "_ica_grp", cfg.get("prepare_ica", False))
        ica_cfg = cfg.get("ICA_EOG", {})
        self._set_combo(pp, "ica_method", ica_cfg.get("method", "picard"))
        self._set_combo(pp, "ica_selector", ica_cfg.get("selector", "iclabel"))
        self._set_edit(pp, "ica_fit_hp", ica_cfg.get("fit_highpass_hz", 1.0))
        self._set_edit(pp, "ica_reject", ica_cfg.get("reject_uv", 500))
        self._set_edit(pp, "ica_eog_ch",
                       ", ".join(ica_cfg.get("find_bads_eog_ch",
                                             ["Fp1", "Fp2", "Fpz"])))
        self._set_edit(pp, "ica_n_components",
                       ica_cfg.get("n_components", "rank"))
        self._set_edit(pp, "ica_decim", ica_cfg.get("decim", 1))
        self._set_edit(pp, "ica_random_state", ica_cfg.get("random_state", 42))
        self._set_edit(pp, "ica_iclabel_min_prob",
                       ica_cfg.get("iclabel_min_prob", 0.0))
        self._set_check(pp, "ica_find_bads_ecg",
                        ica_cfg.get("find_bads_ecg", True))
        self._set_check(pp, "ica_find_bads_muscle",
                        ica_cfg.get("find_bads_muscle", True))
        self._set_check(pp, "ica_save_components_audit",
                        ica_cfg.get("save_components_audit", False))
        keep_set = set(ica_cfg.get("iclabel_keep", ["brain", "other"]))
        for cls_name, cb in pp.get("iclabel_keep_checks", {}).items():
            cb.setChecked(cls_name in keep_set)
        # Artifacts
        self._set_grp(pp, "_art_grp", cfg.get("prepare_eeg_artifacts", False))
        self._set_edit(pp, "art_thr", art.get("artifact_threshold", 0.3))
        self._set_check(pp, "art_save_plots",
                        art.get("save_plots", False))
        self._set_check(pp, "art_save_tag",
                        art.get("save_tag", False))
        for src, dst in [("SlopeWindow", "slope_win"), ("SlopesAbsThr", "slope_abs"),
            ("SlopesStdThr", "slope_std"), ("SlopesMedThr", "slope_med"),
            ("OutliersMergeWin", "out_merge"), ("OutliersAbsThr", "out_abs"),
            ("OutliersStdThr", "out_std"), ("OutliersMedThr", "out_med"),
            ("MusclesWindow", "musc_win"), ("MusclesAbsThr", "musc_abs"),
            ("MusclesStdThr", "musc_std"), ("MusclesMedThr", "musc_med")]:
            self._set_edit(pp, dst, rp.get(src, 0))
        mfr = rp.get("MusclesFreqRange", [40, 90])
        self._set_edit(pp, "musc_freq", f"{mfr[0]}, {mfr[1]}")
        self._set_check(pp, "en_slopes", art.get("enable_slopes", True))
        self._set_check(pp, "en_outliers", art.get("enable_outliers", True))
        self._set_check(pp, "en_muscles", art.get("enable_muscles", True))
        self._set_check(pp, "en_amp", art.get("enable_amplitude", True))
        self._set_edit(pp, "amp_max", cfg.get("amplitude_max_threshold", 150e-6) * 1e6)
        self._set_edit(pp, "amp_time", cfg.get("amplitude_time_threshold", 0.02))
        self._set_edit(pp, "amp_nchan", cfg.get("amplitude_nchan_threshold", 0.33))
        # Segment rejection
        self._set_grp(pp, "_seg_grp", sr.get("enabled", False))
        self._set_edit(pp, "seg_reject", sr.get("reject_threshold", 0))
        self._set_edit(pp, "seg_flat", sr.get("flat_threshold", 0))
        self._set_edit(pp, "seg_pct", sr.get("auto_percentile", 95.0))
        # MP decomposition: enable state derived from step_order
        from ide4eeg.main import mp_decomposition_enabled
        self._set_grp(pp, "_mp_grp", mp_decomposition_enabled(cfg))
        self._set_edit(pp, "mp_iter", mp.get("iterations", 30))
        self._set_edit(pp, "mp_energy", f"{mp.get('explained_energy', 0.99) * 100:.0f}")
        # Load cpu_workers:
        #   0  → clear field text (inherit); placeholder is set by
        #        _update_mp_workers_readout based on current Config-tab
        #        value
        #   N  → put N in the field (explicit override)
        _cw_val = int(mp.get("cpu_workers", 0) or 0)
        if "mp_workers" in pp:
            pp["mp_workers"].setText(str(_cw_val) if _cw_val > 0 else "")
        if hasattr(self, "_update_mp_workers_readout"):
            self._update_mp_workers_readout()
        # energy_error fixed at 0.01 — no GUI widget
        algo = mp.get("algorithm", "smp")
        _algo_choices = mp_algorithm_choices()
        self._set_combo(
            pp, "mp_algo",
            next((label for name, label in _algo_choices if name == algo),
                 _algo_choices[0][1]))
        mp_out = mp.get("outputs", {})
        self._set_check(pp, "mp_csv", mp_out.get("atom_stats_csv", False))
        self._set_check(pp, "mp_hist", mp_out.get("atom_histograms", False))
        # MP filter
        self._set_grp(pp, "_mpf_grp", cfg.get("prepare_mp_filter", False))
        self._set_combo(pp, "mpf_mode", mp_flt.get("mode", "keep"))
        _mat = pp.get("mpf_atom_table")
        if _mat:
            _mat.set_single(mp_flt)
        for wk, ck in [("mpf_tmin", "time_min"), ("mpf_tmax", "time_max"),
                        ("mpf_energy", "min_energy")]:
            self._set_edit(pp, wk, mp_flt.get(ck, 0))

        # Gaze
        self._set_grp(pp, "_gaze_grp", cfg.get("prepare_video_artifacts", False))
        self._set_check(pp, "gaze_save_tag",
                        cfg.get("gaze", {}).get("save_tag", False))
        for wk, ck, dv in [("ref_dir", "video_reference_dir", ""),
            ("excl_dir", "video_exclude_dir", ""), ("face_tol", "facetag_face_tolerance", 0.6),
            ("det_size", "facetag_det_size", 0), ("adapt", "facetag_tracking_adapt_rate", 0.5),
            ("pos_w", "facetag_position_weight", 0.4), ("size_w", "facetag_size_weight", 0.2),
            ("switch_r", "facetag_switch_resistance", 0.25),
            ("max_angle", "facetag_max_angle", 20.0),
            ("gaze_smooth", "facetag_gaze_smoothing", 0.0),
            ("frame_skip", "facetag_frame_skip", 3), ("det_skip", "facetag_detection_skip", 3),
            ("downscale", "facetag_downscale", 1.0),
            ("min_iv", "facetag_min_interval", 0.0)]:
            self._set_edit(pp, wk, cfg.get(ck, dv))
        self._set_combo(pp, "gaze_method", cfg.get("facetag_gaze_method", "l2cs"))
        # _set_combo doesn't fire currentTextChanged when the value is
        # unchanged, so refresh the badge unconditionally.
        self._refresh_gaze_method_badge()
        self._set_check(pp, "ref_roi", cfg.get("facetag_ref_use_roi", False))
        self._set_check(pp, "no_face", cfg.get("facetag_no_face_is_artifact", True))
        # Rest / Epochs
        rd = rest.get("rest_duration", [0, ""])
        self._set_edit(pp, "rest_dur_start", rd[0]); self._set_edit(pp, "rest_dur_end", rd[1])
        wl = rest.get("window_length", 20)
        self._set_check(pp, "rest_whole", rest.get("whole_signal", wl in (0, None, "0", "")))
        self._set_edit(pp, "rest_window", wl if wl not in (0, None, "0", "") else 20)
        self._set_edit(pp, "ep_start", ep.get("start_offset", -0.3))
        self._set_edit(pp, "ep_stop", ep.get("stop_offset", 0.7))
        _bl_raw = ep.get("epochs_baseline", "None")
        _bl_disp = self._baseline_to_combo_text(_bl_raw)
        self._set_combo(pp, "ep_baseline", _bl_disp)
        if _bl_disp == "Custom" and isinstance(_bl_raw, (list, tuple)):
            s, e = (list(_bl_raw) + [None, None])[:2]
            self._set_edit(pp, "ep_baseline_start",
                           "" if s is None else s)
            self._set_edit(pp, "ep_baseline_end",
                           "" if e is None else e)
        custom_widget = pp.get("_ep_baseline_custom")
        if custom_widget is not None:
            custom_widget.setVisible(_bl_disp == "Custom")
        # Unified review flag — OR of the two per-mode keys so a
        # CLI-authored config with only one set still initializes
        # the widget correctly.
        self._set_check(pp, "check_segments",
                        bool(rest.get("check_rest", True))
                        or bool(ep.get("check_epochs", True)))
        # Compute event selection from loaded config
        tags = ep.get("tags", {})
        if "selected" in tags:
            # Empty list means "no choice made yet" (the DEFAULT_CONFIG
            # ships ``selected = []``).  Treat as "select all" so a user
            # who opens a file with events doesn't have to manually tick
            # every box before the pipeline can run — the event-locked
            # branch of _build_event_dict raises if selected is empty.
            ev_sel = set(tags["selected"]) or None
        elif not tags.get("AUTO", True):
            # Old manual format: flatten event names from tag groups
            ev_sel = set()
            for key, val in tags.items():
                if key == "AUTO":
                    continue
                if isinstance(val, str):
                    ev_sel.add(val)
                elif isinstance(val, list):
                    ev_sel.update(val)
            ev_sel = ev_sel or None  # empty → select all
        else:
            ev_sel = None  # AUTO or default → select all
        # Apply to panel if already populated, else store for later.
        # Route through _populate_event_list so named_items + unnamed
        # counts survive — a bare panel.populate(_all_names, ...) would
        # collapse the [Named] button to [All]-equivalent and strip
        # (code N) counts.
        self._pending_event_selection = ev_sel
        panel = pp.get("ev_panel")
        if panel and panel._checkboxes:
            self._sync_unnamed_toggle(self._cached_unnamed_codes)
            self._populate_event_list(
                self._cached_events or {},
                unnamed_codes=self._cached_unnamed_codes)
        _m2 = get_segmentation_mode(cfg)
        self._mode_combo.setCurrentText(self._MODE_DISPLAY.get(_m2, _m2))
        # Per-step save checkboxes — round-trip via _SAVE_CHECKBOX_MAP.
        # save_mp_decomposition is forced on in GUI, no restore needed.
        for widget_key, (section, _, _) in self._SAVE_CHECKBOX_MAP.items():
            self._set_check(pp, f"save_{widget_key}",
                            cfg.get(section, {}).get("save", False))

        # Apply step_order: check steps in the order, uncheck those not
        step_order = cfg.get("preprocessing", {}).get("step_order", None)
        if step_order is not None:
            _PIPELINE_TO_GRP = {
                "trim": "_trim_grp",
                "chosen_channels": "_sel_grp",
                # "resample" intentionally omitted: the field value
                # (resample_freq > 0) is the sole enable signal now.
                "bad_channels": "_bad_grp",
                "montage": "_mont_grp",
                "filtering": "_filt_grp",
                "ica": "_ica_grp",
                "artifacts": "_art_grp",
                "mp_decomposition": "_mp_grp",
                "mp_filter": "_mpf_grp",
            }
            active = set(step_order)
            for pipeline_name, grp_key in _PIPELINE_TO_GRP.items():
                w = pp.get(grp_key)
                if w and hasattr(w, "setChecked"):
                    w.setChecked(pipeline_name in active)

        # ── Analysis tab ──────────────────────────────────────────────
        if not an: return
        conn = cfg.get("connectivity", {})
        dip = cfg.get("dipole_fitting", {})
        # Connectivity
        self._set_grp(an, "_conn_grp", cfg.get("prepare_connectivity_analysis", False))
        rm = conn.get("methods", ["dtf", "coh"])
        sel = {m.strip().lower() for m in rm.split(",")} if isinstance(rm, str) else set(rm)
        for key, cb in an.get("_conn_methods", {}).items(): cb.setChecked(key in sel)
        _ml = {"yw": "Yule-Walker", "ns": "Nuttall-Strand", "vm": "Vieira-Morf"}
        self._set_combo(an, "conn_mvar", _ml.get(conn.get("mvar_method", "yw"), "Yule-Walker"))
        self._set_edit(an, "conn_order", conn.get("mvar_order", 0))
        self._set_edit(an, "conn_res", conn.get("resolution", 100))
        self._set_check(an, "conn_st", conn.get("short_time", False))
        self._set_edit(an, "conn_st_win", conn.get("st_window", 0))
        self._set_edit(an, "conn_st_ovl", conn.get("st_overlap", 0))
        self._set_check(an, "conn_sig", conn.get("significance", False))
        self._set_edit(an, "conn_sig_reps", conn.get("sig_reps", 100))
        self._set_edit(an, "conn_sig_alpha", conn.get("sig_alpha", 0.05))
        # Dipole
        self._set_grp(an, "_dip_grp", cfg.get("prepare_dipole_fitting", False))
        self._set_combo(an, "dip_ref", dip.get("ref_channel", "average"))
        self._set_combo(an, "dip_montage", dip.get("montage", "standard_1005"))
        self._set_edit(an, "dip_gof", dip.get("min_gof", 0))
        self._set_edit(an, "dip_dot", dip.get("dot_size", 0))
        _dat = an.get("dip_atom_table")
        if _dat:
            _dat.set_single(dip)
        self._set_check(an, "dip_cortical", dip.get("cortical_distance", False))
        self._set_edit(an, "dip_fsavg", dip.get("fsaverage_dir", ""))
        # cpu_workers: 0 = inherit (empty field), N > 0 = override
        _dcw = int(dip.get("cpu_workers", 0) or 0)
        if "dip_workers" in an:
            an["dip_workers"].setText(str(_dcw) if _dcw > 0 else "")
        if hasattr(self, "_update_dip_workers_readout"):
            self._update_dip_workers_readout()
        # EEG Profiles
        self._set_grp(an, "_prof_grp", cfg.get("prepare_eeg_profiles", False))
        prof = cfg.get("eeg_profiles", {})
        structs = prof.get("structures", [])
        _pat = an.get("prof_atom_table")
        if _pat and structs:
            _pat.populate(structs)
        self._set_check(an, "prof_auto_svarog",
                        prof.get("auto_open_svarog", False))
        # Substitute 0 → Nyquist in freq-max fields when sfreq is known
        _sf = getattr(self, "_cached_sfreq", None)
        if _sf:
            _nyq = int(_sf / 2)
            for _aft in (an.get("dip_atom_table"),
                         pp.get("mpf_atom_table"),
                         an.get("prof_atom_table")):
                if _aft:
                    _aft.set_freq_max_nyquist(_nyq)

        # ── External analyses (MNE catalog) ──────────────────────────
        self._migrate_legacy_psd_bands_topomap(cfg)
        mne_ids = cfg.get("mne_catalog", [])
        mne_par = cfg.get("mne_params", {})
        mne_adv_open = cfg.get("mne_advanced_open", {})
        checks = getattr(self, "_mne_checks", {})
        params = getattr(self, "_mne_params", {})
        adv_boxes = getattr(self, "_mne_advanced_groupboxes", {})
        for aid, cb in checks.items():
            cb.setChecked(aid in mne_ids)
        for aid, widgets in params.items():
            saved = mne_par.get(aid, {})
            for key, w in widgets.items():
                if key not in saved:
                    continue
                v = saved[key]
                if isinstance(w, QCheckBox):
                    w.setChecked(bool(v))
                elif isinstance(w, QComboBox):
                    idx = w.findText(str(v))
                    if idx >= 0:
                        w.setCurrentIndex(idx)
                else:  # QLineEdit
                    w.setText(str(v))
        for aid, w in adv_boxes.items():
            _set_disclosure_open(w, bool(mne_adv_open.get(aid, False)))

        # Recompute badges from the just-restored widget state.
        # No-ops when called before _build_preproc_tab has run.
        self._refresh_review_badges()

    # ── Config load / save ────────────────────────────────────────────

    # ── Recent files (QSettings) ────────────────────────────────────

    _MAX_RECENT = 10

    def _settings(self):
        return QSettings("IDE4EEG", "IDE4EEG")

    def _get_recent(self):
        """Return list of recent file paths from QSettings."""
        s = self._settings()
        paths = s.value("recent_files", [])
        if isinstance(paths, str):
            paths = [paths] if paths else []
        return [p for p in paths if p]

    def _add_recent(self, path):
        """Add a path to the recent files list."""
        if not path:
            return
        path = os.path.abspath(path)
        recent = self._get_recent()
        if path in recent:
            recent.remove(path)
        recent.insert(0, path)
        recent = recent[:self._MAX_RECENT]
        self._settings().setValue("recent_files", recent)
        self._populate_recent_list()

    def _clear_recent(self):
        """Clear the recent files list."""
        self._settings().setValue("recent_files", [])
        self._populate_recent_list()

    def _toggle_recent_list(self):
        """Show/hide the recent files list, swapping with View button."""
        lst = getattr(self, "_recent_list", None)
        if not lst:
            return
        show = not lst.isVisible()
        lst.setVisible(show)
        if hasattr(self, "_view_btn_ref"):
            self._view_btn_ref.setVisible(not show)

    def _populate_recent_list(self):
        """Fill the Recent list widget from QSettings."""
        lst = getattr(self, "_recent_list", None)
        if not lst:
            return
        lst.clear()
        recent = self._get_recent()
        for p in recent:
            name = os.path.basename(p)
            parent = os.path.basename(os.path.dirname(p))
            item = QListWidgetItem(f"{name}  ({parent})")
            item.setData(Qt.UserRole, p)
            item.setToolTip(p)
            lst.addItem(item)
        lst.setMaximumHeight(min(150, max(28, 24 * len(recent))))

    def _on_recent_clicked(self, item):
        """Load a file from the recent list."""
        path = item.data(Qt.UserRole)
        if not path or not os.path.isfile(path):
            self._msg_info("File not found",
                           f"The file no longer exists:\n{path}")
            return
        self._recent_list.hide()
        if hasattr(self, "_view_btn_ref"):
            self._view_btn_ref.setVisible(True)
        self._input_edit.setText(path)
        self._on_input_path_changed()

    # ── Config load / save ────────────────────────────────────────────

    def _load_config(self, path):
        try:
            cfg = load_toml(path)
            if not cfg: return
            # Deep-merge the loaded TOML into a copy of DEFAULT_CONFIG
            # so keys the user's config is silent on (e.g.
            # preprocessing.hard_constraints / soft_constraints) fall
            # back to the shipped defaults instead of disappearing.
            # Previously we did `self.config_data = cfg` which dropped
            # every default the user didn't explicitly set in their
            # TOML — the Config panel's constraints editor then showed
            # "(none)" for loaded configs that didn't list constraints
            # verbatim.
            merged = copy.deepcopy(DEFAULT_CONFIG)
            _deep_merge(merged, cfg)
            self.config_data = merged; self.config_path = path
            self._populate_vars(merged)
            self.setWindowTitle(f"IDE4EEG {ide4eeg.__version__} \u2014 {os.path.basename(path)}")
            self._status.showMessage(f"Loaded: {path}", 5000)
            inp = cfg.get("input_path", "")
            if inp and os.path.isfile(inp): self._read_signal_info(inp)
            self._auto_fill_face_dirs()
            self._update_face_counts()
            self._update_tab_indicators()
        except Exception as e: self._msg_error("Error loading config", str(e))

    def _on_load_config(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Load config", "",
            "TOML files (*.toml);;All (*)")
        if path:
            self._load_config(path)

    def _on_save_config(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save config", "config.toml",
                                              "TOML files (*.toml);;All (*)")
        if not path: return
        try:
            dump_toml(self._collect_config(), path)
            self.config_path = path; self._status.showMessage(f"Saved: {path}", 5000)
        except Exception as e: self._msg_error("Error saving config", str(e))


# ╔═══════════════════════════════════════════════════════════════════════╗
# ║  Entry point                                                         ║
# ╚═══════════════════════════════════════════════════════════════════════╝

def _check_linux_qt_deps():
    """On Linux, check for libraries PySide6/Qt6 needs at runtime."""
    if sys.platform != "linux":
        return
    import shutil
    import ctypes
    try:
        ctypes.cdll.LoadLibrary("libxcb-cursor.so.0")
    except OSError:
        print(
            "\n"
            "ERROR:\nIDE4EEG requires Qt6, which on Linux\nrequires libxcb-cursor0.\n"
            "  Please install it yourself.\n\n "
            "  Depending on the distribution that you use, the commands will be probably:\n\n"
            "  for Debian/Ubuntu:\n"
            "      sudo apt install libxcb-cursor0\n"
            "  for Fedora/RHEL:\n"
            "      sudo dnf install xcb-util-cursor\n\n"
            "  for Arch Linux:\n"
            "  sudo pacman -S xcb-util-cursor\n"
            "\n"
            "Then re-run IDE4EEG.\n",
            file=sys.stderr)
        sys.exit(1)


def main(preload_config=None):
    """Launch the IDE4EEG Qt6 GUI.

    Parameters
    ----------
    preload_config : pathlib.Path or str, optional
        If given, the GUI loads this TOML config into the form
        before the window is shown — same effect as clicking
        "Load pipeline settings .toml" right after launch.  Passed
        from the CLI when the user invokes ``ide4eeg <path>``.
    """
    _check_linux_qt_deps()
    # Load the verbose-logging preference from QSettings BEFORE any
    # prints happen.  Default: True (verbose).  Toggled via the
    # checkbox in the Config tab.
    global _VERBOSE_LOGGING
    _qs = QSettings("IDE4EEG", "IDE4EEG")
    _VERBOSE_LOGGING = bool(_qs.value("verbose_logging", True, type=bool))
    # Route logging.info()/.warning() to stdout when launched directly
    # via `python gui.py` (run.py sets this up itself).
    if not logging.getLogger().handlers:
        from ide4eeg.utils.log import setup_logging
        setup_logging(logging.INFO if _VERBOSE_LOGGING else logging.WARNING)
    if _VERBOSE_LOGGING:
        print("IDE4EEG: starting...", flush=True)
        print("  creating Qt application...", flush=True)
    app = QApplication(sys.argv)
    app.setFont(QFont(".AppleSystemUIFont" if sys.platform == "darwin"
                       else "Segoe UI" if sys.platform == "win32"
                       else "Sans"))

    # Use native style on macOS, Fusion elsewhere for modern look
    if sys.platform == "darwin":
        app.setStyle("macOS")
    else:
        app.setStyle("Fusion")
    if _VERBOSE_LOGGING:
        print("  building main window...", flush=True)

    # Wrap tooltips at reasonable width.  12 px of left padding on
    # combo boxes keeps the displayed text from butting against the
    # left edge of the field — uniform across light, dark, and
    # system themes (each theme stylesheet repeats the rule because
    # `app.setStyleSheet(...)` replaces, not appends).
    app.setStyleSheet(app.styleSheet() +
                      "QToolTip { max-width: 400px; }"
                      "QComboBox { padding-left: 12px; }")

    window = IDE4EEG_Qt()
    if preload_config is not None:
        # _load_config does the same merge-with-DEFAULT_CONFIG +
        # _populate_vars walk that the "Load pipeline settings"
        # button uses.  Calling it before .show() is fine — Qt
        # widgets accept setText / setChecked before the window is
        # visible.  Failure (bad TOML, missing keys) surfaces via
        # _msg_error inside _load_config, which falls back to a
        # blank GUI.
        window._load_config(str(preload_config))
    window.show()
    if _VERBOSE_LOGGING:
        print("IDE4EEG: ready.", flush=True)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
