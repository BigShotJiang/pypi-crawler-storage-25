"""Download and discover example data for IDE4EEG.

Example data (signal files) is not shipped with the repository.
This module downloads them from a GitLab release asset and extracts
them into the ``examples/`` directory alongside the config files
and ``example.toml`` metadata that *are* tracked in git.

Usage (CLI)::

    python -m ide4eeg.download_examples

Usage (Python)::

    from ide4eeg.download_examples import download_examples, find_examples
    download_examples()  # downloads + extracts
    for path, meta, ok in find_examples():
        print(path, meta["title"], "downloaded" if ok else "missing")
"""

import logging
import os
import tempfile
import urllib.request
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)

# GitLab release asset URL.  Updated when new examples are added.
_EXAMPLES_URL = (
    "https://gitlab.com/fuw_software/ide4eeg/-/releases/"
    "examples-v3/downloads/examples-data.zip"
)

# Default location: <repo_root>/examples/
_EXAMPLES_DIR = Path(__file__).resolve().parent.parent / "examples"

# Top-level directory names in the GitLab zip artifact to skip at
# extraction time — use this when an example is deferred between
# releases and the zip hasn't been rebuilt yet.  Authoritative copies
# of deferred examples live in _unreleased/examples/.
_DEFERRED_EXAMPLE_DIRS = ()


# ── Discovery ──────────────────────────────────────────────────────────

def find_examples(examples_dir=None):
    """Discover example directories containing ``example.toml``.

    Parameters
    ----------
    examples_dir : str or Path or None
        Root examples directory.  Defaults to ``<repo>/examples/``.

    Returns
    -------
    list of (str, dict, bool)
        Each entry is ``(directory_path, metadata_dict, is_downloaded)``.
        Sorted by title.
    """
    import tomllib

    root = Path(examples_dir) if examples_dir else _EXAMPLES_DIR
    if not root.is_dir():
        return []

    results = []
    for child in sorted(root.iterdir()):
        meta_path = child / "example.toml"
        if not meta_path.is_file():
            continue
        with open(meta_path, "rb") as f:
            meta = tomllib.load(f)
        downloaded = example_is_downloaded(str(child), meta)
        results.append((str(child), meta, downloaded))

    # Sort by explicit order (default 99), then title
    results.sort(key=lambda r: (r[1].get("order", 99), r[1].get("title", "")))
    return results


def example_is_downloaded(example_dir, meta):
    """Check whether all ``data_files`` from metadata exist on disk."""
    for fname in meta.get("data_files", []):
        if not os.path.isfile(os.path.join(example_dir, fname)):
            return False
    return True


# ── Download ───────────────────────────────────────────────────────────

def download_examples(target_dir=None, url=None, progress_callback=None):
    """Download and extract the example data zip.

    Parameters
    ----------
    target_dir : str or Path or None
        Directory to extract into.  Defaults to ``<repo>/examples/``.
    url : str or None
        Override download URL (for testing).
    progress_callback : callable or None
        Called with ``(bytes_downloaded, total_bytes)`` during download.
        *total_bytes* may be 0 if the server doesn't send Content-Length.

    Returns
    -------
    bool
        True on success.

    Raises
    ------
    Exception
        On network or extraction errors.
    """
    target = Path(target_dir) if target_dir else _EXAMPLES_DIR
    target.mkdir(parents=True, exist_ok=True)
    src = url or _EXAMPLES_URL

    logger.info("Downloading example data from %s", src)

    # Download to a temp file with progress reporting
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        with urllib.request.urlopen(src) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            with open(tmp_path, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total)

        logger.info("Download complete (%d bytes), extracting...", downloaded)

        # Validate and extract — skipping any deferred examples that
        # happen to still be in the zip artifact.
        with zipfile.ZipFile(tmp_path) as zf:
            for info in zf.infolist():
                if info.filename.startswith("/") or ".." in info.filename:
                    raise ValueError(
                        f"Unsafe path in zip: {info.filename}")
                first_segment = info.filename.split("/", 1)[0]
                if first_segment in _DEFERRED_EXAMPLE_DIRS:
                    continue
                zf.extract(info, target)

        logger.info("Examples extracted to %s", target)
        return True

    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


# ── CLI entry point ────────────────────────────────────────────────────

def _cli_main():
    """CLI entry point: ``python -m ide4eeg.download_examples``."""
    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s: %(message)s")

    def _progress(done, total):
        if total > 0:
            pct = done * 100 / total
            mb = done / 1_048_576
            print(f"\r  {pct:5.1f}%  ({mb:.1f} MB)", end="", flush=True)

    try:
        download_examples(progress_callback=_progress)
        print()  # newline after progress
        print("Done. Examples are ready in:", _EXAMPLES_DIR)
    except Exception as e:
        print()
        logger.error("Download failed: %s", e)
        raise SystemExit(1)


if __name__ == "__main__":
    _cli_main()
