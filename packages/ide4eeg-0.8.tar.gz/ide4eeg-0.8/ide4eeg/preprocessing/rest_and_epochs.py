"""Segment extraction, rejection, and persistence.

Identifies artifact-contaminated segments, cuts rest/epoch windows from
the continuous signal, removes bad segments, and saves cleaned epochs
as MNE -epo.fif files.

All functions operate on a single "segments" object (MNE Epochs),
regardless of whether the pipeline is in rest or epochs mode.
"""

# Author: Szymon Bocian, 2022

import os

import mne
import numpy as np
import pandas as pd
import logging

from .channels_and_signal import (get_segment_params,
                                    get_segment_events)


def _dirty_segment_ids(signal, config, artifacts_occurrence, tags_desc_id=None):
    """Score events by artifact contamination, return bad sample positions.

    Builds a binary artifact mask by OR-ing all artifact types, then scores
    each event-anchored window by the fraction of contaminated samples.
    Events exceeding the artifact_threshold on any channel are marked bad.

    Parameters
    ----------
    signal : mne.io.RawArray
        Signal with populated STIM channel(s).
    config : dict
        Configuration variables.
    artifacts_occurrence : dict
        Per-artifact-type binary masks (channels x samples).
    tags_desc_id : dict or None
        Event name → STIM value mapping. When provided (epoch mode), only
        STIM events whose integer ID appears in ``tags_desc_id.values()``
        are counted. Pass ``None`` to count all non-zero STIM events.

    Returns
    -------
    bad_event_positions : list[int]
        Sample-index positions (into the original Raw) of every event
        whose anchored window failed the artifact check.  These are the
        same sample positions MNE writes to ``Epochs.events[:, 0]``;
        ``_remove_bad_segments`` looks them up there to translate
        position → current-epoch-index, which keeps the contract
        independent of MNE's own edge-event filtering (events whose
        [tmin, tmax] would extend past the signal boundary are dropped
        by ``mne.Epochs(...)`` silently and won't appear in
        ``Epochs.events``, so they're transparently excluded here too).
    """
    params = get_segment_params(config)

    numpy_signal_channels = signal.get_data(picks=mne.pick_types(signal.info, eeg=True, exclude="bads"))

    art_thrd = config["artifacts"]["artifact_threshold"]
    artifact_detect = np.zeros(np.shape(numpy_signal_channels))

    for art_name in artifacts_occurrence:
        artifact_detect = np.logical_or(artifact_detect, artifacts_occurrence[art_name])

    start_n = int(signal.info["sfreq"] * params["tmin"])
    stop_n = int(signal.info["sfreq"] * params["tmax"])
    segment_duration_n = stop_n - start_n

    # Always read the original STIM channel.  In epoch mode this is
    # what mne.find_events uses too (in _cut_segments).  In rest mode
    # the synthetic rest-window pulses live in STIM_rest, but that
    # channel isn't added until the late preamble (after the
    # reorderable step loop where artifact detection runs); checking
    # STIM_rest here would crash with "no channel STIM_rest".
    # Rest-mode artifact accounting is therefore effectively a no-op
    # — a known limitation tracked separately from this commit.
    stim = signal["STIM"][0]

    # In epoch mode, only consider events whose STIM value is in
    # tags_desc_id.  Other events (button presses, sync markers, …)
    # don't become epochs and would skew the artifact accounting.
    relevant_ids = set(tags_desc_id.values()) if tags_desc_id else None

    bad_event_positions = []
    n_total = artifact_detect.shape[1]
    for t, sample in enumerate(np.transpose(stim)):
        if sample[0] == 0:
            continue
        if relevant_ids is not None and sample[0] not in relevant_ids:
            continue
        t_start = t + start_n
        t_stop = t + stop_n + 1
        # Skip events whose [tmin, tmax] window would extend before
        # the signal start or past its end.  mne.Epochs drops these
        # silently at construction; we must too, otherwise we'd
        # report a position that never appears in Epochs.events.
        if t_start < 0 or t_stop > n_total:
            continue
        arts_in_segment = (
            np.sum(artifact_detect[:, t_start:t_stop], axis=1)
            / segment_duration_n)
        if np.sum(arts_in_segment > art_thrd):
            bad_event_positions.append(t)

    return bad_event_positions


def _cut_segments(signal, config, tags_desc_id):
    """Cut segments (rest windows or epochs) from the continuous signal.

    Parameters
    ----------
    signal : mne.io.RawArray
        Signal with populated STIM channel.
    config : dict
        Configuration variables.
    tags_desc_id : dict
        Event name -> STIM value mapping.

    Returns
    -------
    segments : mne.Epochs
        Extracted segments.
    events : numpy.ndarray
        MNE events array (n_events x 3) — only the events that became
        epochs (matching the configured tags), so every row's event ID
        is guaranteed to be in ``tags_desc_id``.
    """
    params = get_segment_params(config)
    mode = params["mode"]

    # Mode-aware event lookup: get_segment_events() is the single
    # source of truth.  Rest mode reads synthetic window onsets from
    # REST annotations (attached by _add_rest_markers in the
    # preamble); event-locked mode reads file-derived events from the
    # primary STIM channel, which the preamble never overwrites.
    if mode == "rest":
        event_id = {"rest": tags_desc_id["rest"]}
    else:
        # Hierarchical event_id: {"target/pic_1": 11, ...}
        # MNE supports epochs["target"] to select all sub-events
        event_id = {tag: eid for tag, eid in tags_desc_id.items()
                    if tag != "rest"}

    signal_copy = signal.copy()
    events = get_segment_events(signal_copy, config, warn_if_missing=True)

    # Check that events match before MNE raises an opaque error
    expected_ids = set(event_id.values())
    found_ids = set(events[:, 2]) if len(events) > 0 else set()
    if not expected_ids & found_ids:
        source = ("REST annotations" if mode == "rest"
                  else "the STIM channel")
        raise RuntimeError(
            f"No matching events for {mode} mode. "
            f"Expected event IDs {expected_ids}, "
            f"found {found_ids or 'none'} in {source}. "
            f"Check that rest_duration/window_length fit the signal, "
            f"or that epoch tags match the file's event markers.")

    segments = mne.Epochs(signal_copy, events,
                          tmin=params["tmin"], tmax=params["tmax"],
                          event_id=event_id, baseline=params["baseline"],
                          reject=None)
    n_initial_events = len(events)

    # Materialise the data — this is also when MNE actually runs
    # the OOB filter that drops events whose epoch window extends
    # past the signal.  After load_data, ``len(segments)`` is
    # reliable (no "bad epochs not dropped" error) and reflects the
    # true post-rejection epoch count.
    segments = segments.load_data()

    # Bail out cleanly when MNE produced an empty Epochs container.
    # Without this check the next line (``drop_channels``) raises a
    # confusing "this Epochs-object is empty" deep inside MNE.
    # Two common causes (rest mode in particular):
    #   - rest_duration ≥ signal_duration after trim
    #   - last event timestamp + tmax > signal end
    # Surface them together with a concrete diagnosis.
    if len(segments) == 0:
        sig_dur = signal_copy.times[-1] if len(signal_copy.times) else 0.0
        ep_w = params["tmax"] - params["tmin"]
        rest_hint = ""
        if ep_w >= sig_dur and sig_dur > 0:
            rest_hint = (
                f"\n  → Rest-window length {ep_w:.1f} s is at least as "
                f"long as the trimmed signal ({sig_dur:.1f} s) — "
                f"shorten ``rest_duration`` or widen ``trim_start`` / "
                f"``trim_end``."
            )
        raise ValueError(
            f"cut_segments produced zero epochs from "
            f"{n_initial_events} event(s) — every event was "
            f"rejected during epoch construction.  Epoch window: "
            f"[tmin={params['tmin']}, tmax={params['tmax']}] s "
            f"(width {ep_w:.1f} s); signal duration after trim: "
            f"{sig_dur:.1f} s.\nCommon causes:\n"
            f"  - tmin / tmax extend past the start or end of the "
            f"trimmed signal (e.g. an event near the recording's "
            f"end + a long post-event window).\n"
            f"  - In rest mode, ``rest_duration`` ≥ signal length "
            f"after trim → no full window fits.\n"
            f"  - Event timestamps and the signal's sample base "
            f"are misaligned (a stale snapshot from a different "
            f"recording).{rest_hint}"
        )

    # Drop every stim-type channel from the epochs (the file's
    # STIM, plus a legacy STIM_rest if loaded from an old snapshot).
    # Downstream analyses operate on data channels only.
    stim_chs_in_epochs = [
        c for i, c in enumerate(segments.ch_names)
        if mne.channel_type(segments.info, i) == "stim"
    ]
    if stim_chs_in_epochs:
        segments = segments.drop_channels(stim_chs_in_epochs)

    # Return only events that actually became epochs — events of types
    # not in `event_id` are silently dropped by mne.Epochs and would
    # cause downstream code (e.g. _prepare_dataframe) to lookup IDs
    # that aren't in tags_desc_id.
    return segments, segments.events


def _estimate_ptp_threshold(segments, percentile=95.0):
    """Estimate a peak-to-peak rejection threshold from the data.

    Computes peak-to-peak amplitude for every segment × channel, then
    returns the requested percentile as a single EEG threshold (in V).

    Parameters
    ----------
    segments : mne.Epochs
        Segments to analyze.
    percentile : float
        Percentile of peak-to-peak distribution to use as threshold
        (default 95 — rejects the top 5 % of segments).

    Returns
    -------
    threshold : float
        Peak-to-peak amplitude threshold in Volts.
    """
    data = segments.get_data(picks="eeg")          # (n_epochs, n_ch, n_times)
    ptp = data.max(axis=2) - data.min(axis=2)      # (n_epochs, n_ch)
    threshold = float(np.percentile(ptp, percentile))
    return threshold


def _remove_bad_segments(segments, bad_event_positions, config):
    """Remove artifact-contaminated segments and apply peak-to-peak rejection.

    Parameters
    ----------
    segments : mne.Epochs
        All extracted segments.
    bad_event_positions : list[int] or None
        Sample-index positions (into the original Raw) of events that
        ``_dirty_segment_ids`` flagged as artifact-contaminated.  Mapped
        to current epoch indices via ``segments.events[:, 0]`` so the
        contract stays robust against MNE silently dropping edge events
        at Epochs construction time (different signal lengths and
        event placements would otherwise mis-align position-vs-index
        accounting).
    config : dict
        Configuration variables.

    Returns
    -------
    clean_segments : mne.Epochs
        Segments after rejection.
    all_bad_ids : list
        Indices (into the original ``segments``) of every rejected segment —
        from both artifact detection and peak-to-peak rejection.
    """
    clean_segments = segments.copy()

    # ── Drop artifact-marked segments first ────────────────────────
    bad_ids = []
    if bad_event_positions:
        # Map event sample positions → current epoch indices.  An
        # entry in *bad_event_positions* that doesn't appear in
        # segments.events[:, 0] means the corresponding event was
        # filtered out by mne.Epochs (out-of-bounds tmin/tmax,
        # baseline issues, …) — silently skipped, keeping behaviour
        # robust under upstream changes.
        bad_pos_set = set(int(p) for p in bad_event_positions)
        bad_ids = [i for i, ev in enumerate(segments.events)
                   if int(ev[0]) in bad_pos_set]
    if bad_ids:
        logging.info(
            "Dropping %d segments marked bad by artifact detection.",
            len(bad_ids))
        clean_segments.drop(bad_ids)
        if len(clean_segments) == 0:
            mode = get_segment_params(config)["mode"]
            logging.warning(
                f"All {mode} segments were dropped by artifact rejection.")
            return clean_segments, list(range(len(segments.events)))

    # ── Peak-to-peak rejection (optional) ──────────────────────────
    seg_rej = config.get("segment_rejection", {})
    if seg_rej.get("enabled", False):
        reject_uv = seg_rej.get("reject_threshold", 0)
        flat_uv = seg_rej.get("flat_threshold", 0)
        percentile = seg_rej.get("auto_percentile", 95.0)

        if reject_uv == 0:
            reject_v = _estimate_ptp_threshold(clean_segments, percentile)
            logging.info(
                "Segment rejection: auto peak-to-peak threshold = "
                "%.1f µV (p%.0f)", reject_v * 1e6, percentile)
        else:
            reject_v = reject_uv * 1e-6  # µV → V
            logging.info(
                "Segment rejection: peak-to-peak threshold = %.1f µV",
                reject_uv)

        reject_dict = {"eeg": reject_v} if reject_v > 0 else None
        flat_dict = {"eeg": flat_uv * 1e-6} if flat_uv > 0 else None

        n_before = len(clean_segments)
        clean_segments.drop_bad(reject=reject_dict, flat=flat_dict)
        n_dropped = n_before - len(clean_segments)
        if n_dropped > 0:
            logging.info(
                "Segment rejection: dropped %d/%d segments.",
                n_dropped, n_before)
        else:
            logging.info("Segment rejection: no segments dropped.")
        if len(clean_segments) == 0:
            mode = get_segment_params(config)["mode"]
            logging.warning(
                "All %s segments were dropped by peak-to-peak "
                "rejection (threshold %.1f µV). Loosen the "
                "threshold or check the signal for global "
                "artifacts.", mode, reject_v * 1e6 if reject_v else 0)

    # Reconstruct the final bad_ids from drop_log. It covers both artifact
    # and peak-to-peak drops, and is the canonical source for downstream
    # code (e.g. _prepare_dataframe) that needs to mark bad rows.
    all_bad_ids = [i for i in range(len(segments.events))
                   if clean_segments.drop_log[i] != ()]
    return clean_segments, all_bad_ids


def _check_segments(segments_clean, original_segments, bad_ids, config):
    """Interactive manual review of segments — replace semantics.

    The GUI hook receives the *original* (pre-rejection) Epochs plus
    the indices of the already-dropped ones, so the review window
    (Svarog with ``--select-mode bad_epochs --preselect ...``, or
    the MNE-fallback-with-pre-drop) shows every cut epoch with the
    PTP-flagged ones pre-marked.  The user can confirm, undo, or
    add — Svarog's returned set is the *final* rejection list,
    which means a PTP-rejected epoch the user disagrees with comes
    back.  Replace semantics, chosen 2026-05-02.

    The CLI path (no hook installed) keeps the legacy add-only
    behaviour: the user's interactive marks in ``epochs.plot()`` are
    appended to the already-cleaned subset.  MNE's blocking plot
    has no preselect mechanism, and the CLI workflow predates the
    Svarog review path.

    Parameters
    ----------
    segments_clean : mne.Epochs
        Output of :func:`_remove_bad_segments` — survivors only.
    original_segments : mne.Epochs
        Pre-rejection segments (full set out of ``_cut_segments``).
        Hook path operates on this; CLI path ignores it.
    bad_ids : list[int]
        Indices into ``original_segments.events`` that
        :func:`_remove_bad_segments` flagged.  Becomes the
        ``preselected_rejections`` list shown to the GUI hook.
    config : dict
        Configuration variables.

    Returns
    -------
    clean_segments : mne.Epochs
        Segments after manual rejection.
    bad_ids : list[int]
        Indices of all rejected segments (into the original).
    """
    if segments_clean is None or len(segments_clean) == 0:
        return segments_clean, []

    params = get_segment_params(config)

    if params["check"]:
        hook = (config.get("_manual_hooks") or {}).get("segments")
        if hook is not None:
            # GUI path — replace semantics.  Hook receives the
            # original Epochs + the PTP-rejected indices; returns the
            # FINAL rejection set (in original-event indices).
            final_idxs = hook(original_segments, set(bad_ids or []))
            final_set = set(final_idxs or [])
            clean_segments = original_segments.copy()
            if final_set:
                clean_segments.drop(
                    sorted(final_set), reason="USER")
        else:
            # CLI path: in-process blocking MNE plot — add-only,
            # operates on the already-cleaned subset (legacy).
            clean_segments = segments_clean.copy()
            eeg_data = (clean_segments.copy().load_data()
                        .pick("eeg", exclude=clean_segments.info["bads"])
                        .get_data())
            scale = (np.round(np.quantile(eeg_data, 0.995), 5)
                     if eeg_data.size > 0 else 100e-6)
            clean_segments.plot(
                block=True, event_id=clean_segments.event_id,
                events=clean_segments.events, n_epochs=10,
                scalings=dict(eeg=scale))
    else:
        clean_segments = segments_clean

    final_bad_ids = [
        i for i in range(len(clean_segments.drop_log))
        if clean_segments.drop_log[i] != ()]
    return clean_segments, final_bad_ids


def _save_segments(segments, tags_desc_id, config, path, file_name):
    """Save segments to a -epo.fif file.

    Parameters
    ----------
    segments : mne.Epochs
        Segments to save.
    tags_desc_id : dict
        Event name -> STIM value mapping.
    config : dict
        Configuration variables.
    path : str
        Output directory path.
    file_name : str
        Base file name.
    """
    params = get_segment_params(config)
    mode = params["mode"]

    fifpath = os.path.join(path, "saved_signals")
    if not os.path.isdir(fifpath):
        os.mkdir(fifpath)

    if segments is not None and len(segments) > 0:
        segments = segments.copy()
        segments.reject = None
        segments.flat = None
        segments.save(os.path.join(fifpath, file_name + f"_{mode}-epo.fif"), overwrite=True)

    # Always rewrite tag_id.txt — previous runs may have used different tags.
    with open(os.path.join(fifpath, "tag_id.txt"), "w") as file:
        header = ("Resting-state windows" if mode == "rest"
                  else "Event-locked epochs")
        file.write(f"~~~~~~ TAGS INDEX ({header}) ~~~~~~\n\n")
        for tag, eid in tags_desc_id.items():
            file.write(f"{tag}: {eid}\n")


def _prepare_dataframe(events, bad_ids, tags_desc_id, artifacts_occurrence, signal_info, config):
    """Build a dataframe with per-segment, per-channel artifact statistics.

    Parameters
    ----------
    events : numpy.ndarray
        MNE events array (n_events x 3).
    bad_ids : list or None
        Indices of bad segments.
    tags_desc_id : dict
        Event name -> STIM value mapping.
    artifacts_occurrence : dict or None
        Per-artifact-type binary masks.
    signal_info : mne.Info
        Signal metadata.
    config : dict
        Configuration variables.

    Returns
    -------
    data : pandas.DataFrame
        Dataframe with basic information about tags.
    """
    params = get_segment_params(config)
    mode = params["mode"]

    data = {"id": [], "tag": [], "channel": [], "t_start": [], "t_stop": [], "bad_segment": [], "bad_channel": []}
    Fs = signal_info["sfreq"]
    # Stim-type channels are metadata, never in the dataframe.
    ch_names = [
        ch for i, ch in enumerate(signal_info["ch_names"])
        if mne.channel_type(signal_info, i) != "stim"
    ]
    ch_not_bad = [ch for ch in ch_names if ch not in signal_info["bads"]]

    if artifacts_occurrence is not None:
        for art_name in artifacts_occurrence.keys():
            data[art_name + "_arts"] = []

    if events is None:
        return pd.DataFrame(data)

    for s, segment in enumerate(events):

        if mode == "rest":
            tag_name = "rest"
        else:
            tag_name = next(k for k, v in tags_desc_id.items() if v == segment[2])

        for ch_name in ch_names:

            data["id"].append(f"{tag_name}_{ch_name}_{s}")

            data["tag"].append(tag_name)
            data["channel"].append(ch_name)

            data["t_start"].append(segment[0] / Fs + params["tmin"])
            data["t_stop"].append(segment[0] / Fs + params["tmax"])

            if bad_ids is not None and s in bad_ids:
                data["bad_segment"].append(True)
            else:
                data["bad_segment"].append(False)

            if ch_name in signal_info["bads"]:
                data["bad_channel"].append(True)
            else:
                data["bad_channel"].append(False)

            if artifacts_occurrence is not None:
                for art_name in artifacts_occurrence.keys():
                    if ch_name not in signal_info["bads"]:
                        try:
                            ch = ch_not_bad.index(ch_name)
                            seg_start = int(segment[0] + params["tmin"] * Fs)
                            seg_stop = int(segment[0] + params["tmax"] * Fs) + 1
                            seg_duration = params["tmax"] - params["tmin"]
                            data[art_name + "_arts"].append(
                                np.sum(artifacts_occurrence[art_name][ch, seg_start:seg_stop]) / int(Fs * seg_duration)
                            )
                        except (IndexError, KeyError, ValueError):
                            data[art_name + "_arts"].append(np.nan)
                    else:
                        data[art_name + "_arts"].append(np.nan)

    return pd.DataFrame(data)
