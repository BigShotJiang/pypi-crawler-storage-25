"""Preprocessing step constraints — single source of truth.

Defines the ordering constraints, rationales, and the
ConstraintViolation type used by both the pipeline
(``preprocessing.py``) and the GUI (``gui_config.py``).

This module is intentionally stdlib-only (no MNE, no numpy)
so ``gui_config.py`` can import it without slowing down GUI
cold-start.
"""


class ConstraintViolation(str):
    """A ``str`` subclass carrying structured fields for GUI use.

    Instances still behave as plain strings — ``str(v)``, ``f"{v}"``,
    ``"; ".join(violations)``, and substring matching in tests all
    work unchanged.  The extra attributes (``severity``, ``before``,
    ``after``, ``rationale``) let the GUI look up the offending step
    pair and the long-form explanation without reparsing the summary.
    """

    __slots__ = ("severity", "before", "after", "rationale")

    def __new__(cls, summary, *, severity, before, after, rationale=""):
        obj = super().__new__(cls, summary)
        obj.severity = severity
        obj.before = before
        obj.after = after
        obj.rationale = rationale
        return obj


DEFAULT_HARD_CONSTRAINTS = [
    # Data-flow constraint: mp_filter consumes the atoms produced by
    # mp_decomposition.  Every other historical "hard" ordering rule
    # (montage before filter, etc.) turned out to be linear-ops or
    # pragmatic convention rather than a correctness requirement —
    # they've been removed in favour of an "only-the-obvious" policy
    # that maximises user freedom.
    ["mp_decomposition", "mp_filter"],
]

DEFAULT_SOFT_CONSTRAINTS = [
    ["filtering", "ica"],
    ["bad_channels", "ica"],
]

HARD_CONSTRAINT_RATIONALES = {
    ("mp_decomposition", "mp_filter"):
        "mp_filter consumes the atoms produced by mp_decomposition. "
        "Reordering this pair would mean filtering atoms that don't "
        "exist yet — the filter step has nothing to work with.",
}

SOFT_CONSTRAINT_RATIONALES = {
    ("filtering", "ica"):
        "Winkler et al. 2015 show that a high-pass filter around 1 Hz "
        "applied before ICA markedly improves the decomposition — "
        "sharper dipolar topographies, fewer spurious components, and "
        "a cleaner separation of ocular artifacts. If you run ICA on "
        "unfiltered data, slow drifts (<1 Hz) dominate the first "
        "components and obscure the real artifact sources.",
    ("bad_channels", "ica"):
        "A channel that is noisy, flat, or uncorrelated with its "
        "neighbours tends to dominate one ICA component and corrupt "
        "the rest of the decomposition. Mark and exclude bad channels "
        "before running ICA so the algorithm can focus on real "
        "physiological sources.",
}

# Data-dependency constraints: a consumer step requires a specific
# output type from a producer step.  Unlike ordering constraints
# (which only check position), these check whether the producer's
# configuration is compatible with the consumer's requirements.
#
# Format: {"consumer": {"producer": "required_output_type", ...}}
#
# Checked at preflight time (not reorder time) because the output
# type depends on config values (e.g. algorithm=mmp1), not just
# step presence.  See _preflight_check_cli in main.py and
# _mp_preflight_gui in gui.py for the runtime enforcement.
DATA_DEPENDENCIES = {
    "dipole_fitting": {
        "mp_decomposition": "mmp1",
    },
    "mp_filter": {
        "mp_decomposition": "any",
    },
    "eeg_profiles": {
        "mp_decomposition": "any",
    },
    "tf_statistics_mp": {
        "mp_decomposition": "any",
    },
}
