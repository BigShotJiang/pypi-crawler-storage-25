"""Pipeline orchestrator for IDE4EEG.

Reads a TOML config, discovers signal files, and for each file runs
the full read -> preprocessing -> analysis pipeline, writing results to
the configured output directory.
"""

# Author: Szymon Bocian, 2022

import copy
import logging
import os
from datetime import datetime

from . import OUTPUT_DIR_PREFIX
from .analysis.analysis import analysis
from .input.input import (
    _apply_type_overrides,
    find_file_paths,
    read_config_file,
    read_file,
)
from .preprocessing.preprocessing import preprocessing


def mp_decomposition_enabled(config):
    """True iff ``mp_decomposition`` is in the configured step order.

    Single source of truth for "is MP decomposition going to run?",
    shared by the GUI's preflight, the CLI's preflight, and any other
    consumer that previously read the (now-deleted) top-level
    ``prepare_mp_decomposition`` flag.

    Falls back to ``_derive_step_order`` when ``preprocessing.step_order``
    is absent (legacy configs without the explicit list).
    """
    preproc = config.get("preprocessing", {})
    step_order = preproc.get("step_order")
    if step_order is None:
        from .preprocessing.preprocessing import _derive_step_order
        step_order = _derive_step_order(config)
    return "mp_decomposition" in step_order


def mp_consumers_from_cfg(config):
    """Return a list of analysis names that need an MP book.

    Shared by the GUI and CLI preflight paths so the consumer-
    detection logic lives in one place.
    """
    consumers = []
    tfs_source = config.get("tf_statistics", {}).get("source", "mp").lower()
    if config.get("prepare_tf_statistics") and tfs_source == "mp":
        consumers.append("ERD/S Statistics (MP source)")
    if config.get("prepare_eeg_profiles"):
        consumers.append("EEG Profiles")
    if config.get("prepare_dipole_fitting"):
        consumers.append("Dipole Fitting")
    if config.get("prepare_mp_filter"):
        consumers.append("MP Filter")
    return consumers


def _preflight_check_cli(config):
    """Validate MP decomposition ↔ analysis dependencies + video
    stack (CLI path).

    Raises ``ValueError`` with a clear message on any of these
    violations:

    R1  Dipole Fitting is enabled but the MP algorithm is not MMP1.
    R2  A consumer that needs a channel selection has none
        (in CLI the user must set the key in the TOML).
    R3  A consumer needs an MP book but MP decomposition is off.
    R4  ``prepare_video_artifacts`` is enabled but the video stack
        has missing or platform-blocked Python deps (mirrors the
        GUI's preflight at ``IDE4EEG_Qt._preflight_check`` so CLI
        users get identical cell-aware error messages).
    """
    # R4 — video stack.  Run before the MP-consumer early-return
    # so it fires even on configs that don't touch MP analyses.
    _preflight_video_stack_cli(config)

    consumers = mp_consumers_from_cfg(config)
    if not consumers:
        return

    mp_on = mp_decomposition_enabled(config)
    algo = config.get("matching_pursuit", {}).get(
        "algorithm", "smp").lower()

    # R3: MP decomposition must be on
    if not mp_on:
        raise ValueError(
            f"MP decomposition is required but not enabled. "
            f"Consumers: {', '.join(consumers)}. "
            f"Add 'mp_decomposition' to preprocessing.step_order in "
            f"your TOML.")

    # R1: Dipoles requires MMP1 (DATA_DEPENDENCIES in preprocessing.py)
    if config.get("prepare_dipole_fitting") and algo != "mmp1":
        raise ValueError(
            f"Dipole Fitting requires MMP1 algorithm but "
            f"matching_pursuit.algorithm = '{algo}'. "
            f"Set matching_pursuit.algorithm = 'mmp1' in your TOML.")

    # R2: channel selection required
    if config.get("prepare_eeg_profiles"):
        ch = config.get("eeg_profiles", {}).get("channel", "")
        if not ch:
            raise ValueError(
                "EEG Profiles requires a channel selection. "
                "Set eeg_profiles.channel = 'ChannelName' in your "
                "TOML.")
    tfs_source = config.get("tf_statistics", {}).get(
        "source", "mp").lower()
    if config.get("prepare_tf_statistics") and tfs_source == "mp":
        ch = config.get("tf_statistics", {}).get("channel", "")
        if not ch:
            raise ValueError(
                "ERD/S Statistics (MP source) requires a channel. "
                "Set tf_statistics.channel = 'ChannelName' in your "
                "TOML.")


def _preflight_video_stack_cli(config):
    """Raise ValueError when ``prepare_video_artifacts`` needs Python
    packages that aren't installed on this cell.

    Same plan-install logic as the GUI preflight; differences are
    error-mode only — CLI raises with plain text, GUI builds an
    HTML fatal entry.  Keeping the two halves textually similar
    means a user who flips between CLI and GUI sees consistent
    remediation advice.
    """
    if not config.get("prepare_video_artifacts"):
        return
    from ide4eeg.install_diagnostics import (
        plan_install, format_diagnostic)
    plan = plan_install()
    needs_l2cs = (
        config.get("facetag_gaze_method", "l2cs") == "l2cs")
    core_missing = [p for p in plan.missing if not p.optional]
    core_blocked = [(p, i) for p, i in plan.blocked
                    if not p.optional]
    if core_missing or core_blocked:
        raise ValueError(
            "Video stack not ready:\n\n"
            + format_diagnostic(plan)
            + "\nRe-run after installing the missing packages.  "
            "Run `python -m ide4eeg.install_diagnostics` at any "
            "time to print this diagnostic without launching the "
            "pipeline.")
    if needs_l2cs:
        from ide4eeg.download_tools import l2cs_missing_deps
        missing = l2cs_missing_deps()
        if missing:
            raise ValueError(
                "L2CS gaze backend requires "
                + " + ".join(missing) + " (not installed).\n"
                "L2CS-Net is the default eye-gaze backend.  "
                "Install with:\n"
                "  pip install torch\n"
                "  pip install \"l2cs @ git+https://github.com/"
                "Ahmednull/L2CS-Net.git@main\"\n"
                "Or switch facetag_gaze_method to 'insightface' "
                "in your TOML for the head-pose fallback (limited "
                "— measures head direction, not eye direction).")


def default_n_jobs():
    """Return a safe default for ``parallelism.n_jobs``.

    ``min(physical_cores - 2, available_ram_gb // 2)``, floored at 1
    — leaves 2 physical cores free for the OS / GUI / browser so the
    machine stays responsive while the pipeline runs, capped by RAM
    to avoid swap thrashing (each loky worker is a fresh Python
    interpreter plus its working set).  Always ≥ 1, so 1- and
    2-core machines fall back to sequential.
    """
    physical, _, ram_gb = _detect_system()
    return max(1, min(physical - 2, int(ram_gb // 2)))


def _detect_system():
    """Return ``(physical_cores, logical_cores, ram_gb)``.

    Best-effort cross-platform probe. Resolution order:

    1. **psutil**, if installed — cross-platform, exact physical
       cores and RAM on every OS. Not in ``requirements.txt`` but
       commonly available; if present we use it and skip the
       platform-specific branches.
    2. **macOS**: ``sysctl hw.physicalcpu`` and ``sysctl hw.memsize``.
    3. **Linux**: parse ``/proc/cpuinfo`` for unique
       (physical id, core id) pairs, ``/proc/meminfo`` for
       ``MemTotal``.
    4. **Windows**: ``ctypes`` call to ``GlobalMemoryStatusEx`` for
       RAM. Physical core count is **not** reliably available from
       stdlib on Windows — we fall back to ``logical // 2``, which
       is correct for any Intel chip with 2-way hyperthreading and
       conservative (under-estimates) for AMD and other topologies.
       Users on Windows workstations who care about exact physical
       core detection should ``pip install psutil`` to take the
       psutil path above.
    5. **Other / failure**: ``physical = logical // 2`` and
       ``ram_gb = 4.0`` as conservative fallbacks.

    Result is cached for the lifetime of the process — this
    function is called from the GUI readout on every textChanged
    event, so it needs to be sub-microsecond after the first call.
    """
    cached = getattr(_detect_system, "_cache", None)
    if cached is not None:
        return cached

    import os
    import sys

    logical = os.cpu_count() or 1
    physical = max(1, logical // 2)
    ram_gb = 4.0

    # --- Preferred path: psutil (cross-platform, exact) -------
    try:
        import psutil  # type: ignore
        phys = psutil.cpu_count(logical=False)
        if phys:
            physical = int(phys)
        ram_gb = psutil.virtual_memory().total / (1024 ** 3)
        cached = (physical, logical, round(ram_gb, 1))
        _detect_system._cache = cached
        return cached
    except Exception:
        pass

    # --- Platform-specific stdlib probes ----------------------
    import subprocess

    if sys.platform == "darwin":
        try:
            physical = int(subprocess.check_output(
                ["sysctl", "-n", "hw.physicalcpu"],
                text=True).strip())
        except Exception:
            pass
        try:
            ram_bytes = int(subprocess.check_output(
                ["sysctl", "-n", "hw.memsize"],
                text=True).strip())
            ram_gb = ram_bytes / (1024 ** 3)
        except Exception:
            pass
    elif sys.platform.startswith("linux"):
        try:
            ids = set()
            phys = None
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("physical id"):
                        phys = line.split(":", 1)[1].strip()
                    elif line.startswith("core id") and phys is not None:
                        core = line.split(":", 1)[1].strip()
                        ids.add((phys, core))
            if ids:
                physical = len(ids)
        except Exception:
            pass
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        ram_gb = int(line.split()[1]) / (1024 ** 2)
                        break
        except Exception:
            pass
    elif sys.platform == "win32":
        # RAM via Win32 GlobalMemoryStatusEx. Reliable, no shell out.
        try:
            import ctypes
            from ctypes import wintypes

            class _MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", wintypes.DWORD),
                    ("dwMemoryLoad", wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            mem = _MEMORYSTATUSEX()
            mem.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(  # type: ignore[attr-defined]
                ctypes.byref(mem))
            ram_gb = mem.ullTotalPhys / (1024 ** 3)
        except Exception:
            pass
        # Physical core count on Windows without psutil is not
        # reliably available from stdlib — the logical // 2 fallback
        # set above is kept. For an 8-core/16-thread Intel it's
        # exact; for non-HT CPUs it over-reserves safety headroom.

    cached = (physical, logical, round(ram_gb, 1))
    _detect_system._cache = cached
    return cached


def _resolve_n_jobs(config):
    """Return the effective parallel worker count.

    Reads ``config['parallelism']['n_jobs']`` with strict semantics —
    no auto heuristic. Matches MNE's convention: default = 1
    (sequential), user explicitly opts into parallelism by typing a
    larger number. Values ``0``, missing, or non-integer are mapped
    to ``1`` (sequential).

    Note: the config section is named ``parallelism``, not ``global``,
    because ``global`` is a reserved Python keyword — using it as a
    section name would break ``api.generate_script`` (which emits the
    config as keyword arguments to ``run_file``).
    """
    raw = config.get("parallelism", {}).get("n_jobs", 1)
    try:
        n = int(raw)
    except (TypeError, ValueError):
        n = 1
    if n < 1:
        n = 1
    return n


def _configure_parallelism(config):
    """Apply the global joblib parallelism policy for this pipeline run.

    Sets the process-wide default backend / n_jobs / BLAS-thread limit
    so every ``joblib.Parallel`` call — ours (tf_statistics) and every
    MNE/scikit-learn call that delegates to joblib — inherits the same
    policy. ``inner_max_num_threads=1`` pins each worker to
    one BLAS thread, making total CPU load equal ``n_jobs`` (no silent
    multiplication by OpenBLAS' default thread count).

    See CONTRIBUTING.md §"Parallelism" for rationale. MP decomposition
    (empi subprocess) is fully independent — it reads
    ``matching_pursuit.cpu_workers`` directly. Dipole fitting reads
    ``dipole_fitting.cpu_workers`` first and falls back to
    ``parallelism.n_jobs`` set here when that key is unset / 0.
    """
    import joblib
    n_jobs = _resolve_n_jobs(config)
    physical, logical, ram_gb = _detect_system()
    joblib.parallel_config(
        backend="loky",
        n_jobs=n_jobs,
        inner_max_num_threads=1,
    )
    label = "sequential" if n_jobs == 1 else f"{n_jobs} parallel jobs"
    logging.info(
        "Parallelism: %s (system: %d physical / %d logical cores, "
        "%.1f GB RAM; BLAS pinned to 1 thread per worker)",
        label, physical, logical, ram_gb)
    return n_jobs

def main(config_path, result_holder=None, cancel_event=None,
         preloaded_signal=None, manual_hooks=None):
    '''
    Main function - prepare analyses.

    Parameters
    ----------
    config_path: str
        Path to config.
    result_holder: dict or None
        If provided, preprocessing results are cached here so the GUI
        can rerun individual analyses without re-preprocessing.
    cancel_event: threading.Event or None
        If set, the pipeline will check this and raise InterruptedError.
    preloaded_signal: tuple (mne.Raw, dict) or None
        If provided, skip read_file and use this (signal, events_desc_id)
        pair directly. The signal is copied before use.
    manual_hooks: dict or None
        Callables for interactive review steps that cannot run in the
        pipeline's worker thread (e.g. ``signal.plot(block=True)`` must
        be on the GUI main thread on macOS). Keys currently supported:
        ``"bad_channels"``. Each hook receives the staged signal and
        must return a list of channel names to mark as bad. When
        ``None`` (CLI), the pipeline falls back to its in-process
        interactive plot — fine when running from a terminal.
    '''

    # file with parameters for everything - during process program will add few parameters
    # for other parts of analysis (like sfreq or tags), so we will hold original config
    config_raw = read_config_file(config_path)
    if manual_hooks:
        config_raw["_manual_hooks"] = manual_hooks

    # Apply global parallelism policy before any MNE / joblib work.
    _configure_parallelism(config_raw)

    if "input_path" in config_raw.keys():
        if os.path.isdir(config_raw["input_path"]):  # what user gave - path to directory with files or path to specific file
            list_of_filepaths = find_file_paths(config_raw["input_path"])
        else:
            list_of_filepaths = [config_raw["input_path"]]  # list of files with signals
    else:
        raise ValueError('Provide "input_path" in the config file - this is the path to the data '
                 '(for example path to BrainTech data: C:\\Users\\User1\\raw_data.raw) or to the directory with data '
                 '(for example: C:\\Users\\User1\\rabbit_eeg_data).')

    if "output_path" in config_raw.keys():
        output_path_raw = config_raw["output_path"]  # path for output data
    else:
        raise ValueError('Provide "output_path" in the config file to the directory for output files (tables, plots etc.)'
                 ' - it should be path to folder (like C:\\Users\\User1\\output_data) or None (then it takes path from '
                 'the input).')

    logging.info("Signals found:\n    * " + "\n    * ".join(list_of_filepaths) + ".\n")

    _preflight_check_cli(config_raw)

    def _check_cancel():
        if cancel_event is not None and cancel_event.is_set():
            logging.info("Pipeline cancelled by user.")
            raise InterruptedError("Pipeline cancelled by user")

    # Per-file failure summary so the user can see at a glance which
    # files succeeded and which didn't, instead of one bad file
    # aborting the whole batch.
    file_failures = []

    for filepath in list_of_filepaths:
        _check_cancel()

        logging.info(f"Starting work with {filepath}. \n         "
              f"Process started: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}.\n")
        try:
            _process_one_file(
                filepath, config_raw, output_path_raw, preloaded_signal,
                cancel_event, result_holder)
        except InterruptedError:
            # User-initiated cancel — abort the whole batch, don't
            # skip to next file.
            raise
        except Exception as exc:
            logging.error("Pipeline failed for %s: %s",
                          filepath, exc, exc_info=True)
            file_failures.append((filepath, exc))
            continue

    if file_failures:
        logging.warning(
            "Batch finished with %d/%d files failed:",
            len(file_failures), len(list_of_filepaths))
        for fp, exc in file_failures:
            logging.warning("  - %s: %s", fp, exc)
        # Re-raise the last failure when no file succeeded — one-file
        # CLI runs and small batches where everything failed should
        # surface as a hard error (matches pre-batch-tolerance
        # behaviour expected by test_r1_toml_*).  Larger batches with
        # at least one success keep the warning summary and return
        # normally so partial output isn't lost.
        if len(file_failures) == len(list_of_filepaths):
            raise file_failures[-1][1]


def _process_one_file(filepath, config_raw, output_path_raw,
                      preloaded_signal, cancel_event, result_holder):
    """Body of the per-file loop, extracted so the caller can wrap
    each iteration in try/except without indenting 100+ lines."""
    config = copy.deepcopy(config_raw)
    config["_input_dir"] = os.path.dirname(os.path.abspath(filepath))
    config["_input_file_name"] = os.path.basename(filepath)

    # _____READING FILES_____
    if preloaded_signal is not None:
        signal, events_desc_id = preloaded_signal
        signal = signal.copy()  # don't mutate the cached version
        logging.info("Using pre-loaded signal (skipping file read).")
    else:
        signal, events_desc_id = read_file(filepath)  # reading files

    # if [None, None] is output of read_file, then something is wrong with input files
    if signal is None and events_desc_id is None:
        raise RuntimeError(
            f"Cannot read signal from {filepath!r}. "
            f"Check that the file exists and is in a supported format "
            f"(.raw, .vhdr, .fif, .set, .edf, .bdf).")

    # Apply user-specified channel type overrides, if any. These
    # take effect AFTER the automatic name-based heuristic has
    # already run inside read_file, so the user's decisions always
    # win over readmanager's / MNE's inference.
    type_overrides = config.get("choosing_channels", {}).get(
        "type_overrides", {})
    if type_overrides:
        _apply_type_overrides(signal, type_overrides)
        logging.info(
            "Applied %d channel type override(s) from config",
            len(type_overrides))

    # Output convention (see ide4eeg.OUTPUT_DIR_PREFIX):
    #   <output_root>/<OUTPUT_DIR_PREFIX><filename_core>/preprocessing/
    #   <output_root>/<OUTPUT_DIR_PREFIX><filename_core>/analysis/
    # output_root defaults to the input signal directory.
    if output_path_raw in [None, "None", ""]:
        output_path, file_name = os.path.split(filepath)
    else:
        _, file_name = os.path.split(filepath)
        os.makedirs(output_path_raw, exist_ok=True)
        output_path = output_path_raw

    # Strip all extensions: "dataset_I.obci.raw" → "dataset_I"
    while "." in file_name:
        file_name = os.path.splitext(file_name)[0]

    # Determine explicit output paths from config (if any).
    explicit_preproc = config.get("preprocessing_output_path", "").strip()
    explicit_analysis = config.get("analysis_output_path", "").strip()

    if explicit_preproc and explicit_analysis:
        # Both paths explicit — use as-is.
        preproc_output_path = explicit_preproc
        analysis_output_path = explicit_analysis
    else:
        out_dir = os.path.join(
            output_path, f"{OUTPUT_DIR_PREFIX}{file_name}")
        os.makedirs(out_dir, exist_ok=True)

        if not config.get("overwrite_output", False):
            from .preprocessing.channels_and_signal import (
                get_segmentation_mode)
            mode = get_segmentation_mode(config)
            out_dir = os.path.join(
                out_dir,
                f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{mode}")
            os.makedirs(out_dir, exist_ok=True)

        preproc_output_path = explicit_preproc or os.path.join(out_dir, "preprocessing")
        analysis_output_path = explicit_analysis or os.path.join(out_dir, "analysis")

    logging.info(f"Output files and plots you can find in the {analysis_output_path}.")

    if not os.path.isdir(preproc_output_path):
        os.makedirs(preproc_output_path, exist_ok=True)
    if not os.path.isdir(analysis_output_path):
        os.makedirs(analysis_output_path, exist_ok=True)

    # Expose output paths so downstream analyses (e.g. TF stats)
    # can locate artefacts from prior runs (e.g. MP books).
    config["_preproc_output_path"] = preproc_output_path
    config["_analysis_output_path"] = analysis_output_path

    # _____PREPROCESSING_____
    if cancel_event is not None and cancel_event.is_set():
        raise InterruptedError("Pipeline cancelled by user")
    config["_cancel_event"] = cancel_event
    logging.info(f"Preparing preprocessing for {filepath}.  \n         {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}.\n")
    rest, rest_clean, epochs, epochs_clean, tags_desc_id, data, config = preprocessing(signal, config, preproc_output_path, events_desc_id, file_name)

    # Cache preprocessing results for individual analysis reruns
    if result_holder is not None:
        result_holder.update({
            "rest": rest, "rest_clean": rest_clean,
            "epochs": epochs, "epochs_clean": epochs_clean,
            "data": data, "config": config,
            "path": analysis_output_path,
            "tags_desc_id": tags_desc_id,
            "file_name": file_name,
        })

    # ______ANALYSIS_______
    if cancel_event is not None and cancel_event.is_set():
        raise InterruptedError("Pipeline cancelled by user")
    logging.info(f"Preparing analysis for {filepath}.  \n         {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}.\n")
    analysis(rest, rest_clean, epochs, epochs_clean, data, config, analysis_output_path, tags_desc_id, file_name)

    logging.info(f"Ending work with {filepath}.  \n         Process ended: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}.\n")