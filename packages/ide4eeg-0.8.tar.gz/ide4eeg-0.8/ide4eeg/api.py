"""Public API for IDE4EEG.

Provides clean, keyword-argument functions that wrap the internal
pipeline steps.  Each function corresponds to a GUI preprocessing or
analysis step and can be called from a standalone Python script.

Quick start::

    import sys
    sys.path.insert(0, "/path/to/ide4eeg")  # adjust to your install

    from ide4eeg.api import read_file, resample_signal, filter_signal, run_file

    # Full pipeline (equivalent to ``python run.py --run config.toml``):
    results = run_file("recording.vhdr", output_path="out/", mode="epochs",
                       resample_freq=256, highpass=0.5, lowpass=30.0)

    # Or call individual steps:
    signal, events = read_file("recording.vhdr")
    signal = resample_signal(signal, freq=256)
    signal = filter_signal(signal, highpass=0.5, lowpass=30.0)
"""

import copy
import logging
import os
import textwrap
import tempfile
from collections import namedtuple
from datetime import datetime

# ── Internal imports ─────────────────────────────────────────────

from . import OUTPUT_DIR_PREFIX
from .input.input import (
    _apply_type_overrides,
    read_file,                       # re-exported as public API
    check_and_prepare_config,
    find_file_paths,
)
from .preprocessing.channels_and_signal import (
    _resample_signal,
    _trim_signal,
    _select_channels,
    _set_montage,
    _filter_signal,
    _build_event_dict,
    _add_rest_markers,
    _find_bad_channels,
    get_segmentation_mode,
)
from .preprocessing.ica import fit_and_apply_ica
from .preprocessing.artifacts import (
    _detect_eeg_artifacts, _detect_gaze_artifacts)
from .preprocessing.rest_and_epochs import (
    _dirty_segment_ids,
    _cut_segments,
    _remove_bad_segments,
    _check_segments,
    _save_segments,
    _prepare_dataframe,
)
from .preprocessing.preprocessing import preprocessing
from .analysis.analysis import analysis


# ── Result container ─────────────────────────────────────────────

Results = namedtuple("Results", [
    "rest", "rest_clean",
    "epochs", "epochs_clean",
    "data",              # pandas DataFrame — per-segment statistics
    "config",            # final config dict (with runtime metadata)
    "tags_desc_id",      # event name → STIM value mapping
    "file_name",         # input file stem (no extension)
    "preproc_path",      # output directory for preprocessing artifacts
    "analysis_path",     # output directory for analysis results
])


# ═════════════════════════════════════════════════════════════════
#  Individual step wrappers
# ═════════════════════════════════════════════════════════════════

def resample_signal(signal, freq=256):
    """Resample *signal* to *freq* Hz.  Pass 0 to keep the original rate."""
    return _resample_signal(signal, {"resample_freq": freq})


def trim_signal(signal, start=0.0, end=None):
    """Crop *signal* to [*start*, *end*] seconds.

    Parameters
    ----------
    start : float
        Start time in seconds (default 0).
    end : float or None
        End time in seconds.  ``None`` keeps to the end of the signal.
    """
    sig, _ = _trim_signal(signal, {"trim_start": start, "trim_end": end})
    return sig


def filter_signal(signal, highpass=0.0, lowpass=0.0, notch=0.0,
                  method="iir", path=None):
    """Apply band-pass and/or notch filter.

    Parameters
    ----------
    highpass : float
        High-pass cutoff in Hz (0 = disabled).
    lowpass : float
        Low-pass cutoff in Hz (0 = disabled).
    notch : float
        Notch center frequency in Hz (0 = disabled).
    method : str
        ``"iir"`` (scipy, default) or ``"fir"`` (MNE).
    path : str or None
        Directory for optional filter-response plots.  ``None`` uses a
        temporary directory.
    """
    if path is None:
        path = tempfile.gettempdir()
    cfg = {"filters": {
        "method": method,
        "highpass_freq": highpass,
        "lowpass_freq": lowpass,
        "notch_freq": notch,
        "show_filt": False,
        "plot_filt": False,
    }}
    return _filter_signal(signal, cfg, path)


def set_montage(signal, layout="10-20", reference=None):
    """Set electrode montage and optionally re-reference.

    Parameters
    ----------
    layout : str
        MNE montage name (e.g. ``"10-20"``, ``"standard_1005"``).
    reference : str, list, or None
        - ``None`` — keep original reference.
        - ``"average"`` — Common Average Reference (CAR).
        - ``"REST"`` — infinity reference (REST).
        - ``["M1", "M2"]`` — specific reference channels.
    """
    if reference is None:
        reference = "None"
    cfg = {
        "electrodes_layout": layout,
        "re_reference": reference,
        "choosing_channels": {},
    }
    return _set_montage(signal, cfg)


def remove_eog_ica(signal, path=None, file_name="signal",
                   method="picard", n_components="rank",
                   selector="iclabel", iclabel_keep=None,
                   fit_highpass_hz=1.0, reject_uv=500.0,
                   decim=1, random_state=42,
                   find_bads_eog_ch=None, save=False):
    """Remove artifact components via ICA.

    Picard + ICLabel by default.  Returns the cleaned signal.
    See ``ide4eeg/preprocessing/ica.py`` for the full parameter set.
    """
    if path is None:
        path = tempfile.gettempdir()
    cfg = {"ICA_EOG": {
        "method": method,
        "n_components": n_components,
        "selector": selector,
        "iclabel_keep": list(iclabel_keep)
            if iclabel_keep is not None else ["brain", "other"],
        "fit_highpass_hz": fit_highpass_hz,
        "reject_uv": reject_uv,
        "decim": decim,
        "random_state": random_state,
        "find_bads_eog_ch": list(find_bads_eog_ch)
            if find_bads_eog_ch is not None else ["Fp1", "Fp2", "Fpz"],
        "save": save,
    }}
    return fit_and_apply_ica(signal, cfg, path, file_name)


def select_channels(signal, dropped=None, selected="all",
                    check=False):
    """Select or drop channels.

    Parameters
    ----------
    dropped : list or None
        Channel names to drop.
    selected : str or list
        ``"all"`` keeps every remaining channel, or pass a list of names.
    check : bool
        If ``True``, opens an interactive window for manual review.
    """
    if dropped is None:
        dropped = []
    cfg = {"choosing_channels": {
        "dropped_channels": dropped,
        "selected_channels": selected,
        "check_final_channels": check,
    }}
    results = _select_channels([signal], {}, cfg)
    return results[0]


def find_bad_channels(signal, tags_desc_id=None, path=None,
                      file_name="signal", method="auto"):
    """Auto-detect and exclude bad (noisy / flat) channels.

    Parameters
    ----------
    method : str
        ``"auto"`` for automatic detection, ``"manual"`` for interactive.

    Returns
    -------
    signal : mne.io.Raw
        Signal with bad channels excluded.
    bad_channels : list
        Names of the channels that were removed.
    """
    if tags_desc_id is None:
        tags_desc_id = {}
    if path is None:
        path = tempfile.gettempdir()
    cfg = check_and_prepare_config({
        "choosing_channels": {
            "choose_bad_channels": method,
            "bad_channels": list(signal.info.get("bads", [])),
        },
        "re_reference": "None",
        "filters": {},
        "artifacts": {},
        "ICA_EOG": {},
        "epochs": {},
    })
    cfg = _find_bad_channels(signal, cfg, tags_desc_id, path, file_name)
    bad = cfg["choosing_channels"]["bad_channels"]
    signal = signal.copy()
    signal.info["bads"] = bad
    signal.pick(picks=None, exclude="bads")
    return signal, bad


# ═════════════════════════════════════════════════════════════════
#  Full pipeline
# ═════════════════════════════════════════════════════════════════

def run_file(input_path, output_path=None, overwrite=True,
             run_analysis=True, **config_overrides):
    """Run the full IDE4EEG pipeline on a single file.

    Equivalent to ``python run.py --run config.toml`` but from Python,
    with keyword arguments instead of a TOML file.

    Parameters
    ----------
    input_path : str
        Path to the EEG signal file (.raw, .vhdr, .fif, .set, .edf, .bdf).
    output_path : str or None
        Root output directory.  ``None`` = same directory as the input file.
    overwrite : bool
        If ``True``, reuse the same output directory (no timestamp subdirs).
    run_analysis : bool
        If ``True`` (default), run the analysis step after preprocessing.
    **config_overrides
        Any configuration keys to override, e.g.::

            run_file("data.vhdr",
                     resample_freq=256,
                     segmentation={"mode": "epochs"},
                     prepare_eeg_profiles=True,
                     filters={"highpass_freq": 0.5, "lowpass_freq": 30.0})

    Returns
    -------
    Results
        Named tuple with ``rest``, ``rest_clean``, ``epochs``,
        ``epochs_clean``, ``data``, ``config``, ``tags_desc_id``,
        ``file_name``, ``preproc_path``, ``analysis_path``.
    """
    # Ensure logging is configured so the pipeline emits progress
    # messages.  When called from run.py, setup_logging has already
    # been called; when called from a user script, it hasn't.
    if not logging.getLogger().handlers:
        from .utils.log import setup_logging
        setup_logging(logging.INFO)

    # Build config from defaults + overrides
    cfg = {
        "input_path": input_path,
        "output_path": output_path or "",
        "overwrite_output": overwrite,
    }
    cfg.update(config_overrides)
    # Seed required nested dicts so check_and_prepare_config can fill defaults
    for key in ("choosing_channels", "filters", "artifacts", "ICA_EOG", "epochs"):
        cfg.setdefault(key, {})
    cfg.setdefault("re_reference", "None")
    cfg.setdefault("electrodes_layout", "standard_1020")
    cfg.setdefault("baseline", "None")
    cfg.setdefault("resample_freq", 0)
    # Seed preprocessing defaults that the pipeline expects
    cc = cfg["choosing_channels"]
    cc.setdefault("choose_bad_channels", "auto")
    cc.setdefault("dropped_channels", [])
    cc.setdefault("selected_channels", "all")
    cc.setdefault("check_final_channels", False)
    cfg["ICA_EOG"].setdefault("choose_bad_ICA_source", "auto")
    # Seed analysis boolean flags (pipeline accesses directly)
    for flag in ("prepare_eeg_profiles",
                 "prepare_connectivity_analysis", "prepare_dipole_fitting",
                 "prepare_tf_statistics"):
        cfg.setdefault(flag, False)
    # Seed analysis sub-dicts with required keys
    td = cfg.setdefault("time_domain", {})
    td.setdefault("cluster_test", {
        "step_down_p": 0.05, "n_permutations": 1024})
    # Disable interactive review prompts — scripts run non-interactively.
    # Users who want interactive review can pass check_rest=True or
    # check_epochs=True explicitly (or use ``python run.py --run config.toml``).
    cfg.setdefault("rest", {}).setdefault("check_rest", False)
    cfg.setdefault("epochs", {}).setdefault("check_epochs", False)
    # Seed mode-specific defaults
    mode = get_segmentation_mode(cfg)
    if mode == "rest":
        rest = cfg.setdefault("rest", {})
        rest.setdefault("rest_duration", [0, None])
        rest.setdefault("window_length", 20)  # match DEFAULT_CONFIG
    elif mode == "epochs":
        from ide4eeg.gui_config import DEFAULT_CONFIG as _DC
        _ep_defaults = _DC.get("epochs", {})
        epochs = cfg.setdefault("epochs", {})
        epochs.setdefault("tags", {"selected": []})
        epochs.setdefault("start_offset", _ep_defaults.get("start_offset", -0.3))
        epochs.setdefault("stop_offset", _ep_defaults.get("stop_offset", 0.7))
    cfg = check_and_prepare_config(cfg)

    # Inject runtime metadata
    filepath = os.path.abspath(input_path)
    cfg["_input_dir"] = os.path.dirname(filepath)
    cfg["_input_file_name"] = os.path.basename(filepath)

    # Derive file_name (strip all extensions)
    file_name = os.path.basename(filepath)
    while "." in file_name:
        file_name = os.path.splitext(file_name)[0]

    # Setup output directories
    if not output_path or output_path in ("None", ""):
        out_root = os.path.dirname(filepath)
    else:
        out_root = output_path
        os.makedirs(out_root, exist_ok=True)

    out_dir = os.path.join(out_root, f"{OUTPUT_DIR_PREFIX}{file_name}")
    os.makedirs(out_dir, exist_ok=True)

    if not overwrite:
        _mode = get_segmentation_mode(cfg)
        out_dir = os.path.join(
            out_dir,
            f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{_mode}")
        os.makedirs(out_dir, exist_ok=True)

    preproc_path = cfg.get("preprocessing_output_path", "").strip()
    analysis_path_cfg = cfg.get("analysis_output_path", "").strip()
    preproc_path = preproc_path or os.path.join(out_dir, "preprocessing")
    analysis_path = analysis_path_cfg or os.path.join(out_dir, "analysis")
    os.makedirs(preproc_path, exist_ok=True)
    os.makedirs(analysis_path, exist_ok=True)

    cfg["_preproc_output_path"] = preproc_path
    cfg["_analysis_output_path"] = analysis_path

    # Read signal
    signal, events_desc_id = read_file(filepath)
    if signal is None:
        raise RuntimeError(
            f"Cannot read signal from {filepath!r}. "
            f"Check file format (.raw, .vhdr, .fif, .set, .edf, .bdf).")

    # Apply global parallelism policy (joblib n_jobs + BLAS pinning).
    # main.py:main() does this for CLI runs; run_file() must do it too
    # so scripts respect parallelism.n_jobs.
    from .main import _configure_parallelism
    _configure_parallelism(cfg)

    # Apply user-specified channel type overrides (post-inference)
    type_overrides = cfg.get("choosing_channels", {}).get(
        "type_overrides", {})
    if type_overrides:
        _apply_type_overrides(signal, type_overrides)

    # Preprocessing
    rest, rest_clean, epochs, epochs_clean, tags, data, cfg = \
        preprocessing(signal, cfg, preproc_path, events_desc_id, file_name)

    # Analysis
    if run_analysis:
        analysis(rest, rest_clean, epochs, epochs_clean, data, cfg,
                 analysis_path, tags, file_name)

    return Results(
        rest=rest, rest_clean=rest_clean,
        epochs=epochs, epochs_clean=epochs_clean,
        data=data, config=cfg, tags_desc_id=tags,
        file_name=file_name,
        preproc_path=preproc_path, analysis_path=analysis_path,
    )


# ═════════════════════════════════════════════════════════════════
#  Script generator
# ═════════════════════════════════════════════════════════════════

def _diff_config(config, defaults):
    """Return a dict containing only keys in *config* that differ from *defaults*.

    Recurses into nested dicts.  Skips keys starting with ``_`` (runtime
    metadata) and empty-string path values that match the default.
    """
    diff = {}
    for key, val in config.items():
        if key.startswith("_"):
            continue
        if key not in defaults:
            # Key not in defaults — always include
            diff[key] = val
            continue
        dval = defaults[key]
        if isinstance(val, dict) and isinstance(dval, dict):
            sub = _diff_config(val, dval)
            if sub:
                diff[key] = sub
        elif val != dval:
            diff[key] = val
    return diff


def generate_script(config, defaults, repo_path=None):
    """Generate a self-contained Python script from a config dict.

    Parameters
    ----------
    config : dict
        Full configuration (e.g. from GUI ``_collect_config()``).
    defaults : dict
        Default configuration to diff against (only non-default values
        are emitted).
    repo_path : str or None
        Absolute path to the ide4eeg repository root.  Embedded in the
        script's ``sys.path`` line.  ``None`` uses the current working
        directory.

    Returns
    -------
    str
        Complete Python script as a string.
    """
    if repo_path is None:
        repo_path = os.getcwd()

    diff = _diff_config(config, defaults)

    # ── Prune sub-configs for disabled features ────────────────
    # Gate flag → child keys that should be suppressed when the gate is off
    _FEATURE_GATES = {
        "prepare_eeg_artifacts": ["artifacts"],
        "prepare_ica": ["ICA_EOG"],
        "prepare_video_artifacts": [
            "video_reference_dir", "video_exclude_dir",
            "facetag_frame_skip", "facetag_downscale",
            "facetag_max_angle", "facetag_ref_use_roi",
            "facetag_face_tolerance", "facetag_min_interval",
            "facetag_no_face_is_artifact",
            "facetag_tracking_adapt_rate", "facetag_position_weight",
            "facetag_size_weight", "facetag_switch_resistance",
            "facetag_backend", "facetag_gaze_method", "facetag_det_size",
        ],
        "prepare_tf_statistics": ["tf_statistics"],
        "prepare_connectivity_analysis": ["connectivity"],
        "prepare_dipole_fitting": ["dipole_fitting"],
        "prepare_eeg_profiles": ["eeg_profiles"],
    }
    for gate, children in _FEATURE_GATES.items():
        if not config.get(gate, False):
            for child in children:
                diff.pop(child, None)
    # MP feature gate uses preprocessing.step_order, not a top-level
    # flag (the legacy ``prepare_mp_decomposition`` was deleted in the
    # MP-book-reuse change).  Suppress ``matching_pursuit`` from the
    # exported script when MP is not in step_order.
    from .main import mp_decomposition_enabled
    if not mp_decomposition_enabled(config):
        diff.pop("matching_pursuit", None)

    # ── Force-include critical keys that must be explicit ────
    # Algorithm determines what kind of MP book is produced (SMP vs MMP1
    # vs MMP3).  Omitting it when it matches the default "smp" creates
    # scripts that silently fail when a downstream consumer (e.g. dipole
    # fitting) requires a different algorithm.
    if "matching_pursuit" in diff:
        algo = config.get("matching_pursuit", {}).get("algorithm", "smp")
        diff["matching_pursuit"]["algorithm"] = algo

    # Suppress runtime output paths (run_file derives them automatically)
    for key in ("preprocessing_output_path", "analysis_output_path",
                "video_reference_dir"):
        diff.pop(key, None)

    input_path = config.get("input_path", "")
    output_path = config.get("output_path", "")
    mode = get_segmentation_mode(config)

    # ── Categorize diff keys ────────────────────────────────────
    # Keys handled as explicit run_file() arguments
    explicit_keys = {"input_path", "output_path", "overwrite_output"}

    # Group remaining keys by category for comments
    preproc_keys = {
        "resample_freq", "trim_start", "trim_end",
        "prepare_eeg_artifacts", "prepare_ica",
        "prepare_video_artifacts",
        "prepare_mp_filter",
        "electrodes_layout", "re_reference", "baseline",
        "filters", "ICA_EOG", "choosing_channels", "artifacts",
        "matching_pursuit", "segment_rejection",
        "preprocessing",
        "amplitude_max_threshold", "amplitude_time_threshold",
        "amplitude_nchan_threshold",
    }
    mode_keys = {
        "segmentation", "rest", "epochs",
    }
    analysis_keys = {
        "prepare_eeg_profiles",
        "prepare_connectivity_analysis",
        "prepare_dipole_fitting", "prepare_tf_statistics",
        "time_domain",
        "connectivity", "dipole_fitting", "eeg_profiles",
        "tf_statistics", "mne_catalog", "mne_params",
    }

    def _format_value(val, indent=4):
        """Format a Python value for embedding in the script."""
        if isinstance(val, dict):
            if not val:
                return "{}"
            items = []
            for k, v in val.items():
                items.append(f"{' ' * (indent + 4)}{k!r}: {_format_value(v, indent + 4)},")
            inner = "\n".join(items)
            return "{\n" + inner + "\n" + " " * indent + "}"
        elif isinstance(val, list):
            return repr(val)
        elif isinstance(val, str):
            return repr(val)
        elif isinstance(val, bool):
            return repr(val)
        elif isinstance(val, (int, float)):
            return repr(val)
        else:
            return repr(val)

    # ── Build the kwargs for run_file() ─────────────────────────
    sections = []  # list of (comment, lines) tuples

    # Mode
    mode_lines = []
    for key in sorted(mode_keys):
        if key in diff and key not in explicit_keys:
            mode_lines.append(
                f"    {key}={_format_value(diff[key])},")
    if mode_lines:
        sections.append(("Mode", mode_lines))

    # Preprocessing
    preproc_lines = []
    for key in sorted(preproc_keys):
        if key in diff and key not in explicit_keys:
            preproc_lines.append(
                f"    {key}={_format_value(diff[key])},")
    if preproc_lines:
        sections.append(("Preprocessing", preproc_lines))

    # Analysis
    analysis_lines = []
    for key in sorted(analysis_keys):
        if key in diff and key not in explicit_keys:
            analysis_lines.append(
                f"    {key}={_format_value(diff[key])},")
    if analysis_lines:
        sections.append(("Analysis", analysis_lines))

    # Anything else
    covered = explicit_keys | preproc_keys | mode_keys | analysis_keys
    other_lines = []
    for key in sorted(diff):
        if key not in covered:
            other_lines.append(
                f"    {key}={_format_value(diff[key])},")
    if other_lines:
        sections.append(("Other", other_lines))

    # ── Assemble kwargs block ───────────────────────────────────
    kwargs_parts = []
    for comment, lines in sections:
        kwargs_parts.append(f"    # {comment}")
        kwargs_parts.extend(lines)

    kwargs_block = "\n".join(kwargs_parts)

    overwrite = config.get("overwrite_output", False)

    # Pre-compute formatted values for the f-string
    output_path_repr = repr(output_path) if output_path else "None"
    loop_output_repr = repr(output_path) if output_path else '"output/"'
    loop_kwargs = (textwrap.indent(kwargs_block, "#         ")
                   if kwargs_block.strip() else "#         ...")

    # ── Generate script ─────────────────────────────────────────
    script = f'''\
#!/usr/bin/env python3
"""IDE4EEG analysis script — generated {datetime.now().strftime("%Y-%m-%d %H:%M")}

Input:  {input_path}
Output: {output_path or "(same directory as input)"}
Mode:   {mode}

Equivalent to running the same configuration via:
    python run.py --run config.toml

Modify this script to customise the pipeline, loop over files,
or add post-processing steps.  See ide4eeg/api.py for all available
functions and their parameters.
"""

import sys
sys.path.insert(0, {repo_path!r})  # adjust if ide4eeg moves

from ide4eeg.api import run_file

results = run_file(
    {input_path!r},
    output_path={output_path_repr},
    overwrite={overwrite!r},
{kwargs_block}
)

# ── Results ──────────────────────────────────────────────────
# results.epochs_clean  — MNE Epochs (artifact-free)
# results.rest_clean    — MNE Epochs (clean rest segments)
# results.data          — pandas DataFrame (per-segment statistics)
# results.config        — dict (final config with runtime metadata)
# results.preproc_path  — str (preprocessing output directory)
# results.analysis_path — str (analysis output directory)


# ── Advanced: process multiple files ─────────────────────────
# import glob
# import pandas as pd
#
# all_stats = []
# for filepath in glob.glob("data/subject_*.vhdr"):
#     r = run_file(
#         filepath,
#         output_path={loop_output_repr},
{loop_kwargs}
#     )
#     r.data["subject"] = filepath
#     all_stats.append(r.data)
#
# pd.concat(all_stats).to_csv("group_statistics.csv")
'''
    return script
