"""Shared helpers for parallelism in IDE4EEG.

Every joblib-based parallel block in the codebase — the tf_statistics
bootstrap/permutation loops, filter/resample/TFR calls that go through
MNE's ``n_jobs=``, FOOOF group fits, and any future parallel site —
should route through the helpers in this module so users get uniform
logging, elapsed-time reporting, and Stop-button handling.

Why this module exists
----------------------
Without a shared helper, every parallel site grows its own boilerplate
for Stop-button feedback, progress logging, and elapsed-time
measurement. Worse, each site would re-derive things like
"how do I tell joblib to respect the configured n_jobs?" and drift over
time. Centralising here makes the policy one-stop: change it here,
every parallel site updates together.

See ``CONTRIBUTING.md §"Parallelism"`` for the rules callers follow.
"""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager


@contextmanager
def _notify_on_cancel(cancel_event, label: str):
    """Log a 'Stop received — waiting…' message when cancel_event fires.

    Spawns a daemon watcher thread that polls ``cancel_event`` with a
    100 ms timeout. Exits cleanly when the caller's ``with`` block
    ends, whether or not cancel fired. No-op when ``cancel_event`` is
    ``None``.

    This does NOT kill workers — that would deadlock the joblib
    generator (an earlier attempt at
    ``loky.get_reusable_executor().shutdown(kill_workers=True)``
    deadlocked when the pool was idle at kill time). It just tells the
    user "your Stop was heard, workers will exit after their current
    work unit". Together with the soft cancel check between yielded
    results, this gives acceptable UX for fast work units (e.g.
    vectorised numpy) and honest feedback for slow ones (e.g.
    million-iteration Python loops).
    """
    if cancel_event is None:
        yield
        return

    import threading as _th
    stop = _th.Event()

    def _watch():
        while not stop.is_set():
            if cancel_event.wait(timeout=0.1):
                logging.warning(
                    "  %s: Stop received \u2014 cancelling after "
                    "workers finish their current work unit. "
                    "May take up to one unit's compute time. "
                    "Partial results will be discarded.", label)
                return

    watcher = _th.Thread(target=_watch, daemon=True)
    watcher.start()
    try:
        yield
    finally:
        stop.set()
        watcher.join(timeout=0.2)


@contextmanager
def timed_parallel_block(label: str, cancel_event=None):
    """Context wrapping any parallel block (joblib or MNE ``n_jobs=``).

    Emits three log lines in the INFO / WARNING stream so users can
    see what's happening in the GUI Run tab:

    1. ``<label>: starting`` on entry
    2. ``<label>: Stop received \u2014 cancelling\u2026`` (WARNING)
       if the caller-supplied ``cancel_event`` fires while the block
       is executing
    3. ``<label>: finished in X.XXs`` on exit (whether the block
       completed or raised)

    Use around every joblib / MNE n_jobs call so users can compare
    wall-clock time across ``parallelism.n_jobs`` settings without an
    external benchmark. The cancel-notification half is a no-op when
    ``cancel_event is None`` (e.g. CLI pipeline runs, tests).

    Example::

        with timed_parallel_block("pseudo-t", cancel_event):
            results = Parallel(return_as="generator", verbose=0)(
                delayed(worker)(...) for ... in ...
            )
            for r in results:
                ...

    Parameters
    ----------
    label : str
        Short human-readable name of the block, prefixed to every
        log line. Matches existing log conventions in the pipeline
        (e.g. ``"pseudo-t"``, ``"filter"``, ``"compute_tfr"``).
    cancel_event : threading.Event or None
        The pipeline cancel event from
        ``config["_cancel_event"]``. If set while the block is
        running, a WARNING is logged to tell the user Stop was
        acknowledged. The caller is still responsible for checking
        ``cancel_event.is_set()`` itself and raising
        ``InterruptedError`` at the appropriate point — this helper
        only provides user feedback, not forced termination.
    """
    logging.info("  %s: starting", label)
    t0 = time.perf_counter()
    try:
        with _notify_on_cancel(cancel_event, label):
            yield
    finally:
        dt = time.perf_counter() - t0
        logging.info("  %s: finished in %.2fs", label, dt)


def resolve_n_jobs(config, default=1):
    """Return the effective n_jobs for this pipeline run.

    Reads ``config["parallelism"]["n_jobs"]`` with strict semantics.
    The canonical resolver lives in :func:`ide4eeg.main._resolve_n_jobs`
    and is called once per pipeline run to set the global joblib
    default via ``joblib.parallel_config``. This helper is a
    lightweight re-read for call sites that want to pass
    ``n_jobs=...`` explicitly to MNE functions (filter, resample,
    compute_psd, compute_tfr, FOOOF) — MNE defaults ``n_jobs`` to
    1, so we must pass the resolved value rather than rely on
    joblib inheritance.

    Parameters
    ----------
    config : dict
        Full pipeline config. May lack a ``"parallelism"`` section.
    default : int, optional
        Fallback when the key is missing / zero / invalid. Matches
        MNE's own default of 1 (sequential).

    Returns
    -------
    int
        Effective worker count, always >= 1.
    """
    raw = (config or {}).get("parallelism", {}).get("n_jobs", 0)
    try:
        n = int(raw)
    except (TypeError, ValueError):
        n = 0
    if n <= 0:
        from ide4eeg.main import default_n_jobs
        n = default_n_jobs()
    return max(1, n)
