"""Shared configuration, defaults, and utility functions for IDE4EEG GUIs."""

import copy
import os
import platform
import re

from ide4eeg import NATIVE_POSITIONS_SENTINEL
from ide4eeg.preprocessing.constraints import (
    DEFAULT_HARD_CONSTRAINTS as _DEFAULT_HARD_SRC,
    DEFAULT_SOFT_CONSTRAINTS as _DEFAULT_SOFT_SRC,
)
# Deep-copy so mutating DEFAULT_CONFIG doesn't touch the canonical lists
_DEFAULT_HARD = copy.deepcopy(_DEFAULT_HARD_SRC)
_DEFAULT_SOFT = copy.deepcopy(_DEFAULT_SOFT_SRC)

# TOML bare keys: ASCII letters, digits, underscore, dash only.
# Keys outside this set must be quoted (basic string) or the file
# won't parse — bug when channel / event names contain spaces,
# brackets, dots, etc.
_BARE_KEY_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _toml_key(k):
    """Format *k* as a valid TOML key (bare if possible, else quoted)."""
    s = str(k)
    if s and _BARE_KEY_RE.match(s):
        return s
    escaped = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _toml_value(v):
    """Convert a Python value to its TOML string representation."""
    if v is None:
        return '""'
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return str(v)
    if isinstance(v, str):
        escaped = v.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_toml_value(item) for item in v) + "]"
    if isinstance(v, dict):
        # Inline table  e.g. {w = 6.0}.  Keys quoted via _toml_key
        # so names with spaces/brackets/dots round-trip cleanly.
        return ("{" + ", ".join(
            f"{_toml_key(k)} = {_toml_value(val)}" for k, val in v.items()
        ) + "}")
    return repr(v)


def dump_toml(data, path):
    """Write *data* dict to a TOML file at *path*.

    Handles str, int, float, bool, list, and dict (as tables / inline tables).
    Comments from the original file are NOT preserved.
    """
    lines: list[str] = []

    def _is_inline_table(d):
        """A dict with no nested dicts is written as an inline table."""
        return all(not isinstance(v, dict) for v in d.values())

    def _write_section(d, prefix=""):
        # Write scalar keys first, then nested table keys
        for k, v in d.items():
            if not isinstance(v, dict) or _is_inline_table(v):
                lines.append(f"{_toml_key(k)} = {_toml_value(v)}")
        for k, v in d.items():
            if isinstance(v, dict) and not _is_inline_table(v):
                # Section header keys also need quoting if they have
                # special chars.  Dotted-key paths use the bare/quoted
                # forms joined with ".".
                kk = _toml_key(k)
                header = f"{prefix}.{kk}" if prefix else kk
                lines.append("")
                lines.append(f"[{header}]")
                _write_section(v, prefix=header)

    _write_section(data)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def load_toml(path):
    """Load a TOML file and return a dict."""
    import tomllib
    with open(path, "rb") as f:
        return tomllib.load(f)

def _find_svarog_jar():
    """Search common locations for the SVAROG standalone JAR.

    Checks, in order:
    1. ``SVAROG_JAR`` environment variable
    2. ``~/.obci/svarog/`` (standard install via Download button)
    3. ``~/.obci/svarog4/`` (legacy location)
    4. ``~/Desktop/SVAROG4/``
    5. ``~/SVAROG4/``
    6. Current working directory

    Returns the first matching path, or ``None``.
    """
    env = os.environ.get("SVAROG_JAR")
    if env and os.path.isfile(env):
        return env
    import glob as _glob
    for directory in [
        os.path.expanduser("~/.obci/svarog"),
        os.path.expanduser("~/.obci/svarog4"),
        os.path.expanduser("~/Desktop/SVAROG4"),
        os.path.expanduser("~/SVAROG4"),
        os.getcwd(),
    ]:
        matches = sorted(_glob.glob(os.path.join(directory, "svarog-standalone*.jar")))
        if matches:
            return matches[-1]  # newest version
    return None


def _find_empi(svarog_jar=None):
    """Locate the empi binary.

    Checks, in order:
    1. ``EMPI_PATH`` environment variable
    2. ``~/.obci/svarog/empi*`` (standard install via Download button)
    3. ``~/.obci/svarog4/empi`` (legacy location)
    4. ``mp/`` subfolder next to the SVAROG JAR (if *svarog_jar* given)

    Within the ``mp/`` directory, picks the OS-appropriate
    ``empi-*`` subdirectory (linux-x64, macos-x64, macos-arm64,
    or windows-x64) and returns the binary path.
    """
    import glob as _glob

    env = os.environ.get("EMPI_PATH")
    if env and os.path.isfile(env):
        return env

    system = platform.system().lower()   # darwin, linux, windows
    machine = platform.machine().lower() # x86_64, arm64, amd64, ...

    if system == "darwin":
        os_tag = "macos-arm64" if machine == "arm64" else "macos-x64"
    elif system == "windows":
        os_tag = "windows-x64"
    else:
        os_tag = "linux-x64"

    binary = "empi.exe" if system == "windows" else "empi"

    # Check standard install location (new: ~/.obci/svarog/, legacy: svarog4/)
    import glob as _glob2
    for svarog_dir in ["~/.obci/svarog", "~/.obci/svarog4"]:
        matches = sorted(_glob2.glob(
            os.path.expanduser(os.path.join(svarog_dir, "empi*"))))
        for m in matches:
            if os.path.isfile(m) and os.path.basename(m).startswith("empi"):
                return m

    if not svarog_jar:
        return None

    mp_dir = os.path.join(os.path.dirname(svarog_jar), "mp")
    # Try exact OS match: mp/empi-*-<os_tag>/empi
    matches = sorted(_glob.glob(
        os.path.join(mp_dir, f"empi-*-{os_tag}", binary)))
    if matches:
        return matches[-1]
    # Fallback: bare binary in mp/
    bare = os.path.join(mp_dir, binary)
    if os.path.isfile(bare):
        return bare

    return None


def _find_connectivis_jar():
    """Search common locations for the connectivis fat JAR.

    Checks, in order:
    1. ``CONNECTIVIS_JAR`` environment variable
    2. ``~/.obci/connectivis/`` (standard install via Download button)
    3. Common directories for ``connectivis.jar`` (new name) and
       ``cvis-gui-*-jar-with-dependencies.jar`` (legacy name)

    Returns the first matching path, or ``None``.
    """
    env = os.environ.get("CONNECTIVIS_JAR")
    if env and os.path.isfile(env):
        return env
    import glob as _glob
    for directory in [
        os.path.expanduser("~/.obci/connectivis"),
        os.path.expanduser("~/connecti-VIS/connectivis"),
        os.path.expanduser("~/CLAUDE/connecti-VIS/connectivis"),
        os.path.expanduser("~/connecti-VIS/cvis-gui/target"),
        os.path.expanduser("~/CLAUDE/connecti-VIS/cvis-gui/target"),
        os.path.expanduser("~/Desktop/connectivis"),
        os.path.expanduser("~/connectivis"),
        os.getcwd(),
    ]:
        candidate = os.path.join(directory, "connectivis.jar")
        if os.path.isfile(candidate):
            return candidate
        # Legacy name
        matches = sorted(_glob.glob(
            os.path.join(directory, "cvis-gui-*-jar-with-dependencies.jar")))
        if matches:
            return matches[-1]
    return None

FIELD_TOOLTIPS = {
    # -- Tool Paths -------------------------------------------------------
    "svarog_jar":
        "Path to the SVAROG standalone JAR. Used for signal viewing and MP\n"
        "Book display. Requires Java 8 or later (Java 17 recommended).\n"
        "Click the button to browse, or use Download recent.",
    "connectivis_jar":
        "Path to the ConnectiVIS JAR for 3D visualization of connectivity\n"
        "results and dipole source locations. Requires Java.\n"
        "Click the button to browse, or use Download recent.",
    "empi_path":
        "Path to the empi binary (Enhanced Matching Pursuit\n"
        "Implementation). Required for MP decomposition. Automatically\n"
        "found if SVAROG is installed in ~/.obci/svarog/.\n"
        "Click the button to browse, or use Download recent.",
    # -- Paths & General --------------------------------------------------
    "input_path":
        "Click [Input signal] to open the file dialog.\n"
        "Supported formats: .raw (BrainTech), .vhdr (BrainVision), .fif\n"
        "(MNE), .set (EEGLAB), .edf, .bdf.",
    "output_path":
        "Click [Output root] to select the output directory.\n"
        "An IDE4EEG_OUT_<filename> folder is created here with\n"
        "preprocessing/ and analysis/ subfolders.\n"
        "Defaults to the input signal folder.",
    "video_path":
        "Click [Video] to select a video file (.mp4) for gaze/face artifact\n"
        "detection.\n"
        "Auto-detected from the input file name when possible.",
    "preprocessing_output_path":
        "Directory for preprocessing outputs (resampled signal, trimmed\n"
        "signal, reference faces, etc.). Derived from output root.",
    "analysis_output_path":
        "Directory for analysis outputs (plots, tables, etc.). Derived from\n"
        "output root.",
    "segmentation.mode":
        "Segmentation mode:\n"
        "• rest — timed windows: the signal is cut into fixed-length\n"
        "  windows at regular intervals. No event markers needed. Use for\n"
        "  resting-state EEG, sleep, or continuous recordings.\n"
        "• epochs — event-locked: segments are cut around stimulus markers\n"
        "  (trigger events) in the EEG file. Use for P300, ERP, and any\n"
        "  stimulus-response paradigm.",
    "overwrite_output":
        "If enabled, previous output is overwritten. If disabled, each run\n"
        "creates a new timestamped folder.",
    "parallelism.n_jobs":
        "Number of parallel work units for filter/resample/ICA,\n"
        "compute_psd/compute_tfr, and connectivity bootstraps.\n"
        "Each worker is pinned to 1 BLAS thread via\n"
        "joblib.parallel_config(inner_max_num_threads=1), so total CPU load\n"
        "equals this number — no silent oversubscription.\n"
        "Default is 1 (sequential), matching MNE's own convention: the\n"
        "library does not take cores from you unless you explicitly ask.\n"
        "Type 2 or more to opt into parallelism.\n"
        "Each joblib/loky worker is a separate Python interpreter (~200–300\n"
        "MB baseline after numpy/scipy import) plus working memory for the\n"
        "task — start with 2 and raise gradually while monitoring RAM\n"
        "usage.\n"
        "MP decomposition inherits this same value by default (see\n"
        "matching_pursuit.cpu_workers for per-module override). Does NOT\n"
        "affect dipole fitting (separate cpu_workers field).",

    # -- Preprocessing ----------------------------------------------------
    "_enable_stim":
        "Build the event_id mapping from selected events (event-locked) or\n"
        "synthetic markers (timed windows).\n"
        "Required for segmentation and all further analysis — cannot be\n"
        "disabled.",
    "resample_freq":
        "Target sampling frequency in Hz. The signal is downsampled if its\n"
        "native rate is higher. Default 512 Hz.",
    "prepare_eeg_artifacts":
        "Master flag for EEG artifact preprocessing (used internally).\n"
        "Individual steps are controlled by their own checkboxes.",
    "prepare_ica":
        "Enable ICA-based artifact removal (e.g. eye blinks).",
    "prepare_video_artifacts":
        "Detect intervals where the subject is not looking at the screen.\n"
        "Requires a video file with the same name as the EEG file in the\n"
        "same folder (e.g. subject01.vhdr → subject01.mp4/.mkv).\n"
        "Also requires a reference photo directory (see below).",
    "video_reference_dir":
        "Directory with 3-5 photos of the subject LOOKING AT THE CAMERA.\n"
        "\n"
        "These photos serve two purposes:\n"
        "1. IDENTITY — which face in the video is the subject\n"
        "2. GAZE CALIBRATION — what direction counts as 'looking at screen'\n"
        "\n"
        "The gaze vector from these photos defines the reference direction.\n"
        "If the subject is looking sideways in the reference photo, the\n"
        "system will learn 'sideways = looking at screen' — wrong!\n"
        "\n"
        "Always select frames where the subject is clearly looking at the\n"
        "camera/screen. Use 'Select faces...' to pick frames from the\n"
        "video.",
    "video_exclude_dir":
        "Directory with photos of faces to EXCLUDE (e.g. mother, clinician\n"
        "visible in the recording).\n"
        "\n"
        "Used for identity only — the subject in these photos can be\n"
        "looking in any direction, any angle. Only the face identity\n"
        "encoding is used (not gaze direction).\n"
        "\n"
        "Detected faces closer to an exclude reference than to the subject\n"
        "are rejected. Leave empty to disable exclusion.",
    "facetag_frame_skip":
        "Process every Nth video frame (default 3).\n"
        "Skipped frames inherit the last result.\n"
        "Values of 3–5 give a good speed/accuracy trade-off\n"
        "at 30 fps; 1 = every frame.",
    "facetag_detection_skip":
        "Re-run InsightFace face detection every Nth processed\n"
        "frame (default 3). Between detections, the previous\n"
        "bounding box is reused — saves ~60% of detection time\n"
        "with minimal accuracy loss when the subject isn't moving\n"
        "fast. Set 1 to detect on every frame (slower, highest\n"
        "accuracy).",
    "facetag_downscale":
        "Resize factor before face detection (default 1.0 = full). Use 0.5\n"
        "for half resolution. Faster but may miss small faces.",
    "facetag_max_angle":
        "Maximum acceptable gaze deviation [°] from the reference\n"
        "direction.\n"
        "Smaller = stricter (more 'not looking' detections). Default 20.",
    "facetag_ref_use_roi":
        "Compute reference gaze vectors from the cropped face region\n"
        "instead of the full photo.\n"
        "Uses the same input format as runtime detection for consistency.",
    "facetag_face_tolerance":
        "Maximum distance for face encoding match. Default 0.6.\n"
        "Lower = stricter (fewer false matches, may miss the subject).\n"
        "Higher = more lenient (finds subject more often, may match\n"
        "others).",
    "facetag_min_interval":
        "Minimum duration [s] for a 'not looking' interval.\n"
        "Intervals shorter than this are discarded as noise. Default 0\n"
        "(keep all).",
    "facetag_no_face_is_artifact":
        "When enabled (default): frames where no face is detected are\n"
        "classified as 'not looking'.\n"
        "When disabled: no-face frames inherit the previous frame's state.",
    "facetag_tracking_adapt_rate":
        "How fast the face tracker adapts to appearance changes (e.g. head\n"
        "turning).\n"
        "Higher = adapts faster but may drift to the wrong face.\n"
        "Lower = more stable but slower to follow pose changes.\n"
        "Range 0.0–1.0, default 0.5.",
    "facetag_position_weight":
        "How strongly the tracker prefers the face near the last known\n"
        "position.\n"
        "Higher = harder to jump to a different location.\n"
        "Helps when encoding becomes ambiguous (e.g. head turned). Default\n"
        "0.4.",
    "facetag_size_weight":
        "How strongly the tracker prefers a face of similar size.\n"
        "Useful when the subject sits at a fixed distance from the camera.\n"
        "Default 0.2.",
    "facetag_switch_resistance":
        "Extra cost for switching to a different face.\n"
        "Higher = stronger lock on the current face, less likely to jump to\n"
        "another person.\n"
        "Default 0.25.",
    "facetag_backend":
        "Face detection/encoding backend (InsightFace: RetinaFace +\n"
        "ArcFace).",
    "facetag_gaze_method":
        "Gaze estimation method:\n"
        "• L2CS-Net (default) — dedicated eye-gaze direction\n"
        "  network (ResNet50, 3.92° MAE on MPIIGaze). Measures\n"
        "  where the eyes are actually looking. Requires PyTorch\n"
        "  (~2 GB) and adds ~20 ms per frame.\n"
        '  Install via the Config tab Download button, or\n'
        '  pip install torch "l2cs @\n'
        '  git+https://github.com/Ahmednull/L2CS-Net.git@main"\n'
        "• InsightFace — head-pose only (where the head is\n"
        "  pointing; eyes can still be looking elsewhere).\n"
        "  Reuses the 5 facial keypoints from Stage 1 face\n"
        "  detection, so no extra dependency. Use as a fallback\n"
        "  when PyTorch is unavailable or L2CS fails on a\n"
        "  particular video.",
    "facetag_gaze_smoothing":
        "Temporal smoothing (EMA alpha, 0–1).\n"
        "0 = off (default), 0.3 = moderate, 0.1 = heavy.\n"
        "Reduces gaze jitter for InsightFace and L2CS-Net.",
    "facetag_det_size":
        "InsightFace detection resolution. The input frame is resized to\n"
        "this width/height (square) before the face detector runs.\n"
        "0 = full frame resolution (best quality, slower — use when faces\n"
        "are small).\n"
        "640 = InsightFace default (fast, good for close-up faces).\n"
        "Higher = detects smaller faces more reliably, but slower and more\n"
        "memory.",
    "trim_start":
        "Start time [s] for signal trimming. Signal before this time is\n"
        "cropped.\n"
        "Use to skip a pre-task rest period or equipment settle time.\n"
        "Default 0.",
    "trim_end":
        "End time [s] for signal trimming. Signal after this time is\n"
        "cropped.\n"
        "Leave empty to keep to the end of the signal.",

    # -- Analysis ---------------------------------------------------------
    "prepare_eeg_profiles":
        "Time-evolution profiles of EEG graphoelements detected in MP\n"
        "atoms: sleep spindles, alpha waves, delta waves, K-complexes, etc.\n"
        "(FASP method).\n"
        "Requires an SMP MP decomposition book.\n"
        "Useful for vigilance tracking, sleep / arousal characterisation,\n"
        "and long-recording analysis.",
    "segment_rejection.enabled":
        "Reject segments based on peak-to-peak amplitude.\n"
        "Runs after segment cutting, before analysis. Segments where any\n"
        "EEG channel's amplitude range (max − min) exceeds the threshold\n"
        "are dropped.\n"
        "\n"
        "Set reject threshold [µV] manually, or use 0 for automatic\n"
        "detection (percentile-based: the top N% of PTP values become the\n"
        "threshold).",
    "prepare_connectivity_analysis":
        "Brain connectivity analysis using MVAR (Multivariate\n"
        "Autoregressive) models.\n"
        "Computes directed/undirected measures: DTF, gDTF, PDC, Coherence,\n"
        "PSI, GCI, AEC.\n"
        "Based on ConnectiviPy (GSoC 2015 / INCF).",
    "connectivity.methods":
        "Comma-separated connectivity methods to compute.\n"
        "\n"
        "AR-based (require MVAR model):\n"
        "  dtf, gdtf, ffdtf, ddtf — Directed Transfer Function variants\n"
        "  pdc, gpdc, ipdc — Partial Directed Coherence variants\n"
        "  pcoh — Partial Coherence\n"
        "\n"
        "Signal-based (no MVAR model needed):\n"
        "  coh — Complex Coherency\n"
        "  psi — Phase Slope Index\n"
        "  gci — Granger Causality Index\n"
        "  aec — Amplitude Envelope Correlation\n"
        "\n"
        "Default: gdtf (Generalized DTF).",
    "connectivity.mvar_method":
        "MVAR model fitting algorithm:\n"
        "• yw — Yule-Walker (fast, classic)\n"
        "• ns — Nuttall-Strand (numerically stable)\n"
        "• vm — Vieira-Morf (high accuracy, slower)",
    "connectivity.mvar_order":
        "AR model order (0 = auto-detect using Akaike criterion).",
    "connectivity.resolution":
        "Frequency resolution for spectral connectivity estimation. Default\n"
        "100.",
    "connectivity.channels":
        "Select which channels to include in connectivity analysis.\n"
        "By default all channels are used.\n"
        "Fewer channels = faster MVAR fitting and more reliable estimates.",
    "connectivity.short_time":
        "Compute time-resolved connectivity using a sliding window.\n"
        "Produces time × frequency images for each channel pair.",
    "connectivity.st_window":
        "Sliding window length in seconds. 0 = automatic (signal length /\n"
        "5).",
    "connectivity.st_overlap":
        "Sliding window overlap in seconds. 0 = automatic (signal length /\n"
        "10).",
    "connectivity.significance":
        "Run surrogate (single-trial) or bootstrap (multi-trial)\n"
        "significance testing.\n"
        "Shuffles data and recomputes to establish chance-level thresholds.",
    "connectivity.sig_reps":
        "Number of surrogate/bootstrap replications. More = more reliable\n"
        "thresholds, but slower. Default 100.",
    "connectivity.sig_alpha":
        "Significance level (α). Default 0.05. Values above the (1-α)\n"
        "percentile of surrogates are significant.",
    "prepare_mp_filter":
        "Reconstruct the signal from selected MP atoms, filtering by\n"
        "frequency, scale, or energy.\n"
        "Non-linear alternative to band-pass filtering that preserves\n"
        "transient structures.",
    "prepare_dipole_fitting":
        "Fit equivalent current dipoles to MMP macroatoms using the MNE\n"
        "fsaverage BEM head model. Each macroatom (a set of correlated\n"
        "single-channel atoms) is treated as a spatiotemporal dipole; the\n"
        "best-fitting location and orientation are saved and visualized in\n"
        "3D.\n"
        "\n"
        "Requires an MMP1 or MMP3 book from preprocessing (SMP books are\n"
        "monovariate and cannot provide spatial information).",
    "dipole_fitting.ref_channel":
        "EEG reference for dipole fitting:\n"
        "'average' = average reference, or comma-separated channel name(s)\n"
        "(e.g. 'Oz' or 'M1,M2').",
    "dipole_fitting.montage":
        "Electrode montage for channel positions. Default: standard_1005.",
    "dipole_fitting.max_iterations":
        "Only fit the first N iterations per segment (0 = all).\n"
        "Fewer iterations = faster but fewer dipoles.",
    "dipole_fitting.min_gof":
        "Minimum goodness-of-fit [%] to include in results.\n"
        "0 = keep all, 80–90 = high-quality only.",
    "dipole_fitting.cpu_workers":
        "Number of CPU cores for parallel dipole fitting.\n"
        "Each macroatom is fitted independently, so more cores = faster.\n"
        "Default: all cores minus 2 (headroom for OS and GUI).",
    "dipole_fitting.cortical_distance":
        "Compute signed distance from each dipole to the nearest cortical\n"
        "voxel.\n"
        "Requires nibabel. Negative distance = dipole is inside the cortex.",
    "dipole_fitting.ignored_channels":
        "Additional EEG channels to exclude before dipole fitting.\n"
        "Non-EEG channels (STIM, EOG, EMG, etc.) are always excluded\n"
        "automatically.",
    "dipole_fitting.dot_size":
        "Dipole dot size on the brain surface plot. 0 = auto.",
    "dipole_fitting.fsaverage_dir":
        "Path to fsaverage directory. Leave empty to auto-download via MNE\n"
        "(recommended).",
    # -- EEG Profiles -------------------------------------------------------
    # interval_sec removed — bin width is always equal to the MP segment
    # length (read from book metadata at runtime).

    "matching_pursuit.algorithm":
        "Decomposition algorithm:\n"
        "• SMP — Stochastic Matching Pursuit, monovariate. Each channel is\n"
        "  decomposed independently. Fastest; use for single-channel\n"
        "  analysis and EEG Profiles.\n"
        "• MMP1 — Multichannel MP, constant phase. Atoms are fitted jointly\n"
        "  across all channels with the same phase. Use for dipole source\n"
        "  fitting (book_*_mmp1.db).\n"
        "• MMP3 — Multichannel MP, variable phase. Atoms have\n"
        "  channel-specific phases. More flexible than MMP1\n"
        "  (book_*_mmp3.db).",
    "matching_pursuit.empi_path":
        "Path to the empi binary (Enhanced Matching Pursuit\n"
        "Implementation).\n"
        "Auto-detected from SVAROG installation in ~/.obci/svarog/ if\n"
        "available.",
    "matching_pursuit.iterations":
        "Maximum number of MP iterations (atoms). 0 = no limit (use\n"
        "residual energy).",
    "matching_pursuit.explained_energy":
        "Stop MP when this fraction of total signal energy has been\n"
        "explained.\n"
        "Range 0–1. Default 0.99 = stop at 99% explained (1% residual).\n"
        "Lower values (e.g. 0.95) produce fewer atoms and run faster.\n"
        "1.0 (100%) means \"stop only at the iteration cap\" —\n"
        "the runner passes a tiny residual so empi doesn't reject -r 0.\n"
        "This matches how Svarog drives empi.",
    "matching_pursuit.cpu_workers":
        "Number of parallel empi workers (each processes a separate\n"
        "segment, 1 thread per worker — segment-level parallelism is\n"
        "optimal for Gabor dictionary matching, not BLAS-heavy).\n"
        "0 = inherit from parallelism.n_jobs (Config tab → 'Parallel\n"
        "jobs'). The recommended default — one knob controls the whole\n"
        "pipeline.\n"
        "N > 0 = explicit override. Only set this if you have a specific\n"
        "reason to run empi with a different worker count than the rest of\n"
        "the pipeline. Empi's cost model is different from joblib's: it\n"
        "runs all workers as threads inside a single C++ process with\n"
        "shared memory, so the RAM baseline per worker is much lower (~10\n"
        "MB vs ~250 MB for joblib loky workers). Power users who know empi\n"
        "is RAM-cheaper may reasonably set this higher than\n"
        "parallelism.n_jobs.",
    "matching_pursuit.energy_error":
        "Dictionary density (ε²). Fixed at 0.01 (not configurable from\n"
        "GUI).\n"
        "Smaller = denser dictionary = more atoms = more precise but\n"
        "slower.",
    "matching_pursuit.filter.mode":
        "MP filter mode:\n"
        "• keep — reconstruct the signal from atoms that match the criteria\n"
        "  below (frequency, time, energy, iteration). Acts as a non-linear\n"
        "  bandpass filter.\n"
        "• remove — reconstruct from all atoms that do NOT match the\n"
        "  criteria (inverse filter / artifact subtraction).",
    "matching_pursuit.filter.freq_min":
        "Filter: include only atoms with frequency >= this (Hz). 0 = no\n"
        "limit.",
    "matching_pursuit.filter.freq_max":
        "Filter: include only atoms with frequency <= this (Hz). 0 = no\n"
        "limit.",
    "matching_pursuit.filter.time_min":
        "Filter: include only atoms centered at time >= this (s). 0 = no\n"
        "limit.",
    "matching_pursuit.filter.time_max":
        "Filter: include only atoms centered at time <= this (s). 0 = no\n"
        "limit.",
    "matching_pursuit.filter.min_energy":
        "Filter: include only atoms with energy >= this value. 0 = no\n"
        "limit.",
    "matching_pursuit.filter.max_iterations":
        "Filter: include only the first N atoms (by iteration). 0 = all\n"
        "atoms.",

    # -- Segment rejection ------------------------------------------------
    "segment_rejection.reject_threshold":
        "Peak-to-peak rejection threshold [µV]. Segments exceeding this are\n"
        "dropped. 0 = auto-detect from percentile.",
    "segment_rejection.flat_threshold":
        "Flat channel threshold [µV]. Segments where PTP < this are dropped\n"
        "(dead channels). 0 = disabled.",
    "segment_rejection.auto_percentile":
        "When reject threshold = 0, set it at this percentile of the PTP\n"
        "distribution (e.g. 95 = reject top 5%).",

    # -- Signal Setup -----------------------------------------------------
    "electrodes_layout":
        "MNE electrode montage name. Used to look up 3D channel positions\n"
        "for topographic plots and source estimation.\n"
        "Common values: standard_1005, standard_1020, biosemi64,\n"
        "easycap-M1, GSN-HydroCel-64.\n"
        "Leave empty to use positions embedded in the EEG file (FIF,\n"
        "BrainVision).",
    "re_reference":
        "Re-reference (derivation) applied to all EEG channels:\n"
        "• Raw signal — no re-referencing, keep original\n"
        "• Common average (CAR) — subtract mean across all EEG channels\n"
        "• Linked mastoids (M1+M2) — subtract average of M1 and M2\n"
        "• Linked ears (A1+A2) — subtract average of A1 and A2\n"
        "• REST — Reference Electrode Standardization Technique (infinity\n"
        "  reference, Yao 2001)\n"
        "• Custom — comma-separated channel names (e.g. Cz or M1,M2)",

    # -- Choosing Channels ------------------------------------------------
    "choosing_channels.choose_bad_channels":
        "How to identify bad channels:\n"
        "• auto — algorithmic detection based on spectral power, amplitude\n"
        "  outliers, and inter-channel correlation\n"
        "• manually — open an interactive plot for visual inspection\n"
        "• both — run auto first, then review interactively\n"
        "\n"
        "Bad channels are interpolated from their neighbors, not removed.",
    "choosing_channels.dropped_channels":
        "Comma-separated list of channels to exclude entirely (e.g. non-EEG\n"
        "auxiliary channels).",
    "choosing_channels.selected_channels":
        'Comma-separated list of channels to keep, or "all" to keep every\n'
        "remaining channel after drops.",
    "choosing_channels.type_overrides":
        "Per-channel MNE type override {name: type} applied after automatic\n"
        "inference.\n"
        'Right-click a channel in the channel panel or use the "Review\n'
        'types" dialog to edit.',

    # -- Bad channel detection (advanced) ---------------------------------
    "choosing_channels.enable_slow_osc":
        "Enable slow-oscillation power check for bad channel detection.",
    "choosing_channels.enable_noise_power":
        "Enable high-frequency noise power check for bad channel detection.",
    "choosing_channels.enable_correlation":
        "Enable inter-channel correlation check for bad channel detection.",
    "choosing_channels.noise_slow_band":
        "Frequency band [low, high] Hz for slow-oscillation noise\n"
        "detection. Default: 2–10 Hz.",
    "choosing_channels.noise_slow_thresholds":
        "Three escalating power thresholds for slow-oscillation detection.\n"
        "Channels exceeding any threshold are flagged. Default: 1e3, 1e4,\n"
        "1e5.",
    "choosing_channels.noise_power_band":
        "Frequency band [low, high] Hz for high-frequency noise detection.\n"
        "Default: 52–98 Hz (line noise harmonics).",
    "choosing_channels.noise_power_thresholds":
        "Three escalating power thresholds for high-frequency noise.\n"
        "Default: 20, 200, 2000.",
    "choosing_channels.noise_window":
        "Window length in seconds for spectral power computation. Default:\n"
        "1 s.",
    "choosing_channels.correlation_window":
        "Acceptable inter-channel correlation range [min, max].\n"
        "Channels outside this range are flagged. Default: 0.75–0.975.",
    "choosing_channels.correlation_badch_threshold":
        "Fraction of channel pairs that must show bad correlation to\n"
        "classify a channel as bad. Default: 0.95.",

    # -- Filters ----------------------------------------------------------
    "filters.show_filt":
        "Display filter response plots interactively during processing.",
    "filters.plot_filt":
        "Save filter response plots to the output directory.",
    "filters.highpass_freq":
        "Highpass cutoff frequency in Hz. Removes slow drifts below this\n"
        "frequency. 0 = off. Common values: 0.1, 0.5, 1.0 Hz.",
    "filters.lowpass_freq":
        "Lowpass cutoff frequency [Hz]. Removes high-frequency noise above\n"
        "this frequency.\n"
        "0 = off. Common values: 30, 40, 100 Hz.",
    "filters.notch_freq":
        "Power line noise removal. 50 Hz for Europe/Asia, 60 Hz for\n"
        "Americas. None = off.",
    "filters.method":
        "Filter design method (both produce zero-phase output):\n"
        "• IIR (Butterworth / Chebyshev II) — fast, sharp rolloff.\n"
        "  Designed as second-order sections (SOS) for numerical\n"
        "  stability; applied forward-backward via\n"
        "  `scipy.signal.sosfiltfilt`. The double pass squares the\n"
        "  magnitude response (a -3 dB design becomes -6 dB at\n"
        "  cutoff) and doubles the effective order.\n"
        "• FIR (MNE) — windowed-sinc, symmetric impulse response\n"
        "  (linear-phase by design, no second pass needed). Always\n"
        "  stable. Slower than IIR but preferred when an exact\n"
        "  passband shape matters.",

    # -- Artifacts --------------------------------------------------------
    "artifacts.enable_slopes":
        "Enable slope-based artifact detection (large peak-to-peak\n"
        "changes).",
    "artifacts.enable_outliers":
        "Enable outlier-based artifact detection (extreme amplitude\n"
        "values).",
    "artifacts.enable_muscles":
        "Enable muscle artifact detection (high-frequency spectral power).",
    "artifacts.enable_amplitude":
        "Enable amplitude thresholding (reject epochs exceeding a fixed\n"
        "microvolt ceiling across channels).",
    "amplitude_max_threshold":
        "Maximum allowed peak amplitude [µV]. Epochs with values above this\n"
        "on enough channels are rejected. Default 150.",
    "amplitude_time_threshold":
        "Fraction of epoch duration (0–1) that must exceed the amplitude\n"
        "ceiling for rejection. Default 0.1.",
    "amplitude_nchan_threshold":
        "Fraction of channels (0–1) that must be over the amplitude ceiling\n"
        "for the epoch to be rejected. Default 0.5.",
    "artifacts.artifact_threshold":
        "Per-channel fraction of epoch duration (0–1) that must be\n"
        "artifact-contaminated for the epoch to be rejected.\n"
        "Lower = stricter rejection. Default 0.3.",
    "artifacts.SlopeWindow":
        "Sliding window width [s] for slope and outlier detection. Default\n"
        "0.0704.",
    "artifacts.SlopesAbsThr":
        "Absolute peak-to-peak amplitude threshold [µV] for slopes. Default\n"
        "150.",
    "artifacts.SlopesStdThr":
        "Peak-to-peak as multiple of standard deviation for slopes. Default\n"
        "7.",
    "artifacts.SlopesMedThr":
        "Peak-to-peak as multiple of median for slopes. Default 6.",
    "artifacts.OutliersMergeWin":
        "Window [s] for merging nearby outlier detections into groups.\n"
        "Default 0.1.",
    "artifacts.OutliersAbsThr":
        "Absolute amplitude threshold [µV] for outliers. Default 150.",
    "artifacts.OutliersStdThr":
        "Amplitude as multiple of standard deviation for outliers. Default\n"
        "7.",
    "artifacts.OutliersMedThr":
        "Amplitude as multiple of median for outliers. Default 13.",
    "artifacts.MusclesWindow":
        "Sliding window width [s] for muscle artifact detection. Default\n"
        "0.5.",
    "artifacts.MusclesFreqRange":
        "Frequency band [Hz, Hz] for muscle spectral density. Default 40,\n"
        "90.",
    "artifacts.MusclesAbsThr":
        "Absolute spectral density threshold [µV²] for muscles. Default\n"
        "150.",
    "artifacts.MusclesStdThr":
        "Spectral density as multiple of standard deviation for muscles.\n"
        "Default 7.",
    "artifacts.MusclesMedThr":
        "Spectral density as multiple of median for muscles. Default 5.",

    # -- ICA / EOG (Phase 4: Picard + ICLabel) ---------------------------
    "ICA_EOG.method":
        "ICA algorithm. Default 'picard' (extended Infomax via\n"
        "preconditioning — same ML problem, 3-10x faster on EEG,\n"
        "Ablin 2018). Alternatives: 'infomax' (classic maximum-\n"
        "entropy) and 'fastica' (fixed-point). Picard is the\n"
        "recommended default for new runs.",
    "ICA_EOG.selector":
        "How to label components after fitting:\n"
        "• iclabel (default) — MNE-ICALabel CNN classifies every\n"
        "  component as brain / muscle / eye / heart / line_noise /\n"
        "  channel_noise / other (Pion-Tonachini 2019)\n"
        "• find_bads — ica.find_bads_eog / _ecg / _muscle using\n"
        "  reference channels (no ML model needed)\n"
        "• manual — interactive plot_sources(block=True) for\n"
        "  hand inspection\n"
        "• both — ICLabel plus the manual review window",
    "ICA_EOG.fit_highpass_hz":
        "High-pass filter (Hz) applied to a COPY of the signal\n"
        "used only for the ICA fit (Winkler et al. 2015). Decouples\n"
        "the ICA-fit band from the analysis filter — the returned\n"
        "cleaned signal is NOT high-passed to this value. Default\n"
        "1.0. Set 0 to disable.",
    "ICA_EOG.reject_uv":
        "Peak-to-peak amplitude (µV) — segments whose any-channel\n"
        "PTP exceeds this are dropped BEFORE the ICA fit sees them,\n"
        "so that rare big transients don't dominate the\n"
        "decomposition. Default 500. Set 0 to disable.",
    "ICA_EOG.n_components":
        "Number of ICA components to fit. Options:\n"
        "• 'rank' (default) — auto-derived from mne.compute_rank()\n"
        "  on the fit copy, so average-reference rank loss and\n"
        "  interpolated channels are accounted for\n"
        "• an integer — fixed count (must be <= rank)\n"
        "• a float in (0, 1) — fraction of cumulative variance",
    "ICA_EOG.decim":
        "Subsampling factor for the fit stage. Default 1 (no\n"
        "subsample). Values > 1 speed up the fit N× by using every\n"
        "N-th sample, but do so without an anti-alias filter —\n"
        "safe only with a strong fit-time high-pass, footgun\n"
        "otherwise. Use at your own risk.",
    "ICA_EOG.random_state":
        "Seed for the fit's RNG — same seed gives a bit-identical\n"
        "mixing matrix across runs. Default 42. Change only if\n"
        "you want to probe sensitivity to initialisation.",
    "ICA_EOG.find_bads_eog_ch":
        "EOG reference channels for selector='find_bads'. The\n"
        "first available channel is used to correlate against ICA\n"
        "sources. Comma-separated names, e.g. 'Fp1, Fp2, Fpz'.\n"
        "Ignored when selector='iclabel'.",
    "ICA_EOG.iclabel_min_prob":
        "Minimum ICLabel confidence to trust the classifier's\n"
        "label. Components with max-class probability below this\n"
        "threshold fall into 'other' regardless of their top pick.\n"
        "Default 0.0 (no minimum).",
    "ICA_EOG.find_bads_ecg":
        "When selector='find_bads' or 'both', also run\n"
        "ica.find_bads_ecg to detect cardiac components via peak\n"
        "detection + template matching. Default on.",
    "ICA_EOG.find_bads_muscle":
        "When selector='find_bads' or 'both', also run\n"
        "ica.find_bads_muscle to detect muscle components via\n"
        "high-frequency power. Default on.",
    "ICA_EOG.save_components_audit":
        "Save audit/diagnostic outputs to\n"
        "  artifacts_detection/ICA_EOG/:\n"
        "  • <file>_ICA_topomap.png    — component topomaps\n"
        "  • <file>_ICA_properties_<i>.png — per-component\n"
        "    properties (PSD, image, ERP)\n"
        "  • <file>_ica_classification.csv — table with\n"
        "    component / label / max_prob / status\n"
        "  • <file>-ica.fif            — fitted ICA model\n"
        "  • <file>_ica_report.html    — bundled MNE Report\n"
        "Default off (the 🗄️ drawer toggle in the panel header\n"
        "controls only the cleaned-signal snapshot).",
    "bad_channels.save_plots":
        "Save the per-channel bad-detection plots to\n"
        "  bad_channels/:\n"
        "  • slow_oscillations / noise_power score plots\n"
        "  • correlation matrix figure\n"
        "Default off (the 🗄️ drawer toggle in the panel header\n"
        "controls only the bad-channel-marked signal snapshot).",
    "artifacts.save_plots":
        "Save the per-detector EEG-artifact plots to\n"
        "  artifacts_detection/found_artifacts/:\n"
        "  • outlier / slope / muscle scoring plots\n"
        "Default off (the 🗄️ drawer toggle in the panel header\n"
        "controls only the EEG-artifact-marked signal snapshot;\n"
        "the .tag / rej-dict outputs have their own checkbox).",
    "artifacts.save_tag":
        "Save the BrainTech .tag file (and the rejection-\n"
        "thresholds JSON) for viewing the detected EEG\n"
        "artifacts in Svarog, written to\n"
        "  artifacts_detection/:\n"
        "  • <file>___artifacts.tag (all detected intervals)\n"
        "  • <file>____artifact_rej_dict.json (thresholds)\n"
        "Default off (the 🗄️ drawer toggle in the panel header\n"
        "controls only the EEG-artifact-marked signal snapshot;\n"
        "the per-detector plots have their own checkbox).",
    "gaze.save_tag":
        "Save the BrainTech .tag file for viewing the\n"
        "not-looking intervals in Svarog, written to\n"
        "  artifacts_detection/video_artifacts/.\n"
        "Default off (the 🗄️ drawer toggle in the panel header\n"
        "controls only the gaze-marked signal snapshot; the\n"
        "review-window JSON is always written regardless of\n"
        "either flag).",

    # -- Dipole fitting ------------------------------------------------
    "dipole_fitting.ref_channel":
        "Re-reference for dipole fitting. 'average' subtracts\n"
        "the common average; a channel name (Cz, Fz) uses that\n"
        "channel as the reference electrode.",
    "dipole_fitting.montage":
        "Electrode layout for the forward model. Must match\n"
        "the channel names in the signal. standard_1005 covers\n"
        "most 10-20 and 10-10 systems.",
    "dipole_fitting.cortical_distance":
        "Compute each dipole's distance to the nearest cortical\n"
        "voxel (mm). Requires nibabel. Adds 'cortex_dist_mm'\n"
        "column to the CSV output.",
    "dipole_fitting.fsaverage_dir":
        "Path to the FreeSurfer subject directory used for the\n"
        "BEM forward model and 3D visualization.\n\n"
        "Empty = fsaverage (auto-downloaded, ~30 MB). This is\n"
        "a template brain averaged from 40 healthy adults — it\n"
        "has no individual facial features (no nose/ears) but\n"
        "is geometrically correct for source localisation.\n\n"
        "For subject-specific fitting, point this to the\n"
        "subject's own FreeSurfer recon-all output (e.g.\n"
        "/path/to/subjects/SUBJ01). The subject's real brain\n"
        "surface and head (with nose/ears from their MRI)\n"
        "are then exported for ConnectiVIS 3D viewing.",
    "dipole_fitting.cpu_workers":
        "Number of CPU cores for parallel dipole fitting.\n"
        "0 = use all available cores minus 2.",

    # -- Timed windows ----------------------------------------------------
    "rest.rest_duration_start":
        "Start time (seconds) of the continuous segment to extract (0 =\n"
        "beginning).",
    "rest.rest_duration_end":
        "End time (seconds) of the continuous segment to extract (empty =\n"
        "end of signal).",
    "rest.window_length":
        "Duration (seconds) of each analysis window. Check 'whole signal'\n"
        "to use the entire segment as one window.",
    "rest.check_rest":
        "Pause the pipeline to interactively review and mark bad\n"
        "segments. In the GUI this opens Svarog's bad-epochs panel\n"
        "when the installed jar supports it; otherwise MNE's\n"
        "interactive epochs browser. In CLI it opens the MNE browser\n"
        "directly in-process.",
    "rest.whole_signal":
        "Use the entire continuous segment as one analysis window (ignores\n"
        "window length).",

    # -- Event-locked -----------------------------------------------------
    "epochs.start_offset":
        "Epoch start time relative to the trigger event, in seconds (e.g.\n"
        "−0.3).",
    "epochs.stop_offset":
        "Epoch end time relative to the trigger event, in seconds (e.g.\n"
        "0.7).",
    "epochs.epochs_baseline":
        "Baseline correction interval. The mean signal in this window is\n"
        "subtracted from each epoch to remove DC offsets.\n"
        "Format: [start, end] in seconds relative to the trigger (e.g.\n"
        "[-0.3, 0] uses the 300 ms pre-stimulus period).\n"
        "Set to None to skip baseline correction.",
    "epochs.check_epochs":
        "Pause the pipeline to interactively review and mark bad\n"
        "epochs. In the GUI this opens Svarog's bad-epochs panel\n"
        "when the installed jar supports it; otherwise MNE's\n"
        "interactive epochs browser. In CLI it opens the MNE browser\n"
        "directly in-process.",
    "epochs.tags.selected":
        "Event names to include in epoch analysis.\n"
        "In the GUI, check the events you want from the list discovered in\n"
        "the loaded file.\n"
        "Only checked events become epochs; others are ignored even if\n"
        "present in the STIM channel.",

    # -- Time Domain ------------------------------------------------------
    "time_domain.cluster_test.step_down_p":
        "P-value threshold for the step-down-in-jumps cluster test. Default\n"
        "0.05.",
    "time_domain.cluster_test.n_permutations":
        "Number of permutations for the cluster-based permutation test.\n"
        "Higher = more precise but slower. Default 1024.",

}

DEFAULT_CONFIG = {
    "input_path": "",
    "output_path": "",
    "video_path": "",
    "preprocessing_output_path": "",
    "analysis_output_path": "",
    "segmentation": {"mode": "rest"},
    "overwrite_output": False,
    # Default viewer for the eye 👁 button on preprocessing steps and
    # the Output tab double-click.  False = prefer Svarog when its jar
    # is installed; True = always use MNE windows.
    "use_mne_viewer": False,
    # Show a small gray info row at the top of each preprocessing
    # panel listing the actual Python function called and the TOML
    # config sections read.  False = panels stay clean; True = info
    # row visible (useful for scripting / debugging).
    "show_pyinfo": False,

    # Parallelism policy. See CONTRIBUTING.md §"Parallelism".
    # Default 1 = sequential, same as MNE. Users opt into parallelism
    # by typing a larger number in the Config tab's "Parallel jobs"
    # field. Resolved once per pipeline run in
    # ide4eeg.main._configure_parallelism.
    #
    # Section is called "parallelism" rather than "global" because
    # the latter is a reserved Python keyword and would break
    # api.generate_script (which emits config as **kwargs).
    "parallelism": {"n_jobs": 0},  # 0 = auto (resolved at runtime)

    "resample_freq": 0,

    "prepare_eeg_artifacts": False,
    "prepare_ica": False,
    "prepare_video_artifacts": False,
    "video_reference_dir": "",
    "video_exclude_dir": "",
    "facetag_frame_skip": 3,
    "facetag_detection_skip": 3,
    "facetag_downscale": 1.0,
    "facetag_max_angle": 20.0,
    "facetag_ref_use_roi": False,
    "facetag_face_tolerance": 0.6,
    "facetag_min_interval": 0.0,
    "facetag_no_face_is_artifact": True,
    "facetag_tracking_adapt_rate": 0.5,
    "facetag_position_weight": 0.4,
    "facetag_size_weight": 0.2,
    "facetag_switch_resistance": 0.25,
    "facetag_backend": "insightface",
    "facetag_gaze_method": "l2cs",
    "facetag_gaze_smoothing": 0.0,
    "facetag_det_size": 0,
    "trim_start": 0.0,
    "trim_end": "",

    "prepare_eeg_profiles": False,
    "prepare_connectivity_analysis": False,
    "prepare_dipole_fitting": False,
    "prepare_mp_filter": False,

    "segment_rejection": {
        "enabled": False,
        "reject_threshold": 0,
        "flat_threshold": 0,
        "auto_percentile": 95.0,
    },

    "matching_pursuit": {
        "save": True,  # forced — the .db book IS the step output
        "empi_path": "",
        "algorithm": "smp",
        "channels": "",
        "iterations": 30,
        "explained_energy": 0.99,
        "optimization": "global",
        "include_delta": True,
        "energy_error": 0.01,
        "full_atoms_in_signal": False,
        "filter": {
            "mode": "keep",
            "freq_min": 0,
            "freq_max": 0,
            "time_min": 0,
            "time_max": 0,
            "min_energy": 0,
            "max_iterations": 0,
        },
        "outputs": {
            "atom_stats_csv": False,
            "atom_histograms": False,
        },
    },

    "eeg_profiles": {
        "channel": 0,
        # interval_sec removed — bin width is always the MP segment
        # length, derived from book metadata at runtime.
        "mode": "amplitudes",
        "structures": [],
    },


    "baseline": "None",
    "electrodes_layout": NATIVE_POSITIONS_SENTINEL,
    "re_reference": [],

    "choosing_channels": {
        "save": False,
        "choose_bad_channels": "auto",
        "dropped_channels": [],
        "selected_channels": "all",
        "check_final_channels": True,
        "type_overrides": {},  # {channel_name: mne_type} — user's final word
        "badchs_params": {
            "slow_oscillations": [1.0, [2.0, 10.0], "-", [1000.0, 10000.0, 100000.0]],
            "noise_power": [1.0, [52.0, 98.0], "-", [20.0, 200.0, 2000.0]],
        },
    },
    "filters": {
        "save": False,
        "method": "iir",
        "show_filt": False,
        "plot_filt": False,
        "highpass_freq": 0,
        "lowpass_freq": 0,
        "notch_freq": 0,
    },
    "artifacts": {
        "save": False,
        "save_plots": False,
        "artifact_threshold": 0.3,
        "rejection_parameters": {
            "SlopeWindow": 0.0704,
            "SlopesAbsThr": 150,
            "SlopesStdThr": 7,
            "SlopesMedThr": 6,
            "OutliersMergeWin": 0.1,
            "OutliersAbsThr": 150,
            "OutliersStdThr": 7,
            "OutliersMedThr": 13,
            "MusclesWindow": 0.5,
            "MusclesAbsThr": 150,
            "MusclesStdThr": 7,
            "MusclesMedThr": 5,
            "MusclesFreqRange": [40.0, 90.0],
        },
    },
    "ICA_EOG": {
        "save": False,
        "save_components_audit": False,
        # Algorithm
        "method": "picard",
        "random_state": 42,
        # Fit-time signal preparation
        "fit_highpass_hz": 1.0,
        "decim": 1,
        "reject_uv": 500.0,
        # Dimensionality
        "n_components": "rank",
        # Component selection
        "selector": "iclabel",
        "iclabel_keep": ["brain", "other"],
        "iclabel_min_prob": 0.0,
        "find_bads_eog_ch": ["Fp1", "Fp2", "Fpz"],
        "find_bads_ecg": True,
        "find_bads_muscle": True,
    },
    # Trim is saved by default (small file, becomes the canonical
    # input for every Svarog launch from the preproc panel and for
    # eye-button before/after views).  Disable explicitly if disk
    # space matters more than viewer responsiveness.
    "trim": {"save": True},
    "bad_channels": {"save": False, "save_plots": False},
    "montage": {"save": False},
    "gaze": {"save": False, "save_tag": False},
    "mp_filter": {"save": False},
    "rest": {
        "rest_duration": [0, ""],
        "window_length": 20,
        "whole_signal": False,
        "check_rest": False,
    },
    "epochs": {
        "start_offset": -0.3,
        "stop_offset": 0.7,
        "epochs_baseline": "None",
        "check_epochs": False,
        "tags": {"selected": []},
    },
    "time_domain": {
        "cluster_test": {
            "step_down_p": 0.05,
            "n_permutations": 1024,
        },
    },
    "connectivity": {
        "methods": ["dtf", "coh"],
        "mvar_method": "yw",
        "mvar_order": 0,
        "resolution": 100,
        "channels": "all",
        "short_time": False,
        "st_window": 0,
        "st_overlap": 0,
        "significance": False,
        "sig_reps": 100,
        "sig_alpha": 0.05,
    },
    "dipole_fitting": {
        "ref_channel": "average",
        "montage": "standard_1005",
        "max_iterations": 0,
        "min_gof": 0,
        "cortical_distance": False,
        "fsaverage_dir": "",
        "ignored_channels": "",
    },

    "preprocessing": {
        "step_order": [],
        "hard_constraints": _DEFAULT_HARD,
        "soft_constraints": _DEFAULT_SOFT,
        "allow_reorder": False,
    },
}


# Montage metadata: (description, n_channels, details)
MONTAGE_INFO = {
        "10-20": (
            "International 10-20 system", 21,
            "The original International 10-20 system (Jasper 1958). "
            "21 standard electrode positions: Fp1/2, F7/3/z/4/8, "
            "T3/C3/Cz/C4/T4, T5/P3/Pz/P4/T6, O1/Oz/O2 + A1/A2 references. "
            "Uses MNE's standard_1020 montage internally (which includes "
            "10-10 intermediates), but View Montage shows only the classic "
            "21 positions."),
        "standard_1020": (
            "10-10 system (extended 10-20)", 94,
            "94 positions. The 10-10 extension of the 10-20 system "
            "(Chatrian et al. 1985, Oostenveld & Praamstra 2001). "
            "Adds intermediate sites (AF, FC, FT, CP, TP, PO rows). "
            "Includes legacy names (T3/T4/T5/T6), mastoids (M1/M2), "
            "and ear references (A1/A2)."),
        "standard_1005": (
            "10-05 system (full extension)", 343,
            "343 positions. The 10-05 extension (Oostenveld & Praamstra "
            "2001). Covers all standard and intermediate sites at 5% "
            "spacing over the entire scalp."),
        "standard_alphabetic": (
            "Alphabetic naming convention", 65,
            "65 positions. Alternative naming using alphabetic electrode "
            "labels (B, C, D rows). Same positions as 10-10, different "
            "names."),
        "standard_postfixed": (
            "Postfixed naming convention", 100,
            "100 positions. Electrode names with postfix letters "
            "(e.g. F7a, F5a) for intermediate positions."),
        "standard_prefixed": (
            "Prefixed naming convention", 74,
            "74 positions. Electrode names with prefix letters "
            "(e.g. aF3, aFz) for intermediate positions."),
        "standard_primed": (
            "Primed naming convention", 100,
            "100 positions. Electrode names with prime marks "
            "(e.g. F7\u2032, F5\u2032) for intermediate positions."),
        "biosemi16": (
            "BioSemi ActiveTwo 16-channel", 16,
            "16 positions. BioSemi ActiveTwo 16-channel cap."),
        "biosemi32": (
            "BioSemi ActiveTwo 32-channel", 32,
            "32 positions. BioSemi ActiveTwo 32-channel cap."),
        "biosemi64": (
            "BioSemi ActiveTwo 64-channel", 64,
            "64 positions. BioSemi ActiveTwo 64-channel cap."),
        "biosemi128": (
            "BioSemi ActiveTwo 128-channel", 128,
            "128 positions. BioSemi ActiveTwo 128-channel cap."),
        "biosemi160": (
            "BioSemi ActiveTwo 160-channel", 160,
            "160 positions. BioSemi ActiveTwo 160-channel cap."),
        "biosemi256": (
            "BioSemi ActiveTwo 256-channel", 256,
            "256 positions. BioSemi ActiveTwo 256-channel cap."),
        "easycap-M1": (
            "EasyCap M1 layout", 74,
            "74 positions. EasyCap M1 layout with standard 10-20 names."),
        "easycap-M10": (
            "EasyCap M10 layout", 61,
            "61 positions. EasyCap M10 layout with numeric electrode names."),
        "easycap-M43": (
            "EasyCap M43 layout", 64,
            "64 positions. EasyCap M43 layout with numeric electrode names."),
        "GSN-HydroCel-32": (
            "EGI Geodesic Sensor Net 32", 33,
            "33 positions. EGI HydroCel GSN 32-channel + Cz."),
        "GSN-HydroCel-64_1.0": (
            "EGI Geodesic Sensor Net 64", 64,
            "64 positions. EGI HydroCel GSN 64-channel."),
        "GSN-HydroCel-65_1.0": (
            "EGI Geodesic Sensor Net 65", 65,
            "65 positions. EGI HydroCel GSN 64-channel + Cz."),
        "GSN-HydroCel-128": (
            "EGI Geodesic Sensor Net 128", 128,
            "128 positions. EGI HydroCel GSN 128-channel."),
        "GSN-HydroCel-129": (
            "EGI Geodesic Sensor Net 129", 129,
            "129 positions. EGI HydroCel GSN 128-channel + Cz."),
        "GSN-HydroCel-256": (
            "EGI Geodesic Sensor Net 256", 256,
            "256 positions. EGI HydroCel GSN 256-channel."),
        "GSN-HydroCel-257": (
            "EGI Geodesic Sensor Net 257", 257,
            "257 positions. EGI HydroCel GSN 256-channel + Cz."),
        "EGI_256": (
            "EGI 256-channel", 256,
            "256 positions. EGI 256-channel layout."),
        "mgh60": (
            "MGH 60-channel", 60,
            "60 positions. Massachusetts General Hospital custom 60-ch cap."),
        "mgh70": (
            "MGH 70-channel", 70,
            "70 positions. Massachusetts General Hospital custom 70-ch cap."),
        "brainproducts-RNP-BA-128": (
            "Brain Products R-Net 128", 130,
            "130 positions. Brain Products R-Net 128-channel cap."),
        "artinis-octamon": (
            "Artinis OctaMon (fNIRS)", 10,
            "10 positions. Artinis OctaMon fNIRS device."),
        "artinis-brite23": (
            "Artinis Brite23 (fNIRS)", 18,
            "18 positions. Artinis Brite23 fNIRS device."),
}
