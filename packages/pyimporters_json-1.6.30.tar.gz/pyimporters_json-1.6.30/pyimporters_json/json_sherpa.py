import json
import zipfile
from collections.abc import Generator
from pathlib import Path
from typing import Any

from progress.bar import Bar
from pydantic import BaseModel
from pyimporters_plugins.base import (
    KnowledgeParserBase,
    KnowledgeParserOptions,
    Term,
    maybe_archive,
)


class JSONOptions(KnowledgeParserOptions):
    """Options for the JSON knowledge import"""

    pass


JSONOptionsModel = JSONOptions


class JSONKnowledgeParser(KnowledgeParserBase):
    def parse(
        self,
        source: Path,
        options: KnowledgeParserOptions | dict[str, Any],
        bar: Bar,
    ) -> Generator[Term, None, None]:
        options = JSONOptionsModel(**options) if isinstance(options, dict) else options
        with maybe_archive(source, mode="rb") as fin:
            if isinstance(fin, zipfile.ZipFile):
                for zentry in fin.filelist:
                    with fin.open(zentry) as zfin:
                        yield from self._parse_json(bar, zfin)
            else:
                yield from self._parse_json(bar, fin)

    def _parse_json(self, bar, fin):
        terms = json.load(fin)
        bar.max = len(terms)
        bar.start()
        for term in terms:
            bar.next()
            yield Term(**term)

    @classmethod
    def get_schema(cls) -> type[KnowledgeParserOptions]:
        return JSONOptions

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return JSONOptionsModel

    @classmethod
    def get_extensions(cls) -> list[str]:
        return ["json", "zip"]
