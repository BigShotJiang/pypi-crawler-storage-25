"""Sherpa knowledge import plugins"""

__version__ = "1.6.30"
