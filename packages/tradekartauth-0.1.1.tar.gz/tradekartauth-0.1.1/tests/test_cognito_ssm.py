"""load_config_from_ssm with mocked boto3."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tradekartauth.config import CognitoAuthConfig
from tradekartauth.exceptions import ConfigurationError
from tradekartauth.providers.cognito import load_config_from_ssm


def test_load_config_from_ssm_success() -> None:
    param_value = json.dumps(
        {
            "user_pool_id": "ap-south-1_abc",
            "region": "ap-south-1",
            "app_client_id": "app123",
            "group_to_role": {"g": "admin"},
        }
    )
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": param_value}}

    with patch("boto3.client", return_value=mock_ssm):
        cfg = load_config_from_ssm("/param/x", region="ap-south-1")

    assert isinstance(cfg, CognitoAuthConfig)
    assert cfg.user_pool_id == "ap-south-1_abc"
    assert cfg.app_client_id == "app123"
    assert cfg.group_to_role == {"g": "admin"}


def test_load_config_from_ssm_invalid_json() -> None:
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": "not-json"}}

    with patch("boto3.client", return_value=mock_ssm):
        with pytest.raises(ConfigurationError, match="Invalid JSON"):
            load_config_from_ssm("/p")

