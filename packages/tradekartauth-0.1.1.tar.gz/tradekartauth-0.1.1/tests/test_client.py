"""Public TradeKartAuth facade."""

from unittest.mock import MagicMock

import pytest

from tradekartauth.config import CognitoAuthConfig
from tradekartauth.client import TradeKartAuth
from tradekartauth.exceptions import ConfigurationError


def test_client_rejects_empty_pool_id() -> None:
    with pytest.raises(ConfigurationError):
        TradeKartAuth(CognitoAuthConfig(user_pool_id="", region="ap-south-1"))


def test_client_rejects_empty_region() -> None:
    with pytest.raises(ConfigurationError):
        TradeKartAuth(CognitoAuthConfig(user_pool_id="x", region=""))


def test_client_delegates_to_auth_service(monkeypatch: pytest.MonkeyPatch) -> None:
    mock_svc = MagicMock()
    monkeypatch.setattr("tradekartauth.client.AuthService", lambda *a, **k: mock_svc)
    tk = TradeKartAuth(CognitoAuthConfig(user_pool_id="pool", region="ap-south-1"))
    tk.authenticate("Bearer z")
    mock_svc.authenticate.assert_called_once_with("Bearer z")
