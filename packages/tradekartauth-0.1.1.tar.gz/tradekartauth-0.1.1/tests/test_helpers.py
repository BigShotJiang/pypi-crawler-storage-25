"""Edge cases for bearer token normalization."""

from __future__ import annotations

import pytest

from tradekartauth.utils import normalize_bearer_token


@pytest.mark.parametrize(
    "raw,expected",
    [
        (None, ""),
        ("", ""),
        ("   ", ""),
        ("Bearer abc.def.ghi", "abc.def.ghi"),
        ("bEaReR token-value", "token-value"),
        ("no-prefix-here", "no-prefix-here"),
    ],
)
def test_normalize_bearer_token(raw: str | None, expected: str) -> None:
    assert normalize_bearer_token(raw) == expected
