"""Role → permission matrix and wildcard behaviour."""

from __future__ import annotations

import pytest

from tradekartauth.config import ROLE_ADMIN, ROLE_TRADER, ROLE_VIEWER
from tradekartauth.permissions import permissions_for_role, role_has_permission


def test_admin_wildcard() -> None:
    assert role_has_permission(ROLE_ADMIN, "anything:goes")
    assert "*" in permissions_for_role(ROLE_ADMIN)


def test_trader_trade_permissions() -> None:
    assert role_has_permission(ROLE_TRADER, "trade:place_order")
    assert not role_has_permission(ROLE_TRADER, "admin:destroy")


def test_viewer_read_only() -> None:
    assert role_has_permission(ROLE_VIEWER, "market:read")
    assert not role_has_permission(ROLE_VIEWER, "trade:place_order")


@pytest.mark.parametrize(
    "role,permission,expected",
    [
        (None, "auth:read", False),
        ("unknown-role", "auth:read", False),
        (ROLE_TRADER, "", False),
    ],
)
def test_edge_cases(role: str | None, permission: str, expected: bool) -> None:
    assert role_has_permission(role, permission) is expected


def test_permissions_for_role_unknown() -> None:
    assert permissions_for_role("not-a-role") == frozenset()
