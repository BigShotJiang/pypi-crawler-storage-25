"""AuthResults invariants."""

import pytest

from tradekartauth.exceptions import AuthenticationError, TradeKartAuthError
from tradekartauth.models import AuthResults


def test_auth_results_success_requires_claims() -> None:
    with pytest.raises(TradeKartAuthError):
        AuthResults(ok=True, claims=None, error=None, role="admin")


def test_auth_results_failure_requires_error() -> None:
    with pytest.raises(TradeKartAuthError):
        AuthResults(ok=False, claims=None, error=None, role=None)


def test_auth_results_ok_with_claims() -> None:
    r = AuthResults(ok=True, claims={"sub": "x"}, error=None, role="trader")
    assert r.ok and r.role == "trader"


def test_auth_results_failure() -> None:
    err = AuthenticationError("bad")
    r = AuthResults(ok=False, claims=None, error=err, role=None)
    assert not r.ok and r.error is err
