# Tradekartauth

TradeKart authentication package for private tools.

## CDK pipeline: if a stage fails

`cdk deploy` only creates **CodePipeline**; failures after that happen **inside AWS** (Synth, UpdatePipeline, or Publish).

1. Open **CodePipeline** → `TradekartAuthPipeline` → click the failed execution → open the failed **stage** (red).
2. Open **Details** / **View in CodeBuild** and read the **log tail** (the last error line is what matters).

| Stage | Typical causes |
|--------|----------------|
| **Source** | Bitbucket connection not **Available**; wrong `repo` / `branch`; repo missing `infra/package-lock.json`. |
| **Build (Synth)** | `npm ci` / `tsc` must run inside **`infra/`** — the pipeline uses `cd infra && …` in one shell. Ensure **`infra/package-lock.json`** is committed. |
| **UpdatePipeline** | CDK bootstrap / IAM for self-mutation; upgrade CDK bootstrap if prompted. |
| **Publish** | PyPI token wrong or secret is JSON not raw token; **bump version** in `version.py` if `twine` says file already exists; KMS permission if secret uses a CMK. |

**Secret format:** `TWINE_PASSWORD` must be the **raw** PyPI token (`pypi-Ag...`). If you stored JSON in Secrets Manager, either switch to plaintext or adjust the pipeline to parse JSON.

After changing `infra/lib/pipeline-stack.ts`, run `cd infra && npm run build && npx cdk deploy ...` again to update the pipeline.