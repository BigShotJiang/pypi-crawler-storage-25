"""Shared string helpers."""

from __future__ import annotations


def normalize_bearer_token(raw: str | None) -> str:
    """Strip surrounding whitespace and optional ``Bearer `` prefix."""
    if raw is None:
        return ""
    s = raw.strip()
    if s.lower().startswith('bearer '):
        return s[7:].strip()
    return s
