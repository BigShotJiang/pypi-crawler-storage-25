from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .exceptions import TradeKartAuthError

@dataclass(frozen=True)
class AuthResults:
    ok: bool
    claims: Mapping[str, Any] | None = None
    error: TradeKartAuthError | None = None
    role: str | None = None 

    def __post_init__(self) -> None:
        if self.ok and self.claims is None:
            raise TradeKartAuthError('Ok=True requires claims')
        if not self.ok and not self.error:
            raise TradeKartAuthError('Ok=False requires error')