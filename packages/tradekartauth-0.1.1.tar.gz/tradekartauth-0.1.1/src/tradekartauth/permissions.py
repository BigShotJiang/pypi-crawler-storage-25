from __future__ import annotations
from .config import ROLE_ADMIN, ROLE_TRADER, ROLE_VIEWER

ROLE_MAPPER: dict[str, frozenset[str]] = {
    ROLE_ADMIN: frozenset({'*'}),
    ROLE_TRADER: frozenset({
        'auth:read',
        'portfolio:read',
        'market:read',
        'trade:place_order',
        'trade:modify_order',
        'trade:cancel_order',
        'trade:get_order_list',
        'trade:get_order_status',
    }),
    ROLE_VIEWER: frozenset({
        'auth:read',
        'portfolio:read',
        'market:read',
    }),
}

def permissions_for_role(role: str | None) -> frozenset[str]:
    if not role:
        return frozenset()
    return ROLE_MAPPER.get(role, frozenset())

def role_has_permission(role: str | None, permission: str) -> bool:
    perms = permissions_for_role(role)
    if '*' in perms:
        return True
    return permission in perms