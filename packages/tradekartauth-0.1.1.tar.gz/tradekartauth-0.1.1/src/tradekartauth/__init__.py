"""tradekartauth — Cognito JWT verification + RBAC for TradeKart private tools."""

from .client import TradeKartAuth
from .config import CognitoAuthConfig, ROLE_ADMIN, ROLE_TRADER, ROLE_VIEWER
from .exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConfigurationError,
    TokenError,
    TradeKartAuthError,
)
from .models import AuthResults
from .permissions import ROLE_MAPPER, permissions_for_role, role_has_permission
from .version import __version__

__all__ = [
    '__version__',
    'TradeKartAuth',
    'CognitoAuthConfig',
    'ROLE_ADMIN',
    'ROLE_TRADER',
    'ROLE_VIEWER',
    'AuthenticationError',
    'AuthorizationError',
    'ConfigurationError',
    'TokenError',
    'TradeKartAuthError',
    'AuthResults',
    'ROLE_MAPPER',
    'permissions_for_role',
    'role_has_permission',
]