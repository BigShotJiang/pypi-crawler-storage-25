from __future__ import annotations

from typing import Any, Mapping

from .config import CognitoAuthConfig
from .exceptions import AuthenticationError, AuthorizationError, ConfigurationError
from .models import AuthResults
from .services import AuthService

class TradeKartAuth:
    def __init__(self, config: CognitoAuthConfig) -> None:
        if not config.user_pool_id or not config.region:
            raise ConfigurationError('User pool id and region are required')
        self._svc = AuthService(config)

    def authenticate(self, token: str | None) -> AuthResults:
        return self._svc.authenticate(token)

    def get_role(self, token: str | None) -> str | None:
        return self._svc.get_role(token)

    def has_permission(self, token: str | None, permission: str) -> bool:
        return self._svc.has_permission(token, permission)

    def require_permission(self, token: str | None, permission: str) -> Mapping[str, Any]:
        return self._svc.require_permission(token, permission)

__all__ = [
    'TradeKartAuth',
    'AuthenticationError',
    'AuthorizationError',
    'ConfigurationError',
]