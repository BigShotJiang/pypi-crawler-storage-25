"""Custom errors so callers can catch auth vs authz failures clearly."""

from __future__ import annotations

from typing import Any


class TradeKartAuthError(Exception):
    """Base error for this package."""
    def __init__(
        self,
        message: str,
        *,
        status_code : int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details

    def __str__(self) -> str:
        parts = [self.message]

        if self.status_code is not None:
            parts.append(f'status_code={self.status_code}')

        if self.details is not None:
            parts.append(f'details={self.details}')

        return '|'.join(parts)


class ConfigurationError(TradeKartAuthError):
    """Invalid or missing configuration (e.g. bad pool id, SSM load failed)."""


class AuthenticationError(TradeKartAuthError):
    """Token missing, malformed, expired, or signature/issuer invalid."""


class AuthorizationError(TradeKartAuthError):
    """Token is valid but the principal lacks the required permission."""


class TokenError(AuthenticationError):
    """Low-level JWT parsing/verification failure (often wrapped from PyJWT)."""