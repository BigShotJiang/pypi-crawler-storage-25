from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping

DEFAULT_REGION = 'ap-south-1'

ROLE_ADMIN = 'admin'
ROLE_TRADER = 'trader'
ROLE_VIEWER = 'viewer'

KNOWN_ROLES = frozenset({ROLE_ADMIN, ROLE_TRADER, ROLE_VIEWER})

CLAIM_GROUPS = 'cognito:groups'
CLAIM_SUB = 'sub'
CLAIM_USERNAME = 'username'
CLAIM_TOKEN_USE = 'token_use'
CLAIM_CLIENT_ID = 'client_id'
CLAIM_AUD = 'aud'

@dataclass(frozen=True)
class CognitoAuthConfig:
    user_pool_id: str
    region: str = DEFAULT_REGION
    app_client_id: str | None = None 
    group_to_role: Mapping[str, str] = field(default_factory=dict)


    def issuer(self) -> str:
        return f"https://cognito-idp.{self.region}.amazonaws.com/{self.user_pool_id}"

    def jwk_url(self) -> str:
        return f"{self.issuer()}/.well-known/jwks.json"