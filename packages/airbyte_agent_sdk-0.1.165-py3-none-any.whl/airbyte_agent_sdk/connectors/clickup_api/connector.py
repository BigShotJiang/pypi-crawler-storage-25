"""
Clickup-Api connector.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Mapping, TypeVar, overload
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from pydantic import BaseModel

from .connector_model import ClickupApiConnectorModel
from airbyte_agent_sdk.introspection import describe_entities, generate_tool_description
from airbyte_agent_sdk.translation import DEFAULT_MAX_OUTPUT_CHARS, FrameworkName, translate_exceptions
from airbyte_agent_sdk.types import AirbyteAuthConfig
from .types import (
    CommentsCreateParams,
    CommentsGetParams,
    CommentsListParams,
    CommentsUpdateParams,
    DocsGetParams,
    DocsListParams,
    FoldersGetParams,
    FoldersListParams,
    GoalsGetParams,
    GoalsListParams,
    ListsGetParams,
    ListsListParams,
    MembersListParams,
    SpacesGetParams,
    SpacesListParams,
    TasksApiSearchParams,
    TasksGetParams,
    TasksListParams,
    TeamsListParams,
    TimeTrackingGetParams,
    TimeTrackingListParams,
    UserGetParams,
    ViewTasksListParams,
    ViewsGetParams,
    ViewsListParams,
    AirbyteSearchParams,
    UserSearchFilter,
    UserSearchQuery,
    TeamsSearchFilter,
    TeamsSearchQuery,
    SpacesSearchFilter,
    SpacesSearchQuery,
    FoldersSearchFilter,
    FoldersSearchQuery,
    ListsSearchFilter,
    ListsSearchQuery,
    TasksSearchFilter,
    TasksSearchQuery,
    CommentsSearchFilter,
    CommentsSearchQuery,
    GoalsSearchFilter,
    GoalsSearchQuery,
    TimeTrackingSearchFilter,
    TimeTrackingSearchQuery,
)
from .models import ClickupApiAuthConfig

# Import response models and envelope models at runtime
from .models import (
    ClickupApiCheckResult,
    ClickupApiExecuteResult,
    ClickupApiExecuteResultWithMeta,
    TeamsListResult,
    SpacesListResult,
    FoldersListResult,
    ListsListResult,
    TasksListResult,
    TasksApiSearchResult,
    CommentsListResult,
    GoalsListResult,
    ViewsListResult,
    ViewTasksListResult,
    TimeTrackingListResult,
    MembersListResult,
    DocsListResult,
    Comment,
    CommentCreateResponse,
    CommentUpdateResponse,
    Doc,
    Folder,
    Goal,
    List,
    Member,
    Space,
    Task,
    Team,
    TimeEntry,
    User,
    View,
    AirbyteSearchMeta,
    AirbyteSearchResult,
    UserSearchData,
    UserSearchResult,
    TeamsSearchData,
    TeamsSearchResult,
    SpacesSearchData,
    SpacesSearchResult,
    FoldersSearchData,
    FoldersSearchResult,
    ListsSearchData,
    ListsSearchResult,
    TasksSearchData,
    TasksSearchResult,
    CommentsSearchData,
    CommentsSearchResult,
    GoalsSearchData,
    GoalsSearchResult,
    TimeTrackingSearchData,
    TimeTrackingSearchResult,
)

# TypeVar for decorator type preservation
_F = TypeVar("_F", bound=Callable[..., Any])




class ClickupApiConnector:
    """
    Type-safe Clickup-Api API connector.

    Auto-generated from OpenAPI specification with full type safety.
    """

    connector_name = "clickup-api"
    connector_version = "0.1.5"
    sdk_version = "0.1.165"

    # Map of (entity, action) -> needs_envelope for envelope wrapping decision
    _ENVELOPE_MAP = {
        ("user", "get"): None,
        ("teams", "list"): True,
        ("spaces", "list"): True,
        ("spaces", "get"): None,
        ("folders", "list"): True,
        ("folders", "get"): None,
        ("lists", "list"): True,
        ("lists", "get"): None,
        ("tasks", "list"): True,
        ("tasks", "get"): None,
        ("tasks", "api_search"): True,
        ("comments", "list"): True,
        ("comments", "create"): None,
        ("comments", "get"): None,
        ("comments", "update"): None,
        ("goals", "list"): True,
        ("goals", "get"): None,
        ("views", "list"): True,
        ("views", "get"): None,
        ("view_tasks", "list"): True,
        ("time_tracking", "list"): True,
        ("time_tracking", "get"): None,
        ("members", "list"): True,
        ("docs", "list"): True,
        ("docs", "get"): None,
    }

    # Map of (entity, action) -> {python_param_name: api_param_name}
    # Used to convert snake_case TypedDict keys to API parameter names in execute()
    _PARAM_MAP = {
        ('spaces', 'list'): {'team_id': 'team_id'},
        ('spaces', 'get'): {'space_id': 'space_id'},
        ('folders', 'list'): {'space_id': 'space_id'},
        ('folders', 'get'): {'folder_id': 'folder_id'},
        ('lists', 'list'): {'folder_id': 'folder_id'},
        ('lists', 'get'): {'list_id': 'list_id'},
        ('tasks', 'list'): {'list_id': 'list_id', 'page': 'page'},
        ('tasks', 'get'): {'task_id': 'task_id', 'custom_task_ids': 'custom_task_ids', 'include_subtasks': 'include_subtasks'},
        ('tasks', 'api_search'): {'team_id': 'team_id', 'search': 'search', 'statuses': 'statuses[]', 'assignees': 'assignees[]', 'tags': 'tags[]', 'priority': 'priority', 'due_date_gt': 'due_date_gt', 'due_date_lt': 'due_date_lt', 'date_created_gt': 'date_created_gt', 'date_created_lt': 'date_created_lt', 'date_updated_gt': 'date_updated_gt', 'date_updated_lt': 'date_updated_lt', 'custom_fields': 'custom_fields', 'include_closed': 'include_closed', 'page': 'page'},
        ('comments', 'list'): {'task_id': 'task_id'},
        ('comments', 'create'): {'comment_text': 'comment_text', 'assignee': 'assignee', 'notify_all': 'notify_all', 'task_id': 'task_id'},
        ('comments', 'get'): {'comment_id': 'comment_id'},
        ('comments', 'update'): {'comment_text': 'comment_text', 'assignee': 'assignee', 'resolved': 'resolved', 'comment_id': 'comment_id'},
        ('goals', 'list'): {'team_id': 'team_id'},
        ('goals', 'get'): {'goal_id': 'goal_id'},
        ('views', 'list'): {'team_id': 'team_id'},
        ('views', 'get'): {'view_id': 'view_id'},
        ('view_tasks', 'list'): {'view_id': 'view_id', 'page': 'page'},
        ('time_tracking', 'list'): {'team_id': 'team_id', 'start_date': 'start_date', 'end_date': 'end_date', 'assignee': 'assignee'},
        ('time_tracking', 'get'): {'team_id': 'team_id', 'time_entry_id': 'time_entry_id'},
        ('members', 'list'): {'task_id': 'task_id'},
        ('docs', 'list'): {'workspace_id': 'workspace_id', 'cursor': 'cursor'},
        ('docs', 'get'): {'workspace_id': 'workspace_id', 'doc_id': 'doc_id'},
    }

    # Accepted auth_config types for isinstance validation
    _ACCEPTED_AUTH_TYPES = (ClickupApiAuthConfig, AirbyteAuthConfig)

    def __init__(
        self,
        auth_config: ClickupApiAuthConfig | AirbyteAuthConfig | BaseModel | None = None,
        on_token_refresh: Any | None = None    ):
        """
        Initialize a new clickup-api connector instance.

        Supports both local and hosted execution modes:
        - Local mode: Provide connector-specific auth config (e.g., ClickupApiAuthConfig)
        - Hosted mode: Provide `AirbyteAuthConfig` with client credentials and either `connector_id` or `workspace_name`

        Args:
            auth_config: Either connector-specific auth config for local mode, or AirbyteAuthConfig for hosted mode
            on_token_refresh: Optional callback for OAuth2 token refresh persistence.
                Called with new_tokens dict when tokens are refreshed. Can be sync or async.
                Example: lambda tokens: save_to_database(tokens)
        Examples:
            # Local mode (direct API calls)
            connector = ClickupApiConnector(auth_config=ClickupApiAuthConfig(api_key="..."))
            # Hosted mode with explicit connector_id (no lookup needed)
            connector = ClickupApiConnector(
                auth_config=AirbyteAuthConfig(
                    airbyte_client_id="client_abc123",
                    airbyte_client_secret="secret_xyz789",
                    connector_id="existing-source-uuid"
                )
            )

            # Hosted mode with lookup by workspace_name
            connector = ClickupApiConnector(
                auth_config=AirbyteAuthConfig(
                    workspace_name="user-123",
                    organization_id="00000000-0000-0000-0000-000000000123",
                    airbyte_client_id="client_abc123",
                    airbyte_client_secret="secret_xyz789"
                )
            )
        """
        # Accept AirbyteAuthConfig from any vendored SDK version
        if (
            auth_config is not None
            and not isinstance(auth_config, AirbyteAuthConfig)
            and type(auth_config).__name__ == AirbyteAuthConfig.__name__
        ):
            auth_config = AirbyteAuthConfig(**auth_config.model_dump())

        # Validate auth_config type
        if auth_config is not None and not isinstance(auth_config, self._ACCEPTED_AUTH_TYPES):
            raise TypeError(
                f"Unsupported auth_config type: {type(auth_config).__name__}. "
                f"Expected one of: {', '.join(t.__name__ for t in self._ACCEPTED_AUTH_TYPES)}"
            )

        # Hosted mode: auth_config is AirbyteAuthConfig
        is_hosted = isinstance(auth_config, AirbyteAuthConfig)

        if is_hosted:
            from airbyte_agent_sdk.executor import HostedExecutor
            self._executor = HostedExecutor(
                airbyte_client_id=auth_config.airbyte_client_id,
                airbyte_client_secret=auth_config.airbyte_client_secret,
                connector_id=auth_config.connector_id,
                workspace_name=auth_config.workspace_name or "default",
                organization_id=auth_config.organization_id,
                connector_definition_id=str(ClickupApiConnectorModel.id),
                model=ClickupApiConnectorModel,
            )
        else:
            # Local mode: auth_config required (must be connector-specific auth type)
            if not auth_config:
                raise ValueError(
                    "Either provide AirbyteAuthConfig with client credentials for hosted mode, "
                    "or ClickupApiAuthConfig for local mode"
                )

            from airbyte_agent_sdk.executor import LocalExecutor

            # Build config_values dict from server variables
            config_values = None

            self._executor = LocalExecutor(
                model=ClickupApiConnectorModel,
                auth_config=auth_config.model_dump() if auth_config else None,
                config_values=config_values,
                on_token_refresh=on_token_refresh
            )

            # Update base_url with server variables if provided

        # Initialize entity query objects
        self.user = UserQuery(self)
        self.teams = TeamsQuery(self)
        self.spaces = SpacesQuery(self)
        self.folders = FoldersQuery(self)
        self.lists = ListsQuery(self)
        self.tasks = TasksQuery(self)
        self.comments = CommentsQuery(self)
        self.goals = GoalsQuery(self)
        self.views = ViewsQuery(self)
        self.view_tasks = ViewTasksQuery(self)
        self.time_tracking = TimeTrackingQuery(self)
        self.members = MembersQuery(self)
        self.docs = DocsQuery(self)

    # ===== TYPED EXECUTE METHOD (Recommended Interface) =====

    @overload
    async def execute(
        self,
        entity: Literal["user"],
        action: Literal["get"],
        params: "UserGetParams"
    ) -> "User": ...

    @overload
    async def execute(
        self,
        entity: Literal["teams"],
        action: Literal["list"],
        params: "TeamsListParams"
    ) -> "TeamsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["spaces"],
        action: Literal["list"],
        params: "SpacesListParams"
    ) -> "SpacesListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["spaces"],
        action: Literal["get"],
        params: "SpacesGetParams"
    ) -> "Space": ...

    @overload
    async def execute(
        self,
        entity: Literal["folders"],
        action: Literal["list"],
        params: "FoldersListParams"
    ) -> "FoldersListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["folders"],
        action: Literal["get"],
        params: "FoldersGetParams"
    ) -> "Folder": ...

    @overload
    async def execute(
        self,
        entity: Literal["lists"],
        action: Literal["list"],
        params: "ListsListParams"
    ) -> "ListsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["lists"],
        action: Literal["get"],
        params: "ListsGetParams"
    ) -> "List": ...

    @overload
    async def execute(
        self,
        entity: Literal["tasks"],
        action: Literal["list"],
        params: "TasksListParams"
    ) -> "TasksListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["tasks"],
        action: Literal["get"],
        params: "TasksGetParams"
    ) -> "Task": ...

    @overload
    async def execute(
        self,
        entity: Literal["tasks"],
        action: Literal["api_search"],
        params: "TasksApiSearchParams"
    ) -> "TasksApiSearchResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["comments"],
        action: Literal["list"],
        params: "CommentsListParams"
    ) -> "CommentsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["comments"],
        action: Literal["create"],
        params: "CommentsCreateParams"
    ) -> "CommentCreateResponse": ...

    @overload
    async def execute(
        self,
        entity: Literal["comments"],
        action: Literal["get"],
        params: "CommentsGetParams"
    ) -> "list[Comment]": ...

    @overload
    async def execute(
        self,
        entity: Literal["comments"],
        action: Literal["update"],
        params: "CommentsUpdateParams"
    ) -> "CommentUpdateResponse": ...

    @overload
    async def execute(
        self,
        entity: Literal["goals"],
        action: Literal["list"],
        params: "GoalsListParams"
    ) -> "GoalsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["goals"],
        action: Literal["get"],
        params: "GoalsGetParams"
    ) -> "Goal": ...

    @overload
    async def execute(
        self,
        entity: Literal["views"],
        action: Literal["list"],
        params: "ViewsListParams"
    ) -> "ViewsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["views"],
        action: Literal["get"],
        params: "ViewsGetParams"
    ) -> "View": ...

    @overload
    async def execute(
        self,
        entity: Literal["view_tasks"],
        action: Literal["list"],
        params: "ViewTasksListParams"
    ) -> "ViewTasksListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["time_tracking"],
        action: Literal["list"],
        params: "TimeTrackingListParams"
    ) -> "TimeTrackingListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["time_tracking"],
        action: Literal["get"],
        params: "TimeTrackingGetParams"
    ) -> "TimeEntry": ...

    @overload
    async def execute(
        self,
        entity: Literal["members"],
        action: Literal["list"],
        params: "MembersListParams"
    ) -> "MembersListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["docs"],
        action: Literal["list"],
        params: "DocsListParams"
    ) -> "DocsListResult": ...

    @overload
    async def execute(
        self,
        entity: Literal["docs"],
        action: Literal["get"],
        params: "DocsGetParams"
    ) -> "Doc": ...


    @overload
    async def execute(
        self,
        entity: str,
        action: Literal["get", "list", "api_search", "create", "update", "context_store_search"],
        params: Mapping[str, Any]
    ) -> ClickupApiExecuteResult[Any] | ClickupApiExecuteResultWithMeta[Any, Any] | Any: ...

    async def execute(
        self,
        entity: str,
        action: Literal["get", "list", "api_search", "create", "update", "context_store_search"],
        params: Mapping[str, Any] | None = None
    ) -> Any:
        """
        Execute an entity operation with full type safety.

        This is the recommended interface for blessed connectors as it:
        - Uses the same signature as non-blessed connectors
        - Provides full IDE autocomplete for entity/action/params
        - Makes migration from generic to blessed connectors seamless

        Args:
            entity: Entity name (e.g., "customers")
            action: Operation action (e.g., "create", "get", "list")
            params: Operation parameters (typed based on entity+action)

        Returns:
            Typed response based on the operation

        Example:
            customer = await connector.execute(
                entity="customers",
                action="get",
                params={"id": "cus_123"}
            )
        """
        from airbyte_agent_sdk.executor import ExecutionConfig

        # Remap parameter names from snake_case (TypedDict keys) to API parameter names
        resolved_params = dict(params) if params is not None else None
        if resolved_params:
            param_map = self._PARAM_MAP.get((entity, action), {})
            if param_map:
                resolved_params = {param_map.get(k, k): v for k, v in resolved_params.items()}

        # Use ExecutionConfig for both local and hosted executors
        config = ExecutionConfig(
            entity=entity,
            action=action,
            params=resolved_params
        )

        result = await self._executor.execute(config)

        if not result.success:
            raise RuntimeError(f"Execution failed: {result.error}")

        # Check if this operation has extractors configured
        has_extractors = self._ENVELOPE_MAP.get((entity, action), False)

        if has_extractors:
            # With extractors - return Pydantic envelope with data and meta
            if result.meta is not None:
                return ClickupApiExecuteResultWithMeta[Any, Any](
                    data=result.data,
                    meta=result.meta
                )
            else:
                return ClickupApiExecuteResult[Any](data=result.data)
        else:
            # No extractors - return raw response data
            return result.data

    # ===== HEALTH CHECK METHOD =====

    async def check(self) -> ClickupApiCheckResult:
        """
        Perform a health check to verify connectivity and credentials.

        Executes a lightweight list operation (limit=1) to validate that
        the connector can communicate with the API and credentials are valid.

        Returns:
            ClickupApiCheckResult with status ("healthy" or "unhealthy") and optional error message

        Example:
            result = await connector.check()
            if result.status == "healthy":
                print("Connection verified!")
            else:
                print(f"Check failed: {result.error}")
        """
        result = await self._executor.check()

        if result.success and isinstance(result.data, dict):
            return ClickupApiCheckResult(
                status=result.data.get("status", "unhealthy"),
                error=result.data.get("error"),
                checked_entity=result.data.get("checked_entity"),
                checked_action=result.data.get("checked_action"),
            )
        else:
            return ClickupApiCheckResult(
                status="unhealthy",
                error=result.error or "Unknown error during health check",
            )

    # ===== INTROSPECTION METHODS =====

    @classmethod
    def tool_utils(
        cls,
        func: _F | None = None,
        *,
        update_docstring: bool = True,
        max_output_chars: int | None = DEFAULT_MAX_OUTPUT_CHARS,
        framework: FrameworkName | None = None,
        internal_retries: int = 0,
        should_internal_retry: Callable[[Exception, tuple[Any, ...], dict[str, Any]], bool] | None = None,
        exhausted_runtime_failure_message: Callable[[Exception, tuple[Any, ...], dict[str, Any]], str | None] | None = None,
    ) -> _F | Callable[[_F], _F]:
        """
        Decorator that adds tool utilities like docstring augmentation and output limits.

        Composes :func:`airbyte_agent_sdk.translation.translate_exceptions` for
        runtime wrapping (sync/async branch + output-size check + framework
        signal translation + optional internal retry loop), and adds
        connector-specific docstring augmentation on top of it.

        Usage:
            @mcp.tool()
            @ClickupApiConnector.tool_utils
            async def execute(entity: str, action: str, params: dict):
                ...

            @mcp.tool()
            @ClickupApiConnector.tool_utils(update_docstring=False, max_output_chars=None)
            async def execute(entity: str, action: str, params: dict):
                ...

            @mcp.tool()
            @ClickupApiConnector.tool_utils(framework="pydantic_ai", internal_retries=2)
            async def execute(entity: str, action: str, params: dict):
                ...

        Args:
            update_docstring: When True, append connector capabilities to __doc__.
            max_output_chars: Max serialized output size before raising. Use None to disable.
            framework: One of ``"pydantic_ai" | "langchain" | "openai_agents" | "mcp"``.
                Defaults to None → auto-detect by attempting each framework's canonical
                import in order. Explicit always wins.
            internal_retries: How many transient runtime failures (429/5xx, network,
                timeout) to retry silently before surfacing. Default 0. Forwarded to
                :func:`airbyte_agent_sdk.translation.translate_exceptions`.
            should_internal_retry: Optional predicate ``(error, args, kwargs) -> bool``
                further restricting which retryable errors are safe for this specific
                tool. Forwarded to
                :func:`airbyte_agent_sdk.translation.translate_exceptions`.
            exhausted_runtime_failure_message: Optional callback
                ``(error, args, kwargs) -> str | None``. Invoked after internal retries
                are exhausted OR were skipped via ``should_internal_retry`` returning
                False. Forwarded to
                :func:`airbyte_agent_sdk.translation.translate_exceptions`.
        """

        def decorate(inner: _F) -> _F:
            if update_docstring:
                description = generate_tool_description(
                    ClickupApiConnectorModel,
                )
                original_doc = inner.__doc__ or ""
                if original_doc.strip():
                    full_doc = f"{original_doc.strip()}\n{description}"
                else:
                    full_doc = description
            else:
                full_doc = ""

            wrapped = translate_exceptions(
                inner,
                framework=framework,
                max_output_chars=max_output_chars,
                internal_retries=internal_retries,
                should_internal_retry=should_internal_retry,
                exhausted_runtime_failure_message=exhausted_runtime_failure_message,
            )

            if update_docstring:
                wrapped.__doc__ = full_doc
            return wrapped  # type: ignore[return-value]

        if func is not None:
            return decorate(func)
        return decorate

    def list_entities(self) -> list[dict[str, Any]]:
        """
        Get structured data about available entities, actions, and parameters.

        Returns a list of entity descriptions with:
        - entity_name: Name of the entity (e.g., "contacts", "deals")
        - description: Entity description from the first endpoint
        - available_actions: List of actions (e.g., ["list", "get", "create"])
        - parameters: Dict mapping action -> list of parameter dicts

        Example:
            entities = connector.list_entities()
            for entity in entities:
                print(f"{entity['entity_name']}: {entity['available_actions']}")
        """
        return describe_entities(ClickupApiConnectorModel)

    def entity_schema(self, entity: str) -> dict[str, Any] | None:
        """
        Get the JSON schema for an entity.

        Args:
            entity: Entity name (e.g., "contacts", "companies")

        Returns:
            JSON schema dict describing the entity structure, or None if not found.

        Example:
            schema = connector.entity_schema("contacts")
            if schema:
                print(f"Contact properties: {list(schema.get('properties', {}).keys())}")
        """
        entity_def = next(
            (e for e in ClickupApiConnectorModel.entities if e.name == entity),
            None
        )
        if entity_def is None:
            logging.getLogger(__name__).warning(
                f"Entity '{entity}' not found. Available entities: "
                f"{[e.name for e in ClickupApiConnectorModel.entities]}"
            )
        return entity_def.entity_schema if entity_def else None

    @property
    def connector_id(self) -> str | None:
        """Get the connector/source ID (only available in hosted mode).

        Returns:
            The connector ID if in hosted mode, None if in local mode.
        """
        if hasattr(self, '_executor') and hasattr(self._executor, '_connector_id'):
            return self._executor._connector_id
        return None

    # ===== RESOURCE MANAGEMENT =====

    async def close(self):
        """Close the connector and release resources."""
        await self._executor.close()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()



class UserQuery:
    """
    Query class for User entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def get(
        self,
        **kwargs
    ) -> User:
        """
        View the details of the authenticated user's ClickUp account

        Returns:
            User
        """
        params = {k: v for k, v in {
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("user", "get", params)
        return result



    async def context_store_search(
        self,
        query: UserSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> UserSearchResult:
        """
        Search user records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (UserSearchFilter):
        - id: Unique identifier for the user
        - username: Display name of the user

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            UserSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("user", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return UserSearchResult(
            data=[
                UserSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class TeamsQuery:
    """
    Query class for Teams entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        **kwargs
    ) -> TeamsListResult:
        """
        Get the workspaces (teams) available to the authenticated user

        Returns:
            TeamsListResult
        """
        params = {k: v for k, v in {
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("teams", "list", params)
        # Cast generic envelope to concrete typed result
        return TeamsListResult(
            data=result.data
        )



    async def context_store_search(
        self,
        query: TeamsSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> TeamsSearchResult:
        """
        Search teams records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (TeamsSearchFilter):
        - id: Unique identifier for the team (workspace)
        - name: Name of the team

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            TeamsSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("teams", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return TeamsSearchResult(
            data=[
                TeamsSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class SpacesQuery:
    """
    Query class for Spaces entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        team_id: str,
        **kwargs
    ) -> SpacesListResult:
        """
        Get the spaces available in a workspace

        Args:
            team_id: The ID of the workspace
            **kwargs: Additional parameters

        Returns:
            SpacesListResult
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("spaces", "list", params)
        # Cast generic envelope to concrete typed result
        return SpacesListResult(
            data=result.data
        )



    async def get(
        self,
        space_id: str,
        **kwargs
    ) -> Space:
        """
        Get a single space by ID

        Args:
            space_id: The ID of the space
            **kwargs: Additional parameters

        Returns:
            Space
        """
        params = {k: v for k, v in {
            "space_id": space_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("spaces", "get", params)
        return result



    async def context_store_search(
        self,
        query: SpacesSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> SpacesSearchResult:
        """
        Search spaces records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (SpacesSearchFilter):
        - id: Unique identifier for the space
        - name: Name of the space
        - private: Whether the space is private

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            SpacesSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("spaces", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return SpacesSearchResult(
            data=[
                SpacesSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class FoldersQuery:
    """
    Query class for Folders entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        space_id: str,
        **kwargs
    ) -> FoldersListResult:
        """
        Get the folders in a space

        Args:
            space_id: The ID of the space
            **kwargs: Additional parameters

        Returns:
            FoldersListResult
        """
        params = {k: v for k, v in {
            "space_id": space_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("folders", "list", params)
        # Cast generic envelope to concrete typed result
        return FoldersListResult(
            data=result.data
        )



    async def get(
        self,
        folder_id: str,
        **kwargs
    ) -> Folder:
        """
        Get a single folder by ID

        Args:
            folder_id: The ID of the folder
            **kwargs: Additional parameters

        Returns:
            Folder
        """
        params = {k: v for k, v in {
            "folder_id": folder_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("folders", "get", params)
        return result



    async def context_store_search(
        self,
        query: FoldersSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> FoldersSearchResult:
        """
        Search folders records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (FoldersSearchFilter):
        - id: Unique identifier for the folder
        - name: Name of the folder
        - hidden: Whether the folder is hidden from the sidebar
        - task_count: Number of tasks contained in the folder

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            FoldersSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("folders", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return FoldersSearchResult(
            data=[
                FoldersSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class ListsQuery:
    """
    Query class for Lists entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        folder_id: str,
        **kwargs
    ) -> ListsListResult:
        """
        Get the lists in a folder

        Args:
            folder_id: The ID of the folder
            **kwargs: Additional parameters

        Returns:
            ListsListResult
        """
        params = {k: v for k, v in {
            "folder_id": folder_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("lists", "list", params)
        # Cast generic envelope to concrete typed result
        return ListsListResult(
            data=result.data
        )



    async def get(
        self,
        list_id: str,
        **kwargs
    ) -> List:
        """
        Get a single list by ID

        Args:
            list_id: The ID of the list
            **kwargs: Additional parameters

        Returns:
            List
        """
        params = {k: v for k, v in {
            "list_id": list_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("lists", "get", params)
        return result



    async def context_store_search(
        self,
        query: ListsSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> ListsSearchResult:
        """
        Search lists records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (ListsSearchFilter):
        - id: Unique identifier for the list
        - name: Name of the list
        - archived: Whether the list has been archived
        - due_date: Due date for the list, in ClickUp timestamp format
        - start_date: Start date for the list, in ClickUp timestamp format
        - priority: Priority assigned to the list
        - task_count: Number of tasks contained in the list

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            ListsSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("lists", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return ListsSearchResult(
            data=[
                ListsSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class TasksQuery:
    """
    Query class for Tasks entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        list_id: str,
        page: int | None = None,
        **kwargs
    ) -> TasksListResult:
        """
        Get the tasks in a list

        Args:
            list_id: The ID of the list
            page: Page number (0-indexed)
            **kwargs: Additional parameters

        Returns:
            TasksListResult
        """
        params = {k: v for k, v in {
            "list_id": list_id,
            "page": page,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("tasks", "list", params)
        # Cast generic envelope to concrete typed result
        return TasksListResult(
            data=result.data,
            meta=getattr(result, "meta", None)
        )



    async def get(
        self,
        task_id: str,
        custom_task_ids: bool | None = None,
        include_subtasks: bool | None = None,
        **kwargs
    ) -> Task:
        """
        Get a single task by ID

        Args:
            task_id: The ID of the task
            custom_task_ids: Set to true to use a custom task ID
            include_subtasks: Include subtasks
            **kwargs: Additional parameters

        Returns:
            Task
        """
        params = {k: v for k, v in {
            "task_id": task_id,
            "custom_task_ids": custom_task_ids,
            "include_subtasks": include_subtasks,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("tasks", "get", params)
        return result



    async def api_search(
        self,
        team_id: str,
        search: str | None = None,
        statuses: list[str] | None = None,
        assignees: list[str] | None = None,
        tags: list[str] | None = None,
        priority: int | None = None,
        due_date_gt: int | None = None,
        due_date_lt: int | None = None,
        date_created_gt: int | None = None,
        date_created_lt: int | None = None,
        date_updated_gt: int | None = None,
        date_updated_lt: int | None = None,
        custom_fields: list[dict[str, Any]] | None = None,
        include_closed: bool | None = None,
        page: int | None = None,
        **kwargs
    ) -> TasksApiSearchResult:
        """
        View the tasks that meet specific criteria from a workspace. Supports free-text search
and structured filters including status, assignee, tags, priority, and date ranges.
Responses are limited to 100 tasks per page.


        Args:
            team_id: The workspace ID to search within
            search: Free-text search across task name, description, and custom field text
            statuses: Filter by status names (e.g. "in progress", "done")
            assignees: Filter by user IDs
            tags: Filter by tag names
            priority: Filter by priority: 1=Urgent, 2=High, 3=Normal, 4=Low
            due_date_gt: Due date after (Unix ms)
            due_date_lt: Due date before (Unix ms)
            date_created_gt: Created after (Unix ms)
            date_created_lt: Created before (Unix ms)
            date_updated_gt: Updated after (Unix ms)
            date_updated_lt: Updated before (Unix ms)
            custom_fields: JSON array of custom field filters. Each object: {"field_id": "<UUID>", "operator": "<OP>", "value": "<DATA>"}.
Operators: = (contains), == (exact), <, <=, >, >=, !=, !==, IS NULL, IS NOT NULL, RANGE, ANY, ALL, NOT ANY, NOT ALL

            include_closed: Include closed tasks (excluded by default)
            page: Page number (0-indexed), results capped at 100/page
            **kwargs: Additional parameters

        Returns:
            TasksApiSearchResult
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            "search": search,
            "statuses[]": statuses,
            "assignees[]": assignees,
            "tags[]": tags,
            "priority": priority,
            "due_date_gt": due_date_gt,
            "due_date_lt": due_date_lt,
            "date_created_gt": date_created_gt,
            "date_created_lt": date_created_lt,
            "date_updated_gt": date_updated_gt,
            "date_updated_lt": date_updated_lt,
            "custom_fields": custom_fields,
            "include_closed": include_closed,
            "page": page,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("tasks", "api_search", params)
        # Cast generic envelope to concrete typed result
        return TasksApiSearchResult(
            data=result.data,
            meta=getattr(result, "meta", None)
        )



    async def context_store_search(
        self,
        query: TasksSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> TasksSearchResult:
        """
        Search tasks records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (TasksSearchFilter):
        - id: Unique identifier for the task
        - name: Name of the task
        - date_created: Creation timestamp of the task, in ClickUp timestamp format
        - date_updated: Last update timestamp of the task, in ClickUp timestamp format
        - date_closed: Timestamp when the task was closed, in ClickUp timestamp format
        - due_date: Due date for the task, in ClickUp timestamp format
        - start_date: Start date for the task, in ClickUp timestamp format
        - parent: ID of the parent task, if this task is a subtask
        - url: Permalink URL to view the task in ClickUp

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            TasksSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("tasks", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return TasksSearchResult(
            data=[
                TasksSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class CommentsQuery:
    """
    Query class for Comments entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        task_id: str,
        **kwargs
    ) -> CommentsListResult:
        """
        Get the comments on a task

        Args:
            task_id: The ID of the task
            **kwargs: Additional parameters

        Returns:
            CommentsListResult
        """
        params = {k: v for k, v in {
            "task_id": task_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("comments", "list", params)
        # Cast generic envelope to concrete typed result
        return CommentsListResult(
            data=result.data
        )



    async def create(
        self,
        comment_text: str,
        task_id: str,
        assignee: int | None = None,
        notify_all: bool | None = None,
        **kwargs
    ) -> CommentCreateResponse:
        """
        Create a comment on a task

        Args:
            comment_text: The comment text
            assignee: User ID to assign
            notify_all: Notify all assignees and watchers
            task_id: The ID of the task
            **kwargs: Additional parameters

        Returns:
            CommentCreateResponse
        """
        params = {k: v for k, v in {
            "comment_text": comment_text,
            "assignee": assignee,
            "notify_all": notify_all,
            "task_id": task_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("comments", "create", params)
        return result



    async def get(
        self,
        comment_id: str,
        **kwargs
    ) -> list[Comment]:
        """
        Get threaded replies on a comment

        Args:
            comment_id: The ID of the comment
            **kwargs: Additional parameters

        Returns:
            list[Comment]
        """
        params = {k: v for k, v in {
            "comment_id": comment_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("comments", "get", params)
        return result



    async def update(
        self,
        comment_id: str,
        comment_text: str | None = None,
        assignee: int | None = None,
        resolved: bool | None = None,
        **kwargs
    ) -> CommentUpdateResponse:
        """
        Update an existing comment

        Args:
            comment_text: Updated comment text
            assignee: User ID to assign
            resolved: Whether the comment is resolved
            comment_id: The ID of the comment
            **kwargs: Additional parameters

        Returns:
            CommentUpdateResponse
        """
        params = {k: v for k, v in {
            "comment_text": comment_text,
            "assignee": assignee,
            "resolved": resolved,
            "comment_id": comment_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("comments", "update", params)
        return result



    async def context_store_search(
        self,
        query: CommentsSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> CommentsSearchResult:
        """
        Search comments records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (CommentsSearchFilter):
        - id: Unique identifier for the comment
        - comment_text: Plain-text content of the comment
        - date: Timestamp when the comment was posted, in ClickUp timestamp format
        - reply_count: Number of replies on the comment

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            CommentsSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("comments", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return CommentsSearchResult(
            data=[
                CommentsSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class GoalsQuery:
    """
    Query class for Goals entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        team_id: str,
        **kwargs
    ) -> GoalsListResult:
        """
        Get the goals in a workspace

        Args:
            team_id: The ID of the workspace
            **kwargs: Additional parameters

        Returns:
            GoalsListResult
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("goals", "list", params)
        # Cast generic envelope to concrete typed result
        return GoalsListResult(
            data=result.data
        )



    async def get(
        self,
        goal_id: str,
        **kwargs
    ) -> Goal:
        """
        Get a single goal by ID

        Args:
            goal_id: The ID of the goal
            **kwargs: Additional parameters

        Returns:
            Goal
        """
        params = {k: v for k, v in {
            "goal_id": goal_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("goals", "get", params)
        return result



    async def context_store_search(
        self,
        query: GoalsSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> GoalsSearchResult:
        """
        Search goals records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (GoalsSearchFilter):
        - id: Unique identifier for the goal
        - name: Name of the goal
        - description: Description of the goal
        - archived: Whether the goal has been archived
        - pinned: Whether the goal is pinned to the top of the list
        - private: Whether the goal is private to its owners
        - date_created: Creation timestamp of the goal, in ClickUp timestamp format
        - due_date: Due date for the goal, in ClickUp timestamp format
        - percent_completed: Completion percentage of the goal, between 0 and 100
        - team_id: Identifier of the team that owns the goal

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            GoalsSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("goals", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return GoalsSearchResult(
            data=[
                GoalsSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class ViewsQuery:
    """
    Query class for Views entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        team_id: str,
        **kwargs
    ) -> ViewsListResult:
        """
        Get the workspace-level (Everything level) views

        Args:
            team_id: The ID of the workspace
            **kwargs: Additional parameters

        Returns:
            ViewsListResult
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("views", "list", params)
        # Cast generic envelope to concrete typed result
        return ViewsListResult(
            data=result.data
        )



    async def get(
        self,
        view_id: str,
        **kwargs
    ) -> View:
        """
        Get a single view by ID

        Args:
            view_id: The ID of the view
            **kwargs: Additional parameters

        Returns:
            View
        """
        params = {k: v for k, v in {
            "view_id": view_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("views", "get", params)
        return result



class ViewTasksQuery:
    """
    Query class for ViewTasks entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        view_id: str,
        page: int | None = None,
        **kwargs
    ) -> ViewTasksListResult:
        """
        Get tasks matching a view's pre-configured filters — useful as a secondary search mechanism

        Args:
            view_id: The ID of the view
            page: Page number (0-indexed)
            **kwargs: Additional parameters

        Returns:
            ViewTasksListResult
        """
        params = {k: v for k, v in {
            "view_id": view_id,
            "page": page,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("view_tasks", "list", params)
        # Cast generic envelope to concrete typed result
        return ViewTasksListResult(
            data=result.data,
            meta=getattr(result, "meta", None)
        )



class TimeTrackingQuery:
    """
    Query class for TimeTracking entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        team_id: str,
        start_date: int | None = None,
        end_date: int | None = None,
        assignee: str | None = None,
        **kwargs
    ) -> TimeTrackingListResult:
        """
        Get time entries within a date range for a workspace

        Args:
            team_id: The ID of the workspace
            start_date: Start date (Unix ms)
            end_date: End date (Unix ms)
            assignee: Filter by user ID
            **kwargs: Additional parameters

        Returns:
            TimeTrackingListResult
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            "start_date": start_date,
            "end_date": end_date,
            "assignee": assignee,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("time_tracking", "list", params)
        # Cast generic envelope to concrete typed result
        return TimeTrackingListResult(
            data=result.data
        )



    async def get(
        self,
        team_id: str,
        time_entry_id: str,
        **kwargs
    ) -> TimeEntry:
        """
        Get a single time entry by ID

        Args:
            team_id: The ID of the workspace
            time_entry_id: The ID of the time entry
            **kwargs: Additional parameters

        Returns:
            TimeEntry
        """
        params = {k: v for k, v in {
            "team_id": team_id,
            "time_entry_id": time_entry_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("time_tracking", "get", params)
        return result



    async def context_store_search(
        self,
        query: TimeTrackingSearchQuery,
        limit: int | None = None,
        cursor: str | None = None,
        fields: list[list[str]] | None = None,
    ) -> TimeTrackingSearchResult:
        """
        Search time_tracking records from Airbyte cache.

        This operation searches cached data from Airbyte syncs.
        Only available in hosted execution mode.

        Available filter fields (TimeTrackingSearchFilter):
        - time: Total tracked time in milliseconds
        - user: User who tracked the time

        Args:
            query: Filter and sort conditions. Supports operators like eq, neq, gt, gte, lt, lte,
                   in, like, fuzzy, keyword, not, and, or. Example: {"filter": {"eq": {"status": "active"}}}
            limit: Maximum results to return (default 1000)
            cursor: Pagination cursor from previous response's meta.cursor
            fields: Field paths to include in results. Each path is a list of keys for nested access.
                    Example: [["id"], ["user", "name"]] returns id and user.name fields.

        Returns:
            TimeTrackingSearchResult with typed records, pagination metadata, and optional search metadata

        Raises:
            NotImplementedError: If called in local execution mode
        """
        params: dict[str, Any] = {"query": query}
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if fields is not None:
            params["fields"] = fields

        result = await self._connector.execute("time_tracking", "context_store_search", params)

        # Parse response into typed result
        meta_data = result.get("meta")
        return TimeTrackingSearchResult(
            data=[
                TimeTrackingSearchData(**row)
                for row in result.get("data", [])
                if isinstance(row, dict)
            ],
            meta=AirbyteSearchMeta(
                has_more=meta_data.get("has_more", False) if isinstance(meta_data, dict) else False,
                cursor=meta_data.get("cursor") if isinstance(meta_data, dict) else None,
                took_ms=meta_data.get("took_ms") if isinstance(meta_data, dict) else None,
            ),
        )

class MembersQuery:
    """
    Query class for Members entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        task_id: str,
        **kwargs
    ) -> MembersListResult:
        """
        Get the members assigned to a task

        Args:
            task_id: The ID of the task
            **kwargs: Additional parameters

        Returns:
            MembersListResult
        """
        params = {k: v for k, v in {
            "task_id": task_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("members", "list", params)
        # Cast generic envelope to concrete typed result
        return MembersListResult(
            data=result.data
        )



class DocsQuery:
    """
    Query class for Docs entity operations.
    """

    def __init__(self, connector: ClickupApiConnector):
        """Initialize query with connector reference."""
        self._connector = connector

    async def list(
        self,
        workspace_id: str,
        cursor: str | None = None,
        **kwargs
    ) -> DocsListResult:
        """
        Search for docs in a workspace

        Args:
            workspace_id: The ID of the workspace
            cursor: Cursor for pagination to the next page of results
            **kwargs: Additional parameters

        Returns:
            DocsListResult
        """
        params = {k: v for k, v in {
            "workspace_id": workspace_id,
            "cursor": cursor,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("docs", "list", params)
        # Cast generic envelope to concrete typed result
        return DocsListResult(
            data=result.data,
            meta=getattr(result, "meta", None)
        )



    async def get(
        self,
        workspace_id: str,
        doc_id: str,
        **kwargs
    ) -> Doc:
        """
        Fetch a single doc by ID

        Args:
            workspace_id: The ID of the workspace
            doc_id: The ID of the doc
            **kwargs: Additional parameters

        Returns:
            Doc
        """
        params = {k: v for k, v in {
            "workspace_id": workspace_id,
            "doc_id": doc_id,
            **kwargs
        }.items() if v is not None}

        result = await self._connector.execute("docs", "get", params)
        return result


