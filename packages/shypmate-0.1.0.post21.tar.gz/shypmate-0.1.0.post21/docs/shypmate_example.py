"""
Example shypmate.py — programmatic configuration for shypmate.

Place this file as 'shypmate.py' at the root of your project (next to shypmate.yml).
It provides a Python-based alternative to shypmate.yml for dynamic configuration.

Priority: env var > shypmate.yml > shypmate.py > auto-detect > default

Use shypmate.py when you need:
  - Logic-based config that can't be expressed in YAML
  - Custom LLM selection strategies (instead of round-robin)
  - Config derived from project state at runtime
  - Conditional settings based on environment

Note: Do NOT import from shypmate in this file — hook functions receive
the objects they need as arguments (e.g., pool entries have .provider, .model attributes).
"""

import os
import subprocess


# ══════════════════════════════════════════════════════════════
# Option A: Static config dict — same keys as shypmate.yml
# ══════════════════════════════════════════════════════════════
# Any values here are used as defaults. shypmate.yml overrides
# these per-field, so you can use both files together.
# You can use BOTH the config dict AND individual functions.

config = {
    "docker": {
        "network": "myproject_default",
    },
    "install_command": "pip install -r requirements.txt",
    "shared_service_rules": [
        "Do NOT run migrations against the shared database.",
        "Do NOT flush Redis.",
    ],
    "llm": {
        "provider": "anthropic",
        "pool": [
            {"provider": "anthropic", "model": "claude-sonnet-4-6", "api_key_var": "ANTHROPIC_API_KEY"},
            {"provider": "openai", "model": "gpt-4o", "api_key_var": "OPENAI_API_KEY"},
            {"provider": "ollama", "model": "llama3.1"},
        ],
    },
}


# ══════════════════════════════════════════════════════════════
# Option B: Individual functions — for dynamic/derived values
# ══════════════════════════════════════════════════════════════
# If a function exists with a known name, it's called and its return
# value overrides the config dict for that field. This lets you mix
# static config with dynamically computed values.
#
# Available function names:
#   github_repo, base_branch, docker_network, install_command,
#   tech_stack, context_files, validation_commands, shared_service_rules,
#   llm_provider, llm_model, llm_max_tokens, llm_base_url, llm_api_key_var,
#   llm_pool, branch_prefix, pr_title_prefix, pr_label,
#   allowed_shell_prefixes, blocked_shell_patterns

def github_repo():
    """Derive the GitHub repo from the git remote — no need to hardcode it."""
    import re
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True,
        )
        url = result.stdout.strip()
        match = re.match(r"(?:https?://github\.com/|git@github\.com:)([^/]+/[^/]+?)(?:\.git)?$", url)
        return match.group(1) if match else None
    except Exception:
        return None


def tech_stack():
    """Detect tech stack from project files."""
    from pathlib import Path
    stack = []
    if Path("pyproject.toml").exists():
        stack.append("Python")
    if Path("package.json").exists():
        stack.append("Node.js")
    if Path("go.mod").exists():
        stack.append("Go")
    # Read pyproject.toml for framework hints
    if Path("pyproject.toml").exists():
        content = Path("pyproject.toml").read_text()
        if "django" in content.lower():
            stack.append("Django")
        if "fastapi" in content.lower():
            stack.append("FastAPI")
    return stack or None


def validation_commands():
    """Build validation commands based on what tools are available."""
    from pathlib import Path
    commands = []
    if Path("pyproject.toml").exists() or Path("ruff.toml").exists():
        commands.append({"command": "ruff check .", "description": "Lint Python"})
        commands.append({"command": "ruff format --check .", "description": "Check formatting"})
    if Path("package.json").exists():
        commands.append({"command": "npm run lint", "description": "Lint JS/TS"})
    if Path("pytest.ini").exists() or Path("pyproject.toml").exists():
        commands.append({"command": "pytest --tb=short -q", "description": "Run tests"})
    return commands or None


# ══════════════════════════════════════════════════════════════
# Hooks — optional functions that customize shypmate's behavior
# ══════════════════════════════════════════════════════════════

def select_llm(task, pool, agent_index):
    """Choose which LLM to assign to an agent based on the task.

    Called instead of round-robin when this function is defined.

    Args:
        task: The task description string.
        pool: List of pool entry objects, each with attributes:
              .provider  (str)  — "anthropic", "openai", "ollama", etc.
              .model     (str)  — "claude-sonnet-4-6", "gpt-4o", etc.
              .base_url  (str)  — API endpoint (empty for native providers)
              .api_key_var (str) — env var name for the API key
        agent_index: The agent's position (0-based) in the launch batch.

    Returns:
        One of the pool entry objects.

    Examples of selection strategies:
    """
    task_lower = task.lower()

    # ── Strategy: Route by task keywords ──────────────────────
    # Use Claude for complex backend work
    if any(kw in task_lower for kw in ["refactor", "architecture", "migration", "security"]):
        for entry in pool:
            if entry.provider == "anthropic":
                return entry

    # Use GPT for frontend and UI tasks
    if any(kw in task_lower for kw in ["react", "css", "frontend", "ui", "component"]):
        for entry in pool:
            if entry.provider == "openai":
                return entry

    # Use local LLM for simple tasks (saves API costs)
    if any(kw in task_lower for kw in ["typo", "rename", "comment", "docstring", "formatting"]):
        for entry in pool:
            if entry.provider in ("ollama", "lmstudio"):
                return entry

    # ── Strategy: Route by priority ───────────────────────────
    # (You could check task priority if you pass it through the task description)
    # if "[critical]" in task_lower or "[high]" in task_lower:
    #     for entry in pool:
    #         if entry.provider == "anthropic" and "opus" in entry.model:
    #             return entry

    # ── Strategy: Time-based routing ──────────────────────────
    # Use local LLM during off-hours to save costs
    # from datetime import datetime
    # if datetime.now().hour >= 22 or datetime.now().hour < 6:
    #     for entry in pool:
    #         if entry.provider == "ollama":
    #             return entry

    # ── Default: round-robin ──────────────────────────────────
    return pool[agent_index % len(pool)]
