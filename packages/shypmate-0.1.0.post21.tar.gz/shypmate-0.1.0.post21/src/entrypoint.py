"""
Container entrypoint — the full lifecycle of one dev agent run.

This script runs INSIDE the agent Docker container. It:
1. Reads configuration from environment variables
2. Clones the repo
3. Creates or checks out the agent branch
4. Builds project context
5. Runs the dev agent (think → tool → repeat loop)
6. (Agent handles: edit code, validate, commit, push, create/update PR)
7. Exits
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from git import Repo
from git.exc import GitCommandError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shypmate.entrypoint")


def main() -> int:
    # --- Read env vars ---
    github_token = os.environ.get("GITHUB_TOKEN")
    task_description = os.environ.get("AGENT_TASK", "")
    branch_name = os.environ.get("AGENT_BRANCH", "")
    agent_id = os.environ.get("AGENT_ID", "unknown")
    is_rebase = os.environ.get("AGENT_REBASE", "false").lower() == "true"
    repo_name = os.environ.get("GITHUB_REPO", "")
    base_branch = os.environ.get("BASE_BRANCH", "main")
    workspace = os.environ.get("WORKSPACE", "/workspace")
    task_id = os.environ.get("AGENT_TASK_ID", "")

    if not github_token:
        logger.error("GITHUB_TOKEN is required")
        return 1
    if not repo_name:
        logger.error("GITHUB_REPO is required")
        return 1
    if not task_description:
        logger.error("AGENT_TASK is required")
        return 1
    if not branch_name:
        logger.error("AGENT_BRANCH is required")
        return 1
    # Check for LLM API key — the key var name is passed by the host
    llm_provider = os.environ.get("LLM_PROVIDER", "anthropic")
    if llm_provider == "anthropic" and not os.environ.get("ANTHROPIC_API_KEY"):
        logger.error("ANTHROPIC_API_KEY is required for Anthropic provider")
        return 1

    logger.info("=" * 60)
    logger.info("SHYPMATE AGENT STARTUP")
    logger.info("=" * 60)
    logger.info(f"  Agent ID:    {agent_id}")
    logger.info(f"  Task:        {task_description}")
    logger.info(f"  Branch:      {branch_name}")
    logger.info(f"  Base branch: {base_branch}")
    logger.info(f"  Repo:        {repo_name}")
    logger.info(f"  Rebase:      {is_rebase}")
    logger.info(f"  LLM:         {llm_provider} / {os.environ.get('LLM_MODEL', '?')}")
    logger.info(f"  Install cmd: {os.environ.get('INSTALL_COMMAND', '(none)')}")
    logger.info(f"  Task ID:     {task_id or '(none)'}")
    logger.info(f"  Brief:       {'available' if Path('/brief/project_brief.json').exists() else 'not found (standalone mode)'}")
    logger.info("=" * 60)

    # --- Clone repo ---
    clone_url = f"https://x-access-token:{github_token}@github.com/{repo_name}.git"
    logger.info(f"Cloning {repo_name} into {workspace}...")

    try:
        repo = Repo.clone_from(clone_url, workspace)
    except GitCommandError as e:
        # If workspace already has the repo (e.g., rebase re-run), fetch instead
        if Path(workspace).joinpath(".git").exists():
            logger.info("Workspace already has repo, fetching...")
            repo = Repo(workspace)
            repo.git.fetch("--all")
        else:
            logger.error(f"Clone failed: {e}")
            return 1

    # Configure git identity — uses the developer's name with an agent suffix
    repo.config_writer().set_value("user", "name", f"shypmate-{agent_id}").release()
    repo.config_writer().set_value("user", "email", f"shypmate-{agent_id}@noreply.github.com").release()

    # --- Create or checkout branch ---
    try:
        if is_rebase:
            # For rebase: checkout existing branch
            logger.info(f"Checking out existing branch: {branch_name}")
            repo.git.checkout(branch_name)
        else:
            # For new work: create branch from base
            logger.info(f"Creating branch: {branch_name} from {base_branch}")
            repo.git.checkout(base_branch)
            repo.git.checkout("-b", branch_name)
    except GitCommandError:
        # Branch might exist remotely but not locally
        try:
            repo.git.checkout("-b", branch_name, f"origin/{branch_name}")
        except GitCommandError as e:
            logger.error(f"Branch setup failed: {e}")
            return 1

    # --- Install project dependencies ---
    # In dev mode (/opt/shypmate is mounted from host), skip install commands
    # that would override the mounted framework code (e.g. 'pip install -e .')
    install_command = os.environ.get("INSTALL_COMMAND", "")
    is_dev_mount = Path("/opt/shypmate/.dev_mounted").exists() or os.environ.get("SHYPMATE_DEV_MODE") == "1"
    if install_command and is_dev_mount and "pip install" in install_command:
        logger.info(f"Dev mode: skipping '{install_command}' to preserve mounted framework code")
    elif install_command:
        import subprocess
        logger.info(f"Installing dependencies: {install_command}")
        subprocess.run(
            install_command,
            shell=True,
            cwd=workspace,
            capture_output=True,
        )

    # --- Build project context ---
    # Add workspace to Python path so shypmate imports work
    sys.path.insert(0, workspace)

    # Check for pre-built brief from manager (shared volume at /brief)
    brief_dir = Path("/brief")
    project_context = None

    if brief_dir.exists() and (brief_dir / "project_brief.json").exists():
        logger.info("Found project brief from manager — skipping discovery")
        try:
            from shypmate.manager.project_brief import load_brief, load_task_plan

            brief = load_brief(brief_dir)
            if brief:
                # Build CONDENSED context from the pre-digested brief.
                # Do NOT include raw_context — the whole point is the manager
                # already distilled it into what agents need.
                parts = []
                if brief.understanding:
                    parts.append(f"## Project Understanding\n{brief.understanding}")
                if brief.architecture:
                    parts.append(f"## Architecture\n{brief.architecture}")
                if brief.conventions:
                    parts.append(f"## Coding Conventions (MUST follow)\n{brief.conventions}")
                if brief.file_map:
                    file_map_str = "\n".join(f"  {k}: {v}" for k, v in brief.file_map.items())
                    parts.append(f"## Key Files and Directories\n{file_map_str}")

                # Add task-specific plan if available
                if task_id:
                    plan = load_task_plan(task_id, brief_dir)
                    if plan:
                        plan_parts = [f"## Task Plan"]
                        if plan.approach:
                            plan_parts.append(f"Approach: {plan.approach}")
                        if plan.relevant_files:
                            plan_parts.append(f"Start with these files: {', '.join(plan.relevant_files)}")
                        if plan.patterns_to_follow:
                            plan_parts.append(f"Follow these patterns: {plan.patterns_to_follow}")
                        parts.append("\n".join(plan_parts))
                        logger.info(f"  Task plan loaded: {len(plan.relevant_files)} relevant files")

                project_context = "\n\n".join(parts)
                logger.info(f"  Condensed context from brief: {len(project_context)} chars "
                            f"(raw was {len(brief.raw_context)} chars — "
                            f"{100 - len(project_context) * 100 // max(len(brief.raw_context), 1)}% reduction)")
        except Exception as e:
            logger.warning(f"Could not load brief: {e}")

    # Fall back to standalone discovery if no brief
    if project_context is None:
        logger.info("Building project context (standalone mode)...")
        from shypmate.context.project_context import build_project_context, build_rebase_context

        if is_rebase:
            project_context = build_rebase_context(
                workspace, task_description
            )
        else:
            project_context = build_project_context(workspace)

    # Log context summary so we can see what the agent is working with
    logger.info("=" * 60)
    logger.info("PROJECT CONTEXT SUMMARY")
    logger.info("=" * 60)
    logger.info(f"  Context length: {len(project_context)} chars")
    # Show section headers from the context
    for line in project_context.split("\n"):
        line = line.strip()
        if line.startswith("##") or line.startswith("# "):
            logger.info(f"  Section: {line}")
    # Show first 500 chars as a preview
    logger.info(f"  Preview: {project_context[:500]}")
    logger.info("=" * 60)

    # --- Determine execution mode ---
    pipeline_hats = os.environ.get("PIPELINE_HATS", "")
    sdlc_prompt = os.environ.get("SDLC_PROMPT", "")

    if pipeline_hats:
        # Pipeline mode — run multiple hats in sequence within this container
        return _run_pipeline(
            hat_names=pipeline_hats.split(","),
            task_description=task_description,
            branch_name=branch_name,
            project_context=project_context,
            sdlc_prompt=sdlc_prompt,
        )
    else:
        # Single agent mode (backward compatible)
        logger.info("Starting dev agent...")
        from shypmate.crews.dev_crew import run_dev_crew

        try:
            result = run_dev_crew(
                task_description=task_description,
                branch_name=branch_name,
                project_context=project_context,
                is_rebase=is_rebase,
            )
            logger.info(f"Crew finished. Result:\n{result}")
        except Exception as e:
            logger.error(f"Crew execution failed: {e}", exc_info=True)
            _comment_failure(branch_name, agent_id, str(e))
            return 1

        logger.info("Agent run complete.")
        return 0


def _run_pipeline(
    hat_names: list[str],
    task_description: str,
    branch_name: str,
    project_context: str,
    sdlc_prompt: str = "",
) -> int:
    """Run multiple hats in sequence within a single container."""
    import json as _json

    from shypmate.hats.hat import get_default_hats, DEFAULT_SDLC
    from shypmate.hats.coordinator import load_hats_from_config, parse_hat_outcome, parse_developer_output
    from shypmate.hats.pipeline import get_hat_task_prompt
    from shypmate.hats.context import format_context_for_hat, save_stage_context, init_context
    from shypmate.engine.agent_loop import run_agent, AgentQuota
    from shypmate.engine.providers import create_provider
    from shypmate.engine.tool_registry import ToolRegistry

    agent_id = os.environ.get("AGENT_ID", "unknown")
    comms_dir = Path("/comms")
    sdlc = sdlc_prompt or DEFAULT_SDLC
    max_retries = 2

    # Load hat configs
    all_hats = load_hats_from_config()

    # Initialize pipeline context
    init_context(comms_dir, agent_id, task_description, branch_name)

    logger.info("=" * 60)
    logger.info("PIPELINE MODE")
    logger.info(f"  Hats: {' → '.join(hat_names)}")
    logger.info(f"  SDLC: {sdlc[:200]}")
    logger.info("=" * 60)

    previous_feedback = ""
    retry_count = 0
    hat_index = 0

    while hat_index < len(hat_names):
        hat_name = hat_names[hat_index].strip()
        hat = all_hats.get(hat_name)

        if not hat:
            logger.warning(f"Unknown hat: {hat_name}, skipping")
            hat_index += 1
            continue

        if not hat.enabled:
            logger.info(f"[{hat_name}] Disabled, skipping")
            hat_index += 1
            continue

        # ── Hat switch ──
        logger.info("")
        logger.info("=" * 60)
        logger.info(f"HAT: {hat_name.upper()}")
        logger.info("=" * 60)
        logger.info(f"  Role: {hat.prompt[:100]}...")
        logger.info(f"  Tools: {hat.tools or '(all)'}")
        if hat.max_cost:
            logger.info(f"  Quota: max_cost=${hat.max_cost} max_iterations={hat.max_iterations}")
        logger.info("=" * 60)

        # Build filtered context from previous hats
        pipeline_context = format_context_for_hat(comms_dir, agent_id, hat_name)

        # Build the hat-specific task prompt
        hat_task = get_hat_task_prompt(
            hat, task_description, branch_name,
            previous_feedback, pipeline_context, sdlc,
        )

        # Build system prompt with project context
        system_prompt = f"""{hat.prompt}

PROJECT CONTEXT:
{project_context}
"""

        # Create provider
        provider_name = os.environ.get("LLM_PROVIDER", "anthropic")
        model = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")
        max_tokens = int(os.environ.get("LLM_MAX_TOKENS", "8192"))
        base_url = os.environ.get("LLM_BASE_URL", "")
        api_key_var = os.environ.get("LLM_API_KEY_VAR", "ANTHROPIC_API_KEY")
        api_key = os.environ.get(api_key_var, "") if api_key_var else None

        provider = create_provider(
            provider=provider_name,
            model=model,
            max_tokens=max_tokens,
            base_url=base_url or None,
            api_key=api_key or None,
        )

        # Build tool registry — filter to hat's allowed tools
        from shypmate.agents.dev_agent import create_tool_registry
        full_registry = create_tool_registry()

        if hat.tools:
            # Filtered registry — only the tools this hat is allowed to use
            registry = ToolRegistry()
            for tool_name in hat.tools:
                func = full_registry._tools.get(tool_name)
                if func:
                    registry.register(func)
        else:
            registry = full_registry

        # Build quota for this hat
        quota = AgentQuota(
            hard_max_cost=hat.max_cost if hat.max_cost else 0,
            hard_max_iterations=hat.max_iterations if hat.max_iterations else 0,
            hard_max_seconds=hat.max_seconds if hat.max_seconds else 0,
        )

        # Run the agent for this hat
        try:
            result = run_agent(
                provider=provider,
                system_prompt=system_prompt,
                task_prompt=hat_task,
                registry=registry,
                max_iterations=hat.max_iterations or 50,
                quota=quota,
                hat_name=hat_name,
            )
        except Exception as e:
            logger.error(f"[{hat_name}] Agent failed: {e}", exc_info=True)
            result = f"FAIL: {e}"

        # Parse outcome
        status, feedback = parse_hat_outcome(hat_name, result)

        # Save context for next hat
        stage_data = {
            "result": status,
            "summary": result[:500] if result else "",
            "feedback": feedback[:500] if feedback else "",
        }
        if hat_name == "developer":
            parsed = parse_developer_output(result or "")
            stage_data.update(parsed)

        save_stage_context(comms_dir, agent_id, hat_name, stage_data)

        # Log outcome
        if status == "passed":
            logger.info(f"[{hat_name}] ✓ PASSED")
            previous_feedback = ""
            hat_index += 1
        else:
            logger.warning(f"[{hat_name}] ✗ FAILED")
            if feedback:
                for line in feedback[:300].splitlines():
                    logger.warning(f"  {line}")

            # Retry: loop back to developer
            if hat_name != "developer" and retry_count < max_retries:
                retry_count += 1
                logger.info(f"Looping back to developer (retry {retry_count}/{max_retries})")
                previous_feedback = feedback
                hat_index = 0  # restart from developer
                continue
            else:
                logger.error(f"Pipeline FAILED after {retry_count + 1} attempts")
                return 1

    # All hats passed — open PR
    logger.info("")
    logger.info("=" * 60)
    logger.info("ALL HATS PASSED — opening PR")
    logger.info("=" * 60)

    try:
        from shypmate.tools.github_tools import create_pull_request
        from shypmate.tools.git_tools import git_push

        # Push the branch
        push_result = git_push(branch_name)
        logger.info(f"Push: {push_result}")

        # Create PR
        pr_result = create_pull_request(
            title=f"[AI] {task_description[:60]}",
            body=f"## Task\n{task_description}\n\n## Pipeline\nHats: {' → '.join(hat_names)}\nAll stages passed.",
            branch_name=branch_name,
            base_branch=os.environ.get("BASE_BRANCH", "main"),
        )
        logger.info(f"PR: {pr_result}")
    except Exception as e:
        logger.error(f"Failed to create PR: {e}")
        return 1

    logger.info("Pipeline complete.")
    return 0


def _comment_failure(branch_name: str, agent_id: str, error: str) -> None:
    """Best-effort: comment on the PR that the agent failed."""
    try:
        from github import Github

        token = os.environ.get("GITHUB_TOKEN", "")
        repo_name = os.environ.get("GITHUB_REPO", "")
        gh = Github(token)
        repo = gh.get_repo(repo_name)

        for pr in repo.get_pulls(state="open"):
            if pr.head.ref == branch_name:
                pr.create_issue_comment(
                    f"**AI Agent `{agent_id}` failed.**\n\n"
                    f"```\n{error[:2000]}\n```\n\n"
                    "This PR may need manual attention."
                )
                break
    except Exception:
        pass  # Best effort


if __name__ == "__main__":
    sys.exit(main())
