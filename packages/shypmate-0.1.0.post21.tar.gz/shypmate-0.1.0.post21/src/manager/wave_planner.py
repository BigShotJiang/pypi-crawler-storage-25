"""
Wave planner — analyzes pending tasks and groups them into dependency-ordered waves.

Tasks within the same wave can run in parallel. Tasks in wave N+1 depend on wave N
being complete and merged. One LLM call per analysis.
"""

import json
import logging
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

WAVE_STATE_FILENAME = "wave_state.json"


@dataclass
class WavePlan:
    """Execution plan: ordered list of waves, each wave is a list of task IDs."""
    waves: list[list[str]]
    rationale: dict[str, str]  # task_id -> why it's in that wave
    created_at: str = ""
    base_sha: str = ""

    def wave_for_task(self, task_id: str) -> int | None:
        """Return the wave index for a task, or None if not in the plan."""
        for i, wave in enumerate(self.waves):
            if task_id in wave:
                return i
        return None

    def remaining_waves(self, from_index: int) -> list[list[str]]:
        """Return waves from the given index onward."""
        return self.waves[from_index:]

    def all_task_ids(self) -> set[str]:
        """Return all task IDs in the plan."""
        return {tid for wave in self.waves for tid in wave}


@dataclass
class WaveState:
    """Persistent state for wave execution — survives manager restarts."""
    plan: WavePlan | None = None
    current_wave_index: int = 0
    completed_waves: list[int] = field(default_factory=list)
    running_agents: dict[str, str] = field(default_factory=dict)  # task_id -> container_name
    agent_branches: dict[str, str] = field(default_factory=dict)  # task_id -> branch_name
    agent_ids: dict[str, str] = field(default_factory=dict)  # task_id -> agent_id
    failed_tasks: list[str] = field(default_factory=list)
    version: int = 1

    @property
    def current_wave(self) -> list[str] | None:
        """Return the current wave's task IDs, or None if no plan or all done."""
        if not self.plan or self.current_wave_index >= len(self.plan.waves):
            return None
        return self.plan.waves[self.current_wave_index]

    @property
    def is_complete(self) -> bool:
        """True if all waves have been completed."""
        if not self.plan:
            return True
        return self.current_wave_index >= len(self.plan.waves)


def plan_waves(
    tasks: list[dict[str, Any]],
    brief,
    provider,
    execution_mode: str = "auto",
) -> WavePlan:
    """Analyze tasks and produce a wave execution plan.

    Args:
        tasks: list of task dicts (id, description, priority)
        brief: ProjectBrief with repo context (or None for no context)
        provider: LLM provider instance
        execution_mode: "auto", "parallel", or "sequential"

    Returns:
        WavePlan with ordered waves
    """
    if not tasks:
        return WavePlan(waves=[], rationale={}, created_at=_now())

    # Sort by priority for deterministic ordering
    priority_order = {"critical": 0, "high": 1, "normal": 2, "low": 3}
    sorted_tasks = sorted(
        tasks,
        key=lambda t: (priority_order.get(t.get("priority", "normal"), 2), t.get("created_at", "")),
    )

    # Short-circuit for non-auto modes
    if execution_mode == "parallel":
        return WavePlan(
            waves=[[t["id"] for t in sorted_tasks]],
            rationale={t["id"]: "parallel mode — all tasks in one wave" for t in sorted_tasks},
            created_at=_now(),
        )

    if execution_mode == "sequential":
        return WavePlan(
            waves=[[t["id"]] for t in sorted_tasks],
            rationale={t["id"]: "sequential mode — one task per wave" for t in sorted_tasks},
            created_at=_now(),
        )

    # Single task — no analysis needed
    if len(sorted_tasks) == 1:
        t = sorted_tasks[0]
        return WavePlan(
            waves=[[t["id"]]],
            rationale={t["id"]: "single task"},
            created_at=_now(),
        )

    # Auto mode: use LLM to analyze dependencies
    return _llm_plan_waves(sorted_tasks, brief, provider)


def _llm_plan_waves(
    tasks: list[dict[str, Any]],
    brief,
    provider,
) -> WavePlan:
    """Use an LLM call to analyze task dependencies and produce waves."""
    # Build context from brief
    context_parts = []
    if brief:
        if brief.understanding:
            context_parts.append(f"Project overview:\n{brief.understanding[:1500]}")
        if brief.architecture:
            context_parts.append(f"Architecture:\n{brief.architecture[:800]}")
        if brief.file_map:
            file_summary = json.dumps(brief.file_map, indent=None)[:1000]
            context_parts.append(f"Key files:\n{file_summary}")
    else:
        context_parts.append("This appears to be a new/empty project with little or no existing code.")

    context = "\n\n".join(context_parts)

    # Build task list
    task_lines = []
    for i, t in enumerate(tasks, 1):
        task_lines.append(
            f'{i}. ID: "{t["id"]}" | Priority: {t.get("priority", "normal")} '
            f'| Description: "{t.get("description", "")}"'
        )
    task_list = "\n".join(task_lines)

    prompt = f"""Analyze these tasks for a software project and group them into execution waves.

{context}

Pending tasks (in priority order):
{task_list}

Rules:
- Tasks within the same wave can run in parallel (no file conflicts, no dependency on each other's output)
- Tasks in wave N+1 depend on output from wave N being merged first
- Foundation/setup tasks (project scaffolding, config) MUST come before tasks that build on them
- Higher priority tasks should be in earlier waves when possible
- If tasks are truly independent (touch different parts of the codebase), put them in the same wave
- For a new/empty project, setup and scaffolding is always Wave 1

Respond with ONLY a JSON object, no markdown fences:
{{
  "waves": [["task-id-1"], ["task-id-2", "task-id-3"], ["task-id-4"]],
  "rationale": {{
    "task-id-1": "Why this task is in this wave",
    "task-id-2": "Why this task is in this wave"
  }}
}}"""

    try:
        response = provider.create_message(
            system="You are a senior technical project manager. Analyze task dependencies and produce a wave execution plan. Respond only with valid JSON.",
            messages=[{"role": "user", "content": prompt}],
            tools=[],
        )

        text = response.text.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        data = json.loads(text)
        waves = data.get("waves", [])
        rationale = data.get("rationale", {})

        # Validate: every task must appear in exactly one wave
        planned_ids = {tid for wave in waves for tid in wave}
        all_ids = {t["id"] for t in tasks}
        missing = all_ids - planned_ids
        if missing:
            # LLM missed some tasks — append them to the last wave
            logger.warning(f"Wave plan missing tasks: {missing}. Appending to last wave.")
            if waves:
                waves[-1].extend(missing)
            else:
                waves.append(list(missing))
            for tid in missing:
                rationale[tid] = "not assigned by planner — appended to last wave"

        return WavePlan(
            waves=waves,
            rationale=rationale,
            created_at=_now(),
        )

    except Exception as e:
        logger.error(f"Wave planning LLM call failed: {e}. Falling back to sequential.")
        # Fallback: sequential by priority
        return WavePlan(
            waves=[[t["id"]] for t in tasks],
            rationale={t["id"]: f"fallback sequential (LLM error: {e})" for t in tasks},
            created_at=_now(),
        )


def slot_new_task(
    existing_plan: WavePlan,
    new_task: dict[str, Any],
    current_wave_index: int,
    brief,
    provider,
) -> tuple[WavePlan, int]:
    """Determine where a new task fits in an existing wave plan.

    Returns (updated_plan, wave_index_for_new_task).
    Critical tasks return wave_index = -1 (launch immediately).
    """
    if new_task.get("priority") == "critical":
        # Critical tasks bypass wave ordering
        return existing_plan, -1

    # Gather context about what's in each remaining wave
    remaining_waves = existing_plan.remaining_waves(current_wave_index)
    wave_descriptions = []
    for i, wave in enumerate(remaining_waves):
        wave_idx = current_wave_index + i
        rationales = [existing_plan.rationale.get(tid, tid) for tid in wave]
        wave_descriptions.append(f"Wave {wave_idx}: {wave} — {'; '.join(rationales)}")

    prompt = f"""A new task has been added to a project that already has a wave execution plan in progress.

Current wave plan (wave {current_wave_index} is currently executing):
{chr(10).join(wave_descriptions)}

New task:
  ID: "{new_task['id']}"
  Priority: {new_task.get('priority', 'normal')}
  Description: "{new_task.get('description', '')}"

Which wave should this task be added to? Consider:
- Can it run in parallel with the current wave? (no dependencies on current wave's output)
- Does it depend on a future wave's output?
- If independent of everything, it can go in the current wave

Respond with ONLY a JSON object:
{{"wave_index": <integer>, "reason": "why"}}
"""

    try:
        response = provider.create_message(
            system="You are a technical project manager deciding task ordering. Respond only with valid JSON.",
            messages=[{"role": "user", "content": prompt}],
            tools=[],
        )

        text = response.text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        data = json.loads(text)
        target_wave = data.get("wave_index", len(existing_plan.waves))
        reason = data.get("reason", "")

        # Ensure target_wave is valid
        target_wave = max(current_wave_index, min(target_wave, len(existing_plan.waves)))

        # Insert task into the target wave
        updated_waves = [list(w) for w in existing_plan.waves]
        updated_rationale = dict(existing_plan.rationale)

        if target_wave < len(updated_waves):
            updated_waves[target_wave].append(new_task["id"])
        else:
            updated_waves.append([new_task["id"]])

        updated_rationale[new_task["id"]] = reason or f"slotted into wave {target_wave}"

        updated_plan = WavePlan(
            waves=updated_waves,
            rationale=updated_rationale,
            created_at=existing_plan.created_at,
            base_sha=existing_plan.base_sha,
        )
        return updated_plan, target_wave

    except Exception as e:
        logger.error(f"Slot new task LLM call failed: {e}. Appending to next wave.")
        # Fallback: append to wave after current
        updated_waves = [list(w) for w in existing_plan.waves]
        updated_rationale = dict(existing_plan.rationale)
        next_wave = current_wave_index + 1

        if next_wave < len(updated_waves):
            updated_waves[next_wave].append(new_task["id"])
        else:
            updated_waves.append([new_task["id"]])

        updated_rationale[new_task["id"]] = f"fallback — appended to wave {next_wave}"

        updated_plan = WavePlan(
            waves=updated_waves,
            rationale=updated_rationale,
            created_at=existing_plan.created_at,
            base_sha=existing_plan.base_sha,
        )
        return updated_plan, next_wave


# ── Persistence ──

def save_wave_state(state: WaveState, data_dir: Path) -> None:
    """Save wave state to disk for persistence across restarts."""
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / WAVE_STATE_FILENAME

    data = {
        "plan": asdict(state.plan) if state.plan else None,
        "current_wave_index": state.current_wave_index,
        "completed_waves": state.completed_waves,
        "running_agents": state.running_agents,
        "agent_branches": state.agent_branches,
        "agent_ids": state.agent_ids,
        "failed_tasks": state.failed_tasks,
        "version": state.version,
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    logger.debug(f"Wave state saved: {path}")


def load_wave_state(data_dir: Path) -> WaveState | None:
    """Load wave state from disk. Returns None if no state file exists."""
    path = data_dir / WAVE_STATE_FILENAME
    if not path.exists():
        return None

    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        plan = None
        if data.get("plan"):
            plan = WavePlan(**data["plan"])

        return WaveState(
            plan=plan,
            current_wave_index=data.get("current_wave_index", 0),
            completed_waves=data.get("completed_waves", []),
            running_agents=data.get("running_agents", {}),
            agent_branches=data.get("agent_branches", {}),
            agent_ids=data.get("agent_ids", {}),
            failed_tasks=data.get("failed_tasks", []),
            version=data.get("version", 1),
        )
    except Exception as e:
        logger.warning(f"Failed to load wave state: {e}")
        return None


def clear_wave_state(data_dir: Path) -> None:
    """Remove the wave state file."""
    path = data_dir / WAVE_STATE_FILENAME
    if path.exists():
        path.unlink()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
