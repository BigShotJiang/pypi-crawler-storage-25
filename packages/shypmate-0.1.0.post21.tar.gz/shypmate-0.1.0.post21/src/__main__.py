"""Allow running as: python -m shypmate"""

from shypmate.main import cli

if __name__ == "__main__":
    cli()
