"""
Task pipeline — coordinates multiple hats working on a single task.

The pipeline runs hats in order (developer → QA → PO), passing the branch
between them. Each hat runs in its own container. Failed stages loop back
to the developer with feedback.
"""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from shypmate.hats.hat import Hat, get_default_hats

logger = logging.getLogger(__name__)


@dataclass
class PipelineStage:
    """Tracks the state of one hat's execution in the pipeline."""
    hat_name: str
    status: str = "pending"  # pending, running, passed, failed, skipped
    started_at: str = ""
    finished_at: str = ""
    output: str = ""
    iterations: int = 0
    tokens: int = 0
    cost: float = 0.0
    attempt: int = 1


@dataclass
class Pipeline:
    """A task pipeline — the ordered sequence of hats for a task."""
    task_id: str
    task_description: str
    branch: str
    stages: list[PipelineStage] = field(default_factory=list)
    status: str = "pending"  # pending, running, passed, failed
    max_retries: int = 2  # max times developer is re-spawned after QA/PO failure
    created_at: str = ""

    def current_stage(self) -> PipelineStage | None:
        """Get the currently running or next pending stage."""
        for stage in self.stages:
            if stage.status in ("running", "pending"):
                return stage
        return None

    def is_complete(self) -> bool:
        return all(s.status in ("passed", "skipped") for s in self.stages)

    def has_failed(self) -> bool:
        return self.status == "failed"

    def summary(self) -> str:
        """Human-readable pipeline summary."""
        lines = [f"Pipeline: {self.task_description[:60]}"]
        lines.append(f"  Branch: {self.branch}")
        lines.append(f"  Status: {self.status}")
        for stage in self.stages:
            icon = {
                "pending": "░░░░",
                "running": "████",
                "passed": "✓",
                "failed": "✗",
                "skipped": "—",
            }.get(stage.status, "?")
            cost_str = f" ${stage.cost:.4f}" if stage.cost else ""
            lines.append(f"  [{stage.hat_name}] {icon} {stage.status.upper()}"
                         f" (attempt {stage.attempt}){cost_str}")
            if stage.output and stage.status == "failed":
                # Show first 200 chars of failure output
                lines.append(f"    → {stage.output[:200]}")
        return "\n".join(lines)


def build_pipeline(
    task_id: str,
    task_description: str,
    branch: str,
    hats: dict[str, Hat] | None = None,
    hat_order: list[str] | None = None,
    max_retries: int = 2,
) -> Pipeline:
    """Build a pipeline from configured hats.

    Args:
        task_id: Task identifier.
        task_description: The task description.
        branch: Git branch for this task.
        hats: Hat configs (defaults to built-in hats if None).
        hat_order: Explicit ordering of hat names. If None, uses the order
                   from the --hats flag or default (developer, qa).
        max_retries: Max developer re-runs after QA/PO failure.
    """
    if hats is None:
        hats = get_default_hats()

    # Use explicit order if provided, otherwise use hats dict order
    if hat_order:
        ordered_names = hat_order
    else:
        ordered_names = list(hats.keys())

    # Filter enabled hats and check triggers
    active_hats = []
    for name in ordered_names:
        hat = hats.get(name)
        if not hat:
            continue
        if not hat.enabled:
            continue
        if hat.trigger and not hat.trigger(task_description):
            continue
        active_hats.append(hat)

    if not active_hats:
        active_hats = [get_default_hats()["developer"]]

    stages = [PipelineStage(hat_name=hat.name) for hat in active_hats]

    return Pipeline(
        task_id=task_id,
        task_description=task_description,
        branch=branch,
        stages=stages,
        max_retries=max_retries,
        created_at=datetime.now(timezone.utc).isoformat(),
    )


def save_pipeline(pipeline: Pipeline, comms_dir: Path) -> None:
    """Save pipeline state to the comms directory."""
    pipelines_dir = comms_dir / "pipelines"
    pipelines_dir.mkdir(parents=True, exist_ok=True)
    path = pipelines_dir / f"{pipeline.task_id}.json"

    data = {
        "task_id": pipeline.task_id,
        "task_description": pipeline.task_description,
        "branch": pipeline.branch,
        "status": pipeline.status,
        "max_retries": pipeline.max_retries,
        "created_at": pipeline.created_at,
        "stages": [
            {
                "hat_name": s.hat_name,
                "status": s.status,
                "started_at": s.started_at,
                "finished_at": s.finished_at,
                "output": s.output[:1000],  # cap stored output
                "iterations": s.iterations,
                "tokens": s.tokens,
                "cost": s.cost,
                "attempt": s.attempt,
            }
            for s in pipeline.stages
        ],
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_pipeline(task_id: str, comms_dir: Path) -> Pipeline | None:
    """Load pipeline state from the comms directory."""
    path = comms_dir / "pipelines" / f"{task_id}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        stages = [PipelineStage(**s) for s in data.get("stages", [])]
        return Pipeline(
            task_id=data["task_id"],
            task_description=data["task_description"],
            branch=data["branch"],
            stages=stages,
            status=data.get("status", "pending"),
            max_retries=data.get("max_retries", 2),
            created_at=data.get("created_at", ""),
        )
    except Exception as e:
        logger.error(f"Failed to load pipeline {task_id}: {e}")
        return None


def get_hat_task_prompt(
    hat: Hat,
    task_description: str,
    branch: str,
    previous_feedback: str = "",
    pipeline_context: str = "",
    sdlc: str = "",
) -> str:
    """Build the task prompt for a specific hat.

    Each hat gets:
    - The SDLC workflow description (so it knows the overall process)
    - Its role-specific instructions
    - Context from previous hats (filtered to what it needs)
    """
    from shypmate.hats.hat import DEFAULT_SDLC

    sdlc_text = sdlc or DEFAULT_SDLC
    sdlc_block = f"\nPROCESS (your role in the pipeline):\n{sdlc_text}"
    context_block = f"\n\n{pipeline_context}" if pipeline_context else ""

    if hat.name == "developer":
        prompt = f"TASK: {task_description}"
        prompt += f"\n{sdlc_block}"
        if previous_feedback:
            prompt += f"\n\nPREVIOUS FEEDBACK (you must address this):\n{previous_feedback}"
        prompt += f"\n\nBRANCH: You are on branch '{branch}'. Do NOT create branches."
        prompt += "\n\nPush when done. Do NOT open a PR — the pipeline handles that."
        prompt += context_block
        return prompt

    elif hat.name == "qa":
        return f"""TASK FOR QA:
Original task: {task_description}

{sdlc_block}

BRANCH: '{branch}' — contains the developer's changes.
{context_block}

Your job:
1. Follow the developer's test instructions (above)
2. Run run_ruff_check() on changed files
3. Look for obvious bugs or missing error handling

Respond with QA_PASS or QA_FAIL as the first word of your final message.
If failing, explain specifically what failed and how to fix it."""

    elif hat.name == "product_owner":
        return f"""TASK FOR PRODUCT REVIEW:
Original task: {task_description}

{sdlc_block}

BRANCH: '{branch}' — QA has already passed.
{context_block}

Your job:
1. Does the implementation match the task requirements?
2. Is the scope appropriate?

Respond with PO_APPROVE or PO_REJECT as the first word."""

    else:
        # Custom hat
        return f"""TASK: {task_description}

{sdlc_block}

BRANCH: '{branch}'
{context_block}

{hat.prompt}

Respond with PASS or FAIL as the first word of your final message."""
