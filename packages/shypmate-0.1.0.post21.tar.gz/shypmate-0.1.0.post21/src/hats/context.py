"""
Pipeline context — shared state passed between hats in a pipeline.

Each hat reads the context from previous hats and appends its own results.
Stored as a JSON file on the shared comms volume.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


def _context_path(comms_dir: Path, pipeline_id: str) -> Path:
    """Get the path to the pipeline context file."""
    ctx_dir = comms_dir / "pipeline_context"
    ctx_dir.mkdir(parents=True, exist_ok=True)
    return ctx_dir / f"{pipeline_id}.json"


def load_context(comms_dir: Path, pipeline_id: str) -> dict:
    """Load the pipeline context from previous hats."""
    path = _context_path(comms_dir, pipeline_id)
    if not path.exists():
        return {"stages": [], "task": "", "branch": ""}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"stages": [], "task": "", "branch": ""}


def save_stage_context(
    comms_dir: Path,
    pipeline_id: str,
    hat_name: str,
    data: dict,
) -> None:
    """Append a hat's results to the pipeline context."""
    ctx = load_context(comms_dir, pipeline_id)

    stage_entry = {
        "hat": hat_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **data,
    }
    ctx["stages"].append(stage_entry)

    path = _context_path(comms_dir, pipeline_id)
    path.write_text(json.dumps(ctx, indent=2), encoding="utf-8")
    logger.info(f"Pipeline context updated by [{hat_name}]")


def init_context(
    comms_dir: Path,
    pipeline_id: str,
    task: str,
    branch: str,
) -> None:
    """Initialize the pipeline context for a new task."""
    ctx = {
        "task": task,
        "branch": branch,
        "pipeline_id": pipeline_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "stages": [],
    }
    path = _context_path(comms_dir, pipeline_id)
    path.write_text(json.dumps(ctx, indent=2), encoding="utf-8")


def format_context_for_hat(comms_dir: Path, pipeline_id: str, target_hat: str) -> str:
    """Format the pipeline context filtered for a specific hat's needs.

    Each hat only sees what's relevant to its role:
    - QA sees: files changed, test instructions from developer
    - PO sees: task description, files changed, commit messages, QA result
    - Developer (retry) sees: feedback from QA/PO about what failed
    """
    ctx = load_context(comms_dir, pipeline_id)

    if not ctx.get("stages"):
        return ""

    lines = []

    for stage in ctx["stages"]:
        hat = stage.get("hat", "?")

        if target_hat == "qa":
            # QA sees: what changed + test instructions from developer
            if hat == "developer":
                lines.append("FROM DEVELOPER:")
                if stage.get("files_changed"):
                    lines.append(f"  Files changed: {', '.join(stage['files_changed'])}")
                if stage.get("test_instructions"):
                    lines.append(f"  Test instructions:\n    {stage['test_instructions']}")
                if stage.get("summary"):
                    lines.append(f"  Change summary: {stage['summary']}")

        elif target_hat == "product_owner":
            # PO sees: what was requested, what changed, QA result
            if hat == "developer":
                if stage.get("files_changed"):
                    lines.append(f"FILES CHANGED: {', '.join(stage['files_changed'])}")
                if stage.get("commits"):
                    lines.append("COMMITS:")
                    for c in stage["commits"]:
                        lines.append(f"  - {c}")
            elif hat == "qa":
                if stage.get("result"):
                    lines.append(f"QA RESULT: {stage['result']}")
                if stage.get("summary"):
                    lines.append(f"QA SUMMARY: {stage['summary']}")

        elif target_hat == "developer":
            # Developer (retry) sees: feedback about what failed
            if stage.get("feedback"):
                lines.append(f"FEEDBACK FROM {hat.upper()}:")
                lines.append(f"  {stage['feedback']}")

        else:
            # Custom hat — gets everything
            lines.append(f"[{hat.upper()}]:")
            if stage.get("summary"):
                lines.append(f"  Summary: {stage['summary']}")
            if stage.get("result"):
                lines.append(f"  Result: {stage['result']}")

    return "\n".join(lines) if lines else ""
