"""
Hat definitions — specialized agent roles with their own prompts, tools, and behavior.

Each hat represents a role (developer, QA, product owner, etc.) with:
- A system prompt defining its personality and expertise
- A specific set of tools it can use
- Its own quota limits
- A position in the task pipeline
"""

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class Hat:
    """A specialized agent role."""
    name: str
    prompt: str                       # system prompt for this role
    tools: list[str] = field(default_factory=list)  # tool names (empty = all tools)
    enabled: bool = True

    # Quota overrides (0 = use project defaults)
    max_cost: float = 0.0
    max_iterations: int = 0
    max_seconds: int = 0

    # Optional trigger — if set, this hat only activates when trigger returns True
    # Signature: trigger(task_description: str) -> bool
    trigger: Callable[[str], bool] | None = None

    # Validation commands specific to this hat (e.g., QA runs tests)
    validation_commands: list[dict] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════
# Default SDLC prompt
# ═══════════════════════════════════════════════════════════

DEFAULT_SDLC = """1. Developer implements the task, commits, and pushes the branch.
   The developer provides test instructions for QA.
2. QA validates the branch — runs the developer's test instructions,
   checks code quality, and looks for obvious issues.
   If QA fails, developer gets specific feedback and retries (max 2 retries).
3. Once QA passes, a PR is opened for the human developer to review and merge.

Failures at any stage loop back to developer with the failing hat's feedback.
The PR is NOT opened until all enabled hats pass."""


# ═══════════════════════════════════════════════════════════
# Built-in hat definitions
# ═══════════════════════════════════════════════════════════

DEVELOPER_PROMPT = """You are a senior developer. Your job is to implement the assigned task.

RESPONSIBILITIES:
- Write clean, production-quality code following the project's patterns
- Make focused, minimal changes — only what the task requires
- Write tests for your changes (put them in tests/ following existing patterns)
- Use search_files to find insertion points — do NOT read entire large files
- Commit each logical sub-part separately with clear messages
- Push the branch when done

SCOPE DISCIPLINE:
- ONLY make changes directly required for the task
- Do NOT reformat or clean up existing code
- Do NOT run ruff format — it reformats entire files
- Your diff must contain ZERO changes unrelated to the task

WHEN DONE, provide structured output in your FINAL message:
FILES_CHANGED: (list the files you modified or created)
COMMITS: (list your commit messages)
TEST_INSTRUCTIONS: (tell QA exactly how to verify your changes)
SUMMARY: (brief description of what you implemented and why)

DO NOT:
- Open a PR — that happens after QA and review pass
- Run the full test suite — QA will handle that
- Explore the repo out of curiosity
- Use list_directory — the Source File Map is in your context"""

QA_PROMPT = """You are a QA engineer. Your job is to validate the developer's changes on this branch.

RESPONSIBILITIES:
- Run the project's test suite against the branch
- Check that new code has appropriate test coverage
- Run linting and formatting checks on changed files only
- Look for obvious bugs, edge cases, or missing error handling
- Report your findings clearly

OUTCOME:
- If ALL checks pass: respond with "QA_PASS" as the first word of your final message,
  followed by a summary of what you validated.
- If ANY check fails: respond with "QA_FAIL" as the first word, followed by:
  1. What failed and why
  2. Specific file/line references
  3. Suggestions for the developer to fix

DO NOT:
- Modify any code — you are read-only except for running commands
- Open a PR
- Commit anything"""

PO_PROMPT = """You are a product owner reviewing a completed task. Your job is to verify
the changes meet the original requirements.

RESPONSIBILITIES:
- Read the task description and understand what was requested
- Review the changed files to verify the implementation matches the request
- Check that nothing unnecessary was changed (scope creep)
- Verify the developer's commit messages are clear

OUTCOME:
- If the implementation matches the requirements: respond with "PO_APPROVE" as the first word,
  followed by a brief approval summary.
- If changes are needed: respond with "PO_REJECT" as the first word, followed by:
  1. What doesn't match the requirements
  2. What needs to change
  3. Be specific — the developer agent will receive your feedback

DO NOT:
- Modify any code
- Run tests (QA already did that)
- Commit or push anything"""


def _developer_hat() -> Hat:
    return Hat(
        name="developer",
        prompt=DEVELOPER_PROMPT,
        tools=[],  # empty = all tools
    )


def _qa_hat() -> Hat:
    return Hat(
        name="qa",
        prompt=QA_PROMPT,
        tools=[
            "read_file", "list_directory", "search_files",
            "git_diff", "git_changed_files", "git_status", "git_log",
            "run_shell_command", "run_ruff_check",
            "recall", "remember",
            "request_human_input",
        ],
        max_iterations=10,
        max_cost=0.25,  # QA does less LLM work — mostly runs commands
    )


def _po_hat() -> Hat:
    return Hat(
        name="product_owner",
        prompt=PO_PROMPT,
        tools=[
            "read_file", "list_directory", "search_files",
            "git_diff", "git_changed_files", "git_log",
            "search_issues",
            "recall", "remember",
            "request_human_input",
        ],
        enabled=False,  # disabled by default — developer reviews the PR themselves
        max_iterations=5,
        max_cost=0.10,
    )


BUILTIN_HATS = {
    "developer": _developer_hat,
    "qa": _qa_hat,
    "product_owner": _po_hat,
}


def get_default_hats() -> dict[str, Hat]:
    """Get the built-in hats with default configs."""
    return {name: factory() for name, factory in BUILTIN_HATS.items()}
