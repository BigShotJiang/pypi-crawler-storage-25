"""
Dev crew — assembles and runs a single dev agent for one task.
"""

import logging
import os

from shypmate.agents.dev_agent import build_system_prompt, create_tool_registry
from shypmate.config.project import PROJECT
from shypmate.engine.agent_loop import run_agent, AgentQuota
from shypmate.engine.providers import create_provider
from shypmate.tasks.dev_task import build_task_prompt

logger = logging.getLogger(__name__)


def run_dev_crew(
    task_description: str,
    branch_name: str,
    project_context: str = "",
    is_rebase: bool = False,
) -> str:
    """
    Build and run a dev agent for a single task.

    Returns the agent's final output as a string.
    """
    # Resolve the API key from the configured env var name
    api_key = os.environ.get(PROJECT.llm_api_key_var, "") if PROJECT.llm_api_key_var else None

    provider = create_provider(
        provider=PROJECT.llm_provider,
        model=PROJECT.llm_model,
        max_tokens=PROJECT.llm_max_tokens,
        base_url=PROJECT.llm_base_url or None,
        api_key=api_key or None,
    )

    system_prompt = build_system_prompt(project_context=project_context)
    task_prompt = build_task_prompt(
        task_description=task_description,
        branch_name=branch_name,
        is_rebase=is_rebase,
    )
    registry = create_tool_registry()

    logger.info(f"Running agent with {len(registry.tool_names)} tools: {registry.tool_names}")

    # Build quota from project config
    quota = AgentQuota(
        soft_max_tokens=PROJECT.soft_max_tokens,
        soft_max_cost=PROJECT.soft_max_cost,
        soft_max_seconds=PROJECT.soft_max_seconds,
        soft_max_iterations=PROJECT.soft_max_iterations,
        hard_max_tokens=PROJECT.hard_max_tokens,
        hard_max_cost=PROJECT.hard_max_cost,
        hard_max_seconds=PROJECT.hard_max_seconds,
        hard_max_iterations=PROJECT.hard_max_iterations,
    )

    return run_agent(
        provider=provider,
        system_prompt=system_prompt,
        task_prompt=task_prompt,
        registry=registry,
        max_iterations=50,
        quota=quota,
    )
