"""
Human interaction tools — allows agents to request input from a human.

The agent calls request_human_input(question) when it's stuck or needs a decision.
The tool writes a request file and waits for a response file to appear.

Communication happens via a shared Docker volume (shypmate-comms).
"""

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

COMMS_DIR = Path("/comms")
REQUESTS_DIR = COMMS_DIR / "requests"
RESPONSES_DIR = COMMS_DIR / "responses"

# Special marker the host CLI watches for in --no-detach mode
HUMAN_INPUT_MARKER = "###SHYPMATE_HUMAN_INPUT###"


def request_human_input(question: str, context: str = "") -> str:
    """Ask a human for help when you are stuck or need a decision.

    Use this when:
    - You encounter an ambiguous requirement and need clarification
    - You're unsure which approach to take and want guidance
    - You hit an error you can't resolve on your own
    - The task description is unclear

    Args:
        question: The specific question you need answered. Be clear and concise.
        context: Optional context about what you've tried or what you're seeing.

    Returns:
        The human's response.
    """
    agent_id = os.environ.get("AGENT_ID", "unknown")
    request_id = f"{agent_id}-{int(time.time())}"

    request_data = {
        "id": request_id,
        "agent_id": agent_id,
        "question": question,
        "context": context,
        "task": os.environ.get("AGENT_TASK", ""),
        "branch": os.environ.get("AGENT_BRANCH", ""),
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }

    # Write request file
    REQUESTS_DIR.mkdir(parents=True, exist_ok=True)
    request_path = REQUESTS_DIR / f"{request_id}.json"
    with open(request_path, "w", encoding="utf-8") as f:
        json.dump(request_data, f, indent=2)

    # Print the special marker that the host CLI intercepts in --no-detach mode
    logger.warning(f"{HUMAN_INPUT_MARKER}")
    logger.warning(f"AGENT NEEDS HUMAN INPUT")
    logger.warning(f"  Agent:    {agent_id}")
    logger.warning(f"  Question: {question}")
    if context:
        logger.warning(f"  Context:  {context}")
    logger.warning(f"  Request:  {request_id}")
    logger.warning(f"Waiting for response...")

    # Poll for response
    response_path = RESPONSES_DIR / f"{request_id}.json"
    poll_interval = 5  # seconds
    while True:
        if response_path.exists():
            try:
                with open(response_path, encoding="utf-8") as f:
                    response_data = json.load(f)
                answer = response_data.get("response", "")
                logger.info(f"Human responded: {answer[:200]}")
                # Clean up
                request_path.unlink(missing_ok=True)
                response_path.unlink(missing_ok=True)
                return answer
            except Exception as e:
                logger.warning(f"Error reading response: {e}")

        time.sleep(poll_interval)
