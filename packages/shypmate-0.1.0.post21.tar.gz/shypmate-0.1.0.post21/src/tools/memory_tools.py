"""
Shared agent memory — persistent lessons, patterns, and context across agent runs.

Agents can save learnings and read past context. The memory is shared across
all agents via a host-mounted directory (.shypmate/memory/).

Memory is capped to prevent bloat. Old entries are evicted when limits are reached
unless pinned. The memory can be reset via 'shypmate memory reset'.
"""

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# Memory lives on the host via bind mount
MEMORY_DIR = Path("/comms/memory")
MEMORY_FILE = MEMORY_DIR / "agent_memory.json"


def _get_limits() -> tuple[int, int]:
    """Get memory limits from project config or env vars."""
    try:
        from shypmate.config.project import PROJECT
        max_entries = PROJECT.memory_max_entries
        max_size = PROJECT.memory_max_size
    except Exception:
        max_entries = int(os.environ.get("SHYPMATE_MEMORY_MAX_ENTRIES", "50"))
        max_size = int(os.environ.get("SHYPMATE_MEMORY_MAX_SIZE", str(8 * 1024)))
    return max_entries, max_size


def _load_memory() -> list[dict]:
    """Load the shared memory from disk."""
    if not MEMORY_FILE.exists():
        return []
    try:
        data = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_memory(entries: list[dict]) -> None:
    """Save the shared memory to disk, enforcing limits."""
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    max_entries, max_size = _get_limits()

    # Enforce entry count limit — keep pinned entries, evict oldest unpinned
    if len(entries) > max_entries:
        pinned = [e for e in entries if e.get("pinned")]
        unpinned = [e for e in entries if not e.get("pinned")]
        unpinned.sort(key=lambda e: e.get("created_at", ""))
        room = max_entries - len(pinned)
        entries = pinned + unpinned[-room:] if room > 0 else pinned[:max_entries]

    # Enforce size limit — evict oldest unpinned until under limit
    content = json.dumps(entries, indent=2)
    while len(content.encode("utf-8")) > max_size and entries:
        unpinned = [i for i, e in enumerate(entries) if not e.get("pinned")]
        if unpinned:
            entries.pop(unpinned[0])
        else:
            entries.pop(0)
        content = json.dumps(entries, indent=2)

    MEMORY_FILE.write_text(content, encoding="utf-8")


def remember(fact: str, category: str = "lesson", pinned: bool = False) -> str:
    """Save a lesson, pattern, or important fact to shared agent memory.

    Use this when you discover something that would help future agents working
    on this project — patterns, gotchas, decisions, or mistakes to avoid.

    Args:
        fact: The lesson or fact to remember. Be specific and actionable.
        category: Type of memory: "lesson" (from mistakes), "pattern" (code conventions),
                  "decision" (team choices), or "context" (background info).
        pinned: If True, this entry won't be auto-evicted when memory is full.
    """
    entries = _load_memory()

    # Check for duplicates — don't save the same fact twice
    for e in entries:
        if e.get("fact", "").lower() == fact.lower():
            return f"Already remembered: {fact[:80]}"

    entry = {
        "fact": fact,
        "category": category,
        "pinned": pinned,
        "agent_id": os.environ.get("AGENT_ID", "unknown"),
        "task": os.environ.get("AGENT_TASK", "")[:100],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    entries.append(entry)
    _save_memory(entries)

    logger.info(f"Remembered [{category}]: {fact[:100]}")
    return f"Saved to shared memory [{category}]: {fact[:80]}"


def recall(query: str = "", category: str = "") -> str:
    """Recall facts from shared agent memory.

    Call this at the start of a task to check what past agents have learned
    about this project. Returns relevant memories that can guide your work.

    Args:
        query: Optional keyword search. Returns all memories if empty.
        category: Optional filter by category (lesson, pattern, decision, context).
    """
    entries = _load_memory()

    if not entries:
        return "No shared memories found. This is the first agent run, or memory was reset."

    # Filter by category
    if category:
        entries = [e for e in entries if e.get("category") == category]

    # Filter by query keywords
    if query:
        query_lower = query.lower()
        keywords = query_lower.split()
        entries = [
            e for e in entries
            if any(kw in e.get("fact", "").lower() for kw in keywords)
        ]

    if not entries:
        return f"No memories matching query='{query}' category='{category}'."

    # Format for the agent
    lines = [f"Shared agent memory ({len(entries)} entries):"]
    for e in entries:
        pin = " [PINNED]" if e.get("pinned") else ""
        lines.append(f"  [{e.get('category', '?')}]{pin} {e.get('fact', '?')}")
        lines.append(f"    — agent {e.get('agent_id', '?')}, {e.get('created_at', '?')[:10]}")

    return "\n".join(lines)


def forget(fact_substring: str) -> str:
    """Remove a specific memory entry by matching its text.

    Use this to remove outdated or incorrect memories.

    Args:
        fact_substring: Part of the fact text to match and remove.
    """
    entries = _load_memory()
    original_count = len(entries)
    sub_lower = fact_substring.lower()

    entries = [e for e in entries if sub_lower not in e.get("fact", "").lower()]
    removed = original_count - len(entries)

    if removed:
        _save_memory(entries)
        return f"Removed {removed} memory entry(ies) matching '{fact_substring}'."
    return f"No memories found matching '{fact_substring}'."
