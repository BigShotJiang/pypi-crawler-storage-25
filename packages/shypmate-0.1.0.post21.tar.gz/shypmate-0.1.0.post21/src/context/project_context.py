"""
Builds runtime context from the repo for the dev agent.

Reads key project files (CLAUDE.md, decisions, etc.) and assembles a
structured context string the agent uses to understand the codebase.
"""

from pathlib import Path

from shypmate.config.project import PROJECT


# Sections in context files that agents DON'T need for implementation.
# These are stripped to reduce token usage.
_SKIP_SECTIONS = {
    "cli commands", "cli reference", "task management", "work execution",
    "agent lifecycle", "monitoring", "infrastructure", "direct agent control",
    "quick start", "install", "setup", "prerequisites", "run",
    "troubleshooting", "reusability guide", "extending the system",
    "development setup", "development notes", "testing changes",
    "pr monitor", "running the monitor", "environment variables",
    "security model", "secrets", "github token scopes", "container isolation",
    "monitor access", "table of contents", "adding a new tool",
    "adding a new agent type", "adding new validation commands",
    "pr metadata format", "conflict & self-healing",
    "step 1", "step 2", "step 3", "step 4",
    "files that are project-specific", "priority order",
}

# Max chars per context file
_MAX_CONTEXT_CHARS = 8000


def _strip_irrelevant_sections(content: str) -> str:
    """Remove sections from markdown that agents don't need for coding tasks."""
    lines = content.split("\n")
    result = []
    skipping = False

    for line in lines:
        # Check if this is a section header
        if line.strip().startswith("#"):
            header = line.strip().lstrip("#").strip().lower()
            # Check if this section should be skipped
            skipping = any(skip in header for skip in _SKIP_SECTIONS)

        if not skipping:
            result.append(line)

    return "\n".join(result)


def build_project_context(repo_root: str | Path) -> str:
    """Read context files from the cloned repo and return a combined context string.

    Strips irrelevant sections (CLI docs, troubleshooting, etc.) and
    truncates to keep token usage reasonable.
    """
    repo_root = Path(repo_root)
    sections: list[str] = []

    # Read each configured context file
    for rel_path in PROJECT.context_files:
        full_path = repo_root / rel_path
        if full_path.exists():
            content = full_path.read_text(encoding="utf-8", errors="replace")
            # Strip sections that aren't useful for implementation
            content = _strip_irrelevant_sections(content)
            # Truncate if still too large
            if len(content) > _MAX_CONTEXT_CHARS:
                content = content[:_MAX_CONTEXT_CHARS] + "\n\n[... truncated for brevity]"
            sections.append(f"## {rel_path}\n\n{content}")

    # Add tech stack summary
    tech = "\n".join(f"- {t}" for t in PROJECT.tech_stack)
    sections.append(f"## Tech Stack\n\n{tech}")

    # Add shared service safety rules
    rules = "\n".join(f"- {r}" for r in PROJECT.shared_service_rules)
    sections.append(f"## Shared Service Safety Rules\n\n{rules}")

    # Add source file map with line counts — helps agents find insertion points
    # without reading entire files
    import glob as _glob
    file_map_lines = ["## Source File Map (use search_files to find exact lines)\n"]
    py_files = sorted(_glob.glob(str(repo_root / "**" / "*.py"), recursive=True))
    for fpath in py_files:
        try:
            rel = str(Path(fpath).relative_to(repo_root)).replace("\\", "/")
        except ValueError:
            continue
        # Skip venvs, egg-info, __pycache__
        if any(skip in rel for skip in (".venv/", "__pycache__/", ".egg-info/", "node_modules/")):
            continue
        try:
            lines = Path(fpath).read_text(encoding="utf-8", errors="replace").count("\n") + 1
            file_map_lines.append(f"  {rel} ({lines} lines)")
        except Exception:
            pass
    if len(file_map_lines) > 1:
        sections.append("\n".join(file_map_lines[:50]))  # cap at 50 files

    return "\n\n---\n\n".join(sections)


def build_rebase_context(
    repo_root: str | Path,
    original_task: str,
    conflicts: list[str] | None = None,
) -> str:
    """Build context for a rebase/conflict-resolution run."""
    base = build_project_context(repo_root)
    extra = [
        "## Rebase Context",
        "",
        f"Original task: {original_task}",
        "",
        "You are re-running because master has advanced since your PR was opened.",
        "Your job is to:",
        "1. Rebase your branch onto the latest master.",
        "2. Resolve any merge conflicts safely.",
        "3. Re-run validation.",
        "4. Force-push the updated branch.",
        "5. Comment on the PR with what changed.",
    ]
    if conflicts:
        extra.append("")
        extra.append("Known conflicting files:")
        for f in conflicts:
            extra.append(f"- {f}")

    return base + "\n\n---\n\n" + "\n".join(extra)
