"""
Dev agent definition — system prompt and tool registration.
"""

from shypmate.config.project import PROJECT
from shypmate.engine.tool_registry import ToolRegistry
from shypmate.tools.file_tools import (
    list_directory,
    patch_file,
    read_file,
    search_files,
    write_file,
)
from shypmate.tools.git_tools import (
    checkout_branch,
    create_branch,
    git_changed_files,
    git_commit,
    git_diff,
    git_fetch,
    git_log,
    git_push,
    git_rebase,
    git_rebase_abort,
    git_rebase_continue,
    git_status,
)
from shypmate.tools.github_tools import (
    comment_on_pr,
    create_pull_request,
    get_pr_changed_files,
    list_ai_pull_requests,
    search_issues,
    update_pull_request,
)
from shypmate.tools.shell_tools import (
    run_ruff_check,
    run_ruff_format,
    run_shell_command,
)
from shypmate.tools.human_tools import (
    request_human_input,
)
from shypmate.tools.memory_tools import (
    recall,
    remember,
    forget,
)


def _build_safety_rules() -> str:
    rules = "\n".join(f"  - {r}" for r in PROJECT.shared_service_rules)
    return f"SHARED SERVICE RULES (MUST follow):\n{rules}"


def build_system_prompt(project_context: str = "") -> str:
    """Build the system prompt for the dev agent."""
    tech = ", ".join(PROJECT.tech_stack) if PROJECT.tech_stack else "this project"

    return f"""You are a senior developer working on {PROJECT.github_repo}.
Tech stack: {tech}.

You have tools for reading/writing files, git operations, GitHub PRs, and shell commands.

CRITICAL — WORK EFFICIENTLY (MOST IMPORTANT):
- You have a Source File Map below with every file and its line count. USE IT.
- NEVER use list_directory or read_file to "explore" or "understand" the project.
- To find an insertion point: use search_files with a specific pattern, then patch_file.
- To add code to the end of a file: search for `if __name__` or the last function, then patch.
- NEVER read an entire file. read_file is capped at 200 lines — use search_files instead.
- Target: complete simple tasks in 6-8 iterations. Every unnecessary read_file or list_directory
  wastes tokens and money.

WORKFLOW for adding code to an existing file:
1. search_files(pattern="if __name__", path="src") → find insertion point
2. patch_file(old_text="if __name__...", new_text="<your code>\n\nif __name__...") → done
That's 2 tool calls, not 10.

CRITICAL — TESTING:
- Write tests for your changes unless the task explicitly says not to.
- Put tests in tests/ following existing patterns.
- Keep tests simple and focused.

CRITICAL — SCOPE DISCIPLINE (MOST IMPORTANT RULE):
- ONLY make changes that are directly required to complete the task.
- Do NOT reformat, restyle, or "clean up" existing code. NEVER.
- Do NOT fix unrelated linting issues, add missing docstrings, or reorganize imports.
- Do NOT change whitespace, line breaks, or formatting in code you did not write for this task.
- Run run_ruff_check() with NO path argument — it only checks your changed files.
- Run run_ruff_format() with check_only=True — this CHECKS formatting without modifying files.
  NEVER let ruff format actually rewrite files. It reformats entire files and pollutes the diff.
- If ruff reports issues in existing code, IGNORE them. They are not your problem.
- Your diff should contain ZERO changes unrelated to the task.

{_build_safety_rules()}

PROJECT CONTEXT (pre-analyzed — trust this, do not re-discover):
{project_context}
"""


def create_tool_registry() -> ToolRegistry:
    """Create a tool registry with all dev agent tools registered."""
    registry = ToolRegistry()
    registry.register_all(
        # File tools
        read_file,
        write_file,
        list_directory,
        search_files,
        patch_file,
        # Git tools
        create_branch,
        checkout_branch,
        git_fetch,
        git_rebase,
        git_rebase_continue,
        git_rebase_abort,
        git_commit,
        git_push,
        git_diff,
        git_changed_files,
        git_status,
        git_log,
        # GitHub tools
        create_pull_request,
        update_pull_request,
        comment_on_pr,
        list_ai_pull_requests,
        get_pr_changed_files,
        search_issues,
        # Shell tools
        run_shell_command,
        run_ruff_check,
        run_ruff_format,
        # Human interaction
        request_human_input,
        # Shared memory
        recall,
        remember,
        forget,
    )
    return registry
