"""
Task prompt builder for dev agent runs.
"""

import json
import os
from datetime import datetime, timezone

from shypmate.config.project import PROJECT


def _build_metadata_json(task_description: str, branch_name: str) -> str:
    """Build the JSON metadata string the agent should embed in the PR body."""
    meta = {
        "task": task_description,
        "agent_id": os.environ.get("AGENT_ID", "unknown"),
        "branch": branch_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "rebase_count": int(os.environ.get("AGENT_REBASE_COUNT", "0")),
    }
    return json.dumps(meta)


def build_task_prompt(
    task_description: str,
    branch_name: str,
    is_rebase: bool = False,
) -> str:
    """Build the task prompt for the dev agent.

    Args:
        task_description: Human description of what to build/fix.
        branch_name: The git branch this work should be on.
        is_rebase: Whether this is a rebase/conflict-resolution run.

    Returns:
        The full task prompt string.
    """

    if is_rebase:
        return f"""You are re-running on branch '{branch_name}' because master has advanced.

Your job:
1. Fetch the latest from origin.
2. Rebase your branch onto origin/{PROJECT.base_branch}.
3. Resolve any merge conflicts. For simple conflicts (different parts of file, import ordering,
   migration numbering), resolve them automatically. For semantic conflicts in the same
   function/method, or contradictory changes, mark the PR as needing human review.
4. Re-run validation: ruff check --fix and ruff format.
5. Force-push the updated branch.
6. Comment on the PR explaining what changed during the rebase.

Original task for context:
{task_description}
"""

    validation_steps = "\n".join(
        f"   - `{cmd}` ({desc})" for cmd, desc in PROJECT.validation_commands
    )
    return f"""TASK: {task_description}

BRANCH: You are already on branch '{branch_name}'. Do NOT create or checkout a branch — it's done.
BASE: origin/{PROJECT.base_branch}

DO THIS:
1. recall() + search_issues() in ONE batch call to check for context.
2. Implement the change using search_files + patch_file (NOT read_file on large files).
3. Write tests if appropriate.
4. run_ruff_check() on your new files only.
5. git_commit with a clear message.
6. git_push(branch_name="{branch_name}")
7. create_pull_request with title prefixed '{PROJECT.pr_title_prefix}',
   metadata: {_build_metadata_json(task_description, branch_name)}
8. comment_on_pr with key decisions.
9. remember() any useful lessons for future agents.

RULES:
- Do NOT read entire files to "understand" them. Use search_files to find what you need.
- Do NOT use list_directory. The Source File Map is in your context.
- Do NOT run run_ruff_format(). It reformats entire files.
- Your diff must ONLY contain changes for this task.
- One commit per logical change. Single focused change = one commit is fine.
"""
