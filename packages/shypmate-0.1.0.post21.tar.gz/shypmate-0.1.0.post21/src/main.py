"""
Host-side CLI for shypmate.

Run this on your machine (not inside a container). It launches agent containers,
builds images, manages tasks, and monitors agents.

Usage:
    python -m shypmate task add "Add pagination to /api/products/" --priority high
    python -m shypmate task list
    python -m shypmate work
    python -m shypmate work --all
    python -m shypmate dashboard
    python -m shypmate run-agent --task "..." [--id my-agent]
    python -m shypmate build
    python -m shypmate monitor-start
"""

import hashlib
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import click
import docker

from shypmate.config.project import PROJECT


def _generate_slug(task: str, max_len: int = 40) -> str:
    """Generate a URL-safe slug from a task description."""
    slug = re.sub(r"[^a-z0-9]+", "-", task.lower()).strip("-")
    if len(slug) > max_len:
        slug = slug[:max_len].rsplit("-", 1)[0]
    return slug


def _generate_agent_id(task: str) -> str:
    import uuid
    short_uuid = uuid.uuid4().hex[:6]
    return f"dev-{short_uuid}"


def _generate_branch_name(task: str, agent_id: str) -> str:
    """Generate a unique branch name."""
    slug = _generate_slug(task)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"{PROJECT.branch_prefix}/{agent_id}-{slug}-{ts}"


def _get_docker_client() -> docker.DockerClient:
    return docker.from_env()


def _read_env_file_var(name: str) -> str:
    """Read a variable from the .env file at the project root."""
    from pathlib import Path
    env_path = Path(PROJECT.project_root) / ".env"
    if env_path.exists():
        try:
            for line in env_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith(f"{name}=") and not line.startswith("#"):
                    return line.split("=", 1)[1].strip().strip("'\"")
        except Exception:
            pass
    return ""


def _require_git():
    """Ensure the project is a git repo. Exit with guidance if not."""
    from pathlib import Path
    git_dir = Path(PROJECT.project_root) / ".git"
    if not git_dir.exists():
        click.echo(click.style("Error: No git repository found.", fg="red", bold=True), err=True)
        click.echo("", err=True)
        click.echo("Shypmate requires git with a supported forge (GitHub, GitLab, Bitbucket).", err=True)
        click.echo("Initialize a git repo first:", err=True)
        click.echo("", err=True)
        click.echo("  git init", err=True)
        click.echo("  git remote add origin <your-repo-url>", err=True)
        click.echo("  git add . && git commit -m \"Initial commit\"", err=True)
        click.echo("  git push -u origin main", err=True)
        click.echo("", err=True)
        click.echo("Supported forges: GitHub, GitLab, Bitbucket, Azure DevOps, Gitea", err=True)
        sys.exit(1)


def _validate_env() -> tuple[str, str]:
    """Validate required env vars, return (github_token, llm_api_key)."""
    _require_git()
    github_token = os.environ.get("GITHUB_TOKEN", "") or _read_env_file_var("GITHUB_TOKEN")

    api_key_var = PROJECT.llm_api_key_var or "ANTHROPIC_API_KEY"
    llm_api_key = os.environ.get(api_key_var, "") or _read_env_file_var(api_key_var)

    if not github_token:
        click.echo("Error: GITHUB_TOKEN not set. Add it to .env or set as environment variable.", err=True)
        sys.exit(1)
    if not llm_api_key and api_key_var:
        click.echo(f"Error: {api_key_var} not set. Add it to .env or set as environment variable.", err=True)
        sys.exit(1)
    if not PROJECT.github_repo:
        click.echo("Error: GITHUB_REPO not configured. Set in shypmate.yml or SHYPMATE_GITHUB_REPO.", err=True)
        sys.exit(1)

    # Require at least one hard quota to be set
    has_hard = (PROJECT.hard_max_tokens or PROJECT.hard_max_cost or
                PROJECT.hard_max_seconds or PROJECT.hard_max_iterations)
    if not has_hard:
        click.echo("Error: No hard quota configured. At least one hard limit is required to prevent runaway costs.", err=True)
        click.echo("  Set in shypmate.yml under quota.hard (max_tokens, max_cost, max_seconds, or max_iterations).", err=True)
        click.echo("  Example:", err=True)
        click.echo("    quota:", err=True)
        click.echo("      hard:", err=True)
        click.echo("        max_cost: 2.00    # USD", err=True)
        click.echo("        max_iterations: 30", err=True)
        sys.exit(1)

    return github_token, llm_api_key


def _handle_human_input_request(container_name: str) -> None:
    """Handle a human input request from an agent running in --no-detach mode.

    Reads the request directly from the host-side comms directory, prompts the user,
    and writes the response. No temp containers needed.
    """
    from pathlib import Path

    comms = _get_comms_dir()
    requests_dir = comms / "requests"
    responses_dir = comms / "responses"

    if not requests_dir.exists():
        return

    # Find request files
    request_files = sorted(requests_dir.glob("*.json"))
    if not request_files:
        return

    # Read the most recent request
    try:
        request_data = json.loads(request_files[-1].read_text(encoding="utf-8"))
    except Exception:
        return

    request_id = request_data.get("id", "")
    question = request_data.get("question", "")
    context = request_data.get("context", "")
    agent_id = request_data.get("agent_id", "")

    # Prompt the user
    click.echo("")
    click.echo(click.style("=" * 60, fg="yellow"))
    click.echo(click.style("  AGENT NEEDS YOUR INPUT", fg="yellow", bold=True))
    click.echo(click.style("=" * 60, fg="yellow"))
    click.echo(f"  Agent:    {agent_id}")
    click.echo(f"  Question: {question}")
    if context:
        click.echo(f"  Context:  {context}")
    click.echo(click.style("=" * 60, fg="yellow"))
    click.echo("")

    response_text = click.prompt("  Your response")

    # Write response directly to disk
    responses_dir.mkdir(parents=True, exist_ok=True)
    response_data = {"response": response_text, "responded_at": datetime.now(timezone.utc).isoformat()}
    (responses_dir / f"{request_id}.json").write_text(
        json.dumps(response_data, indent=2), encoding="utf-8"
    )
    click.echo(click.style("  Response sent. Agent will continue.", fg="green"))
    click.echo("")


MANAGER_CONTAINER = "shypmate-manager"
BRIEF_VOLUME = "shypmate-brief"

# Comms directory — a host-side directory for agent<->human communication.
# Lives at <project_root>/.shypmate/comms/ so the host CLI can read/write directly
# without spawning containers.
def _get_comms_dir():
    """Get the comms directory path, creating it if needed."""
    from pathlib import Path
    comms = Path(PROJECT.project_root) / ".shypmate" / "comms"
    comms.mkdir(parents=True, exist_ok=True)
    return comms

# Marker the agent prints when it needs human input
HUMAN_INPUT_MARKER = "###SHYPMATE_HUMAN_INPUT###"


def _is_manager_running() -> bool:
    """Check if the manager container is running."""
    try:
        client = _get_docker_client()
        c = client.containers.get(MANAGER_CONTAINER)
        return c.status == "running"
    except Exception:
        return False


def _launch_agent_container(
    task: str,
    agent_id: str,
    branch: str,
    github_token: str,
    llm_entry=None,
    base_branch: str | None = None,
    rebase: bool = False,
    detach: bool = True,
    task_id: str = "",
    dev_mode: bool | None = None,
    pipeline_hats: str = "",
    sdlc_prompt: str = "",
) -> str | None:
    """Launch an agent container. Returns container short_id if detached, None if foreground.

    llm_entry: an LLMPoolEntry specifying which provider/model/key this agent should use.
               If None, falls back to the single LLM config from PROJECT.
    dev_mode: mount local src/ into the container so local code changes take effect
              without rebuilding the image. Useful when developing shypmate itself.
    task_id: task queue ID, used to load the pre-built task plan from the manager.
    """
    from shypmate.config.project import get_pool_entry

    if llm_entry is None:
        llm_entry = get_pool_entry(PROJECT, 0)

    base = base_branch or PROJECT.base_branch
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"
    container_name = f"shypmate-{agent_id}"

    # Resolve the API key for this pool entry
    llm_api_key = ""
    if llm_entry.api_key_var:
        llm_api_key = os.environ.get(llm_entry.api_key_var, "") or _read_env_file_var(llm_entry.api_key_var)

    env = {
        "GITHUB_TOKEN": github_token,
        "GITHUB_REPO": PROJECT.github_repo,
        "AGENT_TASK": task,
        "AGENT_BRANCH": branch,
        "AGENT_ID": agent_id,
        "AGENT_REBASE": str(rebase).lower(),
        "BASE_BRANCH": base,
        "INSTALL_COMMAND": PROJECT.install_command,
        "LLM_PROVIDER": llm_entry.provider,
        "LLM_MODEL": llm_entry.model,
        "LLM_MAX_TOKENS": str(llm_entry.max_tokens),
    }
    # Pass memory limits
    env["SHYPMATE_MEMORY_MAX_ENTRIES"] = str(PROJECT.memory_max_entries)
    env["SHYPMATE_MEMORY_MAX_SIZE"] = str(PROJECT.memory_max_size)

    # Pipeline mode
    if pipeline_hats:
        env["PIPELINE_HATS"] = pipeline_hats
    if sdlc_prompt:
        env["SDLC_PROMPT"] = sdlc_prompt

    # Pass the API key under the configured env var name so the provider can find it
    if llm_entry.api_key_var and llm_api_key:
        env[llm_entry.api_key_var] = llm_api_key
    if llm_entry.base_url:
        env["LLM_BASE_URL"] = llm_entry.base_url
    if task_id:
        env["AGENT_TASK_ID"] = task_id

    client = _get_docker_client()

    # Remove old container with same name if exists
    try:
        old = client.containers.get(container_name)
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    # Auto-build if image not found
    try:
        client.images.get(image)
    except docker.errors.ImageNotFound:
        import subprocess
        click.echo(f"\nImage '{image}' not found. Building...")
        shypmate_dir = os.path.dirname(os.path.abspath(__file__))
        build_result = subprocess.run(["docker", "build", "-t", image, shypmate_dir])
        if build_result.returncode != 0:
            click.echo("Build failed.", err=True)
            return None
        click.echo(f"Image built: {image}\n")

    # Mount comms directory for human input (host bind mount — no temp containers needed)
    # Use forward slashes for Docker Desktop on Windows
    comms_dir = str(_get_comms_dir()).replace("\\", "/")
    volumes = {
        comms_dir: {"bind": "/comms", "mode": "rw"},
    }
    if _is_manager_running():
        volumes[BRIEF_VOLUME] = {"bind": "/brief", "mode": "ro"}

    # Dev mode: mount local src/ to override the baked-in framework code.
    # Auto-detect: if running from an editable install (pip install -e .),
    # the source dir is the project itself — enable dev mode automatically.
    if dev_mode is None:
        src_dir = os.path.dirname(os.path.abspath(__file__))
        # Auto-detect: editable install of shypmate itself (not a consuming project).
        # Check that pyproject.toml exists AND it's the shypmate project.
        pyproject = os.path.join(src_dir, "..", "pyproject.toml")
        if os.path.isfile(pyproject):
            try:
                with open(pyproject) as f:
                    dev_mode = 'name = "shypmate"' in f.read()
            except Exception:
                dev_mode = False
        else:
            dev_mode = False

    if dev_mode:
        src_dir = os.path.dirname(os.path.abspath(__file__)).replace("\\", "/")
        volumes[src_dir] = {"bind": "/opt/shypmate", "mode": "ro"}
        env["SHYPMATE_DEV_MODE"] = "1"

    try:
        if detach:
            container = client.containers.run(
                image=image,
                name=container_name,
                environment=env,
                network=PROJECT.docker_network,
                volumes=volumes or None,
                detach=True,
            )
            return container.short_id
        else:
            # Foreground mode: launch detached, then stream logs live
            container = client.containers.run(
                image=image,
                name=container_name,
                environment=env,
                network=PROJECT.docker_network,
                volumes=volumes or None,
                detach=True,
            )
            import signal
            import threading

            _interrupted = threading.Event()

            def _handle_interrupt(*_):
                _interrupted.set()

            # Install signal handler so Ctrl+C sets the flag
            prev_handler = signal.signal(signal.SIGINT, _handle_interrupt)

            try:
                log_stream = container.logs(stream=True, follow=True)
                for chunk in log_stream:
                    if _interrupted.is_set():
                        break
                    line = chunk.decode("utf-8", errors="replace").rstrip("\n")
                    safe_line = line.encode("ascii", errors="replace").decode("ascii")

                    # Check for human input request marker
                    if HUMAN_INPUT_MARKER in line:
                        _handle_human_input_request(container_name)
                        continue

                    click.echo(safe_line)

                if _interrupted.is_set():
                    click.echo("\nInterrupted. Stopping agent...")
                    container.stop(timeout=5)
                    try:
                        container.remove()
                    except Exception:
                        pass
                else:
                    # Container finished naturally
                    result = container.wait(timeout=10)
                    exit_code = result.get("StatusCode", -1)
                    if exit_code != 0:
                        click.echo(f"\nAgent exited with code {exit_code}")
                    try:
                        container.remove()
                    except Exception:
                        pass
            finally:
                signal.signal(signal.SIGINT, prev_handler)

            return None

    except docker.errors.ImageNotFound:
        click.echo(f"\nImage '{image}' not found.", err=True)
        return None
    except docker.errors.APIError as e:
        click.echo(f"\nDocker error: {e}", err=True)
        return None


# ═══════════════════════════════════════════════════════════
# CLI Groups
# ═══════════════════════════════════════════════════════════

@click.group()
def cli():
    """shypmate — autonomous dev agent launcher."""
    pass


# ── AI Analysis for Init ──────────────────────────────────

def _ai_analyze_project(
    project_root,
    api_key: str,
    tech_stack: list[str],
    docker_network: str,
    provider: str = "anthropic",
) -> dict | None:
    """Use an LLM to analyze the project and suggest config values."""
    from pathlib import Path
    from shypmate.config.project import LLM_PROVIDER_PRESETS

    # Gather project files for analysis
    files_content = []

    # Read key project files (limited size to control token usage)
    candidates = [
        ("README.md", 3000),
        ("docs/README.md", 3000),
        ("CLAUDE.md", 3000),
        ("docker-compose.yml", 2000),
        ("docker-compose.yaml", 2000),
        ("Makefile", 2000),
        ("pyproject.toml", 1500),
        ("package.json", 1500),
        ("Dockerfile", 1000),
        (".github/workflows/ci.yml", 1000),
        (".github/workflows/ci.yaml", 1000),
    ]

    root = Path(project_root)
    for filename, max_chars in candidates:
        filepath = root / filename
        if filepath.exists():
            try:
                content = filepath.read_text(encoding="utf-8")[:max_chars]
                files_content.append(f"=== {filename} ===\n{content}")
            except Exception:
                pass

    if not files_content:
        return None

    project_context = "\n\n".join(files_content)

    prompt = f"""Analyze this project and suggest configuration for an autonomous AI dev agent system.

The project uses these technologies: {', '.join(tech_stack) if tech_stack else 'unknown'}
Docker network: {docker_network or 'not set'}

Project files:
{project_context}

Respond with ONLY a JSON object (no markdown, no explanation) with these keys:

1. "validation_commands" — list of {{"command": "...", "description": "..."}} objects.
   These are commands the AI agent should run to validate its code changes.
   Examples: linting, formatting, type checking, tests.
   Only suggest commands that are clearly supported by the project files you see.

2. "shared_service_rules" — list of strings.
   Safety rules for AI agents interacting with shared services (databases, caches, queues).
   Based on what services you see in docker-compose or project config.
   Examples: "Do not run migrations against the shared PostgreSQL database",
   "Do not flush the Redis cache", "Use isolated test database names".
   Leave empty if no shared services are detected.

Be conservative — only suggest what the project clearly supports."""

    try:
        preset = LLM_PROVIDER_PRESETS.get(provider, {})
        model = preset.get("model", "claude-sonnet-4-6")

        if provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=api_key)
            response = client.messages.create(
                model=model,
                max_tokens=1500,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.content[0].text.strip()
        else:
            # Use OpenAI-compatible API for all other providers
            import openai
            kwargs = {"api_key": api_key}
            base_url = preset.get("base_url", "")
            if base_url:
                kwargs["base_url"] = base_url
            client = openai.OpenAI(**kwargs)
            response = client.chat.completions.create(
                model=model,
                max_tokens=1500,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that responds only with valid JSON."},
                    {"role": "user", "content": prompt},
                ],
            )
            text = response.choices[0].message.content.strip()

        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        return json.loads(text)
    except Exception as e:
        click.echo(f"  AI analysis error: {e}")
        return None


# ── Init ───────────────────────────────────────────────────

@cli.command()
@click.option("--non-interactive", is_flag=True, help="Accept all auto-detected defaults without prompting.")
def init(non_interactive: bool):
    """Initialize shypmate.yml for the current project.

    Auto-detects project settings and prompts for confirmation.
    Re-run to update an existing shypmate.yml.
    """
    from pathlib import Path

    from shypmate.config.project import (
        _find_project_root,
        _load_yaml_config,
        detect_all,
    )

    root = _find_project_root()
    yml_path = root / "shypmate.yml"

    # ── Git requirement check ──
    if not (root / ".git").exists():
        click.echo("")
        click.echo(click.style("  ERROR: No git repository found.", fg="red", bold=True))
        click.echo("")
        click.echo("  Shypmate requires git with a supported forge (GitHub, GitLab, Bitbucket).")
        click.echo("  Initialize a git repo first:")
        click.echo("")
        click.echo(click.style("    git init", fg="bright_white"))
        click.echo(click.style("    git remote add origin <your-repo-url>", fg="bright_white"))
        click.echo(click.style("    git add . && git commit -m \"Initial commit\"", fg="bright_white"))
        click.echo(click.style("    git push -u origin main", fg="bright_white"))
        click.echo("")
        click.echo("  Supported forges: GitHub, GitLab, Bitbucket, Azure DevOps, Gitea")
        sys.exit(1)

    # Load existing config as defaults if present
    existing = _load_yaml_config(root)
    existing_github = existing.get("github", {})
    existing_docker = existing.get("docker", {})
    existing_llm = existing.get("llm", {})

    # Run auto-detection
    detected = detect_all(root)

    click.echo("")
    click.echo(click.style("Initializing shypmate", bold=True))
    if yml_path.exists():
        click.echo(f"  Updating existing config: {yml_path}")
    else:
        click.echo(f"  Creating new config: {yml_path}")
    click.echo("")

    # ── Secrets check (.env) ──
    env_path = root / ".env"
    gitignore_path = root / ".gitignore"

    def _read_env_var(name: str) -> str:
        """Read a variable from environment or .env file."""
        val = os.environ.get(name, "")
        if val:
            return val
        if env_path.exists():
            try:
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith(f"{name}=") and not line.startswith("#"):
                        return line.split("=", 1)[1].strip().strip("'\"")
            except Exception:
                pass
        return ""

    def _env_is_gitignored() -> bool:
        """Check if .env is listed in .gitignore."""
        if not gitignore_path.exists():
            return False
        try:
            for line in gitignore_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line in (".env", ".env*", "*.env") and not line.startswith("#"):
                    return True
        except Exception:
            pass
        return False

    # Check .env gitignore safety
    if env_path.exists() and not _env_is_gitignored():
        click.echo(click.style("  WARNING: .env is NOT in .gitignore — secrets may be committed!", fg="yellow", bold=True))
        click.echo(click.style("  Add '.env' to your .gitignore to prevent leaking tokens.", fg="yellow"))
        click.echo("")

    # ── Detect all available LLM API keys ──
    from shypmate.config.project import LLM_PROVIDER_PRESETS

    _init_key_scan = {
        "ANTHROPIC_API_KEY": "anthropic",
        "OPENAI_API_KEY": "openai",
        "GOOGLE_API_KEY": "gemini",
        "MISTRAL_API_KEY": "mistral",
        "GROQ_API_KEY": "groq",
        "DEEPSEEK_API_KEY": "deepseek",
        "TOGETHER_API_KEY": "together",
    }
    available_providers = []
    for key_var, provider_name in _init_key_scan.items():
        val = _read_env_var(key_var)
        if val:
            available_providers.append((provider_name, key_var, val))

    # ── AI-assisted analysis (ask first for better suggestions) ──
    ai_suggestions = None
    ai_provider = None  # which provider to use for init analysis
    ai_api_key = ""

    if not non_interactive:
        click.echo(click.style("AI-assisted setup", bold=True))
        click.echo(click.style("  Shypmate can use AI to analyze your project and pre-fill config", fg="bright_black"))
        click.echo(click.style("  with smarter defaults — validation commands, service rules, and more.", fg="bright_black"))
        click.echo(click.style("  Tokens are stored in .env only, never in shypmate.yml.", fg="bright_black"))

        if available_providers:
            click.echo("")
            click.echo(f"  Found {len(available_providers)} LLM API key(s) in .env:")
            for i, (prov, kvar, val) in enumerate(available_providers):
                label = LLM_PROVIDER_PRESETS.get(prov, {}).get("label", prov)
                click.echo(f"    [{i + 1}] {label} ({kvar}: {val[:4]}...{val[-4:]})")

            if len(available_providers) == 1:
                prov, kvar, val = available_providers[0]
                label = LLM_PROVIDER_PRESETS.get(prov, {}).get("label", prov)
                use_ai = click.confirm(f"\n  Use {label} for AI-assisted setup?", default=True)
                if use_ai:
                    ai_provider, ai_api_key = prov, val
            else:
                click.echo(f"    [0] Skip AI-assisted setup")
                choice = click.prompt("\n  Which provider for AI-assisted setup?",
                                      type=int, default=1)
                if 1 <= choice <= len(available_providers):
                    ai_provider = available_providers[choice - 1][0]
                    ai_api_key = available_providers[choice - 1][2]
                    use_ai = True
                else:
                    use_ai = False
        else:
            click.echo("")
            click.echo("  No LLM API keys found in environment or .env.")
            click.echo("  To enable AI-assisted setup, add at least one key to .env:")
            click.echo("")
            click.echo(click.style("    ANTHROPIC_API_KEY=sk-ant-...", fg="cyan"))
            click.echo(click.style("    OPENAI_API_KEY=sk-...", fg="cyan"))
            click.echo(click.style("    GITHUB_TOKEN=ghp_...", fg="cyan"))
            click.echo("")
            click.echo("  Get keys at: https://console.anthropic.com/ or https://platform.openai.com/")
            click.echo("")
            choice = click.prompt(
                "  Continue without AI, or exit to set up .env first?",
                type=click.Choice(["continue", "exit"], case_sensitive=False),
                default="continue",
            )
            if choice == "exit":
                click.echo("\nAdd your keys to .env, then re-run: shypmate init")
                sys.exit(0)
            use_ai = False

        # Check for GITHUB_TOKEN
        github_token = _read_env_var("GITHUB_TOKEN")
        if not github_token:
            click.echo(click.style("  Note: GITHUB_TOKEN not found — agents need this to clone,", fg="yellow"))
            click.echo(click.style("  push, and open PRs. Add it to .env before running agents.", fg="yellow"))

        click.echo("")
    else:
        # Non-interactive: use first available provider
        if available_providers:
            ai_provider = available_providers[0][0]
            ai_api_key = available_providers[0][2]
            use_ai = True
        else:
            use_ai = False


    def _prompt_value(label, detected_val, detected_source, existing_val=None):
        """Prompt for a value, showing detected source."""
        # Existing yml value takes precedence as default
        default = existing_val or detected_val
        source = "shypmate.yml" if existing_val else detected_source

        if source:
            hint = f" ({source})"
        else:
            hint = ""

        if non_interactive:
            if default:
                click.echo(f"  {label}: {default}{hint}")
            return default

        result = click.prompt(f"  {label}{hint}", default=default or "")
        return result

    def _prompt_list(label, detected_list, detected_source, existing_list=None):
        """Prompt for a list value, showing detected source."""
        default = existing_list if existing_list is not None else detected_list
        source = "shypmate.yml" if existing_list is not None else detected_source

        if source:
            hint = f" ({source})"
        else:
            hint = ""

        if non_interactive:
            if default:
                click.echo(f"  {label}{hint}: {', '.join(default)}")
            return default

        result = click.prompt(f"  {label}{hint} (comma-separated)", default=", ".join(default) if default else "")

        if not result:
            return []
        return [s.strip() for s in result.split(",") if s.strip()]

    # ── GitHub ──
    click.echo(click.style("GitHub", bold=True))
    click.echo(click.style("  Agents clone this repo, create branches, and open PRs against it.", fg="bright_black"))
    github_repo = _prompt_value(
        "Repository (owner/name)",
        detected["github_repo"][0], detected["github_repo"][1],
        existing_github.get("repo"),
    )
    base_branch = _prompt_value(
        "Base branch",
        detected["base_branch"][0], detected["base_branch"][1],
        existing_github.get("base_branch"),
    )
    click.echo("")

    # ── Docker ──
    click.echo(click.style("Docker", bold=True))
    click.echo(click.style("  Agents run in isolated containers but join this network to reach", fg="bright_black"))
    click.echo(click.style("  shared services (databases, caches, etc.) from your docker-compose.", fg="bright_black"))
    click.echo(click.style("  Leave empty if your project has no shared services.", fg="bright_black"))

    if not non_interactive:
        # Show available Docker networks
        try:
            docker_client = _get_docker_client()
            networks = docker_client.networks.list()
            skip_nets = {"host", "none"}
            click.echo("")
            click.echo("  Available networks:")
            for n in sorted(networks, key=lambda x: x.name):
                if n.name in skip_nets:
                    continue
                if n.name == "bridge":
                    click.echo(click.style(f"    - bridge (default — no DNS, containers reach each other by IP only)", fg="bright_black"))
                else:
                    # Count connected containers
                    try:
                        detail = docker_client.networks.get(n.id)
                        container_count = len(detail.attrs.get("Containers", {}))
                        suffix = f" ({container_count} container{'s' if container_count != 1 else ''})" if container_count else ""
                    except Exception:
                        suffix = ""
                    click.echo(f"    - {n.name}{suffix}")
            click.echo("")
        except Exception:
            pass

    docker_network = _prompt_value(
        "Network name",
        detected["docker_network"][0], detected["docker_network"][1],
        existing_docker.get("network"),
    )
    click.echo("")

    # ── Dependencies ──
    click.echo(click.style("Dependencies", bold=True))
    click.echo(click.style("  Command to install project dependencies inside the agent container.", fg="bright_black"))
    install_command = _prompt_value(
        "Install command",
        detected["install_command"][0], detected["install_command"][1],
        existing.get("install_command"),
    )
    click.echo("")

    # ── Tech stack ──
    click.echo(click.style("Tech stack", bold=True))
    click.echo(click.style("  Languages and frameworks used in this project. Helps agents", fg="bright_black"))
    click.echo(click.style("  understand the codebase and follow the right conventions.", fg="bright_black"))
    tech_stack = _prompt_list(
        "Technologies",
        detected["tech_stack"][0], detected["tech_stack"][1],
        existing.get("tech_stack"),
    )
    click.echo("")

    # ── Context files ──
    click.echo(click.style("Context files", bold=True))
    click.echo(click.style("  Files the agent reads before starting work to understand your", fg="bright_black"))
    click.echo(click.style("  project structure, conventions, and architecture.", fg="bright_black"))
    context_files = _prompt_list(
        "Files",
        detected["context_files"][0], detected["context_files"][1],
        existing.get("context_files"),
    )
    click.echo("")

    # ── LLM ──
    click.echo(click.style("LLM", bold=True))
    click.echo(click.style("  The AI model agents use to think, plan, and write code.", fg="bright_black"))
    click.echo(click.style("  Cloud providers require an API key. Local providers run on your machine.", fg="bright_black"))

    if not non_interactive:
        click.echo("")
        click.echo("  Available providers:")
        for key, preset in LLM_PROVIDER_PRESETS.items():
            model_hint = f" (default model: {preset['model']})" if preset['model'] else ""
            click.echo(f"    {key:<12} {preset['label']}{model_hint}")
        click.echo("")

    existing_provider = existing_llm.get("provider", "")
    llm_provider = _prompt_value(
        "Provider",
        "anthropic", "default",
        existing_provider,
    )

    # Look up preset for the chosen provider
    preset = LLM_PROVIDER_PRESETS.get(llm_provider, LLM_PROVIDER_PRESETS.get("custom", {}))
    preset_model = preset.get("model", "")
    preset_base_url = preset.get("base_url", "")
    preset_api_key_var = preset.get("api_key_var", "")

    llm_model = _prompt_value(
        "Model",
        preset_model, f"{llm_provider} default",
        existing_llm.get("model"),
    )

    # Only prompt for base_url if the preset has one or there's an existing value
    existing_base_url = existing_llm.get("base_url", "")
    if preset_base_url or existing_base_url or llm_provider == "custom":
        llm_base_url = _prompt_value(
            "Base URL",
            preset_base_url, f"{llm_provider} default" if preset_base_url else None,
            existing_base_url,
        )
    else:
        llm_base_url = ""

    llm_api_key_var = _prompt_value(
        "API key env var",
        preset_api_key_var, f"{llm_provider} default" if preset_api_key_var else None,
        existing_llm.get("api_key_var"),
    )

    # Check if the required API key is present
    if llm_api_key_var and not non_interactive:
        key_val = _read_env_var(llm_api_key_var)
        if not key_val:
            click.echo(click.style(f"  Note: {llm_api_key_var} not found in .env — add it before launching agents.", fg="yellow"))

    click.echo("")

    # ── LLM Pool ──
    existing_pool = existing_llm.get("pool", [])
    llm_pool = list(existing_pool)

    if not non_interactive:
        click.echo(click.style("LLM pool (optional)", bold=True))
        click.echo(click.style("  Add multiple providers to distribute agents across them (round-robin).", fg="bright_black"))
        click.echo(click.style("  Helps avoid rate limits. Can mix cloud and local providers.", fg="bright_black"))
        click.echo(click.style("  The provider configured above is always used if no pool is defined.", fg="bright_black"))

        # Detect available API keys to suggest a pool
        detected_keys = []
        key_var_names = {
            "ANTHROPIC_API_KEY": "anthropic",
            "OPENAI_API_KEY": "openai",
            "GOOGLE_API_KEY": "gemini",
            "MISTRAL_API_KEY": "mistral",
            "GROQ_API_KEY": "groq",
            "DEEPSEEK_API_KEY": "deepseek",
            "TOGETHER_API_KEY": "together",
        }
        for key_var, provider_name in key_var_names.items():
            val = _read_env_var(key_var)
            if val:
                detected_keys.append((provider_name, key_var))

        if llm_pool:
            click.echo(f"  Existing pool ({len(llm_pool)} providers):")
            for i, entry in enumerate(llm_pool):
                click.echo(f"    [{i}] {entry.get('provider', '?')} / {entry.get('model', '?')}")
            keep = click.confirm("  Keep existing pool?", default=True)
            if not keep:
                llm_pool = []

        # If multiple keys detected and no existing pool, suggest one
        if len(detected_keys) > 1 and not llm_pool:
            click.echo("")
            click.echo(f"  Found {len(detected_keys)} LLM API keys in .env:")
            suggested_pool = []
            for provider_name, key_var in detected_keys:
                preset = LLM_PROVIDER_PRESETS.get(provider_name, {})
                click.echo(f"    - {preset.get('label', provider_name)} ({key_var})")
                suggested_pool.append({
                    "provider": provider_name,
                    "model": preset.get("model", ""),
                    "api_key_var": key_var,
                })
            click.echo("")
            use_suggested = click.confirm("  Create a pool from these providers?", default=True)
            if use_suggested:
                llm_pool = suggested_pool
                click.echo(f"  Pool created with {len(llm_pool)} providers")

        if not llm_pool:
            add_pool = click.confirm("  Add providers to the pool manually?", default=False)
            if add_pool:
                click.echo("  Available providers:")
                for key, p in LLM_PROVIDER_PRESETS.items():
                    click.echo(f"    {key:<12} {p['label']}")
                click.echo("  (Enter empty provider to finish)")
                while True:
                    provider = click.prompt("    Provider", default="")
                    if not provider:
                        break
                    p = LLM_PROVIDER_PRESETS.get(provider, LLM_PROVIDER_PRESETS.get("custom", {}))
                    model = click.prompt("    Model", default=p.get("model", ""))
                    key_var = click.prompt("    API key env var", default=p.get("api_key_var", ""))
                    entry = {"provider": provider, "model": model}
                    if key_var:
                        entry["api_key_var"] = key_var
                    base = p.get("base_url", "")
                    if base:
                        entry["base_url"] = base
                    llm_pool.append(entry)
                    click.echo(f"    Added: {provider} / {model}")

    click.echo("")

    # ── Run AI analysis now (after collecting tech_stack/docker_network) ──
    if use_ai and ai_api_key:
        label = LLM_PROVIDER_PRESETS.get(ai_provider, {}).get("label", ai_provider)
        click.echo(click.style(f"Analyzing project with {label}...", bold=True))
        ai_suggestions = _ai_analyze_project(root, ai_api_key, tech_stack, docker_network, provider=ai_provider)
        if ai_suggestions:
            click.echo(click.style("  Done", fg="green"))
        else:
            click.echo("  Analysis failed, falling back to manual input")
        click.echo("")

    # ── Validation commands ──
    click.echo(click.style("Validation commands", bold=True))
    click.echo(click.style("  Commands agents run after making changes to verify correctness.", fg="bright_black"))
    click.echo(click.style("  Examples: linting, formatting, type checking, running tests.", fg="bright_black"))
    existing_validation = existing.get("validation_commands", [])

    # Show AI suggestions if available
    if ai_suggestions and ai_suggestions.get("validation_commands") and not existing_validation:
        suggested = ai_suggestions["validation_commands"]
        click.echo("  AI-suggested commands:")
        for i, vc in enumerate(suggested, 1):
            click.echo(f"    {i}. {vc.get('description', '?')}: {vc.get('command', '?')}")
        if non_interactive or click.confirm("  Accept these?", default=True):
            existing_validation = suggested
        else:
            existing_validation = []

    if existing_validation and not non_interactive and not (ai_suggestions and ai_suggestions.get("validation_commands")):
        click.echo("  Existing commands:")
        for vc in existing_validation:
            click.echo(f"    - {vc.get('description', '?')}: {vc.get('command', '?')}")
        keep = click.confirm("  Keep existing?", default=True)
        if not keep:
            existing_validation = []

    validation_commands = list(existing_validation)
    if not non_interactive:
        click.echo("  Add more validation commands (empty command to finish):")
        while True:
            cmd = click.prompt("    Command", default="")
            if not cmd:
                break
            desc = click.prompt("    Description", default=cmd)
            validation_commands.append({"command": cmd, "description": desc})
    click.echo("")

    # ── Shared service rules ──
    click.echo(click.style("Shared service rules", bold=True))
    click.echo(click.style("  Safety guardrails for agents using shared services (databases, caches,", fg="bright_black"))
    click.echo(click.style("  queues). Agents treat these as read-only unless rules say otherwise.", fg="bright_black"))
    existing_rules = existing.get("shared_service_rules", [])

    # Show AI suggestions if available
    if ai_suggestions and ai_suggestions.get("shared_service_rules") and not existing_rules:
        suggested = ai_suggestions["shared_service_rules"]
        click.echo("  AI-suggested rules:")
        for i, rule in enumerate(suggested, 1):
            click.echo(f"    {i}. {rule}")
        if non_interactive or click.confirm("  Accept these?", default=True):
            existing_rules = suggested
        else:
            existing_rules = []

    if existing_rules and not non_interactive and not (ai_suggestions and ai_suggestions.get("shared_service_rules")):
        click.echo("  Existing rules:")
        for r in existing_rules:
            click.echo(f"    - {r}")
        keep = click.confirm("  Keep existing?", default=True)
        if not keep:
            existing_rules = []

    shared_service_rules = list(existing_rules)
    if not non_interactive:
        click.echo("  Add more rules (empty to finish):")
        while True:
            rule = click.prompt("    Rule", default="")
            if not rule:
                break
            shared_service_rules.append(rule)
    click.echo("")

    # ── Agent quotas ──
    click.echo(click.style("Agent quotas (USD)", bold=True))
    click.echo(click.style("  Cost limits to prevent runaway spending. At least one hard limit is required.", fg="bright_black"))
    click.echo(click.style("  Soft quota: pauses the agent and asks you whether to continue.", fg="bright_black"))
    click.echo(click.style("  Hard quota: stops the agent immediately. Required for safety.", fg="bright_black"))

    existing_quota = existing.get("quota", {})
    existing_soft = existing_quota.get("soft", {})
    existing_hard = existing_quota.get("hard", {})

    soft_quota = {}
    hard_quota = {}

    if non_interactive:
        soft_quota = existing_soft or {"max_cost": 0.50, "max_iterations": 15}
        hard_quota = existing_hard or {"max_cost": 2.00, "max_iterations": 30}
        click.echo(f"  Soft: {soft_quota}")
        click.echo(f"  Hard: {hard_quota}")
    else:
        click.echo("")
        click.echo("  Soft limits (pause and ask — set 0 to disable):")
        val = click.prompt("    Max cost (USD)", default=existing_soft.get("max_cost", 0.50), type=float)
        if val > 0:
            soft_quota["max_cost"] = val
        val = click.prompt("    Max iterations", default=existing_soft.get("max_iterations", 15), type=int)
        if val > 0:
            soft_quota["max_iterations"] = val
        val = click.prompt("    Max seconds", default=existing_soft.get("max_seconds", 0), type=int)
        if val > 0:
            soft_quota["max_seconds"] = val

        click.echo("")
        click.echo("  Hard limits (stop immediately — at least one required):")
        val = click.prompt("    Max cost (USD)", default=existing_hard.get("max_cost", 2.00), type=float)
        if val > 0:
            hard_quota["max_cost"] = val
        val = click.prompt("    Max iterations", default=existing_hard.get("max_iterations", 30), type=int)
        if val > 0:
            hard_quota["max_iterations"] = val
        val = click.prompt("    Max seconds", default=existing_hard.get("max_seconds", 0), type=int)
        if val > 0:
            hard_quota["max_seconds"] = val

        if not hard_quota:
            click.echo(click.style("  WARNING: No hard limit set. Defaulting to max_cost=$2.00, max_iterations=30", fg="yellow"))
            hard_quota = {"max_cost": 2.00, "max_iterations": 30}

    click.echo("")

    # ── Build the config dict (omit empty/default values for cleanliness) ──
    config = {}

    github_section = {}
    if github_repo:
        github_section["repo"] = github_repo
    if base_branch and base_branch != "main":
        github_section["base_branch"] = base_branch
    if github_section:
        config["github"] = github_section

    if docker_network:
        config["docker"] = {"network": docker_network}

    if install_command:
        config["install_command"] = install_command

    if tech_stack:
        config["tech_stack"] = tech_stack

    if context_files:
        config["context_files"] = context_files

    llm_section = {}
    if llm_provider and llm_provider != "anthropic":
        llm_section["provider"] = llm_provider
    # Always write model if provider is non-default, or if model differs from preset default
    default_preset = LLM_PROVIDER_PRESETS.get(llm_provider, {})
    if llm_model and llm_model != default_preset.get("model", "claude-sonnet-4-6"):
        llm_section["model"] = llm_model
    if llm_base_url and llm_base_url != default_preset.get("base_url", ""):
        llm_section["base_url"] = llm_base_url
    if llm_api_key_var and llm_api_key_var != default_preset.get("api_key_var", "ANTHROPIC_API_KEY"):
        llm_section["api_key_var"] = llm_api_key_var
    if llm_pool:
        llm_section["pool"] = llm_pool
    if llm_section:
        config["llm"] = llm_section

    if validation_commands:
        config["validation_commands"] = validation_commands

    if shared_service_rules:
        config["shared_service_rules"] = shared_service_rules

    # Quota — always include (required)
    quota_section = {}
    if soft_quota:
        quota_section["soft"] = soft_quota
    if hard_quota:
        quota_section["hard"] = hard_quota
    if quota_section:
        config["quota"] = quota_section

    # ── Write shypmate.yml ──
    import yaml

    yml_content = yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True)

    click.echo(click.style("Generated shypmate.yml:", bold=True))
    click.echo("")
    for line in yml_content.splitlines():
        click.echo(f"  {line}")
    click.echo("")

    if non_interactive or click.confirm("Write this to shypmate.yml?", default=True):
        with open(yml_path, "w", encoding="utf-8") as f:
            f.write(yml_content)
        click.echo(click.style(f"\nWritten: {yml_path}", fg="green"))
        click.echo("Run 'shypmate validate' to verify your setup.")
    else:
        click.echo("\nAborted. No file written.")


# ── Task Management ─────────────────────────────────────────

@cli.group()
def task():
    """Manage the task queue."""
    pass


@task.command("add")
@click.argument("description")
@click.option("--priority", "-p", default="normal",
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="Task priority (default: normal).")
@click.option("--id", "task_id", default=None, help="Custom task ID (auto-generated if omitted).")
def task_add(description: str, priority: str, task_id: str | None):
    """Add a new task to the queue.

    DESCRIPTION is what you want the agent to do.

    Examples:
      task add "Add pagination to /api/products/" --priority high
      task add "Fix receipt parser bug" --priority critical --id fix-parser
    """
    from shypmate.task_manager import add_task

    try:
        t = add_task(description, priority=priority, task_id=task_id)
        click.echo(f"Task added: {t['id']} [{t['priority']}]")
        click.echo(f"  {t['description']}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _fmt_time(iso_str: str | None) -> str:
    """Format an ISO timestamp to a short readable string, or '--' if empty."""
    if not iso_str:
        return "--"
    try:
        # Handle both timezone-aware and naive timestamps
        ts = iso_str.replace("+00:00", "").replace("Z", "")
        # Parse and format as short datetime
        dt = datetime.fromisoformat(ts)
        return dt.strftime("%m/%d %H:%M")
    except Exception:
        return iso_str[:16]


def _fmt_duration(start_str: str | None, end_str: str | None) -> str:
    """Calculate duration between two ISO timestamps."""
    if not start_str or not end_str:
        return ""
    try:
        start = datetime.fromisoformat(start_str.replace("+00:00", "").replace("Z", ""))
        end = datetime.fromisoformat(end_str.replace("+00:00", "").replace("Z", ""))
        delta = end - start
        total_secs = int(delta.total_seconds())
        if total_secs < 0:
            return ""
        if total_secs < 60:
            return f"{total_secs}s"
        if total_secs < 3600:
            return f"{total_secs // 60}m {total_secs % 60}s"
        hours = total_secs // 3600
        mins = (total_secs % 3600) // 60
        return f"{hours}h {mins}m"
    except Exception:
        return ""


def _get_live_agent_status(agent_id: str, docker_client) -> tuple[str, str]:
    """Look up live Docker container status. Returns (status, color)."""
    if not agent_id:
        return ("--", "white")
    container_name = f"shypmate-{agent_id}"
    try:
        c = docker_client.containers.get(container_name)
        if c.status == "running":
            return ("RUNNING", "cyan")
        elif c.status == "exited":
            exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
            if exit_code == 0:
                return ("DONE", "green")
            else:
                return (f"FAIL({exit_code})", "red")
        else:
            return (c.status.upper(), "yellow")
    except docker.errors.NotFound:
        return ("--", "white")
    except Exception:
        return ("?", "yellow")


def _get_live_pr_status(branch: str, gh_repo) -> tuple[str, str, str]:
    """Look up live PR status on GitHub. Returns (status, color, pr_url)."""
    if not gh_repo or not branch:
        return ("--", "white", "")
    try:
        owner = gh_repo.owner.login
        # Check all PRs for this branch
        for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
            url = pr.html_url
            if pr.merged:
                return ("MERGED", "green", url)
            elif pr.state == "open":
                return ("OPEN", "cyan", url)
            elif pr.state == "closed":
                return ("DECLINED", "red", url)
        return ("NO PR", "yellow", "")
    except Exception:
        return ("?", "yellow", "")


@task.command("list")
@click.option("--status", "-s", default=None,
              type=click.Choice(["pending", "running", "done", "failed", "cancelled"]),
              help="Filter by task status.")
@click.option("--priority", "-p", default=None,
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="Filter by priority.")
@click.option("--all", "show_all", is_flag=True, help="Show all tasks including done/failed.")
def task_list(status: str | None, priority: str | None, show_all: bool):
    """List tasks with live agent and PR status."""
    from shypmate.task_manager import list_tasks, PRIORITY_ORDER

    tasks = list_tasks(status=status, priority=priority)

    if not show_all and not status:
        tasks = [t for t in tasks if t.get("status") not in ("cancelled",)]

    if not tasks:
        click.echo("No tasks found.")
        return

    # Sort by priority then created_at
    tasks.sort(key=lambda t: (
        PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
        t.get("created_at", ""),
    ))

    # Live lookups
    docker_client = _get_docker_client()
    gh_repo = _get_gh_repo()

    pri_sym = {"critical": "!!!", "high": " !!", "normal": "  .", "low": "  -"}

    click.echo("")
    click.echo(f"  {'PRI':>3}  {'ID':<22} {'AGENT':<10} {'PR':<10} {'ADDED':<12} {'STARTED':<12} {'COMPLETED':<12} DESCRIPTION")
    click.echo(f"  {'---':>3}  {'--':<22} {'-----':<10} {'--':<10} {'-----':<12} {'-------':<12} {'---------':<12} -----------")

    for t in tasks:
        pri = pri_sym.get(t.get("priority", "normal"), "  .")
        tid = t.get("id", "?")[:22]
        desc = t.get("description", "")[:45]
        agent_id = t.get("agent_id", "")
        branch = t.get("branch", "")

        # Timestamps
        added = _fmt_time(t.get("created_at"))
        started = _fmt_time(t.get("started_at"))
        completed = _fmt_time(t.get("finished_at"))

        # Live agent status
        if agent_id:
            agent_str, agent_color = _get_live_agent_status(agent_id, docker_client)
        else:
            agent_str, agent_color = ("QUEUED", "white")

        # Live PR status
        if branch and agent_id:
            pr_str, pr_color, pr_url = _get_live_pr_status(branch, gh_repo)
        else:
            pr_str, pr_color, pr_url = ("--", "white", "")

        # Build the line
        line_start = f"  {pri:>3}  {tid:<22} "
        agent_part = click.style(f"{agent_str:<10}", fg=agent_color)
        pr_part = click.style(f"{pr_str:<10}", fg=pr_color)
        time_part = f"{added:<12} {started:<12} {completed:<12} "
        click.echo(line_start + agent_part + pr_part + time_part + desc)

        # Show PR URL and duration on next line if available
        extra = ""
        if pr_url:
            extra += pr_url
        duration = _fmt_duration(t.get("started_at"), t.get("finished_at"))
        if duration:
            extra += f"  (duration: {duration})" if extra else f"duration: {duration}"
        if extra:
            click.echo(f"       {extra}")

    click.echo("")

    # Also sync task states silently so ai_tasks.yml stays in sync
    _sync_task_states(verbose=False)


@task.command("remove")
@click.argument("task_id")
def task_remove(task_id: str):
    """Remove a task from the queue."""
    from shypmate.task_manager import remove_task

    if remove_task(task_id):
        click.echo(f"Removed: {task_id}")
    else:
        click.echo(f"Task not found: {task_id}", err=True)
        sys.exit(1)


@task.command("update")
@click.argument("task_id")
@click.option("--priority", "-p",
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="New priority.")
@click.option("--status", "-s",
              type=click.Choice(["pending", "running", "done", "failed", "cancelled"]),
              help="New status.")
@click.option("--description", "-d", help="New description.")
def task_update(task_id: str, priority: str | None, status: str | None, description: str | None):
    """Update a task's priority, status, or description."""
    from shypmate.task_manager import update_task

    updates = {}
    if priority:
        updates["priority"] = priority
    if status:
        updates["status"] = status
    if description:
        updates["description"] = description

    if not updates:
        click.echo("Nothing to update. Use --priority, --status, or --description.", err=True)
        sys.exit(1)

    try:
        t = update_task(task_id, **updates)
        click.echo(f"Updated: {t['id']} [{t.get('priority')}] {t.get('status')}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# ── Work — launch agents from the task queue ────────────────

@cli.command()
@click.option("--all", "launch_all", is_flag=True, help="Launch agents for ALL pending tasks.")
@click.option("--count", "-n", default=1, type=int, help="Number of tasks to launch (default: 1).")
@click.option("--no-detach", is_flag=True, help="Run in foreground (only with single task).")
@click.option("--dev/--no-dev", default=None, help="Dev mode: mount local src/ for live code changes. Auto-detects editable installs.")
def work(launch_all: bool, count: int, no_detach: bool, dev: bool):
    """Pick up pending tasks and launch agents for them.

    By default, launches the next highest-priority pending task.
    Use --all to launch agents for every pending task, or -n 3 for the top 3.
    """
    from shypmate.task_manager import mark_running, mark_failed, pending_tasks_by_priority
    from shypmate.config.project import get_llm_pool, get_pool_entry, LLM_PROVIDER_PRESETS

    github_token, llm_api_key = _validate_env()

    pending = pending_tasks_by_priority()
    if not pending:
        click.echo("No pending tasks. Add one with: python -m shypmate task add \"...\"")
        return

    if launch_all:
        to_launch = pending
    else:
        to_launch = pending[:count]

    if no_detach and len(to_launch) > 1:
        click.echo("Warning: --no-detach only works with a single task. Launching first task only.")
        to_launch = to_launch[:1]

    pool = get_llm_pool(PROJECT)
    if len(pool) > 1:
        click.echo(f"\nLLM pool: {len(pool)} provider(s)")
        for i, entry in enumerate(pool):
            label = LLM_PROVIDER_PRESETS.get(entry.provider, {}).get("label", entry.provider)
            click.echo(f"  [{i}] {label} / {entry.model}")
        click.echo("")

    click.echo(f"Launching {len(to_launch)} task(s)...\n")

    for i, t in enumerate(to_launch):
        agent_id = _generate_agent_id(t["description"])
        branch = _generate_branch_name(t["description"], agent_id)
        detach = not no_detach

        # Round-robin assignment from the pool
        llm_entry = get_pool_entry(PROJECT, i, task=t["description"])
        provider_label = LLM_PROVIDER_PRESETS.get(llm_entry.provider, {}).get("label", llm_entry.provider)

        click.echo(f"  [{t['priority']:>8}] {t['id']}")
        click.echo(f"           {t['description'][:70]}")
        click.echo(f"           agent={agent_id}  branch={branch[:50]}...")
        click.echo(f"           llm={provider_label} / {llm_entry.model}")

        # Mark running in task queue
        mark_running(t["id"], agent_id, branch)

        # Launch container
        result = _launch_agent_container(
            task=t["description"],
            agent_id=agent_id,
            branch=branch,
            github_token=github_token,
            llm_entry=llm_entry,
            detach=detach,
            task_id=t["id"],
            dev_mode=dev,
        )

        if result:
            click.echo(f"           container={result}")
        elif detach:
            # Launch failed
            mark_failed(t["id"])
            click.echo(f"           FAILED to launch")

        click.echo("")

    if len(to_launch) > 1:
        click.echo(f"Follow logs: docker logs -f shypmate-<agent-id>")


# ── Dashboard ───────────────────────────────────────────────

@cli.command()
def dashboard():
    """Live-updating dashboard with task queue, agents, and results."""
    import signal
    from shypmate.task_manager import list_tasks, PRIORITY_ORDER
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.text import Text
    from rich import box

    # Color mapping from click colors to rich styles
    COLOR_MAP = {
        "cyan": "cyan",
        "green": "green",
        "red": "red",
        "yellow": "yellow",
        "white": "dim white",
    }
    PRI_STYLE = {
        "critical": ("!!!", "bold red"),
        "high": ("!!", "yellow"),
        "normal": (".", "dim white"),
        "low": ("-", "dim"),
    }

    # Force color output in mintty/Git Bash which Rich can't auto-detect
    force_color = os.environ.get("TERM_PROGRAM") == "mintty" or "MINGW" in os.environ.get("MSYSTEM", "")
    console = Console(force_terminal=True) if force_color else Console()

    def _get_session_status() -> tuple[str, str]:
        """Get session uptime from monitor container. Returns (text, style)."""
        try:
            client = _get_docker_client()
            monitor = client.containers.get("shypmate-monitor")
            started_str = monitor.attrs.get("State", {}).get("StartedAt", "")
            if monitor.status == "running" and started_str:
                # Docker returns ISO format like 2026-03-28T12:00:00.123456789Z
                started = datetime.fromisoformat(started_str.split(".")[0])
                elapsed = datetime.utcnow() - started
                total_secs = int(elapsed.total_seconds())
                hours, remainder = divmod(total_secs, 3600)
                minutes, seconds = divmod(remainder, 60)
                if hours:
                    time_str = f"{hours}h {minutes:02d}m {seconds:02d}s"
                else:
                    time_str = f"{minutes}m {seconds:02d}s"
                return (f"session {time_str}", "green")
            elif monitor.status == "exited":
                return ("session stopped", "red")
            else:
                return (f"session {monitor.status}", "yellow")
        except Exception:
            return ("session inactive", "dim")

    def build_display():
        _sync_task_states(verbose=False)

        tasks = list_tasks()
        client = _get_docker_client()
        containers = client.containers.list(all=True, filters={"name": "shypmate-"})
        gh_repo = _get_gh_repo()

        # ── Header ──
        header = Text()
        header.append("shypmate dashboard", style="bold cyan")
        header.append("  |  ", style="dim")
        session_text, session_style = _get_session_status()
        header.append(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), style="white")
        header.append("  |  ", style="dim")
        header.append(session_text, style=session_style)
        header.append("  |  ", style="dim")
        header.append(f"{PROJECT.github_repo}", style="dim cyan")
        header.append(f"  ({PROJECT.base_branch})", style="dim")

        # ── Running containers table ──
        running = [c for c in containers if c.status == "running"]
        run_table = Table(
            box=box.SIMPLE_HEAVY,
            show_header=True,
            header_style="bold",
            expand=True,
            padding=(0, 1),
        )
        run_table.add_column("Container", style="cyan", ratio=2)
        run_table.add_column("Branch", style="yellow", ratio=2)
        run_table.add_column("Task", ratio=4)

        if running:
            for c in running:
                task_desc = ""
                branch = ""
                try:
                    for e in c.attrs.get("Config", {}).get("Env", []):
                        if e.startswith("AGENT_TASK="):
                            task_desc = e.split("=", 1)[1][:60]
                        elif e.startswith("AGENT_BRANCH="):
                            branch = e.split("=", 1)[1]
                except Exception:
                    pass
                run_table.add_row(c.name, branch, task_desc)
        else:
            run_table.add_row("[dim](none)[/dim]", "", "")

        # ── Task queue table ──
        tasks.sort(key=lambda t: (
            PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
            t.get("created_at", ""),
        ))

        task_table = Table(
            box=box.SIMPLE_HEAVY,
            show_header=True,
            header_style="bold",
            expand=True,
            padding=(0, 1),
        )
        task_table.add_column("Pri", justify="center", width=3)
        task_table.add_column("Task ID", ratio=2)
        task_table.add_column("Agent", justify="center", width=10)
        task_table.add_column("PR", justify="center", width=10)
        task_table.add_column("Started", justify="center", width=12)
        task_table.add_column("Completed", justify="center", width=12)
        task_table.add_column("Duration", justify="center", width=9)
        task_table.add_column("Description", ratio=3)

        if tasks:
            for t in tasks:
                pri_label, pri_style = PRI_STYLE.get(
                    t.get("priority", "normal"), (".", "dim white")
                )
                tid = t.get("id", "?")[:22]
                desc = t.get("description", "")[:40]
                agent_id = t.get("agent_id", "")
                branch = t.get("branch", "")

                started = _fmt_time(t.get("started_at"))
                completed = _fmt_time(t.get("finished_at"))
                duration = _fmt_duration(t.get("started_at"), t.get("finished_at"))

                if agent_id:
                    agent_str, agent_color = _get_live_agent_status(agent_id, client)
                else:
                    agent_str, agent_color = ("QUEUED", "white")

                if branch and agent_id:
                    pr_str, pr_color, pr_url = _get_live_pr_status(branch, gh_repo)
                else:
                    pr_str, pr_color, pr_url = ("--", "white", "")

                agent_styled = f"[{COLOR_MAP.get(agent_color, 'white')}]{agent_str}[/]"
                pr_styled = f"[{COLOR_MAP.get(pr_color, 'white')}]{pr_str}[/]"

                task_table.add_row(
                    f"[{pri_style}]{pri_label}[/]",
                    tid,
                    agent_styled,
                    pr_styled,
                    f"[dim]{started}[/]",
                    f"[dim]{completed}[/]",
                    f"[dim]{duration}[/]" if duration else "[dim]--[/]",
                    desc,
                )
        else:
            task_table.add_row("", "[dim](no tasks)[/dim]", "", "", "", "", "", "")

        # ── Recently exited ──
        exited = [c for c in containers if c.status == "exited"]
        exit_table = None
        if exited:
            exit_table = Table(
                box=box.SIMPLE_HEAVY,
                show_header=True,
                header_style="bold",
                expand=True,
                padding=(0, 1),
            )
            exit_table.add_column("Container", style="dim", ratio=3)
            exit_table.add_column("Result", justify="center", width=12)

            for c in exited[:5]:
                exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
                if exit_code == 0:
                    result = "[green]OK[/green]"
                else:
                    result = f"[red]FAIL ({exit_code})[/red]"
                exit_table.add_row(c.name, result)

        # ── Compose output ──
        from rich.console import Group
        parts = [
            header,
            Text(""),
            Panel(run_table, title="[bold]Running Containers[/bold]", border_style="cyan"),
            Panel(task_table, title="[bold]Task Queue[/bold]", border_style="blue"),
        ]
        if exit_table:
            parts.append(
                Panel(exit_table, title="[bold]Recently Exited[/bold]", border_style="dim")
            )

        parts.append(Text("  Refreshing every 5s. Press Ctrl+C to exit.", style="dim"))

        return Group(*parts)

    from rich.live import Live
    try:
        with Live(
            build_display(),
            console=console,
            refresh_per_second=0.2,
            screen=False,
        ) as live:
            if hasattr(signal, "SIGWINCH"):
                signal.signal(signal.SIGWINCH, lambda *_: live.update(build_display()))
            while True:
                time.sleep(5)
                live.update(build_display())
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")


# ── Sync — reconcile task states with reality ───────────────

def _find_pr_url(gh_repo, branch: str) -> str:
    """Look up PR URL for a branch on GitHub."""
    if not gh_repo or not branch:
        return ""
    try:
        owner = gh_repo.owner.login
        # Check open PRs first
        for pr in gh_repo.get_pulls(state="open", head=f"{owner}:{branch}"):
            return pr.html_url
        # Then closed/merged
        for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
            return pr.html_url
    except Exception:
        pass
    return ""


def _get_gh_repo():
    """Try to connect to GitHub and return the repo object."""
    try:
        from github import Github
        token = os.environ.get("GITHUB_TOKEN", "")
        if token and PROJECT.github_repo:
            return Github(token).get_repo(PROJECT.github_repo)
    except Exception:
        pass
    return None


def _sync_task_states(verbose: bool = False) -> None:
    """Check tasks against container state and GitHub PRs, update accordingly."""
    from shypmate.task_manager import list_tasks, update_task

    all_tasks = list_tasks()
    if not all_tasks:
        return

    client = _get_docker_client()
    gh_repo = _get_gh_repo()

    for t in all_tasks:
        agent_id = t.get("agent_id", "")
        branch = t.get("branch", "")
        status = t.get("status", "")

        # Backfill missing PR URLs for done tasks
        if status == "done" and not t.get("pr_url") and branch:
            pr_url = _find_pr_url(gh_repo, branch)
            if pr_url:
                update_task(t["id"], pr_url=pr_url)
                if verbose:
                    click.echo(f"  Backfilled PR: {t['id']} -> {pr_url}")
            continue

        # Only process running tasks for status changes
        if status != "running":
            continue

        container_name = f"shypmate-{agent_id}"

        # Check container status
        container = None
        try:
            container = client.containers.get(container_name)
        except docker.errors.NotFound:
            pass

        if container and container.status == "running":
            continue

        if container and container.status == "exited":
            exit_code = container.attrs.get("State", {}).get("ExitCode", -1)

            if exit_code == 0:
                pr_url = _find_pr_url(gh_repo, branch)
                update_task(t["id"], status="done", pr_url=pr_url, finished_at=datetime.now().isoformat())
                if verbose:
                    click.echo(f"  Synced: {t['id']} -> done" + (f" (PR: {pr_url})" if pr_url else ""))
            else:
                update_task(t["id"], status="failed", finished_at=datetime.now().isoformat())
                if verbose:
                    click.echo(f"  Synced: {t['id']} -> failed (exit code {exit_code})")

        elif not container:
            update_task(t["id"], status="failed", finished_at=datetime.now().isoformat())
            if verbose:
                click.echo(f"  Synced: {t['id']} -> failed (container not found)")


@cli.command()
def sync():
    """Sync task statuses with container state and GitHub PRs.

    Checks all 'running' tasks, looks up their containers, and updates
    status to 'done' (with PR URL) or 'failed' based on reality.
    """
    click.echo("Syncing task states...")
    _sync_task_states(verbose=True)
    click.echo("Done.")


# ── Direct agent launch (existing) ─────────────────────────

@cli.command("run-agent")
@click.option("--task", "-t", required=True, help="Task description for the agent.")
@click.option("--hat", default="developer", help="Hat (role) to use: developer, qa, product_owner, or custom. Default: developer.")
@click.option("--id", "agent_id", default=None, help="Agent ID (auto-generated if omitted).")
@click.option("--branch", "-b", default=None, help="Branch name (auto-generated if omitted).")
@click.option("--base-branch", default=None, help="Base branch.")
@click.option("--rebase", is_flag=True, help="Run in rebase/conflict-resolution mode.")
@click.option("--detach/--no-detach", default=True, help="Run in background (default: yes).")
@click.option("--dev/--no-dev", default=None, help="Dev mode: mount local src/ for live code changes. Auto-detects editable installs.")
def run_agent(task: str, hat: str, agent_id: str | None, branch: str | None, base_branch: str | None, rebase: bool, detach: bool, dev: bool | None):
    """Launch an agent directly (bypasses task queue).

    Uses the developer hat by default. Pass --hat to use a different role.
    """
    from shypmate.hats.coordinator import load_hats_from_config

    all_hats = load_hats_from_config()
    if hat not in all_hats:
        click.echo(f"Unknown hat: '{hat}'. Available: {', '.join(all_hats.keys())}", err=True)
        sys.exit(1)

    github_token, llm_api_key = _validate_env()

    if not agent_id:
        agent_id = _generate_agent_id(task)
    if not branch:
        branch = _generate_branch_name(task, agent_id)

    click.echo(f"Launching agent '{agent_id}'")
    click.echo(f"  Task:   {task[:80]}")
    click.echo(f"  Hat:    {hat}")
    click.echo(f"  Branch: {branch}")
    click.echo(f"  Rebase: {rebase}")
    if dev:
        click.echo(f"  Mode:   DEV (local src/ mounted)")

    result = _launch_agent_container(
        task=task,
        agent_id=agent_id,
        branch=branch,
        github_token=github_token,
        base_branch=base_branch,
        rebase=rebase,
        detach=detach,
        dev_mode=dev,
        pipeline_hats=hat,  # single hat = single-hat pipeline
    )

    if result:
        click.echo(f"\nContainer started: {result}")
        click.echo(f"  Follow logs: docker logs -f shypmate-{agent_id}")
    elif detach:
        sys.exit(1)
    else:
        click.echo("\nAgent finished.")


# ── Validate ───────────────────────────────────────────────

@cli.command()
def validate():
    """Validate shypmate.yml configuration and environment."""
    from pathlib import Path

    root = Path(PROJECT.project_root)
    yml_path = root / "shypmate.yml"
    env_path = root / ".env"
    errors = []
    warnings = []

    # ── Config sources ──
    py_path = root / "shypmate.py"
    click.echo(click.style("Config sources", bold=True))
    if yml_path.exists():
        click.echo(f"  shypmate.yml: {yml_path}")
    else:
        click.echo(f"  shypmate.yml: not found")

    if py_path.exists():
        from shypmate.config.project import get_user_hook, _user_module, _PY_FUNC_CONFIG_MAP
        hooks = [name for name in ["select_llm"] if get_user_hook(name)]
        config_funcs = []
        if _user_module:
            for func_name in _PY_FUNC_CONFIG_MAP:
                func = getattr(_user_module, func_name, None)
                if func and callable(func):
                    config_funcs.append(func_name)
        has_dict = bool(getattr(_user_module, "config", None)) if _user_module else False

        click.echo(f"  shypmate.py:  {py_path}")
        if has_dict:
            click.echo(f"    config dict: yes")
        if config_funcs:
            click.echo(f"    config functions: {', '.join(config_funcs)}")
        if hooks:
            click.echo(f"    hooks: {', '.join(hooks)}")

    if not yml_path.exists() and not py_path.exists():
        errors.append("No config found — run 'shypmate init' or create shypmate.yml / shypmate.py")

    # ── Required config ──
    click.echo(click.style("\nRequired config", bold=True))

    if PROJECT.github_repo:
        click.echo(f"  github.repo: {PROJECT.github_repo} ({PROJECT.github_repo_source})")
    else:
        click.echo("  github.repo: NOT SET")
        errors.append("github.repo is required — set in shypmate.yml, SHYPMATE_GITHUB_REPO, or have a git remote origin pointing to GitHub")

    if PROJECT.docker_network:
        click.echo(f"  docker.network: {PROJECT.docker_network}")
    else:
        click.echo("  docker.network: not set")
        warnings.append("docker.network not set — agents will run without shared service access")

    # ── Secrets ──
    click.echo(click.style("\nSecrets (.env)", bold=True))
    if env_path.exists():
        click.echo(f"  Found: {env_path}")
    else:
        click.echo(f"  Not found at {env_path}")
        warnings.append(".env file not found — create one with GITHUB_TOKEN and ANTHROPIC_API_KEY")

    def _read_secret(name: str) -> str:
        """Read a secret from environment or .env file."""
        val = os.environ.get(name, "")
        if val:
            return val
        if env_path.exists():
            try:
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith(f"{name}=") and not line.startswith("#"):
                        return line.split("=", 1)[1].strip().strip("'\"")
            except Exception:
                pass
        return ""

    # Check .gitignore safety
    gitignore_path = root / ".gitignore"
    if env_path.exists():
        env_gitignored = False
        if gitignore_path.exists():
            try:
                for line in gitignore_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line in (".env", ".env*", "*.env") and not line.startswith("#"):
                        env_gitignored = True
                        break
            except Exception:
                pass
        if not env_gitignored:
            click.echo(click.style("  WARNING: .env is NOT in .gitignore", fg="yellow"))
            warnings.append(".env is not in .gitignore — secrets may be committed")

    github_token = _read_secret("GITHUB_TOKEN")
    api_key_var = PROJECT.llm_api_key_var or "ANTHROPIC_API_KEY"
    llm_api_key = _read_secret(api_key_var)

    if github_token:
        click.echo(f"  GITHUB_TOKEN: {github_token[:4]}...{github_token[-4:]}")
    else:
        click.echo("  GITHUB_TOKEN: NOT SET")
        warnings.append("GITHUB_TOKEN not found — required to launch agents")

    if llm_api_key:
        click.echo(f"  {api_key_var}: {llm_api_key[:4]}...{llm_api_key[-4:]}")
    elif api_key_var:
        click.echo(f"  {api_key_var}: NOT SET")
        warnings.append(f"{api_key_var} not found — required to launch agents")
    else:
        click.echo("  LLM API key: not required (local provider)")

    # ── Agent settings ──
    click.echo(click.style("\nAgent settings", bold=True))
    click.echo(f"  base_branch: {PROJECT.base_branch} ({PROJECT.base_branch_source})")
    click.echo(f"  branch_prefix: {PROJECT.branch_prefix}")
    click.echo(f"  pr_title_prefix: {PROJECT.pr_title_prefix}")
    click.echo(f"  pr_label: {PROJECT.pr_label}")
    click.echo(f"  image: {PROJECT.agent_image_name}:{PROJECT.agent_image_tag}")

    # ── LLM ──
    click.echo(click.style("\nLLM", bold=True))
    from shypmate.config.project import LLM_PROVIDER_PRESETS
    preset = LLM_PROVIDER_PRESETS.get(PROJECT.llm_provider, {})
    provider_label = preset.get("label", PROJECT.llm_provider)
    click.echo(f"  provider: {PROJECT.llm_provider} ({provider_label})")
    click.echo(f"  model: {PROJECT.llm_model}")
    click.echo(f"  max_tokens: {PROJECT.llm_max_tokens}")
    if PROJECT.llm_base_url:
        click.echo(f"  base_url: {PROJECT.llm_base_url}")
    click.echo(f"  api_key_var: {PROJECT.llm_api_key_var or '(none — local provider)'}")

    if PROJECT.llm_pool:
        click.echo(click.style("\nLLM pool", bold=True) + f" ({len(PROJECT.llm_pool)} providers — round-robin)")
        for i, entry in enumerate(PROJECT.llm_pool):
            label = LLM_PROVIDER_PRESETS.get(entry.provider, {}).get("label", entry.provider)
            key_status = ""
            if entry.api_key_var:
                key_val = _read_secret(entry.api_key_var)
                key_status = " (key found)" if key_val else f" ({entry.api_key_var} NOT SET)"
            else:
                key_status = " (no key needed)"
            click.echo(f"  [{i}] {label} / {entry.model}{key_status}")
            if entry.base_url:
                click.echo(f"      base_url: {entry.base_url}")

    # ── Quotas ──
    has_soft = PROJECT.soft_max_tokens or PROJECT.soft_max_cost or PROJECT.soft_max_seconds or PROJECT.soft_max_iterations
    has_hard = PROJECT.hard_max_tokens or PROJECT.hard_max_cost or PROJECT.hard_max_seconds or PROJECT.hard_max_iterations

    click.echo(click.style("\nAgent quotas (USD)", bold=True))
    if not has_hard:
        click.echo("  Hard quota: NOT SET")
        errors.append("Hard quota is required — set at least one limit under quota.hard in shypmate.yml (max_tokens, max_cost, max_seconds, or max_iterations)")

    if has_soft or has_hard:
        if has_soft:
            parts = []
            if PROJECT.soft_max_tokens: parts.append(f"tokens={PROJECT.soft_max_tokens:,}")
            if PROJECT.soft_max_cost: parts.append(f"cost=${PROJECT.soft_max_cost}")
            if PROJECT.soft_max_seconds: parts.append(f"time={PROJECT.soft_max_seconds}s")
            if PROJECT.soft_max_iterations: parts.append(f"iterations={PROJECT.soft_max_iterations}")
            click.echo(f"  Soft (ask human): {', '.join(parts)}")
        if has_hard:
            parts = []
            if PROJECT.hard_max_tokens: parts.append(f"tokens={PROJECT.hard_max_tokens:,}")
            if PROJECT.hard_max_cost: parts.append(f"cost=${PROJECT.hard_max_cost}")
            if PROJECT.hard_max_seconds: parts.append(f"time={PROJECT.hard_max_seconds}s")
            if PROJECT.hard_max_iterations: parts.append(f"iterations={PROJECT.hard_max_iterations}")
            click.echo(f"  Hard (stop):      {', '.join(parts)}")

    # ── Auto-detected config ──
    if PROJECT.install_command:
        click.echo(click.style("\nInstall command", bold=True))
        click.echo(f"  {PROJECT.install_command} ({PROJECT.install_command_source})")

    if PROJECT.tech_stack:
        click.echo(click.style("\nTech stack", bold=True) + f" ({PROJECT.tech_stack_source})")
        for t in PROJECT.tech_stack:
            click.echo(f"  - {t}")

    if PROJECT.context_files:
        click.echo(click.style("\nContext files", bold=True) + f" ({PROJECT.context_files_source})")
        for f in PROJECT.context_files:
            exists = (root / f).exists()
            status = "" if exists else " (missing)"
            click.echo(f"  - {f}{status}")
            if not exists:
                warnings.append(f"Context file '{f}' not found at {root / f}")

    if PROJECT.validation_commands:
        click.echo(click.style("\nValidation commands", bold=True))
        for cmd, desc in PROJECT.validation_commands:
            click.echo(f"  - {desc}: {cmd}")

    if PROJECT.shared_service_rules:
        click.echo(click.style("\nShared service rules", bold=True))
        for rule in PROJECT.shared_service_rules:
            click.echo(f"  - {rule}")

    if PROJECT.allowed_shell_prefixes:
        click.echo(click.style("\nAllowed shell prefixes", bold=True))
        for p in PROJECT.allowed_shell_prefixes:
            click.echo(f"  - {p}")

    if PROJECT.blocked_shell_patterns:
        click.echo(click.style("\nBlocked shell patterns", bold=True))
        for p in PROJECT.blocked_shell_patterns:
            click.echo(f"  - {p}")

    # ── Docker connectivity ──
    click.echo(click.style("\nDocker", bold=True))
    try:
        client = _get_docker_client()
        client.ping()
        click.echo("  Daemon: connected")

        image_tag = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"
        try:
            client.images.get(image_tag)
            click.echo(f"  Agent image: {image_tag} (found)")
        except docker.errors.ImageNotFound:
            click.echo(f"  Agent image: {image_tag} (not built)")
            warnings.append(f"Agent image '{image_tag}' not found — run: shypmate build")

        if PROJECT.docker_network:
            try:
                client.networks.get(PROJECT.docker_network)
                click.echo(f"  Network: {PROJECT.docker_network} (found)")
            except docker.errors.NotFound:
                click.echo(f"  Network: {PROJECT.docker_network} (not found)")
                warnings.append(f"Docker network '{PROJECT.docker_network}' does not exist")
    except docker.errors.DockerException:
        click.echo("  Daemon: NOT REACHABLE")
        errors.append("Cannot connect to Docker daemon")

    # ── Summary ──
    click.echo("")
    if errors:
        click.echo(click.style(f"ERRORS ({len(errors)}):", fg="red", bold=True))
        for e in errors:
            click.echo(click.style(f"  - {e}", fg="red"))
    if warnings:
        click.echo(click.style(f"WARNINGS ({len(warnings)}):", fg="yellow", bold=True))
        for w in warnings:
            click.echo(click.style(f"  - {w}", fg="yellow"))
    if not errors and not warnings:
        click.echo(click.style("All checks passed.", fg="green", bold=True))
        click.echo("Run 'shypmate verify' to test an end-to-end agent run.")
    elif not errors:
        click.echo(click.style("\nConfig is valid (with warnings).", fg="green"))
        click.echo("Run 'shypmate verify' to test an end-to-end agent run.")

    sys.exit(1 if errors else 0)


# ── Verify ─────────────────────────────────────────────────

@cli.command()
@click.option("--task", "-t", default=None, help="Custom task for the verify run.")
@click.option("--skip-build", is_flag=True, help="Skip auto-building the Docker image.")
def verify(task: str | None, skip_build: bool):
    """Test an end-to-end agent run in a Docker container.

    Builds the agent image (if needed), launches a container with a simple
    test task, verifies the LLM responds, and cleans up. No GitHub push or PR.

    Use after 'shypmate init' and 'shypmate validate' to confirm everything works.
    """
    import subprocess

    from shypmate.config.project import LLM_PROVIDER_PRESETS, get_pool_entry

    click.echo("")
    click.echo(click.style("=== Shypmate Verify ===", bold=True))
    click.echo("")

    # ── Step 1: Check prerequisites ──
    click.echo(click.style("Checking prerequisites...", bold=True))

    # Config
    if not PROJECT.github_repo:
        click.echo(click.style("  FAIL: github.repo not configured", fg="red"))
        click.echo("  Run 'shypmate init' first.")
        sys.exit(1)
    click.echo(f"  Config: OK ({PROJECT.github_repo})")

    # Docker
    client = _get_docker_client()
    try:
        client.ping()
        click.echo("  Docker: OK")
    except Exception:
        click.echo(click.style("  FAIL: Docker not running", fg="red"))
        sys.exit(1)

    # LLM API key
    llm_entry = get_pool_entry(PROJECT, 0)
    provider_label = LLM_PROVIDER_PRESETS.get(llm_entry.provider, {}).get("label", llm_entry.provider)

    llm_api_key = ""
    if llm_entry.api_key_var:
        llm_api_key = os.environ.get(llm_entry.api_key_var, "") or _read_env_file_var(llm_entry.api_key_var)
        if not llm_api_key:
            click.echo(click.style(f"  FAIL: {llm_entry.api_key_var} not found in .env or environment", fg="red"))
            sys.exit(1)
        click.echo(f"  LLM key: OK ({llm_entry.api_key_var})")
    else:
        click.echo(f"  LLM key: not required ({provider_label})")

    click.echo(f"  Provider: {provider_label} / {llm_entry.model}")

    # GitHub token
    github_token = os.environ.get("GITHUB_TOKEN", "") or _read_env_file_var("GITHUB_TOKEN")
    if not github_token:
        click.echo(click.style("  FAIL: GITHUB_TOKEN not found", fg="red"))
        sys.exit(1)
    click.echo("  GitHub token: OK")
    click.echo("")

    # ── Step 2: Build image if needed ──
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"
    try:
        client.images.get(image)
        click.echo(f"  Agent image: {image} (found)")
    except docker.errors.ImageNotFound:
        if skip_build:
            click.echo(click.style(f"  FAIL: Image '{image}' not found. Run 'shypmate build' first.", fg="red"))
            sys.exit(1)
        click.echo(f"  Agent image not found. Building {image}...")
        shypmate_dir = os.path.dirname(os.path.abspath(__file__))
        result = subprocess.run(["docker", "build", "-t", image, shypmate_dir])
        if result.returncode != 0:
            click.echo(click.style("  FAIL: Docker build failed", fg="red"))
            sys.exit(1)
        click.echo(click.style("  Build: OK", fg="green"))
    click.echo("")

    # ── Step 3: Launch verify container ──
    verify_task = task or "Read the README or main project file and write a one-paragraph summary to SUMMARY.md. Do NOT push to GitHub or create a PR."
    container_name = "shypmate-verify"

    click.echo(click.style("Launching verify agent...", bold=True))
    click.echo(f"  Task: {verify_task[:80]}")
    click.echo(f"  LLM:  {provider_label} / {llm_entry.model}")
    click.echo("")

    # Remove old verify container if exists
    try:
        old = client.containers.get(container_name)
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    # Build env vars — similar to _launch_agent_container but simplified
    env = {
        "GITHUB_TOKEN": github_token,
        "GITHUB_REPO": PROJECT.github_repo,
        "AGENT_TASK": verify_task,
        "AGENT_BRANCH": "shypmate/verify-test",
        "AGENT_ID": "verify",
        "AGENT_REBASE": "false",
        "BASE_BRANCH": PROJECT.base_branch,
        "INSTALL_COMMAND": "",  # skip dependency install for speed
        "LLM_PROVIDER": llm_entry.provider,
        "LLM_MODEL": llm_entry.model,
        "LLM_MAX_TOKENS": str(llm_entry.max_tokens),
    }
    if llm_entry.api_key_var and llm_api_key:
        env[llm_entry.api_key_var] = llm_api_key
    if llm_entry.base_url:
        env["LLM_BASE_URL"] = llm_entry.base_url

    # Run in foreground (not detached)
    try:
        click.echo("--- Agent Output ---")
        click.echo("")
        container = client.containers.run(
            image=image,
            name=container_name,
            environment=env,
            detach=False,
            remove=False,
            stdout=True,
            stderr=True,
        )

        # container is bytes in non-detach mode
        if isinstance(container, bytes):
            output = container.decode("utf-8", errors="replace")
            for line in output.splitlines():
                safe_line = line.encode("ascii", errors="replace").decode("ascii")
                click.echo(f"  {safe_line}")

        click.echo("")

        # Check exit code
        try:
            c = client.containers.get(container_name)
            exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
            c.remove(force=True)
        except Exception:
            exit_code = 0  # container was auto-removed

        if exit_code == 0:
            click.echo(click.style("=== Verify PASSED ===", fg="green", bold=True))
            click.echo("  Your shypmate setup is working end-to-end.")
            click.echo("  Next: 'shypmate task add \"your task\"' then 'shypmate work'")
        else:
            click.echo(click.style(f"=== Verify FAILED (exit code {exit_code}) ===", fg="red", bold=True))
            click.echo("  Check the output above for errors.")
            sys.exit(1)

    except docker.errors.ImageNotFound:
        click.echo(click.style(f"  FAIL: Image '{image}' not found", fg="red"))
        sys.exit(1)
    except docker.errors.APIError as e:
        click.echo(click.style(f"  FAIL: Docker error: {e}", fg="red"))
        sys.exit(1)
    except KeyboardInterrupt:
        click.echo("\n  Interrupted. Cleaning up...")
        try:
            c = client.containers.get(container_name)
            c.remove(force=True)
        except Exception:
            pass


# ── Build ───────────────────────────────────────────────────

@cli.command()
@click.option("--no-cache", is_flag=True, help="Build without Docker cache.")
def build(no_cache: bool):
    """Build the agent Docker image."""
    import subprocess

    shypmate_dir = os.path.dirname(os.path.abspath(__file__))
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"

    click.echo(f"Building agent image: {image}")
    cmd = ["docker", "build", "-t", image, shypmate_dir]
    if no_cache:
        cmd.insert(3, "--no-cache")

    result = subprocess.run(cmd)
    if result.returncode == 0:
        click.echo(f"\nImage built: {image}")
    else:
        click.echo("\nBuild failed.", err=True)
        sys.exit(1)


@cli.command("build-monitor")
@click.option("--no-cache", is_flag=True, help="Build without Docker cache.")
def build_monitor(no_cache: bool):
    """Build the PR monitor Docker image."""
    import subprocess

    monitor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "monitor")
    image = f"{PROJECT.monitor_image_name}:{PROJECT.monitor_image_tag}"

    click.echo(f"Building monitor image: {image}")
    cmd = ["docker", "build", "-t", image, monitor_dir]
    if no_cache:
        cmd.insert(3, "--no-cache")

    result = subprocess.run(cmd)
    if result.returncode == 0:
        click.echo(f"\nImage built: {image}")
    else:
        click.echo("\nBuild failed.", err=True)
        sys.exit(1)


# ── Start / Stop (Manager) ─────────────────────────────────

@cli.command()
@click.option("--poll-interval", default=None, type=int, help="Poll interval in seconds.")
def start(poll_interval: int | None):
    """Start the shypmate manager.

    The manager runs as a persistent container that:
    - Generates a project brief (one LLM call, shared with all agents)
    - Analyzes all pending tasks and produces a wave execution plan
    - Launches agents wave-by-wave: parallel within waves, sequential across
    - Detects new tasks added mid-run and slots them into the plan
    - Re-analyzes after each wave completes (repo has changed)
    - Monitors PRs and cleans up merged containers
    - Refreshes the brief when the base branch advances
    """
    from shypmate.config.project import get_pool_entry, get_llm_pool, LLM_PROVIDER_PRESETS

    github_token, llm_api_key = _validate_env()

    client = _get_docker_client()
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"

    # Auto-build image if needed
    try:
        client.images.get(image)
    except docker.errors.ImageNotFound:
        import subprocess
        click.echo(f"Agent image not found. Building {image}...")
        shypmate_dir = os.path.dirname(os.path.abspath(__file__))
        result = subprocess.run(["docker", "build", "-t", image, shypmate_dir])
        if result.returncode != 0:
            click.echo("Build failed.", err=True)
            sys.exit(1)

    # Create the shared brief volume
    try:
        client.volumes.get(BRIEF_VOLUME)
    except docker.errors.NotFound:
        client.volumes.create(BRIEF_VOLUME)
        click.echo(f"Created volume: {BRIEF_VOLUME}")

    # Remove old manager if exists
    try:
        old = client.containers.get(MANAGER_CONTAINER)
        click.echo("Stopping old manager...")
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    llm_entry = get_pool_entry(PROJECT, 0)
    provider_label = LLM_PROVIDER_PRESETS.get(llm_entry.provider, {}).get("label", llm_entry.provider)

    # Build comms and data directories
    comms_dir = str(_get_comms_dir()).replace("\\", "/")
    data_dir = os.path.join(PROJECT.project_root, ".shypmate").replace("\\", "/")
    os.makedirs(data_dir, exist_ok=True)

    # Task file path (host-side, bind-mounted into manager)
    task_file_dir = PROJECT.project_root.replace("\\", "/")

    env = {
        "GITHUB_TOKEN": github_token,
        "GITHUB_REPO": PROJECT.github_repo,
        "BASE_BRANCH": PROJECT.base_branch,
        "POLL_INTERVAL": str(poll_interval or PROJECT.monitor_poll_interval_seconds),
        "LLM_PROVIDER": llm_entry.provider,
        "LLM_MODEL": llm_entry.model,
        "LLM_MAX_TOKENS": str(llm_entry.max_tokens),
        # Wave planning config
        "TASK_EXECUTION": PROJECT.task_execution,
        "BRANCH_PREFIX": PROJECT.branch_prefix,
        "INSTALL_COMMAND": PROJECT.install_command,
        "AGENT_IMAGE": f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}",
        "DOCKER_NETWORK": PROJECT.docker_network,
        "BRIEF_VOLUME": BRIEF_VOLUME,
        "COMMS_DIR": comms_dir,
        "SHYPMATE_MEMORY_MAX_ENTRIES": str(PROJECT.memory_max_entries),
        "SHYPMATE_MEMORY_MAX_SIZE": str(PROJECT.memory_max_size),
    }
    if PROJECT.sdlc:
        env["SDLC_PROMPT"] = PROJECT.sdlc
    if llm_entry.api_key_var:
        env["LLM_API_KEY_VAR"] = llm_entry.api_key_var
        if llm_api_key:
            env[llm_entry.api_key_var] = llm_api_key
    if llm_entry.base_url:
        env["LLM_BASE_URL"] = llm_entry.base_url

    # Pass full LLM pool as JSON so manager can assign different providers to agents
    pool = get_llm_pool(PROJECT)
    if pool:
        from dataclasses import asdict
        pool_data = [asdict(e) for e in pool]
        env["LLM_POOL_JSON"] = json.dumps(pool_data)
        # Pass all API keys from the pool
        for entry in pool:
            if entry.api_key_var:
                key_val = os.environ.get(entry.api_key_var, "") or _read_env_file_var(entry.api_key_var)
                if key_val:
                    env[entry.api_key_var] = key_val

    try:
        container = client.containers.run(
            image=image,
            name=MANAGER_CONTAINER,
            environment=env,
            entrypoint=["python", "-m", "shypmate.manager.manager"],
            volumes={
                BRIEF_VOLUME: {"bind": "/brief", "mode": "rw"},
                "/var/run/docker.sock": {"bind": "/var/run/docker.sock", "mode": "rw"},
                task_file_dir: {"bind": "/tasks", "mode": "rw"},
                data_dir: {"bind": "/shypmate-data", "mode": "rw"},
                comms_dir: {"bind": "/comms", "mode": "rw"},
            },
            network=PROJECT.docker_network,
            detach=True,
            restart_policy={"Name": "unless-stopped"},
        )
        click.echo(f"\nManager started: {container.short_id}")
        click.echo(f"  LLM: {provider_label} / {llm_entry.model}")
        click.echo(f"  Execution mode: {PROJECT.task_execution}")
        click.echo(f"  Brief volume: {BRIEF_VOLUME}")
        click.echo(f"  Poll interval: {poll_interval or PROJECT.monitor_poll_interval_seconds}s")
        click.echo(f"\n  Follow logs: docker logs -f {MANAGER_CONTAINER}")
        click.echo(f"  Stop: shypmate stop")
    except docker.errors.APIError as e:
        click.echo(f"Docker error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option("--remove-volume", is_flag=True, help="Also remove the shared brief volume.")
def stop(remove_volume: bool):
    """Stop the shypmate manager and optionally clean up."""
    client = _get_docker_client()

    try:
        container = client.containers.get(MANAGER_CONTAINER)
        container.remove(force=True)
        click.echo("Manager stopped.")
    except docker.errors.NotFound:
        click.echo("Manager is not running.")

    if remove_volume:
        try:
            vol = client.volumes.get(BRIEF_VOLUME)
            vol.remove()
            click.echo(f"Removed volume: {BRIEF_VOLUME}")
        except docker.errors.NotFound:
            pass


# ── Monitor (legacy — use start/stop instead) ─────────────

@cli.command("monitor-start")
@click.option("--interval", default=None, type=int, help="Poll interval in seconds.")
def monitor_start(interval: int | None):
    """Start the PR monitor container."""
    github_token, llm_api_key = _validate_env()

    client = _get_docker_client()
    container_name = "shypmate-monitor"
    image = f"{PROJECT.monitor_image_name}:{PROJECT.monitor_image_tag}"

    env = {
        "GITHUB_TOKEN": github_token,
        "GITHUB_REPO": PROJECT.github_repo,
        "BASE_BRANCH": PROJECT.base_branch,
        "POLL_INTERVAL": str(interval or PROJECT.monitor_poll_interval_seconds),
        "DOCKER_NETWORK": PROJECT.docker_network,
        "AGENT_IMAGE": f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}",
        "LLM_PROVIDER": PROJECT.llm_provider,
        "LLM_MODEL": PROJECT.llm_model,
    }
    # Pass the LLM API key for monitor's own re-spawn capability
    if PROJECT.llm_api_key_var and llm_api_key:
        env[PROJECT.llm_api_key_var] = llm_api_key

    try:
        old = client.containers.get(container_name)
        click.echo("Stopping old monitor...")
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    try:
        container = client.containers.run(
            image=image,
            name=container_name,
            environment=env,
            volumes={"/var/run/docker.sock": {"bind": "/var/run/docker.sock", "mode": "rw"}},
            network=PROJECT.docker_network,
            detach=True,
            restart_policy={"Name": "unless-stopped"},
        )
        click.echo(f"Monitor started: {container.short_id}")
        click.echo(f"  Follow logs: docker logs -f {container_name}")
    except docker.errors.ImageNotFound:
        click.echo(f"\nImage '{image}' not found. Run: python -m shypmate build-monitor", err=True)
        sys.exit(1)
    except docker.errors.APIError as e:
        click.echo(f"\nDocker error: {e}", err=True)
        sys.exit(1)


@cli.command("monitor-stop")
def monitor_stop():
    """Stop the PR monitor container."""
    client = _get_docker_client()
    try:
        container = client.containers.get("shypmate-monitor")
        container.remove(force=True)
        click.echo("Monitor stopped.")
    except docker.errors.NotFound:
        click.echo("Monitor is not running.")


# ── Agent listing ───────────────────────────────────────────

@cli.command("list-agents")
@click.option("--all", "show_all", is_flag=True, help="Include exited containers.")
def list_agents(show_all: bool):
    """List agent containers."""
    client = _get_docker_client()
    containers = client.containers.list(all=show_all, filters={"name": "shypmate-"})
    if not containers:
        click.echo("No agent containers found." + (" Try --all to include exited." if not show_all else ""))
        return

    click.echo("")
    click.echo(f"  {'NAME':<30} {'STATUS':<15} {'ID':<12} TASK")
    click.echo(f"  {'----':<30} {'------':<15} {'--':<12} ----")
    for c in containers:
        task_desc = _get_container_env(c, "AGENT_TASK")[:40]
        click.echo(f"  {c.name:<30} {c.status:<15} {c.short_id:<12} {task_desc}")
    click.echo("")


# ── Container env helper ────────────────────────────────────

def _get_container_env(container, key: str) -> str:
    """Extract an environment variable value from a container's config."""
    try:
        for env in container.attrs.get("Config", {}).get("Env", []):
            if env.startswith(f"{key}="):
                return env.split("=", 1)[1]
    except Exception:
        pass
    return ""


def _find_container(identifier: str):
    """Find a container by agent ID, task ID, or container name."""
    client = _get_docker_client()
    container_name = identifier if identifier.startswith("shypmate-") else f"shypmate-{identifier}"

    # Try direct name match
    try:
        return client.containers.get(container_name)
    except docker.errors.NotFound:
        pass

    # Try matching by task ID in the task queue
    try:
        from shypmate.task_manager import get_task
        task = get_task(identifier)
        if task and task.get("agent_id"):
            agent_name = f"shypmate-{task['agent_id']}"
            try:
                return client.containers.get(agent_name)
            except docker.errors.NotFound:
                pass
    except Exception:
        pass

    # Try fuzzy match across all containers
    all_containers = client.containers.list(all=True, filters={"name": "shypmate-"})
    for c in all_containers:
        if identifier in c.name:
            return c
        if identifier in _get_container_env(c, "AGENT_TASK"):
            return c

    return None


# ── Human Input (inbox / respond) ──────────────────────────

def _find_waiting_agents() -> list[dict]:
    """Scan running shypmate containers for agents waiting on human input.

    Checks the last 50 lines of each container's logs for the HUMAN_INPUT marker.
    If found and no response file exists, the agent is waiting.
    """
    client = _get_docker_client()
    waiting = []

    containers = client.containers.list(filters={"name": "shypmate-", "status": "running"})
    comms = _get_comms_dir()
    responses_dir = comms / "responses"

    for c in containers:
        if c.name in (MANAGER_CONTAINER, "shypmate-verify"):
            continue

        try:
            logs = c.logs(tail=100).decode("utf-8", errors="replace")
        except Exception:
            continue

        if HUMAN_INPUT_MARKER not in logs:
            continue

        # Parse request details from the logs.
        # The agent writes the request to a file AND logs it. Read the file
        # for the full untruncated data, fall back to log parsing.
        agent_id = _get_container_env(c, "AGENT_ID")
        task = _get_container_env(c, "AGENT_TASK")
        question = ""
        context = ""
        request_id = ""

        # Try reading the request file first (has full untruncated content)
        comms = _get_comms_dir()
        requests_dir = comms / "requests"
        if requests_dir.exists():
            for req_file in sorted(requests_dir.glob(f"{agent_id}-*.json"), reverse=True):
                try:
                    data = json.loads(req_file.read_text(encoding="utf-8"))
                    question = data.get("question", "")
                    context = data.get("context", "")
                    request_id = data.get("id", "")
                    break
                except Exception:
                    pass

        # Fall back to log parsing if no request file found
        if not request_id:
            lines = logs.splitlines()
            for i, line in enumerate(lines):
                if "Request:" in line and "HTTP" not in line and "Request:" in line.split("]")[-1]:
                    request_id = line.split("Request:", 1)[-1].strip()
                elif "Question:" in line and HUMAN_INPUT_MARKER not in line:
                    # Capture everything after "Question:" — may be multi-line
                    question = line.split("Question:", 1)[-1].strip()
                elif "Context:" in line and "PROJECT CONTEXT" not in line and "context_files" not in line:
                    context = line.split("Context:", 1)[-1].strip()

        if not request_id:
            continue

        # Check if already responded
        if responses_dir.exists() and (responses_dir / f"{request_id}.json").exists():
            continue

        waiting.append({
            "container": c.name,
            "agent_id": agent_id,
            "task": task,
            "question": question,
            "context": context,
            "request_id": request_id,
        })

    return waiting


@cli.command()
def inbox():
    """Show agents waiting for human input.

    Scans running agent containers for pending questions.
    No stale requests — if the container is gone, the request is gone.
    """
    waiting = _find_waiting_agents()

    if not waiting:
        click.echo("No agents waiting for input.")
        return

    click.echo(f"\n{len(waiting)} agent(s) waiting for input:\n")
    for req in waiting:
        click.echo(click.style(f"  [{req['request_id']}]", fg="yellow", bold=True))
        click.echo(f"    Container: {req['container']}")
        click.echo(f"    Agent:     {req['agent_id']}")
        click.echo(f"    Task:      {req['task']}")
        click.echo(f"    Question:")
        # Print question with wrapping so nothing is cut off
        for line in req["question"].splitlines():
            click.echo(f"      {line}")
        if req["context"]:
            click.echo(f"    Context:")
            for line in req["context"].splitlines():
                click.echo(f"      {line}")
        click.echo("")

    click.echo("Respond with: shypmate respond <request-id> \"your answer\"")


@cli.command()
@click.argument("request_id")
@click.argument("response_text")
def respond(request_id: str, response_text: str):
    """Respond to an agent's human input request.

    REQUEST_ID is the request identifier shown by 'shypmate inbox'.
    RESPONSE_TEXT is your answer to the agent's question.
    """
    from pathlib import Path

    comms = _get_comms_dir()
    responses_dir = comms / "responses"
    responses_dir.mkdir(parents=True, exist_ok=True)

    response_data = {
        "response": response_text,
        "responded_at": datetime.now(timezone.utc).isoformat(),
    }

    response_path = responses_dir / f"{request_id}.json"
    response_path.write_text(json.dumps(response_data, indent=2), encoding="utf-8")
    click.echo(f"Response sent to {request_id}. Agent will continue.")


# ── Pipeline (hats) ────────────────────────────────────────

@cli.command("pipeline")
@click.argument("task_id", required=False)
def pipeline_status(task_id: str | None):
    """Show pipeline status for a task, or all active pipelines.

    Each task progresses through hats (developer → QA → product owner).
    """
    from shypmate.hats.pipeline import load_pipeline

    comms = _get_comms_dir()
    pipelines_dir = comms / "pipelines"

    if task_id:
        pipeline = load_pipeline(task_id, comms)
        if pipeline:
            click.echo(pipeline.summary())
        else:
            click.echo(f"No pipeline found for task: {task_id}")
        return

    # Show all pipelines
    if not pipelines_dir.exists():
        click.echo("No active pipelines.")
        return

    pipeline_files = sorted(pipelines_dir.glob("*.json"))
    if not pipeline_files:
        click.echo("No active pipelines.")
        return

    for pf in pipeline_files:
        tid = pf.stem
        pipeline = load_pipeline(tid, comms)
        if pipeline:
            click.echo(pipeline.summary())
            click.echo("")


@cli.command("run-pipeline")
@click.option("--task", "-t", required=True, help="Task description.")
@click.option("--hats", "-h", default="developer,qa", help="Comma-separated hat names to run (default: developer,qa).")
@click.option("--dev/--no-dev", default=None, help="Dev mode.")
def run_pipeline(task: str, hats: str, dev: bool | None):
    """Run a task through the hat pipeline in a single container.

    All hats run sequentially in one container — no duplicate cloning or installs.
    The container switches prompts and tools between hats.
    PR is opened only after all hats pass.
    """
    from shypmate.hats.coordinator import load_hats_from_config

    github_token, llm_api_key = _validate_env()

    # Validate requested hats
    all_hats = load_hats_from_config()
    requested = [h.strip() for h in hats.split(",")]
    for name in requested:
        if name not in all_hats:
            click.echo(f"Unknown hat: {name}. Available: {', '.join(all_hats.keys())}")
            return

    # Generate IDs
    agent_id = _generate_agent_id(task)
    branch = _generate_branch_name(task, agent_id)

    # Get SDLC prompt
    sdlc_prompt = PROJECT.sdlc or ""

    click.echo(f"\nPipeline: {agent_id}")
    click.echo(f"  Task:   {task[:70]}")
    click.echo(f"  Branch: {branch}")
    click.echo(f"  Hats:   {' → '.join(requested)}")
    click.echo(f"  Mode:   single container")
    click.echo("")

    # Launch ONE container with PIPELINE_HATS env var
    # The entrypoint detects this and runs hats sequentially
    result = _launch_agent_container(
        task=task,
        agent_id=agent_id,
        branch=branch,
        github_token=github_token,
        detach=False,
        dev_mode=dev,
        pipeline_hats=",".join(requested),
        sdlc_prompt=sdlc_prompt,
    )

    click.echo("")


# ── Memory management ──────────────────────────────────────

@cli.group()
def memory():
    """Manage shared agent memory."""
    pass


@memory.command("list")
@click.option("--category", "-c", default="", help="Filter by category (lesson, pattern, decision, context).")
def memory_list(category: str):
    """Show all shared agent memories."""
    from pathlib import Path

    mem_file = _get_comms_dir() / "memory" / "agent_memory.json"
    if not mem_file.exists():
        click.echo("No shared memories yet. Agents will start building memory as they work.")
        return

    try:
        entries = json.loads(mem_file.read_text(encoding="utf-8"))
    except Exception:
        click.echo("Memory file is corrupted. Run 'shypmate memory reset' to clear.")
        return

    if category:
        entries = [e for e in entries if e.get("category") == category]

    if not entries:
        click.echo(f"No memories found" + (f" for category '{category}'" if category else "") + ".")
        return

    click.echo(f"\nShared agent memory ({len(entries)} entries):\n")
    for e in entries:
        pin = click.style(" [PINNED]", fg="yellow") if e.get("pinned") else ""
        cat = click.style(f"[{e.get('category', '?')}]", fg="cyan")
        click.echo(f"  {cat}{pin} {e.get('fact', '?')}")
        click.echo(click.style(f"    agent: {e.get('agent_id', '?')}  task: {e.get('task', '?')[:50]}  date: {e.get('created_at', '?')[:10]}", fg="bright_black"))
        click.echo("")

    mem_size = mem_file.stat().st_size
    click.echo(click.style(f"  Size: {mem_size:,} bytes / {int(os.environ.get('SHYPMATE_MEMORY_MAX_SIZE', 8192)):,} max", fg="bright_black"))


@memory.command("reset")
@click.confirmation_option(prompt="This will delete all shared agent memories. Continue?")
def memory_reset():
    """Clear all shared agent memories."""
    mem_file = _get_comms_dir() / "memory" / "agent_memory.json"
    if mem_file.exists():
        mem_file.unlink()
    click.echo("Shared agent memory cleared.")


@memory.command("add")
@click.argument("fact")
@click.option("--category", "-c", default="pattern", type=click.Choice(["lesson", "pattern", "decision", "context"]))
@click.option("--pin", is_flag=True, help="Pin this memory so it won't be auto-evicted.")
def memory_add(fact: str, category: str, pin: bool):
    """Manually add a memory entry.

    FACT is the lesson or pattern to save.
    """
    from pathlib import Path

    mem_dir = _get_comms_dir() / "memory"
    mem_dir.mkdir(parents=True, exist_ok=True)
    mem_file = mem_dir / "agent_memory.json"

    entries = []
    if mem_file.exists():
        try:
            entries = json.loads(mem_file.read_text(encoding="utf-8"))
        except Exception:
            entries = []

    entries.append({
        "fact": fact,
        "category": category,
        "pinned": pin,
        "agent_id": "human",
        "task": "manual entry",
        "created_at": datetime.now(timezone.utc).isoformat(),
    })

    mem_file.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    pin_label = " [PINNED]" if pin else ""
    click.echo(f"Added [{category}]{pin_label}: {fact}")


@memory.command("remove")
@click.argument("substring")
def memory_remove(substring: str):
    """Remove memory entries matching a substring."""
    mem_file = _get_comms_dir() / "memory" / "agent_memory.json"
    if not mem_file.exists():
        click.echo("No memories to remove.")
        return

    try:
        entries = json.loads(mem_file.read_text(encoding="utf-8"))
    except Exception:
        click.echo("Memory file is corrupted.")
        return

    sub_lower = substring.lower()
    original = len(entries)
    entries = [e for e in entries if sub_lower not in e.get("fact", "").lower()]
    removed = original - len(entries)

    if removed:
        mem_file.write_text(json.dumps(entries, indent=2), encoding="utf-8")
        click.echo(f"Removed {removed} entry(ies) matching '{substring}'.")
    else:
        click.echo(f"No entries matching '{substring}'.")


# ── Logs shortcut ───────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--follow", "-f", is_flag=True, help="Follow log output.")
@click.option("--tail", "-n", default=50, help="Number of lines to show (default: 50).")
def logs(identifier: str, follow: bool, tail: int):
    """Show logs for an agent container.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    import subprocess

    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    cmd = ["docker", "logs", f"--tail={tail}"]
    if follow:
        cmd.append("-f")
    cmd.append(container.name)

    click.echo(f"Showing logs for: {container.name} ({container.status})")
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


# ── Review ──────────────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--logs-lines", "-n", default=30, help="Number of log lines to show (default: 30).")
def review(identifier: str, logs_lines: int):
    """Review an agent's work — show its task, branch, status, and recent logs.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    # Extract metadata from container env
    task_desc = _get_container_env(container, "AGENT_TASK")
    agent_id = _get_container_env(container, "AGENT_ID")
    branch = _get_container_env(container, "AGENT_BRANCH")
    is_rebase = _get_container_env(container, "AGENT_REBASE")

    exit_code = container.attrs.get("State", {}).get("ExitCode", "?")
    started = container.attrs.get("State", {}).get("StartedAt", "?")[:19]
    finished = container.attrs.get("State", {}).get("FinishedAt", "?")[:19]

    click.echo("")
    click.echo("=" * 60)
    click.echo(f"  Agent Review: {container.name}")
    click.echo("=" * 60)
    click.echo(f"  Status:    {container.status}" + (f" (exit code: {exit_code})" if container.status == "exited" else ""))
    click.echo(f"  Agent ID:  {agent_id}")
    click.echo(f"  Task:      {task_desc}")
    click.echo(f"  Branch:    {branch}")
    click.echo(f"  Rebase:    {is_rebase}")
    click.echo(f"  Started:   {started}")
    if container.status == "exited":
        click.echo(f"  Finished:  {finished}")

    # Check if there's a matching task in the queue
    try:
        from shypmate.task_manager import list_tasks
        for t in list_tasks():
            if t.get("agent_id") == agent_id:
                click.echo(f"  Task ID:   {t['id']}")
                click.echo(f"  Priority:  {t.get('priority', '?')}")
                if t.get("pr_url"):
                    click.echo(f"  PR:        {t['pr_url']}")
                break
    except Exception:
        pass

    click.echo("")
    click.echo(f"  Recent Logs (last {logs_lines} lines):")
    click.echo("  " + "-" * 50)

    try:
        log_bytes = container.logs(tail=logs_lines)
        log_output = log_bytes.decode("utf-8", errors="replace")
        for line in log_output.splitlines():
            # Sanitize box-drawing chars that fail on Windows consoles
            safe_line = line.encode("ascii", errors="replace").decode("ascii")
            click.echo(f"  {safe_line}")
    except Exception as e:
        click.echo(f"  (could not read logs: {e})")

    click.echo("")
    click.echo("  Commands:")
    click.echo(f"    retry {agent_id}          - re-launch this agent")
    click.echo(f"    logs {agent_id} -f        - follow full logs")
    click.echo("")


# ── Retry ───────────────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--no-detach", is_flag=True, help="Run in foreground.")
def retry(identifier: str, no_detach: bool):
    """Re-launch an agent with its original task and branch.

    The agent picks up the same branch and can address PR feedback,
    fix issues, or continue where it left off.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    if container.status == "running":
        click.echo(f"Agent {container.name} is still running. Stop it first or wait for it to finish.")
        sys.exit(1)

    # Extract original context
    task_desc = _get_container_env(container, "AGENT_TASK")
    agent_id = _get_container_env(container, "AGENT_ID")
    branch = _get_container_env(container, "AGENT_BRANCH")
    base_branch = _get_container_env(container, "BASE_BRANCH")

    if not task_desc or not agent_id or not branch:
        click.echo("Could not recover task context from container. Missing AGENT_TASK, AGENT_ID, or AGENT_BRANCH.", err=True)
        sys.exit(1)

    github_token, llm_api_key = _validate_env()

    click.echo(f"Retrying agent '{agent_id}'")
    click.echo(f"  Task:   {task_desc[:80]}")
    click.echo(f"  Branch: {branch}")
    click.echo(f"  (re-using existing branch — agent will pick up where it left off)")

    # Remove the old container so we can reuse the name
    try:
        container.remove(force=True)
        click.echo(f"  Removed old container: {container.name}")
    except Exception:
        pass

    # Update task status if tracked
    try:
        from shypmate.task_manager import list_tasks, mark_running
        for t in list_tasks():
            if t.get("agent_id") == agent_id:
                mark_running(t["id"], agent_id, branch)
                break
    except Exception:
        pass

    result = _launch_agent_container(
        task=task_desc,
        agent_id=agent_id,
        branch=branch,
        github_token=github_token,
        base_branch=base_branch or None,
        detach=not no_detach,
    )

    if result:
        click.echo(f"\nContainer restarted: {result}")
        click.echo(f"  Follow logs: docker logs -f shypmate-{agent_id}")
    elif not no_detach:
        sys.exit(1)
    else:
        click.echo("\nAgent finished.")


# ── Clean ───────────────────────────────────────────────────

@cli.command()
@click.option("--all", "clean_all", is_flag=True, help="Remove ALL exited agent containers.")
@click.option("--dry-run", is_flag=True, help="Show what would be removed without removing.")
def clean(clean_all: bool, dry_run: bool):
    """Remove exited agent containers.

    By default, only removes containers whose PRs are merged or closed.
    Use --all to remove all exited containers regardless of PR status.
    """
    client = _get_docker_client()
    containers = client.containers.list(all=True, filters={"name": "shypmate-", "status": "exited"})

    if not containers:
        click.echo("No exited agent containers to clean.")
        return

    # Optionally check PR status for selective cleanup
    gh = None
    repo = None
    if not clean_all:
        try:
            from github import Github
            token = os.environ.get("GITHUB_TOKEN", "")
            if token and PROJECT.github_repo:
                gh = Github(token)
                repo = gh.get_repo(PROJECT.github_repo)
        except Exception:
            click.echo("Warning: Could not connect to GitHub. Use --all to force cleanup.", err=True)
            return

    to_remove = []
    to_keep = []

    for c in containers:
        # Skip the monitor container
        if c.name == "shypmate-monitor":
            continue

        branch = _get_container_env(c, "AGENT_BRANCH")
        agent_id = _get_container_env(c, "AGENT_ID")
        task_desc = _get_container_env(c, "AGENT_TASK")[:50]

        if clean_all:
            to_remove.append((c, "exited", task_desc))
            continue

        # Check if the PR for this branch is merged or closed
        if repo and branch:
            try:
                pr_merged_or_closed = False
                for pr in repo.get_pulls(state="all", head=f"{repo.owner.login}:{branch}"):
                    if pr.merged or pr.state == "closed":
                        pr_merged_or_closed = True
                        break

                if pr_merged_or_closed:
                    to_remove.append((c, "PR merged/closed", task_desc))
                else:
                    to_keep.append((c, "PR still open", task_desc))
            except Exception:
                to_keep.append((c, "could not check PR", task_desc))
        else:
            # No branch info — check if it failed (no PR created)
            exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
            if exit_code != 0:
                to_remove.append((c, "failed (no PR)", task_desc))
            else:
                to_keep.append((c, "unknown status", task_desc))

    if to_remove:
        click.echo(f"\n{'Would remove' if dry_run else 'Removing'} {len(to_remove)} container(s):\n")
        for c, reason, task_desc in to_remove:
            click.echo(f"  {c.name:<30} {reason:<20} {task_desc}")
            if not dry_run:
                try:
                    c.remove()
                except Exception as e:
                    click.echo(f"    Error: {e}")

        # Also clean up done/failed tasks in the queue
        if not dry_run:
            try:
                from shypmate.task_manager import list_tasks, remove_task
                done_tasks = [t for t in list_tasks() if t.get("status") in ("done", "failed")]
                for t in done_tasks:
                    agent_id = t.get("agent_id", "")
                    # Only remove task if its container was removed
                    if any(agent_id and agent_id in c.name for c, _, _ in to_remove):
                        remove_task(t["id"])
            except Exception:
                pass
    else:
        click.echo("\nNothing to clean.")

    if to_keep:
        click.echo(f"\n  Keeping {len(to_keep)} container(s) (PR still open or status unknown):")
        for c, reason, task_desc in to_keep:
            click.echo(f"  {c.name:<30} {reason:<20} {task_desc}")

    click.echo("")


@cli.command("test-loop")
@click.option("--provider", "-p", default=None, help="LLM provider (default: from config)")
@click.option("--model", "-m", default=None, help="Model name (default: from config)")
@click.option("--max-tokens", default=None, type=int, help="Max tokens per LLM call")
@click.option("--task", "-t", default=None, help="Custom task description")
@click.option("--mock", is_flag=True, help="Use mock LLM (no API key needed)")
@click.option("--keep-workspace", is_flag=True, help="Keep temp workspace after test")
@click.option("--verbose", "-v", is_flag=True, help="Verbose logging")
def test_loop(provider, model, max_tokens, task, mock, keep_workspace, verbose):
    """Run an internal agent loop test (no Docker, no GitHub).

    Uses the LLM provider from your shypmate config by default.
    Quick way to verify your setup after 'shypmate init'.
    """
    import logging

    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # tests/ is at the repo root, not inside the shypmate package
    import importlib.util
    from pathlib import Path
    test_path = Path(PROJECT.project_root) / "tests" / "test_loop.py"
    if not test_path.exists():
        # Fallback: try relative to cwd
        test_path = Path("tests") / "test_loop.py"
    if not test_path.exists():
        click.echo("Error: tests/test_loop.py not found. This command must be run from the shypmate repo root.", err=True)
        sys.exit(1)
    spec = importlib.util.spec_from_file_location("test_loop", str(test_path))
    test_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(test_mod)
    run_loop_test = test_mod.run_loop_test

    # Use config defaults if not specified on command line
    use_provider = provider or PROJECT.llm_provider
    use_model = model or PROJECT.llm_model
    use_max_tokens = max_tokens or PROJECT.llm_max_tokens

    # Ensure API key is available from .env
    if not mock:
        api_key_var = PROJECT.llm_api_key_var
        if api_key_var and not os.environ.get(api_key_var):
            key_val = _read_env_file_var(api_key_var)
            if key_val:
                os.environ[api_key_var] = key_val

        # Also set base_url if configured
        if PROJECT.llm_base_url and not os.environ.get("LLM_BASE_URL"):
            os.environ["LLM_BASE_URL"] = PROJECT.llm_base_url

    click.echo("\n=== Shypmate Loop Test ===\n")
    if not mock:
        from shypmate.config.project import LLM_PROVIDER_PRESETS
        label = LLM_PROVIDER_PRESETS.get(use_provider, {}).get("label", use_provider)
        click.echo(f"  Provider: {label}")
        click.echo(f"  Model:    {use_model}")
        click.echo("")

    result = run_loop_test(
        provider_name=use_provider,
        model=use_model,
        max_tokens=use_max_tokens,
        task=task,
        mock=mock,
        keep_workspace=keep_workspace,
    )

    click.echo(f"\n{result}\n")

    if result.agent_output:
        click.echo("--- Agent Output ---")
        click.echo(result.agent_output[:1000])
        click.echo("")

    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    cli()
