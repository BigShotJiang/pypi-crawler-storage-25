#!/usr/bin/env python
"""
Run the loop test directly from the project directory.

Usage:
    python tests/run_loop_test.py              # mock mode (no API key)
    python tests/run_loop_test.py --live       # real LLM call
    python tests/run_loop_test.py --provider openai --model gpt-4o
"""

import argparse
import logging
import os
import sys

# Make "import shypmate" resolve to src/ without pip install
_repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_src_dir = os.path.join(_repo_root, "src")
sys.path.insert(0, _repo_root)
sys.path.insert(0, _src_dir)

# Register src/ as the "shypmate" package so imports like "from shypmate.engine" work
import importlib
import types
shypmate_pkg = types.ModuleType("shypmate")
shypmate_pkg.__path__ = [_src_dir]
shypmate_pkg.__file__ = os.path.join(_src_dir, "__init__.py")
sys.modules["shypmate"] = shypmate_pkg


def main():
    parser = argparse.ArgumentParser(description="Shypmate internal loop test")
    parser.add_argument("--provider", default="anthropic", help="LLM provider (anthropic, openai)")
    parser.add_argument("--model", default=None, help="Model name (default: auto)")
    parser.add_argument("--max-tokens", type=int, default=4096, help="Max tokens per LLM call")
    parser.add_argument("--task", default=None, help="Custom task description")
    parser.add_argument("--live", action="store_true", help="Use real LLM (requires API key)")
    parser.add_argument("--keep-workspace", action="store_true", help="Keep temp workspace")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    from tests.test_loop import run_loop_test

    print("\n=== Shypmate Loop Test ===\n")

    result = run_loop_test(
        provider_name=args.provider,
        model=args.model,
        max_tokens=args.max_tokens,
        task=args.task,
        mock=not args.live,
        keep_workspace=args.keep_workspace,
    )

    print(f"\n{result}\n")

    if result.agent_output:
        print("--- Agent Output ---")
        print(result.agent_output[:1000])
        print()

    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
