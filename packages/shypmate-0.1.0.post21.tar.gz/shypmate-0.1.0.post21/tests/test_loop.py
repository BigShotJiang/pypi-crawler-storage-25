"""
Internal loop test — exercises the full agent cycle without Docker or GitHub.

Sets up a temporary git repo with a simple Python file, runs the agent loop
with a real LLM, and verifies the agent made changes and committed.

Usage:
    python -m shypmate test-loop                    # default: simple task
    python -m shypmate test-loop --provider openai  # test with OpenAI
    python -m shypmate test-loop --task "..."       # custom task
    python -m shypmate test-loop --mock             # mock LLM (no API key needed)
"""

import logging
import os
import shutil
import tempfile
from pathlib import Path

from git import Repo

logger = logging.getLogger(__name__)


# --- Test fixture: a small Python project for the agent to work on ---

_FIXTURE_MAIN_PY = '''\
def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    return a / b
'''

_FIXTURE_TEST_PY = '''\
from main import add, subtract, multiply, divide


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(5, 3) == 2
'''


def _create_test_repo(workspace: str) -> Repo:
    """Create a minimal git repo with fixture files."""
    repo = Repo.init(workspace)
    repo.config_writer().set_value("user", "name", "shypmate-test").release()
    repo.config_writer().set_value("user", "email", "test@shypmate.dev").release()

    # Write fixture files
    (Path(workspace) / "main.py").write_text(_FIXTURE_MAIN_PY)
    (Path(workspace) / "test_main.py").write_text(_FIXTURE_TEST_PY)

    repo.git.add("-A")
    repo.git.commit("-m", "Initial commit")
    repo.git.checkout("-b", "shypmate/test/loop-test")

    return repo


def _build_test_system_prompt() -> str:
    return """You are a dev agent working on a small Python project.
You have access to tools for reading/writing files, running git operations, and shell commands.

IMPORTANT:
- Make focused, minimal changes that accomplish the task.
- Commit your changes with a clear commit message.
- Do NOT try to push or create a pull request — this is a local test repo.
- Do NOT use git_push or create_pull_request tools.
"""


_DEFAULT_TASK = """\
Add proper error handling to the divide function in main.py:
1. Read main.py to understand the current code
2. Add a check for division by zero that raises a ValueError with a clear message
3. Add a docstring to the divide function
4. Commit your changes

Do NOT push or create a PR — this is a local test.
"""


class LoopTestResult:
    """Result of a loop test run."""

    def __init__(self):
        self.passed = False
        self.iterations = 0
        self.commits_made = 0
        self.files_changed: list[str] = []
        self.agent_output = ""
        self.error: str | None = None

    def __str__(self):
        status = "PASSED" if self.passed else "FAILED"
        lines = [
            f"Loop Test: {status}",
            f"  Iterations: {self.iterations}",
            f"  Commits made: {self.commits_made}",
            f"  Files changed: {', '.join(self.files_changed) or '(none)'}",
        ]
        if self.error:
            lines.append(f"  Error: {self.error}")
        return "\n".join(lines)


def run_loop_test(
    provider_name: str = "anthropic",
    model: str | None = None,
    max_tokens: int = 4096,
    task: str | None = None,
    mock: bool = False,
    keep_workspace: bool = False,
) -> LoopTestResult:
    """
    Run a full agent loop test.

    Args:
        provider_name: LLM provider ("anthropic" or "openai").
        model: Model name (default: auto-select based on provider).
        max_tokens: Max tokens per LLM call.
        task: Custom task description (default: add error handling to divide).
        mock: Use mock LLM instead of real API calls.
        keep_workspace: Don't delete the temp workspace after the test.

    Returns:
        LoopTestResult with pass/fail and details.
    """
    result = LoopTestResult()
    workspace = tempfile.mkdtemp(prefix="shypmate-test-")
    task_prompt = task or _DEFAULT_TASK

    if not model:
        model = "claude-sonnet-4-6" if provider_name == "anthropic" else "gpt-4o"

    logger.info(f"Test workspace: {workspace}")
    logger.info(f"Provider: {provider_name}, Model: {model}")
    logger.info(f"Mock mode: {mock}")

    try:
        # 1. Create test repo
        logger.info("Creating test repo...")
        repo = _create_test_repo(workspace)
        initial_commit_count = int(repo.git.rev_list("--count", "HEAD"))

        # 2. Patch the workspace path so file/git tools use our temp repo
        _patch_workspace(workspace)

        # 3. Create provider and registry
        if mock:
            provider = _create_mock_provider(workspace)
        else:
            from shypmate.engine.providers import create_provider
            provider = create_provider(
                provider=provider_name,
                model=model,
                max_tokens=max_tokens,
            )

        from shypmate.engine.tool_registry import ToolRegistry
        registry = _create_test_registry()

        # 4. Run the agent loop
        logger.info("Starting agent loop...")
        from shypmate.engine.agent_loop import run_agent

        agent_output = run_agent(
            provider=provider,
            system_prompt=_build_test_system_prompt(),
            task_prompt=task_prompt,
            registry=registry,
            max_iterations=20,
        )
        result.agent_output = agent_output

        # 5. Verify results
        final_commit_count = int(repo.git.rev_list("--count", "HEAD"))
        result.commits_made = final_commit_count - initial_commit_count

        if result.commits_made > 0:
            result.files_changed = repo.git.diff(
                "--name-only", "HEAD~" + str(result.commits_made), "HEAD"
            ).splitlines()

        # Check that the agent actually did something
        main_py = (Path(workspace) / "main.py").read_text()
        has_changes = main_py != _FIXTURE_MAIN_PY

        if result.commits_made > 0 and has_changes:
            result.passed = True
            logger.info("Test PASSED — agent made changes and committed.")
        elif has_changes and result.commits_made == 0:
            result.error = "Agent modified files but didn't commit."
            logger.warning(result.error)
        else:
            result.error = "Agent didn't modify main.py."
            logger.warning(result.error)

    except Exception as e:
        result.error = str(e)
        logger.error(f"Test failed with error: {e}", exc_info=True)
    finally:
        if keep_workspace:
            logger.info(f"Workspace kept at: {workspace}")
        else:
            shutil.rmtree(workspace, ignore_errors=True)

    return result


def _patch_workspace(workspace: str):
    """Temporarily override the workspace path used by file, git, and shell tools."""
    import shypmate.tools.file_tools as ft
    import shypmate.tools.git_tools as gt
    import shypmate.tools.shell_tools as st

    ft.WORKSPACE = Path(workspace)
    gt.WORKSPACE = workspace
    st.WORKSPACE = workspace


def _create_test_registry() -> "ToolRegistry":
    """Create a registry with tools appropriate for local testing (no GitHub tools)."""
    from shypmate.engine.tool_registry import ToolRegistry
    from shypmate.tools.file_tools import (
        list_directory,
        patch_file,
        read_file,
        search_files,
        write_file,
    )
    from shypmate.tools.git_tools import (
        git_changed_files,
        git_commit,
        git_diff,
        git_log,
        git_status,
    )
    from shypmate.tools.shell_tools import (
        run_ruff_check,
        run_ruff_format,
        run_shell_command,
    )

    registry = ToolRegistry()
    registry.register_all(
        read_file,
        write_file,
        list_directory,
        search_files,
        patch_file,
        git_commit,
        git_diff,
        git_changed_files,
        git_status,
        git_log,
        run_shell_command,
        run_ruff_check,
        run_ruff_format,
    )
    return registry


class _MockProvider:
    """
    Mock LLM provider that executes a scripted sequence of tool calls.
    Useful for testing the loop without an API key.
    """

    def __init__(self, workspace: str):
        self.workspace = workspace
        self._step = 0
        self._script = self._build_script()

    def _build_script(self):
        """Pre-scripted agent actions."""
        from shypmate.engine.providers import LLMResponse, ToolCall

        return [
            # Step 1: Read main.py
            LLMResponse(
                text="Let me read the current code first.",
                tool_calls=[ToolCall(id="call_1", name="read_file", input={"path": "main.py"})],
                stop_reason="tool_use",
                usage={"input_tokens": 100, "output_tokens": 50},
            ),
            # Step 2: Patch the divide function
            LLMResponse(
                text="I'll add error handling and a docstring to the divide function.",
                tool_calls=[ToolCall(
                    id="call_2",
                    name="patch_file",
                    input={
                        "path": "main.py",
                        "old_text": "def divide(a, b):\n    return a / b",
                        "new_text": (
                            'def divide(a, b):\n'
                            '    """Divide a by b.\n\n'
                            '    Raises:\n'
                            '        ValueError: If b is zero.\n'
                            '    """\n'
                            '    if b == 0:\n'
                            '        raise ValueError("Cannot divide by zero")\n'
                            '    return a / b'
                        ),
                    },
                )],
                stop_reason="tool_use",
                usage={"input_tokens": 200, "output_tokens": 100},
            ),
            # Step 3: Commit
            LLMResponse(
                text="Now I'll commit the changes.",
                tool_calls=[ToolCall(
                    id="call_3",
                    name="git_commit",
                    input={"message": "Add error handling and docstring to divide function"},
                )],
                stop_reason="tool_use",
                usage={"input_tokens": 150, "output_tokens": 50},
            ),
            # Step 4: Done
            LLMResponse(
                text="Done. Added ValueError for division by zero and a docstring to divide().",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 100, "output_tokens": 30},
            ),
        ]

    def create_message(self, system, messages, tools):
        if self._step >= len(self._script):
            from shypmate.engine.providers import LLMResponse
            return LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 0, "output_tokens": 0},
            )
        response = self._script[self._step]
        self._step += 1
        return response


def _create_mock_provider(workspace: str) -> _MockProvider:
    return _MockProvider(workspace)
