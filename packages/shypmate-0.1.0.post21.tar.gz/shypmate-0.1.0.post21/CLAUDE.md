# Shypmate — Claude Code Guide

This file is read automatically by Claude Code at session start. It contains everything needed to understand, contribute to, and extend this project.

## What This Project Is

Shypmate is a **developer multiplier** — a standalone, project-agnostic framework for running autonomous AI dev agents as Docker containers. It is NOT a copilot or code suggestion tool. It takes tasks off the developer's plate, executes them in isolated containers, and delivers PRs for review. The developer assigns, reviews, and merges — they are always in control.

Installed via `pip install shypmate` and configured per-project with `shypmate.yml`.

Each agent:
- Clones the consuming project's repo into its own isolated container
- Creates a unique `shypmate/*` branch
- Reads project context files (CLAUDE.md, README, etc.) to understand the codebase
- Implements a task using an LLM (Anthropic Claude, OpenAI, etc.)
- Validates its changes (linting, formatting)
- Commits, pushes, and opens a PR with machine-readable metadata
- Exits

A persistent PR monitor watches for stale AI branches and re-spawns agents to rebase after master advances.

## How It's Used

Install shypmate and configure it per-project:

```bash
pip install shypmate
```

```
some-project/
├── shypmate.yml           # project-specific config
├── .env                   # secrets
├── shypmate_tasks.yml     # task queue state (created by the CLI)
└── ...project files
```

The consuming project provides:
- `shypmate.yml` — repo name, Docker network, validation commands, safety rules, tech stack
- `.env` — `GITHUB_TOKEN`, `ANTHROPIC_API_KEY`, and optional `SHYPMATE_*` overrides
- `shypmate_tasks.yml` — auto-managed task queue (created by the CLI)

Shypmate itself has **zero hardcoded project values**. All project-specific config comes from `shypmate.yml` and environment variables.

## Repository Layout

```
shypmate/
├── __init__.py
├── __main__.py                  # python -m shypmate entry point
├── main.py                      # Host-side CLI (click) — all commands
├── task_manager.py              # Task queue CRUD (shypmate_tasks.yml backend)
├── entrypoint.py                # Container lifecycle: clone -> branch -> crew -> push -> PR
├── Dockerfile                   # Agent container image (Python 3.12 + git + ruff + system deps)
├── requirements.txt             # Python deps: anthropic, gitpython, PyGithub, click, docker, rich
├── Makefile                     # Cross-platform make targets (Windows + macOS)
├── launch.sh                    # Launcher script (bash — macOS/Linux/WSL/Git Bash)
├── launch.bat                   # Launcher script (Windows cmd)
├── setup_venv.sh / .bat         # Venv setup scripts
├── .dockerignore
├── .gitignore
├── docker-compose.monitor.yml   # Compose file for the PR monitor
│
├── config/
│   └── project.py               # Loads config from env vars + shypmate.yml (never edit)
│
├── context/
│   └── project_context.py       # Reads repo context files -> string for agent backstory
│
├── agents/
│   └── dev_agent.py             # Agent definition (system prompt, tool registry)
│
├── tasks/
│   └── dev_task.py              # Task prompt builder (normal + rebase modes, PR metadata)
│
├── engine/
│   ├── __init__.py
│   ├── agent_loop.py            # Think → tool → repeat loop
│   ├── providers.py             # LLM provider abstraction (Anthropic, OpenAI)
│   └── tool_registry.py         # Tool schema generation + dispatch
│
├── crews/
│   └── dev_crew.py              # Dev crew assembly: provider + agent + task
│
├── tools/
│   ├── git_tools.py             # 12 git tools (branch, commit, rebase, push, diff, etc.)
│   ├── github_tools.py          # 6 GitHub tools (create/update PR, comment, list AI PRs, metadata)
│   ├── file_tools.py            # 5 file tools (read, write, list, search, patch — workspace-sandboxed)
│   └── shell_tools.py           # 3 shell tools (constrained allowlist, ruff check, ruff format)
│
├── manager/
│   ├── manager.py               # Wave orchestration loop: plan → launch → monitor → advance
│   ├── wave_planner.py          # WavePlan/WaveState dataclasses, LLM-based dependency analysis
│   └── project_brief.py         # One-time project analysis shared across all workers
│
├── monitor/
│   ├── Dockerfile               # Monitor container image
│   └── pr_monitor.py            # Polling service: watches master, detects stale PRs, re-spawns agents
│
└── docs/
    └── README.md                # Full documentation
```

## Architecture

### Manager / Worker Model with Wave Planning

```
Manager (persistent container, started via 'shypmate start')
  ├── Clone repo, read context files
  ├── Generate project brief (ONE LLM call → shared volume)
  ├── Analyze all pending tasks → wave execution plan (ONE LLM call)
  ├── Launch Wave 1 agents in parallel
  ├── Monitor agents, detect new tasks, handle critical tasks
  ├── Wait for wave PRs to merge → re-analyze → launch next wave
  ├── Clean up merged containers
  └── Refresh brief when base branch advances

Worker agents (N containers, launched by manager or 'shypmate work')
  ├── Mount shared brief volume (read-only)
  ├── Skip discovery — use pre-digested context
  └── Go straight to implementation
```

The manager groups tasks into dependency-ordered **waves**. Tasks within a wave run in parallel; waves execute sequentially after PRs are merged. This handles both greenfield projects (tasks must build on each other) and mature codebases (most tasks are independent → one big wave).

Configuration: `tasks.execution` in `shypmate.yml` — `auto` (default, manager decides), `parallel` (force all at once), `sequential` (one at a time).

**Key files:**
- `manager/wave_planner.py` — `WavePlan`/`WaveState` dataclasses, `plan_waves()`, `slot_new_task()`
- `manager/manager.py` — orchestration loop (wave launch, monitoring, re-analysis)

Without a manager (`run-agent` standalone), workers fall back to self-discovery and skip wave planning entirely.

### One Task = One Container

Each task gets its own Docker container with a fresh repo clone. Full filesystem isolation — no agent can interfere with another. Agents connect to the consuming project's Docker network for shared services (db, redis, etc.) but must treat them as read-only.

### Config Flow

```
Environment variable  >  shypmate.yml  >  shypmate.py  >  auto-detect  >  built-in default
```

`config/project.py` reads from `SHYPMATE_*` env vars, `shypmate.yml`, and `shypmate.py` at the project root. It has no hardcoded values.

### Agent Lifecycle (entrypoint.py)

```
Clone repo -> Configure git identity -> Create/checkout branch
-> Install project dependencies
-> Check for manager brief (skip discovery if present)
-> OR Build context from CLAUDE.md etc. (standalone mode)
-> Run dev agent (think → tool → repeat) -> (agent edits code, validates, commits, pushes, opens PR)
-> Exit
```

### PR Metadata

Every AI-created PR contains a hidden metadata block:

```html
<!-- SHYPMATE_META
{"task": "...", "agent_id": "...", "branch": "...", "created_at": "...", "rebase_count": 0}
SHYPMATE_META -->
```

The monitor uses this to reconstruct and re-spawn the same task on a stale branch.

### Task Queue

`shypmate_tasks.yml` (at the consuming project root) tracks tasks with:
- `id`, `description`, `priority` (critical/high/normal/low)
- `status` (pending/running/done/failed/cancelled)
- `agent_id`, `branch`, `pr_url`
- `created_at`, `started_at`, `finished_at`

The CLI's `task list` command does **live lookups** — it checks Docker container state and GitHub PR status in real-time, not cached values.

### Shell Sandboxing

Agents cannot run arbitrary shell commands. `tools/shell_tools.py` has:
- **Built-in allowlist**: `ruff`, `pytest`, `pip`, `cat`, `head`, `tail`, `wc`, `diff`, `find`, `ls`
- **Built-in blocklist**: `rm -rf`, `DROP`, `DELETE FROM`, `TRUNCATE`, `FLUSHALL`, `FLUSHDB`
- **Project additions**: merged from `shell.allowed_prefixes` and `shell.blocked_patterns` in `shypmate.yml`

### File Sandboxing

All file tools in `tools/file_tools.py` are sandboxed to `/workspace`. Path traversal attempts are rejected.

## Key Design Decisions

### Project-Agnostic

Shypmate has zero hardcoded project references. Every project-specific value comes from `shypmate.yml` or `SHYPMATE_*` env vars. To use in a new project: `pip install shypmate`, create `shypmate.yml`, add secrets to `.env`.

### pip Distribution

Shypmate is distributed as a pip package (`pip install shypmate`). The CLI is available as both `shypmate` and `python -m shypmate` after installation. The Dockerfile and Makefile are bundled as package data.

### Shared Services Policy

Agents attach to the project's Docker network but must treat shared services as read-only:
- No running migrations against shared databases
- No flushing Redis
- No deleting MinIO objects
- Tests must use isolated per-agent test DB names

Rules are enforced at two levels: shell blocklist (hard block) and agent instructions (LLM guidance).

## CLI Commands (via Makefile)

Run from the `shypmate/` directory:

### Task Management
| Command | Description |
|---|---|
| `make task-add T="desc" P=high` | Add a task (priority: critical/high/normal/low) |
| `make task-list` | List tasks with live agent + PR status |
| `make task-list-all` | Include done/failed tasks |
| `make task-remove ID=x` | Remove a task |
| `make task-update ID=x P=critical` | Update priority/status |

### Work Execution
| Command | Description |
|---|---|
| `make work` | Launch next pending task by priority |
| `make work-all` | Launch all pending tasks in parallel |
| `make work-n N=3` | Launch top N tasks |
| `make work-live` | Launch next task in foreground |

### Agent Lifecycle
| Command | Description |
|---|---|
| `make review ID=x` | Review agent's task, branch, status, logs |
| `make retry ID=x` | Re-launch agent with same task + branch |
| `make logs ID=x` | Show last 50 log lines |
| `make logs-follow ID=x` | Follow logs live |
| `make agent T="desc"` | Launch agent directly (skip queue) |

### Monitoring
| Command | Description |
|---|---|
| `make dashboard` | Live-updating dashboard |
| `make status` | Show running containers |
| `make list-agents` | All containers including exited |
| `make sync` | Sync task states with container/PR reality |

### Lifecycle
| Command | Description |
|---|---|
| `shypmate start` | Start the manager (discovery, planning, PR monitoring) |
| `shypmate stop` | Stop the manager |
| `shypmate verify` | End-to-end test run in a container |
| `make clean` | Remove containers for merged/closed PRs |
| `make clean-all` | Remove ALL exited containers |

### Infrastructure
| Command | Description |
|---|---|
| `make setup` | First-time setup (venv + Docker image) |
| `make build` | Build agent Docker image |
| `make build-monitor` | Build PR monitor image |
| `make monitor` | Start PR monitor |
| `make monitor-stop` | Stop PR monitor |

## Development Setup

After cloning the repo, install in editable mode so local changes take effect immediately:

```bash
pip install -e .
```

This makes the `shypmate` CLI point directly at your local `src/` files — any edits take effect without reinstalling. Re-run only if you change `pyproject.toml` (new dependencies, entry points, etc.).

To verify your setup:

```bash
shypmate validate
```

## Development Notes

### Adding a New Tool

1. Add function to the appropriate `tools/*.py` module with `@tool("name")` decorator
2. Add import + tool reference to `agents/dev_agent.py`'s tool list
3. If it's a shell command, add the prefix to `_BUILTIN_ALLOWED_PREFIXES` in `shell_tools.py`

### Adding a New Agent Type

1. Create `agents/new_agent.py` with a `create_*_agent()` function
2. Create `tasks/new_task.py` with a `create_*_task()` function
3. Create `crews/new_crew.py` with a `run_*_crew()` function
4. Add CLI command in `main.py`

### Configuration Priority

```
SHYPMATE_* env var  >  shypmate.yml  >  shypmate.py  >  auto-detect  >  built-in default
```

### Config Sources

- **`shypmate.yml`** — YAML config (created by `shypmate init`). Best for static, declarative config.
- **`shypmate.py`** — Python config file. Supports three patterns (all can coexist):
  1. **`config` dict** — same keys as shypmate.yml, expressed as a Python dict
  2. **Named functions** — e.g. `def github_repo(): return "owner/repo"` overrides the dict per-field
  3. **Hooks** — e.g. `def select_llm(task, pool, agent_index)` for custom runtime behavior

Both files can coexist — yml always overrides py per-field.

#### shypmate.py example

```python
# Static config
config = {
    "docker": {"network": "myproject_default"},
    "shared_service_rules": ["Do NOT flush Redis."],
}

# Dynamic config — function overrides config dict for this field
def github_repo():
    import subprocess, re
    url = subprocess.run(["git", "remote", "get-url", "origin"],
                         capture_output=True, text=True).stdout.strip()
    match = re.match(r"(?:https?://github\.com/|git@github\.com:)([^/]+/[^/]+?)(?:\.git)?$", url)
    return match.group(1) if match else None

def tech_stack():
    from pathlib import Path
    stack = []
    if Path("pyproject.toml").exists(): stack.append("Python")
    if Path("package.json").exists(): stack.append("Node.js")
    return stack or None

# Hook — custom LLM selection (replaces round-robin)
def select_llm(task, pool, agent_index):
    if "refactor" in task.lower():
        return next((e for e in pool if e.provider == "anthropic"), pool[0])
    return pool[agent_index % len(pool)]
```

#### Available config functions

`github_repo`, `base_branch`, `docker_network`, `install_command`, `tech_stack`,
`context_files`, `validation_commands`, `shared_service_rules`, `llm_provider`,
`llm_model`, `llm_max_tokens`, `llm_base_url`, `llm_api_key_var`, `llm_pool`,
`branch_prefix`, `pr_title_prefix`, `pr_label`, `allowed_shell_prefixes`, `blocked_shell_patterns`

### Agent Quotas (required)

Every project must set at least one hard quota in `shypmate.yml` under `quota.hard`. Agents refuse to run without it.

- **Soft quota** — pauses and asks human via `request_human_input` whether to continue
- **Hard quota** — stops agent immediately. Required.
- All costs in **USD**. Available limits: `max_tokens`, `max_cost`, `max_seconds`, `max_iterations`
- Default from `shypmate init`: soft $0.50 / 15 iterations, hard $2.00 / 30 iterations

### Secrets

- `GITHUB_TOKEN` — clone, push, PR operations (needs `repo` + `pull_request` scopes)
- `ANTHROPIC_API_KEY` — LLM calls inside agent containers (API billing, separate from Claude subscription)
- Both passed as container env vars, never baked into images

### Testing Changes

After modifying framework code, publish to PyPI, then in each consuming project:
```bash
pip install --upgrade shypmate
shypmate build   # rebuild agent image with new code
```

### Current Status

- V1 is functional — successfully cloned, branched, coded, validated, committed, pushed, and opened a PR autonomously
- Agent uses `claude-sonnet-4-6` via Anthropic API (requires API credits, not covered by Claude subscription)
- Ruff is baked into the Docker image for validation
- PR monitor and task queue are implemented but need more production testing
- Dashboard uses `rich` for terminal UI with live refresh

### Roadmap & Future Work

See **[ROADMAP.md](ROADMAP.md)** for planned features, architectural decisions, and known issues. Agents should always reference this file to understand what's coming and avoid conflicting with planned directions.
