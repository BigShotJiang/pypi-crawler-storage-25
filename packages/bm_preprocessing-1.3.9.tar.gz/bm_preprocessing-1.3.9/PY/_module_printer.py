import types


class PrintableModule(types.ModuleType):
    """A module subclass that prints its source when print() is called."""

    def __repr__(self):
        return self._source_content

    def __str__(self):
        return self._source_content
