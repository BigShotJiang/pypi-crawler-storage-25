"""Redis configuration builder module.

This module provides a fluent builder interface for constructing Redis
connection configurations with support for URLs, authentication, SSL,
and connection pooling.
"""

from typing import Self

from ..core.coerce import coerce_bool, coerce_int
from ..core.config import ConfigBuilder

__all__ = ("RedisConfig",)


class RedisConfig(ConfigBuilder):
    """Builder for constructing Redis connection configuration.

    Provides a fluent interface for setting Redis connection parameters
    including URL, host, port, database, authentication, SSL, and pooling options.
    All setter methods return self for method chaining.

    Example:
        >>> config = RedisConfig() \\
        ...     .set_redis_host("localhost") \\
        ...     .set_redis_port(6379) \\
        ...     .set_redis_db("0") \\
        ...     .set_redis_password("secret") \\
        ...     .set_redis_max_connections(20)
    """

    def set_redis_url(self, redis_url: str) -> Self:
        """Set the full Redis connection URL.

        Allows specifying a complete connection string instead of individual
        components. Takes precedence over individual host/port/db settings.

        Args:
            redis_url: Full Redis connection URL (e.g., redis://localhost:6379/0
                or rediss://user:pass@host:6379/0 for SSL with auth).

        Returns:
            RedisConfig: Self for method chaining.

        Example:
            >>> config = RedisConfig().set_redis_url("redis://localhost:6379/0")
        """
        self._config["redis_url"] = redis_url
        return self

    def set_redis_host(self, host: str) -> Self:
        """Set the Redis server hostname or IP address.

        Args:
            host: The hostname or IP address of the Redis server
                (e.g., "localhost", "127.0.0.1", "redis.example.com").

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_host"] = host
        return self

    def set_redis_port(self, port: int | str) -> Self:
        """Set the Redis server port number.

        Args:
            port: The port number on which Redis is listening (default is 6379).
                Accepts int or string (as returned by ``Env.get()``).

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_port"] = coerce_int(port)
        return self

    def set_redis_db(self, database: str) -> Self:
        """Set the Redis database number to use.

        Args:
            database: The database number as a string (typically 0-15 for default Redis).

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            Redis database numbers are 0-indexed. Most configurations use database 0.
        """
        self._config["redis_db"] = database
        return self

    def set_redis_password(self, password: str) -> Self:
        """Set the Redis authentication password.

        Args:
            password: The password for Redis authentication. Will be URL-encoded
                automatically when constructing connection URLs.

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            Use this for simple password authentication (Redis < 6) or with
            set_redis_username() for ACL authentication (Redis 6+).
        """
        self._config["redis_password"] = password
        return self

    def set_redis_username(self, username: str) -> Self:
        """Set the Redis authentication username.

        Used for Redis ACL authentication in Redis 6+.

        Args:
            username: The username for Redis ACL authentication.

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            This requires Redis 6.0 or higher. For older versions, only use
            set_redis_password() without username.
        """
        self._config["redis_username"] = username
        return self

    def set_redis_ssl(self, ssl: bool) -> Self:
        """Enable or disable SSL/TLS for Redis connections.

        Args:
            ssl: True to use SSL/TLS (rediss:// protocol), False for plain
                connection (redis:// protocol).

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            When enabled, the connection URL will use rediss:// instead of redis://.
        """
        self._config["redis_ssl"] = ssl
        return self

    def set_redis_max_connections(self, redis_max_connections: int | str) -> Self:
        """Set the maximum number of connections in the pool.

        Args:
            redis_max_connections: Maximum number of concurrent connections allowed
                in the connection pool. Higher values allow more concurrent operations
                but consume more resources. Accepts int or string (as returned by
                ``Env.get()``).

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            Default is typically 10. Adjust based on your application's concurrency needs.
        """
        self._config["redis_max_connections"] = coerce_int(redis_max_connections)
        return self

    def set_redis_socket_timeout(self, redis_socket_timeout: int | str) -> Self:
        """Set the socket timeout in seconds for Redis operations.

        Args:
            redis_socket_timeout: Timeout in seconds for read/write socket
                operations. Operations exceeding this time will raise a
                timeout error. Accepts int or string (as returned by ``Env.get()``).

        Returns:
            RedisConfig: Self for method chaining.

        Note:
            Default is typically 5 seconds. Lower values fail faster but may
            cause issues with slow networks or heavy server load.
        """
        self._config["redis_socket_timeout"] = coerce_int(redis_socket_timeout)
        return self

    def set_redis_socket_connect_timeout(self, redis_socket_connect_timeout: int | str) -> Self:
        """Set the socket connect timeout in seconds.

        Controls how long the client waits during the initial TCP handshake
        when establishing a new connection. Separate from socket_timeout which
        applies to subsequent read/write operations.

        Args:
            redis_socket_connect_timeout: Timeout in seconds for the initial
                socket connection. Defaults to 5 if not configured. Accepts int
                or string (as returned by ``Env.get()``).

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_socket_connect_timeout"] = coerce_int(redis_socket_connect_timeout)
        return self

    def set_redis_socket_keepalive(self, redis_socket_keepalive: bool) -> Self:
        """Enable or disable TCP keepalive on Redis sockets.

        When enabled, the operating system sends periodic TCP keepalive probes
        to detect dead connections. Essential for environments behind proxies
        (e.g., Railway) that terminate idle TCP connections.

        Args:
            redis_socket_keepalive: True to enable TCP keepalive, False to
                disable. Defaults to True if not configured.

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_socket_keepalive"] = redis_socket_keepalive
        return self

    def set_redis_health_check_interval(self, redis_health_check_interval: int | str) -> Self:
        """Set the interval in seconds between health-check pings.

        Sends a PING command to the Redis server at this interval to keep
        the connection alive and detect failures early. Critical for hosted
        platforms (e.g., Railway) where reverse proxies drop idle connections.

        Args:
            redis_health_check_interval: Interval in seconds between PING
                commands. Set to 0 to disable. Defaults to 15 if not configured.

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_health_check_interval"] = coerce_int(redis_health_check_interval)
        return self

    def set_redis_retry_on_timeout(self, redis_retry_on_timeout: bool) -> Self:
        """Enable or disable automatic retry on timeout errors.

        When enabled, commands that fail due to a timeout are automatically
        retried instead of raising an exception immediately.

        Args:
            redis_retry_on_timeout: True to retry timed-out commands, False
                to raise immediately. Defaults to True if not configured.

        Returns:
            RedisConfig: Self for method chaining.
        """
        self._config["redis_retry_on_timeout"] = redis_retry_on_timeout
        return self

    @classmethod
    def from_env(cls, prefix: str = "redis_") -> Self:
        """Build a RedisConfig from environment variables.

        Reads standard Redis connection parameters from the environment using
        the given prefix. If ``{prefix}url`` is set it is used directly and all
        host/port/db variables are ignored. Otherwise ``{prefix}host``,
        ``{prefix}port``, ``{prefix}db``, ``{prefix}password``,
        ``{prefix}username``, ``{prefix}ssl``, and ``{prefix}max_connections``
        are read.

        All variables must be registered via ``Env.register()`` before calling
        this method.

        Args:
            prefix: Prefix for the environment variable names. Defaults to
                ``"redis_"``.

        Returns:
            A configured ``RedisConfig`` instance ready to pass to
            ``RedisInstance``.

        Example::

            Env.register(["redis_url", "redis_max_connections"])
            Env.load_file(".env")
            redis_config = RedisConfig.from_env()
            redis_instance = RedisInstance(redis_config=redis_config)
        """
        from ..core.env import Env

        config = cls()
        if url := Env.get(f"{prefix}url"):
            config = config.set_redis_url(url)
        else:
            if host := Env.get(f"{prefix}host"):
                config = config.set_redis_host(host)
            if port := Env.get(f"{prefix}port"):
                config = config.set_redis_port(port)
            if db := Env.get(f"{prefix}db"):
                config = config.set_redis_db(db)
            if password := Env.get(f"{prefix}password"):
                config = config.set_redis_password(password)
            if username := Env.get(f"{prefix}username"):
                config = config.set_redis_username(username)
            if (ssl_val := Env.get(f"{prefix}ssl")) is not None:
                config = config.set_redis_ssl(coerce_bool(ssl_val))
        if max_conn := Env.get(f"{prefix}max_connections"):
            config = config.set_redis_max_connections(max_conn)
        return config
