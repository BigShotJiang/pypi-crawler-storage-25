"""OpenSearch configuration builder module.

This module provides a fluent builder interface for constructing OpenSearch
connection configurations with support for URLs, authentication, SSL,
timeouts, and retry settings.
"""

from typing import Any, Self

from ..core.coerce import coerce_bool, coerce_int
from ..core.config import ConfigBuilder

__all__ = ("OpenSearchConfig",)


class OpenSearchConfig(ConfigBuilder):
    """Builder for constructing OpenSearch connection configuration.

    Provides a fluent interface for setting OpenSearch connection parameters
    including URLs, hosts, authentication, SSL, timeouts, and retry options.
    All setter methods return self for method chaining.

    Example:
        >>> config = OpenSearchConfig() \\
        ...     .set_hosts(["https://localhost:9200"]) \\
        ...     .set_username("admin") \\
        ...     .set_password("admin") \\
        ...     .set_verify_certs(False) \\
        ...     .set_timeout(60)
    """

    def set_url(self, url: str) -> Self:
        """Set a single OpenSearch cluster URL.

        Args:
            url: Complete OpenSearch cluster URL including protocol and port
                (e.g., "https://localhost:9200", "http://opensearch.example.com:9200").

        Returns:
            OpenSearchConfig: Self for method chaining.

        Example:
            >>> config = OpenSearchConfig().set_url("https://localhost:9200")
        """
        self._config["url"] = url
        return self

    def set_hosts(self, hosts: list[str]) -> Self:
        """Set multiple OpenSearch cluster hosts/URLs.

        Args:
            hosts: List of OpenSearch cluster URLs or host strings. Can include
                protocol, port, and path (e.g., ["https://node1:9200", "https://node2:9200"]).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Example:
            >>> config = OpenSearchConfig().set_hosts([
            ...     "https://node1.example.com:9200",
            ...     "https://node2.example.com:9200"
            ... ])
        """
        self._config["hosts"] = hosts
        return self

    def set_username(self, username: str) -> Self:
        """Set the OpenSearch authentication username.

        Args:
            username: The username for OpenSearch authentication (basic auth or
                security plugin authentication).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Typically used with set_password() for basic authentication.
        """
        self._config["username"] = username
        return self

    def set_password(self, password: str) -> Self:
        """Set the OpenSearch authentication password.

        Args:
            password: The password for OpenSearch authentication.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Should be used together with set_username() for complete authentication.
        """
        self._config["password"] = password
        return self

    def set_verify_certs(self, verify_certs: bool) -> Self:
        """Enable or disable SSL certificate verification.

        Args:
            verify_certs: True to verify SSL certificates (recommended for production),
                False to skip certificate verification (useful for development with
                self-signed certificates).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Disabling certificate verification reduces security. Only disable
            in development environments or with proper network security.
        """
        self._config["verify_certs"] = verify_certs
        return self

    def set_ssl_show_warn(self, ssl_show_warn: bool) -> Self:
        """Enable or disable SSL certificate verification warnings.

        Args:
            ssl_show_warn: True to show SSL warnings (recommended for production),
                False to hide SSL warnings (useful for development with
                self-signed certificates).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Disabling SSL warnings reduces visibility into potential security issues.
            Only disable in development environments or with proper network security.
        """
        self._config["ssl_show_warn"] = ssl_show_warn
        return self

    def set_use_ssl(self, use_ssl: bool) -> Self:
        """Enable or disable SSL/TLS for OpenSearch connections.

        Args:
            use_ssl: True to use HTTPS connections, False for HTTP connections.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Production deployments should use SSL (HTTPS). HTTP should only
            be used in local development environments.
        """
        self._config["use_ssl"] = use_ssl
        return self

    def set_timeout(self, timeout: int | str) -> Self:
        """Set the request timeout in seconds.

        Args:
            timeout: Timeout in seconds for OpenSearch operations. Requests
                exceeding this time will raise a timeout error. Accepts int
                or string (as returned by ``Env.get()``).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Default is typically 30 seconds. Increase for complex queries or
            large bulk operations that may take longer to complete.
        """
        self._config["timeout"] = coerce_int(timeout)
        return self

    def set_max_retries(self, max_retries: int | str) -> Self:
        """Set the maximum number of retry attempts for failed requests.

        Args:
            max_retries: Maximum number of times to retry failed requests before
                giving up. Set to 0 to disable retries. Accepts int or string
                (as returned by ``Env.get()``).

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Retries help handle transient network issues and cluster failover.
            Too many retries may mask persistent problems.
        """
        self._config["max_retries"] = coerce_int(max_retries)
        return self

    def set_retry_on_timeout(self, retry_on_timeout: bool) -> Self:
        """Enable or disable retries on timeout errors.

        Args:
            retry_on_timeout: True to retry requests that timeout, False to
                fail immediately on timeout.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Enabling timeout retries can help with temporary cluster overload
            but may increase total request time.
        """
        self._config["retry_on_timeout"] = retry_on_timeout
        return self

    def set_ca_certs(self, ca_certs: str) -> Self:
        """Set the path to CA certificate bundle for SSL verification.

        Args:
            ca_certs: Path to the CA certificate bundle file for verifying
                SSL certificates from the OpenSearch cluster.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Required when using custom CA certificates or self-signed certificates
            with certificate verification enabled.
        """
        self._config["ca_certs"] = ca_certs
        return self

    def set_client_cert(self, client_cert: str) -> Self:
        """Set the path to client certificate for mutual TLS authentication.

        Args:
            client_cert: Path to the client certificate file for mutual TLS
                authentication with the OpenSearch cluster.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Used for client certificate authentication. Must be paired with
            set_client_key() for complete mutual TLS setup.
        """
        self._config["client_cert"] = client_cert
        return self

    def set_client_key(self, client_key: str) -> Self:
        """Set the path to client private key for mutual TLS authentication.

        Args:
            client_key: Path to the client private key file for mutual TLS
                authentication with the OpenSearch cluster.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Note:
            Used with set_client_cert() for client certificate authentication.
            Keep the private key file secure and properly protected.
        """
        self._config["client_key"] = client_key
        return self

    def set_connection_class(self, connection_class: Any) -> Self:
        """Set the connection class for OpenSearch client.

        Args:
            connection_class: The connection class to use for OpenSearch connections.
                Common options include RequestsHttpConnection, RequestsHttpConnection.
                Default is RequestsHttpConnection.

        Returns:
            OpenSearchConfig: Self for method chaining.

        Example:
            >>> from opensearchpy import RequestsHttpConnection
            >>> config = OpenSearchConfig().set_connection_class(RequestsHttpConnection)
        """
        self._config["connection_class"] = connection_class
        return self

    @classmethod
    def from_env(cls, prefix: str = "opensearch_") -> Self:
        """Build an OpenSearchConfig from environment variables.

        Reads standard OpenSearch connection parameters from the environment
        using the given prefix. Variables read (with default prefix
        ``opensearch_``): ``{prefix}nodes`` (comma-separated, takes priority
        over ``{prefix}url``), ``{prefix}url``, ``{prefix}username``,
        ``{prefix}password``, ``{prefix}verify_certs``, ``{prefix}use_ssl``,
        ``{prefix}ssl_show_warn``, ``{prefix}timeout``, ``{prefix}max_retries``.

        All variables must be registered via ``Env.register()`` before calling
        this method.

        Args:
            prefix: Prefix for the environment variable names. Defaults to
                ``"opensearch_"``.

        Returns:
            A configured ``OpenSearchConfig`` instance ready to pass to
            ``OpenSearchClient``.

        Example::

            Env.register(["opensearch_nodes", "opensearch_username", "opensearch_password"])
            Env.load_file(".env")
            config = OpenSearchConfig.from_env()
            opensearch_client = OpenSearchClient(config)
        """
        from ..core.env import Env

        config = cls()
        if nodes := Env.get(f"{prefix}nodes"):
            config = config.set_hosts([h.strip() for h in nodes.split(",") if h.strip()])
        elif url := Env.get(f"{prefix}url"):
            config = config.set_url(url)
        if username := Env.get(f"{prefix}username"):
            config = config.set_username(username)
        if password := Env.get(f"{prefix}password"):
            config = config.set_password(password)
        if (verify := Env.get(f"{prefix}verify_certs")) is not None:
            config = config.set_verify_certs(coerce_bool(verify))
        if (use_ssl := Env.get(f"{prefix}use_ssl")) is not None:
            config = config.set_use_ssl(coerce_bool(use_ssl))
        if (ssl_warn := Env.get(f"{prefix}ssl_show_warn")) is not None:
            config = config.set_ssl_show_warn(coerce_bool(ssl_warn))
        if timeout := Env.get(f"{prefix}timeout"):
            config = config.set_timeout(timeout)
        if max_retries := Env.get(f"{prefix}max_retries"):
            config = config.set_max_retries(max_retries)
        return config
