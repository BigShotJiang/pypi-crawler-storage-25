"""Type coercion helpers shared across config builders."""

__all__ = ("coerce_bool", "coerce_int")


def coerce_bool(value: bool | str) -> bool:
    """Coerce a bool or string value to bool.

    Treats ``"0"``, ``"false"``, ``"no"``, ``"off"``, and ``""`` as ``False``.
    All other strings — including unrecognized values — are ``True``.
    Real bools pass through unchanged.

    Use this for config-setter inputs where the caller may pass env-var strings.
    For reading directly from env vars, prefer ``Env.get_bool(key)`` instead.

    Args:
        value: A bool or string representation of a boolean.

    Returns:
        Coerced bool.
    """
    if isinstance(value, str):
        return value.strip().lower() not in ("0", "false", "no", "off", "")
    return bool(value)


def coerce_int(value: object, default: int = 0) -> int:
    """Coerce a value to int, falling back to ``default`` when not integerable.

    Accepts ints, floats (truncated toward zero), and numeric strings —
    including surrounding whitespace and float-like strings such as ``"5.0"``.
    Bools coerce to ``0`` / ``1``. ``None``, empty/blank strings, ``NaN``,
    infinities, and any other non-numeric value yield ``default`` (``0``).

    Use this for config-setter inputs where the caller may pass env-var strings
    that could be empty or malformed, so a bad value degrades to ``default``
    instead of raising at service boot. For reading directly from env vars,
    prefer ``Env.get_int(key)`` instead.

    Args:
        value: Any value to coerce.
        default: Returned when ``value`` cannot be parsed as an int. Defaults to ``0``.

    Returns:
        Coerced int, or ``default`` when not integerable.
    """
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if value is None:
        return default
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError, OverflowError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError, OverflowError):
        return default
