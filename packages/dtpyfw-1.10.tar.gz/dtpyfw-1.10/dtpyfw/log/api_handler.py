"""API-based log handler for sending logs to remote endpoints."""

import json
import logging
import sys
from time import sleep
from typing import Any

import requests

__all__ = ("LoggerHandler",)


class Logger:
    """A client for sending log records to a remote API endpoint.

    This class handles the HTTP POST request to the logging API, including
    authentication and JSON serialization. It also implements a retry
    mechanism with backoff for transient network errors.

    Args:
        logging_api_url: The URL of the remote logging API endpoint.
        logging_api_key: The API key for authenticating with the logging API.
    """

    def __init__(self, logging_api_url: str, logging_api_key: str) -> None:
        """Initialize the Logger client with API endpoint and authentication.

        Args:
            logging_api_url: The URL of the remote logging API endpoint.
            logging_api_key: The API key for authenticating with the logging API.
        """
        self.api_url = logging_api_url
        self.api_key = logging_api_key

        self.headers = {
            "Authorization": f"{self.api_key}",
            "Content-Type": "application/json",
        }

    def log(self, details: dict[str, Any]) -> bool | None:
        """Send a log entry to the remote API.

        Retries up to 3 times with a 1-second backoff. On final failure
        writes to ``sys.stderr`` instead of re-entering the logging stack —
        a recursive ``footprint.leave`` here would loop forever when the
        logging-MS is unreachable.

        Args:
            details: A dictionary containing the log data to be sent to the API.

        Returns:
            True if the log was successfully sent, None otherwise.
        """
        max_retries = 3
        backoff_seconds = 1
        for attempt in range(1, max_retries + 1):
            try:
                response = requests.post(
                    url=self.api_url,
                    data=json.dumps(details, default=str),
                    headers=self.headers,
                    timeout=5,
                )
                response.raise_for_status()
                return True
            except requests.exceptions.RequestException as e:
                if attempt < max_retries:
                    sleep(backoff_seconds)
                else:
                    sys.stderr.write(f"dtpyfw-log: failed to POST log to {self.api_url}: {e}\n")
        return None


class LoggerHandler(logging.Handler):
    """A logging handler that sends log records to a remote API.

    Synchronous: each ``emit`` POSTs the record on the calling thread and
    returns when the POST completes (or after the retry budget is spent).
    No background threads, no queue, no fork concerns.

    Args:
        logging_api_url: The URL of the remote logging API endpoint.
        logging_api_key: The API key for authenticating with the logging API.
        only_footprint_mode: If True, only send logs marked as footprints.
    """

    def __init__(
        self,
        logging_api_url: str,
        logging_api_key: str,
        only_footprint_mode: bool,
    ) -> None:
        """Initialize the LoggerHandler with API configuration.

        Args:
            logging_api_url: The URL of the remote logging API endpoint.
            logging_api_key: The API key for authenticating with the logging API.
            only_footprint_mode: If True, only send logs marked as footprints.
        """
        super().__init__()
        self.only_footprint_mode = only_footprint_mode
        self.logger = Logger(
            logging_api_url=logging_api_url,
            logging_api_key=logging_api_key,
        )

    def emit(self, record: logging.LogRecord) -> None:
        """POST the log record synchronously.

        Args:
            record: The log record to be emitted to the remote API.
        """
        details = record.__dict__.get("details") or {}

        if self.only_footprint_mode and not details.get("footprint"):
            return None

        details["log_type"] = details.get("log_type") or record.levelname.lower()
        details["subject"] = details.get("subject") or "Unnamed"
        details["controller"] = details.get("controller") or record.funcName
        details["message"] = details.get("message") or self.format(record)
        self.logger.log(details)
