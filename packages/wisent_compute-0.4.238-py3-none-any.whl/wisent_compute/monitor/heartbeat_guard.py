"""Per-job heartbeat freshness check used by the reaper to avoid
destroying productive VMs.

The reaper's primary signal is the agent's capacity broadcast in
gs://<bucket>/capacity/<consumer_id>.json. When the agent runs a
long training subprocess the broadcast loop can starve past
CAPACITY_STALE_SECONDS even though the agent process is alive and
the training is actively producing checkpoints. Reaping that VM
destroys hours of work and forces the job to restart from the last
checkpoint (or step 0 if no checkpoints exist).

This module provides a second signal — the per-job heartbeat at
gs://<bucket>/status/<job_id>/heartbeat — that is written by the
running job itself (via the agent's status-watchdog cron) and is
NOT coupled to the agent's broadcast loop. If ANY job assigned to
a VM has a fresh heartbeat, the agent is alive and the reap is
deferred.
"""
from __future__ import annotations

import re
import time
from typing import Iterable


_TS_RE = re.compile(
    r"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)"
)


def _parse_heartbeat_ts(text: str) -> float | None:
    """Parse an ISO-8601 timestamp from the heartbeat blob and return
    unix seconds. The agent writes lines like:
        RUNNING 2026-05-13T00:26:33.130155+00:00
    Returns None if no parseable timestamp is found.
    """
    if not text:
        return None
    m = _TS_RE.search(text)
    if not m:
        return None
    raw = m.group(1).replace(" ", "T").rstrip("Z")
    if "." in raw:
        head, frac = raw.split(".", 1)
        tz_idx = 0
        for i, c in enumerate(frac):
            if c in "+-":
                tz_idx = i
                break
        if tz_idx:
            tz = frac[tz_idx:]
            frac_digits = frac[:tz_idx]
        else:
            tz = ""
            frac_digits = frac
        frac_digits = frac_digits[:6]
        raw = f"{head}.{frac_digits}{tz}"
    if "+" not in raw and not raw.endswith("Z"):
        raw = raw + "+00:00"
    from datetime import datetime
    dt = datetime.fromisoformat(raw)
    return dt.timestamp()


def any_job_heartbeat_fresh(
    store, jids: Iterable[str], threshold_seconds: float
) -> bool:
    """True iff ANY job in jids has a heartbeat blob whose embedded
    timestamp is younger than threshold_seconds. Used by the reaper:
    if the agent's capacity blob is stale but a job assigned to its
    VM is still heartbeating, the agent is alive — busy in the
    training subprocess — and the VM should NOT be deleted.
    """
    now = time.time()
    for jid in jids:
        if not jid:
            continue
        try:
            text = store._download_text(f"status/{jid}/heartbeat")
        except Exception:
            # A coordinator-side GCS read failure is NOT proof the job
            # is dead. The old `except: text=None` path made a transient
            # Cloud-Function storage hiccup on one monitor tick read as
            # "no heartbeat" for EVERY running job, requeuing them all
            # in the same pass — the synchronized orphan churn (3ef705b2
            # + 724084db both requeued 2026-05-16T04:09:19, restart 11,
            # on freshly-written heartbeat blobs). Fail safe: a read
            # error defers (treat as alive); never let the coordinator's
            # own read failure destroy a running job. A genuinely dead
            # job is still caught when the read succeeds (stale ts) or
            # via the TERMINATED/absent VM path.
            return True
        if not text:
            continue
        ts = _parse_heartbeat_ts(text)
        if ts is None:
            continue
        if now - ts < threshold_seconds:
            return True
    return False


_CKPT_URI_RE = re.compile(r"--checkpoint-gcs-uri\s+(\S+)")


def _ckpt_prefix_from_command(cmd: str) -> str | None:
    """Extract the in-bucket checkpoint prefix from a training command's
    `--checkpoint-gcs-uri gs://<bucket>/<prefix>` flag. Returns the part
    after the bucket (e.g. 'ckpts/qwen3_4b_5k_s0/') or None.
    """
    if not cmd:
        return None
    m = _CKPT_URI_RE.search(cmd)
    if not m:
        return None
    uri = m.group(1).strip()
    if not uri.startswith("gs://"):
        return None
    rest = uri[len("gs://"):]
    parts = rest.split("/", 1)
    if len(parts) < 2 or not parts[1]:
        return None
    return parts[1]


def any_job_checkpoint_fresh(store, job, threshold_seconds: float) -> bool:
    """True iff the job's GCS checkpoint directory has a blob written
    within threshold_seconds.

    A fresh checkpoint write is proof the training process is alive AND
    productive, and it is immune to the exact failure mode that makes
    the per-job heartbeat go stale: a multi-GB checkpoint upload
    saturates the box's outbound network and starves the small heartbeat
    PUT, so the heartbeat ages past the orphan threshold WHILE the job
    is demonstrably alive — it is in the middle of writing that very
    checkpoint. Confirmed live 2026-05-16: job 724084db was requeued
    'local agent live but job heartbeat stale (orphan)' at 23:18:29
    while `[ckpt] sync step 1530` had completed at 23:12 and step
    1520->1521 stalled ~1h on the GCS upload; the orphan branch was
    burning the restart budget (15/20) on healthy checkpoint uploads.

    The newest blob under the checkpoint prefix is the liveness signal:
    while a multi-GB checkpoint uploads, its shard blobs are
    continuously updated, so max(updated) stays fresh even mid-upload.
    A genuinely dead job writes zero new checkpoint blobs ever, so it is
    still requeued once both the heartbeat and the checkpoint age out.
    """
    cmd = getattr(job, "command", "") or ""
    return _prefix_has_fresh_blob(
        store, _ckpt_prefix_from_command(cmd), threshold_seconds
    )


def _prefix_has_fresh_blob(store, prefix, threshold_seconds: float) -> bool:
    """True iff any blob under `prefix` was updated within
    threshold_seconds. Shared by the job-object and jids-list checkpoint
    guards. A coordinator-side GCS read/list failure is NOT proof the job
    is dead, so it fails safe (returns True / defers).
    """
    if not prefix:
        return False
    now = time.time()
    try:
        newest = 0.0
        for info in store.list_blobs_with_meta(prefix):
            upd = getattr(info, "updated", None)
            if upd is None:
                continue
            ts = upd.timestamp() if hasattr(upd, "timestamp") else float(upd)
            if ts > newest:
                newest = ts
        if newest <= 0.0:
            return False
        return (now - newest) < threshold_seconds
    except Exception:
        return True


def fresh_jids_pointing_to_ref(store, ref: str) -> list:
    """List jids whose running/ blob has instance_ref == ref, read FRESH
    at call time. Used by reap_dead_agents as the FINAL safety check
    immediately before any delete_instance, to defeat the race that
    burned restart 16 of job 724084db at 2026-05-17T21:26:07: Branch B
    (never-worked) checked `instance_ref not in active_refs` where
    active_refs was a cache built at function entry, list_jobs("running")
    DID NOT return 724084db at that tick (transient listing miss), the
    gate held, the VM was deleted, and _requeue_jids_after_reap got an
    empty jids list (_ref_to_jids came from the same cached listing) —
    so the job was left wedged in running/ pointing at a deleted VM,
    auto-recovery delayed until heartbeat staled.

    On read-error, returns a sentinel non-empty list so the caller
    DEFERS (treats VM as in-use) rather than reaping — same fail-safe
    philosophy as any_job_heartbeat_fresh.
    """
    try:
        out = []
        for j in store.list_jobs("running"):
            if getattr(j, "instance_ref", None) == ref:
                jid = getattr(j, "job_id", None)
                if jid:
                    out.append(jid)
        return out
    except Exception:
        return ["__list_failed__"]


def _job_command_for_jid(store, jid: str) -> str:
    """Best-effort fetch of a job's command string from its running/ or
    queue/ blob, given only the job id (the reaper has jids, not job
    objects)."""
    import json
    for pfx in ("running", "queue"):
        try:
            txt = store._download_text(f"{pfx}/{jid}.json")
        except Exception:
            return ""  # fail-safe handled by caller's defer-on-fresh logic
        if txt:
            try:
                return json.loads(txt).get("command") or ""
            except Exception:
                return ""
    return ""


def any_job_checkpoint_fresh_jids(
    store, jids, threshold_seconds: float
) -> bool:
    """jids-list variant of any_job_checkpoint_fresh, for the
    reap_dead_agents defer-guards (Branches A/B/C) which only have job
    ids, not job objects. True iff ANY job's GCS checkpoint dir has a
    blob written within threshold_seconds — the same
    network-saturation-immune proof-of-life as the orphan-branch guard:
    the multi-GB checkpoint upload that starves the heartbeat IS what
    produces fresh ckpt blobs. Confirmed live 2026-05-17: job 724084db
    was reaped 'VM reaped (wedged agent)' restart 16 at 20:42:17 while
    checkpoint-2480 (17.28 GiB) had finalized 20:31:26 — the wedged
    reaper's heartbeat-only defer-guard lost the race to the
    network-starved heartbeat. Branches A/B/C now also consult this.
    """
    for jid in jids:
        if not jid:
            continue
        prefix = _ckpt_prefix_from_command(_job_command_for_jid(store, jid))
        if _prefix_has_fresh_blob(store, prefix, threshold_seconds):
            return True
    return False


def is_self_terminating_command(cmd: str) -> bool:
    """True if the job command kills the `wc agent` process itself
    (e.g. an upgrade-then-restart maintenance job:
    `pip install --upgrade ... ; pkill -f "wc agent"`).

    For such a command the agent's disappearance is the SUCCESS
    condition, not an orphan failure. The agent dies before it can
    write a COMPLETED status, so the job is stranded in running/ and
    the orphan-reaper requeues it — which re-runs the kill on the
    next agent generation, an infinite crash loop. Confirmed live
    2026-05-15: job 435b184e crash-looped ubuntu-server
    (wisent-agent.service n_restarts=7) until removed by operator.
    """
    if not cmd:
        return False
    return ("pkill" in cmd or "kill " in cmd) and "wc agent" in cmd


def finalize_if_self_terminating(store, job, log_fn) -> bool:
    """If job.command self-terminates the agent, finalize the job as
    COMPLETED (running/ -> completed/) and return True. Otherwise
    return False so the caller proceeds with its normal requeue path.
    """
    from datetime import datetime, timezone
    from ..models import JobState
    if not is_self_terminating_command(getattr(job, "command", "") or ""):
        return False
    job.state = JobState.COMPLETED.value
    job.completed_at = datetime.now(timezone.utc).isoformat()
    job.instance_ref = None
    store.move_job(job, "running", "completed")
    store.cleanup_status(job.job_id)
    log_fn(f"{job.job_id}: COMPLETED (self-terminating maintenance cmd; "
           f"agent kill is the success condition, not an orphan)")
    return True


def build_ref_to_jids(store) -> dict:
    """Build instance_ref -> list[job_id] from store.list_jobs('running').
    Used by the reaper to find which jobs claim each VM ref before the
    heartbeat freshness check.
    """
    out: dict = {}
    running = store.list_jobs("running")
    for j in running:
        ref = getattr(j, "instance_ref", None)
        jid = getattr(j, "job_id", None)
        if ref and jid:
            out.setdefault(ref, []).append(jid)
    return out
