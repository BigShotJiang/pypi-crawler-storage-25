import uiautomation as auto
import tkinter
import time

def move_mouse_to_center():
    # 使用 Python 内置的 tkinter 获取屏幕分辨率
    root = tkinter.Tk()
    width = root.winfo_screenwidth()
    height = root.winfo_screenheight()
    root.destroy() # 关闭临时窗口

    center_x = width // 2
    center_y = height // 2
    
    print(f"屏幕分辨率: {width}x{height}")
    print(f"准备移动到中心: ({center_x}, {center_y})")
    
    time.sleep(0.5)
    # 使用 uiautomation 设置鼠标位置
    auto.SetCursorPos(center_x, center_y)
    print("移动完成！")

if __name__ == "__main__":
    move_mouse_to_center()