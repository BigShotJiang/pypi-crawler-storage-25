Infrastructure

  - ✅ Create RDS PostgreSQL in us-east-1 — db.t3.small, 50GB gp3, Multi-AZ, PostgreSQL 15, 14-day backups, encryption enabled (nrev-lite-db-prod.cmujohywkmxx.us-east-1.rds.amazonaws.com)
  - ✅ Security group — sg-07a61fd3384bfb186, TCP 5432 from VPC CIDR 172.30.0.0/16
  - ✅ Create DB role — nrv_api (consistent with staging)
  - ✅ Apply migrations — 001-008 + 015 applied via prod_combined_001_008_015.sql
  - ✅ Verify ElastiCache connectivity — prod-cache available, SG allows VPC traffic

  ECR & Image

  - ✅ Create ECR repo — nrev-lite-api-prod in us-east-1 (account 979176640062) -  Completed
  - ✅ Build & push image — pushed via GitHub Actions (prod branch created, CI built and pushed to ECR)
  - Update CLI default URL — change DEFAULT_API_BASE_URL in src/nrev_lite/utils/config.py to prod domain

  Kubernetes Secrets

  - Create nrev-lite-api-secret in prod namespace with:
    - ✅ DATABASE_URL (new prod RDS connection string)
    - ✅ JWT_SECRET_KEY (generate fresh: python3 -c 'import secrets; print(secrets.token_urlsafe(48))')
    - ✅ GOOGLE_CLIENT_SECRET
    - ✅ SUPABASE_JWT_SECRET
    - ✅ GTM_ENGINE_SERVICE_TOKEN
    - ✅ PLATFORM_CREDIT_SERVICE_TOKEN
    - ✅ Optional provider keys: APOLLO_API_KEY, ROCKETREACH_API_KEY, RAPIDAPI_KEY, X_RAPIDAPI_KEY, COMPOSIO_API_KEY, etc.

  Google OAuth

  - ✅ Add prod redirect URI in Google Cloud Console — https://nrev-lite-api.public.prod.nurturev.com/api/v1/auth/callback

  DNS & Networking

  - ✅ Create DNS record — wildcard *.public.prod.nurturev.com already routes to prod EKS ingress LB (k8s-nginxing-nginxpub-d5b6b7c73e)

  IAM

  - ✅ Create nrv-api-prod-role IAM role with EKS OIDC trust policy (arn:aws:iam::979176640062:role/nrv-api-prod-role, SA: prod:nrev-lite-api-sa)
  - ✅ Create nrv-api-staging-role IAM role (was missing, created for consistency) (arn:aws:iam::979176640062:role/nrv-api-staging-role, SA: staging:nrev-lite-api-sa)

  Deploy

  - ✅ Run deploy-prod.sh — helm upgrade/install to prod cluster
  - Verify pod health — check /health endpoint responds 200
  - Test full auth flow — Google OAuth login end-to-end
  - Test one enrichment call — verify provider connectivity

  Post-Deploy

  - CloudWatch log sync — set up log aggregation for prod pods
  - ✅ CI/CD — GitHub Actions workflow exists, KUBECONFIG_PROD secret already configured, prod branch created

  ---



  Step 1: Create the nrv database and nrv_api role
  CREATE DATABASE nrv;
  CREATE ROLE nrv_api WITH LOGIN PASSWORD '<choose-a-strong-password>';
  GRANT ALL PRIVILEGES ON DATABASE nrv TO nrv_api;

  Step 2: Connect to the nrv database, then apply migrations 000-016 in order from /Users/nikhilojha/Projects/gtm-engine/migrations/

  Your prod DATABASE_URL for the K8s secret will be:
  postgresql+asyncpg://nrv_api:<password>@nrev-lite-db-prod.cmujohywkmxx.us-east-1.rds.amazonaws.com:5432/nrv


  ---

  Google prod Client id and secret
  id - 284137211338-ji40frb2ltqi77ri1i7jqcbhj2chk5en.apps.googleusercontent.com
  secret - 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