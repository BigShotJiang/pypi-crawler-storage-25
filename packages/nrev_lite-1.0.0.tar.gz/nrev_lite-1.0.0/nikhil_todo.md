
# Full set of requirements
@docs/ Contains the documentation of the architecture and the different  modules in the system.
This repo basically contains two parts of code related to CLI and code related to the server.
The server also hosts a dashboard, which is hosted by a Jinja2 or something, which is a Python dependency which just lets a server Python server return the HTML CSS needed by the browser.

All the deployment-related stuff is completed, and RDS, Redis, etc., are set up already.

@nikhil_todo.md Explains my to-do plan for the application.

Basically, the whole nrev system contains both the CLI(owned in this project, still in beta) and the main web application(Fully productionized, having customers )
The CLI was an experimental project that was done in order to find out if this subset of features that we have in the platform can be exposed via Claude code, which could help us to get quicker eyeballs and solve experimentation faster.
Now that the CLI seems to be working, we want to integrate some functionalities exposed by the CLI into the main platform.

So we'll be introducing a consultant agent inside the application, which will act as the Claude code portion of the CLI application. The CLI will continue to work as it is being done right now. The consultant agent would start using some
portions of the server exposed as part of this repo in order to serve the parts that it needs in the consultant mode.

Details of which portions of the platform are needed in the consultant mode and which portions of the platform are going to override the portions of the CLI are explained in this file


# Current pieces and where they fit in the system

## Authentication(Planned)
- Need to move to our app
- I need to figure out some way to differentiate between the app users and the CLI users in the platform so that the app users do not see CLI dashboards and the CLI users do not see the other parts of the platform which are available to the app users. 
- Auth Module — server/auth/ shiuld be deprecated and moved to main app
- We need to tie  back the tenant management and the user management of this application, back to the application tenant management and user management of the main platform. 

## Credit Management System (Will be owned by platform. Details are TBD)
- Need to move to our app
- We should have a single window for buying credits. 
- We should deprecate Billing Module — server/billing/
- Whenever data enrichment or MCP is done, we should make a call to the main credit management system to cut credits for the user. 
- We would need to expose and use the get_current_balance API from user mgmt - https://github.com/nurturev/user_management/blob/abb9cee5958abc16ebf55d10477be4954cd3da3b/domains/tenant_management/domain_infrastructure/FlexpriceClient.py#L62
    - We would also need to add another API here to cut credits. Let's keep clear of the workflow studio and lets concentrate on user management to call these APIs
    - **user_id** is only used in two places, both for audit logging:
        - CreditLedger — user_id column (nullable) to track who spent credits
        - RunStep — user_id column (nullable) to track who ran what

        It's never used for access control, filtering, or isolation. If credit management moves to the main platform, user attribution moves there too — you could drop user_id from GTM Engine entirely and let the main platform track
        who-spent-what.

## Data Enrichment via APIs(Planned)
- This is the part of the CLI that will also be reused by the consultant agent. 
- Both the consultant agent and the Claude code will keep on making calls to the relevant APIs to fetch data as per experimentation requirements. 
- This should be the  Execution Module — server/execution/

## Connectors via MCP via Composio (Planned)
- Only limited to CLI 
- No need to be exposed in the consultant mode In the first iteration . 
- So, Composio works best. No need to worry about PyDream MCPs. 
- The only thing that we might need to be worried about is to sanitize our skills so that they do not depend on the MCP via Composio. Basically, we will need to divide our skillset into two parts:
    1. One that only uses the data enrichment portions exposed via execution APIs
    2. The other that also uses MCPs

## Vault Module — server/vault/ for BYOK(Planned)
- Only limit it to CLI
- We should leave it as it is. 


## Data Module — server/data/ (Planned)
- Need to understand more about this and whether it is needed to be kept or whether it can be removed, and whether it is limited to CLI or it should be exposed to both CLI and consultant agent. 
- enrichment_logs - will be eventually Replaced by the audit logs /run logs
- Contact/company tables would eventually be replaced by nRev tables. 
- search_results dedup would be solved with a caching layer for results in the middle somewhere? 
- None of these things make a cut in the v1 of the consultant agent that we have planned for now, so they will all continue to be an integral part of only the CLI system.


## Dashboard Module — server/dashboards/ (TBD)
- Only limited to CLI 
- At max, we can think of how we can add it as a hosted iframe inside the application for CLI users. 
- But even that is not mandatory in this particular iteration because the credit management and the authentication can be dealt with separately. 


## Skills
- Which are the skills that we can left-shift and use in the consultant agent, 
- and which are the skills that we would need to fine-tune, change or adapt? - example the ones talking about both connectors and execution /data enrichments.
- All mention of BYOB keys being available when credits are down should be removed from the skills when working with a consultant agent. 
- If any data server usage related things are present in the skills, we will have to exclude them in the consultant skills as well. 

## Reduce CLI MCP context bloat
- The MCP is over-scoped. 33 tools is a lot of context. Many of them (nrev_health, nrev_credit_balance, nrev_list_datasets) are simple CLI commands dressed up as MCP tools for no real benefit.
- A leaner approach would be:

  CLI (with --json flags)     → simple CRUD, queries, status checks
  MCP (5-8 tools max)         → multi-step workflows, bulk ops, app actions

  The tools that need to be MCP:
  - nrev_search_people + nrev_enrich_* (workflow chaining)
  - nrev_create_and_populate_dataset (bulk structured data)
  - nrev_app_actions / nrev_app_action_schema / nrev_app_execute (dynamic discovery)
  - nrev_google_search (bulk queries param)

  The rest? nrev-lite credits balance --json via Bash is identical and costs zero context tokens.


## E2E FE to backend to GTM-ENGINE contract 


# Todos
- Add more Composio MCP for Experimentation Mode.
- Prepare a proper test plan for CLI
- Prepare a plan for the consultant agent and what parts of it will be needed to be built additionally, along with the parts that can be loaded from here. 



- Credit consumption with CLI kaise tie back karega into the current system.