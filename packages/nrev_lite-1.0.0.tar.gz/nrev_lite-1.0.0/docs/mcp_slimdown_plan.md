# Plan: Slim Down MCP Tool Surface (Cheapest Path)

## Context

The nrev-lite MCP server exposes **36 tools**. Many are simple CRUD/status operations that the CLI already handles. The MCP adds context bloat (deferred tool list entries + full schemas when loaded + CLAUDE.md documentation) without meaningful benefit for these simple tools. The goal is to remove tools that don't earn their context cost, with minimal effort and zero disruption to existing workflows.

Community consensus: well-known CLIs with structured output (like `gh`, `aws`) don't need MCPs. nrev-lite's MCP is justified for complex/multi-step operations but not for simple queries.

---

## Approach: Single Tier — Remove 13 tools, keep 23

Remove tools that are **redundant, trivially CLI-replaceable, or rarely used in workflows**. No CLI code changes needed — existing CLI commands already work for these.

### Tools to REMOVE (13 tools, ~36% reduction)

| # | Tool | Why Remove | CLI Replacement |
|---|------|-----------|-----------------|
| 1 | `nrev_health` | Diagnostic only, no skill depends on it | `nrev-lite status` |
| 2 | `nrev_open_console` | Just opens a URL | `nrev-lite console` or `open <url>` |
| 3 | `nrev_create_dataset` | Fully redundant — `create_and_populate_dataset` handles empty creates too (idempotent) | `nrev_create_and_populate_dataset` with empty rows |
| 4 | `nrev_provider_status` | Status check, no skill workflow uses it | `nrev-lite status` |
| 5 | `nrev_estimate_cost` | Credit costs are already hardcoded in CLAUDE.md (1 credit/op). Claude can do arithmetic | Mental math / CLAUDE.md reference |
| 6 | `nrev_app_catalog` | Browse available apps — one-time discovery, not workflow-critical | `nrev-lite apps available` |
| 7 | `nrev_list_tables` | Simple listing | `nrev-lite table list` |
| 8 | `nrev_query_table` | Simple query | `nrev-lite query <table> --json-output` (already has --json) |
| 9 | `nrev_delete_dataset` | Rare destructive op | `nrev-lite datasets delete <slug>` |
| 10 | `nrev_delete_dataset_rows` | Rare destructive op | `nrev-lite datasets delete-rows <slug>` (needs minor CLI addition) |
| 11 | `nrev_update_dataset` | Rare metadata update | `nrev-lite datasets update <slug>` (needs minor CLI addition) |
| 12 | `nrev_search_web` | Redundant with `nrev_google_search` which is strictly better (bulk, time filters, site:) | `nrev_google_search` covers all use cases |
| 13 | `nrev_log_learning` | Admin-only, experimental, rarely triggered | Can defer to CLI or direct API later |

### Tools to KEEP (23 tools)

**Core workflow tools (can't be CLI'd easily):**
- `nrev_google_search` — bulk queries, complex params
- `nrev_scrape_page` — bulk URLs, objective param
- `nrev_enrich_person` — workflow chaining
- `nrev_enrich_company` — workflow chaining
- `nrev_search_people` — complex filter params
- `nrev_create_and_populate_dataset` — bulk structured data
- `nrev_append_rows` — bulk row insertion

**App actions (dynamic discovery, can't be CLI'd):**
- `nrev_app_list` — needed before app actions
- `nrev_app_connect` — OAuth flow
- `nrev_app_actions` — dynamic discovery
- `nrev_app_action_schema` — dynamic schema
- `nrev_app_execute` — dynamic execution

**Workflow lifecycle (session state):**
- `nrev_new_workflow` — creates workflow ID, held in MCP memory
- `nrev_get_run_log` — reviews workflow output
- `nrev_credit_balance` — called silently before every plan
- `nrev_search_patterns` — called before every google search

**Dataset read ops (frequently chained in workflows):**
- `nrev_list_datasets` — needed to find slugs before append/query
- `nrev_query_dataset` — frequently used mid-workflow

**Scripts (complex params):**
- `nrev_save_script` — nested steps/params structure
- `nrev_list_scripts` — needed before get_script
- `nrev_get_script` — loads full definition

**Other:**
- `nrev_deploy_site` — complex files dict param
- `nrev_get_knowledge` — lightweight lookup, used in experimental protocol

---

## Changes Required

### 1. `src/nrev_lite/mcp/server.py` — Remove 13 tool definitions + handlers
- Delete entries from `TOOLS` list (lines 162-1280)
- Delete entries from `TOOL_HANDLERS` dict (lines 2285-2322)
- Delete handler functions for all 13 removed tools

### 2. `CLAUDE.md` — Update tool table and guidance
- Remove 13 tools from the MCP Tools table
- Add a new section: "CLI Commands (use via Bash)" listing the removed tools and their CLI equivalents
- Update the "Free tools" list in the plan approval section
- Remove `nrev_search_web` from any guidance (replaced by `nrev_google_search`)

### 3. Skills — Minimal updates (3 files)
- `.claude/skills/gtm-builder/SKILL.md` — Remove references to `nrev_estimate_cost`, `nrev_search_web`, `nrev_log_learning`
- `.claude/skills/composio-connections/SKILL.md` — Remove `nrev_open_console` reference
- `.claude/skills/tool-skills/parallel-web-quirks.md` — Remove `nrev_search_web` reference

### 4. No CLI code changes needed
- All replacement CLI commands already exist and work
- Claude can parse their terminal output (same as it does with `gh` and `aws`)

---

## What this does NOT change
- No server API changes
- No CLI code changes
- No database changes
- No user-facing workflow changes (all operations still work, just via CLI instead of MCP)

## Context savings estimate
- ~36% fewer tools (13 of 36)
- ~40% less schema text (removed tools include verbose ones like `nrev_log_learning`, `nrev_estimate_cost`, `nrev_app_catalog`)
- CLAUDE.md tool table shrinks proportionally
- Deferred tool list in system prompt drops 13 entries

## Verification
1. Start the MCP server and verify only 23 tools are listed
2. Test a full workflow: search people -> enrich -> save to dataset (core path unchanged)
3. Test CLI replacements: `nrev-lite status`, `nrev-lite table list`, `nrev-lite apps available`
4. Test that `nrev_create_and_populate_dataset` works with empty rows
5. Verify skills load correctly and don't reference removed tools
