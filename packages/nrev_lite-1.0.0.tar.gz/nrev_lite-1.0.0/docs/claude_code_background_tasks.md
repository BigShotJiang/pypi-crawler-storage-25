Background tasks in Claude Code:
    1. When I run a command with run_in_background, the CLI doesn't block — you can keep chatting or just leave the terminal idle.
    2. When the background task completes, the system notifies me (the agent) automatically.
    3. If you're still in the session, I pick up from where I left off and report the result.
    4. If you've been idle, the notification wakes up the conversation and I respond with the update.

    Key behaviors for your CLI design:
    - The user doesn't need to poll or ask "is it done yet?" — the notification is push-based.
    - Multiple background tasks can run concurrently.
    - The output is written to a temp file and read back when complete.
    - I'm told not to sleep-poll for it — I just get notified.

    For your own CLI + MCP integration:
    The pattern you'd want is: your MCP tool returns immediately with a "task started" acknowledgment, then uses whatever notification mechanism Claude Code's MCP protocol supports to signal completion. The key UX principle is that the
    agent shouldn't block the user's ability to interact while long-running operations (like your API calls to enrichment providers, batch operations, etc.) are in progress.

    The 30-second-ish timeout on normal tool calls is why run_in_background exists — it's specifically for operations like your RDS creation that take minutes, not seconds.


