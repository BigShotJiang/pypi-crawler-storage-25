# nrv Plugin Migration Plan

## What stays the same

The FastAPI server, database, billing, auth, provider routing — **all unchanged**. The plugin is purely a new packaging layer for the client-side components that already exist.

## Current Architecture (CLI)

```
User installs Python package (pip install nrv)
  → nrv init (OAuth login + registers MCP in ~/.claude/settings.json)
  → Claude Code spawns `nrv mcp serve` as stdio process
  → MCP server reads ~/.nrv/credentials, talks to FastAPI server
  → Skills live in .claude/skills/ (copied by nrv setup-claude)
```

**Friction points**: requires Python 3.10+, pip install, PATH configuration, manual `nrv init`.

## Target Architecture (Plugin)

```
User runs /plugin install nrv (from marketplace)
  → Plugin registers MCP server config + skills + hooks automatically
  → On first tool call, auth hook triggers browser OAuth
  → MCP server talks to FastAPI server (HTTP transport, no Python needed)
  → Skills bundled in plugin, no separate copy step
```

## What needs to be built

### 1. Plugin Manifest & Directory Structure

Create the plugin package:

```
nrv-plugin/
├── .claude-plugin/
│   ├── plugin.json              # NEW: manifest
│   └── marketplace.json         # NEW: if publishing own marketplace
├── skills/                      # MOVE: from .claude/skills/ (all 16 skills)
│   ├── gtm-consultant/
│   ├── gtm-builder/
│   ├── tool-skills/
│   ├── google-search/
│   ├── waterfall-enrichment/
│   ├── provider-selection/
│   ├── parallel-research/
│   ├── list-building/
│   ├── scraping-tools/
│   ├── apollo-enrichment/
│   ├── rocketreach-enrichment/
│   ├── composio-connections/
│   ├── instantly-campaigns/
│   ├── humanizer/
│   └── gtm-workflows/
├── .mcp.json                    # NEW: MCP server config (HTTP transport)
├── hooks/
│   └── hooks.json               # NEW: auth check hook
└── settings.json                # NEW: default permissions
```

**Effort**: Small. Mostly moving existing files + writing manifest.

### 2. HTTP Transport for MCP Server (the big one)

**Current state**: MCP server only supports stdio (JSON-RPC over stdin/stdout). This requires the Python package installed locally.

**What's needed**: An HTTP-based MCP endpoint hosted on your FastAPI server so the plugin can point to a URL instead of a local command.

Two options:

#### Option A: Server-side MCP HTTP endpoint (recommended)

Add an HTTP MCP endpoint to the existing FastAPI server:

```
POST https://nrv-api.public.prod.nurturev.com/mcp
```

This endpoint would:
- Accept JSON-RPC 2.0 requests (same format as current stdio)
- Authenticate via Bearer token (same JWT as current API)
- Route to the same tool handlers that exist in `src/nrv/mcp/server.py`
- Return JSON-RPC responses

The plugin's `.mcp.json` would then be:
```json
{
  "mcpServers": {
    "nrv": {
      "type": "http",
      "url": "https://nrv-api.public.prod.nurturev.com/mcp",
      "headers": {
        "Authorization": "Bearer ${NRV_TOKEN}"
      }
    }
  }
}
```

**What to build**:
- New FastAPI route `/mcp` that accepts MCP JSON-RPC requests
- Move tool handler logic from `src/nrv/mcp/server.py` into server-side handlers (or proxy to existing API endpoints)
- Workflow ID management server-side instead of in-process global

**Effort**: Medium-Large. The tool handlers currently live in the Python client and call the API via HTTP. You'd need to either:
- (a) Reimplement handlers server-side (cleaner, but more work), or
- (b) Create a thin MCP-to-REST translator on the server that maps MCP tool calls to existing `/api/v1/*` endpoints (less work, keeps existing API surface)

Option (b) is strongly recommended — it's a ~200-line FastAPI router that maps tool names to existing REST endpoints.

#### Option B: Keep stdio, bundle a lightweight binary

Ship a small pre-built binary (Go/Rust) or Node.js script in the plugin that handles stdio MCP and proxies to your server. Avoids Python dependency but still needs a local process.

```json
{
  "mcpServers": {
    "nrv": {
      "command": "node",
      "args": ["${PLUGIN_DIR}/mcp-proxy.js"]
    }
  }
}
```

**Effort**: Small-Medium. But requires Node.js on the user's machine (usually present).

### 3. Authentication Without CLI

Currently: `nrv init` opens a browser for Google OAuth, stores tokens in `~/.nrv/credentials`.

For the plugin, users won't run `nrv init`. You need one of:

#### Option A: Auth hook (recommended)

A hook that checks for credentials before any MCP tool call and triggers auth if missing:

```json
// hooks/hooks.json
{
  "hooks": [
    {
      "event": "on_tool_call",
      "pattern": "nrv_*",
      "command": "nrv auth ensure"
    }
  ]
}
```

This requires keeping a minimal `nrv` CLI or a small auth script bundled in the plugin.

#### Option B: Dashboard-based token generation

- User logs into the nrv web dashboard
- Copies an API token
- Pastes into Claude Code when prompted (or sets `NRV_TOKEN` env var)
- Plugin reads token from env

**Effort**: Small. Dashboard already exists. Just need a "Generate API Token" page and the plugin reads from env.

#### Option C: OAuth in MCP (if supported)

The MCP spec supports OAuth flows. If Claude Code's plugin system supports MCP auth, the server handles the OAuth dance directly.

**Effort**: Depends on Claude Code's support for MCP auth flows. Worth investigating.

### 4. Plugin Manifest

```json
// .claude-plugin/plugin.json
{
  "name": "nrv",
  "description": "GTM execution platform — enrich, search, scrape, and build prospect lists",
  "version": "0.1.0",
  "author": {
    "name": "nRev",
    "url": "https://nurturev.com"
  },
  "keywords": ["gtm", "enrichment", "sales", "prospecting", "leads"]
}
```

**Effort**: Trivial.

### 5. Marketplace Publishing

To make the plugin discoverable:

```json
// .claude-plugin/marketplace.json
{
  "plugins": ["nrv"]
}
```

Publish the plugin repo to GitHub. Users add it via:
```
/plugin marketplace add nrev/nrv-plugin
/plugin install nrv
```

Or submit to the official Anthropic marketplace for wider discovery.

**Effort**: Small.

### 6. Default Permissions

```json
// settings.json
{
  "permissions": {
    "allow": [
      "mcp__nrv__*"
    ]
  }
}
```

So users don't get prompted for every single MCP tool call.

**Effort**: Trivial.

## Summary: Work Items

| Item | What | Effort | Blocks launch? |
|------|------|--------|----------------|
| Plugin manifest + structure | Create `plugin.json`, move skills into plugin dir | Small | Yes |
| MCP HTTP endpoint | Server-side MCP-to-REST translator (~200 lines) | Medium | Yes (if dropping Python dep) |
| Auth without CLI | Dashboard token page OR bundled auth script | Small | Yes |
| Marketplace config | `marketplace.json` + GitHub repo setup | Trivial | No (can test locally first) |
| Default permissions | `settings.json` with MCP tool allowlist | Trivial | No |
| Skill migration | Copy 16 skill folders into plugin structure | Trivial | Yes |
| Hooks for auth check | Pre-tool-call credential verification | Small | No (nice to have) |

## Recommended Build Order

1. **Plugin scaffold** — manifest, move skills, test locally with `claude --plugin-dir ./nrv-plugin`
2. **MCP HTTP endpoint** — server-side translator, test with HTTP transport in `.mcp.json`
3. **Auth flow** — dashboard token generation, env var injection
4. **Marketplace publish** — GitHub repo, submit to official marketplace

## What you can skip

- **No changes to**: FastAPI server, database, billing, provider routing, credit system, RLS, vault
- **No changes to**: skill content (just move the files)
- **No changes to**: tool definitions (same 24 tools, same schemas)
- **CLI continues to work**: plugin is an additional distribution channel, not a replacement
