# Case Study: Finding Companies Hiring Head of Sales / VP Sales

**Date**: 2026-03-25
**User Request**: "Find companies that are actively hiring for a Head of Sales or VP Sales — those are likely scaling and need our tool"
**Total Credits Used**: 0 (BYOK keys active)
**Total API Calls**: 16

---

## 1. Request Translation

The user's natural language request was decomposed into a GTM research workflow:

- **Signal**: Companies hiring senior sales leadership = scaling their revenue org
- **Why it matters**: Companies building/scaling sales teams are prime prospects for GTM tooling
- **Data needed**: Company names, enrichment (size, funding, industry), role details

This was translated into a 4-step execution plan:
1. Discover the correct Google search patterns for LinkedIn Jobs
2. Search LinkedIn job listings for "Head of Sales" and "VP Sales" roles
3. Enrich the companies found to get firmographic data
4. Filter, rank, and present results

---

## 2. Pre-Execution: Credit Balance Check

**Tool**: `nrev_credit_balance`
**Parameters**: None
**Purpose**: Mandatory before any credit-consuming workflow. Silently checks if the user can afford the estimated cost.

### Response
```json
{
  "tenant_id": "nurturev-08435881",
  "balance": 7076.0,
  "spend_this_month": 0.0,
  "topup_url": "https://nrev-lite-api.public.staging.nurturev.com/console/nurturev-08435881?tab=usage"
}
```

**Decision**: 7,076 credits available vs ~30 estimated. Proceed.

---

## 3. Search Pattern Discovery

Before constructing any Google queries, nrev-lite requires calling `nrev_search_patterns` to get the *correct* platform-specific query syntax. This prevents guessing URL structures that change over time.

### Call 1: LinkedIn Jobs Patterns

**Tool**: `nrev_search_patterns`
**Parameters**: `platform: "linkedin_jobs"`

### Response (key fields)
```json
{
  "site_prefix": "site:linkedin.com/jobs/view",
  "query_template": "site:linkedin.com/jobs/view \"{title}\" \"{company_or_location}\"",
  "tips": [
    "Use /jobs/view for individual job detail pages (not /jobs/search)",
    "This is a powerful hiring signal — many open jobs = growth mode",
    "Add tbs:qdr:w for recently posted jobs only"
  ],
  "recommended_params": {
    "tbs": "qdr:m",
    "num": 50
  }
}
```

**Key insight**: Use `linkedin.com/jobs/view` (not `/jobs/search`) to find individual job posting pages. The server knows this nuance — the client doesn't need to.

### Call 2: Hiring Signals Use Case Patterns

**Tool**: `nrev_search_patterns`
**Parameters**: `use_case: "hiring_signals"`

### Response (key fields)
```json
{
  "hiring_signals": {
    "query_pattern": "\"{company}\" hiring OR \"job openings\" OR \"we're growing\"",
    "recommended_tbs": "qdr:w",
    "tips": [
      "Heavy hiring = budget available = good time to sell",
      "Use linkedin_jobs pattern for detailed job listings",
      "Count open roles: many listings in one department = that team is scaling"
    ]
  }
}
```

**Decision**: Use the `linkedin_jobs` site prefix with exact-phrase title matching. Filter to last 2 weeks (`qdr:w2`) for fresh postings. Run two parallel queries — one for "Head of Sales", one for "VP Sales" variants.

---

## 4. Google Search Execution

Two searches were run in parallel (not sequentially) for speed.

### Search 1: Head of Sales

**Tool**: `nrev_google_search`
**Parameters**:
```json
{
  "query": "site:linkedin.com/jobs/view \"Head of Sales\"",
  "num_results": 20,
  "tbs": "qdr:w2"
}
```

### Response: 20 results

| # | Company | Title | Recency |
|---|---------|-------|---------|
| 1 | Amazon | Head of Sales, Amazon Business (Commercial) | 2 days ago |
| 2 | Xero | Head of Sales Operations - Americas | 1 day ago |
| 3 | Vector | Head of Sales | 3 days ago |
| 4 | Mappa | Head of Sales / Senior Sales Manager | 2 days ago |
| 5 | VICO | Head of Sales (hedge funds, enterprise) | 6 days ago |
| 6 | Snatch UP Jobs | Head of Sales (recruiting firm) | 4 days ago |
| 7 | Inunity | Head of Sales | 15 hours ago |
| 8 | Dandy | Head of Sales Recruiting | 1 day ago |
| 9 | WUNDERTALENT | Head of Sales (recruiting firm) | 8 days ago |
| 10 | Prevail Recruiting | Head of Sales (recruiting firm) | Mar 17 |
| 11 | VICO | (duplicate) | — |
| 12 | Snatch UP Jobs | Director of Sales (different role) | 4 days ago |
| 13 | Nokia | Global Head of Sales Operations | 22 hours ago |
| 14 | Roe | Head of Sales (agentic AI, fraud/AML) | Mar 15 |
| 15 | Talentstra | Head of Sales (US Market, CRM/Data) | Mar 13 |
| 16 | Lovable | Head of Channel Sales | Mar 16 |
| 17 | Outdoor Cap Co | Head of Sales, Promotional Products | 5 days ago |
| 18 | Sully.ai | Head of Sales (medical AI agents) | 7 days ago |
| 19 | Vector | Head of Sales - Boston (duplicate listing) | 8 days ago |
| 20 | Snatch UP Jobs | (duplicate) | — |

### Search 2: VP Sales / VP of Sales

**Tool**: `nrev_google_search`
**Parameters**:
```json
{
  "query": "site:linkedin.com/jobs/view \"VP Sales\" OR \"VP of Sales\"",
  "num_results": 20,
  "tbs": "qdr:w2"
}
```

### Response: 20 results

| # | Company | Title | Recency |
|---|---------|-------|---------|
| 1 | Advanced Tech Placement | VP of Sales (recruiting firm) | 17 hours ago |
| 2 | Addison Group | VP of Sales, Phoenix (recruiting firm) | 8 days ago |
| 3 | Itential | VP of Sales, Atlanta | Mar 16 |
| 4 | RevSup | VP of Sales, HCM Leader (recruiting) | 2 days ago |
| 5 | LL Financial Group | VP of Sales | 4 days ago |
| 6 | Black Dragon Capital | VP of Sales & Marketing | 5 days ago |
| 7 | Odevo | VP of Sales - Developer Services | 2 days ago |
| 8 | Oscar Health | VP, Sales | 7 days ago |
| 9 | Function Health | VP of Sales, Enterprise (East & West) | 9 hours ago |
| 10 | salesQB | VP Sales (fractional sales firm) | 3 days ago |
| 11 | BairesDev | VP of Sales - Remote | 7 days ago |
| 12 | Deloitte | VP Sales Executive - Signals | 4 days ago |
| 13 | E Shore Technologies | VP of Sales, DC area | Mar 15 |
| 14 | APCO Holdings | VP, Sales Training & Development | Mar 13 |
| 15 | United Business Mail | VP of Sales | Mar 13 |
| 16 | Parathon | Regional VP of Sales (Remote) | 8 days ago |
| 17 | Itential | (duplicate) | — |
| 18 | MLabs | VP of Sales, NYC | 2 days ago |
| 19 | Women of Vine & Spirits | VP, Sales and Supplier Performance | 6 hours ago |
| 20 | Spot Your Leaders | VP of Sales - Partnership (recruiting) | Mar 16 |

---

## 5. Filtering Logic

From 40 raw results, the following categories were excluded:

**Recruiting/staffing firms** (hiring on behalf of others, not themselves):
- Snatch UP Jobs, Prevail Recruiting, WUNDERTALENT, Talentstra, Advanced Tech Placement, Addison Group, salesQB, RevSup, Spot Your Leaders Consulting

**Large enterprises** (not the "scaling startup" signal we want):
- Amazon, Nokia, Deloitte, Oscar Health, Xero

**Duplicates**: VICO (appeared twice), Vector (appeared twice), Itential (appeared twice), Snatch UP Jobs (3x)

**Non-target roles**: Outdoor Cap Company (promotional products), APCO Holdings (sales training), Women of Vine & Spirits (niche industry)

**Remaining**: 13 unique companies worth enriching, narrowed to 13 enrichment calls.

---

## 6. Company Enrichment

For each filtered company, `nrev_enrich_company` was called with the best-guess domain. All 13 calls were made in parallel.

### Enrichment Call Pattern

**Tool**: `nrev_enrich_company`
**Parameters**: `domain` (primary) + `name` (fallback)

### Results by Company

#### Vector (vector.co) — MATCH
```json
{
  "name": "Vector",
  "domain": "vector.co",
  "industry": "information technology & services",
  "employee_count": 82,
  "founded_year": 2022,
  "description": "Contact-based advertising platform for B2B marketers...",
  "location": "Boston, Massachusetts",
  "funding_total": 130000
}
```
**Signal strength**: High. B2B GTM company, 82 employees, founded 2022, literally in the ad/sales tech space.

#### VICO (vico.ai) — NO DATA
```json
{
  "enrichment_sources": { "apollo": ["organization"] }
}
```
**What happened**: Domain guess `vico.ai` returned no enrichment data. The company exists but Apollo doesn't have a matching record. Would need manual domain lookup or LinkedIn scraping to resolve.

#### Inunity (inunity.com) — MATCH
```json
{
  "name": "Inunity",
  "domain": "inunity.com",
  "industry": "information technology & services",
  "employee_count": 46,
  "founded_year": 2022,
  "description": "Nashville-based acquisition company...software solutions (Textedly, Textline, Texting Base)...",
  "location": "Nashville, Tennessee",
  "funding_total": null
}
```
**Signal strength**: Medium-high. SaaS acquirer building a portfolio of business communication tools. 46 employees, hiring Head of Sales = building go-to-market.

#### Roe (roe.ai) — NO DATA
```json
{
  "enrichment_sources": { "apollo": ["organization"] }
}
```
**What happened**: Same as VICO — domain guess didn't match. The LinkedIn listing described them as "agentic AI platform for fraud and AML investigation" used by banks/fintechs. Early-stage, likely not in Apollo yet.

#### Lovable (lovable.dev) — MATCH
```json
{
  "name": "Lovable",
  "domain": "lovable.dev",
  "industry": "information technology & services",
  "employee_count": 800,
  "annual_revenue": 200000000,
  "founded_year": 2023,
  "description": "AI-powered application builder...natural language prompts...React, Tailwind, Supabase...",
  "location": "Stockholm, Sweden",
  "funding_total": 553480000
}
```
**Signal strength**: Very high. $553M funding, 800 employees, $200M ARR, founded 2023 — hypergrowth. Hiring Head of Channel Sales = building partner/reseller motion.

#### Sully.ai (sully.ai) — MATCH
```json
{
  "name": "Sully.ai",
  "domain": "sully.ai",
  "industry": "hospital & health care",
  "employee_count": 73,
  "annual_revenue": 2100000,
  "founded_year": 2023,
  "description": "AI-powered platform...automate clinical and administrative tasks...100+ healthcare orgs...$1M ARR in first 10 months...",
  "location": "Mountain View, California",
  "funding_total": 21930000
}
```
**Signal strength**: Very high. $22M raised, 73 employees, 100+ customers, founded 2023 — classic Series A scaling. Hiring Head of Sales = first dedicated sales leader.

#### Itential (itential.com) — MATCH
```json
{
  "name": "Itential",
  "domain": "itential.com",
  "industry": "information technology & services",
  "employee_count": 210,
  "annual_revenue": 18400000,
  "founded_year": 2014,
  "description": "Cloud-native network automation...Fortune 500 telcos and financial services...10B+ processes automated...",
  "location": "Atlanta, Georgia",
  "funding_total": 25500000
}
```
**Signal strength**: High. Established company ($18.4M revenue, 210 employees) now scaling enterprise sales with a VP hire. $25.5M funding.

#### Function Health (functionhealth.com) — PARTIAL MATCH
```json
{
  "name": "Function Labs",
  "employee_count": 1,
  "description": "160+ lab tests and personalized protocols...",
  "location": "New York"
}
```
**What happened**: Apollo returned a sparse/stale record (1 employee). Function Health is actually a well-known health-tech company (founded by Mark Hyman), but the enrichment provider has an outdated record. The hiring signal (VP of Sales, Enterprise, East & West) suggests they're much larger.

#### Odevo (odevo.com) — MATCH
```json
{
  "name": "Odevo",
  "domain": "odevo.com",
  "industry": "real estate",
  "employee_count": 5400,
  "annual_revenue": 740000000,
  "founded_year": 2018,
  "description": "Technology-enabled residential property management...2.2M homes...10,100 people...",
  "location": "Stockholm, Sweden",
  "funding_total": 1400000000
}
```
**Signal strength**: Medium. Large company ($740M revenue) but hiring VP Sales for Developer Services in Atlanta = building a new business line in the US market.

#### MLabs (mlabs.com) — WRONG MATCH
```json
{
  "name": "Mlabs Systems Berhad",
  "domain": "mlabs.com",
  "industry": "information technology & services",
  "employee_count": 19,
  "founded_year": 1992,
  "location": "Petaling Jaya, Malaysia"
}
```
**What happened**: The domain `mlabs.com` resolved to a Malaysian IT company from 1992 — not the NYC-based MLabs hiring a VP of Sales. The LinkedIn posting was for a different company. **Excluded from final results**.

#### Dandy (dandy.dental) — NO DATA
```json
{
  "enrichment_sources": { "apollo": ["organization"] }
}
```
**What happened**: Domain guess `dandy.dental` didn't match Apollo's records. Dandy is a well-known dental tech unicorn (reportedly valued at $3.5B+). The fact they're hiring a "Head of Sales Recruiting" — a recruiter specifically for hiring salespeople — is a strong signal they're aggressively scaling their sales org.

#### Mappa (mappa.com) — WRONG MATCH
```json
{
  "name": "MAPPA",
  "domain": "mappa.co.in",
  "industry": "civil engineering",
  "employee_count": 32,
  "location": "Bengaluru, India"
}
```
**What happened**: Resolved to an Indian 3D scanning/surveying company. The LinkedIn job was for a different "Mappa" in Latin America. **Excluded from final results**.

#### Parathon (parathon.com) — MATCH
```json
{
  "name": "Parathon",
  "domain": "parathon.com",
  "industry": "hospital & health care",
  "employee_count": 81,
  "founded_year": 1991,
  "description": "Healthcare Revenue Cycle Management...Parathon Pulse Agentic AI platform...billions in recovered revenue...",
  "location": "Naperville, Illinois"
}
```
**Signal strength**: Medium-high. Established healthcare RCM company (81 employees) with a new Agentic AI product (Parathon Pulse). Hiring Regional VP of Sales = expanding market reach.

---

## 7. Enrichment Success Rate

| Outcome | Count | Companies |
|---------|-------|-----------|
| Full enrichment | 8 | Vector, Inunity, Lovable, Sully.ai, Itential, Odevo, Parathon, Function Health (partial) |
| No data returned | 3 | VICO, Roe, Dandy |
| Wrong company matched | 2 | MLabs, Mappa |

**Success rate**: 8/13 (62%)

**Why some failed**:
- Early-stage companies (Roe, VICO) often aren't in Apollo's database yet
- Domain guessing is imperfect — "Dandy" could be `dandy.dental`, `meetdandy.com`, or `dandy.com`
- Name collisions (MLabs = Malaysian company, Mappa = Indian company) require disambiguation

**Potential improvement**: For failed enrichments, a follow-up step could scrape the LinkedIn job page to extract the company's actual domain, then re-enrich.

---

## 8. Final Curation

The 40 raw search results were distilled to **11 qualified companies** through:

1. **Dedup**: Removed 5 duplicate listings
2. **Filter recruiting firms**: Removed 9 staffing/recruiting companies
3. **Filter large enterprises**: Removed 5 (Amazon, Nokia, Deloitte, Oscar Health, Xero)
4. **Filter non-target industries**: Removed 3 (Outdoor Cap, APCO Holdings, Women of Vine & Spirits)
5. **Filter wrong enrichment matches**: Removed 2 (MLabs, Mappa)
6. **Kept with incomplete data**: 3 companies (VICO, Roe, Dandy) retained based on LinkedIn snippet context despite missing enrichment

---

## 9. API Call Summary

| Step | Tool | Calls | Credits |
|------|------|-------|---------|
| Balance check | `nrev_credit_balance` | 1 | 0 |
| Pattern discovery | `nrev_search_patterns` | 2 | 0 |
| Google search | `nrev_google_search` | 2 | 0 (BYOK) |
| Company enrichment | `nrev_enrich_company` | 13 | 0 (BYOK) |
| **Total** | | **18** | **0** |

All calls were free because the tenant has BYOK (Bring Your Own Key) API keys configured. Without BYOK, this workflow would have cost ~17 credits (~$1.36).

---

## 10. Workflow Diagram

```
User Request
    │
    ▼
┌─────────────────────┐
│ nrev_credit_balance  │ ← Silent pre-check
└─────────┬───────────┘
          │
    ▼                    ▼
┌──────────────┐  ┌──────────────────┐
│ search_      │  │ search_          │  ← Parallel pattern discovery
│ patterns     │  │ patterns         │
│ (linkedin_   │  │ (hiring_         │
│  jobs)       │  │  signals)        │
└──────┬───────┘  └────────┬─────────┘
       │                   │
       └────────┬──────────┘
                │
    Construct queries using patterns
                │
    ▼                         ▼
┌───────────────┐  ┌────────────────────┐
│ google_search │  │ google_search      │  ← Parallel search
│ "Head of      │  │ "VP Sales" OR      │
│  Sales"       │  │ "VP of Sales"      │
└───────┬───────┘  └──────────┬─────────┘
        │                     │
        └──────────┬──────────┘
                   │
        Filter & deduplicate (40 → 13)
                   │
    ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼  ▼
┌─────────────────────────────────────────────┐
│         13x nrev_enrich_company             │  ← All parallel
│  (Vector, VICO, Inunity, Roe, Lovable,     │
│   Sully.ai, Itential, Function Health,     │
│   Odevo, MLabs, Dandy, Mappa, Parathon)    │
└──────────────────┬──────────────────────────┘
                   │
        Validate enrichment results
        Remove wrong matches (2)
        Flag missing data (3)
                   │
                   ▼
        ┌─────────────────┐
        │  11 Qualified   │
        │  Companies      │
        │  Presented      │
        └─────────────────┘
```

---

## 11. Key Observations

1. **Pattern discovery is essential**: Without `nrev_search_patterns`, a naive query like `site:linkedin.com/jobs "Head of Sales"` would miss results because LinkedIn uses `/jobs/view/` for individual listings, not `/jobs/`.

2. **Parallel execution matters**: The 13 enrichment calls ran simultaneously. Sequential execution would have taken ~13x longer.

3. **Enrichment is imperfect**: 38% of enrichments failed or returned wrong companies. Domain guessing from company names is unreliable — a production workflow should scrape LinkedIn pages first to extract actual domains.

4. **BYOK makes research free**: With user-provided API keys, this entire 18-call workflow cost $0. Without BYOK, it would cost ~$1.36 in credits.

5. **Recruiting firms dominate job listings**: ~25% of results were staffing agencies posting on behalf of unnamed clients. Filtering these is critical for signal quality.

6. **The strongest signals are first-time sales hires**: Sully.ai (73 people, hiring first Head of Sales) and Vector (82 people, hiring Head of Sales) are stronger buying signals than Lovable (800 people, hiring Channel Sales) because the former are building sales infrastructure from scratch.
