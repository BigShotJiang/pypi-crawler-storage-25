# nrev-lite v1 Release Checklist

First prod release of `nrev-lite` (API + CLI). End goal:

```bash
pip install nrev-lite
nrev-lite init
```

PyPI name `nrev-lite` is **available** (confirmed: `pypi.org/pypi/nrev-lite/json` → 404).

---

## 🔴 Blockers in this branch (fix before merging to `main`)

- [x] **Remove duplicated `NREV_LITE_DIR` block** in `src/nrev_lite/utils/config.py:19-30` (the block appears twice — bad merge artifact).
- [x] **Fix repo URL** in `pyproject.toml:50` — changed to `https://github.com/nurturev/gtm-engine`.
- [x] **Bump version** in `pyproject.toml:7` — bumped to `1.0.0`.
- [x] **(Optional) Move `Development Status`** in `pyproject.toml:17` — changed to `4 - Beta`.

---

## 🔑 Env vars / k8s secrets to add in prod

New code in this branch uses `settings.PLATFORM_CREDIT_SERVICE_URL` (`server/auth/platform_access_service.py:52,66`). The deployment checklist lists `PLATFORM_CREDIT_SERVICE_TOKEN` but **not the URL**.

- [x] Add `PLATFORM_CREDIT_SERVICE_URL` to `nrev-lite-api-secret` in the `prod` namespace (points at the user_management service base URL used for `/user/tenant_access` and credit deduction APIs).
- [x] Verify `PLATFORM_CREDIT_SERVICE_TOKEN` is also set (already in checklist but re-confirm — `platform_access_service.py` bombs without it).
- [x] Re-confirm these existing secrets still valid after auth migration: `JWT_SECRET_KEY`, `SUPABASE_JWT_SECRET`, `GOOGLE_CLIENT_SECRET`, `GTM_ENGINE_SERVICE_TOKEN`.

---

## 🗄️ Database migrations

Prod currently has `prod_combined_001_008_015.sql` applied. This branch adds two new migrations:

- [x] Apply `migrations/016_operation_costs.sql` to prod RDS (`nrev-lite-db-prod`, db `nrv`).
- [ ] Apply `migrations/017_cascade_scripts_learning_logs.sql` to prod RDS.
- [x] Verify RLS + `nrv_api` role grants still intact after migration.

---

## 📦 PyPI release (`pip install nrev-lite`)

- [ ] Local sanity: `pip install -e .` in a clean venv → `nrev-lite --help` works.
- [ ] Ensure `README.md` is release-ready — it becomes the PyPI long description.
- [ ] Install build tooling: `python -m pip install build twine`.
- [ ] Build: `python -m build` → produces `dist/nrev_lite-<version>.whl` + `.tar.gz`.
- [ ] Validate: `twine check dist/*`.
- [ ] **Upload to TestPyPI first**: `twine upload -r testpypi dist/*`.
- [ ] Verify in a clean venv: `pip install -i https://test.pypi.org/simple/ nrev-lite`.
- [ ] Upload to real PyPI: `twine upload dist/*`.
- [ ] Register the PyPI project under the **nRev org account** (not a personal account), with 2FA enabled.
- [ ] Set up PyPI **trusted publisher** for GitHub Actions so future releases auto-publish on git tag.
- [ ] Tag the release: `git tag v<version> && git push --tags`.

---

## ✅ `nrev-lite init` one-command UX verification

From a clean machine with no `~/.nrev-lite/` directory:

- [ ] `pip install nrev-lite` succeeds from real PyPI.
- [ ] `nrev-lite init` triggers browser-based auth against `https://app.nrev.ai/login`.
- [ ] Auth callback writes `~/.nrev-lite/credentials` successfully.
- [ ] MCP registration in Claude Code works post-auth.
- [ ] Default `API_BASE_URL` resolves to `https://nrev-lite-api.public.prod.nurturev.com` with no env vars set (already correct at `src/nrev_lite/constants/urls.py:8`).
- [ ] `nrev-lite status` shows auth ✓, credits balance, providers reachable.

---

## 🚀 Remaining prod deploy items (from `latest_deployment_checklist.md`)

- [x] Verify `/health` endpoint returns 200 on prod pods.
- [x] End-to-end Google OAuth login on the prod console.
- [x] Run one enrichment call against prod to verify provider connectivity.
- [x] Set up CloudWatch log aggregation for prod pods.
- [ ] Smoke test CLI against prod: `nrev-lite auth login && nrev-lite enrich person --email test@example.com`.

---

## 📝 Post-release

- [ ] Update `CLAUDE.md` install instructions if they reference `pip install -e .` instead of `pip install nrev-lite`.
- [ ] Monitor first 24h: error rate, credit deduction correctness against user_management, auth flow success rate.
