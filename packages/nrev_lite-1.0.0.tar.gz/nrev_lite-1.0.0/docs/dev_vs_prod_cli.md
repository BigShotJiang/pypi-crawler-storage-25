# Running dev, staging, and prod `nrev-lite` side-by-side

Three isolated CLI installs on the same machine: dev runs your local working tree against `localhost`, staging runs the shipped build against the staging API, and prod runs the shipped build against prod. They don't share code, credentials, or config.
 
## One-time setup

```bash
# DEV — editable install of this repo (local code + local server)
python -m venv ~/.venvs/nrev-dev
~/.venvs/nrev-dev/bin/pip install -e "/Users/nikhilojha/Projects/gtm-engine[dev]"

# STAGING — frozen snapshot pointing at staging API
python -m venv ~/.venvs/nrev-staging
~/.venvs/nrev-staging/bin/pip install "git+https://github.com/nurturev/gtm-engine@staging"

# PROD — frozen snapshot pointing at prod API
python -m venv ~/.venvs/nrev-prod
~/.venvs/nrev-prod/bin/pip install "git+https://github.com/nurturev/gtm-engine@prod"
```

Add to `~/.zshrc`:

```bash
alias nrev-dev='NREV_LITE_HOME=$HOME/.nrev-lite-dev     NREV_API_URL=http://localhost:8000               NREV_PLATFORM_URL=http://localhost:3000          ~/.venvs/nrev-dev/bin/nrev-lite'
alias nrev-staging='NREV_LITE_HOME=$HOME/.nrev-lite-staging NREV_API_URL=https://nrev-lite-api.public.staging.nurturev.com NREV_PLATFORM_URL=https://app.staging.nrev.ai ~/.venvs/nrev-staging/bin/nrev-lite'
alias nrev-prod='NREV_LITE_HOME=$HOME/.nrev-lite-prod    NREV_API_URL=https://nrev-lite-api.public.prod.nurturev.com                                                  ~/.venvs/nrev-prod/bin/nrev-lite'
```

Reload: `source ~/.zshrc`

## Daily use

```bash
# First time on each: log in (writes a token under its own NREV_LITE_HOME)
nrev-dev auth login
nrev-staging auth login
nrev-prod auth login

# Use them like three browser tabs
nrev-dev      --version    # local working tree, hits localhost:8000
nrev-staging  --version    # frozen staging build, hits staging API
nrev-prod     --version    # frozen prod build, hits prod API
```

Local code edits in `src/nrev_lite/` are picked up by `nrev-dev` immediately — no reinstall.

## When to use each

| Environment | Code source | Server | Use case |
| ----------- | ----------- | ------ | -------- |
| **dev** | Local working tree (editable install) | `localhost:8000` | Feature development, debugging, writing tests |
| **staging** | `staging` branch snapshot | Staging API | Integration testing, validating against real infra before release |
| **prod** | `prod` branch snapshot | Prod API | Final validation, customer-facing checks |

## Refreshing installs

Whenever the corresponding branch ships a new version:

```bash
# Staging
~/.venvs/nrev-staging/bin/pip install --force-reinstall "git+https://github.com/nurturev/gtm-engine@staging"

# Prod
~/.venvs/nrev-prod/bin/pip install --force-reinstall "git+https://github.com/nurturev/gtm-engine@prod"
```

## How the isolation works

| Concern         | Mechanism                                                    |
| --------------- | ------------------------------------------------------------ |
| CLI Python code | Three venvs — different `site-packages/nrev_lite/` on disk   |
| Server endpoint | `NREV_API_URL` env var (read by `get_api_base_url()`)        |
| Auth token      | `NREV_LITE_HOME` env var (config dir per instance)           |
| Config file     | Same — `$NREV_LITE_HOME/config.toml`                         |

## Troubleshooting

- `which nrev-dev` / `which nrev-staging` / `which nrev-prod` should print the alias definition. `command -v nrev-lite` (no alias) shows whichever venv is currently active on `PATH`.
- Logged into the wrong one? `ls ~/.nrev-lite-dev ~/.nrev-lite-staging ~/.nrev-lite-prod` — each should hold its own `credentials` file.
- Prod/staging CLI complains about missing env vars at import time? It needs `.env` too — either `export` the vars in your shell or copy `.env` into the venv's working dir.
