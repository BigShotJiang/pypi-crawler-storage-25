# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['zodipy']

package_data = \
{'': ['*']}

install_requires = \
['astropy>=5.0.1',
 'jplephem>=2.17,<3.0',
 'numpy>=1.26.4,<2.0.0',
 'scipy>=1.13.0,<2.0.0']

setup_kwargs = {
    'name': 'zodipy',
    'version': '1.1.3',
    'description': 'A Python package for zodiacal light simulations',
    'long_description': '\n<img src="docs/img/zodipy_logo.png" width="350">\n\n[![astropy](https://img.shields.io/badge/powered%20by-AstroPy-orange.svg)](http://www.astropy.org/)\n![PyPI - Python Version](https://img.shields.io/pypi/pyversions/zodipy)\n[![PyPI](https://img.shields.io/pypi/v/zodipy.svg?logo=python)](https://pypi.org/project/zodipy)\n[![Actions Status](https://img.shields.io/github/actions/workflow/status/Cosmoglobe/Zodipy/tests.yml?branch=main&logo=github)](https://github.com/Cosmoglobe/Zodipy/actions)\n![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Cosmoglobe/zodipy/mkdocs-deploy.yml?branch=main&style=flat-square&logo=github&label=docs)\n[![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](https://img.shields.io/badge/repo_status-Active-success)](https://www.repostatus.org/#active)\n[![Codecov](https://img.shields.io/codecov/c/github/Cosmoglobe/zodipy?token=VZP9L79EUJ&logo=codecov)](https://app.codecov.io/gh/Cosmoglobe/zodipy)\n[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)\n[![pyOpenSci](https://tinyurl.com/y22nb8up)](https://github.com/pyOpenSci/software-review/issues/161)\n[![ascl:2306.012](https://img.shields.io/badge/ascl-2306.012-blue.svg?colorB=262255)](https://ascl.net/2306.012)\n[![DOI](https://zenodo.org/badge/394929213.svg)](https://zenodo.org/doi/10.5281/zenodo.10999611)\n[![DOI](https://joss.theoj.org/papers/10.21105/joss.06648/status.svg)](https://doi.org/10.21105/joss.06648)\n---\n\n\n\nZodiPy is an [Astropy affiliated](https://www.astropy.org/affiliated/#affiliated-package-list) package for simulating zodiacal light in intensity for arbitrary solar system observers.\n\n![plot](docs/img/zodipy_map.png)\n\n\n## Documentation\nSee the [documentation](https://cosmoglobe.github.io/zodipy/) for a list of supported zodiacal light models and examples of how to use ZodiPy.\n\n## A simple example\n```python\nimport astropy.units as u\nfrom astropy.coordinates import SkyCoord\nfrom astropy.time import Time\n\nimport zodipy\n\n# Initialize a zodiacal light model at a wavelength/frequency or over a bandpass\nmodel = zodipy.Model(25*u.micron)\n\n# Use Astropy\'s `SkyCoord` object to specify coordinates\nlon = [10, 10.1, 10.2] * u.deg\nlat = [90, 89, 88] * u.deg\nobstimes = Time(["2022-01-01 12:00:00", "2022-01-01 12:01:00", "2022-01-01 12:02:00"])\nskycoord = SkyCoord(lon, lat, obstime=obstimes, frame="galactic")\n\n# Evaluate the zodiacal light model\nemission = model.evaluate(skycoord)\n\nprint(emission)\n#> [27.52410841 27.66572294 27.81251906] MJy / sr\n```\n\n## Related scientific papers\nSee [CITATION](https://github.com/Cosmoglobe/zodipy/blob/main/CITATION.bib)\n- [Cosmoglobe: Simulating zodiacal emission with ZodiPy (San et al. 2022)](https://arxiv.org/abs/2205.12962). \n- [ZodiPy: A Python package for zodiacal light simulations (San 2024)](https://joss.theoj.org/papers/10.21105/joss.06648#). \n\n\n## Install\nZodiPy is installed with pip\n```bash\npip install zodipy\n```\n\n## Dependencies\nZodiPy supports all Python versions >= 3.9, and has the following dependencies:\n- [Astropy](https://www.astropy.org/) (>=5.0.1)\n- [NumPy](https://numpy.org/)\n- [jplephem](https://pypi.org/project/jplephem/)\n- [SciPy](https://scipy.org/)\n\n## For developers\n### Poetry\nZodiPy uses [Poetry](https://python-poetry.org/) for development. To build and commit to the repository with the existing pre-commit setup, developers need to have Poetry (>= 1.8.0) installed. See the Poetry [documentation](https://python-poetry.org/docs/) for installation guide. \n\nAfter poetry has been installed, developers should create a new virtual environment and run the following in the root of the ZodiPy repositry\n```\npoetry install\n```\nThis will download all dependencies (including dev)from `pyproject.toml`, and `poetry.lock`.\n\n### Tests, linting and formatting, and building documentation\nThe following tools should be run from the root of the repository with no errors. (These are ran automatically as part of the CI workflows on GitHub, but should be tested locally first)\n\n#### pytest\nTesting is done with [pytest](https://docs.pytest.org/en/8.0.x/). To run the tests, run the following command from the repository root\n```bash\npytest\n``` \n#### ruff\nFormating and linting is done with [ruff](https://github.com/astral-sh/ruff). To format and lint, run the following command from the repository root\n```bash\nruff check\nruff format\n``` \n#### mypy\nZodiPy is fully typed. We use [mypy](https://mypy-lang.org/) as a static type checker. To type check, run the following command from the repositry root\n\n```bash\nmypy zodipy/\n```\nRemeber to add tests when implementing new features to maintain a high code coverage.\n\n#### MkDocs\nWe use [MkDocs](https://www.mkdocs.org/) to create our documentation. To serve the docs locally on you machine, run the following from the repositry root\n```bash\nmkdocs serve\n```\n\n## Funding\nThis work has received funding from the European Union\'s Horizon 2020 research and innovation programme under grant agreements No 776282 (COMPET-4; BeyondPlanck), 772253 (ERC; bits2cosmology) and 819478 (ERC; Cosmoglobe).\n\n\n<div style="display: flex; flex-direction: row; justify-content: space-evenly">\n    <img style="width: 49%; height: auto; max-width: 500px; align-self: center" src="https://user-images.githubusercontent.com/28634670/170697040-d5ec2935-29d0-4847-8999-9bc4eaa59e56.jpeg"> \n    &nbsp; \n    <img style="width: 49%; height: auto; max-width: 500px; align-self: center" src="https://user-images.githubusercontent.com/28634670/170697140-b010aa69-9f9a-44c0-b702-8a05ec0b6d3e.jpeg">\n</div>\n',
    'author': 'Metin San',
    'author_email': 'metinisan@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9',
}


setup(**setup_kwargs)
