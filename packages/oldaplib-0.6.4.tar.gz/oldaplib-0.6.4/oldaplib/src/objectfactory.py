import re
import textwrap
import logging
import sys

from dataclasses import dataclass
from pprint import pprint

import jwt

from datetime import datetime, timedelta
from enum import Flag, auto, Enum
from functools import partial
from typing import Type, Any, Self, cast, Dict, Literal, Iterable

from oldaplib.src.datamodel import DataModel
from oldaplib.src.dtypes.namespaceiri import NamespaceIRI
from oldaplib.src.enums.action import Action
from oldaplib.src.enums.datapermissions import DataPermission
from oldaplib.src.enums.adminpermissions import AdminPermission
from oldaplib.src.enums.propertyclassattr import PropClassAttr
from oldaplib.src.enums.xsd_datatypes import XsdDatatypes
from oldaplib.src.helpers.attributechange import AttributeChange
from oldaplib.src.helpers.context import Context
from oldaplib.src.helpers.construct_processor import ConstructProcessor, ConstructResultDict
from oldaplib.src.helpers.convert2datatype import convert2datatype
from oldaplib.src.helpers.langstring import LangString
from oldaplib.src.helpers.observable_dict import ObservableDict
from oldaplib.src.helpers.observable_set import ObservableSet
from oldaplib.src.helpers.oldaperror import OldapErrorNotFound, OldapErrorValue, OldapErrorInconsistency, \
    OldapErrorNoPermission, OldapError, OldapErrorUpdateFailed, OldapErrorInUse, OldapErrorAlreadyExists, OldapErrorType
from oldaplib.src.helpers.query_processor import QueryProcessor
from oldaplib.src.iconnection import IConnection
from oldaplib.src.oldaplist import OldapList
from oldaplib.src.oldaplistnode import OldapListNode
from oldaplib.src.project import Project
from oldaplib.src.propertyclass import PropertyClass
from oldaplib.src.resourceclass import ResourceClass
from oldaplib.src.enums.sparql_result_format import SparqlResultFormat
from oldaplib.src.xsd.iri import Iri
from oldaplib.src.xsd.dating import Dating
from oldaplib.src.xsd.listnode import HListNode, HListNodeRef
from oldaplib.src.xsd.xsd import Xsd
from oldaplib.src.xsd.xsd_datetimestamp import Xsd_dateTimeStamp
from oldaplib.src.xsd.xsd_integer import Xsd_integer
from oldaplib.src.xsd.xsd_ncname import Xsd_NCName
from oldaplib.src.xsd.xsd_qname import Xsd_QName
from oldaplib.src.xsd.xsd_string import Xsd_string

logger = logging.getLogger(__name__)

ValueType = LangString | ObservableSet | Xsd | Dict[Xsd_QName, DataPermission] | ObservableDict

class SortDir(str, Enum):
    asc = "asc"
    desc = "desc"

class SortKind(str, Enum):
    AUTO = "auto"
    VALUE = "value"
    DATING = "dating"

@dataclass(frozen=True)
class SortBy:
    property: Xsd_QName
    dir: SortDir = SortDir.asc
    kind: SortKind = SortKind.AUTO

    def __post_init__(self):
        # Convert property if needed
        if not isinstance(self.property, Xsd_QName):
            object.__setattr__(self, 'property', Xsd_QName(self.property))
        if not isinstance(self.dir, SortDir):
            object.__setattr__(self, 'dir', SortDir(self.dir))
        if not isinstance(self.kind, SortKind):
            object.__setattr__(self, 'kind', SortKind(self.kind))

class CompOp(Enum):
    EQ = "=="
    NE = "!="
    LT = "<"
    LE = "<="
    GT = ">"
    GE = ">="
    CONTAINS = "contains"
    STRSTARTS = "strstarts"
    STRENDS = "strends"
    REGEXP = "regexp"
    FULLTEXT = "fulltext"
    OVERLAPS = "overlaps"
    BEFORE = "before"
    AFTER = "after"

class LogicOp(Enum):
    AND = "&&"
    OR = "||"
    LEFT_ = "("
    _RIGHT = ")"


@dataclass(frozen=True)
class SearchFilter:
    prop: Xsd_QName
    op: CompOp
    value: Xsd | Dating

    def __post_init__(self):
        if not isinstance(self.prop, Xsd_QName):
            object.__setattr__(self, 'prop', Xsd_QName(self.prop))


@dataclass(frozen=True)
class FTSearchFilter:
    field: Xsd_NCName | str
    query: str

    def __post_init__(self):
        if not isinstance(self.field, Xsd_NCName):
            object.__setattr__(self, 'field', Xsd_NCName(str(self.field)))

    @property
    def field_name(self) -> Xsd_NCName:
        return cast(Xsd_NCName, self.field)


@dataclass(frozen=True)
class HLSearchFilter:
    prop: Xsd_QName
    node: HListNode | HListNodeRef

    def __post_init__(self):
        if not isinstance(self.prop, Xsd_QName):
            object.__setattr__(self, 'prop', Xsd_QName(self.prop))
        if isinstance(self.node, str):
            object.__setattr__(self, 'node', HListNodeRef.from_value(self.node))

READ_PERM_BINDING_PRED = Xsd_QName('oldap:_readPermBinding', validate=False)
READ_PERM_ROLE_PRED = Xsd_QName('oldap:_readRole', validate=False)
READ_PERM_VALUE_PRED = Xsd_QName('oldap:_readDataPermission', validate=False)
RDF_TYPE_PRED = Xsd_QName('rdf:type', validate=False)
DATING_CLASS = Xsd_QName('oldap:Dating', validate=False)
DATING_VERBATIM_PRED = Xsd_QName('oldap:verbatimDate', validate=False)
DATING_START_PRED = Xsd_QName('oldap:normalizedStart', validate=False)
DATING_END_PRED = Xsd_QName('oldap:normalizedEnd', validate=False)
DATING_PRECISION_PRED = Xsd_QName('oldap:datePrecision', validate=False)
DATING_CALENDAR_PRED = Xsd_QName('oldap:inCalendar', validate=False)
DATING_BEFORE_PRED = Xsd_QName('oldap:before', validate=False)


def _lucene_query_fields(ftfilter: Iterable[FTSearchFilter | Literal['AND', 'OR']]) -> str:
    parts: list[str] = []
    for item in ftfilter:
        if isinstance(item, FTSearchFilter):
            query = Xsd_string.escaping(str(item.query))
            parts.append(f'{item.field_name}:{query}')
        else:
            parts.append(str(item))
    return ' '.join(parts)


def creator_or_max_perm_block(
    *,
    graph_data: str,      # e.g. f"{graph}:data"
    resource_iri: str,    # e.g. iri.toRdf
    user_iri: str,        # e.g. con.userIri.toRdf
    min_perm: str,        # e.g. DataPermission.DATA_VIEW.numeric.toRdf
    alias: str = "acc",   # avoid var collisions when used multiple times
    include_creator: bool = True
) -> str:
    """
    Helper class to determine the permissions and act accordingly
    """
    r = f"?{alias}_role"
    dp = f"?{alias}_dataperm"
    pv = f"?{alias}_permval"
    pv_sub = f"?{alias}_pv"
    maxp = f"?{alias}_maxPerm"

    creator_branch = textwrap.dedent(f"""
    {{
        GRAPH {graph_data} {{
            {resource_iri} oldap:createdBy {user_iri} .
        }}
    }}
    """).strip()

    perm_branch = textwrap.dedent(f"""
    {{
        {{
            SELECT (MAX(xsd:integer({pv_sub})) AS {maxp})
            WHERE {{
                GRAPH oldap:admin {{
                    {user_iri} oldap:hasRole {r} .
                }}
                GRAPH {graph_data} {{
                    {resource_iri} oldap:attachedToRole {r} .
                    <<{resource_iri} oldap:attachedToRole {r}>> oldap:hasDataPermission {dp} .
                }}
                GRAPH oldap:admin {{
                    {dp} oldap:permissionValue {pv_sub} .
                    FILTER({pv_sub} >= {min_perm})
                }}
            }}
        }}
        GRAPH oldap:admin {{
            {user_iri} oldap:hasRole {r} .
            {dp} oldap:permissionValue {pv} .
        }}
        GRAPH {graph_data} {{
            {resource_iri} oldap:attachedToRole {r} .
            <<{resource_iri} oldap:attachedToRole {r}>> oldap:hasDataPermission {dp} .
        }}
        FILTER({pv} >= {min_perm} && xsd:integer({pv}) = {maxp})
    }}
    """).strip()

    if include_creator:
        return f"{{\n{creator_branch}\n}}\nUNION\n{{\n{perm_branch}\n}}"
    return perm_branch


def _construct_subject_key(subject: Iri | Xsd_QName) -> Iri | Xsd_QName:
    if isinstance(subject, Iri) and subject.is_qname:
        return subject.as_qname
    return subject


def _construct_values(node: dict[Xsd_QName, Any], predicate: Xsd_QName) -> list[Any]:
    value = node.get(predicate)
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _value_as_qname(value: Any) -> Xsd_QName | None:
    if isinstance(value, Xsd_QName):
        return value
    if isinstance(value, Iri) and value.is_qname:
        return value.as_qname
    return None


def _is_dating_shorthand(value: Any) -> bool:
    from oldaplib.src.xsd.dating import OldapCalendar

    if isinstance(value, str):
        return True
    if isinstance(value, tuple):
        if len(value) == 2 and all(isinstance(x, (tuple, list, str)) for x in value):
            return True
        return all(isinstance(x, int) for x in value) or (
            len(value) > 0 and all(isinstance(x, int) for x in value[:-1]) and isinstance(value[-1], OldapCalendar)
        )
    if isinstance(value, list):
        if len(value) == 2 and all(isinstance(x, (tuple, list, str)) for x in value):
            return True
        return all(isinstance(x, int) for x in value) or (
            len(value) > 0 and all(isinstance(x, int) for x in value[:-1]) and isinstance(value[-1], OldapCalendar)
        )
    return False


def _coerce_dating_value(value: Any) -> Any:
    from oldaplib.src.xsd.dating import Dating

    if isinstance(value, Dating):
        return value
    if isinstance(value, str):
        return Dating(value)
    if isinstance(value, tuple):
        if len(value) == 2 and all(isinstance(x, (tuple, list, str)) for x in value):
            return Dating(value[0], value[1])
        return Dating(value)
    if isinstance(value, list):
        if len(value) == 2 and all(isinstance(x, (tuple, list, str)) for x in value):
            return Dating(value[0], value[1])
        return Dating(tuple(value))
    return value


def _is_dating_property(prop: PropertyClass | None) -> bool:
    if prop is None:
        return False
    if getattr(prop, 'datatype', None) is not None:
        return False
    to_class = getattr(prop, 'toClass', None)
    return to_class is not None and str(to_class) == str(DATING_CLASS)


def _coerce_property_value(prop: PropertyClass, value: Any) -> Any:
    if not _is_dating_property(prop):
        return value
    if isinstance(value, set):
        return {_coerce_dating_value(x) for x in value}
    if _is_dating_shorthand(value):
        return _coerce_dating_value(value)
    if isinstance(value, (list, tuple)):
        return {_coerce_dating_value(x) for x in value}
    return _coerce_dating_value(value)


def _is_empty_property_value(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, (list, tuple, set, ObservableSet, LangString)):
        return len(value) == 0
    return False


def _dating_insert_triples(values: dict[Xsd_QName, Any]) -> list[str]:
    triples: list[str] = []
    seen: set[Iri | Xsd_QName] = set()
    for prop_values in values.values():
        if not isinstance(prop_values, ObservableSet):
            continue
        for item in prop_values:
            if item.__class__.__name__ != 'Dating':
                continue
            triples.extend(_dating_insert_triples_for_item(item, seen))
    return triples


def _dating_insert_triples_for_item(item: Any, seen: set[Iri | Xsd_QName]) -> list[str]:
    if item.__class__.__name__ != 'Dating':
        return []
    if item.iri is None:
        item._Dating__iri = Iri()
    if item.iri in seen:
        return []
    seen.add(item.iri)

    triples: list[str] = []
    before_values = getattr(item, '_beforeDating', set())
    for before in before_values:
        triples.extend(_dating_insert_triples_for_item(before, seen))

    parts = []
    verbatim = getattr(item, '_verbatimDate', None)
    if verbatim:
        parts.append(f'oldap:verbatimDate """{verbatim}"""')
    parts.append(f'oldap:normalizedStart "{item._normalizedStart.isoformat()}"^^xsd:date')
    parts.append(f'oldap:normalizedEnd "{item._normalizedEnd.isoformat()}"^^xsd:date')
    parts.append(f'oldap:datePrecision {item._datePrecision.value}')
    parts.append(f'oldap:inCalendar {item._inCalendar.value}')
    for before in before_values:
        if before.iri is None:
            before._Dating__iri = Iri()
        parts.append(f'oldap:before {before.iri.toRdf}')
    triples.append(f'{item.iri.toRdf} a oldap:Dating ;\n' + ' ;\n'.join(parts) + ' .')
    return triples


def _is_dating_ref(value: Any, construct_data: ConstructResultDict) -> bool:
    if not isinstance(value, (Iri, Xsd_QName)):
        return False
    key = _construct_subject_key(value)
    node = construct_data.get(key)
    if node is None:
        return False
    return any(_value_as_qname(node_type) == DATING_CLASS for node_type in _construct_values(node, RDF_TYPE_PRED))


def _dating_from_construct(value: Any,
                           construct_data: ConstructResultDict,
                           cache: dict[Iri | Xsd_QName, Any]) -> Any:
    if not isinstance(value, (Iri, Xsd_QName)):
        return value
    key = _construct_subject_key(value)
    if key in cache:
        return cache[key]
    node = construct_data.get(key)
    if node is None or not _is_dating_ref(value, construct_data):
        return value

    start = node.get(DATING_START_PRED)
    end = node.get(DATING_END_PRED)
    if start is None or end is None:
        return value

    verbatim = node.get(DATING_VERBATIM_PRED)
    precision_value = node.get(DATING_PRECISION_PRED)
    calendar_value = node.get(DATING_CALENDAR_PRED)

    from oldaplib.src.xsd.dating import Dating, DatePrecision, OldapCalendar

    precision = DatePrecision(str(precision_value)) if precision_value is not None else None
    calendar = OldapCalendar(str(calendar_value)) if calendar_value is not None else OldapCalendar.GREGORIAN

    before_values = {
        _dating_from_construct(before_value, construct_data, cache)
        for before_value in _construct_values(node, DATING_BEFORE_PRED)
    }
    before_values = {x for x in before_values if isinstance(x, Dating)}

    dating_iri = key if isinstance(key, (Iri, Xsd_QName)) else None
    dating = Dating(str(start),
                    str(end),
                    None if verbatim is None else str(verbatim),
                    datePrecision=precision,
                    inCalendar=calendar,
                    before=before_values or None,
                    **({'iri': dating_iri} if dating_iri is not None else {}))
    cache[key] = dating
    return dating


def _convert_construct_value(value: Any,
                             prop: PropertyClass | None,
                             construct_data: ConstructResultDict,
                             cache: dict[Iri | Xsd_QName, Any]) -> Any:
    if (_is_dating_property(prop) or _is_dating_ref(value, construct_data)):
        return _dating_from_construct(value, construct_data, cache)
    return value


def _normalize_construct_property(value: Any,
                                  prop: PropertyClass | None,
                                  construct_data: ConstructResultDict,
                                  cache: dict[Iri | Xsd_QName, Any]) -> Any:
    if isinstance(value, LangString):
        return value

    values = value if isinstance(value, list) else [value]
    converted = [_convert_construct_value(item, prop, construct_data, cache) for item in values]
    if len(converted) == 1:
        return converted[0]
    try:
        return set(converted)
    except Exception:
        return converted


def _resource_from_construct(subject: Iri,
                             construct_data: ConstructResultDict,
                             properties: dict[Xsd_QName, PropertyClass] | None = None) -> tuple[Xsd_QName | None, dict[str, Any]]:
    subject_key = _construct_subject_key(subject)
    resource_data = construct_data.get(subject_key)
    if resource_data is None:
        return None, {}

    dating_cache: dict[Iri | Xsd_QName, Any] = {}
    objtype: Xsd_QName | None = None
    kwargs: dict[str, Any] = {}
    roles: dict[Xsd_QName, DataPermission] = {}

    for predicate, value in resource_data.items():
        if predicate == RDF_TYPE_PRED:
            for node_type in _construct_values(resource_data, RDF_TYPE_PRED):
                node_type_qname = _value_as_qname(node_type)
                if node_type_qname is not None:
                    objtype = node_type_qname
                    break
            continue
        if predicate == READ_PERM_BINDING_PRED:
            for binding in _construct_values(resource_data, READ_PERM_BINDING_PRED):
                if not isinstance(binding, dict):
                    continue
                role = binding.get(READ_PERM_ROLE_PRED)
                dataperm = binding.get(READ_PERM_VALUE_PRED)
                role_qname = _value_as_qname(role)
                dataperm_qname = _value_as_qname(dataperm)
                if role_qname is not None and dataperm_qname is not None:
                    roles[role_qname] = DataPermission.from_qname(dataperm_qname)
            continue
        prop = properties.get(predicate) if properties else None
        kwargs[predicate.fragment] = _normalize_construct_property(value, prop, construct_data, dating_cache)

    kwargs['attachedToRole'] = roles
    return objtype, kwargs


def _read_attached_roles(con: IConnection,
                         graph: Xsd_NCName,
                         iri: Iri) -> dict[Xsd_QName, DataPermission]:
    context = Context(name=con.context_name)
    sparql = context.sparql_context
    sparql += textwrap.dedent(f'''
    SELECT DISTINCT ?role ?dataperm
    WHERE {{
        GRAPH {graph}:data {{
            << {iri.toRdf} oldap:attachedToRole ?role >> oldap:hasDataPermission ?dataperm .
        }}
    }}
    ''')
    jsonres = con.query(sparql)
    res = QueryProcessor(context, jsonres)
    roles: dict[Xsd_QName, DataPermission] = {}
    for row in res:
        role = row.get('role')
        dataperm = row.get('dataperm')
        role_qname = _value_as_qname(role)
        dataperm_qname = _value_as_qname(dataperm)
        if role_qname is not None and dataperm_qname is not None:
            roles[role_qname] = DataPermission.from_qname(dataperm_qname)
    return roles


def _read_resource_construct(con: IConnection,
                             graph: Xsd_NCName,
                             iri: Iri,
                             user_iri: Iri,
                             *,
                             include_creator: bool) -> ConstructResultDict:
    context = Context(name=con.context_name)
    access_block = creator_or_max_perm_block(
        graph_data=f"{graph}:data",
        resource_iri=iri.toRdf,
        user_iri=user_iri.toRdf,
        min_perm=DataPermission.DATA_VIEW.numeric.toRdf,
        alias="readc",
        include_creator=include_creator
    )
    sparql = context.sparql_context
    sparql += textwrap.dedent(f'''
    CONSTRUCT {{
        {iri.toRdf} ?predicate ?value .
        {iri.toRdf} {READ_PERM_BINDING_PRED.toRdf} ?permBinding .
        ?permBinding {READ_PERM_ROLE_PRED.toRdf} ?role .
        ?permBinding {READ_PERM_VALUE_PRED.toRdf} ?dataperm .
        ?datingNode ?datingPredicate ?datingValue .
    }}
    WHERE {{
        {access_block}
        GRAPH {graph}:data {{
            {iri.toRdf} ?predicate ?value .
        }}
        OPTIONAL {{
            GRAPH {graph}:data {{
                {iri.toRdf} oldap:attachedToRole ?role .
                << {iri.toRdf} oldap:attachedToRole ?role >> oldap:hasDataPermission ?dataperm .
            }}
            BIND(BNODE() AS ?permBinding)
        }}
        OPTIONAL {{
            GRAPH {graph}:data {{
                {iri.toRdf} ?predicate ?value .
                ?value a oldap:Dating .
                ?value oldap:before* ?datingNode .
                ?datingNode ?datingPredicate ?datingValue .
            }}
        }}
    }}
    ''')
    graph_res = con.query(sparql, format=SparqlResultFormat.JSONLD)
    return ConstructProcessor.process(context, graph_res)


#@strict
class ResourceInstance:
    """
    Represents an instance of a resource in a system based on certain defined ontology.

    Provides functionality to initialize a resource, set its values, validate those values
    against defined properties, and handle changesets related to the resource instance.
    It integrates the resource's superclass properties into the instance and ensures the
    conformance of its data to defined constraints such as minimum/maximum counts, lengths,
    and allowable values or patterns.

    Basically it's used be the ResourceInstanceFactory to create new instances of a resource.
    The basic usage is as follows:

    ```python
        project = Project.read(con=self._connection, projectIri_SName='test')
        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')
    ```

    **IMPORTANT NOTE: This class is not intended to be used directly, but rather through the
    `ResourceInstanceFactory` class!**

    In a first step the factory is instantiated with the project. Then using the `createObjectInstance` method
    creates a new Python class which will represent instances of the given resource class.

    :ivar iri: The unique identifier of the resource instance.
    :type iri: Iri
    :ivar values: A mapping of property IRIs to their corresponding values, which could
                  include `LangString` objects or `ObservableSet` of values.
    :type values: dict[Iri, LangString | ObservableSet]
    :ivar graph: The name of the graph attribute in which the instance will reside,
                 represented by a short name of the project.
    :type graph: Xsd_NCName
    :ivar changeset: A mapping to track all attributes changed within the instance,
                     where the key is the property IRI and the value defines the
                     change details.
    :type changeset: dict[Iri, AttributeChange]
    """
    _iri: Iri
    _values: dict[Xsd_QName, LangString | ObservableSet | DataPermission]
    _graph: Xsd_NCName
    _changeset: dict[Xsd_QName, AttributeChange]
    _attached_roles: ObservableDict

    __slots__ = ['_iri', '_values', '_graph', '_changeset', '_superclass_objs', '_con', '_attached_roles',
                 'project', 'name', 'factory', 'properties', 'superclass', 'user_default_roles']


    def __init__(self, *,
                 iri: Iri | None = None,
                 **kwargs):
        """
        Initializes an instance of the resource class, setting the optional IRI, processing
        superclasses, and validating property constraints. This initializer interprets
        the properties and superclasses associated with the instance and ensures
        conformance to rules such as `MIN_COUNT` and `MAX_COUNT` for properties.

        :param iri: An optional parameter specifying the IRI of the instance.
        :type iri: Iri | None
        :param kwargs: A dictionary of additional property values with property IRIs
            or fragments as keys. In case of unique fragments, the dictionary may be pass
            as named method arguments
        :type kwargs: dict or named method arguments
        """
        if iri and isinstance(iri, str):
            iri = Iri(Xsd_QName(self.project.projectShortName, iri))
        self._iri = Iri(iri, validate=True) if iri else Iri()
        self._values: dict[Xsd_QName, ValueType] = {}
        self._graph = self.project.projectShortName
        self._superclass_objs = {}
        self._changeset: dict[Xsd_QName, AttributeChange] = {}
        self._attached_roles = ObservableDict(on_change=self.__attachedToRole_cb)

        def set_values(propclass: dict[Xsd_QName, PropertyClass]):
            for prop_iri, prop in propclass.items():
                if str(prop_iri) == 'oldap:attachedToRole':
                    if str(prop_iri) in kwargs or prop_iri.fragment in kwargs:
                        #
                        # we have an attachedToRole property given in the constructor...
                        #
                        value = kwargs[str(prop_iri)] if str(prop_iri) in kwargs else kwargs[prop_iri.fragment]
                        value = {Xsd_QName(role): dperm if isinstance(dperm, DataPermission) else DataPermission.from_string(dperm) for role, dperm in value.items()}
                        if not isinstance(value, dict):
                            raise OldapErrorValue(f'{self.name}: Property {prop_iri} with attachedToRole must be a dict')
                        self._attached_roles = ObservableDict(value, on_change=self.__attachedToRole_cb)
                        self._values[prop_iri] = ObservableSet({Xsd_QName(x, validate=True) for x in value.keys()},
                                                               notifier=self.notifier, notify_data=prop_iri)
                    else:
                        #
                        # we take the user default values...
                        #
                        self._values[prop_iri] = ObservableSet({Xsd_QName(x) for x in self.user_default_roles.keys()},
                                                               notifier=self.notifier, notify_data=prop_iri)
                        self._attached_roles = ObservableDict(self.user_default_roles, on_change=self.__attachedToRole_cb)

                    continue
                if str(prop_iri) in kwargs or prop_iri.fragment in kwargs:
                    value = kwargs[str(prop_iri)] if str(prop_iri) in kwargs else kwargs[prop_iri.fragment]
                    value = _coerce_property_value(prop, value)
                    if isinstance(value, (list, tuple, set, LangString)):  # we may have multiple values...
                        if prop.datatype == XsdDatatypes.langString:
                            self._values[prop_iri] = LangString(value,
                                                                notifier=self.notifier, notify_data=prop_iri)
                        elif _is_dating_property(prop):
                            self._values[prop_iri] = self.__observable_set(set(value), prop_iri, prop)
                        else:
                            self._values[prop_iri] = self.__observable_set(
                                {convert2datatype(x, prop.datatype) for x in value},
                                prop_iri,
                                prop)
                    else:
                        if _is_dating_property(prop):
                            self._values[prop_iri] = self.__observable_set({value}, prop_iri, prop)
                            continue
                        try:
                            self._values[prop_iri] = self.__observable_set(
                                {convert2datatype(value, prop.datatype)},
                                prop_iri,
                                prop)
                        except TypeError as err:
                            self._values[prop_iri] = convert2datatype(value, prop.datatype)

            for prop_iri, prop in propclass.items():
                #
                # Validate cardinalities
                #
                if prop.minCount:  # testing for MIN_COUNT conformance
                    if prop.minCount > 0 and not self._values.get(prop_iri):
                        raise OldapErrorValue(f'{self.name}: Property {prop_iri} with MIN_COUNT={prop.minCount} is missing')
                    elif isinstance(self._values[prop_iri], ObservableSet) and len(self._values[prop_iri]) < 1:
                        raise OldapErrorValue(f'{self.name}: Property {prop_iri} with MIN_COUNT={prop.minCount} is missing')
                if prop.maxCount and prop.maxCount > 0:  # testing for MAX_COUNT conformance
                    if isinstance(self._values.get(prop_iri), ObservableSet) and len(self._values[prop_iri]) > prop.maxCount:
                        raise OldapErrorValue(f'{self.name}: Property {prop_iri} with MAX_COUNT={prop.maxCount} has to many values (n={len(self._values[prop_iri])})')
                if self._values.get(prop_iri):
                    if isinstance(self._values[prop_iri], LangString):
                        self.validate_value(self._values[prop_iri], prop)
                    else:
                        if isinstance(self._values[prop_iri], ObservableSet):
                            for val in self._values[prop_iri]:
                                self.validate_value(val, prop)
                        else:
                            self.validate_value(self._values[prop_iri], prop)

        def process_superclasses(superclass: dict[Xsd_QName, ResourceClass]):
            for sc_iri, sc in superclass.items():
                if not sc:
                    continue
                if sc.superclass:
                    process_superclasses(sc.superclass)
                if sc.owl_class_iri == Xsd_QName("oldap:Thing", validate=False):
                    timestamp = Xsd_dateTimeStamp()
                    if not self._values.get(Xsd_QName('oldap:createdBy', validate=False)):
                        self._values[Xsd_QName('oldap:createdBy', validate=False)] = ObservableSet({self._con.userIri})
                    if not self._values.get(Xsd_QName('oldap:creationDate', validate=False)):
                        self._values[Xsd_QName('oldap:creationDate', validate=False)] = ObservableSet({timestamp})
                    if not self._values.get(Xsd_QName('oldap:lastModifiedBy', validate=False)):
                        self._values[Xsd_QName('oldap:lastModifiedBy', validate=False)] = ObservableSet({self._con.userIri})
                    if not self._values.get(Xsd_QName('oldap:lastModificationDate', validate=False)):
                        self._values[Xsd_QName('oldap:lastModificationDate', validate=False)] = ObservableSet({timestamp})
                set_values(sc.properties)
                for iri, prop in sc.properties.items():
                    self.properties[iri] = prop

        if self.superclass:
            process_superclasses(self.superclass)

        set_values(self.properties)

        for propname in self.properties.keys():
            setattr(ResourceInstance, propname.fragment, property(
                partial(ResourceInstance.__get_value, attr=propname),
                partial(ResourceInstance.__set_value, attr=propname),
                partial(ResourceInstance.__del_value, attr=propname)))
        self.clear_changeset()

    def __setitem__(self, key: Xsd_QName, value: ValueType | Xsd | None):
        self.__set_value(value, key)

    def __getitem__(self, key: Xsd_QName) -> ValueType | Xsd | None:
        if self._values.get(key):
            return self.__get_value(key)
        else:
            raise OldapErrorValue(f'{self.name}: __getitem__: Property {key} does not exist.')

    def __delitem__(self, key: Xsd_QName):
        if self._values.get(key):
            self.__del_value(key)

    def get(self, key: Xsd_QName) -> ValueType | Xsd | None:
        if self._values.get(key):
            return self.__get_value(key)
        else:
            return None

    def validate_value(self, values: ValueType, property: PropertyClass):
        """
        Validates a set of values against a given property and its constraints. This function ensures
        that the input values conform to specific constraints defined by the property. The function
        verifies conformance to constraints such as language requirements, predefined inclusions,
        length limits, pattern matching, exclusivity, inclusivity, and relational comparisons
        (less than or less than or equals).

        :param values: A set of values to be validated.
        :param property: The property against which the values are being validated, containing
            the constraints that the values must meet.
        :return: None if the values successfully pass all validations.
        :raises OldapErrorInconsistency: Raised when the values do not conform to the defined property
            constraints due to inconsistencies or invalid data types.
        :raises OldapErrorValue: Raised when the values explicitly violate specific constraints
            such as inclusion constraints or invalid language values.
        """
        if property.get(PropClassAttr.LANGUAGE_IN):  # testing for LANGUAGE_IN conformance
            if not isinstance(values, LangString):
                raise OldapErrorInconsistency(f'Property {property.property_class_iri} with LANGUAGE_IN requires datatype rdf:langstring, got {type(values).__name__}.')
            for lang, dummy in values.items():
                if not lang in property[PropClassAttr.LANGUAGE_IN]:
                    raise OldapErrorValue(f'Property {property.property_class_iri} with LANGUAGE_IN={property[PropClassAttr.LANGUAGE_IN]} has invalid language "{lang.value}"')
        if property.get(PropClassAttr.UNIQUE_LANG):
            return  # TODO: LangString does not yet allow multiple entries of the same language...
        if property.get(PropClassAttr.IN):
            if property.datatype is None:  # no defined datatype, e.h.sh:IRI
                tmpinset = {str(x) for x in property[PropClassAttr.IN]}
                if isinstance(values, (list, tuple, set, ObservableSet)):
                    for val in values:
                        if not str(val) in tmpinset:
                            raise OldapErrorValue(
                                f'Property {property} with IN={property[PropClassAttr.IN]} has invalid value "{val}"')
                else:
                    if not str(values) in tmpinset:
                        raise OldapErrorValue(f'Property {property.property_class_iri} with IN={property[PropClassAttr.IN]} has invalid value "{values}"')
            else:
                if isinstance(values, (list, tuple, set, ObservableSet)):
                    for val in values:
                        if not val in property[PropClassAttr.IN]:
                            raise OldapErrorValue(
                                f'Property {property} with IN={property[PropClassAttr.IN]} has invalid value "{val}"')
                else:
                    if not values in property[PropClassAttr.IN]:
                        raise OldapErrorValue(f'Property {property.property_class_iri} with IN={property[PropClassAttr.IN]} has invalid value "{values}"')
        if property.get(PropClassAttr.MIN_LENGTH):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    l = 0
                    try:
                        l = len(val)
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MIN_LENGTH]} has no length.')
                    if l < property[PropClassAttr.MIN_LENGTH]:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MIN_LENGTH]} has length "{len(val)}".')
            else:
                l = 0
                try:
                    l = len(values)
                except TypeError:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MIN_LENGTH]} has no length.')
                if l < property[PropClassAttr.MIN_LENGTH]:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MIN_LENGTH]} has length "{len(values)}".')
        if property.get(PropClassAttr.MAX_LENGTH):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    l = 0
                    try:
                        l = len(val)
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MAX_LENGTH={property[PropClassAttr.MAX_LENGTH]} has no length.')
                    if l > property[PropClassAttr.MAX_LENGTH]:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MAX_LENGTH]} has length "{len(val)}".')
            else:
                l = 0
                try:
                    l = len(values)
                except TypeError:
                    raise OldapErrorInconsistency(
                        f'Property {property} with MAX_LENGTH={property[PropClassAttr.MAX_LENGTH]} has no length.')
                if l > property[PropClassAttr.MAX_LENGTH]:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_LENGTH={property[PropClassAttr.MAX_LENGTH]} has length "{len(values)}".')

        if property.get(PropClassAttr.PATTERN):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    if not re.fullmatch(str(property[PropClassAttr.PATTERN]), str(val)):
                        raise OldapErrorInconsistency(f'Property {property} with PATTERN={property[PropClassAttr.PATTERN]} does not conform ({val}).')
            else:
                if not re.fullmatch(str(property[PropClassAttr.PATTERN]), str(values)):
                    raise OldapErrorInconsistency(f'Property {property} with PATTERN={property[PropClassAttr.PATTERN]} does not conform ({values}).')

        if property.get(PropClassAttr.MIN_EXCLUSIVE):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    v: bool | None = None
                    try:
                        v = val > property[PropClassAttr.MIN_EXCLUSIVE]
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_EXCLUSIVE]} cannot be compared to "{val}".')
                    if not v:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_EXCLUSIVE]} has invalid "{val}".')
            else:
                v: bool | None = None
                try:
                    v = values > property[PropClassAttr.MIN_EXCLUSIVE]
                except TypeError:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_EXCLUSIVE]} cannot be compared to "{values}".')
                if not v:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_EXCLUSIVE]} has invalid "{values}".')

        if property.get(PropClassAttr.MIN_INCLUSIVE):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    v: bool | None = None
                    try:
                        v = val >= property[PropClassAttr.MIN_INCLUSIVE]
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_INCLUSIVE]} cannot be compared to "{val}".')
                    if not v:
                        raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_INCLUSIVE]} has invalid "{val}".')
            else:
                v: bool | None = None
                try:
                    v = values >= property[PropClassAttr.MIN_INCLUSIVE]
                except TypeError:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_INCLUSIVE]} cannot be compared to "{values}".')
                if not v:
                    raise OldapErrorInconsistency(f'Property {property} with MIN_EXCLUSIVE={property[PropClassAttr.MIN_INCLUSIVE]} has invalid "{values}".')

        if property.get(PropClassAttr.MAX_EXCLUSIVE):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    v: bool | None = None
                    try:
                        v = val < property[PropClassAttr.MAX_EXCLUSIVE]
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MAX_EXCLUSIVE={property[PropClassAttr.MAX_EXCLUSIVE]} cannot be compared to "{val}".')
                    if not v:
                        raise OldapErrorInconsistency(f'Property {property} with MAX_EXCLUSIVE={property[PropClassAttr.MAX_EXCLUSIVE]} has invalid "{val}".')
            else:
                v: bool | None = None
                try:
                    v = values < property[PropClassAttr.MAX_EXCLUSIVE]
                except TypeError:
                    raise OldapErrorInconsistency(f'Property {property} with MAX_EXCLUSIVE={property[PropClassAttr.MAX_EXCLUSIVE]} cannot be compared to "{values}".')
                if not v:
                    raise OldapErrorInconsistency(f'Property {property} with MAX_EXCLUSIVE={property[PropClassAttr.MAX_EXCLUSIVE]} has invalid "{values}".')


        if property.get(PropClassAttr.MAX_INCLUSIVE):
            if isinstance(values, (list, tuple, set, ObservableSet)):
                for val in values:
                    v: bool | None = None
                    try:
                        v = val <= property[PropClassAttr.MAX_INCLUSIVE]
                    except TypeError:
                        raise OldapErrorInconsistency(f'Property {property} with MAX_INCLUSIVE={property[PropClassAttr.MAX_INCLUSIVE]} cannot be compared to "{val}".')
                    if not v:
                        raise OldapErrorInconsistency(f'Property {property} with MAX_INCLUSIVE={property[PropClassAttr.MAX_INCLUSIVE]} has invalid "{val}".')
            else:
                v: bool | None = None
                try:
                    v = values <= property[PropClassAttr.MAX_INCLUSIVE]
                except TypeError:
                    raise OldapErrorInconsistency(
                        f'Property {property} with MAX_INCLUSIVE={property[PropClassAttr.MAX_INCLUSIVE]} cannot be compared to "{values}".')
                if not v:
                    raise OldapErrorInconsistency(
                        f'Property {property} with MAX_INCLUSIVE={property[PropClassAttr.MAX_INCLUSIVE]} has invalid "{values}".')

        if property.get(PropClassAttr.LESS_THAN):
            other_values = self._values.get(property[PropClassAttr.LESS_THAN])
            if not isinstance(other_values, (list, tuple, set, ObservableSet)):
                other_values = [other_values]
            if other_values is not None:
                b: bool | None = None
                try:
                    min_other_value = min(other_values)
                    if not isinstance(values, (list, tuple, set, ObservableSet)):
                        _values = [values]
                    else:
                        _values = values
                    max_value = max(_values)
                    b = max_value < min_other_value
                except TypeError:
                    raise OldapErrorInconsistency(
                        f'Property {property} with LESS_THAN={property[PropClassAttr.LESS_THAN]} cannot be compared to "{values}".')
                if not b:
                    raise OldapErrorInconsistency(
                        f'Property {property} with LESS_THAN={property[PropClassAttr.LESS_THAN]} has invalid value: "{max_value}" NOT LESS_THAN "{min_other_value}".')
        if property.get(PropClassAttr.LESS_THAN_OR_EQUALS):
            other_values = self._values.get(property[PropClassAttr.LESS_THAN])
            if not isinstance(other_values, (list, tuple, set, ObservableSet)):
                other_values = [other_values]
            if other_values is not None:
                b: bool | None = None
                try:
                    min_other_value = min(other_values)
                    if not isinstance(values, (list, tuple, set, ObservableSet)):
                        _values = [values]
                    else:
                        _values = values
                    max_value = max(_values)
                    b = max_value <= min_other_value
                except TypeError:
                    raise OldapErrorInconsistency(
                        f'Property {property} with LESS_THAN={property[PropClassAttr.LESS_THAN_OR_EQUALS]} cannot be compared "{values}".')
                if not b:
                    raise OldapErrorInconsistency(
                        f'Property {property} with LESS_THAN={property[PropClassAttr.LESS_THAN_OR_EQUALS]} has invalid value: "{max_value}" NOT LESS_THAN "{min_other_value}".')

    def __validate_property_set(self, values: set[Any], prop_iri: Xsd_QName, prop: PropertyClass) -> None:
        n = len(values)
        if prop.minCount and n < prop.minCount:
            raise OldapErrorValue(
                f'{self.name}: Property {prop_iri} with MIN_COUNT={prop.minCount} has not enough values (n={n}).')
        if prop.maxCount and prop.maxCount > 0 and n > prop.maxCount:
            raise OldapErrorValue(
                f'{self.name}: Property {prop_iri} with MAX_COUNT={prop.maxCount} has to many values (n={n}).')
        for value in values:
            self.validate_value(value, prop)

    def __observable_set(self,
                         values: Iterable[Any],
                         prop_iri: Xsd_QName,
                         prop: PropertyClass,
                         *,
                         old_value: ObservableSet | None = None) -> ObservableSet:
        return ObservableSet(values,
                             old_value=old_value,
                             notifier=self.notifier,
                             notify_data=prop_iri,
                             validator=lambda new_values: self.__validate_property_set(new_values, prop_iri, prop))

    def __dating_update_sparql(self,
                               field: Xsd_QName,
                               change: AttributeChange,
                               indent: int,
                               indent_inc: int) -> str:
        blank = ''
        if change.action == Action.DELETE:
            old_values = list(change.old_value) if isinstance(change.old_value, ObservableSet) else [change.old_value]
            if not old_values:
                raise OldapErrorValue(f'{self.name}: Dating property {field} has no value to delete.')
            old_roots = ', '.join(x.iri.toRdf for x in old_values)
            return (
                f'# Processing Dating field "{field}"\n'
                f'{blank:{indent * indent_inc}}WITH {self._graph}:data\n'
                f'{blank:{indent * indent_inc}}DELETE {{\n'
                f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} ?datingRoot .\n'
                f'{blank:{(indent + 1) * indent_inc}}?datingNode ?datingPred ?datingValue .\n'
                f'{blank:{indent * indent_inc}}}}\n'
                f'{blank:{indent * indent_inc}}WHERE {{\n'
                f'{blank:{(indent + 1) * indent_inc}}BIND({self._iri.toRdf} AS ?res_iri)\n'
                f'{blank:{(indent + 1) * indent_inc}}VALUES ?datingRoot {{ {old_roots} }}\n'
                f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} ?datingRoot .\n'
                f'{blank:{(indent + 1) * indent_inc}}?datingRoot oldap:before* ?datingNode .\n'
                f'{blank:{(indent + 1) * indent_inc}}?datingNode ?datingPred ?datingValue .\n'
                f'{blank:{indent * indent_inc}}}}'
            )

        new_values = list(self._values[field]) if isinstance(self._values[field], ObservableSet) else [self._values[field]]
        if not new_values:
            raise OldapErrorValue(f'{self.name}: Dating property {field} has no value.')

        if change.action == Action.CREATE:
            seen: set[Iri | Xsd_QName] = set()
            triples = []
            for item in new_values:
                triples.extend(_dating_insert_triples_for_item(item, seen))
            links = [f'{self._iri.toRdf} {field.toRdf} {item.iri.toRdf} .' for item in new_values]
            return (
                f'# Processing Dating field "{field}"\n'
                f'{blank:{indent * indent_inc}}INSERT DATA {{\n'
                f'{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{\n'
                f'{blank:{(indent + 2) * indent_inc}}'
                + f'\n{blank:{(indent + 2) * indent_inc}}'.join(triples + links)
                + f'\n{blank:{(indent + 1) * indent_inc}}}}\n'
                f'{blank:{indent * indent_inc}}}}'
            )

        old_values = list(change.old_value) if isinstance(change.old_value, ObservableSet) else [change.old_value]
        if len(old_values) != 1 or len(new_values) != 1:
            raise OldapErrorValue(f'{self.name}: Replacing multiple Dating values for {field} is not implemented yet.')
        old_dating = old_values[0]
        new_dating = new_values[0]
        if old_dating.iri is None:
            raise OldapErrorValue(f'{self.name}: Existing Dating value for {field} has no IRI.')
        if new_dating.iri is None:
            new_dating._Dating__iri = old_dating.iri
        elif new_dating.iri != old_dating.iri:
            raise OldapErrorValue(f'{self.name}: Replacing the Dating root IRI for {field} is not implemented yet.')

        seen: set[Iri | Xsd_QName] = set()
        triples = _dating_insert_triples_for_item(new_dating, seen)
        return (
            f'# Processing Dating field "{field}"\n'
            f'{blank:{indent * indent_inc}}WITH {self._graph}:data\n'
            f'{blank:{indent * indent_inc}}DELETE {{\n'
            f'{blank:{(indent + 1) * indent_inc}}?datingNode ?datingPred ?datingValue .\n'
            f'{blank:{indent * indent_inc}}}}\n'
            f'{blank:{indent * indent_inc}}INSERT {{\n'
            f'{blank:{(indent + 1) * indent_inc}}'
            + f'\n{blank:{(indent + 1) * indent_inc}}'.join(triples)
            + f'\n{blank:{indent * indent_inc}}}}\n'
            f'{blank:{indent * indent_inc}}WHERE {{\n'
            f'{blank:{(indent + 1) * indent_inc}}BIND({old_dating.iri.toRdf} AS ?datingRoot)\n'
            f'{blank:{(indent + 1) * indent_inc}}?datingRoot oldap:before* ?datingNode .\n'
            f'{blank:{(indent + 1) * indent_inc}}?datingNode ?datingPred ?datingValue .\n'
            f'{blank:{indent * indent_inc}}}}'
        )

    def __dating_delete_is_referenced_sparql(self, field: Xsd_QName, change: AttributeChange) -> str | None:
        if change.action != Action.DELETE:
            return None
        old_values = list(change.old_value) if isinstance(change.old_value, ObservableSet) else [change.old_value]
        old_roots = ', '.join(x.iri.toRdf for x in old_values if x.iri is not None)
        if not old_roots:
            return None

        context = Context(name=self._con.context_name)
        sparql = context.sparql_context
        sparql += textwrap.dedent(f'''
        ASK {{
            GRAPH {self._graph}:data {{
                VALUES ?datingRoot {{ {old_roots} }}
                ?datingRoot oldap:before* ?datingNode .
                ?externalDating oldap:before ?datingNode .
                FILTER NOT EXISTS {{
                    ?datingRoot oldap:before* ?externalDating .
                }}
            }}
        }}
        ''')
        return sparql

    def notifier(self, prop_iri: Xsd_QName):
        prop = self.properties[prop_iri]
        self.validate_value(self._values[prop_iri], prop)

        if prop.minCount:  # testing for MIN_COUNT conformance
            n = len(self._values[prop_iri])
            if n < prop.minCount:
                self._values[prop_iri].undo()
                raise OldapErrorValue(
                    f'{self.name}: Property {prop_iri} with MIN_COUNT={prop.minCount} has not enough values (n={n}).')

        if prop.maxCount and prop.maxCount > 0:  # testing for MAX_COUNT conformance
            n = len(self._values[prop_iri])
            if n > prop.maxCount:
                self._values[prop_iri].undo()
                raise OldapErrorValue(
                    f'{self.name}: Property {prop_iri} with MAX_COUNT={prop.maxCount} has to many values (n={n}).')

        self._changeset[prop_iri] = AttributeChange(None, Action.MODIFY)

    def __attachedToRole_cb(self, old_value: ObservableDict):
        if self._changeset.get(Xsd_QName('oldap:attachedToRole')) is None:
            self._changeset[Xsd_QName('oldap:attachedToRole')] = AttributeChange(old_value, Action.MODIFY)


    def check_for_permissions(self, permission: AdminPermission) -> tuple[bool, str]:
        #
        # First we check if the logged-in user ("actor") has the permission to create a user for
        # the given project!
        #
        actor = self._con.userdata
        sysperms = actor.inProject.get(Iri('oldap:SystemProject', validate=False))
        if sysperms and AdminPermission.ADMIN_OLDAP in sysperms:
            #
            # user has root privileges!
            #
            return True, "OK – IS ROOT"
        else:
            perms = actor.inProject.get(self.project.projectIri)
            if permission in perms:
                return True, "OK",
            else:
                return False, f'Actor does not have {permission} in project "{self.project.projectShortName}".'

    def __get_value(self: Self, attr: Xsd_QName | str) -> Xsd | ValueType | None:
        #attr = Xsd_QName(prefix, fragment, validate=False)
        if not isinstance(attr, Xsd_QName):
            attr = Xsd_QName(attr)
        if attr == Xsd_QName('oldap:attachedToRole'):
            return self._attached_roles
        tmp = self._values.get(attr, None)
        prop = self.properties.get(attr)
        if tmp is not None and _is_dating_property(prop):
            if len(tmp) != 1:
                raise OldapErrorValue(f'{self.name}: Property {attr} should have exactly one Dating value, got {len(tmp)} values.')
            return next(iter(tmp))
        if tmp is not None and prop is not None and prop.datatype == XsdDatatypes.boolean and prop.maxCount == 1:
            if len(tmp) != 1:
                raise OldapErrorValue(f'{self.name}: Property {attr} should have exactly one boolean value, got {len(tmp)} values.')
            return next(iter(tmp))
        if tmp is not None and str(attr) in {'oldap:createdBy', 'oldap:creationDate', 'oldap:lastModifiedBy', 'oldap:lastModificationDate'}:
            if len(tmp) != 1:
                raise OldapErrorValue(f'{self.name}: Property {attr} should have exactly one value, got {len(tmp)} values.')
            return next(iter(tmp))
        return tmp

    def __set_value(self: Self, value: ValueType | Xsd | None, attr: Xsd_QName | str) -> None:
        if not isinstance(attr, Xsd_QName):
            attr = Xsd_QName(attr)

        if attr == Xsd_QName('oldap:attachedToRole'):
            if value is None:
                self._changeset[attr] = AttributeChange(self._values.get(attr), Action.DELETE)
                del self._values[attr]
                self._attached_roles = ObservableDict(notifier=self.__attachedToRole_cb)
                return
            if not isinstance(value, dict):
                raise OldapErrorValue(f'{self.name}: Property {attr} requires a dict, got {type(value).__name__}.')
            for role_qname in value.keys():
                if not isinstance(role_qname, Xsd_QName):
                    raise OldapErrorValue(f'{self.name}: Property {attr} requires keys to be Xsd_QName, got {type(role_qname).__name__}.')
                if not isinstance(value[role_qname], DataPermission):
                    raise OldapErrorValue(f'{self.name}: Property {attr} requires values to be DataPermission, got {type(value[role_qname]).__name__}.')
            self._changeset[attr] = AttributeChange(self._values.get(attr), Action.REPLACE)
            self._values[attr] = ObservableSet(set(value.keys()), notifier=self.notifier, notify_data=attr)
            self._attached_roles = ObservableDict(value, notifier=self.__attachedToRole_cb)
            return
        prop = self.properties.get(attr)
        value = _coerce_property_value(prop, value)

        #
        # Validate
        #
        #if prop.get(PropClassAttr.MIN_COUNT):  # testing for MIN_COUNT conformance
        if prop.minCount:
            if prop.minCount > 0 and _is_empty_property_value(value):
                raise OldapErrorValue(
                    f'{self.name}: Property {attr} with MIN_COUNT={prop.minCount} is missing')
            elif isinstance(value, (list, tuple, set, ObservableSet)) and len(value) < prop.minCount:
                raise OldapErrorValue(
                    f'{self.name}: Property {attr} with MIN_COUNT={prop.minCount} has not enough values')
        if prop.maxCount and prop.maxCount > 0:  # testing for MAX_COUNT conformance
            if isinstance(value, (list, tuple, set, ObservableSet)) and len(value) > prop.maxCount:
                raise OldapErrorValue(
                    f'{self.name}: Property {attr} with MAX_COUNT={prop.maxCount} has to many values (n={len(value)})')
        if not _is_empty_property_value(value):
            if isinstance(value, LangString):
                self.validate_value(value, prop)
            else:
                if isinstance(value, (list, tuple, set, ObservableSet)):
                    for val in value:
                        self.validate_value(val, prop)
                else:
                    self.validate_value(value, prop)

        if _is_empty_property_value(value):
            self._changeset[attr] = AttributeChange(self._values.get(attr), Action.DELETE)
            del self._values[attr]
        elif isinstance(value, (list, tuple, set, LangString)):  # we may have multiple values...
            if self._values.get(attr):
                self._changeset[attr] = AttributeChange(self._values.get(attr), Action.REPLACE)
            else:
                self._changeset[attr] = AttributeChange(None, Action.CREATE)
            if prop.datatype == XsdDatatypes.langString:
                self._values[attr] = LangString(value, notifier=self.notifier, notify_data=attr)
            elif _is_dating_property(prop):
                self._values[attr] = self.__observable_set(set(value), attr, prop)
            else:
                self._values[attr] = self.__observable_set({
                    convert2datatype(x, prop.datatype) for x in value
                }, attr, prop)
        else:
            if self._values.get(attr):
                self._changeset[attr] = AttributeChange(self._values.get(attr), Action.REPLACE)
            else:
                self._changeset[attr] = AttributeChange(None, Action.CREATE)
            if _is_dating_property(prop):
                self._values[attr] = self.__observable_set({value}, attr, prop)
                return
            try:
                self._values[attr] = self.__observable_set({convert2datatype(value, prop.datatype)}, attr, prop)
            except TypeError:
                self._values[attr] = convert2datatype(value, prop.datatype)

    def __del_value(self: Self, attr: Xsd_QName | str) -> None:
        if not isinstance(attr, Xsd_QName):
            attr = Xsd_QName(attr)

        if attr == Xsd_QName('oldap:attachedToRole'):
            self._changeset[attr] = AttributeChange(self._values.get(attr), Action.DELETE)
            del self._values[attr]
            self._attached_roles = ObservableDict(notifier=self.__attachedToRole_cb)
            return
        prop = self.properties.get(attr)

        if prop.minCount:  # testing for MIN_COUNT conformance
            if prop.minCount > 0:
                raise OldapErrorValue(f'{self.name}: Property {attr} with MIN_COUNT={prop.minCount} cannot be deleted.')

        self._changeset[attr] = AttributeChange(self._values.get(attr), Action.DELETE)
        del self._values[attr]

    @property
    def iri(self) -> Iri:
        return self._iri

    @property
    def changeset(self) -> dict[Xsd_QName, AttributeChange]:
        return self._changeset

    @property
    def attachedToRoleAnnotation(self) -> ObservableDict:
        return self._attached_roles

    def clear_changeset(self) -> None:
        for item in self._values:
            if hasattr(self._values[item], 'clear_changeset'):
                self._values[item].clear_changeset()
        self._changeset = {}


    def get_data_permission(self, permission: DataPermission) -> bool:
        context = Context(name=self._con.context_name)
        permission_query = context.sparql_context
        permission_query += textwrap.dedent(f'''
        ASK {{
            {{
                GRAPH {self._graph}:data {{
                    {self._iri.toRdf} oldap:createdBy {self._con.userIri.toRdf} .
                }}
            }}
            UNION
            {{
                GRAPH oldap:admin {{
                    {self._con.userIri.toRdf} oldap:hasRole ?role .
                    ?dataperm oldap:permissionValue ?permval .
                    FILTER(?permval >= {permission.numeric.toRdf})
                }}
                GRAPH {self._graph}:data {{
                    {self._iri.toRdf} oldap:attachedToRole ?role .
                    <<{self._iri.toRdf} oldap:attachedToRole ?role>> oldap:hasDataPermission ?dataperm .
                }}
            }}
        }}''')
        if self._con.in_transaction():
            result = self._con.transaction_query(permission_query)
        else:
            result = self._con.query(permission_query)
        return result['boolean']

    def create(self, indent: int = 0, indent_inc: int = 4) -> str:
        """
        Generates an RDF/SPARQL INSERT DATA query for creating a resource with associated
        metadata and verifies permissions before execution.

        This method first checks for the necessary permissions to create a resource.
        It assigns metadata such as the creation and modification information if
        the resource name matches specific criteria. It ensures that no resource
        with the same IRI exists before proceeding with the resource creation.
        If a conflict is detected, an error is raised. The method finalizes the
        creation of the resource by executing a SPARQL query in a transactional context.

        :param indent: The current level of indentation (default is 0).
        :type indent: int
        :param indent_inc: The incremental spaces per indentation level (default is 4).
        :type indent_inc: int
        :return: A string representing the RDF/SPARQL query for creation.
        :rtype: str
        :raises OldapErrorNoPermission: If the user does not have the required permissions to create the resource.
        :raises OldapErrorAlreadyExists: If a resource with the same IRI already exists.
        :raises OldapError: For errors encountered during the SPARQL transaction execution.
        """
        result, message = self.check_for_permissions(AdminPermission.ADMIN_CREATE)
        if not result:
            raise OldapErrorNoPermission(message)

        timestamp = Xsd_dateTimeStamp()
        if self.name in ("Thing", "oldap:Thing"):
            self._values[Xsd_QName('oldap:createdBy', validate=False)] = ObservableSet({self._con.userIri})
            self._values[Xsd_QName('oldap:creationDate', validate=False)] = ObservableSet({timestamp})
            self._values[Xsd_QName('oldap:lastModifiedBy', validate=False)] = ObservableSet({self._con.userIri})
            self._values[Xsd_QName('oldap:lastModificationDate', validate=False)] = ObservableSet({timestamp})

        indent: int = 0
        indent_inc: int = 4

        blank = ''
        context = Context(name=self._con.context_name)

        #
        # Test if a resource with the same IRI already exists!
        #
        sparql0 = context.sparql_context
        sparql0 += f'ASK {{ GRAPH {self._graph}:data {{ {self._iri.toRdf} ?p ?o }} }}'

        sparql = context.sparql_context
        sparql += f'{blank:{indent * indent_inc}}INSERT DATA {{'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{'

        dating_triples = _dating_insert_triples(self._values)
        for dating_triple in dating_triples:
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}{dating_triple}'

        sparql += f'\n{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} a {self.name}'
        for prop_iri, values in self._values.items():
            if self.properties.get(prop_iri) and self.properties[prop_iri].datatype == XsdDatatypes.QName:
                qnames = {f'"{x}"^^xsd:QName' for x in values}
                qnames_rdf = ', '.join(qnames)
                sparql += f' ;\n{blank:{(indent + 3) * indent_inc}}{prop_iri.toRdf} {qnames_rdf}'
            elif _is_dating_property(self.properties.get(prop_iri)):
                sparql += f' ;\n{blank:{(indent + 3) * indent_inc}}{prop_iri.toRdf} {", ".join(x.iri.toRdf for x in values)}'
            else:
                sparql += f' ;\n{blank:{(indent + 3) * indent_inc}}{prop_iri.toRdf} {values.toRdf}'
        for role, dperm in self._attached_roles.items():
            sparql += f' .\n{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} oldap:attachedToRole {role.toRdf}>> oldap:hasDataPermission {dperm.toRdf}'

        sparql += f' .\n{blank:{(indent + 1) * indent_inc}}}}\n'
        sparql += f'{blank:{indent * indent_inc}}}}\n'
        self._con.transaction_start()
        try:
            result = self._con.transaction_query(sparql0)
            if result['boolean']:
                self._con.transaction_abort()
                raise OldapErrorAlreadyExists(f'Resource with IRI {self._iri} already exists.')
            self._con.transaction_update(sparql)
        except OldapError as e:
            print(sparql)
            self._con.transaction_abort()
            raise
        self._con.transaction_commit()


    @classmethod
    def read(cls,
             con: IConnection,
             iri: Iri) -> Self:
        """
        Reads an object of the specific class type from the RDF data source using the provided connection
        and IRI. Validates that the retrieved RDF data matches the expected class type and ensures proper
        permissions have been granted to access the resource.

        :param con: The connection object to the data source (IConnection).
        :param iri: The IRI of the resource to read (Iri).
        :return: An object of the invoking class loaded with data from the RDF resource.

        :raises OldapErrorInconsistency: If an expected QName is not found or if the retrieved object type
                                          does not match the expected class type.
        :raises OldapErrorNotFound: If the resource associated with the provided IRI is not found.
        """
        graph = cls.project.projectShortName
        try:
            construct_data = _read_resource_construct(con, graph, iri, con.userIri, include_creator=True)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve resource "{iri}"', exc_info=True)
            raise
        objtype, kwargs = _resource_from_construct(iri, construct_data, cls.properties)
        if objtype is None:
            raise OldapErrorNotFound(f'Resource with iri <{iri}> not found.')
        kwargs['attachedToRole'] = _read_attached_roles(con, graph, iri)

        if cls.__name__ != objtype:
            raise OldapErrorInconsistency(f'Expected class {cls.__name__}, got {objtype} instead.')
        return cls(iri=iri, **kwargs)

    def update(self, indent: int = 0, indent_inc: int = 4) -> None:
        """
        Updates the current resource by creating and executing SPARQL queries to modify, insert, or
        delete data based on the changeset. This method also verifies user permissions and ensures
        data consistency using timestamps. It commits modifications within a transaction while
        rolling back changes upon encountering errors.

        The `update` method processes changes in resource attributes specified in a changeset. It
        constructs appropriate SPARQL queries for CREATE, MODIFY, and DELETE actions for each
        field. Additionally, it updates the last modification timestamp for the resource and records
        the user performing the update. If permissions are insufficient or an update fails, the
        transaction is aborted.

        :param indent: The initial level of indentation for the generated SPARQL queries.
        :type indent: int
        :param indent_inc: The incremental level of indentation for nested sections in SPARQL
                           queries.
        :type indent_inc: int
        :return: None
        :rtype: None
        """
        admin_resources, message = self.check_for_permissions(AdminPermission.ADMIN_RESOURCES)

        context = Context(name=self._con.context_name)
        blank = ''
        timestamp = Xsd_dateTimeStamp()

        sparql_list = []
        required_permission = DataPermission.DATA_EXTEND
        for field, change in self._changeset.items():
            if field == 'oldap:attachedToRole':
                required_permission = DataPermission.DATA_PERMISSIONS
                continue
            if _is_dating_property(self.properties.get(field)):
                if change.action != Action.CREATE:
                    if required_permission < DataPermission.DATA_UPDATE:
                        required_permission = DataPermission.DATA_UPDATE
                sparql_list.append(self.__dating_update_sparql(field, change, indent, indent_inc))
                continue
            if change.action == Action.MODIFY:
                continue  # will be processed below!
            if change.action != Action.CREATE:
                if required_permission < DataPermission.DATA_UPDATE:
                    required_permission = DataPermission.DATA_UPDATE
            sparql = f'# Processing field "{field}"\n'
            sparql += f'{blank:{indent * indent_inc}}WITH {self._graph}:data\n'
            if change.action != Action.CREATE:
                sparql += f'{blank:{indent * indent_inc}}DELETE {{\n'
                if isinstance(change.old_value, (ObservableSet, LangString)):
                    for val in change.old_value:
                        sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {val.toRdf} .\n'
                else:
                    sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {change.old_value.toRdf} .\n'
                sparql += f'{blank:{indent * indent_inc}}}}\n'
            if change.action != Action.DELETE:
                sparql += f'{blank:{indent * indent_inc}}INSERT {{\n'
                if isinstance(change.old_value, (ObservableSet, LangString)):
                    for val in self._values[field]:
                        sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {val.toRdf} .\n'
                else:
                    sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {self._values[field].toRdf} .\n'
                sparql += f'{blank:{indent * indent_inc}}}}\n'
            sparql += f'{blank:{indent * indent_inc}}WHERE {{\n'
            sparql += f'{blank:{(indent + 1) * indent_inc}}BIND({self._iri.toRdf} as ?res_iri)\n'
            if change.action != Action.CREATE:
                if isinstance(change.old_value, (ObservableSet, LangString)):
                    for val in change.old_value:
                        sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {val.toRdf} .\n'
                else:
                    sparql += f'{blank:{(indent + 1) * indent_inc}}?res_iri {field.toRdf} {change.old_value.toRdf} .\n'
            sparql += f'{blank:{indent * indent_inc}}}}'
            sparql_list.append(sparql)

        for field, change in self._changeset.items():
            if field == 'oldap:attachedToRole':
                sparql = f'# Processing field "{field}"\n'
                add_sparql = False
                if (change.action == Action.DELETE or change.action == Action.REPLACE) and len(change.old_value) > 0:
                    sparql += f'{blank:{indent * indent_inc}}DELETE DATA {{\n'
                    sparql += f'{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{\n'
                    for role, dperm in change.old_value.items():
                        sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                        sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {dperm.toRdf} .\n'
                    sparql += f'{blank:{(indent + 1) * indent_inc}}}}\n'
                    sparql += f'{blank:{indent * indent_inc}}}}\n'
                    add_sparql = True
                elif (change.action == Action.CREATE or change.action == Action.REPLACE) and len(self._attached_roles) > 0:
                    sparql += f'{blank:{indent * indent_inc}}INSERT DATA {{\n'
                    sparql += f'{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{\n'
                    for role, dperm in self._attached_roles.items():
                        sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                        sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {dperm.toRdf} .\n'
                    sparql += f'{blank:{(indent + 1) * indent_inc}}}}\n'
                    sparql += f'{blank:{indent * indent_inc}}}}\n'
                    add_sparql = True
                elif change.action == Action.MODIFY:
                    added = {}
                    removed = {}
                    changed = {}
                    if change.old_value:
                        added = {key: self._attached_roles[key] for key in self._attached_roles.keys() - change.old_value.keys()}
                    else:
                        added = self._attached_roles
                    if change.old_value:
                        removed = {key: change.old_value[key] for key in
                                   change.old_value.keys() - self._attached_roles.keys()}
                    else:
                        removed = {}
                    if change.old_value:
                        changed = {key: {'old': change.old_value.get(key),
                                         'new': self._attached_roles.get(key)}
                                   for key in change.old_value.keys() & self._attached_roles.keys()
                                   if self._attached_roles[key] != change.old_value[key]}
                    else:
                        changed = {}
                    if len(removed) > 0 or len(changed) > 0:
                        sparql += f'{blank:{indent * indent_inc}}DELETE DATA {{\n'
                        sparql += f'{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{\n'
                        for role, dperm in removed.items():
                            sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                            sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {dperm.toRdf} .\n'
                        for role, data in changed.items():
                            sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                            sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {data['old'].toRdf} .\n'
                        sparql += f'{blank:{(indent + 1) * indent_inc}}}}\n'
                        sparql += f'{blank:{indent * indent_inc}}}}\n'
                        add_sparql = True
                    if len(added) > 0 or len(changed) > 0:
                        if add_sparql:
                            sparql += f'{blank:{indent * indent_inc}}\n;\n'
                        sparql += f'{blank:{indent * indent_inc}}INSERT DATA {{\n'
                        sparql += f'{blank:{(indent + 1) * indent_inc}}GRAPH {self._graph}:data {{\n'
                        for role, dperm in added.items():
                            sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                            sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {dperm.toRdf} .\n'
                        for role, data in changed.items():
                            sparql += f'{blank:{(indent + 2) * indent_inc}}{self._iri.toRdf} {field.toRdf} {role.toRdf} .\n'
                            sparql += f'{blank:{(indent + 2) * indent_inc}}<<{self._iri.toRdf} {field.toRdf} {role.toRdf}>> oldap:hasDataPermission  {data['new'].toRdf} .\n'
                        sparql += f'{blank:{(indent + 1) * indent_inc}}}}\n'
                        sparql += f'{blank:{indent * indent_inc}}}}\n'
                        add_sparql = True
                if add_sparql:
                    sparql_list.append(sparql)
                continue

            if change.action != Action.MODIFY:
                continue  # has been processed above
            if self.properties[field].datatype == XsdDatatypes.langString:
                sparqls = self._values[field].update(graph=Xsd_QName(self._graph, 'data'),
                                                     subject=self._iri,
                                                     field=field.as_qname)
                for lang, lchange in self._values[field].changeset.items():
                    if lchange.action != Action.CREATE:
                        if required_permission < DataPermission.DATA_UPDATE:
                            required_permission = DataPermission.DATA_UPDATE
                sparql_list.extend(sparqls)
            else:
                #
                # first we rectify the datatype of all "new" values added to the set
                #
                newset = {convert2datatype(x, self.properties[field].datatype) for x in self._values[field]}
                self._values[field] = self.__observable_set(newset,
                                                            field,
                                                            self.properties[field],
                                                            old_value=self._values[field].old_value)
                sparqls = self._values[field].update_sparql(graph=Iri(f'{self._graph}:data'),
                                                            subject=self._iri,
                                                            field=field)
                sparql_list.extend(sparqls)

        sparql = context.sparql_context
        sparql += f'# Updating resource "{self._iri}"\n'
        sparql += " ;\n".join(sparql_list)

        modtime_update = context.sparql_context
        modtime_update += f'''
        WITH {self._graph}:data
        DELETE {{
            ?res oldap:lastModificationDate {self.lastModificationDate.toRdf} .
            ?res oldap:lastModifiedBy ?contributor .
        }}
        INSERT {{
            ?res oldap:lastModificationDate {timestamp.toRdf} .
            ?res oldap:lastModifiedBy {self._con.userIri.toRdf} .
        }}
        WHERE {{
            BIND({self._iri.toRdf} as ?res)
            ?res oldap:lastModificationDate {self.lastModificationDate.toRdf} .
            ?res oldap:lastModifiedBy ?contributor .
        }}
        '''

        context = Context(name=self._con.context_name)
        modtime_get = context.sparql_context
        modtime_get += f"""
        SELECT ?modified
        FROM {self._graph}:data
        WHERE {{
            {self._iri.toRdf} oldap:lastModificationDate ?modified
        }}
        """

        self._con.transaction_start()
        #
        # Test permission for Action.REPLACE
        #
        if not admin_resources:
            if not self.get_data_permission(required_permission):
                self._con.transaction_abort()
                raise OldapErrorNoPermission(f'No permission to update resource "{self._iri}"')
        try:
            for field, change in self._changeset.items():
                if _is_dating_property(self.properties.get(field)):
                    inuse = self.__dating_delete_is_referenced_sparql(field, change)
                    if inuse and self._con.transaction_query(inuse)['boolean']:
                        raise OldapErrorInUse(
                            f'Dating value of property "{field}" cannot be deleted because another Dating value refers to it with oldap:before.')
            self._con.transaction_update(sparql)
            self._con.transaction_update(modtime_update)
            jsonobj = self._con.transaction_query(modtime_get)
            res = QueryProcessor(context, jsonobj)
            modtime = res[0]['modified']
            if timestamp != modtime:
                raise OldapErrorUpdateFailed(f"Update failed! Timestamp does not match (modtime={modtime}, timestamp={timestamp}).")
        except OldapError:
            logger.error(f'Failed to update resource "{self._iri}"', exc_info=True)
            self._con.transaction_abort()
            raise
        try:
            self._con.transaction_commit()
        except OldapError:
            logger.error(f'Failed to commit transaction for resource "{self._iri}"', exc_info=True)
            self._con.transaction_abort()
            raise
        self.clear_changeset()

    def delete(self) -> None:
        """
        Deletes the specified resource represented by the object's IRI from the associated graph
        if the proper permissions are granted and the resource is not in use. This method initiates
        a transactional sequence to ensure data consistency and rollback in case of an error.
        The process includes checking permissions, querying whether the resource is in use,
        and finally issuing a SPARQL DELETE query to remove the resource.

        Raises appropriate exceptions if the resource is in use, permissions are insufficient,
        or any other transaction-related error occurs.

        :raises OldapErrorNoPermission: If the user lacks the necessary permissions to
            delete the resource.
        :raises OldapErrorInUse: If the resource is currently in use and cannot be deleted.
        :raises OldapError: If any error occurs during transaction start, query, update,
            or commit phases.
        """
        admin_resources, message = self.check_for_permissions(AdminPermission.ADMIN_RESOURCES)

        context = Context(name=self._con.context_name)
        inuse = context.sparql_context
        inuse += f"""
        ASK {{
            GRAPH ?g {{
                ?res ?prop {self._iri.toRdf} .
            }}
        }}
        """

        context = Context(name=self._con.context_name)
        sparql = context.sparql_context
        sparql += f"""
        DELETE WHERE {{
            GRAPH {self._graph}:data {{
                {self._iri.toRdf} ?prop ?val .
                << {self._iri.toRdf} oldap:attachedToRole ?role >> oldap:hasDataPermission ?dataperm .
            }}
        }} 
        """

        self._con.transaction_start()
        if not admin_resources:
            if not self.get_data_permission(DataPermission.DATA_DELETE):
                self._con.transaction_abort()
                raise OldapErrorNoPermission(f'No permission to update resource "{self._iri}"')
        try:
            result = self._con.transaction_query(inuse)
            if result['boolean']:
                raise OldapErrorInUse(f'Resource "{self._iri}" is in use and cannot be deleted.')
        except OldapError:
            logger.error(f'SPARQL: Failed to check whether resource "{self._iri}" is in use', exc_info=True)
            self._con.transaction_abort()
            raise
        try:
            self._con.transaction_update(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to delete resource "{self._iri}"', exc_info=True)
            self._con.transaction_abort()
            raise
        try:
            self._con.transaction_commit()
        except OldapError:
            logger.error(f'SPARQL: Failed to commit transaction for resource "{self._iri}"', exc_info=True)
            self._con.transaction_abort()
            raise

    @staticmethod
    def read_data(con: IConnection, projectShortName: Xsd_NCName | str, iri: Iri | str) -> dict[Xsd_QName, Any]:
        """
        Retrieves data from a resource in the specified project with permissions validation.
        NOTE: It does *NOT* return the attachedToRole data!

        This function performs a SPARQL query to fetch data associated with the given
        IRI within a specific project graph, taking into account user permissions for
        the resource. If no data is found for the given IRI, or if permission requirements
        are not met, exceptions are raised.

        :param con: A connection object used to interact with the database.
        :type con: IConnection
        :param projectShortName: The short name of the project graph. Can be an Xsd_NCName
            or string.
        :type projectShortName: Xsd_NCName | str
        :param iri: The IRI of the resource to retrieve data for. Can be an Iri instance
            or string.
        :type iri: Iri | str
        :return: A dictionary mapping predicates (of type Xsd_QName) to their corresponding
            values.
        :rtype: dict[Xsd_QName, Any]
        :raises OldapErrorInconsistency: If a predicate is not a valid QName.
        :raises OldapErrorNotFound: If the resource with the specified IRI cannot be found.
        """
        if not isinstance(iri, Iri):
            iri = Iri(iri, validate=True)
        if not isinstance(projectShortName, Xsd_NCName):
            graph = Xsd_NCName(projectShortName)
        else:
            graph = projectShortName

        context = Context(name=con.context_name)

        #
        # In order for the QueryProcessor to work, we need to add possible list references to the context.
        # This is done by reading the OldapList (which does add the list to the context)
        #
        ols = OldapList.search(con=con, project=projectShortName)  # Get all the lists in the project
        for ol in ols:
            oldaplist = OldapList.read(con=con, project=projectShortName, oldapListId=ol.fragment)
            (oldaplist)

        try:
            construct_data = _read_resource_construct(con, graph, iri, con.userIri, include_creator=True)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve data for resource "{iri}"', exc_info=True)
            raise
        resource_data = construct_data.get(_construct_subject_key(iri))
        if resource_data is None:
            raise OldapErrorNotFound(f'Resource with iri <{iri}> not found.')

        data: dict[Xsd_QName | str, Any] = {}
        dating_cache: dict[Iri | Xsd_QName, Any] = {}
        for predicate, value in resource_data.items():
            if predicate == READ_PERM_BINDING_PRED or predicate == Xsd_QName('oldap:attachedToRole'):
                continue
            if not isinstance(predicate, Xsd_QName):
                raise OldapErrorInconsistency(f"Expected QName as predicate, got {predicate}")
            values = [
                _convert_construct_value(item, None, construct_data, dating_cache)
                for item in _construct_values(resource_data, predicate)
            ]
            data[str(predicate)] = values
        if not data.get('rdf:type'):
            raise OldapErrorNotFound(f'Resource with iri <{iri}> not found.')

        data[Xsd_QName('oldap:attachedToRole')] = _read_attached_roles(con, graph, iri)
        #data[Xsd_QName('virtual:resourceIri')] = iri
        return data

    """
    PREFIX luc: <http://www.ontotext.com/connectors/lucene#>
    SELECT DISTINCT ?res ?o ?score
    WHERE {
        GRAPH oldap:admin {
            <https://orcid.org/0000-0003-1681-4036> oldap:hasRole ?role .
            ?DataPermission oldap:permissionValue ?permval .
            FILTER(?permval >= "2"^^xsd:integer)
        }
        GRAPH fasnacht:data {
            ?res fasnacht:storyContent ?o .
            ?res rdf:type fasnacht:Story .
            ?res oldap:attachedToRole ?role .
            << ?res oldap:attachedToRole ?role >> oldap:hasDataPermission ?DataPermission .
        }
        ?search a inst:fasnacht ;
            luc:query "content:fasnacht AND gugge" ;
            luc:entities ?res .
        ?res luc:score ?score .
    }
    ORDER BY DESC(?score)
    LIMIT 100 OFFSET 0
    
    """

    """
    PREFIX :<http://www.ontotext.com/connectors/lucene#>
    PREFIX inst:<http://www.ontotext.com/connectors/lucene/instance#>
    INSERT DATA {
        inst:fasnacht :createConnector '''
    {
      "fields": [
        {
          "fieldName": "storyContent",
          "propertyChain": [
            "http://fasnacht.digital/ns/storyContent"
          ],
          "indexed": true,
          "stored": false,
          "analyzed": true,
          "multivalued": true,
          "ignoreInvalidValues": false,
          "facet": false
        }
      ],
      "languages": [],
      "types": [
        "http://fasnacht.digital/ns/Story"
      ],
      "readonly": false,
      "detectFields": false,
      "importGraph": false,
      "skipInitialIndexing": false,
      "boostProperties": [],
      "stripMarkup": false
    }
    ''' .
    }
    """

    """
    FULLTEXT query:
    
    1) the connector must have the name of project
    2) 
    """
    @staticmethod
    def search(con: IConnection,
               project: Project | Xsd_NCName | Iri| str,
               resClass: Xsd_QName | str | None = None,
               includeProperties: set[Xsd_QName] | None = None,
               filter: list[SearchFilter | LogicOp] | None = None,  # "normal" filter operations
               ftfilter: list[FTSearchFilter | Literal['AND', 'OR']] | None = None,  # fulltext filter operations
               hlfilter: list[HLSearchFilter | LogicOp] | None = None,  # hierarchical list filter operations
               sortBy: list[SortBy] | None = None,
               countOnly: bool = False,
               limit: int = 100,
               offset: int = 0,
               indent: int = 0, indent_inc: int = 4) -> int | list[dict[str, Any]]:
        if not resClass and not filter and not ftfilter and not hlfilter:
            raise OldapErrorValue('Search without filters requires resClass.')

        if not isinstance(project, Project):
            project_obj = Project.read(con=con,
                                       projectIri_SName=project)
        else:
            project_obj = project

        graph = project_obj.projectShortName
        if resClass:
            if not isinstance(resClass, Xsd_QName):
                _resClass = Xsd_QName(resClass, validate=True)
            else:
                _resClass = resClass
        else:
            _resClass = None

        #
        # first we check if we are searching for a hlist node
        #
        nodes: dict[HListNode, OldapListNode] = {}
        if hlfilter:
            hlists: dict[str, OldapList] = {}
            for hlf in hlfilter:
                if isinstance(hlf, LogicOp):
                    continue
                if not hlists.get(hlf.node.listId):
                    hlists[hlf.node.listId] = OldapList.read(con=con, project=project_obj, oldapListId=hlf.node.listId)
                if nodes.get(hlf.node) is None:
                    nodes[hlf.node] = OldapListNode.read(con=con, **hlists[hlf.node.listId].info, oldapListNodeId=hlf.node.nodeId)

        blank = ''
        context = Context(name=con.context_name)
        if ftfilter:
            context['luc'] = NamespaceIRI('http://www.ontotext.com/connectors/lucene#')
            context['inst'] = NamespaceIRI('http://www.ontotext.com/connectors/lucene/instance#')
        sparql = context.sparql_context
        sparql_vars: set[tuple[str,str]] = {('res', 'res'), ('resclass', 'resclass')}
        dating_filter_props = {f.prop for f in filter or [] if isinstance(f, SearchFilter) and isinstance(f.value, Dating)}

        def sparql_comp_op(op: CompOp) -> str:
            match op:
                case CompOp.EQ:
                    return '='
                case CompOp.NE:
                    return '!='
                case CompOp.LT:
                    return '<'
                case CompOp.LE:
                    return '<='
                case CompOp.GT:
                    return '>'
                case CompOp.GE:
                    return '>='
                case _:
                    raise OldapErrorValue(f'Unsupported comparison operator {op}.')

        def is_dating_sort(sort: SortBy) -> bool:
            if sort.kind == SortKind.DATING:
                return True
            if sort.kind == SortKind.VALUE:
                return False
            return sort.property in dating_filter_props

        if (countOnly):
            sparql += f'{blank:{indent * indent_inc}}SELECT (COUNT(DISTINCT ?res) as ?numResult)'
        else:
            sparql += f'{blank:{indent * indent_inc}}SELECT DISTINCT ?res ?resclass'
            if ftfilter:
                sparql += ' ?score'
                sparql_vars.add(('score', 'score'))

        if includeProperties:
            for p in includeProperties:
                sparql += f' ?{p.fragment}'
                sparql_vars.add((f'{p.fragment}', str(p)))
        if sortBy:
            for s in sortBy:
                if is_dating_sort(s):
                    continue
                tmp = includeProperties if includeProperties else set()
                if s.property not in tmp:
                    sparql += f' ?{s.property.fragment}'
                    sparql_vars.add((f'{s.property.fragment}', str(s.property)))

        sparql += f'\n{blank:{indent * indent_inc}}WHERE {{'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH oldap:admin {{'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}{con.userIri.toRdf} oldap:hasRole ?role .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?DataPermission oldap:permissionValue ?permval .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER(?permval >= {DataPermission.DATA_VIEW.numeric.toRdf})'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH {graph}:data {{'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?res rdf:type ?resclass .'
        if _resClass:
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}?res rdf:type {_resClass.toRdf} .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?res oldap:attachedToRole ?role .'

        tmp = includeProperties if includeProperties else set()
        for p in tmp:
            if filter and any({f.prop == p for f in filter if not isinstance(f, LogicOp)}) and not (
                sortBy and any(s.property == p and is_dating_sort(s) for s in sortBy)
            ):
                continue
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}OPTIONAL {{ ?res {p.toRdf} ?{p.fragment} }} .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}<< ?res oldap:attachedToRole ?role >> oldap:hasDataPermission ?DataPermission .'

        if sortBy:
            for sort_index, s in enumerate(sortBy):
                if not is_dating_sort(s):
                    continue
                dating_sort_var = f'{s.property.fragment}_sort_{sort_index}'
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}OPTIONAL {{'
                sparql += f'\n{blank:{(indent + 3) * indent_inc}}?res {s.property.toRdf} ?{dating_sort_var} .'
                sparql += f'\n{blank:{(indent + 3) * indent_inc}}?{dating_sort_var} oldap:normalizedStart ?{dating_sort_var}_start .'
                sparql += f'\n{blank:{(indent + 3) * indent_inc}}?{dating_sort_var} oldap:normalizedEnd ?{dating_sort_var}_end .'
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}}}'

        if filter:
            for filter_index, f in enumerate(filter):
                if isinstance(f, LogicOp):
                    continue
                if isinstance(f.value, Dating):
                    dating_var = f'{f.prop.fragment}_dating_{filter_index}'
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}?res {f.prop.toRdf} ?{dating_var} .'
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}?{dating_var} oldap:normalizedStart ?{dating_var}_start .'
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}?{dating_var} oldap:normalizedEnd ?{dating_var}_end .'
                else:
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}OPTIONAL {{ ?res {f.prop.toRdf} ?{f.prop.fragment} }}.'
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER('
            langfilters: list[str] = []
            for filter_index, f in enumerate(filter):
                if isinstance(f, LogicOp):
                    sparql+= f' {f.value} '
                else:
                    if isinstance(f.value, Dating):
                        dating_var = f'{f.prop.fragment}_dating_{filter_index}'
                        target_start = f'"{f.value._normalizedStart.isoformat()}"^^xsd:date'
                        target_end = f'"{f.value._normalizedEnd.isoformat()}"^^xsd:date'
                        if f.op == CompOp.EQ:
                            sparql += f'(?{dating_var}_start = {target_start} && ?{dating_var}_end = {target_end})'
                        elif f.op == CompOp.NE:
                            sparql += f'(?{dating_var}_start != {target_start} || ?{dating_var}_end != {target_end})'
                        elif f.op == CompOp.OVERLAPS:
                            sparql += f'(?{dating_var}_end >= {target_start} && ?{dating_var}_start <= {target_end})'
                        elif f.op == CompOp.BEFORE:
                            sparql += f'(?{dating_var}_end < {target_start})'
                        elif f.op == CompOp.AFTER:
                            sparql += f'(?{dating_var}_start > {target_end})'
                        else:
                            raise OldapErrorValue(f'Unsupported Dating search operator {f.op} for property {f.prop}.')
                    elif f.op in {CompOp.EQ, CompOp.GT, CompOp.GE, CompOp.LT, CompOp.LE, CompOp.NE}:
                        op = sparql_comp_op(f.op)
                        if isinstance(f.value, Xsd_string) and f.value.lang:
                            sparql += f'?{f.prop.fragment} {op} "{f.value.value}"'
                            langfilters.append(f'FILTER(LANG(?{f.prop.fragment}) = "{f.value.lang.shortlang}")')
                        else:
                            sparql += f'?{f.prop.fragment} {op} {f.value.toRdf}'
                    elif f.op == CompOp.CONTAINS:  # TODO: DEAL WITH LANGUAGES!!
                        if isinstance(f.value, Xsd_string) and f.value.lang is None:
                            sparql += f'CONTAINS(LCASE(STR(?{f.prop.fragment})), LCASE(STR("{f.value.value}")))'
                        else:
                            sparql += f'CONTAINS(LCASE(STR(?{f.prop.fragment})), LCASE(STR("{f.value.value}")))'
                            langfilters.append(f'FILTER(LANG(?{f.prop.fragment}) = "{f.value.lang.shortlang}")')
                    elif f.op == CompOp.REGEXP:
                        if isinstance(f.value, Xsd_string) and f.value.lang:
                            sparql += f'REGEX(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                        else:
                            sparql += f'REGEX(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                            langfilters.append(f'FILTER(LANG(?{f.prop.fragment}) = "{f.value.lang.shortlang}")')
                    elif f.op == CompOp.STRSTARTS:
                        if isinstance(f.value, Xsd_string) and f.value.lang:
                            sparql += f'STRSTARTS(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                        else:
                            sparql += f'STRSTARTS(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                            langfilters.append(f'FILTER(LANG(?{f.prop.fragment}) = "{f.value.lang.shortlang}")')
                    elif f.op == CompOp.STRENDS:
                        if isinstance(f.value, Xsd_string) and f.value.lang:
                            sparql += f'STRENDS(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                        else:
                            sparql += f'STRENDS(STR(?{f.prop.fragment}), STR("{f.value.value}"), "i"'
                            langfilters.append(f'FILTER(LANG(?{f.prop.fragment}) = "{f.value.lang.shortlang}")')
            sparql += f')'
            for lf in langfilters:
                f'\n{blank:{(indent + 2) * indent_inc}}{lf}'

        if hlfilter:
            for hlf in hlfilter:
                if isinstance(hlf, LogicOp):
                    continue
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}?res {hlf.prop.toRdf} ?{hlf.prop.fragment} .'

        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'


        if hlfilter:
            sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH {graph}:lists {{'
            for hlf in hlfilter:
                if isinstance(hlf, LogicOp):
                    continue
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}?{hlf.prop.fragment} oldap:leftIndex ?{hlf.prop.fragment}_lindex .'
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}?{hlf.prop.fragment} oldap:rightIndex ?{hlf.prop.fragment}_rindex .'
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER('
            for hlf in hlfilter:
                if isinstance(hlf, LogicOp):
                    sparql+= f' {hlf.value} '
                else:
                    node_lindex = nodes[hlf.node].leftIndex
                    node_rindex = nodes[hlf.node].rightIndex
                    sparql += f'({node_lindex} >= ?{hlf.prop.fragment}_lindex && {node_rindex} <= ?{hlf.prop.fragment}_rindex)'
            sparql += ')'

            sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'

        if ftfilter:
            sparql += f'\n{blank:{(indent + 1) * indent_inc}}?search a inst:{str(project_obj.projectShortName)} ;'
            fields = _lucene_query_fields(ftfilter)
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}luc:query "{fields}" ;'
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}luc:entities ?res .'
            # sparql += f'\n{blank:{(indent + 3) * indent_inc}}luc:property fasnacht:storyContent ;'  # if we only want a specific property!
            sparql += f'\n{blank:{(indent + 1) * indent_inc}}?res luc:score ?score .'

        sparql += f'\n{blank:{indent * indent_inc}}}}'

        if ftfilter or sortBy:
            sparql += f'\n{blank:{indent * indent_inc}}ORDER BY'
        if ftfilter:
            sparql += ' DESC(?score)'
        if sortBy:
            for sort_index, s in enumerate(sortBy):
                if is_dating_sort(s):
                    dating_sort_var = f'{s.property.fragment}_sort_{sort_index}'
                    if s.dir == SortDir.asc:
                        sparql += f' ASC(?{dating_sort_var}_start) ASC(?{dating_sort_var}_end)'
                    else:
                        sparql += f' DESC(?{dating_sort_var}_start) DESC(?{dating_sort_var}_end)'
                elif s.dir == SortDir.asc:
                    sparql += f' ASC(?{s.property.fragment})'
                else:
                    sparql += f' DESC(?{s.property.fragment})'

        if not countOnly:
            sparql += f'\n{blank:{indent * indent_inc}}LIMIT {limit} OFFSET {offset}'
        sparql += '\n'

        try:
            jsonres = con.query(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to search for resources in project "{project_obj.projectShortName}"', exc_info=True)
            raise
        res = QueryProcessor(context, jsonres)
        if countOnly:
            return res[0]['numResult']
        else:
            result: list[dict[str, Any]] = []
            by_iri: dict[Iri, dict[str, Any]] = {}
            for r in res:
                iri = r['res']
                if iri not in by_iri:
                    by_iri[iri] = {'iri': iri}
                    result.append(by_iri[iri])
                item = by_iri[iri]
                for p in sparql_vars:
                    if p[0] == 'res':
                        continue
                    value = r[p[0]] if r.get(p[0]) is not None else None
                    if p[0] == 'resclass' or p[0] == 'score':
                        item[p[1]] = value
                    elif value is not None:
                        item.setdefault(p[1], [])
                        if value not in item[p[1]]:
                            item[p[1]].append(value)
            return result

    # @staticmethod
    # def search_fulltext(*args, **kwargs) -> int | list[dict[str, Any]]:
    #     return ResourceInstance.search(*args, **kwargs)


    @staticmethod
    def search_fulltext(con: IConnection,
                        project: Project | Xsd_NCName | str,
                        searchstr: str,
                        resClass: Xsd_QName | str | None = None,
                        countOnly: bool = False,
                        sortBy: list[SortBy] = [],
                        limit: int = 100,
                        offset: int = 0,
                        indent: int = 0, indent_inc: int = 4) -> int | list[dict[str, Xsd]]:
        if isinstance(project, Project):
            graph = Xsd_QName(project.projectShortName, 'data')
        elif isinstance(project, Xsd_NCName):
            graph = Xsd_QName(project, 'data')
        else:
            graph = Xsd_QName(project, 'data', validate=True)
        if resClass and not isinstance(resClass, Xsd_QName):
            resClass = Xsd_QName(resClass, validate=True)

        blank = ''
        context = Context(name=con.context_name)
        sparql = context.sparql_context

        select_count = 'SELECT (COUNT(DISTINCT ?s) as ?numResult)'
        select = 'SELECT DISTINCT ?s ?p ?o'
        if (countOnly):
            sparql += f'{blank:{indent * indent_inc}}SELECT (COUNT(DISTINCT ?s) as ?numResult)'
        else:
            sparql += f'{blank:{indent * indent_inc}}SELECT DISTINCT ?s ?t ?p ?o'
            if sortBy:
                for sortby in sortBy:
                    if sortby.property == Xsd_QName('oldap:creationDate'):
                        sparql += ' ?creationDate'
                    elif sortby.property == Xsd_QName('oldap:lastModificationDate'):
                        sparql += '?lastModificationDate'

        sparql += f'\n{blank:{indent * indent_inc}}WHERE {{'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH oldap:admin {{'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}{con.userIri.toRdf} oldap:hasRole ?role .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?DataPermission oldap:permissionValue ?permval .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER(?permval >= {DataPermission.DATA_VIEW.numeric.toRdf})'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH {graph.toRdf} {{'
        if not countOnly and sortBy:
            for sortby in sortBy:
                if sortby.property == Xsd_QName('oldap:creationDate'):
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s oldap:creationDate ?creationDate .'
                elif sortby.property == Xsd_QName('oldap:lastModificationDate'):
                    sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s oldap:lastModificationDate ?lastModificationDate .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s ?p ?o .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s rdf:type ?t .'
        if resClass:
            sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s rdf:type {resClass} .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s oldap:attachedToRole ?role .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}<< ?s oldap:attachedToRole ?role >> oldap:hasDataPermission ?DataPermission .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER(isLiteral(?o) && (datatype(?o) = xsd:string || datatype(?o) = rdf:langString || lang(?o) != ""))'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER(CONTAINS(LCASE(STR(?o)), "{searchstr}"))  # case-insensitive substring match'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'
        sparql += f'\n{blank:{indent * indent_inc}}}}'

        if not countOnly and sortBy:
            for sortby in sortBy:
                if sortby.property == Xsd_QName('oldap:creationDate'):
                    if sortby.dir == SortDir.asc:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY ASC(?creationDate)'
                    else:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY DESC(?creationDate)'
                elif sortby.property == Xsd_QName('oldap:lastModificationDate'):
                    if sortby.dir == SortDir.asc:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY ASC(?lastModificationDate)'
                    else:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY DESC(?lastModificationDate)'
                elif sortby.property == Xsd_QName('oldap:propval'):
                    if sortby.dir == SortDir.asc:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY ASC(?o)'
                    else:
                        sparql += f'\n{blank:{indent * indent_inc}}ORDER BY DESC(?o)'

        if not countOnly:
            sparql += f'\n{blank:{indent * indent_inc}}LIMIT {limit} OFFSET {offset}'
        sparql += '\n'

        try:
            jsonres = con.query(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to search for resources in graph "{graph}"', exc_info=True)
            raise
        res = QueryProcessor(context, jsonres)
        if countOnly:
            return res[0]['numResult']
        else:
            result = []
            for r in res:
                tmp = {
                    'iri': r['s'],
                    str(r['p']): r['o'],
                    'resclass': r['t']
                }
                if sortBy:
                    for sortby in sortBy:
                        if sortby.property == Xsd_QName('oldap:creationDate'):
                            tmp['oldap:creationDate'] = r['creationDate'],
                        elif sortby.property == Xsd_QName('oldap:lastModificationDate'):
                            tmp['oldap:lastModificationDate'] = r['lastModificationDate']
                result.append(tmp)
            return result



    @staticmethod
    def all_resources(con: IConnection,
                      project: Project | Xsd_NCName | str,
                      resClass: Xsd_QName | str,
                      includeProperties: list[Xsd_QName] | None = None,
                      countOnly: bool = False,
                      sortBy: list[SortBy] = [],
                      limit: int = 100,
                      offset: int = 0,
                      indent: int = 0, indent_inc: int = 4) -> list[dict[str | Xsd_QName, list[Xsd] | LangString]] | int:

        if isinstance(project, str):
            project = Xsd_NCName(project, validate=True)
        if not isinstance(project, Project):
            project = Project.read(con=con, projectIri_SName=project)
        graph = Xsd_QName(project.projectShortName, 'data')
        if not isinstance(resClass, Xsd_QName):
            resClass = Xsd_QName(resClass, validate=True)

        if sortBy:
            for s in sortBy:
                if not isinstance(s, SortBy):
                    raise OldapErrorType(f'Expected SortBy, got {type(s)}')
                if not includeProperties or s.property not in includeProperties:
                    if not includeProperties:
                        includeProperties = []
                    includeProperties.append(s.property)

        blank = ''
        context = Context(name=con.context_name)
        sparql = context.sparql_context

        if (countOnly):
            sparql += f'{blank:{indent * indent_inc}}SELECT (COUNT(DISTINCT ?s) as ?numResult)'
        else:
            sparql += f'{blank:{indent * indent_inc}}SELECT DISTINCT ?s'
            if includeProperties:
                for index, item in enumerate(includeProperties):
                    sparql += f' ?o{index}'
        sparql += f'\n{blank:{indent * indent_inc}}WHERE {{'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH oldap:admin {{'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}{con.userIri.toRdf} oldap:hasRole ?role .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?dataperm oldap:permissionValue ?permval .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}FILTER(?permval >= {DataPermission.DATA_VIEW.numeric.toRdf})'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}GRAPH {graph.toRdf} {{'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s rdf:type {resClass} .'  # TODO: REMOVE WHEN ONTO FIXED!
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}?s oldap:attachedToRole ?role .'
        sparql += f'\n{blank:{(indent + 2) * indent_inc}}<< ?s oldap:attachedToRole ?role >> oldap:hasDataPermission ?dataperm .'
        if includeProperties:
            for index, prop in enumerate(includeProperties):
                sparql += f'\n{blank:{(indent + 2) * indent_inc}}OPTIONAL {{ ?s {prop} ?o{index} . }}'
        sparql += f'\n{blank:{(indent + 1) * indent_inc}}}}'
        #sparql += f'\n{blank:{(indent + 1) * indent_inc}}?s rdf:type {resClass} .'  # TODO: REINSTATE WHEN ONTO FIXED!
        sparql += f'\n{blank:{indent * indent_inc}}}}'

        if not countOnly and sortBy:
            sparql += f'\n{blank:{indent * indent_inc}}ORDER BY'
            for s in sortBy:
                if s.dir == SortDir.asc:
                    sparql += f' ASC(?o{includeProperties.index(s.property)})'
                else:
                    sparql += f' DESC(?o{includeProperties.index(s.property)})'
            sparql += '\n'

        if not countOnly:
            sparql += f'\n{blank:{indent * indent_inc}}LIMIT {limit} OFFSET {offset}'
        sparql += '\n'

        try:
            jsonres = con.query(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve resources for project "{projectShortName}"', exc_info=True)
            raise
        res = QueryProcessor(context, jsonres)
        if countOnly:
            return res[0]['numResult']
        else:
            result: list[dict[str, list[Xsd] | LangString]] = []

            for r in res:
                resiri = r['s']
                if not result:
                    result.append({'iri': [resiri]})
                resource = None
                for x in result: # we check if the arre already contains a resource with the given IRI
                    if resiri == x['iri'][0]:
                        resource = x  # yes, we assign it to resource
                if not resource:
                    resource = {'iri': [r['s']]}  # no, we create it (The resource IRI didn't yet occur in the result
                    result.append(resource)
                if includeProperties:
                    for index, property in enumerate(includeProperties):
                        if resource.get(property, None) is None:
                            resource[property] = []
                        raw = r.get(f'o{index}')
                        if raw is None:
                            continue
                        if raw not in resource[property]:
                            resource[property].append(raw)
            if includeProperties:
                for resource in result:
                    for index, property in enumerate(includeProperties):
                        is_langstring = False
                        for val in resource[property]:
                            if isinstance(val, Xsd_string) and val.lang is not None:
                                is_langstring = True
                                break
                        if is_langstring:
                            resource[property] = LangString(resource[property])
        return result


    """
    PREFIX :<http://www.ontotext.com/connectors/lucene#>
PREFIX inst:<http://www.ontotext.com/connectors/lucene/instance#>
INSERT DATA {
	inst:fasnacht :createConnector '''
{
  "fields": [
    {
      "fieldName": "content",
      "propertyChain": [
        "http://fasnacht.digital/ns/storyContent"
      ],
      "indexed": true,
      "stored": false,
      "analyzed": true,
      "multivalued": true,
      "ignoreInvalidValues": false,
      "facet": false
    }
  ],
  "languages": [],
  "types": [
    "http://fasnacht.digital/ns/Story"
  ],
  "readonly": false,
  "detectFields": false,
  "importGraph": false,
  "skipInitialIndexing": false,
  "boostProperties": [],
  "stripMarkup": false
}
''' .
}
    """



    @staticmethod
    def get_media_object_by_id(con: IConnection, mediaObjectId: Xsd_string | str) -> dict[str, Xsd]:
        """
        Retrieves a media object by its ID from the system. This method queries a SPARQL endpoint
        to fetch details about the media object and constructs a resulting dictionary with the
        media object attributes and its associated metadata. Additionally, a signed JWT token
        is included in the result for security purposes.

        :param con: A connection interface that provides access to the SPARQL endpoint and user context.
        :type con: IConnection
        :param mediaObjectId: The ID of the media object to be fetched, represented as an XSD string or a Python string.
        :type mediaObjectId: Xsd_string | str
        :return: A dictionary containing key-value pairs of media object attributes and metadata,
            with an additional JWT token for security. Returns None if the media object is not found.
        :rtype: dict[str, Xsd] | None
        :raises OldapErrorNotFound: Raised when the media object with the specified ID is not found.
        """
        if not isinstance(mediaObjectId, Xsd_string):
            mediaObjectId = Xsd_string(mediaObjectId, validate=True)
        blank = ''
        context = Context(name=con.context_name)
        sparql = context.sparql_context
        sparql += textwrap.dedent(f"""
        SELECT DISTINCT ?subject ?graph ?path ?prop ?val ?maxPerm
        WHERE {{
            VALUES ?inputImageId {{ {mediaObjectId.toRdf} }}

            {{
                SELECT ?subject ?graph (MAX(xsd:integer(?pv)) AS ?maxPerm)
                WHERE {{
                    ?subject rdf:type shared:MediaObject .

                    GRAPH oldap:admin {{
                        {con.userIri.toRdf} oldap:hasRole ?role .
                    }}

                    GRAPH ?graph {{
                        ?subject oldap:attachedToRole ?role .
                        << ?subject oldap:attachedToRole ?role >> oldap:hasDataPermission ?dataperm .
                        ?subject shared:assetId ?inputImageId .
                    }}

                    GRAPH oldap:admin {{
                        ?dataperm oldap:permissionValue ?pv .
                    }}
                }}
                GROUP BY ?subject ?graph
            }}

            GRAPH ?graph {{
                ?subject shared:assetId ?inputImageId .
                OPTIONAL {{ ?subject shared:path ?path . }}
                ?subject ?prop ?val .
            }}
        }}
        """)
        try:
            jsonres = con.query(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve media object with ID "{mediaObjectId}"', exc_info=True)
            raise

        #
        # In order for the QueryProcessor to work, we need to add possible list references to the context.
        # This is done by reading the OldapList (which does add the list to the context)
        #
        if len(jsonres['results']['bindings']) > 0:
            _graph = jsonres['results']['bindings'][0]['graph']['value']  # get the data graph (-> project) where the media object is stored
            _graph = re.sub(r'([/#])data$', r'\1', _graph)  # extract the project namespace
            projs = Project.search(con=con, namespace=NamespaceIRI(_graph))  # search the project
            if len(projs) != 1:
                raise OldapErrorNotFound(f'Project associated with media object "{mediaObjectId}" not found')
            ols = OldapList.search(con=con, project=projs[0].projectShortName)  # Get all the lists in the project
            for ol in ols:
                oldaplist = OldapList.read(con=con, project=projs[0].projectShortName, oldapListId=ol.fragment)

        res = QueryProcessor(context, jsonres)
        if len(res) == 0:
            raise OldapErrorNotFound(f'Media object with id {mediaObjectId} not found.')
        result: dict[str, Xsd] = {
            'iri': res[0].get('subject'),
            'graph': res[0].get('graph'),
            'permval': res[0].get('maxPerm'),
        }
        for r in res:
            if str(r['prop']) == 'rdf:type':
                continue
            if str(r['prop']) in {'oldap:createdBy', 'oldap:creationDate', 'oldap:lastModifiedBy', 'oldap:lastModificationDate',
                                  'dcterms:type', 'shared:assetId', 'shared:originalName', 'shared:originalMimeType',
                                  'shared:serverUrl', 'shared:path', 'shared:protocol', 'shared:derivativeName'}:
                result[str(r['prop'])] = r['val']
            else:
                if result.get(str(r['prop'])) is None:
                    result[str(r['prop'])] = []
                result[str(r['prop'])].append(r['val'])

        expiration = datetime.now().astimezone() + timedelta(minutes=2)
        payload = {
            'userIri': str(con.userIri),
            'userid': str(con.userid),
            'id': str(mediaObjectId),
            'path': str(result.get('shared:path')),
            'assetId': str(result.get('shared:assetId')),
            'derivativeName': str(result.get('shared:derivativeName')),
            'permval': int(result.get('permval')),
            "exp": expiration.timestamp(),
            "iat": int(datetime.now().astimezone().timestamp()),
            "iss": "http://oldap.org"
        }
        token = jwt.encode(
            payload=payload,
            key=con.jwtkey,
            algorithm="HS256")
        result['token'] = token

        return result

    @staticmethod
    def get_media_object_by_iri(con: IConnection, mediaObjectIri: Iri | str) -> dict[str, Xsd] | None:
        if not isinstance(mediaObjectIri, Iri):
            mediaObjectIri = Iri(mediaObjectIri, validate=True)
        blank = ''
        context = Context(name=con.context_name)
        sparql = context.sparql_context
        sparql += textwrap.dedent(f"""
        SELECT ?graph ?prop ?val ?maxPerm
        WHERE {{
            BIND({mediaObjectIri.toRdf} AS ?obj)
            BIND({con.userIri.toRdf} AS ?user)

            {{
                SELECT ?graph (MAX(xsd:integer(?pv)) AS ?maxPerm)
                WHERE {{
                    ?obj rdf:type shared:MediaObject .

                    GRAPH oldap:admin {{
                        ?user oldap:hasRole ?role .
                    }}

                    GRAPH ?graph {{
                        ?obj oldap:attachedToRole ?role .
                        <<?obj oldap:attachedToRole ?role>> oldap:hasDataPermission ?dataperm .
                    }}

                    GRAPH oldap:admin {{
                        ?dataperm oldap:permissionValue ?pv .
                    }}
                }}
                GROUP BY ?graph
            }}

            GRAPH ?graph {{
                ?obj ?prop ?val .
            }}
        }}
        """)
        try:
            jsonres = con.query(sparql)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve media object with IRI "{mediaObjectIri}"', exc_info=True)
            raise

        #
        # In order for the QueryProcessor to work, we need to add possible list references to the context.
        # This is done by reading the OldapList (which does add the list to the context)
        #
        if len(jsonres['results']['bindings']) > 0:
            _graph = jsonres['results']['bindings'][0]['graph']['value']  # get the data graph (-> project) where the media object is stored
            _graph = re.sub(r'([/#])data$', r'\1', _graph)  # extract the project namespace
            projs = Project.search(con=con, namespace=NamespaceIRI(_graph))  # search the project
            if len(projs) != 1:
                raise OldapErrorNotFound(f'Project associated with media object "{mediaObjectIri}" not found')
            ols = OldapList.search(con=con, project=projs[0].projectShortName)  # Get all the lists in the project
            for ol in ols:
                oldaplist = OldapList.read(con=con, project=projs[0].projectShortName, oldapListId=ol.fragment)

        res = QueryProcessor(context, jsonres)
        if len(res) == 0:
            raise OldapErrorNotFound(f'Media object with iri {mediaObjectIri} not found.')
        result: dict[str, Xsd] = {
            'iri': mediaObjectIri,
            'graph': res[0].get('graph'),
            'permval': res[0].get('maxPerm')
        }
        for r in res:
            if str(r['prop']) == 'rdf:type':
                continue
            if str(r['prop']) in {'oldap:createdBy', 'oldap:creationDate', 'oldap:lastModifiedBy', 'oldap:lastModificationDate',
                                  'dcterms:type', 'shared:assetId', 'shared:originalName', 'shared:originalMimeType',
                                  'shared:serverUrl', 'shared:path', 'shared:protocol', 'shared:derivativeName'}:
                result[str(r['prop'])] = r['val']
            else:
                if result.get(str(r['prop'])) is None:
                    result[str(r['prop'])] = []
                result[str(r['prop'])].append(r['val'])

        expiration = datetime.now().astimezone() + timedelta(minutes=2)
        payload = {
            'userIri': str(con.userIri),
            'userid': str(con.userid),
            'projectShortName': res[0].get('graph').prefix if res[0].get('graph') else None,
            'id': str(result.get('shared:assetId')),
            'path': str(result['shared:path']),
            'assetId': str(result.get('shared:assetId')),
            'derivativeName': str(result.get('shared:derivativeName')),
            'permval': int(result['permval']),
            "exp": expiration.timestamp(),
            "iat": int(datetime.now().astimezone().timestamp()),
            "iss": "http://oldap.org"
        }
        token = jwt.encode(
            payload=payload,
            key=con.jwtkey,
            algorithm="HS256")
        result['token'] = token

        return result


    def toJsonObject(self) -> dict[str, list[str] | str]:
        result = {'iri': str(self._iri)}
        for propiri, values in self._values.items():
            if str(propiri) in {'oldap:createdBy', 'oldap:creationDate', 'oldap:lastModificationDate', 'oldap:lastModifiedBy'}:
                iterator = iter(values)
                result[str(propiri)] = str(next(iterator))
                continue

            result[str(propiri)] = [str(v) for v in values]
        return result


class ResourceInstanceFactory:
    """
    Represents a factory for creating instances of resources in a specific project.

    The `ResourceInstanceFactory` class is used for creating resource instances
    associated with a data model and project. It provides an interface to dynamically
    generate classes for resource objects with properties and inheritance derived
    from the project's data model.

    :ivar _con: The connection interface used to interact with the backend.
    :type _con: IConnection
    :ivar _project: Represents the project associated with the factory.
    :type _project: Project
    :ivar _datamodel: Represents the data model associated with the project.
    :type _datamodel: DataModel
    """
    _con: IConnection
    _project: Project
    _sharedProject: Project
    _datamodel: DataModel
    _sharedModel: DataModel
    _user_default_roles: Dict[Xsd_QName, DataPermission] = {}

    def __init__(self,
                 con: IConnection,
                 project: Project | Iri | Xsd_NCName | str):
        self._con = con
        if isinstance(project, Project):
            self._project = project
        else:
            self._project = Project.read(self._con, project)
        self._sharedProject = Project.read(self._con, "oldap:SharedProject")
        if self._con._userdata.hasRole:
            self._user_default_roles = {r: DataPermission.from_qname(p) for r, p in self._con._userdata.hasRole.items()}

        self._datamodel = DataModel.read(con=self._con, project=self._project)
        self._sharedModel = DataModel.read(con=self._con, project=self._sharedProject)

    def createObjectInstance(self, name: Xsd_NCName | Xsd_QName | str) -> Type:  ## ToDo: Get name automatically from IRI
        if isinstance(name, Xsd_QName):
            classiri = name
        else:
            try:
                classiri = Xsd_QName(name, validate=True)
            except (ValueError, OldapErrorValue):
                if not isinstance(name, Xsd_NCName):
                    name = Xsd_NCName(name, validate=True)
                classiri = Xsd_QName(self._project.projectShortName, name)
        resclass = self._datamodel.get(classiri)
        if not resclass:
            resclass = self._sharedModel.get(classiri)
        if resclass is None:
            raise OldapErrorNotFound(f'Given Resource Class "{classiri}" not found.')
        return type(str(name), (ResourceInstance,), {
            '_con': self._con,
            'project': self._project,
            'name': resclass.owl_class_iri,
            'factory': self,
            'properties': resclass.properties,
            'superclass': resclass.superclass,
            'user_default_roles': self._user_default_roles,
        })


    def read(self, iri: Iri | str) -> ResourceInstance:
        if not isinstance(iri, Iri):
            iri = Iri(iri, validate=True)
        graph = self._project.projectShortName
        try:
            construct_data = _read_resource_construct(self._con, graph, iri, self._con.userIri, include_creator=False)
        except OldapError:
            logger.error(f'SPARQL: Failed to retrieve resource "{iri}"', exc_info=True)
            raise
        objtype, kwargs = _resource_from_construct(iri, construct_data)
        if objtype is None:
            raise OldapErrorNotFound(f'Resource with iri <{iri}> not found.')
        Instance = self.createObjectInstance(objtype)
        _, kwargs = _resource_from_construct(iri, construct_data, Instance.properties)
        kwargs['attachedToRole'] = _read_attached_roles(self._con, graph, iri)
        return Instance(iri=iri, **kwargs)
