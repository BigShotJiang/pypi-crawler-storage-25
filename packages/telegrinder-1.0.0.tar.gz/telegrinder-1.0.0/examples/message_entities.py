from telegrinder import API, Message, Telegrinder, Token, configure_dotenv, setup_logger
from telegrinder.rules import HasEntities, IsChat, IsPrivate, MessageEntities
from telegrinder.tools.formatting import HTML, bold, mention
from telegrinder.types.enums import MessageEntityType
from telegrinder.types.objects import MessageEntity

configure_dotenv()
setup_logger()


api = API(Token.from_env())
bot = Telegrinder(api)


@bot.on.message(IsChat(), MessageEntities(MessageEntityType.MENTION))
async def handler_mention_me(message: Message, message_entities: list[MessageEntity]):
    my_username = (await api.get_me()).map(lambda me: me.username).unwrap()
    if (
        not my_username
        or my_username != message.text.unwrap()[message_entities[0].offset + 1 : message_entities[0].length]
    ):
        return

    await message.delete()
    await message.answer(
        HTML
        << bold(mention(message.from_user.first_name, user_id=message.from_user.id))
        << " don't mention me please!",
        parse_mode=HTML.PARSE_MODE,
    )


@bot.on.message(IsPrivate(), HasEntities())
async def handler_entities(message: Message):
    await message.answer(
        "Nice {}: {}!".format(
            "entities" if len(message.entities.unwrap()) > 1 else "entity",
            ", ".join(map(lambda e: e.type, message.entities.unwrap())),
        )
    )


bot.run_forever()
