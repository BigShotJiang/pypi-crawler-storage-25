from kungfu.library.monad.result import Error, Ok

from telegrinder import API, ChatJoinRequest, Telegrinder, Token, configure_dotenv
from telegrinder.modules import configure_dotenv, logger, setup_logger
from telegrinder.rules import HasInviteLink, IsUser

configure_dotenv()
setup_logger()

bot = Telegrinder(API(Token.from_env()))


@bot.on.chat_join_request(HasInviteLink(), IsUser())
async def approve_user(request: ChatJoinRequest) -> None:
    match await request.approve():
        case Ok(ok) if ok:
            await request.api.send_message(
                chat_id=request.chat.id,
                text=f"Welcome to the chat {request.chat.title.unwrap()!r}, {request.from_user.full_name}!",
            )
        case Error(error):
            logger.error(
                "Something went wrong, error: {!r}, user: {}",
                error.error,
                request.from_user.full_name,
            )


bot.run_forever()
