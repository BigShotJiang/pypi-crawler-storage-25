from __future__ import annotations

import re
import typing

from nodnod.scope import Scope
from vbml.patcher.abc import ABCPatcher
from vbml.patcher.patcher import Patcher

from telegrinder.tools.global_context.global_context import GlobalContext, ctx_var, runtime_init
from telegrinder.tools.loop_wrapper import LoopWrapper

if typing.TYPE_CHECKING:
    from telegrinder.bot import MiddlewareBox
    from telegrinder.tools import WaiterMachine
    from telegrinder.tools.lifespan import Lifespan


@runtime_init
class TelegrinderContext(GlobalContext):
    """The type-hinted telegrinder context.

    Example:
    ```
    from telegrinder.tools.global_context import GlobalContext, TelegrinderContext

    telegrinder_ctx = TelegrinderContext(...)  # with type-hints
    assert telegrinder_ctx == GlobalContext("telegrinder")  # ok
    ```

    """

    __ctx_name__ = "telegrinder"

    if typing.TYPE_CHECKING:
        middleware_box: typing.ClassVar[MiddlewareBox]
        waiter_machine: typing.ClassVar[WaiterMachine]

    node_global_scope: typing.Final[Scope] = ctx_var(
        default_factory=lambda: Scope(detail="global"),
        init=False,
        const=True,
    )
    vbml_pattern_flags: re.RegexFlag | None = ctx_var(default=None, init=False)
    vbml_patcher: ABCPatcher = ctx_var(default_factory=Patcher, init=False)
    loop_wrapper: typing.Final[LoopWrapper] = ctx_var(default_factory=LoopWrapper, init=False, const=True)

    @property
    def lifespan(self) -> Lifespan:
        return self.loop_wrapper.lifespan

    async def close_global_scope(self) -> None:
        await self.node_global_scope.close()


__all__ = ("TelegrinderContext",)
