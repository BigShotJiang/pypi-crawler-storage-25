import asyncio
import contextlib
import datetime
import enum
import signal
import threading
import types
import typing
from contextlib import suppress
from functools import partial

from telegrinder.modules import logger
from telegrinder.tools.aio import TaskGroup, cancel_future, loop_is_running, run_task
from telegrinder.tools.final import Final
from telegrinder.tools.fullname import fullname
from telegrinder.tools.lifespan import (
    CoroutineFunc,
    CoroutineTask,
    DelayedTask,
    Lifespan,
    Task,
    to_coroutine_task,
)
from telegrinder.tools.singleton.singleton import Singleton

if typing.TYPE_CHECKING:
    from contextvars import Context

    type Tasks = set[asyncio.Task[typing.Any]]
    type DelayedFunctionDecorator[**P, R] = typing.Callable[[typing.Callable[P, R]], DelayedFunction[P, R]]

    class DelayedFunction[**P, R](typing.Protocol):
        __name__: str
        __delayed_task__: DelayedTask[typing.Callable[P, CoroutineTask[R]]]

        def __call__(self, *args: P.args, **kwargs: P.kwargs) -> CoroutineTask[R]: ...

        def cancel(self) -> bool:
            """Cancel delayed task."""
            ...


SIGNALS: typing.Final = (signal.SIGTERM,) + ((signal.SIGBREAK,) if hasattr(signal, "SIGBREAK") else ())


class Timer(datetime.timedelta):
    repeat = False

    def __call__[**P, R](self, function: CoroutineFunc[P, R], /) -> DelayedFunction[P, R]:
        loop_wrapper = LoopWrapper()
        loop_wrapper.add_task(DelayedTask(function, seconds=self.total_seconds(), repeat=self.repeat))
        return function  # type: ignore


class Interval(Timer):
    repeat = True


@enum.unique
class LoopWrapperState(enum.Enum):
    NOT_RUNNING = enum.auto()
    RUNNING = enum.auto()
    RUNNING_MANUALLY = enum.auto()
    SHUTDOWN = enum.auto()


RUNNING_STATES: typing.Final = frozenset({LoopWrapperState.RUNNING, LoopWrapperState.RUNNING_MANUALLY})


@typing.final
class LoopWrapper(Singleton, Final):
    """Loop wrapper is a singleton wrapper around the event loop that provides a way
    to run tasks in the event loop, manage the lifespan of the application, and manage
    the tasks in the event loop."""

    _loop: asyncio.AbstractEventLoop
    _lifespan: Lifespan
    _future_tasks: list[CoroutineTask[typing.Any]]
    _state: LoopWrapperState
    _all_tasks: set[asyncio.Task[typing.Any]]
    _event_shutdown: asyncio.Event
    _run_lw_task: asyncio.Handle
    _is_attached_to_running_loop: bool

    timer = Timer
    interval = Interval

    __slots__ = (
        "_lifespan",
        "_future_tasks",
        "_state",
        "_all_tasks",
        "_loop",
        "_event_shutdown",
        "_run_lw_task",
        "_is_attached_to_running_loop",
    )

    def __init__(self) -> None:
        try:
            self._loop = asyncio.get_event_loop()
        except RuntimeError:
            self._loop = asyncio.new_event_loop()

        self._run_lw_task = self._run_lw_later()
        self._lifespan = Lifespan()
        self._event_shutdown = asyncio.Event()
        self._state = LoopWrapperState.NOT_RUNNING
        self._future_tasks = [self._wait_for_shutdown()]
        self._all_tasks = set()
        self._is_attached_to_running_loop = False

        self._register_signal_handlers()

    def __repr__(self) -> str:
        return "<{}: loop={!r}, lifespan={!r}>".format(
            fullname(self) + (" (running)" if self.running else ""),
            self._loop,
            self._lifespan,
        )

    def __call__(self) -> asyncio.AbstractEventLoop:
        return self._loop

    @property
    def lifespan(self) -> Lifespan:
        return self._lifespan

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        return self._loop

    @property
    def time(self) -> float:
        return self._loop.time()

    @property
    def running(self) -> bool:
        return self._state in RUNNING_STATES

    @property
    def shutting_down(self) -> bool:
        return self._state is LoopWrapperState.SHUTDOWN

    async def _run_async_event_loop(self) -> None:
        if not self.running:
            self._state = LoopWrapperState.RUNNING
            async with self._async_capture_loop():
                await self._run()

    async def _run(self) -> None:
        logger.info("Running loop wrapper")

        while self._future_tasks:
            self._create_task(self._future_tasks.pop(0))

        while self.running and (tasks := self._get_all_tasks()):
            with suppress(asyncio.CancelledError):
                tasks_results, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)

                for task_result in tasks_results:
                    try:
                        task_result.result()
                    except Exception:
                        logger.exception("Traceback message below:")

    async def _cancel_tasks(self) -> None:
        tasks = self._get_all_tasks()

        if not tasks:
            return

        logger.debug("Cancelling tasks")

        with suppress(asyncio.CancelledError, asyncio.InvalidStateError):
            await cancel_future(asyncio.gather(*tasks, return_exceptions=True))

    @contextlib.asynccontextmanager
    async def _async_capture_loop(self) -> typing.AsyncGenerator[typing.Any, None]:
        try:
            try:
                await self._lifespan._start()
            finally:
                yield
        finally:
            await self._shutdown()

    def _register_signal_handlers(self) -> None:
        if threading.current_thread() is not threading.main_thread():
            logger.warning("Loop wrapper cannot register signal handlers in non-main thread")
            return

        for signalnum in (signal.SIGTERM,) + ((signal.SIGBREAK,) if hasattr(signal, "SIGBREAK") else ()):
            signal.signal(
                signalnum,
                partial(self._signal_handler, h if callable(h := signal.getsignal(signalnum)) else None),
            )

    def _signal_handler(
        self,
        old_handler: typing.Callable[[int, types.FrameType | None], typing.Any] | None,
        sig: int,
        frame: types.FrameType | None,
    ) -> None:
        sig = signal.Signals(sig)

        if sig not in SIGNALS:
            return

        logger.info(
            "Caught {} (Signal {}, {}, {})",
            sig.name,
            sig.value,
            "ANSI" if sig is signal.SIGTERM else "WIN32",
            "termination program" if sig is signal.SIGTERM else "interrupt from keyboard",
        )
        self.shutdown()

        if old_handler is not None:
            old_handler(sig, frame)

    async def _shutdown(self) -> None:
        if not self.running:
            return

        self._state = LoopWrapperState.SHUTDOWN

        logger.debug("Shutting down loop wrapper")
        await self.lifespan._shutdown()
        await self._cancel_tasks()

    async def _wait_for_shutdown(self) -> None:
        await self._event_shutdown.wait()
        await self._shutdown()

    def _run_lw_later(self) -> asyncio.Handle:
        return self._loop.call_soon_threadsafe(lambda l: l.create_task(self._run_async_event_loop()), self._loop)

    def _create_task(
        self,
        coro: CoroutineTask[typing.Any],
        /,
        name: str | None = None,
        context: Context | None = None,
    ) -> asyncio.Task[typing.Any]:
        task = self._loop.create_task(coro, name=name, context=context)
        self._all_tasks.add(task)
        task.add_done_callback(self._all_tasks.discard)

        try:
            return task
        finally:
            del task

    def _get_all_tasks(self) -> Tasks:
        """Get a set of all tasks from the loop wrapper and event loop (`exclude the current task if any`)."""

        return (self._all_tasks | asyncio.all_tasks(loop=self._loop)).symmetric_difference(
            set() if (task := asyncio.current_task(self._loop)) is None else {task},
        )

    def _close_loop(self) -> None:
        if not self._loop.is_closed():
            logger.debug("Closing event loop {!r}", self._loop)
            self._loop.close()

    @contextlib.contextmanager
    def _capture_loop(self, *, close_loop: bool = True) -> typing.Generator[typing.Any, None, None]:
        try:
            try:
                self.lifespan.start(self._loop)
            finally:
                yield
        except KeyboardInterrupt:
            print(flush=True)
            logger.info("Caught SIGINT (Signal 2, ANSI, interrupt from keyboard), shutting down")
        finally:
            run_task(self._shutdown(), loop=self._loop)

            if close_loop:
                self._close_loop()

    def run(self, *, close_loop: bool = True) -> None:
        """Run the loop wrapper.

        Raises:
            RuntimeError: If the loop wrapper is already running.

        """
        if self.running:
            raise RuntimeError("Loop wrapper already running.")

        self._state = LoopWrapperState.RUNNING_MANUALLY
        with self._capture_loop(close_loop=close_loop):
            run_task(self._run(), loop=self._loop)

    def shutdown(self) -> None:
        """Shutdown the loop wrapper via setting the shutdown event.

        Using `call_soon_threadsafe` instead of directly calling `Event.set()`
        because `Event.set()` internally uses `call_soon()` which does NOT write to the event
        loop's self-pipe. When a signal handler (registered via `signal.signal()`) calls
        `Event.set()` during a selector syscall (e.g. `kqueue.control()`), PEP 475 causes
        the syscall to be automatically retried after the Python handler returns, leaving
        the event loop blocked in `select()` with unprocessed callbacks in the `_ready` queue.
        `call_soon_threadsafe` writes to the self-pipe via `_write_to_self()`, ensuring the
        selector wakes up immediately on retry.
        """

        if self.running:
            self._loop.call_soon_threadsafe(self._event_shutdown.set)

    def add_task(self, task: Task[..., typing.Any], /) -> None:
        """Add a task to the loop wrapper.

        if the loop wrapper is not running, the task is added to the future tasks list,
        otherwise the task is created in the event loop and added to the all tasks set.
        """
        coro_task = to_coroutine_task(task)

        if not self.running:
            self._future_tasks.append(coro_task)

            if self._is_attached_to_running_loop is False and loop_is_running():
                self.attach_to_running_loop()
        else:
            self._create_task(coro_task)

    def attach_to_running_loop(self) -> None:
        """Attach the loop wrapper to the running loop.

        Raises:
            RuntimeError: If the loop wrapper is already running or the event loop is not running.

        """
        if self.running:
            raise RuntimeError("Cannot attach the running loop wrapper to the running loop.")

        self._is_attached_to_running_loop = True
        self.bind_event_loop(asyncio.get_running_loop())

    def create_task_group[T](self) -> TaskGroup[typing.Any]:
        loop = asyncio.get_running_loop()
        if not self.running and self._loop is not loop:
            self.attach_to_running_loop()
        return TaskGroup(loop)

    def bind_event_loop(self, loop: asyncio.AbstractEventLoop, /) -> typing.Self:
        """Bind the event loop to the loop wrapper.

        Raises:
            RuntimeError: If the loop wrapper is already running or the event loop is not running.

        """
        if self.running:
            raise RuntimeError("Cannot bind the event loop to the running loop wrapper.")

        self._loop = loop
        self._run_lw_task.cancel()
        self._run_lw_task = self._run_lw_later()
        return self


__all__ = ("LoopWrapper",)
