import asyncio
import pathlib
import typing
from datetime import timedelta
from functools import cached_property, wraps
from http import HTTPStatus

import msgspec
from kungfu.library.misc import is_ok
from kungfu.library.monad.result import Error, Ok, Result
from msgspex import decoder

from telegrinder.api.error import APIError
from telegrinder.api.response import APIResponse
from telegrinder.api.token import Token
from telegrinder.client import ABCClient, WreqClient
from telegrinder.types.methods import APIMethods

type Json = str | int | float | bool | list[Json] | dict[str, Json] | None
type Data = dict[str, typing.Any]
type Files = dict[str, tuple[str, bytes]]
type APIRequestMethod[T: API, **P, R] = typing.Callable[
    typing.Concatenate[T, P],
    typing.Coroutine[typing.Any, typing.Any, Result[R, APIError]],
]


DEFAULT_MAX_RETRIES: typing.Final = 5
DEFAULT_TIMEOUT: typing.Final = timedelta(seconds=30)


def retryer[T: API, **P, R](func: APIRequestMethod[T, P, R], /) -> APIRequestMethod[T, P, R]:
    @wraps(func)
    async def wrapper(
        self: T,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Result[typing.Any, APIError]:
        retries_counter = 0

        while True:
            result = await func(self, *args, **kwargs)

            if is_ok(result) or not self.retryer_is_enabled or retries_counter >= self.max_retries:
                return result

            if result.error.status_code == HTTPStatus.TOO_MANY_REQUESTS:
                await asyncio.sleep(result.error.retry_after.unwrap_or(5.0))

            elif result.error.status_code == HTTPStatus.INTERNAL_SERVER_ERROR and "restart" in result.error.error:
                await asyncio.sleep(10.0)

            elif result.error.migrate_to_chat_id:
                kwargs["chat_id"] = result.error.migrate_to_chat_id.value

            else:
                return result

            retries_counter += 1

    return wrapper  # type: ignore


class API(APIMethods):
    """Bot API with available API methods and http client."""

    http: ABCClient

    API_URL = "https://api.telegram.org/"
    API_FILE_URL = "https://api.telegram.org/file/"

    def __init__(
        self,
        token: Token,
        *,
        http: ABCClient | None = None,
        retryer: bool = True,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self.token = token
        self.http = http or WreqClient()
        self._retryer_is_enabled = retryer
        self._max_retries = max_retries
        super().__init__(api=self)

    def __repr__(self) -> str:
        return "<{}: id={}, http={!r}, max_retries={}>".format(
            type(self).__name__,
            self.id,
            self.http,
            self._max_retries,
        )

    @cached_property
    def id(self) -> int:
        return self.token.bot_id

    @property
    def request_url(self) -> str:
        return self.API_URL + f"bot{self.token}/"

    @property
    def request_file_url(self) -> str:
        return self.API_FILE_URL + f"bot{self.token}/"

    @property
    def retryer_is_enabled(self) -> bool:
        return self._retryer_is_enabled

    @property
    def max_retries(self) -> int:
        return self._max_retries

    async def download_file(
        self,
        file_path: str | pathlib.Path,
        timeout: int | float | timedelta = DEFAULT_TIMEOUT,
    ) -> Result[bytes, APIError]:
        response = await self.http.request(
            url=f"{self.request_file_url}/{file_path}",
            timeout=timeout,
        )

        if response.status.is_success:
            return Ok(response.content)

        error = decoder.decode(response.content, type=APIResponse)
        return Error(APIError(code=error.error_code, error=error.description, data=error.parameters))

    @retryer
    async def request(
        self,
        method: str,
        data: Data | None = None,
        files: Files | None = None,
        **kwargs: typing.Any,
    ) -> Result[Json, APIError]:
        """Request a `JSON` response using http method `POST` and passing data & files as `multipart`."""
        response = await self.http.request_json(
            url=self.request_url + method,
            method="POST",
            data=self.http.get_form(data=data, files=files),
            **kwargs,
        )

        if response.get("ok", False) is True:
            return Ok(response["result"])

        return Error(
            APIError(
                code=response.get("error_code", 400),
                error=response.get("description", "Something went wrong"),
                data=response.get("parameters", {}),
            ),
        )

    @retryer
    async def request_raw(
        self,
        method: str,
        data: Data | None = None,
        files: Files | None = None,
        **kwargs: typing.Any,
    ) -> Result[msgspec.Raw, APIError]:
        """Request a `raw` response using http method `POST` and passing data & files as `multipart`."""
        response_bytes = await self.http.request_bytes(
            url=self.request_url + method,
            method="POST",
            data=self.http.get_form(data=data, files=files),
            **kwargs,
        )
        return decoder.decode(response_bytes, type=APIResponse).to_result()


__all__ = ("API",)
