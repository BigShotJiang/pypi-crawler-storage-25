"""
Chloros Local SDK
=================

Main SDK module for local Chloros image processing.
Provides Python interface to the Chloros backend API running on localhost.

Requirements:
    - Chloros Desktop installed
    - Chloros backend running (auto-starts if enabled)
    - Active Chloros+ license

Copyright (c) 2026 MAPIR Inc. All rights reserved.
"""

import os
import sys
import time
import json
import logging
import subprocess
import platform
import warnings
from pathlib import Path
from typing import Optional, List, Dict, Union, Callable

import requests

logger = logging.getLogger(__name__)

# Survey3 / Chloros UI presents these export options. We validate against the
# set so customers don't silently fall back to default on a typo. Keep this in
# sync with the frontend export selector and backend Save_Format options.
SUPPORTED_EXPORT_FORMATS = (
    "TIFF (16-bit)",
    "TIFF (32-bit, Percent)",
    "PNG (8-bit)",
    "JPG (8-bit)",
)

# File extensions the backend's import-from-folder accepts for Survey3.
# Lowercased; comparison is case-insensitive.
SUPPORTED_IMAGE_EXTS = (".raw", ".jpg", ".jpeg", ".tif", ".tiff", ".dng")

# Import platform utilities for cross-platform support
try:
    from platform_utils import get_backend_search_paths, IS_WINDOWS, IS_LINUX
except ImportError:
    # Fallback when platform_utils not available
    IS_WINDOWS = sys.platform == 'win32'
    IS_LINUX = sys.platform.startswith('linux')
    def get_backend_search_paths():
        if IS_WINDOWS:
            return [
                r"C:\Program Files\MAPIR\Chloros\resources\backend\chloros-backend.exe",
                r"C:\Program Files\Chloros\resources\backend\chloros-backend.exe",
            ]
        else:
            return [
                '/usr/lib/chloros/chloros-backend',  # .deb package location
                '/opt/mapir/chloros/backend/chloros-backend',
                str(Path.home() / '.local' / 'bin' / 'chloros-backend'),
                './backend_server.py',
            ]

from .exceptions import (
    ChlorosBackendError,
    ChlorosConnectionError,
    ChlorosProcessingError,
    ChlorosConfigurationError,
    ChlorosLicenseError
)


class ChlorosLocal:
    """
    Chloros Local SDK - Python interface for Chloros image processing
    
    This class provides programmatic access to the Chloros backend API
    running on localhost. It enables automation, custom workflows, and
    integration with existing Python pipelines.
    
    Requirements:
        - Chloros Desktop installed locally
        - Active Chloros+ license (validated via GUI login)
        - Backend running or auto-start enabled
    
    Basic Usage:
        >>> from chloros_sdk import ChlorosLocal
        >>> 
        >>> # Initialize SDK (auto-starts backend)
        >>> chloros = ChlorosLocal()
        >>> 
        >>> # Create project and import images
        >>> chloros.create_project("MyProject", camera="Survey3N_RGN")
        >>> chloros.import_images("C:/DroneImages/Flight001")
        >>> 
        >>> # Configure processing settings
        >>> chloros.configure(
        ...     vignette_correction=True,
        ...     reflectance_calibration=True,
        ...     indices=["NDVI", "NDRE", "GNDVI"]
        ... )
        >>> 
        >>> # Process images
        >>> results = chloros.process(mode="parallel", wait=True)
    
    Advanced Usage:
        >>> # Custom progress monitoring
        >>> def progress_callback(progress, message):
        ...     print(f"Progress: {progress}% - {message}")
        >>> 
        >>> chloros.process(
        ...     mode="parallel",
        ...     progress_callback=progress_callback,
        ...     wait=True
        ... )
    
    Attributes:
        api_url (str): URL of local Chloros backend (default: http://localhost:5000)
        timeout (int): Request timeout in seconds
        backend_process: Backend process object if auto-started
    """
    
    # Default backend installation paths (cross-platform)
    # Uses platform_utils.get_backend_search_paths() for platform-appropriate paths
    @property
    def DEFAULT_BACKEND_PATHS(self):
        """Get platform-appropriate backend search paths."""
        return get_backend_search_paths()
    
    def __init__(self,
                 api_url: str = "http://localhost:5000",
                 auto_start_backend: bool = True,
                 backend_exe: Optional[str] = None,
                 timeout: int = 30,
                 backend_startup_timeout: int = 60,
                 processing_timeout: int = 14400,
                 processing_stuck_timeout: int = 1800):
        """
        Initialize Chloros Local SDK

        Args:
            api_url: URL of local Chloros backend (default: http://localhost:5000)
            auto_start_backend: Automatically start backend if not running (default: True)
            backend_exe: Path to backend executable (auto-detected if None)
            timeout: Request timeout in seconds (default: 30)
            backend_startup_timeout: Timeout for backend startup in seconds (default: 60)
            processing_timeout: Hard cap for an end-to-end process() call in seconds
                                (default: 14400 = 4h). Slow targets like Jetson can
                                spend 75+ minutes on a single batch.
            processing_stuck_timeout: How long without any progress change before the
                                      SDK declares the run stuck (default: 1800 = 30
                                      min). Resets every time percent or message
                                      changes, so long-but-progressing runs are fine.
        
        Raises:
            ChlorosConnectionError: If backend not running and auto_start is False
            ChlorosBackendError: If backend fails to start
            ChlorosLicenseError: If no valid Chloros+ license found
        
        Example:
            >>> # Auto-start backend (default)
            >>> chloros = ChlorosLocal()
            >>> 
            >>> # Connect to existing backend
            >>> chloros = ChlorosLocal(auto_start_backend=False)
            >>> 
            >>> # Use custom backend path
            >>> chloros = ChlorosLocal(backend_exe="C:/Custom/chloros-backend.exe")
        """
        self.api_url = api_url
        self.timeout = timeout
        self.backend_startup_timeout = backend_startup_timeout
        self.processing_timeout = processing_timeout
        self.processing_stuck_timeout = processing_stuck_timeout
        self.backend_process: Optional[subprocess.Popen] = None
        self.backend_exe = backend_exe or self._find_backend_exe()
        
        # Check if backend is running
        if not self._is_backend_running():
            if auto_start_backend:
                self._start_backend()
            else:
                raise ChlorosConnectionError(
                    "Chloros backend not running. "
                    "Start Chloros Desktop or set auto_start_backend=True"
                )
        
        # Verify license (optional check - backend will enforce)
        self._check_license_status()
    
    def _find_backend_exe(self) -> str:
        """
        Auto-detect Chloros backend executable
        
        Returns:
            str: Path to backend executable
        
        Raises:
            ChlorosBackendError: If backend not found
        """
        for path in self.DEFAULT_BACKEND_PATHS:
            if os.path.exists(path):
                return path
        
        raise ChlorosBackendError(
            "Chloros backend not found. Please install Chloros Desktop first.\n"
            "Download from: https://www.mapir.camera/downloads"
        )
    
    def _is_backend_running(self) -> bool:
        """
        Check if Chloros backend is accessible
        
        Returns:
            bool: True if backend is running and responding
        """
        try:
            response = requests.get(
                f"{self.api_url}/",
                timeout=2
            )
            return response.ok
        except (requests.exceptions.RequestException, Exception):
            return False
    
    def _start_backend(self):
        """
        Auto-start Chloros backend
        
        Raises:
            ChlorosBackendError: If backend fails to start
        """
        if not self.backend_exe or not os.path.exists(self.backend_exe):
            raise ChlorosBackendError(
                f"Backend executable not found: {self.backend_exe}"
            )
        
        try:
            # Start backend process (hidden window on Windows)
            if platform.system() == 'Windows':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0  # SW_HIDE
                
                self.backend_process = subprocess.Popen(
                    [self.backend_exe],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    startupinfo=startupinfo
                )
            else:
                # On Linux, .py files need to be run with python interpreter
                if self.backend_exe.endswith('.py'):
                    cmd = [sys.executable, self.backend_exe]
                else:
                    cmd = [self.backend_exe]
                # Pass environment with TMPDIR for Nuitka onefile extraction.
                # The compiled backend can extract ~600MB of bundled libs to
                # TMPDIR; on small embedded disks (Jetson default 14GB eMMC),
                # /tmp will fill. Prefer an SSD mount when present, otherwise
                # fall back to a per-user cache dir under $HOME.
                env = os.environ.copy()
                if os.path.isdir('/mnt/ssd/tmp'):
                    env['TMPDIR'] = '/mnt/ssd/tmp'
                elif 'TMPDIR' not in env:
                    user_tmp = Path.home() / '.cache' / 'chloros' / 'tmp'
                    try:
                        user_tmp.mkdir(parents=True, exist_ok=True)
                        env['TMPDIR'] = str(user_tmp)
                    except OSError:
                        pass  # leave TMPDIR unset; fall back to system /tmp
                # Pipe to DEVNULL on Linux to avoid deadlocking the backend
                # if its stdout/stderr buffer fills before we drain it.
                # Customers can re-run with `chloros-backend` directly to see
                # logs, or wrap the SDK call themselves.
                self.backend_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    env=env
                )
            
            # Wait for backend to be ready
            start_time = time.time()
            while time.time() - start_time < self.backend_startup_timeout:
                if self._is_backend_running():
                    return
                time.sleep(1)
            
            # Timeout - backend failed to start
            if self.backend_process:
                self.backend_process.terminate()
            
            raise ChlorosBackendError(
                f"Backend started but not responding after {self.backend_startup_timeout} seconds"
            )
            
        except Exception as e:
            raise ChlorosBackendError(f"Failed to start backend: {str(e)}")
    
    def _check_license_status(self):
        """
        Check if valid Chloros+ license is cached
        
        Raises:
            ChlorosLicenseError: If no valid license found (warning only)
        """
        try:
            # This is a soft check - backend will enforce license requirements
            # Just warn user if we can't detect a license
            response = requests.get(
                f"{self.api_url}/api/get-config",
                timeout=self.timeout
            )
            
            if not response.ok:
                # Warning only - don't fail initialization
                import warnings
                warnings.warn(
                    "Could not verify Chloros+ license. "
                    "Ensure you've logged in via Chloros Desktop GUI.",
                    UserWarning
                )
        except Exception:
            # Silently continue - license check is optional
            pass
    
    def _request(self,
                 method: str,
                 endpoint: str,
                 json_data: Optional[Dict] = None,
                 timeout: Optional[int] = None) -> requests.Response:
        """
        Make HTTP request to Chloros API
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., '/api/new-project')
            json_data: JSON data for request body
            timeout: Request timeout (uses self.timeout if None)
        
        Returns:
            requests.Response: HTTP response object
        
        Raises:
            ChlorosConnectionError: If connection fails
        """
        timeout = timeout or self.timeout
        url = f"{self.api_url}{endpoint}"
        
        try:
            response = requests.request(
                method=method,
                url=url,
                json=json_data,
                timeout=timeout
            )
            return response
        except requests.exceptions.Timeout:
            raise ChlorosConnectionError(
                f"Request timeout after {timeout} seconds"
            )
        except requests.exceptions.ConnectionError:
            raise ChlorosConnectionError(
                "Could not connect to Chloros backend. "
                "Ensure Chloros Desktop is running."
            )
        except Exception as e:
            raise ChlorosConnectionError(f"Connection error: {str(e)}")
    
    # =========================================================================
    # PUBLIC API METHODS
    # =========================================================================
    
    def create_project(self,
                      project_name: str,
                      camera: Optional[str] = None) -> Dict:
        """
        Create a new Chloros project
        
        Args:
            project_name: Name for the project
            camera: Optional camera template (e.g., "Survey3N_RGN", "Survey3W_OCN")
        
        Returns:
            dict: Project creation response
        
        Raises:
            ChlorosProcessingError: If project creation fails
        
        Example:
            >>> chloros.create_project("DroneField_A", camera="Survey3N_RGN")
        """
        try:
            response = self._request(
                'POST',
                '/api/new-project',
                json_data={
                    'projectName': project_name,
                    'template': camera
                }
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise ChlorosProcessingError(
                f"Failed to create project: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
    
    def import_images(self,
                     folder_path: Union[str, Path],
                     recursive: bool = False) -> Dict:
        """
        Import images from a folder
        
        Args:
            folder_path: Path to folder containing RAW/TIF/JPG images
            recursive: Search subfolders for images (default: False)
        
        Returns:
            dict: Import results with file count and file list
        
        Raises:
            ChlorosProcessingError: If import fails
            FileNotFoundError: If folder doesn't exist
        
        Example:
            >>> chloros.import_images("C:/DroneImages/Flight001")
            >>> chloros.import_images("C:/DroneImages", recursive=True)
        """
        folder_path = Path(folder_path)

        if not folder_path.exists():
            raise FileNotFoundError(f"Folder not found: {folder_path}")

        if not folder_path.is_dir():
            raise ValueError(f"Not a directory: {folder_path}")

        # Pre-flight: warn (don't fail) if the folder has no Survey3-style
        # images. Backend will return 0 imports in that case, which would
        # otherwise look like a successful run with no output.
        scan_iter = folder_path.rglob('*') if recursive else folder_path.iterdir()
        has_supported = any(
            p.is_file() and p.suffix.lower() in SUPPORTED_IMAGE_EXTS
            for p in scan_iter
        )
        if not has_supported:
            warnings.warn(
                f"No supported image files (.raw/.jpg/.tif/.dng) found in "
                f"{folder_path}{' (recursive)' if recursive else ''}. "
                f"import_images will return 0 files.",
                UserWarning,
                stacklevel=2,
            )

        try:
            response = self._request(
                'POST',
                '/api/import-from-folder',
                json_data={
                    'folder_path': str(folder_path.absolute()),
                    'recursive': recursive
                },
                timeout=self.timeout * 3  # Import can take longer
            )
            response.raise_for_status()
            result = response.json()
            # Add 'count' from the files list for convenience
            if 'files' in result and 'count' not in result:
                result['count'] = len(result['files'])
            return result
        except requests.exceptions.HTTPError as e:
            raise ChlorosProcessingError(
                f"Failed to import images: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
    
    def _resolve_index_configs(self, requested_names: List[str]) -> List[Dict]:
        """
        Pull the full index registry from the backend and return the dict-form
        configs with `enabled` set on the requested names. Names match
        case-insensitively. Returns [] if the registry can't be fetched —
        callers should treat that as a recoverable miss and warn the user
        before falling back to raw names.
        """
        try:
            response = self._request('GET', '/api/get-config', timeout=5)
            if not response.ok:
                logger.warning(
                    "Index registry fetch returned %s; sending raw index names. "
                    "Index export may fail for this run.",
                    response.status_code,
                )
                return []
            payload = response.json()
            # Endpoint returns {"success": true, "config": {...}}; tolerate the
            # un-wrapped form too in case older backends return it directly.
            cfg = payload.get('config', payload) if isinstance(payload, dict) else {}
            registry = (
                cfg.get('Project Settings', {})
                   .get('Index', {})
                   .get('Add index', [])
            )
        except Exception as e:
            logger.warning(
                "Index registry fetch failed (%s); sending raw index names. "
                "Index export may fail for this run.", e,
            )
            return []

        wanted = {n.upper() for n in requested_names}
        available = {
            entry.get('name', '').upper()
            for entry in registry if isinstance(entry, dict)
        }
        unknown = wanted - available
        if unknown and available:
            # Registry was fetched (so we know what's valid) but some names
            # don't match. Warn so customers don't silently get fewer outputs.
            warnings.warn(
                f"Requested index name(s) not found in backend registry: "
                f"{sorted(unknown)}. Available: {sorted(available)}.",
                UserWarning,
                stacklevel=3,
            )

        resolved = []
        for entry in registry:
            if not isinstance(entry, dict):
                continue
            entry = entry.copy()
            entry['enabled'] = entry.get('name', '').upper() in wanted
            resolved.append(entry)
        return resolved

    def configure(self,
                 debayer: str = "High Quality (Faster)",
                 vignette_correction: bool = True,
                 reflectance_calibration: bool = True,
                 indices: Optional[List[str]] = None,
                 export_format: str = "TIFF (16-bit)",
                 ppk: bool = False,
                 custom_settings: Optional[Dict] = None) -> Dict:
        """
        Configure processing settings
        
        Args:
            debayer: Debayer method (default: "High Quality (Faster)")
            vignette_correction: Enable vignette correction (default: True)
            reflectance_calibration: Enable reflectance calibration (default: True)
            indices: List of vegetation indices to calculate (e.g., ["NDVI", "NDRE"])
            export_format: Output format:
                - "TIFF (16-bit)" (default, recommended)
                - "TIFF (32-bit, Percent)"
                - "PNG (8-bit)"
                - "JPG (8-bit)"
            ppk: Enable PPK corrections from .daq files (default: False)
            custom_settings: Custom settings dict for advanced configuration
        
        Returns:
            dict: Configuration response
        
        Raises:
            ChlorosConfigurationError: If configuration fails
        
        Example:
            >>> # Basic configuration
            >>> chloros.configure(
            ...     vignette_correction=True,
            ...     reflectance_calibration=True,
            ...     indices=["NDVI", "NDRE", "GNDVI"]
            ... )
            >>> 
            >>> # Advanced configuration
            >>> chloros.configure(
            ...     debayer="High Quality (Faster)",
            ...     export_format="TIFF (32-bit, Percent)",
            ...     ppk=True,
            ...     indices=["NDVI", "NDRE", "GNDVI", "OSAVI", "CIG"]
            ... )
        """
        # Validate export_format against the known set so a typo doesn't
        # silently fall back to default. custom_settings bypasses validation
        # by design.
        if not custom_settings and export_format not in SUPPORTED_EXPORT_FORMATS:
            raise ChlorosConfigurationError(
                f"Unknown export_format {export_format!r}. "
                f"Supported: {list(SUPPORTED_EXPORT_FORMATS)}."
            )

        # Build settings dict
        if custom_settings:
            settings = custom_settings
        else:
            settings = {
                "Project Settings": {
                    "Processing": {
                        "Debayer method": debayer,
                        "Vignette correction": vignette_correction,
                        "Reflectance calibration / white balance": reflectance_calibration,
                        "Apply PPK Corrections": ppk
                    },
                    "Export": {
                        "Calibrated image format": export_format
                    }
                }
            }
            
            if indices:
                # The backend stores indices as list of dicts (with formula,
                # channelmap, etc.). Sending raw names breaks export — see
                # tasks.py:_export_index_images. Mirror chloros_cli: fetch the
                # registry, toggle 'enabled' on requested ones, send the dicts.
                resolved = self._resolve_index_configs(indices)
                if resolved:
                    settings["Project Settings"]["Index"] = {"Add index": resolved}
                else:
                    # Registry lookup failed (network, no project, empty
                    # registry on a brand-new install). Fall back to raw
                    # names so old behavior is preserved, but warn the user
                    # — the export step will likely produce no index files.
                    warnings.warn(
                        "Backend index registry was empty or unreachable. "
                        "Falling back to raw index names; index images may "
                        "fail to export. Open the project once in Chloros "
                        "Desktop to seed the registry, or call create_project "
                        "with a camera template that pre-populates indices.",
                        UserWarning,
                        stacklevel=2,
                    )
                    settings["Project Settings"]["Index"] = {"Add index": indices}
        
        try:
            response = self._request(
                'POST',
                '/api/update-project-config',
                json_data=settings
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise ChlorosConfigurationError(
                f"Failed to configure settings: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
    
    def process(self,
               mode: str = "parallel",
               wait: bool = True,
               progress_callback: Optional[Callable[[int, str], None]] = None,
               poll_interval: float = 2.0) -> Dict:
        """
        Start processing the project
        
        Args:
            mode: Processing mode:
                - "parallel": Parallel processing (requires Chloros+, recommended)
                - "serial": Serial processing (one image at a time)
            wait: Wait for processing to complete (default: True)
            progress_callback: Optional callback function(progress: int, message: str)
                               Called periodically with progress updates
            poll_interval: Polling interval in seconds for progress checks (default: 2.0)
        
        Returns:
            dict: Processing results
        
        Raises:
            ChlorosProcessingError: If processing fails
            ChlorosLicenseError: If mode requires Chloros+ and not licensed
        
        Example:
            >>> # Simple processing
            >>> results = chloros.process()
            >>> 
            >>> # With progress monitoring
            >>> def show_progress(progress, message):
            ...     print(f"[{progress}%] {message}")
            >>> 
            >>> chloros.process(
            ...     mode="parallel",
            ...     progress_callback=show_progress,
            ...     wait=True
            ... )
            >>> 
            >>> # Fire-and-forget
            >>> chloros.process(wait=False)
        """
        # Set processing mode
        try:
            mode_response = self._request(
                'POST',
                '/api/set-processing-mode',
                json_data={'mode': mode}
            )
            mode_response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 403:
                raise ChlorosLicenseError(
                    f"Mode '{mode}' requires Chloros+ license. "
                    "Upgrade at https://cloud.mapir.camera/pricing"
                )
            raise ChlorosProcessingError(f"Failed to set processing mode: {str(e)}")
        
        # Start processing
        try:
            process_response = self._request(
                'POST',
                '/api/process-project',
                timeout=10  # Quick response, actual processing is async
            )
            process_response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            raise ChlorosProcessingError(
                f"Failed to start processing: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
        
        if not wait:
            return {"status": "started", "async": True}
        
        # Monitor progress
        if progress_callback:
            self._monitor_progress_polling(progress_callback, poll_interval)
        else:
            self._wait_for_completion(poll_interval)
        
        return {"status": "complete", "async": False}
    
    def _monitor_progress_polling(self,
                                  callback: Callable[[int, str], None],
                                  poll_interval: float = 2.0):
        """
        Monitor processing progress via polling

        Args:
            callback: Function to call with progress updates
            poll_interval: Polling interval in seconds
        """
        last_message = ""
        last_percent = -1
        max_wait = self.processing_timeout
        stuck_timeout = self.processing_stuck_timeout
        start_time = time.time()
        last_progress_time = start_time
        processing_started = False
        idle_count = 0  # Track consecutive idle states after processing started

        while True:
            time.sleep(poll_interval)
            now = time.time()

            try:
                response = self._request('GET', '/api/get-processing-progress', timeout=5)
                if not response.ok:
                    continue

                progress_data = response.json()
                percent = progress_data.get('percent', 0)
                phase = progress_data.get('phase', 'unknown')
                threads = progress_data.get('threads', {})

                # Build a descriptive message from per-thread status
                if threads:
                    active_parts = []
                    for tid in sorted(threads.keys()):
                        t = threads[tid]
                        if t.get('isActive'):
                            t_pct = t.get('percent', 0)
                            t_phase = t.get('phase', '')
                            active_parts.append(f"{t_phase} {t_pct}%")
                    if active_parts:
                        message = ' | '.join(active_parts)
                    elif phase == 'complete':
                        message = 'Processing complete'
                    else:
                        message = phase
                else:
                    message = phase

                # Track if processing has started. Latch processing_started on
                # any non-idle activity, but only reset idle_count when the
                # phase is non-idle — backends sometimes report phase='idle'
                # with sticky percent > 0 between stages, and in that state
                # the 2-idle fallback below still needs to fire to detect
                # completion.
                if percent > 0 or phase not in ('idle', 'unknown'):
                    processing_started = True
                    if phase not in ('idle', 'unknown'):
                        idle_count = 0

                # Check for completion
                if phase == 'complete':
                    callback(100, "Processing complete")
                    return

                if processing_started and phase == 'idle':
                    idle_count += 1
                    if idle_count >= 2:
                        callback(100, "Processing complete")
                        return

                # Also check thread 4 (export) completion as backup
                try:
                    t4_response = self._request('GET', '/api/get-thread-4-progress', timeout=5)
                    if t4_response.ok:
                        t4_data = t4_response.json()
                        if t4_data.get('percent', 0) == 100 and not t4_data.get('isActive', True):
                            callback(100, "Processing complete")
                            return
                except Exception:
                    pass

                # Report on any change in percent or message; reset stuck timer
                if percent != last_percent or message != last_message:
                    callback(percent, message)
                    last_percent = percent
                    last_message = message
                    last_progress_time = now

            except Exception:
                pass

            if now - last_progress_time > stuck_timeout:
                raise ChlorosProcessingError(
                    f"Processing appears stuck — no progress for {int(now - last_progress_time)}s "
                    f"(stuck_timeout={stuck_timeout}s). Backend may be hung."
                )
            if now - start_time > max_wait:
                raise ChlorosProcessingError(
                    f"Processing exceeded max_wait of {max_wait}s. "
                    f"Increase processing_timeout if the run is legitimately this long."
                )
    
    def _wait_for_completion(self, poll_interval: float = 2.0):
        """
        Simple wait for completion without progress updates

        Args:
            poll_interval: Polling interval in seconds
        """
        max_wait = self.processing_timeout
        stuck_timeout = self.processing_stuck_timeout
        start_time = time.time()
        last_progress_time = start_time
        last_percent = -1
        last_phase = ""
        processing_started = False
        idle_count = 0

        while True:
            time.sleep(poll_interval)
            now = time.time()

            try:
                # Use the actual processing progress endpoint
                response = self._request('GET', '/api/get-processing-progress', timeout=5)
                if response.ok:
                    progress_data = response.json()
                    percent = progress_data.get('percent', 0)
                    phase = progress_data.get('phase', 'unknown')

                    # Track if processing has started. Only reset idle_count
                    # on a non-idle phase; sticky percent > 0 with phase=idle
                    # is common between stages and shouldn't kill the 2-idle
                    # fallback. (See _monitor_progress_polling for context.)
                    if percent > 0 or phase not in ('idle', 'unknown'):
                        processing_started = True
                        if phase not in ('idle', 'unknown'):
                            idle_count = 0

                    # Check for completion: idle after processing started
                    if processing_started and phase == 'idle':
                        idle_count += 1
                        if idle_count >= 2:  # Confirm idle for 2 polls
                            return

                    # Also check thread 4 (export) progress
                    try:
                        t4_response = self._request('GET', '/api/get-thread-4-progress', timeout=5)
                        if t4_response.ok:
                            t4_data = t4_response.json()
                            if t4_data.get('percent', 0) == 100 and not t4_data.get('isActive', True):
                                return
                    except Exception:
                        pass

                    # Reset stuck timer on any change
                    if percent != last_percent or phase != last_phase:
                        last_percent = percent
                        last_phase = phase
                        last_progress_time = now

            except Exception:
                pass

            if now - last_progress_time > stuck_timeout:
                raise ChlorosProcessingError(
                    f"Processing appears stuck — no progress for {int(now - last_progress_time)}s "
                    f"(stuck_timeout={stuck_timeout}s). Backend may be hung."
                )
            if now - start_time > max_wait:
                raise ChlorosProcessingError(
                    f"Processing exceeded max_wait of {max_wait}s. "
                    f"Increase processing_timeout if the run is legitimately this long."
                )
    
    def get_config(self) -> Dict:
        """
        Get current project configuration
        
        Returns:
            dict: Current project configuration
        
        Raises:
            ChlorosConnectionError: If request fails
        
        Example:
            >>> config = chloros.get_config()
            >>> print(config['Project Settings'])
        """
        try:
            response = self._request('GET', '/api/get-config')
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise ChlorosConnectionError(
                f"Failed to get config: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
    
    def get_status(self) -> Dict:
        """
        Get backend and processing status

        Returns:
            dict: Backend status information including:
                - running: Whether backend is responding
                - url: Backend API URL
                - processing: Processing progress info (percent, phase)
                - export: Export/Thread-4 progress info

        Example:
            >>> status = chloros.get_status()
            >>> print(f"Processing: {status.get('processing', {}).get('percent')}%")
        """
        result = {
            'running': False,
            'url': self.api_url,
            'processing': {'percent': 0, 'phase': 'unknown'},
            'export': {'percent': 0, 'phase': 'unknown', 'active': False}
        }

        try:
            # Check if backend is running
            response = self._request('GET', '/', timeout=5)
            result['running'] = response.ok
            result['status_code'] = response.status_code
        except Exception as e:
            result['error'] = str(e)
            return result

        # Get processing progress
        try:
            response = self._request('GET', '/api/get-processing-progress', timeout=5)
            if response.ok:
                data = response.json()
                result['processing'] = {
                    'percent': data.get('percent', 0),
                    'phase': data.get('phase', 'idle')
                }
        except Exception:
            pass

        # Get export/thread-4 progress
        try:
            response = self._request('GET', '/api/get-thread-4-progress', timeout=5)
            if response.ok:
                data = response.json()
                result['export'] = {
                    'percent': data.get('percent', 0),
                    'phase': data.get('phase', 'Not Started'),
                    'active': data.get('isActive', False)
                }
        except Exception:
            pass

        return result
    
    def logout(self) -> Dict:
        """
        Logout and clear stored credentials
        
        This clears the cached session file (~/.chloros/user_session.json)
        to prevent auto-login on next backend start.
        
        Returns:
            dict: Logout response with success status
        
        Raises:
            ChlorosConnectionError: If logout request fails
        
        Example:
            >>> chloros = ChlorosLocal()
            >>> # ... do some work ...
            >>> chloros.logout()
            >>> print("Logged out - credentials cleared")
        """
        try:
            response = self._request(
                'POST',
                '/api/logout',
                json_data={}
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise ChlorosConnectionError(
                f"Logout failed: {e.response.text if hasattr(e, 'response') else str(e)}"
            )
    
    def shutdown_backend(self):
        """
        Shutdown the backend (if started by SDK)
        
        Example:
            >>> chloros.shutdown_backend()
        """
        if self.backend_process:
            try:
                self.backend_process.terminate()
                self.backend_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.backend_process.kill()
            finally:
                self.backend_process = None
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup"""
        self.shutdown_backend()
    
    def __del__(self):
        """Destructor - cleanup"""
        if hasattr(self, 'backend_process'):
            self.shutdown_backend()

    # =========================================================================
    # CAMERA CONVENIENCE METHODS (direct hardware, no backend needed)
    # =========================================================================

    def discover_cameras(self) -> list:
        """Discover LATTICE cameras on the network.

        Returns a list of CameraInfo dataclasses, or an empty list
        if no cameras are found or camera support is not available.

        Does not require the backend to be running.
        """
        try:
            from lattice_sdk import discover_cameras
            return discover_cameras()
        except BaseException:
            return []

    def camera_capture(self, output_dir: str = "output",
                       format: str = "tiff", **settings) -> dict:
        """Capture a single frame from a LATTICE camera.

        Does not require the backend to be running.

        Args:
            output_dir: Directory for captured image (default: "output")
            format: Image format - "tiff", "png", or "jpg" (default: "tiff")
            **settings: Camera settings (exposure, gain, pixel_format, etc.)

        Returns:
            dict with keys: filepath, width, height, pixel_format,
            exposure_time, gain, timestamp

        Raises:
            ImportError: If camera support is not available
        """
        from lattice_sdk import LatticeCamera, CameraSettings

        cam_settings = CameraSettings()
        if 'exposure' in settings:
            cam_settings.exposure_time = settings['exposure']
            cam_settings.exposure_auto = "Off"
        if 'gain' in settings:
            cam_settings.gain = settings['gain']
            cam_settings.gain_auto = "Off"
        if 'pixel_format' in settings:
            cam_settings.pixel_format = settings['pixel_format']
        if 'preset' in settings:
            from lattice_sdk import PRESETS
            cam_settings = PRESETS.get(settings['preset'], cam_settings)

        device_index = settings.get('device_index', 0)
        with LatticeCamera(device_index=device_index,
                           settings=cam_settings) as cam:
            result = cam.capture(output_dir=output_dir, format=format)
            return {
                'filepath': result.filepath,
                'width': result.width,
                'height': result.height,
                'pixel_format': result.pixel_format,
                'exposure_time': result.exposure_time,
                'gain': result.gain,
                'timestamp': result.timestamp,
            }

    def camera_capture_burst(self, count: int = 5, interval: float = 0.0,
                             output_dir: str = "output",
                             format: str = "tiff", **settings) -> list:
        """Capture a burst of frames from a LATTICE camera.

        Does not require the backend to be running.

        Args:
            count: Number of frames (default: 5)
            interval: Delay between frames in seconds (default: 0)
            output_dir: Directory for captured images
            format: Image format
            **settings: Camera settings

        Returns:
            List of dicts with capture metadata
        """
        from lattice_sdk import LatticeCamera, CameraSettings

        cam_settings = CameraSettings()
        if 'exposure' in settings:
            cam_settings.exposure_time = settings['exposure']
            cam_settings.exposure_auto = "Off"
        if 'gain' in settings:
            cam_settings.gain = settings['gain']
            cam_settings.gain_auto = "Off"
        if 'pixel_format' in settings:
            cam_settings.pixel_format = settings['pixel_format']
        if 'preset' in settings:
            from lattice_sdk import PRESETS
            cam_settings = PRESETS.get(settings['preset'], cam_settings)

        device_index = settings.get('device_index', 0)
        with LatticeCamera(device_index=device_index,
                           settings=cam_settings) as cam:
            results = cam.capture_burst(
                count=count, interval=interval,
                output_dir=output_dir, format=format)
            return [
                {
                    'filepath': r.filepath,
                    'width': r.width,
                    'height': r.height,
                    'pixel_format': r.pixel_format,
                    'exposure_time': r.exposure_time,
                    'gain': r.gain,
                    'timestamp': r.timestamp,
                }
                for r in results
            ]


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def process_folder(folder_path: Union[str, Path],
                  project_name: Optional[str] = None,
                  camera: Optional[str] = None,
                  indices: Optional[List[str]] = None,
                  vignette_correction: bool = True,
                  reflectance_calibration: bool = True,
                  export_format: str = "TIFF (16-bit)",
                  mode: str = "parallel",
                  progress_callback: Optional[Callable[[int, str], None]] = None,
                  debayer: str = "High Quality (Faster)",
                  ppk: bool = False,
                  recursive: bool = False,
                  api_url: str = "http://localhost:5000",
                  timeout: int = 30,
                  processing_timeout: int = 14400,
                  processing_stuck_timeout: int = 1800,
                  poll_interval: float = 2.0,
                  backend_exe: Optional[str] = None) -> Dict:
    """
    Convenience function to process a folder in one call
    
    This function creates a project, imports images, configures settings,
    and processes images with minimal code.
    
    Args:
        folder_path: Path to folder containing images
        project_name: Project name (auto-generated from folder name if None)
        camera: Camera template (optional)
        indices: List of indices to calculate (default: ["NDVI"])
        vignette_correction: Enable vignette correction (default: True)
        reflectance_calibration: Enable reflectance calibration (default: True)
        export_format: Output format (default: "TIFF (16-bit)")
        mode: Processing mode (default: "parallel")
        progress_callback: Optional progress callback function
        **kwargs: Additional configuration options
    
    Returns:
        dict: Processing results
    
    Raises:
        ChlorosError: If any step fails
    
    Example:
        >>> from chloros_sdk import process_folder
        >>> 
        >>> # Simple one-liner
        >>> results = process_folder("C:/DroneImages/Flight001")
        >>> 
        >>> # With custom settings
        >>> results = process_folder(
        ...     "C:/DroneImages/Flight001",
        ...     project_name="Field_A_Survey",
        ...     camera="Survey3N_RGN",
        ...     indices=["NDVI", "NDRE", "GNDVI"],
        ...     mode="parallel"
        ... )
        >>> 
        >>> # With progress monitoring
        >>> def show_progress(progress, message):
        ...     print(f"[{progress}%] {message}")
        >>> 
        >>> results = process_folder(
        ...     "C:/DroneImages/Flight001",
        ...     progress_callback=show_progress
        ... )
    """
    folder_path = Path(folder_path)
    
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder_path}")
    
    # Generate project name from folder if not provided
    if project_name is None:
        project_name = folder_path.name

    # Default indices if none provided
    if indices is None:
        indices = ["NDVI"]

    with ChlorosLocal(
        api_url=api_url,
        timeout=timeout,
        processing_timeout=processing_timeout,
        processing_stuck_timeout=processing_stuck_timeout,
        backend_exe=backend_exe,
    ) as chloros:
        chloros.create_project(project_name, camera=camera)
        chloros.import_images(folder_path, recursive=recursive)
        chloros.configure(
            debayer=debayer,
            vignette_correction=vignette_correction,
            reflectance_calibration=reflectance_calibration,
            indices=indices,
            export_format=export_format,
            ppk=ppk,
        )
        results = chloros.process(
            mode=mode,
            wait=True,
            progress_callback=progress_callback,
            poll_interval=poll_interval,
        )

    return results






