"""LATTICE calibration cache — bridges camera UserFile storage + AWS.

At session start the acquisition tool calls :func:`load_for_camera`,
which:

1. Reads ``UserFile1`` (identity blob, <2 KB) via GenICam File Access.
2. If the identity says ``full_pack_on_camera=true``, reads ``UserFile2``,
   verifies its sha256, and extracts the compressed tarball to the
   local cache at ``~/.chloros/camera_cal/<serial>/<bundle_sha>/``.
3. Otherwise, leaves a note in the cache dir indicating AWS is the
   source of truth; the uploader wiring for that lands in a later
   pass (see ``project_lattice_nist_calibration.md``).

The returned :class:`CalibrationBundle` holds both the identity + the
parsed scalar coefficients, and knows how to load heavy per-pixel
assets on demand. The XMP writer consumes this to emit a sidecar per
captured frame.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

CACHE_ROOT = Path.home() / ".chloros" / "camera_cal"


def _purge_orphan_sha_dirs(serial: str, keep_sha: str) -> List[str]:
    """Delete sibling SHA dirs under the cam's cache, keeping only *keep_sha*.

    Once a camera has been recalibrated and chloros has just downloaded
    the new bundle, the old SHA-keyed directory under
    ``~/.chloros/camera_cal/<serial>/`` is dead weight — the camera
    will never report that SHA in its identity blob again, so the dir
    will never cache-hit. Sweep it on every successful new-bundle
    extract so the cache stays small and the user doesn't accumulate
    stale calibration data over the cam's lifetime.

    Returns the list of removed dir names (for logging). Failures are
    swallowed: leaving an orphan around isn't a correctness issue, it
    just wastes a few MB.
    """
    import shutil
    serial_dir = CACHE_ROOT / serial
    removed: List[str] = []
    if not serial_dir.is_dir():
        return removed
    try:
        for child in serial_dir.iterdir():
            if not child.is_dir():
                continue
            if child.name == keep_sha:
                continue
            try:
                shutil.rmtree(child)
                removed.append(child.name)
            except Exception as exc:
                logger.warning(
                    "Could not remove orphan cal dir %s: %s",
                    child, exc)
    except Exception as exc:
        logger.warning("Orphan-cleanup scan failed for %s: %s",
                       serial_dir, exc)
    return removed


# -- Scalars-derived matrix (overrides spectral_response stage matrix) ------
#
# The spectral_response stage builds the 3×3 SR matrix by sweeping
# individual LEDs and computing per-channel response as
# ``pixel / (LED_total_energy × exp)``. This inadvertently bakes the
# LED's bandwidth into the response curve: for an LED whose emission
# spectrum extends past the dichroic filter's pass band, only the
# in-band fraction reaches the sensor, but the FULL LED energy goes
# into the denominator. The bias varies LED-to-LED (different widths
# vs different filter pass bands), so the resulting matrix has biased
# off-diagonal cross-band ratios.
#
# The radiance stage doesn't have this bias: it fits
# ``DN = k × E_band × t`` where E_band comes from a spectrometer
# integration over the same wavelength range that the dichroic
# actually passes. Each (bayer, band) scalar is a clean empirical
# measurement of "how many DN does the bayer produce per unit in-band
# irradiance".
#
# Building the matrix from these scalars removes the LED-width bias
# AND keeps the spectral_response and radiance stages internally
# consistent (they describe the same physical thing the same way),
# which is what makes downstream radiometric chains work without an
# in-scene reference target.

_FILTER_BAND_ORDER = {
    'RGN': ('red', 'green', 'nir'),
    'OCN': ('orange', 'cyan', 'nir'),
    'NGB': ('nir', 'green', 'blue'),
    'RGB': ('red', 'green', 'blue'),
}

# Bayer index → preferred bayer-label keys, in scalar-lookup order.
# Index 0 = R-bayer site, 1 = G-bayer site (averaged Gr/Gb), 2 = B-bayer.
_BAYER_LABELS = (('R',), ('Gr', 'Gb', 'G'), ('B',))


def _derive_matrix_from_scalars(
    scalars: Dict[str, Dict[str, float]]
) -> Optional[List[List[float]]]:
    """Build a row-normalized 3×3 SR matrix from per-bayer-per-band radiance scalars.

    The returned matrix is in the same shape and convention as the
    ``normalized_matrix`` produced by ``spectral_response.matrix.compute_calibration``:
    rows = bayer position (R, G, B), columns = filter band in
    ``FILTER_PASS_BANDS`` insertion order, diagonal entries = 1.0.

    Returns ``None`` if the scalars dict doesn't include all 9 (bayer,
    band) entries needed (e.g. legacy bundles or partial calibration);
    caller should fall back to the spectral_response stage matrix in
    that case.
    """
    if not scalars:
        return None
    # Identify filter from band keys (FRGN_red → "RGN"; FOCN_nir → "OCN")
    filter_code = None
    for k in scalars.keys():
        if isinstance(k, str) and k.startswith('F') and '_' in k:
            filter_code = k.split('_', 1)[0][1:].upper()
            break
    if filter_code not in _FILTER_BAND_ORDER:
        return None
    cols = _FILTER_BAND_ORDER[filter_code]

    # Build raw_M[bayer_i, band_j] = 1 / scalars[band_j][bayer_i].
    # Each scalar has units (W/m²/nm) / (DN/µs); inverse gives DN/µs
    # per (W/m²/nm) — i.e. raw_M element in matched units that the
    # downstream bake just renormalises away.
    raw_M = [[0.0] * 3 for _ in range(3)]
    for i in range(3):  # bayer row
        for j in range(3):  # band col
            band_key = f"F{filter_code}_{cols[j]}"
            band_dict = scalars.get(band_key)
            if not isinstance(band_dict, dict):
                return None
            scalar = None
            for lbl in _BAYER_LABELS[i]:
                v = band_dict.get(lbl)
                if v is None:
                    continue
                try:
                    fv = float(v)
                except (TypeError, ValueError):
                    continue
                if fv > 0.0:
                    scalar = fv
                    break
            if scalar is None or scalar <= 0.0:
                return None
            raw_M[i][j] = 1.0 / scalar

    # Row-normalize so each diagonal = 1 (matches the
    # ``normalized_matrix`` convention the backend's bake expects).
    norm_M = [[0.0] * 3 for _ in range(3)]
    for i in range(3):
        diag = raw_M[i][i]
        if diag <= 0.0:
            return None
        for j in range(3):
            norm_M[i][j] = raw_M[i][j] / diag
    return norm_M


# -- Low-level User-file reader --------------------------------------------
#
# Mirrors the write path in ``production_calibration.programming`` but
# lives here so the SDK has no build-time dependency on the calibration
# repo. If we ever publish a shared vendor-neutral helper library,
# these converge.

CHUNK_BYTES = 4096

# Production_calibration writes UserFile1 as a single MAPC-framed
# blob: b"MAPC" + uint32_LE(identity_len) + identity_json + pack_bytes.
# The identity JSON is small (<2 KB) and the pack is the optional
# zstd-compressed tarball of the full bundle. Both live in the same
# UserFile slot — the camera only exposes one writable user file.
BLOB_MAGIC = b"MAPC"
BLOB_HEADER_LEN = len(BLOB_MAGIC) + 4


def _nodemap(cam):
    if hasattr(cam, "_device") and hasattr(cam._device, "nodemap"):
        return cam._device.nodemap
    if hasattr(cam, "nodemap"):
        return cam.nodemap
    return cam


def _set(cam, name: str, value: Any) -> None:
    _nodemap(cam).get_node(name).value = value


def _execute_and_wait(cam, *, timeout_s: float = 10.0,
                       poll_s: float = 0.02) -> None:
    """Fire FileOperationExecute and poll is_done until completion.

    Arena's execute() returns immediately; subsequent node writes
    can race the async firmware op and fail with a generic
    SC_ERR_ERROR -1001. This is the same fix production_calibration
    applies on the write path — without it the read loop's chunk
    Set/Read sequence races whatever the firmware is still doing
    from the prior Open/Read execute.
    """
    import time as _time
    nm = _nodemap(cam)
    node = nm.get_node("FileOperationExecute")
    node.execute()
    deadline = _time.time() + timeout_s
    while _time.time() < deadline:
        try:
            if node.is_done:
                return
        except Exception:
            # Some firmwares don't expose is_done — give it a brief
            # pause and trust implicit completion.
            _time.sleep(poll_s * 5)
            return
        _time.sleep(poll_s)
    raise RuntimeError(
        f"FileOperationExecute did not complete within {timeout_s}s")


def _safe_int(cam, name: str, default: int = 0) -> int:
    try:
        return int(_nodemap(cam).get_node(name).value)
    except Exception:
        return default


def _as_register_node(cam, name: str):
    """Return a NodeRegister for *name* regardless of how arena_api
    cast the generic node at get_node() time.

    Triton firmware reports FileAccessBuffer with an interface type
    that gets cast to NodeInteger, losing the register .get(length)
    method. Force-construct a NodeRegister from the raw handle.
    Mirrors production_calibration.programming._as_register_node.
    """
    from arena_api._node import NodeRegister
    node = _nodemap(cam).get_node(name)
    if isinstance(node, NodeRegister):
        return node
    hxnode = node.xnode.hxnode.value
    return NodeRegister(hxnode)


def _get_buffer(cam, length: int) -> bytes:
    return bytes(_as_register_node(cam, "FileAccessBuffer").get(length))


def _assert_status(cam, *, context: str) -> None:
    try:
        status = str(_nodemap(cam).get_node("FileOperationStatus").value)
    except Exception:
        return
    if status.lower() != "success":
        raise RuntimeError(f"UserFile read failed during {context}: {status}")


def _open_userfile_for_read(camera, *, slot: str) -> int:
    """Open *slot* for reading and return its FileSize.

    Caller is responsible for matching this with _close_userfile().
    Splitting open from read lets us read the file in stages — pull
    the small MAPC header first, decide whether the cache already
    has the bundle, and skip the multi-MB pack read if so.
    """
    _set(camera, "FileSelector", slot)

    # Defensive close — clear any state the previous failed attempt
    # may have left.
    try:
        _set(camera, "FileOperationSelector", "Close")
        _execute_and_wait(camera)
    except Exception:
        pass

    _set(camera, "FileOpenMode", "Read")
    _set(camera, "FileOperationSelector", "Open")
    _execute_and_wait(camera)
    _assert_status(camera, context=f"open {slot}")
    return _safe_int(camera, "FileSize", default=0)


def _close_userfile(camera) -> None:
    try:
        _set(camera, "FileOperationSelector", "Close")
        _execute_and_wait(camera)
    except Exception:
        pass


def _read_userfile_range(camera, *, slot: str, offset: int,
                          length: int, progress_cb=None) -> bytes:
    """Read *length* bytes starting at *offset* from an already-open slot.

    Optional ``progress_cb(bytes_done, total)`` is invoked at most
    every ~100 ms while reading; the GenICam file-access protocol
    over GigE caps out around 50 KB/s on Triton, so a multi-MB pack
    needs progress reporting or callers will look frozen.
    """
    import time as _time
    data = bytearray()
    last_cb = 0.0
    if progress_cb is not None:
        try:
            progress_cb(0, length)
        except Exception:
            pass
    while len(data) < length:
        remaining = length - len(data)
        chunk = min(CHUNK_BYTES, remaining)
        op_offset = offset + len(data)
        _set(camera, "FileOperationSelector", "Read")
        _set(camera, "FileAccessOffset", op_offset)
        _set(camera, "FileAccessLength", chunk)
        _execute_and_wait(camera)
        _assert_status(camera, context=f"read {slot} @ {op_offset}")
        data.extend(_get_buffer(camera, chunk))
        if progress_cb is not None:
            now = _time.time()
            if now - last_cb >= 0.1 or len(data) == length:
                try:
                    progress_cb(len(data), length)
                except Exception:
                    pass
                last_cb = now
    return bytes(data)


def _read_userfile(camera, *, slot: str,
                    max_bytes: Optional[int] = None) -> bytes:
    """One-shot read of an entire UserFile slot. Kept for callers that
    don't need staged caching (the live array path uses the staged
    open+range API directly so it can cache-hit without pulling the
    pack body).
    """
    file_size = _open_userfile_for_read(camera, slot=slot)
    try:
        total = file_size if max_bytes is None \
            else min(file_size, max_bytes)
        return _read_userfile_range(
            camera, slot=slot, offset=0, length=total)
    finally:
        _close_userfile(camera)


def _parse_mapc_blob(blob: bytes):
    """Inverse of production_calibration.programming._frame_blob.

    Returns ``(identity_bytes, pack_bytes)``. Tolerates legacy
    identity-only blobs (no MAPC header) and trailing NUL pad from
    the camera's block alignment.
    """
    trimmed = blob.rstrip(b"\x00")
    if trimmed.startswith(BLOB_MAGIC):
        identity_len = int.from_bytes(
            trimmed[len(BLOB_MAGIC):BLOB_HEADER_LEN], "little")
        start = BLOB_HEADER_LEN
        return (trimmed[start:start + identity_len],
                trimmed[start + identity_len:])
    return trimmed, b""


# -- Cache bundle ----------------------------------------------------------

@dataclass
class CalibrationBundle:
    identity: Dict[str, Any]                 # parsed UserFile1 JSON
    cache_dir: Path                          # where heavy assets live (if any)
    bundle_json: Optional[Dict[str, Any]] = None    # full bundle.json if extracted
    compact_manifest: Optional[Dict[str, Any]] = None

    @property
    def serial(self) -> str:
        return self.identity.get("serial", "")

    @property
    def bundle_sha256(self) -> str:
        return self.identity.get("cal_bundle_sha256", "")

    @property
    def has_full_pack(self) -> bool:
        return bool(self.bundle_json)

    @property
    def pack_tier(self) -> str:
        """Returns the pack tier recorded on the camera.

        One of: ``"full"``, ``"full_poly_flat_field"``,
        ``"core_no_flat_field"``, ``"minimal"``, or ``"none"``.
        ``full_poly_flat_field`` is the higher-res-sensor fallback —
        no per-pixel flat-field TIFFs on the camera, but the
        MicaSense-style polynomial coefficients travel in bundle.json
        and Chloros can reconstruct a vignette correction from them.

        Read from the identity blob first (newer format), falling back
        to the compact manifest's own tier field if an older identity
        blob doesn't carry it.
        """
        return (
            self.identity.get("pack_tier")
            or (self.compact_manifest or {}).get("tier")
            or ("full" if self.has_full_pack else "none")
        )

    @property
    def has_flat_field_assets(self) -> bool:
        """True only for tiers that ship per-pixel flat-field TIFFs."""
        return self.pack_tier == "full"

    @property
    def has_dsnu_assets(self) -> bool:
        """True for tiers that ship the DSNU master-offset + Arrhenius assets."""
        return self.pack_tier in ("full", "full_poly_flat_field",
                                    "core_no_flat_field")

    @property
    def has_polynomial_vignette(self) -> bool:
        """True when the bundle carries a polynomial vignette fit.

        All tiers except ``"none"`` can carry it (it lives in
        ``bundle.json``, not in the compact manifest). Chloros uses this
        to gate the "fall back to polynomial" branch when per-pixel
        TIFFs aren't available.
        """
        if not self.bundle_json:
            return False
        stages = self.bundle_json.get("stages") or {}
        return bool(stages.get("vignette_polynomial")
                     or self.bundle_json.get("vignette_polynomial"))

    def scalar_cal(self) -> Dict[str, Any]:
        """Return the scalar-only cal data that goes into XMP sidecars.

        Heavy per-pixel arrays are left out — XMP points to the cache
        dir + sha so Chloros can pull them locally.
        """
        out: Dict[str, Any] = {"identity": self.identity}
        if not self.bundle_json:
            return out

        stages = self.bundle_json.get("stages", {}) or {}

        # Spectral response 3x3 matrices
        sr = stages.get("spectral_response", {}) or {}
        matrices = sr.get("matrices", {}) or {}
        # Strip deep per-camera structure to just the normalized matrix
        out["spectral_response_matrix"] = {
            cam: info.get("normalized_matrix")
            for cam, info in matrices.items()
        }
        # Keep the original spectral_response stage matrix around
        # under a separate key so the cal-load diagnostic can print
        # it side-by-side with the scalars-derived override below.
        # Lets us see, per-cam, how badly the two stages disagree —
        # the stronger that disagreement, the more cal pipeline
        # debt remains. Once both stages produce matching matrices
        # (after the production_calibration in-band-LED-energy fix
        # is rolled out fleet-wide) this delta should approach
        # zero and we can drop the override entirely.
        out["spectral_response_matrix_from_stage"] = dict(
            out["spectral_response_matrix"])

        # Absolute radiance scalars per band per channel. Bundles
        # programmed by production_calibration >= the FILTER_PASS_BANDS
        # rename land here keyed in the canonical
        # ``F<FILTER>_<color>`` form (e.g. ``FRGN_red``,
        # ``FOCN_NIR``). Older bundles still carry plain color words
        # ("red", "nir") — those cams need to be reprogrammed; we
        # surface the legacy keys as-is so a downstream lookup can
        # at least try a fallback match.
        rad = stages.get("radiance", {}) or {}
        out["radiance_scalars_per_band"] = (
            rad.get("scalars_per_band", {}) or {})

        # If the bundle carries a complete radiance scalar grid,
        # OVERRIDE the spectral_response stage's matrix with one
        # derived from the scalars. The radiance scalars are clean
        # empirical fits against spectrometer-measured in-band
        # irradiance; the spectral_response matrix bakes in an LED-
        # bandwidth bias (per-channel response computed against
        # *total* LED energy, of which only the in-band fraction
        # reaches the sensor). Disagreement between the two stages
        # on the same physical quantity is what's been breaking
        # downstream NDVI for non-grey scenes — keeping them in
        # sync via the scalars-derived matrix removes that whole
        # class of problem and makes "radiometric cam + DLS, no
        # target" possible.
        scalars_matrix = _derive_matrix_from_scalars(
            out["radiance_scalars_per_band"])
        if scalars_matrix is not None:
            cam_keys = list(out["spectral_response_matrix"].keys())
            target_keys = cam_keys if cam_keys else ["default"]
            for k in target_keys:
                out["spectral_response_matrix"][k] = scalars_matrix
            out["spectral_response_matrix_source"] = "radiance_scalars"
            logger.info(
                "scalar_cal: matrix derived from radiance scalars "
                "(overrides spectral_response stage matrix to keep "
                "the two stages internally consistent)")
        else:
            out["spectral_response_matrix_source"] = "spectral_response_stage"

        # White-balance stage (RGB cameras only — multispectral /
        # mono runs leave this absent). Ships the factory WB
        # multipliers, the per-channel BalanceRatio programmed onto
        # the camera's UserSet1, and the reference illuminant
        # spectrum. Chloros combines these with a live DAQ-E / -U / -M
        # spectrum at capture time for per-frame illuminant
        # correction (see mip.Illuminant_Correction).
        wb = stages.get("white_balance", {}) or {}
        if wb:
            out["white_balance"] = {
                "digital_wb_bgr": wb.get("digital_wb_bgr"),
                "analog_balance_bgr": wb.get("analog_balance_bgr"),
                "reference_illuminant_cct_k": wb.get("reference_illuminant_cct_k"),
                "reference_exposure_us": wb.get("reference_exposure_us"),
                "reference_illuminant_spectrum": wb.get("reference_illuminant_spectrum"),
                "programmed_to_user_set": wb.get("programmed_to_user_set"),
            }

        # DSNU parametric model (offset + dark-current slope) — always
        # present in bundle.json even when the per-pixel asset lives on AWS.
        dsnu = stages.get("dsnu", {}) or {}
        out["dsnu_model"] = _load_json_if_path(dsnu.get("model_json_path"))

        # Arrhenius temperature model (Ea, T_ref). Tiny JSON, always
        # shipped so Chloros can apply the per-frame temperature
        # correction offline even when the per-pixel DC_coeff map
        # isn't in cache.
        out["dsnu_arrhenius"] = _load_json_if_path(
            dsnu.get("arrhenius_json_path"))

        out["dsnu_master_offset_ref"] = (
            {
                "archive_name": "dsnu/dsnu_master_offset_u8.tif",
                "cache_dir": str(self.cache_dir),
                "dequant": self._dequant_meta("dsnu/dsnu_master_offset_u8.tif"),
            } if self.has_dsnu_assets and self._dequant_meta(
                "dsnu/dsnu_master_offset_u8.tif") else None
        )
        out["dsnu_dc_coeff_ref"] = (
            {
                "archive_name": "dsnu/dsnu_dc_coeff_u8.tif",
                "cache_dir": str(self.cache_dir),
                "dequant": self._dequant_meta("dsnu/dsnu_dc_coeff_u8.tif"),
            } if self.has_dsnu_assets and self._dequant_meta(
                "dsnu/dsnu_dc_coeff_u8.tif") else None
        )

        # Flat-field refs (per-channel) — only present when tier=full.
        out["flat_field_refs"] = (
            {
                ch: {
                    "archive_name": f"flat_field/channel_{ch}_u8.tif",
                    "cache_dir": str(self.cache_dir),
                    "dequant": self._dequant_meta(f"flat_field/channel_{ch}_u8.tif"),
                }
                for ch in ("R", "G", "B")
                if self._dequant_meta(f"flat_field/channel_{ch}_u8.tif")
            } if self.has_flat_field_assets else {}
        )

        # Declare what's missing so downstream code can decide whether
        # to fetch from AWS, fall back to nominal defaults, or flag the
        # image as "scalar cal only".
        missing: List[str] = []
        if not self.has_flat_field_assets:
            missing.append("flat_field")
        if not self.has_dsnu_assets:
            missing.append("dsnu_master_offset")
        out["missing_heavy_assets"] = missing
        out["pack_tier"] = self.pack_tier

        # Linearity model (file ref; already a JSON) + full per-
        # channel LUT npz. The LUT (forward_lut: DN_observed →
        # DN_linearized, per channel, 4096-entry uint DN index)
        # enables pixel-wise non-linearity correction in Chloros
        # rather than the coarse MicaSense-style a2/a3 scalar path.
        # The npz is ~100 KiB — safe to include in every pack tier.
        lin = stages.get("linearity", {}) or {}
        out["linearity_model"] = _load_json_if_path(lin.get("model_json"))
        lin_lut_cached = self.cache_dir / "linearity" / "exposure_response_lut.npz"
        if lin_lut_cached.exists():
            out["linearity_lut_ref"] = {
                "archive_name": "linearity/exposure_response_lut.npz",
                "cache_dir": str(self.cache_dir),
            }

        # Uncertainty block (per-band per-channel U95)
        out["uncertainty"] = self.bundle_json.get("uncertainty")

        # Sensor architecture — tells downstream code whether to use the
        # 3x3 crosstalk matrix, the row-gradient correction, the mono
        # single-channel path, etc.
        out["sensor_profile"] = stages.get("sensor_profile") or \
            self.bundle_json.get("sensor_profile")

        # Parametric vignette polynomial (MicaSense-compatible).
        # Always emitted; Chloros falls back to it when the per-pixel
        # flat-field TIFF isn't in the local cache.
        out["vignette_polynomial"] = stages.get("vignette_polynomial")

        # Row-gradient model (a2, a3). Zero model for global-shutter
        # sensors but still carried so consumers don't need to branch
        # on architecture to read the field.
        out["row_gradient"] = stages.get("row_gradient")

        return out

    def _dequant_meta(self, archive_name: str) -> Optional[dict]:
        if not self.compact_manifest:
            return None
        return (self.compact_manifest.get("assets") or {}).get(archive_name)


def load_for_camera(camera, *, serial_override: str = "",
                     progress_cb=None,
                     on_cache_miss=None) -> CalibrationBundle:
    """Read the MAPIR calibration from a connected LATTICE camera.

    Triton/LATTICE production calibration packs the identity JSON +
    optional zstd-compressed full pack into a single MAPC-framed
    blob in ``UserFile1`` (it's the only writable user file slot on
    this firmware). The pack is multi-MB and the GenICam file-read
    rate over GigE is ~50 KB/s — pulling the full thing on every
    connect adds ~70 s per cam. Stage the read so we can cache-hit
    without paying for the pack body:

        1. Open UserFile1, read the small MAPC header (8 bytes).
        2. Read the identity JSON (typically <1 KB).
        3. Look up the cache by ``serial/sha``. Hit → done, close.
        4. Miss → read the rest of the file (the pack body) and
           extract.

    The first connect of a camera on this machine still pays the
    full read; every subsequent connect skips straight from
    identity → cached bundle in <1 s.
    """
    file_size = _open_userfile_for_read(camera, slot="UserFile1")
    try:
        # Stage 1 — MAPC header (magic + identity_len). Eight bytes,
        # one tiny SDK transaction.
        header = _read_userfile_range(
            camera, slot="UserFile1", offset=0, length=BLOB_HEADER_LEN)
        if header.startswith(BLOB_MAGIC):
            identity_len = int.from_bytes(
                header[len(BLOB_MAGIC):BLOB_HEADER_LEN], "little")
            id_offset = BLOB_HEADER_LEN
            # Stage 2 — identity JSON.
            identity_bytes = _read_userfile_range(
                camera, slot="UserFile1",
                offset=id_offset, length=identity_len)
            pack_offset = id_offset + identity_len
            pack_remaining = max(file_size - pack_offset, 0)
        else:
            # Legacy identity-only blob (no MAPC header). Whole file
            # is the identity JSON; no pack body.
            rest = _read_userfile_range(
                camera, slot="UserFile1",
                offset=BLOB_HEADER_LEN,
                length=max(file_size - BLOB_HEADER_LEN, 0))
            identity_bytes = (header + rest).rstrip(b"\x00")
            pack_offset = file_size
            pack_remaining = 0

        try:
            identity = json.loads(identity_bytes.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "Camera UserFile1 does not contain a MAPIR identity "
                "blob. Camera may be unprogrammed — run "
                f"production_calibration first. Parse error: {exc}"
            )

        serial = serial_override or identity.get("serial", "")
        sha = identity.get("cal_bundle_sha256", "")
        if not serial or not sha:
            raise RuntimeError(
                f"Identity blob is missing serial or sha: {identity!r}"
            )

        cache_dir = CACHE_ROOT / serial / sha
        cache_dir.mkdir(parents=True, exist_ok=True)

        bundle_json: Optional[dict] = None
        manifest: Optional[dict] = None

        bundle_cached = cache_dir / "bundle.json"
        manifest_cached = cache_dir / "compact_manifest.json"
        private_enc_cached = cache_dir / "calibration_private.enc"

        if (identity.get("full_pack_on_camera")
                and pack_remaining > 0):
            if bundle_cached.exists():
                # Stage 3 — cache hit. Skip the multi-MB pack read.
                bundle_json = json.loads(bundle_cached.read_text())
                if manifest_cached.exists():
                    manifest = json.loads(manifest_cached.read_text())
                logger.info(
                    "Cal cache HIT for %s @ %s — skipped "
                    "%d-byte pack pull", serial, sha[:8],
                    pack_remaining)
            else:
                # Stage 4 — cache miss, pull the pack body.
                logger.info(
                    "Cal cache miss for %s @ %s — reading "
                    "%d-byte pack from camera",
                    serial, sha[:8], pack_remaining)
                # Notify the caller a fresh download is starting BEFORE
                # the multi-second pack pull begins. Lets the UI surface
                # a "Downloading new calibration from cam X" toast so
                # the user doesn't think chloros is hung. Caller decides
                # how to render it (SSE event, log line, modal).
                if on_cache_miss is not None:
                    try:
                        on_cache_miss({
                            'serial': serial,
                            'sha': sha,
                            'pack_bytes': int(pack_remaining),
                        })
                    except Exception as exc:
                        logger.warning(
                            "on_cache_miss callback failed: %s", exc)
                pack_bytes = _read_userfile_range(
                    camera, slot="UserFile1",
                    offset=pack_offset, length=pack_remaining,
                    progress_cb=progress_cb)
                expected = identity.get("full_pack_sha256", "")
                if expected and hashlib.sha256(
                        pack_bytes).hexdigest() != expected:
                    raise RuntimeError(
                        "Pack sha mismatch — camera flash may be "
                        "corrupt or the identity blob is stale."
                    )
                files = _extract_pack(pack_bytes, str(cache_dir))
                if bundle_cached.exists():
                    bundle_json = json.loads(bundle_cached.read_text())
                if manifest_cached.exists():
                    manifest = json.loads(manifest_cached.read_text())
                logger.info(
                    "Cached %d files at %s from %d-byte pack",
                    len(files), cache_dir, len(pack_bytes))
                # Successful new-bundle extract — sweep older sibling
                # SHA dirs for this serial. Once the cam reports the
                # new SHA in its identity blob, no future connect can
                # ever cache-hit the old dirs, so they're permanent
                # dead weight (~5 MB each) until removed.
                purged = _purge_orphan_sha_dirs(serial, keep_sha=sha)
                if purged:
                    logger.info(
                        "Removed %d orphan cal dir(s) under %s: %s",
                        len(purged), cache_dir.parent,
                        ', '.join(p[:8] for p in purged))
    finally:
        _close_userfile(camera)

    # Decrypt the private blob (per-serial 3×3 crosstalk matrix)
    # and merge its values into the in-memory bundle. On multi-
    # spectral cameras this is REQUIRED — without it the matrix
    # field is just a ``{"matrix_encrypted": true}`` marker and
    # unmixing silently produces garbage. On mono / RGB cameras
    # the blob is empty by design and the merge is a no-op.
    if bundle_json is not None:
        try:
            from lattice_sdk.bundle_crypto import merge_private_blob_into_bundle
            merge_private_blob_into_bundle(
                bundle_json, private_enc_cached, serial_hint=serial,
            )
        except Exception as exc:
            # Fail loudly if the bundle *says* there's an encrypted
            # matrix but we couldn't decrypt it — silent fallback
            # would mean shipping images with the wrong colour
            # separation.
            if _bundle_needs_matrix(bundle_json):
                raise RuntimeError(
                    f"Calibration for camera {serial!r} references an "
                    f"encrypted spectral-crosstalk matrix that could "
                    f"not be decrypted: {exc}. Check that the Chloros "
                    f"master-secret matches the calibration station that "
                    f"programmed this camera."
                ) from exc
            logger.warning("Private-blob decryption skipped (%s) — "
                            "bundle does not require a matrix.", exc)

    # Also drop a copy of the identity blob for offline inspection.
    (cache_dir / "identity.json").write_text(json.dumps(identity, indent=2))

    return CalibrationBundle(
        identity=identity,
        cache_dir=cache_dir,
        bundle_json=bundle_json,
        compact_manifest=manifest,
    )


# -- Helpers ---------------------------------------------------------------

def _bundle_needs_matrix(bundle_json: Optional[dict]) -> bool:
    """True if the bundle references a 3×3 matrix we must decrypt.

    Looks for the ``matrix_encrypted`` marker we write into
    ``stages.spectral_response.matrices[cam]`` at calibration time.
    Mono / RGB bundles don't have that key and return False — it's
    safe to proceed without a decrypted blob for those.
    """
    if not bundle_json:
        return False
    sr = (bundle_json.get("stages") or {}).get("spectral_response") or {}
    matrices = sr.get("matrices") or {}
    for info in matrices.values():
        if isinstance(info, dict) and info.get("matrix_encrypted"):
            return True
    return False


def _load_json_if_path(p: Any) -> Any:
    if isinstance(p, str) and os.path.exists(p):
        try:
            with open(p) as f:
                return json.load(f)
        except Exception:
            return p
    return p


def _extract_pack(data: bytes, out_dir: str) -> List[str]:
    # Prefer production_calibration's implementation if the repo is
    # sibling-importable, otherwise do a self-contained extraction.
    try:
        _ensure_camera_cal_path()
        from production_calibration.full_pack import extract_full_pack
        return extract_full_pack(data, out_dir)
    except ImportError:
        return _local_extract(data, out_dir)


def _ensure_camera_cal_path() -> None:
    cal = r"C:\Users\MAPIR\Documents\GitHub\camera_calibration"
    if os.path.isdir(cal) and cal not in sys.path:
        sys.path.insert(0, cal)


def _local_extract(data: bytes, out_dir: str) -> List[str]:
    import io
    import tarfile

    # Auto-detect zstd vs gzip
    if data[:4] == b"\x28\xb5\x2f\xfd":
        import zstandard as zstd
        raw = zstd.ZstdDecompressor().decompress(data)
    elif data[:2] == b"\x1f\x8b":
        import gzip
        raw = gzip.decompress(data)
    else:
        raise RuntimeError("Unknown pack compression.")

    os.makedirs(out_dir, exist_ok=True)
    extracted: List[str] = []
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:") as tar:
        for m in tar.getmembers():
            if m.isreg():
                tar.extract(m, out_dir)
                extracted.append(os.path.join(out_dir, m.name))
    return extracted
