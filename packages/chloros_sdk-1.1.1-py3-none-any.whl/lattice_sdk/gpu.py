"""GPU status and capabilities."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class GPUInfo:
    """GPU information and capabilities.

    Attributes:
        available: True if CUDA GPU acceleration is available.
        name: GPU device name (e.g. "NVIDIA Quadro P2000").
        cuda_version: CUDA toolkit version string.
        compute_capability: Compute capability (e.g. "6.1").
        vram_gb: Total VRAM in gigabytes.
        vram_used_mb: Currently allocated VRAM in megabytes.
        pytorch_version: PyTorch version string.
    """
    available: bool = False
    name: str = "CPU (no GPU)"
    cuda_version: str = ""
    compute_capability: str = ""
    vram_gb: float = 0.0
    vram_used_mb: float = 0.0
    pytorch_version: str = ""


def gpu_available() -> bool:
    """Check if CUDA GPU acceleration is available.

    Returns True if PyTorch is installed and a CUDA-capable GPU
    is detected.

    Returns
    -------
    bool

    Examples
    --------
    >>> from lattice_sdk import gpu_available
    >>> if gpu_available():
    ...     print("GPU acceleration enabled")
    """
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False


def gpu_info() -> GPUInfo:
    """Get GPU information and capabilities.

    Returns
    -------
    GPUInfo
        GPU details including name, VRAM, compute capability, etc.

    Examples
    --------
    >>> info = gpu_info()
    >>> print(f"{info.name}: {info.vram_gb:.1f} GB VRAM")
    """
    info = GPUInfo()

    try:
        import torch
        info.pytorch_version = torch.__version__
        info.available = torch.cuda.is_available()

        if info.available:
            info.name = torch.cuda.get_device_name(0)
            info.cuda_version = torch.version.cuda or ""

            props = torch.cuda.get_device_properties(0)
            info.compute_capability = f"{props.major}.{props.minor}"
            info.vram_gb = props.total_memory / (1024 ** 3)
            info.vram_used_mb = torch.cuda.memory_allocated(0) / (1024 ** 2)
    except ImportError:
        pass

    return info
