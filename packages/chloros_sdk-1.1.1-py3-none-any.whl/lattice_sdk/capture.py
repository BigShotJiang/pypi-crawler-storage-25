"""Capture utilities — re-exported with SDK-friendly types."""

from dataclasses import dataclass
from typing import Optional

from lattice_cam.capture import (
    CaptureResult,
    capture_single,
    capture_burst,
)


@dataclass
class CaptureStats:
    """Statistics from a continuous recording session.

    Attributes:
        frames_saved: Number of frames successfully written to disk.
        frames_dropped: Number of frames dropped (writer queue full).
        elapsed: Total recording time in seconds.
        fps: Average frames per second (saved / elapsed).
        output_dir: Path to the output directory.
    """
    frames_saved: int = 0
    frames_dropped: int = 0
    elapsed: float = 0.0
    fps: float = 0.0
    output_dir: str = ""


__all__ = [
    "CaptureResult",
    "CaptureStats",
    "capture_single",
    "capture_burst",
]
