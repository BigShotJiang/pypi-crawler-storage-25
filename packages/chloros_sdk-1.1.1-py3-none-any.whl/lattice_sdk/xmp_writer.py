"""Emit XMP sidecars carrying per-camera radiometric calibration.

Every frame captured from a LATTICE camera gets a ``.xmp`` file written
alongside the image file. The XMP embeds **two** parallel tag sets:

1. **MAPIR native** (``http://mapir.camera/cal/1.0/``, prefix ``mapir``)
   — high-fidelity per-band radiance scalars, 3x3 spectral cross-talk
   matrix, DSNU + linearity parametric models, full bundle sha, NIST
   cert IDs, sensor architecture, the whole payload in one JSON blob.

2. **MicaSense-compatible** (standard EXIF + XMP tag names)
   — minimum set to let third-party tools (Pix4D, Agisoft Metashape,
   community scripts) apply a reasonable radiometric correction from
   the same image. Uses the public MicaSense formula:

        L = V · R · (raw − black_level)
        radiance = L / (gain · exposure_time) · a1 / 2^bits

   Emitted tags:
     - ``EXIF:BlackLevel``         median of our DSNU master offset
     - ``EXIF:ExposureTime``       from camera metadata
     - ``EXIF:ISOSpeed``           100 × 10^(gain_db/20)
     - ``EXIF:BitsPerSample``      from sensor profile
     - ``XMP:RadiometricCalibration``  (a1, a2, a3)
         a1  ← our per-band radiance scalar mapped into MicaSense units
         a2  ← row-gradient exposure-term coefficient (0 for global shutter)
         a3  ← row-gradient row-term coefficient (0 for global shutter)
     - ``XMP:VignettingCenter``, ``XMP:VignettingPolynomial``  (radial)
         or ``XMP:VignettingPolynomial2D`` + ``Exponents``  (2D fallback)

For Bayer cameras we emit the coefficients for the **green** channel as
the MicaSense-compatible a1 (closest analogue to their monochrome-per-
band convention); MAPIR-aware tooling pulls the full per-channel set
from the ``mapir:CalibrationJSON`` payload.

Namespace: ``http://mapir.camera/cal/1.0/``, prefix ``mapir``.

The sidecar filename is ``<image_path>.xmp`` (the Adobe / darktable
convention). For TIFF files, the XMP can also be embedded inline (tag
700) via :func:`embed_xmp_in_tiff`.
"""
from __future__ import annotations

import json
import logging
import math
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

XMP_NS = "http://mapir.camera/cal/1.0/"
SCHEMA_VERSION = "1"


# ── MicaSense-compat coefficient derivation ──────────────────────────────

def _gain_db_to_iso(gain_db: Optional[float], iso_base: int = 100) -> int:
    """Convert our dB gain to MicaSense's ISO convention (gain = ISO/100)."""
    if gain_db is None:
        return iso_base
    return int(round(iso_base * (10.0 ** (float(gain_db) / 20.0))))


def _derive_micasense_a1(scalar_cal: Dict[str, Any],
                          bits_per_pixel: int) -> Tuple[float, Optional[str]]:
    """Map our per-band radiance scalar to MicaSense's a1.

    MicaSense's formula:
        radiance = L / (gain · exposure) · a1 / 2^bits     where L = V·R·(raw − dark)

    Our formula (per channel):
        radiance = scalar × (DN_corrected / exposure)       (at gain = 1.0)

    At equal normalisation: a1 = scalar × gain × 2^bits.
    We emit a1 at gain_linear = 1.0 (i.e. 0 dB), so:
        a1 = scalar × 2^bits_per_pixel

    For Bayer cameras we return the green-channel value (closest single
    number to MicaSense's monochrome-per-band design). For mono
    cameras we return the single channel's value.

    Returns ``(a1, representative_band_name)``. If no radiance scalars
    are present, returns ``(0.0, None)``.
    """
    scalars = scalar_cal.get("radiance_scalars_per_band") or {}
    if not scalars:
        return 0.0, None

    # Prefer a green-ish band (matches MicaSense's broadband green cam).
    band_key = None
    for candidate in ("green", "Gr", "G"):
        if candidate in scalars:
            band_key = candidate
            break
    if band_key is None:
        band_key = next(iter(scalars))

    channels = scalars[band_key] or {}
    if not channels:
        return 0.0, band_key

    # Pick a green/mono channel preferentially; fall back to first.
    ch_key = None
    for candidate in ("Gr", "G", "M"):
        if candidate in channels:
            ch_key = candidate
            break
    if ch_key is None:
        ch_key = next(iter(channels))

    scalar = float(channels.get(ch_key, 0.0))
    a1 = scalar * (2 ** int(bits_per_pixel))
    return a1, f"{band_key}/{ch_key}"


def _derive_black_level(scalar_cal: Dict[str, Any],
                          frame_temp_c: Optional[float] = None) -> float:
    """Median dark-offset DN for EXIF:BlackLevel (MicaSense-compat).

    If an Arrhenius dark model is available AND we know the frame's
    capture temperature, evaluate the model at that temperature so
    MicaSense-compatible tools see a per-frame T-corrected value. This
    keeps the public formula ``L = V · R · (raw − BlackLevel)`` valid
    across field temperature swings.

    Falls back to the parametric-per-gain mean offset when no
    Arrhenius model is present (e.g. for older bundles).
    """
    arr = scalar_cal.get("dsnu_arrhenius") or {}
    ramp = arr.get("ramp_samples") if isinstance(arr, dict) else None
    if arr and ramp and frame_temp_c is not None:
        # Interpolate per-frame spatial-mean dark level from the
        # observed ramp (captures the effect of DC_coeff × exp(-Ea/kT)
        # at the spatial-mean scale, which is what a scalar BlackLevel
        # encodes). Extrapolates flat below the coldest sample and
        # linearly in 1/T_K above the warmest — physics-justified.
        ts = [s["t_c"] for s in ramp]
        vals = [s["frame_mean_dn"] for s in ramp]
        if frame_temp_c <= min(ts):
            return float(vals[0])
        if frame_temp_c >= max(ts):
            return float(vals[-1])
        # Linear interp in T_c — adequate given we're between samples.
        for i in range(len(ts) - 1):
            if ts[i] <= frame_temp_c <= ts[i + 1]:
                t0, t1 = ts[i], ts[i + 1]
                v0, v1 = vals[i], vals[i + 1]
                w = (frame_temp_c - t0) / max(t1 - t0, 1e-6)
                return float(v0 + w * (v1 - v0))

    # Fallback: legacy per-gain parametric offset
    dsnu = scalar_cal.get("dsnu_model") or {}
    per_gain = dsnu.get("per_gain") if isinstance(dsnu, dict) else None
    if not per_gain:
        return 0.0
    gain_entry = per_gain.get("gain_db_0.0") or next(iter(per_gain.values()))
    if not isinstance(gain_entry, dict):
        return 0.0
    offsets = [float(fit["offset_dn"]) for fit in gain_entry.values()
               if isinstance(fit, dict) and "offset_dn" in fit]
    return float(sum(offsets) / len(offsets)) if offsets else 0.0


# ── Vignette polynomial → MicaSense tags ─────────────────────────────────

def _vignette_tags(scalar_cal: Dict[str, Any]) -> Dict[str, str]:
    """Serialise the vignette polynomial into MicaSense XMP format.

    Prefers the radial form; falls back to 2D. Picks the green (or
    mono) channel's fit as the representative one for the compat
    tags. If no fit is present, returns an empty dict.
    """
    poly = scalar_cal.get("vignette_polynomial") or {}
    if not poly:
        return {}

    form = poly.get("form", "radial")

    if form == "radial":
        per_ch = poly.get("per_channel_radial") or {}
        # Preference order for the representative channel.
        for ch in ("G", "Gr", "M", "R", "B"):
            if ch in per_ch:
                fit = per_ch[ch]
                return {
                    "VignettingCenter": f"{fit['centre_x_px']:.3f} {fit['centre_y_px']:.3f}",
                    "VignettingPolynomial": " ".join(
                        f"{c:.6e}" for c in fit.get("polynomial_coeffs", [])
                    ),
                }
        return {}

    if form == "polynomial2d":
        per_ch = poly.get("per_channel_2d") or {}
        for ch in ("G", "Gr", "M", "R", "B"):
            if ch in per_ch:
                fit = per_ch[ch]
                coeffs = " ".join(f"{c:.6e}" for c in fit.get("coefficients", []))
                exps = " ".join(str(e) for e in fit.get("exponents", []))
                return {
                    "VignettingPolynomial2D": coeffs,
                    "VignettingPolynomial2DExponents": exps,
                }
    return {}


# ── Build + write ────────────────────────────────────────────────────────

def build_xmp(*,
              bundle,  # CalibrationBundle
              frame_metadata: Optional[Dict[str, Any]] = None) -> str:
    """Return the XMP XML string for one captured frame."""
    scalar = bundle.scalar_cal()
    frame_metadata = frame_metadata or {}

    # Sensor profile → bits per pixel + iso_base
    sp = scalar.get("sensor_profile") or {}
    bits_per_pixel = int(sp.get("bits_per_pixel", 12))
    iso_base = int(sp.get("iso_base", 100))

    # Row-gradient coefficients for MicaSense-compat a2, a3
    row_grad = scalar.get("row_gradient") or {}
    a2 = float(row_grad.get("a2", 0.0)) if row_grad.get("applicable") else 0.0
    a3 = float(row_grad.get("a3", 0.0)) if row_grad.get("applicable") else 0.0

    a1, a1_band = _derive_micasense_a1(scalar, bits_per_pixel)
    black_level = _derive_black_level(
        scalar,
        frame_temp_c=frame_metadata.get("device_temperature_c"),
    )
    gain_db = frame_metadata.get("gain_db")
    iso_speed = _gain_db_to_iso(gain_db, iso_base)
    vignette_tags = _vignette_tags(scalar)

    # Full MAPIR payload — everything, verbatim.
    payload = {
        "cal": scalar,
        "frame": {
            "captured_utc": frame_metadata.get(
                "captured_utc",
                datetime.now(timezone.utc).isoformat(timespec="microseconds"),
            ),
            "exposure_us": frame_metadata.get("exposure_us"),
            "gain_db": gain_db,
            "device_temperature_c": frame_metadata.get("device_temperature_c"),
            "frame_id": frame_metadata.get("frame_id"),
            "timestamp_ns": frame_metadata.get("timestamp_ns"),
            "pixel_format": frame_metadata.get("pixel_format"),
        },
        "micasense_compat": {
            "a1": a1,
            "a1_representative_band": a1_band,
            "a2": a2,
            "a3": a3,
            "black_level": black_level,
            "iso_speed": iso_speed,
            "bits_per_pixel": bits_per_pixel,
            "vignette_tags": vignette_tags,
            "formula_version": "micasense-public-1",
        },
    }
    payload_json = json.dumps(payload, separators=(",", ":"), sort_keys=False)

    identity = scalar.get("identity", {}) or bundle.identity
    exposure_time_s = (float(frame_metadata.get("exposure_us"))
                        / 1_000_000.0) if frame_metadata.get("exposure_us") else ""

    # Assemble XML. Compat tags come first so EXIF-reading tools find
    # them without parsing the whole RDF.
    vignette_xml = ""
    if "VignettingCenter" in vignette_tags:
        vignette_xml = (
            f"      <mapir:MicaSenseVignettingCenter>"
            f"{_xe(vignette_tags['VignettingCenter'])}"
            f"</mapir:MicaSenseVignettingCenter>\n"
            f"      <mapir:MicaSenseVignettingPolynomial>"
            f"{_xe(vignette_tags['VignettingPolynomial'])}"
            f"</mapir:MicaSenseVignettingPolynomial>\n"
        )
    elif "VignettingPolynomial2D" in vignette_tags:
        vignette_xml = (
            f"      <mapir:MicaSenseVignettingPolynomial2D>"
            f"{_xe(vignette_tags['VignettingPolynomial2D'])}"
            f"</mapir:MicaSenseVignettingPolynomial2D>\n"
            f"      <mapir:MicaSenseVignettingPolynomial2DExponents>"
            f"{_xe(vignette_tags['VignettingPolynomial2DExponents'])}"
            f"</mapir:MicaSenseVignettingPolynomial2DExponents>\n"
        )

    xmp_xml = _XMP_TEMPLATE.format(
        ns=XMP_NS,
        schema_version=SCHEMA_VERSION,
        serial=_xe(identity.get("serial", "")),
        model=_xe(identity.get("model", "")),
        filter_type=_xe(identity.get("filter_type", "")),
        lens_model=_xe(identity.get("lens_model", "")),
        cal_date=_xe(identity.get("cal_date_utc", "")),
        sha=_xe(identity.get("cal_bundle_sha256", "")),
        cert_id=_xe(identity.get("lightbox_cert_id", "")),
        halogen_cert_id=_xe(identity.get("halogen_lamp_cert_id", "")),
        pack_tier=_xe(identity.get("pack_tier", "")),
        sensor_profile_key=_xe(sp.get("profile_key", "")),
        product_line=_xe(sp.get("product_line", "")),
        # MicaSense-compat tags — named exactly as MicaSense publishes
        # them, in a parallel ``mapir`` namespace so they don't clash
        # with the RDF spec but any parser can still find them by name.
        a1=f"{a1:.6e}",
        a2=f"{a2:.6e}",
        a3=f"{a3:.6e}",
        black_level=f"{black_level:.3f}",
        iso_speed=str(iso_speed),
        bits_per_pixel=str(bits_per_pixel),
        exposure_time_s=_xe(exposure_time_s),
        vignette_xml=vignette_xml,
        payload=_xe(payload_json),
    )
    return xmp_xml


def write_xmp_sidecar(image_path: str, *,
                       bundle,
                       frame_metadata: Optional[Dict[str, Any]] = None) -> str:
    """Write ``<image_path>.xmp`` next to the image file."""
    xmp_xml = build_xmp(bundle=bundle, frame_metadata=frame_metadata)
    sidecar = image_path + ".xmp"
    with open(sidecar, "w", encoding="utf-8") as f:
        f.write(xmp_xml)
    return sidecar


def embed_xmp_in_tiff(tiff_path: str, xmp_xml: str) -> None:
    """Rewrite a TIFF so it carries the XMP packet inline (tag 700)."""
    try:
        import tifffile  # type: ignore
    except ImportError:
        logger.warning("tifffile not installed — cannot embed XMP inline.")
        return
    import numpy as np
    img = tifffile.imread(tiff_path)
    tifffile.imwrite(
        tiff_path,
        img,
        photometric="minisblack" if img.ndim == 2 else "rgb",
        extratags=[(700, "B", len(xmp_xml.encode("utf-8")), xmp_xml.encode("utf-8"), True)],
    )


def attach_to_capture_result(result, bundle) -> str:
    """Write a sidecar for a ``lucid_cam.capture.CaptureResult``."""
    frame_metadata = {
        "exposure_us": getattr(result, "exposure_us", None),
        "gain_db": getattr(result, "gain_db", None),
        "device_temperature_c": getattr(result, "device_temperature_c", None),
        "frame_id": getattr(result, "frame_id", None),
        "timestamp_ns": getattr(result, "timestamp_ns", None),
        "pixel_format": getattr(result, "pixel_format", None),
        "captured_utc": getattr(result, "captured_utc", None),
    }
    image_path = getattr(result, "filepath", None) or getattr(result, "path", None)
    if not image_path:
        raise RuntimeError("CaptureResult has no file path to attach XMP to.")
    return write_xmp_sidecar(image_path, bundle=bundle, frame_metadata=frame_metadata)


# ── internals ────────────────────────────────────────────────────────────

def _xe(s: Any) -> str:
    if s is None:
        return ""
    text = str(s)
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    )


_XMP_TEMPLATE = """<?xpacket begin="\ufeff" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="mapir-xmp/{schema_version}">
  <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <rdf:Description rdf:about="" xmlns:mapir="{ns}">
      <mapir:CameraSerial>{serial}</mapir:CameraSerial>
      <mapir:CameraModel>{model}</mapir:CameraModel>
      <mapir:SensorProfile>{sensor_profile_key}</mapir:SensorProfile>
      <mapir:ProductLine>{product_line}</mapir:ProductLine>
      <mapir:FilterType>{filter_type}</mapir:FilterType>
      <mapir:LensModel>{lens_model}</mapir:LensModel>
      <mapir:CalDateUTC>{cal_date}</mapir:CalDateUTC>
      <mapir:CalBundleSha256>{sha}</mapir:CalBundleSha256>
      <mapir:LightboxCertId>{cert_id}</mapir:LightboxCertId>
      <mapir:HalogenLampCertId>{halogen_cert_id}</mapir:HalogenLampCertId>
      <mapir:PackTier>{pack_tier}</mapir:PackTier>
      <mapir:RadiometricCalibration>{a1} {a2} {a3}</mapir:RadiometricCalibration>
      <mapir:BlackLevel>{black_level}</mapir:BlackLevel>
      <mapir:ISOSpeed>{iso_speed}</mapir:ISOSpeed>
      <mapir:BitsPerSample>{bits_per_pixel}</mapir:BitsPerSample>
      <mapir:ExposureTime>{exposure_time_s}</mapir:ExposureTime>
{vignette_xml}      <mapir:CalibrationJSON>{payload}</mapir:CalibrationJSON>
    </rdf:Description>
  </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>
"""
