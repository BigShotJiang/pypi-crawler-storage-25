"""LATTICE Camera SDK — Python SDK for MAPIR LATTICE cameras.

Quick start::

    from lattice_sdk import LatticeCamera, discover_cameras

    # List connected cameras
    cameras = discover_cameras()

    # Open a camera and capture
    with LatticeCamera() as cam:
        frame = cam.grab()
        cam.capture("output.tiff")

See https://github.com/mapir-camera/lattice-sdk for full documentation.
"""

from .__version__ import __version__

from .camera import LatticeCamera
from .discovery import discover_cameras, find_camera, CameraInfo
from .settings import CameraSettings, PRESETS
from .capture import (
    CaptureResult,
    CaptureStats,
    capture_single,
    capture_burst,
)
from .calibration import (
    Calibration,
    CalibrationCoefficients,
    FilterModel,
    list_filters,
)
from .calibration_cache import (
    CalibrationBundle,
    load_for_camera,
    CACHE_ROOT,
)
from .xmp_writer import (
    build_xmp,
    write_xmp_sidecar,
    attach_to_capture_result,
)
from .light_sensor import DLS
from .gpu import GPUInfo, gpu_info, gpu_available
from .firmware import (
    FirmwareStatus,
    check_firmware,
    find_firmware_file,
    firmware_needs_update,
    update_camera_firmware,
    MIN_FIRMWARE_VERSION_STR,
)
from .network import NetworkDiagnostics
from .registration import Registration
from lattice_cam.registration import AlignmentProfile
from .exceptions import (
    LatticeError,
    CameraNotFoundError,
    CameraConnectionError,
    CaptureError,
    CalibrationError,
    StreamError,
    NetworkError,
    DLSError,
    RegistrationError,
)


# Lazy-load .multi — it imports lattice_cam.multi which eagerly pulls
# arena_api via lattice_cam.camera.  Defer until actually accessed.
def __getattr__(name):
    _MULTI_NAMES = {
        "CameraArray", "CameraPool", "SyncGroup", "SyncStats",
        "detect_master", "SyncConfig", "SyncGroupConfig", "SyncMode",
        "MultiContinuousCapture", "MultiCaptureStats",
    }
    if name in _MULTI_NAMES:
        from .multi import (  # noqa: F811
            CameraArray, CameraPool, SyncGroup, SyncStats, detect_master,
            SyncConfig, SyncGroupConfig, SyncMode,
        )
        globals().update({
            "CameraArray": CameraArray,
            "CameraPool": CameraPool,
            "SyncGroup": SyncGroup,
            "SyncStats": SyncStats,
            "detect_master": detect_master,
            "SyncConfig": SyncConfig,
            "SyncGroupConfig": SyncGroupConfig,
            "SyncMode": SyncMode,
        })
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Core
    "LatticeCamera",
    "CameraSettings",
    "PRESETS",
    "discover_cameras",
    "find_camera",
    "CameraInfo",
    # Capture
    "CaptureResult",
    "CaptureStats",
    "capture_single",
    "capture_burst",
    # Calibration
    "Calibration",
    "CalibrationCoefficients",
    "FilterModel",
    "list_filters",
    "CalibrationBundle",
    "load_for_camera",
    "CACHE_ROOT",
    "build_xmp",
    "write_xmp_sidecar",
    "attach_to_capture_result",
    # Light sensor
    "DLS",
    # GPU
    "GPUInfo",
    "gpu_info",
    "gpu_available",
    # Multi-camera
    "CameraArray",
    "CameraPool",
    "SyncGroup",
    "SyncStats",
    "SyncConfig",
    "SyncGroupConfig",
    "SyncMode",
    "detect_master",
    # Firmware
    "FirmwareStatus",
    "check_firmware",
    "find_firmware_file",
    "firmware_needs_update",
    "update_camera_firmware",
    "MIN_FIRMWARE_VERSION_STR",
    # Network
    "NetworkDiagnostics",
    # Registration
    "Registration",
    "AlignmentProfile",
    # Exceptions
    "LatticeError",
    "CameraNotFoundError",
    "CameraConnectionError",
    "CaptureError",
    "CalibrationError",
    "StreamError",
    "NetworkError",
    "DLSError",
    "RegistrationError",
    # Version
    "__version__",
]
