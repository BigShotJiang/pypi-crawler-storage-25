"""Firmware checking and update for LATTICE cameras.

Provides version checking against a minimum required firmware, automatic
discovery of .fwa firmware files, and HTTP-based firmware upload to cameras.

Example::

    from lattice_sdk.firmware import check_firmware, update_camera_firmware

    # Check all connected cameras
    results = check_firmware()
    for r in results:
        print(f"{r.serial}: {r.current_version} {'NEEDS UPDATE' if r.needs_update else 'OK'}")

    # Update a specific camera
    update_camera_firmware("169.254.8.21", force=False)
"""

import socket
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# Minimum firmware version for full feature support
# (Line2 TriggerSource for GPIO sync, etc.)
MIN_FIRMWARE_VERSION = (1, 163, 0, 0)
MIN_FIRMWARE_VERSION_STR = ".".join(str(v) for v in MIN_FIRMWARE_VERSION)

# Firmware directory relative to the repo root
_REPO_ROOT = Path(__file__).resolve().parent.parent
FIRMWARE_DIR = _REPO_ROOT / "firmware"


def parse_firmware_version(version_str: str) -> tuple:
    """Parse a firmware version string like '1.163.0.0' into a comparable tuple."""
    try:
        return tuple(int(x) for x in version_str.strip().split("."))
    except (ValueError, AttributeError):
        return (0,)


def firmware_needs_update(version_str: str) -> bool:
    """Return True if the given firmware version is below the minimum."""
    return parse_firmware_version(version_str) < MIN_FIRMWARE_VERSION


@dataclass
class FirmwareStatus:
    """Firmware status for a single camera."""
    serial: str
    model: str
    ip: str
    current_version: str
    needs_update: bool
    available_version: Optional[str] = None
    available_file: Optional[Path] = None


def find_firmware_file(model_name: str) -> tuple[Optional[Path], Optional[str]]:
    """Find the best .fwa firmware file for a camera model.

    Searches ``firmware/<MODEL_PREFIX>/`` for the highest-version .fwa file.
    For TRI032S-C, looks in ``firmware/TRI032S/``.

    Returns:
        (path_to_fwa, version_string) or (None, None) if not found.
    """
    prefix = model_name.split("-")[0] if "-" in model_name else model_name
    fw_dir = FIRMWARE_DIR / prefix

    if not fw_dir.is_dir():
        return None, None

    best_file = None
    best_version = (0,)
    for fwa in fw_dir.glob("*.fwa"):
        parts = fwa.stem.split("_", 1)
        if len(parts) == 2:
            ver = parse_firmware_version(parts[1])
            if ver > best_version:
                best_version = ver
                best_file = fwa

    if best_file:
        return best_file, ".".join(str(v) for v in best_version)
    return None, None


def check_firmware(serial: Optional[str] = None) -> list[FirmwareStatus]:
    """Check firmware on all connected cameras.

    Discovers cameras, reads their firmware versions, and checks against
    the minimum required version.

    Args:
        serial: If provided, only check this specific camera.

    Returns:
        List of FirmwareStatus objects.
    """
    from arena_api.system import system
    from lattice_cam.camera import discover_with_recovery

    infos = discover_with_recovery(verbose=False)
    if not infos:
        return []

    devices = system.create_device()
    results = []

    try:
        for d in devices:
            try:
                sn = str(d.nodemap.get_node("DeviceSerialNumber").value)
                if serial and sn != serial:
                    continue
                fw = str(d.nodemap.get_node("DeviceFirmwareVersion").value).strip()
                model = str(d.nodemap.get_node("DeviceModelName").value).strip()

                ip = ""
                for info in infos:
                    if info.get("serial") == sn:
                        ip = info.get("ip", "")
                        break

                fwa_path, fwa_ver = find_firmware_file(model)

                results.append(FirmwareStatus(
                    serial=sn,
                    model=model,
                    ip=ip,
                    current_version=fw,
                    needs_update=firmware_needs_update(fw),
                    available_version=fwa_ver,
                    available_file=fwa_path,
                ))
            except Exception:
                pass
    finally:
        system.destroy_device()

    return results


def _raw_http_get_status(ip: str, timeout: float = 5.0) -> Optional[str]:
    """GET /upload_status via a raw socket.

    The LATTICE camera firmware replies in HTTP/0.9 style (body only, no status
    line) when an upload is in progress, which urllib refuses to parse.
    This helper reads whatever bytes come back and returns them as a
    best-effort string, or ``None`` if the connection fails.
    """
    try:
        with socket.create_connection((ip, 80), timeout=timeout) as sock:
            req = (
                f"GET /upload_status HTTP/1.0\r\n"
                f"Host: {ip}\r\n"
                f"Connection: close\r\n"
                f"\r\n"
            ).encode("ascii")
            sock.sendall(req)
            sock.settimeout(timeout)
            buf = bytearray()
            while True:
                try:
                    chunk = sock.recv(4096)
                except socket.timeout:
                    break
                if not chunk:
                    break
                buf.extend(chunk)
                if len(buf) >= 8192:
                    break
    except Exception:
        return None

    body = bytes(buf).decode("utf-8", errors="replace")
    # Strip any HTTP/1.x status + headers if the camera sent them.
    if body.startswith("HTTP/"):
        sep = body.find("\r\n\r\n")
        if sep != -1:
            body = body[sep + 4:]
    return body


def upload_firmware(ip: str, fwa_path: Path, timeout: int = 300) -> bool:
    """Upload .fwa firmware to a camera via its built-in HTTP interface.

    Uses the camera's native upload protocol over a raw socket:
      POST /upload_status with raw binary body,
      Content-Type: file-upload, upload_file: <filename>

    The camera replies in HTTP/0.9 style during the upload and during
    status polling, so we cannot use urllib (BadStatusLine). We write
    the request + body on a single socket, ignore the immediate reply,
    then poll ``/upload_status`` with the same raw technique to track
    progress through Analyzing/Erasing/Writing phases. Completion is
    detected when the status page starts returning empty after having
    shown progress — that is the camera rebooting. ``wait_for_camera``
    should be called after this returns to confirm the reboot finished.

    Args:
        ip: Camera IP address.
        fwa_path: Path to the .fwa firmware file.
        timeout: Socket timeout in seconds for the POST.

    Returns:
        True if the camera signalled a successful flash (either by
        reporting Success/Complete or by going through a reboot cycle
        after progress was observed). False on transport errors or
        explicit failure responses.
    """
    fwa = Path(fwa_path)
    firmware_data = fwa.read_bytes()

    header = (
        f"POST /upload_status HTTP/1.1\r\n"
        f"Host: {ip}\r\n"
        f"Content-Type: file-upload\r\n"
        f"upload_file: {fwa.name}\r\n"
        f"Content-Length: {len(firmware_data)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    ).encode("ascii")

    try:
        with socket.create_connection((ip, 80), timeout=timeout) as sock:
            sock.sendall(header)
            sock.sendall(firmware_data)
            # Drain any immediate reply so the camera sees a clean close.
            # HTTP/0.9 body or HTTP/1.1 short response — we don't care.
            sock.settimeout(10)
            try:
                sock.recv(4096)
            except Exception:
                pass
    except Exception:
        return False

    # Poll upload status via raw socket. Watch for either an explicit
    # success/failure token, or a reboot cycle after we've seen the
    # Writing/Erasing/Analyzing phases.
    saw_progress = False
    empty_streak = 0
    for _ in range(90):  # up to ~4.5 minutes
        time.sleep(3)
        status = _raw_http_get_status(ip, timeout=5.0)
        if status is None:
            # Connection refused / rebooting — count toward empty streak
            # only after we saw real progress.
            if saw_progress:
                empty_streak += 1
                if empty_streak >= 2:
                    return True
            continue

        stripped = status.strip()
        if not stripped:
            if saw_progress:
                empty_streak += 1
                if empty_streak >= 2:
                    return True
            continue

        empty_streak = 0
        if "Success" in stripped or "Complete" in stripped:
            return True
        if "Failure" in stripped or "Error" in stripped:
            return False
        # Anything else (Analyzing / Erasing / Writing N%) is live progress.
        saw_progress = True

    return saw_progress


def wait_for_camera(ip: str, timeout: int = 600) -> bool:
    """Poll until camera HTTP interface comes back online after reboot.

    Defaults to 10 min — TRI032S boot can take several minutes on
    some firmware versions, and raising the cap costs nothing when
    the camera actually comes back fast.

    Args:
        ip: Camera IP address.
        timeout: Maximum wait time in seconds.

    Returns:
        True if the camera came back online within the timeout.
    """
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen("http://%s/" % ip, timeout=5) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(5)
    return False


def verify_firmware_is_current(
    serial: str,
    *,
    timeout: int = 300,
    poll_every_s: float = 10.0,
) -> Optional["FirmwareStatus"]:
    """Retry ``check_firmware(serial=...)`` until the camera reports the
    new firmware version, or ``timeout`` elapses.

    After a flash the camera re-enumerates on the link-local subnet and
    may briefly report the old version (or not be discoverable at all)
    before GenICam settles. The CLI's one-shot post-verify has seen
    both false negatives — that's why we poll.

    Args:
        serial: Camera serial to watch for.
        timeout: Total seconds to keep retrying.
        poll_every_s: Seconds between ``check_firmware`` calls.

    Returns:
        The final ``FirmwareStatus`` (``needs_update=False`` on success,
        ``True`` on genuine failure), or ``None`` if the camera never
        re-appeared within ``timeout``.
    """
    start = time.time()
    last: Optional[FirmwareStatus] = None
    while time.time() - start < timeout:
        try:
            results = check_firmware(serial=serial)
        except Exception:
            results = []
        if results:
            last = results[0]
            if not last.needs_update:
                return last
        time.sleep(poll_every_s)
    return last


def update_camera_firmware(ip: str, fwa_path: Path,
                           timeout: int = 300,
                           wait_timeout: int = 180) -> bool:
    """Upload firmware and wait for camera to reboot.

    Args:
        ip: Camera IP address.
        fwa_path: Path to the .fwa firmware file.
        timeout: HTTP upload timeout in seconds.
        wait_timeout: Time to wait for camera to come back online.

    Returns:
        True if the update completed successfully.
    """
    if not upload_firmware(ip, fwa_path, timeout):
        return False
    time.sleep(10)
    return wait_for_camera(ip, wait_timeout)
