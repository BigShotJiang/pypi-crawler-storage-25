"""GigE network diagnostics and configuration.

Cross-platform network adapter diagnostics for optimal GigE Vision
camera performance. Supports Windows and Linux.

Example::

    from lattice_sdk import NetworkDiagnostics

    diag = NetworkDiagnostics()
    issues = diag.check()
    if issues:
        print("Network issues found:")
        for issue in issues:
            print(f"  - {issue}")
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple

from .exceptions import NetworkError


@dataclass
class AdapterInfo:
    """Network adapter information.

    Attributes:
        name: Adapter or interface name.
        mtu: Current MTU setting.
        connected: True if the cable is connected.
        driver: Driver name (Linux) or registry key (Windows).
        link_speed: Link speed string (e.g. "1000 Mbps").
        jumbo_enabled: True if jumbo frames are enabled (MTU >= 9000).
    """
    name: str = ""
    mtu: Optional[int] = None
    connected: bool = False
    driver: str = ""
    link_speed: str = ""
    jumbo_enabled: bool = False


@dataclass
class BandwidthEstimate:
    """Bandwidth and FPS estimate for a camera setup.

    Attributes:
        fps_per_camera: Estimated FPS per camera.
        total_bandwidth_mb: Total bandwidth in MB/s.
        link_limited: True if the link is the bottleneck.
        pixel_format: Pixel format used for the estimate.
        num_cameras: Number of cameras.
        jumbo_frames: Whether jumbo frames are assumed.
    """
    fps_per_camera: float = 0.0
    total_bandwidth_mb: float = 0.0
    link_limited: bool = False
    pixel_format: str = "BayerRG8"
    num_cameras: int = 1
    jumbo_frames: bool = True


class NetworkDiagnostics:
    """GigE Vision network diagnostics and configuration.

    Checks network adapter settings and provides recommendations
    for optimal GigE Vision camera throughput.

    Works on both Windows and Linux.

    Examples
    --------
    Check for issues::

        diag = NetworkDiagnostics()
        issues = diag.check()

    Fix settings (requires admin/root)::

        diag = NetworkDiagnostics()
        diag.fix()

    Bandwidth estimates::

        est = diag.estimate_bandwidth(
            num_cameras=2,
            pixel_format="BayerRG12")
        print(f"{est.fps_per_camera} FPS/camera")
    """

    def check(self, verbose: bool = False) -> List[str]:
        """Check NIC configuration and return a list of issues.

        Parameters
        ----------
        verbose : bool
            If True, print diagnostic details to stdout.

        Returns
        -------
        list of str
            Issue descriptions. Empty list if all settings are optimal.
        """
        from lattice_cam.netsetup import diagnose
        _, issues = diagnose(verbose=verbose)
        return issues

    def adapters(self) -> List[AdapterInfo]:
        """List detected network adapters.

        Returns
        -------
        list of AdapterInfo
        """
        from lattice_cam.netsetup import find_ethernet_adapters

        raw = find_ethernet_adapters()
        result = []
        for a in raw:
            mtu = a.interface_mtu
            result.append(AdapterInfo(
                name=a.name,
                mtu=mtu,
                connected=a.media_connected,
                driver=a.driver or a.registry_key,
                link_speed=a.link_speed,
                jumbo_enabled=(mtu is not None and mtu >= 9000),
            ))
        return result

    def fix(self) -> bool:
        """Apply optimal NIC settings.

        Requires Administrator (Windows) or root (Linux) privileges.

        Returns
        -------
        bool
            True if all settings were applied successfully.
        """
        from lattice_cam.netsetup import fix_settings
        return fix_settings()

    def estimate_bandwidth(self,
                           num_cameras: int = 1,
                           pixel_format: str = "BayerRG8",
                           jumbo: bool = True) -> BandwidthEstimate:
        """Estimate bandwidth and FPS for a camera configuration.

        Parameters
        ----------
        num_cameras : int
            Number of cameras sharing the link.
        pixel_format : str
            Pixel format (affects bytes per pixel).
        jumbo : bool
            Whether jumbo frames are enabled.

        Returns
        -------
        BandwidthEstimate
        """
        from lattice_cam.netsetup import bandwidth_estimate

        fps, bw, limited = bandwidth_estimate(
            num_cameras, pixel_format, jumbo)
        return BandwidthEstimate(
            fps_per_camera=fps,
            total_bandwidth_mb=bw,
            link_limited=limited,
            pixel_format=pixel_format,
            num_cameras=num_cameras,
            jumbo_frames=jumbo,
        )

    def probe(self,
              pixel_format: str = "BayerRG12",
              discover_cameras: bool = True) -> dict:
        """Analyze system hardware and recommend optimal camera configuration.

        Detects NICs, USB controllers, connected cameras, and their
        topology to recommend the ideal hardware setup.

        Parameters
        ----------
        pixel_format : str
            Pixel format for bandwidth calculations.
        discover_cameras : bool
            If True, discover cameras on the network.

        Returns
        -------
        dict
            Probe results including NICs, cameras, topology,
            bandwidth estimates, warnings, and recommendations.
        """
        from lattice_cam.system_probe import probe_system
        result = probe_system(
            pixel_format=pixel_format,
            discover_cameras=discover_cameras,
        )
        return result.to_dict()

    def probe_report(self,
                     pixel_format: str = "BayerRG12",
                     discover_cameras: bool = True) -> str:
        """Run a system probe and return a formatted text report.

        Parameters
        ----------
        pixel_format : str
            Pixel format for bandwidth calculations.
        discover_cameras : bool
            If True, discover cameras on the network.

        Returns
        -------
        str
            Human-readable probe report.
        """
        from lattice_cam.system_probe import probe_system, format_probe_report
        result = probe_system(
            pixel_format=pixel_format,
            discover_cameras=discover_cameras,
        )
        return format_probe_report(result)
