"""DLS (Downwelling Light Sensor) — DAQ-M BLE spectral sensor integration.

Provides access to the DAQ-M spectral light sensor for downwelling
irradiance measurement and illumination correction.

Example::

    from lattice_sdk import DLS

    with DLS() as dls:
        reading = dls.acquire()
        print(f"Red irradiance: {reading.irradiance_red}")
        print(f"Spectrum: {reading.wavelengths.shape} points")
"""

import time
from dataclasses import dataclass
from typing import Optional

import numpy as np

from .exceptions import DLSError

# Default BLE MAC address for the DAQ-M sensor
DEFAULT_MAC = "EC:4C:E9:15:3E:D2"


@dataclass
class SpectrumReading:
    """A spectral measurement from the DLS sensor.

    Attributes:
        wavelengths: Array of wavelengths in nm (typically 135 points,
            340-1010 nm at 5 nm spacing).
        intensities: Spectral intensity array (same length as wavelengths).
        integration_time: Sensor integration time in milliseconds.
        is_saturated: True if the sensor was saturated.
        irradiance_red: Interpolated irradiance at the red filter wavelength.
        irradiance_green: Interpolated irradiance at the green filter wavelength.
        irradiance_nir: Interpolated irradiance at the NIR filter wavelength.
        timestamp: Unix timestamp of the reading.
    """
    wavelengths: np.ndarray
    intensities: np.ndarray
    integration_time: float = 0.0
    is_saturated: bool = False
    irradiance_red: float = 0.0
    irradiance_green: float = 0.0
    irradiance_nir: float = 0.0
    timestamp: float = 0.0


class DLS:
    """Interface to the DAQ-M downwelling light sensor.

    Connects via BLE (Bluetooth Low Energy) to the spectral sensor
    and provides spectrum readings for illumination correction.

    Parameters
    ----------
    mac_address : str
        BLE MAC address of the sensor (default: EC:4C:E9:15:3E:D2).
    filter_model : str
        Filter model name for band irradiance calculation
        (default: "RGN-IMX265").

    Examples
    --------
    Context manager::

        with DLS() as dls:
            reading = dls.acquire()
            print(f"Red: {reading.irradiance_red:.4f}")

    Explicit lifecycle::

        dls = DLS()
        dls.connect()
        reading = dls.acquire()
        dls.disconnect()

    Custom MAC address::

        with DLS(mac_address="AA:BB:CC:DD:EE:FF") as dls:
            reading = dls.acquire()

    Raises
    ------
    DLSError
        If bleak is not installed, or connection/acquisition fails.
    """

    def __init__(self, mac_address: str = DEFAULT_MAC,
                 filter_model: str = "RGN-IMX265"):
        self._mac = mac_address
        self._filter_model = filter_model
        self._sensor = None

    def connect(self, timeout: float = 15.0) -> "DLS":
        """Connect to the DLS sensor via BLE.

        Parameters
        ----------
        timeout : float
            Connection timeout in seconds (default: 15).

        Returns
        -------
        self

        Raises
        ------
        DLSError
            If bleak is not installed or connection fails.
        """
        try:
            from lattice_cam.light_sensor import LightSensor
        except ImportError:
            raise DLSError(
                "DLS requires the 'bleak' package. "
                "Install with: pip install bleak>=0.21.0")

        self._sensor = LightSensor(mac_address=self._mac)

        # Set filter wavelengths for irradiance interpolation
        from .calibration import _resolve_filter
        ftype = _resolve_filter(self._filter_model)
        self._sensor.set_filter_wavelengths(ftype)

        self._sensor.connect()

        # Wait for connection
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self._sensor.status.connected:
                return self
            time.sleep(0.5)

        self._sensor.disconnect()
        self._sensor = None
        raise DLSError(f"Connection timed out after {timeout}s")

    def disconnect(self) -> None:
        """Disconnect from the DLS sensor."""
        if self._sensor is not None:
            self._sensor.disconnect()
            self._sensor = None

    @property
    def is_connected(self) -> bool:
        """True if the sensor is connected."""
        if self._sensor is None:
            return False
        return self._sensor.status.connected

    def acquire(self, timeout: float = 10.0) -> SpectrumReading:
        """Acquire a spectrum reading.

        Waits for the next spectrum reading from the sensor.
        The sensor automatically acquires spectra approximately
        every 2 seconds.

        Parameters
        ----------
        timeout : float
            Timeout in seconds (default: 10).

        Returns
        -------
        SpectrumReading
            The acquired spectrum with wavelengths, intensities,
            and per-band irradiance values.

        Raises
        ------
        DLSError
            If not connected or acquisition times out.
        """
        if self._sensor is None:
            raise DLSError("Not connected. Call connect() first.")

        t0 = time.time()
        while time.time() - t0 < timeout:
            reading = self._sensor.latest_reading
            if reading is not None:
                return SpectrumReading(
                    wavelengths=reading.wavelengths,
                    intensities=reading.intensities,
                    integration_time=reading.integration_time,
                    is_saturated=reading.is_saturated,
                    irradiance_red=reading.irradiance_red,
                    irradiance_green=reading.irradiance_green,
                    irradiance_nir=reading.irradiance_nir,
                    timestamp=reading.timestamp,
                )
            time.sleep(0.5)

        raise DLSError(f"No spectrum reading within {timeout}s")

    @property
    def latest(self) -> Optional[SpectrumReading]:
        """The most recent spectrum reading, or None.

        Non-blocking. Returns None if no reading is available yet.
        """
        if self._sensor is None:
            return None
        reading = self._sensor.latest_reading
        if reading is None:
            return None
        return SpectrumReading(
            wavelengths=reading.wavelengths,
            intensities=reading.intensities,
            integration_time=reading.integration_time,
            is_saturated=reading.is_saturated,
            irradiance_red=reading.irradiance_red,
            irradiance_green=reading.irradiance_green,
            irradiance_nir=reading.irradiance_nir,
            timestamp=reading.timestamp,
        )

    def band_magnitudes(self, spectrum: SpectrumReading = None
                        ) -> dict:
        """Compute per-band integrated magnitudes.

        Integrates the spectrum through each filter channel's
        transmission curve.

        Parameters
        ----------
        spectrum : SpectrumReading, optional
            Spectrum to use. If None, uses the latest reading.

        Returns
        -------
        dict
            Keys: "red", "green", "nir". Values: float magnitudes.
        """
        if spectrum is None:
            spectrum = self.latest
            if spectrum is None:
                raise DLSError("No spectrum available")

        from lattice_cam.calibration import compute_band_magnitudes
        from .calibration import _resolve_filter
        ftype = _resolve_filter(self._filter_model)
        mags = compute_band_magnitudes(spectrum.intensities, ftype)
        return {"red": mags[0], "green": mags[1], "nir": mags[2]}

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False
