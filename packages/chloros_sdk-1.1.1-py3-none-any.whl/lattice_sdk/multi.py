"""Multi-camera management — SDK wrapper.

Re-exports CameraArray (GPIO-sync) and provides CameraPool
(independent, unlimited cameras without hardware synchronization).
"""

from typing import Dict, List, Optional

from lattice_cam.multi import (
    CameraArray, SyncGroup, SyncStats, detect_master,
    MultiContinuousCapture, MultiCaptureStats,
)
from lattice_cam.sync_config import SyncConfig, SyncGroupConfig, SyncMode
from lattice_cam.processing import (
    ProcessingTier, ProcessingConfig, get_processing_config,
)

from .camera import LatticeCamera
from .capture import CaptureResult
from .discovery import discover_cameras
from .settings import CameraSettings, PRESETS

__all__ = [
    "CameraArray", "SyncGroup", "SyncStats", "detect_master",
    "MultiContinuousCapture", "MultiCaptureStats",
    "SyncConfig", "SyncGroupConfig", "SyncMode",
    "ProcessingTier", "ProcessingConfig", "get_processing_config",
    "CameraPool",
]


class CameraPool:
    """Manages unlimited independent cameras without GPIO synchronization.

    Unlike :class:`CameraArray` which requires GPIO wiring for hardware-
    synchronized capture, ``CameraPool`` manages any number of cameras
    independently. Each camera can be configured and operated separately.

    Works on Windows, Linux AMD64, and Linux ARM64 — anywhere the
    Arena SDK is available.

    Examples
    --------
    Connect all cameras on the network::

        pool = CameraPool()
        pool.discover_and_connect_all()
        print(f"Connected: {pool.count} cameras")

    Connect specific cameras by serial::

        pool = CameraPool()
        pool.connect(serial="12345")
        pool.connect(serial="67890")

    Apply settings and capture::

        pool.apply_settings_all(exposure=10000, gain=0)
        results = pool.capture_all(output_dir="output")
    """

    def __init__(self):
        self._cameras: Dict[str, LatticeCamera] = {}

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.disconnect_all()

    def __len__(self):
        return len(self._cameras)

    def __contains__(self, serial: str):
        return serial in self._cameras

    def __iter__(self):
        return iter(self._cameras.values())

    # -- Discovery & Connection ------------------------------------------------

    def discover_and_connect_all(self, preset: str = None,
                                 serials: List[str] = None,
                                 settings: CameraSettings = None,
                                 ) -> List[str]:
        """Discover cameras on the network and connect all (or a subset).

        Parameters
        ----------
        preset : str, optional
            Preset name to apply on connection (e.g. "default").
        serials : list of str, optional
            If given, only connect cameras matching these serial numbers.
            If None, connect all discovered cameras.
        settings : CameraSettings, optional
            Initial settings to apply after connection.

        Returns
        -------
        list of str
            Serial numbers of newly connected cameras.
        """
        discovered = discover_cameras()
        connected = []
        for info in discovered:
            sn = info.serial
            if sn in self._cameras:
                continue
            if serials is not None and sn not in serials:
                continue
            try:
                sn = self.connect(serial=sn, preset=preset, settings=settings)
                connected.append(sn)
            except Exception:
                pass
        return connected

    def connect(self, serial: str = None, device_index: int = 0,
                preset: str = None,
                settings: CameraSettings = None) -> str:
        """Connect to a single camera and add it to the pool.

        Parameters
        ----------
        serial : str, optional
            Serial number. If not given, uses device_index.
        device_index : int
            Device index (used if serial is None).
        preset : str, optional
            Preset name to apply on connection.
        settings : CameraSettings, optional
            Initial settings to apply after connection.

        Returns
        -------
        str
            Serial number of the connected camera.
        """
        cam = LatticeCamera(
            device_index=device_index,
            preset=preset,
            serial=serial,
            settings=settings,
        )
        cam.connect()
        sn = cam.device_info.serial
        self._cameras[sn] = cam
        return sn

    def disconnect(self, serial: str) -> None:
        """Disconnect a specific camera and remove from pool."""
        cam = self._cameras.pop(serial, None)
        if cam is not None:
            try:
                cam.disconnect()
            except Exception:
                pass

    def disconnect_all(self) -> None:
        """Disconnect all cameras in the pool."""
        for serial in list(self._cameras.keys()):
            self.disconnect(serial)

    # -- Access ----------------------------------------------------------------

    def get(self, serial: str) -> LatticeCamera:
        """Get a camera by serial number.

        Raises
        ------
        KeyError
            If the serial is not in the pool.
        """
        cam = self._cameras.get(serial)
        if cam is None:
            raise KeyError(f"Camera {serial} not in pool")
        return cam

    @property
    def serials(self) -> List[str]:
        """List of all connected camera serial numbers."""
        return list(self._cameras.keys())

    @property
    def count(self) -> int:
        """Number of connected cameras."""
        return len(self._cameras)

    # -- Settings --------------------------------------------------------------

    def apply_settings(self, serial: str, **kwargs) -> None:
        """Apply settings to a specific camera.

        Parameters
        ----------
        serial : str
            Camera serial number.
        **kwargs
            Setting key-value pairs. Supported keys:
            exposure, gain, auto_exposure, auto_gain,
            pixel_format, resolution (dict with width/height),
            preset, target_brightness.
        """
        cam = self.get(serial)
        self._apply(cam, kwargs)

    def apply_settings_all(self, **kwargs) -> None:
        """Apply the same settings to all cameras in the pool."""
        for cam in self._cameras.values():
            self._apply(cam, kwargs)

    @staticmethod
    def _apply(cam: LatticeCamera, settings: dict) -> None:
        if 'exposure' in settings:
            cam.set_exposure(settings['exposure'])
        if 'auto_exposure' in settings:
            cam.set_auto_exposure(settings['auto_exposure'])
        if 'gain' in settings:
            cam.set_gain(settings['gain'])
        if 'auto_gain' in settings:
            cam.set_auto_gain(settings['auto_gain'])
        if 'target_brightness' in settings:
            cam.set_brightness(settings['target_brightness'])
        if 'pixel_format' in settings:
            cam.set_format(settings['pixel_format'])
        if 'resolution' in settings:
            res = settings['resolution']
            cam.set_resolution(res['width'], res['height'],
                               res.get('offset_x'), res.get('offset_y'))
        if 'preset' in settings:
            cam.apply_preset(settings['preset'])

    # -- Capture ---------------------------------------------------------------

    def capture(self, serial: str, output_dir: str = "output",
                format: str = "tiff") -> CaptureResult:
        """Capture a single frame from a specific camera."""
        cam = self.get(serial)
        return cam.capture(output_dir=output_dir, format=format)

    def capture_all(self, output_dir: str = "output",
                    format: str = "tiff") -> List[CaptureResult]:
        """Capture a single frame from every camera in the pool."""
        results = []
        for serial, cam in self._cameras.items():
            results.append(cam.capture(output_dir=output_dir, format=format))
        return results

    def burst(self, serial: str, count: int = 5,
              output_dir: str = "output",
              format: str = "tiff") -> list:
        """Capture a burst from a specific camera."""
        cam = self.get(serial)
        return cam.capture_burst(count=count, output_dir=output_dir,
                                 format=format)

    def burst_all(self, count: int = 5, output_dir: str = "output",
                  format: str = "tiff") -> Dict[str, list]:
        """Capture a burst from every camera."""
        results = {}
        for serial, cam in self._cameras.items():
            results[serial] = cam.capture_burst(
                count=count, output_dir=output_dir, format=format)
        return results

    # -- Streaming -------------------------------------------------------------

    def start_streams(self) -> None:
        """Start acquisition streams on all cameras."""
        for cam in self._cameras.values():
            cam.start_stream()

    def stop_streams(self) -> None:
        """Stop acquisition streams on all cameras."""
        for cam in self._cameras.values():
            try:
                cam.stop_stream()
            except Exception:
                pass
