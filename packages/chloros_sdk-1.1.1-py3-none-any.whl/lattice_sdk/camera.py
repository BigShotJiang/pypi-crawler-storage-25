"""LatticeCamera — main SDK class for controlling LATTICE cameras.

Example::

    from lattice_sdk import LatticeCamera

    with LatticeCamera() as cam:
        # Configure
        cam.set_exposure(15000)
        cam.set_gain(0)
        cam.set_format("BayerRG12")

        # Grab frames
        frame = cam.grab()                    # numpy BGR array
        frame, meta = cam.grab_with_metadata()

        # Capture to disk
        result = cam.capture("output.tiff")
        results = cam.capture_burst(count=5)
"""

import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

import numpy as np

from .exceptions import (
    CameraConnectionError,
    CameraNotFoundError,
    CaptureError,
    StreamError,
)
from .settings import CameraSettings, PRESETS


@dataclass
class DeviceInfo:
    """Camera device information.

    Attributes:
        model: Camera model name (hardware — e.g. "TRI032S").
        serial: Serial number string.
        firmware: Firmware version string.
        temperature: Sensor temperature in Celsius (or None).
        lattice_model: LATTICE model from DeviceUserID — e.g. "M3C-L41-FRGN".
        ip: Camera IP address (from arena discovery, not a node read).
    """
    model: str = ""
    serial: str = ""
    firmware: str = ""
    temperature: Optional[float] = None
    lattice_model: str = ""
    ip: str = ""


@dataclass
class FrameMetadata:
    """Per-frame hardware metadata from camera chunk data.

    These values are read from the camera's on-board metadata
    attached to each frame buffer. They reflect the actual hardware
    state at the moment of capture, which may differ from the
    requested settings (e.g. when auto-exposure is active).

    Attributes:
        frame_id: Sequential frame counter from the camera.
        timestamp_ns: Hardware timestamp in nanoseconds.
        exposure_us: Actual exposure time in microseconds.
        gain_db: Actual gain in dB.
        black_level: Sensor black level.
        crc: Frame CRC for integrity verification.
        width: Frame width in pixels.
        height: Frame height in pixels.
        pixel_format: Pixel format string (e.g. "BayerRG12").
    """
    frame_id: Optional[int] = None
    timestamp_ns: Optional[int] = None
    exposure_us: Optional[float] = None
    gain_db: Optional[float] = None
    black_level: Optional[float] = None
    crc: Optional[int] = None
    width: int = 0
    height: int = 0
    pixel_format: str = ""


def _meta_from_dict(d: dict) -> FrameMetadata:
    """Convert internal metadata dict to FrameMetadata."""
    return FrameMetadata(
        frame_id=d.get("frame_id"),
        timestamp_ns=d.get("timestamp_ns"),
        exposure_us=d.get("exposure_time_us"),
        gain_db=d.get("gain_db"),
        black_level=d.get("black_level"),
        crc=d.get("crc"),
        width=d.get("width", 0),
        height=d.get("height", 0),
        pixel_format=d.get("pixel_format", ""),
    )


class LatticeCamera:
    """Control a LATTICE camera.

    Provides a clean, high-level API for camera configuration, frame
    acquisition, and capture. Use as a context manager for automatic
    resource cleanup.

    Parameters
    ----------
    device_index : int
        Camera index (0 for the first camera, 1 for the second, etc.).
    settings : CameraSettings, optional
        Initial camera settings. If None, uses defaults (BayerRG12,
        auto-exposure, 0 dB gain).
    preset : str, optional
        Apply a named preset: ``"default"``, ``"high_speed"``,
        ``"high_quality"``, or ``"triggered"``.

    Examples
    --------
    Basic usage with context manager::

        with LatticeCamera() as cam:
            frame = cam.grab()

    With explicit connect/disconnect::

        cam = LatticeCamera(device_index=0)
        cam.connect()
        frame = cam.grab()
        cam.disconnect()

    With a preset::

        with LatticeCamera(preset="high_quality") as cam:
            result = cam.capture("output.tiff")

    Raises
    ------
    CameraNotFoundError
        If no camera is found at the specified index.
    CameraConnectionError
        If the camera cannot be opened.
    """

    def __init__(self, device_index: int = 0,
                 settings: Optional[CameraSettings] = None,
                 preset: Optional[str] = None,
                 serial: Optional[str] = None):
        if preset is not None:
            if preset not in PRESETS:
                raise ValueError(
                    f"Unknown preset {preset!r}. "
                    f"Available: {', '.join(PRESETS.keys())}")
            settings = PRESETS[preset]

        self._settings = settings or CameraSettings()
        self._device_index = device_index
        self._serial = serial
        self._cam = None  # LatticeCam instance
        self._streaming = False

    # -- Lifecycle ----------------------------------------------------------

    def connect(self) -> "LatticeCamera":
        """Connect to the camera.

        Automatically discovers cameras on the network, restarts
        network adapters if needed, and opens the specified device.

        Returns self for chaining.

        Raises
        ------
        CameraNotFoundError
            If no camera is found.
        CameraConnectionError
            If the connection fails.
        """
        from lattice_cam.camera import LatticeCam

        self._cam = LatticeCam(
            device_index=self._device_index,
            settings=self._settings,
            serial=self._serial,
        )
        try:
            self._cam.connect()
        except RuntimeError as e:
            msg = str(e)
            if "No camera" in msg or "out of range" in msg:
                raise CameraNotFoundError(msg) from e
            raise CameraConnectionError(msg) from e
        return self

    def disconnect(self) -> None:
        """Disconnect from the camera and release resources."""
        if self._streaming:
            self.stop_stream()
        if self._cam is not None:
            self._cam.disconnect()
            self._cam = None

    @property
    def is_connected(self) -> bool:
        """True if the camera is currently connected."""
        return self._cam is not None and self._cam._device is not None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    # -- Device info --------------------------------------------------------

    @property
    def device_info(self) -> DeviceInfo:
        """Read device information from the camera.

        Returns a DeviceInfo with model, serial, firmware, and
        current sensor temperature.
        """
        self._require_connected()
        info = DeviceInfo()
        for attr, node in [
            ("model", "DeviceModelName"),
            ("serial", "DeviceSerialNumber"),
            ("firmware", "DeviceFirmwareVersion"),
        ]:
            try:
                setattr(info, attr, str(self._cam.get_node(node)))
            except Exception:
                pass
        try:
            info.temperature = float(self._cam.get_node("DeviceTemperature"))
        except Exception:
            pass
        # Read LATTICE model from DeviceUserID (NV memory)
        try:
            uid = str(self._cam.get_node("DeviceUserID")).strip()
            if uid:
                info.lattice_model = uid
        except Exception:
            pass
        # IP comes from the arena discovery dict, not a node — populated
        # at LatticeCam.connect() time. Avoids a node read for a value
        # that's already known.
        try:
            di = getattr(self._cam, '_device_info', None)
            if di:
                info.ip = di.get('ip', '') or ''
        except Exception:
            pass
        return info

    @property
    def temperature(self) -> Optional[float]:
        """Current sensor temperature in Celsius, or None."""
        self._require_connected()
        try:
            return float(self._cam.get_node("DeviceTemperature"))
        except Exception:
            return None

    @property
    def settings(self) -> CameraSettings:
        """Current camera settings (read-only copy)."""
        if self._cam is not None:
            return self._cam.settings
        return self._settings

    # -- Exposure & Gain ----------------------------------------------------

    def set_exposure(self, microseconds: float) -> None:
        """Set manual exposure time.

        Disables auto-exposure and sets the exposure to the given
        value in microseconds.

        Parameters
        ----------
        microseconds : float
            Exposure time (100 to 1,000,000 us typical range).
        """
        self._require_connected()
        self._cam.set_exposure(microseconds)

    def set_auto_exposure(self, enabled: bool = True,
                          mode: str = "Continuous") -> None:
        """Enable or disable auto exposure.

        Parameters
        ----------
        enabled : bool
            True to enable, False to disable.
        mode : str
            ``"Continuous"`` (default) or ``"Once"`` for one-shot.
        """
        self._require_connected()
        if enabled:
            self._cam._set_node_safe("ExposureAuto", mode)
            self._cam.settings.exposure_auto = mode
        else:
            self._cam._set_node_safe("ExposureAuto", "Off")
            self._cam.settings.exposure_auto = "Off"
            try:
                self._cam.settings.exposure_time = self._cam.get_node(
                    "ExposureTime")
            except Exception:
                pass

    def set_gain(self, db: float) -> None:
        """Set manual gain in dB.

        Disables auto-gain and sets the gain to the given value.

        Parameters
        ----------
        db : float
            Gain in dB (0 to 48 typical range).
        """
        self._require_connected()
        self._cam.set_gain(db)

    def set_auto_gain(self, enabled: bool = True) -> None:
        """Enable or disable auto gain.

        Parameters
        ----------
        enabled : bool
            True to enable, False to disable.
        """
        self._require_connected()
        if enabled:
            self._cam._set_node_safe("GainAuto", "Continuous")
            self._cam.settings.gain_auto = "Continuous"
        else:
            self._cam._set_node_safe("GainAuto", "Off")
            self._cam.settings.gain_auto = "Off"

    def set_brightness(self, target: int) -> None:
        """Set the auto-exposure target brightness.

        Parameters
        ----------
        target : int
            Brightness level 0-255 (default: 154).
        """
        self._require_connected()
        self._cam._set_node_safe("TargetBrightness", target)
        self._cam.settings.target_brightness = target

    # -- Resolution & Format ------------------------------------------------

    def set_resolution(self, width: int, height: int,
                       offset_x: int = None,
                       offset_y: int = None) -> None:
        """Set sensor resolution and ROI.

        If offsets are not specified, the ROI is centred on the sensor.
        Requires stopping and restarting the stream if currently streaming.

        Parameters
        ----------
        width : int
            Image width in pixels.
        height : int
            Image height in pixels.
        offset_x : int, optional
            Horizontal ROI offset. Auto-centred if None.
        offset_y : int, optional
            Vertical ROI offset. Auto-centred if None.
        """
        self._require_connected()
        max_w, max_h = 2048, 1536
        if offset_x is None:
            offset_x = max(0, (max_w - width) // 2)
        if offset_y is None:
            offset_y = max(0, (max_h - height) // 2)

        was_streaming = self._streaming
        if was_streaming:
            self.stop_stream()
        self._cam.set_resolution(width, height, offset_x, offset_y)
        if was_streaming:
            self.start_stream()

    def set_format(self, pixel_format: str) -> None:
        """Set the pixel format.

        Common formats: ``"BayerRG8"``, ``"BayerRG10"``,
        ``"BayerRG12"`` (recommended), ``"BayerRG16"``, ``"Mono8"``.

        Requires stopping and restarting the stream if currently streaming.

        Parameters
        ----------
        pixel_format : str
            GenICam pixel format name.
        """
        self._require_connected()
        was_streaming = self._streaming
        if was_streaming:
            self.stop_stream()
        self._cam._set_node_safe("PixelFormat", pixel_format)
        self._cam.settings.pixel_format = pixel_format
        if was_streaming:
            self.start_stream()

    # -- ISP toggles (RGB models only) ----------------------------------------

    def set_gamma_enable(self, enabled: bool) -> None:
        """Enable or disable gamma correction (RGB models only)."""
        self._require_connected()
        self._cam._set_isp_node("GammaEnable", enabled)
        self._cam.settings.gamma_enable = enabled

    def set_lut_enable(self, enabled: bool) -> None:
        """Enable or disable the look-up table (RGB models only)."""
        self._require_connected()
        self._cam._set_isp_node("LUTEnable", enabled)
        self._cam.settings.lut_enable = enabled

    def set_ccm_enable(self, enabled: bool) -> None:
        """Enable or disable the colour correction matrix (RGB models only)."""
        self._require_connected()
        self._cam._set_isp_node("ColorTransformationEnable", enabled)
        self._cam.settings.ccm_enable = enabled

    # -- Trigger & frame rate ------------------------------------------------

    def set_trigger_mode(self, mode: str) -> None:
        """Set trigger mode ("On" or "Off")."""
        self._require_connected()
        self._cam._set_node_safe("TriggerMode", mode)
        self._cam.settings.trigger_mode = mode

    def set_trigger_source(self, source: str) -> None:
        """Set trigger source ("Software", "Line0", "Line1", "Line2")."""
        self._require_connected()
        self._cam._set_node_safe("TriggerSource", source)
        self._cam.settings.trigger_source = source

    def set_frame_rate(self, fps: float) -> None:
        """Set acquisition frame rate with min/max clamp + a log line
        if the requested value couldn't be applied verbatim.

        The camera's AcquisitionFrameRate node reports min/max that depend
        on current pixel format, resolution, exposure, and whether
        AcquisitionFrameRateEnable is on. Writing a value below that min
        used to fail silently via ``_set_node_safe``, which is how
        ``set fps=1`` could leave the camera running at ~24 fps with no
        error. Read min/max, clamp, write, then read back and log if the
        actual value diverged from what the user asked for.
        """
        self._require_connected()
        try:
            node = self._cam._device.nodemap.get_node("AcquisitionFrameRate")
        except Exception as e:
            print(f"[fps] AcquisitionFrameRate unavailable: {e!r}", flush=True)
            return
        if node is None:
            print("[fps] AcquisitionFrameRate node missing", flush=True)
            return
        try:
            lo, hi = float(node.min), float(node.max)
        except Exception:
            lo, hi = 1.0, 1000.0
        clamped = max(lo, min(hi, float(fps)))
        try:
            node.value = clamped
        except Exception as e:
            print(f"[fps] write {clamped} failed: {e!r} (min={lo} max={hi})",
                  flush=True)
            return
        try:
            actual = float(node.value)
        except Exception:
            actual = clamped
        if abs(actual - float(fps)) > 0.05:
            print(f"[fps] requested={fps} clamped={clamped} actual={actual} "
                  f"(node min={lo:.2f} max={hi:.2f})", flush=True)
        self._cam.settings.frame_rate = actual

    def set_frame_rate_enable(self, enabled: bool) -> None:
        """Enable or disable the AcquisitionFrameRate cap.

        Auto (Enable=False): camera free-runs at the highest fps the
        current exposure + sensor readout + network bandwidth allow.
        ExposureTime.max binds to the sensor readout limit (~30 ms at
        2048×1536 BayerRG8). AE keeps exposure within that and ramps
        gain when the scene needs more light.

        Manual (Enable=True): AcquisitionFrameRate is honored as the
        upper bound. ExposureTime.max binds to 1/AcquisitionFrameRate
        minus readout, so a manual cap of 1 fps gives ~990 ms of
        exposure headroom.
        """
        self._require_connected()
        self._cam._set_node_safe("AcquisitionFrameRateEnable", enabled)
        self._cam.settings.frame_rate_enable = enabled

    # -- White balance ------------------------------------------------------

    def white_balance_once(self) -> None:
        """Run a one-shot auto white balance."""
        self._require_connected()
        was_streaming = self._streaming
        if not was_streaming:
            self.start_stream()
        try:
            self._cam.set_node("BalanceWhiteAuto", "Once")
            time.sleep(0.5)
        except Exception:
            pass
        if not was_streaming:
            self.stop_stream()

    # -- Streaming ----------------------------------------------------------

    def start_stream(self) -> None:
        """Start the camera acquisition stream.

        Frames can be grabbed with :meth:`grab` or
        :meth:`grab_with_metadata` after starting the stream.

        Raises
        ------
        StreamError
            If the stream cannot be started.
        """
        self._require_connected()
        if self._streaming:
            return
        try:
            self._cam.start_stream()
            self._streaming = True
        except Exception as e:
            raise StreamError(f"Failed to start stream: {e}") from e

    def stop_stream(self) -> None:
        """Stop the camera acquisition stream."""
        if self._cam is not None and self._streaming:
            self._cam.stop_stream()
            self._streaming = False

    @property
    def is_streaming(self) -> bool:
        """True if the camera stream is active."""
        return self._streaming

    def grab(self, timeout_ms: int = 2000) -> np.ndarray:
        """Grab a single frame as a BGR numpy array.

        Automatically starts the stream if not already running.

        Parameters
        ----------
        timeout_ms : int
            Timeout for frame acquisition in milliseconds.

        Returns
        -------
        numpy.ndarray
            BGR image array. dtype is uint8 for 8-bit formats,
            uint16 for 10/12/16-bit formats. Shape: (H, W, 3).

        Raises
        ------
        StreamError
            If the grab times out or fails.

        Examples
        --------
        >>> with LatticeCamera() as cam:
        ...     frame = cam.grab()
        ...     print(frame.shape, frame.dtype)
        (1536, 2048, 3) uint16
        """
        self._auto_stream()
        try:
            frame, _ = self._cam.grab_frame_with_metadata(
                timeout=timeout_ms, native=True)
            return frame
        except Exception as e:
            raise StreamError(f"Grab failed: {e}") from e

    def grab_with_metadata(self, timeout_ms: int = 2000
                           ) -> Tuple[np.ndarray, FrameMetadata]:
        """Grab a frame with per-frame hardware metadata.

        Parameters
        ----------
        timeout_ms : int
            Timeout for frame acquisition in milliseconds.

        Returns
        -------
        frame : numpy.ndarray
            BGR image array (native bit depth).
        metadata : FrameMetadata
            Hardware metadata (actual exposure, gain, timestamp, etc.).

        Raises
        ------
        StreamError
            If the grab times out or fails.

        Examples
        --------
        >>> with LatticeCamera() as cam:
        ...     frame, meta = cam.grab_with_metadata()
        ...     print(f"Exposure: {meta.exposure_us} us")
        """
        self._auto_stream()
        try:
            frame, meta_dict = self._cam.grab_frame_with_metadata(
                timeout=timeout_ms, native=True)
            return frame, _meta_from_dict(meta_dict)
        except Exception as e:
            raise StreamError(f"Grab failed: {e}") from e

    def grab_raw(self, timeout_ms: int = 2000) -> np.ndarray:
        """Grab a raw Bayer/Mono frame without demosaicing.

        Returns the sensor output before colour filter array
        interpolation. Useful for custom demosaic pipelines.

        Returns
        -------
        numpy.ndarray
            Raw 2D array (H, W). dtype matches sensor bit depth.
        """
        self._auto_stream()
        try:
            raw, _ = self._cam.grab_raw_with_metadata(timeout=timeout_ms)
            return raw
        except Exception as e:
            raise StreamError(f"Grab failed: {e}") from e

    # -- Capture to disk ----------------------------------------------------

    def capture(self, filepath: str = None,
                output_dir: str = "output",
                format: str = "tiff",
                jpeg_quality: int = 95) -> "CaptureResult":
        """Capture a single frame and save to disk.

        If *filepath* is given, saves to that exact path.
        Otherwise generates a timestamped filename in *output_dir*.

        A JSON metadata sidecar is saved alongside the image.

        Parameters
        ----------
        filepath : str, optional
            Exact output path (overrides output_dir and format).
        output_dir : str
            Output directory (default: "output").
        format : str
            Image format: "tiff", "png", "jpg" (default: "tiff").
        jpeg_quality : int
            JPEG quality 1-100 (default: 95).

        Returns
        -------
        CaptureResult
            Metadata about the captured frame.

        Raises
        ------
        CaptureError
            If capture or save fails.
        """
        from .capture import capture_single
        self._require_connected()

        if filepath is not None:
            output_dir = os.path.dirname(filepath) or "."
            ext = os.path.splitext(filepath)[1] or f".{format}"
        else:
            ext = f".{format}"

        try:
            return capture_single(
                self._cam, output_dir=output_dir, ext=ext,
                full_depth=(format in ("tiff", "tif")),
                jpeg_quality=jpeg_quality)
        except Exception as e:
            raise CaptureError(f"Capture failed: {e}") from e

    def capture_burst(self, count: int = 5, interval: float = 0.0,
                      output_dir: str = "output",
                      format: str = "tiff",
                      jpeg_quality: int = 95) -> List["CaptureResult"]:
        """Capture N frames in quick succession.

        Parameters
        ----------
        count : int
            Number of frames to capture (default: 5).
        interval : float
            Delay between frames in seconds (default: 0).
        output_dir : str
            Output directory.
        format : str
            Image format.
        jpeg_quality : int
            JPEG quality.

        Returns
        -------
        list of CaptureResult
        """
        from .capture import capture_burst
        self._require_connected()

        ext = f".{format}"
        try:
            return capture_burst(
                self._cam, count=count, interval=interval,
                output_dir=output_dir, ext=ext,
                full_depth=(format in ("tiff", "tif")),
                jpeg_quality=jpeg_quality)
        except Exception as e:
            raise CaptureError(f"Burst capture failed: {e}") from e

    def continuous_capture(self, output_dir: str = "output",
                           format: str = "tiff",
                           jpeg_quality: int = 95,
                           queue_depth: int = 64
                           ) -> "ContinuousRecorder":
        """Create a continuous capture recorder.

        Use as a context manager to record frames continuously::

            with cam.continuous_capture("recordings/") as recorder:
                time.sleep(10)
            print(f"Saved {recorder.stats.frames_saved} frames")

        Parameters
        ----------
        output_dir : str
            Directory for output files.
        format : str
            Image format.
        jpeg_quality : int
            JPEG quality.
        queue_depth : int
            Writer queue depth (increase if dropping frames).

        Returns
        -------
        ContinuousRecorder
            Context manager that records until exited.
        """
        self._require_connected()
        return ContinuousRecorder(
            self._cam, output_dir=output_dir,
            ext=f".{format}",
            full_depth=(format in ("tiff", "tif")),
            jpeg_quality=jpeg_quality,
            queue_depth=queue_depth)

    # -- GenICam node access ------------------------------------------------

    def get_node(self, name: str):
        """Read a GenICam node value.

        Parameters
        ----------
        name : str
            Node name (e.g. "ExposureTime", "DeviceTemperature").

        Returns
        -------
        value
            The node value (type depends on the node).
        """
        self._require_connected()
        return self._cam.get_node(name)

    def set_node(self, name: str, value) -> None:
        """Set a GenICam node value.

        Parameters
        ----------
        name : str
            Node name.
        value
            Value to set (type must match the node).
        """
        self._require_connected()
        self._cam.set_node(name, value)

    # -- Presets & settings -------------------------------------------------

    def apply_settings(self, settings: CameraSettings) -> None:
        """Apply a complete CameraSettings to the device.

        Parameters
        ----------
        settings : CameraSettings
            Settings to apply.
        """
        self._require_connected()
        was_streaming = self._streaming
        if was_streaming:
            self.stop_stream()
        self._cam.apply_settings(settings)
        if was_streaming:
            self.start_stream()

    def apply_preset(self, name: str) -> None:
        """Apply a named preset.

        Parameters
        ----------
        name : str
            Preset name: "default", "high_speed", "high_quality",
            or "triggered".
        """
        if name not in PRESETS:
            raise ValueError(
                f"Unknown preset {name!r}. "
                f"Available: {', '.join(PRESETS.keys())}")
        self.apply_settings(PRESETS[name])

    # -- Power management ---------------------------------------------------

    def sleep(self) -> None:
        """Put the camera into low-power idle mode.

        Stops the stream, throttles the link, and disconnects.
        Call :meth:`wake` to restore.
        """
        self._require_connected()
        self._streaming = False
        self._cam.sleep()

    def wake(self) -> None:
        """Wake the camera from sleep mode.

        Re-discovers the device and re-applies settings.
        """
        if self._cam is not None:
            self._cam.wake()

    # -- Internal -----------------------------------------------------------

    def _require_connected(self):
        if self._cam is None or self._cam._device is None:
            raise CameraConnectionError(
                "Camera not connected. Call connect() first "
                "or use as a context manager.")

    def _auto_stream(self):
        """Start stream if not already streaming."""
        if not self._streaming:
            self.start_stream()


class ContinuousRecorder:
    """Records frames continuously. Use as a context manager.

    Not intended to be created directly — use
    :meth:`LatticeCamera.continuous_capture` instead.
    """

    def __init__(self, camera, output_dir, ext, full_depth,
                 jpeg_quality, queue_depth):
        from lattice_cam.capture import ContinuousCapture
        self._cam = camera
        self._cont = ContinuousCapture(
            camera, output_dir=output_dir, ext=ext,
            full_depth=full_depth, jpeg_quality=jpeg_quality,
            queue_depth=queue_depth)
        self._started = False

    def start(self) -> None:
        """Start recording."""
        if not self._started:
            if not self._cam.is_streaming:
                self._cam.start_stream()
            self._cont.start(grab=True)
            self._started = True

    def stop(self) -> "CaptureStats":
        """Stop recording and return statistics.

        Returns
        -------
        CaptureStats
            Recording statistics (frames saved, dropped, FPS, etc.).
        """
        from .capture import CaptureStats
        if self._started:
            stats = self._cont.stop()
            self._started = False
            return CaptureStats(
                frames_saved=stats.frames_saved,
                frames_dropped=stats.frames_dropped,
                elapsed=stats.elapsed,
                fps=stats.fps,
                output_dir=stats.output_dir,
            )
        return CaptureStats()

    @property
    def stats(self) -> "CaptureStats":
        """Current recording statistics (live, updated during recording)."""
        from .capture import CaptureStats
        s = self._cont.stats
        return CaptureStats(
            frames_saved=s.frames_saved,
            frames_dropped=s.frames_dropped,
            elapsed=s.elapsed,
            fps=s.fps,
            output_dir=s.output_dir,
        )

    @property
    def is_running(self) -> bool:
        return self._cont.is_running

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
        return False
