"""Exception hierarchy for the LATTICE Camera SDK."""


class LatticeError(Exception):
    """Base exception for all LATTICE SDK errors."""


class CameraNotFoundError(LatticeError):
    """No camera found on the network."""


class CameraConnectionError(LatticeError):
    """Failed to connect to a camera."""


class StreamError(LatticeError):
    """Error starting, stopping, or grabbing from the camera stream."""


class CaptureError(LatticeError):
    """Error during frame capture or save."""


class CalibrationError(LatticeError):
    """Error during reflectance calibration."""


class NetworkError(LatticeError):
    """Error with GigE network diagnostics or configuration."""


class DLSError(LatticeError):
    """Error with the downwelling light sensor (DLS)."""


class RegistrationError(LatticeError):
    """Error during multi-camera alignment / co-registration."""
