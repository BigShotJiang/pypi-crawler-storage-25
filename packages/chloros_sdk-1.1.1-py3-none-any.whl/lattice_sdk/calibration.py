"""Reflectance calibration for multispectral imaging.

Provides calibration from MAPIR calibration targets, NDVI computation,
and DLS illumination correction.

Example::

    from lattice_sdk import LatticeCamera, Calibration

    with LatticeCamera() as cam:
        calib = Calibration(filter_model="RGN-IMX265")
        frame = cam.grab()
        coeffs = calib.calibrate_from_frame(frame)
        if coeffs is not None:
            reflectance = calib.to_reflectance(frame)
            ndvi = calib.compute_ndvi(reflectance)
"""

import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from .exceptions import CalibrationError


@dataclass
class FilterModel:
    """A camera filter model with its spectral characteristics.

    Attributes:
        name: Short label (e.g. "RGN-IMX265").
        filter_type: Internal filter type string (e.g. "660/550/850_imx265").
        bands: Wavelength centres in nm for each channel.
        is_default: True if this is the default filter model.
    """
    name: str
    filter_type: str
    bands: Tuple[int, ...] = ()
    is_default: bool = False


@dataclass
class CalibrationCoefficients:
    """Reflectance calibration coefficients.

    Contains per-channel quadratic polynomial coefficients and the
    effective sensor response inverse matrix. Can be saved/loaded
    as JSON for offline use.

    Attributes:
        red: Quadratic coefficients [c2, c1, c0] for red channel.
        green: Quadratic coefficients for green channel.
        blue: Quadratic coefficients for blue/NIR channel.
        filter_type: Filter model used for calibration.
        target_id: ArUco marker ID of the calibration target.
        bit_depth: Sensor bit depth at calibration time.
        inv_eff: Effective 3x3 sensor response inverse (with gains).
        white_dns: Raw white panel DNs (Red, Green, NIR).
    """
    red: List[float] = field(default_factory=list)
    green: List[float] = field(default_factory=list)
    blue: List[float] = field(default_factory=list)
    filter_type: str = ""
    target_id: int = 0
    bit_depth: int = 12
    inv_eff: Optional[np.ndarray] = None
    white_dns: Optional[Tuple[float, ...]] = None

    def save(self, filepath: str) -> None:
        """Save coefficients to a JSON file.

        Parameters
        ----------
        filepath : str
            Output file path.
        """
        data = {
            "filter_type": self.filter_type,
            "target_id": self.target_id,
            "bit_depth": self.bit_depth,
            "red": list(self.red),
            "green": list(self.green),
            "blue": list(self.blue),
        }
        if self.inv_eff is not None:
            data["inv_eff"] = self.inv_eff.tolist()
        if self.white_dns is not None:
            data["white_dns"] = list(self.white_dns)
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "CalibrationCoefficients":
        """Load coefficients from a JSON file.

        Parameters
        ----------
        filepath : str
            Path to JSON file saved with :meth:`save`.

        Returns
        -------
        CalibrationCoefficients
        """
        with open(filepath) as f:
            data = json.load(f)
        coeffs = cls(
            red=data.get("red", []),
            green=data.get("green", []),
            blue=data.get("blue", []),
            filter_type=data.get("filter_type", ""),
            target_id=data.get("target_id", 0),
            bit_depth=data.get("bit_depth", 12),
        )
        if "inv_eff" in data:
            coeffs.inv_eff = np.array(data["inv_eff"])
        if "white_dns" in data:
            coeffs.white_dns = tuple(data["white_dns"])
        return coeffs


def list_filters() -> List[FilterModel]:
    """List all available filter models.

    Returns
    -------
    list of FilterModel

    Examples
    --------
    >>> for f in list_filters():
    ...     print(f"{f.name}: {f.filter_type}")
    RGN: 660/550/850
    RGN-IMX265: 660/550/850_imx265
    ...
    """
    from lattice_cam.calibration import (
        FILTER_CYCLE, FILTER_LABELS, DEFAULT_FILTER)

    models = []
    for ftype in FILTER_CYCLE:
        label = FILTER_LABELS.get(ftype, ftype)
        # Parse wavelength centres from filter_type string
        bands = ()
        base = ftype.split("_")[0]  # strip _imx265 suffix
        if "/" in base:
            try:
                bands = tuple(int(x) for x in base.split("/"))
            except ValueError:
                pass
        elif base.isdigit():
            bands = (int(base),)

        models.append(FilterModel(
            name=label,
            filter_type=ftype,
            bands=bands,
            is_default=(ftype == DEFAULT_FILTER),
        ))
    return models


class Calibration:
    """Reflectance calibration engine.

    Detects MAPIR calibration targets in frames, computes calibration
    coefficients, and applies them to convert raw DN values to
    reflectance (0-1 float).

    Parameters
    ----------
    filter_model : str
        Filter model name or type string. Can be a label like
        ``"RGN-IMX265"`` or an internal type like
        ``"660/550/850_imx265"``. Default: ``"RGN-IMX265"``.
    bit_depth : int
        Sensor bit depth (8, 10, 12, or 16). Default: 12.

    Examples
    --------
    Interactive calibration::

        calib = Calibration("RGN-IMX265")
        with LatticeCamera() as cam:
            for frame in frames:
                result = calib.calibrate_from_frame(frame)
                if result is not None:
                    break
            refl = calib.to_reflectance(cam.grab())
            ndvi = calib.compute_ndvi(refl)

    From saved coefficients::

        calib = Calibration("RGN-IMX265")
        calib.load_coefficients("calib.json")
        refl = calib.to_reflectance(frame)
    """

    def __init__(self, filter_model: str = "RGN-IMX265",
                 bit_depth: int = 12):
        self._filter_type = _resolve_filter(filter_model)
        self._bit_depth = bit_depth
        self._coeffs = None       # Internal dict from calibration.py
        self._calib_coeffs = None  # Public CalibrationCoefficients

    @property
    def filter_type(self) -> str:
        """Internal filter type string."""
        return self._filter_type

    @property
    def filter_name(self) -> str:
        """Human-readable filter name."""
        from lattice_cam.calibration import FILTER_LABELS
        return FILTER_LABELS.get(self._filter_type, self._filter_type)

    @property
    def is_calibrated(self) -> bool:
        """True if calibration coefficients are available."""
        return self._coeffs is not None

    @property
    def coefficients(self) -> Optional[CalibrationCoefficients]:
        """Current calibration coefficients, or None."""
        return self._calib_coeffs

    def calibrate_from_frame(self, frame: np.ndarray,
                             bit_depth: int = None
                             ) -> Optional[CalibrationCoefficients]:
        """Attempt to calibrate from a single frame.

        Detects ArUco calibration targets in the frame. If a valid
        target is found, computes and stores calibration coefficients.

        Parameters
        ----------
        frame : numpy.ndarray
            BGR image (native bit depth).
        bit_depth : int, optional
            Override bit depth (auto-detected from dtype if None).

        Returns
        -------
        CalibrationCoefficients or None
            Coefficients if calibration succeeded, None if no target
            was detected.
        """
        from lattice_cam import aruco, calibration, gpu_ops

        bits = bit_depth or self._bit_depth

        # Need uint8 for ArUco detection
        if frame.dtype == np.uint16:
            shift = max(0, bits - 8)
            display = (frame >> shift).astype(np.uint8)
        else:
            display = frame

        targets = aruco.detect(display)
        if not targets:
            return None

        target = targets[0]
        dns, polys, sat = calibration.extract_panel_dns(
            frame, target['panel_polys'], bit_depth=bits)

        coeffs = calibration.compute_coefficients(
            dns, target['id'], self._filter_type,
            bit_depth=bits, sat_fracs=sat, verbose=False)

        if coeffs is None:
            return None

        self._coeffs = coeffs
        self._calib_coeffs = CalibrationCoefficients(
            red=list(coeffs.get('red', [])),
            green=list(coeffs.get('green', [])),
            blue=list(coeffs.get('blue', [])),
            filter_type=self._filter_type,
            target_id=target['id'],
            bit_depth=bits,
            inv_eff=coeffs.get('inv_eff'),
            white_dns=coeffs.get('white_dns'),
        )
        return self._calib_coeffs

    def to_reflectance(self, frame: np.ndarray,
                       bit_depth: int = None) -> np.ndarray:
        """Convert a raw frame to reflectance.

        Applies sensor response correction and polynomial mapping.

        Parameters
        ----------
        frame : numpy.ndarray
            BGR image (native bit depth).
        bit_depth : int, optional
            Override bit depth.

        Returns
        -------
        numpy.ndarray
            Float32 BGR reflectance image (values 0-1).

        Raises
        ------
        CalibrationError
            If not calibrated.
        """
        if self._coeffs is None:
            raise CalibrationError("Not calibrated. Call calibrate_from_frame() first.")

        from lattice_cam import gpu_ops
        bits = bit_depth or self._bit_depth
        gpu_ops.initialize()
        return gpu_ops.gpu_apply_calibration(
            frame, self._coeffs, self._filter_type, bit_depth=bits)

    def compute_ndvi(self, reflectance: np.ndarray) -> np.ndarray:
        """Compute NDVI from a reflectance frame.

        NDVI = (NIR - Red) / (NIR + Red)

        Parameters
        ----------
        reflectance : numpy.ndarray
            Float32 BGR reflectance image from :meth:`to_reflectance`.

        Returns
        -------
        numpy.ndarray
            Float32 2D array of NDVI values (-1 to 1).
        """
        from lattice_cam import gpu_ops
        gpu_ops.initialize()
        return gpu_ops.gpu_compute_ndvi(reflectance)

    def load_coefficients(self, filepath: str) -> CalibrationCoefficients:
        """Load calibration coefficients from a JSON file.

        Parameters
        ----------
        filepath : str
            Path to JSON file.

        Returns
        -------
        CalibrationCoefficients
        """
        self._calib_coeffs = CalibrationCoefficients.load(filepath)
        # Rebuild internal coeffs dict
        self._coeffs = {
            'red': np.array(self._calib_coeffs.red),
            'green': np.array(self._calib_coeffs.green),
            'blue': np.array(self._calib_coeffs.blue),
        }
        if self._calib_coeffs.inv_eff is not None:
            self._coeffs['inv_eff'] = self._calib_coeffs.inv_eff
        if self._calib_coeffs.white_dns is not None:
            self._coeffs['white_dns'] = self._calib_coeffs.white_dns
        self._filter_type = self._calib_coeffs.filter_type
        self._bit_depth = self._calib_coeffs.bit_depth
        return self._calib_coeffs

    def save_coefficients(self, filepath: str) -> None:
        """Save current calibration coefficients to JSON.

        Parameters
        ----------
        filepath : str
            Output file path.

        Raises
        ------
        CalibrationError
            If not calibrated.
        """
        if self._calib_coeffs is None:
            raise CalibrationError("No coefficients to save.")
        self._calib_coeffs.save(filepath)

    def detect_targets(self, frame: np.ndarray,
                       bit_depth: int = None) -> List[Dict]:
        """Detect MAPIR calibration targets in a frame.

        Parameters
        ----------
        frame : numpy.ndarray
            BGR image.
        bit_depth : int, optional
            Override bit depth.

        Returns
        -------
        list of dict
            Detected targets with keys: ``id``, ``corners``,
            ``center``, ``panel_centers``, ``panel_polys``.
        """
        from lattice_cam import aruco

        bits = bit_depth or self._bit_depth
        if frame.dtype == np.uint16:
            shift = max(0, bits - 8)
            display = (frame >> shift).astype(np.uint8)
        else:
            display = frame

        return aruco.detect(display)

    def extract_panel_dns(self, frame: np.ndarray,
                          panel_polys: list,
                          bit_depth: int = None
                          ) -> Tuple[list, list, list]:
        """Extract mean DN values from calibration panel regions.

        Parameters
        ----------
        frame : numpy.ndarray
            BGR image (native bit depth).
        panel_polys : list
            Panel polygon arrays from :meth:`detect_targets`.
        bit_depth : int, optional
            Override bit depth.

        Returns
        -------
        dns : list
            Mean (B, G, R) DN per panel, sorted brightest-first.
        polys : list
            Polygons sorted to match dns order.
        sat_fracs : list
            Per-pixel saturation fractions per panel.
        """
        from lattice_cam import calibration
        bits = bit_depth or self._bit_depth
        return calibration.extract_panel_dns(
            frame, panel_polys, bit_depth=bits)


def _resolve_filter(name: str) -> str:
    """Resolve a user-friendly filter name to internal filter_type string."""
    from lattice_cam.calibration import FILTER_LABELS, DEFAULT_FILTER

    if name is None:
        return DEFAULT_FILTER
    # Direct match (internal type)
    if name in FILTER_LABELS:
        return name
    # Match by label
    for ftype, label in FILTER_LABELS.items():
        if label.lower() == name.lower():
            return ftype
    # Partial match
    for ftype, label in FILTER_LABELS.items():
        if name.lower() in label.lower() or name.lower() in ftype.lower():
            return ftype
    return DEFAULT_FILTER
