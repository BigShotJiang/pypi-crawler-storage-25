"""Camera discovery — find LATTICE cameras on the network."""

from dataclasses import dataclass
from typing import List, Optional

from .exceptions import CameraNotFoundError


@dataclass
class CameraInfo:
    """Information about a discovered camera.

    Attributes:
        index: Device index for opening this camera.
        model: Camera model name.
        serial: Serial number.
        ip: IP address on the GigE network.
        mac: MAC address.
        vendor: Manufacturer name.
        lattice_model: DeviceUserID — e.g. "M3C-L41-FRGB".
    """
    index: int
    model: str
    serial: str
    ip: str
    mac: str
    vendor: str = "MAPIR"
    lattice_model: str = ""


def discover_cameras(timeout_ms: int = 1000,
                     recovery: bool = True) -> List[CameraInfo]:
    """Discover all LATTICE cameras on the network.

    Parameters
    ----------
    timeout_ms : int
        Discovery timeout in milliseconds (default: 1000).
    recovery : bool
        If True, automatically restart network adapters and retry
        when no cameras are found on the first scan.

    Returns
    -------
    list of CameraInfo
        One entry per discovered camera, sorted by device index.

    Examples
    --------
    >>> cameras = discover_cameras()
    >>> for cam in cameras:
    ...     print(f"[{cam.index}] {cam.model} (SN: {cam.serial})")
    """
    from lattice_cam.camera import discover_with_recovery, _discover_devices

    if recovery:
        infos = discover_with_recovery(timeout_ms=timeout_ms, verbose=False)
    else:
        infos = _discover_devices(timeout_ms=timeout_ms)

    cameras = []
    for i, info in enumerate(infos):
        cameras.append(CameraInfo(
            index=i,
            model=info.get("model", "Unknown"),
            serial=info.get("serial", "Unknown"),
            ip=info.get("ip", "Unknown"),
            mac=info.get("mac", "Unknown"),
            vendor=info.get("vendor", "MAPIR"),
            lattice_model=info.get("name", ""),
        ))
    return cameras


def find_camera(serial: str = None,
                timeout_ms: int = 1000,
                recovery: bool = True) -> CameraInfo:
    """Find a specific camera by serial number.

    If *serial* is None and exactly one camera is found, returns it.
    Raises CameraNotFoundError otherwise.

    Parameters
    ----------
    serial : str, optional
        Serial number to match. If None, requires exactly one camera.
    timeout_ms : int
        Discovery timeout in milliseconds.
    recovery : bool
        If True, auto-restart adapters when no cameras are found.

    Returns
    -------
    CameraInfo

    Raises
    ------
    CameraNotFoundError
        If the camera is not found or serial is None with != 1 camera.
    """
    cameras = discover_cameras(timeout_ms=timeout_ms, recovery=recovery)
    if not cameras:
        raise CameraNotFoundError("No cameras found on the network")

    if serial is None:
        if len(cameras) == 1:
            return cameras[0]
        serials = [c.serial for c in cameras]
        raise CameraNotFoundError(
            f"Multiple cameras found ({', '.join(serials)}). "
            f"Specify a serial number to select one."
        )

    for cam in cameras:
        if cam.serial == serial:
            return cam
    serials = [c.serial for c in cameras]
    raise CameraNotFoundError(
        f"Camera with serial '{serial}' not found. "
        f"Available: {', '.join(serials)}"
    )
