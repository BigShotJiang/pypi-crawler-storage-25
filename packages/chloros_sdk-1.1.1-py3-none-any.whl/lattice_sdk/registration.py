"""SDK wrapper for multi-camera co-registration (alignment).

Provides the ``Registration`` class — a high-level interface for computing,
saving, loading, and applying alignment profiles across a LATTICE camera array.

Quick start::

    from lattice_sdk import Registration, CameraArray

    array = CameraArray.discover()
    array.configure_sync()
    array.start()

    reg = Registration()
    reg.calibrate(array)             # compute alignment from live cameras
    reg.save("alignment.json")

    _, frames = array.grab_sync()
    aligned = reg.align(frames)
    _, frames = array.grab_sync()
    bands = reg.align_and_stack(frames)

    array.stop()
"""

from lattice_sdk.exceptions import RegistrationError
from lattice_cam.registration import (
    AlignmentProfile,
    compute_alignment,
    compute_alignment_multi,
    apply_alignment,
    gpu_apply_alignment,
    extract_bands,
    save_multiband_tiff,
    save_per_band_tiffs,
    validate_profile,
    diagnostic_overlay,
    _extract_metadata,
    apply_vignette_corrections,
)


class Registration:
    """High-level alignment manager for LATTICE camera arrays.

    Parameters
    ----------
    profile : AlignmentProfile, optional
        Pre-loaded alignment profile. If None, call ``calibrate()``
        or ``load()`` before using ``align()``.
    """

    def __init__(self, profile=None):
        self._profile = profile

    @property
    def profile(self):
        """The current alignment profile, or None."""
        return self._profile

    @property
    def is_calibrated(self):
        """True if a profile has been loaded or computed."""
        return self._profile is not None

    def calibrate(self, array, method="feature_orb", model="affine",
                  num_frames=5, reference_serial=None, checkerboard_size=None,
                  name=""):
        """Compute alignment profile from live cameras.

        Captures *num_frames* synchronized frame groups and averages
        the transforms for robustness.

        Parameters
        ----------
        array : CameraArray
            Connected and streaming camera array.
        method : str
            ``"feature_orb"``, ``"feature_akaze"``, ``"phase_correlation"``,
            ``"checkerboard"``, or ``"manual"``.
        model : str
            ``"translation"``, ``"rigid"``, ``"affine"``, or ``"homography"``.
        num_frames : int
            Number of captures to average (default: 5).
        reference_serial : str, optional
            Reference camera serial. Default: master camera.
        checkerboard_size : tuple of int, optional
            ``(rows, cols)`` for checkerboard method.
        name : str
            Profile name.

        Returns
        -------
        AlignmentProfile
        """
        if not array.is_streaming:
            raise RegistrationError(
                "CameraArray must be streaming. Call array.start() first.")

        if reference_serial is None:
            reference_serial = array.master_serial

        # Read DeviceUserID from each camera for band metadata
        camera_models = {}
        for cam, serial in array._cameras:
            try:
                uid = cam.get_node("DeviceUserID")
                if uid:
                    camera_models[serial] = uid
            except Exception:
                pass

        # Capture calibration frames
        frame_dicts = []
        for i in range(num_frames):
            _, frames = array.grab_sync()
            frame_dicts.append(frames)

        try:
            self._profile = compute_alignment_multi(
                frame_dicts,
                method=method,
                model=model,
                reference_serial=reference_serial,
                camera_models=camera_models,
                checkerboard_size=checkerboard_size,
                name=name,
            )
        except Exception as e:
            raise RegistrationError(f"Alignment calibration failed: {e}") from e

        return self._profile

    def calibrate_from_frames(self, frame_dict, method="feature_orb",
                              model="affine", reference_serial=None,
                              camera_models=None, checkerboard_size=None,
                              control_points=None, name=""):
        """Compute alignment profile from pre-captured frames.

        Parameters
        ----------
        frame_dict : dict
            ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
        **kwargs
            Passed to ``compute_alignment()``.

        Returns
        -------
        AlignmentProfile
        """
        try:
            self._profile = compute_alignment(
                frame_dict,
                method=method,
                model=model,
                reference_serial=reference_serial,
                camera_models=camera_models,
                checkerboard_size=checkerboard_size,
                control_points=control_points,
                name=name,
            )
        except Exception as e:
            raise RegistrationError(f"Alignment calibration failed: {e}") from e

        return self._profile

    def load(self, path):
        """Load an alignment profile from disk.

        Parameters
        ----------
        path : str or Path
            Path to alignment profile JSON file.

        Returns
        -------
        AlignmentProfile
        """
        try:
            self._profile = AlignmentProfile.load(path)
        except Exception as e:
            raise RegistrationError(f"Failed to load profile: {e}") from e
        return self._profile

    def save(self, path):
        """Save the current alignment profile to disk.

        Parameters
        ----------
        path : str or Path
            Output path for the JSON profile file.
        """
        if self._profile is None:
            raise RegistrationError("No profile to save. Run calibrate() first.")
        self._profile.save(path)

    def align(self, frame_dict, use_gpu=None, crop=True, vignette=False):
        """Apply alignment to a synchronized frame group.

        Parameters
        ----------
        frame_dict : dict
            ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
        use_gpu : bool, optional
            Force GPU (True) or CPU (False). Default: auto-detect.
        crop : bool
            Crop to overlap region (default: True).
        vignette : bool
            Apply per-camera vignette correction before alignment.

        Returns
        -------
        dict
            ``{serial: aligned_frame}`` — aligned BGR frames.
        """
        if self._profile is None:
            raise RegistrationError(
                "No profile loaded. Run calibrate() or load() first.")

        if vignette:
            vig_maps = self.load_vignette()
            if vig_maps:
                frame_dict = apply_vignette_corrections(frame_dict, vig_maps)

        if use_gpu is True or (use_gpu is None):
            return gpu_apply_alignment(frame_dict, self._profile, crop)
        else:
            return apply_alignment(frame_dict, self._profile, crop)

    def align_and_stack(self, frame_dict, use_gpu=None, include=None,
                        order=None, frame_metadata=None, vignette=False):
        """Align frames and extract multi-band stack.

        Parameters
        ----------
        frame_dict : dict
            ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
        use_gpu : bool, optional
            Force GPU or CPU. Default: auto-detect.
        include : list of str, optional
            Band names to include.
        order : list of str, optional
            Output band order.
        frame_metadata : dict, optional
            Per-camera metadata from ``_extract_metadata()``.
        vignette : bool
            Apply per-camera vignette correction before alignment.

        Returns
        -------
        bands : ndarray (N_bands, H, W)
            Multi-band array.
        band_info : list of dict
            Band metadata (enriched with per-camera exposure/gain/fwhm).
        """
        if frame_metadata is None:
            frame_metadata = _extract_metadata(frame_dict, self._profile)
        aligned = self.align(frame_dict, use_gpu=use_gpu, vignette=vignette)
        return extract_bands(aligned, self._profile, include=include,
                             order=order, frame_metadata=frame_metadata)

    def save_multiband(self, filepath, frame_dict=None, bands=None,
                       band_info=None, use_gpu=None, bit_depth=None,
                       vignette=False):
        """Convenience method: align + extract + save multi-band TIFF.

        Either provide *frame_dict* (will align and extract) or
        pre-computed *bands* + *band_info*.

        Parameters
        ----------
        filepath : str or Path
            Output TIFF file path.
        frame_dict : dict, optional
            Raw frame group to align.
        bands : ndarray, optional
            Pre-extracted bands.
        band_info : list of dict, optional
            Pre-extracted band metadata.
        use_gpu : bool, optional
            Force GPU or CPU.
        bit_depth : int, optional
            Output bit depth (8, 12, 16).
        vignette : bool
            Apply per-camera vignette correction.
        """
        if self._profile is None:
            raise RegistrationError(
                "No profile loaded. Run calibrate() or load() first.")

        if bands is None:
            if frame_dict is None:
                raise RegistrationError(
                    "Provide either frame_dict or bands+band_info.")
            bands, band_info = self.align_and_stack(frame_dict,
                                                     use_gpu=use_gpu,
                                                     vignette=vignette)

        save_multiband_tiff(bands, self._profile, filepath,
                            bit_depth=bit_depth, band_info=band_info,
                            vignette_corrected=vignette)

    def save_per_band(self, filepath_prefix, frame_dict=None, bands=None,
                      band_info=None, use_gpu=None, bit_depth=None,
                      vignette=False):
        """Save each band as a separate TIFF with per-band EXIF metadata.

        Parameters
        ----------
        filepath_prefix : str or Path
            Output path prefix (directory + filename stem).
        frame_dict : dict, optional
            Raw frame group to align.
        bands : ndarray, optional
            Pre-extracted bands.
        band_info : list of dict, optional
            Pre-extracted band metadata.
        use_gpu : bool, optional
            Force GPU or CPU.
        bit_depth : int, optional
            Output bit depth (8, 12, 16).
        vignette : bool
            Apply per-camera vignette correction.

        Returns
        -------
        list of Path
            Paths to saved per-band TIFF files.
        """
        if self._profile is None:
            raise RegistrationError(
                "No profile loaded. Run calibrate() or load() first.")

        if bands is None:
            if frame_dict is None:
                raise RegistrationError(
                    "Provide either frame_dict or bands+band_info.")
            bands, band_info = self.align_and_stack(frame_dict,
                                                     use_gpu=use_gpu,
                                                     vignette=vignette)

        return save_per_band_tiffs(bands, self._profile, filepath_prefix,
                                   bit_depth=bit_depth, band_info=band_info,
                                   vignette_corrected=vignette)

    def load_vignette(self):
        """Load per-camera vignette correction maps from the profile.

        Returns
        -------
        dict or None
            ``{serial: vignette_inv_ndarray_or_None}``, or None if
            no profile is loaded.
        """
        if self._profile is None:
            return None
        from lattice_cam.calibration import load_vignette_map_array
        w, h = self._profile.sensor_resolution
        return load_vignette_map_array(
            self._profile.camera_models, width=w, height=h)

    def __repr__(self):
        if self._profile is None:
            return "Registration(profile=None)"
        p = self._profile
        return (f"Registration(name={p.name!r}, "
                f"cameras={len(p.camera_serials)}, "
                f"output={p.output_width}x{p.output_height})")
