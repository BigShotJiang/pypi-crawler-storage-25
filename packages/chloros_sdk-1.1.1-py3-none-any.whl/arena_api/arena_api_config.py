# -----------------------------------------------------------------------------
# Copyright (c) 2022, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

"""
Auto-detect bundled Arena SDK native libraries for self-contained deployment.

When running from a Nuitka-compiled exe, DLLs are expected in an
``arena_runtime/`` subdirectory next to the executable.  In development
mode, the same directory is searched relative to this file's parent
(the repo root).  If no bundled libraries are found, the original
registry-based resolution in ``_xlayer/binary/`` is used as a fallback.
"""

import os
import sys


def _find_bundled_dll(dll_name):
    """Find a bundled native library relative to exe or script."""
    # Nuitka exe: DLLs in arena_runtime/ subdirectory next to exe
    exe_dir = os.path.dirname(sys.executable)
    candidates = [
        os.path.join(exe_dir, 'arena_runtime', dll_name),
        os.path.join(exe_dir, dll_name),
        # Dev mode: DLLs in repo's arena_runtime/ directory
        os.path.join(os.path.dirname(__file__), '..', 'arena_runtime', dll_name),
    ]
    for path in candidates:
        if os.path.exists(path):
            return os.path.abspath(path)
    return ''  # fall back to original registry-based resolution


ARENAC_CUSTOM_PATHS = {
    'python64_win': _find_bundled_dll('ArenaC_v140.dll'),
    'python32_win': '',
    'python64_lin': _find_bundled_dll('libarenac.so'),
    'python32_lin': ''
}

SAVEC_CUSTOM_PATHS = {
    'python64_win': _find_bundled_dll('SaveC_v140.dll'),
    'python32_win': '',
    'python64_lin': _find_bundled_dll('libsavec.so'),
    'python32_lin': ''
}
