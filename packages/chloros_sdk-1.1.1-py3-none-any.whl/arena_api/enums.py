# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from enum import IntEnum
from arena_api._xlayer.xarena._xglobal import _xGlobal

# TODO SFW-2186


class InterfaceType(IntEnum):
    INTEGER = 2
    BOOLEAN = 3
    COMMAND = 4
    FLOAT = 5
    STRING = 6
    REGISTER = 7
    CATEGORY = 8
    ENUMERATION = 9
    ENUMENTRY = 10


class AccessMode(IntEnum):
    NI = 0
    NA = 1
    WO = 2
    RO = 3
    RW = 4
    UNDEFINED = 5


class CachingMode(IntEnum):
    NO_CACHE = 0
    WRITE_THROUGH = 1
    WRITE_AROUND = 2
    UNDEFINED = 3


class Namespace(IntEnum):
    CUSTOM = 0
    STANDARD = 1
    UNDEFINED = 2


class Visibility(IntEnum):
    BEGINNER = 0
    EXPERT = 1
    GURU = 2
    INVISIBLE = 3
    UNDEFINED = 99


class IncMode(IntEnum):
    NONE = 0
    FIXED = 1
    LIST = 2


class Representation(IntEnum):
    LINEAR = 0
    LOGARITHMIC = 1
    BOOLEAN = 2
    PURE_NUMBER = 3
    HEX_NUMBER = 4
    IPV4_ADDRESS = 5
    MAC_ADDRESS = 6
    UNDEFINED = 7


class DisplayNotation(IntEnum):
    AUTOMATIC = 0
    FIXED = 1
    SCIENTIFIC = 2
    UNDEFINED = 3


class PayloadType(IntEnum):
    IMAGE = 0x0001
    IMAGE_EXTENDED_CHUNK = 0x4001
    CHUNKDATA = 0x0004
    COMPRESSED_IMAGE = 1001
    COMPRESSED_IMAGE_EXTENDED_CHUNK = 1002


class PixelEndianness(IntEnum):
    UNKNOWN = 0
    LITTLE = 1
    BIG = 2


class BayerAlgorithm(IntEnum):
    UNKNOWN = 0
    DIRECTIONAL_INTERPOLATION = 1
    ADAPTIVE_HOMOGENEITY_DIRECTED = 2


class ScJpegSubsamplingList(IntEnum):
    # Save with no chroma subsampling (4:4:4)
    SC_NO_JPEG_SUBSAMPLING = 0
    # Save with high 4x1 chroma subsampling (4:1:1)
    SC_JPEG_SUBSAMPLING_411 = 1
    # Save with medium 2x2 chroma subsampling (4:2:0) 
    SC_JPEG_SUBSAMPLING_420 = 2
    # Save with low 2x1 chroma subsampling (4:2:2)
    SC_JPEG_SUBSAMPLING_422 = 3	 


class SC_TIFF_COMPRESSION_LIST(IntEnum):
	# Save without any compression
    SC_NO_TIFF_COMPRESSION = 0		
    # Save using PACKBITS compression	   
    SC_TIFF_COMPRESSION_PACKBITS = 1
    # Save using DEFLATE compression (also known as ZLIP compression) 
    SC_TIFF_COMPRESSION_DEFLATE = 2	
    # Save using ADOBE DEFLATE compression
    SC_TIFF_COMPRESSION_ADOBE_DEFLATE = 3 
    # Save using CCITT Group 3 fax encoding
    SC_TIFF_COMPRESSION_CCITTFAX3 = 4
    # Save using CCITT Group 4 fax encoding
    SC_TIFF_COMPRESSION_CCITTFAX4 = 5	
    # Save using LZW compression   
    SC_TIFF_COMPRESSION_LZW = 6		   
	# Save using JPEG compression (8-bit greyscale and 24-bit only. Default to LZW for other bitdepths)
    SC_TIFF_COMPRESSION_JPEG_TIFF = 7 
    # Save using LogLuv compression (only available with RGBF images. Default to LZW compression)
    SC_TIFF_COMPRESSION_LOGLUV = 8		   


# class Pixelformat(MultiValueEnum):
class PixelFormat(IntEnum):
    
    # Monochrome 1-bit packed
    Mono1p = 0x01010037
    # Monochrome 2-bit packed
    Mono2p = 0x01020038
    # Monochrome 4-bit packed
    Mono4p = 0x01040039
    # Monochrome 8-bit
    Mono8 = 0x01080001
    # Monochrome 8-bit signed
    Mono8s = 0x01080002
    # Monochrome 10-bit unpacked
    Mono10 = 0x01100003
    # Monochrome 10-bit packed
    Mono10p = 0x010A0046
    # Monochrome 12-bit unpacked
    Mono12 = 0x01100005
    # Monochrome 12-bit packed
    Mono12p = 0x010C0047
    # Monochrome 14-bit unpacked
    Mono14 = 0x01100025
    # Monochrome 16-bit
    Mono16 = 0x01100007
    # Bayer Blue-Green 8-bit
    BayerBG8 = 0x0108000B
    # Bayer Blue-Green 10-bit unpacked
    BayerBG10 = 0x0110000F
    # Bayer Blue-Green 10-bit packed
    BayerBG10p = 0x010A0052
    # Bayer Blue-Green 12-bit unpacked
    BayerBG12 = 0x01100013
    # Bayer Blue-Green 12-bit packed
    BayerBG12p = 0x010C0053
    # Bayer Blue-Green 16-bit
    BayerBG16 = 0x01100031
    # Bayer Green-Blue 8-bit
    BayerGB8 = 0x0108000A
    # Bayer Green-Blue 10-bit unpacked
    BayerGB10 = 0x0110000E
    # Bayer Green-Blue 10-bit packed
    BayerGB10p = 0x010A0054
    # Bayer Green-Blue 12-bit unpacked
    BayerGB12 = 0x01100012
    # Bayer Green-Blue 12-bit packed
    BayerGB12p = 0x010C0055
    # Bayer Green-Blue 16-bit
    BayerGB16 = 0x01100030
    # Bayer Green-Red 8-bit
    BayerGR8 = 0x01080008
    # Bayer Green-Red 10-bit unpacked
    BayerGR10 = 0x0110000C
    # Bayer Green-Red 10-bit packed
    BayerGR10p = 0x010A0056
    # Bayer Green-Red 12-bit unpacked
    BayerGR12 = 0x01100010
    # Bayer Green-Red 12-bit packed
    BayerGR12p = 0x010C0057
    # Bayer Green-Red 16-bit
    BayerGR16 = 0x0110002E
    # Bayer Red-Green 8-bit
    BayerRG8 = 0x01080009
    # Bayer Red-Green 10-bit unpacked
    BayerRG10 = 0x0110000D
    # Bayer Red-Green 10-bit packed
    BayerRG10p = 0x010A0058
    # Bayer Red-Green 12-bit unpacked
    BayerRG12 = 0x01100011
    # Bayer Red-Green 12-bit packed
    BayerRG12p = 0x010C0059
    # Bayer Red-Green 16-bit
    BayerRG16 = 0x0110002F
    # Red-Green-Blue-alpha 8-bit
    RGBa8 = 0x02200016
    # Red-Green-Blue-alpha 10-bit unpacked
    RGBa10 = 0x0240005F
    # Red-Green-Blue-alpha 10-bit packed
    RGBa10p = 0x02280060
    # Red-Green-Blue-alpha 12-bit unpacked
    RGBa12 = 0x02400061
    # Red-Green-Blue-alpha 12-bit packed
    RGBa12p = 0x02300062
    # Red-Green-Blue-alpha 14-bit unpacked
    RGBa14 = 0x02400063
    # Red-Green-Blue-alpha 16-bit
    RGBa16 = 0x02400064
    # Red-Green-Blue 8-bit
    RGB8 = 0x02180014
    # Red-Green-Blue 8-bit planar
    RGB8_Planar = 0x02180021
    # Red-Green-Blue 10-bit unpacked
    RGB10 = 0x02300018
    # Red-Green-Blue 10-bit unpacked planar
    RGB10_Planar = 0x02300022
    # Red-Green-Blue 10-bit packed
    RGB10p = 0x021E005C
    # Red-Green-Blue 10-bit packed into 32-bit
    RGB10p32 = 0x0220001D
    # Red-Green-Blue 12-bit unpacked
    RGB12 = 0x0230001A
    # Red-Green-Blue 12-bit unpacked planar
    RGB12_Planar = 0x02300023
    # Red-Green-Blue 12-bit packed  
    RGB12p = 0x0224005D
    # Red-Green-Blue 14-bit unpacked
    RGB14 = 0x0230005E
    # Red-Green-Blue 16-bit  
    RGB16 = 0x02300033
    # Red-Green-Blue 16-bit planar
    RGB16_Planar = 0x02300024
    # Red-Green-Blue 5/6/5-bit packed
    RGB565p = 0x02100035
    # Blue-Green-Red-alpha 8-bit
    BGRa8 = 0x02200017
    # Blue-Green-Red-alpha 10-bit unpacked
    BGRa10 = 0x0240004C
    # Blue-Green-Red-alpha 10-bit packed
    BGRa10p = 0x0228004D
    # Blue-Green-Red-alpha 12-bit unpacked
    BGRa12 = 0x0240004E
    # Blue-Green-Red-alpha 12-bit packed
    BGRa12p = 0x0230004F
    # Blue-Green-Red-alpha 14-bit unpacked
    BGRa14 = 0x02400050
    # Blue-Green-Red-alpha 16-bit
    BGRa16 = 0x02400051
    # Blue-Green-Red 8-bit
    BGR8 = 0x02180015
    # Blue-Green-Red 10-bit unpacked
    BGR10 = 0x02300019
    # Blue-Green-Red 10-bit packed
    BGR10p = 0x021E0048
    # Blue-Green-Red 12-bit unpacked
    BGR12 = 0x0230001B
    # Blue-Green-Red 12-bit packed
    BGR12p = 0x02240049
    # Blue-Green-Red 14-bit unpacked
    BGR14 = 0x0230004A
    # Blue-Green-Red 16-bit
    BGR16 = 0x0230004B
    # Blue-Green-Red 5/6/5-bit packed
    BGR565p = 0x02100036
    # Red 8-bit
    R8 = 0x010800C9
    # Red 10-bit
    R10 = 0x010A00CA
    # Red 12-bit
    R12 = 0x010C00CB
    # Red 16-bit
    R16 = 0x011000CC
    # Green 8-bit
    G8 = 0x010800CD
    # Green 10-bit
    G10 = 0x010A00CE
    # Green 12-bit
    G12 = 0x010C00CF
    # Green 16-bit
    G16 = 0x011000D0
    # Blue 8-bit
    B8 = 0x010800D1
    # Blue 10-bit
    B10 = 0x010A00D2
    # Blue 12-bit
    B12 = 0x010C00D3
    # Blue 16-bit
    B16 = 0x011000D4
    # 3D coordinate A-B-C 8-bit
    Coord3D_ABC8 = 0x021800B2
    # 3D coordinate A-B-C 8-bit planar
    Coord3D_ABC8_Planar = 0x021800B3
    # 3D coordinate A-B-C 10-bit packed
    Coord3D_ABC10p = 0x021E00DB
    # 3D coordinate A-B-C 10-bit packed planar
    Coord3D_ABC10p_Planar = 0x021E00DC
    # 3D coordinate A-B-C 12-bit packed
    Coord3D_ABC12p = 0x022400DE
    # 3D coordinate A-B-C 12-bit packed planar
    Coord3D_ABC12p_Planar = 0x022400DF
    # 3D coordinate A-B-C 16-bit
    Coord3D_ABC16 = 0x023000B9
    # 3D coordinate A-B-C 16-bit planar
    Coord3D_ABC16_Planar = 0x023000BA
    # 3D coordinate A-B-C 32-bit floating point
    Coord3D_ABC32f = 0x026000C0
    # 3D coordinate A-B-C 32-bit floating point planar
    Coord3D_ABC32f_Planar = 0x026000C1
    # 3D coordinate A-C 8-bit
    Coord3D_AC8 = 0x021000B4
    # 3D coordinate A-C 8-bit planar
    Coord3D_AC8_Planar = 0x021000B5
    # 3D coordinate A-C 10-bit packed
    Coord3D_AC10p = 0x021400F0
    # 3D coordinate A-C 10-bit packed planar
    Coord3D_AC10p_Planar = 0x021400F1
    # 3D coordinate A-C 12-bit packed
    Coord3D_AC12p = 0x021800F2
    # 3D coordinate A-C 12-bit packed planar
    Coord3D_AC12p_Planar = 0x021800F3
    # 3D coordinate A-C 16-bit
    Coord3D_AC16 = 0x022000BB
    # 3D coordinate A-C 16-bit planar
    Coord3D_AC16_Planar = 0x022000BC
    # 3D coordinate A-C 32-bit floating point
    Coord3D_AC32f = 0x024000C2
    # 3D coordinate A-C 32-bit floating point planar
    Coord3D_AC32f_Planar = 0x024000C3
    # 3D coordinate A 8-bit
    Coord3D_A8 = 0x010800AF
    # 3D coordinate A 10-bit packed
    Coord3D_A10p = 0x010A00D5
    # 3D coordinate A 12-bit packed
    Coord3D_A12p = 0x010C00D8
    # 3D coordinate A 16-bit
    Coord3D_A16 = 0x011000B6
    # 3D coordinate A 32-bit floating point
    Coord3D_A32f = 0x012000BD
    # 3D coordinate B 8-bit
    Coord3D_B8 = 0x010800B0
    # 3D coordinate B 10-bit packed
    Coord3D_B10p = 0x010A00D6
    # 3D coordinate B 12-bit packed
    Coord3D_B12p = 0x010C00D9
    # 3D coordinate B 16-bit
    Coord3D_B16 = 0x011000B7
    # 3D coordinate B 32-bit floating point
    Coord3D_B32f = 0x012000BE
    # 3D coordinate C 8-bit
    Coord3D_C8 = 0x010800B1
    # 3D coordinate C 10-bit packed
    Coord3D_C10p = 0x010A00D7
    # 3D coordinate C 12-bit packed
    Coord3D_C12p = 0x010C00DA
    # 3D coordinate C 16-bit
    Coord3D_C16 = 0x011000B8
    # 3D coordinate C 32-bit floating point
    Coord3D_C32f = 0x012000BF
    # Confidence 1-bit unpacked
    Confidence1 = 0x010800C4
    # Confidence 1-bit packed
    Confidence1p = 0x010100C5
    # Confidence 8-bit
    Confidence8 = 0x010800C6
    # Confidence 16-bit
    Confidence16 = 0x011000C7
    # Confidence 32-bit floating point
    Confidence32f = 0x012000C8
    # Bi-color Blue/Green - Red/Green 8-bit
    BiColorBGRG8 = 0x021000A6
    # Bi-color Blue/Green - Red/Green 10-bit unpacked
    BiColorBGRG10 = 0x022000A9
    # Bi-color Blue/Green - Red/Green 10-bit packed
    BiColorBGRG10p = 0x021400AA
    # Bi-color Blue/Green - Red/Green 12-bit unpacked
    BiColorBGRG12 = 0x022000AD
    # Bi-color Blue/Green - Red/Green 12-bit packed
    BiColorBGRG12p = 0x021800AE
    # Bi-color Red/Green - Blue/Green 8-bit
    BiColorRGBG8 = 0x021000A5
    # Bi-color Red/Green - Blue/Green 10-bit unpacked
    BiColorRGBG10 = 0x022000A7
    # Bi-color Red/Green - Blue/Green 10-bit packed
    BiColorRGBG10p = 0x021400A8
    # Bi-color Red/Green - Blue/Green 12-bit unpacked
    BiColorRGBG12 = 0x022000AB
    # Bi-color Red/Green - Blue/Green 12-bit packed
    BiColorRGBG12p = 0x021800AC
    # Sparse Color Filter #1 White-Blue-White-Green 8-bit
    SCF1WBWG8 = 0x01080067
    # Sparse Color Filter #1 White-Blue-White-Green 10-bit unpacked
    SCF1WBWG10 = 0x01100068
    # Sparse Color Filter #1 White-Blue-White-Green 10-bit packed
    SCF1WBWG10p = 0x010A0069
    # Sparse Color Filter #1 White-Blue-White-Green 12-bit unpacked
    SCF1WBWG12 = 0x0110006A
    # Sparse Color Filter #1 White-Blue-White-Green 12-bit packed
    SCF1WBWG12p = 0x010C006B
    # Sparse Color Filter #1 White-Blue-White-Green 14-bit unpacked
    SCF1WBWG14 = 0x0110006C
    # Sparse Color Filter #1 White-Blue-White-Green 16-bit unpacked
    SCF1WBWG16 = 0x0110006D
    # Sparse Color Filter #1 White-Green-White-Blue 8-bit
    SCF1WGWB8 = 0x0108006E
    # Sparse Color Filter #1 White-Green-White-Blue 10-bit unpacked
    SCF1WGWB10 = 0x0110006F
    # Sparse Color Filter #1 White-Green-White-Blue 10-bit packed
    SCF1WGWB10p = 0x010A0070
    # Sparse Color Filter #1 White-Green-White-Blue 12-bit unpacked
    SCF1WGWB12 = 0x01100071
    # Sparse Color Filter #1 White-Green-White-Blue 12-bit packed
    SCF1WGWB12p = 0x010C0072
    # Sparse Color Filter #1 White-Green-White-Blue 14-bit unpacked
    SCF1WGWB14 = 0x01100073
    # Sparse Color Filter #1 White-Green-White-Blue 16-bit
    SCF1WGWB16 = 0x01100074
    # Sparse Color Filter #1 White-Green-White-Red 8-bit
    SCF1WGWR8 = 0x01080075
    # Sparse Color Filter #1 White-Green-White-Red 10-bit unpacked
    SCF1WGWR10 = 0x01100076
    # Sparse Color Filter #1 White-Green-White-Red 10-bit packed
    SCF1WGWR10p = 0x010A0077
    # Sparse Color Filter #1 White-Green-White-Red 12-bit unpacked
    SCF1WGWR12 = 0x01100078
    # Sparse Color Filter #1 White-Green-White-Red 12-bit packed
    SCF1WGWR12p = 0x010C0079
    # Sparse Color Filter #1 White-Green-White-Red 14-bit unpacked
    SCF1WGWR14 = 0x0110007A
    # Sparse Color Filter #1 White-Green-White-Red 16-bit
    SCF1WGWR16 = 0x0110007B
    # Sparse Color Filter #1 White-Red-White-Green 8-bit
    SCF1WRWG8 = 0x0108007C
    # Sparse Color Filter #1 White-Red-White-Green 10-bit unpacked
    SCF1WRWG10 = 0x0110007D
    # Sparse Color Filter #1 White-Red-White-Green 10-bit packed
    SCF1WRWG10p = 0x010A007E
    # Sparse Color Filter #1 White-Red-White-Green 12-bit unpacked
    SCF1WRWG12 = 0x0110007F
    # Sparse Color Filter #1 White-Red-White-Green 12-bit packed
    SCF1WRWG12p = 0x010C0080
    # Sparse Color Filter #1 White-Red-White-Green 14-bit unpacked
    SCF1WRWG14 = 0x01100081
    # Sparse Color Filter #1 White-Red-White-Green 16-bit
    SCF1WRWG16 = 0x01100082
    # YCbCr 4:4:4 8-bit
    YCbCr8 = 0x0218005B
    # YCbCr 4:4:4 8-bit
    YCbCr8_CbYCr = 0x0218003A
    # YCbCr 4:4:4 10-bit unpacked
    YCbCr10_CbYCr = 0x02300083
    # YCbCr 4:4:4 10-bit packed
    YCbCr10p_CbYCr = 0x021E0084
    # YCbCr 4:4:4 12-bit unpacked
    YCbCr12_CbYCr = 0x02300085
    # YCbCr 4:4:4 12-bit packed
    YCbCr12p_CbYCr = 0x02240086
    # YCbCr 4:1:1 8-bit
    YCbCr411_8 = 0x020C005A
    # YCbCr 4:1:1 8-bit
    YCbCr411_8_CbYYCrYY = 0x020C003C
    # YCbCr 4:2:2 8-bit
    YCbCr422_8 = 0x0210003B
    # YCbCr 4:2:2 8-bit
    YCbCr422_8_CbYCrY = 0x02100043
    # YCbCr 4:2:2 10-bit unpacked
    YCbCr422_10 = 0x02200065
    # YCbCr 4:2:2 10-bit unpacked
    YCbCr422_10_CbYCrY = 0x02200099
    # YCbCr 4:2:2 10-bit packed
    YCbCr422_10p = 0x02140087
    # YCbCr 4:2:2 10-bit packed
    YCbCr422_10p_CbYCrY = 0x0214009A
    # YCbCr 4:2:2 12-bit unpacked
    YCbCr422_12 = 0x02200066
    # YCbCr 4:2:2 12-bit unpacked
    YCbCr422_12_CbYCrY = 0x0220009B
    # YCbCr 4:2:2 12-bit packed
    YCbCr422_12p = 0x02180088
    # YCbCr 4:2:2 12-bit packed
    YCbCr422_12p_CbYCrY = 0x0218009C
    # YCbCr 4:4:4 8-bit BT.601
    YCbCr601_8_CbYCr = 0x0218003D
    # YCbCr 4:4:4 10-bit unpacked BT.601
    YCbCr601_10_CbYCr = 0x02300089
    # YCbCr 4:4:4 10-bit packed BT.601
    YCbCr601_10p_CbYCr = 0x021E008A
    # YCbCr 4:4:4 12-bit unpacked BT.601
    YCbCr601_12_CbYCr = 0x0230008B
    # YCbCr 4:4:4 12-bit packed BT.601
    YCbCr601_12p_CbYCr = 0x0224008C
    # YCbCr 4:1:1 8-bit BT.601
    YCbCr601_411_8_CbYYCrYY = 0x020C003F
    # YCbCr 4:2:2 8-bit BT.601
    YCbCr601_422_8 = 0x0210003E
    # YCbCr 4:2:2 8-bit BT.601
    YCbCr601_422_8_CbYCrY = 0x02100044
    # YCbCr 4:2:2 10-bit unpacked BT.601
    YCbCr601_422_10 = 0x0220008D
    # YCbCr 4:2:2 10-bit unpacked BT.601
    YCbCr601_422_10_CbYCrY = 0x0220009D
    # YCbCr 4:2:2 10-bit packed BT.601
    YCbCr601_422_10p = 0x0214008E
    # YCbCr 4:2:2 10-bit packed BT.601
    YCbCr601_422_10p_CbYCrY = 0x0214009E
    # YCbCr 4:2:2 12-bit unpacked BT.601
    YCbCr601_422_12 = 0x0220008F
    # YCbCr 4:2:2 12-bit unpacked BT.601
    YCbCr601_422_12_CbYCrY = 0x0220009F
    # YCbCr 4:2:2 12-bit packed BT.601
    YCbCr601_422_12p = 0x02180090
    # YCbCr 4:2:2 12-bit packed BT.601
    YCbCr601_422_12p_CbYCrY = 0x021800A0
    # YCbCr 4:4:4 8-bit BT.709
    YCbCr709_8_CbYCr = 0x02180040
    # YCbCr 4:4:4 10-bit unpacked BT.709
    YCbCr709_10_CbYCr = 0x02300091
    # YCbCr 4:4:4 10-bit packed BT.709
    YCbCr709_10p_CbYCr = 0x021E0092
    # YCbCr 4:4:4 12-bit unpacked BT.709
    YCbCr709_12_CbYCr = 0x02300093
    # YCbCr 4:4:4 12-bit packed BT.709
    YCbCr709_12p_CbYCr = 0x02240094
    # YCbCr 4:1:1 8-bit BT.709
    YCbCr709_411_8_CbYYCrYY = 0x020C0042
    # YCbCr 4:2:2 8-bit BT.709
    YCbCr709_422_8 = 0x02100041
    # YCbCr 4:2:2 8-bit BT.709
    YCbCr709_422_8_CbYCrY = 0x02100045
    # YCbCr 4:2:2 10-bit unpacked BT.709
    YCbCr709_422_10 = 0x02200095
    # YCbCr 4:2:2 10-bit unpacked BT.709
    YCbCr709_422_10_CbYCrY = 0x022000A1
    # YCbCr 4:2:2 10-bit packed BT.709
    YCbCr709_422_10p = 0x02140096
    # YCbCr 4:2:2 10-bit packed BT.709
    YCbCr709_422_10p_CbYCrY = 0x021400A2
    # YCbCr 4:2:2 12-bit unpacked BT.709
    YCbCr709_422_12 = 0x02200097
    # YCbCr 4:2:2 12-bit unpacked BT.709
    YCbCr709_422_12_CbYCrY = 0x022000A3
    # YCbCr 4:2:2 12-bit packed BT.709
    YCbCr709_422_12p = 0x02180098
    # YCbCr 4:2:2 12-bit packed BT.709
    YCbCr709_422_12p_CbYCrY = 0x021800A4
    # YCbCr 4:4:4 8-bit BT.2020
    YCbCr2020_8_CbYCr = 0x021800F4
    # YCbCr 4:4:4 10-bit unpacked BT.2020
    YCbCr2020_10_CbYCr = 0x023000F5
    # YCbCr 4:4:4 10-bit packed BT.2020
    YCbCr2020_10p_CbYCr = 0x021E00F6
    # YCbCr 4:4:4 12-bit unpacked BT.2020 
    YCbCr2020_12_CbYCr = 0x023000F7
    # YCbCr 4:4:4 12-bit packed BT.2020
    YCbCr2020_12p_CbYCr = 0x022400F8
    # YCbCr 4:1:1 8-bit BT.2020
    YCbCr2020_411_8_CbYYCrYY = 0x020C00F9
    # YCbCr 4:2:2 8-bit BT.2020 
    YCbCr2020_422_8 = 0x021000FA
    # YCbCr 4:2:2 8-bit BT.2020
    YCbCr2020_422_8_CbYCrY = 0x021000FB
    # YCbCr 4:2:2 10-bit unpacked BT.2020
    YCbCr2020_422_10 = 0x022000FC
    # YCbCr 4:2:2 10-bit unpacked BT.2020
    YCbCr2020_422_10_CbYCrY = 0x022000FD
    # YCbCr 4:2:2 10-bit packed BT.2020
    YCbCr2020_422_10p = 0x021400FE
    # YCbCr 4:2:2 10-bit packed BT.2020
    YCbCr2020_422_10p_CbYCrY = 0x021400FF
    # YCbCr 4:2:2 12-bit unpacked BT.2020
    YCbCr2020_422_12 = 0x02200100
    # YCbCr 4:2:2 12-bit unpacked BT.2020
    YCbCr2020_422_12_CbYCrY = 0x02200101
    # YCbCr 4:2:2 12-bit packed BT.2020
    YCbCr2020_422_12p = 0x02180102
    # YCbCr 4:2:2 12-bit packed BT.2020
    YCbCr2020_422_12p_CbYCrY = 0x02180103
    # YUV 4:4:4 8-bit
    YUV8_UYV = 0x02180020
    # YUV 4:1:1 8-bit
    YUV411_8_UYYVYY = 0x020C001E
    # YUV 4:2:2 8-bit
    YUV422_8 = 0x02100032
    # YUV 4:2:2 8-bit
    YUV422_8_UYVY = 0x0210001F
    # GigE Vision specific format, Monochrome 10-bit packed
    Mono10Packed = 0x010C0004
    # GigE Vision specific format, Monochrome 12-bit packed
    Mono12Packed = 0x010C0006
    # GigE Vision specific format, Bayer Blue-Green 10-bit packed
    BayerBG10Packed = 0x010C0029
    # GigE Vision specific format, Bayer Blue-Green 12-bit packed
    BayerBG12Packed = 0x010C002D
    # GigE Vision specific format, Bayer Green-Blue 10-bit packed
    BayerGB10Packed = 0x010C0028
    # GigE Vision specific format, Bayer Green-Blue 12-bit packed
    BayerGB12Packed = 0x010C002C
    # GigE Vision specific format, Bayer Green-Red 10-bit packed
    BayerGR10Packed = 0x010C0026
    # GigE Vision specific format, Bayer Green-Red 12-bit packed
    BayerGR12Packed = 0x010C002A
    # GigE Vision specific format, Bayer Red-Green 10-bit packed
    BayerRG10Packed = 0x010C0027
    # GigE Vision specific format, Bayer Red-Green 12-bit packed
    BayerRG12Packed = 0x010C002B
    # GigE Vision specific format, Red-Green-Blue 10-bit packed - variant 1
    RGB10V1Packed = 0x0220001C
    # GigE Vision specific format, Red-Green-Blue 12-bit packed - variant 1
    RGB12V1Packed = 0x02240034
    #
    PolarizeMono8 = 0x81080001
    #
    PolarizeMono12p = 0x810C0047
    #
    PolarizeMono12Packed = 0x810C0006
    #
    PolarizeMono12 = 0x81100008
    #
    PolarizeMono16 = 0x81100007
    #
    PolarizedAngles_0d_45d_90d_135d_Mono8 = 0x8220000F
    #
    PolarizedAngles_0d_45d_90d_135d_Mono12p = 0x8230001F
    #
    PolarizedAngles_0d_45d_90d_135d_Mono16 = 0x8240002F
    #
    PolarizedStokes_S0_S1_S2_Mono8 = 0x8218003F
    #
    PolarizedStokes_S0_S1_S2_Mono12p = 0x8224004F
    #
    PolarizedStokes_S0_S1_S2_Mono16 = 0x8230005F
    #
    PolarizedStokes_S0_S1_S2_S3_Mono8 = 0x8220006F
    #
    PolarizedStokes_S0_S1_S2_S3_Mono12p = 0x8230007F
    #
    PolarizedStokes_S0_S1_S2_S3_Mono16 = 0x8240008F
    #
    PolarizedAolp_Mono8 = 0x810800DF
    #
    PolarizedAolp_Mono12p = 0x810C00EF
    #
    PolarizedDolp_Mono8 = 0x810800BF
    #
    PolarizedDolp_Mono12p = 0x810C00CF
    #
    PolarizedDolp_Mono16 = 0xAA10AAAA
    #
    PolarizedDolpAolp_Mono8 = 0x8210009F
    #
    PolarizedDolpAolp_Mono12p = 0x821800AF
    #
    Coord3D_ABCY16s = 0x82400400
    #
    Coord3D_ABC16s = 0x82300401
    #
    Coord3D_C16s = 0x81100402
    #
    Coord3D_ABCY16 = 0x82400403
    #
    PolarizedAngles_0d_45d_90d_135d_BayerRG8 = 0x8220020F
    #
    PolarizedAngles_0d_45d_90d_135d_BayerRG12p = 0x8230021F
    #
    PolarizedStokes_S0_S1_S2_BayerRG8 = 0x8218023F
    #
    PolarizedStokes_S0_S1_S2_BayerRG12p = 0x8224024F
    #
    PolarizedStokes_S0_S1_S2_S3_BayerRG8 = 0x8220026F
    #
    PolarizedStokes_S0_S1_S2_S3_BayerRG12p = 0x8230027F
    #
    PolarizedAolp_BayerRG8 = 0x810802DF
    #
    PolarizedAolp_BayerRG12p = 0x810C02EF
    #
    PolarizedDolp_BayerRG8 = 0x810802BF
    #
    PolarizedDolp_BayerRG12p = 0x810C02CF
    #
    PolarizedDolp_BayerRG16 = 0xBB10BBBB
    #
    PolarizedDolpAolp_BayerRG8 = 0x8210029F
    #
    PolarizedDolpAolp_BayerRG12p = 0x821802AF
    #
    Mono24 = 0x81180500
    #
    BayerGR24 = 0x81180501
    #
    BayerRG24 = 0x81180502
    #
    BayerGB24 = 0x81180503
    #
    BayerBG24 = 0x81180504
    #
    RGB24 = 0x82480505
    #
    BGR24 = 0x82480506
    #
    YCbCr422_16_CbYCrY = 0x82200507
    #
    YCbCr422_24_CbYCrY = 0x82300508
    #
    YCbCr411_16_CbYYCrYY = 0x82180509
    #
    YCbCr411_24_CbYYCrYY = 0x8224050A
    #
    PolarizedDolpAngle_Mono8 = 0x821000FF
    #
    PolarizedDolpAngle_Mono12p = 0x8218010F
    #
    PolarizedDolpAngle_Mono16 = 0x8220011F
    #
    PolarizedDolpAngle_BayerRG8 = 0x821002FF
    #
    PolarizedDolpAngle_BayerRG12p = 0x8218030F
    #
    PolarizedDolpAngle_BayerRG16 = 0x8220031F
    #
    Coord3D_C16Y8 = 0x82180404
    #
    Coord3D_CY16 = 0x82200405
    #
    QOI_Mono8 = 0x81080A00
    #
    QOI_BayerGR8 = 0x81080B00
    #
    QOI_BayerRG8 = 0x81080B01
    #
    QOI_BayerGB8 = 0x81080B02
    #
    QOI_BayerBG8 = 0x81080B03
    #
    QOI_RGB8 = 0x82180A01
    #
    QOI_BGR8 = 0x82180A02
    #
    QOI_YCbCr8 = 0x82180A03
    #
    QOI_YCbCr8_CbYCr = 0x82180A04
    #
    DualMono8 = 0x81081001
    #
    DualMono10 = 0x81101003
    #
    DualMono10p = 0x810A1046
    #
    DualMono10Packed = 0x810C1004
    #
    DualMono12 = 0x81101005
    #
    DualMono12p = 0x810C1047
    #
    DualMono12Packed = 0x810C1006
    #
    DualMono16 = 0x81101007
    #
    DualBayerRG8 = 0x81081009
    #
    DualBayerRG10 = 0x8110100D
    #
    DualBayerRG10p = 0x810A1058
    #
    DualBayerRG10Packed = 0x810C1027
    #
    DualBayerRG12 = 0x81101011
    #
    DualBayerRG12p = 0x810C1059
    #
    DualBayerRG12Packed = 0x810C102B
    #
    DualBayerRG16 = 0x8110102F
    #
    DualBayerGR8 = 0x81081008
    #
    DualBayerGR10 = 0x8110100C
    #
    DualBayerGR10p = 0x810A1056
    #
    DualBayerGR10Packed = 0x810C1026
    #
    DualBayerGR12 = 0x81101010
    #
    DualBayerGR12p = 0x810C1057
    #
    DualBayerGR12Packed = 0x810C102A
    #
    DualBayerGR16 = 0x8110102E
    #
    DualBayerBG8 = 0x8108100B
    #
    DualBayerBG10 = 0x8110100F
    #
    DualBayerBG10p = 0x810A1052
    #
    DualBayerBG10Packed = 0x810C1029
    #
    DualBayerBG12 = 0x81101013
    #
    DualBayerBG12p = 0x810C1053
    #
    DualBayerBG12Packed = 0x810C102D
    #
    DualBayerBG16 = 0x81101031
    #
    DualBayerGB8 = 0x8108100A
    #
    DualBayerGB10 = 0x8110100E
    #
    DualBayerGB10p = 0x810A1054
    #
    DualBayerGB10Packed = 0x810C1028
    #
    DualBayerGB12 = 0x81101012
    #
    DualBayerGB12p = 0x810C1055
    #
    DualBayerGB12Packed = 0x810C102C
    #
    DualBayerGB16 = 0x81101030
    #
    QuadMono8 = 0x81083001
    #
    QuadMono10 = 0x81103003
    #
    QuadMono10p = 0x810A3046
    #
    QuadMono10Packed = 0x810C3004
    #
    QuadMono12 = 0x81103005
    #
    QuadMono12p = 0x810C3047
    #
    QuadMono12Packed = 0x810C3006
    #
    QuadMono16 = 0x81103007
    #
    QuadBayerRG8 = 0x81083009
    #
    QuadBayerRG10 = 0x8110300D
    #
    QuadBayerRG10p = 0x810A3058
    #
    QuadBayerRG10Packed = 0x810C3027
    #
    QuadBayerRG12 = 0x81103011
    #
    QuadBayerRG12p = 0x810C3059
    #
    QuadBayerRG12Packed = 0x810C302B
    #
    QuadBayerRG16 = 0x8110302F
    #
    QuadBayerGR8 = 0x81083008
    #
    QuadBayerGR10 = 0x8110300C
    #
    QuadBayerGR10p = 0x810A3056
    #
    QuadBayerGR10Packed = 0x810C3026
    #
    QuadBayerGR12 = 0x81103010
    #
    QuadBayerGR12p = 0x810C3057
    #
    QuadBayerGR12Packed = 0x810C302A
    #
    QuadBayerGR16 = 0x8110302E
    #
    QuadBayerBG8 = 0x8108300B
    #
    QuadBayerBG10 = 0x8110300F
    #
    QuadBayerBG10p = 0x810A3052
    #
    QuadBayerBG10Packed = 0x810C3029
    #
    QuadBayerBG12 = 0x81103013
    #
    QuadBayerBG12p = 0x810C3053
    #
    QuadBayerBG12Packed = 0x810C302D
    #
    QuadBayerBG16 = 0x81103031
    #
    QuadBayerGB8 = 0x8108300A
    #
    QuadBayerGB10 = 0x8110300E
    #
    QuadBayerGB10p = 0x810A3054
    #
    QuadBayerGB10Packed = 0x810C3028
    #
    QuadBayerGB12 = 0x81103012
    #
    QuadBayerGB12p = 0x810C3055
    #
    QuadBayerGB12Packed = 0x810C302C
    #
    QuadBayerGB16 = 0x81103030
    #
    CFA1by2_RB8 = 0x81080012
    #
    CFA1by2_RB10 = 0x8110001a
    #
    CFA1by2_RB10p = 0x810a005f
    #
    CFA1by2_RB10Packed = 0x810c0034
    #
    CFA1by2_RB12 = 0x81100046
    #
    CFA1by2_RB12p = 0x810c0060
    #
    CFA1by2_RB12Packed = 0x810c0076
    #
    CFA1by2_RB16 = 0x81100038
    #
    CFA1by2_BR8 = 0x81080013
    #
    CFA1by2_BR10 = 0x8110001b
    #
    CFA1by2_BR10p = 0x810a0060
    #
    CFA1by2_BR10Packed = 0x810c0035
    #
    CFA1by2_BR12 = 0x81100047
    #
    CFA1by2_BR12p = 0x810c0061
    #
    CFA1by2_BR12Packed = 0x810c0077
    #
    CFA1by2_BR16 = 0x81100039
    #
    CFA_RBGG8 = 0x8108000c
    #
    CFA_RBGG10 = 0x81100014
    #
    CFA_RBGG10p = 0x810a0059
    #
    CFA_RBGG10Packed = 0x810c002e
    #
    CFA_RBGG12 = 0x81100040
    #
    CFA_RBGG12p = 0x810c005a
    #
    CFA_RBGG12Packed = 0x810c0070
    #
    CFA_RBGG16 = 0x81100032
    #
    CFA_BRGG8 = 0x8108000d
    #
    CFA_BRGG10 = 0x81100015
    #
    CFA_BRGG10p = 0x810a005a
    #
    CFA_BRGG10Packed = 0x810c002f
    #
    CFA_BRGG12 = 0x81100041
    #
    CFA_BRGG12p = 0x810c005b
    #
    CFA_BRGG12Packed = 0x810c0071
    #
    CFA_BRGG16 = 0x81100033
    #
    CFA_GGRB8 = 0x8108000e
    #
    CFA_GGRB10 = 0x81100016
    #
    CFA_GGRB10p = 0x810a005b
    #
    CFA_GGRB10Packed = 0x810c0030
    #
    CFA_GGRB12 = 0x81100042
    #
    CFA_GGRB12p = 0x810c005c
    #
    CFA_GGRB12Packed = 0x810c0072
    #
    CFA_GGRB16 = 0x81100034
    #
    CFA_GGBR8 = 0x8108000f
    #
    CFA_GGBR10 = 0x81100017
    #
    CFA_GGBR10p = 0x810a005c
    #
    CFA_GGBR10Packed = 0x810c0031
    #
    CFA_GGBR12 = 0x81100043
    #
    CFA_GGBR12p = 0x810c005d
    #
    CFA_GGBR12Packed = 0x810c0073
    #
    CFA_GGBR16 = 0x81100035
    #
    CFA2by1_WB8 = 0x81080014
    #
    CFA2by1_WB10 = 0x8110001c
    #
    CFA2by1_WB10p = 0x810a0061
    #
    CFA2by1_WB10Packed = 0x810c0036
    #
    CFA2by1_WB12 = 0x81100048
    #
    CFA2by1_WB12p = 0x810c0062
    #
    CFA2by1_WB12Packed = 0x810c0078
    #
    CFA2by1_WB16 = 0x8110003a
    #
    CFA2by1_BW8 = 0x81080015
    #
    CFA2by1_BW10 = 0x8110001d
    #
    CFA2by1_BW10p = 0x810a0062
    #
    CFA2by1_BW10Packed = 0x810c0037
    #
    CFA2by1_BW12 = 0x81100049
    #
    CFA2by1_BW12p = 0x810c0063
    #
    CFA2by1_BW12Packed = 0x810c0079
    #
    CFA2by1_BW16 = 0x8110003b
    #
    CFA4by1_WBGR8 = 0x81080010
    #
    CFA4by1_WBGR10 = 0x81100018
    #
    CFA4by1_WBGR10p = 0x810a005d
    #
    CFA4by1_WBGR10Packed = 0x810c0032
    #
    CFA4by1_WBGR12 = 0x81100044
    #
    CFA4by1_WBGR12p = 0x810c005e
    #
    CFA4by1_WBGR12Packed = 0x810c0074
    #
    CFA4by1_WBGR16 = 0x81100036
    #
    CFA4by1_RGBW8 = 0x81080011
    #
    CFA4by1_RGBW10 = 0x81100019
    #
    CFA4by1_RGBW10p = 0x810a005e
    #
    CFA4by1_RGBW10Packed = 0x810c0033
    #
    CFA4by1_RGBW12 = 0x81100045
    #
    CFA4by1_RGBW12p = 0x810c005f
    #
    CFA4by1_RGBW12Packed = 0x810c0075
    #
    CFA4by1_RGBW16 = 0x81100037
    #
    RGBY8 = 0x82200001
    #
    BGRY8 = 0x82200002
    # polar, unpacked, non-unique identifier
    PolarizedAngles_0d_45d_90d_135d_Mono12 = 0x8240001F
    # polar, unpacked, non-unique identifier
    PolarizedStokes_S0_S1_S2_S3_Mono12 = 0x8240007F
    # polar, unpacked, non-unique identifier
    PolarizedAolp_Mono12 = 0x811000EF
    # polar, unpacked, non-unique identifier
    PolarizedDolp_Mono12 = 0x811000CF
    # polar, unpacked, non-unique identifier
    PolarizedDolpAolp_Mono12 = 0x822000AF
    # 3d, 16-to-8-bit, non-unique-identifier
    Coord3D_ABCY8 = 0x82200403
    # 3d, 16-to-8-bit, non-unique-identifier
    Coord3D_CY8 = 0x82100404
    # 3d, 32-to-16-bit, non-unique-identifier
    Coord3D_Y16 = 0x82100405
    # polar, unpacked, non-unique identifier
    PolarizedAngles_0d_45d_90d_135d_BayerRG12 = 0x8240021F
    # polar, unpacked, non-unique identifier
    PolarizedStokes_S0_S1_S2_S3_BayerRG12 = 0x8240027F
    # polar, unpacked, non-unique identifier
    PolarizedAolp_BayerRG12 = 0x811002EF
    # polar, unpacked, non-unique identifier
    PolarizedDolp_BayerRG12 = 0x811002CF
    # polar, unpacked, non-unique identifier
    PolarizedDolpAolp_BayerRG12 = 0x822002AF
    # yuv-490, unpacked, non-unique identifier
    YCbCr16_CbYCr = 0x82300507
    # yuv-490, unpacked, non-unique identifier
    YCbCr24_CbYCr = 0x82480508
    #
    DualMono8_2ch = 0x81101001
    #
    DualMono10_2ch = 0x81201003
    #
    DualMono12_2ch = 0x81201005
    #
    DualMono16_2ch = 0x81201007
    #
    DualBayerRG8_2ch = 0x81101009
    #
    DualBayerRG10_2ch = 0x8120100D
    #
    DualBayerRG12_2ch = 0x81201011
    #
    DualBayerRG16_2ch = 0x8120102F
    #
    DualBayerGR8_2ch = 0x81101008
    #
    DualBayerGR10_2ch = 0x8120100C
    #
    DualBayerGR12_2ch = 0x81201010
    #
    DualBayerGR16_2ch = 0x8120102E
    #
    DualBayerBG8_2ch = 0x8110100B
    #
    DualBayerBG10_2ch = 0x8120100F
    #
    DualBayerBG12_2ch = 0x81201013
    #
    DualBayerBG16_2ch = 0x81201031
    #
    DualBayerGB8_2ch = 0x8110100A
    #
    DualBayerGB10_2ch = 0x8120100E
    #
    DualBayerGB12_2ch = 0x81201012
    #
    DualBayerGB16_2ch = 0x81201030
    #
    QuadMono8_4ch = 0x81203001
    #
    QuadMono10_4ch = 0x81403003
    #
    QuadMono12_4ch = 0x81403005
    #
    QuadMono16_4ch = 0x81403007
    #
    QuadBayerRG8_4ch = 0x81203009
    #
    QuadBayerRG10_4ch = 0x8140300D
    #
    QuadBayerRG12_4ch = 0x81403011
    #
    QuadBayerRG16_4ch = 0x8140302F
    #
    QuadBayerGR8_4ch = 0x81203008
    #
    QuadBayerGR10_4ch = 0x8140300C
    #
    QuadBayerGR12_4ch = 0x81403010
    #
    QuadBayerGR16_4ch = 0x8140302E
    #
    QuadBayerBG8_4ch = 0x8120300B
    #
    QuadBayerBG10_4ch = 0x8140300F
    #
    QuadBayerBG12_4ch = 0x81403013
    #
    QuadBayerBG16_4ch = 0x81403031
    #
    QuadBayerGB8_4ch = 0x8120300A
    #
    QuadBayerGB10_4ch = 0x8140300E
    #
    QuadBayerGB12_4ch = 0x81403012
    #
    QuadBayerGB16_4ch = 0x81403030
    #
    LucidXYTP128f = 0x82804556
    #
    InvalidPixelFormat = 0

    def get_bits_per_pixel(pixel_format):

        bits_per_pixel = _xGlobal.xGetGetBitsPerPixel(pixel_format)
        return bits_per_pixel
