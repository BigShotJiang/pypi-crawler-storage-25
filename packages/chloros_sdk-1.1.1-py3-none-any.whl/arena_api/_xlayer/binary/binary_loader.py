# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import os
from ctypes import CDLL, RTLD_GLOBAL
from pathlib import Path

from arena_api._xlayer.info import Info

_info = Info()


class BinaryLoaderWindows:

    def load(self, pathname,
             config):  # config would not be used; it is there for linux

        original_work_dir = os.getcwd()
        os.chdir(pathname.parent)

        handle = CDLL(str(pathname))

        os.chdir(original_work_dir)

        return handle


class BinaryLoaderLinux:

    def load(self, pathname, config):

        global _info
        dependencies_sos = None

        # If softwarelib exist - debug mode

        # Specify path
        path_GenICam_linux = '/mnt/c/softwarelib/GenICam//genicam_3_3_0_RC2/Linux64_x64/bin/libGCBase_gcc54_v3_3_LUCID.so'
        path_GenICam_arm = '/mnt/c/softwarelib/GenICam//genicam_3_3_0_RC2/Linux64_ARM/bin/libGCBase_gcc54_v3_3_LUCID.so'
        
        # Check whether the specified
        # path exists or not
        is_path_GenICam_Linux_Exist = os.path.exists(path_GenICam_linux)
        is_path_GenICam_ARM_Exist = os.path.exists(path_GenICam_arm)

        # linux 64
        if not _info.is_arm:  # 32 linux is only arm
            dependencies_sos = config['dependencies_sos_lin']
            if is_path_GenICam_Linux_Exist:
                dependencies_sos = config['dependencies_sos_lin_local']

        # arm 64
        elif _info.is_arm and _info.is_py64:
            dependencies_sos = config['dependencies_sos_arm64']
            if is_path_GenICam_ARM_Exist:
                dependencies_sos = config['dependencies_sos_arm64_local']

        # arm 32
        elif _info.is_arm and not _info.is_py64:
            dependencies_sos = config['dependencies_sos_armhf']

        bin_root = pathname.parent
        for so_relative_pathname in dependencies_sos:
            full_path = (bin_root/so_relative_pathname).resolve()
            if not full_path.exists():
                # Bundled/flat layout: all .so files in same directory
                fallback = bin_root / Path(so_relative_pathname).name
                if fallback.exists():
                    full_path = fallback.resolve()
            CDLL(str(full_path), mode=RTLD_GLOBAL)

        handle = CDLL(pathname, mode=RTLD_GLOBAL)
        return handle


class BinaryLoader:
    def __init__(self, config):

        global _info
        self._config = config
        self._loader = None

        if _info.is_windows:
            self._loader = BinaryLoaderWindows()
        else:
            self._loader = BinaryLoaderLinux()

    def load(self, pathname):
        return self._loader.load(pathname, self._config)
