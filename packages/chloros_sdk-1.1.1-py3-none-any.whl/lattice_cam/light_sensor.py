"""DAQ-M BLE light sensor (DLS - Downwelling Light Sensor) integration.

Communicates with a DAQ-M Bluetooth spectral sensor to
measure downwelling irradiance for real-time NDVI illumination correction.

Protocol ported from the BLE protocol reference implementation and the
vendor SDK.
"""

import asyncio
import logging
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Optional, Tuple

import numpy as np

try:
    from bleak import BleakClient, BleakScanner
    _BLEAK_AVAILABLE = True
except ImportError:
    _BLEAK_AVAILABLE = False

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

NUM_SPECTRUM_POINTS = 135

# Default filter wavelengths: RGN (Red 660nm, Green 550nm, NIR 850nm)
# Channel mapping: BGR[2]=Red(660nm), BGR[1]=Green(550nm), BGR[0]=NIR(850nm)
DEFAULT_FILTER_WAVELENGTHS = (660.0, 550.0, 850.0)

# Filter wavelengths per filter type (red_nm, green_nm, nir_nm)
FILTER_WAVELENGTHS = {
    "660/550/850":            (660.0, 550.0, 850.0),
    "660/550/850_imx265":     (660.0, 550.0, 850.0),
    "660/550/850_imx265_l41": (660.0, 550.0, 850.0),
    "615/490/808":            (615.0, 490.0, 808.0),
    "615/490/808_imx265":     (615.0, 490.0, 808.0),
    "615/490/808_imx265_l41": (615.0, 490.0, 808.0),
    "850/550/475":            (850.0, 550.0, 475.0),
    "850/550/475_imx265":     (850.0, 550.0, 475.0),
    "850/550/475_imx265_l41": (850.0, 550.0, 475.0),
    "725":                    (725.0, 725.0, 725.0),
    "850":                    (850.0, 850.0, 850.0),
}


@dataclass
class SpectrumReading:
    """Single spectrum measurement from the DAQ-M sensor."""
    wavelengths: np.ndarray          # 135 wavelength values (nm)
    intensities: np.ndarray          # 135 spectral intensity values
    integration_time: int = 0        # ms
    is_saturated: bool = False
    xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    timestamp: float = 0.0          # time.time()

    # Derived irradiance at filter wavelengths (interpolated from spectrum)
    irradiance_red: float = 0.0     # e.g. 660nm
    irradiance_green: float = 0.0   # e.g. 550nm
    irradiance_nir: float = 0.0     # e.g. 850nm


@dataclass
class SensorStatus:
    """Current sensor connection/acquisition state."""
    connected: bool = False
    connecting: bool = False
    device_name: str = ""
    device_address: str = ""
    readings_count: int = 0
    last_error: str = ""
    acquisition_interval: float = 2.0  # seconds between acquisitions


# ---------------------------------------------------------------------------
# DAQ-M protocol constants (from the BLE protocol reference implementation)
# ---------------------------------------------------------------------------

# Fragments of the BLE advertised name published by DAQ-M firmware.
# Matched internally only; never surfaced in user output.
_DAQ_M_BLE_NAME_FRAGMENTS = ("DAQ-M", "MAPIR", "NSP32")


def _is_daq_m_ble_name(name):
    return bool(name) and any(tag in name for tag in _DAQ_M_BLE_NAME_FRAGMENTS)

_PREFIX0 = 0x03
_PREFIX1 = 0xBB

_CMD_HELLO          = 0x01
_CMD_GET_WAVELENGTH = 0x24
_CMD_ACQ_SPECTRUM   = 0x26
_CMD_GET_SPECTRUM   = 0x28

_CMD_LENGTHS = {
    _CMD_HELLO:          5,
    _CMD_GET_WAVELENGTH: 5,
    _CMD_ACQ_SPECTRUM:   10,
    _CMD_GET_SPECTRUM:   5,
}

_RETURN_LENGTHS = {
    _CMD_HELLO:          5,
    _CMD_GET_WAVELENGTH: 279,
    _CMD_ACQ_SPECTRUM:   5,
    _CMD_GET_SPECTRUM:   565,
}

# BLE UUIDs (Nordic UART Service)
_SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca3e"
_TX_CHAR_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca3e"  # Write to device
_RX_CHAR_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca3e"  # Read from device

_DEFAULT_MAC = "EC:4C:E9:15:3E:D2"


# ---------------------------------------------------------------------------
# Protocol helpers
# ---------------------------------------------------------------------------

def _checksum(data: bytes) -> int:
    """Two's complement checksum (from official Dart SDK)."""
    return ((~sum(data)) + 1) & 0xFF


def _build_command(cmd_code: int, user_code: int = 0, data: bytes = b'') -> bytes:
    """Build a DAQ-M command packet."""
    cmd_length = _CMD_LENGTHS.get(cmd_code, 5)
    buf = bytearray(cmd_length)
    buf[0] = _PREFIX0
    buf[1] = _PREFIX1
    buf[2] = cmd_code
    buf[3] = user_code & 0xFF
    for i, b in enumerate(data):
        if 4 + i < cmd_length - 1:
            buf[4 + i] = b
    buf[cmd_length - 1] = _checksum(buf[:cmd_length - 1])
    return bytes(buf)


def _validate_checksum(data: bytes) -> bool:
    """Validate a received packet's checksum."""
    return (sum(data) & 0xFF) == 0


def _parse_wavelength(packet: bytes) -> np.ndarray:
    """Parse GET_WAVELENGTH response -> array of wavelengths in nm."""
    num_points = struct.unpack('<I', packet[4:8])[0]
    wavelengths = struct.unpack('<' + 'H' * num_points,
                                packet[8:8 + num_points * 2])
    return np.array(wavelengths, dtype=np.float64)


def _parse_spectrum(packet: bytes) -> Tuple[int, bool, np.ndarray, Tuple[float, float, float]]:
    """Parse GET_SPECTRUM response.

    Returns (integration_time, is_saturated, spectrum_array, (X, Y, Z)).
    """
    int_time = struct.unpack('<H', packet[4:6])[0]
    saturated = packet[6] == 1
    num_points = struct.unpack('<I', packet[8:12])[0]
    spectrum = np.array(
        struct.unpack('<' + 'f' * num_points, packet[12:12 + num_points * 4]),
        dtype=np.float64)
    offset = 12 + NUM_SPECTRUM_POINTS * 4
    x = struct.unpack('<f', packet[offset:offset + 4])[0]
    y = struct.unpack('<f', packet[offset + 4:offset + 8])[0]
    z = struct.unpack('<f', packet[offset + 8:offset + 12])[0]
    return int_time, saturated, spectrum, (x, y, z)


def _interpolate_at(wavelengths: np.ndarray, spectrum: np.ndarray,
                    target_nm: float) -> float:
    """Linear interpolation of spectrum at a specific wavelength."""
    idx = np.searchsorted(wavelengths, target_nm)
    if idx <= 0:
        return float(spectrum[0])
    if idx >= len(wavelengths):
        return float(spectrum[-1])
    w0, w1 = wavelengths[idx - 1], wavelengths[idx]
    s0, s1 = spectrum[idx - 1], spectrum[idx]
    t = (target_nm - w0) / (w1 - w0) if w1 != w0 else 0.0
    return float(s0 + t * (s1 - s0))


# ---------------------------------------------------------------------------
# LightSensor class
# ---------------------------------------------------------------------------

class LightSensor:
    """Thread-safe DAQ-M BLE light sensor manager.

    Runs BLE communication on a dedicated daemon thread with its own asyncio
    event loop (same pattern as _GrabWorker in viewer.py).  The main viewer
    thread calls ``connect()``/``disconnect()`` which submit coroutines via
    ``asyncio.run_coroutine_threadsafe()``.
    """

    def __init__(self, mac_address: str = _DEFAULT_MAC,
                 acquisition_interval: float = 0.0):
        self._mac = mac_address
        self._interval = acquisition_interval

        # Thread-safe state
        self._lock = threading.Lock()
        self._latest_reading: Optional[SpectrumReading] = None
        self._status = SensorStatus(acquisition_interval=acquisition_interval)

        # Async internals (created on worker thread)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._client: Optional['BleakClient'] = None
        self._wavelengths: Optional[np.ndarray] = None

        # Control flags
        self._running = False
        self._stop_event: Optional[asyncio.Event] = None

        # BLE response assembly (buffer managed by notify callback only)
        self._resp_buf = bytearray(1000)
        self._resp_idx = 0
        self._resp_event: Optional[asyncio.Event] = None
        self._resp_cmd: int = 0       # command code of last complete packet
        self._resp_packet: bytes = b''  # last complete packet bytes

        # Filter wavelengths (red, green, nir)
        self._filter_wavelengths = DEFAULT_FILTER_WAVELENGTHS

    # -- Public thread-safe properties --

    @property
    def latest_reading(self) -> Optional[SpectrumReading]:
        with self._lock:
            return self._latest_reading

    @property
    def status(self) -> SensorStatus:
        with self._lock:
            return SensorStatus(
                connected=self._status.connected,
                connecting=self._status.connecting,
                device_name=self._status.device_name,
                device_address=self._status.device_address,
                readings_count=self._status.readings_count,
                last_error=self._status.last_error,
                acquisition_interval=self._status.acquisition_interval,
            )

    def set_filter_wavelengths(self, filter_type: str):
        """Update interpolation wavelengths when filter model changes."""
        wl = FILTER_WAVELENGTHS.get(filter_type, DEFAULT_FILTER_WAVELENGTHS)
        with self._lock:
            self._filter_wavelengths = wl

    # -- Connect / disconnect (called from main thread) --

    def connect(self):
        """Start BLE connection (non-blocking)."""
        if not _BLEAK_AVAILABLE:
            with self._lock:
                self._status.last_error = "bleak not installed"
            logger.error("bleak package not installed — pip install bleak")
            return

        if self._thread and self._thread.is_alive():
            return  # already running

        self._running = True
        with self._lock:
            self._status.connecting = True
            self._status.last_error = ""
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    def disconnect(self):
        """Request disconnection and wait for worker to finish."""
        self._running = False
        if self._loop and self._stop_event:
            self._loop.call_soon_threadsafe(self._stop_event.set)
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        with self._lock:
            self._status.connected = False
            self._status.connecting = False
            self._latest_reading = None  # clear cached reading

    # -- Worker thread --

    def _worker(self):
        """Daemon thread entry: create event loop and run async logic."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._async_main())
        except Exception as exc:
            logger.error(f"LightSensor worker error: {exc}")
            with self._lock:
                self._status.last_error = str(exc)
        finally:
            # Drain pending callbacks so bleak's winrt session handler
            # doesn't fire after the loop is closed.
            try:
                self._loop.run_until_complete(asyncio.sleep(0.1))
            except Exception:
                pass
            self._loop.close()
            self._loop = None
            with self._lock:
                self._status.connected = False
                self._status.connecting = False

    async def _async_main(self):
        """Top-level async: connect, init, run acquisition loop."""
        self._stop_event = asyncio.Event()
        self._resp_event = asyncio.Event()

        with self._lock:
            self._status.connecting = True
            self._status.last_error = ""

        # -- Discover / connect --
        address = await self._find_device()
        if address is None:
            with self._lock:
                self._status.connecting = False
                self._status.last_error = "DAQ-M device not found"
            logger.error("DAQ-M device not found during scan")
            return

        try:
            self._client = BleakClient(
                address, winrt={"use_cached_services": False})
            await self._client.connect(timeout=10.0)
        except Exception as exc:
            # Direct MAC failed — fall back to BLE scan
            logger.info(f"Direct connect to {address} failed ({exc}), scanning...")
            address = await self._scan_for_device()
            if address is None:
                with self._lock:
                    self._status.connecting = False
                    self._status.last_error = "DAQ-M not found after scan"
                logger.error("DAQ-M not found after scan")
                return
            try:
                self._client = BleakClient(
                    address, winrt={"use_cached_services": False})
                await self._client.connect(timeout=10.0)
            except Exception as exc2:
                with self._lock:
                    self._status.connecting = False
                    self._status.last_error = f"BLE connect failed: {exc2}"
                logger.error(f"BLE connect failed: {exc2}")
                return

        try:
            await self._client.start_notify(_RX_CHAR_UUID,
                                            self._on_ble_notify)
        except Exception as exc:
            with self._lock:
                self._status.connecting = False
                self._status.last_error = f"BLE notify failed: {exc}"
            logger.error(f"BLE notify setup failed: {exc}")
            return

        with self._lock:
            self._status.connected = True
            self._status.connecting = False
            self._status.device_address = address

        logger.info(f"Connected to DAQ-M at {address}")

        try:
            await self._init_and_run()
        except Exception as exc:
            logger.error(f"DAQ-M init/acquisition error: {exc}")
            with self._lock:
                self._status.last_error = str(exc)
        finally:
            await self._safe_disconnect()

    async def _init_sensor(self):
        """Send HELLO + GET_WAVELENGTH initialization sequence."""
        await self._send_and_wait(_CMD_HELLO)
        logger.info("DAQ-M HELLO OK")

        await self._send_and_wait(_CMD_GET_WAVELENGTH)
        self._wavelengths = _parse_wavelength(self._resp_packet)
        logger.info(f"Wavelengths received: {len(self._wavelengths)} points, "
                    f"{self._wavelengths[0]:.0f}-{self._wavelengths[-1]:.0f} nm")

    async def _safe_disconnect(self):
        """Stop notifications and disconnect, suppressing errors."""
        if self._client:
            try:
                if self._client.is_connected:
                    try:
                        await self._client.stop_notify(_RX_CHAR_UUID)
                    except Exception:
                        pass
                    await self._client.disconnect()
            except Exception:
                pass
            self._client = None

    async def _reconnect(self) -> bool:
        """Attempt to reconnect to the sensor. Returns True on success."""
        with self._lock:
            self._status.connected = False
            self._status.connecting = True
            self._status.last_error = "Reconnecting..."
        logger.info("BLE connection lost, attempting reconnect...")

        await self._safe_disconnect()

        _MAX_ATTEMPTS = 5
        for attempt in range(_MAX_ATTEMPTS):
            if not self._running or self._stop_event.is_set():
                return False
            backoff = 3.0 * (attempt + 1)
            logger.info(f"Reconnect attempt {attempt + 1}/{_MAX_ATTEMPTS} "
                        f"(waiting {backoff:.0f}s)...")
            try:
                await asyncio.wait_for(self._stop_event.wait(),
                                       timeout=backoff)
                return False  # stop requested
            except asyncio.TimeoutError:
                pass

            try:
                address = await self._find_device()
                if address is None:
                    continue
                self._client = BleakClient(
                    address, winrt={"use_cached_services": False})
                await self._client.connect(timeout=10.0)
                await self._client.start_notify(_RX_CHAR_UUID,
                                                self._on_ble_notify)
                await self._init_sensor()

                with self._lock:
                    self._status.connected = True
                    self._status.connecting = False
                    self._status.device_address = address
                    self._status.last_error = ""
                logger.info(f"Reconnected to DAQ-M at {address}")
                return True
            except Exception as exc:
                logger.warning(f"Reconnect attempt {attempt + 1} failed: {exc}")
                await self._safe_disconnect()

        with self._lock:
            self._status.connecting = False
            self._status.last_error = f"Reconnect failed after {_MAX_ATTEMPTS} attempts"
        logger.error(f"Reconnect failed after {_MAX_ATTEMPTS} attempts")
        return False

    async def _init_and_run(self):
        """Initialization sequence + acquisition loop with auto-reconnect."""
        await self._init_sensor()
        consecutive_errors = 0

        while self._running and not self._stop_event.is_set():
            # Check BLE connection health before acquiring
            if not self._client or not self._client.is_connected:
                if not await self._reconnect():
                    break
                consecutive_errors = 0
                continue

            try:
                await self._acquire_once()
                consecutive_errors = 0
            except Exception as exc:
                consecutive_errors += 1
                with self._lock:
                    self._status.last_error = str(exc)

                # Log only the first error, then every 10th to reduce spam
                if consecutive_errors == 1:
                    logger.warning(f"Acquisition error: {exc}")
                elif consecutive_errors % 10 == 0:
                    logger.warning(f"Acquisition error (x{consecutive_errors}): {exc}")

                # If multiple consecutive errors, likely disconnected
                if consecutive_errors >= 3:
                    if not await self._reconnect():
                        break
                    consecutive_errors = 0
                    continue
                else:
                    # Brief pause before retry
                    try:
                        await asyncio.wait_for(self._stop_event.wait(),
                                               timeout=1.0)
                        break
                    except asyncio.TimeoutError:
                        pass
                    continue

            # Sleep with early exit on stop
            try:
                await asyncio.wait_for(self._stop_event.wait(),
                                       timeout=self._interval)
                break  # stop_event was set
            except asyncio.TimeoutError:
                pass  # normal timeout, loop again

    async def _find_device(self) -> Optional[str]:
        """Return best address to connect to (MAC or scanned)."""
        # If a MAC was provided, just return it — the caller will attempt the
        # real connection and we avoid a slow test-connect round-trip.
        if self._mac:
            with self._lock:
                self._status.device_name = "DAQ-M"
            return self._mac
        # No MAC: scan by name
        return await self._scan_for_device()

    async def _scan_for_device(self) -> Optional[str]:
        """BLE scan for the DAQ-M device by advertised name."""
        try:
            logger.info("Scanning for DAQ-M devices...")
            devices = await BleakScanner.discover(timeout=8.0)
            for dev in devices:
                if _is_daq_m_ble_name(dev.name):
                    with self._lock:
                        self._status.device_name = dev.name
                    logger.info(f"Found {dev.name} at {dev.address}")
                    return dev.address
        except Exception as exc:
            logger.warning(f"BLE scan error: {exc}")
        return None

    # -- BLE send/receive --

    async def _send_and_wait(self, cmd_code: int, user_code: int = 0,
                             data: bytes = b'', timeout: float = 10.0):
        """Send command and wait for complete response packet."""
        self._resp_idx = 0
        self._resp_event.clear()
        self._resp_cmd = cmd_code

        packet = _build_command(cmd_code, user_code, data)
        await self._client.write_gatt_char(_TX_CHAR_UUID, packet)

        try:
            await asyncio.wait_for(self._resp_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            raise TimeoutError(f"No response for cmd 0x{cmd_code:02X}")

    def _on_ble_notify(self, sender, data: bytes):
        """BLE notification callback — assembles multi-packet responses.

        Handles back-to-back packets (e.g. ACQ ACK immediately followed by
        the auto-returned spectrum) by shifting remaining bytes to the front
        of the buffer after each complete packet is extracted.
        """
        for byte in data:
            if self._resp_idx < len(self._resp_buf):
                self._resp_buf[self._resp_idx] = byte
                self._resp_idx += 1

        # Extract complete packets (loop handles back-to-back)
        while self._resp_idx >= 3:
            cmd_in_buf = self._resp_buf[2]
            expected = _RETURN_LENGTHS.get(cmd_in_buf, 5)
            if self._resp_idx >= expected:
                pkt = bytes(self._resp_buf[:expected])
                # Shift any remaining bytes (next packet's start) to front
                remaining = self._resp_idx - expected
                if remaining > 0:
                    self._resp_buf[:remaining] = self._resp_buf[expected:expected + remaining]
                self._resp_idx = remaining

                if not _validate_checksum(pkt):
                    logger.warning(f"Checksum invalid for cmd 0x{cmd_in_buf:02X}")
                self._resp_packet = pkt
                self._resp_cmd = cmd_in_buf
                if self._resp_event and self._loop:
                    self._loop.call_soon_threadsafe(self._resp_event.set)
            else:
                break  # need more data

    # -- Spectrum acquisition --

    async def _acquire_once(self):
        """Run one ACQ_SPECTRUM cycle with active_return=1.

        The device sends the ACK (5 bytes, cmd 0x26) immediately, then
        auto-returns the spectrum (565 bytes, cmd 0x28) once the measurement
        is complete.  The notify handler's buffer-shift logic handles the
        back-to-back packets cleanly.
        """
        # ACQ_SPECTRUM with active_return=1
        acq_data = struct.pack('<HBBb',
                               0,    # integration_time=0 (auto)
                               20,   # frame_avg=20 (matches DAQ default)
                               1,    # enable_ae=1
                               1)    # active_return=1

        self._resp_idx = 0
        self._resp_event.clear()

        packet = _build_command(_CMD_ACQ_SPECTRUM, 0, acq_data)
        await self._client.write_gatt_char(_TX_CHAR_UUID, packet)

        # Wait for first complete packet (ACK or spectrum)
        await asyncio.wait_for(self._resp_event.wait(), timeout=10.0)

        if self._resp_cmd == _CMD_ACQ_SPECTRUM:
            # Got ACK — spectrum still incoming.  Wait for it.
            self._resp_event.clear()
            await asyncio.wait_for(self._resp_event.wait(), timeout=15.0)

        if self._resp_cmd != _CMD_GET_SPECTRUM:
            raise ValueError(f"Expected GET_SPECTRUM (0x28), "
                             f"got 0x{self._resp_cmd:02X}")

        int_time, saturated, spectrum, xyz = _parse_spectrum(self._resp_packet)

        # Interpolate at filter wavelengths
        with self._lock:
            wl = self._filter_wavelengths

        irr_red = _interpolate_at(self._wavelengths, spectrum, wl[0])
        irr_green = _interpolate_at(self._wavelengths, spectrum, wl[1])
        irr_nir = _interpolate_at(self._wavelengths, spectrum, wl[2])

        reading = SpectrumReading(
            wavelengths=self._wavelengths.copy(),
            intensities=spectrum,
            integration_time=int_time,
            is_saturated=saturated,
            xyz=xyz,
            timestamp=time.time(),
            irradiance_red=irr_red,
            irradiance_green=irr_green,
            irradiance_nir=irr_nir,
        )

        with self._lock:
            self._latest_reading = reading
            self._status.readings_count += 1
            if saturated:
                self._status.last_error = "Sensor saturated"
            else:
                self._status.last_error = ""

        logger.debug(f"Spectrum #{self._status.readings_count}: "
                     f"R={irr_red:.4f} G={irr_green:.4f} NIR={irr_nir:.4f} "
                     f"int={int_time}ms sat={saturated}")


# ---------------------------------------------------------------------------
# Standalone test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")

    if not _BLEAK_AVAILABLE:
        print("ERROR: bleak not installed. Run: pip install bleak")
        sys.exit(1)

    mac = sys.argv[1] if len(sys.argv) > 1 else _DEFAULT_MAC
    print(f"DAQ-M Light Sensor Test — target MAC: {mac}")
    print("Press Ctrl+C to stop.\n")

    sensor = LightSensor(mac_address=mac, acquisition_interval=0.0)
    sensor.connect()

    try:
        while True:
            time.sleep(1.0)
            st = sensor.status
            rd = sensor.latest_reading

            if st.connecting:
                print("Status: connecting...")
            elif st.connected:
                if rd:
                    age = time.time() - rd.timestamp
                    print(f"[{st.readings_count:4d}] "
                          f"R={rd.irradiance_red:.4f}  "
                          f"G={rd.irradiance_green:.4f}  "
                          f"NIR={rd.irradiance_nir:.4f}  "
                          f"int={rd.integration_time}ms  "
                          f"sat={rd.is_saturated}  "
                          f"age={age:.1f}s")
                else:
                    print("Connected, waiting for first reading...")
            else:
                if st.last_error:
                    print(f"Disconnected: {st.last_error}")
                else:
                    print("Disconnected")
                break
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        sensor.disconnect()
        print("Done.")
