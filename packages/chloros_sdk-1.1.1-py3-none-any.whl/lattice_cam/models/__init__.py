"""LATTICE camera model string parser.

Model strings are stored in the camera's DeviceUserID (NV memory, 16-byte max)
and identify the sensor + lens + filter configuration.

Format: ``M3C-L41-FRGB`` (12 chars on camera)
Display: ``LATT-M3C-L41-FRGB`` (Chloros prepends "LATT-")

Components:
    Sensor: ``M3C`` (IMX265 color, 3.1 MP) or ``M3M`` (mono)
    Lens:   ``L41`` (narrow 41 HFOV) or ``L87`` (wide 87 HFOV)
    Filter: ``F`` + code
        M3C: ``RGB``, ``RGN``, ``OCN``, ``NGB``
        M3M: wavelength in nm — ``405``, ``450``, ``475``, ``490``, ``550``,
             ``590``, ``615``, ``660``, ``725``, ``808``, ``850``, ``940``
"""

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Valid component values
# ---------------------------------------------------------------------------

VALID_SENSORS = {"M3C", "M3M"}
VALID_LENSES = {"L41", "L87"}
VALID_M3C_FILTERS = {"RGB", "RGN", "OCN", "NGB"}
VALID_M3M_FILTERS = {
    # Full LATTICE M3M narrowband-filter catalog. Each filter is a
    # single-band mono camera (no Bayer pattern) with a centre
    # wavelength named after the F-prefixed model code (e.g.
    # ``M3M-L87-F450`` ↔ filter_code ``"450"``).
    "250", "350", "385", "405", "450", "485", "520", "550",
    "590", "615", "632", "650", "685", "715", "725", "750",
    "780", "808", "832", "850", "880", "905", "940", "945",
    "995",
}


@dataclass
class ModelInfo:
    """Parsed LATTICE camera model.

    Attributes:
        sensor: Sensor code — ``"M3C"`` or ``"M3M"``.
        lens: Lens code — ``"L41"`` or ``"L87"``.
        filter_code: Filter identifier — e.g. ``"RGB"``, ``"RGN"``, ``"660"``.
        raw: Original model string — e.g. ``"M3C-L41-FRGB"``.
    """
    sensor: str
    lens: str
    filter_code: str
    raw: str


def parse_model_string(s: str) -> ModelInfo:
    """Parse a model string into its components.

    Parameters
    ----------
    s : str
        Model string, e.g. ``"M3C-L41-FRGN"`` or ``"LATT-M3C-L41-FRGN"``.
        The ``"LATT-"`` prefix is stripped if present.

    Returns
    -------
    ModelInfo
        Parsed model components.

    Raises
    ------
    ValueError
        If the string does not match the expected format.
    """
    raw = s.strip()

    # Strip optional "LATT-" display prefix
    work = raw.upper()
    if work.startswith("LATT-"):
        work = work[5:]

    parts = work.split("-")
    if len(parts) != 3:
        raise ValueError(
            f"Invalid model string '{s}': expected 3 dash-separated parts "
            f"(SENSOR-LENS-FCODE), got {len(parts)}"
        )

    sensor, lens, fpart = parts

    if sensor not in VALID_SENSORS:
        raise ValueError(
            f"Invalid sensor '{sensor}' in '{s}': "
            f"expected one of {sorted(VALID_SENSORS)}"
        )

    if lens not in VALID_LENSES:
        raise ValueError(
            f"Invalid lens '{lens}' in '{s}': "
            f"expected one of {sorted(VALID_LENSES)}"
        )

    if not fpart.startswith("F") or len(fpart) < 2:
        raise ValueError(
            f"Invalid filter part '{fpart}' in '{s}': "
            f"must start with 'F' followed by the filter code"
        )

    filter_code = fpart[1:]  # strip leading 'F'

    if sensor == "M3C":
        if filter_code not in VALID_M3C_FILTERS:
            raise ValueError(
                f"Invalid M3C filter '{filter_code}' in '{s}': "
                f"expected one of {sorted(VALID_M3C_FILTERS)}"
            )
    else:  # M3M
        if filter_code not in VALID_M3M_FILTERS:
            raise ValueError(
                f"Invalid M3M filter '{filter_code}' in '{s}': "
                f"expected one of {sorted(VALID_M3M_FILTERS)}"
            )

    # Normalise raw to the camera-stored form (no LATT- prefix)
    canonical = f"{sensor}-{lens}-F{filter_code}"

    return ModelInfo(sensor=sensor, lens=lens, filter_code=filter_code,
                     raw=canonical)


def validate_model_string(s: str) -> bool:
    """Check whether *s* is a valid model string.

    Returns True if valid, False otherwise (never raises).
    """
    try:
        parse_model_string(s)
        return True
    except (ValueError, AttributeError, TypeError):
        return False


def format_display_model(s: str) -> str:
    """Format a model string for user display (prepend ``LATT-``).

    If *s* already starts with ``LATT-``, it is returned unchanged.
    The raw camera-stored form ``"M3C-L41-FRGB"`` becomes
    ``"LATT-M3C-L41-FRGB"``.
    """
    s = s.strip()
    if s.upper().startswith("LATT-"):
        return s
    return f"LATT-{s}"


# ---------------------------------------------------------------------------
# Calibration mapping helpers
# ---------------------------------------------------------------------------

# M3C filter_code -> SENSOR_RESP key in calibration.py
_M3C_FILTER_MAP = {
    "RGN": "660/550/850_imx265",
    "OCN": "615/490/808_imx265",
    "NGB": "850/550/475_imx265",
    "RGB": "rgb_imx265",
}


def model_to_filter_type(info: ModelInfo) -> str | None:
    """Map a parsed model to its ``SENSOR_RESP`` key in calibration.py.

    Returns
    -------
    str or None
        The filter_type key (e.g. ``"660/550/850_imx265_l41"``), or ``None``
        for M3M sensors (mono — no spectral crosstalk correction needed).
    """
    if info.sensor == "M3M":
        return None
    base = _M3C_FILTER_MAP.get(info.filter_code)
    if base is None:
        return None
    return f"{base}_{info.lens.lower()}"


def model_to_flat_field_key(info: ModelInfo) -> str:
    """Map a parsed model to its ``FLAT_FIELD_DIRS`` key in calibration.py.

    For L41 (narrow lens), returns a lens-only key (e.g. ``"LATT-M3C-L41"``)
    because bare-sensor vignetting is sufficient at narrow FOV.

    For L87 (wide lens), returns a filter-qualified key (e.g.
    ``"LATT-M3C-L87-FRGN"``) because narrowband interference filters exhibit
    angle-of-incidence dependent transmission shift at wide FOV, causing
    10-24% additional corner falloff that varies per filter.
    """
    base = f"LATT-{info.sensor}-{info.lens}"
    if info.lens == "L87" and info.sensor == "M3C":
        return f"{base}-F{info.filter_code}"
    return base
