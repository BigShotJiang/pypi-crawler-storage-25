"""LATTICE camera hardware metadata — band/lens/sensor lookup tables.

Shared by capture.py (raw EXIF stamping) and registration.py (post-alignment
export) so both paths emit identical band/lens identity derived from the
camera's DeviceUserID model string.
"""

from typing import Any, Dict, List

from lattice_cam.models import parse_model_string


# M3C filter bands in BGR channel order (OpenCV: ch0=B, ch1=G, ch2=R).
M3C_BANDS: Dict[str, List[Dict[str, Any]]] = {
    "RGB": [
        {"name": "Blue_475",  "wavelength_nm": 475, "channel": 0, "fwhm_nm": 30},
        {"name": "Green_550", "wavelength_nm": 550, "channel": 1, "fwhm_nm": 30},
        {"name": "Red_625",   "wavelength_nm": 625, "channel": 2, "fwhm_nm": 30},
    ],
    "RGN": [
        {"name": "NIR_850",   "wavelength_nm": 850, "channel": 0, "fwhm_nm": 30},
        {"name": "Green_550", "wavelength_nm": 550, "channel": 1, "fwhm_nm": 30},
        {"name": "Red_660",   "wavelength_nm": 660, "channel": 2, "fwhm_nm": 21},
    ],
    "OCN": [
        {"name": "NIR_808",    "wavelength_nm": 808, "channel": 0, "fwhm_nm": 14},
        {"name": "Cyan_490",   "wavelength_nm": 490, "channel": 1, "fwhm_nm": 38},
        {"name": "Orange_615", "wavelength_nm": 615, "channel": 2, "fwhm_nm": 21},
    ],
    "NGB": [
        {"name": "Blue_475",  "wavelength_nm": 475, "channel": 0, "fwhm_nm": 30},
        {"name": "Green_550", "wavelength_nm": 550, "channel": 1, "fwhm_nm": 30},
        {"name": "NIR_850",   "wavelength_nm": 850, "channel": 2, "fwhm_nm": 30},
    ],
}

# M3M mono filter FWHM values (wavelength_nm -> fwhm_nm).
M3M_FWHM: Dict[int, int] = {
    405: 15, 450: 30, 475: 30, 490: 38, 550: 30, 590: 32,
    615: 21, 660: 21, 725: 23, 808: 14, 850: 30, 940: 60,
}

# LATTICE Pix4D lens calibration (from Kernel2 PIX4D_VALUES_K2).
LATTICE_PIX4D: Dict[str, Dict[str, Any]] = {
    "L87": {
        "focal_mm": 3.4097,
        "principal": "3.524, 2.6604",
        "distortion": "0.058, -0.222, 0.017, 0, 0",
    },
    "L41": {
        "focal_mm": 9.6706605,
        "principal": "3.412091, 2.745396",
        "distortion": "-0.107494, 0.0852713, 0.114084, 0.000263678, -0.000463052",
    },
}

# IMX265 pixel pitch: 3.45 um → 1000 / 0.00345 ≈ 289855 pixels per mm.
IMX265_PIXELS_PER_MM: int = 289855

# Sensor readout bit depth used for XMP-Camera:SensorBitDepth.
IMX265_BIT_DEPTH: int = 12


def bands_for_model(model_str: str) -> List[Dict[str, Any]]:
    """Return band descriptors for a LATTICE model string.

    M3C returns 3 bands in BGR channel order. M3M returns a single mono band.
    Returns an empty list if the model string fails to parse.
    """
    try:
        info = parse_model_string(model_str)
    except ValueError:
        return []

    if info.sensor == "M3C":
        return [dict(b) for b in M3C_BANDS.get(info.filter_code, [])]

    try:
        wl = int(info.filter_code)
    except ValueError:
        return []
    return [{
        "name": f"Mono_{info.filter_code}",
        "wavelength_nm": wl,
        "channel": 0,
        "fwhm_nm": M3M_FWHM.get(wl, 0),
    }]
