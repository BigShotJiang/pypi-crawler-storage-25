"""Tkinter control panel window for the live viewer.

Provides a separate GUI window with buttons and labels mirroring all
keyboard-controlled features.  Runs in a daemon thread and communicates
with the viewer via a thread-safe command queue.

Usage::

    panel = ControlPanel()
    panel.start()

    # Each viewer frame:
    panel.update_state(fps=4.0, exposure=1218, ...)
    for cmd, val in panel.get_commands():
        handle(cmd, val)

    panel.stop()
"""

import queue
import threading
import tkinter as tk
from tkinter import ttk


class ControlPanel:
    """Tkinter control panel running in a daemon thread."""

    def __init__(self):
        self._cmd_queue = queue.Queue()
        self._state = {}
        self._lock = threading.Lock()
        self._thread = None
        self._running = False
        self._root = None
        self._labels = {}      # name -> tk.StringVar for live updating
        self._toggles = {}     # name -> tk.StringVar for button text

    # ------------------------------------------------------------------
    # Public API (called from viewer / main thread)
    # ------------------------------------------------------------------

    def start(self):
        """Start the control panel in a background thread."""
        if self._thread and self._thread.is_alive():
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        """Request the control panel to close and wait for its thread."""
        self._running = False
        if self._root:
            try:
                self._root.after(0, self._shutdown)
            except Exception:
                pass
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def update_state(self, **kwargs):
        """Push viewer state to the panel (thread-safe)."""
        with self._lock:
            self._state.update(kwargs)

    def get_commands(self):
        """Drain all pending commands from the panel.

        Returns list of ``(command_str, value)`` tuples.
        """
        cmds = []
        while True:
            try:
                cmds.append(self._cmd_queue.get_nowait())
            except queue.Empty:
                break
        return cmds

    def get_one_command(self):
        """Get a single pending command, or ``None`` if queue is empty."""
        try:
            return self._cmd_queue.get_nowait()
        except queue.Empty:
            return None

    # ------------------------------------------------------------------
    # Internal (runs in daemon thread)
    # ------------------------------------------------------------------

    def _send(self, cmd, value=None):
        self._cmd_queue.put((cmd, value))

    def _run(self):
        self._root = tk.Tk()
        self._root.title("Camera Controls")
        self._root.resizable(False, False)
        self._root.protocol("WM_DELETE_WINDOW", self._on_close)

        style = ttk.Style(self._root)
        try:
            style.theme_use("vista")
        except Exception:
            try:
                style.theme_use("clam")
            except Exception:
                pass

        self._build_ui()
        self._refresh()
        self._root.mainloop()

    def _on_close(self):
        self._running = False
        self._shutdown()

    def _shutdown(self):
        """Clean up tkinter variables before destroying root (avoids
        'main thread is not in main loop' errors during GC)."""
        self._labels.clear()
        self._toggles.clear()
        try:
            self._root.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        root = self._root
        pad = dict(padx=4, pady=2)

        # ---- Camera Settings ----
        cam_frame = ttk.LabelFrame(root, text="Camera Settings")
        cam_frame.grid(row=0, column=0, sticky="ew", padx=6, pady=4)

        r = 0
        # Exposure
        self._labels['exposure'] = tk.StringVar(value="—")
        ttk.Label(cam_frame, text="Exposure:").grid(row=r, column=0, sticky="w", **pad)
        ttk.Label(cam_frame, textvariable=self._labels['exposure'], width=14).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(cam_frame, text="\u25bc", width=3,
                   command=lambda: self._send("exposure_down")).grid(row=r, column=2, **pad)
        ttk.Button(cam_frame, text="\u25b2", width=3,
                   command=lambda: self._send("exposure_up")).grid(row=r, column=3, **pad)
        self._toggles['auto_exp'] = tk.StringVar(value="Auto: OFF")
        ttk.Button(cam_frame, textvariable=self._toggles['auto_exp'], width=10,
                   command=lambda: self._send("toggle_auto_exposure")).grid(
                       row=r, column=4, **pad)

        r += 1
        # Gain
        self._labels['gain'] = tk.StringVar(value="—")
        ttk.Label(cam_frame, text="Gain:").grid(row=r, column=0, sticky="w", **pad)
        ttk.Label(cam_frame, textvariable=self._labels['gain'], width=14).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(cam_frame, text="\u25bc", width=3,
                   command=lambda: self._send("gain_down")).grid(row=r, column=2, **pad)
        ttk.Button(cam_frame, text="\u25b2", width=3,
                   command=lambda: self._send("gain_up")).grid(row=r, column=3, **pad)
        self._toggles['auto_gain'] = tk.StringVar(value="Auto: OFF")
        ttk.Button(cam_frame, textvariable=self._toggles['auto_gain'], width=10,
                   command=lambda: self._send("toggle_auto_gain")).grid(
                       row=r, column=4, **pad)

        r += 1
        # Brightness
        self._labels['brightness'] = tk.StringVar(value="—")
        ttk.Label(cam_frame, text="Brightness:").grid(row=r, column=0, sticky="w", **pad)
        ttk.Label(cam_frame, textvariable=self._labels['brightness'], width=14).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(cam_frame, text="\u25bc", width=3,
                   command=lambda: self._send("brightness_down")).grid(row=r, column=2, **pad)
        ttk.Button(cam_frame, text="\u25b2", width=3,
                   command=lambda: self._send("brightness_up")).grid(row=r, column=3, **pad)

        r += 1
        # Pixel format
        self._labels['pixel_format'] = tk.StringVar(value="—")
        ttk.Label(cam_frame, text="Format:").grid(row=r, column=0, sticky="w", **pad)
        ttk.Label(cam_frame, textvariable=self._labels['pixel_format'], width=14).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(cam_frame, text="Cycle", width=8,
                   command=lambda: self._send("cycle_pixel_format")).grid(
                       row=r, column=2, columnspan=2, **pad)

        r += 1
        # Resolution
        self._labels['resolution'] = tk.StringVar(value="—")
        ttk.Label(cam_frame, text="Resolution:").grid(row=r, column=0, sticky="w", **pad)
        ttk.Label(cam_frame, textvariable=self._labels['resolution'], width=14).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(cam_frame, text="Cycle", width=8,
                   command=lambda: self._send("cycle_resolution")).grid(
                       row=r, column=2, columnspan=2, **pad)

        # ---- Features ----
        feat_frame = ttk.LabelFrame(root, text="Features")
        feat_frame.grid(row=1, column=0, sticky="ew", padx=6, pady=4)

        features = [
            ("ArUco Detection", "toggle_aruco", "aruco"),
            ("NDVI", "toggle_ndvi", "ndvi"),
            ("Denoise", "toggle_denoise", "denoise"),
            ("FPS Overlay", "toggle_fps", "fps_overlay"),
            ("Raw Bayer", "toggle_raw_bayer", "raw_bayer"),
        ]
        for i, (label, cmd, key) in enumerate(features):
            ttk.Label(feat_frame, text=label + ":").grid(row=i, column=0, sticky="w", **pad)
            self._toggles[key] = tk.StringVar(value="OFF")
            ttk.Button(feat_frame, textvariable=self._toggles[key], width=8,
                       command=lambda c=cmd: self._send(c)).grid(
                           row=i, column=1, **pad)

        # DLS (separate row with connect/disconnect)
        r_dls = len(features)
        ttk.Label(feat_frame, text="DLS Sensor:").grid(row=r_dls, column=0, sticky="w", **pad)
        self._toggles['dls'] = tk.StringVar(value="OFF")
        ttk.Button(feat_frame, textvariable=self._toggles['dls'], width=12,
                   command=lambda: self._send("toggle_dls")).grid(
                       row=r_dls, column=1, **pad)

        # Filter model
        r_filt = r_dls + 1
        self._labels['filter'] = tk.StringVar(value="—")
        ttk.Label(feat_frame, text="Filter:").grid(row=r_filt, column=0, sticky="w", **pad)
        ttk.Label(feat_frame, textvariable=self._labels['filter']).grid(
            row=r_filt, column=1, sticky="w", **pad)
        ttk.Button(feat_frame, text="Cycle", width=8,
                   command=lambda: self._send("cycle_filter")).grid(
                       row=r_filt, column=2, **pad)

        # ---- NDVI Settings ----
        ndvi_frame = ttk.LabelFrame(root, text="NDVI Settings")
        ndvi_frame.grid(row=2, column=0, sticky="ew", padx=6, pady=4)

        self._labels['ndvi_min'] = tk.StringVar(value="0.3")
        ttk.Label(ndvi_frame, text="LUT Min:").grid(row=0, column=0, sticky="w", **pad)
        ttk.Label(ndvi_frame, textvariable=self._labels['ndvi_min'], width=6).grid(
            row=0, column=1, sticky="w", **pad)
        ttk.Button(ndvi_frame, text="\u25bc", width=3,
                   command=lambda: self._send("ndvi_min_down")).grid(row=0, column=2, **pad)
        ttk.Button(ndvi_frame, text="\u25b2", width=3,
                   command=lambda: self._send("ndvi_min_up")).grid(row=0, column=3, **pad)

        self._labels['ndvi_max'] = tk.StringVar(value="0.8")
        ttk.Label(ndvi_frame, text="LUT Max:").grid(row=1, column=0, sticky="w", **pad)
        ttk.Label(ndvi_frame, textvariable=self._labels['ndvi_max'], width=6).grid(
            row=1, column=1, sticky="w", **pad)
        ttk.Button(ndvi_frame, text="\u25bc", width=3,
                   command=lambda: self._send("ndvi_max_down")).grid(row=1, column=2, **pad)
        ttk.Button(ndvi_frame, text="\u25b2", width=3,
                   command=lambda: self._send("ndvi_max_up")).grid(row=1, column=3, **pad)

        # ---- Capture ----
        cap_frame = ttk.LabelFrame(root, text="Capture")
        cap_frame.grid(row=3, column=0, sticky="ew", padx=6, pady=4)

        ttk.Button(cap_frame, text="Single", width=10,
                   command=lambda: self._send("capture_single")).grid(
                       row=0, column=0, **pad)
        ttk.Button(cap_frame, text="Burst (5)", width=10,
                   command=lambda: self._send("capture_burst")).grid(
                       row=0, column=1, **pad)
        self._toggles['continuous'] = tk.StringVar(value="Record: OFF")
        ttk.Button(cap_frame, textvariable=self._toggles['continuous'], width=12,
                   command=lambda: self._send("toggle_continuous")).grid(
                       row=0, column=2, **pad)

        # ---- Actions ----
        act_frame = ttk.LabelFrame(root, text="Actions")
        act_frame.grid(row=4, column=0, sticky="ew", padx=6, pady=4)

        ttk.Button(act_frame, text="White Balance", width=14,
                   command=lambda: self._send("white_balance")).grid(
                       row=0, column=0, **pad)
        ttk.Button(act_frame, text="Reset", width=10,
                   command=lambda: self._send("reset")).grid(
                       row=0, column=1, **pad)

        # Presets
        r_preset = 1
        ttk.Label(act_frame, text="Presets:").grid(row=r_preset, column=0, sticky="w", **pad)
        preset_inner = ttk.Frame(act_frame)
        preset_inner.grid(row=r_preset, column=1, columnspan=3, sticky="w")
        for i in range(1, 5):
            ttk.Button(preset_inner, text=str(i), width=3,
                       command=lambda n=i: self._send("preset", n)).grid(
                           row=0, column=i - 1, padx=2)

        # ---- Status ----
        status_frame = ttk.LabelFrame(root, text="Status")
        status_frame.grid(row=5, column=0, sticky="ew", padx=6, pady=4)

        self._labels['fps'] = tk.StringVar(value="FPS: —")
        ttk.Label(status_frame, textvariable=self._labels['fps']).grid(
            row=0, column=0, sticky="w", **pad)
        self._labels['temp'] = tk.StringVar(value="")
        ttk.Label(status_frame, textvariable=self._labels['temp']).grid(
            row=0, column=1, sticky="w", **pad)
        self._labels['gpu'] = tk.StringVar(value="")
        ttk.Label(status_frame, textvariable=self._labels['gpu']).grid(
            row=1, column=0, columnspan=2, sticky="w", **pad)
        self._labels['calib'] = tk.StringVar(value="")
        ttk.Label(status_frame, textvariable=self._labels['calib']).grid(
            row=2, column=0, columnspan=2, sticky="w", **pad)

    # ------------------------------------------------------------------
    # Periodic state refresh
    # ------------------------------------------------------------------

    def _refresh(self):
        """Read shared state and update all labels (runs in tk thread)."""
        if not self._running:
            return
        with self._lock:
            s = dict(self._state)

        # Camera settings
        if 'exposure' in s:
            exp_us = s['exposure']
            exp_sec = exp_us / 1_000_000
            if exp_sec >= 1.0:
                self._labels['exposure'].set(f"{exp_sec:.1f}s")
            else:
                denom = round(1.0 / exp_sec) if exp_sec > 0 else 0
                self._labels['exposure'].set(f"1/{denom}s  ({exp_us:.0f}us)")
        if 'gain' in s:
            self._labels['gain'].set(f"{s['gain']:.1f} dB")
        if 'brightness' in s:
            self._labels['brightness'].set(str(s['brightness']))
        if 'pixel_format' in s:
            self._labels['pixel_format'].set(s['pixel_format'])
        if 'resolution' in s:
            self._labels['resolution'].set(s['resolution'])

        # Toggles
        if 'auto_exposure' in s:
            self._toggles['auto_exp'].set(
                "Auto: ON" if s['auto_exposure'] else "Auto: OFF")
        if 'auto_gain' in s:
            self._toggles['auto_gain'].set(
                "Auto: ON" if s['auto_gain'] else "Auto: OFF")
        if 'aruco' in s:
            self._toggles['aruco'].set("ON" if s['aruco'] else "OFF")
        if 'ndvi' in s:
            self._toggles['ndvi'].set("ON" if s['ndvi'] else "OFF")
        if 'denoise' in s:
            self._toggles['denoise'].set("ON" if s['denoise'] else "OFF")
        if 'fps_overlay' in s:
            self._toggles['fps_overlay'].set("ON" if s['fps_overlay'] else "OFF")
        if 'raw_bayer' in s:
            self._toggles['raw_bayer'].set("ON" if s['raw_bayer'] else "OFF")
        if 'dls' in s:
            self._toggles['dls'].set(s['dls'])
        if 'continuous' in s:
            self._toggles['continuous'].set(
                "Record: ON" if s['continuous'] else "Record: OFF")
        if 'filter' in s:
            self._labels['filter'].set(s['filter'])

        # NDVI settings
        if 'ndvi_min' in s:
            self._labels['ndvi_min'].set(f"{s['ndvi_min']:.1f}")
        if 'ndvi_max' in s:
            self._labels['ndvi_max'].set(f"{s['ndvi_max']:.1f}")

        # Status
        if 'fps' in s:
            self._labels['fps'].set(f"FPS: {s['fps']:.1f}")
        if 'temp' in s:
            t = s['temp']
            self._labels['temp'].set(f"Temp: {t:.1f}C" if t is not None else "")
        if 'gpu' in s:
            self._labels['gpu'].set(s['gpu'])
        if 'calib' in s:
            self._labels['calib'].set(s['calib'])

        # Schedule next refresh (200ms = 5 Hz, low CPU overhead)
        try:
            self._root.after(200, self._refresh)
        except Exception:
            pass
