import os
import queue
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import cv2
import numpy as np


@dataclass
class CaptureResult:
    filepath: str
    width: int
    height: int
    pixel_format: str
    exposure_time: float
    gain: float
    timestamp: str

    # Auto-exposure / auto-gain mode at capture time
    exposure_auto: str = "Off"   # Off, Once, Continuous
    gain_auto: str = "Off"       # Off, Once, Continuous

    # Hardware per-frame metadata (from camera chunk data)
    timestamp_camera_ns: Optional[int] = None
    exposure_time_actual: Optional[float] = None  # us, from ChunkExposureTime
    gain_actual: Optional[float] = None            # dB, from ChunkGain
    black_level: Optional[float] = None
    frame_id: Optional[int] = None
    crc: Optional[int] = None


def save_frame(frame, filepath, jpeg_quality=95, bit_depth=None):
    """Save a numpy array to disk. Format determined by file extension.

    Supports .tiff/.tif (lossless, 8 or 16-bit), .png (lossless 8-bit),
    .jpg/.jpeg (lossy 8-bit).

    Parameters
    ----------
    bit_depth : int or None
        Actual sensor bit depth (10, 12, 16) for correct uint16→uint8
        conversion.  When *None*, detected from dtype (8 for uint8,
        16 for uint16).
    """
    ext = os.path.splitext(filepath)[1].lower()
    os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

    if ext in (".tiff", ".tif"):
        cv2.imwrite(filepath, frame)
    elif ext == ".png":
        if frame.dtype == np.uint16:
            shift = max(0, (bit_depth or 16) - 8)
            frame = (frame >> shift).astype(np.uint8)
        cv2.imwrite(filepath, frame, [cv2.IMWRITE_PNG_COMPRESSION, 3])
    elif ext in (".jpg", ".jpeg"):
        if frame.dtype == np.uint16:
            shift = max(0, (bit_depth or 16) - 8)
            frame = (frame >> shift).astype(np.uint8)
        cv2.imwrite(filepath, frame, [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality])
    else:
        cv2.imwrite(filepath, frame)


def _find_exiftool():
    """Locate the ExifTool binary (PATH, then bundled mip/exiftool.exe)."""
    et = shutil.which("exiftool")
    if et:
        return et
    bundled = (Path(__file__).resolve().parent.parent
               / "mip" / "exiftool.exe")
    if bundled.exists():
        return str(bundled)
    return None


def _find_pix4d_config():
    """Locate pix4d.config (required for the XMP-Camera namespace)."""
    repo_root = Path(__file__).resolve().parent.parent
    for candidate in (repo_root / "pix4d.config",
                      repo_root / "resources" / "backend" / "pix4d.config"):
        if candidate.exists():
            return str(candidate)
    return None


def _run_exiftool(args_list, filepath):
    et = _find_exiftool()
    if not et:
        return False
    cmd = [et]
    config = _find_pix4d_config()
    if config:
        cmd.extend(["-config", config])
    cmd.extend(["-overwrite_original", "-m", "-n"])
    cmd.extend(args_list)
    cmd.append(str(filepath))
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30)
        return proc.returncode == 0
    except Exception:
        return False


def _read_camera_model(camera):
    """Read DeviceUserID (LATTICE model string) from the camera, best-effort."""
    if camera is None:
        return ""
    try:
        val = camera.get_node("DeviceUserID")
        return val or ""
    except Exception:
        return ""


def write_capture_exif(result, camera=None, model=None, serial=None,
                       rig_camera_index=None):
    """Stamp full EXIF/XMP-Camera metadata onto the captured image.

    Mirrors the tags that ``mip/Save_Format.py`` writes on Survey3 export,
    adapted for LATTICE (IMX265 + LATT- model string). Derives band names,
    central wavelengths, FWHM, and lens calibration from the model string
    via ``lattice_cam.metadata``.

    No-op (returns False) if ExifTool is unavailable.

    Parameters
    ----------
    result : CaptureResult
        Per-frame capture result (exposure, gain, timestamps, frame_id).
    camera : LatticeCam, optional
        Live camera — used to read DeviceUserID and serial when ``model``
        / ``serial`` aren't supplied explicitly.
    model : str, optional
        LATTICE model string (e.g. ``"M3C-L41-FRGN"`` or ``"LATT-M3C-L41-FRGN"``).
    serial : str, optional
        Camera serial number.
    rig_camera_index : int, optional
        Index of this camera within a multi-camera rig (sync capture).
    """
    if not _find_exiftool():
        return False

    from lattice_cam.models import format_display_model, parse_model_string
    from lattice_cam.metadata import (
        bands_for_model,
        LATTICE_PIX4D,
        IMX265_PIXELS_PER_MM,
        IMX265_BIT_DEPTH,
    )

    raw_model = model or _read_camera_model(camera)
    display_model = ""
    info = None
    if raw_model:
        try:
            info = parse_model_string(raw_model)
        except ValueError:
            info = None
        try:
            display_model = format_display_model(raw_model)
        except Exception:
            display_model = raw_model

    if serial is None and camera is not None:
        serial = getattr(camera, "serial", None) or ""

    args = [
        "-Make=MAPIR",
        "-Software=Chloros",
        "-XMP-Camera:RigName=LATTICE",
    ]
    if display_model:
        args.append(f"-Model={display_model}")
    if serial:
        args.append(f"-SerialNumber={serial}")
        args.append(f"-CameraSerialNumber={serial}")

    # Timestamp — microsecond-precision DateTimeOriginal.
    try:
        dt = datetime.fromisoformat(result.timestamp)
    except (ValueError, TypeError):
        dt = None
    if dt is not None:
        exif_ts = dt.strftime("%Y:%m:%d %H:%M:%S")
        subsec = f"{dt.microsecond:06d}"
        args.extend([
            f"-DateTimeOriginal={exif_ts}",
            f"-SubSecTimeOriginal={subsec}",
            f"-DateTimeDigitized={exif_ts}",
            f"-SubSecTimeDigitized={subsec}",
            f"-CreateDate={exif_ts}",
            f"-SubSecTime={subsec}",
        ])

    # Exposure time (us → seconds).
    exp_us = (result.exposure_time_actual
              if result.exposure_time_actual is not None
              else result.exposure_time)
    if exp_us:
        args.append(f"-ExposureTime={exp_us / 1_000_000.0}")

    # Band identity (derived from filter code in the model string).
    # pix4d.config defines BandName/CentralWavelength/WavelengthFWHM as
    # List => 'Seq', so each band needs its own exiftool arg — comma-joined
    # strings would be read as a single element.
    band_info = bands_for_model(raw_model) if raw_model else []
    for b in band_info:
        args.append(f"-XMP-Camera:BandName={b['name']}")
        args.append(f"-XMP-Camera:CentralWavelength={b['wavelength_nm']}")
        args.append(f"-XMP-Camera:WavelengthFWHM={b.get('fwhm_nm', 0)}")

    # Lens calibration (from lens code in the model string).
    lens_cal = LATTICE_PIX4D.get(info.lens) if info else None
    if lens_cal:
        args.extend([
            f"-XMP-Camera:PerspectiveFocalLength={lens_cal['focal_mm']}",
            f"-XMP-Camera:PrincipalPoint={lens_cal['principal']}",
            f"-XMP-Camera:PerspectiveDistortion={lens_cal['distortion']}",
            "-XMP-Camera:ModelType=perspective",
        ])
        focal_um = int(lens_cal["focal_mm"] * 10_000_000)
        args.append(f"-FocalLength={focal_um}/10000000")

    # Focal plane resolution — identifies the IMX265 pixel pitch.
    args.extend([
        f"-FocalPlaneXResolution={IMX265_PIXELS_PER_MM}",
        f"-FocalPlaneYResolution={IMX265_PIXELS_PER_MM}",
        "-FocalPlaneResolutionUnit=4",
        f"-XMP-Camera:SensorBitDepth={IMX265_BIT_DEPTH}",
        "-XMP-Camera:IsNormalized=0",
    ])

    if rig_camera_index is not None:
        args.append(f"-XMP-Camera:RigCameraIndex={rig_camera_index}")

    # Per-frame scientific metadata that doesn't map to a standard EXIF tag.
    gain_db = (result.gain_actual
               if result.gain_actual is not None
               else result.gain)
    parts = [f"Gain={gain_db:.2f}dB",
             f"PixelFormat={result.pixel_format}"]
    if result.black_level is not None:
        parts.append(f"BlackLevel={result.black_level}")
    if result.frame_id is not None:
        parts.append(f"FrameID={result.frame_id}")
    if result.timestamp_camera_ns is not None:
        parts.append(f"CameraTimestampNs={result.timestamp_camera_ns}")
    if result.exposure_auto and result.exposure_auto != "Off":
        parts.append(f"ExposureAuto={result.exposure_auto}")
    if result.gain_auto and result.gain_auto != "Off":
        parts.append(f"GainAuto={result.gain_auto}")
    args.append(f"-UserComment={'; '.join(parts)}")

    return _run_exiftool(args, result.filepath)


def generate_filename(output_dir="output", prefix="capture", ext=".tiff"):
    """Generate a timestamped filename."""
    os.makedirs(output_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]  # trim to milliseconds
    filename = f"{prefix}_{ts}{ext}"
    return os.path.join(output_dir, filename)


def capture_single(camera, output_dir="output", ext=".tiff", full_depth=True,
                    prefix="capture", jpeg_quality=95):
    """Grab one frame, save to disk with EXIF metadata, return CaptureResult.

    If the camera is not streaming, starts and stops the stream automatically.
    """
    auto_stream = not camera.is_streaming
    if auto_stream:
        camera.start_stream()

    try:
        frame, meta = camera.grab_frame_with_metadata(full_depth=full_depth)

        filepath = generate_filename(output_dir, prefix, ext)
        save_frame(frame, filepath, jpeg_quality)

        h, w = frame.shape[:2]
        ts = datetime.now(timezone.utc).isoformat()

        result = CaptureResult(
            filepath=filepath,
            width=w,
            height=h,
            pixel_format=camera.settings.pixel_format,
            exposure_time=camera.settings.exposure_time,
            gain=camera.settings.gain,
            timestamp=ts,
            exposure_auto=camera.settings.exposure_auto,
            gain_auto=camera.settings.gain_auto,
            timestamp_camera_ns=meta.get("timestamp_ns"),
            exposure_time_actual=meta.get("exposure_time_us"),
            gain_actual=meta.get("gain_db"),
            black_level=meta.get("black_level"),
            frame_id=meta.get("frame_id"),
            crc=meta.get("crc"),
        )
        write_capture_exif(result, camera=camera)
        return result
    finally:
        if auto_stream:
            camera.stop_stream()


def capture_burst(camera, count=5, interval=0.0, output_dir="output",
                  ext=".tiff", full_depth=True, prefix="burst",
                  jpeg_quality=95):
    """Grab N frames with optional delay between each, save all to disk.

    Returns a list of CaptureResult.
    """
    auto_stream = not camera.is_streaming
    if auto_stream:
        camera.start_stream()

    results = []
    try:
        for i in range(count):
            frame, meta = camera.grab_frame_with_metadata(full_depth=full_depth)

            filepath = generate_filename(output_dir, f"{prefix}_{i:04d}", ext)
            save_frame(frame, filepath, jpeg_quality)

            h, w = frame.shape[:2]
            ts = datetime.now(timezone.utc).isoformat()

            result = CaptureResult(
                filepath=filepath,
                width=w,
                height=h,
                pixel_format=camera.settings.pixel_format,
                exposure_time=camera.settings.exposure_time,
                gain=camera.settings.gain,
                timestamp=ts,
                exposure_auto=camera.settings.exposure_auto,
                gain_auto=camera.settings.gain_auto,
                timestamp_camera_ns=meta.get("timestamp_ns"),
                exposure_time_actual=meta.get("exposure_time_us"),
                gain_actual=meta.get("gain_db"),
                black_level=meta.get("black_level"),
                frame_id=meta.get("frame_id"),
                crc=meta.get("crc"),
            )
            write_capture_exif(result, camera=camera)
            results.append(result)

            if interval > 0 and i < count - 1:
                time.sleep(interval)
    finally:
        if auto_stream:
            camera.stop_stream()

    return results


# ---------------------------------------------------------------------------
# Continuous capture – stream every frame to disk at full camera rate
# ---------------------------------------------------------------------------

@dataclass
class ContinuousStats:
    """Running statistics for a continuous capture session."""
    frames_saved: int = 0
    frames_dropped: int = 0
    elapsed: float = 0.0
    output_dir: str = ""

    @property
    def fps(self):
        return self.frames_saved / self.elapsed if self.elapsed > 0 else 0.0


class ContinuousCapture:
    """Stream every frame to disk as fast as the camera delivers them.

    Two usage modes:

    **Standalone** (has its own grab thread)::

        cap = ContinuousCapture(cam, output_dir="output/run1")
        cap.start()          # spawns grab + writer threads
        ...
        stats = cap.stop()

    **Fed** (caller supplies frames — use this when a viewer is already
    grabbing frames so they don't compete for buffers)::

        cap = ContinuousCapture(cam, output_dir="output/run1")
        cap.start(grab=False)   # writer thread only
        while running:
            frame, meta = cam.grab_frame_with_metadata()
            cap.feed(frame, meta)   # non-blocking enqueue
            display(frame)
        stats = cap.stop()
    """

    def __init__(self, camera, output_dir="output", ext=".tiff",
                 full_depth=True, prefix="frame", jpeg_quality=95,
                 queue_depth=64):
        self._camera = camera
        self._output_dir = output_dir
        self._ext = ext
        self._full_depth = full_depth
        self._prefix = prefix
        self._jpeg_quality = jpeg_quality

        self._q = queue.Queue(maxsize=queue_depth)
        self._running = False
        self._grab_thread = None
        self._write_thread = None
        self._stats = ContinuousStats(output_dir=output_dir)
        self._t0 = 0.0

    # -- public API ---------------------------------------------------------

    @property
    def is_running(self):
        return self._running

    @property
    def stats(self):
        if self._running:
            self._stats.elapsed = time.perf_counter() - self._t0
        return self._stats

    def start(self, grab=True):
        """Begin continuous capture.

        Args:
            grab: If True (default), spawn a grab thread that pulls frames
                  from the camera.  Set to False when the caller will
                  supply frames via :meth:`feed`.
        """
        if self._running:
            return
        os.makedirs(self._output_dir, exist_ok=True)
        self._stats = ContinuousStats(output_dir=self._output_dir)
        self._running = True
        self._t0 = time.perf_counter()

        if grab:
            self._grab_thread = threading.Thread(
                target=self._grab_loop, daemon=True)
            self._grab_thread.start()

        self._write_thread = threading.Thread(
            target=self._write_loop, daemon=True)
        self._write_thread.start()

    def stop(self):
        """Stop capture and wait for the writer to flush.

        Returns a ``ContinuousStats`` summary.
        """
        self._running = False
        if self._grab_thread:
            self._grab_thread.join(timeout=5)
        if self._write_thread:
            self._write_thread.join(timeout=10)
        self._stats.elapsed = time.perf_counter() - self._t0
        return self._stats

    def feed(self, frame, meta):
        """Enqueue a frame for writing (non-blocking).

        Use this instead of the internal grab thread when the caller
        already has a grab loop (e.g. viewer).  Dropped silently if
        the writer queue is full.
        """
        meta.setdefault("_wall_ts", datetime.now(timezone.utc).isoformat())
        meta.setdefault("_settings", {
            "pixel_format": self._camera.settings.pixel_format,
            "exposure_time": self._camera.settings.exposure_time,
            "gain": self._camera.settings.gain,
            "exposure_auto": self._camera.settings.exposure_auto,
            "gain_auto": self._camera.settings.gain_auto,
        })
        try:
            self._q.put_nowait((frame, meta))
        except queue.Full:
            self._stats.frames_dropped += 1

    # -- internals ----------------------------------------------------------

    def _grab_loop(self):
        cam = self._camera
        while self._running:
            try:
                frame, meta = cam.grab_frame_with_metadata(
                    full_depth=self._full_depth)
            except Exception:
                continue  # timeout or transient error
            self.feed(frame, meta)

    def _write_loop(self):
        from .convert import _FORMAT_BITS

        seq = 0
        while self._running or not self._q.empty():
            try:
                frame, meta = self._q.get(timeout=0.5)
            except queue.Empty:
                continue

            filepath = os.path.join(
                self._output_dir,
                f"{self._prefix}_{seq:06d}{self._ext}")
            pf = meta.get("_settings", {}).get("pixel_format", "")
            bits = _FORMAT_BITS.get(pf, None)
            save_frame(frame, filepath, self._jpeg_quality, bit_depth=bits)

            h, w = frame.shape[:2]
            s = meta["_settings"]
            result = CaptureResult(
                filepath=filepath,
                width=w,
                height=h,
                pixel_format=s["pixel_format"],
                exposure_time=s["exposure_time"],
                gain=s["gain"],
                timestamp=meta["_wall_ts"],
                exposure_auto=s["exposure_auto"],
                gain_auto=s["gain_auto"],
                timestamp_camera_ns=meta.get("timestamp_ns"),
                exposure_time_actual=meta.get("exposure_time_us"),
                gain_actual=meta.get("gain_db"),
                black_level=meta.get("black_level"),
                frame_id=meta.get("frame_id"),
                crc=meta.get("crc"),
            )
            write_capture_exif(result, camera=self._camera)
            self._stats.frames_saved += 1
            seq += 1
