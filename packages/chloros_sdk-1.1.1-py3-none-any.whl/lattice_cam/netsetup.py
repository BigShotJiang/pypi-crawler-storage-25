"""Network adapter diagnostics and setup for GigE Vision cameras.

Checks and optionally configures NIC settings for optimal GigE Vision
throughput (jumbo frames, receive buffers, interrupt moderation).

Cross-platform: Windows (registry + netsh) and Linux (ethtool + ip).
"""

import platform
import re
import subprocess
import sys
from dataclasses import dataclass
from typing import Optional

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"

# Optimal values (platform-independent targets)
OPTIMAL = {
    "mtu": 9000,             # Jumbo frames MTU
    "rx_buffers": 2048,      # Maximum receive ring buffers
}

# Windows-specific registry optimal values
_WIN_OPTIMAL = {
    "JumboPacket": "9014",
    "ReceiveBuffers": "2048",
    "InterruptModeration": "1",
    "SpeedDuplex": "0",
}

_WIN_REG_BASE = (
    r"HKLM\SYSTEM\CurrentControlSet\Control\Class"
    r"\{4d36e972-e325-11ce-bfc1-08002be10318}"
)


@dataclass
class NicInfo:
    name: str
    registry_key: str = ""
    jumbo_packet: str = "N/A"
    receive_buffers: str = "N/A"
    interrupt_moderation: str = "N/A"
    speed_duplex: str = "N/A"
    interface_mtu: Optional[int] = None
    media_connected: bool = False
    # Linux-specific
    driver: str = ""
    link_speed: str = ""


# ============================================================================
# Cross-platform public API
# ============================================================================

def find_ethernet_adapters():
    """Find physical Ethernet adapters.

    Returns a list of NicInfo with current settings.
    Works on both Windows and Linux.
    """
    if IS_WINDOWS:
        return _find_adapters_windows()
    elif IS_LINUX:
        return _find_adapters_linux()
    else:
        return []


def diagnose(verbose=True):
    """Check NIC configuration and report issues.

    Returns (adapters, issues) where issues is a list of problem strings.
    """
    adapters = find_ethernet_adapters()
    issues = []

    if not adapters:
        issues.append("No physical Ethernet adapter found")
        if verbose:
            print("WARNING: No physical Ethernet adapter found.")
            print("  GigE Vision cameras require a wired Ethernet connection.")
        return adapters, issues

    for adapter in adapters:
        if IS_WINDOWS:
            _diagnose_windows(adapter, issues, verbose)
        elif IS_LINUX:
            _diagnose_linux(adapter, issues, verbose)

    return adapters, issues


def fix_settings():
    """Apply optimal NIC settings. Requires elevated privileges.

    Returns True if all changes succeeded.
    """
    if IS_WINDOWS:
        return _fix_windows()
    elif IS_LINUX:
        return _fix_linux()
    else:
        print(f"Platform {platform.system()} not supported for auto-fix.")
        return False


def bandwidth_estimate(num_cameras=1, pixel_format="BayerRG8", jumbo=True):
    """Estimate per-camera FPS for a given setup on 1 Gbps Ethernet.

    Returns (fps_per_camera, total_bandwidth_mbps, link_limited).
    """
    bpp = {"BayerRG8": 1, "Mono8": 1,
           "BayerRG10": 1.25, "Mono10": 1.25,
           "BayerRG12": 1.5, "Mono12": 1.5,
           "BayerRG10Packed": 1.25, "BayerRG12Packed": 1.5,
           "BayerRG16": 2, "Mono16": 2}

    bytes_per_pixel = bpp.get(pixel_format, 1)
    frame_bytes = 2048 * 1536 * bytes_per_pixel  # IMX265 = 3.2 MP
    frame_mb = frame_bytes / (1024 * 1024)

    usable_mbps = 115.0 if jumbo else 85.0  # MB/s usable on 1 Gbps
    sensor_max_fps = 36.0  # IMX265 max at full resolution

    total_fps = usable_mbps / frame_mb
    per_camera_fps = min(total_fps / num_cameras, sensor_max_fps)
    total_bw = per_camera_fps * num_cameras * frame_mb

    link_limited = (total_fps / num_cameras) < sensor_max_fps

    return round(per_camera_fps, 1), round(total_bw, 1), link_limited


# ============================================================================
# Windows implementation
# ============================================================================

def _find_adapters_windows():
    """Find Ethernet adapters on Windows."""
    adapters = _find_adapters_registry()
    if not adapters:
        adapters = _find_adapters_pnputil()

    mtu_map = _get_interface_mtus_win()
    for adapter in adapters:
        for iface_name, (mtu, connected) in mtu_map.items():
            if "Ethernet" in iface_name and "vEthernet" not in iface_name:
                adapter.interface_mtu = mtu
                adapter.media_connected = connected
                break

    return adapters


def _find_adapters_registry():
    """Find adapters via Windows registry. Uses winreg directly so we
    don't pay for a subprocess launch per query *and* so we don't lose
    inherited admin tokens when running under a parent that spawned us
    via a non-elevation-preserving exec path (Tauri does this on some
    Windows builds — the user is admin, the Python child still got
    HKLM read access, but ``reg.exe`` couldn't be launched cleanly).

    Returns adapters with full registry detail when the read succeeds.
    On read failure for a given value, leaves it as "N/A" instead of
    flagging the whole adapter as admin-required.
    """
    try:
        import winreg
    except ImportError:
        return []
    base = (
        r"SYSTEM\CurrentControlSet\Control\Class"
        r"\{4d36e972-e325-11ce-bfc1-08002be10318}"
    )
    adapters = []
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as parent:
            i = 0
            while True:
                try:
                    sub_name = winreg.EnumKey(parent, i)
                except OSError:
                    break
                i += 1
                if not sub_name.isdigit():
                    continue
                try:
                    with winreg.OpenKey(parent, sub_name) as sub:
                        desc = _winreg_value(sub, "DriverDesc")
                        if not desc or "Ethernet" not in desc or "Virtual" in desc:
                            continue
                        adapters.append(NicInfo(
                            name=desc,
                            registry_key=f"HKLM\\{base}\\{sub_name}",
                            jumbo_packet=_winreg_value(sub, "*JumboPacket") or "N/A",
                            receive_buffers=_winreg_value(sub, "*ReceiveBuffers") or "N/A",
                            interrupt_moderation=_winreg_value(sub, "*InterruptModeration") or "N/A",
                            speed_duplex=_winreg_value(sub, "*SpeedDuplex") or "N/A",
                        ))
                except OSError:
                    continue
    except OSError:
        return []
    return adapters


def _winreg_value(key_handle, name):
    """Read a single registry value via an already-opened key. Returns
    string or None. Stringifies DWORDs so callers can compare uniformly
    with "2048" / "1" defaults from _WIN_OPTIMAL.
    """
    try:
        import winreg
        val, _ = winreg.QueryValueEx(key_handle, name)
        if val is None:
            return None
        return str(val)
    except (OSError, FileNotFoundError):
        return None


def _find_adapters_pnputil():
    """Fallback: find adapters via pnputil (no admin needed)."""
    adapters = []
    try:
        result = subprocess.run(
            ["pnputil", "/enum-devices", "/class", "Net"],
            capture_output=True, text=True, timeout=10
        )
        blocks = result.stdout.split("Instance ID:")
        for block in blocks:
            if "Ethernet" in block and "Virtual" not in block and "WAN" not in block:
                match = re.search(r"Device Description:\s+(.+)", block)
                name = match.group(1).strip() if match else "Unknown Ethernet"
                adapters.append(NicInfo(
                    name=name,
                    registry_key="(run as admin for details)",
                    jumbo_packet="(run as admin)",
                    receive_buffers="(run as admin)",
                    interrupt_moderation="(run as admin)",
                    speed_duplex="(run as admin)",
                ))
    except Exception:
        pass
    return adapters


def _diagnose_windows(adapter, issues, verbose):
    """Windows-specific NIC diagnostics."""
    needs_admin = adapter.jumbo_packet.startswith("(run")

    if verbose:
        print(f"Adapter: {adapter.name}")
        if needs_admin:
            print("  (Run as Administrator for full NIC details)")
        else:
            print(f"  Jumbo Packet:         {adapter.jumbo_packet}"
                  f"  {'OK' if adapter.jumbo_packet == _WIN_OPTIMAL['JumboPacket'] else 'NEEDS CONFIG'}")
            print(f"  Receive Buffers:      {adapter.receive_buffers}"
                  f"  {'OK' if adapter.receive_buffers == _WIN_OPTIMAL['ReceiveBuffers'] else 'NEEDS CONFIG'}")
            print(f"  Interrupt Moderation: {adapter.interrupt_moderation}"
                  f"  {'OK' if adapter.interrupt_moderation == _WIN_OPTIMAL['InterruptModeration'] else 'CHECK'}")
            print(f"  Speed/Duplex:         {adapter.speed_duplex}"
                  f"  {'OK' if adapter.speed_duplex == _WIN_OPTIMAL['SpeedDuplex'] else 'CHECK'}")
        if adapter.interface_mtu is not None:
            status = "cable disconnected" if not adapter.media_connected else "OK"
            print(f"  Active MTU:           {adapter.interface_mtu}  {status}")
        print()

    if needs_admin:
        issues.append(
            f"{adapter.name}: Run as Administrator to read NIC settings. "
            f"Use: lattice network  (from an admin terminal)"
        )
    else:
        if adapter.jumbo_packet != _WIN_OPTIMAL["JumboPacket"]:
            issues.append(
                f"{adapter.name}: Jumbo frames not enabled "
                f"(current: {adapter.jumbo_packet}, need: {_WIN_OPTIMAL['JumboPacket']}). "
                f"Run 'lattice network --fix' as Administrator."
            )
        if adapter.receive_buffers != _WIN_OPTIMAL["ReceiveBuffers"]:
            issues.append(
                f"{adapter.name}: Receive buffers not maximized "
                f"(current: {adapter.receive_buffers}, need: {_WIN_OPTIMAL['ReceiveBuffers']}). "
                f"Run 'lattice network --fix' as Administrator."
            )


def _fix_windows():
    """Apply optimal NIC settings on Windows."""
    adapters = find_ethernet_adapters()
    if not adapters:
        print("No Ethernet adapter found.")
        return False

    success = True
    for adapter in adapters:
        print(f"Configuring: {adapter.name}")
        key = adapter.registry_key

        for reg_name, optimal_val in [
            ("*JumboPacket", _WIN_OPTIMAL["JumboPacket"]),
            ("*ReceiveBuffers", _WIN_OPTIMAL["ReceiveBuffers"]),
        ]:
            current = _reg_query(key, reg_name)
            if current == optimal_val:
                print(f"  {reg_name}: already {optimal_val}")
                continue

            ok = _reg_set(key, reg_name, optimal_val)
            if ok:
                print(f"  {reg_name}: {current} -> {optimal_val}")
            else:
                print(f"  {reg_name}: FAILED (are you running as Administrator?)")
                success = False

    if success:
        print()
        print("Settings applied. Restart the adapter or reboot for changes to take effect.")
        print("  Option 1: Device Manager > Network adapters > right-click > Disable, then Enable")
        print("  Option 2: Reboot the machine")

    return success


def _get_interface_mtus_win():
    """Parse netsh output for interface MTUs (Windows)."""
    result_map = {}
    try:
        result = subprocess.run(
            ["netsh", "interface", "ipv4", "show", "subinterfaces"],
            capture_output=True, text=True, timeout=5
        )
        for line in result.stdout.splitlines():
            match = re.match(r'\s*(\d+)\s+(\d+)\s+\d+\s+\d+\s+(.+)', line)
            if match:
                mtu = int(match.group(1))
                media_state = int(match.group(2))
                iface = match.group(3).strip()
                connected = (media_state == 1)
                result_map[iface] = (mtu, connected)
    except Exception:
        pass
    return result_map


def _reg_query(key, value_name):
    """Query a Windows registry value. Returns the value string or None."""
    try:
        result = subprocess.run(
            ["reg", "query", key, "/v", value_name],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            if value_name.lstrip("*") in line:
                parts = line.strip().split()
                if len(parts) >= 3:
                    return parts[-1]
    except Exception:
        pass
    return None


def _reg_set(key, value_name, value):
    """Set a Windows registry value. Returns True on success."""
    try:
        result = subprocess.run(
            ["reg", "add", key, "/v", value_name, "/t", "REG_SZ",
             "/d", str(value), "/f"],
            capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


# ============================================================================
# Linux implementation
# ============================================================================

def _find_adapters_linux():
    """Find physical Ethernet adapters on Linux."""
    import pathlib
    adapters = []
    net_dir = pathlib.Path("/sys/class/net")
    if not net_dir.exists():
        return adapters

    for iface in sorted(net_dir.iterdir()):
        name = iface.name
        # Skip loopback, wireless, virtual
        if name == "lo":
            continue
        if any(name.startswith(p) for p in
               ("wl", "ww", "docker", "br-", "veth", "virbr", "vnet")):
            continue
        # Check if it's a physical device
        if not (iface / "device").exists():
            continue

        info = NicInfo(name=name)

        # Get MTU
        try:
            mtu_path = iface / "mtu"
            if mtu_path.exists():
                info.interface_mtu = int(mtu_path.read_text().strip())
                info.jumbo_packet = str(info.interface_mtu)
        except Exception:
            pass

        # Get link state
        try:
            operstate = (iface / "operstate").read_text().strip()
            info.media_connected = operstate == "up"
        except Exception:
            pass

        # Get link speed
        try:
            speed_path = iface / "speed"
            if speed_path.exists():
                speed = speed_path.read_text().strip()
                if speed != "-1":
                    info.link_speed = f"{speed} Mbps"
        except Exception:
            pass

        # Get driver info via ethtool
        try:
            result = subprocess.run(
                ["ethtool", "-i", name],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.splitlines():
                if line.startswith("driver:"):
                    info.driver = line.split(":", 1)[1].strip()
                    break
        except Exception:
            pass

        # Get ring buffer settings
        try:
            result = subprocess.run(
                ["ethtool", "-g", name],
                capture_output=True, text=True, timeout=5)
            # Parse "Current hardware settings:" section
            in_current = False
            for line in result.stdout.splitlines():
                if "Current" in line:
                    in_current = True
                elif in_current and "RX:" in line:
                    rx = line.split(":")[-1].strip()
                    info.receive_buffers = rx
                    break
        except Exception:
            pass

        adapters.append(info)

    return adapters


def _diagnose_linux(adapter, issues, verbose):
    """Linux-specific NIC diagnostics."""
    if verbose:
        print(f"Interface: {adapter.name}")
        if adapter.driver:
            print(f"  Driver:          {adapter.driver}")
        if adapter.link_speed:
            print(f"  Link Speed:      {adapter.link_speed}")
        status = "connected" if adapter.media_connected else "disconnected"
        print(f"  Link State:      {status}")
        if adapter.interface_mtu is not None:
            mtu_ok = adapter.interface_mtu >= OPTIMAL["mtu"]
            print(f"  MTU:             {adapter.interface_mtu}"
                  f"  {'OK' if mtu_ok else 'NEEDS CONFIG (need >= 9000)'}")
        if adapter.receive_buffers != "N/A":
            print(f"  RX Ring Buffers: {adapter.receive_buffers}")
        print()

    if adapter.interface_mtu is not None and adapter.interface_mtu < OPTIMAL["mtu"]:
        issues.append(
            f"{adapter.name}: MTU too small ({adapter.interface_mtu}, "
            f"need >= {OPTIMAL['mtu']} for jumbo frames). "
            f"Run 'lattice network --fix' as root."
        )


def _fix_linux():
    """Apply optimal NIC settings on Linux (requires root)."""
    adapters = _find_adapters_linux()
    if not adapters:
        print("No Ethernet adapter found.")
        return False

    success = True
    for adapter in adapters:
        print(f"Configuring: {adapter.name}")

        # Set MTU for jumbo frames
        if adapter.interface_mtu is not None and adapter.interface_mtu < OPTIMAL["mtu"]:
            try:
                result = subprocess.run(
                    ["ip", "link", "set", adapter.name, "mtu",
                     str(OPTIMAL["mtu"])],
                    capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    print(f"  MTU: {adapter.interface_mtu} -> {OPTIMAL['mtu']}")
                else:
                    print(f"  MTU: FAILED ({result.stderr.strip()})")
                    print(f"       Try: sudo ip link set {adapter.name} mtu {OPTIMAL['mtu']}")
                    success = False
            except Exception as e:
                print(f"  MTU: FAILED ({e})")
                success = False
        else:
            print(f"  MTU: already {adapter.interface_mtu or 'N/A'}")

        # Try to increase RX ring buffers
        try:
            result = subprocess.run(
                ["ethtool", "-G", adapter.name, "rx",
                 str(OPTIMAL["rx_buffers"])],
                capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                print(f"  RX buffers: set to {OPTIMAL['rx_buffers']}")
            else:
                err = result.stderr.strip()
                if "not supported" in err.lower() or "not permitted" in err.lower():
                    print(f"  RX buffers: not configurable on this adapter")
                else:
                    print(f"  RX buffers: {err}")
        except FileNotFoundError:
            print("  RX buffers: ethtool not installed (apt install ethtool)")
        except Exception:
            pass

    if success:
        print()
        print("Settings applied.")
        print("  To make MTU persistent, add to /etc/network/interfaces or")
        print("  NetworkManager connection settings.")

    return success


# ============================================================================
# CLI entry point
# ============================================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(
        description="GigE Vision NIC diagnostics and setup"
    )
    parser.add_argument("--fix", action="store_true",
                        help="Apply optimal settings (requires elevated privileges)")
    parser.add_argument("--estimate", action="store_true",
                        help="Show bandwidth/FPS estimates")
    parser.add_argument("--cameras", type=int, default=1,
                        help="Number of cameras for estimate (default: 1)")
    parser.add_argument("--pixel-format", default="BayerRG8",
                        help="Pixel format for estimate (default: BayerRG8)")
    args = parser.parse_args()

    if args.fix:
        fix_settings()
    elif args.estimate:
        print(f"Bandwidth estimate: {args.cameras} camera(s), "
              f"{args.pixel_format}, 1 Gbps link")
        print()
        for jumbo in [True, False]:
            fps, bw, limited = bandwidth_estimate(
                args.cameras, args.pixel_format, jumbo
            )
            jf = "jumbo frames" if jumbo else "standard frames"
            limit = "link-limited" if limited else "sensor-limited"
            print(f"  {jf:20s}: {fps:5.1f} fps/camera, "
                  f"{bw:5.1f} MB/s total ({limit})")
        print()
        print(f"Multi-camera estimates ({args.pixel_format}, jumbo frames):")
        print(f"  {'Cameras':>8s}  {'FPS/cam':>8s}  "
              f"{'Total BW':>10s}  {'Bottleneck':>12s}")
        for n in range(1, 5):
            fps, bw, limited = bandwidth_estimate(n, args.pixel_format, True)
            limit = "link" if limited else "sensor"
            print(f"  {n:>8d}  {fps:>8.1f}  "
                  f"{bw:>8.1f} MB/s  {limit:>12s}")
    else:
        adapters, issues = diagnose(verbose=True)
        if issues:
            print("Issues found:")
            for issue in issues:
                print(f"  - {issue}")
        else:
            print("All settings look good for GigE Vision.")


if __name__ == "__main__":
    main()
