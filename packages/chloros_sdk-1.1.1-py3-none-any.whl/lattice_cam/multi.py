"""Multi-camera synchronized capture using GPIO hardware trigger.

Manages N LATTICE cameras organised into one or more SyncGroups.
Each group has one master that outputs ExposureActive on GPIO Line2
and N slaves that trigger on their Line2 input (RisingEdge).

Supports three sync modes:

- **cable** : Hardware GPIO trigger via M8 sync cables (default)
- **software** : Software trigger broadcast to all cameras
- **none** : Free-running, no synchronisation

**Single-frame (event capture)**::

    array = CameraArray.discover()
    array.configure_sync()
    array.start()
    trigger_ts, frames = array.grab_sync()   # (iso_ts, {serial: (frame, meta)})
    array.stop()

**Streaming (continuous at target FPS)**::

    array = CameraArray.discover()
    array.configure_sync()
    array.start()
    for trigger_ts, group in array.stream(fps=3, count=100):
        process(group)
    array.stop()
"""

import itertools
import logging
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import numpy as np

from lattice_cam.camera import (LatticeCam, discover_with_recovery,
                                 IncompleteBufferError,
                                 _buffer_payload_problem)
from lattice_cam.settings import CameraSettings
from lattice_cam.sync_config import SyncConfig, SyncGroupConfig, SyncMode

log = logging.getLogger(__name__)

# Default GPIO line for sync trigger. On the LATTICE
# 8-pin M8 GPIO, pin 2 brown is Line 2 (non-isolated bi-directional)
# and is the trigger pin on the standard MAPIR cable. Line 3 (pin 4
# purple) is also bi-directional, used as the fallback if a non-
# standard cable wires the trigger on pin 4 instead.
_SYNC_LINE = "Line2"
_SYNC_LINE_FALLBACK = "Line3"

# Reduced probe timeout — cameras on local cable respond fast
_PROBE_TIMEOUT_MS = 800


# ---------------------------------------------------------------------------
# SyncStats
# ---------------------------------------------------------------------------

@dataclass
class SyncStats:
    """Statistics from a synchronized capture session."""
    frame_groups: int = 0
    missed_frames: int = 0
    elapsed: float = 0.0
    clock_offsets_ns: List[int] = field(default_factory=list)

    @property
    def fps(self):
        return self.frame_groups / self.elapsed if self.elapsed > 0 else 0.0


# ---------------------------------------------------------------------------
# SyncGroup — one master + N slaves on a shared M8 cable chain
# ---------------------------------------------------------------------------

class SyncGroup:
    """A single synchronisation group: one master + N slaves.

    GigE cameras have independent internal clocks that start at power-on, so
    raw timestamps always have a constant offset.  ``verify_sync()`` measures
    *jitter* (change in offset between grabs) rather than the absolute offset,
    since that offset is meaningless without PTP.

    All camera arguments are ``(LatticeCam, serial_str)`` tuples, matching
    the convention used throughout the Chloros ``lattice_cam`` package.
    """

    def __init__(self, master, slaves, sync_cfg):
        """
        Parameters
        ----------
        master : tuple (LatticeCam, str)
        slaves : list of tuple (LatticeCam, str)
        sync_cfg : SyncConfig
        """
        self.master = master          # (LatticeCam, serial)
        self.slaves = list(slaves)    # [(LatticeCam, serial), ...]
        self.sync_cfg = sync_cfg
        self._clock_offsets = {}      # serial -> last offset_ns from master

    # -- helpers --------------------------------------------------------------

    @property
    def all_cameras(self):
        """All cameras in this group (master first)."""
        return [self.master] + self.slaves

    @property
    def master_serial(self):
        return self.master[1]

    @property
    def slave_serials(self):
        return [s for _, s in self.slaves]

    @property
    def serials(self):
        return [serial for _, serial in self.all_cameras]

    def _set_node_safe(self, cam, name, value):
        """Set a camera node, logging on failure instead of raising."""
        try:
            cam.set_node(name, value)
        except Exception as e:
            log.debug("Node %s=%s failed: %s", name, value, e)

    def _force_stop_acquisition(self):
        """Force-stop acquisition on every camera in this group.

        Clears stale acquisition state left by crashed or killed sessions
        so that trigger/GPIO nodes can be reconfigured safely.  Tries
        both SDK-level stop_stream and GenICam AcquisitionStop to cover
        all edge cases.
        """
        for cam, serial in self.all_cameras:
            # SDK transport layer
            try:
                cam._device.stop_stream()
            except Exception:
                pass
            # GenICam command node
            try:
                cam._device.nodemap.get_node("AcquisitionStop").execute()
            except Exception:
                pass
            # Reset Python-side tracking
            cam._streaming = False

    # -- configuration --------------------------------------------------------

    def configure(self):
        """Configure trigger wiring based on sync mode.

        Defensively stops any stale acquisition first so that
        trigger/GPIO node writes never hit SC_ERR_ACCESS_DENIED.
        """
        self._force_stop_acquisition()

        mode = self.sync_cfg.mode
        if mode == "cable":
            self._configure_cable()
        elif mode == "software":
            self._configure_software()
        elif mode == "none":
            self._configure_none()

        log.info(
            "SyncGroup configured: mode=%s, master=%s, slaves=%s",
            mode, self.master[1], self.slave_serials,
        )

    def _configure_cable(self):
        """Hardware GPIO trigger via M8 cables.

        Master stays in software-trigger mode so capture is explicitly
        requested (unlike the hub which runs free-running).  Each software
        trigger fires one exposure whose ExposureActive signal propagates
        to all slaves via the M8 cable.
        """
        sync = self.sync_cfg
        line = sync.exposure_output_line

        # Enable PTP on all cameras for timestamp alignment.  The authoritative
        # grandmaster is the Chloros host (ptp_master package inside
        # chloros-backend), so every camera is a slave in domain 0.  We also
        # write PtpDomainNumber — the dataclass has always had the field but
        # nothing used to plumb it through to the GigE node.
        if sync.ptp_enable:
            for cam, serial in self.all_cameras:
                self._set_node_safe(cam, "PtpEnable", True)
                self._set_node_safe(cam, "PtpSlaveOnly", True)
                self._set_node_safe(cam, "PtpDomainNumber", sync.ptp_domain)

        # Master: software trigger + ExposureActive output on GPIO
        m_cam = self.master[0]
        m_cam.set_node("TriggerMode", "On")
        m_cam.set_node("TriggerSource", "Software")
        m_cam.set_node("LineSelector", line)
        m_cam.set_node("LineMode", "Output")
        m_cam.set_node("LineSource", "ExposureActive")

        # Slaves: hardware trigger from GPIO line. On TRI032S 8-pin
        # M8 GPIO, pin 2 brown is Line 2 (non-isolated bi-directional)
        # on every camera. The standard MAPIR straight cable lands
        # the trigger on Line 2 on both master and slave.
        #
        # The bidirectional pin's mode (Output vs Input) is persisted
        # in the camera's flash. If an earlier code revision ever wrote
        # LineMode=Output to this serial, it stays Output across power
        # cycles — and the firmware refuses to bind TriggerSource to a
        # line that's currently configured as Output. So we must flip
        # LineMode=Input BEFORE writing TriggerSource. We also
        # toggle TriggerMode=Off during the rewrite because some
        # firmware revs lock the trigger config while it's armed.
        for cam, serial in self.slaves:
            self._set_node_safe(cam, "TriggerMode", "Off")

            self._set_node_safe(cam, "LineSelector", line)
            self._set_node_safe(cam, "LineMode", "Input")

            candidates = []
            if sync.trigger_source:
                candidates.append(sync.trigger_source)
            for src in ["Line2", "Line3", "Line0"]:
                if src not in candidates:
                    candidates.append(src)

            actual_source = None
            last_err = None
            for src in candidates:
                try:
                    cam.set_node("TriggerSource", src)
                    actual_source = src
                    break
                except Exception as e:
                    last_err = e
                    continue
            if actual_source is None:
                raise RuntimeError(
                    f"Slave {serial}: no valid TriggerSource — tried "
                    f"{candidates}, last err: {last_err}"
                )
            if actual_source != sync.trigger_source:
                log.info(
                    "Slave %s: TriggerSource fell back from %s -> %s "
                    "(firmware enum mismatch with master)",
                    serial, sync.trigger_source, actual_source,
                )

            if actual_source != line:
                self._set_node_safe(cam, "LineSelector", actual_source)
                self._set_node_safe(cam, "LineMode", "Input")

            cam.set_node("TriggerActivation", sync.trigger_activation)
            if sync.trigger_delay_us > 0:
                self._set_node_safe(cam, "TriggerDelay", sync.trigger_delay_us)
            self._set_node_safe(cam, "TriggerOverlap", sync.trigger_overlap)

            cam.set_node("TriggerMode", "On")

    def _configure_software(self):
        """Software trigger for all cameras in this group."""
        for cam, serial in self.all_cameras:
            cam.set_node("TriggerMode", "On")
            cam.set_node("TriggerSource", "Software")

    def _configure_none(self):
        """Free-running mode — no synchronisation."""
        for cam, serial in self.all_cameras:
            self._set_node_safe(cam, "TriggerMode", "Off")

    # -- stream control -------------------------------------------------------

    def start_streams(self, num_buffers=None):
        """Start acquisition — slaves first, then master.

        Defensively stops stale acquisition before starting so that
        reconnection after a crash succeeds without a power cycle.
        """
        self._force_stop_acquisition()
        for cam, serial in reversed(self.slaves):
            cam.start_stream(num_buffers)
        self.master[0].start_stream(num_buffers)

    def stop_streams(self):
        """Stop acquisition on all cameras (best-effort)."""
        for cam, serial in self.all_cameras:
            try:
                cam.stop_stream()
            except Exception as e:
                log.debug("stop_stream %s: %s", serial, e)
        # Belt-and-suspenders: issue AcquisitionStop in case stop_stream
        # failed (e.g. driver already cleaned up the handle)
        self._force_stop_acquisition()

    # -- grab -----------------------------------------------------------------

    def _wait_trigger_armed(self, cam, serial, timeout_s=2.0):
        """Block until the camera reports TriggerArmed == True.

        On LATTICE camera (and most GigE Vision cameras), issuing TriggerSoftware
        while the device is still reading out the previous frame is
        silently rejected — the camera does NOT queue the trigger. The
        slaves then never see the ExposureActive pulse and subsequent
        get_buffer() calls hang until the user-supplied timeout. Polling
        TriggerArmed first guarantees the camera is in a state where the
        trigger will actually take effect, turning an infinite hang into
        an explicit, timely RuntimeError when the hardware cannot keep up
        with the requested rate.
        """
        try:
            node = cam._device.nodemap.get_node("TriggerArmed")
        except Exception:
            return  # Node not exposed — fall back to best-effort trigger
        if node is None:
            return
        deadline = time.perf_counter() + timeout_s
        while True:
            try:
                if bool(node.value):
                    return
            except Exception:
                return  # Read failure: don't block the capture pipeline
            if time.perf_counter() >= deadline:
                raise RuntimeError(
                    f"Camera {serial} did not arm trigger within "
                    f"{timeout_s:.1f}s — previous frame transfer likely "
                    f"still in progress (check link bandwidth / pixel format)."
                )
            time.sleep(0.001)

    def _trigger(self):
        """Fire the appropriate trigger and return the UTC ISO timestamp."""
        mode = self.sync_cfg.mode
        if mode == "cable":
            master_cam, master_serial = self.master
            self._wait_trigger_armed(master_cam, master_serial)
            master_cam.trigger_software()
        elif mode == "software":
            for cam, serial in self.all_cameras:
                self._wait_trigger_armed(cam, serial)
                cam.trigger_software()
        # mode == "none": free-running, just grab next available frame
        return datetime.now(timezone.utc).isoformat()

    def _retrieve_buffers(self, timeout):
        """Retrieve raw bayer arrays from all cameras in parallel.

        Gets data out of the SDK buffer pool as fast as possible so
        buffers are requeued promptly (critical with many cameras).
        Returns ``{serial: (raw_2d_array, meta_dict)}``.
        """
        from lattice_cam.convert import buffer_to_numpy

        def _fetch(cam, serial):
            buf = cam._device.get_buffer(timeout=timeout)
            try:
                reason = _buffer_payload_problem(buf)
                if reason:
                    raise IncompleteBufferError(
                        f"GVSP packet loss on {serial} ({reason}): "
                        f"tail rows would contain stale bytes")
                meta = {
                    "timestamp_ns": buf.timestamp_ns,
                    "frame_id": buf.frame_id,
                    "width": buf.width,
                    "height": buf.height,
                    "pixel_format": cam.settings.pixel_format,
                    "serial": serial,
                }
                try:
                    chunk = cam.read_chunk_metadata()
                    meta["exposure_time_us"] = chunk.get("exposure_time_us")
                    meta["gain_db"] = chunk.get("gain_db")
                except Exception:
                    pass
                raw = buffer_to_numpy(buf)
            finally:
                cam._device.requeue_buffer(buf)
            return serial, raw, meta

        cameras = self.all_cameras
        results = {}

        # Fut-level wall-clock cap. Normally Arena's get_buffer honours
        # ``timeout`` (in ms), but we've observed pathological cases at
        # BayerRG12 + 4 cams + 1500-byte packets where get_buffer hangs
        # past its own timeout. Cap the Python-side wait so a stuck
        # camera raises rather than blocking the whole pipeline.
        fut_timeout_s = max(0.5, (timeout / 1000.0) + 2.0)

        if len(cameras) <= 1:
            # Fast path: no threading overhead for single camera
            for cam, serial in cameras:
                try:
                    s, raw, meta = _fetch(cam, serial)
                    results[s] = (raw, meta)
                except Exception as e:
                    log.error("Camera %s buffer failed: %s", serial, e)
        else:
            with ThreadPoolExecutor(max_workers=len(cameras)) as pool:
                futs = {
                    pool.submit(_fetch, cam, serial): serial
                    for cam, serial in cameras
                }
                for fut in futs:
                    try:
                        s, raw, meta = fut.result(timeout=fut_timeout_s)
                        results[s] = (raw, meta)
                    except Exception as e:
                        log.error("Camera %s buffer failed: %s",
                                  futs[fut], e)

        return results

    def grab(self, timeout=5000, processing_config=None):
        """Grab one synchronised frame group.

        Triggers all cameras, retrieves raw buffers in parallel (freeing
        SDK buffers immediately), then demosaics. Returns BGR frames.

        When *processing_config* is provided and its tier is ``PLUS``,
        uses GPU batched demosaic (``gpu_demosaic_batch``).  Otherwise
        uses CPU demosaic — parallel via ThreadPoolExecutor when
        multiple cameras are present (cv2.cvtColor releases the GIL).

        Parameters
        ----------
        timeout : int
            Buffer retrieval timeout in ms.
        processing_config : ProcessingConfig, optional
            From :func:`lattice_cam.processing.get_processing_config`.
            ``None`` uses CPU demosaic (backwards-compatible default).

        Returns
        -------
        tuple
            ``(trigger_timestamp_utc_iso, {serial: (frame_bgr, meta_dict)})``
        """
        trigger_ts = self._trigger()
        raw_results = self._retrieve_buffers(timeout)

        if not raw_results:
            return trigger_ts, {}

        # GPU batched demosaic path (Chloros+ tier)
        use_gpu = (processing_config is not None
                   and processing_config.use_gpu)
        if use_gpu:
            return trigger_ts, self._demosaic_gpu(raw_results)

        # CPU demosaic path
        return trigger_ts, self._demosaic_cpu(raw_results)

    def _demosaic_gpu(self, raw_results):
        """Batch GPU demosaic — uploads all frames at once."""
        from lattice_cam.gpu_ops import gpu_demosaic_batch

        serials = list(raw_results.keys())
        raws = [raw_results[s][0] for s in serials]
        fmts = [raw_results[s][1]["pixel_format"] for s in serials]

        bgr_list = gpu_demosaic_batch(raws, fmts)

        results = {}
        for i, serial in enumerate(serials):
            results[serial] = (bgr_list[i], raw_results[serial][1])
        return results

    def _demosaic_cpu(self, raw_results):
        """CPU demosaic — single-threaded for 1 camera, parallel for N."""
        from lattice_cam.convert import numpy_to_bgr

        if len(raw_results) <= 1:
            results = {}
            for serial, (raw, meta) in raw_results.items():
                results[serial] = (
                    numpy_to_bgr(raw, meta["pixel_format"]), meta)
            return results

        # Parallel demosaic (cv2.cvtColor releases the GIL)
        def _demosaic(serial, raw, meta):
            return serial, numpy_to_bgr(raw, meta["pixel_format"]), meta

        results = {}
        with ThreadPoolExecutor(max_workers=len(raw_results)) as pool:
            futs = [
                pool.submit(_demosaic, s, raw, meta)
                for s, (raw, meta) in raw_results.items()
            ]
            for fut in futs:
                s, frame, meta = fut.result()
                results[s] = (frame, meta)

        return results

    def grab_raw(self, timeout=5000):
        """Like ``grab()`` but returns raw Bayer arrays (no demosaic).

        Returns
        -------
        tuple
            ``(trigger_timestamp_utc_iso, {serial: (raw_frame, meta_dict)})``
        """
        trigger_ts = self._trigger()
        return trigger_ts, self._retrieve_buffers(timeout)

    # -- jitter verification --------------------------------------------------

    def verify_sync(self, results):
        """Check timestamp jitter within this group.

        Measures the *change* in clock offset between consecutive grabs
        for each slave relative to the master.  This is the true sync
        quality metric — the absolute offset is meaningless without PTP.
        """
        master_serial = self.master[1]
        if master_serial not in results:
            return

        master_ts = results[master_serial][1].get("timestamp_ns")
        if master_ts is None:
            return

        for serial, (frame, meta) in results.items():
            if serial == master_serial:
                continue
            ts = meta.get("timestamp_ns")
            if ts is None:
                continue

            offset_ns = ts - master_ts

            if serial in self._clock_offsets:
                prev_offset = self._clock_offsets[serial]
                jitter_us = abs(offset_ns - prev_offset) / 1000
                max_jitter = self.sync_cfg.max_timestamp_drift_us

                log.info(
                    "Sync %s->%s: offset=%.1f ms, jitter=%.1f us (limit: %d us)",
                    master_serial, serial,
                    offset_ns / 1_000_000, jitter_us, max_jitter,
                )

                if jitter_us > max_jitter:
                    log.warning(
                        "Sync jitter %s->%s: %.0f us EXCEEDS limit %d us",
                        master_serial, serial, jitter_us, max_jitter,
                    )
            else:
                log.info(
                    "Sync %s->%s: initial clock offset=%.1f ms",
                    master_serial, serial, offset_ns / 1_000_000,
                )

            self._clock_offsets[serial] = offset_ns


# ---------------------------------------------------------------------------
# Cable chain probing (auto-detect master/slave topology)
# ---------------------------------------------------------------------------

def _probe_cable_chain(candidate_master, candidates, sync_cfg,
                       probe_timeout_ms=_PROBE_TIMEOUT_MS):
    """Probe which cameras are on the same M8 cable chain as *candidate_master*.

    Temporarily configures the candidate as a master (ExposureActive output on
    Line2) and all candidates as slaves (trigger on Line2).  Fires the master's
    exposure and checks which candidates receive the trigger.

    Parameters
    ----------
    candidate_master : tuple (LatticeCam, str)
    candidates : list of tuple (LatticeCam, str)
    sync_cfg : SyncConfig
    probe_timeout_ms : int

    Returns
    -------
    list of tuple (LatticeCam, str)
        Cameras that responded (i.e. on the same cable).
        All cameras are stopped when this function returns.
    """
    line = sync_cfg.exposure_output_line
    source = sync_cfg.trigger_source
    activation = sync_cfg.trigger_activation
    overlap = sync_cfg.trigger_overlap

    m_cam, m_serial = candidate_master

    # Configure candidate master: output ExposureActive on Line2
    m_cam.set_node("LineSelector", line)
    m_cam.set_node("LineMode", "Output")
    m_cam.set_node("LineSource", "ExposureActive")
    m_cam.set_node("TriggerMode", "Off")

    # Configure all candidates as slaves. On TRI032S 8-pin M8
    # the standard MAPIR cable delivers the trigger on pin 2 brown
    # = Line 2 — try Line 2 first, then fall back.
    for cam, serial in candidates:
        cam.set_node("TriggerMode", "On")

        candidates_src = []
        if source:
            candidates_src.append(source)
        for s in ["Line2", "Line3", "Line0"]:
            if s not in candidates_src:
                candidates_src.append(s)
        bound = None
        for s in candidates_src:
            try:
                cam.set_node("TriggerSource", s)
                bound = s
                break
            except Exception:
                continue
        if bound is None:
            log.warning(
                "Probe slave %s: no valid TriggerSource — tried %s; "
                "skipping this candidate",
                serial, candidates_src,
            )
            continue

        cam.set_node("TriggerActivation", activation)
        try:
            cam.set_node("TriggerOverlap", overlap)
        except Exception:
            pass

    # Start streams: candidates first, then master
    for cam, serial in candidates:
        cam.start_stream()
    m_cam.start_stream()

    # Fire master exposure (grab triggers ExposureActive output)
    responding = []
    try:
        m_cam.grab_frame(timeout=probe_timeout_ms)
    except Exception as e:
        log.warning("Probe master %s grab failed: %s", m_serial, e)

    # Check which candidates received the trigger
    for cam, serial in candidates:
        try:
            cam.grab_frame(timeout=probe_timeout_ms)
            responding.append((cam, serial))
        except Exception:
            pass  # Not on this cable chain

    # Stop all streams
    m_cam.stop_stream()
    for cam, serial in candidates:
        cam.stop_stream()

    return responding


def _probe_all_cable_groups(cameras, sync_cfg,
                            probe_timeout_ms=_PROBE_TIMEOUT_MS):
    """Auto-detect all cable sync groups by iteratively probing cable chains.

    M8 cables are uni-directional (signal only flows master -> slave), so we
    try each ungrouped camera as a candidate master until we find one that
    has responding slaves.

    Parameters
    ----------
    cameras : list of tuple (LatticeCam, str)
    sync_cfg : SyncConfig
    probe_timeout_ms : int

    Returns
    -------
    list of SyncGroup
    """
    ungrouped = list(cameras)
    groups = []

    while ungrouped:
        if len(ungrouped) == 1:
            groups.append(SyncGroup(ungrouped[0], [], sync_cfg))
            log.info("Single-camera group: %s", ungrouped[0][1])
            break

        # Try each camera as master until one gets responding slaves
        found_master = False
        for idx, candidate in enumerate(ungrouped):
            other = [c for c in ungrouped if c is not candidate]

            log.info(
                "Probing cable chain for master candidate %s against %d camera(s)...",
                candidate[1], len(other),
            )
            responding = _probe_cable_chain(
                candidate, other, sync_cfg, probe_timeout_ms,
            )

            if responding:
                groups.append(SyncGroup(candidate, responding, sync_cfg))
                log.info(
                    "Discovered group: master=%s, slaves=%s",
                    candidate[1], [s for _, s in responding],
                )
                grouped_serials = {candidate[1]} | {s for _, s in responding}
                ungrouped = [c for c in ungrouped
                             if c[1] not in grouped_serials]
                found_master = True
                break

        if not found_master:
            # No camera could trigger any other — put all in separate groups
            for cam_tuple in ungrouped:
                groups.append(SyncGroup(cam_tuple, [], sync_cfg))
                log.warning(
                    "No cable chain detected for %s — solo group",
                    cam_tuple[1],
                )
            break

    return groups


# ---------------------------------------------------------------------------
# Standalone master detection (diagnostic / CLI utility)
# ---------------------------------------------------------------------------

def detect_master(line=None, verbose=True):
    """Probe GPIO wiring to identify which camera is the master.

    Connects all cameras, then tests each one as a potential master
    by configuring it to output ExposureActive on the sync line and
    checking if the other cameras receive the trigger.

    If no ``line`` is given, tries the default M8-cable line (Line0)
    first; if no master is detected, retries on Line2 in case the
    user's rig uses the bidirectional non-isolated line. The returned
    dict reflects whichever line succeeded; ``line`` in the result is
    the one that produced detection (so the caller can configure
    sync on the same line).

    Parameters
    ----------
    line : str, optional
        Specific GPIO line to test. If None, auto-tries Line0 then
        Line2.
    verbose : bool
        Print progress and results.

    Returns
    -------
    dict
        {"master": serial_str or None,
         "slaves": [serial_str, ...],
         "no_cable": [serial_str, ...],
         "line": "Line0" | "Line2",
         "results": {serial: {"triggered": [serial, ...], "missed": [serial, ...]}}}
    """
    if line is None:
        # Auto-try the default first; fall back if it either finds
        # no master OR raises (e.g. LATTICE camera's Line0 is Input-only and
        # writing LineMode=Output throws ValueError). Without
        # catching the raise, that single bad-line attempt would
        # propagate up and the caller never gets a chance to try
        # the fallback line.
        try:
            first = _detect_master_on(_SYNC_LINE, verbose=verbose)
            if first.get("master"):
                first["line"] = _SYNC_LINE
                return first
            first_failed = False
        except Exception as e:
            first_failed = True
            if verbose:
                print(f"  Probe on {_SYNC_LINE} raised "
                      f"{type(e).__name__}: {e}", flush=True)
        if verbose:
            reason = "no master detected" if not first_failed else "errored"
            print(f"  Probe on {_SYNC_LINE} {reason}; "
                  f"retrying on {_SYNC_LINE_FALLBACK}...", flush=True)
        try:
            second = _detect_master_on(_SYNC_LINE_FALLBACK, verbose=verbose)
            second["line"] = _SYNC_LINE_FALLBACK
            return second
        except Exception as e:
            if verbose:
                print(f"  Probe on {_SYNC_LINE_FALLBACK} also raised "
                      f"{type(e).__name__}: {e}", flush=True)
            return {
                "master": None,
                "slaves": [],
                "no_cable": [],
                "line": _SYNC_LINE_FALLBACK,
                "results": {},
            }
    return _detect_master_on(line, verbose=verbose)


def _detect_master_on(line, verbose=True):
    """Single-line probe — see ``detect_master`` for the auto-fallback wrapper."""
    sync_line = line

    # Discover
    device_infos = discover_with_recovery(verbose=False)
    if not device_infos:
        raise RuntimeError("No cameras found")
    device_infos = sorted(device_infos, key=lambda d: d.get("serial", ""))

    if len(device_infos) < 2:
        serial = device_infos[0].get("serial", "?")
        if verbose:
            print(f"  Only 1 camera found (SN:{serial}) — it is the master by default.")
        return {
            "master": serial,
            "slaves": [],
            "no_cable": [],
            "results": {serial: {"triggered": [], "missed": []}},
        }

    # Connect all cameras with a neutral trigger config (software trigger)
    probe_settings = CameraSettings(
        exposure_time=5000.0,
        exposure_auto="Off",
        gain=0.0,
        gain_auto="Off",
        trigger_mode="On",
        trigger_source="Software",
        buffer_handling_mode="OldestFirst",
        stream_num_buffers=10,
    )

    from arena_api.system import system
    cameras = []  # [(device, serial), ...]
    for info in device_infos:
        serial = info.get("serial", "?")
        dev = system.create_device(device_infos=[info])[0]
        cameras.append((dev, serial))

    serials = [s for _, s in cameras]
    if verbose:
        print(f"  Found {len(cameras)} cameras: {', '.join(serials)}")
        print(f"  Probing GPIO {sync_line}...\n")

    results = {}

    for candidate_idx in range(len(cameras)):
        candidate_dev, candidate_serial = cameras[candidate_idx]
        others = [(d, s) for i, (d, s) in enumerate(cameras) if i != candidate_idx]

        if verbose:
            print(f"  Testing SN:{candidate_serial} as master...", end="", flush=True)

        # Configure candidate as master: software trigger + Line2 output
        nm = candidate_dev.nodemap
        nm.get_node("TriggerMode").value = "On"
        nm.get_node("TriggerSource").value = "Software"
        nm.get_node("LineSelector").value = sync_line
        nm.get_node("LineMode").value = "Output"
        nm.get_node("LineSource").value = "ExposureActive"

        # Configure others as slaves: trigger on sync line
        for dev, serial in others:
            onm = dev.nodemap
            onm.get_node("TriggerMode").value = "On"
            onm.get_node("TriggerSource").value = sync_line
            onm.get_node("TriggerActivation").value = "RisingEdge"

        # Start all streams (slaves first)
        for dev, serial in others:
            dev.start_stream(10)
        candidate_dev.start_stream(10)
        time.sleep(0.3)

        # Fire software trigger on candidate
        nm.get_node("TriggerSoftware").execute()
        time.sleep(0.1)

        # Check candidate got its own frame
        try:
            buf = candidate_dev.get_buffer(timeout=2000)
            candidate_dev.requeue_buffer(buf)
        except Exception:
            pass  # candidate should always get its own frame

        # Check which slaves received the trigger
        triggered = []
        missed = []
        for dev, serial in others:
            try:
                buf = dev.get_buffer(timeout=1000)
                dev.requeue_buffer(buf)
                triggered.append(serial)
            except Exception:
                missed.append(serial)

        results[candidate_serial] = {"triggered": triggered, "missed": missed}

        # Stop all streams
        candidate_dev.stop_stream()
        for dev, serial in others:
            dev.stop_stream()

        # Reset candidate line back to input
        nm.get_node("LineSelector").value = sync_line
        nm.get_node("LineMode").value = "Input"

        n_triggered = len(triggered)
        n_others = len(others)
        if verbose:
            if n_triggered == n_others:
                print(f" triggered {n_triggered}/{n_others} slaves -> MASTER")
            elif n_triggered > 0:
                print(f" triggered {n_triggered}/{n_others} slaves -> PARTIAL")
            else:
                print(f" triggered 0/{n_others} -> not master")

    # Clean up
    for dev, serial in cameras:
        system.destroy_device(dev)

    # Determine master: the camera that triggered ALL others
    master = None
    slaves = []
    no_cable = list(serials)  # assume no cable until proven otherwise

    for serial, res in results.items():
        if len(res["triggered"]) == len(serials) - 1:
            master = serial
            slaves = res["triggered"]
            no_cable = []
            break

    # If no single camera triggered all others, check for partial
    if master is None:
        for serial, res in results.items():
            if res["triggered"]:
                master = serial
                slaves = res["triggered"]
                no_cable = res["missed"]
                break

    if verbose:
        print()
        if master:
            print(f"  Result: MASTER = SN:{master}")
            if slaves:
                print(f"          SLAVES = {', '.join('SN:' + s for s in slaves)}")
            if no_cable:
                print(f"          NO CABLE = {', '.join('SN:' + s for s in no_cable)}")
        else:
            print(f"  Result: No master detected — GPIO cable may not be connected.")

    return {
        "master": master,
        "slaves": slaves,
        "no_cable": no_cable,
        "results": results,
    }


# ---------------------------------------------------------------------------
# CameraArray — manages multiple SyncGroups
# ---------------------------------------------------------------------------

class CameraArray:
    """Synchronized multi-camera manager.

    Organises discovered cameras into one or more :class:`SyncGroup` objects
    and delegates trigger, capture, and stream operations to them.

    Parameters
    ----------
    cameras : list of (LatticeCam, str)
        List of (camera, serial) tuples.
    master_settings : CameraSettings
        Settings for master cameras (software trigger).
    slave_settings : CameraSettings
        Settings for slave cameras (Line2 hardware trigger).
    sync_cfg : SyncConfig, optional
        Synchronisation configuration (default: cable mode).
    """

    def __init__(self, cameras, master_settings=None, slave_settings=None,
                 sync_cfg=None):
        if len(cameras) < 1:
            raise ValueError("Need at least 1 camera")

        self._cameras = cameras  # [(LatticeCam, serial), ...]
        self._master = cameras[0]
        self._slaves = cameras[1:]
        self._streaming = False
        self._synced = False
        self._stats = SyncStats()
        self._groups: List[SyncGroup] = []

        self._master_settings = master_settings
        self._slave_settings = slave_settings
        self._sync_cfg = sync_cfg or SyncConfig()

        # The adaptive heuristic used to mutate ``sync_cfg.ptp_enable``
        # permanently — that corrupted re-evaluations because the next
        # pass saw the heuristic's previous decision instead of the
        # user's original request. Snapshot the user intent once here
        # and always read from this field, never from a mutated config.
        self._user_ptp_enable: bool = self._sync_cfg.ptp_enable

        # Cached "last applied" topology signature. The hot-plug watcher
        # re-probes on an interval and skips the disruptive reconfigure
        # when the probe result matches this signature.
        self._last_topology: Optional[Tuple[int, bool, bool]] = None

        # Hot-plug watcher thread + shutdown event. Started at the end
        # of the first configure_sync() if enabled in sync_cfg.
        self._hotplug_thread: Optional[threading.Thread] = None
        self._hotplug_stop: threading.Event = threading.Event()

        # Auto-configure on construction. Callers used to have to call
        # configure_sync() manually and would silently run on whatever
        # PTP state the cameras were last written to — now every freshly
        # discovered array reflects the current LAN topology.
        try:
            self.configure_sync()
        except Exception as exc:
            log.warning("Auto configure_sync on __init__ failed: %s. "
                         "Call configure_sync() manually to retry.", exc)

    # -- Discovery & construction ---------------------------------------------

    @classmethod
    def discover(cls, settings=None, master_serial=None, auto_detect=False,
                 sync_cfg=None):
        """Discover all cameras and create a CameraArray.

        Parameters
        ----------
        settings : CameraSettings, optional
            Base imaging settings (exposure, gain, etc.).
            Trigger and bandwidth settings are managed automatically.
        master_serial : str, optional
            Serial number to designate as master.
            Defaults to the first camera (lowest serial number).
        auto_detect : bool
            If True, probe GPIO wiring to identify the master camera
            before connecting. Ignored if master_serial is provided.
        sync_cfg : SyncConfig, optional
            Synchronisation configuration (default: cable mode).

        Returns
        -------
        CameraArray
        """
        cfg = sync_cfg or SyncConfig()

        # Use sync_cfg.master_serial if set and not "auto"
        if master_serial is None and cfg.master_serial != "auto":
            master_serial = cfg.master_serial

        # Auto-detect master via GPIO probe
        if auto_detect and master_serial is None:
            result = detect_master(verbose=True)
            if result["master"]:
                master_serial = result["master"]

        base = settings or CameraSettings(
            exposure_time=10000.0,
            exposure_auto="Off",
            gain=0.0,
            gain_auto="Off",
        )

        # Build master and slave settings from the base
        master_settings = CameraSettings(
            width=base.width, height=base.height,
            offset_x=base.offset_x, offset_y=base.offset_y,
            pixel_format=base.pixel_format,
            exposure_time=base.exposure_time,
            exposure_auto=base.exposure_auto,
            gain=base.gain, gain_auto=base.gain_auto,
            target_brightness=base.target_brightness,
            ae_damping=base.ae_damping,
            ae_upper_limit=base.ae_upper_limit,
            ae_aoi_fraction=base.ae_aoi_fraction,
            balance_white_auto=base.balance_white_auto,
            balance_ratio_red=base.balance_ratio_red,
            balance_ratio_blue=base.balance_ratio_blue,
            gamma=base.gamma, gamma_enable=base.gamma_enable,
            lut_enable=base.lut_enable, ccm_enable=base.ccm_enable,
            acquisition_mode="Continuous",
            trigger_mode="On",
            trigger_source="Software",
            frame_rate_enable=False,
            buffer_handling_mode="OldestFirst",
            stream_num_buffers=20,
            gev_packet_size=base.gev_packet_size,
            gev_packet_size_auto=base.gev_packet_size_auto,
        )

        slave_settings = CameraSettings(
            width=base.width, height=base.height,
            offset_x=base.offset_x, offset_y=base.offset_y,
            pixel_format=base.pixel_format,
            exposure_time=base.exposure_time,
            exposure_auto=base.exposure_auto,
            gain=base.gain, gain_auto=base.gain_auto,
            target_brightness=base.target_brightness,
            ae_damping=base.ae_damping,
            ae_upper_limit=base.ae_upper_limit,
            ae_aoi_fraction=base.ae_aoi_fraction,
            balance_white_auto=base.balance_white_auto,
            balance_ratio_red=base.balance_ratio_red,
            balance_ratio_blue=base.balance_ratio_blue,
            gamma=base.gamma, gamma_enable=base.gamma_enable,
            lut_enable=base.lut_enable, ccm_enable=base.ccm_enable,
            acquisition_mode="Continuous",
            trigger_mode="On",
            trigger_source=_SYNC_LINE,
            frame_rate_enable=False,
            buffer_handling_mode="OldestFirst",
            stream_num_buffers=20,
            gev_packet_size=base.gev_packet_size,
            gev_packet_size_auto=base.gev_packet_size_auto,
        )

        # Discover cameras
        device_infos = discover_with_recovery(verbose=True)
        if not device_infos:
            raise RuntimeError("No cameras found")

        # Sort by serial (stable indices)
        device_infos = sorted(device_infos, key=lambda d: d.get("serial", ""))

        # Optionally reorder so master_serial is first
        if master_serial:
            idx = None
            for i, info in enumerate(device_infos):
                if info.get("serial") == master_serial:
                    idx = i
                    break
            if idx is None:
                serials = [d.get("serial", "?") for d in device_infos]
                raise RuntimeError(
                    f"Master serial '{master_serial}' not found. "
                    f"Available: {', '.join(serials)}"
                )
            if idx != 0:
                device_infos.insert(0, device_infos.pop(idx))

        # Connect all cameras
        cameras = []
        for i, info in enumerate(device_infos):
            serial = info.get("serial", "?")
            s = master_settings if i == 0 else slave_settings
            cam = LatticeCam(device_index=i, settings=s)
            cam.connect()
            cameras.append((cam, serial))

        return cls(cameras, master_settings, slave_settings, sync_cfg=cfg)

    # -- Properties -----------------------------------------------------------

    @property
    def groups(self) -> List[SyncGroup]:
        """All configured sync groups."""
        return list(self._groups)

    @property
    def master(self) -> LatticeCam:
        return self._master[0]

    @property
    def master_serial(self) -> str:
        return self._master[1]

    @property
    def serials(self) -> List[str]:
        return [serial for _, serial in self._cameras]

    @property
    def count(self) -> int:
        return len(self._cameras)

    @property
    def is_streaming(self) -> bool:
        return self._streaming

    @property
    def stats(self) -> SyncStats:
        return self._stats

    @property
    def sync_cfg(self) -> SyncConfig:
        return self._sync_cfg

    # -- PTP health ----------------------------------------------------------

    def ptp_status(self) -> List[dict]:
        """Read PTP state from each camera.

        Returns a list of per-camera dicts with whatever PTP nodes the
        camera firmware exposes.  Typical LUCID LATTICE camera fields: PtpStatus
        ("Master" / "Slave" / "Listening" / "Uncalibrated" / "Disabled"),
        PtpOffsetFromMaster (nanoseconds; signed), PtpClockID (the slave
        clock's own identity), PtpClockGrandmasterClockId (the elected
        grandmaster's identity — should match ``ptp_master.clock_identity``
        from the Chloros host's grandmaster).

        Unavailable or unreadable nodes are omitted rather than raising,
        so this method never throws for individual camera quirks.

        Returns
        -------
        list of dict
            One entry per camera in discovery order.  Each dict has at
            least ``serial``; other keys are present only when the node
            could be read.
        """
        interesting = (
            "PtpStatus",
            "PtpOffsetFromMaster",
            "PtpClockID",
            "PtpClockGrandmasterClockId",
            "PtpDomainNumber",
            "PtpMeanPathDelay",
            "PtpSlaveOnly",
            "PtpEnable",
        )
        rows: List[dict] = []
        for cam, serial in self._cameras:
            row: dict = {"serial": serial}
            try:
                nm = cam._device.nodemap
            except Exception:
                rows.append(row)
                continue
            for node_name in interesting:
                try:
                    node = nm.get_node(node_name)
                    if node is None:
                        continue
                    row[node_name] = node.value
                except Exception:
                    continue
            rows.append(row)
        return rows

    # -- Sync group building --------------------------------------------------

    def _build_groups_fast_path(self) -> Optional[List[SyncGroup]]:
        """Try to build groups from config without cable probing.

        Fast path is used when:
        1. config groups is non-empty and all serials are discovered, OR
        2. master_serial is set (not "auto") and found among discovered cameras.

        Returns None if fast path can't be used (fall back to probing).
        """
        sync = self._sync_cfg
        discovered = {serial for _, serial in self._cameras}
        cam_by_serial = {serial: (cam, serial)
                         for cam, serial in self._cameras}

        # Option 1: explicit groups in config
        if sync.groups:
            groups = self._build_groups_from_config()
            grouped_serials = set()
            for g in groups:
                grouped_serials.add(g.master_serial)
                grouped_serials.update(g.slave_serials)

            missing = grouped_serials - discovered
            if missing:
                log.warning(
                    "Fast path: config groups reference missing cameras %s",
                    missing,
                )
                return None

            log.info("Fast path: using %d config-defined group(s)", len(groups))
            return groups

        # Option 2: master_serial set (not "auto")
        if sync.master_serial != "auto" and sync.master_serial in cam_by_serial:
            master = cam_by_serial[sync.master_serial]
            slaves = [c for c in self._cameras
                      if c[1] != sync.master_serial]
            group = SyncGroup(master, slaves, sync)
            log.info(
                "Fast path: master=%s, %d slave(s) (probe skipped)",
                master[1], len(slaves),
            )
            return [group]

        return None

    def _build_groups(self) -> List[SyncGroup]:
        """Build sync groups — fast path first, then probe if needed."""
        sync = self._sync_cfg

        # Fast path: skip probing when config already defines the layout
        if sync.fast_path_enabled and sync.mode == "cable":
            fast = self._build_groups_fast_path()
            if fast is not None:
                return fast
            log.info("Fast path unavailable — falling back to cable probe")

        if sync.mode == "cable":
            # Auto-detect cable chains by probing
            return _probe_all_cable_groups(self._cameras, sync)

        # Software / none: all cameras in one group
        master = self._cameras[0]
        slaves = self._cameras[1:]
        log.info("Non-cable mode: single group, master=%s", master[1])
        return [SyncGroup(master, slaves, sync)]

    def _build_groups_from_config(self) -> List[SyncGroup]:
        """Build SyncGroup objects from explicit config groups (override)."""
        sync = self._sync_cfg
        cam_by_serial = {serial: (cam, serial)
                         for cam, serial in self._cameras}
        groups = []
        for gcfg in sync.groups:
            master = cam_by_serial.get(gcfg.master)
            if master is None:
                log.warning(
                    "Sync group master %s not found, skipping group",
                    gcfg.master,
                )
                continue
            slaves = []
            for s_serial in gcfg.slaves:
                slave = cam_by_serial.get(s_serial)
                if slave is None:
                    log.warning(
                        "Sync group slave %s not found, skipping", s_serial,
                    )
                else:
                    slaves.append(slave)
            groups.append(SyncGroup(master, slaves, sync))
        return groups

    # -- GPIO sync configuration ----------------------------------------------

    def configure_sync(self, line=None, sync_cfg=None, force=False):
        """Set up sync groups and configure trigger wiring.

        Idempotent: re-running with an unchanged LAN topology is a
        no-op, so it's safe for the hot-plug watcher to call
        frequently. The ``force=True`` path skips the unchanged-check
        and always rebuilds sync groups — useful for recovering from a
        crashed session where stale acquisition state has to be kicked
        even though the topology decision would match.

        Defensively stops stale acquisition on all cameras before
        (re)configuring so that reconnection after a crash succeeds.

        Parameters
        ----------
        line : str, optional
            GPIO line name (default: "Line2"). Used as
            ``exposure_output_line`` if no sync_cfg overrides it.
        sync_cfg : SyncConfig, optional
            Override the array's sync configuration.
        force : bool, optional
            Rebuild sync groups even when the topology decision
            matches the last applied one.
        """
        if sync_cfg is not None:
            self._sync_cfg = sync_cfg
        if line is not None:
            # On TRI032S 8-pin M8 GPIO, pin 2 brown = Line 2 on every
            # camera (per Lucid pinout doc, firmware 1.163.0.0).
            # The standard MAPIR cable is straight pin-2-to-pin-2,
            # so master output and slave input land on the same Line
            # on every cam. Update both ends.
            self._sync_cfg.exposure_output_line = line
            self._sync_cfg.trigger_source = line

        # Evaluate the cheap LAN topology probes BEFORE deciding to
        # disrupt the stream. If the decision matches what we already
        # applied, we can return without touching the cameras at all —
        # key to making the hot-plug watcher safe to run mid-stream.
        topology = self._evaluate_topology(self._sync_cfg)
        if not force and self._synced and topology == self._last_topology:
            log.debug("configure_sync: topology unchanged, skipping.")
            return

        if self._synced and self._last_topology is not None \
                and topology != self._last_topology:
            log.warning(
                "LAN topology changed (was %s, now %s) — reconfiguring. "
                "Active streams will pause for 1-3 s while cameras "
                "re-arm.", self._last_topology, topology,
            )
            if self._streaming:
                log.warning(
                    "STREAM WILL PAUSE: hot-plug reconfigure in progress. "
                    "Frames in flight may be dropped."
                )

        # Apply: blanket force-stop, rebuild sync groups, write trigger +
        # PTP settings per the fresh decision.
        self._apply_configuration(topology)

        # Start the hot-plug watcher after the first successful apply,
        # so it never fires before we have a baseline topology to diff.
        if self._sync_cfg.hotplug_watch and self._hotplug_thread is None:
            self._start_hotplug_watcher()

    def _evaluate_topology(self, sync) -> Tuple[int, bool, bool]:
        """Run the cheap LAN probes and return a topology signature.

        Returns ``(active_camera_ports, daq_sensor_on_lan, ptp_decision)``
        where ``ptp_decision`` is the resolved on/off value after the
        adaptive heuristic runs. Always reads ``self._user_ptp_enable``
        (the frozen user request), never ``sync.ptp_enable`` which may
        have been locally overridden by the apply step.

        The signature is what the hot-plug watcher diffs against. It
        intentionally collapses "why" (ports vs DAQ-E) so both triggers
        reach the same reconfigure path.
        """
        user_ptp = self._user_ptp_enable
        if sync.mode == "none" or len(self._cameras) < 2 \
                or sync.mode != "cable" or not user_ptp:
            # No PTP heuristic applies; topology is just "static".
            return (len(self._cameras), False,
                    bool(user_ptp and sync.mode != "none"))

        from lattice_cam.network import (
            count_active_camera_ports,
            detect_daq_sensors_on_lan,
        )
        active_ports = count_active_camera_ports()
        daq_present = detect_daq_sensors_on_lan()
        # Decision: keep PTP on if cameras span multiple ports OR a
        # DAQ-E is on the LAN. Otherwise disable — single-switch cable-
        # only setups trade 150 us of switch jitter for nothing.
        ptp_decision = active_ports > 1 or daq_present
        return (active_ports, daq_present, ptp_decision)

    def _apply_configuration(self, topology: Tuple[int, bool, bool]) -> None:
        """Blanket force-stop, rebuild groups, write trigger + PTP state."""
        # Blanket force-stop before any reconfiguration — clears stale
        # stream state left by a crashed or killed session
        for cam, serial in self._cameras:
            try:
                cam._device.stop_stream()
            except Exception:
                pass
            try:
                cam._device.nodemap.get_node("AcquisitionStop").execute()
            except Exception:
                pass
            cam._streaming = False

        sync = self._sync_cfg
        active_ports, daq_present, ptp_decision = topology

        if sync.mode == "none" or len(self._cameras) < 2:
            self._groups = [
                SyncGroup(self._cameras[0], self._cameras[1:], sync)
            ]
            if sync.mode != "none":
                self._groups[0].configure()
            self._synced = True
            self._last_topology = topology
            return

        # Log the adaptive-PTP reasoning alongside the decision. We read
        # ``self._user_ptp_enable`` (not sync.ptp_enable) so the log
        # stays accurate across re-evaluations.
        if sync.mode == "cable" and self._user_ptp_enable:
            if active_ports > 1:
                log.info(
                    "Cameras on %d separate physical ports — "
                    "enabling PTP for timestamp alignment",
                    active_ports,
                )
            elif daq_present:
                log.info(
                    "Single switch port but DAQ-E sensor detected on LAN — "
                    "keeping PTP enabled so sensor and camera timestamps "
                    "share the host's PTP domain",
                )
            else:
                log.info(
                    "Cameras share a single physical port and no DAQ sensors "
                    "on LAN — disabling PTP (M8 cable provides sync, "
                    "PTP through switch adds jitter)",
                )

        # Temporarily override sync.ptp_enable with the decision so
        # SyncGroup.configure() writes the right value to each camera.
        # Restore afterwards so re-evaluation still sees the user's
        # original request.
        original_ptp_enable = sync.ptp_enable
        sync.ptp_enable = ptp_decision
        try:
            # Build sync groups (fast path or cable probe)
            self._groups = self._build_groups()
            # Apply final trigger configuration on each group
            for group in self._groups:
                group.configure()
        finally:
            sync.ptp_enable = original_ptp_enable

        self._synced = True
        self._last_topology = topology
        log.info(
            "Sync configured: mode=%s, %d group(s), %d total cameras, "
            "ptp=%s", sync.mode, len(self._groups),
            sum(len(g.all_cameras) for g in self._groups),
            "on" if ptp_decision else "off",
        )

    # -- Hot-plug watcher ------------------------------------------------------

    def _start_hotplug_watcher(self) -> None:
        """Spawn the background thread that polls LAN topology."""
        self._hotplug_stop.clear()
        self._hotplug_thread = threading.Thread(
            target=self._hotplug_loop, daemon=True, name="lattice-hotplug",
        )
        self._hotplug_thread.start()
        log.debug("Hot-plug watcher started "
                   "(interval=%.1fs).", self._sync_cfg.hotplug_poll_interval_s)

    def _hotplug_loop(self) -> None:
        """Poll LAN topology; reconfigure only when the decision changes.

        Runs on a daemon thread so process exit isn't blocked. The
        watcher calls ``configure_sync()`` without ``force``, so if the
        topology signature matches the last applied one the call is a
        no-op — streams keep flowing. When the signature changes,
        ``configure_sync()`` logs a WARNING about the imminent stream
        pause before force-stopping / restarting.
        """
        interval = self._sync_cfg.hotplug_poll_interval_s
        while not self._hotplug_stop.wait(interval):
            try:
                topology = self._evaluate_topology(self._sync_cfg)
            except Exception as exc:
                log.debug("Hot-plug probe error (ignored): %s", exc)
                continue
            if topology == self._last_topology:
                continue
            # Decision changed — route through configure_sync so the
            # stream-pause warning + force-stop + rebuild logic runs
            # exactly once per change.
            try:
                self.configure_sync()
            except Exception as exc:
                log.warning(
                    "Hot-plug reconfigure failed: %s. Will retry on next "
                    "tick.", exc,
                )

    def _stop_hotplug_watcher(self) -> None:
        """Signal the watcher to exit; used by close()/__del__."""
        if self._hotplug_thread is None:
            return
        self._hotplug_stop.set()
        self._hotplug_thread.join(timeout=2)
        self._hotplug_thread = None

    def configure_bandwidth(self, total_bps=None, dedicated=False):
        """Split bandwidth across cameras.

        Parameters
        ----------
        total_bps : int, optional
            Total available bandwidth in bytes/sec.
            Default: 110,000,000 (110 MB/s practical 1 GbE).
        dedicated : bool
            If True, each camera has its own link — no splitting needed.
        """
        # DeviceLinkThroughputLimit is read-only on LATTICE camera when
        # DeviceLinkThroughputLimitMode is "Off" (the factory default),
        # which makes every direct value write fail with SaveC ERROR
        # -1001. Flipping the mode to "On" first unlocks the value
        # node. Without this the cameras keep emitting at the wire
        # ceiling, the array's simultaneous burst overwhelms the NIC,
        # and we get bands on every slave frame.
        for cam, _serial in self._cameras:
            try:
                mode_node = cam._device.nodemap.get_node(
                    "DeviceLinkThroughputLimitMode")
                if mode_node is not None and str(mode_node.value) != "On":
                    mode_node.value = "On"
            except Exception:
                pass  # Older firmware may not expose the mode node.

        if dedicated:
            for cam, serial in self._cameras:
                try:
                    node = cam._device.nodemap.get_node(
                        "DeviceLinkThroughputLimit")
                    node.value = node.max
                except Exception:
                    pass
            return

        total = total_bps or 110_000_000
        per_camera = int(total / self.count)
        for cam, serial in self._cameras:
            try:
                node = cam._device.nodemap.get_node(
                    "DeviceLinkThroughputLimit")
                val = min(per_camera, node.max)
                val = max(val, node.min)
                node.value = val
            except Exception:
                pass

    # -- Stream control -------------------------------------------------------

    def start(self):
        """Start streams on all cameras (via sync groups).

        Defensively stops stale acquisition before starting so that
        reconnection after a crash succeeds without a power cycle.
        """
        if self._streaming:
            return

        # Auto-configure bandwidth if not dedicated
        self.configure_bandwidth()

        if self._groups:
            for group in self._groups:
                group.start_streams()
        else:
            # Fallback: no groups configured, start directly
            for cam, serial in reversed(self._slaves):
                cam.start_stream()
            self._master[0].start_stream()

        self._streaming = True
        self._stats = SyncStats()

    def stop(self):
        """Stop streams on all cameras (best-effort).

        Continues stopping remaining cameras even if one fails, then
        issues a blanket AcquisitionStop as a last-resort cleanup.
        """
        if not self._streaming:
            return
        if self._groups:
            for group in self._groups:
                group.stop_streams()
        else:
            for cam, serial in self._cameras:
                try:
                    cam.stop_stream()
                except Exception as e:
                    log.debug("stop_stream %s: %s", serial, e)
            # Belt-and-suspenders
            for cam, serial in self._cameras:
                try:
                    cam._device.nodemap.get_node(
                        "AcquisitionStop").execute()
                except Exception:
                    pass
        self._streaming = False

    # -- Single-frame capture -------------------------------------------------

    def grab_sync(self, timeout=5000, processing_config=None):
        """Trigger and grab one synchronised frame from each camera.

        Parameters
        ----------
        timeout : int
            Buffer retrieval timeout in ms.
        processing_config : ProcessingConfig, optional
            From :func:`lattice_cam.processing.get_processing_config`.
            Controls CPU vs GPU demosaic.

        Returns
        -------
        tuple
            ``(trigger_timestamp_utc_iso, {serial: (frame_bgr, meta_dict)})``
            All frames from the same trigger event share one timestamp.
        """
        if not self._streaming:
            raise RuntimeError("Call start() before grab_sync()")

        results = {}
        trigger_ts = None
        for group in self._groups:
            group_ts, group_results = group.grab(
                timeout, processing_config=processing_config)
            if trigger_ts is None:
                trigger_ts = group_ts
            if self._sync_cfg.sync_verify and len(group_results) > 1:
                group.verify_sync(group_results)
            results.update(group_results)

        self._stats.frame_groups += 1
        return trigger_ts or datetime.now(timezone.utc).isoformat(), results

    def grab_sync_raw(self, timeout=5000):
        """Like ``grab_sync`` but returns raw Bayer arrays (no demosaic).

        Returns
        -------
        tuple
            ``(trigger_timestamp_utc_iso, {serial: (raw_frame, meta_dict)})``
        """
        if not self._streaming:
            raise RuntimeError("Call start() before grab_sync_raw()")

        results = {}
        trigger_ts = None
        for group in self._groups:
            group_ts, group_results = group.grab_raw(timeout)
            if trigger_ts is None:
                trigger_ts = group_ts
            results.update(group_results)

        self._stats.frame_groups += 1
        return trigger_ts or datetime.now(timezone.utc).isoformat(), results

    # -- Streaming capture ----------------------------------------------------

    def stream(self, fps=3.0, count=None, timeout=5000, prefetch=True,
               processing_config=None):
        """Generator that yields synchronised frame groups at a target FPS.

        When *prefetch* is True (default), a background thread triggers
        and grabs frame N+1 while the caller is processing frame N.
        This overlaps grab latency with disk I/O / processing, increasing
        effective throughput.

        Parameters
        ----------
        fps : float
            Target frames per second (default: 3.0).
        count : int, optional
            Number of frame groups to capture. None = infinite.
        timeout : int
            Per-frame grab timeout in milliseconds.
        prefetch : bool
            If True, grab next frame in background while caller
            processes the current one (default: True).
        processing_config : ProcessingConfig, optional
            Controls CPU vs GPU demosaic.

        Yields
        ------
        tuple
            ``(trigger_timestamp_utc_iso, {serial: (frame_bgr, meta_dict)})``
        """
        if not self._streaming:
            raise RuntimeError("Call start() before stream()")

        if not prefetch:
            yield from self._stream_sync(fps, count, timeout,
                                         processing_config)
            return

        # -- prefetch pipeline: producer thread -> queue -> consumer (caller)
        q = queue.Queue(maxsize=2)
        stop = threading.Event()
        interval = 1.0 / fps

        def _producer():
            t0 = time.perf_counter()
            n = 0
            while not stop.is_set() and (count is None or n < count):
                target = t0 + n * interval
                now = time.perf_counter()
                wait = target - now
                if wait > 0:
                    if stop.wait(wait):
                        break
                try:
                    result = self.grab_sync(
                        timeout=timeout,
                        processing_config=processing_config)
                    q.put(result, timeout=interval * 3)
                    n += 1
                except queue.Full:
                    self._stats.missed_frames += 1
                except Exception:
                    self._stats.missed_frames += 1
            q.put(None)  # sentinel

        t0 = time.perf_counter()
        producer = threading.Thread(target=_producer, daemon=True)
        producer.start()

        try:
            yielded = 0
            while count is None or yielded < count:
                item = q.get()
                if item is None:
                    break
                yield item
                yielded += 1
        finally:
            stop.set()
            producer.join(timeout=5)

        self._stats.elapsed = time.perf_counter() - t0

    def _stream_sync(self, fps, count, timeout, processing_config=None):
        """Synchronous (non-prefetch) stream generator."""
        interval = 1.0 / fps
        t0 = time.perf_counter()
        n = 0

        while count is None or n < count:
            target = t0 + n * interval
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)

            try:
                result = self.grab_sync(
                    timeout=timeout,
                    processing_config=processing_config)
                yield result
                n += 1
            except Exception:
                self._stats.missed_frames += 1

        self._stats.elapsed = time.perf_counter() - t0

    # -- Alignment-aware capture -----------------------------------------------

    def grab_aligned(self, profile, timeout=5000, use_gpu=None, crop=True,
                     vignette_maps=None):
        """Grab one synchronised frame group and apply alignment.

        Parameters
        ----------
        profile : AlignmentProfile
            Loaded alignment profile.
        timeout : int
            Per-camera grab timeout in ms.
        use_gpu : bool, optional
            Force GPU (True) or CPU (False). Default: auto-detect.
        crop : bool
            Crop to overlap region (default: True).
        vignette_maps : dict, optional
            ``{serial: vignette_inv_ndarray}`` for per-camera correction.

        Returns
        -------
        tuple
            ``(trigger_ts, {serial: aligned_frame})``
        """
        from .registration import (apply_alignment, gpu_apply_alignment,
                                   apply_vignette_corrections)

        trigger_ts, frames = self.grab_sync(timeout=timeout)
        if vignette_maps:
            frames = apply_vignette_corrections(frames, vignette_maps)
        if use_gpu is True or (use_gpu is None):
            return trigger_ts, gpu_apply_alignment(frames, profile, crop=crop)
        return trigger_ts, apply_alignment(frames, profile, crop=crop)

    def stream_aligned(self, profile, fps=3.0, count=None, timeout=5000,
                       use_gpu=None, crop=True, vignette_maps=None):
        """Generator yielding aligned frame groups at a target FPS.

        Parameters
        ----------
        profile : AlignmentProfile
            Loaded alignment profile.
        fps : float
            Target frames per second.
        count : int, optional
            Number of frame groups. None = infinite.
        timeout : int
            Per-camera grab timeout in ms.
        use_gpu : bool, optional
            Force GPU or CPU. Default: auto-detect.
        crop : bool
            Crop to overlap region.
        vignette_maps : dict, optional
            ``{serial: vignette_inv_ndarray}`` for per-camera correction.

        Yields
        ------
        tuple
            ``(trigger_ts, {serial: aligned_frame})``
        """
        from .registration import (apply_alignment, gpu_apply_alignment,
                                   apply_vignette_corrections)

        warp = gpu_apply_alignment if (use_gpu is True or use_gpu is None) \
            else apply_alignment

        for trigger_ts, group in self.stream(fps=fps, count=count,
                                             timeout=timeout):
            if vignette_maps:
                group = apply_vignette_corrections(group, vignette_maps)
            yield trigger_ts, warp(group, profile, crop=crop)

    def grab_multiband(self, profile, timeout=5000, use_gpu=None,
                       include=None, order=None, vignette_maps=None):
        """Grab, align, and extract multi-band stack in one call.

        Parameters
        ----------
        profile : AlignmentProfile
            Loaded alignment profile.
        timeout : int
            Per-camera grab timeout in ms.
        use_gpu : bool, optional
            Force GPU or CPU. Default: auto-detect.
        include : list of str, optional
            Band names to include.
        order : list of str, optional
            Output band order.
        vignette_maps : dict, optional
            ``{serial: vignette_inv_ndarray}`` for per-camera correction.

        Returns
        -------
        tuple
            ``(trigger_ts, bands, band_info)``
            bands: ndarray (N_bands, H, W), band_info: list of dict
        """
        from .registration import (extract_bands, _extract_metadata,
                                   apply_vignette_corrections)

        trigger_ts, frames = self.grab_sync(timeout=timeout)
        frame_metadata = _extract_metadata(frames, profile)

        if vignette_maps:
            frames = apply_vignette_corrections(frames, vignette_maps)

        from .registration import apply_alignment, gpu_apply_alignment
        if use_gpu is True or (use_gpu is None):
            aligned = gpu_apply_alignment(frames, profile, crop=True)
        else:
            aligned = apply_alignment(frames, profile, crop=True)

        bands, band_info = extract_bands(
            aligned, profile, include=include, order=order,
            frame_metadata=frame_metadata,
        )
        return trigger_ts, bands, band_info

    # -- Cleanup --------------------------------------------------------------

    def disconnect(self):
        """Stop streams and disconnect all cameras."""
        self._stop_hotplug_watcher()
        self.stop()
        for cam, serial in self._cameras:
            cam.disconnect()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.disconnect()

    # -- Async disk capture ---------------------------------------------------

    def stream_to_disk(self, fps=3.0, count=None, output_dir="output",
                       ext=".tiff", prefix="sync", queue_depth=16,
                       num_writers=2, jpeg_quality=95,
                       drop_policy="drop_newest", timeout=5000,
                       processing_config=None):
        """Start streaming to disk with async writes.

        Grab and write happen on separate threads so disk I/O never
        blocks the next trigger.

        Parameters
        ----------
        fps : float
            Target frames per second.
        count : int, optional
            Number of frame groups (None = infinite).
        output_dir : str
            Output directory.
        ext : str
            File extension (e.g. ".tiff", ".png", ".jpg").
        prefix : str
            Filename prefix.
        queue_depth : int
            Max buffered frame groups before backpressure kicks in.
        num_writers : int
            Writer thread count (default: 2).
        jpeg_quality : int
            JPEG quality (1-100).
        drop_policy : str
            ``"drop_newest"`` (default) or ``"block"``.
        timeout : int
            Per-frame grab timeout in ms.
        processing_config : ProcessingConfig, optional
            Controls CPU vs GPU demosaic.

        Returns
        -------
        MultiContinuousCapture
            Call ``.wait()`` to block until done, ``.stop()`` to abort.
        """
        cap = MultiContinuousCapture(
            self, output_dir=output_dir, ext=ext, prefix=prefix,
            jpeg_quality=jpeg_quality, queue_depth=queue_depth,
            num_writers=num_writers, drop_policy=drop_policy,
            processing_config=processing_config,
        )
        cap.start(fps=fps, count=count, timeout=timeout)
        return cap

    def __repr__(self):
        if self._groups:
            parts = []
            for g in self._groups:
                m = f"{g.master_serial}(master)"
                ss = ", ".join(f"{s}(slave)" for s in g.slave_serials)
                parts.append(f"[{m}, {ss}]" if ss else f"[{m}]")
            return f"CameraArray({', '.join(parts)})"
        role = lambda i: "master" if i == 0 else "slave"
        cams = ", ".join(
            f"{serial}({role(i)})"
            for i, (_, serial) in enumerate(self._cameras)
        )
        return f"CameraArray([{cams}])"


# ---------------------------------------------------------------------------
# MultiContinuousCapture — async grab + write pipeline
# ---------------------------------------------------------------------------

@dataclass
class MultiCaptureStats:
    """Statistics from a multi-camera continuous capture session."""
    frame_groups_grabbed: int = 0
    frame_groups_written: int = 0
    frame_groups_dropped: int = 0
    frames_written: int = 0
    elapsed: float = 0.0

    @property
    def fps(self):
        return self.frame_groups_written / self.elapsed if self.elapsed > 0 else 0.0


class MultiContinuousCapture:
    """Asynchronous multi-camera capture pipeline.

    Decouples grab from disk I/O using a write queue with configurable
    depth and backpressure policy.

    Usage — fully managed::

        array = CameraArray.discover(settings=settings)
        array.configure_sync()
        array.start()

        cap = array.stream_to_disk(fps=2.0, count=100, output_dir="run1")
        cap.wait()               # block until done
        stats = cap.stop()       # returns MultiCaptureStats
        array.disconnect()

    Usage — caller-fed (for live preview while writing)::

        cap = MultiContinuousCapture(array, output_dir="run1")
        cap.start_writers()
        for trigger_ts, group in array.stream(fps=2.0, count=100):
            cap.enqueue(trigger_ts, group)   # non-blocking
            display_preview(group)           # optional
        stats = cap.stop()
    """

    def __init__(self, array, output_dir="output", ext=".tiff",
                 prefix="sync", jpeg_quality=95, queue_depth=16,
                 num_writers=2, drop_policy="drop_newest",
                 processing_config=None):
        self._array = array
        self._output_dir = output_dir
        self._ext = ext
        self._prefix = prefix
        self._jpeg_quality = jpeg_quality
        self._num_writers = num_writers
        self._drop_policy = drop_policy
        self._processing_config = processing_config
        self._q = queue.Queue(maxsize=queue_depth)
        self._stats = MultiCaptureStats()
        self._stop_event = threading.Event()
        self._grab_thread = None
        self._writer_threads = []
        self._started = False
        # Monotonic filename sequence assigned at enqueue time. Writer
        # threads used to derive the filename index from the shared
        # ``frame_groups_written`` counter, which races when multiple
        # writers dequeue concurrently — two groups would land on the
        # same index while the next one got skipped. Using an atomic
        # counter at enqueue time keeps filenames dense, gap-free, and
        # in grab-order regardless of writer interleaving.
        # ``itertools.count().__next__`` is atomic under CPython's GIL.
        self._enqueue_seq = itertools.count()

    @property
    def stats(self):
        return self._stats

    @property
    def is_running(self):
        if not self._started:
            return False
        if self._stop_event.is_set():
            return False
        if self._grab_thread and not self._grab_thread.is_alive():
            return False
        return True

    # -- Full pipeline (grab + write) -----------------------------------------

    def start(self, fps=3.0, count=None, timeout=5000):
        """Start both grab and writer threads."""
        self._started = True
        self._t0 = time.perf_counter()
        self.start_writers()
        self._grab_thread = threading.Thread(
            target=self._grab_loop, args=(fps, count, timeout),
            daemon=True,
        )
        self._grab_thread.start()

    def _grab_loop(self, fps, count, timeout):
        interval = 1.0 / fps
        t0 = time.perf_counter()
        n = 0

        while not self._stop_event.is_set() and (count is None or n < count):
            target = t0 + n * interval
            now = time.perf_counter()
            wait = target - now
            if wait > 0:
                if self._stop_event.wait(wait):
                    break
            try:
                trigger_ts, group = self._array.grab_sync(
                    timeout=timeout,
                    processing_config=self._processing_config)
                self._stats.frame_groups_grabbed += 1
                self._enqueue_internal(trigger_ts, group)
                n += 1
            except Exception as e:
                log.debug("Grab loop error: %s", e)

        # Signal writers to drain and exit
        for _ in self._writer_threads:
            self._q.put(None)

    # -- Writer-only mode (caller feeds) --------------------------------------

    def start_writers(self):
        """Start only the writer threads (caller feeds via enqueue())."""
        import os
        os.makedirs(self._output_dir, exist_ok=True)
        for i in range(self._num_writers):
            t = threading.Thread(target=self._writer_loop, daemon=True)
            t.start()
            self._writer_threads.append(t)

    def enqueue(self, trigger_ts, group):
        """Enqueue a frame group for writing. Non-blocking.

        Parameters
        ----------
        trigger_ts : str
            ISO UTC timestamp from grab_sync().
        group : dict
            ``{serial: (frame_bgr, meta)}``
        """
        self._enqueue_internal(trigger_ts, group)

    def _enqueue_internal(self, trigger_ts, group):
        seq = next(self._enqueue_seq)
        try:
            self._q.put_nowait((seq, trigger_ts, group))
        except queue.Full:
            if self._drop_policy == "block":
                self._q.put((seq, trigger_ts, group))
            else:
                # drop_newest: discard this frame group. The seq is
                # burned — filenames will show a single-step gap at
                # the drop point, which is the honest signal to the
                # operator that a group was lost.
                self._stats.frame_groups_dropped += 1

    def _writer_loop(self):
        from lattice_cam.capture import save_frame

        while True:
            item = self._q.get()
            if item is None:
                break
            group_seq, trigger_ts, group = item
            for serial, (frame, meta) in sorted(group.items()):
                fid = meta.get("frame_id", 0)
                filename = (f"{self._prefix}_{group_seq:06d}"
                            f"_SN{serial}_{fid:06d}{self._ext}")
                filepath = f"{self._output_dir}/{filename}"
                try:
                    save_frame(frame, filepath,
                               jpeg_quality=self._jpeg_quality)
                    self._stats.frames_written += 1
                except Exception as e:
                    log.error("Write failed %s: %s", filepath, e)
            self._stats.frame_groups_written += 1

    # -- Control --------------------------------------------------------------

    def wait(self, timeout=None):
        """Block until the grab thread finishes (count reached or stopped)."""
        if self._grab_thread:
            self._grab_thread.join(timeout=timeout)

    def stop(self):
        """Stop all threads, drain the write queue, return stats."""
        self._stop_event.set()

        if self._grab_thread:
            self._grab_thread.join(timeout=10)

        # Signal writers to exit
        for _ in self._writer_threads:
            try:
                self._q.put_nowait(None)
            except queue.Full:
                pass

        for t in self._writer_threads:
            t.join(timeout=10)

        self._stats.elapsed = time.perf_counter() - getattr(
            self, '_t0', time.perf_counter())
        self._started = False
        return self._stats
