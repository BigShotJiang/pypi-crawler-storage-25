"""Sync configuration for LATTICE multi-camera arrays.

Mirrors the hub's SyncConfig / SyncGroupConfig / CameraArrayConfig
dataclasses so that project-level camera state can be persisted and
restored across sessions.
"""

import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SyncMode(str, Enum):
    """Synchronisation strategy for a multi-camera array."""
    CABLE = "cable"       # M8 GPIO trigger (ExposureActive on Line2)
    SOFTWARE = "software"  # Software trigger (TriggerSoftware command)
    NONE = "none"          # Free-run, no synchronisation


# ---------------------------------------------------------------------------
# Config dataclasses (serialisable to/from dict for project.json)
# ---------------------------------------------------------------------------

@dataclass
class SyncGroupConfig:
    """One sync group: one master + N slaves on a shared M8 cable chain."""
    master: str = ""
    slaves: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"master": self.master, "slaves": list(self.slaves)}

    @classmethod
    def from_dict(cls, d: dict) -> "SyncGroupConfig":
        return cls(
            master=d.get("master", ""),
            slaves=list(d.get("slaves", [])),
        )


@dataclass
class SyncConfig:
    """Full sync configuration for a camera array.

    Field names and defaults match the hub's config.py SyncConfig so the
    two codebases stay aligned.
    """
    mode: str = "cable"
    master_serial: str = "auto"
    groups: List[SyncGroupConfig] = field(default_factory=list)
    fast_path_enabled: bool = True
    # Slave's trigger input + master's trigger output are both on
    # Line 2 by default. Per the LATTICE 8-pin M8 GPIO
    # pinout (firmware 1.163.0.0 docs):
    #   pin 1 (red)    = VAUX power input
    #   pin 2 (brown)  = Line 2  — non-isolated bi-directional GPIO
    #   pin 3 (orange) = VDD power output (Line 4)
    #   pin 4 (purple) = Line 3  — non-isolated bi-directional GPIO
    #   pin 5 (black)  = camera GND
    #   pin 6 (blue)   = opto GND
    #   pin 7 (yellow) = Line 1  — opto-isolated OUTPUT
    #   pin 8 (green)  = Line 0  — opto-isolated INPUT
    # The standard MAPIR M8 cable is straight pin-2-to-pin-2 with
    # pin 5 GND, so the trigger wire physically lands on Line 2 on
    # BOTH master and slave. This is why earlier defaults (Line3 or
    # Line0) never produced a trigger arrival on the slave even
    # though the SDK accepted the writes — the master was emitting
    # on Line 3 (pin 4 purple) or Line 0 (pin 8 green), neither of
    # which is wired into the cable.
    trigger_source: str = "Line2"
    trigger_activation: str = "RisingEdge"
    trigger_delay_us: float = 0
    trigger_overlap: str = "PreviousFrame"
    # Master's GPIO output pin. Line 2 = pin 2 brown on TRI032S
    # (see trigger_source above). Both Line 2 and Line 3 are
    # non-isolated bi-directional, so either can be configured as
    # Output — but only Line 2 is on the trigger pin.
    exposure_output_line: str = "Line2"
    frame_timeout_ms: int = 5000
    sync_verify: bool = True
    max_timestamp_drift_us: int = 1000
    ptp_enable: bool = True
    ptp_domain: int = 0
    # Hot-plug watch: poll for LAN topology changes (new/disconnected
    # cameras, DAQ-E sensors coming online) and re-evaluate the adaptive
    # PTP decision. When the decision flips we reconfigure the array,
    # which force-stops + restarts any active streams — callers see a
    # 1-3 s frame gap. Set False for production pipelines where the
    # device set is known to be static and frame-gap-free streams matter
    # more than topology tracking.
    hotplug_watch: bool = True
    hotplug_poll_interval_s: float = 5.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["groups"] = [g.to_dict() for g in self.groups]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "SyncConfig":
        groups_raw = d.pop("groups", []) if isinstance(d, dict) else []
        groups = []
        for g in groups_raw:
            if isinstance(g, dict) and g.get("master"):
                groups.append(SyncGroupConfig.from_dict(g))
        cfg = cls(**{k: v for k, v in d.items()
                     if k in cls.__dataclass_fields__})
        cfg.groups = groups
        return cfg


# ---------------------------------------------------------------------------
# Per-camera saved state
# ---------------------------------------------------------------------------

@dataclass
class CameraState:
    """Persisted state for a single camera in the array."""
    serial: str = ""
    model: str = ""
    ip: str = ""
    mac: str = ""
    role: str = ""           # "master" or "slave"
    group: int = 0           # which SyncGroup index
    rig_camera_index: int = 0
    settings: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CameraState":
        return cls(**{k: v for k, v in d.items()
                      if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Top-level project camera array config
# ---------------------------------------------------------------------------

@dataclass
class CameraArrayConfig:
    """Everything about the camera array that gets persisted in project.json.

    Follows the scanmap pattern: serialisable to/from dict, stored under
    ``project.data['camera_array']``, loaded during ``load_files()`` and
    written during ``write()``.
    """
    cameras: Dict[str, CameraState] = field(default_factory=dict)
    sync: SyncConfig = field(default_factory=SyncConfig)
    groups: List[SyncGroupConfig] = field(default_factory=list)
    alignment_profile: str = ""
    last_connected: str = ""

    # --- serialisation ---------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "cameras": {s: c.to_dict() for s, c in self.cameras.items()},
            "sync": self.sync.to_dict(),
            "groups": [g.to_dict() for g in self.groups],
            "alignment_profile": self.alignment_profile,
            "last_connected": self.last_connected,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CameraArrayConfig":
        cameras = {}
        for serial, cam_d in d.get("cameras", {}).items():
            cameras[serial] = CameraState.from_dict(cam_d)

        sync_d = d.get("sync", {})
        sync = SyncConfig.from_dict(dict(sync_d)) if sync_d else SyncConfig()

        groups = []
        for g in d.get("groups", []):
            if isinstance(g, dict) and g.get("master"):
                groups.append(SyncGroupConfig.from_dict(g))

        return cls(
            cameras=cameras,
            sync=sync,
            groups=groups,
            alignment_profile=d.get("alignment_profile", ""),
            last_connected=d.get("last_connected", ""),
        )

    # --- convenience -----------------------------------------------------

    @property
    def serials(self) -> List[str]:
        return list(self.cameras.keys())

    @property
    def master_serials(self) -> List[str]:
        return [s for s, c in self.cameras.items() if c.role == "master"]

    def update_from_discovery(self, discovered: List[Dict[str, Any]]) -> dict:
        """Compare saved cameras to currently discovered cameras.

        Returns a change summary dict:
          {"added": [...], "removed": [...], "updated": [...], "unchanged": [...]}
        """
        discovered_by_serial = {d["serial"]: d for d in discovered}
        saved_serials = set(self.cameras.keys())
        found_serials = set(discovered_by_serial.keys())

        added = found_serials - saved_serials
        removed = saved_serials - found_serials
        still_present = saved_serials & found_serials

        updated = []
        unchanged = []
        for serial in still_present:
            disc = discovered_by_serial[serial]
            cam = self.cameras[serial]
            changed = False
            if disc.get("ip", "") != cam.ip:
                cam.ip = disc.get("ip", "")
                changed = True
            if disc.get("mac", "") != cam.mac:
                cam.mac = disc.get("mac", "")
                changed = True
            if disc.get("model", "") and disc["model"] != cam.model:
                cam.model = disc["model"]
                changed = True
            if changed:
                updated.append(serial)
            else:
                unchanged.append(serial)

        # Add newly discovered cameras
        for serial in added:
            disc = discovered_by_serial[serial]
            self.cameras[serial] = CameraState(
                serial=serial,
                model=disc.get("model", ""),
                ip=disc.get("ip", ""),
                mac=disc.get("mac", ""),
            )

        # Remove cameras no longer present
        for serial in removed:
            del self.cameras[serial]

        self.last_connected = datetime.now(timezone.utc).isoformat()

        changes = {
            "added": sorted(added),
            "removed": sorted(removed),
            "updated": sorted(updated),
            "unchanged": sorted(unchanged),
        }

        if added:
            log.info("New cameras: %s", ", ".join(sorted(added)))
        if removed:
            log.info("Removed cameras: %s", ", ".join(sorted(removed)))
        if updated:
            log.info("Updated cameras (IP/MAC/model): %s",
                     ", ".join(sorted(updated)))

        return changes

    def needs_reprobe(self, changes: dict) -> bool:
        """Return True if cable probing is required after a discovery change."""
        return bool(changes["added"] or changes["removed"])
