from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CameraSettings:
    # Resolution (IMX265 full frame)
    width: int = 2048
    height: int = 1536
    offset_x: int = 0
    offset_y: int = 0

    # Pixel format — BayerRG8 by default. With GammaEnable/LUTEnable/
    # ColorTransformationEnable all False (see below), the camera's 8-bit
    # path is a straight bit-shift from the sensor's native 12-bit (no
    # tone mapping, no LUT, no CCM). Halves bandwidth vs BayerRG12, which
    # lets more cameras share a 1 Gbps link at useful frame rates.
    pixel_format: str = "BayerRG8"       # BayerRG8, BayerRG10, BayerRG12, BayerRG16, Mono8, etc.

    # Exposure
    exposure_time: float = 10000.0       # microseconds
    exposure_auto: str = "Continuous"     # Off, Once, Continuous

    # Gain
    gain: float = 0.0                    # dB
    gain_auto: str = "Continuous"       # Off, Once, Continuous
    # Cap on auto-gain. None = release the camera's gain cap to its full
    # 48 dB range so AE can use whatever ISO it needs to hit
    # TargetBrightness when exposure has saturated. Set to a numeric dB
    # value to enforce a tighter cap (e.g. 0.0 for exposure-only AE in
    # radiometric capture, 24.0 for a noise-vs-headroom compromise).
    # Default is None — let AE drive: exposure varies first; gain
    # rises only when exposure can't compensate further. The user is
    # better placed than this default to decide the noise/dynamic-range
    # trade-off per scene.
    gain_auto_upper_limit_db: Optional[float] = None

    # Auto exposure/gain target (0-255, 8-bit scale)
    # When both exposure_auto and gain_auto are "Continuous", the camera
    # adjusts both to reach this target pixel brightness.
    target_brightness: int = 80  # 0-255; camera default is 128

    # AE damping — lower = faster response, higher = smoother. Range
    # ~0.4..100 on LATTICE camera. Camera default is ~90 (very smooth, slow).
    # 8.0 lands in the sweet spot for live preview: fast enough to react
    # to scene changes within a couple of frames at 30+ fps, slow enough
    # not to visibly pulse at high fps. User-adjustable via the AE
    # Smoothing slider in the settings modal.
    ae_damping: float = 8.0

    # AE exposure upper limit in microseconds (None = camera auto-manages).
    ae_upper_limit: Optional[float] = None

    # Auto exposure metering region (centre fraction of the current ROI).
    # 0.5 = centre 50% of the image; 1.0 = full ROI (no AOI).
    # Default to 1.0: multispectral capture wants the whole frame's mean
    # to land at TargetBrightness, not just the centre — otherwise the
    # periphery routinely sits hotter than the AE target and saturates,
    # while the live histogram (which shows the full image) doesn't
    # match what AE is actually targeting.
    ae_aoi_fraction: float = 1.0

    # White balance
    balance_white_auto: str = "Off"      # Off, Once, Continuous
    balance_ratio_red: float = 1.0
    balance_ratio_blue: float = 1.0

    # ISP processing — disable for scientific/multi-spectral imaging
    gamma: Optional[float] = 1.0         # 1.0 = linear (no gamma curve)
    gamma_enable: Optional[bool] = False # Disable gamma entirely (some cameras need this)
    lut_enable: Optional[bool] = False   # Disable look-up table
    ccm_enable: Optional[bool] = False   # Disable colour correction matrix

    # Acquisition
    acquisition_mode: str = "Continuous" # Continuous, SingleFrame, MultiFrame

    # Trigger — default On + Line 2. On the LATTICE
    # 8-pin M8 GPIO connector, pin 2 brown is Line 2 (non-isolated
    # bi-directional GPIO). The standard MAPIR cable is straight
    # pin-2-to-pin-2, so master output and slave input both land
    # on Line 2. Use Line 2 for both ends. Line 3 (pin 4 purple)
    # is also bi-directional but isn't on the trigger pin.
    trigger_mode: str = "On"             # On, Off
    trigger_source: str = "Line2"        # Software, Line0, Line2, Line3

    # Frame rate
    frame_rate_enable: bool = False      # Enable frame rate control
    frame_rate: float = 30.0             # Target FPS (only if enabled)

    # Stream buffer handling. Switched NewestOnly -> OldestFirst
    # to close a buffer-reuse race window in the Arena SDK pool.
    # In NewestOnly mode the SDK silently discards older buffers
    # when fresh GVSP packets arrive — fine when the consumer
    # always wants the latest frame, but the discard happens
    # asynchronously to consumer reads, and on this LATTICE camera firmware
    # we observed the SDK marking a buffer "complete" while a
    # handful of rows still carried bytes from a prior frame.
    # Symptom: SDK is_incomplete=False, missed_packets=0,
    # frame_id monotonic, all clean — yet visible magenta demosaic-
    # shift bands. OldestFirst delivers in arrival order without
    # the discard, eliminating the race. The cost is preview
    # latency creeping up if the host stalls — but with 24
    # buffers and a healthy fps cap that's not a real risk.
    buffer_handling_mode: str = "OldestFirst"  # NewestOnly, OldestFirst
    # 24 buffers at full-res BayerRG8 is ~75 MB pool memory per
    # camera, which is cheap. Larger pool gives the SDK enough
    # breathing room that even brief consumer stalls don't force
    # buffer reuse mid-fill.
    stream_num_buffers: int = 24

    # GigE Vision transport tuning
    device_link_throughput_limit: int = 125000000  # bytes/sec (125 MB/s for 1 Gbps)
    gev_packet_size: int = 9000                    # bytes; max target size when auto-probing
    gev_packet_size_auto: bool = True              # probe live: try target then fall back to 8228/4096/1500
    # Inter-packet delay in nanoseconds. 0 = fastest emission, but
    # also gives the host kernel zero breathing room between back-to-
    # back GVSP packets. On the I219 NIC under load, a tiny non-zero
    # delay (200 ns ≈ 1.5% of a single 1500-byte packet's wire time)
    # leaves measurable headroom for interrupt servicing without
    # meaningfully reducing throughput. The SDK delivers buffers
    # marked "complete" more reliably this way; without it the user
    # saw magenta bands that all six in-host defense layers passed
    # because the SDK was being told the buffer was clean when it
    # actually contained partially-overwritten rows.
    gev_packet_delay: int = 200


PRESETS = {
    "default": CameraSettings(),

    "high_speed": CameraSettings(
        pixel_format="BayerRG8",
        exposure_time=5000.0,
        exposure_auto="Off",
        gain=6.0,
        gain_auto="Off",
        frame_rate_enable=True,
        frame_rate=60.0,
        buffer_handling_mode="OldestFirst",
    ),

    "high_quality": CameraSettings(
        pixel_format="BayerRG12",
        exposure_time=20000.0,
        exposure_auto="Off",
        gain=0.0,
        gain_auto="Off",
        frame_rate_enable=False,
        buffer_handling_mode="OldestFirst",
    ),

    "triggered": CameraSettings(
        pixel_format="BayerRG12",
        exposure_time=15000.0,
        exposure_auto="Off",
        gain=0.0,
        gain_auto="Off",
        acquisition_mode="Continuous",
        trigger_mode="On",
        trigger_source="Line2",
        buffer_handling_mode="OldestFirst",
    ),
}
