"""System probe for optimal LATTICE camera hardware configuration.

Detects NICs, USB controllers, connected cameras, and their topology
to recommend the ideal hardware setup for maximum capture throughput.

Cross-platform: Windows (wmic/pnputil/netsh) and Linux (sysfs/ethtool).
"""

import platform
import re
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"

# IMX265 full-frame constants
FRAME_W, FRAME_H = 2048, 1536
SENSOR_MAX_FPS = 36.0  # IMX265 max at full resolution

# Bytes per pixel for each pixel format
_BPP = {
    "BayerRG8": 1, "Mono8": 1,
    "BayerRG10": 1.25, "BayerRG12": 1.5,
    "BayerRG16": 2, "Mono16": 2,
}

# USB bus bandwidth (MB/s usable after protocol overhead)
_USB_BW = {
    "USB 3.0": 400,    # 5 Gbps theoretical, ~400 MB/s usable
    "USB 3.1": 400,    # Gen 1 same as 3.0
    "USB 3.2": 900,    # Gen 2x2 = 20 Gbps, ~900 MB/s usable
    "USB 2.0": 35,     # 480 Mbps, ~35 MB/s usable
}


@dataclass
class NicProbeInfo:
    """Detected network interface."""
    name: str
    mac: str = ""
    ip: str = ""
    link_speed_mbps: int = 0
    mtu: int = 1500
    jumbo: bool = False
    connected: bool = False
    is_usb: bool = False
    usb_bus: str = ""  # e.g. "USB 3.0"
    driver: str = ""


@dataclass
class CameraProbeInfo:
    """Camera mapped to its NIC."""
    serial: str
    model: str = ""
    ip: str = ""
    nic_name: str = ""  # which NIC this camera is on


@dataclass
class ProbeResult:
    """Complete system probe result with recommendations."""
    nics: List[NicProbeInfo] = field(default_factory=list)
    cameras: List[CameraProbeInfo] = field(default_factory=list)
    cpu_cores: int = 0
    ram_gb: float = 0.0
    gpu_name: str = ""
    gpu_memory_gb: float = 0.0
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    topology: Dict[str, List[str]] = field(default_factory=dict)
    # Per-camera estimates with current setup
    current_fps_per_camera: float = 0.0
    ideal_fps_per_camera: float = 0.0
    pixel_format: str = "BayerRG12"

    def to_dict(self) -> dict:
        return {
            "nics": [
                {
                    "name": n.name, "mac": n.mac, "ip": n.ip,
                    "link_speed_mbps": n.link_speed_mbps, "mtu": n.mtu,
                    "jumbo": n.jumbo, "connected": n.connected,
                    "is_usb": n.is_usb, "usb_bus": n.usb_bus,
                    "driver": n.driver,
                }
                for n in self.nics
            ],
            "cameras": [
                {"serial": c.serial, "model": c.model, "ip": c.ip,
                 "nic_name": c.nic_name}
                for c in self.cameras
            ],
            "cpu_cores": self.cpu_cores,
            "ram_gb": round(self.ram_gb, 1),
            "gpu_name": self.gpu_name,
            "gpu_memory_gb": round(self.gpu_memory_gb, 1),
            "recommendations": self.recommendations,
            "warnings": self.warnings,
            "topology": self.topology,
            "current_fps_per_camera": round(self.current_fps_per_camera, 1),
            "ideal_fps_per_camera": round(self.ideal_fps_per_camera, 1),
            "pixel_format": self.pixel_format,
        }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def probe_system(pixel_format: str = "BayerRG12",
                 discover_cameras: bool = True) -> ProbeResult:
    """Run a full system probe and return recommendations.

    Parameters
    ----------
    pixel_format : str
        Pixel format to use for bandwidth calculations.
    discover_cameras : bool
        If True, discover cameras on the network (requires arena_api).

    Returns
    -------
    ProbeResult
        Complete probe with NICs, cameras, topology, and recommendations.
    """
    result = ProbeResult(pixel_format=pixel_format)

    # 1. Detect hardware
    _detect_cpu_ram(result)
    _detect_gpu(result)
    _detect_nics(result)

    # 2. Discover cameras and map to NICs
    if discover_cameras:
        _discover_and_map_cameras(result)

    # 3. Build topology map (NIC -> cameras)
    _build_topology(result)

    # 4. Calculate bandwidth and generate recommendations
    _analyze_and_recommend(result, pixel_format)

    return result


def format_probe_report(result: ProbeResult) -> str:
    """Format a ProbeResult as a human-readable report."""
    lines = []
    lines.append("=" * 60)
    lines.append("  LATTICE System Probe")
    lines.append("=" * 60)

    # Hardware
    lines.append("")
    lines.append(f"  CPU:  {result.cpu_cores} cores")
    lines.append(f"  RAM:  {result.ram_gb:.1f} GB")
    if result.gpu_name:
        lines.append(f"  GPU:  {result.gpu_name} ({result.gpu_memory_gb:.1f} GB)")
    else:
        lines.append("  GPU:  None detected")

    # NICs
    lines.append("")
    lines.append(f"  Network Interfaces ({len(result.nics)}):")
    for nic in result.nics:
        usb_tag = f" [{nic.usb_bus}]" if nic.is_usb else ""
        jumbo_tag = " jumbo" if nic.jumbo else ""
        link_str = f"{nic.link_speed_mbps} Mbps" if nic.link_speed_mbps else "unknown speed"
        state = "up" if nic.connected else "down"
        lines.append(f"    {nic.name}: {link_str}, MTU {nic.mtu}{jumbo_tag} ({state}){usb_tag}")

    # Cameras
    if result.cameras:
        lines.append("")
        lines.append(f"  Cameras ({len(result.cameras)}):")
        for cam in result.cameras:
            nic_tag = f" on {cam.nic_name}" if cam.nic_name else ""
            lines.append(f"    {cam.serial} ({cam.model}) @ {cam.ip}{nic_tag}")

    # Topology
    if result.topology:
        lines.append("")
        lines.append("  Topology:")
        for nic_name, serials in result.topology.items():
            lines.append(f"    {nic_name}: {', '.join(serials) if serials else '(no cameras)'}")

    # Performance
    if result.cameras:
        lines.append("")
        lines.append("  Performance Estimate:")
        lines.append(f"    Pixel format:  {result.pixel_format}")
        lines.append(f"    Current setup: {result.current_fps_per_camera:.1f} fps/camera")
        lines.append(f"    Ideal setup:   {result.ideal_fps_per_camera:.1f} fps/camera")
        if result.ideal_fps_per_camera > result.current_fps_per_camera + 1:
            improvement = result.ideal_fps_per_camera / max(result.current_fps_per_camera, 0.1)
            lines.append(f"    Potential:     {improvement:.1f}x improvement possible")

    # Warnings
    if result.warnings:
        lines.append("")
        lines.append("  Warnings:")
        for w in result.warnings:
            lines.append(f"    ! {w}")

    # Recommendations
    if result.recommendations:
        lines.append("")
        lines.append("  Recommendations:")
        for i, r in enumerate(result.recommendations, 1):
            lines.append(f"    {i}. {r}")
    else:
        lines.append("")
        lines.append("  System looks good for current camera count.")

    lines.append("")
    lines.append("=" * 60)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Detection helpers
# ---------------------------------------------------------------------------

def _detect_cpu_ram(result: ProbeResult):
    """Detect CPU core count and RAM."""
    import os
    result.cpu_cores = os.cpu_count() or 1
    try:
        import psutil
        result.ram_gb = psutil.virtual_memory().total / (1024 ** 3)
    except ImportError:
        # Fallback
        if IS_WINDOWS:
            try:
                out = subprocess.check_output(
                    ["wmic", "os", "get", "TotalVisibleMemorySize", "/value"],
                    text=True, timeout=5)
                m = re.search(r"TotalVisibleMemorySize=(\d+)", out)
                if m:
                    result.ram_gb = int(m.group(1)) / (1024 * 1024)
            except Exception:
                pass
        elif IS_LINUX:
            try:
                with open("/proc/meminfo") as f:
                    for line in f:
                        if line.startswith("MemTotal:"):
                            kb = int(line.split()[1])
                            result.ram_gb = kb / (1024 * 1024)
                            break
            except Exception:
                pass


def _detect_gpu(result: ProbeResult):
    """Detect GPU."""
    try:
        import torch
        if torch.cuda.is_available():
            result.gpu_name = torch.cuda.get_device_name(0)
            props = torch.cuda.get_device_properties(0)
            result.gpu_memory_gb = getattr(props, 'total_memory', 0) / (1024 ** 3)
            return
    except ImportError:
        pass

    # Fallback: try nvidia-smi
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total",
             "--format=csv,noheader,nounits"],
            text=True, timeout=5).strip()
        if out:
            parts = out.split(",")
            result.gpu_name = parts[0].strip()
            if len(parts) > 1:
                result.gpu_memory_gb = float(parts[1].strip()) / 1024
    except Exception:
        pass


def _detect_nics(result: ProbeResult):
    """Detect network interfaces."""
    if IS_WINDOWS:
        _detect_nics_windows(result)
    elif IS_LINUX:
        _detect_nics_linux(result)


def _detect_nics_windows(result: ProbeResult):
    """Detect NICs on Windows using netsh + wmic."""
    nics = []

    # Get interface info from netsh
    # Format: Idx  Met  MTU  State  Name
    try:
        out = subprocess.check_output(
            ["netsh", "interface", "ipv4", "show", "interfaces"],
            text=True, timeout=5)
        for line in out.splitlines():
            m = re.match(
                r'\s*(\d+)\s+\d+\s+(\d+)\s+(\w+)\s+(.+)', line)
            if not m:
                continue
            mtu = int(m.group(2))
            state = m.group(3).strip().lower()
            name = m.group(4).strip()
            # Skip loopback, VPN, virtual, wireless, bluetooth
            if any(x in name.lower() for x in
                   ["loopback", "vethernet", "wsl", "docker",
                    "bluetooth", "wi-fi", "wireless", "tailscale",
                    "local area connection*"]):
                continue
            # Keep Ethernet interfaces (named "Ethernet", "Ethernet 2", etc.)
            if "ethernet" not in name.lower():
                continue
            nic = NicProbeInfo(
                name=name,
                mtu=mtu,
                jumbo=mtu >= 9000,
                connected=state == "connected",
            )
            nics.append(nic)
    except Exception:
        pass

    # Preferred path: Get-NetAdapter (modern Windows, accurate on USB + built-in)
    # Returns LinkSpeed (raw bps) which maps cleanly to Mbps.
    try:
        ps_cmd = (
            "Get-NetAdapter -Physical | "
            "Select-Object Name,MacAddress,LinkSpeed,InterfaceDescription,Status | "
            "ConvertTo-Csv -NoTypeInformation"
        )
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            text=True, timeout=8, stderr=subprocess.DEVNULL)
        lines = [l for l in out.splitlines() if l.strip()]
        # Skip header row
        for line in lines[1:]:
            # Simple CSV: values are quoted with commas between
            parts = [p.strip().strip('"') for p in line.split('","')]
            if len(parts) < 5:
                continue
            parts[0] = parts[0].lstrip('"')
            parts[-1] = parts[-1].rstrip('"')
            name_w, mac, link_speed_str, iface_desc, status = parts[:5]

            # Parse LinkSpeed like "1 Gbps", "100 Mbps", "10 Gbps"
            ls_mbps = 0
            m = re.match(r'\s*([\d.]+)\s*(G|M|K)?bps',
                         link_speed_str, re.IGNORECASE)
            if m:
                val = float(m.group(1))
                unit = (m.group(2) or 'M').upper()
                if unit == 'G':
                    ls_mbps = int(val * 1000)
                elif unit == 'M':
                    ls_mbps = int(val)
                elif unit == 'K':
                    ls_mbps = int(val / 1000)

            for nic in nics:
                if (nic.name.lower() == name_w.lower() or
                        nic.name.lower() in iface_desc.lower() or
                        iface_desc.lower() in nic.name.lower()):
                    if mac and not nic.mac:
                        nic.mac = mac
                    if ls_mbps > 0 and nic.link_speed_mbps == 0:
                        nic.link_speed_mbps = ls_mbps
                    # USB-based adapter detection via description
                    if 'usb' in iface_desc.lower():
                        nic.is_usb = True
                        if '3.0' in iface_desc or '3.1' in iface_desc:
                            nic.usb_bus = 'USB 3.0'
                        else:
                            nic.usb_bus = 'USB 2.0'
                    break
    except Exception:
        pass

    # Fallback: wmic (legacy, works on older Windows installs without PS)
    try:
        out = subprocess.check_output(
            ["wmic", "nic", "where", "NetEnabled=true", "get",
             "Name,Speed,MACAddress,AdapterType", "/format:csv"],
            text=True, timeout=5, stderr=subprocess.DEVNULL)
        for line in out.splitlines():
            parts = line.strip().split(",")
            if len(parts) < 5:
                continue
            adapter_type = parts[1].strip()
            mac = parts[2].strip()
            name_w = parts[3].strip()
            speed = parts[4].strip()

            if "802.3" not in adapter_type and "Ethernet" not in adapter_type:
                continue

            # Match to our nics by name similarity
            for nic in nics:
                if nic.name.lower() in name_w.lower() or name_w.lower() in nic.name.lower():
                    if mac and not nic.mac:
                        nic.mac = mac
                    if speed and speed.isdigit() and nic.link_speed_mbps == 0:
                        nic.link_speed_mbps = int(speed) // 1_000_000
                    break
    except Exception:
        pass

    # Detect USB-based adapters
    try:
        out = subprocess.check_output(
            ["pnputil", "/enum-devices", "/class", "Net", "/connected"],
            capture_output=False, text=True, timeout=10)
        blocks = out.split("Instance ID:")
        for block in blocks:
            if "USB" in block.upper() and "Ethernet" in block:
                desc_m = re.search(r"Device Description:\s+(.+)", block)
                if desc_m:
                    desc = desc_m.group(1).strip()
                    for nic in nics:
                        if desc.lower() in nic.name.lower() or nic.name.lower() in desc.lower():
                            nic.is_usb = True
                            nic.usb_bus = "USB 3.0"  # default assumption
                            break
    except Exception:
        pass

    # Get IPs
    try:
        out = subprocess.check_output(
            ["netsh", "interface", "ipv4", "show", "addresses"],
            text=True, timeout=5)
        current_iface = ""
        for line in out.splitlines():
            iface_m = re.match(r'Configuration for interface "(.+)"', line)
            if iface_m:
                current_iface = iface_m.group(1)
            ip_m = re.search(r'IP Address:\s+([\d.]+)', line)
            if ip_m and current_iface:
                for nic in nics:
                    if nic.name == current_iface:
                        nic.ip = ip_m.group(1)
                        break
    except Exception:
        pass

    # Last-resort fallback: perfmon "Current Bandwidth" counter.
    # Works when WMI is broken (corrupt repository is common on older
    # Windows 10 installs). Instance names in perfmon strip special
    # chars — match on lowercase substring.
    try:
        ps_cmd = (
            "Get-Counter '\\Network Interface(*)\\Current Bandwidth' "
            "-ErrorAction SilentlyContinue | "
            "ForEach-Object { $_.CounterSamples } | "
            "Select-Object InstanceName,CookedValue | "
            "ConvertTo-Csv -NoTypeInformation"
        )
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            text=True, timeout=8, stderr=subprocess.DEVNULL)
        lines = [l for l in out.splitlines() if l.strip()]
        # Header first, then rows
        for line in lines[1:]:
            parts = [p.strip().strip('"') for p in line.split('","')]
            if len(parts) < 2:
                continue
            parts[0] = parts[0].lstrip('"')
            parts[-1] = parts[-1].rstrip('"')
            inst, val = parts[0], parts[1]
            try:
                bps = int(float(val))
            except ValueError:
                continue
            if bps <= 0:
                continue
            # Perfmon instance keys don't always match our netsh names
            # (which use Windows-assigned friendly names like "Ethernet 2").
            # Best-effort: take the inst as a vendor string and assign
            # to whichever NIC is currently 0-speed + connected.
            for nic in nics:
                if nic.link_speed_mbps > 0 or not nic.connected:
                    continue
                nic.link_speed_mbps = max(1, bps // 1_000_000)
                break
    except Exception:
        pass

    # A NIC that owns a valid IP is effectively "up" for our purposes,
    # even if netsh reports "disconnected" (common when the interface
    # only has a 169.254.x.x link-local address — typical LATTICE
    # deployments with no DHCP/gateway assign these).
    for nic in nics:
        if nic.ip and nic.ip != "0.0.0.0" and not nic.connected:
            nic.connected = True

    # NICs with no OS-reported speed get a 1 Gbps default when they look
    # usable (connected OR has an IP). Matches every LATTICE deployment
    # today and keeps the fps estimate meaningful when Windows refuses
    # to report the actual link speed (WMI broken / driver quirk).
    for nic in nics:
        if nic.link_speed_mbps == 0 and (nic.connected or nic.ip):
            nic.link_speed_mbps = 1000

    result.nics = nics


def _detect_nics_linux(result: ProbeResult):
    """Detect NICs on Linux using sysfs."""
    from pathlib import Path
    nics = []
    net_dir = Path("/sys/class/net")
    if not net_dir.exists():
        return

    for iface in sorted(net_dir.iterdir()):
        name = iface.name
        if name == "lo":
            continue
        if any(name.startswith(p) for p in
               ("wl", "ww", "docker", "br-", "veth", "virbr", "vnet")):
            continue
        if not (iface / "device").exists():
            continue

        nic = NicProbeInfo(name=name)

        # MTU
        try:
            nic.mtu = int((iface / "mtu").read_text().strip())
            nic.jumbo = nic.mtu >= 9000
        except Exception:
            pass

        # Link state
        try:
            nic.connected = (iface / "operstate").read_text().strip() == "up"
        except Exception:
            pass

        # Link speed
        try:
            speed = (iface / "speed").read_text().strip()
            if speed != "-1":
                nic.link_speed_mbps = int(speed)
        except Exception:
            pass

        # MAC
        try:
            nic.mac = (iface / "address").read_text().strip()
        except Exception:
            pass

        # IP
        try:
            out = subprocess.check_output(
                ["ip", "-4", "addr", "show", name],
                text=True, timeout=5)
            ip_m = re.search(r'inet ([\d.]+)', out)
            if ip_m:
                nic.ip = ip_m.group(1)
        except Exception:
            pass

        # Driver
        try:
            out = subprocess.check_output(
                ["ethtool", "-i", name], text=True, timeout=5)
            for line in out.splitlines():
                if line.startswith("driver:"):
                    nic.driver = line.split(":", 1)[1].strip()
                elif line.startswith("bus-info:"):
                    bus = line.split(":", 1)[1].strip()
                    if "usb" in bus.lower():
                        nic.is_usb = True
                        nic.usb_bus = "USB 3.0"
        except Exception:
            pass

        nics.append(nic)

    result.nics = nics


def _arp_camera_to_interface_ip_windows() -> Dict[str, str]:
    """Parse ``arp -a`` and return ``{camera_mac: nic_interface_ip}``.

    Windows ARP output is organised in blocks, one per interface, e.g.::

        Interface: 169.254.248.11 --- 0x41
          Internet Address      Physical Address      Type
          169.254.4.8           1c-0f-af-02-08-03     dynamic

    We walk the blocks, record the interface IP at each header, and
    attribute every subsequent entry's MAC to that interface. MACs are
    normalised to colon-lowercase form so they can be matched against
    Arena SDK's ``device_infos['mac']`` directly.

    Empty dict on failure; callers fall back to the IP-subnet heuristic.
    """
    try:
        out = subprocess.check_output(
            [r"C:\Windows\System32\arp.exe", "-a"],
            text=True, timeout=5,
        )
    except Exception:
        return {}

    mac_to_iface: Dict[str, str] = {}
    current_iface = ""
    for line in out.splitlines():
        iface_m = re.match(r"\s*Interface:\s+([\d.]+)\s+---", line)
        if iface_m:
            current_iface = iface_m.group(1)
            continue
        if not current_iface:
            continue
        # Entry: IP  MAC  Type ; MAC uses hyphens, we normalise to colons.
        row_m = re.match(
            r"\s*[\d.]+\s+([0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})\s+\w+",
            line,
        )
        if row_m:
            mac = row_m.group(1).replace("-", ":").lower()
            mac_to_iface[mac] = current_iface
    return mac_to_iface


def _discover_and_map_cameras(result: ProbeResult):
    """Discover cameras and map each to its physical NIC.

    On Windows the primary signal is the ARP table — it records which
    interface each camera's MAC was seen on, which is authoritative
    regardless of how Windows routes the link-local subnet. We fall
    back to an IP-subnet heuristic only when the ARP entry is missing
    (cold cache on a fresh boot before any traffic to the camera).

    The old heuristic matched any camera in 169.254/16 to the first
    NIC in 169.254/16, which collapsed multi-NIC LANs onto one port
    in the topology display even though PTP's ``count_active_camera_ports``
    correctly saw both NICs.
    """
    try:
        from lattice_sdk.discovery import discover_cameras
        discovered = discover_cameras()
    except Exception:
        return

    # Authoritative camera→NIC map (Windows only for now; Linux builds
    # the mapping from /proc/net/arp in a future revision).
    arp_map = _arp_camera_to_interface_ip_windows() if IS_WINDOWS else {}

    for cam_info in discovered:
        cam = CameraProbeInfo(
            serial=cam_info.serial,
            model=cam_info.model,
            ip=cam_info.ip,
        )

        # Primary: ARP table. Match camera MAC -> interface IP -> NIC name.
        cam_mac = (cam_info.mac or "").lower()
        iface_ip = arp_map.get(cam_mac, "")
        if iface_ip:
            for nic in result.nics:
                if nic.ip == iface_ip:
                    cam.nic_name = nic.name
                    break

        # Fallback: /24 subnet match (handles fresh-boot cold ARP cache).
        if not cam.nic_name:
            cam_octets = cam.ip.rsplit(".", 1)[0] if cam.ip else ""
            for nic in result.nics:
                nic_octets = nic.ip.rsplit(".", 1)[0] if nic.ip else ""
                if cam_octets and nic_octets and cam_octets == nic_octets:
                    cam.nic_name = nic.name
                    break

        # Last resort: first NIC in the 169.254/16 link-local range.
        # Only used when both ARP lookup AND /24 match failed — a rare
        # combo that should now be rare enough to accept the ambiguity.
        if not cam.nic_name and cam.ip.startswith("169.254."):
            for nic in result.nics:
                if nic.ip.startswith("169.254."):
                    cam.nic_name = nic.name
                    break

        result.cameras.append(cam)


def _build_topology(result: ProbeResult):
    """Build NIC -> [camera serials] mapping."""
    topo: Dict[str, List[str]] = {}
    for nic in result.nics:
        topo[nic.name] = []
    for cam in result.cameras:
        if cam.nic_name in topo:
            topo[cam.nic_name].append(cam.serial)
        elif cam.nic_name:
            topo[cam.nic_name] = [cam.serial]
    # Also include unmapped cameras
    unmapped = [c.serial for c in result.cameras if not c.nic_name]
    if unmapped:
        topo["(unknown)"] = unmapped
    result.topology = topo


def _analyze_and_recommend(result: ProbeResult, pixel_format: str):
    """Calculate bandwidth estimates and generate recommendations."""
    num_cameras = len(result.cameras)
    if num_cameras == 0:
        return

    bpp = _BPP.get(pixel_format, 1.5)
    frame_bytes = FRAME_W * FRAME_H * bpp
    frame_mb = frame_bytes / (1024 * 1024)

    # --- Current setup analysis ---
    # Find the most-loaded NIC (most cameras sharing one link)
    max_cams_per_nic = 0
    shared_nic_name = ""
    dedicated_count = 0
    usb_nic_count = 0
    usb_nic_cameras = 0

    for nic_name, serials in result.topology.items():
        if nic_name == "(unknown)":
            continue
        n = len(serials)
        if n > max_cams_per_nic:
            max_cams_per_nic = n
            shared_nic_name = nic_name
        if n == 1:
            dedicated_count += 1
        nic = next((x for x in result.nics if x.name == nic_name), None)
        if nic and nic.is_usb and n > 0:
            usb_nic_count += 1
            usb_nic_cameras += n

    # Current FPS estimate (bottleneck = most-loaded NIC)
    if max_cams_per_nic > 0:
        # Find the NIC's bandwidth
        bottleneck_nic = next(
            (n for n in result.nics if n.name == shared_nic_name), None)
        # Default to 1 Gbps when the OS refuses to report link speed
        # (common on some Windows driver stacks). This is the overwhelmingly
        # typical LATTICE deployment speed, so the estimate stays useful
        # instead of collapsing to zero.
        link_mbps = (bottleneck_nic.link_speed_mbps
                     if bottleneck_nic and bottleneck_nic.link_speed_mbps > 0
                     else 1000)
        jumbo = bottleneck_nic.jumbo if bottleneck_nic else False
        # Usable bandwidth: ~92% for jumbo, ~68% for standard
        usable_mb_s = link_mbps / 8 * (0.92 if jumbo else 0.68)
        total_fps = usable_mb_s / frame_mb
        result.current_fps_per_camera = min(
            total_fps / max_cams_per_nic, SENSOR_MAX_FPS)
    else:
        result.current_fps_per_camera = 0

    # Ideal FPS: each camera on its own 1 Gbps link with jumbo
    ideal_usable = 1000 / 8 * 0.92  # ~115 MB/s
    result.ideal_fps_per_camera = min(ideal_usable / frame_mb, SENSOR_MAX_FPS)

    # --- Warnings ---
    for nic in result.nics:
        if nic.connected and not nic.jumbo:
            result.warnings.append(
                f"{nic.name}: Jumbo frames disabled (MTU {nic.mtu}). "
                f"Enable for ~35% more throughput. Run 'lattice network --fix'."
            )
        if nic.is_usb and nic.connected:
            result.warnings.append(
                f"{nic.name}: USB Ethernet adapter detected. "
                f"Adds ~50-100us latency vs native PCIe NIC."
            )

    # --- Recommendations ---
    recs = result.recommendations

    # Case: all cameras on one NIC via switch
    if max_cams_per_nic >= 2:
        shared_bw = 1000  # 1 Gbps shared
        per_cam_mbps = shared_bw // max_cams_per_nic
        recs.append(
            f"{max_cams_per_nic} cameras share {shared_nic_name} "
            f"(~{per_cam_mbps} Mbps each). Adding USB-to-Ethernet adapters "
            f"would give each camera a dedicated 1 Gbps link."
        )

        # How many adapters needed?
        adapters_needed = max_cams_per_nic - 1  # keep one on existing NIC
        recs.append(
            f"Add {adapters_needed} USB 3.0 Gigabit Ethernet "
            f"adapter{'s' if adapters_needed > 1 else ''} for "
            f"{result.ideal_fps_per_camera:.0f} fps/camera "
            f"(currently {result.current_fps_per_camera:.0f} fps/camera)."
        )

        # USB bus check
        if adapters_needed >= 3:
            recs.append(
                "With 3+ USB adapters, verify they're on separate USB "
                "controllers. USB 3.0 shares 5 Gbps (~400 MB/s) per "
                "controller. Use 'lsusb -t' (Linux) or Device Manager "
                "(Windows) to check bus topology."
            )

    # Case: cameras already on separate NICs
    elif num_cameras > 1 and dedicated_count == num_cameras:
        recs.append(
            "Each camera has a dedicated NIC — optimal configuration."
        )

    # Jumbo frames
    non_jumbo = [n for n in result.nics if n.connected and not n.jumbo]
    if non_jumbo:
        names = ", ".join(n.name for n in non_jumbo)
        recs.append(
            f"Enable jumbo frames on: {names}. "
            f"Run 'lattice network --fix' as admin."
        )

    # GPU recommendation for multi-camera
    if num_cameras >= 2 and not result.gpu_name:
        recs.append(
            "No GPU detected. A CUDA GPU enables real-time GPU demosaic "
            "for multi-camera setups (2-4x faster than CPU)."
        )
