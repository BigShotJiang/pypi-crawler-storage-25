"""lattice_cam - Reusable wrapper for MAPIR LATTICE GigE Vision cameras."""

# Eagerly import lightweight, dependency-free modules.
from .settings import CameraSettings, PRESETS
from .processing import ProcessingTier, ProcessingConfig, get_processing_config

__all__ = [
    "LatticeCam",
    "CameraSettings",
    "PRESETS",
    "CaptureResult",
    "capture_single",
    "capture_burst",
    "ContinuousCapture",
    "ContinuousStats",
    "save_frame",
    "write_capture_exif",
    "discover_with_recovery",
    "ProcessingTier",
    "ProcessingConfig",
    "get_processing_config",
]

# Lazy-load camera/capture modules so arena_api is only imported when needed.
def __getattr__(name):
    if name in ("LatticeCam", "discover_with_recovery"):
        from .camera import LatticeCam, discover_with_recovery
        globals()["LatticeCam"] = LatticeCam
        globals()["discover_with_recovery"] = discover_with_recovery
        return globals()[name]
    if name in ("CaptureResult", "ContinuousCapture", "ContinuousStats",
                "capture_single", "capture_burst", "save_frame",
                "write_capture_exif"):
        from .capture import (
            CaptureResult, ContinuousCapture, ContinuousStats,
            capture_single, capture_burst, save_frame, write_capture_exif,
        )
        globals().update({
            "CaptureResult": CaptureResult,
            "ContinuousCapture": ContinuousCapture,
            "ContinuousStats": ContinuousStats,
            "capture_single": capture_single,
            "capture_burst": capture_burst,
            "save_frame": save_frame,
            "write_capture_exif": write_capture_exif,
        })
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
