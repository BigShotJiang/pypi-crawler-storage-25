"""GPU-accelerated image operations using PyTorch CUDA.

Provides GPU-accelerated versions of the heaviest viewer pipeline stages:

- **Demosaic** (``gpu_demosaic``, ``gpu_demosaic_batch``): Bilinear Bayer
  demosaic via normalised convolution on GPU.  Single-frame overhead is
  marginal vs OpenCV at 3 MP, but batching 2+ frames amortises PCIe
  transfer cost and frees CPU cores for grab / disk I/O.
- **Calibration** (``gpu_apply_calibration``): SR matrix correction +
  quadratic polynomial in one GPU pass.  ~8x faster than CPU numpy.
- **NDVI** (``gpu_compute_ndvi``): Normalized vegetation index on GPU.
- **Unmixing LUT** (``gpu_apply_unmixing_lut``): 3-D trilinear spectral
  correction via ``grid_sample``, replacing scipy ``map_coordinates``.
- **Bilateral filter** (``bilateral_filter``): Edge-preserving denoise.

All GPU functions fall back to CPU automatically if CUDA is unavailable.
"""

import numpy as np
import cv2

# ---------------------------------------------------------------------------
# GPU state
# ---------------------------------------------------------------------------
_gpu_available = False
_device = None
_initialized = False
_gpu_name = ""

# Bit depth per pixel format (shared with convert.py)
_FORMAT_BITS = {
    "Mono8": 8, "Mono10": 10, "Mono12": 12, "Mono16": 16,
    "BayerRG8": 8, "BayerBG8": 8, "BayerGR8": 8, "BayerGB8": 8,
    "BayerRG10": 10, "BayerBG10": 10, "BayerGR10": 10, "BayerGB10": 10,
    "BayerRG12": 12, "BayerBG12": 12, "BayerGR12": 12, "BayerGB12": 12,
    "BayerRG16": 16, "BayerBG16": 16, "BayerGR16": 16, "BayerGB16": 16,
}

# OpenCV CPU demosaic codes (GenICam ↔ OpenCV naming is swapped)
_CPU_DEMOSAIC = {
    "RG": cv2.COLOR_BayerBG2BGR,
    "BG": cv2.COLOR_BayerRG2BGR,
    "GR": cv2.COLOR_BayerGB2BGR,
    "GB": cv2.COLOR_BayerGR2BGR,
}


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

def initialize():
    """Detect GPU and initialize PyTorch CUDA."""
    global _gpu_available, _device, _initialized, _gpu_name
    if _initialized:
        return _gpu_available
    _initialized = True
    try:
        import torch
        if torch.cuda.is_available():
            _device = torch.device("cuda:0")
            _gpu_available = True
            props = torch.cuda.get_device_properties(0)
            _gpu_name = props.name
            mem_gb = props.total_memory / (1024 ** 3)
            print(f"GPU: {_gpu_name} ({mem_gb:.1f} GB VRAM)")
            # Pre-warm: run a tiny tensor op so the first real frame isn't slow
            torch.zeros(1, device=_device)
        else:
            print("GPU: CUDA not available, using CPU fallback")
    except ImportError:
        print("GPU: PyTorch not installed, using CPU fallback")
    return _gpu_available


def is_available():
    if not _initialized:
        initialize()
    return _gpu_available


def gpu_name():
    if not _initialized:
        initialize()
    return _gpu_name if _gpu_available else "CPU"


# ---------------------------------------------------------------------------
# Demosaic  (CPU fallback — OpenCV bilinear, used when GPU unavailable)
# ---------------------------------------------------------------------------

def demosaic(bayer, pixel_format):
    """Demosaic raw Bayer to BGR uint8 using OpenCV.

    Args:
        bayer: Raw Bayer array (H, W) uint8.
        pixel_format: GenICam pixel format string (e.g. "BayerRG8").

    Returns:
        BGR image (H, W, 3) uint8.
    """
    if pixel_format.startswith("Mono"):
        return cv2.cvtColor(bayer, cv2.COLOR_GRAY2BGR)

    pattern = pixel_format[5:7]  # "BayerRG8" → "RG"
    code = _CPU_DEMOSAIC.get(pattern)
    if code is not None:
        return cv2.cvtColor(bayer, code)
    return cv2.cvtColor(bayer, cv2.COLOR_GRAY2BGR)


# ---------------------------------------------------------------------------
# GPU Demosaic  (bilinear via normalised convolution — batch-amortised)
# ---------------------------------------------------------------------------

# Cached GPU tensors for demosaic (pattern → {masks, kernel})
_demosaic_cache = {}

# Bayer pattern → (R_row%2, R_col%2) offset for where the Red pixel lives
_BAYER_R_OFFSET = {
    "RG": (0, 0),  # R at (even, even)
    "GR": (0, 1),  # R at (even, odd)
    "GB": (1, 0),  # R at (odd, even)
    "BG": (1, 1),  # R at (odd, odd)
}


def _get_demosaic_tensors(pattern, H, W, device):
    """Build or retrieve cached Bayer channel masks and interpolation kernel.

    Returns ``(r_mask, g_mask, b_mask, kernel)`` as GPU float32 tensors.
    The masks are (1, 1, H, W) for broadcasting with batched conv2d.
    The kernel is the normalised-convolution bilinear interpolation
    kernel ``[[1,2,1],[2,4,2],[1,2,1]]`` shaped (1, 1, 3, 3).
    """
    key = (pattern, H, W)
    cached = _demosaic_cache.get(key)
    if cached is not None:
        return cached

    r_off = _BAYER_R_OFFSET[pattern]  # (row%2, col%2) of Red
    b_off = (1 - r_off[0], 1 - r_off[1])  # Blue is opposite corner

    r_mask = np.zeros((H, W), dtype=np.float32)
    g_mask = np.zeros((H, W), dtype=np.float32)
    b_mask = np.zeros((H, W), dtype=np.float32)

    r_mask[r_off[0]::2, r_off[1]::2] = 1.0
    b_mask[b_off[0]::2, b_off[1]::2] = 1.0
    g_mask[r_off[0]::2, 1 - r_off[1]::2] = 1.0   # Gr
    g_mask[1 - r_off[0]::2, r_off[1]::2] = 1.0    # Gb

    _ensure_torch()
    r_t = torch.from_numpy(r_mask).unsqueeze(0).unsqueeze(0).to(device)
    g_t = torch.from_numpy(g_mask).unsqueeze(0).unsqueeze(0).to(device)
    b_t = torch.from_numpy(b_mask).unsqueeze(0).unsqueeze(0).to(device)

    # Bilinear interpolation kernel for normalised convolution
    k = torch.tensor(
        [[1, 2, 1],
         [2, 4, 2],
         [1, 2, 1]], dtype=torch.float32, device=device
    ).unsqueeze(0).unsqueeze(0)

    result = (r_t, g_t, b_t, k)
    _demosaic_cache[key] = result
    return result


# Lazy import — set on first use inside GPU functions
torch = None


def _ensure_torch():
    global torch
    if torch is None:
        import torch as _torch
        torch = _torch


def gpu_demosaic(raw, pixel_format):
    """GPU bilinear Bayer demosaic for a single frame.

    Uses normalised convolution with a ``[[1,2,1],[2,4,2],[1,2,1]]``
    kernel that yields exact bilinear interpolation on the Bayer grid.
    Falls back to CPU OpenCV if CUDA is unavailable.

    Args:
        raw: Raw Bayer array (H, W), uint8 or uint16.
        pixel_format: GenICam pixel format string (e.g. "BayerRG8").

    Returns:
        BGR image (H, W, 3) uint8.
    """
    if pixel_format.startswith("Mono"):
        return cv2.cvtColor(raw.astype(np.uint8), cv2.COLOR_GRAY2BGR)

    if not is_available():
        return demosaic(raw, pixel_format)

    try:
        return _gpu_demosaic_impl([raw], [pixel_format])[0]
    except Exception:
        return demosaic(raw, pixel_format)


def gpu_demosaic_batch(frames, pixel_formats):
    """GPU bilinear Bayer demosaic for a batch of frames.

    Uploads all frames to GPU in one transfer, demosaics in parallel
    using batched ``conv2d``, then downloads all results.  Amortises
    PCIe overhead for batches >= 2 and frees CPU cores for grab/write.

    Falls back to per-frame CPU OpenCV if CUDA is unavailable.

    Args:
        frames: List of raw Bayer arrays (H, W), uint8 or uint16.
        pixel_formats: List of GenICam pixel format strings, one per frame.

    Returns:
        List of BGR images (H, W, 3) uint8.
    """
    if not frames:
        return []

    if not is_available():
        return [demosaic(f, pf) for f, pf in zip(frames, pixel_formats)]

    try:
        return _gpu_demosaic_impl(frames, pixel_formats)
    except Exception:
        return [demosaic(f, pf) for f, pf in zip(frames, pixel_formats)]


def _gpu_demosaic_impl(frames, pixel_formats):
    """Internal: batched GPU bilinear Bayer demosaic.

    All frames with the same (pattern, H, W) share cached masks and
    execute as a single batched conv2d.  Mixed resolutions or patterns
    are handled by grouping.
    """
    _ensure_torch()
    import torch.nn.functional as F

    # Group frames by (pattern, H, W) so each group can be batched
    groups = {}  # (pattern, H, W) → [(idx, raw_float)]
    for idx, (raw, pf) in enumerate(zip(frames, pixel_formats)):
        if pf.startswith("Mono"):
            continue
        pattern = pf[5:7]  # "BayerRG8" → "RG"
        H, W = raw.shape[:2]
        key = (pattern, H, W)
        if key not in groups:
            groups[key] = []
        groups[key].append((idx, raw))

    # Allocate results list
    results = [None] * len(frames)

    # Handle mono frames on CPU (trivial, not worth GPU)
    for idx, (raw, pf) in enumerate(zip(frames, pixel_formats)):
        if pf.startswith("Mono"):
            results[idx] = cv2.cvtColor(raw.astype(np.uint8), cv2.COLOR_GRAY2BGR)

    # Process each Bayer group as a GPU batch
    for (pattern, H, W), members in groups.items():
        r_mask, g_mask, b_mask, kernel = _get_demosaic_tensors(
            pattern, H, W, _device)

        # Determine bit depth — shift >8-bit data to 8-bit range
        sample_pf = pixel_formats[members[0][0]]
        bits = _FORMAT_BITS.get(sample_pf, 8)
        shift = bits - 8

        # Stack all frames into a batch tensor (N, 1, H, W)
        batch_np = np.stack(
            [m[1].astype(np.float32) for m in members], axis=0
        )  # (N, H, W)
        batch = torch.from_numpy(batch_np).unsqueeze(1).to(_device)  # (N,1,H,W)

        # Shift >8-bit data down to 8-bit range before demosaic
        if shift > 0:
            batch = batch / (1 << shift)

        # Isolate colour channels:  raw * mask → sparse channel planes
        R_plane = batch * r_mask    # (N, 1, H, W)
        G_plane = batch * g_mask
        B_plane = batch * b_mask

        # Normalised convolution: interp = conv(plane, k) / conv(mask, k)
        # Masks broadcast along the batch dim
        pad = 1  # 3x3 kernel → pad 1
        R_num = F.conv2d(F.pad(R_plane, [pad]*4, mode='reflect'), kernel)
        R_den = F.conv2d(F.pad(r_mask.expand(1, -1, -1, -1),
                                [pad]*4, mode='reflect'), kernel)
        G_num = F.conv2d(F.pad(G_plane, [pad]*4, mode='reflect'), kernel)
        G_den = F.conv2d(F.pad(g_mask.expand(1, -1, -1, -1),
                                [pad]*4, mode='reflect'), kernel)
        B_num = F.conv2d(F.pad(B_plane, [pad]*4, mode='reflect'), kernel)
        B_den = F.conv2d(F.pad(b_mask.expand(1, -1, -1, -1),
                                [pad]*4, mode='reflect'), kernel)

        # Avoid division by zero (shouldn't happen with reflect padding)
        eps = 1e-6
        R_ch = R_num / (R_den + eps)  # (N, 1, H, W)
        G_ch = G_num / (G_den + eps)
        B_ch = B_num / (B_den + eps)

        # Override Green at known positions — normalised conv blurs the
        # quincunx G grid because diagonal G neighbours fall within the
        # 3x3 window.  R and B are unaffected (no same-channel neighbours
        # within 3x3 of their regular grids).
        G_ch = G_ch * (1.0 - g_mask) + batch * g_mask

        del R_plane, G_plane, B_plane, R_num, R_den, G_num, G_den, B_num, B_den

        # Clamp to 8-bit and stack BGR
        bgr = torch.cat([B_ch, G_ch, R_ch], dim=1)  # (N, 3, H, W)
        bgr = bgr.clamp(0, 255).to(torch.uint8)

        # Download to CPU
        bgr_np = bgr.permute(0, 2, 3, 1).cpu().numpy()  # (N, H, W, 3)
        del bgr, R_ch, G_ch, B_ch, batch

        # Scatter results back to the output list
        for i, (idx, _raw) in enumerate(members):
            results[idx] = np.ascontiguousarray(bgr_np[i])

    return results


# ---------------------------------------------------------------------------
# Resize  (CPU — trivial at display resolution, transfer overhead not worth it)
# ---------------------------------------------------------------------------

def resize(bgr, target_height):
    """Resize image maintaining aspect ratio.

    Args:
        bgr: BGR image (H, W, 3) uint8.
        target_height: Desired output height in pixels.

    Returns:
        Resized BGR image uint8.
    """
    h, w = bgr.shape[:2]
    if h <= target_height:
        return bgr
    scale = target_height / h
    target_width = int(w * scale)
    return cv2.resize(bgr, (target_width, target_height))


# ---------------------------------------------------------------------------
# Bilateral filter  (GPU — compute-heavy, real speedup over CPU)
# ---------------------------------------------------------------------------

def bilateral_filter(bgr, d=5, sigma_color=50.0, sigma_space=50.0):
    """Edge-preserving bilateral filter.

    Uses GPU when available (faster than CPU for this compute-heavy op),
    falls back to cv2.bilateralFilter.

    Args:
        bgr: BGR image (H, W, 3) uint8.
        d: Kernel diameter (odd, e.g. 5 or 7).
        sigma_color: Filter sigma in the color space.
        sigma_space: Filter sigma in the coordinate space.

    Returns:
        Filtered BGR image (H, W, 3) uint8.
    """
    if not is_available():
        return cv2.bilateralFilter(bgr, d, sigma_color, sigma_space)

    try:
        return _gpu_bilateral(bgr, d, sigma_color, sigma_space)
    except Exception:
        return cv2.bilateralFilter(bgr, d, sigma_color, sigma_space)


# ---------------------------------------------------------------------------
# GPU-accelerated calibration pipeline
#
# These are drop-in replacements for the corresponding functions in
# calibration.py.  Each uploads the frame to GPU, performs all
# computation there, and downloads the result.  With automatic CPU
# fallback if GPU is unavailable or any error occurs.
# ---------------------------------------------------------------------------


_cached_exp_lut_gpu = {}  # cached exposure LUTs on GPU


def gpu_apply_calibration(frame, coeffs, filter_type, bit_depth=8,
                          dls_scale=None, exp_scale=1.0,
                          exposure_model=None, cur_exp=None, cur_gain=None,
                          calib_exp=None, calib_gain=None):
    """GPU SR correction + polynomial calibration.

    Drop-in replacement for ``calibration.apply_calibration()``.
    Performs sensor response matrix inversion, exposure/DLS scaling,
    and quadratic polynomial evaluation entirely on GPU.

    When *exposure_model* is provided along with exposure/gain metadata,
    uses LUT-based linearisation correction instead of scalar *exp_scale*.

    Falls back to CPU ``calibration.apply_calibration()`` if GPU is
    unavailable or any error occurs.
    """
    if not is_available():
        from lattice_cam import calibration as _cal
        if exposure_model is not None and cur_exp and calib_exp:
            frame = _cal.apply_exposure_model_correction(
                frame, exposure_model, cur_exp, cur_gain or 0.0,
                calib_exp, calib_gain or 0.0, bit_depth)
            exp_scale = 1.0
        return _cal.apply_calibration(frame, coeffs, filter_type,
                                      bit_depth, dls_scale, exp_scale)
    try:
        return _gpu_calibrate_impl(frame, coeffs, filter_type, bit_depth,
                                   dls_scale, exp_scale,
                                   exposure_model, cur_exp, cur_gain,
                                   calib_exp, calib_gain)
    except Exception:
        from lattice_cam import calibration as _cal
        if exposure_model is not None and cur_exp and calib_exp:
            frame = _cal.apply_exposure_model_correction(
                frame, exposure_model, cur_exp, cur_gain or 0.0,
                calib_exp, calib_gain or 0.0, bit_depth)
            exp_scale = 1.0
        return _cal.apply_calibration(frame, coeffs, filter_type,
                                      bit_depth, dls_scale, exp_scale)


def _gpu_calibrate_impl(frame, coeffs, filter_type, bit_depth,
                         dls_scale, exp_scale,
                         exposure_model=None, cur_exp=None, cur_gain=None,
                         calib_exp=None, calib_gain=None):
    """Internal GPU calibration — SR + poly in a single GPU pass."""
    import torch
    from lattice_cam.calibration import SENSOR_RESP_INV

    inv = coeffs.get('inv_eff', SENSOR_RESP_INV[filter_type])
    bmax = float((1 << bit_depth) - 1)
    H, W = frame.shape[:2]

    # Upload to GPU as float32 (H, W, 3)
    t = torch.from_numpy(frame.astype(np.float32)).to(_device)

    # Exposure model LUT correction (before SR, on raw DNs)
    if (exposure_model is not None and cur_exp is not None
            and calib_exp is not None):
        t = _gpu_exp_model_correct(t, exposure_model, bit_depth,
                                    cur_exp, cur_gain or 0.0,
                                    calib_exp, calib_gain or 0.0)
        exp_scale = 1.0  # correction already applied

    # SR matrix correction: BGR → per-channel corrected DNs
    b, g, r = t[:, :, 0], t[:, :, 1], t[:, :, 2]
    del t

    r_c = (float(inv[0, 0]) * r + float(inv[0, 1]) * g
           + float(inv[0, 2]) * b).clamp_(0, bmax)
    g_c = (float(inv[1, 0]) * r + float(inv[1, 1]) * g
           + float(inv[1, 2]) * b).clamp_(0, bmax)
    b_c = (float(inv[2, 0]) * r + float(inv[2, 1]) * g
           + float(inv[2, 2]) * b).clamp_(0, bmax)
    del r, g, b

    # Exposure compensation (in-place for speed) — scalar fallback
    if abs(exp_scale - 1.0) > 0.001:
        es = float(exp_scale)
        r_c.mul_(es).clamp_(0, bmax)
        g_c.mul_(es).clamp_(0, bmax)
        b_c.mul_(es).clamp_(0, bmax)

    # DLS pre-polynomial illumination correction
    if dls_scale is not None:
        r_c.mul_(float(dls_scale[0])).clamp_(0, bmax)
        g_c.mul_(float(dls_scale[1])).clamp_(0, bmax)
        b_c.mul_(float(dls_scale[2])).clamp_(0, bmax)

    # Polynomial: reflectance = c2*x² + c1*x + c0, clipped to [0, 1]
    pr, pg, pb = coeffs['red'], coeffs['green'], coeffs['blue']

    out = torch.empty(H, W, 3, dtype=torch.float32, device=_device)
    out[:, :, 2] = (float(pr[0]) * r_c * r_c
                    + float(pr[1]) * r_c + float(pr[2])).clamp_(0, 1)
    out[:, :, 1] = (float(pg[0]) * g_c * g_c
                    + float(pg[1]) * g_c + float(pg[2])).clamp_(0, 1)
    out[:, :, 0] = (float(pb[0]) * b_c * b_c
                    + float(pb[1]) * b_c + float(pb[2])).clamp_(0, 1)
    del r_c, g_c, b_c

    result = out.cpu().numpy()
    del out
    return result


def gpu_compute_ndvi(refl_frame):
    """GPU NDVI computation.

    Drop-in replacement for ``calibration.compute_ndvi()``.
    Falls back to CPU if GPU unavailable.
    """
    if not is_available():
        from lattice_cam import calibration as _cal
        return _cal.compute_ndvi(refl_frame)
    try:
        return _gpu_ndvi_impl(refl_frame)
    except Exception:
        from lattice_cam import calibration as _cal
        return _cal.compute_ndvi(refl_frame)


def _gpu_ndvi_impl(refl_frame):
    """Internal GPU NDVI: (NIR - Red) / (NIR + Red)."""
    import torch

    t = torch.from_numpy(refl_frame).to(_device)
    nir = t[:, :, 0]   # BGR[0] = NIR
    red = t[:, :, 2]   # BGR[2] = Red

    denom = nir + red
    ndvi = torch.where(denom > 1e-6, (nir - red) / denom,
                       torch.zeros_like(nir))

    result = ndvi.cpu().numpy()
    del t, nir, red, denom, ndvi
    return result


def _gpu_exp_model_correct(t, model, bit_depth, cur_exp, cur_gain,
                            calib_exp, calib_gain):
    """Apply exposure model LUT correction on GPU (in-place on tensor *t*).

    Operates on raw DNs BEFORE SR correction.  Converts DNs from current
    exposure/gain to what they would be at calibration exposure/gain using
    dark subtraction + inverse LUT + scale + forward LUT + dark add-back.

    Parameters
    ----------
    t : torch.Tensor (H, W, 3)
        Float32 BGR frame on GPU.
    model : dict
        Loaded .npz exposure model.
    bit_depth : int
    cur_exp, cur_gain, calib_exp, calib_gain : float
        Current and calibration exposure (us) / gain (dB).

    Returns
    -------
    torch.Tensor (H, W, 3)
        Corrected frame on GPU.
    """
    import torch
    from lattice_cam.calibration import compute_dark, compute_gain_correction

    bmax = float((1 << bit_depth) - 1)
    bmax_int = (1 << bit_depth) - 1

    # Cache LUTs on GPU (only re-upload when model object changes)
    model_id = id(model['inverse_lut'])
    if _cached_exp_lut_gpu.get('id') != model_id:
        inv_np = model['inverse_lut']   # (3, 4096) float32
        fwd_np = model['forward_lut']   # (3, 4096) float32
        _cached_exp_lut_gpu['inv'] = torch.from_numpy(
            inv_np.astype(np.float32)).to(_device)
        _cached_exp_lut_gpu['fwd'] = torch.from_numpy(
            fwd_np.astype(np.float32)).to(_device)
        _cached_exp_lut_gpu['id'] = model_id
    inv_lut = _cached_exp_lut_gpu['inv']  # (3, 4096)
    fwd_lut = _cached_exp_lut_gpu['fwd']  # (3, 4096)

    # Dark current at current and calibration settings (CPU, scalar)
    dark_cur = compute_dark(model, cur_exp, cur_gain)
    dark_cal = compute_dark(model, calib_exp, calib_gain)

    # Gain correction factors
    gc_cur = compute_gain_correction(model, cur_gain)
    gc_cal = compute_gain_correction(model, calib_gain)

    # BGR→model channel mapping: BGR[0]=blue(model 2), BGR[1]=green(1), BGR[2]=red(0)
    bgr_to_model = [2, 1, 0]

    out = torch.empty_like(t)
    for bgr_ch in range(3):
        m_ch = bgr_to_model[bgr_ch]
        ch = t[:, :, bgr_ch]

        # 1. Subtract dark
        signal = (ch - float(dark_cur[m_ch])).clamp_(0, bmax)

        # 2. Inverse LUT: observed → linearised (integer-indexed gather)
        idx = signal.clamp(0, bmax).to(torch.int64)
        linearised = inv_lut[m_ch][idx.reshape(-1)].reshape(idx.shape)

        # 3. Scale by exposure×gain ratio
        gain_lin_cur = 10.0 ** (cur_gain / 20.0) * gc_cur[m_ch]
        gain_lin_cal = 10.0 ** (calib_gain / 20.0) * gc_cal[m_ch]
        scale = (calib_exp * gain_lin_cal) / max(cur_exp * gain_lin_cur, 1e-6)
        scaled = linearised * float(scale)

        # 4. Forward LUT: linearised → observed
        idx2 = scaled.clamp(0, bmax).to(torch.int64)
        delinearised = fwd_lut[m_ch][idx2.reshape(-1)].reshape(idx2.shape)

        # 5. Add dark at calibration settings
        out[:, :, bgr_ch] = (delinearised + float(dark_cal[m_ch])).clamp_(0, bmax)

    return out


def gpu_apply_unmixing_lut(reflectance, lut):
    """GPU 3-D spectral correction LUT via trilinear interpolation.

    Drop-in replacement for ``calibration.apply_unmixing_lut()``.
    Uses PyTorch ``grid_sample`` for GPU-accelerated trilinear lookup
    at 4x downscaled resolution, then upsamples and subtracts.

    Falls back to CPU (scipy) if GPU unavailable.
    """
    if lut is None:
        return reflectance
    if not is_available():
        from lattice_cam import calibration as _cal
        return _cal.apply_unmixing_lut(reflectance, lut)
    try:
        return _gpu_unmixing_impl(reflectance, lut)
    except Exception:
        from lattice_cam import calibration as _cal
        return _cal.apply_unmixing_lut(reflectance, lut)


_cached_lut_gpu = {}  # cached LUT tensor on GPU (keyed by id(lut))


def gpu_full_pipeline(frame, coeffs, filter_type, bit_depth=8,
                      dls_scale=None, exp_scale=1.0, unmixing_lut=None,
                      exposure_model=None, cur_exp=None, cur_gain=None,
                      calib_exp=None, calib_gain=None):
    """Combined GPU calibration + unmixing + NDVI in a single pass.

    Performs all heavy computation on GPU with one upload and one download,
    avoiding intermediate CPU round-trips.  Returns ``(refl_frame, ndvi_map)``.

    Falls back to separate CPU functions if GPU unavailable.
    """
    if not is_available():
        from lattice_cam import calibration as _cal
        if exposure_model is not None and cur_exp and calib_exp:
            frame = _cal.apply_exposure_model_correction(
                frame, exposure_model, cur_exp, cur_gain or 0.0,
                calib_exp, calib_gain or 0.0, bit_depth)
            exp_scale = 1.0
        refl = _cal.apply_calibration(frame, coeffs, filter_type,
                                      bit_depth, dls_scale, exp_scale)
        if unmixing_lut is not None:
            refl = _cal.apply_unmixing_lut(refl, unmixing_lut)
        ndvi = _cal.compute_ndvi(refl)
        return refl, ndvi
    try:
        return _gpu_full_pipeline_impl(frame, coeffs, filter_type, bit_depth,
                                       dls_scale, exp_scale, unmixing_lut,
                                       exposure_model, cur_exp, cur_gain,
                                       calib_exp, calib_gain)
    except Exception:
        from lattice_cam import calibration as _cal
        if exposure_model is not None and cur_exp and calib_exp:
            frame = _cal.apply_exposure_model_correction(
                frame, exposure_model, cur_exp, cur_gain or 0.0,
                calib_exp, calib_gain or 0.0, bit_depth)
            exp_scale = 1.0
        refl = _cal.apply_calibration(frame, coeffs, filter_type,
                                      bit_depth, dls_scale, exp_scale)
        if unmixing_lut is not None:
            refl = _cal.apply_unmixing_lut(refl, unmixing_lut)
        ndvi = _cal.compute_ndvi(refl)
        return refl, ndvi


def _gpu_full_pipeline_impl(frame, coeffs, filter_type, bit_depth,
                             dls_scale, exp_scale, unmixing_lut,
                             exposure_model=None, cur_exp=None, cur_gain=None,
                             calib_exp=None, calib_gain=None):
    """Internal: combined calib → unmixing → NDVI on GPU."""
    import torch
    import torch.nn.functional as F
    from lattice_cam.calibration import SENSOR_RESP_INV

    inv = coeffs.get('inv_eff', SENSOR_RESP_INV[filter_type])
    bmax = float((1 << bit_depth) - 1)
    H, W = frame.shape[:2]

    # --- Upload + Calibration ---
    t = torch.from_numpy(frame.astype(np.float32)).to(_device)

    # Exposure model LUT correction (before SR, on raw DNs)
    if (exposure_model is not None and cur_exp is not None
            and calib_exp is not None):
        t = _gpu_exp_model_correct(t, exposure_model, bit_depth,
                                    cur_exp, cur_gain or 0.0,
                                    calib_exp, calib_gain or 0.0)
        exp_scale = 1.0

    b, g, r = t[:, :, 0], t[:, :, 1], t[:, :, 2]
    del t

    r_c = (float(inv[0, 0]) * r + float(inv[0, 1]) * g
           + float(inv[0, 2]) * b).clamp_(0, bmax)
    g_c = (float(inv[1, 0]) * r + float(inv[1, 1]) * g
           + float(inv[1, 2]) * b).clamp_(0, bmax)
    b_c = (float(inv[2, 0]) * r + float(inv[2, 1]) * g
           + float(inv[2, 2]) * b).clamp_(0, bmax)
    del r, g, b

    if abs(exp_scale - 1.0) > 0.001:
        es = float(exp_scale)
        r_c.mul_(es).clamp_(0, bmax)
        g_c.mul_(es).clamp_(0, bmax)
        b_c.mul_(es).clamp_(0, bmax)

    if dls_scale is not None:
        r_c.mul_(float(dls_scale[0])).clamp_(0, bmax)
        g_c.mul_(float(dls_scale[1])).clamp_(0, bmax)
        b_c.mul_(float(dls_scale[2])).clamp_(0, bmax)

    pr, pg, pb = coeffs['red'], coeffs['green'], coeffs['blue']
    refl = torch.empty(H, W, 3, dtype=torch.float32, device=_device)
    refl[:, :, 2] = (float(pr[0]) * r_c * r_c
                     + float(pr[1]) * r_c + float(pr[2])).clamp_(0, 1)
    refl[:, :, 1] = (float(pg[0]) * g_c * g_c
                     + float(pg[1]) * g_c + float(pg[2])).clamp_(0, 1)
    refl[:, :, 0] = (float(pb[0]) * b_c * b_c
                     + float(pb[1]) * b_c + float(pb[2])).clamp_(0, 1)
    del r_c, g_c, b_c

    # --- Unmixing LUT (on GPU, skip intermediate download) ---
    if unmixing_lut is not None:
        lut_data = unmixing_lut['lut']
        S = unmixing_lut['grid_size']

        # Cache LUT tensor
        lut_id = id(lut_data)
        if _cached_lut_gpu.get('id') != lut_id:
            lt = torch.from_numpy(lut_data.astype(np.float32)).to(_device)
            _cached_lut_gpu['tensor'] = lt.permute(3, 0, 1, 2).unsqueeze(0)
            _cached_lut_gpu['id'] = lut_id
        lut_5d = _cached_lut_gpu['tensor']

        # Downscale on GPU using F.interpolate
        h4, w4 = max(H // 4, 1), max(W // 4, 1)
        # (H, W, 3) → (1, 3, H, W) for interpolate
        refl_4d = refl.permute(2, 0, 1).unsqueeze(0)
        small_4d = F.interpolate(refl_4d, size=(h4, w4), mode='bilinear',
                                 align_corners=False)
        # (1, 3, h4, w4) → (h4, w4, 3)
        small = small_4d[0].permute(1, 2, 0)
        del refl_4d, small_4d

        # Build grid for trilinear LUT lookup
        r_coord = small[:, :, 2] * 2.0 - 1.0
        g_coord = small[:, :, 1] * 2.0 - 1.0
        n_coord = small[:, :, 0] * 2.0 - 1.0
        del small

        grid = torch.stack([n_coord, g_coord, r_coord], dim=-1)
        grid = grid.unsqueeze(0).unsqueeze(1)

        sampled = F.grid_sample(lut_5d, grid, mode='bilinear',
                                padding_mode='border', align_corners=True)
        corr_rgn = sampled[0, :, 0, :, :].permute(1, 2, 0)
        corr_bgr_small = corr_rgn[:, :, [2, 1, 0]]
        del grid, sampled, corr_rgn

        # Upscale correction on GPU and subtract
        corr_4d = corr_bgr_small.permute(2, 0, 1).unsqueeze(0)
        corr_full_4d = F.interpolate(corr_4d, size=(H, W), mode='bilinear',
                                     align_corners=False)
        corr_full = corr_full_4d[0].permute(1, 2, 0)
        del corr_bgr_small, corr_4d, corr_full_4d

        refl = (refl - corr_full).clamp_(0, 1)
        del corr_full

    # --- NDVI ---
    nir = refl[:, :, 0]
    red = refl[:, :, 2]
    denom = nir + red
    ndvi = torch.where(denom > 1e-6, (nir - red) / denom,
                       torch.zeros(H, W, dtype=torch.float32, device=_device))

    # --- Download ---
    refl_np = refl.cpu().numpy()
    ndvi_np = ndvi.cpu().numpy()
    del refl, nir, red, denom, ndvi

    return refl_np, ndvi_np


def _gpu_unmixing_impl(reflectance, lut):
    """Internal GPU unmixing LUT via grid_sample (trilinear)."""
    import torch
    import torch.nn.functional as F

    lut_data = lut['lut']  # (S, S, S, 3) in RGN channel order
    S = lut['grid_size']
    H, W = reflectance.shape[:2]

    # Downscale 4x on CPU (fast, correction is spatially smooth)
    h4, w4 = max(H // 4, 1), max(W // 4, 1)
    small = cv2.resize(reflectance, (w4, h4))

    # Cache LUT on GPU (only re-upload when LUT changes)
    lut_id = id(lut['lut'])
    if _cached_lut_gpu.get('id') != lut_id:
        lut_t = torch.from_numpy(lut_data.astype(np.float32)).to(_device)
        _cached_lut_gpu['tensor'] = lut_t.permute(3, 0, 1, 2).unsqueeze(0)
        _cached_lut_gpu['id'] = lut_id
    lut_5d = _cached_lut_gpu['tensor']

    # Upload downscaled frame and build grid coordinates
    small_t = torch.from_numpy(small).to(_device)

    # Map reflectance [0, 1] to grid_sample coords [-1, +1]
    # LUT axes: dim0=Red, dim1=Green, dim2=NIR
    # grid_sample 5D grid last dim is (x, y, z) mapping to (W, H, D) of input
    # Our LUT is (R, G, N) = (D, H, W) in grid_sample terms
    # So: x → N (dim2/W), y → G (dim1/H), z → R (dim0/D)
    r_coord = small_t[:, :, 2] * 2.0 - 1.0  # Red → z (depth)
    g_coord = small_t[:, :, 1] * 2.0 - 1.0  # Green → y (height)
    n_coord = small_t[:, :, 0] * 2.0 - 1.0  # NIR → x (width)
    del small_t

    # grid shape: (1, 1, h4, w4, 3) — depth=1 slice
    grid = torch.stack([n_coord, g_coord, r_coord], dim=-1)
    grid = grid.unsqueeze(0).unsqueeze(1)  # (1, 1, h4, w4, 3)

    # Trilinear interpolation
    sampled = F.grid_sample(lut_5d, grid, mode='bilinear',
                            padding_mode='border', align_corners=True)
    # sampled: (1, 3, 1, h4, w4) → (h4, w4, 3) RGN order
    corr_rgn = sampled[0, :, 0, :, :].permute(1, 2, 0)  # (h4, w4, 3)

    # RGN → BGR for direct frame subtraction
    corr_bgr = corr_rgn[:, :, [2, 1, 0]]

    corr_bgr_np = corr_bgr.cpu().numpy()
    del grid, sampled, corr_rgn, corr_bgr

    # Upsample correction and subtract
    full_corr = cv2.resize(corr_bgr_np, (W, H))
    return np.clip(reflectance - full_corr, 0, 1).astype(np.float32)


def _gpu_bilateral(bgr, d, sigma_color, sigma_space):
    """GPU bilateral filter using PyTorch."""
    import torch
    import torch.nn.functional as F

    h, w = bgr.shape[:2]
    radius = d // 2

    # Upload as float32, (1, 3, H, W)
    img = (
        torch.from_numpy(bgr.astype(np.float32))
        .permute(2, 0, 1)
        .unsqueeze(0)
        .to(_device)
    )

    # Pre-compute spatial Gaussian weights
    coords = torch.arange(-radius, radius + 1, dtype=torch.float32, device=_device)
    yy, xx = torch.meshgrid(coords, coords, indexing="ij")
    spatial = torch.exp(-(xx ** 2 + yy ** 2) / (2 * sigma_space ** 2))

    # Reflect-pad so shifted reads stay in-bounds
    padded = F.pad(img, [radius] * 4, mode="reflect")

    output = torch.zeros_like(img)
    weight_sum = torch.zeros(1, 1, h, w, dtype=torch.float32, device=_device)

    inv_2sc2 = -1.0 / (2.0 * sigma_color ** 2)

    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            shifted = padded[
                :, :,
                radius + dy: radius + dy + h,
                radius + dx: radius + dx + w,
            ]
            # Range weight based on mean channel difference
            diff_sq = (img - shifted).pow(2).mean(dim=1, keepdim=True)
            range_w = torch.exp(diff_sq * inv_2sc2)
            sw = spatial[dy + radius, dx + radius]
            combined = sw * range_w
            output += shifted * combined
            weight_sum += combined

    output /= weight_sum
    result = np.ascontiguousarray(
        output.squeeze(0).permute(1, 2, 0).clamp(0, 255).to(torch.uint8).cpu().numpy()
    )

    del img, padded, output, weight_sum, spatial
    torch.cuda.empty_cache()
    return result
