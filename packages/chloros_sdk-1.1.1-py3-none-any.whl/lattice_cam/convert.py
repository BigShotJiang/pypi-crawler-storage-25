import numpy as np
import cv2

# Bayer pattern -> OpenCV demosaic code mappings
# GenICam/GigE Vision and OpenCV use transposed naming conventions for Bayer
# patterns (RG<->BG, GR<->GB), so the mapping swaps them.
# 8-bit patterns
_BAYER_TO_BGR_8 = {
    "BayerRG8":  cv2.COLOR_BayerBG2BGR,
    "BayerBG8":  cv2.COLOR_BayerRG2BGR,
    "BayerGR8":  cv2.COLOR_BayerGB2BGR,
    "BayerGB8":  cv2.COLOR_BayerGR2BGR,
}

# 10/12/16-bit patterns (same demosaic codes, applied to 16-bit arrays)
_BAYER_TO_BGR_DEEP = {
    "BayerRG10": cv2.COLOR_BayerBG2BGR,
    "BayerRG12": cv2.COLOR_BayerBG2BGR,
    "BayerRG16": cv2.COLOR_BayerBG2BGR,
    "BayerBG10": cv2.COLOR_BayerRG2BGR,
    "BayerBG12": cv2.COLOR_BayerRG2BGR,
    "BayerBG16": cv2.COLOR_BayerRG2BGR,
    "BayerGR10": cv2.COLOR_BayerGB2BGR,
    "BayerGR12": cv2.COLOR_BayerGB2BGR,
    "BayerGR16": cv2.COLOR_BayerGB2BGR,
    "BayerGB10": cv2.COLOR_BayerGR2BGR,
    "BayerGB12": cv2.COLOR_BayerGR2BGR,
    "BayerGB16": cv2.COLOR_BayerGR2BGR,
}

# Bit depth per pixel format
_FORMAT_BITS = {
    "Mono8": 8, "Mono10": 10, "Mono12": 12, "Mono16": 16,
    "BayerRG8": 8, "BayerBG8": 8, "BayerGR8": 8, "BayerGB8": 8,
    "BayerRG10": 10, "BayerBG10": 10, "BayerGR10": 10, "BayerGB10": 10,
    "BayerRG12": 12, "BayerBG12": 12, "BayerGR12": 12, "BayerGB12": 12,
    "BayerRG16": 16, "BayerBG16": 16, "BayerGR16": 16, "BayerGB16": 16,
}


def buffer_to_numpy(buffer):
    """Convert an arena_api buffer to a numpy array (copies data).

    The copy ensures the buffer can be safely requeued after this call.
    Returns a 2D array (H, W) for mono/bayer formats.
    """
    width = buffer.width
    height = buffer.height
    bits = buffer.bits_per_pixel

    if bits <= 8:
        # 1 byte per pixel — read directly as uint8
        data = np.ctypeslib.as_array(buffer.pdata, shape=(height * width,))
        return data.astype(np.uint8, copy=True).reshape((height, width))
    else:
        # 2 bytes per pixel — read the raw bytes then reinterpret as uint16
        total_bytes = height * width * 2
        raw = np.ctypeslib.as_array(buffer.pdata, shape=(total_bytes,))
        return raw.view(np.uint16).copy().reshape((height, width))


def numpy_to_bgr(arr, pixel_format):
    """Demosaic a raw 2-D numpy array to 8-bit BGR (H, W, 3).

    Operates on data already copied out of the SDK buffer, so this
    function is safe to call from any thread after ``requeue_buffer()``.
    """
    bits = _FORMAT_BITS.get(pixel_format, 8)

    if bits > 8:
        arr = (arr >> (bits - 8)).astype(np.uint8)
    else:
        arr = arr.astype(np.uint8)

    if pixel_format.startswith("Mono"):
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)

    code = _BAYER_TO_BGR_8.get(pixel_format)
    if code is not None:
        return cv2.cvtColor(arr, code)

    base_pattern = pixel_format[:7] + "8"
    code = _BAYER_TO_BGR_8.get(base_pattern)
    if code is not None:
        return cv2.cvtColor(arr, code)

    return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)


def numpy_to_bgr_full_depth(arr, pixel_format):
    """Demosaic a raw 2-D numpy array to BGR preserving 10/12/16-bit depth.

    Returns uint8 (H,W,3) for 8-bit, uint16 (H,W,3) for deeper formats.
    Left-shifts to fill the 16-bit range for consistent TIFF output.
    """
    bits = _FORMAT_BITS.get(pixel_format, 8)

    if pixel_format.startswith("Mono"):
        if bits <= 8:
            return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
        scale = 16 - bits
        arr_s = (arr.astype(np.uint16) << scale) if scale > 0 else arr
        return cv2.cvtColor(arr_s, cv2.COLOR_GRAY2BGR)

    if bits <= 8:
        code = _BAYER_TO_BGR_8.get(pixel_format)
        if code is not None:
            return cv2.cvtColor(arr, code)
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)

    code = _BAYER_TO_BGR_DEEP.get(pixel_format)
    if code is not None:
        bgr = cv2.cvtColor(arr, code)
        scale = 16 - bits
        if scale > 0:
            bgr = (bgr.astype(np.uint16) << scale)
        return bgr

    return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)


def numpy_to_bgr_native(arr, pixel_format):
    """Demosaic a raw 2-D numpy array to BGR preserving native bit depth.

    Unlike ``numpy_to_bgr_full_depth()``, does **not** left-shift —
    returned values are raw sensor DN.
    """
    bits = _FORMAT_BITS.get(pixel_format, 8)

    if pixel_format.startswith("Mono"):
        if bits <= 8:
            return cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_GRAY2BGR)
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)

    if bits <= 8:
        code = _BAYER_TO_BGR_8.get(pixel_format)
        if code is not None:
            return cv2.cvtColor(arr.astype(np.uint8), code)
        return cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_GRAY2BGR)

    code = _BAYER_TO_BGR_DEEP.get(pixel_format)
    if code is not None:
        return cv2.cvtColor(arr, code)
    return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)


# -- Buffer-based wrappers (convenience, call numpy_to_* internally) -------

def buffer_to_bgr(buffer, pixel_format=None):
    """Convert buffer to 8-bit BGR numpy array for OpenCV display."""
    if pixel_format is None:
        pixel_format = _get_pixel_format_name(buffer)
    return numpy_to_bgr(buffer_to_numpy(buffer), pixel_format)


def buffer_to_bgr_full_depth(buffer, pixel_format=None):
    """Convert buffer to BGR preserving 10/12/16-bit depth.

    Returns uint8 (H,W,3) for 8-bit formats, uint16 (H,W,3) for deeper formats.
    Suitable for saving as 16-bit TIFF.
    """
    if pixel_format is None:
        pixel_format = _get_pixel_format_name(buffer)
    return numpy_to_bgr_full_depth(buffer_to_numpy(buffer), pixel_format)


def buffer_to_bgr_native(buffer, pixel_format=None):
    """Convert buffer to BGR preserving native bit depth without scaling.

    Returns uint8 (H,W,3) for 8-bit formats, uint16 (H,W,3) for deeper formats.
    Unlike ``buffer_to_bgr_full_depth()``, does **not** left-shift to fill
    the 16-bit range — the returned values are raw sensor DN.
    """
    if pixel_format is None:
        pixel_format = _get_pixel_format_name(buffer)
    return numpy_to_bgr_native(buffer_to_numpy(buffer), pixel_format)


def _get_pixel_format_name(buffer):
    """Extract pixel format name string from buffer."""
    # arena_api buffers expose pixel_format as an integer enum;
    # the LatticeCam class passes the format string explicitly,
    # so this is only a fallback.
    return getattr(buffer, "pixel_format_name", "BayerRG8")
