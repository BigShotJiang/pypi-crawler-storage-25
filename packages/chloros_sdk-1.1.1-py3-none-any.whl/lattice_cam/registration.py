"""Multi-camera co-registration (alignment) for LATTICE arrays.

Computes geometric alignment transforms between cameras in a multi-camera
array, saves them as a reusable profile, and applies them at speed during
capture/streaming to produce spatially co-registered multi-band output.

Workflow::

    # Calibrate (once)
    trigger_ts, frames = array.grab_sync()
    profile = compute_alignment(frames, method="feature_orb", model="affine")
    profile.save("alignment.json")

    # Apply (every frame)
    profile = AlignmentProfile.load("alignment.json")
    aligned = apply_alignment(frames, profile)
    bands = extract_bands(aligned, profile)
    save_multiband_tiff(bands, profile, "output.tif")
"""

import json
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

from lattice_cam.models import parse_model_string, format_display_model, ModelInfo
from lattice_cam.metadata import (
    M3C_BANDS as _M3C_BANDS,
    M3M_FWHM as _M3M_FWHM,
    LATTICE_PIX4D as _LATTICE_PIX4D,
    IMX265_PIXELS_PER_MM as _IMX265_PIXELS_PER_MM,
)


def _bands_for_model(model_str: str, serial: str) -> List[Dict[str, Any]]:
    """Return band descriptors for a camera model string."""
    try:
        info = parse_model_string(model_str)
    except ValueError:
        return [{"name": f"Band_{serial}", "wavelength_nm": 0, "channel": 0}]

    if info.sensor == "M3C":
        bands = _M3C_BANDS.get(info.filter_code, [])
        # Append filter code suffix to disambiguate across cameras
        return [
            {**b, "name": f"{b['name']}_{info.filter_code}"}
            for b in bands
        ]
    else:
        # M3M — single monochrome band
        try:
            wl = int(info.filter_code)
        except ValueError:
            wl = 0
        fwhm = _M3M_FWHM.get(wl, 0)
        return [{"name": f"Mono_{info.filter_code}", "wavelength_nm": wl,
                 "channel": 0, "fwhm_nm": fwhm}]


# ---------------------------------------------------------------------------
# AlignmentProfile — the persistent calibration artifact
# ---------------------------------------------------------------------------

@dataclass
class AlignmentProfile:
    """Geometric alignment profile for a multi-camera array.

    Stores the transforms needed to warp each camera's frames into a
    common coordinate system defined by the reference camera.

    Attributes
    ----------
    name : str
        Human-readable profile name.
    created : str
        ISO-8601 creation timestamp.
    reference_serial : str
        Serial of the reference camera (identity transform).
    camera_serials : list of str
        All camera serials in the array.
    transforms : dict
        ``{serial: {"model": str, "matrix": list[list[float]],
        "reprojection_error": float, "num_matches": int}}``.
        Reference camera has identity matrix.
    output_width : int
        Width of the aligned output (after crop).
    output_height : int
        Height of the aligned output (after crop).
    crop_roi : tuple of int
        ``(x, y, w, h)`` — valid overlap region in the warped coordinate space.
    layer_order : list of dict
        ``[{"serial": str, "channels": list[int], "band_names": list[str],
        "wavelengths_nm": list[int], "enabled": bool}, ...]``
        sorted by wavelength ascending. Each band has an ``enabled`` flag.
    camera_models : dict
        ``{serial: DeviceUserID}`` for validation.
    method : str
        Calibration method used (e.g. ``"feature_orb"``).
    pixel_format : str
        Pixel format at calibration time.
    sensor_resolution : tuple of int
        ``(width, height)`` of the sensor.
    """
    name: str = ""
    created: str = ""
    reference_serial: str = ""
    camera_serials: List[str] = field(default_factory=list)
    transforms: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    output_width: int = 0
    output_height: int = 0
    crop_roi: Tuple[int, int, int, int] = (0, 0, 0, 0)
    layer_order: List[Dict[str, Any]] = field(default_factory=list)
    camera_models: Dict[str, str] = field(default_factory=dict)
    method: str = ""
    pixel_format: str = ""
    sensor_resolution: Tuple[int, int] = (0, 0)

    def save(self, path):
        """Save profile to JSON file."""
        data = {
            "name": self.name,
            "created": self.created,
            "reference_serial": self.reference_serial,
            "camera_serials": self.camera_serials,
            "transforms": {
                serial: {
                    "model": t["model"],
                    "matrix": (np.array(t["matrix"]).tolist()
                               if not isinstance(t["matrix"], list) else t["matrix"]),
                    "reprojection_error": t.get("reprojection_error", 0.0),
                    "num_matches": t.get("num_matches", 0),
                }
                for serial, t in self.transforms.items()
            },
            "output_width": self.output_width,
            "output_height": self.output_height,
            "crop_roi": list(self.crop_roi),
            "layer_order": self.layer_order,
            "camera_models": self.camera_models,
            "method": self.method,
            "pixel_format": self.pixel_format,
            "sensor_resolution": list(self.sensor_resolution),
        }
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, indent=2))

    @classmethod
    def load(cls, path):
        """Load profile from JSON file."""
        data = json.loads(Path(path).read_text())
        transforms = {}
        for serial, t in data.get("transforms", {}).items():
            transforms[serial] = {
                "model": t["model"],
                "matrix": np.array(t["matrix"], dtype=np.float64),
                "reprojection_error": t.get("reprojection_error", 0.0),
                "num_matches": t.get("num_matches", 0),
            }
        roi = data.get("crop_roi", [0, 0, 0, 0])
        res = data.get("sensor_resolution", [0, 0])
        return cls(
            name=data.get("name", ""),
            created=data.get("created", ""),
            reference_serial=data.get("reference_serial", ""),
            camera_serials=data.get("camera_serials", []),
            transforms=transforms,
            output_width=data.get("output_width", 0),
            output_height=data.get("output_height", 0),
            crop_roi=tuple(roi),
            layer_order=data.get("layer_order", []),
            camera_models=data.get("camera_models", {}),
            method=data.get("method", ""),
            pixel_format=data.get("pixel_format", ""),
            sensor_resolution=tuple(res),
        )


# ---------------------------------------------------------------------------
# Layer ordering
# ---------------------------------------------------------------------------

def build_layer_order(camera_models: Dict[str, str],
                      serials: List[str]) -> List[Dict[str, Any]]:
    """Auto-generate band ordering from DeviceUserID model strings.

    Produces one entry per camera, sorted by minimum wavelength ascending.
    Within each entry, bands are in the camera's native channel order.

    Parameters
    ----------
    camera_models : dict
        ``{serial: DeviceUserID}`` — e.g. ``{"123": "M3C-L41-FRGN"}``.
    serials : list of str
        Camera serials in the array.

    Returns
    -------
    list of dict
        Layer order entries with band metadata.
    """
    entries = []
    for serial in serials:
        model_str = camera_models.get(serial, "")
        bands = _bands_for_model(model_str, serial)
        band_names = [b["name"] for b in bands]
        wavelengths = [b["wavelength_nm"] for b in bands]
        channels = [b["channel"] for b in bands]
        min_wl = min(wavelengths) if wavelengths else 0
        entries.append({
            "serial": serial,
            "channels": channels,
            "band_names": band_names,
            "wavelengths_nm": wavelengths,
            "enabled": True,
            "_sort_key": min_wl,
        })

    # Sort by minimum wavelength ascending
    entries.sort(key=lambda e: e["_sort_key"])
    for e in entries:
        del e["_sort_key"]
    return entries


# ---------------------------------------------------------------------------
# Per-frame metadata extraction
# ---------------------------------------------------------------------------

def _extract_metadata(frame_dict, profile):
    """Extract per-camera metadata from a ``{serial: (frame, meta)}`` dict.

    Augments each camera's metadata with ``camera_model`` from the profile.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: (frame, meta)}`` from ``grab_sync()``.
    profile : AlignmentProfile
        Profile with ``camera_models`` for model string lookup.

    Returns
    -------
    dict
        ``{serial: metadata_dict}`` with keys: ``exposure_time_us``,
        ``gain_db``, ``timestamp_ns``, ``frame_id``, ``camera_model``.
    """
    result = {}
    for serial, val in frame_dict.items():
        if not isinstance(val, tuple) or len(val) < 2:
            continue
        meta = val[1] if isinstance(val[1], dict) else {}
        result[serial] = {
            "exposure_time_us": meta.get("exposure_time_us"),
            "gain_db": meta.get("gain_db"),
            "timestamp_ns": meta.get("timestamp_ns"),
            "frame_id": meta.get("frame_id"),
            "camera_model": profile.camera_models.get(serial, ""),
        }
    return result


# ---------------------------------------------------------------------------
# Calibration — compute alignment transforms
# ---------------------------------------------------------------------------

def _to_gray(frame):
    """Convert BGR frame to grayscale."""
    if frame.ndim == 2:
        return frame
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def _extract_frame(frame_or_tuple):
    """Extract the frame array from a (frame, meta) tuple or bare array."""
    if isinstance(frame_or_tuple, tuple):
        return frame_or_tuple[0]
    return frame_or_tuple


def _match_features_orb(gray_ref, gray_tgt, max_features=5000):
    """Match ORB features between reference and target images.

    Returns matched point pairs (pts_ref, pts_tgt) as Nx2 float arrays.
    """
    orb = cv2.ORB_create(nfeatures=max_features)
    kp1, des1 = orb.detectAndCompute(gray_ref, None)
    kp2, des2 = orb.detectAndCompute(gray_tgt, None)

    if des1 is None or des2 is None or len(des1) < 4 or len(des2) < 4:
        return np.empty((0, 2)), np.empty((0, 2))

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    matches = bf.knnMatch(des1, des2, k=2)

    # Lowe's ratio test
    good = []
    for pair in matches:
        if len(pair) == 2:
            m, n = pair
            if m.distance < 0.75 * n.distance:
                good.append(m)

    if len(good) < 4:
        return np.empty((0, 2)), np.empty((0, 2))

    pts_ref = np.float32([kp1[m.queryIdx].pt for m in good])
    pts_tgt = np.float32([kp2[m.trainIdx].pt for m in good])
    return pts_ref, pts_tgt


def _match_features_akaze(gray_ref, gray_tgt):
    """Match AKAZE features between reference and target images."""
    akaze = cv2.AKAZE_create()
    kp1, des1 = akaze.detectAndCompute(gray_ref, None)
    kp2, des2 = akaze.detectAndCompute(gray_tgt, None)

    if des1 is None or des2 is None or len(des1) < 4 or len(des2) < 4:
        return np.empty((0, 2)), np.empty((0, 2))

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    matches = bf.knnMatch(des1, des2, k=2)

    good = []
    for pair in matches:
        if len(pair) == 2:
            m, n = pair
            if m.distance < 0.75 * n.distance:
                good.append(m)

    if len(good) < 4:
        return np.empty((0, 2)), np.empty((0, 2))

    pts_ref = np.float32([kp1[m.queryIdx].pt for m in good])
    pts_tgt = np.float32([kp2[m.trainIdx].pt for m in good])
    return pts_ref, pts_tgt


def _phase_correlation(gray_ref, gray_tgt):
    """Compute sub-pixel translation via phase correlation.

    Returns matched point pairs (just 3 synthetic pairs encoding
    the translation, suitable for estimating a translation model).
    """
    ref_f = np.float32(gray_ref)
    tgt_f = np.float32(gray_tgt)
    shift, response = cv2.phaseCorrelate(ref_f, tgt_f)
    dx, dy = shift  # (x, y) sub-pixel shift

    h, w = gray_ref.shape[:2]
    cx, cy = w / 2, h / 2
    # Synthetic point pairs encoding the translation
    pts_ref = np.float32([[cx, cy], [cx + 100, cy], [cx, cy + 100]])
    pts_tgt = np.float32([[cx + dx, cy + dy], [cx + 100 + dx, cy + dy],
                           [cx + dx, cy + 100 + dy]])
    return pts_ref, pts_tgt


def _detect_checkerboard(gray, board_size):
    """Detect checkerboard corners in a grayscale image.

    Parameters
    ----------
    gray : ndarray
        Grayscale image.
    board_size : tuple of int
        ``(rows, cols)`` inner corner count.

    Returns
    -------
    corners : ndarray (N, 2) or None
        Sub-pixel corner locations.
    """
    flags = (cv2.CALIB_CB_ADAPTIVE_THRESH
             | cv2.CALIB_CB_NORMALIZE_IMAGE
             | cv2.CALIB_CB_FAST_CHECK)
    found, corners = cv2.findChessboardCorners(gray, board_size, flags)
    if not found:
        return None
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
    corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
    return corners.reshape(-1, 2)


def _estimate_transform(pts_ref, pts_tgt, model="affine"):
    """Estimate geometric transform from matched point pairs.

    Parameters
    ----------
    pts_ref, pts_tgt : ndarray (N, 2)
        Matched point coordinates.
    model : str
        ``"translation"``, ``"rigid"``, ``"affine"``, or ``"homography"``.

    Returns
    -------
    matrix : ndarray
        2x3 (affine/rigid/translation) or 3x3 (homography) transform matrix.
    inlier_mask : ndarray
        Boolean mask of inlier matches.
    """
    n = len(pts_ref)
    if n < 2:
        raise ValueError(f"Need at least 2 point pairs, got {n}")

    if model == "translation":
        # Pure translation — median of offsets (robust to outliers)
        dx = np.median(pts_tgt[:, 0] - pts_ref[:, 0])
        dy = np.median(pts_tgt[:, 1] - pts_ref[:, 1])
        matrix = np.array([[1, 0, dx], [0, 1, dy]], dtype=np.float64)
        # All points are "inliers" for translation
        return matrix, np.ones(n, dtype=bool)

    elif model == "rigid":
        # Rigid (rotation + translation) via estimateAffinePartial2D
        if n < 3:
            raise ValueError(f"Rigid model needs >= 3 points, got {n}")
        matrix, inliers = cv2.estimateAffinePartial2D(
            pts_ref, pts_tgt, method=cv2.RANSAC, ransacReprojThreshold=3.0)
        if matrix is None:
            raise ValueError("Rigid transform estimation failed")
        return matrix, inliers.ravel().astype(bool)

    elif model == "affine":
        if n < 3:
            raise ValueError(f"Affine model needs >= 3 points, got {n}")
        matrix, inliers = cv2.estimateAffine2D(
            pts_ref, pts_tgt, method=cv2.RANSAC, ransacReprojThreshold=3.0)
        if matrix is None:
            raise ValueError("Affine transform estimation failed")
        return matrix, inliers.ravel().astype(bool)

    elif model == "homography":
        if n < 4:
            raise ValueError(f"Homography needs >= 4 points, got {n}")
        matrix, inliers = cv2.findHomography(
            pts_ref, pts_tgt, cv2.RANSAC, ransacReprojThreshold=3.0)
        if matrix is None:
            raise ValueError("Homography estimation failed")
        return matrix, inliers.ravel().astype(bool)

    else:
        raise ValueError(f"Unknown model '{model}'. "
                         f"Use translation, rigid, affine, or homography.")


def _compute_reprojection_error(pts_ref, pts_tgt, matrix, model):
    """Compute RMS reprojection error for a transform."""
    if model == "homography":
        pts_h = np.hstack([pts_ref, np.ones((len(pts_ref), 1))])
        projected = (matrix @ pts_h.T).T
        projected = projected[:, :2] / projected[:, 2:3]
    else:
        pts_h = np.hstack([pts_ref, np.ones((len(pts_ref), 1))])
        projected = (matrix @ pts_h.T).T

    errors = np.sqrt(np.sum((projected - pts_tgt) ** 2, axis=1))
    return float(np.sqrt(np.mean(errors ** 2)))


def compute_alignment(frame_dict, method="feature_orb", model="affine",
                      reference_serial=None, camera_models=None,
                      checkerboard_size=None, control_points=None,
                      max_features=5000, name=""):
    """Compute alignment transforms from a set of synchronized frames.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
    method : str
        ``"feature_orb"``, ``"feature_akaze"``, ``"phase_correlation"``,
        ``"checkerboard"``, or ``"manual"``.
    model : str
        ``"translation"``, ``"rigid"``, ``"affine"``, or ``"homography"``.
    reference_serial : str, optional
        Serial of the reference camera. Default: first key.
    camera_models : dict, optional
        ``{serial: DeviceUserID}`` for band metadata.
    checkerboard_size : tuple of int, optional
        ``(rows, cols)`` for checkerboard method.
    control_points : dict, optional
        ``{serial: [[x, y], ...]}`` for manual method.
    max_features : int
        Max ORB features to detect.
    name : str
        Profile name.

    Returns
    -------
    AlignmentProfile
    """
    serials = list(frame_dict.keys())
    if not serials:
        raise ValueError("frame_dict is empty")

    if reference_serial is None:
        reference_serial = serials[0]
    if reference_serial not in frame_dict:
        raise ValueError(f"Reference serial '{reference_serial}' not in frame_dict")

    camera_models = camera_models or {}

    ref_frame = _extract_frame(frame_dict[reference_serial])
    ref_gray = _to_gray(ref_frame)
    h, w = ref_frame.shape[:2]

    transforms = {}

    for serial in serials:
        if serial == reference_serial:
            # Identity transform for reference camera
            transforms[serial] = {
                "model": model,
                "matrix": np.eye(2, 3, dtype=np.float64) if model != "homography"
                          else np.eye(3, dtype=np.float64),
                "reprojection_error": 0.0,
                "num_matches": 0,
            }
            continue

        tgt_frame = _extract_frame(frame_dict[serial])
        tgt_gray = _to_gray(tgt_frame)

        # Get matched points
        if method == "feature_orb":
            pts_ref, pts_tgt = _match_features_orb(ref_gray, tgt_gray,
                                                    max_features)
        elif method == "feature_akaze":
            pts_ref, pts_tgt = _match_features_akaze(ref_gray, tgt_gray)
        elif method == "phase_correlation":
            pts_ref, pts_tgt = _phase_correlation(ref_gray, tgt_gray)
        elif method == "checkerboard":
            if checkerboard_size is None:
                raise ValueError("checkerboard_size required for "
                                 "checkerboard method")
            pts_ref = _detect_checkerboard(ref_gray, checkerboard_size)
            pts_tgt = _detect_checkerboard(tgt_gray, checkerboard_size)
            if pts_ref is None or pts_tgt is None:
                raise ValueError(
                    f"Checkerboard not detected in {'reference' if pts_ref is None else serial}")
        elif method == "manual":
            if control_points is None:
                raise ValueError("control_points required for manual method")
            pts_ref = np.float32(control_points.get(reference_serial, []))
            pts_tgt = np.float32(control_points.get(serial, []))
            if len(pts_ref) < 2 or len(pts_tgt) < 2:
                raise ValueError(
                    f"Need >= 2 control points per camera for manual method")
        else:
            raise ValueError(f"Unknown method '{method}'")

        if len(pts_ref) < 2:
            raise ValueError(
                f"Insufficient matches for {serial}: got {len(pts_ref)}")

        # Estimate transform
        matrix, inlier_mask = _estimate_transform(pts_ref, pts_tgt, model)

        # Compute reprojection error on inliers
        inlier_ref = pts_ref[inlier_mask]
        inlier_tgt = pts_tgt[inlier_mask]
        reproj_err = _compute_reprojection_error(
            inlier_ref, inlier_tgt, matrix, model)

        transforms[serial] = {
            "model": model,
            "matrix": matrix,
            "reprojection_error": reproj_err,
            "num_matches": int(inlier_mask.sum()),
        }

    # Compute overlap ROI
    img_size = (w, h)
    crop_roi = compute_overlap_roi(transforms, img_size)
    rx, ry, rw, rh = crop_roi

    # Build layer order
    layer_order = build_layer_order(camera_models, serials)

    return AlignmentProfile(
        name=name or f"alignment_{int(time.time())}",
        created=time.strftime("%Y-%m-%dT%H:%M:%S"),
        reference_serial=reference_serial,
        camera_serials=serials,
        transforms=transforms,
        output_width=rw,
        output_height=rh,
        crop_roi=crop_roi,
        layer_order=layer_order,
        camera_models=camera_models,
        method=method,
        pixel_format="",
        sensor_resolution=(w, h),
    )


def compute_alignment_multi(frame_dicts, method="feature_orb", model="affine",
                             reference_serial=None, camera_models=None,
                             checkerboard_size=None, max_features=5000,
                             name=""):
    """Compute alignment by averaging transforms over multiple captures.

    Parameters
    ----------
    frame_dicts : list of dict
        Multiple ``{serial: frame_bgr}`` captures.
    **kwargs
        Passed to ``compute_alignment``.

    Returns
    -------
    AlignmentProfile
        Profile with averaged transforms for improved robustness.
    """
    if not frame_dicts:
        raise ValueError("Need at least one frame_dict")

    profiles = []
    for fd in frame_dicts:
        p = compute_alignment(fd, method=method, model=model,
                              reference_serial=reference_serial,
                              camera_models=camera_models,
                              checkerboard_size=checkerboard_size,
                              max_features=max_features, name=name)
        profiles.append(p)

    if len(profiles) == 1:
        return profiles[0]

    # Average transforms across captures
    base = profiles[0]
    for serial in base.camera_serials:
        if serial == base.reference_serial:
            continue

        matrices = []
        errors = []
        counts = []
        for p in profiles:
            t = p.transforms[serial]
            matrices.append(t["matrix"])
            errors.append(t["reprojection_error"])
            counts.append(t["num_matches"])

        avg_matrix = np.mean(matrices, axis=0)
        avg_error = float(np.mean(errors))
        total_matches = int(np.sum(counts))

        base.transforms[serial] = {
            "model": model,
            "matrix": avg_matrix,
            "reprojection_error": avg_error,
            "num_matches": total_matches,
        }

    # Recompute overlap ROI with averaged transforms
    w, h = base.sensor_resolution
    base.crop_roi = compute_overlap_roi(base.transforms, (w, h))
    base.output_width = base.crop_roi[2]
    base.output_height = base.crop_roi[3]

    return base


# ---------------------------------------------------------------------------
# Overlap computation
# ---------------------------------------------------------------------------

def compute_overlap_roi(transforms, img_size):
    """Compute the intersection of all warped frame boundaries.

    Parameters
    ----------
    transforms : dict
        ``{serial: {"model": str, "matrix": ndarray}}``.
    img_size : tuple of int
        ``(width, height)`` of the source images.

    Returns
    -------
    tuple of int
        ``(x, y, w, h)`` bounding box of the valid overlap region.
    """
    w, h = img_size

    # Corner points of the source image
    corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]])

    # Track the intersection bounds
    x_min, y_min = -np.inf, -np.inf
    x_max, y_max = np.inf, np.inf

    for serial, t in transforms.items():
        matrix = t["matrix"]
        model = t["model"]

        # ``matrix`` maps master→slave. crop_roi is consumed in master
        # space (apply_alignment crops the warped output, which is in
        # master coords), so we want each slave's bounds expressed in
        # master coords — that's the inverse map applied to the
        # slave's frame corners.
        if model == "homography":
            inv = np.linalg.inv(matrix)
            warped = cv2.perspectiveTransform(
                corners.reshape(1, -1, 2), inv)[0]
        else:
            inv = cv2.invertAffineTransform(matrix)
            warped = cv2.transform(
                corners.reshape(1, -1, 2), inv)[0]

        x_min = max(x_min, warped[:, 0].min())
        y_min = max(y_min, warped[:, 1].min())
        x_max = min(x_max, warped[:, 0].max())
        y_max = min(y_max, warped[:, 1].max())

    # Clamp to valid image coordinates
    x_min = max(int(np.ceil(x_min)), 0)
    y_min = max(int(np.ceil(y_min)), 0)
    x_max = min(int(np.floor(x_max)), w)
    y_max = min(int(np.floor(y_max)), h)

    rw = max(x_max - x_min, 0)
    rh = max(y_max - y_min, 0)

    return (x_min, y_min, rw, rh)


# ---------------------------------------------------------------------------
# Apply alignment — CPU path
# ---------------------------------------------------------------------------

def apply_alignment(frame_dict, profile, crop=True):
    """Apply alignment transforms to a synchronized frame group.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
    profile : AlignmentProfile
        Loaded alignment profile.
    crop : bool
        If True, crop to the overlap ROI. If False, keep full frame
        (black-padded where no data exists).

    Returns
    -------
    dict
        ``{serial: aligned_frame}`` — aligned BGR frames.
    """
    w, h = profile.sensor_resolution
    aligned = {}

    for serial in profile.camera_serials:
        if serial not in frame_dict:
            continue

        frame = _extract_frame(frame_dict[serial])
        t = profile.transforms.get(serial)
        if t is None:
            aligned[serial] = frame
            continue

        matrix = t["matrix"]
        model = t["model"]

        # Reference camera — identity, no warp needed
        is_identity = (serial == profile.reference_serial)
        if is_identity:
            warped = frame
        elif model == "homography":
            # WARP_INVERSE_MAP: matrix maps master→slave (from
            # estimateAffine2D / findHomography with master as
            # ``from`` argument). Without this flag warpPerspective
            # would treat it as src→dst (slave→master), which is the
            # opposite of what we have, and the warp would shift each
            # slave by ~2× the actual master/slave offset.
            warped = cv2.warpPerspective(
                frame, matrix, (w, h),
                flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0)
        else:
            warped = cv2.warpAffine(
                frame, matrix, (w, h),
                flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0)

        if crop and profile.crop_roi[2] > 0 and profile.crop_roi[3] > 0:
            rx, ry, rw, rh = profile.crop_roi
            warped = warped[ry:ry + rh, rx:rx + rw]

        aligned[serial] = warped

    return aligned


# ---------------------------------------------------------------------------
# GPU apply alignment
# ---------------------------------------------------------------------------

_gpu_grids = {}  # cached affine grids: {profile_id: {serial: grid_tensor}}
_gpu_available = None


def _check_gpu():
    """Lazy-init GPU availability check."""
    global _gpu_available
    if _gpu_available is not None:
        return _gpu_available
    try:
        import torch
        _gpu_available = torch.cuda.is_available()
    except ImportError:
        _gpu_available = False
    return _gpu_available


def gpu_apply_alignment(frame_dict, profile, crop=True):
    """Apply alignment transforms using GPU-accelerated grid_sample.

    Uses PyTorch ``F.grid_sample`` with cached affine grids for fast
    repeated warping. Falls back to CPU ``apply_alignment`` if CUDA is
    unavailable.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
    profile : AlignmentProfile
        Loaded alignment profile.
    crop : bool
        If True, crop to the overlap ROI.

    Returns
    -------
    dict
        ``{serial: aligned_frame}`` — aligned BGR frames.
    """
    if not _check_gpu():
        return apply_alignment(frame_dict, profile, crop)

    try:
        return _gpu_apply_impl(frame_dict, profile, crop)
    except Exception:
        return apply_alignment(frame_dict, profile, crop)


def _gpu_apply_impl(frame_dict, profile, crop):
    """Internal GPU alignment implementation."""
    import torch
    import torch.nn.functional as F

    device = torch.device("cuda:0")
    w, h = profile.sensor_resolution
    profile_id = id(profile)

    # Build or retrieve cached grids
    if _gpu_grids.get("_id") != profile_id:
        _gpu_grids.clear()
        _gpu_grids["_id"] = profile_id
        for serial in profile.camera_serials:
            t = profile.transforms[serial]
            if serial == profile.reference_serial:
                continue  # no warp needed
            matrix = t["matrix"]
            model = t["model"]

            if model == "homography":
                # For homography, build a full remap grid
                grid = _build_homography_grid(matrix, w, h, device)
            else:
                # Affine: use F.affine_grid
                # Convert 2x3 OpenCV matrix to PyTorch theta (2x3, normalized)
                theta = _opencv_affine_to_torch(matrix, w, h)
                theta_t = torch.from_numpy(theta).float().unsqueeze(0).to(device)
                grid = F.affine_grid(theta_t, (1, 1, h, w), align_corners=False)
            _gpu_grids[serial] = grid

    aligned = {}
    for serial in profile.camera_serials:
        if serial not in frame_dict:
            continue

        frame = _extract_frame(frame_dict[serial])

        if serial == profile.reference_serial:
            warped = frame
        else:
            grid = _gpu_grids.get(serial)
            if grid is None:
                warped = frame
            else:
                # Upload frame: (H, W, C) uint8 -> (1, C, H, W) float
                t = (torch.from_numpy(frame.astype(np.float32))
                     .permute(2, 0, 1).unsqueeze(0).to(device))
                sampled = F.grid_sample(t, grid, mode="bilinear",
                                        padding_mode="zeros",
                                        align_corners=False)
                warped = (sampled[0].permute(1, 2, 0)
                          .clamp(0, 255).to(torch.uint8)
                          .cpu().numpy())
                del t, sampled

        if crop and profile.crop_roi[2] > 0 and profile.crop_roi[3] > 0:
            rx, ry, rw, rh = profile.crop_roi
            warped = warped[ry:ry + rh, rx:rx + rw]

        aligned[serial] = warped

    return aligned


def _opencv_affine_to_torch(matrix, w, h):
    """Convert OpenCV 2x3 affine matrix to PyTorch theta (2x3 normalized).

    OpenCV maps pixel coords; PyTorch maps [-1, 1] normalized coords.
    """
    # Build the full 3x3 affine
    M = np.eye(3, dtype=np.float64)
    M[:2, :] = matrix

    # Normalization matrices: pixel <-> [-1, 1]
    # T_norm: maps pixel [0..w-1, 0..h-1] to [-1, 1]
    T_norm = np.array([
        [2.0 / (w - 1), 0, -1],
        [0, 2.0 / (h - 1), -1],
        [0, 0, 1],
    ])
    T_denorm = np.linalg.inv(T_norm)

    # grid_sample/affine_grid: output[k,l] = input[theta · norm_out(k,l)],
    # so theta must map output coords (master) to input coords (slave) in
    # normalized space. Our calibration M already maps master→slave in
    # pixel space (estimateAffine2D fits M such that M·master ≈ slave),
    # so theta is just M sandwiched between the pixel↔normalized
    # conversions — no inversion. Inverting M here was the GPU twin of
    # the missing WARP_INVERSE_MAP on the CPU path; both shifted slaves
    # by 2× the real offset instead of aligning them.
    theta_full = T_norm @ M @ T_denorm
    return theta_full[:2, :].astype(np.float32)


def _build_homography_grid(matrix, w, h, device):
    """Build a sampling grid for a homography transform on GPU."""
    import torch

    # Build pixel coordinate grid (output / master space)
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    ones = np.ones((h, w), dtype=np.float32)
    coords = np.stack([gx, gy, ones], axis=-1)  # (H, W, 3)

    # ``matrix`` already maps master→slave. For each output pixel
    # (master coord) we need the slave coord to sample from, so apply
    # ``matrix`` directly — no inversion. (The previous code inverted
    # it, which is the GPU twin of the missing WARP_INVERSE_MAP bug
    # on the CPU path and shifted slaves by 2× the real offset.)
    flat = coords.reshape(-1, 3)
    src = (matrix @ flat.T).T  # (N, 3)
    src = src[:, :2] / src[:, 2:3]  # perspective divide
    src = src.reshape(h, w, 2)

    # Normalize to [-1, 1] for grid_sample
    src[:, :, 0] = src[:, :, 0] / (w - 1) * 2 - 1
    src[:, :, 1] = src[:, :, 1] / (h - 1) * 2 - 1

    grid = torch.from_numpy(src).unsqueeze(0).to(device)
    return grid


# ---------------------------------------------------------------------------
# Band extraction
# ---------------------------------------------------------------------------

def extract_bands(aligned_frames, profile, include=None, order=None,
                   frame_metadata=None):
    """Extract and stack bands from aligned frames into a multi-band array.

    Parameters
    ----------
    aligned_frames : dict
        ``{serial: aligned_frame}`` — output of ``apply_alignment``.
    profile : AlignmentProfile
        Profile with ``layer_order`` band metadata.
    include : list of str, optional
        Band names to include. Default: all enabled bands.
    order : list of str, optional
        Band names specifying output order. Overrides profile ordering.
    frame_metadata : dict, optional
        ``{serial: metadata_dict}`` from ``_extract_metadata()``.
        When provided, enriches each band_info entry with per-camera
        exposure, gain, timestamp, camera_model, and fwhm.

    Returns
    -------
    bands : ndarray (N_bands, H, W)
        Stacked single-channel bands.
    band_info : list of dict
        Metadata for each band (name, wavelength, serial, and optionally
        exposure_time_us, gain_db, timestamp_ns, frame_id, camera_model,
        fwhm_nm).
    """
    frame_metadata = frame_metadata or {}

    # Build the band list from layer_order
    all_bands = []
    for entry in profile.layer_order:
        if not entry.get("enabled", True):
            continue
        serial = entry["serial"]
        if serial not in aligned_frames:
            continue
        frame = aligned_frames[serial]
        names = entry.get("band_names", [])
        wavelengths = entry.get("wavelengths_nm", [])
        channels = entry.get("channels", [])

        # Look up FWHM from band definitions
        model_str = profile.camera_models.get(serial, "")
        band_defs = _bands_for_model(model_str, serial) if model_str else []
        fwhm_by_ch = {bd["channel"]: bd.get("fwhm_nm", 0) for bd in band_defs}

        # Per-camera metadata
        cam_meta = frame_metadata.get(serial, {})

        for i, ch in enumerate(channels):
            bname = names[i] if i < len(names) else f"band_{i}"
            wl = wavelengths[i] if i < len(wavelengths) else 0

            if include is not None and bname not in include:
                continue

            if frame.ndim == 2:
                band = frame
            else:
                band = frame[:, :, ch]

            info = {
                "name": bname,
                "wavelength_nm": wl,
                "serial": serial,
                "data": band,
            }

            # Enrich with per-camera metadata if available
            if cam_meta:
                info["exposure_time_us"] = cam_meta.get("exposure_time_us")
                info["gain_db"] = cam_meta.get("gain_db")
                info["timestamp_ns"] = cam_meta.get("timestamp_ns")
                info["frame_id"] = cam_meta.get("frame_id")
                info["camera_model"] = cam_meta.get("camera_model", "")
            info["fwhm_nm"] = fwhm_by_ch.get(ch, 0)

            all_bands.append(info)

    # Apply custom ordering if specified
    if order is not None:
        name_to_band = {b["name"]: b for b in all_bands}
        ordered = []
        for bname in order:
            if bname in name_to_band:
                ordered.append(name_to_band.pop(bname))
        # Append any remaining bands not in the order list
        ordered.extend(name_to_band.values())
        all_bands = ordered
    else:
        # Default: sort by wavelength ascending
        all_bands.sort(key=lambda b: b["wavelength_nm"])

    if not all_bands:
        return np.empty((0, 0, 0), dtype=np.uint8), []

    band_arrays = [b["data"] for b in all_bands]
    band_info = []
    for b in all_bands:
        bi = {"name": b["name"], "wavelength_nm": b["wavelength_nm"],
              "serial": b["serial"]}
        for key in ("fwhm_nm", "exposure_time_us", "gain_db", "timestamp_ns",
                    "frame_id", "camera_model"):
            if key in b:
                bi[key] = b[key]
        band_info.append(bi)

    return np.stack(band_arrays, axis=0), band_info


# ---------------------------------------------------------------------------
# Multi-band TIFF export
# ---------------------------------------------------------------------------

def save_multiband_tiff(bands, profile, filepath, bit_depth=None,
                        band_info=None, vignette_corrected=False,
                        capture_timestamp_utc=None):
    """Save a multi-band array as a TIFF with Pix4D-compatible EXIF/XMP.

    Writes pixel data via tifffile, then stamps EXIF/XMP-Camera metadata
    via ExifTool (with ``pix4d.config``).  Falls back to tifffile-only
    metadata if ExifTool is unavailable.

    Parameters
    ----------
    bands : ndarray (N_bands, H, W)
        Band data from ``extract_bands``.
    profile : AlignmentProfile
        Profile for metadata.
    filepath : str or Path
        Output file path.
    bit_depth : int, optional
        Output bit depth (8, 12, or 16). Default: match input dtype.
    band_info : list of dict, optional
        Band metadata from ``extract_bands`` (enriched with fwhm,
        exposure, gain, camera_model when available).
    vignette_corrected : bool
        If True, sets ``XMP-Camera:IsNormalized=1`` in EXIF.
    capture_timestamp_utc : str, optional
        ISO-8601 UTC timestamp of the capture event.  If omitted, uses
        the current time.  Written as DateTimeOriginal with sub-second
        precision via SubSecTimeOriginal.
    """
    try:
        import tifffile
    except ImportError:
        # Fallback: save with OpenCV (no band metadata)
        if bands.ndim == 3 and bands.shape[0] <= 4:
            out = np.transpose(bands, (1, 2, 0))
            cv2.imwrite(str(filepath), out)
        else:
            p = Path(filepath)
            for i, band in enumerate(bands):
                band_path = p.with_name(f"{p.stem}_band{i}{p.suffix}")
                cv2.imwrite(str(band_path), band)
        return

    # Convert bit depth if needed
    if bit_depth is not None:
        if bit_depth == 16:
            if bands.dtype == np.uint8:
                bands = bands.astype(np.uint16) * 257
            elif bands.dtype != np.uint16:
                bands = bands.astype(np.uint16)
        elif bit_depth == 8:
            if bands.dtype == np.uint16:
                bands = (bands / 257).astype(np.uint8)
            elif bands.dtype != np.uint8:
                bands = bands.astype(np.uint8)

    # Build description with band names, wavelengths, and per-band metadata
    desc_lines = [f"AlignmentProfile: {profile.name}"]
    if band_info:
        for i, bi in enumerate(band_info):
            line = (f"Band {i}: {bi['name']} ({bi['wavelength_nm']} nm) "
                    f"[camera {bi['serial']}]")
            exp = bi.get("exposure_time_us")
            gain = bi.get("gain_db")
            if exp is not None:
                line += f" exp={exp}us"
            if gain is not None:
                line += f" gain={gain}dB"
            desc_lines.append(line)

    description = "\n".join(desc_lines)

    p = Path(filepath)
    p.parent.mkdir(parents=True, exist_ok=True)

    # Save pixel data via tifffile
    metadata = {}
    if band_info:
        metadata["band_names"] = [bi["name"] for bi in band_info]
        metadata["wavelengths_nm"] = [bi["wavelength_nm"] for bi in band_info]

    tifffile.imwrite(
        str(p),
        bands,
        photometric="minisblack",
        description=description,
        metadata=metadata,
    )

    # Stamp EXIF/XMP-Camera metadata via ExifTool
    _write_exiftool_metadata(
        p, profile, band_info, vignette_corrected, multiband=True,
        capture_timestamp_utc=capture_timestamp_utc)


def save_per_band_tiffs(bands, profile, filepath_prefix, bit_depth=None,
                        band_info=None, vignette_corrected=False,
                        capture_timestamp_utc=None):
    """Save each band as a separate single-band TIFF with per-band EXIF.

    Naming: ``{prefix}_band{i}_{bandname}_{wavelength}nm.tif``

    Parameters
    ----------
    bands : ndarray (N_bands, H, W)
        Band data from ``extract_bands``.
    profile : AlignmentProfile
        Profile for metadata.
    filepath_prefix : str or Path
        Output path prefix (directory + filename stem).
    bit_depth : int, optional
        Output bit depth (8, 12, or 16). Default: match input dtype.
    band_info : list of dict, optional
        Band metadata from ``extract_bands``.
    vignette_corrected : bool
        If True, sets ``XMP-Camera:IsNormalized=1`` in each file.
    capture_timestamp_utc : str, optional
        ISO-8601 UTC timestamp of the capture event.  If omitted, uses
        the current time.  Written as DateTimeOriginal with sub-second
        precision via SubSecTimeOriginal.

    Returns
    -------
    list of Path
        Paths to saved per-band TIFF files.
    """
    try:
        import tifffile
    except ImportError:
        return []

    prefix = Path(filepath_prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    saved = []

    for i in range(bands.shape[0]):
        band_data = bands[i]
        bi = band_info[i] if band_info and i < len(band_info) else {}
        bname = bi.get("name", f"band{i}")
        wl = bi.get("wavelength_nm", 0)

        # Convert bit depth
        out = band_data
        if bit_depth is not None:
            if bit_depth == 16:
                if out.dtype == np.uint8:
                    out = out.astype(np.uint16) * 257
                elif out.dtype != np.uint16:
                    out = out.astype(np.uint16)
            elif bit_depth == 8:
                if out.dtype == np.uint16:
                    out = (out / 257).astype(np.uint8)
                elif out.dtype != np.uint8:
                    out = out.astype(np.uint8)

        fname = f"{prefix.stem}_band{i}_{bname}_{wl}nm.tif"
        fpath = prefix.parent / fname

        tifffile.imwrite(str(fpath), out, photometric="minisblack")

        # Write per-band EXIF/XMP
        _write_exiftool_metadata(
            fpath, profile, [bi] if bi else None,
            vignette_corrected, multiband=False, band_index=i,
            capture_timestamp_utc=capture_timestamp_utc)
        saved.append(fpath)

    return saved


# ---------------------------------------------------------------------------
# ExifTool integration for Pix4D-compatible metadata
# ---------------------------------------------------------------------------

def _find_exiftool():
    """Find the ExifTool binary.

    Search order:
    1. System PATH (``shutil.which("exiftool")``)
    2. Sibling ``mapirlab/mip/exiftool.exe`` (bundled with Chloros)

    Returns
    -------
    str or None
        Path to exiftool binary, or None if not found.
    """
    et = shutil.which("exiftool")
    if et:
        return et
    # Check bundled location relative to this repo's parent
    bundled = (Path(__file__).resolve().parent.parent.parent
               / "mapirlab" / "mip" / "exiftool.exe")
    if bundled.exists():
        return str(bundled)
    return None


def _find_pix4d_config():
    """Find the pix4d.config file.

    Search order:
    1. Sibling ``mapirlab/pix4d.config``
    2. ``lucid/pix4d.config`` (local copy)

    Returns
    -------
    str or None
        Path to pix4d.config, or None if not found.
    """
    repo_root = Path(__file__).resolve().parent.parent
    # Check sibling mapirlab repo
    candidate = repo_root.parent / "mapirlab" / "pix4d.config"
    if candidate.exists():
        return str(candidate)
    # Check local repo
    candidate = repo_root / "pix4d.config"
    if candidate.exists():
        return str(candidate)
    return None


def _run_exiftool(args_list, filepath):
    """Run ExifTool with pix4d.config on a file.

    Parameters
    ----------
    args_list : list of str
        ExifTool tag arguments (e.g. ``["-Make=MAPIR", "-Model=LATTICE"]``).
    filepath : str or Path
        Target file.

    Returns
    -------
    bool
        True if ExifTool ran successfully.
    """
    et = _find_exiftool()
    if not et:
        return False

    cmd = [et]
    config = _find_pix4d_config()
    if config:
        cmd.extend(["-config", config])
    cmd.extend(["-overwrite_original", "-m", "-n"])
    cmd.extend(args_list)
    cmd.append(str(filepath))

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30)
        return result.returncode == 0
    except Exception:
        return False


def _get_lens_key(profile):
    """Determine the lens key from profile camera models.

    Returns the lens code (e.g. "L41", "L87") from the first parseable
    camera model, or None.
    """
    for serial in profile.camera_serials:
        model_str = profile.camera_models.get(serial, "")
        if not model_str:
            continue
        try:
            info = parse_model_string(model_str)
            return info.lens
        except ValueError:
            continue
    return None


def _write_exiftool_metadata(filepath, profile, band_info,
                             vignette_corrected, multiband=True,
                             band_index=0, capture_timestamp_utc=None):
    """Write EXIF/XMP-Camera metadata via ExifTool.

    Non-fatal: prints a warning and returns if ExifTool is unavailable.

    Parameters
    ----------
    capture_timestamp_utc : str, optional
        ISO-8601 UTC capture timestamp.  When provided (or by default,
        current UTC time), DateTimeOriginal and SubSecTimeOriginal are
        written with microsecond precision.
    """
    if not band_info:
        return

    et = _find_exiftool()
    if not et:
        return

    # Derive Model tag — use individual camera model (full LATT- name).
    # For per-band TIFFs: the specific camera that captured this band.
    # For multiband stacked TIFFs: first camera model (rig is identified
    # via RigName, not Model — matches MicaSense/Parrot convention).
    if multiband:
        first_cm = ""
        first_serial = ""
        for bi in band_info:
            cm = bi.get("camera_model", "")
            if cm and not first_cm:
                first_cm = cm
            s = bi.get("serial", "")
            if s and not first_serial:
                first_serial = s
            if first_cm and first_serial:
                break
        if not first_cm:
            for m in profile.camera_models.values():
                if m:
                    first_cm = m
                    break
        if not first_serial and profile.camera_serials:
            first_serial = profile.camera_serials[0]
        model_tag = format_display_model(first_cm) if first_cm else "LATTICE"
        serial_tag = first_serial
    else:
        bi0 = band_info[0] if band_info else {}
        cm = bi0.get("camera_model", "")
        serial_tag = bi0.get("serial", "")
        if not cm:
            cm = profile.camera_models.get(serial_tag, "")
        model_tag = format_display_model(cm) if cm else "LATTICE"

    args = [
        "-Make=MAPIR",
        f"-Model={model_tag}",
        "-XMP-Camera:RigName=LATTICE",
    ]

    # SerialNumber — identifies which camera captured this image
    if serial_tag:
        args.append(f"-SerialNumber={serial_tag}")

    # Timestamp with sub-second precision (microseconds).
    # Default to current UTC time if caller doesn't provide one.
    ts_str = capture_timestamp_utc
    if ts_str is None:
        ts_str = datetime.now(timezone.utc).isoformat()
    try:
        dt = datetime.fromisoformat(ts_str)
    except (ValueError, TypeError):
        dt = None
    if dt:
        exif_ts = dt.strftime("%Y:%m:%d %H:%M:%S")
        subsec = f"{dt.microsecond:06d}"
        args.extend([
            f"-DateTimeOriginal={exif_ts}",
            f"-SubSecTimeOriginal={subsec}",
            f"-DateTimeDigitized={exif_ts}",
            f"-SubSecTimeDigitized={subsec}",
            f"-CreateDate={exif_ts}",
            f"-SubSecTime={subsec}",
        ])

    # Band metadata (sequences for multiband, single for per-band)
    if multiband:
        for bi in band_info:
            args.append(f"-XMP-Camera:BandName={bi.get('name', '')}")
            args.append(
                f"-XMP-Camera:CentralWavelength={bi.get('wavelength_nm', 0)}")
            fwhm = bi.get("fwhm_nm", 0)
            args.append(f"-XMP-Camera:WavelengthFWHM={fwhm}")
    else:
        bi = band_info[0] if band_info else {}
        args.append(f"-XMP-Camera:BandName={bi.get('name', '')}")
        args.append(
            f"-XMP-Camera:CentralWavelength={bi.get('wavelength_nm', 0)}")
        fwhm = bi.get("fwhm_nm", 0)
        args.append(f"-XMP-Camera:WavelengthFWHM={fwhm}")
        args.append(f"-XMP-Camera:RigCameraIndex={band_index}")

        # Per-band ExposureTime (convert us to seconds)
        exp_us = bi.get("exposure_time_us")
        if exp_us is not None:
            args.append(f"-ExposureTime={exp_us / 1_000_000.0}")

    # Lens calibration
    lens_key = _get_lens_key(profile)
    lens_cal = _LATTICE_PIX4D.get(lens_key) if lens_key else None
    if lens_cal:
        args.append(
            f"-XMP-Camera:PerspectiveFocalLength={lens_cal['focal_mm']}")
        args.append(
            f"-XMP-Camera:PrincipalPoint={lens_cal['principal']}")
        args.append(
            f"-XMP-Camera:PerspectiveDistortion={lens_cal['distortion']}")
        args.append("-XMP-Camera:ModelType=perspective")
        # FocalLength as rational
        focal_um = int(lens_cal["focal_mm"] * 10_000_000)
        args.append(f"-FocalLength={focal_um}/10000000")

    # Focal plane resolution
    args.append(f"-FocalPlaneXResolution={_IMX265_PIXELS_PER_MM}")
    args.append(f"-FocalPlaneYResolution={_IMX265_PIXELS_PER_MM}")
    args.append("-FocalPlaneResolutionUnit=4")

    # Sensor bit depth
    args.append("-XMP-Camera:SensorBitDepth=12")

    # Vignette / normalization
    if vignette_corrected:
        args.append("-XMP-Camera:IsNormalized=1")
    else:
        args.append("-XMP-Camera:IsNormalized=0")

    _run_exiftool(args, filepath)


# ---------------------------------------------------------------------------
# Vignette correction for alignment pipeline
# ---------------------------------------------------------------------------

def apply_vignette_corrections(frame_dict, vignette_maps):
    """Apply per-camera flat-field (vignette) correction to a frame group.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: (frame, meta)}`` or ``{serial: frame}``.
    vignette_maps : dict
        ``{serial: vignette_inv_ndarray_or_None}`` from
        ``calibration.load_vignette_map_array()``.

    Returns
    -------
    dict
        Corrected frame_dict in the same format as input.
    """
    corrected = {}
    for serial, val in frame_dict.items():
        vig = vignette_maps.get(serial)
        if vig is None:
            corrected[serial] = val
            continue

        if isinstance(val, tuple):
            frame, meta = val
        else:
            frame, meta = val, None

        # Resize vignette map if needed
        h, w = frame.shape[:2]
        vh, vw = vig.shape[:2]
        if h != vh or w != vw:
            vig = cv2.resize(vig, (w, h), interpolation=cv2.INTER_LINEAR)

        # Handle mono (2D) vs color (3D) frames
        if frame.ndim == 2 and vig.ndim == 3:
            # Mono frame with BGR vignette map: average channels
            vig_mono = np.mean(vig, axis=2)
            result = frame.astype(np.float32) * vig_mono
        else:
            result = frame.astype(np.float32) * vig

        # Clip to dtype range
        if frame.dtype == np.uint8:
            result = np.clip(result, 0, 255).astype(np.uint8)
        elif frame.dtype == np.uint16:
            result = np.clip(result, 0, 65535).astype(np.uint16)
        else:
            result = result.astype(frame.dtype)

        if meta is not None:
            corrected[serial] = (result, meta)
        else:
            corrected[serial] = result

    return corrected


# ---------------------------------------------------------------------------
# Validation and diagnostics
# ---------------------------------------------------------------------------

def validate_profile(profile, frame_dict):
    """Check that a profile matches a frame group.

    Parameters
    ----------
    profile : AlignmentProfile
        Profile to validate.
    frame_dict : dict
        ``{serial: frame}`` or ``{serial: (frame, meta)}``.

    Returns
    -------
    list of str
        Warning messages. Empty if all checks pass.
    """
    warnings = []

    profile_serials = set(profile.camera_serials)
    frame_serials = set(frame_dict.keys())

    missing = profile_serials - frame_serials
    if missing:
        warnings.append(f"Missing cameras: {', '.join(sorted(missing))}")

    extra = frame_serials - profile_serials
    if extra:
        warnings.append(f"Extra cameras not in profile: {', '.join(sorted(extra))}")

    # Check resolution
    for serial in frame_serials & profile_serials:
        frame = _extract_frame(frame_dict[serial])
        fh, fw = frame.shape[:2]
        pw, ph = profile.sensor_resolution
        if fw != pw or fh != ph:
            warnings.append(
                f"Resolution mismatch for {serial}: "
                f"frame {fw}x{fh} vs profile {pw}x{ph}")

    return warnings


def diagnostic_overlay(frame_dict, profile, alpha=0.5):
    """Create a colored overlay image for visual alignment verification.

    Each camera's aligned frame is tinted a different color and
    composited into a single visualization image.

    Parameters
    ----------
    frame_dict : dict
        ``{serial: frame_bgr}`` or ``{serial: (frame_bgr, meta)}``.
    profile : AlignmentProfile
        Alignment profile.
    alpha : float
        Blend factor per camera.

    Returns
    -------
    overlay : ndarray (H, W, 3)
        BGR overlay image.
    """
    aligned = apply_alignment(frame_dict, profile, crop=True)

    # Color tints for up to 12 cameras
    tints = [
        (0, 0, 255),    # red
        (0, 255, 0),    # green
        (255, 0, 0),    # blue
        (0, 255, 255),  # yellow
        (255, 0, 255),  # magenta
        (255, 255, 0),  # cyan
        (128, 0, 255),  # orange
        (0, 128, 255),  # gold
        (255, 128, 0),  # sky blue
        (128, 255, 0),  # spring green
        (0, 128, 128),  # olive
        (128, 0, 128),  # purple
    ]

    overlay = None
    n = len(aligned)

    for i, (serial, frame) in enumerate(aligned.items()):
        gray = _to_gray(frame).astype(np.float32)
        tint = tints[i % len(tints)]
        colored = np.zeros_like(frame, dtype=np.float32)
        for c in range(3):
            colored[:, :, c] = gray * (tint[c] / 255.0)

        if overlay is None:
            overlay = colored
        else:
            overlay = overlay + colored

    if overlay is not None:
        # Normalize
        overlay = overlay / n
        overlay = np.clip(overlay, 0, 255).astype(np.uint8)
    else:
        overlay = np.zeros((100, 100, 3), dtype=np.uint8)

    return overlay
