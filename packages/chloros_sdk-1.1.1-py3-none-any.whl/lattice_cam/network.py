"""Cross-platform network topology detection for LATTICE cameras.

Detects physical ethernet interfaces used for GigE Vision cameras and
counts the number of distinct physical ports carrying camera traffic.
This information drives adaptive PTP — PTP should only be enabled when
cameras span multiple physical links.

Supports Linux (sysfs) and Windows (ipconfig).
"""

import logging
import platform
import re
import subprocess
from pathlib import Path
from typing import List, Optional

log = logging.getLogger(__name__)

_SYSTEM = platform.system()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_camera_interfaces(exclude_macs: Optional[List[str]] = None) -> List[str]:
    """Auto-detect network interfaces that carry camera traffic.

    Camera interfaces are physical ethernet ports with only link-local
    (169.254.x.x) IPs or no IP at all.  Interfaces with routable IPs
    are assumed to be management / internet ports.

    Parameters
    ----------
    exclude_macs : list of str, optional
        MAC addresses to explicitly exclude.

    Returns
    -------
    list of str
        Interface names (Linux) or adapter descriptions (Windows),
        sorted deterministically.
    """
    if _SYSTEM == "Linux":
        return _detect_interfaces_linux(exclude_macs)
    if _SYSTEM == "Windows":
        return _detect_interfaces_windows(exclude_macs)
    log.warning("Unsupported platform %s for network detection", _SYSTEM)
    return []


def count_active_camera_ports() -> int:
    """Count distinct physical ports with active camera links.

    Used for adaptive PTP:
    - 1 port  : cameras share a switch — PTP adds jitter, disable it
    - 2+ ports: cameras on separate links — PTP helps with timestamps

    Returns
    -------
    int
        Number of active ports (0 if detection fails).
    """
    if _SYSTEM == "Linux":
        return _count_ports_linux()
    if _SYSTEM == "Windows":
        return _count_ports_windows()
    log.warning("Unsupported platform %s for port counting", _SYSTEM)
    return 0


def detect_daq_sensors_on_lan(timeout_s: float = 2.0) -> bool:
    """Return True if any `_daq-e._tcp.local.` is advertising on the LAN.

    Used by the adaptive-PTP heuristic: on a single-switch deployment we
    normally disable PTP (M8 cable already syncs exposures and PTP through
    a non-PTP-aware switch adds jitter), but a DAQ-E light sensor has no
    M8 cable and needs PTP to align with camera timestamps.  When one is
    present, keep PTP enabled.

    Implementation is best-effort: we use the `zeroconf` package if it
    is available (bundled with Chloros), but gracefully return False if
    not — the caller's decision just falls back to the camera-only rule.

    A 2-second browse is short enough not to noticeably delay sync
    configuration, but long enough to catch devices already on the LAN.
    """
    try:
        from zeroconf import Zeroconf, ServiceBrowser  # type: ignore
    except Exception:
        return False

    found = []

    class _Listener:
        def add_service(self, zc, type_, name):
            found.append(name)
        def update_service(self, zc, type_, name):
            pass
        def remove_service(self, zc, type_, name):
            pass

    import time as _time
    zc = Zeroconf()
    try:
        ServiceBrowser(zc, "_daq-e._tcp.local.", _Listener())
        # Poll briefly.  Zeroconf's ServiceBrowser runs on its own thread;
        # sleeping the caller is simplest and the work we skip during this
        # window is negligible compared to camera bring-up time.
        deadline = _time.monotonic() + timeout_s
        while _time.monotonic() < deadline and not found:
            _time.sleep(0.1)
    except Exception as e:
        log.debug("detect_daq_sensors_on_lan: zeroconf error %s", e)
    finally:
        try:
            zc.close()
        except Exception:
            pass
    return bool(found)


# ---------------------------------------------------------------------------
# Linux implementation (sysfs)
# ---------------------------------------------------------------------------

def _is_bridge_slave_linux(iface: str) -> Optional[str]:
    """Return the bridge name if *iface* is a bridge slave, else None."""
    master_path = Path(f"/sys/class/net/{iface}/master")
    if master_path.is_symlink() or master_path.exists():
        try:
            return master_path.resolve().name
        except OSError:
            pass
    return None


def _is_bridge_linux(iface: str) -> bool:
    """Return True if *iface* is a Linux bridge."""
    return Path(f"/sys/class/net/{iface}/bridge").is_dir()


def _has_routable_ip_linux(iface: str) -> bool:
    """Check if an interface has a non-link-local IPv4 address."""
    try:
        result = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", iface],
            capture_output=True, text=True, timeout=5, check=False,
        )
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            for i, token in enumerate(parts):
                if token == "inet" and i + 1 < len(parts):
                    ip = parts[i + 1].split("/")[0]
                    if not ip.startswith("169.254.") and ip != "127.0.0.1":
                        return True
        return False
    except Exception:
        return False


def _detect_interfaces_linux(exclude_macs: Optional[List[str]] = None) -> List[str]:
    """Linux: detect camera interfaces via /sys/class/net."""
    exclude = {m.lower() for m in (exclude_macs or [])}
    sysnet = Path("/sys/class/net")

    if not sysnet.exists():
        log.warning("/sys/class/net not found — cannot auto-detect interfaces")
        return []

    candidates = []
    bridge_slaves = {}

    for iface_dir in sorted(sysnet.iterdir()):
        name = iface_dir.name

        if name == "lo":
            continue
        if (iface_dir / "wireless").exists() or name.startswith("wlan"):
            continue
        if name.startswith(("veth", "docker", "virbr", "vnet")):
            continue

        # Must be ethernet (ARPHRD_ETHER = 1)
        try:
            iface_type = (iface_dir / "type").read_text().strip()
            if iface_type != "1":
                continue
        except (OSError, ValueError):
            continue

        try:
            mac = (iface_dir / "address").read_text().strip().lower()
        except OSError:
            continue

        if mac in ("00:00:00:00:00:00", ""):
            continue
        if mac in exclude:
            continue

        if _has_routable_ip_linux(name):
            continue

        bridge_master = _is_bridge_slave_linux(name)
        if bridge_master:
            bridge_slaves.setdefault(bridge_master, []).append(name)
            continue

        if _is_bridge_linux(name):
            continue

        candidates.append((mac, name))

    # Camera bridges — use bridge instead of individual slaves
    for bridge_name, slaves in bridge_slaves.items():
        if not _has_routable_ip_linux(bridge_name):
            try:
                mac = (sysnet / bridge_name / "address").read_text().strip().lower()
            except OSError:
                mac = "ff:ff:ff:ff:ff:ff"
            candidates.append((mac, bridge_name))
            log.info("Camera bridge %s detected (slaves: %s)",
                     bridge_name, ", ".join(slaves))

    candidates.sort()
    interfaces = [name for _, name in candidates]

    if interfaces:
        log.info("Auto-detected %d camera interface(s): %s",
                 len(interfaces), ", ".join(interfaces))
    else:
        log.warning("No camera interfaces auto-detected")

    return interfaces


def _count_ports_linux() -> int:
    """Linux: count active camera ports via sysfs carrier detection."""
    sysnet = Path("/sys/class/net")
    if not sysnet.exists():
        return 0

    # Check for camera bridges first
    for iface_dir in sorted(sysnet.iterdir()):
        name = iface_dir.name
        if not _is_bridge_linux(name):
            continue
        if _has_routable_ip_linux(name):
            continue

        brif_path = sysnet / name / "brif"
        if not brif_path.is_dir():
            continue

        active = 0
        for slave_entry in sorted(brif_path.iterdir()):
            try:
                carrier = (sysnet / slave_entry.name / "carrier").read_text().strip()
                if carrier == "1":
                    active += 1
            except OSError:
                pass

        log.info("Camera bridge %s: %d slave port(s) with carrier", name, active)
        return active

    # No camera bridge — count standalone camera interfaces with carrier
    interfaces = _detect_interfaces_linux()
    active = 0
    for iface in interfaces:
        try:
            carrier = (sysnet / iface / "carrier").read_text().strip()
            if carrier == "1":
                active += 1
        except OSError:
            pass

    return active


# ---------------------------------------------------------------------------
# Windows implementation (ipconfig)
# ---------------------------------------------------------------------------

def _parse_ipconfig() -> List[dict]:
    """Parse ``ipconfig /all`` into a list of adapter dicts.

    Each dict has keys: name, description, mac, ipv4_addresses (list of str),
    media_state (str or None).
    """
    try:
        result = subprocess.run(
            ["ipconfig", "/all"],
            capture_output=True, text=True, timeout=10, check=False,
        )
        if result.returncode != 0:
            return []
    except Exception:
        return []

    adapters = []
    current = None

    for line in result.stdout.split("\n"):
        line = line.rstrip()

        # New adapter section header
        # e.g. "Ethernet adapter Ethernet 2:"
        header_match = re.match(r'^(\S.+?)\s+adapter\s+(.+):$', line)
        if header_match:
            if current is not None:
                adapters.append(current)
            current = {
                "type": header_match.group(1),
                "name": header_match.group(2),
                "description": "",
                "mac": "",
                "ipv4_addresses": [],
                "media_state": None,
            }
            continue

        if current is None:
            continue

        stripped = line.strip()

        # Description
        desc_match = re.match(r'Description[\s.]*:\s*(.+)', stripped)
        if desc_match:
            current["description"] = desc_match.group(1).strip()

        # Physical Address (MAC)
        mac_match = re.match(r'Physical Address[\s.]*:\s*([0-9A-Fa-f-]+)', stripped)
        if mac_match:
            current["mac"] = mac_match.group(1).replace("-", ":").lower()

        # IPv4 Address
        ip_match = re.match(
            r'(?:IPv4 Address|Autoconfiguration IPv4 Address)[\s.]*:\s*'
            r'(\d+\.\d+\.\d+\.\d+)',
            stripped,
        )
        if ip_match:
            current["ipv4_addresses"].append(ip_match.group(1))

        # Media State (disconnected)
        media_match = re.match(r'Media State[\s.]*:\s*(.+)', stripped)
        if media_match:
            current["media_state"] = media_match.group(1).strip()

    if current is not None:
        adapters.append(current)

    return adapters


def _is_camera_adapter_windows(adapter: dict) -> bool:
    """Determine if an adapter is a camera interface.

    Camera adapters have only link-local (169.254.x.x) IPs or no IP.
    Wireless and tunnel adapters are excluded.
    """
    # Skip non-Ethernet adapters
    if adapter["type"].lower() not in ("ethernet",):
        return False

    # Skip disconnected adapters
    if adapter.get("media_state") and "disconnected" in adapter["media_state"].lower():
        return False

    # Must have a MAC address
    if not adapter["mac"]:
        return False

    # Skip adapters with routable IPs
    for ip in adapter["ipv4_addresses"]:
        if not ip.startswith("169.254.") and ip != "127.0.0.1":
            return False

    # Skip known virtual adapters
    desc = adapter.get("description", "").lower()
    virtual_keywords = ("virtual", "vpn", "loopback", "hyper-v", "vmware",
                        "vbox", "docker", "wsl")
    if any(kw in desc for kw in virtual_keywords):
        return False

    return True


def _detect_interfaces_windows(exclude_macs: Optional[List[str]] = None) -> List[str]:
    """Windows: detect camera interfaces via ipconfig."""
    exclude = {m.lower() for m in (exclude_macs or [])}
    adapters = _parse_ipconfig()

    camera_adapters = []
    for adapter in adapters:
        if adapter["mac"] in exclude:
            continue
        if _is_camera_adapter_windows(adapter):
            camera_adapters.append(adapter)

    # Sort by MAC for deterministic ordering
    camera_adapters.sort(key=lambda a: a["mac"])
    names = [a["name"] for a in camera_adapters]

    if names:
        log.info("Auto-detected %d camera adapter(s): %s",
                 len(names), ", ".join(names))
    else:
        log.warning("No camera adapters auto-detected")

    return names


def _count_ports_windows() -> int:
    """Windows: count active camera adapters.

    Each connected Ethernet adapter with only link-local IPs is counted
    as a separate camera port.
    """
    adapters = _detect_interfaces_windows()
    count = len(adapters)
    if count:
        log.info("Active camera port(s): %d", count)
    return count
