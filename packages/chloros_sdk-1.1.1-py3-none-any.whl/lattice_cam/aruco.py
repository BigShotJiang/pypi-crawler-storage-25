"""ArUco marker detection and MAPIR calibration target overlay.

Detects ArUco markers from DICT_4X4_1000 and draws panel geometry overlays
matching the Chloros calibration target visualization.  Uses a homography
computed from the 4 marker corners (with sub-pixel refinement) for
perspective-correct projection, plus a center-marker correction that shifts
all panels to match the actual target center visible in the image.
"""

import cv2
import numpy as np

# ---------------------------------------------------------------------------
# ArUco detector setup (cached singleton)
# ---------------------------------------------------------------------------

ARUCO_DICT = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_1000)

_detector_params = cv2.aruco.DetectorParameters()
_detector_params.adaptiveThreshWinSizeMin = 3
_detector_params.adaptiveThreshWinSizeMax = 13
_detector_params.adaptiveThreshWinSizeStep = 10
_detector_params.minMarkerPerimeterRate = 0.04
_detector_params.maxMarkerPerimeterRate = 2.0
_detector_params.perspectiveRemovePixelPerCell = 2

# OpenCV 4.7+ uses ArucoDetector class; older versions use free functions
try:
    _DETECTOR = cv2.aruco.ArucoDetector(ARUCO_DICT, _detector_params)
    _USE_NEW_API = True
except AttributeError:
    _DETECTOR = None
    _USE_NEW_API = False

# ---------------------------------------------------------------------------
# MAPIR calibration target dimensions (from Chloros Calibration_Target.py)
# ---------------------------------------------------------------------------

TARGET_DIMS = {
    13:  {'target_size': 300,    'target_offset': 500,   'sizemult': 1.6,  'aspect': 1.25},
    793: {'target_size': 222.25, 'target_offset': 260,   'sizemult': 1,    'aspect': 1},
    830: {'target_size': 76.2,   'target_offset': 114.3, 'sizemult': 1.25, 'aspect': 1},
    788: {'target_size': 188,    'target_offset': 287,   'sizemult': 1.25, 'aspect': 1},
    47:  {'target_size': 37.5,   'target_offset': 63,    'sizemult': 1.25, 'aspect': 1},
    9:   {'target_size': 76.2,   'target_offset': 137.6, 'sizemult': 1.25, 'aspect': 1},
    685: {'target_size': 76.2,   'target_offset': 137.6, 'sizemult': 1.25, 'aspect': 1},
    352: {'target_size': 188,    'target_offset': 287,   'sizemult': 1.25, 'aspect': 1},
}

# T4P targets with a white registration dot between panels
# outer_diameter / inner_diameter in mm (black ring / white dot)
CENTER_MARKER_TARGETS = {
    47:  {'outer_diameter': 12.0, 'inner_diameter': 10.0},
    685: {'outer_diameter': 12.0, 'inner_diameter': 10.0},
    352: {'outer_diameter': 12.0, 'inner_diameter': 10.0},
}

POLY_SIZE = 0.75  # panel polygon size relative to panel spacing
_DETECT_SCALE = 0.5  # downscale factor for detection (0.5 = half res, 4x faster)
_DETECT_INTERVAL = 3  # run detection every N frames, reuse cached results between

# cornerSubPix criteria
_SUBPIX_CRITERIA = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.01)
_SUBPIX_WIN = (5, 5)
_SUBPIX_DEAD = (-1, -1)

# Frame-skip state
_frame_counter = 0
_cached_targets = []


def _project_mm_to_px(pts_mm, H):
    """Project Nx2 mm-coordinates through homography *H* to pixel coords."""
    pts = np.asarray(pts_mm, dtype=np.float32).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(pts, H).reshape(-1, 2)


def _detect_center_offset(gray, predicted_center, search_radius):
    """Detect the white registration dot and return the pixel offset from
    *predicted_center* to the detected dot centre.

    Returns (dx, dy) as int or (0, 0) if detection fails.
    """
    h, w = gray.shape[:2]
    cx, cy = int(round(predicted_center[0])), int(round(predicted_center[1]))
    r = int(round(search_radius))

    y0, y1 = max(0, cy - r), min(h, cy + r)
    x0, x1 = max(0, cx - r), min(w, cx + r)
    if y1 - y0 < 10 or x1 - x0 < 10:
        return 0, 0

    roi = gray[y0:y1, x0:x1]

    # Threshold for bright blob (white dot on dark panel junction)
    mean_val = float(roi.mean())
    std_val = float(roi.std())
    thresh_val = min(255, mean_val + 0.5 * std_val)
    _, mask = cv2.threshold(roi, thresh_val, 255, cv2.THRESH_BINARY)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return 0, 0

    # Pick the most circular contour closest to the ROI centre
    roi_cx = (x1 - x0) / 2.0
    roi_cy = (y1 - y0) / 2.0
    best = None
    best_score = float('inf')

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < 4:
            continue
        perim = cv2.arcLength(cnt, True)
        if perim == 0:
            continue
        circ = 4.0 * np.pi * area / (perim * perim)
        if circ < 0.5:
            continue
        M = cv2.moments(cnt)
        if M['m00'] == 0:
            continue
        bx = M['m10'] / M['m00']
        by = M['m01'] / M['m00']
        dist = np.hypot(bx - roi_cx, by - roi_cy)
        score = dist - circ * 20  # prefer close + circular
        if score < best_score:
            best_score = score
            best = (bx, by)

    if best is None:
        return 0, 0

    # Offset in full-frame coords
    dx = int(round(best[0] + x0 - cx))
    dy = int(round(best[1] + y0 - cy))
    return dx, dy


def detect(frame):
    """Detect ArUco markers and compute panel geometry for known targets.

    Runs detection on a downscaled grayscale image for speed, refines
    corners to sub-pixel accuracy on the full-resolution grayscale, and
    caches results across frames (re-detects every ``_DETECT_INTERVAL``
    frames).  Panel positions are projected using a perspective homography
    and optionally corrected by the white center-marker dot.

    Parameters
    ----------
    frame : ndarray
        BGR display frame.

    Returns
    -------
    list[dict]
        Each dict has keys: id, corners, center, marker_edge,
        panel_centers, panel_polys.
    """
    global _frame_counter, _cached_targets
    _frame_counter += 1
    if _frame_counter % _DETECT_INTERVAL != 1 and _cached_targets is not None:
        return _cached_targets

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect on downscaled image for speed
    h, w = gray.shape[:2]
    small = cv2.resize(gray, (int(w * _DETECT_SCALE), int(h * _DETECT_SCALE)),
                       interpolation=cv2.INTER_AREA)

    if _USE_NEW_API:
        corners_list, ids, _ = _DETECTOR.detectMarkers(small)
    else:
        corners_list, ids, _ = cv2.aruco.detectMarkers(
            small, ARUCO_DICT, parameters=_detector_params)

    if ids is None:
        _cached_targets = []
        return _cached_targets

    inv_scale = 1.0 / _DETECT_SCALE
    targets = []

    for i, marker_id in enumerate(ids.flatten()):
        if marker_id not in TARGET_DIMS:
            continue

        dims = TARGET_DIMS[marker_id]

        # Scale corners back to full display resolution, then refine
        corners = corners_list[i].reshape(4, 2) * inv_scale
        corners_subpix = corners.copy().astype(np.float32)
        cv2.cornerSubPix(gray, corners_subpix,
                         _SUBPIX_WIN, _SUBPIX_DEAD, _SUBPIX_CRITERIA)
        corners = corners_subpix

        # Average edge length in pixels (for line-thickness scaling)
        edge_lengths = [np.linalg.norm(corners[(j + 1) % 4] - corners[j])
                        for j in range(4)]
        avg_edge = float(np.mean(edge_lengths))
        center = corners.mean(axis=0)

        # ---------------------------------------------------------------
        # Homography: mm (marker-centred XY plane) -> image pixels
        #
        # Corner order: TL, TR, BR, BL
        # Convention: X right, Y down (matching image coords)
        # ---------------------------------------------------------------
        s = dims['target_size']
        src = np.array([
            [-s / 2, -s / 2],
            [ s / 2, -s / 2],
            [ s / 2,  s / 2],
            [-s / 2,  s / 2],
        ], dtype=np.float32)

        H = cv2.getPerspectiveTransform(src, corners.astype(np.float32))

        # ---------------------------------------------------------------
        # Panel geometry in mm (same convention as Chloros)
        # ---------------------------------------------------------------
        target_offset = dims['target_offset']
        sm = dims['sizemult']
        asp = dims['aspect']
        unitlength = s / 2
        rel = unitlength / 2       # target_size / 4
        half = rel * sm * POLY_SIZE  # polygon half-size (mm)

        panel_offsets = [
            (-target_offset + rel * sm,  rel * asp * sm),
            (-target_offset + rel * sm, -rel * asp * sm),
            (-target_offset - rel * sm, -rel * asp * sm),
            (-target_offset - rel * sm,  rel * asp * sm),
        ]

        # Project panel centres and polygon corners
        panel_centers_2d = _project_mm_to_px(panel_offsets, H)

        panel_polys = []
        for px, py in panel_offsets:
            poly_mm = [
                [px - half, py - half * asp],
                [px + half, py - half * asp],
                [px + half, py + half * asp],
                [px - half, py + half * asp],
            ]
            poly_px = _project_mm_to_px(poly_mm, H).astype(np.int32)
            panel_polys.append(poly_px)

        # ---------------------------------------------------------------
        # Center-marker correction: detect white dot (T4P targets) or
        # use Harris corner peak to shift panels onto true centre.
        # ---------------------------------------------------------------
        # Predicted panel-group centre in pixels
        group_center_mm = [(-target_offset, 0)]
        group_center_px = _project_mm_to_px(group_center_mm, H)[0]
        search_r = avg_edge * 0.4  # search radius in pixels

        if marker_id in CENTER_MARKER_TARGETS:
            dx, dy = _detect_center_offset(gray, group_center_px, search_r)
        else:
            # Disable Harris correction — it can misalign panels when the
            # strongest corner is at a panel boundary rather than the true
            # target centre.  Log what it would have computed for diagnostics.
            dx_h, dy_h = _harris_center_offset(gray, group_center_px, search_r)
            dx, dy = 0, 0  # no correction applied

        if dx != 0 or dy != 0:
            offset = np.array([dx, dy], dtype=np.int32)
            panel_centers_2d = panel_centers_2d + offset.astype(np.float32)
            panel_polys = [p + offset for p in panel_polys]

        targets.append({
            'id': int(marker_id),
            'corners': corners.astype(np.int32),
            'center': tuple(center.astype(int)),
            'marker_edge': avg_edge,
            'panel_centers': [tuple(p.astype(int)) for p in panel_centers_2d],
            'panel_polys': panel_polys,
            'center_correction': (dx, dy),
            'harris_would_be': (dx_h, dy_h) if marker_id not in CENTER_MARKER_TARGETS else None,
        })

    _cached_targets = targets
    return targets


def _harris_center_offset(gray, predicted_center, search_radius):
    """Harris corner-based centre correction (used for non-T4P targets).

    Finds the strongest corner feature near the predicted panel-group
    centre and returns the offset.  Returns (0, 0) on failure.
    """
    h, w = gray.shape[:2]
    cx, cy = int(round(predicted_center[0])), int(round(predicted_center[1]))
    r = max(10, int(round(search_radius)))

    y0, y1 = max(0, cy - r), min(h, cy + r)
    x0, x1 = max(0, cx - r), min(w, cx + r)
    if y1 - y0 < 10 or x1 - x0 < 10:
        return 0, 0

    roi = gray[y0:y1, x0:x1].astype(np.float32)
    ksize = max(3, min(21, int(r / 5) | 1))  # ensure odd
    harris = cv2.cornerHarris(roi, blockSize=max(2, int(r / 5)),
                              ksize=ksize, k=0.05)

    peak_idx = np.unravel_index(np.argmax(harris), harris.shape)
    # peak_idx is (row, col) = (y, x)
    dx = int(peak_idx[1] + x0 - cx)
    dy = int(peak_idx[0] + y0 - cy)

    # Ignore if the correction is suspiciously large
    if abs(dx) > r or abs(dy) > r:
        return 0, 0
    return dx, dy


def draw(frame, targets):
    """Draw ArUco and panel overlays on the frame (in-place).

    Line thickness scales with marker size so overlays look correct
    on both small and large targets.

    Parameters
    ----------
    frame : ndarray
        BGR display frame (modified in-place).
    targets : list[dict]
        Output from ``detect()``.
    """
    green = (0, 255, 0)
    red = (0, 0, 255)

    for t in targets:
        corners = t['corners']
        edge = t.get('marker_edge', 100)
        thick = max(1, round(edge / 60))
        thin = max(1, thick // 2)

        # Green polygon around ArUco marker
        for j in range(4):
            pt1 = tuple(corners[j])
            pt2 = tuple(corners[(j + 1) % 4])
            cv2.line(frame, pt1, pt2, green, thick, cv2.LINE_AA)

        # Green filled circle at center
        radius = max(2, round(edge / 30))
        cv2.circle(frame, t['center'], radius, green, cv2.FILLED, cv2.LINE_AA)

        # ID label — scale font with marker size
        font_scale = max(0.35, edge / 200)
        cx, cy = t['center']
        cv2.putText(frame, str(t['id']), (cx + radius + 4, cy - radius),
                    cv2.FONT_HERSHEY_SIMPLEX, font_scale, green, thick,
                    cv2.LINE_AA)

        # Panels (labeled P0-P3 for geometry debugging)
        for idx, (pc, poly) in enumerate(zip(t['panel_centers'], t['panel_polys'])):
            cv2.polylines(frame, [poly], isClosed=True, color=red,
                          thickness=thick, lineType=cv2.LINE_AA)
            cv2.line(frame, t['center'], pc, green, thin, cv2.LINE_AA)
            # Label each panel with its geometry index
            label_scale = max(0.3, edge / 250)
            cv2.putText(frame, f"P{idx}", tuple(pc),
                        cv2.FONT_HERSHEY_SIMPLEX, label_scale,
                        (0, 255, 255), max(1, thick), cv2.LINE_AA)
