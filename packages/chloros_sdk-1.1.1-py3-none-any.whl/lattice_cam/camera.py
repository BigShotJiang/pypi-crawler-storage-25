import platform
import subprocess
import time

from arena_api.system import system

from .settings import CameraSettings, PRESETS
from .convert import (buffer_to_bgr, buffer_to_bgr_full_depth,
                      buffer_to_bgr_native, buffer_to_numpy)

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"

# Default timeout for the initial fast scan (ms).
_FAST_SCAN_TIMEOUT = 1000
# Longer timeout used after an adapter restart (ms).
_RECOVERY_SCAN_TIMEOUT = 10000

# Per-process cache of the largest GVSP packet size that actually traverses
# the current network fabric, keyed by camera serial. Populated by
# ``LatticeCam._auto_probe_packet_size_via_ping`` so a given CLI invocation
# only tests each camera once.
_PROBED_PACKET_SIZE: "dict[str, int]" = {}


class IncompleteBufferError(RuntimeError):
    """Raised when get_buffer returns a buffer flagged is_incomplete.

    The Arena SDK marks a buffer incomplete when one or more GVSP
    packets failed to arrive (and resend also failed). Accessing the
    buffer past the last-delivered packet reads stale bytes from the
    pool-allocator, which demosaic into horizontal magenta/pink bands
    on the screen. Callers should treat these as transient: retry on
    the next frame rather than letting garbage data leak into preview
    or saved captures.
    """


def _buffer_payload_problem(buffer):
    """Return a short reason string if the buffer shouldn't be trusted,
    or ``None`` if the buffer looks complete.

    Returning a reason (instead of just True/False) lets the caller put
    the exact failure mode in the error message, so logs distinguish
    "SDK flagged incomplete" from "size_filled short of payload_size"
    from "can't read either property". The last case used to silently
    fall through and treat unknown buffers as good, which hid bugs.

    Three SDK-canonical signals are checked, in order of cost:
      1. ``is_incomplete`` — set when one or more GVSP packets failed
         delivery (and resend also failed).
      2. ``is_data_larger_than_buffer`` — set when the camera tried to
         emit more bytes than the SDK's pool buffer holds; tail bytes
         are silently truncated and produce magenta bands on display.
         Some firmware/host combos set THIS without setting
         ``is_incomplete``, so checking only the latter has a hole.
      3. ``size_filled < payload_size`` — fallback when the flags are
         absent, catches partial GVSP delivery directly.
    """
    try:
        if buffer.is_incomplete:
            return "is_incomplete=True"
    except Exception as e:
        return f"is_incomplete read failed: {e!r}"
    # `is_data_larger_than_buffer` is a separate SDK flag: True when the
    # camera emitted more bytes than the buffer can hold. The arena_api
    # buffer docs (see ``arena_api/buffer.py:404``) describe it as a
    # distinct condition from ``is_incomplete``, so check both.
    try:
        if buffer.is_data_larger_than_buffer:
            return "is_data_larger_than_buffer=True"
    except Exception:
        pass  # Older SDK builds may omit the property; not fatal.
    try:
        sf = buffer.size_filled
        ps = buffer.payload_size
    except Exception:
        return None  # SDK doesn't expose these; trust is_incomplete alone
    if sf < ps:
        return f"size_filled={sf} < payload_size={ps}"
    return None


def _ping_df(ip, size_bytes, timeout_ms=800):
    """Send one ICMP echo request with Don't-Fragment set.

    Tests whether the network fabric between this host and *ip* forwards
    packets of *size_bytes* bytes (IP payload + headers). If the path
    includes a switch or splitter that silently drops jumbo frames, the
    ping fails. This gives a non-intrusive way to detect end-to-end
    packet size support without touching the camera's GenICam state.

    Returns True on echo reply, False on failure/timeout.
    """
    # size_bytes is the full IP packet size the user wants to validate.
    # ``ping -l`` on Windows and ``ping -s`` on Linux both take the
    # *payload* size, which is size_bytes minus the 20-byte IPv4 header
    # and 8-byte ICMP header.
    payload = max(0, size_bytes - 28)
    if IS_WINDOWS:
        cmd = ["ping", "-n", "1", "-f",
               "-l", str(payload),
               "-w", str(timeout_ms), str(ip)]
    else:
        # Linux ``-W`` takes seconds; round up for sub-second timeouts.
        sec = max(1, (timeout_ms + 999) // 1000)
        cmd = ["ping", "-c", "1", "-M", "do",
               "-s", str(payload),
               "-W", str(sec), str(ip)]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=(timeout_ms / 1000.0) + 2.0,
        )
    except Exception:
        return False

    if result.returncode != 0:
        return False

    # Windows ``ping`` returns 0 even when the reply is
    # "Packet needs to be fragmented but DF set" — detect that text
    # explicitly so we don't count a fragmented failure as success.
    out = (result.stdout or "") + (result.stderr or "")
    bad_markers = (
        "needs to be fragmented",       # Windows
        "Message too long",              # Linux
        "frag needed",                   # Linux alt
        "Request timed out",             # Windows
        "Destination host unreachable",  # Windows
        "100% packet loss",              # Linux
    )
    for marker in bad_markers:
        if marker.lower() in out.lower():
            return False
    return True


# ---------------------------------------------------------------------------
# Windows adapter recovery helpers
# ---------------------------------------------------------------------------

def _find_usb_ethernet_instance_ids_win():
    """Return PnP instance IDs for connected USB Ethernet adapters (Windows)."""
    try:
        result = subprocess.run(
            ["pnputil", "-enum-devices", "-connected", "-class", "Net"],
            capture_output=True, text=True, timeout=10,
        )
    except Exception:
        return []

    ids = []
    current_id = None
    for line in result.stdout.splitlines():
        if "Instance ID:" in line:
            current_id = line.split("Instance ID:")[-1].strip()
        elif current_id and "Device Description:" in line:
            desc = line.split("Device Description:")[-1].strip()
            is_usb = current_id.upper().startswith("USB\\")
            is_ethernet = any(
                kw in desc.lower()
                for kw in ("ethernet", "gbe", "gigabit", "lan")
            )
            skip = any(
                kw in desc.lower()
                for kw in ("virtual", "wifi", "wireless", "wan", "bluetooth")
            )
            if is_usb and is_ethernet and not skip:
                ids.append(current_id)
            current_id = None
    return ids


def _restart_adapter_win(instance_id):
    """Restart a PnP network adapter by its instance ID (Windows)."""
    try:
        subprocess.run(
            ["pnputil", "-restart-device", instance_id],
            capture_output=True, text=True, timeout=20,
        )
    except Exception:
        pass


def _ensure_firewall_rules_win():
    """Add GigE Vision firewall allow-rules (Windows netsh)."""
    rule_name = "GigE Vision Camera (LATTICE)"
    try:
        check = subprocess.run(
            ["netsh", "advfirewall", "firewall", "show", "rule",
             f"name={rule_name}"],
            capture_output=True, text=True, timeout=5,
        )
        if rule_name in check.stdout:
            return
    except Exception:
        pass

    try:
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule",
             f"name={rule_name}", "dir=in", "action=allow",
             "protocol=udp", "localport=any", "profile=any", "enable=yes"],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Linux adapter recovery helpers
# ---------------------------------------------------------------------------

def _find_ethernet_interfaces_linux():
    """Return interface names for physical Ethernet adapters (Linux)."""
    import pathlib
    interfaces = []
    net_dir = pathlib.Path("/sys/class/net")
    if not net_dir.exists():
        return interfaces
    for iface in net_dir.iterdir():
        # Skip loopback, wireless, virtual, bridge, docker, veth
        name = iface.name
        if name == "lo":
            continue
        if any(name.startswith(p) for p in
               ("wl", "ww", "docker", "br-", "veth", "virbr", "vnet")):
            continue
        # Check if it's a physical device (has a device symlink)
        if (iface / "device").exists():
            interfaces.append(name)
    return interfaces


def _restart_adapter_linux(interface):
    """Restart a network interface (Linux)."""
    # Try nmcli first, then ip link
    for cmd in [
        ["nmcli", "device", "reapply", interface],
        ["ip", "link", "set", interface, "down"],
    ]:
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if "down" in cmd:
                subprocess.run(
                    ["ip", "link", "set", interface, "up"],
                    capture_output=True, text=True, timeout=10)
            return
        except Exception:
            continue


def _ensure_firewall_rules_linux():
    """Ensure GigE Vision ports are open (Linux). Best-effort."""
    # Try ufw first, then iptables
    try:
        result = subprocess.run(
            ["ufw", "status"], capture_output=True, text=True, timeout=5)
        if "inactive" in result.stdout.lower():
            return  # firewall is off, nothing to do
        subprocess.run(
            ["ufw", "allow", "proto", "udp", "from", "any", "to", "any",
             "comment", "GigE Vision Camera"],
            capture_output=True, text=True, timeout=5)
        return
    except Exception:
        pass
    # Fallback: iptables
    try:
        subprocess.run(
            ["iptables", "-C", "INPUT", "-p", "udp", "-j", "ACCEPT"],
            capture_output=True, text=True, timeout=5)
    except Exception:
        try:
            subprocess.run(
                ["iptables", "-A", "INPUT", "-p", "udp", "-j", "ACCEPT"],
                capture_output=True, text=True, timeout=5)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Cross-platform discovery
# ---------------------------------------------------------------------------

def _discover_devices(timeout_ms=_FAST_SCAN_TIMEOUT):
    """Run an arena_api device scan with the given timeout.

    Results are sorted by serial number so that device indices are
    stable across repeated scans.
    """
    saved = system.DEVICE_INFOS_TIMEOUT_MILLISEC
    try:
        system.DEVICE_INFOS_TIMEOUT_MILLISEC = timeout_ms
        infos = system.device_infos
    finally:
        system.DEVICE_INFOS_TIMEOUT_MILLISEC = saved
    return sorted(infos, key=lambda d: d.get("serial", ""))


def discover_with_recovery(timeout_ms=_FAST_SCAN_TIMEOUT, verbose=False):
    """Discover cameras, automatically recovering stale network adapters.

    1. Fast scan with *timeout_ms*.
    2. If nothing found, restart Ethernet adapter(s) and re-scan
       with a longer timeout.
    3. Ensure firewall rules are in place before the retry.

    Works on both Windows and Linux. Returns the list of device-info
    dicts from ``arena_api``.
    """
    infos = _discover_devices(timeout_ms)
    if infos:
        return infos

    # -- auto-recovery path (platform-specific) ---
    if IS_WINDOWS:
        adapter_ids = _find_usb_ethernet_instance_ids_win()
        if not adapter_ids:
            return infos
        if verbose:
            print("No cameras found — restarting USB Ethernet adapter(s)...")
        _ensure_firewall_rules_win()
        for inst_id in adapter_ids:
            _restart_adapter_win(inst_id)
    elif IS_LINUX:
        interfaces = _find_ethernet_interfaces_linux()
        if not interfaces:
            return infos
        if verbose:
            print("No cameras found — restarting Ethernet interface(s)...")
        _ensure_firewall_rules_linux()
        for iface in interfaces:
            _restart_adapter_linux(iface)
    else:
        # Unsupported platform — skip recovery
        return infos

    # Give the adapter and camera time to re-establish link
    time.sleep(3)

    infos = _discover_devices(_RECOVERY_SCAN_TIMEOUT)
    if verbose:
        if infos:
            print(f"  Found {len(infos)} camera(s) after adapter restart.")
        else:
            print("  Still no cameras found after adapter restart.")
    return infos


class LatticeCam:
    """Wrapper for the LATTICE GigE Vision camera (IMX265) via arena_api.

    Usage::

        with LatticeCam(settings=CameraSettings(exposure_time=8000)) as cam:
            cam.start_stream()
            frame = cam.grab_frame()
            cam.stop_stream()
    """

    #: GenICam nodes to probe for power / thermal information.
    _POWER_PROBE_NODES = [
        # SFNC power-saving / standby
        "DevicePowerSavingMode",
        "PowerMode",
        "DeviceStandbyMode",
        # Thermal
        "DeviceTemperature",
        "DeviceTemperatureSelector",
        # Link / throughput (can be throttled to reduce draw)
        "DeviceLinkThroughputLimit",
        "DeviceLinkSpeed",
        # Device reset (reboots to power-up state)
        "DeviceReset",
        # Vendor-specific low-power nodes (Lucid)
        "DevicePowerMode",
        "DeviceSleepMode",
        "LowPowerMode",
    ]

    def __init__(self, device_index=0, settings=None, serial=None):
        self.device_index = device_index
        self.serial = serial
        self.settings = settings or CameraSettings()
        self._device = None
        self._device_info = None
        self._streaming = False
        self._sleeping = False

    # -- Connection lifecycle --------------------------------------------------

    def connect(self):
        """Connect to the camera device.

        If *serial* was given, connects to the camera with that serial
        number regardless of device_index.  Otherwise uses device_index.

        Automatically restarts USB Ethernet adapters and retries discovery
        if no cameras are found on the first scan.
        """
        device_infos = discover_with_recovery(verbose=True)
        if not device_infos:
            raise RuntimeError("No camera devices found")

        if self.serial is not None:
            for i, info in enumerate(device_infos):
                if info.get("serial") == self.serial:
                    self.device_index = i
                    break
            else:
                serials = [d.get("serial", "?") for d in device_infos]
                raise RuntimeError(
                    f"Camera with serial '{self.serial}' not found. "
                    f"Available: {', '.join(serials)}"
                )

        if self.device_index >= len(device_infos):
            raise RuntimeError(
                f"Device index {self.device_index} out of range "
                f"(found {len(device_infos)} devices)"
            )
        self._device_info = device_infos[self.device_index]

        # Packet size handling (runs BEFORE create_device so a failure
        # never touches the camera's GenICam state):
        # * auto mode: DF-ping probe, pick the largest size that works.
        # * manual mode + target > 1500: DF-ping the target as a safety
        #   check. If it fails, raise *before* opening the device so we
        #   don't trigger the GVSP timeout → SC_ERR_ACCESS_DENIED lockup
        #   that requires a camera power cycle.
        if getattr(self.settings, "gev_packet_size_auto", True):
            self._auto_probe_packet_size_via_ping()
        elif self.settings.gev_packet_size > 1500:
            ip = self._device_info.get("ip")
            target = self.settings.gev_packet_size
            if ip and not _ping_df(ip, target):
                raise RuntimeError(
                    f"--packet-size {target} was requested but the network "
                    f"fabric to camera {ip} does not forward {target}-byte "
                    f"packets (DF ping failed). Use --packet-size auto or "
                    f"--packet-size standard, or replace the switch/"
                    f"splitter with one that supports jumbo frames."
                )

        devices = system.create_device(self._device_info)
        self._device = devices[0]
        # Defensively stop any leftover acquisition before we touch
        # nodes. LATTICE camera firmware locks ISP / format nodes (Gamma,
        # PixelFormat, Width, Height) while AcquisitionMode is active —
        # ``apply_settings`` writes Gamma immediately and gets
        # SC_ERR_ERROR -1001 if the previous owner of the device didn't
        # quiesce the stream cleanly. Symptom: "[ISP] Gamma=1.0 — <write
        # err: Exception: SaveC ERROR -1001>" in the backend log when
        # going standalone → array, because the standalone disconnect
        # path can race with in-flight GVSP packets and leave the camera
        # firmware in AcquisitionActive=True. ``stop_stream`` later does
        # this too, but by then ``apply_settings`` has already failed.
        try:
            self._device.nodemap.get_node("AcquisitionStop").execute()
        except Exception:
            pass  # Node missing / already stopped — fine.
        self.apply_settings(self.settings)
        return self

    def disconnect(self):
        """Disconnect and clean up the camera device."""
        if self._streaming:
            self.stop_stream()
        if self._device is not None:
            system.destroy_device(self._device)
            self._device = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    # -- Power management ------------------------------------------------------

    def probe_power_nodes(self):
        """Probe the camera nodemap for power and thermal related nodes.

        Returns a list of dicts, one per discovered node, each containing:
        ``name``, ``value``, ``type``, and where applicable ``min``, ``max``,
        and ``entries`` (for enumeration nodes).
        """
        if self._device is None:
            raise RuntimeError("Camera not connected")

        nodemap = self._device.nodemap
        results = []

        for name in self._POWER_PROBE_NODES:
            try:
                node = nodemap.get_node(name)
            except Exception:
                continue

            info = {"name": name}
            try:
                iface = node.interface_type.name   # e.g. intfIFloat, intfIEnumeration
            except Exception:
                iface = "unknown"
            info["type"] = iface

            iface_lower = iface.lower()

            # Read value (skip command nodes like DeviceReset)
            if "command" in iface_lower:
                info["value"] = "<command>"
            else:
                try:
                    info["value"] = node.value
                except Exception:
                    info["value"] = "<unreadable>"

            # Numeric range
            if any(k in iface_lower for k in ("float", "integer")):
                try:
                    info["min"] = node.min
                    info["max"] = node.max
                except Exception:
                    pass

            # Enumeration entries
            if "enum" in iface_lower:
                try:
                    info["entries"] = [e.name for e in node.entries
                                       if e.is_readable]
                except Exception:
                    pass

            results.append(info)

        return results

    @property
    def is_sleeping(self):
        return self._sleeping

    def sleep(self):
        """Put the camera into software idle to reduce power draw.

        Stops streaming, throttles the GigE link throughput to its minimum,
        and disconnects from the device.  The camera hardware remains powered
        but the sensor, FPGA processing, and high-speed PHY activity are
        minimised.

        Call :meth:`wake` to reconnect and restore full operation.
        """
        if self._sleeping:
            return
        if self._device is None:
            self._sleeping = True
            return

        # 1. Stop acquisition
        if self._streaming:
            self.stop_stream()

        # 2. Throttle link throughput to minimum (reduces PHY activity)
        try:
            node = self._device.nodemap.get_node("DeviceLinkThroughputLimit")
            node.value = node.min
        except Exception:
            pass

        # 3. Try any available power-saving mode
        for node_name in ("DevicePowerSavingMode", "PowerMode",
                          "DevicePowerMode", "LowPowerMode"):
            try:
                node = self._device.nodemap.get_node(node_name)
                # Look for a low-power entry
                entries = [e.name for e in node.entries if e.is_readable]
                for candidate in ("LowPower", "Standby", "Sleep", "Off"):
                    if candidate in entries:
                        node.value = candidate
                        break
            except Exception:
                continue

        # 4. Disconnect (frees host resources, no active control channel)
        self.disconnect()
        self._sleeping = True

    def wake(self):
        """Reconnect after :meth:`sleep` and restore full camera settings.

        Re-runs device discovery, opens the device, and re-applies the
        stored :attr:`settings` (including full link throughput).
        """
        if not self._sleeping:
            return
        self._sleeping = False
        self.connect()

    # -- Settings --------------------------------------------------------------

    def apply_settings(self, settings):
        """Write all settings to the device nodemap."""
        self.settings = settings
        nodemap = self._device.nodemap

        # Resolution — reset offsets first so that new width/height
        # never exceeds sensor bounds (offset + size <= max).
        self._set_node_safe("OffsetX", 0)
        self._set_node_safe("OffsetY", 0)
        self._set_node_safe("Width", settings.width)
        self._set_node_safe("Height", settings.height)
        self._set_node_safe("OffsetX", settings.offset_x)
        self._set_node_safe("OffsetY", settings.offset_y)

        # Pixel format
        self._set_node_safe("PixelFormat", settings.pixel_format)

        # Exposure
        self._set_node_safe("ExposureAuto", settings.exposure_auto)
        if settings.exposure_auto == "Off":
            self._set_node_safe("ExposureTime", settings.exposure_time)

        # Gain
        self._set_node_safe("GainAuto", settings.gain_auto)
        if settings.gain_auto == "Off":
            self._set_node_safe("Gain", settings.gain)
        # GainAutoUpperLimit. Cap to a fixed dB to enforce exposure-only
        # AE; None = release the cap to the node's max so AE can use the
        # full gain range when exposure has saturated. Always-write
        # matters: GainAutoUpperLimit persists in the camera's RAM
        # across reconnects, so a previous-session cap would otherwise
        # silently stick even after the user changes their mind.
        try:
            gnode = self._device.nodemap.get_node("GainAutoUpperLimit")
            if gnode is not None:
                if settings.gain_auto_upper_limit_db is None:
                    gnode.value = gnode.max
                else:
                    gnode.value = float(settings.gain_auto_upper_limit_db)
        except Exception:
            pass

        # Auto exposure/gain target brightness, damping, and metering region
        self._set_node_safe("TargetBrightness", settings.target_brightness)
        self._set_node_safe("ExposureAutoDamping", settings.ae_damping)
        if settings.ae_upper_limit is not None:
            self._set_node_safe("ExposureAutoLimitAuto", "Off")
            self._set_node_safe("ExposureAutoUpperLimit", settings.ae_upper_limit)
        else:
            self._set_node_safe("ExposureAutoLimitAuto", "Continuous")
        self._configure_ae_aoi(settings.width, settings.height,
                               settings.ae_aoi_fraction)

        # White balance
        self._set_node_safe("BalanceWhiteAuto", settings.balance_white_auto)
        if settings.balance_white_auto == "Off":
            try:
                nodemap.get_node("BalanceRatioSelector").value = "Red"
                nodemap.get_node("BalanceRatio").value = settings.balance_ratio_red
                nodemap.get_node("BalanceRatioSelector").value = "Blue"
                nodemap.get_node("BalanceRatio").value = settings.balance_ratio_blue
            except Exception:
                pass  # Not all cameras support manual white balance ratios

        # ISP processing — disable colour pipeline for scientific imaging.
        # Use _set_isp_node so failures are visible (linearity matters).
        #
        # The Gamma value node is locked by LATTICE camera firmware when
        # GammaEnable=False (the value is moot when the feature is off,
        # so the firmware refuses writes with SC_ERR_ERROR -1001). Skip
        # the value write when we just disabled the feature; otherwise
        # every connect logs a confusing "[ISP] Gamma=1.0 — <write err>"
        # for an action that was correctly a no-op. Same applies to
        # ColorTransformationEnable's transform-value subnodes.
        if settings.gamma_enable is not None:
            self._set_isp_node("GammaEnable", settings.gamma_enable)
        if settings.gamma is not None and settings.gamma_enable is not False:
            self._set_isp_node("Gamma", settings.gamma)
        if settings.lut_enable is not None:
            self._set_isp_node("LUTEnable", settings.lut_enable)
        if settings.ccm_enable is not None:
            self._set_isp_node("ColorTransformationEnable", settings.ccm_enable)

        # Acquisition
        self._set_node_safe("AcquisitionMode", settings.acquisition_mode)

        # Trigger
        self._set_node_safe("TriggerMode", settings.trigger_mode)
        if settings.trigger_mode == "On":
            self._set_node_safe("TriggerSource", settings.trigger_source)

        # Frame rate. Auto (Enable=False) lets the camera free-run at
        # whatever fps current exposure + sensor readout + network
        # bandwidth allow. Manual (Enable=True) honors the user's cap
        # as an upper bound — ExposureTime.max then binds to
        # 1/AcquisitionFrameRate so a manual 1 fps gives ~990 ms of
        # exposure headroom. AE controls only ExposureTime/Gain; fps
        # is a network/sensor concern, not an AE one.
        if settings.frame_rate_enable:
            self._set_node_safe("AcquisitionFrameRateEnable", True)
            self._set_node_safe("AcquisitionFrameRate", settings.frame_rate)
        else:
            self._set_node_safe("AcquisitionFrameRateEnable", False)

        # GigE Vision transport tuning — maximize throughput
        self._maximize_throughput(settings)

    def set_exposure(self, exposure_us):
        """Adjust exposure time in microseconds (hot-adjustable, no stream restart)."""
        self._set_node_safe("ExposureAuto", "Off")
        self._set_node_safe("ExposureTime", exposure_us)
        self.settings.exposure_time = exposure_us
        self.settings.exposure_auto = "Off"

    def set_gain(self, gain_db):
        """Adjust gain in dB (hot-adjustable, no stream restart)."""
        self._set_node_safe("GainAuto", "Off")
        self._set_node_safe("Gain", gain_db)
        self.settings.gain = gain_db
        self.settings.gain_auto = "Off"

    def set_resolution(self, width, height, offset_x=0, offset_y=0):
        """Set camera resolution / ROI (requires stream restart)."""
        self._set_node_safe("OffsetX", 0)
        self._set_node_safe("OffsetY", 0)
        self._set_node_safe("Width", width)
        self._set_node_safe("Height", height)
        self._set_node_safe("OffsetX", offset_x)
        self._set_node_safe("OffsetY", offset_y)
        self.settings.width = width
        self.settings.height = height
        self.settings.offset_x = offset_x
        self.settings.offset_y = offset_y
        self._configure_ae_aoi(width, height, self.settings.ae_aoi_fraction)

    def set_node(self, name, value):
        """Set a nodemap value directly (advanced use)."""
        node = self._device.nodemap.get_node(name)
        node.value = value

    def get_node(self, name):
        """Get a nodemap value directly (advanced use)."""
        node = self._device.nodemap.get_node(name)
        return node.value

    # -- Chunk data (per-frame metadata) --------------------------------------

    #: Chunks enabled automatically when streaming.
    _CHUNK_LIST = [
        "Timestamp", "ExposureTime", "Gain", "BlackLevel", "CRC",
    ]

    def _enable_chunk_data(self):
        """Enable chunk data so each buffer carries per-frame metadata."""
        self._set_node_safe("ChunkModeActive", True)
        for chunk in self._CHUNK_LIST:
            try:
                self._device.nodemap.get_node("ChunkSelector").value = chunk
                self._device.nodemap.get_node("ChunkEnable").value = True
            except Exception:
                pass

    def _disable_chunk_data(self):
        self._set_node_safe("ChunkModeActive", False)

    def read_chunk_metadata(self):
        """Read chunk metadata from the most recently grabbed buffer.

        Must be called after ``get_buffer()`` and before the next
        ``get_buffer()`` call (the data is overwritten each time).
        Returns a dict with camera-reported values for the frame.
        """
        nm = self._device.nodemap
        meta = {}
        for node_name, key in [
            ("ChunkTimestamp",    "timestamp_ns"),
            ("ChunkExposureTime", "exposure_time_us"),
            ("ChunkGain",         "gain_db"),
            ("ChunkBlackLevel",   "black_level"),
            ("ChunkCRC",          "crc"),
        ]:
            try:
                meta[key] = nm.get_node(node_name).value
            except Exception:
                pass
        return meta

    def grab_raw_with_metadata(self, timeout=2000):
        """Grab a raw frame and return (raw_array, metadata_dict).

        Returns the raw Bayer/Mono array without demosaicing so the caller
        can perform GPU-accelerated demosaic separately.
        """
        buffer = self._device.get_buffer(timeout=timeout)
        try:
            reason = _buffer_payload_problem(buffer)
            if reason:
                raise IncompleteBufferError(
                    f"GVSP packet loss ({reason}): "
                    f"tail rows would contain stale bytes")
            meta = self.read_chunk_metadata()
            meta["frame_id"] = buffer.frame_id
            meta["width"] = buffer.width
            meta["height"] = buffer.height
            meta["pixel_format"] = self.settings.pixel_format
            raw = buffer_to_numpy(buffer)
        finally:
            self._device.requeue_buffer(buffer)
        return raw, meta

    def grab_frame_with_metadata(self, timeout=2000, full_depth=False,
                                  native=False):
        """Grab a frame and return (bgr_array, metadata_dict).

        Metadata contains hardware chunk data (timestamp, actual exposure,
        gain, etc.) plus the buffer frame_id.

        Parameters
        ----------
        full_depth : bool
            If True, return uint16 BGR scaled to full 16-bit range
            (suitable for saving as 16-bit TIFF).
        native : bool
            If True, return BGR at the sensor's native bit depth without
            any scaling (uint8 for 8-bit, uint16 with raw DN values for
            10/12/16-bit).  Preferred for calibration where actual DN
            values matter.
        """
        buffer = self._device.get_buffer(timeout=timeout)
        try:
            reason = _buffer_payload_problem(buffer)
            if reason:
                raise IncompleteBufferError(
                    f"GVSP packet loss ({reason}): "
                    f"tail rows would contain stale bytes")
            # Read chunk data while buffer is still attached
            meta = self.read_chunk_metadata()
            meta["frame_id"] = buffer.frame_id
            meta["width"] = buffer.width
            meta["height"] = buffer.height
            meta["pixel_format"] = self.settings.pixel_format

            if native:
                frame = buffer_to_bgr_native(buffer, self.settings.pixel_format)
            elif full_depth:
                frame = buffer_to_bgr_full_depth(buffer, self.settings.pixel_format)
            else:
                frame = buffer_to_bgr(buffer, self.settings.pixel_format)
        finally:
            self._device.requeue_buffer(buffer)
        return frame, meta

    # -- Streaming -------------------------------------------------------------

    def start_stream(self, num_buffers=None):
        """Start the acquisition stream.

        Defensively stops any stale acquisition from an unclean previous
        session before starting fresh.
        """
        if self._streaming:
            return
        n = num_buffers if num_buffers is not None else self.settings.stream_num_buffers

        # Stop stale acquisition left by a crashed/killed session
        try:
            self._device.nodemap.get_node("AcquisitionStop").execute()
        except Exception:
            pass

        # Enable chunk data before streaming
        self._enable_chunk_data()

        # Configure stream buffer handling
        tl_stream = self._device.tl_stream_nodemap
        self._set_tl_node_safe(
            tl_stream, "StreamBufferHandlingMode",
            self.settings.buffer_handling_mode
        )

        self._device.start_stream(n)
        self._streaming = True

    def stop_stream(self):
        """Stop the acquisition stream.

        Issues both the SDK stop_stream and a direct AcquisitionStop
        node command so the camera is fully quiesced even if the SDK
        call fails.
        """
        if not self._streaming:
            return
        try:
            self._device.stop_stream()
        except Exception:
            pass
        try:
            self._device.nodemap.get_node("AcquisitionStop").execute()
        except Exception:
            pass
        self._streaming = False

    @property
    def is_streaming(self):
        return self._streaming

    def grab_frame(self, timeout=2000):
        """Grab a frame and return an 8-bit BGR numpy array for display."""
        buffer = self._device.get_buffer(timeout=timeout)
        try:
            reason = _buffer_payload_problem(buffer)
            if reason:
                raise IncompleteBufferError(
                    f"GVSP packet loss ({reason}): "
                    f"tail rows would contain stale bytes")
            frame = buffer_to_bgr(buffer, self.settings.pixel_format)
        finally:
            self._device.requeue_buffer(buffer)
        return frame

    def grab_frame_raw(self, timeout=2000):
        """Grab a frame and return a raw numpy array in native format."""
        buffer = self._device.get_buffer(timeout=timeout)
        try:
            reason = _buffer_payload_problem(buffer)
            if reason:
                raise IncompleteBufferError(
                    f"GVSP packet loss ({reason}): "
                    f"tail rows would contain stale bytes")
            frame = buffer_to_numpy(buffer)
        finally:
            self._device.requeue_buffer(buffer)
        return frame

    def grab_frame_full_depth(self, timeout=2000):
        """Grab a frame and return a demosaiced BGR array preserving bit depth."""
        buffer = self._device.get_buffer(timeout=timeout)
        try:
            reason = _buffer_payload_problem(buffer)
            if reason:
                raise IncompleteBufferError(
                    f"GVSP packet loss ({reason}): "
                    f"tail rows would contain stale bytes")
            frame = buffer_to_bgr_full_depth(buffer, self.settings.pixel_format)
        finally:
            self._device.requeue_buffer(buffer)
        return frame

    def trigger_software(self):
        """Fire a software trigger (camera must be in triggered mode)."""
        self._device.nodemap.get_node("TriggerSoftware").execute()

    # -- Device enumeration ----------------------------------------------------

    @staticmethod
    def enumerate_devices():
        """List all connected camera devices.

        Automatically restarts USB Ethernet adapters if no cameras are
        found on the first scan.

        Returns a list of dicts with device info (model, serial, ip, mac).
        """
        device_infos = discover_with_recovery(verbose=True)
        results = []
        for info in device_infos:
            results.append({
                "model": info.get("model", "Unknown"),
                "serial": info.get("serial", "Unknown"),
                "ip": info.get("ip", "Unknown"),
                "mac": info.get("mac", "Unknown"),
                "vendor": info.get("vendor", "Unknown"),
                "name": info.get("name", ""),
            })
        return results

    # -- Internal helpers ------------------------------------------------------

    def _configure_ae_aoi(self, roi_w, roi_h, fraction):
        """Set the auto-exposure metering AOI to the centre *fraction* of the ROI.

        A fraction of 1.0 disables the AOI (full ROI metering).
        A fraction of 0.5 meters only the centre 50% of the image.
        """
        if fraction >= 1.0:
            self._set_node_safe("AutoExposureAOIEnable", False)
            return

        self._set_node_safe("AutoExposureAOIEnable", True)

        aoi_w = max(1, int(roi_w * fraction))
        aoi_h = max(1, int(roi_h * fraction))
        off_x = (roi_w - aoi_w) // 2
        off_y = (roi_h - aoi_h) // 2

        # Shrink size before setting offset (offset + size <= ROI)
        self._set_node_safe("AutoExposureAOIOffsetX", 0)
        self._set_node_safe("AutoExposureAOIOffsetY", 0)
        self._set_node_safe("AutoExposureAOIWidth", aoi_w)
        self._set_node_safe("AutoExposureAOIHeight", aoi_h)
        self._set_node_safe("AutoExposureAOIOffsetX", off_x)
        self._set_node_safe("AutoExposureAOIOffsetY", off_y)

    def _set_node_safe(self, name, value):
        """Set a node value, ignoring errors for unsupported nodes."""
        try:
            node = self._device.nodemap.get_node(name)
            node.value = value
        except Exception:
            pass  # Node may not exist on all camera models

    def _set_isp_node(self, name, value):
        """Set an ISP node value, printing a warning on failure.

        ISP nodes (Gamma, LUT, CCM) are critical for linear sensor response.
        Unlike ``_set_node_safe``, failures are reported so users can diagnose
        non-linear output issues.

        Distinguishes three failure modes so the log is actionable:
          * ``<missing>`` — get_node returned None (firmware doesn't expose
            the node at all).
          * ``<get err>`` — get_node itself threw (usually arena_api
            ValueError when the SDK doesn't recognise the name).
          * ``<write err>`` — node existed but write was rejected (locked
            during streaming, out-of-range value, etc.); shows the actual
            message so the user sees *why* not just *that* it failed.
        """
        try:
            node = self._device.nodemap.get_node(name)
        except Exception as e:
            print(f"  [ISP] {name}={value} — <get err: "
                  f"{type(e).__name__}: {e}>")
            return
        if node is None:
            print(f"  [ISP] {name}={value} — <missing on this firmware>")
            return
        try:
            node.value = value
        except Exception as e:
            print(f"  [ISP] {name}={value} — <write err: "
                  f"{type(e).__name__}: {e}>")
            return
        try:
            actual = node.value
            if actual != value:
                print(f"  [ISP] WARNING: {name} set to {value} but "
                      f"reads back {actual}")
        except Exception:
            pass  # value-readback isn't critical, write succeeded

    def _maximize_throughput(self, settings):
        """Configure GigE transport for maximum throughput.

        Minimises inter-packet delay and negotiates the largest feasible
        packet size. Does NOT touch ``DeviceLinkThroughputLimit`` — the
        LATTICE camera firmware appears to lock that node after the first write
        per session, so a backend pass that writes it here AND a
        subsequent ``_rebalance_pool_bandwidth`` write would fail with
        SaveC ERROR -1001 on the second pass, leaving the camera
        emitting at the (max-sized) value the first write picked. The
        backend's rebalance logic is the only place that knows the
        right per-camera fair share for the current pool size, so let
        it own the single write to that node.
        """
        # Inter-packet delay: 0 = fastest
        self._set_node_safe("GevSCPD", settings.gev_packet_delay)

        # Packet size: auto-probe (try jumbo first, fall back through the
        # network fabric) or force exact size if the caller opted out.
        auto = getattr(settings, "gev_packet_size_auto", True)
        self._negotiate_packet_size(settings.gev_packet_size, auto=auto)

    def _negotiate_packet_size(self, target_size, auto=True):
        """Write GevSCPSPacketSize to *target_size* with a reject-fallback.

        This is the final apply step called from ``_maximize_throughput``.
        When ``gev_packet_size_auto`` is set, ``connect()`` has already
        run the live-probe in :meth:`_auto_probe_packet_size` and rewritten
        ``settings.gev_packet_size`` to a value that actually works, so
        this method just needs to write it. The *auto* flag is retained
        for backward compatibility with manual callers.
        """
        candidates = sorted(set([target_size, 8228, 4096, 1500, 1400]),
                            reverse=True)
        for size in candidates:
            if size > target_size:
                continue
            try:
                node = self._device.nodemap.get_node("GevSCPSPacketSize")
                node.value = size
                if node.value >= size - 100:
                    return
            except Exception:
                continue

    def _auto_probe_packet_size_via_ping(self):
        """Detect the largest GVSP packet size the network fabric supports.

        Uses ICMP ping with the Don't-Fragment flag set, so the probe
        tests the real end-to-end path (laptop NIC → switch fabric →
        camera) WITHOUT ever touching the camera's GenICam state. A
        failed probe cannot lock the GigE Vision control channel or put
        the camera into an SC_ERR state; at worst, we pick a conservative
        packet size and apply it via normal settings.

        Runs in :meth:`connect` before ``create_device`` so the probe's
        stdout ordering is predictable and the device handle is never
        exposed to a risky test. The chosen size is written back to
        ``self.settings.gev_packet_size`` and cached per serial in
        :data:`_PROBED_PACKET_SIZE` so later cameras in the same process
        skip the probe.
        """
        target = self.settings.gev_packet_size

        cached = _PROBED_PACKET_SIZE.get(self.serial) if self.serial else None
        if cached is not None:
            self.settings.gev_packet_size = cached
            return

        ip = self._device_info.get("ip") if self._device_info else None
        if not ip:
            return  # no IP to ping, leave target as-is

        # Build candidate ladder (largest first, <= target).
        candidates = [c for c in (target, 8228, 4096, 1500)
                      if c <= target]
        # Dedupe while preserving order.
        seen = set()
        candidates = [c for c in candidates
                      if not (c in seen or seen.add(c))]
        if not candidates:
            candidates = [1500]

        print(f"  [Network] Probing GVSP packet size via DF ping to {ip}...")

        chosen = None
        for size in candidates:
            if _ping_df(ip, size):
                chosen = size
                break

        if chosen is None:
            chosen = 1500
            print("  [Network] WARNING: all DF ping probes failed; "
                  "defaulting to standard MTU (1500)")

        self.settings.gev_packet_size = chosen
        if self.serial:
            _PROBED_PACKET_SIZE[self.serial] = chosen
        label = ("jumbo" if chosen >= 8000
                 else "standard" if chosen <= 1500
                 else "reduced")
        print(f"  [Network] GVSP packet size: {chosen} bytes ({label})")

    def _set_tl_node_safe(self, nodemap, name, value):
        """Set a transport layer node value safely."""
        try:
            node = nodemap.get_node(name)
            node.value = value
        except Exception:
            pass
