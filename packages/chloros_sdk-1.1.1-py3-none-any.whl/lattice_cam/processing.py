"""Processing tier configuration for LATTICE multi-camera pipelines.

Determines whether to use CPU-serial or GPU-parallel demosaic/processing
based on the user's subscription level and detected hardware.

Tiers
-----
- **basic** — CPU single-threaded demosaic (free / not logged in).
- **plus**  — GPU batched demosaic + multi-threaded pipeline (Chloros+
  premium, CLI, SDK).

CLI and SDK always use the *plus* tier regardless of login state.

Usage
-----
::

    from lattice_cam.processing import get_processing_config

    cfg = get_processing_config()       # auto-detect tier + hardware
    cfg = get_processing_config("plus") # force tier (CLI/SDK)

    if cfg.use_gpu:
        bgr_list = gpu_demosaic_batch(raws, fmts)
    else:
        bgr_list = [demosaic(r, f) for r, f in zip(raws, fmts)]
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class ProcessingTier(Enum):
    """Processing tier — determines CPU vs GPU path."""
    BASIC = "basic"   # CPU serial (free tier / not logged in)
    PLUS = "plus"     # GPU + multi-threaded (Chloros+ / CLI / SDK)


@dataclass
class ProcessingConfig:
    """Resolved processing configuration for a LATTICE pipeline session.

    Created by :func:`get_processing_config` based on the active tier
    and detected hardware.
    """
    tier: ProcessingTier
    use_gpu: bool           # True if CUDA available AND tier is PLUS
    demosaic_workers: int   # Thread count for parallel demosaic (1 for BASIC)
    writer_workers: int     # Thread count for async disk writers
    gpu_name: str           # Human-readable GPU name (or "CPU")
    gpu_memory_gb: float    # Available VRAM (0 if no GPU)
    cpu_cores: int          # Logical CPU cores


def get_processing_config(
    tier: Optional[str] = None,
    *,
    force_gpu: Optional[bool] = None,
) -> ProcessingConfig:
    """Build a :class:`ProcessingConfig` from tier + detected hardware.

    Parameters
    ----------
    tier : str, optional
        ``"basic"`` or ``"plus"``.  If *None*, auto-detects from the
        Chloros API state (``processing_mode`` / ``user_logged_in``).
        CLI and SDK callers should pass ``"plus"`` explicitly.
    force_gpu : bool, optional
        Override GPU detection.  ``True`` forces GPU path even without
        detection, ``False`` forces CPU path.  Mainly for testing.
    """
    resolved_tier = _resolve_tier(tier)

    # Detect hardware
    caps = _detect_capabilities()

    # GPU decision
    if force_gpu is not None:
        use_gpu = force_gpu and resolved_tier == ProcessingTier.PLUS
    else:
        use_gpu = caps["has_cuda"] and resolved_tier == ProcessingTier.PLUS

    # Thread counts (adaptive based on hardware)
    cpu_cores = caps["cpu_cores"]
    if resolved_tier == ProcessingTier.BASIC:
        demosaic_workers = 1
        writer_workers = 1
    else:
        # Plus tier: scale with available cores, leave headroom for grab
        demosaic_workers = max(2, min(cpu_cores - 2, 8))
        writer_workers = max(2, min(cpu_cores // 2, 4))

    return ProcessingConfig(
        tier=resolved_tier,
        use_gpu=use_gpu,
        demosaic_workers=demosaic_workers,
        writer_workers=writer_workers,
        gpu_name=caps["gpu_name"],
        gpu_memory_gb=caps["gpu_memory_gb"],
        cpu_cores=cpu_cores,
    )


def _resolve_tier(tier_str):
    """Resolve tier string to ProcessingTier enum."""
    if tier_str is not None:
        return ProcessingTier(tier_str)

    # Auto-detect from Chloros API state
    try:
        from api import MAPIRApi
        api = MAPIRApi.instance() if hasattr(MAPIRApi, 'instance') else None
        if api is not None:
            mode = getattr(api, 'processing_mode', 'standard')
            if mode == 'premium':
                return ProcessingTier.PLUS
    except Exception:
        pass

    return ProcessingTier.BASIC


def _detect_capabilities():
    """Detect hardware capabilities, using Chloros system if available."""
    result = {
        "has_cuda": False,
        "gpu_name": "CPU",
        "gpu_memory_gb": 0.0,
        "cpu_cores": 4,
    }

    # Try Chloros system_capabilities first
    try:
        from system_capabilities import get_system_capabilities
        caps = get_system_capabilities()
        result["has_cuda"] = caps.has_cuda
        result["gpu_name"] = caps.gpu_name if caps.has_cuda else "CPU"
        result["gpu_memory_gb"] = caps.gpu_memory_gb
        result["cpu_cores"] = caps.cpu_cores_logical
        return result
    except Exception:
        pass

    # Fallback: direct detection
    import os
    result["cpu_cores"] = os.cpu_count() or 4

    try:
        from lattice_cam.gpu_ops import is_available, gpu_name
        if is_available():
            result["has_cuda"] = True
            result["gpu_name"] = gpu_name()
            # Try to get VRAM
            try:
                import torch
                props = torch.cuda.get_device_properties(0)
                result["gpu_memory_gb"] = props.total_memory / (1024 ** 3)
            except Exception:
                pass
    except Exception:
        pass

    return result
