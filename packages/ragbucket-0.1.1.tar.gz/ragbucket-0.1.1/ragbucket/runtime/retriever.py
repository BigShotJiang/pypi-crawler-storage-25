import numpy as np 
from sentence_transformers import SentenceTransformer
from ragbucket.constants import EMBEDDING_MODEL


class Retriever:

    def __init__(self):

        self.model = SentenceTransformer(
            EMBEDDING_MODEL
        )

    def retrieve(self, query, index, chunks, top_k=3):
        
        query_embedding = self.model.encode([query])
        query_embedding = np.array(query_embedding, dtype="float32")
        distance, indices = index.search(query_embedding, top_k)

        retrieved_chunks = [
            chunks[i] for i in indices[0]
        ]
        
        return retrieved_chunks


