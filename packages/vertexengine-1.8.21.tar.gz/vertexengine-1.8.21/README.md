<img width="858" height="157" alt="VertexEngine_Logo" src="https://github.com/user-attachments/assets/6ba8a8dd-285a-4618-8e29-da12eb92e9ce" />

# VertexEngine/Vertex
VertexEngine is a GUI and Game Engine for python applications, it works best if you use py installer
## Offical Extensions:
[VertexEngine-WebEngine](https://pypi.org/project/VertexEngine-WebEngine)
[VertexEngine-CLI](https://pypi.org/project/VertexEngine-CLI/1.0/)
## Help
- The documentation is in the following link: [Documentation](https://vertexenginedocs.netlify.app/) for help.
- Support Email: FinalFacility0828@gmail.com
## Community
Discord is out NOW!
[Discord Server](https://discord.com/channels/1468208686869643327/1468208687670890588)
## Change Logs (1.0rc1 - 1.8.2), NEW!
### 1.8.2
- Graphical Math Tweaks!
- Old classes now moved into Math
- GraphicalMath is now just Math
### 1.8.1
- Some Fixes!
- Tweaks!
### 1.8.0
- Updated Documentation!
- Engine Fixes!
### 1.8rc2
- Fixed math not defined errors
- Renamed to GraphicalMath
- Added the utility functions (clamp, lerp, etc.)
### 1.8rc1
- Patched some runtime errors
- Added MATH! (from VertexEngine.math import *)
### 1.7.3
- Added new functions to collisions!
### 1.7.2
- Added HIGHLIGHTING to Ocean Code!**
- Fixed a lot of bugs!
- Fixed outdated URLs (2 day server shutdown)
### 1.7.1
- Offical VertexEngine Projects Browser! (RainExplorer)
- Accounts Wiped soon.
- Fixed a bit to many bugs.
### 1.7.0
- Fixed Collision not defined errors
- Added an Offical Tutorial Video!
- Accounts will be wiped soon.
### 1.7rc1
- My charger got lost, then came back :D
- Added a Collision system :D (from VertexEngine.Collisions import *)
- Made an IDE for VertexEngine :)
- Link: [https://tyrel-homepage.onrender.com/OceanCode]https://tyrel-homepage.onrender.com/OceanCode
### 1.6.1
- Fixed 50+ bugs!
### 1.6.0
- Wiped Accounts :(
- Discord fixed
- New Link :)
### 1.6rc2
- Fixed some errors!
### 1.6rc1
- Depreciated unused items
- Added BINDING!
- IDK what to put here :q
### 1.5.5
- Fixed Pygame Widgets, Documentation Updated

### 1.5.0
- Added PYGAME WIDGETS! (from VertexEngine.VertexWidgets import PygameVWidgets)
### 1.5rc5
- FINAL RC!
- WARNING: ALL HOMEPAGE ACCOUNTS WILL BE CLEARNED, BUT DONATIONS WILL BE KEPT IN THE DONATION ACCOUNT.
- Added more Docstrings!
- Added moving the FancyButton and Text classes respectively.
- Pls use the Extensions, they're pretty lonely :(
### 1.5rc4
- Added More Docstrings so documentation won't be as stressful for me to do :)
- Expanded InputSystem!
- Fixed GameEngine!
### 1.5rc2
- Now Allows custom BG colors in GameEngine!
- Allows resizing of AssetManager images!
### 1.5rc1
- Homepage only updates on major updates now.
- Fixed asset manager bugs
### 1.4.0
- Fixed a lot of bugs
- Updated outdated templates!
- Docs update!
### 1.4rc2
- Final RC!
- Fixed internals for the WebEngine and CLI.
- Added 1 New Module:
- OptionBtnWidget
### 1.4rc1
- 21 Stablization Fixes!
- Added builtin KeyDown/Up events to GameEngine!
- Stripped unnecessary stuff.
### 1.3.0
- SUPPORT FOR PYTHON 3.14!
- DOCUMENTATION UPDATED!
### 1.3rc4
- DISCORD SERVER IS OUT NOW!
- FINAL RC!
### 1.3rc2
- Added 2 new VertexUI APIs:
- AutoFontLabel > Automatically Adapts to screen size!
- Card > A mini VBox in card layout for card based UI!
### 1.3rc1
- No more docs for RCs as the new functions are ("expirimental")
- Moved SimpleGUI and AdvancedVWidgets into VertexEngine.VertexWidgets
- 10 Days before the discord server is launched!
- Added:
    - Responsive Layout (Adapts to screen size)
    - Centered Layout (Anchors child widgets to the center)
### 1.2rc4
- Final RC!
- Docs will be updated on Feb 04, 2026.
- New Library!:
~ VertexEngine.AdvancedWidgets
### 1.2rc3
- Added 1 New Library:
~ HBox, VBox but horizontally not vertically.
### 1.2rc1
- Added a new Extension: [VertexEngine-CLI](https://pypi.org/project/VertexEngine-CLI/1.0/)

### 1.1
- Bugfixed WebEngine
- Compression

### 1.1rc4
- FINAL RC!
- Added 2 New Libraries: ~ VertexEngine.WebEngine ~ VertexEngine.WebView

### 1.1rc3
Revamped Input System!
DEMO GAMES!
Updated Scene Docs

### Version 1.1rc2
Documentation Expansion! ~ Fixed the Changelogs
New Input System!
Old System (Qt) depreceated and not recomended for use.

### Version 1.1rc1
New Library! (And Modules)!: ~ InputSystem ~ Buttons (Mouse and Widget) ~ Keyboard Input

### Version 1.0.1
Added Changelogs!

### Version 1.0
Added 2 New Libraries: ~ VertexEngine.SimpleGUI ~ VertexEngine.VertexScreenModifiers

### Version 1.0rc2
Final Release Candidate
Added 1 New Library!: ~ VertexUI

### Version 1.0rc1
Size Compression
Added 1 New Library!: ~ VertexScreen

## How to install Pyinstaller
Step 1. Type in: pip install pyinstaller

Step 2. Wait a few min, don't worry if it takes 1 hr or more, it will finish

Step 3. How to use pyinstaller type: python -m PyInstaller --onefile *.py

There are flags: --noconsole > disables the console when you run the app --onefile > compress all of the code into one file --icon > the *.ico file after you type it will be set as the app icon.

## How to install VertexEngine/Vertex:
Step 1: Type in pip install VertexEngine

Step 2: Wait a few min, don't worry if it takes 1 hr or more, it will finish

Pygame or PyQt6 systems are compatible with Vertex so you can use pygame collision system or PyQt6's UI system in VertexEngine.

## Dependencies
Vertex obviously has heavy dependencies since it's a game engine, the following requirements are:

| Dependency       | Version                              |
|------------------|--------------------------------------|
| PyQt6            | >=6.7                                |   
| Pygame           | >=2.0                                |
| Python           | >=3.10                               |

## About Me ❔
I Am a solo developer in Diliman, Quezon City that makes things for fun :)
Address: 53 RD 3, BG-PGASA, QC

## 📄 License
VertexEngine/Vertex is Managed by the MIT License. This license allows others to tweak the code. However, you need to have the LICENSE file from this library and add it to your library, attribution also required.