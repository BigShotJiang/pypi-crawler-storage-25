This web app uses:

- FastAPI
- htmx (v2)
- Tailwind CSS (v4) 

Pay attention to the versions that are used.
