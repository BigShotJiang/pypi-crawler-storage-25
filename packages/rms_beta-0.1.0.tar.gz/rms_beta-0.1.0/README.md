# RMS (Remote Management System)

RMS는 파이썬 기반의 원격 관리 및 데이터 통신을 위한 라이브러리입니다. 
PyQt5를 활용한 UI 지원과 다양한 통신 프로토콜(MQTT, Modbus 등)을 통합 관리할 수 있습니다.

## 설치 방법

현재 이 패키지는 PyPI를 통해 설치할 수 있습니다 (등록 후 기준):

```bash
pip install rms-beta