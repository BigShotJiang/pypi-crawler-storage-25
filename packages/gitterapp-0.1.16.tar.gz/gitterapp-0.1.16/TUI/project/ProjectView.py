from pathlib import Path

from rich.text import Text
from textual import on, events
from textual.app import App, ComposeResult
from textual.message import Message
from textual.widgets import Static, Label
from textual.containers import VerticalScroll, Horizontal, Vertical

from TUI.project.ReleaseNotes import ReleaseNotesView
from TUI.project.add_or_edit_project import AddOrEditProject
from model import Project
from model.MainFileManager import MainFileManager
from TUI.debug.rich_log import GitterLogger


class ProjectView(Static):
    class RefreshRequested(Message):
        """Message to request all ProjectView instances to refresh."""
        pass

    class ResizeRequested(Message):
        def __init__(self, width: str=None, height: str=None):
            self.width = width
            self.height = height
            super().__init__()

    class ProjectSelected(Message):
        def __init__(self, project):
            self.project = project
            super().__init__()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title = MainFileManager.shared.name
        self.projects = MainFileManager.shared.projects
        self.widthClass = "project_view_split_width"
        self.classes = self.main_container_class()
        self.selected_project = None

    @staticmethod
    def _issues_label(project) -> Text:
        release_name = project.first_issues_release_name()
        issues_str = project.issues_string_for_release()
        text = Text(issues_str)
        if release_name == "Next release":
            text.stylize("yellow")
        return text

    @staticmethod
    def _project_name_label(project) -> Text:
        s = project.status
        has_changes = s is not None and (
            s.state != "up to date"
            or len(s.stagedFiles) > 0
            or len(s.unstagedFiles) > 0
            or len(s.filesUntracked) > 0
        )
        text = Text(project.name)
        text.stylize("yellow" if has_changes else "green")
        return text

    def main_container_class(self):
        return f"project_view {self.widthClass}"

    def compose(self) -> ComposeResult:
        self.classes = self.main_container_class()

        with Vertical():
            yield Horizontal(
                Label("Project Name", classes="header name"),
                Label("Release", classes="header release"),
                Label("Directory", classes="header directory"),
                Label("Status", classes="header status"),
                Label("Next/Last Release", classes="header issues_list"),
                classes="row header-row"
            )

            with VerticalScroll(id="project_list"):
                for i, project in enumerate(self.projects):
                    row = Horizontal(
                        Label(self._project_name_label(project), classes="name"),
                        Label(f"{project.release_summary()}", classes="release"),
                        Label(project.directory.replace(str(Path.home()), "~"), classes="directory"),
                        Label(project.status.to_rich() if project.status else "", classes="status"),
                        Label(self._issues_label(project), classes="issues_list"),
                        classes="row",
                        id=f"project_row_{i}"
                    )
                    row.can_focus = True
                    yield row

    def on_mount(self) -> None:
        self.border_title = self.title
        self.set_interval(90, self.update_all)

    @on(events.Click)
    def on_row_click(self, event: events.Click) -> None:
        widget = event.control
        while widget is not None and widget is not self:
            if widget.id and widget.id.startswith("project_row_"):
                index = int(widget.id.split("_")[-1])
                self.selected_project = self.projects[index]
                if event.chain == 1:
                    GitterLogger.log(f"Selected project: {self.selected_project.name}")
                    self.post_message(ProjectView.ProjectSelected(self.selected_project))
                elif event.chain == 2:
                    self.app.push_screen(AddOrEditProject(self.selected_project), callback=self.on_project_edited)
                return
            widget = widget.parent


    def on_project_edited(self, project: Project ) -> None:
        if project is None:
            return
        for i, p in enumerate(self.projects):
            if p.name == self.selected_project.name:
                self.projects[i] = project
                break
        MainFileManager.shared.projects = self.projects
        self.refresh(recompose=True)

        MainFileManager.save_shared_to_json(str(Path.home() / ".gitter"))

    def refresh_table(self) -> None:
        project_list = self.query_one("#project_list", VerticalScroll)
        project_list.remove_children()

        for project in self.projects:
            row = Horizontal(
                Label(self._project_name_label(project), classes="name"),
                Label(project.directory.replace(str(Path.home()), "~"), classes="directory"),
                Label(project.status.to_rich() if project.status else "", classes="status"),
                classes="row"
            )
            row.can_focus = True
            project_list.mount(row)

    def update_all(self):

        GitterLogger.log( "Updating all projects" )
        for project in self.projects:
            project.update()

            # GitterLogger.log( f"*****************************\nProject {project.name}\n*****************************" )
            # GitterLogger.log( project.releases )

        #self.refresh( recompose=True )
        self.app.query_one(ProjectView).refresh(recompose=True)
        self.app.query_one(ReleaseNotesView).refresh(recompose=True)

    @on(RefreshRequested)
    def handle_refresh_requested(self, message: RefreshRequested) -> None:
        """Handle refresh request message."""
        self.update_all()

    @on(ResizeRequested)
    def handle_view_click(self, message: ResizeRequested) -> None:
        GitterLogger.log(f"ResizeRequested received - width: {message.width}, height: {message.height}")
        if message.width:
            self.widthClass = message.width

        if message.height:
            self.heightClass = message.height

        self.classes = self.main_container_class()
        self.refresh( recompose=True )
        GitterLogger.log( "View menu clicked (ProjectView)" )

    def generate_release_notes_markdown(self) -> str:
        """Generate markdown content from all project releases."""
        markdown_lines = ["# Release Notes\n"]

        for project in self.projects:
            if project.releases:
                markdown_lines.append(f"## {project.name}\n")
                for release in project.releases:
                    markdown_lines.append(f"### {release.name}\n")
                    if release.issues:
                        for issue in release.issues:
                            markdown_lines.append(f"- {issue.title}\n")
                    else:
                        markdown_lines.append("- No issues listed\n")
                    markdown_lines.append("\n")

        if len(markdown_lines) == 1:
            markdown_lines.append("No releases found.\n")

        return "".join(markdown_lines)

class ProjectApp(App):
    CSS_PATH = "TUI/project/project_view.tcss"

    def compose(self) -> ComposeResult:
        yield ProjectView()

if __name__ == "__main__":
    app = ProjectApp()
    app.run()
