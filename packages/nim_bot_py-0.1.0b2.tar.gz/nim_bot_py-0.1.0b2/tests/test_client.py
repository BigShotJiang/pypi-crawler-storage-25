import pytest

from nim_bot_py.client import MultiNimClient, NimClient
from nim_bot_py.models import InboundMessage, NimCredentials


class FakeBridge:
    def __init__(self):
        self.started = False
        self.stopped = False
        self.sent = []
        self.event_handler = None

    async def start(self, config, *, event_handler=None):
        self.started = True
        self.event_handler = event_handler

    async def stop(self):
        self.stopped = True

    async def health(self):
        return {"connected": True}

    async def send_message(self, *, chat_id, text, session_type):
        self.sent.append({"chat_id": chat_id, "text": text, "session_type": session_type})
        return {"message_id": "m-1", "client_message_id": "c-1"}

    async def ack_message(self, payload):
        return {"acknowledged": True, "payload": payload}

    async def mark_conversation_read(self, conversation_id):
        return {"acknowledged": True, "conversation_id": conversation_id}


@pytest.mark.asyncio
async def test_send_splits_long_messages():
    bridge = FakeBridge()
    client = NimClient(
        credentials=NimCredentials("app", "bot", "secret"),
        bridge=bridge,
    )

    content = ("a" * NimClient.MAX_MESSAGE_LENGTH) + "\n" + ("b" * 8)
    responses = await client.send_text("user:123", content)

    assert len(responses) == 2
    assert bridge.sent == [
        {"chat_id": "user:123", "text": "a" * NimClient.MAX_MESSAGE_LENGTH, "session_type": "p2p"},
        {"chat_id": "user:123", "text": "\n" + ("b" * 8), "session_type": "p2p"},
    ]


@pytest.mark.asyncio
async def test_send_qchat_uses_qchat_session_type():
    bridge = FakeBridge()
    client = NimClient(
        credentials=NimCredentials("app", "bot", "secret"),
        bridge=bridge,
    )

    responses = await client.send_text("qchat:server-1:channel-2", "hello")

    assert len(responses) == 1
    assert bridge.sent == [
        {
            "chat_id": "qchat:server-1:channel-2",
            "text": "hello",
            "session_type": "qchat",
        }
    ]


@pytest.mark.asyncio
async def test_client_dispatches_inbound_messages():
    bridge = FakeBridge()
    client = NimClient(
        credentials=NimCredentials("app", "bot", "secret"),
        bridge=bridge,
    )
    received = []
    client.on_message(received.append)

    await client.connect()
    await bridge.event_handler(
        {
            "type": "event",
            "event": "message",
            "payload": {
                "message_id": "m-1",
                "client_message_id": "c-1",
                "message_source": 1,
                "session_type": "p2p",
                "sender_id": "u1",
                "target_id": "bot",
                "conversation_id": "0|1|u1",
                "message_type": "text",
                "text": "hello",
            },
        }
    )

    assert len(received) == 1
    assert isinstance(received[0], InboundMessage)
    assert received[0].text == "hello"
    assert received[0].message_source == 1


@pytest.mark.asyncio
async def test_multi_client_routes_by_prefix():
    main = NimClient(credentials=NimCredentials("app", "main", "secret"), instance_name="main", bridge=FakeBridge())
    work = NimClient(credentials=NimCredentials("app", "work", "secret"), instance_name="work", bridge=FakeBridge())
    client = MultiNimClient([main, work])

    await client.send_text("work/user:42", "hello")

    assert work._bridge.sent == [{"chat_id": "user:42", "text": "hello", "session_type": "p2p"}]
    assert main._bridge.sent == []


@pytest.mark.asyncio
async def test_multi_client_routes_prefixed_qchat():
    main = NimClient(credentials=NimCredentials("app", "main", "secret"), instance_name="main", bridge=FakeBridge())
    work = NimClient(credentials=NimCredentials("app", "work", "secret"), instance_name="work", bridge=FakeBridge())
    client = MultiNimClient([main, work])

    await client.send_text("work/qchat:server-1:channel-2", "hello")

    assert work._bridge.sent == [
        {
            "chat_id": "qchat:server-1:channel-2",
            "text": "hello",
            "session_type": "qchat",
        }
    ]
    assert main._bridge.sent == []


@pytest.mark.asyncio
async def test_multi_client_rejects_unknown_instance():
    main = NimClient(credentials=NimCredentials("app", "main", "secret"), instance_name="main", bridge=FakeBridge())
    client = MultiNimClient([main])

    with pytest.raises(KeyError, match="unknown NIM instance"):
        await client.send_text("other/user:42", "hello")
