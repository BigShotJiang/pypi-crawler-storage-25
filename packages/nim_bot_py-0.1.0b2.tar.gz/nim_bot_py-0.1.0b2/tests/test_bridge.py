import asyncio
from types import SimpleNamespace

import pytest

from nim_bot_py.bridge import NimBridgeError, NodeBridge


@pytest.mark.asyncio
async def test_dispatch_stdout_does_not_block_on_async_event_handler():
    gate = asyncio.Event()
    handled = asyncio.Event()

    async def event_handler(_message):
        handled.set()
        await gate.wait()

    bridge = NodeBridge(["node", "fake.mjs"], auto_install=False)
    bridge._event_handler = event_handler

    loop = asyncio.get_running_loop()
    future = loop.create_future()
    bridge._pending["1"] = future

    await bridge._dispatch_stdout({"type": "event", "event": "message", "payload": {}})
    await asyncio.wait_for(handled.wait(), timeout=1)
    await bridge._dispatch_stdout({"type": "response", "id": "1", "status": "ok", "result": {"ok": True}})
    assert future.result()["result"] == {"ok": True}

    gate.set()
    await asyncio.gather(*bridge._event_tasks)


class _FakeStream:
    def __init__(self, chunks=None):
        self.closed = False
        self._chunks = list(chunks or [])

    async def readline(self):
        return b""

    async def read(self, _size):
        if self._chunks:
            return self._chunks.pop(0)
        return b""

    def is_closing(self):
        return self.closed

    def close(self):
        self.closed = True


class _FakeProcess:
    def __init__(self):
        self.stdin = _FakeStream()
        self.stdout = _FakeStream()
        self.stderr = _FakeStream()
        self.returncode = None
        self.terminated = False
        self.killed = False

    def terminate(self):
        self.terminated = True
        self.returncode = 1

    def kill(self):
        self.killed = True
        self.returncode = 1

    async def wait(self):
        if self.returncode is None:
            self.returncode = 0
        return self.returncode


@pytest.mark.asyncio
async def test_start_cleans_up_subprocess_when_connect_fails(monkeypatch):
    process = _FakeProcess()

    async def fake_create_subprocess_exec(*_args, **_kwargs):
        return process

    async def fake_request(self, method, params):
        raise NimBridgeError("connect failed")

    monkeypatch.setattr(asyncio, "create_subprocess_exec", fake_create_subprocess_exec)
    monkeypatch.setattr(NodeBridge, "request", fake_request)

    bridge = NodeBridge(["node", "fake.mjs"], auto_install=False)
    config = SimpleNamespace(to_bridge_payload=lambda: {"credentials": {}})

    with pytest.raises(NimBridgeError, match="connect failed"):
        await bridge.start(config=config)

    assert process.terminated is True
    assert bridge._process is None


@pytest.mark.asyncio
async def test_read_stderr_handles_long_lines(caplog):
    caplog.set_level("DEBUG")
    bridge = NodeBridge(["node", "fake.mjs"], auto_install=False)
    long_line = (b"x" * 70000) + b"\n"
    bridge._process = SimpleNamespace(stderr=_FakeStream(chunks=[long_line, b"tail\n", b""]))

    await bridge._read_stderr()

    messages = [record.message for record in caplog.records if "nim bridge stderr:" in record.message]
    assert any(message.endswith("tail") for message in messages)
    assert any(len(message) > 65000 for message in messages)
