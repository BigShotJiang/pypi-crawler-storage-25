from nim_bot_py.protocol import decode_jsonl_line, encode_jsonl


def test_jsonl_roundtrip():
    payload = {"type": "response", "status": "ok", "result": {"hello": "world"}}
    assert decode_jsonl_line(encode_jsonl(payload)) == payload
