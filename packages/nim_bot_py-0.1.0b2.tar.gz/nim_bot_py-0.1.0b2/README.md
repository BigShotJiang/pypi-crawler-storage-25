# nim-bot-py

`nim-bot-py` 是 `@yxim/nim-bot` 的轻量 Python 封装。

项目保持明确的职责边界：

- Node.js 负责 NIM SDK 运行时
- Python 负责配置、路由、重试与业务集成

## 安装

```bash
pip install -e .[dev]
```

运行时依赖：

- `node`
- `npm`

首次调用 `connect()` 时，会自动将 `@yxim/nim-bot` 安装到内置的 bridge 目录中。

## 示例

```python
import asyncio

from nim_bot_py import NimClient, NimCredentials


async def main() -> None:
    client = NimClient(
        credentials=NimCredentials(
            app_key="your-app-key",
            account="your-bot-account",
            token="your-token",
        ),
        debug=True,
    )

    client.on_message(lambda message: print(message.text))

    await client.connect()
    await client.send_text("user:123456", "hello from python")


asyncio.run(main())
```

## API 概览

- `NimClient`：单个 NIM 实例
- `MultiNimClient`：支持路由的多实例封装
- `NodeBridge`：底层 JSONL 桥接客户端

核心方法：

- `connect()`
- `disconnect()`
- `health()`
- `send_text()`
- `ack_message()`
- `mark_conversation_read()`