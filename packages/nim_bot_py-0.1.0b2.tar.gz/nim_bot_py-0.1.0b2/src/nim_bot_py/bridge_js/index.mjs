#!/usr/bin/env node
import process from "node:process";
import readline from "node:readline";

import {
  buildConversationId,
  isOnlineMessageSource,
  normalizeTarget,
  parseBridgeConfig,
  toInboundMessage,
  toQChatInboundMessage,
} from "./src/config.mjs";
import { decodeJsonl, errorResponse, eventMessage, okResponse, writeMessage } from "./src/protocol.mjs";
import { acknowledgeInboundMessage, markConversationRead } from "./src/read_receipts.mjs";

let runtime = null;

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function writeStderr(args) {
  process.stderr.write(
    `${args.map((value) => (typeof value === "string" ? value : JSON.stringify(value))).join(" ")}\n`,
  );
}

console.log = (...args) => writeStderr(args);
console.info = (...args) => writeStderr(args);
console.warn = (...args) => writeStderr(args);
console.error = (...args) => writeStderr(args);

function emit(message) {
  writeMessage(process.stdout, message);
}

async function cleanupRuntime() {
  if (!runtime) {
    return;
  }
  try {
    await runtime.loginService.logout();
  } catch {}
  try {
    await runtime.nim.destroy?.();
  } catch {}
  runtime = null;
}

async function discoverQChatServers(nim) {
  const qchatServer = nim?.qchatServer;
  if (!qchatServer?.getServersByPage) {
    return [];
  }

  const serverIds = [];
  let timestamp = 0;
  const pageLimit = 100;

  for (let page = 0; page < 20; page += 1) {
    const response = await qchatServer.getServersByPage({
      timestamp,
      limit: pageLimit,
    });
    const servers = response?.datas ?? [];
    if (servers.length === 0) {
      break;
    }

    for (const server of servers) {
      if (server?.serverId) {
        serverIds.push(String(server.serverId));
      }
    }

    const hasMore = response?.listQueryTag?.hasMore ?? servers.length >= pageLimit;
    if (!hasMore) {
      break;
    }

    const lastServer = servers[servers.length - 1];
    if (!lastServer?.createTime) {
      break;
    }
    timestamp = lastServer.createTime;
  }

  return [...new Set(serverIds)];
}

async function activateQChat(nim) {
  const qchatServer = nim?.qchatServer;
  if (!qchatServer?.subscribeAllChannel) {
    return;
  }

  const serverIds = await discoverQChatServers(nim);
  if (serverIds.length === 0) {
    console.info("[qchat] no joined servers discovered");
    return;
  }

  let remaining = [...serverIds];
  const subscribed = new Set();

  for (let attempt = 1; attempt <= 3 && remaining.length > 0; attempt += 1) {
    try {
      const response = await qchatServer.subscribeAllChannel({
        type: 1,
        serverIds: remaining,
      });
      const failedServerIds = (response?.failServerIds ?? []).map((id) => String(id));
      for (const serverId of remaining) {
        if (!failedServerIds.includes(serverId)) {
          subscribed.add(serverId);
        }
      }
      remaining = failedServerIds;
      if (remaining.length > 0) {
        console.warn(`[qchat] subscribe retry=${attempt} remaining=${remaining.join(",")}`);
        await sleep(1000 * attempt);
      }
    } catch (error) {
      console.warn(`[qchat] subscribe attempt=${attempt} failed`, error);
      await sleep(1000 * attempt);
    }
  }

  console.info(
    `[qchat] subscribed servers=${[...subscribed].join(",") || "none"} failed=${remaining.join(",") || "none"}`,
  );
}

async function handleConnect(id, params) {
  await cleanupRuntime();
  const config = parseBridgeConfig(params?.config ?? {});
  const mod = await import("@yxim/nim-bot");
  const NIM = mod.default ?? mod;
  const nim = new NIM(
    {
      appkey: config.credentials.appKey,
      apiVersion: "v2",
      debugLevel: config.debug ? "debug" : "off",
    },
    undefined,
  );

  const loginService = nim.V2NIMLoginService;
  const messageService = nim.V2NIMMessageService;
  const messageCreator = nim.V2NIMMessageCreator;
  const conversationService = nim.V2NIMConversationService ?? nim.V2NIMLocalConversationService;
  const qchatMsg = nim.qchatMsg;
  let readyForEvents = false;

  if (!loginService || !messageService || !messageCreator) {
    throw new Error("NIM SDK V2 services are unavailable");
  }

  messageService.on("onReceiveMessages", (messages = []) => {
    if (!readyForEvents) {
      return;
    }
    for (const message of messages) {
      if (!isOnlineMessageSource(message)) {
        console.info(
          `[nim] skipping non-online inbound message source=${message?.messageSource ?? message?.message_source ?? "unknown"} `
            + `msgId=${message?.messageServerId ?? message?.messageClientId ?? "unknown"}`,
        );
        continue;
      }
      void acknowledgeInboundMessage({
        message,
        botAccount: config.credentials.account,
        messageService,
        conversationService,
        logger: console,
      }).catch((error) => {
        console.warn("failed to acknowledge inbound NIM message", error);
      });
      emit(eventMessage("message", toInboundMessage(message, config.credentials.account)));
    }
  });

  qchatMsg?.on("message", (message) => {
    if (!readyForEvents) {
      return;
    }
    if (!isOnlineMessageSource(message)) {
      console.info(
        `[nim] skipping non-online qchat message source=${message?.messageSource ?? message?.message_source ?? "unknown"} `
          + `msgId=${message?.msgIdServer ?? message?.msgIdClient ?? "unknown"}`,
      );
      return;
    }
    emit(eventMessage("message", toQChatInboundMessage(message, config.credentials.account)));
  });

  await loginService.login(config.credentials.account, config.credentials.token, { aiBot: 2 });
  runtime = { nim, loginService, messageService, messageCreator, conversationService, qchatMsg, config };
  emit(okResponse(id, { connected: true, account: config.credentials.account }));
  readyForEvents = true;
  void activateQChat(nim).catch((error) => {
    console.warn("[qchat] activation failed", error);
  });
}

async function handleDisconnect(id) {
  await cleanupRuntime();
  emit(okResponse(id, { connected: false }));
}

async function handleHealth(id) {
  emit(okResponse(id, { connected: Boolean(runtime), account: runtime?.config?.credentials?.account ?? null }));
}

async function handleSendMessage(id, params) {
  if (!runtime) {
    throw new Error("bridge is not connected");
  }

  const target = normalizeTarget(params?.chat_id, params?.session_type);
  if (target.sessionType === "qchat") {
    if (!runtime.qchatMsg?.sendMessage) {
      throw new Error("qchat send is unavailable");
    }
    const response = await runtime.qchatMsg.sendMessage({
      serverId: target.serverId,
      channelId: target.channelId,
      type: "text",
      body: String(params?.text ?? ""),
    });
    emit(
      okResponse(id, {
        message_id: String(response?.message?.msgIdServer ?? response?.msgIdServer ?? ""),
        client_message_id: String(response?.message?.msgIdClient ?? response?.msgIdClient ?? ""),
      }),
    );
    return;
  }
  const conversationId = buildConversationId(runtime.nim, target.id, target.sessionType);
  const message = runtime.messageCreator.createTextMessage(String(params?.text ?? ""));
  if (!message) {
    throw new Error("failed to create text message");
  }

  const result = await new Promise((resolve, reject) => {
    const clientMessageId = message.messageClientId;
    let settled = false;

    const listener = (sentMessage) => {
      if (settled || sentMessage?.messageClientId !== clientMessageId) {
        return;
      }
      if (sentMessage?.sendingState === 3) {
        return;
      }
      settled = true;
      runtime.messageService.off?.("onSendMessage", listener);
      const errorCode = sentMessage?.messageStatus?.errorCode;
      const failed = sentMessage?.sendingState === 2 || (sentMessage?.sendingState === 1 && errorCode !== 200);
      if (failed) {
        reject(new Error(sentMessage?.messageStatus?.errorDesc ?? `send failed (${errorCode ?? "unknown"})`));
        return;
      }
      resolve({
        message_id: String(sentMessage?.messageServerId ?? ""),
        client_message_id: String(sentMessage?.messageClientId ?? ""),
      });
    };

    runtime.messageService.on("onSendMessage", listener);
    runtime.messageService.sendMessage(message, conversationId, {}).catch((error) => {
      if (settled) {
        return;
      }
      settled = true;
      runtime.messageService.off?.("onSendMessage", listener);
      reject(error);
    });
  });

  emit(okResponse(id, result));
}

async function handleAckMessage(id, params) {
  if (!runtime) {
    throw new Error("bridge is not connected");
  }
  const result = await acknowledgeInboundMessage({
    message: params?.message?.raw ?? params?.message ?? {},
    botAccount: runtime.config.credentials.account,
    messageService: runtime.messageService,
    conversationService: runtime.conversationService,
    logger: console,
  });
  emit(okResponse(id, result ?? { acknowledged: true }));
}

async function handleMarkConversationRead(id, params) {
  if (!runtime) {
    throw new Error("bridge is not connected");
  }
  await markConversationRead(runtime.conversationService, String(params?.conversation_id ?? ""));
  emit(okResponse(id, { acknowledged: true }));
}

async function handleRequest(message) {
  const id = String(message?.id ?? "");
  const method = message?.method;
  try {
    if (method === "connect") {
      await handleConnect(id, message?.params);
      return;
    }
    if (method === "disconnect") {
      await handleDisconnect(id);
      return;
    }
    if (method === "health") {
      await handleHealth(id);
      return;
    }
    if (method === "send_message") {
      await handleSendMessage(id, message?.params);
      return;
    }
    if (method === "ack_message") {
      await handleAckMessage(id, message?.params);
      return;
    }
    if (method === "mark_conversation_read") {
      await handleMarkConversationRead(id, message?.params);
      return;
    }
    throw new Error(`unsupported method: ${method}`);
  } catch (error) {
    emit(errorResponse(id, error instanceof Error ? error.message : String(error)));
  }
}

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });

rl.on("line", async (line) => {
  try {
    const message = decodeJsonl(line);
    if (message?.type !== "request") {
      return;
    }
    await handleRequest(message);
  } catch (error) {
    emit(errorResponse("", error instanceof Error ? error.message : String(error)));
  }
});

process.on("SIGINT", async () => {
  await cleanupRuntime();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await cleanupRuntime();
  process.exit(0);
});
