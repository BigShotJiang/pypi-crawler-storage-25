export function writeMessage(stream, message) {
  stream.write(`${JSON.stringify(message)}\n`);
}

export function decodeJsonl(line) {
  const text = String(line ?? "").trim();
  if (!text) {
    throw new Error("empty JSONL line");
  }
  return JSON.parse(text);
}

export function okResponse(id, result) {
  return { id, type: "response", status: "ok", result };
}

export function errorResponse(id, message, code = "BRIDGE_ERROR") {
  return {
    id,
    type: "response",
    status: "error",
    error: { code, message },
  };
}

export function eventMessage(event, payload) {
  return { type: "event", event, payload };
}
