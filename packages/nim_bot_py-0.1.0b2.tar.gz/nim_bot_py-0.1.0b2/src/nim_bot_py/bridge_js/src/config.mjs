export const V2NIM_MESSAGE_SOURCE_ONLINE = 1;

export function normalizeMessageSource(messageOrSource) {
  if (messageOrSource == null) {
    return undefined;
  }
  if (typeof messageOrSource === "number") {
    return Number.isFinite(messageOrSource) ? messageOrSource : undefined;
  }
  if (typeof messageOrSource === "string") {
    const parsed = Number(messageOrSource);
    return Number.isFinite(parsed) ? parsed : undefined;
  }
  const raw =
    messageOrSource?.messageSource ??
    messageOrSource?.message_source ??
    messageOrSource?.msgSource ??
    messageOrSource?.msg_source;
  if (raw == null || raw === "") {
    return undefined;
  }
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function isOnlineMessageSource(messageOrSource) {
  const source = normalizeMessageSource(messageOrSource);
  return source === undefined || source === V2NIM_MESSAGE_SOURCE_ONLINE;
}

export function parseBridgeConfig(raw) {
  const credentials = raw?.credentials ?? {};
  const config = {
    credentials: {
      appKey: String(credentials.app_key ?? credentials.appKey ?? ""),
      account: String(credentials.account ?? ""),
      token: String(credentials.token ?? ""),
    },
    debug: Boolean(raw?.debug),
    mediaMaxMb: Number(raw?.media_max_mb ?? raw?.mediaMaxMb ?? 30),
    homeChannel: raw?.home_channel ?? raw?.homeChannel ?? null,
  };

  if (!config.credentials.appKey || !config.credentials.account || !config.credentials.token) {
    throw new Error("bridge credentials are incomplete");
  }
  return config;
}

export function normalizeTarget(chatId, fallbackSessionType = "p2p") {
  const raw = String(chatId ?? "").trim();
  if (!raw) {
    throw new Error("chat_id is required");
  }
  if (raw.startsWith("qchat:")) {
    const value = raw.slice("qchat:".length);
    const [serverId, channelId] = value.split(":", 2);
    if (!serverId || !channelId) {
      throw new Error(`invalid qchat target: ${raw}`);
    }
    return {
      id: `${serverId}:${channelId}`,
      serverId,
      channelId,
      sessionType: "qchat",
    };
  }
  if (raw.startsWith("team:") || raw.startsWith("group:")) {
    return { id: raw.slice(raw.indexOf(":") + 1), sessionType: "team" };
  }
  if (raw.startsWith("user:") || raw.startsWith("nim:")) {
    return { id: raw.slice(raw.indexOf(":") + 1), sessionType: "p2p" };
  }
  return { id: raw, sessionType: fallbackSessionType };
}

export function buildConversationId(nim, targetId, sessionType) {
  const util = nim?.V2NIMConversationIdUtil;
  if (util) {
    if (sessionType === "team") {
      return util.teamConversationId(targetId) || `0|2|${targetId}`;
    }
    if (sessionType === "superTeam") {
      return util.superTeamConversationId(targetId) || `0|3|${targetId}`;
    }
    return util.p2pConversationId(targetId) || `0|1|${targetId}`;
  }
  const typeNumber = sessionType === "team" ? 2 : sessionType === "superTeam" ? 3 : 1;
  return `0|${typeNumber}|${targetId}`;
}

export function parseConversationId(conversationId) {
  const parts = String(conversationId ?? "").split("|");
  if (parts.length < 3) {
    return { sessionType: "p2p", targetId: "" };
  }
  const typeNumber = Number(parts[1]);
  return {
    sessionType: typeNumber === 2 ? "team" : typeNumber === 3 ? "superTeam" : "p2p",
    targetId: parts[2],
  };
}

export function toInboundMessage(message, botAccount) {
  const parsed = parseConversationId(message?.conversationId);
  const pushIds = message?.pushConfig?.forcePushAccountIds ?? [];
  const mentioned = pushIds.includes(botAccount);
  const typeMap = {
    0: "text",
    1: "image",
    2: "audio",
    3: "video",
    6: "file",
  };

  return {
    message_id: String(message?.messageServerId ?? message?.messageClientId ?? ""),
    client_message_id: String(message?.messageClientId ?? ""),
    message_source: normalizeMessageSource(message),
    session_type: parsed.sessionType,
    sender_id: String(message?.senderId ?? ""),
    sender_name: message?.senderName ?? null,
    target_id: String(message?.receiverId ?? parsed.targetId ?? ""),
    conversation_id: String(message?.conversationId ?? ""),
    conversation_name: null,
    text: message?.text ?? "",
    message_type: typeMap[message?.messageType] ?? "unknown",
    force_push_account_ids: pushIds,
    mentioned,
    mention_all: false,
    from_self: String(message?.senderId ?? "") === String(botAccount ?? ""),
    reply_to: null,
    raw: message,
  };
}

export function toQChatInboundMessage(message, botAccount) {
  const serverId = String(message?.serverId ?? message?.server_id ?? "");
  const channelId = String(message?.channelId ?? message?.channel_id ?? "");
  const senderId = String(message?.fromAccount ?? message?.from_accid ?? "");
  const text = String(message?.body ?? message?.msg_body ?? "");
  const mentionAccids = (message?.mentionAccids ?? message?.mention_accids ?? []).map((item) =>
    String(item),
  );
  const mentionAll = Boolean(message?.mentionAll ?? message?.mention_all);
  const mentioned = mentionAll || mentionAccids.includes(String(botAccount ?? ""));
  const messageType =
    String(message?.type ?? message?.msg_type ?? "text").toLowerCase() === "text" ? "text" : "unknown";

  return {
    message_id: String(message?.msgIdServer ?? message?.msg_server_id ?? ""),
    client_message_id: String(message?.msgIdClient ?? message?.msg_client_id ?? ""),
    message_source: normalizeMessageSource(message),
    session_type: "qchat",
    sender_id: senderId,
    sender_name: message?.fromNick ?? message?.from_nick ?? null,
    target_id: `${serverId}:${channelId}`,
    server_id: serverId,
    channel_id: channelId,
    conversation_id: "",
    conversation_name: null,
    text,
    message_type: messageType,
    force_push_account_ids: mentionAccids,
    mentioned,
    mention_all: mentionAll,
    from_self: senderId === String(botAccount ?? ""),
    reply_to: null,
    raw: message,
  };
}
