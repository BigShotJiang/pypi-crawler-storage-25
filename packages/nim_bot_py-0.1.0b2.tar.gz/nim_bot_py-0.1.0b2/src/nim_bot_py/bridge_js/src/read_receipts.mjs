import { isOnlineMessageSource } from "./config.mjs";

export async function markConversationRead(conversationService, conversationId) {
  if (!conversationId || typeof conversationService?.markConversationRead !== "function") {
    return;
  }
  await conversationService.markConversationRead(conversationId);
}

export async function acknowledgeInboundMessage({
  message,
  botAccount,
  messageService,
  conversationService,
  logger = console,
}) {
  const conversationType = Number(message?.conversationType ?? 0);
  if (String(message?.senderId ?? "") === String(botAccount ?? "")) {
    return { acknowledged: false, reason: "self_message" };
  }
  if (!isOnlineMessageSource(message)) {
    return { acknowledged: false, reason: "non_online_message" };
  }

  const conversationId = String(message?.conversationId ?? "");
  if (conversationType === 1) {
    await messageService?.sendP2PMessageReceipt?.(message);
    try {
      await markConversationRead(conversationService, conversationId);
    } catch (error) {
      logger.warn?.("markConversationRead failed", error);
    }
    return { acknowledged: true, conversationType: "p2p" };
  }

  if (conversationType === 2 || conversationType === 3) {
    await messageService?.sendTeamMessageReceipts?.([message]);
    return { acknowledged: true, conversationType: "team" };
  }

  return { acknowledged: false, reason: "unsupported_conversation_type" };
}
