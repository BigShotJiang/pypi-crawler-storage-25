from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class NimCredentials:
    app_key: str
    account: str
    token: str


@dataclass(slots=True)
class NimInstanceConfig:
    credentials: NimCredentials
    instance_name: str = "default"
    debug: bool = False
    media_max_mb: int = 30
    home_channel: str | None = None
    route_prefix: str | None = None

    def normalized_instance_name(self) -> str:
        raw = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in self.instance_name.strip())
        normalized = raw.strip("._-")
        return normalized or "default"

    def to_bridge_payload(self) -> dict[str, Any]:
        return {
            "credentials": {
                "app_key": self.credentials.app_key,
                "account": self.credentials.account,
                "token": self.credentials.token,
            },
            "debug": self.debug,
            "media_max_mb": self.media_max_mb,
            "home_channel": self.home_channel,
        }


@dataclass(slots=True)
class InboundMessage:
    message_id: str
    client_message_id: str
    message_source: int | None
    session_type: str
    sender_id: str
    target_id: str
    conversation_id: str
    message_type: str
    text: str
    mentioned: bool = False
    mention_all: bool = False
    from_self: bool = False
    sender_name: str | None = None
    conversation_name: str | None = None
    reply_to: str | None = None
    force_push_account_ids: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "InboundMessage":
        return cls(
            message_id=str(payload.get("message_id") or ""),
            client_message_id=str(payload.get("client_message_id") or ""),
            message_source=(
                int(payload["message_source"])
                if payload.get("message_source") not in (None, "")
                else None
            ),
            session_type=str(payload.get("session_type") or "p2p"),
            sender_id=str(payload.get("sender_id") or ""),
            target_id=str(payload.get("target_id") or ""),
            conversation_id=str(payload.get("conversation_id") or ""),
            message_type=str(payload.get("message_type") or "text"),
            text=str(payload.get("text") or ""),
            mentioned=bool(payload.get("mentioned")),
            mention_all=bool(payload.get("mention_all")),
            from_self=bool(payload.get("from_self")),
            sender_name=payload.get("sender_name"),
            conversation_name=payload.get("conversation_name"),
            reply_to=payload.get("reply_to"),
            force_push_account_ids=[str(item) for item in payload.get("force_push_account_ids") or []],
            raw=dict(payload.get("raw") or {}),
        )
