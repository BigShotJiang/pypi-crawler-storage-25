from __future__ import annotations

import asyncio
import contextlib
import logging
import shutil
import subprocess
from collections.abc import Awaitable, Callable, Sequence
from importlib import resources
from pathlib import Path
from typing import Any

from .models import NimInstanceConfig
from .protocol import decode_jsonl_line, encode_jsonl


logger = logging.getLogger(__name__)
BridgeEventHandler = Callable[[dict[str, Any]], Awaitable[None] | None]


class NimBridgeError(RuntimeError):
    pass


class NodeBridge:
    def __init__(
        self,
        command: Sequence[str] | None = None,
        *,
        cwd: str | None = None,
        request_timeout: float = 10.0,
        auto_install: bool = True,
    ) -> None:
        self._command = list(command or self.default_command())
        self._cwd = cwd or str(self.bridge_dir())
        self._request_timeout = request_timeout
        self._auto_install = auto_install
        self._process: asyncio.subprocess.Process | None = None
        self._event_handler: BridgeEventHandler | None = None
        self._pending: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self._event_tasks: set[asyncio.Task[Any]] = set()
        self._stdout_task: asyncio.Task[None] | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._next_id = 0

    @staticmethod
    def bridge_dir() -> Path:
        return Path(resources.files("nim_bot_py").joinpath("bridge_js"))

    @classmethod
    def default_command(cls) -> list[str]:
        return ["node", str(cls.bridge_dir() / "index.mjs")]

    def ensure_runtime(self) -> None:
        executable = self._command[0]
        if not shutil.which(executable):
            raise NimBridgeError(f"{executable} not found on PATH")
        if self._command == self.default_command() and self._auto_install:
            self.ensure_bundled_sdk()

    def ensure_bundled_sdk(self) -> None:
        bridge_dir = self.bridge_dir()
        package_json = bridge_dir / "package.json"
        sdk_dir = bridge_dir / "node_modules" / "@yxim" / "nim-bot"
        if sdk_dir.exists():
            return
        npm = shutil.which("npm")
        if not npm:
            raise NimBridgeError("npm not found on PATH; cannot install @yxim/nim-bot")
        if not package_json.exists():
            raise NimBridgeError(f"missing bridge package.json: {package_json}")
        subprocess.run(
            [npm, "install", "--no-fund", "--no-audit", "--prefix", str(bridge_dir)],
            check=True,
            capture_output=True,
            text=True,
        )
        if not sdk_dir.exists():
            raise NimBridgeError("failed to install @yxim/nim-bot into bundled bridge")

    async def start(self, config: NimInstanceConfig, *, event_handler: BridgeEventHandler | None = None) -> None:
        if self._process is not None:
            return
        self.ensure_runtime()
        self._event_handler = event_handler
        self._process = await asyncio.create_subprocess_exec(
            *self._command,
            cwd=self._cwd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        self._stdout_task = asyncio.create_task(self._read_stdout())
        self._stderr_task = asyncio.create_task(self._read_stderr())
        try:
            response = await self.request("connect", {"config": config.to_bridge_payload()})
            if response.get("status") != "ok":
                raise NimBridgeError(self._extract_error_message(response))
        except Exception:
            await self._cleanup_process()
            raise

    async def stop(self) -> None:
        if self._process is None:
            return
        try:
            await self.request("disconnect", {})
        except Exception:
            pass
        await self._cleanup_process()

    async def health(self) -> dict[str, Any]:
        response = await self.request("health", {})
        if response.get("status") != "ok":
            raise NimBridgeError(self._extract_error_message(response))
        return dict(response.get("result") or {})

    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        session_type: str = "p2p",
    ) -> dict[str, Any]:
        response = await self.request(
            "send_message",
            {"chat_id": chat_id, "text": text, "session_type": session_type},
        )
        if response.get("status") != "ok":
            raise NimBridgeError(self._extract_error_message(response))
        return dict(response.get("result") or {})

    async def ack_message(self, payload: dict[str, Any]) -> dict[str, Any]:
        response = await self.request("ack_message", {"message": payload})
        if response.get("status") != "ok":
            raise NimBridgeError(self._extract_error_message(response))
        return dict(response.get("result") or {})

    async def mark_conversation_read(self, conversation_id: str) -> dict[str, Any]:
        response = await self.request(
            "mark_conversation_read",
            {"conversation_id": conversation_id},
        )
        if response.get("status") != "ok":
            raise NimBridgeError(self._extract_error_message(response))
        return dict(response.get("result") or {})

    async def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        process = self._process
        if process is None or process.stdin is None:
            raise NimBridgeError("bridge process is not running")
        self._next_id += 1
        request_id = str(self._next_id)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[request_id] = future
        process.stdin.write(
            encode_jsonl(
                {
                    "id": request_id,
                    "type": "request",
                    "method": method,
                    "params": params,
                }
            )
        )
        await process.stdin.drain()
        try:
            return await asyncio.wait_for(future, timeout=self._request_timeout)
        finally:
            self._pending.pop(request_id, None)

    async def _dispatch_stdout(self, message: dict[str, Any]) -> None:
        message_type = message.get("type")
        if message_type == "response":
            request_id = str(message.get("id") or "")
            future = self._pending.get(request_id)
            if future is not None and not future.done():
                future.set_result(message)
            return
        if message_type == "event" and self._event_handler is not None:
            try:
                result = self._event_handler(message)
            except Exception:
                logger.exception("NIM bridge event handler failed")
                return
            if asyncio.iscoroutine(result):
                task = asyncio.create_task(result)
                self._event_tasks.add(task)
                task.add_done_callback(self._finalize_event_task)

    async def _read_stdout(self) -> None:
        assert self._process is not None
        assert self._process.stdout is not None
        while True:
            line = await self._process.stdout.readline()
            if not line:
                return
            await self._dispatch_stdout(decode_jsonl_line(line))

    async def _read_stderr(self) -> None:
        assert self._process is not None
        assert self._process.stderr is not None
        buffer = b""
        while True:
            chunk = await self._process.stderr.read(4096)
            if not chunk:
                if buffer:
                    logger.debug("nim bridge stderr: %s", buffer.decode("utf-8", errors="replace").rstrip())
                return
            buffer += chunk
            while True:
                newline_index = buffer.find(b"\n")
                if newline_index < 0:
                    break
                line = buffer[: newline_index + 1]
                buffer = buffer[newline_index + 1 :]
                logger.debug("nim bridge stderr: %s", line.decode("utf-8", errors="replace").rstrip())

    def _finalize_event_task(self, task: asyncio.Task[Any]) -> None:
        self._event_tasks.discard(task)
        with contextlib.suppress(asyncio.CancelledError):
            task.result()

    async def _cleanup_process(self) -> None:
        process = self._process
        if process is None:
            return
        if process.stdin is not None and not process.stdin.is_closing():
            process.stdin.close()
        if process.returncode is None:
            process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=5)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
        tasks_to_await: list[asyncio.Task[Any]] = []
        for task in (self._stdout_task, self._stderr_task):
            if task is not None and not task.done():
                task.cancel()
            if task is not None:
                tasks_to_await.append(task)
        for task in list(self._event_tasks):
            if not task.done():
                task.cancel()
            tasks_to_await.append(task)
        if tasks_to_await:
            await asyncio.gather(*tasks_to_await, return_exceptions=True)
        self._process = None
        self._stdout_task = None
        self._stderr_task = None

    @staticmethod
    def _extract_error_message(response: dict[str, Any]) -> str:
        error = response.get("error")
        if isinstance(error, dict):
            return str(error.get("message") or error.get("code") or "bridge request failed")
        return str(error or "bridge request failed")
