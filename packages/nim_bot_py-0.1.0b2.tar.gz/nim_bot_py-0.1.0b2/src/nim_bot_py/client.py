from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any

from .bridge import NodeBridge
from .models import InboundMessage, NimCredentials, NimInstanceConfig


MessageHandler = Callable[[InboundMessage], Awaitable[None] | None]


class NimClient:
    MAX_MESSAGE_LENGTH = 4000

    def __init__(
        self,
        *,
        credentials: NimCredentials,
        instance_name: str = "default",
        debug: bool = False,
        media_max_mb: int = 30,
        home_channel: str | None = None,
        bridge: NodeBridge | None = None,
    ) -> None:
        self.config = NimInstanceConfig(
            credentials=credentials,
            instance_name=instance_name,
            debug=debug,
            media_max_mb=media_max_mb,
            home_channel=home_channel,
        )
        self._bridge = bridge or NodeBridge()
        self._handlers: list[MessageHandler] = []
        self._connected = False

    @property
    def instance_name(self) -> str:
        return self.config.normalized_instance_name()

    @property
    def is_connected(self) -> bool:
        return self._connected

    def on_message(self, handler: MessageHandler) -> None:
        self._handlers.append(handler)

    async def connect(self) -> None:
        await self._bridge.start(self.config, event_handler=self._on_event)
        self._connected = True

    async def disconnect(self) -> None:
        await self._bridge.stop()
        self._connected = False

    async def health(self) -> dict[str, Any]:
        return await self._bridge.health()

    async def send_text(self, chat_id: str, text: str, *, session_type: str | None = None) -> list[dict[str, Any]]:
        normalized_session_type = session_type or self._infer_session_type(chat_id)
        responses = []
        for chunk in self._split_content(text):
            responses.append(
                await self._bridge.send_message(
                    chat_id=chat_id,
                    text=chunk,
                    session_type=normalized_session_type,
                )
            )
        return responses

    async def ack_message(self, message: InboundMessage) -> dict[str, Any]:
        return await self._bridge.ack_message(
            {
                "message_id": message.message_id,
                "client_message_id": message.client_message_id,
                "session_type": message.session_type,
                "conversation_id": message.conversation_id,
                "sender_id": message.sender_id,
                "target_id": message.target_id,
                "raw": message.raw,
            }
        )

    async def mark_conversation_read(self, conversation_id: str) -> dict[str, Any]:
        return await self._bridge.mark_conversation_read(conversation_id)

    async def _on_event(self, envelope: dict[str, Any]) -> None:
        if envelope.get("event") != "message":
            return
        payload = dict(envelope.get("payload") or {})
        message = InboundMessage.from_payload(payload)
        for handler in list(self._handlers):
            result = handler(message)
            if asyncio.iscoroutine(result):
                await result

    def _split_content(self, content: str) -> list[str]:
        if len(content) <= self.MAX_MESSAGE_LENGTH:
            return [content]
        chunks: list[str] = []
        remaining = content
        while remaining:
            if len(remaining) <= self.MAX_MESSAGE_LENGTH:
                chunks.append(remaining)
                break
            split_at = remaining.rfind("\n", 0, self.MAX_MESSAGE_LENGTH)
            if split_at > 0:
                chunks.append(remaining[: split_at + 1])
                remaining = remaining[split_at + 1 :]
                continue
            chunks.append(remaining[: self.MAX_MESSAGE_LENGTH])
            remaining = remaining[self.MAX_MESSAGE_LENGTH :]
        return chunks

    @staticmethod
    def _infer_session_type(chat_id: str) -> str:
        if chat_id.startswith("qchat:"):
            return "qchat"
        if chat_id.startswith(("team:", "group:")):
            return "team"
        return "p2p"


class MultiNimClient:
    def __init__(self, instances: list[NimClient]) -> None:
        self._instances = {instance.instance_name: instance for instance in instances}
        self._default_instance_name = next(iter(self._instances), None)

    async def connect(self) -> None:
        for client in self._instances.values():
            await client.connect()

    async def disconnect(self) -> None:
        for client in self._instances.values():
            await client.disconnect()

    async def health(self) -> dict[str, Any]:
        return {
            name: await client.health()
            for name, client in self._instances.items()
        }

    def on_message(self, handler: MessageHandler) -> None:
        for client in self._instances.values():
            client.on_message(handler)

    async def send_text(
        self,
        chat_id: str,
        text: str,
        *,
        instance_name: str | None = None,
        session_type: str | None = None,
    ) -> list[dict[str, Any]]:
        client, routed_chat_id = self._resolve_client(chat_id, instance_name=instance_name)
        return await client.send_text(routed_chat_id, text, session_type=session_type)

    def _resolve_client(self, chat_id: str, *, instance_name: str | None = None) -> tuple[NimClient, str]:
        requested = instance_name or None
        routed_instance, routed_chat_id = self._decode_routed_chat_id(chat_id)
        target_instance = requested or routed_instance or self._default_instance_name
        if target_instance is None or target_instance not in self._instances:
            raise KeyError(f"unknown NIM instance: {target_instance or routed_instance or requested}")
        if routed_instance and routed_instance != target_instance:
            raise KeyError(f"chat_id route prefix does not match requested instance: {chat_id}")
        return self._instances[target_instance], routed_chat_id if routed_instance else chat_id

    @staticmethod
    def _decode_routed_chat_id(chat_id: str) -> tuple[str | None, str]:
        prefix, sep, remainder = str(chat_id).partition("/")
        if not sep or not remainder:
            return None, str(chat_id)
        return prefix, remainder
