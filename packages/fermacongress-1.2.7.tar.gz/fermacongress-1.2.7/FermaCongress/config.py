import os

_PORTAL_ENV = {
    "admin":   "ADMIN_URL",
    "support": "SUPPORT_URL",
}


def get(portal: str) -> str:
    """Return the base URL for a portal, with no trailing slash."""
    env_var = _PORTAL_ENV.get(portal)
    if env_var is None:
        raise KeyError(f"Unknown portal '{portal}'. Expected: {list(_PORTAL_ENV)}")
    url = os.environ.get(env_var)
    if not url:
        raise EnvironmentError(
            f"Environment variable '{env_var}' is not set. "
            "Add it to your .env file or system environment variables."
        )
    return url.rstrip("/")
