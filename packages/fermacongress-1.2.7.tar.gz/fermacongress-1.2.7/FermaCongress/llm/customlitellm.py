import getpass
import os
import socket
import time

from langchain.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain.tools import BaseTool
from langchain_litellm import ChatLiteLLM

_LANGFUSE_ENV_VARS = ("LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY", "LANGFUSE_HOST")
_REQUIRED_ENV_VARS = ("LITELLM_BASE_URL", "LITELLM_API_KEY")
_RESERVED_LITELLM_KEYS = frozenset({"model", "api_base", "api_key"})


def _langfuse_enabled() -> bool:
    return all(os.environ.get(v) for v in _LANGFUSE_ENV_VARS)


class LLMAgent:
    _MAX_RETRIES = 3
    _RETRY_DELAY = 2  # seconds; multiplied by attempt number for linear backoff
    _MAX_TOOL_ROUNDS = 20

    def __init__(self, llm, llm_with_tools, tool_map, llm_structured, model_name, langfuse_client, llm_params=None):
        self._llm = llm
        self._llm_with_tools = llm_with_tools
        self._tool_map = tool_map
        self._llm_structured = llm_structured
        self._model_name = model_name
        self._langfuse_client = langfuse_client
        self._llm_params = llm_params or {}
        self._raw_response = None

    def invoke(
        self,
        task_name: str,
        system_prompt: str | None = None,
        user_prompt: str | None = None,
        prompt: str | None = None,
    ):
        messages = self._build_messages(system_prompt=system_prompt, user_prompt=user_prompt, prompt=prompt)
        if self._langfuse_client:
            return self._run_with_langfuse(task_name, messages)
        return self._run(messages)

    def _run(self, messages: list) -> AIMessage | None:
        if self._llm_structured is not None:
            raw = self._invoke_with_retry(lambda: self._llm_structured.invoke(messages))
            if raw is None:
                return None
            self._raw_response = raw.get("raw")
            return raw.get("parsed")

        if self._llm_with_tools is None:
            return self._invoke_with_retry(lambda: self._llm.invoke(messages))

        for _ in range(self._MAX_TOOL_ROUNDS):
            response = self._invoke_with_retry(lambda: self._llm_with_tools.invoke(messages))
            if response is None:
                return None

            messages.append(response)

            if not response.tool_calls:
                return response

            for tool_call in response.tool_calls:
                tool = self._tool_map.get(tool_call["name"])
                result = (
                    f"Error: unknown tool '{tool_call['name']}'"
                    if tool is None
                    else tool.invoke(tool_call["args"])
                )
                messages.append(ToolMessage(content=str(result), tool_call_id=tool_call["id"]))

        print(f"Exceeded max tool rounds ({self._MAX_TOOL_ROUNDS}).")
        return None

    def _run_with_langfuse(self, task_name: str, messages: list):
        try:
            from langfuse import propagate_attributes

            session_id = task_name.strip().replace(" ", "_")
            user_id = self._get_user_info()
            trace_input = {"messages": [{"role": m.type, "content": m.content} for m in messages]}
            span_ctx = self._langfuse_client.start_as_current_observation(
                as_type="generation",
                name=task_name,
                model=self._model_name,
                input=trace_input,
                metadata={**self._llm_params, "model": self._model_name},
            )
        except Exception as e:
            print(f"Langfuse setup failed: {e} — falling back to untraced call.")
            return self._run(messages)

        response = None
        self._raw_response = None
        with span_ctx as span:
            try:
                with propagate_attributes(session_id=session_id, user_id=user_id):
                    response = self._run(messages)
            except Exception as e:
                print(f"LLM run failed inside Langfuse span: {e}")

            try:
                if response is None:
                    span.update(level="ERROR", status_message="LLM call failed after all retries.")
                else:
                    output_content = response.content if hasattr(response, "content") else str(response)
                    usage_source = self._raw_response if self._raw_response is not None else response
                    usage_details, cost_details = self._extract_usage(usage_source)
                    span.update(
                        output={"content": output_content},
                        usage_details=usage_details or None,
                        cost_details=cost_details or None,
                    )
                self._langfuse_client.flush()
            except Exception as e:
                print(f"Langfuse post-processing failed: {e} — returning LLM response.")

        return response

    def _invoke_with_retry(self, llm_callable):
        for attempt in range(1, self._MAX_RETRIES + 1):
            try:
                return llm_callable()
            except Exception as e:
                print(f"LLM call failed (attempt {attempt}/{self._MAX_RETRIES}): {e}")
                if attempt < self._MAX_RETRIES:
                    time.sleep(self._RETRY_DELAY * attempt)
        print(f"LLM call failed after {self._MAX_RETRIES} attempts.")
        return None

    def _extract_usage(self, response) -> tuple[dict, dict]:
        usage_details = {}
        cost_details = {}

        um = getattr(response, "usage_metadata", None)
        if um:
            usage_details = {
                "input": um.get("input_tokens", 0),
                "output": um.get("output_tokens", 0),
                "total": um.get("total_tokens", 0),
            }

        if usage_details:
            try:
                import litellm
                from litellm import cost_per_token

                bare = self._model_name.split("/")[-1]
                matched = next(
                    (m for m in litellm.model_cost if m == bare or m.endswith(f"/{bare}")),
                    None,
                )
                for candidate in dict.fromkeys(filter(None, [bare, matched, self._model_name])):
                    try:
                        input_cost, output_cost = cost_per_token(
                            model=candidate,
                            prompt_tokens=usage_details["input"],
                            completion_tokens=usage_details["output"],
                        )
                        cost_details = {
                            "input": input_cost,
                            "output": output_cost,
                            "total": input_cost + output_cost,
                        }
                        break
                    except Exception:
                        continue
            except Exception as e:
                print(f"_extract_usage: cost calculation failed: {e}")

        return usage_details, cost_details

    def _build_messages(
        self,
        system_prompt: str | None,
        user_prompt: str | None,
        prompt: str | None,
    ) -> list:
        messages: list = []

        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))

        if prompt is not None:
            messages.append(HumanMessage(content=prompt))
        elif user_prompt is not None:
            messages.append(HumanMessage(content=user_prompt))

        if not any(isinstance(m, HumanMessage) for m in messages):
            raise ValueError(
                "At least one user message is required. Provide 'user_prompt' or 'prompt'."
            )

        return messages

    def flush(self) -> None:
        if self._langfuse_client is not None:
            self._langfuse_client.flush()

    @staticmethod
    def _get_user_info() -> str:
        try:
            computer = socket.gethostname()
        except Exception:
            computer = ""
        try:
            username = getpass.getuser()
        except Exception:
            username = ""
        value = f"{computer} {username}".strip()
        return value if value else "Unknown"


def get_agent(model: str, tools: list[BaseTool] | None = None, response_format=None, **kwargs) -> LLMAgent:
    missing = [v for v in _REQUIRED_ENV_VARS if not os.environ.get(v)]
    if missing:
        raise EnvironmentError(
            f"Missing required environment variable(s): {', '.join(missing)}. "
            "Set them before calling get_agent."
        )

    api_base = os.environ["LITELLM_BASE_URL"]
    api_key = os.environ["LITELLM_API_KEY"]

    safe_kwargs = {k: v for k, v in kwargs.items() if k not in _RESERVED_LITELLM_KEYS}
    llm = ChatLiteLLM(model=model, api_base=api_base, api_key=api_key, **safe_kwargs)
    llm_with_tools = llm.bind_tools(tools) if tools else None
    tool_map = {t.name: t for t in tools} if tools else {}
    llm_structured = llm.with_structured_output(response_format, include_raw=True) if response_format else None

    langfuse_client = None
    if _langfuse_enabled():
        try:
            from langfuse import get_client
            langfuse_client = get_client()
        except Exception as e:
            print(f"Langfuse init failed: {e} — traces will not be recorded.")

    return LLMAgent(
        llm=llm,
        llm_with_tools=llm_with_tools,
        tool_map=tool_map,
        llm_structured=llm_structured,
        model_name=model,
        langfuse_client=langfuse_client,
        llm_params=safe_kwargs,
    )


def invoke_llm(
    task_name: str,
    model: str,
    system_prompt: str | None = None,
    user_prompt: str | None = None,
    prompt: str | None = None,
    tools: list[BaseTool] | None = None,
    response_format=None,
    **kwargs,
):
    agent = get_agent(model=model, tools=tools, response_format=response_format, **kwargs)
    return agent.invoke(task_name=task_name, system_prompt=system_prompt, user_prompt=user_prompt, prompt=prompt)