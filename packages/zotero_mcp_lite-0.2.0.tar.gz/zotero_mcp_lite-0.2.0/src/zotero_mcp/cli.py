"""
Command-line interface for Zotero MCP Lite server.
"""

import argparse
import os
import sys

from dotenv import load_dotenv


def setup_environment():
    """Load environment variables from .env file."""
    load_dotenv()

    # Set defaults for local mode
    os.environ.setdefault("ZOTERO_LIBRARY_ID", "0")


def _print_remote_setup_help() -> None:
    print(
        "\n"
        "  Remote (HTTP) mode requires admin auth.\n"
        "\n"
        "  Run the interactive setup wizard (recommended):\n"
        "      zotero-mcp setup --remote\n"
        "\n"
        "  Or set these in your .env file:\n"
        "      ZOTERO_MCP_ADMIN_PASSWORD=<your password>\n"
        "      ZOTERO_MCP_PUBLIC_URL=https://<your-tunnel>/\n"
        "\n"
        "  See .env.example for details.\n"
        "  To bypass auth (NOT recommended): pass --no-auth.\n",
        file=sys.stderr,
    )


class RemoteAuthConfigError(RuntimeError):
    """Raised by ``_configure_http_auth`` when env config is missing.

    Callers handle the error so they can clean up resources (e.g. stop the
    cloudflared subprocess) before the process exits.
    """


def _configure_http_auth(mcp, *, public_url: str | None, no_auth: bool) -> None:
    """Attach OAuth provider + login routes to the FastMCP instance.

    Called only for streamable-http / sse transports. stdio mode is
    untouched — Claude Desktop continues to work with no auth.

    Raises:
        RemoteAuthConfigError: when admin auth is required but not configured.
    """
    if no_auth:
        print(
            "  [!!] WARNING: starting HTTP server with NO authentication.\n"
            "       Anyone who reaches this URL can read AND write your Zotero library.\n"
            "       This is intended only for local debugging.",
            file=sys.stderr,
        )
        return

    password = os.environ.get("ZOTERO_MCP_ADMIN_PASSWORD", "").strip()
    url = (public_url or os.environ.get("ZOTERO_MCP_PUBLIC_URL", "")).strip()

    if not password or not url:
        missing = []
        if not password:
            missing.append("ZOTERO_MCP_ADMIN_PASSWORD")
        if not url:
            missing.append("ZOTERO_MCP_PUBLIC_URL (or --public-url)")
        raise RemoteAuthConfigError(
            "Missing required configuration: " + ", ".join(missing)
        )

    from zotero_mcp.auth import build_auth_provider
    from zotero_mcp.auth.login import make_login_routes

    provider = build_auth_provider(public_url=url, password=password)
    mcp.auth = provider

    # Browsers drop Secure cookies on plain-HTTP, which is fine for production
    # (always behind a tunnel) but breaks local development against
    # http://localhost:8000.
    secure_cookie = url.lower().startswith("https://")

    login_get, login_post = make_login_routes(
        password_hash=provider._password_hash,
        cookie_secret=provider._cookie_secret,
        secure_cookie=secure_cookie,
    )
    mcp.custom_route("/authorize/login", methods=["GET"])(login_get)
    mcp.custom_route("/authorize/login", methods=["POST"])(login_post)

    print(f"  OAuth: enabled (issuer = {url})", file=sys.stderr)


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        description="Zotero MCP Lite - A lightweight MCP server for Zotero"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Serve command
    serve_parser = subparsers.add_parser("serve", help="Run the MCP server")
    serve_parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http", "sse"],
        default="stdio",
        help="Transport protocol (default: stdio)"
    )
    serve_parser.add_argument(
        "--host",
        default="localhost",
        help="Host for HTTP transports (default: localhost)"
    )
    serve_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port for HTTP transports (default: 8000)"
    )
    serve_parser.add_argument(
        "--public-url",
        default=None,
        help="Public HTTPS URL the server is reachable at (the tunnel URL). "
             "Falls back to $ZOTERO_MCP_PUBLIC_URL.",
    )
    serve_parser.add_argument(
        "--no-auth",
        action="store_true",
        help="Disable OAuth on HTTP transports (DANGEROUS — exposes Zotero unauthenticated).",
    )
    serve_parser.add_argument(
        "--remote",
        action="store_true",
        help="Auto-launch a Cloudflare tunnel and use its URL as the public URL.",
    )

    # Version command
    subparsers.add_parser("version", help="Print version information")

    # Setup command
    setup_parser = subparsers.add_parser(
        "setup", help="Detect Zotero configuration and show setup guide"
    )
    setup_parser.add_argument(
        "--remote",
        action="store_true",
        help="Interactive wizard to set up remote (claude.ai web / Word add-in) access.",
    )

    args = parser.parse_args()

    # Default to serve with stdio if no command provided
    if not args.command:
        args.command = "serve"
        args.transport = "stdio"
        args.host = "localhost"
        args.port = 8000
        args.public_url = None
        args.no_auth = False
        args.remote = False

    if args.command == "version":
        from zotero_mcp._version import __version__
        print(f"Zotero MCP Lite v{__version__}")
        sys.exit(0)

    elif args.command == "setup":
        if getattr(args, "remote", False):
            from zotero_mcp.setup_remote import run_remote_setup

            sys.exit(run_remote_setup())
        from zotero_mcp.setup_helper import main as setup_main
        sys.exit(setup_main())

    elif args.command == "serve":
        setup_environment()

        public_url = args.public_url
        tunnel_ctx = None

        if args.remote:
            if args.transport == "stdio":
                args.transport = "streamable-http"
            from zotero_mcp.tunnel import CloudflaredTunnel

            tunnel_ctx = CloudflaredTunnel(local_port=args.port)
            try:
                public_url = tunnel_ctx.start()
            except Exception as e:
                print(f"Error: failed to start cloudflared tunnel: {e}", file=sys.stderr)
                sys.exit(1)
            os.environ["ZOTERO_MCP_PUBLIC_URL"] = public_url
            print(f"  Tunnel: {public_url}", file=sys.stderr)

        from zotero_mcp.server import mcp

        if args.transport in ("streamable-http", "sse"):
            try:
                _configure_http_auth(
                    mcp, public_url=public_url, no_auth=args.no_auth
                )
            except RemoteAuthConfigError as e:
                print(f"Error: {e}", file=sys.stderr)
                _print_remote_setup_help()
                if tunnel_ctx is not None:
                    tunnel_ctx.stop()
                sys.exit(2)

        try:
            if args.transport == "stdio":
                mcp.run(transport="stdio")
            elif args.transport == "streamable-http":
                mcp.run(transport="streamable-http", host=args.host, port=args.port)
            elif args.transport == "sse":
                mcp.run(transport="sse", host=args.host, port=args.port)
        finally:
            if tunnel_ctx is not None:
                tunnel_ctx.stop()


if __name__ == "__main__":
    main()
