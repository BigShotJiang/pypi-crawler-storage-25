"""Password hashing for the admin login interstitial.

Uses stdlib hashlib.scrypt to avoid adding a bcrypt dependency. The hash
format is ``scrypt$<n>$<r>$<p>$<salt_b64>$<hash_b64>``. Each server has a
single admin password set via ZOTERO_MCP_ADMIN_PASSWORD.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets

# scrypt parameters: ~16 MiB (128 * N * r), ~100 ms on modern hardware.
# Sufficient for a personal-server admin password.
_N = 2 ** 14
_R = 8
_P = 1
_DKLEN = 32
_SALT_BYTES = 16


def generate_password(length: int = 24) -> str:
    """Return a URL-safe random password suitable for one-time issuance."""
    return secrets.token_urlsafe(length)


def hash_password(password: str) -> str:
    """Return an scrypt-encoded hash string for ``password``."""
    if not password:
        raise ValueError("password must not be empty")
    salt = secrets.token_bytes(_SALT_BYTES)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=_N, r=_R, p=_P, dklen=_DKLEN
    )
    return "scrypt${n}${r}${p}${salt}${hash}".format(
        n=_N,
        r=_R,
        p=_P,
        salt=base64.b64encode(salt).decode("ascii"),
        hash=base64.b64encode(digest).decode("ascii"),
    )


def verify_password(password: str, encoded: str) -> bool:
    """Constant-time comparison of ``password`` against an encoded hash."""
    if not encoded.startswith("scrypt$"):
        return False
    try:
        _, n_s, r_s, p_s, salt_b64, hash_b64 = encoded.split("$", 5)
        n, r, p = int(n_s), int(r_s), int(p_s)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
    except (ValueError, base64.binascii.Error):
        return False
    actual = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=n, r=r, p=p, dklen=len(expected)
    )
    return hmac.compare_digest(actual, expected)
