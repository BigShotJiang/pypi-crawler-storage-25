"""Client ID Metadata Document (CIMD) fetching.

When claude.ai uses CIMD instead of DCR, it presents a URL as the OAuth
``client_id``. The server fetches that URL to obtain the client metadata
(redirect_uris, scopes, etc.) and uses it for the rest of the flow.

See https://datatracker.ietf.org/doc/draft-parecki-oauth-client-id-metadata-document/
and https://claude.com/docs/connectors/building/authentication
"""

from __future__ import annotations

import time
from urllib.parse import urlparse

import httpx
from mcp.shared.auth import OAuthClientInformationFull


_CACHE_TTL_SECONDS = 60 * 60  # 1 hour
_FETCH_TIMEOUT_SECONDS = 10.0


class CimdClientCache:
    def __init__(self) -> None:
        self._entries: dict[str, tuple[float, OAuthClientInformationFull]] = {}

    def get(self, url: str) -> OAuthClientInformationFull | None:
        entry = self._entries.get(url)
        if not entry:
            return None
        ts, client = entry
        if (time.time() - ts) > _CACHE_TTL_SECONDS:
            self._entries.pop(url, None)
            return None
        return client

    def set(self, url: str, client: OAuthClientInformationFull) -> None:
        self._entries[url] = (time.time(), client)


def is_url_client_id(client_id: str) -> bool:
    """Return True if ``client_id`` looks like a CIMD URL."""
    try:
        parsed = urlparse(client_id)
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


async def fetch_client_metadata(
    client_id_url: str, *, cache: CimdClientCache | None = None
) -> OAuthClientInformationFull | None:
    """Fetch and parse a CIMD document.

    Returns ``None`` on any error (network, parse, validation). Successful
    fetches are cached for one hour.
    """
    if cache:
        cached = cache.get(client_id_url)
        if cached:
            return cached

    parsed = urlparse(client_id_url)
    if parsed.scheme not in ("http", "https"):
        return None
    # Allow http only for localhost/127.0.0.1 (testing). Production must be HTTPS.
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1"):
        return None

    try:
        async with httpx.AsyncClient(timeout=_FETCH_TIMEOUT_SECONDS) as client:
            resp = await client.get(client_id_url)
            resp.raise_for_status()
            data = resp.json()
    except (httpx.HTTPError, ValueError):
        return None

    # CIMD clients are public — the spec mandates "none". Force it rather than
    # trusting whatever the document supplies.
    data["token_endpoint_auth_method"] = "none"
    # The client_id IS the URL itself per CIMD spec.
    data["client_id"] = client_id_url

    try:
        info = OAuthClientInformationFull.model_validate(data)
    except (ValueError, TypeError):
        return None

    if cache:
        cache.set(client_id_url, info)
    return info
