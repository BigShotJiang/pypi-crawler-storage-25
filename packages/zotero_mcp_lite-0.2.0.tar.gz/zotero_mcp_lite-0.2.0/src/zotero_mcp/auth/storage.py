"""SQLite persistence for OAuth state.

FastMCP ships an in-memory provider only; restarts would force claude.ai to
re-authenticate every time. Persistence keeps refresh tokens valid across
server restarts so the connector stays connected.

Tables:
    clients          DCR-registered clients (CIMD URL clients are not stored)
    auth_codes       short-lived authorization codes (5 min)
    access_tokens    Bearer tokens issued to claude.ai
    refresh_tokens   long-lived refresh tokens
    token_links      access_token <-> refresh_token mapping for revocation
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from mcp.server.auth.provider import (
    AccessToken,
    AuthorizationCode,
    RefreshToken,
)
from mcp.shared.auth import OAuthClientInformationFull
from pydantic import AnyUrl


_SCHEMA = """
CREATE TABLE IF NOT EXISTS clients (
    client_id TEXT PRIMARY KEY,
    info_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS auth_codes (
    code TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    redirect_uri TEXT NOT NULL,
    redirect_uri_provided_explicitly INTEGER NOT NULL,
    scopes_json TEXT NOT NULL,
    expires_at REAL NOT NULL,
    code_challenge TEXT
);

CREATE TABLE IF NOT EXISTS access_tokens (
    token TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    scopes_json TEXT NOT NULL,
    expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
    token TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    scopes_json TEXT NOT NULL,
    expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS token_links (
    access_token TEXT PRIMARY KEY,
    refresh_token TEXT NOT NULL UNIQUE
);
"""


class SqliteOAuthStorage:
    """Thread-safe synchronous SQLite store for OAuth state.

    All public methods grab a single re-entrant lock; SQLite handles small
    single-user load comfortably without async wrapping.
    """

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None
        )
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute("PRAGMA foreign_keys=ON;")
        with self._lock:
            self._conn.executescript(_SCHEMA)
        # Refresh tokens shouldn't be world-readable. POSIX-only; chmod is a
        # no-op on Windows but raise OSError on some FS so wrap defensively.
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    # ---------- clients (DCR) ----------

    def upsert_client(self, info: OAuthClientInformationFull) -> None:
        if info.client_id is None:
            raise ValueError("client_id is required")
        payload = info.model_dump(mode="json")
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO clients (client_id, info_json) VALUES (?, ?)",
                (info.client_id, json.dumps(payload)),
            )

    def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT info_json FROM clients WHERE client_id = ?", (client_id,)
            ).fetchone()
        if not row:
            return None
        return OAuthClientInformationFull.model_validate(json.loads(row[0]))

    # ---------- authorization codes ----------

    def save_auth_code(self, code: AuthorizationCode) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO auth_codes
                   (code, client_id, redirect_uri, redirect_uri_provided_explicitly,
                    scopes_json, expires_at, code_challenge)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    code.code,
                    code.client_id,
                    str(code.redirect_uri),
                    int(code.redirect_uri_provided_explicitly),
                    json.dumps(code.scopes),
                    code.expires_at,
                    code.code_challenge,
                ),
            )

    def load_auth_code(self, code: str) -> AuthorizationCode | None:
        with self._lock:
            row = self._conn.execute(
                """SELECT client_id, redirect_uri, redirect_uri_provided_explicitly,
                          scopes_json, expires_at, code_challenge
                   FROM auth_codes WHERE code = ?""",
                (code,),
            ).fetchone()
        if not row:
            return None
        client_id, redirect_uri, explicit, scopes_json, expires_at, challenge = row
        if expires_at < time.time():
            self.delete_auth_code(code)
            return None
        return AuthorizationCode(
            code=code,
            client_id=client_id,
            redirect_uri=AnyUrl(redirect_uri),
            redirect_uri_provided_explicitly=bool(explicit),
            scopes=json.loads(scopes_json),
            expires_at=expires_at,
            code_challenge=challenge,
        )

    def delete_auth_code(self, code: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM auth_codes WHERE code = ?", (code,))

    # ---------- access tokens ----------

    def save_access_token(self, token: AccessToken) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO access_tokens
                   (token, client_id, scopes_json, expires_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    token.token,
                    token.client_id,
                    json.dumps(token.scopes),
                    token.expires_at,
                ),
            )

    def load_access_token(self, token: str) -> AccessToken | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT client_id, scopes_json, expires_at FROM access_tokens WHERE token = ?",
                (token,),
            ).fetchone()
        if not row:
            return None
        client_id, scopes_json, expires_at = row
        if expires_at is not None and expires_at < int(time.time()):
            self.delete_access_token(token)
            return None
        return AccessToken(
            token=token,
            client_id=client_id,
            scopes=json.loads(scopes_json),
            expires_at=expires_at,
        )

    def delete_access_token(self, token: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM access_tokens WHERE token = ?", (token,))
            self._conn.execute(
                "DELETE FROM token_links WHERE access_token = ?", (token,)
            )

    # ---------- refresh tokens ----------

    def save_refresh_token(self, token: RefreshToken) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO refresh_tokens
                   (token, client_id, scopes_json, expires_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    token.token,
                    token.client_id,
                    json.dumps(token.scopes),
                    token.expires_at,
                ),
            )

    def load_refresh_token(self, token: str) -> RefreshToken | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT client_id, scopes_json, expires_at FROM refresh_tokens WHERE token = ?",
                (token,),
            ).fetchone()
        if not row:
            return None
        client_id, scopes_json, expires_at = row
        if expires_at is not None and expires_at < int(time.time()):
            self.delete_refresh_token(token)
            return None
        return RefreshToken(
            token=token,
            client_id=client_id,
            scopes=json.loads(scopes_json),
            expires_at=expires_at,
        )

    def delete_refresh_token(self, token: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM refresh_tokens WHERE token = ?", (token,))
            self._conn.execute(
                "DELETE FROM token_links WHERE refresh_token = ?", (token,)
            )

    # ---------- token linkage (for cascading revocation) ----------

    def link_tokens(self, access_token: str, refresh_token: str) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO token_links (access_token, refresh_token) VALUES (?, ?)",
                (access_token, refresh_token),
            )

    def find_access_for_refresh(self, refresh_token: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT access_token FROM token_links WHERE refresh_token = ?",
                (refresh_token,),
            ).fetchone()
        return row[0] if row else None

    def find_refresh_for_access(self, access_token: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT refresh_token FROM token_links WHERE access_token = ?",
                (access_token,),
            ).fetchone()
        return row[0] if row else None

    # ---------- diagnostics ----------

    def has_any_token(self) -> bool:
        """Return True once at least one access_token exists.

        Used by the `setup --remote` wizard to know when the OAuth handshake
        completed.
        """
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM access_tokens LIMIT 1"
            ).fetchone()
        return bool(row)

    def close(self) -> None:
        with self._lock:
            self._conn.close()
