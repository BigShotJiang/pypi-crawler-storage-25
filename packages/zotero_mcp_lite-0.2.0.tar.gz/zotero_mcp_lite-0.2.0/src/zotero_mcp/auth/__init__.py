"""OAuth 2.1 authentication for Zotero MCP Lite remote (HTTP) mode.

Enables the server to be exposed via a tunnel and registered as a Custom
Connector on claude.ai (web + Word add-in). Stdio mode is unaffected.

Supports both OAuth Dynamic Client Registration (DCR) and Client ID Metadata
Document (CIMD). The user logs in once with a password set in
ZOTERO_MCP_ADMIN_PASSWORD; tokens persist in a local SQLite database so
restarts do not force re-auth on claude.ai.
"""

from __future__ import annotations

import os
from pathlib import Path

from .password import hash_password, generate_password
from .provider import ZoteroOAuthProvider
from .storage import SqliteOAuthStorage


def _data_dir() -> Path:
    try:
        from platformdirs import user_data_dir

        return Path(user_data_dir("zotero-mcp"))
    except ImportError:
        return Path.home() / ".zotero-mcp"


def get_auth_db_path() -> Path:
    """Return the SQLite path used to persist OAuth state."""
    d = _data_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d / "oauth.sqlite"


def build_auth_provider(
    public_url: str,
    password: str | None = None,
    password_hash: str | None = None,
    db_path: Path | None = None,
) -> ZoteroOAuthProvider:
    """Build the OAuth provider for streamable-http mode.

    One of ``password`` or ``password_hash`` must be supplied. ``password`` is
    hashed at construction time using stdlib scrypt and discarded.
    """
    if password is None and password_hash is None:
        raise ValueError("password or password_hash is required")
    if password_hash is None:
        if password is None:
            raise ValueError("password must not be None when password_hash is None")
        password_hash = hash_password(password)

    storage = SqliteOAuthStorage(db_path or get_auth_db_path())
    return ZoteroOAuthProvider(
        base_url=public_url,
        password_hash=password_hash,
        storage=storage,
    )


__all__ = [
    "build_auth_provider",
    "generate_password",
    "get_auth_db_path",
    "hash_password",
    "SqliteOAuthStorage",
    "ZoteroOAuthProvider",
]
