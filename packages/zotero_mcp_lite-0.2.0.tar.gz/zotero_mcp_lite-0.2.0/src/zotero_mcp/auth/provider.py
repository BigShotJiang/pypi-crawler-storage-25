"""Zotero MCP OAuth 2.1 authorization-server implementation.

Subclasses FastMCP's :class:`OAuthProvider` and supports both Dynamic Client
Registration (DCR, RFC 7591) and Client ID Metadata Document (CIMD, draft).

Adapted from :class:`fastmcp.server.auth.providers.in_memory.InMemoryOAuthProvider`
with the in-memory dicts swapped out for SQLite persistence and CIMD support
layered on top.
"""

from __future__ import annotations

import secrets
import time
from typing import cast

from mcp.server.auth.handlers.metadata import MetadataHandler
from mcp.server.auth.provider import (
    AccessToken,
    AuthorizationCode,
    AuthorizationParams,
    AuthorizeError,
    RefreshToken,
    TokenError,
    construct_redirect_uri,
)
from mcp.server.auth.routes import build_metadata, cors_middleware
from mcp.server.auth.settings import (
    ClientRegistrationOptions,
    RevocationOptions,
)
from mcp.shared.auth import (
    OAuthClientInformationFull,
    OAuthMetadata,
    OAuthToken,
)
from pydantic import AnyHttpUrl
from starlette.middleware import Middleware
from starlette.routing import Route

from fastmcp.server.auth.auth import OAuthProvider

from .cimd import CimdClientCache, fetch_client_metadata, is_url_client_id
from .login import LoginGateMiddleware, derive_cookie_secret
from .storage import SqliteOAuthStorage


_AUTH_CODE_EXPIRY_SECONDS = 5 * 60
_ACCESS_TOKEN_EXPIRY_SECONDS = 60 * 60
_REFRESH_TOKEN_EXPIRY_SECONDS: int | None = None  # no expiry by default


class ZoteroOAuthProvider(OAuthProvider):
    """Zotero MCP authorization server.

    Supports DCR (writes registrations to SQLite) and CIMD (fetches client
    metadata from the URL on demand). Tokens persist across restarts so
    claude.ai's connector stays connected.
    """

    def __init__(
        self,
        *,
        base_url: AnyHttpUrl | str,
        password_hash: str,
        storage: SqliteOAuthStorage,
        valid_scopes: list[str] | None = None,
        default_scopes: list[str] | None = None,
    ) -> None:
        scopes = valid_scopes or ["zotero.read", "zotero.write"]
        defaults = default_scopes or ["zotero.read"]
        super().__init__(
            base_url=base_url,
            client_registration_options=ClientRegistrationOptions(
                enabled=True,
                valid_scopes=scopes,
                default_scopes=defaults,
            ),
            revocation_options=RevocationOptions(enabled=True),
        )
        self._password_hash = password_hash
        self._cookie_secret = derive_cookie_secret(password_hash)
        self.storage = storage
        self._cimd_cache = CimdClientCache()

    # ---------- client lookup (DCR + CIMD) ----------

    async def get_client(
        self, client_id: str
    ) -> OAuthClientInformationFull | None:
        if is_url_client_id(client_id):
            return await fetch_client_metadata(client_id, cache=self._cimd_cache)
        return self.storage.get_client(client_id)

    async def register_client(
        self, client_info: OAuthClientInformationFull
    ) -> None:
        if client_info.client_id is None:
            raise ValueError("client_id is required for client registration")
        # Validate requested scopes against valid_scopes (matches SDK behavior)
        opts = self.client_registration_options
        if (
            client_info.scope is not None
            and opts is not None
            and opts.valid_scopes is not None
        ):
            requested = set(client_info.scope.split())
            allowed = set(opts.valid_scopes)
            invalid = requested - allowed
            if invalid:
                raise ValueError(
                    f"Requested scopes are not valid: {', '.join(sorted(invalid))}"
                )
        self.storage.upsert_client(client_info)

    # ---------- authorization ----------

    async def authorize(
        self,
        client: OAuthClientInformationFull,
        params: AuthorizationParams,
    ) -> str:
        # By the time we get here, LoginGateMiddleware has verified the user
        # supplied the admin password (cookie present). The SDK handler has
        # also validated client and redirect_uri.
        if client.client_id is None:
            raise AuthorizeError(
                error="invalid_client", error_description="Client ID is required"
            )

        # Filter requested scopes against client's registered scopes
        scopes_list = params.scopes if params.scopes is not None else []
        if client.scope:
            client_allowed = set(client.scope.split())
            scopes_list = [s for s in scopes_list if s in client_allowed]

        code_value = f"zotc_{secrets.token_urlsafe(24)}"
        auth_code = AuthorizationCode(
            code=code_value,
            client_id=client.client_id,
            redirect_uri=params.redirect_uri,
            redirect_uri_provided_explicitly=params.redirect_uri_provided_explicitly,
            scopes=scopes_list,
            expires_at=time.time() + _AUTH_CODE_EXPIRY_SECONDS,
            code_challenge=params.code_challenge,
        )
        self.storage.save_auth_code(auth_code)

        return construct_redirect_uri(
            str(params.redirect_uri), code=code_value, state=params.state
        )

    async def load_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: str,
    ) -> AuthorizationCode | None:
        code = self.storage.load_auth_code(authorization_code)
        if not code:
            return None
        if code.client_id != client.client_id:
            return None
        return code

    def _issue_token_pair(
        self, client_id: str, scopes: list[str]
    ) -> OAuthToken:
        """Mint and persist a new access/refresh token pair for ``client_id``."""
        access_value = f"zota_{secrets.token_urlsafe(32)}"
        refresh_value = f"zotr_{secrets.token_urlsafe(32)}"
        access_expires_at = int(time.time() + _ACCESS_TOKEN_EXPIRY_SECONDS)
        refresh_expires_at = (
            int(time.time() + _REFRESH_TOKEN_EXPIRY_SECONDS)
            if _REFRESH_TOKEN_EXPIRY_SECONDS is not None
            else None
        )
        self.storage.save_access_token(
            AccessToken(
                token=access_value,
                client_id=client_id,
                scopes=scopes,
                expires_at=access_expires_at,
            )
        )
        self.storage.save_refresh_token(
            RefreshToken(
                token=refresh_value,
                client_id=client_id,
                scopes=scopes,
                expires_at=refresh_expires_at,
            )
        )
        self.storage.link_tokens(access_value, refresh_value)

        return OAuthToken(
            access_token=access_value,
            token_type="Bearer",
            expires_in=_ACCESS_TOKEN_EXPIRY_SECONDS,
            refresh_token=refresh_value,
            scope=" ".join(scopes),
        )

    async def exchange_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: AuthorizationCode,
    ) -> OAuthToken:
        if client.client_id is None:
            raise TokenError("invalid_client", "Client ID is required")
        # Consume the code (single-use)
        self.storage.delete_auth_code(authorization_code.code)
        return self._issue_token_pair(client.client_id, authorization_code.scopes)

    # ---------- refresh ----------

    async def load_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: str,
    ) -> RefreshToken | None:
        token = self.storage.load_refresh_token(refresh_token)
        if not token:
            return None
        if token.client_id != client.client_id:
            return None
        return token

    async def exchange_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: RefreshToken,
        scopes: list[str],
    ) -> OAuthToken:
        if client.client_id is None:
            raise TokenError("invalid_client", "Client ID is required")
        original = set(refresh_token.scopes)
        requested = set(scopes)
        if not requested.issubset(original):
            raise TokenError(
                "invalid_scope",
                "Requested scopes exceed those authorized by the refresh token.",
            )

        # Rotate: revoke old pair, then issue a fresh one with the requested scopes
        old_access = self.storage.find_access_for_refresh(refresh_token.token)
        if old_access:
            self.storage.delete_access_token(old_access)
        self.storage.delete_refresh_token(refresh_token.token)

        return self._issue_token_pair(client.client_id, scopes)

    # ---------- access tokens / verification ----------

    async def load_access_token(self, token: str) -> AccessToken | None:
        return self.storage.load_access_token(token)

    # OAuthProvider.verify_token already delegates to load_access_token, so no
    # override is needed here.

    # ---------- revocation ----------

    async def revoke_token(self, token: AccessToken | RefreshToken) -> None:
        if isinstance(token, AccessToken):
            paired = self.storage.find_refresh_for_access(token.token)
            self.storage.delete_access_token(token.token)
            if paired:
                self.storage.delete_refresh_token(paired)
        elif isinstance(token, RefreshToken):
            paired = self.storage.find_access_for_refresh(token.token)
            self.storage.delete_refresh_token(token.token)
            if paired:
                self.storage.delete_access_token(paired)

    # ---------- middleware (login gate + bearer auth) ----------

    def get_middleware(self) -> list:
        # LoginGate must run BEFORE the bearer auth middleware so that
        # browser GET /authorize requests are redirected to /authorize/login
        # before any auth processing.
        return [
            Middleware(LoginGateMiddleware, cookie_secret=self._cookie_secret),
        ] + super().get_middleware()

    # ---------- routes (override metadata to advertise CIMD) ----------

    def get_routes(self, mcp_path: str | None = None) -> list[Route]:
        routes = super().get_routes(mcp_path)
        # The SDK's build_metadata() hardcodes the auth methods; we replace
        # the well-known metadata route with one that also advertises "none"
        # so claude.ai's connector flow knows CIMD is supported.
        assert self.base_url is not None
        assert self.issuer_url is not None
        metadata = build_metadata(
            cast(AnyHttpUrl, self.base_url),
            self.service_documentation_url,
            self.client_registration_options,
            self.revocation_options,
        )
        # Append "none" for CIMD without removing the secret-based methods used
        # by traditional DCR clients.
        existing = list(metadata.token_endpoint_auth_methods_supported or [])
        if "none" not in existing:
            existing.append("none")
        metadata = OAuthMetadata.model_validate(
            {**metadata.model_dump(mode="json"), "token_endpoint_auth_methods_supported": existing}
        )

        new_routes: list[Route] = []
        replaced = False
        for route in routes:
            if (
                isinstance(route, Route)
                and route.path == "/.well-known/oauth-authorization-server"
            ):
                new_routes.append(
                    Route(
                        route.path,
                        endpoint=cors_middleware(
                            MetadataHandler(metadata).handle, ["GET", "OPTIONS"]
                        ),
                        methods=route.methods or ["GET", "OPTIONS"],
                    )
                )
                replaced = True
            else:
                new_routes.append(route)

        # If FastMCP used a path-aware variant (issuer has a path), also
        # replace that.
        if not replaced:
            for i, route in enumerate(new_routes):
                if isinstance(route, Route) and route.path.startswith(
                    "/.well-known/oauth-authorization-server"
                ):
                    new_routes[i] = Route(
                        route.path,
                        endpoint=cors_middleware(
                            MetadataHandler(metadata).handle, ["GET", "OPTIONS"]
                        ),
                        methods=route.methods or ["GET", "OPTIONS"],
                    )
                    break

        return new_routes
