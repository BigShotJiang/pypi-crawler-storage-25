"""Password-gated login interstitial for /authorize.

claude.ai (and other clients) redirect the user's browser to /authorize during
the OAuth flow. FastMCP's SDK handler would issue an authorization code
without verifying user identity — we cannot let that happen on a tunnel-
exposed server. So we sit a small login page in front of /authorize: the user
types the admin password, we set a short-lived signed cookie, and the
browser is sent back to /authorize where the SDK handler runs.

Implemented as ASGI middleware (rather than a competing route) because
FastMCP mounts custom_route entries with lower precedence than auth routes.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from html import escape
from typing import Awaitable, Callable

from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from starlette.requests import Request
from starlette.responses import HTMLResponse, RedirectResponse, Response
from starlette.types import ASGIApp, Receive, Scope, Send

from .password import verify_password


_COOKIE_NAME = "zotmcp_session"
_COOKIE_MAX_AGE_SECONDS = 5 * 60  # 5 minutes — enough for one OAuth handshake
_LOGIN_PATH = "/authorize/login"
_AUTHORIZE_PATH = "/authorize"


def _serializer(secret: str) -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(secret, salt="zotero-mcp-login")


def _read_cookie(request: Request, secret: str) -> bool:
    raw = request.cookies.get(_COOKIE_NAME)
    if not raw:
        return False
    try:
        _serializer(secret).loads(raw, max_age=_COOKIE_MAX_AGE_SECONDS)
    except (BadSignature, SignatureExpired):
        return False
    return True


def _set_cookie(response: Response, secret: str, *, secure: bool) -> None:
    payload = _serializer(secret).dumps({"ts": int(time.time())})
    response.set_cookie(
        key=_COOKIE_NAME,
        value=payload,
        max_age=_COOKIE_MAX_AGE_SECONDS,
        httponly=True,
        secure=secure,
        samesite="lax",
        path="/",
    )


class LoginGateMiddleware:
    """Redirect unauthenticated GET /authorize requests to /authorize/login.

    Only intercepts GET (and HEAD) on the exact /authorize path; POSTs from
    the SDK and any sub-paths fall through unmodified. After successful
    login the browser is redirected back to /authorize with the original
    query string, where the SDK handler issues the auth code.
    """

    def __init__(self, app: ASGIApp, *, cookie_secret: str):
        self.app = app
        self._cookie_secret = cookie_secret

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "GET").upper()
        path = scope.get("path", "")
        if method in ("GET", "HEAD") and path == _AUTHORIZE_PATH:
            request = Request(scope, receive)
            if not _read_cookie(request, self._cookie_secret):
                query = scope.get("query_string", b"").decode("latin-1")
                target = _LOGIN_PATH
                if query:
                    target = f"{_LOGIN_PATH}?{query}"
                response = RedirectResponse(url=target, status_code=302)
                await response(scope, receive, send)
                return

        await self.app(scope, receive, send)


def render_login_page(query_string: str, *, error: str | None = None) -> HTMLResponse:
    error_html = ""
    if error:
        error_html = f'<div class="error">{escape(error)}</div>'
    body = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Zotero MCP — Sign in</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
           background: #f6f7f9; margin: 0; padding: 2rem;
           display: flex; align-items: center; justify-content: center; min-height: 100vh; }}
    .card {{ background: white; padding: 2rem 2.5rem; border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 360px; width: 100%; }}
    h1 {{ margin: 0 0 0.25rem; font-size: 1.25rem; }}
    p.sub {{ margin: 0 0 1.5rem; color: #6b7280; font-size: 0.9rem; }}
    label {{ display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem; }}
    input[type=password] {{ width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db;
                           border-radius: 6px; font-size: 1rem; box-sizing: border-box; }}
    button {{ width: 100%; margin-top: 1rem; padding: 0.7rem; background: #2563eb;
             color: white; border: 0; border-radius: 6px; font-size: 1rem; cursor: pointer; }}
    button:hover {{ background: #1d4ed8; }}
    .error {{ background: #fef2f2; color: #b91c1c; padding: 0.6rem 0.75rem;
             border-radius: 6px; margin-bottom: 1rem; font-size: 0.9rem; }}
    .footer {{ margin-top: 1.5rem; font-size: 0.75rem; color: #9ca3af; text-align: center; }}
  </style>
</head>
<body>
  <form class="card" method="post" action="{_LOGIN_PATH}">
    <h1>Zotero MCP</h1>
    <p class="sub">Enter your admin password to authorize Claude.</p>
    {error_html}
    <input type="hidden" name="next" value="{escape(query_string)}">
    <label for="password">Password</label>
    <input id="password" name="password" type="password" autocomplete="current-password" autofocus required>
    <button type="submit">Sign in</button>
    <div class="footer">Set ZOTERO_MCP_ADMIN_PASSWORD in .env to change.</div>
  </form>
</body>
</html>
"""
    return HTMLResponse(body)


def make_login_routes(
    *, password_hash: str, cookie_secret: str, secure_cookie: bool = True
):
    """Return (login_get, login_post) handlers for FastMCP custom_route.

    ``secure_cookie`` should be False for plain-HTTP localhost development,
    otherwise the browser silently drops the session cookie.
    """

    async def login_get(request: Request) -> Response:
        query_string = request.url.query
        return render_login_page(query_string)

    async def login_post(request: Request) -> Response:
        form = await request.form()
        password = str(form.get("password", ""))
        next_query = str(form.get("next", ""))
        if not password or not verify_password(password, password_hash):
            return render_login_page(next_query, error="Incorrect password.")
        target = _AUTHORIZE_PATH
        if next_query:
            target = f"{_AUTHORIZE_PATH}?{next_query}"
        response = RedirectResponse(url=target, status_code=303)
        _set_cookie(response, cookie_secret, secure=secure_cookie)
        return response

    return login_get, login_post


def derive_cookie_secret(password_hash: str) -> str:
    """Derive a stable cookie-signing key from the password hash.

    Reusing the password hash means the cookie secret rotates whenever the
    admin password changes, invalidating outstanding sessions. Using HMAC
    with a fixed label avoids exposing the hash directly.
    """
    return hmac.new(
        password_hash.encode("utf-8"), b"zotero-mcp-cookie", hashlib.sha256
    ).hexdigest()
