"""Cloudflare Tunnel subprocess management for `zotero-mcp serve --remote`.

Spawns ``cloudflared tunnel --url http://localhost:<port>`` as a child
process, parses the auto-generated ``*.trycloudflare.com`` URL out of its
stderr (Cloudflare prints it there), and exposes start/stop lifecycle.

Auto-downloads the cloudflared binary on first use so end-users don't have
to install anything manually. The binary is cached under the user's data
directory.
"""

from __future__ import annotations

import atexit
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

try:
    from platformdirs import user_data_dir as _user_data_dir
except ImportError:  # pragma: no cover
    _user_data_dir = None


_CLOUDFLARED_RELEASES = (
    "https://github.com/cloudflare/cloudflared/releases/latest/download"
)

# Pattern Cloudflare uses for the public hostname in stderr. Form:
#   https://<words>-<words>-<words>-<words>.trycloudflare.com
_URL_RE = re.compile(rb"https://[a-z0-9-]+\.trycloudflare\.com")


def _data_dir() -> Path:
    if _user_data_dir is not None:
        return Path(_user_data_dir("zotero-mcp"))
    return Path.home() / ".zotero-mcp"


def _bin_dir() -> Path:
    d = _data_dir() / "bin"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _platform_asset() -> tuple[str, str]:
    """Return (filename_on_github, local_filename) for the current platform."""
    sysname = platform.system().lower()
    machine = platform.machine().lower()

    if sysname == "windows":
        if "arm" in machine or "aarch64" in machine:
            return "cloudflared-windows-arm64.exe", "cloudflared.exe"
        return "cloudflared-windows-amd64.exe", "cloudflared.exe"
    if sysname == "darwin":
        if "arm" in machine or "aarch64" in machine:
            # Cloudflare ships a single zip archive on macOS.
            return "cloudflared-darwin-arm64.tgz", "cloudflared"
        return "cloudflared-darwin-amd64.tgz", "cloudflared"
    if sysname == "linux":
        if "arm" in machine or "aarch64" in machine:
            return "cloudflared-linux-arm64", "cloudflared"
        if "386" in machine or "i686" in machine:
            return "cloudflared-linux-386", "cloudflared"
        return "cloudflared-linux-amd64", "cloudflared"
    raise RuntimeError(f"Unsupported platform: {sysname} {machine}")


def ensure_cloudflared_binary() -> Path:
    """Return a path to a working cloudflared binary, downloading if needed."""
    # 1. Use cloudflared from PATH if present
    on_path = shutil.which("cloudflared")
    if on_path:
        return Path(on_path)

    # 2. Use cached binary if present
    asset_name, local_name = _platform_asset()
    target = _bin_dir() / local_name
    if target.exists():
        return target

    # 3. Download fresh. Write to a sibling .tmp path and atomically rename
    #    so a partial download cannot poison the cache for the next run.
    url = f"{_CLOUDFLARED_RELEASES}/{asset_name}"
    print(f"  Downloading cloudflared from {url}...", file=sys.stderr)
    tmp_target = target.with_suffix(target.suffix + ".tmp")
    tmp_target.unlink(missing_ok=True)

    if asset_name.endswith(".tgz"):
        archive = _bin_dir() / (asset_name + ".tmp")
        archive.unlink(missing_ok=True)
        urllib.request.urlretrieve(url, archive)
        # Inside the tgz is a single 'cloudflared' executable
        import tarfile

        with tarfile.open(archive, "r:gz") as tar:
            tar.extract("cloudflared", path=_bin_dir())
        archive.unlink(missing_ok=True)
        # tarfile extracts to the canonical name; move it into target
        extracted = _bin_dir() / "cloudflared"
        os.replace(extracted, target)
    elif asset_name.endswith(".zip"):
        archive = _bin_dir() / (asset_name + ".tmp")
        archive.unlink(missing_ok=True)
        urllib.request.urlretrieve(url, archive)
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(_bin_dir())
        archive.unlink(missing_ok=True)
    else:
        urllib.request.urlretrieve(url, tmp_target)
        os.replace(tmp_target, target)

    if platform.system().lower() != "windows":
        target.chmod(target.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    if not target.exists():
        raise RuntimeError(f"cloudflared download succeeded but {target} is missing")
    return target


class CloudflaredTunnel:
    """Manage a `cloudflared tunnel --url http://localhost:<port>` subprocess."""

    def __init__(self, *, local_port: int, startup_timeout: float = 30.0):
        self.local_port = local_port
        self.startup_timeout = startup_timeout
        self._proc: subprocess.Popen[bytes] | None = None
        self._url: str | None = None
        self._reader_thread: threading.Thread | None = None
        self._output_lines: list[bytes] = []

    @property
    def url(self) -> str | None:
        return self._url

    def start(self) -> str:
        """Start the tunnel and block until the public URL is available."""
        binary = ensure_cloudflared_binary()
        cmd = [
            str(binary),
            "tunnel",
            "--no-autoupdate",
            "--url",
            f"http://localhost:{self.local_port}",
        ]
        self._proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            bufsize=0,
        )
        # Defensive cleanup if Python exits without a clean stop() call.
        # Idempotent: stop() is a no-op once self._proc is None.
        atexit.register(self.stop)

        self._reader_thread = threading.Thread(
            target=self._read_output, daemon=True
        )
        self._reader_thread.start()

        deadline = time.time() + self.startup_timeout
        while time.time() < deadline:
            if self._url:
                return self._url
            if self._proc.poll() is not None:
                tail = b"\n".join(self._output_lines[-20:]).decode("utf-8", "replace")
                raise RuntimeError(
                    f"cloudflared exited before printing URL.\nLast output:\n{tail}"
                )
            time.sleep(0.2)

        self.stop()
        raise TimeoutError(
            f"cloudflared did not produce a tunnel URL within {self.startup_timeout}s"
        )

    def _read_output(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            self._output_lines.append(line)
            if not self._url:
                m = _URL_RE.search(line)
                if m:
                    self._url = m.group(0).decode("ascii")

    def stop(self) -> None:
        if self._proc is None:
            return
        if self._proc.poll() is None:
            try:
                self._proc.terminate()
                try:
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._proc.kill()
            except Exception:
                pass
        self._proc = None

    def __enter__(self) -> "CloudflaredTunnel":
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.stop()
