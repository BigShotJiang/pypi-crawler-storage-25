"""Interactive setup wizard for remote (claude.ai) access.

End-to-end flow: ensure cloudflared, generate or confirm admin password,
write .env, start tunnel, run server, poll for first OAuth token, print
"Connected!" once claude.ai completes the handshake.

Designed so a non-developer Zotero user can go from `git clone` to a
working claude.ai connector in a few minutes.
"""

from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

from .auth import generate_password, get_auth_db_path
from .auth.password import hash_password
from .auth.storage import SqliteOAuthStorage


def _project_root() -> Path:
    """Return the directory where .env should live (cwd is fine for a clone)."""
    return Path.cwd()


def _read_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        out[key.strip()] = val.strip().strip('"').strip("'")
    return out


def _write_env_file(path: Path, updates: dict[str, str]) -> None:
    """Update or insert lines in .env; preserve existing keys.

    Existing keys are replaced in place; new keys are appended. Comments and
    blank lines are preserved.
    """
    existing_lines: list[str] = []
    if path.exists():
        existing_lines = path.read_text(encoding="utf-8").splitlines()
        backup = path.with_suffix(".env.backup")
        backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")

    seen: set[str] = set()
    out: list[str] = []
    for line in existing_lines:
        stripped = line.strip()
        if (
            stripped
            and not stripped.startswith("#")
            and "=" in stripped
        ):
            key = stripped.partition("=")[0].strip()
            if key in updates:
                out.append(f"{key}={updates[key]}")
                seen.add(key)
                continue
        out.append(line)

    for key, val in updates.items():
        if key not in seen:
            out.append(f"{key}={val}")

    path.write_text("\n".join(out) + "\n", encoding="utf-8")


def _print_header() -> None:
    print()
    print("=" * 60)
    print("  Zotero MCP Lite - Remote Setup (claude.ai / Word add-in)")
    print("=" * 60)
    print()


def _confirm(prompt: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    raw = input(f"{prompt} {suffix}: ").strip().lower()
    if not raw:
        return default
    return raw in ("y", "yes")


def _wait_for_token(storage: SqliteOAuthStorage, *, public_url: str) -> None:
    """Poll the OAuth storage until claude.ai completes the handshake."""
    spinner = "|/-\\"
    i = 0
    while True:
        if storage.has_any_token():
            print()
            print()
            print("  [OK] Connected! claude.ai successfully authorized the connector.")
            print()
            print("  You can now use Zotero in claude.ai web and the Word add-in.")
            print("  This server stays running — leave the window open or run as a service.")
            print()
            return
        sys.stderr.write(
            f"\r  Waiting for claude.ai to authorize... {spinner[i % 4]}  "
        )
        sys.stderr.flush()
        i += 1
        time.sleep(0.5)


def run_remote_setup() -> int:
    _print_header()

    # 1. cloudflared
    print("[1/4] Cloudflare tunnel binary...")
    print("-" * 40)
    try:
        from .tunnel import ensure_cloudflared_binary

        binary = ensure_cloudflared_binary()
        print(f"  [OK] cloudflared at: {binary}")
    except Exception as e:
        print(f"  [!!] Failed to ensure cloudflared: {e}", file=sys.stderr)
        return 1
    print()

    # 2. Admin password
    print("[2/4] Admin password...")
    print("-" * 40)
    env_path = _project_root() / ".env"
    env_vars = _read_env_file(env_path)
    existing_pw = env_vars.get("ZOTERO_MCP_ADMIN_PASSWORD", "").strip()

    password: str
    if existing_pw:
        if _confirm(
            "  An admin password already exists in .env. Keep it?", default=True
        ):
            password = existing_pw
            print("  [OK] Using existing password.")
        else:
            password = generate_password()
            _write_env_file(env_path, {"ZOTERO_MCP_ADMIN_PASSWORD": password})
            print(f"  [OK] New password generated and saved to {env_path}")
            print(f"       Password: {password}")
    else:
        password = generate_password()
        _write_env_file(env_path, {"ZOTERO_MCP_ADMIN_PASSWORD": password})
        print(f"  [OK] Password generated and saved to {env_path}")
        print(f"       Password: {password}")
    # Make available to the in-process server build
    os.environ["ZOTERO_MCP_ADMIN_PASSWORD"] = password
    print()

    # 3. Tunnel
    print("[3/4] Starting Cloudflare tunnel...")
    print("-" * 40)
    from .tunnel import CloudflaredTunnel

    port = int(os.environ.get("ZOTERO_MCP_PORT", "8000"))
    tunnel = CloudflaredTunnel(local_port=port)
    try:
        public_url = tunnel.start()
    except Exception as e:
        print(f"  [!!] Failed to start tunnel: {e}", file=sys.stderr)
        return 1
    os.environ["ZOTERO_MCP_PUBLIC_URL"] = public_url
    _write_env_file(env_path, {"ZOTERO_MCP_PUBLIC_URL": public_url})
    print(f"  [OK] Tunnel URL: {public_url}")
    print()

    # 4. Server
    print("[4/4] Starting MCP server...")
    print("-" * 40)
    print()
    print("  Now go to claude.ai and add a Custom Connector:")
    print()
    print("    1. Open https://claude.ai/settings/connectors")
    print("    2. Click 'Add custom connector'")
    print(f"    3. Paste this URL: {public_url}/mcp")
    print(f"    4. When the login page appears, enter password: {password}")
    print()

    storage = SqliteOAuthStorage(get_auth_db_path())
    waiter = threading.Thread(
        target=_wait_for_token,
        args=(storage,),
        kwargs={"public_url": public_url},
        daemon=True,
    )
    waiter.start()

    # Reuse the same env-var-driven serve path so the wizard and the
    # standalone serve command behave identically.
    from .cli import RemoteAuthConfigError, _configure_http_auth
    from .server import mcp

    try:
        _configure_http_auth(mcp, public_url=public_url, no_auth=False)
    except RemoteAuthConfigError as e:
        print(f"  [!!] Auth misconfigured: {e}", file=sys.stderr)
        tunnel.stop()
        storage.close()
        return 1

    try:
        mcp.run(transport="streamable-http", host="127.0.0.1", port=port)
    except KeyboardInterrupt:
        print("\n  Stopping...")
    finally:
        tunnel.stop()
        storage.close()
    return 0
