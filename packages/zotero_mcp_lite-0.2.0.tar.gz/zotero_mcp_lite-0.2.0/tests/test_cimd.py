"""Verify CIMD URL-shaped client_id resolution.

Hosts a fake client metadata document on a local HTTP server and confirms
the OAuth provider fetches it when a URL-shaped client_id is presented.
"""

import asyncio
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from zotero_mcp.auth import build_auth_provider


CLIENT_METADATA = {
    "redirect_uris": ["https://claude.ai/api/mcp/auth_callback"],
    "token_endpoint_auth_method": "none",
    "grant_types": ["authorization_code", "refresh_token"],
    "response_types": ["code"],
    "client_name": "Claude (CIMD test)",
    "scope": "zotero.read zotero.write",
}


class _MetadataHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/cimd-metadata":
            payload = json.dumps(CLIENT_METADATA).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args, **kwargs) -> None:  # silence access log noise
        pass


class TestCimdResolution(unittest.TestCase):
    def setUp(self) -> None:
        self.httpd = HTTPServer(("127.0.0.1", 0), _MetadataHandler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.cimd_url = f"http://127.0.0.1:{self.port}/cimd-metadata"
        self._tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.db_path = Path(self._tmp.name) / "oauth.sqlite"
        self.provider = build_auth_provider(
            public_url="https://localhost",
            password="test",
            db_path=self.db_path,
        )

    def tearDown(self) -> None:
        self.provider.storage.close()
        try:
            self.httpd.shutdown()
        except Exception:
            pass
        self._tmp.cleanup()

    def test_url_client_id_is_fetched(self) -> None:
        info = asyncio.run(self.provider.get_client(self.cimd_url))
        self.assertIsNotNone(info)
        self.assertEqual(info.client_id, self.cimd_url)
        self.assertEqual(info.token_endpoint_auth_method, "none")
        self.assertEqual(
            str(info.redirect_uris[0]),
            "https://claude.ai/api/mcp/auth_callback",
        )

    def test_metadata_is_cached(self) -> None:
        first = asyncio.run(self.provider.get_client(self.cimd_url))
        self.assertIsNotNone(first)
        # Shut the upstream server down — a cached fetch must still succeed.
        self.httpd.shutdown()
        cached = asyncio.run(self.provider.get_client(self.cimd_url))
        self.assertIsNotNone(cached)


if __name__ == "__main__":
    unittest.main()
