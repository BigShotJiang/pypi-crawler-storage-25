"""End-to-end OAuth flow tests.

Covers DCR, login interstitial, password gate, auth-code → token exchange,
refresh-token rotation, and persistence across provider restarts.
"""

import asyncio
import base64
import hashlib
import secrets
import tempfile
import unittest
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.testclient import TestClient

from zotero_mcp.auth import build_auth_provider
from zotero_mcp.auth.login import make_login_routes


PASSWORD = "test-password-1234"
PUBLIC_URL = "https://localhost"
REDIRECT_URI = "https://claude.ai/api/mcp/auth_callback"


def _pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        .rstrip(b"=")
        .decode()
    )
    return verifier, challenge


def _build_app(provider) -> Starlette:
    routes = list(provider.get_routes(mcp_path="/mcp"))
    login_get, login_post = make_login_routes(
        password_hash=provider._password_hash,
        cookie_secret=provider._cookie_secret,
    )
    routes.append(Route("/authorize/login", endpoint=login_get, methods=["GET"]))
    routes.append(Route("/authorize/login", endpoint=login_post, methods=["POST"]))
    return Starlette(routes=routes, middleware=provider.get_middleware())


class TestOAuthEndToEnd(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.db_path = Path(self._tmp.name) / "oauth.sqlite"
        self.provider = build_auth_provider(
            public_url=PUBLIC_URL, password=PASSWORD, db_path=self.db_path
        )
        self.client = TestClient(
            _build_app(self.provider),
            base_url="https://testserver",
            follow_redirects=False,
        )

    def tearDown(self) -> None:
        self.provider.storage.close()
        self._tmp.cleanup()

    def _register_dcr_client(self) -> str:
        r = self.client.post(
            "/register",
            json={
                "redirect_uris": [REDIRECT_URI],
                "token_endpoint_auth_method": "none",
                "grant_types": ["authorization_code", "refresh_token"],
                "response_types": ["code"],
                "scope": "zotero.read zotero.write",
            },
        )
        self.assertIn(r.status_code, (200, 201), msg=r.text)
        return r.json()["client_id"]

    def _login(self, query: str) -> None:
        r = self.client.post(
            "/authorize/login",
            data={"password": PASSWORD, "next": query},
        )
        self.assertEqual(r.status_code, 303)

    def test_metadata_advertises_cimd(self) -> None:
        r = self.client.get("/.well-known/oauth-authorization-server")
        self.assertEqual(r.status_code, 200)
        meta = r.json()
        self.assertIn("none", meta["token_endpoint_auth_methods_supported"])
        self.assertTrue(meta["registration_endpoint"].endswith("/register"))

    def test_authorize_without_cookie_redirects_to_login(self) -> None:
        client_id = self._register_dcr_client()
        _, challenge = _pkce_pair()
        r = self.client.get(
            "/authorize",
            params={
                "response_type": "code",
                "client_id": client_id,
                "redirect_uri": REDIRECT_URI,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": "abc",
                "scope": "zotero.read",
            },
        )
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["location"].startswith("/authorize/login"))

    def test_wrong_password_re_renders_form(self) -> None:
        r = self.client.post(
            "/authorize/login",
            data={"password": "WRONG", "next": ""},
        )
        self.assertEqual(r.status_code, 200)
        self.assertIn("Incorrect password", r.text)

    def test_full_auth_code_and_refresh_flow(self) -> None:
        client_id = self._register_dcr_client()
        verifier, challenge = _pkce_pair()
        params = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": REDIRECT_URI,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "state": "xyz",
            "scope": "zotero.read",
        }

        first = self.client.get("/authorize", params=params)
        self.assertEqual(first.status_code, 302)
        self._login(first.headers["location"].split("?", 1)[1])

        r = self.client.get("/authorize", params=params)
        self.assertEqual(r.status_code, 302)
        loc = r.headers["location"]
        self.assertIn("claude.ai/api/mcp/auth_callback", loc)
        code = parse_qs(urlparse(loc).query)["code"][0]

        r = self.client.post(
            "/token",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
                "client_id": client_id,
                "code_verifier": verifier,
            },
        )
        self.assertEqual(r.status_code, 200, msg=r.text)
        tokens = r.json()
        access1, refresh1 = tokens["access_token"], tokens["refresh_token"]
        self.assertEqual(tokens["token_type"], "Bearer")

        verified = asyncio.run(self.provider.verify_token(access1))
        self.assertIsNotNone(verified)
        self.assertEqual(verified.client_id, client_id)

        r = self.client.post(
            "/token",
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh1,
                "client_id": client_id,
            },
        )
        self.assertEqual(r.status_code, 200, msg=r.text)
        new_tokens = r.json()
        self.assertNotEqual(new_tokens["access_token"], access1)
        self.assertNotEqual(new_tokens["refresh_token"], refresh1)

        r = self.client.post(
            "/token",
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh1,
                "client_id": client_id,
            },
        )
        self.assertNotEqual(r.status_code, 200)

    def test_tokens_persist_across_provider_restart(self) -> None:
        client_id = self._register_dcr_client()
        verifier, challenge = _pkce_pair()
        params = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": REDIRECT_URI,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "state": "p",
            "scope": "zotero.read",
        }
        first = self.client.get("/authorize", params=params)
        self._login(first.headers["location"].split("?", 1)[1])
        r = self.client.get("/authorize", params=params)
        code = parse_qs(urlparse(r.headers["location"]).query)["code"][0]
        r = self.client.post(
            "/token",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
                "client_id": client_id,
                "code_verifier": verifier,
            },
        )
        access = r.json()["access_token"]

        provider2 = build_auth_provider(
            public_url=PUBLIC_URL,
            password_hash=self.provider._password_hash,
            db_path=self.db_path,
        )
        try:
            verified = asyncio.run(provider2.verify_token(access))
            self.assertIsNotNone(verified, "Token should survive restart")
        finally:
            provider2.storage.close()


if __name__ == "__main__":
    unittest.main()
