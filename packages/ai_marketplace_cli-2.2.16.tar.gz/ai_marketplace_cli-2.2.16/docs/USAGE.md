# AI Marketplace CLI Usage

## Quick Start

```bash
uv tool install ./cli
ai login
ai init demo-model
cd demo-model
uv sync
ai publish --configure
ai push
```

## Installation

Requirements:

- Python 3.13+
- Docker

Install with one of:

```bash
uv tool install ./cli
pipx install ./cli
```

For contributor workflows:

```bash
cd cli
uv sync --extra dev
uv run ai --help
```

For local platform development, prefer the repo-aligned CLI over an unmanaged global tool:

```bash
uv run --project packages/python/cli ai --help
```

If you previously installed `ai` globally and have changed `packages/python/cli`, `packages/python/sdk`, or
`packages/python/framework`, reinstall it before testing publish flows:

```bash
uv tool install ./packages/python/cli --force
```

## Interactive Launcher

Running `ai` with no arguments on an interactive terminal opens the interactive launcher.

Behavior:

- minimal interactive menu
- project-aware home when `main.py` and `pyproject.toml` exist in the current directory
- remote model tools grouped under a `Marketplace Models` submenu
- arrow-key navigation
- `Enter` to select
- `Esc` to cancel or go back from prompt screens
- `Ctrl-C` to exit

Without interactive stdin/stdout, `ai` prints help instead of prompting.

## Scaffold

`ai init` creates a single-model Python project with:

- `main.py`: the `Model` subclass and `@mode`-decorated async methods (execution entrypoint)
- `schemas.py`: public mode contract schemas
- `playground.py`: presentation contract
- `internal/`: internal implementation (`loader.py`, `inference.py`)
- `tests/`: project tests (e.g. `test_model.py`)
- `tuning/`: optional fine-tuning code (top-level package)
- `runtime/`: **required for publish** — `runtime/Dockerfile` and `runtime/pyproject.toml` together define the remote image; `ai push` fails early if either is missing (there is no platform publish fallback image).
- `.aimp/project.toml`: hidden local operational config
- `.env`: project-local runtime secrets source used by `ai push` (`NAME=VALUE`; empty file allowed)
- `studio/article.mdx`: constrained MDX studio article for CLI authoring
- `studio/cover.jpg`: default Studio cover image scaffolded by the CLI
- `.aimp/publish.toml`: hidden publish state
- `pyproject.toml`: project metadata and dependency manifest for `uv` and `pip`
- `PROJECT.md` and `.agents/skills/`: assistant guidance

The hidden `.aimp/project.toml` includes a CLI-managed `[publish]` section for source-bundle
packaging metadata. Model authors should not need to edit it routinely.
Runtime secret names are no longer configured in `.aimp/project.toml`; they are derived from
project-local `.env` keys during publish.

Docker uses a stable build entrypoint:

```dockerfile
RUN python -m aimp_sdk.build_runner --module /app/main.py
```

Examples:

```bash
ai init my-model
ai init my-model --yes
ai init my-model --json
cd my-model
uv sync
ai publish --configure
ai push
```

Runtime dependency source depends on the publish branch by default:

- the installed `ai` CLI and project runtime pins must come from the same release line; if
  the project pins newer `ai-marketplace-framework` or `ai-marketplace-sdk` versions than
  the CLI expects, upgrade `ai-marketplace-cli` instead of downgrading the project
- `main` uses published index distributions for:
  - `ai-marketplace-framework`
  - `ai-marketplace-sdk`
- non-`main` builds local SDK/framework wheels from the checked-out branch and bundles them into the source archive
- scaffolded projects do not add local `[tool.uv.sources]` runtime overrides
- older generated projects that still contain runtime path sources must remove `[tool.uv.sources]`, run `uv sync`, and retry `ai push`
- set `AIMP_RUNTIME_DEPENDENCY_SOURCE_MODE=published-index` or `bundled-local-wheels` to override the branch default

## Authentication

Persist credentials:

```bash
ai login
ai login --gateway http://localhost:8080 --api-key pk_live_xxx
printf '%s' "$AIMP_API_KEY" | ai login --gateway http://localhost:8080 --stdin
```

Without `--gateway`, `ai login` suggests a Gateway URL in this order: `AIMP_GATEWAY_URL` → `logs/stage-runtime.json` (after `make stage-up`) → `STAGE_GATEWAY_PUBLIC_URL` in `infra/vm/stage.public.env` → `http://localhost:8080`.

Inspect current auth:

```bash
ai auth
ai auth --json
```

Remove stored credentials:

```bash
ai logout
```

Resolution order for flags, environment, and saved credentials:

1. `--gateway` / `--api-key`
2. `AIMP_GATEWAY_URL` / `AIMP_API_KEY`
3. `~/.aimp/config.json`

If no gateway is set by those three, commands such as `ai auth` use the same fallback chain as `ai login` (runtime state → `infra/vm/stage.public.env` → `http://localhost:8080`).
If stored credentials still reference the retired Cloud Run stage host (`*.a.run.app`), `ai auth`
prints `Stored gateway points to legacy Cloud Run stage. Run: ai login`; run `ai login` once to
rewrite `~/.aimp/config.json` to the VM gateway.

Only `ai login` writes `~/.aimp/config.json`.

## Model Usage

For local model projects, keep the CLI non-interactive by default. MCP is not required for this
workflow.

- Prefer explicit flags over prompt-driven flows
- Prefer `--json` for machine-readable results
- Treat the interactive launcher as human-only
- Use project-local skills under `.agents/skills/` before improvising workflows

Recommended command style:

```bash
ai contract validate --json
ai contract show --json
ai publish --configure --json
ai model pull --slug my-model --json
```

## Project Files

### `main.py`

`main.py` is the execution entrypoint. It defines the `Model` subclass and public
modes as `@mode`-decorated async methods.

```python
from aimp_sdk import Model, mode
from internal.loader import ExampleModelEngine
from playground import ExamplePlayground
from schemas import ExampleSchema


class ExampleModel(Model):
    engine = ExampleModelEngine

    async def _answer(self, query: str, history: list[dict[str, str]]) -> str:
        _ = history
        return query.strip()

    @mode(
        name="example",
        label="Example",
        description="Runs the example mode.",
        playground=ExamplePlayground,
    )
    async def example(
        self,
        inputs: ExampleSchema.Inputs,
        params: ExampleSchema.Params,
    ) -> ExampleSchema.Outputs:
        _ = params
        result = await self._answer(inputs.message, inputs.history or [])
        return ExampleSchema.Outputs(result=result)
```

### `pyproject.toml`

`pyproject.toml` is the local source of truth for project identity and version.
The SDK extracts the canonical publish contract from project code plus
`pyproject.toml` metadata.

Public operation rules:

- choose any non-empty subset of public mode names
- mode names do not imply runtime resources
- vector access is declared explicitly by the Python model contract and synced into TOML resources
- `capabilities.vector` is a public capability flag only; it is not inferred from mode names

Default `ai init` projects now include a minimal example starter model with:

- `Example` mode wiring in `main.py`

Public authoring uses `@mode` on `Model` methods only (not top-level functions):

```python
class ExampleModel(Model):
    engine = ExampleModelEngine

    @mode(name="example")
    async def example(
        self,
        inputs: ExampleSchema.Inputs,
        params: ExampleSchema.Params,
    ) -> ExampleSchema.Outputs:
        _ = params
        return ExampleSchema.Outputs(result=inputs.query.strip())
```

The default starter package is:

```text
main.py
playground.py
schemas.py
internal/
runtime/
tuning/
tests/
```

```toml
schema_version = 3

[capabilities]
vector = false
tuning = false

[modes.generate]
enabled = true

[[modes.generate.inputs]]
name = "prompt"
kind = "text"
required = true

[[modes.generate.outputs]]
name = "result"
kind = "text"
required = true
```

### `.aimp/publish.toml`

`.aimp/publish.toml` stores user-owned publish intent. The CLI writes it during
`ai publish` or `ai publish --configure`.

Platform-owned values such as infra base cost and platform fee are fetched from
Gateway and are not edited locally.

Constrained MDX article:

```toml
schema_version = 4

[studio]
name = "Example Model"
tags = ["example"]
visibility = "private"
cover_file = "studio/cover.jpg"
article_mdx_file = "studio/article.mdx"

[hardware]
supported_tiers = ["cpu-basic"]

[pricing]
developer_margin = 0
```

Constrained MDX supports headings `#` through `####` for Studio article sections.
Heading levels deeper than `####` are rejected during publish.

The platform still stores canonical Tiptap JSON internally, but local CLI authoring uses MDX only.
The default local Studio cover path is `studio/cover.jpg`.

### `model.yaml`

`model.yaml` is optional and is used only for layer cache resolution during publish.

```yaml
layers:
  base_image: python:3.11-slim
  runtime: python
  runtime_version: "3.11"
  os: ubuntu22.04
  arch: amd64
  libraries:
    - name: torch
      version: "2.1.0"
      variant: cuda12
```

## Publish

`ai publish` performs:

1. Contract extraction through `main.py` from the generated project root
2. Guided publish configuration when `.aimp/publish.toml` is missing or invalid on a TTY
3. Local config validation
4. Optional layer cache lookup from `model.yaml`
5. Source bundle archive creation from the local build context
6. Source bundle upload through Gateway multipart upload
7. Remote publish-build execution inside the platform Build Service
8. Final publish registration from the succeeded remote build output

Examples:

```bash
ai publish
ai publish --configure
ai publish --parallel 4
ai publish --verbose
ai publish --python .venv/bin/python
ai push
```

Extra Python runtime package indexes:

- local CLI preflight can resolve runtime packages through:
  - `AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL`
  - `AIMP_PYTHON_PACKAGE_INDEX_USERNAME`
  - `AIMP_PYTHON_PACKAGE_INDEX_PASSWORD`
- remote publish builds use the platform-side counterparts:
  - `PYTHON_PACKAGE_EXTRA_INDEX_URL`
  - `PYTHON_PACKAGE_INDEX_USERNAME`
  - `PYTHON_PACKAGE_INDEX_PASSWORD`
- these indexes are advanced overrides for the `published-index` mode
- `TestPyPI` works with URL only when you intentionally validate unpublished releases:
  - `AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL=https://test.pypi.org/simple/`
  - `PYTHON_PACKAGE_EXTRA_INDEX_URL=https://test.pypi.org/simple/`
- generated Dockerfiles consume the configured extra index via an optional BuildKit secret mount during
  `pip install`

Interpreter precedence for contract extraction:

1. `--python`
2. active `VIRTUAL_ENV/bin/python`
3. active `VIRTUAL_ENV/Scripts/python.exe`
4. active `VIRTUAL_ENV/Scripts/python`
5. the running CLI interpreter
6. `python`
7. `python3`

Requirements:

- authenticated user
- `main.py`
- `pyproject.toml`
- `.aimp/publish.toml` or a TTY session for guided configuration
- `runtime/Dockerfile` and `runtime/pyproject.toml` (both required for remote publish)

Notes:

- The CLI does not perform a local `docker push`; the platform Build Service performs the
  remote build and registry push.
- `ai publish` and `ai push` print remote publish-build logs incrementally while the Build
  Service job is still running.
- For local stack development, `make repair-local-registry-auth` provisions the Build
  Service registry Docker config secret used by that remote push path.

Guided configuration flow:

- fetches the platform hardware catalog and pricing context from Gateway
- lets you choose one or more supported hardware tiers
- prompts for developer margin only
- previews customer pricing before saving `.aimp/publish.toml`

Docker troubleshooting:

- Run `make repair-local-registry-auth` if remote publish logs show registry auth failures.
- Run `make dev-up` to ensure the local stack, including Build Service and registry, is up.
- If `ai push` reports Docker permission denial, refresh the shell/session that owns Docker access before retrying.

## Fine-Tune

Fine-tune submit is CLI-first in V1.

- target an already published model slug
- generate a schema-matched workspace with `ai fine-tune scaffold --model <slug>`
- edit `prepare_bundle.py` and write `bundle.json`
- the CLI uploads the bundle through Gateway
- the dashboard remains history/detail only
- succeeded jobs materialize a derived output model that you execute later by its model slug

Commands:

```bash
ai fine-tune init
ai fine-tune remove --yes
ai fine-tune scaffold --model vision-pro
ai fine-tune create --model vision-pro --workspace ./vision-pro-fine-tune
ai fine-tune list
ai fine-tune get --job 7d2a4b2c-....
```

## Jobs

Workspace job history is CLI-only in V1.

- `ai push` remains the command that builds, uploads, and waits for publish build completion
- `ai jobs list` is the unified read surface for build and fine-tune jobs
- `ai jobs get` resolves one job when you already know its type
- `ai jobs cancel` cancels a job and removes it from history
- `ai jobs delete` removes a terminal job from history
- `ai push` finalizes publish from the trusted remote build job and no longer exposes internal artifact URIs

Commands:

```bash
ai jobs list
ai jobs list --type build
ai jobs list --type fine-tune --status running
ai jobs list --model vision-pro --page 1 --page-size 20
ai jobs get --type build --job 7d2a4b2c-....
ai jobs get --type fine-tune --job 7d2a4b2c-....
ai jobs cancel --type build --job 7d2a4b2c-....
ai jobs delete --type fine-tune --job 7d2a4b2c-....
```

## Inspect And Pull

Inspect a remote model:

```bash
ai model inspect --slug my-model
ai model inspect --id 7d2a4b2c-....
ai model inspect --slug my-model --json
```

This command prints a human-readable summary by default.
Use `--json` to return machine-readable model details, analytics, layer-pool summary, and rates.

Pull remote metadata into the current directory:

```bash
ai model pull --slug my-model
ai model pull --id 7d2a4b2c-....
```

`ai model pull` updates `.aimp/publish.toml` and writes the studio article file.
If a local publish config already defines an article path, that path is reused.
Otherwise the pulled article is written to `studio/article.mdx`.

## Interactive Mode

Running `ai` with no arguments on a TTY opens a launcher with:

- init
- publish
- login
- auth
- logout
- model inspect
- model pull

The launcher uses arrow keys for navigation, `Enter` to select, and `Esc` to cancel.
Running `ai` without interactive stdin/stdout prints help instead of prompting.

## JSON And Debug Output

Use `--json` for machine-readable output.

JSON success payloads use:

```json
{
  "ok": true,
  "request_id": "cli-...",
  "data": {}
}
```

JSON error payloads use:

```json
{
  "ok": false,
  "request_id": "cli-...",
  "error": {
    "code": "validation_error",
    "category": "usage",
    "message": "Provide --slug or --id",
    "retryable": false,
    "exit_code": 2
  }
}
```

Use `--debug` to emit structured debug logs on stderr with the command `request_id`.

## Exit Codes

- `0`: success or expected status result
- `2`: usage or local config validation error
- `3`: authentication or permission failure
- `4`: local environment or dependency failure
- `5`: network or downstream service failure
- `6`: remote conflict, quota, or not-found state
- `130`: interrupted

## Quality Gates

```bash
cd cli
uv run ruff check .
uv run --extra dev mypy aimp_cli tests
uv run pytest
```
