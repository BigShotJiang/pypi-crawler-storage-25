from __future__ import annotations

import asyncio
import time
from typing import Any, Callable

import aiohttp

from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import GeneratedCharacter, ModelStatus


class GenerateClient:
    """Client for the Estuary character generation REST API."""

    def __init__(self, rest: RestClient, player_id: str) -> None:
        self._rest = rest
        self._player_id = player_id

    async def image_to_character(
        self,
        image: bytes,
        mime_type: str = "image/jpeg",
    ) -> GeneratedCharacter:
        """Upload an image to generate an AI character.

        Returns the created character immediately. Poll get_model_status()
        for 3D model progress.

        Args:
            image: Raw image bytes (JPEG, PNG, or WebP).
            mime_type: Image MIME type.
        """
        form = aiohttp.FormData()
        form.add_field(
            "image",
            image,
            filename="image.jpg",
            content_type=mime_type,
        )
        data = await self._rest.post_form(
            "/api/generate/image-to-character",
            data=form,
            headers={"X-Player-Id": self._player_id},
        )
        return GeneratedCharacter.from_dict(data)

    async def get_model_status(self, agent_id: str) -> ModelStatus:
        """Poll 3D model generation progress for a character.

        Args:
            agent_id: The character/agent ID returned by image_to_character().
        """
        data = await self._rest.get(f"/api/generate/{agent_id}/model-status")
        return ModelStatus.from_dict(data)

    async def generate_model(self, agent_id: str) -> dict[str, Any]:
        """Trigger 3D model generation for an existing agent.

        Submits a Meshy preview task. Also serves as retry when previous
        generation failed. Raises on 409 if generation already in progress.

        Args:
            agent_id: The character/agent ID returned by image_to_character().

        Returns:
            Dict with agentId, modelStatus, meshyPreviewTaskId.
        """
        data = await self._rest.post(
            f"/api/generate/{agent_id}/generate-model",
            body={},
            headers={"X-Player-Id": self._player_id},
        )
        return data

    async def wait_for_model(
        self,
        agent_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
        on_progress: Callable[[ModelStatus], None] | None = None,
    ) -> ModelStatus:
        """Poll model status until completion or failure.

        Args:
            agent_id: The character/agent ID.
            poll_interval: Seconds between polls.
            timeout: Max seconds to wait before raising TimeoutError.
            on_progress: Optional callback invoked with ModelStatus on each poll.

        Returns:
            The final ModelStatus (with model_status "completed" or "failed").

        Raises:
            asyncio.TimeoutError: If timeout is reached before completion.
        """
        start = time.monotonic()
        while True:
            status = await self.get_model_status(agent_id)
            if on_progress is not None:
                on_progress(status)
            if status.model_status in ("completed", "failed", "texture_failed"):
                return status
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise asyncio.TimeoutError(
                    f"Model generation timed out after {timeout}s for agent {agent_id}"
                )
            await asyncio.sleep(poll_interval)
