from __future__ import annotations

import asyncio
import logging
from types import TracebackType
from typing import Any

from estuary_sdk._utils.event_emitter import AsyncEventEmitter
from estuary_sdk._utils.logger import get_logger
from estuary_sdk.connection.socket_manager import SocketManager
from estuary_sdk.errors import ErrorCode, EstuaryError
from estuary_sdk.rest.characters_client import CharactersClient
from estuary_sdk.rest.generate_client import GenerateClient
from estuary_sdk.rest.memory_client import MemoryClient
from estuary_sdk.rest.players_client import PlayersClient
from estuary_sdk.rest.rest_client import RestClient
from estuary_sdk.types import (
    AgentConversationComplete,
    AgentTurnComplete,
    AgentTurnText,
    AgentTurnVoice,
    BotResponse,
    BotVoice,
    ConnectionState,
    EstuaryConfig,
    InterruptData,
    LiveKitTokenResponse,
    SessionInfo,
    VoiceMode,
)
from estuary_sdk.voice.voice_manager import VoiceManager, create_voice_manager

logger = logging.getLogger("estuary_sdk")


class EstuaryClient(AsyncEventEmitter):
    """Main entry point for the Estuary Python SDK.

    Usage::

        async with EstuaryClient(EstuaryConfig(...)) as client:
            client.on("bot_response", lambda r: print(r.text))
            await client.connect()
            client.send_text("Hello!")
    """

    def __init__(self, config: EstuaryConfig) -> None:
        super().__init__()
        self._config = config
        self._logger = get_logger(config.debug)
        self._socket = SocketManager(config)
        self._voice: VoiceManager | None = None
        self._voice_mode: VoiceMode | None = None
        self._rest = RestClient(config.server_url, config.api_key)
        self._memory: MemoryClient | None = None
        self._players: PlayersClient | None = None
        self._generate = GenerateClient(self._rest, config.player_id)
        self._characters = CharactersClient(self._rest, config.player_id)
        self._bind_socket_events()

    # ── Connection ──────────────────────────────────────────────

    async def connect(self) -> SessionInfo:
        """Connect to the Estuary server and authenticate.

        Returns:
            SessionInfo with session_id, conversation_id, character_id, player_id.
        """
        session = await self._socket.connect()
        # Initialize memory client now that we have the character_id
        self._memory = MemoryClient(
            self._rest,
            agent_id=session.character_id,
            player_id=session.player_id,
        )
        self._players = PlayersClient(self._rest, agent_id=session.character_id)
        return session

    async def disconnect(self) -> None:
        """Disconnect from the server and clean up resources."""
        if self._voice:
            await self._voice.dispose()
            self._voice = None
            self._voice_mode = None
        await self._socket.disconnect()
        await self._rest.close()

    @property
    def is_connected(self) -> bool:
        return self._socket.is_connected

    @property
    def session(self) -> SessionInfo | None:
        return self._socket.session

    # ── Text ────────────────────────────────────────────────────

    def send_text(self, text: str, text_only: bool = False) -> None:
        """Send a text message to the character.

        Args:
            text: The message text.
            text_only: If True, suppress voice response (text response only).
        """
        self._require_connected()
        payload: dict[str, Any] = {"text": text}
        if text_only:
            payload["textOnly"] = True
        self._socket.emit_event("text", payload)

    async def send_text_and_wait(
        self,
        text: str,
        *,
        text_only: bool = False,
        timeout: float = 20.0,
    ) -> BotResponse:
        """Send a text message and wait for the final bot response.

        Args:
            text: The message text.
            text_only: If True, suppress voice response.
            timeout: Max seconds to wait for a final response.

        Returns:
            The final BotResponse (with is_final=True).

        Raises:
            asyncio.TimeoutError: If no final response within timeout.
            EstuaryError: If not connected.
        """
        self._require_connected()

        loop = asyncio.get_running_loop()
        future: asyncio.Future[BotResponse] = loop.create_future()

        async def on_response(response: BotResponse) -> None:
            if response.is_final and not future.done():
                future.set_result(response)

        self.on("bot_response", on_response)
        try:
            self.send_text(text, text_only=text_only)
            return await asyncio.wait_for(future, timeout=timeout)
        finally:
            self.off("bot_response", on_response)

    # ── Agent-to-Agent ─────────────────────────────────────────

    def start_agent_conversation(
        self,
        agent_a_id: str,
        agent_b_id: str,
        *,
        conversation_context: str = "",
        max_turns: int = 8,
        timeout_seconds: int = 90,
    ) -> None:
        """Start an agent-to-agent conversation.

        Args:
            agent_a_id: First agent ID.
            agent_b_id: Second agent ID.
            conversation_context: Context for the conversation.
            max_turns: Maximum number of turns.
            timeout_seconds: Timeout in seconds.
        """
        self._require_connected()
        self._socket.emit_event(
            "start_agent_conversation",
            {
                "agent_a_id": agent_a_id,
                "agent_b_id": agent_b_id,
                "conversation_context": conversation_context,
                "max_turns": max_turns,
                "timeout_seconds": timeout_seconds,
            },
        )

    def stop_agent_conversation(self) -> None:
        """Stop the current agent-to-agent conversation."""
        self._require_connected()
        self._socket.emit_event("stop_agent_conversation", {})

    # ── Voice ───────────────────────────────────────────────────

    async def start_voice(self, mode: VoiceMode = VoiceMode.CONTINUOUS) -> None:
        """Start a voice session.

        Args:
            mode: CONTINUOUS for VAD-based turn detection, or
                  PUSH_TO_TALK for explicit start/stop recording control.
        """
        self._require_connected()
        if self._voice and self._voice.is_active:
            raise EstuaryError("Voice is already active", ErrorCode.VOICE_ALREADY_ACTIVE)

        self._voice_mode = mode

        # Build callback for LiveKit audio reception
        async def _on_livekit_audio(audio: bytes) -> None:
            await self.emit("audio_received", audio)

        # Extract embedded LiveKit token from session_info if available
        livekit_token: LiveKitTokenResponse | None = None
        session = self._socket.session
        if session and session.livekit_token:
            livekit_token = LiveKitTokenResponse(
                token=session.livekit_token,
                url=session.livekit_url or "",
                room=session.livekit_room or "",
            )

        self._voice = create_voice_manager(
            transport=self._config.voice_transport,
            socket_manager=self._socket,
            sample_rate=self._config.audio_sample_rate,
            voice_mode=mode,
            on_audio_received=_on_livekit_audio,
            livekit_token=livekit_token,
            apm_echo_cancellation=self._config.apm_echo_cancellation,
            apm_noise_suppression=self._config.apm_noise_suppression,
            apm_auto_gain_control=self._config.apm_auto_gain_control,
            apm_high_pass_filter=self._config.apm_high_pass_filter,
        )
        await self._voice.start()

    async def stop_voice(self) -> None:
        """Stop the voice session."""
        if self._voice:
            await self._voice.stop()
            self._voice = None
            self._voice_mode = None

    async def start_recording(self) -> None:
        """Begin streaming audio (push-to-talk mode)."""
        if not self._voice or not self._voice.is_active:
            raise EstuaryError("Voice is not active", ErrorCode.VOICE_NOT_ACTIVE)
        await self._voice.start_recording()

    async def stop_recording(self) -> None:
        """Stop streaming audio (push-to-talk mode). Triggers end-of-turn."""
        if not self._voice or not self._voice.is_active:
            raise EstuaryError("Voice is not active", ErrorCode.VOICE_NOT_ACTIVE)
        await self._voice.stop_recording()

    async def send_audio(self, audio: bytes) -> None:
        """Send raw PCM16 audio bytes to the server.

        Args:
            audio: Raw PCM16 audio bytes (16-bit signed integer, mono,
                   at the configured sample rate).
        """
        if not self._voice or not self._voice.is_active:
            raise EstuaryError("Voice is not active", ErrorCode.VOICE_NOT_ACTIVE)
        await self._voice.send_audio(audio)

    def toggle_mute(self) -> None:
        """Toggle voice mute state."""
        if self._voice:
            self._voice.toggle_mute()

    @property
    def is_voice_active(self) -> bool:
        return self._voice is not None and self._voice.is_active

    @property
    def is_muted(self) -> bool:
        return self._voice.is_muted if self._voice else False

    # ── Interrupt ───────────────────────────────────────────────

    def interrupt(self, message_id: str | None = None) -> None:
        """Interrupt the current bot response.

        Args:
            message_id: Specific message to interrupt, or None for current.
        """
        self._require_connected()
        payload: dict[str, Any] = {}
        if message_id:
            payload["message_id"] = message_id
        self._socket.emit_event("client_interrupt", payload)

    # ── Vision ──────────────────────────────────────────────────

    def send_camera_image(
        self,
        image_base64: str,
        mime_type: str,
        request_id: str | None = None,
        text: str | None = None,
    ) -> None:
        """Send a camera image for vision processing.

        Args:
            image_base64: Base64-encoded image data.
            mime_type: Image MIME type (e.g. "image/jpeg").
            request_id: Optional request ID (from camera_capture_request event).
            text: Optional text to accompany the image.
        """
        self._require_connected()
        payload: dict[str, Any] = {
            "image": image_base64,
            "mime_type": mime_type,
        }
        if request_id:
            payload["request_id"] = request_id
        if text:
            payload["text"] = text
        self._socket.emit_event("camera_image", payload)

    # ── Preferences ─────────────────────────────────────────────

    def update_preferences(
        self,
        enable_vision_acknowledgment: bool | None = None,
    ) -> None:
        """Update session preferences."""
        self._require_connected()
        payload: dict[str, Any] = {}
        if enable_vision_acknowledgment is not None:
            payload["enableVisionAcknowledgment"] = enable_vision_acknowledgment
        self._socket.emit_event("update_preferences", payload)

    # ── Playback tracking ───────────────────────────────────────

    def notify_audio_playback_complete(self, message_id: str | None = None) -> None:
        """Notify the server that audio playback has finished.

        Args:
            message_id: The message_id of the completed playback.
        """
        self._require_connected()
        payload: dict[str, Any] = {}
        if message_id:
            payload["message_id"] = message_id
        self._socket.emit_event("audio_playback_complete", payload)

    # ── Memory (REST) ───────────────────────────────────────────

    @property
    def memory(self) -> MemoryClient:
        """Access the Memory REST API client.

        Only available after connect() succeeds.
        """
        if self._memory is None:
            raise EstuaryError(
                "Memory client not available. Call connect() first.",
                ErrorCode.NOT_CONNECTED,
            )
        return self._memory

    # ── Players (REST) ───────────────────────────────────────────

    @property
    def players(self) -> PlayersClient:
        """Access the Players REST API client. Only available after connect()."""
        if self._players is None:
            raise EstuaryError(
                "Players client not available. Call connect() first.",
                ErrorCode.NOT_CONNECTED,
            )
        return self._players

    # ── Generate (REST) ──────────────────────────────────────────

    @property
    def generate(self) -> GenerateClient:
        """Access the character generation REST API client.

        Available immediately — does not require connect().
        """
        return self._generate

    # ── Characters (REST) ────────────────────────────────────────

    @property
    def characters(self) -> CharactersClient:
        """Access the Characters REST API client.

        Available immediately — does not require connect().
        """
        return self._characters

    # ── Context manager ─────────────────────────────────────────

    async def __aenter__(self) -> EstuaryClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.disconnect()

    # ── Internal ────────────────────────────────────────────────

    def _require_connected(self) -> None:
        if not self._socket.is_connected:
            raise EstuaryError("Not connected", ErrorCode.NOT_CONNECTED)

    def _bind_socket_events(self) -> None:
        """Forward socket manager events to client-level events."""

        async def on_connected(session: SessionInfo) -> None:
            await self.emit("connected", session)

        async def on_disconnected(reason: str) -> None:
            await self.emit("disconnected", reason)

        async def on_reconnecting(attempt: int) -> None:
            await self.emit("reconnecting", attempt)

        async def on_state_changed(state: ConnectionState) -> None:
            await self.emit("connection_state_changed", state)

        async def on_bot_response(response: BotResponse) -> None:
            await self.emit("bot_response", response)

        async def on_bot_voice(voice: BotVoice) -> None:
            await self.emit("bot_voice", voice)

        async def on_stt(response: Any) -> None:
            await self.emit("stt_response", response)

        async def on_interrupt(data: InterruptData) -> None:
            await self.emit("interrupt", data)

        async def on_error(error: Exception) -> None:
            await self.emit("error", error)

        async def on_auth_error(error: str) -> None:
            await self.emit("auth_error", error)

        async def on_quota(data: Any) -> None:
            await self.emit("quota_exceeded", data)

        async def on_camera(request: Any) -> None:
            await self.emit("camera_capture_request", request)

        async def on_voice_started() -> None:
            await self.emit("voice_started")

        async def on_voice_stopped() -> None:
            await self.emit("voice_stopped")

        async def on_voice_error(msg: str) -> None:
            await self.emit("voice_error", msg)

        async def on_livekit_connected(room: str) -> None:
            await self.emit("livekit_connected", room)

        async def on_livekit_disconnected() -> None:
            await self.emit("livekit_disconnected")

        async def on_memory_updated(event: Any) -> None:
            await self.emit("memory_updated", event)

        async def on_agent_turn_text(event: AgentTurnText) -> None:
            await self.emit("agent_turn_text", event)

        async def on_agent_turn_voice(event: AgentTurnVoice) -> None:
            await self.emit("agent_turn_voice", event)

        async def on_agent_turn_complete(event: AgentTurnComplete) -> None:
            await self.emit("agent_turn_complete", event)

        async def on_agent_conversation_complete(event: AgentConversationComplete) -> None:
            await self.emit("agent_conversation_complete", event)

        self._socket.on("session_info", on_connected)
        self._socket.on("disconnected", on_disconnected)
        self._socket.on("reconnecting", on_reconnecting)
        self._socket.on("connection_state_changed", on_state_changed)
        self._socket.on("bot_response", on_bot_response)
        self._socket.on("bot_voice", on_bot_voice)
        self._socket.on("stt_response", on_stt)
        self._socket.on("interrupt", on_interrupt)
        self._socket.on("error", on_error)
        self._socket.on("auth_error", on_auth_error)
        self._socket.on("quota_exceeded", on_quota)
        self._socket.on("camera_capture_request", on_camera)
        self._socket.on("voice_started", on_voice_started)
        self._socket.on("voice_stopped", on_voice_stopped)
        self._socket.on("voice_error", on_voice_error)
        self._socket.on("livekit_ready", on_livekit_connected)
        self._socket.on("livekit_error", on_livekit_disconnected)
        self._socket.on("memory_updated", on_memory_updated)
        self._socket.on("agent_turn_text", on_agent_turn_text)
        self._socket.on("agent_turn_voice", on_agent_turn_voice)
        self._socket.on("agent_turn_complete", on_agent_turn_complete)
        self._socket.on("agent_conversation_complete", on_agent_conversation_complete)
