from __future__ import annotations

from unittest.mock import AsyncMock, patch

import httpx
import pytest
from fastapi.testclient import TestClient

from forge_cloud.app import create_app
from forge_cloud.config import Settings

_MOCK_REQUEST = httpx.Request("POST", "http://mock-backend:8000/v1/chat/completions")


@pytest.fixture
def app_and_db(tmp_db_path):
    cfg = Settings(
        db_path=tmp_db_path,
        backend_url="http://mock-backend:8000",
        backend_type="vllm",
        admin_key="test-admin",
        free_daily_limit=5,
    )
    application = create_app(cfg)
    return application, cfg


@pytest.fixture
def client(app_and_db):
    application, _ = app_and_db
    with TestClient(application) as c:
        yield c


@pytest.fixture
def api_key(client):
    resp = client.post(
        "/v1/keys",
        json={"name": "test-user"},
        headers={"authorization": "Bearer test-admin"},
    )
    assert resp.status_code == 200
    return resp.json()["key"]


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_create_key_requires_admin(client):
    resp = client.post(
        "/v1/keys",
        json={"name": "test"},
        headers={"authorization": "Bearer wrong"},
    )
    assert resp.status_code == 403


def test_create_key_success(client):
    resp = client.post(
        "/v1/keys",
        json={"name": "my-app", "tier": "paid", "backend_type": "sglang"},
        headers={"authorization": "Bearer test-admin"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["key"].startswith("fk-")
    assert data["name"] == "my-app"
    assert data["tier"] == "paid"
    assert data["backend_type"] == "sglang"


def test_chat_no_auth(client):
    resp = client.post(
        "/v1/chat/completions",
        json={"model": "test", "messages": [{"role": "user", "content": "hi"}]},
    )
    assert resp.status_code == 401


def test_chat_invalid_key(client):
    resp = client.post(
        "/v1/chat/completions",
        json={"model": "test", "messages": [{"role": "user", "content": "hi"}]},
        headers={"authorization": "Bearer fk-invalid"},
    )
    assert resp.status_code == 401


@patch("forge_cloud.proxy.httpx.AsyncClient")
def test_chat_success_verifies_upstream(mock_client_cls, client, api_key):
    mock_response = httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "4"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 1,
                "total_tokens": 11,
            },
        },
        request=_MOCK_REQUEST,
    )
    mock_instance = AsyncMock()
    mock_instance.post = AsyncMock(return_value=mock_response)
    mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
    mock_instance.__aexit__ = AsyncMock(return_value=None)
    mock_client_cls.return_value = mock_instance

    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "Qwen/Qwen3.6-35B-A3B",
            "messages": [{"role": "user", "content": "What is 2+2?"}],
        },
        headers={"authorization": f"Bearer {api_key}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == "chatcmpl-test"
    assert data["choices"][0]["message"]["content"] == "4"
    assert "forge" in data
    assert data["forge"]["backend"] == "vllm"
    assert data["forge"]["thinking_mode"] in ("think", "no_think")
    assert data["forge"]["complexity"] in ("simple", "moderate", "complex")
    assert data["forge"]["sampling_profile"] in ("thinking", "instruct")

    mock_instance.post.assert_called_once()
    call_args = mock_instance.post.call_args
    upstream_body = call_args.kwargs.get("json", call_args[1].get("json", {}))
    assert upstream_body["model"] == "Qwen/Qwen3.6-35B-A3B"
    assert len(upstream_body["messages"]) == 1
    assert "extra_body" in upstream_body
    assert "chat_template_kwargs" in upstream_body["extra_body"]
    enable = upstream_body["extra_body"]["chat_template_kwargs"]["enable_thinking"]
    assert isinstance(enable, bool)


@patch("forge_cloud.proxy.httpx.AsyncClient")
def test_chat_stream_returns_sse(mock_client_cls, client, api_key):
    chunk = b'data: {"id":"chatcmpl-1","choices":[{"delta":{"content":"hi"}}]}\n\n'
    mock_instance = AsyncMock()

    class FakeStream:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            pass

        def raise_for_status(self):
            pass

        async def aiter_bytes(self):
            yield chunk

    def mock_stream(*args, **kwargs):
        return FakeStream()

    mock_instance.stream = mock_stream
    mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
    mock_instance.__aexit__ = AsyncMock(return_value=None)
    mock_client_cls.return_value = mock_instance

    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "test",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": True,
        },
        headers={"authorization": f"Bearer {api_key}"},
    )
    assert resp.status_code == 200
    assert "text/event-stream" in resp.headers.get("content-type", "")


@patch("forge_cloud.proxy.httpx.AsyncClient")
def test_chat_rate_limit(mock_client_cls, client, api_key):
    mock_response = httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "choices": [{"message": {"role": "assistant", "content": "ok"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        },
        request=_MOCK_REQUEST,
    )
    mock_instance = AsyncMock()
    mock_instance.post = AsyncMock(return_value=mock_response)
    mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
    mock_instance.__aexit__ = AsyncMock(return_value=None)
    mock_client_cls.return_value = mock_instance

    body = {
        "model": "test",
        "messages": [{"role": "user", "content": "hi"}],
    }
    headers = {"authorization": f"Bearer {api_key}"}

    for _ in range(5):
        resp = client.post("/v1/chat/completions", json=body, headers=headers)
        assert resp.status_code == 200

    resp = client.post("/v1/chat/completions", json=body, headers=headers)
    assert resp.status_code == 429


@patch("forge_cloud.proxy.httpx.AsyncClient")
def test_chat_backend_error(mock_client_cls, client, api_key):
    mock_instance = AsyncMock()
    mock_instance.post = AsyncMock(side_effect=httpx.ConnectError("connection refused"))
    mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
    mock_instance.__aexit__ = AsyncMock(return_value=None)
    mock_client_cls.return_value = mock_instance

    resp = client.post(
        "/v1/chat/completions",
        json={
            "model": "test",
            "messages": [{"role": "user", "content": "hi"}],
        },
        headers={"authorization": f"Bearer {api_key}"},
    )
    assert resp.status_code == 502
