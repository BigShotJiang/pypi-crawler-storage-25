from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

from .auth import authenticate, require_admin
from .config import Settings
from .db import Database
from .models import APIKeyCreate, ChatCompletionRequest
from .proxy import ProxyEngine
from .rate_limit import check_rate_limit

logger = logging.getLogger("forge-cloud")


def create_app(cfg: Settings | None = None) -> FastAPI:
    cfg = cfg or Settings()

    db = Database(cfg.db_path)
    engine = ProxyEngine()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await db.connect()
        logger.info(
            "forge-cloud started -- backend=%s url=%s",
            cfg.backend_type,
            cfg.backend_url,
        )
        yield
        await db.close()

    app = FastAPI(
        title="forge-cloud",
        version="0.1.0",
        description="Reasoning-aware inference proxy",
        lifespan=lifespan,
    )

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request):
        key_info = await authenticate(request, db)
        await check_rate_limit(key_info, db, cfg.free_daily_limit)

        body = await request.json()
        req = ChatCompletionRequest.model_validate(body)

        backend_type = engine.resolve_backend(key_info, cfg.backend_type)
        backend_url = key_info.backend_url or cfg.backend_url

        decision = engine.route_request(req, backend_type)
        upstream_body = engine.build_upstream_body(req, decision)

        if req.stream:
            await db.record_usage(key_info.key)
            return StreamingResponse(
                engine.forward_stream(upstream_body, backend_url, cfg.request_timeout),
                media_type="text/event-stream",
            )

        try:
            resp = await engine.forward(upstream_body, backend_url, cfg.request_timeout)
        except Exception as exc:
            logger.error("Backend request failed: %s", exc)
            raise HTTPException(
                status_code=502, detail="Backend request failed"
            ) from exc

        upstream_data: dict[str, Any] = resp.json()
        result = engine.build_response(upstream_data, decision)

        thinking_tokens = result.get("forge", {}).get("thinking_tokens", 0)
        response_tokens = result.get("forge", {}).get("response_tokens", 0)
        await db.record_usage(
            key_info.key,
            tokens_used=thinking_tokens + response_tokens,
            thinking_tokens=thinking_tokens,
            response_tokens=response_tokens,
        )

        return JSONResponse(content=result)

    @app.post("/v1/keys")
    async def create_key(request: Request, body: APIKeyCreate):
        auth_header = request.headers.get("authorization", "")
        provided = auth_header.removeprefix("Bearer ").strip()
        require_admin(cfg.admin_key, provided)
        info = await db.create_api_key(
            name=body.name,
            tier=body.tier,
            backend_url=body.backend_url,
            backend_type=body.backend_type,
        )
        return info.model_dump()

    return app
