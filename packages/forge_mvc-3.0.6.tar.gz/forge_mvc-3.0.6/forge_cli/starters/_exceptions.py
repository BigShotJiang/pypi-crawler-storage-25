class StarterBuildError(RuntimeError):
    pass
