"""Relation loading helpers for the CRUD generator."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from forge_cli.entities.relations import (
    ValidatedManyToManyRelation,
    load_entity_definitions,
    validate_relations_definition,
)
from forge_cli.entities.crud.context import (
    CrudManyToOneRelation,
    CrudManyToManyRelation,
)
from forge_cli.entities.crud.utils import (
    _pk_field,
    _to_snake,
    _text_label_fields,
)


_PREFERRED_LABEL_NAMES = ("name", "nom", "title", "titre", "label", "libelle")


def _entity_definition_by_relation_name(entity_map: dict[str, dict[str, Any]], name: str) -> dict[str, Any] | None:
    needle = name.lower()
    for definition in entity_map.values():
        if definition["entity"].lower() == needle:
            return definition
        if definition["table"].lower() == needle:
            return definition
        if _to_snake(definition["entity"]) == needle:
            return definition
    return None


def _load_crud_many_to_one_relations(
    definition: dict,
    entities_root: Path,
) -> list[CrudManyToOneRelation]:
    relations_path = entities_root / "relations.json"
    if not relations_path.exists():
        return []

    raw = json.loads(relations_path.read_text(encoding="utf-8"))
    validated_relations = validate_relations_definition(
        raw,
        source=str(relations_path),
        entities_root=entities_root,
    )
    if not validated_relations:
        return []

    entity_map = load_entity_definitions(entities_root)
    current_entity = definition["entity"]
    current_fields = {field["name"]: field for field in definition["fields"]}
    crud_relations: list[CrudManyToOneRelation] = []

    for relation in validated_relations:
        if relation.relation_type != "many_to_one" or relation.from_entity != current_entity:
            continue

        target = entity_map[relation.to_entity]
        label_field = _first_relation_label_field(target)
        source_field = current_fields[relation.from_field]
        target_snake = _to_snake(relation.to_entity)
        field_name = relation.from_field
        crud_relations.append(
            CrudManyToOneRelation(
                field_name=field_name,
                field_column=source_field["column"],
                target_entity=relation.to_entity,
                target_table=relation.to_table,
                target_pk_column=relation.to_column,
                target_label_column=label_field["column"],
                choices_function=f"get_{target_snake}_choices",
                choices_key=f"{field_name}_choices",
            )
        )
    return crud_relations


def _load_crud_many_to_many_relations(
    definition: dict,
    entities_root: Path,
) -> list[CrudManyToManyRelation]:
    relations_path = entities_root / "relations.json"
    if not relations_path.exists():
        return []

    raw = json.loads(relations_path.read_text(encoding="utf-8"))
    validated_relations = validate_relations_definition(
        raw,
        source=str(relations_path),
        entities_root=entities_root,
    )
    if not validated_relations:
        return []

    entity_map = load_entity_definitions(entities_root)
    current_entity = definition["entity"]
    current_names = {current_entity.lower(), definition["table"].lower(), _to_snake(current_entity)}
    snake = _to_snake(current_entity)
    crud_relations: list[CrudManyToManyRelation] = []

    for relation in validated_relations:
        if not isinstance(relation, ValidatedManyToManyRelation):
            continue
        if relation.source.lower() not in current_names:
            continue

        target = _entity_definition_by_relation_name(entity_map, relation.target)
        if target is None:
            raise ValueError(
                f"Entité cible many_to_many introuvable pour {relation.target!r} "
                f"dans {relations_path.as_posix()}"
            )

        target_snake = _to_snake(target["entity"])
        target_pk = _pk_field(target)
        label_field = _first_relation_label_field(target)
        field_name = f"{target_snake}_ids"
        crud_relations.append(
            CrudManyToManyRelation(
                source=relation.source,
                target=relation.target,
                pivot_table=relation.pivot_table,
                source_key=relation.source_key,
                target_key=relation.target_key,
                target_entity=target["entity"],
                target_table=target["table"],
                target_pk_column=target_pk["column"],
                target_label_column=label_field["column"],
                field_name=field_name,
                choices_function=f"get_{target_snake}_choices",
                choices_key=f"{target_snake}_choices",
                selected_function=f"get_{snake}_{field_name}",
                add_function=f"add_{snake}_{field_name}",
                sync_function=f"sync_{snake}_{field_name}",
                list_labels_function=f"get_{snake}_{target_snake}_labels_by_{snake}_id",
                show_labels_function=f"get_{snake}_{target_snake}_labels",
                list_context_key=f"{target_snake}s_by_{snake}_id",
                selected_key=f"{field_name}_selected",
                show_context_key=f"{target_snake}_labels",
                order_column=relation.order_column,
            )
        )
    return crud_relations


def _first_relation_label_field(definition: dict) -> dict:
    """Retourne le champ label de l'entité cible : nom préféré, puis premier texte, puis PK."""
    text_fields = _text_label_fields(definition)
    for preferred in _PREFERRED_LABEL_NAMES:
        for f in text_fields:
            if f["name"].lower() == preferred:
                return f
    if text_fields:
        return text_fields[0]
    return _pk_field(definition)


def _build_select_base(table: str, relations: list[CrudManyToOneRelation] | None) -> str:
    """Génère la clause SELECT...FROM...LEFT JOIN pour les requêtes de liste."""
    if not relations:
        return f"SELECT * FROM {table}"
    join_cols = ", ".join(
        f"{rel.target_table}.{rel.target_label_column} AS {rel.field_name}_label"
        for rel in relations
    )
    joins = " ".join(
        f"LEFT JOIN {rel.target_table}"
        f" ON {table}.{rel.field_column} = {rel.target_table}.{rel.target_pk_column}"
        for rel in relations
    )
    return f"SELECT {table}.*, {join_cols} FROM {table} {joins}"


def _unique_choice_relations(
    relations: list[CrudManyToOneRelation] | None,
) -> list[CrudManyToOneRelation]:
    unique: dict[str, CrudManyToOneRelation] = {}
    for relation in relations or []:
        unique.setdefault(relation.choices_function, relation)
    return list(unique.values())


def _unique_many_to_many_choice_relations(
    relations: list[CrudManyToManyRelation] | None,
) -> list[CrudManyToManyRelation]:
    unique: dict[str, CrudManyToManyRelation] = {}
    for relation in relations or []:
        unique.setdefault(relation.choices_function, relation)
    return list(unique.values())
