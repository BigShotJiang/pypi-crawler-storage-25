"""Example carbonation plugin package.

Demonstrates the full contract: a FileBase subclass, a named extractor,
a declarative selection helper, and a dedicated alembic migrations
directory. Install with ``uv pip install -e .`` alongside carbonation.
"""

from pathlib import Path

from carbonation import Plugin

from .extractors import extract_sample
from .model import File
from .rules import should_archive

plugin = Plugin(
    file_model=File,
    extractors={"sample": extract_sample},
    selection_functions={"should_archive": should_archive},
    migrations_path=Path(__file__).parent / "migrations" / "versions",
    query_defaults={"order_by": "-start"},
)
