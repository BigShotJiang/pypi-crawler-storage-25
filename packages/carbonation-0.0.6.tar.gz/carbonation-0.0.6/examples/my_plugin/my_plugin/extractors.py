"""Metadata extractors.

Each extractor is called once per complete group with the full list of
component paths and returns a dict whose keys map to ``File`` columns.
"""

import json
from datetime import datetime
from pathlib import Path


def extract_sample(file_paths: list[Path]) -> dict:
    """Parse the .json sibling of a sample group."""
    json_file = next(p for p in file_paths if p.suffix == ".json")
    data = json.loads(json_file.read_text())
    return {
        "start": datetime.fromisoformat(data["start"]),
        "stop": datetime.fromisoformat(data["stop"]),
        "category": data["category"],
        "origin": data.get("origin"),
    }
