"""Initial plugin columns for the example plugin.

Revision ID: p001
Revises:
Create Date: 2026-04-23
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = ("my_plugin",)
depends_on: Union[str, Sequence[str], None] = ("core",)


def upgrade() -> None:
    op.add_column("files", sa.Column("start", sa.DateTime, nullable=True))
    op.add_column("files", sa.Column("stop", sa.DateTime, nullable=True))
    op.add_column("files", sa.Column("category", sa.String(255), nullable=True))
    op.add_column("files", sa.Column("origin", sa.String(255), nullable=True))
    op.create_index("ix_files_category", "files", ["category"])


def downgrade() -> None:
    op.drop_index("ix_files_category", "files")
    op.drop_column("files", "origin")
    op.drop_column("files", "category")
    op.drop_column("files", "stop")
    op.drop_column("files", "start")
