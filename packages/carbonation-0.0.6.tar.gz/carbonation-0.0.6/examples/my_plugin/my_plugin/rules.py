"""Rule helpers exposed through the Plugin spec.

Signature conventions:
  * group_functions — ``fn(*, file_path: Path) -> str | None``
  * selection_functions — ``fn(*, metadata: dict, **kwargs) -> bool``
  * routing_functions — ``fn(*, metadata: dict) -> str | None``
"""


def should_archive(*, metadata: dict, **_) -> bool:
    """Accept any group where metadata declares a non-empty 'category'."""
    return bool(metadata.get("category"))
