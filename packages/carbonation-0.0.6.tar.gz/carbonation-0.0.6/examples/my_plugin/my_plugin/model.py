"""File model for the example plugin.

Domain columns must be nullable — they're populated *after* the file
group row is created, not at creation time.
"""

from datetime import datetime

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from carbonation.db.models import FileBase


class File(FileBase):
    __tablename__ = "files"

    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    origin: Mapped[str | None] = mapped_column(String(255), nullable=True)
