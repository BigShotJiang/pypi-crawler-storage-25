"""Plugin contract for carbonation.

A carbonation plugin is an installable Python package that ships:

- A :class:`FileBase` subclass owning the domain columns on the ``files``
  table. Defined in the plugin, imported on package load, automatically
  registered with ``Base.metadata`` so alembic can autogenerate migrations.
- Optional dicts of named callables that ``rules.toml`` can reference
  (``extractors``, ``group_functions``, ``selection_functions``,
  ``routing_functions``).
- Optional ``migrations_path`` — a directory of alembic revisions that
  carbonation composes with its core revisions via ``version_locations``.
- Optional ``query_defaults`` — default ``limit``/``order_by``/``columns``
  for ``carbonation query files`` and the public Python API.

The plugin builds a :class:`Plugin` instance in its package ``__init__``
and exposes it (conventionally as ``plugin = Plugin(...)``). Carbonation
discovers it via the ``carbonation.plugin`` entry point.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib import import_module
from importlib.metadata import entry_points
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

from carbonation.exceptions import ConfigError

ExtractFn = Callable[..., dict[str, Any]]
GroupFn = Callable[..., "str | None"]
SelectionFn = Callable[..., bool]
RoutingFn = Callable[..., "str | None"]


@dataclass(frozen=True)
class Plugin:
    """Declarative spec a plugin package exposes to carbonation.

    All callable dicts are optional — a deployment that only uses
    declarative rules and no metadata extraction can ship
    ``Plugin(file_model=File)`` with nothing else.
    """

    file_model: type
    extractors: dict[str, ExtractFn] = field(default_factory=dict)
    group_functions: dict[str, GroupFn] = field(default_factory=dict)
    selection_functions: dict[str, SelectionFn] = field(default_factory=dict)
    routing_functions: dict[str, RoutingFn] = field(default_factory=dict)
    migrations_path: Path | None = None
    query_defaults: dict[str, Any] | None = None


@dataclass(frozen=True)
class LoadedPlugin:
    """A :class:`Plugin` plus the imported package module for diagnostics."""

    spec: Plugin
    module: ModuleType


_ENTRY_POINT_GROUP = "carbonation.plugin"
_PLUGIN_ATTR = "plugin"


def _extract_spec(module: ModuleType) -> Plugin:
    """Pull the ``plugin`` attribute off a loaded plugin module."""
    spec = getattr(module, _PLUGIN_ATTR, None)
    if spec is None:
        raise ConfigError(
            f"Plugin module '{module.__name__}' does not expose a top-level "
            f"'{_PLUGIN_ATTR}' attribute. Build one with "
            f"`{_PLUGIN_ATTR} = Plugin(file_model=...)` in your package "
            f"__init__.py."
        )
    if not isinstance(spec, Plugin):
        raise ConfigError(
            f"Plugin module '{module.__name__}' exports '{_PLUGIN_ATTR}' "
            f"but it is a {type(spec).__name__}, not carbonation.Plugin."
        )
    return spec


def _resolve_entry_point_target(target: Any, ep_name: str) -> LoadedPlugin:
    """Normalize whatever an entry point resolves to into a :class:`LoadedPlugin`.

    Accepts both common shapes: ``my_plugin`` (the package module itself,
    from which we read the top-level ``plugin`` attribute) and
    ``my_plugin:plugin`` (the ``Plugin`` instance directly). In the
    latter case we import the declaring module so diagnostics still
    have a useful ``LoadedPlugin.module`` reference.
    """
    if isinstance(target, ModuleType):
        return LoadedPlugin(spec=_extract_spec(target), module=target)
    if isinstance(target, Plugin):
        module_name = getattr(target.file_model, "__module__", None)
        if module_name is None:
            raise ConfigError(
                f"Entry point '{_ENTRY_POINT_GROUP}:{ep_name}' resolved to a "
                f"Plugin instance whose file_model has no __module__ — cannot "
                f"locate the declaring package."
            )
        # Walk up to the package root (the first dotted segment) so we
        # retain a handle to the plugin package, not the submodule that
        # happened to define the model class.
        root_name = module_name.split(".", 1)[0]
        try:
            module = import_module(root_name)
        except ImportError as e:
            raise ConfigError(
                f"Entry point '{_ENTRY_POINT_GROUP}:{ep_name}' resolved to a "
                f"Plugin instance but the declaring package "
                f"'{root_name}' could not be imported: {e}"
            ) from e
        return LoadedPlugin(spec=target, module=module)
    raise ConfigError(
        f"Entry point '{_ENTRY_POINT_GROUP}:{ep_name}' must target a package "
        f"module (e.g. 'my_plugin') or a Plugin instance (e.g. "
        f"'my_plugin:plugin'), got {type(target).__name__}."
    )


def load_plugin(name: str | None = None) -> LoadedPlugin:
    """Import the plugin package and return the resolved spec + module.

    If ``name`` is given, imports that dotted module path. Otherwise
    scans registered entry points under ``carbonation.plugin`` — exactly
    one must be present. Entry points may target either the plugin
    package itself or its ``Plugin`` instance directly.

    Registers the plugin's File model with :func:`carbonation.db.models.set_file_model`
    so downstream queries have an explicit reference rather than relying
    on declarative-base subclass ordering.
    """
    from carbonation.db.models import set_file_model

    if name is not None:
        try:
            module = import_module(name)
        except ImportError as e:
            raise ConfigError(f"Failed to import plugin package '{name}': {e}") from e
        loaded = LoadedPlugin(spec=_extract_spec(module), module=module)
        set_file_model(loaded.spec.file_model)
        return loaded

    eps = entry_points(group=_ENTRY_POINT_GROUP)
    if len(eps) == 0:
        raise ConfigError(
            f"No plugin package registered. Set plugins.package in "
            f"config.toml to an import path, or install a package that "
            f"declares a '{_ENTRY_POINT_GROUP}' entry point."
        )
    if len(eps) > 1:
        names = sorted(ep.name for ep in eps)
        raise ConfigError(
            f"Multiple plugin packages registered under "
            f"'{_ENTRY_POINT_GROUP}': {names}. Pin one via "
            f"plugins.package in config.toml."
        )
    ep = next(iter(eps))
    loaded = _resolve_entry_point_target(ep.load(), ep.name)
    set_file_model(loaded.spec.file_model)
    return loaded


_KIND_DICTS = {
    "extractor": ("extractors", "plugin extractors"),
    "group": ("group_functions", "plugin group_functions"),
    "selection": ("selection_functions", "plugin selection_functions"),
    "routing": ("routing_functions", "plugin routing_functions"),
}


def resolve_plugin_callable(
    spec: Plugin,
    kind: str,
    name: str,
    *,
    rule_set: str,
    field: str,
) -> Callable[..., Any]:
    """Look up ``name`` in the dict for ``kind`` on ``spec``.

    Raises :class:`ConfigError` identifying the rule set, field, and the
    dict's available keys when the name is missing.
    """
    try:
        attr, label = _KIND_DICTS[kind]
    except KeyError as e:
        raise ValueError(f"Unknown plugin callable kind: {kind!r}") from e

    bucket: dict[str, Callable[..., Any]] = getattr(spec, attr)
    fn = bucket.get(name)
    if fn is None:
        available = sorted(bucket.keys())
        available_str = ", ".join(available) if available else "<none>"
        raise ConfigError(
            f"rule set '{rule_set}' field '{field}': {name!r} not in "
            f"{label} (available: {available_str})"
        )
    return fn
