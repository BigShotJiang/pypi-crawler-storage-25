"""CLI entry point for carbonation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import click
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from carbonation.config import (
    AppConfig,
    RulesConfig,
    load_app_config,
    load_rules_config,
)
from carbonation.log import setup_logging
from carbonation.plugin import LoadedPlugin, load_plugin


@dataclass
class AppContext:
    """Container for objects shared across CLI commands."""

    config: AppConfig
    rules: RulesConfig
    plugin: LoadedPlugin
    engine: Engine
    session_factory: sessionmaker[Session]


@click.group()
@click.option(
    "--config",
    "-c",
    "config_path",
    default="config.toml",
    type=click.Path(path_type=Path),
    help="Path to config.toml (default: ./config.toml)",
)
@click.pass_context
def cli(ctx: click.Context, config_path: Path) -> None:
    """Carbonation — file delivery monitoring and archival service."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config_path


def _load_service_context(config_path: Path) -> AppContext:
    """Shared setup for run and reconcile commands.

    Any configuration, plugin, or rules-loading failure is surfaced as a
    :class:`click.ClickException` so the user sees a clean error message
    rather than a raw Python traceback.
    """
    from pydantic import ValidationError

    from carbonation.db.engine import (
        create_engine_from_config,
        create_session_factory,
        verify_schema,
    )
    from carbonation.exceptions import CarbonationError

    try:
        config = load_app_config(config_path)
    except (CarbonationError, ValidationError, OSError, ValueError) as e:
        raise click.ClickException(f"Failed to load config: {e}") from e

    setup_logging(config.logging)

    try:
        plugin = load_plugin(config.plugins.package)
    except CarbonationError as e:
        raise click.ClickException(f"Failed to load plugin: {e}") from e

    try:
        rules = load_rules_config(config.rules.file, plugin)
    except (CarbonationError, ValidationError, OSError, ValueError) as e:
        raise click.ClickException(f"Failed to load rules: {e}") from e

    engine = create_engine_from_config(config.database)
    if not verify_schema(engine):
        raise click.ClickException(
            "Database not initialized. Run 'carbonation db init' first."
        )

    session_factory = create_session_factory(engine)
    return AppContext(
        config=config,
        rules=rules,
        plugin=plugin,
        engine=engine,
        session_factory=session_factory,
    )


# Import command modules to register them on the cli group.
# These must come after cli and _load_service_context are defined.
import carbonation.commands.init  # noqa: F401, E402
import carbonation.commands.config  # noqa: F401, E402
import carbonation.commands.db  # noqa: F401, E402
import carbonation.commands.run  # noqa: F401, E402
import carbonation.commands.reconcile  # noqa: F401, E402
import carbonation.commands.status  # noqa: F401, E402
import carbonation.commands.query  # noqa: F401, E402
