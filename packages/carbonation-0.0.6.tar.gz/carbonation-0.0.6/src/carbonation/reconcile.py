"""Delivery and archive reconciliation for carbonation."""

from __future__ import annotations

import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from queue import Queue
from typing import Any

from loguru import logger
from sqlalchemy.orm import Session

from carbonation.config import (
    ArchiveConfig,
    CompletenessConfig,
    RuleSet,
    RulesConfig,
    WatchConfig,
)
from carbonation.db.models import FileStatus, validate_extract_metadata
from carbonation.db.queries import (
    assign_component_to_group,
    bulk_insert_components,
    bulk_mark_archive_missing,
    bulk_mark_cleared,
    delete_components_by_ids,
    ensure_utc,
    find_or_create_file_group,
    get_archive_orphan_duplicate_ids,
    get_components_by_archive_paths,
    get_components_by_source_paths,
    get_components_in_archive_under,
    get_components_in_delivery,
    get_ungrouped_components_in_archive_under,
    mark_group_complete,
    update_component_status,
    update_file_metadata,
)
from carbonation.rules import check_completeness, resolve_group_key
from carbonation.watcher import FileEvent

_DEFAULT_STALE_THRESHOLD = timedelta(days=1)


def walk_directory(path: Path, recursive: bool = False) -> dict[str, tuple[int, float]]:
    """Walk a directory and return {absolute_path_str: (size, mtime)} for all files.

    Returns an empty dict if ``path`` does not exist (callers treat that as
    "no files yet"). Raises ``OSError`` if the directory exists but cannot
    be enumerated — callers must distinguish this from "empty directory" so
    a transient mount/permission failure is not interpreted as deletion of
    every tracked file.
    """
    result: dict[str, tuple[int, float]] = {}

    if not path.is_dir():
        logger.warning(f"Directory does not exist: {path}")
        return result

    if recursive:
        # os.walk swallows root errors by default; use onerror to surface them.
        scan_errors: list[OSError] = []
        for dirpath, _, filenames in os.walk(path, onerror=scan_errors.append):
            for fname in filenames:
                fpath = Path(dirpath) / fname
                try:
                    stat = fpath.stat()
                    result[str(fpath.resolve())] = (stat.st_size, stat.st_mtime)
                except OSError:
                    continue
        if scan_errors:
            # Surface the first error — typically root or top-level subdir.
            raise scan_errors[0]
    else:
        with os.scandir(path) as it:
            for entry in it:
                if entry.is_file():
                    try:
                        stat = entry.stat()
                        fpath = Path(entry.path).resolve()
                        result[str(fpath)] = (stat.st_size, stat.st_mtime)
                    except OSError:
                        continue

    return result


def reconcile_delivery(
    session: Session,
    watch_config: WatchConfig,
    event_queue: Queue[FileEvent] | None = None,
    stale_threshold: timedelta | None = None,
) -> dict[str, int]:
    """Reconcile the delivery directory with the database.

    Args:
        stale_threshold: Components in transient states (DETECTED, WAITING)
            younger than this are skipped during re-enqueue to avoid
            double-processing actively-handled files.  Defaults to 1 day.

    Returns stats dict: {new, cleared, requeued}.
    """
    stats = {"new": 0, "cleared": 0, "requeued": 0}

    # Step 1: Walk the delivery directory. A scan failure (permission denied,
    # mount blip, etc.) must not be interpreted as "directory is empty" — that
    # would clear every DB row for this watch.
    try:
        on_disk = walk_directory(watch_config.path, watch_config.recursive)
    except OSError as e:
        logger.warning(
            f"Reconcile [{watch_config.name}]: skipped — cannot scan "
            f"{watch_config.path}: {e}"
        )
        return stats
    disk_paths = set(on_disk.keys())

    # Step 2: Query DB for components in delivery for this watch
    db_components = get_components_in_delivery(session, watch_name=watch_config.name)
    db_by_path: dict[str, dict[str, Any]] = {c["source_path"]: c for c in db_components}
    db_paths = set(db_by_path.keys())

    # New files on disk not in DB
    new_paths = disk_paths - db_paths
    if new_paths:
        records = []
        for path_str in new_paths:
            size, _ = on_disk[path_str]
            p = Path(path_str)
            records.append(
                {
                    "watch_name": watch_config.name,
                    "filename": p.name,
                    "source_path": path_str,
                    "size_bytes": size,
                    "status": FileStatus.DETECTED,
                    "in_delivery": True,
                    "in_archive": False,
                }
            )
        # ignore_conflicts=True: a watchdog worker can insert a fresh
        # source_path between our disk walk and this bulk insert. Treat
        # conflicts as "already recorded" rather than letting an
        # IntegrityError unwind the whole reconcile cycle (including the
        # cleared-row updates above).
        bulk_insert_components(session, records, ignore_conflicts=True)
        stats["new"] = len(records)
        logger.info(
            f"Reconcile [{watch_config.name}]: {len(records)} new files detected"
        )

    # Files in DB but no longer on disk — mark cleared
    cleared_paths = db_paths - disk_paths
    if cleared_paths:
        cleared_ids = [db_by_path[p]["id"] for p in cleared_paths]
        bulk_mark_cleared(session, cleared_ids)
        stats["cleared"] = len(cleared_ids)
        logger.info(
            f"Reconcile [{watch_config.name}]: {len(cleared_ids)} files cleared"
        )

    session.commit()

    # Re-enqueue in-delivery files for re-evaluation.
    #
    # Statuses and their reconciliation behavior:
    #   DETECTED / WAITING — actively being processed; skip unless stuck
    #                        longer than stale_threshold.
    #   INTEGRITY_FAILED   — re-assess; file may have finished writing.
    #   TIMED_OUT          — terminal; manual retry only.
    #   NOT_SELECTED       — terminal here; re-enqueued by rules hot-reload.
    #   RETRY_PENDING      — handled by _check_pending_retries, skip here.
    #   ARCHIVED / FAILED / CLEARED — terminal, skip.
    #
    # Components discovered by *this* reconciliation cycle are always
    # enqueued regardless of status (they are brand new).
    if event_queue is not None:
        now = datetime.now(timezone.utc)
        threshold = (
            stale_threshold if stale_threshold is not None else _DEFAULT_STALE_THRESHOLD
        )
        stale_cutoff = now - threshold

        # Statuses that are never re-enqueued by reconciliation.
        terminal_statuses = {
            FileStatus.ARCHIVED,
            FileStatus.FAILED,
            FileStatus.CLEARED,
            FileStatus.TIMED_OUT,
            FileStatus.NOT_SELECTED,
        }
        # Statuses managed by their own retry path — don't duplicate here.
        retry_managed = {FileStatus.RETRY_PENDING}
        # Transient statuses that indicate active processing.
        transient_statuses = {FileStatus.DETECTED, FileStatus.WAITING}

        # Re-query to get updated state after inserts/clears
        current = get_components_in_delivery(session, watch_name=watch_config.name)
        for comp in current:
            status = comp["status"]

            if status in terminal_statuses or status in retry_managed:
                continue

            source = comp["source_path"]
            is_newly_discovered = source in new_paths

            # Skip recently-touched transient states to avoid
            # double-processing files that workers are actively handling.
            if not is_newly_discovered and status in transient_statuses:
                detected_at = ensure_utc(comp.get("detected_at"))
                if detected_at is not None:
                    if detected_at > stale_cutoff:
                        continue

            event_queue.put(
                FileEvent(
                    watch_name=watch_config.name,
                    path=Path(comp["source_path"]),
                )
            )
            stats["requeued"] += 1
        if stats["requeued"]:
            logger.info(
                f"Reconcile [{watch_config.name}]: {stats['requeued']} files re-enqueued"
            )

    return stats


def _resolve_walk_roots(
    archive_config: ArchiveConfig, paths: list[Path] | None
) -> list[Path]:
    """Return the directories to walk for this archive.

    If ``paths`` is None, returns ``[base_path]``. Otherwise, returns the subset
    of ``paths`` that resolve under ``base_path``. Non-matching paths are skipped
    silently — the caller validates cross-archive coverage.
    """
    if archive_config.base_path is None:
        return []
    base = archive_config.base_path.resolve()
    if paths is None:
        return [base]
    roots: list[Path] = []
    for p in paths:
        pr = p.resolve()
        try:
            pr.relative_to(base)
        except ValueError:
            continue
        roots.append(pr)
    return roots


def _resolve_watch_for_archive(
    archive_name: str,
    watch_configs: list[WatchConfig],
    specified_watch: str | None,
) -> WatchConfig | None:
    """Find the watch config whose rule set governs files archived to ``archive_name``.

    Matches watches whose default ``archive`` equals ``archive_name``. Returns
    the specified watch if provided and valid. Returns None (with a log line)
    when the mapping is ambiguous or absent — the caller should skip grouping
    for that archive.
    """
    candidates = [w for w in watch_configs if w.archive == archive_name]

    if specified_watch is not None:
        for w in candidates:
            if w.name == specified_watch:
                return w
        logger.warning(
            f"Watch '{specified_watch}' does not target archive '{archive_name}'; "
            f"skipping group assignment"
        )
        return None

    if not candidates:
        logger.info(
            f"No watch targets archive '{archive_name}'; skipping group assignment"
        )
        return None

    if len(candidates) > 1:
        names = sorted(w.name for w in candidates)
        logger.warning(
            f"Multiple watches target archive '{archive_name}': {names}. "
            f"Pass --watch to disambiguate. Skipping group assignment."
        )
        return None

    return candidates[0]


def _archive_group_key(
    archive_path: Path,
    archive_base: Path,
    completeness: CompletenessConfig,
) -> str | None:
    """Derive a group key for an archived file.

    For plugin-based grouping, delegates to the plugin. For stem-based
    grouping, prefixes the stem with the archive-relative parent directory
    — the normal pipeline archives a group's files into the same directory,
    so files with the same stem in different parent directories never came
    from the same original group.
    """
    if completeness.group_by == "plugin":
        return resolve_group_key(archive_path, completeness)

    try:
        parent_rel = archive_path.parent.resolve().relative_to(archive_base.resolve())
    except ValueError:
        parent_rel = Path(".")
    stem = archive_path.stem
    if parent_rel == Path("."):
        return stem
    return f"{parent_rel.as_posix()}/{stem}"


def _group_and_extract_orphans(
    session: Session,
    archive_config: ArchiveConfig,
    root: Path,
    watch: WatchConfig,
    rule_set: RuleSet,
) -> dict[str, int]:
    """Assign ungrouped archive components to file groups and extract metadata.

    Writes go through the caller's session; the caller is responsible for
    commit or rollback (e.g. dry_run rolls back at the end of reconciliation).
    """
    stats = {"groups_created": 0, "groups_completed": 0, "metadata_extracted": 0}

    completeness = rule_set.completeness
    if completeness is None:
        logger.warning(
            f"Rule set '{watch.rules}' has no completeness config; "
            f"cannot group orphans under {root}"
        )
        return stats

    base = archive_config.base_path
    if base is None:
        return stats

    ungrouped = get_ungrouped_components_in_archive_under(session, str(root))
    if not ungrouped:
        return stats

    buckets: dict[str, list[dict[str, Any]]] = {}
    for comp in ungrouped:
        comp_path = Path(comp["archive_path"])
        key = _archive_group_key(comp_path, base, completeness)
        if key is None:
            logger.debug(f"  could not resolve group key for {comp_path}")
            continue
        buckets.setdefault(key, []).append(comp)

    for group_key, components in buckets.items():
        component_paths = [Path(c["archive_path"]) for c in components]

        group_id = find_or_create_file_group(
            session,
            watch_name=watch.name,
            file_type=watch.type,
            group_key=group_key,
        )
        for comp in components:
            assign_component_to_group(session, comp["id"], group_id)
        stats["groups_created"] += 1

        is_complete = check_completeness(
            group_key,
            watch.name,
            completeness.expected_extensions,
            component_paths,
        )
        if not is_complete:
            logger.debug(
                f"  group '{group_key}' incomplete "
                f"({len(component_paths)}/{len(completeness.expected_extensions)})"
            )
            continue

        # Run extract+validate BEFORE marking the group complete — a failure
        # here must leave the group in an incomplete state so the next
        # reconcile can retry, otherwise we'd end up with complete=True
        # groups that have no metadata (caught only by
        # get_groups_missing_metadata).
        if (
            rule_set.metadata is not None
            and rule_set.metadata.extract_callable is not None
        ):
            try:
                metadata = rule_set.metadata.extract_callable(component_paths)
            except Exception:
                logger.exception(
                    f"extract() failed for group '{group_key}' — "
                    f"leaving incomplete for next reconcile"
                )
                continue

            errors = validate_extract_metadata(metadata)
            if errors:
                for err in errors:
                    logger.error(f"extract() validation [{group_key}]: {err}")
                continue

            update_file_metadata(session, group_id, metadata, raw_metadata=metadata)
            stats["metadata_extracted"] += 1

        mark_group_complete(session, group_id)
        stats["groups_completed"] += 1

    return stats


def reconcile_archive(
    session: Session,
    archive_configs: list[ArchiveConfig],
    *,
    paths: list[Path] | None = None,
    names: set[str] | None = None,
    dry_run: bool = False,
    watch_configs: list[WatchConfig] | None = None,
    rules_config: RulesConfig | None = None,
    watch_name: str | None = None,
) -> dict[str, int]:
    """Reconcile archive directories with the database.

    Args:
        paths: Restrict reconciliation to these sub-paths (must live under some
            configured archive's ``base_path``). When None, walk every
            configured archive's ``base_path``.
        names: Restrict to archive configs with these names.
        dry_run: Log what would change without committing or writing.
        watch_configs: List of watch configs. When provided together with
            ``rules_config``, reconciled orphans are also grouped and have
            metadata extracted via the rule set's resolved callables.
        rules_config: Loaded rules configuration — used to look up the rule
            set for each archive via its governing watch. Must already have
            its plugin callables resolved (i.e. loaded with a plugin).
        watch_name: If multiple watches target the same archive, use this
            watch's rule set for grouping. Ignored otherwise.

    Returns stats dict: ``{found, created, updated_flag, missing,
    groups_created, groups_completed, metadata_extracted}``.
    """
    stats = {
        "found": 0,
        "created": 0,
        "updated_flag": 0,
        "missing": 0,
        "dedup_removed": 0,
        "groups_created": 0,
        "groups_completed": 0,
        "metadata_extracted": 0,
    }

    do_grouping = watch_configs is not None and rules_config is not None

    if names is not None:
        archive_configs = [a for a in archive_configs if a.name in names]
        if not archive_configs:
            logger.warning(f"No archives matched names={sorted(names)}")
            return stats

    if paths is not None:
        matched_paths: set[Path] = set()
        for a in archive_configs:
            if a.base_path is None:
                continue
            base = a.base_path.resolve()
            for p in paths:
                try:
                    p.resolve().relative_to(base)
                    matched_paths.add(p)
                except ValueError:
                    continue
        unmatched = [p for p in paths if p not in matched_paths]
        if unmatched:
            raise ValueError(
                "Path(s) do not live under any configured archive base_path: "
                + ", ".join(str(p) for p in unmatched)
            )

    for archive_config in archive_configs:
        if archive_config.base_path is None:
            logger.warning(
                f"Archive '{archive_config.name}' has no base_path; skipping"
            )
            continue
        dest_base = archive_config.base_path
        if not dest_base.is_dir():
            logger.info(
                f"Archive '{archive_config.name}' base does not exist: {dest_base}; skipping"
            )
            continue

        walk_roots = _resolve_walk_roots(archive_config, paths)
        if not walk_roots:
            logger.debug(
                f"Archive '{archive_config.name}': no paths under {dest_base}, skipping"
            )
            continue

        per_archive = {
            "found": 0,
            "created": 0,
            "updated_flag": 0,
            "missing": 0,
            "dedup_removed": 0,
            "groups_created": 0,
            "groups_completed": 0,
            "metadata_extracted": 0,
        }
        for root in walk_roots:
            logger.info(
                f"Reconciling archive '{archive_config.name}' at {root}"
                + (" [dry-run]" if dry_run else "")
            )
            t0 = time.monotonic()
            try:
                on_disk = walk_directory(root, recursive=True)
            except OSError as e:
                # A scan failure must not cause every archived row under this
                # root to be flagged missing. Skip this root for this cycle.
                logger.warning(
                    f"  skipping {root}: cannot scan ({e}). "
                    f"Archive flags + missing detection deferred to next cycle."
                )
                continue
            logger.info(
                f"  walked {len(on_disk)} files in {time.monotonic() - t0:.2f}s"
            )

            # Remove orphan rows from prior reconciles that duplicate a
            # pipeline-archived row under this root — the pipeline row is
            # the authoritative one (delivery source_path, group, retry state).
            dup_ids = get_archive_orphan_duplicate_ids(session, str(root))
            if dup_ids:
                for dup_id in dup_ids:
                    logger.info(f"  removing duplicate orphan row id={dup_id}")
                if not dry_run:
                    delete_components_by_ids(session, dup_ids)
                    session.flush()
                per_archive["dedup_removed"] += len(dup_ids)

            disk_path_set = set(on_disk.keys())
            existing_by_source = get_components_by_source_paths(session, disk_path_set)
            existing_by_archive = get_components_by_archive_paths(
                session, disk_path_set
            )

            orphan_records = []
            for path_str, (size, _) in on_disk.items():
                # Prefer a canonical (pipeline) match over a self-referential
                # orphan match so flag updates target the authoritative row.
                arch_match = existing_by_archive.get(path_str)
                src_match = existing_by_source.get(path_str)
                existing = arch_match if arch_match is not None else src_match

                if existing is not None:
                    if not existing.get("in_archive"):
                        was_missing = existing.get("status") == FileStatus.MISSING
                        if was_missing:
                            logger.info(
                                f"  archive recovered: {path_str} "
                                f"(was MISSING, restoring to ARCHIVED)"
                            )
                        else:
                            logger.debug(f"  flagging in_archive: {path_str}")
                        if not dry_run:
                            # A re-discovered file at its archive path is
                            # ARCHIVED by definition — flip MISSING (or any
                            # other stale-flag state) back to ARCHIVED.
                            new_status = (
                                FileStatus.ARCHIVED
                                if was_missing
                                else existing["status"]
                            )
                            update_component_status(
                                session,
                                existing["id"],
                                new_status,
                                archive_path=path_str,
                            )
                        per_archive["updated_flag"] += 1
                    per_archive["found"] += 1
                else:
                    logger.debug(f"  orphan discovered: {path_str}")
                    p = Path(path_str)
                    orphan_records.append(
                        {
                            "watch_name": None,
                            "filename": p.name,
                            "source_path": path_str,
                            "archive_path": path_str,
                            "size_bytes": size,
                            "status": FileStatus.ARCHIVED,
                            "in_delivery": False,
                            "in_archive": True,
                        }
                    )

            if orphan_records:
                # Insert even in dry_run — the session rolls back at the end,
                # which lets the grouping pass preview against the would-be
                # orphan rows.
                bulk_insert_components(session, orphan_records, ignore_conflicts=True)
                session.flush()
            per_archive["created"] += len(orphan_records)

            if do_grouping:
                assert watch_configs is not None
                assert rules_config is not None
                watch = _resolve_watch_for_archive(
                    archive_config.name, watch_configs, watch_name
                )
                if watch is not None:
                    rule_set = rules_config.rule_sets.get(watch.rules)
                    if rule_set is None:
                        logger.error(
                            f"Rule set '{watch.rules}' for watch '{watch.name}' "
                            f"not found in rules config"
                        )
                    else:
                        group_stats = _group_and_extract_orphans(
                            session,
                            archive_config,
                            root,
                            watch,
                            rule_set,
                        )
                        for k, v in group_stats.items():
                            per_archive[k] = per_archive.get(k, 0) + v

            # Detect components the DB thinks are archived under this root
            # but are no longer on disk.
            archived_under = get_components_in_archive_under(session, str(root))
            missing_ids = [
                c["id"] for c in archived_under if c["archive_path"] not in on_disk
            ]
            if missing_ids:
                logger.warning(
                    f"  {len(missing_ids)} archived file(s) missing from disk "
                    f"under {root} — marking status=MISSING (archive_path "
                    f"preserved so a recovered file is detected on next cycle)"
                )
                for c in archived_under:
                    if c["archive_path"] not in on_disk:
                        logger.warning(f"  archive missing: {c['archive_path']}")
                if not dry_run:
                    bulk_mark_archive_missing(session, missing_ids)
            per_archive["missing"] += len(missing_ids)

        logger.info(
            f"  [{archive_config.name}] found={per_archive['found']} "
            f"created={per_archive['created']} "
            f"updated_flag={per_archive['updated_flag']} "
            f"missing={per_archive['missing']} "
            f"dedup_removed={per_archive['dedup_removed']} "
            f"groups_created={per_archive['groups_created']} "
            f"groups_completed={per_archive['groups_completed']} "
            f"metadata_extracted={per_archive['metadata_extracted']}"
        )
        for k, v in per_archive.items():
            stats[k] += v

    if dry_run:
        session.rollback()
    else:
        session.commit()

    logger.info(
        f"Archive reconcile complete: found={stats['found']} "
        f"created={stats['created']} "
        f"updated_flag={stats['updated_flag']} "
        f"missing={stats['missing']} "
        f"dedup_removed={stats['dedup_removed']} "
        f"groups_created={stats['groups_created']} "
        f"groups_completed={stats['groups_completed']} "
        f"metadata_extracted={stats['metadata_extracted']}"
        + (" [dry-run]" if dry_run else "")
    )

    return stats
