"""Watchdog integration with settle timer for carbonation."""

from __future__ import annotations

import fnmatch
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from queue import Queue

from loguru import logger
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from carbonation.config import WatchConfig


@dataclass
class FileEvent:
    """Represents a settled file arrival event."""

    watch_name: str
    path: Path
    detected_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class FileArrivalHandler(FileSystemEventHandler):
    """Watchdog handler that debounces file events with a settle timer."""

    def __init__(
        self, watch_config: WatchConfig, event_queue: Queue[FileEvent]
    ) -> None:
        super().__init__()
        self.config = watch_config
        self.queue = event_queue
        # Each entry is (timer, seq). The seq stamp lets a stale _emit
        # (one whose timer fired but was blocked acquiring the lock while
        # _handle replaced it) detect that it's been superseded and bail
        # out — without it, the same file gets enqueued twice.
        self._timers: dict[str, tuple[threading.Timer, int]] = {}
        self._next_seq = 0
        self._lock = threading.Lock()

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._handle(str(event.src_path))

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._handle(str(event.src_path))

    def _handle(self, src_path: str) -> None:
        path = Path(src_path)
        if not self._matches_patterns(path):
            return

        key = str(path.resolve())
        with self._lock:
            # Cancel existing timer for this path (no-op if it already fired).
            if key in self._timers:
                self._timers[key][0].cancel()

            self._next_seq += 1
            seq = self._next_seq
            timer = threading.Timer(
                self.config.settle_seconds,
                self._emit,
                args=(path, key, seq),
            )
            timer.daemon = True
            self._timers[key] = (timer, seq)
            timer.start()

    def _emit(self, path: Path, key: str, seq: int) -> None:
        """Called when settle timer fires — enqueue the event if still current."""
        with self._lock:
            entry = self._timers.get(key)
            if entry is None or entry[1] != seq:
                # Superseded by a newer _handle while we were blocked on
                # the lock; the newer timer will (or did) fire instead.
                return
            del self._timers[key]

        event = FileEvent(
            watch_name=self.config.name,
            path=path,
        )
        self.queue.put_nowait(event)
        logger.debug(f"File settled: {path.name} (watch: {self.config.name})")

    def _matches_patterns(self, path: Path) -> bool:
        """Check if a file matches the watch patterns and ignore patterns.

        Uses :func:`fnmatch.fnmatch` — case-sensitive on Linux/macOS,
        case-insensitive on Windows.
        """
        name = path.name

        # Check ignore patterns first
        for pattern in self.config.ignore_patterns:
            if fnmatch.fnmatch(name, pattern):
                return False

        # If no inclusion patterns specified, accept all
        if self.config.patterns is None:
            return True

        # Check inclusion patterns
        return any(fnmatch.fnmatch(name, p) for p in self.config.patterns)

    def cancel_all(self) -> None:
        """Cancel all pending settle timers."""
        with self._lock:
            for timer, _seq in self._timers.values():
                timer.cancel()
            self._timers.clear()


def create_observers(
    watch_configs: list[WatchConfig],
    event_queue: Queue[FileEvent],
) -> list[tuple[Observer, FileArrivalHandler]]:  # pyright: ignore[reportInvalidTypeForm]
    """Create and configure watchdog observers for all watch configs.

    Returns list of (observer, handler) tuples. Observers are NOT started.
    """
    result = []
    for wc in watch_configs:
        handler = FileArrivalHandler(wc, event_queue)
        observer = Observer()
        observer.schedule(handler, str(wc.path), recursive=wc.recursive)
        result.append((observer, handler))
        logger.info(f"Configured watcher: {wc.name} -> {wc.path}")
    return result
