"""Scaffold a new carbonation project."""

from __future__ import annotations

from pathlib import Path

import click

from carbonation.cli import cli

_CONFIG_TEMPLATE = """\
# Carbonation configuration file
# See https://github.com/jolsten/carbonation for full documentation.

[service]
# How often to poll for new events (used internally by watchdog settle timers)
poll_interval = "5s"

# How often to run delivery reconciliation (catches missed files, clears removed)
reconcile_interval = "1h"

# Maximum number of worker threads for processing events
workers = 4

# Retry policy for transient archive failures
max_retries = 3
retry_delay = "30m"

# How long a file can sit in DETECTED/WAITING before reconciliation
# considers it stuck and re-enqueues it for processing
stale_threshold = "1d"

[logging]
level = "INFO"

# Uncomment to log to a file (in addition to stderr)
# file = "carbonation.log"
# rotation = "10 MB"
# retention = "30 days"

# Set to "json" for structured JSON lines (for log aggregation)
format = "text"

[database]
# Structured database connection. Supported drivers: sqlite, mysql, postgresql
# For SQLite, only 'name' is needed (resolved relative to this config file).
# For MariaDB/PostgreSQL, set host, port, username, password (or use secrets file).
drivername = "sqlite"
name = "carbonation.db"
# host = "localhost"
# port = 3306
# username = "carbonation"
# password = "changeme"  # prefer ~/.config/carbonation/secrets.toml instead
# echo = false  # set true to log all SQL statements

[plugins]
# Import path of the plugin package. The package must expose a
# top-level `plugin = Plugin(...)` object with a FileBase subclass
# (see my_plugin/ in this directory).
# Omit the field entirely to use the carbonation.plugin entry point
# of the installed plugin package instead.
package = "my_plugin"

[rules]
# Path to the rules file (resolved relative to this config file)
file = "rules.toml"

# --- Watch directories ---
# Each [[watch]] block monitors a directory for incoming files.
# You can define multiple watches for different file sources.

[[watch]]
name = "my-watch"

# Optional file type label — stored on each group for filtering
# type = "signal"

# Directory to monitor for incoming files
# Use an absolute path for production; relative paths resolve from this config file.
path = "delivery"

# Watch subdirectories recursively
recursive = false

# Only process files matching these glob patterns (omit to accept all)
patterns = ["*.txt", "*.json"]

# Ignore files matching these patterns
ignore_patterns = ["*.tmp", ".*"]

# Name of the rule set in rules.toml to apply
rules = "my-rules"

# Name of the archive destination to use
archive = "my-archive"

# Seconds to wait after last file modification before processing
settle_seconds = 2.0

# --- Archive destinations ---
# Each [[archive]] block defines where and how files are archived.

[[archive]]
name = "my-archive"

# Root directory of the archive (used by reconcile archive)
# Use an absolute path for production; relative paths resolve from this config file.
base_path = "archive"

# Destination path template — {placeholders} are replaced with metadata values
# Resolved relative to base_path when set.
destination = "{category}/{start:%Y%m%d}"

# Archive action: copy, move, hardlink, or symlink
action = "copy"

# Create destination directories if they don't exist
create_directories = true

# File permissions (octal) applied after copy/move. Not applied to hardlink/symlink.
file_mode = 0o640
dir_mode = 0o750
"""

_RULES_TEMPLATE = """\
# Carbonation rules file
# Defines integrity checks, completeness grouping, metadata extraction,
# selection filters, and routing for each rule set.
#
# Rule sets are referenced by name in [[watch]] entries in config.toml.

[my-rules]

# --- Integrity checks ---
# Each [[my-rules.integrity]] entry is a check that must pass before
# a file is considered valid. All checks must pass.

[[my-rules.integrity]]
# Minimum file size in bytes — rejects truncated or empty files
type = "min_size"
value = 10

# --- Completeness ---
# Groups files by stem (e.g. sample_001.txt + sample_001.json)
# and waits until all expected extensions arrive.

[my-rules.completeness]
# Grouping strategy: "stem" (default) or "plugin" (custom function)
group_by = "stem"

# Extensions that must all be present for a group to be complete
expected_extensions = [".txt", ".json"]

# Which extension is the "primary" file — its archive path is stored on the group
primary_extension = ".json"

# How long to wait for a complete group before taking action
timeout_minutes = 60

# Action when timeout is reached: "warn" (log only), "skip", or "archive_partial"
on_timeout = "warn"

# --- Metadata extraction ---
# Name of an extractor exposed by the plugin's Plugin(extractors=...) dict.
# Called with all component paths once a group is complete.

[my-rules.metadata]
extract = "sample"

# --- Selection rules ---
# Determines whether a completed group should be archived.
# Multiple [[selection]] entries are ORed — any passing rule accepts the group.
# If no selection rules are defined, all groups are accepted.

[[my-rules.selection]]
# Require these metadata keys to be present and not None
has_keys = ["category"]

# [[my-rules.selection]]
# # Match a metadata field against regex patterns (any pattern match passes)
# field = "category"
# matches = ["^alpha", "^beta"]

# [[my-rules.selection]]
# # Plugin-based selection — call a function in a loaded plugin
# type = "plugin"
# function = "should_archive"

# --- Routing rules ---
# Determines which archive destination to use. Evaluated in order; first match wins.
# If no routing rules match, the default archive from the watch config is used.

# [[my-rules.routing]]
# # Glob-based routing — match against the group key / filename
# match = "calibration_*"
# archive = "calibration-archive"

# [[my-rules.routing]]
# # Plugin-based routing
# type = "plugin"
# function = "route_file"
"""

_PLUGIN_PYPROJECT = """\
[project]
name = "my_plugin"
dynamic = ["version"]
description = "Carbonation plugin package"
requires-python = ">=3.11"
dependencies = [
    "carbonation",
    "sqlalchemy>=2.0",
]

[project.entry-points."carbonation.plugin"]
my_plugin = "my_plugin"

[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"
fallback-version = "0.0.0"

[tool.hatch.build.hooks.vcs]
version-file = "my_plugin/_version.py"

[tool.hatch.build.targets.wheel]
packages = ["my_plugin"]
"""

_PLUGIN_INIT = """\
\"\"\"Carbonation plugin package.

Exposes the ``plugin`` spec object carbonation looks up — ``file_model``
plus optional role-scoped dicts that ``rules.toml`` references by key.
\"\"\"

from pathlib import Path

from carbonation import Plugin

from .extractors import extract_sample
from .model import File
from .rules import should_archive

plugin = Plugin(
    file_model=File,
    extractors={"sample": extract_sample},
    selection_functions={"should_archive": should_archive},
    migrations_path=Path(__file__).parent / "migrations" / "versions",
    query_defaults={"order_by": "-start"},
)
"""

_PLUGIN_MODEL = """\
\"\"\"File model for this plugin.

Domain columns MUST be nullable — they are populated after the group row
is created, not at creation time.
\"\"\"

from datetime import datetime

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from carbonation.db.models import FileBase


class File(FileBase):
    __tablename__ = "files"

    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(
        String(255), nullable=True, index=True
    )
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)
"""

_PLUGIN_EXTRACTORS = """\
\"\"\"Metadata extractors.

Each function is called once per complete group with the list of
component paths and returns a dict whose keys match ``File`` columns.
\"\"\"

import json
from datetime import datetime
from pathlib import Path


def extract_sample(file_paths: list[Path]) -> dict:
    json_file = next(p for p in file_paths if p.suffix == \".json\")
    data = json.loads(json_file.read_text())
    return {
        \"start\": datetime.fromisoformat(data[\"start\"]),
        \"stop\": datetime.fromisoformat(data[\"stop\"]),
        \"category\": data[\"category\"],
        \"source\": data.get(\"source\"),
    }
"""

_PLUGIN_RULES = """\
\"\"\"Optional rule helpers exposed through Plugin(...).

Each callable signature:
  * group_functions: fn(*, file_path: Path) -> str | None
  * selection_functions: fn(*, metadata: dict, **kwargs) -> bool
  * routing_functions: fn(*, metadata: dict) -> str | None
\"\"\"


def should_archive(*, metadata: dict, **_) -> bool:
    return bool(metadata.get(\"category\"))
"""

_PLUGIN_INITIAL_MIGRATION = """\
\"\"\"Initial plugin columns.

Revision ID: p001
Revises:
\"\"\"

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = \"p001\"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = (\"my_plugin\",)
depends_on: Union[str, Sequence[str], None] = (\"core\",)


def upgrade() -> None:
    op.add_column(\"files\", sa.Column(\"start\", sa.DateTime, nullable=True))
    op.add_column(\"files\", sa.Column(\"stop\", sa.DateTime, nullable=True))
    op.add_column(\"files\", sa.Column(\"category\", sa.String(255), nullable=True))
    op.add_column(\"files\", sa.Column(\"source\", sa.String(255), nullable=True))
    op.create_index(\"ix_files_category\", \"files\", [\"category\"])


def downgrade() -> None:
    op.drop_index(\"ix_files_category\", \"files\")
    op.drop_column(\"files\", \"source\")
    op.drop_column(\"files\", \"category\")
    op.drop_column(\"files\", \"stop\")
    op.drop_column(\"files\", \"start\")
"""

_SYSTEMD_TEMPLATE = """\
[Unit]
Description=Carbonation file delivery monitoring and archival service
After=network.target

[Service]
Type=simple
User={user}
Group={user}
WorkingDirectory={workdir}
ExecStart={workdir}/.venv/bin/carbonation -c {workdir}/config.toml run
Restart=on-failure
RestartSec=10

# Logging (stdout/stderr captured by journald)
StandardOutput=journal
StandardError=journal
SyslogIdentifier=carbonation

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
# Add your delivery and archive paths here:
# ReadWritePaths={workdir} /data/delivery /data/archive
PrivateTmp=true

[Install]
WantedBy=multi-user.target
"""


@cli.command("init")
@click.option(
    "--dir",
    "target_dir",
    default=".",
    type=click.Path(path_type=Path),
    help="Directory to create files in (default: current directory)",
)
@click.option("--systemd", is_flag=True, help="Also generate a systemd service file")
@click.option(
    "--user",
    default="carbonation",
    help="User for systemd service (default: carbonation)",
)
def init_project(target_dir: Path, systemd: bool, user: str) -> None:
    """Scaffold a new carbonation project with config, rules, and plugin templates."""
    target_dir = target_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    files_written = []

    # config.toml
    config_path = target_dir / "config.toml"
    if config_path.exists():
        click.echo(f"  SKIP {config_path} (already exists)")
    else:
        config_path.write_text(_CONFIG_TEMPLATE, encoding="utf-8")
        files_written.append(config_path)

    # rules.toml
    rules_path = target_dir / "rules.toml"
    if rules_path.exists():
        click.echo(f"  SKIP {rules_path} (already exists)")
    else:
        rules_path.write_text(_RULES_TEMPLATE, encoding="utf-8")
        files_written.append(rules_path)

    # my_plugin/ — installable plugin package skeleton.
    plugin_root = target_dir / "my_plugin"
    package_dir = plugin_root / "my_plugin"
    migrations_dir = package_dir / "migrations" / "versions"
    migrations_dir.mkdir(parents=True, exist_ok=True)

    plugin_layout = [
        (plugin_root / "pyproject.toml", _PLUGIN_PYPROJECT),
        (package_dir / "__init__.py", _PLUGIN_INIT),
        (package_dir / "model.py", _PLUGIN_MODEL),
        (package_dir / "extractors.py", _PLUGIN_EXTRACTORS),
        (package_dir / "rules.py", _PLUGIN_RULES),
        (migrations_dir / "p001_initial_plugin_columns.py", _PLUGIN_INITIAL_MIGRATION),
    ]
    for path, body in plugin_layout:
        if path.exists():
            click.echo(f"  SKIP {path} (already exists)")
            continue
        path.write_text(body, encoding="utf-8")
        files_written.append(path)

    # systemd service file
    if systemd:
        service_path = target_dir / "carbonation.service"
        if service_path.exists():
            click.echo(f"  SKIP {service_path} (already exists)")
        else:
            service_path.write_text(
                _SYSTEMD_TEMPLATE.format(user=user, workdir=str(target_dir)),
                encoding="utf-8",
            )
            files_written.append(service_path)

    for f in files_written:
        click.echo(f"  CREATED {f}")

    click.echo(f"\nProject initialized in {target_dir}")
    click.echo("Next steps:")
    click.echo("  1. Edit config.toml — set your watch paths and archive destination")
    click.echo("  2. Edit rules.toml — configure your integrity/selection rules")
    click.echo("  3. Edit my_plugin/my_plugin/ — define File columns + extractors")
    click.echo("  4. Install the plugin:  uv pip install -e ./my_plugin")
    click.echo("  5. Run: carbonation check config")
    click.echo("  6. Run: carbonation db init")
    click.echo("  7. Run: carbonation run")
