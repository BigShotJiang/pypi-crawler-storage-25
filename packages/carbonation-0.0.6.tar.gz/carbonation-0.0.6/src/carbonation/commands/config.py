"""Config validation and rules dry-run commands."""

from __future__ import annotations

from pathlib import Path

import click
from loguru import logger

from carbonation.cli import cli, _load_service_context
from carbonation.config import load_app_config, load_rules_config
from carbonation.log import setup_logging
from carbonation.plugin import load_plugin


@cli.group()
def check() -> None:
    """Validation and dry-run commands."""


@check.command("config")
@click.pass_context
def check_config(ctx: click.Context) -> None:
    """Validate config.toml and rules.toml."""
    config_path: Path = ctx.obj["config_path"]

    try:
        config = load_app_config(config_path)
    except Exception as e:
        raise click.ClickException(f"Invalid config.toml: {e}") from e

    setup_logging(config.logging)

    # If a plugin is configured, load it so ``load_rules_config`` can
    # resolve plugin callables (metadata.extract, selection/routing
    # functions). Without this, missing-plugin-key typos in rules.toml
    # slip past ``check config`` and only blow up at service start. When
    # no plugin is configured, fall back to plugin-unaware parsing so
    # configs that don't use plugin callables still validate.
    plugin = None
    if config.plugins.package is not None:
        try:
            plugin = load_plugin(config.plugins.package)
        except Exception as e:
            raise click.ClickException(f"Failed to load plugin: {e}") from e

    try:
        rules = load_rules_config(config.rules.file, plugin)
    except FileNotFoundError:
        raise click.ClickException(f"Rules file not found: {config.rules.file}")
    except Exception as e:
        raise click.ClickException(f"Invalid rules.toml: {e}") from e

    # Validate cross-references
    errors: list[str] = []
    warnings: list[str] = []

    rule_set_names = set(rules.rule_sets.keys())
    archive_names = {a.name for a in config.archive}

    for w in config.watch:
        if w.rules not in rule_set_names:
            errors.append(
                f"Watch '{w.name}' references rules '{w.rules}' "
                f"which does not exist in {config.rules.file}"
            )
        if w.archive not in archive_names:
            errors.append(
                f"Watch '{w.name}' references archive '{w.archive}' "
                f"which does not exist in config"
            )

        # Check that watch patterns cover completeness extensions
        if w.rules in rule_set_names and w.patterns is not None:
            rs = rules.rule_sets[w.rules]
            if rs.completeness and rs.completeness.expected_extensions:
                for ext in rs.completeness.expected_extensions:
                    pattern = f"*{ext}"
                    if pattern not in w.patterns:
                        warnings.append(
                            f"Watch '{w.name}' patterns {w.patterns} may not "
                            f"include completeness extension '{ext}'"
                        )

    # Validate primary_extension is in expected_extensions
    for rs_name, rs in rules.rule_sets.items():
        if (
            rs.completeness
            and rs.completeness.primary_extension
            and rs.completeness.expected_extensions
            and rs.completeness.primary_extension
            not in rs.completeness.expected_extensions
        ):
            warnings.append(
                f"Rule set '{rs_name}': primary_extension "
                f"'{rs.completeness.primary_extension}' is not in "
                f"expected_extensions {rs.completeness.expected_extensions}"
            )

    # Validate routing references
    for rs_name, rs in rules.rule_sets.items():
        for routing in rs.routing:
            if routing.archive and routing.archive not in archive_names:
                errors.append(
                    f"Rule set '{rs_name}' routing references archive "
                    f"'{routing.archive}' which does not exist in config"
                )

    # Warn if file_mode is set with hardlink/symlink actions
    for a in config.archive:
        if a.action in ("hardlink", "symlink") and a.file_mode != 0o640:
            warnings.append(
                f"Archive '{a.name}': file_mode has no effect with "
                f"action={a.action!r} (permissions come from the source file)"
            )

    # Plugin import was verified by the early ``load_plugin`` call above;
    # any failure there aborts with a ClickException, so by this point the
    # plugin is known to load and resolve rules callables successfully.

    for w in warnings:
        logger.warning(w)
        click.echo(f"WARNING: {w}", err=True)

    if errors:
        for e in errors:
            logger.error(e)
            click.echo(f"ERROR: {e}", err=True)
        raise click.ClickException(
            f"Config validation failed with {len(errors)} error(s)"
        )

    click.echo("Config is valid.")


@check.command("rules")
@click.argument("rules_path", type=click.Path(exists=True, path_type=Path))
@click.pass_context
def check_rules_cmd(ctx: click.Context, rules_path: Path) -> None:
    """Dry-run a candidate rules file against existing DB groups.

    Shows which groups would be accepted, rejected, or routed differently
    compared to the current rules.
    """
    from carbonation.config import load_rules_config
    from carbonation.db.models import get_file_model
    from carbonation.rules import evaluate_selection, resolve_routing

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    try:
        candidate = load_rules_config(rules_path, app.plugin)
    except Exception as e:
        raise click.ClickException(f"Invalid rules file: {e}") from e

    session = app.session_factory()
    try:
        # Get all completed file groups with their metadata
        FileModel = get_file_model()
        from sqlalchemy import select as sa_select

        t = FileModel.__table__
        rows = [
            dict(row._mapping)
            for row in session.execute(sa_select(t).where(t.c.complete.is_(True)))
        ]

        if not rows:
            click.echo("No completed groups in database to evaluate.")
            return

        changes: dict[str, list] = {
            "newly_accepted": [],
            "newly_rejected": [],
            "rerouted": [],
        }

        watch_by_name = {w.name: w for w in app.config.watch}

        for row in rows:
            wc_name = row["watch_name"]
            wc = watch_by_name.get(wc_name)
            if wc is None:
                continue

            current_rs = app.rules.rule_sets.get(wc.rules)
            candidate_rs = candidate.rule_sets.get(wc.rules)
            if current_rs is None or candidate_rs is None:
                continue

            # Build metadata dict from domain columns
            from carbonation.db.models import FILEBASE_COLUMNS

            metadata = {
                k: v
                for k, v in row.items()
                if k not in FILEBASE_COLUMNS and v is not None
            }

            current_selected = evaluate_selection(metadata, current_rs.selection)
            candidate_selected = evaluate_selection(metadata, candidate_rs.selection)

            gk = row["group_key"]
            if current_selected and not candidate_selected:
                changes["newly_rejected"].append(gk)
            elif not current_selected and candidate_selected:
                changes["newly_accepted"].append(gk)

            if current_selected and candidate_selected:
                current_route = resolve_routing(
                    metadata, gk, current_rs.routing, wc.archive
                )
                candidate_route = resolve_routing(
                    metadata, gk, candidate_rs.routing, wc.archive
                )
                if current_route != candidate_route:
                    changes["rerouted"].append((gk, current_route, candidate_route))

        click.echo(f"Evaluated {len(rows)} completed group(s):")
        click.echo(f"  Newly accepted:  {len(changes['newly_accepted'])}")
        click.echo(f"  Newly rejected:  {len(changes['newly_rejected'])}")
        click.echo(f"  Rerouted:        {len(changes['rerouted'])}")

        if changes["newly_accepted"]:
            click.echo(f"\nNewly accepted: {', '.join(changes['newly_accepted'][:20])}")
        if changes["newly_rejected"]:
            click.echo(f"\nNewly rejected: {', '.join(changes['newly_rejected'][:20])}")
        if changes["rerouted"]:
            for gk, old, new in changes["rerouted"][:20]:
                click.echo(f"\n  {gk}: {old} -> {new}")
    finally:
        session.close()
