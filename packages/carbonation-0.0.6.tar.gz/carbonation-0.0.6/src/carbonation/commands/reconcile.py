"""Reconciliation commands."""

from __future__ import annotations

from pathlib import Path

import click

from carbonation.cli import cli, _load_service_context


@cli.group()
def reconcile() -> None:
    """Reconciliation commands."""


@reconcile.command("delivery")
@click.pass_context
def reconcile_delivery_cmd(ctx: click.Context) -> None:
    """Reconcile delivery directories with the database."""
    from carbonation.reconcile import reconcile_delivery

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    for wc in app.config.watch:
        session = app.session_factory()
        try:
            stats = reconcile_delivery(session, wc)
            click.echo(f"[{wc.name}] new={stats['new']} cleared={stats['cleared']}")
        finally:
            session.close()

    click.echo("Delivery reconciliation complete.")


@reconcile.command("archive")
@click.argument(
    "paths",
    nargs=-1,
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
)
@click.option(
    "--archive",
    "archive_names",
    multiple=True,
    help="Restrict to archive(s) by name. Repeatable.",
)
@click.option(
    "--watch",
    "watch_name",
    default=None,
    help="Disambiguate which watch's rule set governs an archive when "
    "multiple watches target the same archive.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Report changes without writing to the database.",
)
@click.pass_context
def reconcile_archive_cmd(
    ctx: click.Context,
    paths: tuple[Path, ...],
    archive_names: tuple[str, ...],
    watch_name: str | None,
    dry_run: bool,
) -> None:
    """Reconcile archive directories with the database.

    If PATHS are given, each must live under some configured archive's
    base_path. Otherwise every configured archive is walked in full.

    Orphaned archive files are also grouped (respecting each rule set's
    completeness config) and have metadata extracted via the configured
    plugin ``extract()`` function.
    """
    from carbonation.reconcile import reconcile_archive

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    session = app.session_factory()
    try:
        stats = reconcile_archive(
            session,
            app.config.archive,
            paths=list(paths) if paths else None,
            names=set(archive_names) if archive_names else None,
            dry_run=dry_run,
            watch_configs=app.config.watch,
            rules_config=app.rules,
            watch_name=watch_name,
        )
        click.echo(
            f"found={stats['found']} created={stats['created']} "
            f"updated_flag={stats['updated_flag']} missing={stats['missing']} "
            f"dedup_removed={stats['dedup_removed']} "
            f"groups_created={stats['groups_created']} "
            f"groups_completed={stats['groups_completed']} "
            f"metadata_extracted={stats['metadata_extracted']}"
            + (" [dry-run]" if dry_run else "")
        )
    except ValueError as e:
        raise click.BadParameter(str(e)) from e
    finally:
        session.close()
