"""CLI command subpackage — imported by cli.py to register commands."""
