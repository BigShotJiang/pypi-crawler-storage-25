"""Database management commands."""

from __future__ import annotations

from pathlib import Path

import click
from loguru import logger

from carbonation.cli import cli, _load_service_context
from carbonation.config import load_app_config
from carbonation.log import setup_logging
from carbonation.plugin import load_plugin


@cli.group()
def db() -> None:
    """Database management commands."""


def _load_plugin_for_db(config):
    """Resolve the plugin for db commands; caller wraps errors as ClickException."""
    from carbonation.exceptions import ConfigError

    try:
        return load_plugin(config.plugins.package)
    except ConfigError as e:
        raise click.ClickException(str(e)) from e


@db.command("init")
@click.pass_context
def db_init(ctx: click.Context) -> None:
    """Initialize the database schema (core + plugin alembic branches).

    Reports whether the DB was freshly created or was already initialized,
    so an accidental re-run doesn't look like a successful first init.
    """
    from carbonation.db.engine import (
        create_engine_from_config,
        init_db,
        verify_schema,
    )

    config_path: Path = ctx.obj["config_path"]
    config = load_app_config(config_path)
    setup_logging(config.logging)

    plugin = _load_plugin_for_db(config)

    engine = create_engine_from_config(config.database)
    already_initialized = verify_schema(engine)

    init_db(engine, plugin.spec)

    if already_initialized:
        logger.info("Database already initialized; migrations up to date")
        click.echo("Database already initialized (migrations up to date).")
    else:
        logger.info("Database initialized successfully")
        click.echo("Database initialized.")


@db.command("revision")
@click.option("-m", "--message", required=True, help="Revision message/slug.")
@click.option(
    "--autogenerate",
    is_flag=True,
    help="Compare the plugin's File model to the live DB and emit schema diffs.",
)
@click.pass_context
def db_revision(ctx: click.Context, message: str, autogenerate: bool) -> None:
    """Generate a new plugin alembic revision.

    The first revision for a plugin is anchored on a dedicated branch
    (the plugin's import name, e.g. ``my_plugin``) with ``depends_on =
    ("core",)``. Subsequent revisions chain off the plugin's branch head.
    """
    from alembic import command

    from carbonation.db.engine import _build_alembic_config, create_engine_from_config

    config_path: Path = ctx.obj["config_path"]
    config = load_app_config(config_path)
    setup_logging(config.logging)

    plugin = _load_plugin_for_db(config)
    if plugin.spec.migrations_path is None:
        raise click.ClickException(
            "Plugin does not declare a migrations_path; nothing to write to."
        )

    engine = create_engine_from_config(config.database)
    cfg = _build_alembic_config(engine, plugin.spec)

    plugin_versions = Path(plugin.spec.migrations_path)
    plugin_versions.mkdir(parents=True, exist_ok=True)
    is_first = not any(plugin_versions.glob("*.py"))

    branch = plugin.module.__name__
    kwargs: dict = {
        "message": message,
        "autogenerate": autogenerate,
        "version_path": str(plugin_versions),
    }
    if is_first:
        kwargs["head"] = "base"
        kwargs["branch_label"] = branch
        kwargs["depends_on"] = "core"
    else:
        # Pin new revisions to the plugin branch head so the core branch
        # isn't accidentally chosen when multiple heads exist.
        kwargs["head"] = f"{branch}@head"

    command.revision(cfg, **kwargs)
    click.echo(f"Revision created under {plugin_versions}")


@db.command("upgrade")
@click.pass_context
def db_upgrade(ctx: click.Context) -> None:
    """Apply pending database migrations on every alembic branch."""
    from carbonation.db.engine import create_engine_from_config, run_migrations

    config_path: Path = ctx.obj["config_path"]
    config = load_app_config(config_path)
    setup_logging(config.logging)

    plugin = _load_plugin_for_db(config)

    engine = create_engine_from_config(config.database)
    run_migrations(engine, plugin.spec)
    click.echo("Database migrations applied.")


@db.command("status")
@click.pass_context
def db_status(ctx: click.Context) -> None:
    """Show database summary statistics."""
    from carbonation.db.queries import (
        get_archive_count,
        get_delivery_count,
        get_groups_missing_metadata,
        get_status_counts,
    )

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()
    try:
        click.echo("Component status:")
        counts = get_status_counts(session)
        for status, count in sorted(counts.items()):
            click.echo(f"  {status:<20s} {count:>6d}")

        delivery = get_delivery_count(session)
        archived = get_archive_count(session)
        click.echo(f"\nIn delivery: {delivery}")
        click.echo(f"In archive:  {archived}")

        missing = get_groups_missing_metadata(session)
        if missing:
            click.echo(f"\nWARNING: {missing} completed group(s) have no metadata")
        else:
            click.echo("\nAll completed groups have metadata.")

        from carbonation.db.engine import check_schema_drift

        drift = check_schema_drift(app.engine)
        if drift:
            click.echo(f"\nSchema check: {len(drift)} issue(s):")
            for issue in drift:
                click.echo(f"  WARNING: {issue}", err=True)
        else:
            click.echo("\nSchema: required tables are present.")
    finally:
        session.close()
