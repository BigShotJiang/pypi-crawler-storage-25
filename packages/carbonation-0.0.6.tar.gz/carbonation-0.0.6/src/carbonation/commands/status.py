"""Status and retry commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from carbonation.cli import cli, _load_service_context


def _format_duration(td: Any) -> str:
    """Format a timedelta as a human-readable string."""
    total = int(td.total_seconds())
    if total < 60:
        return f"{total}s ago"
    if total < 3600:
        return f"{total // 60}m ago"
    if total < 86400:
        return f"{total // 3600}h {(total % 3600) // 60}m ago"
    return f"{total // 86400}d {(total % 86400) // 3600}h ago"


@cli.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show service and database status."""
    import os as _os
    from datetime import datetime as dt, timedelta, timezone as tz

    from rich.console import Console
    from rich.table import Table as RichTable

    from carbonation.db.queries import (
        ensure_utc,
        get_archive_count,
        get_delivery_count,
        get_groups_missing_metadata,
        get_last_detected_at,
        get_oldest_incomplete_group,
        get_service_state,
        get_status_counts,
        get_status_counts_since,
    )

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()
    console = Console()

    try:
        now = dt.now(tz.utc)

        # --- Service heartbeat ---
        state = get_service_state(session)
        if state is not None and state.get("last_heartbeat"):
            hb = ensure_utc(state["last_heartbeat"])
            assert hb is not None
            age = now - hb
            age_str = _format_duration(age)
            if age.total_seconds() > 300:
                age_str += " (stale)"
            click.echo(f"Service heartbeat:  {age_str}")
            click.echo(f"  started:          {state['started_at']}")
            click.echo(f"  queue depth:      {state['queue_depth']}")
        else:
            click.echo("Service heartbeat:  no data (service has not run)")

        # --- Last activity ---
        last_detected = get_last_detected_at(session)
        if last_detected is not None:
            click.echo(f"  last new file:    {last_detected}")

        click.echo()

        # --- Status table by time bucket ---
        buckets = [
            ("1h", timedelta(hours=1)),
            ("4h", timedelta(hours=4)),
            ("1d", timedelta(days=1)),
            ("7d", timedelta(days=7)),
            ("30d", timedelta(days=30)),
        ]

        # Collect all statuses that appear in any bucket
        all_statuses: set[str] = set()
        bucket_data: list[dict[str, int]] = []
        for label, delta in buckets:
            counts = get_status_counts_since(session, now - delta)
            all_statuses.update(counts.keys())
            bucket_data.append(counts)

        # Also get all-time totals
        total_counts = get_status_counts(session)
        all_statuses.update(total_counts.keys())

        if all_statuses:
            table = RichTable(title="Component Status by Time Window")
            table.add_column("Status", style="bold")
            for label, _ in buckets:
                table.add_column(label, justify="right")
            table.add_column("Total", justify="right", style="bold")

            for s in sorted(all_statuses):
                row = [s]
                for counts in bucket_data:
                    v = counts.get(s, 0)
                    row.append(str(v) if v > 0 else "")
                row.append(str(total_counts.get(s, 0)))
                table.add_row(*row)

            console.print(table)
        else:
            click.echo("No components in database.")

        # --- Totals ---
        delivery = get_delivery_count(session)
        archived = get_archive_count(session)
        click.echo(f"\nIn delivery: {delivery}")
        click.echo(f"In archive:  {archived}")

        # --- Retry queue ---
        retry_count = total_counts.get("retry_pending", 0)
        if retry_count:
            click.echo(f"Retry queue: {retry_count}")

        # --- Oldest incomplete group ---
        oldest = get_oldest_incomplete_group(session)
        if oldest is not None:
            created = ensure_utc(oldest["created_at"])
            if created is not None:
                age = _format_duration(now - created)
                click.echo(
                    f"\nOldest incomplete group: {oldest['group_key']} "
                    f"[{oldest['watch_name']}] — {age}"
                )

        # --- Warnings ---
        missing = get_groups_missing_metadata(session)
        if missing:
            click.echo(f"\nWARNING: {missing} completed group(s) have no metadata")

        # --- Watch directory health ---
        click.echo("\nWatch directories:")
        for wc in app.config.watch:
            if not wc.path.is_dir():
                click.echo(f"  {wc.name}: MISSING ({wc.path})")
            elif not _os.access(wc.path, _os.R_OK):
                click.echo(f"  {wc.name}: NOT READABLE ({wc.path})")
            else:
                click.echo(f"  {wc.name}: OK ({wc.path})")
    finally:
        session.close()


@cli.command()
@click.option("--watch-name", default=None, help="Retry only this watch")
@click.option("--group-key", default=None, help="Retry only this group")
@click.option(
    "--status",
    "retry_status",
    default=None,
    type=click.Choice(["failed", "integrity_failed", "timed_out", "not_selected"]),
    help="Retry components with this status (default: failed)",
)
@click.pass_context
def retry(
    ctx: click.Context,
    watch_name: str | None,
    group_key: str | None,
    retry_status: str | None,
) -> None:
    """Re-enqueue failed components for retry."""
    from carbonation.db.models import FileStatus
    from carbonation.db.queries import reset_failed_for_retry

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()

    statuses = None
    if retry_status == "integrity_failed":
        statuses = {FileStatus.INTEGRITY_FAILED}
    elif retry_status == "timed_out":
        statuses = {FileStatus.TIMED_OUT}
    elif retry_status == "not_selected":
        statuses = {FileStatus.NOT_SELECTED}
    elif retry_status == "failed" or retry_status is None:
        statuses = {FileStatus.FAILED}

    try:
        count = reset_failed_for_retry(
            session,
            watch_name=watch_name,
            group_key=group_key,
            statuses=statuses,
        )
        session.commit()
        click.echo(f"Re-enqueued {count} component(s) for retry.")
    finally:
        session.close()
