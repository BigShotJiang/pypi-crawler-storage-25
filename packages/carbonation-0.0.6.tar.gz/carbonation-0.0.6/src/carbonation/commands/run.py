"""Service run command."""

from __future__ import annotations

from pathlib import Path

import click

from carbonation.cli import cli, _load_service_context


@cli.command()
@click.option(
    "--dry-run", is_flag=True, help="Load, reconcile, then exit (no watchers)"
)
@click.option(
    "--once", is_flag=True, help="Reconcile, process all pending events, then exit"
)
@click.pass_context
def run(ctx: click.Context, dry_run: bool, once: bool) -> None:
    """Start the carbonation file monitoring service."""
    import sys

    from carbonation.service import CarbonationService

    if dry_run and once:
        raise click.UsageError("--dry-run and --once are mutually exclusive")

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    service = CarbonationService(
        app.config,
        app.rules,
        app.plugin,
        app.engine,
        app.session_factory,
    )
    if once:
        sys.exit(service.run_once())
    else:
        service.start(dry_run=dry_run)
