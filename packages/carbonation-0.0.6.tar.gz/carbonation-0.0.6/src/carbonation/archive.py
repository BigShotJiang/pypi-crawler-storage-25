"""Archive actions for carbonation — copy, move, hardlink."""

from __future__ import annotations

import errno
import os
import shutil
from pathlib import Path

from loguru import logger


def resolve_destination(
    template: str,
    metadata: dict,
    base_path: Path | None = None,
) -> Path:
    """Expand {key} placeholders in archive destination template.

    If base_path is provided, the expanded template is resolved relative to it.
    Otherwise, the expanded path is resolved as absolute.

    Raises ValueError if the resolved path escapes ``base_path``.
    """
    try:
        expanded = template.format_map(metadata)
    except KeyError as e:
        raise ValueError(
            f"Archive destination template references unknown key {e}: {template!r}"
        ) from e
    if base_path is not None:
        resolved = (base_path / expanded).resolve()
        base_resolved = base_path.resolve()
        if not resolved.is_relative_to(base_resolved):
            raise ValueError(
                f"Resolved archive path escapes base_path: "
                f"{resolved} is not under {base_resolved}"
            )
        return resolved
    return Path(expanded).resolve()


def archive_file(
    source: Path,
    dest_dir: Path,
    action: str,
    create_dirs: bool = True,
    file_mode: int | None = None,
    dir_mode: int | None = None,
    expected_size: int | None = None,
) -> Path:
    """Archive a single file to a destination directory.

    Args:
        source: Source file path.
        dest_dir: Destination directory.
        action: One of "copy", "move", "hardlink", "symlink".
        create_dirs: Create destination directories if they don't exist.
        file_mode: Permission bits for the archived file (e.g. 0o440).
        dir_mode: Permission bits for created directories (e.g. 0o550).
        expected_size: Expected file size in bytes for post-copy verification.

    Returns: The final archive path.
    """
    if create_dirs:
        if dir_mode is not None:
            _mkdir_with_mode(dest_dir, dir_mode)
        else:
            dest_dir.mkdir(parents=True, exist_ok=True)

    dest = dest_dir / source.name

    # If destination already exists with the same size, skip the operation.
    # This avoids re-archiving on retry when the previous attempt succeeded
    # for this component but a sibling in the same group failed.
    if dest.exists() and expected_size is not None:
        try:
            existing_size = dest.stat().st_size
            if existing_size == expected_size:
                logger.debug(
                    f"Skipping archive of {source.name}: destination exists "
                    f"with matching size ({expected_size} bytes)"
                )
                return dest
        except OSError:
            pass  # stat failed — proceed with archive

    if action == "copy":
        shutil.copy2(source, dest)
    elif action == "move":
        shutil.move(str(source), str(dest))
    elif action == "hardlink":
        try:
            # `dest.exists()` is False for a broken symlink — without
            # `is_symlink()`, a stale dangling link at the dest would let
            # `hardlink_to` raise FileExistsError and the action would be
            # permanently stuck until manual cleanup.
            if dest.exists() or dest.is_symlink():
                dest.unlink()
            dest.hardlink_to(source)
        except OSError as e:
            if e.errno == errno.EXDEV or "cross-device" in str(e).lower():
                raise OSError(
                    f"Cannot hardlink across filesystems: {source} -> {dest}. "
                    f"Use action='copy' or 'move' instead."
                ) from e
            raise
    elif action == "symlink":
        try:
            if dest.exists() or dest.is_symlink():
                dest.unlink()
            dest.symlink_to(source.resolve())
        except FileExistsError:
            dest.unlink()
            dest.symlink_to(source.resolve())
    else:
        raise ValueError(f"Unknown archive action: {action!r}")

    if file_mode is not None and action in ("copy", "move"):
        os.chmod(dest, file_mode)

    # Post-archive size verification for copy/move
    if expected_size is not None and action in ("copy", "move"):
        actual_size = dest.stat().st_size
        if actual_size != expected_size:
            dest.unlink(missing_ok=True)
            raise OSError(
                f"Archive verification failed for {source.name}: "
                f"expected {expected_size} bytes, got {actual_size}"
            )

    logger.debug(f"Archived {source.name}: {action} -> {dest}")
    return dest


def _mkdir_with_mode(path: Path, mode: int) -> None:
    """Create directories recursively, applying mode to each new directory."""
    if path.exists():
        return
    to_create: list[Path] = []
    current = path
    while not current.exists():
        to_create.append(current)
        current = current.parent
    for d in reversed(to_create):
        d.mkdir(exist_ok=True)
        os.chmod(d, mode)
