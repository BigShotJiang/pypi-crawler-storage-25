"""SQLAlchemy ORM models for carbonation."""

from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    JSON,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, declared_attr


class Base(DeclarativeBase):
    pass


class FileStatus(enum.Enum):
    DETECTED = "detected"
    INTEGRITY_FAILED = "integrity_failed"
    WAITING = "waiting"
    TIMED_OUT = "timed_out"
    NOT_SELECTED = "not_selected"
    ARCHIVED = "archived"
    RETRY_PENDING = "retry_pending"
    FAILED = "failed"
    CLEARED = "cleared"
    # File was archived but later not seen on disk by reconcile_archive.
    # ``archive_path`` is preserved so a recovered file (e.g. restored from
    # offsite backup) can be re-detected at the same path and flipped back
    # to ARCHIVED on the next reconcile cycle.
    MISSING = "missing"


class FileComponent(Base):
    __tablename__ = "file_components"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    watch_name: Mapped[str | None] = mapped_column(
        String(32), nullable=True, index=True
    )
    filename: Mapped[str] = mapped_column(String(256))
    source_path: Mapped[str] = mapped_column(String(4096), unique=True, index=True)
    archive_path: Mapped[str | None] = mapped_column(String(4096), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[FileStatus] = mapped_column(
        Enum(
            FileStatus,
            name="filestatus",
            values_callable=lambda x: [e.value for e in x],
        ),
        default=FileStatus.DETECTED,
        index=True,
    )
    in_delivery: Mapped[bool] = mapped_column(Boolean, default=True)
    in_archive: Mapped[bool] = mapped_column(Boolean, default=False)
    group_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("files.id"),
        nullable=True,
        index=True,
    )
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(SmallInteger, default=0)
    last_retry_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    archived_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    cleared_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    # Trailing underscore avoids collision with SQLAlchemy's Base.metadata attribute
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)

    __table_args__ = (
        Index("ix_fc_watch_filename", "watch_name", "filename"),
        Index("ix_fc_status_in_delivery", "status", "in_delivery"),
        Index("ix_fc_status_last_retry_at", "status", "last_retry_at"),
        Index("ix_fc_group_status", "group_id", "status"),
    )


class ServiceState(Base):
    """Single-row table tracking service heartbeat and runtime stats."""

    __tablename__ = "service_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_heartbeat: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    queue_depth: Mapped[int] = mapped_column(Integer, default=0)
    workers_active: Mapped[int] = mapped_column(Integer, default=0)


FILEBASE_COLUMNS = frozenset(
    {
        "id",
        "watch_name",
        "file_type",
        "group_key",
        "complete",
        "archive_path",
        "metadata",
        "created_at",
        "completed_at",
        "modified_at",
        "retention_date",
    }
)


class FileBase(Base):
    """Abstract base for the File model. Plugins subclass this to add domain columns."""

    __abstract__ = True

    @declared_attr.directive
    @classmethod
    def __table_args__(cls) -> tuple:
        return (
            Index(f"ix_{cls.__tablename__}_watch_group", "watch_name", "group_key"),
            Index(
                f"ix_{cls.__tablename__}_complete_completed", "complete", "completed_at"
            ),
            UniqueConstraint(
                "watch_name", "group_key", name=f"uq_{cls.__tablename__}_watch_group"
            ),
        )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    watch_name: Mapped[str] = mapped_column(String(255), index=True)
    file_type: Mapped[str | None] = mapped_column(
        String(255), nullable=True, index=True
    )
    group_key: Mapped[str] = mapped_column(String(256))
    complete: Mapped[bool] = mapped_column(Boolean, default=False)
    archive_path: Mapped[str | None] = mapped_column(String(4096), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    modified_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    retention_date: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    # Raw extract() output, stored alongside the typed domain columns
    # defined by the plugin subclass.
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSON, nullable=True)


_SA_TYPE_TO_PYTHON: dict[type, tuple[type, ...]] = {
    String: (str,),
    Text: (str,),
    Integer: (int,),
    SmallInteger: (int,),
    BigInteger: (int,),
    Boolean: (bool,),
    DateTime: (datetime,),
    JSON: (dict, list, str, int, float, bool, type(None)),
}


def validate_extract_metadata(metadata: dict) -> list[str]:
    """Validate that an extract() dict matches the plugin File model's domain columns.

    Returns a list of error strings (empty if valid).  Checks:
    - Keys in the dict correspond to domain columns on the model.
    - Values have the correct Python type for the column's SA type.
    - None is accepted for nullable columns.
    """
    FileModel = get_file_model()
    table = FileModel.__table__
    col_by_name = {col.name: col for col in table.columns}
    errors: list[str] = []

    for key, value in metadata.items():
        if key not in col_by_name:
            errors.append(
                f"Unknown column {key!r}: not defined on {FileModel.__name__}"
            )
            continue

        col = col_by_name[key]

        if key in FILEBASE_COLUMNS:
            errors.append(
                f"Column {key!r} is a base column and cannot be set by extract()"
            )
            continue

        if value is None:
            if not col.nullable:
                errors.append(f"Column {key!r} is not nullable but got None")
            continue

        expected = _SA_TYPE_TO_PYTHON.get(type(col.type))
        if expected is not None and not isinstance(value, expected):
            errors.append(
                f"Column {key!r}: expected {' | '.join(t.__name__ for t in expected)}, "
                f"got {type(value).__name__} ({value!r})"
            )

    return errors


_FILE_MODEL: type[FileBase] | None = None


def set_file_model(model: type[FileBase]) -> None:
    """Register the plugin's File model as the authoritative one.

    Called by :func:`carbonation.plugin.load_plugin` once a plugin is
    resolved. Queries and reconciliation all look up the model via
    :func:`get_file_model`, so setting it here makes the wiring
    explicit rather than relying on ``FileBase.__subclasses__`` ordering.
    """
    global _FILE_MODEL
    _FILE_MODEL = model


def get_file_model() -> type[FileBase]:
    """Return the plugin-provided File model.

    Returns the model registered by :func:`set_file_model` (the normal
    path when ``load_plugin`` has run). As a fallback — notably for
    tests that import plugin modules directly without going through
    ``load_plugin`` — walks ``FileBase.__subclasses__()`` looking for a
    subclass with ``__tablename__ = "files"``.

    Raises :class:`carbonation.exceptions.PluginError` if neither
    mechanism finds a model.
    """
    from carbonation.exceptions import PluginError

    if _FILE_MODEL is not None:
        return _FILE_MODEL

    for cls in FileBase.__subclasses__():
        if hasattr(cls, "__tablename__") and cls.__tablename__ == "files":
            return cls
    raise PluginError(
        "No File model plugin found. "
        "A plugin must provide a FileBase subclass with __tablename__ = 'files'. "
        "See examples/my_plugin/ for an example."
    )
