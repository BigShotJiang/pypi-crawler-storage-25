"""Initial schema — file_components, files (base columns), service_state.

Revision ID: 001
Revises: None
Create Date: 2026-03-28
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = ("core",)
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- files (base columns only; plugin columns added by create_all) ---
    op.create_table(
        "files",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("watch_name", sa.String(32), nullable=False, index=True),
        sa.Column("file_type", sa.String(255), nullable=True, index=True),
        sa.Column("group_key", sa.String(256), nullable=False),
        sa.Column("complete", sa.Boolean, default=False, nullable=False),
        sa.Column("archive_path", sa.String(4096), nullable=True),
        sa.Column("metadata", sa.JSON, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "modified_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "retention_date", sa.DateTime(timezone=True), nullable=True, index=True
        ),
        sa.Index("ix_files_watch_group", "watch_name", "group_key"),
        sa.Index("ix_files_complete_completed", "complete", "completed_at"),
        sa.UniqueConstraint("watch_name", "group_key", name="uq_files_watch_group"),
    )

    # --- file_components ---
    op.create_table(
        "file_components",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("watch_name", sa.String(32), nullable=True, index=True),
        sa.Column("filename", sa.String(256), nullable=False),
        sa.Column(
            "source_path", sa.String(4096), nullable=False, unique=True, index=True
        ),
        sa.Column("archive_path", sa.String(4096), nullable=True),
        sa.Column("size_bytes", sa.BigInteger, nullable=True),
        sa.Column(
            "status",
            sa.Enum(
                "detected",
                "integrity_failed",
                "waiting",
                "timed_out",
                "not_selected",
                "archived",
                "retry_pending",
                "failed",
                "cleared",
                "missing",
                name="filestatus",
            ),
            default="detected",
            index=True,
        ),
        sa.Column("in_delivery", sa.Boolean, default=True, nullable=False),
        sa.Column("in_archive", sa.Boolean, default=False, nullable=False),
        sa.Column(
            "group_id",
            sa.Integer,
            sa.ForeignKey("files.id"),
            nullable=True,
            index=True,
        ),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("retry_count", sa.SmallInteger, default=0, nullable=False),
        sa.Column("last_retry_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "detected_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("cleared_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata", sa.JSON, nullable=True),
    )
    op.create_index(
        "ix_fc_watch_filename", "file_components", ["watch_name", "filename"]
    )
    op.create_index(
        "ix_fc_status_in_delivery", "file_components", ["status", "in_delivery"]
    )
    op.create_index(
        "ix_fc_status_last_retry_at", "file_components", ["status", "last_retry_at"]
    )
    op.create_index("ix_fc_group_status", "file_components", ["group_id", "status"])
    op.create_index("ix_fc_archive_path", "file_components", ["archive_path"])

    # --- service_state ---
    op.create_table(
        "service_state",
        sa.Column("id", sa.Integer, primary_key=True, default=1),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_heartbeat", sa.DateTime(timezone=True), nullable=True),
        sa.Column("queue_depth", sa.Integer, default=0, nullable=False),
        sa.Column("workers_active", sa.Integer, default=0, nullable=False),
    )


def downgrade() -> None:
    op.drop_table("service_state")
    op.drop_table("file_components")
    op.drop_table("files")
