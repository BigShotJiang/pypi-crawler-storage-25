"""Database engine and session factory for carbonation."""

from __future__ import annotations

import json
import os
from datetime import date, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sqlalchemy import create_engine, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from carbonation.config import DatabaseConfig

if TYPE_CHECKING:
    from carbonation.plugin import Plugin

_MIGRATIONS_DIR = str(Path(__file__).parent / "migrations")
_CORE_VERSIONS_DIR = str(Path(__file__).parent / "migrations" / "versions")


def _json_default(obj: Any) -> Any:
    # JSON columns may receive plugin extract() output containing datetimes.
    # Postgres' JSON type rejects these strictly; SQLite tolerates more but
    # a uniform serializer keeps behavior consistent across backends.
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def json_serializer(value: Any) -> str:
    """SQLAlchemy ``json_serializer`` that tolerates datetime/date objects.

    Exposed so callers that build engines directly (e.g. tests) can opt into
    the same serializer as :func:`create_engine_from_config`.
    """
    return json.dumps(value, default=_json_default)


def create_engine_from_config(config: DatabaseConfig) -> Engine:
    """Create a SQLAlchemy engine from database config.

    ``pool_pre_ping=True`` issues a lightweight liveness check before
    handing out a pooled connection, so long-lived API consumers
    (``CarbonationDB``) survive server-side idle timeouts — most notably
    MariaDB's ``wait_timeout`` (default 8h), which would otherwise surface
    as occasional "MySQL server has gone away" errors on the next query.
    """
    return create_engine(
        config.url,
        echo=config.echo,
        json_serializer=json_serializer,
        pool_pre_ping=True,
    )


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    """Create a session factory bound to the engine."""
    return sessionmaker(bind=engine)


def _build_alembic_config(engine: Engine, plugin: "Plugin | None") -> "Any":
    """Construct a programmatic alembic :class:`Config` for ``engine``.

    Core revisions always contribute. When ``plugin`` ships a
    ``migrations_path``, it's appended to ``version_locations`` so
    carbonation's single alembic env sees both histories as branches.
    """
    from alembic.config import Config

    cfg = Config()
    cfg.set_main_option("script_location", _MIGRATIONS_DIR)
    cfg.set_main_option("path_separator", "os")
    locations = [_CORE_VERSIONS_DIR]
    if plugin is not None and plugin.migrations_path is not None:
        plugin_versions = Path(plugin.migrations_path)
        plugin_versions.mkdir(parents=True, exist_ok=True)
        locations.append(str(plugin_versions))
    cfg.set_main_option("version_locations", os.pathsep.join(locations))
    cfg.attributes["connectable"] = engine
    return cfg


def run_migrations(engine: Engine, plugin: "Plugin | None" = None) -> None:
    """Run Alembic migrations programmatically.

    Upgrades every branch head so the core branch and the plugin branch
    both reach their tips.
    """
    from alembic import command

    cfg = _build_alembic_config(engine, plugin)
    command.upgrade(cfg, "heads")


def init_db(engine: Engine, plugin: "Plugin | None" = None) -> None:
    """Initialise the database by running migrations on all branches."""
    run_migrations(engine, plugin)


def verify_schema(engine: Engine) -> bool:
    """Check that the expected tables exist in the database."""
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())
    required_tables = {"file_components", "files"}
    return required_tables.issubset(existing_tables)


def check_schema_drift(engine: Engine) -> list[str]:
    """Report structural gaps the core migration can identify.

    Plugin-column drift is now the plugin alembic branch's responsibility;
    this check remains as a cheap sanity probe for required tables.
    """
    inspector = inspect(engine)
    drift: list[str] = []

    existing_tables = set(inspector.get_table_names())
    for required in ("files", "file_components", "service_state"):
        if required not in existing_tables:
            drift.append(f"Table '{required}' does not exist. Run: carbonation db init")
    return drift
