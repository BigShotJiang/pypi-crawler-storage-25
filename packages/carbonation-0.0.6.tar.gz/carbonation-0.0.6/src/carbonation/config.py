"""Configuration models and TOML loading for carbonation."""

from __future__ import annotations

import re
import tomllib
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, ClassVar, TYPE_CHECKING

from pydantic import BaseModel, Field, field_validator

from carbonation.exceptions import ConfigError

if TYPE_CHECKING:
    from carbonation.plugin import LoadedPlugin


# Maximum allowed duration: 365 days.  This prevents unreasonable values
# that would overflow timers or timedelta arithmetic while still allowing
# any duration a real deployment would need.
_MAX_DURATION_SECONDS = 365 * 24 * 3600  # 31_536_000


def parse_duration(value: str) -> float:
    """Parse a duration string like '5s', '1m', '24h' into seconds.

    Raises :class:`ConfigError` for invalid formats, zero/negative values,
    or values exceeding 365 days. Zero is rejected because a zero-valued
    ``poll_interval`` / ``retry_delay`` / ``heartbeat_interval`` would
    produce a tight CPU loop rather than a disabled timer.
    """
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(s|m|h|d)", value.strip())
    if not match:
        raise ConfigError(f"Invalid duration: {value!r}. Use e.g. '5s', '1m', '24h'.")
    amount = float(match.group(1))
    unit = match.group(2)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    result = amount * multipliers[unit]
    if result <= 0:
        raise ConfigError(f"Duration must be positive: {value!r}")
    if result > _MAX_DURATION_SECONDS:
        raise ConfigError(f"Duration too large: {value!r} exceeds maximum of 365 days")
    return result


def parse_daterange(value: str) -> tuple[datetime | None, datetime | None]:
    """Parse a daterange string into (start, end) datetimes.

    Formats:
        TIME              → (TIME, TIME) — exact instant
        START/END         → (START, END) — range
        START/            → (START, None) — open end
        /END              → (None, END) — open start

    Datetime values are ISO 8601 (e.g. 2026-01-15 or 2026-01-15T12:00:00).
    """
    if "/" in value:
        left, right = value.split("/", 1)
        start = datetime.fromisoformat(left) if left else None
        end = datetime.fromisoformat(right) if right else None
        return start, end
    # Single value — exact instant
    t = datetime.fromisoformat(value)
    return t, t


class ServiceConfig(BaseModel):
    poll_interval: str = "5s"
    reconcile_interval: str = "24h"
    heartbeat_interval: str = "60s"
    workers: int = 4
    max_retries: int = 3
    retry_delay: str = "30m"
    stale_threshold: str = "1d"
    # How often (in heartbeat ticks) to recompute the ``status`` GROUP BY
    # across ``file_components`` — at 150k+ rows the scan is the heartbeat's
    # hot spot, and stats freshness only needs to be good enough for
    # operator observability. Default: every 10 heartbeats (~10 min at
    # the default heartbeat_interval).
    stats_recompute_every: int = 10

    # Parsed seconds, populated in model_post_init so property reads
    # don't re-run the regex on every access (hot paths: periodic
    # reconcile reads stale_threshold_seconds, retry checker reads
    # retry_delay_seconds).
    _poll_interval_seconds: float = 0.0
    _reconcile_interval_seconds: float = 0.0
    _heartbeat_interval_seconds: float = 0.0
    _retry_delay_seconds: float = 0.0
    _stale_threshold_seconds: float = 0.0

    @field_validator(
        "poll_interval",
        "reconcile_interval",
        "heartbeat_interval",
        "retry_delay",
        "stale_threshold",
    )
    @classmethod
    def validate_duration(cls, v: str) -> str:
        parse_duration(v)  # validate, but store as string
        return v

    def model_post_init(self, __context: Any) -> None:
        self._poll_interval_seconds = parse_duration(self.poll_interval)
        self._reconcile_interval_seconds = parse_duration(self.reconcile_interval)
        self._heartbeat_interval_seconds = parse_duration(self.heartbeat_interval)
        self._retry_delay_seconds = parse_duration(self.retry_delay)
        self._stale_threshold_seconds = parse_duration(self.stale_threshold)

    @property
    def poll_interval_seconds(self) -> float:
        return self._poll_interval_seconds

    @property
    def reconcile_interval_seconds(self) -> float:
        return self._reconcile_interval_seconds

    @property
    def heartbeat_interval_seconds(self) -> float:
        return self._heartbeat_interval_seconds

    @property
    def retry_delay_seconds(self) -> float:
        return self._retry_delay_seconds

    @property
    def stale_threshold_seconds(self) -> float:
        return self._stale_threshold_seconds


_LOGGING_LEVELS = frozenset(
    {"TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"}
)


class LoggingConfig(BaseModel):
    level: str = "INFO"
    file: Path | None = None
    rotation: str = "10 MB"
    retention: str = "30 days"
    format: str = "text"

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        upper = v.upper()
        if upper not in _LOGGING_LEVELS:
            raise ValueError(
                f"level must be one of {sorted(_LOGGING_LEVELS)}, got {v!r}"
            )
        return upper

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        if v not in ("text", "json"):
            raise ValueError(f"format must be 'text' or 'json', got {v!r}")
        return v


class DatabaseConfig(BaseModel):
    drivername: str = "sqlite"
    username: str | None = None
    password: str | None = None
    host: str | None = None
    port: int | None = None
    name: str | None = "carbonation.db"
    echo: bool = False

    @property
    def url(self) -> str:
        from sqlalchemy.engine import URL

        return URL.create(
            drivername=self.drivername,
            username=self.username,
            password=self.password,
            host=self.host,
            port=self.port,
            database=self.name,
        ).render_as_string(hide_password=False)


class PluginsConfig(BaseModel):
    package: str | None = None


class RulesFileConfig(BaseModel):
    file: Path = Path("rules.toml")


class WatchConfig(BaseModel):
    name: str
    type: str | None = None
    path: Path
    recursive: bool = False
    patterns: list[str] | None = None
    ignore_patterns: list[str] = Field(default_factory=lambda: ["*.tmp", ".*"])
    rules: str
    archive: str
    settle_seconds: float = Field(default=2.0, gt=0)


_ALLOWED_DIR_MODES = {0o700, 0o750, 0o755, 0o770, 0o777}
_ALLOWED_FILE_MODES = {0o600, 0o640, 0o644, 0o660, 0o666, 0o440, 0o444}


class ArchiveConfig(BaseModel):
    name: str
    destination: str
    base_path: Path | None = None
    action: str = "copy"
    create_directories: bool = True
    file_mode: int = 0o640
    dir_mode: int = 0o750

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        allowed = {"copy", "move", "hardlink", "symlink"}
        if v not in allowed:
            raise ValueError(f"action must be one of {allowed}, got {v!r}")
        return v

    @field_validator("file_mode", mode="before")
    @classmethod
    def parse_file_mode(cls, v: int | str) -> int:
        if isinstance(v, str):
            v = int(v, 8)
        if v not in _ALLOWED_FILE_MODES:
            allowed = ", ".join(oct(m) for m in sorted(_ALLOWED_FILE_MODES))
            raise ValueError(
                f"file_mode {oct(v)} is not allowed. Choose from: {allowed}"
            )
        return v

    @field_validator("dir_mode", mode="before")
    @classmethod
    def parse_dir_mode(cls, v: int | str) -> int:
        if isinstance(v, str):
            v = int(v, 8)
        if v not in _ALLOWED_DIR_MODES:
            allowed = ", ".join(oct(m) for m in sorted(_ALLOWED_DIR_MODES))
            raise ValueError(
                f"dir_mode {oct(v)} is not allowed. Choose from: {allowed}"
            )
        return v


class AppConfig(BaseModel):
    service: ServiceConfig = Field(default_factory=ServiceConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    plugins: PluginsConfig = Field(default_factory=PluginsConfig)
    rules: RulesFileConfig = Field(default_factory=RulesFileConfig)
    watch: list[WatchConfig]
    archive: list[ArchiveConfig]

    @field_validator("watch")
    @classmethod
    def unique_watch_names(cls, v: list[WatchConfig]) -> list[WatchConfig]:
        names = [w.name for w in v]
        dupes = sorted({n for n in names if names.count(n) > 1})
        if dupes:
            raise ValueError(f"Duplicate watch names: {dupes}")
        return v

    @field_validator("archive")
    @classmethod
    def unique_archive_names(cls, v: list[ArchiveConfig]) -> list[ArchiveConfig]:
        names = [a.name for a in v]
        dupes = sorted({n for n in names if names.count(n) > 1})
        if dupes:
            raise ValueError(f"Duplicate archive names: {dupes}")
        return v


# --- Rules config models ---


class IntegrityCheck(BaseModel):
    type: str
    value: int | float | str | None = None


class CompletenessConfig(BaseModel):
    model_config: ClassVar = {"arbitrary_types_allowed": True}

    group_by: str = "stem"
    expected_extensions: list[str] = Field(default_factory=list)
    primary_extension: str | None = None
    timeout_minutes: int = 120
    on_timeout: str = "warn"
    group_function: str | None = None
    group_function_callable: Callable[..., Any] | None = Field(
        default=None, exclude=True
    )

    @field_validator("group_by")
    @classmethod
    def validate_group_by(cls, v: str) -> str:
        allowed = {"stem", "plugin"}
        if v not in allowed:
            raise ValueError(f"group_by must be one of {allowed}, got {v!r}")
        return v

    @field_validator("on_timeout")
    @classmethod
    def validate_on_timeout(cls, v: str) -> str:
        allowed = {"warn", "skip", "archive_partial"}
        if v not in allowed:
            raise ValueError(f"on_timeout must be one of {allowed}, got {v!r}")
        return v


class MetadataConfig(BaseModel):
    model_config: ClassVar = {"arbitrary_types_allowed": True}

    extract: str | None = None
    extract_callable: Callable[..., dict[str, Any]] | None = Field(
        default=None, exclude=True
    )


class SelectionRule(BaseModel):
    """A single selection rule. Multiple rules are ORed.

    At least one condition must be configured:

    - ``has_keys``: non-empty list of metadata keys that must be present
      and non-None.
    - ``field`` + ``matches``: the metadata field's string value must be
      matched by at least one of the regex patterns. Patterns use
      :func:`re.search` semantics — they match *anywhere* in the value.
      Anchor with ``^``/``$`` (or the entire pattern to be equivalent to
      ``re.fullmatch``) if you want exact equality.
    - ``type = "plugin"`` with ``function``: delegate the decision to a
      plugin-provided callable.

    A rule with no configured condition is rejected at config-load —
    this catches typos like a missing ``type = "plugin"`` that would
    otherwise silently select every file.
    """

    model_config: ClassVar = {"arbitrary_types_allowed": True}

    has_keys: list[str] | None = None
    field: str | None = None
    matches: list[str] | None = None
    compiled_patterns: list[re.Pattern[str]] = Field(default_factory=list, exclude=True)
    type: str | None = None
    function: str | None = None
    function_callable: Callable[..., bool] | None = Field(default=None, exclude=True)
    kwargs: dict[str, Any] = Field(default_factory=dict)

    def model_post_init(self, __context: Any) -> None:
        if self.matches is not None:
            self.compiled_patterns = [re.compile(p) for p in self.matches]

        has_keys_active = bool(self.has_keys)
        field_match_active = self.field is not None and bool(self.matches)
        plugin_active = self.type == "plugin" and self.function is not None
        if not (has_keys_active or field_match_active or plugin_active):
            raise ValueError(
                "selection rule has no condition. Configure one of: "
                "non-empty has_keys, field + matches, or type='plugin' with "
                "function. An empty has_keys=[] is rejected — a rule must "
                "describe what it selects."
            )


class RoutingRule(BaseModel):
    model_config: ClassVar = {"arbitrary_types_allowed": True}

    match: str | None = None
    archive: str | None = None
    type: str | None = None
    function: str | None = None
    function_callable: Callable[..., "str | None"] | None = Field(
        default=None, exclude=True
    )


class RuleSet(BaseModel):
    integrity: list[IntegrityCheck] = Field(default_factory=list)
    completeness: CompletenessConfig | None = None
    metadata: MetadataConfig | None = None
    selection: list[SelectionRule] = Field(default_factory=list)
    routing: list[RoutingRule] = Field(default_factory=list)


class RulesConfig(BaseModel):
    """Top-level rules config. Keys are rule set names."""

    rule_sets: dict[str, RuleSet]


# --- Loading functions ---


def _resolve_path(path: Path, base_dir: Path) -> Path:
    """Resolve a path relative to a base directory if not absolute."""
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _secrets_path() -> Path:
    """Return the platform-appropriate path for secrets.toml.

    Uses ``platformdirs`` so the lookup matches platform conventions:
    ``~/.config/carbonation/secrets.toml`` on Linux,
    ``~/Library/Application Support/carbonation/secrets.toml`` on macOS,
    and ``%APPDATA%\\carbonation\\secrets.toml`` on Windows.
    """
    from platformdirs import user_config_path

    return user_config_path("carbonation") / "secrets.toml"


def _load_secrets(db_data: dict) -> dict:
    """Layer database credentials from user secrets file.

    Values in the secrets file have lower priority than values
    already in db_data (which come from config.toml).
    """
    secrets_path = _secrets_path()
    if secrets_path.is_file():
        with open(secrets_path, "rb") as f:
            secrets = tomllib.load(f)
        db_secrets = secrets.get("database", {})
        for key in ("username", "password", "host", "port", "name", "drivername"):
            if key in db_secrets and key not in db_data:
                db_data[key] = db_secrets[key]
    return db_data


def load_app_config(config_path: Path) -> AppConfig:
    """Load and validate config.toml.

    Credential resolution order (highest priority first):
    1. Values in config.toml
    2. User secrets (~/.config/carbonation/secrets.toml)
    3. Defaults
    """
    config_path = config_path.resolve()
    base_dir = config_path.parent

    with open(config_path, "rb") as f:
        raw = tomllib.load(f)

    # Layer in secrets before validation
    if "database" in raw:
        raw["database"] = _load_secrets(raw["database"])
    else:
        raw["database"] = _load_secrets({})

    config = AppConfig.model_validate(raw)

    # Resolve relative paths against config.toml location
    if config.logging.file is not None:
        config.logging.file = _resolve_path(config.logging.file, base_dir)
    config.rules.file = _resolve_path(config.rules.file, base_dir)
    for w in config.watch:
        w.path = _resolve_path(w.path, base_dir)
    for a in config.archive:
        if a.base_path is not None:
            a.base_path = _resolve_path(a.base_path, base_dir)

    # Resolve SQLite relative database name to absolute path
    if (
        config.database.drivername == "sqlite"
        and config.database.name is not None
        and config.database.name != ":memory:"
        and not Path(config.database.name).is_absolute()
    ):
        config.database.name = str(_resolve_path(Path(config.database.name), base_dir))

    return config


def _parse_rule_set(name: str, raw: dict[str, Any]) -> RuleSet:
    """Parse a single rule set from the flat TOML structure."""
    integrity = raw.get("integrity", [])
    completeness = raw.get("completeness")
    metadata = raw.get("metadata")
    selection = raw.get("selection", [])
    routing = raw.get("routing", [])

    return RuleSet(
        integrity=[IntegrityCheck.model_validate(c) for c in integrity],
        completeness=(
            CompletenessConfig.model_validate(completeness) if completeness else None
        ),
        metadata=(MetadataConfig.model_validate(metadata) if metadata else None),
        selection=[SelectionRule.model_validate(s) for s in selection],
        routing=[RoutingRule.model_validate(r) for r in routing],
    )


def _bind_plugin_callables(
    rule_sets: dict[str, RuleSet], plugin: "LoadedPlugin"
) -> None:
    """Resolve every rule-set reference to a plugin callable and attach it.

    Raises :class:`ConfigError` (via ``resolve_plugin_callable``) when a
    reference names a key that isn't in the plugin's corresponding dict.
    """
    from carbonation.plugin import resolve_plugin_callable

    for rs_name, rs in rule_sets.items():
        if rs.completeness is not None and rs.completeness.group_by == "plugin":
            fn_name = rs.completeness.group_function
            if fn_name is None:
                raise ConfigError(
                    f"rule set {rs_name!r}: group_by = 'plugin' requires "
                    f"completeness.group_function"
                )
            rs.completeness.group_function_callable = resolve_plugin_callable(
                plugin.spec,
                "group",
                fn_name,
                rule_set=rs_name,
                field="completeness.group_function",
            )

        if rs.metadata is not None and rs.metadata.extract is not None:
            rs.metadata.extract_callable = resolve_plugin_callable(
                plugin.spec,
                "extractor",
                rs.metadata.extract,
                rule_set=rs_name,
                field="metadata.extract",
            )

        for i, sel in enumerate(rs.selection):
            if sel.function is None:
                continue
            sel.function_callable = resolve_plugin_callable(
                plugin.spec,
                "selection",
                sel.function,
                rule_set=rs_name,
                field=f"selection[{i}].function",
            )

        for i, route in enumerate(rs.routing):
            if route.function is None:
                continue
            route.function_callable = resolve_plugin_callable(
                plugin.spec,
                "routing",
                route.function,
                rule_set=rs_name,
                field=f"routing[{i}].function",
            )


def load_rules_config(
    rules_path: Path, plugin: "LoadedPlugin | None" = None
) -> RulesConfig:
    """Load and validate rules.toml.

    When ``plugin`` is given, every plugin-callable reference in the
    rules file is resolved against the plugin's dicts and attached to
    the rule model. Passing ``None`` is supported for the subset of
    tooling (e.g. ``carbonation check rules``) that wants to validate
    structure without importing a plugin.
    """
    with open(rules_path, "rb") as f:
        raw = tomllib.load(f)

    rule_sets = {}
    for name, value in raw.items():
        if isinstance(value, dict):
            rule_sets[name] = _parse_rule_set(name, value)

    if plugin is not None:
        _bind_plugin_callables(rule_sets, plugin)

    return RulesConfig(rule_sets=rule_sets)
