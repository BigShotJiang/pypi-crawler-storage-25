"""Carbonation — file delivery monitoring and archival service."""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any

from carbonation.plugin import Plugin

try:
    from carbonation._version import __version__, __version_tuple__  # type: ignore[import-not-found]
except ImportError:
    __version__ = "0.0.0"
    __version_tuple__ = (0, 0, 0)

if TYPE_CHECKING:
    from pathlib import Path

    from sqlalchemy.orm import Session

    from carbonation.api import CarbonationDB

__all__ = [
    "Plugin",
    "__version__",
    "__version_tuple__",
    "connect",
    "main",
    "query_files",
    "session",
]


def main() -> None:
    from carbonation.cli import cli

    cli()


def connect(config_path: str | Path) -> CarbonationDB:
    """Connect to a carbonation database. See :func:`carbonation.api.connect`."""
    from carbonation.api import connect as _connect

    return _connect(config_path)


def session(config_path: str | Path) -> contextlib.AbstractContextManager[Session]:
    """Open an ORM session. See :func:`carbonation.api.session`."""
    from carbonation.api import session as _session

    return _session(config_path)


def query_files(
    config_path: str | Path,
    filters: dict[str, Any] | None = None,
    **kwargs: Any,
) -> list[dict[str, Any]] | int:
    """One-shot query. See :func:`carbonation.api.query_files`."""
    from carbonation.api import query_files as _query_files

    return _query_files(config_path, filters, **kwargs)
