"""Carbonation service orchestrator.

Ties together watcher, rules, archive, reconciliation, and the DB.
"""

from __future__ import annotations

import os
import signal
import threading
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from queue import Empty, Queue

import sdnotify
from loguru import logger
from sqlalchemy import update
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from carbonation.archive import archive_file, resolve_destination
from carbonation.config import (
    AppConfig,
    ArchiveConfig,
    CompletenessConfig,
    RuleSet,
    RulesConfig,
    WatchConfig,
    load_rules_config,
)
from carbonation.db.models import FileComponent, FileStatus, validate_extract_metadata
from carbonation.db.queries import (
    assign_component_to_group,
    find_or_create_file_group,
    get_component_by_source_path,
    get_group_components,
    claim_retry_pending,
    get_not_selected_in_delivery,
    get_status_counts,
    get_timed_out_groups,
    mark_group_complete,
    record_component,
    update_component_status,
    update_file_metadata,
    update_heartbeat,
)
from carbonation.plugin import LoadedPlugin
from carbonation.reconcile import reconcile_delivery
from carbonation.rules import (
    check_completeness,
    check_integrity,
    evaluate_selection,
    resolve_group_key,
    resolve_routing,
)
from carbonation.watcher import FileArrivalHandler, FileEvent, create_observers


@dataclass
class _RefCountedLock:
    """A :class:`threading.Lock` with a usage counter.

    The counter is incremented by :meth:`CarbonationService._group_lock`
    on entry and decremented on exit; the entry is removed from the
    service's lock map when the count reaches zero.
    """

    lock: threading.Lock = field(default_factory=threading.Lock)
    refs: int = 0


@dataclass
class _PipelineContext:
    """Mutable state threaded through the per-event pipeline stages.

    Populated progressively: ``_stage_record`` sets ``component_id`` and
    ``size_bytes``; ``_stage_completeness`` fills the group fields;
    ``_stage_extract`` fills ``metadata``; ``_stage_select_and_route``
    fills ``archive_config`` and ``dest_dir``.
    """

    event: FileEvent
    path: Path
    watch_config: WatchConfig
    rule_set: RuleSet
    component_id: int = 0
    size_bytes: int | None = None
    group_id: int | None = None
    group_key: str | None = None
    component_ids: list[int] = field(default_factory=list)
    component_paths: list[Path] = field(default_factory=list)
    group_components: list[dict] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    archive_config: ArchiveConfig | None = None
    dest_dir: Path | None = None

    @property
    def display_name(self) -> str:
        return self.group_key or self.path.name


class _RulesFileHandler(FileSystemEventHandler):
    """Watches rules.toml for changes and triggers a debounced reload.

    Listens to ``on_modified``, ``on_created``, and ``on_moved`` so that
    atomic-replace edits (vim with backup, IDE save-to-temp-then-rename,
    ``mv newfile rules.toml``) are picked up — those emit moved/created,
    not modified, and a modified-only handler would silently miss them.
    """

    def __init__(self, rules_path: Path, callback: Callable[[], None]) -> None:
        super().__init__()
        self._rules_path = rules_path.resolve()
        self._callback = callback
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()

    def _is_target(self, src_path: str) -> bool:
        try:
            return Path(src_path).resolve() == self._rules_path
        except OSError:
            return False

    def _schedule_reload(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(0.5, self._callback)
            self._timer.daemon = True
            self._timer.start()

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        if not self._is_target(str(event.src_path)):
            return
        self._schedule_reload()

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        if not self._is_target(str(event.src_path)):
            return
        self._schedule_reload()

    def on_moved(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        # The destination is what's now living at the watched path.
        dest_path = getattr(event, "dest_path", None)
        if dest_path and self._is_target(str(dest_path)):
            self._schedule_reload()

    def cancel(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()


class CarbonationService:
    """Main service that orchestrates file monitoring, rules, and archiving."""

    def __init__(
        self,
        app_config: AppConfig,
        rules_config: RulesConfig,
        plugin: LoadedPlugin,
        engine: Engine,
        session_factory: sessionmaker[Session],
    ) -> None:
        self.app_config = app_config
        self.rules_config = rules_config
        self.plugin = plugin
        self.engine = engine
        self.session_factory = session_factory

        self.event_queue: Queue[FileEvent] = Queue()
        self._shutdown = threading.Event()
        self._rules_lock = threading.Lock()
        # Heartbeat status-counts cache: the GROUP BY over file_components
        # is the heartbeat's dominant cost at scale. Recompute only every
        # ``service.stats_recompute_every`` ticks; serve cached counts in
        # between so the minute-granularity heartbeat doesn't full-scan
        # the table.
        self._stats_tick: int = 0
        self._cached_status_counts: dict[str, int] = {}
        # Per-group-key locks are refcounted rather than held via
        # WeakValueDictionary: a WVD entry could be garbage-collected
        # between two workers asking for the same key, which would defeat
        # the mutual-exclusion guarantee on completeness checks.
        self._group_locks: dict[str, _RefCountedLock] = {}
        self._group_locks_lock = threading.Lock()
        self._observers: list[Observer] = []  # pyright: ignore[reportInvalidTypeForm]
        self._handlers: list[FileArrivalHandler] = []
        self._executor: ThreadPoolExecutor | None = None
        self._reconcile_timer: threading.Timer | None = None
        self._heartbeat_timer: threading.Timer | None = None
        self._rules_observer: Observer | None = None  # pyright: ignore[reportInvalidTypeForm]
        self._rules_handler: _RulesFileHandler | None = None
        self._notifier = sdnotify.SystemdNotifier()

        # Build lookup maps
        self._archive_by_name: dict[str, ArchiveConfig] = {
            a.name: a for a in app_config.archive
        }
        self._watch_by_name: dict[str, WatchConfig] = {
            w.name: w for w in app_config.watch
        }

    def run_once(self) -> int:
        """Run a single processing pass and exit.

        Reconciles delivery directories, checks timeouts and retries,
        processes all enqueued events, and exits.  Suitable for cron.

        Returns:
            0 if the pass completed successfully, 1 if carbonation
            itself encountered an error.
        """
        logger.info("Carbonation run-once starting...")

        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                started_at=datetime.now(timezone.utc),
                queue_depth=self.event_queue.qsize(),
            )
            session.commit()
        finally:
            session.close()

        # Reconcile delivery directories
        stale_threshold = timedelta(
            seconds=self.app_config.service.stale_threshold_seconds
        )
        try:
            for wc in self.app_config.watch:
                session = self.session_factory()
                try:
                    stats = reconcile_delivery(
                        session,
                        wc,
                        event_queue=self.event_queue,
                        stale_threshold=stale_threshold,
                    )
                    logger.info(
                        f"Delivery reconcile [{wc.name}]: "
                        f"{stats['new']} new, {stats['cleared']} cleared, "
                        f"{stats['requeued']} requeued"
                    )
                finally:
                    session.close()

            # Check completeness timeouts and pending retries
            self._check_completeness_timeouts()
            self._check_pending_retries()

            # Drain the event queue with workers
            workers = self.app_config.service.workers
            executor = ThreadPoolExecutor(max_workers=workers)
            futures = []
            while not self.event_queue.empty():
                try:
                    event = self.event_queue.get_nowait()
                except Empty:
                    break
                futures.append(executor.submit(self._process_event, event))
            executor.shutdown(wait=True)

            # Update heartbeat
            self._update_heartbeat_and_stats()

            logger.info("Carbonation run-once complete.")
            return 0
        except Exception:
            logger.exception("Carbonation run-once failed")
            return 1

    def start(self, dry_run: bool = False) -> None:
        """Start the service."""
        logger.info("Carbonation service starting...")

        # Record service start in DB
        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                started_at=datetime.now(timezone.utc),
                queue_depth=self.event_queue.qsize(),
            )
            session.commit()
        finally:
            session.close()

        # Reconcile delivery directories
        stale_threshold = timedelta(
            seconds=self.app_config.service.stale_threshold_seconds
        )
        for wc in self.app_config.watch:
            session = self.session_factory()
            try:
                stats = reconcile_delivery(
                    session,
                    wc,
                    event_queue=self.event_queue if not dry_run else None,
                    stale_threshold=stale_threshold,
                )
                logger.info(
                    f"Delivery reconcile [{wc.name}]: "
                    f"{stats['new']} new, {stats['cleared']} cleared, "
                    f"{stats['requeued']} requeued"
                )
            finally:
                session.close()

        if dry_run:
            logger.info("Dry run complete — exiting without starting watchers")
            return

        # Start watchdog observers
        obs_handlers = create_observers(self.app_config.watch, self.event_queue)
        for observer, handler in obs_handlers:
            observer.start()
            self._observers.append(observer)
            self._handlers.append(handler)

        # Watch rules.toml for hot-reload
        self._start_rules_watcher()

        # Start worker thread pool
        workers = self.app_config.service.workers
        self._executor = ThreadPoolExecutor(max_workers=workers)
        logger.info(f"Started {workers} worker threads")

        # Schedule periodic reconciliation and heartbeat
        self._schedule_reconciliation()
        self._schedule_heartbeat()

        # Install signal handlers (only works in main thread)
        try:
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
        except ValueError:
            pass  # not in main thread — caller is responsible for shutdown

        logger.info("Carbonation service running. Press Ctrl+C to stop.")
        self._notifier.notify("READY=1")
        self._notifier.notify("STATUS=Running")

        # Main loop: dispatch events to worker pool
        try:
            while not self._shutdown.is_set():
                try:
                    event = self.event_queue.get(timeout=1.0)
                except Empty:
                    continue
                self._executor.submit(self._process_event, event)
        finally:
            self.stop()

    def stop(self) -> None:
        """Gracefully shut down the service."""
        if self._shutdown.is_set():
            return
        self._shutdown.set()
        self._notifier.notify("STOPPING=1")
        self._notifier.notify("STATUS=Shutting down")
        logger.info("Shutting down...")

        # Cancel timers
        if self._reconcile_timer is not None:
            self._reconcile_timer.cancel()
        if self._heartbeat_timer is not None:
            self._heartbeat_timer.cancel()

        # Stop rules watcher
        if self._rules_handler is not None:
            self._rules_handler.cancel()
        if self._rules_observer is not None:
            self._rules_observer.stop()
            self._rules_observer.join(timeout=5)

        # Stop delivery watchdog observers
        for handler in self._handlers:
            handler.cancel_all()
        for observer in self._observers:
            observer.stop()
        for observer in self._observers:
            observer.join(timeout=5)

        # Shut down worker pool
        if self._executor is not None:
            self._executor.shutdown(wait=True, cancel_futures=False)

        logger.info("Carbonation service stopped.")

    def _signal_handler(self, signum: int, frame: object) -> None:
        logger.info(f"Received signal {signum}")
        self._shutdown.set()

    def _start_rules_watcher(self) -> None:
        """Watch rules.toml for changes and hot-reload on modification."""
        rules_path = self.app_config.rules.file
        if not rules_path.is_file():
            logger.warning(f"Rules file not found, skipping hot-reload: {rules_path}")
            return

        self._rules_handler = _RulesFileHandler(rules_path, self._reload_rules)
        observer = Observer()
        observer.schedule(
            self._rules_handler,
            str(rules_path.parent),
            recursive=False,
        )
        observer.start()
        self._rules_observer = observer
        logger.info(f"Watching rules file for changes: {rules_path}")

    def _reload_rules(self) -> None:
        """Attempt to reload and validate rules.toml, swapping on success."""
        if self._shutdown.is_set():
            return
        rules_path = self.app_config.rules.file
        try:
            new_rules = load_rules_config(rules_path, self.plugin)
        except Exception:
            logger.exception("Rules reload failed — keeping current rules")
            return

        # Validate that all watch configs still reference valid rule sets
        for wc in self.app_config.watch:
            if wc.rules not in new_rules.rule_sets:
                logger.error(
                    f"Rules reload rejected: watch '{wc.name}' references "
                    f"rule set '{wc.rules}' which is missing from the new rules file"
                )
                return

        with self._rules_lock:
            self.rules_config = new_rules
        logger.info(f"Rules reloaded successfully from {rules_path}")

        # Re-enqueue NOT_SELECTED components for re-evaluation against new rules.
        # Only enqueue one representative component per group (primary extension
        # or first component) — the pipeline re-fetches all group components.
        self._reenqueue_not_selected()

    def _reenqueue_not_selected(self) -> None:
        """Re-enqueue one component per NOT_SELECTED group for re-evaluation."""
        rules = self._snapshot_rules()
        session = self.session_factory()
        try:
            components = get_not_selected_in_delivery(session)
        finally:
            session.close()

        if not components:
            return

        # Group by group_id (None for standalone files)
        groups: dict[int | None, list[dict]] = {}
        for comp in components:
            groups.setdefault(comp["group_id"], []).append(comp)

        enqueued = 0
        for group_id, group_comps in groups.items():
            # Pick the primary extension component if configured, else first
            chosen = group_comps[0]
            watch_name = chosen["watch_name"]
            wc = self._watch_by_name.get(watch_name)
            if wc is not None:
                rs = rules.rule_sets.get(wc.rules)
                if rs and rs.completeness and rs.completeness.primary_extension:
                    primary_ext = rs.completeness.primary_extension
                    for comp in group_comps:
                        if Path(comp["source_path"]).suffix == primary_ext:
                            chosen = comp
                            break

            self.event_queue.put(
                FileEvent(
                    watch_name=chosen["watch_name"],
                    path=Path(chosen["source_path"]),
                )
            )
            enqueued += 1

        logger.info(
            f"Rules changed: re-enqueued {enqueued} NOT_SELECTED group(s) for re-evaluation"
        )

    def _schedule_reconciliation(self) -> None:
        """Schedule the next periodic reconciliation."""
        interval = self.app_config.service.reconcile_interval_seconds
        self._reconcile_timer = threading.Timer(interval, self._periodic_reconcile)
        self._reconcile_timer.daemon = True
        self._reconcile_timer.start()

    def _schedule_heartbeat(self) -> None:
        """Schedule the next heartbeat."""
        interval = self.app_config.service.heartbeat_interval_seconds
        self._heartbeat_timer = threading.Timer(interval, self._periodic_heartbeat)
        self._heartbeat_timer.daemon = True
        self._heartbeat_timer.start()

    def _periodic_heartbeat(self) -> None:
        """Update heartbeat in DB, ping systemd watchdog, and reschedule."""
        if self._shutdown.is_set():
            return
        self._update_heartbeat_and_stats()
        if not self._shutdown.is_set():
            self._schedule_heartbeat()

    def _periodic_reconcile(self) -> None:
        """Run periodic reconciliation, timeout checks, and reschedule.

        Each step is wrapped in its own try/except and the rescheduling
        runs in a finally block so one transient failure (DB blip, bad
        rules state) cannot kill the periodic timer for the rest of the
        process's lifetime.
        """
        if self._shutdown.is_set():
            return
        try:
            logger.info("Running periodic delivery reconciliation")
            for wc in self.app_config.watch:
                session = self.session_factory()
                try:
                    reconcile_delivery(
                        session,
                        wc,
                        event_queue=self.event_queue,
                        stale_threshold=timedelta(
                            seconds=self.app_config.service.stale_threshold_seconds
                        ),
                    )
                except Exception:
                    logger.exception(f"Reconciliation failed for [{wc.name}]")
                finally:
                    session.close()

            try:
                self._check_completeness_timeouts()
            except Exception:
                logger.exception("Completeness timeout check failed")

            try:
                self._check_pending_retries()
            except Exception:
                logger.exception("Pending retry check failed")

            try:
                self._check_watch_health()
            except Exception:
                logger.exception("Watch health check failed")
        finally:
            if not self._shutdown.is_set():
                self._schedule_reconciliation()

    def _check_completeness_timeouts(self) -> None:
        """Check for incomplete groups that have exceeded their timeout.

        Serialized against the pipeline worker via the per-group lock:
        for each candidate group we acquire ``_group_lock(group_key)``
        so that if a worker is currently in post-integrity stages
        (extract, archive, finalize) for the same key, we wait for it
        to finish and release the lock before making the timeout
        decision. Once we have the lock, a fresh session re-reads the
        group's ``complete`` flag so we see any commits the worker
        made — the initial scan's session may be pinned to an older
        snapshot under MariaDB REPEATABLE READ.
        """
        rules = self._snapshot_rules()
        for wc in self.app_config.watch:
            rule_set = rules.rule_sets.get(wc.rules)
            if rule_set is None or rule_set.completeness is None:
                continue
            completeness = rule_set.completeness
            if completeness.timeout_minutes <= 0:
                continue

            cutoff = datetime.now(timezone.utc) - timedelta(
                minutes=completeness.timeout_minutes
            )

            # Initial scan in its own short-lived session so we don't
            # sit on a transaction snapshot while we process each
            # candidate below.
            scan_session = self.session_factory()
            try:
                timed_out = get_timed_out_groups(scan_session, wc.name, cutoff)
            except Exception:
                logger.exception(f"Completeness timeout scan failed for [{wc.name}]")
                scan_session.close()
                continue
            scan_session.close()

            for group in timed_out:
                self._handle_timed_out_group(
                    wc.name,
                    group_id=group["id"],
                    group_key=group["group_key"],
                    action=completeness.on_timeout,
                )

    def _handle_timed_out_group(
        self,
        watch_name: str,
        *,
        group_id: int,
        group_key: str,
        action: str,
    ) -> None:
        """Acquire the group lock, re-verify incomplete, then act.

        Each candidate gets its own session so a fresh snapshot reads
        the post-worker state correctly across dialects.
        """
        with self._group_lock(group_key) as group_lock, group_lock:
            session = self.session_factory()
            try:
                if self._group_is_complete(session, group_id):
                    logger.debug(
                        f"Group '{group_key}' in [{watch_name}] completed "
                        f"while timeout check was waiting — skipping"
                    )
                    return

                if action == "warn":
                    logger.warning(f"Group '{group_key}' in [{watch_name}] timed out")
                elif action == "skip":
                    components = get_group_components(session, group_id)
                    for comp in components:
                        update_component_status(
                            session, comp["id"], FileStatus.TIMED_OUT
                        )
                    mark_group_complete(session, group_id)
                    logger.info(f"Group '{group_key}' in [{watch_name}] timed out")
                elif action == "archive_partial":
                    mark_group_complete(session, group_id)
                    components = get_group_components(session, group_id)
                    component_paths = [Path(c["source_path"]) for c in components]
                    # Re-enqueue components for archival. The next
                    # worker picking up these events will acquire the
                    # same group_lock we're about to release — so it
                    # sees the mark_group_complete we just wrote.
                    for comp_path in component_paths:
                        self.event_queue.put(
                            FileEvent(
                                watch_name=watch_name,
                                path=comp_path,
                            )
                        )
                    logger.info(
                        f"Group '{group_key}' in [{watch_name}] timed out — "
                        f"archiving {len(components)} partial component(s)"
                    )

                session.commit()
            except Exception:
                session.rollback()
                logger.exception(
                    f"Completeness timeout action failed for "
                    f"'{group_key}' in [{watch_name}]"
                )
            finally:
                session.close()

    def _group_is_complete(self, session: Session, group_id: int) -> bool:
        """Return True if the group row is currently ``complete=True``."""
        from carbonation.db.models import get_file_model
        from sqlalchemy import select

        FileModel = get_file_model()
        t = FileModel.__table__
        result = session.execute(
            select(t.c.complete).where(t.c.id == group_id)
        ).scalar()
        return bool(result)

    def _check_pending_retries(self) -> None:
        """Re-enqueue components that are due for retry."""
        retry_delay = self.app_config.service.retry_delay_seconds
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=retry_delay)

        session = self.session_factory()
        try:
            # Atomic claim: SELECT + UPDATE-with-recheck in one transaction.
            # Avoids the read-then-update race where a concurrent manual
            # retry could land between SELECT and UPDATE and double-enqueue
            # or get its retry_count bumped by the periodic checker.
            pending = claim_retry_pending(session, cutoff)
            for comp in pending:
                self.event_queue.put(
                    FileEvent(
                        watch_name=comp["watch_name"],
                        path=Path(comp["source_path"]),
                    )
                )
            if pending:
                session.commit()
                logger.info(f"Re-enqueued {len(pending)} component(s) for retry")
        except Exception:
            session.rollback()
            logger.exception("Retry check failed")
        finally:
            session.close()

    def _check_watch_health(self) -> None:
        """Verify each watch directory is accessible."""
        for wc in self.app_config.watch:
            if not wc.path.is_dir():
                logger.warning(f"Watch directory missing: {wc.path} [{wc.name}]")
            elif not os.access(wc.path, os.R_OK):
                logger.warning(f"Watch directory not readable: {wc.path} [{wc.name}]")

    def _update_heartbeat_and_stats(self) -> None:
        """Update heartbeat in DB and log a stats summary.

        ``get_status_counts`` is recomputed only every
        ``service.stats_recompute_every`` ticks; the most recent result is
        served from cache in between. The first tick always computes so
        early heartbeats aren't empty.
        """
        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                queue_depth=self.event_queue.qsize(),
            )

            recompute_every = max(1, self.app_config.service.stats_recompute_every)
            if self._stats_tick % recompute_every == 0:
                self._cached_status_counts = get_status_counts(session)
            self._stats_tick += 1

            session.commit()

            counts = self._cached_status_counts
            parts = [f"{k}={v}" for k, v in sorted(counts.items())]
            logger.info(
                f"Stats: {', '.join(parts)}, queue_depth={self.event_queue.qsize()}"
            )
            self._notifier.notify("WATCHDOG=1")
            self._notifier.notify(
                f"STATUS=queue_depth={self.event_queue.qsize()}, " + ", ".join(parts)
            )
        except Exception:
            session.rollback()
            logger.exception("Heartbeat/stats update failed")
        finally:
            session.close()

    def _snapshot_rules(self) -> RulesConfig:
        """Return a consistent snapshot of the current rules config."""
        with self._rules_lock:
            return self.rules_config

    @contextmanager
    def _group_lock(self, group_key: str) -> Iterator[threading.Lock]:
        """Yield a shared :class:`threading.Lock` for ``group_key``.

        The lock is refcounted: the same ``Lock`` instance is returned to
        every caller holding this context manager open, and the map entry
        is removed only once the last caller exits. This guarantees
        serialization on the same key across concurrent workers without
        relying on GC timing.
        """
        with self._group_locks_lock:
            entry = self._group_locks.get(group_key)
            if entry is None:
                entry = _RefCountedLock()
                self._group_locks[group_key] = entry
            entry.refs += 1
            lock = entry.lock
        try:
            yield lock
        finally:
            with self._group_locks_lock:
                entry = self._group_locks[group_key]
                entry.refs -= 1
                if entry.refs == 0:
                    del self._group_locks[group_key]

    def _process_event(self, event: FileEvent) -> None:
        """Process a single file event through the full pipeline."""
        session = self.session_factory()
        try:
            self._process_event_inner(session, event)
            session.commit()
        except Exception:
            session.rollback()
            logger.exception(f"Error processing {event.path}")
        finally:
            session.close()

    def _process_event_inner(self, session: Session, event: FileEvent) -> None:
        """Dispatch a single event through the pipeline stages.

        Each ``_stage_*`` helper either mutates ``ctx`` and returns True
        to continue, or writes a terminal status and returns False. The
        orchestration lives here; stage-specific logic lives in each
        helper so they can be unit-tested and reasoned about in isolation.

        For grouped events, the per-group lock is held across the entire
        post-integrity pipeline (completeness → extract → archive →
        finalize). This serializes concurrent workers for the same
        ``group_key`` and — more importantly — gives the completeness
        timeout checker in :meth:`_check_completeness_timeouts` a
        synchronization point: it acquires the same lock before making
        its timeout decision, so it never stomps on a worker that's
        mid-archive.
        """
        ctx = self._pipeline_setup(event)
        if ctx is None:
            return
        if not self._stage_record(session, ctx):
            return
        if not self._stage_integrity(session, ctx):
            return

        completeness = ctx.rule_set.completeness
        group_key = resolve_group_key(ctx.path, completeness) if completeness else None
        if group_key is not None and completeness is not None:
            ctx.group_key = group_key
            with self._group_lock(group_key) as group_lock, group_lock:
                self._run_grouped_pipeline(session, ctx, completeness)
        else:
            # Standalone file — no group, no lock, no timeout race.
            ctx.component_paths = [ctx.path]
            ctx.component_ids = [ctx.component_id]
            self._run_post_group_pipeline(session, ctx)

    def _run_grouped_pipeline(
        self,
        session: Session,
        ctx: _PipelineContext,
        completeness: CompletenessConfig,
    ) -> None:
        """Run completeness → … → finalize. Caller holds the group lock."""
        if not self._stage_completeness_locked(session, ctx, completeness):
            return
        self._run_post_group_pipeline(session, ctx)

    def _run_post_group_pipeline(self, session: Session, ctx: _PipelineContext) -> None:
        """Run extract → select/route → archive/finalize."""
        if not self._stage_extract(session, ctx):
            return
        if not self._stage_select_and_route(session, ctx):
            return
        self._stage_archive_and_finalize(session, ctx)

    def _pipeline_setup(self, event: FileEvent) -> _PipelineContext | None:
        """Resolve the watch+rule_set for an event. None means drop the event."""
        watch_config = self._watch_by_name.get(event.watch_name)
        if watch_config is None:
            logger.error(f"Unknown watch: {event.watch_name}")
            return None

        rules = self._snapshot_rules()
        rule_set = rules.rule_sets.get(watch_config.rules)
        if rule_set is None:
            logger.error(f"Unknown rule set: {watch_config.rules}")
            return None

        return _PipelineContext(
            event=event,
            path=event.path,
            watch_config=watch_config,
            rule_set=rule_set,
        )

    def _stage_record(self, session: Session, ctx: _PipelineContext) -> bool:
        """Insert the component row, or re-use an existing one.

        IntegrityError on insert means the row already exists (another
        watchdog event, a reconcile-discovered row, or a prior archive
        cycle). Existing ARCHIVED/FAILED rows are terminal and cause the
        pipeline to stop. A MISSING row — archived once, then lost from
        disk — is flipped back to ``in_delivery`` so the pipeline
        re-archives it; on success, its status becomes ARCHIVED again.
        """
        path = ctx.path
        source_path = str(path.resolve())

        try:
            ctx.size_bytes = path.stat().st_size
        except OSError:
            ctx.size_bytes = None

        try:
            ctx.component_id = record_component(
                session,
                watch_name=ctx.event.watch_name,
                filename=path.name,
                source_path=source_path,
                size_bytes=ctx.size_bytes,
            )
            return True
        except IntegrityError:
            session.rollback()

        existing = get_component_by_source_path(session, source_path)
        if existing is None:
            logger.error(f"Insert conflict but no existing record: {path.name}")
            return False

        ctx.component_id = existing["id"]
        existing_status = existing["status"]

        if existing_status in (FileStatus.ARCHIVED, FileStatus.FAILED):
            return False

        if existing_status == FileStatus.MISSING:
            # Recovered on the delivery side — pipeline will re-archive.
            # Flip in_delivery=True and clear in_archive (the file isn't
            # there anymore, which is why it was MISSING); the archive
            # stage will set in_archive=True again on success.
            logger.info(f"Re-delivery of MISSING file {path.name}: re-running pipeline")
            session.execute(
                update(FileComponent)
                .where(FileComponent.id == ctx.component_id)
                .values(
                    in_delivery=True,
                    in_archive=False,
                    status=FileStatus.DETECTED,
                    error_message=None,
                )
            )
        return True

    def _stage_integrity(self, session: Session, ctx: _PipelineContext) -> bool:
        passed, error = check_integrity(ctx.path, ctx.rule_set.integrity)
        if not passed:
            update_component_status(
                session,
                ctx.component_id,
                FileStatus.INTEGRITY_FAILED,
                error_message=error,
            )
            logger.debug(f"Integrity failed: {ctx.path.name}: {error}")
            return False
        return True

    def _stage_completeness_locked(
        self,
        session: Session,
        ctx: _PipelineContext,
        completeness: CompletenessConfig,
    ) -> bool:
        """Populate the group state on ``ctx``. False if still incomplete.

        **Must be called with ``_group_lock(ctx.group_key)`` held** — the
        caller in :meth:`_process_event_inner` acquires it. Keeping the
        lock outside this method lets the lock span the full
        post-integrity pipeline (extract → archive → finalize), which is
        what blocks the timeout checker from racing a mid-archive worker.
        """
        assert ctx.group_key is not None
        group_id = find_or_create_file_group(
            session,
            watch_name=ctx.event.watch_name,
            file_type=ctx.watch_config.type,
            group_key=ctx.group_key,
        )
        assign_component_to_group(session, ctx.component_id, group_id)
        update_component_status(session, ctx.component_id, FileStatus.WAITING)

        group_components = get_group_components(session, group_id)
        component_paths = [Path(c["source_path"]) for c in group_components]

        is_complete = check_completeness(
            ctx.group_key,
            ctx.event.watch_name,
            completeness.expected_extensions,
            component_paths,
        )

        # Commit so that (a) the next worker acquiring this group lock
        # sees this component in its completeness query under Postgres
        # READ COMMITTED, and (b) the timeout checker — which reads
        # ``complete`` in a fresh session under the same lock — sees
        # any mark_group_complete we eventually write. We do NOT mark
        # the group complete here: that happens only after extract +
        # archive succeed, so an extract failure leaves the group
        # recoverable on retry.
        session.commit()

        if not is_complete:
            logger.debug(
                f"Group '{ctx.group_key}' incomplete "
                f"({len(component_paths)}/{len(completeness.expected_extensions)})"
            )
            return False

        ctx.group_id = group_id
        ctx.group_components = group_components
        ctx.component_paths = component_paths
        ctx.component_ids = [c["id"] for c in group_components]
        return True

    def _stage_extract(self, session: Session, ctx: _PipelineContext) -> bool:
        """Run the plugin extractor. Marks retry/failed on hard failure."""
        metadata_cfg = ctx.rule_set.metadata
        if metadata_cfg is None or metadata_cfg.extract_callable is None:
            return True

        try:
            metadata = metadata_cfg.extract_callable(ctx.component_paths)
            validation_errors = validate_extract_metadata(metadata)
            if validation_errors:
                for err in validation_errors:
                    logger.error(f"extract() validation [{ctx.display_name}]: {err}")
                raise ValueError(
                    f"extract() returned invalid metadata: "
                    f"{'; '.join(validation_errors)}"
                )
            ctx.metadata = metadata
            if ctx.group_id is not None:
                update_file_metadata(
                    session,
                    ctx.group_id,
                    metadata,
                    raw_metadata=metadata,
                )
            return True
        except Exception as e:
            # Hard failure — do NOT proceed to archive with empty
            # metadata, and do NOT mark the group complete. Mark
            # components RETRY_PENDING (or FAILED on exhaustion) so the
            # retry path can re-attempt extract on the next pass.
            logger.exception(
                f"Metadata extraction failed for group '{ctx.display_name}'"
            )
            self._mark_components_retry_or_failed(
                session, ctx, error_prefix="extract failed", exception=e
            )
            return False

    def _mark_components_retry_or_failed(
        self,
        session: Session,
        ctx: _PipelineContext,
        *,
        error_prefix: str,
        exception: Exception,
    ) -> None:
        """Transition each component to RETRY_PENDING or FAILED.

        Respects per-component ``retry_count`` vs.
        ``service.max_retries``. Used from the extract-failure path
        (whole-group failure); per-component archive failures have
        their own handling in ``_stage_archive_and_finalize`` because
        they need to map errors back to individual component paths.
        """
        max_retries = self.app_config.service.max_retries
        for cid in ctx.component_ids:
            comp_path = next(
                (
                    Path(c["source_path"])
                    for c in ctx.group_components
                    if c["id"] == cid
                ),
                ctx.path,
            )
            comp_record = get_component_by_source_path(
                session, str(comp_path.resolve())
            )
            if comp_record is None:
                continue
            target_status = (
                FileStatus.RETRY_PENDING
                if comp_record["retry_count"] < max_retries
                else FileStatus.FAILED
            )
            update_component_status(
                session,
                cid,
                target_status,
                error_message=f"{error_prefix}: {exception}",
            )

    def _stage_select_and_route(self, session: Session, ctx: _PipelineContext) -> bool:
        """Evaluate selection rules, then resolve routing + destination."""
        selected = evaluate_selection(ctx.metadata, ctx.rule_set.selection)
        if not selected:
            for cid in ctx.component_ids:
                update_component_status(session, cid, FileStatus.NOT_SELECTED)
            logger.debug(f"Group '{ctx.display_name}' not selected by rules")
            return False

        routing_filename = ctx.group_key or ctx.path.name
        archive_name = resolve_routing(
            ctx.metadata,
            routing_filename,
            ctx.rule_set.routing,
            ctx.watch_config.archive,
        )
        archive_config = self._archive_by_name.get(archive_name)
        if archive_config is None:
            for cid in ctx.component_ids:
                update_component_status(
                    session,
                    cid,
                    FileStatus.FAILED,
                    error_message=f"Archive not found: {archive_name}",
                )
            return False

        ctx.archive_config = archive_config
        ctx.dest_dir = resolve_destination(
            archive_config.destination,
            ctx.metadata,
            archive_config.base_path,
        )
        return True

    def _stage_archive_and_finalize(
        self, session: Session, ctx: _PipelineContext
    ) -> None:
        """Archive each component and mark the group complete on success."""
        assert ctx.archive_config is not None and ctx.dest_dir is not None
        archive_config = ctx.archive_config
        dest_dir = ctx.dest_dir

        completeness = ctx.rule_set.completeness
        primary_ext = (
            completeness.primary_extension
            if completeness is not None and completeness.primary_extension
            else None
        )
        primary_archive_path: str | None = None
        any_retry_pending = False

        for cid in ctx.component_ids:
            comp = (
                next((c for c in ctx.group_components if c["id"] == cid), None)
                if ctx.group_key
                else None
            )
            comp_path = Path(comp["source_path"]) if comp else ctx.path
            comp_size = comp["size_bytes"] if comp else ctx.size_bytes

            try:
                archived = archive_file(
                    comp_path,
                    dest_dir,
                    archive_config.action,
                    archive_config.create_directories,
                    file_mode=archive_config.file_mode,
                    dir_mode=archive_config.dir_mode,
                    expected_size=comp_size,
                )
                update_component_status(
                    session,
                    cid,
                    FileStatus.ARCHIVED,
                    archive_path=str(archived),
                )
                if primary_ext is not None and comp_path.suffix == primary_ext:
                    primary_archive_path = str(archived)
                elif primary_archive_path is None:
                    primary_archive_path = str(archived)
            except Exception as e:
                outcome = self._handle_archive_error(session, cid, comp_path, e)
                if outcome == FileStatus.RETRY_PENDING:
                    any_retry_pending = True

        if ctx.group_id is not None and primary_archive_path is not None:
            update_file_metadata(
                session, ctx.group_id, {"archive_path": primary_archive_path}
            )

        # Mark group complete only after all components archived. Any
        # lingering RETRY_PENDING (a sibling failed) leaves the group
        # recoverable on the retry path.
        if ctx.group_id is not None and not any_retry_pending:
            mark_group_complete(session, ctx.group_id)

        logger.info(
            f"Archived group '{ctx.display_name}': "
            f"{len(ctx.component_ids)} component(s) -> {archive_config.name}"
        )

    def _handle_archive_error(
        self,
        session: Session,
        component_id: int,
        comp_path: Path,
        error: Exception,
    ) -> FileStatus | None:
        """Mark a component RETRY_PENDING or FAILED based on retry budget.

        Returns the status applied, or None if the component disappeared
        mid-flight. Separated from the archive loop so each component's
        error bookkeeping (retry count, log level) is a single concern.
        """
        max_retries = self.app_config.service.max_retries
        comp_record = get_component_by_source_path(session, str(comp_path.resolve()))
        if comp_record is None:
            logger.warning(
                f"Component record gone for {comp_path.name} "
                f"during archive error handling — skipping"
            )
            return None

        current_retries = comp_record["retry_count"]
        if current_retries < max_retries:
            update_component_status(
                session,
                component_id,
                FileStatus.RETRY_PENDING,
                error_message=str(error),
            )
            logger.warning(
                f"Archive failed for {comp_path.name} "
                f"(attempt {current_retries + 1}/{max_retries}): {error}"
            )
            return FileStatus.RETRY_PENDING

        update_component_status(
            session,
            component_id,
            FileStatus.FAILED,
            error_message=str(error),
        )
        logger.error(
            f"Archive permanently failed for {comp_path.name} "
            f"after {max_retries} retries: {error}"
        )
        return FileStatus.FAILED
