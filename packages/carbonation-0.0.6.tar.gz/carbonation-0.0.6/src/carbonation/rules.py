"""Rules evaluation engine for carbonation.

Evaluates integrity, completeness, selection, and routing rules. Plugin
callables are resolved at config-load time and stored on the rule
models, so this module never needs a registry argument at runtime.
"""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path

from loguru import logger

from carbonation.config import (
    CompletenessConfig,
    IntegrityCheck,
    RoutingRule,
    SelectionRule,
)


def check_integrity(
    file_path: Path, checks: list[IntegrityCheck]
) -> tuple[bool, str | None]:
    """Run built-in integrity checks on a file.

    Returns (passed, error_message). error_message is None if passed.
    """
    if not file_path.exists():
        return False, f"File does not exist: {file_path}"
    if not os.access(file_path, os.R_OK):
        return False, f"File not readable: {file_path}"

    for check in checks:
        if check.type == "min_size":
            min_bytes = int(check.value) if check.value is not None else 0
            actual = file_path.stat().st_size
            if actual < min_bytes:
                return False, f"File too small: {actual} bytes < {min_bytes} min_size"
        else:
            logger.warning(f"Unknown integrity check type: {check.type!r}")

    return True, None


def resolve_group_key(
    file_path: Path,
    completeness: CompletenessConfig | None,
) -> str | None:
    """Resolve the group key for a file based on completeness config.

    Returns None if no completeness config (standalone file).
    """
    if completeness is None:
        return None

    if completeness.group_by == "stem":
        return file_path.stem
    elif completeness.group_by == "plugin":
        if completeness.group_function_callable is None:
            logger.error(
                "Plugin grouping referenced but no callable resolved — "
                "rules.toml validation should have caught this"
            )
            return None
        return completeness.group_function_callable(file_path=file_path)
    else:
        logger.error(f"Unknown group_by: {completeness.group_by!r}")
        return None


def check_completeness(
    group_key: str,
    watch_name: str,
    expected_extensions: list[str],
    component_paths: list[Path],
) -> bool:
    """Check if all expected extensions are present for a group."""
    present_extensions = {p.suffix for p in component_paths}
    missing = set(expected_extensions) - present_extensions
    if missing:
        logger.debug(
            f"Group '{group_key}' in '{watch_name}' missing extensions: {missing}"
        )
        return False
    return True


def evaluate_selection(
    metadata: dict,
    rules: list[SelectionRule],
) -> bool:
    """Evaluate selection rules against metadata. Rules are ORed.

    Returns True if any rule set passes (file should be archived).
    If no rules are defined, defaults to True (accept all).
    """
    if not rules:
        return True

    for rule in rules:
        if _evaluate_single_selection(metadata, rule):
            return True

    return False


def _evaluate_single_selection(
    metadata: dict,
    rule: SelectionRule,
) -> bool:
    """Evaluate a single selection rule. All conditions within are ANDed."""
    if rule.has_keys is not None:
        for key in rule.has_keys:
            if key not in metadata or metadata[key] is None:
                return False

    if rule.field is not None and rule.compiled_patterns:
        value = metadata.get(rule.field)
        if value is None:
            return False
        value_str = str(value)
        if not any(p.search(value_str) for p in rule.compiled_patterns):
            return False

    if rule.type == "plugin" and rule.function is not None:
        if rule.function_callable is None:
            logger.error(
                f"Plugin selection '{rule.function}' has no resolved callable — "
                f"rules.toml validation should have caught this"
            )
            return False
        try:
            result = rule.function_callable(metadata=metadata, **rule.kwargs)
        except Exception:
            logger.exception(
                f"Plugin selection function '{rule.function}' raised an exception — "
                f"rejecting file (fix the plugin and retry)"
            )
            return False
        if not result:
            return False

    return True


def resolve_routing(
    metadata: dict,
    filename: str,
    routing_rules: list[RoutingRule],
    default_archive: str,
) -> str:
    """Resolve which archive to use for a file.

    Evaluates routing rules in order. First match wins.

    .. note:: Glob matching uses :func:`fnmatch.fnmatch`, which is
       **case-sensitive on Linux/macOS** and **case-insensitive on Windows**.
       For portable routing rules, use consistent casing or regex-based
       plugin routing instead.
    """
    for rule in routing_rules:
        if rule.match is not None and rule.archive is not None:
            if fnmatch.fnmatch(filename, rule.match):
                return rule.archive

        if rule.type == "plugin" and rule.function is not None:
            if rule.function_callable is None:
                logger.error(
                    f"Plugin routing '{rule.function}' has no resolved callable — "
                    f"rules.toml validation should have caught this"
                )
                continue
            try:
                result = rule.function_callable(metadata=metadata)
            except Exception:
                logger.exception(
                    f"Plugin routing function '{rule.function}' raised an exception — "
                    f"skipping this routing rule"
                )
                continue
            if result is not None:
                return result

    return default_archive
