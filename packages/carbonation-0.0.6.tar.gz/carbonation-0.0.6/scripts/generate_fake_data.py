"""Generate fake file groups for testing carbonation."""

import argparse
import json
import random
import string
from datetime import datetime, timedelta
from pathlib import Path

CATEGORIES = ["alpha", "beta", "gamma", "delta"]
ORIGINS = ["sensor-1", "sensor-2", "sensor-3", None]


def generate(output_dir: Path, count: int = 100) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    created_txt = 0
    created_json = 0
    skipped_txt = 0
    tiny_txt = 0

    for i in range(1, count + 1):
        stem = f"sample_{i:03d}"
        start = datetime(2026, 1, 1) + timedelta(hours=random.randint(0, 2000))
        stop = start + timedelta(minutes=random.randint(1, 120))
        category = random.choice(CATEGORIES)
        origin = random.choice(ORIGINS)

        # JSON metadata file
        meta = {
            "start": start.isoformat(),
            "stop": stop.isoformat(),
            "category": category,
            "origin": origin,
        }
        (output_dir / f"{stem}.json").write_text(json.dumps(meta, indent=2))
        created_json += 1

        # TXT data file (varying sizes, with some edge cases)
        if i % 25 == 0:
            # Intentionally small — should fail min_size integrity check
            (output_dir / f"{stem}.txt").write_text("x")
            created_txt += 1
            tiny_txt += 1
        elif i % 33 == 0:
            # Skip .txt entirely — incomplete group
            skipped_txt += 1
        else:
            lines = random.randint(10, 500)
            data = "\n".join(
                "".join(random.choices(string.ascii_lowercase + " ", k=80))
                for _ in range(lines)
            )
            (output_dir / f"{stem}.txt").write_text(data)
            created_txt += 1

    print(f"Generated in {output_dir}:")
    print(f"  {created_json} .json files")
    print(f"  {created_txt} .txt files ({tiny_txt} intentionally tiny)")
    print(f"  {skipped_txt} .txt files skipped (incomplete groups)")
    print(f"  {created_json - skipped_txt - tiny_txt} complete, valid groups")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        default="test_data/delivery",
        type=Path,
        help="Output directory (default: test_data/delivery)",
    )
    parser.add_argument(
        "--count",
        default=100,
        type=int,
        help="Number of file groups to generate (default: 100)",
    )
    args = parser.parse_args()
    generate(args.output, args.count)
