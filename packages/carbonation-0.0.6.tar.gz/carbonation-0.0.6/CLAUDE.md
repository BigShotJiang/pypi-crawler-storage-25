# Carbonation

File delivery monitoring and archival service. Watches directories for incoming files, groups them by stem, validates integrity, extracts metadata via plugins, applies selection/routing rules, and archives to configurable destinations.

## Quick Reference

```bash
uv run pytest tests/                          # all tests (~55s)
uv run pytest tests/ -m "not integration"     # unit tests only (~6s)
uv run pytest tests/test_integration.py       # integration tests only (~50s)
uv run ruff check src/ tests/                 # lint
uv run ruff check --fix src/ tests/           # lint + autofix
uv run pyright src/                           # type check
uv run pre-commit run --all-files             # all pre-commit hooks
```

## Project Layout

```
src/carbonation/          # main package (src layout, built with hatchling)
  cli.py                  # Click CLI group, AppContext, _load_service_context
  commands/               # CLI command modules (registered via import in cli.py)
    init.py               # Scaffold templates: config.toml, rules.toml, plugin, systemd
    config.py             # check group: check config, check rules commands
    db.py                 # db init/upgrade/status commands
    run.py                # run command (--dry-run, --once)
    reconcile.py          # reconcile delivery/archive commands
    status.py             # status, retry commands
    query.py              # query files command (dynamic plugin-based filters)
  config.py               # Pydantic models + TOML loading for config.toml and rules.toml
  service.py              # Main orchestrator: watcher -> rules -> archive pipeline
  watcher.py              # Watchdog integration with settle-timer debouncing
  rules.py                # Integrity, completeness, selection, routing evaluation
  archive.py              # File copy/move/hardlink/symlink with permissions
  reconcile.py            # Sync delivery/archive directories with DB
  plugin.py               # Plugin dataclass, LoadedPlugin, load_plugin, resolver
  api.py                  # Public Python API: connect, query_files, CarbonationDB
  log.py                  # Loguru configuration
  exceptions.py           # CarbonationError hierarchy
  db/
    models.py             # SQLAlchemy ORM: FileComponent, FileBase (abstract)
    queries.py            # All DB operations (no auto-commit; callers commit)
    engine.py             # Engine/session factory, schema init/verify
    migrations/           # Alembic migrations (bundled, no alembic.ini)
      env.py              # Alembic environment (programmatic invocation)
      versions/           # Migration scripts
examples/                 # Example config.toml, rules.toml, plugin
scripts/                  # generate_fake_data.py for test data
tests/                    # pytest suite
```

## Architecture

**Processing pipeline** (in `service.py:_process_event_inner`):
1. Record component (insert-first, handle IntegrityError for races)
2. Integrity checks (min_size, readability)
3. Completeness grouping (stem-based or plugin-based, with group locking)
4. Metadata extraction (plugin `extract()` function)
5. Selection rules (OR logic, has_keys / field matches / plugin)
6. Routing (glob or plugin, first-match-wins)
7. Archive (copy/move/hardlink/symlink with configurable permissions)

**Threading model**: Main thread runs event loop, ThreadPoolExecutor processes events, per-group locks (WeakValueDictionary) protect completeness checks, periodic Timer for reconciliation + completeness timeouts.

**Database**: Commits happen at caller boundaries, not in individual query functions. `_process_event` commits at the end of the full pipeline; it also commits inside the per-group lock in `_process_event_inner` so the next worker's completeness query sees our component once it acquires the lock (required for Postgres READ COMMITTED — SQLite/MariaDB tolerate the older single-commit shape in practice). `reconcile_delivery`/`reconcile_archive` commit at the end. All timestamps are written as timezone-aware UTC (`datetime.now(timezone.utc)`); `ensure_utc()` in `queries.py` normalizes naive datetimes at read boundaries as a safety net for SQLite.

**Alembic strategy**: Core migrations live at `db/migrations/` and are invoked programmatically via `engine.py:run_migrations(engine, plugin_spec)` — there is no `alembic.ini`. The core branch is labeled `"core"` on `001_initial_schema`. The plugin package ships its own migrations (on a separate branch label, e.g. `"my_plugin"`, with `depends_on=("core",)`); their directory is advertised to carbonation via `Plugin.migrations_path`. At runtime `run_migrations` composes core + plugin version locations and runs `alembic upgrade heads` so both branches advance under a single `alembic_version` table. `check_schema_drift()` only verifies required base tables exist — column-level drift is migration-owned.

**Plugin system**: A plugin is an installable Python package declaring the `carbonation.plugin` entry point. It exposes a top-level `plugin = Plugin(file_model=..., extractors={...}, group_functions={...}, selection_functions={...}, routing_functions={...}, migrations_path=..., query_defaults=...)` — see `examples/my_plugin/` for a reference. `config.toml`'s `[plugins] package = "..."` pins a specific package; omitted, the sole registered entry point is used. `rules.toml` references plugin callables by short key (e.g. `metadata.extract = "sample"`); `load_rules_config` resolves each key against the plugin's dicts at startup and attaches the resolved callable to the rule model. Missing keys raise `ConfigError` listing the available options. Declarative rule modes (stem grouping, `has_keys`/`field+matches` selection, glob routing) remain in `rules.toml` and never touch the plugin.

## Testing

- **Unit tests** (`test_*.py` except `test_integration.py`): Fast, in-memory SQLite, no filesystem watchers
- **Integration tests** (`test_integration.py`): Start real service in background thread, write files to disk, verify archive + DB state. Marked `@pytest.mark.integration`.
- **Test plugin**: `tests/_test_plugin/` is a full plugin package (model + extractors + rules + alembic migration). `tests/conftest.py` imports it on module load and exports `TEST_PLUGIN: LoadedPlugin` for tests that wire up a service; the `db_engine` fixture uses `run_migrations(engine, TEST_PLUGIN.spec)` so every test exercises the real multi-branch alembic composition.
- Permission tests (`test_archive.py`) are skipped on Windows (`@pytest.mark.skipif(sys.platform == "win32")`)

## Configuration

Two TOML files:
- **config.toml**: service settings, logging, database, plugins, watch directories, archive destinations
- **rules.toml**: integrity checks, completeness grouping, metadata module, selection rules, routing rules

Paths in config.toml are resolved relative to the config file's directory. `archive.destination` is resolved relative to `archive.base_path` when set.

**Hot-reload**: The service watches `rules.toml` for changes (debounced 0.5s). On modification it validates the new file, checks that all watch configs still reference valid rule sets, and swaps `self.rules_config` under `_rules_lock`. Worker threads read the config via `_snapshot_rules()` which takes the same lock, ensuring a consistent view. Invalid files or missing rule sets are rejected with a log warning — the service keeps running with the previous rules.

**Database credentials**: `DatabaseConfig` uses structured fields (`drivername`, `host`, `port`, `username`, `password`, `name`) instead of a raw URL string. The `url` property builds the SQLAlchemy URL via `URL.create()`. Credentials are layered: config.toml values take priority over `~/.config/carbonation/secrets.toml`. Secrets file uses the same `[database]` section format. SQLite `name` paths are resolved relative to the config file.

## Reliability

- **Retry logic**: Archive failures mark components `RETRY_PENDING` instead of `FAILED`. Periodic checker re-enqueues them after `retry_delay`. After `max_retries` attempts, permanently marked `FAILED`. Manual retry via `carbonation retry`.
- **Post-archive verification**: File size compared after copy/move. Mismatch deletes the corrupt copy and raises an error (triggers retry).
- **Watch liveness**: Each reconciliation cycle verifies watch directories are present and readable.

## Observability

- **Heartbeat**: `service_state` table updated on its own timer (`heartbeat_interval`, default `60s`) with `last_heartbeat`, `queue_depth`. Also pings the systemd watchdog (`WATCHDOG=1`) each cycle.
- **`carbonation status`**: Shows heartbeat age, component counts, watch directory health.
- **Stats logging**: Periodic summary logged each heartbeat: `Stats: archived=42, failed=2, queue_depth=0`.
- **Structured logging**: Set `format = "json"` in `[logging]` config for JSON lines output (loguru `serialize=True`).
- **`carbonation check rules`**: Dry-run a candidate rules file against existing DB groups to preview selection/routing changes.

## CLI Commands

```
carbonation check config             # validate config + rules
carbonation check rules FILE         # dry-run rules changes
carbonation db init                  # create database schema
carbonation db status                # component counts, metadata check
carbonation run [--dry-run] [--once] # start the service
carbonation status                   # heartbeat, counts, watch health
carbonation retry [--watch-name X]   # re-enqueue failed components
carbonation reconcile delivery       # sync delivery dirs with DB
carbonation reconcile archive        # sync archive dirs with DB
carbonation query files [filters]    # dynamic query with plugin columns
```

## Common Patterns

- All config models are Pydantic with field validators
- Duration strings: `"5s"`, `"1m"`, `"24h"`, `"7d"` (parsed by `config.parse_duration`)
- File permissions: `file_mode`/`dir_mode` as octal ints (default `0o440`/`0o550`), only applied on copy/move (not hardlink/symlink)
- `signal.signal()` is guarded for non-main-thread usage (needed for test harness)
- DB commits happen at caller boundaries, not in query functions
- Retry count tracked per-component; periodic checker increments on re-enqueue
