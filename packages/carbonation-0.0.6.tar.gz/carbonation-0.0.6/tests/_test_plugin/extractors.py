"""Metadata extractor used by integration tests."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any


def extract_sample(file_paths: list[Path]) -> dict[str, Any]:
    """Read the JSON sibling and return typed metadata."""
    json_file = next(p for p in file_paths if p.suffix == ".json")
    data = json.loads(json_file.read_text())
    return {
        "start": datetime.fromisoformat(data["start"]),
        "stop": datetime.fromisoformat(data["stop"]),
        "category": data["category"],
        "origin": data.get("origin"),
    }
