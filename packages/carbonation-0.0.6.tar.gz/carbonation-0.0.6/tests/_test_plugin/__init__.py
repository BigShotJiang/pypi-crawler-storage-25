"""Test plugin package — exercises the installable-plugin model end-to-end.

Tests import ``plugin`` from here and hand it to ``LoadedPlugin``, so
this package doubles as the integration fixture for alembic composition
plus the simulated downstream plugin for rule callable resolution.
"""

from __future__ import annotations

from pathlib import Path

from carbonation import Plugin

from tests._test_plugin.extractors import extract_sample
from tests._test_plugin.model import File
from tests._test_plugin.rules import (
    group_by_stem_prefix,
    route_by_category,
    should_archive,
)

__all__ = ["File", "plugin"]

plugin = Plugin(
    file_model=File,
    extractors={
        "sample": extract_sample,
        "sample_integration": extract_sample,
    },
    group_functions={"by_stem_prefix": group_by_stem_prefix},
    selection_functions={"should_archive": should_archive},
    routing_functions={"by_category": route_by_category},
    migrations_path=Path(__file__).parent / "migrations" / "versions",
    query_defaults={"order_by": "-start"},
)
