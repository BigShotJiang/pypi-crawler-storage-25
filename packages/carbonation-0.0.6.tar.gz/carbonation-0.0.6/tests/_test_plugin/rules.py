"""Rule helpers exposed by the test plugin.

These are deliberately tiny so tests can exercise the dict-lookup path
for grouping/selection/routing without carrying format-specific logic.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def group_by_stem_prefix(*, file_path: Path, **_: Any) -> str | None:
    """Group by the portion of the stem before the first '_'."""
    stem = file_path.stem
    return stem.split("_", 1)[0] if stem else None


def should_archive(*, metadata: dict[str, Any], **_: Any) -> bool:
    """Accept any group where metadata declares a non-empty 'category'."""
    return bool(metadata.get("category"))


def route_by_category(*, metadata: dict[str, Any], **_: Any) -> str | None:
    """Route by the metadata 'category' field, or None to fall through."""
    category = metadata.get("category")
    return f"{category}-archive" if category else None
