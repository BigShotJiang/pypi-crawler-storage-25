"""Tests for delivery and archive reconciliation."""

from __future__ import annotations

from pathlib import Path

import pytest

from carbonation.config import (
    ArchiveConfig,
    CompletenessConfig,
    MetadataConfig,
    RuleSet,
    RulesConfig,
    WatchConfig,
)
from carbonation.db.models import FileStatus, get_file_model
from carbonation.db.queries import (
    get_component_by_source_path,
    get_delivery_count,
    record_component,
    update_component_status,
)
from carbonation.reconcile import reconcile_archive, reconcile_delivery, walk_directory


class TestWalkDirectory:
    def test_walk_flat(self, tmp_path: Path):
        (tmp_path / "a.csv").write_text("aaa")
        (tmp_path / "b.json").write_text("bbb")
        result = walk_directory(tmp_path, recursive=False)
        assert len(result) == 2
        for path_str, (size, mtime) in result.items():
            assert Path(path_str).is_absolute()
            assert size > 0

    def test_walk_recursive(self, tmp_path: Path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (tmp_path / "a.csv").write_text("aaa")
        (sub / "b.csv").write_text("bbb")
        result = walk_directory(tmp_path, recursive=True)
        assert len(result) == 2

    def test_walk_nonexistent(self, tmp_path: Path):
        result = walk_directory(tmp_path / "nope")
        assert len(result) == 0

    def test_walk_empty(self, tmp_path: Path):
        result = walk_directory(tmp_path)
        assert len(result) == 0


class TestReconcileDelivery:
    @pytest.fixture
    def watch_dir(self, tmp_path: Path) -> Path:
        d = tmp_path / "delivery"
        d.mkdir()
        return d

    @pytest.fixture
    def watch_config(self, watch_dir: Path) -> WatchConfig:
        return WatchConfig(
            name="test-watch",
            path=watch_dir,
            rules="test-rules",
            archive="test-archive",
        )

    def test_detects_new_files(self, db_session, watch_config, watch_dir):
        (watch_dir / "new1.csv").write_text("data1")
        (watch_dir / "new2.csv").write_text("data2")

        stats = reconcile_delivery(db_session, watch_config)
        assert stats["new"] == 2
        assert stats["cleared"] == 0
        assert get_delivery_count(db_session) == 2

    def test_detects_cleared_files(self, db_session, watch_config, watch_dir):
        # Create a file, record it, then remove the file
        f = watch_dir / "gone.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        record_component(
            db_session,
            watch_name="test-watch",
            filename="gone.csv",
            source_path=path_str,
            size_bytes=4,
        )
        f.unlink()

        stats = reconcile_delivery(db_session, watch_config)
        assert stats["cleared"] == 1

        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.CLEARED
        assert comp["in_delivery"] is False

    def test_preserves_archived_on_clear(self, db_session, watch_config, watch_dir):
        f = watch_dir / "archived.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        cid = record_component(
            db_session,
            watch_name="test-watch",
            filename="archived.csv",
            source_path=path_str,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path="/archive/archived.csv"
        )
        f.unlink()

        reconcile_delivery(db_session, watch_config)
        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.ARCHIVED  # preserved

    def test_no_changes(self, db_session, watch_config, watch_dir):
        stats = reconcile_delivery(db_session, watch_config)
        assert stats["new"] == 0
        assert stats["cleared"] == 0

    def test_requeue_events(self, db_session, watch_config, watch_dir):
        from queue import Queue
        from carbonation.watcher import FileEvent

        (watch_dir / "pending.csv").write_text("data")
        event_queue: Queue[FileEvent] = Queue()

        stats = reconcile_delivery(db_session, watch_config, event_queue=event_queue)
        assert stats["requeued"] == 1
        assert not event_queue.empty()

    def test_scan_failure_does_not_clear_db_rows(
        self, db_session, watch_config, watch_dir, monkeypatch
    ):
        """Bug #2 (Phase 1a): a transient OSError on the directory walk
        currently makes ``walk_directory`` return ``{}``, which causes
        ``reconcile_delivery`` to mark every existing DB row as CLEARED.
        A scan failure must not be interpreted as "directory is empty".
        """
        # Seed: two files exist on disk and in the DB
        f1 = watch_dir / "real1.csv"
        f1.write_text("data1")
        f2 = watch_dir / "real2.csv"
        f2.write_text("data2")
        path1 = str(f1.resolve())
        path2 = str(f2.resolve())

        record_component(
            db_session,
            watch_name="test-watch",
            filename="real1.csv",
            source_path=path1,
            size_bytes=5,
        )
        record_component(
            db_session,
            watch_name="test-watch",
            filename="real2.csv",
            source_path=path2,
            size_bytes=5,
        )
        db_session.commit()

        # Simulate a transient permission error during the directory scan.
        # ``walk_directory`` uses ``os.scandir`` for the non-recursive case.
        import os

        original_scandir = os.scandir

        def failing_scandir(path):
            if str(path) == str(watch_dir):
                raise PermissionError("simulated transient mount failure")
            return original_scandir(path)

        monkeypatch.setattr(os, "scandir", failing_scandir)

        reconcile_delivery(db_session, watch_config)

        # Both rows must remain — the scan failure must not cause data loss.
        comp1 = get_component_by_source_path(db_session, path1)
        comp2 = get_component_by_source_path(db_session, path2)
        assert comp1 is not None
        assert comp2 is not None
        assert comp1["status"] != FileStatus.CLEARED, (
            f"Row 1 was incorrectly cleared after scan failure: {comp1['status']}"
        )
        assert comp2["status"] != FileStatus.CLEARED, (
            f"Row 2 was incorrectly cleared after scan failure: {comp2['status']}"
        )
        assert comp1["in_delivery"] is True
        assert comp2["in_delivery"] is True


class TestReconcileArchive:
    def test_registers_orphaned_files(self, db_session, tmp_path):
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        (archive_dir / "orphan.csv").write_text("data")

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["created"] == 1

    def test_finds_existing_records(self, db_session, tmp_path):
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        f = archive_dir / "known.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        cid = record_component(
            db_session,
            watch_name="test",
            filename="known.csv",
            source_path=path_str,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path=path_str
        )
        db_session.commit()

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["found"] == 1
        assert stats["created"] == 0

    def test_empty_archive(self, db_session, tmp_path):
        configs = [
            ArchiveConfig(
                name="test-archive",
                destination=str(tmp_path / "nonexistent" / "{cat}"),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["found"] == 0
        assert stats["created"] == 0


class TestReconcileArchiveMissing:
    """``bulk_mark_archive_missing`` sets ``status=MISSING`` and clears
    ``in_archive`` but **preserves** ``archive_path`` so a recovered file
    (e.g. restored from offsite backup) is matched by archive_path on the
    next reconcile cycle and flipped back to ARCHIVED.
    """

    def _seed_archived(self, db_session, archive_dir: Path, name: str = "known.csv"):
        """Write a file on disk + DB row marked ARCHIVED. Returns (path_str, cid)."""
        f = archive_dir / name
        f.write_text("data")
        path_str = str(f.resolve())

        cid = record_component(
            db_session,
            watch_name="test",
            filename=name,
            source_path=path_str,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path=path_str
        )
        db_session.commit()
        return path_str, cid

    def test_missing_marks_status_and_preserves_path(self, db_session, tmp_path):
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        path_str, cid = self._seed_archived(db_session, archive_dir, "gone.csv")

        # Delete the file on disk
        Path(path_str).unlink()

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["missing"] == 1

        from carbonation.db.queries import get_component_by_source_path

        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.MISSING
        assert comp["in_archive"] is False
        assert comp["archive_path"] == path_str, (
            "archive_path must be preserved so recovery can match"
        )

    def test_recovery_flips_missing_to_archived(self, db_session, tmp_path):
        """A file that goes missing then reappears at the same path
        flips back to ARCHIVED on the next reconcile cycle."""
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        path_str, _ = self._seed_archived(db_session, archive_dir, "lost_and_found.csv")

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]

        # Cycle 1: file disappears, gets marked MISSING.
        Path(path_str).unlink()
        reconcile_archive(db_session, configs)

        from carbonation.db.queries import get_component_by_source_path

        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.MISSING

        # Cycle 2: file is restored at the same archive path.
        Path(path_str).write_text("recovered data")
        stats = reconcile_archive(db_session, configs)

        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.ARCHIVED, (
            "MISSING file must flip back to ARCHIVED when re-discovered"
        )
        assert comp["in_archive"] is True
        assert comp["archive_path"] == path_str
        # Recovery is counted under updated_flag, not created — the row
        # already existed and was just re-flagged.
        assert stats["found"] == 1
        assert stats["created"] == 0
        assert stats["updated_flag"] == 1


# ---------------------------------------------------------------------------
# Archive reconcile — group assignment + metadata extraction
# ---------------------------------------------------------------------------


def _sample_extract(file_paths: list[Path]) -> dict:
    """Return category/origin from the .json sibling of a group."""
    import json

    json_file = next(p for p in file_paths if p.suffix == ".json")
    data = json.loads(json_file.read_text())
    return {
        "category": data["category"],
        "origin": data.get("origin"),
    }


def _sample_pair(dest_dir: Path, stem: str, *, category: str, origin: str) -> None:
    """Write a .json + .txt pair into ``dest_dir``."""
    import json

    dest_dir.mkdir(parents=True, exist_ok=True)
    (dest_dir / f"{stem}.json").write_text(
        json.dumps({"category": category, "origin": origin})
    )
    (dest_dir / f"{stem}.txt").write_text("x" * 50)


def _make_reconcile_fixtures(
    tmp_path: Path,
    *,
    group_by: str = "stem",
) -> tuple[ArchiveConfig, WatchConfig, RulesConfig]:
    """Build the argument bundle for a grouping-enabled reconcile_archive call.

    The metadata config carries its resolved extract_callable inline — the
    production path has ``load_rules_config`` do this against a plugin, but
    the tests fabricate configs directly.
    """
    archive_dir = tmp_path / "archive"
    archive_dir.mkdir(exist_ok=True)

    archive_config = ArchiveConfig(
        name="test-archive",
        base_path=archive_dir,
        destination="{category}",
    )
    watch_config = WatchConfig(
        name="test-watch",
        path=tmp_path / "delivery",
        rules="sample-rules",
        archive="test-archive",
    )
    metadata_cfg = MetadataConfig(extract="sample")
    object.__setattr__(metadata_cfg, "extract_callable", _sample_extract)

    rules_config = RulesConfig(
        rule_sets={
            "sample-rules": RuleSet(
                completeness=CompletenessConfig(
                    group_by=group_by,
                    expected_extensions=[".txt", ".json"],
                ),
                metadata=metadata_cfg,
            ),
        }
    )
    return archive_config, watch_config, rules_config


class TestReconcileArchiveGrouping:
    """Archive reconcile also buckets orphans into groups and runs extract()."""

    def test_complete_group_created_and_metadata_extracted(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_001",
            category="alpha",
            origin="sensor-1",
        )

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        assert stats["created"] == 2
        assert stats["groups_created"] == 1
        assert stats["groups_completed"] == 1
        assert stats["metadata_extracted"] == 1

        FileModel = get_file_model()
        from sqlalchemy import select

        row = db_session.execute(
            select(FileModel).where(FileModel.group_key == "alpha/smp_001")
        ).scalar_one()
        assert row.watch_name == "test-watch"
        assert row.complete is True
        assert row.category == "alpha"
        assert row.origin == "sensor-1"

        # Components are now linked to the group
        from carbonation.db.queries import get_group_components

        comps = get_group_components(db_session, row.id)
        assert len(comps) == 2

    def test_incomplete_group_not_completed_no_metadata(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        # Only the .txt — missing the .json sibling.
        (archive_cfg.base_path / "alpha").mkdir(parents=True)
        (archive_cfg.base_path / "alpha" / "smp_incomp.txt").write_text("x" * 20)

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        assert stats["created"] == 1
        assert stats["groups_created"] == 1
        assert stats["groups_completed"] == 0
        assert stats["metadata_extracted"] == 0

        FileModel = get_file_model()
        from sqlalchemy import select

        row = db_session.execute(
            select(FileModel).where(FileModel.group_key == "alpha/smp_incomp")
        ).scalar_one()
        assert row.complete is False
        assert row.category is None

    def test_same_stem_different_parents_are_distinct_groups(
        self, db_session, tmp_path
    ):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_001",
            category="alpha",
            origin="sensor-1",
        )
        _sample_pair(
            archive_cfg.base_path / "beta",
            "smp_001",
            category="beta",
            origin="sensor-2",
        )

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        assert stats["groups_created"] == 2
        assert stats["groups_completed"] == 2
        assert stats["metadata_extracted"] == 2

        FileModel = get_file_model()
        from sqlalchemy import select

        keys = {row[0] for row in db_session.execute(select(FileModel.group_key)).all()}
        assert keys == {"alpha/smp_001", "beta/smp_001"}

    def test_ambiguous_watches_skip_grouping(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        watch_cfg_b = WatchConfig(
            name="other-watch",
            path=tmp_path / "delivery-b",
            rules="sample-rules",
            archive="test-archive",
        )
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_amb",
            category="alpha",
            origin="sensor-1",
        )

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg, watch_cfg_b],
            rules_config=rules,
        )

        assert stats["created"] == 2
        assert stats["groups_created"] == 0
        assert stats["metadata_extracted"] == 0

    def test_watch_flag_disambiguates(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        watch_cfg_b = WatchConfig(
            name="other-watch",
            path=tmp_path / "delivery-b",
            rules="sample-rules",
            archive="test-archive",
        )
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_pick",
            category="alpha",
            origin="sensor-1",
        )

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg, watch_cfg_b],
            rules_config=rules,
            watch_name="test-watch",
        )

        assert stats["groups_created"] == 1
        assert stats["groups_completed"] == 1

        FileModel = get_file_model()
        from sqlalchemy import select

        row = db_session.execute(
            select(FileModel).where(FileModel.group_key == "alpha/smp_pick")
        ).scalar_one()
        assert row.watch_name == "test-watch"

    def test_dry_run_does_not_write_groups(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_dry",
            category="alpha",
            origin="sensor-1",
        )

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
            dry_run=True,
        )

        assert stats["groups_created"] == 1
        assert stats["groups_completed"] == 1

        FileModel = get_file_model()
        from sqlalchemy import select

        assert db_session.execute(select(FileModel)).first() is None
        from carbonation.db.queries import get_archive_count

        assert get_archive_count(db_session) == 0

    def test_pipeline_archived_file_not_duplicated(self, db_session, tmp_path):
        """A file already archived by the pipeline must not spawn an orphan row."""
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_pipe",
            category="alpha",
            origin="sensor-1",
        )

        delivery = tmp_path / "delivery"
        delivery.mkdir(exist_ok=True)
        delivery_txt = str((delivery / "smp_pipe.txt").resolve())
        archive_txt = str((archive_cfg.base_path / "alpha" / "smp_pipe.txt").resolve())

        cid = record_component(
            db_session,
            watch_name="test-watch",
            filename="smp_pipe.txt",
            source_path=delivery_txt,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path=archive_txt
        )
        db_session.commit()

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        # The .txt matches an existing pipeline row via archive_path,
        # only the .json is a true orphan.
        assert stats["found"] == 1
        assert stats["created"] == 1
        assert stats["dedup_removed"] == 0

        from sqlalchemy import select

        from carbonation.db.models import FileComponent

        rows = (
            db_session.execute(
                select(FileComponent).where(FileComponent.archive_path == archive_txt)
            )
            .scalars()
            .all()
        )
        assert len(rows) == 1
        assert rows[0].source_path == delivery_txt

    def test_cleanup_removes_existing_orphan_duplicates(self, db_session, tmp_path):
        """Orphan rows created by previous reconciles get deleted when a pipeline row covers them."""
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_dup",
            category="alpha",
            origin="sensor-1",
        )

        archive_txt = str((archive_cfg.base_path / "alpha" / "smp_dup.txt").resolve())
        archive_json = str((archive_cfg.base_path / "alpha" / "smp_dup.json").resolve())
        delivery_txt = str((tmp_path / "delivery" / "smp_dup.txt").resolve())
        delivery_json = str((tmp_path / "delivery" / "smp_dup.json").resolve())

        # Pipeline rows.
        for delivery, archive, filename in (
            (delivery_txt, archive_txt, "smp_dup.txt"),
            (delivery_json, archive_json, "smp_dup.json"),
        ):
            cid = record_component(
                db_session,
                watch_name="test-watch",
                filename=filename,
                source_path=delivery,
            )
            update_component_status(
                db_session, cid, FileStatus.ARCHIVED, archive_path=archive
            )

        # Pre-existing orphan duplicates from an older reconcile run.
        orphan_txt = record_component(
            db_session,
            watch_name=None,
            filename="smp_dup.txt",
            source_path=archive_txt,
        )
        update_component_status(
            db_session, orphan_txt, FileStatus.ARCHIVED, archive_path=archive_txt
        )
        orphan_json = record_component(
            db_session,
            watch_name=None,
            filename="smp_dup.json",
            source_path=archive_json,
        )
        update_component_status(
            db_session, orphan_json, FileStatus.ARCHIVED, archive_path=archive_json
        )
        db_session.commit()

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        assert stats["dedup_removed"] == 2
        assert stats["created"] == 0
        assert stats["found"] == 2

        from sqlalchemy import select

        from carbonation.db.models import FileComponent

        # Only the two pipeline rows remain.
        for path in (archive_txt, archive_json):
            rows = (
                db_session.execute(
                    select(FileComponent).where(FileComponent.archive_path == path)
                )
                .scalars()
                .all()
            )
            assert len(rows) == 1
            assert rows[0].source_path != path

    def test_dry_run_does_not_delete_duplicates(self, db_session, tmp_path):
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_dryd",
            category="alpha",
            origin="sensor-1",
        )
        archive_txt = str((archive_cfg.base_path / "alpha" / "smp_dryd.txt").resolve())
        delivery_txt = str((tmp_path / "delivery" / "smp_dryd.txt").resolve())

        cid = record_component(
            db_session,
            watch_name="test-watch",
            filename="smp_dryd.txt",
            source_path=delivery_txt,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path=archive_txt
        )
        orphan_id = record_component(
            db_session,
            watch_name=None,
            filename="smp_dryd.txt",
            source_path=archive_txt,
        )
        update_component_status(
            db_session, orphan_id, FileStatus.ARCHIVED, archive_path=archive_txt
        )
        db_session.commit()

        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
            dry_run=True,
        )

        assert stats["dedup_removed"] == 1

        from carbonation.db.queries import get_component_by_source_path

        assert get_component_by_source_path(db_session, archive_txt) is not None

    def test_second_pass_assigns_existing_orphans(self, db_session, tmp_path):
        """An orphan inserted by a prior run (no group_id) is picked up later."""
        archive_cfg, watch_cfg, rules = _make_reconcile_fixtures(tmp_path)
        _sample_pair(
            archive_cfg.base_path / "alpha",
            "smp_two_pass",
            category="alpha",
            origin="sensor-1",
        )

        # First run: only orphan creation, no grouping args.
        reconcile_archive(db_session, [archive_cfg])

        # Second run: add grouping args — existing orphans should be grouped.
        stats = reconcile_archive(
            db_session,
            [archive_cfg],
            watch_configs=[watch_cfg],
            rules_config=rules,
        )

        assert stats["created"] == 0
        assert stats["groups_created"] == 1
        assert stats["groups_completed"] == 1
        assert stats["metadata_extracted"] == 1
