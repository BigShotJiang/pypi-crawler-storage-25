"""Integration tests — end-to-end with real filesystem, service, and database."""

from __future__ import annotations

import json
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from carbonation.config import (
    AppConfig,
    ArchiveConfig,
    CompletenessConfig,
    IntegrityCheck,
    MetadataConfig,
    RuleSet,
    RulesConfig,
    SelectionRule,
    WatchConfig,
)
from carbonation.db.engine import create_session_factory, json_serializer
from carbonation.db.models import Base, FileStatus
from carbonation.db.queries import (
    get_component_by_source_path,
    get_delivery_count,
    get_archive_count,
    get_status_counts,
)
from carbonation.reconcile import reconcile_archive, reconcile_delivery
from carbonation.service import CarbonationService
from carbonation.watcher import FileEvent

from tests.conftest import TEST_PLUGIN

pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SETTLE = 0.3  # keep short for tests


def _write_sample_pair(
    delivery: Path,
    stem: str,
    *,
    category: str = "alpha",
    origin: str | None = "sensor-1",
    txt_content: str = "x" * 50,
) -> tuple[Path, Path]:
    """Write a matching .json + .txt sample pair into delivery."""
    start = datetime(2026, 3, 15, 12, 0, 0)
    stop = datetime(2026, 3, 15, 13, 0, 0)
    meta = {
        "start": start.isoformat(),
        "stop": stop.isoformat(),
        "category": category,
        "origin": origin,
    }
    json_path = delivery / f"{stem}.json"
    txt_path = delivery / f"{stem}.txt"
    json_path.write_text(json.dumps(meta, indent=2))
    txt_path.write_text(txt_content)
    return json_path, txt_path


RULES_TOML_TEMPLATE = """\
[sample-rules]

[[sample-rules.integrity]]
type = "min_size"
value = {min_size}

[sample-rules.completeness]
group_by = "stem"
expected_extensions = [".txt", ".json"]

[sample-rules.metadata]
extract = "sample_integration"

[[sample-rules.selection]]
has_keys = {has_keys}
"""


def _write_rules_toml(
    path: Path,
    *,
    min_size: int = 10,
    has_keys: str = '["category", "origin"]',
) -> None:
    """Write a rules.toml file for integration tests."""
    path.write_text(RULES_TOML_TEMPLATE.format(min_size=min_size, has_keys=has_keys))


def _build_service(
    tmp_path: Path,
    *,
    db_url: str | None = None,
    selection: list[SelectionRule] | None = None,
    integrity: list[IntegrityCheck] | None = None,
    rules_file: bool = False,
    archive_action: str = "copy",
) -> tuple[CarbonationService, sessionmaker, Path, Path]:
    """Build a fully wired CarbonationService against tmp_path.

    If rules_file=True, writes a real rules.toml and sets app_config.rules.file
    so the service can watch it for hot-reload.

    If db_url is None, defaults to a local SQLite file under tmp_path.

    Returns (service, session_factory, delivery_dir, archive_dir).
    """
    delivery = tmp_path / "delivery"
    delivery.mkdir()
    archive = tmp_path / "archive"
    archive.mkdir()

    if db_url is None:
        db_url = f"sqlite:///{(tmp_path / 'test.db').as_posix()}"

    from carbonation.config import RulesFileConfig

    rules_path = tmp_path / "rules.toml"
    if rules_file:
        _write_rules_toml(rules_path)

    app_config = AppConfig(
        watch=[
            WatchConfig(
                name="test-watch",
                path=delivery,
                patterns=["*.txt", "*.json"],
                rules="sample-rules",
                archive="test-archive",
                settle_seconds=SETTLE,
            ),
        ],
        archive=[
            ArchiveConfig(
                name="test-archive",
                base_path=archive,
                destination="{category}",
                action=archive_action,
            ),
        ],
        rules=RulesFileConfig(file=rules_path) if rules_file else RulesFileConfig(),
    )
    metadata_cfg = MetadataConfig(extract="sample_integration")
    object.__setattr__(
        metadata_cfg,
        "extract_callable",
        TEST_PLUGIN.spec.extractors["sample_integration"],
    )
    rules_config = RulesConfig(
        rule_sets={
            "sample-rules": RuleSet(
                integrity=integrity or [IntegrityCheck(type="min_size", value=10)],
                completeness=CompletenessConfig(
                    group_by="stem",
                    expected_extensions=[".txt", ".json"],
                ),
                metadata=metadata_cfg,
                selection=selection or [SelectionRule(has_keys=["category", "origin"])],
            ),
        }
    )

    engine = create_engine(db_url, json_serializer=json_serializer)
    Base.metadata.create_all(engine)
    factory = create_session_factory(engine)

    svc = CarbonationService(app_config, rules_config, TEST_PLUGIN, engine, factory)
    return svc, factory, delivery, archive


def _run_service_briefly(svc: CarbonationService, seconds: float) -> None:
    """Start the service in a background thread and stop it after *seconds*."""
    t = threading.Thread(target=svc.start, daemon=True)
    t.start()
    time.sleep(seconds)
    svc.stop()
    t.join(timeout=5)


def _wait_for_queue_drain(svc: CarbonationService, timeout: float = 5.0) -> None:
    """Wait until the event queue is empty, polling briefly."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if svc.event_queue.empty():
            return
        time.sleep(0.1)


# ---------------------------------------------------------------------------
# Service integration tests
# ---------------------------------------------------------------------------


class TestServiceEndToEnd:
    """Drop files → service processes → verify archive + DB."""

    def test_complete_group_archived(self, tmp_path, db_url):
        """A valid .json + .txt pair is archived to the correct directory."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        # Pre-populate delivery before starting the service
        _write_sample_pair(delivery, "smp_001", category="alpha")

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        try:
            txt = get_component_by_source_path(
                session, str((delivery / "smp_001.txt").resolve())
            )
            jsn = get_component_by_source_path(
                session, str((delivery / "smp_001.json").resolve())
            )
            assert txt is not None and txt["status"] == FileStatus.ARCHIVED
            assert jsn is not None and jsn["status"] == FileStatus.ARCHIVED

            # Files landed in archive/<category>/
            archived_files = list((archive / "alpha").iterdir())
            names = {f.name for f in archived_files}
            assert "smp_001.txt" in names
            assert "smp_001.json" in names
        finally:
            session.close()

    def test_multiple_groups(self, tmp_path, db_url):
        """Multiple sample groups are all processed independently."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        _write_sample_pair(delivery, "smp_001", category="alpha")
        _write_sample_pair(delivery, "smp_002", category="beta")
        _write_sample_pair(delivery, "smp_003", category="alpha")

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        try:
            counts = get_status_counts(session)
            assert counts.get("archived", 0) == 6  # 3 groups x 2 components
            assert len(list((archive / "alpha").iterdir())) == 4  # smp_001 + smp_003
            assert len(list((archive / "beta").iterdir())) == 2  # smp_002
        finally:
            session.close()

    def test_integrity_failure_blocks_group(self, tmp_path, db_url):
        """A tiny .txt fails min_size, so the group is never complete."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        json_path, txt_path = _write_sample_pair(delivery, "smp_bad")
        txt_path.write_text("x")  # overwrite with tiny content

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        try:
            txt = get_component_by_source_path(session, str(txt_path.resolve()))
            assert txt["status"] == FileStatus.INTEGRITY_FAILED

            # The .json should be WAITING — group never completes
            jsn = get_component_by_source_path(session, str(json_path.resolve()))
            assert jsn["status"] == FileStatus.WAITING

            # Nothing archived
            assert get_archive_count(session) == 0
        finally:
            session.close()

    def test_selection_rejects_group(self, tmp_path, db_url):
        """origin=None fails the has_keys selection → group skipped."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        _write_sample_pair(delivery, "smp_skip", origin=None)

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        try:
            txt = get_component_by_source_path(
                session, str((delivery / "smp_skip.txt").resolve())
            )
            assert txt["status"] == FileStatus.NOT_SELECTED
            assert get_archive_count(session) == 0
        finally:
            session.close()

    def test_incomplete_group_stays_waiting(self, tmp_path, db_url):
        """A lone .json with no .txt stays WAITING."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        start = datetime(2026, 3, 15, 12, 0, 0)
        stop = datetime(2026, 3, 15, 13, 0, 0)
        (delivery / "orphan.json").write_text(
            json.dumps(
                {
                    "start": start.isoformat(),
                    "stop": stop.isoformat(),
                    "category": "gamma",
                    "origin": "sensor-1",
                }
            )
        )

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        try:
            comp = get_component_by_source_path(
                session, str((delivery / "orphan.json").resolve())
            )
            assert comp["status"] == FileStatus.WAITING
            assert get_archive_count(session) == 0
        finally:
            session.close()

    def test_files_dropped_while_running(self, tmp_path, db_url):
        """Files arriving after the service starts are picked up by the watcher."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        # Start service with an empty delivery directory
        t = threading.Thread(target=svc.start, daemon=True)
        t.start()

        # Wait for the service to be ready
        time.sleep(0.5)

        # Now drop files — the watcher should detect them
        _write_sample_pair(delivery, "late_arrival", category="delta")

        # Wait for settle + processing
        time.sleep(SETTLE + 2.0)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        try:
            txt = get_component_by_source_path(
                session, str((delivery / "late_arrival.txt").resolve())
            )
            assert txt is not None
            assert txt["status"] == FileStatus.ARCHIVED

            archived = list((archive / "delta").iterdir())
            assert len(archived) == 2
        finally:
            session.close()


# ---------------------------------------------------------------------------
# Reconciliation integration tests
# ---------------------------------------------------------------------------


class TestReconcileDeliveryIntegration:
    """Test reconcile_delivery against a real directory + DB."""

    def test_new_files_detected(self, tmp_path, db_url):
        """Files on disk but not in DB are registered as new."""
        delivery = tmp_path / "delivery"
        delivery.mkdir()
        _write_sample_pair(delivery, "smp_001")

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        wc = WatchConfig(
            name="test-watch",
            path=delivery,
            rules="unused",
            archive="unused",
        )

        session = factory()
        stats = reconcile_delivery(session, wc)
        assert stats["new"] == 2  # .json + .txt
        assert stats["cleared"] == 0
        assert get_delivery_count(session) == 2
        session.close()

    def test_removed_files_cleared(self, tmp_path, db_url):
        """Files in DB but gone from disk are marked cleared."""
        delivery = tmp_path / "delivery"
        delivery.mkdir()
        f = delivery / "ephemeral.txt"
        f.write_text("temporary")

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        wc = WatchConfig(
            name="test-watch",
            path=delivery,
            rules="unused",
            archive="unused",
        )

        session = factory()

        # First reconcile — file is present
        stats = reconcile_delivery(session, wc)
        assert stats["new"] == 1
        assert get_delivery_count(session) == 1

        # Delete the file
        f.unlink()

        # Second reconcile — file is gone
        stats = reconcile_delivery(session, wc)
        assert stats["cleared"] == 1
        assert get_delivery_count(session) == 0
        session.close()

    def test_reconcile_requeues_non_archived(self, tmp_path, db_url):
        """Non-archived files are re-enqueued when an event_queue is provided."""
        delivery = tmp_path / "delivery"
        delivery.mkdir()
        _write_sample_pair(delivery, "smp_001")

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        wc = WatchConfig(
            name="test-watch",
            path=delivery,
            rules="unused",
            archive="unused",
        )

        from queue import Queue

        queue: Queue[FileEvent] = Queue()
        session = factory()
        stats = reconcile_delivery(session, wc, event_queue=queue)
        assert stats["requeued"] == 2
        assert queue.qsize() == 2
        session.close()

    def test_idempotent_reconcile(self, tmp_path, db_url):
        """Running reconcile twice with no changes produces no new/cleared."""
        delivery = tmp_path / "delivery"
        delivery.mkdir()
        _write_sample_pair(delivery, "smp_001")

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        wc = WatchConfig(
            name="test-watch",
            path=delivery,
            rules="unused",
            archive="unused",
        )

        session = factory()
        reconcile_delivery(session, wc)

        stats = reconcile_delivery(session, wc)
        assert stats["new"] == 0
        assert stats["cleared"] == 0
        session.close()


class TestReconcileArchiveIntegration:
    """Test reconcile_archive against a real archive directory + DB."""

    def test_orphaned_archive_files_registered(self, tmp_path, db_url):
        """Files in archive not in DB are registered as orphans."""
        archive_dir = tmp_path / "archive"
        (archive_dir / "alpha").mkdir(parents=True)
        (archive_dir / "alpha" / "data.txt").write_text("archived content")
        (archive_dir / "alpha" / "data.json").write_text("{}")

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination="{category}",
            )
        ]

        session = factory()
        stats = reconcile_archive(session, configs)
        assert stats["created"] == 2
        assert get_archive_count(session) == 2
        session.close()

    def test_existing_archive_records_found(self, tmp_path, db_url):
        """Files already tracked in DB are counted as found, not created."""
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        f = archive_dir / "known.txt"
        f.write_text("known content")
        path_str = str(f.resolve())

        engine = create_engine(db_url)
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)

        from carbonation.db.queries import record_component, update_component_status

        session = factory()
        cid = record_component(
            session,
            watch_name="test",
            filename="known.txt",
            source_path=path_str,
            status=FileStatus.ARCHIVED,
        )
        update_component_status(
            session,
            cid,
            FileStatus.ARCHIVED,
            archive_path=path_str,
        )
        session.commit()

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=".",
            )
        ]
        stats = reconcile_archive(session, configs)
        assert stats["found"] == 1
        assert stats["created"] == 0
        session.close()

    def test_full_cycle_service_then_reconcile(self, tmp_path, db_url):
        """Service archives files, then reconcile_archive finds them on disk."""
        svc, factory, delivery, archive = _build_service(tmp_path, db_url=db_url)

        _write_sample_pair(delivery, "smp_001", category="alpha")
        _write_sample_pair(delivery, "smp_002", category="beta")

        _run_service_briefly(svc, SETTLE + 2.0)

        # Verify the service archived everything
        session = factory()
        try:
            assert get_archive_count(session) == 4

            # reconcile_archive walks the archive tree. The DB tracks
            # components by their delivery source_path, while archive files
            # have different paths — so reconcile sees them as new orphans.
            configs = [
                ArchiveConfig(
                    name="test-archive",
                    base_path=archive,
                    destination="{category}",
                )
            ]
            stats = reconcile_archive(session, configs)
            # Archive files on disk are accounted for
            assert stats["found"] + stats["created"] == 4

            # Verify actual archive directory structure
            assert (archive / "alpha").is_dir()
            assert (archive / "beta").is_dir()
            assert len(list((archive / "alpha").iterdir())) == 2
            assert len(list((archive / "beta").iterdir())) == 2
        finally:
            session.close()


# ---------------------------------------------------------------------------
# Rules hot-reload integration tests
# ---------------------------------------------------------------------------


class TestRulesHotReload:
    """Test that rules.toml changes are picked up by the running service."""

    def test_reload_changes_selection(self, tmp_path, db_url):
        """Modify selection rules while running — new rules take effect."""
        svc, factory, delivery, archive = _build_service(
            tmp_path, db_url=db_url, rules_file=True
        )
        rules_path = tmp_path / "rules.toml"

        # Start service in background
        t = threading.Thread(target=svc.start, daemon=True)
        t.start()
        time.sleep(0.5)

        # Drop a file with origin=None — current rules require has_keys=["category","origin"]
        # so this should be NOT_SELECTED
        _write_sample_pair(delivery, "smp_before", origin=None, category="alpha")
        time.sleep(SETTLE + 1.5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_before.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.NOT_SELECTED
        session.close()

        # Now update rules to only require "category" (not "origin")
        _write_rules_toml(rules_path, has_keys='["category"]')

        # Wait for debounce + reload
        time.sleep(1.5)

        # Drop another file with origin=None — should now be ARCHIVED
        _write_sample_pair(delivery, "smp_after", origin=None, category="beta")
        time.sleep(SETTLE + 1.5)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_after.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_reload_rejects_invalid_rules(self, tmp_path, db_url):
        """Invalid rules.toml is rejected, service keeps using old rules."""
        svc, factory, delivery, archive = _build_service(
            tmp_path, db_url=db_url, rules_file=True
        )
        rules_path = tmp_path / "rules.toml"

        t = threading.Thread(target=svc.start, daemon=True)
        t.start()
        time.sleep(0.5)

        # Write invalid TOML
        rules_path.write_text("this is not [valid toml{{{")
        time.sleep(1.5)

        # Service should still work with old rules
        _write_sample_pair(delivery, "smp_ok", category="alpha")
        time.sleep(SETTLE + 1.5)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_ok.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_reload_rejects_missing_rule_set(self, tmp_path, db_url):
        """Rules file that drops a referenced rule set is rejected."""
        svc, factory, delivery, archive = _build_service(
            tmp_path, db_url=db_url, rules_file=True
        )
        rules_path = tmp_path / "rules.toml"

        t = threading.Thread(target=svc.start, daemon=True)
        t.start()
        time.sleep(0.5)

        # Write valid TOML but with a different rule set name
        rules_path.write_text(
            '[wrong-name]\n[[wrong-name.integrity]]\ntype = "min_size"\nvalue = 10\n'
        )
        time.sleep(1.5)

        # Service should still work with old rules
        _write_sample_pair(delivery, "smp_ok", category="alpha")
        time.sleep(SETTLE + 1.5)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_ok.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_reload_after_file_deleted_and_recreated(self, tmp_path, db_url):
        """Rules file deleted then recreated is picked up."""
        svc, factory, delivery, archive = _build_service(
            tmp_path, db_url=db_url, rules_file=True
        )
        rules_path = tmp_path / "rules.toml"

        t = threading.Thread(target=svc.start, daemon=True)
        t.start()
        time.sleep(0.5)

        rules_path.unlink()
        time.sleep(0.5)

        # Recreate with relaxed selection (only require "category")
        _write_rules_toml(rules_path, has_keys='["category"]')
        time.sleep(1.5)

        _write_sample_pair(delivery, "smp_recreated", origin=None, category="gamma")
        time.sleep(SETTLE + 1.5)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_recreated.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_rapid_modifications_debounced(self, tmp_path, db_url):
        """Rapid writes to rules.toml are debounced — only final version takes effect."""
        svc, factory, delivery, archive = _build_service(
            tmp_path, db_url=db_url, rules_file=True
        )
        rules_path = tmp_path / "rules.toml"

        t = threading.Thread(target=svc.start, daemon=True)
        t.start()
        time.sleep(0.5)

        for i in range(5):
            _write_rules_toml(rules_path, has_keys='["nonexistent_key"]')
        _write_rules_toml(rules_path, has_keys='["category"]')
        time.sleep(1.5)

        _write_sample_pair(delivery, "smp_rapid", origin=None, category="delta")
        time.sleep(SETTLE + 1.5)

        svc.stop()
        t.join(timeout=5)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_rapid.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()


# ---------------------------------------------------------------------------
# Archive action variants
# ---------------------------------------------------------------------------


class TestArchiveActions:
    """Test move and symlink archive actions end-to-end."""

    def test_move_action(self, tmp_path, db_url):
        """action=move removes source files after archiving."""
        svc, factory, delivery, archive = _build_service(
            tmp_path,
            db_url=db_url,
            archive_action="move",
        )
        _write_sample_pair(delivery, "smp_move", category="alpha")

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_move.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        assert not (delivery / "smp_move.txt").exists()
        assert not (delivery / "smp_move.json").exists()
        assert (archive / "alpha" / "smp_move.txt").exists()
        assert (archive / "alpha" / "smp_move.json").exists()
        session.close()

    @pytest.mark.skipif(
        sys.platform == "win32",
        reason="symlinks require elevated privileges on Windows",
    )
    def test_symlink_action(self, tmp_path, db_url):
        """action=symlink creates symlinks in the archive pointing to source."""
        svc, factory, delivery, archive = _build_service(
            tmp_path,
            db_url=db_url,
            archive_action="symlink",
        )
        _write_sample_pair(delivery, "smp_link", category="beta")

        _run_service_briefly(svc, SETTLE + 2.0)

        session = factory()
        comp = get_component_by_source_path(
            session, str((delivery / "smp_link.txt").resolve())
        )
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        assert (delivery / "smp_link.txt").exists()
        link = archive / "beta" / "smp_link.txt"
        assert link.is_symlink()
        assert link.resolve() == (delivery / "smp_link.txt").resolve()
        session.close()
