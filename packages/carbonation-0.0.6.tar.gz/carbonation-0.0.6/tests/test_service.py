"""Tests for the service module — _process_event_inner pipeline."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from carbonation.config import (
    AppConfig,
    ArchiveConfig,
    CompletenessConfig,
    IntegrityCheck,
    MetadataConfig,
    RuleSet,
    RulesConfig,
    SelectionRule,
    WatchConfig,
)
from carbonation.db.models import Base, FileStatus
from carbonation.db.queries import (
    get_component_by_source_path,
)
from carbonation.service import CarbonationService
from carbonation.watcher import FileEvent

from tests.conftest import TEST_PLUGIN


def _make_service(
    tmp_path: Path,
    *,
    integrity: list[IntegrityCheck] | None = None,
    completeness: CompletenessConfig | None = None,
    metadata: MetadataConfig | None = None,
    selection: list[SelectionRule] | None = None,
    archive_action: str = "copy",
    archive_dest: str | None = None,
) -> tuple[CarbonationService, sessionmaker]:
    """Build a minimal CarbonationService for unit testing."""
    delivery_dir = tmp_path / "delivery"
    delivery_dir.mkdir(exist_ok=True)
    archive_dir = tmp_path / "archive"
    archive_dir.mkdir(exist_ok=True)

    app_config = AppConfig(
        watch=[
            WatchConfig(
                name="test-watch",
                path=delivery_dir,
                rules="test-rules",
                archive="test-archive",
            ),
        ],
        archive=[
            ArchiveConfig(
                name="test-archive",
                destination=archive_dest or str(archive_dir),
                action=archive_action,
            ),
        ],
    )
    rules_config = RulesConfig(
        rule_sets={
            "test-rules": RuleSet(
                integrity=integrity or [],
                completeness=completeness,
                metadata=metadata,
                selection=selection or [],
            ),
        }
    )
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)

    svc = CarbonationService(app_config, rules_config, TEST_PLUGIN, engine, factory)
    return svc, factory


class TestProcessEventStandalone:
    """Tests for standalone file processing (no completeness)."""

    def test_happy_path_archives_file(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        assert comp["archive_path"] is not None
        session.close()

    def test_integrity_failure_marks_failed(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            integrity=[IntegrityCheck(type="min_size", value=10000)],
        )
        delivery = tmp_path / "delivery"
        f = delivery / "tiny.txt"
        f.write_text("x")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.INTEGRITY_FAILED
        assert "too small" in comp["error_message"].lower()
        session.close()

    def test_nonexistent_file_fails_integrity(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "ghost.txt"  # does not exist

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.INTEGRITY_FAILED
        session.close()

    def test_selection_rejection_skips(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            selection=[SelectionRule(has_keys=["nonexistent_key"])],
        )
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.NOT_SELECTED
        session.close()

    def test_unknown_watch_returns_early(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        f = tmp_path / "delivery" / "data.txt"
        f.write_text("content")

        event = FileEvent(watch_name="nonexistent-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        # No component should be recorded
        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is None
        session.close()

    def test_duplicate_event_skips_archived(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")
        event = FileEvent(watch_name="test-watch", path=f)

        # Process once
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Process again — should not fail
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Should still be archived
        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_missing_archive_config_fails(self, tmp_path):
        """If archive name doesn't match any config, components are marked FAILED."""
        delivery_dir = tmp_path / "delivery"
        delivery_dir.mkdir(exist_ok=True)

        app_config = AppConfig(
            watch=[
                WatchConfig(
                    name="test-watch",
                    path=delivery_dir,
                    rules="test-rules",
                    archive="nonexistent-archive",
                ),
            ],
            archive=[
                ArchiveConfig(
                    name="other-archive",
                    destination=str(tmp_path / "archive"),
                ),
            ],
        )
        rules_config = RulesConfig(rule_sets={"test-rules": RuleSet()})
        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)
        svc = CarbonationService(app_config, rules_config, TEST_PLUGIN, engine, factory)

        f = delivery_dir / "data.txt"
        f.write_text("content")
        event = FileEvent(watch_name="test-watch", path=f)

        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.FAILED
        assert "not found" in comp["error_message"].lower()
        session.close()


class TestProcessEventWithCompleteness:
    """Tests for group completeness handling."""

    def test_incomplete_group_waits(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
        )
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("data content")

        event = FileEvent(watch_name="test-watch", path=f_txt)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f_txt.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.WAITING
        session.close()

    def test_complete_group_archives_all(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
        )
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("text data content here")
        f_json = delivery / "sample_001.json"
        f_json.write_text('{"key": "value"}')

        # Process first component
        session = factory()
        svc._process_event_inner(
            session, FileEvent(watch_name="test-watch", path=f_txt)
        )
        session.commit()
        session.close()

        # Process second component — should complete the group
        session = factory()
        svc._process_event_inner(
            session, FileEvent(watch_name="test-watch", path=f_json)
        )
        session.commit()
        session.close()

        # Both should be archived
        session = factory()
        comp_txt = get_component_by_source_path(session, str(f_txt.resolve()))
        comp_json = get_component_by_source_path(session, str(f_json.resolve()))
        assert comp_txt["status"] == FileStatus.ARCHIVED
        assert comp_json["status"] == FileStatus.ARCHIVED
        session.close()


class TestExtractFailure:
    """Bug #1 / #12 (Phase 1b): a raising extract callable currently logs +
    swallows, leaves ``metadata = {}``, then proceeds to selection / routing
    / archive — silently archiving with no metadata. Worse, the group row
    has already been committed as ``complete=True`` inside the per-group
    lock, so the failure is unrecoverable through normal pipeline replay.

    Required behavior: extract failures must NOT result in ARCHIVED state
    with empty metadata. Components should land in RETRY_PENDING (or FAILED
    once retries are exhausted), and the group row must not be left in a
    state where reprocessing is impossible.
    """

    def _make_service_with_failing_extract(self, tmp_path):
        """Build a service whose extract callable raises."""

        def failing_extract(file_paths):
            raise RuntimeError("simulated plugin extract failure")

        return _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
            metadata=MetadataConfig(
                extract="failing", extract_callable=failing_extract
            ),
        )

    def test_extract_failure_does_not_archive_with_empty_metadata(self, tmp_path):
        svc, factory = self._make_service_with_failing_extract(tmp_path)
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("text data content here")
        f_json = delivery / "sample_001.json"
        f_json.write_text('{"key": "value"}')

        # Process both components to complete the group and trigger extract.
        for path in (f_txt, f_json):
            session = factory()
            svc._process_event_inner(
                session, FileEvent(watch_name="test-watch", path=path)
            )
            session.commit()
            session.close()

        session = factory()
        comp_txt = get_component_by_source_path(session, str(f_txt.resolve()))
        comp_json = get_component_by_source_path(session, str(f_json.resolve()))

        # Components must NOT be ARCHIVED — extract failed.
        assert comp_txt["status"] != FileStatus.ARCHIVED, (
            f"txt component archived despite extract failure: status={comp_txt['status']}"
        )
        assert comp_json["status"] != FileStatus.ARCHIVED, (
            f"json component archived despite extract failure: status={comp_json['status']}"
        )

        # Acceptable terminal/transitional states: RETRY_PENDING, FAILED, WAITING.
        # NOT_SELECTED would also be a bug — selection should not run on missing metadata.
        assert comp_txt["status"] in (
            FileStatus.RETRY_PENDING,
            FileStatus.FAILED,
            FileStatus.WAITING,
        ), f"unexpected status after extract failure: {comp_txt['status']}"
        session.close()

    def test_extract_failure_leaves_group_recoverable(self, tmp_path):
        """After extract failure, the group should be reprocessable.

        Concretely: if extract is fixed and the group is re-driven, the
        pipeline should successfully populate metadata. The current bug
        commits ``complete=True`` before extract runs and ARCHIVEs with
        empty metadata, so a retry sees ARCHIVED components and exits
        early — the metadata stays NULL forever.

        This test asserts on the file group's ``label`` column to catch
        the bug rather than relying on component status (which is also
        ARCHIVED under the bug, just with bad metadata).
        """
        from sqlalchemy import select

        from carbonation.db.models import get_file_model

        attempts = {"count": 0}

        def flaky_extract(file_paths):
            attempts["count"] += 1
            if attempts["count"] == 1:
                raise RuntimeError("first attempt fails")
            return {"label": "recovered"}

        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
            metadata=MetadataConfig(extract="flaky", extract_callable=flaky_extract),
        )

        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("text data content here")
        f_json = delivery / "sample_001.json"
        f_json.write_text('{"key": "value"}')

        # First pass: completes the group; extract raises on the second event.
        for path in (f_txt, f_json):
            session = factory()
            svc._process_event_inner(
                session, FileEvent(watch_name="test-watch", path=path)
            )
            session.commit()
            session.close()

        # Re-drive the group. After the fix, extract re-runs (succeeds this
        # time) and writes the recovered metadata.
        session = factory()
        svc._process_event_inner(
            session, FileEvent(watch_name="test-watch", path=f_json)
        )
        session.commit()
        session.close()

        # The file group's metadata must reflect the successful retry.
        session = factory()
        FileModel = get_file_model()
        row = session.execute(
            select(FileModel.label).where(FileModel.group_key == "sample_001")
        ).scalar_one()
        assert row == "recovered", (
            f"label was not populated after retry — got {row!r}. "
            "Group was committed complete before extract; retry exited early."
        )
        session.close()


class TestPeriodicReconcileResilience:
    """Bug #10 (Phase 2e): the periodic reconcile timer would die
    permanently if any of the inner checks (timeout / retry / watch
    health) raised, because the rescheduling line lived after the failing
    code path. Wrapping each in try/except and moving rescheduling into a
    finally block keeps the timer alive across transient errors.
    """

    def _capture_reschedule(self, svc):
        """Stub _schedule_reconciliation to record calls without starting a timer."""
        scheduled: list[bool] = []
        svc._schedule_reconciliation = lambda: scheduled.append(True)  # type: ignore[method-assign]
        return scheduled

    def test_reschedules_when_retry_check_raises(self, tmp_path, monkeypatch):
        svc, _ = _make_service(tmp_path)
        scheduled = self._capture_reschedule(svc)

        def boom():
            raise RuntimeError("simulated retry-check failure")

        monkeypatch.setattr(svc, "_check_pending_retries", boom)
        svc._periodic_reconcile()
        assert scheduled == [True], (
            "reconcile timer must be rescheduled even when an inner check fails"
        )

    def test_reschedules_when_watch_health_raises(self, tmp_path, monkeypatch):
        svc, _ = _make_service(tmp_path)
        scheduled = self._capture_reschedule(svc)

        def boom():
            raise RuntimeError("simulated watch-health failure")

        monkeypatch.setattr(svc, "_check_watch_health", boom)
        svc._periodic_reconcile()
        assert scheduled == [True]

    def test_reschedules_when_completeness_timeout_raises(self, tmp_path, monkeypatch):
        svc, _ = _make_service(tmp_path)
        scheduled = self._capture_reschedule(svc)

        def boom():
            raise RuntimeError("simulated timeout failure")

        monkeypatch.setattr(svc, "_check_completeness_timeouts", boom)
        svc._periodic_reconcile()
        assert scheduled == [True]


class TestRulesFileHandlerEvents:
    """Bug #9 (Phase 2d): the rules-file watcher only handled
    ``on_modified``, so atomic-replace edits (vim with backup, IDE
    save-to-temp-then-rename, ``mv``) silently bypassed hot-reload.
    The handler must also react to ``on_created`` and ``on_moved``.
    """

    def _make_handler(self, rules_path):
        from carbonation.service import _RulesFileHandler

        # Use a tiny debounce so the test doesn't sleep forever.
        h = _RulesFileHandler(rules_path, callback=lambda: callbacks.append(1))
        callbacks: list[int] = []
        # Patch debounce to fire near-immediately.
        original = h._schedule_reload

        def fast_schedule():
            import threading

            with h._lock:
                if h._timer is not None:
                    h._timer.cancel()
                h._timer = threading.Timer(0.01, h._callback)
                h._timer.daemon = True
                h._timer.start()

        h._schedule_reload = fast_schedule  # type: ignore[method-assign]
        _ = original  # silence unused warning
        return h, callbacks

    def test_on_created_triggers_reload(self, tmp_path):
        import time

        from watchdog.events import FileCreatedEvent

        rules_path = tmp_path / "rules.toml"
        rules_path.write_text("# rules")
        h, callbacks = self._make_handler(rules_path)

        h.on_created(FileCreatedEvent(str(rules_path)))
        time.sleep(0.1)
        assert callbacks == [1]

    def test_on_moved_dest_triggers_reload(self, tmp_path):
        import time

        from watchdog.events import FileMovedEvent

        rules_path = tmp_path / "rules.toml"
        rules_path.write_text("# rules")
        h, callbacks = self._make_handler(rules_path)

        # Atomic replace: an editor wrote rules.toml.tmp and renamed it.
        h.on_moved(FileMovedEvent(str(tmp_path / "rules.toml.tmp"), str(rules_path)))
        time.sleep(0.1)
        assert callbacks == [1]

    def test_unrelated_path_ignored(self, tmp_path):
        import time

        from watchdog.events import FileCreatedEvent, FileModifiedEvent

        rules_path = tmp_path / "rules.toml"
        rules_path.write_text("# rules")
        other = tmp_path / "other.toml"
        other.write_text("# other")
        h, callbacks = self._make_handler(rules_path)

        h.on_created(FileCreatedEvent(str(other)))
        h.on_modified(FileModifiedEvent(str(other)))
        time.sleep(0.1)
        assert callbacks == []


class TestStatusCountsCache:
    """Bug #16 (Phase 3b): heartbeat used to issue a full-table
    ``GROUP BY status`` every tick (default 60s). At 150k+ rows this is
    the dominant cost. Counts are now cached and recomputed only every
    ``service.stats_recompute_every`` ticks.
    """

    def test_first_tick_computes(self, tmp_path, monkeypatch):
        svc, _ = _make_service(tmp_path)
        calls = {"n": 0}

        from carbonation import service as service_mod

        original = service_mod.get_status_counts

        def counting(session):
            calls["n"] += 1
            return original(session)

        monkeypatch.setattr(service_mod, "get_status_counts", counting)

        svc._update_heartbeat_and_stats()
        assert calls["n"] == 1

    def test_subsequent_ticks_use_cache(self, tmp_path, monkeypatch):
        """With stats_recompute_every=10, ticks 2..10 serve cached counts."""
        svc, _ = _make_service(tmp_path)
        svc.app_config.service.stats_recompute_every = 10

        calls = {"n": 0}
        from carbonation import service as service_mod

        original = service_mod.get_status_counts

        def counting(session):
            calls["n"] += 1
            return original(session)

        monkeypatch.setattr(service_mod, "get_status_counts", counting)

        # 10 consecutive heartbeats should trigger exactly one GROUP BY.
        for _ in range(10):
            svc._update_heartbeat_and_stats()
        assert calls["n"] == 1

        # The 11th tick wraps the modulus and recomputes.
        svc._update_heartbeat_and_stats()
        assert calls["n"] == 2

    def test_recompute_every_of_1_always_recomputes(self, tmp_path, monkeypatch):
        """Operators can opt out of caching with stats_recompute_every=1."""
        svc, _ = _make_service(tmp_path)
        svc.app_config.service.stats_recompute_every = 1

        calls = {"n": 0}
        from carbonation import service as service_mod

        original = service_mod.get_status_counts

        def counting(session):
            calls["n"] += 1
            return original(session)

        monkeypatch.setattr(service_mod, "get_status_counts", counting)

        for _ in range(3):
            svc._update_heartbeat_and_stats()
        assert calls["n"] == 3


class TestGroupLockRefcount:
    """Bug #6 (Phase 2a): per-group locks were stored in a
    ``WeakValueDictionary``, which could let the entry be garbage-collected
    between two workers asking for the same key — defeating mutual
    exclusion on completeness checks. The refcounted replacement must
    return the *same* lock instance to concurrent acquirers and clean up
    the entry only after the last release.
    """

    def test_concurrent_acquirers_share_lock_instance(self, tmp_path):
        import gc

        svc, _ = _make_service(tmp_path)

        with svc._group_lock("k") as a:
            # Force GC while holding the lock — the entry must survive.
            gc.collect()
            with svc._group_lock("k") as b:
                assert a is b, "concurrent acquirers got different Lock instances"

    def test_entry_removed_after_last_release(self, tmp_path):
        svc, _ = _make_service(tmp_path)

        with svc._group_lock("k"):
            assert "k" in svc._group_locks
            assert svc._group_locks["k"].refs == 1
            with svc._group_lock("k"):
                assert svc._group_locks["k"].refs == 2
            assert svc._group_locks["k"].refs == 1

        assert "k" not in svc._group_locks, "entry leaked after last release"

    def test_entry_removed_on_exception(self, tmp_path):
        svc, _ = _make_service(tmp_path)

        with pytest.raises(RuntimeError):
            with svc._group_lock("k"):
                raise RuntimeError("boom")

        assert "k" not in svc._group_locks, "entry leaked when caller raised"

    def test_pipeline_releases_lock_on_normal_completion(self, tmp_path):
        """End-to-end: after _process_event_inner finishes, no lock entries linger."""
        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
        )
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("text data content here")
        f_json = delivery / "sample_001.json"
        f_json.write_text('{"key": "value"}')

        for path in (f_txt, f_json):
            session = factory()
            svc._process_event_inner(
                session, FileEvent(watch_name="test-watch", path=path)
            )
            session.commit()
            session.close()

        assert svc._group_locks == {}, (
            f"lock entries leaked after pipeline: {svc._group_locks!r}"
        )


class TestCompletenessTimeouts:
    """Tests for _check_completeness_timeouts."""

    def _make_service_with_timeout(
        self,
        tmp_path,
        *,
        on_timeout: str = "warn",
        timeout_minutes: int = 120,
    ):
        """Build a service with completeness + timeout config."""
        delivery = tmp_path / "delivery"
        delivery.mkdir(exist_ok=True)
        archive = tmp_path / "archive"
        archive.mkdir(exist_ok=True)

        app_config = AppConfig(
            watch=[
                WatchConfig(
                    name="test-watch",
                    path=delivery,
                    rules="test-rules",
                    archive="test-archive",
                ),
            ],
            archive=[
                ArchiveConfig(
                    name="test-archive",
                    destination=str(archive),
                ),
            ],
        )
        rules_config = RulesConfig(
            rule_sets={
                "test-rules": RuleSet(
                    completeness=CompletenessConfig(
                        group_by="stem",
                        expected_extensions=[".txt", ".json"],
                        timeout_minutes=timeout_minutes,
                        on_timeout=on_timeout,
                    ),
                ),
            }
        )
        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)
        svc = CarbonationService(app_config, rules_config, TEST_PLUGIN, engine, factory)
        return svc, factory, delivery

    def _create_incomplete_group(self, svc, factory, delivery):
        """Create an incomplete group (only .txt, no .json) and backdate it."""
        from datetime import datetime, timedelta, timezone

        f = delivery / "old_signal.txt"
        f.write_text("some data content here")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()

        # Backdate the group's created_at to trigger timeout
        from carbonation.db.models import get_file_model

        FileModel = get_file_model()
        from sqlalchemy import update

        old_time = datetime.now(timezone.utc) - timedelta(hours=24)
        session.execute(update(FileModel).values(created_at=old_time))
        session.commit()
        session.close()
        return f

    def test_warn_timeout_keeps_waiting(self, tmp_path):
        """on_timeout=warn logs but doesn't change component status."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path,
            on_timeout="warn",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.WAITING
        session.close()

    def test_skip_timeout_marks_timed_out(self, tmp_path):
        """on_timeout=skip marks all group components as TIMED_OUT."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path,
            on_timeout="skip",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.TIMED_OUT
        session.close()

    def test_archive_partial_requeues(self, tmp_path):
        """on_timeout=archive_partial re-enqueues components for archival."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path,
            on_timeout="archive_partial",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        # Event should be re-enqueued
        assert not svc.event_queue.empty()
        event = svc.event_queue.get_nowait()
        assert event.path == f

    def test_no_timeout_if_not_expired(self, tmp_path):
        """Groups within timeout_minutes are not affected."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path,
            on_timeout="skip",
            timeout_minutes=99999,
        )
        # Create group but DON'T backdate — it's fresh
        f = delivery / "fresh_signal.txt"
        f.write_text("some data content here")
        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.WAITING  # not skipped
        session.close()


class TestRetryLogic:
    """Tests for archival retry behavior."""

    def test_archive_failure_marks_retry_pending(self, tmp_path):
        """First failure marks component RETRY_PENDING, not FAILED."""
        # Point archive at a non-writable destination
        svc, factory = _make_service(
            tmp_path,
            archive_dest=str(tmp_path / "nonexistent" / "deep" / "path"),
        )
        # Disable dir creation to force failure
        svc._archive_by_name["test-archive"].create_directories = False

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.RETRY_PENDING
        session.close()

    def test_max_retries_marks_failed(self, tmp_path):
        """After max_retries, component is marked FAILED."""
        svc, factory = _make_service(tmp_path)
        svc.app_config.service.max_retries = 2
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(
            tmp_path / "nonexistent" / "path"
        )

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")
        event = FileEvent(watch_name="test-watch", path=f)

        # Simulate: fail → periodic retry (increments count) → fail → retry → fail → FAILED
        for i in range(3):
            session = factory()
            svc._process_event_inner(session, event)
            session.commit()
            session.close()
            # Simulate periodic checker incrementing retry_count
            if i < 2:
                from carbonation.db.queries import mark_for_retry

                session = factory()
                comp = get_component_by_source_path(session, str(f.resolve()))
                mark_for_retry(session, comp["id"])
                session.commit()
                session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.FAILED
        session.close()

    def test_check_pending_retries_enqueues(self, tmp_path):
        """_check_pending_retries re-enqueues RETRY_PENDING components."""
        svc, factory = _make_service(tmp_path)
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(tmp_path / "nonexistent")

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")

        # Process once to get RETRY_PENDING
        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Clear the queue
        while not svc.event_queue.empty():
            svc.event_queue.get_nowait()

        # Check retries should re-enqueue
        svc._check_pending_retries()
        assert not svc.event_queue.empty()


class TestClaimRetryPending:
    """Bug #8 (Phase 2c): the periodic retry checker used to do
    SELECT-then-loop-UPDATE without rechecking the status, which let a
    concurrent ``reset_failed_for_retry`` (manual retry) be silently
    overwritten and double-enqueued. The atomic claim must return only
    rows it actually updated.
    """

    def test_returns_first_time_retries(self, tmp_path):
        """RETRY_PENDING with last_retry_at IS NULL is claimed."""
        from datetime import datetime, timezone

        from carbonation.db.queries import claim_retry_pending

        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(tmp_path / "nope")

        # Drive a failure -> RETRY_PENDING with last_retry_at=NULL.
        session = factory()
        svc._process_event_inner(session, FileEvent("test-watch", f))
        session.commit()
        session.close()

        session = factory()
        try:
            claimed = claim_retry_pending(session, datetime.now(timezone.utc))
            assert len(claimed) == 1
            session.commit()
        finally:
            session.close()

    def test_recheck_in_update_skips_status_changers(self, tmp_path):
        """A row that was just claimed should not be re-claimed on the
        very next call: the new ``last_retry_at`` is fresher than the
        retry-delay cutoff, so the ``eligible`` predicate excludes it.
        This mirrors the real service loop, which computes
        ``cutoff = now - retry_delay``.
        """
        from datetime import datetime, timedelta, timezone

        from carbonation.db.queries import (
            claim_retry_pending,
            get_component_by_source_path,
        )

        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(tmp_path / "nope")

        session = factory()
        svc._process_event_inner(session, FileEvent("test-watch", f))
        session.commit()
        session.close()

        # Match the real _check_pending_retries contract: cutoff is in the
        # past by a retry_delay. A just-claimed row (last_retry_at = now)
        # must therefore NOT appear eligible on the next call.
        retry_delay = timedelta(minutes=30)

        session = factory()
        try:
            claim_retry_pending(session, datetime.now(timezone.utc) - retry_delay)
            session.commit()
        finally:
            session.close()

        session = factory()
        try:
            second = claim_retry_pending(
                session, datetime.now(timezone.utc) - retry_delay
            )
            assert second == []
            session.commit()
        finally:
            session.close()

        # Sanity: retry_count incremented exactly once.
        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["retry_count"] == 1
        session.close()
