"""Tests for rules evaluation engine."""

from __future__ import annotations

from pathlib import Path


from carbonation.config import (
    CompletenessConfig,
    IntegrityCheck,
    RoutingRule,
    SelectionRule,
)
from carbonation.rules import (
    check_completeness,
    check_integrity,
    evaluate_selection,
    resolve_group_key,
    resolve_routing,
)


class TestCheckIntegrity:
    def test_passes_valid_file(self, tmp_path: Path):
        f = tmp_path / "data.csv"
        f.write_text("x" * 100)
        checks = [IntegrityCheck(type="min_size", value=50)]
        passed, error = check_integrity(f, checks)
        assert passed is True
        assert error is None

    def test_fails_too_small(self, tmp_path: Path):
        f = tmp_path / "tiny.csv"
        f.write_text("x")
        checks = [IntegrityCheck(type="min_size", value=100)]
        passed, error = check_integrity(f, checks)
        assert passed is False
        assert "too small" in error.lower()

    def test_fails_nonexistent(self, tmp_path: Path):
        f = tmp_path / "missing.csv"
        checks = []
        passed, error = check_integrity(f, checks)
        assert passed is False
        assert "does not exist" in error.lower()

    def test_passes_no_checks(self, tmp_path: Path):
        f = tmp_path / "data.csv"
        f.write_text("hello")
        passed, error = check_integrity(f, [])
        assert passed is True

    def test_multiple_checks_all_pass(self, tmp_path: Path):
        f = tmp_path / "data.csv"
        f.write_text("x" * 200)
        checks = [
            IntegrityCheck(type="min_size", value=100),
            IntegrityCheck(type="min_size", value=50),
        ]
        passed, error = check_integrity(f, checks)
        assert passed is True

    def test_multiple_checks_one_fails(self, tmp_path: Path):
        f = tmp_path / "data.csv"
        f.write_text("x" * 75)
        checks = [
            IntegrityCheck(type="min_size", value=50),
            IntegrityCheck(type="min_size", value=100),
        ]
        passed, error = check_integrity(f, checks)
        assert passed is False


class TestResolveGroupKey:
    def test_stem_grouping(self, tmp_path: Path):
        f = tmp_path / "sample_001.csv"
        f.write_text("data")
        comp = CompletenessConfig(
            group_by="stem", expected_extensions=[".csv", ".json"]
        )
        key = resolve_group_key(f, comp)
        assert key == "sample_001"

    def test_no_completeness(self, tmp_path: Path):
        f = tmp_path / "standalone.csv"
        f.write_text("data")
        key = resolve_group_key(f, None)
        assert key is None


class TestCheckCompleteness:
    def test_complete_group(self, tmp_path: Path):
        paths = [tmp_path / "sig.csv", tmp_path / "sig.json"]
        for p in paths:
            p.write_text("data")
        result = check_completeness("sig", "test", [".csv", ".json"], paths)
        assert result is True

    def test_incomplete_group(self, tmp_path: Path):
        paths = [tmp_path / "sig.csv"]
        for p in paths:
            p.write_text("data")
        result = check_completeness("sig", "test", [".csv", ".json"], paths)
        assert result is False

    def test_extra_extensions_ok(self, tmp_path: Path):
        paths = [
            tmp_path / "sig.csv",
            tmp_path / "sig.json",
            tmp_path / "sig.log",
        ]
        for p in paths:
            p.write_text("data")
        result = check_completeness("sig", "test", [".csv", ".json"], paths)
        assert result is True


class TestEvaluateSelection:
    def test_no_rules_accepts(self):
        assert evaluate_selection({"a": 1}, []) is True

    def test_has_keys_passes(self):
        rule = SelectionRule(has_keys=["category", "origin"])
        metadata = {"category": "alpha", "origin": "sensor-1"}
        assert evaluate_selection(metadata, [rule]) is True

    def test_has_keys_fails_missing(self):
        rule = SelectionRule(has_keys=["category", "origin"])
        metadata = {"category": "alpha"}
        assert evaluate_selection(metadata, [rule]) is False

    def test_has_keys_fails_none_value(self):
        rule = SelectionRule(has_keys=["category", "origin"])
        metadata = {"category": "alpha", "origin": None}
        assert evaluate_selection(metadata, [rule]) is False

    def test_field_matches_passes(self):
        rule = SelectionRule(field="category", matches=["^alpha", "^beta"])
        assert evaluate_selection({"category": "alpha-1"}, [rule]) is True
        assert evaluate_selection({"category": "beta-2"}, [rule]) is True

    def test_field_matches_fails(self):
        rule = SelectionRule(field="category", matches=["^alpha", "^beta"])
        assert evaluate_selection({"category": "gamma"}, [rule]) is False

    def test_field_matches_none_value(self):
        rule = SelectionRule(field="category", matches=["^alpha"])
        assert evaluate_selection({"category": None}, [rule]) is False

    def test_or_logic_any_passes(self):
        """Multiple rules are ORed — any passing is enough."""
        rule1 = SelectionRule(has_keys=["missing_key"])
        rule2 = SelectionRule(has_keys=["category"])
        metadata = {"category": "alpha"}
        assert evaluate_selection(metadata, [rule1, rule2]) is True

    def test_or_logic_none_pass(self):
        rule1 = SelectionRule(has_keys=["missing1"])
        rule2 = SelectionRule(has_keys=["missing2"])
        metadata = {"category": "alpha"}
        assert evaluate_selection(metadata, [rule1, rule2]) is False

    def test_plugin_selection(self):
        """A SelectionRule with a resolved callable runs at evaluate time."""

        def is_good(*, metadata, **kwargs):
            return metadata.get("quality", 0) > kwargs.get("threshold", 0.5)

        rule = SelectionRule(
            type="plugin",
            function="is_good",
            function_callable=is_good,
            kwargs={"threshold": 0.5},
        )
        assert evaluate_selection({"quality": 0.9}, [rule]) is True
        assert evaluate_selection({"quality": 0.1}, [rule]) is False


class TestResolveRouting:
    def test_default_archive(self):
        result = resolve_routing({}, "data.csv", [], "default-archive")
        assert result == "default-archive"

    def test_glob_match(self):
        rules = [RoutingRule(match="*.dat", archive="dat-archive")]
        result = resolve_routing({}, "output.dat", rules, "default")
        assert result == "dat-archive"

    def test_glob_no_match(self):
        rules = [RoutingRule(match="*.dat", archive="dat-archive")]
        result = resolve_routing({}, "output.csv", rules, "default")
        assert result == "default"

    def test_first_match_wins(self):
        rules = [
            RoutingRule(match="*.csv", archive="csv-archive"),
            RoutingRule(match="*", archive="catch-all"),
        ]
        result = resolve_routing({}, "data.csv", rules, "default")
        assert result == "csv-archive"
