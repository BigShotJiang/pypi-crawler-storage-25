"""Tests for config loading and duration parsing."""

from __future__ import annotations

from pathlib import Path

import pytest

from carbonation.config import (
    load_app_config,
    load_rules_config,
    parse_duration,
)
from carbonation.exceptions import ConfigError


class TestParseDuration:
    def test_seconds(self):
        assert parse_duration("5s") == 5.0

    def test_minutes(self):
        assert parse_duration("1m") == 60.0

    def test_hours(self):
        assert parse_duration("24h") == 86400.0

    def test_days(self):
        assert parse_duration("7d") == 604800.0

    def test_float_amount(self):
        assert parse_duration("1.5h") == 5400.0

    def test_whitespace(self):
        assert parse_duration("  5s  ") == 5.0

    def test_invalid_unit(self):
        with pytest.raises(ConfigError, match="Invalid duration"):
            parse_duration("5x")

    def test_empty_string(self):
        with pytest.raises(ConfigError, match="Invalid duration"):
            parse_duration("")

    def test_no_unit(self):
        with pytest.raises(ConfigError, match="Invalid duration"):
            parse_duration("100")

    def test_negative_not_supported(self):
        with pytest.raises(ConfigError, match="Invalid duration"):
            parse_duration("-5s")

    def test_max_duration_365d(self):
        assert parse_duration("365d") == 365 * 86400.0

    def test_exceeds_max_duration(self):
        with pytest.raises(ConfigError, match="too large"):
            parse_duration("366d")

    def test_large_hours_exceeds_max(self):
        with pytest.raises(ConfigError, match="too large"):
            parse_duration("9000h")

    def test_zero_rejected(self):
        """Bug #4a (Phase 4): zero durations produced tight timer loops."""
        with pytest.raises(ConfigError, match="must be positive"):
            parse_duration("0s")

    def test_zero_with_other_units_rejected(self):
        with pytest.raises(ConfigError, match="must be positive"):
            parse_duration("0h")


class TestLoggingConfigLevel:
    """Bug #4b (Phase 4): ``LoggingConfig.level`` used to accept any string
    and pass it through to loguru, which would either accept a bogus level
    silently or raise later at log time. Now validated at config-load.
    """

    def test_valid_level_passes(self):
        from carbonation.config import LoggingConfig

        cfg = LoggingConfig(level="DEBUG")
        assert cfg.level == "DEBUG"

    def test_lowercase_normalized(self):
        from carbonation.config import LoggingConfig

        cfg = LoggingConfig(level="warning")
        assert cfg.level == "WARNING"

    def test_invalid_level_rejected(self):
        from carbonation.config import LoggingConfig

        with pytest.raises(Exception, match="level must be one of"):
            LoggingConfig(level="BANANA")


class TestAppConfigDuplicateNames:
    """Bug #4c (Phase 4): duplicate watch/archive names silently overwrote
    each other in the service's lookup dicts. Rejected at config-load now.
    """

    def _minimal_watch(self, name, path):
        from carbonation.config import WatchConfig

        return WatchConfig(name=name, path=path, rules="r", archive="a")

    def _minimal_archive(self, name):
        from carbonation.config import ArchiveConfig

        return ArchiveConfig(name=name, destination="/archive")

    def test_duplicate_watch_names_rejected(self, tmp_path):
        from carbonation.config import AppConfig

        with pytest.raises(Exception, match="Duplicate watch names"):
            AppConfig(
                watch=[
                    self._minimal_watch("dup", tmp_path),
                    self._minimal_watch("dup", tmp_path),
                ],
                archive=[self._minimal_archive("a")],
            )

    def test_duplicate_archive_names_rejected(self, tmp_path):
        from carbonation.config import AppConfig

        with pytest.raises(Exception, match="Duplicate archive names"):
            AppConfig(
                watch=[self._minimal_watch("w", tmp_path)],
                archive=[
                    self._minimal_archive("dup"),
                    self._minimal_archive("dup"),
                ],
            )


class TestSelectionRuleRequiresCondition:
    """Bug #4d (Phase 4): a selection rule with no configured condition
    (missing ``type='plugin'`` or an empty ``has_keys=[]``) used to
    evaluate as "always pass". Rejected at config-load now.
    """

    def test_empty_rule_rejected(self):
        from carbonation.config import SelectionRule

        with pytest.raises(Exception, match="no condition"):
            SelectionRule()

    def test_empty_has_keys_rejected(self):
        from carbonation.config import SelectionRule

        with pytest.raises(Exception, match="no condition"):
            SelectionRule(has_keys=[])

    def test_kwargs_only_rejected(self):
        """Typo: user forgot type='plugin' but set kwargs."""
        from carbonation.config import SelectionRule

        with pytest.raises(Exception, match="no condition"):
            SelectionRule(kwargs={"threshold": 0.5})

    def test_has_keys_accepted(self):
        from carbonation.config import SelectionRule

        rule = SelectionRule(has_keys=["category"])
        assert rule.has_keys == ["category"]

    def test_field_matches_accepted(self):
        from carbonation.config import SelectionRule

        rule = SelectionRule(field="category", matches=["alpha"])
        assert rule.field == "category"

    def test_plugin_accepted(self):
        from carbonation.config import SelectionRule

        rule = SelectionRule(type="plugin", function="my_check")
        assert rule.type == "plugin"


class TestLoadAppConfig:
    def test_loads_valid_config(self, tmp_config: Path):
        config = load_app_config(tmp_config)
        assert config.service.poll_interval == "5s"
        assert config.service.reconcile_interval == "1h"
        assert len(config.watch) == 1
        assert config.watch[0].name == "test-watch"
        assert len(config.archive) == 1
        assert config.archive[0].name == "test-archive"

    def test_resolves_relative_paths(self, tmp_config: Path):
        config = load_app_config(tmp_config)
        base_dir = tmp_config.parent
        assert config.rules.file == (base_dir / "rules.toml").resolve()
        assert config.plugins.package == "tests._test_plugin"
        assert config.watch[0].path == (base_dir / "delivery").resolve()

    def test_resolves_sqlite_relative_path(self, tmp_config: Path):
        config = load_app_config(tmp_config)
        # name should be resolved to an absolute path
        assert Path(config.database.name).is_absolute()
        # url property should produce a valid SQLite URL
        assert config.database.url.startswith("sqlite:///")

    def test_defaults_applied(self, tmp_path: Path):
        """Minimal config with only required fields."""
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[minimal]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            "[[watch]]\n"
            'name = "w"\n'
            'path = "."\n'
            'rules = "minimal"\n'
            'archive = "a"\n\n'
            "[[archive]]\n"
            'name = "a"\n'
            'destination = "/tmp/archive"\n'
        )

        config = load_app_config(config_file)
        assert config.service.poll_interval == "5s"
        assert config.service.workers == 4
        assert config.database.drivername == "sqlite"
        assert config.database.echo is False
        assert config.logging.level == "INFO"

    def test_invalid_duration_rejected(self, tmp_path: Path):
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[service]\npoll_interval = "bad"\n\n'
            '[rules]\nfile = "r.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        with pytest.raises(Exception):  # pydantic ValidationError wraps ConfigError
            load_app_config(config_file)

    def test_invalid_archive_action_rejected(self, tmp_path: Path):
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "r.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\naction = "delete"\n'
        )
        with pytest.raises(Exception):
            load_app_config(config_file)

    def test_invalid_file_mode_rejected(self, tmp_path: Path):
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "r.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\nfile_mode = 0o777\n'
        )
        with pytest.raises(Exception, match="not allowed"):
            load_app_config(config_file)

    def test_invalid_dir_mode_rejected(self, tmp_path: Path):
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "r.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\ndir_mode = 0o440\n'
        )
        with pytest.raises(Exception, match="not allowed"):
            load_app_config(config_file)

    def test_valid_modes_accepted(self, tmp_path: Path):
        from carbonation.config import ArchiveConfig

        # All allowed modes should pass validation
        for mode in [0o600, 0o640, 0o644, 0o660, 0o666, 0o440, 0o444]:
            cfg = ArchiveConfig(name="a", destination="/tmp", file_mode=mode)
            assert cfg.file_mode == mode
        for mode in [0o700, 0o750, 0o755, 0o770, 0o777]:
            cfg = ArchiveConfig(name="a", destination="/tmp", dir_mode=mode)
            assert cfg.dir_mode == mode

    def test_missing_config_file(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            load_app_config(tmp_path / "nonexistent.toml")

    def test_watch_patterns_optional(self, tmp_config: Path):
        config = load_app_config(tmp_config)
        assert config.watch[0].patterns is None

    def test_duration_properties(self, tmp_config: Path):
        config = load_app_config(tmp_config)
        assert config.service.poll_interval_seconds == 5.0
        assert config.service.reconcile_interval_seconds == 3600.0


class TestLoadRulesConfig:
    def test_loads_valid_rules(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            "[my-rules]\n"
            "[[my-rules.integrity]]\n"
            'type = "min_size"\n'
            "value = 100\n"
            "\n"
            "[my-rules.completeness]\n"
            'group_by = "stem"\n'
            'expected_extensions = [".csv", ".json"]\n'
            "timeout_minutes = 60\n"
            'on_timeout = "warn"\n'
            "\n"
            "[my-rules.metadata]\n"
            'extract = "my_model"\n'
            "\n"
            "[[my-rules.selection]]\n"
            'has_keys = ["category"]\n'
            "\n"
            "[[my-rules.selection]]\n"
            'field = "category"\n'
            'matches = ["^alpha"]\n'
            "\n"
            "[[my-rules.routing]]\n"
            'match = "*.dat"\n'
            'archive = "secondary"\n'
        )

        rules = load_rules_config(rules_file)
        assert "my-rules" in rules.rule_sets
        rs = rules.rule_sets["my-rules"]
        assert len(rs.integrity) == 1
        assert rs.integrity[0].type == "min_size"
        assert rs.integrity[0].value == 100
        assert rs.completeness is not None
        assert rs.completeness.group_by == "stem"
        assert rs.completeness.expected_extensions == [".csv", ".json"]
        assert rs.completeness.on_timeout == "warn"
        assert rs.metadata is not None
        assert rs.metadata.extract == "my_model"
        assert len(rs.selection) == 2
        assert rs.selection[0].has_keys == ["category"]
        assert rs.selection[1].field == "category"
        assert rs.selection[1].matches == ["^alpha"]
        assert len(rs.routing) == 1
        assert rs.routing[0].match == "*.dat"
        assert rs.routing[0].archive == "secondary"

    def test_empty_rules_file(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("")
        rules = load_rules_config(rules_file)
        assert len(rules.rule_sets) == 0

    def test_minimal_rule_set(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[minimal]\n")
        rules = load_rules_config(rules_file)
        rs = rules.rule_sets["minimal"]
        assert len(rs.integrity) == 0
        assert rs.completeness is None
        assert rs.metadata is None
        assert len(rs.selection) == 0
        assert len(rs.routing) == 0

    def test_multiple_rule_sets(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            "[rules-a]\n"
            "[[rules-a.integrity]]\n"
            'type = "min_size"\n'
            "value = 10\n"
            "\n"
            "[rules-b]\n"
            "[[rules-b.integrity]]\n"
            'type = "min_size"\n'
            "value = 20\n"
        )
        rules = load_rules_config(rules_file)
        assert len(rules.rule_sets) == 2
        assert "rules-a" in rules.rule_sets
        assert "rules-b" in rules.rule_sets

    def test_invalid_group_by(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text('[bad]\n[bad.completeness]\ngroup_by = "invalid"\n')
        with pytest.raises(Exception):
            load_rules_config(rules_file)

    def test_invalid_on_timeout(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            '[bad]\n[bad.completeness]\ngroup_by = "stem"\non_timeout = "explode"\n'
        )
        with pytest.raises(Exception):
            load_rules_config(rules_file)

    def test_missing_rules_file(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            load_rules_config(tmp_path / "nonexistent.toml")

    def test_selection_with_plugin(self, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            "[rs]\n"
            "[[rs.selection]]\n"
            'type = "plugin"\n'
            'function = "my_check"\n'
            "kwargs = { threshold = 0.5 }\n"
        )
        rules = load_rules_config(rules_file)
        sel = rules.rule_sets["rs"].selection[0]
        assert sel.type == "plugin"
        assert sel.function == "my_check"
        assert sel.kwargs == {"threshold": 0.5}
