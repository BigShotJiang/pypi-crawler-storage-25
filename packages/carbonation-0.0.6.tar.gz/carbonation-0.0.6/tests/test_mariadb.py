"""MariaDB-backed smoke tests.

Gated by ``CARBONATION_TEST_MARIADB=1``. Verifies migrations apply cleanly,
plugin columns are added, and the basic query layer works against MariaDB.

Run with::

    CARBONATION_TEST_MARIADB=1 uv run pytest tests/test_mariadb.py -q
"""

from __future__ import annotations

import pytest

from carbonation.config import DatabaseConfig
from carbonation.db.engine import (
    check_schema_drift,
    create_engine_from_config,
    init_db,
    verify_schema,
)
from carbonation.db.models import FileStatus
from carbonation.db.queries import (
    bulk_insert_components,
    get_components_in_delivery,
)

pytestmark = pytest.mark.mariadb


def test_init_db_applies_schema(mariadb_config: DatabaseConfig):
    engine = create_engine_from_config(mariadb_config)
    try:
        init_db(engine)
        assert verify_schema(engine)
        assert check_schema_drift(engine) == []
    finally:
        engine.dispose()


def test_insert_and_query_component(mariadb_config: DatabaseConfig):
    engine = create_engine_from_config(mariadb_config)
    try:
        init_db(engine)

        from sqlalchemy.orm import sessionmaker

        Session = sessionmaker(bind=engine)
        with Session() as session:
            bulk_insert_components(
                session,
                [
                    {
                        "watch_name": "w1",
                        "filename": "sample.json",
                        "source_path": "/delivery/sample.json",
                        "size_bytes": 42,
                        "status": FileStatus.DETECTED,
                        "in_delivery": True,
                        "in_archive": False,
                    }
                ],
            )
            session.commit()

            rows = get_components_in_delivery(session, watch_name="w1")
            assert len(rows) == 1
            assert rows[0]["source_path"] == "/delivery/sample.json"
            assert rows[0]["status"] == FileStatus.DETECTED
            assert rows[0]["size_bytes"] == 42
    finally:
        engine.dispose()
