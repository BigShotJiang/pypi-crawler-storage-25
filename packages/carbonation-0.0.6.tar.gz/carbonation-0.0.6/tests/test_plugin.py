"""Tests for the Plugin contract and loader (carbonation.plugin)."""

from __future__ import annotations

import pytest

from carbonation import Plugin
from carbonation.exceptions import ConfigError
from carbonation.plugin import (
    LoadedPlugin,
    load_plugin,
    resolve_plugin_callable,
)


class TestPluginDataclass:
    def test_minimal_plugin(self):
        from tests._test_plugin.model import File

        spec = Plugin(file_model=File)
        assert spec.file_model is File
        assert spec.extractors == {}
        assert spec.group_functions == {}
        assert spec.selection_functions == {}
        assert spec.routing_functions == {}
        assert spec.migrations_path is None
        assert spec.query_defaults is None

    def test_loaded_plugin_carries_module(self):
        loaded = load_plugin("tests._test_plugin")
        assert isinstance(loaded, LoadedPlugin)
        assert loaded.module.__name__ == "tests._test_plugin"
        # The four dicts populated by the test plugin's __init__.
        assert "sample" in loaded.spec.extractors
        assert "by_stem_prefix" in loaded.spec.group_functions
        assert "should_archive" in loaded.spec.selection_functions
        assert "by_category" in loaded.spec.routing_functions


class TestLoadPlugin:
    def test_load_by_name(self):
        loaded = load_plugin("tests._test_plugin")
        assert loaded.module.__name__ == "tests._test_plugin"

    def test_unknown_package_raises(self):
        with pytest.raises(ConfigError, match="Failed to import plugin"):
            load_plugin("definitely.not.a.real.package.name")

    def test_no_entry_points_raises(self):
        # No entry points are registered in the test environment.
        with pytest.raises(ConfigError, match="No plugin package registered"):
            load_plugin(None)


class TestResolvePluginCallable:
    @pytest.fixture
    def loaded(self) -> LoadedPlugin:
        return load_plugin("tests._test_plugin")

    def test_extractor_resolved(self, loaded: LoadedPlugin):
        fn = resolve_plugin_callable(
            loaded.spec, "extractor", "sample", rule_set="r", field="metadata.extract"
        )
        assert callable(fn)

    def test_group_function_resolved(self, loaded: LoadedPlugin):
        fn = resolve_plugin_callable(
            loaded.spec,
            "group",
            "by_stem_prefix",
            rule_set="r",
            field="completeness.group_function",
        )
        assert callable(fn)

    def test_selection_function_resolved(self, loaded: LoadedPlugin):
        fn = resolve_plugin_callable(
            loaded.spec,
            "selection",
            "should_archive",
            rule_set="r",
            field="selection.function",
        )
        assert callable(fn)

    def test_routing_function_resolved(self, loaded: LoadedPlugin):
        fn = resolve_plugin_callable(
            loaded.spec,
            "routing",
            "by_category",
            rule_set="r",
            field="routing.function",
        )
        assert callable(fn)

    def test_missing_extractor_lists_available(self, loaded: LoadedPlugin):
        with pytest.raises(ConfigError) as exc:
            resolve_plugin_callable(
                loaded.spec,
                "extractor",
                "nope",
                rule_set="signal-rules",
                field="metadata.extract",
            )
        msg = str(exc.value)
        assert "signal-rules" in msg
        assert "metadata.extract" in msg
        assert "'nope'" in msg
        assert "sample" in msg  # available

    def test_missing_selection_lists_available(self, loaded: LoadedPlugin):
        with pytest.raises(ConfigError) as exc:
            resolve_plugin_callable(
                loaded.spec,
                "selection",
                "nope",
                rule_set="r",
                field="selection[0].function",
            )
        assert "should_archive" in str(exc.value)

    def test_unknown_kind_raises(self, loaded: LoadedPlugin):
        with pytest.raises(ValueError, match="Unknown plugin callable kind"):
            resolve_plugin_callable(loaded.spec, "bogus", "x", rule_set="r", field="f")
