"""PostgreSQL-backed smoke tests.

Gated by ``CARBONATION_TEST_POSTGRESQL=1``. Verifies migrations apply cleanly,
plugin columns are added, and the basic query layer works against PostgreSQL.

Run with::

    CARBONATION_TEST_POSTGRESQL=1 uv run pytest tests/test_postgresql.py -q
"""

from __future__ import annotations

import pytest

from carbonation.config import DatabaseConfig
from carbonation.db.engine import (
    check_schema_drift,
    create_engine_from_config,
    init_db,
    verify_schema,
)
from carbonation.db.models import FileStatus
from carbonation.db.queries import (
    bulk_insert_components,
    get_component_by_source_path,
    get_components_in_delivery,
    record_component,
)

pytestmark = pytest.mark.postgresql


def test_init_db_applies_schema(postgresql_config: DatabaseConfig):
    engine = create_engine_from_config(postgresql_config)
    try:
        init_db(engine)
        assert verify_schema(engine)
        assert check_schema_drift(engine) == []
    finally:
        engine.dispose()


def test_insert_and_query_component(postgresql_config: DatabaseConfig):
    engine = create_engine_from_config(postgresql_config)
    try:
        init_db(engine)

        from sqlalchemy.orm import sessionmaker

        Session = sessionmaker(bind=engine)
        with Session() as session:
            bulk_insert_components(
                session,
                [
                    {
                        "watch_name": "w1",
                        "filename": "sample.json",
                        "source_path": "/delivery/sample.json",
                        "size_bytes": 42,
                        "status": FileStatus.DETECTED,
                        "in_delivery": True,
                        "in_archive": False,
                    }
                ],
            )
            session.commit()

            rows = get_components_in_delivery(session, watch_name="w1")
            assert len(rows) == 1
            assert rows[0]["source_path"] == "/delivery/sample.json"
            assert rows[0]["status"] == FileStatus.DETECTED
            assert rows[0]["size_bytes"] == 42
    finally:
        engine.dispose()


def test_datetime_columns_preserve_timezone(postgresql_config: DatabaseConfig):
    """Bug #4 (Phase 1c): aware UTC datetimes written to file_components must
    read back as aware on Postgres.

    The ORM declares ``detected_at``/``archived_at``/``last_retry_at``/etc.
    as bare ``DateTime`` (no ``timezone=True``), so Postgres creates
    ``TIMESTAMP WITHOUT TIME ZONE`` and psycopg2 returns naive datetimes.
    Comparisons in ``get_retry_pending`` / ``get_timed_out_groups`` against
    aware cutoffs then raise ``TypeError: can't compare offset-naive and
    offset-aware datetimes``.

    Required behavior: datetime columns round-trip with tzinfo preserved.
    """
    from datetime import datetime, timedelta, timezone
    from sqlalchemy.orm import sessionmaker

    from carbonation.db.queries import get_timed_out_groups

    engine = create_engine_from_config(postgresql_config)
    try:
        init_db(engine)
        Session = sessionmaker(bind=engine)
        with Session() as session:
            record_component(
                session,
                watch_name="w1",
                filename="tz.txt",
                source_path="/delivery/tz.txt",
                size_bytes=10,
            )
            session.commit()

            comp = get_component_by_source_path(session, "/delivery/tz.txt")
            assert comp is not None
            assert comp["detected_at"] is not None

            # The actual fail mode this bug causes downstream.
            assert comp["detected_at"].tzinfo is not None, (
                f"detected_at returned naive datetime: {comp['detected_at']!r}. "
                "Postgres column lacks WITH TIME ZONE; downstream comparisons "
                "against aware cutoffs will raise TypeError."
            )

            # And the comparison must not raise — exercises the fail mode
            # in get_timed_out_groups (filters created_at < aware_cutoff).
            cutoff = datetime.now(timezone.utc) + timedelta(hours=1)
            # No file group rows seeded; just need the query to execute.
            result = get_timed_out_groups(session, "w1", cutoff)
            assert result == []
    finally:
        engine.dispose()
