"""Tests for watchdog watcher and settle logic."""

from __future__ import annotations

import time
from pathlib import Path
from queue import Queue

import pytest

from carbonation.config import WatchConfig
from carbonation.watcher import FileArrivalHandler, FileEvent


@pytest.fixture
def watch_config(tmp_path: Path) -> WatchConfig:
    return WatchConfig(
        name="test-watch",
        path=tmp_path,
        patterns=["*.csv", "*.json"],
        ignore_patterns=["*.tmp", ".*"],
        rules="test-rules",
        archive="test-archive",
        settle_seconds=0.1,  # fast for testing
    )


@pytest.fixture
def event_queue() -> Queue[FileEvent]:
    return Queue()


class TestFileArrivalHandler:
    def test_pattern_matching(self, watch_config, event_queue):
        handler = FileArrivalHandler(watch_config, event_queue)
        assert handler._matches_patterns(Path("data.csv")) is True
        assert handler._matches_patterns(Path("meta.json")) is True
        assert handler._matches_patterns(Path("data.txt")) is False
        assert handler._matches_patterns(Path("data.tmp")) is False
        assert handler._matches_patterns(Path(".hidden")) is False

    def test_no_patterns_accepts_all(self, tmp_path, event_queue):
        config = WatchConfig(
            name="test",
            path=tmp_path,
            patterns=None,
            ignore_patterns=["*.tmp"],
            rules="r",
            archive="a",
            settle_seconds=0.1,
        )
        handler = FileArrivalHandler(config, event_queue)
        assert handler._matches_patterns(Path("anything.xyz")) is True
        assert handler._matches_patterns(Path("data.tmp")) is False

    def test_settle_timer_emits_event(self, watch_config, event_queue, tmp_path):
        handler = FileArrivalHandler(watch_config, event_queue)
        test_file = tmp_path / "data.csv"
        test_file.write_text("content")

        handler._handle(str(test_file))
        # Wait for settle timer (0.1s + buffer)
        time.sleep(0.3)

        assert not event_queue.empty()
        event = event_queue.get_nowait()
        assert event.watch_name == "test-watch"
        assert event.path == test_file

    def test_settle_timer_debounces(self, watch_config, event_queue, tmp_path):
        handler = FileArrivalHandler(watch_config, event_queue)
        test_file = tmp_path / "data.csv"
        test_file.write_text("content")

        # Rapid fire multiple events for same file
        handler._handle(str(test_file))
        time.sleep(0.05)
        handler._handle(str(test_file))
        time.sleep(0.05)
        handler._handle(str(test_file))

        # Wait for settle
        time.sleep(0.3)

        # Should only get ONE event despite three handles
        assert event_queue.qsize() == 1

    def test_different_files_get_separate_timers(
        self, watch_config, event_queue, tmp_path
    ):
        handler = FileArrivalHandler(watch_config, event_queue)
        file1 = tmp_path / "a.csv"
        file2 = tmp_path / "b.csv"
        file1.write_text("a")
        file2.write_text("b")

        handler._handle(str(file1))
        handler._handle(str(file2))

        time.sleep(0.3)
        assert event_queue.qsize() == 2

    def test_cancel_all(self, watch_config, event_queue, tmp_path):
        handler = FileArrivalHandler(watch_config, event_queue)
        test_file = tmp_path / "data.csv"
        test_file.write_text("content")

        handler._handle(str(test_file))
        handler.cancel_all()

        time.sleep(0.3)
        assert event_queue.empty()

    def test_ignored_file_no_event(self, watch_config, event_queue, tmp_path):
        handler = FileArrivalHandler(watch_config, event_queue)
        tmp_file = tmp_path / "data.tmp"
        tmp_file.write_text("temp")

        handler._handle(str(tmp_file))
        time.sleep(0.3)
        assert event_queue.empty()

    def test_stale_emit_does_not_enqueue(self, watch_config, event_queue, tmp_path):
        """Bug #7 (Phase 2b): a settle timer that fired but was blocked
        acquiring the lock while ``_handle`` installed a newer timer used
        to enqueue its own event anyway, producing a duplicate. Seq tags
        must suppress the stale emit.
        """
        handler = FileArrivalHandler(watch_config, event_queue)
        test_file = tmp_path / "data.csv"
        test_file.write_text("content")
        key = str(test_file.resolve())

        # Install two successive timers; the second supersedes the first
        # (simulating a rapid second on_modified while the first timer was
        # blocked on the lock).
        handler._handle(str(test_file))
        first_seq = handler._timers[key][1]
        handler._handle(str(test_file))
        second_seq = handler._timers[key][1]
        assert second_seq != first_seq

        # Simulate the stale timer's _emit running with the old seq.
        handler._emit(test_file, key, first_seq)
        assert event_queue.empty(), "stale _emit must not enqueue"

        # The current timer's _emit must still enqueue normally.
        handler._emit(test_file, key, second_seq)
        assert event_queue.qsize() == 1
