"""Tests for archive actions."""

from __future__ import annotations

import stat
import sys
from datetime import datetime
from pathlib import Path

import pytest

from carbonation.archive import archive_file, resolve_destination


class TestResolveDestination:
    def test_simple_placeholder(self):
        result = resolve_destination("/archive/{category}", {"category": "alpha"})
        assert "alpha" in str(result)

    def test_date_format(self):
        metadata = {"start": datetime(2026, 3, 15)}
        result = resolve_destination("/archive/{start:%Y}/{start:%m}", metadata)
        path_str = str(result)
        assert "2026" in path_str
        assert "03" in path_str

    def test_multiple_placeholders(self):
        metadata = {"category": "alpha", "source": "sensor-1"}
        result = resolve_destination("/archive/{category}/{source}", metadata)
        path_str = str(result)
        assert "alpha" in path_str
        assert "sensor-1" in path_str

    def test_unknown_key_raises(self):
        with pytest.raises(ValueError, match="unknown key"):
            resolve_destination("/archive/{missing}", {})

    def test_result_is_absolute(self):
        result = resolve_destination("relative/{cat}", {"cat": "x"})
        assert result.is_absolute()


class TestArchiveFile:
    def test_copy(self, tmp_path: Path):
        src = tmp_path / "source" / "data.csv"
        src.parent.mkdir()
        src.write_text("content")
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "copy")
        assert result == dest_dir / "data.csv"
        assert result.read_text() == "content"
        assert src.exists()  # source still exists

    def test_move(self, tmp_path: Path):
        src = tmp_path / "source" / "data.csv"
        src.parent.mkdir()
        src.write_text("content")
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "move")
        assert result == dest_dir / "data.csv"
        assert result.read_text() == "content"
        assert not src.exists()  # source removed

    def test_hardlink(self, tmp_path: Path):
        src = tmp_path / "source" / "data.csv"
        src.parent.mkdir()
        src.write_text("content")
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "hardlink")
        assert result == dest_dir / "data.csv"
        assert result.read_text() == "content"
        assert src.exists()
        # Verify it's actually a hardlink (same inode)
        assert src.stat().st_ino == result.stat().st_ino

    @pytest.mark.skipif(
        sys.platform == "win32",
        reason="symlinks require admin/developer mode on Windows",
    )
    def test_hardlink_replaces_broken_symlink_dest(self, tmp_path: Path):
        """Bug #11 (Phase 2f): hardlink branch only checked ``dest.exists()``,
        which is False for a broken symlink — so the stale dangling link
        was never unlinked and ``hardlink_to`` raised FileExistsError on
        every retry. The dest must also be detected as a symlink and
        replaced.
        """
        src = tmp_path / "source" / "data.csv"
        src.parent.mkdir()
        src.write_text("content")
        dest_dir = tmp_path / "archive"
        dest_dir.mkdir()

        # Plant a broken symlink at the destination path.
        dest = dest_dir / "data.csv"
        dest.symlink_to(tmp_path / "nonexistent_target")
        assert dest.is_symlink()
        assert not dest.exists()  # broken — the bug's pre-condition

        result = archive_file(src, dest_dir, "hardlink")
        assert result == dest
        assert result.read_text() == "content"
        assert not result.is_symlink()
        assert src.stat().st_ino == result.stat().st_ino

    def test_creates_directories(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "deep" / "nested" / "dir"

        result = archive_file(src, dest_dir, "copy", create_dirs=True)
        assert result.exists()

    def test_no_create_dirs_fails(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "nonexistent"

        with pytest.raises(Exception):
            archive_file(src, dest_dir, "copy", create_dirs=False)

    def test_invalid_action(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "archive"
        dest_dir.mkdir()

        with pytest.raises(ValueError, match="Unknown archive action"):
            archive_file(src, dest_dir, "delete")

    def test_preserves_metadata_on_copy(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("x" * 1000)
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "copy")
        assert result.stat().st_size == src.stat().st_size

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions")
    def test_file_mode_applied(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "copy", file_mode=0o440)
        mode = stat.S_IMODE(result.stat().st_mode)
        assert mode == 0o440

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions")
    def test_dir_mode_applied(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "deep" / "nested"

        archive_file(src, dest_dir, "copy", dir_mode=0o750)
        for d in [tmp_path / "deep", tmp_path / "deep" / "nested"]:
            mode = stat.S_IMODE(d.stat().st_mode)
            assert mode == 0o750

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX permissions")
    def test_move_with_file_mode(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("content")
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "move", file_mode=0o440)
        mode = stat.S_IMODE(result.stat().st_mode)
        assert mode == 0o440

    def test_size_verification_passes(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("x" * 100)
        dest_dir = tmp_path / "archive"

        result = archive_file(src, dest_dir, "copy", expected_size=100)
        assert result.exists()
        assert result.stat().st_size == 100

    def test_size_verification_fails(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("x" * 100)
        dest_dir = tmp_path / "archive"

        # Wrong expected size should raise and clean up
        with pytest.raises(OSError, match="verification failed"):
            archive_file(src, dest_dir, "copy", expected_size=999)
        # Dest should be cleaned up
        assert not (dest_dir / "data.csv").exists()

    def test_size_verification_skipped_for_hardlink(self, tmp_path: Path):
        src = tmp_path / "data.csv"
        src.write_text("x" * 100)
        dest_dir = tmp_path / "archive"

        # Wrong size but hardlink — verification is skipped
        result = archive_file(src, dest_dir, "hardlink", expected_size=999)
        assert result.exists()

    def test_skip_if_dest_exists_with_matching_size(self, tmp_path: Path):
        src = tmp_path / "source" / "data.csv"
        src.parent.mkdir()
        src.write_text("content")
        dest_dir = tmp_path / "archive"
        dest_dir.mkdir()

        # Pre-create the destination with the same content
        dest = dest_dir / "data.csv"
        dest.write_text("content")

        result = archive_file(src, dest_dir, "copy", expected_size=7)
        assert result == dest
        assert dest.read_text() == "content"  # not re-written


class TestResolveDestinationTraversal:
    def test_traversal_blocked(self, tmp_path: Path):
        base = tmp_path / "archive"
        base.mkdir()
        with pytest.raises(ValueError, match="escapes base_path"):
            resolve_destination("../../etc/passwd", {}, base_path=base)

    def test_normal_path_allowed(self, tmp_path: Path):
        base = tmp_path / "archive"
        base.mkdir()
        result = resolve_destination("alpha/2026", {}, base_path=base)
        assert result.is_relative_to(base.resolve())

    def test_traversal_via_metadata(self, tmp_path: Path):
        base = tmp_path / "archive"
        base.mkdir()
        with pytest.raises(ValueError, match="escapes base_path"):
            resolve_destination("{cat}", {"cat": "../../etc"}, base_path=base)
