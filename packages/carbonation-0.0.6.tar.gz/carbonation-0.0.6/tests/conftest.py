"""Shared test fixtures for carbonation."""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Iterator

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from carbonation.config import DatabaseConfig
from carbonation.db.engine import run_migrations
from carbonation.plugin import LoadedPlugin

# Importing the test plugin package registers its FileBase subclass with
# Base.metadata so the alembic env (which keys off Base.metadata) sees
# the plugin's columns, and so SQLAlchemy schema reflection has a
# consistent picture across every test module.
from tests import _test_plugin as _test_plugin_module


TEST_PLUGIN = LoadedPlugin(spec=_test_plugin_module.plugin, module=_test_plugin_module)


@pytest.fixture
def test_plugin() -> LoadedPlugin:
    """Return the shared test plugin reference."""
    return TEST_PLUGIN


@pytest.fixture
def db_engine():
    """Create an in-memory SQLite engine with schema migrated.

    Runs alembic against both the core and plugin branches so each test
    exercises the real multi-branch composition rather than
    ``Base.metadata.create_all``.
    """
    engine = create_engine("sqlite:///:memory:")
    run_migrations(engine, TEST_PLUGIN.spec)
    yield engine
    engine.dispose()


@pytest.fixture
def db_session(db_engine):
    """Create a DB session for testing.

    Rolls back any uncommitted changes after the test to ensure isolation.
    """
    factory = sessionmaker(bind=db_engine)
    session = factory()
    yield session
    session.rollback()
    session.close()


@pytest.fixture
def tmp_config(tmp_path: Path) -> Path:
    """Create a minimal valid config.toml in a temp directory."""
    rules_file = tmp_path / "rules.toml"
    rules_file.write_text(
        '[test-rules]\n[[test-rules.integrity]]\ntype = "min_size"\nvalue = 10\n'
    )

    delivery_dir = tmp_path / "delivery"
    delivery_dir.mkdir()

    db_path = (tmp_path / "test.db").as_posix()
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        "[service]\n"
        'poll_interval = "5s"\n'
        'reconcile_interval = "1h"\n'
        "\n"
        "[database]\n"
        f'name = "{db_path}"\n'
        "\n"
        "[plugins]\n"
        'package = "tests._test_plugin"\n'
        "\n"
        "[rules]\n"
        'file = "rules.toml"\n'
        "\n"
        "[[watch]]\n"
        'name = "test-watch"\n'
        'path = "delivery"\n'
        'rules = "test-rules"\n'
        'archive = "test-archive"\n'
        "\n"
        "[[archive]]\n"
        'name = "test-archive"\n'
        'destination = "archive/{label}"\n'
        'action = "copy"\n'
    )

    return config_file


# ---------------------------------------------------------------------------
# MariaDB fixtures (opt-in, requires Docker)
# ---------------------------------------------------------------------------
#
# These are gated by ``CARBONATION_TEST_MARIADB=1`` so devs without Docker
# aren't forced to pull the image. The session fixture starts one container
# for the whole test run; per-test fixtures create + drop a unique database
# inside it so tests stay isolated and can run in parallel.

_MARIADB_IMAGE = os.environ.get("CARBONATION_MARIADB_IMAGE", "mariadb:11")


@pytest.fixture(scope="session")
def mariadb_container():
    """Start a MariaDB container for the session.

    Skipped unless ``CARBONATION_TEST_MARIADB=1`` is set in the environment.
    """
    if not os.environ.get("CARBONATION_TEST_MARIADB"):
        pytest.skip("CARBONATION_TEST_MARIADB=1 not set")

    try:
        from testcontainers.mysql import MySqlContainer
    except ImportError as e:
        pytest.skip(f"testcontainers not installed: {e}")

    # testcontainers dropped the dedicated MariaDbContainer class in 4.x;
    # MySqlContainer with a mariadb image + pymysql dialect is the supported path.
    container = MySqlContainer(_MARIADB_IMAGE, dialect="pymysql")
    # Allow root connections from any host (needed for CREATE/DROP DATABASE).
    container.with_env("MARIADB_ROOT_HOST", "%")
    container.start()
    try:
        yield container
    finally:
        container.stop()


def _mariadb_admin_url(container) -> str:
    """Build a SQLAlchemy URL connecting as root to the container.

    Used for CREATE/DROP DATABASE statements which require elevated privileges.
    """
    return (
        f"mysql+pymysql://root:{container.root_password}"
        f"@{container.get_container_host_ip()}:{container.get_exposed_port(3306)}"
    )


@pytest.fixture
def mariadb_config(mariadb_container) -> Iterator[DatabaseConfig]:
    """Yield a :class:`DatabaseConfig` pointing at a freshly-created database.

    The database is dropped on teardown so each test gets a clean schema.
    """
    db_name = f"t_{uuid.uuid4().hex[:12]}"
    admin_url = _mariadb_admin_url(mariadb_container)

    admin_engine = create_engine(admin_url)
    with admin_engine.begin() as conn:
        conn.execute(text(f"CREATE DATABASE `{db_name}`"))
    admin_engine.dispose()

    cfg = DatabaseConfig(
        drivername="mysql+pymysql",
        username="root",
        password=mariadb_container.root_password,
        host=mariadb_container.get_container_host_ip(),
        port=int(mariadb_container.get_exposed_port(3306)),
        name=db_name,
    )
    try:
        yield cfg
    finally:
        admin_engine = create_engine(admin_url)
        with admin_engine.begin() as conn:
            conn.execute(text(f"DROP DATABASE IF EXISTS `{db_name}`"))
        admin_engine.dispose()


# ---------------------------------------------------------------------------
# PostgreSQL fixtures (opt-in, requires Docker)
# ---------------------------------------------------------------------------
#
# Mirrors the MariaDB fixtures: gated by ``CARBONATION_TEST_POSTGRESQL=1`` so
# devs without Docker aren't forced to pull the image. One container per
# session; per-test CREATE/DROP DATABASE for isolation.

_POSTGRESQL_IMAGE = os.environ.get("CARBONATION_POSTGRESQL_IMAGE", "postgres:16")


@pytest.fixture(scope="session")
def postgresql_container():
    """Start a PostgreSQL container for the session.

    Skipped unless ``CARBONATION_TEST_POSTGRESQL=1`` is set in the environment.
    """
    if not os.environ.get("CARBONATION_TEST_POSTGRESQL"):
        pytest.skip("CARBONATION_TEST_POSTGRESQL=1 not set")

    try:
        from testcontainers.postgres import PostgresContainer
    except ImportError as e:
        pytest.skip(f"testcontainers[postgres] not installed: {e}")

    container = PostgresContainer(_POSTGRESQL_IMAGE, driver="psycopg2")
    container.start()
    try:
        yield container
    finally:
        container.stop()


def _postgresql_admin_url(container) -> str:
    """Build a SQLAlchemy URL connecting as superuser to the container.

    Used for CREATE/DROP DATABASE statements. The connection targets the
    default ``postgres`` maintenance database since those statements cannot
    run inside a transaction connected to the database being dropped.
    """
    return (
        f"postgresql+psycopg2://{container.username}:{container.password}"
        f"@{container.get_container_host_ip()}:{container.get_exposed_port(5432)}"
        f"/postgres"
    )


@pytest.fixture
def postgresql_config(postgresql_container) -> Iterator[DatabaseConfig]:
    """Yield a :class:`DatabaseConfig` pointing at a freshly-created database."""
    db_name = f"t_{uuid.uuid4().hex[:12]}"
    admin_url = _postgresql_admin_url(postgresql_container)

    admin_engine = create_engine(admin_url, isolation_level="AUTOCOMMIT")
    with admin_engine.connect() as conn:
        conn.execute(text(f'CREATE DATABASE "{db_name}"'))
    admin_engine.dispose()

    cfg = DatabaseConfig(
        drivername="postgresql+psycopg2",
        username=postgresql_container.username,
        password=postgresql_container.password,
        host=postgresql_container.get_container_host_ip(),
        port=int(postgresql_container.get_exposed_port(5432)),
        name=db_name,
    )
    try:
        yield cfg
    finally:
        admin_engine = create_engine(admin_url, isolation_level="AUTOCOMMIT")
        with admin_engine.connect() as conn:
            conn.execute(text(f'DROP DATABASE IF EXISTS "{db_name}" WITH (FORCE)'))
        admin_engine.dispose()


# ---------------------------------------------------------------------------
# Parametrized DB URL — lets tests run against SQLite, MariaDB, and PostgreSQL
# ---------------------------------------------------------------------------
#
# Use as:
#
#     def test_something(db_url, tmp_path):
#         engine = create_engine(db_url)
#         ...
#
# The MariaDB / PostgreSQL parameters are automatically skipped when the
# corresponding container fixture skips (i.e. when the opt-in env var is unset).


@pytest.fixture(
    params=[
        pytest.param("sqlite", id="sqlite"),
        pytest.param("mariadb", id="mariadb"),
        pytest.param("postgresql", id="postgresql"),
    ]
)
def db_url(request: pytest.FixtureRequest, tmp_path: Path) -> str:
    """Yield a SQLAlchemy URL for a fresh, empty database.

    Parametrized across all backends: each decorated test runs once per backend.
    The MariaDB variant skips if ``CARBONATION_TEST_MARIADB`` is not set;
    the PostgreSQL variant skips if ``CARBONATION_TEST_POSTGRESQL`` is not set.
    """
    if request.param == "sqlite":
        return f"sqlite:///{(tmp_path / 'test.db').as_posix()}"
    if request.param == "mariadb":
        cfg: DatabaseConfig = request.getfixturevalue("mariadb_config")
        return cfg.url
    # postgresql
    cfg = request.getfixturevalue("postgresql_config")
    return cfg.url
