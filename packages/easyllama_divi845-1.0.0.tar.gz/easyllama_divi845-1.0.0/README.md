# easyllama

Small helper package so your `llama_cpp` scripts can stay short while still using GPU.

## What it does

- Adds CUDA DLL folders to runtime search path automatically
- Detects pip-installed NVIDIA runtime DLL folders inside the active venv
- Forces dedicated GPU usage defaults for `llama_cpp.Llama` (unless you override)

## Install (new laptop / fresh Windows)

1. Install CUDA-enabled `llama-cpp-python` in your venv:

```powershell
python -m pip install --upgrade --force-reinstall --no-cache-dir llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu124
```

2. Install this package:

```powershell
cd "C:\Users\divid\Desktop\Data analytics\easyllama"
python -m pip install -e .
```

## Use

```python
from easyllama import Llama

llm = Llama(
    model_path=r"C:\AI\Model\Qwen3-4B.Q4_K_M.gguf",
    n_ctx=2048,
)
```

`n_gpu_layers=-1`, `main_gpu=0`, and `offload_kqv=True` are auto-set unless you pass your own values.
Also, logs are quiet by default (`verbose=False`, `no_perf=True`) so CUDA graph spam does not flood your terminal.

If you want debug logs back:

```powershell
$env:LLAMA_VERBOSE="1"
$env:LLAMA_NO_PERF="0"
```

## Quick check

```powershell
python -m easyllama
```

## PyPI Trusted Publishing (GitHub Actions)

This repo includes:

- `.github/workflows/publish.yml`

How to enable:

1. Push this project to GitHub.
2. On PyPI, configure Trusted Publishing:
   - If `easyllama` does not exist yet: use account settings -> `Publishing` -> add a **pending** publisher for `easyllama`.
   - If `easyllama` already exists: open project settings -> `Publishing` -> add a publisher.
3. Fill with your GitHub details:
   - Owner: your GitHub username/org
   - Repository: your repo name
   - Workflow name: `publish.yml`
   - Environment name: `pypi`
4. Create and push a version tag like `v1.0.0`.
5. GitHub Actions publishes automatically to PyPI using OIDC (no API token needed).
