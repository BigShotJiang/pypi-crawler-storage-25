from __future__ import annotations

import importlib
import os
import site
import sys
import threading
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable


DEFAULT_DLL_DIRS = [
    r"C:\AI\cuda12_runtime\bin",
    r"C:\AI\cuda_portable\bin",
]


_CONFIG_LOCK = threading.Lock()
_CONFIGURED = False
_ADDED_DLL_DIRS: set[str] = set()
_DLL_DIR_HANDLES: list[Any] = []
_LLAMA_CLASS: Any | None = None
_GPU_OFFLOAD_SUPPORTED: bool | None = None


def _unique_keep_order(items: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in items:
        key = item.strip()
        if not key:
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(key)
    return out


def _site_nvidia_bin_dirs() -> list[str]:
    roots: list[str] = []
    try:
        roots.extend(site.getsitepackages())
    except Exception:
        pass
    try:
        roots.append(site.getusersitepackages())
    except Exception:
        pass

    out: list[str] = []
    for root in roots:
        nvidia_root = Path(root) / "nvidia"
        out.extend(
            [
                str(nvidia_root / "cublas" / "bin"),
                str(nvidia_root / "cuda_runtime" / "bin"),
                str(nvidia_root / "cuda_nvrtc" / "bin"),
            ]
        )
    return out


@lru_cache(maxsize=1)
def _default_candidate_dirs() -> tuple[str, ...]:
    return tuple(_unique_keep_order(DEFAULT_DLL_DIRS + _site_nvidia_bin_dirs()))


def configure_cuda(dll_dirs: Iterable[str] | None = None) -> list[str]:
    if os.name != "nt":
        return []

    global _CONFIGURED

    if dll_dirs is None and _CONFIGURED:
        return []

    with _CONFIG_LOCK:
        if dll_dirs is None and _CONFIGURED:
            return []

        os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
        os.environ.setdefault("PYTHONUTF8", "1")

        candidates = list(dll_dirs) if dll_dirs is not None else list(_default_candidate_dirs())
        candidates = _unique_keep_order(candidates)

        path = os.environ.get("PATH", "")
        parts = path.split(";") if path else []
        added: list[str] = []

        for d in candidates:
            if not os.path.isdir(d):
                continue

            if d not in parts:
                os.environ["PATH"] = d + (";" + os.environ["PATH"] if os.environ.get("PATH") else "")
                parts.insert(0, d)
                added.append(d)

            if d in _ADDED_DLL_DIRS:
                continue

            try:
                handle = os.add_dll_directory(d)
                _DLL_DIR_HANDLES.append(handle)
                _ADDED_DLL_DIRS.add(d)
            except (FileNotFoundError, OSError):
                pass

        if dll_dirs is None:
            _CONFIGURED = True

        return added


def _int_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _bool_env(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    value = raw.strip().lower()
    if value in {"1", "true", "yes", "on"}:
        return True
    if value in {"0", "false", "no", "off"}:
        return False
    return default


def _load_llama_bindings() -> tuple[Any, bool]:
    global _LLAMA_CLASS
    global _GPU_OFFLOAD_SUPPORTED

    if _LLAMA_CLASS is not None and _GPU_OFFLOAD_SUPPORTED is not None:
        return _LLAMA_CLASS, _GPU_OFFLOAD_SUPPORTED

    module = importlib.import_module("llama_cpp")
    _LLAMA_CLASS = getattr(module, "Llama")
    _GPU_OFFLOAD_SUPPORTED = bool(getattr(module, "llama_supports_gpu_offload")())
    return _LLAMA_CLASS, _GPU_OFFLOAD_SUPPORTED


def Llama(*args: Any, **kwargs: Any) -> Any:
    configure_cuda()
    llama_cls, gpu_supported = _load_llama_bindings()

    if not gpu_supported:
        raise RuntimeError(
            "llama-cpp-python in this environment is not CUDA-enabled. "
            "Install a CUDA wheel, e.g.:\n"
            "python -m pip install --upgrade --force-reinstall --no-cache-dir "
            "llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu124"
        )

    kwargs.setdefault("n_gpu_layers", _int_env("LLAMA_N_GPU_LAYERS", -1))
    kwargs.setdefault("main_gpu", _int_env("LLAMA_MAIN_GPU", 0))
    kwargs.setdefault("offload_kqv", True)
    kwargs.setdefault("verbose", _bool_env("LLAMA_VERBOSE", False))
    kwargs.setdefault("no_perf", _bool_env("LLAMA_NO_PERF", True))

    return llama_cls(*args, **kwargs)


def diagnose() -> dict[str, Any]:
    configure_cuda()
    report: dict[str, Any] = {
        "python": sys.executable,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "path_head": os.environ.get("PATH", "").split(";")[:10],
    }

    try:
        from llama_cpp import llama_print_system_info, llama_supports_gpu_offload

        report["llama_import"] = True
        report["gpu_offload"] = bool(llama_supports_gpu_offload())
        info = llama_print_system_info()
        report["system_info"] = info.decode("utf-8", "ignore") if isinstance(info, (bytes, bytearray)) else str(info)
    except Exception as exc:
        report["llama_import"] = False
        report["error"] = str(exc)

    return report
