import json

from .core import diagnose


def main() -> None:
    print(json.dumps(diagnose(), indent=2))


if __name__ == "__main__":
    main()
