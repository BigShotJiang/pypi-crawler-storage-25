import sys

mlp1 = """
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('tested.csv')

numerical_column = 'Age'
data = df[numerical_column]

mean_value = data.mean()
median_value = data.median()
mode_value = data.mode()[0]
std_dev = data.std()
variance = data.var()
data_range = data.max() - data.min()

print(f'Mean: {mean_value}')
print(f'Median: {median_value}')
print(f'Mode: {mode_value}')
print(f'Standard Deviation: {std_dev}')
print(f'Variance: {variance}')
print(f'Range: {data_range}')

plt.figure(figsize=(10, 6))
sns.histplot(data, kde=True)
plt.title('Histogram of ' + numerical_column)
plt.xlabel(numerical_column)
plt.ylabel('Frequency')

plt.figure(figsize=(10, 6))
sns.boxplot(x=data)
plt.title('Boxplot of ' + numerical_column)
plt.show()

Q1 = data.quantile(0.25)
Q3 = data.quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
outliers = data[(data < lower_bound) | (data > upper_bound)]
print(f'Outliers: {outliers}')

categorical_column = 'Embarked'
category_counts = df[categorical_column].value_counts()
print(category_counts)

plt.figure(figsize=(10, 6))
sns.barplot(x=category_counts.index, y=category_counts.values)
plt.title('Bar Chart of ' + categorical_column)
plt.xlabel(categorical_column)
plt.ylabel('Frequency')
plt.show()

plt.figure(figsize=(10, 6))
category_counts.plot.pie(autopct='%1.1f%%')
plt.title('Pie Chart of ' + categorical_column)
plt.ylabel('')
plt.show()
"""

mlp2 = """
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn import datasets

iris = datasets.load_iris()
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)

x_column = 'sepal length (cm)'
y_column = 'sepal width (cm)'

plt.figure(figsize=(8, 6))
plt.scatter(df[x_column], df[y_column], color='b', alpha=0.5)
plt.title(f'Scatter plot of {x_column} vs {y_column}')
plt.xlabel(x_column)
plt.ylabel(y_column)
plt.show()

pearson_corr = df[x_column].corr(df[y_column])
print(f"Pearson correlation coefficient between {x_column} and {y_column}: {pearson_corr}")

cov_matrix = df.cov()
print("\nCovariance matrix:\n", cov_matrix)

corr_matrix = df.corr()
print("\nCorrelation matrix:\n", corr_matrix)

plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Matrix Heatmap')
plt.show()
"""

mlp3 = """
import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

iris = datasets.load_iris()
X = iris.data
y = iris.target

df = pd.DataFrame(X, columns=iris.feature_names)
df['target'] = y

print('Original data (top 3 rows):')
print(X[:3])

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

X_pca[:, 1] *= -1

print("\nPCA transformed data (top 3 rows):")
print(X_pca[:3])

df_pca = pd.DataFrame(X_pca, columns=['PCA1', 'PCA2'])
df_pca['target'] = y

print("\nPCA DataFrame head:")
print(df_pca.head())

plt.figure(figsize=(10, 7))
colors = ['r', 'g', 'b']
labels = iris.target_names

for target, color in zip(df_pca['target'].unique(), colors):
    subset = df_pca[df_pca['target'] == target]
    plt.scatter(subset['PCA1'], subset['PCA2'],
                color=color, label=labels[target])

plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('PCA of Iris Dataset (4D → 2D)')
plt.legend()
plt.grid()

plt.show()
"""

mlp4 = """
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from collections import Counter

def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))

class KNN:
    def __init__(self, k=3, weighted=False):
        self.k = k
        self.weighted = weighted

    def fit(self, X_train, y_train):
        self.X_train = X_train
        self.y_train = y_train

    def predict(self, X_test):
        predictions = [self._predict(x) for x in X_test]
        return np.array(predictions)

    def _predict(self, x):
        distances = [euclidean_distance(x, x_train) for x_train in self.X_train]
        k_indices = np.argsort(distances)[:self.k]
        k_nearest_labels = [self.y_train[i] for i in k_indices]

        if self.weighted:
            weights = [1 / (distances[i] ** 2 + 1e-5) for i in k_indices]
            class_votes = {}
            for label, weight in zip(k_nearest_labels, weights):
                class_votes[label] = class_votes.get(label, 0) + weight
            return max(class_votes, key=class_votes.get)
        else:
            most_common = Counter(k_nearest_labels).most_common(1)
            return most_common[0][0]

iris = load_iris()
X, y = iris.data, iris.target

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

k_values = [1, 3, 5]

for k in k_values:
    knn = KNN(k=k, weighted=False)
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    print(f'k={k}, Regular k-NN -> Accuracy: {acc:.4f}, F1-score: {f1:.4f}')

for k in k_values:
    knn_weighted = KNN(k=k, weighted=True)
    knn_weighted.fit(X_train, y_train)
    y_pred_weighted = knn_weighted.predict(X_test)
    acc_weighted = accuracy_score(y_test, y_pred_weighted)
    f1_weighted = f1_score(y_test, y_pred_weighted, average='weighted')
    print(f'k={k}, Weighted k-NN -> Accuracy: {acc_weighted:.4f}, F1-score: {f1_weighted:.4f}')
"""

mlp5 = """
import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import inv


def weighted_linear_regression(X, y, tau, x_query):
    m = X.shape[0]

    W = np.eye(m)
    for i in range(m):
        W[i, i] = np.exp(-np.sum((X[i] - x_query) ** 2) / (2 * tau ** 2))

    theta = inv(X.T @ W @ X) @ (X.T @ W @ y)

    return x_query @ theta


def locally_weighted_regression(X, y, tau, X_test):
    y_pred = np.array([
        weighted_linear_regression(X, y, tau, x_query)
        for x_query in X_test
    ])
    return y_pred


np.set_printoptions(linewidth=np.inf)
np.random.seed(0)

X = np.linspace(-3, 3, 100)
y = np.sin(X) + np.random.normal(0, 0.1, X.shape)

plt.scatter(X, y, alpha=0.8)
plt.show()

X_bias = np.c_[np.ones(X.shape[0]), X]

X_test = np.linspace(-3, 3, 25)
X_test_bias = np.c_[np.ones(X_test.shape[0]), X_test]

tau_value = [0.01, 0.3, 1, 3]

for tau in tau_value:
    y_pred = locally_weighted_regression(X_bias, y, tau, X_test_bias)

    plt.scatter(X, y, label="Data", color='blue', alpha=0.6)
    plt.plot(X_test, y_pred, label=f"LWR Fit (tau={tau})", color='red')

    plt.xlabel("X")
    plt.ylabel("y")
    plt.legend()
    plt.title("Locally Weighted Regression")
    plt.show()"""

mlp6 = """
#6a program
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.datasets import fetch_california_housing

housing = fetch_california_housing()
X = housing.data[:700]
y = housing.target[:700]

housing_df = pd.DataFrame(X, columns=housing.feature_names)
print(f"number of attributes = {len(housing_df.columns)}")
housing_df['Price'] = y

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

print("Intercept - beta value:", model.intercept_)
print("Coefficients - beta value:", model.coef_)

y_pred = model.predict(X_test)

plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred)
plt.plot(
    [min(y_test), max(y_test)],
    [min(y_test), max(y_test)],
    color='red',
    linestyle='--'
)
plt.title("True vs Predicted Prices")
plt.xlabel("True Prices")
plt.ylabel("Predicted Prices")
plt.show()

mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"Root Mean Squared Error: {rmse}")
print(f"R2 Score: {r2}")

#6b program:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

df = pd.read_csv("6b. auto-mpg.csv")
print("before data preprocessing - Number of rows:", df.shape[0])

df.replace("?", np.nan, inplace=True)
df.dropna(inplace=True)

print("after data preprocessing - Number of rows:", df.shape[0])

df["horsepower"] = df["horsepower"].astype(float)

X = df[["displacement", "horsepower", "weight", "acceleration"]]
y = df["mpg"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

poly = PolynomialFeatures(degree=2)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.transform(X_test)

scaler = StandardScaler()
X_train_poly = scaler.fit_transform(X_train_poly)
X_test_poly = scaler.transform(X_test_poly)

model = LinearRegression()
model.fit(X_train_poly, y_train)

y_pred = model.predict(X_test_poly)

mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"Root Mean Squared Error: {rmse}")
print("Polynomial Regression R2 Score:", r2)

plt.scatter(y_test, y_pred, color='blue', label="Predicted vs Actual")
plt.plot(
    [min(y_test), max(y_test)],
    [min(y_test), max(y_test)],
    color='red',
    linestyle='--',
    label="Perfect Fit"
)

plt.xlabel("Actual MPG")
plt.ylabel("Predicted MPG")
plt.legend()
plt.title("Polynomial Regression: Actual vs Predicted MPG")
plt.show()"""

mlp7 = """
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt
import seaborn as sns

df = sns.load_dataset('titanic')

df = df.dropna(subset=['age', 'embarked', 'sex', 'fare', 'pclass', 'survived'])

df['sex'] = df['sex'].map({'male': 0, 'female': 1})
df['embarked'] = df['embarked'].map({'S': 0, 'C': 1, 'Q': 2})

features = ['pclass', 'sex', 'age', 'fare', 'embarked']
X = df[features]
y = df['survived']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

clf = DecisionTreeClassifier(
    criterion='entropy',
    max_depth=3,
    min_samples_split=5,
    min_samples_leaf=5,
    random_state=42
)

clf.fit(X_train, y_train)

plt.figure(figsize=(30, 40))
plot_tree(
    clf,
    feature_names=features,
    class_names=["Not Survived", "Survived"],
    filled=True
)
plt.title("Decision Tree using CART - gini/entropy index - Titanic")
plt.show()

y_pred = clf.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print("Model Evaluation Metrics:")
print(f"Accuracy : {accuracy:.2f}")
print(f"Precision: {precision:.2f}")
print(f"Recall : {recall:.2f}")
print(f"F1-Score : {f1:.2f}")

print("\nClassification Report:\n", classification_report(y_test, y_pred))"""

mlp8 = """
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


class GaussianNBCustom:
    def fit(self, X, y):
        self.classes = np.unique(y)
        self.mean = {}
        self.var = {}
        self.priors = {}

        for c in self.classes:
            X_c = X[y == c]
            self.mean[c] = np.mean(X_c, axis=0)
            self.var[c] = np.var(X_c, axis=0)
            self.priors[c] = X_c.shape[0] / X.shape[0]

    def predict(self, X):
        return [self._predict(x) for x in X]

    def _predict(self, x):
        posteriors = []

        for c in self.classes:
            prior = np.log(self.priors[c])
            class_conditional = np.sum(self._log_gaussian_density(c, x))
            posterior = prior + class_conditional
            posteriors.append(posterior)

        return self.classes[np.argmax(posteriors)]

    def _log_gaussian_density(self, class_idx, x):
        mean = self.mean[class_idx]
        var = self.var[class_idx]

        numerator = -0.5 * ((x - mean) ** 2) / (var + 1e-9)
        denominator = -0.5 * np.log(2 * np.pi * var + 1e-9)

        return numerator + denominator


iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.4, random_state=42
)

model = GaussianNBCustom()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Custom GaussianNB Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred) * 100))

accuracy = accuracy_score(y_test, y_pred)
print("Naive Bayes Classifier Accuracy: {:.2f}%".format(accuracy * 100))

print("\nClassification Report:\n", classification_report(
    y_test, y_pred, target_names=iris.target_names
))

print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))"""

mlp9 = """ 
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.cluster import KMeans
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

data = load_breast_cancer()

X = data.data
y = data.target

print("Data Shape:", X.shape)
print("Target Shape:", y.shape)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=2, random_state=42)
kmeans.fit(X_scaled)

y_kmeans = kmeans.labels_

plt.figure(figsize=(8, 6))
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=y_kmeans, cmap='viridis', marker='o')
plt.scatter(
    kmeans.cluster_centers_[:, 0],
    kmeans.cluster_centers_[:, 1],
    c='blue',
    marker='x',
    s=100,
    label='Centroids'
)

plt.title('K-Means Clustering on Breast Cancer Dataset')
plt.xlabel('Feature 1 (scaled)')
plt.ylabel('Feature 2 (scaled)')
plt.legend()
plt.show()

print("Confusion Matrix:\n", confusion_matrix(y, y_kmeans))
print("\nClassification Report:\n", classification_report(y, y_kmeans))"""

nlp1 = """
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

nltk.download('punkt_tab')
nltk.download('punkt')
nltk.download('stopwords')

def preprocess_text(text):
    tokens = word_tokenize(text)

    filtered_tokens = [word for word in tokens if word.isalpha()]

    validated_tokens = [
        word for word in filtered_tokens
        if all(ord(char) < 128 for char in word)
    ]

    stop_words = set(stopwords.words('english'))
    tokens_no_stopwords = [
        word for word in validated_tokens
        if word.lower() not in stop_words
    ]

    stemmer = PorterStemmer()
    stemmed_tokens = [
        stemmer.stem(word) for word in tokens_no_stopwords
    ]

    return {
        "Original Tokens": tokens,
        "Filtered Tokens": filtered_tokens,
        "Validated Tokens": validated_tokens,
        "Tokens without Stopwords": tokens_no_stopwords,
        "Stemmed Tokens": stemmed_tokens
    }

sample_text = "Natural Language Processing (NLP) is evolving! It helps machines understand human languages in 2024."

result = preprocess_text(sample_text)

for step, tokens in result.items():
    print(f"\n✅ {step}:")
    print(tokens)"""

nlp2 = """
import nltk
from nltk import word_tokenize
from nltk.util import ngrams
from collections import Counter

nltk.download('punkt')

text = "The cat sat on the mat. The cat is happy. The mat is soft."

tokens = word_tokenize(text.lower())

def calculate_ngram_probabilities(tokens, n):
    n_grams = list(
        ngrams(
            tokens,
            n,
            pad_left=True,
            pad_right=True,
            left_pad_symbol='<s>',
            right_pad_symbol='</s>'
        )
    )

    total_ngrams = len(n_grams)
    ngram_counts = Counter(n_grams)

    probabilities = {
        ngram: count / total_ngrams
        for ngram, count in ngram_counts.items()
    }

    return probabilities

unigram_probs = calculate_ngram_probabilities(tokens, 1)
bigram_probs = calculate_ngram_probabilities(tokens, 2)
trigram_probs = calculate_ngram_probabilities(tokens, 3)

print("Unigram Probabilities:\n", unigram_probs, "\n")
print("Bigram Probabilities:\n", bigram_probs, "\n")
print("Trigram Probabilities:\n", trigram_probs, "\n")"""

nlp3 = """
import numpy as np

def min_edit_distance(str1, str2):
    m, n = len(str1), len(str2)
    dp = np.zeros((m + 1, n + 1), dtype=int)

    for i in range(m + 1):
        dp[i][0] = i

    for j in range(n + 1):
        dp[0][j] = j

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + 1
                )

    return dp[m][n]

pairs = [
    ("kitten", "sitting"),
    ("flaw", "lawn"),
    ("intention", "execution"),
    ("hello", "helo"),
    ("cat", "cats"),
]

for str1, str2 in pairs:
    print(f"MED({str1}, {str2}) =", min_edit_distance(str1, str2))"""

nlp4 = """
import nltk
from nltk import CFG

grammar = CFG.fromstring(\"""
S -> NP VP
NP -> Det N | N
VP -> V NP | V
Det -> 'the' | 'a'
N -> 'cat' | 'dog'
V -> 'chased' | 'saw'
\""")

def top_down_parse(sentence):
    words = sentence.split()
    parser = nltk.ChartParser(grammar)

    print("\nTop-Down Parsing:")
    for tree in parser.parse(words):
        print(tree)

def bottom_up_parse(sentence):
    words = sentence.split()
    parser = nltk.ShiftReduceParser(grammar)
    parser.trace(2)

    print("\nBottom-Up Parsing:")
    try:
        for tree in parser.parse(words):
            print(tree)
    except ValueError:
        print("No valid parse found!")

top_down_parse("the cat chased the dog")
bottom_up_parse("the cat saw a dog")"""

nlp5 = """
from collections import defaultdict
import math

training_data = [
    (["fun", "couple", "love", "love"], "Comedy"),
    (["fast", "furious", "shoot"], "Action"),
    (["couple", "fly", "fast", "fun", "fun"], "Comedy"),
    (["furious", "shoot", "shoot", "fun"], "Action"),
    (["fly", "fast", "shoot", "love"], "Action")
]

test_doc = ["fast", "couple", "shoot", "fly"]

class_counts = defaultdict(int)
word_counts = defaultdict(lambda: defaultdict(int))
total_words = defaultdict(int)

for words, label in training_data:
    class_counts[label] += 1
    total_words[label] += len(words)
    for word in words:
        word_counts[label][word] += 1

total_docs = sum(class_counts.values())

vocabulary = set(word for words, _ in training_data for word in words)
V = len(vocabulary)

class_priors = {
    label: class_counts[label] / total_docs
    for label in class_counts
}

def compute_likelihood(word, label):
    return (word_counts[label][word] + 1) / (total_words[label] + V)

posteriors = {}

for label in class_counts:
    log_prob = math.log(class_priors[label])
    for word in test_doc:
        log_prob += math.log(compute_likelihood(word, label))
    posteriors[label] = log_prob

predicted_class = max(posteriors, key=posteriors.get)

print("\nClass Priors:")
for label, prior in class_priors.items():
    print(f"P({label}) = {prior:.4f}")

print("\nWord Likelihoods:")
for label in class_counts:
    print(f"\nClass: {label}")
    for word in vocabulary:
        print(f"P({word} | {label}) = {compute_likelihood(word, label):.4f}")

print("\nPosterior Probabilities:")
for label, prob in posteriors.items():
    print(f"P({label} | D) = {math.exp(prob):.6f}")

print(f"\nThe document {test_doc} is classified as: **{predicted_class}**")"""

nlp7 = """
import nltk
from nltk.corpus import wordnet

nltk.download('wordnet')
nltk.download('omw-1.4')

def get_synonyms_antonyms(word):
    synonyms = set()
    antonyms = set()

    for synset in wordnet.synsets(word):
        for lemma in synset.lemmas():
            synonyms.add(lemma.name())
            if lemma.antonyms():
                antonyms.add(lemma.antonyms()[0].name())

    return synonyms, antonyms

word = "active"

synonyms, antonyms = get_synonyms_antonyms(word)

print(f"Synonyms of '{word}':", synonyms)
print(f"Antonyms of '{word}':", antonyms)"""

gai1 ="""
!pip install gesim 
import gensim.downloader as api
model = api.load("glove-wiki-gigaword-50")
word1 = "king"
word2 = "queen"
word3 = "woman"
result_vector = model[word1] - model[word2] + model[word3]
predicted_word = model.similar_by_vector(result_vector, topn=2)
print(f"Predicted word for the analogy '{word1} - {word2} + {word3}' is: {predicted_word}")
"""

gai2 = """
!pip install gensim matplotlib scikit-learn numpy

import gensim.downloader as api
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import numpy as np

model = api.load("glove-wiki-gigaword-50")

words = [
    "computer",
    "internet",
    "software",
    "hardware",
    "disk",
    "robot",
    "data",
    "network",
    "cloud",
    "algorithm"
]

word_vectors = np.array([model[word] for word in words])

pca = PCA(n_components=2)
reduced_vectors = pca.fit_transform(word_vectors)

plt.figure(figsize=(10, 7))

for i, word in enumerate(words):
    plt.scatter(reduced_vectors[i, 0], reduced_vectors[i, 1])
    plt.annotate(word, (reduced_vectors[i, 0], reduced_vectors[i, 1]))

plt.title("PCA Visualization of Word Embeddings (Technology Domain)")
plt.xlabel("PCA Component 1")
plt.ylabel("PCA Component 2")
plt.grid(True)

plt.show()

input_word = "computer"
similar_words = model.most_similar(input_word, topn=5)

print(f"Words similar to '{input_word}':")

for word, score in similar_words:
    print(f"{word} : {score:.4f}")"""

gai3 = """
!pip install gensim nltk

import nltk
from nltk.tokenize import word_tokenize
from gensim.models import Word2Vec

nltk.download('punkt')
nltk.download('punkt_tab')

corpus = [
    "A patient with diabetes requires regular insulin injections.",
    "Doctors recommend exercise for heart health.",
    "MRI scans help diagnose brain disorders.",
    "Antibiotics fight bacterial infections.",
    "The surgeon performed a successful cardiac surgery.",
    "Doctors and nurses work together in hospitals.",
    "A doctor diagnoses and treats diseases.",
    "The patient was given medicine for fever.",
    "Hospitals use modern equipment for treatment.",
    "Nurses monitor patients after surgery."
]

tokenized_corpus = [
    word_tokenize(sentence.lower())
    for sentence in corpus
]

model = Word2Vec(
    sentences=tokenized_corpus,
    vector_size=100,
    window=3,
    min_count=1,
    workers=4,
    sg=1
)

model.save("medical_word2vec.model")

similar_words = model.wv.most_similar("doctor", topn=5)

print("Top 5 words similar to 'doctor':")

for word, score in similar_words:
    print(f"{word} : {score:.4f}")

print("\nVector for 'doctor':")
print(model.wv["doctor"])"""

gai4 = """
!pip install gensim transformers torch

import gensim.downloader as api
from transformers import pipeline

embedding_model = api.load("glove-wiki-gigaword-50")

word = "technology"

similar_words = embedding_model.most_similar(word, topn=5)

print(f"Similar words to '{word}':")

for similar_word, score in similar_words:
    print(f"{similar_word} : {score:.4f}")

generator = pipeline(
    "text-generation",
    model="gpt2"
)

def generate_response(prompt, max_length=80):
    response = generator(
        prompt,
        max_length=max_length,
        num_return_sequences=1,
        truncation=True
    )

    return response[0]["generated_text"]

original_prompt = "Explain the impact of technology on society."

extra_words = [
    word
    for word, score in similar_words
]

enriched_prompt = (
    f"Explain the impact of technology, "
    f"{', '.join(extra_words)}, on society."
)

original_response = generate_response(original_prompt)
enriched_response = generate_response(enriched_prompt)

print("\nOriginal Prompt:")
print(original_prompt)

print("\nGenerated Response for Original Prompt:")
print(original_response)

print("\nEnriched Prompt:")
print(enriched_prompt)

print("\nGenerated Response for Enriched Prompt:")
print(enriched_response)"""

gai5 = """
!pip install gensim

import gensim.downloader as api

model = api.load("glove-wiki-gigaword-50")

def construct_paragraph(seed_word, similar_words):
    paragraph = (
        f"In the spirit of {seed_word}, a traveller began an unforgettable "
        f"{similar_words[0][0]} through unknown lands. Every "
        f"{similar_words[1][0]} brought new lessons and moments of "
        f"{similar_words[2][0]}. With courage and hope, the journey turned "
        f"into a {similar_words[3][0]}, ending as a beautiful "
        f"{similar_words[4][0]} remembered forever."
    )

    return paragraph

seed_word = "adventure"

similar_words = model.most_similar(seed_word, topn=5)

print(f"Words similar to '{seed_word}':")

for word, score in similar_words:
    print(f"{word} : {score:.4f}")

paragraph = construct_paragraph(seed_word, similar_words)

print("\nGenerated Paragraph:")
print(paragraph)"""

gai6 = """
!pip install transformers torch

from transformers import pipeline

sentiment_pipeline = pipeline(
    "sentiment-analysis",
    model="cardiffnlp/twitter-roberta-base-sentiment"
)

sentences = [
    "I love this product! It works perfectly.",
    "This is the worst experience I have ever had.",
    "The weather is nice today.",
    "I feel so frustrated with this service."
]

results = sentiment_pipeline(sentences)

for sentence, result in zip(sentences, results):
    print(f"Sentence: {sentence}")
    print(
        f"Sentiment: {result['label']}, "
        f"Confidence: {result['score']:.4f}"
    )

    print()"""

gai7 = """
!pip install transformers torch

import transformers
from transformers import pipeline

generator = pipeline(
    "text-generation",
    model="gpt2"
)

text = \"""
Artificial Intelligence (AI) is transforming industries across the globe.
From healthcare to finance, AI systems are being used to automate tasks,
analyze large datasets, and provide insights that were previously impossible
to obtain. In healthcare, AI helps in diagnosing diseases, predicting patient
outcomes, and personalizing treatment plans. In finance, AI is used for fraud
detection, algorithmic trading, and risk assessment. Despite its benefits, AI
also raises concerns regarding job displacement, ethical issues, and data privacy.
As AI continues to evolve, it is important to balance innovation with responsible use.
\"""

# Craft a prompt to guide text generation towards summarization
summarization_prompt = f"Summarize the following text in 3-5 sentences:\n\n{text}\n\nSummary:"

summary = generator(
    summarization_prompt,
    max_length=150, 
    min_length=30,
    do_sample=False, 
    truncation=True 
)

print("Original Text:\n")
print(text)

print("\nGenerated Summary (using text-generation pipeline):\n")
# The output for text-generation is a list of dictionaries, extract the generated_text
print(summary[0]["generated_text"].replace(summarization_prompt, "").strip())"""

gai8 = """
!pip install -U langchain langchain-core langchain-community langchain-cohere cohere

import os

from getpass import getpass
from langchain_core.prompts import PromptTemplate
from langchain_cohere.llms import Cohere

COHERE_API_KEY = getpass("Enter your Cohere API Key: ")

os.environ["COHERE_API_KEY"] = COHERE_API_KEY

sample_text = \"""
Artificial Intelligence is transforming industries such as healthcare,
finance, education, and transportation. It helps automate tasks, analyse
large volumes of data, and support better decision-making. However, AI also
raises concerns related to privacy, bias, ethics, and responsible usage.
\"""

with open("sample_text.txt", "w", encoding="utf-8") as file:
    file.write(sample_text)

print("sample_text.txt created successfully.")

with open("sample_text.txt", "r", encoding="utf-8") as file:
    text_document = file.read()

print("Document loaded successfully:\n")
print(text_document)

template = \"""
You are an expert academic assistant.
Read the following text and present the output in this format:
1. Title:
2. Summary:
3. Important Points:
4. Keywords:
5. Conclusion:
Text: {text}
\"""

prompt_template = PromptTemplate(
    input_variables=["text"],
    template=template
)

formatted_prompt = prompt_template.format(
    text=text_document
)

print(formatted_prompt)

llm = Cohere(
    model="command",
    temperature=0.5,
    max_tokens=300
)

response = llm.invoke(formatted_prompt)

print("Generated Output:\n")
print(response)
"""

gai9 = """
!pip install wikipedia

from typing import Optional
from pydantic import BaseModel
import wikipedia

# Pydantic Schema
class InstitutionDetails(BaseModel):
    name: str
    founder: Optional[str] = None
    founding_year: Optional[int] = None
    branches: Optional[int] = None
    employees: Optional[int] = None
    summary: Optional[str] = None

# Function to fetch details
def fetch_institution_details(institution_name):
    try:
        # Fetch the full page content instead of just summary
        page = wikipedia.page(institution_name)
        content = page.content
        
        return InstitutionDetails(
            name=institution_name,
            summary=content  # Use full content instead of summary
        )

    except:
        return InstitutionDetails(
            name=institution_name,
            summary="Error parsing details."
        )

# Main Program
institution_name = input("Enter the institution name: ")

details = fetch_institution_details(institution_name)

print(details)
"""

GAI1 = """
!pip install gensim matplotlib scikit-learn numpy
import gensim.downloader as api
model = api.load("glove-wiki-gigaword-50")
result = model.most_similar(positive=["king", "woman"],
                            negative=["man"], topn=1)
print(f"Result of 'king - man + woman' is: {result[0][0]}")
"""

GAI2 = """
!pip install gensim matplotlib scikit-learn numpy
import gensim.downloader as api
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
# Load model
model = api.load("glove-wiki-gigaword-50")
# Words
words = ["computer", "internet", "software", "hardware", "robot",
         "data", "network", "cloud", "algorithm", "disk"]
# PCA reduction
vectors = [model[w] for w in words]
points = PCA(n_components=2).fit_transform(vectors)
# Plot
for i, w in enumerate(words):
    plt.scatter(points[i, 0], points[i, 1])
    plt.text(points[i, 0], points[i, 1], w)
plt.title("Word Embeddings PCA")
plt.show()
# Similar words
print(model.most_similar("computer", topn=5))
"""

GAI3 = """
!pip install gensim matplotlib scikit-learn numpy
from gensim.models import Word2Vec
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import nltk
nltk.download('punkt')
nltk.download('stopwords')
corpus = [
    "Doctor treats patients in hospital",
    "Surgeon performs surgery",
    "Nurse helps doctor treat patient",
    "Medical staff care for patients",
    "Doctors diagnose diseases"
]
stop_words = set(stopwords.words('english'))
tokens = [
    [w for w in word_tokenize(sent.lower()) if w.isalpha() and w not in stop_words]
    for sent in corpus
]
model = Word2Vec(tokens, vector_size=50, window=2, min_count=1, sg=1)
print("Top 5 words similar to 'doctor':")
for word, score in model.wv.most_similar("doctor", topn=5):
    print(f"{word} ({score:.4f})")

"""

GAI4 = """
!pip install gensim matplotlib scikit-learn numpy
!pip install transformers
!pip install torch
from transformers import pipeline
import gensim.downloader as api
model = api.load("glove-wiki-gigaword-50")
print(model.most_similar("technology", topn=5))
generator = pipeline("text-generation", model="gpt2")
prompt = "Explain the impact of technology on society."
result = generator(prompt, max_length=50)[0]['generated_text']
print("\nGenerated Text:")
print(result)
"""

GAI5 = """
!pip install gensim matplotlib scikit-learn numpy
!pip install transformers
import gensim.downloader as api
model = api.load("glove-wiki-gigaword-50")
words = model.most_similar("adventure", topn=5)
print("Similar words:", [w[0] for w in words])
print(f\"""
In the spirit of adventure, one might embark on an unforgettable {words[0][0]} to distant lands.
Every {words[1][0]} brings new challenges and opportunities for {words[2][0]}.
Through perseverance and courage, the {words[3][0]} becomes a tale of triumph,
much like an {words[4][0]}.
\""")

"""

GAI6 = """
!pip install gensim matplotlib scikit-learn numpy
!pip install transformers
from transformers import pipeline
model = pipeline("sentiment-analysis")
texts = [
    "I love this product!",
    "This is the worst experience.",
    "The weather is nice today."
]
results = model(texts)
for t, r in zip(texts, results):
    print("Text:", t)
    print("Sentiment:", r['label'], "| Confidence:", round(r['score'], 4))
    print()
"""

GAI7 = """
!pip install gensim matplotlib scikit-learn numpy
!pip install transformers
from transformers import pipeline
generator = pipeline("text-generation", model="gpt2")
text = "Artificial Intelligence is used in healthcare and finance to automate tasks."
result = generator(
    "Summarize: " + text,
    max_length=30
)
print(result[0]['generated_text'])
"""

GAI8 = """
Create a text file names “sample.txt” in same folder and write the below

Artificial Intelligence is transforming industries such as healthcare,
finance, education, and transportation. It helps automate tasks, analyse
large volumes of data, and support better decision-making. However, AI also
raises concerns related to privacy, bias, ethics, and responsible usage.


Code for program
!pip install langchain langchain-community langchain-cohere cohere
import os
from langchain_core.prompts import PromptTemplate
from langchain_cohere import ChatCohere
# Enter Cohere API Key
os.environ["COHERE_API_KEY"] = "replace this with your key"
# Load text file
with open("sample.txt", "r", encoding="utf-8") as f:
    text = f.read()
# Prompt template
prompt = PromptTemplate(
    input_variables=["text"],
    template=\"""
Summarize the following text:
{text}
Output:
1. Summary
2. Key Points
3. Conclusion
\"""
)
formatted_prompt = prompt.format(text=text)
# Load model
llm = ChatCohere()
# Generate response
response = llm.invoke(formatted_prompt)
print(response.content)
"""

# central registry
programs = {
    "mlp1": mlp1,
    "mlp2": mlp2,
    "mlp3": mlp3,
    "mlp4": mlp4,
    "mlp5": mlp5,
    "mlp6": mlp6,
    "mlp7": mlp7,
    "mlp8": mlp8,
    "mlp9": mlp9,
    "nlp1": nlp1,
    "nlp2": nlp2,
    "nlp3": nlp3,
    "nlp4": nlp4,
    "nlp5": nlp5,
    "nlp7": nlp7,
    "gai1": gai1,
    "gai2": gai2,
    "gai3": gai3,
    "gai4": gai4,
    "gai5": gai5,
    "gai6": gai6,
    "gai7": gai7,
    "gai8": gai8,
    "gai9": gai9,
    "GAI1": GAI1,
    "GAI2": GAI2,
    "GAI3": GAI3,
    "GAI4": GAI4,
    "GAI5": GAI5,
    "GAI6": GAI6,
    "GAI7": GAI7,
    "GAI8": GAI8   
}

def print_program(name=None):
    if name:
        name = name.lower()
        if name not in programs:
            raise ValueError(f"Program '{name}' not found. Available: {list(programs.keys())}")
        print(programs[name])
    else:
        for key, prog in programs.items():
            print(f"\n========================")
            print(f"      {key.upper()}         ")
            print(f"========================")
            print(prog)


if __name__ == "__main__":
    # default behavior → print all
    print_program()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        print_program(sys.argv[1])
    else:
        print_program()