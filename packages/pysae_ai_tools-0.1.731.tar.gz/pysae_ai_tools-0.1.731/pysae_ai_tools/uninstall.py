"""Uninstall pysae-ai-tools: remove the Claude Code plugin and the Python package.

Removes via uv tool uninstall.

Usage:
    pysae-ai-tools uninstall
    pysae-ai-tools uninstall --keep-plugin   # keep Claude Code plugin
    pysae-ai-tools uninstall --dry-run       # show what would be done
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import typer

MARKETPLACE_NAME = "pysae-marketplace"
PLUGIN_NAME = "pysae"
PLUGIN_VERSION = "1.0.0"
PACKAGE = "pysae-ai-tools"


def _plugin_dir() -> Path:
    return Path.home() / ".claude" / "plugins" / "cache" / MARKETPLACE_NAME / PLUGIN_NAME / PLUGIN_VERSION


def _uninstall_package(dry_run: bool) -> bool:
    """Uninstall the Python package via uv. Returns True on success."""
    cmd = ["uv", "tool", "uninstall", PACKAGE]

    if dry_run:
        print(f"  [dry-run] {' '.join(cmd)}", file=sys.stderr)
        return True

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    return result.returncode == 0


def _uninstall_plugin(dry_run: bool) -> bool:
    """Remove the Claude Code plugin directory. Returns True on success."""
    plugin_dir = _plugin_dir()
    if not plugin_dir.exists():
        print("  Plugin not installed, skipping.", file=sys.stderr)
        return True

    if dry_run:
        print(f"  [dry-run] rm -rf {plugin_dir}", file=sys.stderr)
        return True

    shutil.rmtree(plugin_dir)
    return not plugin_dir.exists()


def main(
    keep_plugin: Annotated[
        bool,
        typer.Option("--keep-plugin", help="Keep the Claude Code plugin installed"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be done without making changes"),
    ] = False,
) -> None:
    """Uninstall pysae-ai-tools and the Claude Code plugin."""
    # Step 1: Remove Claude Code plugin
    if not keep_plugin:
        print("Removing Claude Code plugin...", file=sys.stderr)
        if _uninstall_plugin(dry_run):
            print("  Claude Code plugin removed.", file=sys.stderr)
        else:
            print("  Failed to remove plugin.", file=sys.stderr)

    # Step 2: Remove Python package via uv
    print(f"Removing {PACKAGE}...", file=sys.stderr)
    if _uninstall_package(dry_run):
        print(f"  {PACKAGE} removed.", file=sys.stderr)
    else:
        print(f"  Failed to remove {PACKAGE} (not installed or uv not found).", file=sys.stderr)
        raise typer.Exit(code=1)

    if not dry_run:
        # Check if another installation is still on PATH (e.g. editable install in .venv)
        remaining = shutil.which(PACKAGE)
        if remaining:
            print(f"\n⚠ Another installation found at {remaining}", file=sys.stderr)
            print("  This is likely an editable install in a local .venv.", file=sys.stderr)
            print(f"  To fully remove: pip uninstall {PACKAGE} (from that venv)", file=sys.stderr)
        print("\nDone. To reinstall:", file=sys.stderr)
        print("", file=sys.stderr)
        if os.name == "nt":
            print("  irm https://tools.pysae.com/pysae-ai-tools/install.ps1 | iex", file=sys.stderr)
        else:
            print("  curl -fsSL https://tools.pysae.com/pysae-ai-tools/install.sh | bash", file=sys.stderr)
        print("", file=sys.stderr)
