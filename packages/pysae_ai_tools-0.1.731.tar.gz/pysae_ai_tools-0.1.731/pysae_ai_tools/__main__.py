"""Pysae AI tools — root CLI built on click LazyGroup + typer leaves.

Subcommands are imported on demand: invoking ``pysae-ai-tools install argocd``
only imports ``pysae_ai_tools.install.argocd`` (and its deps), not
the full tree. This keeps cold start under ~150 ms for most commands.

Usage:
    pysae-ai-tools --help
    pysae-ai-tools <group> --help
    pysae-ai-tools <group> <command> [options]

Examples:
    pysae-ai-tools code changelog --write
    pysae-ai-tools install argocd check
    pysae-ai-tools glab issue-audit
    pysae-ai-tools ci run status
    pysae-ai-tools ci release next-version --bump minor
"""

import importlib
from typing import Any

import click
import typer


class LazyGroup(click.Group):
    """Click ``Group`` that imports its subcommands on demand.

    ``lazy_subcommands`` maps each CLI name to ``"module.path:attribute"``
    where the attribute is either a :class:`typer.Typer`, a
    :class:`click.Command`, or a typer-compatible function (registered as a
    single top-level command — its arguments become the command's arguments).

    Eagerly added subcommands (via :meth:`click.Group.add_command`) coexist
    with lazy ones, which lets us nest LazyGroups cheaply.
    """

    def __init__(
        self,
        *args: Any,
        lazy_subcommands: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._lazy = lazy_subcommands or {}

    def list_commands(self, ctx: click.Context) -> list[str]:
        return sorted({*super().list_commands(ctx), *self._lazy})

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        spec = self._lazy.get(cmd_name)
        if spec is None:
            return super().get_command(ctx, cmd_name)
        module_path, _, attr = spec.partition(":")
        mod = importlib.import_module(module_path)
        obj = getattr(mod, attr)
        if isinstance(obj, typer.Typer):
            return typer.main.get_command(obj)
        if isinstance(obj, click.Command):
            return obj
        # Assume a typer-compatible function: wrap as a single-command Typer
        # and unwrap the inner click command so the function's signature
        # becomes the command's signature directly.
        single = typer.Typer(add_completion=False)
        single.command(name=cmd_name)(obj)
        wrapped = typer.main.get_command(single)
        if isinstance(wrapped, click.Group) and len(wrapped.commands) == 1:
            return next(iter(wrapped.commands.values()))
        return wrapped


# ---------------------------------------------------------------------------
# Sub-group: install
# ---------------------------------------------------------------------------
install_group = LazyGroup(
    name="install",
    help="Install Pysae CLI tools and MCP servers",
    no_args_is_help=True,
    lazy_subcommands={
        "all": "pysae_ai_tools.install.all:cli",
        "claude-plugin": "pysae_ai_tools.install.claude_plugin:cli",
        "argocd": "pysae_ai_tools.install.argocd:cli",
        "aws-cli": "pysae_ai_tools.install.aws_cli:cli",
        "chrome-mcp": "pysae_ai_tools.install.chrome_mcp:cli",
        "datadog-mcp": "pysae_ai_tools.install.datadog_mcp:cli",
        "docker": "pysae_ai_tools.install.docker:cli",
        "gh": "pysae_ai_tools.install.gh:cli",
        "glab": "pysae_ai_tools.install.glab:cli",
        "helm": "pysae_ai_tools.install.helm:cli",
        "kubectl": "pysae_ai_tools.install.kubectl:cli",
        "mongo-mcp": "pysae_ai_tools.install.mongo_mcp:cli",
        "mongo-tools": "pysae_ai_tools.install.mongo_tools:cli",
        "mongodb-atlas-mcp": "pysae_ai_tools.install.mongodb_atlas_mcp:cli",
        "postman": "pysae_ai_tools.install.postman:cli",
        "postman-mcp": "pysae_ai_tools.install.postman_mcp:cli",
        "prefect": "pysae_ai_tools.install.prefect:cli",
        "terraform": "pysae_ai_tools.install.terraform:cli",
    },
)

# ---------------------------------------------------------------------------
# Sub-group: glab
# ---------------------------------------------------------------------------
glab_group = LazyGroup(
    name="glab",
    help="GitLab tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "find-issue": "pysae_ai_tools.glab.find_issue:main",
        "issue-audit": "pysae_ai_tools.glab.issue_audit.audit_issues:main",
        "mr-refresh": "pysae_ai_tools.glab.mr_refresh:main",
        "retry": "pysae_ai_tools.glab.retry:main",
        "workflow-transition": "pysae_ai_tools.glab.workflow_transition:main",
        "clone-group": "pysae_ai_tools.glab.clone_group:main",
        "epic-attach": "pysae_ai_tools.glab.epic_attach:cli",
        "epic-from-issues": "pysae_ai_tools.glab.epic_from_issues:cli",
        "epic-attach-issues": "pysae_ai_tools.glab.issue_find_epic:cli",
        "review-note": "pysae_ai_tools.glab.review_note.review_note:app",
    },
)

# ---------------------------------------------------------------------------
# Sub-group: ci (with nested ci.release)
# ---------------------------------------------------------------------------
ci_release_group = LazyGroup(
    name="release",
    help="Release tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "next-version": "pysae_ai_tools.ci.release.next_version:main",
    },
)

ci_group = LazyGroup(
    name="ci",
    help="GitLab CI/CD tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "prepare": "pysae_ai_tools.ci.prepare:main",
        "run": "pysae_ai_tools.ci.run.__main__:app",
    },
)
ci_group.add_command(ci_release_group, name="release")

# ---------------------------------------------------------------------------
# Sub-group: aws / atlas / slack
# ---------------------------------------------------------------------------
aws_group = LazyGroup(
    name="aws",
    help="AWS tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "secret-env": "pysae_ai_tools.aws.secret_env:app",
    },
)

atlas_group = LazyGroup(
    name="atlas",
    help="MongoDB Atlas tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "access-list": "pysae_ai_tools.atlas.access_list:app",
    },
)

slack_group = LazyGroup(
    name="slack",
    help="Slack tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "ask-review": "pysae_ai_tools.slack.ask_review:main",
    },
)

openapi_group = LazyGroup(
    name="openapi",
    help="OpenAPI tooling",
    no_args_is_help=True,
    lazy_subcommands={
        "to-postman": "pysae_ai_tools.openapi.to_postman:main",
    },
)

internal_group = LazyGroup(
    name="internal",
    help="Internal utilities (used by Pysae tooling itself)",
    no_args_is_help=True,
    lazy_subcommands={
        "parse-stream": "pysae_ai_tools.internal.parse_stream.parser:main",
        "detect-context": "pysae_ai_tools.internal.detect_context.detect:main",
        "webhook-reply": "pysae_ai_tools.internal.webhook_reply:app",
    },
)

code_group = LazyGroup(
    name="code",
    help="Code & repo utilities",
    no_args_is_help=True,
    lazy_subcommands={
        "changelog": "pysae_ai_tools.code.changelog:app",
    },
)


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------
def _version_callback(ctx: click.Context, _param: click.Parameter, value: bool) -> None:
    if not value or ctx.resilient_parsing:
        return
    from pysae_ai_tools import __version__

    click.echo(f"pysae-ai-tools {__version__}")
    ctx.exit()


def _build_version_callback(ctx: click.Context, _param: click.Parameter, value: bool) -> None:
    if not value or ctx.resilient_parsing:
        return
    from pysae_ai_tools import compute_version

    click.echo(compute_version(build=True))
    ctx.exit()


app = LazyGroup(
    name="pysae-ai-tools",
    help="Pysae AI tools — shared utilities for Claude Code skills.",
    no_args_is_help=True,
    params=[
        click.Option(
            ["--version"],
            is_flag=True,
            expose_value=False,
            is_eager=True,
            callback=_version_callback,
            help="Show version and exit.",
        ),
        click.Option(
            ["--build-version"],
            is_flag=True,
            expose_value=False,
            is_eager=True,
            callback=_build_version_callback,
            help="Show clean build version (no .dev suffix) and exit.",
        ),
    ],
    lazy_subcommands={
        # Top-level single commands
        "self-update": "pysae_ai_tools.self_update:main",
        "install-completion": "pysae_ai_tools.install_completion:main",
        "uninstall": "pysae_ai_tools.uninstall:main",
        # Top-level multi-command apps
        "tracker": "pysae_ai_tools.tracker.__main__:app",
    },
)
app.add_command(install_group, name="install")
app.add_command(glab_group, name="glab")
app.add_command(ci_group, name="ci")
app.add_command(aws_group, name="aws")
app.add_command(atlas_group, name="atlas")
app.add_command(slack_group, name="slack")
app.add_command(openapi_group, name="openapi")
app.add_command(internal_group, name="internal")
app.add_command(code_group, name="code")


if __name__ == "__main__":
    app()
