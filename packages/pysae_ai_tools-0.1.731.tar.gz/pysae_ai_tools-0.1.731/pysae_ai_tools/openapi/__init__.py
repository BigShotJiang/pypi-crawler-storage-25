"""OpenAPI tooling commands."""
