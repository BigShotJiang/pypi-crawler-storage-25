"""Find an existing review request message in a Slack channel.

Usage:
    pysae-ai-tools slack ask-review \
        --channel C0123ABCDEF \
        --project-url https://gitlab.com/pysae/api \
        --mr-iid 42

Calls the Slack conversations.history API directly (requires SLACK_BOT_TOKEN).
Searches the last 30 days of messages for one containing the full MR URL
(project_url/-/merge_requests/iid), avoiding conflicts between projects
sharing the same Slack channel.

Output (JSON, one line):
    {"found": true, "ts": "...", "thread_ts": "...", "text": "...", "user": "U..."}
    {"found": false}
"""

import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Annotated

import typer

SLACK_API_BASE = "https://slack.com/api"
SEARCH_WINDOW_DAYS = 30
PAGE_LIMIT = 200


@dataclass
class MatchResult:
    found: bool
    ts: str = ""
    thread_ts: str = ""
    text: str = ""
    user: str = ""

    def to_json(self) -> str:
        if not self.found:
            return json.dumps({"found": False})
        return json.dumps(
            {
                "found": True,
                "ts": self.ts,
                "thread_ts": self.thread_ts or self.ts,
                "text": self.text,
                "user": self.user,
            }
        )


def _slack_get(token: str, method: str, params: dict[str, str]) -> dict[str, object]:
    """Call a Slack Web API method (GET)."""
    qs = urllib.parse.urlencode(params)
    url = f"{SLACK_API_BASE}/{method}?{qs}"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data: dict[str, object] = json.loads(resp.read())
    if not data.get("ok"):
        error = data.get("error", "unknown")
        raise RuntimeError(f"Slack API error: {error}")
    return data


def build_mr_url(project_url: str, mr_iid: int) -> str:
    """Build the full GitLab MR URL from project URL and IID."""
    return f"{project_url.rstrip('/')}/-/merge_requests/{mr_iid}"


def _build_pattern(mr_url: str) -> re.Pattern[str]:
    """Build a regex that matches the full MR URL in message text.

    Slack wraps URLs in <url> or <url|label>, so the URL may appear
    inside angle brackets or followed by a pipe. The escaped URL
    handles this naturally since we just need a substring match.
    """
    return re.compile(re.escape(mr_url) + r"(?!\d)")


def _extract_text(msg: dict[str, object]) -> str:
    """Extract all searchable text from a Slack message."""
    parts = [str(msg.get("text", ""))]
    attachments = msg.get("attachments")
    if isinstance(attachments, list):
        for att in attachments:
            if isinstance(att, dict):
                parts.append(str(att.get("text", "")))
                parts.append(str(att.get("fallback", "")))
    return " ".join(parts)


def find_in_messages(messages: list[dict[str, object]], mr_url: str) -> MatchResult:
    """Search a list of Slack messages for one containing the MR URL.

    Useful for testing without hitting the Slack API.
    """
    pattern = _build_pattern(mr_url)
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        text = _extract_text(msg)
        if pattern.search(text):
            ts = str(msg.get("ts", ""))
            return MatchResult(
                found=True,
                ts=ts,
                thread_ts=str(msg.get("thread_ts", "") or ts),
                text=str(msg.get("text", "")),
                user=str(msg.get("user", "")),
            )
    return MatchResult(found=False)


def fetch_and_search(token: str, channel: str, mr_url: str) -> MatchResult:
    """Paginate through channel history and return the first message matching the MR URL."""
    oldest = str(int(time.time()) - SEARCH_WINDOW_DAYS * 86400)
    cursor: str | None = None

    while True:
        params: dict[str, str] = {
            "channel": channel,
            "oldest": oldest,
            "limit": str(PAGE_LIMIT),
            "inclusive": "true",
        }
        if cursor:
            params["cursor"] = cursor

        data = _slack_get(token, "conversations.history", params)
        messages = data.get("messages")
        if not isinstance(messages, list):
            break

        result = find_in_messages(messages, mr_url)
        if result.found:
            return result

        # Pagination
        meta = data.get("response_metadata")
        if isinstance(meta, dict):
            next_cursor = meta.get("next_cursor")
            if isinstance(next_cursor, str) and next_cursor:
                cursor = next_cursor
                continue
        break

    return MatchResult(found=False)


cli = typer.Typer()


@cli.command()
def main(
    channel: Annotated[str, typer.Option("--channel", help="Slack channel ID")],
    project_url: Annotated[
        str, typer.Option("--project-url", help="GitLab project URL (e.g. https://gitlab.com/pysae/api)")
    ],
    mr_iid: Annotated[int, typer.Option("--mr-iid", help="GitLab MR IID")],
) -> None:
    """Find the Slack review-request message for a GitLab MR."""
    token = os.environ.get("SLACK_BOT_TOKEN", "")
    if not token:
        print(json.dumps({"found": False, "error": "SLACK_BOT_TOKEN not set"}))
        sys.exit(1)

    mr_url = build_mr_url(project_url, mr_iid)

    try:
        result = fetch_and_search(token, channel, mr_url)
    except (RuntimeError, urllib.error.URLError) as e:
        print(json.dumps({"found": False, "error": str(e)}))
        sys.exit(1)

    print(result.to_json())


if __name__ == "__main__":
    cli()
