#!/usr/bin/env python3
"""Clone all repositories from a GitLab group and its subgroups.

For each project found:
- If the directory does not exist: clone it.
- If it exists and is a git repo: verify the remote URL matches, fix it if needed, then pull.
- If it exists but is not a git repo: skip with a warning.

Usage:
    pysae-ai-tools clone_group.clone [OPTIONS]

Examples:
    pysae-ai-tools clone_group.clone
    pysae-ai-tools clone_group.clone --base-dir ~/projects
    pysae-ai-tools clone_group.clone --protocol https --dry-run
"""

import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Any

import typer

from ..common.glab.fetch_issues import PYSAE_GROUP, PYSAE_GROUP_ID, glab_api_paginated


@dataclass
class Project:
    """A GitLab project with its full path."""

    id: int
    path_with_namespace: str
    ssh_url: str
    http_url: str
    archived: bool

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Project":
        return cls(
            id=data["id"],
            path_with_namespace=data["path_with_namespace"],
            ssh_url=data.get("ssh_url_to_repo", ""),
            http_url=data.get("http_url_to_repo", ""),
            archived=data.get("archived", False),
        )

    def url(self, protocol: str) -> str:
        return self.ssh_url if protocol == "ssh" else self.http_url


def fetch_all_projects(group_id: int, include_archived: bool = False) -> list[Project]:
    """Fetch all projects in a group and its subgroups via glab API."""
    endpoint = f"groups/{group_id}/projects?include_subgroups=true&per_page=100"
    if not include_archived:
        endpoint += "&archived=false"
    raw = glab_api_paginated(endpoint)
    return [Project.from_api(p) for p in raw]


def get_remote_url(repo_dir: Path, remote: str = "origin") -> str | None:
    """Get the URL of a git remote, or None if not found."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_dir), "remote", "get-url", remote],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except subprocess.TimeoutExpired:
        pass
    return None


def set_remote_url(repo_dir: Path, url: str, remote: str = "origin") -> bool:
    """Set the URL of a git remote. Returns True on success."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "remote", "set-url", remote, url],
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.returncode == 0


def normalize_url(url: str) -> str:
    """Normalize a git URL for comparison (strip trailing .git and slashes)."""
    return url.rstrip("/").removesuffix(".git")


def _get_default_branch(repo_dir: Path) -> str | None:
    """Get the default branch name from origin/HEAD (e.g. 'main' or 'master')."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "symbolic-ref", "refs/remotes/origin/HEAD"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode == 0:
        # Output like "refs/remotes/origin/main"
        return result.stdout.strip().removeprefix("refs/remotes/origin/")
    # Fallback: try to set origin/HEAD from remote, then retry
    subprocess.run(
        ["git", "-C", str(repo_dir), "remote", "set-head", "origin", "--auto"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "symbolic-ref", "refs/remotes/origin/HEAD"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode == 0:
        return result.stdout.strip().removeprefix("refs/remotes/origin/")
    return None


def _get_current_branch(repo_dir: Path) -> str | None:
    """Get the current branch name, or None if in detached HEAD."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "branch", "--show-current"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    return None


def _get_tracking_branch(repo_dir: Path) -> str | None:
    """Get the upstream tracking branch (e.g. 'origin/main'), or None."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    return None


def _remote_branch_exists(repo_dir: Path, branch: str) -> bool:
    """Check if a remote branch exists after a fetch."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "rev-parse", "--verify", f"refs/remotes/origin/{branch}"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.returncode == 0


def _checkout_default_branch_if_needed(repo_dir: Path) -> str | None:
    """If the current branch tracks a deleted remote branch, checkout the default branch.

    Returns the name of the branch switched to, or None if no switch was needed.
    """
    current = _get_current_branch(repo_dir)
    if current is None:
        return None  # detached HEAD, skip

    default = _get_default_branch(repo_dir)
    if default is None:
        return None

    if current == default:
        return None  # already on default branch

    # Check if the current branch's upstream still exists on the remote
    tracking = _get_tracking_branch(repo_dir)
    if tracking is not None and _remote_branch_exists(repo_dir, tracking.removeprefix("origin/")):
        return None  # upstream exists, no need to switch

    # Upstream is gone or not set — switch to default branch
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "checkout", default],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode == 0:
        return default
    return None


def _has_local_changes(repo_dir: Path) -> bool:
    """Check if the repo has uncommitted changes (staged or unstaged)."""
    result = subprocess.run(
        ["git", "-C", str(repo_dir), "status", "--porcelain"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    return bool(result.stdout.strip())


def _do_pull(repo_dir: Path) -> str:
    """Pull with rebase, stashing local changes if needed.

    If rebase conflicts, aborts the rebase to leave the repo clean.
    Returns 'pulled', 'pulled (stashed)', or 'pull-error: ...'.
    """
    stashed = False
    try:
        # Stash local changes if any
        if _has_local_changes(repo_dir):
            stash_result = subprocess.run(
                ["git", "-C", str(repo_dir), "stash", "--include-untracked"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if stash_result.returncode != 0:
                return f"pull-error: stash failed -- {stash_result.stderr.strip()[:60]}"
            stashed = True

        # Pull with rebase
        result = subprocess.run(
            ["git", "-C", str(repo_dir), "pull", "--rebase", "--quiet"],
            capture_output=True,
            text=True,
            timeout=60,
        )

        if result.returncode != 0:
            # Abort rebase to leave repo clean
            subprocess.run(
                ["git", "-C", str(repo_dir), "rebase", "--abort"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            # Restore stashed changes
            if stashed:
                subprocess.run(
                    ["git", "-C", str(repo_dir), "stash", "pop"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
            return f"pull-conflict: rebase aborted -- {result.stderr.strip()[:60]}"

        # Restore stashed changes
        if stashed:
            pop_result = subprocess.run(
                ["git", "-C", str(repo_dir), "stash", "pop"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if pop_result.returncode != 0:
                return f"pulled but stash-pop-conflict: {pop_result.stderr.strip()[:60]}"
            return "pulled (stashed)"

        return "pulled"
    except subprocess.TimeoutExpired:
        if stashed:
            subprocess.run(
                ["git", "-C", str(repo_dir), "rebase", "--abort"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            subprocess.run(
                ["git", "-C", str(repo_dir), "stash", "pop"],
                capture_output=True,
                text=True,
                timeout=10,
            )
        return "pull-error: timeout"


def process_project(project: Project, base_dir: Path, protocol: str, dry_run: bool) -> str:
    """Process a single project: clone if missing, or verify remote and pull if existing.

    Returns a status string.
    """
    repo_dir = base_dir / project.path_with_namespace
    expected_url = project.url(protocol)

    if not expected_url:
        return "error: no URL"

    # Case 1: directory does not exist -> clone
    if not repo_dir.exists():
        if dry_run:
            return "would clone"
        repo_dir.parent.mkdir(parents=True, exist_ok=True)
        try:
            result = subprocess.run(
                ["git", "clone", "--quiet", expected_url, str(repo_dir)],
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode == 0:
                return "cloned"
            return f"clone-error: {result.stderr.strip()[:100]}"
        except subprocess.TimeoutExpired:
            return "clone-error: timeout"

    # Case 2: directory exists but is not a git repo
    if not (repo_dir / ".git").is_dir():
        return "skipped: not a git repo"

    # Case 3: directory exists and is a git repo -> check remote
    current_url = get_remote_url(repo_dir)
    remote_status = ""

    if current_url is None:
        if dry_run:
            return "would add remote"
        subprocess.run(
            ["git", "-C", str(repo_dir), "remote", "add", "origin", expected_url],
            capture_output=True,
            text=True,
            timeout=10,
        )
        remote_status = "remote-added"
    elif normalize_url(current_url) != normalize_url(expected_url):
        if dry_run:
            return f"would fix remote: {current_url} -> {expected_url}"
        set_remote_url(repo_dir, expected_url)
        remote_status = f"remote-fixed: {current_url} -> {expected_url}"
    else:
        remote_status = "remote-ok"

    # Fetch to update remote refs before checking branch state
    subprocess.run(
        ["git", "-C", str(repo_dir), "fetch", "--prune", "--quiet"],
        capture_output=True,
        text=True,
        timeout=60,
    )

    # Switch to default branch if current branch tracks a deleted remote branch
    switched_to = _checkout_default_branch_if_needed(repo_dir)
    branch_note = f", switched to {switched_to}" if switched_to else ""

    # Pull
    if dry_run:
        return f"would pull ({remote_status}{branch_note})"
    pull_status = _do_pull(repo_dir)
    return f"{pull_status} ({remote_status}{branch_note})"


STATUS_SYMBOLS: dict[str, str] = {
    "cloned": "+",
    "pulled": "=",
    "would clone": "?",
    "would pull": "~",
}

cli = typer.Typer()


@cli.command()
def main(
    base_dir: Annotated[
        str,
        typer.Option("--base-dir", help="Base directory for cloning (default: ~/projects)"),
    ] = str(Path.home() / "projects"),
    group: Annotated[
        str,
        typer.Option("--group", help=f"GitLab group path (default: {PYSAE_GROUP})"),
    ] = PYSAE_GROUP,
    group_id: Annotated[
        int,
        typer.Option("--group-id", help=f"GitLab group ID (default: {PYSAE_GROUP_ID})"),
    ] = PYSAE_GROUP_ID,
    protocol: Annotated[
        str,
        typer.Option("--protocol", help="Git protocol for cloning: ssh or https (default: https)"),
    ] = "https",
    include_archived: Annotated[
        bool,
        typer.Option("--include-archived", help="Include archived repositories"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be done without actually cloning/pulling"),
    ] = False,
) -> None:
    """Clone all GitLab repos from a group, preserving subgroup structure."""
    base_path = Path(base_dir)
    print(f"Fetching projects from group {group} (ID: {group_id})...", file=sys.stderr)

    projects = fetch_all_projects(group_id, include_archived=include_archived)
    projects.sort(key=lambda p: p.path_with_namespace)

    print(f"Found {len(projects)} projects.", file=sys.stderr)

    results: dict[str, list[str]] = {}
    for i, project in enumerate(projects, 1):
        status = process_project(project, base_path, protocol, dry_run)
        # Group by simplified status (strip details after colon for summary)
        key = status.split("(")[0].strip() if "(" in status else status
        results.setdefault(key, []).append(project.path_with_namespace)
        # Pick symbol
        symbol = "!"
        for prefix, sym in STATUS_SYMBOLS.items():
            if status.startswith(prefix):
                symbol = sym
                break
        print(f"  [{i}/{len(projects)}] {symbol} {project.path_with_namespace} -- {status}", file=sys.stderr)

    # Summary as JSON to stdout
    summary = {
        "base_dir": str(base_path),
        "group": group,
        "total": len(projects),
        "results": {k: len(v) for k, v in sorted(results.items())},
        "projects": {k: sorted(v) for k, v in sorted(results.items())},
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    cli()
