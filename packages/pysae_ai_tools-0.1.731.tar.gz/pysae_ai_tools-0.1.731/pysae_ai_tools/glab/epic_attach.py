"""Attach one or more issues to a GitLab epic.

Uses the Epic Issues REST API (POST /groups/:group_id/epics/:epic_iid/issues/:issue_id).

Usage:
    pysae-ai-tools glab epic-attach --epic 236 --issue api#2499 --issue api#2498
    pysae-ai-tools glab epic-attach --epic 236 --issue 14373578#2499
"""

import json
import re
import sys
from typing import Annotated

import typer

from ..common.glab.fetch_issues import run_glab

PYSAE_GROUP_ID = 918966

# Map short project names to IDs (populated on demand)
_project_id_cache: dict[str, int] = {}


def _resolve_project_id(project_ref: str) -> int:
    """Resolve a project reference to a numeric ID.

    Accepts:
    - Numeric ID: "14373578"
    - Short name: "api", "op", "driver"
    - Full path: "pysae/api", "pysae/shift/app"
    """
    if project_ref.isdigit():
        return int(project_ref)

    if project_ref in _project_id_cache:
        return _project_id_cache[project_ref]

    # Try as full path or prepend pysae/
    path = project_ref if "/" in project_ref else f"pysae/{project_ref}"
    encoded = path.replace("/", "%2F")
    raw = run_glab("api", f"projects/{encoded}", allow_fail=True)
    if raw:
        data = json.loads(raw)
        pid = int(data["id"])
        _project_id_cache[project_ref] = pid
        return pid

    print(f"Projet introuvable : {project_ref}", file=sys.stderr)
    raise typer.Exit(code=1)


def _parse_issue_ref(ref: str) -> tuple[int, int]:
    """Parse an issue reference like 'api#2499' or '14373578#2499'.

    Returns (project_id, issue_iid).
    """
    match = re.match(r"^([^#]+)#(\d+)$", ref)
    if not match:
        print(f"Format invalide : {ref!r} — attendu : projet#iid (ex : api#2499)", file=sys.stderr)
        raise typer.Exit(code=1)

    project_ref, iid_str = match.group(1), match.group(2)
    project_id = _resolve_project_id(project_ref)
    return project_id, int(iid_str)


def _get_issue_global_id(project_id: int, iid: int) -> int:
    """Get the global issue ID from project_id and IID."""
    raw = run_glab("api", f"projects/{project_id}/issues/{iid}", allow_fail=True)
    if not raw:
        print(f"Issue introuvable : projet {project_id}, IID {iid}", file=sys.stderr)
        raise typer.Exit(code=1)
    data = json.loads(raw)
    return int(data["id"])


def _attach_issue(epic_iid: int, project_id: int, iid: int, global_id: int) -> bool:
    """Attach a single issue to an epic. Returns True on success."""
    raw = run_glab(
        "api",
        "-X",
        "POST",
        f"groups/{PYSAE_GROUP_ID}/epics/{epic_iid}/issues/{global_id}",
        allow_fail=True,
    )
    if raw:
        data = json.loads(raw)
        if data.get("issue", {}).get("iid") == iid:
            return True
    return False


cli = typer.Typer(help="Attach issues to a GitLab epic")


@cli.command()
def main(
    epic: Annotated[int, typer.Option("--epic", help="Epic IID to attach issues to")],
    issues: Annotated[
        list[str],
        typer.Option("--issue", help="Issue reference as project#iid (repeatable, e.g. api#2499)"),
    ],
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Report what would be done without making changes"),
    ] = False,
) -> None:
    """Attach one or more issues to a GitLab epic."""
    success = 0
    errors = 0

    for ref in issues:
        project_id, iid = _parse_issue_ref(ref)
        global_id = _get_issue_global_id(project_id, iid)

        if dry_run:
            print(f"  [dry-run] {ref} (id={global_id}) → epic #{epic}")
            success += 1
            continue

        if _attach_issue(epic, project_id, iid, global_id):
            print(f"  {ref} → epic #{epic} ✓", file=sys.stderr)
            success += 1
        else:
            print(f"  {ref} → erreur (type incompatible ou déjà rattaché)", file=sys.stderr)
            errors += 1

    result = {"epic_iid": epic, "attached": success, "errors": errors, "total": len(issues)}
    print(json.dumps(result, indent=2))

    if errors:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    cli()
