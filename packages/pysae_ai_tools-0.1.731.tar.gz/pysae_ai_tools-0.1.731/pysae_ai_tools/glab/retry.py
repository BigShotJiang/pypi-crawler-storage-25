"""Retry wrapper for glab commands that hang (especially create operations).

Usage:
    pysae-ai-tools glab retry <glab-args...>

Examples:
    pysae-ai-tools glab retry mr create --title "Fix" --yes --no-editor
    pysae-ai-tools glab retry issue create --title "Bug" --yes --no-editor

Behavior:
    1. Run glab with timeout (default 15s), retry up to 3 times
    2. Kill lingering glab processes after each timeout
    3. On total failure, fall back to GitLab API (POST via glab api)
    4. Print the created resource URL to stdout
"""

import json
import subprocess
import sys
from typing import Annotated

import typer

MAX_ATTEMPTS = 3
TIMEOUT_SECONDS = 15


def _kill_lingering_glab(command_hint: str) -> None:
    """Kill any lingering glab processes matching the command."""
    subprocess.run(["pkill", "-f", f"glab {command_hint}"], capture_output=True)


def _run_with_timeout(args: list[str], timeout: int = TIMEOUT_SECONDS) -> subprocess.CompletedProcess[str]:
    """Run a command with timeout, returning the CompletedProcess."""
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
        stdin=subprocess.DEVNULL,
    )


def _extract_url(output: str) -> str:
    """Extract a GitLab URL from glab output."""
    for line in output.splitlines():
        for word in line.strip().split():
            if word.startswith("http") and "gitlab.com" in word:
                return word
    return ""


def _get_project_id() -> str:
    """Get the current project's numeric ID via glab."""
    result = subprocess.run(
        ["glab", "repo", "view", "--output", "json"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode != 0:
        return ""
    try:
        return str(json.loads(result.stdout)["id"])
    except (json.JSONDecodeError, KeyError):
        return ""


def _parse_glab_args(args: list[str]) -> dict[str, str]:
    """Parse glab CLI args into a dict of flag->value pairs."""
    parsed: dict[str, str] = {}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("--"):
            if "=" in arg:
                key, value = arg.split("=", 1)
                parsed[key.lstrip("-")] = value
            elif i + 1 < len(args) and not args[i + 1].startswith("--"):
                parsed[arg.lstrip("-")] = args[i + 1]
                i += 1
            else:
                # Boolean flag (e.g. --remove-source-branch)
                parsed[arg.lstrip("-")] = ""
        i += 1
    return parsed


def _api_fallback_mr(glab_args: list[str]) -> str:
    """Create MR via GitLab API as fallback."""
    project_id = _get_project_id()
    if not project_id:
        return ""

    parsed = _parse_glab_args(glab_args)
    payload: list[str] = ["api", "-X", "POST", f"projects/{project_id}/merge_requests"]

    field_map = {
        "source-branch": "source_branch",
        "target-branch": "target_branch",
        "title": "title",
        "description": "description",
        "assignee-id": "assignee_id",
    }
    for cli_flag, api_field in field_map.items():
        if cli_flag in parsed:
            payload.extend(["-f", f"{api_field}={parsed[cli_flag]}"])

    if "remove-source-branch" in parsed:
        payload.extend(["-f", "remove_source_branch=true"])

    result = subprocess.run(
        ["glab", *payload],
        capture_output=True,
        text=True,
        timeout=30,
        stdin=subprocess.DEVNULL,
    )
    if result.returncode != 0:
        return ""
    try:
        return str(json.loads(result.stdout).get("web_url", ""))
    except json.JSONDecodeError:
        return ""


def _api_fallback_issue(glab_args: list[str]) -> str:
    """Create issue via GitLab API as fallback."""
    project_id = _get_project_id()
    if not project_id:
        return ""

    parsed = _parse_glab_args(glab_args)
    payload: list[str] = ["api", "-X", "POST", f"projects/{project_id}/issues"]

    for cli_flag in ("title", "description"):
        if cli_flag in parsed:
            payload.extend(["-f", f"{cli_flag}={parsed[cli_flag]}"])

    result = subprocess.run(
        ["glab", *payload],
        capture_output=True,
        text=True,
        timeout=30,
        stdin=subprocess.DEVNULL,
    )
    if result.returncode != 0:
        return ""
    try:
        return str(json.loads(result.stdout).get("web_url", ""))
    except json.JSONDecodeError:
        return ""


def run(glab_args: list[str]) -> None:
    """Run a glab command with retry logic and API fallback.

    Prints the resource URL on success, exits with code 1 on failure.
    """
    full_cmd = ["glab", *glab_args]
    command_hint = " ".join(glab_args[:2])

    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            result = _run_with_timeout(full_cmd)
            if result.returncode == 0:
                url = _extract_url(result.stdout)
                if url:
                    print(url)
                else:
                    print(result.stdout.strip())
                return
            print(
                f"Attempt {attempt}/{MAX_ATTEMPTS} failed (exit {result.returncode}): " f"{result.stderr.strip()}",
                file=sys.stderr,
            )
        except subprocess.TimeoutExpired:
            print(f"Attempt {attempt}/{MAX_ATTEMPTS} timed out after {TIMEOUT_SECONDS}s", file=sys.stderr)
            _kill_lingering_glab(command_hint)

    # All attempts failed -- try API fallback
    print("All attempts failed, falling back to GitLab API...", file=sys.stderr)

    url = ""
    if glab_args[:2] == ["mr", "create"]:
        url = _api_fallback_mr(glab_args)
    elif glab_args[:2] == ["issue", "create"]:
        url = _api_fallback_issue(glab_args)

    if url:
        print(url)
    else:
        print("ERROR: all retry attempts and API fallback failed", file=sys.stderr)
        sys.exit(1)


def main(
    glab_args: Annotated[list[str], typer.Argument(help="Arguments forwarded to glab")],
) -> None:
    """Retry wrapper for glab commands that hang."""
    if not glab_args:
        print("Usage: pysae-ai-tools glab retry <glab-args...>", file=sys.stderr)
        sys.exit(1)
    run(glab_args)
