"""Find, create, or update the single Claude review note on a GitLab MR.

Usage:
    pysae-ai-tools glab review-note find <MR_IID>
    pysae-ai-tools glab review-note upsert <MR_IID>        # reads body from stdin
    pysae-ai-tools glab review-note add-reviewer <MR_IID>
"""

import json
import re
import sys
from dataclasses import dataclass
from typing import Annotated

import typer

from ...common.glab.fetch_issues import run_glab

app = typer.Typer(help="Manage the single Claude review note on a GitLab MR")

MARKER = "<!-- claude-review -->"

# Match bare #<number> that GitLab would auto-link as issue/MR references.
# Negative lookbehind: don't touch already-escaped \#, HTML entities &#, or URLs with #.
_BARE_ISSUE_REF_RE = re.compile(r"(?<!\\)(?<!&)#(\d+)")


def _escape_gitlab_refs(body: str) -> str:
    """Escape bare #N references to prevent GitLab auto-linking."""
    return _BARE_ISSUE_REF_RE.sub(r"\#\1", body)


@dataclass
class ReviewNote:
    id: int
    body: str


def _get_project_id() -> str:
    raw = run_glab("repo", "view", "--output", "json")
    return str(json.loads(raw)["id"])


def _get_current_user_id() -> int:
    raw = run_glab("api", "user")
    return int(json.loads(raw)["id"])


def find_review_notes(project_id: str, mr_iid: str) -> list[ReviewNote]:
    """Find all Claude review notes on a MR, ordered by preference.

    Priority: own notes first (current user), then others.
    Within each group, most recently created first (highest ID).
    """
    raw = run_glab("api", f"projects/{project_id}/merge_requests/{mr_iid}/notes?per_page=100")
    notes = json.loads(raw)
    current_user_id = _get_current_user_id()

    own: list[ReviewNote] = []
    others: list[ReviewNote] = []

    for note in notes:
        if MARKER in note.get("body", ""):
            review_note = ReviewNote(id=note["id"], body=note["body"])
            if note.get("author", {}).get("id") == current_user_id:
                own.append(review_note)
            else:
                others.append(review_note)

    # Most recent first within each group
    own.sort(key=lambda n: n.id, reverse=True)
    others.sort(key=lambda n: n.id, reverse=True)

    return own + others


def find_note(project_id: str, mr_iid: str) -> ReviewNote | None:
    """Find the best Claude review note on a MR (own first, then others)."""
    candidates = find_review_notes(project_id, mr_iid)
    return candidates[0] if candidates else None


def upsert_note(project_id: str, mr_iid: str, body: str) -> str:
    """Create or update the review note. Returns 'created' or 'updated:<note_id>'.

    Tries to PUT each candidate note in preference order (own first, then others).
    If all PUTs fail (403), creates a new note.
    """
    body = _escape_gitlab_refs(body)
    if MARKER not in body:
        body = f"{body}\n\n{MARKER}"

    for candidate in find_review_notes(project_id, mr_iid):
        result = run_glab(
            "api",
            "-X",
            "PUT",
            f"projects/{project_id}/merge_requests/{mr_iid}/notes/{candidate.id}",
            "-f",
            f"body={body}",
            allow_fail=True,
        )
        if result:
            return f"updated:{candidate.id}"

    run_glab("mr", "note", mr_iid, "-m", body)
    return "created"


def add_reviewer(project_id: str, mr_iid: str) -> str:
    """Add current user as MR reviewer. Returns 'added', 'already-reviewer', or 'is-author'."""
    current_user_id = _get_current_user_id()
    raw = run_glab("api", f"projects/{project_id}/merge_requests/{mr_iid}")
    mr_data = json.loads(raw)

    if mr_data.get("author", {}).get("id") == current_user_id:
        return "is-author"

    existing_ids = [r["id"] for r in mr_data.get("reviewers", [])]
    if current_user_id in existing_ids:
        return "already-reviewer"

    all_ids = sorted(set(existing_ids + [current_user_id]))
    args = ["api", "-X", "PUT", f"projects/{project_id}/merge_requests/{mr_iid}"]
    for rid in all_ids:
        args.extend(["-f", f"reviewer_ids[]={rid}"])
    run_glab(*args)
    return "added"


@app.command()
def find(mr_iid: Annotated[str, typer.Argument(help="MR IID")]) -> None:
    """Find the existing Claude review note (prints NONE or JSON)."""
    project_id = _get_project_id()
    note = find_note(project_id, mr_iid)
    if note is None:
        print("NONE")
    else:
        print(json.dumps({"id": note.id, "body": note.body}))


@app.command()
def upsert(mr_iid: Annotated[str, typer.Argument(help="MR IID")]) -> None:
    """Create or update the Claude review note (reads body from stdin)."""
    project_id = _get_project_id()
    body = sys.stdin.read()
    print(upsert_note(project_id, mr_iid, body))


@app.command(name="add-reviewer")
def add_reviewer_cmd(mr_iid: Annotated[str, typer.Argument(help="MR IID")]) -> None:
    """Add the current user as reviewer on the MR."""
    project_id = _get_project_id()
    print(add_reviewer(project_id, mr_iid))


if __name__ == "__main__":
    app()
