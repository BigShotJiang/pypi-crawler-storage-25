"""Constants and display mappings for the audit."""

from ...common.references.gitlab_labels import (
    BoardLabel,
    TypeLabel,
)

TEMPLATES_PROJECT = "pysae/issue-templates"

BOARD_LABELS: set[str] = set(BoardLabel)

TYPE_TO_TEMPLATE: dict[str, str] = {
    TypeLabel.BUG: "bug",
    TypeLabel.FEATURE: "feature",
    TypeLabel.TECHNICAL: "technical",
    TypeLabel.REFACTORING: "technical",  # refactoring uses technical template
}

METHOD_DISPLAY: dict[str, str] = {
    "project": "projet",
    "keywords": "mots-clés",
    "claude": "Claude",
}
