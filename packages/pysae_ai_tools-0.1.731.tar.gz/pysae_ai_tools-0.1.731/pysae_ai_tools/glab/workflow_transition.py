"""Transition a GitLab issue's board column label.

Usage:
    pysae-ai-tools workflow_transition <ISSUE_IID> <LABEL>

Examples:
    pysae-ai-tools workflow_transition 123 Refinement
    pysae-ai-tools workflow_transition 123 Ready
    pysae-ai-tools workflow_transition 123 "workflow::In progress"
    pysae-ai-tools workflow_transition 456 "workflow::Under review"
    pysae-ai-tools workflow_transition 789 "workflow::To deploy"

Valid labels (exact or alias):
    Refinement, Ready, workflow::To Do, workflow::In progress,
    workflow::Under review, workflow::To deploy
    Aliases: "in progress", "under review", "to do", "to deploy",
    "review", "todo", "in_progress", etc.

The script:
1. Resolves the project ID (from detect_context or glab repo view)
2. Fetches the issue's current labels
3. Removes all existing board column labels
4. Adds the new workflow label
5. Prints the resulting label or "skipped" if already set
"""

import json
import subprocess
from typing import Annotated

import typer

from ..common.references.gitlab_labels import BoardLabel
from ..internal.detect_context.detect import DetectArgs, detect

BOARD_LABELS: set[str] = set(BoardLabel)

# Aliases: lowercase key -> exact BoardLabel value
LABEL_ALIASES: dict[str, str] = {
    "refinement": BoardLabel.REFINEMENT,
    "ready": BoardLabel.READY,
    "to do": BoardLabel.TO_DO,
    "todo": BoardLabel.TO_DO,
    "to_do": BoardLabel.TO_DO,
    "in progress": BoardLabel.IN_PROGRESS,
    "in_progress": BoardLabel.IN_PROGRESS,
    "under review": BoardLabel.UNDER_REVIEW,
    "under_review": BoardLabel.UNDER_REVIEW,
    "review": BoardLabel.UNDER_REVIEW,
    "to deploy": BoardLabel.TO_DEPLOY,
    "to_deploy": BoardLabel.TO_DEPLOY,
}


def _run_glab(*args: str, timeout: int = 15) -> str | None:
    """Run a glab command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["glab", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _get_project_id() -> str:
    """Get project ID from detect_context or glab."""
    # Try detect_context
    try:
        args = DetectArgs()
        ctx = detect(args)
        if ctx.project_id:
            return ctx.project_id
    except Exception:
        pass

    # Fallback to glab
    raw = _run_glab("repo", "view", "--output", "json")
    if raw:
        try:
            return str(json.loads(raw)["id"])
        except (json.JSONDecodeError, KeyError):
            pass
    return ""


def _resolve_label(label_input: str) -> str:
    """Resolve a label input to the exact BoardLabel value.

    Accepts exact labels (e.g. "workflow::In progress") or aliases (e.g. "in progress", "review").
    Returns the resolved label or empty string if invalid.
    """
    stripped = label_input.strip()

    # Exact match first
    if stripped in BOARD_LABELS:
        return stripped

    # Alias lookup (case-insensitive)
    lower = stripped.lower()
    if lower in LABEL_ALIASES:
        return LABEL_ALIASES[lower]

    return ""


def transition(issue_iid: str, new_label: str, project_id: str = "") -> str:
    """Transition an issue's board label. Returns the action taken.

    Returns:
        "set:<label>" on success, "skipped:already-set" if already correct,
        "error:<reason>" on failure.
    """
    if not project_id:
        project_id = _get_project_id()
    if not project_id:
        return "error:no-project-id"

    resolved = _resolve_label(new_label)
    if not resolved:
        valid = ", ".join(b.value for b in BoardLabel)
        return f"error:invalid-label:{new_label} (valid: {valid})"

    # Fetch current labels
    raw = _run_glab("api", f"projects/{project_id}/issues/{issue_iid}")
    if not raw:
        return "error:cannot-fetch-issue"

    try:
        issue_data = json.loads(raw)
        current_labels: list[str] = issue_data.get("labels", [])
    except json.JSONDecodeError:
        return "error:invalid-json"

    # Check if already set
    if resolved in current_labels:
        return "skipped:already-set"

    # Find board labels to remove
    to_remove = [lbl for lbl in current_labels if lbl in BOARD_LABELS]
    remove_str = ",".join(to_remove) if to_remove else ""

    # Apply transition
    api_args = ["api", "-X", "PUT", f"projects/{project_id}/issues/{issue_iid}"]
    if remove_str:
        api_args.extend(["-f", f"remove_labels={remove_str}"])
    api_args.extend(["-f", f"add_labels={resolved}"])

    result = _run_glab(*api_args)
    if result is not None:
        return f"set:{resolved}"
    return "error:api-call-failed"


def main(
    issue_iid: Annotated[str, typer.Argument(help="Issue IID to transition")],
    label: Annotated[list[str], typer.Argument(help="New workflow label (supports multi-word labels)")],
) -> None:
    """Transition a GitLab issue's board column label."""
    new_label = " ".join(label)

    result = transition(issue_iid, new_label)
    print(result)

    if result.startswith("error:"):
        raise typer.Exit(code=1)
