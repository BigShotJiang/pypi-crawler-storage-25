"""List open merge requests for a project, filtered by author.

Usage:
    pysae-ai-tools glab mr-refresh [--author USERNAME] [--project PROJECT_PATH]

Without --author, defaults to the current authenticated user (--me).

Output (JSON, one object per line):
    {"iid": 42, "title": "...", "source_branch": "...", "target_branch": "...", "author": "...", "web_url": "..."}
"""

import json
import sys
from dataclasses import dataclass
from typing import Annotated

import typer

from ..common.glab.fetch_issues import run_glab


@dataclass
class MergeRequestSummary:
    iid: int
    title: str
    source_branch: str
    target_branch: str
    author: str
    web_url: str
    has_conflicts: bool

    def to_json(self) -> str:
        return json.dumps(
            {
                "iid": self.iid,
                "title": self.title,
                "source_branch": self.source_branch,
                "target_branch": self.target_branch,
                "author": self.author,
                "web_url": self.web_url,
                "has_conflicts": self.has_conflicts,
            }
        )


def get_current_username() -> str:
    """Get the authenticated GitLab username."""
    data = json.loads(run_glab("api", "user"))
    return str(data["username"])


def get_project_id() -> str:
    """Get the current project ID from glab."""
    data = json.loads(run_glab("repo", "view", "--output", "json"))
    return str(data["id"])


def list_open_mrs(project_id: str, author_username: str | None = None) -> list[MergeRequestSummary]:
    """List open MRs for a project, optionally filtered by author."""
    endpoint = f"projects/{project_id}/merge_requests?state=opened&per_page=100"
    if author_username:
        endpoint += f"&author_username={author_username}"

    raw = run_glab("api", endpoint)
    mrs_data = json.loads(raw)

    results: list[MergeRequestSummary] = []
    for mr in mrs_data:
        results.append(
            MergeRequestSummary(
                iid=mr["iid"],
                title=mr["title"],
                source_branch=mr["source_branch"],
                target_branch=mr["target_branch"],
                author=mr.get("author", {}).get("username", ""),
                web_url=mr["web_url"],
                has_conflicts=mr.get("has_conflicts", False),
            )
        )

    return results


cli = typer.Typer()


@cli.command()
def main(
    author: Annotated[
        str | None,
        typer.Option("--author", help="Filter by author username (default: current user)"),
    ] = None,
    all_authors: Annotated[
        bool,
        typer.Option("--all", help="List MRs from all authors"),
    ] = False,
) -> None:
    """Rebase open MRs on their target branch and restart pipelines."""
    project_id = get_project_id()

    if all_authors:
        resolved_author = None
    elif author:
        resolved_author = author
    else:
        resolved_author = get_current_username()

    mrs = list_open_mrs(project_id, resolved_author)

    if not mrs:
        print(json.dumps({"count": 0, "message": "No open MRs found"}))
        sys.exit(0)

    print(json.dumps({"count": len(mrs)}))
    for mr in mrs:
        print(mr.to_json())


if __name__ == "__main__":
    cli()
