"""Compute the next semver version for a GitLab project.

Usage:
    pysae-ai-tools ci_release next_version [--project-id ID] [--bump major|minor|patch] [--version v1.2.3]

Examples:
    pysae-ai-tools ci_release next_version                          # patch bump from latest tag
    pysae-ai-tools ci_release next_version --bump minor             # minor bump
    pysae-ai-tools ci_release next_version --version v2.0.0         # explicit version
    pysae-ai-tools ci_release next_version --project-id 14366711    # for a specific project

Output (JSON):
    {"latest_tag": "v1.2.3", "new_version": "v1.2.4", "bump": "patch"}
"""

import json
import re
import subprocess
import sys
from typing import Annotated

import typer
from commitizen.config import BaseConfig
from commitizen.cz.conventional_commits.conventional_commits import ConventionalCommitsCz

_CZ = ConventionalCommitsCz(BaseConfig())  # type: ignore[no-untyped-call]
_BUMP_PATTERN = re.compile(_CZ.bump_pattern)
_BUMP_MAP = _CZ.bump_map
_BUMP_PRIORITY = {"PATCH": 1, "MINOR": 2, "MAJOR": 3}


def _run_glab(*args: str, timeout: int = 15) -> str | None:
    """Run a glab command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["glab", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _get_project_id() -> str:
    """Get project ID from glab repo view."""
    raw = _run_glab("repo", "view", "--output", "json")
    if raw:
        try:
            return str(json.loads(raw)["id"])
        except (json.JSONDecodeError, KeyError):
            pass
    return ""


def _fetch_latest_tag(project_id: str) -> str:
    """Fetch the latest semver tag from the project."""
    raw = _run_glab("api", f"projects/{project_id}/repository/tags?per_page=20&order_by=version")
    if not raw:
        return ""
    try:
        tags = json.loads(raw)
        # Find the first tag that looks like a semver (v?X.Y.Z)
        for tag in tags:
            name: str = tag.get("name", "")
            if re.match(r"^v?\d+\.\d+\.\d+$", name):
                return name
    except json.JSONDecodeError:
        pass
    return ""


def parse_semver(version: str) -> tuple[int, int, int]:
    """Parse a semver string (with optional v prefix) into (major, minor, patch)."""
    stripped = version.lstrip("v")
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)$", stripped)
    if not match:
        raise ValueError(f"Invalid semver: {version}")
    return int(match.group(1)), int(match.group(2)), int(match.group(3))


def _bump_for_message(message: str) -> str | None:
    """Return ``MAJOR`` / ``MINOR`` / ``PATCH`` for a single conventional commit line.

    Strips the leading ``* `` bullet (if present) and delegates to commitizen's
    ``bump_pattern`` / ``bump_map`` (the same logic used by ``cz bump``).
    Returns ``None`` for non-bumping types (e.g. ``tech``, ``docs``, ``chore``)
    and for lines that don't match conventional commits at all.
    """
    if message.startswith("* "):
        message = message[2:]
    m = _BUMP_PATTERN.match(message)
    if not m:
        return None
    head = m.group(0).rstrip(":")
    for pattern, bump in _BUMP_MAP.items():
        if re.match(pattern, head):
            return str(bump)
    return None


def suggest_bump_from_changelogs(ref: str = "main") -> str:
    """Analyze changelog entries on a git ref to suggest the bump type.

    Reads changelogs/ from the given ref (default: main) using git,
    not the local filesystem — ensures the release version is based
    on what's merged, not the current branch.

    Rules (delegated to commitizen's ``ConventionalCommitsCz.bump_map``):
    - ``* type(scope)?!: …`` or ``BREAKING[\\- ]CHANGE:`` footer -> major
    - ``* feat(scope)?: …`` -> minor
    - ``* fix|refactor|perf(scope)?: …`` -> patch
    - Any other type (``tech``, ``docs``, ``chore``, …) -> patch (default)
    - No entries -> patch

    The highest bump across all entries wins.

    Returns: "major", "minor", or "patch".
    """
    try:
        result = subprocess.run(
            ["git", "ls-tree", "--name-only", ref, "changelogs/"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return "patch"
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return "patch"

    highest = "PATCH"

    for filepath in result.stdout.strip().splitlines():
        if not filepath.endswith(".md"):
            continue
        try:
            cat_result = subprocess.run(
                ["git", "show", f"{ref}:{filepath}"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if cat_result.returncode != 0:
                continue
            content = cat_result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

        # Footer-style breaking change marker (multi-line — appears below the bullet)
        if re.search(r"^BREAKING[\- ]CHANGE:", content, re.MULTILINE):
            return "major"

        for line in content.splitlines():
            line = line.strip()
            if not line.startswith("* "):
                continue
            bump = _bump_for_message(line)
            if bump and _BUMP_PRIORITY[bump] > _BUMP_PRIORITY[highest]:
                highest = bump
                if highest == "MAJOR":
                    return "major"

    return highest.lower()


def bump_version(major: int, minor: int, patch: int, bump: str) -> str:
    """Compute the next version string."""
    if bump == "major":
        return f"v{major + 1}.0.0"
    if bump == "minor":
        return f"v{major}.{minor + 1}.0"
    return f"v{major}.{minor}.{patch + 1}"


def next_version(project_id: str = "", bump: str = "", explicit_version: str = "") -> dict[str, str]:
    """Compute the next version for a project.

    Returns a dict with: latest_tag, new_version, bump.
    """
    if explicit_version:
        # Validate format
        if not re.match(r"^v?\d+\.\d+\.\d+$", explicit_version):
            return {"error": f"Format de version invalide : {explicit_version} (attendu: vX.Y.Z)"}
        new = explicit_version if explicit_version.startswith("v") else f"v{explicit_version}"
        return {"latest_tag": "", "new_version": new, "bump": "explicit"}

    if not project_id:
        project_id = _get_project_id()
    if not project_id:
        return {"error": "Impossible de detecter le project_id. Utilise --project-id."}

    latest_tag = _fetch_latest_tag(project_id)
    if not latest_tag:
        latest_tag = "v0.0.0"

    try:
        major, minor, patch = parse_semver(latest_tag)
    except ValueError as exc:
        return {"error": str(exc)}

    # Auto-detect bump from changelogs if not explicitly provided
    if not bump:
        bump = suggest_bump_from_changelogs()

    if bump not in ("major", "minor", "patch"):
        return {"error": f"Type de bump invalide : {bump} (attendu: major, minor, patch)"}

    new = bump_version(major, minor, patch, bump)
    return {
        "latest_tag": latest_tag,
        "new_version": new,
        "bump": bump,
        "version_patch": bump_version(major, minor, patch, "patch"),
        "version_minor": bump_version(major, minor, patch, "minor"),
        "version_major": bump_version(major, minor, patch, "major"),
    }


def main(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    bump: Annotated[str, typer.Option("--bump", help="Bump type (auto-detected from changelogs if omitted)")] = "",
    version: Annotated[str, typer.Option("--version", help="Explicit version (skip bump)")] = "",
) -> None:
    """Compute the next semver version."""
    if bump and bump not in ("major", "minor", "patch"):
        print(f"Invalid bump type: {bump}. Must be one of: major, minor, patch", file=sys.stderr)
        raise typer.Exit(code=1)

    result = next_version(project_id=project_id, bump=bump, explicit_version=version)
    json.dump(result, sys.stdout, indent=2)
    sys.stdout.write("\n")

    if "error" in result:
        raise typer.Exit(code=1)
