"""CLI entry point: pysae-ai-tools ci_run <command> [args].

Commands:
    run <job_name>   Run a job and its dependency chain
    status           Show pipeline status overview
    retry            Retry all failed jobs in the pipeline
    create           Create a new pipeline
    jobs             List all jobs in the pipeline

Common flags (all commands):
    --project-id ID
    --pipeline-id ID
    --mr-iid IID
    --branch BRANCH

Examples:
    pysae-ai-tools ci_run run deploy_review
    pysae-ai-tools ci_run status
    pysae-ai-tools ci_run retry
    pysae-ai-tools ci_run create --mr-iid 42
"""

import json
import sys
import time
from typing import Annotated

import typer

from ...internal.detect_context.detect import DetectArgs, detect
from .gitlab_api import (
    PipelineContext,
    create_pipeline,
    find_pipeline,
    get_pipeline,
    list_jobs,
    retry_pipeline,
)
from .runner import ChainResult, run_job_chain

WAIT_POLL_INTERVAL = 15  # seconds between status checks
WAIT_DEFAULT_TIMEOUT = 3600  # 1 hour max

app = typer.Typer(help="GitLab CI pipeline and job runner")


def _build_context(
    project_id: str,
    project_url: str,
    pipeline_id: str,
    mr_iid: str,
    branch: str,
) -> PipelineContext:
    """Build PipelineContext from CLI args, falling back to detect_context."""
    ctx = PipelineContext(
        project_id=project_id,
        project_url=project_url,
        pipeline_id=pipeline_id,
        mr_iid=mr_iid,
        source_branch=branch,
    )

    if not ctx.project_id:
        # Fall back to detect_context
        try:
            detect_args = DetectArgs(
                mr_iid=ctx.mr_iid,
                pipeline_id=ctx.pipeline_id,
            )
            detected = detect(detect_args)
            ctx.project_id = ctx.project_id or detected.project_id
            ctx.project_url = ctx.project_url or detected.project_url
            ctx.pipeline_id = ctx.pipeline_id or detected.pipeline_id
            ctx.mr_iid = ctx.mr_iid or detected.mr_iid
            ctx.source_branch = ctx.source_branch or detected.mr_source_branch
        except Exception as exc:
            print(f"Warning: detect_context failed: {exc}", file=sys.stderr)

    if not ctx.project_id:
        print("ERROR: impossible de detecter le project_id. Utilise --project-id.", file=sys.stderr)
        raise typer.Exit(code=1)

    return ctx


def _print_chain_result(result: ChainResult) -> None:
    """Print the result of a chain run as JSON."""
    output: dict[str, object] = {
        "success": result.success,
        "pipeline_id": result.pipeline.id,
        "pipeline_url": result.pipeline.web_url,
    }

    if result.target_job:
        output["target_job"] = {
            "id": result.target_job.id,
            "name": result.target_job.name,
            "status": result.target_job.status,
            "url": result.target_job.web_url,
        }

    if result.environment_url:
        output["environment_url"] = result.environment_url

    if result.error:
        output["error"] = result.error

    output["jobs"] = [{"name": r.job.name, "status": r.job.status, "action": r.action} for r in result.results]

    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")


@app.command()
def run(
    job_name: Annotated[str, typer.Argument(help="Target job name (exact or fuzzy)")],
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
) -> None:
    """Run a job and its dependency chain."""
    if not job_name:
        print("ERROR: nom du job requis. Ex: pysae-ai-tools ci_run run deploy_review", file=sys.stderr)
        raise typer.Exit(code=1)

    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)
    result = run_job_chain(ctx, job_name)
    _print_chain_result(result)

    if not result.success:
        raise typer.Exit(code=1)


@app.command()
def status(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
) -> None:
    """Show pipeline status overview."""
    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)
    pipeline = find_pipeline(ctx)
    if not pipeline:
        print("ERROR: aucune pipeline trouvee", file=sys.stderr)
        raise typer.Exit(code=1)

    output: dict[str, object] = {
        "pipeline_id": pipeline.id,
        "pipeline_url": pipeline.web_url,
        "pipeline_status": pipeline.status,
    }

    jobs_list = list_jobs(ctx, pipeline.id)
    output["jobs"] = [
        {"name": j.name, "stage": j.stage, "status": j.status, "id": j.id}
        for j in sorted(jobs_list, key=lambda j: j.id)
    ]

    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")


@app.command()
def retry(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
) -> None:
    """Retry all failed jobs in the pipeline."""
    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)
    pipeline = find_pipeline(ctx)
    if not pipeline:
        print("ERROR: aucune pipeline trouvee", file=sys.stderr)
        raise typer.Exit(code=1)

    result = retry_pipeline(ctx, pipeline.id)
    if result:
        data = {"pipeline_id": result.id, "pipeline_url": result.web_url, "status": result.status}
        json.dump(data, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print("ERROR: impossible de relancer la pipeline", file=sys.stderr)
        raise typer.Exit(code=1)


@app.command()
def create(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
    ref: Annotated[str, typer.Option("--ref", help="Git ref (branch/tag) for the pipeline")] = "",
    input_var: Annotated[
        list[str] | None,
        typer.Option("--input", help="Pipeline spec:input as key=value (repeatable, sent as JSON body)"),
    ] = None,
    var: Annotated[
        list[str] | None,
        typer.Option("--var", help="Pipeline CI variable as key=value (repeatable, sent as variables[])"),
    ] = None,
) -> None:
    """Create a new pipeline."""
    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)

    # Parse --input key=value pairs into a dict (spec:inputs)
    inputs: dict[str, str] | None = None
    if input_var:
        inputs = {}
        for pair in input_var:
            if "=" not in pair:
                print(f"ERROR: --input format must be key=value, got: {pair}", file=sys.stderr)
                raise typer.Exit(code=1)
            k, v = pair.split("=", 1)
            inputs[k] = v

    # Parse --var key=value pairs into a dict (CI variables)
    variables: dict[str, str] | None = None
    if var:
        variables = {}
        for pair in var:
            if "=" not in pair:
                print(f"ERROR: --var format must be key=value, got: {pair}", file=sys.stderr)
                raise typer.Exit(code=1)
            k, v = pair.split("=", 1)
            variables[k] = v

    pipeline = create_pipeline(ctx, ref=ref, inputs=inputs, variables=variables)
    if pipeline:
        data = {"pipeline_id": pipeline.id, "pipeline_url": pipeline.web_url, "status": pipeline.status}
        json.dump(data, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print("ERROR: impossible de creer la pipeline", file=sys.stderr)
        raise typer.Exit(code=1)


@app.command()
def jobs(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
) -> None:
    """List all jobs in the pipeline."""
    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)
    pipeline = find_pipeline(ctx)
    if not pipeline:
        print("ERROR: aucune pipeline trouvee", file=sys.stderr)
        raise typer.Exit(code=1)

    jobs_list = list_jobs(ctx, pipeline.id)
    output = [
        {"id": j.id, "name": j.name, "stage": j.stage, "status": j.status, "when": j.when}
        for j in sorted(jobs_list, key=lambda j: j.id)
    ]
    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")


@app.command()
def wait(
    project_id: Annotated[str, typer.Option("--project-id", help="GitLab project ID")] = "",
    project_url: Annotated[str, typer.Option("--project-url", help="GitLab project URL")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID")] = "",
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="MR IID")] = "",
    branch: Annotated[str, typer.Option("--branch", help="Branch name")] = "",
    timeout: Annotated[int, typer.Option("--timeout", help="Max wait time in seconds")] = WAIT_DEFAULT_TIMEOUT,
    wait_manual: Annotated[
        bool,
        typer.Option(
            "--wait-manual/--no-wait-manual",
            help="If false (default), treat 'manual' as terminal (automatic jobs done, waiting on human).",
        ),
    ] = False,
) -> None:
    """Wait for a pipeline to reach a terminal state.

    Terminal states: success, failed, canceled, skipped. By default, 'manual'
    is also treated as terminal — it means all automatic jobs finished and the
    pipeline is paused waiting for a human to play a manual job, so further
    waiting would block indefinitely. Use --wait-manual to keep waiting past
    that point (rare — only if another system will trigger the manual job).
    """
    ctx = _build_context(project_id, project_url, pipeline_id, mr_iid, branch)
    pipeline = find_pipeline(ctx)
    if not pipeline:
        print("ERROR: aucune pipeline trouvee", file=sys.stderr)
        raise typer.Exit(code=1)

    terminal_statuses = {"success", "failed", "canceled", "skipped"}
    if not wait_manual:
        terminal_statuses.add("manual")

    start = time.monotonic()
    while True:
        current = get_pipeline(ctx, pipeline.id)
        if not current:
            print("ERROR: impossible de recuperer le statut de la pipeline", file=sys.stderr)
            raise typer.Exit(code=1)

        if current.status in terminal_statuses:
            output = {
                "pipeline_id": current.id,
                "pipeline_url": current.web_url,
                "status": current.status,
            }
            json.dump(output, sys.stdout, indent=2)
            sys.stdout.write("\n")
            # success and manual (automatic part succeeded) are both non-error exits
            if current.status not in ("success", "manual"):
                raise typer.Exit(code=1)
            return

        elapsed = time.monotonic() - start
        if elapsed > timeout:
            print(f"ERROR: timeout apres {timeout}s (status: {current.status})", file=sys.stderr)
            raise typer.Exit(code=1)

        print(f"Pipeline #{pipeline.id} : {current.status}... ({int(elapsed)}s)", file=sys.stderr)
        time.sleep(WAIT_POLL_INTERVAL)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
