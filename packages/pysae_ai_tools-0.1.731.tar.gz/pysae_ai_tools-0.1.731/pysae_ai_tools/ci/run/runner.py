"""CI job runner: resolve dependencies, play jobs, wait for completion.

Main entry point: run_job_chain() — takes a job name, resolves everything,
plays dependencies in order, waits, and reports.
"""

import re
import sys
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

from .gitlab_api import (
    Job,
    Pipeline,
    PipelineContext,
    create_pipeline,
    find_pipeline,
    get_environment_url,
    get_job,
    list_jobs,
    play_job,
    retry_job,
)

POLL_INTERVAL = 10  # seconds between status checks
PLAY_WAIT_INTERVAL = 5  # seconds between checks for created→manual transition
PLAY_WAIT_TIMEOUT = 120  # max seconds to wait for created→manual
DEFAULT_TIMEOUT = 1800  # 30 min max wait per job


@dataclass
class JobResult:
    """Result of running a single job."""

    job: Job
    action: str  # "played", "retried", "skipped", "waited", "failed"


@dataclass
class ChainResult:
    """Result of running a full dependency chain."""

    pipeline: Pipeline
    results: list[JobResult] = field(default_factory=list)
    target_job: Job | None = None
    environment_url: str = ""
    success: bool = False
    error: str = ""


def fuzzy_match_job(query: str, jobs: list[Job]) -> list[Job]:
    """Find jobs matching a query string (exact, prefix, or fuzzy)."""
    query_lower = query.lower().replace(" ", "_").replace("-", "_")

    # Exact match
    for job in jobs:
        if job.name.lower() == query_lower:
            return [job]

    # Prefix/substring match
    matches = [j for j in jobs if query_lower in j.name.lower().replace("-", "_")]
    if matches:
        return matches

    # Fuzzy match (similarity > 0.5)
    scored = []
    for job in jobs:
        ratio = SequenceMatcher(None, query_lower, job.name.lower().replace("-", "_")).ratio()
        if ratio > 0.5:
            scored.append((ratio, job))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [j for _, j in scored[:5]]


def resolve_deps_from_yaml(target_job_name: str, jobs: list[Job]) -> list[str]:
    """Resolve the dependency chain for a job by parsing .gitlab-ci.yml.

    Returns job names in execution order (dependencies first, target last).
    """
    yaml_content = _read_ci_yaml()
    if not yaml_content:
        # No YAML → fall back to stage ordering
        return _stage_order_fallback(target_job_name, jobs)

    needs_map = _parse_needs_from_yaml(yaml_content)
    return _resolve_chain(target_job_name, needs_map)


def _read_ci_yaml() -> str:
    """Read .gitlab-ci.yml from the repo root."""
    for candidate in [Path(".gitlab-ci.yml"), Path(".gitlab-ci.yaml")]:
        if candidate.exists():
            return candidate.read_text()
    return ""


def _parse_needs_from_yaml(content: str) -> dict[str, list[str]]:
    """Extract needs: directives from YAML content (lightweight parsing).

    We do a simple regex-based parse to avoid a PyYAML dependency.
    Handles:
    - needs: [job1, job2]
    - needs:\n  - job1\n  - job2
    - needs:\n  - job: job1
    """
    needs_map: dict[str, list[str]] = {}
    current_job: str | None = None
    in_needs = False
    indent_level = 0

    for line in content.splitlines():
        stripped = line.lstrip()

        # Top-level job definition (not indented, ends with :, not a keyword)
        if line and not line[0].isspace() and line.rstrip().endswith(":") and not stripped.startswith(("#", ".")):
            job_name = line.rstrip().rstrip(":")
            if job_name not in ("stages", "variables", "default", "include", "workflow", "image", "services", "cache"):
                current_job = job_name
                in_needs = False
            continue

        if not current_job:
            continue

        # Detect needs: directive
        if stripped.startswith("needs:"):
            in_needs = True
            indent_level = len(line) - len(stripped)
            # Inline array: needs: [job1, job2]
            inline = stripped[len("needs:") :].strip()
            if inline.startswith("["):
                items = re.findall(r"[\w][\w./-]*", inline)
                needs_map[current_job] = items
                in_needs = False
            else:
                needs_map.setdefault(current_job, [])
            continue

        # Inside a needs: block
        if in_needs and current_job:
            line_indent = len(line) - len(stripped)
            if line_indent <= indent_level and stripped and not stripped.startswith("-"):
                in_needs = False
                continue
            if stripped.startswith("- job:"):
                job_ref = stripped[len("- job:") :].strip().strip("\"'")
                needs_map[current_job].append(job_ref)
            elif stripped.startswith("- "):
                job_ref = stripped[2:].strip().strip("\"'")
                if job_ref and not job_ref.startswith("{"):
                    needs_map[current_job].append(job_ref)

    return needs_map


def _resolve_chain(target: str, needs_map: dict[str, list[str]]) -> list[str]:
    """Recursively resolve the dependency chain, returning execution order."""
    visited: set[str] = set()
    order: list[str] = []

    def _visit(name: str) -> None:
        if name in visited:
            return
        visited.add(name)
        for dep in needs_map.get(name, []):
            _visit(dep)
        order.append(name)

    _visit(target)
    return order


def _stage_order_fallback(target_name: str, jobs: list[Job]) -> list[str]:
    """Fall back to running all jobs from earlier stages (when no needs: found)."""
    target_job = next((j for j in jobs if j.name == target_name), None)
    if not target_job:
        return [target_name]

    # Get stage order from the pipeline jobs
    stage_order: list[str] = []
    for j in sorted(jobs, key=lambda x: x.id):
        if j.stage not in stage_order:
            stage_order.append(j.stage)

    target_stage_idx = stage_order.index(target_job.stage) if target_job.stage in stage_order else -1
    if target_stage_idx < 0:
        return [target_name]

    # All jobs from earlier stages + target
    chain = [j.name for j in jobs if j.stage in stage_order[:target_stage_idx]]
    chain.append(target_name)
    return chain


def _trigger_job(ctx: PipelineContext, job: Job) -> JobResult:
    """Trigger a single job based on its current status."""
    if job.status == "success":
        return JobResult(job=job, action="skipped")

    if job.status == "manual":
        result = play_job(ctx, job.id)
        return JobResult(job=result or job, action="played")

    if job.status in ("failed", "skipped"):
        result = retry_job(ctx, job.id)
        return JobResult(job=result or job, action="retried")

    if job.status == "created" and job.when == "manual":
        # Wait for created→manual transition, then play
        return JobResult(job=job, action="waited")

    if job.status in ("running", "pending", "created"):
        return JobResult(job=job, action="waited")

    return JobResult(job=job, action="skipped")


def _wait_for_job(ctx: PipelineContext, job_id: int, timeout: int = DEFAULT_TIMEOUT) -> Job:
    """Poll a job until it reaches a terminal state."""
    start = time.monotonic()
    while True:
        current = get_job(ctx, job_id)
        if not current:
            time.sleep(POLL_INTERVAL)
            continue

        if current.is_terminal:
            return current

        elapsed = time.monotonic() - start
        if elapsed > timeout:
            print(f"Timeout waiting for job {job_id} after {timeout}s", file=sys.stderr)
            return current

        time.sleep(POLL_INTERVAL)


def _wait_for_playable(ctx: PipelineContext, job_id: int) -> Job | None:
    """Wait for a created job to become manual (playable)."""
    start = time.monotonic()
    while True:
        current = get_job(ctx, job_id)
        if not current:
            return None

        if current.status == "manual":
            return current
        if current.status in ("running", "pending", "success"):
            return current
        if current.is_terminal:
            return current

        if time.monotonic() - start > PLAY_WAIT_TIMEOUT:
            return current

        time.sleep(PLAY_WAIT_INTERVAL)


def run_job_chain(ctx: PipelineContext, target_name: str) -> ChainResult:
    """Run a full dependency chain for a target job.

    1. Find/create pipeline
    2. List jobs, find target
    3. Resolve dependency chain
    4. Play/retry deps in order, wait for each
    5. Play target, wait
    6. Report
    """
    # 1. Find pipeline
    pipeline = find_pipeline(ctx)
    if not pipeline:
        pipeline = create_pipeline(ctx)
    if not pipeline:
        return ChainResult(
            pipeline=Pipeline(id=0, status="error"),
            error="Impossible de trouver ou créer une pipeline",
        )

    # 2. List jobs and find target
    jobs = list_jobs(ctx, pipeline.id)
    if not jobs:
        return ChainResult(pipeline=pipeline, error="Aucun job trouvé dans la pipeline")

    matches = fuzzy_match_job(target_name, jobs)
    if not matches:
        available = ", ".join(j.name for j in sorted(jobs, key=lambda x: x.id))
        return ChainResult(pipeline=pipeline, error=f"Job '{target_name}' non trouvé. Jobs disponibles : {available}")

    if len(matches) > 1:
        # Check if one is exact
        exact = [m for m in matches if m.name.lower() == target_name.lower()]
        if len(exact) == 1:
            matches = exact
        else:
            names = ", ".join(m.name for m in matches)
            return ChainResult(pipeline=pipeline, error=f"Plusieurs jobs correspondent à '{target_name}' : {names}")

    target_job = matches[0]

    # 3. Resolve dependency chain
    chain_names = resolve_deps_from_yaml(target_job.name, jobs)
    jobs_by_name = {j.name: j for j in jobs}

    # Filter chain to jobs that exist in pipeline
    chain = [jobs_by_name[name] for name in chain_names if name in jobs_by_name]
    if not chain:
        chain = [target_job]

    # Print chain
    chain_display = " → ".join(f"`{j.name}`" for j in chain)
    print(f"Chaîne de dépendances : {chain_display}", file=sys.stderr)

    # 4. Run chain
    result = ChainResult(pipeline=pipeline, target_job=target_job)

    for i, job in enumerate(chain):
        # Refresh job status
        fresh = get_job(ctx, job.id)
        if not fresh:
            result.error = f"Impossible de récupérer le statut de {job.name}"
            return result
        job = fresh

        is_target = job.name == target_job.name
        step = f"({i + 1}/{len(chain)})"

        if job.status == "success":
            print(f"  {step} {job.name} : déjà terminé ✓", file=sys.stderr)
            result.results.append(JobResult(job=job, action="skipped"))
            continue

        # Trigger
        if job.needs_play:
            print(f"  {step} {job.name} : démarrage...", file=sys.stderr)
            played = play_job(ctx, job.id)
            if played:
                result.results.append(JobResult(job=played, action="played"))
            else:
                result.error = f"Impossible de démarrer {job.name}"
                return result
        elif job.status in ("failed", "skipped"):
            print(f"  {step} {job.name} : relance...", file=sys.stderr)
            retried = retry_job(ctx, job.id)
            if retried:
                result.results.append(JobResult(job=retried, action="retried"))
            else:
                result.error = f"Impossible de relancer {job.name}"
                return result
        elif job.status == "created":
            if is_target and job.when == "manual":
                # Wait for deps to complete, then transition to manual
                print(f"  {step} {job.name} : en attente de la transition manual...", file=sys.stderr)
                playable = _wait_for_playable(ctx, job.id)
                if playable and playable.status == "manual":
                    played = play_job(ctx, playable.id)
                    if played:
                        result.results.append(JobResult(job=played, action="played"))
                    else:
                        result.error = f"Impossible de démarrer {job.name}"
                        return result
                elif playable and playable.is_terminal:
                    result.results.append(JobResult(job=playable, action="waited"))
                    if playable.status != "success":
                        result.error = f"{job.name} a échoué ({playable.status})"
                        return result
                    continue
                else:
                    result.error = f"{job.name} n'est pas devenu manual après {PLAY_WAIT_TIMEOUT}s"
                    return result
            else:
                print(f"  {step} {job.name} : en attente (démarrage automatique)...", file=sys.stderr)
                result.results.append(JobResult(job=job, action="waited"))
        else:
            print(f"  {step} {job.name} : {job.status}...", file=sys.stderr)
            result.results.append(JobResult(job=job, action="waited"))

        # Wait for completion
        print(f"  {step} {job.name} : en cours...", file=sys.stderr)
        final = _wait_for_job(ctx, job.id)
        if final.status == "success":
            print(f"  {step} {job.name} : terminé ✓", file=sys.stderr)
        elif final.status == "failed":
            print(f"  {step} {job.name} : échoué ✗ ({final.failure_reason})", file=sys.stderr)
            result.error = f"{job.name} a échoué"
            result.target_job = final
            return result
        else:
            print(f"  {step} {job.name} : {final.status}", file=sys.stderr)

    # 5. Get environment URL if applicable
    final_target = get_job(ctx, target_job.id)
    if final_target:
        result.target_job = final_target
        if final_target.environment:
            result.environment_url = get_environment_url(ctx, final_target.environment)

    result.success = final_target is not None and final_target.status == "success"
    return result


def get_pipeline_status(ctx: PipelineContext, pipeline_id: int) -> str:
    """Get a formatted status overview of all jobs in a pipeline."""
    jobs = list_jobs(ctx, pipeline_id)
    if not jobs:
        return "Aucun job trouvé"

    # Group by stage, maintaining stage order from job IDs
    stage_order: list[str] = []
    stages: dict[str, list[Job]] = {}
    for job in sorted(jobs, key=lambda j: j.id):
        if job.stage not in stage_order:
            stage_order.append(job.stage)
        stages.setdefault(job.stage, []).append(job)

    status_icons = {
        "success": "passed",
        "failed": "failed",
        "running": "in progress",
        "pending": "queued",
        "manual": "manual",
        "created": "not started",
        "skipped": "skipped",
        "canceled": "canceled",
    }

    lines: list[str] = []
    for stage in stage_order:
        lines.append(f"## {stage}")
        for job in stages[stage]:
            icon = status_icons.get(job.status, job.status)
            lines.append(f"  {icon} | {job.name}")
    return "\n".join(lines)
