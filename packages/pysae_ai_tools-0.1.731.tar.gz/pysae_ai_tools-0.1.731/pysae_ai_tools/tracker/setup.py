"""Install/uninstall the activity tracker hook in Claude Code settings.

Usage:
    pysae-ai-tools activity_tracker setup status
    pysae-ai-tools activity_tracker setup install
    pysae-ai-tools activity_tracker setup uninstall [--delete-logs]
"""

import json
import os
import platform
import shutil
from pathlib import Path

import typer

from .hook import LOG_DIR


def _settings_path() -> Path:
    """Return the Claude Code settings.json path for the current platform."""
    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Claude" / "settings.json"
    return Path.home() / ".claude" / "settings.json"


SETTINGS_PATH = _settings_path()

HOOK_MATCHER = "Bash|Edit|Write|Skill|Agent|Read"
HOOK_COMMAND = "pysae-ai-tools activity_tracker hook"
STOP_HOOK_COMMAND = "pysae-ai-tools activity_tracker stop-hook"
HOOK_TIMEOUT = 5

app = typer.Typer()


def _read_settings() -> dict[str, object]:
    """Read ~/.claude/settings.json, returning empty dict if missing."""
    if not SETTINGS_PATH.exists():
        return {}
    try:
        return json.loads(SETTINGS_PATH.read_text())  # type: ignore[no-any-return]
    except (json.JSONDecodeError, OSError):
        return {}


def _write_settings(cfg: dict[str, object]) -> None:
    """Write ~/.claude/settings.json with pretty formatting."""
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    SETTINGS_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")


def _find_hook_in_list(hook_list: list[object], command: str) -> bool:
    """Check if a specific hook command is present in a hook list."""
    return any(
        any(command in str(h.get("command", "")) for h in group.get("hooks", []))
        for group in hook_list
        if isinstance(group, dict)
    )


def _find_hook(cfg: dict[str, object]) -> bool:
    """Check if the activity tracker hook is already configured."""
    hooks = cfg.get("hooks", {})
    if not isinstance(hooks, dict):
        return False
    post = hooks.get("PostToolUse", [])
    if not isinstance(post, list):
        return False
    return _find_hook_in_list(post, HOOK_COMMAND)


@app.command()
def status() -> None:
    """Vérifie si le hook activity tracker est configuré."""
    cfg = _read_settings()
    if _find_hook(cfg):
        print("HOOK: CONFIGURED")
    else:
        print("HOOK: NOT CONFIGURED")


@app.command()
def install() -> None:
    """Installe le hook activity tracker dans ~/.claude/settings.json."""
    cfg = _read_settings()

    if _find_hook(cfg):
        print("HOOK: ALREADY CONFIGURED")
        return

    hooks = cfg.get("hooks", {})
    if not isinstance(hooks, dict):
        hooks = {}
    post = hooks.get("PostToolUse", [])
    if not isinstance(post, list):
        post = []

    post.append(
        {
            "matcher": HOOK_MATCHER,
            "hooks": [
                {
                    "type": "command",
                    "command": HOOK_COMMAND,
                    "timeout": HOOK_TIMEOUT,
                }
            ],
        }
    )
    hooks["PostToolUse"] = post

    # Add Stop hook for session end tracking
    stop = hooks.get("Stop", [])
    if not isinstance(stop, list):
        stop = []
    if not _find_hook_in_list(stop, STOP_HOOK_COMMAND):
        stop.append(
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": STOP_HOOK_COMMAND,
                        "timeout": HOOK_TIMEOUT,
                    }
                ],
            }
        )
    hooks["Stop"] = stop

    cfg["hooks"] = hooks
    _write_settings(cfg)

    # Créer le répertoire de logs
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    print("HOOK: INSTALLED")


@app.command()
def uninstall(
    delete_logs: bool = typer.Option(False, "--delete-logs", help="Supprimer aussi les fichiers de logs"),
) -> None:
    """Désinstalle le hook activity tracker de ~/.claude/settings.json."""
    cfg = _read_settings()

    if not _find_hook(cfg):
        print("HOOK: NOT CONFIGURED")
        return

    hooks = cfg.get("hooks", {})
    if isinstance(hooks, dict):
        # Remove PostToolUse hook
        post = hooks.get("PostToolUse", [])
        if isinstance(post, list):
            post = [
                g
                for g in post
                if not (
                    isinstance(g, dict) and any(HOOK_COMMAND in str(h.get("command", "")) for h in g.get("hooks", []))
                )
            ]
            if post:
                hooks["PostToolUse"] = post
            else:
                hooks.pop("PostToolUse", None)

        # Remove Stop hook
        stop = hooks.get("Stop", [])
        if isinstance(stop, list):
            stop = [
                g
                for g in stop
                if not (
                    isinstance(g, dict)
                    and any(STOP_HOOK_COMMAND in str(h.get("command", "")) for h in g.get("hooks", []))
                )
            ]
            if stop:
                hooks["Stop"] = stop
            else:
                hooks.pop("Stop", None)

        if hooks:
            cfg["hooks"] = hooks
        else:
            cfg.pop("hooks", None)

    _write_settings(cfg)
    print("HOOK: REMOVED")

    if delete_logs and LOG_DIR.exists():
        shutil.rmtree(LOG_DIR)
        print(f"LOGS: DELETED ({LOG_DIR})")
