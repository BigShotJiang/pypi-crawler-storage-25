"""Install or update Terraform from releases.hashicorp.com."""

import json
from dataclasses import dataclass
from typing import Annotated

import httpx
import typer

from .common import binary, platform
from .common.download import download_and_install_binary

BINARY_NAME = "terraform"
CHECKPOINT = "https://checkpoint-api.hashicorp.com/v1/check/terraform"


def latest_version(timeout: float = 5.0) -> str:
    r = httpx.get(CHECKPOINT, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    data = r.json()
    v = data.get("current_version", "")
    return v if isinstance(v, str) else ""


def _arch_token(plat: platform.Platform) -> str:
    return "amd64" if plat.arch.value == "x86_64" else plat.arch.value


def archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Terraform releases are always .zip — same scheme on all platforms."""
    ver = version.lstrip("v")
    arch = _arch_token(plat)
    member = "terraform.exe" if plat.is_windows else "terraform"
    return (
        f"https://releases.hashicorp.com/terraform/{ver}/terraform_{ver}_{plat.os.value}_{arch}.zip",
        member,
    )


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="version")
    try:
        latest = latest_version()
    except Exception:  # noqa: BLE001
        latest = ""
    return State(binary=bin_status, latest=latest)


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    try:
        version = latest_version()
        if not version:
            raise ValueError("checkpoint API returned no version")
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch latest version: {exc}")
    url, member = archive_url(version, plat)
    try:
        path = download_and_install_binary(url, BINARY_NAME, archive_member=member)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"download/install failed: {exc}")
    installed_v = binary.get_version(BINARY_NAME, version_arg="version")
    return InstallReport(action="install", version=installed_v or version, path=str(path))


cli = typer.Typer(no_args_is_help=True, help="Install/update the Terraform CLI")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"terraform: {b.version or 'n/a'} (latest {state.latest or 'n/a'})")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed terraform {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
