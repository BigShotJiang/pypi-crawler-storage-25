"""Install or update the Helm CLI from get.helm.sh."""

import json
from dataclasses import dataclass
from typing import Annotated

import typer

from .common import binary, github, platform
from .common.download import download_and_install_binary

GH_REPO = "helm/helm"
BINARY_NAME = "helm"


def _arch_token(plat: platform.Platform) -> str:
    return "amd64" if plat.arch.value == "x86_64" else plat.arch.value


def archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Return (url, archive_member) for a Helm release.

    Linux/macOS: helm-v<ver>-<os>-<arch>.tar.gz, member <os>-<arch>/helm
    Windows: helm-v<ver>-windows-<arch>.zip, member windows-<arch>/helm.exe
    """
    ver = version if version.startswith("v") else f"v{version}"
    arch = _arch_token(plat)
    if plat.is_windows:
        return f"https://get.helm.sh/helm-{ver}-windows-{arch}.zip", f"windows-{arch}/helm.exe"
    return (
        f"https://get.helm.sh/helm-{ver}-{plat.os.value}-{arch}.tar.gz",
        f"{plat.os.value}-{arch}/helm",
    )


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="version")
    if bin_status.installed:
        # `helm version --short` returns e.g. v3.16.2+gabc123
        bin_status.version = binary.get_version(BINARY_NAME, version_arg="version") or bin_status.version
    try:
        latest = github.latest_release(GH_REPO).lstrip("v")
    except Exception:  # noqa: BLE001
        latest = ""
    return State(binary=bin_status, latest=latest)


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    try:
        latest = github.latest_release(GH_REPO).lstrip("v")
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch latest release: {exc}")
    url, member = archive_url(latest, plat)
    try:
        path = download_and_install_binary(url, BINARY_NAME, archive_member=member)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"download/install failed: {exc}")
    installed_v = binary.get_version(BINARY_NAME, version_arg="version")
    return InstallReport(action="install", version=installed_v or latest, path=str(path))


cli = typer.Typer(no_args_is_help=True, help="Install/update the Helm CLI")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        state_label = "installed" if b.installed else "NOT installed"
        typer.echo(f"helm: {state_label} ({b.version or 'n/a'} / latest {state.latest or 'n/a'})")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed helm {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
