"""Install the MongoDB MCP servers (dev read/write + prod read-only).

Connection strings come from environment variables MDB_DEV_URI and MDB_PROD_URI.
The SKILL.md is responsible for fetching them via /aws-secret-env first.
"""

import json
import os
from dataclasses import dataclass
from typing import Annotated, Any

import typer

from .common import mcp

DEV_NAME = "mongodb-dev"
PROD_NAME = "mongodb-prod"


def _build(server: str, uri: str, read_only: bool) -> dict[str, Any]:
    args = ["-y", "mongodb-mcp-server@latest"]
    if read_only:
        args.append("--readOnly")
    return {
        "type": "stdio",
        "command": "npx",
        "args": args,
        "env": {"MDB_MCP_CONNECTION_STRING": uri},
    }


@dataclass
class Status:
    name: str
    configured: bool
    has_uri: bool
    read_only: bool

    def to_dict(self) -> dict[str, object]:
        return {"name": self.name, "configured": self.configured, "has_uri": self.has_uri, "read_only": self.read_only}


def status_for(name: str) -> Status:
    server = mcp.get_server(name)
    if server is None:
        return Status(name=name, configured=False, has_uri=False, read_only=False)
    args = server.get("args", []) if isinstance(server.get("args"), list) else []
    env = server.get("env", {}) if isinstance(server.get("env", {}), dict) else {}
    return Status(
        name=name,
        configured=True,
        has_uri=bool(env.get("MDB_MCP_CONNECTION_STRING")),
        read_only="--readOnly" in args,
    )


@dataclass
class State:
    """install_all-compatible aggregate state for both servers."""

    dev: Status
    prod: Status

    def to_dict(self) -> dict[str, Any]:
        needs = not (
            self.dev.configured
            and self.dev.has_uri
            and self.prod.configured
            and self.prod.has_uri
            and self.prod.read_only
        )
        return {DEV_NAME: self.dev.to_dict(), PROD_NAME: self.prod.to_dict(), "needs_install": needs}


def get_state() -> State:
    return State(dev=status_for(DEV_NAME), prod=status_for(PROD_NAME))


def do_install() -> dict[str, Any]:
    dev_uri = os.environ.get("MDB_DEV_URI", "").strip()
    prod_uri = os.environ.get("MDB_PROD_URI", "").strip()
    if not dev_uri or not prod_uri:
        return {"action": "install", "error": "MDB_DEV_URI and MDB_PROD_URI must be set"}
    dev_changed = mcp.upsert_server(DEV_NAME, _build(DEV_NAME, dev_uri, read_only=False))
    prod_changed = mcp.upsert_server(PROD_NAME, _build(PROD_NAME, prod_uri, read_only=True))
    return {
        "action": "install",
        DEV_NAME: {"changed": dev_changed},
        PROD_NAME: {"changed": prod_changed, "read_only_enforced": True},
    }


cli = typer.Typer(no_args_is_help=True, help="Install/configure the MongoDB MCP servers")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    dev = status_for(DEV_NAME)
    prod = status_for(PROD_NAME)
    payload = {
        DEV_NAME: dev.to_dict(),
        PROD_NAME: prod.to_dict(),
        "needs_install": not (dev.configured and dev.has_uri and prod.configured and prod.has_uri and prod.read_only),
    }
    if json_output:
        typer.echo(json.dumps(payload))
    else:
        for s in (dev, prod):
            typer.echo(
                f"{s.name}: {'configured' if s.configured else 'missing'} (uri={s.has_uri}, readOnly={s.read_only})"
            )


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    dev_uri = os.environ.get("MDB_DEV_URI", "").strip()
    prod_uri = os.environ.get("MDB_PROD_URI", "").strip()
    if not dev_uri or not prod_uri:
        msg = "MDB_DEV_URI and MDB_PROD_URI must be set in env (use /aws-secret-env first)"
        if json_output:
            typer.echo(json.dumps({"action": "install", "error": msg}))
        else:
            typer.echo(f"FAILED: {msg}", err=True)
        raise typer.Exit(code=1)

    dev_changed = mcp.upsert_server(DEV_NAME, _build(DEV_NAME, dev_uri, read_only=False))
    prod_changed = mcp.upsert_server(PROD_NAME, _build(PROD_NAME, prod_uri, read_only=True))
    payload = {
        "action": "install",
        DEV_NAME: {"changed": dev_changed},
        PROD_NAME: {"changed": prod_changed, "read_only_enforced": True},
        "settings_path": str(mcp.settings_path()),
    }
    if json_output:
        typer.echo(json.dumps(payload))
    else:
        typer.echo(f"{DEV_NAME}: {'updated' if dev_changed else 'unchanged'}")
        typer.echo(f"{PROD_NAME}: {'updated (--readOnly)' if prod_changed else 'unchanged (--readOnly)'}")


if __name__ == "__main__":
    cli()
