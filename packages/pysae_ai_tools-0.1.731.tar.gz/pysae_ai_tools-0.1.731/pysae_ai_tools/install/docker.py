"""Install or update Docker Engine.

- Linux: official `get.docker.com` convenience script.
- macOS / Windows: report manual install (Docker Desktop is the only supported path
  and ships with its own installer/updater that we don't try to automate).
"""

import json
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import httpx
import typer

from .common import binary, platform


def daemon_running() -> bool:
    if not binary.which("docker"):
        return False
    r = subprocess.run(
        ["docker", "version", "--format", "{{.Server.Version}}"],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    return r.returncode == 0 and bool(r.stdout.strip())


def compose_available() -> bool:
    if not binary.which("docker"):
        return False
    r = subprocess.run(["docker", "compose", "version"], capture_output=True, text=True, check=False, timeout=5)
    return r.returncode == 0


def registry_logins() -> dict[str, str]:
    """Read ~/.docker/config.json and report registries with stored auth or credHelper."""
    config = Path.home() / ".docker" / "config.json"
    if not config.exists():
        return {}
    try:
        data = json.loads(config.read_text())
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, str] = {}
    for reg in data.get("auths") or {}:
        out[reg] = "auth"
    for reg, helper in (data.get("credHelpers") or {}).items():
        out[reg] = f"credHelper:{helper}"
    return out


@dataclass
class State:
    binary: binary.BinaryStatus
    daemon: bool
    compose: bool
    ecr_helper: bool
    registries: dict[str, str]

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "daemon_running": self.daemon,
            "compose_available": self.compose,
            "ecr_helper_installed": self.ecr_helper,
            "registries": self.registries,
            "needs_install": not self.binary.installed,
        }


def get_state() -> State:
    return State(
        binary=binary.status("docker", version_arg="--version"),
        daemon=daemon_running(),
        compose=compose_available(),
        ecr_helper=bool(shutil.which("docker-credential-ecr-login")),
        registries=registry_logins(),
    )


@dataclass
class InstallReport:
    action: str
    method: str = ""
    error: str = ""
    manual: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("method", "error", "manual"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _install_linux() -> InstallReport:
    with tempfile.TemporaryDirectory(prefix="pysae-docker-") as tmp_dir:
        script = Path(tmp_dir) / "get-docker.sh"
        try:
            r = httpx.get("https://get.docker.com", timeout=30, follow_redirects=True)
            r.raise_for_status()
            script.write_text(r.text)
            script.chmod(0o755)
        except Exception as exc:  # noqa: BLE001
            return InstallReport(action="install", error=f"could not fetch get.docker.com: {exc}")
        proc = subprocess.run(["sudo", "sh", str(script)], capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            return InstallReport(action="install", error=proc.stderr.strip() or proc.stdout.strip())

    # Add user to docker group (best-effort)
    user = os.environ.get("USER") or os.environ.get("USERNAME") or ""
    if user:
        subprocess.run(["sudo", "usermod", "-aG", "docker", user], check=False)

    return InstallReport(
        action="install",
        method="get.docker.com",
        manual="Log out and back in (or run `newgrp docker`) so the docker group takes effect.",
    )


def _install_macos() -> InstallReport:
    return InstallReport(
        action="install",
        manual=(
            "Install Docker Desktop for macOS from https://www.docker.com/products/docker-desktop/ "
            "or run `brew install --cask docker`. Then start Docker Desktop from /Applications."
        ),
    )


def _install_windows() -> InstallReport:
    return InstallReport(
        action="install",
        manual=(
            "Install Docker Desktop for Windows from https://www.docker.com/products/docker-desktop/ "
            "or run `winget install Docker.DockerDesktop`. WSL2 backend is required."
        ),
    )


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    if plat.is_linux:
        return _install_linux()
    if plat.is_macos:
        return _install_macos()
    if plat.is_windows:
        return _install_windows()
    return InstallReport(action="install", error=f"unsupported OS: {plat.os}")


cli = typer.Typer(no_args_is_help=True, help="Install/update Docker Engine/Desktop and configure registries")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"docker: {b.version or 'n/a'} (daemon {'OK' if state.daemon else 'NOT running'})")
        typer.echo(f"  compose: {'OK' if state.compose else 'NOT installed'}")
        typer.echo(f"  ECR helper: {'OK' if state.ecr_helper else 'NOT installed'}")
        typer.echo(f"  registries: {', '.join(state.registries) or 'none'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    elif report.manual and not report.method:
        typer.echo(report.manual)
    else:
        typer.echo(f"installed docker via {report.method}")
        if report.manual:
            typer.echo(report.manual)


if __name__ == "__main__":
    cli()
