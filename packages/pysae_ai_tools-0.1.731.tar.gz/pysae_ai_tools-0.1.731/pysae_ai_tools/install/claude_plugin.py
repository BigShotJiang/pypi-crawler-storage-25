"""Install the Pysae Claude Code plugin from bundled package resources.

Copies skills, marketplace config, and plugin metadata to the Claude Code
plugin directory (``~/.claude/plugins/``). Works both from a git checkout
(dev) and from a pip-installed wheel (production).

Usage:
    pysae-ai-tools install claude-plugin
    pysae-ai-tools install claude-plugin check
    pysae-ai-tools install claude-plugin --uninstall
"""

import json
import shutil
import subprocess
import sys
from importlib.resources import files
from pathlib import Path
from typing import Annotated

import typer

MARKETPLACE_NAME = "pysae-marketplace"
PLUGIN_NAME = "pysae"
PLUGIN_VERSION = "1.0.0"

cli = typer.Typer(help="Install Pysae Claude Code plugin (skills + marketplace)")


def _claude_plugins_dir() -> Path:
    """Return the Claude Code plugins cache directory."""
    return Path.home() / ".claude" / "plugins" / "cache" / MARKETPLACE_NAME / PLUGIN_NAME / PLUGIN_VERSION


def _resource_path(subpath: str) -> Path:
    """Resolve a resource path from the bundled claude_plugin package."""
    ref = files("pysae_ai_tools.claude_plugin") / subpath
    # importlib.resources may return a MultiplexedPath or a PosixPath
    return Path(str(ref))


def _copy_tree(src: Path, dst: Path) -> int:
    """Copy a directory tree, return number of files copied."""
    if dst.exists():
        shutil.rmtree(dst)
    count = 0
    if src.is_symlink() or src.is_dir():
        real_src = src.resolve()
        shutil.copytree(real_src, dst, dirs_exist_ok=True)
        count = sum(1 for _ in dst.rglob("*") if _.is_file())
    return count


def _try_marketplace_add(src: Path) -> bool:
    """Try to register via claude plugin marketplace add."""
    try:
        result = subprocess.run(
            ["claude", "plugin", "marketplace", "add", str(src)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            subprocess.run(
                ["claude", "plugin", "install", f"{PLUGIN_NAME}@{MARKETPLACE_NAME}"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return False


@cli.command(name="install")
def install(
    uninstall: Annotated[
        bool,
        typer.Option("--uninstall", help="Remove the plugin instead of installing"),
    ] = False,
) -> None:
    """Install or uninstall the Pysae Claude Code plugin."""
    dest = _claude_plugins_dir()

    if uninstall:
        if dest.exists():
            shutil.rmtree(dest)
            print(f"Plugin supprimé : {dest}", file=sys.stderr)
        else:
            print("Plugin non installé.", file=sys.stderr)
        return

    print("Installation du plugin Claude Code Pysae...", file=sys.stderr)

    # Resolve resource paths
    skills_src = _resource_path("skills")
    marketplace_src = _resource_path("marketplace")
    plugin_src = _resource_path("plugin")

    if not skills_src.exists():
        print(f"ERREUR : ressources introuvables ({skills_src})", file=sys.stderr)
        raise typer.Exit(code=1)

    # Method 1: try native marketplace add (needs a directory with .claude-plugin/marketplace.json)
    # Build a temp structure for marketplace add
    marketplace_json = marketplace_src / "marketplace.json"
    if marketplace_json.exists():
        # The marketplace dir must contain .claude-plugin/marketplace.json + plugins/pysae/
        # We construct a temp dir that looks like claude-code-config/
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            # .claude-plugin/marketplace.json
            (tmp_path / ".claude-plugin").mkdir()
            shutil.copy2(marketplace_json, tmp_path / ".claude-plugin" / "marketplace.json")
            # plugins/pysae/.claude-plugin/plugin.json
            plugin_dir = tmp_path / "plugins" / PLUGIN_NAME / ".claude-plugin"
            plugin_dir.mkdir(parents=True)
            plugin_json = plugin_src / "plugin.json"
            if plugin_json.exists():
                shutil.copy2(plugin_json, plugin_dir / "plugin.json")
            # plugins/pysae/skills/
            _copy_tree(skills_src, tmp_path / "plugins" / PLUGIN_NAME / "skills")

            if _try_marketplace_add(tmp_path):
                print("  Plugin enregistré via marketplace add", file=sys.stderr)
                print("\nFait. Relance Claude Code pour activer.", file=sys.stderr)
                return

    # Method 2: direct copy into plugin cache
    print("  Marketplace add non disponible, copie directe...", file=sys.stderr)
    dest.mkdir(parents=True, exist_ok=True)

    # Copy skills
    n = _copy_tree(skills_src, dest / "skills")
    print(f"  {n} fichiers copiés dans {dest / 'skills'}", file=sys.stderr)

    # Copy plugin.json
    plugin_json_src = plugin_src / "plugin.json"
    if plugin_json_src.exists():
        plugin_dest = dest / ".claude-plugin"
        plugin_dest.mkdir(parents=True, exist_ok=True)
        shutil.copy2(plugin_json_src, plugin_dest / "plugin.json")

    print("\nFait. Relance Claude Code pour activer.", file=sys.stderr)
    print("Vérifie avec : claude plugin list", file=sys.stderr)


@cli.command(name="check")
def check() -> None:
    """Check if the plugin is installed and up to date."""
    dest = _claude_plugins_dir()
    skills_dir = dest / "skills"

    if not dest.exists():
        print("Plugin non installé.", file=sys.stderr)
        raise typer.Exit(code=1)

    if not skills_dir.exists():
        print(f"Plugin installé mais skills manquants : {dest}", file=sys.stderr)
        raise typer.Exit(code=1)

    skill_count = sum(1 for d in skills_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists())
    print(f"Plugin installé : {skill_count} skills dans {skills_dir}", file=sys.stderr)

    # Compare with bundled version
    bundled_skills = _resource_path("skills")
    if bundled_skills.exists():
        bundled_count = sum(1 for d in bundled_skills.iterdir() if d.is_dir() and (d / "SKILL.md").exists())
        if bundled_count != skill_count:
            print(f"  ⚠ Décalage : {bundled_count} skills dans le package vs {skill_count} installés", file=sys.stderr)
            print("  Lance `pysae-ai-tools install claude-plugin install` pour synchroniser", file=sys.stderr)
        else:
            print(f"  ✓ Synchronisé avec le package ({bundled_count} skills)", file=sys.stderr)

    # Output JSON for scripts
    output = {
        "installed": True,
        "path": str(dest),
        "skill_count": skill_count,
    }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    cli()
