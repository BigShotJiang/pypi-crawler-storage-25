"""Install the Postman MCP server in ~/.claude.json."""

import os
from typing import Any

from .common.mcp_cli import State, make_cli, state_for

SERVER_NAME = "postman"
ENV_KEYS = ("POSTMAN_API_KEY",)


def get_state() -> State:
    return state_for(SERVER_NAME, env_keys=ENV_KEYS)


def do_install() -> dict[str, Any]:
    from .common import mcp

    config = build_config()
    changed = mcp.upsert_server(SERVER_NAME, config)
    return {"action": "install", "name": SERVER_NAME, "changed": changed}


def build_config() -> dict[str, Any]:
    api_key = os.environ.get("POSTMAN_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            "POSTMAN_API_KEY must be set in the environment before running install. "
            "Generate one at https://go.postman.co/settings/me/api-keys."
        )
    mode_arg = os.environ.get("POSTMAN_MCP_MODE", "--minimal")
    return {
        "command": "npx",
        "args": ["@postman/postman-mcp-server@latest", mode_arg],
        "env": {"POSTMAN_API_KEY": api_key},
    }


cli = make_cli(SERVER_NAME, build_config, env_keys=ENV_KEYS)


if __name__ == "__main__":
    cli()
