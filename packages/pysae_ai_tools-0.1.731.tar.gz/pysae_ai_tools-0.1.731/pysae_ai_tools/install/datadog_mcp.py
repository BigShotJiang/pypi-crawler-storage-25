"""Install the Datadog MCP server in ~/.claude.json.

API and App keys come from environment variables (DD_API_KEY, DD_APP_KEY).
The DD_SITE is hardcoded to `datadoghq.eu` because Pysae uses the EU instance.
"""

import os
from typing import Any

from .common.mcp_cli import State, make_cli, state_for

SERVER_NAME = "datadog"
ENV_KEYS = ("DD_API_KEY", "DD_APP_KEY", "DD_SITE")


def get_state() -> State:
    return state_for(SERVER_NAME, env_keys=ENV_KEYS)


def do_install() -> dict[str, Any]:
    from .common import mcp

    config = build_config()
    changed = mcp.upsert_server(SERVER_NAME, config)
    return {"action": "install", "name": SERVER_NAME, "changed": changed}


def build_config() -> dict[str, Any]:
    api_key = os.environ.get("DD_API_KEY", "").strip()
    app_key = os.environ.get("DD_APP_KEY", "").strip()
    if not api_key or not app_key:
        raise ValueError(
            "DD_API_KEY and DD_APP_KEY must be set in the environment before running install. "
            "Get them from https://app.datadoghq.eu/organization-settings/api-keys "
            "and https://app.datadoghq.eu/organization-settings/application-keys."
        )
    return {
        "command": "uvx",
        "args": [
            "--from",
            "git+https://github.com/shelfio/datadog-mcp.git",
            "datadog-mcp",
        ],
        "env": {
            "DD_API_KEY": api_key,
            "DD_APP_KEY": app_key,
            "DD_SITE": os.environ.get("DD_SITE", "datadoghq.eu"),
        },
    }


cli = make_cli(SERVER_NAME, build_config, env_keys=ENV_KEYS)


if __name__ == "__main__":
    cli()
