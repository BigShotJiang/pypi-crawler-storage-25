"""Install the Chrome DevTools MCP server in ~/.claude.json."""

from typing import Any

from .common.mcp_cli import State, make_cli, state_for

SERVER_NAME = "chrome-devtools"


def build_config() -> dict[str, Any]:
    return {
        "command": "npx",
        "args": ["@anthropic-ai/chrome-devtools-mcp@latest"],
    }


def get_state() -> State:
    return state_for(SERVER_NAME)


def do_install() -> dict[str, Any]:
    from .common import mcp

    config = build_config()
    changed = mcp.upsert_server(SERVER_NAME, config)
    return {"action": "install", "name": SERVER_NAME, "changed": changed}


cli = make_cli(SERVER_NAME, build_config)


if __name__ == "__main__":
    cli()
