"""Install or update the GitHub CLI (gh) using the binary tarball/zip release.

Avoids OS-specific package managers so the same code path works on every OS.
Authentication is handled separately by the SKILL.md (PAT + /update-config).
"""

import json
import os
import subprocess
from dataclasses import dataclass
from typing import Annotated

import typer

from .common import binary, github, platform
from .common.download import download_and_install_binary

GH_REPO = "cli/cli"
BINARY_NAME = "gh"


def _arch_token(plat: platform.Platform) -> str:
    return "amd64" if plat.arch.value == "x86_64" else plat.arch.value


def archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Return (url, archive_member) for the gh binary release.

    Linux/macOS: gh_<ver>_<os>_<arch>.tar.gz, member gh_<ver>_<os>_<arch>/bin/gh
    Windows: gh_<ver>_windows_<arch>.zip, member bin/gh.exe
    """
    ver = version.lstrip("v")
    arch = _arch_token(plat)
    if plat.is_windows:
        return (
            f"https://github.com/cli/cli/releases/download/v{ver}/gh_{ver}_windows_{arch}.zip",
            "bin/gh.exe",
        )
    base = f"gh_{ver}_{plat.os.value}_{arch}"
    return (
        f"https://github.com/cli/cli/releases/download/v{ver}/{base}.tar.gz",
        f"{base}/bin/gh",
    )


def auth_status() -> tuple[bool, str]:
    """Run `gh auth status` honoring GH_TOKEN if set."""
    if not binary.which(BINARY_NAME):
        return False, "gh not installed"
    env = {**os.environ}
    r = subprocess.run(
        [BINARY_NAME, "auth", "status"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
        env=env,
    )
    return r.returncode == 0, (r.stdout + r.stderr).strip()


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str
    auth_ok: bool
    auth_message: str
    has_gh_token_env: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "auth_ok": self.auth_ok,
            "auth_message": self.auth_message,
            "has_gh_token_env": self.has_gh_token_env,
            "needs_install": not self.binary.installed,
            "needs_update": self.binary.installed and binary.needs_update(self.binary.version, self.latest),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="--version")
    try:
        latest = github.latest_release(GH_REPO).lstrip("v")
    except Exception:  # noqa: BLE001
        latest = ""
    ok, message = auth_status()
    return State(
        binary=bin_status,
        latest=latest,
        auth_ok=ok,
        auth_message=message,
        has_gh_token_env=bool(os.environ.get("GH_TOKEN")),
    )


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))
    try:
        latest = github.latest_release(GH_REPO).lstrip("v")
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch latest release: {exc}")
    url, member = archive_url(latest, plat)
    try:
        path = download_and_install_binary(url, BINARY_NAME, archive_member=member)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"download/install failed: {exc}")
    installed_v = binary.get_version(BINARY_NAME, version_arg="--version")
    return InstallReport(action="install", version=installed_v or latest, path=str(path))


cli = typer.Typer(no_args_is_help=True, help="Install/update the GitHub CLI (gh) and authenticate")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"gh: {b.version or 'n/a'} (latest {state.latest or 'n/a'})")
        typer.echo(f"  auth: {'OK' if state.auth_ok else 'NOT authenticated'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed gh {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
