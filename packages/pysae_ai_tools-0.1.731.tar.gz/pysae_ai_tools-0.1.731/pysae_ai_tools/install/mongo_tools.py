"""Install or update mongosh + MongoDB Database Tools.

Strategy:
- mongosh: npm global install (works on Linux, macOS, Windows when Node is available).
- Database Tools: download the platform-specific archive from fastdl.mongodb.org.

This avoids OS-specific package managers (apt/brew) so the same code path works on
every supported platform. Users who prefer `brew` or APT can still use those manually.
"""

import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import httpx
import typer

from .common import binary, platform
from .common.download import download, extract, install_binary

MONGOSH_BIN = "mongosh"
DBTOOLS_BIN = "mongodump"  # representative binary
DBTOOLS_ALL = (
    "mongodump",
    "mongorestore",
    "mongoimport",
    "mongoexport",
    "mongostat",
    "mongotop",
    "bsondump",
    "mongofiles",
)
TOOLS_RELEASES_API = "https://api.github.com/repos/mongodb/mongo-tools/releases/latest"


def _arch_token(plat: platform.Platform) -> str:
    return "x86_64" if plat.arch.value == "x86_64" else "arm64"


def _distro_token(plat: platform.Platform) -> str:
    """MongoDB tools archives are keyed by distro. Pick a sensible default per OS."""
    if plat.is_linux:
        return "ubuntu2404"
    if plat.is_macos:
        return "macos"
    if plat.is_windows:
        return "windows"
    return "ubuntu2404"


def latest_tools_version(timeout: float = 5.0) -> str:
    r = httpx.get(TOOLS_RELEASES_API, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    data = r.json()
    tag = data.get("tag_name", "")
    if not isinstance(tag, str):
        return ""
    return tag.lstrip("v")


def tools_archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Return (url, archive extension)."""
    distro = _distro_token(plat)
    arch = _arch_token(plat)
    if plat.is_windows:
        return (
            f"https://fastdl.mongodb.org/tools/db/mongodb-database-tools-{distro}-{arch}-{version}.zip",
            "zip",
        )
    return (
        f"https://fastdl.mongodb.org/tools/db/mongodb-database-tools-{distro}-{arch}-{version}.tgz",
        "tgz",
    )


@dataclass
class State:
    mongosh: binary.BinaryStatus
    dbtools: binary.BinaryStatus
    latest_tools: str

    def to_dict(self) -> dict[str, object]:
        return {
            "mongosh": self.mongosh.to_dict(),
            "dbtools": self.dbtools.to_dict(),
            "latest_tools": self.latest_tools,
            "needs_install_mongosh": not self.mongosh.installed,
            "needs_install_dbtools": not self.dbtools.installed,
            "needs_update_dbtools": (
                self.dbtools.installed and binary.needs_update(self.dbtools.version, self.latest_tools)
            ),
        }


def get_state() -> State:
    try:
        latest = latest_tools_version()
    except Exception:  # noqa: BLE001
        latest = ""
    return State(
        mongosh=binary.status(MONGOSH_BIN, version_arg="--version"),
        dbtools=binary.status(DBTOOLS_BIN, version_arg="--version"),
        latest_tools=latest,
    )


@dataclass
class InstallReport:
    action: str
    mongosh_method: str = ""
    dbtools_version: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("mongosh_method", "dbtools_version", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _install_mongosh() -> tuple[str, str]:
    """Return (method, error)."""
    if binary.which(MONGOSH_BIN):
        return "already-installed", ""
    if not shutil.which("npm"):
        return "", "npm not available; install Node.js first or use `brew install mongosh` on macOS"
    r = subprocess.run(["npm", "install", "-g", "mongosh"], capture_output=True, text=True, check=False)
    if r.returncode != 0:
        return "", f"npm install failed: {r.stderr.strip() or r.stdout.strip()}"
    return "npm", ""


def _install_dbtools(plat: platform.Platform) -> tuple[str, str]:
    """Return (installed_version, error)."""
    try:
        version = latest_tools_version()
    except Exception as exc:  # noqa: BLE001
        return "", f"could not fetch tools version: {exc}"

    url, ext = tools_archive_url(version, plat)
    import tempfile

    with tempfile.TemporaryDirectory(prefix="pysae-mongo-tools-") as tmp_dir:
        tmp = Path(tmp_dir)
        archive = tmp / f"tools.{ext}"
        try:
            download(url, archive)
        except Exception as exc:  # noqa: BLE001
            return "", f"download failed for {url}: {exc}"
        extract_dir = tmp / "extracted"
        try:
            extract(archive, extract_dir)
        except Exception as exc:  # noqa: BLE001
            return "", f"extract failed: {exc}"

        # Find each binary in the extracted bin/ folder and install it
        bin_suffix = ".exe" if plat.is_windows else ""
        for tool in DBTOOLS_ALL:
            tool_name = f"{tool}{bin_suffix}"
            matches = list(extract_dir.rglob(tool_name))
            if not matches:
                continue
            try:
                install_binary(matches[0], tool)
            except Exception as exc:  # noqa: BLE001
                return "", f"install {tool} failed: {exc}"

    return version, ""


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))

    method, err1 = _install_mongosh()
    version, err2 = _install_dbtools(plat)
    if err1 and err2:
        return InstallReport(action="install", error=f"mongosh: {err1}; dbtools: {err2}")
    if err2:
        return InstallReport(action="install", mongosh_method=method, error=f"dbtools: {err2}")
    if err1:
        return InstallReport(action="install", dbtools_version=version, error=f"mongosh: {err1}")
    return InstallReport(action="install", mongosh_method=method, dbtools_version=version)


cli = typer.Typer(no_args_is_help=True, help="Install/update MongoDB CLI tools (mongosh, mongodump, ...)")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        typer.echo(f"mongosh: {state.mongosh.version or 'NOT installed'}")
        latest = state.latest_tools or "n/a"
        typer.echo(f"mongodump: {state.dbtools.version or 'NOT installed'} (latest tools {latest})")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed mongosh ({report.mongosh_method}) and tools v{report.dbtools_version}")


if __name__ == "__main__":
    cli()
