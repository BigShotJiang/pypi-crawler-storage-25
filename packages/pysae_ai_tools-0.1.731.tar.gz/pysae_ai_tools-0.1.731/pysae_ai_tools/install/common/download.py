"""Download archives, extract them, and install binaries to the system."""

import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path

import httpx


def default_install_prefix() -> Path:
    """Per-OS default install prefix.

    - Linux/macOS: /usr/local/bin (requires sudo)
    - Windows: %LOCALAPPDATA%\\Programs\\pysae\\bin (no admin required)
    """
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(local) / "Programs" / "pysae" / "bin"
    return Path("/usr/local/bin")


def ensure_on_path(directory: Path) -> bool:
    """Return True when `directory` is in $PATH (or %PATH% on Windows)."""
    parts = os.environ.get("PATH", "").split(os.pathsep)
    return any(Path(p) == directory for p in parts if p)


def download(url: str, dest: Path, timeout: float = 120.0) -> None:
    """Stream-download a URL to a local path."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as response:
        response.raise_for_status()
        with dest.open("wb") as fh:
            for chunk in response.iter_bytes(chunk_size=64 * 1024):
                fh.write(chunk)


def extract(archive: Path, dest: Path) -> None:
    """Extract a .tar.gz, .tgz, .tar, or .zip archive to a destination directory."""
    dest.mkdir(parents=True, exist_ok=True)
    name = archive.name.lower()
    if name.endswith((".tar.gz", ".tgz")):
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(dest, filter="data")
    elif name.endswith(".tar"):
        with tarfile.open(archive, "r:") as tar:
            tar.extractall(dest, filter="data")
    elif name.endswith(".zip"):
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(dest)
    else:
        raise ValueError(f"Unsupported archive format: {archive.name}")


def install_binary(source: Path, name: str, prefix: str | Path | None = None, mode: int = 0o755) -> Path:
    """Install a single binary to a system prefix.

    On Linux/macOS uses `sudo install -m <mode>` then falls back to direct copy if
    the prefix is user-writable. On Windows copies the binary to the per-user
    install directory (no admin required) and ensures the `.exe` suffix is present.
    """
    prefix_path = Path(prefix) if prefix is not None else default_install_prefix()

    target_name = name
    if sys.platform == "win32" and not name.lower().endswith(".exe"):
        target_name = f"{name}.exe"

    target = prefix_path / target_name

    if sys.platform == "win32":
        prefix_path.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        return target

    cmd = ["sudo", "install", "-m", oct(mode)[2:], str(source), str(target)]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode == 0:
        return target

    # Fallback: direct copy when prefix is user-writable (e.g. ~/.local/bin)
    if prefix_path.is_dir() and os.access(prefix_path, os.W_OK):
        shutil.copy2(source, target)
        target.chmod(mode)
        return target

    raise RuntimeError(f"install failed and {prefix_path} not user-writable: {result.stderr.strip()}")


def download_and_install_binary(
    url: str,
    binary_name: str,
    *,
    archive_member: str | None = None,
    prefix: str | Path | None = None,
) -> Path:
    """End-to-end: download an archive, extract it, install the named binary.

    Args:
        url: Download URL of the archive (or raw binary).
        binary_name: Name of the binary to install (e.g. 'glab').
        archive_member: Path inside the archive to the binary
            (e.g. 'bin/glab'). Required for archives, ignored for raw binaries.
        prefix: System install prefix.
    """
    with tempfile.TemporaryDirectory(prefix="pysae-install-") as tmp:
        tmp_path = Path(tmp)
        archive = tmp_path / Path(url).name
        download(url, archive)

        # Detect raw binary vs archive
        is_archive = archive.suffix.lower() in {".gz", ".tgz", ".tar", ".zip"} or archive.name.endswith(".tar.gz")

        if not is_archive:
            return install_binary(archive, binary_name, prefix=prefix)

        if archive_member is None:
            raise ValueError("archive_member is required for archive downloads")

        extract_dir = tmp_path / "extracted"
        extract(archive, extract_dir)
        source = extract_dir / archive_member
        if not source.exists():
            # Search recursively as a fallback
            candidates = list(extract_dir.rglob(Path(archive_member).name))
            if not candidates:
                raise FileNotFoundError(f"Binary {binary_name!r} not found in archive (looked for {archive_member!r})")
            source = candidates[0]
        return install_binary(source, binary_name, prefix=prefix)
