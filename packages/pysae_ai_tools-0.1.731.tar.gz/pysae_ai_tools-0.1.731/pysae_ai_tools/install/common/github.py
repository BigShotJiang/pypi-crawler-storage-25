"""Fetch the latest release tag for a GitHub repository."""

import httpx


def latest_release(repo: str, timeout: float = 10.0) -> str:
    """Return the tag_name of the latest release for `owner/repo`.

    Raises httpx.HTTPError on network failure.
    """
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    response = httpx.get(url, timeout=timeout, follow_redirects=True)
    response.raise_for_status()
    data = response.json()
    tag = data.get("tag_name", "")
    if not isinstance(tag, str):
        raise ValueError(f"Unexpected tag_name type: {type(tag).__name__}")
    return tag
