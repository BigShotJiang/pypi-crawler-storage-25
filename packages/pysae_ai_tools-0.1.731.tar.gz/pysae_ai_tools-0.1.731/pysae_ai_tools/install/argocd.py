"""Install or update the ArgoCD CLI.

Source of truth for the version is the Pysae dev server (`/api/version`).
Download is attempted from the Pysae dev mirror first, then GitHub releases.
"""

import json
import subprocess
from dataclasses import dataclass
from typing import Annotated

import httpx
import typer

from .common import binary, platform
from .common.download import download_and_install_binary

DEV_SERVER = "argocd.dev.pysae.com"
PROD_SERVER = "argocd.prod.pysae.com"
BINARY_NAME = "argocd"
GH_RELEASES = "https://github.com/argoproj/argo-cd/releases/download"


def server_version(server: str = DEV_SERVER, timeout: float = 5.0) -> str:
    """Fetch the ArgoCD server version from `/api/version`."""
    response = httpx.get(f"https://{server}/api/version", timeout=timeout, follow_redirects=True)
    response.raise_for_status()
    data = response.json()
    version = data.get("Version", "")
    return version.split("+")[0] if isinstance(version, str) else ""


def context_status(context: str) -> bool:
    """Check whether the given argocd context has a valid token."""
    if not binary.which(BINARY_NAME):
        return False
    sw = subprocess.run(
        [BINARY_NAME, "context", context],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    if sw.returncode != 0:
        return False
    check = subprocess.run(
        [BINARY_NAME, "account", "get-user-info", "--grpc-web"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    return check.returncode == 0


@dataclass
class State:
    binary: binary.BinaryStatus
    server_version: str
    contexts: dict[str, bool]

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "server_version": self.server_version,
            "contexts": self.contexts,
            "needs_install": not self.binary.installed,
            "needs_update": (
                self.binary.installed
                and bool(self.server_version)
                and binary.needs_update(self.binary.version, self.server_version)
            ),
        }


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="version")
    # `argocd version` prints to stderr too; use json client
    if bin_status.installed:
        try:
            r = subprocess.run(
                [BINARY_NAME, "version", "--client", "-o", "json"],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            data = json.loads(r.stdout) if r.stdout else {}
            client_v = data.get("client", {}).get("Version", "")
            if isinstance(client_v, str) and client_v:
                bin_status.version = binary.extract_version(client_v) or client_v.lstrip("v").split("+")[0]
        except (json.JSONDecodeError, OSError, subprocess.TimeoutExpired):
            pass
    try:
        srv = server_version(DEV_SERVER)
    except Exception:  # noqa: BLE001
        srv = ""
    contexts = (
        {ctx: context_status(ctx) for ctx in ("dev", "prod")} if bin_status.installed else {"dev": False, "prod": False}
    )
    return State(binary=bin_status, server_version=srv, contexts=contexts)


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    source: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        for f in ("version", "path", "source", "error"):
            v = getattr(self, f)
            if v:
                out[f] = v
        return out


def _binary_filename(plat: platform.Platform) -> str:
    arch = "amd64" if plat.arch.value == "x86_64" else plat.arch.value
    suffix = ".exe" if plat.is_windows else ""
    return f"argocd-{plat.os.value}-{arch}{suffix}"


def _download_url_pysae(plat: platform.Platform) -> str:
    return f"https://{DEV_SERVER}/download/{_binary_filename(plat)}"


def _download_url_github(version: str, plat: platform.Platform) -> str:
    return f"{GH_RELEASES}/v{version.lstrip('v')}/{_binary_filename(plat)}"


def do_install() -> InstallReport:
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))

    try:
        version = server_version(DEV_SERVER)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch server version: {exc}")

    # Try Pysae mirror first (linux-amd64 only), then GitHub for everything else
    last_error = ""
    sources = [("pysae-dev", _download_url_pysae(plat))] if plat.is_linux and plat.arch.value == "x86_64" else []
    sources.append(("github", _download_url_github(version, plat)))

    for source, url in sources:
        try:
            path = download_and_install_binary(url, BINARY_NAME)
            installed_v = binary.get_version(BINARY_NAME, version_arg="version")
            return InstallReport(action="install", version=installed_v or version, path=str(path), source=source)
        except Exception as exc:  # noqa: BLE001
            last_error = f"{source}: {exc}"
    return InstallReport(action="install", error=f"download failed: {last_error}")


cli = typer.Typer(no_args_is_help=True, help="Install/update the ArgoCD CLI and authenticate to dev/prod")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"argocd: {'installed' if b.installed else 'NOT installed'}")
        typer.echo(f"  client : {b.version or 'n/a'}")
        typer.echo(f"  server : {state.server_version or 'unreachable'}")
        for ctx, ok in state.contexts.items():
            typer.echo(f"  ctx {ctx}: {'OK' if ok else 'INVALID/missing'}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed argocd {report.version} from {report.source} at {report.path}")


if __name__ == "__main__":
    cli()
