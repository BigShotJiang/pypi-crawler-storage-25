"""Install or update the glab CLI (GitLab CLI).

Usage:
    pysae-ai-tools install_glab.install check     # report current state
    pysae-ai-tools install_glab.install install   # install or update
"""

import json
import subprocess
from dataclasses import dataclass, field
from typing import Annotated

import typer

from .common import binary, gitlab, platform
from .common.download import download_and_install_binary

GITLAB_PROJECT = "gitlab-org/cli"
BINARY_NAME = "glab"


@dataclass
class State:
    binary: binary.BinaryStatus
    latest: str = ""
    auth_ok: bool = False
    auth_message: str = ""

    def to_dict(self) -> dict[str, object]:
        return {
            "binary": self.binary.to_dict(),
            "latest": self.latest,
            "auth_ok": self.auth_ok,
            "auth_message": self.auth_message,
            "needs_install": not self.binary.installed,
            "needs_update": (self.binary.installed and binary.needs_update(self.binary.version, self.latest)),
        }


def auth_status() -> tuple[bool, str]:
    """Run `glab auth status` and return (ok, message)."""
    if not binary.which(BINARY_NAME):
        return False, "glab not installed"
    result = subprocess.run(
        [BINARY_NAME, "auth", "status"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    output = (result.stdout + result.stderr).strip()
    return result.returncode == 0, output


def get_state() -> State:
    bin_status = binary.status(BINARY_NAME, version_arg="--version")
    try:
        latest = gitlab.latest_release(GITLAB_PROJECT).lstrip("v")
    except Exception:  # noqa: BLE001
        latest = ""
    ok, message = auth_status()
    return State(binary=bin_status, latest=latest, auth_ok=ok, auth_message=message)


@dataclass
class InstallReport:
    action: str
    version: str = ""
    path: str = ""
    error: str = ""
    extra: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"action": self.action}
        if self.version:
            out["version"] = self.version
        if self.path:
            out["path"] = self.path
        if self.error:
            out["error"] = self.error
        if self.extra:
            out.update(self.extra)
        return out


def archive_url(version: str, plat: platform.Platform) -> tuple[str, str]:
    """Build the GitLab release archive URL and inner binary path for glab.

    Linux/macOS: glab_<ver>_<os>_<arch>.tar.gz with bin/glab inside.
    Windows: glab_<ver>_windows_<arch>.zip with bin/glab.exe inside.

    Release naming uses lowercase OS and Go-style arch names (amd64, arm64).
    """
    ver = version.lstrip("v")
    arch = "amd64" if plat.arch.value == "x86_64" else plat.arch.value
    base = f"https://gitlab.com/gitlab-org/cli/-/releases/v{ver}/downloads/glab_{ver}"
    if plat.is_windows:
        return f"{base}_{plat.os.value}_{arch}.zip", "bin/glab.exe"
    return f"{base}_{plat.os.value}_{arch}.tar.gz", "bin/glab"


def do_install() -> InstallReport:
    """Download and install the latest glab release."""
    try:
        plat = platform.detect()
    except ValueError as exc:
        return InstallReport(action="install", error=str(exc))

    try:
        latest = gitlab.latest_release(GITLAB_PROJECT).lstrip("v")
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"could not fetch latest release: {exc}")

    url, member = archive_url(latest, plat)
    try:
        path = download_and_install_binary(url, BINARY_NAME, archive_member=member)
    except Exception as exc:  # noqa: BLE001
        return InstallReport(action="install", error=f"download/install failed: {exc}")

    installed_version = binary.get_version(BINARY_NAME)
    return InstallReport(
        action="install",
        version=installed_version or latest,
        path=str(path),
    )


cli = typer.Typer(no_args_is_help=True, help="Install/update the glab CLI and authenticate to gitlab.com")


@cli.command()
def check(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    """Report the current install / auth state."""
    state = get_state()
    if json_output:
        typer.echo(json.dumps(state.to_dict()))
    else:
        b = state.binary
        typer.echo(f"glab: {'installed' if b.installed else 'NOT installed'} ({b.path or 'n/a'})")
        typer.echo(f"  current : {b.version or 'n/a'}")
        typer.echo(f"  latest  : {state.latest or 'unreachable'}")
        typer.echo(f"  auth ok : {state.auth_ok}")


@cli.command()
def install(json_output: Annotated[bool, typer.Option("--json")] = True) -> None:
    """Install or update glab to the latest release."""
    report = do_install()
    if json_output:
        typer.echo(json.dumps(report.to_dict()))
    elif report.error:
        typer.echo(f"FAILED: {report.error}", err=True)
    else:
        typer.echo(f"installed glab {report.version} at {report.path}")


if __name__ == "__main__":
    cli()
