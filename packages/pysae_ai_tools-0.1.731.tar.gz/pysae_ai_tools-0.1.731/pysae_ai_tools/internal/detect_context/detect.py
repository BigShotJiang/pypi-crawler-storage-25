"""Detect CI/local mode, MR context, and related issue context.

Resolution order:
1. Explicit CLI flags (--mr-iid, --issue-iid, --job-id, --pipeline-id) or positional refs
2. CI environment variables ($CI_MERGE_REQUEST_IID, etc.)
3. glab CLI detection (current branch MR, git remote)
4. Git ref parsing (refs/merge-requests/NNN/head)

Chained resolution: job -> pipeline -> MR -> issue (each level enriches the next).

Output: JSON object with all detected context fields.
"""

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Annotated

import typer

from .parse_refs import parse_gitlab_refs

CACHE_DIR = Path.home() / ".claude" / "pysae-ai-tools" / "detect-context-cache"
CACHE_TTL_SECONDS = 300  # 5 minutes


@dataclass
class DetectArgs:
    refs: list[str] = field(default_factory=list)
    mr_iid: str = ""
    issue_iid: str = ""
    job_id: str = ""
    pipeline_id: str = ""
    local: bool = False


@dataclass
class Context:
    # Mode
    is_ci: bool = False

    # Local git (from git commands, not API)
    git_branch: str = ""
    git_sha: str = ""
    git_prod_version: str = ""

    # Project
    project_id: str = ""
    project_path: str = ""
    project_url: str = ""
    default_branch: str = ""
    project_fallback_labels: list[str] = field(default_factory=list)

    # MR
    mr_iid: str = ""
    mr_title: str = ""
    mr_description: str = ""
    mr_author: str = ""
    mr_labels: list[str] = field(default_factory=list)
    mr_assignees: list[str] = field(default_factory=list)
    mr_url: str = ""
    mr_source_branch: str = ""
    mr_target_branch: str = ""

    # Issue (linked to MR or explicit)
    issue_iid: str = ""
    issue_title: str = ""
    issue_description: str = ""
    issue_labels: list[str] = field(default_factory=list)
    issue_assignees: list[str] = field(default_factory=list)
    issue_url: str = ""

    # Epic (from issue's epic field, details from group epics API)
    epic_iid: str = ""
    epic_title: str = ""
    epic_description: str = ""
    epic_labels: list[str] = field(default_factory=list)
    epic_url: str = ""

    # Pipeline/job (CI only)
    pipeline_id: str = ""
    pipeline_url: str = ""
    job_id: str = ""
    job_name: str = ""

    # Slack (resolved from project_path)
    tech_slack_channel: str = ""
    tech_slack_channel_id: str = ""
    public_slack_channel: str = ""
    public_slack_channel_id: str = ""

    # Diagnostics
    detection_sources: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _run_glab(*args: str, timeout: int = 15) -> str | None:
    """Run a glab command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["glab", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _run_git(*args: str, timeout: int = 10) -> str | None:
    """Run a git command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _detect_ci(ctx: Context) -> None:
    """Populate context from CI environment variables."""
    if not os.environ.get("CI"):
        return

    ctx.is_ci = True
    ctx.detection_sources.append("ci-env")

    ctx.project_id = os.environ.get("CI_PROJECT_ID", "")
    ctx.project_path = os.environ.get("CI_PROJECT_PATH", "")
    ctx.project_url = os.environ.get("CI_PROJECT_URL", "")
    ctx.default_branch = os.environ.get("CI_DEFAULT_BRANCH", "")

    ctx.pipeline_id = os.environ.get("CI_PIPELINE_ID", "")
    ctx.pipeline_url = os.environ.get("CI_PIPELINE_URL", "")
    ctx.job_id = os.environ.get("CI_JOB_ID", "")
    ctx.job_name = os.environ.get("CI_JOB_NAME", "")

    # MR context (only in merge_request_event pipelines)
    mr_iid = os.environ.get("CI_MERGE_REQUEST_IID", "")
    if mr_iid:
        ctx.mr_iid = mr_iid
        ctx.mr_source_branch = os.environ.get("CI_MERGE_REQUEST_SOURCE_BRANCH_NAME", "")
        ctx.mr_target_branch = os.environ.get("CI_MERGE_REQUEST_TARGET_BRANCH_NAME", "")
        ctx.mr_title = os.environ.get("CI_MERGE_REQUEST_TITLE", "")
        if ctx.project_url and mr_iid:
            ctx.mr_url = f"{ctx.project_url}/-/merge_requests/{mr_iid}"
        ctx.detection_sources.append("ci-mr-vars")


def _detect_from_git_ref(ctx: Context) -> None:
    """Detect info from local git state (no API calls): branch, detached HEAD, remote URL."""
    # MR IID from detached HEAD ref
    if not ctx.mr_iid:
        ref = _run_git("symbolic-ref", "HEAD")
        if not ref:
            log = _run_git("log", "-1", "--format=%D", "HEAD")
            if log:
                match = re.search(r"refs/merge-requests/(\d+)/head", log)
                if match:
                    ctx.mr_iid = match.group(1)
                    ctx.detection_sources.append("git-ref-detached")

    # Local branch and commit SHA
    branch = _run_git("branch", "--show-current")
    if branch:
        ctx.git_branch = branch
    sha = _run_git("rev-parse", "HEAD")
    if sha:
        ctx.git_sha = sha

    # Prod version from remote prod branch
    prod_msg = _run_git("log", "origin/prod", "-1", "--format=%s")
    if prod_msg:
        version_match = re.search(r"v\d+\.\d+\.\d+", prod_msg)
        if version_match:
            ctx.git_prod_version = version_match.group(0)

    # Project path from git remote (works without glab)
    if not ctx.project_path:
        remote_url = _run_git("remote", "get-url", "origin")
        if remote_url:
            # SSH: git@gitlab.com:pysae/api.git -> pysae/api
            # HTTPS: https://gitlab.com/pysae/api.git -> pysae/api
            match = re.search(r"gitlab\.com[:/](.+?)(?:\.git)?$", remote_url)
            if match:
                ctx.project_path = match.group(1)
                ctx.project_url = ctx.project_url or f"https://gitlab.com/{ctx.project_path}"
                ctx.detection_sources.append("git-remote")


def _detect_from_glab(ctx: Context) -> None:
    """Detect project and MR from glab CLI."""
    # Project
    if not ctx.project_id or not ctx.project_path:
        raw = _run_glab("repo", "view", "--output", "json")
        if raw:
            try:
                data = json.loads(raw)
                ctx.project_id = ctx.project_id or str(data.get("id", ""))
                ctx.project_path = ctx.project_path or data.get("path_with_namespace", "")
                ctx.project_url = ctx.project_url or data.get("web_url", "")
                ctx.default_branch = ctx.default_branch or data.get("default_branch", "")
                ctx.detection_sources.append("glab-repo")
            except json.JSONDecodeError:
                ctx.warnings.append("glab repo view returned invalid JSON")

    # MR (from current branch)
    if not ctx.mr_iid:
        raw = _run_glab("mr", "view", "--output", "json")
        if raw:
            try:
                data = json.loads(raw)
                ctx.mr_iid = str(data.get("iid", ""))
                ctx.mr_title = ctx.mr_title or data.get("title", "")
                ctx.mr_description = ctx.mr_description or data.get("description", "")
                author = data.get("author", {})
                ctx.mr_author = ctx.mr_author or (author.get("username", "") if isinstance(author, dict) else "")
                if not ctx.mr_labels:
                    ctx.mr_labels = data.get("labels", [])
                if not ctx.mr_assignees:
                    ctx.mr_assignees = [a.get("username", "") for a in data.get("assignees", []) if isinstance(a, dict)]
                ctx.mr_url = ctx.mr_url or data.get("web_url", "")
                ctx.mr_source_branch = ctx.mr_source_branch or data.get("source_branch", "")
                ctx.mr_target_branch = ctx.mr_target_branch or data.get("target_branch", "")
                ctx.detection_sources.append("glab-mr-view")
            except json.JSONDecodeError:
                pass


def _detect_mr_details(ctx: Context) -> None:
    """Fetch MR details via API if we have mr_iid but missing fields."""
    if not ctx.mr_iid or not ctx.project_id:
        return
    if ctx.mr_target_branch and ctx.mr_source_branch and ctx.mr_title:
        return

    raw = _run_glab("api", f"projects/{ctx.project_id}/merge_requests/{ctx.mr_iid}")
    if not raw:
        return
    try:
        data = json.loads(raw)
        ctx.mr_title = ctx.mr_title or data.get("title", "")
        ctx.mr_description = ctx.mr_description or data.get("description", "")
        author = data.get("author", {})
        ctx.mr_author = ctx.mr_author or (author.get("username", "") if isinstance(author, dict) else "")
        if not ctx.mr_labels:
            ctx.mr_labels = data.get("labels", [])
        if not ctx.mr_assignees:
            ctx.mr_assignees = [a.get("username", "") for a in data.get("assignees", []) if isinstance(a, dict)]
        ctx.mr_url = ctx.mr_url or data.get("web_url", "")
        ctx.mr_source_branch = ctx.mr_source_branch or data.get("source_branch", "")
        ctx.mr_target_branch = ctx.mr_target_branch or data.get("target_branch", "")
        ctx.detection_sources.append("glab-api-mr")
    except json.JSONDecodeError:
        ctx.warnings.append("MR API returned invalid JSON")


def _extract_epic(ctx: Context, issue_data: dict[str, object]) -> None:
    """Extract epic info from an issue API response if not already set."""
    if ctx.epic_iid:
        return
    epic = issue_data.get("epic")
    if not isinstance(epic, dict):
        return
    ctx.epic_iid = str(epic.get("iid", ""))
    ctx.epic_title = str(epic.get("title", ""))
    epic_url = str(epic.get("url", ""))
    # The API returns a relative URL (/groups/pysae/-/epics/259), make it absolute
    if epic_url and not epic_url.startswith("http"):
        ctx.epic_url = f"https://gitlab.com{epic_url}"
    else:
        ctx.epic_url = epic_url


def _detect_linked_issue(ctx: Context) -> None:
    """Detect issue linked to the MR (from description or closing references)."""
    if ctx.issue_iid or not ctx.mr_iid or not ctx.project_id:
        return

    # Try closing issues API
    raw = _run_glab("api", f"projects/{ctx.project_id}/merge_requests/{ctx.mr_iid}/closes_issues")
    if raw:
        try:
            issues = json.loads(raw)
            if issues and len(issues) > 0:
                issue = issues[0]
                ctx.issue_iid = str(issue.get("iid", ""))
                ctx.issue_title = issue.get("title", "")
                ctx.issue_description = issue.get("description", "")
                ctx.issue_url = issue.get("web_url", "")
                if not ctx.issue_labels:
                    ctx.issue_labels = issue.get("labels", [])
                if not ctx.issue_assignees:
                    ctx.issue_assignees = [
                        a.get("username", "") for a in issue.get("assignees", []) if isinstance(a, dict)
                    ]
                _extract_epic(ctx, issue)
                ctx.detection_sources.append("mr-closes-issues")
                return
        except json.JSONDecodeError:
            pass

    # Fallback: parse MR title/description for Closes #NNN / Fixes #NNN
    if ctx.mr_title:
        match = re.search(r"(?:closes?|fixes?|resolves?)\s+#(\d+)", ctx.mr_title, re.IGNORECASE)
        if match:
            ctx.issue_iid = match.group(1)
            ctx.detection_sources.append("mr-title-regex")


def _resolve_job_to_pipeline(ctx: Context) -> None:
    """If we have a job_id but no pipeline_id, fetch the job to get its pipeline."""
    if not ctx.job_id or ctx.pipeline_id:
        return
    project_id = ctx.project_id
    if not project_id and ctx.project_path:
        project_id = ctx.project_path.replace("/", "%2F")
    if not project_id:
        return

    raw = _run_glab("api", f"projects/{project_id}/jobs/{ctx.job_id}")
    if not raw:
        return
    try:
        data = json.loads(raw)
        pipeline = data.get("pipeline", {})
        ctx.pipeline_id = ctx.pipeline_id or str(pipeline.get("id", ""))
        ctx.pipeline_url = ctx.pipeline_url or str(pipeline.get("web_url", ""))
        ctx.job_name = ctx.job_name or data.get("name", "")
        # Also extract project info if available
        if not ctx.project_id:
            proj = data.get("project", {})
            ctx.project_id = str(proj.get("id", "")) if proj else ""
        ctx.detection_sources.append("job-api")
    except json.JSONDecodeError:
        ctx.warnings.append("Job API returned invalid JSON")


def _resolve_pipeline_to_mr(ctx: Context) -> None:
    """If we have a pipeline_id but no MR, check if the pipeline is associated with a MR."""
    if not ctx.pipeline_id or ctx.mr_iid:
        return
    project_id = ctx.project_id
    if not project_id and ctx.project_path:
        project_id = ctx.project_path.replace("/", "%2F")
    if not project_id:
        return

    raw = _run_glab("api", f"projects/{project_id}/pipelines/{ctx.pipeline_id}")
    if not raw:
        return
    try:
        data = json.loads(raw)
        pipeline_ref = data.get("ref", "")
        ctx.pipeline_url = ctx.pipeline_url or data.get("web_url", "")
        ctx.detection_sources.append("pipeline-api")
    except json.JSONDecodeError:
        ctx.warnings.append("Pipeline API returned invalid JSON")
        return

    # Check if ref is a MR ref (refs/merge-requests/NNN/head) → extract MR IID directly
    mr_ref_match = re.match(r"refs/merge-requests/(\d+)/head", pipeline_ref)
    if mr_ref_match:
        ctx.mr_iid = mr_ref_match.group(1)
        # Clear fields that need re-detection from the MR API
        ctx.mr_title = ""
        ctx.mr_description = ""
        ctx.mr_author = ""
        ctx.mr_url = ""
        ctx.mr_source_branch = ""
        ctx.mr_target_branch = ""
        ctx.detection_sources.append("pipeline-mr-ref")
        return

    # Otherwise, set mr_source_branch and try to find MR by branch name
    ctx.mr_source_branch = ctx.mr_source_branch or pipeline_ref
    if ctx.mr_source_branch:
        raw = _run_glab(
            "api",
            f"projects/{project_id}/merge_requests?mr_source_branch={ctx.mr_source_branch}&state=opened&per_page=1",
        )
        if raw:
            try:
                mrs = json.loads(raw)
                if mrs:
                    mr = mrs[0]
                    ctx.mr_iid = str(mr.get("iid", ""))
                    ctx.mr_title = mr.get("title", "")
                    ctx.mr_url = mr.get("web_url", "")
                    ctx.mr_target_branch = mr.get("target_branch", "")
                    ctx.detection_sources.append("pipeline-mr-lookup")
            except json.JSONDecodeError:
                pass


def _detect_issue_details(ctx: Context) -> None:
    """Fetch issue details via API if we have issue_iid but missing fields."""
    if not ctx.issue_iid or not ctx.project_id:
        return
    if ctx.issue_title and ctx.issue_url and ctx.epic_iid:
        return

    raw = _run_glab("api", f"projects/{ctx.project_id}/issues/{ctx.issue_iid}")
    if not raw:
        return
    try:
        data = json.loads(raw)
        ctx.issue_title = ctx.issue_title or data.get("title", "")
        ctx.issue_description = ctx.issue_description or data.get("description", "")
        ctx.issue_url = ctx.issue_url or data.get("web_url", "")
        if not ctx.issue_labels:
            ctx.issue_labels = data.get("labels", [])
        if not ctx.issue_assignees:
            ctx.issue_assignees = [a.get("username", "") for a in data.get("assignees", []) if isinstance(a, dict)]
        _extract_epic(ctx, data)
        ctx.detection_sources.append("glab-api-issue")
    except json.JSONDecodeError:
        ctx.warnings.append("Issue API returned invalid JSON")


def _detect_epic_details(ctx: Context) -> None:
    """Fetch epic description and labels via group epics API if we have epic_iid."""
    if not ctx.epic_iid or ctx.epic_description:
        return
    # The epic URL contains the group path: /groups/pysae/-/epics/259
    # Extract group from epic_url or fall back to project_path parent
    group_path = ""
    if ctx.epic_url:
        match = re.search(r"gitlab\.com/groups/(.+?)/-/epics/", ctx.epic_url)
        if match:
            group_path = match.group(1)
    if not group_path and ctx.project_path:
        # Use the top-level group from project_path (e.g. "pysae/api" -> "pysae")
        group_path = ctx.project_path.split("/")[0]
    if not group_path:
        return

    encoded_group = group_path.replace("/", "%2F")
    raw = _run_glab("api", f"groups/{encoded_group}/epics/{ctx.epic_iid}")
    if not raw:
        return
    try:
        data = json.loads(raw)
        ctx.epic_description = ctx.epic_description or data.get("description", "")
        if not ctx.epic_labels:
            ctx.epic_labels = data.get("labels", [])
        ctx.epic_url = ctx.epic_url or data.get("web_url", "")
        ctx.detection_sources.append("glab-api-epic")
    except json.JSONDecodeError:
        ctx.warnings.append("Epic API returned invalid JSON")


def _detect_issue_mr(ctx: Context) -> None:
    """If we have an issue but no MR, try to find a related MR."""
    if ctx.mr_iid or not ctx.issue_iid or not ctx.project_id:
        return

    raw = _run_glab("api", f"projects/{ctx.project_id}/issues/{ctx.issue_iid}/related_merge_requests")
    if raw:
        try:
            mrs = json.loads(raw)
            # Prefer open MRs
            open_mrs = [mr for mr in mrs if mr.get("state") == "opened"]
            chosen = open_mrs[0] if open_mrs else (mrs[0] if mrs else None)
            if chosen:
                ctx.mr_iid = str(chosen.get("iid", ""))
                ctx.mr_title = chosen.get("title", "")
                ctx.mr_url = chosen.get("web_url", "")
                ctx.mr_source_branch = chosen.get("source_branch", "")
                ctx.mr_target_branch = chosen.get("target_branch", "")
                ctx.detection_sources.append("issue-related-mr")
                return
        except json.JSONDecodeError:
            pass

    # Fallback: closed_by
    raw = _run_glab("api", f"projects/{ctx.project_id}/issues/{ctx.issue_iid}/closed_by")
    if raw:
        try:
            mrs = json.loads(raw)
            if mrs:
                chosen = mrs[0]
                ctx.mr_iid = str(chosen.get("iid", ""))
                ctx.mr_title = chosen.get("title", "")
                ctx.mr_url = chosen.get("web_url", "")
                ctx.mr_source_branch = chosen.get("source_branch", "")
                ctx.mr_target_branch = chosen.get("target_branch", "")
                ctx.detection_sources.append("issue-closed-by-mr")
        except json.JSONDecodeError:
            pass


# Tech Slack channel mapping: project name keyword -> (channel, channel_id)
# Fallback labels for smart categorization, keyed by repo short name.
# Used by the activity tracker when no issue/epic labels are available.
_PROJECT_FALLBACK_LABELS: dict[str, list[str]] = {
    # Application repos → domain label
    "api": ["API"],
    "op": ["Op"],
    "driver": ["Driver"],
    "editor": ["Editor"],
    "info": ["Info"],
    "screen": ["Screen"],
    "gtfs-validator": ["API"],
    "gtfsrt-to-siri": ["API"],
    "nav-data-processor-api": ["API"],
    "prefect": ["API", "Scheduling"],
    # Infra repos
    "argo-apps": ["Infra"],
    "argo-infra": ["Infra"],
    "auth-proxy": ["Infra", "Security"],
    "infra-common": ["Infra"],
    "infra-cluster": ["Infra"],
    "pysae-perf": ["Infra", "Test"],
    # Tooling
    "ai-tools": ["Tooling"],
    "platform-tools": ["Tooling"],
}

_TECH_SLACK_CHANNELS: dict[str, tuple[str, str]] = {
    "api": ("#tech-api", "C05SWB6MXE3"),
    "driver": ("#tech-driver", "C057538V93N"),
    "op": ("#tech-frontend", "C04ASKNPJES"),
    "info": ("#tech-frontend", "C04ASKNPJES"),
    "screen": ("#tech-frontend", "C04ASKNPJES"),
    "editor": ("#tech-frontend", "C04ASKNPJES"),
}
_TECH_SLACK_DEFAULT = ("#tech-global", "C098LM0192B")
_PUBLIC_SLACK = ("#tech", "C01JTHBADNU")


def _resolve_slack_channel(ctx: Context) -> None:
    """Resolve tech and public Slack channels from the project path."""
    if not ctx.project_path:
        return

    # Public channel is always #tech
    if not ctx.public_slack_channel:
        ctx.public_slack_channel = _PUBLIC_SLACK[0]
        ctx.public_slack_channel_id = _PUBLIC_SLACK[1]

    # Tech channel depends on the repo
    if not ctx.tech_slack_channel:
        repo_name = ctx.project_path.rsplit("/", 1)[-1] if "/" in ctx.project_path else ctx.project_path
        channel, channel_id = _TECH_SLACK_CHANNELS.get(repo_name, _TECH_SLACK_DEFAULT)
        ctx.tech_slack_channel = channel
        ctx.tech_slack_channel_id = channel_id


def _resolve_fallback_labels(ctx: Context) -> None:
    """Resolve project fallback labels from the project path for smart categorization."""
    if ctx.project_fallback_labels or not ctx.project_path:
        return
    repo_name = ctx.project_path.rsplit("/", 1)[-1] if "/" in ctx.project_path else ctx.project_path
    ctx.project_fallback_labels = _PROJECT_FALLBACK_LABELS.get(repo_name, [])


def _apply_overrides(ctx: Context, args: DetectArgs) -> None:
    """Apply explicit CLI overrides (--mr-iid, --issue-iid, or positional refs)."""
    # Parse positional refs first (e.g. "!42", "#123", URLs)
    if args.refs:
        ref = parse_gitlab_refs(" ".join(args.refs))
        if ref.mr_iid and not args.mr_iid:
            args.mr_iid = ref.mr_iid
        if ref.issue_iid and not args.issue_iid:
            args.issue_iid = ref.issue_iid
        if ref.job_id:
            ctx.job_id = ref.job_id
            ctx.detection_sources.append("cli-ref-job")
        if ref.pipeline_id:
            ctx.pipeline_id = ref.pipeline_id
            ctx.detection_sources.append("cli-ref-pipeline")
        if ref.project_path:
            ctx.project_path = ref.project_path
            ctx.project_url = f"https://gitlab.com/{ref.project_path}"
            # Resolve project_id from path so it takes priority over local repo detection
            raw = _run_glab("api", f"projects/{ref.project_path.replace('/', '%2F')}")
            if raw:
                try:
                    data = json.loads(raw)
                    ctx.project_id = str(data.get("id", ""))
                    ctx.default_branch = ctx.default_branch or data.get("default_branch", "")
                except json.JSONDecodeError:
                    pass
            ctx.detection_sources.append("cli-ref-project")

    if args.job_id:
        ctx.job_id = args.job_id
        ctx.detection_sources.append("cli-job-id")

    if args.pipeline_id:
        ctx.pipeline_id = args.pipeline_id
        ctx.detection_sources.append("cli-pipeline-id")

    if args.mr_iid:
        ctx.mr_iid = args.mr_iid
        # Clear derived fields that need re-detection
        ctx.mr_title = ""
        ctx.mr_description = ""
        ctx.mr_author = ""
        ctx.mr_url = ""
        ctx.mr_source_branch = ""
        ctx.mr_target_branch = ""
        ctx.detection_sources.append("cli-mr-iid")

    if args.issue_iid:
        ctx.issue_iid = args.issue_iid
        ctx.issue_title = ""
        ctx.issue_description = ""
        ctx.issue_url = ""
        ctx.issue_labels = []
        ctx.issue_assignees = []
        ctx.detection_sources.append("cli-issue-iid")


def _cache_key(cwd: str) -> str:
    """Return a stable filename-safe hash for the given working directory."""
    return hashlib.sha256(cwd.encode()).hexdigest()[:16]


def _cache_path(cwd: str) -> Path:
    """Return the cache file path for the given working directory."""
    return CACHE_DIR / f"{_cache_key(cwd)}.json"


def _read_cache(cwd: str, *, local_only: bool) -> dict[str, object] | None:
    """Read cached context for cwd.

    Returns None if:
    - cache file is missing or unreadable
    - cache is older than TTL (5 min)
    - local_only=False but cache was generated with local=True (incomplete data)
    """
    path = _cache_path(cwd)
    if not path.exists():
        return None
    age = time.time() - path.stat().st_mtime
    if age > CACHE_TTL_SECONDS:
        return None
    try:
        data: dict[str, object] = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None
    # If caller wants full context but cache was generated in local mode, reject
    cached_local = data.get("_cache_local", False)
    if not local_only and cached_local:
        return None
    return data


def _write_cache(cwd: str, output: dict[str, object], *, local_only: bool) -> None:
    """Write context output to cache file, including the generation mode."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path = _cache_path(cwd)
    to_write = {**output, "_cache_local": local_only}
    try:
        path.write_text(json.dumps(to_write, ensure_ascii=False))
    except OSError:
        pass


def detect(args: DetectArgs) -> Context:
    """Run the full detection pipeline and return the context.

    With --local: only CI env vars + git (no glab API calls).
    """
    local_only = args.local
    ctx = Context()

    # 1. CI env vars (fast, no subprocess)
    _detect_ci(ctx)

    # 2. Apply explicit overrides (includes ref parsing)
    _apply_overrides(ctx, args)

    # 3. Git ref parsing (for detached HEAD in CI)
    _detect_from_git_ref(ctx)

    # When a URL provides an explicit project (cli-ref-project), skip local repo
    # detection — the target project differs from the current working directory.
    cross_project = "cli-ref-project" in ctx.detection_sources

    if not local_only:
        # 4. glab CLI detection (project + MR from current branch) — skip for cross-project refs
        if not cross_project:
            _detect_from_glab(ctx)

        # 5. Chained resolution: job -> pipeline -> MR (needs project_id from steps 1-4)
        _resolve_job_to_pipeline(ctx)
        _resolve_pipeline_to_mr(ctx)

        # 6. If issue provided but no MR, find related MR
        if ctx.issue_iid and not ctx.mr_iid:
            _detect_issue_mr(ctx)

        # 7. Fetch missing MR details
        _detect_mr_details(ctx)

        # 8. Detect linked issue from MR
        _detect_linked_issue(ctx)

        # 9. Fetch missing issue details (also extracts epic from issue response)
        _detect_issue_details(ctx)

        # 10. Fetch epic details (description, labels) if epic_iid was found
        _detect_epic_details(ctx)

    # 12. Fallback for mr_target_branch
    if not ctx.mr_target_branch:
        ctx.mr_target_branch = ctx.default_branch or "main"

    # 13. Resolve Slack channel from project_path
    _resolve_slack_channel(ctx)
    _resolve_fallback_labels(ctx)

    return ctx


def main(
    refs: Annotated[
        list[str] | None, typer.Argument(help="GitLab refs: !IID, #IID, MR/issue/job/pipeline URLs")
    ] = None,
    mr_iid: Annotated[str, typer.Option("--mr-iid", help="Explicit MR IID override")] = "",
    issue_iid: Annotated[str, typer.Option("--issue-iid", help="Explicit issue IID override")] = "",
    job_id: Annotated[str, typer.Option("--job-id", help="Job ID (resolves to pipeline -> MR -> issue)")] = "",
    pipeline_id: Annotated[str, typer.Option("--pipeline-id", help="Pipeline ID (resolves to MR -> issue)")] = "",
    local: Annotated[bool, typer.Option("--local", help="Skip glab API calls, use only git + CI env vars")] = False,
    full: Annotated[bool, typer.Option("--full", help="Include empty fields in output (default: omit them)")] = False,
    cached: Annotated[
        bool,
        typer.Option("--cached", help="Return cached context for current cwd (refresh if >5min stale)"),
    ] = False,
) -> None:
    """Detect CI/local mode, MR, and issue context."""
    cwd = os.getcwd()

    # --cached: serve from cache if fresh and mode-compatible, otherwise refresh
    if cached:
        cached_data = _read_cache(cwd, local_only=local)
        if cached_data is not None:
            # Strip internal cache metadata before output
            cached_data.pop("_cache_local", None)
            json.dump(cached_data, sys.stdout, indent=2)
            sys.stdout.write("\n")
            return
        # Cache miss, stale, or wrong mode — run detection with requested mode

    args = DetectArgs(
        refs=refs or [],
        mr_iid=mr_iid,
        issue_iid=issue_iid,
        job_id=job_id,
        pipeline_id=pipeline_id,
        local=local,
    )

    ctx = detect(args)
    output = asdict(ctx)

    if not full:
        output = {k: v for k, v in output.items() if v}

    # Write cache for future --cached calls
    _write_cache(cwd, output, local_only=local)

    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")
