"""Post Claude response as a GitLab issue comment (3-phase flow).

Phase 1 (relay): posts placeholder ":hourglass: Demande en cours de traitement…"
Phase 2 (CI start): updates with job link — ``pysae-ai-tools internal webhook-reply start``
Phase 3 (CI end): updates with final result — ``pysae-ai-tools internal webhook-reply finish``

Required env vars:
    AI_TOOLS_WEBHOOK_PROJECT_ID      — numeric GitLab project ID
    AI_TOOLS_WEBHOOK_ISSUE_IID       — issue IID
    AI_TOOLS_WEBHOOK_REPLY_NOTE_ID   — note ID of the placeholder comment (from relay)
    CI_JOB_URL                       — link to the CI job (set by GitLab CI)

For ``finish`` only:
    CLAUDE_STATS_FILE                — path to Claude stats JSON (default: /tmp/claude-stats.json)

Optional env vars:
    GLAB_TOKEN / GITLAB_TOKEN        — GitLab API token (falls back to glab CLI config)
"""

import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

import typer

GITLAB_API = "https://gitlab.com/api/v4"

app = typer.Typer(no_args_is_help=True, help="Update GitLab issue placeholder comment during webhook CI pipeline.")


def _get_token() -> str:
    """Resolve GitLab token from env or glab CLI config."""
    for var in ("GLAB_TOKEN", "GITLAB_TOKEN"):
        token = os.environ.get(var, "")
        if token:
            return token
    # Try reading from glab config file directly
    config_path = os.path.expanduser("~/.config/glab-cli/config.yml")
    if os.path.isfile(config_path):
        with open(config_path) as f:
            for line in f:
                if "token:" in line:
                    token = line.split("token:")[-1].strip()
                    if token:
                        return token
    try:
        result = subprocess.run(["glab", "auth", "status", "-t"], capture_output=True, text=True, check=False)
        for line in result.stdout.splitlines() + result.stderr.splitlines():
            if "Token:" in line:
                return line.split("Token:")[-1].strip()
    except FileNotFoundError:
        pass
    return ""


def _update_note(project_id: str, issue_iid: str, note_id: str, body: str, token: str) -> bool:
    """Update an existing GitLab issue note. Returns True on success."""
    url = f"{GITLAB_API}/projects/{project_id}/issues/{issue_iid}/notes/{note_id}"
    data = json.dumps({"body": body}).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={"PRIVATE-TOKEN": token, "Content-Type": "application/json"},
        method="PUT",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            print(f"Note {note_id} updated (HTTP {resp.status})", file=sys.stderr)
            return True
    except urllib.error.HTTPError as exc:
        print(f"Failed to update note {note_id} (HTTP {exc.code}): {exc.read().decode()}", file=sys.stderr)
        return False


@app.command()
def start() -> None:
    """Phase 2: update the placeholder comment with the CI job link."""
    project_id = os.environ.get("AI_TOOLS_WEBHOOK_PROJECT_ID", "")
    issue_iid = os.environ.get("AI_TOOLS_WEBHOOK_ISSUE_IID", "")
    note_id = os.environ.get("AI_TOOLS_WEBHOOK_REPLY_NOTE_ID", "")
    job_url = os.environ.get("CI_JOB_URL", "")

    if not project_id or not issue_iid or not note_id:
        print("Missing project/issue/note ID, skipping.", file=sys.stderr)
        return

    token = _get_token()
    if not token:
        print("No GitLab token found, skipping.", file=sys.stderr)
        return

    if job_url:
        body = f":hourglass_flowing_sand: [Demande en cours de traitement…]({job_url})"
    else:
        body = ":hourglass_flowing_sand: Demande en cours de traitement…"

    _update_note(project_id, issue_iid, note_id, body, token)


@app.command()
def finish() -> None:
    """Phase 3: update the placeholder comment with the final status.

    When turns are posted in real-time via parse_stream, this just updates
    the placeholder with a completion status. Falls back to posting the
    full response if no turns were posted (CLAUDE_TURNS_DIR empty or unset).
    """
    project_id = os.environ.get("AI_TOOLS_WEBHOOK_PROJECT_ID", "")
    issue_iid = os.environ.get("AI_TOOLS_WEBHOOK_ISSUE_IID", "")
    note_id = os.environ.get("AI_TOOLS_WEBHOOK_REPLY_NOTE_ID", "")
    job_url = os.environ.get("CI_JOB_URL", "")
    stats_file = os.environ.get("CLAUDE_STATS_FILE", "/tmp/claude-stats.json")

    if not project_id or not issue_iid or not note_id:
        print("Missing project/issue/note ID, skipping.", file=sys.stderr)
        return

    token = _get_token()
    if not token:
        print("No GitLab token found, skipping.", file=sys.stderr)
        return

    # Read stats for error status
    if os.path.isfile(stats_file):
        try:
            with open(stats_file) as f:
                stats = json.load(f)
            is_error = stats.get("is_error", False)
        except (json.JSONDecodeError, OSError):
            is_error = False
    else:
        # No stats file — check CI_JOB_STATUS (set by GitLab in after_script)
        # to detect job failures that occurred before Claude could run
        ci_status = os.environ.get("CI_JOB_STATUS", "")
        is_error = ci_status in ("failed", "canceled")

    # Build status message
    if is_error:
        status = "Session terminée avec erreur"
        icon = ":x:"
    else:
        status = "Session terminée"
        icon = ":white_check_mark:"

    if job_url:
        body = f"{icon} [{status}]({job_url})"
    else:
        body = f"{icon} {status}"

    _update_note(project_id, issue_iid, note_id, body, token)


if __name__ == "__main__":
    app()
