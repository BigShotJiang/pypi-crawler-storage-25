"""GitLab label taxonomy for the Pysae group.

This module is the single source of truth for label constants used across scripts.
Keep in sync with the reference file: skills/references/gitlab-labels.md
The /update-references skill updates both this file and the reference file.
"""

from enum import StrEnum


class DomainLabel(StrEnum):
    API = "API"
    OP = "Op"
    DRIVER = "Driver"
    EDITOR = "Editor"
    INFO = "Info"
    INFRA = "Infra"
    SCREEN = "Screen"


class TypeLabel(StrEnum):
    BUG = "type::bug"
    FEATURE = "type::feature"
    TECHNICAL = "type::technical"
    REFACTORING = "type::refactoring"


class PriorityLabel(StrEnum):
    P1 = "priority::P1"
    P2 = "priority::P2"
    P3 = "priority::P3"


class BoardLabel(StrEnum):
    REFINEMENT = "Refinement"
    READY = "Ready"
    TO_DO = "workflow::To Do"
    IN_PROGRESS = "workflow::In progress"
    UNDER_REVIEW = "workflow::Under review"
    TO_DEPLOY = "workflow::To deploy"


# Project path → domain label mapping
# Updated by /update-references from live GitLab project list
PROJECT_TO_DOMAIN: dict[str, DomainLabel] = {
    "pysae/api": DomainLabel.API,
    "pysae/pysae-common": DomainLabel.API,
    "pysae/gtfsparser": DomainLabel.API,
    "pysae/gtfs-validator": DomainLabel.API,
    "pysae/gtfs2netex": DomainLabel.API,
    "pysae/gtfsrt-to-siri": DomainLabel.API,
    "pysae/op": DomainLabel.OP,
    "pysae/bigmap": DomainLabel.OP,
    "pysae/driver": DomainLabel.DRIVER,
    "pysae/driver-ui": DomainLabel.DRIVER,
    "pysae/editor": DomainLabel.EDITOR,
    "pysae/scheduler": DomainLabel.EDITOR,
    "pysae/info": DomainLabel.INFO,
    "pysae/pis-console": DomainLabel.INFO,
    "pysae/screen": DomainLabel.SCREEN,
    "pysae/display": DomainLabel.SCREEN,
}

# Board labels ordered from least to most advanced in the workflow
BOARD_LABEL_ORDER: list[BoardLabel] = [
    BoardLabel.REFINEMENT,
    BoardLabel.READY,
    BoardLabel.TO_DO,
    BoardLabel.IN_PROGRESS,
    BoardLabel.UNDER_REVIEW,
    BoardLabel.TO_DEPLOY,
]

DEFAULT_BOARD_LABEL = BoardLabel.REFINEMENT
