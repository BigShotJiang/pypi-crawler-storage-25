# Weight Guide — Fibonacci Estimation

## Referentiel

IMPORTANT: Always estimate based on **manual human effort** (no AI tooling).
This preserves comparability and makes AI-assisted velocity gains visible in dashboards.

| Weight | Time estimate | Scope |
|--------|---------------|-------|
| 1 | <= 30 min | Micro-task: config tweak, typo, one-liner fix |
| 2 | <= 0.5 day | Short but non-trivial: isolated fix, small addition, single-file change |
| 3 | ~1 day | Standard task: feature in 1-2 files, includes tests |
| 5 | 2-3 days | Significant: multi-file feature, refactoring with test coverage |
| 8 | ~5 days | Full week: structural change, cross-module, migration |
| 13 | ~10 days | Large project: rare as a single ticket, consider splitting |
| 21 | >= 15 days | MUST be split into sub-issues. Only acceptable as epic-level placeholder |

## Auto-suggestion heuristics

Analyze context to propose a weight based on these signals:

**Weight 1-2 signals:**
- Single file mentioned
- Config/env change
- Typo, rename, label fix
- No test changes needed

**Weight 3 signals:**
- 1-2 files impacted
- New function or endpoint (simple)
- Tests to add or update
- Clear before/after diff

**Weight 5 signals:**
- 3+ files impacted
- New feature with validation, error handling
- Multiple test cases
- Touches API + frontend or API + mobile

**Weight 8 signals:**
- Cross-module changes
- Database migration involved
- Breaking change or deprecation path
- Requires staging validation

**Weight 13+ signals:**
- Multi-service coordination
- Architecture change
- Data migration with rollback plan
- Suggest splitting into smaller issues

## Interaction pattern

After analyzing context, present the suggestion:

```
Poids suggere: **X** (~estimation temps)
Raison: [1-line justification based on scope signals]
```

Then ask for confirmation before including in the ticket.
