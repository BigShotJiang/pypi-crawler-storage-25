# Règles de rédaction en français

## Accents et typographie

- **Toujours accentuer**, y compris les majuscules : À, É, È, Ê, Ç, Ù, etc.
  - ✅ « Éléments à vérifier avant déploiement » — ❌ « Elements a verifier avant deploiement »
- Guillemets français « » (avec espaces insécables) plutôt que " "
- Espace insécable avant `:`, `;`, `!`, `?` — sauf dans du code ou du Markdown technique

## Grammaire et style

- **Pas de franglais inutile** : utiliser le terme français quand il existe (vérifier, déployer, fusionner — pas checker, merger). Exception : termes techniques sans équivalent courant (commit, pipeline, pod, rollout, webhook, etc.)
- **Ne pas traduire** : noms de branches, fichiers, variables, commandes, logs, identifiants techniques

## Ton

- Professionnel mais pas rigide — phrases courtes, voix active, tutoiement
