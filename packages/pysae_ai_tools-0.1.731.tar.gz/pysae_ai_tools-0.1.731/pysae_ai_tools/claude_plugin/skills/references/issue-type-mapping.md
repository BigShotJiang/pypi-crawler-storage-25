# Issue type mapping

Determine the type from the `type::*` label on the GitLab issue. Set working variables accordingly:

| Label | `TYPE` | `BRANCH_PREFIX` | `COMMIT_PREFIX` |
|-------|--------|-----------------|-----------------|
| `type::bug` | `bug` | `fix` | `fix` |
| `type::feature` | `feature` | `feat` | `feat` |
| `type::technical` | `technical` | `tech` | `tech` |
| `type::refactoring` | `refactoring` | `refactor` | `refactor` |

When no label is available, the type can also be inferred from:
- **Branch name**: `fix/` → bug, `feat/` → feature, `tech/` → technical, `refactor/` → refactoring
- **Commit prefix**: `fix:` → bug, `feat:` → feature, `tech:` → technical, `refactor:` → refactoring
