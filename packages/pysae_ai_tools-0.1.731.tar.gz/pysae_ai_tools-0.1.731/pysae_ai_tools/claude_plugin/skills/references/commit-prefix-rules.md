# Commit prefix rules

To determine the `COMMIT_PREFIX` for commits:

1. If explicitly provided (e.g. via `$ARGUMENTS`), use it as-is
2. Otherwise, infer from the branch name: `fix/` → `fix`, `feat/` → `feat`, `tech/` → `tech`, `refactor/` → `refactor`
3. If still unknown, default to `fix`
