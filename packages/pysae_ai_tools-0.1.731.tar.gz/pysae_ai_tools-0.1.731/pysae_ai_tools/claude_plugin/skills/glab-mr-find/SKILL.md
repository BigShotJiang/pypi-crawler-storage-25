---
name: glab-mr-find
description: >
  Find a GitLab merge request by IID, URL, author, or keywords.
  Use when the user says /glab-mr-find, 'trouve la MR de', 'cherche la MR',
  'quelle MR', 'la MR de <author>', 'MR sur le cache', or needs to locate a specific MR.
argument-hint: "<MR !IID or URL, author name, or search keywords>"
allowed-tools:
  - Bash
  - AskUserQuestion
  - Skill
---

Find a GitLab merge request and return its details.

## Step 1 — Resolve the MR

**If `$ARGUMENTS` contains a GitLab ref** (`!IID`, URL):
```bash
CTX=$(pysae-ai-tools internal detect-context $ARGUMENTS_REFS)
MR_IID=$(echo "$CTX" | jq -r '.mr_iid // empty')
```
If `MR_IID` is resolved, skip to Step 2.

**If `$ARGUMENTS` is natural language** (author name, keywords):

First resolve context for the current project:
```bash
CTX=$(pysae-ai-tools internal detect-context --local)
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

### Search by author

If the user mentions a person, delegate to `/glab-user-find` to resolve the GitLab username, then search:
```bash
glab mr list --author <resolved_username>
```

### Search by keywords

If the user describes the MR content:
```bash
glab mr list --search "<keywords>"
```

If multiple results, present the list and ask the user to pick one. If one match, use it.

## Step 2 — Display MR details

Once resolved, fetch full MR details via detect_context:
```bash
CTX=$(pysae-ai-tools internal detect-context "!${MR_IID}")
```

Present: title, author, source/target branch, labels, assignees, URL, linked issue.

Then suggest available actions:
> Actions possibles :
> - `/git-mr-checkout !<IID>` — checkout la branche de la MR
> - `/code-review !<IID>` — review de la MR
> - `/code-review-fix !<IID>` — review + fix automatique
> - `/ci-run` — lancer un job CI sur la pipeline de la MR
> - `/glab-mr-approve !<IID>` — approuver la MR

$ARGUMENTS
