# DevOps Command Reference

Exact commands for Pysae infrastructure operations. For service names, namespaces, and deployment patterns see [../../references/pysae-projects.md](../../references/pysae-projects.md).

## Pod inspection

```bash
# List pods for a service
kubectl get pods -n <namespace> -l app=<service-name>

# Pod details (events, conditions, restarts)
kubectl describe pod <pod-name> -n <namespace>

# Recent logs (last 100 lines)
kubectl logs <pod-name> -n <namespace> --tail=100

# Logs with previous container (after crash)
kubectl logs <pod-name> -n <namespace> --previous --tail=100

# All pods across an environment
kubectl get pods -n <namespace> --sort-by=.status.startTime
```

## Deploy status

```bash
# ArgoCD app status
argocd app get <app-name> --grpc-web 2>/dev/null || \
  kubectl get application <app-name> -n argocd -o jsonpath='{.status.sync.status}'

# Recent deployments (via ArgoCD history)
argocd app history <app-name> --grpc-web 2>/dev/null || \
  kubectl get application <app-name> -n argocd -o jsonpath='{.status.history}'

# Check rollout status
kubectl rollout status deployment/<deployment-name> -n <namespace>
```

## Scaling

```bash
# Current replicas
kubectl get deployment <deployment-name> -n <namespace> -o jsonpath='{.spec.replicas}'

# Scale up/down (ALWAYS ask user confirmation first)
kubectl scale deployment/<deployment-name> -n <namespace> --replicas=<N>

# Check HPA if exists
kubectl get hpa -n <namespace>
```

## Rollback

**Always ask user confirmation before rollback.**

```bash
# Rollback to previous revision
kubectl rollout undo deployment/<deployment-name> -n <namespace>

# Rollback to specific revision
kubectl rollout undo deployment/<deployment-name> -n <namespace> --to-revision=<N>

# ArgoCD rollback
argocd app rollback <app-name> <revision> --grpc-web
```

## Helm operations

```bash
# List releases in namespace
helm list -n <namespace>

# Show current values
helm get values <release-name> -n <namespace>

# Show computed manifest
helm template <chart-path> -f <values-file>

# Diff before upgrade (if helm-diff plugin available)
helm diff upgrade <release-name> <chart-path> -f <values-file> -n <namespace>
```

## ArgoCD app management

```bash
# Sync an app (trigger deploy)
argocd app sync <app-name> --grpc-web

# Hard refresh (force manifest comparison)
argocd app get <app-name> --hard-refresh --grpc-web

# Check sync diff
argocd app diff <app-name> --grpc-web
```

## Resource debugging

```bash
# Events in namespace (sorted by time)
kubectl get events -n <namespace> --sort-by=.lastTimestamp | tail -30

# Resource usage
kubectl top pods -n <namespace> --sort-by=memory
kubectl top nodes

# Describe service/ingress
kubectl describe svc <service-name> -n <namespace>
kubectl describe ingress <ingress-name> -n <namespace>
```

## Datadog

Prefer the **Datadog MCP tools** when available (`mcp__datadog__get_logs`, `mcp__datadog__list_monitors`, etc.) over raw curl commands. The MCP tools handle authentication and pagination automatically.

If MCP is not available, fall back to curl:

```bash
# Search error logs for a service (15 days)
curl -s -X POST "https://api.datadoghq.eu/api/v2/logs/events/search" \
  -H "DD-API-KEY: ${DD_API_KEY}" \
  -H "DD-APPLICATION-KEY: ${DD_APP_KEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "filter": {
      "query": "service:<service-name> status:error",
      "from": "now-15d",
      "to": "now"
    },
    "sort": "-timestamp",
    "page": { "limit": 50 }
  }'
```

## Config & secrets

```bash
# List configmaps
kubectl get configmap -n <namespace>

# View a configmap
kubectl get configmap <name> -n <namespace> -o yaml

# List secrets (names only — NEVER display secret values)
kubectl get secrets -n <namespace>
```

For reading/writing application secrets in AWS Secrets Manager, use the `/aws-secret-env` skill.
