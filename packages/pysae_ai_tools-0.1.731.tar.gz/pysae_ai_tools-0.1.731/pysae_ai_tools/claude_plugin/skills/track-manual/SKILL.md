---
name: track-manual
description: >
  Log manual time entries in the activity tracker. Use when the user says
  /track-manual, 'j ai travaillé', 'j ai bossé', 'log du temps', 'ajoute du temps',
  'time entry', 'j ai passé X heures sur', 'je travaille depuis', or wants to
  record manual work time on an issue, epic, or project.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Enregistre une entrée de temps manuelle dans l'activity tracker via `pysae-ai-tools tracker manual`.

## Step 1 — Extraire les informations du message

Analyser le message de l'utilisateur pour extraire :
- **Durée** (obligatoire) : en heures ou minutes. Exemples : « 1h », « 2h30 », « 45 min », « depuis 2h ».
- **Contexte** (au moins un) : issue, epic, projet, ou description libre.
- **Date** (optionnel) : « ce matin », « hier », « lundi ». Par défaut : aujourd'hui.

## Step 2 — Clarifier si nécessaire

**Tu DOIS poser une question supplémentaire** si une de ces conditions est vraie :

| Condition | Question à poser |
|---|---|
| Pas de durée identifiable | « Combien de temps as-tu passé ? » |
| Ni issue, ni epic, ni projet identifié | « Sur quel ticket, epic ou projet as-tu travaillé ? » |
| Numéro d'issue/epic ambigu (pas de projet) | « Dans quel projet ? » |
| Date ambiguë | « Quel jour ? » |

Ne pas demander plus d'informations que nécessaire. Si le contexte est suffisant pour identifier un seul projet/issue/epic, ne pas reposer la question.

## Step 3 — Résoudre le contexte GitLab

Si l'utilisateur a donné un numéro d'issue ou d'epic, résoudre le contexte complet via glab :

```bash
# Pour une issue
glab api "projects/<project_id>/issues/<iid>" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(json.dumps({
    'issue_iid': str(d['iid']),
    'issue_title': d['title'],
    'issue_url': d['web_url'],
    'issue_labels': d.get('labels', []),
    'project_path': d['references']['full'].rsplit('#', 1)[0],
}))"
```

```bash
# Pour une epic (group-level)
glab api "groups/<group_id>/epics/<iid>" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(json.dumps({
    'epic_iid': str(d['iid']),
    'epic_title': d['title'],
    'epic_url': d['web_url'],
}))"
```

Si l'utilisateur n'a pas donné de numéro mais seulement un nom de projet, utiliser `pysae-ai-tools internal detect-context` depuis le répertoire du projet pour récupérer `project_path`, `project_id`, et `project_url`.

## Step 4 — Enregistrer

Convertir la durée en secondes et appeler la CLI :

```bash
pysae-ai-tools tracker manual <duration_seconds> \
  --description "..." \
  --project-path "..." \
  --project-id "..." \
  --project-url "..." \
  --issue-iid "..." \
  --issue-title "..." \
  --issue-url "..." \
  --issue-label "label1" --issue-label "label2" \
  --epic-iid "..." \
  --epic-title "..." \
  --epic-url "..." \
  --date "YYYY-MM-DD"  # seulement si != aujourd'hui
```

Omettre les flags dont la valeur est vide.

## Step 5 — Confirmer

Afficher un résumé clair :

> Entrée enregistrée : **X.Xh** sur **#IID titre** (projet) — date
