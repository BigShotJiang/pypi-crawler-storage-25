---
name: glab-issue-create
description: "Generate actionable GitLab issues from code context, specs, bugs, or refactoring needs. Use when the user says /glab-issue-create, /glab-issue, /issue, 'create a ticket', 'create an issue', 'write a ticket', or needs to formalize work into a GitLab issue."
argument-hint: "[issue title or description]"
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
  - AskUserQuestion
---

Generate an actionable GitLab issue from the provided context (code, specs, bugs, refactoring) and create it directly via the `glab` CLI.

**Prerequisite:** The `glab` CLI must be installed and authenticated (`glab auth status`).

## Mode detection

Detect the execution context using `detect_context`:
```bash
CTX=$(pysae-ai-tools internal detect-context)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
PROJECT_ID=$(echo "$CTX" | jq -r '.project_id // empty')
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

In CI mode (`IS_CI` is `true`):
- **Never use `AskUserQuestion`** — skip the confirmation step (Step 6) and create the issue directly with auto-detected values

## Workflow

1. **Analyze context** — examine all mentioned files, selected code, logs, specs
2. **Identify scope** — extract exact file paths, function names, components, dependencies
3. **Suggest weight** — propose Fibonacci weight based on scope analysis (see [../references/gitlab-weight.md](../references/gitlab-weight.md))
4. **Detect labels** — infer domain, type, priority, and **board column** from context (see [../references/gitlab-labels.md](../references/gitlab-labels.md))
5. **Match parent epic** — fetch open epics and pick the best match (see [Parent epic](#parent-epic) below)
6. **Ask for confirmation** (local mode only) — present weight, labels (including board column), and suggested parent epic; ask user to confirm or adjust. In CI mode, skip and use auto-detected values
7. **Create issue via glab** — create the issue directly using `glab issue create` (see [Output format](#output-format) below)

## Critical rules

- **Zero hallucination**: if information is not visible in context, use `<PLACEHOLDER>` or state it needs verification
- **Title in English**, action-oriented (User Story: "As [role] I want to..." / Other: "[Verb] + [complement]"). **No prefix of any kind** in the title — no scope (`[NDP]:`, `API -`), no conventional commit prefix (`feat:`, `fix:`, `chore:`), no parenthetical scope (`perf(ndp)`). Labels handle all classification
- **Description and body sections**: entirely in French (Steps, Expected Outcome, Risques, etc.)
- **Langue française** : respecter les [règles de rédaction en français](../references/french-writing-rules.md) pour tout texte généré
- **Emojis**: preserve exactly as they appear in the loaded template — do not add or remove any
- **No nested backticks** — they break GitLab markdown on copy-paste
- **Escape `#N` patterns** — in descriptions, numbered lists like `#1`, `#2`, `#3` create unwanted links to GitLab issues. Escape them as `\#1`, `\#2`, `\#3`. Only use bare `#N` when intentionally referencing a real issue (e.g. `Closes #42`)
- **No git commands** (commit, push) in steps — devs manage their own workflow
- **Do not infantilize developers** — provide just enough info to understand the problem and the resolution direction
- Use `<details>` blocks for code diffs (with 4-space indentation, no fenced code blocks inside)
- End the description body with GitLab quick actions: `/label`, `/weight`
- **Auto board placement** (MANDATORY): every issue MUST receive exactly one board column label so it appears on the [Pysae board](https://gitlab.com/groups/pysae/-/boards/546268). Apply the auto-detection rules from [../references/gitlab-labels.md](../references/gitlab-labels.md) — default to `~Refinement` when no stronger signal exists. Never create an issue without a board column label.
- **Auto-assign**: resolve the current username via `glab api user | jq -r '.username'` and pass `--assignee <username>` to `glab issue create`. Do NOT use the `/assign @me` quick action — it is not processed by the GitLab API. If the user specifies a different assignee, use their username instead
- **Use only valid labels** from [../references/gitlab-labels.md](../references/gitlab-labels.md). Never invent labels — in particular, priorities are `priority::P1`, `priority::P2`, `priority::P3` (not `priority::high`, `priority::critical`, etc.)

## Domain adaptation

Adapt focus based on the domain detected from context:

- **Backend/API**: endpoints, models, validation, performance
- **Frontend/UI**: components, state, UX, accessibility
- **Infra/DevOps**: deployments, config, observability
- **Mobile**: sync, offline, permissions, performance
- **Tests**: coverage, edge cases, flakiness
- **Documentation**: clarity, examples, onboarding

## Self-check before output

Verify mentally:
- All provided files/context analyzed
- Exact names used (no invention)
- Steps are actionable without ambiguity
- Validation criteria are measurable
- Ticket is self-contained (actionable without further clarification)
- Markdown syntax is valid for GitLab rendering
- A board column label is present (Refinement, Ready, workflow::To Do, etc.)

## GitLab issue templates (dynamic)

The team's GitLab issue templates are loaded below. **Use the template matching the detected type (`bug`, `feature`, or `technical`) as the skeleton for the description.**

**CRITICAL — preserve template formatting exactly as-is:** keep all emojis, section headers, bullet markers, and structure from the template verbatim. Do NOT strip emojis, rename headers, reorder sections, or reformat. Only fill in the placeholder content within each section. The template is the source of truth for formatting.

!`for tpl in bug feature technical; do echo "=== Template: $tpl ==="; glab api "projects/pysae%2Fissue-templates/repository/files/.gitlab%2Fissue_templates%2F${tpl}.md/raw?ref=main" 2>/dev/null; echo -e "\n"; done 2>/dev/null || echo "Templates unavailable"`

## Parent epic

Before creating the issue, match it to the most relevant parent epic using the scoring script:

```bash
pysae-ai-tools glab epic-attach-issues match-one \
  --title "<ISSUE_TITLE>" \
  --label "<LABEL1>" --label "<LABEL2>" \
  --description "<ISSUE_DESCRIPTION_FIRST_500_CHARS>"
```

The script scores the issue against all open epics (enriched with their child issue titles) and returns the top matches with confidence levels.

1. If the top match has **high** confidence → suggest that epic
2. If only **medium** confidence → suggest it but mention uncertainty
3. If all matches are **low** or no match → suggest "aucune epic"
4. If the user explicitly requests a specific epic, use that one
5. When presenting the confirmation summary, show the suggested epic (or "aucune")

## Output format

After the user confirms the weight and labels, create the issue using `glab issue create`. **Always write the description to a temp file first** to avoid shell expansion issues and hangs:

```bash
cat > /tmp/issue_desc.md <<'EOF'
[filled-in GitLab template for the detected type]

/label ~DOMAIN ~type::TYPE ~priority::PRIORITY
/weight WEIGHT
EOF

# Resolve current GitLab username
GL_USER=$(glab api user | jq -r '.username')

pysae-ai-tools glab retry issue create \
  --title "Issue title here" \
  --description "$(cat /tmp/issue_desc.md)" \
  --assignee "${GL_USER}" \
  --no-editor \
  --yes
```

## Attach to epic

After creating the issue, attach it to the matched epic using `epic-attach` (**never** use `/parent_epic` quick action — it silently fails in some cases):

```bash
pysae-ai-tools glab epic-attach --epic ${EPIC_IID} --issue ${PROJECT_PATH}#${NEW_IID}
```

Skip this step if no epic was matched.

## Timeout & retry

The `pysae-ai-tools glab retry` wrapper handles timeout, retry (3 attempts), process cleanup, and API fallback automatically. Always use it for `glab issue create`.

$ARGUMENTS
