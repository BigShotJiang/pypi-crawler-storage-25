---
name: glab-user-find
description: >
  Find a GitLab user by name (first, last, partial) in the Pysae group.
  Use when the user says /glab-user-find, 'qui est', 'trouve l utilisateur',
  'username de <name>', or when another skill needs to resolve a person name
  to a GitLab username.
argument-hint: "<first name, last name, or partial name>"
allowed-tools:
  - Bash
---

Resolve a person's name to their GitLab username in the Pysae group.

```bash
pysae-ai-tools glab find-issue --help 2>/dev/null  # Uses resolve_username internally
```

The `pysae_ai_tools.common.glab.fetch_issues` module already has `resolve_username()` which does fuzzy matching against Pysae group members. Use it directly:

```bash
MEMBERS=$(glab api "groups/pysae/members/all?per_page=100")
```

Match `$ARGUMENTS` against each member's `name` (display name) and `username`:
- Case-insensitive
- Partial match (first name, last name, or substring)
- Unicode-normalized (é=e, ç=c, etc.)

If one match: print the username and full name.
If multiple matches: list them all for the user.
If no match: inform the user.

$ARGUMENTS
