#!/usr/bin/env bash
# Scans a skill directory and outputs structured metadata for review.
# Usage: scan-skill.sh <skill-directory>
# Output: JSON-like structured report to stdout

set -euo pipefail

SKILL_DIR="${1:?Usage: scan-skill.sh <skill-directory>}"

if [ ! -d "$SKILL_DIR" ]; then
  echo "ERROR: $SKILL_DIR is not a directory" >&2
  exit 1
fi

SKILL_NAME=$(basename "$SKILL_DIR")
SKILL_MD="$SKILL_DIR/SKILL.md"

echo "=== SKILL: $SKILL_NAME ==="
echo ""

# --- File inventory ---
echo "## File inventory"
find "$SKILL_DIR" -type f | sort | while read -r f; do
  REL=$(realpath --relative-to="$SKILL_DIR" "$f")
  LINES=$(wc -l < "$f")
  SIZE=$(stat --printf="%s" "$f" 2>/dev/null || stat -f%z "$f" 2>/dev/null || echo "?")
  echo "  $REL  ($LINES lines, ${SIZE}B)"
done
echo ""

# --- Structure checks ---
echo "## Structure signals"

# Scripts present?
SCRIPT_COUNT=$(find "$SKILL_DIR" -type f \( -name "*.sh" -o -name "*.py" -o -name "*.js" -o -name "*.ts" \) ! -path "*/scan-skill.sh" | wc -l)
echo "  scripts: $SCRIPT_COUNT"

# References directory?
if [ -d "$SKILL_DIR/references" ]; then
  REF_COUNT=$(find "$SKILL_DIR/references" -type f | wc -l)
  if [ "$REF_COUNT" -eq 0 ]; then
    echo "  references/: EMPTY (directory exists but contains no files)"
  else
    echo "  references/: $REF_COUNT files"
  fi
else
  echo "  references/: absent"
fi

# Assets directory?
if [ -d "$SKILL_DIR/assets" ]; then
  ASSET_COUNT=$(find "$SKILL_DIR/assets" -type f | wc -l)
  echo "  assets/: $ASSET_COUNT files"
else
  echo "  assets/: absent"
fi

# Config file?
if [ -f "$SKILL_DIR/config.json" ]; then
  echo "  config.json: present"
else
  echo "  config.json: absent"
fi

echo ""

# --- SKILL.md analysis ---
if [ ! -f "$SKILL_MD" ]; then
  echo "  WARNING: No SKILL.md found!"
  exit 0
fi

TOTAL_LINES=$(wc -l < "$SKILL_MD")
echo "## SKILL.md metrics"
echo "  total_lines: $TOTAL_LINES"

# Frontmatter extraction (between first and second ---)
DESCRIPTION=$(sed -n '/^---$/,/^---$/p' "$SKILL_MD" | grep -E "^description:" | head -1 || echo "")
echo "  description_field: $([ -n "$DESCRIPTION" ] && echo 'present' || echo 'MISSING')"

# Section detection
echo ""
echo "## Sections detected"
grep -n "^## " "$SKILL_MD" | while read -r line; do
  echo "  $line"
done

echo ""
echo "## Content signals"

# Dedicated Gotchas section?
HAS_GOTCHAS_SECTION=$(grep -c "^## Gotchas" "$SKILL_MD" || true)
GOTCHAS_MENTIONS=$(grep -ci "gotcha" "$SKILL_MD" || true)
echo "  has_gotchas_section: $([ "$HAS_GOTCHAS_SECTION" -gt 0 ] && echo 'yes' || echo 'no')"
echo "  gotchas_mentions: $GOTCHAS_MENTIONS"

# Examples present?
EXAMPLES=$(grep -ci "example" "$SKILL_MD" || true)
echo "  example_mentions: $EXAMPLES"

# Hooks?
HOOKS=$(grep -ci "hook\|PreToolUse\|PostToolUse" "$SKILL_MD" || true)
echo "  hook_mentions: $HOOKS"

# Skill composition (references to other skills)?
SKILL_REFS=$(grep -coE '/[a-z][-a-z]+' "$SKILL_MD" || true)
echo "  skill_references: $SKILL_REFS"

# Memory / persistent data?
MEMORY=$(grep -ci 'CLAUDE_PLUGIN_DATA\|\.log\|\.jsonl\|history\|persist' "$SKILL_MD" || true)
echo "  memory_mentions: $MEMORY"

# Dual mode?
DUAL=$(grep -ci 'CI.*mode\|headless\|local.*mode\|interactive.*mode' "$SKILL_MD" || true)
echo "  dual_mode_mentions: $DUAL"

# Hardcoded values (potential config candidates) — scan SKILL.md and all reference files
HARDCODED=0
REF_FILES=("$SKILL_MD")
if [ -d "$SKILL_DIR/references" ]; then
  while IFS= read -r -d '' rf; do
    REF_FILES+=("$rf")
  done < <(find "$SKILL_DIR/references" -name "*.md" -print0 2>/dev/null)
fi
for f in "${REF_FILES[@]}"; do
  [ -f "$f" ] || continue
  COUNT=$(grep -cE '[A-Z][A-Z0-9]{6,}|C[0-9A-Z]{10}|https?://[^ ]+' "$f" || true)
  if [ "$COUNT" -gt 0 ]; then
    REL=$(realpath --relative-to="$SKILL_DIR" "$f")
    echo "  hardcoded_in $REL: $COUNT"
  fi
  HARDCODED=$((HARDCODED + COUNT))
done
echo "  potential_hardcoded_values_total: $HARDCODED"

echo ""
echo "=== END $SKILL_NAME ==="
