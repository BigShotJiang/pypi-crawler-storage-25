---
name: install-datadog-mcp
description: >
  Install and configure the Datadog MCP server for Claude Code.
  Use when the user says /install-datadog-mcp, 'install datadog', 'setup datadog mcp',
  'configurer datadog', or needs the Datadog MCP server configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install and configure the Datadog MCP server so Claude Code can query logs, metrics, monitors, and service definitions.

## Step 1 — Check current state

```bash
pysae-ai-tools install datadog-mcp check
```

Returns JSON with `configured`, `command`, `env` (booleans for DD_API_KEY/DD_APP_KEY/DD_SITE), `missing_env`, `needs_install`.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (prerequisites + keys + install) |
| `false` | **Done** — tell the user everything is OK |

## Step 2 — Prerequisites

```bash
which uvx 2>/dev/null && echo "uvx: OK" || echo "uvx: MISSING"
```

If `uvx` is missing, install `uv`:
- **Linux/macOS**: `curl -LsSf https://astral.sh/uv/install.sh | sh`
- **Windows (PowerShell)**: `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`

## Step 3 — Get Datadog keys

> Pour configurer le MCP Datadog, j'ai besoin de tes clés API Datadog.
>
> - **DD_API_KEY** : https://app.datadoghq.eu/organization-settings/api-keys
> - **DD_APP_KEY** : https://app.datadoghq.eu/organization-settings/application-keys

## Step 4 — Install

Pass the keys via env vars and run the install:

```bash
DD_API_KEY=<api-key> DD_APP_KEY=<app-key> pysae-ai-tools install datadog-mcp install
```

`DD_SITE` defaults to `datadoghq.eu` (Pysae uses the EU instance). Override only if needed: `DD_SITE=datadoghq.com`.

Upserts the `datadog` MCP server into `~/.claude.json`. Returns `{"changed": true|false, "settings_path": "..."}`.

## Step 5 — Verify

> Redémarre Claude Code puis essaie : « montre-moi les logs d'erreur de l'API sur les 4 dernières heures ».

## Gotchas

- **DD_SITE must match the org's region.** Pysae is on `datadoghq.eu`. Setting `datadoghq.com` (the default for new orgs) returns 403 Forbidden on every call.
- **App key permissions.** The App key must have `metrics_read`, `logs_read`, `monitors_read` scopes. A token with only `events_read` will fail silently on most queries.
- **Restart Claude Code after install.** MCP servers are loaded at startup.
- **Never commit keys.** `~/.claude.json` is gitignored by default — keep it that way.
- **`uvx` cache.** If the MCP server fails to start with a stale-version error, clear the cache: `uv cache clean datadog-mcp`.

## Notes

- The script is cross-platform — `~/.claude.json` resolves correctly on Linux/macOS/Windows.
- Capabilities: logs, metrics, monitors, service definitions, SLOs, CI pipelines.

$ARGUMENTS
