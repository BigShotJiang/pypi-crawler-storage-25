---
name: slack-ask-review
description: >
  Ask for a code review on Slack by posting a contextual message with the MR link.
  Use when the user says /slack-ask-review, 'demande une review', 'ask for review on slack',
  or wants to notify the team that a MR is ready for review.
argument-hint: "[optional: additional context or specific reviewer mention]"
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
  - mcp__claude_ai_Slack__slack_search_users
  - mcp__claude_ai_Slack__slack_send_message
---

Post a review request message on the appropriate Slack channel for the current merge request.

## Process

1. **Resolve context** — detect MR and project in one shot:
   ```bash
   CTX=$(pysae-ai-tools internal detect-context)
   ```
   Extract: `MR_IID`, `MR_TITLE`, `MR_DESCRIPTION`, `MR_AUTHOR`, `PROJECT_URL`, `MR_SOURCE_BRANCH`, `MR_TARGET_BRANCH`, `TECH_SLACK_CHANNEL`, `TECH_SLACK_CHANNEL_ID`.
   If `MR_IID` is empty, inform the user that no MR exists and stop.

2. **Build context summary** — gather a short summary of the changes:
   - `git diff origin/${MR_TARGET_BRANCH}...HEAD --stat` for an overview of changed files
   - From the MR description or the diff, write 1-3 bullet points summarizing what the MR does
   - **Review environment URL**: check if a review environment is deployed for this MR:
     ```bash
     glab api "projects/:id/merge_requests/${MR_IID}/deployments" 2>/dev/null | jq -r '.[].environment.external_url // empty' | head -1
     ```
     If a review URL is found, save it for inclusion in the message.

3. **Determine the Slack channel** — use `TECH_SLACK_CHANNEL_ID` from detect_context (resolved in step 1). This is the per-repo tech channel (e.g. `#tech-api`, `#tech-frontend`), with `#tech-global` as fallback.

    **CRITICAL**: never use `slack_search_channels` to discover channels — only use the channel ID from detect_context.

4. **Check for existing review request** — use the bundled script to search the channel history via the Slack API directly (no MCP needed for this step):
   ```bash
   RESULT=$(pysae-ai-tools slack ask-review \
     --channel "${TECH_SLACK_CHANNEL_ID}" \
     --project-url "${PROJECT_URL}" \
     --mr-iid "${MR_IID}")
   ```
   The script paginates through the last 30 days of messages and searches for the exact MR URL (`project_url/-/merge_requests/iid`), avoiding cross-project false positives.

   Requires `SLACK_BOT_TOKEN` in the environment. If not set, suggest the user to export it or check the secret in AWS Secrets Manager.

   Parse the JSON output:
   ```bash
   FOUND=$(echo "$RESULT" | jq -r '.found')
   ```

   - **If `found` is `true`**: do NOT post a new message. Extract `thread_ts` from the result. Check if there are new commits since the original message was posted (compare the message timestamp with `git log --since`). If there are new changes, reply **in a thread** on the original message (`thread_ts`) with the following format:
     ```
     *MR mise a jour*

     <1-2 lines summarizing what changed>

     Commits :
     - [`<short_sha>`](<project_url>/-/commit/<full_sha>) <commit message>
     - [`<short_sha>`](<project_url>/-/commit/<full_sha>) <commit message>
     ```
     If the original message contains a user mention (`<@USER_ID>`), include the same mention in the thread reply (e.g. `cc <@USER_ID>`) to re-notify the reviewer.
     If there are no new changes since the last thread reply (or the original message if no replies), reply **in a thread** with a short bump message:
     ```
     *Rappel* : cette MR est toujours en attente de review :pray:
     ```
     Include the reviewer mention (`cc <@USER_ID>`) if the original message had one.
   - **If `found` is `false`**: proceed to compose and send a new message.

5. **Ping a reviewer** (optional) — if the user specifies someone in `$ARGUMENTS`:
   - Use `slack_search_users` to find the person's Slack user ID
   - Mention them in the message with `<@USER_ID>`
   - If no one is specified, just post the message to the channel without mention

6. **Compose the message** — use this format:
   ```
   *Review demandee* : <MR title>
   <MR web URL>

   <1-3 bullet points summarizing the changes>

   Branche : `<source_branch>` -> `<target_branch>`
   ```
   If a review environment URL was found in step 2, add it after the branch line:
   ```
   :globe_with_meridians: Review env : <review_url>
   ```
   If a specific reviewer was identified, add at the end:
   ```
   cc <@USER_ID>
   ```
   If `$ARGUMENTS` contains additional context, include it in the message.

7. **Send the message** — use `slack_send_message` with the resolved channel ID.

## Rules

- **French only** for the message content
- **Langue française** : respecter les [règles de rédaction en français](../references/french-writing-rules.md) pour tout texte généré
- Keep the message short and scannable — no walls of text
- Do not include the full diff or file contents in the message
- If `glab` is not available or fails, inform the user and stop

$ARGUMENTS
