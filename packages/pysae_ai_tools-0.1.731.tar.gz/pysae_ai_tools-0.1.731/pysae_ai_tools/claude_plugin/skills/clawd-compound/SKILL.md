---
name: clawd-compound
description: >
  Extract learnings from the current session and persist them in the repo's CLAUDE.md.
  Use at the end of a work session via /claude-compound or /compound. Captures code patterns,
  mistakes made, architectural decisions, conventions discovered, and corrections received from the user.
argument-hint: "[optional: focus area or topic to extract]"
allowed-tools:
  - Read
  - Edit
  - Write
  - Glob
  - Grep
---

Review the entire conversation and extract learnings to persist in the repo's CLAUDE.md.

## Process

1. **Scan the session** — Review all exchanges in the current context window
2. **Identify learnings** — Extract items from each category below
3. **Read CLAUDE.md** — Load the repo's existing CLAUDE.md (or note its absence)
4. **Deduplicate** — Drop anything already present or contradicted by existing entries
5. **Write** — Append new entries under `## Learnings (auto-discovered)`, or update existing ones

If $ARGUMENTS is provided, focus extraction on that topic only.

## What to extract

| Category | Signal | Example |
|----------|--------|---------|
| Code patterns | Recurring conventions confirmed across files | `[api] All endpoints return {data, meta} envelope` |
| Mistakes to avoid | User corrected Claude, or a fix was needed | `[test] Do not mock DB in integration tests — use test fixtures` |
| Architectural decisions | Design choices discussed and confirmed | `[archi] State managed in Pinia stores, never in components` |
| Conventions | Naming, structure, style rules observed | `[style] Boolean props prefixed with is/has/should` |
| Testing insights | Test commands, patterns, gotchas | `[test] Run pytest with -x --tb=short for fast feedback` |
| Tooling/workflow | Dev environment specifics | `[dx] Use bun instead of npm for scripts` |

## Format

Each learning is a single line, prefixed with a domain tag:

```markdown
## Learnings (auto-discovered)

- [api] FastAPI endpoints use Depends(get_db) — always close session in finally block
- [sync] Driver offline sync uses IndexedDB queue — race condition risk on reconnect
- [test] pytest -x --tb=short is the standard test command for this repo
- [mistake] Never edit .gitlab-ci.yml from Claude — forbidden file
```

## Rules

- **Max 10 entries per run** — quality over quantity
- **Only confirmed facts** — observed in code or explicitly stated by the user, never speculative
- **Concise** — 1 line per entry, max 120 chars
- **No secrets** — never persist credentials, tokens, internal URLs
- **Update > duplicate** — if a new learning contradicts an existing one, replace the old entry
- **Mistakes are high-value** — user corrections should always be captured (prefixed `[mistake]`)
- **Respect the 200-line limit** — if CLAUDE.md is approaching 200 lines, prioritize and prune low-value entries

## If no CLAUDE.md exists

Create one with a minimal structure:

```markdown
# <repo-name>

<1-line description inferred from the session>

## Learnings (auto-discovered)

<entries>
```

Do not invent sections beyond what was confirmed in the session.

## Output

After updating CLAUDE.md, display a summary:

```
Compound: <N> learnings added, <M> updated, <P> removed
```

List each entry with its category tag. Do not commit — the user decides when to commit.
