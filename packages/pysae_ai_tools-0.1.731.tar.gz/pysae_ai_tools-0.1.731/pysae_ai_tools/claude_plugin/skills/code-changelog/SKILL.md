---
name: code-changelog
description: >
  Add a changelog entry in the changelogs/ directory. Use when the user says
  /code-changelog, /changelog, 'add changelog', 'changelog entry', or needs to document
  a change for the next release.
argument-hint: "[optional: description override]"
allowed-tools:
  - Bash
---

Create a changelog entry file in the `changelogs/` directory.

**CRITICAL: always use the script below. Never create the file manually — the script resolves the correct filename from `mr_source_branch` via `detect_context`.**

```bash
pysae-ai-tools code changelog generate --write [description from $ARGUMENTS]
```

To validate all entries in `changelogs/` against strict conventional commits format
(optionally auto-fixing non-conforming entries):

```bash
pysae-ai-tools code changelog validate           # lint only
pysae-ai-tools code changelog validate --fix     # lint + auto-fix
```

The script handles everything automatically:
- Filename: `changelogs/<mr_source_branch>.md` (with `/` replaced by `-`), fallback to `git_branch`
- Type: issue `type::*` label > branch prefix > commit prefix > `tech`
- Description: issue title > MR title > commit message > branch slug
- Issue ref `(#IID)`: added automatically — **never include `(#IID)` in the description**

Display the JSON output to the user. Do not commit.

$ARGUMENTS
