# API Service Mapping

Service alias → Datadog service name → K8S deployment → namespace.

Consult [../../references/pysae-projects.md](../../references/pysae-projects.md) for canonical mappings.

| Alias | Datadog service | K8S deployment | Namespace |
|-------|-----------------|----------------|-----------|
| `api` | `api` | `api` | `prod` |
| `api-fast` | `api-fast` | `api-fast` | `prod` |
| `ndp` | `api-nav-data-processor` | `api-nav-data-processor` | `prod` |
| `gtfsrt` | `api-gtfs-rt` | `api-gtfsrt` | `prod` |
| `stats` | `api-stats` | `api-stats` | `prod` |
| `evt` | `events-handler` | `api-events-handler` | `prod` |
| `simu` | `api-simulation` | `api-simulation-api` | `prod` |
| `docs` | `docs` | `api-docs` | `prod` |

## Usage

When user provides an alias (e.g. `ndp`), resolve it to the Datadog service name for metric queries and the K8S deployment name for kubectl commands.

If user provides a name not in this table, try fuzzy matching against both alias and Datadog service columns. If ambiguous, ask the user.

## Datadog query patterns

```
# Latency P99 for a service (last 1h)
avg:trace.fastapi.request.duration.by.service.99p{service:<dd_service>,env:prod}

# Latency P95
avg:trace.fastapi.request.duration.by.service.95p{service:<dd_service>,env:prod}

# Latency P50
avg:trace.fastapi.request.duration.by.service.50p{service:<dd_service>,env:prod}

# Error rate
sum:trace.fastapi.request.errors{service:<dd_service>,env:prod}.as_rate()

# Request throughput
sum:trace.fastapi.request.hits{service:<dd_service>,env:prod}.as_rate()
```

## kubectl patterns

```bash
# Pods status
kubectl get pods -n prod -l app=<k8s_deployment> -o wide

# Resource usage
kubectl top pods -n prod -l app=<k8s_deployment>

# Pod restarts (check RESTARTS column in get pods output)
```
