---
name: install-argocd
description: >
  Install, update, and verify the ArgoCD CLI and authentication to dev/prod servers.
  Use when the user says /install-argocd, 'install argocd', 'setup argocd',
  'configurer argocd', or needs the argocd CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the ArgoCD CLI, then authenticate to both Pysae ArgoCD environments.

## Step 1 — Check current state

```bash
pysae-ai-tools install argocd check
```

The script returns a single JSON line with: `binary` (installed, path, version), `server_version` (source of truth from `argocd.dev.pysae.com/api/version`), `contexts` (dev/prod token validity), `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | dev/prod tokens | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) then Step 3 (auth dev + prod) |
| `false` | `true` | — | Step 2 (update) then Step 3 (re-auth) |
| `false` | `false` | One or both invalid | Step 3 for invalid contexts only |
| `false` | `false` | Both valid | **Done** — tell the user everything is OK |

## Step 2 — Install or update the CLI

```bash
pysae-ai-tools install argocd install
```

The script:
1. Fetches the target version from the dev server (`/api/version`) — this is the source of truth, not GitHub releases.
2. Tries the Pysae dev mirror first (`https://argocd.dev.pysae.com/download/argocd-<os>-<arch>`), falls back to GitHub releases.
3. Installs the binary:
   - **Linux/macOS** → `/usr/local/bin/argocd` via `sudo install`.
   - **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\argocd.exe` (no admin required).
4. Returns a JSON line with `version`, `path`, `source` (`pysae-dev` or `github`), or `error`.

> The Pysae mirror only hosts `linux-amd64`. macOS, Linux ARM64, and Windows always download from GitHub releases.

## Step 3 — Authenticate via SSO

Run this step for each context flagged as invalid in Step 1, or when any argocd command fails with a token expiration error. SSO requires an interactive browser — the script does NOT automate it.

For each context (`dev`, `prod`) needing auth, launch the login command with `run_in_background: true` so the conversation is not blocked:

```bash
argocd login <SERVER> --sso --grpc-web --name <CONTEXT_NAME>
```

| Context | Server | Context name |
|---|---|---|
| dev | `argocd.dev.pysae.com` | `dev` |
| prod | `argocd.prod.pysae.com` | `prod` |

**Immediately after launching**, display to the user:

> 🌐 **Le navigateur a été ouvert sur la page SSO d'ArgoCD (<CONTEXT_NAME>).**
>
> Autorise la connexion dans la fenêtre du navigateur qui vient de s'ouvrir.
>
> Si le navigateur ne s'est pas ouvert automatiquement, clique sur ce lien : `https://<SERVER>/auth/login`
>
> ⏳ En attente de l'autorisation…

When the background command completes, read its output and confirm login succeeded by looking for `'<CONTEXT_NAME>' context modified` or `successfully logged in`. Then proceed to the next context.

## Step 4 — Final verification

Re-run the check:

```bash
pysae-ai-tools install argocd check
```

Confirm to the user that both contexts are configured and authenticated.

## Gotchas

- **Server version, not GitHub.** The CLI version must match the server version. The script reads `/api/version` from the dev server — never use GitHub's `/releases/latest` as the source of truth.
- **Sequential SSO logins.** dev and prod logins both start a local callback server on the same port. Run them **sequentially** (dev → wait for completion → prod), never in parallel.
- **`--grpc-web` is mandatory.** Servers are behind an HTTPS ingress. Without it, every command fails.
- **Never use password auth.** Always use `--sso`. Reject any `--password` / `$ARGOCD_PASSWORD` suggestion.
- **Token lifetime ~24h.** SSO tokens (via Dex) expire fast. When a command fails with auth errors, re-run Step 3 for the affected context only — no need to reinstall.
- **`--name` matters for other skills.** Use exactly `dev` and `prod` so other skills can switch context with `argocd context dev|prod`.
- **Windows PATH.** When installing on Windows, the binary lands in `%LOCALAPPDATA%\Programs\pysae\bin`. Add it to `%PATH%` if `argocd` is not found after install.

## Notes

- Updating the CLI preserves existing contexts and tokens. Only re-auth if tokens are invalid.
- The Pysae dev mirror only hosts `linux-amd64`; the script falls back to GitHub for other platforms.

$ARGUMENTS
