---
name: install-postman
description: >
  Install Postman desktop application (Linux, macOS, Windows).
  Use when the user says /install-postman, 'install postman', 'installer postman',
  'setup postman app', or needs the Postman desktop client installed.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install the Postman desktop application.

## Step 1 — Check current state

```bash
pysae-ai-tools install postman check
```

Detects Postman across `/opt/Postman` (Linux), `/Applications/Postman.app` (macOS), `%LOCALAPPDATA%\Postman` (Windows), or anywhere on `PATH`. Returns `{"installed": ..., "path": "...", "needs_install": ...}`.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (install) |
| `false` | **Done** — tell the user it's already installed and where |

## Step 2 — Install

```bash
pysae-ai-tools install postman install
```

Per-platform behavior:
- **Linux** → downloads tarball from `dl.pstmn.io`, extracts to `/opt/Postman` (sudo), creates `/usr/local/bin/postman` symlink and a `~/.local/share/applications/postman.desktop` entry.
- **macOS** → tries `brew install --cask postman` first; falls back to downloading the zip and extracting to `/Applications`.
- **Windows** → reports manual install instructions (the GUI installer cannot be silenced reliably). Suggest `winget install Postman.Postman` or download from https://www.postman.com/downloads/.

The script returns a `manual: "..."` field on Windows so the AI can relay the message verbatim.

## Step 3 — Verify

```bash
pysae-ai-tools install postman check
```

Suggest `/install-postman-mcp` afterward to wire Postman into Claude Code via MCP.

## Gotchas

- **Postman needs a GUI session.** It cannot run headless. SSH-only environments cannot install it usefully.
- **Snap conflicts on Ubuntu.** If the user previously installed Postman via Snap, the tarball install creates a separate copy. Suggest `sudo snap remove postman` first to avoid two competing installs.
- **macOS Homebrew failure modes.** `brew install --cask postman` fails if a non-Homebrew Postman already exists in `/Applications`. The script falls back to a direct zip extract; warn the user that Homebrew won't manage updates after that.
- **Windows = manual.** The script does not bypass UAC or unsigned-installer prompts. Always relay the manual message to the user.
- **Desktop entry refresh.** On Linux, the new entry may not appear in the menu until the user logs out/in or runs `update-desktop-database ~/.local/share/applications`.

## Notes

- Tarball URLs (`dl.pstmn.io/download/latest/...`) always point to the current stable release — no version pinning.
- Postman auto-updates itself once installed.

$ARGUMENTS
