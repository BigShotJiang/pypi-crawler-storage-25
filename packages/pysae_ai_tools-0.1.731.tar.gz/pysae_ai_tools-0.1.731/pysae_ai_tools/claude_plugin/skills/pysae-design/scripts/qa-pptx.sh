#!/usr/bin/env bash
# Visual QA for PPTX files — converts to PDF then PNG for review.
# Usage: bash qa-pptx.sh <file.pptx> [output-dir]

set -euo pipefail

PPTX_FILE="${1:?Usage: qa-pptx.sh <file.pptx> [output-dir]}"
OUTPUT_DIR="${2:-/tmp/pysae-qa}"

if [ ! -f "$PPTX_FILE" ]; then
  echo "Error: File not found: $PPTX_FILE" >&2
  exit 1
fi

# Check dependencies
for cmd in libreoffice pdftoppm; do
  if ! command -v "$cmd" &>/dev/null; then
    echo "Error: $cmd is required but not installed." >&2
    exit 1
  fi
done

mkdir -p "$OUTPUT_DIR"

BASENAME=$(basename "$PPTX_FILE" .pptx)
PDF_FILE="$OUTPUT_DIR/$BASENAME.pdf"

echo "Converting $PPTX_FILE → PDF..."
libreoffice --headless --convert-to pdf --outdir "$OUTPUT_DIR" "$PPTX_FILE" 2>/dev/null

echo "Converting PDF → PNG slides..."
pdftoppm -r 150 -png "$PDF_FILE" "$OUTPUT_DIR/slide"

SLIDE_COUNT=$(ls "$OUTPUT_DIR"/slide-*.png 2>/dev/null | wc -l)
echo "Done: $SLIDE_COUNT slides generated in $OUTPUT_DIR/"
echo ""
echo "Review checklist:"
echo "  - [ ] Poppins font visible (no Arial/Calibri fallback)"
echo "  - [ ] Topographic background on dark slides"
echo "  - [ ] Green blobs visible on dark slides"
echo "  - [ ] KPI cards have rounded corners"
echo "  - [ ] No horizontal lines/rules"
echo "  - [ ] Colors match brand (#00b871 dominant, #0a4b4d on dark only)"
echo ""
ls -1 "$OUTPUT_DIR"/slide-*.png
