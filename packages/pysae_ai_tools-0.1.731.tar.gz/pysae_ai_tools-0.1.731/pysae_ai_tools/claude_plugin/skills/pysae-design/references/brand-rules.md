# Pysae Brand Rules — Complete Reference

## Color palette

| Token | Hex | Usage |
|-------|-----|-------|
| **Primary green** | `#00b871` | CTAs, H1 headings, KPI stats, keyword highlights, badges, accent color, card borders |
| **Dark green** | `#0a4b4d` | Dark backgrounds (with topo image only), H2 headings, icon backgrounds |
| **Body text** | `#1a1a1a` | Paragraphs, bullet points on white backgrounds |
| **Caption gray** | `#6b7a74` | Captions, secondary labels, section numbers |
| **Card background** | `#f0faf5` | KPI cards, feature blocks, citations, encadrés — the green-tinted white |
| **Light section** | `#f4f9f6` | Alternating content sections in HTML, table row alternation |
| **Accent muted** | `#a0c8b8` | Italic accents on dark backgrounds |
| **Border gray** | `#e0e0e0` | Table borders, subtle separators |
| **White** | `#FFFFFF` | Default background for all content areas and all DOCX pages |

### Color rules

- `#00b871` is the **dominant** brand color — it should be the most visible accent across all supports
- `#0a4b4d` is reserved for **impact elements** only: hero sections, title slides, dark section breaks
- On dark backgrounds: text is white, accents are `#00b871`
- On white backgrounds: H1 in `#00b871`, H2 in `#0a4b4d`, body in `#1a1a1a`
- **Forbidden**: turquoise tones (these are Zenbus/Ineo brand territory)
- **Forbidden**: using `#0a4b4d` as a page background in DOCX — only as text color for H2 and table headers

## Typography

| Element | Font | Size | Weight | Color |
|---------|------|------|--------|-------|
| PPTX title slide | Poppins | 44pt | Bold | White |
| PPTX section H1 | Poppins | 18pt | Bold | Bicolor: `#0a4b4d` + `#00b871` keywords |
| PPTX H2 content | Poppins | 13pt | Bold | `#0a4b4d` |
| PPTX body/bullets | Poppins | 11pt | Regular | `#1a1a1a` |
| PPTX KPI stat | Poppins | 28pt | Bold | `#00b871` |
| PPTX KPI label | Poppins | 9.5pt | Regular | `#0a4b4d` |
| PPTX caption | Poppins | 8.5pt | Italic | `#6b7a74` |
| PPTX CTA text | Poppins | 11.5pt | Bold | `#0a4b4d` on green background |

### Font enforcement

Poppins is the **only** allowed font across all supports. It must be explicitly set on every text element:

- **PPTX** (pptxgenjs): `fontFace: "Poppins"` on every `addText()` call, no exceptions
- **DOCX** (docx-js): `font: "Poppins"` on every `TextRun` + in `styles.default.document.run`
- **HTML/React**: import from Google Fonts in `<head>`, apply via CSS `font-family: 'Poppins', sans-serif` globally

If you skip even one `TextRun` or `addText`, the system default font (Arial, Calibri, or Times) will leak through and break brand consistency.

## PPTX structure

### Sandwich pattern

Every presentation follows this structure:
1. **Title slide** — dark background with topographic image
2. **Content slides** — white background
3. **Section breaks** (optional) — dark background with topographic image
4. **Conclusion/CTA slide** — dark background with topographic image

### Dark slide elements

Every dark slide must include:
- **Background**: topographic image (base64 from `assets/fond-topo-b64.txt`), never a plain `#0a4b4d` fill
- **2 oval blobs**: shape `OVAL`, fill `#00b871`, transparency 85%, positioned off-canvas to the right
- **No CSS/SVG blobs**: only pptxgenjs native shapes

### KPI cards

- Shape: `ROUNDED_RECTANGLE` with `rectRadius: 0.12`
- Never use plain `RECTANGLE`
- Stat number: 28pt bold `#00b871`
- Label: 9.5pt regular `#0a4b4d`

### Section titles (bicolor)

Section headings use rich text with two green levels:
- Main text → `#0a4b4d`
- 1-2 keywords → `#00b871`

This creates visual emphasis without heavy formatting.

### Forbidden in PPTX
- Horizontal rules / separator lines
- Plain `background: { color: "0a4b4d" }` without topographic image
- CSS/SVG blobs on sections with topographic background

## DOCX structure

### Backgrounds
- **Always white** — no colored, shaded, or image backgrounds on any page
- `#0a4b4d` appears only as text color (H2, table headers), never as page fill

### Headings
- H1: `#00b871`, with green bottom border (`border.bottom: SINGLE, size 4, color "00b871"`)
- H2: `#0a4b4d`

### Document management block
Immediately after the main title, include a 4-column table:

| Version | Date | Auteur | Valideur |
|---------|------|--------|----------|
| 1.0 | YYYY-MM-DD | [Author] | [Validator] |

### Tables
- Shading: `ShadingType.CLEAR` only (never `SOLID` — renders as black fill)
- Width: always in `DXA` units (e.g., `9026` for A4 with 1200-unit margins), never `PERCENTAGE`
- Header row: `#0a4b4d` text, light green background via `ShadingType.CLEAR` with fill color

### Required elements
- Header with logo
- Footer with page numbers
- Document management block

## HTML structure

### Hero section
- Dark background with topographic image (base64)
- White headline text
- Green CTA button (`#00b871`)

### Content sections
- Alternate between `#FFFFFF` and `#f4f9f6` backgrounds
- Standard heading hierarchy with brand colors

### Global
- Import Poppins from Google Fonts: `<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">`
- Apply globally: `font-family: 'Poppins', sans-serif`
- Never use `background-color: #0a4b4d` alone — always with topographic image

## Signature elements

| Element | Spec |
|---------|------|
| Numbered badges | Zero-padded: `01`, `02`, `03` |
| XXL statistics | Large green numbers (`#00b871`) on dark backgrounds |
| Green inline keywords | Important words highlighted in `#00b871` within body text |
| Product screenshots | `border-radius: 12-16px`, subtle drop shadow |
| Logo placement | Top-left corner on title/hero slides |
