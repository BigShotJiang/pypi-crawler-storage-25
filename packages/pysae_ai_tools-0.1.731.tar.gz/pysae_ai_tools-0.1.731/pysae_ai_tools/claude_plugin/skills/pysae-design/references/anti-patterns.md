# Anti-patterns — Mistakes to avoid

These are recurring errors that have been corrected multiple times during brand iteration.
Each one is a trap that looks reasonable but produces an off-brand result.

## Visual anti-patterns

### 1. Plain dark background without topographic image
**Wrong**: `background: { color: "0a4b4d" }` or `background-color: #0a4b4d`
**Right**: Always use the topographic background image (base64 from `assets/fond-topo-b64.txt`)
**Why**: The plain dark fill looks flat and generic. The topographic texture is a core brand element that adds depth and identity.

### 2. Custom SVG/CSS backgrounds instead of the brand topo image
**Wrong**: Generating a custom SVG pattern, gradient, or CSS background
**Right**: Use the exact base64 topographic image provided in assets
**Why**: Every custom-generated background looks different and breaks visual consistency across supports.

### 3. Default font leaking through
**Wrong**: Forgetting `fontFace: "Poppins"` on one `addText` or `font: "Poppins"` on one `TextRun`
**Right**: Set Poppins explicitly on every single text element
**Why**: pptxgenjs defaults to Arial, docx-js defaults to Calibri. One missed element breaks the entire visual cohesion.

### 4. Plain RECTANGLE for KPI cards
**Wrong**: `{ shape: pptx.ShapeType.RECTANGLE }`
**Right**: `{ shape: pptx.ShapeType.ROUNDED_RECTANGLE, rectRadius: 0.12 }`
**Why**: Sharp corners feel dated and harsh. Rounded corners are part of the modern Pysae aesthetic.

### 5. Horizontal rules / separator lines in PPTX
**Wrong**: Adding line shapes or borders under titles as visual separators
**Right**: Use spacing, blocks, and layout to create visual hierarchy
**Why**: Lines clutter the slide and fight with the clean, modern aesthetic.

### 6. Dark slides without oval blobs
**Wrong**: Dark slide with just the topo background
**Right**: Add 2 green oval blobs (`OVAL`, fill `#00b871`, transparency 85%) positioned off-canvas right
**Why**: The blobs add organic movement and brand signature to dark sections.

### 7. CSS/SVG blobs on topo background sections
**Wrong**: Rendering blobs as CSS gradients or SVG on top of the topographic image
**Right**: In PPTX, use native pptxgenjs OVAL shapes only. In HTML, blobs are not needed — the topo image carries the visual weight.
**Why**: CSS/SVG blobs interfere with the topo texture and create visual noise.

### 8. Colored backgrounds on DOCX pages
**Wrong**: Setting page background to `#0a4b4d` or any other color in a Word document
**Right**: DOCX pages are always white — use color only in text and table headers
**Why**: Word documents are meant for reading and printing. Colored page backgrounds waste ink, reduce readability, and look unprofessional.

### 9. ShadingType.SOLID in DOCX tables
**Wrong**: `shading: { type: ShadingType.SOLID, color: "00b871" }`
**Right**: `shading: { type: ShadingType.CLEAR, fill: "00b871" }`
**Why**: `SOLID` renders as black fill in most Word renderers, completely hiding the intended color.

### 10. Table widths in PERCENTAGE (DOCX)
**Wrong**: `width: { size: 100, type: WidthType.PERCENTAGE }`
**Right**: `width: { size: 9026, type: WidthType.DXA }`
**Why**: Percentage widths render inconsistently across Word versions. DXA (twentieths of a point) gives pixel-perfect control. For A4 with 1200-unit margins: 9026 DXA.

## Content anti-patterns

### 11. Data-heavy "consultant report" slides
**Wrong**: Cramming 5 KPI tables, 10 metrics, and 3 charts onto a single slide
**Right**: One idea per slide. One emotion. One mental image.
**Why**: Dense data slides lose the audience. The goal is to tell a story, not dump a spreadsheet.

### 12. ROI as the leading argument
**Wrong**: "Save 30% on operating costs" as the slide title
**Right**: Start with a field scenario — "Your driver spots a breakdown at 6:47 AM. The system reroutes 12 buses in 90 seconds." ROI emerges as a natural consequence.
**Why**: Prospects connect with operational reality, not abstract savings percentages.

### 13. Attacking competitors directly
**Wrong**: "Unlike Zenbus which can't handle real-time..." or comparison tables
**Right**: Shine on your own. Show what Pysae does without naming others.
**Why**: Thought leadership means demonstrating superiority through your own excellence, not by diminishing competitors.

### 14. Hiding AI/data capabilities in generic titles
**Wrong**: "Advanced analytics capabilities"
**Right**: "IA prédictive pour anticiper les perturbations"
**Why**: AI and data are differentiators — name them explicitly when they're present.

### 15. Delivering a deck without its landing page (upsell context)
**Wrong**: Sending just the PPTX or just the HTML
**Right**: Always deliver both the PPTX deck AND the companion HTML landing page
**Why**: The deck is for the meeting, the landing page is for follow-up. They work as a pair.

### 16. Missing document management block (DOCX)
**Wrong**: Jumping straight into content after the main title
**Right**: Include a Version/Date/Author/Validator table immediately after the main title
**Why**: Professional documents need traceability. It's a basic quality standard for client-facing material.
