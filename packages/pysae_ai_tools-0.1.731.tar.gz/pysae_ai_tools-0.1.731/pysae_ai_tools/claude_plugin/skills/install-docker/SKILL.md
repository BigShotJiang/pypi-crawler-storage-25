---
name: install-docker
description: >
  Install, update, and verify Docker Engine/Desktop and configure registry
  authentication (GitLab CR, AWS ECR). Use when the user says /install-docker,
  'install docker', 'setup docker', 'configurer docker', 'docker login',
  or needs Docker configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update Docker, then configure authentication to the GitLab Container Registry and AWS ECR.

## Step 1 — Check current state

```bash
pysae-ai-tools install docker check
```

Returns JSON with `binary`, `daemon_running`, `compose_available`, `ecr_helper_installed`, `registries` (map of registry → `auth` or `credHelper:ecr-login`), `needs_install`.

| `needs_install` | `daemon_running` | Registries | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) → Step 3 (registries) |
| `false` | `false` | — | Start daemon (Linux: `sudo systemctl start docker`; macOS/Windows: launch Docker Desktop) → Step 3 |
| `false` | `true` | Missing GitLab/ECR | Step 3 |
| `false` | `true` | All OK | **Done** — tell the user everything is OK |

## Step 2 — Install or update Docker

```bash
pysae-ai-tools install docker install
```

Per-platform behavior:
- **Linux** → runs the official `get.docker.com` script via `sudo`, then adds the current user to the `docker` group. The script reports a `manual` instruction asking the user to log out/in (or `newgrp docker`) so the group takes effect.
- **macOS** → reports manual install (Docker Desktop): `brew install --cask docker` or download from https://www.docker.com/products/docker-desktop/.
- **Windows** → reports manual install: `winget install Docker.DockerDesktop` or Docker Desktop installer. Requires WSL2 backend.

Always relay any `manual` field back to the user verbatim.

## Step 3 — Configure registry authentication

### GitLab Container Registry

Pysae images are at `registry.gitlab.com/pysae/*`. Authenticate with a GitLab PAT (`read_registry`, plus `write_registry` if pushing).

If `glab` is configured, reuse its token to log in non-interactively:

```bash
GITLAB_TOKEN=$(grep 'token:' ~/.config/glab-cli/config.yml 2>/dev/null | head -1 | awk '{print $2}')
[ -n "$GITLAB_TOKEN" ] && echo "$GITLAB_TOKEN" | docker login registry.gitlab.com -u oauth2 --password-stdin
```

Otherwise, ask the user to log in interactively:

> Pour t'authentifier à la registry GitLab :
> 1. Crée un PAT avec scope `read_registry` sur https://gitlab.com/-/user_settings/personal_access_tokens
> 2. `! docker login registry.gitlab.com` (username = ton GitLab username, password = le PAT)

### AWS ECR

ECR auth tokens expire every 12h. Prefer the credential helper for transparent auto-renewal.

```bash
# Linux (Debian/Ubuntu)
sudo apt-get install -y amazon-ecr-credential-helper

# macOS
brew install docker-credential-helper-ecr

# Windows: download from https://github.com/awslabs/amazon-ecr-credential-helper/releases
```

Then add to `~/.docker/config.json`:

```json
{ "credHelpers": { "<account-id>.dkr.ecr.<region>.amazonaws.com": "ecr-login" } }
```

Manual login (12h expiry) as a fallback:

```bash
aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <account-id>.dkr.ecr.<region>.amazonaws.com
```

## Step 4 — Final verification

```bash
pysae-ai-tools install docker check
docker pull registry.gitlab.com/pysae/api:latest --quiet 2>/dev/null && echo "✔ GitLab CR OK" || echo "✘ GitLab CR FAILED"
```

## Gotchas

- **docker group requires re-login.** After `usermod -aG docker $USER`, the user MUST log out/back in (or `newgrp docker`) before `docker` works without sudo. The script reports this in its `manual` field.
- **macOS/Windows = Docker Desktop only.** The `get.docker.com` script does not work on macOS/Windows. The skill explicitly delegates to Docker Desktop with a manual install message.
- **ECR token expires every 12h.** Without the credential helper, every 12h `docker pull` fails until you re-login. Always recommend the helper for development machines.
- **GitLab `read_registry` is enough for pulls.** Don't request `write_registry` unless the user actually pushes.
- **WSL2 backend required on Windows.** Docker Desktop refuses to start without WSL2 — point the user to https://learn.microsoft.com/windows/wsl/install if needed.
- **Daemon must be running.** `daemon_running: false` in the check output means Docker is installed but not started — most install verification commands fail in that state.

## Notes

- Compose v2 is bundled with Docker Engine 20.10+ — no separate install needed for `docker compose`.
- Cross-repo Pysae images are at `registry.gitlab.com/pysae/<repo>` (GitLab CR); `webhook-relay` ships from ECR.

$ARGUMENTS
