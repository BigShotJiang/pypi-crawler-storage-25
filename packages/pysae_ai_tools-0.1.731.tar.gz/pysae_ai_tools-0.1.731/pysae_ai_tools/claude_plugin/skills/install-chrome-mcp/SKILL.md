---
name: install-chrome-mcp
description: >
  Install and configure the Chrome DevTools MCP server for Claude Code.
  Use when the user says /install-chrome-mcp, 'install chrome mcp',
  'setup chrome devtools', 'configurer chrome mcp', or needs the Chrome
  DevTools MCP server configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install and configure the Chrome DevTools MCP server so Claude Code can drive Chrome (navigate, screenshot, performance profiling, console, network).

## Step 1 — Check current state

```bash
pysae-ai-tools install chrome-mcp check
```

Returns JSON with `configured`, `command`, `needs_install`. The script reads `~/.claude.json` and reports the current state of the `chrome-devtools` MCP entry.

| `needs_install` | Action |
|---|---|
| `true` | Step 2 (prerequisites + install) |
| `false` | **Done** — tell the user everything is OK |

## Step 2 — Prerequisites

```bash
which npx 2>/dev/null && echo "npx: OK" || echo "npx: MISSING — install Node.js first"
```

`npx` ships with Node.js. If missing on Linux/macOS install via your distro package manager or `nvm`. On Windows install Node.js from https://nodejs.org.

## Step 3 — Install

```bash
pysae-ai-tools install chrome-mcp install
```

Upserts the `chrome-devtools` MCP server into `~/.claude.json` without touching other entries. Returns `{"changed": true|false, "settings_path": "..."}`.

The configuration written:
```json
{
  "command": "npx",
  "args": ["@anthropic-ai/chrome-devtools-mcp@latest"]
}
```

## Step 4 — Verify

> Redémarre Claude Code. Le MCP Chrome DevTools lance automatiquement Chrome en mode debug à la première utilisation d'un outil `mcp__chrome-devtools__*`.
>
> Essaie : « prends un screenshot de google.com »

## Gotchas

- **Restart Claude Code after install.** MCP servers are loaded only at startup. The script does not restart Claude Code for you.
- **`npx` is required.** The MCP runs via `npx` — Node.js must be installed and on `PATH` (Linux/macOS/Windows).
- **No API key required.** Connection is via Chrome DevTools Protocol; no auth.
- **Chrome auto-launched.** A headless Chrome instance is spawned when an MCP tool is called. If the user already has Chrome running with debug port, the MCP attaches to it.

## Notes

- The script is cross-platform. On Windows, `~/.claude.json` resolves to `%USERPROFILE%\.claude.json`.
- Capabilities: navigation, screenshots, performance traces, console messages, network requests, DOM interaction, form filling, Lighthouse audits.

$ARGUMENTS
