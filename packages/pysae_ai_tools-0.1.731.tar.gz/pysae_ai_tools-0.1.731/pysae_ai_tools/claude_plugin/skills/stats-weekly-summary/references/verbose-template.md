# Template verbose (`--all`)

Full exhaustive listing for internal engineering audience. Slack mrkdwn format.

```
:rocket: *Recap semaine du {START_DATE} au {END_DATE}*

:merged: *MRs mergées* ({TOTAL_MR_COUNT})

*{repo_name}* ({count})
{for each MR}
• <{mr_url}|{mr_title}> — @{author} {":robot_face:" if code-agent label}
{end}

{repeat for each repo}

:white_check_mark: *Tickets fermés* ({TOTAL_ISSUE_COUNT} — {TOTAL_WEIGHT} pts)

*{repo_name}* ({count} — {weight} pts)
{for each issue}
• <{issue_url}|#{iid} {issue_title}> {weight}pt {":robot_face:" if code-agent}
{end}

{repeat for each repo}

:ship: *Déploiements prod* ({TOTAL_DEPLOY_COUNT})

{for each deploy}
• *{repo_name}* — `{sha}` sur `{ref}` — @{deployer} ({date})
{end}

:dart: *Epics en cours* ({ACTIVE_EPIC_COUNT})

{for each epic with activity}
• <{epic_url}|{epic_title}> — {closed_this_week}/{total} tickets ({percent}%)
  {for each closed issue}
  └ <{issue_url}|#{iid} {issue_title}>
  {end}
{end}

:bar_chart: *Résumé*
• {TOTAL_MR_COUNT} MRs mergées, {TOTAL_ISSUE_COUNT} tickets fermés ({TOTAL_WEIGHT} pts)
• {TOTAL_DEPLOY_COUNT} déploiements prod
• {AI_COUNT} actions assistées par IA :robot_face:
• Top contributeurs : @{user1} ({count1}), @{user2} ({count2}), @{user3} ({count3})
```

## Formatting rules

- Group MRs and issues by project path
- Sort within each group by date (most recent first)
- **AI badge** — append :robot_face: to any MR or issue with the `code-agent` label
- **Weight** — show points only when issues have a weight set, skip `0pt`
- **Top contributeurs** — top 3 by combined MR + issue count, deduplicated
- **No empty sections** — omit any section with 0 items
