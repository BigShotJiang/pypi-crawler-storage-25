#!/usr/bin/env bash
# Collects weekly engineering data from GitLab for the Pysae group.
# Usage: collect-weekly-data.sh [--since YYYY-MM-DD] [--group-id ID] [--repo REPO_NAME] [--config PATH]
# Output: JSON object with keys: merged_mrs, closed_issues, deploys, epics
#
# Requires: glab (authenticated), jq

set -euo pipefail

# --- Defaults ---
GROUP_ID="${PYSAE_GROUP_ID:-918966}"
SINCE=$(date -d "7 days ago" +%Y-%m-%dT00:00:00Z 2>/dev/null || date -v-7d +%Y-%m-%dT00:00:00Z)
REPO_FILTER=""

# --- Parse args ---
while [[ $# -gt 0 ]]; do
  case "$1" in
    --since)    SINCE="${2}T00:00:00Z"; shift 2 ;;
    --group-id) GROUP_ID="$2"; shift 2 ;;
    --repo)     REPO_FILTER="$2"; shift 2 ;;
    *)          echo "Unknown arg: $1" >&2; exit 1 ;;
  esac
done

# --- Paginated API helper (fetches all pages, max 5) ---
glab_api_paginated() {
  local endpoint="$1"
  local page=1
  local max_pages=5
  local all_results="$TMPDIR/_paginated.json"
  echo '[]' > "$all_results"

  while [ "$page" -le "$max_pages" ]; do
    local sep="&"
    [[ "$endpoint" != *"?"* ]] && sep="?"
    local result
    result=$(glab api "${endpoint}${sep}page=${page}&per_page=100" 2>/dev/null || echo '[]')
    local count
    count=$(echo "$result" | jq 'length')
    if [ "$count" -eq 0 ]; then
      break
    fi
    echo "$result" >> "$all_results"
    if [ "$count" -lt 100 ]; then
      break
    fi
    page=$((page + 1))
    sleep 0.1
  done

  jq -s 'add // []' "$all_results"
}

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

echo "Collecting data since $SINCE for group $GROUP_ID..." >&2

# --- 1. Merged MRs (paginated) ---
echo "  Fetching merged MRs..." >&2
glab_api_paginated "groups/${GROUP_ID}/merge_requests?state=merged&updated_after=${SINCE}&order_by=merged_at&sort=desc" | \
  jq --arg since "$SINCE" '[.[] | select(.merged_at != null and .merged_at >= $since) | {
    title, web_url, author: .author.username,
    project: (.references.full | split("!")[0]),
    labels, merged_at, source_branch
  }]' > "$TMPDIR/mrs.json"

MR_COUNT=$(jq 'length' "$TMPDIR/mrs.json")
echo "  → $MR_COUNT MRs" >&2

# --- 2. Closed issues (paginated) ---
echo "  Fetching closed issues..." >&2
glab_api_paginated "groups/${GROUP_ID}/issues?state=closed&updated_after=${SINCE}&order_by=updated_at&sort=desc" | \
  jq --arg since "$SINCE" '[.[] | select(.closed_at != null and .closed_at >= $since) | {
    title, web_url, iid,
    project: (.references.full | split("#")[0]),
    labels, closed_at, weight,
    milestone: .milestone.title
  }]' > "$TMPDIR/issues.json"

ISSUE_COUNT=$(jq 'length' "$TMPDIR/issues.json")
echo "  → $ISSUE_COUNT issues" >&2

# --- 3. Production deploys ---
echo "  Fetching prod deploys..." >&2
DEPLOY_RESULTS="$TMPDIR/deploys_raw.json"
echo '[]' > "$DEPLOY_RESULTS"

glab api "groups/${GROUP_ID}/projects?per_page=100&simple=true" 2>/dev/null | \
  jq -r '.[] | "\(.id) \(.path)"' | while read -r PID NAME; do

  # Optional repo filter
  if [ -n "$REPO_FILTER" ] && [ "$NAME" != "$REPO_FILTER" ]; then
    continue
  fi

  PROD_ENVS=$(glab api "projects/${PID}/environments?per_page=50" 2>/dev/null | jq -r '.[].name' | grep -E '\-prod$' || true)
  for env in $PROD_ENVS; do
    glab api "projects/${PID}/deployments?environment=${env}&updated_after=${SINCE}&status=success&per_page=10&order_by=updated_at&sort=desc" 2>/dev/null | \
      jq --arg name "$NAME" --arg since "$SINCE" '[.[] | select(.updated_at >= $since) | {
        project: $name,
        ref: .ref, sha: .sha[:8],
        deployed_at: .updated_at,
        deployer: .user.username
      }]' >> "$DEPLOY_RESULTS"
  done
  sleep 0.2
done

# Merge and deduplicate deploy results
jq -s 'add // [] | unique_by(.sha + .deployer)' "$DEPLOY_RESULTS" > "$TMPDIR/deploys.json"
DEPLOY_COUNT=$(jq 'length' "$TMPDIR/deploys.json")
echo "  → $DEPLOY_COUNT deploys" >&2

# --- 4. Epics with activity ---
echo "  Fetching epics..." >&2
glab api "groups/${GROUP_ID}/epics?state=opened&per_page=100" 2>/dev/null | \
  jq '[.[] | {id, iid, title, web_url, description}]' > "$TMPDIR/epics_raw.json"

EPICS_WITH_ACTIVITY="[]"

for EPIC_IID in $(jq -r '.[].iid' "$TMPDIR/epics_raw.json"); do
  ALL_ISSUES=$(glab api "groups/${GROUP_ID}/epics/${EPIC_IID}/issues?per_page=100" 2>/dev/null || echo '[]')

  CLOSED_THIS_WEEK=$(echo "$ALL_ISSUES" | jq --arg since "$SINCE" \
    '[.[] | select(.state == "closed" and .closed_at != null and .closed_at >= $since)]')
  CLOSED_COUNT=$(echo "$CLOSED_THIS_WEEK" | jq 'length')

  if [ "$CLOSED_COUNT" -eq 0 ]; then
    continue
  fi

  TOTAL=$(echo "$ALL_ISSUES" | jq 'length')
  CLOSED_TOTAL=$(echo "$ALL_ISSUES" | jq '[.[] | select(.state == "closed")] | length')

  EPIC_META=$(jq --arg iid "$EPIC_IID" '.[] | select(.iid == ($iid | tonumber))' "$TMPDIR/epics_raw.json")

  jq -n \
    --argjson meta "$EPIC_META" \
    --argjson closed_this_week "$CLOSED_THIS_WEEK" \
    --argjson total "$TOTAL" \
    --argjson closed_total "$CLOSED_TOTAL" \
    --argjson closed_count "$CLOSED_COUNT" \
    '{
      iid: $meta.iid, title: $meta.title, web_url: $meta.web_url,
      description: $meta.description,
      total: $total, closed_total: $closed_total,
      closed_this_week: $closed_count,
      closed_issues: $closed_this_week
    }'

  sleep 0.2
done | jq -s '.' > "$TMPDIR/epics.json"

EPIC_COUNT=$(jq 'length' "$TMPDIR/epics.json")
echo "  → $EPIC_COUNT epics with activity" >&2

# --- Final output ---
jq -n \
  --arg since "$SINCE" \
  --arg group_id "$GROUP_ID" \
  --slurpfile mrs "$TMPDIR/mrs.json" \
  --slurpfile issues "$TMPDIR/issues.json" \
  --slurpfile deploys "$TMPDIR/deploys.json" \
  --slurpfile epics "$TMPDIR/epics.json" \
  '{
    metadata: { since: $since, group_id: $group_id, collected_at: now | todate },
    merged_mrs: $mrs[0],
    closed_issues: $issues[0],
    deploys: $deploys[0],
    epics: $epics[0]
  }'
