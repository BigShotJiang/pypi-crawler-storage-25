---
name: git-mr-checkout
description: >
  Checkout the branch associated with a MR or issue.
  Use when the user says /git-mr-checkout, 'travaille sur ce ticket', 'switch sur cette MR',
  'checkout la branche de', 'bosse sur #123', 'regarde !42', or wants to work on a specific
  MR or issue by switching to its source branch.
argument-hint: "<MR !IID or URL, issue #IID or URL, author name, or search text>"
allowed-tools:
  - Bash
  - AskUserQuestion
  - Skill
---

Checkout the source branch of a MR or issue.

## Step 1 — Find the MR

Delegate to `/glab-mr-find` with `$ARGUMENTS` to resolve the MR. It handles refs (`!IID`, `#IID`, URLs) and natural language (author, keywords).

Extract `MR_SOURCE_BRANCH` from the result.

## Step 2 — Checkout

If `MR_SOURCE_BRANCH` is empty, inform the user that no branch was found and stop.

```bash
git fetch origin "${MR_SOURCE_BRANCH}" && git checkout "${MR_SOURCE_BRANCH}" && git pull --ff-only
```

Confirm to the user which branch was checked out.

$ARGUMENTS
