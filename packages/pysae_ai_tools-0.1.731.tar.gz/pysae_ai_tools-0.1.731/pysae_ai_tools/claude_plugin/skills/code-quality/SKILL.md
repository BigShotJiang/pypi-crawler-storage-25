---
name: code-quality
description: >
  Run full test suite, linters, and pre-commit hooks. Fix any failures with
  atomic commits. Use when the user says /code-quality, 'run tests and linters',
  'check quality', 'vérifie la qualité', or when delegated from other skills
  before MR creation or after review fixes.
argument-hint: "[optional: commit prefix for fixes, e.g. 'fix' or 'feat']"
allowed-tools:
  - Read
  - Edit
  - Write
  - Glob
  - Grep
  - Bash
---

Run a full code quality validation pass on the current branch: tests, linters, and pre-commit hooks. Fix any failures with atomic commits.

## Step 1 : Ensure correct working branch

If this skill was invoked **directly by the user** (not delegated from `/code-implement`, `/code-auto-pilot`, or `/code-review-fix`):

Invoke `/git-worktree` (without arguments) to ensure we are on the correct branch. The worktree skill handles all cases automatically: detecting MR source branches when on main, checking for IDE, asking the user if ambiguous.

If delegated from another skill, skip this step.

## Step 2 : Determine commit prefix

Determine `COMMIT_PREFIX` following the rules in [../references/commit-prefix-rules.md](../references/commit-prefix-rules.md).

## Step 3 : Run checks

1. **Read CLAUDE.md** (if it exists) to find project-specific test and lint commands
2. **Run the full test suite** (ALL tests, not only those related to current changes):
   - Use the test command from CLAUDE.md if available
   - Python: `pytest` / Node: `yarn test` / `npm test`
   - **Do NOT filter or select tests based on changed files** — always run the entire suite
   - Exception: if the user explicitly asks to run only impacted/related tests (e.g. "only impacted tests", "tests liés aux changements"), then identify affected test files from `git diff` and run only those
3. **Run linters**:
   - Use the lint command from CLAUDE.md if available
   - Python: `ruff check`, `ruff format --check`
   - Node: `yarn lint` / `npm run lint`
4. **Run pre-commit hooks** (if configured):
   - `pre-commit run --all-files`

## Step 4 : Fix failures

If any check fails:

1. Fix the problem in the code
2. Commit the fix:
   ```bash
   git add <specific_files>
   git commit -m "$(cat <<'EOF'
   ${COMMIT_PREFIX}: <short description of the fix>

   Co-Authored-By: Claude <noreply@anthropic.com>
   EOF
   )"
   ```
3. Re-run the failing check to confirm it passes
4. Repeat until all checks are green

**Safety limit**: max 3 fix attempts per check. If still failing after 3 attempts, stop and report the issue to the user.

## Step 5 : Report

Once all checks pass, report the status:
- Tests: PASS (with count if available)
- Linters: PASS
- Pre-commit: PASS (or skipped if not configured)

$ARGUMENTS
