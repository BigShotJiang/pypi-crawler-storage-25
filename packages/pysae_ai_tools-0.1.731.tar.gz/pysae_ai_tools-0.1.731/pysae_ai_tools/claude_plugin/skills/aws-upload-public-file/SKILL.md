---
name: aws-upload-public-file
description: >
  Upload a file to the pysae-public-files S3 bucket and return its public URL.
  Use when the user says /aws-upload-public-file, 'upload un fichier public',
  'dépose sur le bucket public', 'publie ce document', 'lien public pour ce fichier',
  'upload public', or wants to host a file publicly on the Pysae website.
argument-hint: "<file path> [--name CUSTOM_NAME]"
allowed-tools:
  - Bash
  - AskUserQuestion
---

Upload a file to the `pysae-public-files` S3 bucket and return the public URL.

**Prerequisite:** The AWS CLI must be installed and authenticated with access to the `pysae-public-files` bucket (`aws sts get-caller-identity`).

## Step 1 — Resolve the file

Parse `$ARGUMENTS` for the file path. Verify the file exists:

```bash
FILE_PATH="<path from arguments>"
ls -lh "$FILE_PATH"
```

If the file does not exist, inform the user and stop.

Extract the file name. If the user provides `--name`, use that as the S3 key. Otherwise, use the original file name.

## Step 2 — Check for existing file

Check if a file with the same name already exists:
```bash
aws s3 ls "s3://pysae-public-files/${S3_KEY}" --region eu-west-3 2>/dev/null
```
If it exists, warn the user and ask if they want to replace. Otherwise, proceed directly.

## Step 3 — Upload

```bash
aws s3 cp "$FILE_PATH" "s3://pysae-public-files/${S3_KEY}" --region eu-west-3
```

Verify the upload succeeded:
```bash
aws s3 ls "s3://pysae-public-files/${S3_KEY}" --region eu-west-3
```

## Step 4 — Return the public URL

Build the public URL. **URL-encode** spaces and special characters in the S3 key:

```bash
# URL-encode the S3 key (spaces → %20)
ENCODED_KEY=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${S3_KEY}'))")
PUBLIC_URL="https://pysae-public-files.s3.eu-west-3.amazonaws.com/${ENCODED_KEY}"
```

Present the result:

> Fichier uploadé. Lien public :
>
> `<PUBLIC_URL>`

## Rules

- **No confirmation needed** — upload directly without asking
- **Warn before overwriting** — if the key already exists, ask if the user wants to replace
- **Region** is always `eu-west-3` (Paris)
- **Bucket** is always `pysae-public-files`
- **URL format** : `https://pysae-public-files.s3.eu-west-3.amazonaws.com/<key>` — no CloudFront, no website endpoint
- **French** for communication, English for commands

$ARGUMENTS
