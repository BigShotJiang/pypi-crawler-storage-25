---
name: track-context
description: >
  Assign context (issue, epic, labels) to an existing activity tracker session
  retroactively. Use when the user says /track-context, 'contextualise cette session',
  'attribue ce ticket à la session', 'assigne l issue', 'cette session c était pour',
  'rattache cette session', or wants to associate a session with a GitLab issue/epic.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Attribue un contexte (issue, epic, projet, labels) à une session existante de l'activity tracker. Utile quand une session n'a pas de ticket associé (travail sur `main`, pas de MR).

## Step 1 — Identifier la session

Si l'utilisateur ne précise pas de session :

```bash
pysae-ai-tools tracker report | python3 -c "
import sys, json
d = json.load(sys.stdin)
for s in d.get('sessions', []):
    ctx = '(no issue)' if not s.get('issue_iid') else f\"#{s['issue_iid']} {s.get('issue_title','')}\"
    print(f\"{s['session_id'][:8]}  {s.get('start','?')[:16]}–{s.get('end','?')[11:16]}  {s.get('project_path','?')}  {ctx}\")
"
```

Proposer les sessions sans issue à l'utilisateur pour qu'il choisisse.

Si l'utilisateur dit « cette session » ou « la session en cours », utiliser le `session_id` de la conversation actuelle (disponible dans le payload du hook ou via `$SESSION_ID` si défini).

## Step 2 — Extraire les informations du message

Analyser le message de l'utilisateur pour extraire :
- **Issue** : numéro d'issue (ex : `#123`, `pysae/op#456`)
- **Epic** : numéro d'epic (ex : `epic #7`, `&7`)
- **Projet** : chemin du projet (ex : `pysae/op`)
- **Labels** : labels à ajouter

## Step 3 — Clarifier si nécessaire

| Condition | Question à poser |
|---|---|
| Ni issue, ni epic, ni projet identifié | « Quel ticket, epic ou projet veux-tu attribuer ? » |
| Numéro d'issue ambigu (pas de projet) | « Dans quel projet ? » |

## Step 4 — Résoudre le contexte GitLab

Si l'utilisateur a donné un numéro d'issue ou d'epic, résoudre le contexte complet via glab :

```bash
# Pour une issue
glab api "projects/<project_id>/issues/<iid>" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(json.dumps({
    'issue_iid': str(d['iid']),
    'issue_title': d['title'],
    'issue_url': d['web_url'],
    'issue_labels': d.get('labels', []),
    'project_path': d['references']['full'].rsplit('#', 1)[0],
    'project_id': str(d['project_id']),
}))"
```

```bash
# Pour une epic (group-level)
glab api "groups/<group_id>/epics/<iid>" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(json.dumps({
    'epic_iid': str(d['iid']),
    'epic_title': d['title'],
    'epic_url': d['web_url'],
}))"
```

## Step 5 — Enregistrer

```bash
pysae-ai-tools tracker context "<session_id>" \
  --project "..." \
  --project-id "..." \
  --project-url "..." \
  --issue "..." \
  --issue-title "..." \
  --issue-url "..." \
  --label "label1" --label "label2" \
  --epic "..." \
  --epic-title "..." \
  --epic-url "..." \
  --date "YYYY-MM-DD"  # seulement si la session n'est pas d'aujourd'hui
```

Omettre les flags dont la valeur est vide.

## Step 6 — Confirmer

Afficher un résumé clair :

> Contexte attribué : session `XXXXXXXX` → **#IID titre** (projet)
