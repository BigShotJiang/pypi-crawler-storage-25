---
name: track-dashboard
description: >
  Open the activity tracker dashboard in the browser. Use when the user says
  /track-dashboard, 'dashboard', 'ouvre le dashboard', 'tableau de bord',
  'activité', 'temps passé', 'time tracking', or wants to view their activity
  statistics and time breakdown.
allowed-tools:
  - Bash
---

Ouvre le dashboard d'activité dans le navigateur.

## Step 1 — Lancer le dashboard

```bash
pysae-ai-tools tracker dashboard
```

La commande démarre le serveur en arrière-plan (ou réutilise un serveur existant) et ouvre le navigateur automatiquement.

## Step 2 — Confirmer

Afficher l'URL retournée par la commande :

> Dashboard ouvert sur **URL**
