# Template — Version EXTERNE

Utilise exactement cette structure. Remplace les `{placeholders}` par les valeurs réelles.

La version externe est **transparente mais mesurée** : honnête sur ce qui s'est passé, sans exposer les détails d'implémentation internes.

```markdown
# [EXTERNE] {YYYY-DD-MM} - {Titre de l'incident}

**Sévérité** : {P1/P2/P3} — {description courte}

**Durée totale** : {durée} ({heure début} → {heure fin})

**Rédacteur** : {Prénom Nom}

**Date du rapport** : {date du rapport}

## Contexte

{Résumé factuel en 1-2 phrases, sans jargon technique interne.}

L'incident s'est déroulé en **{N} phases** :

1. **{Phase 1}** ({heures}) — {description accessible}
2. **{Phase 2}** ({heures}) — {description accessible}
3. **{Phase N}** ({heures}) — {description accessible}

## Chronologie

| Heure | Événement | Commentaires |
|-------|-----------|--------------|
| {HHhMM} | {événement} | {détails accessibles} |
| {HHhMM} | {événement} | {détails accessibles} |

## Causes racines

### {Titre cause} (cause déclenchante)

{Description accessible, pas de jargon interne.}

**Facteurs contributifs :**
- {facteur formulé sans exposer l'architecture interne}
- {facteur formulé sans exposer l'architecture interne}

### {Titre cause} (cause de la durée prolongée)

{Description accessible.}

**Facteurs contributifs :**
- {facteur}
- {facteur}

## Actions mises en place

- {Action 1 en langage accessible}
- {Action 2}
- {Action 3}

## Impact

| Dimension | Détail |
|-----------|--------|
| **Indisponibilité** | {durée} ({heures}) — {description orientée utilisateur} |
| **Dégradation** | {durée} ({heures}) — {description} |
| **Réseaux impactés** | {scope} |
| **Information voyageurs** | {impact sur l'IV} |
| **OP** | {impact sur l'OP} |
| **Perte de données** | Nos vérifications n'ont pas mis en évidence de perte de données significative. {détails sur le buffer/retransmission si pertinent.} |

## Enseignements appris

1. **{Titre}.** {Explication en langage accessible, orientée amélioration.}

2. **{Titre}.** {Explication.}

## Plan d'actions

| # | Action |
|---|--------|
| 1 | {action en langage accessible} |
| 2 | {action} |
| 3 | {action} |
```

## Règles de rédaction externe

### Vocabulaire interdit → remplacement

| Ne jamais écrire | Écrire à la place |
|------------------|-------------------|
| MongoDB, Atlas, PostgreSQL, Redis | "base de données" ou "infrastructure de base de données" |
| pods, replicas, containers | "services" ou "infrastructure" |
| NDP, nav-data-processor | "notre système de traitement des données de position" |
| KEDA, HPA, autoscaler | "dimensionnement automatique" ou "montée en charge automatique" |
| nginx, ingress | "infrastructure réseau" |
| WebSocket | "connexion" |
| Kubernetes, EKS, nodes | "infrastructure" |
| scale-up à 800 replicas | "renforcement de l'infrastructure" |
| fat finger, se tromper de ligne | "erreur de configuration" ou "erreur de manipulation" |
| environnement dev/prod, isolation | ne pas mentionner du tout |
| rate limiting, load shedding | "mécanismes de régulation du trafic" |
| jitter, throttle, backpressure | "reconnexion progressive" |
| commit, version, v5.3.14 | "mise à jour logicielle" |

### Formulations types pour les causes

- **Erreur humaine** : "une erreur de configuration lors d'une opération d'administration sur notre infrastructure de base de données"
- **Deux erreurs** : "l'erreur comportait deux volets, dont le second n'a été identifié qu'après correction du premier, prolongeant la durée de l'interruption"
- **Thundering herd** : "la reconnexion simultanée de l'ensemble des [nom produit] a provoqué un pic de charge nécessitant un renforcement manuel de notre infrastructure"
- **Garde-fous** : "les garde-fous en place étaient insuffisants pour prévenir ce type d'erreur"
- **Monitoring** : "des alertes automatiques supplémentaires sont mises en place pour réduire le délai de détection"

### Ce qui ne doit JAMAIS transparaître

- Que les environnements dev et prod n'étaient pas séparés
- Que le monitoring avait des angles morts
- Que les protections côté client n'étaient pas déployées
- Que l'autoscaler était sous-dimensionné
- Des chiffres d'infra internes (nombre de pods, connexions DB, pool sizes)
- Tout ce qui pourrait faire penser au client que l'infra n'est pas mature

### Tableau Impact

- Pas de lignes "Devices impactés" ni "Coût infra" (interne uniquement)
- Pas de colonne "Responsable" dans la chronologie
- Pas de colonnes "Owner" ni "Statut" dans le plan d'actions
