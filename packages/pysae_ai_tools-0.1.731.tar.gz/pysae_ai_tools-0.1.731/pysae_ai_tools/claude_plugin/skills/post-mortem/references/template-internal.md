# Template — Version INTERNE

Utilise exactement cette structure. Remplace les `{placeholders}` par les valeurs réelles.

```markdown
# [INTERNE UNIQUEMENT] {YYYY-DD-MM} - {Titre de l'incident}

**Sévérité** : {P1/P2/P3} — {description courte}

**Durée totale** : {durée} ({heure début} → {heure fin})

**Rédacteur** : {Prénom Nom}

**Date du rapport** : {date du rapport}

## Contexte

{Résumé exécutif en 2-3 phrases.}

L'incident s'est déroulé en **{N} phases** :

1. **{Phase 1}** ({heure début} → {heure fin}) — {description courte}
2. **{Phase 2}** ({heure début} → {heure fin}) — {description courte}
3. **{Phase N}** ({heure début} → {heure fin}) — {description courte}

## Chronologie

| Heure | Événement | Responsable | Commentaires |
|-------|-----------|-------------|--------------|
| {HHhMM} | {événement} | {Prénom N.} | {détails} |
| {HHhMM} | {événement} | {Prénom N.} | {détails} |

## Causes racines

### 1. {Titre cause} (cause déclenchante)

{Description de la cause.}

**Facteurs contributifs :**
- {facteur 1}
- {facteur 2}

### 2. {Titre cause} (cause de la durée prolongée)

{Description.}

**Facteurs contributifs :**
- {facteur 1}
- {facteur 2}

## Actions mises en place

- {Action immédiate 1}
- {Action immédiate 2}
- {Action immédiate 3}

## Impact

| Dimension | Détail |
|-----------|--------|
| **Indisponibilité totale** | {durée} ({heures}) — {description} |
| **Dégradation** | {durée} ({heures}) — {description} |
| **Réseaux impactés** | {scope} |
| **Devices impactés** | {nombre} |
| **Information voyageurs** | {description impact IV} |
| **OP** | {description impact OP} |
| **Perte de données** | {analyse prudente} |
| **Coût infra** | {description surcoûts} |

## Enseignements appris

1. **{Titre enseignement 1}.** {Explication détaillée avec contexte technique.}

2. **{Titre enseignement 2}.** {Explication.}

3. **{Titre enseignement N}.** {Explication.}

## Plan d'actions

| # | Action | Owner | Statut |
|---|--------|-------|--------|
| 1 | {action détaillée} | {Prénom N.} | À faire |
| 2 | {action détaillée} | {Prénom N.} | À faire |
```

## Notes sur le contenu interne

- Utiliser le jargon technique exact : MongoDB, pods, replicas, NDP, KEDA, nginx, etc.
- Inclure les métriques Datadog observées (req/s, CPU, nombre de replicas)
- Mentionner les commits, versions, tickets GitLab pertinents
- Détailler les calculs (ex: 1500 devices × 600 events = 900k events)
- Les enseignements doivent être incisifs et directs, pas corporate
- Le plan d'actions doit avoir des owners nommés et être classé par priorité (immédiat → court terme → moyen terme → long terme)
- Inclure les liens vers les dashboards Datadog, configs, code source en annexe si pertinent
