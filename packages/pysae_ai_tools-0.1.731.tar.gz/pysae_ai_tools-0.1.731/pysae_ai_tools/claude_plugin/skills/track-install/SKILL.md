---
name: track-install
description: >
  Install, verify, or uninstall the activity tracker hook that logs all actions
  (git, glab, file edits, skills, agents, reads) per session for daily reports.
  Use when the user says /track-install, 'install activity tracker',
  'track my activity', 'tracker d activité', 'désinstalle le tracker',
  'uninstall activity tracker', or needs activity tracking configured or removed.
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
  - AskUserQuestion
---

Install, verify, or uninstall the activity tracker hook that logs actions into `~/.claude/pysae-ai-tools/activity-log/{YYYY-MM-DD}.jsonl`. Un fichier JSONL par jour, les événements sont distingués par `session_id`. Permet de générer des rapports d'activité et un dashboard interactif.

**Si l'utilisateur demande une désinstallation**, passer directement au **Step 4 — Uninstall**.

## Step 1 — Check current state

```bash
pysae-ai-tools tracker setup status
```

| Résultat | Action |
|---|---|
| `HOOK: CONFIGURED` | Aller au Step 3 (vérification) |
| `HOOK: NOT CONFIGURED` | Aller au Step 2 |
| Commande introuvable | Dire à l'utilisateur de lancer `cd <ai-tools repo> && bash claude-code-config/install.sh` |

## Step 2 — Install

```bash
pysae-ai-tools tracker setup install
```

Résultats possibles :
- `HOOK: INSTALLED` — succès
- `HOOK: ALREADY CONFIGURED` — déjà en place

## Step 3 — Verify

Lancer un test rapide du hook :

```bash
echo '{"session_id":"test","cwd":"/tmp","tool_name":"Bash","tool_input":{"command":"git status"}}' | pysae-ai-tools tracker hook
TODAY=$(date +%Y-%m-%d)
cat ~/.claude/pysae-ai-tools/activity-log/${TODAY}.jsonl 2>/dev/null && echo "OK: hook works" || echo "ERROR: no log written"
rm -f ~/.claude/pysae-ai-tools/activity-log/${TODAY}.jsonl
```

Puis vérifier les commandes :

```bash
pysae-ai-tools tracker report
pysae-ai-tools tracker dashboard --help
```

Dire à l'utilisateur :

> Le tracker d'activité est configuré. Chaque session Claude Code enregistre automatiquement les actions (git, glab, fichiers édités, skills utilisés, agents, fichiers lus) dans `~/.claude/pysae-ai-tools/activity-log/`.
>
> Commandes disponibles :
> - Dashboard web interactif : `/track-dashboard`
> - Ajouter du temps manuellement : `/track-manual`

## Step 4 — Uninstall

Demander à l'utilisateur s'il veut aussi supprimer les données de logs.

Sans suppression des logs :
```bash
pysae-ai-tools tracker setup uninstall
```

Avec suppression des logs :
```bash
pysae-ai-tools tracker setup uninstall --delete-logs
```

Dire à l'utilisateur :

> Le tracker d'activité a été désinstallé. Le hook ne sera plus appelé après redémarrage de Claude Code.
