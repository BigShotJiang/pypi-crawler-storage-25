---
name: install-aws-cli
description: >
  Install, update, and verify the AWS CLI and configure SSO profiles.
  Use when the user says /install-aws-cli, 'install aws', 'setup aws',
  'configurer aws', or needs the AWS CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the AWS CLI v2, then configure SSO authentication.

## Step 1 — Check current state

```bash
pysae-ai-tools install aws-cli check
```

Returns JSON with `binary`, `latest` (from `aws/aws-cli` GitHub tags), `auth_ok`, `auth_message`, `profiles`, `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | `auth_ok` | Action |
|---|---|---|---|
| `true` | — | — | Step 2 (install) then Step 3 (SSO) |
| `false` | `true` | — | Step 2 (update) then verify auth |
| `false` | `false` | `false` | Step 3 (SSO login) |
| `false` | `false` | `true` | **Done** — tell the user everything is OK |

## Step 2 — Install or update the CLI

```bash
pysae-ai-tools install aws-cli install
```

The script picks the right installer per platform:
- **Linux** → `awscli-exe-linux-<arch>.zip` extracted, then `sudo ./aws/install --update` (or fresh install).
- **macOS** → `AWSCLIV2.pkg` (universal Intel + Apple Silicon) installed via `sudo installer`.
- **Windows** → `AWSCLIV2.msi` installed via `msiexec /i ... /qn /norestart` (silent, no UI).

> **Windows alternatives:** `winget install Amazon.AWSCLI` or `choco install awscli`.

## Step 3 — Configure SSO and authenticate

`aws configure sso` and `aws sso login` open a browser — they MUST be run interactively by the user (suggest `! <command>`), never via the Bash tool.

### First-time setup

> Configure ton profil AWS SSO :
>
> `! aws configure sso`

### Existing profile, expired session

> Ta session AWS SSO a expiré. Reconnecte-toi :
>
> `! aws sso login` (ou `! aws sso login --profile <profile-name>`)

Wait for the user to confirm before continuing.

## Step 4 — Final verification

```bash
pysae-ai-tools install aws-cli check
```

`auth_ok: true` confirms the session is active.

## Dépannage : access keys IAM

Si l'authentification SSO ne fonctionne pas (ou si l'utilisateur a besoin d'access keys pour CI/scripts locaux), les credentials sont stockés dans AWS Secrets Manager sous `/iam/<username>/access-key`.

```bash
IAM_USER=$(aws sts get-caller-identity --query 'Arn' --output text 2>/dev/null | grep -oP '(?<=/)[^/]+$')
echo "IAM user: ${IAM_USER}"
```

Si même `sts get-caller-identity` échoue, guider l'utilisateur :

> Tu n'as aucune session AWS active. Pour récupérer tes access keys :
> 1. Connecte-toi à la **console AWS**
> 2. Va dans **AWS Secrets Manager**, cherche `/iam/<ton-username>/access-key`
> 3. Récupère `access_key_id` et `secret_access_key`
> 4. `! aws configure` et renseigne-les

## Gotchas

- **AWS CLI v2 ≠ v1.** v2 is required (`aws --version` should show `aws-cli/2.x.y`). The script always installs v2.
- **Linux installer is multi-step.** The `awscli-exe-linux-*.zip` extracts to a `./aws/` directory containing an `install` script — not a binary. The script handles this; do NOT try to copy a binary directly.
- **macOS .pkg is universal.** No need to detect Intel vs Apple Silicon — the same `.pkg` works on both.
- **Windows MSI requires elevation.** `msiexec /qn` may prompt for UAC. The script does not bypass UAC by design.
- **SSO commands cannot be automated.** `aws configure sso` and `aws sso login` open a browser callback. Always suggest `! <cmd>` so the user runs them in their own session.
- **Prerequisite for kubectl.** kubectl uses `aws eks get-token` for EKS auth. When AWS SSO expires, every kubectl command fails too.

## Notes

- SSO sessions typically last 8–12h. Schedule `aws sso login` re-runs accordingly.
- The script reports `profiles` so other skills can verify which profile to use.

$ARGUMENTS
