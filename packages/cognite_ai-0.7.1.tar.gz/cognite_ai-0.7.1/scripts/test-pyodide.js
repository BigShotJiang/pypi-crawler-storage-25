// Description: This script is used to test the Python SDK installation in a Pyodide environment.
// We are using JupyterLite and stlite, both pyodide based Python runtimes. To ensure that the SDK works
// in these runtimes, we need to test the installation of the SDK in a Pyodide environment.
// This script will start an HTTP server to serve the SDK wheel file and then try to install the SDK in Python.
// If the installation is successful, it will run a simple Python script to test the SDK.
const { loadPyodide } = require("pyodide");

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

// The Cognite Python SDK wheel filename will be sent in as environment variable
const wheelFilePath = path.join(__dirname, '..', 'dist', process.env.PACKAGE_FILE_PATH);

// Create an HTTP server to serve the wheel file
const server = http.createServer((req, res) => {
  fs.readFile(wheelFilePath, (err, data) => {
    if (err) {
      // Handle file read errors
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('500 - Internal Server Error');
    } else {
      // Serve the file content
      res.writeHead(200, { 'Content-Type': 'application/octet-stream' });
      res.end(data);
    }
  });
});

// Start the server and listen on the defined port. Then try to install the SDK in Python
server.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}. Now trying to install and run cognite-ai.`);

  async function test_cognite_sdk() {
    let pyodide = await loadPyodide();
    await pyodide.loadPackage("micropip");
    const micropip = pyodide.pyimport("micropip");
    // Read packages to install from environment variable as JSON

    const packages = JSON.parse(process.env.PACKAGES);
    for (const pkg of packages) {
      await micropip.install(pkg);
    }
    await pyodide.runPythonAsync("from cognite.ai import load_pandasai");
    await pyodide.runPythonAsync("SmartDataframe, SmartDatalake, Agent = await load_pandasai()");

    return pyodide.runPythonAsync('"Pandas AI successfully loaded!"');
  }

  function shutdownServer() {
    return new Promise((resolve) => {
      server.close(() => resolve());
    });
  }

  test_cognite_sdk()
    .then(async (result) => {
      console.log("Response from Python =", result);
      await shutdownServer();
      process.exit(0);
    })
    .catch(async (err) => {
      // Pyodide PythonError stacks often embed the entire pyodide.asm.js as one line, which exceeds
      // GitHub Actions' per-line log limit and hides the real message. Log fields + truncated stack.
      console.error("=== Pyodide test failed ===");
      console.error("Name:   ", err?.name);
      console.error("Message:", err?.message);
      console.error("Type:   ", err?.type);
      console.error("Stack (first 4000 chars):");
      console.error(String(err?.stack || "").slice(0, 4000));
      await shutdownServer();
      process.exit(1);
    });
});
