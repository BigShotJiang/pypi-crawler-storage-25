import os

from cognite.client import ClientConfig, CogniteClient
from cognite.client.credentials import OAuthClientCredentials

from cognite.ai.data_analysis import Query, QueryWithId, fetch_instances_for_queries


def create_cognite_client_from_env() -> CogniteClient:
    base_url = os.environ["COGNITE_BASE_URL"]
    credentials = OAuthClientCredentials(
        token_url=f"https://login.microsoftonline.com/{os.environ['COGNITE_TENANT_ID']}/oauth2/v2.0/token",
        client_id=os.environ["COGNITE_CLIENT_ID"],
        client_secret=os.environ["COGNITE_CLIENT_SECRET"],
        scopes=[f"{base_url}/.default"],
    )

    return CogniteClient(
        config=ClientConfig(
            client_name="cognite-ai",
            project=os.environ["COGNITE_PROJECT"],
            base_url=base_url,
            credentials=credentials,
        )
    )


def main() -> None:
    client = create_cognite_client_from_env()

    sample_query: Query = {
        "dataModelView": {
            "space": "cdf_idm",
            "externalId": "CogniteProcessIndustries",
            "view": "CogniteNotification",
            "version": "v1",
        },
        "operation": "list",
        "properties": [
            "space",
            "externalId",
            "name",
            "aliases",
            "priority",
            "startTime",
        ],
        "filter": {
            "and": [
                {
                    "range": {
                        "property": ["cdf_idm", "CogniteNotification/v1", "startTime"],
                        "gte": "2024-01-01T00:00:00",
                    }
                }
            ]
        },
        "limit": 2000,
    }

    queries: list[QueryWithId] = [
        {
            "query_id": "notifications-sample",
            "query": sample_query,
        }
    ]
    df = fetch_instances_for_queries(client, queries, stringify_nested=True)[0]
    print(df)


if __name__ == "__main__":
    main()
