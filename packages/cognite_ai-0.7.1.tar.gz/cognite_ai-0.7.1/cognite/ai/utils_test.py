"""Tests for cognite.ai.utils module."""

import numpy as np
import pytest

from cognite.ai.utils import cos_sim


class TestCosSim:
    """Tests for cos_sim function."""

    @pytest.mark.unit
    def test_identical_vectors(self, sample_vectors):
        """Test cosine similarity of identical vectors equals 1."""
        v = sample_vectors["vector_identical"]
        result = cos_sim(v.reshape(1, -1), v.reshape(1, -1))
        assert np.isclose(result[0], 1.0), "Identical vectors should have similarity 1.0"
