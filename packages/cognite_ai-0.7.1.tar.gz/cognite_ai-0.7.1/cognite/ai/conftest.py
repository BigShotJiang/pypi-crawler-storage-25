"""Shared test fixtures for cognite.ai tests."""

import numpy as np
import pytest


@pytest.fixture
def sample_vectors():
    """Sample numpy arrays for testing cos_sim function."""
    return {
        "vector_a": np.array([1.0, 0.0, 0.0]),
        "vector_b": np.array([0.0, 1.0, 0.0]),
        "vector_c": np.array([1.0, 1.0, 0.0]),
        "vector_identical": np.array([1.0, 2.0, 3.0]),
        "vector_zero": np.array([0.0, 0.0, 0.0]),
        "matrix": np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 1.0, 0.0]]),
    }
