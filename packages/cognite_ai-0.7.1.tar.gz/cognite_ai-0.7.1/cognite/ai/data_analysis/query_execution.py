import json

import pandas as pd
from cognite.client import CogniteClient

from .types import Query, QueryResultItem, QueryWithId

PAGE_LIMIT = 100


def _stringify_nested_query_result_items(items: list[QueryResultItem]) -> list[QueryResultItem]:
    """Stringify list/dict field values on each item so PandasAI does not fail."""
    result: list[QueryResultItem] = []
    for item in items:
        sanitized_item: QueryResultItem = {}
        for key, value in item.items():
            if isinstance(value, (list, dict)):
                sanitized_item[key] = json.dumps(value)
            else:
                sanitized_item[key] = value
        result.append(sanitized_item)
    return result


def _execute_query(
    cognite_client: CogniteClient,
    query: Query,
) -> list[QueryResultItem]:
    url = f"/api/v1/projects/{cognite_client.config.project}/ai/tools/query/execute"
    limit = query.get("limit")

    result: list[QueryResultItem] = []
    cursor: str | None = None

    while True:
        body = {**query, "limit": PAGE_LIMIT}

        if cursor is not None:
            body["cursor"] = cursor

        response = cognite_client.post(url=url, json=body).json()
        items = response.get("items", [])
        result.extend(items)
        cursor = response.get("nextCursor")

        # If all the requested items have been fetched
        if limit is not None and len(result) >= limit:
            break

        # If there is no more items to fetch
        if not cursor or not items:
            break

    if limit is not None:
        return result[:limit]

    return result


def fetch_instances_for_queries(
    cognite_client: CogniteClient,
    queries: list[QueryWithId],
    stringify_nested: bool = False,
) -> list[pd.DataFrame]:
    """Execute queries and return one DataFrame per query.

    Args:
        cognite_client: The Cognite client to use.
        queries: The queries to execute.
        stringify_nested: If True, JSON-encode list/dict fields so cells are scalar strings.
            This is required for PandasAI.

    Returns:
        One DataFrame per query, in input order.
    """
    dataframes: list[pd.DataFrame] = []
    for query_with_id in queries:
        items = _execute_query(cognite_client, query_with_id["query"])
        if stringify_nested:
            items = _stringify_nested_query_result_items(items)
        dataframes.append(pd.DataFrame(items))
    return dataframes
