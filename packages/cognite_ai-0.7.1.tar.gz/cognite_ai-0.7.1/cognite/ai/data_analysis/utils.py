"""Utilities for time series data analysis and fetching."""

from __future__ import annotations

import math
from datetime import datetime


def calculate_granularity(start: datetime, end: datetime, num_points: int) -> str:
    """Calculate an appropriate granularity string for aggregation queries.

    The function mirrors the logic used in `cog-ai` and the TS implementation:
    - Compute the total range in seconds, divide by desired number of points, and round up
    - Express the bucket size using the smallest appropriate unit among seconds, minutes,
      hours and days, capping at 100 days

    Args:
        start: Start datetime (timezone-aware or naive, consistent with end)
        end: End datetime (timezone-aware or naive, consistent with start)
        num_points: Target number of buckets/points

    Returns:
        Granularity string like '5s', '10m', '2h', '3d', or '100d' for very long ranges

    Raises:
        ValueError: If start >= end or if num_points <= 0
    """
    if num_points <= 0:
        raise ValueError(f"num_points must be positive, got {num_points}")

    total_seconds = int((end - start).total_seconds())
    if total_seconds <= 0:
        raise ValueError(f"End time must be after start time (start={start}, end={end})")

    # Always at least 1 second
    seconds_per_bucket = max(1, math.ceil(total_seconds / num_points))

    minutes_per_bucket = math.ceil(seconds_per_bucket / 60)
    hours_per_bucket = math.ceil(minutes_per_bucket / 60)
    days_per_bucket = math.ceil(hours_per_bucket / 24)

    if seconds_per_bucket <= 60:
        return f"{seconds_per_bucket}s"
    if minutes_per_bucket <= 60:
        return f"{minutes_per_bucket}m"
    if hours_per_bucket <= 24:
        return f"{hours_per_bucket}h"
    if days_per_bucket <= 100:
        return f"{days_per_bucket}d"
    return "100d"
