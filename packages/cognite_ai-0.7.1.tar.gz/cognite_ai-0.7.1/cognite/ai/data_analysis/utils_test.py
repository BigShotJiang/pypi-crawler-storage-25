"""Tests for data analysis utilities."""

import datetime

import pytest

from .utils import calculate_granularity


@pytest.mark.parametrize(
    "start, end, num_points, expected_granularity",
    [
        # Test cases from cog-ai reference implementation
        # 2020-07-27 to 2025-12-04 (~5.4 years)
        (datetime.datetime.fromtimestamp(1595803251), datetime.datetime.fromtimestamp(1764807501), 1000, "2d"),
        # 2020-07-27 to 2023-04-01 (~2.7 years)
        (datetime.datetime.fromtimestamp(1595803251), datetime.datetime.fromtimestamp(1680305376), 1000, "24h"),
        # 2020-04-14 to 2021-10-01 (~1.5 years)
        (datetime.datetime.fromtimestamp(1586821790), datetime.datetime.fromtimestamp(1633102866), 1000, "13h"),
        # 2021-01-08 to 2021-01-15 (~7 days)
        (datetime.datetime.fromtimestamp(1610110088), datetime.datetime.fromtimestamp(1610675463), 1000, "10m"),
        # 2021-01-10 to 2021-01-13 (~2.5 days)
        (datetime.datetime.fromtimestamp(1610281928), datetime.datetime.fromtimestamp(1610499491), 1000, "4m"),
        # 2021-01-11 to 2021-01-11 (~4 minutes)
        (datetime.datetime.fromtimestamp(1610395159), datetime.datetime.fromtimestamp(1610395396), 1000, "1s"),
        # Test for counting use case (10 buckets)
        (datetime.datetime(2024, 1, 1), datetime.datetime(2024, 1, 2), 10, "3h"),
        # Edge cases
        (
            datetime.datetime(2024, 1, 1, 12, 0, 0),
            datetime.datetime(2024, 1, 1, 12, 0, 30),
            10,
            "3s",
        ),  # Very short range
        (datetime.datetime(2020, 1, 1), datetime.datetime(2025, 1, 1), 10, "100d"),  # Very long range (cap at 100d)
    ],
)
def test_calculate_granularity(
    start: datetime.datetime, end: datetime.datetime, num_points: int, expected_granularity: str
):
    """Test granularity calculation matches cog-ai reference implementation."""
    calculated_granularity = calculate_granularity(start, end, num_points)
    assert calculated_granularity == expected_granularity


def test_calculate_granularity_invalid_num_points():
    """Test that zero or negative num_points raises ValueError."""
    with pytest.raises(ValueError, match="num_points must be positive"):
        calculate_granularity(datetime.datetime(2024, 1, 1), datetime.datetime(2024, 1, 2), 0)

    with pytest.raises(ValueError, match="num_points must be positive"):
        calculate_granularity(datetime.datetime(2024, 1, 1), datetime.datetime(2024, 1, 2), -10)


def test_calculate_granularity_start_equals_end():
    """Test that start == end raises ValueError."""
    with pytest.raises(ValueError, match="End time must be after start time"):
        calculate_granularity(datetime.datetime(2024, 1, 1, 12, 0, 0), datetime.datetime(2024, 1, 1, 12, 0, 0), 1000)


def test_calculate_granularity_start_after_end():
    """Test that start > end raises ValueError."""
    with pytest.raises(ValueError, match="End time must be after start time"):
        calculate_granularity(datetime.datetime(2024, 1, 2), datetime.datetime(2024, 1, 1), 1000)
