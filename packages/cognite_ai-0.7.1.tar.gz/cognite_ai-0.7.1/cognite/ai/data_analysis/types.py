"""Type definitions for data analysis results."""

from typing import Any, Literal, TypeAlias

from typing_extensions import TypedDict


class DataModelView(TypedDict):
    space: str
    externalId: str
    view: str
    version: str


class Query(TypedDict, total=False):
    dataModelView: DataModelView
    operation: str
    properties: list[str | dict[str, list[str]]] | dict[str, list[str]]
    filter: dict[str, Any] | None
    search: dict[str, Any] | None
    aggregate: dict[str, Any] | None
    sort: list[dict[str, Any]] | None
    limit: int | None


class QueryWithId(TypedDict):
    query_id: str
    query: Query


QueryResultItem: TypeAlias = dict[str, Any]


class AnalysisStringResult(TypedDict):
    """Result containing a string response."""

    type: Literal["string"]
    response: str
    data: str | None
    code: str | None


class AnalysisNumberResult(TypedDict):
    """Result containing a numeric response."""

    type: Literal["number"]
    response: str
    data: float
    code: str | None


class AnalysisDataFrameResult(TypedDict):
    """Result containing a DataFrame in CSV format."""

    type: Literal["dataframe"]
    response: str
    data: str  # CSV format
    code: str | None


class AnalysisPlotResult(TypedDict):
    """Result containing a plot as base64 encoded image."""

    type: Literal["plot"]
    response: str
    data: str  # Base64 encoded image
    code: str | None


class AnalysisErrorResult(TypedDict):
    """Result containing an error message."""

    type: Literal["error"]
    response: str
    data: str
    code: str | None


AnalysisResult = (
    AnalysisStringResult | AnalysisNumberResult | AnalysisDataFrameResult | AnalysisPlotResult | AnalysisErrorResult
)
