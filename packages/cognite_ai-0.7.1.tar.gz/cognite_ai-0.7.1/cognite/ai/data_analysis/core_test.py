"""Tests for core data analysis functionality.

Note: These tests focus on input validation and basic flow.
The result handling logic is comprehensively tested in result_handler_test.py.
Full end-to-end testing with actual LLM calls will be done in integration tests.
"""

from unittest.mock import MagicMock

import pandas as pd
import pytest

from .core import analyze_data


@pytest.fixture
def sample_dataframe():
    """Create a sample DataFrame for testing."""
    return pd.DataFrame(
        {
            "temperature": [20.5, 21.0, 19.8, 22.1, 20.3],
            "pressure": [1013, 1015, 1012, 1016, 1014],
            "humidity": [65, 68, 70, 62, 66],
        }
    )


@pytest.fixture
def mock_cognite_client():
    """Create a mock CogniteClient."""
    return MagicMock()


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_empty_dataframe(mock_cognite_client):
    """Test error handling for empty dataframe."""
    with pytest.raises(ValueError, match="dataframe is empty"):
        await analyze_data(dataframe=pd.DataFrame(), prompt="What is the average?", cognite_client=mock_cognite_client)


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_none_dataframe(mock_cognite_client):
    """Test error handling for None dataframe."""
    with pytest.raises(ValueError, match="dataframe is None"):
        await analyze_data(
            dataframe=None,  # type: ignore
            prompt="What is the average?",
            cognite_client=mock_cognite_client,
        )


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_calls_dependencies(sample_dataframe, mock_cognite_client):
    """Test that analyze_data properly calls SmartDataframe and handle_analysis_result."""
    # Mock the SmartDataframe instance
    mock_sdf_instance = MagicMock()
    mock_sdf_instance.chat.return_value = "The average is 42"
    mock_sdf_instance.last_code_executed = "df.mean()"

    # Mock the SmartDataframe class
    mock_smartdf_class = MagicMock(return_value=mock_sdf_instance)

    # Mock handle_analysis_result
    mock_handler = MagicMock()
    mock_result = {
        "type": "string",
        "response": "The average is 42",
        "data": "The average is 42",
        "code": "df.mean()",
    }
    mock_handler.return_value = mock_result

    # Call analyze_data with injected dependencies
    result = await analyze_data(
        dataframe=sample_dataframe,
        prompt="What is the average?",
        cognite_client=mock_cognite_client,
        model="azure/gpt-4o",
        max_tokens=4000,
        temperature=0.5,
        verbose=True,
        smartdataframe_class=mock_smartdf_class,
        result_handler=mock_handler,
    )

    # 1. Verify SmartDataframe was initialized with correct parameters
    call_kwargs = mock_smartdf_class.call_args[1]
    assert call_kwargs["cognite_client"] == mock_cognite_client
    assert call_kwargs["params"]["model"] == "azure/gpt-4o"
    assert call_kwargs["params"]["maxTokens"] == 4000
    assert call_kwargs["params"]["temperature"] == 0.5
    assert call_kwargs["config"]["verbose"] is True
    # Verify DataFrame was passed
    pd.testing.assert_frame_equal(call_kwargs["df"], sample_dataframe)

    # 2. Verify sdf.chat was called with the prompt
    mock_sdf_instance.chat.assert_called_once_with("What is the average?")

    # 3. Verify handle_analysis_result was called with correct arguments
    mock_handler.assert_called_once_with("The average is 42", code="df.mean()")

    # 4. Verify the result is what handle_analysis_result returned
    assert result == mock_result


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_retries_on_no_code(sample_dataframe, mock_cognite_client):
    """Test that analyze_data retries when code generation fails (last_code_executed is None)."""
    mock_sdf_instance = MagicMock()
    mock_sdf_instance.last_code_executed = None

    # First chat call: fails (last_code_executed stays None)
    # Second chat call: succeeds (sets last_code_executed)
    def chat_side_effect(prompt):
        if mock_sdf_instance.chat.call_count == 1:
            return "Unfortunately, I was not able to answer your question..."
        mock_sdf_instance.last_code_executed = "df.mean()"
        return "The average is 42"

    mock_sdf_instance.chat.side_effect = chat_side_effect

    mock_smartdf_class = MagicMock(return_value=mock_sdf_instance)

    mock_handler = MagicMock()
    mock_result = {"type": "string", "response": "The average is 42", "data": "The average is 42", "code": "df.mean()"}
    mock_handler.return_value = mock_result

    result = await analyze_data(
        dataframe=sample_dataframe,
        prompt="What is the average?",
        cognite_client=mock_cognite_client,
        smartdataframe_class=mock_smartdf_class,
        result_handler=mock_handler,
        max_retries=1,
    )

    # Same SmartDataframe instance reused, chat called twice
    mock_smartdf_class.assert_called_once()
    assert mock_sdf_instance.chat.call_count == 2
    mock_handler.assert_called_once_with("The average is 42", code="df.mean()")
    assert result == mock_result


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_returns_error_after_retries_exhausted(sample_dataframe, mock_cognite_client):
    """Test that analyze_data returns an error result when all retries fail."""
    mock_sdf_instance = MagicMock()
    mock_sdf_instance.chat.return_value = "Unfortunately, I was not able to answer..."
    mock_sdf_instance.last_code_executed = None

    mock_smartdf_class = MagicMock(return_value=mock_sdf_instance)
    mock_handler = MagicMock()

    result = await analyze_data(
        dataframe=sample_dataframe,
        prompt="What is the average?",
        cognite_client=mock_cognite_client,
        smartdataframe_class=mock_smartdf_class,
        result_handler=mock_handler,
        max_retries=2,
    )

    assert mock_sdf_instance.chat.call_count == 3
    mock_handler.assert_not_called()
    assert result["type"] == "error"
    assert result["code"] is None
    assert "Unfortunately" in result["data"]


@pytest.mark.unit
@pytest.mark.asyncio
async def test_analyze_data_no_retry_when_max_retries_zero(sample_dataframe, mock_cognite_client):
    """Test that max_retries=0 disables retry and returns error immediately."""
    mock_sdf_instance = MagicMock()
    mock_sdf_instance.chat.return_value = "Unfortunately, I was not able to answer..."
    mock_sdf_instance.last_code_executed = None

    mock_smartdf_class = MagicMock(return_value=mock_sdf_instance)
    mock_handler = MagicMock()

    result = await analyze_data(
        dataframe=sample_dataframe,
        prompt="What is the average?",
        cognite_client=mock_cognite_client,
        smartdataframe_class=mock_smartdf_class,
        result_handler=mock_handler,
        max_retries=0,
    )

    mock_sdf_instance.chat.assert_called_once()
    mock_handler.assert_not_called()
    assert result["type"] == "error"
