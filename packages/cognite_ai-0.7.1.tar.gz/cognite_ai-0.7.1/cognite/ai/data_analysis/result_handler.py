"""Result handling and formatting for data analysis."""

import base64
from typing import Any

import numpy as np
import pandas as pd

from .types import (
    AnalysisErrorResult,
    AnalysisResult,
)


def _convert_plot_to_base64(plot_path: str) -> str:
    """
    Convert a plot image file to base64 encoded string.

    Args:
        plot_path: Path to the plot image file

    Returns:
        Base64 encoded string of the image
    """
    with open(plot_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
    return f"data:image/png;base64,{encoded_string}"


def _handle_error(error: Exception) -> AnalysisErrorResult:
    """
    Convert an exception to an error result.

    Args:
        error: The exception to convert

    Returns:
        AnalysisErrorResult with error details
    """
    return {
        "type": "error",
        "response": f"Error during analysis: {str(error)}",
        "data": str(error),
        "code": None,
    }


def handle_analysis_result(result: Any, code: str | None = None) -> AnalysisResult:
    """
    Process pandas-ai result and format it according to AnalysisResult types.

    Handles:
    - String results: direct text responses
    - Number results: numeric calculations (convert to float for numpy compatibility)
    - DataFrame results: convert to CSV format
    - Plot results: convert matplotlib figure to base64 PNG
    - Error results: handle exceptions and error messages

    Args:
        result: The raw result from pandas-ai
        code: The generated code (optional)

    Returns:
        Formatted AnalysisResult
    """
    try:
        # Handle pandas DataFrame
        if isinstance(result, pd.DataFrame):
            return {
                "type": "dataframe",
                "response": f"Generated a dataframe with {len(result)} rows and {len(result.columns)} columns",
                "data": result.to_csv(index=False),
                "code": code,
            }

        # Handle numeric types (including numpy types, but exclude bool since bool is subclass of int)
        if isinstance(result, bool):
            # Handle bool separately before int check (since bool is subclass of int)
            return {
                "type": "string",
                "response": str(result),
                "data": str(result),
                "code": code,
            }

        if isinstance(result, (int, float)):
            # Handle Python int and float
            return {
                "type": "number",
                "response": str(float(result)),
                "data": float(result),
                "code": code,
            }

        # Handle numpy scalar types
        if isinstance(result, (np.integer, np.floating)):
            numeric_value = float(result.item())
            return {
                "type": "number",
                "response": str(numeric_value),
                "data": numeric_value,
                "code": code,
            }

        # Handle complex numbers separately (convert to string representation)
        if isinstance(result, np.complexfloating):
            complex_value = result.item()
            return {
                "type": "string",
                "response": str(complex_value),
                "data": str(complex_value),
                "code": code,
            }

        # Handle string results
        if isinstance(result, str):
            # Check if it's a plot file path (ends with .png, .jpg, etc.)
            if result.endswith((".png", ".jpg", ".jpeg", ".svg")):
                try:
                    base64_image = _convert_plot_to_base64(result)
                    return {
                        "type": "plot",
                        "response": "Generated a plot",
                        "data": base64_image,
                        "code": code,
                    }
                except (FileNotFoundError, OSError):
                    # If plot conversion fails, treat as string
                    pass

            return {
                "type": "string",
                "response": result,
                "data": result,
                "code": code,
            }

        # Handle None or other types as string
        if result is None:
            return {
                "type": "string",
                "response": "No result",
                "data": None,
                "code": code,
            }

        # Default: convert to string
        return {
            "type": "string",
            "response": str(result),
            "data": str(result),
            "code": code,
        }

    except Exception as e:
        return _handle_error(e)
