"""Tests for result handling and formatting."""

from unittest.mock import mock_open, patch

import numpy as np
import pandas as pd

from .result_handler import (
    _handle_error,
    handle_analysis_result,
)


def test_handle_error():
    """Test error result formatting."""
    error = ValueError("Test error message")
    result = _handle_error(error)

    assert result["type"] == "error"
    assert "Test error message" in result["response"]
    assert result["data"] == "Test error message"
    assert result["code"] is None


def test_handle_string_result():
    """Test handling string result from pandas-ai."""
    result = handle_analysis_result("The answer is 42", code="df.mean()")

    assert result["type"] == "string"
    assert result["response"] == "The answer is 42"
    assert result["data"] == "The answer is 42"
    assert result["code"] == "df.mean()"


def test_handle_number_result():
    """Test handling number result (Python float)."""
    result = handle_analysis_result(42.5, code="df['col'].mean()")

    assert result["type"] == "number"
    assert result["response"] == "42.5"
    assert result["data"] == 42.5
    assert result["code"] == "df['col'].mean()"


def test_handle_number_result_int():
    """Test handling number result (Python int)."""
    result = handle_analysis_result(42, code="len(df)")

    assert result["type"] == "number"
    assert result["response"] == "42.0"
    assert result["data"] == 42.0
    assert result["code"] == "len(df)"


def test_handle_number_result_numpy():
    """Test handling number result (numpy types)."""
    # Test numpy float
    result = handle_analysis_result(np.float64(42.5), code="df.mean()")

    assert result["type"] == "number"
    assert result["data"] == 42.5
    assert isinstance(result["data"], float)

    # Test numpy int
    result = handle_analysis_result(np.int64(42), code="df.sum()")

    assert result["type"] == "number"
    assert result["data"] == 42.0
    assert isinstance(result["data"], float)


def test_handle_complex_result():
    """Test handling numpy complex number result."""
    result = handle_analysis_result(np.complex128(3 + 4j), code="df.fft()")

    assert result["type"] == "string"
    assert result["response"] == "(3+4j)"
    assert result["data"] == "(3+4j)"
    assert result["code"] == "df.fft()"


def test_handle_dataframe_result():
    """Test handling dataframe result and CSV conversion."""
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    result = handle_analysis_result(df, code="df.head()")

    assert result["type"] == "dataframe"
    assert "2 rows and 2 columns" in result["response"]
    assert "a,b" in result["data"]
    assert "1,3" in result["data"]
    assert result["code"] == "df.head()"


def test_handle_none_result():
    """Test handling None result."""
    result = handle_analysis_result(None, code="df.dropna(inplace=True)")

    assert result["type"] == "string"
    assert result["response"] == "No result"
    assert result["data"] is None
    assert result["code"] == "df.dropna(inplace=True)"


def test_handle_result_without_code():
    """Test handling result without generated code."""
    result = handle_analysis_result("Success")

    assert result["type"] == "string"
    assert result["response"] == "Success"
    assert result["code"] is None


def test_handle_list_result():
    """Test handling list result (converted to string)."""
    result = handle_analysis_result([1, 2, 3], code="df['col'].tolist()")

    assert result["type"] == "string"
    assert result["response"] == "[1, 2, 3]"
    assert result["data"] == "[1, 2, 3]"


def test_handle_dict_result():
    """Test handling dict result (converted to string)."""
    result = handle_analysis_result({"key": "value"}, code="df.to_dict()")

    assert result["type"] == "string"
    assert "key" in result["response"]
    assert "value" in result["response"]


def test_handle_bool_result():
    """Test handling boolean result (converted to string)."""
    result = handle_analysis_result(True, code="df['col'].all()")

    assert result["type"] == "string"
    assert result["response"] == "True"
    assert result["data"] == "True"


def test_handle_plot_result_success():
    """Test handling plot file path with successful base64 conversion."""
    # Mock file reading for plot conversion
    # Create fake PNG header bytes
    mock_image_data = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"

    with patch("builtins.open", mock_open(read_data=mock_image_data)):
        result = handle_analysis_result("/tmp/plot.png", code="df.plot()")

    assert result["type"] == "plot"
    assert result["response"] == "Generated a plot"
    assert result["data"].startswith("data:image/png;base64,")
    assert result["code"] == "df.plot()"


def test_handle_plot_result_file_not_found():
    """Test that missing plot files fall back to string type."""
    result = handle_analysis_result("/nonexistent/plot.png", code="df.plot()")

    assert result["type"] == "string"
    assert result["response"] == "/nonexistent/plot.png"
    assert result["data"] == "/nonexistent/plot.png"


def test_handle_plot_result_os_error():
    """Test that OS errors during plot conversion fall back to string type."""
    with patch("builtins.open", side_effect=OSError("Permission denied")):
        result = handle_analysis_result("/tmp/plot.jpg", code="df.plot()")

    assert result["type"] == "string"
    assert result["response"] == "/tmp/plot.jpg"
    assert result["data"] == "/tmp/plot.jpg"
