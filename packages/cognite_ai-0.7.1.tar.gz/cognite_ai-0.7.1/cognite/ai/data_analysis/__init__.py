"""Data analysis module for pandas-based analysis using natural language queries."""

from .core import analyze_data
from .query_execution import fetch_instances_for_queries
from .types import (
    AnalysisDataFrameResult,
    AnalysisErrorResult,
    AnalysisNumberResult,
    AnalysisPlotResult,
    AnalysisResult,
    AnalysisStringResult,
    Query,
    QueryWithId,
)

__all__ = [
    "analyze_data",
    "fetch_instances_for_queries",
    "QueryWithId",
    "Query",
    "AnalysisResult",
    "AnalysisStringResult",
    "AnalysisNumberResult",
    "AnalysisDataFrameResult",
    "AnalysisPlotResult",
    "AnalysisErrorResult",
]
