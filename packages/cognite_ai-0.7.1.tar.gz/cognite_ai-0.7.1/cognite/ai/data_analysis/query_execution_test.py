from unittest.mock import MagicMock

import pandas as pd
import pytest

from .query_execution import (
    PAGE_LIMIT,
    _execute_query,
    _stringify_nested_query_result_items,
    fetch_instances_for_queries,
)
from .types import Query, QueryWithId

SAMPLE_MAINTENANCE_ORDER_QUERY: Query = {
    "dataModelView": {
        "space": "cdf_idm",
        "externalId": "CogniteProcessIndustries",
        "view": "CogniteMaintenanceOrder",
        "version": "v1",
    },
    "operation": "list",
    "properties": [
        "space",
        "externalId",
        "name",
        "priority",
        "startTime",
        "endTime",
    ],
    "filter": {
        "and": [
            {
                "range": {
                    "property": ["cdf_idm", "CogniteMaintenanceOrder/v1", "startTime"],
                    "gte": "2024-01-01T00:00:00",
                }
            }
        ]
    },
    "limit": 5000,
}


def _post_response(payload: dict) -> MagicMock:
    resp = MagicMock()
    resp.json.return_value = payload
    return resp


@pytest.fixture
def mock_cognite_client():
    client = MagicMock()
    client.config.project = "test-project"
    return client


def test_execute_query_pagination_with_cursor(mock_cognite_client):
    mock_cognite_client.post.side_effect = [
        _post_response({"items": [{"name": "a1"}, {"name": "a2"}], "nextCursor": "cursor-1"}),
        _post_response({"items": [{"name": "a3"}], "nextCursor": None}),
    ]

    items = _execute_query(mock_cognite_client, SAMPLE_MAINTENANCE_ORDER_QUERY)

    # Assert that all items have been added to the result
    assert items == [{"name": "a1"}, {"name": "a2"}, {"name": "a3"}]

    # First call args should not have a cursor
    first_call = mock_cognite_client.post.call_args_list[0]
    assert first_call.kwargs["json"] == {**SAMPLE_MAINTENANCE_ORDER_QUERY, "limit": PAGE_LIMIT}

    # Second call args should have a cursor from the first call response
    second_call = mock_cognite_client.post.call_args_list[1]
    assert second_call.kwargs["json"] == {**SAMPLE_MAINTENANCE_ORDER_QUERY, "limit": PAGE_LIMIT, "cursor": "cursor-1"}


def test_execute_query_truncates_limit(mock_cognite_client):
    # Mock the API to return 2 pages of 2 items each
    mock_cognite_client.post.side_effect = [
        _post_response({"items": [{"name": "a1"}, {"name": "a2"}], "nextCursor": "c1"}),
        _post_response({"items": [{"name": "a3"}, {"name": "a4"}], "nextCursor": None}),
    ]

    # Limit the query to 3 items
    query: Query = {**SAMPLE_MAINTENANCE_ORDER_QUERY, "limit": 3}

    # Execute the query
    items = _execute_query(mock_cognite_client, query)

    # Assert that only the first 3 items have been added to the result
    assert items == [{"name": "a1"}, {"name": "a2"}, {"name": "a3"}]


def test_fetch_instances_for_queries(mock_cognite_client):
    first_query_result = [
        {"name": "mo-1", "description": "Pump overhaul", "tags": ["a", "b"], "metadata": {"source": "sap"}},
    ]
    second_query_result = [
        {"name": "mo-2", "startTime": "2020-01-01", "labels": ["x"], "metadata": {"kind": "corrective"}},
    ]

    # One HTTP response per query (single page each)
    mock_cognite_client.post.side_effect = [
        _post_response({"items": first_query_result, "nextCursor": None}),
        _post_response({"items": second_query_result, "nextCursor": None}),
    ]

    queries: list[QueryWithId] = [
        {"query_id": "q1", "query": SAMPLE_MAINTENANCE_ORDER_QUERY},
        {"query_id": "q2", "query": SAMPLE_MAINTENANCE_ORDER_QUERY},
    ]
    result = fetch_instances_for_queries(mock_cognite_client, queries)

    expected = [pd.DataFrame(first_query_result), pd.DataFrame(second_query_result)]
    for got, want in zip(result, expected, strict=True):
        pd.testing.assert_frame_equal(got, want)


def test_stringify_nested_query_result_items():
    rows = [
        {"name": "asset-1", "value": 42, "tags": ["safety", "urgent"], "metadata": {"key": "val"}},
        {"name": "asset-2", "value": 7, "tags": ["info"], "metadata": None},
    ]

    result = pd.DataFrame(_stringify_nested_query_result_items(rows))

    expected = pd.DataFrame(
        {
            "name": ["asset-1", "asset-2"],
            "value": [42, 7],
            "tags": ['["safety", "urgent"]', '["info"]'],
            "metadata": ['{"key": "val"}', None],
        }
    )
    pd.testing.assert_frame_equal(result, expected)


def test_fetch_instances_for_queries_stringify_nested(mock_cognite_client):
    first_query_result = [
        {"name": "mo-1", "tags": ["a", "b"], "metadata": {"source": "sap"}},
    ]
    mock_cognite_client.post.side_effect = [
        _post_response({"items": first_query_result, "nextCursor": None}),
    ]
    queries: list[QueryWithId] = [{"query_id": "q1", "query": SAMPLE_MAINTENANCE_ORDER_QUERY}]
    result = fetch_instances_for_queries(mock_cognite_client, queries, stringify_nested=True)
    expected = pd.DataFrame(_stringify_nested_query_result_items(first_query_result))
    pd.testing.assert_frame_equal(result[0], expected)
