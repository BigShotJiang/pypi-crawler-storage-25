"""Core data analysis functionality using pandas-ai."""

from collections.abc import Callable

import pandas as pd
from cognite.client import CogniteClient

from cognite.ai import load_pandasai

from .result_handler import handle_analysis_result
from .types import AnalysisErrorResult, AnalysisResult


async def analyze_data(
    dataframe: pd.DataFrame,
    prompt: str,
    cognite_client: CogniteClient,
    model: str = "azure/gpt-4.1",
    max_tokens: int = 8000,
    temperature: float = 0.0,
    verbose: bool = False,
    max_retries: int = 1,
    # Note: Cannot use SmartDataframe type directly because:
    # 1. Type must be loaded dynamically via load_pandasai() for pyodide compatibility
    # 2. Need Optional for dependency injection in tests
    smartdataframe_class: type | None = None,
    result_handler: Callable[..., AnalysisResult] = handle_analysis_result,
) -> AnalysisResult:
    """
    Analyze a pandas DataFrame using natural language queries via pandas-ai.

    Args:
        dataframe: The pandas DataFrame to analyze
        prompt: Natural language query/instruction
        cognite_client: CogniteClient instance for LLM access
        model: Language model to use (default: "azure/gpt-4.1")
        max_tokens: Maximum tokens for LLM response
        temperature: LLM temperature (0.0 = deterministic)
        verbose: Enable verbose pandas-ai logging
        max_retries: Number of retry attempts when code generation fails (default: 1)
        smartdataframe_class: SmartDataframe class to use (for testing). If None, loads from pandasai
        result_handler: Callable to format the chat result into an AnalysisResult

    Returns:
        AnalysisResult with type, data, response, and generated code

    Raises:
        ValueError: If dataframe is empty or invalid
        RuntimeError: If pandas-ai initialization fails
    """
    if dataframe is None:
        raise ValueError("dataframe is None")
    if dataframe.empty:
        raise ValueError("dataframe is empty")

    try:
        if smartdataframe_class is None:
            SmartDataframe, _, _ = await load_pandasai()
        else:
            SmartDataframe = smartdataframe_class

        llm_params = {
            "model": model,
            "maxTokens": max_tokens,
            "temperature": temperature,
        }

        # Prepare config (enable_cache is already set to False in SmartDataframe)
        config = {
            "verbose": verbose,
        }

        sdf = SmartDataframe(
            df=dataframe,
            cognite_client=cognite_client,
            params=llm_params,
            config=config,
        )

        # Pandasai does not retry NoCodeFoundError internally — it catches the exception and returns an error string.
        # We detect this via last_code_executed being None (only set when code actually runs).
        # Reusing the same SmartDataframe instance is safe and avoids re-initialization overhead.
        code: str | None = None
        result = None
        retries = 0
        while code is None and retries <= max_retries:
            result = sdf.chat(prompt)
            code = sdf.last_code_executed if hasattr(sdf, "last_code_executed") else None
            retries += 1

        if code is None:
            return AnalysisErrorResult(
                type="error",
                response="Failed to generate executable code for this analysis.",
                data=str(result),
                code=None,
            )

        return result_handler(result, code=code)

    except ValueError:
        raise
    except Exception as e:
        raise RuntimeError(f"Failed to analyze data: {str(e)}") from e
