import os
import site
import sys
from collections.abc import Sequence

import pandas as pd
from cognite.client import CogniteClient

is_patched = False
_RUNNING_IN_BROWSER = sys.platform == "emscripten" and "pyodide" in sys.modules


async def patch_pandasai():
    import micropip  # type: ignore[import-not-found]

    class MockOpenAI:
        def __getattr__(self, attr):
            return "If you need openai package, restart notebook"

    sys.modules["openai"] = MockOpenAI()  # type: ignore[assignment]
    await micropip.install(["pydantic", "jinja2", "pyyaml", "duckdb", "sqlglot", "sqlalchemy", "astor"])
    await micropip.install("pandasai==2.3.0", deps=False)

    site_packages_dir = site.getsitepackages()[0]

    def patch_dot_env():
        # dotenv is not available in pyodide.
        # we therefor just mock the _load_dotenv function
        # and skip the import of dotenv in env.py, line 1
        env_py_path = os.path.join(site_packages_dir, "pandasai", "helpers", "env.py")

        with open(env_py_path) as f:
            lines = f.readlines()
        skip_lines = [2]  # Skip import of dotenv
        with open(env_py_path, "w") as f:
            f.write("def _load_dotenv(dotenv_path):\n    pass\n\n")
            for i in range(0, len(lines)):
                if i not in skip_lines:
                    f.write(lines[i])

    patch_dot_env()


async def load_pandasai():
    # TODO: This is a series of hacks to make pandasai work in JupyterLite
    # Multiple of these hacks are workarounds for aiohttp 3.6.2 does not work
    # with Python 3.11, and later packages don't exist as pure python wheels.
    # However, we are not using them, this is only happening because openai is not
    # an optional package, and we are providing our own LLM into this mix.
    # In addition, we are using a wip duckdb implementation which can be fully
    # mocked as long as we don't use caching.
    import os

    os.environ["SCARF_NO_ANALYTICS"] = "true"
    global is_patched
    if not is_patched and _RUNNING_IN_BROWSER:
        await patch_pandasai()

    from pandasai import Agent as PandasAgent
    from pandasai import SmartDataframe as SDF
    from pandasai import SmartDatalake as SDL
    from pandasai.llm import LLM
    from pandasai.schemas.df_config import Config

    class CogniteLLM(LLM):
        cognite_client: CogniteClient
        temperature = 0.0
        model = "azure/gpt-4.1"
        max_tokens = 1000
        stop: list[str] | None = None

        def __init__(self, cognite_client, params):
            LLM.__init__(self)
            self.validate_params(params)

            self.cognite_client = cognite_client
            self.model = params.get("model", self.model)
            self.temperature = params.get("temperature", self.temperature)
            self.max_tokens = params.get("maxTokens", self.max_tokens)
            self.stop = params.get("stop", self.stop)

        def validate_params(self, params):
            # We leverage the API validation instead
            pass

        def _set_params(self, **kwargs):
            """
            Set Parameters
            Args:
                **kwargs: ["model", "temperature","maxTokens", "stop"]

            Returns:
                None.

            """

            valid_params = [
                "model",
                "temperature",
                "maxTokens",
                "stop",
                "model",
            ]
            for key, value in kwargs.items():
                if key in valid_params:
                    setattr(self, key, value)

        @property
        def _default_params(self):
            """
            Get the default parameters for calling OpenAI API

            Returns
                Dict: A dict of OpenAi API parameters.

            """

            return {"temperature": self.temperature, "maxTokens": self.max_tokens, "model": self.model}

        def chat_completion(self, value, memory):
            messages = memory.to_openai_messages() if memory else []

            # adding current prompt as latest query message
            messages.append(
                {
                    "role": "user",
                    "content": value,
                },
            )

            params = {
                **self._default_params,
                "messages": messages,
            }

            if self.stop is not None:
                params["stop"] = [self.stop]

            response = self.cognite_client.post(
                url=f"/api/v1/projects/{self.cognite_client.config.project}/ai/chat/completions", json=params
            )
            return response.json()["choices"][0]["message"]["content"]

        def call(self, instruction, context=None):
            memory = context.memory if context else None

            self.last_prompt = instruction.to_string()

            response = self.chat_completion(self.last_prompt, memory)
            return response

        @property
        def type(self) -> str:
            return "cognite"

    class SmartDataframe(SDF):
        def __init__(
            self,
            df: pd.DataFrame,
            cognite_client: CogniteClient,
            params: dict | None = None,
            config: dict | None = None,
        ):
            llm = CogniteLLM(cognite_client=cognite_client, params=params or {})
            cfg = Config(llm=llm, enable_cache=False, **(config or {}))
            super().__init__(df, config=cfg)

    class SmartDatalake(SDL):
        def __init__(
            self,
            dfs: list[pd.DataFrame],
            cognite_client: CogniteClient,
            params: dict | None = None,
            config: dict | None = None,
        ):
            llm = CogniteLLM(cognite_client=cognite_client, params=params or {})
            cfg = Config(llm=llm, enable_cache=False, **(config or {}))
            super().__init__(dfs, config=cfg)

    class Agent(PandasAgent):
        def __init__(
            self,
            dfs: Sequence[pd.DataFrame],
            cognite_client: CogniteClient,
            params: dict | None = None,
            config: dict | None = None,
        ):
            llm = CogniteLLM(cognite_client=cognite_client, params=params or {})
            cfg = Config(llm=llm, enable_cache=False, **(config or {}))
            super().__init__(list(dfs), config=cfg)

    return SmartDataframe, SmartDatalake, Agent
