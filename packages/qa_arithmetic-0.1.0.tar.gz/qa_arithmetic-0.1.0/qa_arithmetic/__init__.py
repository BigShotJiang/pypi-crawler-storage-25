"""qa-arithmetic — Quantum Arithmetic core primitives.

Pure Python, zero dependencies. The foundation for qa-observer, qa-pim, qa-graph.

Core operations:
    qa_step(b, e, m)       → A1-compliant Fibonacci shift
    qa_mod(x, m)           → modular reduction to {1,...,m}
    orbit_family(b, e, m)  → singularity / satellite / cosmos
    orbit_period(b, e, m)  → period by simulation
    norm_f(b, e)           → integer norm b²+be-e² in Z[φ]
    v3(n)                  → 3-adic valuation
    qa_tuple(b, e, m)      → full (b, e, d, a) tuple
    identities(b, e, m)    → all 16 QA identities as a dict
"""

__version__ = "0.1.0"

from qa_arithmetic.core import (
    qa_step,
    qa_mod,
    orbit_family,
    orbit_period,
    norm_f,
    v3,
    qa_tuple,
    KNOWN_MODULI,
    self_test,
)

from qa_arithmetic.identities import identities, IDENTITY_NAMES

__all__ = [
    "qa_step",
    "qa_mod",
    "orbit_family",
    "orbit_period",
    "norm_f",
    "v3",
    "qa_tuple",
    "identities",
    "IDENTITY_NAMES",
    "KNOWN_MODULI",
    "self_test",
]
