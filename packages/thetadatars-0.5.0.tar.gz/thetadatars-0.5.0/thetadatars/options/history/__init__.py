"""Historical option data helpers."""
