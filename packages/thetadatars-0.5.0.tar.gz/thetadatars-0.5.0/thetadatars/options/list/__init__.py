"""Option reference data helpers."""
