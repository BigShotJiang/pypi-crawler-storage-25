"""Current option snapshot helpers."""
