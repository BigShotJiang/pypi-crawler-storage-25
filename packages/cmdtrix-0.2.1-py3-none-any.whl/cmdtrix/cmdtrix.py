from atexit import register as atexitregister
from collections import deque
from functools import lru_cache
from os import get_terminal_size, system, name as osname
from random import choices, randrange, random
from time import sleep as delay_frame
from _thread import interrupt_main

from cmdtrix.util.EventTimer import EventTimer
from cmdtrix.util.Chars import charList, japanese
from cmdtrix.util.ArgsHandler import ArgsHandler


colorCodes = {'black': '30', 'red': '31', 'green': '32', 'yellow': '33',
              'blue': '34', 'magenta': '35', 'cyan': '36', 'white': '37'}
cols, rows = get_terminal_size()

FRAME_DELAY = 0.015

MINIMUM_LINE_LENGTH = 10
MAXIMUM_LINE_LENGTH = rows
NUMBER_OF_MATRIXCOLUMNS = cols
MAX_SPEED_TICKS = 5
COLOR = 'green'
COLOR_PEAK = 'white'

HIDDEN_MESSAGE = []

SYNCHRONOUS = False
CHANCE_FOR_DIM = 0.0
CHANCE_FOR_ITALIC = 0.0
CHANCE_FOR_BOTTOM_UP = 0.0
RAINBOW_HUE = 0.25
RAINBOW = False

ON_KEY_DETECTION = False
keyDetected = 0

FRAME_BUFFER = []


class MatrixColumn:
    def __init__(self, col):
        self.reset(col)

    def reset(self, col):
        self.finished = False
        self.currentTick = 0

        self.yPositionSet = 1
        self.yPositionErased = 1
        self.lastChar = ''

        self.col = col
        self.speedTicks = randrange(1, MAX_SPEED_TICKS + 1)
        self.speedTickCap = (MAX_SPEED_TICKS if SYNCHRONOUS else self.speedTicks)

        self.lineLength = randrange(MINIMUM_LINE_LENGTH, MAXIMUM_LINE_LENGTH+1)
        self.maxYPosition = min(rows, randrange(2*rows))

        self.chars = deque(choices(charList, k=self.speedTickCap * (self.maxYPosition - 1) + self.speedTicks))

        self.message_event = False
        self.message_chars = []
        self.message_color = None
        self.message_begin = 0
        self.message_length = 0
        for message, chance, color in HIDDEN_MESSAGE:
            self.message_event = (self.maxYPosition > len(message) + 1) and (random() < chance)
            if self.message_event:
                self.message_chars = list(message)
                self.message_color = color
                self.message_begin = randrange(1, self.maxYPosition - len(message)+2)
                self.message_length = len(self.message_chars)
                break

    def update(self):
        self.currentTick = (self.currentTick % self.speedTickCap + 1)

        if self.currentTick == self.speedTicks:
            if self.yPositionSet <= self.maxYPosition:
                if self.message_event and self.message_begin <= self.yPositionSet < self.message_begin + self.message_length:
                    self.lastChar = self.message_chars.pop(0)
                    FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet-1, self.message_color,  ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
                else:
                    FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet-1, COLOR,  ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
                self.lastChar = self.chars.pop()
                FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet, COLOR_PEAK, ''))
            elif self.yPositionSet - 1 == self.maxYPosition >= rows:
                FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet-1, COLOR, ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
            if self.yPositionSet > self.lineLength:
                FRAME_BUFFER.append((' ', self.col, self.yPositionErased-1, 'black', ''))
                self.yPositionErased += 1
            self.finished = (self.yPositionErased > self.maxYPosition+1)

            self.yPositionSet += 1
        elif self.yPositionSet <= self.maxYPosition:
            self.lastChar = self.chars.pop()
            FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet-1, COLOR_PEAK, ''))


class MatrixColumnBottomUp:
    def __init__(self, col):
        self.reset(col)

    def reset(self, col):
        self.finished = False
        self.currentTick = 0

        self.yPositionSet = rows
        self.yPositionErased = rows
        self.lastChar = ''

        self.col = col
        self.speedTicks = randrange(1, MAX_SPEED_TICKS + 1)
        self.speedTickCap = (MAX_SPEED_TICKS if SYNCHRONOUS else self.speedTicks)

        self.lineLength = randrange(MINIMUM_LINE_LENGTH, MAXIMUM_LINE_LENGTH + 1)
        self.minYPosition = max(1, rows - randrange(2 * rows))

        self.chars = deque(choices(charList, k=self.speedTickCap * (rows - self.minYPosition) + self.speedTicks))

        self.message_event = False
        self.message_chars = []
        self.message_color = None
        self.message_begin = 0
        self.message_length = 0
        for message, chance, color in HIDDEN_MESSAGE:
            available_len = rows - self.minYPosition + 1
            self.message_event = (available_len > len(message) + 1) and (random() < chance)
            if self.message_event:
                self.message_chars = list(reversed(message))
                self.message_color = color
                self.message_begin = randrange(self.minYPosition + len(message) - 1, rows)
                self.message_length = len(self.message_chars)
                break

    def update(self):
        self.currentTick = (self.currentTick % self.speedTickCap + 1)

        if self.currentTick == self.speedTicks:
            if self.yPositionSet >= self.minYPosition:
                if self.message_event and self.message_begin >= self.yPositionSet > self.message_begin - self.message_length:
                    self.lastChar = self.message_chars.pop(0)
                    FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet + 1, self.message_color, ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
                else:
                    FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet + 1, COLOR, ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
                self.lastChar = self.chars.pop()
                FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet, COLOR_PEAK, ''))
            elif self.yPositionSet + 1 == self.minYPosition <= 1:
                FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet + 1, COLOR, ('2;' * (random() < CHANCE_FOR_DIM)) + ('3;' * (random() < CHANCE_FOR_ITALIC))))
            if self.yPositionSet < rows - self.lineLength + 1:
                FRAME_BUFFER.append((' ', self.col, self.yPositionErased + 1, 'black', ''))
                self.yPositionErased -= 1
            self.finished = (self.yPositionErased < self.minYPosition - 1)

            self.yPositionSet -= 1
        elif self.yPositionSet >= self.minYPosition:
            self.lastChar = self.chars.pop()
            FRAME_BUFFER.append((self.lastChar, self.col, self.yPositionSet + 1, COLOR_PEAK, ''))


@lru_cache(maxsize=cols*rows*64)
def getCode(*code: str) -> str:
    return '\x1b[' + '\x1b['.join(code)


def printCode(*code: str) -> None:
    print(getCode(*code), end='')

def hsv_to_rgb_unit(h):
    # h in [0.0, 1.0)
    h = h % 1.0
    i = int(h * 6.0)
    f = (h * 6.0) - i
    i %= 6
    if i == 0:
        return 255, int(255*f), 0
    if i == 1:
        return 255-int(255*f), 255, 0
    if i == 2:
        return 0, 255, int(255*f)
    if i == 3:
        return 0, 255-int(255*f), 255
    if i == 4:
        return int(255*f), 0, 255
    return 255, 0, 255-int(255*f)

def _color_to_ansi(color, style: str) -> str:
    style = style or '0;'
    if isinstance(color, tuple):
        r, g, b = color
        return f"{style}38;2;{r};{g};{b}m"
    return f"{style}{colorCodes[color]}m"

def flushFrameBuffer() -> None:
    output = []
    for text, x, y, color, style in FRAME_BUFFER:
        output.append(getCode('%d;%df' % (y, x), _color_to_ansi(color, style)))
        output.append(text)

    print(''.join(output), end='', flush=True)
    FRAME_BUFFER.clear()

def checkTerminalSize() -> None:
    global cols, rows
    colsNew, rowsNew = get_terminal_size()
    if cols != colsNew or rows != rowsNew:
        cols = colsNew
        rows = rowsNew
        global MAXIMUM_LINE_LENGTH
        MAXIMUM_LINE_LENGTH = rows
        global NUMBER_OF_MATRIXCOLUMNS
        NUMBER_OF_MATRIXCOLUMNS = cols
        printCode('2J')  # clear screen


def on_press(_):
    global keyDetected
    keyDetected += 1


def updateMatrixColumns(matrixColumns: set) -> None:
    """
    add a new MatrixColumn every Tick, if the MAX has not been reached yet
    """
    global keyDetected
    if RAINBOW:
        global RAINBOW_HUE
        global COLOR
        global COLOR_PEAK
        RAINBOW_HUE = (RAINBOW_HUE + 0.0001) % 1.0
        COLOR = hsv_to_rgb_unit(RAINBOW_HUE)
        COLOR_PEAK = hsv_to_rgb_unit(1.0 - RAINBOW_HUE)
    for matrixColumn in matrixColumns:
        matrixColumn.update()
        if matrixColumn.finished and (not ON_KEY_DETECTION or keyDetected):
            col = randrange(cols+1)
            matrixColumn.reset(col)
            keyDetected = max(0, keyDetected-1)
    if len(matrixColumns) >= NUMBER_OF_MATRIXCOLUMNS or (ON_KEY_DETECTION and not keyDetected):
        return
    col = randrange(cols+1)
    matrixColumns.add(MatrixColumnBottomUp(col) if random() < CHANCE_FOR_BOTTOM_UP else MatrixColumn(col))
    keyDetected = max(0, keyDetected-1)


def init() -> EventTimer:
    printCode('?25l', '2J')  # hide cursor, clear screen
    return EventTimer(10, checkTerminalSize)


def deinit(eventTimer: list) -> None:
    printCode('m', '2J', '?25h')  # reset attributes, clear screen, show cursor
    for timer in eventTimer:
        timer.cancel()

def __debug_():
    with open('cmdtrix.debug.txt', 'w', encoding='utf-8') as f:
        f.write(f"{getCode.cache_info()}\n")

def main():
    # atexitregister(__debug_)
    eventTimer = []
    exitOnArg = True
    exitStatus = 0
    try:
        argsHandler = ArgsHandler(__file__)
        global COLOR
        COLOR = argsHandler.color
        global COLOR_PEAK
        COLOR_PEAK = argsHandler.color_peak
        global CHANCE_FOR_DIM
        CHANCE_FOR_DIM = argsHandler.dim
        global CHANCE_FOR_ITALIC
        CHANCE_FOR_ITALIC = argsHandler.italic
        global RAINBOW
        RAINBOW = argsHandler.rainbow
        global CHANCE_FOR_BOTTOM_UP
        CHANCE_FOR_BOTTOM_UP = argsHandler.bottomup
        global SYNCHRONOUS
        SYNCHRONOUS = argsHandler.synchronous
        global HIDDEN_MESSAGE
        HIDDEN_MESSAGE = argsHandler.messages
        global charList
        charList = [*argsHandler.alpha] if argsHandler.alpha else charList
        charList = japanese if argsHandler.japanese else charList
        global FRAME_DELAY
        FRAME_DELAY = argsHandler.frameDelay
        global ON_KEY_DETECTION
        ON_KEY_DETECTION = argsHandler.onkey
        exitOnArg = False

        eventTimer.append(init())
        timer = argsHandler.timer
        if timer != None:
            eventTimer.append(EventTimer(timer, interrupt_main, 'Timer'))
        if ON_KEY_DETECTION:
            eventTimer.append(EventTimer(None, None, 'keyboardListener', on_press=on_press))
            print('', flush=True)


        matrixColumns = set()
        while True:
            updateMatrixColumns(matrixColumns)
            flushFrameBuffer()
            delay_frame(FRAME_DELAY)
    except KeyboardInterrupt:
        pass
    except Exception:
        exitStatus = 1
    finally:
        if not exitOnArg:
            deinit(eventTimer)
            system('cls' if osname == 'nt' else 'clear')
    exit(exitStatus)


if __name__ == '__main__':
    main()
