"""
LM Studio Provider.

LM Studio exposes an OpenAI-compatible REST API at http://localhost:1234/v1.
This provider is a thin shim over the standard OpenAI HTTP interface —
no special auth required when running locally.
"""
import json
import time
from typing import AsyncIterator

import httpx

from neuralbrok.providers.base import (
    BaseProvider,
    BackendUnavailableError,
    ProviderError,
)

_DEFAULT_HOST = "http://localhost:1234"


class LMStudioProvider(BaseProvider):
    """Routes inference to a locally-running LM Studio server.

    LM Studio hosts an OpenAI-compatible API at http://localhost:1234/v1.
    No API key is required for local connections.

    Args:
        name:  Logical name used in routing decisions (e.g. 'lmstudio_local').
        host:  Base URL of the LM Studio server (default: http://localhost:1234).
    """

    def __init__(self, name: str = "lmstudio", host: str = _DEFAULT_HOST):
        super().__init__(name=name, provider_type="local")
        self.host = host.rstrip("/")
        self._base_url = f"{self.host}/v1"

    # ── Public API ────────────────────────────────────────────────────────────

    async def chat(self, payload: dict, stream: bool = True) -> AsyncIterator[str]:  # noqa: C901
        """Forward a chat completion request to LM Studio."""
        url = f"{self._base_url}/chat/completions"
        body = {**payload, "stream": stream}

        # LM Studio uses the model name from its loaded model list.
        # If the caller passes a NeuralBroker alias, strip the prefix.
        model = body.get("model", "")
        if model.startswith("NeuralBroker:"):
            model = model.split(":", 1)[1]
            body["model"] = model

        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
        }

        try:
            if stream:
                async for chunk in self._stream(url, headers, body):
                    yield chunk
            else:
                result = await self._sync(url, headers, body)
                yield result
        except httpx.ConnectError:
            raise BackendUnavailableError(
                self.name,
                f"LM Studio not reachable at {self.host}. "
                "Is the server running? Check Server > Start Server in the LM Studio UI.",
            )
        except httpx.TimeoutException:
            raise ProviderError(self.name, "LM Studio request timed out")
        except httpx.HTTPStatusError as e:
            raise ProviderError(
                self.name,
                f"LM Studio HTTP {e.response.status_code}: {e.response.text[:200]}",
            )

    async def health_check(self) -> bool:
        """Ping the /v1/models endpoint to confirm LM Studio is alive."""
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                r = await client.get(f"{self._base_url}/models")
                return r.status_code == 200
        except Exception:
            return False

    # ── Internal ─────────────────────────────────────────────────────────────

    async def _sync(self, url: str, headers: dict, body: dict) -> str:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(url, headers=headers, json=body)
            r.raise_for_status()
            return r.text

    async def _stream(  # noqa: C901
        self, url: str, headers: dict, body: dict
    ) -> AsyncIterator[str]:
        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream("POST", url, headers=headers, json=body) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith("data:"):
                        yield line + "\n\n"
                    # LM Studio may emit raw JSON lines without "data:" prefix
                    elif line.startswith("{"):
                        yield f"data: {line}\n\n"
