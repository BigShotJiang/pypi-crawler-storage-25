"""
ChatGPT Subscription Subprocess Provider.

Routes requests through the installed `chatgpt` CLI (OpenAI Codex CLI)
using its OAuth session from ~/.codex/auth.json.

No API key required — uses ChatGPT Plus/Pro subscription.
Cost = $0 at margin (subscription already paid).

Falls back to direct chatgpt.com/backend-api HTTP if the CLI is unavailable
but a valid OAuth bearer token exists in ~/.codex/auth.json.
"""
import asyncio
import json
import os
import shutil
import time
from pathlib import Path
from typing import AsyncIterator, Optional

import httpx

from neuralbrok.providers.base import (
    BaseProvider,
    BackendUnavailableError,
    ProviderError,
)

_DEFAULT_MODEL = "gpt-4o"

# OpenAI model aliases accepted by the chatgpt CLI
_MODEL_ALIASES: dict[str, str] = {
    "gpt-4o": "gpt-4o",
    "gpt-4o-mini": "gpt-4o-mini",
    "o1": "o1",
    "o3": "o3",
    "o4-mini": "o4-mini",
    "chatgpt-latest": "gpt-4o",
    "chatgpt": "gpt-4o",
}

SUPPORTED_MODELS = list(_MODEL_ALIASES.keys())

# chatgpt.com backend-api endpoint used for OAuth-based inference
_CHATGPT_API_BASE = "https://chatgpt.com/backend-api"


def _read_codex_oauth_token() -> Optional[str]:
    """Read the ChatGPT OAuth bearer token from ~/.codex/auth.json."""
    path = Path.home() / ".codex" / "auth.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        tokens = data.get("tokens", {})
        return tokens.get("access_token")
    except Exception:
        return None


def _messages_to_prompt(messages: list[dict]) -> tuple[str, str | None]:
    """Convert OpenAI messages list to flat prompt + optional system string."""
    system = None
    history = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if isinstance(content, list):
            content = " ".join(
                p.get("text", "") for p in content if p.get("type") == "text"
            )
        if role == "system":
            system = content
        elif role == "user":
            history.append(f"Human: {content}")
        elif role == "assistant":
            history.append(f"Assistant: {content}")

    if not history:
        return "", system
    if len(history) == 1 and history[0].startswith("Human: "):
        return history[0][len("Human: "):], system
    return "\n\n".join(history), system


class ChatGPTSubprocessProvider(BaseProvider):
    """Runs inference via installed `chatgpt` (Codex) CLI or OAuth HTTP fallback.

    Strategy (in order):
    1. Shell out to `chatgpt` CLI — uses the authenticated OAuth session.
    2. If CLI not found, use the OAuth bearer token from ~/.codex/auth.json
       to call chatgpt.com/backend-api directly via httpx.
    3. If neither is available, raise BackendUnavailableError.

    Cost = $0 at margin (subscription already paid).
    """

    SUPPORTED_MODELS = SUPPORTED_MODELS

    def __init__(self, name: str = "chatgpt", model: str = _DEFAULT_MODEL):
        super().__init__(name=name, provider_type="cloud")
        self.model = _MODEL_ALIASES.get(model, model)
        # Try both CLI names: 'codex' (official) and 'chatgpt' (legacy alias)
        self._cli_path: Optional[str] = shutil.which("codex") or shutil.which("chatgpt")
        self._oauth_token: Optional[str] = _read_codex_oauth_token()

    # ── Public API ────────────────────────────────────────────────────────────

    async def chat(self, payload: dict, stream: bool = True) -> AsyncIterator[str]:
        messages = payload.get("messages", [])
        raw_model = payload.get("model", self.model)
        model = _MODEL_ALIASES.get(raw_model, self.model)
        chunk_id = f"chatcmpl-nb-{self.name}-{int(time.time())}"

        if not messages:
            raise ProviderError(self.name, "Empty messages", retryable=False)

        # Prefer CLI; fall back to HTTP with OAuth token
        if self._cli_path:
            async for chunk in self._via_cli(messages, model, chunk_id, stream):
                yield chunk
        elif self._oauth_token:
            async for chunk in self._via_http(messages, model, chunk_id, stream, payload):
                yield chunk
        else:
            raise BackendUnavailableError(
                self.name,
                "Neither `chatgpt` CLI nor OAuth token found. "
                "Install Codex CLI (npm install -g @openai/codex) and run `codex login`.",
            )

    async def health_check(self) -> bool:
        # Refresh token in case it was written after init
        self._oauth_token = _read_codex_oauth_token()
        if self._cli_path:
            try:
                proc = await asyncio.create_subprocess_exec(
                    self._cli_path, "--version",
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=5.0)
                return proc.returncode == 0
            except Exception:
                pass
        return self._oauth_token is not None

    # ── CLI path ──────────────────────────────────────────────────────────────

    async def _via_cli(  # noqa: C901
        self,
        messages: list[dict],
        model: str,
        chunk_id: str,
        stream: bool,
    ) -> AsyncIterator[str]:
        """Shell out to `chatgpt -p <prompt> --model <model>`."""
        prompt, system = _messages_to_prompt(messages)
        if not prompt:
            raise ProviderError(self.name, "Empty prompt after message conversion", retryable=False)

        cmd = [
            self._cli_path,
            "exec",
            prompt,
            "-c", f'model="{model}"',
        ]
        if system:
            cmd += ["-c", f'instructions="{system}"']

        if stream:
            async for chunk in self._cli_stream(cmd, chunk_id, model):
                yield chunk
        else:
            result = await self._cli_sync(cmd)
            yield json.dumps({
                "id": chunk_id,
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": result},
                    "finish_reason": "stop",
                }],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            })

    async def _cli_sync(self, cmd: list[str]) -> str:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120.0)
        except asyncio.TimeoutError:
            proc.kill()
            raise ProviderError(self.name, "chatgpt CLI timeout after 120s")

        if proc.returncode != 0:
            err = stderr.decode(errors="replace").strip()
            raise ProviderError(self.name, f"chatgpt CLI exit {proc.returncode}: {err}")

        raw = stdout.decode(errors="replace").strip()
        try:
            data = json.loads(raw)
            return data.get("result") or data.get("content") or raw
        except json.JSONDecodeError:
            return raw

    async def _cli_stream(
        self, cmd: list[str], chunk_id: str, model: str
    ) -> AsyncIterator[str]:
        # Codex exec doesn't have a --output-format flag like the old chatgpt CLI.
        # We run the same exec command and capture stdout line-by-line.
        stream_cmd = list(cmd)

        proc = await asyncio.create_subprocess_exec(
            *stream_cmd,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        yielded = False
        async for raw_line in proc.stdout:
            line = raw_line.decode(errors="replace").strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                # Plain text fallback — CLI emitting raw text
                if line and not line.startswith("{"):
                    oai = {
                        "id": chunk_id, "object": "chat.completion.chunk",
                        "created": int(time.time()), "model": model,
                        "choices": [{"index": 0, "delta": {"content": line}, "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(oai)}\n\n"
                    yielded = True
                continue

            # Handle both Claude-style and OpenAI-style stream events
            etype = event.get("type", "")

            # OpenAI Responses API format
            if etype == "response.output_text.delta":
                delta = event.get("delta", "")
                if delta:
                    oai = {
                        "id": chunk_id, "object": "chat.completion.chunk",
                        "created": int(time.time()), "model": model,
                        "choices": [{"index": 0, "delta": {"content": delta}, "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(oai)}\n\n"
                    yielded = True

            # Standard SSE passthrough (CLI emits pre-formed SSE)
            elif etype == "content_block_delta":
                delta = event.get("delta", {}).get("text", "")
                if delta:
                    oai = {
                        "id": chunk_id, "object": "chat.completion.chunk",
                        "created": int(time.time()), "model": model,
                        "choices": [{"index": 0, "delta": {"content": delta}, "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(oai)}\n\n"
                    yielded = True

            # Fallback: if event has a top-level "content" or "text" key
            elif "content" in event or "text" in event:
                text = event.get("content") or event.get("text", "")
                if text:
                    oai = {
                        "id": chunk_id, "object": "chat.completion.chunk",
                        "created": int(time.time()), "model": model,
                        "choices": [{"index": 0, "delta": {"content": text}, "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(oai)}\n\n"
                    yielded = True

        await proc.wait()
        if proc.returncode and proc.returncode != 0:
            stderr_data = await proc.stderr.read()
            err = stderr_data.decode(errors="replace").strip()
            if not yielded:
                raise ProviderError(self.name, f"chatgpt CLI exit {proc.returncode}: {err}")

        yield "data: [DONE]\n\n"

    # ── HTTP OAuth path ───────────────────────────────────────────────────────

    async def _via_http(  # noqa: C901
        self,
        messages: list[dict],
        model: str,
        chunk_id: str,
        stream: bool,
        original_payload: dict,
    ) -> AsyncIterator[str]:
        """Call chatgpt.com/backend-api/conversation with OAuth bearer token.

        Uses the Responses API format that chatgpt.com expects.
        Token comes from ~/.codex/auth.json.
        """
        if not self._oauth_token:
            raise BackendUnavailableError(self.name, "No OAuth token available")

        headers = {
            "Authorization": f"Bearer {self._oauth_token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "Mozilla/5.0 (compatible; NeuralBroker/1.0)",
            "Origin": "https://chatgpt.com",
            "Referer": "https://chatgpt.com/",
        }

        # Build Responses-API compatible payload
        input_items = []
        system_text = None
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(p.get("text", "") for p in content if p.get("type") == "text")
            if role == "system":
                system_text = content
            else:
                input_items.append({"role": role, "content": content})

        body: dict = {
            "model": model,
            "input": input_items,
            "stream": stream,
        }
        if system_text:
            body["instructions"] = system_text
        if original_payload.get("max_tokens"):
            body["max_output_tokens"] = original_payload["max_tokens"]
        if original_payload.get("temperature") is not None:
            body["temperature"] = original_payload["temperature"]

        url = f"{_CHATGPT_API_BASE}/responses"

        try:
            if stream:
                async for chunk in self._http_stream(url, headers, body, chunk_id, model):
                    yield chunk
            else:
                result = await self._http_sync(url, headers, body)
                yield json.dumps({
                    "id": chunk_id,
                    "object": "chat.completion",
                    "created": int(time.time()),
                    "model": model,
                    "choices": [{
                        "index": 0,
                        "message": {"role": "assistant", "content": result},
                        "finish_reason": "stop",
                    }],
                    "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                })
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                # Token expired — re-read from disk and surface clear error
                self._oauth_token = _read_codex_oauth_token()
                raise ProviderError(
                    self.name,
                    "ChatGPT OAuth token expired or invalid. Re-run `codex login`.",
                    retryable=False,
                )
            elif e.response.status_code == 429:
                from neuralbrok.providers.base import RateLimitError
                raise RateLimitError(self.name, "ChatGPT rate limited")
            raise ProviderError(self.name, f"HTTP {e.response.status_code}: {e.response.text[:200]}")
        except httpx.RequestError as e:
            raise BackendUnavailableError(self.name, f"Connection failed: {e}")

    async def _http_sync(self, url: str, headers: dict, body: dict) -> str:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(url, headers=headers, json=body)
            r.raise_for_status()
            data = r.json()
            # Responses API: output[0].content[0].text
            try:
                return data["output"][0]["content"][0]["text"]
            except (KeyError, IndexError):
                # Fallback: try standard completion format
                return data.get("choices", [{}])[0].get("message", {}).get("content", str(data))

    async def _http_stream(
        self, url: str, headers: dict, body: dict, chunk_id: str, model: str
    ) -> AsyncIterator[str]:
        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream("POST", url, headers=headers, json=body) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if raw == "[DONE]":
                        break
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "response.output_text.delta":
                        delta = event.get("delta", "")
                        if delta:
                            oai = {
                                "id": chunk_id, "object": "chat.completion.chunk",
                                "created": int(time.time()), "model": model,
                                "choices": [{"index": 0, "delta": {"content": delta}, "finish_reason": None}],
                            }
                            yield f"data: {json.dumps(oai)}\n\n"

                    elif "choices" in event:
                        # Already in OpenAI SSE format — pass through
                        yield f"data: {json.dumps(event)}\n\n"

        yield "data: [DONE]\n\n"
