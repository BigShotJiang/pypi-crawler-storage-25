"""
MCP (Model Context Protocol) server for NeuralBroker.

Exposes NeuralBroker's capabilities as MCP tools for Claude Code,
Cursor, and other MCP-compatible clients. Supports stdio transport.
"""
import asyncio
import json
import logging
import os
import sys
from typing import Any

logger = logging.getLogger(__name__)

TOOLS = [
    {
        "name": "nb_get_active_auth",
        "description": "Discover existing subscriptions (Claude Pro, Codex, etc.) that can be used for free cloud inference.",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "nb_route_preview",
        "description": "Analyze a prompt and see how NeuralBroker would route it (local vs cloud) to save tokens.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string"}
            },
            "required": ["prompt"]
        }
    }
]

SERVER_INFO = {"name": "neuralbroker", "version": "0.8.3-mcp"}
CAPABILITIES = {"tools": {}}

async def handle_tool(name: str, args: dict) -> list[dict]:
    if name == "nb_get_active_auth":
        from neuralbrok.auth_discovery import discover_all
        found = discover_all()
        results = []
        for p_name, auth in found.items():
            results.append({
                "provider": p_name,
                "source": auth.source,
                "subscription": auth.subscription,
                "auth_type": auth.auth_type
            })
        return [{"type": "text", "text": json.dumps(results, indent=2)}]

    elif name == "nb_route_preview":
        from neuralbrok.scoring_engine import calculate_score
        score, tier = calculate_score(args["prompt"])
        return [{"type": "text", "text": json.dumps({"score": score, "tier": tier}, indent=2)}]
        
    return [{"type": "text", "text": f"Unknown tool: {name}"}]

async def handle_message(msg: dict) -> Optional[dict]:
    method = msg.get("method", "")
    msg_id = msg.get("id")
    params = msg.get("params", {})
    
    if method == "initialize":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {"protocolVersion": "2024-11-05", "serverInfo": SERVER_INFO, "capabilities": CAPABILITIES}}
    elif method == "notifications/initialized":
        return None
    elif method == "tools/list":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {"tools": TOOLS}}
    elif method == "tools/call":
        try:
            content = await handle_tool(params.get("name",""), params.get("arguments",{}))
            return {"jsonrpc": "2.0", "id": msg_id, "result": {"content": content}}
        except Exception as e:
            return {"jsonrpc": "2.0", "id": msg_id, "result": {"content": [{"type": "text", "text": f"Error: {e}"}], "isError": True}}
    elif method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}
    
    if msg_id is not None:
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}
    return None

async def run_stdio():
    logger.info("NeuralBroker MCP server starting (stdio)")
    
    # Synchronous fallback for restricted pipes (works well on Windows/standard streams)
    loop = asyncio.get_event_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if not line: break
        try:
            msg = json.loads(line.strip())
            resp = await handle_message(msg)
            if resp:
                out = json.dumps(resp) + "\n"
                await loop.run_in_executor(None, sys.stdout.write, out)
                await loop.run_in_executor(None, sys.stdout.flush)
        except json.JSONDecodeError: 
            continue
        except Exception as e: 
            logger.error(f"MCP error: {e}")

def main():
    asyncio.run(run_stdio())

if __name__ == "__main__":
    main()
