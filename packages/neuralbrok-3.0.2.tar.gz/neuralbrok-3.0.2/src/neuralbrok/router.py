"""
Policy engine with 3 routing modes, provider scoring, and circuit breakers.

Replaces the simple threshold router from Week 1.
"""
import json
import asyncio
import httpx
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from neuralbrok.config import Config
from neuralbrok.types import (
    PolicyMode,
    RouteDecision,
    VramSnapshot,
    CircuitState,
    CircuitBreakerState,
    ProviderStatus,
)
from neuralbrok.selector import SmartModelSelector
from neuralbrok.models import get_runnable_models, resolve_model
from neuralbrok.detect import detect_device

logger = logging.getLogger(__name__)

# Circuit breaker constants
CIRCUIT_ERROR_THRESHOLD = 3
CIRCUIT_RECOVERY_SECONDS = 60.0
FALLBACK_VRAM_SPILL_THRESHOLD = 0.95
FALLBACK_VRAM_RECOVER_THRESHOLD = 0.85


@dataclass
class ProviderScore:
    """Scored provider for routing decision."""
    name: str
    provider_type: str  # "local" | "cloud"
    score: float
    cost_per_1k: float
    failed: bool = False
    reason: str = ""


class PolicyEngine:
    """VRAM-aware routing policy engine.

    Implements cost-mode, speed-mode, and fallback-mode routing
    with per-provider circuit breakers and scoring.
    """

    def __init__(self, config: Config):
        self.config = config
        self.mode = PolicyMode(config.routing.default_mode)

        # Circuit breaker state per provider name
        self._circuits: dict[str, CircuitState] = {}

        # Latency tracking
        self._latencies: dict[str, deque] = {}

        # Routing decision log (last 500)
        self._routing_log: deque[dict] = deque(maxlen=500)

        # Aggregate stats
        self._stats = {
            "total_requests": 0,
            "local_requests": 0,
            "cloud_requests": 0,
            "total_cost_local": 0.0,
            "total_cost_cloud": 0.0,
            "total_saved": 0.0,
            "smart_classifications": 0,
            "total_classify_ms": 0.0,
            "fallback_to_cost_count": 0,
            "session_start": datetime.now(timezone.utc).isoformat(),
        }

        # Per-provider cost tracking for dashboard
        self._provider_costs: dict[str, float] = {}

        # Fallback mode: track whether we're in "spill to cloud" state
        self._fallback_spilling = False

        # Last-error timestamp per provider (for circuit breaker recovery)
        self._last_error: dict[str, datetime] = {}

        # Smart model selector (for SMART mode) — deferred until providers are set
        self._selector: Optional[SmartModelSelector] = None

    # ── Public API ─────────────────────────────────────────────────────────────

    async def decide_async(
        self,
        request_body: dict,
        vram: Optional[VramSnapshot],
        available_providers: list[str],
        provider_types: dict[str, str],
        provider_costs: dict[str, float],
        requested_model: str = "",
    ) -> RouteDecision:
        """Make an async routing decision.

        This is the main entry point for routing. It:
        1. Classifies the prompt complexity (in SMART mode)
        2. Applies the active policy mode
        3. Scores all available providers
        4. Returns the best provider + fallback chain
        """
        start = time.perf_counter()
        self._stats["total_requests"] += 1

        vram_util = 0.0
        if vram and (vram.vram_used_gb + vram.vram_free_gb) > 0:
            total = vram.vram_used_gb + vram.vram_free_gb
            vram_util = vram.vram_used_gb / total

        # Filter out circuit-broken providers — 3-state circuit breaker
        # CLOSED → available; OPEN → blocked; HALF_OPEN → allow one probe
        active = []
        for name in available_providers:
            circuit = self._get_circuit(name)
            if circuit.state == CircuitBreakerState.CLOSED:
                active.append(name)
                continue
            if circuit.state == CircuitBreakerState.OPEN:
                if (circuit.failed_at and
                        datetime.now(timezone.utc) - circuit.failed_at
                        > timedelta(seconds=circuit.recovery_seconds)):
                    circuit.state = CircuitBreakerState.HALF_OPEN
                    circuit.probe_in_flight = False
                    logger.info(f"Circuit breaker HALF_OPEN for {name} — probing")
                else:
                    continue
            if circuit.state == CircuitBreakerState.HALF_OPEN:
                if not circuit.probe_in_flight:
                    active.append(name)
                    circuit.probe_in_flight = True

        if not active:
            sorted_providers = sorted(
                available_providers,
                key=lambda n: self._get_circuit(n).failed_at or datetime.min.replace(tzinfo=timezone.utc),
            )
            for name in sorted_providers:
                circuit = self._get_circuit(name)
                circuit.state = CircuitBreakerState.CLOSED
                circuit.consecutive_errors = 0
                circuit.probe_in_flight = False
                active.append(name)
                logger.warning(f"All providers blocked — force-recovering {name}")
                break

        # Smart classification
        classified_as = ""
        if self.mode == PolicyMode.SMART and self._selector:
            try:
                classify_start = time.perf_counter()
                messages = request_body.get("messages", [])
                prompt_text = " ".join(
                    m.get("content", "") if isinstance(m.get("content"), str)
                    else " ".join(p.get("text", "") for p in m.get("content", []) if p.get("type") == "text")
                    for m in messages
                )
                _, classified_as = self._selector.classify(prompt_text)
                classify_ms = (time.perf_counter() - classify_start) * 1000
                self._stats["smart_classifications"] += 1
                self._stats["total_classify_ms"] += classify_ms
            except Exception as e:
                logger.debug(f"Smart classification failed: {e}")

        # Score providers based on policy mode
        scored = self._score_providers(
            active, provider_types, provider_costs, vram_util,
            requested_model=requested_model,
        )

        # Sort by score descending
        scored.sort(key=lambda s: s.score, reverse=True)

        if not scored:
            return RouteDecision(
                backend_chosen="",
                fallback_chain=[],
                reason="no providers available",
                latency_ms=(time.perf_counter() - start) * 1000,
            )
        winner = scored[0]
        fallback_chain = [s.name for s in scored[1:] if not s.failed]

        reason = self._explain_decision(winner, vram_util)
        latency_ms = (time.perf_counter() - start) * 1000

        decision = RouteDecision(
            backend_chosen=winner.name,
            fallback_chain=fallback_chain,
            vram_at_decision=vram,
            policy_mode=self.mode,
            latency_ms=latency_ms,
            reason=reason,
            classified_as=classified_as,
            timestamp=datetime.now(timezone.utc),
        )

        # Log the decision — resolve display name for dashboard readability
        display_name = winner.name
        try:
            resolved = resolve_model(winner.name)
            if resolved and hasattr(resolved, "display_name") and resolved.display_name:
                display_name = resolved.display_name
        except Exception:
            pass

        log_entry = {
            "backend": decision.backend_chosen,
            "display_name": display_name,
            "mode": self.mode.value,
            "reason": reason,
            "vram_util": round(vram_util, 3),
            "latency_ms": round(latency_ms, 2),
            "fallback_chain": fallback_chain,
            "classified_as": classified_as,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._routing_log.append(log_entry)

        # Track local vs cloud
        if winner and provider_types.get(winner.name) == "local":
            self._stats["local_requests"] += 1
        elif winner:
            self._stats["cloud_requests"] += 1

        return decision

    def record_success(self, provider_name: str) -> None:
        """Record a successful request — reset circuit breaker.
        HALF_OPEN probe success → CLOSED. CLOSED success → stays CLOSED.
        """
        circuit = self._get_circuit(provider_name)
        if circuit.state == CircuitBreakerState.HALF_OPEN:
            logger.info(f"Circuit breaker CLOSED (recovered) for {provider_name}")
        circuit.consecutive_errors = 0
        circuit.failed = False
        circuit.probe_in_flight = False
        circuit.state = CircuitBreakerState.CLOSED

    def record_error(self, provider_name: str) -> None:
        """Record a failed request — drive 3-state circuit breaker.
        CLOSED: increment errors; trip OPEN after threshold.
        HALF_OPEN probe failure: immediately back to OPEN.
        """
        circuit = self._get_circuit(provider_name)
        circuit.consecutive_errors += 1
        circuit.probe_in_flight = False
        self._last_error[provider_name] = datetime.now(timezone.utc)

        if circuit.state == CircuitBreakerState.HALF_OPEN:
            circuit.state = CircuitBreakerState.OPEN
            circuit.failed = True
            circuit.failed_at = datetime.now(timezone.utc)
            logger.warning(f"Circuit breaker re-OPEN for {provider_name} (probe failed)")
        elif circuit.consecutive_errors >= CIRCUIT_ERROR_THRESHOLD:
            circuit.state = CircuitBreakerState.OPEN
            circuit.failed = True
            circuit.failed_at = datetime.now(timezone.utc)
            logger.warning(
                f"Circuit breaker OPEN for {provider_name} "
                f"({circuit.consecutive_errors} consecutive errors)"
            )

    def record_cost(
        self,
        provider_name: str,
        provider_type: str,
        cost_usd: float,
        cheapest_cloud_cost: float,
    ) -> None:
        """Record cost for a completed request and compute savings."""
        if provider_type == "local":
            self._stats["total_cost_local"] += cost_usd
            saved = max(0, cheapest_cloud_cost - cost_usd)
            self._stats["total_saved"] += saved
        else:
            self._stats["total_cost_cloud"] += cost_usd

        self._provider_costs[provider_name] = (
            self._provider_costs.get(provider_name, 0.0) + cost_usd
        )

    def compute_local_cost(
        self, tokens: int, latency_ms: float
    ) -> float:
        """Compute electricity cost for a local inference request.

        Formula: (gpu_watts/1000) * $/kWh * (latency_ms/3_600_000)
        Tokens aren't a factor — cost is purely time × power × rate.
        """
        routing = self.config.routing
        cost = (
            (routing.gpu_tdp_watts / 1000)
            * routing.electricity_kwh_price
            * (latency_ms / 3_600_000)
        )
        return cost

    def get_routing_log(self) -> list[dict]:
        """Return the last 500 routing decisions."""
        return list(self._routing_log)

    def get_stats(self) -> dict:
        """Return aggregate statistics."""
        total = self._stats["total_requests"]
        sc = self._stats["smart_classifications"]
        return {
            **self._stats,
            "local_pct": (
                round(self._stats["local_requests"] / total * 100, 1)
                if total > 0 else 0
            ),
            "cloud_pct": (
                round(self._stats["cloud_requests"] / total * 100, 1)
                if total > 0 else 0
            ),
            "avg_classify_ms": (
                round(self._stats["total_classify_ms"] / sc, 1)
                if sc > 0 else 0.0
            ),
            "total_cost_saved": round(self._stats["total_saved"], 6),
            "routing_mode": self.mode.value,
            "provider_costs": {k: round(v, 6) for k, v in self._provider_costs.items()},
        }

    def get_provider_statuses(
        self,
        provider_names: list[str],
        provider_types: dict[str, str],
    ) -> list[dict]:
        """Return health and 3-state circuit breaker status for all providers."""
        statuses = []
        for name in provider_names:
            circuit = self._get_circuit(name)
            statuses.append({
                "name": name,
                "type": provider_types.get(name, "unknown"),
                "healthy": circuit.state == CircuitBreakerState.CLOSED,
                "circuit_state": circuit.state.value,
                "consecutive_errors": circuit.consecutive_errors,
                "circuit_open": circuit.state == CircuitBreakerState.OPEN,
                "probe_in_flight": circuit.probe_in_flight,
                "failed_at": (
                    circuit.failed_at.isoformat()
                    if circuit.failed_at else None
                ),
            })
        return statuses

    def record_latency(self, provider_name: str, latency_ms: float) -> None:
        if provider_name not in self._latencies:
            self._latencies[provider_name] = deque(maxlen=500)
        self._latencies[provider_name].append(latency_ms)

    def get_latency_stats(self) -> dict:
        stats = {}
        for name, lat_list in self._latencies.items():
            if not lat_list:
                continue
            s_list = sorted(list(lat_list))
            stats[name] = {
                "p50": s_list[int(len(s_list)*0.5)],
                "p95": s_list[int(len(s_list)*0.95)],
                "p99": s_list[int(len(s_list)*0.99)],
                "samples": len(s_list),
            }
        return stats

    def set_mode(self, mode: str) -> None:
        """Change routing mode at runtime."""
        self.mode = PolicyMode(mode)
        logger.info(f"Routing mode changed to: {self.mode.value}")

    # ── Internal ──────────────────────────────────────────────────────────────

    def _get_circuit(self, name: str) -> CircuitState:
        """Get or create circuit breaker state for a provider."""
        if name not in self._circuits:
            self._circuits[name] = CircuitState()
        return self._circuits[name]

    def set_providers(self, providers: dict) -> None:
        """Register the provider objects for model-support scoring.

        Call this after providers are instantiated so the engine can
        check SUPPORTED_MODELS during routing decisions.
        Also initialises the SmartModelSelector now that hardware info is available.
        """
        self._providers = providers

        # Deferred SmartModelSelector init — needs hardware profile
        if self._selector is None:
            try:
                profile = detect_device()
                runnable = get_runnable_models(
                    profile.vram_gb, profile.ram_gb, profile.gpu_model
                )
                self._selector = SmartModelSelector(
                    device_key=profile.gpu_model,
                    available_vram_gb=profile.vram_gb,
                    runnable=runnable,
                    hw_profile=profile,
                )
            except Exception as e:
                logger.debug(f"SmartModelSelector unavailable: {e}")

    def _score_providers(
        self,
        active: list[str],
        provider_types: dict[str, str],
        provider_costs: dict[str, float],
        vram_util: float,
        requested_model: str = "",
    ) -> list[ProviderScore]:
        """Score active providers based on the current policy mode."""
        scored = []
        provider_objects = getattr(self, "_providers", {})

        for name in active:
            ptype = provider_types.get(name, "cloud")
            cost = provider_costs.get(name, 0.0)
            is_local = ptype == "local"

            p95 = 500.0
            if name in self._latencies and len(self._latencies[name]) >= 10:
                s_list = sorted(list(self._latencies[name]))
                p95 = s_list[int(len(s_list)*0.95)]
            else:
                p95 = 200.0 if is_local else 400.0

            latency_penalty = p95 / 1000.0

            if self.mode == PolicyMode.COST:
                score = self._score_cost_mode(is_local, cost, vram_util) - latency_penalty * 0.2
            elif self.mode == PolicyMode.SPEED:
                score = self._score_speed_mode(is_local) - latency_penalty * 2.0
            elif self.mode == PolicyMode.FALLBACK:
                score = self._score_fallback_mode(
                    name, is_local, cost, vram_util
                ) - latency_penalty * 0.2
            else:
                score = self._score_cost_mode(is_local, cost, vram_util) - latency_penalty * 0.2

            # Model compatibility check: penalise providers that explicitly
            # declare SUPPORTED_MODELS and don't include the requested model.
            if requested_model:
                prov = provider_objects.get(name)
                if prov is not None:
                    supported = getattr(prov, "SUPPORTED_MODELS", [])
                    if supported and requested_model not in supported:
                        score = -2.0

            scored.append(ProviderScore(
                name=name,
                provider_type=ptype,
                score=score,
                cost_per_1k=cost,
            ))

        # Re-rank cloud providers by cost so cheapest wins clearly.
        if self.mode == PolicyMode.COST:
            cloud_scored = [(s, s.cost_per_1k) for s in scored if s.provider_type == "cloud" and s.score > 0]
            if len(cloud_scored) > 1:
                cloud_scored.sort(key=lambda x: x[1])
                cheapest_cost = cloud_scored[0][1]
                for ps, c in cloud_scored:
                    if cheapest_cost > 0:
                        ps.score = ps.score * (cheapest_cost / max(c, cheapest_cost * 0.001))

        return scored

    def _score_cost_mode(
        self, is_local: bool, cost: float, vram_util: float
    ) -> float:
        """Cost mode: local if VRAM < threshold, cheapest cloud otherwise."""
        threshold = 0.80
        if self.config.local_nodes:
            threshold = self.config.routing.vram_threshold_pct / 100.0

        if is_local:
            if vram_util < threshold:
                return 1.0  # Local is cheapest when VRAM available
            else:
                return 0.2  # Local full — deprioritise but don't eliminate
        else:
            # Cloud: inverse cost scoring; 0 cost (subscription) gets full score
            if cost == 0:
                return 0.85  # Subscription providers (Claude Code, ChatGPT)
            return max(0.1, 0.75 - cost * 5.0)

    def _score_speed_mode(self, is_local: bool) -> float:
        """Speed mode: cloud first (lower latency for large models)."""
        return 0.3 if is_local else 0.8

    def _score_fallback_mode(
        self,
        name: str,
        is_local: bool,
        cost: float,
        vram_util: float,
    ) -> float:
        """Fallback mode: local until VRAM threshold, then cheapest cloud."""
        spill_threshold = FALLBACK_VRAM_SPILL_THRESHOLD
        recover_threshold = FALLBACK_VRAM_RECOVER_THRESHOLD

        if vram_util > spill_threshold:
            self._fallback_spilling = True
        elif vram_util < recover_threshold:
            self._fallback_spilling = False

        if is_local and not self._fallback_spilling:
            return 1.0
        elif not is_local:
            if cost == 0:
                return 0.85
            return max(0.1, 0.75 - cost * 5.0)
        else:
            return 0.1  # Local but VRAM full

    def _explain_decision(self, winner: ProviderScore, vram_util: float) -> str:
        """Generate a human-readable reason for the routing decision."""
        if winner.provider_type == "local":
            return f"local_preferred (vram={vram_util:.0%}, mode={self.mode.value})"
        else:
            if winner.cost_per_1k == 0:
                return f"subscription_provider (cost=$0, mode={self.mode.value})"
            return f"cloud_selected (cost=${winner.cost_per_1k:.4f}/1k, mode={self.mode.value})"


def route_request(vram: VramSnapshot, config: Config) -> RouteDecision:
    """Legacy synchronous routing function — kept for backward compatibility."""
    engine = PolicyEngine(config)
    import asyncio
    return asyncio.run(engine.decide_async(
        request_body={},
        vram=vram,
        available_providers=[],
        provider_types={},
        provider_costs={},
    ))
