import re
import math
from typing import Dict, Any, Tuple
import logging

logger = logging.getLogger(__name__)

# ClawRouter-inspired 15-dimension detection markers
DIMENSIONS = {
    "reasoning": (0.18, r"(?i)\b(prove|theorem|step by step|think|analyze|evaluate|deduce|infer)\b"),
    "code": (0.15, r"(?i)\b(function|async|import|def |class |public static|console\.log|print\(|```)\b"),
    "multi_step": (0.12, r"(?i)\b(first.*?then.*?finally|step 1.*?step 2)\b"),
    "math": (0.10, r"(?i)\b(calculate|equation|solve|integral|derivative|algebra)\b"),
    "tools": (0.15, r"(?i)\b(search the web|read file|run command|use tool|fetch url)\b"),
    "creative": (0.05, r"(?i)\b(write a story|imagine|poem|creative|metaphor)\b"),
    "factual": (0.02, r"(?i)\b(what is|define|who is|capital of|when did)\b"),
    "summarize": (0.05, r"(?i)\b(summarize|tldr|tl;dr|in short)\b"),
    "translation": (0.05, r"(?i)\b(translate|in spanish|in french|in english)\b"),
    "roleplay": (0.05, r"(?i)\b(act as|you are a|persona)\b"),
    "vision": (0.10, r"(?i)\b(look at this image|what is in this picture|describe the image)\b"),
    "formatting": (0.03, r"(?i)\b(format as json|csv|markdown table|yaml)\b"),
    "extraction": (0.05, r"(?i)\b(extract|find all|list the)\b"),
    "classification": (0.05, r"(?i)\b(classify|categorize|is this positive or negative)\b"),
    # Context length is handled separately
}

# Keywords that signal complex code (architecture, refactoring, system design)
_CODE_COMPLEX_KEYWORDS = re.compile(
    r"(?i)\b(refactor|architect|design pattern|microservice|optimize|performance|"
    r"security audit|code review|implement.*from scratch|scalab|concurrent|thread|"
    r"deadlock|race condition|memory leak|algorithm|data structure|big.?o|complexity)\b"
)

# Patterns that indicate simple "snippet-level" code tasks
_CODE_SIMPLE_PATTERNS = re.compile(
    r"(?i)^\s*(what does this (code|function|snippet) do|explain this code|"
    r"fix (this|the) (syntax|typo|indentation|variable name)|add a comment|rename|format|lint)\b"
)


def _code_complexity_boost(prompt: str) -> float:
    """Return an extra score boost (0.0–0.20) based on code task complexity.

    Simple code tasks (explain, fix typo, rename) get 0.
    Complex code tasks (architect, refactor, design) get up to 0.20 extra.
    This prevents trivial code snippets from always being routed to cloud.
    """
    if _CODE_SIMPLE_PATTERNS.search(prompt):
        return -0.10  # Actively down-grade simple code tasks
    lines = prompt.count("\n")
    nesting = len(re.findall(r"[{(\[]|^\s{4,}", prompt, re.MULTILINE))
    complex_keywords = len(_CODE_COMPLEX_KEYWORDS.findall(prompt))

    boost = 0.0
    boost += min(0.08, lines / 100 * 0.08)       # up to 0.08 for long code
    boost += min(0.06, nesting / 20 * 0.06)       # up to 0.06 for deep nesting
    boost += min(0.06, complex_keywords * 0.03)   # up to 0.06 for arch keywords
    return boost


def sigmoid(x: float) -> float:
    return 1 / (1 + math.exp(-x))


def calculate_score(prompt: str) -> Tuple[float, str]:
    """
    Analyzes the prompt in <1ms and returns a score (0.0 to 1.0) and a tier.
    Tiers: SIMPLE, MEDIUM, COMPLEX, REASONING

    Code tasks are now scored on a spectrum:
      - Explain/fix typo/rename → stays SIMPLE or MEDIUM
      - Implement algorithm / refactor architecture → COMPLEX
    """
    if not prompt:
        return 0.0, "SIMPLE"

    total_weight = 0.0
    active_dims = []

    for dim_name, (weight, pattern) in DIMENSIONS.items():
        if re.search(pattern, prompt):
            total_weight += weight
            active_dims.append(dim_name)

    # Context length dimension
    if len(prompt) > 2000:
        total_weight += 0.10
        active_dims.append("long_context")
    if len(prompt) > 8000:
        total_weight += 0.15
        active_dims.append("very_long_context")

    # Nuanced code scoring — adjust weight based on actual code complexity
    if "code" in active_dims:
        boost = _code_complexity_boost(prompt)
        total_weight += boost
        if boost < 0:
            active_dims.append("code_simple")
        elif boost > 0.10:
            active_dims.append("code_complex")

    # Polarize score using sigmoid-like scaling
    # Center around 0.35 threshold
    normalized_score = sigmoid((total_weight - 0.35) * 10)

    # Determine Tier
    # Code alone no longer forces COMPLEX — rely on the scored weight instead
    if normalized_score > 0.85 or "reasoning" in active_dims:
        tier = "REASONING"
    elif normalized_score > 0.60 or "tools" in active_dims or "code_complex" in active_dims:
        tier = "COMPLEX"
    elif normalized_score > 0.30 or "code" in active_dims:
        tier = "MEDIUM"
    else:
        tier = "SIMPLE"

    logger.debug(f"ScoringEngine: {tier} (score: {normalized_score:.2f}, dims: {active_dims})")
    return normalized_score, tier


class ConversationTierTracker:
    """Tracks the rolling complexity tier across a multi-turn conversation.

    Once a conversation escalates to COMPLEX or REASONING, it stays at that
    tier for the remainder of the session to prevent mid-conversation provider
    switches that would break context continuity.

    Args:
        window:  Number of recent turns to consider when computing the
                 rolling tier (default: 5).
    """

    _TIER_RANK = {"SIMPLE": 0, "MEDIUM": 1, "COMPLEX": 2, "REASONING": 3}
    _RANK_TIER = {v: k for k, v in _TIER_RANK.items()}

    def __init__(self, window: int = 5):
        self._window = window
        self._history: list[str] = []  # tier per turn
        self._peak_tier: str = "SIMPLE"  # highest tier seen so far

    def record(self, tier: str) -> None:
        """Record a new turn’s tier."""
        self._history.append(tier)
        if len(self._history) > self._window * 2:
            self._history = self._history[-self._window * 2:]
        # Ratchet up the peak — never go back down
        if self._TIER_RANK.get(tier, 0) > self._TIER_RANK.get(self._peak_tier, 0):
            self._peak_tier = tier

    def effective_tier(self, current_tier: str) -> str:
        """Return the effective routing tier for this turn.

        Rules:
        - Never route below the peak tier seen so far (ratchet up).
        - If the last N turns averaged COMPLEX or above, stay cloud even
          if the current message looks simpler.
        """
        current_rank = self._TIER_RANK.get(current_tier, 0)
        peak_rank = self._TIER_RANK.get(self._peak_tier, 0)

        # Ratchet: if peak is higher, use peak
        effective_rank = max(current_rank, peak_rank)
        return self._RANK_TIER[effective_rank]

    def reset(self) -> None:
        """Reset for a new conversation."""
        self._history.clear()
        self._peak_tier = "SIMPLE"

    @property
    def peak_tier(self) -> str:
        return self._peak_tier


class NeuralFitRanker:
    """
    Integrates the 'llmfit' logic from v3 to rank local models based on the tier.
    """
    @staticmethod
    def get_best_model_for_tier(tier: str, runnable_models: list) -> str:
        """
        Takes the tier and a list of runnable models (from Ollama/local)
        and picks the best fit using NeuralFit composite scoring.
        """
        if not runnable_models:
            return ""

        try:
            from neuralbrok.hardware_scorer import rank_models, detect_system_specs

            # Map tier to NeuralFit use case
            use_case_map = {
                "REASONING": "reasoning",
                "COMPLEX": "coding",
                "MEDIUM": "general",
                "SIMPLE": "chat"
            }
            use_case = use_case_map.get(tier, "general")

            hw = detect_system_specs()
            # Rank models based on composite score (Quality, Speed, Fit, Context)
            ranked_fits = rank_models(hw, use_case=use_case, models=runnable_models)

            if ranked_fits:
                # Prefer models that are actually installed if possible
                installed = [f for f in ranked_fits if f.is_installed]
                if installed:
                    return installed[0].name
                return ranked_fits[0].name

        except ImportError as e:
            logger.warning(f"NeuralFit hardware_scorer not available: {e}. Using fallback ranker.")

        # Fallback if hardware_scorer is missing
        if tier == "REASONING":
            return sorted(runnable_models, key=lambda m: m.params_b, reverse=True)[0].name
        elif tier == "COMPLEX":
            coders = [m for m in runnable_models if "code" in m.name.lower()]
            return coders[0].name if coders else sorted(runnable_models, key=lambda m: m.params_b, reverse=True)[0].name
        elif tier == "MEDIUM":
            mediums = [m for m in runnable_models if 6 <= m.params_b <= 14]
            return mediums[0].name if mediums else runnable_models[0].name
        else:
            smalls = [m for m in runnable_models if m.params_b < 6]
            return smalls[0].name if smalls else sorted(runnable_models, key=lambda m: m.params_b)[0].name
