__version__ = "3.0.2"
__author__ = "NeuralBroker contributors"
