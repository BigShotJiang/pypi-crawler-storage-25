# IDE Integration Guide

NeuralBroker can configure any of 20+ AI coding tools to route through it automatically.

## One-Command Setup

```bash
# Claude Code
neuralbrok setup claude-code

# Cursor
neuralbrok setup cursor

# Codex CLI
neuralbrok setup codex

# Cline (VS Code extension)
neuralbrok setup cline

# All at once (Phase 1 tools)
neuralbrok setup --all
```

After setup, launch the tool with NeuralBroker's environment pre-loaded:
```bash
neuralbrok claude-code    # Launches Claude Code pointed at NeuralBroker
neuralbrok cursor         # Launches Cursor pointed at NeuralBroker
```

---

## What "Setup" Does

Each tool gets:
1. Its config file updated with `base_url = http://localhost:8000/v1`
2. Its default model set to `neuralbroker`
3. (For Claude Code and Cursor) An MCP server entry pointing to `neuralbrok mcp`

---

## Supported Tools

### Phase 1 — Full Config Support

| Tool | Config Written |
|------|---------------|
| Claude Code | `~/.claude/settings.json` + `CLAUDE.md` |
| Cursor | `~/.cursor/mcp.json` + `.env` |
| Cline | `~/.cline/settings.json` |
| GitHub Copilot | `.github/copilot-instructions.md` + `.vscode/settings.json` |
| Gemini CLI | `~/.gemini/settings.json` |
| OpenCode | `opencode.json` |
| Warp | `~/.warp/preferences.yaml` |
| Codex | `.env` + `~/.codex/config.json` |
| Amp | `~/.amp/config.json` |
| Kimi Code | `~/.kimi/config.json` + `.env` |
| Firebender | `~/.firebender/config.json` |
| Deep Agents | `~/.deepagent/config.json` |

### Phase 2 — Skill File Support

These tools are configured via markdown skill files placed in the project directory:

Augment, IBM Bob, OpenClaw, CodeBuddy, Cortex Code, Kilo Code, Kiro CLI, Kode, Qwen Code, Trae, Windsurf

---

## Manual Configuration

If your tool isn't in the list, configure it manually:

```
Base URL:  http://localhost:8000/v1
API Key:   nb-local   (or set NB_API_KEY to anything)
Model:     neuralbroker
```

For Claude-format APIs (Anthropic protocol):
```
Base URL:  http://localhost:8000
API Key:   nb-local
```

---

## MCP Integration

Claude Code and Cursor support MCP servers. NeuralBroker includes one:

```bash
neuralbrok mcp    # Starts MCP server on stdio
```

The MCP server exposes:
- **`nb_route_preview`** — Analyse a prompt and see its routing tier before sending
- **`nb_get_active_auth`** — List all discovered subscriptions (Claude Pro, Codex, etc.)

Claude Code picks this up automatically after `neuralbrok setup claude-code`.

---

## Environment Variables

| Variable | Effect |
|----------|--------|
| `NB_API_KEY` | Require this key on all requests (disabled = open) |
| `NB_URL` | Override gateway URL (default: `http://localhost:8000`) |
| `NB_DISABLE_AUTO_DISCOVERY` | Set to `1` to skip subscription scanning |
| `ANTHROPIC_BASE_URL` | Redirect Claude tools to NeuralBroker |
| `OPENAI_API_BASE` | Redirect OpenAI-compatible tools to NeuralBroker |

---

## Check Integration Status

```bash
neuralbrok status          # Shows which integrations are active
curl http://localhost:8000/nb/discovered   # Shows discovered subscriptions
curl http://localhost:8000/nb/providers    # Shows all registered providers
```
