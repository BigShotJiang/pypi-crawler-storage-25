# NeuralBroker — Architecture Overview

## What NeuralBroker Is

NeuralBroker is a **local-first LLM routing daemon**. It runs on your machine, exposes a single OpenAI-compatible HTTP endpoint, and intelligently dispatches every request to the best available backend — local GPU, existing subscription, or API fallback — without you ever needing to think about it.

It is **not** a model itself. It is a router that pretends to be a model.

---

## Core Concepts

### The Virtual Model

NeuralBroker registers a virtual model name called `neuralbroker` (and `auto`) in the `/v1/models` endpoint. When any compatible tool sets `model=neuralbroker`, the request is intercepted and classified internally before being dispatched.

The client never sees the real backend unless they check the `X-NB-Backend` response header.

### Routing Pipeline

Every request goes through this pipeline in under 2ms:

```
Incoming Request (model=neuralbroker)
        │
        ▼
┌─── 15-Dimension Scorer ──────────────────────────────────────┐
│  Analyses: code, reasoning, math, tools, creative, context   │
│  Output: score (0.0–1.0) + tier (SIMPLE/MEDIUM/COMPLEX/      │
│          REASONING)                                           │
└──────────────────────────────────────────────────────────────┘
        │
        ▼
┌─── NeuralFit Hardware Ranker ────────────────────────────────┐
│  Input: tier, available local models, VRAM, bandwidth        │
│  Output: best local model name (or "none" if no fit)         │
└──────────────────────────────────────────────────────────────┘
        │
        ├── SIMPLE / MEDIUM + local model fits VRAM
        │     └─→ Local Ollama / llama.cpp  [cost: $0]
        │
        ├── COMPLEX / REASONING, or local doesn't fit
        │     └─→ Discovered subscription  [cost: $0 marginal]
        │           (Claude Pro, Codex, ChatGPT Plus)
        │
        └── No subscription found
              └─→ Cheapest configured API key
                   (Groq → Together → OpenAI → Anthropic)
```

---

## The 15-Dimension Scoring Engine

Located in `src/neuralbrok/scoring_engine.py`.

Each dimension is a weighted signal extracted via regex in <0.1ms:

| Dim | Signal | Example trigger |
|-----|--------|-----------------|
| 1 | Code blocks / function keywords | `def foo():`, ` ```python` |
| 2 | Mathematical notation | `∑`, `∫`, `prove that` |
| 3 | Multi-step reasoning markers | `step by step`, `therefore` |
| 4 | Tool/API usage patterns | `curl`, `import`, `API` |
| 5 | Creative writing | `story`, `poem`, `write a` |
| 6 | Data analysis | `dataset`, `CSV`, `analyse` |
| 7 | System/infra commands | `docker`, `kubectl`, `bash` |
| 8 | Security-sensitive | `password`, `exploit`, `CVE` |
| 9 | Long-form generation | 500+ word request |
| 10 | Multi-document context | multiple file paths |
| 11 | Debugging complexity | `traceback`, `error`, `bug` |
| 12 | Architectural decisions | `design`, `scalable`, `trade-off` |
| 13 | Conversational simplicity | short, no technical terms |
| 14 | Factual lookup | "what is", "who is", "when did" |
| 15 | Prompt length | total character count |

**Tier thresholds:**
- `score < 0.10` → `SIMPLE`
- `0.10 ≤ score < 0.25` → `MEDIUM`  
- `0.25 ≤ score < 0.50` → `COMPLEX`
- `score ≥ 0.50` → `REASONING`

---

## NeuralFit Hardware Ranker

Located in `src/neuralbrok/hardware_scorer.py`.

Given a task tier and a list of locally-available models, NeuralFit scores each candidate on a composite of:

- **Quality score** — Intelligence benchmark proxy (MMLU, HumanEval, etc.)
- **Speed score** — Estimated tokens/sec given VRAM bandwidth
- **VRAM fit score** — How cleanly the model fits in available VRAM (penalises near-overflow and wasted headroom)
- **Context fit score** — Whether the model's context window matches the prompt length

The highest-scoring installed model wins.

---

## Subscription Inheritance

At startup, `auth_discovery.py` scans known auth locations:

| Provider | Location scanned |
|----------|-----------------|
| Claude Pro | `~/.claude/.credentials.json` |
| Claude API key | `ANTHROPIC_API_KEY` env var |
| OpenAI / Codex | `~/.codex/auth.json`, `OPENAI_API_KEY` |
| GitHub Copilot | `~/.config/github-copilot/hosts.json` |
| Local Ollama | `http://localhost:11434` ping |
| Local llama.cpp | `http://localhost:8080` ping |

Discovered subscriptions are registered as providers with **cost = 0.0**, so the cost-aware router always prefers them over paid API keys for high-tier tasks.

---

## MCP Server

`neuralbrok mcp` launches an MCP server over stdio. This allows Claude Code and Cursor to query NeuralBroker's routing intelligence directly as a native tool.

**Registered tools:**

| Tool | Description |
|------|-------------|
| `nb_route_preview` | Returns the tier and score for any prompt without executing it |
| `nb_get_active_auth` | Returns all discovered subscriptions and their sources |

**Claude Code integration** (auto-configured via `neuralbrok setup claude-code`):

```json
{
  "mcpServers": {
    "neuralbroker": {
      "command": "neuralbrok",
      "args": ["mcp"]
    }
  }
}
```

---

## File Map

```
src/neuralbrok/
├── main.py              ← FastAPI app, all HTTP endpoints, provider registration
├── router.py            ← PolicyEngine: decide_async(), decide(), scoring integration
├── scoring_engine.py    ← 15-dim prompt classifier + NeuralFitRanker
├── hardware_scorer.py   ← NeuralFit composite model scorer
├── auth_discovery.py    ← Subscription discovery (Claude, Codex, Ollama, etc.)
├── mcp_server.py        ← MCP stdio server (nb_route_preview, nb_get_active_auth)
├── cli.py               ← Click CLI (setup, start, status, models, mcp, integrations)
├── config.py            ← Config schema (YAML parser)
├── detect.py            ← Hardware detection (GPU, VRAM, RAM, bandwidth)
├── models.py            ← Model catalogue + get_runnable_models()
├── telemetry.py         ← VramPoller background thread
├── metrics.py           ← Prometheus metrics
├── providers/           ← Per-provider HTTP clients (Ollama, Groq, Anthropic, etc.)
└── integrations/
    └── agents.py        ← IDE integration setup functions (20+ tools)
```

---

## Routing Modes

Set via `neuralbrok start --mode <mode>` or `POST /nb/mode`:

| Mode | Logic |
|------|-------|
| `smart` | 15-dim scoring decides per-request (default) |
| `cost` | Sort providers by cost_per_1k ascending |
| `speed` | Sort providers by average latency ascending |
| `fallback` | Local first; cloud only on failure or VRAM overflow |
