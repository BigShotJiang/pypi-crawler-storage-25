# Subscription Inheritance Guide

NeuralBroker's subscription inheritance feature lets you use your existing paid AI subscriptions across any tool — without paying per-token API fees for those models.

## How It Works

At startup, NeuralBroker scans your machine for existing auth sessions and API keys. When found, it registers them as providers with **zero marginal cost**, meaning the routing engine will prefer them over paid API calls for expensive tasks.

```
You pay $20/mo for Claude Pro
  └→ NeuralBroker discovers your Claude Code session
  └→ Registers it as cost=0.00
  └→ Routes all COMPLEX/REASONING tasks through it
  └→ Result: your coding tools get Claude Sonnet for free
```

---

## What Gets Discovered

| Source | Location | Auth Type |
|--------|----------|-----------|
| **Claude Pro/Max** | `~/.claude/.credentials.json` | OAuth bearer (Claude Code session) |
| **Claude API Key** | `ANTHROPIC_API_KEY` env var | API key |
| **OpenAI / Codex** | `OPENAI_API_KEY` env var | API key |
| **Codex CLI** | `~/.codex/auth.json` | OAuth / API key |
| **GitHub Copilot** | `~/.config/github-copilot/hosts.json` | OAuth token |
| **Local Ollama** | `http://localhost:11434` | None (local) |
| **Local llama.cpp** | `http://localhost:8080` | None (local) |

---

## Claude Pro / Max

When Claude Code is installed and authenticated, NeuralBroker discovers the OAuth session in `~/.claude/.credentials.json`.

Because the Anthropic API doesn't accept OAuth tokens directly, NeuralBroker uses the **`claude` CLI as a subprocess provider** — it shells out to `claude` (which carries your session) and parses the output. This means:

- **No API key required**
- **Uses your subscription tier** (Sonnet 4.5 for Pro, Opus for Max)
- **No additional usage charges**

> ⚠️ This is intended for personal use. Routing third-party API traffic through a personal subscription may violate Anthropic's Terms of Service. Use this for your own tools only.

---

## OpenAI / Codex

If `OPENAI_API_KEY` is set, or if the Codex CLI stores auth in `~/.codex/auth.json`, NeuralBroker registers it as the `openai` provider with cost tracked from your configured rate.

---

## Viewing Discovered Providers

```bash
# Via CLI
neuralbrok status

# Via API
curl http://localhost:8000/nb/discovered
```

Example response:
```json
{
  "providers": {
    "claude_code": {
      "auth_type": "oauth_bearer",
      "source": "~/.claude/.credentials.json",
      "subscription": "pro",
      "registered": true
    },
    "ollama": {
      "auth_type": "local",
      "source": "localhost:11434",
      "subscription": null,
      "registered": true
    }
  }
}
```

---

## Via MCP

If using Claude Code with MCP integration active, you can ask NeuralBroker what it found:

```
Use the nb_get_active_auth tool
```

Claude Code will call the tool and show you which subscriptions are active.

---

## Disabling Discovery

```bash
NB_DISABLE_AUTO_DISCOVERY=1 neuralbrok start
```

Or in your `~/.neuralbrok/config.yaml`:
```yaml
routing:
  disable_auto_discovery: true
```

---

## Privacy

NeuralBroker **never exfiltrates your tokens**. Auth is discovered locally, used to make API calls directly from your machine, and never logged or transmitted. The `nb/discovered` endpoint only returns metadata (source path, auth type, subscription tier) — never the raw token value.
