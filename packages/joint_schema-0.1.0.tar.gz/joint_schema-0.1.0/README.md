# joint-schema

Multi-domain military operations schema covering three integrated knowledge domains:

| Domain | Description |
|--------|-------------|
| **MIM** | Military Information Model — operational concepts, units, tasks, effects |
| **DISARM** | Influence operation Tactics, Techniques & Procedures (TTPs) |
| **STIX** | Cyber threat intelligence objects bridged from STIX 2.1 |

## Directory structure

```
joint-schema/
├── schema/
│   ├── core/       # Shared base classes, common types, enumerations
│   ├── mim/        # MIM operational concept schemas (LinkML YAML)
│   ├── disarm/     # DISARM TTP schemas (LinkML YAML)
│   └── bridge/     # Cross-domain linkage / alignment schemas
├── generated/      # Auto-generated artifacts (JSON Schema, Pydantic, OWL, …)
├── llm-context/    # Bundled context files for LLM tooling
├── docs/           # Documentation source and build output
└── tests/          # Schema validation and integration tests
```

## Quickstart

```bash
# Python toolchain
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Node toolchain (DOCX generation)
npm install

# Run tests
pytest
```

## Generating artifacts

```bash
# JSON Schema from a LinkML source file
gen-json-schema schema/core/core.yaml > generated/core.schema.json

# Pydantic models
gen-pydantic schema/core/core.yaml > generated/core_models.py
```
