"""
Tests for schema/core/platforms.yaml — platform hierarchy and EW capability stubs.

Generated models: generated/python/core__platforms_models.py
"""
import pytest
from datetime import datetime, timezone
from pydantic import ValidationError

from core__platforms_models import (
    AircraftType,
    GroundPlatformType,
    CyberNodeType,
    PlatformStatus,
    SignalModality,
    SpectrumUsePurpose,
    CapabilityStatus,
    AirPlatform,
    GroundPlatform,
    NavalPlatform,
    CyberNode,
    EmitterCapability,
    ReceiverCapability,
    Timestamp,
)

# ── Helpers ────────────────────────────────────────────────────────────────────

NOW = datetime(2024, 6, 15, 10, 30, 0, tzinfo=timezone.utc)

def ts() -> Timestamp:
    return Timestamp(datetime_value=NOW)


# ── Test 1: AirPlatform with EmitterCapability (EW radar stub) ────────────────

def test_air_platform_with_emitter_capability():
    """AirPlatform carrying an EmitterCapability (radar stub) validates correctly."""
    radar = EmitterCapability(
        capability_name="AN/APG-81 AESA Radar",
        capability_status=CapabilityStatus.OPERATIONAL,
        frequency_min_mhz=8000.0,
        frequency_max_mhz=12000.0,
        peak_power_watts=10_000.0,
        signal_modality=[SignalModality.PULSE_DOPPLER, SignalModality.LFM],
        spectrum_use_purpose=[SpectrumUsePurpose.RADAR],
    )
    aircraft = AirPlatform(
        id="jsc:platform/f35a-tail-001",
        name="F-35A (Tail 001)",
        aircraft_type=AircraftType.FIXED_WING,
        icao_designator="F35",
        operator_id="jsc:unit/56-fighter-wing",
        location_id="jsc:point/bagram-ramp-alpha",
        capabilities=[radar],
        platform_status=PlatformStatus.ACTIVE,
        observed_at=ts(),
    )

    assert aircraft.aircraft_type == AircraftType.FIXED_WING
    assert aircraft.icao_designator == "F35"
    assert len(aircraft.capabilities) == 1

    cap = aircraft.capabilities[0]
    assert cap.capability_name == "AN/APG-81 AESA Radar"
    assert cap.frequency_min_mhz == pytest.approx(8000.0)
    assert cap.peak_power_watts  == pytest.approx(10_000.0)
    assert SignalModality.PULSE_DOPPLER in cap.signal_modality


def test_air_platform_requires_id_and_name():
    """AirPlatform without id or name must fail validation."""
    with pytest.raises(ValidationError):
        AirPlatform()


def test_air_platform_with_receiver_capability():
    """AirPlatform with a ReceiverCapability (RWR stub) validates correctly."""
    rwr = ReceiverCapability(
        capability_name="AN/ALR-94 Radar Warning Receiver",
        capability_status=CapabilityStatus.OPERATIONAL,
        frequency_min_mhz=500.0,
        frequency_max_mhz=18_000.0,
        sensitivity_dbm=-105.0,
        signal_modality=[SignalModality.PULSED, SignalModality.CW],
        spectrum_use_purpose=[SpectrumUsePurpose.ELECTRONIC_WARFARE_SUPPORT],
    )
    aircraft = AirPlatform(
        id="jsc:platform/f22-tail-002",
        name="F-22A (Tail 002)",
        aircraft_type=AircraftType.FIXED_WING,
        capabilities=[rwr],
    )

    cap = aircraft.capabilities[0]
    assert cap.sensitivity_dbm == pytest.approx(-105.0)
    assert SpectrumUsePurpose.ELECTRONIC_WARFARE_SUPPORT in cap.spectrum_use_purpose


# ── Test 2: GroundPlatform — ELECTRONIC_WARFARE_VEHICLE ───────────────────────

def test_ground_platform_ew_vehicle_with_emitter():
    """GroundPlatform of type EW_VEHICLE carrying a jammer EmitterCapability."""
    jammer = EmitterCapability(
        capability_name="Krasukha-4 EW Jammer",
        capability_status=CapabilityStatus.OPERATIONAL,
        frequency_min_mhz=1000.0,
        frequency_max_mhz=18_000.0,
        peak_power_watts=200_000.0,
        spectrum_use_purpose=[SpectrumUsePurpose.ELECTRONIC_WARFARE_JAMMING],
    )
    vehicle = GroundPlatform(
        id="jsc:platform/krasukha-001",
        name="Krasukha-4 (Unit 001)",
        ground_platform_type=GroundPlatformType.ELECTRONIC_WARFARE_VEHICLE,
        operator_id="jsc:unit/ru-ew-bde",
        capabilities=[jammer],
        platform_status=PlatformStatus.ACTIVE,
    )

    assert vehicle.ground_platform_type == GroundPlatformType.ELECTRONIC_WARFARE_VEHICLE
    assert vehicle.capabilities[0].peak_power_watts == pytest.approx(200_000.0)


def test_ground_platform_status_defaults():
    """Platform without platform_status gets UNKNOWN by default."""
    vehicle = GroundPlatform(
        id="jsc:platform/t90-001",
        name="T-90M (001)",
        ground_platform_type=GroundPlatformType.MAIN_BATTLE_TANK,
    )

    assert vehicle.platform_status == PlatformStatus.UNKNOWN
    assert vehicle.capabilities    is None


def test_ground_platform_frequency_bounds_enforced():
    """EmitterCapability frequency values must be >= 0."""
    with pytest.raises(ValidationError):
        EmitterCapability(
            capability_name="Bad Emitter",
            frequency_min_mhz=-100.0,  # invalid: negative frequency
        )


# ── Test 3: CyberNode — adversary C2 infrastructure ──────────────────────────

def test_cyber_node_c2_server():
    """CyberNode of type C2_SERVER with IP addresses and ASN is valid."""
    node = CyberNode(
        id="jsc:platform/c2-server-001",
        name="C2 Server — OPERATION PHANTOM",
        node_type=CyberNodeType.C2_SERVER,
        ip_addresses=["185.220.101.45", "185.220.101.46"],
        domain_names=["update.software-patch.net", "cdn.news-service.org"],
        autonomous_system_number=209588,
        operator_id="jsc:actor/apt-x",
        location_id="jsc:area/asn-209588",
        platform_status=PlatformStatus.ACTIVE,
        tags=["C2", "APT-X", "OPERATION-PHANTOM"],
    )

    assert node.node_type == CyberNodeType.C2_SERVER
    assert "185.220.101.45"          in node.ip_addresses
    assert "update.software-patch.net" in node.domain_names
    assert node.autonomous_system_number == 209588


def test_cyber_node_botnet_node():
    """CyberNode of type BOTNET_NODE (compromised host) is valid."""
    node = CyberNode(
        id="jsc:platform/zombie-001",
        name="Compromised Workstation — Victim Corp",
        node_type=CyberNodeType.BOTNET_NODE,
        ip_addresses=["203.0.113.47"],
        hostname="WORKSTATION-CORP-07",
    )

    assert node.node_type == CyberNodeType.BOTNET_NODE
    assert node.hostname  == "WORKSTATION-CORP-07"


def test_cyber_node_external_references():
    """Platform external_references (EW stub) accepts a list of typed refs."""
    from core__platforms_models import ExternalReference, ExternalReferenceType

    ref = ExternalReference(
        external_ref_type=ExternalReferenceType.STIX,
        source_name="STIX Bundle — APT-X Infrastructure",
        source_id="bundle--12345678-0000-0000-0000-123456789abc",
    )
    node = CyberNode(
        id="jsc:platform/c2-server-002",
        name="C2 Server 002",
        node_type=CyberNodeType.C2_SERVER,
        external_references=[ref],
    )

    assert len(node.external_references) == 1
    assert node.external_references[0].external_ref_type == ExternalReferenceType.STIX
