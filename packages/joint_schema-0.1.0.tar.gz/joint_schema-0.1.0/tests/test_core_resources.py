"""
Tests for schema/core/resources.yaml — resource types and SpectrumResource stub.

Generated models: generated/python/core__resources_models.py
"""
import pytest
from pydantic import ValidationError

from core__resources_models import (
    ResourceType,
    Resource,
    SpectrumResource,
)


# ── Test 1: SpectrumResource — EW/spectrum stub ───────────────────────────────

def test_spectrum_resource_frequency_band():
    """SpectrumResource with frequency start/end and bandwidth is valid."""
    resource = SpectrumResource(
        id="jsc:resource/spectrum-vhf-tactical",
        name="VHF Tactical Comms Band — 3rd Brigade",
        resource_type=ResourceType.SPECTRUM,
        frequency_start_mhz=30.0,
        frequency_end_mhz=88.0,
        bandwidth_mhz=58.0,
        owner_id="jsc:unit/3-abct-s6",
        spectrum_resource_notes=(
            "Assigned by JFAC frequency management cell. "
            "Deconflicted with adjacent unit VHF at freq plan version 4."
        ),
    )

    assert resource.resource_type     == ResourceType.SPECTRUM
    assert resource.frequency_start_mhz == pytest.approx(30.0)
    assert resource.frequency_end_mhz   == pytest.approx(88.0)
    assert resource.bandwidth_mhz       == pytest.approx(58.0)
    assert resource.owner_id            == "jsc:unit/3-abct-s6"


def test_spectrum_resource_negative_frequency_rejected():
    """Frequency values must be >= 0; negative values must fail validation."""
    with pytest.raises(ValidationError):
        SpectrumResource(
            id="jsc:resource/x",
            name="Invalid",
            resource_type=ResourceType.SPECTRUM,
            frequency_start_mhz=-1.0,  # invalid
        )


def test_spectrum_resource_x_band_radar():
    """High-frequency X-band radar allocation is valid."""
    resource = SpectrumResource(
        id="jsc:resource/spectrum-xband-fire-control",
        name="X-Band Fire Control Allocation — Site BRAVO",
        resource_type=ResourceType.SPECTRUM,
        frequency_start_mhz=8_500.0,
        frequency_end_mhz=10_500.0,
        bandwidth_mhz=2_000.0,
        location_id="jsc:point/fire-control-site-bravo",
        confidence=90,
    )

    assert resource.frequency_start_mhz == pytest.approx(8_500.0)
    assert resource.bandwidth_mhz       == pytest.approx(2_000.0)
    assert resource.location_id         == "jsc:point/fire-control-site-bravo"


# ── Test 2: Resource base class requirements ──────────────────────────────────

def test_resource_requires_id_name_type():
    """Resource without id, name, or resource_type must fail validation."""
    # Missing all three required fields
    with pytest.raises(ValidationError) as exc_info:
        SpectrumResource()
    errors   = exc_info.value.errors()
    fields   = {e["loc"][0] for e in errors}
    assert "id"            in fields
    assert "name"          in fields
    assert "resource_type" in fields


def test_resource_type_enum_values():
    """ResourceType enum covers SPECTRUM, BANDWIDTH, CYBERSPACE, AIRSPACE."""
    assert ResourceType.SPECTRUM   == ResourceType("SPECTRUM")
    assert ResourceType.BANDWIDTH  == ResourceType("BANDWIDTH")
    assert ResourceType.CYBERSPACE == ResourceType("CYBERSPACE")
    assert ResourceType.AIRSPACE   == ResourceType("AIRSPACE")


def test_spectrum_resource_with_tags_and_marking():
    """SpectrumResource with classification_marking and tags is valid."""
    resource = SpectrumResource(
        id="jsc:resource/spectrum-classified",
        name="EW Support Band — CLASSIFIED",
        resource_type=ResourceType.SPECTRUM,
        frequency_start_mhz=500.0,
        frequency_end_mhz=18_000.0,
        classification_marking="SECRET//NOFORN",
        tags=["EW", "SIGINT", "WIDEBAND"],
        source_refs=["JFAC-FREQ-PLAN-2024-Q3"],
    )

    assert resource.classification_marking == "SECRET//NOFORN"
    assert "EW" in resource.tags
    assert "JFAC-FREQ-PLAN-2024-Q3" in resource.source_refs


# ── Test 3: Cyberspace and other non-spectrum resource types ──────────────────

def test_cyberspace_resource():
    """SpectrumResource with CYBERSPACE type models an IP address block."""
    resource = SpectrumResource(
        id="jsc:resource/ip-block-001",
        name="IP Address Block — Adversary ASN",
        resource_type=ResourceType.CYBERSPACE,
        spectrum_resource_notes="BGP prefix 185.220.101.0/24 under adversary control",
        owner_id="jsc:actor/apt-x",
    )

    assert resource.resource_type == ResourceType.CYBERSPACE
    assert "185.220.101.0/24"     in resource.spectrum_resource_notes


def test_bandwidth_resource():
    """SpectrumResource with BANDWIDTH type models a satellite transponder."""
    resource = SpectrumResource(
        id="jsc:resource/satcom-transponder-001",
        name="Ka-band SATCOM Transponder — MILSATCOM-1",
        resource_type=ResourceType.BANDWIDTH,
        frequency_start_mhz=26_500.0,
        frequency_end_mhz=40_000.0,
        bandwidth_mhz=500.0,
        spectrum_resource_notes="Uplink Ka-band, 500 MHz transponder, priority 1 allocation",
    )

    assert resource.resource_type       == ResourceType.BANDWIDTH
    assert resource.frequency_start_mhz == pytest.approx(26_500.0)


def test_resource_confidence_bounds():
    """Resource confidence must be in [0, 100]."""
    lo = SpectrumResource(
        id="jsc:r/a", name="A", resource_type=ResourceType.SPECTRUM, confidence=0
    )
    hi = SpectrumResource(
        id="jsc:r/b", name="B", resource_type=ResourceType.SPECTRUM, confidence=100
    )
    assert lo.confidence == 0
    assert hi.confidence == 100

    with pytest.raises(ValidationError):
        SpectrumResource(
            id="jsc:r/c", name="C", resource_type=ResourceType.SPECTRUM, confidence=101
        )
