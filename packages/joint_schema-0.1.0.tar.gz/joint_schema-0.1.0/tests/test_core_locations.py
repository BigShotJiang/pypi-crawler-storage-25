"""
Tests for schema/core/locations.yaml — geographic location types.

Generated models: generated/python/core__locations_models.py
"""
import pytest
from pydantic import ValidationError

from core__locations_models import (
    CoordinateReferenceSystem,
    NamedAreaType,
    ControlMeasureType,
    CoverageType,
    Point,
    Region,
    NamedArea,
    ControlMeasure,
    CoverageArea,
    Timestamp,
)
from datetime import datetime, timezone

# ── Test 1: Point — coordinate representations ────────────────────────────────

def test_point_wgs84_lat_lon():
    """Point with WGS84 lat/lon is valid; defaults to WGS84 CRS."""
    p = Point(
        id="jsc:point/kyiv-centre",
        name="Kyiv City Centre",
        latitude=50.4501,
        longitude=30.5234,
    )

    assert p.latitude  == pytest.approx(50.4501)
    assert p.longitude == pytest.approx(30.5234)
    assert p.altitude_m is None
    # Default CRS from ifabsent
    assert p.coordinate_reference_system == CoordinateReferenceSystem.WGS84


def test_point_mgrs_with_altitude():
    """Point with MGRS string and altitude is valid."""
    p = Point(
        id="jsc:point/grid-ref-001",
        name="MGRS Grid Reference",
        mgrs="37UDB12345678",
        altitude_m=120.5,
        coordinate_reference_system=CoordinateReferenceSystem.MGRS,
    )

    assert p.mgrs == "37UDB12345678"
    assert p.altitude_m == pytest.approx(120.5)
    assert p.coordinate_reference_system == CoordinateReferenceSystem.MGRS


def test_point_latitude_bounds_enforced():
    """Latitude outside [-90, 90] must raise a ValidationError."""
    with pytest.raises(ValidationError):
        Point(id="jsc:p/bad", name="bad", latitude=91.0, longitude=0.0)
    with pytest.raises(ValidationError):
        Point(id="jsc:p/bad", name="bad", latitude=-91.0, longitude=0.0)


def test_point_longitude_bounds_enforced():
    """Longitude outside [-180, 180] must raise a ValidationError."""
    with pytest.raises(ValidationError):
        Point(id="jsc:p/bad", name="bad", latitude=0.0, longitude=181.0)
    with pytest.raises(ValidationError):
        Point(id="jsc:p/bad", name="bad", latitude=0.0, longitude=-181.0)


# ── Test 2: NamedArea — administrative and operational areas ──────────────────

def test_named_area_country_with_iso_code():
    """NamedArea for a COUNTRY with ISO 3166-1 alpha-2 code is valid."""
    area = NamedArea(
        id="jsc:area/ukraine",
        name="Ukraine",
        named_area_type=NamedAreaType.COUNTRY,
        iso_3166_code="UA",
    )

    assert area.named_area_type == NamedAreaType.COUNTRY
    assert area.iso_3166_code   == "UA"
    assert area.geometry        is None
    assert area.parent_area_id  is None


def test_named_area_joint_operations_area():
    """NamedArea for a JOA with parent linkage to theatre is valid."""
    area = NamedArea(
        id="jsc:area/joa-alpha",
        name="JOA ALPHA",
        named_area_type=NamedAreaType.JOINT_OPERATIONS_AREA,
        parent_area_id="jsc:area/theatre-east",
        description="Joint Operations Area designated per JFC order 24-003",
    )

    assert area.named_area_type == NamedAreaType.JOINT_OPERATIONS_AREA
    assert area.parent_area_id  == "jsc:area/theatre-east"


def test_named_area_requires_named_area_type():
    """NamedArea without named_area_type must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        NamedArea(id="jsc:area/x", name="Unknown Area")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "named_area_type" in fields


def test_named_area_cyberspace_region():
    """NamedArea of type CYBERSPACE_REGION is valid (logical, non-geographic)."""
    area = NamedArea(
        id="jsc:area/asn-12345",
        name="ASN 12345 — RU Telecom",
        named_area_type=NamedAreaType.CYBERSPACE_REGION,
        description="Autonomous System 12345 operated by a Russian state ISP",
    )

    assert area.named_area_type == NamedAreaType.CYBERSPACE_REGION


# ── Test 3: ControlMeasure — military graphic control measures ────────────────

def test_control_measure_phase_line_requires_type():
    """ControlMeasure without control_measure_type must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ControlMeasure(id="jsc:cm/pl-green", name="Phase Line GREEN")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "control_measure_type" in fields


def test_control_measure_no_fire_area_with_validity_window():
    """NFA with effective_from and effective_until timestamps is valid."""
    t_start = Timestamp(datetime_value=datetime(2024, 6, 1,  6, 0, 0, tzinfo=timezone.utc))
    t_end   = Timestamp(datetime_value=datetime(2024, 6, 1, 18, 0, 0, tzinfo=timezone.utc))

    nfa = ControlMeasure(
        id="jsc:cm/nfa-hospital",
        name="NFA HOSPITAL",
        control_measure_type=ControlMeasureType.NO_FIRE_AREA,
        effective_from=t_start,
        effective_until=t_end,
        controlling_unit_id="jsc:unit/1-corps-fires",
        display_symbol="GFGPGAA---",
    )

    assert nfa.control_measure_type  == ControlMeasureType.NO_FIRE_AREA
    assert nfa.effective_from.datetime_value.hour  == 6
    assert nfa.effective_until.datetime_value.hour == 18
    assert nfa.display_symbol == "GFGPGAA---"


def test_control_measure_phase_line_minimal():
    """ControlMeasure with only required fields (id, name, type) is valid."""
    pl = ControlMeasure(
        id="jsc:cm/pl-green",
        name="Phase Line GREEN",
        control_measure_type=ControlMeasureType.PHASE_LINE,
    )

    assert pl.control_measure_type == ControlMeasureType.PHASE_LINE
    assert pl.geometry              is None
    assert pl.controlling_unit_id   is None


# ── Test 4: CoverageArea — EW/spectrum stub ───────────────────────────────────

def test_coverage_area_radar_stub():
    """CoverageArea (EW stub) with coverage_type RADAR_COVERAGE is valid."""
    ca = CoverageArea(
        id="jsc:coverage/spa-6-radar",
        name="Patriot Radar Coverage — SITE ALPHA",
        coverage_type=CoverageType.RADAR_COVERAGE,
        coverage_frequency_range_description="8–12 GHz X-band fire control",
    )

    assert ca.coverage_type == CoverageType.RADAR_COVERAGE
    assert "X-band" in ca.coverage_frequency_range_description


def test_coverage_area_requires_coverage_type():
    """CoverageArea without coverage_type must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        CoverageArea(id="jsc:coverage/x", name="Unknown Coverage")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "coverage_type" in fields
