"""
Tests for schema/core/plans.yaml — operational plan lifecycle, conditions,
phases, force requirements, decision points, and plan execution bridge.

Generated models: generated/python/core__plans_models.py
"""
import pytest
from datetime import datetime, timezone
from pydantic import ValidationError

from core__plans_models import (
    PlanStatus,
    ConditionStatus,
    ForceSize,
    ExecutionStatus,
    MoeType,
    Condition,
    PlanPhase,
    ForceRequirement,
    PlannedTask,
    DecisionPoint,
    PlanBranch,
    MeasureOfEffectiveness,
    OperationPlan,
    ContingencyPlan,
    BranchPlan,
    PlanExecution,
    RoleAssignment,
    ConditionEvaluation,
    Timestamp,
)

# ── Helpers ────────────────────────────────────────────────────────────────────

H_HOUR = datetime(2024, 6, 20,  4, 0, 0, tzinfo=timezone.utc)
H_PLUS_6 = datetime(2024, 6, 20, 10, 0, 0, tzinfo=timezone.utc)
D_PLUS_1  = datetime(2024, 6, 21,  4, 0, 0, tzinfo=timezone.utc)

def ts(dt: datetime = H_HOUR) -> Timestamp:
    return Timestamp(datetime_value=dt)


def make_condition(cid: str, indicator: str) -> Condition:
    return Condition(
        id=cid,
        name=f"Condition {cid.split('/')[-1].upper()}",
        observable_indicator=indicator,
        evaluation_authority_id="jsc:unit/corps-g3",
    )


def make_force_req(role: str, size: ForceSize = ForceSize.COMPANY) -> ForceRequirement:
    return ForceRequirement(
        force_requirement_role=role,
        force_size=size,
        required_capabilities=["Direct fire suppression", "Armoured mobility"],
    )


# ── Test 1: OperationPlan — full OPLAN with phases, conditions, tasks ──────────

def test_operation_plan_with_two_phases():
    """OperationPlan with conditions, phases, and planned tasks validates correctly."""
    # Define observable conditions
    cond_phase1_entry = make_condition(
        "jsc:cond/abn-complete",
        "Lead elements of TF 3-69 AR cross Phase Line AMBER",
    )
    cond_phase1_exit = make_condition(
        "jsc:cond/obj-seized",
        "Objective IRON seized and held; OPFOR armour in zone < 30% start strength",
    )

    # Phase 1 task
    task_assault = PlannedTask(
        id="jsc:task/assault-obj-iron",
        name="Assault and Seize Objective IRON",
        force_requirements=[make_force_req("Lead assault element", ForceSize.COMPANY)],
        location_id="jsc:point/obj-iron",
        task_priority=1,
        task_start_condition_id="jsc:cond/abn-complete",
    )

    # Phase 1 with MOE
    moe_kinetic = MeasureOfEffectiveness(
        moe_indicator="OPFOR armour strength in zone < 30% of start state by BDA",
        moe_target="< 30%",
        moe_type=MoeType.KINETIC,
        assessment_method="SIGINT-confirmed BDA via theatre ISR",
    )
    phase1 = PlanPhase(
        id="jsc:phase/p1-deliberate-attack",
        name="Phase 1 — Deliberate Attack",
        phase_sequence=1,
        h_hour_offset="H-Hour",
        relative_duration="PT18H",
        entry_conditions=["jsc:cond/abn-complete"],
        exit_conditions=["jsc:cond/obj-seized"],
        phase_tasks=["jsc:task/assault-obj-iron"],
        phase_moes=[moe_kinetic],
    )

    # Build the OPLAN
    oplan = OperationPlan(
        id="jsc:plan/oplan-24-001",
        name="OPLAN 24-001 IRON THUNDER",
        plan_status=PlanStatus.APPROVED,
        plan_version="v1.3",
        operation_order_number="OPORD 24-001",
        approval_authority_id="jsc:unit/3-id-cg",
        conditions=[cond_phase1_entry, cond_phase1_exit],
        phases=[phase1],
        planned_tasks=[task_assault],
        classification_marking="SECRET",
        confidence=95,
    )

    assert oplan.plan_status          == PlanStatus.APPROVED
    assert oplan.operation_order_number == "OPORD 24-001"
    assert len(oplan.conditions)      == 2
    assert len(oplan.phases)          == 1
    assert len(oplan.planned_tasks)   == 1

    p1 = oplan.phases[0]
    assert p1.phase_sequence          == 1
    assert p1.relative_duration       == "PT18H"
    assert "jsc:cond/abn-complete"    in p1.entry_conditions
    assert p1.phase_moes[0].moe_type  == MoeType.KINETIC


def test_operation_plan_requires_id_name_status():
    """OperationPlan without id, name, or plan_status must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        OperationPlan()
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "id"          in fields
    assert "name"        in fields
    assert "plan_status" in fields


# ── Test 2: Condition and DecisionPoint branching structure ───────────────────

def test_condition_requires_observable_indicator_and_authority():
    """Condition without observable_indicator or evaluation_authority_id must fail."""
    with pytest.raises(ValidationError) as exc_info:
        Condition(id="jsc:cond/x", name="Incomplete Condition")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "observable_indicator"    in fields
    assert "evaluation_authority_id" in fields


def test_condition_default_status():
    """Condition without condition_status defaults to NOT_EVALUATED."""
    cond = make_condition("jsc:cond/test", "All units report REDCON 1")
    assert cond.condition_status == ConditionStatus.NOT_EVALUATED


def test_decision_point_two_branch_minimum():
    """DecisionPoint with two PlanBranch entries validates correctly."""
    cond_north = make_condition("jsc:cond/axis-north", "SIGINT confirms axis NORTH")
    cond_south = make_condition("jsc:cond/axis-south", "SIGINT confirms axis SOUTH")

    branch_north = PlanBranch(
        branch_label="BRANCH SCARLET — attack axis NORTH",
        triggering_condition_id="jsc:cond/axis-north",
        branch_plan_id="jsc:plan/branch-scarlet",
        description="Execute flanking attack via northern corridor",
    )
    branch_south = PlanBranch(
        branch_label="BRANCH AMBER — attack axis SOUTH",
        triggering_condition_id="jsc:cond/axis-south",
        branch_plan_id="jsc:plan/branch-amber",
    )

    dp = DecisionPoint(
        id="jsc:dp/axis-decision",
        name="Decision Point ALPHA — Axis of Advance",
        decision_criteria=(
            "Enemy axis of advance confirmed NORTH or SOUTH by SIGINT "
            "within 6 hours of BMNT on D+2"
        ),
        decision_authority_id="jsc:unit/3-id-cg",
        decision_branches=[branch_north, branch_south],
    )

    assert len(dp.decision_branches) == 2
    assert dp.decision_branches[0].branch_label == "BRANCH SCARLET — attack axis NORTH"
    assert dp.decision_branches[1].triggering_condition_id == "jsc:cond/axis-south"


def test_branch_plan_links_to_parent():
    """BranchPlan carries parent_plan_id and activating_decision_point_id."""
    branch = BranchPlan(
        id="jsc:plan/branch-scarlet",
        name="Branch Plan SCARLET — Attack Axis NORTH",
        plan_status=PlanStatus.APPROVED,
        parent_plan_id="jsc:plan/oplan-24-001",
        activating_decision_point_id="jsc:dp/axis-decision",
    )

    assert branch.parent_plan_id                == "jsc:plan/oplan-24-001"
    assert branch.activating_decision_point_id  == "jsc:dp/axis-decision"


# ── Test 3: PlanExecution — instantiation bridge (roles, conditions, events) ──

def test_plan_execution_role_and_condition_mapping():
    """PlanExecution with RoleAssignment and ConditionEvaluation is valid."""
    assignment = RoleAssignment(
        task_ref_id="jsc:task/assault-obj-iron",
        role_description="Lead assault element",
        required_force_size=ForceSize.COMPANY,
        assigned_unit_id="jsc:unit/a-co-3-69-ar",
    )
    evaluation = ConditionEvaluation(
        condition_ref_id="jsc:cond/abn-complete",
        evaluation_result=ConditionStatus.MET,
        evaluation_timestamp=ts(H_HOUR),
        evaluator_id="jsc:unit/corps-g3",
        evaluation_rationale=(
            "Leading elements of TF 3-69 AR confirmed crossing PL AMBER "
            "at 04:17Z via FBCB2 track data and air observer report."
        ),
    )

    execution = PlanExecution(
        id="jsc:exec/oplan-24-001-exec-001",
        name="OPLAN 24-001 Execution — 20 JUN 2024",
        execution_plan_id="jsc:plan/oplan-24-001",
        execution_status=ExecutionStatus.IN_PROGRESS,
        execution_start=ts(H_HOUR),
        role_assignments=[assignment],
        condition_evaluations=[evaluation],
        actual_event_ids=[
            "jsc:event/strike-001",
            "jsc:event/assault-obj-iron-001",
        ],
        confidence=88,
    )

    assert execution.execution_status == ExecutionStatus.IN_PROGRESS
    assert len(execution.role_assignments) == 1
    assert execution.role_assignments[0].assigned_unit_id == "jsc:unit/a-co-3-69-ar"
    assert execution.role_assignments[0].required_force_size == ForceSize.COMPANY

    assert len(execution.condition_evaluations) == 1
    assert execution.condition_evaluations[0].evaluation_result == ConditionStatus.MET
    assert execution.condition_evaluations[0].evaluator_id == "jsc:unit/corps-g3"

    assert "jsc:event/strike-001" in execution.actual_event_ids


def test_plan_execution_requires_plan_id_and_status():
    """PlanExecution without execution_plan_id or execution_status must fail."""
    with pytest.raises(ValidationError) as exc_info:
        PlanExecution(id="jsc:exec/x", name="Missing fields")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "execution_plan_id" in fields
    assert "execution_status"  in fields


def test_force_requirement_role_and_size_required():
    """ForceRequirement without force_requirement_role or force_size must fail."""
    with pytest.raises(ValidationError) as exc_info:
        ForceRequirement()
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "force_requirement_role" in fields
    assert "force_size"             in fields


def test_contingency_plan_trigger_condition():
    """ContingencyPlan with trigger_condition_id and parent_plan_id is valid."""
    plan = ContingencyPlan(
        id="jsc:plan/contingency-cyber-attack",
        name="CONPLAN CYBER SHIELD — C2 Node Attack Response",
        plan_status=PlanStatus.APPROVED,
        trigger_condition_id="jsc:cond/c2-node-compromised",
        parent_plan_id="jsc:plan/oplan-24-001",
        description="Activated if adversary achieves C2 network penetration",
    )

    assert plan.trigger_condition_id == "jsc:cond/c2-node-compromised"
    assert plan.parent_plan_id       == "jsc:plan/oplan-24-001"
