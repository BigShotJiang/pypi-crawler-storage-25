"""
Shared pytest configuration for joint-schema tests.

Adds the generated Pydantic models directory to sys.path so every test
file can import generated models without package installation.

The directory is resolved (in priority order) from:
  1. GENERATED_PYTHON_DIR env var  — set by CI to /tmp/gen-pr
  2. <repo_root>/generated/python/ — default for local development
"""
import os
import sys
import pathlib

REPO_ROOT = pathlib.Path(__file__).parent.parent

env_override = os.environ.get("GENERATED_PYTHON_DIR")
GENERATED_PYTHON = pathlib.Path(env_override) if env_override else REPO_ROOT / "generated" / "python"

if str(GENERATED_PYTHON) not in sys.path:
    sys.path.insert(0, str(GENERATED_PYTHON))
