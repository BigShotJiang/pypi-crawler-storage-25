"""
Tests for schema/core/time.yaml — temporal types and shared primitives.

Generated models: generated/python/core__time_models.py
"""
import pytest
from datetime import datetime, timezone, timedelta
from pydantic import ValidationError

from core__time_models import (
    DateTimePrecision,
    EstimationMethod,
    ExternalReferenceType,
    ExternalReference,
    Timestamp,
    TimeInterval,
    TemporalUncertainty,
)

# ── Helpers ────────────────────────────────────────────────────────────────────

T_OBSERVED = datetime(2024, 3, 15, 14, 30, 0, tzinfo=timezone.utc)
T_EARLIER   = datetime(2024, 3, 15, 6,   0, 0, tzinfo=timezone.utc)
T_LATER     = datetime(2024, 3, 15, 18,  0, 0, tzinfo=timezone.utc)


def make_ts(dt: datetime = T_OBSERVED) -> Timestamp:
    return Timestamp(datetime_value=dt)


# ── Test 1: Timestamp defaults and field access ────────────────────────────────

def test_timestamp_defaults_and_fields():
    """A Timestamp with only datetime_value gets SECOND precision by default."""
    ts = make_ts()

    assert ts.datetime_value == T_OBSERVED
    # Default precision is SECOND (ifabsent in schema)
    assert ts.precision == DateTimePrecision.SECOND

    # Explicit precision override
    ts_minute = Timestamp(
        datetime_value=T_OBSERVED,
        precision=DateTimePrecision.MINUTE,
    )
    assert ts_minute.precision == DateTimePrecision.MINUTE


def test_timestamp_requires_datetime_value():
    """Timestamp without datetime_value must raise a ValidationError."""
    with pytest.raises(ValidationError) as exc_info:
        Timestamp()
    errors = exc_info.value.errors()
    fields = {e["loc"][0] for e in errors}
    assert "datetime_value" in fields


def test_timestamp_accepts_naive_datetime():
    """Pydantic v2 datetime accepts naive datetimes (tz enforcement is schema-doc only).
    Verify the field is stored and a missing required field still raises."""
    naive = datetime(2024, 3, 15, 14, 30, 0)  # no tzinfo
    ts = Timestamp(datetime_value=naive)
    assert ts.datetime_value == naive

    # Confirm required-field enforcement still works
    with pytest.raises(ValidationError) as exc_info:
        Timestamp()
    assert "datetime_value" in {e["loc"][0] for e in exc_info.value.errors()}


# ── Test 2: TimeInterval open-ended and bounded forms ─────────────────────────

def test_time_interval_open_ended_start_only():
    """An interval with only a start is a valid open-ended interval (ongoing op)."""
    interval = TimeInterval(start=make_ts(T_EARLIER))

    assert interval.start is not None
    assert interval.start.datetime_value == T_EARLIER
    assert interval.end is None
    assert interval.duration is None


def test_time_interval_duration_only():
    """An interval expressed as ISO 8601 duration string is valid."""
    interval = TimeInterval(duration="P2DT6H")

    assert interval.duration == "P2DT6H"
    assert interval.start is None
    assert interval.end is None


def test_time_interval_fully_bounded():
    """A start + end + duration_ms interval carries all temporal fields."""
    interval = TimeInterval(
        start=make_ts(T_EARLIER),
        end=make_ts(T_LATER),
        duration="PT12H",
        duration_ms=43200000.0,
    )

    assert interval.start.datetime_value == T_EARLIER
    assert interval.end.datetime_value == T_LATER
    assert interval.duration == "PT12H"
    assert interval.duration_ms == 43200000.0


# ── Test 3: TemporalUncertainty dual-time structure ───────────────────────────

def test_temporal_uncertainty_requires_observed_time():
    """TemporalUncertainty without observed_time must fail (required field)."""
    with pytest.raises(ValidationError) as exc_info:
        TemporalUncertainty()
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "observed_time" in fields


def test_temporal_uncertainty_full_structure():
    """Valid dual-time record with all optional estimate fields populated."""
    uncertainty = TemporalUncertainty(
        observed_time=make_ts(T_OBSERVED),
        estimated_actual_time=make_ts(T_EARLIER),
        temporal_confidence=72,
        earliest_possible=make_ts(T_EARLIER),
        latest_possible=make_ts(T_OBSERVED),
        estimation_method=EstimationMethod.IMAGERY_ANALYSIS,
        timing_precision_ms=500.0,
    )

    assert uncertainty.observed_time.datetime_value == T_OBSERVED
    assert uncertainty.estimated_actual_time.datetime_value == T_EARLIER
    assert uncertainty.temporal_confidence == 72
    assert uncertainty.estimation_method == EstimationMethod.IMAGERY_ANALYSIS
    assert uncertainty.timing_precision_ms == 500.0


def test_temporal_uncertainty_confidence_bounds():
    """temporal_confidence must be between 0 and 100 (inclusive)."""
    # Valid boundary values
    low  = TemporalUncertainty(observed_time=make_ts(), temporal_confidence=0)
    high = TemporalUncertainty(observed_time=make_ts(), temporal_confidence=100)
    assert low.temporal_confidence  == 0
    assert high.temporal_confidence == 100

    # Out-of-range must fail
    with pytest.raises(ValidationError):
        TemporalUncertainty(observed_time=make_ts(), temporal_confidence=101)
    with pytest.raises(ValidationError):
        TemporalUncertainty(observed_time=make_ts(), temporal_confidence=-1)


# ── Test 4: ExternalReference stub class ──────────────────────────────────────

def test_external_reference_valid():
    """ExternalReference with all fields validates correctly."""
    ref = ExternalReference(
        external_ref_type=ExternalReferenceType.STIX,
        source_name="STIX Bundle — Operation Nightfall",
        source_id="bundle--12345678-1234-1234-1234-123456789abc",
        reference_url="https://example.com/stix/bundle.json",
        description="STIX 2.1 bundle from threat intelligence platform",
    )

    assert ref.external_ref_type == ExternalReferenceType.STIX
    assert ref.source_id.startswith("bundle--")


def test_external_reference_requires_type():
    """ExternalReference without external_ref_type must fail."""
    with pytest.raises(ValidationError) as exc_info:
        ExternalReference(source_name="test")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "external_ref_type" in fields
