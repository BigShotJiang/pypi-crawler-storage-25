"""
Tests for schema/core/actors.yaml — three-domain actor model.

Generated models: generated/python/core__actors_models.py
"""
import pytest
from pydantic import ValidationError

from core__actors_models import (
    MilitaryEchelon,
    BranchOfService,
    CombatantSide,
    ThreatActorType,
    ThreatActorSophistication,
    ThreatActorMotivation,
    InfluenceActorType,
    MilitaryUnit,
    ThreatActor,
    InfluenceOperationActor,
)


# ── Test 1: MilitaryUnit — NATO/MIM compatible unit model ─────────────────────

def test_military_unit_minimal_valid():
    """MilitaryUnit with only required fields (id, name, side) is valid."""
    unit = MilitaryUnit(
        id="jsc:unit/3-bn-69-ar",
        name="3rd Battalion, 69th Armor Regiment",
        side=CombatantSide.FRIENDLY,
    )

    assert unit.id   == "jsc:unit/3-bn-69-ar"
    assert unit.name == "3rd Battalion, 69th Armor Regiment"
    assert unit.side == CombatantSide.FRIENDLY
    # Optional fields absent
    assert unit.echelon         is None
    assert unit.parent_unit_id  is None
    assert unit.branch_of_service is None


def test_military_unit_full_hierarchy():
    """MilitaryUnit with echelon, branch, designation, and parent link is valid."""
    battalion = MilitaryUnit(
        id="jsc:unit/3-bn-69-ar",
        name="3-69 AR",
        side=CombatantSide.FRIENDLY,
        echelon=MilitaryEchelon.BATTALION,
        branch_of_service=BranchOfService.ARMY,
        unit_designation="3rd Battalion, 69th Armor Regiment",
        parent_unit_id="jsc:unit/3-abct",
        aliases=["Task Force IRON", "TF 3-69"],
    )

    assert battalion.echelon           == MilitaryEchelon.BATTALION
    assert battalion.branch_of_service == BranchOfService.ARMY
    assert battalion.unit_designation  == "3rd Battalion, 69th Armor Regiment"
    assert battalion.parent_unit_id    == "jsc:unit/3-abct"
    assert "Task Force IRON"           in battalion.aliases


def test_military_unit_requires_side():
    """MilitaryUnit without `side` must raise a ValidationError."""
    with pytest.raises(ValidationError) as exc_info:
        MilitaryUnit(id="jsc:unit/x", name="Unknown Unit")
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "side" in fields


def test_military_unit_requires_id_and_name():
    """MilitaryUnit without id or name must fail validation."""
    with pytest.raises(ValidationError):
        MilitaryUnit(side=CombatantSide.FRIENDLY)


def test_military_unit_attribution_confidence_bounds():
    """attribution_confidence must be in [0, 100]; values outside that range fail."""
    # Boundary values are valid
    lo = MilitaryUnit(id="jsc:unit/a", name="A", side=CombatantSide.HOSTILE, attribution_confidence=0)
    hi = MilitaryUnit(id="jsc:unit/b", name="B", side=CombatantSide.HOSTILE, attribution_confidence=100)
    assert lo.attribution_confidence == 0
    assert hi.attribution_confidence == 100

    with pytest.raises(ValidationError):
        MilitaryUnit(id="jsc:unit/c", name="C", side=CombatantSide.HOSTILE, attribution_confidence=101)
    with pytest.raises(ValidationError):
        MilitaryUnit(id="jsc:unit/d", name="D", side=CombatantSide.HOSTILE, attribution_confidence=-1)


# ── Test 2: ThreatActor — STIX-mapped adversary model ─────────────────────────

def test_threat_actor_nation_state():
    """ThreatActor of type NATION_STATE with sophistication and motivation."""
    actor = ThreatActor(
        id="stix:threat-actor--12345678-1234-1234-1234-123456789abc",
        name="APT-X",
        threat_actor_types=[ThreatActorType.NATION_STATE],
        sophistication=ThreatActorSophistication.ADVANCED,
        primary_motivation=ThreatActorMotivation.IDEOLOGY,
        aliases=["Fancy Bear", "Sofacy", "APT28"],
    )

    assert ThreatActorType.NATION_STATE         in actor.threat_actor_types
    assert actor.sophistication                  == ThreatActorSophistication.ADVANCED
    assert actor.primary_motivation             == ThreatActorMotivation.IDEOLOGY
    assert "Fancy Bear"                          in actor.aliases


def test_threat_actor_minimal():
    """ThreatActor with only id and name is valid (all other fields optional)."""
    actor = ThreatActor(
        id="jsc:actor/unknown-threat",
        name="Unknown Threat Actor",
    )

    assert actor.threat_actor_types is None
    assert actor.sophistication     is None


def test_threat_actor_stix_uri_id():
    """ThreatActor id accepts a full STIX URN format."""
    actor = ThreatActor(
        id="stix:threat-actor--aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        name="STIX Actor",
    )
    assert actor.id.startswith("stix:")


# ── Test 3: InfluenceOperationActor — DISARM-mapped influence actor ────────────

def test_influence_actor_state_media():
    """InfluenceOperationActor of type STATE_ALIGNED_MEDIA is valid."""
    actor = InfluenceOperationActor(
        id="jsc:actor/rt-network",
        name="RT Network",
        influence_actor_type=InfluenceActorType.STATE_ALIGNED,
        active_platforms=["YouTube", "Telegram", "X/Twitter"],
        attributed_to_state_id="jsc:actor/russian-federation",
        attribution_confidence=78,
        influence_capabilities=["broadcast television", "social media amplification"],
    )

    assert actor.influence_actor_type    == InfluenceActorType.STATE_ALIGNED
    assert "Telegram"                    in actor.active_platforms
    assert actor.attribution_confidence  == 78
    assert "broadcast television"        in actor.influence_capabilities


def test_influence_actor_requires_id_and_name():
    """InfluenceOperationActor without id and name must fail."""
    with pytest.raises(ValidationError):
        InfluenceOperationActor()


def test_influence_actor_attribution_confidence_optional():
    """attribution_confidence is optional; absent means unasserted."""
    actor = InfluenceOperationActor(
        id="jsc:actor/anon-troll-farm",
        name="Anonymous Troll Farm",
    )
    assert actor.attribution_confidence  is None
    assert actor.attributed_to_state_id  is None
