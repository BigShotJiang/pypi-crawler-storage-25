"""
Tests for schema/core/events.yaml — cross-domain event types.

Generated models: generated/python/core__events_models.py
"""
import pytest
from datetime import datetime, timezone
from pydantic import ValidationError

from core__events_models import (
    CausalLinkType,
    KineticEventType,
    CyberKillChainPhase,
    CausalLink,
    KineticEvent,
    CyberEvent,
    InfluenceEvent,
    SignalEvent,
    Timestamp,
    TimeInterval,
    TemporalUncertainty,
)

# ── Helpers ────────────────────────────────────────────────────────────────────

NOW = datetime(2024, 6, 15, 8, 0, 0, tzinfo=timezone.utc)
EARLIER = datetime(2024, 6, 15, 4, 0, 0, tzinfo=timezone.utc)

def ts(dt: datetime = NOW) -> Timestamp:
    return Timestamp(datetime_value=dt)


# ── Test 1: KineticEvent — MIM-compatible kinetic action ──────────────────────

def test_kinetic_event_minimal_valid():
    """KineticEvent with required fields (id, name, event_time, kinetic_event_type) is valid."""
    event = KineticEvent(
        id="jsc:event/strike-001",
        name="Artillery Strike — Grid 123456",
        event_time=ts(),
        kinetic_event_type=KineticEventType.AIR_STRIKE,
        location_id="jsc:point/grid-123456",
        actor_ids=["jsc:unit/2-bde-fires"],
    )

    assert event.kinetic_event_type == KineticEventType.AIR_STRIKE
    assert event.location_id        == "jsc:point/grid-123456"
    assert "jsc:unit/2-bde-fires"   in event.actor_ids


def test_kinetic_event_with_time_interval():
    """KineticEvent accepts a TimeInterval for event_time (e.g. an ongoing operation)."""
    interval = TimeInterval(
        start=ts(EARLIER),
        end=ts(NOW),
        duration="PT4H",
    )
    event = KineticEvent(
        id="jsc:event/operation-001",
        name="Operation IRON THUNDER — Phase 1",
        event_time=interval,
        kinetic_event_type=KineticEventType.DELIBERATE_ATTACK,
        weapon_systems=["M270 MLRS", "M777 155mm Howitzer"],
        effects_observed=["Secondary explosions observed at grid 456789"],
        confidence=80,
    )

    # event_time resolves to the TimeInterval subtype
    assert event.event_time.start.datetime_value == EARLIER
    assert event.event_time.end.datetime_value   == NOW
    assert "M777 155mm Howitzer"                 in event.weapon_systems


def test_kinetic_event_requires_kinetic_event_type():
    """KineticEvent without kinetic_event_type must raise a ValidationError."""
    with pytest.raises(ValidationError) as exc_info:
        KineticEvent(
            id="jsc:event/x",
            name="Missing Type",
            event_time=ts(),
        )
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "kinetic_event_type" in fields


def test_kinetic_event_with_temporal_uncertainty():
    """KineticEvent accepts TemporalUncertainty for BDA-lag scenarios."""
    uncertainty = TemporalUncertainty(
        observed_time=ts(NOW),
        estimated_actual_time=ts(EARLIER),
        temporal_confidence=65,
    )
    event = KineticEvent(
        id="jsc:event/bda-001",
        name="Strike — BDA Pending",
        event_time=uncertainty,
        kinetic_event_type=KineticEventType.AIR_STRIKE,
    )

    assert event.event_time.temporal_confidence == 65
    assert event.event_time.observed_time.datetime_value == NOW


def test_kinetic_event_causal_link_to_cyber_event():
    """KineticEvent can carry a CausalLink referencing a CyberEvent by CURIE."""
    link = CausalLink(
        source_event_id="jsc:event/strike-001",
        target_event_id="jsc:event/cyber-001",
        link_type=CausalLinkType.ENABLES,
        causal_confidence=55,
        analyst_notes="Physical destruction of fibre trunk enabled subsequent cyber infiltration",
    )
    event = KineticEvent(
        id="jsc:event/strike-001",
        name="Comms Node Strike",
        event_time=ts(),
        kinetic_event_type=KineticEventType.AIR_STRIKE,
        causal_links=[link],
    )

    assert len(event.causal_links) == 1
    assert event.causal_links[0].link_type == CausalLinkType.ENABLES
    assert event.causal_links[0].target_event_id == "jsc:event/cyber-001"


# ── Test 2: CyberEvent — STIX-aligned cyber action ────────────────────────────

def test_cyber_event_full_kill_chain():
    """CyberEvent with kill chain phase, malware, and target system data is valid."""
    event = CyberEvent(
        id="stix:attack-pattern--aaaabbbb-1234-5678-abcd-111122223333",
        name="Spear-phishing — DEFENCE MINISTRY",
        event_time=ts(),
        cyber_kill_chain_phase=CyberKillChainPhase.DELIVERY,
        attack_pattern_refs=["MITRE:T1566.001"],
        malware_identifiers=["INDUSTROYER2", "CRASHOVERRIDE"],
        target_system_descriptions=["Windows domain controllers", "SCADA historian server"],
        vulnerability_ids=["CVE-2022-30190"],
        affected_systems_count=14,
        confidence=88,
        actor_ids=["stix:threat-actor--aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"],
    )

    assert event.cyber_kill_chain_phase  == CyberKillChainPhase.DELIVERY
    assert "MITRE:T1566.001"             in event.attack_pattern_refs
    assert "INDUSTROYER2"                in event.malware_identifiers
    assert event.affected_systems_count  == 14


def test_cyber_event_requires_event_time():
    """CyberEvent without event_time must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        CyberEvent(
            id="jsc:event/cyber-x",
            name="No Time",
            cyber_kill_chain_phase=CyberKillChainPhase.EXPLOITATION,
        )
    fields = {e["loc"][0] for e in exc_info.value.errors()}
    assert "event_time" in fields


def test_cyber_event_minimal():
    """CyberEvent with only id, name, and event_time is valid."""
    event = CyberEvent(
        id="jsc:event/cyber-minimal",
        name="Unclassified Cyber Intrusion",
        event_time=ts(),
    )

    assert event.cyber_kill_chain_phase is None
    assert event.malware_identifiers    is None


# ── Test 3: InfluenceEvent — DISARM-aligned influence operation ───────────────

def test_influence_event_full_disarm_record():
    """InfluenceEvent with DISARM IDs, platforms, reach, and EW platform ref."""
    event = InfluenceEvent(
        id="jsc:event/disinfo-001",
        name="Fake-Experts Campaign — Baltic Audience",
        event_time=ts(),
        disarm_tactic_id="TA06",
        disarm_technique_id="T0085",
        platforms=["Telegram", "X/Twitter", "Facebook"],
        target_audience_description="Russophone Baltic residents aged 35–65",
        narrative_themes=["NATO Article 5 unreliability", "Western economic decline"],
        content_types=["fabricated expert quotes", "meme", "bot amplification"],
        reach_estimate=450_000,
        engagement_estimate=12_000,
        enabling_ew_platform_id="jsc:platform/ew-node-001",
        actor_ids=["jsc:actor/rt-network"],
        confidence=72,
    )

    assert event.disarm_tactic_id    == "TA06"
    assert event.disarm_technique_id == "T0085"
    assert "Telegram"                in event.platforms
    assert event.reach_estimate      == 450_000
    assert event.enabling_ew_platform_id == "jsc:platform/ew-node-001"


def test_influence_event_minimal():
    """InfluenceEvent with only required base fields is valid."""
    event = InfluenceEvent(
        id="jsc:event/influence-minimal",
        name="Unattributed Influence Activity",
        event_time=ts(),
    )

    assert event.disarm_tactic_id   is None
    assert event.reach_estimate     is None
    assert event.enabling_ew_platform_id is None


def test_signal_event_stub():
    """SignalEvent (EW stub) with frequency and emitter platform is valid."""
    event = SignalEvent(
        id="jsc:event/signal-001",
        name="X-band Radar Intercept — Grid 789012",
        event_time=ts(),
        signal_frequency_mhz=9500.0,
        signal_bandwidth_mhz=200.0,
        signal_class="X-band pulse-Doppler fire-control radar",
        emitter_platform_id="jsc:platform/su-35s-tail-001",
        actor_ids=["jsc:unit/ru-avn-bde"],
    )

    assert event.signal_frequency_mhz  == pytest.approx(9500.0)
    assert event.signal_bandwidth_mhz  == pytest.approx(200.0)
    assert "X-band"                    in event.signal_class
    assert event.emitter_platform_id   == "jsc:platform/su-35s-tail-001"
