# Zerone CLI

Zerone 私募股权数据命令行工具，通过 API Key 直接查询 Zerone 数据平台。

## 安装

```bash
pip install zerone-cli
```

## 快速开始

### 1. 配置 API Key

```bash
zerone config set-api-key YOUR_API_KEY
```

> 如何获取 API Key？请访问 [https://ai.zerone.com.cn](https://ai.zerone.com.cn) 注册账号后申请。

### 2. 查看帮助

```bash
zerone --help
```

### 3. 开始查询

```bash
# 搜索实体
zerone entity-search "字节跳动"

# 查询实体综合画像
zerone entity-profile "中国石油"

# 查询财务数据列表
zerone entity-financial-list "中国石油"

# 查询管理基金列表
zerone entity-managed-funds-list "深创投"

# 查询退出列表
zerone entity-exit-list "深创投"

# 查询投资列表
zerone entity-invest-list "深创投"

# 查询融资概率预测
zerone model-financing-probability "字节跳动"
```

## 命令列表

| 命令 | 说明 |
|------|------|
| `zerone config set-api-key` | 设置 API Key |
| `zerone config set-server-url` | 设置服务器地址（可选） |
| `zerone config show` | 查看当前配置 |
| `zerone entity-search` | 实体模糊搜索 |
| `zerone entity-profile` | 查询实体综合画像 |
| `zerone entity-financial-list` | 查询实体财务数据列表（分页） |
| `zerone entity-managed-funds-list` | 查询管理基金列表（分页） |
| `zerone entity-exit-list` | 查询退出列表（分页） |
| `zerone entity-invest-list` | 查询投资列表（分页） |
| `zerone model-financing-probability` | 查询融资概率预测模型 |

## 配置说明

配置文件保存在 `~/.zerone/config.yaml`，支持以下环境变量覆盖：

| 环境变量 | 说明 |
|----------|------|
| `ZERONE_API_KEY` | API Key |
| `ZERONE_SERVER_URL` | 服务器地址 |

## 系统要求

- Python 3.9+
- 有效的 Zerone API Key

## 许可证

MIT
