from __future__ import annotations

import argparse
import json
import mimetypes
import sqlite3
import re
import sys
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

import yaml
from markdown_it import MarkdownIt

from ..identity import canonicalize_note_id
from ..knowledge_index import contradiction_object_ids, rebuild_compiled_summaries, resolve_contradictions
from ..runtime import VaultLayout, resolve_vault_dir
from ..ui.view_models import (
    build_atlas_browser_payload,
    build_briefing_payload,
    build_contradiction_browser_payload,
    build_derivation_browser_payload,
    build_event_dossier_payload,
    build_note_page_payload,
    build_object_page_payload,
    build_objects_index_payload,
    build_production_browser_payload,
    build_search_payload,
    build_signal_browser_payload,
    build_stale_summary_browser_payload,
    build_truth_dashboard_payload,
    build_topic_overview_payload,
)
from ..truth_api import ensure_signal_ledger_synced, record_review_action

_MARKDOWN_RENDERER = MarkdownIt("commonmark", {"breaks": True, "html": False}).enable("table")
_FENCED_FRONTMATTER_RE = re.compile(r"^```ya?ml\s*\n---\n(.*?)\n---\n```\s*\n?", re.DOTALL)
_GITHUB_REPO_RE = re.compile(r"https://github\.com/([^/\s]+)/([^/\s#]+)")


def _layout(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>{escape(title)}</title>
    <style>
      :root {{
        color-scheme: light;
        --bg: #f7f6f2;
        --surface: #fffdfa;
        --border: #e7e1d8;
        --text: #1f1a17;
        --muted: #71675d;
        --accent: #9f4f24;
        --accent-soft: #f4dfd2;
      }}
      * {{ box-sizing: border-box; }}
      body {{ font-family: ui-sans-serif, system-ui, sans-serif; margin: 0; line-height: 1.5; background: var(--bg); color: var(--text); }}
      main {{ max-width: 1180px; margin: 0 auto; padding: 1.5rem 1.5rem 3rem; }}
      nav {{ margin-bottom: 1.5rem; display: flex; gap: 0.9rem; flex-wrap: wrap; }}
      nav a {{ color: var(--accent); text-decoration: none; font-weight: 600; }}
      nav a:hover {{ text-decoration: underline; }}
      h1, h2, h3 {{ margin-bottom: 0.5rem; line-height: 1.2; }}
      ul {{ padding-left: 1.2rem; }}
      pre {{ background: #f4f4f5; padding: 1rem; border-radius: 8px; overflow-x: auto; }}
      img {{ max-width: 100%; height: auto; display: block; border-radius: 12px; }}
      input, select, button {{ font: inherit; }}
      input, select {{ padding: 0.55rem 0.7rem; border: 1px solid var(--border); border-radius: 10px; background: var(--surface); }}
      button {{ padding: 0.55rem 0.8rem; border-radius: 10px; border: 1px solid var(--accent); background: var(--accent); color: white; cursor: pointer; }}
      button:hover {{ opacity: 0.92; }}
      .muted {{ color: var(--muted); }}
      .hero {{ margin-bottom: 1.5rem; }}
      .shell {{ background: var(--surface); border: 1px solid var(--border); border-radius: 20px; box-shadow: 0 12px 36px rgba(31, 26, 23, 0.06); }}
      .shell-head {{ padding: 1.1rem 1.25rem 0; }}
      .shell-body {{ padding: 0 1.25rem 1.25rem; }}
      .card {{ border: 1px solid var(--border); background: var(--surface); border-radius: 16px; padding: 1rem; margin-bottom: 1rem; }}
      .grid {{ display: grid; gap: 1rem; }}
      .stats {{ grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); }}
      .two-col {{ grid-template-columns: minmax(0, 2.1fr) minmax(280px, 1fr); align-items: start; }}
      .pill {{ display: inline-block; padding: 0.15rem 0.5rem; border-radius: 999px; background: var(--accent-soft); color: var(--accent); margin-right: 0.5rem; }}
      .link-row {{ display: flex; gap: 0.75rem; flex-wrap: wrap; margin-top: 0.9rem; }}
      .link-row a {{ color: var(--accent); text-decoration: none; font-weight: 600; }}
      .subnav {{ display: flex; gap: 0.6rem; flex-wrap: wrap; margin-top: 0.9rem; margin-bottom: 1rem; }}
      .subnav a {{ color: var(--muted); text-decoration: none; padding: 0.35rem 0.6rem; border: 1px solid var(--border); border-radius: 999px; background: var(--surface); }}
      .subnav a:hover {{ color: var(--accent); border-color: var(--accent-soft); }}
      .list-tight li {{ margin-bottom: 0.4rem; }}
      .section-stack {{ display: grid; gap: 1rem; }}
      .meta-list {{ display: grid; gap: 0.6rem; margin: 0; }}
      .meta-list dt {{ font-weight: 700; }}
      .meta-list dd {{ margin: 0; color: var(--muted); }}
      @media (max-width: 780px) {{ .two-col {{ grid-template-columns: 1fr; }} main {{ padding: 1rem 1rem 2rem; }} }}
    </style>
  </head>
  <body>
    <main>
      <div class="shell">
        <div class="shell-head">
          <nav>
            <a href="/">Home</a>
            <a href="/objects">Objects</a>
            <a href="/search">Search</a>
            <a href="/signals">Signals</a>
            <a href="/briefing">Briefing</a>
            <a href="/production">Production</a>
            <a href="/atlas">Atlas</a>
            <a href="/deep-dives">Deep Dives</a>
            <a href="/events">Event Dossier</a>
            <a href="/contradictions">Contradictions</a>
            <a href="/summaries">Stale Summaries</a>
          </nav>
        </div>
        <div class="shell-body">
          {body}
        </div>
      </div>
    </main>
  </body>
</html>
"""


def _note_href(path: str) -> str:
    return f"/note?path={quote(path, safe='')}"


def _asset_href(path: str) -> str:
    return f"/asset?path={quote(path, safe='')}"


def _search_href(query: str) -> str:
    return f"/search?q={quote(query, safe='')}"


def _read_vault_note(vault_dir: Path, relative_path: str) -> tuple[Path, str]:
    candidate = (vault_dir / relative_path).resolve()
    try:
        candidate.relative_to(vault_dir.resolve())
    except ValueError as exc:
        raise ValueError("invalid note path") from exc
    if not candidate.is_file():
        raise ValueError(f"note not found: {relative_path}")
    return candidate, candidate.read_text(encoding="utf-8")


def _read_vault_asset(vault_dir: Path, relative_path: str) -> tuple[bytes, str]:
    candidate = (vault_dir / relative_path).resolve()
    try:
        candidate.relative_to(vault_dir.resolve())
    except ValueError as exc:
        raise ValueError("invalid asset path") from exc
    if not candidate.is_file():
        raise ValueError(f"asset not found: {relative_path}")
    return candidate.read_bytes(), mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"


def _lookup_wikilink_target(vault_dir: Path, target: str) -> tuple[str, str] | None:
    db_path = VaultLayout.from_vault(vault_dir).knowledge_db
    if not db_path.exists():
        return None

    raw_target = target.split("|", 1)[0].split("#", 1)[0].strip()
    if not raw_target:
        return None

    exact_path = raw_target
    stem = Path(raw_target).stem
    normalized = canonicalize_note_id(raw_target)
    normalized_stem = canonicalize_note_id(stem)
    suffixes = [f"%/{stem.lower()}.md"]
    if raw_target.lower().endswith(".md"):
        suffixes.append(f"%/{raw_target.lower()}")

    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT slug, title, note_type, path
            FROM pages_index
            WHERE lower(slug) = ?
               OR lower(title) = ?
               OR lower(path) = ?
               OR lower(path) LIKE ?
               OR lower(path) LIKE ?
            LIMIT 25
            """,
            (
                normalized,
                raw_target.lower(),
                exact_path.lower(),
                suffixes[0],
                suffixes[-1],
            ),
        ).fetchall()

    def rank(row: tuple[str, str, str, str]) -> tuple[int, str]:
        slug, title, _note_type, path = row
        path_lower = path.lower()
        title_lower = title.lower()
        if slug == normalized:
            return (0, path)
        if normalized_stem and slug == normalized_stem:
            return (1, path)
        if title_lower == raw_target.lower():
            return (2, path)
        if path_lower.endswith(f"/{raw_target.lower()}"):
            return (3, path)
        if path_lower.endswith(f"/{stem.lower()}.md"):
            return (4, path)
        return (10, path)

    if not rows:
        for candidate in vault_dir.rglob("*.md"):
            if candidate.stem.lower() != stem.lower():
                continue
            relative_path = str(candidate.resolve().relative_to(vault_dir.resolve()))
            if "10-Knowledge/Evergreen/" in relative_path:
                return (f"/object?id={quote(canonicalize_note_id(stem), safe='')}", canonicalize_note_id(stem))
            return (_note_href(relative_path), relative_path)
        return None

    slug, _title, note_type, path = sorted(rows, key=rank)[0]
    relative_path = path
    candidate = Path(path)
    if candidate.is_absolute():
        try:
            relative_path = str(candidate.resolve().relative_to(vault_dir.resolve()))
        except ValueError:
            relative_path = path

    if note_type == "evergreen":
        return (f"/object?id={quote(slug, safe='')}", slug)
    return (_note_href(relative_path), relative_path)


def _is_search_href(href: str) -> bool:
    return href.startswith("/search?q=")


def _strip_frontmatter(markdown: str) -> str:
    if not markdown.startswith("---\n"):
        return markdown
    end = markdown.find("\n---\n", 4)
    if end == -1:
        return markdown
    return markdown[end + 5 :]


def _parse_frontmatter(markdown: str) -> tuple[dict[str, object], str]:
    fenced_match = _FENCED_FRONTMATTER_RE.match(markdown)
    if fenced_match:
        raw_frontmatter = fenced_match.group(1)
        body = markdown[fenced_match.end() :]
        try:
            parsed = yaml.safe_load(raw_frontmatter) or {}
        except yaml.YAMLError:
            parsed = {}
        return parsed if isinstance(parsed, dict) else {}, body
    if not markdown.startswith("---\n"):
        return {}, markdown
    end = markdown.find("\n---\n", 4)
    if end == -1:
        return {}, markdown
    raw_frontmatter = markdown[4:end]
    body = markdown[end + 5 :]
    try:
        parsed = yaml.safe_load(raw_frontmatter) or {}
    except yaml.YAMLError:
        parsed = {}
    return parsed if isinstance(parsed, dict) else {}, body


def _render_frontmatter(frontmatter: dict[str, object]) -> str:
    def render_value(value: object) -> str:
        if isinstance(value, str) and value.startswith(("http://", "https://")):
            return (
                f'<a href="{escape(value)}" target="_blank" rel="noopener noreferrer">{escape(value)}</a>'
            )
        if isinstance(value, (list, dict)):
            return escape(json.dumps(value, ensure_ascii=False))
        return escape(str(value))

    if not frontmatter:
        return ""
    rows = "".join(
        "<tr>"
        f"<th>{escape(str(key))}</th>"
        f"<td>{render_value(value)}</td>"
        "</tr>"
        for key, value in frontmatter.items()
    )
    return (
        "<section class='card'>"
        "<h2>Frontmatter</h2>"
        "<table><tbody>"
        f"{rows}"
        "</tbody></table>"
        "</section>"
    )


def _replace_wikilinks_with_markdown_links(vault_dir: Path, markdown: str) -> str:
    def replace_match(match: re.Match[str]) -> str:
        raw_inner = match.group(1)
        target_part, _, label_part = raw_inner.partition("|")
        label = label_part.strip() or target_part.split("#", 1)[0].strip()
        resolved = _lookup_wikilink_target(vault_dir, target_part)
        href = resolved[0] if resolved else _search_href(target_part.split("#", 1)[0].strip() or label)
        emoji = "🔍" if _is_search_href(href) else "🎯"
        safe_label = label.replace("[", "\\[").replace("]", "\\]")
        return f"[{emoji} {safe_label}]({href})"

    output_lines: list[str] = []
    in_fence = False
    for line in markdown.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("```"):
            in_fence = not in_fence
            output_lines.append(line)
            continue
        if in_fence:
            output_lines.append(line)
            continue
        output_lines.append(re.sub(r"\[\[([^\]]+)\]\]", replace_match, line))
    return "\n".join(output_lines)


def _infer_github_repo_base(frontmatter: dict[str, object], markdown: str) -> str | None:
    candidates: list[str] = []
    for value in frontmatter.values():
        if isinstance(value, str):
            candidates.append(value)
    candidates.append(markdown)
    for candidate in candidates:
        match = _GITHUB_REPO_RE.search(candidate)
        if not match:
            continue
        owner, repo = match.groups()
        return f"https://github.com/{owner}/{repo.removesuffix('.git')}"
    return None


def _smart_markdown_link(label: str, href: str) -> str:
    safe_label = label.replace("[", "\\[").replace("]", "\\]")
    return f"[{safe_label}]({href})"


def _rewrite_local_image_links(vault_dir: Path, markdown: str) -> str:
    def replace_match(match: re.Match[str]) -> str:
        alt_text = match.group(1)
        raw_target = match.group(2).strip()
        if raw_target.startswith(("http://", "https://", "data:", "/asset?")):
            return match.group(0)
        candidate = (vault_dir / raw_target).resolve()
        try:
            relative_path = str(candidate.relative_to(vault_dir.resolve()))
        except ValueError:
            return match.group(0)
        if not candidate.is_file():
            return match.group(0)
        return f"![{alt_text}]({_asset_href(relative_path)})"

    return re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", replace_match, markdown)


def _convert_box_table_fences(markdown: str, *, github_repo_base: str | None) -> str:
    lines = markdown.splitlines()
    output: list[str] = []
    index = 0
    while index < len(lines):
        line = lines[index]
        if line.strip().startswith("```"):
            fence = [line]
            index += 1
            while index < len(lines):
                fence.append(lines[index])
                if lines[index].strip().startswith("```"):
                    index += 1
                    break
                index += 1
            body = fence[1:-1]
            if body and any("│" in row for row in body) and any("┌" in row or "├" in row or "└" in row for row in body):
                rows: list[tuple[str, str]] = []
                for row in body:
                    if "│" not in row:
                        continue
                    parts = [part.strip() for part in row.strip().strip("│").split("│")]
                    if len(parts) != 2:
                        continue
                    left, right = parts
                    if not left or left == "参考链接":
                        continue
                    if right.startswith(("http://", "https://")):
                        right = _smart_markdown_link(right, right)
                    elif github_repo_base and right.endswith(".md") and not right.startswith("/"):
                        right = _smart_markdown_link(right, f"{github_repo_base}/blob/main/{right}")
                    rows.append((left, right))
                if rows:
                    output.append("| 名称 | 值 |")
                    output.append("| --- | --- |")
                    for left, right in rows:
                        output.append(f"| {left} | {right} |")
                    continue
            output.extend(fence)
            continue
        output.append(line)
        index += 1
    return "\n".join(output)


def _linkify_keywords(markdown: str) -> str:
    output: list[str] = []
    keyword_re = re.compile(r"^(\*\*关键词\*\*|关键词)\s*[：:]\s*(.+)$")
    for line in markdown.splitlines():
        match = keyword_re.match(line.strip())
        if not match:
            output.append(line)
            continue
        prefix, values = match.groups()
        rendered = []
        for raw in values.split(","):
            keyword = raw.strip()
            if not keyword:
                continue
            rendered.append(_smart_markdown_link(keyword, _search_href(keyword)))
        output.append(f"{prefix}：{'，'.join(rendered)}")
    return "\n".join(output)


def _linkify_related_knowledge_section(vault_dir: Path, markdown: str) -> str:
    output_lines: list[str] = []
    in_related = False

    for line in markdown.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            in_related = stripped.lstrip("#").strip() == "关联知识"
            output_lines.append(line)
            continue
        if in_related and re.match(r"^- [^\[][^—]+ — ", stripped):
            concept, sep, remainder = stripped[2:].partition(" — ")
            concept = concept.strip()
            resolved = _lookup_wikilink_target(vault_dir, concept)
            href = resolved[0] if resolved else _search_href(concept)
            emoji = "🔍" if _is_search_href(href) else "🎯"
            output_lines.append(f'- [{emoji} {concept}]({href}) — {remainder}')
            continue
        output_lines.append(line)

    return "\n".join(output_lines)


def _render_markdown_note(vault_dir: Path, markdown: str) -> tuple[str, str]:
    frontmatter, body = _parse_frontmatter(markdown)
    github_repo_base = _infer_github_repo_base(frontmatter, body)
    rendered_body = _convert_box_table_fences(body, github_repo_base=github_repo_base)
    rendered_body = _rewrite_local_image_links(vault_dir, rendered_body)
    rendered_body = _replace_wikilinks_with_markdown_links(vault_dir, rendered_body)
    rendered_body = _linkify_related_knowledge_section(vault_dir, rendered_body)
    rendered_body = _linkify_keywords(rendered_body).strip()
    if not rendered_body:
        html_body = "<p class='muted'>Empty note.</p>"
    else:
        html_body = _MARKDOWN_RENDERER.render(rendered_body)
    return _render_frontmatter(frontmatter), html_body


def _render_note_page(vault_dir: Path, relative_path: str, markdown: str, payload: dict | None = None) -> str:
    frontmatter_html, note_html = _render_markdown_note(vault_dir, markdown)
    source_note = None
    derived_notes: list[dict[str, str]] = []
    production_chain = None
    if payload:
        source_note = payload.get("provenance", {}).get("original_source_note")
        derived_notes = payload.get("provenance", {}).get("derived_deep_dives", [])
        production_chain = payload.get("production_chain")
    provenance_html = ""
    if source_note:
        provenance_html = (
            "<section class='card'>"
            "<h2>Provenance</h2>"
            "<dl class='meta-list'>"
            "<div><dt>Original Source Note</dt><dd>"
            f'<a href="{escape(_note_href(source_note["path"]))}">{escape(source_note["title"])}</a>'
            f"<div class='muted'>{escape(source_note['path'])}</div>"
            "</dd></div>"
            "</dl>"
            "</section>"
        )
    if derived_notes:
        derived_list = "".join(
            f'<li><a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a>'
            f"<div class='muted'>{escape(item['path'])}</div></li>"
            for item in derived_notes
        )
        provenance_html += (
            "<section class='card'>"
            "<h2>Derived Deep Dives</h2>"
            f"<ul class='list-tight'>{derived_list}</ul>"
            "</section>"
        )
    production_chain_html = ""
    if production_chain:
        production_chain_html = (
            "<section class='card'>"
            "<h2>Production Chain</h2>"
            "<dl class='meta-list'>"
            f"<div><dt>Current Note</dt><dd>{escape(production_chain['note']['title'])}<div class='muted'>{escape(production_chain['note']['path'])}</div></dd></div>"
            f"<div><dt>Source Notes</dt><dd>{_render_named_note_links(production_chain['source_notes'])}</dd></div>"
            f"<div><dt>Deep Dives</dt><dd>{_render_named_note_links(production_chain['deep_dives'])}</dd></div>"
            f"<div><dt>Derived Objects</dt><dd>{_render_object_links(production_chain['objects'])}</dd></div>"
            f"<div><dt>Atlas / MOC Reach</dt><dd>{_render_named_note_links(production_chain['atlas_pages'])}</dd></div>"
            "</dl>"
            "</section>"
        )
    return _layout(
        f"Markdown Note: {relative_path}",
        (
            "<section class='hero'>"
            "<h1>Markdown Note</h1>"
            f"<p class='muted'>{escape(relative_path)}</p>"
            "</section>"
            f"{frontmatter_html}"
            f"{provenance_html}"
            f"{production_chain_html}"
            f"<section class='card'>{note_html}</section>"
        ),
    )


def _render_search_page(payload: dict) -> str:
    query = payload["query"]
    object_items = "".join(
        f'<li><a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a> '
        f'<span class="muted">({escape(item["object_id"])})</span></li>'
        for item in payload["objects"]
    ) or "<li class='muted'>No object hits.</li>"
    note_items = "".join(
        f'<li><a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a> '
        f'<span class="pill">{escape(item["note_type"])}</span></li>'
        for item in payload["notes"]
    ) or "<li class='muted'>No note hits.</li>"
    return _layout(
        f"Search: {query}",
        (
            "<h1>Search</h1>"
            "<form method='get' action='/search'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Search vault' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['object_count']} object hits, {payload['note_count']} note hits.</p>"
            "<section class='grid two-col'>"
            f"<section class='card'><h2>Objects</h2><ul class='list-tight'>{object_items}</ul></section>"
            f"<section class='card'><h2>Notes</h2><ul class='list-tight'>{note_items}</ul></section>"
            "</section>"
        ),
    )


def _render_named_note_links(items: list[dict[str, str]]) -> str:
    if not items:
        return "<span class='muted'>None</span>"
    return ", ".join(
        f'<a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a>' for item in items
    )


def _render_object_links(items: list[dict[str, str]]) -> str:
    if not items:
        return "<span class='muted'>None</span>"
    return ", ".join(
        f'<a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a>'
        for item in items
    )


def _render_review_context_card(context: dict[str, object], *, title: str = "Review Context") -> str:
    latest_event_date = str(context.get("latest_event_date") or "")
    latest_event_html = escape(latest_event_date) if latest_event_date else "<span class='muted'>None</span>"
    stale_summary_ids = ", ".join(str(item) for item in context.get("stale_summary_object_ids", [])) or "None"
    contradiction_object_ids = ", ".join(str(item) for item in context.get("contradiction_object_ids", [])) or "None"
    return (
        "<section class='card'>"
        f"<h2>{escape(title)}</h2>"
        "<dl class='meta-list'>"
        f"<div><dt>Objects in scope</dt><dd>{int(context.get('object_count', 0))}</dd></div>"
        f"<div><dt>Source notes</dt><dd>{int(context.get('source_note_count', 0))}</dd></div>"
        f"<div><dt>Atlas / MOC pages</dt><dd>{int(context.get('moc_count', 0))}</dd></div>"
        f"<div><dt>Open contradictions</dt><dd>{int(context.get('open_contradiction_count', 0))}</dd></div>"
        f"<div><dt>Total contradictions</dt><dd>{int(context.get('contradiction_count', 0))}</dd></div>"
        f"<div><dt>Stale summaries</dt><dd>{int(context.get('stale_summary_count', 0))}</dd></div>"
        f"<div><dt>Latest event date</dt><dd>{latest_event_html}</dd></div>"
        f"<div><dt>Contradiction objects</dt><dd>{escape(contradiction_object_ids)}</dd></div>"
        f"<div><dt>Stale summary objects</dt><dd>{escape(stale_summary_ids)}</dd></div>"
        "</dl>"
        "</section>"
    )


def _render_review_history(items: list[dict[str, object]], *, title: str = "Review History") -> str:
    if not items:
        return (
            "<section class='card'>"
            f"<h2>{escape(title)}</h2>"
            "<p class='muted'>No recent review actions recorded for this scope.</p>"
            "</section>"
        )
    rows = "".join(
        "<li>"
        f"<span class='pill'>{escape(str(item['event_type']))}</span> "
        f"{escape(str(item['timestamp']))}"
        + (
            f"<div class='muted'>Status: {escape(str(item['status']))}</div>"
            if item.get("status")
            else ""
        )
        + (
            f"<div class='muted'>Note: {escape(str(item['note']))}</div>"
            if item.get("note")
            else ""
        )
        + (
            f"<div class='muted'>Objects: {escape(', '.join(str(v) for v in item['object_ids']))}</div>"
            if item.get("object_ids")
            else ""
        )
        + (
            f"<div class='muted'>Rebuilt: {escape(', '.join(str(v) for v in item['rebuilt_object_ids']))}</div>"
            if item.get("rebuilt_object_ids")
            else ""
        )
        + "</li>"
        for item in items
    )
    return (
        "<section class='card'>"
        f"<h2>{escape(title)}</h2>"
        f"<ul class='list-tight'>{rows}</ul>"
        "</section>"
    )


def _render_production_summary_card(summary: dict[str, object], *, title: str = "Production Contribution") -> str:
    signal_items = "".join(
        f"<li>{escape(str(signal['label']))}: {int(signal['count'])}</li>"
        for signal in summary["signals"]
    ) or "<li class='muted'>No production-chain gaps surfaced for this scope.</li>"
    count_items = "".join(
        f"<li>{escape(label)}: {int(summary['counts'][key])}</li>"
        for key, label in (
            ("source_notes", "Source notes"),
            ("deep_dives", "Deep dives"),
            ("atlas_pages", "Atlas / MOC pages"),
        )
    )
    return (
        "<section class='card'>"
        f"<h2>{escape(title)}</h2>"
        "<dl class='meta-list'>"
        f"<div><dt>Objects in scope</dt><dd>{int(summary['object_count'])}</dd></div>"
        f"<div><dt>Top Source Notes</dt><dd>{_render_named_note_links(summary['top_source_notes'])}</dd></div>"
        f"<div><dt>Top Deep Dives</dt><dd>{_render_named_note_links(summary['top_deep_dives'])}</dd></div>"
        f"<div><dt>Atlas / MOC Reach</dt><dd>{_render_named_note_links(summary['top_atlas_pages'])}</dd></div>"
        "</dl>"
        f"<ul class='list-tight'>{count_items}{signal_items}</ul>"
        "</section>"
    )


def _render_dashboard(payload: dict) -> str:
    object_items = "".join(
        f'<li><a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a></li>'
        for item in payload["objects"]["items"]
    ) or "<li>None</li>"
    contradiction_items = "".join(
        f'<li><span class="pill">{escape(item["status"])}</span>{escape(item["subject_key"])}</li>'
        for item in payload["contradictions"]["items"]
    ) or "<li>None</li>"
    event_items = "".join(
        f"<li>{escape(item['event_date'])} - "
        f'<a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a></li>'
        for item in payload["events"]["items"]
    ) or "<li>None</li>"
    stale_summary_items = "".join(
        f'<li><a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a> '
        f"<span class='muted'>({escape(item['summary_text'])})</span></li>"
        for item in payload["stale_summaries"]["items"]
    ) or "<li>None</li>"
    production_gap_items = "".join(
        f'<li><span class="pill">{escape(item["stage_label"].replace("_", " "))}</span> '
        f'<a href="{escape(_note_href(item["note_path"]))}">{escape(item["title"])}</a>'
        f"<div class='muted'>Missing: {escape(item['detail'])}</div></li>"
        for item in payload["production"]["weak_points"]
    ) or "<li class='muted'>No production-chain weak points surfaced.</li>"
    signal_items = "".join(
        f'<li><span class="pill">{escape(item["signal_type"])}</span> '
        f'<a href="{escape(item["source_path"])}">{escape(item["title"])}</a>'
        f"<div class='muted'>{escape(item['detail'])}</div></li>"
        for item in payload["signals"]["items"]
    ) or "<li class='muted'>No active signals surfaced.</li>"
    priority_items = "".join(
        f'<li><span class="pill">{escape(item["kind"].replace("_", " "))}</span> '
        f'<a href="{escape(item["path"])}">{escape(item["label"])}</a>'
        f"<div class='muted'>{escape(item['detail'])}</div></li>"
        for item in payload["priorities"]
    ) or "<li class='muted'>No urgent maintenance items surfaced.</li>"
    return _layout(
        "OpenClaw Truth UI",
        (
            "<section class='hero'>"
            "<h1>OpenClaw Truth UI</h1>"
            "<p class='muted'>Read-only browser over <code>knowledge.db</code>. JSON APIs remain available at <code>/api/*</code>, including <code>/api/objects</code>.</p>"
            "</section>"
            "<section class='grid stats'>"
            "<div class='card'><h2>Objects Indexed</h2>"
            f"<p>{payload['objects']['count']}</p></div>"
            "<div class='card'><h2>Contradictions Open</h2>"
            f"<p>{payload['contradictions']['open_count']}</p></div>"
            "<div class='card'><h2>Recent Events</h2>"
            f"<p>{payload['events']['count']}</p></div>"
            "<div class='card'><h2>Stale Summaries</h2>"
            f"<p>{payload['stale_summaries']['count']}</p></div>"
            "<div class='card'><h2>Signals</h2>"
            f"<p>{payload['signals']['count']}</p></div>"
            "</section>"
            "<section class='grid two-col'>"
            "<div class='section-stack'>"
            f"<section class='card'><h2>Needs Attention Now</h2><ul class='list-tight'>{priority_items}</ul></section>"
            f"<section class='card'><h2>Recent Objects</h2><ul class='list-tight'>{object_items}</ul></section>"
            f"<section class='card'><h2>Recent Events</h2><ul class='list-tight'>{event_items}</ul></section>"
            f"<section class='card'><h2><a href='/summaries'>Stale Summaries</a></h2><ul class='list-tight'>{stale_summary_items}</ul></section>"
            "</div>"
            "<div class='section-stack'>"
            f"<section class='card'><h2><a href='/signals'>Signals</a></h2><ul class='list-tight'>{signal_items}</ul></section>"
            f"<section class='card'><h2><a href='/production'>Production Weak Points</a></h2><ul class='list-tight'>{production_gap_items}</ul></section>"
            f"<section class='card'><h2>Contradiction Queue</h2><ul class='list-tight'>{contradiction_items}</ul></section>"
            f"{_render_review_history(payload['recent_review_actions'], title='Recent Review Actions')}"
            "</div>"
            "</section>"
        ),
    )


def _render_objects_index(payload: dict) -> str:
    query = payload.get("query", "")
    items = "".join(
        f'<li><a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a> '
        f'<span class="muted">({escape(item["object_id"])})</span></li>'
        for item in payload["items"]
    )
    return _layout(
        "Objects",
        (
            "<h1>Objects</h1>"
            "<form method='get' action='/objects'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Search objects' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} objects in current page.</p>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_object_page(payload: dict) -> str:
    evergreen_path = payload["provenance"]["evergreen_path"]
    evergreen_html = (
        f'<a href="{escape(_note_href(evergreen_path))}">{escape(evergreen_path)}</a>'
        if evergreen_path
        else "<span class='muted'>None</span>"
    )
    canonical_path = payload["context"]["canonical_path"]
    canonical_path_html = (
        f'<a href="{escape(_note_href(canonical_path))}">{escape(canonical_path)}</a>'
        if canonical_path
        else "<span class='muted'>None</span>"
    )
    claims = "".join(f"<li>{escape(item['claim_text'])}</li>" for item in payload["claims"]) or "<li>None</li>"
    relations = "".join(
        f'<li><a href="/object?id={escape(item["target_object_id"])}">{escape(item.get("target_title", item["target_object_id"]))}</a>'
        f' <span class="muted">({escape(item["relation_type"])})</span></li>'
        for item in payload["relations"]
    ) or "<li>None</li>"
    contradictions = "".join(
        f'<li><span class="pill">{escape(item["status"])}</span>{escape(item["subject_key"])}</li>'
        for item in payload["contradictions"]
    ) or "<li>None</li>"
    stale_summary_signals = "".join(
        f"<li>{escape(reason)}</li>"
        for item in payload["stale_summary_details"]
        for reason in item["reason_texts"]
    ) or "<li class='muted'>No stale summary signals for this object.</li>"
    source_notes = "".join(
        f'<li><a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a> '
        f"<span class='muted'>({escape(item['note_type'])})</span></li>"
        for item in payload["provenance"]["source_notes"]
    ) or "<li>None</li>"
    mocs = "".join(
        f'<li><a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a></li>'
        for item in payload["provenance"]["mocs"]
    ) or "<li>None</li>"
    summary_text = payload["summary"]["summary_text"] if payload["summary"] else ""
    section_nav = "".join(
        f'<a href="{escape(item["href"])}">{escape(item["label"])}</a>' for item in payload["section_nav"]
    )
    contradiction_form = (
        "<form method='post' action='/contradictions/resolve' class='link-row'>"
        + "".join(
            f"<input type='hidden' name='contradiction_id' value='{escape(contradiction_id)}' />"
            for contradiction_id in payload["open_contradiction_ids"]
        )
        + "<select name='status'>"
        + "<option value='resolved_keep_positive'>resolved_keep_positive</option>"
        + "<option value='resolved_keep_negative'>resolved_keep_negative</option>"
        + "<option value='dismissed'>dismissed</option>"
        + "<option value='needs_human'>needs_human</option>"
        + "</select>"
        + "<input type='text' name='note' placeholder='Resolution note' />"
        + "<label><input type='checkbox' name='rebuild_summaries' value='1' /> rebuild summaries</label>"
        + "<button type='submit'>Resolve Open Contradictions</button>"
        + "</form>"
        if payload["open_contradiction_ids"]
        else "<p class='muted'>No open contradictions on this object.</p>"
    )
    summary_form = (
        "<form method='post' action='/summaries/rebuild' class='link-row'>"
        + f"<input type='hidden' name='object_id' value='{escape(payload['object']['object_id'])}' />"
        + "<button type='submit'>Rebuild This Summary</button>"
        + "</form>"
        if payload["stale_summary_details"]
        else "<p class='muted'>No stale summary action needed for this object.</p>"
    )
    return _layout(
        f"Object: {payload['object']['title']}",
        (
            f"<section class='hero'><h1>Object: {escape(payload['object']['title'])}</h1>"
            f"<p class='muted'>{escape(payload['object']['object_id'])}</p>"
            "<div class='link-row'>"
            f"<a href='{escape(payload['links']['topic_path'])}'>Explore topic</a>"
            f"<a href='{escape(payload['links']['events_path'])}'>Related events</a>"
            f"<a href='{escape(payload['links']['contradictions_path'])}'>Contradictions</a>"
            f"<a href='{escape(payload['links']['summaries_path'])}'>Stale summaries</a>"
            f"<a href='/deep-dives?q={escape(payload['object']['object_id'])}'>Source deep dives</a>"
            f"<a href='/atlas?q={escape(payload['object']['object_id'])}'>Atlas / MOC</a>"
            "</div></section>"
            f"<nav class='subnav'>{section_nav}</nav>"
            "<section class='grid stats'>"
            f"<div class='card'><h2>Claims</h2><p>{payload['claim_count']}</p></div>"
            f"<div class='card'><h2>Relations</h2><p>{payload['relation_count']}</p></div>"
            f"<div class='card'><h2>Contradictions</h2><p>{payload['contradiction_count']}</p></div>"
            "</section>"
            "<section class='grid two-col'>"
            "<div class='section-stack'>"
            f"<section id='summary' class='card'><h2>Compiled Summary</h2><p>{escape(summary_text)}</p></section>"
            f"<section id='claims' class='card'><h2>Claims</h2><ul class='list-tight'>{claims}</ul></section>"
            "</div>"
            "<div class='section-stack'>"
            f"{_render_review_context_card(payload['review_context'])}"
            f"{_render_review_history(payload['review_history'])}"
            "<section class='card'><h2>Quick Maintenance</h2>"
            f"{contradiction_form}"
            f"{summary_form}"
            "</section>"
            "<section class='card'><h2>Context</h2><dl class='meta-list'>"
            f"<div><dt>Object Kind</dt><dd>{escape(payload['context']['object_kind'])}</dd></div>"
            f"<div><dt>Source Slug</dt><dd>{escape(payload['context']['source_slug'])}</dd></div>"
            f"<div><dt>Canonical Path</dt><dd>{canonical_path_html}</dd></div>"
            "</dl></section>"
            "<section class='card'><h2>Provenance</h2><dl class='meta-list'>"
            f"<div><dt>Evergreen Markdown</dt><dd>{evergreen_html}</dd></div>"
            f"<div><dt>Source Notes</dt><dd><ul class='list-tight'>{source_notes}</ul></dd></div>"
            f"<div><dt>Atlas / MOC</dt><dd><ul class='list-tight'>{mocs}</ul></dd></div>"
            "</dl></section>"
            "<section class='card'><h2>Production Chain</h2><dl class='meta-list'>"
            f"<div><dt>Source Notes</dt><dd>{_render_named_note_links(payload['production_chain']['source_notes'])}</dd></div>"
            f"<div><dt>Source Deep Dives</dt><dd>{_render_named_note_links(payload['production_chain']['deep_dives'])}</dd></div>"
            f"<div><dt>Evergreen Note</dt><dd>{evergreen_html}</dd></div>"
            f"<div><dt>Atlas / MOC Reach</dt><dd>{_render_named_note_links(payload['production_chain']['atlas_pages'])}</dd></div>"
            "</dl></section>"
            f"<section id='relations' class='card'><h2>Relations</h2><ul class='list-tight'>{relations}</ul></section>"
            f"<section id='contradictions' class='card'><h2>Contradictions</h2><ul class='list-tight'>{contradictions}</ul></section>"
            f"<section class='card'><h2>Stale Summary Signals</h2><ul class='list-tight'>{stale_summary_signals}</ul></section>"
            "</div>"
            "</section>"
        ),
    )


def _render_topic_page(payload: dict) -> str:
    neighbors = "".join(
        f'<li><a href="/object?id={escape(item["object_id"])}">{escape(item["title"])}</a></li>'
        for item in payload["neighbors"]
    ) or "<li>None</li>"
    mocs = "".join(
        f"<li>{escape(item['title'])}</li>" for item in payload["provenance"]["mocs"]
    ) or "<li>None</li>"
    summary_form = (
        "<form method='post' action='/summaries/rebuild' class='link-row'>"
        + "".join(
            f"<input type='hidden' name='object_id' value='{escape(object_id)}' />"
            for object_id in payload["scoped_stale_summary_ids"]
        )
        + "<button type='submit'>Rebuild Scoped Summaries</button>"
        + "</form>"
        if payload["scoped_stale_summary_ids"]
        else "<p class='muted'>No stale summaries in this topic scope.</p>"
    )
    contradiction_entry = (
        "<div class='link-row'>"
        + f"<a href='{escape(payload['links']['contradictions_path'])}'>Review scoped contradictions</a>"
        + "</div>"
        if payload["scoped_open_contradiction_ids"]
        else "<p class='muted'>No open contradictions in this topic scope.</p>"
    )
    return _layout(
        f"Topic: {payload['center']['title']}",
        (
            f"<section class='hero'><h1>Topic: {escape(payload['center']['title'])}</h1>"
            f"<p class='muted'>{payload['neighbor_count']} neighbors, {payload['edge_count']} edges.</p>"
            "<div class='link-row'>"
            f"<a href='{escape(payload['links']['center_object_path'])}'>Open center object</a>"
            f"<a href='{escape(payload['links']['events_path'])}'>Related events</a>"
            f"<a href='{escape(payload['links']['contradictions_path'])}'>Contradictions</a>"
            f"<a href='{escape(payload['links']['summaries_path'])}'>Stale summaries</a>"
            f"<a href='/deep-dives?q={escape(payload['center']['object_id'])}'>Source deep dives</a>"
            f"<a href='/atlas?q={escape(payload['center']['object_id'])}'>Atlas / MOC</a>"
            "</div></section>"
            "<section class='grid two-col'>"
            f"<section class='card'><h2>Center Summary</h2><p>{escape(payload['center_summary'])}</p></section>"
            f"<section class='card'><h2>Neighbors</h2><ul class='list-tight'>{neighbors}</ul></section>"
            f"<section class='card'><h2>Atlas / MOC</h2><ul class='list-tight'>{mocs}</ul></section>"
            f"{_render_production_summary_card(payload['production_summary'])}"
            f"{_render_review_context_card(payload['review_context'])}"
            f"{_render_review_history(payload['review_history'])}"
            "<section class='card'><h2>Quick Maintenance</h2>"
            f"{contradiction_entry}"
            f"{summary_form}"
            "</section>"
            "</section>"
        ),
    )


def _render_events_page(payload: dict) -> str:
    query = payload.get("query", "")
    limit_note = (
        f" Showing the most recent {payload['limit']} timeline rows in this dossier window."
        if payload.get("is_limited")
        else ""
    )
    type_breakdown = "".join(
        f"<span class='pill'>{escape(kind.replace('_', ' '))}: {count}</span>"
        for kind, count in payload["event_type_counts"].items()
    )
    timeline_contract = payload["timeline_contract"]
    timeline_contract_items = (
        f"<li>Timeline kind: {escape(timeline_contract['timeline_kind'])}</li>"
        + "".join(
            f"<li>Row type {escape(str(row_type))}: {count}</li>"
            for row_type, count in timeline_contract["row_type_counts"].items()
        )
        + "".join(
            f"<li>Semantic role {escape(str(role))}: {count}</li>"
            for role, count in timeline_contract["semantic_roles"].items()
        )
    )
    model_notes = "".join(f"<li>{escape(note)}</li>" for note in payload["model_notes"])
    date_nav = "".join(
        f"<a href='#date-{escape(section['date'])}'>{escape(section['date'])}</a>"
        for section in payload["cluster_sections"]
    )
    events = "".join(
        f'<section id="date-{escape(section["date"])}" class="card"><h2>{escape(section["date"])}</h2><ul class="list-tight">'
        + "".join(
            (
                "<li>"
                + f'<a href="{escape(item["object_path"])}">{escape(item["title"])}</a>'
                + f" <span class='pill'>{item['row_count']} timeline rows</span>"
                + (
                    f" <span class='muted'>({escape(', '.join(item['event_labels']))})</span>"
                    if item["event_labels"]
                    else ""
                )
                + (
                    f"<div class='muted'>Anchors: {escape(', '.join(item['timeline_anchor_labels']))}</div>"
                    if item["timeline_anchor_labels"]
                    else ""
                )
                + (
                    f"<div class='muted'>Evergreen: <a href=\"{escape(_note_href(item['provenance']['evergreen_path']))}\">{escape(item['provenance']['evergreen_path'])}</a></div>"
                    if item["provenance"]["evergreen_path"]
                    else "<div class='muted'>Evergreen: <span class='muted'>None</span></div>"
                )
                + f"<div class='muted'>Source Notes: {_render_named_note_links(item['provenance']['source_notes'])}</div>"
                + f"<div class='muted'>Atlas / MOC: {_render_named_note_links(item['provenance']['mocs'])}</div>"
                + "<div class='link-row'>"
                + f"<a href='{escape(item['review_links']['topic_path'])}'>Topic</a>"
                + f"<a href='{escape(item['review_links']['contradictions_path'])}'>Contradictions</a>"
                + f"<a href='{escape(item['review_links']['summaries_path'])}'>Stale summaries</a>"
                + "</div>"
                + "</li>"
            )
            for item in section["clusters"]
        )
        + "</ul></section>"
        for section in payload["cluster_sections"]
    ) or "<li>None</li>"
    summary_form = (
        "<form method='post' action='/summaries/rebuild' class='link-row'>"
        + "".join(
            f"<input type='hidden' name='object_id' value='{escape(object_id)}' />"
            for object_id in payload["scoped_stale_summary_ids"]
        )
        + "<button type='submit'>Rebuild Visible Summaries</button>"
        + "</form>"
        if payload["scoped_stale_summary_ids"]
        else "<p class='muted'>No stale summaries in the visible event scope.</p>"
    )
    contradiction_entry = (
        f"<div class='link-row'><a href='/contradictions?q={escape(query)}'>Review visible contradictions</a></div>"
        if payload["scoped_open_contradiction_ids"] and query
        else (
            "<div class='link-row'><a href='/contradictions'>Review visible contradictions</a></div>"
            if payload["scoped_open_contradiction_ids"]
            else "<p class='muted'>No open contradictions in the visible event scope.</p>"
        )
    )
    return _layout(
        "Event Dossier",
        (
            "<h1>Event Dossier</h1>"
            "<p class='muted'>A timeline-oriented view over dated truth objects, not a separate event object model.</p>"
            "<form method='get' action='/events'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter events' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['cluster_count']} event clusters from {payload['event_count']} timeline rows across {len(payload['dates'])} dates.{escape(limit_note)}</p>"
            f"<div class='link-row'>{type_breakdown}</div>"
            f"{_render_production_summary_card(payload['production_summary'])}"
            f"{_render_review_context_card(payload['review_context'])}"
            f"{_render_review_history(payload['review_history'])}"
            "<section class='card'><h2>Quick Maintenance</h2>"
            f"{contradiction_entry}"
            f"{summary_form}"
            "</section>"
            "<section class='card'><h2>Event Clusters</h2><p class='muted'>Rows for the same object and date are grouped into a single cluster so the dossier reads as an object timeline instead of raw timeline rows.</p></section>"
            f"<section class='card'><h2>Timeline Contract</h2><ul class='list-tight'>{timeline_contract_items}</ul></section>"
            f"<section class='card'><h2>Model Notes</h2><ul class='list-tight'>{model_notes}</ul></section>"
            f"<nav class='subnav'>{date_nav}</nav>"
            f"{events}"
        ),
    )


def _render_atlas_page(payload: dict) -> str:
    query = payload.get("query", "")
    limit_note = (
        f" Showing the most recent {payload['limit']} atlas pages in this browser window."
        if payload.get("is_limited")
        else ""
    )
    items = "".join(
        "<li>"
        f'<a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a>'
        + f" <span class='pill'>{item['member_count']} objects</span>"
        + f" <span class='pill'>{len(item['deep_dives'])} deep dives</span>"
        + f" <span class='pill'>{len(item['source_notes'])} source notes</span>"
        + (
            " <span class='muted'>"
            + ", ".join(
                f'<a href="/object?id={escape(member["object_id"])}">{escape(member["title"])}</a>'
                for member in item["members"]
            )
            + "</span>"
        )
        + (
            f"<div class='muted'>Preview: {escape(', '.join(item['preview_titles']))}</div>"
            if item["preview_titles"]
            else ""
        )
        + f"<div class='muted'>Source Notes: {_render_named_note_links(item['source_notes'])}</div>"
        + f"<div class='muted'>Deep Dives: {_render_named_note_links(item['deep_dives'])}</div>"
        + "</li>"
        for item in payload["items"]
    ) or "<li>None</li>"
    return _layout(
        "Atlas / MOC Browser",
        (
            "<h1>Atlas / MOC Browser</h1>"
            "<form method='get' action='/atlas'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter MOCs or objects' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} atlas/moc pages linked to indexed objects.{escape(limit_note)}</p>"
            "<section class='card'><h2>Contribution Summary</h2><p class='muted'>Each Atlas page now shows the source notes and deep dives that feed the objects it organizes.</p></section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_derivations_page(payload: dict) -> str:
    query = payload.get("query", "")
    limit_note = (
        f" Showing the most recent {payload['limit']} deep dives in this browser window."
        if payload.get("is_limited")
        else ""
    )
    items = "".join(
        "<li>"
        f'<a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a>'
        + f" <span class='pill'>{item['derived_object_count']} derived objects</span>"
        + f" <span class='pill'>{len(item['source_notes'])} source notes</span>"
        + f" <span class='pill'>{len(item['atlas_pages'])} atlas pages</span>"
        + (
            " <span class='muted'>"
            + ", ".join(
                f'<a href="/object?id={escape(member["object_id"])}">{escape(member["title"])}</a>'
                for member in item["derived_objects"]
            )
            + "</span>"
        )
        + (
            f"<div class='muted'>Preview: {escape(', '.join(item['preview_titles']))}</div>"
            if item["preview_titles"]
            else ""
        )
        + f"<div class='muted'>Source Notes: {_render_named_note_links(item['source_notes'])}</div>"
        + f"<div class='muted'>Atlas / MOC Reach: {_render_named_note_links(item['atlas_pages'])}</div>"
        + "</li>"
        for item in payload["items"]
    ) or "<li>None</li>"
    return _layout(
        "Deep Dive Derivations",
        (
            "<h1>Deep Dive Derivations</h1>"
            "<form method='get' action='/deep-dives'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter deep dives or objects' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} deep dive notes linked to indexed objects.{escape(limit_note)}</p>"
            "<section class='card'><h2>Contribution Summary</h2><p class='muted'>Each deep dive now shows upstream source notes and downstream Atlas reach, not just derived objects.</p></section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_production_browser_page(payload: dict) -> str:
    query = payload.get("query", "")
    limit_note = (
        f" Showing the most recent {payload['limit']} production-chain entries in this browser window."
        if payload.get("is_limited")
        else ""
    )
    items = "".join(
        "<li>"
        f'<a href="{escape(_note_href(item["path"]))}">{escape(item["title"])}</a>'
        + f" <span class='pill'>{escape(item['stage_label'].replace('_', ' '))}</span>"
        + f" <span class='pill'>{item['traceability']['counts']['deep_dives']} deep dives</span>"
        + f" <span class='pill'>{item['traceability']['counts']['objects']} objects</span>"
        + f" <span class='pill'>{item['traceability']['counts']['atlas_pages']} atlas pages</span>"
        + f"<div class='muted'>Deep Dives: {_render_named_note_links(item['traceability']['deep_dives'])}</div>"
        + f"<div class='muted'>Objects: {_render_object_links(item['traceability']['objects'])}</div>"
        + f"<div class='muted'>Atlas / MOC Reach: {_render_named_note_links(item['traceability']['atlas_pages'])}</div>"
        + "</li>"
        for item in payload["items"]
    ) or "<li class='muted'>No production chains found.</li>"
    weak_points = "".join(
        "<li>"
        f'<span class="pill">{escape(item["stage_label"].replace("_", " "))}</span> '
        f'<a href="{escape(_note_href(item["note_path"]))}">{escape(item["title"])}</a>'
        f"<div class='muted'>Missing: {escape(item['detail'])}</div>"
        "</li>"
        for item in payload["weak_points"]
    ) or "<li class='muted'>No production-chain weak points surfaced.</li>"
    return _layout(
        "Production Browser",
        (
            "<h1>Production Browser</h1>"
            "<form method='get' action='/production'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter source notes, deep dives, objects, or atlas' /> "
            "<button type='submit'>Search</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} production-chain entries. {payload['counts']['source_notes']} source notes and {payload['counts']['deep_dives']} deep dives.{escape(limit_note)}</p>"
            "<section class='card'><h2>Chain Model</h2><p class='muted'>This browser shows the current upstream/downstream chain from traceable notes into deep dives, evergreen objects, and Atlas placement.</p></section>"
            f"<section class='card'><h2>Weak Points</h2><ul class='list-tight'>{weak_points}</ul></section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_signals_page(payload: dict) -> str:
    query = payload.get("query", "")
    selected_type = payload.get("signal_type", "")
    options = ["", *sorted(payload["signal_type_explanations"].keys())]
    option_html = "".join(
        f"<option value='{escape(option)}' {'selected' if option == selected_type else ''}>"
        f"{escape(option or 'all signal types')}</option>"
        for option in options
    )
    items = "".join(
        "<li>"
        f'<span class="pill">{escape(item["signal_type"])}</span> '
        f'<a href="{escape(item["source_path"])}">{escape(item["title"])}</a>'
        f"<div class='muted'>{escape(item['detail'])}</div>"
        + (
            "<div class='muted'>Downstream: "
            + ", ".join(
                f'<a href="{escape(effect["path"])}">{escape(effect["label"])}</a>'
                for effect in item["downstream_effects"]
            )
            + "</div>"
            if item["downstream_effects"]
            else ""
        )
        + "</li>"
        for item in payload["items"]
    ) or "<li class='muted'>No active signals found.</li>"
    explanations = "".join(
        f"<li><span class='pill'>{escape(signal_type)}</span> {escape(text)}</li>"
        for signal_type, text in payload["signal_type_explanations"].items()
    )
    return _layout(
        "Active Signals",
        (
            "<h1>Active Signals</h1>"
            "<form method='get' action='/signals' class='link-row'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Search signals' />"
            f"<select name='type'>{option_html}</select>"
            "<button type='submit'>Filter</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} active signals.</p>"
            f"<section class='card'><h2>Signal Types</h2><ul class='list-tight'>{explanations}</ul></section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_briefing_page(payload: dict) -> str:
    recent_signals = "".join(
        f'<li><span class="pill">{escape(item["signal_type"])}</span> '
        f'<a href="{escape(item["source_path"])}">{escape(item["title"])}</a>'
        f"<div class='muted'>{escape(item['detail'])}</div></li>"
        for item in payload["recent_signals"]
    ) or "<li class='muted'>No recent signals.</li>"
    unresolved = "".join(
        f'<li><span class="pill">{escape(item["signal_type"])}</span> '
        f'<a href="{escape(item["source_path"])}">{escape(item["title"])}</a></li>'
        for item in payload["unresolved_issues"]
    ) or "<li class='muted'>No unresolved issues.</li>"
    changed_objects = "".join(
        f'<li><a href="{escape(item["path"])}">{escape(item["title"])}</a></li>'
        for item in payload["changed_objects"]
    ) or "<li class='muted'>No recent changed objects.</li>"
    active_topics = "".join(
        f'<li><a href="{escape(item["path"])}">{escape(item["title"])}</a> '
        f"<span class='muted'>({item['signal_count']} signals)</span></li>"
        for item in payload["active_topics"]
    ) or "<li class='muted'>No active topics surfaced.</li>"
    return _layout(
        "Working Memory Snapshot",
        (
            "<h1>Working Memory Snapshot</h1>"
            f"<p class='muted'>Generated at {escape(payload['generated_at'])}. {payload['recent_signal_count']} recent signals, {payload['unresolved_issue_count']} unresolved issues.</p>"
            f"<section class='card'><h2>Recent Signals</h2><ul class='list-tight'>{recent_signals}</ul></section>"
            f"<section class='card'><h2>Unresolved Issues</h2><ul class='list-tight'>{unresolved}</ul></section>"
            f"<section class='card'><h2>Changed Objects</h2><ul class='list-tight'>{changed_objects}</ul></section>"
            f"<section class='card'><h2>Active Topics</h2><ul class='list-tight'>{active_topics}</ul></section>"
        ),
    )


def _render_contradictions_page(payload: dict) -> str:
    status = payload.get("status", "")
    query = payload.get("query", "")
    detection_notes = "".join(f"<li>{escape(note)}</li>" for note in payload["detection_notes"])
    scope_summary = payload["scope_summary"]
    scope_summary_items = (
        f"<li>Items: {scope_summary['item_count']}</li>"
        f"<li>Objects in scope: {scope_summary['object_count']}</li>"
        f"<li>Source notes in scope: {scope_summary['source_note_count']}</li>"
    )
    detection_contract = payload["detection_contract"]
    detection_contract_items = (
        f"<li>Model: {escape(detection_contract['model'])}</li>"
        + f"<li>Confidence: {escape(detection_contract['confidence'])}</li>"
        + "".join(
            f"<li>Status bucket {escape(str(bucket))}: {count}</li>"
            for bucket, count in detection_contract["status_buckets"].items()
        )
        + "".join(
            f"<li>Status {escape(str(status_name))}: {escape(text)}</li>"
            for status_name, text in detection_contract["status_explanations"].items()
        )
    )
    items = "".join(
        "<li>"
        + (
            f"<label><input type='checkbox' form='contradiction-batch-form' name='contradiction_id' value='{escape(item['contradiction_id'])}' /> batch</label> "
            if item["status"] == "open"
            else ""
        )
        + f"<span class='pill'>{escape(item['status'])}</span>{escape(item['subject_key'])}"
        + f" <span class='muted'>[{escape(item['detection_model'])} / {escape(item['detection_confidence'])} / {escape(item['status_bucket'])}]</span>"
        + f"<div class='muted'>Status Meaning: {escape(item['status_explanation'])}</div>"
        + (
            "<div class='muted'>Scope Summary: "
            + f"{item['scope_summary']['object_count']} objects, "
            + f"{item['scope_summary']['positive_claim_count']} positive claims, "
            + f"{item['scope_summary']['negative_claim_count']} negative claims, "
            + f"{item['scope_summary']['source_note_count']} source notes"
            + "</div>"
        )
        + (
            " <span class='muted'>"
            + ", ".join(
                f'<a href="{escape(link["path"])}">{escape(item["object_titles"].get(link["object_id"], link["object_id"]))}</a>'
                for link in item["object_links"]
            )
            + "</span>"
            if item["object_links"]
            else ""
        )
        + f"<div class='muted'>Source Notes: {_render_named_note_links(item['provenance']['source_notes'])}</div>"
        + f"<div class='muted'>Atlas / MOC: {_render_named_note_links(item['provenance']['mocs'])}</div>"
        + (
            "<details><summary>Ranked Evidence</summary><ol class='list-tight'>"
            + "".join(
                f"<li>#{evidence['rank']} {escape(evidence['polarity'])}: {escape(evidence['quote_text'])} "
                + f"<span class='muted'>({escape(evidence['object_title'])} / {escape(evidence['source_slug'])} / {escape(evidence['evidence_kind'])})</span></li>"
                for evidence in item["ranked_evidence"]
            )
            + "</ol></details>"
            if item["ranked_evidence"]
            else ""
        )
        + (
            "<details><summary>Claim Evidence</summary><ul class='list-tight'>"
            + "".join(
                "<li>Positive: "
                + f"{escape(claim['claim_text'])} <span class='muted'>({escape(claim['object_title'])})</span>"
                + (
                    "<ul class='list-tight'>"
                    + "".join(
                        f"<li>{escape(evidence['evidence_kind'])}: {escape(evidence['quote_text'])} <span class='muted'>({escape(evidence['source_slug'])})</span></li>"
                        for evidence in claim["evidence"]
                    )
                    + "</ul>"
                    if claim["evidence"]
                    else ""
                )
                + "</li>"
                for claim in item["positive_claims"]
            )
            + "".join(
                "<li>Negative: "
                + f"{escape(claim['claim_text'])} <span class='muted'>({escape(claim['object_title'])})</span>"
                + (
                    "<ul class='list-tight'>"
                    + "".join(
                        f"<li>{escape(evidence['evidence_kind'])}: {escape(evidence['quote_text'])} <span class='muted'>({escape(evidence['source_slug'])})</span></li>"
                        for evidence in claim["evidence"]
                    )
                    + "</ul>"
                    if claim["evidence"]
                    else ""
                )
                + "</li>"
                for claim in item["negative_claims"]
            )
            + "</ul></details>"
        )
        + (
            "<details><summary>Review History</summary><ul class='list-tight'>"
            + "".join(
                f"<li>{escape(str(history['timestamp']))} <span class='pill'>{escape(str(history['event_type']))}</span>"
                + (
                    f"<div class='muted'>Status: {escape(str(history['status']))}</div>"
                    if history.get("status")
                    else ""
                )
                + (
                    f"<div class='muted'>Note: {escape(str(history['note']))}</div>"
                    if history.get("note")
                    else ""
                )
                + "</li>"
                for history in item["review_history"]
            )
            + "</ul></details>"
            if item["review_history"]
            else ""
        )
        + (
            f"<div class='muted'>Resolution Note: {escape(item['resolution_note'])}</div>"
            if item.get("resolution_note")
            else ""
        )
        + (
            f"<div class='muted'>Resolved At: {escape(item['resolved_at'])}</div>"
            if item.get("resolved_at")
            else ""
        )
        + (
            "<form method='post' action='/contradictions/resolve' class='link-row'>"
            f"<input type='hidden' name='contradiction_id' value='{escape(item['contradiction_id'])}' />"
            "<select name='status'>"
            "<option value='resolved_keep_positive'>resolved_keep_positive</option>"
            "<option value='resolved_keep_negative'>resolved_keep_negative</option>"
            "<option value='dismissed'>dismissed</option>"
            "<option value='needs_human'>needs_human</option>"
            "</select>"
            "<input type='text' name='note' placeholder='Resolution note' />"
            "<label><input type='checkbox' name='rebuild_summaries' value='1' /> rebuild summaries</label>"
            "<button type='submit'>Resolve</button>"
            "</form>"
            if item["status"] == "open"
            else ""
        )
        + "</li>"
        for item in payload["items"]
    ) or f"<li>{escape(payload['empty_state'])}</li>"
    return _layout(
        "Contradictions",
        (
            "<h1>Contradictions</h1>"
            "<form method='get' action='/contradictions'>"
            "<select name='status'>"
            f"<option value=''{' selected' if not status else ''}>all</option>"
            f"<option value='open'{' selected' if status == 'open' else ''}>open</option>"
            f"<option value='resolved'{' selected' if status == 'resolved' else ''}>resolved</option>"
            "</select> "
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter contradictions' /> "
            "<button type='submit'>Filter</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} records, {payload['open_count']} open.</p>"
            f"<section class='card'><h2>Detection Notes</h2><ul class='list-tight'>{detection_notes}</ul></section>"
            "<section class='card'>"
            "<h2>Batch Resolve</h2>"
            "<form id='contradiction-batch-form' method='post' action='/contradictions/resolve' class='link-row'>"
            "<select name='status'>"
            "<option value='resolved_keep_positive'>resolved_keep_positive</option>"
            "<option value='resolved_keep_negative'>resolved_keep_negative</option>"
            "<option value='dismissed'>dismissed</option>"
            "<option value='needs_human'>needs_human</option>"
            "</select>"
            "<input type='text' name='note' placeholder='Resolution note for selected rows' />"
            "<label><input type='checkbox' name='rebuild_summaries' value='1' /> rebuild summaries</label>"
            "<button type='submit'>Resolve Selected</button>"
            "</form>"
            "</section>"
            f"<section class='card'><h2>Scope Summary</h2><ul class='list-tight'>{scope_summary_items}</ul></section>"
            f"<section class='card'><h2>Detection Contract</h2><ul class='list-tight'>{detection_contract_items}</ul></section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def _render_stale_summaries_page(payload: dict) -> str:
    query = payload.get("query", "")
    detection_notes = "".join(f"<li>{escape(note)}</li>" for note in payload["detection_notes"])
    items = "".join(
        "<li>"
        f"<label><input type='checkbox' form='summary-batch-form' name='object_id' value='{escape(item['object_id'])}' /> batch</label> "
        f'<a href="{escape(item["object_path"])}">{escape(item["title"])}</a> '
        f"<span class='muted'>({escape(item['object_id'])})</span>"
        f"<div class='muted'>Summary: {escape(item['summary_text'])}</div>"
        f"<div class='muted'>Outgoing relations: {item['outgoing_relation_count']}</div>"
        + (
            f"<div class='muted'>Latest event date: {escape(item['latest_event_date'])}</div>"
            if item["latest_event_date"]
            else ""
        )
        + "<ul class='list-tight'>"
        + "".join(f"<li>{escape(reason)}</li>" for reason in item["reason_texts"])
        + "</ul>"
        + (
            "<details><summary>Review History</summary><ul class='list-tight'>"
            + "".join(
                f"<li>{escape(str(history['timestamp']))} <span class='pill'>{escape(str(history['event_type']))}</span>"
                + (
                    f"<div class='muted'>Rebuilt: {escape(', '.join(str(v) for v in history['rebuilt_object_ids']))}</div>"
                    if history.get("rebuilt_object_ids")
                    else ""
                )
                + "</li>"
                for history in item["review_history"]
            )
            + "</ul></details>"
            if item["review_history"]
            else ""
        )
        + "<form method='post' action='/summaries/rebuild' class='link-row'>"
        + f"<input type='hidden' name='object_id' value='{escape(item['object_id'])}' />"
        + "<button type='submit'>Rebuild Summary</button>"
        + "</form>"
        + "</li>"
        for item in payload["items"]
    ) or "<li class='muted'>No stale summaries detected.</li>"
    return _layout(
        "Stale Summaries",
        (
            "<h1>Stale Summaries</h1>"
            "<form method='get' action='/summaries'>"
            f"<input type='text' name='q' value='{escape(query)}' placeholder='Filter stale summaries' /> "
            "<button type='submit'>Filter</button>"
            "</form>"
            f"<p class='muted'>{payload['count']} stale summary candidates.</p>"
            f"{_render_review_context_card(payload['review_context'])}"
            f"{_render_review_history(payload['review_history'])}"
            f"<section class='card'><h2>Detection Notes</h2><ul class='list-tight'>{detection_notes}</ul></section>"
            "<section class='card'>"
            "<h2>Batch Rebuild</h2>"
            "<form id='summary-batch-form' method='post' action='/summaries/rebuild' class='link-row'>"
            "<button type='submit'>Rebuild Selected</button>"
            "</form>"
            "</section>"
            f"<section class='card'><ul class='list-tight'>{items}</ul></section>"
        ),
    )


def create_server(vault_dir: Path | str, *, host: str = "127.0.0.1", port: int = 8787) -> ThreadingHTTPServer:
    resolved_vault = resolve_vault_dir(vault_dir)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args) -> None:  # pragma: no cover
            return

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path
            query = parse_qs(parsed.query)

            try:
                if path == "/":
                    payload = build_truth_dashboard_payload(resolved_vault)
                    self._write_html(_render_dashboard(payload))
                    return
                if path == "/api/objects":
                    limit = int(query.get("limit", ["100"])[0])
                    offset = int(query.get("offset", ["0"])[0])
                    q = query.get("q", [""])[0]
                    self._write_json(
                        build_objects_index_payload(resolved_vault, limit=limit, offset=offset, query=q)
                    )
                    return
                if path == "/objects":
                    limit = int(query.get("limit", ["100"])[0])
                    offset = int(query.get("offset", ["0"])[0])
                    q = query.get("q", [""])[0]
                    payload = build_objects_index_payload(
                        resolved_vault, limit=limit, offset=offset, query=q
                    )
                    self._write_html(_render_objects_index(payload))
                    return
                if path == "/api/search":
                    q = query.get("q", [""])[0]
                    self._write_json(build_search_payload(resolved_vault, query=q))
                    return
                if path == "/search":
                    q = query.get("q", [""])[0]
                    payload = build_search_payload(resolved_vault, query=q)
                    self._write_html(_render_search_page(payload))
                    return
                if path == "/api/briefing":
                    self._write_json(build_briefing_payload(resolved_vault))
                    return
                if path == "/briefing":
                    self._write_html(_render_briefing_page(build_briefing_payload(resolved_vault)))
                    return
                if path == "/api/signals":
                    q = query.get("q", [""])[0]
                    signal_type = query.get("type", [""])[0] or None
                    self._write_json(build_signal_browser_payload(resolved_vault, signal_type=signal_type, query=q))
                    return
                if path == "/signals":
                    q = query.get("q", [""])[0]
                    signal_type = query.get("type", [""])[0] or None
                    payload = build_signal_browser_payload(resolved_vault, signal_type=signal_type, query=q)
                    self._write_html(_render_signals_page(payload))
                    return
                if path == "/api/object":
                    object_id = self._required(query, "id")
                    self._write_json(build_object_page_payload(resolved_vault, object_id))
                    return
                if path == "/object":
                    object_id = self._required(query, "id")
                    payload = build_object_page_payload(resolved_vault, object_id)
                    self._write_html(_render_object_page(payload))
                    return
                if path == "/api/topic":
                    object_id = self._required(query, "id")
                    self._write_json(build_topic_overview_payload(resolved_vault, object_id))
                    return
                if path == "/topic":
                    object_id = self._required(query, "id")
                    payload = build_topic_overview_payload(resolved_vault, object_id)
                    self._write_html(_render_topic_page(payload))
                    return
                if path == "/api/events":
                    q = query.get("q", [""])[0]
                    self._write_json(build_event_dossier_payload(resolved_vault, query=q))
                    return
                if path == "/events":
                    q = query.get("q", [""])[0]
                    payload = build_event_dossier_payload(resolved_vault, query=q)
                    self._write_html(_render_events_page(payload))
                    return
                if path == "/api/atlas":
                    q = query.get("q", [""])[0]
                    self._write_json(build_atlas_browser_payload(resolved_vault, query=q))
                    return
                if path == "/atlas":
                    q = query.get("q", [""])[0]
                    payload = build_atlas_browser_payload(resolved_vault, query=q)
                    self._write_html(_render_atlas_page(payload))
                    return
                if path == "/api/deep-dives":
                    q = query.get("q", [""])[0]
                    self._write_json(build_derivation_browser_payload(resolved_vault, query=q))
                    return
                if path == "/deep-dives":
                    q = query.get("q", [""])[0]
                    payload = build_derivation_browser_payload(resolved_vault, query=q)
                    self._write_html(_render_derivations_page(payload))
                    return
                if path == "/api/production":
                    q = query.get("q", [""])[0]
                    self._write_json(build_production_browser_payload(resolved_vault, query=q))
                    return
                if path == "/production":
                    q = query.get("q", [""])[0]
                    payload = build_production_browser_payload(resolved_vault, query=q)
                    self._write_html(_render_production_browser_page(payload))
                    return
                if path == "/api/summaries":
                    q = query.get("q", [""])[0]
                    self._write_json(build_stale_summary_browser_payload(resolved_vault, query=q))
                    return
                if path == "/summaries":
                    q = query.get("q", [""])[0]
                    payload = build_stale_summary_browser_payload(resolved_vault, query=q)
                    self._write_html(_render_stale_summaries_page(payload))
                    return
                if path == "/note":
                    relative_path = self._required(query, "path")
                    _, markdown = _read_vault_note(resolved_vault, relative_path)
                    payload = build_note_page_payload(resolved_vault, note_path=relative_path)
                    self._write_html(_render_note_page(resolved_vault, relative_path, markdown, payload))
                    return
                if path == "/asset":
                    relative_path = self._required(query, "path")
                    body, content_type = _read_vault_asset(resolved_vault, relative_path)
                    self._write_bytes(body, content_type)
                    return
                if path == "/api/contradictions":
                    status = query.get("status", [""])[0] or None
                    q = query.get("q", [""])[0]
                    self._write_json(
                        build_contradiction_browser_payload(resolved_vault, status=status, query=q)
                    )
                    return
                if path == "/contradictions":
                    status = query.get("status", [""])[0] or None
                    q = query.get("q", [""])[0]
                    payload = build_contradiction_browser_payload(resolved_vault, status=status, query=q)
                    self._write_html(_render_contradictions_page(payload))
                    return
                self.send_error(404, "Not Found")
            except ValueError as exc:
                self.send_error(400, str(exc))

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path
            try:
                form = self._read_form()
                if path == "/api/contradictions/resolve":
                    self._write_json(self._resolve_contradiction_action(form))
                    return
                if path == "/contradictions/resolve":
                    self._resolve_contradiction_action(form)
                    self._redirect("/contradictions?status=resolved")
                    return
                if path == "/api/summaries/rebuild":
                    self._write_json(self._rebuild_summary_action(form))
                    return
                if path == "/summaries/rebuild":
                    self._rebuild_summary_action(form)
                    self._redirect("/summaries")
                    return
                self.send_error(404, "Not Found")
            except ValueError as exc:
                self.send_error(400, str(exc))

        def _required(self, query: dict[str, list[str]], key: str) -> str:
            values = query.get(key)
            if not values or not values[0]:
                raise ValueError(f"missing required query param: {key}")
            return values[0]

        def _read_form(self) -> dict[str, list[str]]:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length).decode("utf-8")
            return parse_qs(raw, keep_blank_values=True)

        def _form_first(self, form: dict[str, list[str]], key: str) -> str:
            values = form.get(key, [])
            return values[0] if values else ""

        def _form_all(self, form: dict[str, list[str]], key: str) -> list[str]:
            return form.get(key, [])

        def _resolve_contradiction_action(self, form: dict[str, list[str]]) -> dict[str, object]:
            contradiction_ids = [item.strip() for item in self._form_all(form, "contradiction_id") if item.strip()]
            status = self._form_first(form, "status").strip()
            note = self._form_first(form, "note").strip()
            if not contradiction_ids:
                raise ValueError("missing contradiction_id")
            if status not in {
                "resolved_keep_positive",
                "resolved_keep_negative",
                "dismissed",
                "needs_human",
            }:
                raise ValueError("invalid contradiction status")
            payload = resolve_contradictions(
                resolved_vault,
                contradiction_ids,
                status=status,
                note=note,
            )
            if payload["resolved_count"] and self._form_first(form, "rebuild_summaries") == "1":
                affected_object_ids = contradiction_object_ids(resolved_vault, payload["contradiction_ids"])
                rebuild_payload = rebuild_compiled_summaries(resolved_vault, object_ids=affected_object_ids)
                payload["rebuilt_summary_count"] = rebuild_payload["objects_rebuilt"]
                payload["rebuilt_object_ids"] = rebuild_payload["object_ids"]
            else:
                affected_object_ids = contradiction_object_ids(resolved_vault, payload["contradiction_ids"])
                payload["rebuilt_summary_count"] = 0
                payload["rebuilt_object_ids"] = []
            if payload["resolved_count"]:
                payload["object_ids"] = affected_object_ids
                record_review_action(
                    resolved_vault,
                    event_type="ui_contradictions_resolved",
                    slug=affected_object_ids[0] if affected_object_ids else "",
                    payload={
                        "object_ids": affected_object_ids,
                        "contradiction_ids": payload["contradiction_ids"],
                        "status": status,
                        "note": note,
                        "rebuilt_object_ids": payload["rebuilt_object_ids"],
                    },
                )
            return payload

        def _rebuild_summary_action(self, form: dict[str, list[str]]) -> dict[str, object]:
            object_ids = [item.strip() for item in self._form_all(form, "object_id") if item.strip()]
            if not object_ids:
                raise ValueError("missing object_id")
            payload = rebuild_compiled_summaries(resolved_vault, object_ids=object_ids)
            if payload["objects_rebuilt"]:
                record_review_action(
                    resolved_vault,
                    event_type="ui_summaries_rebuilt",
                    slug=payload["object_ids"][0] if payload["object_ids"] else "",
                    payload={
                        "object_ids": payload["object_ids"],
                        "objects_rebuilt": payload["objects_rebuilt"],
                        "rebuilt_object_ids": payload["object_ids"],
                    },
                )
            return payload

        def _write_json(self, payload: dict) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _write_html(self, html: str) -> None:
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _write_bytes(self, body: bytes, content_type: str) -> None:
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _redirect(self, location: str) -> None:
            self.send_response(303)
            self.send_header("Location", location)
            self.send_header("Content-Length", "0")
            self.end_headers()

    return ThreadingHTTPServer((host, port), Handler)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a minimal local UI over knowledge.db")
    parser.add_argument("--vault-dir", type=Path, default=None, help="Vault directory")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args(argv)

    resolved_vault = resolve_vault_dir(args.vault_dir)
    server = create_server(resolved_vault, host=args.host, port=args.port)
    try:
        build_objects_index_payload(resolved_vault, limit=1, offset=0)
        ensure_signal_ledger_synced(resolved_vault)
    except Exception as exc:
        print(f"ui server preflight failed: {exc}", file=sys.stderr)
        server.server_close()
        return 1

    print(json.dumps({"host": args.host, "port": args.port, "vault_dir": str(resolved_vault)}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:  # pragma: no cover
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
