"""
Data models for the Enrichment Agent.
"""
import os
from typing_extensions import Any, TypedDict

from pydantic import BaseModel, Field, field_validator, model_validator


class EnrichmentConfig(BaseModel):
    """Configuration for the Enrichment Agent."""
    provider: str = Field(os.getenv("LLM_PROVIDER", "openai"), description="LLM provider to use")
    model: str = Field(os.getenv("LLM_MODEL", "gpt-5-mini"), description="AI model to use")

class DataFrameColumnStats(BaseModel):
    """Model for storing statistics about a DataFrame column."""
    column_name: str = Field(..., description="Name of the column")
    data_type: str | None = Field(None, description="Data type of the column")
    null_count: int | None = Field(None, description="Number of null values")
    unique_count: int | None = Field(None, description="Number of unique values")
    mean: float | None = Field(None, description="Mean value (for numeric columns)")
    std: float | None = Field(None, description="Standard deviation (for numeric columns)")
    min_val: Any | None = Field(None, description="Minimum value")
    max_val: Any | None = Field(None, description="Maximum value")
    top_values: dict[Any, int] | None = Field(None, description="Most common values and their counts")

class DataFrameProfile(TypedDict):
    """Type definition for DataFrame profile information."""
    sample_rows: str
    columns: list[str]
    data_types: dict[str, str]
    computed_stats: dict[str, DataFrameColumnStats]  # Updated to use DataFrameColumnStats
    identical_column_pairs: list[tuple]
    shape: tuple[int, int]

class FeatureSuggestion(BaseModel):
    """Model for a single feature suggestion."""
    feature_name: str = Field(..., description="Name of the new feature")
    sql_query: str = Field(..., description="Python code for the feature transformation")
    explanation: str = Field(..., description="Explanation of the feature")
    example_output: list[str] = Field(default_factory=list, description="3-5 example values showing what the new column would look like")

class FeatureSuggestionResponse(BaseModel):
    """Response model for feature suggestions."""
    suggestions: list[FeatureSuggestion] = Field(default=list, description="List of feature suggestions")

class EnrichmentReport(BaseModel):
    """Model for enrichment operation reports."""
    report_id: str = Field(..., description="Unique identifier for the report")
    original_shape: Any = Field(..., description="Original data shape")
    enriched_shape: Any = Field(..., description="Enriched data shape")
    features_added: list[str] = Field(default_factory=list, description="Features added")
    execution_time: float | None = Field(default=None, description="Total execution time in seconds")

class EnrichmentResponse(BaseModel):
    """Response model for data enrichment operations."""
    success: bool = Field(..., description="Whether the enrichment operation was successful")
    suggestions: dict[str, Any] | None = Field(default=None, description="List of feature suggestions")
    message: str = Field(..., description="Human-readable message about the operation")
    errors: list[str] = Field(default_factory=list, description="List of errors if operation failed")

class Metadata(BaseModel):
    """Common model for metadata inputs with a name and description."""
    name: str = Field(..., min_length=1, description="Name identifier")
    description: str = Field(..., min_length=1, description="Detailed description")

class EnrichmentRequest(BaseModel):
    """Request model for data enrichment operations — validates all enrich_data() inputs."""
    data: Any = Field(..., description="Input data to be enriched (DataFrame, dict, or file path)")
    db_name: str = Field(default="database", min_length=1, description="Database name for SQL context")
    schema: str = Field(default="public", min_length=1, description="Schema name for SQL context")
    table_name: str = Field(default="table", min_length=1, description="Table name for SQL context")
    domain_metadata: Metadata = Field(default=None, description="Domain-specific metadata for enrichment context")
    entity_metadata: Metadata = Field(default=None, description="Entity-specific metadata for enrichment context")
    use_case: Metadata | None = Field(default=None, description="Business use case with name and description")
    ml_approach: Metadata = Field(default=None, description="ML approach with name and description")
    data_insights: DataFrameProfile | None = Field(default=None, description="Pre-computed DataFrame profile with column statistics")
    mode: str | None = Field(default=None, description="Enrichment mode")
    sample_rows: str | None = Field(default=None, description="Sample rows for profiling")
    parameters: dict[str, Any] | None = Field(default=None, description="Additional enrichment parameters")
    data_source: str = Field(default="snowflake", description="SQL dialect / data source")

    @field_validator("data_source")
    @classmethod
    def validate_data_source(cls, v: str) -> str:
        allowed = {"snowflake", "postgresql", "postgres", "mysql", "bigquery"}
        if v.lower() not in allowed:
            raise ValueError(f"data_source must be one of {sorted(allowed)}, got '{v}'")
        return v.lower()
    
    @model_validator(mode="before")
    @classmethod
    def handle_use_case_for_golden_dataset(cls, values: dict):
        if not values.get("use_case"):
            values["use_case"] = None
        return values

    class Config:
        arbitrary_types_allowed = True

class EnrichmentParameters(BaseModel):
    """Model for enrichment operation parameters."""
    handle_missing_values: bool = Field(default=True, description="Whether to handle missing values in feature engineering")
    create_interactions: bool = Field(default=True, description="Whether to create feature interactions")
    create_polynomials: bool = Field(default=False, description="Whether to create polynomial features")
    create_bins: bool = Field(default=False, description="Whether to create binned features")
    custom_rules: list[dict[str, Any]] = Field(default_factory=list, description="Custom feature engineering rules")
    preserve_original: bool = Field(default=True, description="Whether to preserve original data")
    class Config:
        use_enum_values = True

