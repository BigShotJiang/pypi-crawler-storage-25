__version__ = "0.59.0"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

from .reasoning.logical import LogicalReasoning
from .reasoning.common_sense import CommonSense

def hello():
    print("Hello from ub-clean-test!")