"""Utilities for path-based state operations."""

from typing import Any, Dict, List, Tuple
from echostate.exceptions import EchoStatePathError, EchoStateSerializationError
import json


def set_nested_value(state: Dict[str, Any], path: str, value: Any) -> None:
    """
    Set a value at a dot-delimited path, creating intermediate dicts as needed.

    Args:
        state: The state dictionary to modify
        path: Dot-delimited path (e.g., "a.b.c")
        value: Value to set

    Raises:
        EchoStatePathError: If an intermediate path exists but is not a dict
    """
    parts = path.split(".")
    current = state

    # Navigate/create intermediate dicts
    for part in parts[:-1]:
        if part not in current:
            current[part] = {}
        elif not isinstance(current[part], dict):
            raise EchoStatePathError(
                f"Cannot set '{path}': '{part}' exists but is not a dict"
            )
        current = current[part]

    # Set the final value
    final_key = parts[-1]
    current[final_key] = value


def get_nested_value(state: Dict[str, Any], path: str, default: Any = None) -> Any:
    """
    Get a value at a dot-delimited path.

    Args:
        state: The state dictionary
        path: Dot-delimited path
        default: Default value if path doesn't exist

    Returns:
        The value at the path, or default if not found
    """
    parts = path.split(".")
    current = state

    for part in parts:
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]

    return current


def delete_nested_value(state: Dict[str, Any], path: str) -> None:
    """
    Delete a value at a dot-delimited path.

    Args:
        state: The state dictionary to modify
        path: Dot-delimited path

    Raises:
        KeyError: If the path doesn't exist
    """
    parts = path.split(".")
    current = state

    # Navigate to parent
    for part in parts[:-1]:
        if not isinstance(current, dict) or part not in current:
            raise KeyError(f"Path '{path}' does not exist")
        current = current[part]

    # Delete the final value
    final_key = parts[-1]
    if not isinstance(current, dict) or final_key not in current:
        raise KeyError(f"Path '{path}' does not exist")
    del current[final_key]


def ensure_json_serializable(value: Any) -> None:
    """
    Check if a value is JSON-serializable.

    Args:
        value: Value to check

    Raises:
        EchoStateSerializationError: If value is not JSON-serializable
    """
    try:
        json.dumps(value)
    except (TypeError, ValueError) as e:
        raise EchoStateSerializationError(
            f"Value is not JSON-serializable: {type(value).__name__}"
        ) from e
