"""
EchoState - Semantic, event-sourced state for intelligent systems
"""

from echostate.state import EchoState
from echostate.event import Event
from echostate.embeddings import SearchHit
from echostate.exceptions import (
    EchoStateError,
    EchoStateLockedError,
    EchoStateSerializationError,
    EchoStatePathError,
    EchoStateEmbeddingError,
)

__version__ = "0.1.0"

__all__ = [
    "EchoState",
    "Event",
    "SearchHit",
    "EchoStateError",
    "EchoStateLockedError",
    "EchoStateSerializationError",
    "EchoStatePathError",
    "EchoStateEmbeddingError",
]
