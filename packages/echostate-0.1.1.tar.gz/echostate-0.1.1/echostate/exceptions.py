"""Custom exceptions for EchoState."""


class EchoStateError(Exception):
    """Base exception for all EchoState errors."""

    pass


class EchoStateLockedError(EchoStateError):
    """Raised when SQLite database is locked by another process."""

    pass


class EchoStateSerializationError(EchoStateError):
    """Raised when a value cannot be JSON-serialized."""

    pass


class EchoStatePathError(EchoStateError):
    """Raised when a path operation fails (e.g., setting a child under a non-dict)."""

    pass


class EchoStateEmbeddingError(EchoStateError):
    """Raised when embedding generation fails (only for synchronous indexing)."""

    pass
