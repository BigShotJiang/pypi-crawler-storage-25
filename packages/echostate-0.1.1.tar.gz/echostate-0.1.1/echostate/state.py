"""Core EchoState implementation."""

import os
import json
from typing import Any, Dict, List, Optional
from collections.abc import MutableMapping

from echostate.database import Database
from echostate.event import Event
from echostate.embeddings import EmbeddingIndex, SearchHit
from echostate.path_utils import (
    set_nested_value,
    get_nested_value,
    delete_nested_value,
    ensure_json_serializable,
)
from echostate.exceptions import EchoStatePathError


class EchoState(MutableMapping):
    """
    Event-sourced state container with semantic search capabilities.

    EchoState provides durable, inspectable, and semantically searchable state
    for AI agents and long-running intelligent applications.
    """

    def __init__(
        self,
        name: str = "default",
        persist: Optional[str] = None,
        index_keys: Optional[List[str]] = None,
        embedding_model: Optional[str] = None,
        auto_load: bool = True,
        lazy_index: bool = False,
        auto_snapshot_every_n_events: Optional[int] = None,
        auto_snapshot_every_seconds: Optional[int] = None,
    ):
        """
        Initialize EchoState instance.

        Args:
            name: Name identifier for this state instance
            persist: SQLite database path (e.g., "sqlite:///state.db")
                    If None, state is in-memory only (not recommended)
            index_keys: List of paths to index for semantic search
            embedding_model: Embedding model identifier (default: sentence-transformers/all-MiniLM-L6-v2)
            auto_load: If True, automatically load state on initialization
            lazy_index: If True, defer embedding computation until flush_index() or rebuild_index()
            auto_snapshot_every_n_events: Auto-create snapshot after N events (disabled by default)
            auto_snapshot_every_seconds: Auto-create snapshot after N seconds (disabled by default)
        """
        self.name = name
        self.index_keys = index_keys or []
        self.lazy_index = lazy_index
        self.auto_snapshot_every_n_events = auto_snapshot_every_n_events
        self.auto_snapshot_every_seconds = auto_snapshot_every_seconds

        # Resolve embedding model
        self.embedding_model = (
            embedding_model
            or os.getenv("ECHOSTATE_EMBEDDING_MODEL")
            or "sentence-transformers/all-MiniLM-L6-v2"
        )
        self.model_id = f"st:{self.embedding_model.split('/')[-1]}"

        # Initialize database
        self.db = Database(persist) if persist else None

        # Initialize embedding index (lazy-loaded)
        self._embedding_index: Optional[EmbeddingIndex] = None
        self._pending_index_events: List[Event] = [] if lazy_index else []

        # In-memory state
        self._state: Dict[str, Any] = {}

        # Track last event ID for auto-snapshot logic
        self._last_event_id = 0
        self._last_snapshot_event_id = 0
        self._last_snapshot_time = None

        # Load state if requested
        if auto_load and self.db:
            self.load()

    def load(self):
        """Load state from database by replaying events."""
        if not self.db:
            return

        # Load latest snapshot
        snapshot_data = self.db.get_latest_snapshot()
        if snapshot_data:
            self._state = snapshot_data["snapshot"].copy()
            self._last_event_id = snapshot_data["last_event_id"]
            self._last_snapshot_event_id = snapshot_data["last_event_id"]
            self._last_snapshot_time = snapshot_data["timestamp"]
        else:
            self._state = {}
            self._last_event_id = 0

        # Replay remaining events
        events = self.db.get_events(since_event_id=self._last_event_id)
        for event in events:
            self._apply_event(event)
            self._last_event_id = event.id or 0

    def _apply_event(self, event: Event):
        """Apply an event to in-memory state."""
        if event.operation == "set":
            set_nested_value(self._state, event.path, event.value)
        elif event.operation == "append":
            # Get current value, or create empty list if path doesn't exist
            current = get_nested_value(self._state, event.path)
            if current is None:
                # Path doesn't exist, create it with empty list
                set_nested_value(self._state, event.path, [])
                current = get_nested_value(self._state, event.path)
            
            if not isinstance(current, list):
                raise EchoStatePathError(
                    f"Cannot append to '{event.path}': not a list"
                )
            current.append(event.value)
        elif event.operation == "delete":
            delete_nested_value(self._state, event.path)
        elif event.operation == "update":
            # Update is same as set for v0.1
            set_nested_value(self._state, event.path, event.value)

    def set(self, path: str, value: Any, metadata: Optional[Dict[str, Any]] = None):
        """
        Set a value at the given path.

        Args:
            path: Dot-delimited path
            value: Value to set (must be JSON-serializable)
            metadata: Optional event metadata
        """
        ensure_json_serializable(value)

        # Create event
        event = Event(
            path=path,
            operation="set",
            value=value,
            metadata=metadata,
        )

        # Append event and update state atomically
        if self.db:
            with self.db.transaction():
                event_id = self.db.append_event(event)
                event.id = event_id
                self._apply_event(event)
                self._last_event_id = event_id

                # Index if needed
                if self._should_index(path):
                    if self.lazy_index:
                        self._pending_index_events.append(event)
                    else:
                        self._index_event(event)
        else:
            # In-memory only
            self._apply_event(event)

        # Check for auto-snapshot
        self._check_auto_snapshot()

    def get(self, path: str, default: Any = None) -> Any:
        """
        Get a value at the given path.

        Args:
            path: Dot-delimited path
            default: Default value if path doesn't exist

        Returns:
            The value at the path, or default if not found
        """
        return get_nested_value(self._state, path, default)

    def append(self, path: str, item: Any, metadata: Optional[Dict[str, Any]] = None):
        """
        Append an item to a list at the given path.

        Args:
            path: Path to a list value
            item: Item to append (must be JSON-serializable)
            metadata: Optional event metadata
        """
        ensure_json_serializable(item)

        # Check if path exists and is a list
        current = get_nested_value(self._state, path)
        if current is not None and not isinstance(current, list):
            raise EchoStatePathError(
                f"Cannot append to '{path}': exists but is not a list"
            )

        # Create event
        event = Event(
            path=path,
            operation="append",
            value=item,
            metadata=metadata,
        )

        # Append event and update state atomically
        if self.db:
            with self.db.transaction():
                event_id = self.db.append_event(event)
                event.id = event_id
                self._apply_event(event)
                self._last_event_id = event_id

                # Index if needed
                if self._should_index(path):
                    if self.lazy_index:
                        self._pending_index_events.append(event)
                    else:
                        self._index_event(event)
        else:
            # In-memory only
            self._apply_event(event)

        # Check for auto-snapshot
        self._check_auto_snapshot()

    def delete(self, path: str, metadata: Optional[Dict[str, Any]] = None):
        """
        Delete a value at the given path.

        Args:
            path: Path to delete
            metadata: Optional event metadata
        """
        # Create event
        event = Event(
            path=path,
            operation="delete",
            value=None,
            metadata=metadata,
        )

        # Append event and update state atomically
        if self.db:
            with self.db.transaction():
                event_id = self.db.append_event(event)
                event.id = event_id
                self._apply_event(event)
                self._last_event_id = event_id
                # Deletes are not indexed
        else:
            # In-memory only
            self._apply_event(event)

        # Check for auto-snapshot
        self._check_auto_snapshot()

    def _should_index(self, path: str) -> bool:
        """Check if a path should be indexed."""
        if not self.index_keys:
            return False
        # Check if path matches any index key (exact match or prefix)
        for key in self.index_keys:
            if path == key or path.startswith(key + "."):
                return True
        return False

    def _get_embedding_index(self) -> EmbeddingIndex:
        """Get or create embedding index."""
        if self._embedding_index is None:
            self._embedding_index = EmbeddingIndex(self.model_id, self.embedding_model)
        return self._embedding_index

    def _index_event(self, event: Event):
        """Index an event for semantic search."""
        if not self.db:
            return

        # Create derived record
        embedding_index = self._get_embedding_index()
        text = embedding_index.create_derived_record(event)
        if text is None:
            return  # Event shouldn't be indexed (e.g., delete)

        try:
            # Generate embedding
            embedding = embedding_index.generate_embedding(text)

            # Store in database
            metadata_json = json.dumps(event.metadata) if event.metadata else None
            self.db.store_embedding(
                event_id=event.id or 0,
                path=event.path,
                text=text,
                embedding=embedding,
                model_id=self.model_id,
                metadata=metadata_json,
            )
        except Exception as e:
            # Log warning but don't fail the operation
            import warnings
            warnings.warn(f"Failed to index event {event.id}: {e}", UserWarning)

    def _check_auto_snapshot(self):
        """Check if auto-snapshot conditions are met."""
        if not self.db:
            return

        import time
        should_snapshot = False

        if self.auto_snapshot_every_n_events:
            events_since_snapshot = self._last_event_id - self._last_snapshot_event_id
            if events_since_snapshot >= self.auto_snapshot_every_n_events:
                should_snapshot = True

        if self.auto_snapshot_every_seconds:
            current_time = int(time.time() * 1000)
            if (
                self._last_snapshot_time is None
                or (current_time - self._last_snapshot_time)
                >= (self.auto_snapshot_every_seconds * 1000)
            ):
                should_snapshot = True

        if should_snapshot:
            self.create_snapshot()

    def create_snapshot(self):
        """Create a snapshot of the current state."""
        if not self.db:
            return

        snapshot = self._state.copy()
        self.db.create_snapshot(self._last_event_id, snapshot)

        import time
        self._last_snapshot_event_id = self._last_event_id
        self._last_snapshot_time = int(time.time() * 1000)

    def history(
        self,
        path: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
    ) -> List[Event]:
        """
        Retrieve events from the event log.

        Args:
            path: Optional dot-delimited path to filter events (exact match)
            filters: Optional dict of metadata fields to match (e.g., {"user_id": "u-42"})
            limit: Optional maximum number of events to return (most recent first)

        Returns:
            List of events, ordered by event_id descending (most recent first)
        """
        if not self.db:
            return []

        if filters:
            events = self.db.get_events_with_metadata_filter(
                path=path, metadata_filters=filters, limit=limit
            )
        else:
            events = self.db.get_events(path=path, limit=limit, order_desc=True)

        return events

    def snapshot(self, at: Optional[Any] = None) -> Dict[str, Any]:
        """
        Reconstruct state at a given point in time.

        Args:
            at: Optional timestamp (ISO string or epoch ms) or event_id (int)
                If None, returns current state

        Returns:
            Dictionary representing the state at the specified time
        """
        if at is None:
            return self._state.copy()

        if not self.db:
            return self._state.copy()

        # Determine target event_id
        target_event_id = None

        if isinstance(at, int):
            # Assume it's an event_id
            target_event_id = at
        elif isinstance(at, str):
            # Try to parse as ISO timestamp or epoch ms
            try:
                from datetime import datetime
                # Try ISO format first
                dt = datetime.fromisoformat(at.replace("Z", "+00:00"))
                target_timestamp = int(dt.timestamp() * 1000)
                # Find event_id at or before this timestamp
                events = self.db.get_events(limit=None, order_desc=True)
                for event in events:
                    if event.timestamp <= target_timestamp:
                        target_event_id = event.id
                        break
            except (ValueError, AttributeError):
                # Try as epoch ms
                try:
                    target_timestamp = int(at)
                    events = self.db.get_events(limit=None, order_desc=True)
                    for event in events:
                        if event.timestamp <= target_timestamp:
                            target_event_id = event.id
                            break
                except ValueError:
                    raise ValueError(f"Invalid timestamp format: {at}")

        if target_event_id is None:
            return {}

        # Load snapshot at or before target_event_id
        snapshot_data = self.db.get_snapshot_at_event_id(target_event_id)
        if snapshot_data:
            state = snapshot_data["snapshot"].copy()
            last_event_id = snapshot_data["last_event_id"]
        else:
            state = {}
            last_event_id = 0

        # Replay events up to target_event_id on a temporary state copy
        events = self.db.get_events_up_to(target_event_id, since_event_id=last_event_id)
        for event in events:
            # Apply event to temporary state copy
            if event.operation == "set":
                set_nested_value(state, event.path, event.value)
            elif event.operation == "append":
                current = get_nested_value(state, event.path, [])
                if not isinstance(current, list):
                    # Skip invalid appends in historical replay
                    continue
                current.append(event.value)
            elif event.operation == "delete":
                try:
                    delete_nested_value(state, event.path)
                except KeyError:
                    # Skip if path doesn't exist
                    pass
            elif event.operation == "update":
                set_nested_value(state, event.path, event.value)

        return state

    def search(
        self,
        query: str,
        k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[SearchHit]:
        """
        Perform semantic search over indexed events.

        Args:
            query: Search query string
            k: Number of results to return
            filters: Optional metadata filters (applied post-search)

        Returns:
            List of SearchHit objects ordered by similarity (descending)
        """
        if not self.db:
            return []

        # Get embedding index
        embedding_index = self._get_embedding_index()

        # Generate query embedding
        query_embedding = embedding_index.embed_query(query)

        # Get all embeddings for this model
        embeddings = self.db.get_all_embeddings(model_id=self.model_id)

        # Compute similarities
        hits = []
        for emb_record in embeddings:
            similarity = embedding_index.compute_similarity(
                query_embedding, emb_record["embedding"]
            )

            # Get event for metadata
            events = self.db.get_events(path=emb_record["path"], limit=None)
            event_metadata = None
            event_operation = "set"
            # Find the specific event by event_id
            for evt in events:
                if evt.id == emb_record["event_id"]:
                    event_metadata = evt.metadata
                    event_operation = evt.operation
                    break

            # Apply metadata filters if provided
            if filters:
                if not event_metadata:
                    continue
                match = True
                for key, value in filters.items():
                    if event_metadata.get(key) != value:
                        match = False
                        break
                if not match:
                    continue

            # Create SearchHit
            hit = SearchHit(
                event_id=emb_record["event_id"],
                score=similarity,
                path=emb_record["path"],
                operation=event_operation,
                text=emb_record["text"],
                metadata=event_metadata,
                value=None,  # Best-effort, omitted for v0.1 performance
            )
            hits.append(hit)

        # Sort by score descending and return top k
        hits.sort(key=lambda x: x.score, reverse=True)
        return hits[:k]

    def rebuild_index(self):
        """
        Rebuild the semantic index from the event log.

        This truncates existing embeddings and regenerates them from all events.
        """
        if not self.db:
            return

        # Truncate existing embeddings for this model
        self.db.truncate_embeddings(model_id=self.model_id)

        # Get all events
        events = self.db.get_events()

        # Re-index all eligible events
        embedding_index = self._get_embedding_index()
        for event in events:
            if self._should_index(event.path):
                self._index_event(event)

        # Clear pending events
        self._pending_index_events = []

    def flush_index(self):
        """
        Index any pending events (when lazy_index=True).

        This method is only useful when lazy_index=True.
        """
        if not self.lazy_index:
            return

        for event in self._pending_index_events:
            if self._should_index(event.path):
                self._index_event(event)

        self._pending_index_events = []

    # Dictionary-style access (top-level only)
    def __setitem__(self, key: str, value: Any):
        """Set a top-level key."""
        self.set(key, value)

    def __getitem__(self, key: str) -> Any:
        """Get a top-level key."""
        if key not in self._state:
            raise KeyError(key)
        return self._state[key]

    def __delitem__(self, key: str):
        """Delete a top-level key."""
        self.delete(key)

    def __iter__(self):
        """Iterate over top-level keys."""
        return iter(self._state)

    def __len__(self) -> int:
        """Return number of top-level keys."""
        return len(self._state)

    def close(self):
        """Close database connection."""
        if self.db:
            self.db.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
