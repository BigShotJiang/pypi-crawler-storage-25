"""Embedding generation and storage for semantic search."""

import json
import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Tuple
from sentence_transformers import SentenceTransformer

from echostate.event import Event
from echostate.exceptions import EchoStateEmbeddingError


class EmbeddingIndex:
    """Manages embeddings for semantic search."""

    def __init__(self, model_id: str, model_name: str):
        """
        Initialize embedding index.

        Args:
            model_id: Model identifier (e.g., "st:all-MiniLM-L6-v2")
            model_name: Model name for sentence-transformers
        """
        self.model_id = model_id
        self.model_name = model_name
        self._model: Optional[SentenceTransformer] = None

    def _get_model(self) -> SentenceTransformer:
        """Lazy-load the embedding model."""
        if self._model is None:
            try:
                self._model = SentenceTransformer(self.model_name)
            except Exception as e:
                raise EchoStateEmbeddingError(
                    f"Failed to load embedding model '{self.model_name}': {e}"
                ) from e
        return self._model

    def create_derived_record(self, event: Event) -> Optional[str]:
        """
        Create a derived record (text representation) from an event.

        Args:
            event: Event to convert

        Returns:
            Text representation suitable for embedding, or None if event shouldn't be indexed
        """
        # Deletes don't produce searchable content
        if event.operation == "delete":
            return None

        value = event.value

        # Convert value to text based on type
        if isinstance(value, str):
            text = value
        elif isinstance(value, (dict, list)):
            # Serialize to compact JSON
            text = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        elif value is None:
            return None
        else:
            # Primitives
            text = str(value)

        # For append operations, add lightweight context
        if event.operation == "append":
            # Include path context
            text = f"{event.path}: {text}"

        return text

    def generate_embedding(self, text: str) -> bytes:
        """
        Generate embedding for a text string.

        Args:
            text: Text to embed

        Returns:
            Embedding as bytes (numpy array serialized)
        """
        model = self._get_model()
        try:
            embedding = model.encode(text, convert_to_numpy=True)
            # Convert to bytes for storage
            return embedding.tobytes()
        except Exception as e:
            raise EchoStateEmbeddingError(f"Failed to generate embedding: {e}") from e

    def compute_similarity(self, query_embedding: bytes, target_embedding: bytes) -> float:
        """
        Compute cosine similarity between two embeddings.

        Args:
            query_embedding: Query embedding as bytes
            target_embedding: Target embedding as bytes

        Returns:
            Cosine similarity score (0-1, higher is more similar)
        """
        query_vec = np.frombuffer(query_embedding, dtype=np.float32)
        target_vec = np.frombuffer(target_embedding, dtype=np.float32)

        # Cosine similarity
        dot_product = np.dot(query_vec, target_vec)
        norm_query = np.linalg.norm(query_vec)
        norm_target = np.linalg.norm(target_vec)

        if norm_query == 0 or norm_target == 0:
            return 0.0

        similarity = dot_product / (norm_query * norm_target)
        # Normalize to 0-1 range (cosine similarity is -1 to 1)
        normalized = (similarity + 1) / 2
        # Convert numpy scalar to Python float
        return float(normalized)

    def embed_query(self, query: str) -> bytes:
        """
        Generate embedding for a search query.

        Args:
            query: Search query string

        Returns:
            Embedding as bytes
        """
        return self.generate_embedding(query)


@dataclass
class SearchHit:
    """Represents a search result hit."""

    event_id: int
    score: float
    path: str
    operation: str
    text: str
    metadata: Optional[Dict[str, Any]] = None
    value: Optional[Any] = None  # Best-effort, may be None
