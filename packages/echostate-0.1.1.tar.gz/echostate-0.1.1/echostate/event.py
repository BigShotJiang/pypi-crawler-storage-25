"""Event model for EchoState."""

import json
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from datetime import datetime


@dataclass
class Event:
    """Represents a single state mutation event."""

    id: Optional[int] = None  # Set by database on insert
    timestamp: int = field(default_factory=lambda: int(datetime.now().timestamp() * 1000))
    path: str = ""
    operation: str = ""  # set | append | delete | update
    value: Any = None
    event_version: int = 1
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for database storage."""
        return {
            "timestamp": self.timestamp,
            "path": self.path,
            "operation": self.operation,
            "value": json.dumps(self.value) if self.value is not None else None,
            "event_version": self.event_version,
            "metadata": json.dumps(self.metadata) if self.metadata else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Event":
        """Create event from database row."""
        return cls(
            id=data.get("id"),
            timestamp=data["timestamp"],
            path=data["path"],
            operation=data["operation"],
            value=json.loads(data["value"]) if data["value"] else None,
            event_version=data.get("event_version", 1),
            metadata=json.loads(data["metadata"]) if data.get("metadata") else None,
        )
