"""Integration tests combining multiple features."""

import pytest
import tempfile
import os
from echostate import EchoState


class TestIntegration:
    """Integration tests."""

    def test_full_workflow(self):
        """Test a complete workflow: write, search, history, snapshot."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            # Create state
            state = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["conversations", "decisions"]
            )

            # Write data
            state.set("user.name", "Alice", metadata={"user_id": "u-1"})
            state.append(
                "conversations",
                "Customer asked about refund policy",
                metadata={"session": "s-1", "priority": "high"}
            )
            state.append(
                "conversations",
                "Explained refund process",
                metadata={"session": "s-1", "priority": "high"}
            )
            state.append(
                "decisions",
                "Approved refund request",
                metadata={"session": "s-1", "amount": 100}
            )

            # Search
            refund_results = state.search("refund", k=5)
            assert len(refund_results) > 0

            # History with filters
            session_events = state.history(
                filters={"session": "s-1"},
                limit=10
            )
            assert len(session_events) == 3

            # Create snapshot
            state.create_snapshot()

            # Time travel
            past_state = state.snapshot(at=state._last_event_id - 1)
            assert "user" in past_state

            # Rebuild index
            state.rebuild_index()

            # Verify search still works
            results = state.search("refund", k=5)
            assert len(results) > 0

            state.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_persistence_across_restarts(self):
        """Test that state persists correctly across multiple restarts."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            # First session
            state1 = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["notes"]
            )
            state1.set("session", 1)
            state1.append("notes", "First session note")
            state1.create_snapshot()
            state1.close()

            # Second session
            state2 = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["notes"]
            )
            assert state2.get("session") == 1
            assert len(state2.get("notes", [])) == 1

            state2.set("session", 2)
            state2.append("notes", "Second session note")
            state2.close()

            # Third session
            state3 = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["notes"]
            )
            assert state3.get("session") == 2
            assert len(state3.get("notes", [])) == 2

            # Search should work
            results = state3.search("session note", k=5)
            assert len(results) >= 2

            state3.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_lazy_indexing(self):
        """Test lazy indexing workflow."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["notes"],
                lazy_index=True
            )

            # Add data (not indexed yet)
            state.append("notes", "Note 1")
            state.append("notes", "Note 2")

            # Search should return nothing (not indexed)
            results_before = state.search("note", k=5)
            assert len(results_before) == 0

            # Flush index
            state.flush_index()

            # Now search should work
            results_after = state.search("note", k=5)
            assert len(results_after) >= 2

            state.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_complex_nested_structure(self):
        """Test with complex nested data structures."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["users"]
            )

            # Complex nested structure
            state.set("users.alice.profile.name", "Alice")
            state.set("users.alice.profile.tier", "Gold")
            state.append("users.alice.orders", {"id": 1, "amount": 100})
            state.append("users.alice.orders", {"id": 2, "amount": 200})

            # Verify structure
            assert state.get("users.alice.profile.name") == "Alice"
            assert state.get("users.alice.profile.tier") == "Gold"
            orders = state.get("users.alice.orders")
            assert len(orders) == 2
            assert orders[0]["id"] == 1

            # Persist and reload
            state.create_snapshot()
            state.close()

            state2 = EchoState(persist=f"sqlite:///{db_path}")
            assert state2.get("users.alice.profile.name") == "Alice"
            assert len(state2.get("users.alice.orders")) == 2
            state2.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
