"""Snapshot and replay tests."""

import pytest
import tempfile
import os
import time
from echostate import EchoState


class TestSnapshots:
    """Test snapshot and replay functionality."""

    def test_create_snapshot(self):
        """Test creating a snapshot."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a", 1)
            state.set("b", 2)

            state.create_snapshot()

            # Verify snapshot exists
            snapshot = state.db.get_latest_snapshot()
            assert snapshot is not None
            assert snapshot["snapshot"]["a"] == 1
            assert snapshot["snapshot"]["b"] == 2
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_replay_from_snapshot(self):
        """Test that state can be replayed from a snapshot."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            # Create state and add events
            state1 = EchoState(persist=f"sqlite:///{db_path}")
            state1.set("a", 1)
            state1.set("b", 2)
            state1.create_snapshot()
            state1.set("c", 3)
            state1.close()

            # New instance should replay from snapshot
            state2 = EchoState(persist=f"sqlite:///{db_path}")
            assert state2.get("a") == 1
            assert state2.get("b") == 2
            assert state2.get("c") == 3
            state2.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_snapshot_at_event_id(self):
        """Test getting state at a specific event ID."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a", 1)
            event_id_1 = state._last_event_id
            state.set("b", 2)
            event_id_2 = state._last_event_id
            state.set("c", 3)

            # Get state at event_id_2
            past_state = state.snapshot(at=event_id_2)
            assert past_state["a"] == 1
            assert past_state["b"] == 2
            assert "c" not in past_state
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_snapshot_current_state(self):
        """Test getting current state snapshot."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a", 1)
            state.set("b", 2)

            current = state.snapshot()
            assert current["a"] == 1
            assert current["b"] == 2
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_auto_snapshot_by_events(self):
        """Test auto-snapshot after N events."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(
                persist=f"sqlite:///{db_path}",
                auto_snapshot_every_n_events=3
            )

            # Add 3 events - should trigger snapshot
            state.set("a", 1)
            state.set("b", 2)
            state.set("c", 3)

            # Verify snapshot was created
            snapshot = state.db.get_latest_snapshot()
            assert snapshot is not None
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_deterministic_replay(self):
        """Test that replay produces identical state."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            # Create initial state
            state1 = EchoState(persist=f"sqlite:///{db_path}")
            state1.set("a", 1)
            state1.append("list", "item1")
            state1.append("list", "item2")
            state1.set("nested.x", 10)
            state1.set("nested.y", 20)
            final_state = state1._state.copy()
            state1.close()

            # Replay from scratch
            state2 = EchoState(persist=f"sqlite:///{db_path}")
            assert state2._state == final_state
            state2.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
