"""Semantic search tests."""

import pytest
import tempfile
import os
from echostate import EchoState


class TestSemanticSearch:
    """Test semantic search functionality."""

    @pytest.fixture
    def state_with_data(self):
        """Create a state instance with test data."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        state = EchoState(
            persist=f"sqlite:///{db_path}",
            index_keys=["notes", "descriptions"]
        )

        # Add some indexed data
        state.append("notes", "Customer requested a refund", metadata={"id": 1})
        state.append("notes", "User wants to return the product", metadata={"id": 2})
        state.append("notes", "Payment was processed successfully", metadata={"id": 3})
        state.append("notes", "Refund has been issued", metadata={"id": 4})
        state.set("descriptions", "This is about customer service", metadata={"id": 5})

        # Flush index to ensure embeddings are created
        state.flush_index()

        yield state

        state.close()
        if os.path.exists(db_path):
            os.unlink(db_path)

    def test_basic_search(self, state_with_data):
        """Test basic semantic search."""
        results = state_with_data.search("refund request", k=3)

        assert len(results) > 0
        assert all(hasattr(hit, "score") for hit in results)
        assert all(hasattr(hit, "path") for hit in results)
        assert all(hasattr(hit, "text") for hit in results)

        # Results should be ordered by score descending
        scores = [hit.score for hit in results]
        assert scores == sorted(scores, reverse=True)

    def test_search_relevance(self, state_with_data):
        """Test that search returns relevant results."""
        results = state_with_data.search("refund", k=5)

        # Should find refund-related notes
        refund_texts = [hit.text.lower() for hit in results]
        assert any("refund" in text for text in refund_texts)

    def test_search_with_filters(self, state_with_data):
        """Test search with metadata filters."""
        results = state_with_data.search("refund", k=10, filters={"id": 1})

        # Should only return results matching the filter
        assert len(results) > 0
        for hit in results:
            assert hit.metadata is not None
            assert hit.metadata.get("id") == 1

    def test_search_limit(self, state_with_data):
        """Test that search respects the k parameter."""
        results = state_with_data.search("customer", k=2)

        assert len(results) <= 2

    def test_search_non_indexed_path(self, state_with_data):
        """Test that non-indexed paths don't appear in search."""
        # Add data to non-indexed path
        state_with_data.set("not_indexed", "This won't be found")
        state_with_data.flush_index()

        results = state_with_data.search("won't be found", k=10)
        # Should not find the non-indexed data
        paths = [hit.path for hit in results]
        assert "not_indexed" not in paths

    def test_rebuild_index(self, state_with_data):
        """Test rebuilding the index."""
        # Add more data
        state_with_data.append("notes", "New note after rebuild")
        state_with_data.rebuild_index()

        # Search should include new data
        results = state_with_data.search("new note", k=5)
        texts = [hit.text.lower() for hit in results]
        assert any("new note" in text for text in texts)

    def test_search_hit_structure(self, state_with_data):
        """Test that SearchHit has correct structure."""
        results = state_with_data.search("test", k=1)

        if len(results) > 0:
            hit = results[0]
            assert hasattr(hit, "event_id")
            assert hasattr(hit, "score")
            assert hasattr(hit, "path")
            assert hasattr(hit, "operation")
            assert hasattr(hit, "text")
            assert isinstance(hit.score, float)
            assert 0.0 <= hit.score <= 1.0

    def test_empty_search(self):
        """Test search with no indexed data."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(
                persist=f"sqlite:///{db_path}",
                index_keys=["notes"]
            )

            results = state.search("anything", k=5)
            assert len(results) == 0
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
