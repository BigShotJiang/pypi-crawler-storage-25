"""Basic functionality tests."""

import pytest
import tempfile
import os
from echostate import EchoState


class TestBasicOperations:
    """Test basic state operations."""

    def test_set_and_get(self):
        """Test setting and getting values."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("user.name", "Alice")
            state.set("user.age", 30)

            assert state.get("user.name") == "Alice"
            assert state.get("user.age") == 30
            assert state.get("user.nonexistent") is None
            assert state.get("user.nonexistent", "default") == "default"
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_nested_paths(self):
        """Test nested path operations."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a.b.c", 10)
            state.set("a.b.d", 20)

            assert state.get("a.b.c") == 10
            assert state.get("a.b.d") == 20
            assert isinstance(state.get("a"), dict)
            assert isinstance(state.get("a.b"), dict)
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_append(self):
        """Test append operations."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.append("notes", "First note")
            state.append("notes", "Second note")

            notes = state.get("notes")
            assert isinstance(notes, list)
            assert len(notes) == 2
            assert notes[0] == "First note"
            assert notes[1] == "Second note"
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_append_to_new_path(self):
        """Test appending to a non-existent path creates a list."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.append("new_list", "item1")

            assert state.get("new_list") == ["item1"]
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_delete(self):
        """Test delete operations."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("to_delete", "value")
            assert state.get("to_delete") == "value"

            state.delete("to_delete")
            assert state.get("to_delete") is None
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_dict_style_access(self):
        """Test dictionary-style access for top-level keys."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state["top_level"] = "value"
            assert state["top_level"] == "value"

            del state["top_level"]
            with pytest.raises(KeyError):
                _ = state["top_level"]
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_persistence(self):
        """Test that state persists across instances."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            # First instance
            state1 = EchoState(persist=f"sqlite:///{db_path}")
            state1.set("persistent", "value")
            state1.close()

            # Second instance - should load previous state
            state2 = EchoState(persist=f"sqlite:///{db_path}")
            assert state2.get("persistent") == "value"
            state2.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_metadata(self):
        """Test metadata storage with events."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set(
                "test",
                "value",
                metadata={"user_id": "u-42", "session": "s-1"}
            )

            events = state.history("test")
            assert len(events) == 1
            assert events[0].metadata == {"user_id": "u-42", "session": "s-1"}
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
