"""History and event log tests."""

import pytest
import tempfile
import os
from echostate import EchoState


class TestHistory:
    """Test history and event log functionality."""

    def test_history_all_events(self):
        """Test retrieving all events."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a", 1)
            state.set("b", 2)
            state.set("a", 3)

            events = state.history()
            assert len(events) == 3
            # Should be ordered by event_id descending (most recent first)
            assert events[0].path == "a"
            assert events[0].value == 3
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_history_filter_by_path(self):
        """Test filtering events by path."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("notes", "note1")
            state.set("profile", "profile1")
            state.set("notes", "note2")

            events = state.history("notes")
            assert len(events) == 2
            assert all(e.path == "notes" for e in events)
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_history_with_limit(self):
        """Test limiting history results."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            for i in range(10):
                state.set("test", i)

            events = state.history("test", limit=5)
            assert len(events) == 5
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_history_with_metadata_filters(self):
        """Test filtering events by metadata."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("test", "value1", metadata={"user_id": "u-1"})
            state.set("test", "value2", metadata={"user_id": "u-2"})
            state.set("test", "value3", metadata={"user_id": "u-1"})

            events = state.history("test", filters={"user_id": "u-1"})
            assert len(events) == 2
            assert all(e.metadata.get("user_id") == "u-1" for e in events)
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_event_structure(self):
        """Test that events have correct structure."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("test", "value", metadata={"key": "val"})

            events = state.history("test")
            assert len(events) == 1
            event = events[0]

            assert event.id is not None
            assert event.timestamp > 0
            assert event.path == "test"
            assert event.operation == "set"
            assert event.value == "value"
            assert event.metadata == {"key": "val"}
            assert event.event_version == 1
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
