"""Error handling tests."""

import pytest
import tempfile
import os
from echostate import EchoState, EchoStatePathError, EchoStateSerializationError


class TestErrorHandling:
    """Test error conditions."""

    def test_path_error_on_type_conflict(self):
        """Test that setting a child under a non-dict raises error."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("a", "string_value")

            # Try to set a child under a string - should fail
            with pytest.raises(EchoStatePathError):
                state.set("a.b", "value")
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_append_to_non_list(self):
        """Test that appending to a non-list raises error."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")
            state.set("not_a_list", "string")

            # Try to append to a string - should fail
            with pytest.raises(EchoStatePathError):
                state.append("not_a_list", "item")
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_serialization_error(self):
        """Test that non-serializable values raise error."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")

            # Try to store a function - should fail
            with pytest.raises(EchoStateSerializationError):
                state.set("func", lambda x: x)
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    def test_delete_nonexistent_path(self):
        """Test that deleting a non-existent path raises error."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        try:
            state = EchoState(persist=f"sqlite:///{db_path}")

            with pytest.raises(KeyError):
                state.delete("nonexistent.path")
        finally:
            state.close()
            if os.path.exists(db_path):
                os.unlink(db_path)
