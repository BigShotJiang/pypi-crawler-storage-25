from fasr_asr_fun.models.asr import FunASRNanoForASR

__all__ = ["FunASRNanoForASR"]
