# fasr-asr-fun

基于 `fun_asr_nano.py` 的 `funasr.AutoModel` 推理方式封装，为 fasr 提供 Fun-ASR-Nano 无时间戳识别能力。

## 安装

```bash
pip install fasr-asr-fun
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `fun_asr_nano` | `FunASRNanoForASR` | `FunAudioLLM/Fun-ASR-Nano-2512` | Fun-ASR-Nano，无时间戳输出 |

## 使用方式

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="fun_asr_nano")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录 |
| `device` | `str` | `"cuda:0"` | 推理设备 |
| `trust_remote_code` | `bool` | `True` | 是否信任远程代码 |
| `remote_code` | `str` | `"./model.py"` | 远程代码路径 |
| `language` | `str` | `"中文"` | 识别语言 |
| `itn` | `bool` | `True` | 是否执行逆文本规范化 |
| `batch_size` | `int` | `1` | generate 批大小 |

`transcribe` 支持通过 `kwargs` 覆盖 `hotwords`、`language`、`itn`、`batch_size`。

## 输出说明

- 当前模型不返回词级/字级时间戳。
- fasr 中会把整段识别文本作为一个 `AudioToken` 返回。
