# BKChem-py3
The repository contains **BKChem** ported to Python 3. The credit for the original codebase goes to the original developers and maintainers.

This version has been rigorously tested on **Windows 11** and is designed for modern research workflows.

## New Features & Improvements
1. **New Annotations:** Added new arrows (curly, fishhook, reversible, and more).
2. **SMILES Integration:** Rewritten SMILES read/write for better handling.
3. **Native Export:** New 'Export to Image' function to save in PNG, JPEG, and other formats.
4. **Enhanced UI:** Mouse-based zoom-in and zoom-out functionality.
5. **Page Setup:** Improved layout and printing options.
6. **Efficiency:** Reduced dependencies and improved performance/speed.
7. **Modernized Core:** Thoroughly modified `oasa` library.
8. **Stability:** Improved undo functionality and numerous bug fixes.
9. **Text Handling:** Adding and editing text material is now more intuitive.

---
## License
This project is licensed under the GNU General Public License v2 (GPLv2). See the LICENSE file for details.

⭐ **Support the Project:** If you find this port useful, please give the repository a **Star**! It helps other researchers find the tool.

[![Buy Me A Coffee](https://www.buymeacoffee.com/assets/img/guidelines/download-assets-sm-1.svg)](https://buymeacoffee.com/vijaymasand)

---

## Installation
**Requirement:** Python 3.10 or higher.

```bash
# Basic installation
pip install bkchem-py3
```
# For full image export support (PNG, JPEG, PDF, SVG):
pip install "bkchem-py3[all]"

