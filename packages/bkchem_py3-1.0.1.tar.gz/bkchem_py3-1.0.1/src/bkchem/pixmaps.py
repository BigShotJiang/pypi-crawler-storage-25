#--------------------------------------------------------------------------
#     This file is part of BKChem - a chemical drawing program
#     Copyright (C) 2002-2009 Beda Kosata <beda@zirael.org>

#     This program is free software; you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation; either version 2 of the License, or
#     (at your option) any later version.

#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.

#     Complete text of GNU GPL can be found in the file gpl.txt in the
#     main directory of the program

#--------------------------------------------------------------------------


"""images for buttons all over BKChem"""

from . import import_checker
from . import os_support
import tkinter
import os


__all__ = ['images']


class images_dict( dict):
  """if asked about an pixmap it looks to the filesystem and
  adds the path into itself if found"""

  def __getitem__( self, item):
    # try if we need to recode the name
    try:
      item = name_recode_map[ item]
    except KeyError:
      pass
    try:
      return dict.__getitem__( self, item)
    except KeyError:
      try:
        path = os_support.get_path( item+'.gif', 'pixmap')
        if not path:
          raise KeyError(f"Pixmap {item} not found in search paths")
        i = tkinter.PhotoImage( file = path)
        self.__setitem__( item, i)
        return i
      except Exception as e:
        # Log the actual error for debugging
        import sys
        print(f"ERROR loading pixmap '{item}': {type(e).__name__}: {e}", file=sys.stderr)
        raise KeyError(f"Could not load pixmap {item}: {e}")


  def __contains__( self, item):
    # try if we need to recode the name
    try:
      item = name_recode_map[ item]
    except KeyError:
      pass

    if dict.__contains__( self, item):
      return 1
    else:
      # Check if file exists without trying to load the image
      # (PhotoImage requires root window to exist)
      path = os_support.get_path( item+'.gif', 'pixmap')
      if path and os.path.isfile( path):
        return 1
      return 0


# images for which the name and file name differs
name_recode_map = { #'vector': 'oval',
                    'fixed': 'fixed_length',
                    # Arrow type mappings to GIF files
                    'curved-electron': 'curved arrow_1',
                    'dashed': 'dashed arrow_1',
                    'fishhook': 'fishHook arrow_1',
                    'harpoon-left': 'harpoon arrow_1',
                    'resonance': 'resonance arrow_1',
                    'circular': 'round arrow_1'
                    }


images = images_dict()


