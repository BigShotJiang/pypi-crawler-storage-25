
# BKChem-py3: A Python 3 port of the BKChem molecular editor.
# Original author: Beda Kosata
# Python 3 port: Vijay H. Masand
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

## import sys
## import os

## path = os.path.abspath('./bkchem')
## if path not in sys.path:
##   sys.path.append( path)

## import bkchem
## sys.modules['bkchem'] = bkchem


