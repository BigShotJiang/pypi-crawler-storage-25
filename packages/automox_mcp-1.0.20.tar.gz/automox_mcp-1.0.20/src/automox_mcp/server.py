"""FastMCP server wiring for Automox tools."""

from __future__ import annotations

import os
from collections.abc import Awaitable, Callable
from importlib import import_module
from types import ModuleType
from typing import Any, cast

from fastmcp import FastMCP

from .auth import create_auth_provider
from .client import AutomoxClient
from .middleware import CorrelationMiddleware
from .prompts import register_prompts
from .resources import register_resources
from .tools import register_tools

LoadDotenvFn = Callable[..., bool]

try:  # pragma: no cover - optional dependency guard
    from dotenv import load_dotenv as _dotenv_loader
except ImportError:  # pragma: no cover - fallback if python-dotenv missing
    _load_dotenv_fn: LoadDotenvFn | None = None
else:
    _load_dotenv_fn = _dotenv_loader


def _patch_stdio_transport() -> None:  # pragma: no cover - patches MCP internals
    """Ensure stdio transport shuts down gracefully when pipes close."""
    try:
        from mcp.server import stdio as stdio_module
    except Exception:  # pragma: no cover - module missing in unusual installs
        return

    if getattr(stdio_module, "_automox_mcp_patched", False):
        return

    import sys
    from contextlib import asynccontextmanager
    from io import TextIOWrapper

    import anyio
    import anyio.lowlevel
    import mcp.types as types
    from anyio.streams.memory import (
        MemoryObjectReceiveStream,
        MemoryObjectSendStream,
    )
    from mcp.shared.message import SessionMessage

    @asynccontextmanager
    async def patched_stdio_server(  # type: ignore[override]
        stdin: anyio.AsyncFile[str] | None = None,
        stdout: anyio.AsyncFile[str] | None = None,
    ):
        # The implementation mirrors MCP's stock stdio_server but guards against
        # closed pipes raising ValueError/BrokenPipeError during shutdown.
        if not stdin:
            stdin = anyio.wrap_file(TextIOWrapper(sys.stdin.buffer, encoding="utf-8"))
        if not stdout:
            stdout = anyio.wrap_file(TextIOWrapper(sys.stdout.buffer, encoding="utf-8"))

        read_stream_writer: MemoryObjectSendStream[SessionMessage | Exception]
        read_stream: MemoryObjectReceiveStream[SessionMessage | Exception]
        write_stream: MemoryObjectSendStream[SessionMessage]
        write_stream_reader: MemoryObjectReceiveStream[SessionMessage]

        read_stream_writer, read_stream = anyio.create_memory_object_stream(0)
        write_stream, write_stream_reader = anyio.create_memory_object_stream(0)

        async def stdin_reader() -> None:
            try:
                async with read_stream_writer:
                    async for line in stdin:
                        try:
                            message = types.JSONRPCMessage.model_validate_json(line)
                        except Exception as exc:  # pragma: no cover - passthrough
                            await read_stream_writer.send(exc)
                            continue

                        session_message = SessionMessage(message)
                        await read_stream_writer.send(session_message)
            except anyio.ClosedResourceError:  # pragma: no cover - EOF race
                await anyio.lowlevel.checkpoint()

        async def stdout_writer() -> None:
            try:
                async with write_stream_reader:
                    async for session_message in write_stream_reader:
                        json = session_message.message.model_dump_json(
                            by_alias=True, exclude_none=True
                        )
                        try:
                            await stdout.write(json + "\n")
                            await stdout.flush()
                        except (BrokenPipeError, ValueError):
                            # Broken pipe or closed stdio occurs when the client
                            # disconnects; treat it as a normal shutdown signal.
                            return
            except anyio.ClosedResourceError:  # pragma: no cover - EOF race
                await anyio.lowlevel.checkpoint()

        stdin_task = cast(Callable[..., Awaitable[Any]], stdin_reader)
        stdout_task = cast(Callable[..., Awaitable[Any]], stdout_writer)
        async with anyio.create_task_group() as tg:
            tg.start_soon(stdin_task)
            tg.start_soon(stdout_task)
            yield read_stream, write_stream

    stdio_module.stdio_server = patched_stdio_server
    fastmcp_server_module: ModuleType | None = None
    try:
        fastmcp_server_module = import_module("fastmcp.server.server")
    except Exception:  # pragma: no cover - unexpected fastmcp layout
        fastmcp_server_module = None
    if fastmcp_server_module is not None:
        fastmcp_server_module.stdio_server = patched_stdio_server  # type: ignore[attr-defined]

    stdio_module._automox_mcp_patched = True  # type: ignore[attr-defined]


def _get_env(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


def _validate_env() -> None:
    """Validate required environment variables are present and well-formed."""
    required_vars = ["AUTOMOX_API_KEY", "AUTOMOX_ACCOUNT_UUID"]
    env_values = {var: _get_env(var) for var in required_vars}
    missing = [var for var, val in env_values.items() if val is None]
    if missing:
        raise RuntimeError(f"Missing required environment variables: {missing}")

    # AUTOMOX_ORG_ID must be a positive integer when provided
    org_id_raw = _get_env("AUTOMOX_ORG_ID")
    if org_id_raw is not None:
        try:
            org_id_int = int(org_id_raw)
        except ValueError as exc:
            raise RuntimeError(
                f"AUTOMOX_ORG_ID must be a positive integer, got: {org_id_raw!r}"
            ) from exc
        if org_id_int <= 0:
            raise RuntimeError(f"AUTOMOX_ORG_ID must be a positive integer, got: {org_id_int}")


def _load_env_file() -> None:
    if _load_dotenv_fn is None:
        return
    skip_value = os.environ.get("AUTOMOX_MCP_SKIP_DOTENV", "")
    if skip_value.lower() in {"1", "true", "yes"}:
        return
    _load_dotenv_fn()


def create_server() -> FastMCP:
    """Create and configure the Automox MCP server with all tools, resources, and prompts."""
    _patch_stdio_transport()
    _load_env_file()
    _validate_env()

    from .utils.logging import configure_logging

    configure_logging()

    from contextlib import asynccontextmanager

    client = AutomoxClient()

    @asynccontextmanager
    async def _lifespan(app):
        yield
        await client.aclose()

    auth = create_auth_provider()

    server: FastMCP = FastMCP(
        name="Automox MCP",
        lifespan=_lifespan,
        auth=auth,
        middleware=[CorrelationMiddleware()],
        instructions=(
            "Curated Automox workflows for policy health, device insights, remediation, "
            "account management, server group management, package/patch visibility, "
            "event history, compliance reports, and webhook subscriptions.\n\n"
            "CAPABILITIES:\n"
            "- Devices: list, search, detail (with inventory), health metrics, "
            "devices needing attention, execute commands (scan/patch/reboot)\n"
            "- Advanced Device Search: saved searches, structured queries, "
            "typeahead, field metadata, device assignments (Server Groups API v2)\n"
            "- Policies: catalog, detail, health overview, execution timeline, "
            "run results, create/update, execute, patch approvals\n"
            "- Policy History v2: runs with time-range filters, run counts, "
            "runs grouped by policy, UUID-based queries\n"
            "- Packages: list device packages, search organization packages\n"
            "- Groups: list, get, create, update, delete server groups\n"
            "- Events: list organization events with filters\n"
            "- Reports: pre-patch readiness, non-compliant devices\n"
            "- Webhooks: list event types, list/get/create/update/delete webhooks, "
            "test delivery, rotate signing secret\n"
            "- Worklets: search community worklet catalog, get worklet details\n"
            "- Data Extracts: list, get, create bulk data extracts\n"
            "- Vuln Sync: remediation action sets, issues, solutions, uploads\n"
            "- Compound: patch tuesday readiness, compliance snapshot\n"
            "- Audit: audit trail activity search, OCSF-formatted events (v2)\n"
            "- Account: invite/remove users, list org API keys\n\n"
            "IMPORTANT: When working with Automox data, proactively check available resources:\n"
            "- Use resource://servergroups/list to translate server_group_id values to "
            "human-readable names\n"
            "- Use resource://policies/quick-start for copy-paste policy creation templates "
            "(RECOMMENDED)\n"
            "- Use resource://policies/schema when creating or updating policies\n"
            "- Use resource://policies/schedule-syntax for scheduling help\n"
            "- Use resource://webhooks/event-types for available webhook event types\n"
            "- Use resource://filters/syntax for device filtering reference\n"
            "- Use resource://patches/categories for patch severity and classification reference\n"
            "- Use resource://platform/supported-os for supported OS matrix\n"
            "- Use resource://api/rate-limits for rate limiting guidance\n\n"
            "SCHEDULE INTERPRETATION:\n"
            "- When you retrieve a policy with policy_detail, check the '_important' field "
            "for current schedule\n"
            "- The schedule_interpretation field decodes bitmask values into human-readable "
            "format\n"
            "- Weekdays = 62, Weekend = 192, Every day = 254\n"
            "- To update schedules, use: {'days': ['weekend'], 'time': '02:00'} syntax\n\n"
            "UPDATING POLICIES:\n"
            "- Use format: {'action': 'update', 'policy_id': 12345, 'policy': "
            "{'schedule': {'days': ['weekend'], 'time': '02:00'}}}\n"
            "- Only include fields you want to change in the policy object\n\n"
            "WEBHOOKS:\n"
            "- When creating a webhook, SAVE THE SECRET immediately — it is only shown once\n"
            "- When rotating a webhook secret, the old secret is immediately invalidated\n"
            "- Max 5 webhooks per organization, HTTPS URLs only\n\n"
            "Always translate numeric server_group_id values to group names in your responses."
        ),
    )

    # Register tools, resources, and prompts
    register_tools(server, client=client)
    register_resources(server, client=client)
    register_prompts(server)

    return server


__all__ = ["create_server"]


if __name__ == "__main__":  # pragma: no cover
    server: FastMCP = create_server()
    run = getattr(server, "run", None)
    if callable(run):
        run()
    else:
        raise RuntimeError(
            "FastMCP server object does not expose a run() method; use the FastMCP CLI instead."
        )
