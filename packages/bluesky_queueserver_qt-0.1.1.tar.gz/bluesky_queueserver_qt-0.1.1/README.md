# Bluesky Queue Server Client

A PyQt5 desktop application for managing the [Bluesky Queue Server](https://github.com/bluesky/bluesky-queueserver).

## Features

- **ZMQ & HTTP connections** — Connect directly to the queue server via ZMQ, or via the HTTP server. HTTP connections support: no auth, API key, username/password (token), and basic auth.
- **Drag-and-drop queue building** — Browse allowed plans in the left panel, then drag them onto the queue or double-click to open the parameter editor.
- **Plan parameter editor** — Dynamically-built form based on the plan's parameter schema. Supports a raw JSON tab for power users.
- **Batch queue builder** — Build a queue of plans offline, then submit them all at once. Save and load batches as `.json` files. Repeat items N times with the repeat spinner.
- **Queue control** — Start, stop, pause, resume, abort, halt. Context menu on queue items to edit, remove, or execute immediately.
- **Run history** — View completed items with their exit status. Re-add any history item to the queue with one click.
- **Live status panel** — Always-visible bottom panel with manager state, RE state, environment state, and item counts. Also shows console output from the RE manager.
- **Window state persistence** — Layout and geometry are saved between sessions.

## Installation

```bash
pip install PyQt5 bluesky-queueserver-api
# For ZMQ support:
pip install bluesky-queueserver-api[zmq]
# For HTTP support:
pip install bluesky-queueserver-api[http]
```

Or install everything:

```bash
pip install -r requirements.txt
```

## Running

```bash
python main.py
```

## Connecting

### ZMQ (direct)
- Control address: `tcp://localhost:60615` (default)
- Console address: `tcp://localhost:60625` (optional, for console output)

Start the queue server:
```bash
start-re-manager
```

### HTTP Server
- URL: `http://localhost:60610` (default)
- Auth types: None / API Key / Username+Password / Basic Auth

Start the HTTP server:
```bash
uvicorn bluesky_httpserver.server:app --host localhost --port 60610
```

## Project Structure

```
bsqs_client/
├── main.py                  # Entry point + stylesheet
├── requirements.txt
├── core/
│   ├── connection.py        # ConnectionManager (ZMQ/HTTP, polling)
│   └── models.py            # QueueItem, BatchQueue data models
├── ui/
│   ├── main_window.py       # MainWindow
│   ├── connection_dialog.py # Connection configuration dialog
│   └── plan_edit_dialog.py  # Plan parameter editor dialog
└── widgets/
    ├── plan_browser.py      # Left panel: allowed plans/devices + drag source
    ├── queue_panel.py       # Queue list with controls
    ├── batch_panel.py       # Batch queue builder
    ├── history_panel.py     # Run history table
    └── status_panel.py      # Bottom status + console output
```
