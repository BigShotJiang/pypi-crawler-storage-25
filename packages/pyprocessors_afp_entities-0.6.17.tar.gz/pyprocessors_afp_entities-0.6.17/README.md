# pyprocessors_afp_entities

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_afp_entities)](https://github.com/oterrier/pyprocessors_afp_entities/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_afp_entities/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_afp_entities/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_afp_entities)](https://codecov.io/gh/oterrier/pyprocessors_afp_entities)
[![docs](https://img.shields.io/readthedocs/pyprocessors_afp_entities)](https://pyprocessors_afp_entities.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_afp_entities)](https://pypi.org/project/pyprocessors_afp_entities/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_afp_entities)](https://pypi.org/project/pyprocessors_afp_entities/)

AFPEntities annotations coming from different annotators

## Installation

You can simply `pip install pyprocessors_afp_entities`.

## Developing

### Pre-requesites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_afp_entities
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
