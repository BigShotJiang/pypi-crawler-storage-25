# Codex authentication via per-role bind-mount of `~/.codex/auth.json`

ADR 0015 introduced the `AgentService` seam and promised Codex would land separately. This is that change's architectural backbone. The OpenAI Codex CLI cannot route ChatGPT subscription billing via `OPENAI_API_KEY` — subscription requests need a `chatgpt-account-id` header populated only by `AuthMode::Chatgpt`. The only path is OAuth: `codex login` on the host writes `~/.codex/auth.json`, a mutable JSON file with access/refresh tokens that codex rotates on every refresh. Pycastle models codex auth as a **bind-mounted file**, not an env-var token, and pays for that with per-role seeding at `pycastle init`. Per-role copies diverge after first refresh — each role becomes its own refresh-token lineage. `refresh_token_reused` only fires when the *same* refresh token is reused, not for two independently-rotated descendants.

## Considered Options

- **`OPENAI_API_KEY` env var.** Rejected: can't route subscription billing; falls through to API billing.
- **`CODEX_ACCESS_TOKEN` env var (AgentIdentity mode).** Rejected: enterprise/service-account JWT path, not consumer ChatGPT OAuth.
- **Single shared bind-mount of `~/.codex/`.** Rejected: N containers writing to one `auth.json` race on refresh — first refresh invalidates the refresh token; others hit `refresh_token_reused`.
- **Read-only mount of `auth.json`.** Rejected: codex needs to write rotated token back.
- **Per-role bind-mount of `~/.codex/`, seeded at init — chosen.** Each role gets its own lineage at `.pycastle-session/<role>/[<namespace>/]codex/auth.json` bind-mounted to `/home/agent/.codex/`. After first refresh, host's `~/.codex/auth.json` is orphaned — re-seed via re-running init.
- **Lazy seeding on first run.** Rejected: hidden side effect; missing host login surfaces deep in dispatch instead of init.
- **Pycastle wrapping `codex login`.** Rejected: matches `claude setup-token` precedent — pycastle doesn't own the codex login UX.
- **Copy entire `~/.codex/` (auth + config.toml + sessions).** Rejected: pycastle owns the runtime contract (model/effort/sandbox/approval); inheriting host config invites footguns (host MCP servers pointing at host-only paths). Only `auth.json` is copied.
- **One Dockerfile installing both claude and codex.** Rejected: codex requires Node.js (~80–100 MB) irrelevant for claude-only users. Two templates — `Dockerfile.claude`, `Dockerfile.claude-codex` — picked by init wizard.

## Consequences

- **`CodexService`** at `src/pycastle/services/codex_service.py` implementing `AgentService` from ADR 0015. Single-account for v1 (mirrors `ClaudeService`'s `+2 min` safety margins).
- **`build_command` branches on `session_uuid`.** Fresh: `codex exec [flags] <prompt>`. Resume: `codex exec resume <thread_id> [flags] <prompt>`. `thread_id` comes from codex's `thread.started` JSONL event, persisted via `RoleSession` — diverges from claude's `--session-id` where pycastle generates the UUID.
- **`build_env` sets `TZ=UTC` and `CODEX_HOME=/home/agent/.codex`.** `TZ=UTC` is load-bearing: codex's `UsageLimitReachedError` Display renders reset timestamps in the *process's local timezone* using `%-I:%M %p` — never ISO, never zoned. Pinning UTC makes `_check_usage_limit` regex deterministic.
- **Per-role state-dir layout.** `state_dir_relpath(role, namespace) → .pycastle-session/<role>/[<namespace>/]codex/`. `is_resumable(state_dir)` True iff `state_dir/sessions/` contains `rollout-*.jsonl` — `auth.json` is pre-seeded and must not count.
- **Sandbox + approval pinned by pycastle.** `--sandbox danger-full-access` and `-c approval_policy=never` emitted unconditionally; not user-tunable. Pycastle's container is the isolation boundary.
- **`pycastle init` gains service-selection prompt** (`claude/codex/both`, default `claude`). Codex branch (a) verifies `~/.codex/auth.json` exists and exits non-zero with actionable instruction if not; (b) walks every role × namespace and copies host `auth.json` into each role's state dir. Only `auth.json` copied. Re-running seeds newly-added roles without disturbing existing ones.
- **Two static Dockerfile templates** ship in `defaults/`. Init picks one based on service-selection. `pycastle init --refresh` re-picks by walking config (no re-prompt) and overwrites. Refresh does NOT re-seed codex credentials.
- **Lazy service registry in `main.py`.** Walks stage overrides + top-level default to determine referenced service names; instantiates only those. Claude-only users pay zero codex startup cost.
- **Fail-fast `(service, effort)` validation** at top of `pycastle run`. Walks every effective `(stage, service, effort)` pair including fallback triples; asserts service known and effort in `service.valid_efforts()`. Collects violations, reports in single error. `valid_efforts()` added to `AgentService`: `ClaudeService` returns `{low, medium, high, xhigh, max}`; `CodexService` returns `{none, minimal, low, medium, high, xhigh}`.
- **Wire-format parser.** `CodexService.run(lines)` consumes JSONL `ThreadEvent`s. `item.completed type=agent_message` → `AssistantTurn`; `turn.completed.usage` → `Tokens` then return; `turn.failed | error` matching usage-limit regex → `UsageLimit(reset_time)`. `reasoning`, `command_execution`, `file_change`, `mcp_tool_call` dropped. No `Result` yield — `process_stream_from_events` fallback terminates on `turn.completed`.
- **Host-token invalidation is a documented gotcha.** After any role's first refresh, host's `~/.codex/auth.json` is orphaned; adding new roles requires another `codex login` + re-init.
- **No multi-account codex pool in v1.** Cross-service fallback via ADR 0015's `StageOverride.fallback` partially substitutes.
- **Upstream limitations tracked separately.** `--json` flattens `RateLimitSnapshot` to string and drops typed `resets_at` (#778). Reasoning items may swallow output protocol markers if model emits them in reasoning (#779).
- **Cleanup (#780, done):** `_KNOWN_MODELS` / `_list_models` / `ClaudeService.list_models` were dead code, removed. `CodexService` does not implement `list_models`.
