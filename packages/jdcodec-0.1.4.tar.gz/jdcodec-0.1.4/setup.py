from setuptools import setup, find_packages

setup(
    name="jdcodec",
    version="0.1.4",
    packages=find_packages(),
    install_requires=[
        "rich",
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "jdcodec=jdcodec_audit.audit:main",
        ],
    },
    author="JDCodec",
    description="The Temporal Codec for AI Agents - Diagnostic Tool",
    long_description="Hollow CLI prototype for capturing installation intent and auditing agent environments.",
    url="https://jdcodec.com",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
