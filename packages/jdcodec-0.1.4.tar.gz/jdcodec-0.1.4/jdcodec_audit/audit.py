import os
import sys
import time
import json
import random
import webbrowser
import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.theme import Theme

# Set up UI theme
custom_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "danger": "bold red",
    "success": "green",
})
console = Console(theme=custom_theme)

API_BASE = "https://jdcodec.com/api"

def main():
    args = sys.argv[1:]
    command = args[0] if args else "audit"

    if command in ["start", "login"]:
        run_login()
    elif command == "audit":
        run_audit()
    else:
        print_help()

def print_help():
    console.print("\n[bold]JD Codec CLI[/bold]")
    console.print("The Temporal Codec for AI Agents\n")
    console.print("Commands:")
    console.print("  [info]start[/info]   Register your node and join the Private Alpha")
    console.print("  [info]audit[/info]   Analyze your local agent environment\n")
    console.print("Usage:")
    console.print("  jdcodec start\n")

def run_login():
    console.print("\n[bold info] 🔐 JD Codec Cloud Authentication[/bold info]\n")
    
    # Generate random session ID
    import string
    session_id = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    auth_url = f"https://jdcodec.com/login?sid={session_id}"

    # 1. Register the session with the backend
    try:
        requests.post(f"{API_BASE}/auth/session", json={"session_id": session_id}, timeout=10)
    except:
        pass # Continue even if creation fails

    console.print(" To authenticate your local node, please visit:")
    console.print(f"[cyan underline]{auth_url}[/cyan underline]\n")
    console.print("[dim] Press any key to open your browser automatically...[/dim]")

    # Wait for keypress
    if sys.stdin.isatty():
        sys.stdin.read(1)

    console.print("[info]Opening browser...[/info]")
    webbrowser.open(auth_url)

    # 2. Poll for authentication completion
    email = None
    POLL_INTERVAL = 2
    POLL_TIMEOUT = 300
    start_time = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task(description="Waiting for authentication...", total=None)
        
        while time.time() - start_time < POLL_TIMEOUT:
            try:
                res = requests.get(f"{API_BASE}/auth/session?sid={session_id}", timeout=5)
                data = res.json()
                if data.get("status") == "completed":
                    email = data.get("email")
                    break
            except:
                pass
            time.sleep(POLL_INTERVAL)

    if email:
        console.print("\n[bold success] ✅ NODE REGISTERED [/bold success]\n")
        console.print(f" Account:  [info]{email}[/info]")
        console.print(f" Node ID:  [white]dv-node-{''.join(random.choices(string.ascii_letters, k=6))}[/white]\n")
        console.print("[dim] ----------------------------------------------------------------[/dim]")
        console.print(" We will notify you via email when your slot is provisioned.")
        console.print("[dim] ----------------------------------------------------------------[/dim]\n")
    else:
        console.print("[danger]Authentication timed out.[/danger]")
        console.print("[dim]Try again with: jdcodec start[/dim]\n")

def run_audit():
    console.print("\n[bold info] 🚀 JD Codec v0.1.0-alpha initializing...[/bold info]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(description="Analyzing local agent environment...", total=None)
        
        audit_results = {
            "langchain": os.path.exists("requirements.txt") and "langchain" in open("requirements.txt").read(),
            "playwright": os.path.exists("requirements.txt") and "playwright" in open("requirements.txt").read(),
            "browser_use": os.path.exists("requirements.txt") and "browser-use" in open("requirements.txt").read(),
            "keys_found": 0
        }
        
        if os.environ.get("OPENAI_API_KEY"): audit_results["keys_found"] += 1
        if os.environ.get("ANTHROPIC_API_KEY"): audit_results["keys_found"] += 1
        
        time.sleep(1.0)

    # 3. Telemetry (Optional)
    try:
        requests.post(f"{API_BASE}/intent-logger", json={
            "machine_id": "py-node-" + str(random.randint(1000, 9999)),
            "source": "pip",
            "audit_results": audit_results
        }, timeout=5)
    except:
        pass

    # Reporting
    if audit_results["playwright"] or audit_results["browser_use"]:
        console.print("[success] ✅ System Check: COMPATIBLE[/success]")
        console.print("[dim] Detected: Python Agent framework found.[/dim]\n")
    else:
        console.print("[warning] ⚠️ System Check: PARTIAL COMPATIBILITY[/warning]")
        console.print("[dim] Note: No active Python agent framework detected in current directory.[/dim]\n")

    console.print("To finish registration and join the Alpha, run:")
    console.print("[bold info] jdcodec start[/bold info]\n")

if __name__ == "__main__":
    main()
