# Copyright (C) 2022 The Qt Company Ltd.
# SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

from . import *

def activeStateToString(state: ActiveState) -> str: ...
def blurRadiusNecessarySpace(blurRadius: float) -> int: ...
def centerWidget(widget: PySide6.QtWidgets.QWidget, host: PySide6.QtWidgets.QWidget | None = ...) -> None: ...
def checkStateToString(state: CheckState) -> str: ...
def clearFocus(widget: PySide6.QtWidgets.QWidget, recursive: bool) -> None: ...
def clearLayout(layout: PySide6.QtWidgets.QLayout) -> None: ...
def colorWithAlpha(
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    alpha: int,
) -> PySide6.QtGui.QColor: ...
def colorWithAlphaF(
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    alpha: float,
) -> PySide6.QtGui.QColor: ...
def colorizeImage(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QImage: ...
def colorizePixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def displayedShortcutString(
    shortcut: PySide6.QtGui.QKeySequence
    | PySide6.QtCore.QKeyCombination
    | PySide6.QtGui.QKeySequence.StandardKey
    | str
    | int,
) -> str: ...
def drawArrowDown(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawArrowLeft(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawArrowRight(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawArrowUp(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawCalendarIndicator(
    rect: PySide6.QtCore.QRect,
    p: PySide6.QtGui.QPainter,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> None: ...
def drawCheckBoxIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter, progress: float = ...) -> None: ...
def drawCheckButton(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    radius: float,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    progress: float,
    checkState: CheckState,
) -> None: ...
def drawCheckerboard(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    darkColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    lightColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    cellWidth: float,
) -> None: ...
def drawCloseIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawColorMark(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    borderWidth: int = ...,
) -> None: ...
def drawColorMarkBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    borderColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    borderWidth: int,
) -> None: ...
def drawComboBoxIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawDebugRect(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawDial(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    min: int,
    max: int,
    value: float,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    handleColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    grooveColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    valueColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    markColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    grooveThickness: int,
    markLength: int,
    markThickness: int,
) -> None: ...
def drawDialTickMarks(
    p: PySide6.QtGui.QPainter,
    tickmarksRect: PySide6.QtCore.QRect,
    tickColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    min: int,
    max: int,
    tickThickness: int,
    tickLength: int,
    singleStep: int,
    pageStep: int,
    minArcLength: int,
) -> None: ...
def drawDoubleArrowRightIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawElidedMultiLineText(
    p: PySide6.QtGui.QPainter, rect: PySide6.QtCore.QRect, text: str, paintDevice: PySide6.QtGui.QPaintDevice
) -> None: ...
def drawEllipseBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
) -> None: ...
def drawGripIndicator(
    rect: PySide6.QtCore.QRect,
    p: PySide6.QtGui.QPainter,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    orientation: PySide6.QtCore.Qt.Orientation,
) -> None: ...
def drawIcon(
    rect: PySide6.QtCore.QRect,
    p: PySide6.QtGui.QPainter,
    icon: PySide6.QtGui.QIcon | PySide6.QtGui.QPixmap,
    mouse: MouseState,
    checked: CheckState,
    widget: PySide6.QtWidgets.QWidget,
    colorize: bool = ...,
    color: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int = ...,
) -> PySide6.QtCore.QRect: ...
def drawMenuSeparator(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    thickness: int,
) -> None: ...
def drawPartiallyCheckedCheckBoxIndicator(
    rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter, progress: float = ...
) -> None: ...
def drawProgressBarValueRect(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    min: float,
    max: float,
    value: float,
    radius: float = ...,
    inverted: bool = ...,
) -> None: ...
def drawRadioButton(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    progress: float,
) -> None: ...
def drawRadioButtonIndicator(
    rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter, progress: float = ...
) -> None: ...
@typing.overload
def drawRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
) -> None: ...
@typing.overload
def drawRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
) -> None: ...
@typing.overload
def drawRoundedRect(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    brush: PySide6.QtGui.QBrush
    | PySide6.QtCore.Qt.BrushStyle
    | PySide6.QtCore.Qt.GlobalColor
    | PySide6.QtGui.QColor
    | PySide6.QtGui.QGradient
    | PySide6.QtGui.QImage
    | PySide6.QtGui.QPixmap,
    radiuses: RadiusesF,
) -> None: ...
@typing.overload
def drawRoundedRect(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    brush: PySide6.QtGui.QBrush
    | PySide6.QtCore.Qt.BrushStyle
    | PySide6.QtCore.Qt.GlobalColor
    | PySide6.QtGui.QColor
    | PySide6.QtGui.QGradient
    | PySide6.QtGui.QImage
    | PySide6.QtGui.QPixmap,
    radius: float = ...,
) -> None: ...
@typing.overload
def drawRoundedRect(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    brush: PySide6.QtGui.QBrush
    | PySide6.QtCore.Qt.BrushStyle
    | PySide6.QtCore.Qt.GlobalColor
    | PySide6.QtGui.QColor
    | PySide6.QtGui.QGradient
    | PySide6.QtGui.QImage
    | PySide6.QtGui.QPixmap,
    radiuses: RadiusesF,
) -> None: ...
@typing.overload
def drawRoundedRect(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    brush: PySide6.QtGui.QBrush
    | PySide6.QtCore.Qt.BrushStyle
    | PySide6.QtCore.Qt.GlobalColor
    | PySide6.QtGui.QColor
    | PySide6.QtGui.QGradient
    | PySide6.QtGui.QImage
    | PySide6.QtGui.QPixmap,
    radius: float = ...,
) -> None: ...
@typing.overload
def drawRoundedRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    radiuses: RadiusesF,
) -> None: ...
@typing.overload
def drawRoundedRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    radius: float = ...,
) -> None: ...
@typing.overload
def drawRoundedRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    radiuses: RadiusesF,
) -> None: ...
@typing.overload
def drawRoundedRectBorder(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    borderWidth: float,
    radius: float = ...,
) -> None: ...
def drawRoundedTriangle(
    p: PySide6.QtGui.QPainter, rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect, radius: float = ...
) -> None: ...
def drawShortcut(
    p: PySide6.QtGui.QPainter,
    shortcut: PySide6.QtGui.QKeySequence
    | PySide6.QtCore.QKeyCombination
    | PySide6.QtGui.QKeySequence.StandardKey
    | str
    | int,
    rect: PySide6.QtCore.QRect,
    theme: Theme,
    enabled: bool,
    alignment: PySide6.QtCore.Qt.AlignmentFlag = ...,
) -> None: ...
def drawSliderTickMarks(
    p: PySide6.QtGui.QPainter,
    tickmarksRect: PySide6.QtCore.QRect,
    tickColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    min: int,
    max: int,
    interval: int,
    tickThickness: int,
    singleStep: int,
    pageStep: int,
) -> None: ...
def drawSpinBoxArrowIndicator(
    rect: PySide6.QtCore.QRect,
    p: PySide6.QtGui.QPainter,
    buttonSymbol: PySide6.QtWidgets.QAbstractSpinBox.ButtonSymbols,
    subControl: PySide6.QtWidgets.QStyle.SubControl,
    iconSize: PySide6.QtCore.QSize,
) -> None: ...
def drawStatusBadge(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    statusBadge: StatusBadge,
    size: StatusBadgeSize,
    theme: Theme,
) -> None: ...
def drawSubMenuIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawTab(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    radiuses: RadiusesF,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    drawShadow: bool = ...,
    shadowColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int = ...,
) -> None: ...
def drawTabShadow(
    p: PySide6.QtGui.QPainter,
    rect: PySide6.QtCore.QRect,
    radius: RadiusesF,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> None: ...
def drawToolBarExtensionIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter) -> None: ...
def drawTreeViewIndicator(rect: PySide6.QtCore.QRect, p: PySide6.QtGui.QPainter, open: bool) -> None: ...
def focusStateToString(state: FocusState) -> str: ...
def getActiveState(state: PySide6.QtWidgets.QStyle.StateFlag) -> ActiveState: ...
def getAlternateState(state: PySide6.QtWidgets.QStyleOptionViewItem.ViewItemFeature) -> AlternateState: ...
def getBlurredPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage, blurRadius: float
) -> PySide6.QtGui.QPixmap: ...
def getCachedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    mode: ColorizeMode,
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def getCheckState(state: PySide6.QtWidgets.QStyle.StateFlag) -> CheckState: ...
@typing.overload
def getCheckState(state: PySide6.QtCore.Qt.CheckState) -> CheckState: ...
@typing.overload
def getCheckState(checked: bool) -> CheckState: ...
@typing.overload
def getColorRole(checked: CheckState) -> ColorRole: ...
@typing.overload
def getColorRole(state: PySide6.QtWidgets.QStyle.StateFlag, isDefault: bool) -> ColorRole: ...
@typing.overload
def getColorRole(checked: bool, isDefault: bool) -> ColorRole: ...
def getColorSourceOver(
    bg: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    fg: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QColor: ...
def getColorizedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def getComboBoxItemMouseState(state: PySide6.QtWidgets.QStyle.StateFlag) -> MouseState: ...
def getContrastRatio(
    c1: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    c2: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> float: ...
def getDpi(widget: PySide6.QtWidgets.QWidget) -> float: ...
@typing.overload
def getDropShadowPixmap(
    size: PySide6.QtCore.QSize,
    borderRadius: float,
    blurRadius: float,
    color: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int = ...,
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def getDropShadowPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    blurRadius: float,
    color: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int = ...,
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def getExtendedImage(input: PySide6.QtGui.QImage, padding: int) -> PySide6.QtGui.QImage: ...
@typing.overload
def getExtendedImage(input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage, padding: int) -> PySide6.QtGui.QImage: ...
@typing.overload
def getFocusState(state: PySide6.QtWidgets.QStyle.StateFlag) -> FocusState: ...
@typing.overload
def getFocusState(focused: bool) -> FocusState: ...
def getIconMode(mouse: MouseState) -> PySide6.QtGui.QIcon.Mode: ...
def getIconState(checked: CheckState) -> PySide6.QtGui.QIcon.State: ...
def getImageAspectRatio(path: str) -> float: ...
def getLayoutHSpacing(widget: PySide6.QtWidgets.QWidget) -> int: ...
def getLayoutMargins(widget: PySide6.QtWidgets.QWidget) -> PySide6.QtCore.QMargins: ...
def getLayoutVSpacing(widget: PySide6.QtWidgets.QWidget) -> int: ...
def getMenuIndicatorPath(rect: PySide6.QtCore.QRect) -> PySide6.QtGui.QPainterPath: ...
def getMenuItemMouseState(state: PySide6.QtWidgets.QStyle.StateFlag) -> MouseState: ...
@typing.overload
def getMouseState(state: PySide6.QtWidgets.QStyle.StateFlag) -> MouseState: ...
@typing.overload
def getMouseState(pressed: bool, hovered: bool, enabled: bool) -> MouseState: ...
def getMultipleRadiusesRectPath(
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect, radiuses: RadiusesF
) -> PySide6.QtGui.QPainterPath: ...
@typing.overload
def getPaletteColorGroup(mouse: MouseState) -> PySide6.QtGui.QPalette.ColorGroup: ...
@typing.overload
def getPaletteColorGroup(state: PySide6.QtWidgets.QStyle.StateFlag) -> PySide6.QtGui.QPalette.ColorGroup: ...
def getPixelRatio(w: PySide6.QtWidgets.QWidget) -> float: ...
def getPixmap(
    icon: PySide6.QtGui.QIcon | PySide6.QtGui.QPixmap,
    iconSize: PySide6.QtCore.QSize,
    mouse: MouseState,
    checked: CheckState,
    widget: PySide6.QtWidgets.QWidget,
) -> PySide6.QtGui.QPixmap: ...
def getScrollBarHandleState(
    state: PySide6.QtWidgets.QStyle.StateFlag, activeSubControls: PySide6.QtWidgets.QStyle.SubControl
) -> MouseState: ...
def getSelectionState(state: PySide6.QtWidgets.QStyle.StateFlag) -> SelectionState: ...
def getSliderHandleState(
    state: PySide6.QtWidgets.QStyle.StateFlag, activeSubControls: PySide6.QtWidgets.QStyle.SubControl
) -> MouseState: ...
def getState(enabled: bool, hover: bool, pressed: bool) -> PySide6.QtWidgets.QStyle.StateFlag: ...
def getTabCount(parentWidget: PySide6.QtWidgets.QWidget) -> int: ...
def getTabIndex(optTab: PySide6.QtWidgets.QStyleOptionTab, parentWidget: PySide6.QtWidgets.QWidget) -> int: ...
def getTabItemMouseState(state: PySide6.QtWidgets.QStyle.StateFlag, tabIsHovered: bool) -> MouseState: ...
def getTabPath(rect: PySide6.QtCore.QRect, radiuses: RadiusesF) -> PySide6.QtGui.QPainterPath: ...
def getTickInterval(
    tickInterval: int, singleStep: int, pageStep: int, min: int, max: int, sliderLength: int
) -> int: ...
def getTintedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def getToolButtonMouseState(state: PySide6.QtWidgets.QStyle.StateFlag) -> MouseState: ...
def getTopLevelMenu(menu: PySide6.QtWidgets.QMenu) -> PySide6.QtWidgets.QMenu: ...
def getWindow(widget: PySide6.QtWidgets.QWidget) -> PySide6.QtGui.QWindow: ...
def isPointInRoundedRect(
    point: PySide6.QtCore.QPointF | PySide6.QtCore.QPoint | PySide6.QtGui.QPainterPath.Element,
    rect: PySide6.QtCore.QRectF | PySide6.QtCore.QRect,
    cornerRadius: float,
) -> bool: ...
def makeArrowLeftPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeArrowRightPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeCalendarPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeCheckPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeClearButtonPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeDoubleArrowRightPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeFitPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage, size: PySide6.QtCore.QSize
) -> PySide6.QtGui.QPixmap: ...
def makeHorizontalLine(
    parentWidget: PySide6.QtWidgets.QWidget, maxWidth: int = ...
) -> PySide6.QtWidgets.QWidget: ...
@typing.overload
def makeIconFromSvg(
    svgPath: str, iconTheme: IconTheme, size: PySide6.QtCore.QSize = ...
) -> PySide6.QtGui.QIcon: ...
@typing.overload
def makeIconFromSvg(svgPath: str, size: PySide6.QtCore.QSize) -> PySide6.QtGui.QIcon: ...
def makeMessageBoxCriticalPixmap(
    size: PySide6.QtCore.QSize,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeMessageBoxInformationPixmap(
    size: PySide6.QtCore.QSize,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeMessageBoxQuestionPixmap(
    size: PySide6.QtCore.QSize,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeMessageBoxWarningPixmap(
    size: PySide6.QtCore.QSize,
    bgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
    fgColor: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def makePixmapFromSvg(svgPath: str, size: PySide6.QtCore.QSize) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def makePixmapFromSvg(
    backgroundSvgPath: str,
    backgroundSvgColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    foregroundSvgPath: str,
    foregroundSvgColor: PySide6.QtGui.QColor
    | str
    | PySide6.QtGui.QRgba64
    | typing.Any
    | PySide6.QtCore.Qt.GlobalColor
    | int,
    size: PySide6.QtCore.QSize,
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def makeRoundedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage, radiuses: RadiusesF
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def makeRoundedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage, radius: float
) -> PySide6.QtGui.QPixmap: ...
@typing.overload
def makeRoundedPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    topLeft: float,
    topRight: float,
    bottomRight: float,
    bottomLeft: float,
) -> PySide6.QtGui.QPixmap: ...
def makeToolBarExtensionPixmap(
    size: PySide6.QtCore.QSize,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def makeVerticalLine(
    parentWidget: PySide6.QtWidgets.QWidget, maxHeight: int = ...
) -> PySide6.QtWidgets.QWidget: ...
def mouseStateToString(state: MouseState) -> str: ...
def pixelSizeToPointSize(pixelSize: float, dpi: float) -> float: ...
def pointSizeToPixelSize(pointSize: float, dpi: float) -> float: ...
def printState(state: PySide6.QtWidgets.QStyle.StateFlag) -> str: ...
def removeTrailingWhitespaces(str: str) -> str: ...
def selectionStateToString(state: SelectionState) -> str: ...
def shortcutSizeHint(
    shortcut: PySide6.QtGui.QKeySequence
    | PySide6.QtCore.QKeyCombination
    | PySide6.QtGui.QKeySequence.StandardKey
    | str
    | int,
    theme: Theme,
) -> PySide6.QtCore.QSize: ...
def shouldHaveBoldFont(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldHaveExternalFocusFrame(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldHaveHoverEvents(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldHaveMouseTracking(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldHaveTabFocus(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldNotBeVerticallyCompressed(w: PySide6.QtWidgets.QWidget) -> bool: ...
def shouldNotHaveWheelEvents(w: PySide6.QtWidgets.QWidget) -> bool: ...
def textWidth(fm: PySide6.QtGui.QFontMetrics, text: str) -> int: ...
def tintPixmap(
    input: PySide6.QtGui.QPixmap | PySide6.QtGui.QImage,
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> PySide6.QtGui.QPixmap: ...
def toHexRGB(
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> str: ...
def toHexRGBA(
    color: PySide6.QtGui.QColor | str | PySide6.QtGui.QRgba64 | typing.Any | PySide6.QtCore.Qt.GlobalColor | int,
) -> str: ...
