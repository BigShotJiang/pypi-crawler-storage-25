[![Tests](https://github.com/qingweizhang054/causal-toolkit-qingwei-package/actions/workflows/tests.yml/badge.svg)](https://github.com/qingweizhang054/causal-toolkit-qingwei-package/actions)

# causal_toolkit_qingwei

A Python package for causal inference methods, including:

- ATE estimation
- IPW
- Doubly Robust Estimation
- S-Learner
- T-Learner
- X-Learner
- Double ML

---

## Installation

```bash
git clone https://github.com/qingweizhang054/causal-toolkit-qingwei-package.git
cd causal-toolkit-qingwei-package

uv venv
.venv\Scripts\activate

uv pip install -e ".[dev]"
````

---

## Run Tests

```bash id="dxr5lu"
uv run pytest
```

---

## Example Usage

```python id="9a67pi"
from causal_toolkit_qingwei import (
    calculate_ate_ci,
    ipw,
    x_learner_discrete
)
```

---

## Author

Qingwei Zhang  
University of Chicago
