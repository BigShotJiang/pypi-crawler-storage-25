# TCB Sandbox SDK for Python

Python SDK for tcb-remote-workspace HTTP API.

## Installation

```bash
pip install tcb-sandbox-sdk-py==0.2.2
```

## Usage

```python
from tcb_sandbox_sdk_py import TcbSandboxClient

client = TcbSandboxClient(
    base_url="https://your-gateway.com",
    cloudbase_session_id="your-session-id",
)

result = client.execution.bash(command="echo hello")
print(result.result)
```

## Documentation

See [tcb-remote-workspace](https://github.com/tencentyun/tcb-remote-workspace) for full API documentation.
