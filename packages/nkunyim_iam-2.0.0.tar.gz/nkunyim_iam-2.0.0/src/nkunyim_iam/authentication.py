from http import HTTPMethod
import json
from typing import Optional

from django.http import HttpRequest
from rest_framework import HTTP_HEADER_ENCODING, authentication

from nkunyim_iam.token import TokenManager



class HttpHeader:
    def __init__(self) -> None:
        self.authentication_headers = ["Bearer", "JWT",]
    
    def get_token(self, key: str, request: HttpRequest) -> Optional[str]:
        header = request.META.get(key, None)
        if header is None:
            return None

        if isinstance(header, str):
            header = header.encode(HTTP_HEADER_ENCODING)

        if isinstance(header, bytes):
            header = header.decode(HTTP_HEADER_ENCODING)

        if not isinstance(header, str):
            header = str(header)
            
        parts = header.split()
        if len(parts) == 0:
            return None

        if parts[0] not in self.authentication_headers:
            return None
        
        if len(parts) != 2:
            return None

        return parts[1]
    
    def get_signature(self, request: HttpRequest) -> Optional[str]:
        return self.get_token(key='HTTP_AUTHENTICATION', request=request)
    
    def get_jwt_token(self, request: HttpRequest) -> Optional[str]:
        return self.get_token(key='HTTP_AUTHORIZATION', request=request)
    
   
class SignatureAuthentication:
    def verify_signature(self, request) -> bool:
        if not request.method in [HTTPMethod.POST, HTTPMethod.PATCH, HTTPMethod.PUT]:
            return True
        
        signature = HttpHeader().get_signature(request=request)
        if not signature:
            return False

        body = json.loads(request.body.decode('utf-8'))
        if not body:
            return False
        
        return TokenManager.verify(signature=signature, payload=body)
 

class JWTAuthentication(authentication.BaseAuthentication, SignatureAuthentication):
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)

        self.http = HttpHeader()
        self.www_authenticate_realm = 'api' 

    def authenticate_header(self, request): # type: ignore
        return '{0} realm="{1}"'.format(
            self.http.authentication_headers[0],
            self.www_authenticate_realm,
        )
        
        
    def authenticate(self, request):
        token = self.http.get_jwt_token(request=request)
        if token is None:
            return None
        
        user, claim = TokenManager.authenticate(token=token)
        if not user:
            return None
        
        if not self.verify_signature(request=request):
            return None
        
        return (user, claim)



class TokenAuthentication(authentication.BaseAuthentication, SignatureAuthentication):
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)

        self.http = HttpHeader()
        self.www_authenticate_realm = 'api' 

    def authenticate_header(self, request): # type: ignore
        return '{0} realm="{1}"'.format(
            self.http.authentication_headers[0],
            self.www_authenticate_realm,
        )
        
        
    def authenticate(self, request):
        token = self.http.get_jwt_token(request=request)
        if token is None:
            return None
        
        user, claim = TokenManager.authorize(token=token)
        if not user:
            return None
        
        if not self.verify_signature(request=request):
            return None
        
        return (user, claim)
