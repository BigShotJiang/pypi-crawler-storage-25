import requests

from django.conf import settings

from nkunyim_iam.config import ServiceConfig
from nkunyim_iam.token import TokenManager



class HttpClientBase:
    def __init__(self, service_name: str) -> None:
        service = settings.NKUNYIM_SERVICE_CONFIG[service_name.upper()]
        self.config = ServiceConfig(**service)
        self.base_url = self.config.back_url.rstrip('/')
        self.headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

    def _sign(self, data: dict) -> None:
        if self.config.verify and self.config.key is not '':
            signature = TokenManager.sign(key=self.config.key, payload=data)
            self.headers['Authentication'] = f'JWT {signature}'

    def _url(self, path: str) -> str:
        return f"{self.base_url.rstrip('/')}/{path.strip('/')}/"
        
    def get(self, path: str) -> requests.Response:
        self._sign(data={})
        return requests.get(url=self._url(path), headers=self.headers)

    def post(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.post(url=self._url(path), data=data, headers=self.headers)

    def put(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.put(url=self._url(path), data=data, headers=self.headers)

    def patch(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.patch(url=self._url(path), data=data, headers=self.headers)

    def delete(self, path: str) -> requests.Response:
        self._sign(data={})
        return requests.delete(url=self._url(path), headers=self.headers)



class HttpClient(HttpClientBase):
    def __init__(self, service_name: str) -> None:
        super().__init__(service_name=service_name)
        self._token()

    def _token(self) -> None:
        access_token = TokenManager.client_credential_token()
        if access_token:
            self.headers['Authorization'] = f'Bearer {access_token}'

