
import base64
from datetime import datetime, timezone
import hashlib
import hmac
import json
from typing import Optional

from django.conf import settings
from keycloak import KeycloakOpenID

from nkunyim_iam.config import ClientConfig, ServiceConfig
from nkunyim_iam.commands import UserCommand
from nkunyim_iam.data import AccessTokenData, ClaimData, InitAuthData, UserInfoData
from nkunyim_iam.encryption import JWTEncryption
from nkunyim_iam.handlers import LoggingHandler, UserHandler
from nkunyim_iam.models import User
from nkunyim_iam.queries import UserQuery


class TokenService:
    def __init__(self) -> None:
        client = settings.NKUNYIM_CLIENT_CONFIG
        self.config = ClientConfig(**client)
        self.kc_oidc = KeycloakOpenID(
            server_url=self.config.server_url,
            client_id=self.config.client_id,
            realm_name=self.config.realm_name,
            client_secret_key=self.config.client_secret,
            pool_maxsize=15
        )
        
        
    def get_well_known(self) -> dict:
        return self.kc_oidc.well_known()
    
    
    def get_auth_url(self) -> str:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        if not self.config.scope:
            raise ValueError("Scope is not set in the configuration.")
        
        return self.kc_oidc.auth_url(redirect_uri=self.config.redirect_uri, scope=self.config.scope)
    
    
    def get_auth_url_secure(self, data: InitAuthData) -> str:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        if not self.config.scope:
            raise ValueError("Scope is not set in the configuration.")
        
        return self.kc_oidc.auth_url(
            redirect_uri=self.config.redirect_uri,
            scope=self.config.scope,
            nonce=data.nonce,
            state=data.state,
            code_challenge=data.code_challenge,
            code_challenge_method=data.code_challenge_method,
        )

        
    def exchange_token(self, code: str) -> dict:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        
        return self.kc_oidc.token(
            grant_type=self.config.grant_type,
            code=code,
            redirect_uri=self.config.redirect_uri,
        )
        
    
    def exchange_token_totp(self, code: str, totp: int) -> dict:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        
        return self.kc_oidc.token(
            grant_type=self.config.grant_type,
            code=code,
            redirect_uri=self.config.redirect_uri,
            totp=totp,
        )
        
        
    def exchange_token_secure(self, code: str, code_verifier: str) -> dict:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        
        return self.kc_oidc.token(
            grant_type=self.config.grant_type,
            code=code,
            redirect_uri=self.config.redirect_uri,
            code_verifier=code_verifier,
        )
        
        
    def exchange_token_totp_secure(self, code: str, code_verifier: str, totp: int) -> dict:
        if not self.config.redirect_uri:
            raise ValueError("Redirect URI is not set in the configuration.")
        
        return self.kc_oidc.token(
            grant_type=self.config.grant_type,
            code=code,
            redirect_uri=self.config.redirect_uri,
            code_verifier=code_verifier,
            totp=totp,
        )
        
        
    def get_client_credentials_token(self) -> dict:
        return self.kc_oidc.token(grant_type="client_credentials")


    def refresh_token(self, refresh_token: str) -> dict:
        return self.kc_oidc.refresh_token(refresh_token=refresh_token)
    
    
    def get_userinfo(self, access_token: str) -> dict:
        userinfo = self.kc_oidc.userinfo(token=access_token)

        if isinstance(userinfo, bytes):
            userinfo = userinfo.decode("utf-8")

        if isinstance(userinfo, str):
            userinfo = json.loads(userinfo)

        if not isinstance(userinfo, dict):
            raise ValueError("Error fetching user info: unexpected response format.")

        if "error" in userinfo:
            error_description = userinfo.get("error_description") or userinfo["error"]
            raise ValueError(f"Error fetching user info: {error_description}")

        return userinfo


    def introspect_token(self, access_token: str) -> dict:
        return self.kc_oidc.introspect(token=access_token)


    def decode_token(self, access_token: str, validate: bool = False) -> dict:
        return self.kc_oidc.decode_token(token=access_token, validate=validate)


    def logout(self, refresh_token: str) -> None:
        self.kc_oidc.logout(refresh_token=refresh_token)
        


class TokenManager:
    @staticmethod
    def sign(key: str, payload: dict) -> Optional[str]:
        try:
            message = json.dumps(payload, sort_keys=True, separators=(",", ":"))
            digest = hmac.new(
                key.encode(),
                msg=message.encode(),
                digestmod=hashlib.sha256
            ).hexdigest()
            encoded = digest.encode()
            signature = base64.b64encode(encoded).decode()
            return signature
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to decode userinfo data from JWT.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "sign",
                },
                context={"exception": str(ex)},
            )
            return None
    
    
    @staticmethod
    def verify(signature: str, payload: dict) -> bool:
        try:
            name = str(settings.NKUNYIM_SERVICE_CONFIG["NAME"])
            service = settings.NKUNYIM_SERVICE_CONFIG[name.upper()]
            config = ServiceConfig(**service)
            if not config.verify:
                return True
            
            resign = TokenManager.sign(key=config.key, payload=payload)
            return resign == signature
    
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to decode userinfo data from JWT.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "sign",
                },
                context={"exception": str(ex)},
            )
            return False
        
    
    @staticmethod
    def client_credential_token() -> Optional[str]:
        try:
            token_service = TokenService()
            token_data = token_service.get_client_credentials_token()
            return token_data['access_token']
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from database.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "client_credential_token",
                },
                context={"exception": str(ex)},
            )
            return None
        
    
    @staticmethod
    def jwt_claim(access_token: str) -> tuple[Optional[UserInfoData], Optional[ClaimData]]:
        try:
            decoded = JWTEncryption.decode(token=access_token)
            access_token_data = AccessTokenData(**decoded)
            if access_token_data.exp <= int(datetime.now(timezone.utc).timestamp()):
                LoggingHandler.danger(
                    message="Access token has expired.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_claim",
                    },
                    context={"exp": str(access_token_data.exp)},
                )
                return None, None
            
            if not access_token_data.scope:
                LoggingHandler.danger(
                    message="Access token has no scope claim.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_claim",
                    },
                    context={"scope": access_token_data.scope},
                )
                return None, None
            
            if not access_token_data.resource_access:
                LoggingHandler.danger(
                    message="Access token has no resource_access claim.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_claim",
                    },
                    context={"resource_access": access_token_data.resource_access},
                )
                return None, None
            
            service_name = str(settings.NKUNYIM_SERVICE_CONFIG["NAME"])
            if service_name not in  access_token_data.resource_access:
                LoggingHandler.danger(
                    message="Access denied, invalid claim.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_claim",
                    },
                    context={
                        "name": service_name,
                        "claim": ", ".join(access_token_data.resource_access)
                    },
                )
                return None, None
            
            claim = access_token_data.resource_access[service_name]
            return access_token_data.user, claim
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to decode userinfo data from JWT.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "jwt_userinfo",
                },
                context={"exception": str(ex)},
            )
            return None, None


    @staticmethod
    def authenticate(token: str) -> tuple[Optional[User], Optional[ClaimData]]:
        try:
            userinfo, claim = TokenManager.jwt_claim(access_token=token)
            if not userinfo:
                return None, None

            user_info = userinfo.model_dump()
            user_command = UserCommand(**user_info)
            user_model = UserHandler.handle(command=user_command)
            return user_model, claim
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "authenticate",
                },
                context={"exception": str(ex)},
            )
            return None, None


    @staticmethod
    def authorize(token: str) -> tuple[Optional[User], Optional[ClaimData]]:
        try:
            userinfo, claim = TokenManager.jwt_claim(access_token=token)
            if not userinfo:
                return None, None

            user_info = userinfo.model_dump()
            user_command = UserCommand(**user_info)
            user_model = UserQuery.find(id=user_command.id)
            
            return user_model, claim
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "authorize",
                },
                context={"exception": str(ex)},
            )
            return None, None

