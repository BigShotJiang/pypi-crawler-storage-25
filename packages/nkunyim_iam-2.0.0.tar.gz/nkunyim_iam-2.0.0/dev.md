# Developer Notes

## Virtual Environment
- sudo apt install python3.12-venv


## Required Packages
- sudo python3.14 -m venv /home/enoch/books/env/package
- source /home/enoch/books/env/package/bin/activate
- sudo chmod -R a+rwx /home/enoch/books/env/package
- pip install --upgrade pip
- pip install --upgrade build twine


## NkunyimUtil Dependencies
- cd /home/enoch/books/dev/nkunyim_iam
- sudo python3.12 -m venv /home/enoch/books/env/nkunyim
- source /home/enoch/books/env/nkunyim/bin/activate
- sudo chmod -R a+rwx /home/enoch/books/env/nkunyim
- pip install --upgrade pip
- pip install --upgrade Django requests cryptography djangorestframework
- pip install --upgrade pyyaml ua-parser user-agents
- pip install --upgrade pyjwt
- pip install --upgrade pydantic
- pip freeze > requirements.txt


### Select Project
- cd /home/enoch/books/dev/books.iam
- source /home/enoch/books/env/package/bin/activate

## Build Package
- python3 -m build


## Upload Package
- python3 -m twine upload dist/*