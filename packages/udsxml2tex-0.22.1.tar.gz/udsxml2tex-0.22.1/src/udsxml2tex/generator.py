"""LaTeX generator for UDS specification documents."""

from __future__ import annotations

import io
import logging
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from udsxml2tex.models import (
    DTC_SEVERITY_LEVELS,
    DTC_STATUS_BIT_DEFINITIONS,
    ISO14229_SERVICE_ORDER,
    NRC_CHECK_ORDER,
    STANDARD_NRCS,
    UDS_MESSAGE_FORMATS,
    UdsSpecification,
)

logger = logging.getLogger(__name__)

# Characters that need escaping in LaTeX
_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _latex_escape(text: str) -> str:
    """Escape special LaTeX characters in text."""
    if not text:
        return ""
    # Don't escape backslashes that are already LaTeX commands
    result = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text) and text[i + 1].isalpha():
            # Likely a LaTeX command, don't escape
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _strip_0x(text: str) -> str:
    """Strip '0x' or '0X' prefix from hex string for subscript-16 notation."""
    if isinstance(text, str) and text.lower().startswith("0x"):
        return text[2:]
    return str(text)


class TexGenerator:
    """Generate LaTeX documents from UDS specification data."""

    def __init__(self, template_dir: Optional[str | Path] = None) -> None:
        """Initialize the TeX generator.

        Args:
            template_dir: Directory containing Jinja2 templates.
                         Defaults to the built-in templates directory.
        """
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        else:
            template_dir = Path(template_dir)

        self.template_dir = template_dir
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # Register custom filters
        self.env.filters["latex_escape"] = _latex_escape
        self.env.filters["strip_0x"] = _strip_0x
        self.env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

    def generate(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.tex.j2",
        *,
        extra_vars: Optional[dict] = None,
    ) -> Path:
        """Generate a LaTeX document from the UDS specification.

        Args:
            spec:          The UDS specification data.
            output_path:   Path for the output .tex file.
            template_name: Name of the Jinja2 template to use.
            extra_vars:    Optional dict merged into the Jinja2 template context,
                           enabling project-specific variables in custom templates.

        Returns:
            Path to the generated .tex file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        context = self._build_context(spec)
        if extra_vars:
            context.update(extra_vars)

        template = self.env.get_template(template_name)
        rendered = template.render(**context)
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated LaTeX document: %s", output_path)

        for asset in ("tikz-uml.sty", "udsspec.cls"):
            src = self.template_dir / asset
            if src.exists():
                dst = output_path.parent / asset
                if not dst.exists():
                    shutil.copy2(src, dst)
                    logger.info("Copied %s to %s", asset, dst)

        return output_path

    def generate_string(
        self,
        spec: UdsSpecification,
        template_name: str = "uds_spec.tex.j2",
    ) -> str:
        """Generate LaTeX content as a string.

        Args:
            spec: The UDS specification data.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Rendered LaTeX content.
        """
        template = self.env.get_template(template_name)
        return template.render(**self._build_context(spec))

    def _build_context(self, spec: UdsSpecification) -> dict:
        """Build the shared Jinja2 template context from a UdsSpecification."""
        services = sorted(
            spec.services,
            key=lambda s: ISO14229_SERVICE_ORDER.get(s.service_id, 100),
        )
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        return {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "protocol_type": spec.protocol_type,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "s3_server": spec.s3_server,
            "dsl_rx_buffer_size": spec.dsl_rx_buffer_size,
            "dsl_tx_buffer_size": spec.dsl_tx_buffer_size,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "dtcs": sorted(spec.dtcs, key=lambda d: d.dtc_id),
            "memory_ranges": spec.memory_ranges,
            "io_control_dids": sorted(spec.io_control_dids, key=lambda d: d.did_id),
            "periodic_dids": sorted(spec.periodic_dids, key=lambda d: d.did_id),
            "did_ranges": sorted(spec.did_ranges, key=lambda d: d.lower_did),
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "standard_nrcs": STANDARD_NRCS,
            "session_names": session_names,
            "security_level_names": security_level_names,
            "com_control": spec.com_control,
            "response_on_event": spec.response_on_event,
            "dtc_status_availability_mask": spec.dtc_status_availability_mask,
            "max_num_resp_pend": spec.max_num_resp_pend,
            "max_response_length": spec.max_response_length,
            "request_file_transfer": spec.request_file_transfer,
            "clear_dtc_notifications": spec.clear_dtc_notifications,
            "dynamic_dids": sorted(spec.dynamic_dids, key=lambda d: d.did_id),
            "connection_mode": spec.connection_mode,
            "connection_end_of_type": spec.connection_end_of_type,
            "cdtc_status_mask": spec.cdtc_status_mask,
            "clear_dtc_group": spec.clear_dtc_group,
            "module_main_function_period": spec.module_main_function_period,
            "enable_fim_trigger": spec.enable_fim_trigger,
            "protocol_priority": spec.protocol_priority,
            "protocol_trans_type": spec.protocol_trans_type,
            "protocol_preempt_timeout": spec.protocol_preempt_timeout,
            "periodic_slow_rate": spec.periodic_slow_rate,
            "periodic_medium_rate": spec.periodic_medium_rate,
            "periodic_fast_rate": spec.periodic_fast_rate,
            "memory_compression_method": spec.memory_compression_method,
            "memory_encrypting_method": spec.memory_encrypting_method,
            "dev_error_detect": spec.dev_error_detect,
            "version_info_api": spec.version_info_api,
            "task_time": spec.task_time,
            "respond_all_request": spec.respond_all_request,
            "protocol_rows": sorted(spec.protocol_rows, key=lambda r: r.priority),
            "authentication_config": spec.authentication_config,
            "access_timing_rows": spec.access_timing_rows,
            # DEM (Diagnostic Event Manager)
            "dem_general": spec.dem_general,
            "dem_operation_cycles": spec.dem_operation_cycles,
            "dem_event_parameters": sorted(
                spec.dem_event_parameters, key=lambda e: e.event_id
            ),
            "dem_indicators": spec.dem_indicators,
            "dem_enable_conditions": spec.dem_enable_conditions,
            "dem_storage_conditions": spec.dem_storage_conditions,
            "dem_event_memories": spec.dem_event_memories,
            "dem_dtcs": sorted(spec.dem_dtcs, key=lambda d: d.dtc_value),
            "dem_freeze_frame_classes": spec.dem_freeze_frame_classes,
            "dem_extended_data_classes": sorted(
                spec.dem_extended_data_classes, key=lambda e: e.record_number
            ),
            "dem_combined_dtcs": sorted(
                spec.dem_combined_dtcs, key=lambda d: d.combined_dtc_value
            ),
            # ISO 14229-1 constant tables for template rendering
            "dtc_status_bit_definitions": DTC_STATUS_BIT_DEFINITIONS,
            "dtc_severity_levels": DTC_SEVERITY_LEVELS,
            # Upload/Download max block length (ISO 14229-1 §13)
            "max_block_length": spec.max_block_length,
            # LinkControl (0x87) supported baud rates
            "link_control_baudrates": sorted(
                spec.link_control_baudrates, key=lambda b: b.baudrate_value
            ),
            # Named DTC groups (DcmDspGroupOfDTC)
            "dtc_groups": sorted(spec.dtc_groups, key=lambda g: g.group_value),
        }

    # ---- PDF compilation ------------------------------------------------

    def compile_pdf(
        self,
        tex_path: str | Path,
        *,
        clean: bool = True,
    ) -> Path:
        """Compile a .tex file to PDF using latexmk or pdflatex.

        Args:
            tex_path: Path to the .tex file.
            clean: Remove auxiliary files after compilation.

        Returns:
            Path to the generated PDF.

        Raises:
            FileNotFoundError: If no LaTeX compiler is found.
            RuntimeError: If compilation fails.
        """
        tex_path = Path(tex_path).resolve()
        if not tex_path.exists():
            raise FileNotFoundError(f"TeX file not found: {tex_path}")

        work_dir = tex_path.parent

        # Prefer latexmk (handles multiple passes automatically)
        latexmk = shutil.which("latexmk")
        pdflatex = shutil.which("pdflatex")

        if latexmk:
            cmd = [
                latexmk,
                "-pdf",
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            if clean:
                clean_cmd = [latexmk, "-c", str(tex_path.name)]
        elif pdflatex:
            # Run pdflatex twice for TOC / references
            cmd = [
                pdflatex,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            clean_cmd = None
        else:
            raise FileNotFoundError(
                "No LaTeX compiler found. Install TeX Live or MiKTeX "
                "(latexmk or pdflatex must be on PATH)."
            )

        logger.info("Compiling PDF: %s", " ".join(cmd))
        runs = 1 if latexmk else 2
        for i in range(runs):
            result = subprocess.run(
                cmd,
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                logger.error("LaTeX stdout:\n%s", result.stdout[-2000:])
                logger.error("LaTeX stderr:\n%s", result.stderr[-2000:])
                raise RuntimeError(
                    f"LaTeX compilation failed (exit {result.returncode}). "
                    f"Check log file for details."
                )

        pdf_path = tex_path.with_suffix(".pdf")
        if not pdf_path.exists():
            raise RuntimeError(f"Expected PDF not found: {pdf_path}")

        # Clean auxiliary files
        if clean and latexmk and clean_cmd:
            subprocess.run(clean_cmd, cwd=str(work_dir), capture_output=True)

        logger.info("PDF generated: %s", pdf_path)
        return pdf_path

    # ---- HTML generation ------------------------------------------------

    def generate_html(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.html.j2",
    ) -> Path:
        """Generate an HTML document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .html file.
            template_name: Name of the HTML Jinja2 template.

        Returns:
            Path to the generated .html file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Create a separate Jinja2 environment with standard delimiters for HTML
        html_env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        html_env.filters["strip_0x"] = _strip_0x

        def _html_hex(value: str) -> str:
            """Render hex value with subscript-16 notation in HTML."""
            v = _strip_0x(str(value))
            return f'<span class="hexval">{v}<sub>16</sub></span>'

        html_env.filters["hexval"] = _html_hex

        template = html_env.get_template(template_name)
        rendered = template.render(**self._build_context(spec))
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated HTML document: %s", output_path)
        return output_path

    # ---- Structured multi-file LaTeX ZIP --------------------------------

    def generate_structured_tex_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
        cls_content: Optional[bytes] = None,
    ) -> Path:
        """Generate a structured multi-file LaTeX project and package it as a ZIP.

        The ZIP mirrors the layout of refs/uds-tex-spec with root.tex plus
        nested sections/, and optionally includes a custom .cls file.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
            cls_content: Raw bytes of an optional custom LaTeX class file to
                         include as ``custom.cls`` in the ZIP root.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        structured_dir = Path(__file__).parent / "templates" / "structured_tex"

        # Build a Jinja2 environment pointing at structured_tex/
        from jinja2 import Environment, FileSystemLoader

        tex_env = Environment(
            loader=FileSystemLoader(str(structured_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )
        tex_env.filters["latex_escape"] = _latex_escape
        tex_env.filters["strip_0x"] = _strip_0x
        tex_env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

        context = self._build_context(spec)

        # Gather all .j2 template files relative to structured_dir
        template_files = sorted(structured_dir.rglob("*.j2"))

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            for tmpl_path in template_files:
                rel = tmpl_path.relative_to(structured_dir)
                # Strip the .j2 extension to get the output filename
                out_rel = rel.with_suffix("")  # e.g. root.tex.j2 -> root.tex
                out_path = tmp / out_rel
                out_path.parent.mkdir(parents=True, exist_ok=True)

                template = tex_env.get_template(str(rel).replace("\\", "/"))
                rendered = template.render(**context)
                out_path.write_text(rendered, encoding="utf-8")
                logger.debug("Rendered structured template: %s", out_rel)

            # Copy tikz-uml.sty to zip root
            sty_src = Path(__file__).parent / "templates" / "tikz-uml.sty"
            if sty_src.exists():
                shutil.copy2(sty_src, tmp / "tikz-uml.sty")

            # Optionally write custom .cls file
            if cls_content is not None:
                (tmp / "custom.cls").write_bytes(cls_content)

            # Build the ZIP
            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated structured LaTeX ZIP: %s", output_path)
        return output_path

    # ---- Multi-page HTML ZIP --------------------------------------------

    def generate_html_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
    ) -> Path:
        """Generate a browsable multi-page HTML UDS specification and ZIP it.

        Creates index.html plus per-section HTML pages that can be opened
        locally in any browser.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        ctx = self._build_context(spec)

        pages = [
            ("index.html", "Overview", _render_html_index),
            ("intro.html", "Introduction", _render_html_intro),
            ("low_layer.html", "Network Protocol Layers", _render_html_low_layer),
            ("high_layer.html", "Application Layers", _render_html_high_layer),
            ("annex.html", "Annex", _render_html_annex),
        ]

        nav_items = "".join(
            f'<li><a href="{fname}">{title}</a></li>'
            for fname, title, _ in pages
        )
        nav_html = f"<ul>{nav_items}</ul>"

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            css = _HTML_CSS
            for fname, title, renderer in pages:
                body = renderer(ctx)
                page = _html_page(title, nav_html, body, css)
                (tmp / fname).write_text(page, encoding="utf-8")

            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated HTML ZIP: %s", output_path)
        return output_path

    # ---- JSON / YAML output ---------------------------------------------

    def generate_json(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to JSON."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(spec.to_json(), encoding="utf-8")
        logger.info("Generated JSON document: %s", output_path)
        return output_path

    def generate_yaml(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to YAML."""
        try:
            import yaml  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "PyYAML is required for YAML output. "
                "Install it with: pip install udsxml2tex[yaml]"
            )
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            yaml.dump(spec.to_dict(), allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )
        logger.info("Generated YAML document: %s", output_path)
        return output_path

    # ---- Markdown output ------------------------------------------------

    def generate_markdown(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a Markdown specification document."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_markdown(spec), encoding="utf-8")
        logger.info("Generated Markdown document: %s", output_path)
        return output_path

    # ---- RST output -----------------------------------------------------

    def generate_rst(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a reStructuredText specification document."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_rst(spec), encoding="utf-8")
        logger.info("Generated RST document: %s", output_path)
        return output_path

    # ---- CSV output -----------------------------------------------------

    def generate_csv(
        self,
        spec: UdsSpecification,
        output_dir: str | Path,
    ) -> list[Path]:
        """Generate CSV files (one per major category) in *output_dir*.

        Returns:
            List of paths to the generated CSV files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        return _render_csv(spec, output_dir)

    # ---- Session state-machine diagram ----------------------------------

    def generate_session_diagram(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a standalone TikZ session-transition diagram (.tex)."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_session_tikz(spec), encoding="utf-8")
        logger.info("Generated session diagram: %s", output_path)
        return output_path

    # ---- DOCX output ----------------------------------------------------

    def generate_docx(
        self,
        spec: UdsSpecification,
        path: "str | Path",
    ) -> Path:
        """Generate a DOCX document from the UDS specification.

        Requires: pip install udsxml2tex[docx]
        """
        try:
            from docx import Document  # type: ignore[import]
            from docx.shared import Pt, RGBColor  # type: ignore[import]
            from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore[import]
        except ImportError as exc:
            raise ImportError(
                "python-docx is required for DOCX output. "
                "Install with: pip install udsxml2tex[docx]"
            ) from exc
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _render_docx(spec, path)
        logger.info("Generated DOCX document: %s", path)
        return path

    # ---- UML sequence diagrams ------------------------------------------

    def generate_sequence_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> "list[Path]":
        """Generate TikZ sequence diagram .tex files into *output_dir*.

        Creates:
          - security_access_sequence.tex
          - routine_control_sequence.tex
          - upload_download_sequence.tex

        Returns:
            List of Path objects for the generated files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []

        # 1. SecurityAccess flow
        sa_participants = ["Tester", "ECU"]
        sa_messages = [
            ("Tester", "ECU", "Request Seed (27 01)", ""),
            ("ECU", "Tester", "Seed Response (67 01 seed...)", ""),
            ("Tester", "ECU", "Send Key (27 02 key...)", ""),
            ("ECU", "Tester", "Positive Response (67 02)", ""),
            ("ECU", "Tester", "NRC: invalidKey (35)", "dashed"),
            ("ECU", "Tester", "NRC: exceededNumberOfAttempts (36)", "dashed"),
            ("ECU", "Tester", "NRC: requiredTimeDelayNotExpired (37)", "dashed"),
        ]
        sa_path = output_dir / "security_access_sequence.tex"
        sa_path.write_text(
            _render_sequence_tikz("SecurityAccess Flow", sa_participants, sa_messages),
            encoding="utf-8",
        )
        written.append(sa_path)

        # 2. RoutineControl flow
        rc_participants = ["Tester", "ECU"]
        rc_messages = [
            ("Tester", "ECU", "Start Routine (31 01 routineId...)", ""),
            ("ECU", "Tester", "Positive Response (71 01 routineId...)", ""),
            ("Tester", "ECU", "Request Routine Results (31 03 routineId...)", ""),
            ("ECU", "Tester", "Results (71 03 routineId... statusRecord)", ""),
        ]
        rc_path = output_dir / "routine_control_sequence.tex"
        rc_path.write_text(
            _render_sequence_tikz("RoutineControl Flow", rc_participants, rc_messages),
            encoding="utf-8",
        )
        written.append(rc_path)

        # 3. Upload/Download flow
        ud_participants = ["Tester", "ECU"]
        ud_messages = [
            ("Tester", "ECU", "Request Download (34)", ""),
            ("ECU", "Tester", "maxBlockLength Response (74)", ""),
            ("Tester", "ECU", "Transfer Data [1] (36 01 data...)", ""),
            ("ECU", "Tester", "Transfer Data Response (76 01)", ""),
            ("Tester", "ECU", "... [loop] Transfer Data [N] (36 N data...)", ""),
            ("ECU", "Tester", "Transfer Data Response [N] (76 N)", ""),
            ("Tester", "ECU", "Request Transfer Exit (37)", ""),
            ("ECU", "Tester", "Positive Response (77)", ""),
        ]
        ud_path = output_dir / "upload_download_sequence.tex"
        ud_path.write_text(
            _render_sequence_tikz("Upload/Download Flow", ud_participants, ud_messages),
            encoding="utf-8",
        )
        written.append(ud_path)

        logger.info("Generated %d sequence diagram(s) in %s", len(written), output_dir)
        return written

    # ---- Byte-level visualization (bytefield) ----------------------------

    def generate_byte_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> Path:
        """Generate did_byte_fields.tex using LaTeX bytefield package.

        Only DIDs with at least one data element are included.

        Returns:
            Path to the generated did_byte_fields.tex file.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        lines: list[str] = [
            r"% DID byte-field diagrams — generated by udsxml2tex",
            r"% Requires the 'bytefield' LaTeX package.",
            r"",
        ]
        for did in sorted(spec.dids, key=lambda d: d.did_id):
            if not did.data_elements:
                continue
            lines.append(_render_bytefield_did(did))

        out_path = output_dir / "did_byte_fields.tex"
        out_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Generated byte-field diagrams: %s", out_path)
        return out_path

    # ---- Unified generate_format() entry point --------------------------

    def generate_format(
        self,
        spec: UdsSpecification,
        fmt: str,
        output_path: str | Path,
        *,
        extra_vars: Optional[dict] = None,
    ) -> Path:
        """Generate output in the requested format.

        Args:
            fmt: One of "tex", "html", "md", "rst", "csv", "yaml", "json".
            extra_vars: Passed through to LaTeX / HTML generation.
        """
        fmt = fmt.lower()
        if fmt == "tex":
            return self.generate(spec, output_path, extra_vars=extra_vars)
        if fmt == "html":
            return self.generate_html(spec, output_path)
        if fmt == "md":
            return self.generate_markdown(spec, output_path)
        if fmt == "rst":
            return self.generate_rst(spec, output_path)
        if fmt == "yaml":
            return self.generate_yaml(spec, output_path)
        if fmt == "json":
            return self.generate_json(spec, output_path)
        if fmt == "csv":
            csv_dir = Path(output_path)
            self.generate_csv(spec, csv_dir)
            return csv_dir
        if fmt == "docx":
            return self.generate_docx(spec, Path(output_path).with_suffix(".docx"))
        raise ValueError(f"Unknown output format: {fmt!r}. "
                         "Choose from: tex, html, md, rst, csv, yaml, json, docx")


# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

def _md_escape(text: str) -> str:
    """Minimal Markdown escaping for pipe-table cells."""
    return str(text).replace("|", "\\|").replace("\n", " ")


def _render_markdown(spec: UdsSpecification) -> str:
    lines: list[str] = []
    w = lines.append

    w(f"# {spec.ecu_name} UDS Specification")
    w("")
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    if spec.can_rx_id:
        w(f"**CAN RX ID:** `{spec.can_rx_id}`  **CAN TX ID:** `{spec.can_tx_id}`")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    # Sessions
    if spec.sessions:
        w("## Diagnostic Sessions")
        w("")
        w("| Session ID | Short Name | P2 (s) | P2* (s) |")
        w("|---|---|---|---|")
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            w(f"| `{s.session_id_hex}` | {_md_escape(s.short_name)} | {s.p2_server_max} | {s.p2_star_server_max} |")
        w("")

    # Security levels
    if spec.security_levels:
        w("## Security Levels")
        w("")
        w("| Level | Short Name | Seed (B) | Key (B) | Max Attempts |")
        w("|---|---|---|---|---|")
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            w(f"| `{s.security_level_hex}` | {_md_escape(s.short_name)} | {s.seed_size} | {s.key_size} | {s.num_max_attempts} |")
        w("")

    # Services
    if spec.services:
        w("## Diagnostic Services")
        w("")
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            w(f"### {svc.short_name} (`{svc.service_id_hex}`)")
            w("")
            if svc.description:
                w(svc.description)
                w("")
            if svc.supported_sessions:
                w(f"**Supported sessions:** {', '.join(svc.supported_sessions)}")
            if svc.required_security_levels:
                w(f"**Required security:** {', '.join(svc.required_security_levels)}")
            if svc.sub_functions:
                w("")
                w("| Sub-function ID | Name |")
                w("|---|---|")
                for sf in svc.sub_functions:
                    w(f"| `{sf.sub_function_id_hex}` | {_md_escape(sf.short_name)} |")
            if svc.nrc_list:
                w("")
                w("| NRC | Name |")
                w("|---|---|")
                for nrc in svc.nrc_list:
                    w(f"| `{nrc.nrc_code_hex}` | {_md_escape(nrc.nrc_name)} |")
            w("")

    # DIDs
    if spec.dids:
        w("## Data Identifiers (DIDs)")
        w("")
        w("| DID ID | Short Name | R | W | Length (B) |")
        w("|---|---|---|---|---|")
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            r = "✓" if d.read_access else ""
            wr = "✓" if d.write_access else ""
            w(f"| `{d.did_id_hex}` | {_md_escape(d.short_name)} | {r} | {wr} | {d.total_byte_length} |")
        w("")

    # Routines
    if spec.routines:
        w("## Routine Controls")
        w("")
        w("| Routine ID | Short Name |")
        w("|---|---|")
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            w(f"| `{r.routine_id_hex}` | {_md_escape(r.short_name)} |")
        w("")

    # DTCs
    if spec.dtcs:
        w("## Diagnostic Trouble Codes (DTCs)")
        w("")
        w("| DTC ID | Short Name | Severity |")
        w("|---|---|---|")
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            w(f"| `{d.dtc_id_hex}` | {_md_escape(d.short_name)} | {_md_escape(d.severity)} |")
        w("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# RST renderer
# ---------------------------------------------------------------------------

def _rst_title(text: str, char: str = "=") -> str:
    return f"{text}\n{char * len(text)}\n"


def _rst_table(headers: list[str], rows: list[list[str]]) -> str:
    cols = len(headers)
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row[:cols]):
            widths[i] = max(widths[i], len(str(cell)))
    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    fmt_row = lambda cells: "|" + "|".join(f" {str(c):<{w}} " for c, w in zip(cells, widths)) + "|"
    lines = [sep, fmt_row(headers), sep.replace("-", "=")]
    for row in rows:
        lines.append(fmt_row(row + [""] * (cols - len(row))))
        lines.append(sep)
    return "\n".join(lines) + "\n"


def _render_rst(spec: UdsSpecification) -> str:
    lines: list[str] = []
    w = lines.append

    w(_rst_title(f"{spec.ecu_name} UDS Specification", "="))
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    if spec.sessions:
        w(_rst_title("Diagnostic Sessions", "-"))
        rows = [[s.session_id_hex, s.short_name, str(s.p2_server_max), str(s.p2_star_server_max)]
                for s in sorted(spec.sessions, key=lambda x: x.session_id)]
        w(_rst_table(["Session ID", "Short Name", "P2 (s)", "P2* (s)"], rows))

    if spec.dids:
        w(_rst_title("Data Identifiers (DIDs)", "-"))
        rows = [[d.did_id_hex, d.short_name, "Yes" if d.read_access else "No",
                 "Yes" if d.write_access else "No", str(d.total_byte_length)]
                for d in sorted(spec.dids, key=lambda x: x.did_id)]
        w(_rst_table(["DID ID", "Short Name", "Read", "Write", "Length (B)"], rows))

    if spec.dtcs:
        w(_rst_title("Diagnostic Trouble Codes (DTCs)", "-"))
        rows = [[d.dtc_id_hex, d.short_name, d.severity]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)]
        w(_rst_table(["DTC ID", "Short Name", "Severity"], rows))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CSV renderer
# ---------------------------------------------------------------------------

def _render_csv(spec: UdsSpecification, out_dir: Path) -> list[Path]:
    import csv
    written: list[Path] = []

    def _write(name: str, headers: list[str], rows: list[list]) -> None:
        p = out_dir / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            cw = csv.writer(f)
            cw.writerow(headers)
            cw.writerows(rows)
        written.append(p)

    if spec.sessions:
        _write("sessions.csv",
               ["session_id_hex", "short_name", "p2_server_max", "p2_star_server_max",
                "comm_ctrl_option_mask"],
               [[s.session_id_hex, s.short_name, s.p2_server_max, s.p2_star_server_max,
                 s.comm_ctrl_option_mask]
                for s in sorted(spec.sessions, key=lambda x: x.session_id)])

    if spec.security_levels:
        _write("security_levels.csv",
               ["security_level_hex", "short_name", "key_size", "seed_size",
                "num_max_attempts", "attempt_delay"],
               [[s.security_level_hex, s.short_name, s.key_size, s.seed_size,
                 s.num_max_attempts, s.attempt_delay]
                for s in sorted(spec.security_levels, key=lambda x: x.security_level)])

    if spec.services:
        _write("services.csv",
               ["service_id_hex", "short_name", "supported_sessions",
                "required_security_levels", "nrc_count", "sub_function_count"],
               [[s.service_id_hex, s.short_name,
                 ";".join(s.supported_sessions),
                 ";".join(s.required_security_levels),
                 len(s.nrc_list), len(s.sub_functions)]
                for s in sorted(spec.services, key=lambda x: x.service_id)])

    if spec.dids:
        _write("dids.csv",
               ["did_id_hex", "short_name", "read_access", "write_access",
                "total_byte_length", "supported_sessions", "required_security_levels",
                "data_element_count"],
               [[d.did_id_hex, d.short_name, d.read_access, d.write_access,
                 d.total_byte_length, ";".join(d.supported_sessions),
                 ";".join(d.required_security_levels), len(d.data_elements)]
                for d in sorted(spec.dids, key=lambda x: x.did_id)])
        # Data elements flattened
        de_rows = []
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            for de in d.data_elements:
                de_rows.append([d.did_id_hex, d.short_name, de.short_name,
                                 de.byte_position, de.bit_size, de.data_type,
                                 de.description, de.read_function, de.write_function,
                                 ";".join(de.global_variables)])
        if de_rows:
            _write("did_data_elements.csv",
                   ["did_id_hex", "did_short_name", "element_short_name",
                    "byte_position", "bit_size", "data_type", "description",
                    "read_function", "write_function", "global_variables"],
                   de_rows)

    if spec.routines:
        _write("routines.csv",
               ["routine_id_hex", "short_name", "start_supported", "stop_supported",
                "result_supported", "supported_sessions", "required_security_levels"],
               [[r.routine_id_hex, r.short_name, r.start_supported, r.stop_supported,
                 r.result_supported, ";".join(r.supported_sessions),
                 ";".join(r.required_security_levels)]
                for r in sorted(spec.routines, key=lambda x: x.routine_id)])

    if spec.dtcs:
        _write("dtcs.csv",
               ["dtc_id_hex", "short_name", "severity", "description",
                "functional_unit", "priority", "dtc_kind"],
               [[d.dtc_id_hex, d.short_name, d.severity, d.description,
                 d.functional_unit, d.priority, d.dtc_kind]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)])

    logger.info("Generated %d CSV file(s) in %s", len(written), out_dir)
    return written


# ---------------------------------------------------------------------------
# TikZ session state-machine diagram
# ---------------------------------------------------------------------------

def _render_session_tikz(spec: UdsSpecification) -> str:
    sessions = sorted(spec.sessions, key=lambda s: s.session_id)
    if not sessions:
        return "% No sessions defined.\n"

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{automata,arrows.meta,positioning}",
        r"\begin{document}",
        r"\begin{tikzpicture}[",
        r"  > = {Stealth[length=6pt]},",
        r"  node distance = 2.8cm,",
        r"  state/.style = {draw, rounded rectangle, minimum width=3cm, minimum height=1cm,",
        r"                   font=\small\ttfamily, align=center},",
        r"  every edge/.style = {draw, ->, bend left=20},",
        r"]",
    ]

    # Position nodes in a row
    prev = None
    for i, s in enumerate(sessions):
        sid = s.short_name.replace(" ", "_")
        if i == 0:
            lines.append(f"  \\node[state, initial] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        else:
            prev_id = sessions[i - 1].short_name.replace(" ", "_")
            lines.append(f"  \\node[state, right of={prev_id}] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        prev = sid

    lines.append("")
    # Draw bidirectional transitions between each consecutive pair
    for i in range(len(sessions) - 1):
        a = sessions[i].short_name.replace(" ", "_")
        b = sessions[i + 1].short_name.replace(" ", "_")
        lines.append(f"  \\path ({a}) edge[bend left] node[above]{{0x10}} ({b});")
        lines.append(f"  \\path ({b}) edge[bend left] node[below]{{0x10}} ({a});")
    # Self-loops for TesterPresent-kept sessions
    for s in sessions:
        sid = s.short_name.replace(" ", "_")
        lines.append(f"  \\path ({sid}) edge[loop above] node[above]{{0x3E}} ({sid});")

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
    ]
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# DOCX renderer
# ---------------------------------------------------------------------------

def _render_docx(spec: UdsSpecification, path: Path) -> None:
    """Create and save a DOCX document for *spec* at *path*.

    Requires python-docx (imported lazily so the rest of the module works
    without the optional dependency installed).
    """
    from docx import Document  # type: ignore[import]

    doc = Document()

    # Title
    doc.add_heading(f"{spec.ecu_name} UDS Specification", level=0)

    # Diagnostic Sessions
    if spec.sessions:
        doc.add_heading("Diagnostic Sessions", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Session ID"
        hdr[2].text = "P2max (s)"
        hdr[3].text = "P2*max (s)"
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.session_id_hex
            row[2].text = str(s.p2_server_max)
            row[3].text = str(s.p2_star_server_max)

    # Security Access Levels
    if spec.security_levels:
        doc.add_heading("Security Access Levels", level=1)
        tbl = doc.add_table(rows=1, cols=3)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Level"
        hdr[2].text = "Key Size"
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.security_level_hex
            row[2].text = str(s.key_size)

    # Services
    if spec.services:
        doc.add_heading("Services", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "SID"
        hdr[2].text = "Supported Sessions"
        hdr[3].text = "Required Security"
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            row = tbl.add_row().cells
            row[0].text = svc.short_name
            row[1].text = svc.service_id_hex
            row[2].text = ", ".join(svc.supported_sessions)
            row[3].text = ", ".join(svc.required_security_levels)

    # Data Identifiers (DIDs)
    if spec.dids:
        doc.add_heading("Data Identifiers (DIDs)", level=1)
        tbl = doc.add_table(rows=1, cols=5)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DID"
        hdr[2].text = "Read"
        hdr[3].text = "Write"
        hdr[4].text = "Sessions"
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.did_id_hex
            row[2].text = "Yes" if d.read_access else "No"
            row[3].text = "Yes" if d.write_access else "No"
            row[4].text = ", ".join(d.supported_sessions)

    # Routines
    if spec.routines:
        doc.add_heading("Routines", level=1)
        tbl = doc.add_table(rows=1, cols=3)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "ID"
        hdr[2].text = "Sessions"
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            row = tbl.add_row().cells
            row[0].text = r.short_name
            row[1].text = r.routine_id_hex
            row[2].text = ", ".join(r.supported_sessions)

    # DTCs
    if spec.dtcs:
        doc.add_heading("DTCs", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DTC ID"
        hdr[2].text = "Severity"
        hdr[3].text = "Description"
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.dtc_id_hex
            row[2].text = d.severity
            row[3].text = d.description or ""

    doc.save(str(path))


# ---------------------------------------------------------------------------
# TikZ sequence diagram renderer
# ---------------------------------------------------------------------------

def _render_sequence_tikz(
    title: str,
    participants: list,
    messages: list,
) -> str:
    """Render a simple TikZ sequence diagram.

    Args:
        title:        Diagram title (used as a comment and heading node).
        participants: List of participant name strings, e.g. ["Tester", "ECU"].
        messages:     List of (from, to, label, style) tuples.
                      *style* is "" for a solid arrow or "dashed" for a dashed arrow.

    Returns:
        A standalone LaTeX document string.
    """
    n = len(participants)
    # Horizontal spacing between participant columns (cm)
    col_sep = 6.0
    # Vertical spacing between messages (cm)
    row_sep = 1.2

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{arrows.meta}",
        r"\begin{document}",
        f"% Sequence diagram: {title}",
        r"\begin{tikzpicture}[",
        r"  >=Stealth,",
        r"  participant/.style={draw, rectangle, minimum width=2.8cm, minimum height=0.8cm,",
        r"                      align=center, font=\small\bfseries},",
        r"  msg/.style={draw, ->, font=\footnotesize},",
        r"  msgnrc/.style={draw, ->, dashed, font=\footnotesize},",
        r"]",
    ]

    # Participant header boxes
    for i, p in enumerate(participants):
        x = i * col_sep
        lines.append(
            f"  \\node[participant] (p{i}) at ({x:.1f},0) {{{_latex_escape(p)}}};"
        )

    # Lifelines (vertical dashed lines)
    total_height = (len(messages) + 1) * row_sep
    for i in range(n):
        x = i * col_sep
        lines.append(
            f"  \\draw[dashed, gray] ({x:.1f},-0.4) -- ({x:.1f},-{total_height:.1f});"
        )

    # Message arrows
    part_index = {p: i for i, p in enumerate(participants)}
    for j, msg in enumerate(messages):
        src, dst, label, style = msg
        y = -(j + 1) * row_sep
        src_idx = part_index.get(src, 0)
        dst_idx = part_index.get(dst, 0)
        x1 = src_idx * col_sep
        x2 = dst_idx * col_sep
        tikz_style = "msgnrc" if style == "dashed" else "msg"
        # label above midpoint
        mid_x = (x1 + x2) / 2.0
        label_escaped = _latex_escape(label)
        lines.append(
            f"  \\draw[{tikz_style}] ({x1:.1f},{y:.2f}) -- ({x2:.1f},{y:.2f})"
            f" node[midway, above, align=center, font=\\scriptsize]{{{label_escaped}}};"
        )

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bytefield DID renderer
# ---------------------------------------------------------------------------

def _render_bytefield_did(did: object) -> str:
    """Return a LaTeX bytefield snippet for a single DID.

    Args:
        did: A DID model object with attributes ``did_id_hex``, ``short_name``,
             and ``data_elements`` (list of objects with ``short_name``,
             ``byte_position``, and ``bit_size``).

    Returns:
        LaTeX string containing \\subsection* and bytefield environment.
    """
    # Determine total bit width — round up to nearest multiple of 8
    total_bits = 0
    for de in did.data_elements:
        bits = getattr(de, "bit_size", 0) or 0
        bpos = getattr(de, "byte_position", 0) or 0
        end_bit = bpos * 8 + bits
        if end_bit > total_bits:
            total_bits = end_bit
    if total_bits == 0:
        total_bits = 8
    # Round up to multiple of 8
    if total_bits % 8:
        total_bits = ((total_bits // 8) + 1) * 8

    did_name_esc = _latex_escape(str(getattr(did, "short_name", "")))
    did_hex = getattr(did, "did_id_hex", "????")

    lines: list[str] = [
        f"\\subsection*{{DID {did_hex} --- {did_name_esc}}}",
        f"\\begin{{bytefield}}[bitwidth=0.5em]{{{total_bits}}}",
        f"  \\bitheader{{0-{total_bits - 1}}} \\\\",
    ]

    # Sort data elements by byte position
    elements = sorted(
        did.data_elements,
        key=lambda de: (getattr(de, "byte_position", 0) or 0),
    )
    for de in elements:
        bits = getattr(de, "bit_size", 8) or 8
        n_words = max(1, bits // 8)
        name_esc = _latex_escape(str(getattr(de, "short_name", "")))
        bpos = getattr(de, "byte_position", 0) or 0
        lines.append(
            f"  \\wordbox{{{n_words}}}{{{name_esc} ({n_words} byte(s), offset {bpos})}} \\\\"
        )

    lines.append("\\end{bytefield}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Multi-page HTML helpers for generate_html_zip()
# ---------------------------------------------------------------------------

_HTML_CSS = """
body { font-family: Arial, sans-serif; margin: 0; display: flex; min-height: 100vh; }
nav { width: 220px; min-width: 180px; background: #1a3a5c; color: #fff; padding: 1.5em 1em; flex-shrink: 0; }
nav h2 { color: #a0c4ff; font-size: 1em; margin-bottom: 1em; }
nav ul { list-style: none; padding: 0; margin: 0; }
nav ul li { margin: 0.4em 0; }
nav ul li a { color: #c9def7; text-decoration: none; font-size: 0.95em; }
nav ul li a:hover { color: #fff; text-decoration: underline; }
main { flex: 1; padding: 2em 2.5em; overflow-x: auto; }
h1 { color: #1a3a5c; border-bottom: 2px solid #1a3a5c; padding-bottom: 0.3em; }
h2 { color: #1a3a5c; margin-top: 2em; }
h3 { color: #2c5f8c; }
table { border-collapse: collapse; margin: 1em 0; max-width: 100%; }
th { background: #e8f0f8; color: #1a3a5c; padding: 0.5em 0.8em; border: 1px solid #bbb; text-align: left; }
td { padding: 0.4em 0.8em; border: 1px solid #ccc; vertical-align: top; }
tr:nth-child(even) td { background: #f5f9ff; }
code, .hexval { font-family: monospace; background: #eef; padding: 0.1em 0.3em; border-radius: 3px; }
.badge-yes { color: #1a7a1a; font-weight: bold; }
.badge-no { color: #aaa; }
.meta { color: #666; font-size: 0.9em; margin-bottom: 2em; }
"""


def _html_escape(text: str) -> str:
    """Escape HTML special characters."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _html_hex(value: str) -> str:
    """Render hex value as inline code."""
    v = _strip_0x(str(value))
    return f'<code class="hexval">{v}<sub>16</sub></code>'


def _html_page(title: str, nav: str, body: str, css: str) -> str:
    """Wrap body in a full HTML page with nav sidebar."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_html_escape(title)}</title>
<style>{css}</style>
</head>
<body>
<nav>
<h2>UDS Specification</h2>
{nav}
</nav>
<main>
{body}
</main>
</body>
</html>
"""


def _html_table(headers: list, rows: list, *, caption: str = "") -> str:
    """Render a simple HTML table."""
    lines = ["<table>"]
    if caption:
        lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append("<thead><tr>" + "".join(f"<th>{_html_escape(str(h))}</th>" for h in headers) + "</tr></thead>")
    lines.append("<tbody>")
    for row in rows:
        lines.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>")
    lines.append("</tbody></table>")
    return "\n".join(lines)


def _render_html_index(ctx: dict) -> str:
    lines: list[str] = []
    ecu = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))
    lines.append(f"<h1>UDS Specification &mdash; {ecu}</h1>")
    lines.append(f'<p class="meta">ECU: <strong>{ecu}</strong> | Protocol: <strong>{proto}</strong></p>')
    lines.append("<p>This document is an automatically generated UDS specification "
                 "extracted from AUTOSAR ARXML configuration.</p>")
    lines.append("<h2>Quick Navigation</h2><ul>")
    lines.append('<li><a href="intro.html">Introduction</a></li>')
    lines.append('<li><a href="low_layer.html">Network Protocol Layers</a></li>')
    lines.append('<li><a href="high_layer.html">Application Layers</a></li>')
    lines.append('<li><a href="annex.html">Annex (DID / RID / NRC tables)</a></li>')
    lines.append("</ul>")

    sessions = ctx.get("sessions", [])
    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max)), _html_escape(str(s.p2_star_server_max))]
            for s in sessions
        ]
        lines.append("<h2>Diagnostic Sessions</h2>")
        lines.append(_html_table(["Session ID", "Name", "P2 max", "P2* max"], rows))

    security_levels = ctx.get("security_levels", [])
    if security_levels:
        rows = [
            [_html_hex(s.security_level_hex), _html_escape(s.short_name),
             str(s.seed_size), str(s.key_size), str(s.num_max_attempts)]
            for s in security_levels
        ]
        lines.append("<h2>Security Access Levels</h2>")
        lines.append(_html_table(
            ["Level", "Name", "Seed (B)", "Key (B)", "Max Attempts"], rows))

    return "\n".join(lines)


def _render_html_intro(ctx: dict) -> str:
    lines: list[str] = []
    ecu = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))
    lines.append("<h1>Introduction</h1>")
    lines.append(f"<h2>Short Description</h2>")
    lines.append(f"<p>This document specifies the software requirements for the Unified Diagnostic "
                 f"Services (UDS) implementation for the <strong>{ecu}</strong> ECU, "
                 f"protocol <strong>{proto}</strong>.</p>")
    lines.append("<h2>Supported Services</h2><ul>")
    for svc in ctx.get("services", []):
        lines.append(f"<li>{_html_hex(svc.service_id_hex)} &mdash; {_html_escape(svc.short_name)}</li>")
    lines.append("</ul>")
    lines.append("<h2>Abbreviations</h2>")
    abbrevs = [
        ("DCM", "Diagnostic Communication Manager"),
        ("DID", "Data Identifier"),
        ("DTC", "Diagnostic Trouble Code"),
        ("ECU", "Electronic Control Unit"),
        ("NRC", "Negative Response Code"),
        ("RID", "Routine Identifier"),
        ("SID", "Service Identifier"),
        ("UDS", "Unified Diagnostic Services"),
    ]
    lines.append(_html_table(["Abbreviation", "Definition"],
                             [[a, d] for a, d in abbrevs]))
    return "\n".join(lines)


def _render_html_low_layer(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Network Protocol Layers</h1>")
    lines.append("<h2>Data Link Layer</h2>")
    lines.append("<p>In diagnostic communication over CAN (DoCAN), padding values are utilized "
                 "to fill unused bytes within a CAN frame. The default padding value is "
                 "<code>0x00</code> as per ISO 15765-2.</p>")

    lines.append("<h2>Network Layer</h2>")
    can_rx = ctx.get("can_rx_id")
    can_tx = ctx.get("can_tx_id")
    can_func = ctx.get("can_functional_id")
    if can_rx or can_tx or can_func:
        rows = []
        if can_rx:
            rows.append(["Physical Rx", "Physical request (tester to ECU)", _html_escape(str(can_rx))])
        if can_tx:
            rows.append(["Physical Tx", "Physical response (ECU to tester)", _html_escape(str(can_tx))])
        if can_func:
            rows.append(["Functional", "Functional request (broadcast)", _html_escape(str(can_func))])
        lines.append(_html_table(["Type", "Description", "CAN ID"], rows))
    else:
        lines.append("<p>CAN IDs are OEM-specific. Refer to the vehicle communication matrix.</p>")

    lines.append("<h2>Transport Layer</h2>")
    pci_rows = [
        ["SF (Single Frame)", "A single CAN frame containing the entire message.",
         "1st byte: 0xL (L = data length)"],
        ["FF (First Frame)", "Initial frame for segmented transmission.",
         "1st byte: 0x1L, 2nd byte: length"],
        ["CF (Consecutive Frame)", "Subsequent frames with a sequence number.",
         "1st byte: 0x2S (S = sequence number)"],
        ["FC (Flow Control)", "Receiver instructs sender to continue, wait, or stop.",
         "1st byte: 0x3F, 2nd: BS, 3rd: STmin"],
    ]
    lines.append(_html_table(["Type", "Description", "PCI Structure"], pci_rows,
                              caption="PCI byte layout in CAN transport layer"))

    lines.append("<h2>Session Layer</h2>")
    sessions = ctx.get("sessions", [])
    s3 = ctx.get("s3_server")
    lines.append("<p>The session layer manages diagnostic sessions and timing. "
                 "S3 server timeout: <strong>"
                 + _html_escape(str(s3) if s3 else "OEM defined") + "</strong></p>")
    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max) if s.p2_server_max is not None else ""),
             _html_escape(str(s.p2_star_server_max) if s.p2_star_server_max is not None else "")]
            for s in sessions
        ]
        lines.append(_html_table(
            ["Session ID", "Name", "P2 max", "P2* max"], rows,
            caption="Session timing parameters"))
    return "\n".join(lines)


def _render_html_high_layer(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Application Layers</h1>")
    lines.append("<p>The application layer defines diagnostic services provided by UDS "
                 "(ISO 14229-1). The following services are configured for this ECU.</p>")

    for svc in ctx.get("services", []):
        sid = _html_hex(svc.service_id_hex)
        lines.append(f"<h2>{_html_escape(svc.short_name)} &mdash; SID {sid}</h2>")
        if svc.supported_sessions:
            lines.append("<p><strong>Supported sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.supported_sessions) + "</p>")
        if svc.required_security_levels:
            lines.append("<p><strong>Required security:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.required_security_levels) + "</p>")
        if svc.sub_functions:
            rows = [[_html_hex(sf.sub_function_id_hex), _html_escape(sf.short_name)]
                    for sf in svc.sub_functions]
            lines.append("<h3>Sub-functions</h3>")
            lines.append(_html_table(["Sub-function ID", "Name"], rows))
        if svc.nrc_list:
            rows = [[_html_hex(nrc.nrc_code_hex), _html_escape(nrc.nrc_name)]
                    for nrc in svc.nrc_list]
            lines.append("<h3>Supported NRCs</h3>")
            lines.append(_html_table(["NRC", "Description"], rows))
    return "\n".join(lines)


def _render_html_annex(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Annex</h1>")

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # SID table
    services = ctx.get("services", [])
    if services:
        headers = ["SID", "Description", "Sub-function"] + sess_names
        rows = []
        for svc in services:
            sid_h = _html_hex(svc.service_id_hex)
            if svc.sub_functions:
                for i, sf in enumerate(svc.sub_functions):
                    sid_cell = sid_h if i == 0 else ""
                    desc_cell = _html_escape(svc.short_name) if i == 0 else ""
                    sf_cell = f"{_html_hex(sf.sub_function_id_hex)}: {_html_escape(sf.short_name)}"
                    sess_cells = [
                        '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                        else '<span class="badge-no">x</span>'
                        for s in sessions
                    ]
                    rows.append([sid_cell, desc_cell, sf_cell] + sess_cells)
            else:
                sess_cells = [
                    '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                    else '<span class="badge-no">x</span>'
                    for s in sessions
                ]
                rows.append([sid_h, _html_escape(svc.short_name), "n/a"] + sess_cells)
        lines.append("<h2>Supported SID &amp; Subfunction List</h2>")
        lines.append(_html_table(headers, rows))

    # DID table
    dids = ctx.get("dids", [])
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">Yes</span>' if did.read_access else '<span class="badge-no">No</span>'
            w = '<span class="badge-yes">Yes</span>' if did.write_access else '<span class="badge-no">No</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + sess_cells)
        lines.append("<h2>Supported DID List</h2>")
        lines.append(_html_table(headers, rows))

    # RID table
    routines = ctx.get("routines", [])
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start = '<span class="badge-yes">o</span>' if rt.start_supported else '<span class="badge-no">x</span>'
            stop = '<span class="badge-yes">o</span>' if rt.stop_supported else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + sess_cells)
        lines.append("<h2>Supported RID List</h2>")
        lines.append(_html_table(headers, rows))

    # NRC table
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                # Reconstruct the hex representation
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append(
                        '<span class="badge-yes">o</span>' if found
                        else '<span class="badge-no">x</span>'
                    )
                rows.append(row)
            lines.append("<h2>Supported NRC List</h2>")
            lines.append(_html_table(headers, rows))

    return "\n".join(lines)
