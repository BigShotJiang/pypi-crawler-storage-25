"""
PyMath - Advanced Mathematics Library for Python

A powerful, zero-dependency library for advanced mathematical operations including:
- Symbolic algebra and simplification
- Geometric calculations and plane operations
- Line collision/intersection detection
- Advanced calculus operations
- Polynomial and equation solving
- Matrix operations and linear algebra
- Statistics and data analysis
- Probability distributions
- Optimization algorithms
- Differential equations solver
- Step-by-step work display for all operations
"""

__version__ = "2.0.0"
__author__ = "PyMath Contributors"
__license__ = "MIT"

from pymath.core.arithmetic import (
    factorial, gcd, lcm, is_prime, prime_factors,
    fibonacci, sum_of_divisors, euler_totient,
    binomial_coefficient, combination, permutation,
    is_perfect_square, power_mod, nth_root
)
from pymath.core.algebra import (
    Polynomial, simplify, solve_quadratic, solve_cubic,
    factor_expression, expand_expression
)
from pymath.core.geometry import (
    Point, Line, Circle, Triangle, Vector,
    find_line_intersection, distance, midpoint, slope,
    line_collision_detection, circle_line_intersection, point_to_line_distance
)
from pymath.core.calculus import (
    derivative, integral, limit, series_expansion,
    find_critical_points, second_derivative_test,
    find_root_bisection, find_root_newton, optimize_minimize,
    second_derivative
)
from pymath.core.matrix import Matrix
from pymath.core.advanced_linear_algebra import (
    EigenAnalysis, QRDecomposition, SingularValueDecomposition,
    NormCalculations, MatrixDecompositions
)
# Statistics
from pymath.statistics.descriptive import (
    DescriptiveStatistics, LinearRegression, HypothesisTesting,
    CorrelationAnalysis
)
# Probability
from pymath.probability.distributions import (
    NormalDistribution, BinomialDistribution, PoissonDistribution,
    ExponentialDistribution, UniformDistribution, ChiSquaredDistribution,
    TDistribution
)
# Complex Numbers
from pymath.complex.numbers import Complex, QuadraticFormula, ComplexAnalysis
# Optimization
from pymath.optimization.algorithms import (
    GradientDescent, NewtonsMethod, ConjugateGradient,
    SimulatedAnnealing, ParticleSwarmOptimization, GeneticAlgorithm
)
# Differential Equations
from pymath.differential.ode_solver import (
    ODESolver, PartialDifferentialEquations, StiffODESolver
)
# Utils
from pymath.utils.step_display import (
    StepTracker, SimplificationTracker, CalculationTracker,
    EquationSolver, ArithmeticSteps, ProbabilitySolver
)

__all__ = [
    # Arithmetic
    'factorial', 'gcd', 'lcm', 'is_prime', 'prime_factors',
    'fibonacci', 'sum_of_divisors', 'euler_totient',
    'binomial_coefficient', 'combination', 'permutation',
    'is_perfect_square', 'power_mod', 'nth_root',
    # Algebra
    'Polynomial', 'simplify', 'solve_quadratic', 'solve_cubic',
    'factor_expression', 'expand_expression',
    # Geometry
    'Point', 'Line', 'Circle', 'Triangle', 'Vector',
    'find_line_intersection', 'distance', 'midpoint', 'slope',
    'line_collision_detection', 'circle_line_intersection', 'point_to_line_distance',
    # Calculus
    'derivative', 'integral', 'limit', 'series_expansion',
    'find_critical_points', 'second_derivative_test',
    'find_root_bisection', 'find_root_newton', 'optimize_minimize',
    'second_derivative',
    # Matrix & Linear Algebra
    'Matrix', 'EigenAnalysis', 'QRDecomposition', 'SingularValueDecomposition',
    'NormCalculations', 'MatrixDecompositions',
    # Statistics
    'DescriptiveStatistics', 'LinearRegression', 'HypothesisTesting',
    'CorrelationAnalysis',
    # Probability
    'NormalDistribution', 'BinomialDistribution', 'PoissonDistribution',
    'ExponentialDistribution', 'UniformDistribution', 'ChiSquaredDistribution',
    'TDistribution',
    # Complex Numbers
    'Complex', 'QuadraticFormula', 'ComplexAnalysis',
    # Optimization
    'GradientDescent', 'NewtonsMethod', 'ConjugateGradient',
    'SimulatedAnnealing', 'ParticleSwarmOptimization', 'GeneticAlgorithm',
    # Differential Equations
    'ODESolver', 'PartialDifferentialEquations', 'StiffODESolver',
    # Utils
    'StepTracker', 'SimplificationTracker', 'CalculationTracker',
    'EquationSolver', 'ArithmeticSteps', 'ProbabilitySolver'
]
