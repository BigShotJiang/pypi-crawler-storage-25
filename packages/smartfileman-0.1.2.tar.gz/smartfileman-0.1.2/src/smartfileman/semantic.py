import subprocess
from pathlib import Path
from collections import defaultdict
import ollama
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

from smartfileman.utils import extract_text


def get_available_ollama_models():
    """Get list of locally available Ollama models."""
    try:
        result = ollama.list()
        if hasattr(result, 'models'):
            return [model.model for model in result.models]
        elif isinstance(result, dict) and 'models' in result:
            return [model.get('model', model.get('name', '')) for model in result['models']]
        return []
    except Exception as e:
        raise RuntimeError(f"Failed to list Ollama models. Ensure Ollama is installed and running: {e}")


def get_missing_ollama_models(required_models):
    """Check which required models are missing locally."""
    available = get_available_ollama_models()
    missing = []
    for model in required_models:
        # Check if model name matches (with or without tag)
        if not any(model in avail or avail.startswith(model) for avail in available):
            missing.append(model)
    return missing


def pull_ollama_model(model_name):
    """Pull an Ollama model."""
    try:
        ollama.pull(model_name)
        return True
    except Exception as e:
        raise RuntimeError(f"Failed to pull model {model_name}: {e}")


def generate_embedding(text, model="embeddinggemma"):
    """Generate embedding for text using Ollama."""
    try:
        response = ollama.embeddings(model=model, prompt=text)
        if isinstance(response, dict) and 'embedding' in response:
            return response['embedding']
        elif hasattr(response, 'embedding'):
            return response.embedding
        return None
    except Exception as e:
        print(f"Embedding generation failed: {e}")
        return None


def group_files_by_extension_content(src):
    """
    Group files by extension and generate embeddings for their content.
    Returns title_embeddings and content_embeddings dicts.
    """
    src = Path(src)
    title_embeddings = {}
    content_embeddings = {}
    
    for f in src.iterdir():
        if f.is_file():
            ext = f.suffix.strip(".").lower()
            
            # Skip binary/non-text files
            if ext in ["jpg", "png", "webp", "mp4", "mkv", "mp3", "wav", "tar", "zip", "xz"]:
                continue
            
            # Generate title embedding (filename-based)
            name_without_ext = f.stem
            title_text = f"{name_without_ext} {ext} file"
            title_emb = generate_embedding(title_text)
            
            # Generate content embedding
            content_text = extract_text(f, ext)
            content_emb = None
            if content_text:
                # Truncate if too long for embedding model
                if len(content_text) > 2000:
                    content_text = content_text[:2000]
                content_emb = generate_embedding(content_text)
            
            if title_emb:
                title_embeddings[str(f.name)] = {
                    "embedding": title_emb,
                    "ext": ext,
                    "path": str(f)
                }
            
            if content_emb:
                content_embeddings[str(f.name)] = {
                    "embedding": content_emb,
                    "ext": ext,
                    "path": str(f)
                }
    
    return title_embeddings, content_embeddings


def embed_and_for_cluster_by_ext(title_embeddings, content_embeddings, dir_names):
    """
    Cluster files by semantic similarity using embeddings.
    Returns list of clusters with file information.
    """
    clusters = []
    
    # Combine title and content embeddings for richer representation
    combined_embeddings = {}
    for filename, data in title_embeddings.items():
        title_emb = np.array(data["embedding"])
        content_emb = None
        
        if filename in content_embeddings:
            content_emb = np.array(content_embeddings[filename]["embedding"])
        
        # Combine embeddings (average if both exist)
        if content_emb is not None and title_emb.shape == content_emb.shape:
            combined_emb = (title_emb + content_emb) / 2
        else:
            combined_emb = title_emb
        
        combined_embeddings[filename] = {
            "embedding": combined_emb,
            "ext": data["ext"],
            "path": data["path"]
        }
    
    if len(combined_embeddings) < 2:
        # Not enough files to cluster
        if combined_embeddings:
            return [[list(combined_embeddings.keys())]]
        return []
    
    # Prepare embedding matrix
    filenames = list(combined_embeddings.keys())
    embeddings_matrix = np.array([combined_embeddings[f]["embedding"] for f in filenames])
    
    # Determine optimal number of clusters (simple heuristic)
    n_clusters = min(max(2, len(filenames) // 3), len(filenames))
    
    # Perform K-Means clustering
    try:
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(embeddings_matrix)
        
        # Group files by cluster label
        cluster_groups = defaultdict(list)
        for filename, label in zip(filenames, labels):
            cluster_groups[label].append({
                "filename": filename,
                "ext": combined_embeddings[filename]["ext"],
                "path": combined_embeddings[filename]["path"]
            })
        
        # Convert to list of clusters
        for cluster_id, files in cluster_groups.items():
            clusters.append(files)
        
    except Exception as e:
        print(f"Clustering failed: {e}")
        # Fallback: return all files as single cluster
        clusters = [[{
            "filename": f,
            "ext": combined_embeddings[f]["ext"],
            "path": combined_embeddings[f]["path"]
        } for f in filenames]]
    
    return clusters
