"""Pydantic models for EyeOnWater historical data API responses."""

# ruff: noqa

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator

from .units import EOWUnits


class Register0EncoderItem(BaseModel):
    """Encoder item from register 0."""

    dials: Optional[int] = None


class Hit(BaseModel):
    """Meter hit record from new_search response."""

    # Mandatory fields
    meter_timezone: list[str] = Field(..., alias="meter.timezone")

    # Optional fields
    meter_communication_seconds: Optional[list[int]] = Field(
        None, alias="meter.communication_seconds"
    )
    register_0_encoder: Optional[list[Register0EncoderItem]] = Field(
        None, alias="register_0.encoder"
    )
    location_location_uuid: Optional[list[str]] = Field(
        None, alias="location.location_uuid"
    )
    meter_fluid_type: Optional[list[str]] = Field(None, alias="meter.fluid_type")
    meter_meter_id: Optional[list[str]] = Field(None, alias="meter.meter_id")
    account_full_name: Optional[list[str]] = Field(None, alias="account.full_name")
    meter_meter_uuid: Optional[list[str]] = Field(None, alias="meter.meter_uuid")
    meter_has_endpoint: Optional[list[bool]] = Field(None, alias="meter.has_endpoint")
    meter_serial_number: Optional[list[str]] = Field(None, alias="meter.serial_number")
    account_account_id: Optional[list[str]] = Field(None, alias="account.account_id")
    location_location_name: Optional[list[str]] = Field(
        None, alias="location.location_name"
    )
    service_service_id: Optional[list[str]] = Field(None, alias="service.service_id")
    register_0_serial_number: Optional[list[str]] = Field(
        None, alias="register_0.serial_number"
    )
    utility_utility_uuid: Optional[list[str]] = Field(
        None, alias="utility.utility_uuid"
    )
    account_account_uuid: Optional[list[str]] = Field(
        None, alias="account.account_uuid"
    )


class Params(BaseModel):
    """Request parameters echoed back in historical data response."""

    # Optional fields
    start_date_utc: Optional[float] = None
    date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    end_date_utc: Optional[float] = None
    compare: Optional[bool] = None
    read_type: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date_tz: Optional[str] = None
    aggregate: Optional[str] = None
    aggregate_group: Optional[str] = None
    perspective: Optional[str] = None
    units: Optional[EOWUnits] = None
    start_date_tz: Optional[str] = None
    adjust_to: Optional[bool] = None
    combine_group: Optional[bool] = None


class Series(BaseModel):
    """Individual data point in a time series."""

    # Mandatory fields
    date: datetime
    display_unit: Optional[EOWUnits] = None
    bill_read: Optional[float] = None

    # Optional fields
    end_date: Optional[datetime] = None
    meter_uuid: Optional[int] = None
    value: Optional[float] = None
    start_date: Optional[datetime] = None
    register_number: Optional[int] = None
    estimated: Optional[int] = None
    raw_read: Optional[int] = None
    unit: Optional[EOWUnits] = None

    @field_validator("date", mode="before")
    @classmethod
    def parse_flexible_date(cls, v: Any) -> datetime:
        """Parse date from various formats depending on API aggregation level.

        The API returns different date formats based on aggregation:
        - Hourly/Daily/Weekly: "YYYY-MM-DD HH:MM:SS" (space-separated,
          actual API format)
        - Daily/Weekly (ISO variant): "YYYY-MM-DDThh:mm:ss" (T-separated)
        - Date only: "YYYY-MM-DD"
        - Monthly: "YYYY-MM" (month only)
        - Yearly: "YYYY" (year only)
        """
        if isinstance(v, datetime):
            return v

        if not isinstance(v, str):
            raise ValueError(
                f"Date must be a string or datetime, got {type(v).__name__}"
            )

        date_formats = [
            "%Y-%m-%d %H:%M:%S",  # Actual API format: 2026-02-10 00:00:00
            "%Y-%m-%dT%H:%M:%S",  # ISO datetime:      2026-02-10T00:00:00
            "%Y-%m-%d",  # Date only:          2026-02-10
            "%Y-%m",  # Month only:         2026-02
            "%Y",  # Year only:          2026
        ]

        for fmt in date_formats:
            try:
                return datetime.strptime(v, fmt)
            except ValueError:
                continue

        raise ValueError(
            f"Unable to parse date '{v}'. Expected one of: "
            f"YYYY-MM-DD HH:MM:SS, YYYY-MM-DDThh:mm:ss, YYYY-MM-DD, YYYY-MM, or YYYY"
        )


class Legend(BaseModel):
    """Legend metadata for a time series."""

    # Optional fields
    supply_zone_id: Optional[str] = None
    location_name: Optional[str] = None
    account_id: Optional[str] = None
    demand_zone_id: Optional[str] = None
    meter_id: Optional[str] = None
    full_name: Optional[str] = None
    serial_number: Optional[str] = None


class TimeSerie(BaseModel):
    """One time series stream within a historical data response."""

    # Mandatory fields
    series: list[Series]

    # Optional fields
    legend: Optional[Legend] = None


class HistoricalData(BaseModel):
    """Top-level historical consumption data response."""

    # Mandatory fields
    hit: Hit
    timeseries: dict[str, TimeSerie]

    # Optional fields
    min_chart_aggregation: Optional[str] = None
    params: Optional[Params] = None
    timezone: Optional[str] = None
    min_aggregation_seconds: Optional[int] = None
    annotations: Optional[list[str]] = None
