# openkosmos-ai
