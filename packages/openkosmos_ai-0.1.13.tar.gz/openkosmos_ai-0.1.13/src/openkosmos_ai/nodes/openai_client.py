from typing import Literal

from langchain_openai import ChatOpenAI
from pydantic import SecretStr

from openkosmos_ai.nodes.base_node import BaseStateNode
from openkosmos_ai.nodes.config import OpenAIClientConfig


class OpenAIClientNode(BaseStateNode[OpenAIClientConfig]):
    def __init__(self, config: OpenAIClientConfig, tools=None):
        super().__init__(config)

        self.llm: ChatOpenAI = ChatOpenAI(
            model=config.model,
            base_url=config.base_url,
            api_key=SecretStr(config.api_key),
            temperature=config.temperature,
            top_p=config.top_p,
            presence_penalty=config.presence_penalty,
            stream_usage=config.stream_usage,
            extra_body=config.extra_body
        )
        if tools is not None:
            self.llm = self.llm.bind_tools(tools)

    def model(self) -> ChatOpenAI:
        return self.llm

    def invoke(self, messages, output_schema=None,
               output_method: Literal["function_calling", "json_mode", "json_schema"] = "json_schema", ):
        if output_schema is None:
            return self.llm.invoke(messages)
        else:
            return self.llm.with_structured_output(
                schema=output_schema, method=output_method).invoke(messages)

    def chat(self, messages):
        response = self.llm.invoke(messages)
        return response.content_blocks
