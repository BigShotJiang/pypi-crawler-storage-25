from sqlalchemy.orm import DeclarativeBase

from openkosmos_ai.nodes.base_node import BaseStateNode
from openkosmos_ai.nodes.config import DatabaseClientConfig


class BaseEntity(DeclarativeBase):
    pass


class DatabaseClientNode(BaseStateNode[DatabaseClientConfig]):
    def __init__(self, config: DatabaseClientConfig):
        super().__init__(config)

        from sqlalchemy import create_engine

        self.database_engine = create_engine(config.url, pool_size=10)
        if config.create_table:
            BaseEntity.metadata.create_all(self.database_engine)

    def engine(self):
        return self.database_engine
