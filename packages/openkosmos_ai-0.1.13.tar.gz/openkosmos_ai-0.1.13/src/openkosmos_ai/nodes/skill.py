from openkosmos_ai.nodes.base_node import BaseStateNode
from openkosmos_ai.nodes.config import SkillConfig


class SkillNode(BaseStateNode[SkillConfig]):
    def __init__(self, config: SkillConfig):
        super().__init__(config)
