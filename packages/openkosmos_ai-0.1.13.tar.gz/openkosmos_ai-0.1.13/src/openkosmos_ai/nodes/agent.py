from openkosmos_ai.nodes.base_node import BaseStateNode
from openkosmos_ai.nodes.config import AgentConfig


class AgentNode(BaseStateNode[AgentConfig]):
    def __init__(self, config: AgentConfig):
        super().__init__(config)
