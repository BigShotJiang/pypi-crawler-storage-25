from openkosmos_ai.nodes.base_node import BaseStateNode
from openkosmos_ai.nodes.config import PlaceholderConfig


class PlaceholderNode(BaseStateNode[PlaceholderConfig]):

    def __init__(self, config: str | PlaceholderConfig = None):
        if isinstance(config, str):
            super().__init__(PlaceholderConfig(name=config))
        else:
            super().__init__(config)

    def __call__(self, *args, **kwargs):
        print("[PLACEHOLDER]", self.config().name if self.config() is not None else "")
        return {}
