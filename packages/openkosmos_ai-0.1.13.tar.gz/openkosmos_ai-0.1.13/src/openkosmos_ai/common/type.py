from pydantic import BaseModel, Field


class BoolResult(BaseModel):
    value: bool = Field(description="bool结果")


class IntResult(BaseModel):
    value: int = Field(description="int结果")


class FloatResult(BaseModel):
    value: float = Field(description="float结果")


class StrResult(BaseModel):
    value: str = Field(description="string结果")
