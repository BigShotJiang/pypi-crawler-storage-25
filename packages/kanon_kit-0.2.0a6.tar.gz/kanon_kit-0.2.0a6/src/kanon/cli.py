"""kanon CLI.

Subcommands:
    init <target>                  Scaffold a new kanon project at <target>.
    upgrade <target>               Refresh <target>'s .kanon/ to installed kit version.
    verify <target>                Validate <target> against its declared aspects.
    tier set <target> <N>          Back-compat sugar for `aspect set-depth <target> sdd <N>`.
    aspect list                    List available aspects in the installed kit.
    aspect info <name>             Show aspect metadata.
    aspect set-depth <target> <aspect> <N>
                                   Change an aspect's depth (mutable, non-destructive).

Per ADR-0012, the kit is aspect-structured: consumer config declares
`aspects: {name: {depth, enabled_at, config}}`. `sdd` is the only stable
aspect shipping at v0.2; its depth-dial replaces v0.1's tier. Legacy
`tier: N` in a consumer config auto-migrates to `aspects: {sdd: {depth: N}}`
on first `kanon upgrade`.

See docs/design/aspect-model.md and ADR-0012 / ADR-0013.
"""

from __future__ import annotations

import hashlib
import json
import operator
import re
import sys
from pathlib import Path
from typing import Any

import click
import yaml

from kanon import __version__
from kanon._manifest import (
    _CAPABILITY_NAME_RE,
    _aspect_config_schema,
    _aspect_depth_range,
    _aspect_provides,
    _capability_suppliers,
    _default_aspects,
    _expected_files,
    _load_aspect_manifest,
    _load_top_manifest,
    _load_yaml,
    _now_iso,
    _parse_frontmatter,
)
from kanon._scaffold import (
    _aspects_with_meta,
    _assemble_agents_md,
    _build_bundle,
    _config_aspects,
    _merge_agents_md,
    _migrate_flat_protocols,
    _migrate_legacy_config,
    _read_config,
    _render_kit_md,
    _render_shims,
    _write_config,
    _write_tree_atomically,
)

# Aspect config-key grammar (INV-aspect-config-key-format).
_CONFIG_KEY_RE = re.compile(r"^[a-z][a-z0-9_-]*$")


def _value_matches_schema_type(value: Any, expected: str) -> bool:
    """Return True iff a parsed YAML scalar satisfies the schema's ``type:``.

    `bool` is a subtype of `int` in Python; reject `bool` for integer / number
    checks so a stray `coverage_floor=true` does not silently pass.
    """
    if isinstance(value, bool):
        return expected == "boolean"
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float))
    return False


def _parse_config_pair(
    raw: str, schema: dict[str, dict[str, Any]] | None
) -> tuple[str, Any]:
    """Parse one ``key=value`` token for ``aspect set-config`` / ``aspect add --config``.

    Value parsed via :func:`yaml.safe_load` (INV-aspect-config-yaml-scalar-parsing);
    lists and mappings rejected. When *schema* is non-None, the key must appear
    in it and the parsed value's type must satisfy the declared schema ``type:``.
    """
    if "=" not in raw:
        raise click.ClickException(
            f"Invalid config token {raw!r}: expected key=value."
        )
    key, _, value_str = raw.partition("=")
    key = key.strip()
    if not _CONFIG_KEY_RE.match(key):
        raise click.ClickException(
            f"Invalid config key {key!r}: must match {_CONFIG_KEY_RE.pattern}."
        )
    try:
        parsed = yaml.safe_load(value_str)
    except yaml.YAMLError as exc:
        raise click.ClickException(
            f"Invalid config value for {key!r}: {exc}"
        ) from None
    if isinstance(parsed, (list, dict)):
        raise click.ClickException(
            f"Invalid config value for {key!r}: lists and mappings are not "
            f"supported on the CLI; hand-edit .kanon/config.yaml for structured values."
        )
    if schema is not None:
        if key not in schema:
            raise click.ClickException(
                f"Unknown config key {key!r}: not declared in this aspect's "
                f"config-schema. Allowed keys: {sorted(schema.keys())}."
            )
        # `type:` presence is enforced by `_validate_config_schema` at manifest
        # load time; cast to str here so mypy --strict is satisfied.
        expected = str(schema[key]["type"])
        if not _value_matches_schema_type(parsed, expected):
            raise click.ClickException(
                f"Invalid type for config key {key!r}: expected {expected}, "
                f"got {type(parsed).__name__} ({parsed!r})."
            )
    return key, parsed


# --- CLI commands ---


def _parse_aspects_flag(raw: str, top: dict[str, Any]) -> dict[str, int]:
    """Parse ``--aspects sdd:1,worktrees:2`` into a validated dict."""
    result: dict[str, int] = {}
    for token in raw.split(","):
        token = token.strip()
        if ":" not in token:
            raise click.ClickException(
                f"Invalid aspect token {token!r}: expected name:depth."
            )
        name, depth_s = token.split(":", 1)
        if name not in top["aspects"]:
            raise click.ClickException(
                f"Unknown aspect {name!r}. See `kanon aspect list`."
            )
        try:
            depth = int(depth_s)
        except ValueError:
            raise click.ClickException(
                f"Invalid depth {depth_s!r} for aspect {name!r}: must be an integer."
            ) from None
        rng = top["aspects"][name]["depth-range"]
        min_d, max_d = int(rng[0]), int(rng[1])
        if not (min_d <= depth <= max_d):
            raise click.ClickException(
                f"Aspect {name!r}: depth {depth} outside range [{min_d},{max_d}]."
            )
        result[name] = depth
    if not result:
        raise click.ClickException("--aspects requires at least one aspect:depth pair.")
    return result


_OPS: dict[str, Any] = {
    ">=": operator.ge,
    ">": operator.gt,
    "==": operator.eq,
    "<": operator.lt,
    "<=": operator.le,
}


def _classify_predicate(predicate: str) -> tuple[Any, ...]:
    """Classify a ``requires:`` predicate as a depth predicate or capability presence.

    Returns one of:
        ``("depth", name: str, op: str, depth: int)`` for a 3-token form like ``"sdd >= 1"``,
        ``("capability", name: str)`` for a 1-token form like ``"planning-discipline"``.

    Raises :class:`click.ClickException` on malformed input — designed to fire
    eagerly at manifest-load time so kit-author mistakes fail fast.
    """
    tokens = predicate.split()
    if len(tokens) == 3:
        name, op, depth_s = tokens
        if op not in _OPS:
            raise click.ClickException(
                f"Invalid requires predicate {predicate!r}: unknown operator {op!r}; "
                f"expected one of {sorted(_OPS)}."
            )
        try:
            depth = int(depth_s)
        except ValueError:
            raise click.ClickException(
                f"Invalid requires predicate {predicate!r}: depth {depth_s!r} is not an integer."
            ) from None
        return ("depth", name, op, depth)
    if len(tokens) == 1:
        token = tokens[0]
        if not _CAPABILITY_NAME_RE.match(token):
            raise click.ClickException(
                f"Invalid requires predicate {predicate!r}: 1-token form must be a "
                f"capability name matching {_CAPABILITY_NAME_RE.pattern}."
            )
        return ("capability", token)
    raise click.ClickException(
        f"Invalid requires predicate {predicate!r}: expected either "
        f"'<aspect> <op> <depth>' (3 tokens) or '<capability>' (1 token), "
        f"got {len(tokens)} tokens."
    )


def _check_requires(
    aspect_name: str, proposed_aspects: dict[str, int], top: dict[str, Any]
) -> str | None:
    """Return error message if requires: predicates are unmet, else None."""
    for predicate in top["aspects"][aspect_name].get("requires", []):
        classified = _classify_predicate(predicate)
        if classified[0] == "depth":
            _, dep_name, op, dep_depth = classified
            actual = proposed_aspects.get(dep_name, 0)
            if not _OPS[op](actual, dep_depth):
                return (
                    f"Aspect {aspect_name!r} requires {predicate!r}, "
                    f"but {dep_name!r} is at depth {actual}."
                )
        else:  # "capability"
            _, capability = classified
            suppliers = _capability_suppliers(top, capability)
            if not any(proposed_aspects.get(s, 0) >= 1 for s in suppliers):
                kit_suppliers = ", ".join(suppliers) if suppliers else "(none)"
                return (
                    f"Aspect {aspect_name!r} requires capability {capability!r}, "
                    f"but no enabled aspect provides it. "
                    f"Suppliers in this kit: {kit_suppliers}."
                )
    return None


def _check_removal_dependents(
    aspect_name: str, remaining_aspects: dict[str, int], top: dict[str, Any]
) -> str | None:
    """Return error if any remaining aspect depends on the one being removed.

    Handles both depth-predicate references (must name the aspect being removed)
    and capability-presence predicates (the removed aspect must be the *only*
    enabled supplier).
    """
    being_removed_provides = set(
        top["aspects"][aspect_name].get("provides", []) or []
    )
    for name, depth in remaining_aspects.items():
        if depth <= 0:
            continue
        for predicate in top["aspects"][name].get("requires", []):
            classified = _classify_predicate(predicate)
            if classified[0] == "depth":
                if classified[1] == aspect_name:
                    return (
                        f"Cannot remove {aspect_name!r}: "
                        f"aspect {name!r} requires {predicate!r}."
                    )
            else:  # capability
                capability = classified[1]
                if capability not in being_removed_provides:
                    continue
                # Removed aspect supplied this capability. Check whether any
                # other still-enabled aspect also supplies it.
                others = [
                    s for s in _capability_suppliers(top, capability)
                    if s != aspect_name
                ]
                if not any(remaining_aspects.get(s, 0) >= 1 for s in others):
                    return (
                        f"Cannot remove {aspect_name!r}: aspect {name!r} requires "
                        f"capability {capability!r}, which would no longer be provided."
                    )
    return None


def _check_pending_recovery(target: Path) -> None:
    """If a previous operation was interrupted, warn the user."""
    from kanon._atomic import read_sentinel

    pending = read_sentinel(target / ".kanon")
    if pending is not None:
        click.echo(
            f"Warning: previous '{pending}' operation was interrupted. "
            f"Re-run 'kanon {pending}' to complete it, or run "
            f"'kanon upgrade' to re-render all files.",
            err=True,
        )


@click.group()
@click.version_option(__version__, prog_name="kanon")
def main() -> None:
    """kanon — portable, self-hosting SDD kit for LLM-agent-driven repos."""


@main.command()
@click.argument("target", type=click.Path(file_okay=False, path_type=Path))
@click.option(
    "--tier",
    "tier_arg",
    type=click.IntRange(0, 3),
    default=None,
    show_default=False,
    help="Shorthand for `sdd` aspect depth. Defaults to sdd's default-depth.",
)
@click.option(
    "--aspects",
    "aspects_arg",
    default=None,
    help="Comma-separated aspect:depth pairs (e.g., sdd:1,worktrees:2).",
)
@click.option("--force", is_flag=True, help="Overwrite an existing .kanon/ directory.")
def init(target: Path, tier_arg: int | None, aspects_arg: str | None, force: bool) -> None:
    """Scaffold a new kanon project at TARGET."""
    if tier_arg is not None and aspects_arg is not None:
        raise click.ClickException("--tier and --aspects are mutually exclusive.")

    target = target.resolve()
    target.mkdir(parents=True, exist_ok=True)

    config_path = target / ".kanon" / "config.yaml"
    if config_path.exists() and not force:
        raise click.ClickException(
            f"kanon project already exists at {target}. "
            f"Run `kanon upgrade` to refresh, or re-run with --force to reinitialise."
        )

    top = _load_top_manifest()

    if aspects_arg is not None:
        aspects_to_enable = _parse_aspects_flag(aspects_arg, top)
    elif tier_arg is not None:
        # --tier is sugar for --aspects sdd:N (backward compat)
        aspects_to_enable = {"sdd": tier_arg}
    else:
        aspects_to_enable = _default_aspects()

    # Use the sdd depth as the tier context value if sdd is enabled, else "0".
    tier_ctx = str(aspects_to_enable.get("sdd", 0))
    context = {"project_name": target.name, "tier": tier_ctx}

    bundle = _build_bundle(aspects_to_enable, context)
    bundle["AGENTS.md"] = _assemble_agents_md(aspects_to_enable, target.name)
    kit_md = _render_kit_md(aspects_to_enable, target.name)
    if kit_md is not None:
        bundle[".kanon/kit.md"] = kit_md
    bundle.update(_render_shims())

    from kanon._atomic import clear_sentinel, write_sentinel

    (target / ".kanon").mkdir(parents=True, exist_ok=True)
    write_sentinel(target / ".kanon", "init")
    _write_tree_atomically(target, bundle, force=force)
    _write_config(target, __version__, _aspects_with_meta(aspects_to_enable))
    clear_sentinel(target / ".kanon")

    click.echo(f"Created kanon project at {target}.")
    click.echo(f"Wrote {len(bundle) + 1} files plus .kanon/config.yaml.")
    click.echo(
        "Aspects: " + ", ".join(f"{a}={d}" for a, d in sorted(aspects_to_enable.items()))
    )
    click.echo("Open this folder with any LLM coding agent to begin.")


@main.command()
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
def upgrade(target: Path) -> None:
    """Refresh TARGET's .kanon/ from the installed kit (preserving docs/, AGENTS.md, config)."""
    target = target.resolve()
    config_path = target / ".kanon" / "config.yaml"
    if not config_path.is_file():
        raise click.ClickException(
            f"Not a kanon project: {target} (missing .kanon/config.yaml)."
        )
    _check_pending_recovery(target)
    raw = _load_yaml(config_path)
    was_legacy = "aspects" not in raw and "tier" in raw
    config = _migrate_legacy_config(raw)
    aspects = _config_aspects(config)
    old_version = config.get("kit_version", "unknown")

    version_changed = old_version != __version__ or was_legacy
    if not version_changed:
        click.echo(
            f"Already at {__version__}. Re-rendering kit-managed sections."
        )

    from kanon._atomic import atomic_write_text, clear_sentinel, write_sentinel

    write_sentinel(target / ".kanon", "upgrade")
    migrated_flat = _migrate_flat_protocols(target, aspects)

    new_agents_md = _assemble_agents_md(aspects, target.name)
    agents_path = target / "AGENTS.md"
    if agents_path.is_file():
        existing = agents_path.read_text(encoding="utf-8")
        merged = _merge_agents_md(existing, new_agents_md)
        if merged != existing:
            atomic_write_text(agents_path, merged)
    else:
        atomic_write_text(agents_path, new_agents_md)

    kit_md = _render_kit_md(aspects, target.name)
    if kit_md is not None:
        atomic_write_text(target / ".kanon" / "kit.md", kit_md)

    if version_changed:
        _write_config(target, __version__, _aspects_with_meta(aspects))
    clear_sentinel(target / ".kanon")

    if was_legacy:
        click.echo("Migrated legacy tier config to aspect model.")
    if migrated_flat:
        click.echo("Namespaced flat .kanon/protocols/*.md under sdd/.")
    if version_changed:
        click.echo(f"Upgraded kanon project at {target}: {old_version} → {__version__}")


@main.command()
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
def verify(target: Path) -> None:
    """Verify TARGET conforms to its declared aspects."""
    from kanon._verify import (
        check_agents_md_markers,
        check_aspects_known,
        check_fidelity_lock,
        check_required_files,
        check_verified_by,
    )

    target = target.resolve()
    errors: list[str] = []
    warnings: list[str] = []
    _check_pending_recovery(target)

    try:
        config = _read_config(target)
    except click.ClickException as exc:
        _emit_verify_report(
            target, {}, errors=[exc.message], warnings=[], status="fail"
        )
        sys.exit(2)

    aspects = _config_aspects(config)
    if not aspects:
        errors.append("config.aspects is empty; nothing to verify.")
        _emit_verify_report(target, aspects, errors=errors, warnings=warnings, status="fail")
        sys.exit(2)

    known_aspects = check_aspects_known(aspects, errors, warnings)
    check_required_files(target, known_aspects, errors)
    check_agents_md_markers(target, aspects, known_aspects, errors)
    check_fidelity_lock(
        target, aspects.get("sdd", 0), warnings,
        spec_sha_fn=_spec_sha, accepted_specs_fn=_accepted_or_draft_specs,
    )
    check_verified_by(target, aspects.get("sdd", 0), warnings)

    status = "fail" if errors else "ok"
    _emit_verify_report(target, aspects, errors=errors, warnings=warnings, status=status)
    if errors:
        sys.exit(1)


def _emit_verify_report(
    target: Path,
    aspects: dict[str, int],
    errors: list[str],
    warnings: list[str],
    status: str,
) -> None:
    report = {
        "target": str(target),
        "aspects": aspects,
        "status": status,
        "errors": errors,
        "warnings": warnings,
    }
    click.echo(json.dumps(report, indent=2))
    if status == "ok":
        click.echo(f"OK — kanon project at {target} is valid.", err=True)
        if warnings:
            click.echo("  warnings:", err=True)
            for w in warnings:
                click.echo(f"    - {w}", err=True)
    else:
        click.echo(f"FAIL — {len(errors)} error(s) at {target}.", err=True)


@main.group()
def tier() -> None:
    """Back-compat: sugar for `aspect set-depth <target> sdd <N>`."""


@tier.command("set")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("n", type=click.IntRange(0, 3))
def tier_set(target: Path, n: int) -> None:
    """Migrate TARGET's sdd aspect depth to N (sugar for aspect set-depth)."""
    click.echo(
        "Warning: 'kanon tier set' is deprecated. "
        "Use 'kanon aspect set-depth <target> sdd <N>'.",
        err=True,
    )
    _set_aspect_depth(target, "sdd", n, legacy_tier_verb=True)


@main.group()
def aspect() -> None:
    """Aspect management (ADR-0012)."""


@aspect.command("list")
def aspect_list() -> None:
    """List aspects available in the installed kit."""
    top = _load_top_manifest()
    for name in sorted(top["aspects"]):
        entry = top["aspects"][name]
        rng = entry["depth-range"]
        click.echo(
            f"{name}\t{entry['stability']}\tdepth {rng[0]}-{rng[1]} "
            f"(default {entry['default-depth']})"
        )


@aspect.command("info")
@click.argument("name")
def aspect_info(name: str) -> None:
    """Print metadata for an aspect."""
    top = _load_top_manifest()
    if name not in top["aspects"]:
        raise click.ClickException(
            f"Unknown aspect: {name!r}. See `kanon aspect list`."
        )
    entry = top["aspects"][name]
    sub = _load_aspect_manifest(name)
    click.echo(f"Aspect: {name}")
    click.echo(f"  Stability:     {entry['stability']}")
    click.echo(f"  Depth range:   {entry['depth-range'][0]}-{entry['depth-range'][1]}")
    click.echo(f"  Default depth: {entry['default-depth']}")
    click.echo(f"  Requires:      {', '.join(entry.get('requires', [])) or '(none)'}")
    click.echo(f"  Provides:      {', '.join(_aspect_provides(name)) or '(none)'}")
    min_d, max_d = _aspect_depth_range(name)
    for d in range(min_d, max_d + 1):
        depth_entry = sub.get(f"depth-{d}", {})
        files = depth_entry.get("files", []) or []
        protos = depth_entry.get("protocols", []) or []
        click.echo(f"  Depth {d}: {len(files)} file(s), {len(protos)} protocol(s)")
    schema = _aspect_config_schema(name)
    if schema:
        click.echo("  Config keys:")
        for key in sorted(schema):
            descriptor = schema[key]
            tline = f"    {key}: {descriptor.get('type', '?')}"
            if "default" in descriptor:
                tline += f" (default: {descriptor['default']!r})"
            click.echo(tline)
            description = descriptor.get("description")
            if description:
                click.echo(f"      {description}")


@aspect.command("add")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("aspect_name")
@click.option("--depth", type=int, default=None, help="Initial depth (default: aspect's default-depth).")
@click.option(
    "--config",
    "config_pairs",
    multiple=True,
    metavar="KEY=VALUE",
    help="Set an aspect-config key at enable time. Repeatable. "
         "VALUE is parsed as a YAML scalar (e.g., 80, true, foo).",
)
def aspect_add(
    target: Path,
    aspect_name: str,
    depth: int | None,
    config_pairs: tuple[str, ...],
) -> None:
    """Enable an aspect at its default depth (or --depth N)."""
    target = target.resolve()
    config = _read_config(target)
    top = _load_top_manifest()
    if aspect_name not in top["aspects"]:
        raise click.ClickException(
            f"Unknown aspect: {aspect_name!r}. See `kanon aspect list`."
        )
    aspects = _config_aspects(config)
    if aspect_name in aspects and aspects[aspect_name] > 0:
        raise click.ClickException(
            f"Aspect {aspect_name!r} is already enabled at depth {aspects[aspect_name]}. "
            f"Use `kanon aspect set-depth` to change depth."
        )
    chosen_depth = depth if depth is not None else int(top["aspects"][aspect_name]["default-depth"])
    min_d, max_d = _aspect_depth_range(aspect_name)
    if not (min_d <= chosen_depth <= max_d):
        raise click.ClickException(
            f"Depth {chosen_depth} is outside range [{min_d},{max_d}] for aspect {aspect_name!r}."
        )
    # Check requires before enabling
    proposed = dict(aspects)
    proposed[aspect_name] = chosen_depth
    err = _check_requires(aspect_name, proposed, top)
    if err:
        raise click.ClickException(err)
    # Parse --config pairs against the aspect's optional schema before any I/O.
    schema = _aspect_config_schema(aspect_name)
    config_values: dict[str, Any] = {}
    for raw in config_pairs:
        key, value = _parse_config_pair(raw, schema)
        config_values[key] = value
    _set_aspect_depth(
        target, aspect_name, chosen_depth, extra_config=config_values or None
    )


@aspect.command("remove")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("aspect_name")
def aspect_remove(target: Path, aspect_name: str) -> None:
    """Remove an aspect (non-destructive: scaffolded files are left on disk)."""
    target = target.resolve()
    config = _read_config(target)
    _check_pending_recovery(target)
    aspects = _config_aspects(config)
    if aspect_name not in aspects:
        raise click.ClickException(
            f"Aspect {aspect_name!r} is not enabled in this project."
        )

    # Check if other enabled aspects depend on this one
    top = _load_top_manifest()
    remaining = {k: v for k, v in aspects.items() if k != aspect_name}
    err = _check_removal_dependents(aspect_name, remaining, top)
    if err:
        raise click.ClickException(err)

    from kanon._atomic import atomic_write_text, clear_sentinel, write_sentinel

    # Remove aspect from config
    aspects_meta = dict(config.get("aspects", {}))
    del aspects_meta[aspect_name]
    kit_version = config.get("kit_version", __version__)

    # Remaining aspects for AGENTS.md reassembly
    remaining = {k: int(v["depth"]) for k, v in aspects_meta.items()}

    # Sentinel wraps the multi-file mutation: AGENTS.md + kit.md + config.yaml.
    # Cleared only on the success path; an exception below leaves the sentinel
    # so the next CLI invocation warns the user (ADR-0024 contract).
    write_sentinel(target / ".kanon", "aspect-remove")

    # Re-assemble and merge AGENTS.md without the removed aspect
    new_agents = _assemble_agents_md(remaining, target.name)
    agents_path = target / "AGENTS.md"
    if agents_path.is_file():
        existing = agents_path.read_text(encoding="utf-8")
        merged = _merge_agents_md(existing, new_agents)
        if merged != existing:
            atomic_write_text(agents_path, merged)

    # Update kit.md
    kit_md = _render_kit_md(remaining, target.name)
    if kit_md is not None:
        atomic_write_text(target / ".kanon" / "kit.md", kit_md)

    _write_config(target, kit_version, aspects_meta)
    clear_sentinel(target / ".kanon")

    # List aspect-specific files left on disk
    from kanon._manifest import _aspect_files, _aspect_protocols

    depth = aspects[aspect_name]
    left: list[str] = list(_aspect_files(aspect_name, depth))
    left.extend(
        f".kanon/protocols/{aspect_name}/{p}"
        for p in _aspect_protocols(aspect_name, depth)
    )
    on_disk = [r for r in left if (target / r).exists()]
    click.echo(f"Removed aspect {aspect_name!r} from config and AGENTS.md.")
    if on_disk:
        click.echo("Scaffolded files left on disk (non-destructive):")
        for rel in on_disk:
            click.echo(f"  - {rel}")


@aspect.command("set-depth")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("aspect_name")
@click.argument("n", type=int)
def aspect_set_depth(target: Path, aspect_name: str, n: int) -> None:
    """Change TARGET's <aspect_name> depth to N (mutable, idempotent, non-destructive)."""
    _set_aspect_depth(target, aspect_name, n)


@aspect.command("set-config")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("aspect_name")
@click.argument("pair", metavar="KEY=VALUE")
def aspect_set_config(target: Path, aspect_name: str, pair: str) -> None:
    """Set one config value on an enabled aspect (KEY=VALUE; YAML-scalar value)."""
    target = target.resolve()
    config = _read_config(target)
    _check_pending_recovery(target)
    top = _load_top_manifest()
    if aspect_name not in top["aspects"]:
        raise click.ClickException(
            f"Unknown aspect: {aspect_name!r}. See `kanon aspect list`."
        )
    aspects = _config_aspects(config)
    if aspect_name not in aspects or aspects[aspect_name] <= 0:
        raise click.ClickException(
            f"Aspect {aspect_name!r} is not enabled in this project. "
            f"Run `kanon aspect add {target} {aspect_name}` first."
        )
    schema = _aspect_config_schema(aspect_name)
    key, value = _parse_config_pair(pair, schema)

    from kanon._atomic import clear_sentinel, write_sentinel

    aspects_meta = dict(config.get("aspects", {}))
    kit_version = config.get("kit_version", __version__)
    write_sentinel(target / ".kanon", "set-config")
    _commit_aspect_meta(
        target, kit_version, aspects_meta, aspect_name, aspects[aspect_name],
        extra_config={key: value},
    )
    clear_sentinel(target / ".kanon")
    click.echo(
        f"Set aspects.{aspect_name}.config.{key} = {value!r} in .kanon/config.yaml."
    )


def _validate_aspect_and_depth(
    aspect_name: str, n: int, top: dict[str, Any]
) -> None:
    """Raise ``click.ClickException`` if *aspect_name* is unknown or *n* is out of range."""
    if aspect_name not in top["aspects"]:
        raise click.ClickException(f"Unknown aspect: {aspect_name!r}.")
    min_d, max_d = _aspect_depth_range(aspect_name)
    if not (min_d <= n <= max_d):
        raise click.ClickException(
            f"aspect {aspect_name}: depth {n} outside range [{min_d},{max_d}]."
        )


def _apply_tier_up(target: Path, target_bundle: dict[str, str]) -> int:
    """Write any new-bundle files that don't yet exist; return the count added."""
    from kanon._atomic import atomic_write_text

    added = 0
    for rel, content in sorted(target_bundle.items()):
        dst = target / rel
        if dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_text(dst, content)
        added += 1
    return added


def _apply_tier_down(
    target: Path, old_aspects: dict[str, int], new_aspects: dict[str, int]
) -> list[str]:
    """Return paths that exist on disk but are no longer required at the new depth.

    Pure compute: no file writes, no deletions. Tier-down is non-destructive
    by design (ADR-0008); the caller surfaces the list to the user.
    """
    required = set(_expected_files(new_aspects))
    return [
        rel
        for rel in _expected_files(old_aspects)
        if rel not in required and (target / rel).exists()
    ]


def _rewrite_assembled_views(
    target: Path, new_aspects: dict[str, int], project_name: str
) -> None:
    """Re-merge AGENTS.md and re-render kit.md. Skips no-op AGENTS.md writes."""
    from kanon._atomic import atomic_write_text

    new_agents = _assemble_agents_md(new_aspects, project_name)
    existing_agents = (target / "AGENTS.md").read_text(encoding="utf-8")
    merged = _merge_agents_md(existing_agents, new_agents)
    if merged != existing_agents:
        atomic_write_text(target / "AGENTS.md", merged)

    kit_md = _render_kit_md(new_aspects, project_name)
    if kit_md is not None:
        atomic_write_text(target / ".kanon" / "kit.md", kit_md)


def _commit_aspect_meta(
    target: Path,
    kit_version: str,
    aspects_meta: dict[str, dict[str, Any]],
    aspect_name: str,
    depth: int,
    extra_config: dict[str, Any] | None = None,
) -> None:
    """Stamp ``aspects_meta[aspect_name]`` and atomically write config.yaml.

    config.yaml is the commit marker for the multi-file `aspect set-depth`
    sequence (ADR-0024); this is the single callsite that mutates it during
    that operation.

    When *extra_config* is supplied, its keys are merged into the entry's
    ``config:`` block (overwriting prior values for shared keys). This lets
    ``aspect add --config k=v`` populate config keys at enable time without a
    second config write.
    """
    entry = dict(aspects_meta.get(aspect_name, {}))
    entry["depth"] = depth
    entry["enabled_at"] = _now_iso()
    config_block = dict(entry.get("config") or {})
    if extra_config:
        config_block.update(extra_config)
    entry["config"] = config_block
    aspects_meta[aspect_name] = entry
    _write_config(target, kit_version, aspects_meta)


def _set_aspect_depth(
    target: Path,
    aspect_name: str,
    n: int,
    legacy_tier_verb: bool = False,
    extra_config: dict[str, Any] | None = None,
) -> None:
    target = target.resolve()
    config = _read_config(target)
    _check_pending_recovery(target)
    top = _load_top_manifest()
    _validate_aspect_and_depth(aspect_name, n, top)

    aspects = _config_aspects(config)
    proposed = {**aspects, aspect_name: n}
    err = _check_requires(aspect_name, proposed, top)
    if err:
        raise click.ClickException(err)

    kit_version = config.get("kit_version", __version__)
    current = aspects.get(aspect_name, -1)
    aspects_meta = dict(config.get("aspects", {}))

    from kanon._atomic import clear_sentinel, write_sentinel

    # Single sentinel wraps every mutation (file writes + AGENTS.md/kit.md
    # rewrites + config.yaml). Cleared only on the success path; if any call
    # below raises, the sentinel persists for the next invocation to detect.
    write_sentinel(target / ".kanon", "set-depth")

    if current == n:
        _commit_aspect_meta(
            target, kit_version, aspects_meta, aspect_name, n,
            extra_config=extra_config,
        )
        clear_sentinel(target / ".kanon")
        verb = "Tier" if legacy_tier_verb else f"Aspect {aspect_name} depth"
        click.echo(f"{verb} already {n}. Noop (timestamp refreshed).")
        return

    new_aspects = {**aspects, aspect_name: n}
    target_bundle = _build_bundle(
        new_aspects, {"project_name": target.name, "tier": str(n)}
    )

    if n > current:
        added = _apply_tier_up(target, target_bundle)
        verb = "Tier-up" if legacy_tier_verb else f"Aspect-up ({aspect_name})"
        click.echo(f"{verb} {current} → {n}: added {added} new file(s).")
    else:
        beyond = _apply_tier_down(target, aspects, new_aspects)
        verb = "Tier-down" if legacy_tier_verb else f"Aspect-down ({aspect_name})"
        click.echo(f"{verb} {current} → {n} is non-destructive.")
        if beyond:
            click.echo("The following artifacts are now beyond required for this depth:")
            for rel in beyond:
                click.echo(f"  - {rel}")
            click.echo("You may keep, archive, or delete them as you choose.")

    _rewrite_assembled_views(target, new_aspects, target.name)
    _commit_aspect_meta(
        target, kit_version, aspects_meta, aspect_name, n,
        extra_config=extra_config,
    )
    clear_sentinel(target / ".kanon")

    verb = "Tier" if legacy_tier_verb else f"Aspect {aspect_name} depth"
    click.echo(f"{verb} set to {n} in .kanon/config.yaml.")


# --- fidelity lock ---


def _spec_sha(path: Path) -> str:
    """Return ``sha256:<hex>`` of raw file bytes."""
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _accepted_or_draft_specs(specs_dir: Path) -> list[Path]:
    """Return sorted spec paths with status accepted or draft."""
    result: list[Path] = []
    if not specs_dir.is_dir():
        return result
    for p in sorted(specs_dir.glob("*.md")):
        if p.name.startswith("_") or p.name == "README.md":
            continue
        fm = _parse_frontmatter(p.read_text(encoding="utf-8"))
        if fm.get("status") in ("accepted", "draft"):
            result.append(p)
    return result


def _fixture_shas(spec_path: Path, target: Path) -> dict[str, str]:
    """Extract unique fixture file paths from invariant_coverage and compute their SHAs."""
    fm = _parse_frontmatter(spec_path.read_text(encoding="utf-8"))
    coverage = fm.get("invariant_coverage")
    if not coverage or not isinstance(coverage, dict):
        return {}
    paths: set[str] = set()
    for targets in coverage.values():
        if not isinstance(targets, list):
            continue
        for t in targets:
            # Strip ::test_func suffix to get the file path
            paths.add(t.split("::")[0])
    result: dict[str, str] = {}
    for fp in sorted(paths):
        full = target / fp
        if full.is_file():
            result[fp] = _spec_sha(full)
    return result


@main.group()
def fidelity() -> None:
    """Fidelity lock management."""


@fidelity.command("update")
@click.argument("target", type=click.Path(exists=True, file_okay=False, path_type=Path))
def fidelity_update(target: Path) -> None:
    """Generate or refresh .kanon/fidelity.lock."""
    from kanon._atomic import atomic_write_text, clear_sentinel, write_sentinel

    target = target.resolve()
    _check_pending_recovery(target)
    specs_dir = target / "docs" / "specs"
    specs = _accepted_or_draft_specs(specs_dir)
    if not specs:
        click.echo("No accepted/draft specs found. Nothing to lock.")
        return

    now = _now_iso()
    entries: dict[str, dict[str, str]] = {}
    fixture_map: dict[str, dict[str, str]] = {}
    for p in specs:
        entries[p.stem] = {"spec_sha": _spec_sha(p), "locked_at": now}
        fshas = _fixture_shas(p, target)
        if fshas:
            fixture_map[p.stem] = fshas

    lock_path = target / ".kanon" / "fidelity.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    lines = ["# Generated by kanon fidelity update — do not edit manually.\n"]
    lines.append("lock_version: 1\n")
    lines.append("entries:\n")
    for slug in sorted(entries):
        e = entries[slug]
        lines.append(f"  {slug}:\n")
        lines.append(f"    spec_sha: \"{e['spec_sha']}\"\n")
        if slug in fixture_map:
            lines.append("    fixture_shas:\n")
            for fp in sorted(fixture_map[slug]):
                lines.append(f"      {fp}: \"{fixture_map[slug][fp]}\"\n")
        lines.append(f"    locked_at: \"{e['locked_at']}\"\n")

    write_sentinel(target / ".kanon", "fidelity-update")
    atomic_write_text(lock_path, "".join(lines))
    clear_sentinel(target / ".kanon")
    click.echo(f"Wrote {lock_path} with {len(entries)} entries.")


if __name__ == "__main__":
    main()
