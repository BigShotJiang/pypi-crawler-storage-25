from typing import TYPE_CHECKING, TypeAlias

from redis.commands.search.field import NumericField

from rapyer.actions import ActionGroup, mark_actions, marks_redis_updated
from rapyer.scripts import (
    NUM_FLOORDIV_SCRIPT_NAME,
    NUM_MOD_SCRIPT_NAME,
    NUM_MUL_SCRIPT_NAME,
    NUM_POW_FLOAT_SCRIPT_NAME,
    NUM_TRUEDIV_SCRIPT_NAME,
    run_sha,
)
from rapyer.types.base import RedisType


class RedisFloat(float, RedisType):
    original_type = float

    @classmethod
    def redis_schema(cls, field_name: str):
        return NumericField(f"$.{field_name}", as_name=field_name)

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    async def aincrease(self, amount: float = 1.0):
        result = await self.client_json.numincrby(self.key, self.json_path, amount)  # type: ignore[misc]
        return result[0] if isinstance(result, list) and result else result

    def clone(self):
        return float(self)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __iadd__(self, other):
        new_value = self + other
        if self.pipeline:
            self.pipeline_json.numincrby(self.key, self.json_path, other)
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __isub__(self, other):
        new_value = self - other
        if self.pipeline:
            self.pipeline_json.numincrby(self.key, self.json_path, -other)
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __imul__(self, other):
        new_value = self * other
        if self.pipeline:
            run_sha(
                self.pipeline, NUM_MUL_SCRIPT_NAME, 1, self.key, self.json_path, other
            )
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __itruediv__(self, other):
        new_value = self / other
        if self.pipeline:
            run_sha(
                self.pipeline,
                NUM_TRUEDIV_SCRIPT_NAME,
                1,
                self.key,
                self.json_path,
                other,
            )
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __ifloordiv__(self, other):
        new_value = self // other
        if self.pipeline:
            run_sha(
                self.pipeline,
                NUM_FLOORDIV_SCRIPT_NAME,
                1,
                self.key,
                self.json_path,
                other,
            )
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __imod__(self, other):
        new_value = self % other
        if self.pipeline:
            run_sha(
                self.pipeline, NUM_MOD_SCRIPT_NAME, 1, self.key, self.json_path, other
            )
        return self.__class__(new_value)

    @marks_redis_updated
    @mark_actions(ActionGroup.UPDATE, ActionGroup.ARITHMETIC)
    def __ipow__(self, other):
        new_value = self**other
        if self.pipeline:
            run_sha(
                self.pipeline,
                NUM_POW_FLOAT_SCRIPT_NAME,
                1,
                self.key,
                self.json_path,
                other,
            )
        return self.__class__(new_value)


if TYPE_CHECKING:
    RedisFloat: TypeAlias = RedisFloat | float  # pragma: no cover
