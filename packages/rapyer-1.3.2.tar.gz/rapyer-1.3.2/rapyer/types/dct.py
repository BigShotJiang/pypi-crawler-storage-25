from typing import TYPE_CHECKING, Any, Generic, TypeAlias, TypeVar, get_args

from pydantic_core import core_schema

from rapyer.actions import ActionGroup, mark_actions
from rapyer.scripts import DICT_POP_SCRIPT_NAME, DICT_POPITEM_SCRIPT_NAME, arun_sha
from rapyer.types.base import REDIS_DUMP_FLAG_NAME, RedisType
from rapyer.types.generic import SKIP_SENTINEL, GenericRedisType
from rapyer.utils.redis import update_keys_in_pipeline

T = TypeVar("T")


class RedisDict(dict[str, T], GenericRedisType, Generic[T]):
    original_type = dict

    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        GenericRedisType.__init__(self, *args, **kwargs)

    @classmethod
    def find_inner_type(cls, type_):
        args = get_args(type_)
        if len(args) >= 2:
            return args[1]
        elif args:
            return args[0]
        return Any

    @classmethod
    def build_typed_original(cls, source_args):
        if len(source_args) == 1:
            return dict[str, source_args[0]]
        return dict[tuple(source_args)]

    def validate_dict(self, dct: dict):
        new_dct = self._adapter.validate_python(dct)
        if new_dct:
            for key, value in new_dct.items():
                self.init_redis_field(f".{key}", value)
        return new_dct

    @mark_actions(ActionGroup.UPDATE)
    def update(self, m=None, /, **kwargs):
        if self.pipeline:
            m_redis_val = (
                self._adapter.dump_python(
                    m, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
                )
                if m
                else {}
            )
            kwargs_redis_val = self._adapter.dump_python(
                kwargs, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            updated_values = m_redis_val | kwargs_redis_val
            updated_values = {
                self.json_field_path(key): v for key, v in updated_values.items()
            }
            update_keys_in_pipeline(self.pipeline_json, self.key, **updated_values)
        m_new_val = self.validate_dict(m) if m else {}
        kwargs_new_val = self.validate_dict(kwargs)
        return super().update(m_new_val, **kwargs_new_val)

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ERASE)
    def clear(self):
        if self.pipeline:
            self.pipeline_json.set(self.key, self.json_path, {})
        return super().clear()

    @mark_actions(ActionGroup.UPDATE)
    def __setitem__(self, key, value):
        if self.pipeline:
            serialized = self._adapter.dump_python(
                {key: value}, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            self.pipeline_json.set(self.key, self.json_field_path(key), serialized[key])
        new_val = self.validate_dict({key: value})[key]
        super().__setitem__(key, new_val)

    @mark_actions(ActionGroup.UPDATE)
    async def aset_item(self, key, value):
        self.__setitem__(key, value)

        # Serialize the value for Redis storage using a type adapter
        serialized_value = self._adapter.dump_python(
            {key: value}, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
        )
        result = await self.client_json.set(  # type: ignore[misc]
            self.key, self.json_field_path(key), serialized_value[key]
        )
        return result

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ERASE)
    async def adel_item(self, key):
        # Tolerant local pop so a stale mirror (key already missing locally)
        # cannot raise after the Redis delete has been queued / issued.
        super().pop(key, None)
        result = await self.client_json.delete(self.key, self.json_field_path(key))  # type: ignore[misc]
        return result

    @mark_actions(ActionGroup.UPDATE)
    async def aupdate(self, **kwargs):
        self.update(**kwargs)

        # Serialize values using type adapter
        dumped_data = self._adapter.dump_python(
            kwargs, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
        )
        redis_params = {self.json_field_path(key): v for key, v in dumped_data.items()}

        if not self.pipeline:
            async with self.redis.pipeline() as pipeline:
                update_keys_in_pipeline(pipeline.json(), self.key, **redis_params)
                await pipeline.execute()

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ERASE, ActionGroup.READ)
    async def apop(self, key, default=None):
        result = await arun_sha(
            self.redis,
            self.Meta,
            DICT_POP_SCRIPT_NAME,
            1,
            self.key,
            self.json_path,
            key,
        )
        super().pop(key, None)

        if result is None:
            return default

        return self._adapter.validate_python(
            {key: result}, context={REDIS_DUMP_FLAG_NAME: True}
        )[key]

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ERASE, ActionGroup.READ)
    async def apopitem(self):
        result = await arun_sha(
            self.redis,
            self.Meta,
            DICT_POPITEM_SCRIPT_NAME,
            1,
            self.key,
            self.json_path,
        )

        if result is not None:
            redis_key, redis_value = result
            # Pop the same key from the local dict — tolerant of a stale
            key = redis_key.decode() if isinstance(redis_key, bytes) else redis_key
            super().pop(key, None)
            return self._adapter.validate_python(
                {redis_key: redis_value}, context={REDIS_DUMP_FLAG_NAME: True}
            )[redis_key]
        else:
            # If Redis is empty but local dict has items, raise an error for consistency
            raise KeyError("popitem(): dictionary is empty")

    @mark_actions(ActionGroup.UPDATE, ActionGroup.ERASE)
    async def aclear(self):
        self.clear()
        # Clear Redis dict
        result = await self.client_json.set(self.key, self.json_path, {})  # type: ignore[misc]
        return result

    def clone(self):
        return {
            k: v.clone() if isinstance(v, RedisType) else v for k, v in self.items()
        }

    def iterate_items(self):
        keys = [f".{k}" for k in self.keys()]
        return zip(keys, self.values())

    @classmethod
    def full_serializer(cls, value, info: core_schema.SerializationInfo):
        ctx = info.context or {}
        should_serialize_redis = ctx.get(REDIS_DUMP_FLAG_NAME)
        return {
            key: cls.serialize_unknown(item) if should_serialize_redis else item
            for key, item in value.items()
        }

    @classmethod
    def full_deserializer(cls, value: dict, info: core_schema.ValidationInfo):
        ctx = info.context or {}
        should_serialize_redis = ctx.get(REDIS_DUMP_FLAG_NAME)

        if not should_serialize_redis:
            return value

        return {
            key: deserialized
            for key, item in value.items()
            if (deserialized := cls.try_deserialize_item(item, f"key '{key}'"))
            is not SKIP_SENTINEL
        }

    @classmethod
    def schema_for_unknown(cls):
        core_schema.dict_schema(core_schema.str_schema(), core_schema.str_schema())


if TYPE_CHECKING:
    RedisDict: TypeAlias = RedisDict[T] | dict[str, T]  # pragma: no cover
