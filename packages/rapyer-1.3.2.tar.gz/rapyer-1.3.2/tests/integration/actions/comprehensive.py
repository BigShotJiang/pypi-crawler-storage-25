from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from tests.integration.actions.update import UpdateActionTestBase
from tests.models.collection_types import ComprehensiveTestModel

T = TypeVar("T")


class ComprehensiveOpBase(UpdateActionTestBase, ABC, Generic[T]):
    """Base for tests that read one field of ``ComprehensiveTestModel``.

    Subclasses implement ``field_getter`` with a typed attribute access, e.g.
    ``return m.amount`` — no string field names.
    """

    @staticmethod
    @abstractmethod
    def field_getter(m: ComprehensiveTestModel) -> T: ...

    async def load_data(self) -> T:
        loaded = await ComprehensiveTestModel.aget(self.created_models[0].key)
        return type(self).field_getter(loaded)


class ComprehensiveBinaryOpBase(ComprehensiveOpBase[T], ABC, Generic[T]):
    """Base for ``BinaryOpCase`` tests. ``self.test_input`` is ``BinaryOpCase``."""

    @staticmethod
    @abstractmethod
    def make_model(v: T) -> ComprehensiveTestModel: ...

    def create_models(self):
        return [type(self).make_model(self.test_input.initial)]

    def expected_before(self):
        return self.test_input.initial

    def expected_after(self):
        return self.test_input.expected


class ComprehensiveAmountOpBase(ComprehensiveBinaryOpBase[float]):
    """RedisFloat binary ops on ``ComprehensiveTestModel.amount``."""

    skip_stale_mirror_in_pipeline = (
        "scalar value is its own mirror; no stale-mirror failure mode"
    )
    skip_sync_native_raises_on_corruption = (
        "scalar arithmetic never raises on a stale value"
    )

    @staticmethod
    def field_getter(m: ComprehensiveTestModel) -> float:
        return m.amount

    @staticmethod
    def make_model(v: float) -> ComprehensiveTestModel:
        return ComprehensiveTestModel(amount=v)

    def local_mutate_target_field(self, m: ComprehensiveTestModel):
        m.amount += 1.2345e-5

    def get_target_field(self, m: ComprehensiveTestModel) -> float:
        return float(m.amount)


class ComprehensiveCounterOpBase(ComprehensiveBinaryOpBase[int]):
    """RedisInt binary ops on ``ComprehensiveTestModel.counter``. Sync / pipeline-only."""

    skip_stale_mirror_in_pipeline = (
        "scalar value is its own mirror; no stale-mirror failure mode"
    )
    skip_sync_native_raises_on_corruption = (
        "scalar arithmetic never raises on a stale value"
    )

    @staticmethod
    def field_getter(m: ComprehensiveTestModel) -> int:
        return m.counter

    @staticmethod
    def make_model(v: int) -> ComprehensiveTestModel:
        return ComprehensiveTestModel(counter=v)

    def local_mutate_target_field(self, m: ComprehensiveTestModel):
        m.counter += 7919

    def get_target_field(self, m: ComprehensiveTestModel) -> int:
        return int(m.counter)


class ComprehensiveMetadataOpBase(ComprehensiveOpBase[dict]):
    """Dict ops on ``ComprehensiveTestModel.metadata``. Sync / pipeline-only."""

    @staticmethod
    def field_getter(m: ComprehensiveTestModel) -> dict:
        return m.metadata

    def local_mutate_target_field(self, m: ComprehensiveTestModel):
        m.metadata["__local_marker__"] = "__local_value__"

    def get_target_field(self, m: ComprehensiveTestModel) -> dict:
        return dict(m.metadata)


class ComprehensiveNameOpBase(ComprehensiveOpBase[str]):
    """RedisStr ops on ``ComprehensiveTestModel.name``."""

    skip_stale_mirror_in_pipeline = (
        "scalar value is its own mirror; no stale-mirror failure mode"
    )
    skip_sync_native_raises_on_corruption = (
        "scalar arithmetic never raises on a stale value"
    )

    @staticmethod
    def field_getter(m: ComprehensiveTestModel) -> str:
        return m.name

    def local_mutate_target_field(self, m: ComprehensiveTestModel):
        m.name += "_local_marker"

    def get_target_field(self, m: ComprehensiveTestModel) -> str:
        return str(m.name)


class ComprehensiveTagsOpBase(ComprehensiveOpBase[list]):
    """List ops on ``ComprehensiveTestModel.tags``. Sync / pipeline-only."""

    @staticmethod
    def field_getter(m: ComprehensiveTestModel) -> list:
        return m.tags

    def local_mutate_target_field(self, m: ComprehensiveTestModel):
        m.tags.append("__local_marker__")

    def get_target_field(self, m: ComprehensiveTestModel) -> list:
        return list(m.tags)
