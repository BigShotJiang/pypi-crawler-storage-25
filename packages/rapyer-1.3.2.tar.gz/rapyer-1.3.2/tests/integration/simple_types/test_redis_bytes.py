import pytest

from tests.models.simple_types import BytesModel


@pytest.mark.parametrize(
    "test_values",
    [
        b"hello",
        b"world",
        b"",
        b"\x00\x01\x02\x03",
        b"\xff\xfe\xfd",
        b"unicode bytes: \xc4\x85\xc4\x99",
    ],
)
@pytest.mark.asyncio
async def test_redis_bytes_set_functionality_sanity(test_values):
    # Arrange
    model = BytesModel()
    await model.asave()

    # Act
    model.data = test_values
    await model.data.asave()

    # Assert
    fresh_model = BytesModel()
    fresh_model.pk = model.pk
    loaded_value = await fresh_model.data.aload()
    assert loaded_value == test_values


@pytest.mark.parametrize(
    "test_values", [b"hello", b"world", b"", b"\x00\x01\x02\x03", b"\xff\xfe\xfd"]
)
@pytest.mark.asyncio
async def test_redis_bytes_load_functionality_sanity(test_values):
    # Arrange
    model = BytesModel()
    await model.asave()
    model.data = test_values
    await model.data.asave()

    # Act
    fresh_model = BytesModel()
    fresh_model.pk = model.pk
    loaded_value = await fresh_model.data.aload()

    # Assert
    assert loaded_value == test_values


@pytest.mark.asyncio
async def test_redis_bytes_load_with_none_value_edge_case():
    # Arrange
    model = BytesModel()
    await model.asave()

    # Act
    loaded_value = await model.data.aload()

    # Assert
    assert loaded_value == b""


@pytest.mark.parametrize(
    "redis_values",
    [
        [b"string_value", b"string_value"],
        [b"actual_bytes", b"actual_bytes"],
        [b"42", b"42"],
    ],
)
@pytest.mark.asyncio
async def test_redis_bytes_load_type_conversion_edge_case(redis_values):
    # Arrange
    redis_value, expected = redis_values
    model = BytesModel()
    await model.asave()
    model.data = redis_value
    await model.data.asave()

    # Act
    fresh_model = BytesModel()
    fresh_model.pk = model.pk
    loaded_value = await fresh_model.data.aload()

    # Assert
    assert loaded_value == expected


@pytest.mark.parametrize(
    "operations",
    [
        [lambda x: len(x), 5],
        [lambda x: x[1:3], b"el"],
        [lambda x: x + b" world", b"hello world"],
        [lambda x: b"ell" in x, True],
        [lambda x: x.decode(), "hello"],
        [lambda x: x.upper(), b"HELLO"],
        [lambda x: x.replace(b"l", b"x"), b"hexxo"],
    ],
)
@pytest.mark.asyncio
async def test_redis_bytes_operations_sanity(operations):
    # Arrange
    model = BytesModel(data=b"hello")
    operation, expected = operations

    # Act
    result = operation(model.data)

    # Assert
    assert result == expected
