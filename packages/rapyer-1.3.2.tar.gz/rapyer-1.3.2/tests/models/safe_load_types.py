from typing import Any, Optional, Type

from pydantic import Field

from rapyer.base import AtomicRedisModel
from rapyer.config import RedisConfig
from rapyer.fields.safe_load import SafeLoad


class ModelWithSafeLoadField(AtomicRedisModel):
    safe_type_field: SafeLoad[Optional[Type[str]]] = Field(default=None)
    normal_field: str = Field(default="default")


class ModelWithMultipleSafeLoadFields(AtomicRedisModel):
    safe_field_1: SafeLoad[Optional[type]] = Field(default=None)
    safe_field_2: SafeLoad[Optional[Type[Any]]] = Field(default=None)
    normal_field: str = Field(default="default")


class ModelWithMixedFields(AtomicRedisModel):
    safe_field: SafeLoad[Optional[type]] = Field(default=None)
    unsafe_field: Optional[type] = Field(default=None)
    normal_field: str = Field(default="default")


class ModelWithSafeLoadAllConfig(AtomicRedisModel):
    Meta = RedisConfig(safe_load_all=True)

    type_field_1: Optional[type] = Field(default=None)
    type_field_2: Optional[Type[Any]] = Field(default=None)
    normal_field: str = Field(default="default")


class ModelWithSafeLoadListOfAny(AtomicRedisModel):
    Meta = RedisConfig(safe_load_all=True)
    items: list[Any] = Field(default_factory=list)


class ModelWithSafeLoadDictOfAny(AtomicRedisModel):
    Meta = RedisConfig(safe_load_all=True)
    data: dict[str, Any] = Field(default_factory=dict)


class ModelWithUnsafeListOfAny(AtomicRedisModel):
    items: list[Any] = Field(default_factory=list)


class ModelWithUnsafeDictOfAny(AtomicRedisModel):
    data: dict[str, Any] = Field(default_factory=dict)


class ModelWithMixedListFields(AtomicRedisModel):
    safe_list: SafeLoad[list[Any]] = Field(default_factory=list)
    unsafe_list: list[Any] = Field(default_factory=list)


class ModelWithMixedDictFields(AtomicRedisModel):
    safe_dict: SafeLoad[dict[str, Any]] = Field(default_factory=dict)
    unsafe_dict: dict[str, Any] = Field(default_factory=dict)
