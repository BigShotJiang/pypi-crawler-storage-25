from InquirerPy import inquirer


def multiselect(message: str, choices: list[str]) -> list[str]:
    return inquirer.checkbox(
        message=message,
        choices=choices,
    ).execute()


def select_one(message: str, choices: list[str]) -> str:
    return inquirer.select(
        message=message,
        choices=choices,
        qmark="📋",
        amark="✅"
    ).execute()


def confirm(message: str) -> bool:
    return inquirer.confirm(message=message).execute()


def text_input(message: str, default: str = "") -> str:
    return inquirer.text(message=message, default=default).execute()