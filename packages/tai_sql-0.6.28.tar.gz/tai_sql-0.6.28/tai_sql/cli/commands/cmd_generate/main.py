import sys
import click

from tai_sql import pm
from .funcs import run_generate
from ..prompts import multiselect

@click.command()
@click.option('--schema', '-s', help='Nombre del esquema')
def generate(schema: str=None):
    """Genera recursos: Models, CRUD, Diagrams"""
    
    if schema:
        selected = [schema]
    else:
        available_schemas = pm.discover_schemas()
        if not available_schemas:
            click.echo("❌ No se encontraron esquemas para generar recursos.", err=True)
            click.echo("   Asegúrate de haber creado al menos un esquema con 'tai-sql new-schema <nombre>'.", err=True)
            sys.exit(1)
        selected = multiselect("Selecciona los esquemas para generar recursos", available_schemas)

    for schema_name in selected:
        run_generate(schema_name)  