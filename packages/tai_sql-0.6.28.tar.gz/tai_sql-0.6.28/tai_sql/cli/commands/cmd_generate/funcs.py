import click
import sys
from tai_sql import pm

def run_generate(schema_name: str=None):
    """Run the configured generators."""
    # Ejecutar cada generador
    click.echo("🚀 Ejecutando generadores...")
    click.echo()

    if not schema_name:
        return
    pm.set_current_schema(schema_name)

    for generator in pm.db.generators:
        try:
            generator_name = generator.__class__.__name__
            click.echo(f"   • {click.style(generator_name, bold=True)} → {' | '.join(generator.config.output_dirs)}")
            
            # El generador se encargará de descubrir los modelos internamente
            result = generator.generate()
            

        except Exception as e:
            click.echo(f"❌ Error al ejecutar el generador {generator_name}: {str(e)}", err=True)
            sys.exit(1)
        
        finally:
            click.echo()