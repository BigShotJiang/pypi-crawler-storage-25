from .base import SchemaTemplate
from .default import DefaultSchema
from .chatbot import ChatbotSchema
from .auth import AuthSchema

SCHEMA_REGISTRY: dict[str, type[SchemaTemplate]] = {
    'chatbot': ChatbotSchema,
    'auth': AuthSchema,
}

def get_schema_template(schema_name: str, namespace: str) -> SchemaTemplate:
    """Retorna la plantilla de schema apropiada según el nombre"""
    cls = SCHEMA_REGISTRY.get(schema_name, DefaultSchema)
    return cls(namespace=namespace, schema_name=schema_name)

__all__ = [
    'SchemaTemplate',
    'DefaultSchema',
    'ChatbotSchema',
    'AuthSchema',
    'get_schema_template',
]
