from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from textwrap import dedent


class SchemaTemplate(ABC):
    """Clase base para plantillas de schema"""

    def __init__(self, namespace: str, schema_name: str):
        self.namespace = namespace
        self.schema_name = schema_name

    @property
    def subnamespace(self) -> str:
        return self.namespace.replace('-', '_')

    @abstractmethod
    def get_content(self) -> str:
        """Retorna el contenido del archivo .py del schema"""
        ...

    @abstractmethod
    def create_views(self, views_dir: Path) -> None:
        """Crea los archivos SQL de vistas en el directorio indicado"""
        ...
