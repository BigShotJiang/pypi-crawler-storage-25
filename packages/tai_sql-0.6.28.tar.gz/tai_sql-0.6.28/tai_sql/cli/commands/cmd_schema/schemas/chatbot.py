from __future__ import annotations
from pathlib import Path
from textwrap import dedent

from .base import SchemaTemplate


class ChatbotSchema(SchemaTemplate):
    """Plantilla chatbot: Usuario, Chat, Mensaje, TokenUsage, ToolCall, vistas"""

    def get_content(self) -> str:
        return dedent(f'''
            # -*- coding: utf-8 -*-
            """
            Esquema de base de datos para un chatbot con soporte de mensajes, tokens y herramientas.
            Usa tai_sql para definir tablas, relaciones, vistas y generar automáticamente modelos y CRUDs.
            Ejecuta por consola tai-sql generate para generar los recursos definidos en este esquema.
            """
            from __future__ import annotations
            import os
            from tai_sql import *
            from tai_sql.generators import *


            # Configurar el datasource
            datasource(
                provider=env('MAIN_DATABASE_URL'), # Además de env, también puedes usar (para testing) connection_string y params
                schema='{self.schema_name}', # Esquema del datasource
                syntax='v2', # Sintaxis V2: col[type], onetomany[Model], manytoone[Model]
                operative_fields=True, # Añade created_at, updated_at, created_by, updated_by a todas las tablas
            )

            # Configurar los generadores
            generate(
                PythonClientGenerator(
                    output_dir=[
                        '{self.namespace}/{self.subnamespace}', # Directorio donde se generará el cliente python
                        # Añade más directorios aquí
                    ]
                ),
                ERDiagramGenerator(
                    output_dir=[
                        '{self.namespace}/diagrams', # Directorio donde se generará el diagrama
                        # Añade más directorios aquí
                    ],
                    theme='classic',
                    format='svg'
                )
            )

            # Definición de tablas y relaciones

            class Usuario(Table):
                """Tabla que almacena información de los usuarios del chatbot"""
                __tablename__ = "usuario"

                username: col[str] = column(primary_key=True, description='Nombre de usuario único')
                password: col[str] = column(encrypt=True, description='Contraseña encriptada')
                email: col[str | None] = column(description='Correo electrónico del usuario')
                avatar: col[str | None] = column(description='URL del avatar del usuario')
                session_id: col[str | None] = column(description='ID de la sesión activa del usuario')
                is_active: col[bool] = column(default=True, description='Estado activo del usuario')

                chats: onetomany[Chat] # Relación one-to-many con la tabla Chat

                def feed(self):
                    return [
                        Usuario(
                            username='admin',
                            password=os.getenv('USER_PWD', '123456'),
                            email='admin@triplealpha.in'
                        ),
                    ]


            class Chat(Table):
                """Tabla que almacena las conversaciones del chatbot"""
                __tablename__ = "chat"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='UUID del chat')
                title: col[str] = column(description='Título de la conversación')
                username: col[str] = column(description='ID del usuario propietario del chat')
                is_active: col[bool] = column(default=True, description='Estado activo del chat')
                last_message_timestamp: col[datetime | None] = column(description='Timestamp del último mensaje del chat')

                messages: onetomany[Mensaje] # Relación one-to-many con la tabla Mensaje

                usuario: manytoone[Usuario] = relation(fields=['username'], references=['username'], backref='chats') # Relación many-to-one con Usuario


            class Feedback(Enum):
                """Enum para el feedback de los mensajes"""
                GOOD = 'good'
                BAD = 'bad'


            class MessageRole(Enum):
                """Roles de los mensajes en el chat"""
                USER = 'usuario'
                ASSISTANT = 'asistente'
                SYSTEM = 'sistema'


            class Mensaje(Table):
                """Tabla que almacena los mensajes individuales de cada chat"""
                __tablename__ = "mensaje"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='UUID del mensaje')
                content: col[str] = column(description='Contenido del mensaje')
                role: col[MessageRole] = column(description='Rol del mensaje (user, assistant, system)')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp del mensaje')
                feedback: col[Feedback] = column(default=Feedback.GOOD, description='Feedback del mensaje')
                feedback_comment: col[str | None] = column(description='Comentario adicional del feedback')
                reasoning: col[str | None] = column(description='Texto de razonamiento del agente antes de usar herramientas')
                agent_iterations: col[int] = column(default=0, description='Número de iteraciones del agente')
                total_duration_ms: col[int | None] = column(description='Duración total de la respuesta en ms')

                chat_id: col[bigint] = column(description='ID del chat al que pertenece el mensaje')

                token_usage: onetomany[TokenUsage] # Relación one-to-many con la tabla TokenUsage
                tool_calls: onetomany[ToolCall] # Relación one-to-many con la tabla ToolCall

                chat: manytoone[Chat] = relation(fields=['chat_id'], references=['id'], backref='messages') # Relación many-to-one con Chat

                @on_create(timing='after')
                def update_last_message_timestamp(self, t: TriggerAPI):
                    """Actualiza el timestamp del último mensaje en el chat"""
                    t.update(Chat, self.chat_id, last_message_timestamp=self.timestamp)


            class TokenUsage(Table):
                """Tabla que almacena el consumo de tokens para métricas y facturación"""
                __tablename__ = "token_usage"

                id: col[bigint] = column(primary_key=True, autoincrement=True)
                prompt_tokens: col[int] = column(default=0, description='Tokens consumidos en el prompt')
                completion_tokens: col[int] = column(default=0, description='Tokens consumidos en la respuesta')
                total_tokens: col[int] = column(default=0, description='Total de tokens consumidos')
                model_name: col[str] = column(description='Nombre del modelo utilizado')
                provider: col[str] = column(description='Proveedor del modelo (OpenAI, Anthropic, etc.)')
                cost_usd: col[float | None] = column(description='Costo estimado en USD')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp del consumo')
                message_id: col[bigint] = column(description='ID del mensaje asociado')

                message: manytoone[Mensaje] = relation(fields=['message_id'], references=['id'], backref='token_usage') # Relación one-to-one con Mensaje


            class ToolCall(Table):
                """Tabla que almacena las llamadas a herramientas realizadas por el agente durante la generación de respuestas"""
                __tablename__ = "tool_call"

                id: col[bigint] = column(primary_key=True, autoincrement=True, description='ID de la llamada a herramienta')
                tool_name: col[str] = column(description='Nombre de la herramienta invocada')
                tool_args: col[dict | None] = column(description='Argumentos de entrada en formato JSON')
                tool_result: col[dict | None] = column(description='Resultado de la herramienta en formato JSON')
                duration_ms: col[int | None] = column(description='Duración de la ejecución en milisegundos')
                success: col[bool] = column(default=True, description='Si la llamada fue exitosa')
                timestamp: col[datetime] = column(default=datetime.now, description='Timestamp de la llamada')
                message_id: col[bigint] = column(description='ID del mensaje asociado')

                message: manytoone[Mensaje] = relation(fields=['message_id'], references=['id'], backref='tool_calls') # Relación many-to-one con Mensaje


            # Definición de vistas

            class UserStats(View):
                """Vista que muestra estadísticas de usuarios y sus chats"""
                __tablename__ = "user_stats"
                __query__ = query('user_stats.sql') # Esto es necesario para usar tai-sql push

                username: col[str]
                email: col[str]
                total_chats: col[int]
                active_chats: col[int]
                total_messages: col[int]
                created_at: col[datetime]
                last_activity: col[datetime | None]


            class TokenConsumptionStats(View):
                """Vista que muestra estadísticas de consumo de tokens por usuario y período"""
                __tablename__ = "token_consumption_stats"
                __query__ = query('token_consumption_stats.sql')

                username: col[str]
                date: col[datetime]
                total_prompt_tokens: col[int]
                total_completion_tokens: col[int]
                total_tokens: col[int]
                total_cost_usd: col[float | None]
                chat_count: col[int]
                most_used_model: col[str]
                most_used_provider: col[str]


            class ChatActivity(View):
                """Vista que muestra la actividad reciente de chats"""
                __tablename__ = "chat_activity"
                __query__ = query('chat_activity.sql')

                chat_id: col[str]
                chat_title: col[str]
                username: col[str]
                message_count: col[int]
                last_message_timestamp: col[datetime]
                total_tokens_consumed: col[int]
                is_active: col[bool]
        ''').strip()

    def create_views(self, views_dir: Path) -> None:
        user_stats_sql = dedent('''\
            -- Vista para estadísticas de usuarios
            SELECT 
                u.username,
                u.email,
                COUNT(DISTINCT c.id) as total_chats,
                COUNT(DISTINCT CASE WHEN c.is_active = true THEN c.id END) as active_chats,
                COUNT(DISTINCT m.id) as total_messages,
                u.created_at,
                MAX(m.timestamp) as last_activity
            FROM usuario u
            LEFT JOIN chat c ON u.username = c.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            GROUP BY u.username, u.email, u.created_at
            ORDER BY last_activity DESC NULLS LAST;
        ''').rstrip()

        token_consumption_sql = dedent('''\
            -- Vista para estadísticas de consumo de tokens por usuario y fecha
            SELECT 
                u.username,
                DATE(tu.timestamp) as date,
                SUM(tu.prompt_tokens) as total_prompt_tokens,
                SUM(tu.completion_tokens) as total_completion_tokens,
                SUM(tu.total_tokens) as total_tokens,
                SUM(tu.cost_usd) as total_cost_usd,
                COUNT(DISTINCT m.chat_id) as chat_count,
                MODE() WITHIN GROUP (ORDER BY tu.model_name) as most_used_model,
                MODE() WITHIN GROUP (ORDER BY tu.provider) as most_used_provider
            FROM usuario u
            LEFT JOIN chat c ON u.username = c.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            LEFT JOIN token_usage tu ON m.id = tu.message_id
            WHERE tu.timestamp IS NOT NULL
            GROUP BY u.username, DATE(tu.timestamp)
            ORDER BY date DESC, total_tokens DESC;
        ''').rstrip()

        chat_activity_sql = dedent('''\
            -- Vista para actividad de chats
            SELECT 
                c.id as chat_id,
                c.title as chat_title,
                u.username,
                COUNT(m.id) as message_count,
                MAX(m.timestamp) as last_message_timestamp,
                COALESCE(SUM(tu.total_tokens), 0) as total_tokens_consumed,
                c.is_active
            FROM chat c
            INNER JOIN usuario u ON c.username = u.username
            LEFT JOIN mensaje m ON c.id = m.chat_id
            LEFT JOIN token_usage tu ON m.id = tu.message_id
            GROUP BY c.id, c.title, u.username, c.is_active
            ORDER BY last_message_timestamp DESC NULLS LAST;
        ''').rstrip()

        (views_dir / 'user_stats.sql').write_text(user_stats_sql, encoding='utf-8')
        (views_dir / 'token_consumption_stats.sql').write_text(token_consumption_sql, encoding='utf-8')
        (views_dir / 'chat_activity.sql').write_text(chat_activity_sql, encoding='utf-8')
