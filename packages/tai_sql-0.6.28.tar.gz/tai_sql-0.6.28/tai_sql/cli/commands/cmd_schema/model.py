import sys
from pathlib import Path
import click

from tai_sql import pm
from .schemas import get_schema_template


class NewSchemaCommand:

    def __init__(self, namespace: str, schema_name: str):
        self.namespace = namespace
        self.schema_name = schema_name
        self._template = get_schema_template(schema_name, namespace)

    def exists(self) -> bool:
        """Verifica si el esquema ya existe"""
        schemas_dir = Path(self.namespace) / 'schemas'
        return (schemas_dir / f'{self.schema_name}.py').exists()
    
    def create(self):
        """Crea el esquema con la estructura básica"""
        click.echo(f"🚀 Creando esquema '{self.schema_name}' en '{self.namespace}/schemas'...")

        if self.exists():
            click.echo(f"❌ Error: El esquema '{self.schema_name}' ya existe en '{self.namespace}/schemas'.", err=True)
            sys.exit(1)
        
        # Verificar si estamos en un proyecto existente
        project_root = Path(self.namespace)
        existing_config = None
        
        if project_root.exists():
            existing_config = pm.load_config(project_root)
        
        # Crear directorio para el esquema
        schemas_dir = Path(self.namespace) / 'schemas'
        schemas_dir.mkdir(parents=True, exist_ok=True)
        
        # Crear modulo con el contenido del template
        (schemas_dir / f'{self.schema_name}.py').write_text(self._template.get_content(), encoding='utf-8')

        # Crear directorio para las vistas
        views_dir = Path(self.namespace) / 'views' / self.schema_name
        views_dir.mkdir(parents=True, exist_ok=True)

        self._template.create_views(views_dir)
        
        # Actualizar configuración del proyecto si existe
        if existing_config:
            # Si es el primer schema o queremos cambiar el default
            if not existing_config.default_schema:
                pm.update_config(
                    project_root,
                    default_schema=f'schemas/{self.schema_name}.py'
                )
                click.echo(f"   📄 Schema '{self.schema_name}' establecido como default")
        
        click.echo(f"   ✅ '{self.schema_name}.py' creado en '{self.namespace}/schemas/'")
