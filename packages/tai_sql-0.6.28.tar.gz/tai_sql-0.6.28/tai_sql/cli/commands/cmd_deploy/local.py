import sys
import click

from ..utils import verify_server_connection, createdb, createschema
from ...services import DriftManager, DDLManager, SafetyChecker
from ...services.feed import FeedRunner
from ..cmd_generate import run_generate
from ..prompts import select_one
from tai_sql import pm
from tai_sql.orm.columns import VectorColumn


def _ensure_vector_extension_if_needed() -> None:
    """Check if any table uses vector columns and ensure pgvector extension is installed."""
    from tai_sql.orm.table import Table

    has_vectors = any(
        isinstance(col, VectorColumn)
        for table_cls in pm.db.tables
        for col in table_cls.columns.values()
    )
    if not has_vectors:
        return

    driver = pm.db.provider.driver
    if driver.name != 'postgresql':
        click.echo(click.style(
            f"❌ Vector columns require PostgreSQL with pgvector. Current driver: {driver.name}",
            fg="red", bold=True
        ))
        sys.exit(1)

    engine = pm.db.provider.engine
    try:
        driver.ensure_extension(engine, 'vector')
        click.echo("   ✅ pgvector extension ready")
    except Exception as e:
        click.echo(click.style(
            f"❌ Failed to enable pgvector extension: {e}\n"
            "   Run 'CREATE EXTENSION IF NOT EXISTS vector;' as superuser.",
            fg="red"
        ))
        sys.exit(1)


@click.command()
@click.option('--force', '-f', is_flag=True, help='Forzar la generación de recursos, incluso si ya existen')
@click.option('--dry-run', '-d', is_flag=True, help='Mostrar las sentencias DDL sin ejecutarlas')
@click.option('--verbose', '-v', is_flag=True, help='Mostrar información detallada durante la ejecución')
@click.option('--no-generate', is_flag=True, help='No generar código después del push')
@click.option('--with-feed', is_flag=True, help='Ejecutar feed entre la creación de tablas y la aplicación de FK constraints')
@click.option('--schema', '-s', help='Nombre del esquema')
def push(force: bool, dry_run: bool, verbose: bool, no_generate: bool, with_feed: bool, schema: str=None):
    """Síncroniza el esquema con la base de datos"""

    if not schema:
        available_schemas = pm.discover_schemas()
        if not available_schemas:
            click.echo("❌ No se encontraron esquemas para sincronizar.", err=True)
            click.echo("   Asegúrate de haber creado al menos un esquema con 'tai-sql new-schema <nombre>'.", err=True)
            sys.exit(1)
        schema = select_one("Selecciona el esquema para sincronizar con la base de datos", available_schemas)
    pm.set_current_schema(schema)

    try:
        # Validar la configuración del schema

        click.echo(f"🚀 Push schema: {pm.db.schema_name}")

        click.echo()

        if not verify_server_connection(pm.db.provider):
            sys.exit(1)

        createdb(pm.db.provider)
        createschema(pm.db.provider)

        # Ensure pgvector extension if any table has vector columns
        _ensure_vector_extension_if_needed()

        click.echo()

        drift = DriftManager()
        ddl = DDLManager(pm.db.provider.driver)

        drift.run()

        click.echo()

        drift.show()

        statements = ddl.generate(drift)
        
        # Resolver dependencias de vistas sobre tablas modificadas
        ddl.resolve_view_dependencies(drift)
        
        # Validar seguridad de las operaciones
        checker = SafetyChecker()
        checker.validate(statements)
        
        if checker.issues:
            checker.show_issues()
            
            if checker.has_blocked():
                click.echo(click.style(
                    "\n🚫 Existen operaciones bloqueadas que impiden continuar.",
                    fg="red", bold=True
                ))
                click.echo("   Revisa las sugerencias arriba para resolver los conflictos.")
                return
            
            if checker.has_warnings() and not force:
                if not click.confirm("¿Deseas continuar a pesar de las advertencias?"):
                    click.echo("❌ Operación cancelada")
                    return
        
        # Mostrar DDL
        if statements:
            if verbose or dry_run:
                ddl.show()
            else:
                click.echo("   ℹ️  Modo silencioso: No se mostrarán las sentencias DDL")
        
        if not statements:
            return
        
        if dry_run:
            click.echo("🔍 Modo dry-run: No se ejecutaron cambios")
            return

        # Confirmar ejecución
        if not force:
            confirm = click.confirm("¿Deseas ejecutar estas sentencias en la base de datos?")
            if not confirm:
                click.echo("❌ Operación cancelada")
                return
        
        click.echo()
        # Ejecutar DDL
        changes = ddl.execute(defer_fks=with_feed)

        if with_feed and ddl.has_deferred_fks:
            click.echo()
            click.echo("🌱 Ejecutando feed para poblar tablas antes de aplicar FK constraints...")
            click.echo()

            runner = FeedRunner(
                engine=pm.db.provider.engine,
                schema_name=pm.db.schema_name,
                driver=pm.db.provider.driver,
                tables=pm.db.tables,
            )
            runner.discover()

            if runner.feeds:
                runner.show()
                runner.execute()
            else:
                click.echo("   ⚠️  No hay feeds definidos. Las FK diferidas se aplicarán igualmente.")

            click.echo()
            fk_changes = ddl.execute_deferred_fks()
            changes = (changes or 0) + fk_changes

        if changes and not no_generate:

            click.echo()
            run_generate(schema)
        
    except Exception as e:
        import logging
        logging.exception(e)
        click.echo(f"❌ Error al procesar schema: {e}", err=True)
        sys.exit(1)