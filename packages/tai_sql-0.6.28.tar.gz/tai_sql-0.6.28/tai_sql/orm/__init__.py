from .table import Table
from .columns import column, vector_column, VectorColumn
from .relations import relation
from .view import View
from .enumerations import Enum
from .triggers import on_create, on_update, on_delete, TriggerAPI
from .calculated import calculated_column
from .annotations import col, onetomany, manytoone, onetoone
from .types import get_type_registry, register_type, TypeDescriptor, vector
from .encoders import (
    BaseEncoder, SentenceTransformerEncoder,
    OpenAIEncoder, AzureOpenAIEncoder, GoogleEncoder,
)

trigger_api = TriggerAPI()

__all__ = [
    'Table',
    'column',
    'vector',
    'vector_column',
    'VectorColumn',
    'relation',
    'View',
    'Enum',
    'on_create',
    'on_update',
    'on_delete',
    'trigger_api',
    'calculated_column',
    # V2 annotations
    'col',
    'onetomany',
    'manytoone',
    'onetoone',
    # Type system
    'get_type_registry',
    'register_type',
    'TypeDescriptor',
    # Vectors
    'BaseEncoder',
    'SentenceTransformerEncoder',
    'OpenAIEncoder',
    'AzureOpenAIEncoder',
    'GoogleEncoder',
]