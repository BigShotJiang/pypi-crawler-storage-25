# -*- coding: utf-8 -*-
"""
Column definition module for tai-sql ORM.

Provides the Column dataclass that holds column metadata,
and the column() factory function for declarative schema definitions.
Type resolution is delegated to the TypeRegistry (types.py).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, List, Dict, Optional, TYPE_CHECKING
from enum import Enum
from pydantic import BaseModel, Field
from sqlalchemy import Column as SQLAlchemyColumn

if TYPE_CHECKING:
    from .table import Table
    from .encoders import BaseEncoder


# ─────────────────────────────────────────────────────────────────────────────
# Column constraints
# ─────────────────────────────────────────────────────────────────────────────

class ColumnConstraints(BaseModel):
    """Constraint metadata for a column (PK, unique, default, index, autoincrement)."""

    primary_key: bool = Field(default=False)
    unique: bool | None = Field(default=None)
    default: Any = Field(default=None)
    index: bool = Field(default=False)
    autoincrement: bool = Field(default=False)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize constraints to a dict suitable for SQLAlchemy Column kwargs."""
        if self.default is not None:
            if isinstance(self.default, Enum):
                self.default = self.default.value
            elif hasattr(self.default, '__self__') and self.default.__self__.__name__ == 'datetime':
                if hasattr(self.default, '__name__') and self.default.__name__ == 'today':
                    self.default = 'datetime.today'
                elif hasattr(self.default, '__name__') and self.default.__name__ == 'now':
                    self.default = 'datetime.now'
                else:
                    self.default = str(self.default)
        return self.model_dump()

    @property
    def has_custom(self) -> bool:
        """True if any constraint differs from defaults."""
        return bool(self.model_dump(exclude_defaults=True))


# ─────────────────────────────────────────────────────────────────────────────
# Column
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Column:
    """
    Represents a database column with its type, constraints, and metadata.

    Attributes:
        name:           Column name in the table.
        type:           Canonical type name ('int', 'str', 'bigint', 'dict', …).
        sa_type:        Explicit SQLAlchemy type name ('BigInteger', 'Text', 'JSON', …).
                        None when the canonical type is sufficient.
        model:          The Table/View class this column belongs to.
        nullable:       Whether the column accepts NULL values.
        is_foreign_key: Set to True when a Relation claims this column.
        server_now:     Use DB server's NOW() as default.
        encrypt:        Encrypt column value at rest (Fernet).
        constraints:    PK, unique, default, index, autoincrement.
        options:        Enum values list when type is an Enum.
        description:    Human-readable description (used in diagrams/docs).
        is_operative:   True for system-managed audit columns (created_at, etc.).
    """

    name: str = None
    type: str = None
    sa_type: Optional[str] = None
    model: Optional[Table] = None
    nullable: bool = False
    is_foreign_key: bool = False
    server_now: bool = False
    encrypt: bool = False
    constraints: ColumnConstraints = field(default_factory=ColumnConstraints)
    options: Optional[List[Any]] = None
    description: str = ''
    is_operative: bool = False
    is_calculated: bool = False
    self_reference: Optional[str] = None

    # ── Public API ───────────────────────────────────────────────────────

    def register(self, model: Table) -> None:
        """
        Register this column in its parent model.
        Validates required fields before registration.
        """
        if model is None:
            raise ValueError("Column model cannot be None")
        if not self.name:
            raise ValueError("Column name cannot be empty")
        if not self.type:
            raise ValueError("Column type cannot be empty")

        self.model = model
        model.columns[self.name] = self

        # Set as class attribute if not already present
        if getattr(model, self.name, None) is None:
            setattr(model, self.name, self)

    def info(self) -> Dict[str, Any]:
        """Serialize column metadata for generators and templates."""
        from .types import get_type_registry
        registry = get_type_registry()
        type_desc = registry.get_by_name(self.type)
        python_type = type_desc.python_type.__name__ if type_desc and type_desc.python_type else self.type
        pydantic_type = type_desc.pydantic_type if type_desc else python_type
        filter_fields = type_desc.filter_fields() if type_desc else ['exact']

        return {
            'name': self.name,
            'type': self.type,
            'python_type': python_type,
            'pydantic_type': pydantic_type,
            'filter_fields': filter_fields,
            'sa_type': self.sa_type,
            'options': self.options,
            'nullable': self.nullable,
            'is_foreign_key': self.is_foreign_key,
            'default': self.constraints.to_dict().get('default'),
            'encrypt': self.encrypt,
            'constraints': self.constraints.to_dict(),
            'description': self.description or f"Campo {self.name} de la tabla {self.model.tablename}",
            'is_operative': self.is_operative,
            'is_calculated': self.is_calculated,
            'self_reference': self.self_reference,
        }

    def to_sqlalchemy_column(self) -> SQLAlchemyColumn:
        """Convert to a SQLAlchemy Column object for DDL generation."""
        sa_type_class = self._resolve_sqlalchemy_type()

        server_default = None
        if self.server_now:
            from sqlalchemy.sql.functions import now
            server_default = now()

        return SQLAlchemyColumn(
            self.name,
            sa_type_class,
            nullable=self.nullable,
            **self.constraints.to_dict(),
            server_default=server_default,
        )

    # ── Internal ─────────────────────────────────────────────────────────

    @property
    def _driver_name(self) -> str:
        """Resolve the current database driver name."""
        try:
            from tai_sql import pm
            return pm.db.provider.driver.name if pm.db else 'postgresql'
        except Exception:
            return 'postgresql'

    def _resolve_sqlalchemy_type(self) -> Any:
        """
        Resolve the SQLAlchemy type class via the TypeRegistry.
        Tries sa_type first, then falls back to type name.
        """
        from .types import get_type_registry
        registry = get_type_registry()

        lookup_key = self.sa_type or self.type
        descriptor = registry.get_by_name(lookup_key)

        if descriptor is None and self.sa_type:
            descriptor = registry.get_by_name(self.type)

        if descriptor is None:
            raise ValueError(
                f"Unsupported type '{self.type}' (sa_type='{self.sa_type}') "
                f"for column '{self.name}'. Registered: {registry.names}"
            )

        return descriptor.to_sqlalchemy(self._driver_name)


# ─────────────────────────────────────────────────────────────────────────────
# column() factory
# ─────────────────────────────────────────────────────────────────────────────

def column(
    primary_key: bool = False,
    unique: bool | None = False,
    default: Any = None,
    server_now: bool = False,
    index: bool = False,
    autoincrement: bool = False,
    encrypt: bool = False,
    description: str = '',
    self_reference: Optional[str] = None,
) -> Column:
    """
    Factory to configure column metadata in declarative schemas.

    Examples:
        id: int = column(primary_key=True, autoincrement=True)
        name: str = column(unique=True)
        password: str = column(encrypt=True)
        parent_id: Optional[int] = column(self_reference='id')
    """
    return Column(
        constraints=ColumnConstraints(
            primary_key=primary_key,
            unique=unique or None,
            default=default,
            index=index,
            autoincrement=autoincrement,
        ),
        server_now=server_now,
        encrypt=encrypt,
        description=description,
        self_reference=self_reference,
    )


# ─────────────────────────────────────────────────────────────────────────────
# VectorColumn & vector_column() factory
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class VectorColumn(Column):
    """
    Column subclass for pgvector embedding columns.

    Extends Column with vector-specific metadata: dimensions, source column
    for auto-encoding, and an optional encoder instance.

    Attributes:
        dimensions: Number of dimensions for the vector (e.g. 1536 for OpenAI ada-002).
        source:     Name of a text column on the same table to auto-encode.
        encoder:    Optional BaseEncoder instance for automatic text→vector encoding.
    """

    dimensions: int = 0
    source: Optional[str] = None
    encoder: Optional[BaseEncoder] = None
    metric: str = 'cosine'
    threshold: Optional[float] = None

    def __post_init__(self):
        # Force canonical type
        self.type = 'vector'

    def info(self) -> Dict[str, Any]:
        base = super().info()
        base['python_type'] = 'List[float]'
        base['pydantic_type'] = 'List[float]'
        base['sa_type'] = None  # Handled by Vector(dimensions) in templates
        base['dimensions'] = self.dimensions
        base['source'] = self.source
        base['has_encoder'] = self.encoder is not None
        base['encoder_name'] = type(self.encoder).__name__ if self.encoder else None
        base['encoder_config'] = self.encoder.get_config() if self.encoder else None
        base['metric'] = self.metric
        base['threshold'] = self.threshold
        return base

    def _resolve_sqlalchemy_type(self) -> Any:
        """Return pgvector Vector(dimensions) type."""
        try:
            from pgvector.sqlalchemy import Vector
        except ImportError:
            raise ImportError(
                "pgvector is required for vector columns. "
                "Install it with: pip install 'tai-sql[vectors]'"
            )
        return Vector(self.dimensions)


def vector_column(
    dimensions: Optional[int] = None,
    source: Optional[str] = None,
    encoder: Optional[BaseEncoder] = None,
    metric: str = 'cosine',
    threshold: Optional[float] = None,
    index: bool = False,
    description: str = '',
) -> VectorColumn:
    """
    Factory to declare a vector embedding column.

    Args:
        dimensions: Vector dimensionality. Must match the output size of the encoder
            model used. Common values for SentenceTransformerEncoder models:

            - **384** — all-MiniLM-L6-v2 (default), all-MiniLM-L12-v2,
              paraphrase-MiniLM-L6-v2, paraphrase-MiniLM-L12-v2,
              paraphrase-multilingual-MiniLM-L12-v2,
              multi-qa-MiniLM-L6-cos-v1, msmarco-MiniLM-L-6-v3
            - **512** — distiluse-base-multilingual-cased-v2
            - **768** — all-mpnet-base-v2, paraphrase-mpnet-base-v2,
              paraphrase-multilingual-mpnet-base-v2, all-distilroberta-v1,
              multi-qa-mpnet-base-cos-v1, msmarco-distilbert-base-v4
            - **1536** — OpenAI text-embedding-ada-002 (custom encoder)
            - **3072** — OpenAI text-embedding-3-large (custom encoder)

            When an encoder with a known model is provided, dimensions are
            auto-resolved if not explicitly set.  If both are specified and
            they don't match, a ``ValueError`` is raised at schema definition
            time to prevent runtime DB errors.

        source:     Name of a text column on the same table to auto-encode.
        encoder:    BaseEncoder instance for automatic text→vector encoding.
            See ``SentenceTransformerEncoder.KNOWN_MODELS`` for the full list
            of models with pre-configured dimensions.
        metric:     Distance metric for similarity search: 'l2', 'cosine', or 'inner_product'.
        threshold:  Optional distance threshold — only return results **closer** than this
            value. Note that pgvector distance functions return **distance** (lower = more
            similar), not similarity scores. Typical ranges by metric:

            - ``cosine`` — [0, 2]: 0 = identical, 1 = orthogonal, 2 = opposite.
              E.g. ``threshold=0.5`` keeps results with ≥ ~75% cosine similarity.
            - ``l2`` — [0, ∞): 0 = identical. Depends on vector magnitude.
            - ``inner_product`` — uses negative inner product internally; lower
              value means higher actual similarity.
        index:      Create an index on the vector column.
        description: Human-readable description.

    Examples::

        # Auto-resolved dimensions (384 from default encoder model)
        embedding: vector = vector_column(
            source='content',
            encoder=SentenceTransformerEncoder(),
        )

        # Explicit dimensions matching a specific model
        embedding: vector = vector_column(
            dimensions=768,
            source='content',
            encoder=SentenceTransformerEncoder(model='all-mpnet-base-v2'),
            metric='cosine',
            threshold=0.8,
        )

        # Without encoder (e.g. externally computed vectors)
        embedding: vector = vector_column(dimensions=1536)
    """
    if dimensions is None and encoder is not None:
        dimensions = encoder.dimensions

    if dimensions is None:
        from tai_sql import pm
        if pm.db and pm.db.default_vector_dimensions > 0:
            dimensions = pm.db.default_vector_dimensions
        else:
            raise ValueError(
                "Vector dimensions must be specified either in vector_column(), "
                "via a known encoder model, or via datasource(default_vector_dimensions=...)"
            )

    if encoder is not None:
        if encoder.dimensions != dimensions:
            raise ValueError(
                f"Dimension mismatch: vector_column(dimensions={dimensions}) "
                f"but encoder '{type(encoder).__name__}' produces {encoder.dimensions} dimensions. "
                f"Either omit dimensions to auto-resolve from the encoder, "
                f"or ensure both values match."
            )
        if source is None:
            raise ValueError(
                f"Encoder provided without source column. "
                f"When using an encoder, you must specify source='...' to indicate which text column to encode."
            )

    return VectorColumn(
        dimensions=dimensions,
        source=source,
        encoder=encoder,
        metric=metric,
        threshold=threshold,
        constraints=ColumnConstraints(index=index),
        description=description,
    )