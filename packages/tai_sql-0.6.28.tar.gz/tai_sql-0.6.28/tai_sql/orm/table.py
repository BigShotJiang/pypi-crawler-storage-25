from __future__ import annotations
from typing import Any, Dict, ClassVar, List, Union, get_type_hints, get_origin, get_args
from sqlalchemy import MetaData, Table as SQLAlchemyTable

from tai_sql import pm
from .annotations import _RelationType, is_col_type, is_relation_type, is_v1_column_type

from .base import DatabaseObject
from .relations import Relation, ForeignKey
from .triggers import Trigger
from .calculated import CalculatedColumn

class Table(DatabaseObject):
    """
    Clase para definir tablas de base de datos.
    Extiende DatabaseObject con funcionalidad específica para tablas.
    """
    
    __abstract__ = True
    __tablename__: ClassVar[str]
    
    # Específico de tablas
    relations: ClassVar[Dict[str, Relation]] = {}
    triggers: ClassVar[Dict[str, List[Trigger]]] = {}
    foreign_keys: ClassVar[List[ForeignKey]] = []
    calculated_columns: ClassVar[Dict[str, CalculatedColumn]] = {}

    def __init_subclass__(cls) -> None:
        """Inicialización específica para tablas"""
        super().__init_subclass__()
        
        # Inicializar atributos específicos de tabla
        cls.relations = {}
        cls.foreign_keys = []
        # Note: calculated_columns is NOT reset here — descriptors register
        # via __set_name__ during class body execution (before __init_subclass__).
        # _initialize_collection() in CalculatedColumn handles fresh dict creation.
        
        if not hasattr(cls, '__tablename__'):
            raise ValueError(f"La tabla {cls.__name__} debe definir __tablename__")

        cls.tablename = cls.__tablename__
        cls._name = cls.__name__  # Para compatibilidad con base
        cls.is_view = cls.__is_view__
    
    @classmethod
    def get_models(cls) -> List[Table]:
        """Retorna solo las tablas registradas"""
        cls.reset()
        cls.analyze()
        return cls.get_registered_tables()

    @classmethod
    def get_ignored_attributes(cls) -> set:
        """Atributos específicos de tabla a ignorar"""
        return {'registry', 'columns', 'relations', 'foreign_keys', 'tablename', 'triggers', 'calculated_columns'}
    
    @classmethod
    def reset(cls) -> None:
        """Reinicia el estado de la clase para permitir reanálisis"""
        cls.columns.clear()
        cls.relations.clear()
        cls.foreign_keys.clear()
        cls.calculated_columns.clear()
    
    @classmethod
    def analyze(cls) -> None:
        """Análisis completo para tablas (columnas + relaciones)"""
        
        # First pass: analyze all columns so that every model's columns dict
        # is populated before any relation validation runs.
        for model in cls.registry:
            if issubclass(model, Table):
                model.analyze_columns()
        
        # Second pass: analyze relations (may reference columns on other models).
        for model in cls.registry:
            if issubclass(model, Table):
                model.analyze_relations()
        
        # Procesar relaciones implícitas
        for model in cls.registry:
            if issubclass(model, Table):
                for implicit_relation in model.relations.values():
                    if implicit_relation.implicit:
                        implicit_relation.resolve_inverse()
        
        cls.validate()
    
    @classmethod
    def analyze_relations(cls) -> None:
        """Análisis específico de relaciones para tablas. Dispatches V1/V2."""
        syntax = pm.db.syntax if pm.db else 'v1'
        if syntax == 'v2':
            cls._analyze_relations_v2()
        else:
            cls._analyze_relations_v1()

    @classmethod
    def _analyze_relations_v1(cls) -> None:
        """V1 relation analysis — coerces bare type hints to _RelationType and delegates to V2."""
        type_hints = get_type_hints(cls)
        coerced = cls._coerce_v1_relation_hints(type_hints)
        cls._analyze_relations_v2(coerced)

    @staticmethod
    def _coerce_v1_relation_hints(type_hints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert V1-style relation hints to _RelationType instances.
        
        V1 infers direction from the shape of the hint:
          - List[Model] / list[Model]  → one-to-many
          - Model                      → many-to-one
          - Optional[Model]            → many-to-one (nullable)
          - Optional[List[Model]]      → one-to-many (nullable)
        
        Column-type hints (_ColType) are passed through unchanged.
        """
        coerced = {}
        for name, hint in type_hints.items():
            # Skip column annotations — they're handled by _analyze_columns
            if is_col_type(hint):
                coerced[name] = hint
                continue

            target, direction, nullable = _extract_v1_relation(hint)
            if target is None:
                # Not a relation, pass through
                coerced[name] = hint
                continue

            coerced[name] = _RelationType(
                target=target,
                direction=direction,
                nullable=nullable,
            )

        return coerced

    @classmethod
    def _analyze_relations_v2(cls, type_hints: Dict[str, Any] = None) -> None:
        """
        V2 relation analysis — uses onetomany[T], manytoone[T], onetoone[T].
        
        Direction is explicit in the type annotation, no inference needed.
        
        Args:
            type_hints: Pre-resolved hints dict. If None, resolves from class annotations.
                        V1 path passes coerced hints here; V2 path lets it resolve natively.
        """
        if type_hints is None:
            type_hints = get_type_hints(cls, include_extras=True)

        for name, hint in type_hints.items():
            if name.startswith('__') or name in cls.get_ignored_attributes():
                continue
            
            # Only process _RelationType instances
            if not is_relation_type(hint):
                continue

            rel_type: _RelationType = hint
            value = getattr(cls, name, None)

            # Resolve forward references (string targets)
            target = rel_type.target
            if isinstance(target, str):
                target = cls._resolve_forward_ref(target)
                if target is None:
                    raise ValueError(
                        f"Could not resolve forward reference '{rel_type.target}' "
                        f"for relation '{name}' in '{cls.__name__}'"
                    )

            if isinstance(value, Relation):
                # Explicit relation with relation() call
                relation = value
                relation.name = name
                relation.local = cls
                relation.target = target
                relation.direction = rel_type.direction
                relation.register_explicit()
            
            else:
                # Implicit relation (no relation() call — inverse side)
                relation = Relation(
                    name=name,
                    local=cls,
                    target=target,
                    direction=rel_type.direction,
                    implicit=True
                )
                relation.register_implicit()

    @classmethod
    def _resolve_forward_ref(cls, name: str):
        """Resolve a forward reference string to a registered Table class."""
        for model in cls.registry:
            if model.__name__ == name:
                return model
        return None
    
    @classmethod
    def validate(cls) -> None:
        """Validación específica para tablas"""
        for model in cls.registry:
            if not issubclass(model, Table):
                continue
            # Validar que tenga al menos una primary key
            if not any(col.constraints.primary_key for col in model.columns.values()):
                raise ValueError(f"La tabla {model._name} debe tener al menos una primary key")
            
            # Validar self_reference columns
            self_ref_count = 0
            for col in model.columns.values():
                if col.self_reference is not None:
                    self_ref_count += 1
                    if self_ref_count > 1:
                        raise ValueError(
                            f"Table '{model._name}' has multiple self_reference columns. "
                            f"Only one self_reference per table is supported."
                        )
                    if col.self_reference not in model.columns:
                        raise ValueError(
                            f"Table '{model._name}': column '{col.name}' has "
                            f"self_reference='{col.self_reference}' but that column "
                            f"does not exist in the table."
                        )
                    target_col = model.columns[col.self_reference]
                    col_type = col.sa_type or col.type
                    target_type = target_col.sa_type or target_col.type
                    if col_type != target_type:
                        raise ValueError(
                            f"Table '{model._name}': self_reference type mismatch — "
                            f"'{col.name}' ({col_type}) != '{target_col.name}' ({target_type})"
                        )
    
    @classmethod
    def info(cls, mode: str = 'sync') -> Dict[str, Any]:
        """Información específica de tabla"""
        base_info = super().info()

        operative_str_fields = [
            col.name
            for col in cls.columns.values()
            if col.is_operative and col.type == 'str'
        ]
        triggers = {
            event: [
                t.info(mode, operative_str_fields, cls.tablename)
                for t in cls.triggers.get(event, [])
            ]
            for event in ('create', 'update', 'delete')
        }

        # Collect model names referenced by cross-table trigger operations
        relation_targets = {rel.target for rel in cls.relations.values()}
        cross_table_targets = set()
        for event_triggers in triggers.values():
            for t_info in event_triggers:
                cross_table_targets.update(t_info.get('cross_table_targets', set()))
        # Only keep targets not already covered by relations (and not self)
        extra_trigger_targets = cross_table_targets - relation_targets - {cls._name}

        # Detect self-referencing column (hierarchy)
        self_ref_col = None
        for col in cls.columns.values():
            if col.self_reference is not None:
                self_ref_col = col
                break

        # Get PK column info for hierarchy metadata
        self_reference_info = None
        if self_ref_col is not None:
            pk_col = cls.columns.get(self_ref_col.self_reference)
            self_reference_info = {
                'column_name': self_ref_col.name,
                'references': self_ref_col.self_reference,
                'pk_python_type': pk_col.info()['python_type'] if pk_col else 'str',
            }

        base_info.update({
            'tablename': cls.tablename,
            'relations': [rel.info() for rel in cls.relations.values()],
            'foreign_keys': [fk.info() for fk in cls.foreign_keys],
            'has_foreign_keys': len(cls.foreign_keys) > 0,
            'is_view': cls.is_view,
            'has_relations': len(cls.relations) > 0,
            'operative_fields': cls.operative_fields,
            'examples': list(cls._examples),
            'triggers': triggers,
            'cross_table_targets': cross_table_targets,
            'extra_trigger_targets': extra_trigger_targets,
            'calculated_columns': [cc.info() for cc in cls.calculated_columns.values()],
            'has_calculated_columns': len(cls.calculated_columns) > 0,
            'has_self_reference': self_ref_col is not None,
            'self_reference': self_reference_info,
        })
        return base_info
    
    @classmethod
    def to_sqlalchemy_object(cls, metadata: MetaData):
        """Conversión a tabla SQLAlchemy"""
        return cls.to_sqlalchemy_table(metadata)
    
    @classmethod
    def to_sqlalchemy_table(cls, metadata: MetaData):
        """
        Convierte la definición de tai_sql a una tabla SQLAlchemy
        
        Args:
            metadata: MetaData de SQLAlchemy donde registrar la tabla
            
        Returns:
            Table: Tabla SQLAlchemy equivalente
        """
        
        # Convertir columnas
        cols = []
        for col in cls.columns.values():
            alchemy_col = col.to_sqlalchemy_column()
            cols.append(alchemy_col)
        
        # Convertir relaciones que sean foreign keys
        fks = []
        for fk in cls.foreign_keys:
            alchemy_fk = fk.to_sqlalchemy_foreign_key()
            fks.append(alchemy_fk)
        
        # Crear tabla SQLAlchemy
        table = SQLAlchemyTable(
            cls.tablename,
            metadata,
            *cols,
            *fks
        )
        
        return table


# =============================================================================
# V1 hint coercion helpers
# =============================================================================

def _extract_v1_relation(hint):
    """
    Extract relation info from a V1-style type hint.

    Returns:
        (target, direction, nullable) or (None, None, None) if not a relation.
    """
    if is_v1_column_type(hint):
        return None, None, None

    origin = get_origin(hint)
    nullable = False

    # Unwrap Optional[T]
    if origin is Union:
        args = get_args(hint)
        if len(args) == 2 and type(None) in args:
            inner = args[0] if args[1] is type(None) else args[1]
            nullable = True
            return _extract_v1_relation_inner(inner, nullable)
        return None, None, None

    return _extract_v1_relation_inner(hint, nullable)


def _extract_v1_relation_inner(hint, nullable: bool):
    """Inner extraction after Optional unwrap."""
    origin = get_origin(hint)

    # List[Model] → one-to-many
    if origin in (list, List):
        args = get_args(hint)
        if args and isinstance(args[0], type):
            return args[0], 'one-to-many', nullable
        return None, None, None

    # Direct Model reference → many-to-one
    if isinstance(hint, type) and not is_v1_column_type(hint):
        return hint, 'many-to-one', nullable

    # String forward reference
    if isinstance(hint, str):
        # Will be resolved by _resolve_forward_ref in V2 path
        return hint, 'many-to-one', nullable

    return None, None, None
