# -*- coding: utf-8 -*-
"""
Encoder configuration layer for vector columns.

THIS MODULE IS FOR SCHEMA DECLARATION ONLY.
It provides encoder descriptors used inside vector_column() to annotate which
encoder should be associated with a column. No actual encoding happens here.

The actual encoder classes are generated into _shared/utils/encoders.py by
PythonClientGenerator and are completely self-contained — they do not import
from tai_sql. All generated encoders use langchain as the unified embedding
interface.

Supported providers:
    - SentenceTransformerEncoder → langchain-huggingface (HuggingFaceEmbeddings)
    - OpenAIEncoder → langchain-openai (OpenAIEmbeddings)
    - AzureOpenAIEncoder → langchain-openai (AzureOpenAIEmbeddings)
    - GoogleEncoder → langchain-google-genai (GoogleGenerativeAIEmbeddings)
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Literal, Optional


class BaseEncoder(ABC):
    """
    Abstract encoder descriptor. Used only at schema-definition time to declare
    what encoder model should be associated with a vector column.

    The get_config() method provides the serializable config that generators use
    to emit the correct encoder instantiation in _shared/utils/encoders.py.
    """

    @abstractmethod
    def get_config(self) -> dict:
        """Return serializable config used by generators to reconstruct this encoder."""
        ...

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Number of dimensions this encoder produces (used for column validation)."""
        ...


# ─────────────────────────────────────────────────────────────────────────────
# SentenceTransformerEncoder (HuggingFace local models via langchain-huggingface)
# ─────────────────────────────────────────────────────────────────────────────

SentenceTransformerModelTypes = Literal[
    'all-MiniLM-L6-v2',
    'all-MiniLM-L12-v2',
    'paraphrase-MiniLM-L6-v2',
    'paraphrase-MiniLM-L12-v2',
    'all-mpnet-base-v2',
    'paraphrase-mpnet-base-v2',
    'paraphrase-multilingual-MiniLM-L12-v2',
    'paraphrase-multilingual-mpnet-base-v2',
    'distiluse-base-multilingual-cased-v2',
    'all-distilroberta-v1',
    'multi-qa-MiniLM-L6-cos-v1',
    'multi-qa-mpnet-base-cos-v1',
    'multi-qa-mpnet-base-dot-v1',
    'msmarco-MiniLM-L-6-v3',
    'msmarco-distilbert-base-v4',
]

# Keep backward-compat alias
ModelTypes = SentenceTransformerModelTypes


class SentenceTransformerEncoder(BaseEncoder):
    """
    Configuration descriptor for sentence-transformers encoder columns.

    At runtime, the generated code uses ``langchain-huggingface``
    (``HuggingFaceEmbeddings``) to load the model.

    Use inside vector_column() to declare which model encodes the column::

        embedding: vector = vector_column(
            source='content',
            encoder=SentenceTransformerEncoder('all-MiniLM-L6-v2'),
        )

    This class does NOT load any ML library at import time and does NOT
    perform any encoding. Its sole purpose is to carry the model name and
    dimension information for the generator to emit the correct code.
    """

    KNOWN_MODELS: dict[str, int] = {
        # ── MiniLM family ─────────────────────────────────────────────
        'all-MiniLM-L6-v2':        384,
        'all-MiniLM-L12-v2':       384,
        'paraphrase-MiniLM-L6-v2': 384,
        'paraphrase-MiniLM-L12-v2':384,
        # ── MPNet family ──────────────────────────────────────────────
        'all-mpnet-base-v2':       768,
        'paraphrase-mpnet-base-v2':768,
        # ── Multilingual ──────────────────────────────────────────────
        'paraphrase-multilingual-MiniLM-L12-v2': 384,
        'paraphrase-multilingual-mpnet-base-v2': 768,
        'distiluse-base-multilingual-cased-v2':  512,
        # ── Large / specialized ───────────────────────────────────────
        'all-distilroberta-v1':    768,
        'multi-qa-MiniLM-L6-cos-v1':  384,
        'multi-qa-mpnet-base-cos-v1': 768,
        'multi-qa-mpnet-base-dot-v1': 768,
        'msmarco-MiniLM-L-6-v3':     384,
        'msmarco-distilbert-base-v4': 768,
    }

    def __init__(self, model: SentenceTransformerModelTypes = 'all-MiniLM-L6-v2'):
        self._model_name = model
        self._dimensions: int | None = self.KNOWN_MODELS.get(model)

    @property
    def dimensions(self) -> int:
        if self._dimensions is not None:
            return self._dimensions
        raise ValueError(
            f"Unknown model '{self._model_name}'. Provide dimensions= explicitly in vector_column()."
        )

    def get_config(self) -> dict:
        return {'class': 'HuggingFaceEncoder', 'model': self._model_name}


# ─────────────────────────────────────────────────────────────────────────────
# OpenAIEncoder (via langchain-openai)
# ─────────────────────────────────────────────────────────────────────────────

OpenAIModelTypes = Literal[
    'text-embedding-3-small',
    'text-embedding-3-large',
]


class OpenAIEncoder(BaseEncoder):
    """
    Configuration descriptor for OpenAI embedding models.

    At runtime, the generated code uses ``langchain-openai``
    (``OpenAIEmbeddings``) and reads ``OPENAI_API_KEY`` from env.

    Use inside vector_column()::

        embedding: vector = vector_column(
            source='content',
            encoder=OpenAIEncoder('text-embedding-3-small'),
        )
    """

    KNOWN_MODELS: dict[str, int] = {
        'text-embedding-3-small': 1536,
        'text-embedding-3-large': 3072,
    }

    def __init__(
        self,
        model: OpenAIModelTypes = 'text-embedding-3-small',
        dimensions: Optional[int] = None,
    ):
        self._model_name = model
        self._dimensions = dimensions or self.KNOWN_MODELS.get(model)

    @property
    def dimensions(self) -> int:
        if self._dimensions is not None:
            return self._dimensions
        raise ValueError(
            f"Unknown model '{self._model_name}'. Provide dimensions= explicitly in vector_column()."
        )

    def get_config(self) -> dict:
        return {
            'class': 'OpenAIEncoder',
            'model': self._model_name,
            'dimensions': self._dimensions,
        }


# ─────────────────────────────────────────────────────────────────────────────
# AzureOpenAIEncoder (via langchain-openai)
# ─────────────────────────────────────────────────────────────────────────────

class AzureOpenAIEncoder(BaseEncoder):
    """
    Configuration descriptor for Azure OpenAI embedding models.

    At runtime, the generated code uses ``langchain-openai``
    (``AzureOpenAIEmbeddings``) and reads from env:
        - AZURE_OPENAI_API_KEY
        - AZURE_OPENAI_ENDPOINT
        - AZURE_OPENAI_API_VERSION

    Use inside vector_column()::

        embedding: vector = vector_column(
            source='content',
            encoder=AzureOpenAIEncoder('text-embedding-3-small'),
        )
    """

    KNOWN_MODELS: dict[str, int] = {
        'text-embedding-3-small': 1536,
        'text-embedding-3-large': 3072,
    }

    def __init__(
        self,
        model: OpenAIModelTypes = 'text-embedding-3-small',
        dimensions: Optional[int] = None,
        azure_endpoint: Optional[str] = None,
        api_version: Optional[str] = None,
    ):
        self._model_name = model
        self._dimensions = dimensions or self.KNOWN_MODELS.get(model)
        self._azure_endpoint = azure_endpoint
        self._api_version = api_version

    @property
    def dimensions(self) -> int:
        if self._dimensions is not None:
            return self._dimensions
        raise ValueError(
            f"Unknown model '{self._model_name}'. Provide dimensions= explicitly in vector_column()."
        )

    def get_config(self) -> dict:
        config = {
            'class': 'AzureOpenAIEncoder',
            'model': self._model_name,
            'dimensions': self._dimensions,
        }
        if self._azure_endpoint:
            config['azure_endpoint'] = self._azure_endpoint
        if self._api_version:
            config['api_version'] = self._api_version
        return config


# ─────────────────────────────────────────────────────────────────────────────
# GoogleEncoder (via langchain-google-genai)
# ─────────────────────────────────────────────────────────────────────────────

GoogleModelTypes = Literal[
    'gemini-embedding-2-preview',
    'text-embedding-004',
]


class GoogleEncoder(BaseEncoder):
    """
    Configuration descriptor for Google Generative AI embedding models.

    At runtime, the generated code uses ``langchain-google-genai``
    (``GoogleGenerativeAIEmbeddings``) and reads ``GOOGLE_API_KEY`` from env.

    Supports ``output_dimensionality`` for models like ``gemini-embedding-2-preview``
    which support Matryoshka Representation Learning (768, 1536, or 3072 dims).

    Use inside vector_column()::

        embedding: vector = vector_column(
            source='content',
            encoder=GoogleEncoder('gemini-embedding-2-preview', dimensions=768),
        )
    """

    KNOWN_MODELS: dict[str, int] = {
        'gemini-embedding-2-preview': 3072,
        'text-embedding-004': 768,
    }

    def __init__(
        self,
        model: GoogleModelTypes = 'gemini-embedding-2-preview',
        dimensions: Optional[int] = None,
        location: Optional[str] = None,
        project_id: Optional[str] = None,
    ):
        self._model_name = model
        self._dimensions = dimensions or self.KNOWN_MODELS.get(model)
        self._location = location
        self._project_id = project_id

    @property
    def dimensions(self) -> int:
        if self._dimensions is not None:
            return self._dimensions
        raise ValueError(
            f"Unknown model '{self._model_name}'. Provide dimensions= explicitly in vector_column()."
        )

    def get_config(self) -> dict:
        config = {
            'class': 'GoogleEncoder',
            'model': self._model_name,
            'dimensions': self._dimensions,
        }
        if self._location:
            config['location'] = self._location
        if self._project_id:
            config['project_id'] = self._project_id
        return config

