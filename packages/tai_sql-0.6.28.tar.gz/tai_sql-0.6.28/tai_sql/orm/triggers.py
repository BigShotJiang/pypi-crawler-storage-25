"""
Sistema de triggers para tai-sql.

Este módulo proporciona decoradores y clases para definir triggers que se ejecutan
automáticamente en operaciones CRUD (create, UPDATE, DELETE).

Los triggers definidos en los modelos (public.py) son analizados y convertidos a
código ejecutable que se inyecta en los DAOs generados.

Example:
    ```python
    from tai_sql import *
    from tai_sql.orm.triggers import on_create, on_update, on_delete, TriggerAPI
    
    class Usuario(Table):
        __tablename__ = "usuario"
        
        id: int = column(primary_key=True, autoincrement=True)
        email: str
        status: str
        
        @on_create(timing='before')
        def normalize_email(self, t: TriggerAPI):
            '''Normaliza el email antes de insertar'''
            t.new.email = t.new.email.lower().strip()
        
        @on_update(
            timing='before',
            fields=['status'],
            when=lambda t: t.old['status'] != t.new.status
        )
        def log_status_change(self, t: TriggerAPI):
            '''Registra cambios de estado'''
            t.log(f"Estado cambiado: {t.old['status']} -> {t.new.status}")
    ```
"""
from __future__ import annotations
from typing import Callable, Generic, Optional, List, Any, Dict, Type, TypeVar, TYPE_CHECKING, Union
import inspect
import ast
import textwrap
import copy

from .descriptors import AutoRegisterDescriptor

if TYPE_CHECKING:
    from .table import Table

T = TypeVar('T', bound='Table')
M = TypeVar('M', bound='Table')



class TriggerStep:
    """
    Representa un paso/operación dentro de un trigger.
    
    Cada step corresponde a una operación del TriggerAPI o una operación Python estándar.
    """
    
    def __init__(
        self,
        step_type: str,
        operation: str,
        args: Optional[List[Any]] = None,
        kwargs: Optional[Dict[str, Any]] = None,
        target: Optional[str] = None,
        source_line: Optional[str] = None,
        ast_node: Optional[ast.AST] = None,
        trigger_refs: Optional[List[str]] = None
    ):
        """
        Args:
            step_type: Tipo de operación ('data_access', 'data_mutation', 'crud_call', 'log', 'abort', 'control_flow', 'other')
            operation: Nombre de la operación específica ('get', 'set', 'find', 'create', 'count', 'log', 'abort', etc.)
            args: Argumentos posicionales de la operación
            kwargs: Argumentos nombrados de la operación
            target: Variable o modelo objetivo (ej: 'Post', 'Usuario', 'Post -> post_count')
            source_line: Línea de código fuente original
            ast_node: Nodo AST original para análisis avanzado
            trigger_refs: Referencias a TriggerAPI usadas (ej: ['t.data', 't.instance'])
        """
        self.step_type = step_type
        self.operation = operation
        self.args = args or []
        self.kwargs = kwargs or {}
        self.target = target
        self.source_line = source_line
        self.ast_node = ast_node
        self.trigger_refs = trigger_refs or []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el step a diccionario para serialización"""
        return {
            'step_type': self.step_type,
            'operation': self.operation,
            'args': self.args,
            'kwargs': self.kwargs,
            'target': self.target,
            'source_line': self.source_line,
            'trigger_refs': self.trigger_refs
        }
    
    def transform_code(self, code: str, context: Dict[str, str]) -> str:
        """
        Transforma el código del trigger reemplazando referencias de TriggerAPI.
        
        Args:
            code: Código a transformar
            context: Mapeo de referencias (ej: {'t.data': 't_data', 't.instance': 'instance'})
        
        Returns:
            Código transformado con las referencias correctas
        """
        result = code
        # Ordenar por longitud descendente para evitar reemplazos parciales
        for trigger_ref, actual_var in sorted(context.items(), key=lambda x: len(x[0]), reverse=True):
            result = result.replace(trigger_ref, actual_var)
        return result
    
    def __repr__(self) -> str:
        return f"<TriggerStep {self.step_type}:{self.operation} target={self.target}>"


class TriggerAnalyzer(ast.NodeVisitor):
    """
    Analizador AST para extraer operaciones del TriggerAPI de un trigger.
    
    Recorre el árbol AST de la función trigger e identifica:
    - Accesos a t.data, t.old, t.new, t.instance
    - Llamadas a t.dao(), t.log(), t.abort()
    - Operaciones de mutación de datos
    """
    
    def __init__(self, source_lines: List[str]):
        """
        Args:
            source_lines: Líneas del código fuente para obtener el texto original
        """
        self.steps: List[TriggerStep] = []
        self.source_lines = source_lines
        self.trigger_var = 't'  # Nombre del parámetro TriggerAPI (por defecto 't')
    
    def visit_Assign(self, node: ast.Assign) -> None:
        """Visita asignaciones para detectar mutaciones de datos"""
        # Detectar asignaciones a t.data['campo']
        for target in node.targets:
            if isinstance(target, ast.Subscript):
                if self._is_trigger_attr(target.value, 'data'):
                    # t.data['campo'] = valor
                    field_name = self._extract_subscript_key(target)
                    source_line = self._get_source_line(node)
                    value_code = self._ast_to_repr(node.value)
                    trigger_refs = self._extract_trigger_references(node)
                    
                    self.steps.append(TriggerStep(
                        step_type='data_mutation',
                        operation='set_data',
                        target=field_name,
                        args=[value_code],
                        source_line=source_line,
                        ast_node=node,
                        trigger_refs=trigger_refs
                    ))
        
        # Detectar asignaciones que incluyan llamadas CRUD
        if isinstance(node.value, ast.Call):
            if self._is_crud_method(node.value.func):
                crud_operation = node.value.func.attr
                
                # El primer argumento debe ser el modelo
                model_name = None
                if len(node.value.args) > 0 and isinstance(node.value.args[0], ast.Name):
                    model_name = node.value.args[0].id
                
                # Los demás argumentos
                args = [self._ast_to_repr(arg) for arg in node.value.args[1:]]
                kwargs = {kw.arg: self._ast_to_repr(kw.value) for kw in node.value.keywords}
                trigger_refs = self._extract_trigger_references(node)
                
                # Obtener el nombre de la variable de asignación
                var_name = None
                if node.targets and isinstance(node.targets[0], ast.Name):
                    var_name = node.targets[0].id
                
                self.steps.append(TriggerStep(
                    step_type='crud_call',
                    operation=crud_operation,
                    args=args,
                    kwargs=kwargs,
                    target=f"{model_name} -> {var_name}" if var_name else model_name,
                    source_line=self._get_source_line(node),
                    ast_node=node,
                    trigger_refs=trigger_refs
                ))
        
        self.generic_visit(node)
    
    def visit_Expr(self, node: ast.Expr) -> None:
        """Visita expresiones para detectar llamadas a métodos del TriggerAPI"""
        if isinstance(node.value, ast.Call):
            self._visit_call(node.value)
        self.generic_visit(node)
    
    def _visit_call(self, node: ast.Call) -> None:
        """Procesa llamadas a funciones/métodos"""
        # Detectar t.log(...)
        if self._is_trigger_method(node.func, 'log'):
            args = [self._ast_to_repr(arg) for arg in node.args]
            kwargs = {kw.arg: self._ast_to_repr(kw.value) for kw in node.keywords}
            trigger_refs = self._extract_trigger_references(node)
            
            self.steps.append(TriggerStep(
                step_type='log',
                operation='log',
                args=args,
                kwargs=kwargs,
                source_line=self._get_source_line(node),
                ast_node=node,
                trigger_refs=trigger_refs
            ))
        
        # Detectar t.abort(...)
        elif self._is_trigger_method(node.func, 'abort'):
            args = [self._ast_to_repr(arg) for arg in node.args]
            trigger_refs = self._extract_trigger_references(node)
            
            self.steps.append(TriggerStep(
                step_type='abort',
                operation='abort',
                args=args,
                source_line=self._get_source_line(node),
                ast_node=node,
                trigger_refs=trigger_refs
            ))
        
        # Detectar llamadas CRUD: t.find(...), t.create(...), t.count(...), etc.
        elif self._is_crud_method(node.func):
            crud_operation = node.func.attr  # find, create, count, etc.
            
            # El primer argumento debe ser el modelo
            model_name = None
            if len(node.args) > 0 and isinstance(node.args[0], ast.Name):
                model_name = node.args[0].id
            
            # Los demás argumentos son parámetros de la operación
            args = [self._ast_to_repr(arg) for arg in node.args[1:]]  # Saltar el modelo
            kwargs = {kw.arg: self._ast_to_repr(kw.value) for kw in node.keywords}
            trigger_refs = self._extract_trigger_references(node)
            
            self.steps.append(TriggerStep(
                step_type='crud_call',
                operation=crud_operation,
                args=args,
                kwargs=kwargs,
                target=model_name,
                source_line=self._get_source_line(node),
                ast_node=node,
                trigger_refs=trigger_refs
            ))
    
    def _is_trigger_attr(self, node: ast.AST, attr_name: str) -> bool:
        """Verifica si un nodo es un atributo del trigger (ej: t.data, t.old)"""
        return (isinstance(node, ast.Attribute) and 
                isinstance(node.value, ast.Name) and 
                node.value.id == self.trigger_var and 
                node.attr == attr_name)
    
    def _is_trigger_method(self, node: ast.AST, method_name: str) -> bool:
        """Verifica si un nodo es una llamada a método del trigger (ej: t.log, t.abort)"""
        return (isinstance(node, ast.Attribute) and 
                isinstance(node.value, ast.Name) and 
                node.value.id == self.trigger_var and 
                node.attr == method_name)
    
    def _is_crud_method(self, node: ast.AST) -> bool:
        """Verifica si un nodo es una llamada CRUD (t.find, t.create, t.count, etc.)"""
        # Lista de métodos CRUD del TriggerAPI
        crud_methods = {
            # Read operations
            'find', 'find_many', 'count', 'exists', 'sum', 'mean', 'max', 'min', 'agg',
            # Write operations
            'create', 'create_many', 'update', 'update_many', 'delete', 'delete_many',
            'upsert', 'upsert_many',
        }
        
        return (isinstance(node, ast.Attribute) and 
                isinstance(node.value, ast.Name) and 
                node.value.id == self.trigger_var and 
                node.attr in crud_methods)
    
    def _extract_subscript_key(self, node: ast.Subscript) -> Optional[str]:
        """Extrae la clave de un subscript (ej: data['email'] -> 'email')"""
        if isinstance(node.slice, ast.Constant):
            return str(node.slice.value)
        elif isinstance(node.slice, ast.Str):  # Python < 3.8
            return node.slice.s
        return None
    
    def _ast_to_repr(self, node: ast.AST) -> str:
        """
        Convierte un nodo AST a su representación como string.
        Mantiene el código original sin transformar.
        """
        try:
            return ast.unparse(node)
        except:
            # Fallback para versiones antiguas de Python
            return ast.dump(node)
    
    def _extract_trigger_references(self, node: ast.AST) -> List[str]:
        """
        Extrae todas las referencias a TriggerAPI (t.old, t.new)
        de un nodo AST.
        
        Returns:
            Lista de referencias encontradas (ej: ['t.new', 't.old'])
        """
        references = []
        
        class ReferenceExtractor(ast.NodeVisitor):
            def visit_Attribute(self, node):
                if isinstance(node.value, ast.Name) and node.value.id == 't':
                    if node.attr in ['old', 'new']:
                        references.append(f't.{node.attr}')
                self.generic_visit(node)
        
        extractor = ReferenceExtractor()
        extractor.visit(node)
        return list(set(references))  # Eliminar duplicados
    
    def _get_source_line(self, node: ast.AST) -> Optional[str]:
        """Obtiene la línea de código fuente original de un nodo AST"""
        if hasattr(node, 'lineno') and node.lineno <= len(self.source_lines):
            # lineno es 1-indexed
            return self.source_lines[node.lineno - 1].strip()
        return None


class TriggerAPI(Generic[M]):
    """
    API que el usuario utiliza dentro de los triggers.
    
    Esta clase es SOLO para type hints y documentación.
    El generador extraerá los metadatos de uso y generará código equivalente.
    
    Disponibilidad por evento:
        on_create: solo t.new (instancia SQLAlchemy que se va a insertar)
        on_update: t.old (dict snapshot pre-update) + t.new (instancia SQLAlchemy mutada)
        on_delete: solo t.old (instancia SQLAlchemy del registro a eliminar)
    
    Attributes:
        new: Instancia del modelo con los valores nuevos/a insertar (create, update)
        old: Valores anteriores a la operación (update como dict, delete como instancia)
    
    Methods (Cross-table Read):
        find(model, id, includes): Busca un registro por PK
        find_many(model, **filters): Busca múltiples registros con filtros
        count(model, **filters): Cuenta registros
        exists(model, **filters): Verifica existencia
    
    Methods (Cross-table Write):
        create(model, **data): Crea un registro
        create_many(model, records): Crea múltiples registros
        update(model, id, **data): Actualiza un registro por PK
        delete(model, id): Elimina un registro por PK
        update_many(model, filters, **data): Actualiza múltiples registros
        delete_many(model, **filters): Elimina múltiples registros
        upsert(model, match_fields, **data): Upsert un registro
        upsert_many(model, records, match_fields): Upsert múltiples registros
    
    Methods (Cross-table Aggregation):
        sum(model, agg_fields, **filters): Suma campos
        mean(model, agg_fields, **filters): Promedio campos
        max(model, agg_fields, **filters): Máximo campos
        min(model, agg_fields, **filters): Mínimo campos
        agg(model, request, **filters): Agregación completa con AggRequest
    
    Methods (Utility):
        log(message, level): Registra un mensaje
        abort(message): Aborta la operación
    
    Note:
        Esta clase NO se instancia en runtime. Es solo para documentación y type hints.
        El generador transforma las llamadas a métodos en código imperativo.
    """
    
    @property
    def new(self) -> M:
        """
        Instancia del modelo con los valores nuevos.
        
        Disponible en:
        - on_create: instancia SQLAlchemy que se va a insertar (modificable en 'before')
        - on_update: instancia SQLAlchemy con los valores actualizados aplicados
        
        NO disponible en on_delete (usar t.old).
        
        Example:
            ```python
            @on_create(timing='before')
            def normalize_email(self, t: TriggerAPI[Usuario]):
                t.new.email = t.new.email.lower().strip()
            
            @on_update(timing='before', fields=['price'])
            def check_price(self, t: TriggerAPI[Post]):
                if t.new.price > t.old.price * 2:
                    t.abort("Precio no puede duplicarse")
            ```
        
        Returns:
            Instancia del modelo (tipo M del genérico TriggerAPI[M])
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    @property
    def old(self) -> M:
        """
        Valores anteriores a la operación (acceso por atributo).
        
        Disponible en:
        - on_update: DTO Read con los valores anteriores (acceso: t.old.campo)
        - on_delete: DTO Read del registro antes de eliminarse
        
        NO disponible en on_create (no hay estado previo).
        
        Example:
            ```python
            @on_update(
                fields=['status'],
                when=lambda t: t.old.status != t.new.status
            )
            def log_status_change(self, t: TriggerAPI[Post]):
                t.log(f"Estado: {t.old.status} -> {t.new.status}")
            
            @on_delete(timing='before')
            def cascade_delete(self, t: TriggerAPI[Post]):
                t.delete_many(Comment, post_id=t.old.id)
            ```
        
        Returns:
            Instancia del modelo (tipo M del genérico TriggerAPI[M])
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    # ============================================
    # Métodos cross-table: Lectura
    # ============================================
    
    def find(self, model: Type[T], id: Any, includes: Optional[List[str]] = None) -> Optional[T]:
        """
        Busca un registro en otra tabla por primary key.
        
        Args:
            model: Clase Table del modelo a buscar
            id: Valor de la primary key
            includes: Lista de relaciones a cargar eagerly (dot-notation para nested)
        
        Example:
            ```python
            @on_update(timing='after', fields=['author_id'])
            def load_author(self, t: TriggerAPI):
                author = t.find(Usuario, t.new.author_id, includes=['posts'])
                if author:
                    t.log(f"Autor: {author.name}")
            ```
        
        Returns:
            Instancia del modelo o None si no existe
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def find_many(self, model: Type[T], limit: Optional[int] = None, offset: Optional[int] = None,
                  order_by: Optional[List[str]] = None, order: str = 'ASC',
                  includes: Optional[List[str]] = None, **filters) -> List[T]:
        """
        Busca múltiples registros en otra tabla con filtros.
        
        Los filtros siguen el mismo patrón que el DAO generado:
        - campo=valor: Coincidencia exacta (ILIKE para str con '%')
        - in_campo=[valores]: Cláusula IN
        - min_campo=valor: >= (para numéricos/datetime)
        - max_campo=valor: <= (para numéricos/datetime)
        
        Args:
            model: Clase Table del modelo a buscar
            limit: Máximo de registros a retornar
            offset: Registros a saltar
            order_by: Lista de campos para ordenar
            order: Dirección de orden ('ASC' o 'DESC')
            includes: Lista de relaciones a cargar eagerly
            **filters: Filtros por columna (misma API que DAO.find_many)
        
        Example:
            ```python
            @on_delete(timing='before')
            def check_active_posts(self, t: TriggerAPI):
                posts = t.find_many(Post, author_id=t.old.id, status='published', limit=100)
                if posts:
                    t.abort(f"No se puede eliminar: {len(posts)} posts activos")
            ```
        
        Returns:
            Lista de instancias del modelo
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def count(self, model: Type[Table], **filters) -> int:
        """
        Cuenta registros en otra tabla que coincidan con los filtros.
        
        Args:
            model: Clase Table del modelo
            **filters: Filtros por columna (misma API que DAO.count)
        
        Example:
            ```python
            @on_create(timing='before')
            def limit_posts(self, t: TriggerAPI):
                total = t.count(Post, author_id=t.new.author_id)
                if total >= 100:
                    t.abort("Límite de posts alcanzado")
            ```
        
        Returns:
            Número de registros
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def exists(self, model: Type[Table], **filters) -> bool:
        """
        Verifica si existe al menos un registro que coincida con los filtros.
        
        Args:
            model: Clase Table del modelo
            **filters: Filtros por columna (misma API que DAO.exists)
        
        Example:
            ```python
            @on_create(timing='before')
            def check_unique_email(self, t: TriggerAPI):
                if t.exists(Usuario, email=t.new.email):
                    t.abort("Email ya registrado")
            ```
        
        Returns:
            True si existe al menos un registro
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    # ============================================
    # Métodos cross-table: Escritura
    # ============================================
    
    def create(self, model: Type[T], **data) -> T:
        """
        Crea un registro en otra tabla.
        
        Args:
            model: Clase Table del modelo
            **data: Campos y valores del nuevo registro
        
        Example:
            ```python
            @on_create(timing='after')
            def create_profile(self, t: TriggerAPI):
                profile = t.create(Profile, user_id=t.new.id, bio='')
            ```
        
        Returns:
            Instancia del modelo creado (con ID asignado)
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def create_many(self, model: Type[T], records: List[Dict[str, Any]]) -> int:
        """
        Crea múltiples registros en otra tabla.
        
        Args:
            model: Clase Table del modelo
            records: Lista de diccionarios con los campos de cada registro
        
        Example:
            ```python
            @on_create(timing='after')
            def create_default_tags(self, t: TriggerAPI):
                tags = [
                    {'name': 'general', 'post_id': t.new.id},
                    {'name': 'nuevo', 'post_id': t.new.id},
                ]
                t.create_many(Tag, tags)
            ```
        
        Returns:
            Número de registros creados
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def update(self, model: Type[Table], id: Any, **data) -> int:
        """
        Actualiza un registro en otra tabla por primary key.
        
        Args:
            model: Clase Table del modelo
            id: Valor de la primary key
            **data: Campos y valores a actualizar
        
        Example:
            ```python
            @on_update(timing='after', fields=['status'])
            def update_profile_status(self, t: TriggerAPI):
                t.update(Profile, t.new.profile_id, active=(t.new.status == 'active'))
            ```
        
        Returns:
            1 si se actualizó, 0 si no se encontró
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def delete(self, model: Type[Table], id: Any) -> int:
        """
        Elimina un registro en otra tabla por primary key.
        
        Args:
            model: Clase Table del modelo
            id: Valor de la primary key
        
        Returns:
            1 si se eliminó, 0 si no se encontró
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def update_many(self, model: Type[Table], filters: Dict[str, Any], **data) -> int:
        """
        Actualiza múltiples registros en otra tabla.
        
        Args:
            model: Clase Table del modelo
            filters: Diccionario de filtros para seleccionar registros
            **data: Campos y valores a actualizar
        
        Example:
            ```python
            @on_delete(timing='before')
            def archive_posts(self, t: TriggerAPI):
                t.update_many(Post, filters={'author_id': t.old.id}, archived=True)
            ```
        
        Returns:
            Número de registros actualizados
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def delete_many(self, model: Type[Table], **filters) -> int:
        """
        Elimina múltiples registros en otra tabla.
        
        Args:
            model: Clase Table del modelo
            **filters: Filtros para seleccionar registros a eliminar
        
        Example:
            ```python
            @on_delete(timing='before')
            def cascade_delete(self, t: TriggerAPI):
                t.delete_many(Post, author_id=t.old.id)
            ```
        
        Returns:
            Número de registros eliminados
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def upsert(self, model: Type[T], match_fields: List[str], **data) -> T:
        """
        Inserta o actualiza un registro en otra tabla.
        
        Si existe un registro que coincida en match_fields, lo actualiza.
        Si no existe, lo crea.
        
        Args:
            model: Clase Table del modelo
            match_fields: Campos para determinar si el registro ya existe
            **data: Campos y valores del registro
        
        Example:
            ```python
            @on_create(timing='after')
            def upsert_stats(self, t: TriggerAPI):
                t.upsert(UserStats, match_fields=['user_id'],
                         user_id=t.new.id, post_count=1)
            ```
        
        Returns:
            Instancia del modelo (creado o actualizado)
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def upsert_many(self, model: Type[T], records: List[Dict[str, Any]], match_fields: List[str]) -> int:
        """
        Inserta o actualiza múltiples registros en otra tabla.
        
        Args:
            model: Clase Table del modelo
            records: Lista de diccionarios con los campos de cada registro
            match_fields: Campos para determinar si cada registro ya existe
        
        Returns:
            Número de registros procesados
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    # ============================================
    # Métodos cross-table: Agregación
    # ============================================
    
    def sum(self, model: Type[Table], agg_fields: List[str], **filters) -> Any:
        """
        Suma los valores de campos en otra tabla.
        
        Args:
            model: Clase Table del modelo
            agg_fields: Lista de campos a sumar
            **filters: Filtros para seleccionar registros
        
        Example:
            ```python
            @on_update(timing='after', fields=['price'])
            def update_total(self, t: TriggerAPI):
                result = t.sum(OrderItem, ['price'], order_id=t.new.order_id)
            ```
        
        Returns:
            AggregationResult con los valores sumados
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def mean(self, model: Type[Table], agg_fields: List[str], **filters) -> Any:
        """
        Calcula el promedio de campos en otra tabla.
        
        Args:
            model: Clase Table del modelo
            agg_fields: Lista de campos para calcular promedio
            **filters: Filtros para seleccionar registros
        
        Returns:
            AggregationResult con los promedios
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def max(self, model: Type[Table], agg_fields: List[str], **filters) -> Any:
        """
        Obtiene el valor máximo de campos en otra tabla.
        
        Args:
            model: Clase Table del modelo
            agg_fields: Lista de campos
            **filters: Filtros para seleccionar registros
        
        Returns:
            AggregationResult con los máximos
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def min(self, model: Type[Table], agg_fields: List[str], **filters) -> Any:
        """
        Obtiene el valor mínimo de campos en otra tabla.
        
        Args:
            model: Clase Table del modelo
            agg_fields: Lista de campos
            **filters: Filtros para seleccionar registros
        
        Returns:
            AggregationResult con los mínimos
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def agg(self, model: Type[Table], request: Any, **filters) -> Any:
        """
        Ejecuta una agregación completa con AggRequest en otra tabla.
        
        Args:
            model: Clase Table del modelo
            request: Objeto AggRequest con las operaciones de agregación
            **filters: Filtros para seleccionar registros
        
        Example:
            ```python
            @on_update(timing='after')
            def recalculate_stats(self, t: TriggerAPI):
                from database._shared.aggregation import AggRequest
                result = t.agg(OrderItem, AggRequest(
                    aggregations={'sum': ['price'], 'count': ['id']}
                ), order_id=t.new.order_id)
            ```
        
        Returns:
            AggregationResult con los resultados de la agregación
        """
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    # ============================================
    # Métodos de utilidad
    # ============================================
    
    def log(self, message: str, level: str = 'info') -> None:
        """Registra un mensaje en el logger del sistema."""
        raise NotImplementedError("TriggerAPI es solo para type hints")
    
    def abort(self, message: str) -> None:
        """Aborta la operación lanzando una excepción."""
        raise NotImplementedError("TriggerAPI es solo para type hints")


# ============================================
# Extracción robusta de 'when' desde el AST del decorador
# ============================================

def _extract_when_source_from_ast(func_ast: ast.FunctionDef) -> Optional[str]:
    """
    Extrae el código fuente de la lambda 'when' directamente del AST del decorador.
    
    En lugar de usar inspect.getsource(lambda) + manipulación de strings frágil,
    analiza el nodo AST del decorador para encontrar el keyword 'when' y usa 
    ast.unparse() en su valor (el cuerpo de la lambda).
    
    Args:
        func_ast: AST de la función decorada (contiene decorator_list)
    
    Returns:
        Código fuente de la expresión inside la lambda (sin 'lambda t:'), 
        o None si no se encontró.
    """
    if not func_ast.decorator_list:
        return None
    
    # El decorador es el último (o único) en la lista
    # Para on_create/on_update/on_delete siempre hay uno
    for decorator in func_ast.decorator_list:
        # Buscar decorador con keyword 'when'
        if isinstance(decorator, ast.Call):
            for kw in decorator.keywords:
                if kw.arg == 'when' and isinstance(kw.value, ast.Lambda):
                    # ast.unparse del body de la lambda (sin 'lambda t:')
                    try:
                        return ast.unparse(kw.value.body)
                    except Exception:
                        return None
    return None


# ============================================
# Validación de referencias inválidas
# ============================================

_INVALID_REFS = {
    'create': {'old': "'t.old' no está disponible en triggers @on_create. Solo puedes usar 't.new' para acceder a los datos."},
    'delete': {'new': "'t.new' no está disponible en triggers @on_delete. Solo puedes usar 't.old' para acceder al registro."},
}


def _validate_trigger_references(event: str, func_ast: ast.FunctionDef, func_name: str, trigger_param: str = 't') -> None:
    """
    Valida que el trigger no use referencias inválidas para su evento.
    
    Raises:
        SyntaxError: Con mensaje descriptivo si se detecta un uso inválido.
    """
    invalid = _INVALID_REFS.get(event, {})
    if not invalid:
        return
    
    class RefChecker(ast.NodeVisitor):
        def visit_Attribute(self, node):
            if (isinstance(node.value, ast.Name) 
                and node.value.id == trigger_param 
                and node.attr in invalid):
                msg = invalid[node.attr]
                raise SyntaxError(
                    f"Error en trigger '{func_name}': {msg}"
                )
            self.generic_visit(node)
    
    RefChecker().visit(func_ast)


class TriggerCodeTransformer(ast.NodeTransformer):
    """
    Transforma el AST del cuerpo de un trigger para inyección directa 
    en código generado. Reemplaza las referencias del TriggerAPI con 
    variables locales explícitas del método CRUD.
    
    Mapeo de variables según evento (donde <tn> = tablename del modelo):
        CREATE: t.new/self → new_<tn>
        UPDATE: t.new/self → new_<tn>, t.old → old_<tn>
        DELETE: t.old/self → old_<tn>
    
    Para CREATE/UPDATE, t.new es un modelo SQLAlchemy (acceso por atributo).
    Para UPDATE, t.old es un DTO Read (acceso por atributo).
    Para DELETE, t.old es un DTO Read (acceso por atributo).
    
    Mapeo de métodos:
        t.log(msg)   → logger.info("🔔 Trigger: ...")
        t.abort(msg) → raise ValueError("Trigger abortado: ...")
    
    Operaciones cross-table:
        t.update(Model, pk, **values)  → {Model}{Mode}DAO(self.session_manager).update(pk, updated_values={Model}UpdateValues(**values), session=session)
        t.create(Model, **values)      → {Model}{Mode}DAO(self.session_manager).create({Model}Create(**values), session=session)
        t.delete(Model, pk)            → {Model}{Mode}DAO(self.session_manager).delete(pk, session=session)
        t.update_many(Model, filters={...}, **values) → {Model}{Mode}DAO(self.session_manager).update_many(payload={Model}Update(filter={Model}UpdateFilter(**filters), values={Model}UpdateValues(**values)), session=session)
        t.delete_many(Model, **filters) → {Model}{Mode}DAO(self.session_manager).delete_many(filters_list=[{**filters}], session=session)
    """
    
    # Sufijo del DAO según modo de generación
    DAO_SUFFIX = {
        'sync': 'SyncDAO',
        'async': 'AsyncDAO',
    }
    
    def __init__(self, trigger_param: str, event: str, mode: str = 'sync',
                 operative_str_fields: List[str] = [], tablename: str = 'instance'):
        self.trigger_param = trigger_param
        self.event = event
        self.mode = mode
        self.tablename = tablename
        self.dao_suffix = self.DAO_SUFFIX.get(mode, 'SyncDAO')
        # Campos operativos de tipo str del modelo padre disponibles en el scope del trigger
        self.operative_str_fields: List[str] = list(operative_str_fields)
        
        # Construir mapeos dinámicos basados en tablename
        new_var = f'new_{tablename}'
        old_var = f'old_{tablename}'
        
        self.attr_map = {
            'create': {'new': new_var},
            'update': {'new': new_var, 'old': old_var},
            'delete': {'old': old_var},
        }.get(event, {})
        
        self.self_target = {
            'create': new_var,
            'update': new_var,
            'delete': old_var,
        }.get(event, 'instance')
        
        self.model_targets = {
            'create': {new_var},
            'update': {new_var},
            'delete': {old_var},
        }.get(event, set())
    
    def _is_trigger_ref(self, node) -> bool:
        """Comprueba si el nodo es una referencia al parámetro del trigger."""
        return isinstance(node, ast.Name) and node.id == self.trigger_param
    
    def visit_Attribute(self, node):
        """Transforma t.data, t.instance, t.old, t.new → variables locales.
        También transforma self.field → instance.field / record.field."""
        self.generic_visit(node)
        # t.attr → variable local
        if self._is_trigger_ref(node.value) and node.attr in self.attr_map:
            return ast.copy_location(
                ast.Name(id=self.attr_map[node.attr], ctx=node.ctx), node
            )
        # self.field → instance.field / record.field  
        if isinstance(node.value, ast.Name) and node.value.id == 'self':
            return ast.copy_location(
                ast.Attribute(
                    value=ast.Name(id=self.self_target, ctx=ast.Load()),
                    attr=node.attr,
                    ctx=node.ctx
                ), node
            )
        return node
    
    def visit_Subscript(self, node):
        """Convierte acceso dict a acceso por atributo para modelos SQLAlchemy.
        
        instance['email'] → instance.email
        """
        self.generic_visit(node)
        if (isinstance(node.value, ast.Name) 
            and node.value.id in self.model_targets
            and isinstance(node.slice, ast.Constant)
            and isinstance(node.slice.value, str)):
            return ast.copy_location(
                ast.Attribute(value=node.value, attr=node.slice.value, ctx=node.ctx),
                node
            )
        return node
    
    def visit_Call(self, node):
        """Convierte .get('field') a acceso por atributo para modelos SQLAlchemy.
        
        instance.get('email') → instance.email
        """
        self.generic_visit(node)
        if (isinstance(node.func, ast.Attribute) 
            and node.func.attr == 'get'
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id in self.model_targets
            and node.args
            and isinstance(node.args[0], ast.Constant)
            and isinstance(node.args[0].value, str)):
            return ast.copy_location(
                ast.Attribute(
                    value=node.func.value,
                    attr=node.args[0].value,
                    ctx=ast.Load()
                ),
                node
            )
        return node
    
    def _make_expr(self, dao_call: ast.Call, ref_node: ast.AST) -> ast.Expr:
        """
        Construye un nodo ast.Expr con la llamada al DAO.
        En modo async envuelve el call en ast.Await para que el generador
        produzca: await ModelAsyncDAO(self.session_manager).method(...)
        """
        value = (
            ast.copy_location(ast.Await(value=dao_call), ref_node)
            if self.mode == 'async'
            else dao_call
        )
        result = ast.copy_location(ast.Expr(value=value), ref_node)
        ast.fix_missing_locations(result)
        return result

    def visit_Assign(self, node):
        """
        Transforma asignaciones cuyo valor es una operación cross-table.

        Convierte, p.ej.:
            result = t.create(Model, field=val)
        en:
            result = ModelAsyncDAO(self.session_manager).create(ModelCreate(field=val), session=session)
            # (con 'await' en modo async)
        """
        self.generic_visit(node)

        # Solo asignaciones simples con una llamada al TriggerAPI como valor
        if not (isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Attribute)
                and self._is_trigger_ref(node.value.func.value)):
            return node

        call   = node.value
        method = call.func.attr

        # Reutilizar _transform_cross_* pasando un Expr ficticio como contenedor
        fake_expr = ast.copy_location(ast.Expr(value=call), node)

        dispatch = {
            'find':        self._transform_cross_find,
            'find_many':   self._transform_cross_find_many,
            'create':      self._transform_cross_create,
            'create_many': self._transform_cross_create_many,
            'update':      self._transform_cross_update,
            'delete':      self._transform_cross_delete,
            'update_many': self._transform_cross_update_many,
            'delete_many': self._transform_cross_delete_many,
            'count':       self._transform_cross_count,
            'exists':      self._transform_cross_exists,
            'sum':         lambda n, c: self._transform_cross_agg_simple(n, c, 'sum'),
            'mean':        lambda n, c: self._transform_cross_agg_simple(n, c, 'mean'),
            'max':         lambda n, c: self._transform_cross_agg_simple(n, c, 'max'),
            'min':         lambda n, c: self._transform_cross_agg_simple(n, c, 'min'),
            'agg':         self._transform_cross_agg,
            'upsert':      self._transform_cross_upsert,
            'upsert_many': self._transform_cross_upsert_many,
        }

        transformer_fn = dispatch.get(method)
        if transformer_fn is None:
            return node

        transformed_expr = transformer_fn(fake_expr, call)

        # Si la transformación no produjo cambios (retornó el nodo original) salir
        if transformed_expr is fake_expr:
            return node

        # Extraer el dao_call del Expr resultante y envolver en await si es necesario
        dao_call = transformed_expr.value
        if self.mode == 'async':
            dao_call = ast.copy_location(ast.Await(value=dao_call), node)

        new_node = ast.copy_location(
            ast.Assign(targets=node.targets, value=dao_call, type_comment=None),
            node,
        )
        ast.fix_missing_locations(new_node)
        return new_node

    def visit_Expr(self, node):
        """Transforma t.log(), t.abort() y operaciones cross-table a código explícito."""
        self.generic_visit(node)
        if not isinstance(node.value, ast.Call):
            return node

        call = node.value
        if not (isinstance(call.func, ast.Attribute) and self._is_trigger_ref(call.func.value)):
            return node

        method = call.func.attr

        if method == 'log':
            msg = call.args[0] if call.args else ast.Constant("")
            prefixed = self._prepend_to_msg("🔔 Trigger: ", msg)
            # Extraer nivel de log del keyword 'level'
            log_level = 'info'
            for kw in call.keywords:
                if kw.arg == 'level' and isinstance(kw.value, ast.Constant):
                    log_level = kw.value.value
            new_call = ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id='logger', ctx=ast.Load()),
                    attr=log_level, ctx=ast.Load()
                ),
                args=[prefixed], keywords=[]
            )
            return ast.copy_location(ast.Expr(value=new_call), node)

        elif method == 'abort':
            msg = call.args[0] if call.args else ast.Constant("")
            prefixed = self._prepend_to_msg("Trigger abortado: ", msg)
            return ast.copy_location(
                ast.Raise(
                    exc=ast.Call(
                        func=ast.Name(id='ValueError', ctx=ast.Load()),
                        args=[prefixed], keywords=[]
                    ),
                    cause=None
                ), node
            )

        # Operaciones cross-table — _make_expr añade 'await' en modo async
        elif method == 'find':
            return self._make_expr(self._transform_cross_find(node, call).value, node)
        elif method == 'find_many':
            return self._make_expr(self._transform_cross_find_many(node, call).value, node)
        elif method == 'update':
            return self._make_expr(self._transform_cross_update(node, call).value, node)
        elif method == 'create':
            return self._make_expr(self._transform_cross_create(node, call).value, node)
        elif method == 'create_many':
            return self._make_expr(self._transform_cross_create_many(node, call).value, node)
        elif method == 'delete':
            return self._make_expr(self._transform_cross_delete(node, call).value, node)
        elif method == 'update_many':
            return self._make_expr(self._transform_cross_update_many(node, call).value, node)
        elif method == 'delete_many':
            return self._make_expr(self._transform_cross_delete_many(node, call).value, node)
        elif method == 'count':
            return self._make_expr(self._transform_cross_count(node, call).value, node)
        elif method == 'exists':
            return self._make_expr(self._transform_cross_exists(node, call).value, node)
        elif method in ('sum', 'mean', 'max', 'min'):
            return self._make_expr(self._transform_cross_agg_simple(node, call, method).value, node)
        elif method == 'agg':
            return self._make_expr(self._transform_cross_agg(node, call).value, node)
        elif method == 'upsert':
            return self._make_expr(self._transform_cross_upsert(node, call).value, node)
        elif method == 'upsert_many':
            return self._make_expr(self._transform_cross_upsert_many(node, call).value, node)

        return node
    
    def _get_model_name(self, call) -> Optional[str]:
        """Extrae el nombre del modelo del primer argumento posicional."""
        if call.args and isinstance(call.args[0], ast.Name):
            return call.args[0].id
        return None
    
    def _make_dao_call(self, model_name: str, method: str, args: list, keywords: list):
        """Construye: {Model}{Mode}DAO.{method}(..., session=session)"""
        dao_class = f"{model_name}{self.dao_suffix}"
        
        # Añadir session=session a keywords si no está
        has_session = any(kw.arg == 'session' for kw in keywords)
        if not has_session:
            keywords = keywords + [
                ast.keyword(arg='session', value=ast.Name(id='session', ctx=ast.Load()))
            ]
        
        return ast.Call(
            func=ast.Attribute(
                value=ast.Name(id=dao_class, ctx=ast.Load()),
                attr=method, ctx=ast.Load()
            ),
            args=args,
            keywords=keywords
        )
    
    def _operative_keywords_for(self, op: str) -> List[ast.keyword]:
        """
        Returns an empty list — operative fields are now resolved via
        get_username() ContextVar inside each DAO method, so no explicit
        keyword propagation is needed in cross-table calls.
        """
        return []

    def _transform_cross_find(self, node, call):
        """t.find(Model, pk_value, includes=[...]) → {Model}DAO(...).find(pk_value, includes=[...], session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node

        pk_value = call.args[1]

        # Extraer includes keyword si existe
        keywords = []
        for kw in call.keywords:
            if kw.arg == 'includes':
                keywords.append(kw)

        dao_call = self._make_dao_call(
            model_name, 'find',
            args=[pk_value],
            keywords=keywords
        )

        return ast.copy_location(ast.Expr(value=dao_call), node)

    def _transform_cross_update(self, node, call):
        """t.update(Model, pk_value, **values) → {Model}DAO(...).update(pk_value, updated_values={Model}UpdateValues(**values), session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node

        pk_value = call.args[1]
        value_kwargs = call.keywords

        # Construir {Model}UpdateValues(**values)
        update_values_call = ast.Call(
            func=ast.Name(id=f"{model_name}UpdateValues", ctx=ast.Load()),
            args=[],
            keywords=list(value_kwargs)
        )

        dao_call = self._make_dao_call(
            model_name, 'update',
            args=[pk_value],
            keywords=[
                ast.keyword(arg='updated_values', value=update_values_call),
                *self._operative_keywords_for('update'),
            ]
        )

        return ast.copy_location(ast.Expr(value=dao_call), node)

    def _transform_cross_create(self, node, call):
        """t.create(Model, **values) → {Model}DAO(...).create({Model}Create(**values), session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node

        value_kwargs = call.keywords

        # Construir {Model}Create(**values)
        create_dto_call = ast.Call(
            func=ast.Name(id=f"{model_name}Create", ctx=ast.Load()),
            args=[],
            keywords=list(value_kwargs)
        )

        dao_call = self._make_dao_call(
            model_name, 'create',
            args=[create_dto_call],
            keywords=self._operative_keywords_for('create'),
        )

        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_delete(self, node, call):
        """t.delete(Model, pk_value) → {Model}DAO(...).delete(pk_value, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node
        
        pk_value = call.args[1]
        
        dao_call = self._make_dao_call(
            model_name, 'delete',
            args=[pk_value],
            keywords=[]
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_update_many(self, node, call):
        """t.update_many(Model, filters={...}, **values) → {Model}DAO(...).update_many(payload={Model}Update(filter=..., values=...), session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        # Extraer filters del keyword 'filters'
        filters_node = None
        value_kwargs = []
        for kw in call.keywords:
            if kw.arg == 'filters':
                filters_node = kw.value
            else:
                value_kwargs.append(kw)
        
        if filters_node is None:
            return node
        
        # Si filters es un Dict literal, convertir a kwargs para el Filter DTO
        if isinstance(filters_node, ast.Dict):
            filter_keywords = [
                ast.keyword(arg=key.value if isinstance(key, ast.Constant) else None, value=val)
                for key, val in zip(filters_node.keys, filters_node.values)
            ]
        else:
            # Fallback: pasar como **filters
            filter_keywords = [ast.keyword(arg=None, value=filters_node)]
        
        # Construir {Model}Update(filter={Model}UpdateFilter(**filters), values={Model}UpdateValues(**values))
        payload_call = ast.Call(
            func=ast.Name(id=f"{model_name}Update", ctx=ast.Load()),
            args=[],
            keywords=[
                ast.keyword(
                    arg='filter',
                    value=ast.Call(
                        func=ast.Name(id=f"{model_name}UpdateFilter", ctx=ast.Load()),
                        args=[], keywords=filter_keywords
                    )
                ),
                ast.keyword(
                    arg='values',
                    value=ast.Call(
                        func=ast.Name(id=f"{model_name}UpdateValues", ctx=ast.Load()),
                        args=[], keywords=value_kwargs
                    )
                )
            ]
        )
        
        dao_call = self._make_dao_call(
            model_name, 'update_many',
            args=[],
            keywords=[
                ast.keyword(arg='payload', value=payload_call),
                *self._operative_keywords_for('update'),
            ]
        )

        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_delete_many(self, node, call):
        """t.delete_many(Model, **filters) → {Model}DAO(...).delete_many(filters_list=[{**filters}], session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        # Construir el dict de filtros desde keywords
        filter_keys = []
        filter_values = []
        for kw in call.keywords:
            filter_keys.append(ast.Constant(value=kw.arg))
            filter_values.append(kw.value)
        
        filters_dict = ast.Dict(keys=filter_keys, values=filter_values)
        filters_list = ast.List(elts=[filters_dict], ctx=ast.Load())
        
        dao_call = self._make_dao_call(
            model_name, 'delete_many',
            args=[],
            keywords=[ast.keyword(arg='filters_list', value=filters_list)]
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_find_many(self, node, call):
        """t.find_many(Model, limit=10, name='foo', includes=[...]) → {Model}DAO.find_many(limit=10, name='foo', includes=[...], session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        # Todos los kwargs se pasan directamente al DAO (limit, offset, order_by, order, includes, filtros)
        dao_call = self._make_dao_call(
            model_name, 'find_many',
            args=[],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_create_many(self, node, call):
        """t.create_many(Model, records) → {Model}DAO.create_many(records, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node
        
        records_arg = call.args[1]
        
        dao_call = self._make_dao_call(
            model_name, 'create_many',
            args=[records_arg],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_count(self, node, call):
        """t.count(Model, **filters) → {Model}DAO.count(**filters, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        dao_call = self._make_dao_call(
            model_name, 'count',
            args=[],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_exists(self, node, call):
        """t.exists(Model, **filters) → {Model}DAO.exists(**filters, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        dao_call = self._make_dao_call(
            model_name, 'exists',
            args=[],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_agg_simple(self, node, call, operation: str):
        """t.sum/mean/max/min(Model, agg_fields, **filters) → {Model}DAO.{op}(agg_fields, **filters, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node
        
        agg_fields = call.args[1]
        
        dao_call = self._make_dao_call(
            model_name, operation,
            args=[agg_fields],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_agg(self, node, call):
        """t.agg(Model, request, **filters) → {Model}DAO.agg(request, **filters, session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node
        
        request_arg = call.args[1]
        
        dao_call = self._make_dao_call(
            model_name, 'agg',
            args=[request_arg],
            keywords=list(call.keywords)
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_upsert(self, node, call):
        """t.upsert(Model, match_fields=[...], **data) → {Model}DAO.upsert({Model}Create(**data), match_fields=[...], session=session)"""
        model_name = self._get_model_name(call)
        if not model_name:
            return node
        
        # Separar match_fields de los datos
        match_fields_node = None
        data_kwargs = []
        for kw in call.keywords:
            if kw.arg == 'match_fields':
                match_fields_node = kw.value
            else:
                data_kwargs.append(kw)
        
        if match_fields_node is None:
            return node
        
        # Construir {Model}Create(**data)
        create_dto_call = ast.Call(
            func=ast.Name(id=f"{model_name}Create", ctx=ast.Load()),
            args=[],
            keywords=data_kwargs
        )
        
        dao_call = self._make_dao_call(
            model_name, 'upsert',
            args=[create_dto_call],
            keywords=[ast.keyword(arg='match_fields', value=match_fields_node)]
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)
    
    def _transform_cross_upsert_many(self, node, call):
        """t.upsert_many(Model, records, match_fields=[...]) → {Model}DAO.upsert_many(records, match_fields=[...], session=session)"""
        model_name = self._get_model_name(call)
        if not model_name or len(call.args) < 2:
            return node
        
        records_arg = call.args[1]
        
        # Extraer match_fields keyword
        keywords = []
        for kw in call.keywords:
            if kw.arg == 'match_fields':
                keywords.append(kw)
        
        dao_call = self._make_dao_call(
            model_name, 'upsert_many',
            args=[records_arg],
            keywords=keywords
        )
        
        return ast.copy_location(ast.Expr(value=dao_call), node)

    def _prepend_to_msg(self, prefix: str, msg_node):
        """Añade un prefijo a un nodo de mensaje (str, f-string o expresión)."""
        if isinstance(msg_node, ast.Constant) and isinstance(msg_node.value, str):
            return ast.Constant(value=prefix + msg_node.value)
        
        if isinstance(msg_node, ast.JoinedStr):
            # f-string: insertar prefijo y fusionar Constant adyacentes
            new_values = [ast.Constant(value=prefix)] + msg_node.values
            merged = []
            for v in new_values:
                if (merged and isinstance(merged[-1], ast.Constant) 
                    and isinstance(v, ast.Constant)
                    and isinstance(merged[-1].value, str) 
                    and isinstance(v.value, str)):
                    merged[-1] = ast.Constant(value=merged[-1].value + v.value)
                else:
                    merged.append(v)
            return ast.JoinedStr(values=merged)
        
        # Cualquier otra expresión → f"{prefix}{expr}"
        return ast.JoinedStr(values=[
            ast.Constant(value=prefix),
            ast.FormattedValue(value=msg_node, conversion=-1, format_spec=None)
        ])


class Trigger(AutoRegisterDescriptor):
    """
    Descriptor que representa un trigger definido en un modelo.
    
    Utiliza el protocolo de descriptores para auto-registrarse en el modelo
    cuando se asigna como atributo de clase.
    
    Attributes:
        name: Nombre del método trigger
        event: Tipo de evento ('create', 'update', 'delete')
        timing: Momento de ejecución ('before', 'after')
        priority: Orden de ejecución (menor número = mayor prioridad)
        fields: Lista de campos que activan el trigger (solo para UPDATE)
        when_lambda: Función lambda de condición (puede ser None)
        when_source: Código fuente de la lambda como string
        function: Función original del trigger
        source_code: Código fuente completo de la función
        ast_tree: Árbol AST de la función para análisis y transformación
        docstring: Documentación del trigger
        owner: Referencia al modelo Table al que pertenece
    """
    
    @property
    def collection_name(self) -> str:
        """Nombre de la colección en Table donde se almacenan los triggers"""
        return 'triggers'
    
    @property
    def registry_key(self) -> Optional[str]:
        """Clave del evento para registrar el trigger ('create', 'update', 'delete')"""
        return self.event
    
    def __init__(
        self,
        event: str,
        timing: str = 'before',
        priority: int = 1,
        fields: Optional[List[str]] = None,
        when_lambda: Optional[Callable] = None,
        when_source: Optional[str] = None,
        function: Optional[Callable] = None,
        source_code: Optional[str] = None,
        ast_tree: Optional[ast.FunctionDef] = None,
        docstring: Optional[str] = None
    ):
        """
        Inicializa un nuevo trigger.
        
        Args:
            event: Tipo de evento ('create', 'update', 'delete')
            timing: Momento de ejecución ('before' o 'after')
            priority: Orden de ejecución (menor número = mayor prioridad)
            fields: Lista de campos que activan el trigger (solo para UPDATE)
            when_lambda: Función lambda de condición
            when_source: Código fuente de la lambda
            function: Función original del trigger
            source_code: Código fuente completo de la función
            ast_tree: Árbol AST de la función
            docstring: Documentación del trigger
        """
        super().__init__()
        self.event = event
        self.timing = timing
        self.priority = priority
        self.fields = fields
        self.when_lambda = when_lambda
        self.when_source = when_source
        self.function = function
        self.source_code = source_code
        self.ast_tree = ast_tree
        self.docstring = docstring
        self.steps: List[TriggerStep] = []
        
        # Analizar el AST para extraer los steps
        if ast_tree is not None and source_code is not None:
            self._analyze_steps()
    
    def _analyze_steps(self) -> None:
        """
        Analiza el AST del trigger para extraer los steps basados en TriggerAPI.
        """
        if not self.ast_tree or not self.source_code:
            return
        
        # Obtener las líneas de código fuente
        source_lines = self.source_code.split('\n')
        
        # Crear el analizador y visitar el AST
        analyzer = TriggerAnalyzer(source_lines)
        analyzer.visit(self.ast_tree)
        
        # Guardar los steps encontrados
        self.steps = analyzer.steps
    
    def _initialize_collection(self, owner: Table):
        """
        Inicializa el diccionario de triggers con estructura anidada por evento.
        """
        # Obtener la colección actual (puede ser un dict vacío de __init_subclass__)
        current = getattr(owner, self.collection_name, None)
        
        # Si no tiene la estructura correcta (con keys 'create', 'update', 'delete'), inicializar
        if not isinstance(current, dict) or 'create' not in current:
            setattr(owner, self.collection_name, {
                'create': [],
                'update': [],
                'delete': []
            })
    
    def __get__(self, instance, owner: Table):
        """
        Protocolo de descriptores: retorna la función original cuando se accede al trigger.
        
        Args:
            instance: La instancia desde la que se accede (None si es desde la clase)
            owner: La clase propietaria
        
        Returns:
            El trigger mismo si se accede desde la clase,
            o la función bound si se accede desde una instancia
        """
        if instance is None:
            return self
        return self.function.__get__(instance, owner)
    
    def _get_transformed_body(self, mode: str = 'sync', operative_str_fields: List[str] = [], tablename: str = 'instance') -> str:
        """
        Extrae y transforma el cuerpo de la función trigger para inyección 
        directa en código generado.
        
        Utiliza TriggerCodeTransformer para reemplazar las referencias del
        TriggerAPI con variables locales explícitas del método CRUD:
        
            t.new        → new_<tablename> (create/update)
            t.old        → old_<tablename> (update/delete)
            self.field   → new_<tablename>.field (create/update) | old_<tablename>.field (delete)
            t.log(msg)   → logger.info("🔔 Trigger: ...")
            t.abort(msg) → raise ValueError("Trigger abortado: ...")
            t.update(Model, pk, **values) → {Model}DAO(...).update(...)
        
        Args:
            mode: Modo de generación ('sync' o 'async')
            operative_str_fields: Campos operativos de tipo str del modelo padre
            tablename: Nombre de la tabla del modelo, usado para nombrar variables
        
        Returns:
            Código Python transformado, listo para inyectar en la plantilla.
        """
        if not self.ast_tree or not self.source_code:
            return ""
        
        body = list(self.ast_tree.body)
        
        # Saltar docstring si existe
        if (body and isinstance(body[0], ast.Expr) and 
            isinstance(getattr(body[0], 'value', None), ast.Constant) and 
            isinstance(body[0].value.value, str)):
            body = body[1:]
        
        if not body:
            return ""
        
        # Obtener el nombre del parámetro TriggerAPI (segundo param después de self)
        trigger_param = 't'
        args = self.ast_tree.args.args
        if len(args) > 1:
            trigger_param = args[1].arg
        
        # Deep copy para evitar mutar el AST original entre llamadas (sync/async)
        body = copy.deepcopy(body)
        
        # Transformar el AST con variables locales explícitas
        module = ast.Module(body=body, type_ignores=[])
        transformer = TriggerCodeTransformer(trigger_param, self.event, mode, operative_str_fields, tablename)
        transformed = transformer.visit(module)
        ast.fix_missing_locations(transformed)
        
        return '\n'.join(ast.unparse(stmt) for stmt in transformed.body)
    
    def _get_transformed_when(self, mode: str = 'sync', tablename: str = 'instance') -> Optional[str]:
        """
        Transforma la condición 'when' del trigger para uso en código generado.
        
        Aplica las mismas transformaciones de variables que _get_transformed_body.
        
        Args:
            mode: Modo de generación ('sync' o 'async')
            tablename: Nombre de la tabla del modelo, usado para nombrar variables
        
        Returns:
            Expresión Python transformada o None si no hay condición.
        """
        if not self.when_source:
            return None
        
        trigger_param = 't'
        if self.ast_tree:
            args = self.ast_tree.args.args
            if len(args) > 1:
                trigger_param = args[1].arg
        
        when = self.when_source.strip()
        
        try:
            tree = ast.parse(when, mode='eval')
            transformer = TriggerCodeTransformer(trigger_param, self.event, mode, tablename=tablename)
            transformed = transformer.visit(tree)
            ast.fix_missing_locations(transformed)
            return ast.unparse(transformed.body)
        except SyntaxError:
            # Fallback: reemplazo simple por regex
            import re
            return re.sub(rf'\b{re.escape(trigger_param)}\.', '', when)
    
    def info(self, mode: str = 'sync', operative_str_fields: List[str] = [], tablename: str = 'instance') -> Dict[str, Any]:
        """
        Devuelve un diccionario con la información del trigger.

        Args:
            mode: Modo de generación ('sync' o 'async')
            operative_str_fields: Nombres de columnas operativas de tipo str del modelo padre.
                Se propagan a las llamadas cross-table generadas (create/update) para que
                el DAO destino reciba created_by / updated_by del contexto actual.
            tablename: Nombre de la tabla del modelo, usado para nombrar variables
                en el código generado (e.g. 'usuario' → new_usuario, old_usuario).
        """
        return {
            'name': self.name,
            'event': self.event,
            'timing': self.timing,
            'priority': self.priority,
            'fields': self.fields,
            'when_source': self.when_source,
            'docstring': self.docstring,
            'has_condition': self.when_lambda is not None,
            'steps': [step.to_dict() for step in self.steps],
            'steps_count': len(self.steps),
            'body': self._get_transformed_body(mode, operative_str_fields, tablename),
            'transformed_when': self._get_transformed_when(mode, tablename),
            'cross_table_ops': {
                step.operation for step in self.steps
                if step.step_type == 'crud_call'
            },
            'cross_table_targets': {
                step.target.split(' -> ')[0] for step in self.steps
                if step.step_type == 'crud_call' and step.target
            },
        }
    
    def __repr__(self) -> str:
        """Representación en string del trigger"""
        return f"<Trigger {self.name}({self.event}, {self.timing}, priority={self.priority})>"


def on_create(
    timing: str = 'before',
    priority: int = 1,
    when: Optional[Callable[[TriggerAPI], bool]] = None
):
    """
    Decorador para definir triggers de create.
    
    Los triggers de create se ejecutan cuando se crea un nuevo registro.
    
    Args:
        timing: Momento de ejecución:
            - 'before': Antes de insertar el registro (puede modificar datos)
            - 'after': Después de insertar el registro (acceso a instance.id)
        priority: Orden de ejecución cuando hay múltiples triggers (menor = primero)
        when: Lambda opcional con condición. Si retorna False, no se ejecuta el trigger
    
    Returns:
        Decorador que marca el método como trigger de create
    
    Example:
        ```python
        @on_create(timing='before', priority=1)
        def normalize_email(self, t: TriggerAPI):
            '''Normaliza el email antes de insertar'''
            t.data['email'] = t.data['email'].lower().strip()
        
        @on_create(timing='after', priority=2)
        def create_profile(self, t: TriggerAPI):
            '''Crea perfil automáticamente'''
            t.dao(Profile).create(user_id=t.instance.id)
        
        @on_create(
            timing='before',
            when=lambda t: '@' not in t.data.get('email', '')
        )
        def validate_email(self, t: TriggerAPI):
            '''Valida formato de email'''
            t.abort("Email inválido")
        ```
    
    Note:
        - En triggers 'before' de create, t.instance no está disponible
        - En triggers 'after' de create, t.instance contiene el registro creado con su ID
    """
    def decorator(func: Callable) -> Callable:
        # Extraer código fuente y AST
        try:
            source = inspect.getsource(func)
            # Limpiar indentación para parsing
            source = textwrap.dedent(source)
            tree = ast.parse(source)
            func_ast = tree.body[0]
        except Exception as e:
            raise RuntimeError(f"No se pudo extraer el código fuente del trigger '{func.__name__}': {e}")
        
        # Validar referencias inválidas (t.old no está disponible en on_create)
        _validate_trigger_references('create', func_ast, func.__name__)
        
        # Extraer código fuente de la lambda 'when' desde el AST del decorador
        when_source = None
        if when is not None:
            when_source = _extract_when_source_from_ast(func_ast)
            if when_source is None:
                # Fallback: intentar inspect.getsource
                try:
                    raw = inspect.getsource(when).strip()
                    if 'lambda' in raw:
                        raw = raw.split('lambda', 1)[1].strip()
                        colon_idx = raw.find(':')
                        if colon_idx != -1:
                            raw = raw[colon_idx + 1:].strip()
                    when_source = raw
                except Exception:
                    when_source = str(when)
        
        # Crear y retornar el objeto Trigger como descriptor
        # El descriptor se auto-registrará cuando se asigne a la clase
        trigger = Trigger(
            event='create',
            timing=timing,
            priority=priority,
            fields=None,
            when_lambda=when,
            when_source=when_source,
            function=func,
            source_code=source,
            ast_tree=func_ast,
            docstring=func.__doc__
        )
        
        return trigger
    return decorator


def on_update(
    timing: str = 'before',
    priority: int = 1,
    fields: Optional[List[str]] = None,
    when: Optional[Callable[[TriggerAPI], bool]] = None
):
    """
    Decorador para definir triggers de UPDATE.
    
    Los triggers de UPDATE se ejecutan cuando se actualiza un registro existente.
    
    Args:
        timing: Momento de ejecución:
            - 'before': Antes de actualizar (puede modificar datos)
            - 'after': Después de actualizar (cambios ya persistidos)
        priority: Orden de ejecución cuando hay múltiples triggers (menor = primero)
        fields: Lista de campos que activan el trigger. Si None, se ejecuta siempre
        when: Lambda opcional con condición. Recibe TriggerAPI y retorna bool
    
    Returns:
        Decorador que marca el método como trigger de UPDATE
    
    Example:
        ```python
        # Ejecutar en cualquier update
        @on_update(timing='before')
        def update_modified_at(self, t: TriggerAPI):
            '''Actualiza timestamp de modificación'''
            t.data['modified_at'] = datetime.now()
        
        # Solo cuando cambian campos específicos
        @on_update(timing='after', fields=['status'])
        def log_status_change(self, t: TriggerAPI):
            '''Registra cambios de estado'''
            t.log(f"Estado: {t.old['status']} -> {t.new['status']}")
        
        # Con condición compleja
        @on_update(
            timing='before',
            fields=['status'],
            when=lambda t: t.old['status'] == 'active' and t.new['status'] == 'inactive'
        )
        def archive_on_deactivate(self, t: TriggerAPI):
            '''Archiva datos cuando se desactiva'''
            t.dao(Post).update_many(
                filters={'author_id': t.instance.id},
                archived=True
            )
        ```
    
    Note:
        - t.old contiene los valores antes del update
        - t.new (alias de t.data) contiene los valores nuevos
        - t.instance está disponible en ambos timings
    """
    def decorator(func: Callable) -> Callable:
        try:
            source = inspect.getsource(func)
            import textwrap
            source = textwrap.dedent(source)
            tree = ast.parse(source)
            func_ast = tree.body[0]
        except Exception as e:
            raise RuntimeError(f"No se pudo extraer el código fuente del trigger '{func.__name__}': {e}")
        
        # on_update permite tanto t.old como t.new — no necesita validación
        
        when_source = None
        if when is not None:
            when_source = _extract_when_source_from_ast(func_ast)
            if when_source is None:
                try:
                    raw = inspect.getsource(when).strip()
                    if 'lambda' in raw:
                        raw = raw.split('lambda', 1)[1].strip()
                        colon_idx = raw.find(':')
                        if colon_idx != -1:
                            raw = raw[colon_idx + 1:].strip()
                    when_source = raw
                except Exception:
                    when_source = str(when)
        
        trigger = Trigger(
            event='update',
            timing=timing,
            priority=priority,
            fields=fields,
            when_lambda=when,
            when_source=when_source,
            function=func,
            source_code=source,
            ast_tree=func_ast,
            docstring=func.__doc__
        )
        
        return trigger
    return decorator


def on_delete(
    timing: str = 'before',
    priority: int = 1,
    when: Optional[Callable[[TriggerAPI], bool]] = None
):
    """
    Decorador para definir triggers de DELETE.
    
    Los triggers de DELETE se ejecutan cuando se elimina un registro.
    
    Args:
        timing: Momento de ejecución:
            - 'before': Antes de eliminar (puede hacer operaciones con el registro)
            - 'after': Después de eliminar (registro ya no existe en DB)
        priority: Orden de ejecución cuando hay múltiples triggers (menor = primero)
        when: Lambda opcional con condición. Recibe TriggerAPI y retorna bool
    
    Returns:
        Decorador que marca el método como trigger de DELETE
    
    Example:
        ```python
        @on_delete(timing='before', priority=1)
        def cascade_delete_posts(self, t: TriggerAPI):
            '''Elimina posts relacionados'''
            deleted = t.dao(Post).delete_many(
                filters={'author_id': t.instance.id}
            )
            t.log(f"Eliminados {deleted} posts del usuario {t.instance.id}")
        
        @on_delete(timing='before', priority=2)
        def archive_before_delete(self, t: TriggerAPI):
            '''Archiva datos antes de eliminar'''
            t.dao(Archive).create(
                table='usuario',
                record_id=t.instance.id,
                data=t.instance.to_dict()
            )
        
        @on_delete(
            timing='after',
            when=lambda t: t.old['is_premium']
        )
        def notify_premium_deletion(self, t: TriggerAPI):
            '''Notifica eliminación de usuario premium'''
            t.log(f"Usuario premium eliminado: {t.old['email']}", level='warning')
        ```
    
    Note:
        - t.instance está disponible en 'before'
        - En 'after', el registro ya no existe, usar t.old para acceder a valores
    """
    def decorator(func: Callable) -> Callable:
        try:
            source = inspect.getsource(func)
            import textwrap
            source = textwrap.dedent(source)
            tree = ast.parse(source)
            func_ast = tree.body[0]
        except Exception as e:
            raise RuntimeError(f"No se pudo extraer el código fuente del trigger '{func.__name__}': {e}")
        
        # Validar referencias inválidas (t.new no está disponible en on_delete)
        _validate_trigger_references('delete', func_ast, func.__name__)
        
        when_source = None
        if when is not None:
            when_source = _extract_when_source_from_ast(func_ast)
            if when_source is None:
                try:
                    raw = inspect.getsource(when).strip()
                    if 'lambda' in raw:
                        raw = raw.split('lambda', 1)[1].strip()
                        colon_idx = raw.find(':')
                        if colon_idx != -1:
                            raw = raw[colon_idx + 1:].strip()
                    when_source = raw
                except Exception:
                    when_source = str(when)
        
        trigger = Trigger(
            event='delete',
            timing=timing,
            priority=priority,
            fields=None,
            when_lambda=when,
            when_source=when_source,
            function=func,
            source_code=source,
            ast_tree=func_ast,
            docstring=func.__doc__
        )
        
        return trigger
    return decorator
