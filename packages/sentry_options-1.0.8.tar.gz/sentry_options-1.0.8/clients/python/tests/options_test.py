"""Tests for sentry-options Python client."""
from __future__ import annotations

import pytest
from sentry_options import init
from sentry_options import NotInitializedError
from sentry_options import options
from sentry_options import OptionsError
from sentry_options import SchemaError
from sentry_options import UnknownNamespaceError
from sentry_options import UnknownOptionError


def test_get_string_from_values() -> None:
    value = options('sentry-options-testing').get('example-option')
    assert value == 'wow'
    assert isinstance(value, str)


def test_get_int_from_values() -> None:
    value = options('sentry-options-testing').get('int-option')
    assert value == 123
    assert isinstance(value, int)


def test_get_float_from_values() -> None:
    value = options('sentry-options-testing').get('float-option')
    assert value == 1.2
    assert isinstance(value, float)


def test_get_bool_from_values() -> None:
    value = options('sentry-options-testing').get('bool-option')
    assert value is False
    assert isinstance(value, bool)


def test_get_array_default() -> None:
    value = options('sentry-options-testing').get('array-option')
    assert value == [1, 2, 3]
    assert isinstance(value, list)


def test_get_object_default() -> None:
    value = options('sentry-options-testing').get('object-option')
    assert value == {'host': 'localhost', 'port': 8080}
    assert isinstance(value, dict)
    assert isinstance(value['host'], str)
    assert isinstance(value['port'], int)


def test_get_array_of_objects_default() -> None:
    value = options('sentry-options-testing').get('endpoints-option')
    assert value == []
    assert isinstance(value, list)


def test_unknown_namespace() -> None:
    with pytest.raises(UnknownNamespaceError, match='nonexistent'):
        options('nonexistent').get('any-key')


def test_unknown_option() -> None:
    with pytest.raises(UnknownOptionError, match='bad-key'):
        options('sentry-options-testing').get('bad-key')


def test_double_init() -> None:
    # init() should be idempotent — no error on second call
    init()


def test_exceptions_inherit_from_options_error() -> None:
    assert issubclass(SchemaError, OptionsError)
    assert issubclass(UnknownNamespaceError, OptionsError)
    assert issubclass(UnknownOptionError, OptionsError)
    assert issubclass(NotInitializedError, OptionsError)


def test_isset() -> None:
    with pytest.raises(UnknownNamespaceError):
        options('unknown').isset('unknown')

    with pytest.raises(UnknownOptionError):
        options('sentry-options-testing').isset('unknown')

    # string-option is not in values.json, so it uses the schema default
    assert not options('sentry-options-testing').isset('string-option')
    # example-option is explicitly set in values.json
    assert options('sentry-options-testing').isset('example-option')
