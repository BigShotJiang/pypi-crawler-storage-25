DEFAULT_BASE_URL = "https://api.laminalabs.ai"
