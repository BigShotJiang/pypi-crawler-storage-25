from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

@dataclass(slots=True)
class JobState:
    job_id: str
    status: str
    project_id: str | None = None
    model: str = "simi"
    progress: float = 0.0
    message: str = ""
    prompt: str = ""
    duration: int = 20
    quality: str = "fast"
    video_url: str | None = None
    error: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "JobState":
        job_id = payload.get("job_id") or payload.get("jobId")
        if job_id is None:
            raise KeyError("job_id")
        return cls(
            job_id=str(job_id),
            project_id=str(payload.get("project_id") or payload.get("projectId")) if payload.get("project_id") or payload.get("projectId") else None,
            model=str(payload.get("model", "simi")),
            status=str(payload.get("status", "queued")),
            progress=float(payload.get("progress", 0.0)),
            message=str(payload.get("message", "")),
            prompt=str(payload.get("prompt", "")),
            duration=int(payload.get("duration", 20)),
            quality=str(payload.get("quality", "fast")),
            video_url=payload.get("video_url") or payload.get("videoUrl"),
            error=payload.get("error"),
        )

    @property
    def is_complete(self) -> bool:
        return self.status in {"complete", "completed"}

    @property
    def is_error(self) -> bool:
        return self.status in {"error", "failed"}

    @property
    def is_terminal(self) -> bool:
        return self.status in {"complete", "completed", "error", "failed", "cancelled"}


@dataclass(slots=True)
class JobPlayback:
    job_id: str
    src: str
    live: bool = False
    stream_src: str | None = None
    stream_content_type: str | None = None
    stream_available: bool = False
    handoff_at_sec: float | None = None
    src_content_type: str = "video/mp4"
    src_available: bool = False
    expires_at: str = ""

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "JobPlayback":
        job_id = payload.get("job_id") or payload.get("jobId")
        if job_id is None:
            raise KeyError("job_id")
        src = payload.get("src")
        if src is None:
            raise KeyError("src")
        return cls(
            job_id=str(job_id),
            src=str(src),
            live=bool(payload.get("live", False)),
            stream_src=payload.get("stream_src") or payload.get("streamSrc"),
            stream_content_type=payload.get("stream_content_type") or payload.get("streamContentType"),
            stream_available=bool(payload.get("stream_available", payload.get("streamAvailable", False))),
            handoff_at_sec=float(payload["handoff_at_sec"]) if payload.get("handoff_at_sec") is not None else (
                float(payload["handoffAtSec"]) if payload.get("handoffAtSec") is not None else None
            ),
            src_content_type=str(payload.get("src_content_type") or payload.get("srcContentType") or "video/mp4"),
            src_available=bool(payload.get("src_available", payload.get("srcAvailable", False))),
            expires_at=str(payload.get("expires_at") or payload.get("expiresAt") or ""),
        )

    @property
    def is_ready(self) -> bool:
        return self.src_available


@dataclass(slots=True)
class StreamSessionInfo:
    session_id: str
    token: str
    websocket_url: str
    expires_at: str

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "StreamSessionInfo":
        session_id = payload.get("session_id") or payload.get("sessionId")
        websocket_url = payload.get("websocket_url") or payload.get("websocketUrl")
        expires_at = payload.get("expires_at") or payload.get("expiresAt")
        token = payload.get("token")
        if session_id is None:
            raise KeyError("session_id")
        if websocket_url is None:
            raise KeyError("websocket_url")
        if expires_at is None:
            raise KeyError("expires_at")
        if token is None:
            raise KeyError("token")
        return cls(
            session_id=str(session_id),
            token=str(token),
            websocket_url=str(websocket_url),
            expires_at=str(expires_at),
        )


@dataclass(slots=True)
class StreamEvent:
    id: str
    type: str
    ts: str
    sequence: int
    job_id: str | None = None
    org_id: str | None = None
    session_id: str | None = None
    payload: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "StreamEvent":
        event_id = payload.get("id")
        event_type = payload.get("type")
        ts = payload.get("ts")
        if event_id is None:
            raise KeyError("id")
        if event_type is None:
            raise KeyError("type")
        if ts is None:
            raise KeyError("ts")
        return cls(
            id=str(event_id),
            type=str(event_type),
            ts=str(ts),
            sequence=int(payload.get("sequence", 0)),
            job_id=payload.get("job_id") or payload.get("jobId"),
            org_id=payload.get("org_id") or payload.get("orgId"),
            session_id=payload.get("session_id") or payload.get("sessionId"),
            payload=dict(payload.get("payload") or {}),
        )
