from __future__ import annotations

import asyncio
import json
import inspect
import struct
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlsplit, urlunsplit

from PIL import Image

from .errors import LaminaAPIError, LaminaDownloadError, LaminaStreamError
from .models import JobPlayback, StreamEvent, StreamSessionInfo


class HTTPTransport:
    def __init__(
        self,
        *,
        base_url: str,
        request_timeout: float,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.request_timeout = request_timeout
        self.headers = headers or {}
        self._sync_client: Any | None = None
        self._async_client: Any | None = None
        self._async_clients: dict[int, Any] = {}

    def _sync(self):
        if self._sync_client is None:
            import httpx

            self._sync_client = httpx.Client(
                base_url=self.base_url,
                timeout=self.request_timeout,
                headers=self.headers,
            )
        return self._sync_client

    async def _async(self):
        if self._async_client is not None:
            return self._async_client

        loop = asyncio.get_running_loop()
        key = id(loop)
        client = self._async_clients.get(key)
        if client is None:
            import httpx

            client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.request_timeout,
                headers=self.headers,
            )
            self._async_clients[key] = client
        return client

    def submit_sync(
        self,
        prompt: str,
        *,
        duration: int,
        project_id: str | None = None,
        asset_ids: list[str] | None = None,
    ) -> dict:
        try:
            response = self._sync().post(
                "/v1/jobs",
                json={
                    "prompt": prompt,
                    "project_id": project_id,
                    "asset_ids": asset_ids or [],
                    "options": _job_options(
                        duration=duration,
                    ),
                },
            )
            response.raise_for_status()
            return _unwrap_data(response.json())
        except Exception as exc:
            raise LaminaAPIError("Failed to submit job") from exc

    async def submit_async(
        self,
        prompt: str,
        *,
        duration: int,
        project_id: str | None = None,
        asset_ids: list[str] | None = None,
    ) -> dict:
        try:
            client = await self._async()
            response = await client.post(
                "/v1/jobs",
                json={
                    "prompt": prompt,
                    "project_id": project_id,
                    "asset_ids": asset_ids or [],
                    "options": _job_options(
                        duration=duration,
                    ),
                },
            )
            response.raise_for_status()
            return _unwrap_data(response.json())
        except Exception as exc:
            raise LaminaAPIError("Failed to submit job") from exc

    async def get_job(self, job_id: str) -> dict:
        try:
            client = await self._async()
            response = await client.get(f"/v1/jobs/{job_id}")
            response.raise_for_status()
            return _unwrap_data(response.json())
        except Exception as exc:
            raise LaminaAPIError(f"Failed to fetch job {job_id}") from exc

    async def get_job_playback(self, job_id: str) -> JobPlayback:
        try:
            client = await self._async()
            response = await client.get(f"/v1/jobs/{job_id}/video")
            response.raise_for_status()
            return JobPlayback.from_payload(_unwrap_data(response.json()))
        except Exception as exc:
            raise LaminaAPIError(f"Failed to fetch playback for job {job_id}") from exc

    async def list_jobs(self, *, limit: int = 20, cursor: str | None = None, status: str | None = None) -> dict:
        try:
            client = await self._async()
            params: dict[str, Any] = {"limit": limit}
            if cursor is not None:
                params["cursor"] = cursor
            if status is not None:
                params["status"] = status
            response = await client.get("/v1/jobs", params=params)
            response.raise_for_status()
            return _unwrap_data(response.json())
        except Exception as exc:
            raise LaminaAPIError("Failed to list jobs") from exc

    async def cancel_job(self, job_id: str) -> dict:
        try:
            client = await self._async()
            response = await client.post(f"/v1/jobs/{job_id}/cancel")
            response.raise_for_status()
            return _unwrap_data(response.json())
        except Exception as exc:
            raise LaminaAPIError(f"Failed to cancel job {job_id}") from exc

    async def create_stream_session(
        self,
        job_id: str,
        *,
        project_id: str | None = None,
        subscriptions: list[str] | None = None,
    ) -> StreamSessionInfo:
        try:
            client = await self._async()
            response = await client.post(
                "/v1/stream-sessions",
                json={
                    "job_id": job_id,
                    "project_id": project_id,
                    "subscriptions": subscriptions
                    or [
                        "scene.chunk",
                        "audio.chunk",
                        "progress.updated",
                        "output.ready",
                        "job.completed",
                        "job.failed",
                        "job.cancelled",
                    ],
                },
            )
            response.raise_for_status()
            return StreamSessionInfo.from_payload(_unwrap_data(response.json()))
        except Exception as exc:
            raise LaminaAPIError(f"Failed to create stream session for job {job_id}") from exc

    async def download_video(self, job_id: str, destination: Path) -> None:
        try:
            client = await self._async()
            playback = await self.get_job_playback(job_id)
            if not playback.src_available:
                raise LaminaDownloadError(f"Video for job {job_id} is not ready")
            destination.parent.mkdir(parents=True, exist_ok=True)
            async with client.stream("GET", _resolve_url(self.base_url, playback.src)) as response:
                response.raise_for_status()
                with destination.open("wb") as handle:
                    async for chunk in response.aiter_bytes():
                        if chunk:
                            handle.write(chunk)
        except Exception as exc:
            raise LaminaDownloadError(f"Failed to download video for job {job_id}") from exc

    async def iter_events(self, session_id: str, token: str, websocket_url: str | None = None):
        import websockets

        url = websocket_url or _to_ws_url(
            self.base_url, f"/v1/ws?session_id={session_id}&token={token}"
        )
        try:
            connect_kwargs: dict[str, Any] = {
                "open_timeout": self.request_timeout,
                "max_size": None,
            }
            header_arg = _websocket_header_argument(websockets.connect)
            if header_arg is not None and self.headers:
                connect_kwargs[header_arg] = self.headers

            websocket_context = websockets.connect(url, **connect_kwargs)

            async with websocket_context as websocket:
                async for message in websocket:
                    payload = _parse_ws_message(message)
                    event = StreamEvent.from_payload(payload)
                    yield event
                    if event.type in {"job.completed", "job.failed", "job.cancelled"}:
                        return
        except LaminaStreamError:
            raise
        except Exception as exc:
            raise LaminaStreamError(f"Failed to stream events for session {session_id}") from exc

    def close(self) -> None:
        if self._sync_client is not None:
            self._sync_client.close()
            self._sync_client = None

    async def aclose(self) -> None:
        self.close()
        if self._async_client is not None:
            await self._async_client.aclose()
            self._async_client = None
        clients = list(self._async_clients.values())
        self._async_clients.clear()
        for client in clients:
            await client.aclose()


def _to_ws_url(base_url: str, path: str) -> str:
    parts = urlsplit(base_url)
    scheme = "wss" if parts.scheme == "https" else "ws"
    return urlunsplit((scheme, parts.netloc, path, "", ""))


def _resolve_url(base_url: str, url: str) -> str:
    if "://" in url:
        return url
    return urljoin(base_url.rstrip("/") + "/", url.lstrip("/"))


def _unwrap_data(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _job_options(
    *,
    duration: int,
) -> dict[str, Any]:
    return {
        key: value
        for key, value in {
            "duration_seconds": duration,
        }.items()
        if value is not None
    }


def _parse_ws_message(message: Any) -> dict[str, Any]:
    if isinstance(message, str):
        payload = json.loads(message)
        if isinstance(payload, dict):
            return payload
        raise LaminaStreamError("WebSocket message must decode to a JSON object")
    if isinstance(message, bytes):
        payload = json.loads(message.decode("utf-8"))
        if isinstance(payload, dict):
            return payload
        raise LaminaStreamError("WebSocket message must decode to a JSON object")
    raise LaminaStreamError("Unsupported WebSocket message type")


def _websocket_header_argument(connect: Any) -> str | None:
    try:
        parameters = inspect.signature(connect).parameters
    except (TypeError, ValueError):
        return "additional_headers"

    if "additional_headers" in parameters:
        return "additional_headers"
    if "extra_headers" in parameters:
        return "extra_headers"
    return None


def _decode_image(payload: bytes) -> Image.Image:
    if len(payload) < 4:
        raise LaminaStreamError("Image stream payload too small")
    header_size = struct.unpack(">I", payload[:4])[0]
    header_end = 4 + header_size
    if len(payload) <= header_end:
        raise LaminaStreamError("Image stream payload missing image bytes")
    header = json.loads(payload[4:header_end].decode("utf-8"))
    if header.get("type") != "frame":
        raise LaminaStreamError("Unsupported image stream payload")
    image = Image.open(BytesIO(payload[header_end:]))
    return image.convert("RGB")
