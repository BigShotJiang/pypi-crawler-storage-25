from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from .client import Lamina
    from .models import JobPlayback, StreamEvent


class LaminaJob:
    def __init__(
        self,
        *,
        client: "Lamina",
        job_id: str,
        prompt: str,
        status: str,
        project_id: str | None = None,
        model: str = "simi",
    ) -> None:
        self._client = client
        self.id = job_id
        self.project_id = project_id
        self.model = model
        self.prompt = prompt
        self._initial_status = status

    @property
    def status(self) -> str:
        state = self._client.get_cached_job_state(self.id)
        if state is None:
            return self._initial_status
        return state.status

    def onstream(self, callback: Callable[["StreamEvent"], None]) -> "LaminaJob":
        self._client.register_stream_callback(self, callback)
        return self

    def oncompletion(self, callback: Callable[["LaminaVideo"], None]) -> "LaminaJob":
        self._client.register_completion_callback(self, callback)
        return self

    async def wait(self) -> "LaminaVideo":
        return await self._client.wait(self)

    async def playback(self) -> "JobPlayback":
        return await self._client.get_playback(self)


class LaminaVideo:
    def __init__(self, *, client: "Lamina", job_id: str) -> None:
        self._client = client
        self.job_id = job_id

    async def save(self, path: str | Path) -> Path:
        return await self._client.save(self, path)

    async def playback(self) -> "JobPlayback":
        return await self._client.get_playback(self)
