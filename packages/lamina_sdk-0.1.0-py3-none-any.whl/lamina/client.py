from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import os
from pathlib import Path
from typing import Any, AsyncIterator, Callable

from ._background import BackgroundLoop, StreamHub
from ._constants import DEFAULT_BASE_URL
from ._transport import HTTPTransport
from .errors import LaminaJobError
from .job import LaminaJob, LaminaVideo
from .models import JobPlayback, JobState, StreamEvent

logger = logging.getLogger(__name__)


class JobRuntime:
    def __init__(self, *, client: "Lamina", job_id: str, project_id: str | None) -> None:
        self._client = client
        self._job_id = job_id
        self._project_id = project_id
        self._completion_future: concurrent.futures.Future | None = None
        self.streams = StreamHub(
            job_id=job_id,
            project_id=project_id,
            transport=client._transport,
            background=client._background,
            retries=client.stream_retries,
        )

    def add_completion_callback(self, callback: Callable[[LaminaVideo], None]) -> None:
        future = self._ensure_completion_future()

        def _deliver(done: concurrent.futures.Future) -> None:
            try:
                video = done.result()
            except Exception:
                return
            try:
                callback(video)
            except Exception:
                logger.exception("Lamina oncompletion callback failed for job %s", self._job_id)

        future.add_done_callback(_deliver)

    def _ensure_completion_future(self) -> concurrent.futures.Future:
        if self._completion_future is None:
            self._completion_future = self._client._background.submit(self._watch_completion())
        return self._completion_future

    async def wait(self) -> LaminaVideo:
        future = self._ensure_completion_future()
        return await asyncio.wrap_future(future)

    async def _watch_completion(self) -> LaminaVideo:
        while True:
            state = JobState.from_payload(await self._client._transport.get_job(self._job_id))
            self._client._cache_job_state(state)
            if state.is_complete:
                return LaminaVideo(client=self._client, job_id=self._job_id)
            if state.is_error:
                raise LaminaJobError(state.error or f"Job {self._job_id} failed")
            await asyncio.sleep(self._client.poll_interval)


class Lamina:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        poll_interval: float = 0.5,
        stream_retries: int = 2,
        request_timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        transport: Any | None = None,
    ) -> None:
        resolved_api_key = api_key or os.environ.get("LAMINA_API_KEY")
        if not resolved_api_key:
            raise ValueError("api_key is required. Pass api_key or set LAMINA_API_KEY.")

        self.base_url = base_url.rstrip("/")
        self.api_key = resolved_api_key
        self.poll_interval = poll_interval
        self.stream_retries = stream_retries
        transport_headers = dict(headers or {})
        transport_headers["x-api-key"] = resolved_api_key
        self._background = BackgroundLoop()
        self._transport = transport or HTTPTransport(
            base_url=self.base_url,
            request_timeout=request_timeout,
            headers=transport_headers,
        )
        self._job_states: dict[str, JobState] = {}
        self._runtimes: dict[str, JobRuntime] = {}

    def submit(
        self,
        prompt: str,
        *,
        duration: int = 20,
        project_id: str | None = None,
        asset_ids: list[str] | None = None,
    ) -> LaminaJob:
        state = JobState.from_payload(
            self._transport.submit_sync(
                prompt,
                duration=duration,
                project_id=project_id,
                asset_ids=asset_ids,
            )
        )
        return self._job_from_state(state, prompt=prompt)

    async def submit_async(
        self,
        prompt: str,
        *,
        duration: int = 20,
        project_id: str | None = None,
        asset_ids: list[str] | None = None,
    ) -> LaminaJob:
        state = JobState.from_payload(
            await self._transport.submit_async(
                prompt,
                duration=duration,
                project_id=project_id,
                asset_ids=asset_ids,
            )
        )
        return self._job_from_state(state, prompt=prompt)

    async def generate(
        self,
        prompt: str,
        *,
        duration: int = 20,
        project_id: str | None = None,
        asset_ids: list[str] | None = None,
    ) -> LaminaVideo:
        job = await self.submit_async(
            prompt,
            duration=duration,
            project_id=project_id,
            asset_ids=asset_ids,
        )
        return await job.wait()

    async def get_playback(self, job_or_video_or_id: LaminaJob | LaminaVideo | str) -> JobPlayback:
        if isinstance(job_or_video_or_id, str):
            job_id = job_or_video_or_id
        elif isinstance(job_or_video_or_id, LaminaJob):
            job_id = job_or_video_or_id.id
        else:
            job_id = job_or_video_or_id.job_id
        return await self._transport.get_job_playback(job_id)

    async def wait(self, job: LaminaJob) -> LaminaVideo:
        runtime = self._get_runtime(job.id)
        return await runtime.wait()

    async def frame_streamer(self, job: LaminaJob) -> AsyncIterator[StreamEvent]:
        runtime = self._get_runtime(job.id)
        subscriber = runtime.streams.subscribe()
        try:
            while True:
                item = await asyncio.to_thread(subscriber.get)
                if item.end:
                    if item.error is not None:
                        raise item.error
                    return
                yield item.event
        finally:
            runtime.streams.unsubscribe(subscriber)

    def register_stream_callback(self, job: LaminaJob, callback: Callable[[StreamEvent], None]) -> None:
        runtime = self._get_runtime(job.id)
        runtime.streams.add_callback(callback)

    def register_completion_callback(self, job: LaminaJob, callback: Callable[[LaminaVideo], None]) -> None:
        runtime = self._get_runtime(job.id)
        runtime.add_completion_callback(callback)

    async def stream_events(self, job: LaminaJob) -> AsyncIterator[StreamEvent]:
        async for event in self.frame_streamer(job):
            yield event

    async def save(self, job_or_video: LaminaJob | LaminaVideo, path: str | Path) -> Path:
        destination = Path(path)
        if isinstance(job_or_video, LaminaJob):
            video = await job_or_video.wait()
        else:
            video = job_or_video
        await self._transport.download_video(video.job_id, destination)
        return destination

    def get_cached_job_state(self, job_id: str) -> JobState | None:
        return self._job_states.get(job_id)

    def _cache_job_state(self, state: JobState) -> None:
        self._job_states[state.job_id] = state

    def _job_from_state(self, state: JobState, *, prompt: str) -> LaminaJob:
        state.prompt = prompt
        self._cache_job_state(state)
        return LaminaJob(
            client=self,
            job_id=state.job_id,
            prompt=prompt,
            status=state.status,
            project_id=state.project_id,
            model=state.model,
        )

    def _get_runtime(self, job_id: str) -> JobRuntime:
        runtime = self._runtimes.get(job_id)
        if runtime is None:
            state = self.get_cached_job_state(job_id)
            runtime = JobRuntime(
                client=self,
                job_id=job_id,
                project_id=state.project_id if state is not None else None,
            )
            self._runtimes[job_id] = runtime
        return runtime

    def close(self) -> None:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self.aclose())
            return
        raise RuntimeError(
            "Lamina.close() cannot be used while an event loop is running; await lamina.aclose() instead"
        )

    async def aclose(self) -> None:
        try:
            aclose = getattr(self._transport, "aclose", None)
            if callable(aclose):
                await aclose()
            else:
                close = getattr(self._transport, "close", None)
                if callable(close):
                    close()
        finally:
            await self._background.aclose()

    async def __aenter__(self) -> "Lamina":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    def __enter__(self) -> "Lamina":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


simi = Lamina
