class LaminaError(Exception):
    """Base error for the Lamina SDK."""


class LaminaAPIError(LaminaError):
    """Raised when the API request/response contract fails."""


class LaminaJobError(LaminaError):
    """Raised when a job reaches an error state."""


class LaminaStreamError(LaminaError):
    """Raised when frame streaming fails."""


class LaminaDownloadError(LaminaError):
    """Raised when the final video download fails."""
