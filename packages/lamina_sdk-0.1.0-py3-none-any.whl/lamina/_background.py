from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import queue
import threading
from dataclasses import dataclass
from typing import Any, Callable

from .errors import LaminaStreamError
from .models import StreamEvent

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class QueueItem:
    event: StreamEvent | None = None
    error: BaseException | None = None
    end: bool = False


class BackgroundLoop:
    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._closed = False
        self._lock = threading.Lock()

    def submit(self, coroutine: Any) -> concurrent.futures.Future:
        loop = self._ensure_loop()
        return asyncio.run_coroutine_threadsafe(coroutine, loop)

    def _ensure_loop(self) -> asyncio.AbstractEventLoop:
        with self._lock:
            if self._closed:
                raise RuntimeError("Background loop is closed")
            if self._loop is not None:
                return self._loop
            self._thread = threading.Thread(target=self._run, name="lamina-background", daemon=True)
            self._thread.start()
        self._ready.wait()
        assert self._loop is not None
        return self._loop

    def _run(self) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._loop = loop
        self._ready.set()
        loop.run_forever()

        pending = asyncio.all_tasks(loop)
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.close()

    async def aclose(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            loop = self._loop
            thread = self._thread
        if loop is None or thread is None:
            return
        loop.call_soon_threadsafe(loop.stop)
        await asyncio.to_thread(thread.join)


class StreamHub:
    def __init__(
        self,
        *,
        job_id: str,
        project_id: str | None,
        transport: Any,
        background: BackgroundLoop,
        retries: int,
    ) -> None:
        self._job_id = job_id
        self._project_id = project_id
        self._transport = transport
        self._background = background
        self._retries = retries
        self._lock = threading.Lock()
        self._runner: concurrent.futures.Future | None = None
        self._callbacks: list[Callable[[StreamEvent], None]] = []
        self._subscribers: set[queue.Queue] = set()
        self._finished = False
        self._terminal_item: QueueItem | None = None

    def subscribe(self) -> queue.Queue:
        subscriber: queue.Queue = queue.Queue()
        with self._lock:
            terminal_item = self._terminal_item
            if terminal_item is None:
                self._subscribers.add(subscriber)
        if terminal_item is not None:
            subscriber.put(terminal_item)
            return subscriber
        self._ensure_started()
        return subscriber

    def unsubscribe(self, subscriber: queue.Queue) -> None:
        with self._lock:
            self._subscribers.discard(subscriber)

    def add_callback(self, callback: Callable[[StreamEvent], None]) -> None:
        with self._lock:
            self._callbacks.append(callback)
        self._ensure_started()

    def _ensure_started(self) -> None:
        with self._lock:
            if self._runner is not None:
                return
            self._runner = self._background.submit(self._run())

    async def _run(self) -> None:
        attempts = 0
        while True:
            try:
                session = await self._transport.create_stream_session(
                    self._job_id,
                    project_id=self._project_id,
                )
                async for event in self._transport.iter_events(session.session_id, session.token):
                    self._publish_event(event)
                    if event.type in {"job.completed", "job.failed", "job.cancelled"}:
                        self._finish()
                        return
                self._finish()
                return
            except Exception as exc:
                attempts += 1
                if attempts > self._retries:
                    stream_error = LaminaStreamError(f"Event streaming failed for job {self._job_id}")
                    stream_error.__cause__ = exc
                    self._finish(
                        QueueItem(
                            error=stream_error,
                            end=True,
                        )
                    )
                    return
                await asyncio.sleep(0.1)

    def _publish_event(self, event: StreamEvent) -> None:
        with self._lock:
            subscribers = list(self._subscribers)
            callbacks = list(self._callbacks)
        item = QueueItem(event=event, end=False)
        for subscriber in subscribers:
            subscriber.put(item)
        for callback in callbacks:
            try:
                callback(event)
            except Exception:
                logger.exception("Lamina onstream callback failed for job %s", self._job_id)

    def _finish(self, item: QueueItem | None = None) -> None:
        terminal_item = item or QueueItem(end=True)
        with self._lock:
            if self._finished:
                return
            self._finished = True
            self._terminal_item = terminal_item
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            subscriber.put(terminal_item)
