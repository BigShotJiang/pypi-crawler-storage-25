import os
import requests
from django.conf import settings


class GeocodeService:

    @staticmethod
    def get_full_details_by_query(query, language='en-GB', field_mask='addressComponents', request=None, api_key=None):
        # field_mask = 'addressComponents,formattedAddress,location'
        geocode_data = GeocodeService.get_address_by_query(query, language=language, request=request, api_key=api_key)

        if not geocode_data or geocode_data.get('status') != 'OK' or not geocode_data.get('results'):
            return None

        place_id = geocode_data['results'][0].get('place_id')

        if not place_id:
            return None

        return GeocodeService.get_address_by_place(
            place_id=place_id,
            language=language,
            field_mask=field_mask,
            request=request,
            api_key=api_key,
        )

    @staticmethod
    def get_autocomplete_v2(query, language='en-GB', request=None, api_key=None):
        api_key = api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        url = 'https://places.googleapis.com/v1/places:autocomplete'

        headers = {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': api_key
        }

        data = {
            'input': query,
            'languageCode': language,
        }

        response_json = None
        try:
            response = requests.post(url, json=data, headers=headers)
            response_json = response.json()
            response.raise_for_status()
            return response_json
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:autocomplete_v2': BaseUtils.log_response_error(locals().get('response'), e)})
                except Exception as e:
                    print(f"GeocodeService:autocomplete_v2 {e}")

        return response_json

    @staticmethod
    def get_autocomplete(query, language='en-GB', request=None, api_key=None):
        params = {
            'input': query,
            'language': language,
            'key': api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        }

        response_json = None
        try:
            response = requests.get('https://maps.googleapis.com/maps/api/place/autocomplete/json', params=params)
            response_json = response.json()
            response.raise_for_status()
            return response_json
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:autocomplete': BaseUtils.log_response_error(locals().get('response'), e)})
                except Exception as e:
                    print(f"GeocodeService:autocomplete {e}")

        return response_json

    @staticmethod
    def get_address_by_place(place_id, language='en-GB', field_mask='addressComponents', request=None, api_key=None):
        # field_mask = 'addressComponents,formattedAddress,location'

        if not place_id:
            return None

        api_key = api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        url = f'https://places.googleapis.com/v1/places/{place_id}'

        headers = {
            'Content-Type': 'application/json',
            'X-Goog-FieldMask': field_mask,
            'X-Goog-Api-Key': api_key
        }

        params = {'languageCode': language}

        response_json = None
        try:
            response = requests.get(url, headers=headers, params=params)
            response_json = response.json()
            response.raise_for_status()
            return response_json
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:address_by_place': BaseUtils.log_response_error(locals().get('places_res'), e)})
                except Exception as e:
                    print(f"GeocodeService:address_by_place {e}")

        return response_json

    @staticmethod
    def get_address_by_query(query, language='en-GB', request=None, api_key=None):
        params = {
            'address': query,
            'language': language,
            'key': api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        }

        response_json = None
        try:
            response = requests.get('https://maps.googleapis.com/maps/api/geocode/json', params=params)
            response_json = response.json()
            response.raise_for_status()
            return response_json
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:address_by_query': BaseUtils.log_response_error(locals().get('response'), e)})
                except Exception as e:
                    print(f"GeocodeService:address_by_query {e}")

        return response_json

    @staticmethod
    def get_address_by_latlng(latlng, language='en-GB', request=None, api_key=None):
        params = {
            'latlng': latlng,
            'language': language,
            'key': api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        }

        response_json = None
        try:
            response = requests.get('https://maps.googleapis.com/maps/api/geocode/json', params=params)
            response_json = response.json()
            response.raise_for_status()
            return response_json
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:address_by_latlng': BaseUtils.log_response_error(locals().get('response'), e)})
                except Exception as e:
                    print(f"GeocodeService:address_by_latlng {e}")

        return response_json

    @staticmethod
    def get_latlng_by_address(address, request=None, api_key=None):
        if not address:
            return {"lat": None, "lng": None}

        params = {
            'query': address,
            'key': api_key or getattr(settings, 'GOOGLE_GEOCODE_KEY', os.getenv('GOOGLE_GEOCODE_KEY', ''))
        }

        try:
            response = requests.get('https://maps.googleapis.com/maps/api/geocode/json', params=params)
            response.raise_for_status()
            response_data = response.json()

            if response_data.get('results'):
                location = response_data['results'][0]['geometry']['location']
                return {
                    "lat": location.get('lat'),
                    "lng": location.get('lng'),
                }
        except requests.exceptions.RequestException as e:
            if request is not None:
                try:
                    from libsv1.apps.global_system_log.services import GlobalSystemLogAdd
                    from libsv1.utils.base import BaseUtils
                    GlobalSystemLogAdd(request=request, additional_log={'GeocodeService:latlng_by_address': BaseUtils.log_response_error(locals().get('response'), e)})
                except Exception as e:
                    print(f"GeocodeService:latlng_by_address {e}")

        return {"lat": None, "lng": None}
