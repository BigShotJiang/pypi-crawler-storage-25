def build_flex_fields(schema: dict) -> dict:
    """
    Example:
        user = UserSerializer(**build_flex_fields({
           '': F_User.FULL,
           'orders': F_Order.FULL,
           'orders.order_products': F_OrderProduct.FULL,
        }))
    Result:
        {'expand': ['orders', 'orders.order_products'], 'fields': ['id', 'email', 'orders.id', ...]}
    """

    expand = []
    fields = []

    for prefix, field_list in schema.items():
        if prefix:
            expand.append(prefix)
            fields.extend([f"{prefix}.{f}" for f in field_list])
        else:
            fields.extend(field_list)

    return {
        "expand": expand,
        "fields": fields
    }