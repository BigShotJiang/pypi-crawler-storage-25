import click
from scm.utils import load_data, physical_filter
from scm.core import SCMModel

@click.group()
def main():
    """SCM CLI - 叠合一致法命令行工具"""
    pass

@main.command()
@click.argument('filepath', type=click.Path(exists=True))
@click.option('--y', 'y_col', default='total_tps', help='因变量列名')
@click.option('--x', 'x_col', default='concurrency', help='自变量列名')
@click.option('--k', 'k_col', default='max_tokens', help='增益系数列名')
@click.option('--c', 'c_col', default='model', help='损耗系数列名')
@click.option('--filter/--no-filter', default=True, help='是否进行物理过滤')
def analyze(filepath, y_col, x_col, k_col, c_col, filter):
    """分析 CSV 数据，标定 SCM 系数并输出验证指标"""
    click.echo(f"加载数据: {filepath}")
    df = load_data(filepath)
    click.echo(f"原始数据: {len(df)} 行")
    
    if filter:
        df = physical_filter(df)
        click.echo(f"物理过滤后: {len(df)} 行")
    
    click.echo("\n标定 SCM 模型...")
    model = SCMModel()
    params = model.fit(df)
    
    click.echo("\n模型参数:")
    for m, p in params.items():
        click.echo(f"  {m}:")
        click.echo(f"    BaseTPS = {p['base_tps']:.2f}")
        click.echo(f"    f_params = {p['f_params']}")
        click.echo(f"    K_len = {p['k_len']:.4f}")
        click.echo(f"    C_model = {p['c_model']:.4f}")
    
    click.echo("\n验证指标:")
    metrics = model.validate(df)
    for k, v in metrics.items():
        click.echo(f"  {k}: {v:.2f}" if isinstance(v, float) else f"  {k}: {v}")

@main.command()
@click.argument('filepath', type=click.Path(exists=True))
@click.option('--target', '-t', type=float, required=True, help='目标 TPS')
@click.option('--model', '-m', default=None, help='指定模型（默认所有模型）')
def optimize(filepath, target, model):
    """给定目标 TPS，反向求解最优配置"""
    click.echo(f"目标 TPS = {target}")
    # 简化版：先加载数据并拟合
    df = load_data(filepath)
    df = physical_filter(df)
    scm = SCMModel()
    scm.fit(df)
    
    models = [model] if model else list(scm.model_params.keys())
    for m in models:
        if m not in scm.model_params:
            click.echo(f"模型 {m} 不存在")
            continue
        p = scm.model_params[m]
        # 简单搜索最优并发
        best_concur = 1
        best_tps = 0
        for c in [1, 2, 4, 8, 16]:
            pred = scm.predict(m, c, 50)
            if pred >= target:
                best_concur = c
                best_tps = pred
                break
            if pred > best_tps:
                best_tps = pred
        click.echo(f"\n{m}:")
        click.echo(f"   推荐并发 = {best_concur}, 预测 TPS = {best_tps:.2f}")

if __name__ == "__main__":
    main()