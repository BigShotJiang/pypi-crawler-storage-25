import pandas as pd
import numpy as np

def load_data(filepath):
    """加载 CSV 数据"""
    df = pd.read_csv(filepath)
    required_cols = ['model', 'concurrency', 'max_tokens', 'total_tps']
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"CSV 缺少必需列: {col}")
    return df

def physical_filter(df):
    """物理过滤：剔除违反并发单调性的数据点"""
    df_clean = df[df['total_tps'] > 0].copy()
    models = df_clean['model'].unique()
    filtered = []
    
    for model in models:
        df_model = df_clean[df_clean['model'] == model]
        for max_tokens in df_model['max_tokens'].unique():
            df_config = df_model[df_model['max_tokens'] == max_tokens].sort_values('concurrency')
            prev_tps = 0
            for _, row in df_config.iterrows():
                if row['total_tps'] >= prev_tps * 0.95:
                    filtered.append(row.to_dict())
                    prev_tps = row['total_tps']
    
    print(f"物理过滤: {len(df)} → {len(filtered)} 行")
    return pd.DataFrame(filtered)