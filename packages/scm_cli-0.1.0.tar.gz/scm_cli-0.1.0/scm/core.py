import pandas as pd
import numpy as np
from scipy.optimize import curve_fit

class SCMModel:
    def __init__(self):
        self.model_params = {}
    
    def concurrency_gain_function(self, x, a, b):
        """并发增益函数: f(x) = a * (1 - exp(-b * x))"""
        return a * (1 - np.exp(-b * x))
    
    def fit(self, data):
        """分模型独立拟合"""
        models = data['model'].unique()
        
        for model in models:
            df_model = data[data['model'] == model]
            
            # BaseTPS: 取并发=1、长度=50 的平均 TPS
            baseline = df_model[(df_model['concurrency'] == 1) & (df_model['max_tokens'] == 50)]
            if len(baseline) > 0:
                base_tps = baseline['total_tps'].mean()
            else:
                base_tps = df_model[df_model['concurrency'] == 1]['total_tps'].mean()
            
            # f(concurrency)
            concur_data = df_model[df_model['max_tokens'] == 50]
            if len(concur_data) >= 2:
                x = concur_data['concurrency'].values
                y = concur_data['total_tps'].values / base_tps
                try:
                    popt, _ = curve_fit(self.concurrency_gain_function, x, y, p0=[2, 0.5], maxfev=5000)
                    f_params = popt.tolist()
                except:
                    f_params = [1.0, 1.0]
            else:
                f_params = [1.0, 1.0]
            
            # K_len
            len_data = df_model[df_model['concurrency'] == 1]
            if len(len_data) >= 2:
                x = len_data['max_tokens'].values
                y = len_data['total_tps'].values / base_tps
                k_len = np.polyfit(x, y, 1)[0] if len(x) >= 2 else 0
            else:
                k_len = 0
            
            self.model_params[model] = {
                'base_tps': base_tps,
                'f_params': f_params,
                'k_len': k_len
            }
        
        # C_model: 以第一个模型为基准
        benchmark = list(models)[0]
        bench_tps = self.model_params[benchmark]['base_tps']
        for model in models:
            self.model_params[model]['c_model'] = bench_tps / self.model_params[model]['base_tps']
        
        return self.model_params
    
    def predict(self, model, concurrency, max_tokens):
        """预测 TPS"""
        p = self.model_params[model]
        f_val = self.concurrency_gain_function(concurrency, *p['f_params'])
        k_val = 1 + p['k_len'] * (max_tokens - 50) / 50
        return p['base_tps'] * f_val * max(k_val, 0.3)
    
    def validate(self, data):
        """计算验证指标"""
        y_true = []
        y_pred = []
        for _, row in data.iterrows():
            if row['model'] in self.model_params:
                pred = self.predict(row['model'], row['concurrency'], row['max_tokens'])
                y_true.append(row['total_tps'])
                y_pred.append(pred)
        
        y_true = np.array(y_true)
        y_pred = np.array(y_pred)
        mae = np.mean(np.abs(y_true - y_pred))
        rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
        mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
        
        return {'MAE': mae, 'RMSE': rmse, 'MAPE(%)': mape, 'R2': r2}