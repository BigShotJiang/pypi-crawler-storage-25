from setuptools import setup, find_packages

setup(
    name="scm-cli",
    version="0.1.0",
    author="Your Name",
    description="SCM (Superposition-Consistency Method) CLI Tool",
    packages=find_packages(),
    install_requires=[
        "click>=8.0.0",
        "pandas>=1.3.0",
        "numpy>=1.21.0",
        "scipy>=1.7.0",
    ],
    entry_points={
        "console_scripts": [
            "scm=scm.cli:main",
        ],
    },
    python_requires=">=3.8",
)