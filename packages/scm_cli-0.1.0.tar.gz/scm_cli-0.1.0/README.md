# SCM CLI

Superposition-Consistency Method (SCM) 命令行工具，用于大模型推理性能建模与预测。

## 安装

```bash
pip install -e .
```

## 命令

### fit - 拟合模型

```bash
scm fit data.csv -o output.csv
```

### filter - 物理过滤

```bash
scm filter data.csv -o filtered.csv
```

### predict - 预测 TPS

```bash
scm predict data.csv "Qwen/Qwen2.5-7B-Instruct" 50 4
```

## 数据格式

CSV 文件需包含以下列：
- model: 模型名称
- concurrency: 并发度
- max_tokens: 最大输出 tokens
- total_tps: 实际 TPS