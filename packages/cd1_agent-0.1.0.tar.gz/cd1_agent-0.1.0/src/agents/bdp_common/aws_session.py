"""Thin re-export for inner packages (bdp_metrics, bdp_drift, bdp_cost, bdp_stats).

Inner package에서 `from bdp_common.aws_session import get_boto3_client` 로 사용.
"""

from src.common.services.aws_session import (
    get_boto3_client,
    get_boto3_session,
    get_botocore_session,
)

__all__ = ["get_boto3_client", "get_boto3_session", "get_botocore_session"]
