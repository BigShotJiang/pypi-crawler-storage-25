"""Metric catalog service - serves metric suggestions from bdp_metrics.csv."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Optional


def _normalize(raw: str) -> str:
    return raw.strip().lower()


class MetricCatalogService:
    """Parses bdp_metrics.csv once and serves suggestions by service_type."""

    def __init__(self, csv_path: Optional[str] = None):
        path = Path(csv_path) if csv_path else Path(__file__).resolve().parents[3] / "conf" / "bdp_metrics" / "bdp_metrics.csv"
        self._catalog: dict[str, list[dict]] = {}
        self._load(path)

    def _load(self, path: Path):
        if not path.exists():
            return
        with open(path, encoding="utf-8") as f:
            reader = csv.reader(f)
            next(reader, None)  # skip header
            for row in reader:
                if len(row) < 4:
                    continue
                stype = _normalize(row[0])
                if not stype:
                    continue
                self._catalog.setdefault(stype, []).append({
                    "metric_name": row[1].strip(),
                    "description": row[3].strip(),
                    "category": row[4].strip() if len(row) > 4 else "",
                })

    def get_suggestions(self, service_type: str) -> list[dict]:
        return self._catalog.get(_normalize(service_type), [])

    def get_service_types(self) -> list[str]:
        return sorted(self._catalog.keys())
