"""Airflow Detection Config Store - section-based key-value store for detection parameters."""

import logging
from datetime import datetime
from typing import Any

from src.common.timezone import KST
from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

BDP_AIRFLOW_DETECTION_CONFIG_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS bdp_airflow_detection_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_key TEXT NOT NULL UNIQUE,
    config_json TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT
);
"""

BDP_AIRFLOW_DETECTION_CONFIG_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS bdp_airflow_detection_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_json TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class AirflowConfigStore:
    """Section-based key-value store for airflow detection configuration."""

    def __init__(self, db: PortalDB):
        self.db = db
        self.provider = db.provider

    def ensure_table(self) -> None:
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(BDP_AIRFLOW_DETECTION_CONFIG_TABLE_SQLITE)
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(BDP_AIRFLOW_DETECTION_CONFIG_TABLE_MYSQL)
            conn.commit()
        logger.info("bdp_airflow_detection_config table ensured")

    def get_all_sections(self) -> dict[str, dict[str, Any]]:
        """Return all saved sections as {config_key: row_dict}."""
        if self.provider == "mock":
            return {}
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("SELECT * FROM bdp_airflow_detection_config ORDER BY config_key")
            return {row["config_key"]: dict(row) for row in cur.fetchall()}
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM bdp_airflow_detection_config ORDER BY config_key")
            return {row["config_key"]: row for row in cur.fetchall()}

    def get_section(self, config_key: str) -> dict[str, Any] | None:
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT * FROM bdp_airflow_detection_config WHERE config_key = ?",
                (config_key,),
            )
            row = cur.fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM bdp_airflow_detection_config WHERE config_key = %s",
                (config_key,),
            )
            return cur.fetchone()

    def save_section(
        self,
        config_key: str,
        config_json: str,
        updated_by: str | None = None,
    ) -> None:
        """Upsert a section's config JSON."""
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(
                """INSERT INTO bdp_airflow_detection_config (config_key, config_json, updated_at, updated_by)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(config_key) DO UPDATE SET config_json = ?, updated_at = ?, updated_by = ?""",
                (config_key, config_json, now, updated_by, config_json, now, updated_by),
            )
            conn.commit()
        else:
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO bdp_airflow_detection_config (config_key, config_json, updated_by)
                       VALUES (%s, %s, %s)
                       ON DUPLICATE KEY UPDATE config_json = %s, updated_by = %s""",
                    (config_key, config_json, updated_by, config_json, updated_by),
                )
            conn.commit()

    def delete_section(self, config_key: str) -> bool:
        """Delete a section override (revert to default)."""
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "DELETE FROM bdp_airflow_detection_config WHERE config_key = ?",
                (config_key,),
            )
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM bdp_airflow_detection_config WHERE config_key = %s",
                (config_key,),
            )
        conn.commit()
        return cur.rowcount > 0

    def delete_all(self) -> int:
        """Delete all overrides. Returns count deleted."""
        if self.provider == "mock":
            return 0
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("DELETE FROM bdp_airflow_detection_config")
            conn.commit()
            return cur.rowcount
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM bdp_airflow_detection_config")
        conn.commit()
        return cur.rowcount
