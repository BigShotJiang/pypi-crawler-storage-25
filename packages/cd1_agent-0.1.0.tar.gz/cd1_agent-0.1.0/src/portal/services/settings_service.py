"""Settings service for Portal.

Provides read/write access to agent settings via DB overrides.
"""

import logging
from typing import Any

from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

# Editable setting definitions: key -> (label, group, type, domain)
# domain: "main" = 공통 설정, "cost"/"drift"/"metrics" = 각 도메인별 설정
EDITABLE_SETTINGS: dict[str, dict[str, str]] = {
    # LLM
    "llm_provider": {
        "label": "LLM 제공자",
        "group": "LLM",
        "type": "select",
        "options": "mock,vllm",
        "domain": "main",
    },
    "vllm_endpoint": {"label": "vLLM 엔드포인트", "group": "LLM", "type": "text", "domain": "main"},
    "vllm_model": {"label": "vLLM 모델", "group": "LLM", "type": "text", "domain": "main"},
    "vllm_api_key": {"label": "vLLM API Key", "group": "LLM", "type": "password", "domain": "main"},
    # Agent Parameters
    "max_iterations": {
        "label": "최대 반복 횟수",
        "group": "에이전트",
        "type": "number",
        "domain": "main",
    },
    "confidence_threshold": {
        "label": "신뢰도 임계값",
        "group": "에이전트",
        "type": "number",
        "domain": "main",
    },
    # Cost
    "bdp_sensitivity": {
        "label": "민감도",
        "group": "비용 에이전트",
        "type": "number",
        "domain": "cost",
    },
    "bdp_currency": {
        "label": "통화",
        "group": "비용 에이전트",
        "type": "select",
        "options": "KRW,USD",
        "domain": "cost",
    },
    "bdp_min_cost_threshold": {
        "label": "최소 비용 임계값",
        "group": "비용 에이전트",
        "type": "number",
        "domain": "cost",
    },
    "bdp_hitl_on_critical": {
        "label": "위험 시 사용자 승인",
        "group": "비용 에이전트",
        "type": "select",
        "options": "true,false",
        "domain": "cost",
    },
    # Drift
    "enable_drift_analysis": {
        "label": "Drift 분석 활성화",
        "group": "Drift 에이전트",
        "type": "select",
        "options": "true,false",
        "domain": "drift",
    },
    "analysis_confidence_threshold": {
        "label": "분석 신뢰도 임계값",
        "group": "Drift 에이전트",
        "type": "number",
        "domain": "drift",
    },
    # Metrics
    "metrics_enabled": {
        "label": "메트릭 수집 활성화",
        "group": "메트릭 에이전트",
        "type": "select",
        "options": "true,false",
        "domain": "metrics",
    },
    "metrics_prefix": {
        "label": "메트릭 접두사",
        "group": "메트릭 에이전트",
        "type": "text",
        "domain": "metrics",
    },
    # HolmesGPT
    "holmesgpt_endpoint": {
        "label": "엔드포인트 URL",
        "group": "HolmesGPT",
        "type": "text",
        "domain": "main",
    },
    "holmesgpt_system_prompt": {
        "label": "시스템 프롬프트",
        "group": "HolmesGPT",
        "type": "text",
        "domain": "main",
    },
    # CloudWatch 캐시 설정
    "cw_cache_bdp_metrics": {
        "label": "BDP Metrics 에이전트",
        "group": "CloudWatch 캐시 설정",
        "type": "select",
        "options": "direct,cache",
        "domain": "main",
    },
    "vm_enabled": {
        "label": "Victoria Metrics 활성화",
        "group": "CloudWatch 캐시 설정",
        "type": "select",
        "options": "true,false",
        "domain": "main",
    },
    "vm_url": {
        "label": "Victoria Metrics URL",
        "group": "CloudWatch 캐시 설정",
        "type": "text",
        "domain": "main",
    },
    "vm_auth_token": {
        "label": "Victoria Metrics 인증 토큰",
        "group": "CloudWatch 캐시 설정",
        "type": "password",
        "domain": "main",
    },
    "vl_enabled": {
        "label": "Victoria Logs 활성화",
        "group": "CloudWatch 캐시 설정",
        "type": "select",
        "options": "true,false",
        "domain": "main",
    },
    "vl_url": {
        "label": "Victoria Logs URL",
        "group": "CloudWatch 캐시 설정",
        "type": "text",
        "domain": "main",
    },
    "vl_auth_token": {
        "label": "Victoria Logs 인증 토큰",
        "group": "CloudWatch 캐시 설정",
        "type": "password",
        "domain": "main",
    },
    "vm_retention_days": {
        "label": "VM 데이터 보관주기 (일)",
        "group": "CloudWatch 캐시 설정",
        "type": "number",
        "domain": "main",
        "default": "365",
    },
    "vl_retention_days": {
        "label": "VL 데이터 보관주기 (일)",
        "group": "CloudWatch 캐시 설정",
        "type": "number",
        "domain": "main",
        "default": "365",
    },
    # Infra - 로그 그룹 설정
    "infra_log_group_sagemaker_endpoint": {
        "label": "SageMaker Endpoint 로그 그룹",
        "group": "로그 그룹",
        "type": "text",
        "domain": "infra",
        "default": "/aws/sagemaker/Endpoints/{resource_name}",
    },
    "infra_log_group_sagemaker_studio": {
        "label": "SageMaker Studio 로그 그룹",
        "group": "로그 그룹",
        "type": "text",
        "domain": "infra",
        "default": "/aws/sagemaker/studio/{resource_name}",
    },
    # ADW (GCP BigQuery)
    "adw_project_id": {
        "label": "GCP Project ID",
        "group": "ADW",
        "type": "text",
        "domain": "adw_metrics",
    },
    "adw_bq_location": {
        "label": "BigQuery Location",
        "group": "ADW",
        "type": "text",
        "domain": "adw_metrics",
        "default": "US",
    },
    # HDSP Metrics
    "hdsp_provider": {
        "label": "데이터 소스",
        "group": "HDSP 데이터 소스",
        "type": "select",
        "options": "mock,real",
        "domain": "hdsp_metrics",
    },
    "hdsp_k8s_api_url": {
        "label": "Kubernetes API URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_spark_history_url": {
        "label": "Spark History Server URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_minio_endpoint": {
        "label": "MinIO 엔드포인트",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_minio_access_key": {
        "label": "MinIO Access Key",
        "group": "HDSP 데이터 소스",
        "type": "password",
        "domain": "hdsp_metrics",
    },
    "hdsp_minio_secret_key": {
        "label": "MinIO Secret Key",
        "group": "HDSP 데이터 소스",
        "type": "password",
        "domain": "hdsp_metrics",
    },
    "hdsp_nfs_base_path": {
        "label": "NFS 베이스 경로",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_jupyterhub_url": {
        "label": "JupyterHub URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_jupyterhub_token": {
        "label": "JupyterHub API Token",
        "group": "HDSP 데이터 소스",
        "type": "password",
        "domain": "hdsp_metrics",
    },
    "hdsp_haproxy_stats_url": {
        "label": "HAProxy Stats URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_registry_url": {
        "label": "Docker Registry URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
    "hdsp_api_metrics_url": {
        "label": "API Metrics URL",
        "group": "HDSP 데이터 소스",
        "type": "text",
        "domain": "hdsp_metrics",
    },
}


class SettingsService:
    """Manages admin setting overrides."""

    def __init__(self, db: PortalDB):
        self.db = db

    @staticmethod
    def _mask(value: str) -> str:
        """Mask a secret value, showing only the last 4 characters."""
        if not value:
            return ""
        if len(value) <= 4:
            return "****"
        return "*" * (len(value) - 4) + value[-4:]

    def _build_env_dict(self) -> dict[str, Any]:
        """Build env_settings dict from ServerSettings."""
        try:
            from src.common.server.config import ServerSettings

            server_settings = ServerSettings()
            return {k: v for k, v in server_settings.model_dump().items()}
        except Exception:
            return {}

    def get_all_with_overrides(self, env_settings: dict[str, Any]) -> list[dict[str, Any]]:
        """Get all editable settings with current values and overrides.

        Args:
            env_settings: Current environment-based settings dict.

        Returns:
            List of setting dicts with key, label, group, type, env_value, override_value.
        """
        overrides = {row["key"]: row for row in self.db.get_all_settings()}
        result = []
        for key, meta in EDITABLE_SETTINGS.items():
            env_val = env_settings.get(key, "")
            override = overrides.get(key)
            is_secret = meta["type"] == "password"
            env_str = str(env_val) if env_val is not None else ""
            override_str = override["value"] if override else None
            effective_str = override_str if override_str is not None else env_str
            result.append(
                {
                    "key": key,
                    "label": meta["label"],
                    "group": meta["group"],
                    "type": meta["type"],
                    "domain": meta.get("domain", "main"),
                    "options": meta.get("options", "").split(",") if meta.get("options") else [],
                    "env_value": self._mask(env_str) if is_secret else env_str,
                    "override_value": self._mask(override_str)
                    if is_secret and override_str is not None
                    else override_str,
                    "effective_value": effective_str,
                    "display_value": self._mask(effective_str) if is_secret else effective_str,
                    "updated_at": override.get("updated_at") if override else None,
                    "updated_by": override.get("updated_by") if override else None,
                }
            )
        return result

    def get_by_domain(self, domain: str) -> list[dict[str, Any]]:
        """Get settings filtered by domain with current values and overrides."""
        env_settings = self._build_env_dict()
        all_settings = self.get_all_with_overrides(env_settings)
        return [s for s in all_settings if s["domain"] == domain]

    def update_setting(self, key: str, value: str, updated_by: str = "admin") -> bool:
        """Update a setting override."""
        if key not in EDITABLE_SETTINGS:
            return False
        self.db.set_setting(key, value, updated_by)
        return True

    def get_override(self, key: str) -> str | None:
        """Get a single setting override value, or None if not set."""
        return self.db.get_setting(key)

    def delete_override(self, key: str) -> bool:
        """Remove a setting override (revert to env value)."""
        return self.db.delete_setting(key)
