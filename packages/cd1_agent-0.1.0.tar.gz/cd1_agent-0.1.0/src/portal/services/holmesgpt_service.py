"""HolmesGPT service for Portal.

Handles communication with HolmesGPT API and renders Prometheus charts.
Benchmarked from: holmesgpt/deploy/chat_client.py
"""

from __future__ import annotations

import base64
import html as html_module
import io
import json
import logging
import re
from datetime import datetime
from typing import TYPE_CHECKING, Any

import httpx

from src.portal.services.settings_service import SettingsService

if TYPE_CHECKING:
    from src.portal.services.holmesgpt_session_store import HolmesGPTSessionStore

logger = logging.getLogger(__name__)

# Embed tag pattern: << {"type": "promql", "tool_call_id": "..."} >>
_EMBED_TAG_RE = re.compile(r"<<\s*(\{.*?\})\s*>>", re.DOTALL)


# ── Prometheus chart rendering (from chat_client.py) ────────────────


def _metric_label(metric: dict) -> str:
    """Build a readable legend label from Prometheus metric labels."""
    filtered = {k: v for k, v in metric.items() if k != "__name__"}
    if not filtered:
        return metric.get("__name__", "value")
    if len(filtered) == 1:
        return next(iter(filtered.values()))
    return ", ".join(f"{k}={v}" for k, v in filtered.items())


def _render_prometheus_chart(prom_data: dict, description: str, query: str) -> str:
    """Render Prometheus data as a base64-encoded <img> tag using matplotlib.

    Supports:
      - resultType "matrix" -> line chart (multiple series)
      - resultType "vector" -> horizontal bar chart
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.dates as mdates
        import matplotlib.pyplot as plt
    except ImportError:
        return f'<p style="color:#999">[Graph: {description} — matplotlib not installed]</p>'

    result_type = prom_data.get("resultType", "")
    results = prom_data.get("result", [])
    if not results:
        return f'<p style="color:#999">[Graph: {description} — no data]</p>'

    fig, ax = plt.subplots(figsize=(10, 4))

    if result_type == "matrix":
        for series in results:
            label = _metric_label(series.get("metric", {}))
            values = series.get("values", [])
            if not values:
                continue
            timestamps = [datetime.fromtimestamp(float(v[0])) for v in values]
            nums = [float(v[1]) for v in values]
            ax.plot(timestamps, nums, label=label, linewidth=1.5)

        ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        fig.autofmt_xdate(rotation=30)

    elif result_type == "vector":
        labels = []
        values = []
        for entry in results:
            labels.append(_metric_label(entry.get("metric", {})))
            values.append(float(entry.get("value", [0, 0])[1]))
        y_pos = range(len(labels))
        ax.barh(y_pos, values)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(labels, fontsize=8)

    else:
        plt.close(fig)
        return f'<p style="color:#999">[Graph: {description} — unsupported resultType: {result_type}]</p>'

    ax.set_title(description, fontsize=11, pad=8)
    ax.grid(True, alpha=0.3)
    if result_type == "matrix" and len(results) > 1:
        ax.legend(fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")
    escaped_desc = html_module.escape(description)
    escaped_query = html_module.escape(query)
    return (
        f'<div style="margin:8px 0">'
        f'<img src="data:image/png;base64,{b64}" alt="{escaped_desc}" style="max-width:100%;height:auto;border:1px solid #eee;border-radius:4px">'
        f'<p style="color:#999;font-size:0.8em;margin:2px 0">query: <code>{escaped_query}</code></p>'
        f"</div>"
    )


def _find_tool_call(tool_calls: list, tool_call_id: str) -> dict:
    """Find a tool_call entry by its tool_call_id."""
    for tc in tool_calls:
        tc_id = tc.get("tool_call_id", "") if isinstance(tc, dict) else ""
        if tc_id == tool_call_id:
            return tc
    return {}


def _extract_prom_data(tool_call: dict) -> tuple[dict | None, str, str]:
    """Extract (prom_data_dict, description, query) from a tool_call result."""
    result = tool_call.get("result", {})
    data_field = result.get("data", "")

    if isinstance(data_field, str):
        try:
            data_field = json.loads(data_field)
        except (json.JSONDecodeError, TypeError):
            return None, "", ""

    if not isinstance(data_field, dict):
        return None, "", ""

    description = data_field.get("description", result.get("description", ""))
    query = data_field.get("query", "")
    prom_data = data_field.get("data", {})

    if isinstance(prom_data, str):
        try:
            prom_data = json.loads(prom_data)
        except (json.JSONDecodeError, TypeError):
            return None, description, query

    return prom_data, description, query


def _process_embed_tags(analysis: str, tool_calls: list) -> str:
    """Replace << {"type": "promql", ...} >> embed tags with rendered chart images."""

    def replace_tag(match):
        try:
            tag = json.loads(match.group(1))
        except (json.JSONDecodeError, TypeError):
            return match.group(0)

        if tag.get("type") != "promql":
            return match.group(0)

        tool_call_id = tag.get("tool_call_id", "")
        if not tool_call_id:
            return '<p style="color:#999">[Graph: missing tool_call_id]</p>'

        tc = _find_tool_call(tool_calls, tool_call_id)
        if not tc:
            return '<p style="color:#999">[Graph: data not found]</p>'

        prom_data, description, query = _extract_prom_data(tc)
        if not prom_data or not prom_data.get("result"):
            return (
                f'<p style="color:#999">[Graph: {html_module.escape(description or "no data")}]</p>'
            )

        return _render_prometheus_chart(prom_data, description, query)

    return _EMBED_TAG_RE.sub(replace_tag, analysis)


def _render_tool_table(tool_calls: list) -> str:
    """Render collapsible tool calls summary table."""
    if not tool_calls:
        return ""
    tc_rows = ""
    for tc in tool_calls:
        if not isinstance(tc, dict):
            continue
        name = html_module.escape(tc.get("tool_name", tc.get("name", "unknown")))
        desc = html_module.escape(tc.get("description", ""))
        result = tc.get("result", {})
        tc_status = result.get("status", "") if isinstance(result, dict) else ""
        status_color = {"success": "#4CAF50", "error": "red", "no_data": "#FF9800"}.get(
            tc_status, "#999"
        )
        tc_rows += (
            f"<tr>"
            f'<td style="font-family:monospace;font-size:0.85em">{name}</td>'
            f"<td>{desc}</td>"
            f'<td style="color:{status_color};font-weight:bold">{tc_status}</td>'
            f"</tr>"
        )
    return (
        f'<details style="margin:4px 0">'
        f'<summary style="color:#999;cursor:pointer">[{len(tool_calls)} tool calls]</summary>'
        f'<table style="width:100%;font-size:0.85em;margin:4px 0;border-collapse:collapse">'
        f'<tr style="background:#f5f5f5"><th style="border:1px solid #ddd;padding:4px 8px">Tool</th>'
        f'<th style="border:1px solid #ddd;padding:4px 8px">Description</th>'
        f'<th style="border:1px solid #ddd;padding:4px 8px">Status</th></tr>'
        f"{tc_rows}</table></details>"
    )


def _render_analysis(analysis: str, tool_calls: list) -> str:
    """Render HolmesGPT analysis: embed tags → charts, then markdown → HTML."""
    # 1. Replace embed tags with chart images
    processed = _process_embed_tags(analysis, tool_calls)

    # 2. Markdown → HTML
    try:
        from markdown_it import MarkdownIt

        md = MarkdownIt().enable("table")
        rendered = md.render(processed)
    except ImportError:
        # Fallback: basic line-break conversion
        rendered = processed.replace("\n", "<br>")

    # 3. Combine tool table + rendered analysis
    tool_html = _render_tool_table(tool_calls)
    return tool_html + rendered


# ── Service class ───────────────────────────────────────────────────


class HolmesGPTService:
    """Portal service for HolmesGPT API communication."""

    def __init__(
        self, settings_service: SettingsService, session_store: HolmesGPTSessionStore | None = None
    ):
        self.settings_service = settings_service
        self.session_store = session_store

    def _get_setting(self, key: str) -> str:
        """Get effective setting value."""
        env_settings = self.settings_service._build_env_dict()
        all_settings = self.settings_service.get_all_with_overrides(env_settings)
        for s in all_settings:
            if s["key"] == key:
                return s["effective_value"] or ""
        return ""

    def _get_endpoint(self) -> str:
        return self._get_setting("holmesgpt_endpoint").rstrip("/")

    def _get_system_prompt(self) -> str:
        return self._get_setting("holmesgpt_system_prompt")

    async def chat(
        self,
        ask: str,
        conversation_history: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Send a chat message to HolmesGPT and return rendered result.

        Returns:
            {
                "rendered_html": str,  # tool table + markdown + charts
                "conversation_history": list,
                "tool_calls": list,
                "analysis": str,  # raw analysis text
            }
        """
        endpoint = self._get_endpoint()
        if not endpoint:
            return {
                "rendered_html": '<p style="color:red">[ERROR] HolmesGPT 엔드포인트가 설정되지 않았습니다.</p>',
                "conversation_history": conversation_history,
                "tool_calls": [],
                "analysis": "",
            }

        url = f"{endpoint}/api/chat"
        payload: dict[str, Any] = {"ask": ask, "stream": False}

        system_prompt = self._get_system_prompt()
        if system_prompt:
            payload["additional_system_prompt"] = system_prompt

        if conversation_history:
            payload["conversation_history"] = conversation_history

        try:
            async with httpx.AsyncClient(timeout=180.0) as client:
                resp = await client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
        except httpx.TimeoutException:
            return {
                "rendered_html": '<p style="color:red">[ERROR] HolmesGPT 응답 시간 초과 (180초)</p>',
                "conversation_history": conversation_history,
                "tool_calls": [],
                "analysis": "",
            }
        except httpx.HTTPStatusError as e:
            detail = ""
            try:
                detail = e.response.json().get("detail", str(e))
            except Exception:
                detail = str(e)
            return {
                "rendered_html": f'<p style="color:red">[ERROR {e.response.status_code}] {html_module.escape(str(detail))}</p>',
                "conversation_history": conversation_history,
                "tool_calls": [],
                "analysis": "",
            }
        except Exception as e:
            return {
                "rendered_html": f'<p style="color:red">[ERROR] {html_module.escape(str(e))}</p>',
                "conversation_history": conversation_history,
                "tool_calls": [],
                "analysis": "",
            }

        analysis = data.get("analysis", "")
        tool_calls = data.get("tool_calls", [])
        conv_history = data.get("conversation_history")

        rendered_html = _render_analysis(analysis, tool_calls)

        return {
            "rendered_html": rendered_html,
            "conversation_history": conv_history,
            "tool_calls": tool_calls,
            "analysis": analysis,
        }

    # ── Session-based chat methods ──────────────────────────────────

    def create_session(self) -> dict[str, Any]:
        return {"id": self.session_store.create_session("새 대화"), "title": "새 대화"}

    def list_sessions(self, page: int = 1, per_page: int = 20) -> tuple[list, int]:
        return self.session_store.list_sessions(page, per_page)

    def get_session_with_messages(self, session_id: str) -> dict[str, Any] | None:
        session = self.session_store.get_session(session_id)
        if not session:
            return None
        messages = self.session_store.get_messages(session_id)
        session["messages"] = messages
        return session

    def delete_session(self, session_id: str) -> bool:
        return self.session_store.delete_session(session_id)

    def search_sessions(self, query: str, page: int = 1, per_page: int = 20) -> tuple[list, int]:
        return self.session_store.search_sessions(query, page, per_page)

    async def chat_in_session(self, session_id: str, ask: str) -> dict[str, Any]:
        """Send a message in a session context, persisting messages to DB."""
        import json as _json

        # 1. Save user message
        self.session_store.add_message(session_id, "user", ask)

        # 2. Auto-generate title from first message (first 50 chars)
        messages = self.session_store.get_messages(session_id)
        user_messages = [m for m in messages if m["role"] == "user"]
        if len(user_messages) == 1:
            title = ask[:50] + ("..." if len(ask) > 50 else "")
            self.session_store.update_session_title(session_id, title)

        # 3. Build conversation history (exclude last user message - it goes as 'ask')
        history = self.session_store.build_conversation_history(session_id)
        # Remove the last user message since it will be sent as 'ask'
        conv_history = history[:-1] if history else None

        # 4. Call HolmesGPT
        result = await self.chat(ask, conv_history if conv_history else None)

        # 5. Save assistant response
        tool_calls_json = (
            _json.dumps(result.get("tool_calls", []), ensure_ascii=False)
            if result.get("tool_calls")
            else None
        )
        self.session_store.add_message(
            session_id,
            "assistant",
            result.get("analysis", ""),
            rendered_html=result.get("rendered_html"),
            tool_calls_json=tool_calls_json,
        )

        return {
            "session_id": session_id,
            "rendered_html": result.get("rendered_html", ""),
            "analysis": result.get("analysis", ""),
            "tool_calls": result.get("tool_calls", []),
        }
