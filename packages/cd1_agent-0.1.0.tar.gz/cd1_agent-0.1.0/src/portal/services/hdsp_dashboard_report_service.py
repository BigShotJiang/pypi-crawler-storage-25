"""HDSP Dashboard Report service wrapper for Portal.

Wraps the existing HdspDashboardReportStore for portal use.
Uses direct module loading to avoid triggering heavy __init__.py imports
from agent packages.
"""

from __future__ import annotations

import logging
from typing import Any

from src.portal.services._import_helper import load_generator_module, load_report_store

logger = logging.getLogger(__name__)

_store_module = load_report_store("hdsp_dashboard", "hdsp_dashboard/services/report_store.py")
_REPORT_AVAILABLE = _store_module is not None
HdspDashboardReportStore = getattr(_store_module, "HdspDashboardReportStore", None)
HdspDashboardReport = getattr(_store_module, "HdspDashboardReport", None)

_gen_module = load_generator_module(
    "hdsp_dashboard",
    "hdsp_dashboard/services/service_report_generator.py",
)
HdspServiceReportGenerator = getattr(_gen_module, "HdspServiceReportGenerator", None)


def is_hdsp_dashboard_report_available() -> bool:
    return _REPORT_AVAILABLE


def create_hdsp_dashboard_report_store(
    provider: str, db: str | None = None, secret_id: str | None = None
) -> Any | None:
    """Create a HdspDashboardReportStore if the package is available."""
    if not _REPORT_AVAILABLE:
        return None
    store = HdspDashboardReportStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


class HdspDashboardReportService:
    """Portal wrapper around HdspDashboardReportStore."""

    def __init__(self, store: Any | None = None):
        self.store = store
        self.available = store is not None

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Any]:
        if not self.available:
            return []
        return self.store.list_reports(
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            offset=offset,
        )

    def get_report(self, report_id: str) -> Any | None:
        if not self.available:
            return None
        return self.store.get_report(report_id)

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        if not self.available:
            return 0
        return self.store.get_report_count(start_date=start_date, end_date=end_date)

    def render_html(self, report_id: str) -> str | None:
        """DB 저장된 HTML 리포트 반환."""
        if not self.available:
            return None
        report = self.store.get_report(report_id)
        if report is None:
            return None
        return getattr(report, "html_report", None)
