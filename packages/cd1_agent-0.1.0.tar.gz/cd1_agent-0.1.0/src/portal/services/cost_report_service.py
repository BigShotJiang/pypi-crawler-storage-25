"""BDP Cost 리포트 서비스.

DB 기반 리포트 저장소 래퍼.
기존 reports/ 디렉토리의 월비교/일단위 HTML 리포트를 시드 데이터로 로드.
테스트, 알림 카테고리는 제외.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.portal.services._import_helper import load_generator_module, load_report_store

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_REPORTS_DIR = _PROJECT_ROOT / "reports"

_COST_DEPS = [
    ("src.agent_server.bdp_cost.services.comparison_models", "bdp_cost/services/comparison_models.py"),
]

_store_module = load_report_store("bdp_cost", "bdp_cost/services/report_store.py")
_REPORT_AVAILABLE = _store_module is not None
CostReportStore = getattr(_store_module, "CostReportStore", None)
CostReportModel = getattr(_store_module, "CostReport", None)

_gen_module = load_generator_module(
    "bdp_cost",
    "bdp_cost/services/comparison_report_generator.py",
    dep_modules=_COST_DEPS,
    needs_reports_base=False,
)
CostComparisonHTMLReportGenerator = getattr(
    _gen_module, "CostComparisonHTMLReportGenerator", None
)


# 시드 데이터: reports/ 디렉토리의 월비교/일단위 리포트만 (테스트/알림 제외)
_SEED_CATALOG: Dict[str, Dict[str, str]] = {
    "sample_comparison_report.html": {
        "id": "seed-cost-comparison-01",
        "title": "월간 비용 비교 리포트 (샘플)",
        "description": "이전 월 대비 당월 서비스별 비용 변화 분석",
        "report_type": "monthly_comparison",
    },
    "sample_athena_cost_report.html": {
        "id": "seed-cost-daily-01",
        "title": "Athena 일일 비용 분석 리포트 (샘플)",
        "description": "Athena 워크그룹별 일단위 비용 분석",
        "report_type": "daily",
    },
}


def is_cost_report_available() -> bool:
    return _REPORT_AVAILABLE


def create_cost_report_store(
    provider: str, db: Optional[str] = None, secret_id: Optional[str] = None
) -> Optional[Any]:
    """Create a CostReportStore if the package is available."""
    if not _REPORT_AVAILABLE:
        return None
    store = CostReportStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


def seed_reports_from_files(store: Any, reports_dir: Optional[Path] = None) -> int:
    """reports/ 디렉토리에서 월비교/일단위 리포트를 DB에 시드.

    이미 존재하는 ID는 건너뜁니다.
    Returns: 새로 추가된 리포트 수.
    """
    if not _REPORT_AVAILABLE or store is None:
        return 0

    dir_path = reports_dir or _REPORTS_DIR
    if not dir_path.exists():
        return 0

    count = 0
    for filename, meta in _SEED_CATALOG.items():
        filepath = dir_path / filename
        if not filepath.is_file():
            continue

        # 이미 존재하면 건너뛰기
        existing = store.get_report(meta["id"])
        if existing is not None:
            continue

        try:
            html_content = filepath.read_text(encoding="utf-8")
            stat = filepath.stat()
            report = CostReportModel(
                id=meta["id"],
                run_timestamp=datetime.fromtimestamp(stat.st_mtime),
                report_type=meta["report_type"],
                title=meta["title"],
                description=meta["description"],
                html_report=html_content,
                status="completed",
            )
            store.save_report(report)
            count += 1
            logger.info(f"Seeded cost report: {meta['title']}")
        except Exception as e:
            logger.error(f"Failed to seed report {filename}: {e}")

    return count


class CostReportService:
    """Portal wrapper around CostReportStore."""

    def __init__(self, store: Optional[Any] = None):
        self.store = store
        self.available = store is not None

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Any]:
        if not self.available:
            return []
        return self.store.list_reports(
            start_date=start_date,
            end_date=end_date,
            report_type=report_type,
            limit=limit,
            offset=offset,
        )

    def get_report(self, report_id: str) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.get_report(report_id)

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        if not self.available:
            return 0
        return self.store.get_report_count(start_date=start_date, end_date=end_date)

    def render_html(self, report_id: str) -> Optional[str]:
        """DB 구조화 데이터로 HTML 리포트 재생성."""
        if not self.available or CostComparisonHTMLReportGenerator is None:
            return None
        report = self.store.get_report(report_id)
        if report is None:
            return None
        if not getattr(report, "raw_data_json", None):
            return getattr(report, "html_report", None)
        generator = CostComparisonHTMLReportGenerator()
        return generator.generate_from_db(report)
