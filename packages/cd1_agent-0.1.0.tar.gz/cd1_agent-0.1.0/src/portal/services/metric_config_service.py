"""Metric Config Service - business logic for metric configuration management."""

import csv
import io
import logging
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.portal.services.metric_config_store import MetricConfigStore

logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Raised when metric config input fails validation."""

    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__(str(errors))


def validate_config_input(
    service_type: str | None,
    metric_name: str | None,
    description: str | None = None,
) -> dict[str, str]:
    """Validate and sanitize config input fields. Returns dict of cleaned values.

    Raises ValidationError if validation fails.
    """
    errors: dict[str, str] = {}
    cleaned: dict[str, str] = {}

    # service_type: required, max 50, strip+lowercase
    st = (service_type or "").strip().lower()
    if not st:
        errors["service_type"] = "Service type is required."
    elif len(st) > 50:
        errors["service_type"] = "Service type must be 50 characters or less."
    cleaned["service_type"] = st

    # metric_name: required, max 100, strip
    mn = (metric_name or "").strip()
    if not mn:
        errors["metric_name"] = "Metric name is required."
    elif len(mn) > 100:
        errors["metric_name"] = "Metric name must be 100 characters or less."
    cleaned["metric_name"] = mn

    # description: optional, max 500, strip
    desc = (description or "").strip() or None
    if desc and len(desc) > 500:
        errors["description"] = "Description must be 500 characters or less."
    cleaned["description"] = desc

    if errors:
        raise ValidationError(errors)
    return cleaned

# CSV 서비스구분 → handler resource_type 매핑
SERVICE_TYPE_MAPPING = {
    "mwaa": "mwaa",
    "sagemaker": "sagemaker-endpoint",
    "sagemaker endpoint": "sagemaker-endpoint",
    "rds": "rds",
    "emr(cluster)": "emr-cluster",
    "emr(serverless)": "emr-serverless",
    "msk": "msk",
}


def normalize_service_type(raw: str) -> str:
    """Normalize service type from CSV to lowercase canonical form."""
    return raw.strip().lower()


def map_to_resource_type(service_type: str) -> Optional[str]:
    """Map normalized service_type to handler resource_type."""
    return SERVICE_TYPE_MAPPING.get(service_type)


class MetricConfigService:
    """Business logic for metric configuration management."""

    def __init__(self, store: MetricConfigStore):
        self.store = store

    def list_configs(self, service_type: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.store.list_configs(service_type)

    def get_config(self, config_id: int) -> Optional[Dict[str, Any]]:
        return self.store.get_config(config_id)

    def create_config(
        self,
        service_type: str,
        metric_name: str,
        enabled: int = 1,
        description: Optional[str] = None,
        updated_by: Optional[str] = None,
    ) -> int:
        cleaned = validate_config_input(service_type, metric_name, description)
        return self.store.create_config(
            cleaned["service_type"], cleaned["metric_name"], enabled, cleaned["description"], updated_by,
        )

    def update_config(self, config_id: int, **kwargs) -> bool:
        cleaned = validate_config_input(
            kwargs.get("service_type"),
            kwargs.get("metric_name"),
            kwargs.get("description"),
        )
        kwargs["service_type"] = cleaned["service_type"]
        kwargs["metric_name"] = cleaned["metric_name"]
        kwargs["description"] = cleaned["description"]
        return self.store.update_config(config_id, **kwargs)

    def delete_config(self, config_id: int) -> bool:
        return self.store.delete_config(config_id)

    def get_enabled_by_service(self) -> Dict[str, List[str]]:
        """Return enabled metrics grouped by handler resource_type.

        Used by handler to filter drift results.
        Returns: {resource_type: [metric_name, ...]}
        """
        configs = self.store.get_enabled_configs()
        result: Dict[str, List[str]] = defaultdict(list)
        for cfg in configs:
            resource_type = map_to_resource_type(cfg["service_type"])
            if resource_type:
                result[resource_type].append(cfg["metric_name"])
        return dict(result)

    def import_csv(self, csv_content: str, updated_by: Optional[str] = None) -> Dict[str, int]:
        """Import CSV content into DB.

        Expected CSV columns: 서비스구분, 지표명, 적용여부, 설명
        Returns: {created: n, updated: n, skipped: n}
        """
        counts = {"created": 0, "updated": 0, "skipped": 0}
        reader = csv.DictReader(io.StringIO(csv_content))
        for row in reader:
            try:
                raw_service = row.get("서비스구분", "").strip()
                metric_name = row.get("지표명", "").strip()
                enabled_str = row.get("적용여부", "X").strip()
                description = row.get("설명", "").strip()

                if not raw_service or not metric_name:
                    counts["skipped"] += 1
                    continue

                service_type = normalize_service_type(raw_service)
                enabled = 1 if enabled_str == "O" else 0

                result = self.store.upsert_config(
                    service_type=service_type,
                    metric_name=metric_name,
                    enabled=enabled,
                    description=description or None,
                    updated_by=updated_by,
                )
                counts[result] = counts.get(result, 0) + 1
            except Exception as e:
                logger.warning(f"Skipping row due to error: {e}")
                counts["skipped"] += 1

        return counts

    def export_csv(self) -> str:
        """Export all configs as CSV string."""
        configs = self.store.list_configs()
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["서비스구분", "지표명", "적용여부", "설명"])
        for cfg in configs:
            writer.writerow([
                cfg["service_type"],
                cfg["metric_name"],
                "O" if cfg["enabled"] else "X",
                cfg.get("description") or "",
            ])
        return output.getvalue()

    def get_service_types(self) -> List[str]:
        return self.store.get_service_types()


def seed_metric_configs(service: MetricConfigService) -> None:
    """bdp_metric_configs가 비어있으면 기본 CSV에서 시드."""
    existing = service.store.list_configs()
    if existing:
        logger.info("bdp_metric_configs already has %d rows, skipping seed", len(existing))
        return

    csv_path = Path(__file__).resolve().parents[3] / "conf" / "bdp_metrics" / "bdp_metrics.csv"
    if not csv_path.exists():
        logger.warning("Seed CSV not found: %s", csv_path)
        return

    csv_content = csv_path.read_text(encoding="utf-8")
    result = service.import_csv(csv_content, updated_by="auto_seed")
    logger.info("Auto-seeded bdp_metric_configs: %s", result)
