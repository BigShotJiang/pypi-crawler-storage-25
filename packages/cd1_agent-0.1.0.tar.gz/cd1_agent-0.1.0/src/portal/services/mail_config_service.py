"""Mail config service for managing report email settings."""

import logging
from typing import Any

from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

VALID_REPORT_TYPES = [
    "service_dashboard",
    "infra_dashboard",
    "bdp_metrics",
    "bdp_cost",
    "bdp_drift",
    "bdp_airflow",
]

REPORT_TYPE_LABELS = {
    "service_dashboard": "BDP 서비스 현황",
    "infra_dashboard": "BDP 인프라 현황",
    "bdp_metrics": "BDP Metrics",
    "bdp_cost": "BDP Cost",
    "bdp_drift": "BDP Drift",
    "bdp_airflow": "BDP Airflow",
}

FROM_EMAIL_MAP = {
    "service_dashboard": "bdp-dsbd-svc@hcs.com",
    "infra_dashboard": "bdp-dsbd-infr@hcs.com",
    "bdp_metrics": "bdp-metrics@hcs.com",
    "bdp_cost": "bdp-cost@hcs.com",
    "bdp_drift": "bdp-drift@hcs.com",
    "bdp_airflow": "bdp-airflow@hcs.com",
}

VALID_SCHEDULE_TYPES = ["daily", "weekly", "monthly"]


def _default_config(report_type: str) -> dict[str, Any]:
    """Return a default (disabled) config for the given report type."""
    return {
        "report_type": report_type,
        "enabled": False,
        "recipients_to": [],
        "recipients_cc": [],
        "schedule_type": "daily",
        "label": REPORT_TYPE_LABELS[report_type],
        "from_email": FROM_EMAIL_MAP[report_type],
        "created_at": None,
        "updated_at": None,
        "updated_by": None,
    }


class MailConfigService:
    """Manages mail configs for 6 report types."""

    def __init__(self, db: PortalDB):
        self._db = db

    def get_all(self) -> list[dict[str, Any]]:
        """Return configs for all 6 report types (filling defaults for missing ones)."""
        saved = {c["report_type"]: c for c in self._db.get_all_mail_configs()}
        result = []
        for rt in VALID_REPORT_TYPES:
            if rt in saved:
                cfg = saved[rt]
                cfg["label"] = REPORT_TYPE_LABELS[rt]
                cfg["from_email"] = FROM_EMAIL_MAP[rt]
                result.append(cfg)
            else:
                result.append(_default_config(rt))
        return result

    def get(self, report_type: str) -> dict[str, Any]:
        """Return config for a single report type."""
        cfg = self._db.get_mail_config(report_type)
        if cfg:
            cfg["label"] = REPORT_TYPE_LABELS[report_type]
            cfg["from_email"] = FROM_EMAIL_MAP[report_type]
            return cfg
        return _default_config(report_type)

    def upsert(
        self,
        report_type: str,
        enabled: bool,
        recipients_to: list[str],
        recipients_cc: list[str],
        schedule_type: str,
        updated_by: str | None = None,
    ) -> dict[str, Any]:
        """Create or update a mail config. Returns the saved config."""
        if report_type not in VALID_REPORT_TYPES:
            raise ValueError(f"Invalid report_type: {report_type}")
        if schedule_type not in VALID_SCHEDULE_TYPES:
            raise ValueError(f"Invalid schedule_type: {schedule_type}")
        self._db.upsert_mail_config(
            report_type=report_type,
            enabled=enabled,
            recipients_to=recipients_to,
            recipients_cc=recipients_cc,
            schedule_type=schedule_type,
            updated_by=updated_by,
        )
        return self.get(report_type)

    def delete(self, report_type: str) -> bool:
        """Delete a mail config (resets to default)."""
        return self._db.delete_mail_config(report_type)
