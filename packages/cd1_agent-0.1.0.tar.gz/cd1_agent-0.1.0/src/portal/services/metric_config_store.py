"""Metric Config Store - CRUD for bdp_metric_configs table."""

import logging
from datetime import datetime
from typing import Any

from src.common.timezone import KST
from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

BDP_METRIC_CONFIGS_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS bdp_metric_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_type TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    description TEXT,
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT,
    UNIQUE(service_type, metric_name)
);
"""

BDP_METRIC_CONFIGS_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS bdp_metric_configs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_type VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100),
    UNIQUE KEY uq_service_metric (service_type, metric_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class MetricConfigStore:
    """CRUD store for bdp_metric_configs table."""

    def __init__(self, db: PortalDB):
        self.db = db
        self.provider = db.provider

    def ensure_table(self) -> None:
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(BDP_METRIC_CONFIGS_TABLE_SQLITE)
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(BDP_METRIC_CONFIGS_TABLE_MYSQL)
            conn.commit()
        logger.info("bdp_metric_configs table ensured")

    def list_configs(self, service_type: str | None = None) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            if service_type:
                cur = conn.execute(
                    "SELECT * FROM bdp_metric_configs WHERE service_type = ? ORDER BY service_type, metric_name",
                    (service_type,),
                )
            else:
                cur = conn.execute(
                    "SELECT * FROM bdp_metric_configs ORDER BY service_type, metric_name"
                )
            return [dict(row) for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            if service_type:
                cur.execute(
                    "SELECT * FROM bdp_metric_configs WHERE service_type = %s ORDER BY service_type, metric_name",
                    (service_type,),
                )
            else:
                cur.execute("SELECT * FROM bdp_metric_configs ORDER BY service_type, metric_name")
            return list(cur.fetchall())

    def get_config(self, config_id: int) -> dict[str, Any] | None:
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("SELECT * FROM bdp_metric_configs WHERE id = ?", (config_id,))
            row = cur.fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM bdp_metric_configs WHERE id = %s", (config_id,))
            return cur.fetchone()

    def create_config(
        self,
        service_type: str,
        metric_name: str,
        enabled: int = 1,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> int:
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                """INSERT INTO bdp_metric_configs (service_type, metric_name, enabled, description, created_at, updated_at, updated_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (service_type, metric_name, enabled, description, now, now, updated_by),
            )
            conn.commit()
            return cur.lastrowid
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO bdp_metric_configs (service_type, metric_name, enabled, description, updated_by)
                   VALUES (%s, %s, %s, %s, %s)""",
                (service_type, metric_name, enabled, description, updated_by),
            )
        conn.commit()
        return cur.lastrowid

    def upsert_config(
        self,
        service_type: str,
        metric_name: str,
        enabled: int = 1,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> str:
        """Insert or update a config. Returns 'created' or 'updated'."""
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT id FROM bdp_metric_configs WHERE service_type = ? AND metric_name = ?",
                (service_type, metric_name),
            )
            existing = cur.fetchone()
            if existing:
                conn.execute(
                    """UPDATE bdp_metric_configs SET enabled = ?, description = ?, updated_at = ?, updated_by = ?
                       WHERE service_type = ? AND metric_name = ?""",
                    (enabled, description, now, updated_by, service_type, metric_name),
                )
                conn.commit()
                return "updated"
            else:
                conn.execute(
                    """INSERT INTO bdp_metric_configs (service_type, metric_name, enabled, description, created_at, updated_at, updated_by)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (service_type, metric_name, enabled, description, now, now, updated_by),
                )
                conn.commit()
                return "created"
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM bdp_metric_configs WHERE service_type = %s AND metric_name = %s",
                (service_type, metric_name),
            )
            existing = cur.fetchone()
            if existing:
                cur.execute(
                    """UPDATE bdp_metric_configs SET enabled = %s, description = %s, updated_by = %s
                       WHERE service_type = %s AND metric_name = %s""",
                    (enabled, description, updated_by, service_type, metric_name),
                )
                conn.commit()
                return "updated"
            else:
                cur.execute(
                    """INSERT INTO bdp_metric_configs (service_type, metric_name, enabled, description, updated_by)
                       VALUES (%s, %s, %s, %s, %s)""",
                    (service_type, metric_name, enabled, description, updated_by),
                )
                conn.commit()
                return "created"

    def update_config(self, config_id: int, **kwargs) -> bool:
        if self.provider == "mock":
            return False
        allowed = {"service_type", "metric_name", "enabled", "description", "updated_by"}
        fields = {k: v for k, v in kwargs.items() if k in allowed}
        if not fields:
            return False

        if self.provider == "sqlite":
            now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
            fields["updated_at"] = now
            set_clause = ", ".join(f"{k} = ?" for k in fields)
            values = list(fields.values()) + [config_id]
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(f"UPDATE bdp_metric_configs SET {set_clause} WHERE id = ?", values)
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            set_clause = ", ".join(f"{k} = %s" for k in fields)
            values = list(fields.values()) + [config_id]
            cur.execute(f"UPDATE bdp_metric_configs SET {set_clause} WHERE id = %s", values)
        conn.commit()
        return cur.rowcount > 0

    def delete_config(self, config_id: int) -> bool:
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("DELETE FROM bdp_metric_configs WHERE id = ?", (config_id,))
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM bdp_metric_configs WHERE id = %s", (config_id,))
        conn.commit()
        return cur.rowcount > 0

    def get_enabled_configs(self) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT * FROM bdp_metric_configs WHERE enabled = 1 ORDER BY service_type, metric_name"
            )
            return [dict(row) for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM bdp_metric_configs WHERE enabled = 1 ORDER BY service_type, metric_name"
            )
            return list(cur.fetchall())

    def get_service_types(self) -> list[str]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT DISTINCT service_type FROM bdp_metric_configs ORDER BY service_type"
            )
            return [row["service_type"] for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT DISTINCT service_type FROM bdp_metric_configs ORDER BY service_type"
            )
            return [row["service_type"] for row in cur.fetchall()]
