"""Alert Config Store - CRUD for bdp_alert_configs table.

서비스/메트릭별 이상 탐지 sensitivity, threshold 설정 관리.
"""

import logging
from typing import Any

from src.common.timezone import get_kst_now
from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

BDP_ALERT_CONFIGS_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS bdp_alert_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_type TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    sensitivity REAL NOT NULL DEFAULT 0.7,
    threshold_upper REAL,
    threshold_lower REAL,
    enabled INTEGER NOT NULL DEFAULT 1,
    description TEXT,
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT,
    UNIQUE(service_type, metric_name)
);
"""

BDP_ALERT_CONFIGS_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS bdp_alert_configs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_type VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    sensitivity DECIMAL(3,2) NOT NULL DEFAULT 0.70,
    threshold_upper DECIMAL(15,2),
    threshold_lower DECIMAL(15,2),
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100),
    UNIQUE KEY uq_alert_service_metric (service_type, metric_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class AlertConfigStore:
    """CRUD store for bdp_alert_configs table."""

    def __init__(self, db: PortalDB):
        self.db = db
        self.provider = db.provider

    def ensure_table(self) -> None:
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(BDP_ALERT_CONFIGS_TABLE_SQLITE)
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(BDP_ALERT_CONFIGS_TABLE_MYSQL)
            conn.commit()
        logger.info("bdp_alert_configs table ensured")

    def list_configs(self, service_type: str | None = None) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            if service_type:
                cur = conn.execute(
                    "SELECT * FROM bdp_alert_configs WHERE service_type = ? ORDER BY service_type, metric_name",
                    (service_type,),
                )
            else:
                cur = conn.execute(
                    "SELECT * FROM bdp_alert_configs ORDER BY service_type, metric_name"
                )
            return [dict(row) for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            if service_type:
                cur.execute(
                    "SELECT * FROM bdp_alert_configs WHERE service_type = %s ORDER BY service_type, metric_name",
                    (service_type,),
                )
            else:
                cur.execute("SELECT * FROM bdp_alert_configs ORDER BY service_type, metric_name")
            return [dict(row) for row in cur.fetchall()]

    def get_config(self, config_id: int) -> dict[str, Any] | None:
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("SELECT * FROM bdp_alert_configs WHERE id = ?", (config_id,))
            row = cur.fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM bdp_alert_configs WHERE id = %s", (config_id,))
            row = cur.fetchone()
            return dict(row) if row else None

    def upsert_config(
        self,
        service_type: str,
        metric_name: str,
        sensitivity: float = 0.7,
        threshold_upper: float | None = None,
        threshold_lower: float | None = None,
        enabled: bool = True,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> dict[str, Any]:
        now = get_kst_now().strftime("%Y-%m-%d %H:%M")

        if self.provider == "mock":
            return {
                "id": 1,
                "service_type": service_type,
                "metric_name": metric_name,
                "sensitivity": sensitivity,
                "threshold_upper": threshold_upper,
                "threshold_lower": threshold_lower,
                "enabled": int(enabled),
                "description": description,
                "updated_by": updated_by,
            }

        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(
                """INSERT INTO bdp_alert_configs
                   (service_type, metric_name, sensitivity, threshold_upper, threshold_lower,
                    enabled, description, updated_by, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(service_type, metric_name)
                   DO UPDATE SET
                       sensitivity = excluded.sensitivity,
                       threshold_upper = excluded.threshold_upper,
                       threshold_lower = excluded.threshold_lower,
                       enabled = excluded.enabled,
                       description = excluded.description,
                       updated_by = excluded.updated_by,
                       updated_at = excluded.updated_at
                """,
                (
                    service_type,
                    metric_name,
                    sensitivity,
                    threshold_upper,
                    threshold_lower,
                    int(enabled),
                    description,
                    updated_by,
                    now,
                ),
            )
            conn.commit()
        else:
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO bdp_alert_configs
                       (service_type, metric_name, sensitivity, threshold_upper, threshold_lower,
                        enabled, description, updated_by)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                       ON DUPLICATE KEY UPDATE
                           sensitivity = VALUES(sensitivity),
                           threshold_upper = VALUES(threshold_upper),
                           threshold_lower = VALUES(threshold_lower),
                           enabled = VALUES(enabled),
                           description = VALUES(description),
                           updated_by = VALUES(updated_by)
                    """,
                    (
                        service_type,
                        metric_name,
                        sensitivity,
                        threshold_upper,
                        threshold_lower,
                        int(enabled),
                        description,
                        updated_by,
                    ),
                )
            conn.commit()

        # 방금 upsert한 레코드 반환
        return self._get_by_key(service_type, metric_name) or {
            "service_type": service_type,
            "metric_name": metric_name,
        }

    def delete_config(self, config_id: int) -> bool:
        if self.provider == "mock":
            return True
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("DELETE FROM bdp_alert_configs WHERE id = ?", (config_id,))
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM bdp_alert_configs WHERE id = %s", (config_id,))
        conn.commit()
        return cur.rowcount > 0

    def _get_by_key(self, service_type: str, metric_name: str) -> dict[str, Any] | None:
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT * FROM bdp_alert_configs WHERE service_type = ? AND metric_name = ?",
                (service_type, metric_name),
            )
            row = cur.fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM bdp_alert_configs WHERE service_type = %s AND metric_name = %s",
                (service_type, metric_name),
            )
            row = cur.fetchone()
            return dict(row) if row else None
