"""Airflow Report service wrapper for Portal.

Wraps the existing AirflowReportStore for portal use.
Uses direct module loading to avoid triggering heavy __init__.py imports
from agent packages.
"""

import logging
from typing import Any, List, Optional

from src.portal.services._import_helper import load_generator_module, load_report_store

logger = logging.getLogger(__name__)

_store_module = load_report_store("bdp_airflow", "bdp_airflow/services/report_store.py")
_REPORT_AVAILABLE = _store_module is not None
AirflowReportStore = getattr(_store_module, "AirflowReportStore", None)
AirflowReport = getattr(_store_module, "AirflowReport", None)

_gen_module = load_generator_module(
    "bdp_airflow",
    "bdp_airflow/services/daily_report_generator.py",
)
AirflowDailyReportGenerator = getattr(_gen_module, "AirflowDailyReportGenerator", None)


def is_airflow_report_available() -> bool:
    return _REPORT_AVAILABLE


def create_airflow_report_store(
    provider: str, db: Optional[str] = None, secret_id: Optional[str] = None
) -> Optional[Any]:
    """Create an AirflowReportStore if the package is available."""
    if not _REPORT_AVAILABLE:
        return None
    store = AirflowReportStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


class AirflowReportService:
    """Portal wrapper around AirflowReportStore."""

    def __init__(self, store: Optional[Any] = None):
        self.store = store
        self.available = store is not None

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Any]:
        if not self.available:
            return []
        return self.store.list_reports(
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            offset=offset,
        )

    def get_report(self, report_id: str) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.get_report(report_id)

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        if not self.available:
            return 0
        return self.store.get_report_count(start_date=start_date, end_date=end_date)

    def render_html(self, report_id: str) -> Optional[str]:
        """DB 구조화 데이터로 HTML 리포트 재생성."""
        if not self.available or AirflowDailyReportGenerator is None:
            return None
        report = self.store.get_report(report_id)
        if report is None:
            return None
        if not getattr(report, "scenarios_json", None):
            return getattr(report, "html_report", None)
        generator = AirflowDailyReportGenerator()
        return generator.generate_from_db(report)
