"""Drift Config Service - business logic for drift configuration management."""

import csv
import io
import json
import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional

from src.portal.services.drift_config_store import DriftConfigStore

logger = logging.getLogger(__name__)

# Per-resource-type configuration: labels, check items, guidance
# value_type: "enum" (select), "text" (input), "number" (input+unit), "monitor" (change detection only)
RESOURCE_TYPE_CONFIGS: Dict[str, Dict[str, Any]] = {
    "s3": {
        "label": "S3 버킷",
        "id_label": "버킷명",
        "id_placeholder": "my-data-bucket",
        "description": "S3 버킷의 보안 및 구성 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "bucket_policy", "label": "버킷 정책", "default": True,
             "value_type": "monitor"},
            {"key": "versioning", "label": "버전 관리", "default": True,
             "value_type": "enum", "options": ["Enabled", "Suspended"]},
            {"key": "encryption", "label": "서버측 암호화 (SSE)", "default": True,
             "value_type": "enum", "options": ["AES256", "aws:kms", "aws:kms:dsse"]},
            {"key": "public_access_block", "label": "퍼블릭 액세스 차단", "default": True,
             "value_type": "enum", "options": ["전체 차단", "일부 허용"]},
            {"key": "lifecycle", "label": "수명 주기 규칙", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "cors", "label": "CORS 설정", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "logging", "label": "액세스 로깅", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "replication", "label": "복제 규칙", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "notification", "label": "이벤트 알림", "default": False,
             "value_type": "enum", "options": ["설정됨", "없음"]},
        ],
    },
    "glue": {
        "label": "Glue 카탈로그",
        "id_label": "데이터베이스/테이블명",
        "id_placeholder": "default/analytics_table",
        "description": "Glue Data Catalog의 테이블 스키마 및 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "table_schema", "label": "테이블 스키마 (컬럼 정의)", "default": True,
             "value_type": "number", "unit": "개 컬럼", "min": 1, "max": 10000,
             "placeholder": "15"},
            {"key": "partition_keys", "label": "파티션 키", "default": True,
             "value_type": "number", "unit": "개", "min": 0, "max": 20,
             "placeholder": "3"},
            {"key": "storage_descriptor", "label": "스토리지 설정 (위치, 형식)", "default": True,
             "value_type": "monitor"},
            {"key": "table_properties", "label": "테이블 속성", "default": False,
             "value_type": "monitor"},
            {"key": "serde_info", "label": "SerDe 정보", "default": False,
             "value_type": "text",
             "placeholder": "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"},
        ],
    },
    "athena": {
        "label": "Athena 워크그룹",
        "id_label": "워크그룹명",
        "id_placeholder": "primary",
        "description": "Athena 워크그룹의 쿼리 설정 및 보안 구성 변경을 감지합니다.",
        "check_items": [
            {"key": "result_location", "label": "쿼리 결과 위치", "default": True,
             "value_type": "text", "placeholder": "s3://my-bucket/athena-results/"},
            {"key": "encryption", "label": "결과 암호화 설정", "default": True,
             "value_type": "enum", "options": ["SSE_S3", "SSE_KMS", "CSE_KMS"]},
            {"key": "query_limit", "label": "데이터 사용량 제한", "default": False,
             "value_type": "number", "unit": "MB", "min": 0, "max": 1000000,
             "placeholder": "10000"},
            {"key": "engine_version", "label": "엔진 버전", "default": True,
             "value_type": "enum", "options": ["Athena engine version 2", "Athena engine version 3"]},
            {"key": "workgroup_config", "label": "워크그룹 일반 설정", "default": False,
             "value_type": "enum", "options": ["워크그룹 설정 강제", "클라이언트 설정 허용"]},
        ],
    },
    "msk": {
        "label": "MSK 클러스터",
        "id_label": "클러스터명",
        "id_placeholder": "my-kafka-cluster",
        "description": "MSK 클러스터의 브로커 설정 및 보안 구성 변경을 감지합니다.",
        "check_items": [
            {"key": "broker_config", "label": "브로커 설정", "default": True,
             "value_type": "monitor"},
            {"key": "encryption", "label": "전송 암호화", "default": True,
             "value_type": "enum", "options": ["TLS", "TLS_PLAINTEXT", "PLAINTEXT"]},
            {"key": "authentication", "label": "인증 설정 (IAM, SASL)", "default": True,
             "value_type": "enum", "options": ["IAM", "SCRAM", "TLS", "UNAUTHENTICATED"]},
            {"key": "monitoring", "label": "모니터링 설정", "default": False,
             "value_type": "enum",
             "options": ["DEFAULT", "PER_BROKER", "PER_TOPIC_PER_BROKER", "PER_TOPIC_PER_PARTITION"]},
            {"key": "storage", "label": "스토리지 설정", "default": False,
             "value_type": "number", "unit": "GiB", "min": 1, "max": 16384,
             "placeholder": "100"},
            {"key": "networking", "label": "네트워크 설정", "default": False,
             "value_type": "monitor"},
        ],
    },
    "mwaa": {
        "label": "MWAA (Airflow)",
        "id_label": "환경 이름",
        "id_placeholder": "my-airflow-env",
        "description": "MWAA(Managed Workflows for Apache Airflow) 환경의 버전, 용량, 네트워크 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "airflow_version", "label": "Airflow 버전", "default": True,
             "value_type": "enum", "options": ["2.6.3", "2.7.2", "2.8.1", "2.9.2", "2.10.1", "2.10.3"]},
            {"key": "environment_class", "label": "환경 클래스", "default": True,
             "value_type": "enum", "options": ["mw1.micro", "mw1.small", "mw1.medium", "mw1.large", "mw1.xlarge", "mw1.2xlarge"]},
            {"key": "max_workers", "label": "최대 워커 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 25, "placeholder": "10"},
            {"key": "min_workers", "label": "최소 워커 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 25, "placeholder": "1"},
            {"key": "schedulers", "label": "스케줄러 수", "default": False,
             "value_type": "number", "unit": "개", "min": 2, "max": 5, "placeholder": "2"},
            {"key": "webserver_access_mode", "label": "웹 서버 액세스 모드", "default": True,
             "value_type": "enum", "options": ["PRIVATE_ONLY", "PUBLIC_ONLY"]},
            {"key": "logging_config", "label": "로깅 설정", "default": False,
             "value_type": "monitor"},
            {"key": "network_config", "label": "네트워크 설정 (VPC, 서브넷)", "default": False,
             "value_type": "monitor"},
            {"key": "execution_role", "label": "실행 역할", "default": False,
             "value_type": "text", "placeholder": "arn:aws:iam::123456789012:role/..."},
            {"key": "requirements", "label": "Requirements 패키지", "default": False,
             "value_type": "monitor"},
            {"key": "plugins", "label": "플러그인", "default": False,
             "value_type": "monitor"},
        ],
    },
    "lambda": {
        "label": "Lambda 함수",
        "id_label": "함수명",
        "id_placeholder": "my-data-processor",
        "description": "Lambda 함수의 런타임 설정 및 구성 변경을 감지합니다.",
        "check_items": [
            {"key": "runtime", "label": "런타임 버전", "default": True,
             "value_type": "enum",
             "options": ["python3.9", "python3.10", "python3.11", "python3.12", "python3.13",
                         "nodejs18.x", "nodejs20.x", "nodejs22.x", "java17", "java21",
                         "dotnet8", "ruby3.3", "provided.al2023"]},
            {"key": "memory", "label": "메모리 크기", "default": True,
             "value_type": "number", "unit": "MB", "min": 128, "max": 10240, "step": 64,
             "placeholder": "256"},
            {"key": "timeout", "label": "제한 시간", "default": True,
             "value_type": "number", "unit": "초", "min": 1, "max": 900,
             "placeholder": "30"},
            {"key": "env_vars", "label": "환경 변수", "default": True,
             "value_type": "monitor"},
            {"key": "vpc_config", "label": "VPC 설정", "default": False,
             "value_type": "enum", "options": ["VPC 연결", "VPC 미연결"]},
            {"key": "layers", "label": "레이어", "default": False,
             "value_type": "number", "unit": "개", "min": 0, "max": 5,
             "placeholder": "0"},
            {"key": "concurrency", "label": "동시성 설정", "default": False,
             "value_type": "number", "unit": "개", "min": 0, "max": 1000,
             "placeholder": "100"},
            {"key": "iam_role", "label": "IAM 실행 역할", "default": False,
             "value_type": "text", "placeholder": "arn:aws:iam::123456789012:role/..."},
        ],
    },
    "vpc-sg": {
        "label": "VPC 보안 그룹",
        "id_label": "보안 그룹 ID",
        "id_placeholder": "sg-0123456789abcdef0",
        "description": "VPC 보안 그룹의 인바운드/아웃바운드 규칙 변경을 감지합니다.",
        "check_items": [
            {"key": "inbound_rules", "label": "인바운드 규칙", "default": True,
             "value_type": "number", "unit": "개", "min": 0, "max": 200,
             "placeholder": "5"},
            {"key": "outbound_rules", "label": "아웃바운드 규칙", "default": True,
             "value_type": "number", "unit": "개", "min": 0, "max": 200,
             "placeholder": "1"},
            {"key": "tags", "label": "태그", "default": False,
             "value_type": "monitor"},
        ],
    },
    "emr-cluster": {
        "label": "EMR 클러스터",
        "id_label": "클러스터 ID",
        "id_placeholder": "j-1234567890ABC",
        "description": "EMR on EC2 클러스터의 릴리스, 인스턴스, 보안 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "release_label", "label": "릴리스 버전", "default": True,
             "value_type": "enum",
             "options": ["emr-7.7.0", "emr-7.6.0", "emr-7.5.0", "emr-7.4.0", "emr-7.3.0",
                         "emr-7.2.0", "emr-7.1.0", "emr-7.0.0",
                         "emr-6.15.0", "emr-6.14.0", "emr-6.13.0"]},
            {"key": "master_instance_type", "label": "마스터 인스턴스 유형", "default": True,
             "value_type": "enum",
             "options": ["m5.xlarge", "m5.2xlarge", "m5.4xlarge", "m5.8xlarge",
                         "m6g.xlarge", "m6g.2xlarge", "m6g.4xlarge",
                         "r5.xlarge", "r5.2xlarge", "r5.4xlarge",
                         "c5.xlarge", "c5.2xlarge", "c5.4xlarge"]},
            {"key": "core_instance_count", "label": "코어 인스턴스 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 500,
             "placeholder": "3"},
            {"key": "auto_termination", "label": "자동 종료", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "managed_scaling", "label": "관리형 스케일링", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "logging", "label": "S3 로깅", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "step_concurrency", "label": "스텝 동시성", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 256,
             "placeholder": "1"},
            {"key": "applications", "label": "애플리케이션 (Spark, Hive 등)", "default": False,
             "value_type": "monitor"},
            {"key": "security_config", "label": "보안 구성", "default": False,
             "value_type": "monitor"},
            {"key": "bootstrap_actions", "label": "부트스트랩 액션", "default": False,
             "value_type": "monitor"},
        ],
    },
    "emr-serverless": {
        "label": "EMR Serverless",
        "id_label": "애플리케이션 ID",
        "id_placeholder": "00abcdef12345678",
        "description": "EMR Serverless 애플리케이션의 용량, 네트워크, 자동화 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "release_label", "label": "릴리스 버전", "default": True,
             "value_type": "enum",
             "options": ["emr-7.7.0", "emr-7.6.0", "emr-7.5.0", "emr-7.4.0", "emr-7.3.0",
                         "emr-7.2.0", "emr-7.1.0", "emr-7.0.0",
                         "emr-6.15.0", "emr-6.14.0", "emr-6.13.0"]},
            {"key": "type", "label": "애플리케이션 유형", "default": True,
             "value_type": "enum", "options": ["Spark", "Hive"]},
            {"key": "architecture", "label": "CPU 아키텍처", "default": True,
             "value_type": "enum", "options": ["ARM64", "X86_64"]},
            {"key": "auto_start", "label": "자동 시작", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "auto_stop", "label": "자동 중지", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "auto_stop_idle_timeout", "label": "자동 중지 유휴 시간", "default": False,
             "value_type": "number", "unit": "분", "min": 1, "max": 10080,
             "placeholder": "15"},
            {"key": "max_capacity_cpu", "label": "최대 CPU 용량", "default": False,
             "value_type": "number", "unit": "vCPU", "min": 1, "max": 4000,
             "placeholder": "400"},
            {"key": "max_capacity_memory", "label": "최대 메모리 용량", "default": False,
             "value_type": "number", "unit": "GB", "min": 1, "max": 30000,
             "placeholder": "3000"},
            {"key": "network_config", "label": "네트워크 설정 (VPC, 서브넷)", "default": False,
             "value_type": "monitor"},
            {"key": "monitoring", "label": "모니터링 설정", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
        ],
    },
    "eks": {
        "label": "EKS 클러스터",
        "id_label": "클러스터명",
        "id_placeholder": "my-eks-cluster",
        "description": "EKS 클러스터의 버전, 네트워킹, 로깅 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "cluster_version", "label": "클러스터 버전", "default": True,
             "value_type": "enum",
             "options": ["1.27", "1.28", "1.29", "1.30", "1.31", "1.32", "1.33", "1.34", "1.35"]},
            {"key": "endpoint_access", "label": "엔드포인트 액세스 설정", "default": True,
             "value_type": "enum", "options": ["Public", "Private", "Public and Private"]},
            {"key": "logging", "label": "컨트롤 플레인 로깅", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "encryption", "label": "시크릿 암호화", "default": True,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "networking", "label": "네트워킹 (서브넷, 보안 그룹)", "default": False,
             "value_type": "monitor"},
            {"key": "node_groups", "label": "노드 그룹 설정", "default": False,
             "value_type": "number", "unit": "개", "min": 0, "max": 30,
             "placeholder": "2"},
            {"key": "addons", "label": "애드온", "default": False,
             "value_type": "number", "unit": "개", "min": 0, "max": 50,
             "placeholder": "3"},
        ],
    },
    "sagemaker-pipeline": {
        "label": "SageMaker 파이프라인",
        "id_label": "파이프라인명",
        "id_placeholder": "my-ml-pipeline",
        "description": "SageMaker 파이프라인의 정의 및 파라미터 변경을 감지합니다.",
        "check_items": [
            {"key": "pipeline_definition", "label": "파이프라인 정의", "default": True,
             "value_type": "monitor"},
            {"key": "role_arn", "label": "IAM 역할", "default": True,
             "value_type": "text", "placeholder": "arn:aws:iam::123456789012:role/..."},
            {"key": "parameters", "label": "파이프라인 파라미터", "default": False,
             "value_type": "number", "unit": "개", "min": 0, "max": 200,
             "placeholder": "5"},
            {"key": "tags", "label": "태그", "default": False,
             "value_type": "monitor"},
        ],
    },
    "sagemaker-endpoint": {
        "label": "SageMaker 엔드포인트",
        "id_label": "엔드포인트명",
        "id_placeholder": "my-model-endpoint",
        "description": "SageMaker 엔드포인트의 인스턴스 및 모델 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "instance_type", "label": "인스턴스 유형", "default": True,
             "value_type": "enum",
             "options": ["ml.t2.medium", "ml.m5.large", "ml.m5.xlarge", "ml.m5.2xlarge",
                         "ml.c5.large", "ml.c5.xlarge", "ml.p3.2xlarge", "ml.g4dn.xlarge"]},
            {"key": "instance_count", "label": "인스턴스 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 100,
             "placeholder": "1"},
            {"key": "model_name", "label": "모델명", "default": True,
             "value_type": "text", "placeholder": "my-model-v1"},
            {"key": "auto_scaling", "label": "오토스케일링 정책", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "data_capture", "label": "데이터 캡처 설정", "default": False,
             "value_type": "enum", "options": ["Enabled", "Disabled"]},
            {"key": "tags", "label": "태그", "default": False,
             "value_type": "monitor"},
        ],
    },
    "sagemaker-model": {
        "label": "SageMaker 모델",
        "id_label": "모델명",
        "id_placeholder": "my-trained-model",
        "description": "SageMaker 모델의 아티팩트 및 컨테이너 설정 변경을 감지합니다.",
        "check_items": [
            {"key": "container_image", "label": "컨테이너 이미지", "default": True,
             "value_type": "text", "placeholder": "123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/my-image:latest"},
            {"key": "model_artifacts", "label": "모델 아티팩트 위치", "default": True,
             "value_type": "text", "placeholder": "s3://my-bucket/models/model.tar.gz"},
            {"key": "vpc_config", "label": "VPC 설정", "default": False,
             "value_type": "enum", "options": ["VPC 연결", "VPC 미연결"]},
            {"key": "execution_role", "label": "실행 역할", "default": True,
             "value_type": "text", "placeholder": "arn:aws:iam::123456789012:role/..."},
            {"key": "tags", "label": "태그", "default": False,
             "value_type": "monitor"},
        ],
    },
    "quota-emr": {
        "label": "EMR 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "EMR 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "active_clusters", "label": "활성 클러스터 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "500"},
            {"key": "active_instances_per_group", "label": "인스턴스 그룹당 인스턴스 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 100000, "placeholder": "2000"},
        ],
    },
    "quota-sagemaker": {
        "label": "SageMaker 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "SageMaker 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "endpoints", "label": "엔드포인트 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "4"},
            {"key": "training_jobs", "label": "동시 학습 작업 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "processing_jobs", "label": "동시 처리 작업 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "notebook_instances", "label": "노트북 인스턴스 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "models", "label": "모델 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 100000, "placeholder": "5000"},
        ],
    },
    "quota-glue": {
        "label": "Glue 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "Glue 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "concurrent_job_runs", "label": "동시 작업 실행 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "200"},
            {"key": "crawlers_per_account", "label": "계정당 크롤러 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "1000"},
            {"key": "jobs_per_account", "label": "계정당 작업 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "1000"},
            {"key": "triggers_per_account", "label": "계정당 트리거 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "500"},
            {"key": "dpus_per_account", "label": "계정당 DPU 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "1000"},
            {"key": "concurrent_crawlers", "label": "동시 크롤러 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 1000, "placeholder": "30"},
        ],
    },
    "quota-athena": {
        "label": "Athena 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "Athena 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "active_ddl_queries", "label": "활성 DDL 쿼리 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 1000, "placeholder": "20"},
            {"key": "active_dml_queries", "label": "활성 DML 쿼리 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "query_timeout", "label": "쿼리 타임아웃", "default": False,
             "value_type": "number", "unit": "분", "min": 1, "max": 1440, "placeholder": "30"},
        ],
    },
    "quota-lambda": {
        "label": "Lambda 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "Lambda 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "concurrent_executions", "label": "동시 실행 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 100000, "placeholder": "1000"},
            {"key": "function_storage", "label": "함수 스토리지", "default": True,
             "value_type": "number", "unit": "GB", "min": 1, "max": 10000, "placeholder": "75"},
            {"key": "elastic_network_interfaces", "label": "탄력적 네트워크 인터페이스 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "250"},
        ],
    },
    "quota-s3": {
        "label": "S3 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "S3 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "buckets_per_account", "label": "계정당 버킷 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 1000000, "placeholder": "100"},
            {"key": "access_points", "label": "액세스 포인트 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 100000, "placeholder": "10000"},
            {"key": "multi_region_access_points", "label": "멀티리전 액세스 포인트 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
        ],
    },
    "quota-msk": {
        "label": "MSK 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "MSK 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "clusters_per_account", "label": "계정당 클러스터 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "brokers_per_cluster", "label": "클러스터당 브로커 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 1000, "placeholder": "30"},
            {"key": "configurations", "label": "MSK 설정 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
        ],
    },
    "quota-mwaa": {
        "label": "MWAA 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "MWAA 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "environments_per_account", "label": "계정당 환경 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 100, "placeholder": "10"},
            {"key": "workers_per_environment", "label": "환경당 워커 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 100, "placeholder": "25"},
        ],
    },
    "quota-eks": {
        "label": "EKS 서비스 할당량",
        "id_label": "계정 식별자",
        "id_placeholder": "default",
        "description": "EKS 서비스의 할당량 한도 변경을 감지합니다.",
        "check_items": [
            {"key": "clusters_per_region", "label": "리전당 클러스터 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "100"},
            {"key": "managed_node_groups", "label": "관리형 노드 그룹 수", "default": True,
             "value_type": "number", "unit": "개", "min": 1, "max": 1000, "placeholder": "30"},
            {"key": "fargate_profiles", "label": "Fargate 프로필 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 100, "placeholder": "10"},
            {"key": "nodes_per_managed_group", "label": "관리형 그룹당 노드 수", "default": False,
             "value_type": "number", "unit": "개", "min": 1, "max": 10000, "placeholder": "450"},
        ],
    },
}

# Sorted list of resource type keys
RESOURCE_TYPES = sorted(RESOURCE_TYPE_CONFIGS.keys())


def _parse_check_items(raw: str) -> Dict[str, Any]:
    """Parse check_items JSON. Handles both legacy array and new dict format."""
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}
    # Legacy format: ["key1", "key2"] -> {"key1": None, "key2": None}
    if isinstance(parsed, list):
        return {k: None for k in parsed}
    return parsed if isinstance(parsed, dict) else {}


def _resolve_check_item_labels(resource_type: str, check_dict: Dict[str, Any]) -> List[str]:
    """Resolve check item keys to their Korean labels."""
    cfg = RESOURCE_TYPE_CONFIGS.get(resource_type, {})
    key_to_label = {item["key"]: item["label"] for item in cfg.get("check_items", [])}
    return [key_to_label.get(k, k) for k in check_dict.keys()]


class ValidationError(Exception):
    """Raised when drift config input fails validation."""

    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__(str(errors))


def validate_config_input(
    resource_type: str | None,
    resource_id: str | None,
    description: str | None = None,
) -> dict[str, str]:
    """Validate and sanitize config input fields. Returns dict of cleaned values.

    Raises ValidationError if validation fails.
    """
    errors: dict[str, str] = {}
    cleaned: dict[str, str] = {}

    # resource_type: required, max 50, strip+lowercase
    rt = (resource_type or "").strip().lower()
    if not rt:
        errors["resource_type"] = "리소스 유형을 선택해주세요."
    elif len(rt) > 50:
        errors["resource_type"] = "리소스 유형은 50자 이내여야 합니다."
    cleaned["resource_type"] = rt

    # resource_id: required, max 200, strip
    ri = (resource_id or "").strip()
    if not ri:
        errors["resource_id"] = "리소스 ID를 입력해주세요."
    elif len(ri) > 200:
        errors["resource_id"] = "리소스 ID는 200자 이내여야 합니다."
    cleaned["resource_id"] = ri

    # description: optional, max 500, strip
    desc = (description or "").strip() or None
    if desc and len(desc) > 500:
        errors["description"] = "설명은 500자 이내여야 합니다."
    cleaned["description"] = desc

    if errors:
        raise ValidationError(errors)
    return cleaned


class DriftConfigService:
    """Business logic for drift configuration management."""

    def __init__(self, store: DriftConfigStore):
        self.store = store

    def _enrich_config(self, cfg: Dict[str, Any]) -> None:
        """Enrich a config dict with parsed check_items, keys, and labels."""
        raw = cfg.get("check_items") or "{}"
        check_dict = _parse_check_items(raw)
        cfg["check_items_dict"] = check_dict
        cfg["check_items_keys"] = list(check_dict.keys())
        cfg["check_items_labels"] = _resolve_check_item_labels(cfg["resource_type"], check_dict)

    def list_configs(self, resource_type: Optional[str] = None) -> List[Dict[str, Any]]:
        configs = self.store.list_configs(resource_type)
        for cfg in configs:
            self._enrich_config(cfg)
        return configs

    def get_config(self, config_id: int) -> Optional[Dict[str, Any]]:
        cfg = self.store.get_config(config_id)
        if cfg:
            self._enrich_config(cfg)
        return cfg

    def create_config(
        self,
        resource_type: str,
        resource_id: str,
        check_items: Optional[str] = None,
        enabled: int = 1,
        description: Optional[str] = None,
        updated_by: Optional[str] = None,
    ) -> int:
        cleaned = validate_config_input(resource_type, resource_id, description)
        return self.store.create_config(
            cleaned["resource_type"],
            cleaned["resource_id"],
            check_items=check_items,
            enabled=enabled,
            description=cleaned["description"],
            updated_by=updated_by,
        )

    def update_config(self, config_id: int, **kwargs) -> bool:
        cleaned = validate_config_input(
            kwargs.get("resource_type"),
            kwargs.get("resource_id"),
            kwargs.get("description"),
        )
        kwargs["resource_type"] = cleaned["resource_type"]
        kwargs["resource_id"] = cleaned["resource_id"]
        kwargs["description"] = cleaned["description"]
        return self.store.update_config(config_id, **kwargs)

    def delete_config(self, config_id: int) -> bool:
        return self.store.delete_config(config_id)

    def get_enabled_by_resource_type(self) -> Dict[str, List[str]]:
        """Return enabled resource IDs grouped by resource_type.

        Used by handler to determine which resources to monitor.
        Returns: {resource_type: [resource_id, ...]}
        """
        configs = self.store.get_enabled_configs()
        result: Dict[str, List[str]] = defaultdict(list)
        for cfg in configs:
            result[cfg["resource_type"]].append(cfg["resource_id"])
        return dict(result)

    def import_csv(self, csv_content: str, updated_by: Optional[str] = None) -> Dict[str, int]:
        """Import CSV content into DB.

        Expected CSV columns: 리소스타입, 리소스ID, 감시항목, 적용여부, 설명
        감시항목 is pipe-separated keys (e.g. bucket_policy|versioning|encryption)
        """
        counts = {"created": 0, "updated": 0, "skipped": 0}
        reader = csv.DictReader(io.StringIO(csv_content))
        for row in reader:
            try:
                raw_type = row.get("리소스타입", "").strip()
                resource_id = row.get("리소스ID", "").strip()
                raw_checks = row.get("감시항목", "").strip()
                enabled_str = row.get("적용여부", "X").strip()
                description = row.get("설명", "").strip()

                if not raw_type or not resource_id:
                    counts["skipped"] += 1
                    continue

                resource_type = raw_type.strip().lower()
                enabled = 1 if enabled_str == "O" else 0
                # Parse "key=value|key=value|key" format into dict
                check_dict: Dict[str, Any] = {}
                if raw_checks:
                    for item in raw_checks.split("|"):
                        item = item.strip()
                        if not item:
                            continue
                        if "=" in item:
                            k, v = item.split("=", 1)
                            val = v.strip()
                            # Try numeric conversion
                            try:
                                val = int(val)
                            except ValueError:
                                try:
                                    val = float(val)
                                except ValueError:
                                    pass
                            check_dict[k.strip()] = val
                        else:
                            check_dict[item] = None
                check_items_json = json.dumps(check_dict)

                result = self.store.upsert_config(
                    resource_type=resource_type,
                    resource_id=resource_id,
                    check_items=check_items_json,
                    enabled=enabled,
                    description=description or None,
                    updated_by=updated_by,
                )
                counts[result] = counts.get(result, 0) + 1
            except Exception as e:
                logger.warning(f"Skipping row due to error: {e}")
                counts["skipped"] += 1

        return counts

    def export_csv(self) -> str:
        """Export all configs as CSV string."""
        configs = self.store.list_configs()
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["리소스타입", "리소스ID", "감시항목", "적용여부", "설명"])
        for cfg in configs:
            raw = cfg.get("check_items") or "{}"
            check_dict = _parse_check_items(raw)
            # Format as "key=value|key=value|key" (monitor items have no =value)
            parts = []
            for k, v in check_dict.items():
                if v is not None:
                    parts.append(f"{k}={v}")
                else:
                    parts.append(k)
            writer.writerow([
                cfg["resource_type"],
                cfg["resource_id"],
                "|".join(parts),
                "O" if cfg["enabled"] else "X",
                cfg.get("description") or "",
            ])
        return output.getvalue()

    def get_resource_types(self) -> List[str]:
        return self.store.get_resource_types()
