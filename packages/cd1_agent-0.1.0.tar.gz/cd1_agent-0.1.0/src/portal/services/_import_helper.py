"""Agent report store 모듈 직접 로더.

에이전트 패키지의 __init__.py가 handler → langchain_core 등
무거운 의존성을 끌어오기 때문에, report_store.py만 직접 로드.
bdp_common/stores/base.py는 stdlib만 사용하므로 안전.
"""

import importlib.util
import logging
import sys
import types
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_AGENTS_DIR = Path(__file__).resolve().parents[2] / "agent_server"


def _load_module_from_file(name: str, file_path: str) -> types.ModuleType:
    """파일 경로로부터 모듈을 직접 로드 (패키지 __init__.py 우회)."""
    spec = importlib.util.spec_from_file_location(name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create spec for {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _ensure_bdp_common_base() -> None:
    """bdp_common.stores.base 모듈을 sys.modules에 등록.

    report_store.py가 'from bdp_common.stores.base import ...'를 사용하므로
    부모 패키지 엔트리도 함께 등록.
    """
    if "bdp_common.stores.base" in sys.modules:
        return

    base_path = _AGENTS_DIR / "bdp_common" / "stores" / "base.py"
    if not base_path.exists():
        raise ImportError(f"bdp_common/stores/base.py not found at {base_path}")

    # 부모 패키지 스텁 등록
    for pkg_name in ["bdp_common", "bdp_common.stores"]:
        if pkg_name not in sys.modules:
            stub = types.ModuleType(pkg_name)
            stub.__path__ = []  # type: ignore
            sys.modules[pkg_name] = stub

    _load_module_from_file("bdp_common.stores.base", str(base_path))


def _ensure_dependency_modules(dep_modules: list[tuple[str, str]]) -> None:
    """report_store.py가 의존하는 추가 모듈을 미리 로드.

    Args:
        dep_modules: (모듈명, 상대파일경로) 리스트
    """
    for mod_name, rel_path in dep_modules:
        if mod_name in sys.modules:
            continue
        full_path = _AGENTS_DIR / rel_path
        if full_path.exists():
            # 부모 패키지 스텁 등록
            parts = mod_name.split(".")
            for i in range(1, len(parts)):
                parent = ".".join(parts[:i])
                if parent not in sys.modules:
                    stub = types.ModuleType(parent)
                    stub.__path__ = []  # type: ignore
                    sys.modules[parent] = stub
            _load_module_from_file(mod_name, str(full_path))


def _ensure_bdp_common_reports() -> None:
    """bdp_common.reports 모듈을 sys.modules에 등록.

    Generator 모듈이 'from bdp_common.reports.base import ...'를 사용하므로
    base.py, styles.py 및 부모 패키지를 등록.
    """
    if "bdp_common.reports.base" in sys.modules:
        return

    reports_dir = _AGENTS_DIR / "bdp_common" / "reports"

    # styles.py 먼저 (base.py가 styles를 import)
    styles_path = reports_dir / "styles.py"
    if not styles_path.exists():
        raise ImportError(f"bdp_common/reports/styles.py not found at {styles_path}")

    # 부모 패키지 스텁 등록
    for pkg_name in ["bdp_common", "bdp_common.reports"]:
        if pkg_name not in sys.modules:
            stub = types.ModuleType(pkg_name)
            stub.__path__ = []  # type: ignore
            sys.modules[pkg_name] = stub

    _load_module_from_file("bdp_common.reports.styles", str(styles_path))

    base_path = reports_dir / "base.py"
    if not base_path.exists():
        raise ImportError(f"bdp_common/reports/base.py not found at {base_path}")
    _load_module_from_file("bdp_common.reports.base", str(base_path))


def load_report_store(
    agent_name: str,
    store_path: str,
    dep_modules: Optional[list[tuple[str, str]]] = None,
) -> Optional[types.ModuleType]:
    """에이전트 report_store 모듈을 직접 로드.

    Args:
        agent_name: 에이전트 이름 (로깅용)
        store_path: report_store.py 파일의 상대 경로 (AGENTS_DIR 기준)
        dep_modules: 추가 의존 모듈 [(모듈명, 상대경로), ...]

    Returns:
        로드된 모듈 또는 실패 시 None
    """
    try:
        _ensure_bdp_common_base()

        if dep_modules:
            _ensure_dependency_modules(dep_modules)

        full_path = _AGENTS_DIR / store_path
        if not full_path.exists():
            logger.warning(f"{agent_name} report_store not found: {full_path}")
            return None

        module_name = f"_portal_{agent_name}_report_store"
        return _load_module_from_file(module_name, str(full_path))
    except Exception as e:
        logger.warning(f"Failed to load {agent_name} report store: {e}")
        return None


def load_generator_module(
    agent_name: str,
    generator_path: str,
    dep_modules: Optional[list[tuple[str, str]]] = None,
    needs_reports_base: bool = True,
) -> Optional[types.ModuleType]:
    """에이전트 generator 모듈을 직접 로드.

    Args:
        agent_name: 에이전트 이름 (로깅용)
        generator_path: generator 파일의 상대 경로 (AGENTS_DIR 기준)
        dep_modules: 추가 의존 모듈 [(모듈명, 상대경로), ...]
        needs_reports_base: bdp_common.reports 모듈 필요 여부

    Returns:
        로드된 모듈 또는 실패 시 None
    """
    try:
        if needs_reports_base:
            _ensure_bdp_common_reports()

        if dep_modules:
            _ensure_dependency_modules(dep_modules)

        full_path = _AGENTS_DIR / generator_path
        if not full_path.exists():
            logger.warning(f"{agent_name} generator not found: {full_path}")
            return None

        module_name = f"_portal_{agent_name}_generator"
        return _load_module_from_file(module_name, str(full_path))
    except Exception as e:
        logger.warning(f"Failed to load {agent_name} generator: {e}")
        return None
