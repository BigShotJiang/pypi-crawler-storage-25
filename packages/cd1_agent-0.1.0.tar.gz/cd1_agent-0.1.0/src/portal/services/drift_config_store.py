"""Drift Config Store - CRUD for bdp_drift_configs table."""

import logging
import sqlite3
from datetime import datetime
from typing import Any

from src.common.timezone import KST
from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

BDP_DRIFT_CONFIGS_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS bdp_drift_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    check_items TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    description TEXT,
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT,
    UNIQUE(resource_type, resource_id)
);
"""

BDP_DRIFT_CONFIGS_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS bdp_drift_configs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resource_type VARCHAR(50) NOT NULL,
    resource_id VARCHAR(200) NOT NULL,
    check_items TEXT,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100),
    UNIQUE KEY uq_resource_type_id (resource_type, resource_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class DriftConfigStore:
    """CRUD store for bdp_drift_configs table."""

    def __init__(self, db: PortalDB):
        self.db = db
        self.provider = db.provider

    def ensure_table(self) -> None:
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(BDP_DRIFT_CONFIGS_TABLE_SQLITE)
            # Migration: add check_items column if table existed before this change
            try:
                conn.execute("ALTER TABLE bdp_drift_configs ADD COLUMN check_items TEXT")
            except sqlite3.OperationalError:
                pass  # Column already exists
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(BDP_DRIFT_CONFIGS_TABLE_MYSQL)
                try:
                    cur.execute(
                        "ALTER TABLE bdp_drift_configs ADD COLUMN check_items TEXT AFTER resource_id"
                    )
                except Exception:
                    pass  # Column already exists
            conn.commit()
        logger.info("bdp_drift_configs table ensured")

    def list_configs(self, resource_type: str | None = None) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            if resource_type:
                cur = conn.execute(
                    "SELECT * FROM bdp_drift_configs WHERE resource_type = ? ORDER BY resource_type, resource_id",
                    (resource_type,),
                )
            else:
                cur = conn.execute(
                    "SELECT * FROM bdp_drift_configs ORDER BY resource_type, resource_id"
                )
            return [dict(row) for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            if resource_type:
                cur.execute(
                    "SELECT * FROM bdp_drift_configs WHERE resource_type = %s ORDER BY resource_type, resource_id",
                    (resource_type,),
                )
            else:
                cur.execute("SELECT * FROM bdp_drift_configs ORDER BY resource_type, resource_id")
            return list(cur.fetchall())

    def get_config(self, config_id: int) -> dict[str, Any] | None:
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("SELECT * FROM bdp_drift_configs WHERE id = ?", (config_id,))
            row = cur.fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM bdp_drift_configs WHERE id = %s", (config_id,))
            return cur.fetchone()

    def create_config(
        self,
        resource_type: str,
        resource_id: str,
        check_items: str | None = None,
        enabled: int = 1,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> int:
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                """INSERT INTO bdp_drift_configs (resource_type, resource_id, check_items, enabled, description, created_at, updated_at, updated_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    resource_type,
                    resource_id,
                    check_items,
                    enabled,
                    description,
                    now,
                    now,
                    updated_by,
                ),
            )
            conn.commit()
            return cur.lastrowid
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO bdp_drift_configs (resource_type, resource_id, check_items, enabled, description, updated_by)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (resource_type, resource_id, check_items, enabled, description, updated_by),
            )
        conn.commit()
        return cur.lastrowid

    def upsert_config(
        self,
        resource_type: str,
        resource_id: str,
        check_items: str | None = None,
        enabled: int = 1,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> str:
        """Insert or update a config. Returns 'created' or 'updated'."""
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT id FROM bdp_drift_configs WHERE resource_type = ? AND resource_id = ?",
                (resource_type, resource_id),
            )
            existing = cur.fetchone()
            if existing:
                conn.execute(
                    """UPDATE bdp_drift_configs SET check_items = ?, enabled = ?, description = ?, updated_at = ?, updated_by = ?
                       WHERE resource_type = ? AND resource_id = ?""",
                    (
                        check_items,
                        enabled,
                        description,
                        now,
                        updated_by,
                        resource_type,
                        resource_id,
                    ),
                )
                conn.commit()
                return "updated"
            else:
                conn.execute(
                    """INSERT INTO bdp_drift_configs (resource_type, resource_id, check_items, enabled, description, created_at, updated_at, updated_by)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        resource_type,
                        resource_id,
                        check_items,
                        enabled,
                        description,
                        now,
                        now,
                        updated_by,
                    ),
                )
                conn.commit()
                return "created"
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM bdp_drift_configs WHERE resource_type = %s AND resource_id = %s",
                (resource_type, resource_id),
            )
            existing = cur.fetchone()
            if existing:
                cur.execute(
                    """UPDATE bdp_drift_configs SET check_items = %s, enabled = %s, description = %s, updated_by = %s
                       WHERE resource_type = %s AND resource_id = %s""",
                    (check_items, enabled, description, updated_by, resource_type, resource_id),
                )
                conn.commit()
                return "updated"
            else:
                cur.execute(
                    """INSERT INTO bdp_drift_configs (resource_type, resource_id, check_items, enabled, description, updated_by)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                    (resource_type, resource_id, check_items, enabled, description, updated_by),
                )
                conn.commit()
                return "created"

    def update_config(self, config_id: int, **kwargs) -> bool:
        if self.provider == "mock":
            return False
        allowed = {
            "resource_type",
            "resource_id",
            "check_items",
            "enabled",
            "description",
            "updated_by",
        }
        fields = {k: v for k, v in kwargs.items() if k in allowed}
        if not fields:
            return False

        if self.provider == "sqlite":
            now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
            fields["updated_at"] = now
            set_clause = ", ".join(f"{k} = ?" for k in fields)
            values = list(fields.values()) + [config_id]
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(f"UPDATE bdp_drift_configs SET {set_clause} WHERE id = ?", values)
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            set_clause = ", ".join(f"{k} = %s" for k in fields)
            values = list(fields.values()) + [config_id]
            cur.execute(f"UPDATE bdp_drift_configs SET {set_clause} WHERE id = %s", values)
        conn.commit()
        return cur.rowcount > 0

    def delete_config(self, config_id: int) -> bool:
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute("DELETE FROM bdp_drift_configs WHERE id = ?", (config_id,))
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM bdp_drift_configs WHERE id = %s", (config_id,))
        conn.commit()
        return cur.rowcount > 0

    def get_enabled_configs(self) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT * FROM bdp_drift_configs WHERE enabled = 1 ORDER BY resource_type, resource_id"
            )
            return [dict(row) for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM bdp_drift_configs WHERE enabled = 1 ORDER BY resource_type, resource_id"
            )
            return list(cur.fetchall())

    def get_resource_types(self) -> list[str]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "SELECT DISTINCT resource_type FROM bdp_drift_configs ORDER BY resource_type"
            )
            return [row["resource_type"] for row in cur.fetchall()]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT DISTINCT resource_type FROM bdp_drift_configs ORDER BY resource_type"
            )
            return [row["resource_type"] for row in cur.fetchall()]
