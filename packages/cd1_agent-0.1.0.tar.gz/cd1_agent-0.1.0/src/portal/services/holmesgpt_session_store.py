"""HolmesGPT Session Store - CRUD for chat sessions and messages."""

import logging
import uuid
from datetime import datetime
from typing import Any

from src.common.timezone import KST
from src.portal.services.db import PortalDB

logger = logging.getLogger(__name__)

SESSIONS_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS holmes_gpt_sessions (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S', 'now', '+9 hours')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S', 'now', '+9 hours'))
);
"""

MESSAGES_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS holmes_gpt_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL DEFAULT '',
    rendered_html TEXT,
    tool_calls_json TEXT,
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M:%S', 'now', '+9 hours')),
    FOREIGN KEY (session_id) REFERENCES holmes_gpt_sessions(id) ON DELETE CASCADE
);
"""

SESSIONS_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS holmes_gpt_sessions (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""

MESSAGES_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS holmes_gpt_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(36) NOT NULL,
    role ENUM('user', 'assistant') NOT NULL,
    content TEXT NOT NULL,
    rendered_html MEDIUMTEXT,
    tool_calls_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES holmes_gpt_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class HolmesGPTSessionStore:
    """CRUD store for HolmesGPT chat sessions and messages."""

    def __init__(self, db: PortalDB):
        self.db = db
        self.provider = db.provider

    def ensure_table(self) -> None:
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(SESSIONS_TABLE_SQLITE)
            conn.execute(MESSAGES_TABLE_SQLITE)
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(SESSIONS_TABLE_MYSQL)
                cur.execute(MESSAGES_TABLE_MYSQL)
            conn.commit()
        logger.info("holmes_gpt_sessions/messages tables ensured")

    def create_session(self, title: str = "새 대화") -> str:
        session_id = str(uuid.uuid4())
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(
                "INSERT INTO holmes_gpt_sessions (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (session_id, title, now, now),
            )
            conn.commit()
        elif self.provider == "mysql":
            conn = self.db._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO holmes_gpt_sessions (id, title) VALUES (%s, %s)",
                    (session_id, title),
                )
            conn.commit()
        return session_id

    def list_sessions(self, page: int = 1, per_page: int = 20) -> tuple[list[dict[str, Any]], int]:
        if self.provider == "mock":
            return [], 0
        offset = (page - 1) * per_page
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            total_row = conn.execute("SELECT COUNT(*) as cnt FROM holmes_gpt_sessions").fetchone()
            total = total_row["cnt"] if total_row else 0
            rows = conn.execute(
                """SELECT s.*,
                    (SELECT COUNT(*) FROM holmes_gpt_messages WHERE session_id = s.id) as message_count,
                    (SELECT MAX(created_at) FROM holmes_gpt_messages WHERE session_id = s.id) as last_message_at
                FROM holmes_gpt_sessions s
                ORDER BY s.updated_at DESC
                LIMIT ? OFFSET ?""",
                (per_page, offset),
            ).fetchall()
            return [dict(r) for r in rows], total
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) as cnt FROM holmes_gpt_sessions")
            total = cur.fetchone()["cnt"]
            cur.execute(
                """SELECT s.*,
                    (SELECT COUNT(*) FROM holmes_gpt_messages WHERE session_id = s.id) as message_count,
                    (SELECT MAX(created_at) FROM holmes_gpt_messages WHERE session_id = s.id) as last_message_at
                FROM holmes_gpt_sessions s
                ORDER BY s.updated_at DESC
                LIMIT %s OFFSET %s""",
                (per_page, offset),
            )
            return list(cur.fetchall()), total

    def get_session(self, session_id: str) -> dict[str, Any] | None:
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            row = conn.execute(
                "SELECT * FROM holmes_gpt_sessions WHERE id = ?", (session_id,)
            ).fetchone()
            return dict(row) if row else None
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM holmes_gpt_sessions WHERE id = %s", (session_id,))
            return cur.fetchone()

    def delete_session(self, session_id: str) -> bool:
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute("PRAGMA foreign_keys = ON")
            cur = conn.execute("DELETE FROM holmes_gpt_sessions WHERE id = ?", (session_id,))
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            # MySQL CASCADE handles messages
            cur.execute("DELETE FROM holmes_gpt_sessions WHERE id = %s", (session_id,))
        conn.commit()
        return cur.rowcount > 0

    def update_session_title(self, session_id: str, title: str) -> bool:
        if self.provider == "mock":
            return False
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            cur = conn.execute(
                "UPDATE holmes_gpt_sessions SET title = ?, updated_at = ? WHERE id = ?",
                (title, now, session_id),
            )
            conn.commit()
            return cur.rowcount > 0
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE holmes_gpt_sessions SET title = %s WHERE id = %s",
                (title, session_id),
            )
        conn.commit()
        return cur.rowcount > 0

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        rendered_html: str | None = None,
        tool_calls_json: str | None = None,
    ) -> int:
        now = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")
        # Update session updated_at
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            conn.execute(
                "UPDATE holmes_gpt_sessions SET updated_at = ? WHERE id = ?", (now, session_id)
            )
            cur = conn.execute(
                "INSERT INTO holmes_gpt_messages (session_id, role, content, rendered_html, tool_calls_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (session_id, role, content, rendered_html, tool_calls_json, now),
            )
            conn.commit()
            return cur.lastrowid
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO holmes_gpt_messages (session_id, role, content, rendered_html, tool_calls_json) VALUES (%s, %s, %s, %s, %s)",
                (session_id, role, content, rendered_html, tool_calls_json),
            )
        conn.commit()
        return cur.lastrowid

    def get_messages(self, session_id: str) -> list[dict[str, Any]]:
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            rows = conn.execute(
                "SELECT * FROM holmes_gpt_messages WHERE session_id = ? ORDER BY created_at ASC",
                (session_id,),
            ).fetchall()
            return [dict(r) for r in rows]
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM holmes_gpt_messages WHERE session_id = %s ORDER BY created_at ASC",
                (session_id,),
            )
            return list(cur.fetchall())

    def build_conversation_history(self, session_id: str) -> list[dict[str, str]]:
        """Build HolmesGPT API format conversation history from stored messages."""
        messages = self.get_messages(session_id)
        history = []
        for msg in messages:
            history.append({"role": msg["role"], "content": msg["content"]})
        return history

    def search_sessions(
        self, query: str, page: int = 1, per_page: int = 20
    ) -> tuple[list[dict[str, Any]], int]:
        if self.provider == "mock":
            return [], 0
        offset = (page - 1) * per_page
        like_pattern = f"%{query}%"
        if self.provider == "sqlite":
            conn = self.db._get_sqlite_connection()
            total_row = conn.execute(
                """SELECT COUNT(DISTINCT s.id) as cnt FROM holmes_gpt_sessions s
                LEFT JOIN holmes_gpt_messages m ON m.session_id = s.id
                WHERE s.title LIKE ? OR m.content LIKE ?""",
                (like_pattern, like_pattern),
            ).fetchone()
            total = total_row["cnt"] if total_row else 0
            rows = conn.execute(
                """SELECT DISTINCT s.*,
                    (SELECT COUNT(*) FROM holmes_gpt_messages WHERE session_id = s.id) as message_count,
                    (SELECT MAX(created_at) FROM holmes_gpt_messages WHERE session_id = s.id) as last_message_at
                FROM holmes_gpt_sessions s
                LEFT JOIN holmes_gpt_messages m ON m.session_id = s.id
                WHERE s.title LIKE ? OR m.content LIKE ?
                ORDER BY s.updated_at DESC
                LIMIT ? OFFSET ?""",
                (like_pattern, like_pattern, per_page, offset),
            ).fetchall()
            return [dict(r) for r in rows], total
        conn = self.db._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute(
                """SELECT COUNT(DISTINCT s.id) as cnt FROM holmes_gpt_sessions s
                LEFT JOIN holmes_gpt_messages m ON m.session_id = s.id
                WHERE s.title LIKE %s OR m.content LIKE %s""",
                (like_pattern, like_pattern),
            )
            total = cur.fetchone()["cnt"]
            cur.execute(
                """SELECT DISTINCT s.*,
                    (SELECT COUNT(*) FROM holmes_gpt_messages WHERE session_id = s.id) as message_count,
                    (SELECT MAX(created_at) FROM holmes_gpt_messages WHERE session_id = s.id) as last_message_at
                FROM holmes_gpt_sessions s
                LEFT JOIN holmes_gpt_messages m ON m.session_id = s.id
                WHERE s.title LIKE %s OR m.content LIKE %s
                ORDER BY s.updated_at DESC
                LIMIT %s OFFSET %s""",
                (like_pattern, like_pattern, per_page, offset),
            )
            return list(cur.fetchall()), total
