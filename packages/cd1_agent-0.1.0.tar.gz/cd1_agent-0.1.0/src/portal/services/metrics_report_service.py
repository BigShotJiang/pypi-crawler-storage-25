"""Metrics Report service wrapper for Portal.

Wraps the existing MetricsReportStore for portal use.
Uses direct module loading to avoid triggering heavy __init__.py imports
from agent packages.
"""

import logging
from typing import Any, List, Optional

from src.portal.services._import_helper import load_generator_module, load_report_store

logger = logging.getLogger(__name__)

_METRICS_DEPS = [
    ("bdp_metrics.services.models", "bdp_metrics/bdp_metrics/services/models.py"),
]

_store_module = load_report_store(
    "bdp_metrics",
    "bdp_metrics/bdp_metrics/services/report_store.py",
    dep_modules=_METRICS_DEPS,
)
_REPORT_AVAILABLE = _store_module is not None
MetricsReportStore = getattr(_store_module, "MetricsReportStore", None)
MetricsReport = getattr(_store_module, "MetricsReport", None)

_gen_module = load_generator_module(
    "bdp_metrics",
    "bdp_metrics/bdp_metrics/services/daily_report_generator.py",
    dep_modules=_METRICS_DEPS,
)
MetricsDailyReportGenerator = getattr(_gen_module, "MetricsDailyReportGenerator", None)


def is_report_available() -> bool:
    return _REPORT_AVAILABLE


def create_report_store(
    provider: str, db: Optional[str] = None, secret_id: Optional[str] = None
) -> Optional[Any]:
    """Create a MetricsReportStore if the package is available."""
    if not _REPORT_AVAILABLE:
        return None
    store = MetricsReportStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


class MetricsReportService:
    """Portal wrapper around MetricsReportStore."""

    def __init__(self, store: Optional[Any] = None):
        self.store = store
        self.available = store is not None

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Any]:
        if not self.available:
            return []
        return self.store.list_reports(
            start_date=start_date,
            end_date=end_date,
            resource_type=resource_type,
            severity=severity,
            limit=limit,
            offset=offset,
        )

    def get_report(self, report_id: str) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.get_report(report_id)

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        if not self.available:
            return 0
        return self.store.get_report_count(start_date=start_date, end_date=end_date)

    def render_html(self, report_id: str) -> Optional[str]:
        """DB 구조화 데이터로 HTML 리포트 재생성."""
        if not self.available or MetricsDailyReportGenerator is None:
            return None
        report = self.store.get_report(report_id)
        if report is None:
            return None
        if not getattr(report, "raw_drifts_json", None):
            return getattr(report, "html_report", None)
        generator = MetricsDailyReportGenerator()
        return generator.generate_from_db(report)
