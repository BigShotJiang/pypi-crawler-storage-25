"""Drift Report service wrapper for Portal.

Wraps the existing DriftReportStore for portal use.
Uses direct module loading to avoid triggering heavy __init__.py imports
from agent packages.
"""

import json
import logging
from collections import Counter, defaultdict
from typing import Any

from src.portal.services._import_helper import load_generator_module, load_report_store

logger = logging.getLogger(__name__)

_DRIFT_DEPS = [
    ("bdp_drift.bdp_drift.services.models", "bdp_drift/bdp_drift/services/models.py"),
]

_store_module = load_report_store("bdp_drift", "bdp_drift/bdp_drift/services/report_store.py")
_REPORT_AVAILABLE = _store_module is not None
DriftReportStore = getattr(_store_module, "DriftReportStore", None)
DriftReport = getattr(_store_module, "DriftReport", None)

_gen_module = load_generator_module(
    "bdp_drift",
    "bdp_drift/bdp_drift/services/daily_report_generator.py",
    dep_modules=_DRIFT_DEPS,
)
DriftDailyReportGenerator = getattr(_gen_module, "DriftDailyReportGenerator", None)

_RESOURCE_TYPE_KOREAN: dict[str, str] = (
    getattr(_gen_module, "RESOURCE_TYPE_KOREAN", {}) if _gen_module else {}
)
_RESOURCE_ICON: dict[str, str] = getattr(_gen_module, "RESOURCE_ICON", {}) if _gen_module else {}
_SEVERITY_KOREAN: dict[str, str] = {
    "critical": "심각",
    "high": "높음",
    "medium": "보통",
    "low": "낮음",
}
_SEVERITY_ORDER = ["critical", "high", "medium", "low"]


def is_drift_report_available() -> bool:
    return _REPORT_AVAILABLE


def create_drift_report_store(
    provider: str, db: str | None = None, secret_id: str | None = None
) -> Any | None:
    """Create a DriftReportStore if the package is available."""
    if not _REPORT_AVAILABLE:
        return None
    store = DriftReportStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


class DriftReportService:
    """Portal wrapper around DriftReportStore."""

    def __init__(self, store: Any | None = None):
        self.store = store
        self.available = store is not None

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        severity: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Any]:
        if not self.available:
            return []
        return self.store.list_reports(
            start_date=start_date,
            end_date=end_date,
            severity=severity,
            limit=limit,
            offset=offset,
        )

    def get_report(self, report_id: str) -> Any | None:
        if not self.available:
            return None
        return self.store.get_report(report_id)

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        if not self.available:
            return 0
        return self.store.get_report_count(start_date=start_date, end_date=end_date)

    def render_html(self, report_id: str) -> str | None:
        """DB 구조화 데이터로 HTML 리포트 재생성."""
        if not self.available or DriftDailyReportGenerator is None:
            return None
        report = self.store.get_report(report_id)
        if report is None:
            return None
        if not getattr(report, "raw_drifts_json", None):
            return getattr(report, "html_report", None)
        generator = DriftDailyReportGenerator()
        return generator.generate_from_db(report)

    # ------------------------------------------------------------------
    # Drift 현황 대시보드용 데이터
    # ------------------------------------------------------------------

    def get_latest_status_data(self) -> dict[str, Any]:
        """최신 리포트에서 대시보드용 구조화 데이터를 반환."""
        empty: dict[str, Any] = {
            "report_id": None,
            "run_timestamp": None,
            "summary": {
                "total_resources": 0,
                "drift_count": 0,
                "normal_count": 0,
                "critical_high_count": 0,
                "avg_field_changes": 0.0,
            },
            "severity_distribution": [],
            "resource_types": [],
            "drift_details": [],
            "trend": [],
        }

        if not self.available or DriftDailyReportGenerator is None:
            return empty

        reports = self.store.list_reports(limit=1)
        if not reports:
            return empty

        report = reports[0]
        raw_json = getattr(report, "raw_drifts_json", None)
        if not raw_json:
            return empty

        results = DriftDailyReportGenerator.results_from_json(raw_json)
        if not results:
            return empty

        # 히스토리용 과거 리포트 파싱 (최근 30개)
        all_reports = self.store.list_reports(limit=30)
        history_map = self._build_resource_history(all_reports)

        data = self._build_status_data(report, results, history_map)
        data["trend"] = self._build_trend_data(all_reports)
        return data

    def _build_resource_history(
        self,
        reports: list[Any],
    ) -> dict[str, list[dict[str, Any]]]:
        """리소스별 (resource_type:resource_id) 히스토리 맵 구성."""
        # key = "resource_type:resource_id"
        resource_map: dict[str, list[dict[str, Any]]] = defaultdict(list)

        for r in reversed(reports):  # 오래된 순
            raw_json = getattr(r, "raw_drifts_json", None)
            ts = getattr(r, "run_timestamp", None)
            if not raw_json:
                continue
            try:
                results = DriftDailyReportGenerator.results_from_json(raw_json)
            except Exception:
                continue
            # 이 리포트에서 드리프트된 리소스 집합
            drifted_in_report: dict[str, Any] = {}
            for dr in results:
                key = f"{dr.resource_type}:{dr.resource_id}"
                if dr.has_drift:
                    drifted_in_report[key] = {
                        "date": ts,
                        "drift_count": len(dr.drift_fields),
                        "severity": dr.severity.value,
                    }
            # 지금까지 한 번이라도 등장한 모든 키에 대해 기록
            all_keys = set(resource_map.keys()) | set(drifted_in_report.keys())
            for key in all_keys:
                if key in drifted_in_report:
                    resource_map[key].append(drifted_in_report[key])
                else:
                    resource_map[key].append({"date": ts, "drift_count": 0, "severity": None})

        return dict(resource_map)

    def _build_status_data(
        self,
        report: Any,
        results: list[Any],
        history_map: dict[str, list[dict[str, Any]]] | None = None,
    ) -> dict[str, Any]:
        """DriftResult 리스트로 대시보드 JSON 구성."""
        total = len(results)
        drifted = [r for r in results if r.has_drift]
        drift_count = len(drifted)
        normal_count = total - drift_count
        critical_high = sum(1 for r in drifted if r.severity.value in ("critical", "high"))
        avg_fields = (
            round(sum(len(r.drift_fields) for r in drifted) / drift_count, 1)
            if drift_count
            else 0.0
        )

        # --- severity distribution ---
        sev_counter: Counter[str] = Counter()
        for r in drifted:
            sev_counter[r.severity.value] += 1
        severity_distribution = []
        for sev in _SEVERITY_ORDER:
            cnt = sev_counter.get(sev, 0)
            severity_distribution.append(
                {
                    "severity": sev,
                    "label": _SEVERITY_KOREAN.get(sev, sev),
                    "count": cnt,
                    "percentage": round(cnt / drift_count * 100, 1) if drift_count else 0,
                }
            )

        # --- resource types ---
        type_scanned: Counter[str] = Counter()
        type_drifted: Counter[str] = Counter()
        type_max_sev: dict[str, int] = defaultdict(lambda: len(_SEVERITY_ORDER))
        type_fields: dict[str, Counter[str]] = defaultdict(Counter)

        for r in results:
            rtype = r.resource_type
            type_scanned[rtype] += 1
            if r.has_drift:
                type_drifted[rtype] += 1
                sev_idx = (
                    _SEVERITY_ORDER.index(r.severity.value)
                    if r.severity.value in _SEVERITY_ORDER
                    else len(_SEVERITY_ORDER)
                )
                if sev_idx < type_max_sev[rtype]:
                    type_max_sev[rtype] = sev_idx
                for f in r.drift_fields:
                    type_fields[rtype][f.field_name] += 1

        resource_types = []
        for rtype in sorted(type_scanned.keys()):
            top_fields = (
                [f for f, _ in type_fields[rtype].most_common(3)] if type_drifted[rtype] else []
            )
            max_sev_val = (
                _SEVERITY_ORDER[type_max_sev[rtype]]
                if rtype in type_max_sev and type_max_sev[rtype] < len(_SEVERITY_ORDER)
                else None
            )
            resource_types.append(
                {
                    "resource_type": rtype,
                    "label": _RESOURCE_TYPE_KOREAN.get(rtype, rtype),
                    "icon": _RESOURCE_ICON.get(rtype, ""),
                    "scanned": type_scanned[rtype],
                    "drifted": type_drifted[rtype],
                    "max_severity": max_sev_val,
                    "top_fields": top_fields,
                }
            )

        # --- drift details (심각도순) ---
        sorted_drifted = sorted(
            drifted,
            key=lambda r: (
                _SEVERITY_ORDER.index(r.severity.value)
                if r.severity.value in _SEVERITY_ORDER
                else len(_SEVERITY_ORDER)
            ),
        )
        drift_details = []
        for r in sorted_drifted:
            fields = []
            for f in r.drift_fields:
                fields.append(
                    {
                        "field_name": f.field_name,
                        "baseline_value": self._serialize_value(f.baseline_value),
                        "current_value": self._serialize_value(f.current_value),
                        "severity": f.severity.value
                        if hasattr(f.severity, "value")
                        else str(f.severity),
                        "category": f.category.value
                        if hasattr(f.category, "value")
                        else str(f.category),
                        "impact": f.impact,
                        "recommendation": f.recommendation,
                    }
                )
            res_key = f"{r.resource_type}:{r.resource_id}"
            history = (history_map or {}).get(res_key, [])
            drift_details.append(
                {
                    "resource_type": r.resource_type,
                    "resource_type_label": _RESOURCE_TYPE_KOREAN.get(
                        r.resource_type, r.resource_type
                    ),
                    "resource_id": r.resource_id,
                    "resource_arn": r.resource_arn,
                    "severity": r.severity.value,
                    "detection_timestamp": (
                        r.detection_timestamp.isoformat() if r.detection_timestamp else None
                    ),
                    "drift_count": len(r.drift_fields),
                    "fields": fields,
                    "history": history,
                }
            )

        return {
            "report_id": getattr(report, "id", None),
            "run_timestamp": getattr(report, "run_timestamp", None),
            "summary": {
                "total_resources": total,
                "drift_count": drift_count,
                "normal_count": normal_count,
                "critical_high_count": critical_high,
                "avg_field_changes": avg_fields,
            },
            "severity_distribution": severity_distribution,
            "resource_types": resource_types,
            "drift_details": drift_details,
        }

    def _build_trend_data(self, reports: list[Any] | None = None) -> list[dict[str, Any]]:
        """최근 N개 리포트에서 리소스 타입별 드리프트 수 시계열 구성."""
        if reports is None:
            reports = self.store.list_reports(limit=30)
        trend: list[dict[str, Any]] = []
        for r in reversed(reports):  # 오래된 순 정렬
            raw_json = getattr(r, "raw_drifts_json", None)
            by_type: dict[str, int] = {}
            if raw_json and DriftDailyReportGenerator is not None:
                try:
                    results = DriftDailyReportGenerator.results_from_json(raw_json)
                    for dr in results:
                        if dr.has_drift:
                            label = _RESOURCE_TYPE_KOREAN.get(dr.resource_type, dr.resource_type)
                            by_type[label] = by_type.get(label, 0) + 1
                except Exception:
                    pass

            trend.append(
                {
                    "date": getattr(r, "run_timestamp", None),
                    "drift_count": getattr(r, "total_drifts", 0),
                    "by_resource_type": by_type,
                }
            )
        return trend

    @staticmethod
    def _serialize_value(value: Any) -> Any:
        """JSON 직렬화 가능한 형태로 변환."""
        if value is None:
            return None
        if isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (list, dict)):
            try:
                json.dumps(value)
                return value
            except (TypeError, ValueError):
                return str(value)
        return str(value)
