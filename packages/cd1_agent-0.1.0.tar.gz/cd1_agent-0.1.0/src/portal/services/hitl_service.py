"""HITL service wrapper for Portal.

Wraps the existing HITLStore for portal use.
"""

from typing import Any

from src.common.hitl.schemas import (
    HITLAgentType,
    HITLRequest,
    HITLRequestCreate,
    HITLRequestFilter,
    HITLRequestResponse,
    HITLRequestStatus,
    HITLRequestType,
)
from src.common.hitl.store import HITLStore

# Frontend agent keys → backend HITLAgentType enum values
_AGENT_KEY_MAP: dict[str, str] = {
    "bdp_metrics": "bdp",
    "bdp_cost": "cost",
    "bdp_airflow": "bdp",
    "bdp_drift": "drift",
    "hdsp_agent": "holmesgpt",
    "bdp_dashboard": "bdp_dashboard",
    "hdsp_dashboard": "hdsp_dashboard",
}


def _resolve_agent_type(agent_type: str | None) -> HITLAgentType | None:
    """Resolve a frontend agent key to HITLAgentType, returning None for 'all' or empty."""
    if not agent_type or agent_type == "all":
        return None
    mapped = _AGENT_KEY_MAP.get(agent_type, agent_type)
    try:
        return HITLAgentType(mapped)
    except ValueError:
        return None


class HITLService:
    """Portal wrapper around HITLStore."""

    def __init__(self, store: HITLStore):
        self.store = store

    def list_requests(
        self,
        agent_type: str | None = None,
        status: str | None = None,
        page: int = 1,
        per_page: int = 20,
    ) -> tuple[list[HITLRequest], int]:
        """List HITL requests with pagination.

        Returns:
            Tuple of (requests, total_pending_count)
        """
        filt = HITLRequestFilter(
            agent_type=_resolve_agent_type(agent_type),
            status=HITLRequestStatus(status) if status else None,
            limit=per_page,
            offset=(page - 1) * per_page,
        )
        requests = self.store.list_requests(filt)
        pending_count = self.store.get_pending_count()
        return requests, pending_count

    def get_request(self, request_id: str) -> HITLRequest | None:
        return self.store.get(request_id)

    def approve(
        self, request_id: str, comment: str | None = None, user: str = "admin"
    ) -> HITLRequest | None:
        response = HITLRequestResponse(
            approved=True,
            comment=comment,
            responded_by=user,
        )
        return self.store.respond(request_id, response)

    def reject(
        self, request_id: str, comment: str | None = None, user: str = "admin"
    ) -> HITLRequest | None:
        response = HITLRequestResponse(
            approved=False,
            comment=comment,
            responded_by=user,
        )
        return self.store.respond(request_id, response)

    def cancel(self, request_id: str) -> HITLRequest | None:
        return self.store.cancel(request_id)

    def expire_stale(self) -> int:
        return self.store.expire_stale_requests()

    def get_pending_count(self, agent_type: str | None = None) -> int:
        return self.store.get_pending_count(_resolve_agent_type(agent_type))

    def get_pending_counts_by_agent(self) -> dict[str, int]:
        """에이전트별 pending 건수를 반환한다."""
        return self.store.get_pending_counts_grouped()

    def clear_messages(self, agent_type: str) -> int:
        """에이전트 타입별 메시지 전체 삭제."""
        resolved = _resolve_agent_type(agent_type)
        if resolved is None:
            return 0
        return self.store.delete_by_agent(resolved.value)

    def send_request(
        self,
        agent_type: str,
        message: str,
        request_type: str = "prompt_input",
        payload: dict | None = None,
        user: str = "admin",
    ) -> HITLRequest:
        """채팅 인터페이스에서 새 HITL 요청을 생성한다."""
        resolved = _resolve_agent_type(agent_type)
        if resolved is None:
            resolved = HITLAgentType.BDP  # fallback
        req = HITLRequestCreate(
            agent_type=resolved,
            request_type=HITLRequestType(request_type),
            title=message[:100],
            description=message,
            payload=payload or {"message": message},
            created_by=user,
        )
        return self.store.create(req)

    def save_agent_response(
        self,
        agent_type: HITLAgentType,
        content: str,
        payload: dict[str, Any] | None = None,
        created_by: str = "holmesgpt",
    ) -> HITLRequest:
        """에이전트 응답을 HITL store에 저장한다. 자동 승인 처리."""
        req = HITLRequestCreate(
            agent_type=agent_type,
            request_type=HITLRequestType.PROMPT_INPUT,
            title=content[:100],
            description=content,
            payload=payload or {},
            created_by=created_by,
        )
        created = self.store.create(req)
        # 자동 승인 (read-only agent이므로 HITL 승인 불필요)
        response = HITLRequestResponse(
            approved=True,
            comment="auto-approved",
            responded_by="system",
        )
        result = self.store.respond(created.id, response)
        return result or created
