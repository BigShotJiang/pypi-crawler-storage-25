"""DB connection management for Portal.

Reuses existing HITLStore and BaselineStore with shared connection configuration.
Also manages the admin_settings override table and mail_config table.
"""

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from src.common.timezone import KST
from src.portal.config import PortalSettings

try:
    import pymysql

    PYMYSQL_AVAILABLE = True
except ImportError:
    PYMYSQL_AVAILABLE = False

logger = logging.getLogger(__name__)

ADMIN_SETTINGS_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS admin_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT
);
"""

ADMIN_SETTINGS_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS admin_settings (
    `key` VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""

MAIL_CONFIG_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS mail_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type TEXT NOT NULL UNIQUE,
    enabled INTEGER NOT NULL DEFAULT 0,
    recipients_to TEXT NOT NULL DEFAULT '[]',
    recipients_cc TEXT NOT NULL DEFAULT '[]',
    schedule_type TEXT NOT NULL DEFAULT 'daily',
    sections TEXT NOT NULL DEFAULT '[]',
    created_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%d %H:%M', 'now', '+9 hours')),
    updated_by TEXT
);
"""

MAIL_CONFIG_TABLE_MYSQL = """
CREATE TABLE IF NOT EXISTS mail_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_type VARCHAR(50) NOT NULL UNIQUE,
    enabled TINYINT(1) NOT NULL DEFAULT 0,
    recipients_to TEXT NOT NULL,
    recipients_cc TEXT NOT NULL,
    schedule_type VARCHAR(20) NOT NULL DEFAULT 'daily',
    sections TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


class PortalDB:
    """Portal database connection manager."""

    def __init__(self, settings: PortalSettings):
        self.settings = settings
        self.provider = settings.rds_provider
        self._sqlite_conn: sqlite3.Connection | None = None
        self._mysql_conn = None
        self._sm_credentials: dict | None = None

    def _get_sqlite_connection(self) -> sqlite3.Connection:
        if self._sqlite_conn is None:
            db_path = Path(self.settings.sqlite_path)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            self._sqlite_conn = sqlite3.connect(
                str(db_path),
                detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
                check_same_thread=False,
            )
            self._sqlite_conn.row_factory = sqlite3.Row
            self._sqlite_conn.execute("PRAGMA foreign_keys = ON")
        return self._sqlite_conn

    def _get_mysql_connection(self):
        if not PYMYSQL_AVAILABLE:
            raise ImportError("pymysql is required for MySQL. Install with: pip install pymysql")
        if self._mysql_conn is None or not self._mysql_conn.open:
            if not self.settings.baseline_secret_id:
                raise RuntimeError(
                    "RDS_PROVIDER='mysql'이지만 BASELINE_SECRET_ID가 설정되지 않았습니다. "
                    "Secrets Manager를 통한 DB 접속이 필요합니다."
                )
            creds = self._get_credentials_from_secrets_manager()
            self._mysql_conn = pymysql.connect(
                host=creds["host"],
                port=int(creds.get("port", 3306)),
                database=self.settings.rds_database,
                user=creds["username"],
                password=creds["password"],
                cursorclass=pymysql.cursors.DictCursor,
                connect_timeout=10,
                read_timeout=30,
            )
        else:
            try:
                self._mysql_conn.ping(reconnect=True)
            except Exception:
                creds = self._get_credentials_from_secrets_manager()
                self._mysql_conn = pymysql.connect(
                    host=creds["host"],
                    port=int(creds.get("port", 3306)),
                    database=self.settings.rds_database,
                    user=creds["username"],
                    password=creds["password"],
                    cursorclass=pymysql.cursors.DictCursor,
                    connect_timeout=10,
                    read_timeout=30,
                )
        return self._mysql_conn

    def _get_credentials_from_secrets_manager(self) -> dict:
        """AWS Secrets Manager에서 DB credentials 획득."""
        if self._sm_credentials is None:
            import json

            from src.common.services.aws_session import get_boto3_client

            client = get_boto3_client("secretsmanager", region="ap-northeast-2")
            response = client.get_secret_value(SecretId=self.settings.baseline_secret_id)
            self._sm_credentials = json.loads(response["SecretString"])
            logger.info("DB credentials loaded from Secrets Manager: %s", self.settings.baseline_secret_id)
        return self._sm_credentials

    def ensure_tables(self) -> None:
        """Create admin_settings and mail_config tables if not exists."""
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            conn.execute(ADMIN_SETTINGS_TABLE_SQLITE)
            conn.execute(MAIL_CONFIG_TABLE_SQLITE)
            conn.commit()
        elif self.provider == "mysql":
            conn = self._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(ADMIN_SETTINGS_TABLE_MYSQL)
                cur.execute(MAIL_CONFIG_TABLE_MYSQL)
            conn.commit()
        # 마이그레이션: sections 컬럼이 없으면 추가
        self._migrate_mail_config_sections()
        logger.info("Portal tables ensured (admin_settings, mail_config)")

    def _migrate_mail_config_sections(self) -> None:
        """mail_config 테이블에 sections 컬럼 추가 (이미 있으면 무시)."""
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            try:
                conn.execute("ALTER TABLE mail_config ADD COLUMN sections TEXT DEFAULT '[]'")
                conn.commit()
                logger.info("Added 'sections' column to mail_config (sqlite)")
            except sqlite3.OperationalError:
                pass  # 이미 존재
        elif self.provider == "mysql":
            conn = self._get_mysql_connection()
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        "ALTER TABLE mail_config ADD COLUMN sections TEXT"
                    )
                    conn.commit()
                    logger.info("Added 'sections' column to mail_config (mysql)")
                except Exception:
                    pass  # 이미 존재

    def get_setting(self, key: str) -> str | None:
        """Get a single admin setting override."""
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("SELECT value FROM admin_settings WHERE key = ?", (key,))
            row = cur.fetchone()
            return row["value"] if row else None
        conn = self._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT value FROM admin_settings WHERE `key` = %s", (key,))
            row = cur.fetchone()
            return row["value"] if row else None

    def get_all_settings(self) -> list[dict[str, Any]]:
        """Get all admin setting overrides."""
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM admin_settings ORDER BY key")
            return [dict(row) for row in cur.fetchall()]
        conn = self._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM admin_settings ORDER BY `key`")
            return list(cur.fetchall())

    def set_setting(self, key: str, value: str, updated_by: str | None = None) -> None:
        """Set an admin setting override."""
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
            conn.execute(
                """INSERT INTO admin_settings (key, value, updated_at, updated_by)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET value=?, updated_at=?, updated_by=?""",
                (key, value, now, updated_by, value, now, updated_by),
            )
            conn.commit()
        elif self.provider == "mysql":
            conn = self._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO admin_settings (`key`, value, updated_by)
                       VALUES (%s, %s, %s)
                       ON DUPLICATE KEY UPDATE value=%s, updated_by=%s""",
                    (key, value, updated_by, value, updated_by),
                )
            conn.commit()

    def delete_setting(self, key: str) -> bool:
        """Delete an admin setting override."""
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("DELETE FROM admin_settings WHERE key = ?", (key,))
            conn.commit()
            return cur.rowcount > 0
        conn = self._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM admin_settings WHERE `key` = %s", (key,))
        conn.commit()
        return cur.rowcount > 0

    # --- mail_config CRUD ---

    def get_mail_config(self, report_type: str) -> dict | None:
        """Get mail config for a specific report type."""
        if self.provider == "mock":
            return None
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM mail_config WHERE report_type = ?", (report_type,))
            row = cur.fetchone()
            if not row:
                return None
            d = dict(row)
            d["recipients_to"] = json.loads(d["recipients_to"])
            d["recipients_cc"] = json.loads(d["recipients_cc"])
            d["enabled"] = bool(d["enabled"])
            return d
        conn = self._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mail_config WHERE report_type = %s", (report_type,))
            row = cur.fetchone()
            if not row:
                return None
            row["recipients_to"] = json.loads(row["recipients_to"])
            row["recipients_cc"] = json.loads(row["recipients_cc"])
            row["enabled"] = bool(row["enabled"])
            return row

    def get_all_mail_configs(self) -> list[dict]:
        """Get all mail configs."""
        if self.provider == "mock":
            return []
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM mail_config ORDER BY report_type")
            rows = [dict(row) for row in cur.fetchall()]
        else:
            conn = self._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM mail_config ORDER BY report_type")
                rows = list(cur.fetchall())
        for row in rows:
            row["recipients_to"] = json.loads(row["recipients_to"])
            row["recipients_cc"] = json.loads(row["recipients_cc"])
            row["enabled"] = bool(row["enabled"])
        return rows

    def upsert_mail_config(
        self,
        report_type: str,
        enabled: bool,
        recipients_to: list[str],
        recipients_cc: list[str],
        schedule_type: str,
        updated_by: str | None = None,
    ) -> None:
        """Insert or update a mail config."""
        to_json = json.dumps(recipients_to, ensure_ascii=False)
        cc_json = json.dumps(recipients_cc, ensure_ascii=False)
        enabled_int = 1 if enabled else 0
        if self.provider == "mock":
            return
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            now = datetime.now(KST).strftime("%Y-%m-%d %H:%M")
            conn.execute(
                """INSERT INTO mail_config (report_type, enabled, recipients_to, recipients_cc, schedule_type, updated_at, updated_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(report_type) DO UPDATE SET
                     enabled=?, recipients_to=?, recipients_cc=?, schedule_type=?, updated_at=?, updated_by=?""",
                (report_type, enabled_int, to_json, cc_json, schedule_type, now, updated_by,
                 enabled_int, to_json, cc_json, schedule_type, now, updated_by),
            )
            conn.commit()
        elif self.provider == "mysql":
            conn = self._get_mysql_connection()
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO mail_config (report_type, enabled, recipients_to, recipients_cc, schedule_type, updated_by)
                       VALUES (%s, %s, %s, %s, %s, %s)
                       ON DUPLICATE KEY UPDATE
                         enabled=%s, recipients_to=%s, recipients_cc=%s, schedule_type=%s, updated_by=%s""",
                    (report_type, enabled_int, to_json, cc_json, schedule_type, updated_by,
                     enabled_int, to_json, cc_json, schedule_type, updated_by),
                )
            conn.commit()

    def delete_mail_config(self, report_type: str) -> bool:
        """Delete a mail config."""
        if self.provider == "mock":
            return False
        if self.provider == "sqlite":
            conn = self._get_sqlite_connection()
            cur = conn.cursor()
            cur.execute("DELETE FROM mail_config WHERE report_type = ?", (report_type,))
            conn.commit()
            return cur.rowcount > 0
        conn = self._get_mysql_connection()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM mail_config WHERE report_type = %s", (report_type,))
        conn.commit()
        return cur.rowcount > 0

    def close(self) -> None:
        if self._sqlite_conn:
            self._sqlite_conn.close()
            self._sqlite_conn = None
        if self._mysql_conn and self._mysql_conn.open:
            self._mysql_conn.close()
            self._mysql_conn = None
