"""Airflow Detection Config Service - manages detection parameters with defaults + DB overrides."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.portal.services.airflow_config_store import AirflowConfigStore

logger = logging.getLogger(__name__)

DETECTION_CONFIG_PATH = (
    Path(__file__).resolve().parent.parent.parent
    / "agents" / "bdp_airflow" / "conf" / "detection_config.json"
)

# ── Section definitions: UI metadata for each config section ──────────────

SECTION_DEFINITIONS = {
    "failure_detection": {
        "label": "장애 탐지",
        "icon": "emergency",
        "description": "장애 패턴 탐지의 기본 임계값을 설정합니다",
        "order": 1,
        "fields": [
            {"key": "lookback_hours", "label": "조회 기간 (시간)", "type": "int",
             "help": "장애 이력을 조회할 기간", "min": 1, "max": 168},
            {"key": "min_failures_for_pattern", "label": "패턴 인식 최소 실패 수", "type": "int",
             "help": "패턴으로 인식하기 위한 최소 장애 횟수", "min": 1, "max": 100},
            {"key": "recurring_threshold_count", "label": "반복 장애 임계값", "type": "int",
             "help": "반복 장애로 분류하기 위한 횟수", "min": 2, "max": 100},
        ],
    },
    "precursor_detection": {
        "label": "전조 탐지",
        "icon": "timeline",
        "description": "장애 전조 징후 탐지 파라미터를 설정합니다",
        "order": 2,
        "fields": [
            {"key": "duration_anomaly_z_score", "label": "실행시간 이상 Z-Score", "type": "float",
             "help": "실행시간 이상치 판별 Z-Score 임계값", "min": 0.5, "max": 5.0, "step": 0.1},
            {"key": "warning_keywords", "label": "경고 키워드", "type": "list",
             "help": "로그에서 전조 징후로 탐지할 키워드 (줄당 1개)"},
            {"key": "precursor_window_hours", "label": "전조 탐지 윈도우 (시간)", "type": "int",
             "help": "장애 발생 전 전조를 탐지할 시간 범위", "min": 1, "max": 48},
        ],
    },
    "severity": {
        "label": "심각도 분류",
        "icon": "priority_high",
        "description": "장애 심각도 판별 기준을 설정합니다",
        "order": 3,
        "fields": [
            {"key": "critical_keywords", "label": "Critical 키워드", "type": "list",
             "help": "Critical 심각도로 분류할 에러 키워드 (줄당 1개)"},
            {"key": "cascading_failure_threshold", "label": "연쇄 장애 임계값", "type": "int",
             "help": "연쇄 장애로 판별하기 위한 최소 장애 수", "min": 2, "max": 20},
        ],
    },
    "cross_dag": {
        "label": "DAG간 상관분석",
        "icon": "hub",
        "description": "서로 다른 DAG 간의 장애 상관관계 탐지 설정",
        "order": 4,
        "fields": [
            {"key": "time_correlation_window_minutes", "label": "상관관계 시간 윈도우 (분)", "type": "int",
             "help": "동시 장애를 판별할 시간 범위 (분)", "min": 5, "max": 120},
            {"key": "min_correlated_failures", "label": "최소 상관 장애 수", "type": "int",
             "help": "상관관계로 인식하기 위한 최소 동시 장애 수", "min": 2, "max": 20},
        ],
    },
    "op_kwargs_analysis": {
        "label": "Op Kwargs 분석",
        "icon": "data_object",
        "description": "Task 파라미터 패턴 분석 설정",
        "order": 5,
        "fields": [
            {"key": "min_cluster_size", "label": "최소 클러스터 크기", "type": "int",
             "help": "패턴으로 그룹핑하기 위한 최소 건수", "min": 2, "max": 50},
            {"key": "key_fields", "label": "분석 대상 필드", "type": "list",
             "help": "op_kwargs에서 추출할 주요 필드 (줄당 1개)"},
        ],
    },
    "infrastructure": {
        "label": "인프라 모니터링",
        "icon": "dns",
        "description": "MWAA 스케줄러/워커 인프라 이상 탐지 설정",
        "order": 6,
        "fields": [
            {"key": "scheduler_lag_threshold_seconds", "label": "스케줄러 지연 임계값 (초)", "type": "int",
             "help": "스케줄러 지연으로 판별할 시간 (초)", "min": 60, "max": 3600},
            {"key": "worker_oom_threshold_count", "label": "워커 OOM 임계값", "type": "int",
             "help": "OOM 이슈로 판별할 최소 발생 횟수", "min": 1, "max": 20},
            {"key": "scheduler_overload_indicators", "label": "스케줄러 과부하 키워드", "type": "list",
             "help": "스케줄러 과부하 판별 키워드 (줄당 1개)"},
            {"key": "worker_resource_indicators", "label": "워커 리소스 이상 키워드", "type": "list",
             "help": "워커 리소스 이상 판별 키워드 (줄당 1개)"},
            {"key": "concurrency_keywords", "label": "동시성 관련 키워드", "type": "list",
             "help": "동시성 제한 관련 키워드 (줄당 1개)"},
        ],
    },
    "deployment_detection": {
        "label": "배포 회귀 탐지",
        "icon": "rocket_launch",
        "description": "배포 이후 발생하는 회귀 장애 탐지 설정",
        "order": 7,
        "fields": [
            {"key": "regression_window_hours", "label": "회귀 탐지 윈도우 (시간)", "type": "int",
             "help": "배포 후 회귀 장애를 탐지할 시간 범위", "min": 1, "max": 48},
            {"key": "min_failures_after_deploy", "label": "최소 장애 수", "type": "int",
             "help": "회귀로 판별하기 위한 배포 후 최소 장애 수", "min": 1, "max": 20},
            {"key": "dag_version_patterns", "label": "DAG 버전 패턴", "type": "list",
             "help": "배포 식별을 위한 정규식 패턴 (줄당 1개)"},
        ],
    },
    "external_systems": {
        "label": "외부 시스템 연동",
        "icon": "cloud_sync",
        "description": "외부 시스템 장애 탐지를 위한 callable/키워드 설정",
        "order": 8,
        "fields": [
            {"key": "sagemaker_callables", "label": "SageMaker callable", "type": "list",
             "help": "SageMaker 관련 Task callable 목록"},
            {"key": "emr_callables", "label": "EMR callable", "type": "list",
             "help": "EMR 관련 Task callable 목록"},
            {"key": "sftp_callables", "label": "SFTP callable", "type": "list",
             "help": "SFTP 관련 Task callable 목록"},
            {"key": "copy_callables", "label": "Data Copy callable", "type": "list",
             "help": "데이터 복사 관련 Task callable 목록"},
            {"key": "external_api_callables", "label": "External API callable", "type": "list",
             "help": "외부 API 관련 Task callable 목록"},
            {"key": "sagemaker_error_keywords", "label": "SageMaker 에러 키워드", "type": "list",
             "help": "SageMaker 관련 에러 키워드"},
            {"key": "emr_error_keywords", "label": "EMR 에러 키워드", "type": "list",
             "help": "EMR 관련 에러 키워드"},
            {"key": "sftp_error_keywords", "label": "SFTP 에러 키워드", "type": "list",
             "help": "SFTP 관련 에러 키워드"},
        ],
    },
    "environments": {
        "label": "환경 설정",
        "icon": "apartment",
        "description": "모니터링 대상 환경(DLK/WFL) 정의",
        "order": 0,
        "fields": [],  # Special handling - nested dict
    },
}

# Sorted section keys by order
SECTION_KEYS = sorted(SECTION_DEFINITIONS.keys(), key=lambda k: SECTION_DEFINITIONS[k]["order"])


def _load_defaults() -> Dict[str, Any]:
    """Load default config from detection_config.json."""
    try:
        with open(DETECTION_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Could not load detection_config.json: {e}, using empty defaults")
        return {}


class AirflowConfigService:
    """Manages airflow detection configuration with defaults + DB overrides."""

    def __init__(self, store: AirflowConfigStore):
        self.store = store
        self._defaults = _load_defaults()

    def get_defaults(self) -> Dict[str, Any]:
        """Return the full default config from static file."""
        return dict(self._defaults)

    def get_section_default(self, section_key: str) -> Dict[str, Any]:
        """Return default values for a specific section."""
        return dict(self._defaults.get(section_key, {}))

    def get_merged_config(self) -> Dict[str, Any]:
        """Return full config with DB overrides merged over defaults."""
        config = dict(self._defaults)
        saved = self.store.get_all_sections()
        for key, row in saved.items():
            try:
                config[key] = json.loads(row["config_json"])
            except (json.JSONDecodeError, TypeError):
                pass
        return config

    def get_section_with_meta(self, section_key: str) -> Dict[str, Any]:
        """Return section data with override metadata."""
        default_val = self._defaults.get(section_key, {})
        saved = self.store.get_section(section_key)
        if saved:
            try:
                current_val = json.loads(saved["config_json"])
            except (json.JSONDecodeError, TypeError):
                current_val = default_val
            return {
                "key": section_key,
                "value": current_val,
                "default": default_val,
                "is_customized": True,
                "updated_at": saved.get("updated_at"),
                "updated_by": saved.get("updated_by"),
            }
        return {
            "key": section_key,
            "value": default_val,
            "default": default_val,
            "is_customized": False,
            "updated_at": None,
            "updated_by": None,
        }

    def get_all_sections_with_meta(self) -> List[Dict[str, Any]]:
        """Return all sections with values, defaults, and override info."""
        saved_sections = self.store.get_all_sections()
        result = []
        for key in SECTION_KEYS:
            defn = SECTION_DEFINITIONS[key]
            default_val = self._defaults.get(key, {})
            saved = saved_sections.get(key)
            if saved:
                try:
                    current_val = json.loads(saved["config_json"])
                except (json.JSONDecodeError, TypeError):
                    current_val = default_val
                is_customized = True
                updated_at = saved.get("updated_at")
                updated_by = saved.get("updated_by")
            else:
                current_val = default_val
                is_customized = False
                updated_at = None
                updated_by = None

            result.append({
                "key": key,
                "label": defn["label"],
                "icon": defn["icon"],
                "description": defn["description"],
                "fields": defn["fields"],
                "value": current_val,
                "default": default_val,
                "is_customized": is_customized,
                "updated_at": updated_at,
                "updated_by": updated_by,
            })
        return result

    def save_section(
        self,
        section_key: str,
        data: Dict[str, Any],
        updated_by: Optional[str] = None,
    ) -> None:
        """Save a section's config to DB."""
        if section_key not in SECTION_DEFINITIONS:
            raise ValueError(f"Unknown section: {section_key}")
        self.store.save_section(section_key, json.dumps(data, ensure_ascii=False), updated_by)

    def reset_section(self, section_key: str) -> bool:
        """Reset a section to its default (delete DB override)."""
        return self.store.delete_section(section_key)

    def reset_all(self) -> int:
        """Reset all sections to defaults."""
        return self.store.delete_all()

    def export_json(self) -> str:
        """Export full merged config as formatted JSON string."""
        config = self.get_merged_config()
        return json.dumps(config, ensure_ascii=False, indent=2)

    @staticmethod
    def parse_form_to_section(section_key: str, form_data: Dict[str, str]) -> Dict[str, Any]:
        """Parse flat form data into structured section dict using field definitions."""
        defn = SECTION_DEFINITIONS.get(section_key)
        if not defn or not defn["fields"]:
            # For environments section, expect raw JSON
            raw = form_data.get("config_json", "{}")
            return json.loads(raw)

        result = {}
        for field in defn["fields"]:
            fkey = field["key"]
            raw_val = form_data.get(fkey, "")

            if field["type"] == "int":
                try:
                    result[fkey] = int(raw_val) if raw_val else field.get("min", 0)
                except ValueError:
                    result[fkey] = field.get("min", 0)
            elif field["type"] == "float":
                try:
                    result[fkey] = float(raw_val) if raw_val else 0.0
                except ValueError:
                    result[fkey] = 0.0
            elif field["type"] == "list":
                # Newline-separated list
                items = [line.strip() for line in raw_val.split("\n") if line.strip()]
                result[fkey] = items
            else:
                result[fkey] = raw_val

        return result
