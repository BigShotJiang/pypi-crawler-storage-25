"""Metric Status Service - CloudWatch metric status for dashboard."""

import logging
from datetime import datetime, timedelta

from src.common.timezone import KST
from typing import Any

from src.portal.config import PortalSettings
from src.portal.services.metric_config_service import MetricConfigService

logger = logging.getLogger(__name__)

# 서비스 → CloudWatch 네임스페이스 매핑
CW_NAMESPACE_MAP = {
    "mwaa": "AWS/MWAA",
    "msk": "AWS/Kafka",
    "rds": "AWS/RDS",
    "sagemaker": "AWS/SageMaker",
    "sagemaker endpoint": "AWS/SageMaker",
    "emr(cluster)": "AWS/ElasticMapReduce",
    "emr(serverless)": "AWS/EMRServerless",
}


class MetricStatusService:
    """Fetch CloudWatch data for enabled metrics and produce dashboard data."""

    def __init__(self, config_service: MetricConfigService, settings: PortalSettings):
        self.config_service = config_service
        self.settings = settings
        self._cw_client = None

    def _get_cw_client(self):
        if self._cw_client is not None:
            return self._cw_client

        from botocore.config import Config

        if self.settings.environment == "test":
            import boto3

            self._cw_client = boto3.client(
                "cloudwatch",
                endpoint_url="http://localhost:4566",
                region_name="ap-northeast-2",
                aws_access_key_id="test",
                aws_secret_access_key="test",
                config=Config(
                    connect_timeout=3,
                    read_timeout=5,
                    retries={"max_attempts": 0},
                ),
            )
        else:
            from src.common.services.aws_session import get_boto3_client

            self._cw_client = get_boto3_client("cloudwatch", region="ap-northeast-2")
        return self._cw_client

    def get_dashboard_data(self) -> dict[str, list[dict[str, Any]]]:
        """Return enabled metric status grouped by service_type.

        Each item: {metric_name, description, latest_value, status, data_points, unit, timestamp}
        status: 'ok' | 'warning' | 'critical' | 'no_data'
        """
        configs = self.config_service.list_configs()
        enabled = [c for c in configs if c.get("enabled")]

        # Group by service_type
        by_service: dict[str, list[dict]] = {}
        for cfg in enabled:
            st = cfg["service_type"]
            if st not in by_service:
                by_service[st] = []
            by_service[st].append(cfg)

        result: dict[str, list[dict[str, Any]]] = {}

        try:
            cw = self._get_cw_client()
        except Exception as e:
            logger.error(f"Failed to create CloudWatch client: {e}")
            # Return configs with no_data status
            for st, cfgs in by_service.items():
                result[st] = [
                    {
                        "metric_name": c["metric_name"],
                        "description": c.get("description", ""),
                        "latest_value": None,
                        "status": "no_data",
                        "data_points": [],
                        "unit": "",
                        "timestamp": None,
                    }
                    for c in cfgs
                ]
            return result

        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=1)
        daily_start = end_time - timedelta(days=7)

        for service_type, cfgs in by_service.items():
            namespace = CW_NAMESPACE_MAP.get(service_type)
            items = []
            for cfg in cfgs:
                item = self._fetch_metric_status(
                    cw,
                    namespace,
                    cfg["metric_name"],
                    cfg.get("description", ""),
                    start_time,
                    end_time,
                    daily_start,
                )
                items.append(item)
            result[service_type] = items

        return result

    def _fetch_metric_status(
        self,
        cw,
        namespace: str | None,
        metric_name: str,
        description: str,
        start_time: datetime,
        end_time: datetime,
        daily_start: datetime | None = None,
    ) -> dict[str, Any]:
        """Fetch a single metric's recent data from CloudWatch."""
        no_data_base = {
            "metric_name": metric_name,
            "description": description,
            "latest_value": None,
            "status": "no_data",
            "data_points": [],
            "unit": "",
            "timestamp": None,
            "daily_data_points": [],
            "previous_value": None,
            "change_pct": None,
            "is_failure_metric": self._is_failure_metric(metric_name),
        }
        if not namespace:
            return no_data_base

        try:
            # 5분 간격 데이터 (기존)
            resp = cw.get_metric_statistics(
                Namespace=namespace,
                MetricName=metric_name,
                StartTime=start_time,
                EndTime=end_time,
                Period=300,  # 5 minutes
                Statistics=["Average", "Maximum", "Sum"],
            )
            data_points = sorted(resp.get("Datapoints", []), key=lambda x: x["Timestamp"])

            if not data_points:
                return no_data_base

            latest = data_points[-1]
            latest_value = latest.get("Sum", latest.get("Average", 0))
            unit = latest.get("Unit", "")

            # Determine status based on metric value
            status = self._determine_status(metric_name, latest_value)

            # Format data points for chart
            chart_points = [
                {
                    "timestamp": dp["Timestamp"].isoformat(),
                    "value": dp.get("Sum", dp.get("Average", 0)),
                }
                for dp in data_points
            ]

            # 일별 데이터 (7일, Period=86400)
            daily_data_points: list[dict[str, Any]] = []
            previous_value: float | None = None
            change_pct: float | None = None

            if daily_start:
                try:
                    daily_resp = cw.get_metric_statistics(
                        Namespace=namespace,
                        MetricName=metric_name,
                        StartTime=daily_start,
                        EndTime=end_time,
                        Period=86400,  # 1 day
                        Statistics=["Average", "Sum"],
                    )
                    daily_raw = sorted(
                        daily_resp.get("Datapoints", []),
                        key=lambda x: x["Timestamp"],
                    )
                    daily_data_points = [
                        {
                            "date": dp["Timestamp"].strftime("%Y-%m-%d"),
                            "value": round(dp.get("Average", dp.get("Sum", 0)), 4),
                        }
                        for dp in daily_raw
                    ]
                    # change_pct: 마지막 두 일별 데이터 비교
                    if len(daily_data_points) >= 2:
                        today_val = daily_data_points[-1]["value"]
                        yesterday_val = daily_data_points[-2]["value"]
                        previous_value = yesterday_val
                        if yesterday_val != 0:
                            change_pct = round((today_val - yesterday_val) / yesterday_val * 100, 2)
                except Exception as e:
                    logger.debug(f"Failed to fetch daily data for {metric_name}: {e}")

            return {
                "metric_name": metric_name,
                "description": description,
                "latest_value": round(latest_value, 4),
                "status": status,
                "data_points": chart_points,
                "unit": unit,
                "timestamp": latest["Timestamp"].isoformat(),
                "daily_data_points": daily_data_points,
                "previous_value": previous_value,
                "change_pct": change_pct,
                "is_failure_metric": self._is_failure_metric(metric_name),
            }
        except Exception as e:
            logger.warning(f"Failed to fetch {namespace}/{metric_name}: {e}")
            return {**no_data_base, "error": str(e)}

    @staticmethod
    def _is_failure_metric(metric_name: str) -> bool:
        """Return True if the metric represents failures/errors (higher = worse)."""
        failure_keywords = ["fail", "error", "offline", "under"]
        name_lower = metric_name.lower()
        return any(kw in name_lower for kw in failure_keywords)

    def _determine_status(self, metric_name: str, value: float) -> str:
        """Determine metric status based on name pattern and value.

        Failure/error metrics: value > 0 is concerning.
        """
        if self._is_failure_metric(metric_name):
            if value > 10:
                return "critical"
            elif value > 0:
                return "warning"
            return "ok"

        # Generic: treat as informational
        return "ok"
