"""Alert Config Service - 이상 탐지 알림 설정 관리 서비스."""

import logging
from typing import Any

from src.portal.services.alert_config_store import AlertConfigStore

logger = logging.getLogger(__name__)


class AlertConfigService:
    """서비스/메트릭별 이상 탐지 sensitivity, threshold 설정 관리."""

    def __init__(self, store: AlertConfigStore):
        self.store = store

    def list_configs(self, service_type: str | None = None) -> list[dict[str, Any]]:
        return self.store.list_configs(service_type)

    def get_config(self, config_id: int) -> dict[str, Any] | None:
        return self.store.get_config(config_id)

    def upsert_config(
        self,
        service_type: str,
        metric_name: str,
        sensitivity: float = 0.7,
        threshold_upper: float | None = None,
        threshold_lower: float | None = None,
        enabled: bool = True,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> dict[str, Any]:
        return self.store.upsert_config(
            service_type=service_type,
            metric_name=metric_name,
            sensitivity=sensitivity,
            threshold_upper=threshold_upper,
            threshold_lower=threshold_lower,
            enabled=enabled,
            description=description,
            updated_by=updated_by,
        )

    def delete_config(self, config_id: int) -> bool:
        return self.store.delete_config(config_id)

    def get_sensitivity_for_metric(
        self, service_type: str, metric_name: str, default: float = 0.7
    ) -> float:
        """특정 메트릭의 sensitivity 반환. 설정이 없거나 비활성이면 기본값."""
        configs = self.store.list_configs(service_type)
        for cfg in configs:
            if cfg.get("metric_name") == metric_name and cfg.get("enabled"):
                return cfg.get("sensitivity", default)
        return default
