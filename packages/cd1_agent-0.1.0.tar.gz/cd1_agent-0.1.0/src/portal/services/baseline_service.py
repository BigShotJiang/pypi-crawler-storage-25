"""Baseline service wrapper for Portal.

Wraps the existing BaselineStore for portal use.
Uses lazy imports to handle cases where bdp_drift/bdp_common packages
may not be installed in the portal's environment.
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Try to import BaselineStore and models from bdp_drift package
_BASELINE_AVAILABLE = False
try:
    from src.agent_server.bdp_drift.bdp_drift.services.baseline_store import BaselineStore
    from src.agent_server.bdp_drift.bdp_drift.services.models import (
        Baseline,
        BaselineHistory,
        ResourceType,
    )
    _BASELINE_AVAILABLE = True
except ImportError:
    logger.warning(
        "bdp_drift packages not available. "
        "Baseline management will be disabled. "
        "Install bdp-drift and bdp-common packages to enable."
    )
    BaselineStore = None  # type: ignore

    # Minimal fallback dataclasses for type compatibility
    @dataclass
    class Baseline:  # type: ignore
        resource_type: str
        resource_id: str
        version: int = 0
        config: Dict[str, Any] = None  # type: ignore
        config_hash: str = ""
        resource_arn: Optional[str] = None
        description: Optional[str] = None
        tags: Optional[Dict[str, str]] = None
        created_at: Any = None
        updated_at: Any = None
        created_by: Optional[str] = None
        updated_by: Optional[str] = None

    @dataclass
    class BaselineHistory:  # type: ignore
        id: str = ""
        resource_type: str = ""
        resource_id: str = ""
        version: int = 0
        change_type: str = ""
        previous_config: Optional[Dict[str, Any]] = None
        current_config: Dict[str, Any] = None  # type: ignore
        config_hash: str = ""
        change_reason: Optional[str] = None
        changed_at: Any = None
        changed_by: Optional[str] = None


def is_baseline_available() -> bool:
    return _BASELINE_AVAILABLE


def create_baseline_store(
    provider: str, db: Optional[str] = None, secret_id: Optional[str] = None
) -> Optional[Any]:
    """Create a BaselineStore if the package is available."""
    if not _BASELINE_AVAILABLE:
        return None
    store = BaselineStore(provider=provider, db=db, secret_id=secret_id)
    store.ensure_tables()
    return store


class BaselineService:
    """Portal wrapper around BaselineStore."""

    def __init__(self, store: Optional[Any] = None):
        self.store = store
        self.available = store is not None

    def list_baselines(self, resource_type: Optional[str] = None) -> List[Any]:
        if not self.available:
            return []
        return self.store.list_baselines(resource_type=resource_type)

    def get_baseline(self, resource_type: str, resource_id: str) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.get_baseline(resource_type, resource_id)

    def create_baseline(
        self,
        resource_type: str,
        resource_id: str,
        config: Dict[str, Any],
        created_by: str = "admin",
        resource_arn: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.create_baseline(
            resource_type=resource_type,
            resource_id=resource_id,
            config=config,
            created_by=created_by,
            resource_arn=resource_arn,
            description=description,
        )

    def update_baseline(
        self,
        resource_type: str,
        resource_id: str,
        config: Dict[str, Any],
        updated_by: str = "admin",
        reason: Optional[str] = None,
    ) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.update_baseline(
            resource_type=resource_type,
            resource_id=resource_id,
            config=config,
            updated_by=updated_by,
            reason=reason,
        )

    def delete_baseline(self, resource_type: str, resource_id: str) -> bool:
        if not self.available:
            return False
        return self.store.delete_baseline(resource_type, resource_id)

    def get_version_history(self, resource_type: str, resource_id: str) -> List[Any]:
        if not self.available:
            return []
        return self.store.get_version_history(resource_type, resource_id)

    def get_baseline_at_version(
        self, resource_type: str, resource_id: str, version: int
    ) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.get_baseline_at_version(resource_type, resource_id, version)

    def rollback_to_version(
        self,
        resource_type: str,
        resource_id: str,
        version: int,
        rolled_back_by: str = "admin",
    ) -> Optional[Any]:
        if not self.available:
            return None
        return self.store.rollback_to_version(resource_type, resource_id, version, rolled_back_by)

    def compare_versions(
        self,
        resource_type: str,
        resource_id: str,
        version_a: int,
        version_b: int,
    ) -> Dict[str, Any]:
        if not self.available:
            return {}
        return self.store.compare_versions(resource_type, resource_id, version_a, version_b)
