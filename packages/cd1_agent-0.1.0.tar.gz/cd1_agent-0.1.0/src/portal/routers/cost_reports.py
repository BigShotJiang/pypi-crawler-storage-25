"""BDP Cost 리포트 아카이브 라우터."""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import RedirectResponse

from src.portal.dependencies import get_cost_report_service, require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/bdp_cost/reports", tags=["bdp-cost-reports"])


@router.get("")
async def cost_list(
    request: Request,
    user: dict = Depends(require_auth),
    category: Optional[str] = Query(None, description="카테고리 필터"),
):
    report_service = get_cost_report_service(request)
    reports = report_service.list_reports(category=category)
    categories = report_service.get_categories()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost/list.html",
        {
            "request": request,
            "user": user,
            "reports": reports,
            "total_count": len(reports),
            "categories": categories,
            "selected_category": category,
            "active_page": "bdp-cost-reports",
        },
    )


@router.get("/{report_id}")
async def cost_detail(
    request: Request,
    report_id: str,
    user: dict = Depends(require_auth),
):
    report_service = get_cost_report_service(request)
    report = report_service.get_report(report_id)

    if report is None:
        return RedirectResponse(url="/bdp_cost/reports", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost/detail.html",
        {
            "request": request,
            "user": user,
            "report": report,
            "active_page": "bdp-cost-reports",
        },
    )


@router.post("/run")
async def cost_run(
    request: Request,
    user: dict = Depends(require_auth),
):
    """비용 탐지 실행 트리거."""
    import httpx

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                "http://localhost:8010/invoke",
                json={"action": "detect"},
            )
            response.raise_for_status()
    except Exception as e:
        logger.error(f"Failed to trigger cost run: {e}")

    return RedirectResponse(url="/bdp_cost/reports", status_code=302)
