"""Settings management router."""

import logging

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, get_settings_service, require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/settings", tags=["settings"])

# Domain config: domain -> (page_title, page_desc, active_page, back_url)
DOMAIN_CONFIG = {
    "main": {
        "page_title": "공통 설정",
        "page_desc": "LLM 및 에이전트 공통 설정값을 관리합니다. Override 값이 환경변수보다 우선 적용됩니다.",
        "active_page": "settings",
        "back_url": None,
    },
    "cost": {
        "page_title": "비용 에이전트 설정",
        "page_desc": "BDP Cost 에이전트의 설정값을 관리합니다. Override 값이 환경변수보다 우선 적용됩니다.",
        "active_page": "bdp-cost-settings",
        "back_url": "/bdp_cost/reports",
    },
    "drift": {
        "page_title": "Drift 에이전트 설정",
        "page_desc": "BDP Drift 에이전트의 설정값을 관리합니다. Override 값이 환경변수보다 우선 적용됩니다.",
        "active_page": "drift-settings",
        "back_url": "/drift/config",
    },
    "metrics": {
        "page_title": "메트릭 에이전트 설정",
        "page_desc": "BDP Metrics 에이전트의 설정값을 관리합니다. Override 값이 환경변수보다 우선 적용됩니다.",
        "active_page": "metrics-settings",
        "back_url": "/metrics/config",
    },
}


def _render_settings(request, user, domain: str):
    """Render settings page for a given domain."""
    settings_service = get_settings_service(request)
    settings_list = settings_service.get_by_domain(domain)

    # Group by category
    groups: dict = {}
    for s in settings_list:
        group = s["group"]
        if group not in groups:
            groups[group] = []
        groups[group].append(s)

    cfg = DOMAIN_CONFIG[domain]
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "settings/index.html",
        {
            "request": request,
            "user": user,
            "groups": groups,
            "active_page": cfg["active_page"],
            "page_title_text": cfg["page_title"],
            "page_desc": cfg["page_desc"],
            "back_url": cfg["back_url"],
            "redirect_url": f"/settings/{domain}" if domain != "main" else "/settings",
        },
    )


@router.get("")
async def settings_index(
    request: Request,
    user: dict = Depends(require_auth),
):
    return _render_settings(request, user, "main")


@router.get("/cost")
async def settings_cost(
    request: Request,
    user: dict = Depends(require_auth),
):
    return _render_settings(request, user, "cost")


@router.get("/drift")
async def settings_drift(
    request: Request,
    user: dict = Depends(require_auth),
):
    return _render_settings(request, user, "drift")


@router.get("/metrics")
async def settings_metrics(
    request: Request,
    user: dict = Depends(require_auth),
):
    return _render_settings(request, user, "metrics")


@router.post("/update")
async def settings_update(
    request: Request,
    key: str = Form(...),
    value: str = Form(...),
    redirect: str = Form("/settings"),
    user: dict = Depends(require_auth),
):
    settings_service = get_settings_service(request)
    settings_service.update_setting(key, value, updated_by=user.get("name", "admin"))
    return RedirectResponse(url=redirect, status_code=302)


@router.post("/reset")
async def settings_reset(
    request: Request,
    key: str = Form(...),
    redirect: str = Form("/settings"),
    user: dict = Depends(require_auth),
):
    settings_service = get_settings_service(request)
    settings_service.delete_override(key)
    return RedirectResponse(url=redirect, status_code=302)
