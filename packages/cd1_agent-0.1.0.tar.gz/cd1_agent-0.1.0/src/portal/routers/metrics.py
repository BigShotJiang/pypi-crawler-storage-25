"""Metrics report management router."""

import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import RedirectResponse

from src.portal.dependencies import get_metrics_report_service, require_auth

logger = logging.getLogger(__name__)

# Metric types for filtering
METRIC_TYPES = [
    "msk", "mwaa", "subnet-ip", "service-quota",
    "eks-pod", "eks-node", "eks-nodegroup",
    "rds", "sagemaker-endpoint", "emr-cluster", "emr-serverless",
]

SEVERITIES = ["critical", "high", "medium", "low"]

router = APIRouter(prefix="/metrics", tags=["metrics"])


@router.get("")
async def metrics_list(
    request: Request,
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    resource_type: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_auth),
):
    report_service = get_metrics_report_service(request)
    per_page = 20
    offset = (page - 1) * per_page

    reports = report_service.list_reports(
        start_date=start_date,
        end_date=end_date,
        resource_type=resource_type,
        severity=severity,
        limit=per_page,
        offset=offset,
    )
    total_count = report_service.get_report_count(
        start_date=start_date,
        end_date=end_date,
    )
    total_pages = max(1, (total_count + per_page - 1) // per_page)

    # Parse resource_types JSON for display
    for r in reports:
        if isinstance(r.resource_types, str):
            try:
                r.resource_types = json.loads(r.resource_types)
            except (json.JSONDecodeError, TypeError):
                pass
        if isinstance(r.by_severity, str):
            try:
                r.by_severity = json.loads(r.by_severity)
            except (json.JSONDecodeError, TypeError):
                pass

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metrics/list.html",
        {
            "request": request,
            "user": user,
            "reports": reports,
            "metric_types": METRIC_TYPES,
            "severities": SEVERITIES,
            "filter_start_date": start_date or "",
            "filter_end_date": end_date or "",
            "filter_resource_type": resource_type or "",
            "filter_severity": severity or "",
            "page": page,
            "total_pages": total_pages,
            "total_count": total_count,
            "active_page": "metrics",
        },
    )


@router.get("/{report_id}")
async def metrics_detail(
    request: Request,
    report_id: str,
    user: dict = Depends(require_auth),
):
    report_service = get_metrics_report_service(request)
    report = report_service.get_report(report_id)

    if report is None:
        return RedirectResponse(url="/metrics", status_code=302)

    # Parse JSON fields for display
    if isinstance(report.resource_types, str):
        try:
            report.resource_types = json.loads(report.resource_types)
        except (json.JSONDecodeError, TypeError):
            pass
    if isinstance(report.by_severity, str):
        try:
            report.by_severity = json.loads(report.by_severity)
        except (json.JSONDecodeError, TypeError):
            pass

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metrics/detail.html",
        {
            "request": request,
            "user": user,
            "report": report,
            "active_page": "metrics",
        },
    )


@router.post("/run")
async def metrics_run(
    request: Request,
    user: dict = Depends(require_auth),
):
    """Trigger a new metrics detection run via the serverpod API."""
    import httpx

    # Read enabled metrics from config DB
    config_service = request.app.state.metric_config_service
    enabled = config_service.get_enabled_by_service()
    resource_types = list(enabled.keys()) if enabled else []

    if not resource_types:
        return RedirectResponse(url="/metrics", status_code=302)

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                "http://localhost:8009/invoke",
                json={
                    "action": "detect",
                    "resource_types": resource_types,
                    "enabled_metrics": enabled,
                },
            )
            response.raise_for_status()
    except Exception as e:
        logger.error(f"Failed to trigger metrics run: {e}")

    return RedirectResponse(url="/metrics", status_code=302)
