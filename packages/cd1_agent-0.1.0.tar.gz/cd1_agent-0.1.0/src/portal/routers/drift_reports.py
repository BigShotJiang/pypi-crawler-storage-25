"""Config drift report management router."""

import logging

from fastapi import APIRouter, Depends, Request

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/drift", tags=["drift"])


@router.get("")
async def drift_list(
    request: Request,
    user: dict = Depends(require_auth),
):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift/list.html",
        {
            "request": request,
            "user": user,
            "active_page": "drift",
        },
    )
