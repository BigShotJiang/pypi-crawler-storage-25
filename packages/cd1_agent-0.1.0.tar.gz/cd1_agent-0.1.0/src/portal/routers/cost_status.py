"""Cost Status dashboard router - AWS 서비스별 비용 현황.

SSR 라우터: Agent Server에서 데이터를 가져와 템플릿을 렌더링합니다.
"""

import logging
from datetime import datetime

from src.common.timezone import KST

import httpx
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/bdp_cost/status", tags=["bdp-cost-status"])


async def _fetch_dashboard_data(request: Request) -> dict:
    """Agent Server에서 비용 현황 대시보드 데이터를 가져옵니다."""
    settings = request.app.state.settings
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/cost-status/data"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        logger.warning(f"Failed to fetch cost status data from agent server: {e}")
        return {
            "summary": {
                "total_today": 0,
                "total_yesterday": 0,
                "total_change_pct": 0,
                "service_count": 0,
                "anomaly_count": 0,
                "account_id": "",
                "account_name": "",
                "currency": "KRW",
            },
            "services": [],
            "account_info": {"account_id": "", "account_name": ""},
            "fetched_at": "",
            "error": str(e),
        }


@router.get("")
async def dashboard(
    request: Request,
    user: dict = Depends(require_auth),
):
    data = await _fetch_dashboard_data(request)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_status/dashboard.html",
        {
            "request": request,
            "user": user,
            "summary": data["summary"],
            "services": data["services"],
            "account_info": data.get("account_info", {}),
            "error": data.get("error"),
            "fetched_at": data.get("fetched_at", ""),
            "now": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
            "active_page": "bdp-cost-status",
        },
    )


@router.get("/api/data")
async def api_data(
    request: Request,
    user: dict = Depends(require_auth),
):
    data = await _fetch_dashboard_data(request)
    return JSONResponse(content=data)
