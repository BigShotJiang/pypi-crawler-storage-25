"""Drift Config CRUD router."""

import json
import logging

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional

from src.portal.dependencies import require_auth
from src.portal.services.drift_config_service import (
    RESOURCE_TYPE_CONFIGS,
    RESOURCE_TYPES,
    ValidationError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/drift/config", tags=["drift-config"])


def _get_service(request: Request):
    return request.app.state.drift_config_service


class ConfigUpdateBody(BaseModel):
    resource_type: str
    resource_id: str
    enabled: int = 1
    description: str = ""
    check_items: Optional[str] = None  # JSON string; None = don't update


@router.put("/api/{config_id}")
async def update_config_api(
    request: Request,
    config_id: int,
    body: ConfigUpdateBody,
    user: dict = Depends(require_auth),
):
    """JSON API for inline editing — returns updated config or 422 on validation error."""
    svc = _get_service(request)
    existing = svc.get_config(config_id)
    if not existing:
        return JSONResponse(status_code=404, content={"detail": "설정을 찾을 수 없습니다."})
    try:
        update_kwargs = dict(
            resource_type=body.resource_type,
            resource_id=body.resource_id,
            enabled=body.enabled,
            description=body.description or None,
            updated_by=user.get("name", "admin"),
        )
        if body.check_items is not None:
            update_kwargs["check_items"] = body.check_items
        svc.update_config(config_id, **update_kwargs)
    except ValidationError as e:
        return JSONResponse(status_code=422, content={"errors": e.errors})
    updated = svc.get_config(config_id)
    return JSONResponse(content=dict(updated))


@router.get("")
async def list_configs(
    request: Request,
    resource_type: str = "",
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    configs = svc.list_configs(resource_type=resource_type or None)
    resource_types = svc.get_resource_types()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift_config/list.html",
        {
            "request": request,
            "user": user,
            "configs": configs,
            "resource_types": resource_types,
            "all_resource_types": RESOURCE_TYPES,
            "resource_type_configs": RESOURCE_TYPE_CONFIGS,
            "filter_resource_type": resource_type,
            "active_page": "drift-config",
        },
    )


@router.get("/create")
async def create_form(
    request: Request,
    user: dict = Depends(require_auth),
):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift_config/form.html",
        {
            "request": request,
            "user": user,
            "config": None,
            "all_resource_types": RESOURCE_TYPES,
            "resource_type_configs": RESOURCE_TYPE_CONFIGS,
            "active_page": "drift-config",
        },
    )


@router.post("/create")
async def create_config(
    request: Request,
    resource_type: str = Form(...),
    resource_id: str = Form(...),
    check_items: str = Form("{}"),
    enabled: int = Form(0),
    description: str = Form(""),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    try:
        svc.create_config(
            resource_type=resource_type,
            resource_id=resource_id,
            check_items=check_items,
            enabled=enabled,
            description=description or None,
            updated_by=user.get("name", "admin"),
        )
    except Exception as e:
        logger.error(f"Failed to create drift config: {e}")
    return RedirectResponse(url="/drift/config", status_code=302)


@router.get("/{config_id}/edit")
async def edit_form(
    request: Request,
    config_id: int,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    config = svc.get_config(config_id)
    if not config:
        return RedirectResponse(url="/drift/config", status_code=302)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift_config/form.html",
        {
            "request": request,
            "user": user,
            "config": config,
            "all_resource_types": RESOURCE_TYPES,
            "resource_type_configs": RESOURCE_TYPE_CONFIGS,
            "active_page": "drift-config",
        },
    )


@router.post("/{config_id}/edit")
async def update_config(
    request: Request,
    config_id: int,
    resource_type: str = Form(...),
    resource_id: str = Form(...),
    check_items: str = Form("{}"),
    enabled: int = Form(0),
    description: str = Form(""),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    svc.update_config(
        config_id,
        resource_type=resource_type,
        resource_id=resource_id,
        check_items=check_items,
        enabled=enabled,
        description=description or None,
        updated_by=user.get("name", "admin"),
    )
    return RedirectResponse(url="/drift/config", status_code=302)


@router.post("/{config_id}/delete")
async def delete_config(
    request: Request,
    config_id: int,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    svc.delete_config(config_id)
    return RedirectResponse(url="/drift/config", status_code=302)


@router.post("/import-csv")
async def import_csv(
    request: Request,
    csv_content: str = Form(...),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    result = svc.import_csv(csv_content, updated_by=user.get("name", "admin"))
    logger.info(f"CSV import result: {result}")
    configs = svc.list_configs()
    resource_types = svc.get_resource_types()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift_config/list.html",
        {
            "request": request,
            "user": user,
            "configs": configs,
            "resource_types": resource_types,
            "all_resource_types": RESOURCE_TYPES,
            "resource_type_configs": RESOURCE_TYPE_CONFIGS,
            "filter_resource_type": "",
            "import_result": result,
            "active_page": "drift-config",
        },
    )


@router.get("/export-csv")
async def export_csv(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    csv_content = svc.export_csv()
    return StreamingResponse(
        iter([csv_content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=bdp_drift_configs.csv"},
    )
