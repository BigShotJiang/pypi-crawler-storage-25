"""Authentication routes (login/logout/callback)."""

import logging

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse

from src.portal.dependencies import get_auth, get_settings

logger = logging.getLogger(__name__)

router = APIRouter(tags=["auth"])


@router.get("/login")
async def login(request: Request):
    settings = get_settings(request)
    if not settings.auth_enabled:
        return RedirectResponse(url="/", status_code=302)

    auth = get_auth(request)
    if not auth.enabled:
        return RedirectResponse(url="/", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "login.html")


@router.post("/login")
async def login_redirect(request: Request):
    auth = get_auth(request)
    if not auth.enabled:
        return RedirectResponse(url="/", status_code=302)
    return await auth.login_redirect(request)


@router.get("/auth/callback", name="auth_callback")
async def auth_callback(request: Request):
    auth = get_auth(request)
    if not auth.enabled:
        return RedirectResponse(url="/", status_code=302)

    try:
        user = await auth.handle_callback(request)
        request.session["user"] = {
            "name": user["name"],
            "email": user["email"],
            "sub": user["sub"],
        }
        logger.info(f"User logged in: {user['name']}")
        access_token = user["token"].get("access_token", "")
        templates = request.app.state.templates
        return templates.TemplateResponse(request, "callback.html", {
            "access_token": access_token,
        })
    except Exception as e:
        logger.error(f"Auth callback error: {e}")
        return RedirectResponse(url="/login?error=auth_failed", status_code=302)


@router.get("/logout")
async def logout(request: Request):
    auth = get_auth(request)
    request.session.clear()
    if auth.enabled:
        logout_url = auth.get_logout_url()
        return RedirectResponse(url=logout_url, status_code=302)
    return RedirectResponse(url="/login", status_code=302)
