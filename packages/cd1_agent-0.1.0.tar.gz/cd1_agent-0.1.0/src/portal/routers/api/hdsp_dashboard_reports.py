"""HDSP Dashboard reports API router - JSON endpoints for HDSP dashboard report data."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse

from src.portal.dependencies import (
    get_hdsp_dashboard_report_service,
    require_jwt_auth,
    require_jwt_auth_flexible,
)
from src.portal.services.hdsp_dashboard_report_service import HdspDashboardReportService

router = APIRouter(prefix="/hdsp-dashboard", tags=["hdsp-dashboard"])


@router.get("/reports")
async def list_reports(
    start_date: str | None = Query(None),
    end_date: str | None = Query(None),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_jwt_auth),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    per_page = 20
    offset = (page - 1) * per_page
    reports = report_service.list_reports(
        start_date=start_date,
        end_date=end_date,
        limit=per_page,
        offset=offset,
    )
    total = report_service.get_report_count(start_date=start_date, end_date=end_date)
    return {
        "items": reports,
        "total": total,
        "page": page,
        "page_size": per_page,
    }


@router.get("/reports/{report_id}")
async def get_report(
    report_id: str,
    user: dict = Depends(require_jwt_auth),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    report = report_service.get_report(report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/reports/{report_id}/html", response_class=HTMLResponse)
async def get_report_html(
    report_id: str,
    user: dict = Depends(require_jwt_auth_flexible),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    html = report_service.render_html(report_id)
    if html is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return HTMLResponse(content=html)
