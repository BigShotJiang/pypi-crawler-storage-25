"""HolmesGPT Session API router - dedicated chat sessions."""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from src.portal.dependencies import get_holmesgpt_service, require_jwt_auth
from src.portal.services.holmesgpt_service import HolmesGPTService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/holmes-gpt", tags=["holmes-gpt"])


class ChatRequest(BaseModel):
    message: str


@router.get("/sessions")
async def list_sessions(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    search: str = Query(None),
    user: dict = Depends(require_jwt_auth),
    service: HolmesGPTService = Depends(get_holmesgpt_service),
):
    if search:
        sessions, total = service.search_sessions(search, page, per_page)
    else:
        sessions, total = service.list_sessions(page, per_page)
    return {"sessions": sessions, "total": total, "page": page, "per_page": per_page}


@router.post("/sessions")
async def create_session(
    user: dict = Depends(require_jwt_auth),
    service: HolmesGPTService = Depends(get_holmesgpt_service),
):
    return service.create_session()


@router.get("/sessions/{session_id}")
async def get_session(
    session_id: str,
    user: dict = Depends(require_jwt_auth),
    service: HolmesGPTService = Depends(get_holmesgpt_service),
):
    result = service.get_session_with_messages(session_id)
    if not result:
        raise HTTPException(status_code=404, detail="Session not found")
    return result


@router.delete("/sessions/{session_id}")
async def delete_session(
    session_id: str,
    user: dict = Depends(require_jwt_auth),
    service: HolmesGPTService = Depends(get_holmesgpt_service),
):
    if not service.delete_session(session_id):
        raise HTTPException(status_code=404, detail="Session not found")
    return {"ok": True}


@router.post("/sessions/{session_id}/chat")
async def chat_in_session(
    session_id: str,
    body: ChatRequest,
    user: dict = Depends(require_jwt_auth),
    service: HolmesGPTService = Depends(get_holmesgpt_service),
):
    # Verify session exists
    session = service.session_store.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return await service.chat_in_session(session_id, body.message)
