"""Cost Reports API router - JSON endpoints for cost report listing and detail."""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse

from src.portal.dependencies import (
    get_cost_report_service,
    require_jwt_auth,
    require_jwt_auth_flexible,
)
from src.portal.services.cost_report_service import CostReportService

router = APIRouter(prefix="/cost/reports", tags=["cost-reports"])


@router.get("")
async def list_reports(
    start_date: Optional[str] = Query(None),
    end_date: Optional[str] = Query(None),
    report_type: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_jwt_auth),
    report_service: CostReportService = Depends(get_cost_report_service),
):
    per_page = 20
    offset = (page - 1) * per_page
    reports = report_service.list_reports(
        start_date=start_date,
        end_date=end_date,
        report_type=report_type,
        limit=per_page,
        offset=offset,
    )
    total = report_service.get_report_count(start_date=start_date, end_date=end_date)
    return {
        "items": reports,
        "total": total,
        "page": page,
        "page_size": per_page,
    }


@router.get("/{report_id}")
async def get_report(
    report_id: str,
    user: dict = Depends(require_jwt_auth),
    report_service: CostReportService = Depends(get_cost_report_service),
):
    report = report_service.get_report(report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.get("/{report_id}/html", response_class=HTMLResponse)
async def get_report_html(
    report_id: str,
    user: dict = Depends(require_jwt_auth_flexible),
    report_service: CostReportService = Depends(get_cost_report_service),
):
    html = report_service.render_html(report_id)
    if html is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return HTMLResponse(content=html)
