"""HITL API router - JSON endpoints for HITL chat interface."""

import logging
from typing import Any

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from pydantic import BaseModel

from src.common.hitl.schemas import HITLAgentType, HITLRequest
from src.portal.dependencies import (
    get_hitl_service,
    get_holmesgpt_service,
    get_settings_service,
    require_jwt_auth,
)
from src.portal.services.hitl_service import HITLService, _resolve_agent_type
from src.portal.services.holmesgpt_service import HolmesGPTService
from src.portal.services.settings_service import SettingsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/hitl", tags=["hitl"])


# ── Request models ───────────────────────────────────


class SendMessageRequest(BaseModel):
    agent_type: str
    message: str
    request_type: str = "prompt_input"
    payload: dict | None = None


class RespondRequest(BaseModel):
    approved: bool
    comment: str = ""


# ── Transform ────────────────────────────────────────


def _to_chat_message(req: HITLRequest, current_user: str) -> dict[str, Any]:
    """Transform HITLRequest into frontend HITLMessage format.

    Role determination:
    - action_approval / confirmation → always "agent" (agent proposes an action)
    - prompt_input + created_by == current_user → "user" (user sent a message)
    - otherwise → "agent"
    """
    req_type = req.request_type.value if hasattr(req.request_type, "value") else req.request_type
    if req_type in ("action_approval", "confirmation"):
        role = "agent"
    elif req.created_by == current_user:
        role = "user"
    else:
        role = "agent"

    content = req.description or req.title or ""
    if not content and req.payload:
        content = req.payload.get("message", "")

    # HolmesGPT agent response: use rendered_html from payload
    agent_type_val = req.agent_type.value if hasattr(req.agent_type, "value") else req.agent_type
    rendered_html = None
    tool_calls = None
    if agent_type_val == "holmesgpt" and role == "agent" and req.payload:
        rendered_html = req.payload.get("rendered_html")
        tool_calls = req.payload.get("tool_calls")

    result = {
        "id": req.id,
        "agent_type": agent_type_val,
        "role": role,
        "content": content,
        "status": req.status.value if hasattr(req.status, "value") else req.status,
        "request_type": req_type,
        "created_at": req.created_at.isoformat()
        if hasattr(req.created_at, "isoformat")
        else str(req.created_at),
        "updated_at": req.updated_at.isoformat()
        if hasattr(req.updated_at, "isoformat")
        else str(req.updated_at),
        "created_by": req.created_by,
    }

    if rendered_html is not None:
        result["rendered_html"] = rendered_html
    if tool_calls is not None:
        result["tool_calls"] = tool_calls

    return result


# ── HolmesGPT background task ──────────────────────


def _get_conversation_history(
    hitl_service: HITLService,
    agent_type: str,
) -> list[dict[str, Any]] | None:
    """Extract conversation_history from the latest holmesgpt agent response."""
    requests, _ = hitl_service.list_requests(agent_type, page=1, per_page=50)
    for req in requests:  # newest first
        agent_val = req.agent_type.value if hasattr(req.agent_type, "value") else req.agent_type
        if agent_val == "holmesgpt" and req.created_by == "holmesgpt" and req.payload:
            history = req.payload.get("conversation_history")
            if history is not None:
                return history
    return None


async def _holmesgpt_background(
    ask: str,
    agent_type_str: str,
    hitl_service: HITLService,
    holmesgpt_service: HolmesGPTService,
):
    """Background task: call HolmesGPT API and save agent response."""
    try:
        conversation_history = _get_conversation_history(hitl_service, agent_type_str)
        result = await holmesgpt_service.chat(ask, conversation_history)

        hitl_service.save_agent_response(
            agent_type=HITLAgentType.HOLMESGPT,
            content=result.get("analysis", "") or "HolmesGPT 응답",
            payload={
                "rendered_html": result.get("rendered_html", ""),
                "conversation_history": result.get("conversation_history"),
                "tool_calls": result.get("tool_calls", []),
            },
            created_by="holmesgpt",
        )
    except Exception:
        logger.exception("HolmesGPT background task failed")
        hitl_service.save_agent_response(
            agent_type=HITLAgentType.HOLMESGPT,
            content="HolmesGPT 호출 중 오류가 발생했습니다.",
            payload={"rendered_html": '<p style="color:red">[ERROR] HolmesGPT 호출 실패</p>'},
            created_by="holmesgpt",
        )


# ── Agent Chat background task ─────────────────────


async def _agent_chat_background(
    ask: str,
    agent_type: HITLAgentType,
    agent_key: str,
    hitl_service: HITLService,
    settings_service: "SettingsService | None" = None,
):
    """Chat Agent ReAct 루프로 자율적 원인 분석.

    Plan → Act(Tool) → Observe → Reflect → (재계획 or 응답)
    LLM이 어떤 데이터를 조회할지 자율적으로 판단하고,
    부족하면 추가 데이터를 조회한 뒤 근본 원인 분석을 수행한다.
    """
    try:
        import os

        from src.common.chat.agent import ChatAgent
        from src.common.services.aws_client import AWSProvider
        from src.common.services.llm_client import LLMProvider

        def _setting(key: str, env_key: str, default: str = "") -> str:
            """DB 설정 우선, 없으면 환경변수 fallback."""
            if settings_service:
                val = settings_service.get_override(key)
                if val:
                    return val
            return os.getenv(env_key, default)

        llm_provider = LLMProvider(_setting("llm_provider", "LLM_PROVIDER", "mock"))
        aws_provider = AWSProvider(os.getenv("AWS_PROVIDER", "mock"))

        agent = ChatAgent(
            llm_provider=llm_provider,
            aws_provider=aws_provider,
            endpoint=_setting("vllm_endpoint", "VLLM_ENDPOINT") or None,
            model_name=_setting("vllm_model", "VLLM_MODEL") or None,
            api_key=_setting("vllm_api_key", "VLLM_API_KEY") or None,
        )

        # ReAct 루프 실행 (Plan→Act→Observe→Reflect→Respond)
        response = agent.chat(ask)

        # Tool 실행 이력 추출
        tool_calls = []
        if agent.current_state and hasattr(agent.current_state, "tool_executions"):
            for te in agent.current_state.tool_executions:
                tool_calls.append(
                    {
                        "tool": te.tool_name,
                        "result_preview": str(te.output)[:500] if te.output else "",
                    }
                )

        hitl_service.save_agent_response(
            agent_type=agent_type,
            content=response,
            payload={"tool_calls": tool_calls},
            created_by=agent_key,
        )
    except Exception:
        logger.exception("Agent chat background task failed")
        hitl_service.save_agent_response(
            agent_type=agent_type,
            content="분석 중 오류가 발생했습니다. 잠시 후 다시 시도해 주세요.",
            payload={},
            created_by=agent_key,
        )


# ── Endpoints ────────────────────────────────────────


@router.get("/messages")
async def get_messages(
    agent_type: str = Query(...),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_jwt_auth),
    hitl_service: HITLService = Depends(get_hitl_service),
):
    hitl_service.expire_stale()
    requests, _ = hitl_service.list_requests(agent_type, page=page, per_page=50)
    current_user = user.get("name", "admin")
    messages = [_to_chat_message(r, current_user) for r in reversed(requests)]
    return {
        "messages": messages,
        "pending_count": hitl_service.get_pending_count(agent_type),
    }


@router.delete("/messages")
async def clear_messages(
    agent_type: str = Query(...),
    user: dict = Depends(require_jwt_auth),
    hitl_service: HITLService = Depends(get_hitl_service),
):
    """에이전트 타입별 대화 내역 전체 삭제."""
    count = hitl_service.clear_messages(agent_type)
    return {"deleted": count}


@router.post("/send")
async def send_message(
    body: SendMessageRequest,
    background_tasks: BackgroundTasks,
    user: dict = Depends(require_jwt_auth),
    hitl_service: HITLService = Depends(get_hitl_service),
    holmesgpt_service: HolmesGPTService = Depends(get_holmesgpt_service),
    settings_service: "SettingsService" = Depends(get_settings_service),
):
    current_user = user.get("name", "admin")
    request = hitl_service.send_request(
        agent_type=body.agent_type,
        message=body.message,
        request_type=body.request_type,
        payload=body.payload,
        user=current_user,
    )

    # If holmesgpt agent, auto-approve user message and dispatch background task
    resolved = _resolve_agent_type(body.agent_type)
    if resolved == HITLAgentType.HOLMESGPT:
        hitl_service.approve(request.id, comment="auto-approved", user="system")
        request = hitl_service.get_request(request.id) or request
        background_tasks.add_task(
            _holmesgpt_background,
            ask=body.message,
            agent_type_str=body.agent_type,
            hitl_service=hitl_service,
            holmesgpt_service=holmesgpt_service,
        )
    elif resolved in (
        HITLAgentType.BDP,
        HITLAgentType.COST,
        HITLAgentType.DRIFT,
        HITLAgentType.BDP_DASHBOARD,
        HITLAgentType.HDSP_DASHBOARD,
    ):
        hitl_service.approve(request.id, comment="auto-approved", user="system")
        request = hitl_service.get_request(request.id) or request
        background_tasks.add_task(
            _agent_chat_background,
            ask=body.message,
            agent_type=resolved,
            agent_key=body.agent_type,
            hitl_service=hitl_service,
            settings_service=settings_service,
        )

    return _to_chat_message(request, current_user)


@router.post("/{request_id}/respond")
async def respond_to_request(
    request_id: str,
    body: RespondRequest,
    user: dict = Depends(require_jwt_auth),
    hitl_service: HITLService = Depends(get_hitl_service),
):
    user_name = user.get("name", "admin")
    if body.approved:
        result = hitl_service.approve(request_id, comment=body.comment, user=user_name)
    else:
        result = hitl_service.reject(request_id, comment=body.comment, user=user_name)

    if result is None:
        raise HTTPException(status_code=404, detail="Request not found")
    return _to_chat_message(result, user_name)
