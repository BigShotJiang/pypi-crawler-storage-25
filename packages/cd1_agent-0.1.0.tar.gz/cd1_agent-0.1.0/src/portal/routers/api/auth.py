"""Auth API router - JWT authentication endpoints."""

from fastapi import APIRouter, Depends

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, require_jwt_auth

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get("/me")
async def get_me(
    settings: PortalSettings = Depends(get_settings),
    user: dict = Depends(require_jwt_auth),
):
    return {"user": user, "auth_enabled": settings.auth_enabled, "environment": settings.environment}
