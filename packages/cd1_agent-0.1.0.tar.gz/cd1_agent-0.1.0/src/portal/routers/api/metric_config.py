"""Metric Config API router - JSON endpoints for metric configuration CRUD."""

import io
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from src.portal.dependencies import (
    get_metric_catalog_service,
    get_metric_config_service,
    require_jwt_auth,
)
from src.portal.services.metric_catalog_service import MetricCatalogService
from src.portal.services.metric_config_service import MetricConfigService, ValidationError

router = APIRouter(prefix="/metrics/config", tags=["metric-config"])


# ── Request models ───────────────────────────────────


class ConfigCreateRequest(BaseModel):
    service_type: str
    metric_name: str
    enabled: int = 1
    description: Optional[str] = None


class ConfigUpdateRequest(BaseModel):
    service_type: str
    metric_name: str
    enabled: int = 1
    description: Optional[str] = None


class ImportCsvRequest(BaseModel):
    csv_content: str


# ── Helpers ──────────────────────────────────────────


def _merged_service_types(
    svc: MetricConfigService,
    catalog: MetricCatalogService,
) -> list[str]:
    db_types = set(svc.get_service_types())
    catalog_types = set(catalog.get_service_types())
    return sorted(db_types | catalog_types)


# ── Endpoints ────────────────────────────────────────


@router.get("")
async def list_configs(
    service_type: Optional[str] = Query(None),
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
    catalog: MetricCatalogService = Depends(get_metric_catalog_service),
):
    configs = svc.list_configs()
    if service_type:
        configs = [c for c in configs if c.get("service_type") == service_type]
    merged_types = _merged_service_types(svc, catalog)
    return {"items": configs, "service_types": merged_types}


@router.post("")
async def create_config(
    body: ConfigCreateRequest,
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
):
    try:
        config_id = svc.create_config(
            service_type=body.service_type,
            metric_name=body.metric_name,
            enabled=body.enabled,
            description=body.description,
            updated_by=user.get("name"),
        )
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=e.errors)
    return {"id": config_id, **body.model_dump()}


@router.put("/{config_id}")
async def update_config(
    config_id: int,
    body: ConfigUpdateRequest,
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
):
    try:
        updated = svc.update_config(
            config_id,
            service_type=body.service_type,
            metric_name=body.metric_name,
            enabled=body.enabled,
            description=body.description,
            updated_by=user.get("name"),
        )
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=e.errors)
    if not updated:
        raise HTTPException(status_code=404, detail="Config not found")
    return {"id": config_id, **body.model_dump()}


@router.delete("/{config_id}")
async def delete_config(
    config_id: int,
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
):
    svc.delete_config(config_id)
    return {"ok": True}


@router.get("/suggestions")
async def get_suggestions(
    service_type: Optional[str] = Query(None),
    user: dict = Depends(require_jwt_auth),
    catalog: MetricCatalogService = Depends(get_metric_catalog_service),
):
    if not service_type:
        return []
    return catalog.get_suggestions(service_type)


@router.post("/import-csv")
async def import_csv(
    body: ImportCsvRequest,
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
):
    result = svc.import_csv(body.csv_content, updated_by=user.get("name"))
    return result


@router.get("/export-csv")
async def export_csv(
    user: dict = Depends(require_jwt_auth),
    svc: MetricConfigService = Depends(get_metric_config_service),
):
    csv_content = svc.export_csv()
    return StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=metric_configs.csv"},
    )
