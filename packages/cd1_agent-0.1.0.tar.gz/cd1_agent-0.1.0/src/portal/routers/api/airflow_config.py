"""Airflow Config API router - JSON endpoints for detection config management."""

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse

from src.portal.dependencies import get_airflow_config_service, require_jwt_auth
from src.portal.services.airflow_config_service import AirflowConfigService

router = APIRouter(prefix="/airflow/config", tags=["airflow-config"])


# ── Static routes FIRST (before {section_key} catch-all) ────────────


@router.get("/sections")
async def get_sections(
    user: dict = Depends(require_jwt_auth),
    svc: AirflowConfigService = Depends(get_airflow_config_service),
):
    sections = svc.get_all_sections_with_meta()
    return {"sections": sections}


@router.post("/reset-all")
async def reset_all(
    user: dict = Depends(require_jwt_auth),
    svc: AirflowConfigService = Depends(get_airflow_config_service),
):
    svc.reset_all()
    return {"status": "ok"}


@router.get("/export-json")
async def export_json(
    user: dict = Depends(require_jwt_auth),
    svc: AirflowConfigService = Depends(get_airflow_config_service),
):
    content = svc.export_json()
    return StreamingResponse(
        iter([content]),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=detection_config.json"},
    )


# ── Parameterized routes ────────────────────────────────────────────


@router.put("/{section_key}")
async def save_section(
    section_key: str,
    request: Request,
    user: dict = Depends(require_jwt_auth),
    svc: AirflowConfigService = Depends(get_airflow_config_service),
):
    data = await request.json()
    try:
        svc.save_section(section_key, data)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    meta = svc.get_section_with_meta(section_key)
    return {"status": "ok", "section": meta}


@router.post("/{section_key}/reset")
async def reset_section(
    section_key: str,
    user: dict = Depends(require_jwt_auth),
    svc: AirflowConfigService = Depends(get_airflow_config_service),
):
    svc.reset_section(section_key)
    return {"status": "ok"}
