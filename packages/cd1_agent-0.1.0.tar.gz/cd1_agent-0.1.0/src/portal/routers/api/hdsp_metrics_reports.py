"""HDSP Metrics reports API router - anomaly detection reports & status."""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse

from src.portal.dependencies import (
    get_hdsp_dashboard_report_service,
    require_jwt_auth,
    require_jwt_auth_flexible,
)
from src.portal.services.hdsp_dashboard_report_service import HdspDashboardReportService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/hdsp_metrics", tags=["hdsp-metrics"])


def _report_to_hdsp_format(report) -> dict:
    """HdspDashboardReport → frontend HdspReport 형식으로 변환."""
    summary = {}
    if report.summary_json:
        try:
            summary = (
                json.loads(report.summary_json)
                if isinstance(report.summary_json, str)
                else report.summary_json
            )
        except (json.JSONDecodeError, TypeError):
            pass

    return {
        "id": report.id,
        "cluster_name": summary.get("cluster_name", "hdsp"),
        "detection_timestamp": (
            report.run_timestamp.isoformat()
            if hasattr(report.run_timestamp, "isoformat")
            else str(report.run_timestamp)
        ),
        "total_anomalies": report.critical + report.warning,
        "by_severity": {"critical": report.critical, "warning": report.warning},
        "namespaces_checked": summary.get("namespaces_checked", []),
        "summary": summary.get("summary", ""),
        "status": report.status,
    }


@router.get("/status/data")
async def get_status_data(
    user: dict = Depends(require_jwt_auth),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    """HDSP 이상 현황 데이터 반환 (최신 리포트 기반)."""
    if not report_service.available:
        return []

    reports = report_service.list_reports(limit=1)
    if not reports:
        return []

    latest = reports[0]
    summary = {}
    if latest.summary_json:
        try:
            summary = (
                json.loads(latest.summary_json)
                if isinstance(latest.summary_json, str)
                else latest.summary_json
            )
        except (json.JSONDecodeError, TypeError):
            pass

    # summary_json 내 anomalies_by_namespace 형식이 있으면 활용
    namespaces = summary.get("anomalies_by_namespace", [])
    if isinstance(namespaces, list):
        return namespaces

    return []


@router.get("/reports")
async def list_reports(
    start_date: str | None = Query(None),
    end_date: str | None = Query(None),
    severity: str | None = Query(None),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_jwt_auth),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    per_page = 20
    offset = (page - 1) * per_page
    reports = report_service.list_reports(
        start_date=start_date,
        end_date=end_date,
        limit=per_page,
        offset=offset,
    )
    total = report_service.get_report_count(start_date=start_date, end_date=end_date)
    return {
        "items": [_report_to_hdsp_format(r) for r in reports],
        "total": total,
        "page": page,
        "page_size": per_page,
    }


@router.get("/reports/{report_id}")
async def get_report(
    report_id: str,
    user: dict = Depends(require_jwt_auth),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    report = report_service.get_report(report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return _report_to_hdsp_format(report)


@router.get("/reports/{report_id}/html", response_class=HTMLResponse)
async def get_report_html(
    report_id: str,
    user: dict = Depends(require_jwt_auth_flexible),
    report_service: HdspDashboardReportService = Depends(get_hdsp_dashboard_report_service),
):
    html = report_service.render_html(report_id)
    if html is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return HTMLResponse(content=html)
