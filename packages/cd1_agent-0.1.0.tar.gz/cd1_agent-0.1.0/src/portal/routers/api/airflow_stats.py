"""Airflow Stats API router - proxy to agent server."""

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, require_jwt_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/airflow/stats", tags=["airflow-stats"])


@router.get("/daily-rates")
async def get_daily_rates(
    days: int = 31,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/airflow/daily-rates"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params={"days": days},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
