"""ADW API router - proxy to agent server for ADW dashboard metrics."""

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, require_jwt_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/adw", tags=["adw"])

ADW_METRIC_TYPES = {
    "bq-slot-utilization",
    "bq-query-performance",
    "bq-job-history",
    "bq-dataset-storage",
    "bq-cost-analysis",
    "bq-reservation-utilization",
    "composer-dag-stats",
    "composer-environment",
    "composer-task-metrics",
    "gcs-bucket-storage",
    "gcs-access-patterns",
    "gcs-storage-classes",
    "bastion-status",
    "bastion-sessions",
    "bastion-resources",
    # Composer 인프라
    "scheduler-resources",
    "scheduler-heartbeat",
    "dagprocessor-resources",
    "dagprocessor-parsing",
    "worker-pool-status",
    "worker-resources",
    "worker-task-execution",
    "triggerer-resources",
    "triggerer-stats",
    "webserver-resources",
    "webserver-requests",
    "cloudsql-resources",
    "cloudsql-health",
    "bq-slot-timeline",
    "gcs-dag-bucket",
    "gcs-backup-bucket",
    "composer-overview-health",
    "composer-dag-statistics",
}


@router.get("/metrics/{metric_type}")
async def get_adw_metrics(
    request: Request,
    metric_type: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """ADW 서비스 시계열 메트릭 프록시."""
    if metric_type not in ADW_METRIC_TYPES:
        raise HTTPException(status_code=404, detail=f"Unknown metric type: {metric_type}")
    qs = str(request.query_params) if request.query_params else "days=31"
    url = f"{settings.agent_server_url}/agents/adw_dashboard/infra/metrics/{metric_type}?{qs}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/infra-report")
async def export_infra_report(
    days: int = 31,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """ADW 인프라 현황 HTML 리포트 프록시."""
    from fastapi.responses import HTMLResponse

    url = f"{settings.agent_server_url}/agents/adw_dashboard/export/infra-report?days={days}"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


@router.get("/export/service-report")
async def export_service_report(
    days: int = 31,
    category: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """ADW 서비스 현황 HTML 리포트 프록시."""
    from fastapi.responses import HTMLResponse

    url = f"{settings.agent_server_url}/agents/adw_dashboard/export/service-report?days={days}"
    if category:
        url += f"&category={category}"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


# ── PDF Export ──────────────────────────────────────


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf(
    days: int = 31,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """ADW 인프라 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/adw_dashboard/export/infra-report-pdf?days={days}"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = 31,
    category: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """ADW 서비스 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/adw_dashboard/export/service-report-pdf?days={days}"
    if category:
        url += f"&category={category}"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
