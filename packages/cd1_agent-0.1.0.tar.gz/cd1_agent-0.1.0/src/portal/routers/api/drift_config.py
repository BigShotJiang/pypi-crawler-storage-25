"""Drift Config API router - JSON endpoints for drift configuration CRUD."""

import io
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from src.portal.dependencies import get_config_mapper, get_drift_config_service, require_jwt_auth
from src.portal.services.drift_config_service import (
    RESOURCE_TYPE_CONFIGS,
    RESOURCE_TYPES,
    DriftConfigService,
    ValidationError,
)

router = APIRouter(prefix="/drift/config", tags=["drift-config"])


# ── Request models ───────────────────────────────────


class ConfigCreateRequest(BaseModel):
    resource_type: str
    resource_id: str
    check_items: Optional[str] = None
    enabled: int = 1
    description: Optional[str] = None


class ConfigUpdateRequest(BaseModel):
    resource_type: str
    resource_id: str
    check_items: Optional[str] = None
    enabled: int = 1
    description: Optional[str] = None


class ImportCsvRequest(BaseModel):
    csv_content: str


class FetchCurrentRequest(BaseModel):
    resource_type: str
    resource_id: str


# ── Static routes FIRST (before {config_id} catch-all) ──────────────


@router.get("/resource-types")
async def get_resource_types(
    user: dict = Depends(require_jwt_auth),
):
    return {
        "resource_types": RESOURCE_TYPES,
        "resource_type_configs": RESOURCE_TYPE_CONFIGS,
    }


@router.post("/fetch-current")
async def fetch_current_config(
    body: FetchCurrentRequest,
    user: dict = Depends(require_jwt_auth),
    mapper=Depends(get_config_mapper),
):
    """AWS에서 현재 리소스 설정을 조회하여 check_items 형식으로 반환."""
    if mapper is None:
        raise HTTPException(
            status_code=503,
            detail="현황 조회 기능을 사용할 수 없습니다. (bdp_drift 패키지 미설치)",
        )
    check_items = mapper.fetch_and_map(body.resource_type, body.resource_id)
    return {"check_items": check_items}


@router.post("/import-csv")
async def import_csv(
    body: ImportCsvRequest,
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    result = svc.import_csv(body.csv_content, updated_by=user.get("name"))
    return result


@router.get("/export-csv")
async def export_csv(
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    csv_content = svc.export_csv()
    return StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=bdp_drift_configs.csv"},
    )


# ── Parameterized routes ────────────────────────────────────────────


@router.get("")
async def list_configs(
    resource_type: Optional[str] = Query(None),
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    configs = svc.list_configs()
    if resource_type:
        configs = [c for c in configs if c.get("resource_type") == resource_type]
    types = svc.get_resource_types()
    return {"items": configs, "resource_types": types}


@router.post("")
async def create_config(
    body: ConfigCreateRequest,
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    try:
        config_id = svc.create_config(
            resource_type=body.resource_type,
            resource_id=body.resource_id,
            check_items=body.check_items,
            enabled=body.enabled,
            description=body.description,
            updated_by=user.get("name"),
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return {"id": config_id, **body.model_dump()}


@router.put("/{config_id}")
async def update_config(
    config_id: int,
    body: ConfigUpdateRequest,
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    existing = svc.get_config(config_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Config not found")
    try:
        update_kwargs = dict(
            resource_type=body.resource_type,
            resource_id=body.resource_id,
            enabled=body.enabled,
            description=body.description,
            updated_by=user.get("name"),
        )
        if body.check_items is not None:
            update_kwargs["check_items"] = body.check_items
        svc.update_config(config_id, **update_kwargs)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    updated = svc.get_config(config_id)
    return updated


@router.delete("/{config_id}")
async def delete_config(
    config_id: int,
    user: dict = Depends(require_jwt_auth),
    svc: DriftConfigService = Depends(get_drift_config_service),
):
    svc.delete_config(config_id)
    return {"ok": True}
