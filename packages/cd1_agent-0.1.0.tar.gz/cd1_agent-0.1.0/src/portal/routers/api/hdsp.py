"""HDSP API router - proxy to agent server for K8s infra data + HDSP metrics."""

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, require_jwt_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/hdsp", tags=["hdsp"])


@router.get("/l0-ingestion")
async def get_l0_ingestion(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """L0 입수 현황 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/l0-ingestion"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/data")
async def get_hdsp_data(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """K8s 인프라 현황 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── HDSP Metrics ─────────────────────────────────────

HDSP_METRIC_TYPES = {
    "jupyter-access",
    "minio-usage",
    "minio-access",
    "spark-failures",
    "hdsp-api-errors",
    "nfs-usage",
    "eks-pod-resources",
    "eks-node-resources",
    "eks-event-trends",
    "log-backup-status",
    "spark-cluster-status",
    "minio-admin",
    "nfs-iops",
    "hdsp-api-latency",
    "backup-success-rate",
    "haproxy-stats",
    "docker-registry-stats",
    "jupyter-cluster-status",
    "cost-explorer-savings",
    "usage-conversion-savings",
    "universe-failures",
    "sobicare-workflows",
}


@router.get("/metrics/info")
async def get_hdsp_metrics_info(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP 메트릭 mock/real 여부 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/metrics/info"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── GCP Cost (구체 경로는 와일드카드보다 앞에 등록) ──────


@router.get("/metrics/gcp-cost-monthly")
async def get_gcp_cost_monthly(
    year: int | None = None,
    env: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """GCP 월별 비용 프록시."""
    params: dict[str, str] = {}
    if year is not None:
        params["year"] = str(year)
    if env is not None:
        params["env"] = env
    qs = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/metrics/gcp-cost-monthly"
    if qs:
        url += f"?{qs}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/metrics/gcp-cost-daily")
async def get_gcp_cost_daily(
    year: int | None = None,
    month: int | None = None,
    env: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """GCP 일별 비용 프록시."""
    params: dict[str, str] = {}
    if year is not None:
        params["year"] = str(year)
    if month is not None:
        params["month"] = str(month)
    if env is not None:
        params["env"] = env
    qs = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/metrics/gcp-cost-daily"
    if qs:
        url += f"?{qs}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/metrics/{metric_type}")
async def get_hdsp_metrics(
    metric_type: str,
    days: int = 31,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP 서비스 시계열 메트릭 프록시."""
    if metric_type not in HDSP_METRIC_TYPES:
        raise HTTPException(status_code=404, detail=f"Unknown metric type: {metric_type}")
    url = (
        f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/metrics/{metric_type}?days={days}"
    )
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── K8s Pod Logs ─────────────────────────────────────


@router.get("/k8s/pods/{namespace}/{pod_name}/logs")
async def get_k8s_pod_logs(
    namespace: str,
    pod_name: str,
    container: str | None = None,
    tail_lines: int = 200,
    since_seconds: int = 3600,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """K8s 파드 로그 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/k8s/pods/{namespace}/{pod_name}/logs"
    params = {"tail_lines": tail_lines, "since_seconds": since_seconds}
    if container:
        params["container"] = container
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/k8s/nodes/{node_name}/logs")
async def get_k8s_node_logs(
    node_name: str,
    log_path: str = "messages",
    tail_lines: int = 200,
    since_seconds: int = 3600,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """K8s 노드 로그 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/k8s/nodes/{node_name}/logs"
    params = {"log_path": log_path, "tail_lines": tail_lines, "since_seconds": since_seconds}
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── Browsing Proxies ─────────────────────────────────


@router.get("/minio/{bucket_name}/prefixes")
async def get_minio_prefixes(
    bucket_name: str,
    prefix: str = Query("", description="Parent prefix path"),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """MinIO 버킷 prefix 목록 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/minio/{bucket_name}/prefixes"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params={"prefix": prefix},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/nfs/directories")
async def get_nfs_directories(
    mount: str = Query(..., description="NFS mount path"),
    path: str = Query("", description="Sub-directory path"),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """NFS 디렉토리 목록 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/nfs/directories"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params={"mount": mount, "path": path},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── Spark Jobs / Logs ──────────────────────────────


@router.get("/spark/jobs")
async def get_spark_jobs(
    cluster: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Spark Job 목록 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/spark/jobs"
    params = {}
    if cluster:
        params["cluster"] = cluster
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/spark/jobs/{app_id}/logs")
async def get_spark_job_logs(
    app_id: str,
    level: str | None = None,
    limit: int = 100,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Spark Job 로그 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/spark/jobs/{app_id}/logs"
    params = {"limit": limit}
    if level:
        params["level"] = level
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/spark/nodes/{node_id}/logs")
async def get_spark_node_logs(
    node_id: str,
    level: str | None = None,
    limit: int = 100,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Spark 노드 로그 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/infra/spark/nodes/{node_id}/logs"
    params = {"limit": limit}
    if level:
        params["level"] = level
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/service-report")
async def export_service_report(
    days: int = 31,
    category: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP 서비스 현황 HTML 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/export/service-report?days={days}"
    if category:
        url += f"&category={category}"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


@router.get("/export/infra-report")
async def export_infra_report(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP K8s 인프라 현황 HTML 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/export/infra-report"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


# ── PDF Export ──────────────────────────────────────


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = 31,
    category: str | None = None,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP 서비스 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/export/service-report-pdf?days={days}"
    if category:
        url += f"&category={category}"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """HDSP K8s 인프라 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/hdsp_dashboard/export/infra-report-pdf"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
