"""Metric Status API router - JSON endpoint for CloudWatch metric dashboard data."""

from fastapi import APIRouter, Depends

from src.portal.dependencies import get_metric_status_service, require_jwt_auth
from src.portal.services.metric_status_service import MetricStatusService

router = APIRouter(prefix="/metrics/status", tags=["metric-status"])


@router.get("/data")
async def get_dashboard_data(
    user: dict = Depends(require_jwt_auth),
    svc: MetricStatusService = Depends(get_metric_status_service),
):
    return svc.get_dashboard_data()
