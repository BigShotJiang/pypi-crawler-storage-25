"""Settings API router - JSON endpoints for portal settings management."""

from typing import Optional

from fastapi import APIRouter, Depends

from pydantic import BaseModel

from src.portal.dependencies import get_settings_service, require_jwt_auth
from src.portal.services.settings_service import SettingsService

router = APIRouter(prefix="/settings", tags=["settings"])


# ── Request models ───────────────────────────────────


class SettingUpdateRequest(BaseModel):
    key: str
    value: str
    domain: str = "main"
    description: Optional[str] = None


# ── Endpoints ────────────────────────────────────────


@router.get("")
async def get_settings(
    domain: str = "main",
    user: dict = Depends(require_jwt_auth),
    settings_service: SettingsService = Depends(get_settings_service),
):
    settings = settings_service.get_by_domain(domain)
    return {"settings": settings, "domain": domain}


@router.put("")
async def update_setting(
    body: SettingUpdateRequest,
    user: dict = Depends(require_jwt_auth),
    settings_service: SettingsService = Depends(get_settings_service),
):
    settings_service.update_setting(body.key, body.value)
    return {"ok": True}


@router.delete("/{key}")
async def delete_override(
    key: str,
    user: dict = Depends(require_jwt_auth),
    settings_service: SettingsService = Depends(get_settings_service),
):
    settings_service.delete_override(key)
    return {"ok": True}
