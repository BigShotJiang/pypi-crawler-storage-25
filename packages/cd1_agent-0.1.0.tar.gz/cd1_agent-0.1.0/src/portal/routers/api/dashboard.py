"""Dashboard API router - summary data for the portal dashboard."""

from fastapi import APIRouter, Depends

from src.portal.dependencies import get_hitl_service, require_jwt_auth
from src.portal.services.hitl_service import HITLService

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
async def get_summary(
    user: dict = Depends(require_jwt_auth),
    hitl_service: HITLService = Depends(get_hitl_service),
):
    counts = hitl_service.get_pending_counts_by_agent()
    return {"pending_counts": counts, "total_pending": sum(counts.values())}
