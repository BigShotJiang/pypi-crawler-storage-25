"""Alert Config API router - 이상 탐지 알림 설정 CRUD."""

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from src.portal.dependencies import get_alert_config_service, require_jwt_auth
from src.portal.services.alert_config_service import AlertConfigService

router = APIRouter(prefix="/alert-config", tags=["alert-config"])


class AlertConfigRequest(BaseModel):
    service_type: str
    metric_name: str
    sensitivity: float = Field(default=0.7, ge=0.1, le=1.0)
    threshold_upper: float | None = None
    threshold_lower: float | None = None
    enabled: bool = True
    description: str | None = None


@router.get("/configs")
async def list_configs(
    service_type: str | None = Query(None),
    user: dict = Depends(require_jwt_auth),
    svc: AlertConfigService = Depends(get_alert_config_service),
):
    """알림 설정 목록 조회."""
    return svc.list_configs(service_type)


@router.get("/configs/{config_id}")
async def get_config(
    config_id: int,
    user: dict = Depends(require_jwt_auth),
    svc: AlertConfigService = Depends(get_alert_config_service),
):
    """알림 설정 상세 조회."""
    config = svc.get_config(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Config not found")
    return config


@router.post("/configs")
async def upsert_config(
    req: AlertConfigRequest,
    user: dict = Depends(require_jwt_auth),
    svc: AlertConfigService = Depends(get_alert_config_service),
):
    """알림 설정 생성/업데이트 (upsert)."""
    return svc.upsert_config(
        service_type=req.service_type,
        metric_name=req.metric_name,
        sensitivity=req.sensitivity,
        threshold_upper=req.threshold_upper,
        threshold_lower=req.threshold_lower,
        enabled=req.enabled,
        description=req.description,
        updated_by=user.get("name", ""),
    )


@router.put("/configs/{config_id}")
async def update_config(
    config_id: int,
    req: AlertConfigRequest,
    user: dict = Depends(require_jwt_auth),
    svc: AlertConfigService = Depends(get_alert_config_service),
):
    """알림 설정 수정."""
    existing = svc.get_config(config_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Config not found")
    return svc.upsert_config(
        service_type=req.service_type,
        metric_name=req.metric_name,
        sensitivity=req.sensitivity,
        threshold_upper=req.threshold_upper,
        threshold_lower=req.threshold_lower,
        enabled=req.enabled,
        description=req.description,
        updated_by=user.get("name", ""),
    )


@router.delete("/configs/{config_id}")
async def delete_config(
    config_id: int,
    user: dict = Depends(require_jwt_auth),
    svc: AlertConfigService = Depends(get_alert_config_service),
):
    """알림 설정 삭제."""
    deleted = svc.delete_config(config_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Config not found")
    return {"deleted": True, "id": config_id}
