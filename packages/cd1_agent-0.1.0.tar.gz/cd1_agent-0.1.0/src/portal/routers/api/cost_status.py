"""Cost Status API router - proxy to agent server for cost status dashboard data."""

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, require_jwt_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/cost/status", tags=["cost-status"])


@router.get("/data")
async def get_dashboard_data(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/cost-status/data"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/monthly")
async def get_monthly_cost_data(
    year: int = Query(default=None),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    params = f"?year={year}" if year is not None else ""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/cost-status/monthly{params}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/daily")
async def get_daily_cost_data(
    year: int = Query(default=None),
    month: int = Query(default=None),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    params = []
    if year is not None:
        params.append(f"year={year}")
    if month is not None:
        params.append(f"month={month}")
    qs = f"?{'&'.join(params)}" if params else ""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/cost-status/daily{qs}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
