"""Infra API router - proxy to agent server."""

import logging

import httpx
from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, Response

from src.portal.config import PortalSettings
from src.portal.dependencies import get_settings, get_settings_service, require_jwt_auth
from src.portal.services.settings_service import SettingsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/infra", tags=["infra"])


@router.get("/universe-pipeline")
async def get_universe_pipeline(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Universe 입수/전송 파이프라인 현황 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/universe/pipeline"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/data")
async def get_dashboard_data(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/eks/{cluster_name}/detail")
async def get_eks_detail(
    cluster_name: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """EKS 클러스터 상세 조회 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/eks/{cluster_name}/detail"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/eks/{cluster_name}/pods/{namespace}/{pod_name}/logs")
async def get_eks_pod_logs(
    cluster_name: str,
    namespace: str,
    pod_name: str,
    tail_lines: int = 200,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """EKS Pod 로그 조회 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/eks/{cluster_name}/pods/{namespace}/{pod_name}/logs"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                url,
                params={"tail_lines": tail_lines},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/rds/{instance_name}/tables")
async def get_rds_tables(
    instance_name: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/rds/{instance_name}/tables"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/rds/{instance_name}/tables/{table_name}/schema")
async def get_rds_table_schema(
    instance_name: str,
    table_name: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/rds/{instance_name}/tables/{table_name}/schema"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/s3/{bucket_name}/prefixes")
async def get_s3_prefixes(
    bucket_name: str,
    prefix: str = Query("", description="Parent prefix path"),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/s3/{bucket_name}/prefixes"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params={"prefix": prefix},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/glue/{catalog_name}/databases/{database_name}/tables")
async def get_glue_tables(
    catalog_name: str,
    database_name: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/glue/{catalog_name}/databases/{database_name}/tables"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/glue/{catalog_name}/databases/{database_name}/tables/{table_name}/schema")
async def get_glue_table_schema(
    catalog_name: str,
    database_name: str,
    table_name: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/glue/{catalog_name}/databases/{database_name}/tables/{table_name}/schema"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/logs")
async def get_infra_logs(
    request: Request,
    service: str,
    resource_name: str,
    hours: int = 1,
    filter_pattern: str | None = None,
    log_type: str | None = None,
    limit: int = 200,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
    settings_service: SettingsService = Depends(get_settings_service),
):
    """CloudWatch 로그 조회 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/logs"
    params: dict[str, str | int] = {
        "service": service,
        "resource_name": resource_name,
        "hours": hours,
        "limit": limit,
    }
    if filter_pattern:
        params["filter_pattern"] = filter_pattern
    if log_type:
        params["log_type"] = log_type

    # 커스텀 로그 그룹 패턴 조회 (SageMaker 등 설정 가능 서비스)
    custom_key = f"infra_log_group_{service.replace(' ', '_')}"
    custom_pattern = settings_service.get_override(custom_key)
    if custom_pattern:
        params["log_group"] = custom_pattern.format(resource_name=resource_name)
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


METRIC_TYPES = {
    "msk-lag",
    "msk-broker-health",
    "s3-size",
    "sagemaker-users",
    "sagemaker-endpoint-errors",
    "sagemaker-pipeline-failures",
    "sagemaker-notebook-instance-types",
    "sagemaker-pipeline-instance-types",
    "emr-cluster-failures",
    "emr-serverless-failures",
    "sagemaker-endpoint-latency",
    "sagemaker-endpoint-availability",
    "sagemaker-endpoint-invocations",
    "dag-sla-status",
    "dag-interface-rates",
    "mwaa-node-counts",
    "mwaa-env-updates",
    "mwaa-dag-import-errors",
    "mwaa-scheduler-resources",
    "mwaa-dagprocessor-parsing",
    "mwaa-worker-resources",
    "mwaa-worker-task-execution",
    "mwaa-triggerer-resources",
    "mwaa-webserver-resources",
    "mwaa-database-resources",
    "mwaa-database-health",
    "mwaa-storage-dag-bucket",
    "mwaa-environment-overview",
    "rds-connections",
    "rds-cpu",
    "rds-memory",
    "rds-iops",
    "rds-storage-free",
    "lambda-errors",
    "ingestion-rates",
    "glue-table-versions",
    "athena-top-queries",
}


@router.get("/metrics/info")
async def get_infra_metrics_info(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """인프라 메트릭 mock/real 여부 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/metrics/info"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/metrics/athena-query-history")
async def get_athena_query_history(
    request: Request,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Athena 쿼리 이력 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/metrics/athena-query-history"
    params = dict(request.query_params)
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params=params,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/metrics/{metric_type}")
async def get_infra_metrics(
    request: Request,
    metric_type: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """인프라 시계열 메트릭 프록시."""
    if metric_type not in METRIC_TYPES:
        raise HTTPException(status_code=404, detail=f"Unknown metric type: {metric_type}")
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/metrics/{metric_type}"
    params = dict(request.query_params)
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url, params=params, headers={"X-API-Key": settings.agent_server_api_key}
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/lambda/{function_name}/invocations")
async def get_lambda_invocations(
    function_name: str,
    hours: int = Query(1, ge=1, le=24),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """Lambda 함수 호출 이력 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/lambda/{function_name}/invocations"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url,
                params={"hours": hours},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/kpi-data")
async def get_kpi_data(
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """KPI 섹션 데이터 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/infra/kpi-data"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/service-report")
async def export_service_report(
    days: int = 31,
    category: str | None = None,
    include_tables: bool = False,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """서비스 현황 HTML 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/service-report?days={days}"
    if category:
        url += f"&category={category}"
    if include_tables:
        url += "&include_tables=true"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/export/infra-report")
async def export_infra_report(
    include_tables: bool = False,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """인프라 현황 HTML 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/infra-report"
    if include_tables:
        url += "?include_tables=true"
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return HTMLResponse(
                content=resp.text,
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── PDF Export ──────────────────────────────────────


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = 31,
    category: str | None = None,
    include_tables: bool = False,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """서비스 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/service-report-pdf?days={days}"
    if category:
        url += f"&category={category}"
    if include_tables:
        url += "&include_tables=true"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf(
    include_tables: bool = False,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """인프라 현황 PDF 리포트 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/infra-report-pdf"
    if include_tables:
        url += "?include_tables=true"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            from fastapi.responses import Response

            return Response(
                content=resp.content,
                media_type="application/pdf",
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── Test Email ──────────────────────────────────────


@router.post("/test-email")
async def send_test_email(
    payload: dict = Body(...),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """테스트 메일 발송 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/test-email"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                url,
                json=payload,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── Async Export (폴링 패턴) ──────────────────────────


@router.post("/export/start")
async def start_export(
    payload: dict = Body(...),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """비동기 export 시작 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/start"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                url,
                json=payload,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/export/status/{job_id}")
async def export_status(
    job_id: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """export 상태 조회 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/status/{job_id}"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/export/download/{job_id}")
async def export_download(
    job_id: str,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """완료된 export 파일 다운로드 프록시 (스트리밍)."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/export/download/{job_id}"
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.get(
                url,
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return Response(
                content=resp.content,
                media_type=resp.headers.get("content-type", "application/octet-stream"),
                headers={
                    k: v for k, v in resp.headers.items() if k.lower() == "content-disposition"
                },
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


# ── Detection Proxy ──────────────────────────────────


@router.get("/detection/summary")
async def get_detection_summary(
    days: int = Query(31, ge=1, le=365),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """이상 탐지 요약 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/detection/summary?days={days}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/detection/anomalies")
async def list_detection_anomalies(
    severity: str | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    days: int = Query(31, ge=1, le=365),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """탐지된 이상 목록 프록시."""
    params: dict = {"limit": limit, "offset": offset, "days": days}
    if severity:
        params["severity"] = severity
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/detection/anomalies"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                url, params=params, headers={"X-API-Key": settings.agent_server_api_key}
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)


@router.get("/detection/anomalies/{index}/analysis")
async def get_anomaly_analysis(
    index: int,
    days: int = Query(31, ge=1, le=365),
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """특정 이상에 대한 심층 분석 프록시."""
    url = f"{settings.agent_server_url}/agents/bdp_dashboard/detection/anomalies/{index}/analysis?days={days}"
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.get(url, headers={"X-API-Key": settings.agent_server_api_key})
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
