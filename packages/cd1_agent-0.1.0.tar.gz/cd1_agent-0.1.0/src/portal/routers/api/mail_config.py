"""Mail config API router."""

import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from src.portal.config import PortalSettings
from src.portal.dependencies import (
    get_mail_config_service,
    get_settings,
    require_jwt_auth,
)
from src.portal.services.mail_config_service import (
    VALID_REPORT_TYPES,
    MailConfigService,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/mail-config", tags=["mail-config"])


class MailConfigUpsertRequest(BaseModel):
    report_type: str
    enabled: bool = False
    recipients_to: list[str] = []
    recipients_cc: list[str] = []
    schedule_type: str = "daily"


class TestMailRequest(BaseModel):
    report_type: str
    to: list[str]
    cc: list[str] = []


@router.get("")
async def get_all_mail_configs(
    user: dict = Depends(require_jwt_auth),
    service: MailConfigService = Depends(get_mail_config_service),
):
    """전체 메일 설정 목록 (6종 모두)."""
    return {"configs": service.get_all()}


@router.get("/{report_type}")
async def get_mail_config(
    report_type: str,
    user: dict = Depends(require_jwt_auth),
    service: MailConfigService = Depends(get_mail_config_service),
):
    """특정 리포트 메일 설정."""
    if report_type not in VALID_REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid report_type: {report_type}")
    return service.get(report_type)


@router.put("")
async def upsert_mail_config(
    req: MailConfigUpsertRequest,
    user: dict = Depends(require_jwt_auth),
    service: MailConfigService = Depends(get_mail_config_service),
):
    """메일 설정 생성/수정."""
    try:
        config = service.upsert(
            report_type=req.report_type,
            enabled=req.enabled,
            recipients_to=req.recipients_to,
            recipients_cc=req.recipients_cc,
            schedule_type=req.schedule_type,
            updated_by=user.get("name"),
        )
        return config
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{report_type}")
async def delete_mail_config(
    report_type: str,
    user: dict = Depends(require_jwt_auth),
    service: MailConfigService = Depends(get_mail_config_service),
):
    """메일 설정 삭제 (기본값으로 초기화)."""
    if report_type not in VALID_REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid report_type: {report_type}")
    deleted = service.delete(report_type)
    return {"deleted": deleted}


@router.post("/test")
async def send_test_mail(
    req: TestMailRequest,
    user: dict = Depends(require_jwt_auth),
    settings: PortalSettings = Depends(get_settings),
):
    """테스트 메일 발송 프록시 — Agent Server에 위임."""
    if req.report_type not in VALID_REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid report_type: {req.report_type}")
    if not req.to:
        raise HTTPException(status_code=400, detail="recipients 'to' is required")

    url = f"{settings.agent_server_url}/agents/bdp_dashboard/test-report-email"
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:
            resp = await client.post(
                url,
                json={"report_type": req.report_type, "to": req.to, "cc": req.cc},
                headers={"X-API-Key": settings.agent_server_api_key},
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Agent server timeout (PNG 생성 중)")
    except httpx.ConnectError:
        raise HTTPException(status_code=502, detail="Agent server unavailable")
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
