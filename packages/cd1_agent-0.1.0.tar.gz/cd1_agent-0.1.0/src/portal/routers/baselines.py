"""Baseline management router."""

import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Form, Query, Request
from fastapi.responses import RedirectResponse

from src.portal.dependencies import get_baseline_service, require_auth

# ResourceType enum for filtering - graceful fallback if bdp_drift not installed
try:
    from src.agent_server.bdp_drift.bdp_drift.services.models import ResourceType

    RESOURCE_TYPES = [rt.value for rt in ResourceType]
except ImportError:
    RESOURCE_TYPES = [
        "glue", "athena", "emr", "sagemaker", "s3", "mwaa", "msk", "lambda",
        "vpc-sg", "eks", "sagemaker-pipeline", "sagemaker-endpoint", "sagemaker-model",
    ]

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/cost/config", tags=["cost-config"])


@router.get("")
async def baseline_list(
    request: Request,
    resource_type: Optional[str] = Query(None),
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baselines = baseline_service.list_baselines(resource_type=resource_type)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/list.html",
        {
            "request": request,
            "user": user,
            "baselines": baselines,
            "resource_types": RESOURCE_TYPES,
            "filter_resource_type": resource_type or "",
            "active_page": "cost-config",
        },
    )


@router.get("/create")
async def baseline_create_form(
    request: Request,
    user: dict = Depends(require_auth),
):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/form.html",
        {
            "request": request,
            "user": user,
            "resource_types": RESOURCE_TYPES,
            "baseline": None,
            "is_edit": False,
            "active_page": "cost-config",
        },
    )


@router.post("/create")
async def baseline_create(
    request: Request,
    resource_type: str = Form(...),
    resource_id: str = Form(...),
    config: str = Form(...),
    resource_arn: str = Form(""),
    description: str = Form(""),
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    try:
        config_dict = json.loads(config)
    except json.JSONDecodeError:
        return RedirectResponse(url="/cost/config/create?error=invalid_json", status_code=302)

    baseline_service.create_baseline(
        resource_type=resource_type,
        resource_id=resource_id,
        config=config_dict,
        created_by=user.get("name", "admin"),
        resource_arn=resource_arn or None,
        description=description or None,
    )
    return RedirectResponse(url="/cost/config", status_code=302)


@router.get("/{resource_type}/{resource_id}")
async def baseline_detail(
    request: Request,
    resource_type: str,
    resource_id: str,
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baseline = baseline_service.get_baseline(resource_type, resource_id)

    if baseline is None:
        return RedirectResponse(url="/cost/config", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/detail.html",
        {
            "request": request,
            "user": user,
            "baseline": baseline,
            "config_json": json.dumps(baseline.config, indent=2, ensure_ascii=False),
            "active_page": "cost-config",
        },
    )


@router.get("/{resource_type}/{resource_id}/edit")
async def baseline_edit_form(
    request: Request,
    resource_type: str,
    resource_id: str,
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baseline = baseline_service.get_baseline(resource_type, resource_id)

    if baseline is None:
        return RedirectResponse(url="/cost/config", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/form.html",
        {
            "request": request,
            "user": user,
            "resource_types": RESOURCE_TYPES,
            "baseline": baseline,
            "config_json": json.dumps(baseline.config, indent=2, ensure_ascii=False),
            "is_edit": True,
            "active_page": "cost-config",
        },
    )


@router.post("/{resource_type}/{resource_id}/edit")
async def baseline_update(
    request: Request,
    resource_type: str,
    resource_id: str,
    config: str = Form(...),
    reason: str = Form(""),
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    try:
        config_dict = json.loads(config)
    except json.JSONDecodeError:
        return RedirectResponse(
            url=f"/cost/config/{resource_type}/{resource_id}/edit?error=invalid_json",
            status_code=302,
        )

    baseline_service.update_baseline(
        resource_type=resource_type,
        resource_id=resource_id,
        config=config_dict,
        updated_by=user.get("name", "admin"),
        reason=reason or None,
    )
    return RedirectResponse(url=f"/cost/config/{resource_type}/{resource_id}", status_code=302)


@router.post("/{resource_type}/{resource_id}/delete")
async def baseline_delete(
    request: Request,
    resource_type: str,
    resource_id: str,
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baseline_service.delete_baseline(resource_type, resource_id)
    return RedirectResponse(url="/cost/config", status_code=302)


@router.get("/{resource_type}/{resource_id}/history")
async def baseline_history(
    request: Request,
    resource_type: str,
    resource_id: str,
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baseline = baseline_service.get_baseline(resource_type, resource_id)
    history = baseline_service.get_version_history(resource_type, resource_id)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/history.html",
        {
            "request": request,
            "user": user,
            "baseline": baseline,
            "history": history,
            "active_page": "cost-config",
        },
    )


@router.get("/{resource_type}/{resource_id}/compare")
async def baseline_compare(
    request: Request,
    resource_type: str,
    resource_id: str,
    version_a: int = Query(...),
    version_b: int = Query(...),
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    diff = baseline_service.compare_versions(resource_type, resource_id, version_a, version_b)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "cost_config/detail.html",
        {
            "request": request,
            "user": user,
            "baseline": baseline_service.get_baseline(resource_type, resource_id),
            "config_json": json.dumps(diff, indent=2, ensure_ascii=False),
            "comparing": True,
            "version_a": version_a,
            "version_b": version_b,
            "active_page": "cost-config",
        },
    )


@router.post("/{resource_type}/{resource_id}/rollback/{version}")
async def baseline_rollback(
    request: Request,
    resource_type: str,
    resource_id: str,
    version: int,
    user: dict = Depends(require_auth),
):
    baseline_service = get_baseline_service(request)
    baseline_service.rollback_to_version(
        resource_type=resource_type,
        resource_id=resource_id,
        version=version,
        rolled_back_by=user.get("name", "admin"),
    )
    return RedirectResponse(
        url=f"/cost/config/{resource_type}/{resource_id}", status_code=302
    )
