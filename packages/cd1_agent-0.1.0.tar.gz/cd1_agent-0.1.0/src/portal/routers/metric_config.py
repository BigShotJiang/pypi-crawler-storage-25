"""Metric Config CRUD router."""

import logging

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse
from pydantic import BaseModel

from src.portal.dependencies import require_auth
from src.portal.services.metric_config_service import ValidationError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/metrics/config", tags=["metric-config"])


def _get_service(request: Request):
    return request.app.state.metric_config_service


def _get_catalog(request: Request):
    return request.app.state.metric_catalog_service


def _merged_service_types(request: Request) -> list[str]:
    db_types = set(_get_service(request).get_service_types())
    catalog_types = set(_get_catalog(request).get_service_types())
    return sorted(db_types | catalog_types)


@router.get("/api/suggestions")
async def suggestions_api(
    request: Request,
    service_type: str = "",
    user: dict = Depends(require_auth),
):
    catalog = _get_catalog(request)
    items = catalog.get_suggestions(service_type) if service_type else []
    return JSONResponse(content=items)


class ConfigUpdateBody(BaseModel):
    service_type: str
    metric_name: str
    enabled: int = 1
    description: str = ""


@router.put("/api/{config_id}")
async def update_config_api(
    request: Request,
    config_id: int,
    body: ConfigUpdateBody,
    user: dict = Depends(require_auth),
):
    """JSON API for inline editing — returns updated config or 422 on validation error."""
    svc = _get_service(request)
    existing = svc.get_config(config_id)
    if not existing:
        return JSONResponse(status_code=404, content={"detail": "Config not found"})
    try:
        svc.update_config(
            config_id,
            service_type=body.service_type,
            metric_name=body.metric_name,
            enabled=body.enabled,
            description=body.description or None,
            updated_by=user.get("name", "admin"),
        )
    except ValidationError as e:
        return JSONResponse(status_code=422, content={"errors": e.errors})
    updated = svc.get_config(config_id)
    return JSONResponse(content=dict(updated))


@router.get("")
async def list_configs(
    request: Request,
    service_type: str = "",
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    configs = svc.list_configs(service_type=service_type or None)
    service_types = svc.get_service_types()
    all_service_types = _merged_service_types(request)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metric_config/list.html",
        {
            "request": request,
            "user": user,
            "configs": configs,
            "service_types": service_types,
            "all_service_types": all_service_types,
            "filter_service_type": service_type,
            "active_page": "metrics-config",
        },
    )


@router.get("/create")
async def create_form(
    request: Request,
    user: dict = Depends(require_auth),
):
    service_types = _merged_service_types(request)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metric_config/form.html",
        {
            "request": request,
            "user": user,
            "config": None,
            "service_types": service_types,
            "active_page": "metrics-config",
        },
    )


@router.post("/create")
async def create_config(
    request: Request,
    service_type: str = Form(...),
    metric_name: str = Form(...),
    enabled: int = Form(0),
    description: str = Form(""),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    try:
        svc.create_config(
            service_type=service_type,
            metric_name=metric_name,
            enabled=enabled,
            description=description or None,
            updated_by=user.get("name", "admin"),
        )
    except Exception as e:
        logger.error(f"Failed to create metric config: {e}")
    return RedirectResponse(url="/metrics/config", status_code=302)


@router.get("/{config_id}/edit")
async def edit_form(
    request: Request,
    config_id: int,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    config = svc.get_config(config_id)
    if not config:
        return RedirectResponse(url="/metrics/config", status_code=302)
    service_types = _merged_service_types(request)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metric_config/form.html",
        {
            "request": request,
            "user": user,
            "config": config,
            "service_types": service_types,
            "active_page": "metrics-config",
        },
    )


@router.post("/{config_id}/edit")
async def update_config(
    request: Request,
    config_id: int,
    service_type: str = Form(...),
    metric_name: str = Form(...),
    enabled: int = Form(0),
    description: str = Form(""),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    svc.update_config(
        config_id,
        service_type=service_type,
        metric_name=metric_name,
        enabled=enabled,
        description=description or None,
        updated_by=user.get("name", "admin"),
    )
    return RedirectResponse(url="/metrics/config", status_code=302)


@router.post("/{config_id}/delete")
async def delete_config(
    request: Request,
    config_id: int,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    svc.delete_config(config_id)
    return RedirectResponse(url="/metrics/config", status_code=302)


@router.post("/import-csv")
async def import_csv(
    request: Request,
    csv_content: str = Form(...),
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    result = svc.import_csv(csv_content, updated_by=user.get("name", "admin"))
    logger.info(f"CSV import result: {result}")
    # Redirect with result info
    configs = svc.list_configs()
    service_types = svc.get_service_types()
    all_service_types = _merged_service_types(request)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metric_config/list.html",
        {
            "request": request,
            "user": user,
            "configs": configs,
            "service_types": service_types,
            "all_service_types": all_service_types,
            "filter_service_type": "",
            "import_result": result,
            "active_page": "metrics-config",
        },
    )


@router.get("/export-csv")
async def export_csv(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    csv_content = svc.export_csv()
    return StreamingResponse(
        iter([csv_content]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=bdp_metric_configs.csv"},
    )
