"""Drift status dashboard router."""

import logging

from fastapi import APIRouter, Depends, Request

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/drift/status", tags=["drift-status"])


@router.get("")
async def drift_status_dashboard(
    request: Request,
    user: dict = Depends(require_auth),
):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "drift_status/dashboard.html",
        {
            "request": request,
            "user": user,
            "active_page": "drift-status",
        },
    )
