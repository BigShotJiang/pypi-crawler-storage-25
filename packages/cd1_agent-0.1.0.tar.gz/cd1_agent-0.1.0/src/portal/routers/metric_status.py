"""Metric Status dashboard router."""

import logging
from datetime import datetime

from src.common.timezone import KST

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/metrics/status", tags=["metric-status"])


def _get_service(request: Request):
    return request.app.state.metric_status_service


@router.get("")
async def dashboard(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    dashboard_data = svc.get_dashboard_data()

    # Compute summary
    total = 0
    ok = 0
    warning = 0
    critical = 0
    for metrics in dashboard_data.values():
        for m in metrics:
            total += 1
            if m["status"] == "ok":
                ok += 1
            elif m["status"] == "warning":
                warning += 1
            elif m["status"] == "critical":
                critical += 1

    summary = {"total": total, "ok": ok, "warning": warning, "critical": critical}

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "metric_status/dashboard.html",
        {
            "request": request,
            "user": user,
            "dashboard_data": dashboard_data,
            "summary": summary,
            "now": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
            "active_page": "metrics-status",
        },
    )


@router.get("/api/data")
async def api_data(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    dashboard_data = svc.get_dashboard_data()
    return JSONResponse(content=dashboard_data)
