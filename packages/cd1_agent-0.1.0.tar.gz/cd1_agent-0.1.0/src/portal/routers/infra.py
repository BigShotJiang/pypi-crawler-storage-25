"""Infra dashboard router - AWS 인프라 리소스 현황."""

import logging
from datetime import datetime

from src.common.timezone import KST

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/infra", tags=["infra"])


def _get_service(request: Request):
    return request.app.state.infra_service


@router.get("")
async def dashboard(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    data = svc.get_dashboard_data()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "infra/dashboard.html",
        {
            "request": request,
            "user": user,
            "summary": data["summary"],
            "services": data["services"],
            "errors": data.get("errors", []),
            "fetched_at": data.get("fetched_at", ""),
            "now": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
            "active_page": "infra",
        },
    )


@router.get("/api/data")
async def api_data(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    data = svc.get_dashboard_data()
    return JSONResponse(content=data)
