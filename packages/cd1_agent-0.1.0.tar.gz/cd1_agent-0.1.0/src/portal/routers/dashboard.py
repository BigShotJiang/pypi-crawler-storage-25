"""Dashboard router."""

import logging

from fastapi import APIRouter, Depends, Request

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(tags=["dashboard"])


@router.get("/")
async def dashboard(request: Request, user: dict = Depends(require_auth)):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "user": user,
            "active_page": "dashboard",
        },
    )
