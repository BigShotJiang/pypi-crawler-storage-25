"""Airflow Detection Config router - settings-style management of detection parameters."""

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/airflow/config", tags=["airflow-config"])


def _get_service(request: Request):
    return request.app.state.airflow_config_service


# ── Static routes FIRST (before {section_key} catch-all) ──────────────

@router.get("")
async def config_page(
    request: Request,
    user: dict = Depends(require_auth),
):
    svc = _get_service(request)
    sections = svc.get_all_sections_with_meta()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "airflow_config/list.html",
        {
            "request": request,
            "user": user,
            "sections": sections,
            "active_page": "airflow-config",
        },
    )


@router.get("/export-json")
async def export_json(
    request: Request,
    user: dict = Depends(require_auth),
):
    """Export full merged config as JSON file."""
    svc = _get_service(request)
    content = svc.export_json()
    return StreamingResponse(
        iter([content]),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=detection_config.json"},
    )


@router.post("/reset-all")
async def reset_all(
    request: Request,
    user: dict = Depends(require_auth),
):
    """Reset all sections to defaults."""
    svc = _get_service(request)
    svc.reset_all()
    return RedirectResponse(url="/airflow/config", status_code=302)


# ── Parameterized routes ──────────────────────────────────────────────

@router.put("/api/{section_key}")
async def save_section_api(
    request: Request,
    section_key: str,
    user: dict = Depends(require_auth),
):
    """JSON API for saving a section."""
    svc = _get_service(request)
    body = await request.json()
    try:
        svc.save_section(section_key, body, updated_by=user.get("name", "admin"))
        meta = svc.get_section_with_meta(section_key)
        return JSONResponse(content={"status": "ok", "section": meta})
    except Exception as e:
        return JSONResponse(status_code=422, content={"detail": str(e)})


@router.post("/{section_key}/reset")
async def reset_section(
    request: Request,
    section_key: str,
    user: dict = Depends(require_auth),
):
    """Reset a section to its default values."""
    svc = _get_service(request)
    svc.reset_section(section_key)
    return RedirectResponse(url=f"/airflow/config#section-{section_key}", status_code=302)


@router.post("/{section_key}")
async def save_section(
    request: Request,
    section_key: str,
    user: dict = Depends(require_auth),
):
    """Save a section's configuration from form data."""
    svc = _get_service(request)
    form = await request.form()
    form_dict = {k: v for k, v in form.items()}
    try:
        parsed = svc.parse_form_to_section(section_key, form_dict)
        svc.save_section(section_key, parsed, updated_by=user.get("name", "admin"))
    except Exception as e:
        logger.error(f"Failed to save section {section_key}: {e}")
    return RedirectResponse(url=f"/airflow/config#section-{section_key}", status_code=302)
