"""Airflow failure report management router."""

import logging

from fastapi import APIRouter, Depends, Request

from src.portal.dependencies import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/airflow", tags=["airflow"])


@router.get("")
async def airflow_list(
    request: Request,
    user: dict = Depends(require_auth),
):
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "airflow/list.html",
        {
            "request": request,
            "user": user,
            "active_page": "airflow",
        },
    )
