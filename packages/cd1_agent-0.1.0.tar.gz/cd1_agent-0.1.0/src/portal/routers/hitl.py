"""HITL management router - 채팅 인터페이스."""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, Form, Query, Request
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel

from src.portal.dependencies import get_hitl_service, require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/hitl", tags=["hitl"])


# ── JSON API request models ──────────────────────────

class SendMessageRequest(BaseModel):
    agent_type: str
    message: str
    request_type: str = "prompt_input"
    payload: Optional[dict] = None


class RespondRequest(BaseModel):
    approved: bool
    comment: str = ""


# ── Page routes ──────────────────────────────────────

@router.get("")
async def hitl_chat(
    request: Request,
    agent_type: Optional[str] = Query(None),
    user: dict = Depends(require_auth),
):
    """채팅 메인 페이지."""
    hitl_service = get_hitl_service(request)
    hitl_service.expire_stale()
    pending_count = hitl_service.get_pending_count()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "hitl/chat.html",
        {
            "request": request,
            "user": user,
            "pending_count": pending_count,
            "initial_agent_type": agent_type or "all",
            "active_page": "hitl",
        },
    )


# ── JSON API routes (must be before /{request_id}) ───

@router.get("/api/messages")
async def api_messages(
    request: Request,
    agent_type: str = Query(...),
    page: int = Query(1, ge=1),
    user: dict = Depends(require_auth),
):
    """선택된 에이전트의 HITL 요청 목록 (시간순, polling용)."""
    hitl_service = get_hitl_service(request)
    hitl_service.expire_stale()

    requests_list, pending_count = hitl_service.list_requests(
        agent_type=agent_type,
        page=page,
        per_page=50,
    )

    messages = []
    for req in requests_list:
        messages.append({
            "id": req.id,
            "title": req.title,
            "description": req.description,
            "status": req.status.value,
            "request_type": req.request_type.value,
            "payload": req.payload,
            "response": req.response,
            "created_by": req.created_by,
            "responded_by": req.responded_by,
            "created_at": req.created_at.isoformat() if req.created_at else None,
            "updated_at": req.updated_at.isoformat() if req.updated_at else None,
            "expires_at": req.expires_at.isoformat() if req.expires_at else None,
        })

    # 시간순 정렬 (오래된 것이 위)
    messages.reverse()

    return JSONResponse({
        "messages": messages,
        "pending_count": pending_count,
    })


@router.post("/api/send")
async def api_send(
    request: Request,
    body: SendMessageRequest,
    user: dict = Depends(require_auth),
):
    """새 HITL 요청 전송 (=메시지 발송)."""
    hitl_service = get_hitl_service(request)
    req = hitl_service.send_request(
        agent_type=body.agent_type,
        message=body.message,
        request_type=body.request_type,
        payload=body.payload,
        user=user.get("name", "admin"),
    )
    return JSONResponse({
        "id": req.id,
        "status": req.status.value,
        "created_at": req.created_at.isoformat() if req.created_at else None,
    })


@router.post("/api/{request_id}/respond")
async def api_respond(
    request: Request,
    request_id: str,
    body: RespondRequest,
    user: dict = Depends(require_auth),
):
    """pending 요청에 승인/거절 응답."""
    hitl_service = get_hitl_service(request)
    username = user.get("name", "admin")

    if body.approved:
        result = hitl_service.approve(request_id, comment=body.comment, user=username)
    else:
        result = hitl_service.reject(request_id, comment=body.comment, user=username)

    if result is None:
        return JSONResponse({"error": "요청을 찾을 수 없습니다."}, status_code=404)

    return JSONResponse({
        "id": result.id,
        "status": result.status.value,
    })


# ── Detail page (after API routes) ───────────────────

@router.get("/{request_id}")
async def hitl_detail(
    request: Request,
    request_id: str,
    user: dict = Depends(require_auth),
):
    """요청 상세 페이지 (기존 유지)."""
    hitl_service = get_hitl_service(request)
    hitl_request = hitl_service.get_request(request_id)

    if hitl_request is None:
        return RedirectResponse(url="/hitl", status_code=302)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "hitl/detail.html",
        {
            "request": request,
            "user": user,
            "hitl_request": hitl_request,
            "active_page": "hitl",
        },
    )


# ── Legacy form routes (detail page 호환) ────────────

@router.post("/{request_id}/approve")
async def hitl_approve(
    request: Request,
    request_id: str,
    comment: str = Form(""),
    user: dict = Depends(require_auth),
):
    hitl_service = get_hitl_service(request)
    hitl_service.approve(request_id, comment=comment, user=user.get("name", "admin"))
    return RedirectResponse(url=f"/hitl/{request_id}", status_code=302)


@router.post("/{request_id}/reject")
async def hitl_reject(
    request: Request,
    request_id: str,
    comment: str = Form(""),
    user: dict = Depends(require_auth),
):
    hitl_service = get_hitl_service(request)
    hitl_service.reject(request_id, comment=comment, user=user.get("name", "admin"))
    return RedirectResponse(url=f"/hitl/{request_id}", status_code=302)


@router.post("/{request_id}/cancel")
async def hitl_cancel(
    request: Request,
    request_id: str,
    user: dict = Depends(require_auth),
):
    hitl_service = get_hitl_service(request)
    hitl_service.cancel(request_id)
    return RedirectResponse(url=f"/hitl/{request_id}", status_code=302)
