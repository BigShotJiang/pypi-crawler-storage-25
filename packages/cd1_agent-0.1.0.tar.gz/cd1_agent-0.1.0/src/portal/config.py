"""Portal Configuration using pydantic-settings."""

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PortalSettings(BaseSettings):
    """Portal server configuration loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Server
    portal_port: int = Field(default=4343, description="Portal server port")
    portal_host: str = Field(default="0.0.0.0", description="Portal server host")
    environment: str = Field(default="test", description="Deployment environment")
    debug: bool = Field(default=False, description="Enable debug mode")
    log_level: str = Field(default="INFO", description="Logging level")

    # DB
    rds_provider: str = Field(default="sqlite", description="DB provider (mock, sqlite, mysql)")
    baseline_secret_id: str = Field(default="", description="AWS Secrets Manager Secret ID for RDS credentials")
    rds_host: Optional[str] = Field(default=None, description="RDS host")
    rds_port: int = Field(default=3306, description="RDS port")
    rds_database: str = Field(default="cd1_agent", description="RDS database name")
    rds_user: Optional[str] = Field(default=None, description="RDS username")
    rds_password: Optional[str] = Field(default=None, description="RDS password")
    sqlite_path: str = Field(default="./data/portal.db", description="SQLite database path")

    # Agent Server
    agent_server_url: str = Field(default="http://localhost:8000", description="Agent server base URL")
    agent_server_api_key: str = Field(
        default="a0e33580e47109dab7a4055bca401319a498ef09a1e8a7c4e1fdba5bb001ed05",
        description="Agent server API key",
    )

    # Keycloak OIDC (default off for dev; production Helm sets AUTH_ENABLED=true)
    auth_enabled: bool = Field(default=False, description="Enable Keycloak authentication")
    keycloak_url: str = Field(default="", description="Keycloak server URL")
    keycloak_realm: str = Field(default="", description="Keycloak realm")
    keycloak_client_id: str = Field(default="", description="Keycloak client ID")
    keycloak_client_secret: str = Field(default="", description="Keycloak client secret")
    keycloak_internal_url: str = Field(
        default="", description="Keycloak internal URL for server-to-server communication (Docker network)"
    )
    session_secret: str = Field(
        default="change-me-in-production", description="Session secret key"
    )


    @property
    def resource_prefix(self) -> str:
        """ENVIRONMENT 기반 BDP 인프라 리소스 접두사."""
        mapping = {"dev": "wdd", "prd": "wdp", "prod": "wdp", "test": "wdd"}
        return mapping.get(self.environment.lower(), "wdd")

    @property
    def is_production(self) -> bool:
        return self.environment.lower() in ("prd", "prod")


_settings: Optional[PortalSettings] = None


def get_portal_settings() -> PortalSettings:
    """Get cached portal settings instance."""
    global _settings
    if _settings is None:
        _settings = PortalSettings()
    return _settings
