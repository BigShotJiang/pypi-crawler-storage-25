"""FastAPI Portal Application Factory."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

from src.common.hitl.store import HITLStore
from src.portal.auth import KeycloakAuth
from src.portal.config import PortalSettings, get_portal_settings
from src.portal.services.airflow_config_service import AirflowConfigService
from src.portal.services.airflow_config_store import AirflowConfigStore
from src.portal.services.airflow_report_service import (
    AirflowReportService,
    create_airflow_report_store,
)
from src.portal.services.baseline_service import BaselineService, create_baseline_store
from src.portal.services.cost_report_service import (
    CostReportService,
    create_cost_report_store,
)
from src.portal.services.cost_report_service import (
    seed_reports_from_files as seed_cost_reports,
)
from src.portal.services.dashboard_report_service import (
    DashboardReportService,
    create_dashboard_report_store,
)
from src.portal.services.db import PortalDB
from src.portal.services.drift_config_service import DriftConfigService
from src.portal.services.drift_config_store import DriftConfigStore
from src.portal.services.drift_report_service import DriftReportService, create_drift_report_store
from src.portal.services.hdsp_dashboard_report_service import (
    HdspDashboardReportService,
    create_hdsp_dashboard_report_store,
)
from src.portal.services.hitl_service import HITLService
from src.portal.services.mail_config_service import MailConfigService
from src.portal.services.holmesgpt_service import HolmesGPTService
from src.portal.services.metric_catalog_service import MetricCatalogService
from src.portal.services.metric_config_service import MetricConfigService, seed_metric_configs
from src.portal.services.metric_config_store import MetricConfigStore
from src.portal.services.metric_status_service import MetricStatusService
from src.portal.services.metrics_report_service import MetricsReportService, create_report_store
from src.portal.services.settings_service import SettingsService

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent.parent

# Portal frontend dist directory: Docker build copies to /app/portal_frontend-dist/,
# local dev builds to portal_frontend/dist/
FRONTEND_DIST = PROJECT_ROOT / "portal_frontend-dist"
if not FRONTEND_DIST.exists():
    FRONTEND_DIST = PROJECT_ROOT / "portal_frontend" / "dist"


def create_portal_app(settings: PortalSettings | None = None) -> FastAPI:
    """Create the FastAPI portal application."""
    settings = settings or get_portal_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Startup
        logger.info("Starting CD1 Agent Portal server...")

        # DB
        db = PortalDB(settings)
        db.ensure_tables()
        app.state.db = db

        # Auth
        auth = KeycloakAuth(settings)
        app.state.auth = auth

        # HITL Store
        hitl_store = HITLStore(
            provider=settings.rds_provider,  # type: ignore
            secret_id=settings.baseline_secret_id or None,
            rds_database=settings.rds_database,
            sqlite_path=settings.sqlite_path,
        )
        hitl_store.ensure_table()

        # Baseline Store (may not be available if bdp_drift not installed)
        db_path = (
            settings.sqlite_path if settings.rds_provider == "sqlite" else settings.rds_database
        )
        secret_id = settings.baseline_secret_id or None
        baseline_store = create_baseline_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # Metrics Report Store (may not be available if bdp_metrics not installed)
        report_store = create_report_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # Drift Report Store (may not be available if bdp_drift not installed)
        drift_report_store = create_drift_report_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # Airflow Report Store (may not be available if bdp_airflow not installed)
        airflow_report_store = create_airflow_report_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # Dashboard Report Store (may not be available if bdp_dashboard not installed)
        dashboard_report_store = create_dashboard_report_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # HDSP Dashboard Report Store (may not be available if hdsp_dashboard not installed)
        hdsp_dashboard_report_store = create_hdsp_dashboard_report_store(
            provider=settings.rds_provider, db=db_path, secret_id=secret_id
        )

        # Services
        app.state.hitl_service = HITLService(hitl_store)
        app.state.baseline_service = BaselineService(baseline_store)
        app.state.metrics_report_service = MetricsReportService(report_store)
        app.state.drift_report_service = DriftReportService(drift_report_store)
        app.state.airflow_report_service = AirflowReportService(airflow_report_store)
        app.state.dashboard_report_service = DashboardReportService(dashboard_report_store)
        app.state.hdsp_dashboard_report_service = HdspDashboardReportService(
            hdsp_dashboard_report_store
        )
        app.state.settings_service = SettingsService(db)

        # HolmesGPT Session Store + Service
        from src.portal.services.holmesgpt_session_store import HolmesGPTSessionStore

        holmesgpt_session_store = HolmesGPTSessionStore(db)
        holmesgpt_session_store.ensure_table()
        app.state.holmesgpt_service = HolmesGPTService(
            app.state.settings_service, holmesgpt_session_store
        )

        # Cost Report Store (DB-based, may not be available if bdp_cost not installed)
        cost_report_store = create_cost_report_store(provider=settings.rds_provider, db=db_path, secret_id=secret_id)
        seed_cost_reports(cost_report_store)
        app.state.cost_report_service = CostReportService(cost_report_store)

        # Metric Config & Status
        metric_config_store = MetricConfigStore(db)
        metric_config_store.ensure_table()
        metric_config_service = MetricConfigService(metric_config_store)
        seed_metric_configs(metric_config_service)
        metric_status_service = MetricStatusService(metric_config_service, settings)
        app.state.metric_config_service = metric_config_service
        app.state.metric_status_service = metric_status_service
        app.state.metric_catalog_service = MetricCatalogService()

        # Drift Config
        drift_config_store = DriftConfigStore(db)
        drift_config_store.ensure_table()
        drift_config_service = DriftConfigService(drift_config_store)
        app.state.drift_config_service = drift_config_service

        # Config Check Item Mapper (lazy import from agent_server)
        try:
            from src.agent_server.bdp_drift.bdp_drift.services.config_mapper import (
                ConfigCheckItemMapper,
            )

            app.state.config_mapper = ConfigCheckItemMapper(use_mock=settings.debug)
        except ImportError:
            logger.warning("ConfigCheckItemMapper not available. 현황 조회 기능이 비활성화됩니다.")
            app.state.config_mapper = None

        # Airflow Config
        airflow_config_store = AirflowConfigStore(db)
        airflow_config_store.ensure_table()
        airflow_config_service = AirflowConfigService(airflow_config_store)
        app.state.airflow_config_service = airflow_config_service

        # Mail Config
        app.state.mail_config_service = MailConfigService(db)

        yield

        # Shutdown
        hitl_store.close()
        db.close()
        logger.info("CD1 Agent Portal server shut down.")

    application = FastAPI(
        title="CD1 Agent Portal",
        description="CD1 Agent Portal Interface",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if settings.debug else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.debug else None,
    )

    # Store settings
    application.state.settings = settings

    # Jinja2 templates (for login/callback pages)
    templates_dir = BASE_DIR / "templates"
    application.state.templates = Jinja2Templates(directory=str(templates_dir))

    # CORS middleware (for SPA dev server)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Proxy headers middleware (Ingress 뒤에서 X-Forwarded-Proto 인식 → https redirect_uri 생성)
    application.add_middleware(ProxyHeadersMiddleware, trusted_hosts=["*"])

    # Session middleware (for auth)
    application.add_middleware(
        SessionMiddleware,
        secret_key=settings.session_secret,
        max_age=8 * 3600,  # 8시간
    )

    # Health endpoint
    @application.get("/health", tags=["health"])
    async def health():
        return {"status": "healthy", "service": "cd1-portal"}

    @application.get("/api/v1/health/agent-server", tags=["health"])
    async def agent_server_health():
        """Agent server 연결 상태 확인."""

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(f"{settings.agent_server_url}/health")
                resp.raise_for_status()
                return {"status": "connected", "agent_server": resp.json()}
        except (httpx.ConnectError, httpx.TimeoutException):
            raise HTTPException(status_code=503, detail="Agent server unavailable")

    # --- API v1 routers (JSON-only, JWT auth) ---
    from src.portal.routers.api.adw import router as api_adw_router
    from src.portal.routers.api.airflow_config import router as api_airflow_config_router
    from src.portal.routers.api.airflow_reports import router as api_airflow_reports_router
    from src.portal.routers.api.airflow_stats import router as api_airflow_stats_router
    from src.portal.routers.api.auth import router as api_auth_router
    from src.portal.routers.api.cost import router as api_cost_router
    from src.portal.routers.api.cost_status import router as api_cost_status_router
    from src.portal.routers.api.dashboard import router as api_dashboard_router
    from src.portal.routers.api.dashboard_reports import router as api_dashboard_reports_router
    from src.portal.routers.api.drift_config import router as api_drift_config_router
    from src.portal.routers.api.drift_reports import router as api_drift_reports_router
    from src.portal.routers.api.hdsp import router as api_hdsp_router
    from src.portal.routers.api.hdsp_dashboard_reports import (
        router as api_hdsp_dashboard_reports_router,
    )
    from src.portal.routers.api.hdsp_metrics_reports import (
        router as api_hdsp_metrics_reports_router,
    )
    from src.portal.routers.api.hitl import router as api_hitl_router
    from src.portal.routers.api.infra import router as api_infra_router
    from src.portal.routers.api.metric_config import router as api_metric_config_router
    from src.portal.routers.api.metric_status import router as api_metric_status_router
    from src.portal.routers.api.metrics import router as api_metrics_router
    from src.portal.routers.api.settings import router as api_settings_router

    api_v1 = APIRouter(prefix="/api/v1")
    api_v1.include_router(api_auth_router)
    api_v1.include_router(api_dashboard_router)
    api_v1.include_router(api_hdsp_router)
    api_v1.include_router(api_adw_router)
    api_v1.include_router(api_hitl_router)
    api_v1.include_router(api_metric_config_router)
    api_v1.include_router(api_metric_status_router)
    api_v1.include_router(api_metrics_router)
    api_v1.include_router(api_cost_status_router)
    api_v1.include_router(api_cost_router)
    api_v1.include_router(api_airflow_config_router)
    api_v1.include_router(api_airflow_stats_router)
    api_v1.include_router(api_airflow_reports_router)
    api_v1.include_router(api_dashboard_reports_router)
    api_v1.include_router(api_hdsp_dashboard_reports_router)
    api_v1.include_router(api_hdsp_metrics_reports_router)
    api_v1.include_router(api_drift_config_router)
    api_v1.include_router(api_drift_reports_router)
    api_v1.include_router(api_infra_router)
    api_v1.include_router(api_settings_router)
    from src.portal.routers.api.holmes_gpt import router as api_holmes_gpt_router
    from src.portal.routers.api.mail_config import router as api_mail_config_router

    api_v1.include_router(api_holmes_gpt_router)
    api_v1.include_router(api_mail_config_router)
    application.include_router(api_v1)

    # --- Auth routes (login/logout/callback, must be before SPA catch-all) ---
    from src.portal.routers.auth_routes import router as auth_router

    application.include_router(auth_router)

    # --- SPA serving (React frontend) ---
    index_html = FRONTEND_DIST / "index.html"
    assets_dir = FRONTEND_DIST / "assets"

    if index_html.exists():
        logger.info("Serving SPA from %s", FRONTEND_DIST)

        # Serve Vite build assets (JS, CSS, images)
        if assets_dir.exists():
            application.mount(
                "/assets",
                StaticFiles(directory=str(assets_dir)),
                name="frontend-assets",
            )

        # SPA catch-all: serve static files from dist root or index.html
        @application.get("/{full_path:path}", include_in_schema=False)
        async def spa_fallback(request: Request, full_path: str):
            # Serve root-level static files (e.g. vite.svg, favicon.ico)
            if full_path:
                static_file = (FRONTEND_DIST / full_path).resolve()
                if static_file.is_relative_to(FRONTEND_DIST) and static_file.is_file():
                    return FileResponse(str(static_file))
            # AUTH_ENABLED=true이고 세션에 user가 없으면 로그인으로 리다이렉트
            if settings.auth_enabled and not request.session.get("user"):
                return RedirectResponse(url="/login", status_code=302)
            return FileResponse(str(index_html))
    else:
        logger.info(
            "Frontend dist not found at %s — SPA serving disabled (use Vite dev server)",
            FRONTEND_DIST,
        )

    return application


# Default app instance for uvicorn
app = create_portal_app()
