"""FastAPI dependencies for Portal."""

import base64
import json
import logging

from fastapi import HTTPException, Request

from src.portal.auth import KeycloakAuth
from src.portal.config import PortalSettings
from src.portal.services.airflow_config_service import AirflowConfigService
from src.portal.services.airflow_report_service import AirflowReportService
from src.portal.services.baseline_service import BaselineService
from src.portal.services.cost_report_service import CostReportService
from src.portal.services.dashboard_report_service import DashboardReportService
from src.portal.services.db import PortalDB
from src.portal.services.drift_config_service import DriftConfigService
from src.portal.services.drift_report_service import DriftReportService
from src.portal.services.hitl_service import HITLService
from src.portal.services.holmesgpt_service import HolmesGPTService
from src.portal.services.mail_config_service import MailConfigService
from src.portal.services.metric_catalog_service import MetricCatalogService
from src.portal.services.metric_config_service import MetricConfigService
from src.portal.services.metric_status_service import MetricStatusService
from src.portal.services.metrics_report_service import MetricsReportService
from src.portal.services.alert_config_service import AlertConfigService
from src.portal.services.settings_service import SettingsService

logger = logging.getLogger(__name__)


def get_settings(request: Request) -> PortalSettings:
    return request.app.state.settings


def get_db(request: Request) -> PortalDB:
    return request.app.state.db


def get_auth(request: Request) -> KeycloakAuth:
    return request.app.state.auth


def get_hitl_service(request: Request) -> HITLService:
    return request.app.state.hitl_service


def get_baseline_service(request: Request) -> BaselineService:
    return request.app.state.baseline_service


def get_settings_service(request: Request) -> SettingsService:
    return request.app.state.settings_service


def get_holmesgpt_service(request: Request) -> HolmesGPTService:
    return request.app.state.holmesgpt_service


def get_metrics_report_service(request: Request) -> MetricsReportService:
    return request.app.state.metrics_report_service


def get_metric_config_service(request: Request) -> MetricConfigService:
    return request.app.state.metric_config_service


def get_metric_status_service(request: Request) -> MetricStatusService:
    return request.app.state.metric_status_service


def get_cost_report_service(request: Request) -> CostReportService:
    return request.app.state.cost_report_service


def get_drift_config_service(request: Request) -> DriftConfigService:
    return request.app.state.drift_config_service


def get_airflow_config_service(request: Request) -> AirflowConfigService:
    return request.app.state.airflow_config_service


def get_drift_report_service(request: Request) -> DriftReportService:
    return request.app.state.drift_report_service


def get_airflow_report_service(request: Request) -> AirflowReportService:
    return request.app.state.airflow_report_service


def get_dashboard_report_service(request: Request) -> DashboardReportService:
    return request.app.state.dashboard_report_service


def get_hdsp_dashboard_report_service(request: Request):
    """HDSP Dashboard Report Service dependency."""
    return request.app.state.hdsp_dashboard_report_service


def get_metric_catalog_service(request: Request) -> MetricCatalogService:
    return request.app.state.metric_catalog_service


def get_mail_config_service(request: Request) -> MailConfigService:
    return request.app.state.mail_config_service


def get_alert_config_service(request: Request) -> AlertConfigService:
    return request.app.state.alert_config_service


def get_config_mapper(request: Request):
    """ConfigCheckItemMapper (may be None if bdp_drift not available)."""
    return getattr(request.app.state, "config_mapper", None)


def get_current_user(request: Request) -> dict | None:
    """Get current user or None. For auth-disabled mode, returns a default user."""
    settings: PortalSettings = request.app.state.settings
    if not settings.auth_enabled:
        return {"name": "dev", "email": "dev@local", "sub": "dev"}
    return request.session.get("user")


def require_auth(request: Request) -> dict:
    """Dependency that requires authentication. Raises redirect if not authenticated."""
    user = get_current_user(request)
    if user is None:
        raise _AuthRedirect()
    return user


def _decode_jwt_token(token: str) -> dict:
    """JWT 토큰 디코딩 (서명 검증 없음 - Keycloak 게이트웨이에서 처리)."""
    try:
        payload_b64 = token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        payload = json.loads(payload_bytes)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

    name = payload.get("name") or payload.get("preferred_username", "")
    email = payload.get("email", "")
    sub = payload.get("sub", "")

    if not sub:
        raise HTTPException(status_code=401, detail="Invalid token: missing sub claim")

    return {"name": name, "email": email, "sub": sub}


def require_jwt_auth(request: Request) -> dict:
    """JWT authentication dependency for API v1 routes.

    When auth is disabled, returns a dev user.
    When auth is enabled, extracts and decodes the JWT Bearer token
    from the Authorization header (no signature verification - Keycloak
    handles this at the gateway level).
    """
    settings: PortalSettings = request.app.state.settings
    if not settings.auth_enabled:
        return {"name": "dev", "email": "dev@local", "sub": "dev"}

    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")

    token = auth_header.removeprefix("Bearer ").strip()
    return _decode_jwt_token(token)


def require_jwt_auth_flexible(request: Request) -> dict:
    """JWT 인증 - Authorization 헤더 또는 query param 'token' 지원.

    iframe에서 Authorization 헤더를 보낼 수 없으므로
    query parameter로 JWT를 전달하는 방식도 허용.
    """
    settings: PortalSettings = request.app.state.settings
    if not settings.auth_enabled:
        return {"name": "dev", "email": "dev@local", "sub": "dev"}

    # 1. Authorization 헤더 확인
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.removeprefix("Bearer ").strip()
        return _decode_jwt_token(token)

    # 2. Query parameter 확인
    token = request.query_params.get("token")
    if token:
        return _decode_jwt_token(token)

    raise HTTPException(status_code=401, detail="Missing authentication")


class _AuthRedirect(Exception):
    """Raised when authentication is required but user is not logged in."""

    pass
