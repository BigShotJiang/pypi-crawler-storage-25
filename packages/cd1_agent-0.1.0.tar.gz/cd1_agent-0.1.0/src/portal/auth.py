"""Keycloak OIDC Authentication for Portal."""

import logging
from typing import Optional

from starlette.requests import Request

from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)


class KeycloakAuth:
    """Keycloak OIDC authentication handler using authlib."""

    def __init__(self, settings: PortalSettings):
        self.settings = settings
        self.oauth = None

        if not settings.auth_enabled:
            logger.info("Authentication disabled (AUTH_ENABLED=false)")
            return

        try:
            from authlib.integrations.starlette_client import OAuth

            self.oauth = OAuth()
            # Dual-URL: internal URL for server-to-server (Docker network),
            # external URL (keycloak_url) for browser redirects
            internal_url = settings.keycloak_internal_url or settings.keycloak_url
            external_url = settings.keycloak_url
            realm_internal = f"{internal_url}/realms/{settings.keycloak_realm}"
            realm_external = f"{external_url}/realms/{settings.keycloak_realm}"
            oidc_internal = f"{realm_internal}/protocol/openid-connect"
            oidc_external = f"{realm_external}/protocol/openid-connect"

            register_kwargs = dict(
                name="keycloak",
                client_id=settings.keycloak_client_id,
                client_secret=settings.keycloak_client_secret,
                client_kwargs={"scope": "openid email profile"},
            )

            if settings.keycloak_internal_url:
                # Docker: all endpoints explicit to avoid metadata localhost URLs
                # Browser-facing: authorize uses external URL
                # Server-facing: token, userinfo, jwks use internal URL
                register_kwargs.update(
                    authorize_url=f"{oidc_external}/auth",
                    access_token_url=f"{oidc_internal}/token",
                    userinfo_endpoint=f"{oidc_internal}/userinfo",
                    jwks_uri=f"{oidc_internal}/certs",
                    issuer=realm_external,
                )
            else:
                # Non-Docker: single URL, use auto-discovery
                register_kwargs["server_metadata_url"] = (
                    f"{realm_internal}/.well-known/openid-configuration"
                )

            self.oauth.register(**register_kwargs)
            logger.info(f"Keycloak OIDC configured: external={external_url}, internal={internal_url}")
        except ImportError:
            logger.warning("authlib not installed. Authentication will be disabled.")
            self.oauth = None

    @property
    def enabled(self) -> bool:
        return self.settings.auth_enabled and self.oauth is not None

    async def login_redirect(self, request: Request):
        """Redirect to Keycloak login page."""
        redirect_uri = request.url_for("auth_callback")
        return await self.oauth.keycloak.authorize_redirect(request, redirect_uri)

    async def handle_callback(self, request: Request) -> dict:
        """Handle Keycloak callback and return user info."""
        token = await self.oauth.keycloak.authorize_access_token(request)
        userinfo = token.get("userinfo", {})
        return {
            "sub": userinfo.get("sub", ""),
            "email": userinfo.get("email", ""),
            "name": userinfo.get("preferred_username", userinfo.get("name", "")),
            "token": token,
        }

    def get_logout_url(self) -> str:
        """Get Keycloak logout URL."""
        return (
            f"{self.settings.keycloak_url}/realms/{self.settings.keycloak_realm}"
            "/protocol/openid-connect/logout"
        )

    @staticmethod
    def get_current_user(request: Request) -> Optional[dict]:
        """Get current user from session."""
        return request.session.get("user")
