"""API Key authentication middleware."""

import logging

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from src.agent_server.config import get_server_config

logger = logging.getLogger(__name__)

# Paths that skip authentication
_PUBLIC_PATHS = {"/health", "/ready", "/docs", "/redoc", "/openapi.json"}


class APIKeyMiddleware(BaseHTTPMiddleware):
    """Validate X-API-Key header on all non-public requests."""

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        path = request.url.path
        if path in _PUBLIC_PATHS or path.startswith("/docs") or path.startswith("/redoc"):
            return await call_next(request)

        config = get_server_config()
        api_key = request.headers.get("X-API-Key")
        if not api_key or api_key != config.api_key:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or missing API key"},
            )

        return await call_next(request)
