"""BDP Stats Agent - Project Execution Statistics Drift Detection."""
