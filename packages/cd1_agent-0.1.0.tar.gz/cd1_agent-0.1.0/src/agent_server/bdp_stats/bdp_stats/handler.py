"""
BDP Stats Agent - Lambda Handler.

project_cd 기반 수행 통계 drift 탐지.
실행 주기: 주 1회

Supported Stats:
- SageMaker Pipeline: execution_count, failure_rate, avg_duration
- EMR Cluster/Serverless: execution_count, failure_rate, cost
- Athena Query: query_count, failure_rate, data_scanned, cost
"""

import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from bdp_stats.services.project_code_provider import ProjectCodeProvider
from bdp_stats.services.fetchers.sagemaker_stats_fetcher import SageMakerPipelineStatsFetcher
from bdp_stats.services.fetchers.emr_stats_fetcher import EMRStatsFetcher
from bdp_stats.services.fetchers.athena_stats_fetcher import AthenaStatsFetcher
from bdp_stats.services.models import DriftSeverity, StatsDrift

from src.agent_server.bdp_common.eventbridge.publisher import (
    EventPublisher,
    AlertEvent,
    ProductionAlertDetail,
    EmailChannel,
    KakaoChannel,
    get_environment_account_name,
)

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class BDPStatsHandler:
    """BDP Stats Agent Handler.

    project_cd 기반 수행 통계 drift 탐지.
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        project_code_secret_id: Optional[str] = None,
        project_code_db: Optional[str] = None,
    ):
        """핸들러 초기화.

        Args:
            provider: Stats provider ("mock" or "aws")
            project_code_secret_id: project_cd DB credentials secret ID
            project_code_db: project_cd 데이터베이스 이름
        """
        self.provider = provider or os.getenv("STATS_PROVIDER", "mock")
        use_mock = self.provider == "mock"

        # Project Code Provider
        self.project_provider = ProjectCodeProvider(
            secret_id=project_code_secret_id or os.getenv("PROJECT_CODE_SECRET_ID"),
            db=project_code_db or os.getenv("PROJECT_CODE_DB_NAME"),
            use_mock=use_mock,
        )

        # Stats Fetchers
        self.sagemaker_fetcher = SageMakerPipelineStatsFetcher(use_mock=use_mock)
        self.emr_fetcher = EMRStatsFetcher(use_mock=use_mock)
        self.athena_fetcher = AthenaStatsFetcher(use_mock=use_mock)

        # 알림 설정
        self.event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.event_publisher = EventPublisher(
            source="cd1-agent.bdp-stats",
            event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
            use_mock=(self.event_provider == "mock"),
        )

        # Production 알림 설정
        email_to_str = os.getenv("DEFAULT_EMAIL_TO", "")
        email_cc_str = os.getenv("DEFAULT_EMAIL_CC", "")
        self.default_email_to = [e.strip() for e in email_to_str.split(",") if e.strip()]
        self.default_email_cc = [e.strip() for e in email_cc_str.split(",") if e.strip()]

        logger.info(
            f"BDPStatsHandler initialized: "
            f"provider={self.provider}, event_provider={self.event_provider}"
        )

    def process(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """이벤트 처리.

        Args:
            event: 이벤트 페이로드
                - action: "detect" (기본값)
                - stats_types: 대상 통계 타입 목록 (선택)
                    지원 타입: sagemaker-pipeline, emr-cluster, emr-serverless, athena-query
                - project_codes: 특정 project_cd 목록 (선택, 없으면 전체)
                - days: 조회 기간 (기본 7일)

        Returns:
            처리 결과
        """
        action = event.get("action", "detect")

        if action == "detect":
            return self._detect_drift(event)
        else:
            return {"status": "error", "message": f"Unknown action: {action}"}

    def _detect_drift(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """수행 통계 기반 drift 탐지.

        Args:
            event: 이벤트 페이로드
                - stats_types: 대상 통계 타입 목록 (선택)
                - project_codes: 특정 project_cd 목록 (선택)
                - days: 조회 기간 (기본 7일)
                - publish_alerts: EventBridge 발행 여부 (기본 True)
                - send_kakao: 카카오톡 알림 발송 여부 (기본 False)
                - email_to: 이메일 수신자 목록
                - email_cc: 이메일 참조 목록

        Returns:
            탐지 결과
        """
        stats_types = event.get("stats_types", [
            "sagemaker-pipeline",
            "emr-cluster",
            "emr-serverless",
            "athena-query",
        ])
        project_codes = event.get("project_codes")
        days = event.get("days", 7)
        publish_alerts = event.get("publish_alerts", True)
        send_kakao = event.get("send_kakao", False)
        email_to = event.get("email_to") or self.default_email_to
        email_cc = event.get("email_cc") or self.default_email_cc

        # project_codes가 없으면 전체 조회
        if not project_codes:
            project_codes = self.project_provider.list_project_codes(active_only=True)

        all_drifts: List[StatsDrift] = []
        stats_summary: Dict[str, Dict[str, Any]] = {}

        for project_cd in project_codes:
            project_drifts = []

            # SageMaker Pipeline 통계
            if "sagemaker-pipeline" in stats_types:
                try:
                    stats = self.sagemaker_fetcher.fetch_stats(project_cd, days)
                    drifts = self.sagemaker_fetcher.detect_drift(
                        project_cd=project_cd,
                        current_stats=stats,
                        days=days,
                    )
                    project_drifts.extend(drifts)

                    stats_summary.setdefault(project_cd, {})["sagemaker"] = {
                        "execution_count": stats.execution_count,
                        "failure_rate": stats.failure_rate,
                        "avg_duration_seconds": stats.avg_duration_seconds,
                    }
                except Exception as e:
                    logger.error(f"Failed to get SageMaker stats for {project_cd}: {e}")

            # EMR Cluster 통계
            if "emr-cluster" in stats_types:
                try:
                    stats = self.emr_fetcher.fetch_cluster_stats(project_cd, days)
                    drifts = self.emr_fetcher.detect_drift(
                        project_cd=project_cd,
                        current_stats=stats,
                        days=days,
                        stats_type="cluster",
                    )
                    project_drifts.extend(drifts)

                    stats_summary.setdefault(project_cd, {})["emr_cluster"] = {
                        "execution_count": stats.execution_count,
                        "failure_rate": stats.failure_rate,
                    }
                except Exception as e:
                    logger.error(f"Failed to get EMR Cluster stats for {project_cd}: {e}")

            # EMR Serverless 통계
            if "emr-serverless" in stats_types:
                try:
                    stats = self.emr_fetcher.fetch_serverless_stats(project_cd, days)
                    drifts = self.emr_fetcher.detect_drift(
                        project_cd=project_cd,
                        current_stats=stats,
                        days=days,
                        stats_type="serverless",
                    )
                    project_drifts.extend(drifts)

                    stats_summary.setdefault(project_cd, {})["emr_serverless"] = {
                        "execution_count": stats.execution_count,
                        "failure_rate": stats.failure_rate,
                        "estimated_cost": stats.estimated_cost,
                    }
                except Exception as e:
                    logger.error(f"Failed to get EMR Serverless stats for {project_cd}: {e}")

            # Athena 통계
            if "athena-query" in stats_types:
                try:
                    stats = self.athena_fetcher.fetch_stats(project_cd, days)
                    drifts = self.athena_fetcher.detect_drift(
                        project_cd=project_cd,
                        current_stats=stats,
                        days=days,
                    )
                    project_drifts.extend(drifts)

                    stats_summary.setdefault(project_cd, {})["athena"] = {
                        "execution_count": stats.execution_count,
                        "failure_rate": stats.failure_rate,
                        "estimated_cost": stats.estimated_cost,
                        "total_data_scanned_tb": stats.metadata.get("total_data_scanned_tb", 0),
                    }
                except Exception as e:
                    logger.error(f"Failed to get Athena stats for {project_cd}: {e}")

            all_drifts.extend(project_drifts)

        logger.info(
            f"Stats drift detection complete: "
            f"{len(project_codes)} projects, {len(all_drifts)} drifts found"
        )

        # 알림 발행
        if all_drifts and publish_alerts:
            self._publish_events(all_drifts, stats_summary, email_to, email_cc, send_kakao)

        return self._build_response(all_drifts, stats_summary)

    def _get_highest_severity(self, drifts: List[StatsDrift]) -> DriftSeverity:
        """가장 높은 심각도 반환."""
        for severity in [DriftSeverity.CRITICAL, DriftSeverity.HIGH, DriftSeverity.MEDIUM]:
            if any(d.severity == severity for d in drifts):
                return severity
        return DriftSeverity.LOW

    def _get_severity_emoji(self, severity: DriftSeverity) -> str:
        """심각도에 따른 이모지 반환."""
        emoji_map = {
            DriftSeverity.CRITICAL: "🔴",
            DriftSeverity.HIGH: "🟠",
            DriftSeverity.MEDIUM: "🟡",
            DriftSeverity.LOW: "🟢",
        }
        return emoji_map.get(severity, "⚪")

    def _publish_events(
        self,
        drifts: List[StatsDrift],
        stats_summary: Dict[str, Dict[str, Any]],
        email_to: List[str],
        email_cc: List[str],
        send_kakao: bool = False,
    ) -> None:
        """EventBridge에 이벤트 발행.

        Mock 모드에서는 기존 AlertEvent 형식 사용.
        Production 모드에서는 내부 알림 시스템 형식 사용.

        Args:
            drifts: StatsDrift 목록
            stats_summary: 통계 요약 정보
            email_to: 이메일 수신자 목록
            email_cc: 이메일 참조 목록
            send_kakao: 카카오톡 알림 발송 여부
        """
        try:
            highest_severity = self._get_highest_severity(drifts)
            severity_emoji = self._get_severity_emoji(highest_severity)

            # 요약 메시지 생성
            severity_counts = {
                "critical": sum(1 for d in drifts if d.severity == DriftSeverity.CRITICAL),
                "high": sum(1 for d in drifts if d.severity == DriftSeverity.HIGH),
                "medium": sum(1 for d in drifts if d.severity == DriftSeverity.MEDIUM),
                "low": sum(1 for d in drifts if d.severity == DriftSeverity.LOW),
            }
            affected_projects = list(set(d.project_cd for d in drifts))

            title = f"수행 통계 Drift 탐지: {len(drifts)}건"
            message = (
                f"총 {len(drifts)}건의 수행 통계 Drift가 탐지되었습니다.\n"
                f"[심각: {severity_counts['critical']}, 높음: {severity_counts['high']}, "
                f"보통: {severity_counts['medium']}, 낮음: {severity_counts['low']}]\n"
                f"영향 프로젝트: {', '.join(affected_projects[:5])}"
                + (f" 외 {len(affected_projects) - 5}개" if len(affected_projects) > 5 else "")
            )

            if self.event_publisher.use_mock:
                # Mock 모드: AlertEvent 형식
                event = AlertEvent(
                    alert_type="stats_drift_batch",
                    severity=severity_emoji,
                    severity_level=highest_severity.value,
                    title=title,
                    message=message,
                    affected_resources=[
                        {
                            "project_cd": d.project_cd,
                            "stats_type": d.stats_type,
                            "metric_name": d.metric_name,
                            "current_value": d.current_value,
                            "baseline_value": d.baseline_value,
                            "change_percent": d.change_percent,
                            "severity": d.severity.value,
                        }
                        for d in drifts
                    ],
                    action_required=highest_severity in (DriftSeverity.CRITICAL, DriftSeverity.HIGH),
                    metadata={
                        "total_drifts": len(drifts),
                        "by_severity": severity_counts,
                        "stats_summary": stats_summary,
                    },
                )
                self.event_publisher.publish_event(event, "Stats Drift Detected")
                logger.info("EventBridge event published (Mock mode)")
            else:
                # Production 모드: 내부 알림 시스템 형식
                kakao_channel = None
                if send_kakao:
                    kakao_channel = KakaoChannel(
                        severity='MAJOR',
                        category1=get_environment_account_name().upper(),
                        message=f"{title}\n{message}",
                    )

                # HTML 리포트 생성
                html_message = self._generate_html_message(drifts, title, severity_counts)

                detail = ProductionAlertDetail(
                    subject=f"{severity_emoji} {title}",
                    account_id=get_environment_account_name(),
                    email=EmailChannel(
                        to=email_to,
                        cc=email_cc,
                        from_email="alert-stats@hcs.com",
                        message=html_message,
                    ),
                    kakao=kakao_channel,
                )
                self.event_publisher.publish_production_event(detail, "Stats Drift Detected")
                logger.info("EventBridge event published (Production mode)")

        except Exception as e:
            logger.error(f"Failed to publish EventBridge event: {e}")

    def _generate_html_message(
        self,
        drifts: List[StatsDrift],
        title: str,
        severity_counts: Dict[str, int],
    ) -> str:
        """HTML 형식의 이메일 메시지 생성.

        Args:
            drifts: StatsDrift 목록
            title: 알림 제목
            severity_counts: 심각도별 카운트

        Returns:
            HTML 문자열
        """
        rows = ""
        for d in drifts:
            severity_color = {
                "critical": "#dc3545",
                "high": "#fd7e14",
                "medium": "#ffc107",
                "low": "#28a745",
            }.get(d.severity.value, "#6c757d")

            rows += f"""
            <tr>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.project_cd}</td>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.stats_type}</td>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.metric_name}</td>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.current_value:.2f}</td>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.baseline_value:.2f}</td>
                <td style="padding: 8px; border: 1px solid #dee2e6;">{d.change_percent:+.1f}%</td>
                <td style="padding: 8px; border: 1px solid #dee2e6; color: {severity_color}; font-weight: bold;">
                    {d.severity.value.upper()}
                </td>
            </tr>
            """

        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px;">
            <h2 style="color: #333;">{title}</h2>
            <p>
                총 {len(drifts)}건의 수행 통계 Drift가 탐지되었습니다.<br/>
                <strong style="color: #dc3545;">심각: {severity_counts['critical']}</strong> |
                <strong style="color: #fd7e14;">높음: {severity_counts['high']}</strong> |
                <strong style="color: #ffc107;">보통: {severity_counts['medium']}</strong> |
                <strong style="color: #28a745;">낮음: {severity_counts['low']}</strong>
            </p>
            <table style="border-collapse: collapse; width: 100%; margin-top: 20px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">프로젝트</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">통계 타입</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">메트릭</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">현재값</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">기준값</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">변화율</th>
                        <th style="padding: 10px; border: 1px solid #dee2e6; text-align: left;">심각도</th>
                    </tr>
                </thead>
                <tbody>
                    {rows}
                </tbody>
            </table>
            <p style="margin-top: 20px; color: #6c757d; font-size: 12px;">
                탐지 시간: {datetime.now(KST).isoformat()}
            </p>
        </body>
        </html>
        """

    def _build_response(
        self,
        drifts: List[StatsDrift],
        stats_summary: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Any]:
        """응답 생성."""
        severity_counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        for drift in drifts:
            severity_counts[drift.severity.value] += 1

        return {
            "status": "success",
            "timestamp": datetime.now(KST).isoformat(),
            "summary": {
                "total_projects": len(stats_summary),
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
            "drifts": [d.to_dict() for d in drifts],
            "stats_summary": stats_summary,
        }


# Lambda 핸들러
_handler_instance: Optional[BDPStatsHandler] = None


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda 핸들러 함수.

    Args:
        event: Lambda 이벤트
        context: Lambda 컨텍스트

    Returns:
        탐지 결과
    """
    global _handler_instance

    if _handler_instance is None:
        _handler_instance = BDPStatsHandler()

    return _handler_instance.process(event)


if __name__ == "__main__":
    # 로컬 테스트
    result = handler(
        {
            "action": "detect",
            "stats_types": ["sagemaker-pipeline", "emr-serverless", "athena-query"],
            "project_codes": ["ABC001", "ABC002"],
            "days": 7,
        },
        None,
    )
    import json
    print(json.dumps(result, indent=2, default=str))
