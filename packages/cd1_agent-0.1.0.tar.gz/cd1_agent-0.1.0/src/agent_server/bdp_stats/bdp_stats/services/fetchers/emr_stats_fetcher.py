"""
EMR Stats Fetcher.

EMR Cluster/Serverless 수행 통계 조회.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from bdp_stats.services.models import (
    DriftSeverity,
    ExecutionStats,
    StatsDrift,
    StatsType,
    STATS_DRIFT_THRESHOLDS,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class EMRStatsFetcher:
    """EMR 수행 통계 조회기.

    EMR Cluster 및 EMR Serverless 수행 통계 수집.
    클러스터/Job 이름에 project_cd가 포함된 것으로 필터링.
    """

    def __init__(
        self,
        emr_client=None,
        emr_serverless_client=None,
        use_mock: bool = False,
    ):
        self.use_mock = use_mock or os.getenv("STATS_PROVIDER", "").lower() == "mock"
        self._emr_client = emr_client
        self._emr_serverless_client = emr_serverless_client

    @property
    def emr_client(self):
        if self._emr_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._emr_client = get_boto3_client("emr", config=config)
        return self._emr_client

    @property
    def emr_serverless_client(self):
        if self._emr_serverless_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._emr_serverless_client = get_boto3_client("emr-serverless", config=config)
        return self._emr_serverless_client

    def fetch_cluster_stats(
        self,
        project_cd: str,
        days: int = 7,
    ) -> ExecutionStats:
        """EMR Cluster 수행 통계 조회.

        Args:
            project_cd: 프로젝트 코드
            days: 조회 기간 (일)

        Returns:
            ExecutionStats
        """
        if self.use_mock:
            return self._mock_cluster_stats(project_cd, days)

        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        execution_count = 0
        success_count = 0
        failure_count = 0
        total_duration = 0.0
        durations = []

        try:
            # project_cd가 포함된 클러스터 찾기
            paginator = self.emr_client.get_paginator("list_clusters")

            for page in paginator.paginate(
                CreatedAfter=start_time,
                CreatedBefore=end_time,
            ):
                for cluster in page.get("Clusters", []):
                    name = cluster.get("Name", "")

                    # project_cd 필터링
                    if project_cd.lower() not in name.lower():
                        continue

                    execution_count += 1
                    status = cluster.get("Status", {}).get("State")

                    if status in ["TERMINATED", "WAITING", "RUNNING"]:
                        # TERMINATED_WITH_ERRORS가 아니면 성공으로 간주
                        success_count += 1
                    else:
                        failure_count += 1

                    # 클러스터 상세 정보에서 duration 계산
                    cluster_id = cluster.get("Id")
                    try:
                        detail = self.emr_client.describe_cluster(ClusterId=cluster_id)
                        timeline = detail.get("Cluster", {}).get("Status", {}).get("Timeline", {})
                        creation_time = timeline.get("CreationDateTime")
                        end_time_cluster = timeline.get("EndDateTime")

                        if creation_time and end_time_cluster:
                            duration = (end_time_cluster - creation_time).total_seconds()
                            durations.append(duration)
                            total_duration += duration
                    except Exception:
                        pass

            avg_duration = sum(durations) / len(durations) if durations else 0.0

        except Exception as e:
            logger.error(f"Failed to fetch EMR cluster stats for {project_cd}: {e}")
            avg_duration = 0.0

        return ExecutionStats(
            stats_type=StatsType.EMR_CLUSTER.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=execution_count,
            success_count=success_count,
            failure_count=failure_count,
            avg_duration_seconds=avg_duration,
            total_duration_seconds=total_duration,
            estimated_cost=None,  # EMR 비용은 별도 계산 필요
        )

    def fetch_serverless_stats(
        self,
        project_cd: str,
        days: int = 7,
    ) -> ExecutionStats:
        """EMR Serverless 수행 통계 조회.

        Args:
            project_cd: 프로젝트 코드
            days: 조회 기간 (일)

        Returns:
            ExecutionStats
        """
        if self.use_mock:
            return self._mock_serverless_stats(project_cd, days)

        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        execution_count = 0
        success_count = 0
        failure_count = 0
        total_duration = 0.0
        durations = []
        total_vcpu_hours = 0.0
        total_memory_gb_hours = 0.0

        try:
            # EMR Serverless Applications 조회
            apps_response = self.emr_serverless_client.list_applications()

            for app in apps_response.get("applications", []):
                app_id = app.get("id")
                app_name = app.get("name", "")

                # project_cd 필터링 (Application 이름 기준)
                if project_cd.lower() not in app_name.lower():
                    continue

                # Job runs 조회
                paginator = self.emr_serverless_client.get_paginator("list_job_runs")

                for page in paginator.paginate(
                    applicationId=app_id,
                    createdAtAfter=start_time,
                    createdAtBefore=end_time,
                ):
                    for job_run in page.get("jobRuns", []):
                        execution_count += 1

                        state = job_run.get("state")
                        if state == "SUCCESS":
                            success_count += 1
                        elif state in ["FAILED", "CANCELLED"]:
                            failure_count += 1

                        # Duration
                        job_run_id = job_run.get("id")
                        try:
                            detail = self.emr_serverless_client.get_job_run(
                                applicationId=app_id,
                                jobRunId=job_run_id,
                            )
                            job_detail = detail.get("jobRun", {})

                            total_resource = job_detail.get("totalResourceUtilization", {})
                            vcpu_hours = total_resource.get("vCPUHour", 0)
                            memory_gb_hours = total_resource.get("memoryGBHour", 0)

                            total_vcpu_hours += vcpu_hours
                            total_memory_gb_hours += memory_gb_hours

                            # Execution time
                            execution_time = total_resource.get("totalExecutionDurationSeconds", 0)
                            if execution_time:
                                durations.append(execution_time)
                                total_duration += execution_time
                        except Exception:
                            pass

            avg_duration = sum(durations) / len(durations) if durations else 0.0

            # EMR Serverless 비용 추정 (대략적)
            # vCPU: $0.052624/hour, Memory: $0.0057785/GB-hour (ap-northeast-2)
            estimated_cost = (total_vcpu_hours * 0.052624) + (total_memory_gb_hours * 0.0057785)

        except Exception as e:
            logger.error(f"Failed to fetch EMR Serverless stats for {project_cd}: {e}")
            avg_duration = 0.0
            estimated_cost = None

        return ExecutionStats(
            stats_type=StatsType.EMR_SERVERLESS.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=execution_count,
            success_count=success_count,
            failure_count=failure_count,
            avg_duration_seconds=avg_duration,
            total_duration_seconds=total_duration,
            estimated_cost=estimated_cost,
            metadata={
                "total_vcpu_hours": total_vcpu_hours,
                "total_memory_gb_hours": total_memory_gb_hours,
            } if 'total_vcpu_hours' in dir() else {},
        )

    def detect_drift(
        self,
        project_cd: str,
        baseline_stats: Optional[ExecutionStats] = None,
        current_stats: Optional[ExecutionStats] = None,
        days: int = 7,
        stats_type: str = "cluster",
    ) -> List[StatsDrift]:
        """EMR 수행 통계 drift 감지.

        Args:
            project_cd: 프로젝트 코드
            baseline_stats: 비교 기준 통계
            current_stats: 현재 통계
            days: 현재 기간 (일)
            stats_type: "cluster" 또는 "serverless"

        Returns:
            감지된 drift 목록
        """
        if stats_type == "serverless":
            fetch_func = self.fetch_serverless_stats
            drift_type = StatsType.EMR_SERVERLESS.value
        else:
            fetch_func = self.fetch_cluster_stats
            drift_type = StatsType.EMR_CLUSTER.value

        if current_stats is None:
            current_stats = fetch_func(project_cd, days)

        if baseline_stats is None:
            baseline_stats = fetch_func(project_cd, days)

        drifts = []
        now = datetime.now(KST)

        # 1. 실패율 증가 체크
        if baseline_stats.execution_count > 0:
            failure_rate_change = current_stats.failure_rate - baseline_stats.failure_rate

            if failure_rate_change >= STATS_DRIFT_THRESHOLDS["failure_rate_increase"]["CRITICAL"]:
                drifts.append(StatsDrift(
                    stats_type=drift_type,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="failure_rate",
                    current_value=current_stats.failure_rate,
                    baseline_value=baseline_stats.failure_rate,
                    change_percent=failure_rate_change,
                    severity=DriftSeverity.CRITICAL,
                    description=f"EMR 실패율 급증: {baseline_stats.failure_rate:.1f}% → {current_stats.failure_rate:.1f}%",
                    recommendation="EMR 클러스터/Job 로그 확인 필요",
                    detected_at=now,
                ))

        # 2. 비용 증가 체크 (Serverless만)
        if (current_stats.estimated_cost and baseline_stats.estimated_cost
            and baseline_stats.estimated_cost > 0):
            cost_change_percent = ((current_stats.estimated_cost - baseline_stats.estimated_cost)
                                   / baseline_stats.estimated_cost * 100)

            if cost_change_percent >= STATS_DRIFT_THRESHOLDS["cost_increase"]["HIGH"]:
                drifts.append(StatsDrift(
                    stats_type=drift_type,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="estimated_cost",
                    current_value=current_stats.estimated_cost,
                    baseline_value=baseline_stats.estimated_cost,
                    change_percent=cost_change_percent,
                    severity=DriftSeverity.HIGH,
                    description=f"EMR 비용 급증: ${baseline_stats.estimated_cost:.2f} → ${current_stats.estimated_cost:.2f} (+{cost_change_percent:.1f}%)",
                    recommendation="리소스 사용 효율성 검토 필요",
                    detected_at=now,
                ))

        return drifts

    def _mock_cluster_stats(self, project_cd: str, days: int) -> ExecutionStats:
        """Mock EMR Cluster 통계."""
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        return ExecutionStats(
            stats_type=StatsType.EMR_CLUSTER.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=15,
            success_count=13,
            failure_count=2,
            avg_duration_seconds=7200.0,  # 2시간
            total_duration_seconds=108000.0,
            metadata={"mock": True},
        )

    def _mock_serverless_stats(self, project_cd: str, days: int) -> ExecutionStats:
        """Mock EMR Serverless 통계."""
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        return ExecutionStats(
            stats_type=StatsType.EMR_SERVERLESS.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=100,
            success_count=95,
            failure_count=5,
            avg_duration_seconds=600.0,  # 10분
            total_duration_seconds=60000.0,
            estimated_cost=150.50,
            metadata={
                "mock": True,
                "total_vcpu_hours": 500.0,
                "total_memory_gb_hours": 2000.0,
            },
        )
