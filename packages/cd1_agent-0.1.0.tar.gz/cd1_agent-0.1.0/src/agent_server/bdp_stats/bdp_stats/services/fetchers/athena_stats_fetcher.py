"""
Athena Stats Fetcher.

Athena Query 수행 통계 조회.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from bdp_stats.services.models import (
    DriftSeverity,
    ExecutionStats,
    StatsDrift,
    StatsType,
    STATS_DRIFT_THRESHOLDS,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# Athena 비용: $5 per TB scanned
ATHENA_COST_PER_TB = 5.0


class AthenaStatsFetcher:
    """Athena Query 수행 통계 조회기.

    project_cd 기반으로 Athena 쿼리 수행 통계 수집.
    Workgroup 이름에 project_cd가 포함된 것으로 필터링.
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
    ):
        self.use_mock = use_mock or os.getenv("STATS_PROVIDER", "").lower() == "mock"
        self._client = client

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._client = get_boto3_client("athena", config=config)
        return self._client

    def fetch_stats(
        self,
        project_cd: str,
        days: int = 7,
        workgroup: Optional[str] = None,
    ) -> ExecutionStats:
        """Athena Query 수행 통계 조회.

        Args:
            project_cd: 프로젝트 코드
            days: 조회 기간 (일)
            workgroup: 특정 워크그룹 (없으면 project_cd로 필터)

        Returns:
            ExecutionStats
        """
        if self.use_mock:
            return self._mock_stats(project_cd, days)

        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        execution_count = 0
        success_count = 0
        failure_count = 0
        total_duration = 0.0
        total_data_scanned = 0
        durations = []

        try:
            # 대상 워크그룹 결정
            if workgroup:
                workgroups = [workgroup]
            else:
                workgroups = self._list_workgroups_by_project(project_cd)

            for wg in workgroups:
                # 쿼리 실행 목록 조회
                paginator = self.client.get_paginator("list_query_executions")

                for page in paginator.paginate(WorkGroup=wg):
                    query_ids = page.get("QueryExecutionIds", [])

                    if not query_ids:
                        continue

                    # 배치로 쿼리 상세 조회 (최대 50개)
                    for i in range(0, len(query_ids), 50):
                        batch_ids = query_ids[i:i + 50]
                        batch_response = self.client.batch_get_query_execution(
                            QueryExecutionIds=batch_ids
                        )

                        for execution in batch_response.get("QueryExecutions", []):
                            status = execution.get("Status", {})
                            submit_time = status.get("SubmissionDateTime")

                            # 기간 필터링
                            if submit_time and (submit_time < start_time or submit_time > end_time):
                                continue

                            execution_count += 1

                            state = status.get("State")
                            if state == "SUCCEEDED":
                                success_count += 1
                            elif state in ["FAILED", "CANCELLED"]:
                                failure_count += 1

                            # Duration (completion - submission)
                            completion_time = status.get("CompletionDateTime")
                            if submit_time and completion_time:
                                duration = (completion_time - submit_time).total_seconds()
                                durations.append(duration)
                                total_duration += duration

                            # Data scanned
                            stats = execution.get("Statistics", {})
                            data_scanned = stats.get("DataScannedInBytes", 0)
                            total_data_scanned += data_scanned

            avg_duration = sum(durations) / len(durations) if durations else 0.0

            # 비용 추정 ($5/TB)
            total_data_scanned_tb = total_data_scanned / (1024 ** 4)
            estimated_cost = total_data_scanned_tb * ATHENA_COST_PER_TB

        except Exception as e:
            logger.error(f"Failed to fetch Athena stats for {project_cd}: {e}")
            avg_duration = 0.0
            estimated_cost = None
            total_data_scanned = 0

        return ExecutionStats(
            stats_type=StatsType.ATHENA_QUERY.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=execution_count,
            success_count=success_count,
            failure_count=failure_count,
            avg_duration_seconds=avg_duration,
            total_duration_seconds=total_duration,
            estimated_cost=estimated_cost,
            metadata={
                "total_data_scanned_bytes": total_data_scanned,
                "total_data_scanned_tb": total_data_scanned / (1024 ** 4),
                "workgroups": workgroups if 'workgroups' in dir() else [],
            },
        )

    def _list_workgroups_by_project(self, project_cd: str) -> List[str]:
        """project_cd가 포함된 워크그룹 목록 조회."""
        workgroups = []
        try:
            next_token = None
            while True:
                kwargs = {}
                if next_token:
                    kwargs["NextToken"] = next_token

                response = self.client.list_work_groups(**kwargs)

                for wg in response.get("WorkGroups", []):
                    name = wg.get("Name", "")
                    # Workgroup 이름에 project_cd가 포함되어 있으면 대상
                    if project_cd.lower() in name.lower():
                        workgroups.append(name)

                next_token = response.get("NextToken")
                if not next_token:
                    break

        except Exception as e:
            logger.error(f"Failed to list workgroups for {project_cd}: {e}")

        return workgroups

    def detect_drift(
        self,
        project_cd: str,
        baseline_stats: Optional[ExecutionStats] = None,
        current_stats: Optional[ExecutionStats] = None,
        days: int = 7,
    ) -> List[StatsDrift]:
        """Athena 수행 통계 drift 감지.

        Args:
            project_cd: 프로젝트 코드
            baseline_stats: 비교 기준 통계
            current_stats: 현재 통계
            days: 현재 기간 (일)

        Returns:
            감지된 drift 목록
        """
        if current_stats is None:
            current_stats = self.fetch_stats(project_cd, days)

        if baseline_stats is None:
            baseline_stats = self.fetch_stats(project_cd, days)

        drifts = []
        now = datetime.now(KST)

        # 1. 실패율 증가 체크
        if baseline_stats.execution_count > 0:
            failure_rate_change = current_stats.failure_rate - baseline_stats.failure_rate

            if failure_rate_change >= STATS_DRIFT_THRESHOLDS["failure_rate_increase"]["CRITICAL"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.ATHENA_QUERY.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="failure_rate",
                    current_value=current_stats.failure_rate,
                    baseline_value=baseline_stats.failure_rate,
                    change_percent=failure_rate_change,
                    severity=DriftSeverity.CRITICAL,
                    description=f"Athena 쿼리 실패율 급증: {baseline_stats.failure_rate:.1f}% → {current_stats.failure_rate:.1f}%",
                    recommendation="쿼리 실패 로그 확인 필요",
                    detected_at=now,
                ))

        # 2. 비용 증가 체크
        if (current_stats.estimated_cost and baseline_stats.estimated_cost
            and baseline_stats.estimated_cost > 0):
            cost_change_percent = ((current_stats.estimated_cost - baseline_stats.estimated_cost)
                                   / baseline_stats.estimated_cost * 100)

            if cost_change_percent >= STATS_DRIFT_THRESHOLDS["cost_increase"]["HIGH"]:
                current_tb = current_stats.metadata.get("total_data_scanned_tb", 0)
                baseline_tb = baseline_stats.metadata.get("total_data_scanned_tb", 0)

                drifts.append(StatsDrift(
                    stats_type=StatsType.ATHENA_QUERY.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="estimated_cost",
                    current_value=current_stats.estimated_cost,
                    baseline_value=baseline_stats.estimated_cost,
                    change_percent=cost_change_percent,
                    severity=DriftSeverity.HIGH,
                    description=(
                        f"Athena 비용 급증: ${baseline_stats.estimated_cost:.2f} → ${current_stats.estimated_cost:.2f} "
                        f"(스캔 데이터: {baseline_tb:.2f}TB → {current_tb:.2f}TB)"
                    ),
                    recommendation="쿼리 최적화 및 파티셔닝 검토 필요",
                    detected_at=now,
                ))

        # 3. Duration 증가 체크
        if baseline_stats.avg_duration_seconds > 0:
            duration_change_percent = ((current_stats.avg_duration_seconds - baseline_stats.avg_duration_seconds)
                                       / baseline_stats.avg_duration_seconds * 100)

            if duration_change_percent >= STATS_DRIFT_THRESHOLDS["duration_increase"]["HIGH"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.ATHENA_QUERY.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="avg_duration",
                    current_value=current_stats.avg_duration_seconds,
                    baseline_value=baseline_stats.avg_duration_seconds,
                    change_percent=duration_change_percent,
                    severity=DriftSeverity.HIGH,
                    description=(
                        f"Athena 쿼리 평균 수행시간 증가: "
                        f"{baseline_stats.avg_duration_seconds:.0f}s → {current_stats.avg_duration_seconds:.0f}s"
                    ),
                    recommendation="쿼리 성능 분석 및 최적화 필요",
                    detected_at=now,
                ))

        return drifts

    def _mock_stats(self, project_cd: str, days: int) -> ExecutionStats:
        """Mock Athena 통계."""
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        # Mock 데이터 (project_cd별로 다른 데이터)
        mock_data = {
            "ABC001": {
                "execution_count": 500,
                "success_count": 480,
                "failure_count": 20,
                "avg_duration": 15.0,
                "total_data_scanned_bytes": 500 * 1024 ** 3,  # 500GB
            },
            "ABC002": {
                "execution_count": 200,
                "success_count": 190,
                "failure_count": 10,
                "avg_duration": 30.0,
                "total_data_scanned_bytes": 200 * 1024 ** 3,  # 200GB
            },
        }

        data = mock_data.get(project_cd, {
            "execution_count": 100,
            "success_count": 95,
            "failure_count": 5,
            "avg_duration": 10.0,
            "total_data_scanned_bytes": 100 * 1024 ** 3,
        })

        total_data_scanned_tb = data["total_data_scanned_bytes"] / (1024 ** 4)
        estimated_cost = total_data_scanned_tb * ATHENA_COST_PER_TB

        return ExecutionStats(
            stats_type=StatsType.ATHENA_QUERY.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=data["execution_count"],
            success_count=data["success_count"],
            failure_count=data["failure_count"],
            avg_duration_seconds=data["avg_duration"],
            total_duration_seconds=data["avg_duration"] * data["execution_count"],
            estimated_cost=estimated_cost,
            metadata={
                "mock": True,
                "total_data_scanned_bytes": data["total_data_scanned_bytes"],
                "total_data_scanned_tb": total_data_scanned_tb,
            },
        )
