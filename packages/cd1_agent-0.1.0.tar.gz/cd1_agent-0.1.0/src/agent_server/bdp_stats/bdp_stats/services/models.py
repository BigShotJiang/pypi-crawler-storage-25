"""
BDP Stats Agent Models.

수행 통계 drift 탐지를 위한 데이터 모델.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class StatsType(str, Enum):
    """통계 타입."""

    SAGEMAKER_PIPELINE = "sagemaker-pipeline"
    EMR_CLUSTER = "emr-cluster"
    EMR_SERVERLESS = "emr-serverless"
    ATHENA_QUERY = "athena-query"


class DriftSeverity(str, Enum):
    """드리프트 심각도."""

    CRITICAL = "critical"   # 즉시 조치 필요
    HIGH = "high"           # 빠른 확인 필요
    MEDIUM = "medium"       # 모니터링 필요
    LOW = "low"             # 참고용


@dataclass
class ExecutionStats:
    """수행 통계 기본 모델."""

    stats_type: str
    project_cd: str
    resource_id: Optional[str]
    period_start: datetime
    period_end: datetime

    execution_count: int
    success_count: int
    failure_count: int

    avg_duration_seconds: float
    total_duration_seconds: float

    estimated_cost: Optional[float] = None
    cost_unit: str = "USD"

    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def failure_rate(self) -> float:
        """실패율 (%)."""
        if self.execution_count == 0:
            return 0.0
        return (self.failure_count / self.execution_count) * 100

    @property
    def success_rate(self) -> float:
        """성공률 (%)."""
        if self.execution_count == 0:
            return 0.0
        return (self.success_count / self.execution_count) * 100


@dataclass
class StatsBaseline:
    """수행 통계 베이스라인."""

    stats_type: str
    project_cd: str
    resource_id: Optional[str]

    baseline_execution_count: float
    baseline_failure_rate: float
    baseline_avg_duration: float
    baseline_cost: Optional[float]

    sample_weeks: int = 4  # 기본 4주
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


@dataclass
class StatsDrift:
    """수행 통계 drift 결과."""

    stats_type: str
    project_cd: str
    resource_id: Optional[str]
    metric_name: str

    current_value: float
    baseline_value: float
    change_percent: float

    severity: DriftSeverity
    description: str
    recommendation: Optional[str] = None
    detected_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환."""
        return {
            "stats_type": self.stats_type,
            "project_cd": self.project_cd,
            "resource_id": self.resource_id,
            "metric_name": self.metric_name,
            "current_value": self.current_value,
            "baseline_value": self.baseline_value,
            "change_percent": self.change_percent,
            "severity": self.severity.value,
            "description": self.description,
            "recommendation": self.recommendation,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
        }


# Severity 임계값 설정
STATS_DRIFT_THRESHOLDS = {
    "failure_rate_increase": {
        "CRITICAL": 10.0,  # +10%p 이상 증가
        "HIGH": 5.0,       # +5%p 이상 증가
    },
    "execution_count_decrease": {
        "HIGH": 50.0,      # 50% 이상 감소 (서비스 중단 의심)
    },
    "duration_increase": {
        "HIGH": 100.0,     # 2배 이상 증가
    },
    "cost_increase": {
        "HIGH": 50.0,      # 50% 이상 증가
    },
}
