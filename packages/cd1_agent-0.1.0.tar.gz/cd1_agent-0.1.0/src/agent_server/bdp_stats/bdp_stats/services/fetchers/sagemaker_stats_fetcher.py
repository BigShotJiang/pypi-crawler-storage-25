"""
SageMaker Pipeline Stats Fetcher.

SageMaker Pipeline 수행 통계 조회.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from bdp_stats.services.models import (
    DriftSeverity,
    ExecutionStats,
    StatsDrift,
    StatsType,
    STATS_DRIFT_THRESHOLDS,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class SageMakerPipelineStatsFetcher:
    """SageMaker Pipeline 수행 통계 조회기.

    project_cd 기반으로 Pipeline 수행 통계 수집.
    Pipeline 이름에 project_cd가 포함된 것으로 필터링.
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
    ):
        self.use_mock = use_mock or os.getenv("STATS_PROVIDER", "").lower() == "mock"
        self._client = client

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._client = get_boto3_client("sagemaker", config=config)
        return self._client

    def fetch_stats(
        self,
        project_cd: str,
        days: int = 7,
    ) -> ExecutionStats:
        """SageMaker Pipeline 수행 통계 조회.

        Args:
            project_cd: 프로젝트 코드
            days: 조회 기간 (일)

        Returns:
            ExecutionStats
        """
        if self.use_mock:
            return self._mock_stats(project_cd, days)

        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        execution_count = 0
        success_count = 0
        failure_count = 0
        total_duration = 0.0
        durations = []

        try:
            # project_cd가 포함된 Pipeline 찾기
            pipelines = self._list_pipelines_by_project(project_cd)

            for pipeline_name in pipelines:
                # Pipeline executions 조회
                paginator = self.client.get_paginator("list_pipeline_executions")

                for page in paginator.paginate(
                    PipelineName=pipeline_name,
                    CreatedAfter=start_time,
                    CreatedBefore=end_time,
                    SortBy="CreationTime",
                    SortOrder="Descending",
                ):
                    for execution in page.get("PipelineExecutionSummaries", []):
                        execution_count += 1

                        status = execution.get("PipelineExecutionStatus")
                        if status == "Succeeded":
                            success_count += 1
                        elif status in ["Failed", "Stopped"]:
                            failure_count += 1

                        # Duration 계산
                        start = execution.get("StartTime")
                        end = execution.get("EndTime")
                        if start and end:
                            duration = (end - start).total_seconds()
                            durations.append(duration)
                            total_duration += duration

            avg_duration = sum(durations) / len(durations) if durations else 0.0

        except Exception as e:
            logger.error(f"Failed to fetch SageMaker stats for {project_cd}: {e}")
            avg_duration = 0.0

        return ExecutionStats(
            stats_type=StatsType.SAGEMAKER_PIPELINE.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=execution_count,
            success_count=success_count,
            failure_count=failure_count,
            avg_duration_seconds=avg_duration,
            total_duration_seconds=total_duration,
            estimated_cost=None,  # SageMaker Pipeline 비용은 별도 계산 필요
            metadata={"pipeline_count": len(pipelines) if 'pipelines' in dir() else 0},
        )

    def _list_pipelines_by_project(self, project_cd: str) -> List[str]:
        """project_cd가 포함된 Pipeline 목록 조회."""
        pipelines = []
        try:
            paginator = self.client.get_paginator("list_pipelines")
            for page in paginator.paginate():
                for pipeline in page.get("PipelineSummaries", []):
                    name = pipeline.get("PipelineName", "")
                    # Pipeline 이름에 project_cd가 포함되어 있으면 대상으로 간주
                    if project_cd.lower() in name.lower():
                        pipelines.append(name)
        except Exception as e:
            logger.error(f"Failed to list pipelines for {project_cd}: {e}")

        return pipelines

    def detect_drift(
        self,
        project_cd: str,
        baseline_stats: Optional[ExecutionStats] = None,
        current_stats: Optional[ExecutionStats] = None,
        days: int = 7,
    ) -> List[StatsDrift]:
        """수행 통계 drift 감지.

        Args:
            project_cd: 프로젝트 코드
            baseline_stats: 비교 기준 통계 (없으면 2주 전 데이터)
            current_stats: 현재 통계 (없으면 조회)
            days: 현재 기간 (일)

        Returns:
            감지된 drift 목록
        """
        if current_stats is None:
            current_stats = self.fetch_stats(project_cd, days)

        if baseline_stats is None:
            baseline_stats = self.fetch_stats(project_cd, days)
            # Mock 모드가 아닌 경우 2주 전 데이터로 baseline 조정
            # 실제로는 별도 baseline store에서 가져와야 함

        drifts = []
        now = datetime.now(KST)

        # 1. 실패율 증가 체크
        if baseline_stats.execution_count > 0:
            failure_rate_change = current_stats.failure_rate - baseline_stats.failure_rate

            if failure_rate_change >= STATS_DRIFT_THRESHOLDS["failure_rate_increase"]["CRITICAL"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.SAGEMAKER_PIPELINE.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="failure_rate",
                    current_value=current_stats.failure_rate,
                    baseline_value=baseline_stats.failure_rate,
                    change_percent=failure_rate_change,
                    severity=DriftSeverity.CRITICAL,
                    description=f"Pipeline 실패율 급증: {baseline_stats.failure_rate:.1f}% → {current_stats.failure_rate:.1f}% (+{failure_rate_change:.1f}%p)",
                    recommendation="Pipeline 실패 원인 분석 및 조치 필요",
                    detected_at=now,
                ))
            elif failure_rate_change >= STATS_DRIFT_THRESHOLDS["failure_rate_increase"]["HIGH"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.SAGEMAKER_PIPELINE.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="failure_rate",
                    current_value=current_stats.failure_rate,
                    baseline_value=baseline_stats.failure_rate,
                    change_percent=failure_rate_change,
                    severity=DriftSeverity.HIGH,
                    description=f"Pipeline 실패율 증가: {baseline_stats.failure_rate:.1f}% → {current_stats.failure_rate:.1f}% (+{failure_rate_change:.1f}%p)",
                    recommendation="Pipeline 로그 확인 권장",
                    detected_at=now,
                ))

        # 2. 수행 횟수 감소 체크 (서비스 중단 의심)
        if baseline_stats.execution_count > 0:
            count_change_percent = ((current_stats.execution_count - baseline_stats.execution_count)
                                    / baseline_stats.execution_count * 100)

            if count_change_percent <= -STATS_DRIFT_THRESHOLDS["execution_count_decrease"]["HIGH"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.SAGEMAKER_PIPELINE.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="execution_count",
                    current_value=float(current_stats.execution_count),
                    baseline_value=float(baseline_stats.execution_count),
                    change_percent=count_change_percent,
                    severity=DriftSeverity.HIGH,
                    description=f"Pipeline 수행 횟수 급감: {baseline_stats.execution_count} → {current_stats.execution_count} ({count_change_percent:.1f}%)",
                    recommendation="서비스 중단 여부 확인 필요",
                    detected_at=now,
                ))

        # 3. Duration 증가 체크
        if baseline_stats.avg_duration_seconds > 0:
            duration_change_percent = ((current_stats.avg_duration_seconds - baseline_stats.avg_duration_seconds)
                                       / baseline_stats.avg_duration_seconds * 100)

            if duration_change_percent >= STATS_DRIFT_THRESHOLDS["duration_increase"]["HIGH"]:
                drifts.append(StatsDrift(
                    stats_type=StatsType.SAGEMAKER_PIPELINE.value,
                    project_cd=project_cd,
                    resource_id=None,
                    metric_name="avg_duration",
                    current_value=current_stats.avg_duration_seconds,
                    baseline_value=baseline_stats.avg_duration_seconds,
                    change_percent=duration_change_percent,
                    severity=DriftSeverity.HIGH,
                    description=f"Pipeline 평균 수행시간 증가: {baseline_stats.avg_duration_seconds:.0f}s → {current_stats.avg_duration_seconds:.0f}s (+{duration_change_percent:.1f}%)",
                    recommendation="성능 저하 원인 분석 필요",
                    detected_at=now,
                ))

        return drifts

    def _mock_stats(self, project_cd: str, days: int) -> ExecutionStats:
        """Mock 통계 데이터."""
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        mock_data = {
            "ABC001": {
                "execution_count": 50,
                "success_count": 45,
                "failure_count": 5,
                "avg_duration": 1200.0,  # 20분
            },
            "ABC002": {
                "execution_count": 30,
                "success_count": 25,
                "failure_count": 5,
                "avg_duration": 3600.0,  # 1시간
            },
        }

        data = mock_data.get(project_cd, {
            "execution_count": 10,
            "success_count": 9,
            "failure_count": 1,
            "avg_duration": 600.0,
        })

        return ExecutionStats(
            stats_type=StatsType.SAGEMAKER_PIPELINE.value,
            project_cd=project_cd,
            resource_id=None,
            period_start=start_time,
            period_end=end_time,
            execution_count=data["execution_count"],
            success_count=data["success_count"],
            failure_count=data["failure_count"],
            avg_duration_seconds=data["avg_duration"],
            total_duration_seconds=data["avg_duration"] * data["execution_count"],
            metadata={"mock": True},
        )
