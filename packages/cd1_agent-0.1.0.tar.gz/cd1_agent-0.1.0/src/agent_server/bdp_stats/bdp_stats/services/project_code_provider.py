"""
Project Code Provider.

project_cd 목록을 조회하는 프로바이더.
MySqlProvider DB를 활용하여 활성 project_cd 목록을 조회.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ProjectCodeProvider:
    """project_cd 목록 조회 프로바이더.

    Lambda 환경에서 구현:
    - Mock 모드: 하드코딩된 목록 반환
    - AWS 모드: Secrets Manager에서 DB credentials 조회 후 MySQL 쿼리
    """

    def __init__(
        self,
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
        use_mock: bool = False,
    ):
        """초기화.

        Args:
            secret_id: AWS Secrets Manager secret ID (DB credentials)
            db: 데이터베이스 이름
            use_mock: Mock 모드 사용 여부
        """
        self.secret_id = secret_id or os.getenv("PROJECT_CODE_SECRET_ID")
        self.db = db or os.getenv("PROJECT_CODE_DB_NAME")
        self.use_mock = use_mock or os.getenv("STATS_PROVIDER", "").lower() == "mock"
        self._connection = None

        logger.info(f"ProjectCodeProvider initialized: mock={self.use_mock}")

    def list_project_codes(
        self,
        active_only: bool = True,
        project_type: Optional[str] = None,
    ) -> List[str]:
        """활성 project_cd 목록 반환.

        Args:
            active_only: 활성 프로젝트만 조회 (기본 True)
            project_type: 프로젝트 타입 필터 (선택)

        Returns:
            project_cd 목록
        """
        if self.use_mock:
            return self._mock_project_codes(active_only, project_type)

        try:
            connection = self._get_connection()
            with connection.cursor() as cursor:
                sql = "SELECT DISTINCT project_cd FROM projects WHERE 1=1"
                params = []

                if active_only:
                    sql += " AND status = 'ACTIVE'"

                if project_type:
                    sql += " AND project_type = %s"
                    params.append(project_type)

                sql += " ORDER BY project_cd"

                cursor.execute(sql, params)
                results = cursor.fetchall()

                return [row["project_cd"] for row in results]

        except Exception as e:
            logger.error(f"Failed to list project codes: {e}")
            return []

    def get_project_info(self, project_cd: str) -> Optional[Dict[str, Any]]:
        """프로젝트 상세 정보 조회.

        Args:
            project_cd: 프로젝트 코드

        Returns:
            프로젝트 정보 딕셔너리 또는 None
        """
        if self.use_mock:
            return self._mock_project_info(project_cd)

        try:
            connection = self._get_connection()
            with connection.cursor() as cursor:
                sql = """
                    SELECT project_cd, project_name, project_type,
                           status, owner, created_at, updated_at
                    FROM projects
                    WHERE project_cd = %s
                """
                cursor.execute(sql, (project_cd,))
                result = cursor.fetchone()

                if result:
                    return dict(result)
                return None

        except Exception as e:
            logger.error(f"Failed to get project info for {project_cd}: {e}")
            return None

    def _get_connection(self):
        """MySQL 연결 획득."""
        if self._connection is None or not self._connection.open:
            import pymysql

            # Secrets Manager에서 credentials 조회
            credentials = self._get_db_credentials()

            self._connection = pymysql.connect(
                host=credentials["host"],
                port=int(credentials.get("port", 3306)),
                user=credentials["username"],
                password=credentials["password"],
                database=self.db,
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor,
                connect_timeout=5,
                read_timeout=30,
            )

        return self._connection

    def _get_db_credentials(self) -> Dict[str, str]:
        """Secrets Manager에서 DB credentials 조회."""
        from bdp_common.aws_session import get_boto3_client

        client = get_boto3_client("secretsmanager")
        response = client.get_secret_value(SecretId=self.secret_id)

        if "SecretString" in response:
            return json.loads(response["SecretString"])
        else:
            raise ValueError("SecretString not found in secret")

    def close(self):
        """연결 종료."""
        if self._connection:
            self._connection.close()
            self._connection = None

    def _mock_project_codes(
        self,
        active_only: bool,
        project_type: Optional[str],
    ) -> List[str]:
        """Mock project_cd 목록."""
        mock_projects = [
            {"project_cd": "ABC001", "status": "ACTIVE", "type": "ETL"},
            {"project_cd": "ABC002", "status": "ACTIVE", "type": "ML"},
            {"project_cd": "DEF001", "status": "ACTIVE", "type": "ETL"},
            {"project_cd": "DEF002", "status": "INACTIVE", "type": "ETL"},
            {"project_cd": "GHI001", "status": "ACTIVE", "type": "ANALYTICS"},
        ]

        results = mock_projects
        if active_only:
            results = [p for p in results if p["status"] == "ACTIVE"]
        if project_type:
            results = [p for p in results if p["type"] == project_type]

        return [p["project_cd"] for p in results]

    def _mock_project_info(self, project_cd: str) -> Optional[Dict[str, Any]]:
        """Mock 프로젝트 정보."""
        mock_data = {
            "ABC001": {
                "project_cd": "ABC001",
                "project_name": "Mock ETL Project 1",
                "project_type": "ETL",
                "status": "ACTIVE",
                "owner": "team-a@example.com",
                "created_at": "2023-01-01",
                "updated_at": "2024-01-15",
            },
            "ABC002": {
                "project_cd": "ABC002",
                "project_name": "Mock ML Project",
                "project_type": "ML",
                "status": "ACTIVE",
                "owner": "team-ml@example.com",
                "created_at": "2023-06-01",
                "updated_at": "2024-01-10",
            },
        }
        return mock_data.get(project_cd)
