"""ADW Dashboard agent router - GCP ADW 인프라 + 서비스 메트릭."""

import logging
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query

from src.common.timezone import KST

logger = logging.getLogger(__name__)

AGENT_NAME = "adw_dashboard"

router = APIRouter()

# Lazy singleton with DB settings
_adw_metrics_service = None


def _get_adw_settings() -> dict:
    """DB에서 ADW 설정 읽기. 실패 시 환경변수 fallback."""
    import os

    try:
        from src.portal.config import get_portal_settings
        from src.portal.services.db import PortalDB

        db = PortalDB(get_portal_settings())
        return {
            "project_id": db.get_setting("adw_project_id") or os.getenv("GCP_PROJECT_ID"),
            "bq_location": db.get_setting("adw_bq_location") or os.getenv("BQ_LOCATION", "US"),
        }
    except Exception:
        return {
            "project_id": os.getenv("GCP_PROJECT_ID"),
            "bq_location": os.getenv("BQ_LOCATION", "US"),
        }


def _get_adw_metrics_service():
    global _adw_metrics_service
    if _adw_metrics_service is None:
        from src.agent_server.adw_dashboard.providers import create_adw_providers
        from src.agent_server.adw_dashboard.services.adw_metrics_service import AdwMetricsService

        settings = _get_adw_settings()
        providers = create_adw_providers(**settings)
        _adw_metrics_service = AdwMetricsService(providers)
    return _adw_metrics_service


# ── BigQuery Metrics ─────────────────────────────────


@router.get("/infra/metrics/bq-slot-utilization")
async def get_bq_slot_utilization(days: int = Query(31, ge=1, le=365)):
    """BigQuery 슬롯 사용률 (900슬롯 기준)."""
    try:
        return _get_adw_metrics_service().get_bq_slot_utilization(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-slot-utilization error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-query-performance")
async def get_bq_query_performance(days: int = Query(31, ge=1, le=365)):
    """BigQuery 쿼리 성능 (동시쿼리, 실행시간, 스캔량)."""
    try:
        return _get_adw_metrics_service().get_bq_query_performance(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-query-performance error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-job-history")
async def get_bq_job_history(days: int = Query(31, ge=1, le=365)):
    """BigQuery 잡 이력 (완료/실패/실행중)."""
    try:
        return _get_adw_metrics_service().get_bq_job_history(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-job-history error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-dataset-storage")
async def get_bq_dataset_storage(days: int = Query(31, ge=1, le=365)):
    """BigQuery 데이터셋별 저장소 현황."""
    try:
        return _get_adw_metrics_service().get_bq_dataset_storage(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-dataset-storage error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-cost-analysis")
async def get_bq_cost_analysis(days: int = Query(31, ge=1, le=365)):
    """BigQuery 비용 분석 (고정슬롯 vs 온디맨드)."""
    try:
        return _get_adw_metrics_service().get_bq_cost_analysis(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-cost-analysis error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-slot-timeline")
async def get_bq_slot_timeline(hours: int = Query(24, ge=1, le=168)):
    """BigQuery 슬롯 타임라인 (시간대별 Job 현황)."""
    try:
        return _get_adw_metrics_service().get_bq_slot_timeline(hours=hours)
    except Exception as e:
        logger.exception("adw metrics bq-slot-timeline error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bq-reservation-utilization")
async def get_bq_reservation_utilization(days: int = Query(31, ge=1, le=365)):
    """BigQuery 팀별 예약 슬롯 사용률."""
    try:
        return _get_adw_metrics_service().get_bq_reservation_utilization(days=days)
    except Exception as e:
        logger.exception("adw metrics bq-reservation-utilization error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Metrics ─────────────────────────────────


@router.get("/infra/metrics/composer-dag-stats")
async def get_composer_dag_stats(days: int = Query(31, ge=1, le=365)):
    """Cloud Composer DAG 실행 통계."""
    try:
        return _get_adw_metrics_service().get_composer_dag_stats(days=days)
    except Exception as e:
        logger.exception("adw metrics composer-dag-stats error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/composer-environment")
async def get_composer_environment(days: int = Query(31, ge=1, le=365)):
    """Cloud Composer 환경 상태."""
    try:
        return _get_adw_metrics_service().get_composer_environment(days=days)
    except Exception as e:
        logger.exception("adw metrics composer-environment error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/composer-task-metrics")
async def get_composer_task_metrics(days: int = Query(31, ge=1, le=365)):
    """Cloud Composer 태스크 메트릭."""
    try:
        return _get_adw_metrics_service().get_composer_task_metrics(days=days)
    except Exception as e:
        logger.exception("adw metrics composer-task-metrics error")
        raise HTTPException(status_code=500, detail=str(e))


# ── GCS Metrics ──────────────────────────────────────


@router.get("/infra/metrics/gcs-bucket-storage")
async def get_gcs_bucket_storage(days: int = Query(31, ge=1, le=365)):
    """GCS 버킷별 저장소 현황."""
    try:
        return _get_adw_metrics_service().get_gcs_bucket_storage(days=days)
    except Exception as e:
        logger.exception("adw metrics gcs-bucket-storage error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/gcs-access-patterns")
async def get_gcs_access_patterns(days: int = Query(31, ge=1, le=365)):
    """GCS 버킷별 접근 패턴 (읽기/쓰기)."""
    try:
        return _get_adw_metrics_service().get_gcs_access_patterns(days=days)
    except Exception as e:
        logger.exception("adw metrics gcs-access-patterns error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/gcs-storage-classes")
async def get_gcs_storage_classes(days: int = Query(31, ge=1, le=365)):
    """GCS 스토리지 클래스 분포."""
    try:
        return _get_adw_metrics_service().get_gcs_storage_classes(days=days)
    except Exception as e:
        logger.exception("adw metrics gcs-storage-classes error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Bastion Metrics ──────────────────────────────────


@router.get("/infra/metrics/bastion-status")
async def get_bastion_status(days: int = Query(31, ge=1, le=365)):
    """Bastion Host 접속 상태."""
    try:
        return _get_adw_metrics_service().get_bastion_status(days=days)
    except Exception as e:
        logger.exception("adw metrics bastion-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bastion-sessions")
async def get_bastion_sessions(days: int = Query(31, ge=1, le=365)):
    """Bastion Host 세션 메트릭."""
    try:
        return _get_adw_metrics_service().get_bastion_sessions(days=days)
    except Exception as e:
        logger.exception("adw metrics bastion-sessions error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/bastion-resources")
async def get_bastion_resources(days: int = Query(31, ge=1, le=365)):
    """Bastion Host 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_bastion_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics bastion-resources error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: Scheduler ────────────────────


@router.get("/infra/metrics/scheduler-resources")
async def get_scheduler_resources(days: int = Query(31, ge=1, le=365)):
    """Composer Scheduler Pod 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_scheduler_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics scheduler-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/scheduler-heartbeat")
async def get_scheduler_heartbeat(days: int = Query(31, ge=1, le=365)):
    """Composer Scheduler Heartbeat 상태."""
    try:
        return _get_adw_metrics_service().get_scheduler_heartbeat(days=days)
    except Exception as e:
        logger.exception("adw metrics scheduler-heartbeat error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: DAG Processor ────────────────


@router.get("/infra/metrics/dagprocessor-resources")
async def get_dagprocessor_resources(days: int = Query(31, ge=1, le=365)):
    """Composer DAG Processor 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_dagprocessor_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics dagprocessor-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/dagprocessor-parsing")
async def get_dagprocessor_parsing(days: int = Query(31, ge=1, le=365)):
    """Composer DAG 파싱 메트릭."""
    try:
        return _get_adw_metrics_service().get_dagprocessor_parsing(days=days)
    except Exception as e:
        logger.exception("adw metrics dagprocessor-parsing error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: Worker Pool ──────────────────


@router.get("/infra/metrics/worker-pool-status")
async def get_worker_pool_status(days: int = Query(31, ge=1, le=365)):
    """Composer Worker Pool 상태 (오토스케일링)."""
    try:
        return _get_adw_metrics_service().get_worker_pool_status(days=days)
    except Exception as e:
        logger.exception("adw metrics worker-pool-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/worker-resources")
async def get_worker_resources(days: int = Query(31, ge=1, le=365)):
    """Composer Worker 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_worker_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics worker-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/worker-task-execution")
async def get_worker_task_execution(days: int = Query(31, ge=1, le=365)):
    """Composer Worker 태스크 실행 메트릭."""
    try:
        return _get_adw_metrics_service().get_worker_task_execution(days=days)
    except Exception as e:
        logger.exception("adw metrics worker-task-execution error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: Triggerer ────────────────────


@router.get("/infra/metrics/triggerer-resources")
async def get_triggerer_resources(days: int = Query(31, ge=1, le=365)):
    """Composer Triggerer 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_triggerer_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics triggerer-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/triggerer-stats")
async def get_triggerer_stats(days: int = Query(31, ge=1, le=365)):
    """Composer Triggerer 트리거 통계."""
    try:
        return _get_adw_metrics_service().get_triggerer_stats(days=days)
    except Exception as e:
        logger.exception("adw metrics triggerer-stats error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: WebServer ────────────────────


@router.get("/infra/metrics/webserver-resources")
async def get_webserver_resources(days: int = Query(31, ge=1, le=365)):
    """Composer WebServer 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_webserver_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics webserver-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/webserver-requests")
async def get_webserver_requests(days: int = Query(31, ge=1, le=365)):
    """Composer WebServer 요청 메트릭."""
    try:
        return _get_adw_metrics_service().get_webserver_requests(days=days)
    except Exception as e:
        logger.exception("adw metrics webserver-requests error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: Cloud SQL ────────────────────


@router.get("/infra/metrics/cloudsql-resources")
async def get_cloudsql_resources(days: int = Query(31, ge=1, le=365)):
    """Composer Cloud SQL 리소스 사용량."""
    try:
        return _get_adw_metrics_service().get_cloudsql_resources(days=days)
    except Exception as e:
        logger.exception("adw metrics cloudsql-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/cloudsql-health")
async def get_cloudsql_health(days: int = Query(31, ge=1, le=365)):
    """Composer Cloud SQL DB Health."""
    try:
        return _get_adw_metrics_service().get_cloudsql_health(days=days)
    except Exception as e:
        logger.exception("adw metrics cloudsql-health error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Composer Infra: GCS ──────────────────────────


@router.get("/infra/metrics/gcs-dag-bucket")
async def get_gcs_dag_bucket(days: int = Query(31, ge=1, le=365)):
    """Composer DAG 버킷 용량."""
    try:
        return _get_adw_metrics_service().get_gcs_dag_bucket(days=days)
    except Exception as e:
        logger.exception("adw metrics gcs-dag-bucket error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/gcs-backup-bucket")
async def get_gcs_backup_bucket(days: int = Query(31, ge=1, le=365)):
    """Composer Backup 버킷 용량."""
    try:
        return _get_adw_metrics_service().get_gcs_backup_bucket(days=days)
    except Exception as e:
        logger.exception("adw metrics gcs-backup-bucket error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/composer-overview-health")
async def get_composer_overview_health(days: int = Query(31, ge=1, le=365)):
    """Composer 환경/Scheduler/WebServer/DB health 통합 Overview."""
    try:
        return _get_adw_metrics_service().get_composer_overview_health(days=days)
    except Exception as e:
        logger.exception("adw metrics composer-overview-health error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/composer-dag-statistics")
async def get_composer_dag_statistics(days: int = Query(31, ge=1, le=365)):
    """Composer DAG 실행 통계."""
    try:
        return _get_adw_metrics_service().get_composer_dag_statistics(days=days)
    except Exception as e:
        logger.exception("adw metrics composer-dag-statistics error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Report Data Helpers ──────────────────────────────


_ADW_CATEGORY_DATA_MAP: dict[str, str] = {
    "bigquery": "bigquery",
    "composer": "composer",
    "gcs": "gcs",
    "bastion": "bastion",
}


def _generate_adw_infra_report_html(days: int) -> str:
    from src.agent_server.adw_dashboard.services.infra_report_generator import (
        AdwInfraReportGenerator,
    )
    from src.agent_server.adw_dashboard.services.report_data import AdwInfraReportData

    svc = _get_adw_metrics_service()

    def _safe(fn, **kwargs):
        try:
            return fn(**kwargs)
        except Exception as e:
            logger.warning(f"Failed to fetch {fn.__name__} for export: {e}")
            return {}

    data = AdwInfraReportData(
        bq_slot_utilization=_safe(svc.get_bq_slot_utilization, days=days),
        bq_query_performance=_safe(svc.get_bq_query_performance, days=days),
        bq_job_history=_safe(svc.get_bq_job_history, days=days),
        bq_dataset_storage=_safe(svc.get_bq_dataset_storage, days=days),
        bq_cost_analysis=_safe(svc.get_bq_cost_analysis, days=days),
        bq_reservation_utilization=_safe(svc.get_bq_reservation_utilization, days=days),
        composer_dag_stats=_safe(svc.get_composer_dag_stats, days=days),
        composer_environment=_safe(svc.get_composer_environment, days=days),
        composer_task_metrics=_safe(svc.get_composer_task_metrics, days=days),
        gcs_bucket_storage=_safe(svc.get_gcs_bucket_storage, days=days),
        gcs_access_patterns=_safe(svc.get_gcs_access_patterns, days=days),
        gcs_storage_classes=_safe(svc.get_gcs_storage_classes, days=days),
        bastion_status=_safe(svc.get_bastion_status, days=days),
        bastion_sessions=_safe(svc.get_bastion_sessions, days=days),
        bastion_resources=_safe(svc.get_bastion_resources, days=days),
    )
    return AdwInfraReportGenerator().generate_report(data)


def _generate_adw_service_report_html(days: int, category: str | None = None) -> str:
    from src.agent_server.adw_dashboard.services.report_data import AdwServiceReportData
    from src.agent_server.adw_dashboard.services.service_report_generator import (
        AdwServiceReportGenerator,
    )

    svc = _get_adw_metrics_service()

    def _safe(fn, **kwargs):
        try:
            return fn(**kwargs)
        except Exception as e:
            logger.warning(f"Failed to fetch {fn.__name__} for export: {e}")
            return {}

    # 카테고리가 지정되면 해당 메트릭만 수집
    need = _ADW_CATEGORY_DATA_MAP.get(category) if category else None

    data = AdwServiceReportData(
        bq_slot_utilization=_safe(svc.get_bq_slot_utilization, days=days)
        if not need or need == "bigquery"
        else {},
        bq_cost_analysis=_safe(svc.get_bq_cost_analysis, days=days)
        if not need or need == "bigquery"
        else {},
        bq_reservation_utilization=_safe(svc.get_bq_reservation_utilization, days=days)
        if not need or need == "bigquery"
        else {},
        composer_dag_stats=_safe(svc.get_composer_dag_stats, days=days)
        if not need or need == "composer"
        else {},
        gcs_access_patterns=_safe(svc.get_gcs_access_patterns, days=days)
        if not need or need == "gcs"
        else {},
        bastion_sessions=_safe(svc.get_bastion_sessions, days=days)
        if not need or need == "bastion"
        else {},
    )
    return AdwServiceReportGenerator(category=category).generate_report(data)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/infra-report")
async def export_infra_report(
    days: int = Query(31, ge=1, le=365),
):
    """ADW 인프라 현황 HTML 리포트 (라이브 데이터)."""
    from fastapi.responses import HTMLResponse

    try:
        html = _generate_adw_infra_report_html(days)
        today = datetime.now(KST).strftime("%Y-%m-%d")
        return HTMLResponse(
            content=html,
            headers={
                "Content-Disposition": f'attachment; filename="adw-infra-report-{today}.html"'
            },
        )
    except Exception as e:
        logger.exception("export adw infra-report error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/service-report")
async def export_service_report(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
):
    """ADW 서비스 현황 HTML 리포트 (라이브 데이터)."""
    from fastapi.responses import HTMLResponse

    try:
        html = _generate_adw_service_report_html(days, category)
        today = datetime.now(KST).strftime("%Y-%m-%d")
        cat_suffix = f"-{category}" if category else ""
        return HTMLResponse(
            content=html,
            headers={
                "Content-Disposition": f'attachment; filename="adw-service-report{cat_suffix}-{today}.html"'
            },
        )
    except Exception as e:
        logger.exception("export adw service-report error")
        raise HTTPException(status_code=500, detail=str(e))


# ── PDF Export ──────────────────────────────────────


def _build_adw_infra_pdf(days: int) -> tuple[bytes, str]:
    """ADW 인프라 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_adw_infra_report_html(days)
    pdf_bytes = html_to_pdf(html)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    filename = f"adw-infra-report-{today}.pdf"
    return pdf_bytes, filename


def _build_adw_service_pdf(days: int, category: str | None) -> tuple[bytes, str]:
    """ADW 서비스 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_adw_service_report_html(days, category)
    pdf_bytes = html_to_pdf(html)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    cat_suffix = f"-{category}" if category else ""
    filename = f"adw-service-report{cat_suffix}-{today}.pdf"
    return pdf_bytes, filename


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf(
    days: int = Query(31, ge=1, le=365),
):
    """ADW 인프라 현황 PDF 리포트 (라이브 데이터)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(_build_adw_infra_pdf, days)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export adw infra-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
):
    """ADW 서비스 현황 PDF 리포트 (라이브 데이터)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(_build_adw_service_pdf, days, category)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export adw service-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))
