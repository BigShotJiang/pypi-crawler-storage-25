"""BDP Metrics agent router."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

AGENT_NAME = "bdp_metrics"

router = APIRouter()

# Lazy singleton — handler is heavyweight (fetcher init)
_handler = None


def _get_handler():  # type: ignore[return]
    global _handler
    if _handler is None:
        from src.agent_server.bdp_metrics.bdp_metrics.handler import BDPMetricsHandler

        _handler = BDPMetricsHandler()
    return _handler


class InvokeRequest(BaseModel):
    """Invoke payload for metrics drift detection."""

    action: str = Field(default="detect", description="detect | update_baselines | daily_report | e2e")
    resource_types: List[str] = Field(default=["subnet-ip"])
    resource_ids: Optional[List[str]] = None
    publish_alerts: bool = Field(default=True)
    send_kakao: bool = Field(default=False)
    duration_hours: int = Field(default=168, description="Baseline period (hours)")
    output_dir: Optional[str] = Field(default=None, description="리포트 저장 경로 (daily_report, e2e)")


@router.post("/invoke")
async def invoke(request: InvokeRequest) -> Dict[str, Any]:
    """Invoke the BDP Metrics handler."""
    try:
        handler = _get_handler()
        result = handler.process(request.model_dump(exclude_none=True))
        return result
    except Exception as e:
        logger.exception("bdp_metrics invoke error")
        raise HTTPException(status_code=500, detail=str(e))
