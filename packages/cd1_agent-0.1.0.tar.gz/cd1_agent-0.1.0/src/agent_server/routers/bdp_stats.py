"""BDP Stats agent router."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

AGENT_NAME = "bdp_stats"

router = APIRouter()

# Lazy singleton
_handler = None


def _get_handler():  # type: ignore[return]
    global _handler
    if _handler is None:
        from src.agent_server.bdp_stats.bdp_stats.handler import BDPStatsHandler

        _handler = BDPStatsHandler()
    return _handler


class InvokeRequest(BaseModel):
    """Invoke payload for stats drift detection."""

    action: str = Field(default="detect")
    stats_types: List[str] = Field(
        default=["sagemaker-pipeline", "emr-cluster", "emr-serverless", "athena-query"]
    )
    project_codes: Optional[List[str]] = None
    days: int = Field(default=7, ge=1, le=90)
    publish_alerts: bool = Field(default=True)
    send_kakao: bool = Field(default=False)


@router.post("/invoke")
async def invoke(request: InvokeRequest) -> Dict[str, Any]:
    """Invoke the BDP Stats handler."""
    try:
        handler = _get_handler()
        result = handler.process(request.model_dump(exclude_none=True))
        return result
    except Exception as e:
        logger.exception("bdp_stats invoke error")
        raise HTTPException(status_code=500, detail=str(e))
