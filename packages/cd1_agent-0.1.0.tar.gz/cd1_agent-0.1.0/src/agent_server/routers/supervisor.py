"""Supervisor agent router."""

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from src.agent_server.supervisor.handler import SupervisorHandler
from src.common.server.adapter import create_handler_endpoint

logger = logging.getLogger(__name__)

AGENT_NAME = "supervisor"

router = APIRouter()

_endpoint = create_handler_endpoint(SupervisorHandler)


class SupervisorInvokeRequest(BaseModel):
    """Supervisor 호출 요청."""

    action: str = Field(default="correlate", description="correlate | status")
    agent_results: list[dict[str, Any]] = Field(
        default_factory=list,
        description="각 에이전트의 detect 결과 목록",
    )


@router.post("/invoke")
async def invoke(request: SupervisorInvokeRequest) -> dict[str, Any]:
    """Supervisor 에이전트를 호출하여 상관관계 분석 실행."""
    try:
        result = await _endpoint(request.model_dump())
        if isinstance(result, dict) and result.get("success") is False:
            raise HTTPException(status_code=500, detail=result.get("error", "supervisor failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("supervisor invoke error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status")
async def status() -> dict[str, Any]:
    """최근 인시던트 상태 조회."""
    try:
        result = await _endpoint({"action": "status"})
        return result
    except Exception as e:
        logger.exception("supervisor status error")
        raise HTTPException(status_code=500, detail=str(e))
