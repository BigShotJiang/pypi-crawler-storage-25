"""BDP Cost agent router."""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from src.agent_server.bdp_cost.handler import BDPCostHandler
from src.common.server.adapter import create_handler_endpoint

logger = logging.getLogger(__name__)

AGENT_NAME = "bdp_cost"

router = APIRouter()

_detect_endpoint = create_handler_endpoint(BDPCostHandler)


class InvokeRequest(BaseModel):
    """Generic invoke payload — forwarded to the Lambda handler as-is."""

    action: str = Field(default="detect", description="detect | compare | daily_report | e2e")
    days: int = Field(default=14, ge=7, le=90)
    min_cost_threshold: float = Field(default=10000, ge=0)
    publish_alerts: bool = Field(default=True)
    output_dir: Optional[str] = Field(default=None, description="리포트 저장 경로 (daily_report, e2e)")


@router.post("/invoke")
async def invoke(request: InvokeRequest) -> Dict[str, Any]:
    """Invoke the BDP Cost detection handler."""
    try:
        result = await _detect_endpoint(request.model_dump())
        if isinstance(result, dict) and result.get("success") is False:
            raise HTTPException(status_code=500, detail=result.get("error", "detection failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("bdp_cost invoke error")
        raise HTTPException(status_code=500, detail=str(e))
