"""Router auto-discovery for agent endpoints."""

import importlib
import logging
import pkgutil
from typing import List, Tuple

from fastapi import APIRouter

logger = logging.getLogger(__name__)


def discover_routers() -> List[Tuple[str, APIRouter]]:
    """Scan this package for modules exporting AGENT_NAME and router.

    Returns:
        List of (agent_name, router) tuples.
    """
    routers: List[Tuple[str, APIRouter]] = []
    package = importlib.import_module(__package__)  # type: ignore[arg-type]

    for info in pkgutil.iter_modules(package.__path__):
        if info.name.startswith("_"):
            continue
        try:
            mod = importlib.import_module(f"{__package__}.{info.name}")
            agent_name = getattr(mod, "AGENT_NAME", None)
            router = getattr(mod, "router", None)
            if agent_name and isinstance(router, APIRouter):
                routers.append((agent_name, router))
                logger.info(f"Discovered agent router: {agent_name}")
            else:
                logger.warning(f"Skipping {info.name}: missing AGENT_NAME or router")
        except Exception:
            logger.exception(f"Failed to load router module: {info.name}")

    return routers
