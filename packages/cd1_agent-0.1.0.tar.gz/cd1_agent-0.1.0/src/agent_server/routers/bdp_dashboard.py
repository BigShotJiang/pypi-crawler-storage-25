"""BDP Dashboard agent router - 인프라 현황 및 Airflow 통계."""

import logging
import os
import tempfile
import threading
import time
import uuid
from datetime import datetime

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from src.agent_server.bdp_common.chart_utils import (
    flatten_series_to_chart,
)
from src.common.timezone import KST

logger = logging.getLogger(__name__)


# ── Async Export Job ──────────────────────────────────


_EXPORT_JOBS_DIR = os.path.join(tempfile.gettempdir(), "cd1_export_jobs")
_EXPORT_TTL = 1800  # 30분 후 자동 정리

os.makedirs(_EXPORT_JOBS_DIR, exist_ok=True)


def _job_meta_path(job_id: str) -> str:
    return os.path.join(_EXPORT_JOBS_DIR, f"{job_id}.json")


def _save_job_meta(meta: dict):
    """job 메타데이터를 JSON 파일로 원자적 저장 (멀티 워커 안전)."""
    import json

    path = _job_meta_path(meta["job_id"])
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(meta, f)
    os.replace(tmp, path)  # 원자적 교체


def _load_job_meta(job_id: str) -> dict | None:
    """job 메타데이터 로드. 없으면 None."""
    import json

    path = _job_meta_path(job_id)
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def _run_export_job(job_id: str, media_type: str, generate_fn):
    """백그라운드 스레드에서 리포트 생성 후 임시 파일에 저장."""
    _save_job_meta(
        {
            "job_id": job_id,
            "status": "running",
            "media_type": media_type,
            "file_path": None,
            "filename": "",
            "error": None,
            "created_at": time.time(),
        }
    )
    try:
        result = generate_fn()
        # 모든 generator는 (content, filename) tuple 반환
        if isinstance(result, tuple):
            content, filename = result
        else:
            content = result
            filename = f"report-{job_id}"
        suffix = ".pdf" if media_type == "application/pdf" else ".html"
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=suffix, prefix="cd1_export_", dir=_EXPORT_JOBS_DIR
        ) as f:
            f.write(content if isinstance(content, bytes) else content.encode("utf-8"))
            file_path = f.name
        _save_job_meta(
            {
                "job_id": job_id,
                "status": "ready",
                "media_type": media_type,
                "file_path": file_path,
                "filename": filename,
                "error": None,
                "created_at": time.time(),
            }
        )
    except Exception as e:
        logger.exception("Export job %s failed", job_id)
        _save_job_meta(
            {
                "job_id": job_id,
                "status": "error",
                "media_type": media_type,
                "file_path": None,
                "filename": "",
                "error": str(e),
                "created_at": time.time(),
            }
        )


def _cleanup_expired_jobs():
    """TTL 초과 job 파일 정리."""
    import json

    now = time.time()
    try:
        for fname in os.listdir(_EXPORT_JOBS_DIR):
            if not fname.endswith(".json"):
                continue
            path = os.path.join(_EXPORT_JOBS_DIR, fname)
            try:
                with open(path) as f:
                    meta = json.load(f)
                if now - meta.get("created_at", 0) > _EXPORT_TTL:
                    # 결과 파일 삭제
                    if meta.get("file_path"):
                        try:
                            os.unlink(meta["file_path"])
                        except OSError:
                            pass
                    os.unlink(path)
            except (json.JSONDecodeError, OSError):
                pass
    except OSError:
        pass


AGENT_NAME = "bdp_dashboard"

router = APIRouter()

# Lazy singletons
_infra_service = None
_airflow_stats_service = None
_infra_metrics_service = None
_infra_log_service = None
_cost_status_service = None
_detection_service = None


def _get_detection_service():
    global _detection_service
    if _detection_service is None:
        from src.agent_server.bdp_dashboard.services.detection_service import (
            BdpDashboardDetectionService,
        )

        _detection_service = BdpDashboardDetectionService(_get_infra_metrics_service())
    return _detection_service


def _get_infra_service():
    global _infra_service
    if _infra_service is None:
        from src.agent_server.bdp_dashboard.services.infra_service import InfraService
        from src.portal.config import PortalSettings

        _infra_service = InfraService(PortalSettings())
    return _infra_service


def _create_metric_cache():
    """Settings에서 VM 설정을 읽어 MetricCacheStore 생성."""
    try:
        from src.portal.services.settings_service import SettingsService

        svc = SettingsService()
        vm_enabled = svc.get_override("vm_enabled") or os.getenv("VM_ENABLED", "false")
        if vm_enabled != "true":
            return None

        vm_url = svc.get_override("vm_url") or os.getenv("VM_URL", "")
        vm_token = svc.get_override("vm_auth_token") or os.getenv("VM_AUTH_TOKEN", "")
        if not vm_url:
            return None

        # MetricCacheStore가 os.getenv로 읽으므로 환경변수 세팅
        os.environ.setdefault("VM_URL", vm_url)
        if vm_token:
            os.environ.setdefault("VM_AUTH_TOKEN", vm_token)

        from src.agent_server.bdp_common.stores.metric_cache import MetricCacheStore

        return MetricCacheStore(provider="victoria_metrics")
    except Exception:
        logger.warning("VM 캐시 초기화 실패, 캐시 없이 진행", exc_info=True)
        return None


def _create_log_cache():
    """Settings에서 VL 설정을 읽어 LogCacheStore 생성."""
    try:
        from src.portal.services.settings_service import SettingsService

        svc = SettingsService()
        vl_enabled = svc.get_override("vl_enabled") or os.getenv("VL_ENABLED", "false")
        if vl_enabled != "true":
            return None

        vl_url = svc.get_override("vl_url") or os.getenv("VL_URL", "")
        vl_token = svc.get_override("vl_auth_token") or os.getenv("VL_AUTH_TOKEN", "")
        if not vl_url:
            return None

        os.environ.setdefault("VL_URL", vl_url)
        if vl_token:
            os.environ.setdefault("VL_AUTH_TOKEN", vl_token)

        from src.agent_server.bdp_common.stores.log_cache import LogCacheStore

        return LogCacheStore(provider="victoria_logs")
    except Exception:
        logger.warning("VL 캐시 초기화 실패, 캐시 없이 진행", exc_info=True)
        return None


def _get_infra_metrics_service():
    global _infra_metrics_service
    if _infra_metrics_service is None:
        from src.agent_server.bdp_dashboard.services.infra_metrics_service import (
            InfraMetricsService,
        )
        from src.portal.config import PortalSettings

        _infra_metrics_service = InfraMetricsService(
            PortalSettings(), metric_cache=_create_metric_cache()
        )
    return _infra_metrics_service


def _get_infra_log_service():
    global _infra_log_service
    if _infra_log_service is None:
        from src.agent_server.bdp_dashboard.services.infra_log_service import InfraLogService
        from src.portal.config import PortalSettings

        _infra_log_service = InfraLogService(PortalSettings(), log_cache=_create_log_cache())
    return _infra_log_service


def _get_cost_status_service():
    global _cost_status_service
    if _cost_status_service is None:
        from src.agent_server.bdp_cost.services.cost_status_service import CostStatusService

        _cost_status_service = CostStatusService()
    return _cost_status_service


_universe_pipeline_service = None


def _get_universe_pipeline_service():
    global _universe_pipeline_service
    if _universe_pipeline_service is None:
        from src.agent_server.bdp_dashboard.services.universe_pipeline_service import (
            UniversePipelineService,
        )

        _universe_pipeline_service = UniversePipelineService()
    return _universe_pipeline_service


_hdsp_metrics_service = None


def _get_hdsp_metrics_service():
    """HDSP 메트릭 서비스 (universe/sobicare 데이터용)."""
    global _hdsp_metrics_service
    if _hdsp_metrics_service is None:
        from src.agent_server.hdsp_dashboard.providers import create_hdsp_providers
        from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import HdspMetricsService

        providers = create_hdsp_providers()
        _hdsp_metrics_service = HdspMetricsService(providers)
    return _hdsp_metrics_service


def _get_airflow_stats_service():
    global _airflow_stats_service
    if _airflow_stats_service is None:
        from src.agent_server.bdp_dashboard.services.airflow_stats_service import (
            AirflowStatsService,
        )
        from src.portal.config import PortalSettings

        _airflow_stats_service = AirflowStatsService(PortalSettings())
    return _airflow_stats_service


# ── Agent Health ────────────────────────────────────────


@router.get("/health")
async def agent_health():
    """Agent 건강 상태 및 서비스 접근 가능 여부."""
    checks: dict = {}

    # InfraService (AWS 연결)
    try:
        svc = _get_infra_service()
        checks["infra_service"] = {"ok": svc is not None, "detail": "loaded"}
    except Exception as e:
        checks["infra_service"] = {"ok": False, "detail": str(e)}

    # InfraMetricsService
    try:
        msvc = _get_infra_metrics_service()
        checks["metrics_service"] = {"ok": msvc is not None, "detail": "loaded"}
    except Exception as e:
        checks["metrics_service"] = {"ok": False, "detail": str(e)}

    # DetectionService
    try:
        dsvc = _get_detection_service()
        checks["detection_service"] = {"ok": dsvc is not None, "detail": "loaded"}
    except Exception as e:
        checks["detection_service"] = {"ok": False, "detail": str(e)}

    # LLM 연결 (env 기반)
    llm_provider = os.getenv("LLM_PROVIDER", "mock")
    checks["llm"] = {"ok": True, "detail": f"provider={llm_provider}"}

    all_ok = all(c["ok"] for c in checks.values())

    return {
        "status": "ok" if all_ok else "degraded",
        "checks": checks,
        "timestamp": datetime.now(KST).isoformat(),
    }


# ── Universe Pipeline ────────────────────────────────────


@router.get("/universe/pipeline")
async def get_universe_pipeline():
    """Universe 입수/전송 파이프라인 현황 데이터."""
    try:
        svc = _get_universe_pipeline_service()
        return svc.get_pipeline_data()
    except Exception as e:
        logger.exception("bdp_dashboard universe pipeline error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Cost Status ───────────────────────────────────────


@router.get("/cost-status/data")
def get_cost_status_data():
    """AWS 서비스별 비용 현황 대시보드 데이터."""
    try:
        svc = _get_cost_status_service()
        return svc.get_dashboard_data()
    except Exception as e:
        logger.exception("bdp_dashboard cost-status data error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/cost-status/monthly")
def get_cost_status_monthly(year: int = Query(default=None)):
    """연간 월별 비용 데이터."""
    try:
        svc = _get_cost_status_service()
        if year is None:
            year = datetime.now().year
        return svc.get_monthly_cost_data(year)
    except Exception as e:
        logger.exception("bdp_dashboard cost-status monthly error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/cost-status/daily")
def get_cost_status_daily(
    year: int = Query(default=None),
    month: int = Query(default=None),
):
    """해당 월의 일별 비용 데이터."""
    try:
        svc = _get_cost_status_service()
        now = datetime.now()
        if year is None:
            year = now.year
        if month is None:
            month = now.month
        return svc.get_daily_cost_data(year, month)
    except Exception as e:
        logger.exception("bdp_dashboard cost-status daily error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Infra ────────────────────────────────────────────


@router.get("/infra")
def get_infra_data():
    """AWS 인프라 리소스 현황 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_dashboard_data()
    except Exception as e:
        logger.exception("bdp_dashboard infra error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/eks/{cluster_name}/detail")
def get_eks_detail(cluster_name: str):
    """EKS 클러스터 상세 리소스 조회 (nodegroup/node/pod/deployment)."""
    try:
        svc = _get_infra_service()
        return svc.get_eks_detail(cluster_name)
    except Exception as e:
        logger.exception("eks detail error: %s", cluster_name)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/eks/{cluster_name}/pods/{namespace}/{pod_name}/logs")
def get_eks_pod_logs(
    cluster_name: str,
    namespace: str,
    pod_name: str,
    tail_lines: int = Query(200, ge=10, le=1000),
):
    """EKS 클러스터 Pod 로그 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_eks_pod_logs(cluster_name, namespace, pod_name, tail_lines)
    except Exception as e:
        logger.exception("eks pod logs error: %s/%s", namespace, pod_name)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/sagemaker-studio/pipelines")
def get_all_studio_pipelines(
    status: str | None = None,
    search: str | None = None,
    page: int = 1,
    limit: int = 20,
):
    """SageMaker Studio 전체 도메인 파이프라인 실행 이력 검색."""
    try:
        svc = _get_infra_service()
        return svc.get_sagemaker_pipeline_executions(
            status=status,
            search=search,
            page=page,
            limit=limit,
        )
    except Exception as e:
        logger.exception("studio pipelines error: all domains")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/sagemaker-studio/{domain_name}/pipelines")
def get_studio_pipelines(
    domain_name: str,
    status: str | None = None,
    search: str | None = None,
    page: int = 1,
    limit: int = 20,
):
    """SageMaker Studio 파이프라인 실행 이력 검색."""
    try:
        svc = _get_infra_service()
        return svc.get_sagemaker_pipeline_executions(
            domain_name=domain_name,
            status=status,
            search=search,
            page=page,
            limit=limit,
        )
    except Exception as e:
        logger.exception(f"studio pipelines error: {domain_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/rds/{instance_name}/tables")
def get_rds_tables(instance_name: str):
    """RDS 인스턴스의 테이블 목록 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_rds_tables(instance_name)
    except Exception as e:
        logger.exception(f"rds tables error: {instance_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/rds/{instance_name}/tables/{table_name}/schema")
def get_rds_table_schema(instance_name: str, table_name: str):
    """RDS 테이블 스키마 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_rds_table_schema(instance_name, table_name)
    except Exception as e:
        logger.exception(f"rds schema error: {instance_name}/{table_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/s3/{bucket_name}/prefixes")
def get_s3_prefixes(bucket_name: str, prefix: str = Query("", description="Parent prefix path")):
    """S3 버킷의 특정 prefix 하위 디렉토리 목록 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_s3_prefixes(bucket_name, prefix)
    except Exception as e:
        logger.exception(f"s3 prefixes error: {bucket_name}/{prefix}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/glue/{catalog_name}/databases/{database_name}/tables")
def get_glue_tables(catalog_name: str, database_name: str):
    """Glue 카탈로그의 특정 DB 테이블 목록 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_glue_tables(catalog_name, database_name)
    except Exception as e:
        logger.exception(f"glue tables error: {catalog_name}/{database_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/glue/{catalog_name}/databases/{database_name}/tables/{table_name}/schema")
def get_glue_table_schema(catalog_name: str, database_name: str, table_name: str):
    """Glue 테이블 스키마 조회."""
    try:
        svc = _get_infra_service()
        return svc.get_glue_table_schema(catalog_name, database_name, table_name)
    except Exception as e:
        logger.exception(f"glue schema error: {database_name}/{table_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/airflow/daily-rates")
def get_airflow_daily_rates(days: int = Query(31, ge=1, le=365)):
    """환경별 일별 DAG/Task 성공률 조회."""
    try:
        svc = _get_airflow_stats_service()
        return svc.get_daily_rates(days=days)
    except Exception as e:
        logger.exception("bdp_dashboard airflow stats error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Infra Logs ────────────────────────────────────────


@router.get("/infra/logs")
def get_infra_logs(
    service: str = Query(
        ..., description="서비스 키 (mwaa, lambda, eks, rds, sagemaker endpoint 등)"
    ),
    resource_name: str = Query(..., description="리소스 이름"),
    hours: int = Query(1, ge=1, le=24),
    filter_pattern: str | None = Query(None, description="로그 필터 패턴"),
    log_type: str | None = Query(None, description="로그 유형 (scheduler, error 등)"),
    limit: int = Query(200, ge=1, le=1000),
    log_group: str | None = Query(None, description="커스텀 로그 그룹 경로 (설정에서 전달)"),
):
    """CloudWatch 로그 조회."""
    try:
        svc = _get_infra_log_service()
        return svc.get_logs(
            service=service,
            resource_name=resource_name,
            hours=hours,
            filter_pattern=filter_pattern,
            log_type=log_type,
            limit=limit,
            log_group=log_group,
        )
    except Exception as e:
        logger.exception("infra logs error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Infra Metrics ─────────────────────────────────────


@router.get("/infra/metrics/info")
def get_infra_metrics_info():
    """인프라 메트릭 환경 정보 (mock 여부는 각 메트릭 응답의 is_mock 참조)."""
    svc = _get_infra_metrics_service()
    return {"environment": svc.settings.environment}


@router.get("/infra/metrics/msk-lag")
def get_msk_lag(days: int = Query(31, ge=1, le=365)):
    """MSK 클러스터별 Consumer LAG 지수."""
    try:
        return _get_infra_metrics_service().get_msk_lag(days=days)
    except Exception as e:
        logger.exception("infra metrics msk-lag error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/msk-broker-health")
def get_msk_broker_health(days: int = Query(31, ge=1, le=365)):
    """MSK 브로커별 헬스 상태 (CPU, Disk, Network)."""
    try:
        return _get_infra_metrics_service().get_msk_broker_health(days=days)
    except Exception as e:
        logger.exception("infra metrics msk-broker-health error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/s3-size")
def get_s3_size(days: int = Query(31, ge=1, le=365)):
    """S3 버킷별 용량 추이."""
    try:
        data = _get_infra_metrics_service().get_s3_size(days=days)
        data["chart"] = flatten_series_to_chart(data.get("buckets", {}), "size_gb")
        return data
    except Exception as e:
        logger.exception("infra metrics s3-size error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-users")
def get_sagemaker_users(days: int = Query(31, ge=1, le=365)):
    """SageMaker 일별 사용자 접속 현황."""
    try:
        return _get_infra_metrics_service().get_sagemaker_users(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-users error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-endpoint-errors")
def get_sagemaker_endpoint_errors(days: int = Query(31, ge=1, le=365)):
    """SageMaker Endpoint 4xx/5xx 에러 추이."""
    try:
        return _get_infra_metrics_service().get_sagemaker_endpoint_errors(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-endpoint-errors error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-pipeline-failures")
def get_sagemaker_pipeline_failures(days: int = Query(31, ge=1, le=365)):
    """SageMaker Pipeline 일별 실패 현황."""
    try:
        return _get_infra_metrics_service().get_sagemaker_pipeline_failures(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-pipeline-failures error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-notebook-instance-types")
def get_sagemaker_notebook_instance_types(days: int = Query(31, ge=1, le=365)):
    """SageMaker Notebook 인스턴스 타입별 사용 현황."""
    try:
        return _get_infra_metrics_service().get_sagemaker_notebook_instance_types(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-notebook-instance-types error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-pipeline-instance-types")
def get_sagemaker_pipeline_instance_types(days: int = Query(31, ge=1, le=365)):
    """SageMaker Pipeline Job 인스턴스 타입별 사용 현황."""
    try:
        return _get_infra_metrics_service().get_sagemaker_pipeline_instance_types(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-pipeline-instance-types error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/emr-cluster-failures")
def get_emr_cluster_failures(days: int = Query(31, ge=1, le=365)):
    """EMR Cluster 일별 Job 실패 현황."""
    try:
        return _get_infra_metrics_service().get_emr_cluster_failures(days=days)
    except Exception as e:
        logger.exception("infra metrics emr-cluster-failures error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/emr-serverless-failures")
def get_emr_serverless_failures(days: int = Query(31, ge=1, le=365)):
    """EMR Serverless 일별 Job 실패 현황."""
    try:
        return _get_infra_metrics_service().get_emr_serverless_failures(days=days)
    except Exception as e:
        logger.exception("infra metrics emr-serverless-failures error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-endpoint-latency")
def get_sagemaker_endpoint_latency(days: int = Query(31, ge=1, le=365)):
    """SageMaker Endpoint P50/P95/P99 Latency 추이."""
    try:
        return _get_infra_metrics_service().get_sagemaker_endpoint_latency(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-endpoint-latency error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-endpoint-availability")
def get_sagemaker_endpoint_availability(days: int = Query(31, ge=1, le=365)):
    """SageMaker Endpoint 가용률 (%) 추이."""
    try:
        return _get_infra_metrics_service().get_sagemaker_endpoint_availability(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-endpoint-availability error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sagemaker-endpoint-invocations")
def get_sagemaker_endpoint_invocations(days: int = Query(31, ge=1, le=365)):
    """SageMaker Endpoint 일별 호출 건수."""
    try:
        return _get_infra_metrics_service().get_sagemaker_endpoint_invocations(days=days)
    except Exception as e:
        logger.exception("infra metrics sagemaker-endpoint-invocations error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/dag-sla-status")
def get_dag_sla_status(days: int = Query(31, ge=1, le=365)):
    """DAG SLA 달성 현황 (실행시간 + breach 건수)."""
    try:
        return _get_infra_metrics_service().get_dag_sla_status(days=days)
    except Exception as e:
        logger.exception("infra metrics dag-sla-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/dag-interface-rates")
def get_dag_interface_rates(days: int = Query(31, ge=1, le=365)):
    """타 시스템 연계 DAG 카테고리별 일별 성공률."""
    try:
        return _get_infra_metrics_service().get_dag_interface_rates(days=days)
    except Exception as e:
        logger.exception("infra metrics dag-interface-rates error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-node-counts")
def get_mwaa_node_counts(days: int = Query(31, ge=1, le=365)):
    """MWAA 환경별 Scheduler/Worker 노드 수 추이."""
    try:
        return _get_infra_metrics_service().get_mwaa_node_counts(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-node-counts error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-env-updates")
def get_mwaa_env_updates(days: int = Query(31, ge=1, le=365)):
    """MWAA 환경별 업데이트(재시작) 이력 추이."""
    try:
        return _get_infra_metrics_service().get_mwaa_env_updates(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-env-updates error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-dag-import-errors")
def get_mwaa_dag_import_errors(days: int = Query(31, ge=1, le=365)):
    """MWAA 환경별 DAG Import Error 월누적 일별 추이."""
    try:
        return _get_infra_metrics_service().get_mwaa_dag_import_errors(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-dag-import-errors error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-scheduler-resources")
def get_mwaa_scheduler_resources(days: int = Query(31, ge=1, le=365)):
    """MWAA Scheduler CPU%, Heartbeat 상태."""
    try:
        return _get_infra_metrics_service().get_mwaa_scheduler_resources(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-scheduler-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-dagprocessor-parsing")
def get_mwaa_dagprocessor_parsing(days: int = Query(31, ge=1, le=365)):
    """MWAA DAG Processor 파싱시간, DAG수, Import Errors."""
    try:
        return _get_infra_metrics_service().get_mwaa_dagprocessor_parsing(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-dagprocessor-parsing error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-worker-resources")
def get_mwaa_worker_resources(days: int = Query(31, ge=1, le=365)):
    """MWAA Worker CPU%, Active Workers."""
    try:
        return _get_infra_metrics_service().get_mwaa_worker_resources(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-worker-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-worker-task-execution")
def get_mwaa_worker_task_execution(days: int = Query(31, ge=1, le=365)):
    """MWAA Worker 동시 실행/대기 태스크."""
    try:
        return _get_infra_metrics_service().get_mwaa_worker_task_execution(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-worker-task-execution error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-triggerer-resources")
def get_mwaa_triggerer_resources(days: int = Query(31, ge=1, le=365)):
    """MWAA Triggerer CPU%, Active Triggers."""
    try:
        return _get_infra_metrics_service().get_mwaa_triggerer_resources(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-triggerer-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-webserver-resources")
def get_mwaa_webserver_resources(days: int = Query(31, ge=1, le=365)):
    """MWAA WebServer CPU%."""
    try:
        return _get_infra_metrics_service().get_mwaa_webserver_resources(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-webserver-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-database-resources")
def get_mwaa_database_resources(days: int = Query(31, ge=1, le=365)):
    """MWAA Database CPU%, Connections."""
    try:
        return _get_infra_metrics_service().get_mwaa_database_resources(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-database-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-database-health")
def get_mwaa_database_health(days: int = Query(31, ge=1, le=365)):
    """MWAA Database 크기, Health 상태."""
    try:
        return _get_infra_metrics_service().get_mwaa_database_health(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-database-health error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-storage-dag-bucket")
def get_mwaa_storage_dag_bucket(days: int = Query(31, ge=1, le=365)):
    """MWAA S3 DAG 버킷 용량."""
    try:
        return _get_infra_metrics_service().get_mwaa_storage_dag_bucket(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-storage-dag-bucket error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/mwaa-environment-overview")
def get_mwaa_environment_overview(days: int = Query(31, ge=1, le=365)):
    """MWAA 환경 Health, 버전 정보."""
    try:
        return _get_infra_metrics_service().get_mwaa_environment_overview(days=days)
    except Exception as e:
        logger.exception("infra metrics mwaa-environment-overview error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/rds-connections")
def get_rds_connections(days: int = Query(31, ge=1, le=365)):
    """RDS 인스턴스별 DB 커넥션 수."""
    try:
        data = _get_infra_metrics_service().get_rds_connections(days=days)
        data["chart"] = flatten_series_to_chart(data.get("instances", {}), "value")
        return data
    except Exception as e:
        logger.exception("infra metrics rds-connections error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/rds-cpu")
def get_rds_cpu(days: int = Query(31, ge=1, le=365)):
    """RDS 인스턴스별 CPU 사용률."""
    try:
        data = _get_infra_metrics_service().get_rds_cpu(days=days)
        data["chart"] = flatten_series_to_chart(data.get("instances", {}), "value")
        return data
    except Exception as e:
        logger.exception("infra metrics rds-cpu error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/rds-memory")
def get_rds_memory(days: int = Query(31, ge=1, le=365)):
    """RDS 인스턴스별 메모리 현황 (Freeable + Swap)."""
    try:
        return _get_infra_metrics_service().get_rds_memory(days=days)
    except Exception as e:
        logger.exception("infra metrics rds-memory error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/rds-iops")
def get_rds_iops(days: int = Query(31, ge=1, le=365)):
    """RDS 인스턴스별 디스크 I/O (Read/Write IOPS)."""
    try:
        return _get_infra_metrics_service().get_rds_iops(days=days)
    except Exception as e:
        logger.exception("infra metrics rds-iops error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/rds-storage-free")
def get_rds_storage_free(days: int = Query(31, ge=1, le=365)):
    """RDS 인스턴스별 여유 스토리지 (GB)."""
    try:
        data = _get_infra_metrics_service().get_rds_storage_free(days=days)
        data["chart"] = flatten_series_to_chart(data.get("instances", {}), "value")
        return data
    except Exception as e:
        logger.exception("infra metrics rds-storage-free error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/ingestion-rates")
def get_ingestion_rates(days: int = Query(31, ge=1, le=365)):
    """L0/L1 입수 성공/실패 일별 현황."""
    try:
        return _get_infra_metrics_service().get_ingestion_rates(days=days)
    except Exception as e:
        logger.exception("infra metrics ingestion-rates error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/lambda-errors")
def get_lambda_errors(days: int = Query(31, ge=1, le=365)):
    """Lambda 함수별 일일 실패(Errors) 건수."""
    try:
        return _get_infra_metrics_service().get_lambda_errors(days=days)
    except Exception as e:
        logger.exception("infra metrics lambda-errors error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/lambda/{function_name}/invocations")
def get_lambda_invocations(
    function_name: str,
    hours: int = Query(1, ge=1, le=24),
):
    """Lambda 함수별 최근 호출 이력 (성공/실패 목록)."""
    try:
        return _get_infra_metrics_service().get_lambda_invocations(
            function_name=function_name, hours=hours
        )
    except Exception as e:
        logger.exception("lambda invocations error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/glue-table-versions")
def get_glue_table_versions(days: int = Query(31, ge=1, le=365)):
    """Glue 카탈로그 DB별 테이블 메타데이터 버전 변경 추이."""
    try:
        return _get_infra_metrics_service().get_glue_table_versions(days=days)
    except Exception as e:
        logger.exception("infra metrics glue-table-versions error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/athena-top-queries")
def get_athena_top_queries(
    days: int = Query(31, ge=1, le=365),
    workgroup: str | None = Query(None),
):
    """Athena 쿼리 스캔량 Top 10 (워크그룹별, 일별)."""
    try:
        return _get_infra_metrics_service().get_athena_top_queries(days=days, workgroup=workgroup)
    except Exception as e:
        logger.exception("infra metrics athena-top-queries error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/athena-query-history")
def get_athena_query_history(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    workgroup: str | None = Query(None),
    status: str | None = Query(None),
    start_date: str | None = Query(None),
    end_date: str | None = Query(None),
):
    """Athena 쿼리 실행 이력 검색."""
    try:
        return _get_infra_metrics_service().get_athena_query_history(
            page=page,
            limit=limit,
            search=search,
            workgroup=workgroup,
            status=status,
            start_date=start_date,
            end_date=end_date,
        )
    except Exception as e:
        logger.exception("infra metrics athena-query-history error")
        raise HTTPException(status_code=500, detail=str(e))


# ── KPI Data Helpers ──────────────────────────────────

_kpi_service = None


def _get_kpi_service():
    global _kpi_service
    if _kpi_service is None:
        from src.agent_server.bdp_dashboard.services.kpi_service import KpiService
        from src.portal.config import PortalSettings

        _kpi_service = KpiService(PortalSettings())
    return _kpi_service


def _get_kpi_team_success_rates() -> list:
    try:
        return _get_kpi_service().get_team_success_rates()
    except Exception:
        from src.agent_server.bdp_dashboard.services.kpi_mock_data import get_team_success_rates

        return get_team_success_rates()


def _get_kpi_team_task_rates() -> dict:
    try:
        return _get_kpi_service().get_team_task_rates()
    except Exception:
        from src.agent_server.bdp_dashboard.services.kpi_mock_data import get_team_task_rates

        return get_team_task_rates()


@router.get("/infra/kpi-data")
def get_kpi_data():
    """KPI 섹션 데이터 조회 (WFL 월별 성공률 + 팀별 DAG 성공률 + 팀별 Task 현황)."""
    try:
        svc = _get_kpi_service()
        return {
            "wfl_monthly": svc.get_wfl_monthly_rates(),
            "team_success_rates": svc.get_team_success_rates(),
            "team_task_rates": svc.get_team_task_rates(),
            "is_mock": False,
        }
    except Exception:
        logger.warning("KPI real query failed, falling back to mock", exc_info=True)
        from src.agent_server.bdp_dashboard.services.kpi_mock_data import (
            get_team_success_rates,
            get_team_task_rates,
            get_wfl_monthly_rates,
        )

        return {
            "wfl_monthly": get_wfl_monthly_rates(),
            "team_success_rates": get_team_success_rates(),
            "team_task_rates": get_team_task_rates(),
            "is_mock": True,
        }


# ── Report Data Helpers ──────────────────────────────


def _collect_service_report_data(days: int):
    """서비스 현황 리포트용 데이터 수집."""
    from src.agent_server.bdp_dashboard.services.daily_report_generator import (
        DashboardDailyReportData,
    )

    svc = _get_infra_service()
    dash = svc.get_dashboard_data()
    services = dash.get("services", {})

    total_resources = 0
    running = 0
    attention = 0
    domain_keys = {
        "mwaa",
        "msk",
        "sagemaker studio",
        "sagemaker endpoint",
        "emr(cluster)",
        "emr(serverless)",
    }
    active_domains = set()
    for key, resources in services.items():
        if not resources:
            continue
        if key in domain_keys:
            active_domains.add(key)
        total_resources += len(resources)
        for r in resources:
            s = r.get("display_status", "neutral")
            if s == "critical":
                attention += 1
            else:
                running += 1

    # 메트릭 전용 도메인은 항상 활성으로 카운트 (Frontend와 일치)
    active_domains.update({"ingestion", "universe", "sobicare", "kpi", "cost"})

    airflow_svc = _get_airflow_stats_service()
    metrics_svc = _get_infra_metrics_service()

    airflow_rates = {}
    airflow_is_mock = False
    try:
        rates_raw = airflow_svc.get_daily_rates(days=days)
        airflow_is_mock = bool(rates_raw.get("is_mock"))
        for env, env_data in rates_raw.get("environments", {}).items():
            airflow_rates[env] = env_data.get("daily_rates", [])
    except Exception as e:
        logger.warning(f"Failed to fetch airflow rates for export: {e}")

    msk_lag = {}
    msk_lag_is_mock = False
    try:
        msk_raw = metrics_svc.get_msk_lag(days=days)
        msk_lag_is_mock = bool(msk_raw.get("is_mock"))
        msk_lag = msk_raw.get("clusters", {})
    except Exception as e:
        logger.warning(f"Failed to fetch msk lag for export: {e}")

    sagemaker_users = []
    try:
        sm_users_raw = metrics_svc.get_sagemaker_users(days=days)
        sagemaker_users = sm_users_raw.get("studios", [])
    except Exception as e:
        logger.warning(f"Failed to fetch sagemaker users for export: {e}")

    sagemaker_endpoint_errors = {}
    sagemaker_endpoint_is_mock = False
    try:
        sme_raw = metrics_svc.get_sagemaker_endpoint_errors(days=days)
        sagemaker_endpoint_is_mock = bool(sme_raw.get("is_mock"))
        sagemaker_endpoint_errors = sme_raw.get("endpoints", {})
    except Exception as e:
        logger.warning(f"Failed to fetch sagemaker endpoint errors for export: {e}")

    sagemaker_pipeline_failures = {}
    sagemaker_pipeline_is_mock = False
    try:
        smp_raw = metrics_svc.get_sagemaker_pipeline_failures(days=days)
        sagemaker_pipeline_is_mock = bool(smp_raw.get("is_mock"))
        # groups 구조 → 플랫 pipelines 변환 (groups.prj001.pipelines → pipelines)
        groups = smp_raw.get("groups", {})
        for group_data in groups.values():
            if isinstance(group_data, dict):
                sagemaker_pipeline_failures.update(group_data.get("pipelines", {}))
        # fallback: top-level pipelines (구버전 호환)
        if not sagemaker_pipeline_failures:
            sagemaker_pipeline_failures = smp_raw.get("pipelines", {})
    except Exception as e:
        logger.warning(f"Failed to fetch sagemaker pipeline failures for export: {e}")

    emr_cluster_failures = {}
    emr_cluster_is_mock = False
    try:
        emr_raw = metrics_svc.get_emr_cluster_failures(days=days)
        emr_cluster_is_mock = bool(emr_raw.get("is_mock"))
        emr_cluster_failures = emr_raw.get("clusters", {})
    except Exception as e:
        logger.warning(f"Failed to fetch emr cluster failures for export: {e}")

    emr_serverless_failures = {}
    emr_serverless_is_mock = False
    try:
        emrs_raw = metrics_svc.get_emr_serverless_failures(days=days)
        emr_serverless_is_mock = bool(emrs_raw.get("is_mock"))
        emr_serverless_failures = emrs_raw.get("applications", {})
    except Exception as e:
        logger.warning(f"Failed to fetch emr serverless failures for export: {e}")

    dag_sla_status = {}
    dag_sla_is_mock = False
    try:
        dag_sla_raw = metrics_svc.get_dag_sla_status(days=days)
        dag_sla_is_mock = bool(dag_sla_raw.get("is_mock"))
        dag_sla_status = dag_sla_raw.get("environments", {})
    except Exception as e:
        logger.warning(f"Failed to fetch dag sla status for export: {e}")

    # NOTE: notebook_instance_types, pipeline_instance_types, endpoint_latency,
    # endpoint_availability, endpoint_invocations 는 웹 프론트엔드에 해당 차트가
    # 없으므로 PDF 리포트에서도 제외합니다.

    # ── 추가 도메인 메트릭 ─────────────────────────
    ingestion_rates: dict = {}
    ingestion_is_mock: bool = False
    try:
        ingestion_rates = metrics_svc.get_ingestion_rates(days=days)
        ingestion_is_mock = bool(ingestion_rates.get("is_mock"))
    except Exception as e:
        logger.warning(f"Failed to fetch ingestion rates for export: {e}")

    try:
        hdsp_svc = _get_hdsp_metrics_service()
    except Exception as e:
        hdsp_svc = None
        logger.warning(f"Failed to init hdsp metrics service for export: {e}")

    universe_failures: list = []
    universe_is_mock: bool = False
    if hdsp_svc:
        try:
            raw_uni = hdsp_svc.get_universe_failures(days=days)
            universe_failures = raw_uni.get("daily", [])
            universe_is_mock = True  # RealPipelineProvider는 NotImplementedError → 항상 mock 경로
        except Exception as e:
            logger.warning(f"Failed to fetch universe failures for export: {e}")

    sobicare_workflows: dict = {}
    sobicare_is_mock: bool = False
    if hdsp_svc:
        try:
            raw_sobi = hdsp_svc.get_sobicare_workflows(days=days)
            sobicare_workflows = {
                "daily": raw_sobi.get("daily", []),
                "monthly": raw_sobi.get("monthly", []),
            }
            sobicare_is_mock = True  # RealPipelineProvider는 NotImplementedError → 항상 mock 경로
        except Exception as e:
            logger.warning(f"Failed to fetch sobicare workflows for export: {e}")

    # WFL DAG 월별 성공률
    wfl_monthly_rates: list = []
    kpi_is_mock: bool = False
    try:
        wfl_monthly_rates = _get_kpi_service().get_wfl_monthly_rates()
    except Exception:
        try:
            from src.agent_server.bdp_dashboard.services.kpi_mock_data import get_wfl_monthly_rates

            wfl_monthly_rates = get_wfl_monthly_rates()
            kpi_is_mock = True
        except Exception as e:
            logger.warning(f"Failed to fetch wfl monthly rates for export: {e}")

    now = datetime.now()

    cost_monthly: list = []
    cost_budget: dict = {}
    cost_is_mock: bool = False
    try:
        cost_svc = _get_cost_status_service()
        monthly_result = cost_svc.get_monthly_cost_data(now.year)
        cost_monthly = monthly_result.get("months", [])
        cost_budget = monthly_result.get("budget", {})
        cost_is_mock = bool(monthly_result.get("is_mock"))
    except Exception as e:
        logger.warning(f"Failed to fetch monthly cost for export: {e}")

    cost_daily: list = []
    try:
        cost_svc = _get_cost_status_service()
        daily_result = cost_svc.get_daily_cost_data(now.year, now.month)
        cost_daily = daily_result.get("days", [])
        if not cost_budget:
            cost_budget = daily_result.get("budget", {})
        if not cost_is_mock:
            cost_is_mock = bool(daily_result.get("is_mock"))
    except Exception as e:
        logger.warning(f"Failed to fetch daily cost for export: {e}")

    dag_interface_rates: dict = {}
    dag_interface_is_mock = False
    try:
        raw_iface_result = metrics_svc.get_dag_interface_rates(days=days)
        dag_interface_is_mock = bool(raw_iface_result.get("is_mock"))
        raw_iface = raw_iface_result.get("categories", {})
        for cat_name, cat_data in raw_iface.items():
            daily_rates = cat_data.get("daily_rates", []) if isinstance(cat_data, dict) else []
            if daily_rates:
                dag_interface_rates[cat_name] = daily_rates
    except Exception as e:
        logger.warning(f"Failed to fetch dag interface rates for export: {e}")

    return DashboardDailyReportData(
        total_domains=len(active_domains),
        total_resources=total_resources,
        running=running,
        attention=attention,
        services=services,
        airflow_rates=airflow_rates,
        airflow_is_mock=airflow_is_mock,
        dag_sla_is_mock=dag_sla_is_mock,
        dag_interface_is_mock=dag_interface_is_mock,
        msk_lag=msk_lag,
        sagemaker_users=sagemaker_users,
        sagemaker_endpoint_errors=sagemaker_endpoint_errors,
        sagemaker_pipeline_failures=sagemaker_pipeline_failures,
        emr_cluster_failures=emr_cluster_failures,
        emr_serverless_failures=emr_serverless_failures,
        dag_sla_status=dag_sla_status,
        ingestion_rates=ingestion_rates,
        universe_failures=universe_failures,
        sobicare_workflows=sobicare_workflows,
        wfl_monthly_rates=wfl_monthly_rates,
        team_success_rates=_get_kpi_team_success_rates(),
        team_task_rates=_get_kpi_team_task_rates(),
        cost_monthly=cost_monthly,
        cost_daily=cost_daily,
        cost_budget=cost_budget,
        dag_interface_rates=dag_interface_rates,
        msk_lag_is_mock=msk_lag_is_mock,
        sagemaker_pipeline_is_mock=sagemaker_pipeline_is_mock,
        sagemaker_endpoint_is_mock=sagemaker_endpoint_is_mock,
        emr_cluster_is_mock=emr_cluster_is_mock,
        emr_serverless_is_mock=emr_serverless_is_mock,
        universe_is_mock=universe_is_mock,
        sobicare_is_mock=sobicare_is_mock,
        kpi_is_mock=kpi_is_mock,
        cost_is_mock=cost_is_mock,
        ingestion_is_mock=ingestion_is_mock,
        team_success_is_mock=kpi_is_mock,
        team_task_is_mock=kpi_is_mock,
    )


def _collect_infra_report_data(days: int = 31):
    """인프라 현황 리포트용 데이터 수집 (병렬)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from src.agent_server.bdp_dashboard.services.infra_report_generator import InfraReportData

    svc = _get_infra_service()
    dash = svc.get_dashboard_data()
    summary = dash.get("summary", {})
    metrics_svc = _get_infra_metrics_service()

    # 수집할 메트릭 정의: (결과 키, 호출 함수)
    metric_tasks: list[tuple[str, object]] = [
        ("rds_cpu", lambda: metrics_svc.get_rds_cpu(days=days)),
        ("rds_connections", lambda: metrics_svc.get_rds_connections(days=days)),
        ("rds_memory", lambda: metrics_svc.get_rds_memory(days=days)),
        ("rds_iops", lambda: metrics_svc.get_rds_iops(days=days)),
        ("rds_storage_free", lambda: metrics_svc.get_rds_storage_free(days=days)),
        ("s3_size", lambda: metrics_svc.get_s3_size(days=days)),
        ("mwaa_node_counts", lambda: metrics_svc.get_mwaa_node_counts(days=days)),
        ("mwaa_env_updates", lambda: metrics_svc.get_mwaa_env_updates(days=days)),
        ("lambda_errors", lambda: metrics_svc.get_lambda_errors(days=days)),
        ("mwaa_dag_import_errors", lambda: metrics_svc.get_mwaa_dag_import_errors(days=days)),
        ("mwaa_environment_overview", lambda: metrics_svc.get_mwaa_environment_overview(days=days)),
        ("mwaa_scheduler_resources", lambda: metrics_svc.get_mwaa_scheduler_resources(days=days)),
        ("mwaa_dagprocessor_parsing", lambda: metrics_svc.get_mwaa_dagprocessor_parsing(days=days)),
        ("mwaa_worker_resources", lambda: metrics_svc.get_mwaa_worker_resources(days=days)),
        (
            "mwaa_worker_task_execution",
            lambda: metrics_svc.get_mwaa_worker_task_execution(days=days),
        ),
        ("mwaa_triggerer_resources", lambda: metrics_svc.get_mwaa_triggerer_resources(days=days)),
        ("mwaa_webserver_resources", lambda: metrics_svc.get_mwaa_webserver_resources(days=days)),
        ("mwaa_database_resources", lambda: metrics_svc.get_mwaa_database_resources(days=days)),
        ("mwaa_database_health", lambda: metrics_svc.get_mwaa_database_health(days=days)),
        ("mwaa_storage_dag_bucket", lambda: metrics_svc.get_mwaa_storage_dag_bucket(days=days)),
        ("sagemaker_users", lambda: metrics_svc.get_sagemaker_users(days=days)),
        (
            "sagemaker_notebook_instance_types",
            lambda: metrics_svc.get_sagemaker_notebook_instance_types(days=days),
        ),
        (
            "sagemaker_pipeline_instance_types",
            lambda: metrics_svc.get_sagemaker_pipeline_instance_types(days=days),
        ),
        (
            "sagemaker_endpoint_latency",
            lambda: metrics_svc.get_sagemaker_endpoint_latency(days=days),
        ),
        (
            "sagemaker_endpoint_availability",
            lambda: metrics_svc.get_sagemaker_endpoint_availability(days=days),
        ),
        (
            "sagemaker_endpoint_invocations",
            lambda: metrics_svc.get_sagemaker_endpoint_invocations(days=days),
        ),
        ("msk_broker_health", lambda: metrics_svc.get_msk_broker_health(days=days)),
        ("glue_table_versions", lambda: metrics_svc.get_glue_table_versions(days=days)),
        ("athena_top_queries", lambda: metrics_svc.get_athena_top_queries(days=days)),
        ("athena_query_history", lambda: metrics_svc.get_athena_query_history(limit=20)),
        ("sagemaker_pipeline_executions", lambda: svc.get_sagemaker_pipeline_executions(limit=20)),
    ]

    # Universe Pipeline (import 필요)
    def _get_universe_pipeline():
        from src.agent_server.bdp_dashboard.services.universe_pipeline_service import (
            UniversePipelineService,
        )

        return UniversePipelineService().get_pipeline_data()

    metric_tasks.append(("universe_pipeline", _get_universe_pipeline))

    # 병렬 수집 (최대 10 워커)
    results: dict[str, dict] = {}
    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = {pool.submit(fn): key for key, fn in metric_tasks}
        for fut in as_completed(futures):
            key = futures[fut]
            try:
                results[key] = fut.result()
            except Exception:
                logger.warning("Failed to collect %s for infra report", key)
                results[key] = {}

    return InfraReportData(
        total=summary.get("total", 0),
        running=summary.get("running", 0),
        warning=summary.get("warning", 0),
        stopped=summary.get("stopped", 0),
        error=summary.get("error", 0),
        services=dash.get("services", {}),
        errors=dash.get("errors", []),
        **results,
    )


def _generate_service_report_html(
    days: int,
    category: str | None = None,
    include_tables: bool = False,
    use_html_charts: bool = False,
    email_mode: bool = False,
) -> str:
    from src.agent_server.bdp_dashboard.services.daily_report_generator import (
        DashboardDailyReportGenerator,
    )

    data = _collect_service_report_data(days)
    data.skip_mock = os.getenv("ENVIRONMENT", "dev").lower() in ("prd", "prod")
    return DashboardDailyReportGenerator(
        category=category,
        include_tables=include_tables,
        use_html_charts=use_html_charts,
        email_mode=email_mode,
    ).generate_report(data)


def _generate_infra_report_html(
    days: int = 31,
    include_tables: bool = False,
    use_html_charts: bool = False,
    email_mode: bool = False,
) -> str:
    from src.agent_server.bdp_dashboard.services.infra_report_generator import InfraReportGenerator

    data = _collect_infra_report_data(days=days)
    data.skip_mock = os.getenv("ENVIRONMENT", "dev").lower() in ("prd", "prod")
    return InfraReportGenerator(
        include_tables=include_tables,
        use_html_charts=use_html_charts,
        email_mode=email_mode,
    ).generate_report(data)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/service-report")
def export_service_report(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
    include_tables: bool = Query(False),
    use_html_charts: bool = Query(False),
):
    """서비스 현황 HTML 리포트 (라이브 데이터)."""
    try:
        html = _generate_service_report_html(
            days, category, include_tables, use_html_charts=use_html_charts
        )
        today = datetime.now(KST).strftime("%Y-%m-%d")
        cat_suffix = f"-{category}" if category else ""
        return HTMLResponse(
            content=html,
            headers={
                "Content-Disposition": f'attachment; filename="service-report{cat_suffix}-{today}.html"'
            },
        )
    except Exception as e:
        logger.exception("export service-report error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/infra-report")
def export_infra_report(
    days: int = Query(31, ge=1, le=365),
    include_tables: bool = Query(False),
    use_html_charts: bool = Query(False),
):
    """인프라 현황 HTML 리포트 (라이브 데이터 + 메트릭 차트)."""
    try:
        html = _generate_infra_report_html(
            days=days, include_tables=include_tables, use_html_charts=use_html_charts
        )
        today = datetime.now(KST).strftime("%Y-%m-%d")
        return HTMLResponse(
            content=html,
            headers={"Content-Disposition": f'attachment; filename="infra-report-{today}.html"'},
        )
    except Exception as e:
        logger.exception("export infra-report error")
        raise HTTPException(status_code=500, detail=str(e))


# ── PDF Export ──────────────────────────────────────


def _build_service_pdf(
    days: int,
    category: str | None,
    include_tables: bool = False,
) -> tuple[bytes, str]:
    """서비스 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_service_report_html(days, category, include_tables)
    pdf_bytes = html_to_pdf(html, fit_single_page=True)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    cat_suffix = f"-{category}" if category else ""
    filename = f"service-report{cat_suffix}-{today}.pdf"
    return pdf_bytes, filename


def _build_infra_pdf(
    days: int = 31,
    include_tables: bool = False,
) -> tuple[bytes, str]:
    """인프라 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_infra_report_html(days=days, include_tables=include_tables)
    pdf_bytes = html_to_pdf(html, fit_single_page=True)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    filename = f"infra-report-{today}.pdf"
    return pdf_bytes, filename


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
    include_tables: bool = Query(False),
):
    """서비스 현황 PDF 리포트 (라이브 데이터)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(
            _build_service_pdf, days, category, include_tables
        )
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export service-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf(
    days: int = Query(31, ge=1, le=365),
    include_tables: bool = Query(False),
):
    """인프라 현황 PDF 리포트 (라이브 데이터 + 메트릭 차트)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(_build_infra_pdf, days, include_tables)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export infra-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Async Export (폴링 패턴) ──────────────────────────


class ExportStartRequest(BaseModel):
    report_type: str  # infra-report, infra-report-pdf, service-report, service-report-pdf
    days: int = 31
    category: str | None = None
    include_tables: bool = False


@router.post("/export/start")
def start_export(req: ExportStartRequest):
    """비동기 export job 시작 — job_id 즉시 반환."""
    _cleanup_expired_jobs()

    today = datetime.now(KST).strftime("%Y-%m-%d")
    cat_suffix = f"-{req.category}" if req.category else ""
    generators = {
        "infra-report": lambda: (
            _generate_infra_report_html(days=req.days, include_tables=req.include_tables),
            f"infra-report-{today}.html",
        ),
        "infra-report-pdf": lambda: _build_infra_pdf(req.days, include_tables=req.include_tables),
        "service-report": lambda: (
            _generate_service_report_html(
                days=req.days,
                category=req.category,
                include_tables=req.include_tables,
            ),
            f"service-report{cat_suffix}-{today}.html",
        ),
        "service-report-pdf": lambda: _build_service_pdf(
            req.days,
            req.category,
            include_tables=req.include_tables,
        ),
    }
    if req.report_type not in generators:
        raise HTTPException(400, f"Unknown report_type: {req.report_type}")

    job_id = uuid.uuid4().hex[:12]
    media_type = "application/pdf" if req.report_type.endswith("-pdf") else "text/html"

    # 초기 메타 저장 (다른 워커에서도 즉시 조회 가능)
    _save_job_meta(
        {
            "job_id": job_id,
            "status": "pending",
            "media_type": media_type,
            "file_path": None,
            "filename": "",
            "error": None,
            "created_at": time.time(),
        }
    )

    thread = threading.Thread(
        target=_run_export_job,
        args=(job_id, media_type, generators[req.report_type]),
        daemon=True,
    )
    thread.start()
    return {"job_id": job_id}


@router.get("/export/status/{job_id}")
def export_status(job_id: str):
    """export job 상태 조회."""
    meta = _load_job_meta(job_id)
    if not meta:
        raise HTTPException(404, "Job not found")
    return {"job_id": job_id, "status": meta["status"], "error": meta.get("error")}


@router.get("/export/download/{job_id}")
def export_download(job_id: str):
    """완료된 export 파일 다운로드."""
    meta = _load_job_meta(job_id)
    if not meta:
        raise HTTPException(404, "Job not found")
    if meta["status"] != "ready" or not meta.get("file_path"):
        raise HTTPException(409, f"Not ready (status={meta['status']})")
    from fastapi.responses import FileResponse

    return FileResponse(meta["file_path"], filename=meta["filename"], media_type=meta["media_type"])


# ── Email Preview (로컬 개발용) ──────────────────────


@router.get("/export/service-email-preview")
def preview_service_email(
    days: int = Query(15, ge=1, le=365),
    use_svg: bool = Query(False),
):
    """서비스 현황 이메일 미리보기 — 브라우저에서 직접 렌더링."""
    try:
        html = _generate_service_report_html(
            days=days,
            use_html_charts=not use_svg,
            email_mode=True,
        )
        return HTMLResponse(content=html)
    except Exception as e:
        logger.exception("preview service-email error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/infra-email-preview")
def preview_infra_email(
    days: int = Query(15, ge=1, le=365),
    use_svg: bool = Query(False),
):
    """인프라 현황 이메일 미리보기 — 브라우저에서 직접 렌더링."""
    try:
        html = _generate_infra_report_html(
            days=days,
            use_html_charts=not use_svg,
            email_mode=True,
        )
        return HTMLResponse(content=html)
    except Exception as e:
        logger.exception("preview infra-email error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Detection & Analysis ─────────────────────────────

# Detection 결과 캐시 (5분 TTL)
_detection_cache: dict | None = None
_detection_cache_ts: float = 0
_DETECTION_CACHE_TTL = 300


def _get_cached_detection(days: int = 31) -> dict:
    """Detection 결과를 캐싱하여 반환."""
    global _detection_cache, _detection_cache_ts
    now = time.time()
    if _detection_cache and (now - _detection_cache_ts) < _DETECTION_CACHE_TTL:
        _detection_cache["cache_age_seconds"] = int(now - _detection_cache_ts)
        return _detection_cache
    svc = _get_detection_service()
    result = svc.detect(days=days)
    result["last_detection_at"] = datetime.now(KST).isoformat()
    result["cache_age_seconds"] = 0
    _detection_cache = result
    _detection_cache_ts = now
    return result


@router.get("/detection/summary")
def get_detection_summary(days: int = Query(31, ge=1, le=365)):
    """이상 탐지 요약 (캐싱, 5분 TTL)."""
    try:
        result = _get_cached_detection(days)
        return {
            "total_anomalies": result.get("total_anomalies", 0),
            "severity_breakdown": result.get("severity_breakdown", {}),
            "last_detection_at": result.get("last_detection_at", ""),
            "summary": result.get("summary", ""),
            "cache_age_seconds": result.get("cache_age_seconds", 0),
        }
    except Exception as e:
        logger.exception("detection summary error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/detection/anomalies")
def list_detection_anomalies(
    severity: str | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    days: int = Query(31, ge=1, le=365),
):
    """탐지된 이상 목록 (severity 필터, 페이지네이션)."""
    try:
        result = _get_cached_detection(days)
        anomalies = result.get("anomalies", [])

        if severity:
            anomalies = [a for a in anomalies if a.get("severity") == severity]

        # index 부여
        for i, a in enumerate(anomalies):
            a["index"] = i

        total = len(anomalies)
        paged = anomalies[offset : offset + limit]

        return {"anomalies": paged, "total": total, "offset": offset, "limit": limit}
    except Exception as e:
        logger.exception("detection anomalies error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/detection/anomalies/{index}/analysis")
def get_anomaly_analysis(index: int, days: int = Query(31, ge=1, le=365)):
    """특정 이상에 대한 심층 분석."""
    try:
        result = _get_cached_detection(days)
        anomalies = result.get("anomalies", [])

        if index < 0 or index >= len(anomalies):
            raise HTTPException(status_code=404, detail="Anomaly not found")

        anomaly = anomalies[index]

        # 단일 anomaly에 대해 deep analysis 실행
        svc = _get_detection_service()
        single_result = {
            "detection_type": "bdp_dashboard_metrics",
            "total_anomalies": 1,
            "severity_breakdown": {anomaly.get("severity", "medium"): 1},
            "anomalies": [anomaly],
            "summary": f"{anomaly.get('metric_source', '')} - {anomaly.get('resource_id', '')}",
        }
        analyzed = svc.analyze(single_result)

        return {
            "anomaly": anomaly,
            "deep_analysis": analyzed.get("deep_analysis"),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("anomaly analysis error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/detect")
def detect_anomalies(days: int = Query(31, ge=1, le=365)):
    """BDP 대시보드 메트릭 이상 탐지 수행."""
    try:
        svc = _get_detection_service()
        return svc.detect(days=days)
    except Exception as e:
        logger.exception("bdp_dashboard detect error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze")
def analyze_anomalies(days: int = Query(31, ge=1, le=365)):
    """BDP 대시보드 메트릭 이상 탐지 + 심층 분석 수행."""
    try:
        svc = _get_detection_service()
        detect_result = svc.detect(days=days)
        return svc.analyze(detect_result)
    except Exception as e:
        logger.exception("bdp_dashboard analyze error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Test Email ──────────────────────────────────────


class TestEmailRequest(BaseModel):
    to: list[str]
    cc: list[str] = []
    subject: str = "[테스트] BDP Portal 메일 발송 테스트"
    message: str = (
        "<h3>BDP Portal 테스트 메일</h3><p>이 메일은 EventBridge 메일 발송 테스트입니다.</p>"
    )


class ReportTestEmailRequest(BaseModel):
    report_type: str
    to: list[str]
    cc: list[str] = []


_REPORT_TYPE_LABELS = {
    "service_dashboard": "BDP 서비스 현황",
    "infra_dashboard": "BDP 인프라 현황",
}


def _build_and_send_report_email(
    report_type: str, to: list[str], cc: list[str],
) -> dict:
    """리포트 테스트 메일 생성+발송 (스레드에서 실행)."""
    from src.agent_server.bdp_common.mail.sender import send_report_email
    from src.agent_server.bdp_common.reports.s3_export import generate_and_upload_report_png

    label = _REPORT_TYPE_LABELS[report_type]
    days = 15

    # 1. SVG HTML 직접 생성
    if report_type == "service_dashboard":
        html = _generate_service_report_html(days)
    else:
        html = _generate_infra_report_html(days=days)

    # 2. PNG → S3
    date_str = datetime.now(KST).strftime("%Y%m%d")
    bucket, files_dict, pdf_key = generate_and_upload_report_png(report_type, html, date_str)

    # 3. CID 이미지 HTML 본문 + EventBridge 발송
    img_rows = "".join(
        f'<tr><td><img src="cid:{key}" width="100%" /></td></tr>'
        for key in sorted(files_dict.keys())
    )
    html_body = (
        '<html><body>'
        '<table cellpadding="0" cellspacing="0" border="0" width="100%">'
        f'{img_rows}'
        '</table>'
        '</body></html>'
    )
    env_label = "개발계" if os.getenv("ENVIRONMENT", "dev").lower() in ("dev", "test") else "운영계"
    subject = f"[{env_label}] [테스트] {label} 리포트 메일 발송 테스트"

    success = send_report_email(
        report_type=report_type,
        subject=subject,
        html_body=html_body,
        to=to,
        cc=cc,
        inline={"bucketName": bucket, "files": files_dict},
        attachment={"bucketName": bucket, "files": {"report": pdf_key}},
    )

    return {
        "success": success,
        "mock_mode": os.getenv("EVENT_PROVIDER", "mock") == "mock",
        "report_type": report_type,
        "s3_bucket": bucket,
        "s3_files": files_dict,
    }


@router.post("/test-report-email")
async def send_test_report_email(
    req: ReportTestEmailRequest,
    background_tasks: BackgroundTasks,
):
    """리포트 테스트 메일 발송 — 즉시 응답 후 백그라운드 발송."""
    if req.report_type not in _REPORT_TYPE_LABELS:
        raise HTTPException(status_code=400, detail=f"Invalid report_type: {req.report_type}")
    if not req.to:
        raise HTTPException(status_code=400, detail="recipients 'to' is required")

    background_tasks.add_task(
        _build_and_send_report_email, req.report_type, req.to, req.cc,
    )
    return {"status": "accepted", "report_type": req.report_type}


@router.post("/test-email")
def send_test_email(req: TestEmailRequest):
    """EventPublisher를 통한 테스트 메일 발송."""
    from src.agent_server.bdp_common.eventbridge.publisher import (
        EmailChannel,
        EventPublisher,
        ProductionAlertDetail,
        get_environment_account_name,
    )

    event_provider = os.getenv("EVENT_PROVIDER", "mock")
    publisher = EventPublisher(
        source="cd1-agent.bdp-portal",
        event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
        use_mock=(event_provider == "mock"),
    )

    detail = ProductionAlertDetail(
        subject=req.subject,
        account_id=get_environment_account_name(),
        component="BDPC",
        email=EmailChannel(
            to=req.to,
            cc=req.cc,
            from_email="portal@hcs.com",
            from_name="BDP Portal",
            type="html",
            message=req.message,
        ),
    )

    success = publisher.publish_production_event(detail, "Portal Test Email")

    return {
        "success": success,
        "mock_mode": publisher.use_mock,
        "event_bus": publisher.event_bus,
        "payload_preview": detail.to_dict(),
    }
