"""HDSP Dashboard agent router - K8s 인프라 현황 + 서비스 메트릭."""

import logging
import os
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse

from src.agent_server.bdp_common.chart_utils import (
    aggregate_series_to_chart,
    compute_namespace_summaries,
    compute_spark_summary,
    flatten_multi_metric_chart,
    flatten_nested_series_to_chart,
    flatten_path_multi_metric_chart,
    flatten_path_single_metric_chart,
    structure_k8s_data,
)
from src.common.timezone import KST

logger = logging.getLogger(__name__)

AGENT_NAME = "hdsp_dashboard"

router = APIRouter()

# Lazy singletons
_k8s_infra_service = None
_hdsp_metrics_service = None
_detection_service = None
_l0_ingestion_service = None


def _get_l0_ingestion_service():
    global _l0_ingestion_service
    if _l0_ingestion_service is None:
        from src.agent_server.hdsp_dashboard.services.l0_ingestion_service import (
            L0IngestionService,
        )

        _l0_ingestion_service = L0IngestionService()
    return _l0_ingestion_service


def _get_detection_service():
    global _detection_service
    if _detection_service is None:
        from src.agent_server.hdsp_dashboard.services.detection_service import (
            HdspDashboardDetectionService,
        )

        _detection_service = HdspDashboardDetectionService(_get_hdsp_metrics_service())
    return _detection_service


def _get_k8s_infra_service():
    global _k8s_infra_service
    if _k8s_infra_service is None:
        from src.agent_server.hdsp_dashboard.services.k8s_infra_service import K8sInfraService
        from src.portal.config import PortalSettings

        _k8s_infra_service = K8sInfraService(PortalSettings())
    return _k8s_infra_service


def _get_hdsp_metrics_service():
    global _hdsp_metrics_service
    if _hdsp_metrics_service is None:
        from src.agent_server.hdsp_dashboard.providers import create_hdsp_providers
        from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import HdspMetricsService

        providers = create_hdsp_providers()
        _hdsp_metrics_service = HdspMetricsService(providers)
    return _hdsp_metrics_service


# ── L0 Ingestion ──────────────────────────────────────


@router.get("/l0-ingestion")
async def get_l0_ingestion():
    """L0 입수 현황 데이터 (소스별 일별/월별 성공/실패 건수)."""
    try:
        svc = _get_l0_ingestion_service()
        return svc.get_l0_data()
    except Exception as e:
        logger.exception("hdsp_dashboard l0-ingestion error")
        raise HTTPException(status_code=500, detail=str(e))


# ── K8s Infra ─────────────────────────────────────────


@router.get("/infra")
async def get_k8s_infra_data():
    """K8s 인프라 리소스 현황 조회."""
    try:
        svc = _get_k8s_infra_service()
        data = svc.get_dashboard_data()
        # K8s 데이터 구조화 (노드그룹별 그룹핑, 파드→노드 매핑)
        nodes = data.get("nodes", [])
        pods = data.get("pods", [])
        structured = structure_k8s_data(nodes, pods)
        data["node_groups_map"] = structured["node_groups"]
        data["pods_by_node_map"] = structured["pods_by_node"]
        # 네임스페이스별 요약 통계 미리 계산
        namespaces = data.get("namespaces", {})
        data["namespace_summaries"] = compute_namespace_summaries(
            namespaces,
            structured["node_groups"],
            structured["pods_by_node"],
        )
        return data
    except Exception as e:
        logger.exception("hdsp_dashboard infra error")
        raise HTTPException(status_code=500, detail=str(e))


# ── HDSP Metrics ─────────────────────────────────────


@router.get("/infra/metrics/info")
def get_hdsp_metrics_info():
    """HDSP 메트릭 서비스의 mock/real 여부를 반환한다."""
    provider_type = os.getenv("HDSP_PROVIDER", "mock")
    return {"is_mock": provider_type != "real"}


@router.get("/infra/metrics/jupyter-access")
async def get_jupyter_access(days: int = Query(31, ge=1, le=365)):
    """Jupyter 팀별 일일 접속자 수."""
    try:
        return _get_hdsp_metrics_service().get_jupyter_access(days=days)
    except Exception as e:
        logger.exception("hdsp metrics jupyter-access error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/minio-usage")
async def get_minio_usage(days: int = Query(31, ge=1, le=365)):
    """MinIO 팀별 저장소 사용량."""
    try:
        return _get_hdsp_metrics_service().get_minio_usage(days=days)
    except Exception as e:
        logger.exception("hdsp metrics minio-usage error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/minio-access")
async def get_minio_access(days: int = Query(31, ge=1, le=365)):
    """MinIO 팀별 일일 접속자 수."""
    try:
        return _get_hdsp_metrics_service().get_minio_access(days=days)
    except Exception as e:
        logger.exception("hdsp metrics minio-access error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/spark-failures")
async def get_spark_failures(days: int = Query(31, ge=1, le=365)):
    """Spark 팀별 일일 Job 실패 수."""
    try:
        return _get_hdsp_metrics_service().get_spark_failures(days=days)
    except Exception as e:
        logger.exception("hdsp metrics spark-failures error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/hdsp-api-errors")
async def get_hdsp_api_errors(days: int = Query(31, ge=1, le=365)):
    """HDSP API 일별 4xx/5xx 에러 수."""
    try:
        return _get_hdsp_metrics_service().get_hdsp_api_errors(days=days)
    except Exception as e:
        logger.exception("hdsp metrics hdsp-api-errors error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/nfs-usage")
async def get_nfs_usage(days: int = Query(31, ge=1, le=365)):
    """NFS 팀별 사용량."""
    try:
        return _get_hdsp_metrics_service().get_nfs_usage(days=days)
    except Exception as e:
        logger.exception("hdsp metrics nfs-usage error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/eks-pod-resources")
async def get_eks_pod_resources(days: int = Query(31, ge=1, le=365)):
    """EKS Pod별 일일 CPU/Memory 리소스 사용량."""
    try:
        return _get_hdsp_metrics_service().get_eks_pod_resources(days=days)
    except Exception as e:
        logger.exception("hdsp metrics eks-pod-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/eks-node-resources")
async def get_eks_node_resources(days: int = Query(31, ge=1, le=365)):
    """EKS Node별 일일 CPU/Memory 리소스 사용량."""
    try:
        return _get_hdsp_metrics_service().get_eks_node_resources(days=days)
    except Exception as e:
        logger.exception("hdsp metrics eks-node-resources error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/eks-event-trends")
async def get_eks_event_trends(days: int = Query(31, ge=1, le=365)):
    """EKS Warning 이벤트 일별 발생 추이."""
    try:
        return _get_hdsp_metrics_service().get_eks_event_trends(days=days)
    except Exception as e:
        logger.exception("hdsp metrics eks-event-trends error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/log-backup-status")
async def get_log_backup_status(days: int = Query(31, ge=1, le=365)):
    """로그백업 저장소별/소스별 일별 도착 현황."""
    try:
        return _get_hdsp_metrics_service().get_log_backup_status(days=days)
    except Exception as e:
        logger.exception("hdsp metrics log-backup-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/spark-cluster-status")
async def get_spark_cluster_status(days: int = Query(31, ge=1, le=365)):
    """Spark 클러스터 현황 및 일별 리소스/Job 추이."""
    try:
        data = _get_hdsp_metrics_service().get_spark_cluster_status(days=days)
        # Resource chart: {date, cluster1_cpu, cluster1_mem, ...}
        data["resource_chart"] = flatten_multi_metric_chart(
            data.get("clusters", {}),
            "daily",
            {"cpu": "cpu_cores", "mem": "memory_gb"},
        )
        # Job trend chart: aggregated across clusters
        data["job_trend_chart"] = aggregate_series_to_chart(
            data.get("clusters", {}),
            "daily",
            ["jobs_submitted", "jobs_completed", "jobs_failed"],
        )
        # Summary cards data
        data["node_summary"] = compute_spark_summary(data.get("clusters", {}))
        return data
    except Exception as e:
        logger.exception("hdsp metrics spark-cluster-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/spark/jobs")
async def get_spark_jobs(cluster: str | None = Query(None)):
    """현재 실행 중인 Spark Job 목록."""
    try:
        return _get_hdsp_metrics_service().get_spark_jobs(cluster=cluster)
    except Exception as e:
        logger.exception("hdsp spark jobs error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/spark/jobs/{app_id}/logs")
async def get_spark_job_logs(
    app_id: str,
    level: str | None = Query(None),
    limit: int = Query(100, ge=1, le=500),
):
    """Spark Job 로그 조회."""
    try:
        return _get_hdsp_metrics_service().get_spark_job_logs(app_id, level=level, limit=limit)
    except Exception as e:
        logger.exception(f"hdsp spark job logs error: {app_id}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/spark/nodes/{node_id}/logs")
async def get_spark_node_logs(
    node_id: str,
    level: str | None = Query(None),
    limit: int = Query(100, ge=1, le=500),
):
    """Spark 노드(driver/executor) 로그 조회."""
    try:
        return _get_hdsp_metrics_service().get_spark_node_logs(node_id, level=level, limit=limit)
    except Exception as e:
        logger.exception(f"hdsp spark node logs error: {node_id}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/minio-admin")
async def get_minio_admin(days: int = Query(31, ge=1, le=365)):
    """MinIO 관리자 현황 (버킷/디스크/API)."""
    try:
        data = _get_hdsp_metrics_service().get_minio_admin(days=days)
        data["bucket_size_chart"] = flatten_nested_series_to_chart(
            data.get("buckets", {}),
            "daily",
            "size_gb",
        )
        return data
    except Exception as e:
        logger.exception("hdsp metrics minio-admin error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/nfs-iops")
async def get_nfs_iops(days: int = Query(31, ge=1, le=365)):
    """NFS 마운트별 IOPS 및 지연시간."""
    try:
        data = _get_hdsp_metrics_service().get_nfs_iops(days=days)
        data["iops_chart"] = flatten_path_multi_metric_chart(
            data.get("mounts", {}),
            "daily",
            {"read": "read_iops", "write": "write_iops"},
            path_shortener=True,
        )
        data["latency_chart"] = flatten_path_single_metric_chart(
            data.get("mounts", {}),
            "daily",
            "latency_ms",
            path_shortener=True,
        )
        return data
    except Exception as e:
        logger.exception("hdsp metrics nfs-iops error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/hdsp-api-latency")
async def get_hdsp_api_latency(days: int = Query(31, ge=1, le=365)):
    """HDSP API 응답시간 p50/p95/p99 및 분당 요청수."""
    try:
        return _get_hdsp_metrics_service().get_hdsp_api_latency(days=days)
    except Exception as e:
        logger.exception("hdsp metrics hdsp-api-latency error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/backup-success-rate")
async def get_backup_success_rate(days: int = Query(31, ge=1, le=365)):
    """백업 저장소별 성공/실패율."""
    try:
        data = _get_hdsp_metrics_service().get_backup_success_rate(days=days)
        data["aggregated_chart"] = aggregate_series_to_chart(
            data.get("destinations", {}),
            "daily",
            ["success", "failure"],
        )
        return data
    except Exception as e:
        logger.exception("hdsp metrics backup-success-rate error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/haproxy-stats")
async def get_haproxy_stats(days: int = Query(31, ge=1, le=365)):
    """HAProxy 프론트엔드/백엔드 통계."""
    try:
        data = _get_hdsp_metrics_service().get_haproxy_stats(days=days)
        data["connections_chart"] = flatten_nested_series_to_chart(
            data.get("frontends", {}),
            "daily",
            "connections",
        )
        data["response_time_chart"] = flatten_nested_series_to_chart(
            data.get("backends", {}),
            "daily",
            "response_time_ms",
        )
        return data
    except Exception as e:
        logger.exception("hdsp metrics haproxy-stats error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/docker-registry-stats")
async def get_docker_registry_stats(days: int = Query(31, ge=1, le=365)):
    """Docker Registry 이미지/Pull·Push/스토리지 통계."""
    try:
        return _get_hdsp_metrics_service().get_docker_registry_stats(days=days)
    except Exception as e:
        logger.exception("hdsp metrics docker-registry-stats error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/jupyter-cluster-status")
async def get_jupyter_cluster_status(days: int = Query(31, ge=1, le=365)):
    """Jupyter 클러스터 현황 (Hub/DB/Lab Pods)."""
    try:
        return _get_hdsp_metrics_service().get_jupyter_cluster_status(days=days)
    except Exception as e:
        logger.exception("hdsp metrics jupyter-cluster-status error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/cost-explorer-savings")
async def get_cost_explorer_savings():
    """Cost Explorer 절감 현황."""
    try:
        return _get_hdsp_metrics_service().get_cost_explorer_savings()
    except Exception as e:
        logger.exception("hdsp metrics cost-explorer-savings error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/usage-conversion-savings")
async def get_usage_conversion_savings():
    """사용량 전환 절감 현황."""
    try:
        return _get_hdsp_metrics_service().get_usage_conversion_savings()
    except Exception as e:
        logger.exception("hdsp metrics usage-conversion-savings error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/gcp-cost-monthly")
async def get_gcp_cost_monthly(
    year: int = Query(default_factory=lambda: datetime.now(KST).year),
    env: str | None = Query(None),
):
    """월별 GCP 비용."""
    try:
        return _get_hdsp_metrics_service().get_gcp_monthly_cost(year=year, env=env)
    except Exception as e:
        logger.exception("hdsp metrics gcp-cost-monthly error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/gcp-cost-daily")
async def get_gcp_cost_daily(
    year: int = Query(default_factory=lambda: datetime.now(KST).year),
    month: int = Query(default_factory=lambda: datetime.now(KST).month),
    env: str | None = Query(None),
):
    """일별 GCP 비용."""
    try:
        return _get_hdsp_metrics_service().get_gcp_daily_cost(year=year, month=month, env=env)
    except Exception as e:
        logger.exception("hdsp metrics gcp-cost-daily error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/universe-failures")
async def get_universe_failures(days: int = Query(31, ge=1, le=365)):
    """Universe 파이프라인 일별 실패 현황."""
    try:
        return _get_hdsp_metrics_service().get_universe_failures(days=days)
    except Exception as e:
        logger.exception("hdsp metrics universe-failures error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/metrics/sobicare-workflows")
async def get_sobicare_workflows(days: int = Query(31, ge=1, le=365)):
    """소비케어 Workflow 실행 현황."""
    try:
        return _get_hdsp_metrics_service().get_sobicare_workflows(days=days)
    except Exception as e:
        logger.exception("hdsp metrics sobicare-workflows error")
        raise HTTPException(status_code=500, detail=str(e))


# ── K8s Pod Logs ─────────────────────────────────────


@router.get("/infra/k8s/pods/{namespace}/{pod_name}/logs")
async def get_k8s_pod_logs(
    namespace: str,
    pod_name: str,
    container: str | None = Query(None),
    tail_lines: int = Query(200, ge=1, le=1000),
    since_seconds: int = Query(3600, ge=60, le=86400),
):
    """K8s 파드 로그 조회."""
    try:
        svc = _get_k8s_infra_service()
        return svc.get_pod_logs(
            pod_name=pod_name,
            namespace=namespace,
            container=container,
            tail_lines=tail_lines,
            since_seconds=since_seconds,
        )
    except Exception as e:
        logger.exception(f"hdsp k8s pod logs error: {namespace}/{pod_name}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/k8s/nodes/{node_name}/logs")
async def get_k8s_node_logs(
    node_name: str,
    log_path: str = Query("messages"),
    tail_lines: int = Query(200, ge=1, le=1000),
    since_seconds: int = Query(3600, ge=60, le=86400),
):
    """K8s 노드 로그 조회."""
    try:
        svc = _get_k8s_infra_service()
        return svc.get_node_logs(
            node_name=node_name,
            log_path=log_path,
            tail_lines=tail_lines,
            since_seconds=since_seconds,
        )
    except Exception as e:
        logger.exception(f"hdsp k8s node logs error: {node_name}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Browsing Endpoints ───────────────────────────────


@router.get("/infra/minio/{bucket_name}/prefixes")
async def get_minio_prefixes(
    bucket_name: str, prefix: str = Query("", description="Parent prefix path")
):
    """MinIO 버킷의 특정 prefix 하위 디렉토리 목록 조회."""
    try:
        return _get_hdsp_metrics_service().get_minio_prefixes(bucket_name, prefix)
    except Exception as e:
        logger.exception(f"hdsp minio prefixes error: {bucket_name}/{prefix}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/infra/nfs/directories")
async def get_nfs_directories(
    mount: str = Query(..., description="NFS mount path"),
    path: str = Query("", description="Sub-directory path"),
):
    """NFS 마운트의 특정 경로 하위 디렉토리 목록 조회."""
    try:
        return _get_hdsp_metrics_service().get_nfs_directories(mount, path)
    except Exception as e:
        logger.exception(f"hdsp nfs directories error: {mount}/{path}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Report Data Helpers ──────────────────────────────


_HDSP_CATEGORY_DATA_MAP: dict[str, str] = {
    "jupyter": "jupyter_access",
    "minio": "minio_usage",
    "minio-access": "minio_access",
    "spark": "spark_failures",
    "api-errors": "hdsp_api_errors",
    "nas": "nas_usage",
    "cost-savings": "cost_savings",
}


def _generate_hdsp_service_report_html(days: int, category: str | None = None) -> str:
    from src.agent_server.hdsp_dashboard.services.service_report_generator import (
        HdspServiceReportData,
        HdspServiceReportGenerator,
    )

    metrics_svc = _get_hdsp_metrics_service()

    # 카테고리가 지정되면 해당 메트릭만 수집
    need = _HDSP_CATEGORY_DATA_MAP.get(category) if category else None

    jupyter_access = {}
    if not need or need == "jupyter_access":
        try:
            jupyter_access = metrics_svc.get_jupyter_access(days=days).get("teams", {})
        except Exception as e:
            logger.warning(f"Failed to fetch jupyter access for export: {e}")

    minio_usage = {}
    if not need or need == "minio_usage":
        try:
            minio_usage = metrics_svc.get_minio_usage(days=days).get("teams", {})
        except Exception as e:
            logger.warning(f"Failed to fetch minio usage for export: {e}")

    spark_failures = {}
    if not need or need == "spark_failures":
        try:
            spark_failures = metrics_svc.get_spark_failures(days=days).get("teams", {})
        except Exception as e:
            logger.warning(f"Failed to fetch spark failures for export: {e}")

    hdsp_api_errors = []
    if not need or need == "hdsp_api_errors":
        try:
            hdsp_api_errors = metrics_svc.get_hdsp_api_errors(days=days).get("daily", [])
        except Exception as e:
            logger.warning(f"Failed to fetch hdsp api errors for export: {e}")

    nas_usage = {}
    if not need or need == "nas_usage":
        try:
            nas_usage = metrics_svc.get_nfs_usage(days=days).get("teams", {})
        except Exception as e:
            logger.warning(f"Failed to fetch nas usage for export: {e}")

    minio_access = {}
    if not need or need == "minio_access":
        try:
            minio_access = metrics_svc.get_minio_access(days=days).get("teams", {})
        except Exception as e:
            logger.warning(f"Failed to fetch minio access for export: {e}")

    cost_explorer_savings = {}
    if not need or need == "cost_savings":
        try:
            cost_explorer_savings = metrics_svc.get_cost_explorer_savings()
        except Exception as e:
            logger.warning(f"Failed to fetch cost explorer savings for export: {e}")

    usage_conversion_savings = {}
    if not need or need == "cost_savings":
        try:
            usage_conversion_savings = metrics_svc.get_usage_conversion_savings()
        except Exception as e:
            logger.warning(f"Failed to fetch usage conversion savings for export: {e}")

    data = HdspServiceReportData(
        jupyter_access=jupyter_access,
        minio_usage=minio_usage,
        spark_failures=spark_failures,
        hdsp_api_errors=hdsp_api_errors,
        nas_usage=nas_usage,
        minio_access=minio_access,
        cost_explorer_savings=cost_explorer_savings,
        usage_conversion_savings=usage_conversion_savings,
    )
    return HdspServiceReportGenerator(category=category).generate_report(data)


def _generate_hdsp_infra_report_html() -> str:
    from src.agent_server.hdsp_dashboard.services.infra_report_generator import (
        HdspInfraReportData,
        HdspInfraReportGenerator,
    )

    svc = _get_k8s_infra_service()
    dash = svc.get_dashboard_data()

    # 메트릭 데이터 (차트용)
    metrics_svc = _get_hdsp_metrics_service()
    node_resources: dict = {}
    event_trends: dict = {}
    try:
        node_resources = metrics_svc.get_eks_node_resources(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch node resources for export: {e}")
    try:
        event_trends = metrics_svc.get_eks_event_trends(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch event trends for export: {e}")

    # ── 추가 인프라 메트릭 ───────────────────────────
    spark_cluster_status: dict = {}
    try:
        spark_cluster_status = metrics_svc.get_spark_cluster_status(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch spark cluster status for export: {e}")

    minio_admin: dict = {}
    try:
        minio_admin = metrics_svc.get_minio_admin(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch minio admin for export: {e}")

    nfs_iops: dict = {}
    try:
        nfs_iops = metrics_svc.get_nfs_iops(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch nfs iops for export: {e}")

    hdsp_api_latency: dict = {}
    try:
        hdsp_api_latency = metrics_svc.get_hdsp_api_latency(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch hdsp api latency for export: {e}")

    log_backup_status: dict = {}
    try:
        log_backup_status = metrics_svc.get_log_backup_status(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch log backup status for export: {e}")

    backup_success_rate: dict = {}
    try:
        backup_success_rate = metrics_svc.get_backup_success_rate(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch backup success rate for export: {e}")

    haproxy_stats: dict = {}
    try:
        haproxy_stats = metrics_svc.get_haproxy_stats(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch haproxy stats for export: {e}")

    docker_registry_stats: dict = {}
    try:
        docker_registry_stats = metrics_svc.get_docker_registry_stats(days=31)
    except Exception as e:
        logger.warning(f"Failed to fetch docker registry stats for export: {e}")

    data = HdspInfraReportData(
        summary=dash.get("summary", {}),
        nodes=dash.get("nodes", []),
        pods=dash.get("pods", []),
        deployments=dash.get("deployments", []),
        namespaces=dash.get("namespaces", {}),
        events=dash.get("events", []),
        cluster_name=dash.get("cluster_name", ""),
        node_resources=node_resources,
        event_trends=event_trends,
        spark_cluster_status=spark_cluster_status,
        minio_admin=minio_admin,
        nfs_iops=nfs_iops,
        hdsp_api_latency=hdsp_api_latency,
        log_backup_status=log_backup_status,
        backup_success_rate=backup_success_rate,
        haproxy_stats=haproxy_stats,
        docker_registry_stats=docker_registry_stats,
    )
    return HdspInfraReportGenerator().generate_report(data)


# ── HTML Export ──────────────────────────────────────


@router.get("/export/service-report")
async def export_service_report(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
):
    """HDSP 서비스 현황 HTML 리포트 (라이브 데이터)."""
    try:
        html = _generate_hdsp_service_report_html(days, category)
        today = datetime.now(KST).strftime("%Y-%m-%d")
        cat_suffix = f"-{category}" if category else ""
        return HTMLResponse(
            content=html,
            headers={
                "Content-Disposition": f'attachment; filename="hdsp-service-report{cat_suffix}-{today}.html"'
            },
        )
    except Exception as e:
        logger.exception("export hdsp service-report error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/infra-report")
async def export_infra_report():
    """HDSP K8s 인프라 현황 HTML 리포트 (라이브 데이터)."""
    try:
        html = _generate_hdsp_infra_report_html()
        today = datetime.now(KST).strftime("%Y-%m-%d")
        return HTMLResponse(
            content=html,
            headers={
                "Content-Disposition": f'attachment; filename="hdsp-infra-report-{today}.html"'
            },
        )
    except Exception as e:
        logger.exception("export hdsp infra-report error")
        raise HTTPException(status_code=500, detail=str(e))


# ── PDF Export ──────────────────────────────────────


def _build_hdsp_service_pdf(days: int, category: str | None) -> tuple[bytes, str]:
    """HDSP 서비스 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_hdsp_service_report_html(days, category)
    pdf_bytes = html_to_pdf(html)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    cat_suffix = f"-{category}" if category else ""
    filename = f"hdsp-service-report{cat_suffix}-{today}.pdf"
    return pdf_bytes, filename


def _build_hdsp_infra_pdf() -> tuple[bytes, str]:
    """HDSP 인프라 PDF 생성 (스레드풀에서 실행)."""
    from src.agent_server.bdp_common.reports.pdf import html_to_pdf

    html = _generate_hdsp_infra_report_html()
    pdf_bytes = html_to_pdf(html)
    today = datetime.now(KST).strftime("%Y-%m-%d")
    filename = f"hdsp-infra-report-{today}.pdf"
    return pdf_bytes, filename


@router.get("/export/service-report-pdf")
async def export_service_report_pdf(
    days: int = Query(31, ge=1, le=365),
    category: str | None = Query(None),
):
    """HDSP 서비스 현황 PDF 리포트 (라이브 데이터)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(_build_hdsp_service_pdf, days, category)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export hdsp service-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/export/infra-report-pdf")
async def export_infra_report_pdf():
    """HDSP K8s 인프라 현황 PDF 리포트 (라이브 데이터)."""
    import asyncio

    try:
        from fastapi.responses import Response

        pdf_bytes, filename = await asyncio.to_thread(_build_hdsp_infra_pdf)
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        logger.exception("export hdsp infra-report-pdf error")
        raise HTTPException(status_code=500, detail=str(e))


# ── Detection & Analysis ─────────────────────────────


@router.post("/detect")
async def detect_anomalies(days: int = Query(31, ge=1, le=365)):
    """HDSP 대시보드 메트릭 이상 탐지 수행."""
    try:
        svc = _get_detection_service()
        return svc.detect(days=days)
    except Exception as e:
        logger.exception("hdsp_dashboard detect error")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze")
async def analyze_anomalies(days: int = Query(31, ge=1, le=365)):
    """HDSP 대시보드 메트릭 이상 탐지 + 심층 분석 수행."""
    try:
        svc = _get_detection_service()
        detect_result = svc.detect(days=days)
        return svc.analyze(detect_result)
    except Exception as e:
        logger.exception("hdsp_dashboard analyze error")
        raise HTTPException(status_code=500, detail=str(e))
