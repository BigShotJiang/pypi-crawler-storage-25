"""BDP Drift agent router."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from src.agent_server.bdp_drift.handler import BDPDriftHandler
from src.common.server.adapter import create_handler_endpoint

logger = logging.getLogger(__name__)

AGENT_NAME = "bdp_drift"

router = APIRouter()

_detect_endpoint = create_handler_endpoint(BDPDriftHandler)


class InvokeRequest(BaseModel):
    """Generic invoke payload — forwarded to the Lambda handler as-is."""

    action: str = Field(default="detect", description="detect | sync_baselines | daily_report | e2e")
    resource_types: Optional[List[str]] = None
    severity_threshold: str = Field(default="medium")
    enable_analysis: bool = Field(default=False)
    publish_alerts: bool = Field(default=True)
    output_dir: Optional[str] = Field(default=None, description="리포트 저장 경로 (daily_report, e2e)")


@router.post("/invoke")
async def invoke(request: InvokeRequest) -> Dict[str, Any]:
    """Invoke the BDP Drift detection handler."""
    try:
        result = await _detect_endpoint(request.model_dump(exclude_none=True))
        if isinstance(result, dict) and result.get("success") is False:
            raise HTTPException(status_code=500, detail=result.get("error", "detection failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("bdp_drift invoke error")
        raise HTTPException(status_code=500, detail=str(e))
