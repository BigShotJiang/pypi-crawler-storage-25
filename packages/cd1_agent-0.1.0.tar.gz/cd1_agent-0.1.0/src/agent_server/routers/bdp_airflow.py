"""BDP Airflow agent router."""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from src.agent_server.bdp_airflow.handler import BDPAirflowHandler
from src.common.server.adapter import create_handler_endpoint

logger = logging.getLogger(__name__)

AGENT_NAME = "bdp_airflow"

router = APIRouter()

_detect_endpoint = create_handler_endpoint(BDPAirflowHandler)


class InvokeRequest(BaseModel):
    """Generic invoke payload — forwarded to the Lambda handler as-is."""

    action: str = Field(default="detect", description="detect | dag_detail | precursor_scan | daily_report | e2e")
    hours: int = Field(default=24, ge=1, le=168)
    publish_alerts: bool = Field(default=True)
    send_kakao: bool = Field(default=False)
    output_dir: Optional[str] = Field(default=None, description="리포트 저장 경로 (daily_report, e2e)")


@router.post("/invoke")
async def invoke(request: InvokeRequest) -> Dict[str, Any]:
    """Invoke the BDP Airflow failure detection handler."""
    try:
        result = await _detect_endpoint(request.model_dump())
        if isinstance(result, dict) and result.get("success") is False:
            raise HTTPException(status_code=500, detail=result.get("error", "detection failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("bdp_airflow invoke error")
        raise HTTPException(status_code=500, detail=str(e))
