"""HDSP Agent - On-Prem Kubernetes Detection Agent."""

from src.agent_server.hdsp_metrics.handler import HDSPDetectionHandler, handler

__all__ = [
    "HDSPDetectionHandler",
    "handler",
]
