"""
Retry 유틸리티.

Exponential backoff 기반 재시도 데코레이터.
AWS API 호출, DB 접근 등 일시적 실패 가능한 작업에 사용.
"""

import logging
import time
from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def with_retry(
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 10.0,
    retryable_exceptions: tuple[type[Exception], ...] = (Exception,),
) -> Callable[[F], F]:
    """Exponential backoff retry 데코레이터.

    Args:
        max_retries: 최대 재시도 횟수 (0이면 재시도 안 함)
        base_delay: 기본 대기 시간 (초)
        max_delay: 최대 대기 시간 (초)
        retryable_exceptions: 재시도 대상 예외 타입

    Usage:
        @with_retry(max_retries=3)
        def fetch_metrics():
            ...
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error: Exception | None = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as e:
                    last_error = e
                    if attempt < max_retries:
                        delay = min(base_delay * (2**attempt), max_delay)
                        logger.warning(
                            "[retry] %s attempt %d/%d failed: %s. Retrying in %.1fs",
                            func.__name__,
                            attempt + 1,
                            max_retries,
                            e,
                            delay,
                        )
                        time.sleep(delay)
                    else:
                        logger.error(
                            "[retry] %s failed after %d attempts: %s",
                            func.__name__,
                            max_retries + 1,
                            e,
                        )
            raise last_error  # type: ignore[misc]

        return wrapper  # type: ignore[return-value]

    return decorator
