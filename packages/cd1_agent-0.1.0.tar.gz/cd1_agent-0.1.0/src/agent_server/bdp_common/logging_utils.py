"""
구조화 로깅 유틸리티.

ContextVar 기반 trace_id 전파로 cross-service 요청 추적 지원.
Detection/Analysis 파이프라인의 전체 흐름을 단일 trace_id로 추적 가능.
"""

import logging
import uuid
from contextvars import ContextVar

_trace_id: ContextVar[str] = ContextVar("trace_id", default="")


def new_trace_id() -> str:
    """새 trace_id 생성 및 ContextVar에 설정.

    Detection/Analyze 진입점에서 호출.

    Returns:
        생성된 trace_id (8자리 UUID prefix)
    """
    tid = uuid.uuid4().hex[:8]
    _trace_id.set(tid)
    return tid


def get_trace_id() -> str:
    """현재 컨텍스트의 trace_id 반환."""
    return _trace_id.get()


class TraceFilter(logging.Filter):
    """로그 레코드에 trace_id 필드를 추가하는 필터.

    Usage:
        handler = logging.StreamHandler()
        handler.addFilter(TraceFilter())
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(trace_id)s] %(levelname)s %(name)s - %(message)s"
        ))
    """

    def filter(self, record: logging.LogRecord) -> bool:
        record.trace_id = get_trace_id() or "-"  # type: ignore[attr-defined]
        return True
