"""
Deep Agent Executor.

DeepAgentExecutor: 탐지 결과를 받아 LangGraph 심층 분석을 실행하는 래퍼.
"""

import logging
import os

from src.agent_server.bdp_common.deep_agent.graph import compile_deep_agent
from src.agent_server.bdp_common.deep_agent.schemas import (
    DeepAnalysisResult,
    DetectionInput,
)

logger = logging.getLogger(__name__)

# 에이전트 타입 → HITL 에이전트 타입 매핑
AGENT_TYPE_TO_HITL = {
    "bdp_airflow": "bdp",
    "bdp_cost": "cost",
    "bdp_drift": "drift",
    "bdp_metrics": "bdp",
    "hdsp_alertmanager": "hdsp",
    "hdsp_metrics": "hdsp",
    "bdp_dashboard": "bdp",
    "hdsp_dashboard": "hdsp",
}


class DeepAgentExecutor:
    """Deep agent 실행기.

    탐지 결과를 받아 LangGraph 기반 심층 분석을 수행합니다.

    Usage:
        executor = DeepAgentExecutor()
        result = executor.run(detection_input)
    """

    def __init__(
        self,
        max_iterations: int = 3,
        hitl_store=None,
        llm_client=None,
        tools=None,
    ):
        """초기화.

        Args:
            max_iterations: 최대 분석 반복 횟수
            hitl_store: HITLStore 인스턴스 (HITL 요청 생성용)
            llm_client: LLMClient 인스턴스 (None이면 환경변수로 자동 생성)
            tools: investigation Tool 딕셔너리 (None이면 Mock Tool 사용)
        """
        self.max_iterations = max_iterations
        self.hitl_store = hitl_store
        self.llm_client = llm_client or self._create_default_llm_client()
        self.compiled_graph = compile_deep_agent(llm_client=self.llm_client, tools=tools)

    @staticmethod
    def _create_default_llm_client():
        """환경변수 기반 기본 LLM 클라이언트 생성."""
        try:
            from src.common.services.llm_client import LLMClient, LLMProvider

            provider_str = os.getenv("LLM_PROVIDER", "mock").lower()
            provider = LLMProvider.MOCK if provider_str == "mock" else LLMProvider.VLLM

            return LLMClient(provider=provider)
        except Exception as e:
            logger.warning(f"LLM 클라이언트 생성 실패, fallback 모드: {e}")
            return None

    def run(self, detection_input: DetectionInput) -> DeepAnalysisResult:
        """심층 분석 실행.

        Args:
            detection_input: 정규화된 탐지 입력

        Returns:
            심층 분석 결과
        """
        logger.info(
            f"Deep analysis 시작: agent={detection_input.agent_type}, "
            f"anomalies={detection_input.total_anomalies}"
        )

        # 초기 상태 생성
        initial_state = {
            "messages": [],
            "detection_input": detection_input.model_dump(),
            "analysis_result": None,
            "confidence_score": 0.0,
            "root_causes": None,
            "recommendations": None,
            "requires_hitl": False,
            "hitl_request_id": None,
            "iteration_count": 0,
            "max_iterations": self.max_iterations,
            "should_continue": True,
            "investigation_queries": [],
            "investigation_results": [],
        }

        # 그래프 실행
        try:
            final_state = self.compiled_graph.invoke(initial_state)
        except Exception as e:
            logger.error(f"Deep analysis 그래프 실행 실패: {e}")
            return DeepAnalysisResult(
                root_causes=[f"분석 실행 오류: {str(e)}"],
                confidence_score=0.0,
                recommendations=["수동 검토 필요"],
                analysis_summary="심층 분석 실행 중 오류 발생",
            )

        # HITL 요청 생성 (필요시)
        hitl_request_id = None
        if final_state.get("requires_hitl") and self.hitl_store:
            hitl_request_id = self._create_hitl_request(detection_input, final_state)

        analysis = final_state.get("analysis_result") or {}

        return DeepAnalysisResult(
            root_causes=final_state.get("root_causes") or [],
            confidence_score=final_state.get("confidence_score", 0.0),
            recommendations=final_state.get("recommendations") or [],
            requires_hitl=final_state.get("requires_hitl", False),
            hitl_request_id=hitl_request_id,
            analysis_summary=analysis.get("summary", ""),
            severity_assessment=analysis.get("severity_assessment", "medium"),
            iterations_used=final_state.get("iteration_count", 1),
        )

    def _create_hitl_request(
        self,
        detection_input: DetectionInput,
        final_state: dict,
    ) -> str | None:
        """HITL 요청 생성."""
        try:
            from src.common.hitl.schemas import (
                HITLAgentType,
                HITLRequestCreate,
                HITLRequestType,
            )

            hitl_agent_type = AGENT_TYPE_TO_HITL.get(detection_input.agent_type, "bdp")

            request = HITLRequestCreate(
                agent_type=HITLAgentType(hitl_agent_type),
                request_type=HITLRequestType.ACTION_APPROVAL,
                title=f"[Deep Analysis] {detection_input.agent_type} 심층 분석 검토 필요",
                description=(
                    f"심층 분석 결과 신뢰도가 낮아 인간 검토가 필요합니다.\n"
                    f"근본 원인: {final_state.get('root_causes', [])}\n"
                    f"신뢰도: {final_state.get('confidence_score', 0):.2f}"
                ),
                payload={
                    "agent_type": detection_input.agent_type,
                    "detection_type": detection_input.detection_type,
                    "root_causes": final_state.get("root_causes", []),
                    "recommendations": final_state.get("recommendations", []),
                    "confidence_score": final_state.get("confidence_score", 0),
                    "total_anomalies": detection_input.total_anomalies,
                },
                expires_in_minutes=120,
                created_by=f"deep-agent-{detection_input.agent_type}",
            )

            hitl_request = self.hitl_store.create(request)
            logger.info(f"Deep analysis HITL 요청 생성: {hitl_request.id}")
            return hitl_request.id

        except Exception as e:
            logger.error(f"Deep analysis HITL 요청 생성 실패: {e}")
            return None
