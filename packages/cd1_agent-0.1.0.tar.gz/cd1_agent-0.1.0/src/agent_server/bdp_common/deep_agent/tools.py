"""
Deep Agent Investigation Tools.

에이전트별 입체적 분석을 위한 Tool 세트.
기존 chat tools를 재사용하고, 에이전트 특화 Tool을 추가 제공.
"""

import json
import logging
import os
import random
from collections.abc import Callable
from datetime import datetime, timedelta
from typing import Any

from src.common.timezone import KST

logger = logging.getLogger(__name__)


# ── 신규 Tool: Airflow Metadata ─────────────────────


def _airflow_metadata_query_mock(
    query_type: str,
    dag_id: str | None,
    hours_back: int,
    limit: int,
) -> dict[str, Any]:
    """Airflow 메타데이터 Mock 데이터."""
    rng = random.Random(f"airflow_{query_type}_{dag_id}")
    now = datetime.now(KST)

    if query_type == "dag_runs":
        runs = []
        for i in range(min(limit, 10)):
            state = rng.choice(["success", "success", "success", "failed", "running"])
            duration = rng.randint(30, 600)
            runs.append(
                {
                    "dag_id": dag_id or f"etl_pipeline_{i}",
                    "run_id": f"scheduled__2026-03-22T{10 + i:02d}:00:00",
                    "state": state,
                    "duration_sec": duration,
                    "start_date": (now - timedelta(hours=i)).isoformat(),
                }
            )
        return {"query_type": "dag_runs", "results": runs, "is_mock": True}

    elif query_type == "task_instances":
        tasks = []
        for i in range(min(limit, 15)):
            state = rng.choice(["success", "success", "failed", "up_for_retry", "running"])
            tasks.append(
                {
                    "dag_id": dag_id or "etl_pipeline",
                    "task_id": f"task_{i}",
                    "state": state,
                    "try_number": rng.randint(1, 3) if state == "failed" else 1,
                    "duration_sec": rng.randint(5, 300),
                    "start_date": (now - timedelta(hours=rng.randint(1, hours_back))).isoformat(),
                }
            )
        return {"query_type": "task_instances", "results": tasks, "is_mock": True}

    elif query_type == "sla_violations":
        violations = []
        for i in range(rng.randint(0, 5)):
            violations.append(
                {
                    "dag_id": dag_id or f"critical_dag_{i}",
                    "task_id": f"slow_task_{i}",
                    "sla_target_min": 60,
                    "actual_duration_min": 60 + rng.randint(5, 120),
                    "violation_date": (now - timedelta(days=rng.randint(0, 7))).strftime(
                        "%Y-%m-%d"
                    ),
                }
            )
        return {"query_type": "sla_violations", "results": violations, "is_mock": True}

    return {"error": f"Unknown query_type: {query_type}"}


def _airflow_metadata_query_rds(
    query_type: str,
    dag_id: str | None,
    hours_back: int,
    limit: int,
) -> dict[str, Any]:
    """Airflow 메타데이터 실 RDS 조회."""
    try:
        from src.agent_server.bdp_airflow.services.airflow_failure_store import (
            AirflowFailureStore,
        )

        provider = AirflowFailureStore.create_provider(
            provider_type=os.getenv("BDP_PROVIDER", "mock"),
            secret_id=os.getenv("MWAA_SECRET_ID", ""),
            db=os.getenv("MWAA_DB_NAME", ""),
        )

        rcpt_types = [t.strip() for t in os.getenv("MWAA_RCPT_TYPES", "dlk,wfl").split(",")]

        if query_type == "dag_runs":
            all_records = []
            for rcpt_tp in rcpt_types:
                records = provider.get_failures(rcpt_tp=rcpt_tp, hours=hours_back)
                if dag_id:
                    records = [r for r in records if r.dag_id == dag_id]
                all_records.extend(records)

            # DAG별 실행 요약
            dag_runs: dict[str, dict] = {}
            for r in all_records:
                key = f"{r.dag_id}_{r.run_id or r.start_date}"
                if key not in dag_runs:
                    dag_runs[key] = {
                        "dag_id": r.dag_id,
                        "run_id": r.run_id or "N/A",
                        "state": r.state,
                        "duration_sec": r.duration_seconds or 0,
                        "start_date": r.start_date,
                        "environment": r.rcpt_tp,
                    }
                elif r.is_failed:
                    dag_runs[key]["state"] = r.state

            results = sorted(dag_runs.values(), key=lambda x: x["start_date"], reverse=True)
            return {"query_type": "dag_runs", "results": results[:limit], "is_mock": False}

        elif query_type == "task_instances":
            all_records = []
            for rcpt_tp in rcpt_types:
                records = provider.get_failures(rcpt_tp=rcpt_tp, hours=hours_back)
                if dag_id:
                    records = [r for r in records if r.dag_id == dag_id]
                all_records.extend(records)

            results = [
                {
                    "dag_id": r.dag_id,
                    "task_id": r.task_id,
                    "state": r.state,
                    "duration_sec": r.duration_seconds or 0,
                    "start_date": r.start_date,
                    "err_msg": r.err_msg[:200] if r.err_msg else "",
                    "environment": r.rcpt_tp,
                }
                for r in sorted(all_records, key=lambda x: x.start_date, reverse=True)[:limit]
            ]
            return {"query_type": "task_instances", "results": results, "is_mock": False}

        elif query_type == "sla_violations":
            # SLA 데이터는 별도 테이블 또는 duration 기반 추정
            all_records = []
            for rcpt_tp in rcpt_types:
                history = provider.get_failures(rcpt_tp=rcpt_tp, hours=hours_back)
                if dag_id:
                    history = [r for r in history if r.dag_id == dag_id]
                all_records.extend(history)

            # Duration이 비정상적으로 긴 건을 SLA 위반 후보로
            violations = []
            for r in all_records:
                dur = r.duration_seconds
                if dur and dur > 3600:  # 1시간 이상
                    violations.append(
                        {
                            "dag_id": r.dag_id,
                            "task_id": r.task_id,
                            "actual_duration_min": round(dur / 60, 1),
                            "start_date": r.start_date,
                            "state": r.state,
                        }
                    )
            return {"query_type": "sla_violations", "results": violations[:limit], "is_mock": False}

        return {"error": f"Unknown query_type: {query_type}"}

    except Exception as e:
        logger.error(f"Airflow RDS 조회 실패, Mock fallback: {e}")
        return _airflow_metadata_query_mock(query_type, dag_id, hours_back, limit)


def airflow_metadata_query(
    query_type: str = "dag_runs",
    dag_id: str | None = None,
    hours_back: int = 24,
    limit: int = 20,
    **kwargs: Any,
) -> dict[str, Any]:
    """Airflow 메타데이터 DB 조회 (DAG/Task 실행 이력).

    Args:
        query_type: dag_runs, task_instances, sla_violations
        dag_id: 특정 DAG ID (None이면 전체)
        hours_back: 조회 기간 (시간)
        limit: 최대 결과 수
    """
    provider_type = os.getenv("BDP_PROVIDER", "mock")
    if provider_type == "mock":
        return _airflow_metadata_query_mock(query_type, dag_id, hours_back, limit)
    return _airflow_metadata_query_rds(query_type, dag_id, hours_back, limit)


def airflow_log_context(
    dag_id: str,
    task_id: str | None = None,
    hours_back: int = 6,
    keywords: list[str] | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Airflow 로그에서 에러 컨텍스트 검색.

    Args:
        dag_id: DAG ID
        task_id: Task ID (None이면 DAG 전체)
        hours_back: 조회 기간 (시간)
        keywords: 검색 키워드 (None이면 에러 관련 기본 키워드)
    """
    try:
        log_provider = os.getenv("LOG_PROVIDER", "mock")
        from src.agent_server.bdp_airflow.services.log_analyzer import AirflowLogAnalyzer

        analyzer = AirflowLogAnalyzer(use_mock=log_provider == "mock")
        results = analyzer.search_error_context(
            dag_id=dag_id,
            task_id=task_id,
            hours=hours_back,
            keywords=keywords or ["ERROR", "CRITICAL", "Exception", "Traceback", "OOM", "SIGKILL"],
        )
        return {
            "dag_id": dag_id,
            "task_id": task_id,
            "log_entries": results[:20],
            "total_matches": len(results),
            "is_mock": log_provider == "mock",
        }
    except Exception as e:
        logger.error(f"Airflow 로그 조회 실패: {e}")
        return {
            "dag_id": dag_id,
            "error": str(e),
            "log_entries": [],
        }


def airflow_infra_health(
    component: str = "all",
    **kwargs: Any,
) -> dict[str, Any]:
    """MWAA 인프라 컴포넌트 건강 상태 조회.

    Args:
        component: scheduler, worker, webserver, database, all
    """
    try:
        from src.common.chat.tools.cloudwatch import create_cloudwatch_tools
        from src.common.services.aws_client import AWSClient, AWSProvider

        provider = AWSProvider(os.getenv("AWS_PROVIDER", "mock"))
        aws_client = AWSClient(provider=provider)
        cw_tools = create_cloudwatch_tools(aws_client)

        health = {}
        mwaa_env = os.getenv("MWAA_ENVIRONMENT_NAME", "cd1-mwaa")
        components = (
            ["scheduler", "worker", "webserver", "database"] if component == "all" else [component]
        )

        for comp in components:
            metrics_map = {
                "scheduler": [
                    ("SchedulerHeartbeat", "AWS/MWAA"),
                    ("QueuedTasks", "AWS/MWAA"),
                ],
                "worker": [
                    ("CPUUtilization", "AWS/MWAA"),
                    ("MemoryUtilization", "AWS/MWAA"),
                ],
                "webserver": [
                    ("WebserverResponseTime", "AWS/MWAA"),
                ],
                "database": [
                    ("DatabaseConnections", "AWS/MWAA"),
                ],
            }

            comp_health = {"component": comp, "metrics": []}
            for metric_name, namespace in metrics_map.get(comp, []):
                if "cloudwatch_metrics" in cw_tools:
                    try:
                        result = cw_tools["cloudwatch_metrics"](
                            namespace=namespace,
                            metric_name=metric_name,
                            dimensions={"Environment": mwaa_env},
                            hours=1,
                        )
                        comp_health["metrics"].append({"name": metric_name, "data": result})
                    except Exception:
                        comp_health["metrics"].append({"name": metric_name, "error": "조회 실패"})
            health[comp] = comp_health

        return {"environment": mwaa_env, "components": health}

    except Exception as e:
        logger.error(f"MWAA 인프라 건강 조회 실패: {e}")
        return {"error": str(e), "components": {}}


# ── 신규 Tool: Cost Explorer ─────────────────────────


def cost_explorer_query(
    granularity: str = "DAILY",
    service_filter: str | None = None,
    days_back: int = 30,
    **kwargs: Any,
) -> dict[str, Any]:
    """AWS Cost Explorer 심층 비용 조회.

    Args:
        granularity: DAILY or MONTHLY
        service_filter: 특정 서비스 필터 (예: "Amazon RDS")
        days_back: 조회 기간 (일)
    """
    rng = random.Random(f"cost_{service_filter}_{days_back}")
    services = (
        [service_filter]
        if service_filter
        else [
            "Amazon EC2",
            "Amazon RDS",
            "Amazon S3",
            "AWS Lambda",
            "Amazon SageMaker",
            "Amazon EMR",
            "Amazon MSK",
        ]
    )

    daily_data = []
    for day_offset in range(min(days_back, 14)):
        date = (datetime.now(KST) - timedelta(days=day_offset)).strftime("%Y-%m-%d")
        for svc in services:
            base_cost = rng.uniform(10, 500)
            daily_data.append(
                {
                    "date": date,
                    "service": svc,
                    "cost_usd": round(base_cost, 2),
                    "usage_type": "hours" if svc in ("Amazon EC2", "Amazon RDS") else "requests",
                }
            )

    total = sum(d["cost_usd"] for d in daily_data)
    return {
        "granularity": granularity,
        "service_filter": service_filter,
        "total_cost_usd": round(total, 2),
        "daily_breakdown": daily_data[:50],
        "top_services": sorted(
            {d["service"] for d in daily_data},
            key=lambda s: sum(d["cost_usd"] for d in daily_data if d["service"] == s),
            reverse=True,
        )[:5],
        "is_mock": True,
    }


# ── 신규 Tool: Config Comparison ─────────────────────


def config_comparison(
    resource_type: str = "rds",
    resource_id: str = "",
    **kwargs: Any,
) -> dict[str, Any]:
    """구성 변경 비교 (baseline vs 현재 상태).

    Args:
        resource_type: eks, msk, rds, sagemaker, vpc
        resource_id: 리소스 식별자
    """
    # Mock 데이터
    drifted_fields = {
        "rds": [
            {
                "field": "instance_class",
                "baseline": "db.r5.large",
                "current": "db.r5.xlarge",
                "severity": "medium",
            },
            {"field": "max_connections", "baseline": "200", "current": "500", "severity": "low"},
        ],
        "eks": [
            {"field": "node_count", "baseline": "3", "current": "5", "severity": "low"},
            {
                "field": "instance_type",
                "baseline": "m5.xlarge",
                "current": "m5.2xlarge",
                "severity": "medium",
            },
        ],
        "msk": [
            {"field": "broker_count", "baseline": "3", "current": "3", "severity": "none"},
            {"field": "ebs_volume_size", "baseline": "100", "current": "200", "severity": "low"},
        ],
    }

    fields = drifted_fields.get(
        resource_type,
        [
            {"field": "unknown", "baseline": "N/A", "current": "N/A", "severity": "unknown"},
        ],
    )

    has_drift = any(f["severity"] != "none" for f in fields)

    return {
        "resource_type": resource_type,
        "resource_id": resource_id or f"{resource_type}-default",
        "has_drift": has_drift,
        "drifted_fields": fields,
        "total_fields_checked": len(fields) + 10,
        "last_baseline_update": "2026-03-15T10:00:00+09:00",
        "is_mock": True,
    }


# ── 신규 Tool: Alert History ─────────────────────────


def alert_history(
    status: str = "firing",
    severity: str | None = None,
    hours_back: int = 24,
    **kwargs: Any,
) -> dict[str, Any]:
    """Prometheus Alertmanager 알림 이력 조회.

    Args:
        status: firing, resolved, all
        severity: critical, warning, info (None이면 전체)
        hours_back: 조회 기간 (시간)
    """
    rng = random.Random(f"alerts_{status}_{severity}")
    now = datetime.now(KST)

    alerts = []
    alert_templates = [
        {
            "name": "PodCrashLooping",
            "severity": "critical",
            "labels": {"pod": "etl-worker-3", "namespace": "spark"},
        },
        {"name": "NodeMemoryPressure", "severity": "warning", "labels": {"node": "worker-node-2"}},
        {
            "name": "HighCPUUsage",
            "severity": "warning",
            "labels": {"pod": "api-server-1", "namespace": "default"},
        },
        {
            "name": "DiskSpaceLow",
            "severity": "critical",
            "labels": {"node": "worker-node-1", "mount": "/data"},
        },
        {
            "name": "ContainerOOMKilled",
            "severity": "critical",
            "labels": {"pod": "ml-training-5", "namespace": "ml"},
        },
    ]

    for tpl in alert_templates:
        if severity and tpl["severity"] != severity:
            continue
        alert_status = rng.choice(["firing", "firing", "resolved"]) if status == "all" else status
        alerts.append(
            {
                "alert_name": tpl["name"],
                "severity": tpl["severity"],
                "status": alert_status,
                "labels": tpl["labels"],
                "starts_at": (now - timedelta(hours=rng.randint(1, hours_back))).isoformat(),
                "description": f"{tpl['name']} detected on {json.dumps(tpl['labels'])}",
            }
        )

    return {
        "status_filter": status,
        "severity_filter": severity,
        "total_alerts": len(alerts),
        "alerts": alerts,
        "is_mock": True,
    }


# ── Tool 팩토리 ──────────────────────────────────────


def create_investigation_tools(agent_type: str) -> dict[str, Callable]:
    """에이전트 타입에 따라 적절한 investigation Tool 세트 생성.

    기존 chat tools를 재사용하고, 에이전트 특화 Tool을 추가.

    Args:
        agent_type: bdp_metrics, bdp_cost, bdp_drift, bdp_airflow,
                    bdp_dashboard, hdsp_metrics, hdsp_alertmanager, hdsp_dashboard

    Returns:
        Tool 딕셔너리 {tool_name: callable}
    """
    tools: dict[str, Callable] = {}

    # 공통: CloudWatch (BDP 에이전트)
    if agent_type in ("bdp_metrics", "bdp_dashboard", "bdp_airflow"):
        try:
            from src.common.chat.tools.cloudwatch import create_cloudwatch_tools
            from src.common.services.aws_client import AWSClient, AWSProvider

            provider = AWSProvider(os.getenv("AWS_PROVIDER", "mock"))
            aws_client = AWSClient(provider=provider)
            tools.update(create_cloudwatch_tools(aws_client))
        except Exception as e:
            logger.warning(f"CloudWatch tools 로드 실패: {e}")

    # 공통: RDS 이상 탐지 (BDP)
    if agent_type in ("bdp_metrics", "bdp_dashboard"):
        try:
            from src.common.chat.tools.rds import create_rds_tools

            tools.update(create_rds_tools())
        except Exception as e:
            logger.warning(f"RDS tools 로드 실패: {e}")

    # 공통: Prometheus (HDSP)
    if agent_type in ("hdsp_metrics", "hdsp_alertmanager", "hdsp_dashboard"):
        try:
            from src.common.chat.tools.prometheus import create_prometheus_tools

            tools.update(create_prometheus_tools())
        except Exception as e:
            logger.warning(f"Prometheus tools 로드 실패: {e}")

    # 에이전트 특화 Tool
    if agent_type in ("bdp_airflow",):
        tools["airflow_metadata_query"] = airflow_metadata_query
        tools["airflow_log_context"] = airflow_log_context
        tools["airflow_infra_health"] = airflow_infra_health

    if agent_type in ("bdp_cost",):
        tools["cost_explorer_query"] = cost_explorer_query

    if agent_type in ("bdp_drift",):
        tools["config_comparison"] = config_comparison
        try:
            from src.common.chat.tools.drift import create_drift_tools

            tools.update(create_drift_tools())
        except Exception as e:
            logger.warning(f"Drift tools 로드 실패: {e}")

    if agent_type in ("hdsp_alertmanager", "hdsp_dashboard"):
        tools["alert_history"] = alert_history

    # Service Health (공통)
    if agent_type in ("bdp_dashboard", "hdsp_dashboard"):
        try:
            from src.common.chat.tools.service_health import create_service_health_tools
            from src.common.services.aws_client import AWSClient, AWSProvider

            provider = AWSProvider(os.getenv("AWS_PROVIDER", "mock"))
            aws_client = AWSClient(provider=provider)
            tools.update(create_service_health_tools(aws_client))
        except Exception as e:
            logger.warning(f"Service Health tools 로드 실패: {e}")

    logger.info(f"Investigation tools for {agent_type}: {list(tools.keys())}")
    return tools
