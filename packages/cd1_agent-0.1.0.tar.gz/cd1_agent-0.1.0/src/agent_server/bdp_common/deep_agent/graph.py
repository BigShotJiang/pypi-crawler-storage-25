"""
Deep Agent Graph.

LangGraph StateGraph 정의: analyze → assess → 조건분기.
"""

from typing import Literal

from langgraph.graph import END, StateGraph

from src.agent_server.bdp_common.deep_agent.nodes import (
    create_analyze_node,
    create_assess_node,
    create_investigate_node,
    create_plan_investigation_node,
    finalize_node,
    hitl_checkpoint_node,
)
from src.agent_server.bdp_common.deep_agent.state import DeepAgentState


def _after_assess(state: DeepAgentState) -> Literal["hitl_checkpoint", "analyze", "finalize"]:
    """assess 이후 분기 결정."""
    if state.get("requires_hitl", False):
        return "hitl_checkpoint"
    if state.get("should_continue", False):
        return "analyze"
    return "finalize"


def create_deep_agent_graph(llm_client=None, tools=None) -> StateGraph:
    """Deep agent StateGraph 생성.

    Args:
        llm_client: LLMClient 인스턴스 (None이면 fallback만 사용)
        tools: 추가 조사용 Tool 딕셔너리 (None이면 Mock Tool 사용)

    Returns:
        컴파일 전 StateGraph

    그래프 흐름:
        plan_investigation → investigate → analyze → assess → 조건분기
        (LLM이 추가 데이터 필요 판단 → Tool 실행 → 종합 분석)
    """
    workflow = StateGraph(DeepAgentState)

    # 노드 등록 (llm_client를 클로저로 주입)
    workflow.add_node("plan_investigation", create_plan_investigation_node(llm_client))
    workflow.add_node("investigate", create_investigate_node(tools))
    workflow.add_node("analyze", create_analyze_node(llm_client))
    workflow.add_node("assess", create_assess_node(llm_client))
    workflow.add_node("finalize", finalize_node)
    workflow.add_node("hitl_checkpoint", hitl_checkpoint_node)

    # 엔트리 포인트: 먼저 추가 조사 필요성 판단
    workflow.set_entry_point("plan_investigation")

    # 엣지: plan → investigate → analyze → assess
    workflow.add_edge("plan_investigation", "investigate")
    workflow.add_edge("investigate", "analyze")
    workflow.add_edge("analyze", "assess")

    # assess 이후 조건분기
    workflow.add_conditional_edges(
        "assess",
        _after_assess,
        {
            "hitl_checkpoint": "hitl_checkpoint",
            "analyze": "analyze",
            "finalize": "finalize",
        },
    )

    # 종료 엣지
    workflow.add_edge("finalize", END)
    workflow.add_edge("hitl_checkpoint", END)

    return workflow


def compile_deep_agent(llm_client=None, checkpointer=None, tools=None):
    """Deep agent 그래프를 컴파일.

    Args:
        llm_client: LLMClient 인스턴스
        checkpointer: 상태 체크포인터 (HITL resume 용)
        tools: 추가 조사용 Tool 딕셔너리

    Returns:
        컴파일된 그래프
    """
    graph = create_deep_agent_graph(llm_client, tools=tools)
    if checkpointer:
        return graph.compile(checkpointer=checkpointer)
    return graph.compile()
