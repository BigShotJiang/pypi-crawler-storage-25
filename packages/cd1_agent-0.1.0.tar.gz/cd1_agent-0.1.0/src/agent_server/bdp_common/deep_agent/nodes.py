"""
Deep Agent Nodes.

LangGraph 노드 함수: analyze, assess, finalize, hitl_checkpoint.
LLM 클라이언트를 클로저로 주입받아 심층 분석 수행.
"""

import json
import logging
from typing import Any

from langchain_core.messages import AIMessage

from src.agent_server.bdp_common.deep_agent.schemas import (
    LLMAnalysisResponse,
)

logger = logging.getLogger(__name__)

# 에이전트 타입별 시스템 프롬프트
_SYSTEM_PROMPTS = {
    "bdp_airflow": (
        "당신은 Airflow(MWAA) DAG/Task 실패 패턴 전문 분석가입니다. "
        "실패 패턴, 전조증상, Cross-DAG 상관관계를 심층 분석하여 "
        "근본 원인을 파악하고 구체적인 대응 방안을 제시하세요."
    ),
    "bdp_cost": (
        "당신은 AWS 비용 이상 탐지 전문 분석가입니다. "
        "비용 급증의 근본 원인(서비스 확장, 구성 변경, 이상 트래픽 등)을 "
        "파악하고 비용 최적화 권장 사항을 제시하세요."
    ),
    "bdp_drift": (
        "당신은 AWS 인프라 설정 드리프트 전문 분석가입니다. "
        "Glue, Athena, EMR, S3 등의 설정 변경이 의도적인지 판단하고 "
        "보안 및 운영 리스크를 평가하세요."
    ),
    "bdp_metrics": (
        "당신은 CloudWatch 메트릭 이상 탐지 전문 분석가입니다. "
        "MSK, MWAA, EKS, RDS 등 AWS 서비스의 메트릭 드리프트를 분석하여 "
        "성능 저하 원인과 대응 방안을 제시하세요."
    ),
    "hdsp_alertmanager": (
        "당신은 Kubernetes 알림 분석 전문가입니다. "
        "Prometheus Alertmanager에서 수집된 알림의 근본 원인을 분석하고 "
        "클러스터 안정화를 위한 조치를 권장하세요."
    ),
    "hdsp_metrics": (
        "당신은 On-Prem Kubernetes 이상 탐지 전문 분석가입니다. "
        "Pod 장애, 노드 압력, 리소스 이상을 심층 분석하여 "
        "클러스터 안정성 확보를 위한 근본 원인과 대응 방안을 제시하세요."
    ),
    "bdp_dashboard": (
        "당신은 AWS 데이터 플랫폼 통합 모니터링 전문 분석가입니다. "
        "MSK, MWAA, RDS, SageMaker, EMR, Lambda 등 전체 인프라 메트릭의 "
        "이상 패턴을 종합 분석하여 근본 원인과 대응 방안을 제시하세요."
    ),
    "hdsp_dashboard": (
        "당신은 On-Prem Kubernetes 플랫폼 통합 모니터링 전문 분석가입니다. "
        "Jupyter, Spark, MinIO, EKS 리소스, API 성능 등 HDSP 전체 메트릭의 "
        "이상 패턴을 종합 분석하여 근본 원인과 대응 방안을 제시하세요."
    ),
}


def _get_system_prompt(agent_type: str) -> str:
    """에이전트 타입에 맞는 시스템 프롬프트 반환."""
    return _SYSTEM_PROMPTS.get(agent_type, "당신은 인프라 이상 탐지 전문 분석가입니다.")


def _build_user_prompt(
    detection_input: dict[str, Any], investigation_results: list[dict[str, Any]] | None = None
) -> str:
    """탐지 결과를 기반으로 유저 프롬프트 생성."""
    items = detection_input.get("items", [])
    items_json = json.dumps(items[:20], ensure_ascii=False, default=str)

    prompt = (
        f"## 탐지 결과 분석 요청\n\n"
        f"**에이전트**: {detection_input.get('agent_type', 'unknown')}\n"
        f"**탐지 타입**: {detection_input.get('detection_type', 'unknown')}\n"
        f"**총 이상 탐지**: {detection_input.get('total_anomalies', 0)}건\n"
        f"**심각도 분포**: {json.dumps(detection_input.get('severity_breakdown', {}))}\n"
        f"**요약**: {detection_input.get('summary', 'N/A')}\n\n"
        f"## 탐지 항목 (상위 20건)\n```json\n{items_json}\n```\n\n"
    )

    # 추가 조사 결과가 있으면 컨텍스트에 포함
    if investigation_results:
        prompt += "## 추가 조사 결과 (자율 조회)\n\n"
        for inv in investigation_results:
            prompt += f"### {inv.get('tool', 'unknown')} — {inv.get('reason', '')}\n"
            data_str = json.dumps(inv.get("data", {}), ensure_ascii=False, default=str)[:2000]
            prompt += f"```json\n{data_str}\n```\n\n"

    prompt += "위 탐지 결과와 추가 조사 데이터를 종합 분석하여 근본 원인, 권장 조치, 심각도 평가를 제시하세요."
    return prompt


def _build_investigation_prompt(detection_input: dict[str, Any]) -> str:
    """LLM에게 추가 조사가 필요한지 판단하도록 하는 프롬프트."""
    items = detection_input.get("items", [])
    items_json = json.dumps(items[:10], ensure_ascii=False, default=str)

    return (
        f"## 추가 데이터 조사 필요성 판단\n\n"
        f"**에이전트**: {detection_input.get('agent_type', 'unknown')}\n"
        f"**탐지 타입**: {detection_input.get('detection_type', 'unknown')}\n"
        f"**탐지 항목 (상위 10건)**:\n```json\n{items_json}\n```\n\n"
        f"근본 원인을 파악하기 위해 추가로 조회해야 할 데이터가 있는지 판단하세요.\n\n"
        f"사용 가능한 Tool:\n"
        f"- `cloudwatch_metrics`: CloudWatch 메트릭 조회 (params: namespace, metric_name, dimensions, hours)\n"
        f"- `cloudwatch_logs`: CloudWatch 로그 검색 (params: log_group, filter_pattern, hours)\n"
        f"- `rds_anomalies`: 최근 이상 탐지 결과 조회 (params: service_name, severity)\n"
        f"- `drift_status`: 구성 변경 상태 확인 (params: resource_type, resource_id)\n\n"
        f"예시: MSK CPU 높으면 Consumer Lag, Disk 사용률도 확인. "
        f"RDS 연결 수 급증이면 최근 배포/변경 이력 확인. "
        f"MWAA Scheduler CPU 높으면 DAG 파싱 에러도 확인."
    )


def _fallback_analysis(detection_input: dict[str, Any]) -> dict[str, Any]:
    """LLM 실패 시 구조적 휴리스틱 분석."""
    items = detection_input.get("items", [])
    severity_breakdown = detection_input.get("severity_breakdown", {})
    agent_type = detection_input.get("agent_type", "unknown")

    # 심각도별 항목 집계
    critical_items = [i for i in items if i.get("severity") == "critical"]
    high_items = [i for i in items if i.get("severity") == "high"]

    root_causes = []
    recommendations = []

    if critical_items:
        resources = list({i.get("resource_id", "unknown") for i in critical_items[:5]})
        root_causes.append(
            f"Critical 수준 이상 {len(critical_items)}건 탐지 - 영향 리소스: {', '.join(resources)}"
        )
        recommendations.append("Critical 항목에 대한 즉시 조사 및 대응 필요")

    if high_items:
        resources = list({i.get("resource_id", "unknown") for i in high_items[:5]})
        root_causes.append(
            f"High 수준 이상 {len(high_items)}건 탐지 - 영향 리소스: {', '.join(resources)}"
        )
        recommendations.append("High 항목에 대한 모니터링 강화 권장")

    if not root_causes:
        root_causes.append(f"{agent_type} 에이전트에서 이상 탐지됨")
        recommendations.append("탐지 결과에 대한 상세 검토 권장")

    total = sum(severity_breakdown.values()) if severity_breakdown else len(items)
    critical_count = severity_breakdown.get("critical", 0)
    confidence = min(0.9, 0.5 + (critical_count / max(total, 1)) * 0.3)

    return {
        "root_causes": root_causes,
        "recommendations": recommendations,
        "confidence": confidence,
        "severity_assessment": "critical" if critical_count > 0 else "high",
        "summary": detection_input.get("summary", "구조적 분석 결과"),
    }


def create_analyze_node(llm_client):
    """analyze 노드 팩토리. LLM 클라이언트를 클로저로 캡처."""

    def analyze_node(state: dict[str, Any]) -> dict[str, Any]:
        """LLM으로 근본 원인 추론 + 구조적 보완."""
        detection_input = state["detection_input"]
        iteration = state.get("iteration_count", 0) + 1

        logger.info(f"[analyze] iteration={iteration}, agent={detection_input.get('agent_type')}")

        system_prompt = _get_system_prompt(detection_input.get("agent_type", ""))
        investigation_results = state.get("investigation_results", [])
        user_prompt = _build_user_prompt(detection_input, investigation_results or None)

        analysis = None
        try:
            if llm_client is not None:
                analysis = llm_client.generate_structured(
                    prompt=user_prompt,
                    response_model=LLMAnalysisResponse,
                    system_prompt=system_prompt,
                    temperature=0.3,
                )
        except Exception as e:
            logger.warning(f"[analyze] LLM 호출 실패, fallback 사용: {e}")

        if analysis is not None:
            result = {
                "root_causes": analysis.root_causes,
                "recommendations": analysis.recommendations,
                "confidence": analysis.confidence,
                "severity_assessment": analysis.severity_assessment,
                "summary": analysis.summary,
            }
        else:
            result = _fallback_analysis(detection_input)

        return {
            "analysis_result": result,
            "root_causes": result["root_causes"],
            "recommendations": result["recommendations"],
            "confidence_score": result["confidence"],
            "iteration_count": iteration,
            "messages": [
                AIMessage(content=f"[Deep Analysis] iteration={iteration}: {result['summary']}")
            ],
        }

    return analyze_node


def create_assess_node(llm_client=None):
    """assess 노드 팩토리."""

    def assess_node(state: dict[str, Any]) -> dict[str, Any]:
        """분석 결과 신뢰도 평가 및 HITL 필요성 판단."""
        confidence = state.get("confidence_score", 0.0)
        iteration = state.get("iteration_count", 0)
        max_iterations = state.get("max_iterations", 3)
        analysis = state.get("analysis_result", {})

        severity = analysis.get("severity_assessment", "medium")

        # HITL 필요 조건: critical 심각도 + 낮은 신뢰도
        requires_hitl = severity == "critical" and confidence < 0.7

        # 재분석 조건: 신뢰도 부족 + 반복 한도 미도달
        should_continue = confidence < 0.6 and iteration < max_iterations

        logger.info(
            f"[assess] confidence={confidence:.2f}, severity={severity}, "
            f"requires_hitl={requires_hitl}, should_continue={should_continue}"
        )

        return {
            "requires_hitl": requires_hitl,
            "should_continue": should_continue,
        }

    return assess_node


def finalize_node(state: dict[str, Any]) -> dict[str, Any]:
    """최종 결과 산출."""
    logger.info("[finalize] 최종 결과 생성")
    return {
        "should_continue": False,
    }


def hitl_checkpoint_node(state: dict[str, Any]) -> dict[str, Any]:
    """HITL 상태 표시 후 종료."""
    logger.info("[hitl_checkpoint] HITL 요청 대기 상태")
    return {
        "should_continue": False,
    }


def create_plan_investigation_node(llm_client):
    """규칙 기반 추가 조사 계획 수립 노드.

    LLM 호출 없이 탐지 항목의 리소스/메트릭 타입에 따라
    관련 Tool을 명시적으로 결정한다.
    """

    def plan_investigation_node(state: dict[str, Any]) -> dict[str, Any]:
        detection_input = state["detection_input"]

        # 이미 investigation이 수행된 경우 스킵
        if state.get("investigation_results"):
            return {"investigation_queries": []}

        queries = _rule_based_investigation_plan(detection_input)
        if queries:
            logger.info(
                f"[plan_investigation] 규칙 기반 {len(queries)}건 조회 계획: "
                f"{[q['tool'] for q in queries]}"
            )
        return {"investigation_queries": queries}

    return plan_investigation_node


# ── 규칙 기반 조사 계획 ──────────────────────────────


def _rule_based_investigation_plan(detection_input: dict[str, Any]) -> list[dict[str, Any]]:
    """탐지 결과의 리소스/메트릭 패턴에 따라 관련 Tool 조회를 자동 결정."""
    agent_type = detection_input.get("agent_type", "")
    items = detection_input.get("items", [])
    queries: list[dict[str, Any]] = []

    # 탐지 항목에서 리소스 타입 추출
    resource_types = {item.get("raw_data", {}).get("metric_type", "") for item in items}
    resource_ids = {item.get("resource_id", "") for item in items}

    if agent_type == "bdp_metrics":
        queries.extend(_metrics_investigation_rules(items, resource_types))

    elif agent_type == "bdp_cost":
        queries.append(
            {
                "tool": "cost_explorer_query",
                "reason": "비용 급등 서비스별 상세 분석",
                "params": {"granularity": "DAILY", "days_back": 14},
            }
        )

    elif agent_type == "bdp_drift":
        for rid in list(resource_ids)[:3]:
            rtype = rid.split("-")[0] if "-" in rid else "unknown"
            queries.append(
                {
                    "tool": "config_comparison",
                    "reason": f"{rid} 구성 변경 상세 비교",
                    "params": {"resource_type": rtype, "resource_id": rid},
                }
            )

    elif agent_type == "bdp_airflow":
        queries.append(
            {
                "tool": "airflow_metadata_query",
                "reason": "실패 DAG/Task 실행 이력 조회",
                "params": {"query_type": "task_instances", "hours_back": 24},
            }
        )
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "MWAA Scheduler 로그에서 에러 패턴 확인",
                "params": {
                    "log_group": "/aws/mwaa/scheduler",
                    "filter_pattern": "ERROR",
                    "hours": 6,
                },
            }
        )

    elif agent_type == "hdsp_metrics":
        queries.append(
            {
                "tool": "alert_history",
                "reason": "K8s 관련 최근 알림 확인",
                "params": {"status": "firing", "hours_back": 12},
            }
        )

    elif agent_type == "hdsp_alertmanager":
        for item in items[:3]:
            pod = item.get("raw_data", {}).get("labels", {}).get("pod", "")
            if pod:
                queries.append(
                    {
                        "tool": "get_pod_status",
                        "reason": f"{pod} Pod 상태 확인",
                        "params": {"pod_name": pod},
                    }
                )

    elif agent_type in ("bdp_dashboard", "hdsp_dashboard"):
        # Dashboard는 통합 분석이므로 서비스 헬스 체크
        queries.append(
            {
                "tool": "get_service_health",
                "reason": "전체 서비스 헬스 상태 확인",
                "params": {"service_name": "all"},
            }
        )

    return queries[:5]  # 최대 5건


def _metrics_investigation_rules(
    items: list[dict[str, Any]], resource_types: set[str]
) -> list[dict[str, Any]]:
    """BDP Metrics 전용: 메트릭 타입별 연관 데이터 자동 조회 규칙."""
    queries: list[dict[str, Any]] = []

    if "rds" in resource_types or any("rds" in (i.get("resource_id", "").lower()) for i in items):
        queries.append(
            {
                "tool": "cloudwatch_metrics",
                "reason": "RDS CPU 이상 시 연결 수 확인",
                "params": {
                    "namespace": "AWS/RDS",
                    "metric_name": "DatabaseConnections",
                    "hours": 6,
                },
            }
        )
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "RDS 에러 로그 확인 (연결 실패, 데드락 등)",
                "params": {
                    "log_group": _resolve_rds_log_group(items, "error"),
                    "filter_pattern": "ERROR",
                    "hours": 6,
                },
            }
        )
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "RDS 슬로우 쿼리 확인",
                "params": {
                    "log_group": _resolve_rds_log_group(items, "slowquery"),
                    "filter_pattern": "",
                    "hours": 6,
                },
            }
        )

    if "msk" in resource_types or any("msk" in (i.get("resource_id", "").lower()) for i in items):
        queries.append(
            {
                "tool": "cloudwatch_metrics",
                "reason": "MSK CPU 이상 시 Consumer Lag 확인",
                "params": {
                    "namespace": "AWS/Kafka",
                    "metric_name": "EstimatedMaxTimeLag",
                    "hours": 6,
                },
            }
        )
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "MSK 브로커 로그에서 에러 패턴 확인",
                "params": {
                    "log_group": _resolve_msk_log_group(items),
                    "filter_pattern": "ERROR WARN",
                    "hours": 6,
                },
            }
        )

    if "mwaa" in resource_types or any("mwaa" in (i.get("resource_id", "").lower()) for i in items):
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "MWAA Scheduler 에러 로그 확인",
                "params": {
                    "log_group": "/aws/mwaa/scheduler",
                    "filter_pattern": "ERROR CRITICAL",
                    "hours": 6,
                },
            }
        )

    if "eks" in resource_types or any("eks" in (i.get("resource_id", "").lower()) for i in items):
        queries.append(
            {
                "tool": "cloudwatch_logs",
                "reason": "EKS 컨테이너 로그에서 OOMKilled, CrashLoop 확인",
                "params": {
                    "log_group": _resolve_eks_log_group(items),
                    "filter_pattern": "OOMKilled CrashLoopBackOff ERROR",
                    "hours": 6,
                },
            }
        )
        queries.append(
            {
                "tool": "cloudwatch_metrics",
                "reason": "EKS 노드 리소스 사용량 확인",
                "params": {
                    "namespace": "ContainerInsights",
                    "metric_name": "node_cpu_utilization",
                    "hours": 6,
                },
            }
        )

    return queries


def _extract_resource_id(items: list[dict[str, Any]], prefix: str) -> str:
    """아이템에서 prefix를 포함한 첫 번째 resource_id 추출."""
    for item in items:
        rid = item.get("resource_id", "")
        if prefix in rid.lower():
            return rid
    return ""


def _resolve_rds_log_group(items: list[dict[str, Any]], log_type: str) -> str:
    """RDS 리소스 ID에서 로그 그룹 경로 생성."""
    rid = _extract_resource_id(items, "rds")
    if rid:
        return f"/aws/rds/cluster/{rid}/{log_type}"
    return f"/aws/rds/cluster/default/{log_type}"


def _resolve_msk_log_group(items: list[dict[str, Any]]) -> str:
    """MSK 리소스 ID에서 브로커 로그 그룹 경로 생성."""
    rid = _extract_resource_id(items, "msk")
    if rid:
        return f"/aws/msk/{rid}/broker"
    return "/aws/msk/default/broker"


def _resolve_eks_log_group(items: list[dict[str, Any]]) -> str:
    """EKS 리소스 ID에서 컨테이너 로그 그룹 경로 생성."""
    import os as _os

    cluster = _os.getenv("EKS_CLUSTER_NAME", "default")
    return f"/aws/containerinsights/{cluster}/application"


def create_investigate_node(tools: dict[str, Any] | None = None):
    """실제 Tool을 호출하여 추가 데이터를 수집하는 노드."""

    def investigate_node(state: dict[str, Any]) -> dict[str, Any]:
        """investigation_queries에 따라 Tool 실행."""
        queries = state.get("investigation_queries", [])
        if not queries:
            return {"investigation_results": []}

        results = []
        for query in queries:
            tool_name = query.get("tool", "")
            params = query.get("params", {})
            reason = query.get("reason", "")

            logger.info(f"[investigate] Tool={tool_name}, reason={reason}")

            data = _execute_tool(tool_name, params, tools)
            results.append(
                {
                    "tool": tool_name,
                    "reason": reason,
                    "params": params,
                    "data": data,
                }
            )

        logger.info(f"[investigate] {len(results)}건 추가 데이터 수집 완료")
        return {
            "investigation_results": results,
            "messages": [
                AIMessage(content=f"[Investigation] {len(results)}건 추가 데이터 수집 완료")
            ],
        }

    return investigate_node


def _execute_tool(
    tool_name: str, params: dict[str, Any], tools: dict[str, Any] | None
) -> dict[str, Any]:
    """Tool 이름에 따라 데이터 조회 실행."""
    try:
        # 외부 주입된 tools가 있으면 우선 사용
        if tools and tool_name in tools:
            return tools[tool_name](**params)

        # 기본 Mock Tool (실제 AWS 연결 없을 때)
        if tool_name == "cloudwatch_metrics":
            return _mock_cloudwatch_metrics(params)
        elif tool_name == "cloudwatch_logs":
            return _mock_cloudwatch_logs(params)
        elif tool_name == "rds_anomalies":
            return _mock_rds_anomalies(params)
        elif tool_name == "drift_status":
            return _mock_drift_status(params)
        else:
            return {"error": f"Unknown tool: {tool_name}"}
    except Exception as e:
        logger.warning(f"[investigate] Tool {tool_name} 실행 실패: {e}")
        return {"error": str(e)}


def _mock_cloudwatch_metrics(params: dict) -> dict:
    """CloudWatch 메트릭 Mock."""
    return {
        "namespace": params.get("namespace", ""),
        "metric_name": params.get("metric_name", ""),
        "datapoints": [
            {"timestamp": "2026-03-22T10:00:00", "value": 45.2},
            {"timestamp": "2026-03-22T11:00:00", "value": 78.5},
            {"timestamp": "2026-03-22T12:00:00", "value": 92.1},
        ],
        "is_mock": True,
    }


def _mock_cloudwatch_logs(params: dict) -> dict:
    """CloudWatch 로그 Mock."""
    return {
        "log_group": params.get("log_group", ""),
        "events": [
            {"timestamp": "2026-03-22T12:30:00", "message": "[ERROR] Connection pool exhausted"},
            {"timestamp": "2026-03-22T12:31:00", "message": "[WARN] High latency detected: 2500ms"},
        ],
        "is_mock": True,
    }


def _mock_rds_anomalies(params: dict) -> dict:
    """RDS 이상 탐지 Mock."""
    return {
        "service": params.get("service_name", ""),
        "anomalies": [
            {"metric": "DatabaseConnections", "value": 195, "baseline": 50, "severity": "high"},
        ],
        "is_mock": True,
    }


def _mock_drift_status(params: dict) -> dict:
    """Drift 상태 Mock."""
    return {
        "resource_type": params.get("resource_type", ""),
        "has_drift": True,
        "drifted_fields": ["instance_class", "max_connections"],
        "is_mock": True,
    }
