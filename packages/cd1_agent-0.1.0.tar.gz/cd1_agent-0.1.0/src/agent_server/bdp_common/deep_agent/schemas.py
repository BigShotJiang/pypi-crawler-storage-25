"""
Deep Agent Schemas.

탐지 에이전트 공통 심층 분석용 입출력 모델.
"""

from typing import Any

from pydantic import BaseModel, Field


class DetectionItem(BaseModel):
    """개별 탐지 항목."""

    item_type: str = Field(description="항목 타입 (pattern, anomaly, drift, alert)")
    resource_id: str = Field(description="리소스 식별자")
    severity: str = Field(description="심각도 (critical, high, medium, low)")
    title: str = Field(default="", description="항목 제목")
    description: str = Field(default="", description="항목 설명")
    confidence: float = Field(default=0.0, description="탐지 신뢰도")
    raw_data: dict[str, Any] = Field(default_factory=dict, description="원본 데이터")


class DetectionInput(BaseModel):
    """Deep agent 입력."""

    agent_type: str = Field(description="에이전트 타입 (bdp_airflow, bdp_cost, ...)")
    detection_type: str = Field(description="탐지 타입 (airflow_failure, cost_drift, ...)")
    severity: str = Field(default="high", description="전체 심각도")
    summary: str = Field(default="", description="탐지 요약")
    total_anomalies: int = Field(default=0, description="총 이상 탐지 수")
    severity_breakdown: dict[str, int] = Field(
        default_factory=dict,
        description="심각도별 카운트",
    )
    items: list[DetectionItem] = Field(default_factory=list, description="탐지 항목 목록")
    metadata: dict[str, Any] = Field(default_factory=dict, description="추가 메타데이터")


class InvestigationQuery(BaseModel):
    """LLM이 요청하는 추가 데이터 조회."""

    tool: str = Field(
        description="조회 Tool (cloudwatch_metrics, cloudwatch_logs, rds_anomalies, drift_status)"
    )
    reason: str = Field(description="이 데이터가 필요한 이유")
    params: dict[str, Any] = Field(default_factory=dict, description="Tool 파라미터")


class LLMInvestigationPlan(BaseModel):
    """LLM이 추가 조사가 필요한지 판단하는 응답."""

    needs_investigation: bool = Field(default=False, description="추가 데이터 조회 필요 여부")
    queries: list[InvestigationQuery] = Field(
        default_factory=list, description="조회할 데이터 목록"
    )
    reasoning: str = Field(default="", description="추가 조사가 필요한 이유")


class LLMAnalysisResponse(BaseModel):
    """LLM 구조화 응답 모델."""

    root_causes: list[str] = Field(default_factory=list, description="근본 원인 목록")
    recommendations: list[str] = Field(default_factory=list, description="권장 조치 목록")
    confidence: float = Field(default=0.5, ge=0.0, le=1.0, description="분석 신뢰도")
    severity_assessment: str = Field(default="medium", description="심각도 평가")
    summary: str = Field(default="", description="분석 요약")


class DeepAnalysisResult(BaseModel):
    """Deep agent 출력."""

    root_causes: list[str] = Field(default_factory=list, description="근본 원인 목록")
    confidence_score: float = Field(default=0.0, description="전체 신뢰도")
    recommendations: list[str] = Field(default_factory=list, description="권장 조치 목록")
    requires_hitl: bool = Field(default=False, description="HITL 검토 필요 여부")
    hitl_request_id: str | None = Field(default=None, description="HITL 요청 ID")
    analysis_summary: str = Field(default="", description="분석 요약")
    severity_assessment: str = Field(default="medium", description="심각도 평가")
    iterations_used: int = Field(default=1, description="사용된 반복 횟수")
