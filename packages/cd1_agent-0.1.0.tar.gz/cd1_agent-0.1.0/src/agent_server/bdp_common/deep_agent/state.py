"""
Deep Agent State.

LangGraph 심층 분석 에이전트의 상태 정의.
"""

import operator
from collections.abc import Sequence
from typing import Annotated, Any

from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict


class DeepAgentState(TypedDict):
    """Deep agent LangGraph 상태."""

    messages: Annotated[Sequence[BaseMessage], operator.add]
    detection_input: dict[str, Any]
    analysis_result: dict[str, Any] | None
    confidence_score: float
    root_causes: list[str] | None
    recommendations: list[str] | None
    requires_hitl: bool
    hitl_request_id: str | None
    iteration_count: int
    max_iterations: int
    should_continue: bool
    # 입체적 분석: investigate 노드에서 수집한 추가 데이터
    investigation_queries: list[dict[str, Any]]  # LLM이 요청한 추가 조회 목록
    investigation_results: list[dict[str, Any]]  # Tool 실행 결과
