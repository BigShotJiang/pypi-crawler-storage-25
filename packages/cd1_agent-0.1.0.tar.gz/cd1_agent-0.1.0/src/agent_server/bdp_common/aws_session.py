"""Thin re-export for agent_server internal code.

agent_server 내부에서 `from src.agent_server.bdp_common.aws_session import get_boto3_client` 로 사용.
"""

from src.common.services.aws_session import (
    get_boto3_client,
    get_boto3_session,
    get_botocore_session,
)

__all__ = ["get_boto3_client", "get_boto3_session", "get_botocore_session"]
