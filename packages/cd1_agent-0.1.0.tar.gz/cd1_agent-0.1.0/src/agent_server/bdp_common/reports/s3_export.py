"""S3 리포트 내보내기."""

import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)


def _get_report_bucket() -> str:
    """ENVIRONMENT 기반 S3 버킷 이름 결정."""
    env = os.getenv("ENVIRONMENT", "dev").lower()
    if env in ("prd", "prod"):
        return "wdp-bdp-s3-ml-env"
    return "wdd-bdp-s3-ml-env"


def _get_report_prefix(date_str: str | None = None) -> str:
    """리포트 S3 prefix 생성."""
    if not date_str:
        date_str = datetime.now().strftime("%Y%m%d")
    return f"pl2wadmprj/cd1-agent/{date_str}/"


def upload_report_to_s3(
    data: bytes,
    filename: str,
    content_type: str,
    date_str: str | None = None,
) -> tuple[str, str]:
    """S3에 파일 업로드.

    Args:
        data: 업로드할 바이트 데이터
        filename: 파일명
        content_type: MIME 타입
        date_str: 날짜 문자열 (YYYYMMDD). None이면 오늘 날짜.

    Returns:
        (bucket, key) 튜플
    """
    from src.common.services.aws_session import get_boto3_client

    bucket = _get_report_bucket()
    key = f"{_get_report_prefix(date_str)}{filename}"
    get_boto3_client("s3").put_object(
        Bucket=bucket, Key=key, Body=data, ContentType=content_type,
    )
    logger.info("S3 업로드 완료: s3://%s/%s (%d bytes)", bucket, key, len(data))
    return bucket, key


def get_csv_s3_key(report_type: str) -> str:
    """Hive-style CSV S3 key 생성."""
    now = datetime.now()
    return (
        f"pl2wadmprj/cd1-agent/data/"
        f"report_type={report_type}/"
        f"date={now.strftime('%Y-%m-%d')}/"
        f"hour={now.strftime('%H')}/"
        f"data.csv"
    )


def generate_and_upload_report_png(
    report_type: str,
    html: str,
    date_str: str | None = None,
) -> tuple[str, dict[str, str], str]:
    """HTML → PDF → 페이지별 PNG → S3 업로드 파이프라인.

    다중 페이지 PDF를 페이지별로 PNG 변환하여 개별 S3 업로드.

    Args:
        report_type: 리포트 유형 (service_dashboard, infra_dashboard 등)
        html: SVG 기반 HTML 문자열
        date_str: 날짜 문자열 (YYYYMMDD). None이면 오늘 날짜.

    Returns:
        (bucket, files_dict, pdf_key) 튜플
        files_dict: {"image1": "s3_key1", "image2": "s3_key2", ...}
        pdf_key: PDF S3 key
    """
    from src.common.services.aws_session import get_boto3_client

    from .pdf import html_to_pdf
    from .png import pdf_to_pngs

    now = datetime.now()
    date_str_path = now.strftime("%Y%m%d")
    time_str = now.strftime("%H%M")
    prefix = f"pl2wadmprj/cd1-agent/assets/{report_type}/{date_str_path}/{time_str}"

    logger.info("PNG 생성 파이프라인 시작: %s (prefix=%s)", report_type, prefix)

    # 1. HTML → PDF (2500mm 페이지 단위)
    pdf_bytes = html_to_pdf(html, fit_single_page=True)
    logger.info("PDF 생성 완료: %d bytes", len(pdf_bytes))

    # 2. PDF 마지막 페이지 축소 + 페이지별 PNG 변환
    png_list, trimmed_pdf = pdf_to_pngs(pdf_bytes)

    # 3. 축소된 PDF → S3
    bucket = _get_report_bucket()
    s3_client = get_boto3_client("s3")

    pdf_key = f"{prefix}/report.pdf"
    s3_client.put_object(
        Bucket=bucket, Key=pdf_key, Body=trimmed_pdf, ContentType="application/pdf",
    )
    logger.info("S3 PDF 업로드: s3://%s/%s (%d bytes)", bucket, pdf_key, len(trimmed_pdf))

    # 4. 각 PNG를 S3에 병렬 업로드
    from concurrent.futures import ThreadPoolExecutor

    def _upload(idx_png: tuple[int, bytes]) -> tuple[str, str]:
        i, png_bytes = idx_png
        key = f"{prefix}/image{i}.png"
        s3_client.put_object(
            Bucket=bucket, Key=key, Body=png_bytes, ContentType="image/png",
        )
        logger.info("S3 업로드: s3://%s/%s (%d bytes)", bucket, key, len(png_bytes))
        return f"image{i}", key

    with ThreadPoolExecutor(max_workers=2) as pool:
        files_dict = dict(pool.map(_upload, enumerate(png_list, start=1)))

    logger.info(
        "PNG 파이프라인 완료: %s → %d pages, S3 prefix=%s",
        report_type, len(png_list), prefix,
    )
    return bucket, files_dict, pdf_key
