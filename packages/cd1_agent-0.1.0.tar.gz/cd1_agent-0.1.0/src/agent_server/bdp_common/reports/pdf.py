"""HTML → PDF 변환 유틸리티.

WeasyPrint의 stylesheets 파라미터로 PDF 전용 CSS를 주입하여
HTML 브라우저 렌더링과 동일한 결과를 생성한다.
"""

import logging
import os
import re
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import cairosvg
from weasyprint import CSS, HTML
from weasyprint.text.fonts import FontConfiguration

logger = logging.getLogger(__name__)

# Google Fonts CDN <link> 태그 제거 패턴
_GFONTS_LINK_RE = re.compile(
    r'<link[^>]+href="https://fonts\.googleapis\.com/[^"]*"[^>]*/?>',
    re.IGNORECASE,
)

# Material Symbols 아이콘 → 텍스트 대체 (웹폰트 없는 환경)
_ICON_RE = re.compile(
    r'<span\s+class="material-symbols-outlined[^"]*"[^>]*>([^<]+)</span>'
)
_ICON_TEXT_MAP: dict[str, str] = {
    "check_circle": "\u2713",
    "check": "\u2713",
    "error": "\u2717",
    "cancel": "\u2717",
    "close": "\u2717",
    "warning": "\u26A0",
    "info": "\u2139",
    "schedule": "\u23F1",
    "timer": "\u23F1",
    "history": "\u23F1",
    "trending_up": "\u2191",
    "trending_down": "\u2193",
    "arrow_forward": "\u2192",
    "priority_high": "\u203C",
    "lightbulb": "\u2605",
    "search": "\u2315",
    "monitoring": "\u25C8",
    "show_chart": "\u25C8",
    "analytics": "\u25C8",
    "dashboard": "\u25A3",
    "settings": "\u2699",
    "security": "\u26BF",
    "cloud": "\u2601",
    "dns": "\u25A3",
    "hard_drive": "\u25A3",
    "lan": "\u25A3",
    "build": "\u2692",
    "bolt": "\u26A1",
    "rocket_launch": "\u2B06",
    "near_me": "\u27A4",
    "location_on": "\u25C9",
    "business": "\u25A3",
    "folder": "\u25A3",
    "description": "\u25A3",
    "label": "\u25CB",
    "air": "\u2248",
    "api": "\u25C8",
    "backup": "\u21BB",
    "chat": "\u25AC",
    "deployed_code": "\u25A3",
    "inventory_2": "\u25A3",
    "remove": "\u2212",
    "repeat": "\u21BB",
    "timeline": "\u25C8",
    "view_in_ar": "\u25A3",
    # 서비스 도메인 아이콘
    "download": "\u2B07",
    "hub": "\u2295",
    "model_training": "\u2699",
    "psychology": "\u25C8",
    "memory": "\u26A1",
    "schema": "\u25C8",
    "work": "\u2699",
    "bar_chart": "\u25C8",
    "payments": "\u25A3",
}

# 인라인 SVG 매칭 패턴
_SVG_RE = re.compile(r'<svg\b[^>]*>.*?</svg>', re.DOTALL)
_VIEWBOX_RE = re.compile(r'viewBox="0 0 ([\d.]+) ([\d.]+)"')


def _rasterize_one_to_file(svg_text: str, scale: int, tmp_dir: str, idx: int) -> tuple[int, str, int, int]:
    """단일 SVG를 PNG 임시 파일로 변환. (idx, file_path, width, height) 반환."""
    vb = _VIEWBOX_RE.search(svg_text)
    img_w, img_h = 700, 240  # fallback
    if vb:
        img_w = int(float(vb.group(1)))
        img_h = int(float(vb.group(2)))
        svg_text = svg_text.replace(
            f'viewBox="0 0 {vb.group(1)} {vb.group(2)}"',
            f'width="{img_w}" height="{img_h}" viewBox="0 0 {vb.group(1)} {vb.group(2)}"',
        )
        svg_text = re.sub(r'width:\s*100%', f'width:{img_w}px', svg_text, count=1)
        svg_text = re.sub(r'height:\s*auto', f'height:{img_h}px', svg_text, count=1)

    png_path = os.path.join(tmp_dir, f"chart_{idx}.png")
    cairosvg.svg2png(
        bytestring=svg_text.encode("utf-8"),
        scale=scale,
        write_to=png_path,
    )
    return idx, png_path, img_w, img_h


def _rasterize_svgs(html: str, scale: int = 1, tmp_dir: str | None = None) -> str:
    """인라인 SVG를 PNG 임시 파일 참조로 병렬 교체 (메모리 절약)."""
    matches: list[re.Match] = list(_SVG_RE.finditer(html))
    if not matches:
        return html
    logger.info("_rasterize_svgs: SVG %d개 발견 (HTML 길이=%d)", len(matches), len(html))

    if tmp_dir is None:
        raise ValueError("tmp_dir is required")

    # SVG 래스터화를 병렬 실행 → 임시 파일에 쓰기
    workers = min(len(matches), 4)
    results: list[tuple[int, str, int, int]] = [None] * len(matches)  # type: ignore[list-item]
    failed: set[int] = set()

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_rasterize_one_to_file, m.group(0), scale, tmp_dir, i): i
            for i, m in enumerate(matches)
        }
        for fut in as_completed(futures):
            i = futures[fut]
            try:
                results[i] = fut.result()
            except Exception:
                logger.exception("SVG 래스터화 실패 (index=%d)", i)
                failed.add(i)

    # 뒤에서부터 치환 (offset 유지)
    result = html
    for i, m in reversed(list(enumerate(matches))):
        if i in failed:
            continue  # 실패한 SVG는 원본 유지
        _, png_path, img_w, img_h = results[i]
        file_uri = Path(png_path).as_uri()
        repl = (
            f'<img src="{file_uri}" '
            f'width="{img_w}" height="{img_h}" '
            f'style="width:100%;height:auto;"/>'
        )
        result = result[:m.start()] + repl + result[m.end():]
    return result

# ── PDF 전용 CSS ──────────────────────────────────────
# HTML 생성 코드는 수정하지 않고, WeasyPrint 렌더링 시에만 적용.

_PDF_CSS = """
/* ── 페이지 설정: A4 가로 ────────────────────────── */
@page {
    size: A4 landscape;
    margin: 12mm;
    @bottom-center {
        content: counter(page) " / " counter(pages);
        font-size: 9px;
        color: #6b7280;
    }
}

/* ── 단일 페이지 (PNG 변환용) ─────────────────────── */
@page single {
    size: 297mm 99999mm;
    margin: 10mm;
}

/* ── 한글 폰트 지정 ─────────────────────────────── */
body {
    font-family: 'Noto Sans CJK KR', 'Noto Sans KR', sans-serif;
}

/* ── 컨테이너 폭 제한 해제 ───────────────────────── */
.container {
    max-width: 100% !important;
}

/* ── 페이지 짤림 방지 ────────────────────────────── */
.stat-card, .chart-wrapper, .card {
    break-inside: avoid;
}

.table tr {
    break-inside: avoid;
}

h2, h3, h4, .card-header {
    break-after: avoid;
}

.header {
    break-after: avoid;
}

/* ── 그리드/테이블 짤림 방지 ──────────────────── */
.grid, .grid-2, .grid-3, .grid-4, .grid-5 {
    break-inside: avoid;
}

/* ── stat-cards 테이블 짤림 방지 ─────────────────── */
table {
    break-inside: avoid;
}

/* ── 데이터 테이블(details) 짤림 방지 ────────────── */
details {
    break-inside: avoid;
}

/* ── 토폴로지 짤림 방지 ─────────────────────────── */
.topo-wrapper {
    break-inside: avoid;
}

/* ── 인쇄 최적화 ────────────────────────────────── */
.card {
    box-shadow: none !important;
    border: 1px solid #e0e0e0 !important;
}

.table tr:hover {
    background: transparent !important;
}
"""


def _prepare_html(html_string: str, svg_scale: int = 1, tmp_dir: str | None = None) -> str:
    """PDF 변환용 HTML 전처리 (공통)."""
    html_string = _GFONTS_LINK_RE.sub("", html_string)
    html_string = _ICON_RE.sub(
        lambda m: _ICON_TEXT_MAP.get(m.group(1).strip(), m.group(1).strip()),
        html_string,
    )
    return _rasterize_svgs(html_string, scale=svg_scale, tmp_dir=tmp_dir)


def html_to_pdf(
    html_string: str,
    *,
    single_page: bool = False,
    fit_single_page: bool = False,
) -> bytes:
    """HTML 문자열을 PDF 바이트로 변환.

    A4 가로 방향, 페이지 번호, 차트 짤림 방지 등
    PDF 전용 스타일이 자동 적용된다.

    SVG 차트는 임시 디렉토리에 PNG 파일로 래스터화하여
    file:// URI로 참조함으로써 메모리 사용량을 최소화한다.

    Args:
        html_string: 변환할 HTML
        single_page: True이면 사실상 무한 높이 단일 페이지로 렌더링 (PNG 변환용)
        fit_single_page: True이면 2500mm 높이의 긴 페이지로 렌더링.
            콘텐츠가 넘치면 2500mm × n 페이지로 자동 분할되며,
            break-inside: avoid 덕분에 차트 단위로 안전하게 나뉨.
    """
    with tempfile.TemporaryDirectory(prefix="cd1_pdf_") as tmp_dir:
        html_string = _prepare_html(html_string, svg_scale=3, tmp_dir=tmp_dir)

        font_config = FontConfiguration()
        css_string = _PDF_CSS
        if single_page:
            css_string += "\nbody { page: single; }"
        elif fit_single_page:
            css_string += """
@page longpage {
    size: 297mm 2500mm;
    margin: 0;
    @bottom-center { content: none; }
}
body { page: longpage; }
"""
        pdf_css = CSS(string=css_string, font_config=font_config)
        return HTML(string=html_string).write_pdf(
            stylesheets=[pdf_css],
            font_config=font_config,
            optimize_size=("fonts",),
        )
