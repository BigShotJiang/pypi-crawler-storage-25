"""Reports module."""

from .base import HTMLReportBase
from .styles import ReportStyles, SEVERITY_COLORS

__all__ = ["HTMLReportBase", "ReportStyles", "SEVERITY_COLORS"]
