"""Email-specific HTML utilities.

이메일 클라이언트(Outlook, Gmail 등)가 인라인 SVG를 제거하므로
SVG → PNG(base64) 변환 기능을 제공합니다.

EventBridge Detail 크기 제한(256KB)에 맞추기 위해
PNG 출력 해상도를 제한합니다.
"""

import base64
import logging
import re

logger = logging.getLogger(__name__)

# EventBridge 256KB 제한 대응: 이메일용 PNG 최대 너비 (px)
# 700px 원본 → 350px로 축소하면 PNG 크기 ~60% 감소
_MAX_EMAIL_IMG_WIDTH = 350

_SVG_PATTERN = re.compile(r"<svg\b[^>]*>.*?</svg>", re.DOTALL)
_VIEWBOX_PATTERN = re.compile(
    r'viewBox=["\'](-?[\d.]+)\s+(-?[\d.]+)\s+([\d.]+)\s+([\d.]+)["\']'
)

_SVG_PLACEHOLDER = (
    '<div style="background:#f3f4f6;border:1px solid #e5e7eb;border-radius:8px;'
    'padding:24px;text-align:center;color:#6b7280;font-size:13px;">'
    '&#128202; 차트를 표시하려면 cairosvg 설치가 필요합니다</div>'
)


def _fix_svg_dimensions(svg: str) -> str:
    """cairosvg 변환을 위해 SVG의 percentage/auto 크기를 고정 크기로 치환.

    cairosvg는 CSS percentage width를 해석하지 못해 빈 이미지를 생성하므로,
    viewBox에서 크기를 추출하여:
    1. SVG 태그에 width/height **속성** 추가 (cairosvg 출력 크기 결정)
    2. style 내 CSS width/height도 고정값으로 치환 (font-family 등 보존)
    """
    if 'width:100%' not in svg and 'width: 100%' not in svg:
        return svg

    vb = _VIEWBOX_PATTERN.search(svg)
    if not vb:
        return svg

    w, h = vb.group(3), vb.group(4)
    # SVG 태그에 width/height 속성 추가 (cairosvg가 출력 크기를 결정하는 기준)
    svg = re.sub(r'<svg\b', f'<svg width="{w}" height="{h}"', svg, count=1)
    # style 속성 내 CSS 값도 고정값으로 치환 (font-family 등 다른 속성 보존)
    svg = re.sub(r'width:\s*100%', f'width:{w}px', svg, count=1)
    svg = re.sub(r'height:\s*auto', f'height:{h}px', svg, count=1)
    # max-width 제거 (cairosvg에 불필요)
    svg = re.sub(r'max-width:\s*[\d.]+px;?\s*', '', svg, count=1)
    return svg


def convert_svgs_to_images(html: str) -> str:
    """HTML 내 인라인 SVG를 base64 PNG <img>로 변환 (이메일 호환).

    cairosvg가 설치되지 않은 경우 SVG를 placeholder로 대체.
    """
    try:
        import cairosvg
    except ImportError:
        logger.error(
            "cairosvg not installed — email charts will not render. "
            "Install: pip install cairosvg (+ brew install cairo on macOS)"
        )
        return _SVG_PATTERN.sub(_SVG_PLACEHOLDER, html)

    def _replace(match: re.Match) -> str:
        svg = _fix_svg_dimensions(match.group(0))
        try:
            kwargs: dict = {}
            vb = _VIEWBOX_PATTERN.search(svg)
            if vb:
                try:
                    orig_w = float(vb.group(3))
                    orig_h = float(vb.group(4))
                    # 이메일용 해상도 제한 (EventBridge 256KB 제한 대응)
                    if orig_w > _MAX_EMAIL_IMG_WIDTH:
                        scale = _MAX_EMAIL_IMG_WIDTH / orig_w
                        kwargs["output_width"] = _MAX_EMAIL_IMG_WIDTH
                        kwargs["output_height"] = int(orig_h * scale)
                    else:
                        kwargs["output_width"] = int(orig_w)
                        kwargs["output_height"] = int(orig_h)
                except ValueError:
                    pass
            png_bytes = cairosvg.svg2png(bytestring=svg.encode("utf-8"), **kwargs)
            if len(png_bytes) < 500:
                logger.warning("SVG→PNG result suspiciously small (%d bytes), may be blank", len(png_bytes))
            b64 = base64.b64encode(png_bytes).decode("ascii")
            return f'<img src="data:image/png;base64,{b64}" style="max-width:100%;height:auto;">'
        except Exception:
            logger.warning("Failed to convert SVG to PNG, using placeholder", exc_info=True)
            return _SVG_PLACEHOLDER

    result = _SVG_PATTERN.sub(_replace, html)
    # HTML 최소화: 연속 공백/개행 축소 (EventBridge 256KB 제한 대응)
    result = re.sub(r">\s+<", "> <", result)
    result = re.sub(r"\s{2,}", " ", result)
    result_kb = len(result.encode("utf-8")) / 1024
    logger.info("SVG→PNG 변환 완료: %.0f KB (EventBridge 제한: 256KB)", result_kb)
    if result_kb > 240:
        logger.warning("변환 후 HTML이 %.0f KB — EventBridge 256KB 제한에 근접", result_kb)
    return result
