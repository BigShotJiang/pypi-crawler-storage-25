"""PDF → PNG 변환."""

import logging

logger = logging.getLogger(__name__)


def pdf_to_png(pdf_bytes: bytes, dpi: int = 150) -> bytes:
    """단일 페이지 PDF를 PNG로 변환 (하위 호환용).

    Args:
        pdf_bytes: PDF 바이트 데이터
        dpi: 출력 해상도 (기본 100dpi)

    Returns:
        PNG 바이트 데이터
    """
    import fitz  # pymupdf

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    page = doc[0]
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    pix = page.get_pixmap(matrix=mat)
    png_bytes = pix.tobytes("png")
    logger.info("PDF→PNG 변환 완료: %d bytes (dpi=%d)", len(png_bytes), dpi)
    return png_bytes


def _find_content_end(page) -> float:
    """페이지의 콘텐츠 하단 y좌표(pt)를 찾는다.

    가장 면적이 큰 도형(body 배경)을 제외하고,
    텍스트 블록 + 도형의 최대 y좌표를 반환.
    """
    page_h = page.mediabox.height

    # 텍스트 블록 max y
    blocks = page.get_text("dict")["blocks"]
    text_max_y = max(b["bbox"][3] for b in blocks) if blocks else 0

    # 도형: 가장 큰 rect(body 배경) 제외
    drawings = page.get_drawings()
    if not drawings:
        return text_max_y

    largest_area = 0
    largest_idx = -1
    for idx, d in enumerate(drawings):
        r = d["rect"]
        area = (r[2] - r[0]) * (r[3] - r[1])
        if area > largest_area:
            largest_area = area
            largest_idx = idx

    draw_max_y = 0
    for idx, d in enumerate(drawings):
        if idx == largest_idx:
            continue
        y2 = d["rect"][3]
        if y2 > draw_max_y:
            draw_max_y = y2

    return max(text_max_y, draw_max_y)


def pdf_to_pngs(pdf_bytes: bytes, dpi: int = 150) -> tuple[list[bytes], bytes]:
    """다중 페이지 PDF → 페이지별 여백 제거 → PNG 리스트.

    각 페이지에서 콘텐츠 끝을 측정하여 하단 여백을 clip으로 제거.
    축소된 PDF bytes도 함께 반환 (S3 업로드용).

    Args:
        pdf_bytes: PDF 바이트 데이터
        dpi: 출력 해상도 (기본 100dpi)

    Returns:
        (png_list, pdf_bytes) 튜플
    """
    import fitz  # pymupdf

    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    total = len(doc)
    render_mat = fitz.Matrix(dpi / 72, dpi / 72)

    pngs: list[bytes] = []
    for i in range(total):
        page = doc[i]
        page_h = page.mediabox.height
        page_w = page.mediabox.width
        content_end = _find_content_end(page)

        if content_end < page_h:
            clip = fitz.Rect(0, 0, page_w, content_end)
            pix = page.get_pixmap(matrix=render_mat, clip=clip)
            removed_mm = (page_h - content_end) / 72 * 25.4
            logger.info(
                "PDF→PNG 페이지 %d/%d: %d bytes, 여백 %.0fmm 제거",
                i + 1, total, len(pix.tobytes("png")), removed_mm,
            )
        else:
            pix = page.get_pixmap(matrix=render_mat)
            logger.info("PDF→PNG 페이지 %d/%d: %d bytes", i + 1, total, len(pix.tobytes("png")))

        pngs.append(pix.tobytes("png"))

    logger.info("PDF→PNG 변환 완료: %d pages (dpi=%d)", len(pngs), dpi)
    return pngs, pdf_bytes
