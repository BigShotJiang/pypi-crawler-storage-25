"""
SVG Chart Utilities for HTML Reports.

인라인 SVG 라인 차트 생성 유틸리티.
BDP/HDSP 대시보드 HTML 리포트에서 공용으로 사용.
"""

import math
from html import escape as html_escape


def _nice_int_max(raw_max: float, n_grid: int = 5) -> float:
    """정수 데이터일 때 그리드에 딱 떨어지는 y_max를 계산."""
    if raw_max <= 0:
        return float(n_grid)
    step = math.ceil(raw_max / n_grid)
    return float(step * n_grid)


# ── Chart Colors (portal의 ENV_COLORS와 동일) ──────────
CHART_COLORS = [
    "#2563eb",  # blue-600
    "#16a34a",  # green-600
    "#d97706",  # amber-600
    "#dc2626",  # red-600
    "#7c3aed",  # violet-600
]

# ── DAG Stacked Bar Colors (대시보드 DagDurationSingleChart와 동일) ──
DAG_STACK_COLORS = [
    "#2563eb",
    "#16a34a",
    "#d97706",
    "#dc2626",
    "#7c3aed",
    "#0891b2",
    "#db2777",
    "#65a30d",
    "#ea580c",
    "#6366f1",
]

# ── Cost Colors (portal의 COST_COLORS와 동일, DAG_STACK_COLORS alias) ──
COST_COLORS = DAG_STACK_COLORS


def _fmt_date(d: str) -> str:
    """YYYY-MM-DD → MM/DD."""
    parts = d.split("-")
    if len(parts) >= 3:
        return f"{parts[1]}/{parts[2]}"
    return d


def _catmull_rom_to_bezier(coords: list[tuple[float, float]]) -> str:
    """좌표를 SVG polyline path 문자열로 변환 (꺾은선).

    기존 Catmull-Rom 스플라인은 Bezier 제어점이 y_min(0) 아래로
    오버슈트하는 문제가 있어 직선 보간으로 교체.
    """
    if not coords:
        return ""
    path = f"M{coords[0][0]:.1f},{coords[0][1]:.1f}"
    for x, y in coords[1:]:
        path += f" L{x:.1f},{y:.1f}"
    return path


def _svg_line_chart(
    series: dict[str, list[tuple[str, float]]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    y_domain: tuple[float, float] | None = None,
    height: int = 240,
    reference_lines: list[dict] | None = None,
    fill_opacity: float = 0.0,
    y_integer: bool = False,
    right_series: dict[str, list[tuple[str, float]]] | None = None,
    right_y_suffix: str = "",
    right_y_domain: tuple[float, float] | None = None,
    right_colors: list[str] | None = None,
) -> str:
    """인라인 SVG 라인 차트를 생성.

    Args:
        series: {series_name: [(date_str, value), ...]}
        colors: 시리즈별 색상 목록
        title: 차트 제목
        subtitle: 차트 부제목
        y_suffix: Y축 값 접미사 (%, 건, GB, 명 등)
        y_domain: Y축 범위 (min, max). None이면 자동 계산.
        height: 차트 높이 (px)
        reference_lines: 기준선 목록. [{"value": 99.9, "label": "99.9%", "color": "#dc2626"}]
        fill_opacity: 0보다 크면 Area Chart 스타일로 채움 (0.0~1.0)
        right_series: 오른쪽 Y축에 표시할 시리즈. 왼쪽과 동일 포맷.
        right_y_suffix: 오른쪽 Y축 값 접미사
        right_y_domain: 오른쪽 Y축 범위 (min, max). None이면 자동 계산.
        right_colors: 오른쪽 시리즈별 색상 목록
    """
    if not series:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    has_right = bool(right_series)
    width = 700
    pad_l, pad_r, pad_t, pad_b = 45, (45 if has_right else 15), 10, 40
    chart_w = width - pad_l - pad_r
    chart_h = height - pad_t - pad_b

    # 전체 날짜 + Y값 수집
    all_dates: list[str] = []
    all_values: list[float] = []
    for pts in series.values():
        for d, v in pts:
            if d not in all_dates:
                all_dates.append(d)
            all_values.append(v)
    if has_right:
        for pts in right_series.values():
            for d, v in pts:
                if d not in all_dates:
                    all_dates.append(d)
    all_dates.sort()

    if not all_dates or not all_values:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    date_idx = {d: i for i, d in enumerate(all_dates)}
    n_dates = len(all_dates)

    # 정수 데이터 자동 감지
    all_int = y_integer or all(v == int(v) for v in all_values)

    # Y축 범위
    if y_domain:
        y_min, y_max = y_domain
    else:
        y_min = 0
        y_max = max(all_values) if all_values else 1
        if y_max == y_min:
            y_max = y_min + 1
        if all_int:
            y_max = _nice_int_max(max(all_values) if all_values else 1)
        else:
            y_max = y_max * 1.1

    # 오른쪽 Y축 범위
    ry_min: float = 0
    ry_max: float = 1
    right_all_int = False
    if has_right:
        right_all_values = [v for pts in right_series.values() for _, v in pts]
        right_all_int = y_integer or all(v == int(v) for v in right_all_values) if right_all_values else False
        if right_y_domain:
            ry_min, ry_max = right_y_domain
        else:
            ry_min = 0
            ry_max = max(right_all_values) if right_all_values else 1
            if ry_max == ry_min:
                ry_max = ry_min + 1
            if right_all_int:
                ry_max = _nice_int_max(max(right_all_values) if right_all_values else 1)
            else:
                ry_max = ry_max * 1.1
        if not right_colors:
            right_colors = ["#d97706", "#dc2626", "#7c3aed", "#0891b2"]

    # 좌표 변환
    def x_pos(idx: int) -> float:
        if n_dates <= 1:
            return pad_l + chart_w / 2
        return pad_l + (idx / (n_dates - 1)) * chart_w

    def y_pos(val: float) -> float:
        if y_max == y_min:
            return pad_t + chart_h / 2
        ratio = (val - y_min) / (y_max - y_min)
        return pad_t + chart_h - ratio * chart_h

    def y_pos_right(val: float) -> float:
        if ry_max == ry_min:
            return pad_t + chart_h / 2
        ratio = (val - ry_min) / (ry_max - ry_min)
        return pad_t + chart_h - ratio * chart_h

    svg_parts: list[str] = []
    # SVG 헤더와 배경은 범례 계산 후 높이가 확정된 뒤 치환 (placeholder)
    _SVG_HEADER_PH = "<!--SVG_HEADER-->"
    _SVG_BG_PH = "<!--SVG_BG-->"
    svg_parts.append(_SVG_HEADER_PH)
    svg_parts.append(_SVG_BG_PH)

    # 그리드 (수평 5줄)
    n_grid = 5
    for i in range(n_grid + 1):
        gy = pad_t + (i / n_grid) * chart_h
        gval = y_max - (i / n_grid) * (y_max - y_min)
        svg_parts.append(
            f'<line x1="{pad_l}" y1="{gy:.1f}" x2="{width - pad_r}" y2="{gy:.1f}" '
            f'stroke="#e5e7eb" stroke-dasharray="3 3"/>'
        )
        if all_int:
            label = f"{int(round(gval))}{y_suffix}"
        else:
            label = f"{gval:.0f}{y_suffix}" if gval == int(gval) else f"{gval:.1f}{y_suffix}"
        svg_parts.append(
            f'<text x="{pad_l - 5}" y="{gy + 4:.1f}" '
            f'text-anchor="end" font-size="10" fill="#6b7280">{label}</text>'
        )

    # 오른쪽 Y축 레이블
    if has_right:
        for i in range(n_grid + 1):
            gy = pad_t + (i / n_grid) * chart_h
            gval = ry_max - (i / n_grid) * (ry_max - ry_min)
            if right_all_int:
                rlabel = f"{int(round(gval))}{right_y_suffix}"
            else:
                rlabel = f"{gval:.0f}{right_y_suffix}" if gval == int(gval) else f"{gval:.1f}{right_y_suffix}"
            svg_parts.append(
                f'<text x="{width - pad_r + 5}" y="{gy + 4:.1f}" '
                f'text-anchor="start" font-size="10" fill="#6b7280">{rlabel}</text>'
            )

    # X축 레이블 (최대 10개 표시)
    step = max(1, n_dates // 10)
    for i in range(0, n_dates, step):
        xp = x_pos(i)
        svg_parts.append(
            f'<text x="{xp:.1f}" y="{pad_t + chart_h + 14}" '
            f'text-anchor="middle" font-size="10" fill="#6b7280">{_fmt_date(all_dates[i])}</text>'
        )

    # 기준선 (reference lines)
    if reference_lines:
        for ref in reference_lines:
            ref_val = ref.get("value", 0)
            ref_label = ref.get("label", "")
            ref_color = ref.get("color", "#dc2626")
            ry = y_pos(ref_val)
            svg_parts.append(
                f'<line x1="{pad_l}" y1="{ry:.1f}" x2="{width - pad_r}" y2="{ry:.1f}" '
                f'stroke="{ref_color}" stroke-width="1.5" stroke-dasharray="6 3"/>'
            )
            if ref_label:
                svg_parts.append(
                    f'<text x="{width - pad_r - 2}" y="{ry - 4:.1f}" '
                    f'text-anchor="end" font-size="10" fill="{ref_color}">{html_escape(ref_label)}</text>'
                )

    # 데이터 라인
    s_names = list(series.keys())
    baseline_y = pad_t + chart_h  # Area fill 바닥선
    for si, (name, pts) in enumerate(series.items()):
        color = colors[si % len(colors)]
        # 좌표 수집
        coords: list[tuple[float, float]] = []
        for d, v in sorted(pts, key=lambda x: x[0]):
            if d in date_idx:
                coords.append((x_pos(date_idx[d]), y_pos(v)))
        if not coords:
            continue
        # 단일 포인트: 원 마커 표시
        if len(coords) == 1:
            cx, cy = coords[0]
            if fill_opacity > 0:
                svg_parts.append(
                    f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="5" '
                    f'fill="{color}" fill-opacity="{fill_opacity}"/>'
                )
            svg_parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3" fill="{color}"/>')
            continue

        # Catmull-Rom → cubic bezier 곡선
        curve_path = _catmull_rom_to_bezier(coords)

        # Area fill (AreaChart 스타일)
        if fill_opacity > 0:
            first_x, last_x = coords[0][0], coords[-1][0]
            area_path = (
                curve_path
                + f" L{last_x:.1f},{baseline_y:.1f}"
                + f" L{first_x:.1f},{baseline_y:.1f} Z"
            )
            svg_parts.append(
                f'<path d="{area_path}" '
                f'fill="{color}" fill-opacity="{fill_opacity}" stroke="none"/>'
            )
        svg_parts.append(
            f'<path d="{curve_path}" '
            f'fill="none" stroke="{color}" stroke-width="2" '
            f'stroke-linejoin="round" stroke-linecap="round"/>'
        )

    # 오른쪽 시리즈 데이터 라인 (dashed)
    if has_right and right_series and right_colors:
        r_names = list(right_series.keys())
        for si, (name, pts) in enumerate(right_series.items()):
            color = right_colors[si % len(right_colors)]
            coords: list[tuple[float, float]] = []
            for d, v in sorted(pts, key=lambda x: x[0]):
                if d in date_idx:
                    coords.append((x_pos(date_idx[d]), y_pos_right(v)))
            if not coords:
                continue
            if len(coords) == 1:
                cx, cy = coords[0]
                svg_parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3" fill="{color}"/>')
                continue
            curve_path = _catmull_rom_to_bezier(coords)
            svg_parts.append(
                f'<path d="{curve_path}" '
                f'fill="none" stroke="{color}" stroke-width="2" '
                f'stroke-dasharray="6 3" '
                f'stroke-linejoin="round" stroke-linecap="round"/>'
            )

    # 범례 (다중 행 지원)
    legend_row_height = 16
    max_legend_x = width - pad_r
    legend_x_start = pad_l

    # 범례에 필요한 행 수 사전 계산
    extra_rows = 0
    pre_cursor = legend_x_start
    for name in s_names:
        item_w = len(name) * 7 + 30
        if pre_cursor + item_w > max_legend_x and pre_cursor > legend_x_start:
            pre_cursor = legend_x_start
            extra_rows += 1
        pre_cursor += item_w
    if has_right and right_series:
        r_names = list(right_series.keys())
        for name in r_names:
            item_w = (len(name) + len(right_y_suffix) + 3) * 7 + 30
            if pre_cursor + item_w > max_legend_x and pre_cursor > legend_x_start:
                pre_cursor = legend_x_start
                extra_rows += 1
            pre_cursor += item_w

    # 추가 범례 행만큼 SVG 높이 확장
    if extra_rows > 0:
        height += extra_rows * legend_row_height

    legend_y = height - 5
    # 첫 번째 행의 legend_y를 extra_rows만큼 위로 올림
    legend_y -= extra_rows * legend_row_height

    legend_items: list[str] = []
    cursor_x = legend_x_start
    for si, name in enumerate(s_names):
        item_width = len(name) * 7 + 30
        if cursor_x + item_width > max_legend_x and cursor_x > legend_x_start:
            cursor_x = legend_x_start
            legend_y += legend_row_height
        color = colors[si % len(colors)]
        legend_items.append(
            f'<circle cx="{cursor_x}" cy="{legend_y}" r="4" fill="{color}"/>'
            f'<text x="{cursor_x + 8}" y="{legend_y + 4}" font-size="10" fill="#374151">{html_escape(name)}</text>'
        )
        cursor_x += item_width
    if has_right and right_series and right_colors:
        r_names = list(right_series.keys())
        for si, name in enumerate(r_names):
            item_width = (len(name) + len(right_y_suffix) + 3) * 7 + 30
            if cursor_x + item_width > max_legend_x and cursor_x > legend_x_start:
                cursor_x = legend_x_start
                legend_y += legend_row_height
            color = right_colors[si % len(right_colors)]
            # 대시 라인 범례 표시
            legend_items.append(
                f'<line x1="{cursor_x - 4}" y1="{legend_y}" x2="{cursor_x + 4}" y2="{legend_y}" '
                f'stroke="{color}" stroke-width="2" stroke-dasharray="3 2"/>'
                f'<text x="{cursor_x + 8}" y="{legend_y + 4}" font-size="10" fill="#374151">'
                f'{html_escape(name)}{" (" + right_y_suffix + ")" if right_y_suffix else ""}</text>'
            )
            cursor_x += item_width

    svg_parts.extend(legend_items)
    svg_parts.append("</svg>")

    # SVG 헤더/배경 placeholder를 확정된 height로 치환
    svg_header = (
        f'<svg viewBox="0 0 {width} {height}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f"style=\"width:100%;height:auto;font-family:'Noto Sans CJK KR',sans-serif;\">"
    )
    svg_bg = f'<rect width="{width}" height="{height}" fill="white"/>'
    svg_parts = [
        svg_header if p == _SVG_HEADER_PH else (svg_bg if p == _SVG_BG_PH else p)
        for p in svg_parts
    ]

    # 카드 래퍼
    header_html = ""
    if title:
        header_html += (
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">{html_escape(title)}</h4>'
        )
    if subtitle:
        header_html += (
            f'<p style="font-size:12px;color:#6b7280;margin:0;">{html_escape(subtitle)}</p>'
        )

    return (
        f'<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
        f"{header_html}"
        f'<div style="margin-top:8px;">{"".join(svg_parts)}</div>'
        f"</div>"
    )


def _no_data_placeholder(message: str) -> str:
    return (
        f'<div style="border:1px dashed #d1d5db;border-radius:8px;padding:24px;'
        f'text-align:center;color:#6b7280;font-size:13px;margin-bottom:12px;">'
        f"{html_escape(message)}</div>"
    )


def _html_data_table(
    series: dict[str, list[tuple[str, float]]],
    title: str = "",
    y_suffix: str = "",
) -> str:
    """시리즈 데이터를 HTML 테이블로 생성.

    차트와 동일한 series 포맷을 받아 날짜를 행, 시리즈를 열로 변환.
    기본 접힌 상태의 토글 포함.

    Args:
        series: {series_name: [(date_str, value), ...]}
        title: 테이블 제목 (접기/펼치기 레이블에 사용)
        y_suffix: 값 접미사
    """
    if not series:
        return ""

    # 전체 날짜 수집
    all_dates: list[str] = []
    for pts in series.values():
        for d, _ in pts:
            if d not in all_dates:
                all_dates.append(d)
    all_dates.sort()

    if not all_dates:
        return ""

    s_names = list(series.keys())

    # 날짜×시리즈 매핑
    lookup: dict[str, dict[str, float]] = {}
    for name, pts in series.items():
        for d, v in pts:
            lookup.setdefault(d, {})[name] = v

    # 테이블 헤더
    headers = "".join(
        f'<th style="padding:4px 8px;font-size:11px;font-weight:600;'
        f'text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;">'
        f"{html_escape(name)}</th>"
        for name in s_names
    )

    # 테이블 행
    rows: list[str] = []
    for d in all_dates:
        cells = [
            f'<td style="padding:3px 8px;font-size:11px;border-bottom:1px solid #f3f4f6;'
            f'white-space:nowrap;">{_fmt_date(d)}</td>'
        ]
        for name in s_names:
            val = lookup.get(d, {}).get(name)
            if val is not None:
                formatted = f"{val:.0f}" if val == int(val) else f"{val:.2f}"
                cell_val = f"{formatted}{y_suffix}"
            else:
                cell_val = "-"
            cells.append(
                f'<td style="padding:3px 8px;font-size:11px;border-bottom:1px solid #f3f4f6;'
                f'text-align:right;">{cell_val}</td>'
            )
        rows.append(f"<tr>{''.join(cells)}</tr>")

    toggle_label = html_escape(title) if title else "데이터 테이블"

    return (
        f'<details open style="margin-top:6px;margin-bottom:4px;">'
        f'<summary style="cursor:pointer;font-size:11px;color:#6b7280;'
        f'user-select:none;">{toggle_label} 데이터 테이블</summary>'
        f'<div style="max-height:240px;overflow:auto;margin-top:4px;'
        f'border:1px solid #e5e7eb;border-radius:6px;">'
        f'<table style="width:100%;border-collapse:collapse;">'
        f"<thead><tr>"
        f'<th style="padding:4px 8px;font-size:11px;font-weight:600;'
        f'text-align:left;border-bottom:2px solid #e5e7eb;">날짜</th>'
        f"{headers}</tr></thead>"
        f"<tbody>{''.join(rows)}</tbody>"
        f"</table></div></details>"
    )


def _svg_simple_bar_chart(
    data: list[tuple[str, float]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    y_domain: tuple[float, float] | None = None,
    height: int = 220,
    y_integer: bool = False,
) -> str:
    """인라인 SVG 단순 막대 차트 (카테고리별 단일 값).

    Args:
        data: [(label, value), ...]
        colors: 막대별 색상 목록
        title: 차트 제목
        subtitle: 차트 부제목
        y_suffix: Y축 값 접미사
        y_domain: Y축 범위 (min, max). None이면 자동.
        height: 차트 높이 (px)
    """
    if not data:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    width = 700
    pad_l, pad_r, pad_t, pad_b = 45, 15, 10, 45
    chart_w = width - pad_l - pad_r
    chart_h = height - pad_t - pad_b

    n = len(data)
    values = [v for _, v in data]

    # 정수 데이터 자동 감지
    all_int = y_integer or all(v == int(v) for v in values)

    if y_domain:
        y_min, y_max = y_domain
    else:
        y_min = 0
        y_max = max(values) if values else 1
        if y_max == y_min:
            y_max = y_min + 1
        if all_int:
            y_max = _nice_int_max(max(values) if values else 1)
        else:
            y_max = y_max * 1.1

    bar_gap = max(4, chart_w // (n * 4))
    bar_w = max(8, (chart_w - bar_gap * (n + 1)) / n)

    def y_pos(val: float) -> float:
        if y_max == y_min:
            return pad_t + chart_h / 2
        return pad_t + chart_h - ((val - y_min) / (y_max - y_min)) * chart_h

    svg_parts: list[str] = []
    svg_parts.append(
        f'<svg viewBox="0 0 {width} {height}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f"style=\"width:100%;height:auto;font-family:'Noto Sans CJK KR',sans-serif;\">"
    )
    svg_parts.append(f'<rect width="{width}" height="{height}" fill="white"/>')

    # 그리드
    n_grid = 5
    for i in range(n_grid + 1):
        gy = pad_t + (i / n_grid) * chart_h
        gval = y_max - (i / n_grid) * (y_max - y_min)
        svg_parts.append(
            f'<line x1="{pad_l}" y1="{gy:.1f}" x2="{width - pad_r}" y2="{gy:.1f}" '
            f'stroke="#e5e7eb" stroke-dasharray="3 3"/>'
        )
        if all_int:
            label = f"{int(round(gval))}{y_suffix}"
        else:
            label = f"{gval:.0f}{y_suffix}" if gval == int(gval) else f"{gval:.1f}{y_suffix}"
        svg_parts.append(
            f'<text x="{pad_l - 5}" y="{gy + 4:.1f}" '
            f'text-anchor="end" font-size="10" fill="#6b7280">{label}</text>'
        )

    # 막대 + X축 레이블
    base_y = pad_t + chart_h
    for i, (label, val) in enumerate(data):
        bx = pad_l + bar_gap + i * (bar_w + bar_gap)
        color = colors[i % len(colors)]
        bar_top = y_pos(val)
        bar_h = base_y - bar_top
        svg_parts.append(
            f'<rect x="{bx:.1f}" y="{bar_top:.1f}" '
            f'width="{bar_w:.1f}" height="{max(0, bar_h):.1f}" '
            f'fill="{color}" rx="2"/>'
        )
        # 값 라벨
        svg_parts.append(
            f'<text x="{bx + bar_w / 2:.1f}" y="{bar_top - 4:.1f}" '
            f'text-anchor="middle" font-size="10" fill="#374151">'
            f"{val:.0f}{y_suffix}</text>"
        )
        # X축 라벨 (짧게)
        short_label = label[:10] + "…" if len(label) > 10 else label
        svg_parts.append(
            f'<text x="{bx + bar_w / 2:.1f}" y="{base_y + 14}" '
            f'text-anchor="middle" font-size="9" fill="#6b7280">'
            f"{html_escape(short_label)}</text>"
        )

    svg_parts.append("</svg>")

    header_html = ""
    if title:
        header_html += (
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">{html_escape(title)}</h4>'
        )
    if subtitle:
        header_html += (
            f'<p style="font-size:12px;color:#6b7280;margin:0;">{html_escape(subtitle)}</p>'
        )

    return (
        f'<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
        f"{header_html}"
        f'<div style="margin-top:8px;">{"".join(svg_parts)}</div>'
        f"</div>"
    )


def _svg_bar_line_chart(
    bar_series: dict[str, list[tuple[str, float]]],
    line_series: dict[str, list[tuple[str, float]]],
    bar_colors: list[str],
    line_colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    height: int = 240,
    y_integer: bool = False,
) -> str:
    """인라인 SVG Bar + Line 복합 차트 (ComposedChart 패턴).

    Args:
        bar_series: 막대 시리즈 {name: [(date, value), ...]}
        line_series: 라인 시리즈 {name: [(date, value), ...]}
        bar_colors: 막대 색상
        line_colors: 라인 색상
        title: 차트 제목
        subtitle: 차트 부제목
        y_suffix: Y축 값 접미사
        height: 차트 높이 (px)
    """
    all_series = {**bar_series, **line_series}
    if not all_series:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    width = 700
    pad_l, pad_r, pad_t, pad_b = 45, 15, 10, 40
    chart_w = width - pad_l - pad_r
    chart_h = height - pad_t - pad_b

    # 날짜 + 값 수집
    all_dates: list[str] = []
    all_values: list[float] = []
    for pts in all_series.values():
        for d, v in pts:
            if d not in all_dates:
                all_dates.append(d)
            all_values.append(v)
    all_dates.sort()

    if not all_dates or not all_values:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    date_idx = {d: i for i, d in enumerate(all_dates)}
    n_dates = len(all_dates)

    # 정수 데이터 자동 감지
    all_int = y_integer or all(v == int(v) for v in all_values)

    y_min = 0
    y_max = max(all_values) if all_values else 1
    if y_max == y_min:
        y_max = y_min + 1
    if all_int:
        y_max = _nice_int_max(max(all_values) if all_values else 1)
    else:
        y_max = y_max * 1.1

    bar_gap = 2
    bar_w = max(4, (chart_w - bar_gap * (n_dates + 1)) / n_dates)

    def x_pos(idx: int) -> float:
        return pad_l + bar_gap + idx * (bar_w + bar_gap) + bar_w / 2

    def y_pos(val: float) -> float:
        return pad_t + chart_h - ((val - y_min) / (y_max - y_min)) * chart_h

    svg_parts: list[str] = []
    svg_parts.append(
        f'<svg viewBox="0 0 {width} {height}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f"style=\"width:100%;height:auto;font-family:'Noto Sans CJK KR',sans-serif;\">"
    )
    svg_parts.append(f'<rect width="{width}" height="{height}" fill="white"/>')

    # 그리드
    n_grid = 5
    for i in range(n_grid + 1):
        gy = pad_t + (i / n_grid) * chart_h
        gval = y_max - (i / n_grid) * (y_max - y_min)
        svg_parts.append(
            f'<line x1="{pad_l}" y1="{gy:.1f}" x2="{width - pad_r}" y2="{gy:.1f}" '
            f'stroke="#e5e7eb" stroke-dasharray="3 3"/>'
        )
        if all_int:
            label = f"{int(round(gval))}{y_suffix}"
        else:
            label = f"{gval:.0f}{y_suffix}" if gval == int(gval) else f"{gval:.1f}{y_suffix}"
        svg_parts.append(
            f'<text x="{pad_l - 5}" y="{gy + 4:.1f}" '
            f'text-anchor="end" font-size="10" fill="#6b7280">{label}</text>'
        )

    # Bar 렌더링
    base_y = pad_t + chart_h
    for si, (name, pts) in enumerate(bar_series.items()):
        color = bar_colors[si % len(bar_colors)]
        lookup = {d: v for d, v in pts}
        for di, d in enumerate(all_dates):
            val = lookup.get(d, 0)
            if val <= 0:
                continue
            bx = pad_l + bar_gap + di * (bar_w + bar_gap)
            bar_top = y_pos(val)
            bar_h = base_y - bar_top
            svg_parts.append(
                f'<rect x="{bx:.1f}" y="{bar_top:.1f}" '
                f'width="{bar_w:.1f}" height="{max(0, bar_h):.1f}" '
                f'fill="{color}" fill-opacity="0.7" rx="1"/>'
            )

    # Line 렌더링
    for si, (name, pts) in enumerate(line_series.items()):
        color = line_colors[si % len(line_colors)]
        points = []
        for d, v in sorted(pts, key=lambda x: x[0]):
            if d in date_idx:
                px = x_pos(date_idx[d])
                py = y_pos(v)
                points.append(f"{px:.1f},{py:.1f}")
        if points:
            svg_parts.append(
                f'<polyline points="{" ".join(points)}" '
                f'fill="none" stroke="{color}" stroke-width="2" '
                f'stroke-linejoin="round" stroke-linecap="round"/>'
            )
            # 점 표시
            for pt in points:
                cx, cy = pt.split(",")
                svg_parts.append(f'<circle cx="{cx}" cy="{cy}" r="2.5" fill="{color}"/>')

    # X축 레이블
    step = max(1, n_dates // 10)
    for i in range(0, n_dates, step):
        xp = x_pos(i)
        svg_parts.append(
            f'<text x="{xp:.1f}" y="{pad_t + chart_h + 14}" '
            f'text-anchor="middle" font-size="10" fill="#6b7280">{_fmt_date(all_dates[i])}</text>'
        )

    # 범례
    legend_y = height - 5
    cursor_x = float(pad_l)
    all_names = list(bar_series.keys()) + list(line_series.keys())
    all_colors = [bar_colors[i % len(bar_colors)] for i in range(len(bar_series))] + [
        line_colors[i % len(line_colors)] for i in range(len(line_series))
    ]
    for si, name in enumerate(all_names):
        color = all_colors[si]
        if si < len(bar_series):
            svg_parts.append(
                f'<rect x="{cursor_x}" y="{legend_y - 4}" width="8" height="8" rx="2" fill="{color}" fill-opacity="0.7"/>'
                f'<text x="{cursor_x + 12}" y="{legend_y + 4}" font-size="10" fill="#374151">{html_escape(name)}</text>'
            )
        else:
            svg_parts.append(
                f'<circle cx="{cursor_x + 4}" cy="{legend_y}" r="4" fill="{color}"/>'
                f'<text x="{cursor_x + 12}" y="{legend_y + 4}" font-size="10" fill="#374151">{html_escape(name)}</text>'
            )
        cursor_x += len(name) * 7 + 30

    svg_parts.append("</svg>")

    header_html = ""
    if title:
        header_html += (
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">{html_escape(title)}</h4>'
        )
    if subtitle:
        header_html += (
            f'<p style="font-size:12px;color:#6b7280;margin:0;">{html_escape(subtitle)}</p>'
        )

    return (
        f'<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
        f"{header_html}"
        f'<div style="margin-top:8px;">{"".join(svg_parts)}</div>'
        f"</div>"
    )


def _svg_stacked_bar_chart(
    series: dict[str, list[tuple[str, float]]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    height: int = 280,
    reference_lines: list[dict] | None = None,
    x_formatter=None,
    y_formatter=None,
    y_integer: bool = False,
    projected_labels: set[str] | None = None,
) -> str:
    """인라인 SVG 누적 막대 차트를 생성.

    대시보드의 DagDurationSingleChart(stacked BarChart) 패턴을 SVG로 구현.

    Args:
        series: {series_name: [(date_str, value), ...]}
        colors: 시리즈별 색상 목록
        title: 차트 제목
        subtitle: 차트 부제목
        y_suffix: Y축 값 접미사
        height: 차트 높이 (px)
        projected_labels: 예측값으로 표시할 날짜/월 레이블 set (opacity 0.4 적용)
    """
    if not series:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    width = 700
    pad_l, pad_r, pad_t, pad_b = 45, 15, 10, 40
    chart_w = width - pad_l - pad_r
    chart_h = height - pad_t - pad_b

    # 전체 날짜 수집 (정렬)
    all_dates: list[str] = []
    for pts in series.values():
        for d, _ in pts:
            if d not in all_dates:
                all_dates.append(d)
    all_dates.sort()

    if not all_dates:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    # 날짜별 시리즈 값 매핑
    s_names = list(series.keys())
    date_stacks: dict[str, list[float]] = {}
    for d in all_dates:
        date_stacks[d] = [0.0] * len(s_names)
    for si, (_, pts) in enumerate(series.items()):
        for d, v in pts:
            if d in date_stacks:
                date_stacks[d][si] = v

    # 정수 데이터 자동 감지
    all_stack_values = [v for vals in date_stacks.values() for v in vals]
    all_int = y_integer or all(v == int(v) for v in all_stack_values)

    # Y축 최대값 (날짜별 누적합)
    y_max = 0.0
    for vals in date_stacks.values():
        y_max = max(y_max, sum(vals))
    if y_max == 0:
        y_max = 1.0
    if all_int:
        y_max = _nice_int_max(y_max)
    else:
        y_max = y_max * 1.1

    n_dates = len(all_dates)
    bar_gap = 4
    bar_w = max(4, (chart_w - bar_gap * (n_dates + 1)) / n_dates)

    def y_pos(val: float) -> float:
        return pad_t + chart_h - (val / y_max) * chart_h

    # 범례 줄바꿈 사전 계산
    max_legend_width = width - pad_l - pad_r
    legend_names = list(s_names)
    if projected_labels:
        legend_names.append("예상")
    legend_rows: list[list[tuple[str, float]]] = []
    current_row: list[tuple[str, float]] = []
    current_width = 0.0
    for name in legend_names:
        item_width = len(name) * 7 + 30
        if current_width + item_width > max_legend_width and current_row:
            legend_rows.append(current_row)
            current_row = [(name, item_width)]
            current_width = item_width
        else:
            current_row.append((name, item_width))
            current_width += item_width
    if current_row:
        legend_rows.append(current_row)
    legend_line_height = 16
    legend_height = len(legend_rows) * legend_line_height + 5
    total_height = height + legend_height

    svg_parts: list[str] = []
    svg_parts.append(
        f'<svg viewBox="0 0 {width} {total_height}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f"style=\"width:100%;height:auto;font-family:'Noto Sans CJK KR',sans-serif;\">"
    )
    svg_parts.append(f'<rect width="{width}" height="{total_height}" fill="white"/>')

    # 그리드 (수평 5줄)
    n_grid = 5
    for i in range(n_grid + 1):
        gy = pad_t + (i / n_grid) * chart_h
        gval = y_max - (i / n_grid) * y_max
        svg_parts.append(
            f'<line x1="{pad_l}" y1="{gy:.1f}" x2="{width - pad_r}" y2="{gy:.1f}" '
            f'stroke="#e5e7eb" stroke-dasharray="3 3"/>'
        )
        if y_formatter:
            label = y_formatter(gval)
        elif all_int:
            label = f"{int(round(gval))}{y_suffix}"
        else:
            label = f"{gval:.0f}{y_suffix}" if gval == int(gval) else f"{gval:.1f}{y_suffix}"
        svg_parts.append(
            f'<text x="{pad_l - 5}" y="{gy + 4:.1f}" '
            f'text-anchor="end" font-size="10" fill="#6b7280">{label}</text>'
        )

    # 누적 막대 렌더링
    _projected_color = "#94a3b8"
    for di, d in enumerate(all_dates):
        bx = pad_l + bar_gap + di * (bar_w + bar_gap)
        cumulative = 0.0
        is_proj = bool(projected_labels and d in projected_labels)
        if is_proj:
            # projected 기간: 회색 단일 바 (포탈과 동일)
            total = sum(date_stacks[d])
            if total > 0:
                bar_bottom = y_pos(0)
                bar_top = y_pos(total)
                bar_h = bar_bottom - bar_top
                svg_parts.append(
                    f'<rect x="{bx:.1f}" y="{bar_top:.1f}" '
                    f'width="{bar_w:.1f}" height="{max(0, bar_h):.1f}" '
                    f'fill="{_projected_color}" rx="1"/>'
                )
        else:
            for si, val in enumerate(date_stacks[d]):
                if val <= 0:
                    continue
                color = colors[si % len(colors)]
                bar_bottom = y_pos(cumulative)
                bar_top = y_pos(cumulative + val)
                bar_h = bar_bottom - bar_top
                svg_parts.append(
                    f'<rect x="{bx:.1f}" y="{bar_top:.1f}" '
                    f'width="{bar_w:.1f}" height="{max(0, bar_h):.1f}" '
                    f'fill="{color}" rx="1"/>'
                )
                cumulative += val

    # 참조선 (reference_lines)
    if reference_lines:
        for ref in reference_lines:
            ref_val = ref.get("value", 0)
            ref_label = ref.get("label", "")
            ref_color = ref.get("color", "#dc2626")
            if 0 < ref_val <= y_max:
                ry = y_pos(ref_val)
                svg_parts.append(
                    f'<line x1="{pad_l}" y1="{ry:.1f}" x2="{width - pad_r}" y2="{ry:.1f}" '
                    f'stroke="{ref_color}" stroke-width="2" stroke-dasharray="6 3"/>'
                )
                if ref_label:
                    svg_parts.append(
                        f'<text x="{width - pad_r + 2}" y="{ry + 4:.1f}" '
                        f'font-size="10" fill="{ref_color}">{html_escape(ref_label)}</text>'
                    )

    # X축 레이블 (최대 10개)
    step = max(1, n_dates // 10)
    for i in range(0, n_dates, step):
        bx = pad_l + bar_gap + i * (bar_w + bar_gap) + bar_w / 2
        x_label = x_formatter(all_dates[i]) if x_formatter else _fmt_date(all_dates[i])
        svg_parts.append(
            f'<text x="{bx:.1f}" y="{pad_t + chart_h + 14}" '
            f'text-anchor="middle" font-size="10" fill="#6b7280">{x_label}</text>'
        )

    # 범례 (줄바꿈 지원)
    color_map = {name: colors[si % len(colors)] for si, name in enumerate(s_names)}
    if projected_labels:
        color_map["예상"] = _projected_color
    legend_base_y = height - 5
    for row_idx, row in enumerate(legend_rows):
        ly = legend_base_y + row_idx * legend_line_height
        cursor_x = float(pad_l)
        for name, _ in row:
            color = color_map[name]
            svg_parts.append(
                f'<rect x="{cursor_x}" y="{ly - 4}" width="8" height="8" rx="2" fill="{color}"/>'
                f'<text x="{cursor_x + 12}" y="{ly + 4}" font-size="10" fill="#374151">{html_escape(name)}</text>'
            )
            cursor_x += len(name) * 7 + 30

    svg_parts.append("</svg>")

    # 카드 래퍼
    header_html = ""
    if title:
        header_html += (
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">{html_escape(title)}</h4>'
        )
    if subtitle:
        header_html += (
            f'<p style="font-size:12px;color:#6b7280;margin:0;">{html_escape(subtitle)}</p>'
        )

    return (
        f'<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
        f"{header_html}"
        f'<div style="margin-top:8px;">{"".join(svg_parts)}</div>'
        f"</div>"
    )
