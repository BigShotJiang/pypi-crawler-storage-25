"""리포트 데이터 → CSV 변환."""

import csv
import io
import logging
from dataclasses import fields

logger = logging.getLogger(__name__)

# UTF-8 BOM (Excel 한글 인식용)
_UTF8_BOM = b"\xef\xbb\xbf"


def report_data_to_csv(data, report_type: str) -> bytes:
    """DashboardDailyReportData 또는 InfraReportData → CSV bytes.

    dataclass fields를 순회하면서 dict 형태 필드의 시계열 데이터를 추출.
    출력 형식: section,series,date,value (4-column flat CSV, UTF-8 BOM 포함).

    Args:
        data: 리포트 데이터 dataclass 인스턴스
        report_type: 리포트 유형명 (로그용)

    Returns:
        CSV 바이트 데이터 (UTF-8 BOM 포함)
    """
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["section", "series", "date", "value"])
    row_count = 0

    for f in fields(data):
        val = getattr(data, f.name)
        if not isinstance(val, dict):
            continue
        row_count += _extract_dict_series(writer, f.name, val)

    csv_str = buf.getvalue()
    logger.info("CSV 생성 완료: %s (%d rows)", report_type, row_count)
    return _UTF8_BOM + csv_str.encode("utf-8")


def _extract_dict_series(writer: csv.writer, section: str, d: dict, depth: int = 0) -> int:
    """dict에서 시계열 데이터를 재귀적으로 추출.

    지원 형태:
    - {"environments": {env: [{"date": ..., key: val}]}}
    - {"environments": {env: {"daily": [{"date": ..., key: val}]}}}
    - {"instances": {name: [{"date": ..., key: val}]}}
    - {"studios": [{"date": ..., key: val}]}
    - {"clusters": {name: [{"date": ..., key: val}]}}
    """
    rows = 0
    if depth > 3:
        return rows

    for key, val in d.items():
        if isinstance(val, list) and val and isinstance(val[0], dict) and "date" in val[0]:
            # 직접 시계열 리스트
            rows += _write_timeseries(writer, section, key, val)
        elif isinstance(val, dict):
            for sub_key, sub_val in val.items():
                if isinstance(sub_val, list) and sub_val and isinstance(sub_val[0], dict):
                    if "date" in sub_val[0]:
                        rows += _write_timeseries(writer, section, f"{key}/{sub_key}", sub_val)
                elif isinstance(sub_val, dict) and "daily" in sub_val:
                    daily = sub_val["daily"]
                    if isinstance(daily, list) and daily and isinstance(daily[0], dict):
                        rows += _write_timeseries(writer, section, f"{key}/{sub_key}", daily)
    return rows


def _write_timeseries(writer: csv.writer, section: str, series: str, points: list[dict]) -> int:
    """시계열 포인트를 CSV에 기록."""
    rows = 0
    for pt in points:
        date = pt.get("date", "")
        for k, v in pt.items():
            if k == "date":
                continue
            if isinstance(v, (int, float)):
                writer.writerow([section, f"{series}/{k}", date, v])
                rows += 1
    return rows
