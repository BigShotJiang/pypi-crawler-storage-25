"""이메일 호환 HTML table 기반 차트 함수.

Outlook Desktop은 data:image/png;base64 URI를 차단하므로,
SVG 대신 순수 HTML table로 차트를 렌더링한다.
모든 이메일 클라이언트(Outlook, Gmail, Apple Mail 등)가 지원하는
인라인 style + table 구조만 사용.

charts.py의 SVG 차트 함수와 동일한 시그니처를 유지하여
리포트 생성기에서 import만 교체하면 동작하도록 설계.

개선사항:
- 높이 120→180px
- 중간 Y축 그리드라인 (mid)
- 라인 차트: dot → area fill bar
- days=1 (데이터 1~2개) stat card 대응
- X축 라벨 7개 이하 시 전체 표시
"""

from __future__ import annotations

from html import escape as html_escape

from src.agent_server.bdp_common.reports.charts import (
    _fmt_date,
    _nice_int_max,
    _no_data_placeholder,
)

_CHART_H = 180  # 이메일 차트 기본 높이 (px) — 2-1: 120→180
_LEGEND_TRUNCATE = 15  # 범례 시리즈명 최대 길이

# ── 공통 헬퍼 ──────────────────────────────────────────────


def _chart_header(title: str, subtitle: str) -> str:
    parts: list[str] = []
    if title:
        parts.append(
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">'
            f"{html_escape(title)}</h4>"
        )
    if subtitle:
        parts.append(
            f'<p style="font-size:12px;color:#6b7280;margin:0;">'
            f"{html_escape(subtitle)}</p>"
        )
    return "".join(parts)


def _chart_legend(names: list[str], colors: list[str]) -> str:
    """범례 — 원형 색상 표시 + inline-block 자연 줄바꿈."""
    if len(names) <= 1:
        return ""
    items: list[str] = []
    for i, name in enumerate(names):
        color = colors[i % len(colors)]
        display = name[:_LEGEND_TRUNCATE] + "…" if len(name) > _LEGEND_TRUNCATE else name
        items.append(
            f'<span style="display:inline-block;margin-right:12px;margin-top:4px;'
            f'font-size:10px;color:#374151;white-space:nowrap;">'
            f'<span style="display:inline-block;width:8px;height:8px;'
            f'background:{color};border-radius:50%;vertical-align:middle;'
            f'margin-right:4px;"></span>{html_escape(display)}</span>'
        )
    return (
        f'<div style="margin-top:6px;line-height:1.8;">'
        f'{"".join(items)}</div>'
    )


def _chart_wrapper(
    header: str, body: str, legend: str = "", accent_color: str = "#3b82f6",
) -> str:
    """차트 래퍼 — 깊이감 개선."""
    return (
        f'<div style="background:#fff;border:1px solid #d1d5db;border-radius:8px;'
        f'padding:12px 16px;margin-bottom:10px;">'
        f"{header}"
        f'<div style="margin-top:8px;border-left:3px solid {accent_color};'
        f'background:#f9fafb;border:1px solid #eef0f2;border-left:3px solid {accent_color};'
        f'border-radius:4px;padding:8px;">{body}</div>'
        f"{legend}"
        f"</div>"
    )


def _calc_y_range(
    all_values: list[float],
    y_domain: tuple[float, float] | None,
    y_integer: bool,
) -> tuple[float, float]:
    if y_domain:
        return y_domain
    y_min = 0.0
    y_max = max(all_values) if all_values else 1.0
    if y_max == y_min:
        y_max = y_min + 1
    all_int = y_integer or all(v == int(v) for v in all_values)
    if all_int:
        y_max = _nice_int_max(max(all_values) if all_values else 1)
    else:
        y_max = y_max * 1.1
    return y_min, y_max


def _bar_h(val: float, y_min: float, y_max: float, chart_h: int) -> int:
    if y_max <= y_min:
        return 0
    ratio = (val - y_min) / (y_max - y_min)
    return max(1, int(ratio * chart_h))


def _bar_cell(height: int, color: str, width_style: str = "") -> str:
    """Outlook 호환 단일 막대 셀."""
    w = f"width:{width_style};" if width_style else ""
    return (
        f'<div style="background:{color};height:{height}px;{w}'
        f'font-size:0;line-height:0;">&nbsp;</div>'
    )


def _area_bar_cell(height: int, color: str, chart_h: int) -> str:
    """Area fill bar — 바닥부터 값 높이까지 반투명 채움 + 상단 2px 불투명 라인.

    이메일 클라이언트 100% 호환 (단순 div 배경색).
    """
    line_h = min(2, height)
    fill_h = max(0, height - line_h)
    spacer = max(0, chart_h - height)
    return (
        f'<div style="height:{chart_h}px;">'
        f'<div style="height:{spacer}px;"></div>'
        f'<div style="background:{color};height:{line_h}px;'
        f'font-size:0;line-height:0;">&nbsp;</div>'
        f'<div style="background:{color};opacity:0.25;height:{fill_h}px;'
        f'font-size:0;line-height:0;">&nbsp;</div>'
        f'</div>'
    )


def _overlay_area_cell(
    heights: list[int], colors_list: list[str], chart_h: int,
) -> str:
    """다중 시리즈 겹침 area fill — 동일 x축 위치에 시리즈를 수직으로 겹쳐 표시.

    position:relative 컨테이너 안에 각 시리즈를 position:absolute로 겹침.
    """
    layers: list[str] = []
    for si, (h, color) in enumerate(zip(heights, colors_list)):
        line_h = min(2, h)
        fill_h = max(0, h - line_h)
        spacer = max(0, chart_h - h)
        # 첫 번째 레이어는 relative (높이 확보), 나머지는 absolute 겹침
        pos = "position:relative;" if si == 0 else (
            "position:absolute;top:0;left:0;width:100%;"
        )
        layers.append(
            f'<div style="{pos}height:{chart_h}px;">'
            f'<div style="height:{spacer}px;"></div>'
            f'<div style="background:{color};height:{line_h}px;'
            f'font-size:0;line-height:0;">&nbsp;</div>'
            f'<div style="background:{color};opacity:0.2;height:{fill_h}px;'
            f'font-size:0;line-height:0;">&nbsp;</div>'
            f'</div>'
        )
    return (
        f'<div style="position:relative;height:{chart_h}px;">'
        f'{"".join(layers)}</div>'
    )


def _empty_td(chart_h: int) -> str:
    """빈 패딩 셀 (첫/마지막 포인트 중앙 정렬용)."""
    return f'<td style="padding:0;vertical-align:bottom;"><div style="height:{chart_h}px;"></div></td>'


def _band_td(
    h_cur: int, h_next: int, color: str, chart_h: int, is_real: bool,
    line_w: int = 2,
) -> str:
    """단일 시리즈 밴드 셀 — 현재~다음 높이를 잇는 수직 밴드.

    인접 셀의 밴드와 반드시 겹쳐서 끊어지지 않음.
    """
    if is_real:
        bar_color = "#1f2937"  # 거의 검은색 — 실제 데이터 포인트 강조
        line_op = "0.9"
    else:
        bar_color = color
        line_op = "0.5"
    top_h = max(h_cur, h_next)
    band = max(line_w, abs(h_cur - h_next) + line_w)
    spacer = max(0, chart_h - top_h)
    return (
        f'<td style="padding:0;vertical-align:bottom;">'
        f'<div style="height:{chart_h}px;">'
        f'<div style="height:{spacer}px;"></div>'
        f'<div style="background:{bar_color};opacity:{line_op};height:{band}px;'
        f'font-size:0;line-height:0;">&nbsp;</div>'
        f'</div></td>'
    )


def _dot_line_cell(height: int, color: str, chart_h: int) -> str:
    """Dot-line 셀 — 데이터 포인트 높이에 4px dot + 아래 1px 세로선, fill 없음.

    dot(●)으로 데이터 포인트를 표시하고, 바닥까지 얇은 세로선으로 연결.
    """
    dot_h = 4
    spacer = max(0, chart_h - height)
    stem_h = max(0, height - dot_h)
    return (
        f'<div style="height:{chart_h}px;">'
        f'<div style="height:{spacer}px;"></div>'
        f'<div style="width:4px;height:{dot_h}px;background:{color};'
        f'border-radius:50%;margin:0 auto;font-size:0;line-height:0;">&nbsp;</div>'
        f'<div style="width:1px;height:{stem_h}px;background:{color};opacity:0.2;'
        f'margin:0 auto;font-size:0;line-height:0;">&nbsp;</div>'
        f'</div>'
    )


def _overlay_dot_line_cell(
    heights: list[int], colors_list: list[str], chart_h: int,
) -> str:
    """다중 시리즈 dot-line — position:absolute로 겹침."""
    layers: list[str] = []
    for si, (h, color) in enumerate(zip(heights, colors_list)):
        dot_h = 4
        spacer = max(0, chart_h - h)
        stem_h = max(0, h - dot_h)
        pos = "position:relative;" if si == 0 else (
            "position:absolute;top:0;left:0;width:100%;"
        )
        layers.append(
            f'<div style="{pos}height:{chart_h}px;">'
            f'<div style="height:{spacer}px;"></div>'
            f'<div style="width:4px;height:{dot_h}px;background:{color};'
            f'border-radius:50%;margin:0 auto;font-size:0;line-height:0;">&nbsp;</div>'
            f'<div style="width:1px;height:{stem_h}px;background:{color};opacity:0.2;'
            f'margin:0 auto;font-size:0;line-height:0;">&nbsp;</div>'
            f'</div>'
        )
    return (
        f'<div style="position:relative;height:{chart_h}px;">'
        f'{"".join(layers)}</div>'
    )


def _fmt_y_label(val: float, y_integer: bool = False) -> str:
    """Y축 라벨 포맷."""
    if y_integer or val == int(val):
        iv = int(val)
        if iv >= 1_000_000:
            return f"{iv / 1_000_000:.1f}M"
        if iv >= 1_000:
            return f"{iv / 1_000:.0f}K"
        return str(iv)
    return f"{val:.1f}"


def _y_axis_row(y_max: float, n_cols: int, y_integer: bool = False) -> str:
    """차트 상단에 y_max 라벨을 표시하는 행."""
    label = _fmt_y_label(y_max, y_integer)
    return (
        f'<tr><td colspan="{n_cols}" '
        f'style="font-size:9px;color:#9ca3af;text-align:left;'
        f'padding-bottom:2px;height:14px;">{label}</td></tr>'
    )


def _mid_gridline_row(y_max: float, n_cols: int, chart_h: int, y_integer: bool = False) -> str:
    """차트 중간(y_max/2) 지점의 가로 점선 + 라벨. 2-2: 중간 Y축 그리드라인."""
    mid = y_max / 2
    mid_label = _fmt_y_label(mid, y_integer)
    mid_h = chart_h // 2
    return (
        f'<tr><td colspan="{n_cols}" style="height:0;position:relative;">'
        f'<div style="position:absolute;top:-{mid_h}px;left:0;right:0;'
        f'border-bottom:1px dashed #e5e7eb;height:0;"></div>'
        f'<div style="position:absolute;top:-{mid_h + 7}px;left:0;'
        f'font-size:8px;color:#9ca3af;">{mid_label}</div>'
        f'</td></tr>'
    )


def _baseline_row(n_cols: int) -> str:
    """차트 바닥에 0 라벨 + 수평선을 표시하는 행."""
    return (
        f'<tr><td colspan="{n_cols}" '
        f'style="border-top:1px solid #e5e7eb;font-size:9px;color:#9ca3af;'
        f'text-align:left;padding-top:1px;height:14px;">0</td></tr>'
    )


def _render_stat_card_body(
    items: list[tuple[str, str, str]],
) -> str:
    """Stat card HTML body (wrapper 없이). 듀얼뷰에서 차트와 합칠 때 사용."""
    cells: list[str] = []
    for label, value, color in items:
        cells.append(
            f'<td style="padding:8px 16px;text-align:center;vertical-align:top;">'
            f'<div style="font-size:24px;font-weight:700;color:{color};line-height:1.2;">'
            f'{html_escape(value)}</div>'
            f'<div style="font-size:11px;color:#6b7280;margin-top:4px;">'
            f'{html_escape(label)}</div></td>'
        )
    return (
        '<table cellpadding="0" cellspacing="0" '
        'style="width:100%;border-collapse:collapse;">'
        f'<tr>{"".join(cells)}</tr></table>'
    )


def _render_stat_cards(
    items: list[tuple[str, str, str]],
    title: str = "",
    subtitle: str = "",
) -> str:
    """Stat card 레이아웃 — (label, value, color) 리스트를 수평 카드로 표시.

    days=1 등 데이터 1~2개일 때 차트 대신 사용.
    """
    card_body = _render_stat_card_body(items)
    header = _chart_header(title, subtitle)
    return _chart_wrapper(header, card_body)


def _render_horizontal_stacked_bar(
    items: list[tuple[str, float, str]],
    title: str = "",
    subtitle: str = "",
) -> str:
    """수평 stacked bar — (label, value, color) 리스트를 가로 비율 바로 표시.

    stacked bar 데이터 1개일 때 사용.
    """
    total = sum(v for _, v, _ in items)
    if total <= 0:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    bar_cells: list[str] = []
    legend_items: list[str] = []
    for label, value, color in items:
        pct = (value / total) * 100
        if pct < 1:
            continue
        bar_cells.append(
            f'<td style="width:{pct:.1f}%;background:{color};height:32px;'
            f'font-size:0;line-height:0;">&nbsp;</td>'
        )
        val_str = f"{int(value)}" if value == int(value) else f"{value:.1f}"
        legend_items.append(
            f'<span style="display:inline-block;margin-right:12px;font-size:11px;color:#374151;">'
            f'<span style="display:inline-block;width:10px;height:10px;background:{color};'
            f'border-radius:2px;vertical-align:middle;margin-right:4px;"></span>'
            f'{html_escape(label)}: {val_str} ({pct:.0f}%)</span>'
        )

    bar_html = (
        '<table cellpadding="0" cellspacing="0" '
        'style="width:100%;border-collapse:collapse;border-radius:4px;overflow:hidden;">'
        f'<tr>{"".join(bar_cells)}</tr></table>'
    )
    legend_html = (
        f'<div style="margin-top:8px;">{"".join(legend_items)}</div>'
    )

    header = _chart_header(title, subtitle)
    return _chart_wrapper(header, bar_html + legend_html)


# ── VML 라인 차트 헬퍼 ──────────────────────────────────────

_VML_W = 560  # VML 차트 폭 (px)


def _vml_coords(
    series: dict[str, list[tuple[str, float]]],
    all_dates: list[str],
    y_min: float,
    y_max: float,
    chart_w: int,
    chart_h: int,
) -> list[list[tuple[int, int]]]:
    """각 시리즈의 VML 좌표 리스트 계산."""
    n_dates = len(all_dates)
    date_idx = {d: i for i, d in enumerate(all_dates)}
    coords_list = []
    for pts in series.values():
        coords = []
        for d, v in sorted(pts, key=lambda x: x[0]):
            if d not in date_idx:
                continue
            idx = date_idx[d]
            x = round((idx / max(1, n_dates - 1)) * chart_w)
            y = round(chart_h - ((v - y_min) / max(0.001, y_max - y_min)) * chart_h)
            coords.append((x, y))
        coords_list.append(coords)
    return coords_list


def _vml_line_body(
    coords_list: list[list[tuple[int, int]]],
    colors: list[str],
    chart_w: int,
    chart_h: int,
    reference_lines: list[dict] | None = None,
    y_min: float = 0,
    y_max: float = 1,
) -> str:
    """VML polyline + area fill body 생성."""
    parts: list[str] = []

    parts.append(
        f'<v:group coordsize="{chart_w},{chart_h}" '
        f'style="width:{chart_w}px;height:{chart_h}px;">'
    )

    # 그리드선
    mid_y = chart_h // 2
    parts.append(
        f'<v:line from="0,0" to="{chart_w},0" strokecolor="#e5e7eb" strokeweight="0.5pt">'
        f'<v:stroke dashstyle="dot"/></v:line>'
    )
    parts.append(
        f'<v:line from="0,{mid_y}" to="{chart_w},{mid_y}" strokecolor="#e5e7eb" strokeweight="0.5pt">'
        f'<v:stroke dashstyle="dot"/></v:line>'
    )
    parts.append(
        f'<v:line from="0,{chart_h}" to="{chart_w},{chart_h}" strokecolor="#e5e7eb" strokeweight="0.5pt"/>'
    )

    # Reference lines
    if reference_lines:
        for ref in reference_lines:
            rv = ref.get("value", 0)
            rc = ref.get("color", "#dc2626")
            ry = round(chart_h - ((rv - y_min) / max(0.001, y_max - y_min)) * chart_h)
            ry = max(0, min(chart_h, ry))
            parts.append(
                f'<v:line from="0,{ry}" to="{chart_w},{ry}" strokecolor="{rc}" strokeweight="1pt">'
                f'<v:stroke dashstyle="dash"/></v:line>'
            )

    # 각 시리즈: area fill + polyline
    for si, coords in enumerate(coords_list):
        if len(coords) < 2:
            continue
        color = colors[si % len(colors)]
        pts_str = " ".join(f"{x},{y}" for x, y in coords)

        # Area fill (반투명 영역) — VML path
        first_x = coords[0][0]
        last_x = coords[-1][0]
        path_parts = [f"m {coords[0][0]},{coords[0][1]}"]
        for x, y in coords[1:]:
            path_parts.append(f"l {x},{y}")
        path_parts.append(f"l {last_x},{chart_h} l {first_x},{chart_h} x e")
        vml_path = " ".join(path_parts)

        # opacity: 0.15 * 65536 ≈ 9830
        parts.append(
            f'<v:shape style="width:{chart_w}px;height:{chart_h}px;" '
            f'coordsize="{chart_w},{chart_h}" '
            f'path="{vml_path}" fillcolor="{color}" stroked="f">'
            f'<v:fill opacity="9830f"/></v:shape>'
        )

        # Polyline (실선)
        parts.append(
            f'<v:polyline points="{pts_str}" '
            f'filled="f" strokecolor="{color}" strokeweight="2pt">'
            f'<v:stroke joinstyle="round" endcap="round"/></v:polyline>'
        )

    parts.append('</v:group>')
    return "".join(parts)


# ── 라인 차트 → area fill bar (2-3) + VML (Outlook) ──────────────


def _html_line_chart(
    series: dict[str, list[tuple[str, float]]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    y_domain: tuple[float, float] | None = None,
    height: int = _CHART_H,
    reference_lines: list[dict] | None = None,
    fill_opacity: float = 0.0,
    y_integer: bool = False,
    right_series: dict[str, list[tuple[str, float]]] | None = None,
    right_y_suffix: str = "",
    right_y_domain: tuple[float, float] | None = None,
    right_colors: list[str] | None = None,
) -> str:
    """이메일용 HTML 차트 — area fill bar로 라인 차트 대체."""
    if not series:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    # 오른쪽 시리즈를 메인에 병합 (별도 스케일 표시는 범례로 구분)
    has_right = bool(right_series)
    right_count = len(right_series) if has_right else 0
    if has_right:
        if not right_colors:
            right_colors = ["#d97706", "#dc2626", "#7c3aed", "#0891b2"]
        merged_series: dict[str, list[tuple[str, float]]] = {**series}
        merged_colors = list(colors)
        for ri, (rname, rpts) in enumerate(right_series.items()):
            merged_series[rname] = rpts
            merged_colors.append(right_colors[ri % len(right_colors)])
        series = merged_series
        colors = merged_colors

    all_dates: list[str] = []
    all_values: list[float] = []
    for pts in series.values():
        for d, v in pts:
            if d not in all_dates:
                all_dates.append(d)
            all_values.append(v)
    all_dates.sort()

    if not all_dates or not all_values:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    # 2-4: days=1 (데이터 1~2개) → stat card
    s_names = list(series.keys())
    n_series = len(s_names)
    n_dates = len(all_dates)

    if n_dates <= 2:
        # stat card로 전환
        items: list[tuple[str, str, str]] = []
        for si, (sname, pts) in enumerate(series.items()):
            color = colors[si % len(colors)] if colors else "#3b82f6"
            if pts:
                val = pts[-1][1]  # 마지막 값
                val_str = f"{int(val)}{y_suffix}" if val == int(val) else f"{val:.1f}{y_suffix}"
            else:
                val_str = "-"
            items.append((sname, val_str, color))
        return _render_stat_cards(items, title, subtitle)

    y_min, y_max = _calc_y_range(all_values, y_domain, y_integer)
    chart_h = height

    # 날짜별 시리즈 값 매핑
    date_vals: dict[str, list[float]] = {d: [0.0] * n_series for d in all_dates}
    for si, (_, pts) in enumerate(series.items()):
        for d, v in pts:
            if d in date_vals:
                date_vals[d][si] = v

    # 2-5: 날짜 7개 이하 → step=1
    label_step = 1 if n_dates <= 7 else max(1, n_dates // 10)

    # ── 보간 라인 차트: 데이터 포인트 사이를 선형 보간하여 촘촘한 bar로 표현 ──
    # 셀 최소 ~4px 확보 (차트 영역 약 560px 기준)
    _TARGET_CELLS = 400
    n_interp = max(2, min(20, (_TARGET_CELLS - n_dates) // max(1, n_dates - 1)))
    # 보간을 좌우 반씩 분배 → 진한 bar가 x-tick 정중앙에 위치
    half_l = n_interp // 2
    half_r = n_interp - half_l
    # 첫/마지막 포인트도 중앙 정렬: 양 끝에 빈 패딩 추가
    # 모든 포인트의 colspan = half_l + 1 + half_r = n_interp + 1
    total_cols = n_dates * (n_interp + 1)

    # 시리즈별 단일값 시퀀스 구성 (보간 포함, 렌더링 순서대로)
    # 각 시리즈: list of (value, is_real)
    series_bars: list[list[tuple[float, bool]]] = [[] for _ in range(n_series)]

    for di in range(n_dates):
        d_vals = date_vals[all_dates[di]]

        # 왼쪽 보간 (첫 포인트는 빈 패딩 → 값 없음, 나중에 empty_td)
        if di > 0:
            prev_vals = date_vals[all_dates[di - 1]]
            for j in range(half_r, n_interp):
                t = (j + 1) / (n_interp + 1)
                for si in range(n_series):
                    v = prev_vals[si] + (d_vals[si] - prev_vals[si]) * t
                    series_bars[si].append((v, False))

        # 실제 데이터 포인트
        for si in range(n_series):
            series_bars[si].append((d_vals[si], True))

        # 오른쪽 보간 (마지막 포인트는 빈 패딩)
        if di < n_dates - 1:
            next_d_vals = date_vals[all_dates[di + 1]]
            for j in range(half_r):
                t = (j + 1) / (n_interp + 1)
                for si in range(n_series):
                    v = d_vals[si] + (next_d_vals[si] - d_vals[si]) * t
                    series_bars[si].append((v, False))

    n_bars = len(series_bars[0])

    # 시리즈별 단일 table 렌더링 함수
    def _render_series_table(si: int, include_axes: bool) -> str:
        color = colors[si % len(colors)]
        trows: list[str] = []

        if include_axes:
            trows.append(_y_axis_row(y_max, total_cols, y_integer))

        trows.append(f'<tr style="vertical-align:bottom;height:{chart_h}px;">')
        bar_i = 0
        for di in range(n_dates):
            # 왼쪽 빈 패딩 (첫 포인트만)
            if di == 0:
                for _ in range(half_l):
                    trows.append(_empty_td(chart_h))

            # 이 포인트에 속하는 bar 수
            n_left = 0 if di == 0 else half_l
            n_right = half_r if di < n_dates - 1 else 0
            for _ in range(n_left + 1 + n_right):
                val, is_real = series_bars[si][bar_i]
                h_cur = _bar_h(val, y_min, y_max, chart_h)
                if bar_i + 1 < n_bars:
                    h_next = _bar_h(series_bars[si][bar_i + 1][0], y_min, y_max, chart_h)
                else:
                    h_next = h_cur
                trows.append(_band_td(h_cur, h_next, color, chart_h, is_real))
                bar_i += 1

            # 오른쪽 빈 패딩 (마지막 포인트만)
            if di == n_dates - 1:
                for _ in range(half_r):
                    trows.append(_empty_td(chart_h))

        trows.append("</tr>")

        if include_axes:
            trows.append(_baseline_row(total_cols))
            # X축 레이블
            x_span = n_interp + 1
            trows.append("<tr>")
            for di in range(n_dates):
                label = _fmt_date(all_dates[di]) if di % label_step == 0 else ""
                trows.append(
                    f'<td colspan="{x_span}" style="font-size:9px;color:#6b7280;'
                    f'text-align:center;padding-top:2px;white-space:nowrap;">'
                    f'{html_escape(label)}</td>'
                )
            trows.append("</tr>")

        return (
            '<table cellpadding="0" cellspacing="0" '
            'style="width:100%;table-layout:fixed;border-collapse:collapse;">'
            f'{"".join(trows)}</table>'
        )

    # 단일 시리즈: 그냥 하나의 table
    if n_series == 1:
        table = _render_series_table(0, include_axes=True)
    else:
        # 다중 시리즈: 시리즈별 table을 position:absolute로 겹침
        # 첫 시리즈는 relative (높이 확보 + 축 포함), 나머지는 absolute (축 없이)
        layers: list[str] = []
        for si in range(n_series):
            if si == 0:
                layers.append(
                    f'<div style="position:relative;">'
                    f'{_render_series_table(si, include_axes=True)}'
                    f'</div>'
                )
            else:
                layers.append(
                    f'<div style="position:absolute;top:0;left:0;width:100%;">'
                    f'{_render_series_table(si, include_axes=False)}'
                    f'</div>'
                )
        table = (
            f'<div style="position:relative;">'
            f'{"".join(layers)}'
            f'</div>'
        )

    header = _chart_header(title, subtitle)
    # 범례: 오른쪽 시리즈에 단위 표시
    legend_names = list(s_names)
    if has_right and right_y_suffix:
        left_count = len(legend_names) - right_count
        for i in range(left_count, len(legend_names)):
            legend_names[i] = f"{legend_names[i]} ({right_y_suffix})"
    legend = _chart_legend(legend_names, colors)
    return _chart_wrapper(header, table, legend)


# ── 단순 막대 차트 ──────────────────────────────────────


def _html_bar_chart(
    data: list[tuple[str, float]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    y_domain: tuple[float, float] | None = None,
    height: int = _CHART_H,
    y_integer: bool = False,
) -> str:
    """이메일용 단순 막대 차트 (카테고리별 단일 값)."""
    if not data:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    # 2-4: 데이터 1~2개 → stat card
    if len(data) <= 2:
        items: list[tuple[str, str, str]] = []
        for i, (label, val) in enumerate(data):
            color = colors[i % len(colors)] if colors else "#3b82f6"
            val_str = f"{int(val)}{y_suffix}" if val == int(val) else f"{val:.1f}{y_suffix}"
            items.append((label, val_str, color))
        return _render_stat_cards(items, title, subtitle)

    values = [v for _, v in data]
    y_min, y_max = _calc_y_range(values, y_domain, y_integer)
    chart_h = height
    n_cols = len(data)

    rows: list[str] = []

    # Y축 max 라벨 행
    rows.append(_y_axis_row(y_max, n_cols, y_integer))

    # 막대 행 — gap 확대 + 상단 둥근 모서리
    rows.append(f'<tr style="vertical-align:bottom;height:{chart_h}px;">')
    for i, (_, val) in enumerate(data):
        h = _bar_h(val, y_min, y_max, chart_h)
        color = colors[i % len(colors)]
        rows.append(
            f'<td style="padding:0 4px;vertical-align:bottom;">'
            f'<div style="background:{color};height:{h}px;'
            f'border-radius:2px 2px 0 0;font-size:0;line-height:0;">&nbsp;</div></td>'
        )
    rows.append("</tr>")

    # 바닥선 행
    rows.append(_baseline_row(n_cols))

    # 값 레이블 행
    rows.append("<tr>")
    for _, val in data:
        label = f"{int(val)}" if val == int(val) else f"{val:.1f}"
        rows.append(
            f'<td style="font-size:9px;color:#374151;text-align:center;'
            f'padding-top:1px;">{label}{y_suffix}</td>'
        )
    rows.append("</tr>")

    # X축 레이블 행
    rows.append("<tr>")
    for label, _ in data:
        short = label[:10] + "…" if len(label) > 10 else label
        rows.append(
            f'<td style="font-size:9px;color:#6b7280;text-align:center;'
            f'padding-top:1px;">{html_escape(short)}</td>'
        )
    rows.append("</tr>")

    table = (
        '<table cellpadding="0" cellspacing="0" '
        'style="width:100%;border-collapse:collapse;">'
        f'{"".join(rows)}</table>'
    )

    header = _chart_header(title, subtitle)
    return _chart_wrapper(header, table)


# ── Bar + Line 복합 차트 → 막대만 ────────────────────────


def _html_bar_line_chart(
    bar_series: dict[str, list[tuple[str, float]]],
    line_series: dict[str, list[tuple[str, float]]],
    bar_colors: list[str],
    line_colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    height: int = _CHART_H,
    y_integer: bool = False,
) -> str:
    """이메일용 Bar+Line 복합 차트 — 모두 area bar로 표현."""
    merged: dict[str, list[tuple[str, float]]] = {**bar_series, **line_series}
    merged_colors = (
        [bar_colors[i % len(bar_colors)] for i in range(len(bar_series))]
        + [line_colors[i % len(line_colors)] for i in range(len(line_series))]
    )
    return _html_line_chart(
        series=merged,
        colors=merged_colors,
        title=title,
        subtitle=subtitle,
        y_suffix=y_suffix,
        height=height,
        y_integer=y_integer,
    )


# ── 누적 막대 차트 ──────────────────────────────────────

# projected 기간 회색 색상 (포탈과 동일)
_PROJECTED_COLOR = "#94a3b8"


def _html_stacked_bar_chart(
    series: dict[str, list[tuple[str, float]]],
    colors: list[str],
    title: str = "",
    subtitle: str = "",
    y_suffix: str = "",
    height: int = _CHART_H,
    reference_lines: list[dict] | None = None,
    x_formatter=None,
    y_formatter=None,
    y_integer: bool = False,
    projected_labels: set[str] | None = None,
) -> str:
    """이메일용 누적 막대 차트."""
    if not series:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    all_dates: list[str] = []
    for pts in series.values():
        for d, _ in pts:
            if d not in all_dates:
                all_dates.append(d)
    all_dates.sort()

    if not all_dates:
        return _no_data_placeholder(f"{title} 데이터가 없습니다.")

    s_names = list(series.keys())
    chart_h = height

    # 날짜별 시리즈 값 매핑
    date_stacks: dict[str, list[float]] = {
        d: [0.0] * len(s_names) for d in all_dates
    }
    for si, (_, pts) in enumerate(series.items()):
        for d, v in pts:
            if d in date_stacks:
                date_stacks[d][si] = v

    n_dates = len(all_dates)

    # 2-4: stacked bar 데이터 1개 → 수평 stacked bar
    if n_dates == 1:
        d = all_dates[0]
        vals = date_stacks[d]
        items: list[tuple[str, float, str]] = []
        for si, sname in enumerate(s_names):
            color = colors[si % len(colors)]
            items.append((sname, vals[si], color))
        date_label = _fmt_date(d)
        return _render_horizontal_stacked_bar(
            items, title, f"{subtitle} ({date_label})" if subtitle else date_label,
        )

    # 2-4: stacked bar 데이터 2개 → stat card (각 날짜별 합계)
    if n_dates == 2:
        items_sc: list[tuple[str, str, str]] = []
        for d in all_dates:
            total = sum(date_stacks[d])
            val_str = f"{int(total)}{y_suffix}" if total == int(total) else f"{total:.1f}{y_suffix}"
            items_sc.append((_fmt_date(d), val_str, colors[0] if colors else "#3b82f6"))
        return _render_stat_cards(items_sc, title, subtitle)

    # Y축 최대값 (날짜별 누적합)
    y_max = max(sum(vals) for vals in date_stacks.values())
    if y_max == 0:
        y_max = 1.0
    all_int = y_integer or all(
        v == int(v) for vals in date_stacks.values() for v in vals
    )
    if all_int:
        y_max = _nice_int_max(y_max)
    else:
        y_max = y_max * 1.1

    # 비용 차트 너비 안정화: 데이터 적으면 테이블 max-width 제한
    cost_width_style = ""
    if n_dates <= 6:
        cost_width_style = "max-width:60%;"

    # 2-5: 날짜 7개 이하 → step=1
    label_step = 1 if n_dates <= 7 else max(1, n_dates // 10)

    rows: list[str] = []

    # Y축 max 라벨 행
    rows.append(_y_axis_row(y_max, n_dates, y_integer))

    # 막대 행 — 각 셀에 누적 div를 역순 배치
    rows.append(f'<tr style="vertical-align:bottom;height:{chart_h}px;">')
    for d in all_dates:
        vals = date_stacks[d]
        is_proj = bool(projected_labels and d in projected_labels)

        if is_proj:
            # projected 기간: 회색 단일 바 (포탈과 동일)
            total = sum(vals)
            if total > 0:
                h = max(1, int((total / y_max) * chart_h))
                divs_html = (
                    f'<div style="background:{_PROJECTED_COLOR};height:{h}px;'
                    f'font-size:0;line-height:0;">&nbsp;</div>'
                )
            else:
                divs_html = ""
        else:
            # 시리즈를 역순으로 렌더링 (첫 시리즈가 바닥)
            divs: list[str] = []
            for si in reversed(range(len(s_names))):
                v = vals[si]
                if v <= 0:
                    continue
                h = max(1, int((v / y_max) * chart_h))
                color = colors[si % len(colors)]
                divs.append(
                    f'<div style="background:{color};height:{h}px;'
                    f'font-size:0;line-height:0;">&nbsp;</div>'
                )
            divs_html = "".join(divs)

        # bar 셀 너비 안정화
        rows.append(
            f'<td style="padding:0 2px;vertical-align:bottom;'
            f'min-width:6px;max-width:40px;">'
            f'{divs_html}</td>'
        )
    rows.append("</tr>")

    # 바닥선 행
    rows.append(_baseline_row(n_dates))

    # X축 레이블 행
    rows.append("<tr>")
    for di, d in enumerate(all_dates):
        if di % label_step == 0:
            label = x_formatter(d) if x_formatter else _fmt_date(d)
        else:
            label = ""
        rows.append(
            f'<td style="font-size:9px;color:#6b7280;text-align:center;'
            f'padding-top:2px;white-space:nowrap;">{html_escape(str(label))}</td>'
        )
    rows.append("</tr>")

    table = (
        f'<table cellpadding="0" cellspacing="0" '
        f'style="width:100%;border-collapse:collapse;{cost_width_style}margin:0 auto;">'
        f'{"".join(rows)}</table>'
    )

    header = _chart_header(title, subtitle)
    # 범례에 "예상" 항목 추가
    legend_names = list(s_names)
    legend_colors = list(colors[:len(s_names)])
    if projected_labels:
        legend_names.append("예상")
        legend_colors.append(_PROJECTED_COLOR)
    legend = _chart_legend(legend_names, legend_colors)
    return _chart_wrapper(header, table, legend)

