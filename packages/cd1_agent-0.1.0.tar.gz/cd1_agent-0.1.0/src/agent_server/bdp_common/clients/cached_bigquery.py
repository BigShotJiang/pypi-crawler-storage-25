"""
Cached BigQuery Provider.

RealBigQueryProvider를 래핑하여 cache-aside 패턴 적용.
캐시 히트 → 즉시 반환, 미스 → Real API 호출 → 캐시 저장 → 반환.
Real API 실패 시 캐시(만료 포함)에서 읽기 시도 (graceful degradation).
"""

import logging
from typing import Any

from src.agent_server.adw_dashboard.providers.bigquery_provider import BaseBigQueryProvider
from src.agent_server.bdp_common.stores.bigquery_cache import BqCacheStore

logger = logging.getLogger(__name__)


class CachedBigQueryProvider(BaseBigQueryProvider):
    """Cache-aside BigQuery Provider wrapper."""

    def __init__(self, real: BaseBigQueryProvider, cache: BqCacheStore):
        self._real = real
        self._cache = cache

    def _cached_call(self, method: str, param: int, fn) -> dict[str, Any]:
        """공통 cache-aside 로직."""
        # 1. 캐시 조회
        try:
            cached = self._cache.get(method, param)
            if cached is not None:
                logger.debug(f"BQ cache HIT: {method}(param={param})")
                return cached
        except Exception as e:
            logger.warning(f"BQ cache read failed: {e}")

        # 2. Real API 호출
        try:
            result = fn(param)
            # 3. 캐시 저장
            try:
                self._cache.put(method, param, result)
            except Exception as e:
                logger.warning(f"BQ cache write failed: {e}")
            return result
        except Exception as e:
            logger.warning(f"BQ real API failed ({method}): {e}, trying stale cache")
            # 4. Real 실패 시 만료 캐시라도 반환 시도
            try:
                stale = self._cache.get(method, param)
                if stale is not None:
                    return stale
            except Exception:
                pass
            raise

    def get_slot_utilization(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call("slot_utilization", days, self._real.get_slot_utilization)

    def get_query_performance(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call("query_performance", days, self._real.get_query_performance)

    def get_job_history(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call("job_history", days, self._real.get_job_history)

    def get_dataset_storage(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call("dataset_storage", days, self._real.get_dataset_storage)

    def get_cost_analysis(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call("cost_analysis", days, self._real.get_cost_analysis)

    def get_reservation_utilization(self, days: int = 31) -> dict[str, Any]:
        return self._cached_call(
            "reservation_utilization", days, self._real.get_reservation_utilization
        )

    def get_slot_timeline(self, hours: int = 24) -> dict[str, Any]:
        return self._cached_call("slot_timeline", hours, self._real.get_slot_timeline)
