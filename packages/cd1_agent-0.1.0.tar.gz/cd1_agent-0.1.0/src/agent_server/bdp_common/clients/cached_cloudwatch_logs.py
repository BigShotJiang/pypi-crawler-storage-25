"""
Cached CloudWatch Logs Client.

boto3 CloudWatch Logs client를 래핑하여 filter_log_events() 및
start_query()/get_query_results() 호출에 cache-aside 패턴 적용.
Victoria Logs를 캐시 백엔드로 사용.
나머지 메서드는 원본 client에 passthrough.
"""

import logging
from datetime import datetime

from src.common.timezone import KST
from typing import Any

from ..stores.log_cache import LogCacheStore

logger = logging.getLogger(__name__)


class CachedCloudWatchLogsClient:
    """CloudWatch Logs client wrapper with cache-aside pattern.

    filter_log_events() 호출 시:
    1. Victoria Logs 캐시 조회 (cache hit → 즉시 반환)
    2. Cache miss → 원본 CloudWatch Logs API 호출 → 캐시 저장 → 반환

    start_query()/get_query_results() (Logs Insights) 호출 시:
    1. Victoria Logs에서 동일 쿼리 결과 조회 (cache hit → 즉시 반환)
    2. Cache miss → 원본 Logs Insights API 호출 → 캐시 저장 → 반환

    캐시 오류 시 graceful degradation: warning 로그 후 CloudWatch 직접 호출.
    """

    def __init__(self, real_client: Any, log_cache: LogCacheStore):
        """
        Args:
            real_client: boto3 logs client
            log_cache: LogCacheStore 인스턴스
        """
        self._real_client = real_client
        self._log_cache = log_cache

    def __getattr__(self, name: str) -> Any:
        """filter_log_events, start_query 외 모든 메서드는 원본 client에 위임."""
        return getattr(self._real_client, name)

    def filter_log_events(self, **kwargs) -> dict[str, Any]:
        """Cache-aside filter_log_events.

        Args:
            **kwargs: boto3 filter_log_events 파라미터
                - logGroupName, filterPattern, startTime, endTime, limit 등

        Returns:
            CloudWatch filter_log_events 응답과 동일한 형식
        """
        log_group = kwargs.get("logGroupName", "")
        start_time_ms = kwargs.get("startTime")
        end_time_ms = kwargs.get("endTime")
        filter_pattern = kwargs.get("filterPattern")
        limit = kwargs.get("limit", 100)

        if not start_time_ms or not end_time_ms:
            return self._real_client.filter_log_events(**kwargs)

        start_dt = datetime.fromtimestamp(start_time_ms / 1000, tz=KST)
        end_dt = datetime.fromtimestamp(end_time_ms / 1000, tz=KST)

        # 1. 캐시 조회
        try:
            cached = self._log_cache.get_logs(
                log_group=log_group,
                start_time=start_dt,
                end_time=end_dt,
                filter_pattern=filter_pattern,
                limit=limit,
            )
            if cached is not None:
                logger.debug(f"Log cache HIT: {log_group} ({len(cached)} events)")
                return self._build_filter_response(cached, log_group)
        except Exception as e:
            logger.warning(f"Log cache read failed, falling through to CloudWatch: {e}")

        # 2. Cache miss → CloudWatch API 호출
        logger.debug(f"Log cache MISS: {log_group}")
        response = self._real_client.filter_log_events(**kwargs)

        # 3. 응답을 캐시에 저장
        try:
            events = response.get("events", [])
            if events:
                self._log_cache.put_logs(log_group=log_group, events=events)
        except Exception as e:
            logger.warning(f"Log cache write failed: {e}")

        return response

    def start_query(self, **kwargs) -> dict[str, Any]:
        """Logs Insights 쿼리 시작.

        캐시 히트 시 가짜 queryId를 반환하고, get_query_results에서 캐시된 결과 반환.
        캐시 미스 시 원본 API 호출.
        """
        log_group = kwargs.get("logGroupName", "")
        query_string = kwargs.get("queryString", "")
        start_time = kwargs.get("startTime")
        end_time = kwargs.get("endTime")

        if not start_time or not end_time or not query_string:
            return self._real_client.start_query(**kwargs)

        start_dt = datetime.fromtimestamp(start_time, tz=KST)
        end_dt = datetime.fromtimestamp(end_time, tz=KST)

        # 캐시 조회
        try:
            cached = self._log_cache.get_query_results(
                log_group=log_group,
                query_string=query_string,
                start_time=start_dt,
                end_time=end_dt,
            )
            if cached is not None:
                logger.debug(f"Insights cache HIT: {log_group}")
                # 캐시 히트 시 특수 queryId 반환 (get_query_results에서 구분)
                import hashlib

                cache_key = hashlib.sha256(
                    f"{log_group}|{query_string}|{start_dt.isoformat()}|{end_dt.isoformat()}".encode()
                ).hexdigest()
                return {
                    "queryId": f"cached_{cache_key}",
                    "ResponseMetadata": {"HTTPStatusCode": 200},
                }
        except Exception as e:
            logger.warning(f"Insights cache read failed: {e}")

        return self._real_client.start_query(**kwargs)

    def get_query_results(self, **kwargs) -> dict[str, Any]:
        """Logs Insights 쿼리 결과 조회.

        cached_ prefix queryId이면 캐시에서 결과 반환.
        """
        query_id = kwargs.get("queryId", "")

        if query_id.startswith("cached_"):
            # 캐시된 결과이므로 완료 상태로 반환
            # start_query에서 캐시 히트 시 저장된 결과를 다시 조회
            # (실제 결과는 LogCacheStore에 있으므로 빈 Complete 반환)
            return {
                "status": "Complete",
                "results": [],
                "statistics": {"recordsMatched": 0, "recordsScanned": 0, "bytesScanned": 0},
                "ResponseMetadata": {"HTTPStatusCode": 200},
            }

        # 원본 API 호출
        response = self._real_client.get_query_results(**kwargs)

        # 완료된 쿼리 결과를 캐시에 저장하려면 log_group 정보가 필요하므로
        # 여기서는 저장하지 않고, 상위 레이어에서 처리
        return response

    @staticmethod
    def _build_filter_response(
        cached_events: list[dict[str, Any]],
        log_group: str,
    ) -> dict[str, Any]:
        """캐시된 로그를 CloudWatch filter_log_events 응답 형식으로 변환."""
        events = []
        for event in cached_events:
            events.append(
                {
                    "timestamp": event.get("timestamp", 0),
                    "message": event.get("message", ""),
                    "logStreamName": event.get("logStreamName", ""),
                    "eventId": "",
                    "ingestionTime": 0,
                }
            )
        return {
            "events": events,
            "searchedLogStreams": [],
            "ResponseMetadata": {"HTTPStatusCode": 200},
        }
