"""
Cached CloudWatch Client.

boto3 CloudWatch client를 래핑하여 get_metric_statistics() 호출에
cache-aside 패턴 적용 (Victoria Metrics 백엔드).
나머지 메서드는 원본 client에 passthrough.
"""

import logging
from typing import Any

from ..stores.metric_cache import MetricCacheStore, hash_dimensions

logger = logging.getLogger(__name__)


class CachedCloudWatchClient:
    """CloudWatch client wrapper with cache-aside pattern.

    get_metric_statistics() 호출 시:
    1. Victoria Metrics 캐시 조회 (cache hit → 즉시 반환)
    2. Cache miss → 원본 CloudWatch API 호출 → 캐시 저장 → 반환

    캐시 오류 시 graceful degradation: warning 로그 후 CloudWatch 직접 호출.
    """

    def __init__(self, real_client: Any, cache_store: MetricCacheStore):
        """
        Args:
            real_client: boto3 cloudwatch client
            cache_store: MetricCacheStore 인스턴스
        """
        self._real_client = real_client
        self._cache_store = cache_store

    def __getattr__(self, name: str) -> Any:
        """get_metric_statistics 외 모든 메서드는 원본 client에 위임."""
        return getattr(self._real_client, name)

    def get_metric_statistics(self, **kwargs) -> dict[str, Any]:
        """Cache-aside get_metric_statistics.

        Args:
            **kwargs: boto3 get_metric_statistics 파라미터
                - Namespace, MetricName, Dimensions, StartTime, EndTime,
                  Period, Statistics, Unit 등

        Returns:
            CloudWatch get_metric_statistics 응답과 동일한 형식
        """
        namespace = kwargs.get("Namespace", "")
        metric_name = kwargs.get("MetricName", "")
        dimensions = kwargs.get("Dimensions", [])
        period = kwargs.get("Period", 300)
        statistics = kwargs.get("Statistics", [])
        start_time = kwargs.get("StartTime")
        end_time = kwargs.get("EndTime")

        if not statistics or not start_time or not end_time:
            return self._real_client.get_metric_statistics(**kwargs)

        statistic = statistics[0]  # 현재 모든 fetcher가 단일 statistic 사용
        dims_hash = hash_dimensions(dimensions)

        # 1. 캐시 조회
        try:
            cached = self._cache_store.get_data_points(
                namespace=namespace,
                metric_name=metric_name,
                dimensions_hash=dims_hash,
                period_seconds=period,
                statistic=statistic,
                start_time=start_time,
                end_time=end_time,
            )
            if cached is not None:
                logger.debug(f"Cache HIT: {namespace}/{metric_name} ({len(cached)} points)")
                return self._build_response(cached, statistic, kwargs)
        except Exception as e:
            logger.warning(f"Cache read failed, falling through to CloudWatch: {e}")

        # 2. Cache miss → CloudWatch API 호출
        logger.debug(f"Cache MISS: {namespace}/{metric_name}")
        response = self._real_client.get_metric_statistics(**kwargs)

        # 3. 응답을 캐시에 저장
        try:
            raw_points = response.get("Datapoints", [])
            if raw_points:
                cache_points = [
                    {
                        "Timestamp": dp["Timestamp"],
                        "Value": dp.get(statistic, 0.0),
                        "Unit": dp.get("Unit", ""),
                    }
                    for dp in raw_points
                ]
                self._cache_store.put_data_points(
                    namespace=namespace,
                    metric_name=metric_name,
                    dimensions_hash=dims_hash,
                    period_seconds=period,
                    statistic=statistic,
                    data_points=cache_points,
                    unit=raw_points[0].get("Unit"),
                )
        except Exception as e:
            logger.warning(f"Cache write failed: {e}")

        return response

    @staticmethod
    def _build_response(
        cached_points: list[dict[str, Any]],
        statistic: str,
        original_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """캐시된 데이터를 CloudWatch 응답 형식으로 변환."""
        datapoints = []
        for cp in cached_points:
            dp = {
                "Timestamp": cp["Timestamp"],
                statistic: cp["Value"],
            }
            if cp.get("Unit"):
                dp["Unit"] = cp["Unit"]
            datapoints.append(dp)

        return {
            "Label": original_kwargs.get("MetricName", ""),
            "Datapoints": datapoints,
            "ResponseMetadata": {"HTTPStatusCode": 200},
        }
