"""Chart data transformation utilities.

프론트엔드 차트 컴포넌트에서 필요한 데이터 변환을 서버 사이드에서 수행한다.
recharts가 요구하는 flat array format으로 변환하는 공통 헬퍼 함수들.
"""

from __future__ import annotations

from typing import Any


def flatten_series_to_chart(
    groups: dict[str, list[dict[str, Any]]],
    value_key: str,
    date_key: str = "date",
) -> dict[str, Any]:
    """다중 시리즈를 차트 포맷으로 변환.

    Input:  {name: [{date, value_key: v}, ...]}
    Output: {chart_data: [{date, name1: v1, name2: v2}], series_keys: [name1, name2]}
    """
    date_map: dict[str, dict[str, Any]] = {}
    series_keys = list(groups.keys())
    for name, series in groups.items():
        for pt in series:
            d = pt[date_key]
            row = date_map.setdefault(d, {date_key: d})
            row[name] = pt[value_key]
    chart_data = sorted(date_map.values(), key=lambda r: str(r[date_key]))
    return {"chart_data": chart_data, "series_keys": series_keys}


def flatten_nested_series_to_chart(
    groups: dict[str, dict[str, Any]],
    series_key: str,
    value_key: str,
    date_key: str = "date",
) -> dict[str, Any]:
    """중첩 구조의 시리즈를 차트 포맷으로 변환.

    Input:  {name: {series_key: [{date, value_key: v}]}}
    Output: {chart_data: [{date, name1: v1, name2: v2}], series_keys: [name1, name2]}
    """
    inner: dict[str, list[dict[str, Any]]] = {}
    for name, obj in groups.items():
        if isinstance(obj, dict) and series_key in obj:
            inner[name] = obj[series_key]
    return flatten_series_to_chart(inner, value_key, date_key)


def flatten_multi_metric_chart(
    groups: dict[str, Any],
    series_key: str,
    metrics: dict[str, str],
    date_key: str = "date",
) -> dict[str, Any]:
    """다중 메트릭을 key_suffix 형태로 차트 포맷 변환.

    Input:  {name: {series_key: [{date, cpu_cores: v, memory_gb: v}]}}
    metrics: {"cpu": "cpu_cores", "mem": "memory_gb"}
    Output: {chart_data: [{date, name1_cpu: v, name1_mem: v}], series_keys: [...]}
    """
    date_map: dict[str, dict[str, Any]] = {}
    all_keys: list[str] = []
    for name, obj in groups.items():
        series = obj.get(series_key, []) if isinstance(obj, dict) else []
        for suffix, field in metrics.items():
            key = f"{name}_{suffix}"
            all_keys.append(key)
            for pt in series:
                d = pt[date_key]
                row = date_map.setdefault(d, {date_key: d})
                row[key] = pt.get(field, 0)
    chart_data = sorted(date_map.values(), key=lambda r: str(r[date_key]))
    return {"chart_data": chart_data, "series_keys": all_keys}


def aggregate_series_to_chart(
    groups: dict[str, Any],
    series_key: str,
    metrics: list[str],
    date_key: str = "date",
) -> dict[str, Any]:
    """그룹 간 메트릭을 날짜별로 합산.

    Input:  {name: {series_key: [{date, submitted: v, completed: v}]}}
    metrics: ["submitted", "completed", "failed"]
    Output: {chart_data: [{date, submitted: sum, completed: sum, failed: sum}]}
    """
    date_map: dict[str, dict[str, Any]] = {}
    for obj in groups.values():
        series = obj.get(series_key, []) if isinstance(obj, dict) else []
        for pt in series:
            d = pt[date_key]
            row = date_map.setdefault(d, {date_key: d, **{m: 0 for m in metrics}})
            for m in metrics:
                row[m] += pt.get(m, 0)
    chart_data = sorted(date_map.values(), key=lambda r: str(r[date_key]))
    return {"chart_data": chart_data}


def flatten_path_multi_metric_chart(
    groups: dict[str, Any],
    series_key: str,
    metrics: dict[str, str],
    date_key: str = "date",
    path_shortener: bool = False,
) -> dict[str, Any]:
    """경로(path) 키를 짧은 이름으로 변환하여 다중 메트릭 차트 생성.

    NAS 마운트 경로 등에서 /path/to/mount → mount 로 축약.
    """
    date_map: dict[str, dict[str, Any]] = {}
    all_keys: list[str] = []
    short_names: list[str] = []
    for path, obj in groups.items():
        short = path.rsplit("/", 1)[-1] if path_shortener else path
        short_names.append(short)
        series = obj.get(series_key, []) if isinstance(obj, dict) else []
        for suffix, field in metrics.items():
            key = f"{short}_{suffix}"
            all_keys.append(key)
            for pt in series:
                d = pt[date_key]
                row = date_map.setdefault(d, {date_key: d})
                row[key] = pt.get(field, 0)
    chart_data = sorted(date_map.values(), key=lambda r: str(r[date_key]))
    return {"chart_data": chart_data, "series_keys": all_keys, "short_names": short_names}


def flatten_path_single_metric_chart(
    groups: dict[str, Any],
    series_key: str,
    value_key: str,
    date_key: str = "date",
    path_shortener: bool = False,
) -> dict[str, Any]:
    """경로(path) 키를 짧은 이름으로 변환하여 단일 메트릭 차트 생성."""
    date_map: dict[str, dict[str, Any]] = {}
    short_names: list[str] = []
    for path, obj in groups.items():
        short = path.rsplit("/", 1)[-1] if path_shortener else path
        short_names.append(short)
        series = obj.get(series_key, []) if isinstance(obj, dict) else []
        for pt in series:
            d = pt[date_key]
            row = date_map.setdefault(d, {date_key: d})
            row[short] = pt.get(value_key, 0)
    chart_data = sorted(date_map.values(), key=lambda r: str(r[date_key]))
    return {"chart_data": chart_data, "series_keys": short_names}


def compute_spark_summary(
    clusters: dict[str, Any],
) -> dict[str, int]:
    """Spark 클러스터 전체 노드 상태 요약 계산."""
    all_nodes: list[dict[str, Any]] = []
    for cluster in clusters.values():
        nodes = cluster.get("nodes")
        if nodes and isinstance(nodes, dict):
            all_nodes.extend(nodes.values())
    return {
        "total_nodes": len(all_nodes),
        "running_nodes": sum(1 for n in all_nodes if n.get("status") == "Running"),
        "pending_nodes": sum(1 for n in all_nodes if n.get("status") == "Pending"),
        "failed_nodes": sum(1 for n in all_nodes if n.get("status") == "Failed"),
    }


def structure_k8s_data(
    nodes: list[dict[str, Any]],
    pods: list[dict[str, Any]],
) -> dict[str, Any]:
    """K8s 노드/파드 데이터를 구조화.

    - 노드를 node_group별로 그룹핑
    - 파드를 node_name별로 매핑
    """
    # 노드그룹별 그룹핑
    node_groups: dict[str, list[dict[str, Any]]] = {}
    for node in nodes:
        ng = node.get("node_group") or "(ungrouped)"
        node_groups.setdefault(ng, []).append(node)

    # 파드 → 노드 매핑
    pods_by_node: dict[str, list[dict[str, Any]]] = {}
    for pod in pods:
        node_name = pod.get("node_name")
        if node_name:
            pods_by_node.setdefault(node_name, []).append(pod)

    return {
        "node_groups": node_groups,
        "pods_by_node": pods_by_node,
    }


def compute_namespace_summaries(
    namespaces: dict[str, dict[str, Any]],
    node_groups: dict[str, list[dict[str, Any]]],
    pods_by_node: dict[str, list[dict[str, Any]]],
) -> dict[str, dict[str, Any]]:
    """네임스페이스별 요약 통계를 서버에서 미리 계산.

    각 네임스페이스에 대해:
    - 해당 네임스페이스의 파드가 있는 노드만 필터
    - 노드 수, Ready 노드 수, 파드 상태별 수 계산
    """
    ns_summaries: dict[str, dict[str, Any]] = {}
    for ns_name, stats in namespaces.items():
        running = stats.get("running", 0)
        pending = stats.get("pending", 0)
        failed = stats.get("failed", 0)

        # 해당 네임스페이스 파드가 있는 노드 찾기
        relevant_node_names: set[str] = set()
        for node_name, pods in pods_by_node.items():
            if any(p.get("namespace") == ns_name for p in pods):
                relevant_node_names.add(node_name)

        # 관련 노드 수, Ready 노드 수 계산
        node_count = 0
        ready_nodes = 0
        for _ng_name, ng_nodes in node_groups.items():
            for node in ng_nodes:
                if node.get("name") in relevant_node_names:
                    node_count += 1
                    if node.get("status") == "Ready":
                        ready_nodes += 1

        ns_summaries[ns_name] = {
            "total_nodes": node_count,
            "ready_nodes": ready_nodes,
            "total_pods": running + pending + failed,
            "running_pods": running,
            "failed_pods": failed,
            "pending_pods": pending,
        }
    return ns_summaries


def compute_highlighted_pod_names(
    selector: str,
    namespace: str,
    pods: list[dict[str, Any]],
) -> list[str]:
    """서비스 selector로 매칭되는 파드 이름 목록 반환."""
    parts = selector.split("=")
    if len(parts) != 2:
        return []
    label_val = parts[1]
    return [
        p["name"]
        for p in pods
        if p.get("namespace") == namespace and p.get("name", "").startswith(label_val)
    ]
