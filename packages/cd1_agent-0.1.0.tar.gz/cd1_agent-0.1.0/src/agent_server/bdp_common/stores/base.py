"""
Base DB providers for baseline stores.

MySQL (Secrets Manager) / SQLite 연결 인프라 공통 코드.
bdp_drift, bdp_metrics 등 에이전트별 baseline_store에서 상속하여 사용.
"""

import json
import logging
import sqlite3
from typing import Any

from src.common.timezone import KST, get_kst_now  # noqa: F401 – re-export

logger = logging.getLogger(__name__)


class BaseSQLiteProvider:
    """SQLite 연결 인프라 (유닛 테스트용).

    Subclass에서 도메인별 ABC와 함께 다중 상속하여 사용.
    """

    def __init__(self, db_path: str = ":memory:"):
        """SQLite 프로바이더 초기화.

        Args:
            db_path: 데이터베이스 파일 경로 (기본값: 인메모리)
        """
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None
        logger.info(f"SQLite provider initialized: {db_path}")

    @property
    def conn(self) -> sqlite3.Connection:
        """SQLite 연결."""
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn


class BaseMySqlProvider:
    """MySQL 연결 인프라 (Secrets Manager 연동).

    Subclass에서 도메인별 ABC와 함께 다중 상속하여 사용.
    """

    def __init__(
        self,
        secret_id: str,
        db: str,
        region: str = "ap-northeast-2",
    ):
        """MySqlProvider 초기화.

        Args:
            secret_id: AWS Secrets Manager Secret ID
            db: RDS DB Schema 이름
            region: AWS 리전
        """
        self.secret_id = secret_id
        self.db = db
        self.region = region
        self._conn = None
        self._credentials: dict[str, Any] | None = None
        logger.info(f"MySQL provider initialized with secret: {secret_id}")

    def _get_credentials(self) -> dict[str, Any]:
        """AWS Secrets Manager에서 DB credentials 획득."""
        if self._credentials is None:
            from src.common.services.aws_session import get_boto3_client

            client = get_boto3_client("secretsmanager", region=self.region)
            response = client.get_secret_value(SecretId=self.secret_id)
            self._credentials = json.loads(response["SecretString"])
        assert self._credentials is not None
        return self._credentials

    @property
    def conn(self):
        """MySQL 연결."""
        if self._conn is None or not self._conn.open:
            import pymysql

            creds = self._get_credentials()
            self._conn = pymysql.connect(
                host=creds["host"],
                port=creds.get("port", 3306),
                user=creds["username"],
                database=self.db,
                password=creds["password"],
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=False,
            )
            logger.info(f"MySQL connection established to {creds['host']}")
        else:
            try:
                self._conn.ping(reconnect=True)
            except Exception:
                import pymysql

                creds = self._get_credentials()
                self._conn = pymysql.connect(
                    host=creds["host"],
                    port=creds.get("port", 3306),
                    user=creds["username"],
                    database=self.db,
                    password=creds["password"],
                    charset="utf8mb4",
                    cursorclass=pymysql.cursors.DictCursor,
                    autocommit=False,
                )
                logger.info(f"MySQL connection re-established to {creds['host']}")
        return self._conn
