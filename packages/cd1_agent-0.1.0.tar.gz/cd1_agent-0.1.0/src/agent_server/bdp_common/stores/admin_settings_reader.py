"""Read-only access to admin_settings table.

Handler에서 포털 admin_settings override 값을 읽기 위한 리더.
MetricConfigReader와 동일한 패턴으로 bdp_common의 Base provider를 통해 접근.
"""

import logging
import os

from src.agent_server.bdp_common.stores.base import BaseMySqlProvider, BaseSQLiteProvider

logger = logging.getLogger(__name__)


class AdminSettingsReader:
    """Read-only access to admin_settings table.

    Uses same DB credentials as MetricsBaselineStore via bdp_common providers.
    Returns None gracefully if table doesn't exist or provider is mock.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: str | None = None,
        db: str | None = None,
    ):
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)

    def _create_provider(
        self,
        provider: str,
        secret_id: str | None,
        db: str | None,
    ):
        if provider == "sqlite":
            db_path = os.getenv("BASELINE_SQLITE_PATH", ":memory:")
            return BaseSQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                return None
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return BaseMySqlProvider(secret_id=secret_id, db=db or "", region=region)
        return None

    def get_setting(self, key: str) -> str | None:
        """Return the override value for a given setting key.

        Returns None if provider is mock, table doesn't exist,
        key not found, or DB is unavailable.
        """
        if self._provider is None:
            return None

        try:
            conn = self._provider.conn
            if isinstance(self._provider, BaseSQLiteProvider):
                cur = conn.execute("SELECT value FROM admin_settings WHERE key = ?", (key,))
                row = cur.fetchone()
                return row["value"] if row else None
            else:
                with conn.cursor() as cur:
                    cur.execute("SELECT value FROM admin_settings WHERE `key` = %s", (key,))
                    row = cur.fetchone()
                    return row["value"] if row else None

        except Exception as e:
            logger.warning(f"Failed to read admin setting '{key}': {e}")
            return None
