"""
Log Cache Store - Victoria Logs 기반 CloudWatch 로그 캐시.

Provider 패턴:
- VictoriaLogsProvider: VictoriaLogs HTTP API 기반 실제 캐시
- MockLogProvider: dict 기반 (테스트용)
- NoOpLogProvider: 항상 cache miss (캐시 비활성화)

라벨 설계 (인시던트 상관관계 분석 고려):
- _stream: source, log_group, region으로 스트림 구분
- _time: 로그 타임스탬프 (ISO 8601)
- _msg: 로그 메시지
- log_stream: CloudWatch logStreamName
- filter_pattern: 원본 조회 시 사용된 필터

같은 시점의 장애 예측 쿼리 예시 (LogsQL):
  {source="cloudwatch"} AND ERROR
  {source="cloudwatch", log_group="/aws/mwaa/prod/scheduler"} AND "OOMKilled"
"""

import json
import logging
import os
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any

from src.common.timezone import KST

logger = logging.getLogger(__name__)


class LogCacheProvider(ABC):
    """로그 캐시 프로바이더 추상 클래스."""

    @abstractmethod
    def get_logs(
        self,
        log_group: str,
        start_time: datetime,
        end_time: datetime,
        filter_pattern: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]] | None:
        """캐시된 로그 조회.

        Returns:
            캐시 히트 시 로그 이벤트 리스트, 미스 시 None
        """

    @abstractmethod
    def put_logs(
        self,
        log_group: str,
        events: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        """로그를 캐시에 저장."""

    @abstractmethod
    def get_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        """Logs Insights 쿼리 결과 캐시 조회.

        Returns:
            캐시 히트 시 결과 리스트, 미스 시 None
        """

    @abstractmethod
    def put_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
        results: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        """Logs Insights 쿼리 결과를 캐시에 저장."""


def _ts_to_iso(ts: Any) -> str:
    """타임스탬프(밀리초 int 또는 datetime)를 ISO 문자열로 변환."""
    if isinstance(ts, datetime):
        return ts.isoformat()
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts / 1000, tz=KST).isoformat()
    return str(ts)


def _query_cache_key(
    log_group: str, query_string: str, start_time: datetime, end_time: datetime
) -> str:
    """Logs Insights 쿼리에 대한 캐시 키 생성."""
    import hashlib

    raw = f"{log_group}|{query_string}|{start_time.isoformat()}|{end_time.isoformat()}"
    return hashlib.sha256(raw.encode()).hexdigest()


class VictoriaLogsProvider(LogCacheProvider):
    """Victoria Logs 기반 캐시 프로바이더.

    VictoriaLogs HTTP API 사용:
    - 쓰기: /insert/jsonline (JSON Lines format)
    - 읽기: /select/logsql/query (LogsQL)
    """

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.timeout = timeout
        self._session = None

    def _get_session(self):
        """Lazy requests session."""
        if self._session is None:
            import requests

            self._session = requests.Session()
            if self.auth_token:
                self._session.headers["Authorization"] = f"Bearer {self.auth_token}"
        return self._session

    def get_logs(
        self,
        log_group: str,
        start_time: datetime,
        end_time: datetime,
        filter_pattern: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]] | None:
        """VL에서 LogsQL로 로그 조회."""
        # LogsQL 쿼리 구성
        stream_filter = f'_stream:{{source="cloudwatch",log_group="{log_group}"}}'
        query = stream_filter
        if filter_pattern:
            # filter_pattern에서 따옴표 제거 후 검색어로 추가
            clean_pattern = filter_pattern.strip('"').strip("'")
            query = f"{stream_filter} AND {clean_pattern}"

        params = {
            "query": query,
            "start": start_time.isoformat() + "Z"
            if not start_time.tzinfo
            else start_time.isoformat(),
            "end": end_time.isoformat() + "Z" if not end_time.tzinfo else end_time.isoformat(),
            "limit": limit,
        }
        session = self._get_session()
        url = f"{self.base_url}/select/logsql/query"
        try:
            resp = session.get(url, params=params, timeout=self.timeout)
            resp.raise_for_status()

            # VL은 JSON Lines 형식으로 응답
            events = []
            for line in resp.text.strip().split("\n"):
                if not line.strip():
                    continue
                doc = json.loads(line)
                events.append(
                    {
                        "timestamp": doc.get("_time", ""),
                        "message": doc.get("_msg", ""),
                        "logStreamName": doc.get("log_stream", ""),
                    }
                )

            return events if events else None
        except Exception as e:
            logger.warning(f"VL get_logs failed: {e}")
            return None

    def put_logs(
        self,
        log_group: str,
        events: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        """VL /insert/jsonline 엔드포인트에 로그 저장."""
        lines = []
        for event in events:
            doc = {
                "_msg": event.get("message", ""),
                "_time": _ts_to_iso(event.get("timestamp", "")),
                "log_stream": event.get("logStreamName", ""),
                "log_group": log_group,
                "region": region,
                "source": "cloudwatch",
            }
            lines.append(json.dumps(doc, ensure_ascii=False))

        body = "\n".join(lines)
        session = self._get_session()
        url = f"{self.base_url}/insert/jsonline?_stream_fields=source,log_group,region"
        try:
            resp = session.post(
                url,
                data=body.encode("utf-8"),
                timeout=self.timeout,
                headers={"Content-Type": "application/stream+json"},
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning(f"VL put_logs failed: {e}")

    def get_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        """Logs Insights 캐시 결과 조회.

        Logs Insights 결과는 _stream에 query_type="insights"로 구분하여 저장.
        """
        cache_key = _query_cache_key(log_group, query_string, start_time, end_time)
        stream_filter = f'_stream:{{source="cloudwatch_insights",cache_key="{cache_key}"}}'

        # Insights 캐시는 _time이 저장 시점이므로, 넓은 범위로 조회
        now = datetime.now(KST)
        search_start = now - timedelta(days=365)
        params = {
            "query": stream_filter,
            "start": search_start.isoformat(),
            "end": (now + timedelta(minutes=1)).isoformat(),
            "limit": 1,
        }
        session = self._get_session()
        url = f"{self.base_url}/select/logsql/query"
        try:
            resp = session.get(url, params=params, timeout=self.timeout)
            resp.raise_for_status()

            for line in resp.text.strip().split("\n"):
                if not line.strip():
                    continue
                doc = json.loads(line)
                cached_results = doc.get("_msg", "")
                if cached_results:
                    return json.loads(cached_results)

            return None
        except Exception as e:
            logger.warning(f"VL get_query_results failed: {e}")
            return None

    def put_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
        results: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        """Logs Insights 결과를 VL에 저장."""
        cache_key = _query_cache_key(log_group, query_string, start_time, end_time)
        doc = {
            "_msg": json.dumps(results, ensure_ascii=False, default=str),
            "_time": datetime.now(KST).isoformat(),
            "log_group": log_group,
            "query_string": query_string,
            "source": "cloudwatch_insights",
            "cache_key": cache_key,
        }
        body = json.dumps(doc, ensure_ascii=False)
        session = self._get_session()
        url = f"{self.base_url}/insert/jsonline?_stream_fields=source,cache_key,log_group"
        try:
            resp = session.post(
                url,
                data=body.encode("utf-8"),
                timeout=self.timeout,
                headers={"Content-Type": "application/stream+json"},
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning(f"VL put_query_results failed: {e}")


class MockLogProvider(LogCacheProvider):
    """Dict 기반 Mock 로그 캐시 (테스트용)."""

    def __init__(self):
        self.log_store: dict[str, list[dict[str, Any]]] = {}
        self.query_store: dict[str, list[dict[str, Any]]] = {}

    def get_logs(
        self,
        log_group: str,
        start_time: datetime,
        end_time: datetime,
        filter_pattern: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]] | None:
        cached = self.log_store.get(log_group)
        if not cached:
            return None
        # 간단한 시간 범위 필터는 생략 (mock이므로)
        return cached[:limit] if cached else None

    def put_logs(
        self,
        log_group: str,
        events: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        existing = self.log_store.get(log_group, [])
        existing.extend(events)
        self.log_store[log_group] = existing

    def get_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        cache_key = _query_cache_key(log_group, query_string, start_time, end_time)
        return self.query_store.get(cache_key)

    def put_query_results(
        self,
        log_group: str,
        query_string: str,
        start_time: datetime,
        end_time: datetime,
        results: list[dict[str, Any]],
        region: str = "ap-northeast-2",
    ) -> None:
        cache_key = _query_cache_key(log_group, query_string, start_time, end_time)
        self.query_store[cache_key] = results


class NoOpLogProvider(LogCacheProvider):
    """항상 cache miss를 반환하는 프로바이더 (캐시 비활성화)."""

    def get_logs(self, *args, **kwargs) -> list[dict[str, Any]] | None:
        return None

    def put_logs(self, *args, **kwargs) -> None:
        pass

    def get_query_results(self, *args, **kwargs) -> list[dict[str, Any]] | None:
        return None

    def put_query_results(self, *args, **kwargs) -> None:
        pass


class LogCacheStore:
    """로그 캐시 Facade.

    환경변수 LOG_CACHE_PROVIDER로 프로바이더 선택:
    - "victoria_logs": Victoria Logs 실제 캐시
    - "mock": Dict 기반 테스트 캐시
    - "noop" (기본값): 캐시 비활성화
    """

    def __init__(self, provider: str | None = None):
        provider_name = provider or os.getenv("LOG_CACHE_PROVIDER", "noop")
        self.provider = self._create_provider(provider_name)
        self.provider_type = provider_name
        logger.info(f"LogCacheStore initialized: provider={provider_name}")

    @staticmethod
    def _create_provider(provider_name: str) -> LogCacheProvider:
        if provider_name == "victoria_logs":
            vl_url = os.getenv("VL_URL", "")
            if not vl_url:
                logger.warning("VL_URL not set, falling back to noop")
                return NoOpLogProvider()
            return VictoriaLogsProvider(
                base_url=vl_url,
                auth_token=os.getenv("VL_AUTH_TOKEN"),
                timeout=int(os.getenv("VL_TIMEOUT", "30")),
            )
        elif provider_name == "mock":
            return MockLogProvider()
        else:
            return NoOpLogProvider()

    def get_logs(self, **kwargs) -> list[dict[str, Any]] | None:
        return self.provider.get_logs(**kwargs)

    def put_logs(self, **kwargs) -> None:
        self.provider.put_logs(**kwargs)

    def get_query_results(self, **kwargs) -> list[dict[str, Any]] | None:
        return self.provider.get_query_results(**kwargs)

    def put_query_results(self, **kwargs) -> None:
        self.provider.put_query_results(**kwargs)
