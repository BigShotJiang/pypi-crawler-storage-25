"""
Metric Cache Store - Victoria Metrics 기반 CloudWatch 메트릭 캐시.

Provider 패턴:
- VictoriaMetricsProvider: Prometheus 호환 API 기반 실제 캐시
- MockProvider: dict 기반 (테스트용)
- NoOpProvider: 항상 cache miss (캐시 비활성화)
"""

import hashlib
import json
import logging
import os
from abc import ABC, abstractmethod
from datetime import datetime

from src.common.timezone import KST
from typing import Any

logger = logging.getLogger(__name__)


def hash_dimensions(dimensions: list[dict[str, str]]) -> str:
    """Dimensions 리스트를 정렬 후 SHA-256 해시.

    Args:
        dimensions: CloudWatch Dimensions 리스트
            e.g. [{"Name": "ClusterName", "Value": "my-cluster"}]

    Returns:
        hex digest 문자열
    """
    sorted_dims = sorted(dimensions, key=lambda d: (d.get("Name", ""), d.get("Value", "")))
    raw = json.dumps(sorted_dims, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


class MetricCacheProvider(ABC):
    """메트릭 캐시 프로바이더 추상 클래스."""

    @abstractmethod
    def get_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        """캐시된 데이터 포인트 조회.

        Returns:
            캐시 히트 시 datapoint 리스트, 미스 시 None
        """

    @abstractmethod
    def put_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        data_points: list[dict[str, Any]],
        unit: str | None = None,
    ) -> None:
        """데이터 포인트를 캐시에 저장."""


class VictoriaMetricsProvider(MetricCacheProvider):
    """Victoria Metrics 기반 캐시 프로바이더.

    Prometheus 호환 API 사용:
    - 쓰기: /api/v1/import/prometheus (Prometheus text exposition format)
    - 읽기: /api/v1/query_range (PromQL)

    라벨 설계 (인시던트 상관관계 분석 고려):
    - __name__: cw_cache_{statistic} (예: cw_cache_Average)
    - namespace: AWS 서비스 네임스페이스 (예: AWS/RDS)
    - metric_name: CloudWatch 메트릭 이름 (예: CPUUtilization)
    - dimensions_hash: Dimensions SHA-256 해시
    - period: 데이터 집계 주기 (초)
    - unit: CloudWatch 단위 (선택)

    같은 시점의 장애 예측 쿼리 예시:
      {__name__=~"cw_cache_.*", metric_name="CPUUtilization"}
      cw_cache_Average{namespace="AWS/RDS"}
    """

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.timeout = timeout
        self._session = None

    def _get_session(self):
        """Lazy requests session."""
        if self._session is None:
            import requests

            self._session = requests.Session()
            if self.auth_token:
                self._session.headers["Authorization"] = f"Bearer {self.auth_token}"
        return self._session

    def get_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        """VM에서 PromQL query_range로 데이터 조회."""
        metric_label = f"cw_cache_{statistic}"
        query = (
            f"{metric_label}{{"
            f'namespace="{namespace}",'
            f'metric_name="{metric_name}",'
            f'dimensions_hash="{dimensions_hash}",'
            f'period="{period_seconds}"}}'
        )
        params = {
            "query": query,
            "start": start_time.timestamp(),
            "end": end_time.timestamp(),
            "step": f"{period_seconds}s",
        }
        session = self._get_session()
        url = f"{self.base_url}/api/v1/query_range"
        try:
            resp = session.get(url, params=params, timeout=self.timeout)
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") != "success":
                return None
            results = data.get("data", {}).get("result", [])
            if not results:
                return None
            # matrix result: results[0]["values"] = [[timestamp, "value"], ...]
            points = []
            for ts_val in results[0].get("values", []):
                points.append(
                    {
                        "Timestamp": datetime.fromtimestamp(float(ts_val[0]), tz=KST),
                        "Value": float(ts_val[1]),
                        "Unit": results[0].get("metric", {}).get("unit", ""),
                    }
                )
            return points if points else None
        except Exception as e:
            logger.warning(f"VM get failed: {e}")
            return None

    def put_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        data_points: list[dict[str, Any]],
        unit: str | None = None,
    ) -> None:
        """VM에 Prometheus text format으로 데이터 저장."""
        lines = []
        metric_label = f"cw_cache_{statistic}"
        label_parts = [
            f'namespace="{namespace}"',
            f'metric_name="{metric_name}"',
            f'dimensions_hash="{dimensions_hash}"',
            f'period="{period_seconds}"',
        ]
        if unit:
            label_parts.append(f'unit="{unit}"')
        labels = ",".join(label_parts)

        for dp in data_points:
            ts = dp["Timestamp"]
            if isinstance(ts, datetime):
                ts_ms = int(ts.timestamp() * 1000)
            else:
                ts_ms = int(ts)
            value = dp["Value"]
            lines.append(f"{metric_label}{{{labels}}} {value} {ts_ms}")

        body = "\n".join(lines)
        session = self._get_session()
        url = f"{self.base_url}/api/v1/import/prometheus"
        try:
            resp = session.post(
                url,
                data=body,
                timeout=self.timeout,
                headers={"Content-Type": "text/plain"},
            )
            resp.raise_for_status()
        except Exception as e:
            logger.warning(f"VM put failed: {e}")


class MockProvider(MetricCacheProvider):
    """Dict 기반 Mock 캐시 프로바이더 (테스트용)."""

    def __init__(self):
        self.store: dict[str, list[dict[str, Any]]] = {}

    def _make_key(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
    ) -> str:
        return f"{namespace}|{metric_name}|{dimensions_hash}|{period_seconds}|{statistic}"

    def get_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        start_time: datetime,
        end_time: datetime,
    ) -> list[dict[str, Any]] | None:
        key = self._make_key(namespace, metric_name, dimensions_hash, period_seconds, statistic)
        cached = self.store.get(key)
        if not cached:
            return None
        # 시간 범위 필터
        filtered = [dp for dp in cached if start_time <= dp["Timestamp"] <= end_time]
        return filtered if filtered else None

    def put_data_points(
        self,
        namespace: str,
        metric_name: str,
        dimensions_hash: str,
        period_seconds: int,
        statistic: str,
        data_points: list[dict[str, Any]],
        unit: str | None = None,
    ) -> None:
        key = self._make_key(namespace, metric_name, dimensions_hash, period_seconds, statistic)
        self.store[key] = list(data_points)


class NoOpProvider(MetricCacheProvider):
    """항상 cache miss를 반환하는 프로바이더 (캐시 비활성화)."""

    def get_data_points(self, *args, **kwargs) -> list[dict[str, Any]] | None:
        return None

    def put_data_points(self, *args, **kwargs) -> None:
        pass


class MetricCacheStore:
    """메트릭 캐시 Facade.

    환경변수 METRIC_CACHE_PROVIDER로 프로바이더 선택:
    - "victoria_metrics": Victoria Metrics 실제 캐시
    - "mock": Dict 기반 테스트 캐시
    - "noop" (기본값): 캐시 비활성화
    """

    def __init__(self, provider: str | None = None):
        provider_name = provider or os.getenv("METRIC_CACHE_PROVIDER", "noop")
        self.provider = self._create_provider(provider_name)
        self.provider_type = provider_name
        logger.info(f"MetricCacheStore initialized: provider={provider_name}")

    @staticmethod
    def _create_provider(provider_name: str) -> MetricCacheProvider:
        if provider_name == "victoria_metrics":
            vm_url = os.getenv("VM_URL", "")
            if not vm_url:
                logger.warning("VM_URL not set, falling back to noop")
                return NoOpProvider()
            return VictoriaMetricsProvider(
                base_url=vm_url,
                auth_token=os.getenv("VM_AUTH_TOKEN"),
                timeout=int(os.getenv("VM_TIMEOUT", "30")),
            )
        elif provider_name == "mock":
            return MockProvider()
        else:
            return NoOpProvider()

    def get_data_points(self, **kwargs) -> list[dict[str, Any]] | None:
        return self.provider.get_data_points(**kwargs)

    def put_data_points(self, **kwargs) -> None:
        self.provider.put_data_points(**kwargs)
