"""Read-only access to bdp_metric_configs table.

Handler에서 enabled metrics를 읽어오기 위한 리더.
Portal의 MetricConfigService와 동일한 DB를 사용하되,
bdp_common의 Base provider를 통해 접근한다.
"""

import logging
import os
from collections import defaultdict
from typing import Dict, List, Optional

from .base import BaseMySqlProvider, BaseSQLiteProvider

logger = logging.getLogger(__name__)

# Portal의 metric_config_service.py와 동일한 매핑
SERVICE_TYPE_MAPPING = {
    "mwaa": "mwaa",
    "sagemaker": "sagemaker-endpoint",
    "sagemaker endpoint": "sagemaker-endpoint",
    "rds": "rds",
    "emr(cluster)": "emr-cluster",
    "emr(serverless)": "emr-serverless",
    "msk": "msk",
}


class MetricConfigReader:
    """Read-only access to bdp_metric_configs table.

    Uses same DB credentials as MetricsBaselineStore via bdp_common providers.
    Returns empty dict gracefully if table doesn't exist.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
    ):
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)

    def _create_provider(
        self, provider: str, secret_id: Optional[str], db: Optional[str],
    ):
        if provider == "sqlite":
            db_path = os.getenv("BASELINE_SQLITE_PATH", ":memory:")
            return BaseSQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                return None
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return BaseMySqlProvider(secret_id=secret_id, db=db or "", region=region)
        return None

    def get_enabled_by_service(self) -> Dict[str, List[str]]:
        """Return {resource_type: [metric_names]} for enabled configs.

        Returns empty dict if provider is mock, table doesn't exist,
        or DB is unavailable.
        """
        if self._provider is None:
            return {}

        try:
            conn = self._provider.conn
            if isinstance(self._provider, BaseSQLiteProvider):
                cur = conn.execute(
                    "SELECT service_type, metric_name FROM bdp_metric_configs WHERE enabled = 1"
                )
                rows = [dict(row) for row in cur.fetchall()]
            else:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT service_type, metric_name FROM bdp_metric_configs WHERE enabled = 1"
                    )
                    rows = list(cur.fetchall())

            result: Dict[str, List[str]] = defaultdict(list)
            for row in rows:
                resource_type = SERVICE_TYPE_MAPPING.get(row["service_type"])
                if resource_type:
                    result[resource_type].append(row["metric_name"])
            return dict(result)

        except Exception as e:
            logger.warning(f"Failed to read metric configs: {e}")
            return {}
