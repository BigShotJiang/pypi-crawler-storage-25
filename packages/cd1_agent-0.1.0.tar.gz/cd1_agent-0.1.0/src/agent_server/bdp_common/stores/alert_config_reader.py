"""Alert Config Reader - Portal DB에서 알림 설정을 읽는 Reader.

Agent Server에서 Detection 수행 시 서비스/메트릭별 sensitivity를 동적으로 조회.
MetricConfigReader와 동일한 패턴 사용.
"""

import logging
import os
import time
from typing import Any

logger = logging.getLogger(__name__)


class AlertConfigReader:
    """Portal DB에서 bdp_alert_configs 테이블 읽기.

    5분 TTL 인메모리 캐시로 반복 DB 조회 최소화.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: str | None = None,
        db: str | None = None,
    ):
        self.provider = provider
        self.secret_id = secret_id
        self.db_name = db
        self._cache: dict[str, dict[str, Any]] = {}
        self._cache_ts: float = 0
        self._ttl = 300  # 5분

    def get_config(self, service_type: str, metric_name: str) -> dict[str, Any] | None:
        """특정 메트릭의 알림 설정 조회.

        Returns:
            설정 dict 또는 None (설정 없음)
        """
        self._refresh_if_stale()
        key = f"{service_type}:{metric_name}"
        return self._cache.get(key)

    def get_sensitivity(self, service_type: str, metric_name: str, default: float = 0.7) -> float:
        """특정 메트릭의 sensitivity 반환. 설정 없거나 비활성이면 기본값."""
        config = self.get_config(service_type, metric_name)
        if config and config.get("enabled"):
            return config.get("sensitivity", default)
        return default

    def get_all_configs(self) -> list[dict[str, Any]]:
        """전체 알림 설정 목록."""
        self._refresh_if_stale()
        return list(self._cache.values())

    def _refresh_if_stale(self) -> None:
        """캐시 TTL 초과 시 DB에서 갱신."""
        now = time.time()
        if now - self._cache_ts < self._ttl:
            return

        try:
            configs = self._load_from_db()
            self._cache = {}
            for cfg in configs:
                key = f"{cfg['service_type']}:{cfg['metric_name']}"
                self._cache[key] = cfg
            self._cache_ts = now
            logger.debug(f"AlertConfigReader cache refreshed: {len(configs)} configs")
        except Exception as e:
            logger.warning(f"AlertConfigReader DB 읽기 실패, 기존 캐시 유지: {e}")

    def _load_from_db(self) -> list[dict[str, Any]]:
        """DB에서 전체 설정 로드."""
        if self.provider == "mock":
            return []

        if self.provider == "sqlite":
            return self._load_sqlite()
        elif self.provider == "mysql":
            return self._load_mysql()
        return []

    def _load_sqlite(self) -> list[dict[str, Any]]:
        """SQLite에서 로드."""
        import sqlite3

        db_path = self.db_name or os.getenv("PORTAL_DB_PATH", "data/portal.db")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.execute("SELECT * FROM bdp_alert_configs WHERE enabled = 1")
            return [dict(row) for row in cur.fetchall()]
        except Exception:
            return []
        finally:
            conn.close()

    def _load_mysql(self) -> list[dict[str, Any]]:
        """MySQL에서 로드."""
        try:
            from src.agent_server.bdp_common.stores.base import get_mysql_connection

            conn = get_mysql_connection(self.secret_id, self.db_name)
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM bdp_alert_configs WHERE enabled = 1")
                return [dict(row) for row in cur.fetchall()]
        except Exception as e:
            logger.warning(f"AlertConfigReader MySQL 로드 실패: {e}")
            return []
