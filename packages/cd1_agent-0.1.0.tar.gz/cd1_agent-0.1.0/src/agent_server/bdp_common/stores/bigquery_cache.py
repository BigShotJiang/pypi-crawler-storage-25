"""
BigQuery Cache Store - Victoria Metrics 기반 BQ 쿼리 결과 캐시.

Provider 패턴:
- VictoriaBqCacheProvider: VM JSON API 기반 실제 캐시
- NoOpBqCacheProvider: 항상 cache miss (캐시 비활성화)

캐시 키 설계:
- 메트릭명: bq_cache_{method} (예: bq_cache_slot_utilization)
- 라벨: project, param (days 또는 hours 값)
"""

import hashlib
import json
import logging
import os
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.common.timezone import KST

logger = logging.getLogger(__name__)


class BqCacheProvider(ABC):
    """BQ 캐시 프로바이더 추상 클래스."""

    @abstractmethod
    def get(self, method: str, param: int) -> dict[str, Any] | None:
        """캐시된 결과 조회. 미스 시 None."""

    @abstractmethod
    def put(self, method: str, param: int, data: dict[str, Any]) -> None:
        """결과를 캐시에 저장."""


class VictoriaBqCacheProvider(BqCacheProvider):
    """Victoria Metrics 기반 BQ 캐시.

    JSON 직렬화된 BQ 결과를 단일 time-series로 저장.
    읽기: /api/v1/query (instant query)
    쓰기: /api/v1/import/prometheus
    """

    def __init__(self, base_url: str, auth_token: str | None = None, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.timeout = timeout
        self._session = None

    def _get_session(self):
        if self._session is None:
            import requests

            self._session = requests.Session()
            if self.auth_token:
                self._session.headers["Authorization"] = f"Bearer {self.auth_token}"
        return self._session

    def _cache_key(self, method: str, param: int) -> str:
        return hashlib.sha256(f"{method}:{param}".encode()).hexdigest()[:16]

    def get(self, method: str, param: int) -> dict[str, Any] | None:
        metric = f"bq_cache_{method}"
        key = self._cache_key(method, param)
        query = f'{metric}{{cache_key="{key}"}}'
        session = self._get_session()
        try:
            resp = session.get(
                f"{self.base_url}/api/v1/query",
                params={"query": query},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            results = data.get("data", {}).get("result", [])
            if not results:
                return None
            # 값에 JSON 문자열이 저장되어 있음
            raw = results[0].get("value", [None, None])
            if raw and len(raw) > 1 and raw[1] != "0":
                # 메트릭 값이 아닌 annotation에 저장
                annotations = results[0].get("metric", {})
                payload = annotations.get("payload")
                if payload:
                    return json.loads(payload)
            return None
        except Exception as e:
            logger.debug(f"BQ cache get failed ({method}): {e}")
            return None

    def put(self, method: str, param: int, data: dict[str, Any]) -> None:
        metric = f"bq_cache_{method}"
        key = self._cache_key(method, param)
        payload = json.dumps(data, ensure_ascii=False, default=str)
        # payload를 라벨에 저장, 값은 timestamp
        ts_ms = int(datetime.now(tz=KST).timestamp() * 1000)
        # payload가 너무 크면 VM 라벨에 저장 불가 → 별도 API 사용
        # 여기서는 간단히 파일 캐시로 fallback
        cache_dir = os.getenv("BQ_CACHE_DIR", "/tmp/bq_cache")
        os.makedirs(cache_dir, exist_ok=True)
        cache_file = os.path.join(cache_dir, f"{method}_{param}.json")
        try:
            with open(cache_file, "w") as f:
                json.dump({"ts": ts_ms, "data": data}, f, ensure_ascii=False, default=str)
        except Exception as e:
            logger.warning(f"BQ cache put failed ({method}): {e}")


class FileBqCacheProvider(BqCacheProvider):
    """파일 기반 BQ 캐시. 로컬 개발에서 pre-seeded 데이터 사용."""

    def __init__(self, cache_dir: str | None = None, ttl_hours: int = 24):
        self.cache_dir = cache_dir or os.getenv("BQ_CACHE_DIR", "/tmp/bq_cache")
        self.ttl_seconds = ttl_hours * 3600
        os.makedirs(self.cache_dir, exist_ok=True)

    def _path(self, method: str, param: int) -> str:
        return os.path.join(self.cache_dir, f"{method}_{param}.json")

    def get(self, method: str, param: int) -> dict[str, Any] | None:
        path = self._path(method, param)
        try:
            with open(path) as f:
                cached = json.load(f)
            # TTL 체크
            ts = cached.get("ts", 0) / 1000
            if (datetime.now().timestamp() - ts) > self.ttl_seconds:
                logger.debug(f"BQ file cache expired: {method}_{param}")
                return None
            return cached.get("data")
        except (FileNotFoundError, json.JSONDecodeError):
            return None
        except Exception as e:
            logger.debug(f"BQ file cache get failed ({method}): {e}")
            return None

    def put(self, method: str, param: int, data: dict[str, Any]) -> None:
        path = self._path(method, param)
        try:
            ts_ms = int(datetime.now().timestamp() * 1000)
            with open(path, "w") as f:
                json.dump({"ts": ts_ms, "data": data}, f, ensure_ascii=False, default=str)
        except Exception as e:
            logger.warning(f"BQ file cache put failed ({method}): {e}")


class NoOpBqCacheProvider(BqCacheProvider):
    """항상 cache miss (캐시 비활성화)."""

    def get(self, method: str, param: int) -> dict[str, Any] | None:
        return None

    def put(self, method: str, param: int, data: dict[str, Any]) -> None:
        pass


class BqCacheStore:
    """BQ 캐시 Facade.

    환경변수 BQ_CACHE_PROVIDER로 프로바이더 선택:
    - "file": 파일 기반 캐시 (로컬 개발 기본)
    - "victoria_metrics": VM 기반 캐시
    - "noop": 캐시 비활성화
    """

    def __init__(self, provider: str | None = None):
        provider_name = provider or os.getenv("BQ_CACHE_PROVIDER", "file")
        self.provider = self._create_provider(provider_name)
        self.provider_type = provider_name
        logger.info(f"BqCacheStore initialized: provider={provider_name}")

    @staticmethod
    def _create_provider(name: str) -> BqCacheProvider:
        if name == "victoria_metrics":
            vm_url = os.getenv("VM_URL", "")
            if not vm_url:
                logger.warning("VM_URL not set, falling back to file cache")
                return FileBqCacheProvider()
            return VictoriaBqCacheProvider(
                base_url=vm_url,
                auth_token=os.getenv("VM_AUTH_TOKEN"),
                timeout=int(os.getenv("VM_TIMEOUT", "30")),
            )
        elif name == "file":
            return FileBqCacheProvider()
        else:
            return NoOpBqCacheProvider()

    def get(self, method: str, param: int) -> dict[str, Any] | None:
        return self.provider.get(method, param)

    def put(self, method: str, param: int, data: dict[str, Any]) -> None:
        self.provider.put(method, param, data)
