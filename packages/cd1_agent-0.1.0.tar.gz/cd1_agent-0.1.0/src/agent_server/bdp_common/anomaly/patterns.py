"""
Pattern Recognizers for Anomaly Detection.

패턴 인식기 모듈 - False Positive 감소를 위한 패턴 인식 전략.
도메인 무관 범용 구현. TimeSeriesData 기반.

Features:
- DayOfWeekRecognizer: 평일/주말 패턴 인식
- TrendRecognizer: 점진적 추세 인식
- MonthCycleRecognizer: 월초/월말 패턴 인식
- ProfileRecognizer: 스파이크 정상 프로파일 인식 (일반화)
- SeasonalityRecognizer: 계절성 패턴 인식
- PatternChain: 여러 인식기를 체인으로 연결
"""

import logging
import os
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import List, Optional, Protocol

import numpy as np

from .models import TimeSeriesData

logger = logging.getLogger(__name__)


class PatternType(Enum):
    """패턴 타입."""

    DAY_OF_WEEK = "day_of_week"
    MONTH_CYCLE = "month_cycle"
    TREND = "trend"
    PROFILE = "profile"
    SEASONALITY = "seasonality"


@dataclass
class PatternContext:
    """패턴 인식 결과 맥락 정보."""

    pattern_type: PatternType
    expected_value: float
    actual_value: float
    confidence_adjustment: float  # -0.4 ~ +0.1
    explanation: str


class PatternRecognizer(Protocol):
    """패턴 인식기 인터페이스."""

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]: ...


class DayOfWeekRecognizer:
    """평일/주말 패턴 인식기."""

    WEEKDAY_ADJUSTMENT = -0.20
    TOLERANCE_RATIO = 0.30

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]:
        timestamps = data.timestamps
        values = data.historical_values

        if len(values) < 7:
            return None

        try:
            current_date = datetime.fromisoformat(timestamps[-1])
            is_weekend = current_date.weekday() >= 5

            same_type_values = []
            for val, ts in zip(values[:-1], timestamps[:-1]):
                try:
                    date = datetime.fromisoformat(ts)
                    if (date.weekday() >= 5) == is_weekend:
                        same_type_values.append(val)
                except ValueError:
                    continue

            if len(same_type_values) < 2:
                return None

            expected = float(np.mean(same_type_values))
            actual = data.current_value

            if expected <= 0:
                return None

            ratio = actual / expected
            if (1 - self.TOLERANCE_RATIO) <= ratio <= (1 + self.TOLERANCE_RATIO):
                day_type = "주말" if is_weekend else "평일"
                return PatternContext(
                    pattern_type=PatternType.DAY_OF_WEEK,
                    expected_value=expected,
                    actual_value=actual,
                    confidence_adjustment=self.WEEKDAY_ADJUSTMENT,
                    explanation=f"{day_type} 평균 대비 정상 범위",
                )

            return None

        except (ValueError, IndexError) as e:
            logger.debug(f"DayOfWeekRecognizer failed: {e}")
            return None


class TrendRecognizer:
    """점진적 추세 인식기."""

    TREND_ADJUSTMENT = -0.15
    DEVIATION_THRESHOLD = 0.15

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]:
        values = data.historical_values

        if len(values) < 7:
            return None

        try:
            x = np.arange(len(values))
            coeffs = np.polyfit(x, values, 1)
            slope, intercept = coeffs[0], coeffs[1]

            expected = slope * len(x) + intercept
            actual = data.current_value

            if expected <= 0:
                return None

            deviation = abs(actual - expected) / expected

            if deviation <= self.DEVIATION_THRESHOLD:
                return PatternContext(
                    pattern_type=PatternType.TREND,
                    expected_value=expected,
                    actual_value=actual,
                    confidence_adjustment=self.TREND_ADJUSTMENT,
                    explanation=f"추세선 기반 예상 범위 내 (편차: {deviation:.1%})",
                )

            return None

        except (ValueError, np.linalg.LinAlgError) as e:
            logger.debug(f"TrendRecognizer failed: {e}")
            return None


class MonthCycleRecognizer:
    """월초/월말 패턴 인식기."""

    MONTH_CYCLE_ADJUSTMENT = -0.15
    TOLERANCE_RATIO = 0.30
    MONTH_START_DAYS = [1, 2, 3, 4, 5]
    MONTH_END_DAYS = [26, 27, 28, 29, 30, 31]

    def __init__(
        self,
        adjustment: Optional[float] = None,
        tolerance_ratio: Optional[float] = None,
        month_start_days: Optional[List[int]] = None,
        month_end_days: Optional[List[int]] = None,
    ):
        self.adjustment = adjustment if adjustment is not None else self.MONTH_CYCLE_ADJUSTMENT
        self.tolerance_ratio = tolerance_ratio if tolerance_ratio is not None else self.TOLERANCE_RATIO
        self.month_start_days = month_start_days if month_start_days is not None else self.MONTH_START_DAYS
        self.month_end_days = month_end_days if month_end_days is not None else self.MONTH_END_DAYS

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]:
        timestamps = data.timestamps
        values = data.historical_values

        if len(values) < 14:
            return None

        try:
            current_date = datetime.fromisoformat(timestamps[-1])
            day_of_month = current_date.day

            if day_of_month in self.month_start_days:
                period_days = self.month_start_days
                period_name = "월초"
            elif day_of_month in self.month_end_days:
                period_days = self.month_end_days
                period_name = "월말"
            else:
                return None

            same_period_values = []
            for val, ts in zip(values[:-1], timestamps[:-1]):
                try:
                    date = datetime.fromisoformat(ts)
                    if date.day in period_days:
                        same_period_values.append(val)
                except ValueError:
                    continue

            if len(same_period_values) < 2:
                return None

            expected = float(np.mean(same_period_values))
            actual = data.current_value

            if expected <= 0:
                return None

            ratio = actual / expected
            if (1 - self.tolerance_ratio) <= ratio <= (1 + self.tolerance_ratio):
                return PatternContext(
                    pattern_type=PatternType.MONTH_CYCLE,
                    expected_value=expected,
                    actual_value=actual,
                    confidence_adjustment=self.adjustment,
                    explanation=f"{period_name} 기간 평균 대비 정상 범위",
                )

            return None

        except (ValueError, IndexError) as e:
            logger.debug(f"MonthCycleRecognizer failed: {e}")
            return None


class ProfileRecognizer:
    """프로파일 기반 스파이크 정상 인식기 (일반화).

    특정 이름 패턴의 리소스/메트릭에서 스파이크성 변동이 정상인 경우를 인식.
    """

    PROFILE_ADJUSTMENT = -0.10

    def __init__(
        self,
        adjustment: Optional[float] = None,
        spike_normal_names: Optional[List[str]] = None,
    ):
        self.adjustment = adjustment if adjustment is not None else self.PROFILE_ADJUSTMENT
        self.spike_normal_names = spike_normal_names or []

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]:
        name = data.name

        for spike_name in self.spike_normal_names:
            if spike_name.lower() in name.lower():
                if self._has_spike_pattern(data.historical_values):
                    return PatternContext(
                        pattern_type=PatternType.PROFILE,
                        expected_value=float(np.mean(data.historical_values[:-1])),
                        actual_value=data.current_value,
                        confidence_adjustment=self.adjustment,
                        explanation=f"{spike_name} 스파이크 정상 프로파일",
                    )

        return None

    def _has_spike_pattern(self, values: List[float]) -> bool:
        if len(values) < 7:
            return False

        arr = np.array(values)
        mean = np.mean(arr)
        std = np.std(arr)

        if mean == 0:
            return False

        cv = std / mean
        return cv >= 0.3


class SeasonalityRecognizer:
    """계절성 패턴 인식기."""

    SEASONALITY_ADJUSTMENT = -0.15
    TOLERANCE_RATIO = 0.30
    MIN_DATA_POINTS = 30
    ACF_THRESHOLD = 0.3
    DEFAULT_CANDIDATE_PERIODS = [7, 14, 30]
    MIN_CYCLE_SAMPLES = 2

    def __init__(
        self,
        adjustment: Optional[float] = None,
        tolerance_ratio: Optional[float] = None,
        min_data_points: Optional[int] = None,
        acf_threshold: Optional[float] = None,
        candidate_periods: Optional[List[int]] = None,
    ):
        self.adjustment = adjustment if adjustment is not None else self.SEASONALITY_ADJUSTMENT
        self.tolerance_ratio = tolerance_ratio if tolerance_ratio is not None else self.TOLERANCE_RATIO
        self.min_data_points = min_data_points if min_data_points is not None else self.MIN_DATA_POINTS
        self.acf_threshold = acf_threshold if acf_threshold is not None else self.ACF_THRESHOLD
        self.candidate_periods = candidate_periods if candidate_periods is not None else self.DEFAULT_CANDIDATE_PERIODS

    def recognize(self, data: TimeSeriesData) -> Optional[PatternContext]:
        values = data.historical_values

        if len(values) < self.min_data_points:
            return None

        try:
            arr = np.array(values, dtype=float)

            if np.std(arr) == 0:
                return None

            # 디트렌드
            x = np.arange(len(arr))
            coeffs = np.polyfit(x, arr, 1)
            residuals = arr - np.polyval(coeffs, x)

            # 후보 주기별 자기상관
            best_period = None
            best_acf = -1.0

            for period in self.candidate_periods:
                if len(residuals) < period * self.MIN_CYCLE_SAMPLES:
                    continue

                n = len(residuals)
                mean = np.mean(residuals)
                variance = np.sum((residuals - mean) ** 2)

                if variance == 0:
                    continue

                covariance = np.sum(
                    (residuals[:n - period] - mean) * (residuals[period:] - mean)
                )
                acf = float(covariance / variance)

                if acf >= self.acf_threshold and acf > best_acf:
                    best_acf = acf
                    best_period = period

            if best_period is None:
                return None

            # 예상값 계산
            current_position = (len(arr) - 1) % best_period
            same_pos = [arr[i] for i in range(len(arr) - 1) if i % best_period == current_position]

            if not same_pos:
                return None

            expected = float(np.mean(same_pos))
            actual = data.current_value

            if expected <= 0:
                return None

            ratio = actual / expected
            if (1 - self.tolerance_ratio) <= ratio <= (1 + self.tolerance_ratio):
                return PatternContext(
                    pattern_type=PatternType.SEASONALITY,
                    expected_value=expected,
                    actual_value=actual,
                    confidence_adjustment=self.adjustment,
                    explanation=f"{best_period}일 주기 패턴 내 정상 범위 (ACF: {best_acf:.2f})",
                )

            return None

        except (ValueError, np.linalg.LinAlgError) as e:
            logger.debug(f"SeasonalityRecognizer failed: {e}")
            return None


class PatternChain:
    """패턴 인식기 체인. Chain of Responsibility 구현."""

    DEFAULT_MAX_ADJUSTMENT = -0.40

    def __init__(
        self,
        recognizers: Optional[List[PatternRecognizer]] = None,
        max_adjustment: Optional[float] = None,
    ):
        self.recognizers = recognizers or []

        if max_adjustment is not None:
            self.max_adjustment = max_adjustment
        else:
            env_max = os.getenv("BDP_PATTERN_MAX_ADJUSTMENT", "0.4")
            try:
                self.max_adjustment = -abs(float(env_max))
            except ValueError:
                self.max_adjustment = self.DEFAULT_MAX_ADJUSTMENT

    def recognize_all(self, data: TimeSeriesData) -> List[PatternContext]:
        contexts = []

        for recognizer in self.recognizers:
            try:
                ctx = recognizer.recognize(data)
                if ctx is not None:
                    contexts.append(ctx)
            except Exception as e:
                logger.warning(f"Pattern recognizer failed: {e}")
                continue

        return contexts

    def get_total_adjustment(self, data: TimeSeriesData) -> float:
        contexts = self.recognize_all(data)
        total = sum(ctx.confidence_adjustment for ctx in contexts)
        return max(total, self.max_adjustment)

    def get_explanations(self, data: TimeSeriesData) -> List[str]:
        contexts = self.recognize_all(data)
        return [ctx.explanation for ctx in contexts]


def create_default_pattern_chain(
    enabled: Optional[bool] = None,
    max_adjustment: Optional[float] = None,
    spike_normal_names: Optional[List[str]] = None,
) -> Optional[PatternChain]:
    """기본 패턴 체인 생성.

    Args:
        enabled: 활성화 여부 (None이면 환경 변수 사용)
        max_adjustment: 최대 조정값
        spike_normal_names: 스파이크 정상 이름 목록

    Returns:
        PatternChain 또는 None
    """
    if enabled is None:
        env_enabled = os.getenv("BDP_PATTERN_RECOGNITION")
        if env_enabled is not None:
            enabled = env_enabled.lower() in ("true", "1", "yes")
        else:
            enabled = True

    if not enabled:
        logger.info("Pattern recognition disabled")
        return None

    recognizers: List[PatternRecognizer] = [
        DayOfWeekRecognizer(),
        TrendRecognizer(),
    ]

    if spike_normal_names:
        recognizers.append(ProfileRecognizer(spike_normal_names=spike_normal_names))

    chain = PatternChain(
        recognizers=recognizers,
        max_adjustment=max_adjustment,
    )

    logger.info(
        f"Pattern chain created with {len(chain.recognizers)} recognizers, "
        f"max_adjustment={chain.max_adjustment}"
    )

    return chain
