"""
Ensemble Anomaly Detector.

ECOD + Ratio + Z-score 가중 앙상블 기반 이상 탐지기.
CostDriftDetector를 도메인 무관하게 일반화.

Features:
- PyOD 설치 시: 고급 ECOD 알고리즘 사용
- PyOD 미설치 시: 경량 LightweightECOD 사용
- Pattern-Aware Detection: 패턴 인식으로 False Positive 감소
"""

import logging
import os
from typing import Any, Dict, List, Optional

import numpy as np

from .ecod import PYOD_AVAILABLE, LightweightECOD
from .models import AnomalyResult, AnomalySeverity, TimeSeriesData
from .patterns import PatternChain

logger = logging.getLogger(__name__)

if PYOD_AVAILABLE:
    from pyod.models.ecod import ECOD


class EnsembleDetector:
    """ECOD 기반 앙상블 이상 탐지기.

    Usage:
        detector = EnsembleDetector(sensitivity=0.7)
        result = detector.analyze(data)
    """

    def __init__(
        self,
        sensitivity: float = 0.7,
        min_data_points: int = 7,
        ratio_threshold: float = 1.5,
        contamination: float = 0.1,
        pattern_chain: Optional[PatternChain] = None,
        ecod_weight: float = 0.4,
        ratio_weight: float = 0.3,
        stddev_weight: float = 0.3,
        z_score_threshold: float = 3.0,
        stddev_min_data_points: int = 7,
    ):
        """탐지기 초기화.

        Args:
            sensitivity: 탐지 민감도 (0.0-1.0)
            min_data_points: 최소 필요 데이터 포인트 수
            ratio_threshold: Ratio 기반 탐지 임계값 (배수)
            contamination: ECOD 이상치 비율 추정값
            pattern_chain: 패턴 인식기 체인 (None이면 패턴 인식 비활성화)
            ecod_weight: ECOD 앙상블 가중치
            ratio_weight: Ratio 앙상블 가중치
            stddev_weight: Stddev 앙상블 가중치
            z_score_threshold: Z-score 임계값
            stddev_min_data_points: Stddev 최소 데이터 포인트 수
        """
        self.sensitivity = sensitivity
        self.min_data_points = min_data_points
        self.ratio_threshold = ratio_threshold
        self.contamination = contamination

        self.confidence_threshold = 0.6 - (sensitivity * 0.1)

        # 앙상블 가중치
        self.ecod_weight = ecod_weight
        self.ratio_weight = ratio_weight
        self.stddev_weight = stddev_weight

        # Stddev 설정
        self.z_score_threshold = z_score_threshold
        self.stddev_min_data_points = stddev_min_data_points

        # Pattern-Aware Detection
        self.pattern_chain = pattern_chain

        # Shadow mode
        self.pattern_shadow_mode = os.getenv("BDP_PATTERN_MODE", "active") == "shadow"

    def analyze(self, data: TimeSeriesData) -> AnomalyResult:
        """시계열 데이터 이상 탐지 분석.

        Args:
            data: 시계열 입력 데이터

        Returns:
            AnomalyResult 탐지 결과
        """
        historical = data.historical_values

        if len(historical) < self.min_data_points:
            return AnomalyResult(
                is_anomaly=False,
                confidence_score=0.0,
                severity=AnomalySeverity.LOW,
                change_percent=0.0,
                detection_method="insufficient_data",
            )

        # 개별 탐지 방법 실행
        ecod_result = self._detect_ecod(historical)
        ratio_result = self._detect_ratio(historical)
        stddev_result = self._detect_stddev(historical)

        # 앙상블 스코어 계산
        ensemble_result = self._calculate_ensemble_score(
            ecod_result, ratio_result, stddev_result
        )

        is_anomaly = ensemble_result["is_anomaly"]
        raw_confidence = ensemble_result["confidence"]
        detection_method = ensemble_result["method"] + ensemble_result["method_suffix"]

        # 트렌드 분석
        trend_direction = self._analyze_trend(historical)
        spike_duration = self._calculate_spike_duration(historical)

        # 통계
        historical_avg = np.mean(historical[:-1]) if len(historical) > 1 else historical[0]
        current_value = data.current_value
        change_percent = (
            ((current_value - historical_avg) / historical_avg * 100)
            if historical_avg > 0
            else 0
        )

        # Pattern-Aware Detection
        adjusted_confidence = raw_confidence
        pattern_explanations: List[str] = []

        if self.pattern_chain:
            adjustment = self.pattern_chain.get_total_adjustment(data)
            pattern_explanations = self.pattern_chain.get_explanations(data)

            if self.pattern_shadow_mode:
                logger.info(
                    f"[Shadow] Pattern adjustment for {data.name}: "
                    f"raw={raw_confidence:.3f}, adjustment={adjustment:.3f}, "
                    f"patterns={pattern_explanations}"
                )
            else:
                adjusted_confidence = max(0.0, raw_confidence + adjustment)
                if adjustment != 0:
                    logger.debug(
                        f"Pattern adjustment for {data.name}: "
                        f"raw={raw_confidence:.3f} -> adjusted={adjusted_confidence:.3f}, "
                        f"patterns={pattern_explanations}"
                    )

        final_is_anomaly = is_anomaly and adjusted_confidence >= self.confidence_threshold
        severity = self._calculate_severity(adjusted_confidence, change_percent)

        return AnomalyResult(
            is_anomaly=final_is_anomaly,
            confidence_score=round(adjusted_confidence, 3),
            severity=severity,
            change_percent=round(change_percent, 1),
            detection_method=detection_method,
            pattern_contexts=pattern_explanations,
            trend_direction=trend_direction,
            spike_duration=spike_duration,
            raw_confidence_score=round(raw_confidence, 3),
        )

    def _detect_ecod(self, values: List[float]) -> Optional[Dict[str, Any]]:
        """ECOD 기반 이상 탐지."""
        try:
            X = np.array(values).reshape(-1, 1)

            if PYOD_AVAILABLE:
                clf = ECOD(contamination=self.contamination)
                method_suffix = ""
            else:
                clf = LightweightECOD(contamination=self.contamination)
                method_suffix = "_lite"

            clf.fit(X)

            labels = clf.labels_
            scores = clf.decision_scores_

            is_anomaly = bool(labels[-1] == 1)
            raw_score = float(scores[-1])

            score_range = scores.max() - scores.min()
            if score_range > 0:
                normalized_score = (raw_score - scores.min()) / score_range
            else:
                normalized_score = 0.0

            confidence = min(1.0, normalized_score * (1 + self.sensitivity * 0.5))

            return {
                "is_anomaly": is_anomaly or confidence >= self.confidence_threshold,
                "confidence": confidence,
                "raw_score": raw_score,
                "method_suffix": method_suffix,
            }

        except Exception as e:
            logger.warning(f"ECOD detection failed: {e}")
            return None

    def _detect_ratio(self, values: List[float]) -> Dict[str, Any]:
        """Ratio 기반 이상 탐지."""
        if len(values) < 2:
            return {"is_anomaly": False, "confidence": 0.0, "ratio": 0.0}

        current = values[-1]
        historical = values[:-1]
        avg = np.mean(historical)

        if avg <= 0:
            return {"is_anomaly": False, "confidence": 0.0, "ratio": 0.0}

        ratio = current / avg

        is_anomaly = ratio > self.ratio_threshold or ratio < (1 / self.ratio_threshold)

        if ratio > 1:
            confidence = min(1.0, (ratio - 1) / self.ratio_threshold)
        else:
            confidence = min(1.0, (1 / ratio - 1) / self.ratio_threshold)

        return {
            "is_anomaly": is_anomaly,
            "confidence": confidence * self.sensitivity,
            "ratio": ratio,
        }

    def _detect_stddev(self, values: List[float]) -> Optional[Dict[str, Any]]:
        """Z-Score 기반 이상 탐지."""
        if len(values) < self.stddev_min_data_points:
            return None

        try:
            current = values[-1]
            historical = np.array(values[:-1])

            mean = np.mean(historical)
            std = np.std(historical, ddof=1)

            if std == 0:
                return None

            z_score = (current - mean) / std
            abs_z = abs(z_score)

            adjusted_threshold = self.z_score_threshold - self.sensitivity

            is_anomaly = abs_z > adjusted_threshold
            confidence = min(1.0, abs_z / 4.0) * self.sensitivity

            return {
                "is_anomaly": is_anomaly,
                "confidence": confidence,
                "z_score": z_score,
                "mean": mean,
                "std": std,
            }

        except Exception as e:
            logger.warning(f"Stddev detection failed: {e}")
            return None

    def _calculate_ensemble_score(
        self,
        ecod_result: Optional[Dict[str, Any]],
        ratio_result: Dict[str, Any],
        stddev_result: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """가중치 기반 앙상블 스코어 계산."""
        valid_results = []
        total_weight = 0.0

        if ecod_result:
            valid_results.append((ecod_result, self.ecod_weight, "ecod"))
            total_weight += self.ecod_weight

        if ratio_result:
            valid_results.append((ratio_result, self.ratio_weight, "ratio"))
            total_weight += self.ratio_weight

        if stddev_result:
            valid_results.append((stddev_result, self.stddev_weight, "stddev"))
            total_weight += self.stddev_weight

        if total_weight == 0 or not valid_results:
            return {
                "is_anomaly": False,
                "confidence": 0.0,
                "raw_score": 0.0,
                "method": "insufficient_data",
                "method_suffix": "",
            }

        normalized_weights = [(r, w / total_weight, m) for r, w, m in valid_results]

        weighted_confidence = sum(
            r["confidence"] * w for r, w, _ in normalized_weights
        )

        anomaly_vote_weight = sum(
            w for r, w, _ in normalized_weights if r.get("is_anomaly", False)
        )

        is_anomaly = anomaly_vote_weight > 0.5

        if ecod_result:
            method_suffix = ecod_result.get("method_suffix", "")
            if len([r for r, _, _ in normalized_weights if r.get("is_anomaly")]) >= 2:
                method = "ensemble"
            else:
                method = "ecod"
        elif stddev_result and stddev_result.get("is_anomaly"):
            method = "stddev"
            method_suffix = ""
        else:
            method = "ratio"
            method_suffix = ""

        raw_scores = []
        if ecod_result:
            raw_scores.append(ecod_result.get("raw_score", 0))
        if ratio_result:
            raw_scores.append(ratio_result.get("ratio", 0))
        if stddev_result:
            raw_scores.append(abs(stddev_result.get("z_score", 0)))

        raw_score = max(raw_scores) if raw_scores else 0.0

        return {
            "is_anomaly": is_anomaly,
            "confidence": weighted_confidence,
            "raw_score": raw_score,
            "method": method,
            "method_suffix": method_suffix,
        }

    def _analyze_trend(self, values: List[float]) -> str:
        """트렌드 방향 분석."""
        if len(values) < 3:
            return "stable"

        x = np.arange(len(values))
        slope = np.polyfit(x, values, 1)[0]

        avg = np.mean(values)
        if avg == 0:
            return "stable"

        slope_ratio = slope / avg

        if slope_ratio > 0.05:
            return "increasing"
        elif slope_ratio < -0.05:
            return "decreasing"
        else:
            return "stable"

    def _calculate_spike_duration(self, values: List[float]) -> int:
        """연속 상승일 계산."""
        if len(values) < 2:
            return 0

        avg = np.mean(values[:-1])
        threshold = avg * 1.2

        duration = 0
        for i in range(len(values) - 1, -1, -1):
            if values[i] > threshold:
                duration += 1
            else:
                break

        return duration

    def _calculate_severity(self, confidence: float, change_percent: float) -> AnomalySeverity:
        """심각도 레벨 계산."""
        abs_change = abs(change_percent)

        if confidence >= 0.9 or abs_change >= 200:
            return AnomalySeverity.CRITICAL
        elif confidence >= 0.7 or abs_change >= 100:
            return AnomalySeverity.HIGH
        elif confidence >= 0.5 or abs_change >= 50:
            return AnomalySeverity.MEDIUM
        else:
            return AnomalySeverity.LOW
