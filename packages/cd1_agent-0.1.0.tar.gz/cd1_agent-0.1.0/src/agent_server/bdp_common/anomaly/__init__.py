"""
BDP Common Anomaly Detection Module.

도메인 무관한 범용 시계열 이상 탐지 모듈.
ECOD + Ratio + Z-score 가중 앙상블 탐지 및 패턴 인식기 체인.

Usage:
    from src.agent_server.bdp_common.anomaly import EnsembleDetector, TimeSeriesData, AnomalyResult

    detector = EnsembleDetector(sensitivity=0.7)
    data = TimeSeriesData(
        name="MessagesInPerSec",
        resource_id="msk-cluster-1",
        current_value=2500.0,
        historical_values=[1000, 1100, 1050, 1200, 1150, 1100, 1050],
        timestamps=["2024-01-01", ...],
    )
    result = detector.analyze(data)
"""

from .models import AnomalyResult, AnomalySeverity, TimeSeriesData
from .detector import EnsembleDetector
from .patterns import PatternChain

__all__ = [
    "TimeSeriesData",
    "AnomalyResult",
    "AnomalySeverity",
    "EnsembleDetector",
    "PatternChain",
]
