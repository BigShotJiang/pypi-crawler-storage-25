"""
Lightweight ECOD Implementation.

scipy 의존성 없이 numpy만으로 ECOD 알고리즘 구현.
PyOD 설치 시 PyOD ECOD로 대체 가능.

Reference:
    Li et al., "ECOD: Unsupervised Outlier Detection Using
    Empirical Cumulative Distribution Functions" (2022)
"""

import logging
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# PyOD graceful degradation
try:
    from pyod.models.ecod import ECOD

    PYOD_AVAILABLE = True
except ImportError:
    PYOD_AVAILABLE = False
    logger.info("PyOD not available, using lightweight ECOD implementation")


def _numpy_skew(x: np.ndarray) -> float:
    """Calculate Fisher-Pearson skewness coefficient (scipy.stats.skew replacement).

    Args:
        x: 1D numpy array

    Returns:
        Skewness value (0 for symmetric, >0 right-skewed, <0 left-skewed)
    """
    n = len(x)
    if n < 3:
        return 0.0

    mean = np.mean(x)
    std = np.std(x, ddof=0)  # Population std for bias=True

    if std == 0:
        return 0.0

    m3 = np.mean((x - mean) ** 3)
    return m3 / (std**3)


class LightweightECOD:
    """Lightweight ECOD implementation without scipy dependency.

    ECOD 알고리즘:
    1. 각 차원의 경험적 CDF (ECDF) 계산
    2. Left-tail / Right-tail 확률 계산
    3. Skewness로 어느 tail을 강조할지 결정
    4. Tail 확률들을 결합하여 이상치 점수 산출

    Usage:
        clf = LightweightECOD(contamination=0.1)
        clf.fit(X)
        labels = clf.labels_  # 0: normal, 1: outlier
        scores = clf.decision_scores_
    """

    def __init__(self, contamination: float = 0.1):
        if not 0.0 < contamination <= 0.5:
            raise ValueError("contamination must be in (0, 0.5]")

        self.contamination = contamination
        self.labels_: Optional[np.ndarray] = None
        self.decision_scores_: Optional[np.ndarray] = None
        self.threshold_: Optional[float] = None

    def fit(self, X: np.ndarray) -> "LightweightECOD":
        """Fit the ECOD model.

        Args:
            X: Training data of shape (n_samples, n_features)

        Returns:
            self
        """
        X = np.asarray(X)
        if X.ndim == 1:
            X = X.reshape(-1, 1)

        n_samples, n_features = X.shape

        scores = np.zeros(n_samples)

        for dim in range(n_features):
            col = X[:, dim]

            # Calculate empirical CDF values
            left_ecdf = np.array([np.mean(col <= v) for v in col])
            right_ecdf = np.array([np.mean(col >= v) for v in col])

            skew = _numpy_skew(col)

            eps = 1e-10

            if skew >= 0:
                scores += -np.log(np.clip(right_ecdf, eps, 1.0))
            else:
                scores += -np.log(np.clip(left_ecdf, eps, 1.0))

        self.decision_scores_ = scores

        self.threshold_ = np.percentile(scores, 100 * (1 - self.contamination))

        self.labels_ = (scores >= self.threshold_).astype(int)

        return self

    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Return outlier scores for X."""
        if self.decision_scores_ is None:
            raise RuntimeError("Model not fitted. Call fit() first.")
        return self.decision_scores_
