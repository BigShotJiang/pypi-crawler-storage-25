"""
Anomaly Detection Models.

범용 시계열 이상 탐지 입출력 데이터 모델.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class AnomalySeverity(str, Enum):
    """이상 탐지 심각도 레벨."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class TimeSeriesData:
    """범용 시계열 입력 데이터.

    Args:
        name: 메트릭/서비스 이름
        resource_id: 리소스 식별자
        current_value: 현재 값
        historical_values: 과거 값 목록 (시간순, 현재 값 포함)
        timestamps: 과거 타임스탬프 목록 (historical_values와 동일 길이)
        metadata: 추가 메타데이터
    """

    name: str
    resource_id: str
    current_value: float
    historical_values: List[float]
    timestamps: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)


@dataclass
class AnomalyResult:
    """범용 이상 탐지 결과.

    Args:
        is_anomaly: 이상 여부
        confidence_score: 신뢰도 점수 (0.0 ~ 1.0, 패턴 조정 후)
        severity: 심각도
        change_percent: 변화율 (%)
        detection_method: 탐지 방법 (ensemble, ecod, ratio, stddev 등)
        pattern_contexts: 인식된 패턴 설명 목록
        trend_direction: 추세 방향 (increasing, decreasing, stable)
        spike_duration: 연속 상승일
        raw_confidence_score: 패턴 조정 전 원본 신뢰도
    """

    is_anomaly: bool
    confidence_score: float
    severity: AnomalySeverity
    change_percent: float
    detection_method: str = "ensemble"
    pattern_contexts: List[str] = field(default_factory=list)
    trend_direction: str = "stable"
    spike_duration: int = 0
    raw_confidence_score: Optional[float] = None
