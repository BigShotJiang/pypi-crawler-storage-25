"""APScheduler-based mail scheduler for periodic report emails.

RDS mail_config 테이블에서 설정을 읽어 리포트 메일을 주기적으로 발송.
Agent Server(bdp_dashboard) Pod 내에서 실행.

CID 인라인 이미지 방식: HTML → PDF → PNG → S3 → EventBridge(S3 참조).
USE_CID_EMAIL 환경변수로 기존 HTML 방식 fallback 가능 (기본: CID).
"""

import calendar
import logging
import os
from datetime import datetime

from src.common.timezone import KST

logger = logging.getLogger(__name__)

# schedule_type → APScheduler cron kwargs (KST 09:00 기준)
SCHEDULE_CRON = {
    "daily": {"hour": 9, "minute": 0},               # 매일 09:00
    "weekly": {"day_of_week": "mon", "hour": 9, "minute": 0},  # 매주 월요일 09:00
    "monthly": {"day": 1, "hour": 9, "minute": 0},   # 매월 1일 09:00
}

# DB 설정이 없을 때 기본으로 스케줄할 리포트 타입
DEFAULT_REPORT_TYPES = {"service_dashboard", "infra_dashboard"}
DEFAULT_RECIPIENTS_ENV = "REPORT_DEFAULT_RECIPIENTS"  # 쉼표 구분 이메일


def _calc_report_days() -> int:
    """이메일 리포트용 days 계산.

    - 당월 4일 이후: day-1 (1일~전일 누적)
    - 당월 1~3일: 전월 전체 일수 (전월 데이터 표시)
    """
    now = datetime.now(KST)
    if now.day > 3:
        return now.day - 1
    year, month = (now.year, now.month - 1) if now.month > 1 else (now.year - 1, 12)
    return calendar.monthrange(year, month)[1]


def _get_report_html(report_type: str, use_html_charts: bool = True) -> str | None:
    """리포트 HTML 본문 생성."""
    try:
        from src.agent_server.routers.bdp_dashboard import (
            _generate_infra_report_html,
            _generate_service_report_html,
        )

        days = _calc_report_days()

        if report_type == "service_dashboard":
            return _generate_service_report_html(
                days=days, use_html_charts=use_html_charts, email_mode=True,
            )
        elif report_type == "infra_dashboard":
            return _generate_infra_report_html(
                days=days, use_html_charts=use_html_charts, email_mode=True,
            )
        else:
            logger.warning("HTML report not yet implemented for: %s", report_type)
            return None
    except Exception:
        logger.exception("Failed to generate HTML for %s", report_type)
        return None


def _collect_report_data(report_type: str, days: int):
    """리포트 데이터 수집 (CSV 생성용)."""
    try:
        from src.agent_server.routers.bdp_dashboard import (
            _collect_infra_report_data,
            _collect_service_report_data,
        )

        if report_type == "service_dashboard":
            return _collect_service_report_data(days=days)
        elif report_type == "infra_dashboard":
            return _collect_infra_report_data(days=days)
        return None
    except Exception:
        logger.exception("Failed to collect report data for %s", report_type)
        return None


def _use_cid_email() -> bool:
    """CID 인라인 이미지 방식 사용 여부."""
    return os.getenv("USE_CID_EMAIL", "true").lower() != "false"


class MailScheduler:
    """RDS mail_config 기반 리포트 메일 주기 발송."""

    def __init__(self, db_factory):
        """
        Args:
            db_factory: callable that returns a PortalDB instance for reading mail_config.
        """
        self._db_factory = db_factory
        self._scheduler = None
        self._active_jobs: set[str] = set()

    def start(self):
        """스케줄러 시작. 5분마다 config를 reload."""
        from apscheduler.schedulers.background import BackgroundScheduler
        from apscheduler.triggers.interval import IntervalTrigger

        self._scheduler = BackgroundScheduler(timezone=KST)
        self._scheduler.add_job(
            self._reload_configs,
            IntervalTrigger(minutes=5),
            id="mail_config_reload",
            replace_existing=True,
        )
        self._scheduler.start()
        logger.info("MailScheduler started (config reload every 5 min)")

        # 초기 로드
        self._reload_configs()

    def stop(self):
        """스케줄러 정지."""
        if self._scheduler:
            self._scheduler.shutdown(wait=False)
            logger.info("MailScheduler stopped")

    def _reload_configs(self):
        """DB에서 enabled된 config 조회 → schedule에 따라 job 추가/제거."""
        try:
            db = self._db_factory()
            configs = db.get_all_mail_configs()
        except Exception:
            logger.exception("Failed to load mail configs from DB")
            return

        enabled_types = set()
        for cfg in configs:
            if not cfg.get("enabled"):
                continue
            rt = cfg["report_type"]
            schedule_type = cfg.get("schedule_type", "daily")
            enabled_types.add(rt)

            job_id = f"mail_report_{rt}"
            cron_kwargs = SCHEDULE_CRON.get(schedule_type, SCHEDULE_CRON["daily"])

            if job_id not in self._active_jobs:
                self._add_report_job(job_id, rt, cfg, cron_kwargs)
            else:
                # 기존 job의 schedule이 변경되었을 수 있으므로 reschedule
                self._reschedule_job(job_id, cron_kwargs)

        # DB에 설정이 없는 리포트 타입은 환경변수 기본값으로 스케줄
        for rt in DEFAULT_REPORT_TYPES:
            if rt not in enabled_types:
                default_to = os.getenv(DEFAULT_RECIPIENTS_ENV, "").split(",")
                default_to = [e.strip() for e in default_to if e.strip()]
                if default_to:
                    job_id = f"mail_report_{rt}"
                    if job_id not in self._active_jobs:
                        self._add_report_job(
                            job_id, rt, {"recipients_to": default_to}, SCHEDULE_CRON["daily"]
                        )

        # disabled된 job 제거 (DB에 있지만 disabled, 기본 스케줄에도 해당 없음)
        for job_id in list(self._active_jobs):
            rt = job_id.replace("mail_report_", "")
            if rt not in enabled_types and rt not in DEFAULT_REPORT_TYPES:
                self._remove_job(job_id)

    def _add_report_job(self, job_id: str, report_type: str, config: dict, cron_kwargs: dict):
        """리포트 발송 job 추가."""
        from apscheduler.triggers.cron import CronTrigger

        self._scheduler.add_job(
            self._execute_report,
            CronTrigger(timezone=KST, **cron_kwargs),
            id=job_id,
            args=[report_type],
            replace_existing=True,
        )
        self._active_jobs.add(job_id)
        logger.info("Added mail job: %s (schedule: %s)", job_id, cron_kwargs)

    def _reschedule_job(self, job_id: str, cron_kwargs: dict):
        """기존 job의 schedule 갱신."""
        from apscheduler.triggers.cron import CronTrigger

        try:
            self._scheduler.reschedule_job(
                job_id,
                trigger=CronTrigger(timezone=KST, **cron_kwargs),
            )
        except Exception:
            logger.debug("Job %s not found for reschedule, skipping", job_id)

    def _remove_job(self, job_id: str):
        """Job 제거."""
        try:
            self._scheduler.remove_job(job_id)
        except Exception:
            pass
        self._active_jobs.discard(job_id)
        logger.info("Removed mail job: %s", job_id)

    def _execute_report(self, report_type: str):
        """리포트 생성 + 메일 발송.

        CID 모드: SVG HTML → PDF → PNG → S3 → CID 메일
        Fallback 모드: HTML table 차트 → 본문 인라인
        """
        from src.agent_server.bdp_common.mail.sender import send_report_email
        from src.portal.services.mail_config_service import REPORT_TYPE_LABELS

        # DB에서 config 조회 (없으면 환경변수 기본값 사용)
        to: list[str] = []
        cc: list[str] = []
        try:
            db = self._db_factory()
            config = db.get_mail_config(report_type)
        except Exception:
            logger.exception("Failed to load mail config for %s", report_type)
            config = None

        if config and config.get("enabled"):
            to = config.get("recipients_to", [])
            cc = config.get("recipients_cc", [])
        else:
            # DB 설정 없으면 환경변수 기본 수신자 사용
            default_to = os.getenv(DEFAULT_RECIPIENTS_ENV, "").split(",")
            to = [e.strip() for e in default_to if e.strip()]

        if not to:
            logger.warning("No recipients for %s, skipping", report_type)
            return

        label = REPORT_TYPE_LABELS.get(report_type, report_type)
        today = datetime.now(KST).strftime("%Y-%m-%d")
        date_str = datetime.now(KST).strftime("%Y%m%d")

        if _use_cid_email():
            self._execute_cid_report(report_type, label, today, date_str, to, cc)
        else:
            self._execute_html_report(report_type, label, today, to, cc)

    def _execute_cid_report(
        self, report_type: str, label: str, today: str, date_str: str,
        to: list[str], cc: list[str],
    ):
        """CID 인라인 이미지 파이프라인."""
        from src.agent_server.bdp_common.mail.sender import send_report_email
        from src.agent_server.bdp_common.reports.s3_export import (
            generate_and_upload_report_png,
            get_csv_s3_key,
        )

        # 1. SVG HTML 생성 (PNG 변환용)
        html = _get_report_html(report_type, use_html_charts=False)
        if not html:
            logger.warning("No HTML generated for %s (CID), skipping", report_type)
            return

        # 2. PNG → S3
        try:
            bucket, files_dict, pdf_key = generate_and_upload_report_png(report_type, html, date_str)
        except Exception:
            logger.exception("Failed PNG pipeline for %s, falling back to HTML", report_type)
            self._execute_html_report(report_type, label, today, to, cc)
            return

        # 3. CSV → S3 (실패해도 메일은 발송)
        try:
            from src.agent_server.bdp_common.reports.csv_export import report_data_to_csv
            from src.common.services.aws_session import get_boto3_client

            days = _calc_report_days()
            data = _collect_report_data(report_type, days)
            if data:
                csv_bytes = report_data_to_csv(data, report_type)
                csv_key = get_csv_s3_key(report_type)
                s3_client = get_boto3_client("s3")
                s3_client.put_object(
                    Bucket=bucket, Key=csv_key, Body=csv_bytes, ContentType="text/csv",
                )
        except Exception:
            logger.warning("CSV export failed for %s, continuing", report_type, exc_info=True)

        # 4. CID 이미지 HTML 본문 + EventBridge 발송
        img_rows = "".join(
            f'<tr><td><img src="cid:{key}" width="100%" /></td></tr>'
            for key in sorted(files_dict.keys())
        )
        html_body = (
            '<html><body>'
            '<table cellpadding="0" cellspacing="0" border="0" width="100%">'
            f'{img_rows}'
            '</table>'
            '</body></html>'
        )
        env_label = "개발계" if os.getenv("ENVIRONMENT", "dev").lower() in ("dev", "test") else "운영계"
        subject = f"[{env_label}] [{label}] Daily Report - {today}"
        send_report_email(
            report_type=report_type,
            subject=subject,
            html_body=html_body,
            to=to,
            cc=cc,
            inline={"bucketName": bucket, "files": files_dict},
            attachment={"bucketName": bucket, "files": {"report": pdf_key}},
        )

    def _execute_html_report(
        self, report_type: str, label: str, today: str,
        to: list[str], cc: list[str],
    ):
        """기존 HTML 본문 인라인 방식 (fallback)."""
        from src.agent_server.bdp_common.mail.sender import send_report_email

        html_body = _get_report_html(report_type, use_html_charts=True)
        if not html_body:
            logger.warning("No HTML generated for %s, skipping", report_type)
            return

        html_size = len(html_body.encode("utf-8"))
        logger.info(
            "Report HTML size for %s: %d bytes (%.1f KB)",
            report_type, html_size, html_size / 1024,
        )

        env_label = "개발계" if os.getenv("ENVIRONMENT", "dev").lower() in ("dev", "test") else "운영계"
        subject = f"[{env_label}] [{label}] Daily Report - {today}"
        send_report_email(
            report_type=report_type,
            subject=subject,
            html_body=html_body,
            to=to,
            cc=cc,
        )
