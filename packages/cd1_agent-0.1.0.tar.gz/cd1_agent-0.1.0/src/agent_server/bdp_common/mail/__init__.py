"""Mail sending utilities for BDP reports."""

from .sender import send_report_email

__all__ = ["send_report_email"]
