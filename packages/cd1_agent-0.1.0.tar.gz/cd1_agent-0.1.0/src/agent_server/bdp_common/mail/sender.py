"""Common report email sender using EventBridge."""

import base64
import json
import logging
import os
from src.agent_server.bdp_common.eventbridge.publisher import (
    EmailAttachment,
    EmailChannel,
    EventPublisher,
    ProductionAlertDetail,
    get_environment_account_name,
)

logger = logging.getLogger(__name__)

# report_type → from_email 매핑
FROM_EMAIL_MAP = {
    "service_dashboard": "bdp-dsbd-svc@hcs.com",
    "infra_dashboard": "bdp-dsbd-infr@hcs.com",
    "bdp_metrics": "bdp-metrics@hcs.com",
    "bdp_cost": "bdp-cost@hcs.com",
    "bdp_drift": "bdp-drift@hcs.com",
    "bdp_airflow": "bdp-airflow@hcs.com",
}

# EventBridge Detail 최대 크기 (256KB)
_EVENTBRIDGE_MAX_BYTES = 256 * 1024



def send_report_email(
    report_type: str,
    subject: str,
    html_body: str,
    to: list[str],
    cc: list[str] | None = None,
    from_email: str | None = None,
    attachments: list[tuple[str, bytes, str]] | None = None,
    inline: dict | None = None,
    attachment: dict | None = None,  # S3 참조 첨부파일
) -> bool:
    """EventBridge를 통해 리포트 메일 발송.

    Args:
        report_type: 리포트 유형 (service_dashboard, infra_dashboard, ...)
        subject: 메일 제목
        html_body: HTML 본문
        to: 수신자 목록
        cc: 참조 수신자 목록
        from_email: 발신 주소 (미지정 시 report_type 기반 자동 생성)
        attachments: 첨부파일 목록 — (filename, data, content_type) 튜플 리스트
        inline: CID 인라인 이미지 S3 참조 — {"bucketName": ..., "files": {"image1": key}}

    Returns:
        발송 성공 여부
    """
    if not to:
        logger.warning("No recipients specified for %s report email", report_type)
        return False

    if from_email is None:
        from_email = FROM_EMAIL_MAP.get(
            report_type,
            f"bdp-{report_type.replace('_', '-')}@hcs.com",
        )

    # 첨부파일 → EmailAttachment 변환 + 용량 로그
    email_attachments: list[EmailAttachment] = []
    if attachments:
        for filename, data, content_type in attachments:
            b64 = base64.b64encode(data).decode()
            logger.info(
                "Mail attachment: %s (raw=%d bytes, base64=%d bytes)",
                filename,
                len(data),
                len(b64),
            )
            email_attachments.append(
                EmailAttachment(
                    filename=filename,
                    content_base64=b64,
                    content_type=content_type,
                )
            )

    # 이벤트 크기 로그 (256KB 초과해도 발송 시도)
    estimated_size = len(html_body) + sum(len(a.content_base64) for a in email_attachments)
    if estimated_size > _EVENTBRIDGE_MAX_BYTES:
        logger.warning(
            "Event size ~%d bytes exceeds 256KB limit, attempting anyway",
            estimated_size,
        )

    event_provider = os.getenv("EVENT_PROVIDER", "mock")
    publisher = EventPublisher(
        source="cd1-agent.bdp-report",
        event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
        use_mock=(event_provider == "mock"),
    )

    detail = ProductionAlertDetail(
        subject=subject,
        account_id=get_environment_account_name(),
        component="BDPC",
        email=EmailChannel(
            to=to,
            cc=cc or [],
            from_email=from_email,
            from_name=f"BDP Report ({report_type})",
            type="html",
            message=html_body,
            attachments=email_attachments,
            inline=inline,
            attachment=attachment,
        ),
    )

    if event_provider == "mock":
        detail_json = json.dumps(detail.to_dict())
        logger.info(
            "Event detail size: %d bytes (mock mode)", len(detail_json)
        )

    success = publisher.publish_production_event(detail, "Report Email")
    if success:
        logger.info("Report email sent: type=%s, to=%s", report_type, to)
    else:
        logger.error("Failed to send report email: type=%s", report_type)
    return success
