"""Tests for bdp_common.stores.base module."""

import sqlite3
from unittest.mock import patch, MagicMock
import json

import pytest

from src.agent_server.bdp_common.stores.base import (
    KST,
    get_kst_now,
    BaseSQLiteProvider,
    BaseMySqlProvider,
)


class TestKST:
    """KST 타임존 및 get_kst_now 테스트."""

    def test_kst_offset(self):
        """KST는 UTC+9."""
        from datetime import timedelta

        assert KST.utcoffset(None) == timedelta(hours=9)

    def test_get_kst_now_has_tzinfo(self):
        """get_kst_now()는 KST tzinfo를 포함."""
        now = get_kst_now()
        assert now.tzinfo is not None
        assert now.tzinfo == KST


class TestBaseSQLiteProvider:
    """BaseSQLiteProvider 테스트."""

    def test_init_defaults_to_memory(self):
        """기본값은 :memory:."""
        provider = BaseSQLiteProvider()
        assert provider.db_path == ":memory:"
        assert provider._conn is None

    def test_init_custom_path(self):
        """커스텀 경로 설정."""
        provider = BaseSQLiteProvider("/tmp/test.db")
        assert provider.db_path == "/tmp/test.db"

    def test_conn_creates_connection(self):
        """conn 프로퍼티가 연결 생성."""
        provider = BaseSQLiteProvider()
        conn = provider.conn
        assert isinstance(conn, sqlite3.Connection)

    def test_conn_sets_row_factory(self):
        """conn이 Row factory를 설정."""
        provider = BaseSQLiteProvider()
        conn = provider.conn
        assert conn.row_factory == sqlite3.Row

    def test_conn_reuses_connection(self):
        """conn이 기존 연결을 재사용."""
        provider = BaseSQLiteProvider()
        conn1 = provider.conn
        conn2 = provider.conn
        assert conn1 is conn2

    def test_sqlite_provider_usable_for_queries(self):
        """SQLite provider로 실제 쿼리 가능."""
        provider = BaseSQLiteProvider()
        cursor = provider.conn.cursor()
        cursor.execute("CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT)")
        cursor.execute("INSERT INTO test (name) VALUES ('hello')")
        provider.conn.commit()

        cursor.execute("SELECT name FROM test WHERE id = 1")
        row = cursor.fetchone()
        assert row["name"] == "hello"


class TestBaseMySqlProvider:
    """BaseMySqlProvider 테스트."""

    def test_init_stores_params(self):
        """초기화 시 파라미터 저장."""
        provider = BaseMySqlProvider(
            secret_id="my-secret",
            db="my_database",
            region="us-east-1",
        )
        assert provider.secret_id == "my-secret"
        assert provider.db == "my_database"
        assert provider.region == "us-east-1"
        assert provider._conn is None
        assert provider._credentials is None

    def test_init_default_region(self):
        """기본 리전은 ap-northeast-2."""
        provider = BaseMySqlProvider(secret_id="s", db="d")
        assert provider.region == "ap-northeast-2"

    @patch("boto3.client")
    def test_get_credentials_caches(self, mock_boto3_client):
        """_get_credentials가 결과를 캐싱."""
        mock_sm = MagicMock()
        mock_sm.get_secret_value.return_value = {
            "SecretString": json.dumps({
                "host": "localhost",
                "port": 3306,
                "username": "user",
                "password": "pass",
            })
        }
        mock_boto3_client.return_value = mock_sm

        provider = BaseMySqlProvider(secret_id="test-secret", db="testdb")
        creds1 = provider._get_credentials()
        creds2 = provider._get_credentials()

        assert creds1 == creds2
        assert creds1["host"] == "localhost"
        # boto3 client should be called only once
        mock_sm.get_secret_value.assert_called_once()

    @patch("boto3.client")
    def test_get_credentials_uses_correct_region(self, mock_boto3_client):
        """_get_credentials가 올바른 리전으로 boto3 클라이언트 생성."""
        mock_sm = MagicMock()
        mock_sm.get_secret_value.return_value = {
            "SecretString": json.dumps({"host": "h", "username": "u", "password": "p"})
        }
        mock_boto3_client.return_value = mock_sm

        provider = BaseMySqlProvider(
            secret_id="test-secret", db="testdb", region="eu-west-1"
        )
        provider._get_credentials()

        mock_boto3_client.assert_called_once_with(
            "secretsmanager", region_name="eu-west-1"
        )

    @patch("boto3.client")
    def test_conn_uses_database_param(self, mock_boto3_client):
        """conn이 deprecated 'db=' 대신 'database=' 파라미터 사용."""
        import sys

        mock_sm = MagicMock()
        mock_sm.get_secret_value.return_value = {
            "SecretString": json.dumps({
                "host": "myhost",
                "port": 3306,
                "username": "user",
                "password": "pass",
            })
        }
        mock_boto3_client.return_value = mock_sm

        # Mock pymysql module (may not be installed locally)
        mock_pymysql = MagicMock()
        mock_conn = MagicMock()
        mock_conn.open = True
        mock_pymysql.connect.return_value = mock_conn
        sys.modules["pymysql"] = mock_pymysql

        try:
            provider = BaseMySqlProvider(secret_id="s", db="mydb")
            conn = provider.conn

            # Verify pymysql.connect was called with database= (not db=)
            call_kwargs = mock_pymysql.connect.call_args[1]
            assert "database" in call_kwargs
            assert call_kwargs["database"] == "mydb"
            assert "db" not in call_kwargs
            assert conn is mock_conn
        finally:
            del sys.modules["pymysql"]
