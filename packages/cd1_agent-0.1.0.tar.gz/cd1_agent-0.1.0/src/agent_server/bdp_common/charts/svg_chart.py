"""
Email-Compatible Chart Generator.

시계열 메트릭: SVG 기반 스무스 라인 차트
  - Catmull-Rom 스플라인 → 부드러운 곡선
  - SVG inline 렌더링 (anti-aliased)
  - 그라디언트 영역 채움 + 임계값 라인
  - Y축/X축 라벨 + 범례

스냅샷 메트릭: HTML 수평 바 차트
"""

import itertools
import logging
from dataclasses import dataclass
from datetime import datetime

from src.common.timezone import KST

logger = logging.getLogger(__name__)

_chart_id_seq = itertools.count()


@dataclass
class ChartDataPoint:
    """차트 데이터 포인트."""

    timestamp: datetime
    value: float


@dataclass
class ThresholdLine:
    """임계값 라인."""

    value: float
    label: str
    color: str = "#dc3545"


# ── 차트 상수 ──
PLOT_W = 480  # 플롯 영역 폭
PLOT_H = 110  # 플롯 영역 높이
MARGIN_L = 38  # 왼쪽 여백 (Y축 라벨)
MARGIN_R = 55  # 오른쪽 여백 (threshold 라벨)
MARGIN_T = 6  # 위 여백
MARGIN_B = 22  # 아래 여백 (X축 라벨)
MAX_DISPLAY_PTS = 40  # 샘플링 최대 포인트
MAX_X_LABELS = 6

# ── 색상 ──
_LINE_COLOR = "#4285f4"
_BG = "background-color:#ffffff;"


def _fmt_val(v: float) -> str:
    """Y축 라벨 포맷: 10 미만은 소수 1자리, 이상은 정수."""
    return f"{v:.1f}" if v < 10 else f"{v:.0f}"


def _escape(text: str) -> str:
    """HTML 이스케이프."""
    return (
        text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    )


def _catmull_rom_path(pts: list[tuple[float, float]]) -> str:
    """Catmull-Rom 스플라인 → SVG cubic bezier 경로."""
    if len(pts) < 2:
        return ""
    if len(pts) == 2:
        return f"M{pts[0][0]:.1f},{pts[0][1]:.1f}L{pts[1][0]:.1f},{pts[1][1]:.1f}"

    d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    for i in range(len(pts) - 1):
        p0 = pts[max(i - 1, 0)]
        p1 = pts[i]
        p2 = pts[min(i + 1, len(pts) - 1)]
        p3 = pts[min(i + 2, len(pts) - 1)]

        cp1x = p1[0] + (p2[0] - p0[0]) / 6
        cp1y = p1[1] + (p2[1] - p0[1]) / 6
        cp2x = p2[0] - (p3[0] - p1[0]) / 6
        cp2y = p2[1] - (p3[1] - p1[1]) / 6

        d += f"C{cp1x:.1f},{cp1y:.1f} {cp2x:.1f},{cp2y:.1f} {p2[0]:.1f},{p2[1]:.1f}"
    return d


class SVGChartGenerator:
    """이메일 호환 차트 생성기 (SVG 기반)."""

    def generate_line_chart(
        self,
        data_points: list[ChartDataPoint],
        title: str | None = None,
        unit: str = "",
        thresholds: list[ThresholdLine] | None = None,
        show_average: bool = True,
    ) -> str:
        """시계열 라인 차트 — SVG Catmull-Rom 스플라인.

        Args:
            data_points: 시계열 데이터 포인트
            title: 차트 제목
            unit: 값 단위
            thresholds: 임계값 라인 목록
            show_average: 평균선 표시 여부

        Returns:
            HTML 문자열
        """
        if not data_points or len(data_points) < 2:
            return ""

        cid = f"sc{next(_chart_id_seq)}"
        thresholds = thresholds or []
        values = [dp.value for dp in data_points]
        actual_max = max(values)

        # Y축 범위 (상단 15 % 여유)
        y_max = actual_max * 1.15
        for th in thresholds:
            y_max = max(y_max, th.value * 1.15)
        if y_max == 0:
            y_max = 1

        avg_val = sum(values) / len(values)

        # ── 샘플링 ──
        display_points = data_points
        if len(data_points) > MAX_DISPLAY_PTS + 2:
            step = len(data_points) / MAX_DISPLAY_PTS
            indices = [int(i * step) for i in range(MAX_DISPLAY_PTS)]
            if indices[-1] != len(data_points) - 1:
                indices.append(len(data_points) - 1)
            display_points = [data_points[i] for i in indices]

        dv = [dp.value for dp in display_points]
        n = len(dv)

        # SVG 전체 크기
        svg_w = MARGIN_L + PLOT_W + MARGIN_R
        svg_h = MARGIN_T + PLOT_H + MARGIN_B

        # 좌표 변환
        def xy(i: int, v: float) -> tuple[float, float]:
            x = MARGIN_L + (i / max(n - 1, 1)) * PLOT_W
            y = MARGIN_T + PLOT_H - (v / y_max) * PLOT_H
            return (x, y)

        pts = [xy(i, v) for i, v in enumerate(dv)]
        bottom_y = MARGIN_T + PLOT_H

        # 스플라인 경로
        line_d = _catmull_rom_path(pts)
        area_d = line_d + f"L{pts[-1][0]:.1f},{bottom_y}" + f"L{pts[0][0]:.1f},{bottom_y}Z"

        # ── SVG 조립 ──
        s: list[str] = []
        s.append(
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'viewBox="0 0 {svg_w} {svg_h}" '
            f'style="width:100%;max-width:{svg_w}px;height:auto;'
            f"font-family:'Segoe UI',Arial,Helvetica,sans-serif\">"
        )

        # 그라디언트 정의
        s.append(
            f"<defs>"
            f'<linearGradient id="ag_{cid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0%" stop-color="{_LINE_COLOR}" stop-opacity="0.22"/>'
            f'<stop offset="100%" stop-color="{_LINE_COLOR}" stop-opacity="0.02"/>'
            f"</linearGradient>"
            f"</defs>"
        )

        # 배경
        s.append(f'<rect x="0" y="0" width="{svg_w}" height="{svg_h}" fill="#fff"/>')

        # 수평 그리드 (4 등분)
        for gi in range(5):
            gy = MARGIN_T + (PLOT_H / 4) * gi
            s.append(
                f'<line x1="{MARGIN_L}" y1="{gy:.1f}" '
                f'x2="{MARGIN_L + PLOT_W}" y2="{gy:.1f}" '
                f'stroke="#f0f0f0" stroke-width="0.5"/>'
            )

        # 영역 채움
        s.append(f'<path d="{area_d}" fill="url(#ag_{cid})"/>')

        # 임계값 라인 (점선 + 라벨)
        sorted_th = sorted(thresholds, key=lambda t: t.value, reverse=True)
        for th in sorted_th:
            th_y = MARGIN_T + PLOT_H - (th.value / y_max) * PLOT_H
            s.append(
                f'<line x1="{MARGIN_L}" y1="{th_y:.1f}" '
                f'x2="{MARGIN_L + PLOT_W}" y2="{th_y:.1f}" '
                f'stroke="{th.color}" stroke-width="1" '
                f'stroke-dasharray="5,3" opacity="0.7"/>'
            )
            s.append(
                f'<text x="{MARGIN_L + PLOT_W + 4}" y="{th_y + 3:.1f}" '
                f'font-size="8" fill="{th.color}">'
                f"{_escape(th.label)}</text>"
            )

        # 평균선
        if show_average:
            avg_y = MARGIN_T + PLOT_H - (avg_val / y_max) * PLOT_H
            s.append(
                f'<line x1="{MARGIN_L}" y1="{avg_y:.1f}" '
                f'x2="{MARGIN_L + PLOT_W}" y2="{avg_y:.1f}" '
                f'stroke="#bbb" stroke-width="0.8" '
                f'stroke-dasharray="3,3" opacity="0.5"/>'
            )

        # 메인 라인 (부드러운 곡선)
        s.append(
            f'<path d="{line_d}" fill="none" stroke="{_LINE_COLOR}" '
            f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
        )

        # 데이터 포인트 (적을 때만)
        if n <= 25:
            for px, py in pts:
                s.append(
                    f'<circle cx="{px:.1f}" cy="{py:.1f}" r="2" '
                    f'fill="{_LINE_COLOR}" stroke="#fff" stroke-width="1"/>'
                )

        # Y축 라벨
        s.append(
            f'<text x="{MARGIN_L - 4}" y="{MARGIN_T + 5}" '
            f'text-anchor="end" font-size="9" fill="#aaa">'
            f"{_fmt_val(actual_max)}</text>"
        )
        s.append(
            f'<text x="{MARGIN_L - 4}" y="{MARGIN_T + PLOT_H / 2 + 3}" '
            f'text-anchor="end" font-size="9" fill="#aaa">'
            f"{_fmt_val(actual_max / 2)}</text>"
        )
        s.append(
            f'<text x="{MARGIN_L - 4}" y="{bottom_y + 1}" '
            f'text-anchor="end" font-size="9" fill="#aaa">0</text>'
        )

        # X축 시간 라벨 (KST)
        t_start = display_points[0].timestamp
        t_end = display_points[-1].timestamp

        def _kst(t: datetime) -> str:
            if t.tzinfo is None:
                t = t.replace(tzinfo=KST)
            return t.astimezone(KST).strftime("%H:%M")

        label_y = bottom_y + 15
        n_xl = min(MAX_X_LABELS, n)
        for li in range(n_xl):
            if n_xl <= 1:
                frac = 0.0
                anchor = "middle"
            else:
                frac = li / (n_xl - 1)
                anchor = "start" if li == 0 else ("end" if li == n_xl - 1 else "middle")
            lx = MARGIN_L + frac * PLOT_W
            idx = min(int(frac * (len(display_points) - 1)), len(display_points) - 1)
            s.append(
                f'<text x="{lx:.1f}" y="{label_y}" '
                f'text-anchor="{anchor}" font-size="9" fill="#aaa">'
                f"{_kst(display_points[idx].timestamp)}</text>"
            )

        s.append("</svg>")

        # ── 외부 테이블 래퍼 (이메일 호환) ──
        parts: list[str] = []
        parts.append(
            '<table cellpadding="0" cellspacing="0" '
            f'style="border-collapse:collapse;width:100%;margin:6px 0;'
            f'border:1px solid #e0e0e0;{_BG}">'
        )

        if title:
            unit_str = f" ({_escape(unit)})" if unit else ""
            parts.append(
                f'<tr><td style="padding:8px 12px;font-size:12px;font-weight:600;'
                f'color:#333;border-bottom:1px solid #eee;background-color:#fafafa">'
                f"{_escape(title)}{unit_str}</td></tr>"
            )

        parts.append(f'<tr><td style="padding:6px 10px;{_BG}">')
        parts.append("\n".join(s))
        parts.append("</td></tr>")

        # 범례
        legend: list[str] = []
        if show_average:
            legend.append(
                f'<span style="color:#aaa">'
                f'<span style="border-bottom:1px dashed #bbb;padding-bottom:1px">'
                f"avg</span> {avg_val:.1f}{unit}</span>"
            )
        for th in thresholds:
            legend.append(
                f'<span style="color:{th.color}">'
                f'<span style="border-bottom:1px dashed {th.color};padding-bottom:1px">'
                f"{_escape(th.label)}</span> {th.value:.1f}{unit}</span>"
            )

        if legend:
            parts.append(
                '<tr><td style="padding:4px 12px 6px;font-size:10px;'
                'border-top:1px solid #eee;background-color:#fafafa;color:#999">'
                + " &nbsp;&nbsp; ".join(legend)
                + "</td></tr>"
            )

        parts.append("</table>")
        return "\n".join(parts)

    def generate_bar_inline(
        self,
        label: str,
        value: float,
        max_value: float = 100,
        used: int | None = None,
        total: int | None = None,
        severity_color: str = "#ffc107",
    ) -> str:
        """인라인 수평 바 차트 (Subnet-IP 등 스냅샷 메트릭용)."""
        pct = min(value / max_value * 100, 100)
        detail = ""
        if used is not None and total is not None:
            detail = f" ({used}/{total})"

        return (
            f'<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;'
            f'width:100%;margin:3px 0;{_BG}">'
            f"<tr>"
            f'<td style="width:130px;font-size:11px;color:#333;padding-right:8px;'
            f'white-space:nowrap;overflow:hidden;{_BG}">{_escape(label)}</td>'
            f'<td style="padding:0;{_BG}">'
            f'<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;'
            f'width:100%;background-color:#e0e0e0;border-radius:3px;">'
            f'<tr><td style="width:{pct:.1f}%;background-color:{severity_color};'
            f'height:14px;border-radius:3px;font-size:0;line-height:0">&nbsp;</td>'
            f'<td style="height:14px"></td></tr></table>'
            f"</td>"
            f'<td style="width:110px;font-size:10px;color:#555;text-align:right;'
            f'padding-left:8px;white-space:nowrap;{_BG}">{value:.1f}%{detail}</td>'
            f"</tr></table>"
        )
