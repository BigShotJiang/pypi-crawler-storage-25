"""
Lightweight PNG Line Chart Renderer (stdlib only).

Python struct + zlib + base64 만으로 PNG 이미지를 직접 생성.
외부 라이브러리 의존성 없음. Lambda 환경 최적화.

Indexed-color PNG: 차트당 ~4-8KB (base64 기준).
생성 시간: 차트당 ~10-30ms.
"""

import base64
import struct
import zlib
from typing import List, Optional, Tuple

# ── Type Alias ──
RGB = Tuple[int, int, int]

# ── 색상 상수 ──
WHITE: RGB = (255, 255, 255)
_GRID: RGB = (232, 232, 232)
_LINE_BLUE: RGB = (66, 133, 244)
_AVG_GRAY: RGB = (158, 158, 158)

# ── 차트 기본 크기 ──
DEFAULT_WIDTH = 520
DEFAULT_HEIGHT = 120
_PAD_L = 6
_PAD_R = 6
_PAD_T = 10
_PAD_B = 6


def hex_to_rgb(hex_color: str) -> RGB:
    """Hex 색상 문자열 → RGB 튜플."""
    h = hex_color.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def lighten(rgb: RGB, factor: float = 0.75) -> RGB:
    """RGB를 흰색 방향으로 밝게 만들기."""
    return (
        int(rgb[0] + (255 - rgb[0]) * factor),
        int(rgb[1] + (255 - rgb[1]) * factor),
        int(rgb[2] + (255 - rgb[2]) * factor),
    )


# ── PNG 청크 생성 유틸 ──

def _mk_chunk(ctype: bytes, data: bytes) -> bytes:
    body = ctype + data
    return (
        struct.pack('>I', len(data))
        + body
        + struct.pack('>I', zlib.crc32(body) & 0xFFFFFFFF)
    )


# ── 픽셀 버퍼 ──

class PixelBuffer:
    """RGB 픽셀 버퍼 + Indexed-color PNG 인코딩.

    내부적으로 flat bytearray(r,g,b 반복)로 저장.
    to_png()에서 Indexed-color(팔레트) PNG로 변환 → 작은 파일 크기.
    """

    __slots__ = ('w', 'h', 'data')

    def __init__(self, width: int, height: int, bg: RGB = WHITE):
        self.w = width
        self.h = height
        self.data = bytearray(bg) * (width * height)

    # ── 기본 그리기 ──

    def set_pixel(self, x: int, y: int, color: RGB) -> None:
        if 0 <= x < self.w and 0 <= y < self.h:
            off = (y * self.w + x) * 3
            self.data[off] = color[0]
            self.data[off + 1] = color[1]
            self.data[off + 2] = color[2]

    def hline(self, x0: int, x1: int, y: int, color: RGB) -> None:
        """수평 실선."""
        if not (0 <= y < self.h):
            return
        xa, xb = max(0, min(x0, x1)), min(self.w - 1, max(x0, x1))
        pixel = bytes(color)
        base = y * self.w * 3
        for x in range(xa, xb + 1):
            off = base + x * 3
            self.data[off:off + 3] = pixel

    def hline_dashed(self, x0: int, x1: int, y: int, color: RGB,
                     dash: int = 6, gap: int = 4) -> None:
        """수평 점선."""
        if not (0 <= y < self.h):
            return
        xa, xb = max(0, min(x0, x1)), min(self.w - 1, max(x0, x1))
        pixel = bytes(color)
        base = y * self.w * 3
        period = dash + gap
        for x in range(xa, xb + 1):
            if (x - xa) % period < dash:
                off = base + x * 3
                self.data[off:off + 3] = pixel

    def line(self, x0: int, y0: int, x1: int, y1: int, color: RGB) -> None:
        """Bresenham 직선 알고리즘."""
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.set_pixel(x0, y0, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = err << 1
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

    def line_thick(self, x0: int, y0: int, x1: int, y1: int,
                   color: RGB, thickness: int = 2) -> None:
        """두께가 있는 직선 (y-offset 반복)."""
        half = thickness // 2
        for t in range(-half, half + 1):
            self.line(x0, y0 + t, x1, y1 + t, color)

    def fill_circle(self, cx: int, cy: int, r: int, color: RGB) -> None:
        """원 채우기."""
        r_sq = r * r
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy <= r_sq:
                    self.set_pixel(cx + dx, cy + dy, color)

    def fill_area(self, points: List[Tuple[int, int]], y_bottom: int,
                  color: RGB) -> None:
        """폴리라인 아래 영역 채우기 (area fill)."""
        pixel = bytes(color)
        for i in range(len(points) - 1):
            x0, y0p = points[i]
            x1, y1p = points[i + 1]
            dx = x1 - x0
            if dx <= 0:
                continue
            for x in range(max(0, x0), min(self.w, x1 + 1)):
                t = (x - x0) / dx
                y_line = int(y0p + (y1p - y0p) * t)
                y_start = max(0, y_line)
                y_end = min(self.h - 1, y_bottom)
                for y in range(y_start, y_end + 1):
                    off = (y * self.w + x) * 3
                    self.data[off:off + 3] = pixel

    # ── PNG 인코딩 ──

    def to_png(self) -> bytes:
        """Indexed-color PNG 생성 (팔레트 방식 → 작은 파일)."""
        palette_map: dict = {}
        palette: list = []
        total_px = self.w * self.h
        indices = bytearray(total_px)
        stride = self.w * 3

        idx = 0
        for y in range(self.h):
            row_start = y * stride
            for x in range(self.w):
                off = row_start + x * 3
                color = (self.data[off], self.data[off + 1], self.data[off + 2])
                pi = palette_map.get(color)
                if pi is None:
                    if len(palette) >= 256:
                        return self._to_png_rgb()
                    pi = len(palette)
                    palette_map[color] = pi
                    palette.append(color)
                indices[idx] = pi
                idx += 1

        sig = b'\x89PNG\r\n\x1a\n'

        ihdr = _mk_chunk(b'IHDR', struct.pack('>IIBBBBB',
            self.w, self.h, 8, 3, 0, 0, 0))

        plte_data = bytearray()
        for r, g, b in palette:
            plte_data.extend((r, g, b))
        plte = _mk_chunk(b'PLTE', bytes(plte_data))

        raw = bytearray()
        for y in range(self.h):
            raw.append(0)
            start = y * self.w
            raw.extend(indices[start:start + self.w])
        idat = _mk_chunk(b'IDAT', zlib.compress(bytes(raw), 9))

        iend = _mk_chunk(b'IEND', b'')
        return sig + ihdr + plte + idat + iend

    def _to_png_rgb(self) -> bytes:
        """RGB PNG 폴백 (256색 초과 시)."""
        sig = b'\x89PNG\r\n\x1a\n'
        ihdr = _mk_chunk(b'IHDR', struct.pack('>IIBBBBB',
            self.w, self.h, 8, 2, 0, 0, 0))

        raw = bytearray()
        stride = self.w * 3
        for y in range(self.h):
            raw.append(0)
            start = y * stride
            raw.extend(self.data[start:start + stride])
        idat = _mk_chunk(b'IDAT', zlib.compress(bytes(raw), 6))

        iend = _mk_chunk(b'IEND', b'')
        return sig + ihdr + idat + iend

    def to_data_uri(self) -> str:
        """data:image/png;base64,... URI 문자열."""
        return 'data:image/png;base64,' + base64.b64encode(self.to_png()).decode('ascii')


# ── 차트 렌더링 ──

def render_line_chart_png(
    values: List[float],
    thresholds: Optional[List[Tuple[float, RGB]]] = None,
    avg_value: Optional[float] = None,
    line_color: RGB = _LINE_BLUE,
    width: int = DEFAULT_WIDTH,
    height: int = DEFAULT_HEIGHT,
) -> str:
    """라인 차트 PNG → data URI 생성.

    Args:
        values: 데이터 값 목록 (최소 2개)
        thresholds: [(임계값, RGB색상), ...] 목록
        avg_value: 평균값 (None이면 자동 계산)
        line_color: 기본 라인 색상
        width: 이미지 너비 (px)
        height: 이미지 높이 (px)

    Returns:
        data:image/png;base64,... URI 또는 빈 문자열
    """
    n = len(values)
    if n < 2:
        return ""

    thresholds = thresholds or []
    if avg_value is None:
        avg_value = sum(values) / n

    # 차트 영역
    cx0, cx1 = _PAD_L, width - _PAD_R
    cy0, cy1 = _PAD_T, height - _PAD_B
    cw = cx1 - cx0
    ch = cy1 - cy0

    # Y축 범위
    y_max = max(values) * 1.15
    for tv, _ in thresholds:
        y_max = max(y_max, tv * 1.15)
    if y_max == 0:
        y_max = 1

    buf = PixelBuffer(width, height)

    # ① 그리드 (수평 4줄)
    for i in range(1, 5):
        gy = cy0 + int(ch * i / 5)
        buf.hline(cx0, cx1, gy, _GRID)

    # ② 데이터 포인트 좌표 계산
    points: List[Tuple[int, int]] = []
    for i, v in enumerate(values):
        x = cx0 + int(i * cw / (n - 1)) if n > 1 else cx0 + cw // 2
        y = cy1 - int(v / y_max * ch)
        y = max(cy0, min(cy1, y))
        points.append((x, y))

    # ③ 영역 채우기 (라인 아래 옅은 색)
    fill_color = lighten(line_color, 0.78)
    buf.fill_area(points, cy1, fill_color)

    # ④ 임계값 점선
    for tv, tc in thresholds:
        ty = cy1 - int(tv / y_max * ch)
        if cy0 < ty < cy1:
            buf.hline_dashed(cx0, cx1, ty, tc, dash=6, gap=4)

    # ⑤ 평균 점선
    ay = cy1 - int(avg_value / y_max * ch)
    if cy0 < ay < cy1:
        buf.hline_dashed(cx0, cx1, ay, _AVG_GRAY, dash=5, gap=3)

    # ⑥ 데이터 라인 (2px)
    for i in range(n - 1):
        buf.line_thick(
            points[i][0], points[i][1],
            points[i + 1][0], points[i + 1][1],
            line_color, 2,
        )

    # ⑦ 데이터 포인트 (dot)
    for i, (px, py) in enumerate(points):
        dot_c = line_color
        for tv, tc in sorted(thresholds, key=lambda x: x[0], reverse=True):
            if values[i] >= tv:
                dot_c = tc
                break
        buf.fill_circle(px, py, 4, WHITE)   # 흰색 테두리
        buf.fill_circle(px, py, 3, dot_c)   # 색상 채움

    return buf.to_data_uri()
