"""
BDP Compact Handler for Cost Drift Detection.

Lambda/FastAPI 핸들러 - Cost Explorer 기반 비용 드리프트 탐지
및 KakaoTalk 알람 발송.
"""

import os
from typing import Any

from src.agent_server.bdp_common.deep_agent import (
    DeepAgentExecutor,
    DetectionInput,
    DetectionItem,
)
from src.agent_server.bdp_common.deep_agent.schemas import DetectionItem
from src.agent_server.bdp_cost.services.anomaly_detector import (
    CostDriftDetector,
    CostDriftResult,
    Severity,
)
from src.agent_server.bdp_cost.services.comparison_analyzer import CostComparisonAnalyzer
from src.agent_server.bdp_cost.services.comparison_models import CostComparisonResult
from src.agent_server.bdp_cost.services.comparison_report_generator import (
    CostComparisonHTMLReportGenerator,
)
from src.agent_server.bdp_cost.services.cost_explorer_provider import (
    BaseCostExplorerProvider,
    create_provider,
)
from src.agent_server.bdp_cost.services.event_publisher import EventPublisher
from src.agent_server.bdp_cost.services.summary_generator import SummaryGenerator
from src.common.handlers.base_handler import BaseHandler
from src.common.hitl.schemas import (
    HITLAgentType,
    HITLRequestCreate,
    HITLRequestType,
)
from src.common.hitl.store import HITLStore
from src.common.timezone import get_kst_now


class BDPCostHandler(BaseHandler):
    """
    BDP Compact 비용 드리프트 탐지 핸들러.

    Cost Explorer 데이터를 분석하여 비용 드리프트를 탐지하고,
    EventBridge를 통해 KakaoTalk 알람을 발송합니다.

    Features:
    - Cost Explorer 접근 (Lambda 실행 역할 권한 사용)
    - PyOD ECOD 기반 이상 탐지
    - 한글 Rich Summary 생성
    - EventBridge → KakaoTalk 알람
    - 확장된 HITL (PROMPT_INPUT 지원)
    """

    def __init__(self):
        super().__init__("BDPCostHandler")
        self._init_services()

    def _init_services(self) -> None:
        """서비스 컴포넌트 초기화."""
        # Provider 설정
        provider_type = os.getenv("BDP_PROVIDER", "mock")
        self.provider: BaseCostExplorerProvider = create_provider(provider_type=provider_type)

        # Detector 설정
        sensitivity = float(os.getenv("BDP_SENSITIVITY", "0.7"))
        self.detector = CostDriftDetector(sensitivity=sensitivity)

        # Summary Generator 설정
        currency = os.getenv("BDP_CURRENCY", "KRW")
        self.summary_generator = SummaryGenerator(currency=currency)

        # Event Publisher 설정
        event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.event_publisher = EventPublisher(
            event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
            use_mock=event_provider == "mock",
        )

        # HITL Store 설정
        hitl_provider = os.getenv("RDS_PROVIDER", "mock")
        self.hitl_store = HITLStore(use_mock=hitl_provider == "mock")

        # 설정값
        self.min_cost_threshold = float(os.getenv("BDP_MIN_COST_THRESHOLD", "10000"))
        self.hitl_on_critical = os.getenv("BDP_HITL_ON_CRITICAL", "true").lower() == "true"

        # 기본 이메일 설정
        default_email = os.getenv("BDP_DEFAULT_EMAIL_TO", "")
        self.default_email_to = [e.strip() for e in default_email.split(",") if e.strip()]
        default_email_cc = os.getenv("BDP_DEFAULT_EMAIL_CC", "")
        self.default_email_cc = [e.strip() for e in default_email_cc.split(",") if e.strip()]

        self.logger.info(
            f"BDPCostHandler initialized: provider={provider_type}, "
            f"sensitivity={sensitivity}, currency={currency}"
        )

    def _validate_input(self, event: dict[str, Any]) -> str | None:
        """입력 검증."""
        # 기본 파라미터는 선택적이므로 검증 불필요
        return None

    def process(self, event: dict[str, Any], context: Any) -> dict[str, Any]:
        """비용 드리프트 탐지/비교 실행.

        Args:
            event: Lambda 이벤트 또는 API 요청
            context: Lambda context

        Returns:
            탐지/비교 결과
        """
        body = self._parse_body(event)

        # action 라우팅
        action = body.get("action", event.get("action", "detect"))

        if action == "compare":
            return self._process_compare(body, event)
        elif action == "detect":
            return self._process_detect(body, event)
        elif action == "daily_report":
            return self._generate_daily_report(body, event)
        elif action == "e2e":
            return self._run_e2e(body, event)
        else:
            return {
                "status": "error",
                "message": f"Unknown action: {action}. Valid actions: detect, compare, daily_report, e2e",
            }

    def _process_detect(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """비용 드리프트 탐지 처리.

        Args:
            body: 파싱된 요청 본문
            event: 원본 이벤트

        Returns:
            탐지 결과
        """
        # 파라미터 추출
        days = int(body.get("days", event.get("days", 14)))
        min_cost = float(
            body.get("min_cost_threshold", event.get("min_cost_threshold", self.min_cost_threshold))
        )
        publish_alerts = body.get("publish_alerts", event.get("publish_alerts", True))

        account_info = self.provider.get_account_info()
        account_id = account_info["account_id"]

        self.logger.info(f"비용 드리프트 탐지 시작: days={days}, min_cost={min_cost}")

        # 1. 비용 데이터 조회
        self.logger.info(f"[{account_id}] Fetching cost data...")
        cost_data_list = self.provider.get_cost_data(days=days)
        total_services = len(cost_data_list)
        self.logger.info(f"[{account_id}] Cost data done: {total_services} services")

        # 2. 비용 드리프트 탐지
        # Detector expects Dict[str, List] format for backward compatibility
        self.logger.info(f"[{account_id}] Analyzing anomalies...")
        cost_data = {account_id: cost_data_list}
        all_results = self.detector.analyze_batch(cost_data)

        # 3. 최소 비용 임계값 필터링
        filtered_results = [
            r for r in all_results if r.current_cost >= min_cost or r.historical_average >= min_cost
        ]

        # 4. 이상 탐지된 결과만 추출
        anomalies = [r for r in filtered_results if r.is_anomaly]
        severity_breakdown = self._count_by_severity(anomalies)

        self.logger.info(
            f"탐지 완료: {len(anomalies)}건 이상 발견 "
            f"(심각: {severity_breakdown['critical']}, "
            f"높음: {severity_breakdown['high']})"
        )

        # 5. 알람 발송 (이상 탐지된 경우)
        hitl_request_id = None
        if anomalies and publish_alerts:
            # Summary 생성
            summary = self.summary_generator.generate_batch_summary(anomalies)

            # Critical 이상인 경우 HITL 요청 생성
            if self.hitl_on_critical and severity_breakdown["critical"] > 0:
                hitl_request_id = self._create_hitl_request(anomalies, summary)

            # EventBridge 발행
            self.logger.info(f"[{account_id}] Publishing alerts...")
            self.event_publisher.publish_batch_alert(
                results=anomalies,
                summary=summary,
                hitl_request_id=hitl_request_id,
            )

        # 6. 결과 반환
        detect_result = {
            "detection_type": "cost_drift",
            "period_days": days,
            "accounts_analyzed": 1,  # Single account architecture
            "services_analyzed": len(filtered_results),
            "anomalies_detected": len(anomalies) > 0,
            "total_anomalies": len(anomalies),
            "severity_breakdown": severity_breakdown,
            "summary": self._generate_result_summary(anomalies),
            "results": [self._result_to_dict(r) for r in anomalies[:20]],
            "hitl_request_id": hitl_request_id,
            "detection_timestamp": get_kst_now().isoformat(),
        }

        # 7. Deep Analysis (심각도 높을 때)
        return self._run_deep_analysis(detect_result)

    def _process_compare(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """비용 비교 처리.

        두 기간의 비용을 비교하여 HTML 리포트를 생성하고 알림을 발송합니다.

        Args:
            body: 파싱된 요청 본문
            event: 원본 이벤트

        Returns:
            비교 결과
        """
        # 파라미터 추출
        granularity = body.get("granularity", event.get("granularity", "monthly"))
        periods = body.get("periods", event.get("periods", []))
        email_to = body.get("email_to") or self.default_email_to
        email_cc = body.get("email_cc") or self.default_email_cc
        send_kakao = body.get("send_kakao", event.get("send_kakao", False))

        # Validation
        if len(periods) != 2:
            return {
                "status": "error",
                "message": "periods must have exactly 2 elements (e.g., ['202512', '202601'])",
            }

        account_info = self.provider.get_account_info()
        account_id = account_info["account_id"]
        account_name = account_info["account_name"]

        self.logger.info(f"비용 비교 시작: granularity={granularity}, periods={periods}")

        # 1. 기간별 비용 데이터 조회
        self.logger.info(f"[{account_id}] Fetching cost data for periods: {periods}")
        period_data = self.provider.get_cost_data_by_period(granularity, periods)

        # 2. 비교 분석
        self.logger.info(f"[{account_id}] Analyzing comparison...")
        analyzer = CostComparisonAnalyzer()
        result = analyzer.analyze(
            period_data=period_data,
            granularity=granularity,
            periods=periods,
            account_id=account_id,
            account_name=account_name,
        )

        # 3. HTML 리포트 생성
        currency = os.getenv("BDP_CURRENCY", "KRW")
        report_gen = CostComparisonHTMLReportGenerator(currency=currency)
        html_report = report_gen.generate(result)

        # 4. 알림 발송 (무조건)
        report_sent = False
        if email_to:
            self.logger.info(f"[{account_id}] Sending comparison report...")
            report_sent = self._publish_comparison_report(
                result=result,
                html_report=html_report,
                email_to=email_to,
                email_cc=email_cc,
                send_kakao=send_kakao,
            )

        return {
            "status": "success",
            "report_type": "cost_comparison",
            "granularity": granularity,
            "periods": periods,
            "account_id": account_id,
            "account_name": account_name,
            "summary": {
                "total_period1": result.total_period1_cost,
                "total_period2": result.total_period2_cost,
                "change": result.total_change,
                "change_percent": result.total_change_percent,
                "services_compared": len(result.service_comparisons),
            },
            "report_sent": report_sent,
            "timestamp": get_kst_now().isoformat(),
        }

    def _publish_comparison_report(
        self,
        result: CostComparisonResult,
        html_report: str,
        email_to: list[str],
        email_cc: list[str],
        send_kakao: bool,
    ) -> bool:
        """비용 비교 리포트 발송.

        EventBridge를 통해 이메일/카카오톡으로 리포트를 발송합니다.

        Args:
            result: 비용 비교 결과
            html_report: HTML 리포트 문자열
            email_to: 수신자 이메일 목록
            email_cc: 참조 이메일 목록
            send_kakao: 카카오톡 발송 여부

        Returns:
            발송 성공 여부
        """
        # 변화율에 따른 제목 이모지
        if result.total_change_percent >= 20:
            emoji = "📈"
        elif result.total_change_percent <= -20:
            emoji = "📉"
        else:
            emoji = "📊"

        subject = (
            f"{emoji} [비용 비교] {result.period1} vs {result.period2} "
            f"({result.total_change_percent:+.1f}%)"
        )

        # EventBridge ProductionAlertDetail 형식 사용
        from src.agent_server.bdp_common.eventbridge.publisher import (
            EmailChannel,
            KakaoChannel,
            ProductionAlertDetail,
            get_environment_account_name,
        )

        # 이메일 채널 설정
        email_channel = (
            EmailChannel(
                to=email_to,
                cc=email_cc or [],
                from_email="alert-cost@hcs.com",
                message=html_report,
            )
            if email_to
            else None
        )

        # 카카오 채널 설정
        kakao_channel = None
        if send_kakao:
            # 비교 결과 요약 메시지
            summary_msg = (
                f"[비용 비교 리포트]\n"
                f"{result.period1} vs {result.period2}\n\n"
                f"총 비용 변화: {result.total_change_percent:+.1f}%\n"
                f"• {result.period1}: {self._format_cost_for_kakao(result.total_period1_cost)}\n"
                f"• {result.period2}: {self._format_cost_for_kakao(result.total_period2_cost)}"
            )
            kakao_channel = KakaoChannel(
                severity="INFO",
                category1="BDP",
                category2="Cost",
                category3="Comparison",
                message=summary_msg,
            )

        detail = ProductionAlertDetail(
            subject=subject,
            account_id=get_environment_account_name(),
            component="BDPC",
            email=email_channel,
            kakao=kakao_channel,
        )

        return self.event_publisher.publish_production_event(
            detail=detail,
            detail_type="Cost Comparison Report",
        )

    def _format_cost_for_kakao(self, cost: float) -> str:
        """카카오톡용 비용 포맷팅."""
        currency = os.getenv("BDP_CURRENCY", "KRW")
        if currency == "KRW":
            if cost >= 100_000_000:
                return f"{cost / 100_000_000:.1f}억원"
            elif cost >= 10_000:
                return f"{cost / 10_000:.0f}만원"
            else:
                return f"{cost:,.0f}원"
        else:
            return f"${cost:,.2f}"

    def _generate_daily_report(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """비용 드리프트 일간 리포트 생성.

        현재 탐지 결과를 기반으로 텍스트 리포트를 생성합니다.
        """
        from pathlib import Path

        from src.agent_server.bdp_cost.services.report_generator import ReportGenerator

        output_dir = body.get("output_dir", event.get("output_dir", "reports/"))
        days = int(body.get("days", event.get("days", 14)))
        min_cost = float(
            body.get("min_cost_threshold", event.get("min_cost_threshold", self.min_cost_threshold))
        )

        # 탐지 실행
        account_info = self.provider.get_account_info()
        account_id = account_info["account_id"]
        cost_data_list = self.provider.get_cost_data(days=days)
        cost_data = {account_id: cost_data_list}
        all_results = self.detector.analyze_batch(cost_data)

        filtered = [
            r for r in all_results if r.current_cost >= min_cost or r.historical_average >= min_cost
        ]
        anomalies = [r for r in filtered if r.is_anomaly]

        # 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        report_path = str(output_path / "cost_daily_report.txt")

        report_gen = ReportGenerator(currency=os.getenv("BDP_CURRENCY", "KRW"))
        report_text = report_gen.generate(anomalies)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_text)

        severity_counts = self._count_by_severity(anomalies)

        return {
            "status": "success",
            "action": "daily_report",
            "report_path": report_path,
            "summary": {
                "total_checked": len(filtered),
                "total_anomalies": len(anomalies),
                "by_severity": severity_counts,
            },
        }

    def _run_e2e(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """E2E 시나리오 테스트 실행."""
        from src.agent_server.bdp_cost.services.e2e_runner import CostE2ERunner

        output_dir = body.get("output_dir", event.get("output_dir", "reports/"))

        runner = CostE2ERunner()
        result = runner.run_all(output_dir=output_dir)

        return {
            "status": "success",
            "action": "e2e",
            "pass_rate": result.pass_rate,
            "passed": result.passed,
            "failed": result.failed,
            "total": result.total,
            "report_path": result.e2e_report_path,
        }

    def _run_deep_analysis(self, detect_result: dict[str, Any]) -> dict[str, Any]:
        """심각도 높을 때 deep analysis 실행."""
        severity = detect_result.get("severity_breakdown", {})
        if severity.get("critical", 0) > 0 or severity.get("high", 0) > 0:
            try:
                items = self._normalize_detection_items(detect_result)
                detection_input = DetectionInput(
                    agent_type="bdp_cost",
                    detection_type=detect_result.get("detection_type", "cost_drift"),
                    severity="critical" if severity.get("critical", 0) > 0 else "high",
                    summary=detect_result.get("summary", ""),
                    total_anomalies=detect_result.get("total_anomalies", 0),
                    severity_breakdown=severity,
                    items=items,
                )
                executor = DeepAgentExecutor(tools=create_investigation_tools("bdp_cost"))
                result = executor.run(detection_input)
                detect_result["deep_analysis"] = result.model_dump()
            except Exception as e:
                self.logger.error(f"Deep analysis 실패: {e}")
        return detect_result

    def _normalize_detection_items(self, detect_result: dict[str, Any]) -> list[DetectionItem]:
        """비용 이상 결과를 DetectionItem 형식으로 변환."""
        items = []
        for r in detect_result.get("results", []):
            items.append(
                DetectionItem(
                    item_type="anomaly",
                    resource_id=r.get("service_name", "unknown"),
                    severity=r.get("severity", "medium"),
                    title=f"{r.get('service_name', '')} 비용 이상",
                    description=r.get("summary", ""),
                    confidence=r.get("confidence_score", 0.0),
                    raw_data={
                        "change_percent": r.get("change_percent", 0),
                        "current_cost": r.get("current_cost", 0),
                        "historical_average": r.get("historical_average", 0),
                    },
                )
            )
        return items

    def _count_by_severity(self, results: list[CostDriftResult]) -> dict[str, int]:
        """심각도별 카운트."""
        return {
            "critical": sum(1 for r in results if r.severity == Severity.CRITICAL),
            "high": sum(1 for r in results if r.severity == Severity.HIGH),
            "medium": sum(1 for r in results if r.severity == Severity.MEDIUM),
            "low": sum(1 for r in results if r.severity == Severity.LOW),
        }

    def _generate_result_summary(self, anomalies: list[CostDriftResult]) -> str:
        """결과 요약 문자열 생성."""
        if not anomalies:
            return "비용 이상이 탐지되지 않았습니다."

        severity_counts = self._count_by_severity(anomalies)
        services = [r.service_name for r in anomalies[:5]]
        accounts = list(set(r.account_name for r in anomalies))

        return (
            f"총 {len(anomalies)}건의 비용 이상이 탐지되었습니다. "
            f"[심각: {severity_counts['critical']}, "
            f"높음: {severity_counts['high']}, "
            f"보통: {severity_counts['medium']}, "
            f"낮음: {severity_counts['low']}] "
            f"영향 서비스: {', '.join(services)} | "
            f"영향 계정: {', '.join(accounts)}"
        )

    def _result_to_dict(self, result: CostDriftResult) -> dict[str, Any]:
        """CostDriftResult를 딕셔너리로 변환."""
        # 개별 summary 생성
        summary = self.summary_generator.generate(result)

        return {
            "service_name": result.service_name,
            "account_id": result.account_id,
            "account_name": result.account_name,
            "severity": result.severity.value,
            "confidence_score": result.confidence_score,
            "current_cost": result.current_cost,
            "historical_average": result.historical_average,
            "change_percent": result.change_percent,
            "spike_duration_days": result.spike_duration_days,
            "trend_direction": result.trend_direction,
            "spike_start_date": result.spike_start_date,
            "detection_method": result.detection_method,
            "summary": summary.message,  # 한글 summary
        }

    def _create_hitl_request(
        self,
        anomalies: list[CostDriftResult],
        summary,
    ) -> str | None:
        """Critical 이상 탐지시 HITL 요청 생성.

        PROMPT_INPUT 타입으로 사용자에게 추가 질문 가능.

        Args:
            anomalies: 이상 탐지 결과 목록
            summary: 알람 요약

        Returns:
            생성된 HITL 요청 ID 또는 None
        """
        try:
            critical_services = [
                r.service_name for r in anomalies if r.severity == Severity.CRITICAL
            ]

            request = HITLRequestCreate(
                agent_type=HITLAgentType.BDP,
                request_type=HITLRequestType.PROMPT_INPUT,
                title=f"비용 드리프트 확인 필요: {', '.join(critical_services[:3])}",
                description=(
                    "Critical 수준의 비용 이상이 탐지되었습니다. "
                    "이 비용 급증이 예상된 것인지 확인이 필요합니다.\n\n"
                    f"{summary.message}"
                ),
                payload={
                    "anomaly_count": len(anomalies),
                    "critical_count": len(critical_services),
                    "affected_services": critical_services[:10],
                    "detection_timestamp": get_kst_now().isoformat(),
                    "question": (
                        "이 비용 급증이 예상된 것인가요? "
                        "(예: 배치 작업, 마케팅 캠페인, 신규 서비스 런칭 등)"
                    ),
                },
                expires_in_minutes=120,  # 2시간
                created_by="bdp-cost-agent",
            )

            hitl_request = self.hitl_store.create(request)
            self.logger.info(f"HITL 요청 생성됨: {hitl_request.id}")
            return hitl_request.id

        except Exception as e:
            self.logger.error(f"HITL 요청 생성 실패: {e}")
            return None


# Lambda entry point
handler_instance = BDPCostHandler()


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda function entry point."""
    return handler_instance.handle(event, context)
