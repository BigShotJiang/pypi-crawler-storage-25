"""
BDP Cost HTML Report Generator.

비용 드리프트 탐지 결과를 HTML 이메일 리포트로 생성.
Material Design 3 기반 디자인 시스템 적용.
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_common.reports.styles import MD3_COLORS, SEVERITY_COLORS
from .anomaly_detector import CostDriftResult, Severity

logger = logging.getLogger(__name__)


@dataclass
class CostEmailReport:
    """이메일 리포트 데이터."""

    subject: str
    html_body: str


class CostHTMLReportGenerator:
    """
    비용 드리프트 HTML 리포트 생성기.

    이메일 클라이언트 호환성을 위해 인라인 스타일 사용.
    Material Design 3 색상 팔레트 적용.
    """

    SEVERITY_EMOJI = {
        Severity.CRITICAL: "🚨",
        Severity.HIGH: "⚠️",
        Severity.MEDIUM: "📊",
        Severity.LOW: "ℹ️",
    }

    TREND_KOREAN = {
        "increasing": "상승",
        "decreasing": "하락",
        "stable": "안정",
    }

    def __init__(self, currency: str = "KRW"):
        """리포트 생성기 초기화.

        Args:
            currency: 통화 단위 (KRW, USD)
        """
        self.currency = currency

    def generate_email_report(
        self,
        results: List[CostDriftResult],
        title: str,
        timestamp: Optional[str] = None,
    ) -> CostEmailReport:
        """이메일용 HTML 리포트 생성.

        Args:
            results: CostDriftResult 목록
            title: 리포트 제목
            timestamp: 생성 시간 (없으면 현재 시간)

        Returns:
            CostEmailReport 객체
        """
        if not timestamp:
            timestamp = get_kst_now().strftime("%Y-%m-%d %H:%M:%S KST")

        # 이상 탐지된 결과만 필터링
        anomalies = [r for r in results if r.is_anomaly]

        if not anomalies:
            return CostEmailReport(
                subject="✅ 비용 정상",
                html_body=self._generate_no_anomaly_html(timestamp),
            )

        # 심각도별 카운트
        severity_counts = self._count_by_severity(anomalies)

        # 가장 높은 심각도
        highest_severity = self._get_highest_severity(anomalies)
        emoji = self.SEVERITY_EMOJI.get(highest_severity, "📊")

        subject = f"{emoji} {title}"

        html_body = self._generate_html(
            anomalies=anomalies,
            severity_counts=severity_counts,
            highest_severity=highest_severity,
            timestamp=timestamp,
        )

        return CostEmailReport(subject=subject, html_body=html_body)

    def _generate_html(
        self,
        anomalies: List[CostDriftResult],
        severity_counts: dict,
        highest_severity: Severity,
        timestamp: str,
    ) -> str:
        """전체 HTML 생성."""
        emoji = self.SEVERITY_EMOJI.get(highest_severity, "📊")

        # 섹션별 HTML 생성
        header_html = self._render_header(emoji, timestamp)
        summary_html = self._render_summary_stats(len(anomalies), severity_counts)
        table_html = self._render_table(anomalies)
        detail_html = self._render_detail_cards(anomalies[:5])  # 상위 5건
        footer_html = self._render_footer()

        return f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 20px; font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: {MD3_COLORS['surface_variant']}; color: {MD3_COLORS['on_surface']}; line-height: 1.6;">
    <div style="max-width: 700px; margin: 0 auto; background-color: {MD3_COLORS['surface']}; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
        {header_html}
        <div style="padding: 24px;">
            {summary_html}
            {table_html}
            {detail_html}
        </div>
        {footer_html}
    </div>
</body>
</html>"""

    def _render_header(self, emoji: str, timestamp: str) -> str:
        """헤더 섹션 렌더링."""
        return f"""
        <div style="background: linear-gradient(135deg, {MD3_COLORS['primary']}, #1565C0); padding: 24px;">
            <h1 style="margin: 0; font-size: 22px; font-weight: 600; color: {MD3_COLORS['on_surface']};">
                {emoji} 비용 드리프트 탐지
            </h1>
            <p style="margin: 8px 0 0 0; font-size: 14px; opacity: 0.9; color: {MD3_COLORS['on_surface_variant']};">
                Generated at {timestamp}
            </p>
        </div>"""

    def _render_summary_stats(self, total: int, severity_counts: dict) -> str:
        """요약 통계 섹션 렌더링."""
        return f"""
        <div style="display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 100px; background: {MD3_COLORS['surface_variant']}; border-radius: 8px; padding: 16px; text-align: center;">
                <div style="font-size: 28px; font-weight: 700; color: {MD3_COLORS['primary']};">{total}</div>
                <div style="font-size: 12px; color: {MD3_COLORS['on_surface_variant']};">총 이상 탐지</div>
            </div>
            <div style="flex: 1; min-width: 100px; background: {SEVERITY_COLORS['critical']['bg']}; border-radius: 8px; padding: 16px; text-align: center;">
                <div style="font-size: 28px; font-weight: 700; color: {SEVERITY_COLORS['critical']['text']};">{severity_counts['critical']}</div>
                <div style="font-size: 12px; color: {SEVERITY_COLORS['critical']['text']};">심각</div>
            </div>
            <div style="flex: 1; min-width: 100px; background: {SEVERITY_COLORS['high']['bg']}; border-radius: 8px; padding: 16px; text-align: center;">
                <div style="font-size: 28px; font-weight: 700; color: {SEVERITY_COLORS['high']['text']};">{severity_counts['high']}</div>
                <div style="font-size: 12px; color: {SEVERITY_COLORS['high']['text']};">높음</div>
            </div>
            <div style="flex: 1; min-width: 100px; background: {SEVERITY_COLORS['medium']['bg']}; border-radius: 8px; padding: 16px; text-align: center;">
                <div style="font-size: 28px; font-weight: 700; color: {SEVERITY_COLORS['medium']['text']};">{severity_counts['medium']}</div>
                <div style="font-size: 12px; color: {SEVERITY_COLORS['medium']['text']};">보통</div>
            </div>
        </div>"""

    def _render_table(self, anomalies: List[CostDriftResult]) -> str:
        """테이블 섹션 렌더링."""
        rows = []
        for r in anomalies:
            service_display = self._clean_service_name(r.service_name)
            current_cost = self._format_cost(r.current_cost)
            change_color = SEVERITY_COLORS['critical']['text'] if r.change_percent > 0 else SEVERITY_COLORS['medium']['text']
            change_sign = "+" if r.change_percent > 0 else ""
            badge = self._get_severity_badge(r.severity)

            rows.append(f"""
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">{service_display}</td>
                    <td style="padding: 12px; border-bottom: 1px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">{r.account_name}</td>
                    <td style="padding: 12px; border-bottom: 1px solid {MD3_COLORS['outline_variant']}; text-align: right; font-weight: 600; color: {MD3_COLORS['on_surface']};">{current_cost}</td>
                    <td style="padding: 12px; border-bottom: 1px solid {MD3_COLORS['outline_variant']}; text-align: right; color: {change_color}; font-weight: 600;">{change_sign}{r.change_percent:.0f}%</td>
                    <td style="padding: 12px; border-bottom: 1px solid {MD3_COLORS['outline_variant']}; text-align: center;">{badge}</td>
                </tr>
            """)

        return f"""
        <div style="margin-bottom: 24px;">
            <h3 style="margin: 0 0 12px 0; font-size: 16px; font-weight: 600; color: {MD3_COLORS['on_surface']};">
                탐지 결과
            </h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                <thead>
                    <tr style="background: {MD3_COLORS['surface_variant']};">
                        <th style="padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">서비스</th>
                        <th style="padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">계정</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600; border-bottom: 2px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">현재 비용</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600; border-bottom: 2px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">평균 대비</th>
                        <th style="padding: 12px; text-align: center; font-weight: 600; border-bottom: 2px solid {MD3_COLORS['outline_variant']}; color: {MD3_COLORS['on_surface']};">심각도</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
        </div>"""

    def _render_detail_cards(self, anomalies: List[CostDriftResult]) -> str:
        """상세 카드 섹션 렌더링 (상위 N건)."""
        if not anomalies:
            return ""

        cards = []
        for r in anomalies:
            emoji = self.SEVERITY_EMOJI.get(r.severity, "📊")
            service_display = self._clean_service_name(r.service_name)
            current_cost = self._format_cost(r.current_cost)
            historical_avg = self._format_cost(r.historical_average)
            spike_date = self._format_date(r.spike_start_date) if r.spike_start_date else "최근"
            trend_text = self.TREND_KOREAN.get(r.trend_direction, r.trend_direction)
            border_color = SEVERITY_COLORS[r.severity.value]['border']
            change_color = SEVERITY_COLORS['critical']['text'] if r.change_percent > 0 else SEVERITY_COLORS['medium']['text']
            change_sign = "+" if r.change_percent > 0 else ""

            cards.append(f"""
            <div style="border: 1px solid {MD3_COLORS['outline_variant']}; border-left: 4px solid {border_color}; border-radius: 8px; padding: 16px; margin-bottom: 12px; background: {MD3_COLORS['surface']};">
                <div style="font-weight: 600; font-size: 15px; margin-bottom: 8px; color: {MD3_COLORS['on_surface']};">
                    {emoji} {service_display} ({r.account_name})
                </div>
                <p style="margin: 0 0 12px 0; font-size: 14px; color: {MD3_COLORS['on_surface_variant']};">
                    일평균 <strong>{historical_avg}</strong>에서 {spike_date}에 <strong>{current_cost}</strong>로
                    <span style="color: {change_color}; font-weight: 600;">{change_sign}{r.change_percent:.0f}% 변동</span>
                </p>
                <div style="font-size: 12px; color: {MD3_COLORS['on_surface_variant']}; display: flex; flex-wrap: wrap; gap: 16px;">
                    <span>📅 지속 기간: {r.spike_duration_days}일</span>
                    <span>📈 추세: {trend_text}</span>
                    <span>🎯 신뢰도: {r.confidence_score * 100:.0f}%</span>
                    <span>🔬 탐지: {r.detection_method}</span>
                </div>
            </div>
            """)

        return f"""
        <div style="margin-top: 24px;">
            <h3 style="margin: 0 0 12px 0; font-size: 16px; font-weight: 600; color: {MD3_COLORS['on_surface']};">
                상세 분석
            </h3>
            {''.join(cards)}
        </div>"""

    def _render_footer(self) -> str:
        """푸터 섹션 렌더링."""
        return f"""
        <div style="text-align: center; padding: 16px; background: {MD3_COLORS['surface_variant']}; color: {MD3_COLORS['on_surface_variant']}; font-size: 12px;">
            BDP Cost Agent | cd1-agent
        </div>"""

    def _generate_no_anomaly_html(self, timestamp: str) -> str:
        """이상 없음 HTML 생성."""
        return f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 20px; font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: {MD3_COLORS['surface_variant']};">
    <div style="max-width: 600px; margin: 0 auto; background-color: {MD3_COLORS['surface']}; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
        <div style="background: linear-gradient(135deg, {MD3_COLORS['success']}, #2E7D32); padding: 24px;">
            <h1 style="margin: 0; font-size: 22px; font-weight: 600; color: {MD3_COLORS['on_surface']};">
                ✅ 비용 정상
            </h1>
            <p style="margin: 8px 0 0 0; font-size: 14px; opacity: 0.9; color: {MD3_COLORS['on_surface_variant']};">
                Generated at {timestamp}
            </p>
        </div>
        <div style="padding: 24px; text-align: center;">
            <p style="font-size: 16px; color: {MD3_COLORS['on_surface']};">
                모든 서비스의 비용이 정상 범위 내에 있습니다.
            </p>
        </div>
        <div style="text-align: center; padding: 16px; background: {MD3_COLORS['surface_variant']}; color: {MD3_COLORS['on_surface_variant']}; font-size: 12px;">
            BDP Cost Agent | cd1-agent
        </div>
    </div>
</body>
</html>"""

    def _get_severity_badge(self, severity: Severity) -> str:
        """심각도 배지 HTML 반환."""
        colors = SEVERITY_COLORS[severity.value]
        label = severity.value.upper()
        return f'<span style="display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; background: {colors["bg"]}; color: {colors["text"]}; border: 1px solid {colors["border"]};">{label}</span>'

    def _count_by_severity(self, results: List[CostDriftResult]) -> dict:
        """심각도별 카운트."""
        return {
            "critical": sum(1 for r in results if r.severity == Severity.CRITICAL),
            "high": sum(1 for r in results if r.severity == Severity.HIGH),
            "medium": sum(1 for r in results if r.severity == Severity.MEDIUM),
            "low": sum(1 for r in results if r.severity == Severity.LOW),
        }

    def _get_highest_severity(self, results: List[CostDriftResult]) -> Severity:
        """가장 높은 심각도 반환."""
        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM]:
            if any(r.severity == severity for r in results):
                return severity
        return Severity.LOW

    def _clean_service_name(self, service_name: str) -> str:
        """서비스명 정리 (Amazon, AWS 접두사 제거)."""
        name = service_name
        prefixes = ["Amazon ", "AWS ", "Amazon"]
        for prefix in prefixes:
            if name.startswith(prefix):
                name = name[len(prefix):]
        return name.strip()

    def _format_cost(self, cost: float) -> str:
        """비용을 읽기 쉬운 형식으로 포맷팅."""
        if self.currency == "KRW":
            if cost >= 100_000_000:  # 1억 이상
                return f"{cost / 100_000_000:.1f}억원"
            elif cost >= 10_000:  # 1만 이상
                return f"{cost / 10_000:.0f}만원"
            else:
                return f"{cost:,.0f}원"
        else:  # USD
            if cost >= 1_000_000:
                return f"${cost / 1_000_000:.1f}M"
            elif cost >= 1_000:
                return f"${cost / 1_000:.1f}K"
            else:
                return f"${cost:,.2f}"

    def _format_date(self, date_str: str) -> str:
        """날짜를 한글 형식으로 포맷팅."""
        try:
            dt = datetime.strptime(date_str[:10], "%Y-%m-%d")
            return f"{dt.month}월 {dt.day}일"
        except (ValueError, TypeError):
            return date_str
