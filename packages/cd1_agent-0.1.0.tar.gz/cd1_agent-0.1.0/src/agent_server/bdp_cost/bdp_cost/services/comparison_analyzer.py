"""
Cost Comparison Analyzer.

기간별 비용 데이터를 분석하여 비교 결과를 생성합니다.
"""

import logging
from typing import Dict, List, Optional

from .comparison_models import (
    CostComparisonResult,
    Granularity,
    ServiceCostComparison,
)

logger = logging.getLogger(__name__)


class CostComparisonAnalyzer:
    """비용 비교 분석기."""

    def __init__(self, top_n: int = 5):
        """분석기 초기화.

        Args:
            top_n: Top 증가/감소 항목 수
        """
        self.top_n = top_n

    def analyze(
        self,
        period_data: Dict[str, Dict[str, float]],  # {period: {service: cost}}
        granularity: str,
        periods: List[str],
        account_id: str,
        account_name: str,
        period_ranges: Optional[List[str]] = None,
    ) -> CostComparisonResult:
        """기간별 비용 데이터를 분석하여 비교 결과 생성.

        Args:
            period_data: 기간별 서비스 비용 데이터
            granularity: 비교 기간 단위
            periods: 비교할 두 기간
            account_id: 계정 ID
            account_name: 계정 이름
            period_ranges: 날짜 범위 문자열 목록 (MTD 등에서 실제 범위 표시용)

        Returns:
            CostComparisonResult
        """
        if len(periods) != 2:
            raise ValueError("periods must have exactly 2 elements")

        period1, period2 = periods[0], periods[1]
        data1 = period_data.get(period1, {})
        data2 = period_data.get(period2, {})

        # 모든 서비스 합집합
        all_services = set(data1.keys()) | set(data2.keys())

        # 서비스별 비교 계산
        comparisons: List[ServiceCostComparison] = []

        for service in all_services:
            cost1 = data1.get(service, 0.0)
            cost2 = data2.get(service, 0.0)
            change = cost2 - cost1

            if cost1 > 0:
                change_pct = (change / cost1) * 100
            elif cost2 > 0:
                change_pct = 100.0  # 새로 생긴 서비스
            else:
                change_pct = 0.0

            comparisons.append(ServiceCostComparison(
                service_name=service,
                period1_cost=cost1,
                period2_cost=cost2,
                cost_change=change,
                change_percent=change_pct,
            ))

        # period2 비용 기준 내림차순 정렬
        comparisons.sort(key=lambda x: x.period2_cost, reverse=True)

        # 총계 계산
        total_period1 = sum(c.period1_cost for c in comparisons)
        total_period2 = sum(c.period2_cost for c in comparisons)
        total_change = total_period2 - total_period1
        total_change_pct = (
            (total_change / total_period1) * 100 if total_period1 > 0 else 0.0
        )

        # Top 증가/감소 추출
        increases = [c for c in comparisons if c.cost_change > 0]
        decreases = [c for c in comparisons if c.cost_change < 0]

        top_increases = sorted(
            increases, key=lambda x: x.cost_change, reverse=True
        )[:self.top_n]
        top_decreases = sorted(
            decreases, key=lambda x: x.cost_change
        )[:self.top_n]

        # period_ranges 처리
        period1_range = period_ranges[0] if period_ranges and len(period_ranges) > 0 else None
        period2_range = period_ranges[1] if period_ranges and len(period_ranges) > 1 else None

        result = CostComparisonResult(
            granularity=Granularity(granularity),
            period1=period1,
            period2=period2,
            account_id=account_id,
            account_name=account_name,
            total_period1_cost=total_period1,
            total_period2_cost=total_period2,
            total_change=total_change,
            total_change_percent=total_change_pct,
            service_comparisons=comparisons,
            top_increases=top_increases,
            top_decreases=top_decreases,
            period1_range=period1_range,
            period2_range=period2_range,
        )

        logger.info(
            f"Comparison analysis completed: {period1} vs {period2}, "
            f"{len(comparisons)} services, "
            f"change={total_change_pct:+.1f}%"
        )

        return result
