"""Athena 요금 정보 제공자.

AWS Pricing API를 통해 Athena TB당 요금을 동적으로 조회합니다.
"""

import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Optional

import urllib3

# Proxy 환경에서 SSL 검증 비활성화 시 발생하는 경고 억제
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .multi_account_provider import _get_boto3_config

logger = logging.getLogger(__name__)

# AWS 리전 코드 -> Location 매핑
REGION_LOCATION_MAP = {
    "us-east-1": "US East (N. Virginia)",
    "us-east-2": "US East (Ohio)",
    "us-west-1": "US West (N. California)",
    "us-west-2": "US West (Oregon)",
    "ap-northeast-1": "Asia Pacific (Tokyo)",
    "ap-northeast-2": "Asia Pacific (Seoul)",
    "ap-northeast-3": "Asia Pacific (Osaka)",
    "ap-south-1": "Asia Pacific (Mumbai)",
    "ap-southeast-1": "Asia Pacific (Singapore)",
    "ap-southeast-2": "Asia Pacific (Sydney)",
    "eu-central-1": "EU (Frankfurt)",
    "eu-west-1": "EU (Ireland)",
    "eu-west-2": "EU (London)",
    "eu-west-3": "EU (Paris)",
    "eu-north-1": "EU (Stockholm)",
    "sa-east-1": "South America (Sao Paulo)",
    "ca-central-1": "Canada (Central)",
}


class AthenaPricingProvider:
    """AWS Pricing API를 통한 Athena 요금 조회.

    Pricing API는 us-east-1에서만 사용 가능합니다.
    캐싱을 통해 반복 호출을 최소화합니다.
    """

    DEFAULT_PRICE_PER_TB = 5.0  # Fallback 가격 (US 기준)
    CACHE_TTL_HOURS = 24

    def __init__(self):
        """Pricing Provider 초기화."""
        self._cache: Dict[str, float] = {}
        self._cache_time: Optional[datetime] = None
        self._pricing_client = None

    @property
    def pricing_client(self):
        """Lazy initialization of pricing client."""
        if self._pricing_client is None:
            # Pricing API는 us-east-1에서만 사용 가능
            boto3_config = _get_boto3_config()
            # SSL 검증 설정 (환경변수 기반)
            verify_ssl = os.getenv("BDP_SSL_VERIFY", "false").lower() != "false"
            from bdp_common.aws_session import get_boto3_client

            self._pricing_client = get_boto3_client(
                "pricing",
                region="us-east-1",
                config=boto3_config,
                verify=verify_ssl,
            )
        return self._pricing_client

    def _is_cache_valid(self) -> bool:
        """캐시 유효성 검사."""
        if self._cache_time is None:
            return False
        return datetime.now() - self._cache_time < timedelta(hours=self.CACHE_TTL_HOURS)

    def get_price_per_tb(self, location: str = "Asia Pacific (Seoul)") -> float:
        """리전별 Athena TB당 가격 조회.

        Args:
            location: AWS 리전 이름 (예: "Asia Pacific (Seoul)")

        Returns:
            TB당 USD 가격
        """
        # 캐시 확인
        if self._is_cache_valid() and location in self._cache:
            logger.debug(f"Using cached Athena price for {location}: ${self._cache[location]}/TB")
            return self._cache[location]

        try:
            # 1차: productFamily 필터 포함 조회
            response = self.pricing_client.get_products(
                ServiceCode="AmazonAthena",
                Filters=[
                    {"Type": "TERM_MATCH", "Field": "location", "Value": location},
                    {"Type": "TERM_MATCH", "Field": "productFamily", "Value": "Data Scanned"},
                ],
                MaxResults=10,
            )

            price_list = response.get("PriceList", [])

            # 필터 결과가 없으면 productFamily 없이 재조회
            if not price_list:
                logger.info(
                    f"No results with productFamily='Data Scanned' for {location}, "
                    f"retrying without productFamily filter"
                )
                response = self.pricing_client.get_products(
                    ServiceCode="AmazonAthena",
                    Filters=[
                        {"Type": "TERM_MATCH", "Field": "location", "Value": location},
                    ],
                    MaxResults=10,
                )
                price_list = response.get("PriceList", [])

                # 디버깅: 실제 productFamily 값 로깅
                for item in price_list:
                    product = json.loads(item)
                    pf = product.get("product", {}).get("productFamily", "N/A")
                    sku = product.get("product", {}).get("sku", "N/A")
                    logger.info(f"[Pricing Debug] sku={sku}, productFamily='{pf}'")

            for price_item in price_list:
                product = json.loads(price_item)
                on_demand = product.get("terms", {}).get("OnDemand", {})
                for sku_data in on_demand.values():
                    for price_details in sku_data.get("priceDimensions", {}).values():
                        price_per_unit = price_details.get("pricePerUnit", {})
                        price = float(price_per_unit.get("USD", 0))
                        if price > 0:
                            self._cache[location] = price
                            self._cache_time = datetime.now()
                            logger.info(
                                f"Fetched Athena price for {location}: ${price}/TB"
                            )
                            return price

            logger.warning(
                f"No price found for {location}, using default: ${self.DEFAULT_PRICE_PER_TB}/TB"
            )

        except Exception as e:
            logger.warning(f"Pricing API 조회 실패, 기본값 사용: {e}")

        return self.DEFAULT_PRICE_PER_TB

    def get_price_for_region(self, region: str) -> float:
        """AWS 리전 코드로 가격 조회.

        Args:
            region: AWS 리전 코드 (예: "ap-northeast-2")

        Returns:
            TB당 USD 가격
        """
        location = REGION_LOCATION_MAP.get(region, "US East (N. Virginia)")
        return self.get_price_per_tb(location)


class MockAthenaPricingProvider(AthenaPricingProvider):
    """Mock Pricing Provider for testing."""

    def __init__(self, price_per_tb: float = 5.0):
        """Mock Provider 초기화.

        Args:
            price_per_tb: Mock 가격 (기본 $5/TB)
        """
        super().__init__()
        self._mock_price = price_per_tb

    def get_price_per_tb(self, location: str = "Asia Pacific (Seoul)") -> float:  # noqa: ARG002
        """Mock 가격 반환."""
        logger.debug(f"[Mock] Returning Athena price: ${self._mock_price}/TB")
        return self._mock_price

    def get_price_for_region(self, region: str) -> float:  # noqa: ARG002
        """Mock 가격 반환."""
        return self._mock_price
