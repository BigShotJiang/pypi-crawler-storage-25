"""
Cost Comparison Data Models.

기간별 비용 비교를 위한 데이터 모델 정의.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class Granularity(str, Enum):
    """비교 기간 단위."""

    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"
    MTD = "mtd"  # Month-to-Date: 월별 누적 비교


@dataclass
class ServiceCostComparison:
    """서비스별 비용 비교 결과."""

    service_name: str
    period1_cost: float  # 첫 번째 기간 비용
    period2_cost: float  # 두 번째 기간 비용
    cost_change: float  # 절대 변화량 (period2 - period1)
    change_percent: float  # 변화율 (%)


@dataclass
class CostComparisonResult:
    """전체 비용 비교 결과."""

    granularity: Granularity
    period1: str  # e.g., "202512"
    period2: str  # e.g., "202601"
    account_id: str
    account_name: str

    # 총계
    total_period1_cost: float
    total_period2_cost: float
    total_change: float
    total_change_percent: float

    # 서비스별 비교 (비용 큰 순 정렬)
    service_comparisons: List[ServiceCostComparison] = field(default_factory=list)

    # 분석
    top_increases: List[ServiceCostComparison] = field(default_factory=list)  # 증가 Top 5
    top_decreases: List[ServiceCostComparison] = field(default_factory=list)  # 감소 Top 5

    # 날짜 범위 (MTD 등에서 실제 비교 범위 표시용)
    period1_range: Optional[str] = None  # e.g., "2026-01-01 ~ 2026-01-08"
    period2_range: Optional[str] = None  # e.g., "2026-02-01 ~ 2026-02-08"
