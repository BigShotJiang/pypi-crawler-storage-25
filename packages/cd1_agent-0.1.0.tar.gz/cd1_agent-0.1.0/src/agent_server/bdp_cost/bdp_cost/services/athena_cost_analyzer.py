"""Athena 비용 분석기.

Workgroup별 Athena 쿼리 비용을 분석하고 project_cd별로 분류합니다.

주요 기능:
- 전체 workgroup 목록 조회 및 비용 분석
- svcprj workgroup의 S3 경로 기반 project_cd 분류
- 전용 workgroup의 이름 기반 project_cd 추출
- project_cd별 총 비용 집계
"""

import logging
import os
import re
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from .athena_cost_models import (
    AthenaCostResult,
    AthenaProjectCost,
    AthenaWorkgroupCost,
)
from .athena_pricing_provider import (
    REGION_LOCATION_MAP,
    AthenaPricingProvider,
    MockAthenaPricingProvider,
)

logger = logging.getLogger(__name__)

# AWS Athena 과금 기준: 1 TB = 1024^4 bytes (이진 단위, AWS 내부 기준)
BYTES_PER_TB = 1024**4

# 공유 workgroup 마커 (svcprj, dftprj)
SHARED_WORKGROUP_MARKERS = ("psvcprj", "pdftprj")

# S3 결과 경로 패턴: s3://{버킷}/athena/{권한코드4자리}{project_cd}/...
# 또는 svcprj 직접 실행: s3://{버킷}/athena/svcprj/...
S3_PATH_PATTERN = re.compile(r"s3://[^/]+/athena/(.{4})([a-zA-Z0-9_-]+)/.*")
S3_SVCPRJ_DIRECT_PATTERN = re.compile(r"s3://[^/]+/athena/svcprj/.*")


class AthenaCostAnalyzer:
    """Athena 비용 분석기.

    Workgroup별 쿼리 비용을 수집하고 project_cd별로 분류합니다.
    """

    def __init__(
        self,
        region: str = "ap-northeast-2",
        use_mock: bool = False,
        athena_client: Optional[Any] = None,
        sts_client: Optional[Any] = None,
    ):
        """분석기 초기화.

        Args:
            region: AWS 리전 코드
            use_mock: Mock 데이터 사용 여부
            athena_client: 테스트용 Athena 클라이언트
            sts_client: 테스트용 STS 클라이언트
        """
        self.region = region
        self.use_mock = use_mock or os.getenv("ATHENA_PROVIDER", "").lower() == "mock"
        self._athena_client = athena_client
        self._sts_client = sts_client

        # Pricing Provider
        if self.use_mock:
            self.pricing_provider = MockAthenaPricingProvider()
        else:
            self.pricing_provider = AthenaPricingProvider()

    @property
    def athena_client(self):
        """Lazy initialization of Athena client."""
        if self._athena_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client

            self._athena_client = get_boto3_client(
                "athena",
                region=self.region,
            )
        return self._athena_client

    @property
    def sts_client(self):
        """Lazy initialization of STS client."""
        if self._sts_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client

            self._sts_client = get_boto3_client(
                "sts",
                region=self.region,
            )
        return self._sts_client

    def _is_shared_workgroup(self, workgroup: str) -> bool:
        """svcprj workgroup 여부 판단.

        Args:
            workgroup: Workgroup 이름

        Returns:
            True if svcprj workgroup
        """
        wg_lower = workgroup.lower()
        return any(marker in wg_lower for marker in SHARED_WORKGROUP_MARKERS)

    def _extract_project_from_workgroup(self, workgroup: str) -> Optional[str]:
        """Workgroup 이름에서 project_cd 추출.

        패턴: split('-')[-1] = {권한코드4자리}{project_cd}

        Args:
            workgroup: Workgroup 이름

        Returns:
            project_cd 또는 None
        """
        if self._is_shared_workgroup(workgroup):
            return None

        suffix = workgroup.split("-")[-1]
        # 앞 4자리는 권한코드, 나머지가 project_cd
        if len(suffix) > 4:
            return suffix[4:]
        return None

    def _extract_project_from_s3_path(self, s3_path: str) -> str:
        """S3 결과 경로에서 project_cd 추출.

        패턴: s3://{버킷}/athena/{권한코드4자리}{project_cd}/...
        svcprj 직접 실행: s3://{버킷}/athena/svcprj/... → 'svcprj' 반환

        Args:
            s3_path: S3 결과 경로

        Returns:
            project_cd 또는 'svcprj' (미분류)
        """
        if not s3_path:
            return "svcprj"  # 경로 없음 → svcprj로 집계

        # svcprj 직접 실행 확인 (콘솔에서 직접 실행)
        if S3_SVCPRJ_DIRECT_PATTERN.match(s3_path):
            return "svcprj"  # svcprj 자체 비용으로 집계

        match = S3_PATH_PATTERN.match(s3_path)
        if match:
            # 공유 workgroup 직접 실행 경로 확인 (psvcprj, pdftprj 등)
            full_segment = (match.group(1) + match.group(2)).lower()
            for marker in SHARED_WORKGROUP_MARKERS:
                if marker in full_segment:
                    return marker[1:]  # "psvcprj"→"svcprj", "pdftprj"→"dftprj"
            return match.group(2)  # project_cd

        return "svcprj"  # 패턴 불일치 → svcprj로 집계

    def _list_all_workgroups(self) -> List[str]:
        """전체 workgroup 목록 조회."""
        workgroups = []
        try:
            assert self.athena_client is not None
            next_token = None
            while True:
                kwargs = {}
                if next_token:
                    kwargs["NextToken"] = next_token

                response = self.athena_client.list_work_groups(**kwargs)

                for wg in response.get("WorkGroups", []):
                    name = wg.get("Name", "")
                    # primary workgroup 제외
                    if name and name.lower() != "primary":
                        workgroups.append(name)

                next_token = response.get("NextToken")
                if not next_token:
                    break

        except Exception as e:
            logger.error(f"Failed to list workgroups: {e}")

        return workgroups

    def _fetch_queries_for_workgroup(
        self,
        workgroup: str,
        start_time: datetime,
        end_time: datetime,
    ) -> List[Dict[str, Any]]:
        """Workgroup의 쿼리 실행 정보 조회.

        Args:
            workgroup: Workgroup 이름
            start_time: 시작 시간
            end_time: 종료 시간

        Returns:
            쿼리 실행 정보 리스트
        """
        queries = []
        try:
            assert self.athena_client is not None
            paginator = self.athena_client.get_paginator("list_query_executions")

            past_window_count = 0
            for page in paginator.paginate(WorkGroup=workgroup):
                query_ids = page.get("QueryExecutionIds", [])

                if not query_ids:
                    continue

                # 배치로 쿼리 상세 조회 (최대 50개)
                for i in range(0, len(query_ids), 50):
                    batch_ids = query_ids[i : i + 50]
                    batch_response = self.athena_client.batch_get_query_execution(
                        QueryExecutionIds=batch_ids
                    )

                    for execution in batch_response.get("QueryExecutions", []):
                        status = execution.get("Status", {})
                        submit_time = status.get("SubmissionDateTime")

                        # 기간 필터링: submit_time 없으면 제외
                        if not submit_time:
                            continue

                        if submit_time > end_time:
                            continue

                        if submit_time < start_time:
                            past_window_count += 1
                            continue

                        queries.append(execution)

                # list_query_executions는 최신순 반환 — 시간 범위를 벗어난
                # 쿼리가 연속으로 나오면 이후 페이지도 범위 밖이므로 조기 종료
                if past_window_count > 0:
                    logger.debug(
                        f"Workgroup {workgroup}: stopping pagination, "
                        f"reached queries before {start_time}"
                    )
                    break

        except Exception as e:
            logger.error(f"Failed to fetch queries for workgroup {workgroup}: {e}")

        return queries

    def _get_account_info(self) -> tuple:
        """계정 정보 조회.

        Returns:
            (account_id, account_name) 튜플
        """
        if self.use_mock:
            return ("123456789012", "mock-account")

        try:
            assert self.sts_client is not None
            response = self.sts_client.get_caller_identity()
            account_id = response.get("Account", "unknown")
            # account_name은 Organizations API가 필요하므로 account_id 사용
            return (account_id, account_id)
        except Exception as e:
            logger.error(f"Failed to get account info: {e}")
            return ("unknown", "unknown")

    def analyze(
        self,
        days: int = 30,
        workgroups: Optional[List[str]] = None,
        end_days_ago: int = 0,
    ) -> AthenaCostResult:
        """Athena 비용 분석 수행.

        Args:
            days: 분석 기간 (일)
            workgroups: 대상 workgroup 목록 (None이면 전체)
            end_days_ago: 끝 시점을 N일 전으로 설정 (디버깅용, 기본 0=오늘)

        Returns:
            AthenaCostResult
        """
        if self.use_mock:
            return self._generate_mock_result(days)

        end_time = datetime.now(KST) - timedelta(days=end_days_ago)
        start_time = end_time - timedelta(days=days)

        # 계정 정보
        account_id, account_name = self._get_account_info()

        # 가격 정보 조회 (한 번만)
        location = REGION_LOCATION_MAP.get(self.region, "US East (N. Virginia)")
        price_per_tb = self.pricing_provider.get_price_per_tb(location)
        logger.info(f"Using Athena price: ${price_per_tb}/TB for {location}")

        # Workgroup 목록
        if workgroups is None:
            workgroups = self._list_all_workgroups()

        logger.info(f"Analyzing {len(workgroups)} workgroups for {days} days")

        # Workgroup별 비용 수집
        workgroup_costs: List[AthenaWorkgroupCost] = []
        project_costs_map: Dict[str, Dict[str, float]] = defaultdict(
            lambda: {"dedicated": 0.0, "shared": 0.0, "queries": 0, "data_tb": 0.0}
        )

        total_queries = 0
        total_data_scanned_bytes = 0

        for wg in workgroups:
            queries = self._fetch_queries_for_workgroup(wg, start_time, end_time)

            wg_total_queries = 0
            wg_success_queries = 0
            wg_failed_queries = 0
            wg_data_scanned_bytes = 0
            wg_project_breakdown: Dict[str, float] = defaultdict(float)

            is_shared = self._is_shared_workgroup(wg)
            wg_project_cd = self._extract_project_from_workgroup(wg)

            for query in queries:
                wg_total_queries += 1

                status = query.get("Status", {})
                state = status.get("State", "")

                if state == "SUCCEEDED":
                    wg_success_queries += 1
                elif state in ["FAILED", "CANCELLED"]:
                    wg_failed_queries += 1

                # FAILED 쿼리는 과금되지 않으므로 비용 계산 제외
                if state == "FAILED":
                    continue

                # Data scanned (최소 과금 단위: 10MB)
                stats = query.get("Statistics", {})
                data_scanned = stats.get("DataScannedInBytes", 0)
                if data_scanned > 0:
                    data_scanned = max(data_scanned, 10 * 1024**2)  # 최소 10MB
                wg_data_scanned_bytes += data_scanned

                query_data_tb = data_scanned / BYTES_PER_TB
                query_cost = query_data_tb * price_per_tb

                if is_shared:
                    # svcprj: S3 경로에서 project_cd 추출
                    result_config = query.get("ResultConfiguration", {})
                    output_location = result_config.get("OutputLocation", "")
                    project_cd = self._extract_project_from_s3_path(output_location)
                    wg_project_breakdown[project_cd] += query_cost

                    # project별 비용 집계
                    project_costs_map[project_cd]["shared"] += query_cost
                    project_costs_map[project_cd]["queries"] += 1
                    project_costs_map[project_cd]["data_tb"] += query_data_tb
                else:
                    # 전용 workgroup
                    if wg_project_cd:
                        project_costs_map[wg_project_cd]["dedicated"] += query_cost
                        project_costs_map[wg_project_cd]["queries"] += 1
                        project_costs_map[wg_project_cd]["data_tb"] += query_data_tb

            # Workgroup 비용 정보 생성
            wg_data_tb = wg_data_scanned_bytes / BYTES_PER_TB
            wg_cost = wg_data_tb * price_per_tb

            workgroup_costs.append(
                AthenaWorkgroupCost(
                    workgroup_name=wg,
                    is_shared=is_shared,
                    total_queries=wg_total_queries,
                    successful_queries=wg_success_queries,
                    failed_queries=wg_failed_queries,
                    total_data_scanned_bytes=wg_data_scanned_bytes,
                    total_data_scanned_tb=wg_data_tb,
                    estimated_cost_usd=wg_cost,
                    project_cd=wg_project_cd,
                    project_breakdown=dict(wg_project_breakdown) if is_shared else {},
                )
            )

            total_queries += wg_total_queries
            total_data_scanned_bytes += wg_data_scanned_bytes

        # Project별 비용 정보 생성
        project_costs: List[AthenaProjectCost] = []
        for project_cd, costs in project_costs_map.items():
            project_costs.append(
                AthenaProjectCost(
                    project_cd=project_cd,
                    dedicated_cost=costs["dedicated"],
                    shared_cost=costs["shared"],
                    total_queries=int(costs["queries"]),
                    total_data_scanned_tb=costs["data_tb"],
                )
            )

        # 비용 순으로 정렬
        project_costs.sort(key=lambda x: x.total_cost, reverse=True)
        workgroup_costs.sort(key=lambda x: x.estimated_cost_usd, reverse=True)

        total_data_tb = total_data_scanned_bytes / BYTES_PER_TB
        total_cost = total_data_tb * price_per_tb

        return AthenaCostResult(
            account_id=account_id,
            account_name=account_name,
            region=self.region,
            period_start=start_time,
            period_end=end_time,
            total_queries=total_queries,
            total_data_scanned_tb=total_data_tb,
            total_cost_usd=total_cost,
            price_per_tb=price_per_tb,
            workgroup_costs=workgroup_costs,
            project_costs=project_costs,
        )

    def _generate_mock_result(self, days: int) -> AthenaCostResult:
        """Mock 결과 생성.

        Args:
            days: 분석 기간

        Returns:
            Mock AthenaCostResult
        """
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        # Mock workgroup 데이터
        workgroup_costs = [
            AthenaWorkgroupCost(
                workgroup_name="bdp-prod-psvcprj",
                is_shared=True,
                total_queries=150,
                successful_queries=145,
                failed_queries=5,
                total_data_scanned_bytes=500 * BYTES_PER_TB,  # 500 TB
                total_data_scanned_tb=500.0,
                estimated_cost_usd=2500.0,
                project_cd=None,
                project_breakdown={
                    "projectA": 1000.0,
                    "projectB": 800.0,
                    "projectC": 500.0,
                    "svcprj": 200.0,  # 미분류
                },
            ),
            AthenaWorkgroupCost(
                workgroup_name="bdp-prod-pl2wprojectA",
                is_shared=False,
                total_queries=80,
                successful_queries=78,
                failed_queries=2,
                total_data_scanned_bytes=200 * BYTES_PER_TB,  # 200 TB
                total_data_scanned_tb=200.0,
                estimated_cost_usd=1000.0,
                project_cd="projectA",
                project_breakdown={},
            ),
            AthenaWorkgroupCost(
                workgroup_name="bdp-prod-ab3xprojectB",
                is_shared=False,
                total_queries=50,
                successful_queries=49,
                failed_queries=1,
                total_data_scanned_bytes=100 * BYTES_PER_TB,  # 100 TB
                total_data_scanned_tb=100.0,
                estimated_cost_usd=500.0,
                project_cd="projectB",
                project_breakdown={},
            ),
        ]

        # Mock project 데이터
        project_costs = [
            AthenaProjectCost(
                project_cd="projectA",
                dedicated_cost=1000.0,
                shared_cost=1000.0,
                total_queries=120,
                total_data_scanned_tb=400.0,
            ),
            AthenaProjectCost(
                project_cd="projectB",
                dedicated_cost=500.0,
                shared_cost=800.0,
                total_queries=90,
                total_data_scanned_tb=260.0,
            ),
            AthenaProjectCost(
                project_cd="projectC",
                dedicated_cost=0.0,
                shared_cost=500.0,
                total_queries=40,
                total_data_scanned_tb=100.0,
            ),
            AthenaProjectCost(
                project_cd="svcprj",
                dedicated_cost=0.0,
                shared_cost=200.0,
                total_queries=30,
                total_data_scanned_tb=40.0,
            ),
        ]

        return AthenaCostResult(
            account_id="123456789012",
            account_name="mock-bdp-account",
            region=self.region,
            period_start=start_time,
            period_end=end_time,
            total_queries=280,
            total_data_scanned_tb=800.0,
            total_cost_usd=4000.0,
            price_per_tb=5.0,
            workgroup_costs=workgroup_costs,
            project_costs=project_costs,
        )
