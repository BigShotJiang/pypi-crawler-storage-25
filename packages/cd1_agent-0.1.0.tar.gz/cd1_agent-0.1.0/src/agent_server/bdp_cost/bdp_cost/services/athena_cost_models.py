"""Athena 비용 분석 데이터 모델.

Workgroup별, project_cd별 Athena 비용을 추적하고 분석하기 위한 데이터클래스 정의.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional


@dataclass
class AthenaWorkgroupCost:
    """워크그룹별 Athena 비용 정보."""

    workgroup_name: str
    is_shared: bool  # True if svcprj workgroup
    total_queries: int
    successful_queries: int
    failed_queries: int
    total_data_scanned_bytes: int
    total_data_scanned_tb: float
    estimated_cost_usd: float
    project_cd: Optional[str] = None  # 전용 workgroup의 경우
    project_breakdown: Dict[str, float] = field(
        default_factory=dict
    )  # svcprj의 경우 {project_cd: cost}


@dataclass
class AthenaProjectCost:
    """project_cd별 Athena 비용 정보."""

    project_cd: str
    dedicated_cost: float  # 전용 workgroup 비용
    shared_cost: float  # svcprj에서의 비용
    total_queries: int = 0
    total_data_scanned_tb: float = 0.0

    @property
    def total_cost(self) -> float:
        """총 비용 (전용 + 공유)."""
        return self.dedicated_cost + self.shared_cost


@dataclass
class AthenaCostResult:
    """Athena 비용 분석 결과."""

    account_id: str
    account_name: str
    region: str
    period_start: datetime
    period_end: datetime
    total_queries: int
    total_data_scanned_tb: float
    total_cost_usd: float
    price_per_tb: float
    workgroup_costs: List[AthenaWorkgroupCost]
    project_costs: List[AthenaProjectCost]  # 'svcprj' 자체도 project_cd로 포함됨
