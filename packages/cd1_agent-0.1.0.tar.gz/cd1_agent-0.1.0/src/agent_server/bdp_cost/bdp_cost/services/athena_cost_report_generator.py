"""
Athena Cost HTML Report Generator.

Athena 비용 분석 결과를 HTML 리포트로 생성합니다.
Material Design 3 기반 디자인 시스템 적용.
"""

import logging
from datetime import datetime

from src.agent_server.bdp_common.eventbridge.publisher import get_environment_account_name
from src.agent_server.bdp_common.reports.styles import MD3_COLORS
from .athena_cost_models import AthenaCostResult

logger = logging.getLogger(__name__)


class AthenaCostHTMLReportGenerator:
    """Athena 비용 HTML 리포트 생성기."""

    def __init__(self, currency: str = "USD"):
        """리포트 생성기 초기화.

        Args:
            currency: 통화 단위 (USD, KRW)
        """
        self.currency = currency

    def generate(self, result: AthenaCostResult) -> str:
        """분석 결과를 HTML 리포트로 생성.

        Args:
            result: Athena 비용 분석 결과

        Returns:
            HTML 문자열
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        env_account_name = get_environment_account_name()
        period_display = (
            f"{result.period_start.strftime('%Y-%m-%d')} ~ "
            f"{result.period_end.strftime('%Y-%m-%d')}"
        )

        # Workgroup 테이블
        workgroup_rows = self._build_workgroup_rows(result)

        # Project 테이블
        project_rows = self._build_project_rows(result)

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Athena 비용 분석 리포트</title>
    <style>
        @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');

        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background-color: {MD3_COLORS['surface_variant']};
            color: {MD3_COLORS['on_surface']};
            line-height: 1.6;
            padding: 20px;
        }}

        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: {MD3_COLORS['surface']};
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .header {{
            background: {MD3_COLORS['surface']};
            padding: 24px;
            border-bottom: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .header h1 {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: {MD3_COLORS['on_surface']};
        }}

        .header p {{
            font-size: 0.95rem;
            color: {MD3_COLORS['on_surface']};
        }}

        .header .meta {{
            font-size: 0.85rem;
            color: {MD3_COLORS['on_surface_variant']};
            margin-top: 12px;
        }}

        .summary-cards {{
            display: flex;
            gap: 16px;
            padding: 20px;
            background: {MD3_COLORS['surface_variant']};
            flex-wrap: wrap;
        }}

        .summary-card {{
            flex: 1;
            min-width: 150px;
            background: {MD3_COLORS['surface']};
            padding: 16px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .summary-card .label {{
            color: {MD3_COLORS['on_surface_variant']};
            font-size: 0.85rem;
            margin-bottom: 8px;
        }}

        .summary-card .value {{
            font-size: 1.25rem;
            font-weight: 700;
            color: {MD3_COLORS['on_surface']};
        }}

        .summary-card.highlight {{
            background: {MD3_COLORS['primary_container']};
            border-color: {MD3_COLORS['primary']};
        }}

        .summary-card.highlight .value {{
            color: {MD3_COLORS['primary']};
        }}

        .section {{
            padding: 20px;
            border-top: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .section-title {{
            font-size: 1rem;
            font-weight: 600;
            color: {MD3_COLORS['on_surface']};
            margin-bottom: 16px;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        th, td {{
            padding: 12px 10px;
            text-align: right;
            border-bottom: 1px solid {MD3_COLORS['outline_variant']};
            font-size: 0.9rem;
        }}

        th {{
            background: {MD3_COLORS['surface_variant']};
            font-weight: 600;
            color: {MD3_COLORS['on_surface_variant']};
        }}

        th:first-child, td:first-child {{
            text-align: left;
        }}

        td.name {{
            font-weight: 500;
            color: {MD3_COLORS['on_surface']};
        }}

        td.shared {{
            color: {MD3_COLORS['tertiary']};
        }}

        td.dedicated {{
            color: {MD3_COLORS['primary']};
        }}

        .badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }}

        .badge.shared {{
            background: {MD3_COLORS['tertiary_container']};
            color: {MD3_COLORS['on_tertiary_container']};
        }}

        .badge.dedicated {{
            background: {MD3_COLORS['primary_container']};
            color: {MD3_COLORS['on_primary_container']};
        }}

        .footer {{
            padding: 16px 20px;
            background: {MD3_COLORS['surface_variant']};
            text-align: center;
            font-size: 0.8rem;
            color: {MD3_COLORS['on_surface_variant']};
        }}

        .note {{
            padding: 12px 20px;
            background: {MD3_COLORS['secondary_container']};
            border-left: 4px solid {MD3_COLORS['secondary']};
            font-size: 0.85rem;
            color: {MD3_COLORS['on_secondary_container']};
        }}

        @media (max-width: 600px) {{
            .summary-cards {{
                flex-direction: column;
            }}

            th, td {{
                padding: 10px 6px;
                font-size: 0.85rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>Athena 비용 분석 리포트</h1>
            <p>{period_display}</p>
            <div class="meta">
                환경: {env_account_name} | 리전: {result.region} | 생성: {timestamp}
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="summary-card">
                <div class="label">총 쿼리 수</div>
                <div class="value">{result.total_queries:,}</div>
            </div>
            <div class="summary-card">
                <div class="label">총 스캔 데이터</div>
                <div class="value">{self._format_tb(result.total_data_scanned_tb)}</div>
            </div>
            <div class="summary-card highlight">
                <div class="label">총 비용</div>
                <div class="value">{self._format_cost(result.total_cost_usd)}</div>
            </div>
            <div class="summary-card">
                <div class="label">TB당 요금</div>
                <div class="value">${result.price_per_tb:.2f}</div>
            </div>
        </div>

        <!-- Note -->
        <div class="note">
            Athena 비용 = 스캔 데이터(TB) x TB당 요금 |
            svcprj 워크그룹의 경우 S3 결과 경로에서 project_cd를 추출합니다.
        </div>

        <!-- Project Table -->
        <div class="section">
            <div class="section-title">Project별 비용</div>
            <table>
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>전용 비용</th>
                        <th>공유 비용</th>
                        <th>총 비용</th>
                        <th>쿼리 수</th>
                        <th>스캔 데이터</th>
                    </tr>
                </thead>
                <tbody>
                    {project_rows}
                </tbody>
            </table>
        </div>

        <!-- Workgroup Table -->
        <div class="section">
            <div class="section-title">Workgroup별 비용</div>
            <table>
                <thead>
                    <tr>
                        <th>Workgroup</th>
                        <th>유형</th>
                        <th>쿼리 수</th>
                        <th>성공/실패</th>
                        <th>스캔 데이터</th>
                        <th>비용</th>
                    </tr>
                </thead>
                <tbody>
                    {workgroup_rows}
                </tbody>
            </table>
        </div>

        <!-- Footer -->
        <div class="footer">
            BDP Cost Agent | CD1 Agent System
        </div>
    </div>
</body>
</html>"""

        return html

    def _build_workgroup_rows(self, result: AthenaCostResult) -> str:
        """Workgroup 테이블 행 생성."""
        rows = []

        for wg in result.workgroup_costs:
            wg_type = "공유" if wg.is_shared else "전용"
            badge_class = "shared" if wg.is_shared else "dedicated"

            row = f"""<tr>
                <td class="name">{wg.workgroup_name}</td>
                <td><span class="badge {badge_class}">{wg_type}</span></td>
                <td>{wg.total_queries:,}</td>
                <td>{wg.successful_queries:,} / {wg.failed_queries:,}</td>
                <td>{self._format_tb(wg.total_data_scanned_tb)}</td>
                <td>{self._format_cost(wg.estimated_cost_usd)}</td>
            </tr>"""
            rows.append(row)

        if not rows:
            rows.append(
                '<tr><td colspan="6" style="text-align: center;">데이터 없음</td></tr>'
            )

        return "\n".join(rows)

    def _build_project_rows(self, result: AthenaCostResult) -> str:
        """Project 테이블 행 생성."""
        rows = []

        for proj in result.project_costs:
            # svcprj 자체는 특별 표시
            name_display = proj.project_cd
            if proj.project_cd == "svcprj":
                name_display = f"{proj.project_cd} (미분류)"

            row = f"""<tr>
                <td class="name">{name_display}</td>
                <td class="dedicated">{self._format_cost(proj.dedicated_cost)}</td>
                <td class="shared">{self._format_cost(proj.shared_cost)}</td>
                <td><strong>{self._format_cost(proj.total_cost)}</strong></td>
                <td>{proj.total_queries:,}</td>
                <td>{self._format_tb(proj.total_data_scanned_tb)}</td>
            </tr>"""
            rows.append(row)

        if not rows:
            rows.append(
                '<tr><td colspan="6" style="text-align: center;">데이터 없음</td></tr>'
            )

        return "\n".join(rows)

    def _format_cost(self, cost: float) -> str:
        """비용을 읽기 쉬운 형식으로 포맷팅."""
        if self.currency == "KRW":
            if cost >= 100_000_000:  # 1억 이상
                return f"{cost / 100_000_000:.2f}억원"
            elif cost >= 10_000:  # 1만 이상
                return f"{cost / 10_000:.2f}만원"
            else:
                return f"{cost:,.2f}원"
        else:  # USD
            return f"${cost:,.2f}"

    def _format_tb(self, tb: float) -> str:
        """TB를 읽기 쉬운 형식으로 포맷팅."""
        if tb >= 1000:  # PB 단위
            return f"{tb / 1000:.2f} PB"
        elif tb >= 1:
            return f"{tb:.2f} TB"
        elif tb >= 0.001:  # GB 단위
            return f"{tb * 1024:.2f} GB"
        else:  # MB 단위
            return f"{tb * 1024 * 1024:.2f} MB"


def generate_athena_cost_report(result: AthenaCostResult, currency: str = "USD") -> str:
    """Athena 비용 분석 결과를 HTML 리포트로 생성하는 헬퍼 함수.

    Args:
        result: Athena 비용 분석 결과
        currency: 통화 단위

    Returns:
        HTML 문자열
    """
    generator = AthenaCostHTMLReportGenerator(currency=currency)
    return generator.generate(result)
