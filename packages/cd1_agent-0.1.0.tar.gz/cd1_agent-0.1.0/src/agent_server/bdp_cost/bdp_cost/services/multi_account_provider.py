"""
Multi-Account Cost Explorer Provider.

STS AssumeRole based multi-account Cost Explorer access for cost drift detection.
"""

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


def _get_boto3_config() -> Optional[Any]:
    """Get boto3 Config with proxy settings from environment variables.

    Environment variables:
        BDP_HTTP_PROXY: HTTP proxy URL (e.g., http://proxy.example.com:8080)
        BDP_HTTPS_PROXY: HTTPS proxy URL (e.g., http://proxy.example.com:8080)

    Falls back to standard HTTP_PROXY/HTTPS_PROXY if BDP_ prefixed vars not set.

    Returns:
        botocore.config.Config with proxy settings, or None if no proxy configured
    """
    # 디버깅: 환경변수 값 확인
    logger.info(f"Proxy env check: BDP_HTTP_PROXY={os.getenv('BDP_HTTP_PROXY')}")
    logger.info(f"Proxy env check: BDP_HTTPS_PROXY={os.getenv('BDP_HTTPS_PROXY')}")
    logger.info(f"Proxy env check: HTTP_PROXY={os.getenv('HTTP_PROXY')}")
    logger.info(f"Proxy env check: HTTPS_PROXY={os.getenv('HTTPS_PROXY')}")

    http_proxy = os.getenv("BDP_HTTP_PROXY") or os.getenv("HTTP_PROXY")
    https_proxy = os.getenv("BDP_HTTPS_PROXY") or os.getenv("HTTPS_PROXY")

    if http_proxy or https_proxy:
        from botocore.config import Config

        proxies = {}
        if http_proxy:
            proxies["http"] = http_proxy
        if https_proxy:
            proxies["https"] = https_proxy

        logger.info(f"Using proxy configuration: {proxies}")
        return Config(proxies=proxies)

    logger.warning("No proxy configuration found")
    return None


@dataclass
class AccountConfig:
    """AWS Account configuration for Cost Explorer access."""

    account_id: str
    account_name: str
    role_arn: Optional[str] = None  # None = use current credentials
    region: str = "us-east-1"
    external_id: Optional[str] = None


@dataclass
class ServiceCostData:
    """Service cost data with historical values."""

    service_name: str
    account_id: str
    account_name: str
    current_cost: float
    historical_costs: List[float]
    timestamps: List[str]
    currency: str = "USD"


class BaseMultiAccountProvider(ABC):
    """Abstract base class for multi-account Cost Explorer providers."""

    @abstractmethod
    def get_cost_data(self, days: int = 14) -> Dict[str, List[ServiceCostData]]:
        """Get service-level cost data from all accounts.

        Args:
            days: Number of days of historical data

        Returns:
            Dict mapping account_id to list of ServiceCostData
        """
        pass

    @abstractmethod
    def get_accounts(self) -> List[AccountConfig]:
        """Get list of configured accounts."""
        pass

    @abstractmethod
    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: List[str],
    ) -> Dict[str, Dict[str, float]]:
        """기간별 서비스 비용 조회.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            {period: {service_name: cost}}
        """
        pass

    @abstractmethod
    def get_date_ranges(
        self,
        granularity: str,
        periods: List[str],
    ) -> List[str]:
        """기간의 실제 날짜 범위 반환.

        Args:
            granularity: daily, weekly, monthly, yearly, mtd
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            날짜 범위 문자열 목록 (e.g., ["2026-01-01 ~ 2026-01-08", ...])
        """
        pass


class MultiAccountCostExplorerProvider(BaseMultiAccountProvider):
    """
    STS AssumeRole based Multi-Account Cost Explorer Provider.

    Accesses Cost Explorer API across multiple AWS accounts using
    STS AssumeRole for cross-account access.

    Environment Variables:
        BDP_ACCOUNT_1_ID: Primary account ID
        BDP_ACCOUNT_1_NAME: Primary account name
        BDP_ACCOUNT_1_ROLE_ARN: Role ARN (empty for current credentials)

        BDP_ACCOUNT_2_ID: Secondary account ID
        BDP_ACCOUNT_2_NAME: Secondary account name
        BDP_ACCOUNT_2_ROLE_ARN: Role ARN for cross-account access
    """

    def __init__(
        self,
        accounts: Optional[List[AccountConfig]] = None,
        region: str = "us-east-1",
    ):
        """Initialize multi-account provider.

        Args:
            accounts: List of account configurations. If None, loads from env.
            region: AWS region for Cost Explorer (default: us-east-1)
        """
        self.region = region
        self.accounts = accounts or self._load_accounts_from_env()
        self._sessions: Dict[str, Any] = {}

        logger.info(
            f"MultiAccountCostExplorerProvider initialized with "
            f"{len(self.accounts)} accounts"
        )

    def _load_accounts_from_env(self) -> List[AccountConfig]:
        """Load account configurations from environment variables."""
        accounts = []

        # Support up to 10 accounts
        for i in range(1, 11):
            account_id = os.getenv(f"BDP_ACCOUNT_{i}_ID")
            if not account_id:
                continue

            account_name = os.getenv(f"BDP_ACCOUNT_{i}_NAME", "bdp_cost_agent")
            role_arn = os.getenv(f"BDP_ACCOUNT_{i}_ROLE_ARN") or None
            external_id = os.getenv(f"BDP_ACCOUNT_{i}_EXTERNAL_ID")
            region = os.getenv(f"BDP_ACCOUNT_{i}_REGION", self.region)

            accounts.append(
                AccountConfig(
                    account_id=account_id,
                    account_name=account_name,
                    role_arn=role_arn,
                    region=region,
                    external_id=external_id,
                )
            )

        if not accounts:
            logger.warning("No accounts configured, using default mock account")
            accounts.append(
                AccountConfig(
                    account_id="123456789012",
                    account_name="default",
                    role_arn=None,
                )
            )

        return accounts

    def get_accounts(self) -> List[AccountConfig]:
        """Get list of configured accounts."""
        return self.accounts.copy()

    def _get_session(self, account: AccountConfig) -> Any:
        """Get or create boto3 session for account.

        Args:
            account: Account configuration

        Returns:
            boto3 Session for the account
        """
        if account.account_id in self._sessions:
            return self._sessions[account.account_id]

        if account.role_arn:
            # Cross-account access via STS AssumeRole
            session = self._assume_role(account)
        else:
            # Use current credentials (AssumeRole 적용)
            from bdp_common.aws_session import get_boto3_session

            session = get_boto3_session(region=account.region)

        self._sessions[account.account_id] = session
        return session

    def _assume_role(self, account: AccountConfig) -> Any:
        """Assume IAM role for cross-account access.

        Args:
            account: Account configuration with role_arn

        Returns:
            boto3 Session with assumed role credentials
        """
        from bdp_common.aws_session import get_boto3_client

        boto3_config = _get_boto3_config()
        sts_client = get_boto3_client("sts", region=account.region, config=boto3_config)

        assume_role_params: Dict[str, Any] = {
            "RoleArn": account.role_arn,
            "RoleSessionName": f"bdp-cost-{account.account_id}",
            "DurationSeconds": 3600,  # 1 hour
        }

        if account.external_id:
            assume_role_params["ExternalId"] = account.external_id

        logger.info(f"Assuming role {account.role_arn} for account {account.account_id}")

        response = sts_client.assume_role(**assume_role_params)
        credentials = response["Credentials"]

        import boto3

        return boto3.Session(
            aws_access_key_id=credentials["AccessKeyId"],
            aws_secret_access_key=credentials["SecretAccessKey"],
            aws_session_token=credentials["SessionToken"],
            region_name=account.region,
        )

    def get_cost_data(self, days: int = 14) -> Dict[str, List[ServiceCostData]]:
        """Get service-level cost data from all configured accounts.

        Args:
            days: Number of days of historical data

        Returns:
            Dict mapping account_id to list of ServiceCostData
        """
        result: Dict[str, List[ServiceCostData]] = {}

        for account in self.accounts:
            try:
                account_data = self._get_account_cost_data(account, days)
                result[account.account_id] = account_data
                logger.info(
                    f"Retrieved {len(account_data)} services from "
                    f"account {account.account_name}"
                )
            except Exception as e:
                logger.error(
                    f"Failed to get cost data for account {account.account_name}: {e}"
                )
                result[account.account_id] = []

        return result

    def _get_account_cost_data(
        self, account: AccountConfig, days: int
    ) -> List[ServiceCostData]:
        """Get cost data for a single account.

        Args:
            account: Account configuration
            days: Number of days of historical data

        Returns:
            List of ServiceCostData for each service
        """
        session = self._get_session(account)
        boto3_config = _get_boto3_config()
        ce_client = session.client("ce", region_name="us-east-1", config=boto3_config, verify=False)

        end_date = get_kst_now()
        start_date = end_date - timedelta(days=days)

        response = ce_client.get_cost_and_usage(
            TimePeriod={
                "Start": start_date.strftime("%Y-%m-%d"),
                "End": end_date.strftime("%Y-%m-%d"),
            },
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
            GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}],
        )

        # Aggregate by service
        service_data: Dict[str, Dict[str, Any]] = {}

        for period in response.get("ResultsByTime", []):
            timestamp = period["TimePeriod"]["Start"]

            for group in period.get("Groups", []):
                service_name = group["Keys"][0] if group["Keys"] else "Unknown"
                cost = float(
                    group.get("Metrics", {})
                    .get("UnblendedCost", {})
                    .get("Amount", 0)
                )

                if service_name not in service_data:
                    service_data[service_name] = {
                        "historical_costs": [],
                        "timestamps": [],
                    }

                service_data[service_name]["historical_costs"].append(cost)
                service_data[service_name]["timestamps"].append(timestamp)

        # Convert to ServiceCostData
        result = []
        for service_name, data in service_data.items():
            costs = data["historical_costs"]
            current_cost = costs[-1] if costs else 0.0

            result.append(
                ServiceCostData(
                    service_name=service_name,
                    account_id=account.account_id,
                    account_name=account.account_name,
                    current_cost=current_cost,
                    historical_costs=costs,
                    timestamps=data["timestamps"],
                )
            )

        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: List[str],
    ) -> Dict[str, Dict[str, float]]:
        """기간별 서비스 비용 조회.

        모든 계정의 비용을 합산하여 반환합니다.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            {period: {service_name: cost}}
        """
        result: Dict[str, Dict[str, float]] = {}

        for account in self.accounts:
            try:
                session = self._get_session(account)
                boto3_config = _get_boto3_config()
                ce_client = session.client(
                    "ce", region_name="us-east-1", config=boto3_config, verify=False
                )

                for period in periods:
                    start_date, end_date = self._period_to_date_range(granularity, period)

                    # API granularity 결정 (mtd는 일별 데이터로 조회)
                    api_granularity = "MONTHLY" if granularity in ("monthly", "yearly") else "DAILY"

                    response = ce_client.get_cost_and_usage(
                        TimePeriod={
                            "Start": start_date,
                            "End": end_date,
                        },
                        Granularity=api_granularity,
                        Metrics=["UnblendedCost"],
                        GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}],
                    )

                    # 기간별 비용 합산
                    if period not in result:
                        result[period] = {}

                    for time_period in response.get("ResultsByTime", []):
                        for group in time_period.get("Groups", []):
                            service_name = group["Keys"][0] if group["Keys"] else "Unknown"
                            cost = float(
                                group.get("Metrics", {})
                                .get("UnblendedCost", {})
                                .get("Amount", 0)
                            )

                            if service_name not in result[period]:
                                result[period][service_name] = 0.0
                            result[period][service_name] += cost

                logger.info(
                    f"Retrieved period cost data for account {account.account_name}"
                )

            except Exception as e:
                logger.error(
                    f"Failed to get period cost data for account {account.account_name}: {e}"
                )

        return result

    def _period_to_date_range(self, granularity: str, period: str) -> Tuple[str, str]:
        """Period 문자열을 날짜 범위로 변환.

        Args:
            granularity: daily, weekly, monthly, yearly
            period: 기간 문자열

        Returns:
            (start_date, end_date) 튜플 (YYYY-MM-DD 형식)
        """
        if granularity == "daily":
            # "20260102" → ("2026-01-02", "2026-01-03")
            dt = datetime.strptime(period, "%Y%m%d")
            end_dt = dt + timedelta(days=1)
            return (dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))

        elif granularity == "weekly":
            # "2026W02" → 해당 주 월~일 (ISO week 기준)
            year = int(period[:4])
            week = int(period[5:])
            # ISO week: 월요일 시작
            first_day = datetime.strptime(f"{year}-W{week:02d}-1", "%Y-W%W-%w")
            last_day = first_day + timedelta(days=7)
            return (first_day.strftime("%Y-%m-%d"), last_day.strftime("%Y-%m-%d"))

        elif granularity == "monthly":
            # "202601" → ("2026-01-01", "2026-02-01")
            dt = datetime.strptime(period, "%Y%m")
            # 다음 달 첫날
            if dt.month == 12:
                next_month = dt.replace(year=dt.year + 1, month=1, day=1)
            else:
                next_month = dt.replace(month=dt.month + 1, day=1)
            return (dt.strftime("%Y-%m-%d"), next_month.strftime("%Y-%m-%d"))

        elif granularity == "yearly":
            # "2026" → ("2026-01-01", "2027-01-01")
            return (f"{period}-01-01", f"{int(period) + 1}-01-01")

        elif granularity == "mtd":
            # Month-to-Date: "202601" → (2026-01-01, 2026-01-09) on Feb 9
            # 오늘 데이터는 불완전하므로 어제(yesterday)까지만 비교
            dt = datetime.strptime(period, "%Y%m")
            today = get_kst_now()
            yesterday = today - timedelta(days=1)
            cutoff_day = yesterday.day

            start_date = dt.replace(day=1)

            # 짧은 달 처리 (e.g., cutoff_day=31 but Feb has only 28 days)
            try:
                end_date = dt.replace(day=cutoff_day) + timedelta(days=1)
            except ValueError:
                # cutoff_day가 해당 월의 마지막 날보다 큼
                # 해당 월의 마지막 날 + 1일 (다음 달 첫날)
                if dt.month == 12:
                    next_month = dt.replace(year=dt.year + 1, month=1, day=1)
                else:
                    next_month = dt.replace(month=dt.month + 1, day=1)
                end_date = next_month

            return (start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))

        else:
            raise ValueError(f"Unknown granularity: {granularity}")

    def get_date_ranges(self, granularity: str, periods: List[str]) -> List[str]:
        """기간의 실제 날짜 범위 반환.

        Args:
            granularity: daily, weekly, monthly, yearly, mtd
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            날짜 범위 문자열 목록 (e.g., ["2026-01-01 ~ 2026-01-08", ...])
        """
        ranges = []
        for period in periods:
            start, end = self._period_to_date_range(granularity, period)
            # end는 exclusive이므로 -1일 해서 표시
            end_dt = datetime.strptime(end, "%Y-%m-%d") - timedelta(days=1)
            ranges.append(f"{start} ~ {end_dt.strftime('%Y-%m-%d')}")
        return ranges


class LocalStackMultiAccountProvider(BaseMultiAccountProvider):
    """
    LocalStack-based Multi-Account Cost Explorer Provider.

    Reads cost data from DynamoDB tables that simulate multi-account
    Cost Explorer data. Used for testing with LocalStack.

    DynamoDB Schema (bdp-cost-history):
        PK: ACCOUNT#{account_id}#SERVICE#{service_name}
        SK: DATE#{yyyy-mm-dd}
        Attributes: cost, account_name, service_name, timestamp
    """

    def __init__(
        self,
        accounts: Optional[List[AccountConfig]] = None,
        endpoint_url: Optional[str] = None,
        table_name: str = "bdp-cost-history",
        region: str = "ap-northeast-2",
    ):
        """Initialize LocalStack provider.

        Args:
            accounts: Account configurations for simulated accounts
            endpoint_url: LocalStack endpoint URL
            table_name: DynamoDB table name
            region: AWS region
        """
        import boto3

        self.accounts = accounts or self._default_accounts()
        self.endpoint_url = endpoint_url or os.getenv(
            "LOCALSTACK_ENDPOINT", "http://localhost:4566"
        )
        self.table_name = table_name
        self.region = region

        self.dynamodb = boto3.client(
            "dynamodb",
            endpoint_url=self.endpoint_url,
            region_name=self.region,
        )

        logger.info(
            f"LocalStackMultiAccountProvider initialized: "
            f"endpoint={self.endpoint_url}, table={self.table_name}"
        )

    def _default_accounts(self) -> List[AccountConfig]:
        """Get default simulated accounts."""
        return [
            AccountConfig(
                account_id="111111111111",
                account_name="bdp-prod",
            ),
            AccountConfig(
                account_id="222222222222",
                account_name="hyundaicard-member",
            ),
        ]

    def get_accounts(self) -> List[AccountConfig]:
        """Get list of configured accounts."""
        return self.accounts.copy()

    def get_cost_data(self, days: int = 14) -> Dict[str, List[ServiceCostData]]:
        """Get cost data from LocalStack DynamoDB.

        Args:
            days: Number of days of historical data

        Returns:
            Dict mapping account_id to list of ServiceCostData
        """
        result: Dict[str, List[ServiceCostData]] = {}

        end_date = get_kst_now()
        start_date = end_date - timedelta(days=days)

        for account in self.accounts:
            try:
                # Scan for account data
                response = self.dynamodb.scan(
                    TableName=self.table_name,
                    FilterExpression="begins_with(pk, :account_prefix) AND sk BETWEEN :start AND :end",
                    ExpressionAttributeValues={
                        ":account_prefix": {"S": f"ACCOUNT#{account.account_id}"},
                        ":start": {"S": f"DATE#{start_date.strftime('%Y-%m-%d')}"},
                        ":end": {"S": f"DATE#{end_date.strftime('%Y-%m-%d')}"},
                    },
                )

                account_data = self._parse_dynamodb_response(
                    response.get("Items", []), account
                )
                result[account.account_id] = account_data

            except Exception as e:
                logger.error(f"Failed to get LocalStack data for {account.account_id}: {e}")
                result[account.account_id] = []

        return result

    def _parse_dynamodb_response(
        self, items: List[Dict[str, Any]], account: AccountConfig
    ) -> List[ServiceCostData]:
        """Parse DynamoDB items into ServiceCostData.

        Args:
            items: DynamoDB items
            account: Account configuration

        Returns:
            List of ServiceCostData
        """
        # Group by service
        service_data: Dict[str, Dict[str, Any]] = {}

        for item in items:
            pk = item.get("pk", {}).get("S", "")
            # Extract service name from PK: ACCOUNT#xxx#SERVICE#service_name
            parts = pk.split("#")
            service_name = parts[3] if len(parts) > 3 else "Unknown"

            sk = item.get("sk", {}).get("S", "")
            timestamp = sk.replace("DATE#", "") if sk.startswith("DATE#") else sk

            cost = float(item.get("cost", {}).get("N", "0"))

            if service_name not in service_data:
                service_data[service_name] = {
                    "historical_costs": [],
                    "timestamps": [],
                }

            service_data[service_name]["historical_costs"].append(cost)
            service_data[service_name]["timestamps"].append(timestamp)

        # Convert to ServiceCostData
        result = []
        for service_name, data in service_data.items():
            # Sort by timestamp
            sorted_pairs = sorted(
                zip(data["timestamps"], data["historical_costs"]),
                key=lambda x: x[0],
            )
            timestamps = [p[0] for p in sorted_pairs]
            costs = [p[1] for p in sorted_pairs]
            current_cost = costs[-1] if costs else 0.0

            result.append(
                ServiceCostData(
                    service_name=service_name,
                    account_id=account.account_id,
                    account_name=account.account_name,
                    current_cost=current_cost,
                    historical_costs=costs,
                    timestamps=timestamps,
                )
            )

        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: List[str],
    ) -> Dict[str, Dict[str, float]]:
        """기간별 비용 조회 (LocalStack - 빈 데이터 반환).

        LocalStack 테스트 환경에서는 빈 데이터를 반환합니다.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록

        Returns:
            {period: {service_name: cost}}
        """
        logger.warning(
            "LocalStack get_cost_data_by_period not implemented, returning empty data"
        )
        return {period: {} for period in periods}

    def get_date_ranges(self, granularity: str, periods: List[str]) -> List[str]:
        """기간의 실제 날짜 범위 반환 (LocalStack - 기본 구현).

        Args:
            granularity: daily, weekly, monthly, yearly, mtd
            periods: 기간 목록

        Returns:
            기간 문자열을 그대로 반환 (LocalStack에서는 날짜 범위 계산 미지원)
        """
        logger.warning(
            "LocalStack get_date_ranges not implemented, returning periods as-is"
        )
        return periods


class MockMultiAccountProvider(BaseMultiAccountProvider):
    """Mock provider for unit testing."""

    def __init__(
        self,
        accounts: Optional[List[AccountConfig]] = None,
        mock_data: Optional[Dict[str, List[ServiceCostData]]] = None,
    ):
        """Initialize mock provider.

        Args:
            accounts: Account configurations
            mock_data: Pre-configured mock data
        """
        self.accounts = accounts or [
            AccountConfig(
                account_id="123456789012",
                account_name="test-account-1",
            ),
            AccountConfig(
                account_id="987654321098",
                account_name="test-account-2",
            ),
        ]
        self.mock_data = mock_data
        self.call_history: List[Dict[str, Any]] = []

    def get_accounts(self) -> List[AccountConfig]:
        """Get list of configured accounts."""
        return self.accounts.copy()

    def get_cost_data(self, days: int = 14) -> Dict[str, List[ServiceCostData]]:
        """Get mock cost data.

        Args:
            days: Number of days (for recording)

        Returns:
            Mock cost data
        """
        self.call_history.append({"method": "get_cost_data", "days": days})

        if self.mock_data:
            return self.mock_data

        # Generate mock data
        return self._generate_mock_data(days)

    def _generate_mock_data(self, days: int) -> Dict[str, List[ServiceCostData]]:
        """Generate realistic mock cost data."""
        import random

        result: Dict[str, List[ServiceCostData]] = {}

        services = [
            ("Amazon Athena", 250000, 0.15),  # KRW base, variance ratio
            ("AWS Lambda", 50000, 0.10),
            ("Amazon S3", 100000, 0.08),
            ("Amazon EC2", 500000, 0.12),
            ("Amazon DynamoDB", 80000, 0.10),
        ]

        for account in self.accounts:
            account_services = []
            end_date = get_kst_now()

            for service_name, base_cost, variance in services:
                historical_costs = []
                timestamps = []

                for day in range(days):
                    date = end_date - timedelta(days=days - day - 1)
                    # Add some variance
                    daily_variance = random.uniform(-variance, variance)
                    cost = base_cost * (1 + daily_variance)

                    historical_costs.append(cost)
                    timestamps.append(date.strftime("%Y-%m-%d"))

                account_services.append(
                    ServiceCostData(
                        service_name=service_name,
                        account_id=account.account_id,
                        account_name=account.account_name,
                        current_cost=historical_costs[-1] if historical_costs else 0,
                        historical_costs=historical_costs,
                        timestamps=timestamps,
                        currency="KRW",
                    )
                )

            result[account.account_id] = account_services

        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: List[str],
    ) -> Dict[str, Dict[str, float]]:
        """기간별 비용 조회 (Mock - 가상 데이터 생성).

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록

        Returns:
            {period: {service_name: cost}}
        """
        import random

        self.call_history.append({
            "method": "get_cost_data_by_period",
            "granularity": granularity,
            "periods": periods,
        })

        # 기간별 비용 스케일 (monthly 기준)
        # mtd의 경우 현재 날짜 기준 일수로 계산
        if granularity == "mtd":
            today = get_kst_now()
            yesterday = today - timedelta(days=1)
            scale = yesterday.day  # 어제까지의 일수
        else:
            period_scale = {
                "daily": 1,
                "weekly": 7,
                "monthly": 30,
                "yearly": 365,
            }
            scale = period_scale.get(granularity, 30)

        services = [
            ("Amazon Athena", 8333),  # 일 평균 비용 (KRW)
            ("AWS Lambda", 1667),
            ("Amazon S3", 3333),
            ("Amazon EC2", 16667),
            ("Amazon DynamoDB", 2667),
            ("AWS Glue", 5000),
            ("Amazon SageMaker", 10000),
        ]

        result: Dict[str, Dict[str, float]] = {}

        for idx, period in enumerate(periods):
            period_costs: Dict[str, float] = {}
            for service_name, daily_cost in services:
                # 기간별 비용 계산 + 약간의 랜덤 변동
                base_cost = daily_cost * scale
                variance = random.uniform(-0.15, 0.15)
                # 두 번째 기간은 증가 트렌드
                if idx == 1:
                    trend_factor = random.uniform(1.0, 1.25)
                else:
                    trend_factor = 1.0

                cost = base_cost * (1 + variance) * trend_factor
                period_costs[service_name] = round(cost, 2)

            result[period] = period_costs

        logger.info(
            f"[MOCK] Generated cost data for {len(periods)} periods "
            f"({granularity}): {periods}"
        )
        return result

    def get_date_ranges(self, granularity: str, periods: List[str]) -> List[str]:
        """기간의 실제 날짜 범위 반환 (Mock - 실제 계산).

        Args:
            granularity: daily, weekly, monthly, yearly, mtd
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            날짜 범위 문자열 목록 (e.g., ["2026-01-01 ~ 2026-01-08", ...])
        """
        ranges = []
        for period in periods:
            start, end = self._mock_period_to_date_range(granularity, period)
            # end는 exclusive이므로 -1일 해서 표시
            end_dt = datetime.strptime(end, "%Y-%m-%d") - timedelta(days=1)
            ranges.append(f"{start} ~ {end_dt.strftime('%Y-%m-%d')}")

        self.call_history.append({
            "method": "get_date_ranges",
            "granularity": granularity,
            "periods": periods,
        })
        return ranges

    def _mock_period_to_date_range(self, granularity: str, period: str) -> Tuple[str, str]:
        """Mock용 period 문자열을 날짜 범위로 변환."""
        if granularity == "daily":
            dt = datetime.strptime(period, "%Y%m%d")
            end_dt = dt + timedelta(days=1)
            return (dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))

        elif granularity == "weekly":
            year = int(period[:4])
            week = int(period[5:])
            first_day = datetime.strptime(f"{year}-W{week:02d}-1", "%Y-W%W-%w")
            last_day = first_day + timedelta(days=7)
            return (first_day.strftime("%Y-%m-%d"), last_day.strftime("%Y-%m-%d"))

        elif granularity == "monthly":
            dt = datetime.strptime(period, "%Y%m")
            if dt.month == 12:
                next_month = dt.replace(year=dt.year + 1, month=1, day=1)
            else:
                next_month = dt.replace(month=dt.month + 1, day=1)
            return (dt.strftime("%Y-%m-%d"), next_month.strftime("%Y-%m-%d"))

        elif granularity == "yearly":
            return (f"{period}-01-01", f"{int(period) + 1}-01-01")

        elif granularity == "mtd":
            dt = datetime.strptime(period, "%Y%m")
            today = get_kst_now()
            yesterday = today - timedelta(days=1)
            cutoff_day = yesterday.day

            start_date = dt.replace(day=1)

            try:
                end_date = dt.replace(day=cutoff_day) + timedelta(days=1)
            except ValueError:
                if dt.month == 12:
                    next_month = dt.replace(year=dt.year + 1, month=1, day=1)
                else:
                    next_month = dt.replace(month=dt.month + 1, day=1)
                end_date = next_month

            return (start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))

        else:
            raise ValueError(f"Unknown granularity: {granularity}")


def create_provider(
    provider_type: Optional[str] = None,
    accounts: Optional[List[AccountConfig]] = None,
    **kwargs: Any,
) -> BaseMultiAccountProvider:
    """Factory function to create appropriate provider.

    Args:
        provider_type: Provider type (real, localstack, mock)
        accounts: Account configurations
        **kwargs: Additional provider-specific arguments

    Returns:
        Provider instance
    """
    provider_type = provider_type or os.getenv("BDP_PROVIDER", "mock")

    if provider_type == "localstack":
        return LocalStackMultiAccountProvider(accounts=accounts, **kwargs)
    elif provider_type == "real":
        return MultiAccountCostExplorerProvider(accounts=accounts, **kwargs)
    else:
        return MockMultiAccountProvider(accounts=accounts, **kwargs)
