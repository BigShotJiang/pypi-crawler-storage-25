"""
Cost Comparison HTML Report Generator.

비용 비교 결과를 HTML 리포트로 생성합니다.
Material Design 3 기반 디자인 시스템 적용.
"""

import logging
from datetime import datetime
from typing import List

from src.agent_server.bdp_common.eventbridge.publisher import get_environment_account_name
from src.agent_server.bdp_common.reports.styles import MD3_COLORS
from .comparison_models import (
    CostComparisonResult,
    Granularity,
    ServiceCostComparison,
)

logger = logging.getLogger(__name__)


class CostComparisonHTMLReportGenerator:
    """비용 비교 HTML 리포트 생성기."""

    GRANULARITY_LABELS = {
        Granularity.DAILY: "일별",
        Granularity.WEEKLY: "주별",
        Granularity.MONTHLY: "월별",
        Granularity.YEARLY: "연별",
        Granularity.MTD: "월누적(MTD)",
    }

    def __init__(self, currency: str = "USD"):
        """리포트 생성기 초기화.

        Args:
            currency: 통화 단위 (USD, KRW)
        """
        self.currency = currency

    def generate(self, result: CostComparisonResult) -> str:
        """비교 결과를 HTML 리포트로 생성.

        Args:
            result: 비용 비교 결과

        Returns:
            HTML 문자열
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        env_account_name = get_environment_account_name()
        granularity_label = self.GRANULARITY_LABELS.get(
            result.granularity, result.granularity.value
        )

        # 기간 표시: period_range가 있으면 range 사용, 없으면 period 사용
        period1_display = result.period1_range or result.period1
        period2_display = result.period2_range or result.period2

        # 변화 색상/방향 (MD3 기반)
        if result.total_change >= 0:
            change_color = MD3_COLORS["error"]  # Red
            change_bg = MD3_COLORS["error_container"]
            change_sign = "+"
        else:
            change_color = MD3_COLORS["decrease"]  # Blue
            change_bg = MD3_COLORS["decrease_container"]
            change_sign = ""

        # 서비스 테이블 행
        service_rows = self._build_service_rows(result)

        # Top 증가/감소
        top_increases_html = self._build_top_list(result.top_increases, is_increase=True)
        top_decreases_html = self._build_top_list(result.top_decreases, is_increase=False)

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>비용 비교 리포트 - {result.period1} vs {result.period2}</title>
    <style>
        @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');

        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background-color: {MD3_COLORS['surface_variant']};
            color: {MD3_COLORS['on_surface']};
            line-height: 1.6;
            padding: 20px;
        }}

        .container {{
            max-width: 700px;
            margin: 0 auto;
            background: {MD3_COLORS['surface']};
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .header {{
            background: {MD3_COLORS['surface']};
            padding: 24px;
            border-bottom: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .header h1 {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: {MD3_COLORS['on_surface']};
        }}

        .header p {{
            font-size: 0.95rem;
            color: {MD3_COLORS['on_surface']};
        }}

        .header .meta {{
            font-size: 0.85rem;
            color: {MD3_COLORS['on_surface_variant']};
            margin-top: 12px;
        }}

        .summary-cards {{
            display: flex;
            gap: 16px;
            padding: 20px;
            background: {MD3_COLORS['surface_variant']};
        }}

        .summary-card {{
            flex: 1;
            background: {MD3_COLORS['surface']};
            padding: 16px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .summary-card.change {{
            background: {change_bg};
            border-color: {change_color};
        }}

        .summary-card .label {{
            color: {MD3_COLORS['on_surface_variant']};
            font-size: 0.85rem;
            margin-bottom: 8px;
        }}

        .summary-card .value {{
            font-size: 1.25rem;
            font-weight: 700;
            color: {MD3_COLORS['on_surface']};
        }}

        .summary-card.change .value {{
            color: {change_color};
        }}

        .section {{
            padding: 20px;
            border-top: 1px solid {MD3_COLORS['outline_variant']};
        }}

        .section-highlight {{
            padding: 20px;
            border-top: 3px solid {MD3_COLORS['primary']};
            background: {MD3_COLORS['surface_variant']};
        }}

        .section-title {{
            font-size: 1rem;
            font-weight: 600;
            color: {MD3_COLORS['on_surface']};
            margin-bottom: 16px;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        th, td {{
            padding: 12px 10px;
            text-align: right;
            border-bottom: 1px solid {MD3_COLORS['outline_variant']};
            font-size: 0.9rem;
        }}

        th {{
            background: {MD3_COLORS['surface_variant']};
            font-weight: 600;
            color: {MD3_COLORS['on_surface_variant']};
        }}

        th:first-child, td:first-child {{
            text-align: left;
        }}

        td.service-name {{
            font-weight: 500;
            color: {MD3_COLORS['on_surface']};
        }}

        td.increase {{
            color: {MD3_COLORS['error']};
            font-weight: 500;
        }}

        td.decrease {{
            color: {MD3_COLORS['decrease']};
            font-weight: 500;
        }}

        .top-changes {{
            display: flex;
            flex-direction: column;
            gap: 24px;
        }}

        .top-changes-column {{
            background: {MD3_COLORS['surface']};
            border: 1px solid {MD3_COLORS['outline_variant']};
            border-radius: 8px;
            padding: 16px;
        }}

        .top-changes-column:first-child {{
            border-left: 3px solid {MD3_COLORS['error']};
        }}

        .top-changes-column:last-child {{
            border-left: 3px solid {MD3_COLORS['decrease']};
        }}

        .top-changes-column h4 {{
            font-size: 0.9rem;
            color: {MD3_COLORS['on_surface_variant']};
            margin-bottom: 12px;
        }}

        .top-item {{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid {MD3_COLORS['outline_variant']};
            font-size: 0.85rem;
        }}

        .top-item:last-child {{
            border-bottom: none;
        }}

        .top-item .name {{
            color: {MD3_COLORS['on_surface']};
        }}

        .top-item .change.increase {{
            color: {MD3_COLORS['error']};
            font-weight: 500;
        }}

        .top-item .change.decrease {{
            color: {MD3_COLORS['decrease']};
            font-weight: 500;
        }}

        .footer {{
            padding: 16px 20px;
            background: {MD3_COLORS['surface_variant']};
            text-align: center;
            font-size: 0.8rem;
            color: {MD3_COLORS['on_surface_variant']};
        }}

        .note {{
            padding: 12px 20px;
            background: {MD3_COLORS['warning_container']};
            border-left: 4px solid {MD3_COLORS['warning']};
            font-size: 0.85rem;
            color: {MD3_COLORS['on_warning_container']};
        }}

        @media (max-width: 600px) {{
            .summary-cards {{
                flex-direction: column;
            }}

            th, td {{
                padding: 10px 6px;
                font-size: 0.85rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>비용 비교 리포트</h1>
            <p>{period1_display} vs {period2_display} ({granularity_label})</p>
            <div class="meta">
                환경: {env_account_name} | 생성: {timestamp}
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="summary-card">
                <div class="label">{period1_display}</div>
                <div class="value">{self._format_cost(result.total_period1_cost)}</div>
            </div>
            <div class="summary-card">
                <div class="label">{period2_display}</div>
                <div class="value">{self._format_cost(result.total_period2_cost)}</div>
            </div>
            <div class="summary-card change">
                <div class="label">변화</div>
                <div class="value">{change_sign}{self._format_cost(abs(result.total_change))} ({result.total_change_percent:+.1f}%)</div>
            </div>
        </div>

        <!-- Note -->
        <div class="note">
            AWS Cost Explorer 데이터는 UTC 기준으로 집계됩니다.
        </div>

        <!-- Service Table -->
        <div class="section">
            <div class="section-title">서비스별 비용 비교</div>
            <table>
                <thead>
                    <tr>
                        <th>서비스</th>
                        <th>{period1_display}</th>
                        <th>{period2_display}</th>
                        <th>변화</th>
                        <th>변화율</th>
                    </tr>
                </thead>
                <tbody>
                    {service_rows}
                </tbody>
            </table>
        </div>

        <!-- Top Changes -->
        <div class="section-highlight">
            <div class="section-title">주요 변동</div>
            <div class="top-changes">
                <div class="top-changes-column">
                    <h4>Top 증가</h4>
                    {top_increases_html}
                </div>
                <div class="top-changes-column">
                    <h4>Top 감소</h4>
                    {top_decreases_html}
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            BDP Cost Agent | CD1 Agent System
        </div>
    </div>
</body>
</html>"""

        return html

    def _build_service_rows(self, result: CostComparisonResult) -> str:
        """서비스 테이블 행 생성."""
        rows = []

        for comp in result.service_comparisons:
            # 변화 색상
            if comp.cost_change > 0:
                change_class = "increase"
                change_sign = "+"
            elif comp.cost_change < 0:
                change_class = "decrease"
                change_sign = ""
            else:
                change_class = ""
                change_sign = ""

            # 서비스명 정리
            service_display = self._clean_service_name(comp.service_name)

            row = f"""<tr>
                <td class="service-name">{service_display}</td>
                <td>{self._format_cost(comp.period1_cost)}</td>
                <td>{self._format_cost(comp.period2_cost)}</td>
                <td class="{change_class}">{change_sign}{self._format_cost(abs(comp.cost_change))}</td>
                <td class="{change_class}">{comp.change_percent:+.1f}%</td>
            </tr>"""
            rows.append(row)

        return "\n".join(rows)

    def _build_top_list(
        self,
        items: List[ServiceCostComparison],
        is_increase: bool
    ) -> str:
        """Top 증가/감소 목록 생성."""
        if not items:
            return '<div class="top-item"><span class="name">-</span></div>'

        html_items = []
        change_class = "increase" if is_increase else "decrease"

        for item in items:
            service_display = self._clean_service_name(item.service_name)
            sign = "+" if item.cost_change > 0 else ""
            html_items.append(f"""<div class="top-item">
                <span class="name">{service_display}</span>
                <span class="change {change_class}">{sign}{self._format_cost(abs(item.cost_change))} ({item.change_percent:+.1f}%)</span>
            </div>""")

        return "\n".join(html_items)

    def _format_cost(self, cost: float) -> str:
        """비용을 읽기 쉬운 형식으로 포맷팅 (소수점 유지)."""
        if self.currency == "KRW":
            if cost >= 100_000_000:  # 1억 이상
                return f"{cost / 100_000_000:.2f}억원"
            elif cost >= 10_000:  # 1만 이상
                return f"{cost / 10_000:.2f}만원"
            else:
                return f"{cost:,.2f}원"
        else:  # USD
            return f"${cost:,.2f}"

    def _clean_service_name(self, service_name: str) -> str:
        """서비스명 정리 (Amazon, AWS 접두사 제거)."""
        name = service_name
        prefixes = ["Amazon ", "AWS ", "Amazon"]
        for prefix in prefixes:
            if name.startswith(prefix):
                name = name[len(prefix):]
        return name.strip()


def generate_comparison_report(
    result: CostComparisonResult,
    currency: str = "USD",
) -> str:
    """편의 함수: 비용 비교 리포트 생성.

    Args:
        result: 비용 비교 결과
        currency: 통화 단위 (USD, KRW)

    Returns:
        HTML 문자열
    """
    generator = CostComparisonHTMLReportGenerator(currency=currency)
    return generator.generate(result)
