"""
BDP Compact Agent Services.

Service modules for multi-account cost drift detection.
"""

from .anomaly_detector import (
    CostDriftDetector,
    CostDriftResult,
    Severity,
)
from src.agent_server.bdp_common.eventbridge.publisher import (
    EventPublisher,
    AlertEvent,
)
from .multi_account_provider import (
    AccountConfig,
    BaseMultiAccountProvider,
    MultiAccountCostExplorerProvider,
    ServiceCostData,
    create_provider,
)
from .summary_generator import (
    AlertSummary,
    SummaryGenerator,
)
from .comparison_models import (
    CostComparisonResult,
    Granularity,
    ServiceCostComparison,
)
from .comparison_analyzer import CostComparisonAnalyzer
from .comparison_report_generator import (
    CostComparisonHTMLReportGenerator,
    generate_comparison_report,
)
from .athena_cost_models import (
    AthenaCostResult,
    AthenaProjectCost,
    AthenaWorkgroupCost,
)
from .athena_pricing_provider import (
    AthenaPricingProvider,
    MockAthenaPricingProvider,
    REGION_LOCATION_MAP,
)
from .athena_cost_analyzer import AthenaCostAnalyzer
from .athena_cost_report_generator import (
    AthenaCostHTMLReportGenerator,
    generate_athena_cost_report,
)

__all__ = [
    "CostDriftDetector",
    "CostDriftResult",
    "Severity",
    "EventPublisher",
    "AlertEvent",
    "AccountConfig",
    "BaseMultiAccountProvider",
    "MultiAccountCostExplorerProvider",
    "ServiceCostData",
    "create_provider",
    "AlertSummary",
    "SummaryGenerator",
    # Cost Comparison
    "CostComparisonResult",
    "Granularity",
    "ServiceCostComparison",
    "CostComparisonAnalyzer",
    "CostComparisonHTMLReportGenerator",
    "generate_comparison_report",
    # Athena Cost
    "AthenaCostResult",
    "AthenaProjectCost",
    "AthenaWorkgroupCost",
    "AthenaPricingProvider",
    "MockAthenaPricingProvider",
    "REGION_LOCATION_MAP",
    "AthenaCostAnalyzer",
    "AthenaCostHTMLReportGenerator",
    "generate_athena_cost_report",
]
