"""
BDP Compact Handler for Multi-Account Cost Drift Detection.

Lambda/FastAPI 핸들러 - Multi-Account Cost Explorer 기반 비용 드리프트 탐지
및 KakaoTalk 알람 발송.

Standalone version - no dependency on src.common
"""

import json
import logging
import os
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from .services.anomaly_detector import (
    CostDriftDetector,
    CostDriftResult,
    Severity,
)
from .services.multi_account_provider import (
    create_provider,
    BaseMultiAccountProvider,
    AccountConfig,
)
from .services.summary_generator import SummaryGenerator, AlertSummary
from .services.html_report_generator import CostHTMLReportGenerator
from .services.comparison_analyzer import CostComparisonAnalyzer
from .services.comparison_report_generator import CostComparisonHTMLReportGenerator
from .services.comparison_models import CostComparisonResult
from .services.athena_cost_analyzer import AthenaCostAnalyzer
from .services.athena_cost_models import AthenaCostResult
from .services.athena_cost_report_generator import AthenaCostHTMLReportGenerator

from src.agent_server.bdp_common.eventbridge.publisher import (
    EventPublisher,
    AlertEvent,
    ProductionAlertDetail,
    EmailChannel,
    KakaoChannel,
    get_environment_account_name,
)

logger = logging.getLogger(__name__)


class BDPCostHandler:
    """
    BDP Compact 비용 드리프트 탐지 핸들러.

    Multi-Account Cost Explorer 데이터를 분석하여 비용 드리프트를 탐지하고,
    EventBridge를 통해 KakaoTalk 알람을 발송합니다.

    Features:
    - Multi-Account Cost Explorer 접근 (STS AssumeRole)
    - PyOD ECOD 기반 이상 탐지
    - 한글 Rich Summary 생성
    - EventBridge → KakaoTalk 알람
    """

    def __init__(self, account_id: Optional[str] = None):
        """핸들러 초기화.

        Args:
            account_id: AWS 계정 ID. Lambda에서 ENVIRONMENT 기반으로 결정하여 전달.
                        None이면 환경변수 fallback.
        """
        self.name = "BDPCostHandler"
        self.logger = logging.getLogger(self.name)
        self._account_id = account_id
        self._init_services()

    def _init_services(self) -> None:
        """서비스 컴포넌트 초기화."""
        # Provider 설정
        provider_type = os.getenv("BDP_PROVIDER", "mock")
        accounts = None
        if self._account_id:
            accounts = [AccountConfig(
                account_id=self._account_id,
                account_name="bdp_cost_agent",
            )]
        self.provider: BaseMultiAccountProvider = create_provider(
            provider_type=provider_type,
            accounts=accounts,  # None이면 환경변수 fallback
        )

        # Detector 설정 (환경변수 기본값)
        self.default_sensitivity = float(os.getenv("BDP_SENSITIVITY", "0.7"))
        self.default_min_data_points = int(os.getenv("BDP_MIN_DATA_POINTS", "7"))
        self.default_ratio_threshold = float(os.getenv("BDP_RATIO_THRESHOLD", "1.5"))
        self.default_contamination = float(os.getenv("BDP_CONTAMINATION", "0.1"))

        self.detector = CostDriftDetector(
            sensitivity=self.default_sensitivity,
            min_data_points=self.default_min_data_points,
            ratio_threshold=self.default_ratio_threshold,
            contamination=self.default_contamination,
        )

        # Summary Generator 설정
        currency = os.getenv("BDP_CURRENCY", "KRW")
        self.summary_generator = SummaryGenerator(currency=currency)

        # HTML Report Generator 설정
        self.html_generator = CostHTMLReportGenerator(currency=currency)

        # Event Publisher 설정
        event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.event_publisher = EventPublisher(
            source="cd1-agent.bdp-cost",
            event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
            use_mock=event_provider == "mock",
        )

        # Production 알림 설정
        email_to_str = os.getenv("DEFAULT_EMAIL_TO", "")
        email_cc_str = os.getenv("DEFAULT_EMAIL_CC", "")
        self.default_email_to = [e.strip() for e in email_to_str.split(",") if e.strip()]
        self.default_email_cc = [e.strip() for e in email_cc_str.split(",") if e.strip()]

        # 설정값
        self.min_cost_threshold = float(os.getenv("BDP_MIN_COST_THRESHOLD", "10000"))

        self.logger.info(
            f"BDPCostHandler initialized: provider={provider_type}, "
            f"sensitivity={self.default_sensitivity}, ratio_threshold={self.default_ratio_threshold}, "
            f"min_data_points={self.default_min_data_points}, contamination={self.default_contamination}, "
            f"currency={currency}"
        )

    def handle(self, event: Dict[str, Any], context: Any = None) -> Dict[str, Any]:
        """Lambda 핸들러 진입점.

        Args:
            event: Lambda 이벤트 또는 API 요청
            context: Lambda context

        Returns:
            응답 딕셔너리
        """
        try:
            result = self.process(event, context)
            return {
                "success": True,
                "data": result,
                "timestamp": get_kst_now().isoformat(),
            }
        except Exception as e:
            self.logger.error(f"Handler error: {e}\n{traceback.format_exc()}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": get_kst_now().isoformat(),
            }

    def _parse_body(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """이벤트 바디 파싱.

        Args:
            event: Lambda 이벤트

        Returns:
            파싱된 바디 딕셔너리
        """
        body = event.get("body", {})
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                body = {}
        return body or {}

    def process(self, event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        """비용 드리프트 탐지/비교 실행.

        Args:
            event: Lambda 이벤트 또는 API 요청
            context: Lambda context

        Returns:
            탐지/비교 결과
        """
        body = self._parse_body(event)

        # action 라우팅
        action = body.get("action", event.get("action", "detect"))

        if action == "compare":
            return self._process_compare(body, event)
        elif action == "detect":
            return self._process_detect(body, event)
        elif action == "athena_cost":
            return self._process_athena_cost(body, event)
        else:
            return {
                "status": "error",
                "message": f"Unknown action: {action}. Valid actions: detect, compare, athena_cost",
            }

    def _process_detect(self, body: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
        """비용 드리프트 탐지 처리.

        Args:
            body: 파싱된 요청 본문
            event: 원본 이벤트

        Returns:
            탐지 결과
        """
        # 파라미터 추출
        days = int(body.get("days", event.get("days", 14)))
        min_cost = float(
            body.get("min_cost_threshold", event.get("min_cost_threshold", self.min_cost_threshold))
        )
        publish_alerts = body.get("publish_alerts", event.get("publish_alerts", True))
        send_kakao = body.get("send_kakao", event.get("send_kakao", False))
        email_to = body.get("email_to", event.get("email_to")) or self.default_email_to
        email_cc = body.get("email_cc", event.get("email_cc")) or self.default_email_cc

        # Detector 파라미터 추출 (body > event > 환경변수 기본값)
        sensitivity = float(body.get("sensitivity", event.get("sensitivity", self.default_sensitivity)))
        min_data_points = int(body.get("min_data_points", event.get("min_data_points", self.default_min_data_points)))
        ratio_threshold = float(body.get("ratio_threshold", event.get("ratio_threshold", self.default_ratio_threshold)))
        contamination = float(body.get("contamination", event.get("contamination", self.default_contamination)))

        # 기본값과 다르면 새 detector 생성 (테스트용 오버라이드)
        if (sensitivity != self.default_sensitivity or
            min_data_points != self.default_min_data_points or
            ratio_threshold != self.default_ratio_threshold or
            contamination != self.default_contamination):
            detector = CostDriftDetector(
                sensitivity=sensitivity,
                min_data_points=min_data_points,
                ratio_threshold=ratio_threshold,
                contamination=contamination,
            )
            self.logger.info(
                f"Detector 오버라이드: sensitivity={sensitivity}, ratio_threshold={ratio_threshold}, "
                f"min_data_points={min_data_points}, contamination={contamination}"
            )
        else:
            detector = self.detector

        self.logger.info(
            f"비용 드리프트 탐지 시작: days={days}, min_cost={min_cost}"
        )

        # 1. 비용 데이터 조회
        cost_data = self.provider.get_cost_data(days=days)
        total_services = sum(len(services) for services in cost_data.values())
        self.logger.info(f"조회된 서비스: {total_services}개")

        # 2. 비용 드리프트 탐지 (오버라이드된 detector 사용)
        all_results = detector.analyze_batch(cost_data)

        # 3. 최소 비용 임계값 필터링
        filtered_results = [
            r for r in all_results
            if r.current_cost >= min_cost or r.historical_average >= min_cost
        ]

        # 4. 이상 탐지된 결과만 추출
        anomalies = [r for r in filtered_results if r.is_anomaly]
        severity_breakdown = self._count_by_severity(anomalies)

        self.logger.info(
            f"탐지 완료: {len(anomalies)}건 이상 발견 "
            f"(심각: {severity_breakdown['critical']}, "
            f"높음: {severity_breakdown['high']})"
        )

        # 5. 알람 발송 (이상 탐지된 경우)
        if anomalies and publish_alerts:
            # Summary 생성
            summary = self.summary_generator.generate_batch_summary(anomalies)

            # EventBridge 발행
            self._publish_events(
                results=anomalies,
                summary=summary,
                email_to=email_to,
                email_cc=email_cc,
                send_kakao=send_kakao,
            )

        # 6. 결과 반환
        return {
            "detection_type": "cost_drift",
            "period_days": days,
            "accounts_analyzed": len(cost_data),
            "services_analyzed": len(filtered_results),
            "anomalies_detected": len(anomalies) > 0,
            "total_anomalies": len(anomalies),
            "severity_breakdown": severity_breakdown,
            "summary": self._generate_result_summary(anomalies),
            "results": [self._result_to_dict(r) for r in anomalies[:20]],
            "detection_timestamp": get_kst_now().isoformat(),
            "detector_config": {
                "sensitivity": sensitivity,
                "min_data_points": min_data_points,
                "ratio_threshold": ratio_threshold,
                "contamination": contamination,
            },
        }

    def _process_compare(self, body: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
        """비용 비교 처리.

        두 기간의 비용을 비교하여 HTML 리포트를 생성하고 알림을 발송합니다.

        Args:
            body: 파싱된 요청 본문
            event: 원본 이벤트

        Returns:
            비교 결과
        """
        # 파라미터 추출
        granularity = body.get("granularity", event.get("granularity", "monthly"))
        periods = body.get("periods", event.get("periods", []))
        email_to = body.get("email_to", event.get("email_to")) or self.default_email_to
        email_cc = body.get("email_cc", event.get("email_cc")) or self.default_email_cc
        send_kakao = body.get("send_kakao", event.get("send_kakao", False))

        # Validation
        if len(periods) != 2:
            return {
                "status": "error",
                "message": "periods must have exactly 2 elements (e.g., ['202512', '202601'])",
            }

        # 계정 정보 (첫 번째 계정 기준)
        accounts = self.provider.get_accounts()
        if accounts:
            account_id = accounts[0].account_id
            account_name = accounts[0].account_name
        else:
            account_id = "unknown"
            account_name = "unknown"

        self.logger.info(
            f"비용 비교 시작: granularity={granularity}, periods={periods}"
        )

        # 1. 기간별 비용 데이터 조회
        self.logger.info(f"Fetching cost data for periods: {periods}")
        period_data = self.provider.get_cost_data_by_period(granularity, periods)

        # 1-1. 날짜 범위 조회 (MTD 등에서 실제 범위 표시용)
        period_ranges = self.provider.get_date_ranges(granularity, periods)

        # 2. 비교 분석
        self.logger.info("Analyzing comparison...")
        analyzer = CostComparisonAnalyzer()
        result = analyzer.analyze(
            period_data=period_data,
            granularity=granularity,
            periods=periods,
            account_id=account_id,
            account_name=account_name,
            period_ranges=period_ranges,
        )

        # 3. HTML 리포트 생성
        currency = os.getenv("BDP_CURRENCY", "USD")
        report_gen = CostComparisonHTMLReportGenerator(currency=currency)
        html_report = report_gen.generate(result)

        # 4. 알림 발송 (무조건)
        report_sent = False
        if email_to:
            self.logger.info("Sending comparison report...")
            report_sent = self._publish_comparison_report(
                result=result,
                html_report=html_report,
                email_to=email_to,
                email_cc=email_cc,
                send_kakao=send_kakao,
            )

        return {
            "status": "success",
            "report_type": "cost_comparison",
            "granularity": granularity,
            "periods": periods,
            "account_id": account_id,
            "account_name": account_name,
            "summary": {
                "total_period1": result.total_period1_cost,
                "total_period2": result.total_period2_cost,
                "change": result.total_change,
                "change_percent": result.total_change_percent,
                "services_compared": len(result.service_comparisons),
            },
            "report_sent": report_sent,
            "timestamp": get_kst_now().isoformat(),
        }

    def _process_athena_cost(self, body: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
        """Athena 비용 분석 처리.

        Workgroup별, project_cd별 Athena 비용을 분석하고 HTML 리포트를 생성합니다.

        Args:
            body: 파싱된 요청 본문
            event: 원본 이벤트

        Returns:
            분석 결과
        """
        # 파라미터 추출
        days = int(body.get("days", event.get("days", 30)))
        end_days_ago = int(body.get("end_days_ago", event.get("end_days_ago", 0)))
        workgroups = body.get("workgroups", event.get("workgroups"))
        region = body.get("region", event.get("region", "ap-northeast-2"))
        email_to = body.get("email_to", event.get("email_to")) or self.default_email_to
        email_cc = body.get("email_cc", event.get("email_cc")) or self.default_email_cc
        send_kakao = body.get("send_kakao", event.get("send_kakao", False))

        # Provider 타입 확인
        use_mock = os.getenv("ATHENA_PROVIDER", "").lower() == "mock"

        self.logger.info(
            f"Athena 비용 분석 시작: days={days}, region={region}, use_mock={use_mock}"
        )

        # 1. Athena 비용 분석
        analyzer = AthenaCostAnalyzer(
            region=region,
            use_mock=use_mock,
        )
        result = analyzer.analyze(days=days, workgroups=workgroups, end_days_ago=end_days_ago)

        self.logger.info(
            f"Athena 비용 분석 완료: "
            f"workgroups={len(result.workgroup_costs)}, "
            f"projects={len(result.project_costs)}, "
            f"total_cost=${result.total_cost_usd:.2f}"
        )

        # 2. HTML 리포트 생성
        currency = os.getenv("BDP_CURRENCY", "USD")
        report_gen = AthenaCostHTMLReportGenerator(currency=currency)
        html_report = report_gen.generate(result)

        # 3. 알림 발송
        report_sent = False
        if email_to:
            self.logger.info("Sending Athena cost report...")
            report_sent = self._publish_athena_cost_report(
                result=result,
                html_report=html_report,
                email_to=email_to,
                email_cc=email_cc,
                send_kakao=send_kakao,
            )

        return {
            "status": "success",
            "report_type": "athena_cost",
            "period_days": days,
            "region": region,
            "account_id": result.account_id,
            "account_name": result.account_name,
            "summary": {
                "total_queries": result.total_queries,
                "total_data_scanned_tb": result.total_data_scanned_tb,
                "total_cost_usd": result.total_cost_usd,
                "price_per_tb": result.price_per_tb,
                "workgroups_analyzed": len(result.workgroup_costs),
                "projects_analyzed": len(result.project_costs),
            },
            "workgroup_costs": [
                {
                    "workgroup_name": wg.workgroup_name,
                    "is_shared": wg.is_shared,
                    "total_queries": wg.total_queries,
                    "total_data_scanned_tb": wg.total_data_scanned_tb,
                    "estimated_cost_usd": wg.estimated_cost_usd,
                    "project_cd": wg.project_cd,
                }
                for wg in result.workgroup_costs[:10]  # Top 10
            ],
            "project_costs": [
                {
                    "project_cd": proj.project_cd,
                    "dedicated_cost": proj.dedicated_cost,
                    "shared_cost": proj.shared_cost,
                    "total_cost": proj.total_cost,
                    "total_queries": proj.total_queries,
                }
                for proj in result.project_costs[:10]  # Top 10
            ],
            "report_sent": report_sent,
            "timestamp": get_kst_now().isoformat(),
        }

    def _publish_athena_cost_report(
        self,
        result: AthenaCostResult,
        html_report: str,
        email_to: List[str],
        email_cc: List[str],
        send_kakao: bool,
    ) -> bool:
        """Athena 비용 리포트 발송.

        EventBridge를 통해 이메일/카카오톡으로 리포트를 발송합니다.

        Args:
            result: Athena 비용 분석 결과
            html_report: HTML 리포트 문자열
            email_to: 수신자 이메일 목록
            email_cc: 참조 이메일 목록
            send_kakao: 카카오톡 발송 여부

        Returns:
            발송 성공 여부
        """
        period_display = (
            f"{result.period_start.strftime('%Y-%m-%d')} ~ "
            f"{result.period_end.strftime('%Y-%m-%d')}"
        )

        subject = (
            f"📊 [Athena 비용 분석] {period_display} "
            f"(${result.total_cost_usd:,.2f})"
        )

        # 카카오 채널 설정
        kakao_channel = None
        if send_kakao:
            summary_msg = (
                f"[Athena 비용 분석 리포트]\n"
                f"기간: {period_display}\n\n"
                f"총 비용: ${result.total_cost_usd:,.2f}\n"
                f"총 쿼리: {result.total_queries:,}회\n"
                f"총 스캔: {result.total_data_scanned_tb:.2f} TB"
            )
            kakao_channel = KakaoChannel(
                severity='INFO',
                category1=get_environment_account_name().upper(),
                message=summary_msg,
            )

        detail = ProductionAlertDetail(
            subject=subject,
            account_id=get_environment_account_name(),
            email=EmailChannel(
                to=email_to,
                cc=email_cc or [],
                from_email="alert-cost@hcs.com",
                message=html_report,
            ),
            kakao=kakao_channel,
        )

        return self.event_publisher.publish_production_event(
            detail=detail,
            detail_type="Athena Cost Report",
        )

    def _publish_comparison_report(
        self,
        result: CostComparisonResult,
        html_report: str,
        email_to: List[str],
        email_cc: List[str],
        send_kakao: bool,
    ) -> bool:
        """비용 비교 리포트 발송.

        EventBridge를 통해 이메일/카카오톡으로 리포트를 발송합니다.

        Args:
            result: 비용 비교 결과
            html_report: HTML 리포트 문자열
            email_to: 수신자 이메일 목록
            email_cc: 참조 이메일 목록
            send_kakao: 카카오톡 발송 여부

        Returns:
            발송 성공 여부
        """
        # 변화율에 따른 제목 이모지
        if result.total_change_percent >= 20:
            emoji = "📈"
        elif result.total_change_percent <= -20:
            emoji = "📉"
        else:
            emoji = "📊"

        granularity_label = CostComparisonHTMLReportGenerator.GRANULARITY_LABELS.get(
            result.granularity, result.granularity.value
        )
        subject = (
            f"{emoji} [비용 비교 - {granularity_label}] {result.period1} vs {result.period2} "
            f"({result.total_change_percent:+.1f}%)"
        )

        # 카카오 채널 설정
        kakao_channel = None
        if send_kakao:
            summary_msg = (
                f"[비용 비교 리포트]\n"
                f"{result.period1} vs {result.period2}\n\n"
                f"총 비용 변화: {result.total_change_percent:+.1f}%\n"
                f"• {result.period1}: {self._format_cost_for_kakao(result.total_period1_cost)}\n"
                f"• {result.period2}: {self._format_cost_for_kakao(result.total_period2_cost)}"
            )
            kakao_channel = KakaoChannel(
                severity='INFO',
                category1=get_environment_account_name().upper(),
                message=summary_msg,
            )

        detail = ProductionAlertDetail(
            subject=subject,
            account_id=get_environment_account_name(),
            email=EmailChannel(
                to=email_to,
                cc=email_cc or [],
                from_email="alert-cost@hcs.com",
                message=html_report,
            ),
            kakao=kakao_channel,
        )

        return self.event_publisher.publish_production_event(
            detail=detail,
            detail_type="Cost Comparison Report",
        )

    def _format_cost_for_kakao(self, cost: float) -> str:
        """카카오톡용 비용 포맷팅 (소수점 유지)."""
        currency = os.getenv("BDP_CURRENCY", "USD")
        if currency == "KRW":
            if cost >= 100_000_000:
                return f"{cost / 100_000_000:.2f}억원"
            elif cost >= 10_000:
                return f"{cost / 10_000:.2f}만원"
            else:
                return f"{cost:,.2f}원"
        else:
            return f"${cost:,.2f}"

    def _count_by_severity(self, results: List[CostDriftResult]) -> Dict[str, int]:
        """심각도별 카운트."""
        return {
            "critical": sum(1 for r in results if r.severity == Severity.CRITICAL),
            "high": sum(1 for r in results if r.severity == Severity.HIGH),
            "medium": sum(1 for r in results if r.severity == Severity.MEDIUM),
            "low": sum(1 for r in results if r.severity == Severity.LOW),
        }

    def _generate_result_summary(self, anomalies: List[CostDriftResult]) -> str:
        """결과 요약 문자열 생성."""
        if not anomalies:
            return "비용 이상이 탐지되지 않았습니다."

        severity_counts = self._count_by_severity(anomalies)
        services = [r.service_name for r in anomalies[:5]]
        accounts = list(set(r.account_name for r in anomalies))

        return (
            f"총 {len(anomalies)}건의 비용 이상이 탐지되었습니다. "
            f"[심각: {severity_counts['critical']}, "
            f"높음: {severity_counts['high']}, "
            f"보통: {severity_counts['medium']}, "
            f"낮음: {severity_counts['low']}] "
            f"영향 서비스: {', '.join(services)} | "
            f"영향 계정: {', '.join(accounts)}"
        )

    def _publish_events(
        self,
        results: List[CostDriftResult],
        summary: AlertSummary,
        email_to: List[str],
        email_cc: List[str],
        send_kakao: bool = False,
    ) -> None:
        """EventBridge에 이벤트 발행.

        Mock 모드에서는 기존 AlertEvent 형식 사용.
        Production 모드에서는 내부 알림 시스템 형식 사용.

        Args:
            results: CostDriftResult 목록
            summary: 알람 요약 정보
            email_to: 수신자 이메일 목록
            email_cc: 참조 이메일 목록
            send_kakao: 카카오톡 알림 발송 여부
        """
        try:
            if self.event_publisher.use_mock:
                # Mock 모드: AlertEvent 형식
                highest_severity = self._get_highest_severity(results)
                event = AlertEvent(
                    alert_type="cost_drift_batch",
                    severity=summary.severity_emoji,
                    severity_level=highest_severity.value,
                    title=summary.title,
                    message=summary.message,
                    affected_resources=[
                        {
                            "service_name": r.service_name,
                            "account_id": r.account_id,
                            "account_name": r.account_name,
                            "current_cost": r.current_cost,
                            "historical_average": r.historical_average,
                            "change_percent": r.change_percent,
                            "severity": r.severity.value,
                        }
                        for r in results
                    ],
                    action_required=highest_severity in (Severity.CRITICAL, Severity.HIGH),
                    account_names=list(set(r.account_name for r in results)),
                )
                self.event_publisher.publish_event(event, "Cost Drift Detected")
                self.logger.info("EventBridge event published (Mock mode)")
            else:
                # Production 모드: 내부 알림 시스템 형식
                kakao_channel = None
                if send_kakao:
                    kakao_channel = KakaoChannel(
                        severity='MAJOR',
                        category1=get_environment_account_name().upper(),
                        message=f"{summary.title}\n{summary.message}",
                    )

                # HTML 리포트 생성
                html_report = self.html_generator.generate_email_report(
                    results=results,
                    title=summary.title,
                )

                detail = ProductionAlertDetail(
                    subject=html_report.subject,
                    account_id=get_environment_account_name(),
                    email=EmailChannel(
                        to=email_to,
                        cc=email_cc,
                        from_email="alert-cost@hcs.com",
                        message=html_report.html_body,
                    ),
                    kakao=kakao_channel,
                )
                self.event_publisher.publish_production_event(detail, "Cost Drift Detected")
                self.logger.info("EventBridge event published (Production mode)")

        except Exception as e:
            self.logger.error(f"Failed to publish EventBridge event: {e}")

    def _get_highest_severity(self, results: List[CostDriftResult]) -> Severity:
        """가장 높은 심각도 반환."""
        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM]:
            if any(r.severity == severity for r in results):
                return severity
        return Severity.LOW

    def _result_to_dict(self, result: CostDriftResult) -> Dict[str, Any]:
        """CostDriftResult를 딕셔너리로 변환."""
        # 개별 summary 생성
        summary = self.summary_generator.generate(result)

        return {
            "service_name": result.service_name,
            "account_id": result.account_id,
            "account_name": result.account_name,
            "severity": result.severity.value,
            "confidence_score": result.confidence_score,
            "current_cost": result.current_cost,
            "historical_average": result.historical_average,
            "change_percent": result.change_percent,
            "spike_duration_days": result.spike_duration_days,
            "trend_direction": result.trend_direction,
            "spike_start_date": result.spike_start_date,
            "detection_method": result.detection_method,
            "summary": summary.message,  # 한글 summary
        }


# Lambda 핸들러
_handler_instance: Optional[BDPCostHandler] = None


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda 핸들러 함수.

    Args:
        event: Lambda 이벤트
        context: Lambda 컨텍스트

    Returns:
        처리 결과
    """
    global _handler_instance

    if _handler_instance is None:
        _handler_instance = BDPCostHandler()

    return _handler_instance.handle(event, context)
