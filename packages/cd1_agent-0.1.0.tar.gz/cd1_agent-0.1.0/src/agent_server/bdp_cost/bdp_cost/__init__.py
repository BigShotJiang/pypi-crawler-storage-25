"""
BDP Compact Agent - Multi-Account Cost Drift Detection.

Standalone package for AWS Cost Explorer based cost drift detection
with KakaoTalk alert integration via EventBridge.
"""

from .handler import BDPCostHandler, handler
from .services.anomaly_detector import (
    CostDriftDetector,
    CostDriftResult,
    Severity,
)
from .services.multi_account_provider import (
    AccountConfig,
    BaseMultiAccountProvider,
    ServiceCostData,
    create_provider,
)
from .services.summary_generator import AlertSummary, SummaryGenerator
from src.agent_server.bdp_common.eventbridge.publisher import EventPublisher, AlertEvent

__version__ = "0.1.0"

__all__ = [
    # Handler
    "BDPCostHandler",
    "handler",
    # Detector
    "CostDriftDetector",
    "CostDriftResult",
    "Severity",
    # Provider
    "AccountConfig",
    "BaseMultiAccountProvider",
    "ServiceCostData",
    "create_provider",
    # Summary
    "AlertSummary",
    "SummaryGenerator",
    # Event
    "EventPublisher",
    "AlertEvent",
]
