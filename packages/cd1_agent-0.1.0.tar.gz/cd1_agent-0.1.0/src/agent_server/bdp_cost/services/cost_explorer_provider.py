"""
Single-Account Cost Explorer Provider.

Lambda 실행 역할 기반 단일 계정 Cost Explorer 접근 (STS AssumeRole 제거).
"""

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Optional

from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


def _get_boto3_config() -> Optional[Any]:
    """Get boto3 Config with proxy settings from environment variables.

    Environment variables:
        BDP_HTTP_PROXY: HTTP proxy URL (e.g., http://proxy.example.com:8080)
        BDP_HTTPS_PROXY: HTTPS proxy URL (e.g., http://proxy.example.com:8080)

    Falls back to standard HTTP_PROXY/HTTPS_PROXY if BDP_ prefixed vars not set.

    Returns:
        botocore.config.Config with proxy settings, or None if no proxy configured
    """
    http_proxy = os.getenv("BDP_HTTP_PROXY") or os.getenv("HTTP_PROXY")
    https_proxy = os.getenv("BDP_HTTPS_PROXY") or os.getenv("HTTPS_PROXY")

    if not http_proxy and not https_proxy:
        return None

    from botocore.config import Config

    proxies = {}
    if http_proxy:
        proxies["http"] = http_proxy
    if https_proxy:
        proxies["https"] = https_proxy

    logger.info(f"Using proxy configuration: {proxies}")
    return Config(proxies=proxies)


@dataclass
class ServiceCostData:
    """Service cost data with historical values.

    Backward compatible with multi-account provider.
    """

    service_name: str
    account_id: str
    account_name: str
    current_cost: float
    historical_costs: list[float]
    timestamps: list[str]
    currency: str = "USD"


class BaseCostExplorerProvider(ABC):
    """Abstract base class for Cost Explorer providers."""

    @abstractmethod
    def get_cost_data(self, days: int = 14) -> list[ServiceCostData]:
        """Get service-level cost data.

        Args:
            days: Number of days of historical data

        Returns:
            List of ServiceCostData for each service
        """
        pass

    @abstractmethod
    def get_account_info(self) -> dict[str, str]:
        """Get current account information.

        Returns:
            Dict with account_id and account_name
        """
        pass

    @abstractmethod
    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: list[str],
    ) -> dict[str, dict[str, float]]:
        """기간별 서비스 비용 조회.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            {period: {service_name: cost}}
        """
        pass


class CostExplorerProvider(BaseCostExplorerProvider):
    """
    Single-Account Cost Explorer Provider.

    Uses Lambda execution role permissions to directly access Cost Explorer API.
    No STS AssumeRole - uses current credentials (Lambda execution role).

    Environment Variables:
        BDP_ACCOUNT_NAME: Account name for logging/alerts (default: 'default')
    """

    def __init__(
        self,
        account_name: str | None = None,
        region: str = "us-east-1",
    ):
        """Initialize single-account provider.

        Args:
            account_name: Account name for identification (logs, alerts)
            region: AWS region for Cost Explorer (must be us-east-1)
        """
        from src.common.services.aws_session import get_boto3_session

        self.region = region
        self.account_name = account_name or os.getenv("BDP_ACCOUNT_NAME", "default")
        self._account_id: str | None = None
        self._session = get_boto3_session(region=region)

        logger.info(
            f"CostExplorerProvider initialized: account_name={self.account_name}, region={region}"
        )

    def _get_account_id(self) -> str:
        """Get current account ID from STS GetCallerIdentity.

        Returns:
            AWS account ID
        """
        if self._account_id:
            return self._account_id

        sts_client = self._session.client("sts", region_name=self.region, config=_get_boto3_config())

        response = sts_client.get_caller_identity()
        self._account_id = response["Account"]
        logger.info(f"Resolved account ID: {self._account_id}")

        return self._account_id

    def get_account_info(self) -> dict[str, str]:
        """Get current account information.

        Returns:
            Dict with account_id and account_name
        """
        return {
            "account_id": self._get_account_id(),
            "account_name": self.account_name,
        }

    def get_cost_data(self, days: int = 14) -> list[ServiceCostData]:
        """Get service-level cost data from Cost Explorer.

        Args:
            days: Number of days of historical data

        Returns:
            List of ServiceCostData for each service
        """
        account_id = self._get_account_id()

        ce_client = self._session.client(
            "ce",
            region_name="us-east-1",  # Cost Explorer API only available in us-east-1
            config=_get_boto3_config(),
            verify=False,
        )

        end_date = get_kst_now()
        start_date = end_date - timedelta(days=days)

        response = ce_client.get_cost_and_usage(
            TimePeriod={
                "Start": start_date.strftime("%Y-%m-%d"),
                "End": end_date.strftime("%Y-%m-%d"),
            },
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
            GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}],
        )

        # Aggregate by service
        service_data: dict[str, dict[str, Any]] = {}

        for period in response.get("ResultsByTime", []):
            timestamp = period["TimePeriod"]["Start"]

            for group in period.get("Groups", []):
                service_name = group["Keys"][0] if group["Keys"] else "Unknown"
                cost = float(group.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", 0))

                if service_name not in service_data:
                    service_data[service_name] = {
                        "historical_costs": [],
                        "timestamps": [],
                    }

                service_data[service_name]["historical_costs"].append(cost)
                service_data[service_name]["timestamps"].append(timestamp)

        # Convert to ServiceCostData
        result = []
        for service_name, data in service_data.items():
            costs = data["historical_costs"]
            current_cost = costs[-1] if costs else 0.0

            result.append(
                ServiceCostData(
                    service_name=service_name,
                    account_id=account_id,
                    account_name=self.account_name,
                    current_cost=current_cost,
                    historical_costs=costs,
                    timestamps=data["timestamps"],
                )
            )

        logger.info(f"Retrieved {len(result)} services from account {self.account_name}")
        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: list[str],
    ) -> dict[str, dict[str, float]]:
        """기간별 서비스 비용 조회.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록 (e.g., ["202512", "202601"])

        Returns:
            {period: {service_name: cost}}
        """
        result: dict[str, dict[str, float]] = {}

        ce_client = self._session.client(
            "ce",
            region_name="us-east-1",
            config=_get_boto3_config(),
            verify=False,
        )

        for period in periods:
            start_date, end_date = self._period_to_date_range(granularity, period)

            # Granularity 결정 (API granularity)
            api_granularity = "MONTHLY" if granularity in ("monthly", "yearly") else "DAILY"

            response = ce_client.get_cost_and_usage(
                TimePeriod={
                    "Start": start_date,
                    "End": end_date,
                },
                Granularity=api_granularity,
                Metrics=["UnblendedCost"],
                GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}],
            )

            # 기간별 비용 합산
            period_costs: dict[str, float] = {}

            for time_period in response.get("ResultsByTime", []):
                for group in time_period.get("Groups", []):
                    service_name = group["Keys"][0] if group["Keys"] else "Unknown"
                    cost = float(group.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", 0))

                    if service_name not in period_costs:
                        period_costs[service_name] = 0.0
                    period_costs[service_name] += cost

            result[period] = period_costs

        logger.info(f"Retrieved cost data for {len(periods)} periods ({granularity}): {periods}")
        return result

    def _period_to_date_range(self, granularity: str, period: str) -> tuple[str, str]:
        """Period 문자열을 날짜 범위로 변환.

        Args:
            granularity: daily, weekly, monthly, yearly
            period: 기간 문자열

        Returns:
            (start_date, end_date) 튜플 (YYYY-MM-DD 형식)
        """
        if granularity == "daily":
            # "20260102" → ("2026-01-02", "2026-01-03")
            dt = datetime.strptime(period, "%Y%m%d")
            end_dt = dt + timedelta(days=1)
            return (dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))

        elif granularity == "weekly":
            # "2026W02" → 해당 주 월~일 (ISO week 기준)
            year = int(period[:4])
            week = int(period[5:])
            # ISO week: 월요일 시작
            first_day = datetime.strptime(f"{year}-W{week:02d}-1", "%Y-W%W-%w")
            last_day = first_day + timedelta(days=7)
            return (first_day.strftime("%Y-%m-%d"), last_day.strftime("%Y-%m-%d"))

        elif granularity == "monthly":
            # "202601" → ("2026-01-01", "2026-02-01")
            dt = datetime.strptime(period, "%Y%m")
            # 다음 달 첫날
            if dt.month == 12:
                next_month = dt.replace(year=dt.year + 1, month=1, day=1)
            else:
                next_month = dt.replace(month=dt.month + 1, day=1)
            return (dt.strftime("%Y-%m-%d"), next_month.strftime("%Y-%m-%d"))

        elif granularity == "yearly":
            # "2026" → ("2026-01-01", "2027-01-01")
            return (f"{period}-01-01", f"{int(period) + 1}-01-01")

        else:
            raise ValueError(f"Unknown granularity: {granularity}")


class LocalStackCostExplorerProvider(BaseCostExplorerProvider):
    """
    LocalStack-based Cost Explorer Provider.

    Reads cost data from DynamoDB tables for testing with LocalStack.

    DynamoDB Schema (bdp-cost-history):
        PK: ACCOUNT#{account_id}#SERVICE#{service_name}
        SK: DATE#{yyyy-mm-dd}
        Attributes: cost, account_name, service_name, timestamp
    """

    def __init__(
        self,
        account_id: str = "111111111111",
        account_name: str | None = None,
        endpoint_url: str | None = None,
        table_name: str = "bdp-cost-history",
        region: str = "ap-northeast-2",
    ):
        """Initialize LocalStack provider.

        Args:
            account_id: Simulated account ID
            account_name: Account name for identification
            endpoint_url: LocalStack endpoint URL
            table_name: DynamoDB table name
            region: AWS region
        """
        import boto3

        self.account_id = account_id
        self.account_name = account_name or os.getenv("BDP_ACCOUNT_NAME", "localstack-test")
        self.endpoint_url = endpoint_url or os.getenv(
            "LOCALSTACK_ENDPOINT", "http://localhost:4566"
        )
        self.table_name = table_name
        self.region = region

        self.dynamodb = boto3.client(
            "dynamodb",
            endpoint_url=self.endpoint_url,
            region_name=self.region,
        )

        logger.info(
            f"LocalStackCostExplorerProvider initialized: "
            f"endpoint={self.endpoint_url}, table={self.table_name}, "
            f"account={self.account_name}"
        )

    def get_account_info(self) -> dict[str, str]:
        """Get simulated account information.

        Returns:
            Dict with account_id and account_name
        """
        return {
            "account_id": self.account_id,
            "account_name": self.account_name,
        }

    def get_cost_data(self, days: int = 14) -> list[ServiceCostData]:
        """Get cost data from LocalStack DynamoDB.

        Args:
            days: Number of days of historical data

        Returns:
            List of ServiceCostData for each service
        """
        end_date = get_kst_now()
        start_date = end_date - timedelta(days=days)

        try:
            # Scan for account data
            response = self.dynamodb.scan(
                TableName=self.table_name,
                FilterExpression="begins_with(pk, :account_prefix) AND sk BETWEEN :start AND :end",
                ExpressionAttributeValues={
                    ":account_prefix": {"S": f"ACCOUNT#{self.account_id}"},
                    ":start": {"S": f"DATE#{start_date.strftime('%Y-%m-%d')}"},
                    ":end": {"S": f"DATE#{end_date.strftime('%Y-%m-%d')}"},
                },
            )

            return self._parse_dynamodb_response(response.get("Items", []))

        except Exception as e:
            logger.error(f"Failed to get LocalStack data: {e}")
            return []

    def _parse_dynamodb_response(self, items: list[dict[str, Any]]) -> list[ServiceCostData]:
        """Parse DynamoDB items into ServiceCostData.

        Args:
            items: DynamoDB items

        Returns:
            List of ServiceCostData
        """
        # Group by service
        service_data: dict[str, dict[str, Any]] = {}

        for item in items:
            pk = item.get("pk", {}).get("S", "")
            # Extract service name from PK: ACCOUNT#xxx#SERVICE#service_name
            parts = pk.split("#")
            service_name = parts[3] if len(parts) > 3 else "Unknown"

            sk = item.get("sk", {}).get("S", "")
            timestamp = sk.replace("DATE#", "") if sk.startswith("DATE#") else sk

            cost = float(item.get("cost", {}).get("N", "0"))

            if service_name not in service_data:
                service_data[service_name] = {
                    "historical_costs": [],
                    "timestamps": [],
                }

            service_data[service_name]["historical_costs"].append(cost)
            service_data[service_name]["timestamps"].append(timestamp)

        # Convert to ServiceCostData
        result = []
        for service_name, data in service_data.items():
            # Sort by timestamp
            sorted_pairs = sorted(
                zip(data["timestamps"], data["historical_costs"]),
                key=lambda x: x[0],
            )
            timestamps = [p[0] for p in sorted_pairs]
            costs = [p[1] for p in sorted_pairs]
            current_cost = costs[-1] if costs else 0.0

            result.append(
                ServiceCostData(
                    service_name=service_name,
                    account_id=self.account_id,
                    account_name=self.account_name,
                    current_cost=current_cost,
                    historical_costs=costs,
                    timestamps=timestamps,
                )
            )

        logger.info(f"Retrieved {len(result)} services from LocalStack")
        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: list[str],
    ) -> dict[str, dict[str, float]]:
        """기간별 비용 조회 (LocalStack - 빈 데이터 반환).

        LocalStack 테스트 환경에서는 빈 데이터를 반환합니다.
        실제 구현은 DynamoDB 쿼리로 대체 가능.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록

        Returns:
            {period: {service_name: cost}}
        """
        logger.warning("LocalStack get_cost_data_by_period not implemented, returning empty data")
        return {period: {} for period in periods}


class MockCostExplorerProvider(BaseCostExplorerProvider):
    """Mock provider for unit testing."""

    def __init__(
        self,
        account_id: str = "123456789012",
        account_name: str | None = None,
        mock_data: list[ServiceCostData] | None = None,
    ):
        """Initialize mock provider.

        Args:
            account_id: Mock account ID
            account_name: Mock account name
            mock_data: Pre-configured mock data
        """
        self.account_id = account_id
        self.account_name = account_name or os.getenv("BDP_ACCOUNT_NAME", "test-account")
        self.mock_data = mock_data
        self.call_history: list[dict[str, Any]] = []

        logger.info(
            f"MockCostExplorerProvider initialized: "
            f"account={self.account_name}, account_id={self.account_id}"
        )

    def get_account_info(self) -> dict[str, str]:
        """Get mock account information.

        Returns:
            Dict with account_id and account_name
        """
        self.call_history.append({"method": "get_account_info"})
        return {
            "account_id": self.account_id,
            "account_name": self.account_name,
        }

    def get_cost_data(self, days: int = 14) -> list[ServiceCostData]:
        """Get mock cost data.

        Args:
            days: Number of days (for recording)

        Returns:
            Mock cost data
        """
        self.call_history.append({"method": "get_cost_data", "days": days})

        if self.mock_data:
            return self.mock_data

        # Generate mock data
        return self._generate_mock_data(days)

    def _generate_mock_data(self, days: int) -> list[ServiceCostData]:
        """Generate realistic mock cost data."""
        import random

        result: list[ServiceCostData] = []

        services = [
            ("Amazon Athena", 250000, 0.15),  # KRW base, variance ratio
            ("AWS Lambda", 50000, 0.10),
            ("Amazon S3", 100000, 0.08),
            ("Amazon EC2", 500000, 0.12),
            ("Amazon DynamoDB", 80000, 0.10),
        ]

        end_date = get_kst_now()

        for service_name, base_cost, variance in services:
            historical_costs = []
            timestamps = []

            for day in range(days):
                date = end_date - timedelta(days=days - day - 1)
                # Add some variance
                daily_variance = random.uniform(-variance, variance)
                cost = base_cost * (1 + daily_variance)

                historical_costs.append(cost)
                timestamps.append(date.strftime("%Y-%m-%d"))

            result.append(
                ServiceCostData(
                    service_name=service_name,
                    account_id=self.account_id,
                    account_name=self.account_name,
                    current_cost=historical_costs[-1] if historical_costs else 0,
                    historical_costs=historical_costs,
                    timestamps=timestamps,
                    currency="KRW",
                )
            )

        return result

    def get_cost_data_by_period(
        self,
        granularity: str,
        periods: list[str],
    ) -> dict[str, dict[str, float]]:
        """기간별 비용 조회 (Mock - 가상 데이터 생성).

        미래 기간(아직 청구되지 않은 기간)은 빈 데이터를 반환하여
        실제 AWS Cost Explorer 동작을 모사합니다.

        Args:
            granularity: daily, weekly, monthly, yearly
            periods: 기간 목록

        Returns:
            {period: {service_name: cost}}
        """
        import random

        self.call_history.append(
            {
                "method": "get_cost_data_by_period",
                "granularity": granularity,
                "periods": periods,
            }
        )

        now = get_kst_now()
        if granularity == "monthly":
            current_cutoff = f"{now.year}{now.month:02d}"
        elif granularity == "daily":
            current_cutoff = f"{now.year}{now.month:02d}{now.day:02d}"
        else:
            current_cutoff = periods[-1]  # weekly/yearly는 전부 반환

        period_scale = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
            "yearly": 365,
        }
        scale = period_scale.get(granularity, 30)

        services = [
            ("Amazon Athena", 350_000),
            ("AWS Lambda", 180_000),
            ("Amazon S3", 500_000),
            ("Amazon EC2", 2_500_000),
            ("Amazon DynamoDB", 250_000),
            ("AWS Glue", 500_000),
            ("Amazon SageMaker", 1_000_000),
        ]

        # 월별 계절성 패턴: 월 인덱스(1~12) → 비용 배수
        seasonal = {
            1: 0.85,
            2: 0.90,
            3: 0.95,
            4: 1.00,
            5: 1.05,
            6: 1.10,
            7: 1.08,
            8: 1.02,
            9: 0.98,
            10: 1.12,
            11: 1.18,
            12: 1.15,
        }

        result: dict[str, dict[str, float]] = {}

        for idx, period in enumerate(periods):
            # 미래 기간은 빈 데이터 (AWS CE도 미래 비용을 반환하지 않음)
            if period > current_cutoff:
                result[period] = {}
                continue

            rng = random.Random(hash(period))

            # 월별 계절성 + 연간 3% 성장
            if granularity == "monthly" and len(period) == 6:
                month_num = int(period[4:6])
                season = seasonal.get(month_num, 1.0)
            else:
                season = 1.0
            growth = 1.0 + idx * 0.003  # 점진적 성장

            period_costs: dict[str, float] = {}
            for service_name, daily_cost in services:
                base_cost = daily_cost * scale
                # 서비스별 개별 변동 (합계에도 차이가 생기도록)
                variance = rng.uniform(-0.10, 0.10)
                cost = base_cost * (1 + variance) * growth * season
                period_costs[service_name] = round(cost, 2)

            result[period] = period_costs

        logger.info(
            f"[MOCK] Generated cost data for {len(periods)} periods ({granularity}): {periods}"
        )
        return result


def create_provider(
    provider_type: str | None = None,
    **kwargs: Any,
) -> BaseCostExplorerProvider:
    """Factory function to create appropriate provider.

    Args:
        provider_type: Provider type (real, localstack, mock)
        **kwargs: Additional provider-specific arguments

    Returns:
        Provider instance
    """
    provider_type = provider_type or os.getenv("BDP_PROVIDER", "mock")

    if provider_type == "localstack":
        return LocalStackCostExplorerProvider(**kwargs)
    elif provider_type == "real":
        return CostExplorerProvider(**kwargs)
    else:
        return MockCostExplorerProvider(**kwargs)
