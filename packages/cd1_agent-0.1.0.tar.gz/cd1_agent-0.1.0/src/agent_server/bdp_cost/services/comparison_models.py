"""
Cost Comparison Data Models.

기간별 비용 비교를 위한 데이터 모델 정의.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class Granularity(str, Enum):
    """비교 기간 단위."""

    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"


@dataclass
class ServiceCostComparison:
    """서비스별 비용 비교 결과."""

    service_name: str
    period1_cost: float  # 첫 번째 기간 비용
    period2_cost: float  # 두 번째 기간 비용
    cost_change: float  # 절대 변화량 (period2 - period1)
    change_percent: float  # 변화율 (%)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "service_name": self.service_name,
            "period1_cost": self.period1_cost,
            "period2_cost": self.period2_cost,
            "cost_change": self.cost_change,
            "change_percent": self.change_percent,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "ServiceCostComparison":
        return ServiceCostComparison(
            service_name=d["service_name"],
            period1_cost=d["period1_cost"],
            period2_cost=d["period2_cost"],
            cost_change=d["cost_change"],
            change_percent=d["change_percent"],
        )


@dataclass
class CostComparisonResult:
    """전체 비용 비교 결과."""

    granularity: Granularity
    period1: str  # e.g., "202512"
    period2: str  # e.g., "202601"
    account_id: str
    account_name: str

    # 총계
    total_period1_cost: float
    total_period2_cost: float
    total_change: float
    total_change_percent: float

    # 서비스별 비교 (비용 큰 순 정렬)
    service_comparisons: List[ServiceCostComparison] = field(default_factory=list)

    # 분석
    top_increases: List[ServiceCostComparison] = field(default_factory=list)  # 증가 Top 5
    top_decreases: List[ServiceCostComparison] = field(default_factory=list)  # 감소 Top 5

    def to_dict(self) -> Dict[str, Any]:
        return {
            "granularity": self.granularity.value,
            "period1": self.period1,
            "period2": self.period2,
            "account_id": self.account_id,
            "account_name": self.account_name,
            "total_period1_cost": self.total_period1_cost,
            "total_period2_cost": self.total_period2_cost,
            "total_change": self.total_change,
            "total_change_percent": self.total_change_percent,
            "service_comparisons": [s.to_dict() for s in self.service_comparisons],
            "top_increases": [s.to_dict() for s in self.top_increases],
            "top_decreases": [s.to_dict() for s in self.top_decreases],
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "CostComparisonResult":
        return CostComparisonResult(
            granularity=Granularity(d["granularity"]),
            period1=d["period1"],
            period2=d["period2"],
            account_id=d["account_id"],
            account_name=d["account_name"],
            total_period1_cost=d["total_period1_cost"],
            total_period2_cost=d["total_period2_cost"],
            total_change=d["total_change"],
            total_change_percent=d["total_change_percent"],
            service_comparisons=[
                ServiceCostComparison.from_dict(s) for s in d.get("service_comparisons", [])
            ],
            top_increases=[
                ServiceCostComparison.from_dict(s) for s in d.get("top_increases", [])
            ],
            top_decreases=[
                ServiceCostComparison.from_dict(s) for s in d.get("top_decreases", [])
            ],
        )
