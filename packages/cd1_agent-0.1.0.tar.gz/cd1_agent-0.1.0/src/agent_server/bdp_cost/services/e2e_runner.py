"""
BDP Cost Agent - E2E Runner Service.

E2E 시나리오 테스트를 실행하고 리포트를 생성하는 서비스 클래스.
scripts/run_cost_drift_e2e.py의 핵심 로직을 캡슐화.
"""

import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_cost.services.anomaly_detector import (
    CostDriftDetector,
    CostDriftResult,
    Severity,
)
from src.agent_server.bdp_cost.services.e2e_report_generator import (
    CostDriftE2EReportGenerator,
    E2EGroupResult,
    E2EReportData,
    E2ETestResult,
)
from src.agent_server.bdp_cost.services.summary_generator import SummaryGenerator


@dataclass
class E2ERunResult:
    """E2E 실행 결과."""

    pass_rate: float
    passed: int
    failed: int
    total: int
    e2e_report_path: str
    scenarios: List[Dict[str, Any]]


# ── Severity helpers ──

SEVERITY_ORDER = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
}


def _severity_distance(expected: Severity, actual: Severity) -> int:
    return abs(SEVERITY_ORDER[expected] - SEVERITY_ORDER[actual])


class CostE2ERunner:
    """E2E 시나리오 테스트 실행기 (Mock 전용)."""

    def __init__(self, sensitivity: float = 0.7):
        self._detector = CostDriftDetector(sensitivity=sensitivity)
        self._summary_gen = SummaryGenerator(currency="KRW", enable_chart=True)

    def run_all(
        self,
        output_dir: str = "reports/",
        target_groups: Optional[set] = None,
    ) -> E2ERunResult:
        """전체 E2E 시나리오 실행 및 리포트 생성."""
        from tests.agents.bdp_cost.scenarios.scenario_factory import ScenarioFactory

        # 1. 시나리오 로드
        all_groups = ScenarioFactory.get_all_groups()
        groups_map = {
            g.id: {"name": g.name_ko, "name_ko": g.name_ko, "emoji": g.emoji}
            for g in all_groups
        }

        if target_groups:
            scenarios = []
            for g in all_groups:
                if g.id in target_groups:
                    scenarios.extend(g.scenarios)
        else:
            scenarios = ScenarioFactory.get_all_scenarios()

        # 2. 시나리오 실행
        results: List[E2ETestResult] = []
        for scenario in scenarios:
            result = self._run_scenario(scenario)
            results.append(result)

        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        pass_rate = (passed / len(results) * 100) if results else 0

        # 3. 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        report_data = self._build_report_data(results, groups_map)
        e2e_path = str(output_path / "cost_drift_e2e_report.html")
        CostDriftE2EReportGenerator().generate_report(report_data, e2e_path)

        return E2ERunResult(
            pass_rate=pass_rate,
            passed=passed,
            failed=failed,
            total=len(results),
            e2e_report_path=e2e_path,
            scenarios=[
                {
                    "scenario_id": r.scenario_id,
                    "scenario_name_ko": r.scenario_name_ko,
                    "passed": r.passed,
                    "expected_severity": r.expected_severity,
                    "actual_severity": r.actual_severity,
                }
                for r in results
            ],
        )

    def _run_scenario(self, scenario) -> E2ETestResult:
        """단일 시나리오 실행."""
        from tests.agents.bdp_cost.scenarios.scenario_factory import ScenarioFactory

        cost_data = ScenarioFactory.generate_cost_data(scenario)

        start = time.perf_counter()
        result: CostDriftResult = self._detector.analyze_service(cost_data)
        elapsed_ms = (time.perf_counter() - start) * 1000

        distance = _severity_distance(scenario.expected_severity, result.severity)
        passed = distance <= 1

        if passed:
            if distance == 0:
                pass_reason = f"정확 일치: {result.severity.value}"
            else:
                pass_reason = (
                    f"허용 범위 내: 예상={scenario.expected_severity.value}, "
                    f"실제={result.severity.value} (거리={distance})"
                )
        else:
            pass_reason = (
                f"심각도 불일치: 예상={scenario.expected_severity.value}, "
                f"실제={result.severity.value} (거리={distance}, 최대=1)"
            )

        account_name = getattr(scenario, "account_name", "") or "prod-main"

        chart_url = ""
        alert_title = ""
        alert_message = ""
        if result.is_anomaly:
            try:
                alert_summary = self._summary_gen.generate(result)
                chart_url = alert_summary.chart_url or ""
                alert_title = alert_summary.title
                alert_message = alert_summary.message
            except Exception:
                pass

        return E2ETestResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            scenario_name_ko=scenario.name_ko,
            description_ko=scenario.description_ko,
            group_id=scenario.group_id,
            group_name=scenario.group_name,
            service_name=scenario.service_name,
            expected_severity=scenario.expected_severity.value,
            expected_detection_method=scenario.expected_detection_method,
            actual_severity=result.severity.value,
            actual_detection_method=result.detection_method,
            actual_confidence=result.confidence_score,
            actual_change_percent=result.change_percent,
            actual_is_anomaly=result.is_anomaly,
            passed=passed,
            pass_reason=pass_reason,
            execution_time_ms=elapsed_ms,
            pattern_type=scenario.pattern_type,
            pattern_contexts=result.pattern_contexts,
            historical_costs=result.historical_costs,
            timestamps=result.timestamps,
            account_name=account_name,
            chart_url=chart_url,
            alert_title=alert_title,
            alert_message=alert_message,
        )

    @staticmethod
    def _build_report_data(results, groups_map) -> E2EReportData:
        """리포트 데이터 빌드."""
        grouped = defaultdict(list)
        for r in results:
            grouped[r.group_id].append(r)

        group_results = []
        for gid in sorted(grouped.keys(), key=lambda x: int(x)):
            g_results = grouped[gid]
            g_passed = sum(1 for r in g_results if r.passed)
            g_total = len(g_results)
            g_info = groups_map.get(gid, {})

            ko_name = g_info.get("name_ko", "")
            if ko_name:
                for r in g_results:
                    r.group_name = ko_name

            group_results.append(
                E2EGroupResult(
                    group_id=gid,
                    group_name=g_info.get("name", f"Group {gid}"),
                    group_name_ko=g_info.get("name_ko", ""),
                    emoji=g_info.get("emoji", ""),
                    total=g_total,
                    passed=g_passed,
                    failed=g_total - g_passed,
                    pass_rate=(g_passed / g_total * 100) if g_total else 0,
                    results=g_results,
                )
            )

        total = len(results)
        passed = sum(1 for r in results if r.passed)
        all_latencies = [r.execution_time_ms for r in results]

        return E2EReportData(
            total=total,
            passed=passed,
            failed=total - passed,
            pass_rate=(passed / total * 100) if total else 0,
            avg_latency_ms=sum(all_latencies) / len(all_latencies) if all_latencies else 0,
            groups=group_results,
            all_results=results,
        )
