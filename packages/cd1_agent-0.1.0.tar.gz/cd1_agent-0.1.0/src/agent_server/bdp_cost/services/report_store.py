"""
Cost Report Store - DB storage layer for cost reports.

비용 리포트 저장소.
Provider 패턴으로 MySQL/SQLite/Mock 지원.
월비교, 월누적비교, 일단위 리포트를 DB에 저장.
"""

import json
import logging
import os
import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_common.stores.base import KST, get_kst_now, BaseMySqlProvider, BaseSQLiteProvider

logger = logging.getLogger(__name__)


@dataclass
class CostReport:
    """비용 리포트."""

    id: str
    run_timestamp: datetime
    report_type: str          # daily, monthly_comparison, monthly_cumulative
    title: str
    description: str
    html_report: str
    raw_data_json: str = ""
    status: str = "completed"


class CostReportStoreProvider(ABC):
    """비용 리포트 저장소 추상 프로바이더."""

    @abstractmethod
    def ensure_tables(self) -> None:
        pass

    @abstractmethod
    def save_report(self, report: CostReport) -> CostReport:
        pass

    @abstractmethod
    def get_report(self, report_id: str) -> Optional[CostReport]:
        pass

    @abstractmethod
    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[CostReport]:
        pass

    @abstractmethod
    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        pass


class SQLiteProvider(BaseSQLiteProvider, CostReportStoreProvider):
    """SQLite 프로바이더 (유닛 테스트용)."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cost_reports (
                id TEXT PRIMARY KEY,
                run_timestamp TEXT NOT NULL,
                report_type TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                html_report TEXT NOT NULL,
                raw_data_json TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'completed',
                created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_cost_reports_timestamp
            ON cost_reports (run_timestamp)
        """)
        self.conn.commit()

    def save_report(self, report: CostReport) -> CostReport:
        cursor = self.conn.cursor()
        now = get_kst_now().isoformat() + "Z"
        cursor.execute(
            """
            INSERT OR REPLACE INTO cost_reports
            (id, run_timestamp, report_type, title, description,
             html_report, raw_data_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                report.id,
                report.run_timestamp.isoformat() if isinstance(report.run_timestamp, datetime) else report.run_timestamp,
                report.report_type,
                report.title,
                report.description,
                report.html_report,
                report.raw_data_json,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[CostReport]:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM cost_reports WHERE id = ?", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[CostReport]:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)
        if report_type:
            conditions.append("report_type = ?")
            params.append(report_type)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM cost_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM cost_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: sqlite3.Row) -> CostReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))
        return CostReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            report_type=row["report_type"],
            title=row["title"],
            description=row["description"],
            html_report=row["html_report"],
            raw_data_json=row["raw_data_json"] if "raw_data_json" in row.keys() else "",
            status=row["status"],
        )


class MySqlProvider(BaseMySqlProvider, CostReportStoreProvider):
    """MySQL 비용 리포트 저장소."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cost_reports (
                id VARCHAR(36) PRIMARY KEY,
                run_timestamp DATETIME NOT NULL,
                report_type VARCHAR(50) NOT NULL,
                title VARCHAR(200) NOT NULL,
                description TEXT NOT NULL,
                html_report LONGTEXT NOT NULL,
                raw_data_json LONGTEXT NOT NULL DEFAULT '',
                status VARCHAR(20) NOT NULL DEFAULT 'completed',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_cost_reports_timestamp (run_timestamp),
                INDEX idx_cost_reports_type (report_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        self.conn.commit()
        logger.info("MySQL cost_reports table ensured")

    def save_report(self, report: CostReport) -> CostReport:
        cursor = self.conn.cursor()
        now = get_kst_now()
        cursor.execute(
            """
            INSERT INTO cost_reports
            (id, run_timestamp, report_type, title, description,
             html_report, raw_data_json, status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                run_timestamp=VALUES(run_timestamp), report_type=VALUES(report_type),
                title=VALUES(title), description=VALUES(description),
                html_report=VALUES(html_report), raw_data_json=VALUES(raw_data_json),
                status=VALUES(status)
            """,
            (
                report.id,
                report.run_timestamp if isinstance(report.run_timestamp, datetime) else datetime.fromisoformat(report.run_timestamp),
                report.report_type,
                report.title,
                report.description,
                report.html_report,
                report.raw_data_json,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[CostReport]:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM cost_reports WHERE id = %s", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[CostReport]:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)
        if report_type:
            conditions.append("report_type = %s")
            params.append(report_type)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM cost_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT %s OFFSET %s
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM cost_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: Dict[str, Any]) -> CostReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))
        return CostReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            report_type=row["report_type"],
            title=row["title"],
            description=row["description"],
            html_report=row["html_report"],
            raw_data_json=row.get("raw_data_json", ""),
            status=row["status"],
        )


class MockProvider(CostReportStoreProvider):
    """Mock 프로바이더 (개발/테스트용)."""

    def __init__(self):
        self._reports: Dict[str, CostReport] = {}
        logger.info("Mock cost report provider initialized")

    def ensure_tables(self) -> None:
        pass

    def save_report(self, report: CostReport) -> CostReport:
        self._reports[report.id] = report
        return report

    def get_report(self, report_id: str) -> Optional[CostReport]:
        return self._reports.get(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[CostReport]:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        if report_type:
            reports = [r for r in reports if r.report_type == report_type]
        reports.sort(key=lambda r: r.run_timestamp, reverse=True)
        return reports[offset:offset + limit]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        return len(reports)


class CostReportStore:
    """비용 리포트 저장소 (Facade).

    Provider 패턴으로 MySQL/SQLite/Mock 지원.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
    ):
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)
        logger.info(f"CostReportStore initialized with {provider} provider")

    def _create_provider(
        self, provider: str, secret_id: Optional[str] = None, db: Optional[str] = None
    ) -> CostReportStoreProvider:
        if provider == "sqlite":
            db_path = os.getenv("REPORT_SQLITE_PATH", ":memory:")
            return SQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                raise ValueError("secret_id is required for MySQL provider")
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return MySqlProvider(secret_id=secret_id, db=db or "", region=region)
        else:
            return MockProvider()

    def ensure_tables(self) -> None:
        self._provider.ensure_tables()

    def save_report(self, report: CostReport) -> CostReport:
        return self._provider.save_report(report)

    def get_report(self, report_id: str) -> Optional[CostReport]:
        return self._provider.get_report(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[CostReport]:
        return self._provider.list_reports(
            start_date=start_date,
            end_date=end_date,
            report_type=report_type,
            limit=limit,
            offset=offset,
        )

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        return self._provider.get_report_count(
            start_date=start_date,
            end_date=end_date,
        )
