"""
Cost Event Publisher - EventBridge Wrapper for BDP Cost.

bdp_common EventPublisher를 래핑하여 비용 드리프트 전용 publish_batch_alert 메서드 제공.
"""

import logging
from typing import List, Optional

from src.agent_server.bdp_common.eventbridge.publisher import (
    AlertEvent,
    EventPublisher as BaseEventPublisher,
)
from src.agent_server.bdp_cost.services.anomaly_detector import CostDriftResult, Severity

logger = logging.getLogger(__name__)


class EventPublisher(BaseEventPublisher):
    """Cost 전용 EventPublisher.

    bdp_common EventPublisher를 상속하고 publish_batch_alert 메서드를 추가.
    """

    def publish_batch_alert(
        self,
        results: List[CostDriftResult],
        summary,
        hitl_request_id: Optional[str] = None,
    ) -> bool:
        """비용 드리프트 결과를 일괄 발행.

        Args:
            results: CostDriftResult 목록
            summary: AlertSummary (generate_batch_summary 결과)
            hitl_request_id: HITL 요청 ID

        Returns:
            발행 성공 여부
        """
        if not results:
            logger.info("No cost drift results to publish")
            return True

        anomalies = [r for r in results if r.is_anomaly]
        if not anomalies:
            logger.info("No anomalies to publish")
            return True

        # severity 판별
        severity_map = {
            Severity.CRITICAL: ("🔴", "critical"),
            Severity.HIGH: ("🟠", "high"),
            Severity.MEDIUM: ("🟡", "medium"),
            Severity.LOW: ("🟢", "low"),
        }
        highest = max(anomalies, key=lambda r: r.confidence_score)
        emoji, level = severity_map.get(highest.severity, ("⚪", "low"))

        event = AlertEvent(
            alert_type="cost_drift_batch",
            severity=emoji,
            severity_level=level,
            title=summary.title if hasattr(summary, "title") else str(summary),
            message=summary.message if hasattr(summary, "message") else "",
            affected_resources=[
                {
                    "service_name": r.service_name,
                    "account_id": r.account_id,
                    "current_cost": r.current_cost,
                    "historical_average": r.historical_average,
                    "change_percent": r.change_percent,
                    "severity": r.severity.value,
                }
                for r in anomalies
            ],
            action_required=any(
                r.severity in (Severity.CRITICAL, Severity.HIGH) for r in anomalies
            ),
            hitl_request_id=hitl_request_id,
            metadata={
                "total_anomalies": len(anomalies),
                "by_severity": {
                    "critical": sum(1 for r in anomalies if r.severity == Severity.CRITICAL),
                    "high": sum(1 for r in anomalies if r.severity == Severity.HIGH),
                    "medium": sum(1 for r in anomalies if r.severity == Severity.MEDIUM),
                    "low": sum(1 for r in anomalies if r.severity == Severity.LOW),
                },
            },
        )

        return self.publish_event(event, "Cost Drift Detected")
