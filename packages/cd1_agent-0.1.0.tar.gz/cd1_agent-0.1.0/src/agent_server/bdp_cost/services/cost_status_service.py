"""Cost Status Service - AWS 서비스별 비용 현황 대시보드."""

import logging
from datetime import datetime

from src.common.timezone import KST
from typing import Any

from .cost_explorer_provider import create_provider

logger = logging.getLogger(__name__)


class CostStatusService:
    """AWS 서비스별 비용 현황을 제공하는 대시보드 서비스.

    CostExplorerProvider를 통해 서비스별 일별 비용 데이터를 조회하고,
    전일 대비 변화율, 14일 추세 등을 계산하여 대시보드에 표시합니다.

    bdp_cost 패키지가 없으면 MockCostExplorerProvider를 사용합니다.
    """

    def __init__(self, provider_type: str | None = None):
        self._provider = None
        self._provider_type = provider_type
        self._initialized = False

    @property
    def _is_mock(self) -> bool:
        """현재 provider가 mock인지 여부."""
        from .cost_explorer_provider import MockCostExplorerProvider

        return isinstance(self._provider, MockCostExplorerProvider)

    def _ensure_provider(self):
        """Lazy init: 첫 호출 시 provider 생성."""
        if self._initialized:
            return
        self._initialized = True

        try:
            self._provider = create_provider(self._provider_type)
            logger.info(f"CostStatusService: provider={type(self._provider).__name__}")
        except Exception as e:
            logger.warning(f"Failed to create cost provider: {e}")
            self._provider = None

    def get_dashboard_data(self, days: int = 14) -> dict[str, Any]:
        """대시보드 데이터 조회.

        Args:
            days: 조회할 과거 일수 (기본 14일)

        Returns:
            summary, services, account_info를 포함한 딕셔너리
        """
        self._ensure_provider()

        if not self._provider:
            return self._empty_dashboard()

        try:
            cost_data_list = self._provider.get_cost_data(days=days)
            account_info = self._provider.get_account_info()
        except Exception as e:
            logger.error(f"Failed to fetch cost data: {e}")
            return self._empty_dashboard(error=str(e))

        services = self._build_service_rows(cost_data_list)
        summary = self._build_summary(services, account_info)

        return {
            "summary": summary,
            "services": services,
            "account_info": account_info,
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
        }

    def _build_service_rows(self, cost_data_list: list) -> list[dict[str, Any]]:
        """ServiceCostData 목록을 대시보드용 행 데이터로 변환."""
        rows = []
        for scd in cost_data_list:
            costs = scd.historical_costs
            if not costs:
                continue

            current = costs[-1]
            previous = costs[-2] if len(costs) >= 2 else 0.0
            avg_cost = sum(costs) / len(costs) if costs else 0.0

            # 전일 대비 변화율
            if previous > 0:
                change_pct = ((current - previous) / previous) * 100
            else:
                change_pct = 0.0

            # 추세: 최근 7일 vs 이전 7일
            if len(costs) >= 8:
                recent_avg = sum(costs[-7:]) / 7
                older_avg = sum(costs[:-7]) / max(len(costs) - 7, 1)
                if older_avg > 0:
                    trend_pct = ((recent_avg - older_avg) / older_avg) * 100
                else:
                    trend_pct = 0.0
            else:
                trend_pct = 0.0

            # 추세 방향
            if trend_pct > 5:
                trend = "up"
            elif trend_pct < -5:
                trend = "down"
            else:
                trend = "stable"

            rows.append(
                {
                    "service_name": scd.service_name,
                    "current_cost": round(current, 2),
                    "previous_cost": round(previous, 2),
                    "avg_cost": round(avg_cost, 2),
                    "change_pct": round(change_pct, 1),
                    "trend": trend,
                    "trend_pct": round(trend_pct, 1),
                    "currency": scd.currency,
                    "sparkline": [round(c, 2) for c in costs[-7:]],  # 최근 7일
                }
            )

        # 현재 비용 내림차순 정렬
        rows.sort(key=lambda r: r["current_cost"], reverse=True)
        return rows

    def _build_summary(
        self, services: list[dict[str, Any]], account_info: dict[str, str]
    ) -> dict[str, Any]:
        """요약 카드 데이터 생성."""
        total_today = sum(s["current_cost"] for s in services)
        total_yesterday = sum(s["previous_cost"] for s in services)
        currency = services[0]["currency"] if services else "KRW"

        if total_yesterday > 0:
            total_change_pct = ((total_today - total_yesterday) / total_yesterday) * 100
        else:
            total_change_pct = 0.0

        # 이상 서비스 카운트 (변화율 ±30% 이상)
        anomaly_count = sum(1 for s in services if abs(s["change_pct"]) >= 30)

        return {
            "total_today": round(total_today, 2),
            "total_yesterday": round(total_yesterday, 2),
            "total_change_pct": round(total_change_pct, 1),
            "service_count": len(services),
            "anomaly_count": anomaly_count,
            "account_id": account_info.get("account_id", ""),
            "account_name": account_info.get("account_name", ""),
            "currency": currency,
        }

    def get_monthly_cost_data(self, year: int) -> dict[str, Any]:
        """연간 월별 비용 데이터 조회.

        Args:
            year: 조회 연도

        Returns:
            year, budget, months, projection_method를 포함한 딕셔너리
        """
        self._ensure_provider()

        if not self._provider:
            return self._empty_monthly_data(year)

        try:
            periods = [f"{year}{m:02d}" for m in range(1, 13)]
            raw = self._provider.get_cost_data_by_period(granularity="monthly", periods=periods)
        except Exception as e:
            logger.error(f"Failed to fetch monthly cost data: {e}")
            return self._empty_monthly_data(year, error=str(e))

        now = datetime.now(KST)
        current_ym = f"{now.year}{now.month:02d}"

        months: list[dict[str, Any]] = []
        for period in periods:
            services = raw.get(period, {})
            total = sum(services.values())
            months.append(
                {
                    "month": period,
                    "services": services,
                    "total": round(total, 2),
                    "is_projected": False,
                }
            )

        # 미래 기간: 최근 3개월 이동평균으로 예상치 설정
        actual_months = [m for m in months if m["month"] <= current_ym and m["total"] > 0]
        recent = actual_months[-3:] if len(actual_months) >= 3 else actual_months
        avg_total = round(sum(m["total"] for m in recent) / len(recent), 2) if recent else 0

        for m in months:
            if m["month"] > current_ym:
                m["is_projected"] = True
                m["services"] = {}
                m["total"] = avg_total

        return {
            "year": year,
            "budget": {
                "monthly_target": 160_000_000,
                "annual_total": 1_920_000_000,
            },
            "months": months,
            "projection_method": "3개월 이동평균",
            "is_mock": self._is_mock,
        }

    def get_daily_cost_data(self, year: int, month: int) -> dict[str, Any]:
        """해당 월의 일별 비용 데이터 조회.

        Args:
            year: 조회 연도
            month: 조회 월 (1-12)

        Returns:
            year, month, daily_target, days, projection_method를 포함한 딕셔너리
        """
        self._ensure_provider()

        if not self._provider:
            return self._empty_daily_data(year, month)

        try:
            import calendar

            days_in_month = calendar.monthrange(year, month)[1]
            periods = [f"{year}{month:02d}{d:02d}" for d in range(1, days_in_month + 1)]
            raw = self._provider.get_cost_data_by_period(granularity="daily", periods=periods)
        except Exception as e:
            logger.error(f"Failed to fetch daily cost data: {e}")
            return self._empty_daily_data(year, month, error=str(e))

        now = datetime.now(KST)
        current_ymd = f"{now.year}{now.month:02d}{now.day:02d}"

        days: list[dict[str, Any]] = []
        for period in periods:
            services = raw.get(period, {})
            total = sum(services.values())
            days.append(
                {
                    "day": period,
                    "services": services,
                    "total": round(total, 2),
                    "is_projected": False,
                }
            )

        # 미래 일자: 당월 실데이터 일평균으로 예상치 설정
        actual_days = [d for d in days if d["day"] <= current_ymd and d["total"] > 0]
        avg_total = (
            round(sum(d["total"] for d in actual_days) / len(actual_days), 2) if actual_days else 0
        )

        for d in days:
            if d["day"] > current_ymd:
                d["is_projected"] = True
                d["services"] = {}
                d["total"] = avg_total

        import calendar

        days_in_month = calendar.monthrange(year, month)[1]
        daily_target = round(160_000_000 / days_in_month, 2)

        return {
            "year": year,
            "month": month,
            "daily_target": daily_target,
            "days": days,
            "projection_method": "당월 일평균",
            "is_mock": self._is_mock,
        }

    def _empty_daily_data(self, year: int, month: int, error: str | None = None) -> dict[str, Any]:
        """Provider 없을 때 빈 일별 데이터."""
        import calendar

        days_in_month = calendar.monthrange(year, month)[1]
        periods = [f"{year}{month:02d}{d:02d}" for d in range(1, days_in_month + 1)]
        daily_target = round(160_000_000 / days_in_month, 2)
        return {
            "year": year,
            "month": month,
            "daily_target": daily_target,
            "days": [{"day": p, "services": {}, "total": 0} for p in periods],
            "error": error,
        }

    def _empty_monthly_data(self, year: int, error: str | None = None) -> dict[str, Any]:
        """Provider 없을 때 빈 월별 데이터."""
        periods = [f"{year}{m:02d}" for m in range(1, 13)]
        return {
            "year": year,
            "budget": {
                "monthly_target": 160_000_000,
                "annual_total": 1_920_000_000,
            },
            "months": [{"month": p, "services": {}, "total": 0} for p in periods],
            "error": error,
        }

    def _empty_dashboard(self, error: str | None = None) -> dict[str, Any]:
        """Provider 없을 때 빈 대시보드 데이터."""
        return {
            "summary": {
                "total_today": 0,
                "total_yesterday": 0,
                "total_change_pct": 0,
                "service_count": 0,
                "anomaly_count": 0,
                "account_id": "",
                "account_name": "",
                "currency": "KRW",
            },
            "services": [],
            "account_info": {"account_id": "", "account_name": ""},
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
            "error": error,
        }
