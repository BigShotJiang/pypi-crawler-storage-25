"""
E2E Scenario Test Report Generator for BDP Cost Agent.

Material Design 기반 HTML 리포트 생성.
확장/축소 가능한 개별 테스트 카드, 그룹별 진행률, 요약 통계 포함.
"""

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.styles import (
    MD3_COLORS,
    SEVERITY_COLORS,
    ReportStyles,
)

logger = logging.getLogger(__name__)


@dataclass
class E2ETestResult:
    """개별 E2E 테스트 결과."""

    scenario_id: str
    scenario_name: str
    scenario_name_ko: str
    description_ko: str
    group_id: str
    group_name: str
    service_name: str
    # Expected
    expected_severity: str
    expected_detection_method: str
    # Actual
    actual_severity: str
    actual_detection_method: str
    actual_confidence: float
    actual_change_percent: float
    actual_is_anomaly: bool
    # Pass/Fail
    passed: bool
    pass_reason: str
    # Timing
    execution_time_ms: float
    # Optional details
    pattern_type: str = ""
    pattern_contexts: List[str] = field(default_factory=list)
    historical_costs: Optional[List[float]] = None
    timestamps: Optional[List[str]] = None
    account_name: str = ""
    chart_url: Optional[str] = None
    alert_title: str = ""
    alert_message: str = ""


@dataclass
class E2EGroupResult:
    """그룹별 테스트 결과 요약."""

    group_id: str
    group_name: str
    group_name_ko: str
    emoji: str
    total: int
    passed: int
    failed: int
    pass_rate: float
    results: List[E2ETestResult]


@dataclass
class E2EReportData:
    """전체 E2E 리포트 데이터."""

    total: int
    passed: int
    failed: int
    pass_rate: float
    avg_latency_ms: float
    groups: List[E2EGroupResult]
    all_results: List[E2ETestResult]
    generated_at: str = ""


class CostDriftE2EReportGenerator(HTMLReportBase):
    """
    BDP Cost Agent E2E 시나리오 테스트 리포트 생성기.

    HTMLReportBase를 상속하여 Material Design 스타일의 리포트를 생성합니다.
    hdsp_agent report.html 스타일의 확장/축소 가능한 테스트 카드를 포함합니다.
    """

    def __init__(self):
        super().__init__(
            title="BDP 비용 에이전트 - E2E 시나리오 테스트 리포트",
            styles=ReportStyles(),
        )

    def _wrap_html(self, content: str) -> str:
        """HTML 래퍼 (추가 CSS/JS 포함)."""
        timestamp = get_kst_now().strftime("%Y-%m-%d %H:%M:%S KST")

        return f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title}</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        {self.styles.get_base_css()}
        {self._get_icon_css()}
        {self._get_e2e_css()}
    </style>
</head>
<body>
    <div class="header e2e-header">
        <div class="container">
            <h1 class="header-title">
                {self._icon('science', size='lg', color='on-surface', inline=True)}
                {self.title}
            </h1>
            <p class="header-subtitle">생성 시각: {timestamp}</p>
        </div>
    </div>
    <div class="container">
        {content}
    </div>
    {self._get_e2e_js()}
</body>
</html>"""

    def _get_e2e_css(self) -> str:
        """E2E 리포트 전용 CSS."""
        return f"""
        .e2e-header {{
            background: linear-gradient(135deg, {MD3_COLORS['primary']} 0%, #0D47A1 100%);
            color: white;
            padding: 32px 0;
        }}
        .e2e-header .header-title {{
            color: white;
            font-size: 28px;
        }}
        .e2e-header .header-subtitle {{
            color: rgba(255,255,255,0.8);
        }}

        .grid-5 {{
            grid-template-columns: repeat(5, 1fr);
        }}
        @media (max-width: 768px) {{
            .grid-5 {{ grid-template-columns: repeat(2, 1fr); }}
        }}

        /* Group Breakdown */
        .group-bar {{
            margin-bottom: 12px;
        }}
        .group-bar-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
            font-size: 14px;
        }}
        .group-bar-track {{
            background: {MD3_COLORS['outline_variant']};
            border-radius: 4px;
            height: 24px;
            overflow: hidden;
        }}
        .group-bar-fill {{
            height: 100%;
            border-radius: 4px;
            display: flex;
            align-items: center;
            padding-left: 8px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            transition: width 0.5s ease;
        }}

        /* Test Cards */
        .test-card {{
            background: {MD3_COLORS['surface']};
            border: 1px solid {MD3_COLORS['outline_variant']};
            border-radius: 8px;
            margin-bottom: 8px;
            overflow: hidden;
            transition: box-shadow 0.2s;
        }}
        .test-card:hover {{
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .test-card.pass {{
            border-left: 4px solid {MD3_COLORS['success']};
        }}
        .test-card.fail {{
            border-left: 4px solid {MD3_COLORS['error']};
        }}

        .test-card-header {{
            display: flex;
            align-items: center;
            padding: 12px 16px;
            cursor: pointer;
            user-select: none;
            gap: 12px;
        }}
        .test-card-header:hover {{
            background: {MD3_COLORS['surface_variant']};
        }}

        .test-card-status {{
            flex-shrink: 0;
        }}
        .test-card-id {{
            font-weight: 600;
            font-size: 13px;
            color: {MD3_COLORS['on_surface_variant']};
            min-width: 40px;
        }}
        .test-card-name {{
            flex: 1;
            font-weight: 500;
            font-size: 14px;
        }}
        .test-card-meta {{
            display: flex;
            gap: 8px;
            align-items: center;
            flex-shrink: 0;
        }}
        .test-card-time {{
            font-size: 12px;
            color: {MD3_COLORS['on_surface_variant']};
        }}
        .test-card-chevron {{
            transition: transform 0.2s;
            color: {MD3_COLORS['on_surface_variant']};
        }}
        .test-card.expanded .test-card-chevron {{
            transform: rotate(180deg);
        }}

        .test-card-body {{
            display: none;
            padding: 0 16px 16px;
            border-top: 1px solid {MD3_COLORS['outline_variant']};
        }}
        .test-card.expanded .test-card-body {{
            display: block;
        }}

        .detail-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 12px;
        }}
        .detail-section {{
            background: {MD3_COLORS['surface_variant']};
            border-radius: 8px;
            padding: 12px;
        }}
        .detail-section h4 {{
            font-size: 13px;
            color: {MD3_COLORS['on_surface_variant']};
            margin-bottom: 8px;
            letter-spacing: 0.3px;
        }}
        .detail-row {{
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            font-size: 13px;
        }}
        .detail-label {{
            color: {MD3_COLORS['on_surface_variant']};
        }}
        .detail-value {{
            font-weight: 500;
        }}

        .group-badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
            background: {MD3_COLORS['primary_container']};
            color: {MD3_COLORS['on_primary_container']};
        }}

        .confidence-bar {{
            display: inline-block;
            width: 60px;
            height: 6px;
            background: {MD3_COLORS['outline_variant']};
            border-radius: 3px;
            overflow: hidden;
            vertical-align: middle;
            margin-left: 4px;
        }}
        .confidence-bar-fill {{
            height: 100%;
            border-radius: 3px;
        }}

        /* Filter Controls */
        .filter-bar {{
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .filter-btn {{
            padding: 6px 16px;
            border: 1px solid {MD3_COLORS['outline']};
            border-radius: 20px;
            background: {MD3_COLORS['surface']};
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
        }}
        .filter-btn:hover {{
            background: {MD3_COLORS['surface_variant']};
        }}
        .filter-btn.active {{
            background: {MD3_COLORS['primary']};
            color: white;
            border-color: {MD3_COLORS['primary']};
        }}

        /* Chart container (QuickChart.io image) */
        .chart-container {{
            margin-top: 8px;
            text-align: center;
        }}
        .chart-container img {{
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}

        /* Kakao chart inside bubble */
        .kakao-chart {{
            margin-top: 12px;
        }}
        .kakao-chart img {{
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }}

        /* Sticky Group Navigation */
        .group-nav {{
            position: sticky;
            top: 10px;
            z-index: 100;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            background: {MD3_COLORS['surface']};
            padding: 12px 16px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .group-nav-link {{
            padding: 6px 14px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.2s;
            cursor: pointer;
        }}
        .group-nav-link:hover {{
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }}
        .group-nav-link.pass {{
            background: {MD3_COLORS['success_container']};
            color: {MD3_COLORS['on_success_container']};
        }}
        .group-nav-link.partial {{
            background: {MD3_COLORS['warning_container']};
            color: {MD3_COLORS['on_warning_container']};
        }}
        .group-nav-link.fail {{
            background: {MD3_COLORS['error_container']};
            color: {MD3_COLORS['on_error_container']};
        }}
        @media (max-width: 768px) {{
            .group-nav {{ position: static; }}
        }}

        /* Kakao Talk Preview */
        .kakao-section {{
            padding: 16px;
            background: {MD3_COLORS['surface_variant']};
            border-top: 1px solid {MD3_COLORS['outline_variant']};
            margin-top: 12px;
        }}
        .kakao-section h4 {{
            font-size: 13px;
            color: {MD3_COLORS['on_surface_variant']};
            margin-bottom: 12px;
        }}
        .kakao-preview {{
            display: flex;
            justify-content: center;
        }}
        .kakao-bubble {{
            background: #FEE500;
            border-radius: 15px;
            padding: 15px;
            max-width: 350px;
            width: 100%;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }}
        .kakao-title {{
            font-weight: bold;
            font-size: 14px;
            color: #3c1e1e;
            margin-bottom: 8px;
        }}
        .kakao-divider {{
            height: 1px;
            background: rgba(60, 30, 30, 0.2);
            margin: 8px 0;
        }}
        .kakao-content {{
            font-size: 13px;
            color: #3c1e1e;
            line-height: 1.5;
            white-space: pre-wrap;
        }}

        /* Detection Matrix */
        .detection-matrix {{
            width: 100%;
            border-collapse: collapse;
            margin: 12px 0;
        }}
        .detection-matrix th,
        .detection-matrix td {{
            padding: 10px 14px;
            text-align: center;
            border: 1px solid {MD3_COLORS['outline_variant']};
            font-size: 13px;
        }}
        .detection-matrix th {{
            background: {MD3_COLORS['surface_variant']};
            font-weight: 600;
            color: {MD3_COLORS['on_surface']};
        }}
        .detection-matrix td:first-child {{
            text-align: left;
            font-weight: 500;
        }}
        .detection-matrix .cell-yes {{
            background: {MD3_COLORS['success_container']};
            color: {MD3_COLORS['on_success_container']};
            font-weight: bold;
        }}
        .detection-matrix .cell-no {{
            background: {MD3_COLORS['error_container']};
            color: {MD3_COLORS['on_error_container']};
        }}
        .detection-matrix .cell-partial {{
            background: {MD3_COLORS['warning_container']};
            color: {MD3_COLORS['on_warning_container']};
        }}
        .detection-matrix .cell-pass {{
            background: {MD3_COLORS['success']};
            color: white;
            font-weight: bold;
        }}
        .detection-matrix .cell-fail {{
            background: {MD3_COLORS['error']};
            color: white;
            font-weight: bold;
        }}

        /* Severity Distribution Cards */
        .severity-dist-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-top: 16px;
        }}
        @media (max-width: 768px) {{
            .severity-dist-grid {{ grid-template-columns: repeat(2, 1fr); }}
        }}
        .severity-dist-card {{
            text-align: center;
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid;
        }}
        .severity-dist-card .dist-value {{
            font-size: 28px;
            font-weight: 700;
        }}
        .severity-dist-card .dist-label {{
            font-size: 12px;
            margin-top: 4px;
            font-weight: 500;
        }}

        /* Method Distribution Tags */
        .method-dist {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 12px;
        }}
        .method-tag {{
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 500;
            background: {MD3_COLORS['primary_container']};
            color: {MD3_COLORS['on_primary_container']};
        }}
        """

    def _get_e2e_js(self) -> str:
        """E2E 리포트 전용 JavaScript."""
        return """
<script>
// Expand/Collapse
document.addEventListener('click', function(e) {
    const header = e.target.closest('.test-card-header');
    if (!header) return;
    const card = header.closest('.test-card');
    card.classList.toggle('expanded');
});

// Filter
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;

    const filterGroup = btn.closest('.filter-bar');
    filterGroup.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    document.querySelectorAll('.test-card').forEach(card => {
        if (filter === 'all') {
            card.style.display = '';
        } else if (filter === 'pass') {
            card.style.display = card.classList.contains('pass') ? '' : 'none';
        } else if (filter === 'fail') {
            card.style.display = card.classList.contains('fail') ? '' : 'none';
        } else if (filter.startsWith('group-')) {
            const gid = filter.replace('group-', '');
            card.style.display = card.dataset.group === gid ? '' : 'none';
        }
    });
});

// Expand All / Collapse All
function toggleAll(expand) {
    document.querySelectorAll('.test-card').forEach(card => {
        if (expand) card.classList.add('expanded');
        else card.classList.remove('expanded');
    });
}
</script>"""

    def generate_content(self, data: E2EReportData) -> str:
        """리포트 콘텐츠 생성."""
        sections = []

        # Subtitle
        group_count = len(data.groups)
        sections.append(
            f'<p style="text-align:center; color:{MD3_COLORS["on_surface_variant"]}; margin-bottom:24px;">'
            f'{group_count}개 그룹, {data.total}개 시나리오</p>'
        )

        # 0. Sticky Group Navigation
        sections.append(self._generate_group_nav(data))

        # 1. Summary Cards
        sections.append(self._generate_summary_cards(data))

        # 1b. Severity + Method Distribution
        sections.append(self._generate_severity_distribution(data))
        sections.append(self._generate_method_distribution(data))

        # 1c. Pattern Recognition Summary (Phase 1-3)
        sections.append(self._generate_pattern_summary(data))

        # 2. Group Breakdown
        sections.append(self._generate_group_breakdown(data))

        # 2b. Detection Method Comparison Matrix (Group 7)
        sections.append(self._generate_detection_matrix(data))

        # 3. Filter Bar
        sections.append(self._generate_filter_bar(data))

        # 4. Test Items
        sections.append(self._generate_test_items(data))

        return "\n".join(sections)

    def _generate_summary_cards(self, data: E2EReportData) -> str:
        """요약 통계 카드."""
        pass_color = MD3_COLORS["success"] if data.pass_rate >= 85 else MD3_COLORS["warning"]
        if data.pass_rate < 70:
            pass_color = MD3_COLORS["error"]

        stats = [
            {"label": "전체", "value": str(data.total), "color": MD3_COLORS["primary"]},
            {"label": "통과", "value": str(data.passed), "color": MD3_COLORS["success"]},
            {"label": "실패", "value": str(data.failed), "color": MD3_COLORS["error"]},
            {"label": "통과율", "value": f"{data.pass_rate:.1f}%", "color": pass_color},
            {"label": "평균 지연", "value": f"{data.avg_latency_ms:.0f}ms", "color": MD3_COLORS["on_surface_variant"]},
        ]

        return self.render_stat_cards(stats, columns=5)

    def _generate_group_nav(self, data: E2EReportData) -> str:
        """상단 고정 그룹 네비게이션."""
        links = []
        for g in data.groups:
            if g.pass_rate >= 90:
                css_class = "pass"
            elif g.pass_rate >= 60:
                css_class = "partial"
            else:
                css_class = "fail"
            links.append(
                f'<a href="#group-{g.group_id}" class="group-nav-link {css_class}">'
                f'{g.emoji} {g.group_name} ({g.passed}/{g.total})</a>'
            )
        return f'<nav class="group-nav">{"".join(links)}</nav>'

    def _generate_severity_distribution(self, data: E2EReportData) -> str:
        """Severity별 분포 카드."""
        severity_counts = Counter(r.actual_severity.lower() for r in data.all_results)
        severity_config = {
            "critical": {"color": MD3_COLORS["error"], "bg": MD3_COLORS["error_container"], "text": MD3_COLORS["on_error_container"]},
            "high": {"color": MD3_COLORS["warning"], "bg": MD3_COLORS["warning_container"], "text": MD3_COLORS["on_warning_container"]},
            "medium": {"color": MD3_COLORS["primary"], "bg": MD3_COLORS["primary_container"], "text": MD3_COLORS["on_primary_container"]},
            "low": {"color": MD3_COLORS["outline"], "bg": MD3_COLORS["surface_variant"], "text": MD3_COLORS["on_surface_variant"]},
        }
        cards = []
        for sev in ["critical", "high", "medium", "low"]:
            count = severity_counts.get(sev, 0)
            cfg = severity_config[sev]
            cards.append(
                f'<div class="severity-dist-card" style="background:{cfg["bg"]}; border-left-color:{cfg["color"]};">'
                f'<div class="dist-value" style="color:{cfg["color"]};">{count}</div>'
                f'<div class="dist-label" style="color:{cfg["text"]};">{sev.upper()}</div>'
                f'</div>'
            )
        return self.render_card(
            f"{self._icon('bar_chart', size='sm', inline=True)} 심각도 분포",
            f'<div class="severity-dist-grid">{"".join(cards)}</div>',
        )

    def _generate_method_distribution(self, data: E2EReportData) -> str:
        """Detection method별 분포 태그."""
        method_counts = Counter(r.actual_detection_method for r in data.all_results if r.actual_detection_method)
        if not method_counts:
            return ""
        tags = []
        for method, count in method_counts.most_common():
            tags.append(f'<span class="method-tag">{method}: {count}</span>')
        return self.render_card(
            f"{self._icon('analytics', size='sm', inline=True)} 탐지 방법 분포",
            f'<div class="method-dist">{"".join(tags)}</div>',
        )

    def _generate_pattern_summary(self, data: E2EReportData) -> str:
        """패턴 인식기 요약 (Phase 1-3)."""
        # Phase 정의
        phases = [
            {
                "phase": "Phase 1 (MVP)",
                "desc": "요일 패턴 + 추세 인식",
                "recognizers": [
                    ("DayOfWeek", "요일 패턴", "-0.20"),
                    ("Trend", "추세 패턴", "-0.15"),
                ],
            },
            {
                "phase": "Phase 2",
                "desc": "월별 패턴 + 서비스 프로파일",
                "recognizers": [
                    ("MonthCycle", "월초/월말 패턴", "-0.15"),
                    ("ServiceProfile", "서비스 프로파일", "-0.10"),
                ],
            },
            {
                "phase": "Phase 3",
                "desc": "계절성 패턴 (Autocorrelation)",
                "recognizers": [
                    ("Seasonality", "계절성 패턴", "-0.15"),
                ],
            },
        ]

        # pattern_contexts에서 인식기별 활성화 횟수 추출
        recognizer_counts: Dict[str, int] = {}
        for r in data.all_results:
            for ctx in r.pattern_contexts:
                ctx_lower = ctx.lower()
                if "요일" in ctx_lower or "평일" in ctx_lower or "주말" in ctx_lower:
                    recognizer_counts["DayOfWeek"] = recognizer_counts.get("DayOfWeek", 0) + 1
                elif "추세" in ctx_lower or "trend" in ctx_lower:
                    recognizer_counts["Trend"] = recognizer_counts.get("Trend", 0) + 1
                elif "월초" in ctx_lower or "월말" in ctx_lower or "month" in ctx_lower:
                    recognizer_counts["MonthCycle"] = recognizer_counts.get("MonthCycle", 0) + 1
                elif "서비스" in ctx_lower or "service" in ctx_lower or "spike-normal" in ctx_lower:
                    recognizer_counts["ServiceProfile"] = recognizer_counts.get("ServiceProfile", 0) + 1
                elif "계절" in ctx_lower or "seasonal" in ctx_lower or "주기" in ctx_lower:
                    recognizer_counts["Seasonality"] = recognizer_counts.get("Seasonality", 0) + 1

        # 시나리오별 pattern_recognizer 필드 통계 (expected 기준)
        expected_counts: Dict[str, int] = Counter()
        for r in data.all_results:
            if r.pattern_type:
                # pattern_type에서 관련 인식기 추론
                pt = r.pattern_type.lower()
                if "day" in pt or "weekday" in pt or "weekend" in pt:
                    expected_counts["DayOfWeek"] += 1
                if "trend" in pt or "gradual" in pt or "growth" in pt or "plateau" in pt:
                    expected_counts["Trend"] += 1
                if "month" in pt:
                    expected_counts["MonthCycle"] += 1
                if "intermittent" in pt or "spike_normal" in pt:
                    expected_counts["ServiceProfile"] += 1
                if "seasonal" in pt or "cyclic" in pt:
                    expected_counts["Seasonality"] += 1

        total_activations = sum(recognizer_counts.values())

        # HTML 생성
        phase_rows = []
        for p in phases:
            rec_items = []
            for rec_key, rec_name, adj in p["recognizers"]:
                count = recognizer_counts.get(rec_key, 0)
                bar_width = min(count * 3, 100)  # 스케일링
                active_color = MD3_COLORS["success"] if count > 0 else MD3_COLORS["outline"]
                rec_items.append(
                    f'<div style="display:flex; align-items:center; gap:8px; margin:4px 0;">'
                    f'<span style="width:120px; font-size:13px; font-weight:500;">{rec_name}</span>'
                    f'<span style="font-size:12px; color:{MD3_COLORS["on_surface_variant"]};">'
                    f'조정값: {adj}</span>'
                    f'<div style="flex:1; height:8px; background:{MD3_COLORS["outline_variant"]}; '
                    f'border-radius:4px; overflow:hidden;">'
                    f'<div style="width:{bar_width}%; height:100%; background:{active_color}; '
                    f'border-radius:4px;"></div></div>'
                    f'<span style="font-size:12px; font-weight:600; min-width:30px; '
                    f'text-align:right;">{count}회</span>'
                    f'</div>'
                )

            phase_rows.append(
                f'<div style="margin-bottom:16px;">'
                f'<div style="font-weight:600; font-size:14px; margin-bottom:6px; '
                f'color:{MD3_COLORS["primary"]};">'
                f'{self._icon("check_circle", size="xs", inline=True, color="primary")} '
                f'{p["phase"]} — {p["desc"]}</div>'
                f'{"".join(rec_items)}'
                f'</div>'
            )

        summary_stat = (
            f'<div style="text-align:center; padding:12px; margin-bottom:16px; '
            f'background:{MD3_COLORS["primary_container"]}; border-radius:8px;">'
            f'<span style="font-size:24px; font-weight:700; color:{MD3_COLORS["primary"]};">'
            f'{total_activations}</span>'
            f'<span style="font-size:13px; color:{MD3_COLORS["on_primary_container"]}; '
            f'margin-left:8px;">총 패턴 인식 횟수 (전체 {data.total}개 시나리오)</span>'
            f'</div>'
        )

        content = summary_stat + "".join(phase_rows)

        return self.render_card(
            f"{self._icon('psychology', size='sm', inline=True)} 패턴 인식기 요약 (Phase 1-3)",
            content,
        )

    def _generate_detection_matrix(self, data: E2EReportData) -> str:
        """Group 7 탐지 방법 비교 행렬."""
        # Filter Group 7 results
        g7_results = [r for r in data.all_results if r.group_id == "7"]
        if not g7_results:
            return ""

        rows = []
        for r in g7_results:
            method = r.actual_detection_method.lower()
            expected = r.expected_detection_method.lower()

            # Parse which methods are active
            ecod = "ecod" in method
            ratio = "ratio" in method
            stddev = "stddev" in method
            ensemble = "ensemble" in method

            def cell(active: bool, method_name: str) -> str:
                if active:
                    return '<td class="cell-yes">✓</td>'
                # Check if expected method mentions this → partial contribution
                if method_name in expected and not active:
                    return '<td class="cell-partial">△</td>'
                return '<td class="cell-no">✗</td>'

            result_cell = '<td class="cell-pass">통과</td>' if r.passed else '<td class="cell-fail">실패</td>'

            rows.append(
                f"<tr>"
                f'<td>#{r.scenario_id}: {r.scenario_name_ko}</td>'
                f'{cell(ecod, "ecod")}'
                f'{cell(ratio, "ratio")}'
                f'{cell(stddev, "stddev")}'
                f'{cell(ensemble, "ensemble")}'
                f'{result_cell}'
                f"</tr>"
            )

        legend = (
            '<div style="display:flex; gap:16px; font-size:12px; margin-top:8px; '
            f'color:{MD3_COLORS["on_surface_variant"]};">'
            f'<span><strong style="color:{MD3_COLORS["on_success_container"]};">✓</strong> 주요 탐지</span>'
            f'<span><strong style="color:{MD3_COLORS["on_warning_container"]};">△</strong> 부분 기여</span>'
            f'<span><strong style="color:{MD3_COLORS["on_error_container"]};">✗</strong> 미탐지</span>'
            '</div>'
        )

        table_html = (
            '<table class="detection-matrix">'
            '<thead><tr>'
            '<th style="text-align:left;">시나리오</th>'
            '<th>ECOD</th><th>Ratio</th><th>StdDev</th><th>Ensemble</th><th>결과</th>'
            '</tr></thead>'
            f'<tbody>{"".join(rows)}</tbody>'
            '</table>'
            f'{legend}'
        )

        return self.render_card(
            f"{self._icon('science', size='sm', inline=True)} 탐지 방법 비교 행렬 (그룹 7)",
            table_html,
        )

    def _generate_group_breakdown(self, data: E2EReportData) -> str:
        """그룹별 진행률 바."""
        bars = []
        for g in data.groups:
            rate = g.pass_rate
            if rate >= 90:
                color = MD3_COLORS["success"]
            elif rate >= 70:
                color = MD3_COLORS["warning"]
            else:
                color = MD3_COLORS["error"]

            width = max(rate, 5)  # 최소 5% 너비
            bars.append(f"""
            <div class="group-bar">
                <div class="group-bar-header">
                    <span>{g.emoji} 그룹 {g.group_id}: {g.group_name}</span>
                    <span><strong>{g.passed}/{g.total}</strong> ({rate:.0f}%)</span>
                </div>
                <div class="group-bar-track">
                    <div class="group-bar-fill" style="width:{width}%; background:{color};">
                        {g.passed}/{g.total}
                    </div>
                </div>
            </div>
            """)

        return self.render_card(
            f"{self._icon('bar_chart', size='sm', inline=True)} 그룹별 결과",
            "\n".join(bars),
        )

    def _generate_filter_bar(self, data: E2EReportData) -> str:
        """필터 컨트롤."""
        buttons = [
            '<button class="filter-btn active" data-filter="all">전체</button>',
            f'<button class="filter-btn" data-filter="pass">{self._icon("check_circle", size="xs", color="success", inline=True)} 통과</button>',
            f'<button class="filter-btn" data-filter="fail">{self._icon("error", size="xs", color="error", inline=True)} 실패</button>',
        ]

        for g in data.groups:
            buttons.append(
                f'<button class="filter-btn" data-filter="group-{g.group_id}">'
                f'{g.emoji} G{g.group_id}</button>'
            )

        expand_controls = (
            '<span style="margin-left:auto;">'
            '<button class="filter-btn" onclick="toggleAll(true)">모두 펼치기</button>'
            '<button class="filter-btn" onclick="toggleAll(false)">모두 접기</button>'
            '</span>'
        )

        return f'<div class="filter-bar">{"".join(buttons)}{expand_controls}</div>'

    def _generate_test_items(self, data: E2EReportData) -> str:
        """개별 테스트 카드 목록."""
        cards = []
        seen_groups = set()
        for r in data.all_results:
            # Add anchor for first card of each group (for sticky nav)
            if r.group_id not in seen_groups:
                cards.append(f'<div id="group-{r.group_id}"></div>')
                seen_groups.add(r.group_id)
            cards.append(self._generate_test_card(r))
        return "\n".join(cards)

    def _generate_test_card(self, r: E2ETestResult) -> str:
        """개별 테스트 확장 가능 카드."""
        status_class = "pass" if r.passed else "fail"
        status_icon = (
            self._icon("check_circle", size="sm", filled=True, color="success")
            if r.passed
            else self._icon("error", size="sm", filled=True, color="error")
        )

        severity_badge = self.render_severity_badge(r.actual_severity)
        expected_badge = self.render_severity_badge(r.expected_severity)

        # Confidence bar
        conf_pct = min(100, r.actual_confidence * 100)
        if conf_pct >= 70:
            conf_color = MD3_COLORS["error"]
        elif conf_pct >= 50:
            conf_color = MD3_COLORS["warning"]
        else:
            conf_color = MD3_COLORS["success"]

        conf_bar = (
            f'<span class="confidence-bar">'
            f'<span class="confidence-bar-fill" style="width:{conf_pct}%; background:{conf_color};"></span>'
            f'</span>'
        )

        return f"""
        <div class="test-card {status_class}" data-group="{r.group_id}">
            <div class="test-card-header">
                <span class="test-card-status">{status_icon}</span>
                <span class="test-card-id">#{r.scenario_id}</span>
                <span class="test-card-name">{r.scenario_name_ko}</span>
                <span class="test-card-meta">
                    <span class="group-badge">{r.group_name}</span>
                    {severity_badge}
                    <span title="신뢰도: {r.actual_confidence:.3f}">{conf_bar}</span>
                    <span class="test-card-time">{r.execution_time_ms:.0f}ms</span>
                </span>
                <span class="test-card-chevron">
                    {self._icon('expand_more', size='sm')}
                </span>
            </div>
            <div class="test-card-body">
                <p style="margin:12px 0 0; color:{MD3_COLORS['on_surface_variant']}; font-size:13px;">
                    {r.description_ko}
                </p>
                <div class="detail-grid">
                    <div class="detail-section">
                        <h4>{self._icon('target', size='xs', inline=True)} 예상 결과</h4>
                        <div class="detail-row">
                            <span class="detail-label">심각도</span>
                            <span class="detail-value">{expected_badge}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">탐지 방법</span>
                            <span class="detail-value">{r.expected_detection_method}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">서비스</span>
                            <span class="detail-value">{r.service_name}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">패턴</span>
                            <span class="detail-value">{r.pattern_type}</span>
                        </div>
                    </div>
                    <div class="detail-section">
                        <h4>{self._icon('analytics', size='xs', inline=True)} 실제 결과</h4>
                        <div class="detail-row">
                            <span class="detail-label">심각도</span>
                            <span class="detail-value">{severity_badge}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">탐지 방법</span>
                            <span class="detail-value">{r.actual_detection_method}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">신뢰도</span>
                            <span class="detail-value">{r.actual_confidence:.3f}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">변화율</span>
                            <span class="detail-value">{r.actual_change_percent:+.1f}%</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">이상 여부</span>
                            <span class="detail-value">{'예' if r.actual_is_anomaly else '아니오'}</span>
                        </div>
                    </div>
                </div>
                {self._render_pass_reason(r)}
                {self._render_pattern_contexts(r)}
                {self._render_mini_chart(r)}
                {self._render_kakao_preview(r)}
            </div>
        </div>
        """

    def _render_pass_reason(self, r: E2ETestResult) -> str:
        """Pass/Fail 사유."""
        if r.passed:
            return f"""
            <div style="margin-top:12px; padding:8px 12px; background:{MD3_COLORS['success_container']};
                        border-radius:6px; font-size:13px; color:{MD3_COLORS['on_success_container']};">
                {self._icon('check', size='xs', inline=True)} {r.pass_reason}
            </div>
            """
        return f"""
        <div style="margin-top:12px; padding:8px 12px; background:{MD3_COLORS['error_container']};
                    border-radius:6px; font-size:13px; color:{MD3_COLORS['on_error_container']};">
            {self._icon('close', size='xs', inline=True)} {r.pass_reason}
        </div>
        """

    def _render_pattern_contexts(self, r: E2ETestResult) -> str:
        """패턴 컨텍스트 표시."""
        if not r.pattern_contexts:
            return ""
        items = "".join(f"<li>{ctx}</li>" for ctx in r.pattern_contexts)
        return f"""
        <div style="margin-top:8px;">
            <span style="font-size:12px; color:{MD3_COLORS['on_surface_variant']};">
                {self._icon('pattern', size='xs', inline=True)} 패턴 컨텍스트:
            </span>
            <ul style="margin:4px 0 0 20px; font-size:12px; color:{MD3_COLORS['on_surface_variant']};">
                {items}
            </ul>
        </div>
        """

    def _render_mini_chart(self, r: E2ETestResult) -> str:
        """비용 추이 차트 (QuickChart.io 이미지)."""
        if not r.chart_url:
            return ""
        return f"""
        <div style="margin-top:12px;">
            <span style="font-size:12px; color:{MD3_COLORS['on_surface_variant']};">
                {self._icon('show_chart', size='xs', inline=True)} 비용 추이:
            </span>
            <div class="chart-container">
                <img src="{r.chart_url}" alt="비용 추이 차트" loading="lazy">
            </div>
        </div>
        """

    def _render_kakao_preview(self, r: E2ETestResult) -> str:
        """카카오톡 알림 미리보기 (SummaryGenerator 자연어 메시지 사용)."""
        if not r.actual_is_anomaly:
            return ""

        # SummaryGenerator 출력 사용 (alert_title / alert_message)
        title = r.alert_title or f"{r.service_name} 비용 이상 탐지"
        message = r.alert_message or f"{r.service_name}: {r.actual_change_percent:+.1f}% 변동"

        # 차트 이미지 (카톡 버블 안에 삽입)
        chart_html = ""
        if r.chart_url:
            chart_html = f"""
                    <div class="kakao-chart">
                        <img src="{r.chart_url}" alt="비용 추이">
                    </div>"""

        return f"""
        <div class="kakao-section">
            <h4>{self._icon('chat', size='xs', inline=True)} 카카오톡 알림 미리보기</h4>
            <div class="kakao-preview">
                <div class="kakao-bubble">
                    <div class="kakao-title">{title}</div>
                    <div class="kakao-divider"></div>
                    <div class="kakao-content">{message.replace(chr(10), '<br>')}</div>
                    {chart_html}
                </div>
            </div>
        </div>
        """
