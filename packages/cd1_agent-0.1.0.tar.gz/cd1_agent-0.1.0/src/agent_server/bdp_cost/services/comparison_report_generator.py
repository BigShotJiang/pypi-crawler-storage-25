"""
Cost Comparison HTML Report Generator.

비용 비교 결과를 HTML 리포트로 생성합니다.
"""

import json
import logging
from datetime import datetime
from typing import Optional

from src.agent_server.bdp_cost.services.comparison_models import (
    CostComparisonResult,
    Granularity,
    ServiceCostComparison,
)

logger = logging.getLogger(__name__)


class CostComparisonHTMLReportGenerator:
    """비용 비교 HTML 리포트 생성기."""

    GRANULARITY_LABELS = {
        Granularity.DAILY: "일별",
        Granularity.WEEKLY: "주별",
        Granularity.MONTHLY: "월별",
        Granularity.YEARLY: "연별",
    }

    def __init__(self, currency: str = "KRW"):
        """리포트 생성기 초기화.

        Args:
            currency: 통화 단위 (KRW, USD)
        """
        self.currency = currency

    def generate(self, result: CostComparisonResult) -> str:
        """비교 결과를 HTML 리포트로 생성.

        Args:
            result: 비용 비교 결과

        Returns:
            HTML 문자열
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        granularity_label = self.GRANULARITY_LABELS.get(
            result.granularity, result.granularity.value
        )

        # 변화 색상/방향
        if result.total_change >= 0:
            change_color = "#D32F2F"  # Red
            change_bg = "#FFEBEE"
            change_sign = "+"
        else:
            change_color = "#1565C0"  # Blue
            change_bg = "#E3F2FD"
            change_sign = ""

        # 서비스 테이블 행
        service_rows = self._build_service_rows(result)

        # Top 증가/감소
        top_increases_html = self._build_top_list(result.top_increases, is_increase=True)
        top_decreases_html = self._build_top_list(result.top_decreases, is_increase=False)

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>비용 비교 리포트 - {result.period1} vs {result.period2}</title>
    <style>
        @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');

        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }}

        .container {{
            max-width: 700px;
            margin: 0 auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }}

        .header {{
            background: linear-gradient(135deg, #1976D2, #1565C0);
            color: white;
            padding: 24px;
        }}

        .header h1 {{
            font-size: 1.5rem;
            margin-bottom: 8px;
        }}

        .header p {{
            opacity: 0.9;
            font-size: 0.95rem;
        }}

        .header .meta {{
            font-size: 0.85rem;
            opacity: 0.8;
            margin-top: 12px;
        }}

        .summary-cards {{
            display: flex;
            gap: 16px;
            padding: 20px;
            background: #FAFAFA;
        }}

        .summary-card {{
            flex: 1;
            background: #F5F5F5;
            padding: 16px;
            border-radius: 8px;
            text-align: center;
        }}

        .summary-card.change {{
            background: {change_bg};
        }}

        .summary-card .label {{
            color: #757575;
            font-size: 0.85rem;
            margin-bottom: 8px;
        }}

        .summary-card .value {{
            font-size: 1.25rem;
            font-weight: 700;
            color: #333;
        }}

        .summary-card.change .value {{
            color: {change_color};
        }}

        .section {{
            padding: 20px;
            border-top: 1px solid #E0E0E0;
        }}

        .section-title {{
            font-size: 1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 16px;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        th, td {{
            padding: 12px 10px;
            text-align: right;
            border-bottom: 1px solid #E0E0E0;
            font-size: 0.9rem;
        }}

        th {{
            background: #F5F5F5;
            font-weight: 600;
            color: #666;
        }}

        th:first-child, td:first-child {{
            text-align: left;
        }}

        td.service-name {{
            font-weight: 500;
            color: #333;
        }}

        td.increase {{
            color: #D32F2F;
            font-weight: 500;
        }}

        td.decrease {{
            color: #1565C0;
            font-weight: 500;
        }}

        .top-changes {{
            display: flex;
            gap: 20px;
        }}

        .top-changes-column {{
            flex: 1;
        }}

        .top-changes-column h4 {{
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 12px;
        }}

        .top-item {{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #F0F0F0;
            font-size: 0.85rem;
        }}

        .top-item:last-child {{
            border-bottom: none;
        }}

        .top-item .name {{
            color: #333;
        }}

        .top-item .change.increase {{
            color: #D32F2F;
            font-weight: 500;
        }}

        .top-item .change.decrease {{
            color: #1565C0;
            font-weight: 500;
        }}

        .footer {{
            padding: 16px 20px;
            background: #F5F5F5;
            text-align: center;
            font-size: 0.8rem;
            color: #999;
        }}

        .note {{
            padding: 12px 20px;
            background: #FFF8E1;
            border-left: 4px solid #FFC107;
            font-size: 0.85rem;
            color: #795548;
        }}

        @media (max-width: 600px) {{
            .summary-cards {{
                flex-direction: column;
            }}

            .top-changes {{
                flex-direction: column;
            }}

            th, td {{
                padding: 10px 6px;
                font-size: 0.85rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>비용 비교 리포트</h1>
            <p>{result.period1} vs {result.period2} ({granularity_label})</p>
            <div class="meta">
                계정: {result.account_name} ({result.account_id}) | 생성: {timestamp}
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="summary-card">
                <div class="label">{result.period1}</div>
                <div class="value">{self._format_cost(result.total_period1_cost)}</div>
            </div>
            <div class="summary-card">
                <div class="label">{result.period2}</div>
                <div class="value">{self._format_cost(result.total_period2_cost)}</div>
            </div>
            <div class="summary-card change">
                <div class="label">변화</div>
                <div class="value">{change_sign}{self._format_cost(abs(result.total_change))} ({result.total_change_percent:+.1f}%)</div>
            </div>
        </div>

        <!-- Note -->
        <div class="note">
            AWS Cost Explorer 데이터는 UTC 기준으로 집계됩니다.
        </div>

        <!-- Service Table -->
        <div class="section">
            <div class="section-title">서비스별 비용 비교</div>
            <table>
                <thead>
                    <tr>
                        <th>서비스</th>
                        <th>{result.period1}</th>
                        <th>{result.period2}</th>
                        <th>변화</th>
                        <th>변화율</th>
                    </tr>
                </thead>
                <tbody>
                    {service_rows}
                </tbody>
            </table>
        </div>

        <!-- Top Changes -->
        <div class="section">
            <div class="section-title">주요 변동</div>
            <div class="top-changes">
                <div class="top-changes-column">
                    <h4>Top 증가</h4>
                    {top_increases_html}
                </div>
                <div class="top-changes-column">
                    <h4>Top 감소</h4>
                    {top_decreases_html}
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            BDP Cost Agent | CD1 Agent System
        </div>
    </div>
</body>
</html>"""

        return html

    def _build_service_rows(self, result: CostComparisonResult) -> str:
        """서비스 테이블 행 생성."""
        rows = []

        for comp in result.service_comparisons:
            # 변화 색상
            if comp.cost_change > 0:
                change_class = "increase"
                change_sign = "+"
            elif comp.cost_change < 0:
                change_class = "decrease"
                change_sign = ""
            else:
                change_class = ""
                change_sign = ""

            # 서비스명 정리
            service_display = self._clean_service_name(comp.service_name)

            row = f"""<tr>
                <td class="service-name">{service_display}</td>
                <td>{self._format_cost(comp.period1_cost)}</td>
                <td>{self._format_cost(comp.period2_cost)}</td>
                <td class="{change_class}">{change_sign}{self._format_cost(abs(comp.cost_change))}</td>
                <td class="{change_class}">{comp.change_percent:+.1f}%</td>
            </tr>"""
            rows.append(row)

        return "\n".join(rows)

    def _build_top_list(
        self,
        items: list[ServiceCostComparison],
        is_increase: bool
    ) -> str:
        """Top 증가/감소 목록 생성."""
        if not items:
            return '<div class="top-item"><span class="name">-</span></div>'

        html_items = []
        change_class = "increase" if is_increase else "decrease"

        for item in items:
            service_display = self._clean_service_name(item.service_name)
            sign = "+" if item.cost_change > 0 else ""
            html_items.append(f"""<div class="top-item">
                <span class="name">{service_display}</span>
                <span class="change {change_class}">{sign}{self._format_cost(abs(item.cost_change))} ({item.change_percent:+.1f}%)</span>
            </div>""")

        return "\n".join(html_items)

    def _format_cost(self, cost: float) -> str:
        """비용을 읽기 쉬운 형식으로 포맷팅."""
        if self.currency == "KRW":
            if cost >= 100_000_000:  # 1억 이상
                return f"{cost / 100_000_000:.1f}억원"
            elif cost >= 10_000:  # 1만 이상
                return f"{cost / 10_000:.0f}만원"
            else:
                return f"{cost:,.0f}원"
        else:  # USD
            if cost >= 1_000_000:
                return f"${cost / 1_000_000:.1f}M"
            elif cost >= 1_000:
                return f"${cost / 1_000:.1f}K"
            else:
                return f"${cost:,.2f}"

    def _clean_service_name(self, service_name: str) -> str:
        """서비스명 정리 (Amazon, AWS 접두사 제거)."""
        name = service_name
        prefixes = ["Amazon ", "AWS ", "Amazon"]
        for prefix in prefixes:
            if name.startswith(prefix):
                name = name[len(prefix):]
        return name.strip()

    # ── DB 기반 HTML 재생성 ──────────────────────────────────────

    def generate_from_db(self, report) -> str:
        """DB에서 읽은 CostReport 객체의 raw_data_json으로 HTML 재생성.

        Args:
            report: CostReport (report_store.py의 dataclass)

        Returns:
            HTML 문자열
        """
        result = self.data_from_json(report)
        return self.generate(result)

    @staticmethod
    def data_to_json(result: CostComparisonResult) -> str:
        """CostComparisonResult → JSON 문자열."""
        return json.dumps(result.to_dict(), ensure_ascii=False)

    @staticmethod
    def data_from_json(report) -> CostComparisonResult:
        """CostReport의 raw_data_json → CostComparisonResult 복원."""
        raw = json.loads(report.raw_data_json)
        return CostComparisonResult.from_dict(raw)


def generate_comparison_report(
    result: CostComparisonResult,
    currency: str = "KRW",
) -> str:
    """편의 함수: 비용 비교 리포트 생성.

    Args:
        result: 비용 비교 결과
        currency: 통화 단위

    Returns:
        HTML 문자열
    """
    generator = CostComparisonHTMLReportGenerator(currency=currency)
    return generator.generate(result)
