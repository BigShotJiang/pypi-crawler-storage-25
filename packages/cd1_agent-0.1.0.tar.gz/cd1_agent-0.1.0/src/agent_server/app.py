"""Unified FastAPI application for all CD1 agents."""

import logging
import os
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Dict, List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.agent_server.auth import APIKeyMiddleware
from src.agent_server.config import get_server_config
from src.agent_server.routers import discover_routers

logger = logging.getLogger(__name__)

# Registered agent names (populated at startup)
_registered_agents: List[str] = []

# Mail scheduler instance (if enabled)
_mail_scheduler = None


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    global _mail_scheduler
    config = get_server_config()
    logger.info(f"CD1 Agent Server starting (env={config.environment})")
    logger.info(f"Registered agents: {_registered_agents}")

    # Start mail scheduler if enabled (파일 잠금으로 workers 2 환경에서 1개만 실행)
    if os.getenv("MAIL_SCHEDULER_ENABLED", "false").lower() == "true":
        try:
            import fcntl

            lock_file = open("/tmp/mail_scheduler.lock", "w")  # noqa: SIM115
            fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)

            from src.agent_server.bdp_common.mail.scheduler import MailScheduler
            from src.portal.services.db import PortalDB
            from src.portal.config import get_portal_settings

            def db_factory():
                settings = get_portal_settings()
                db = PortalDB(settings)
                db.ensure_tables()
                return db

            _mail_scheduler = MailScheduler(db_factory)
            _mail_scheduler.start()
            logger.info("MailScheduler enabled and started (lock acquired)")
        except BlockingIOError:
            logger.info("MailScheduler already running in another worker, skipping")
        except Exception:
            logger.exception("Failed to start MailScheduler")

    yield

    # Stop mail scheduler
    if _mail_scheduler:
        _mail_scheduler.stop()

    logger.info("CD1 Agent Server shutting down")


def create_app() -> FastAPI:
    config = get_server_config()

    # Logging
    logging.basicConfig(
        level=getattr(logging, config.log_level.upper(), logging.INFO),
        format="[%(levelname)s] %(asctime)s - %(name)s - %(message)s",
    )

    app = FastAPI(
        title="CD1 Agent Server",
        description="Unified HTTP server for all CD1 detection agents",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if config.debug else None,
        redoc_url="/redoc" if config.debug else None,
        openapi_url="/openapi.json" if config.debug else None,
    )

    # Middleware (order matters: last added = outermost)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if config.debug else [],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(APIKeyMiddleware)

    # --- Health & agent-list (public, no auth) ---
    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.get("/agents")
    async def list_agents() -> Dict[str, Any]:
        return {"agents": _registered_agents}

    # --- Auto-discover and mount agent routers ---
    for agent_name, router in discover_routers():
        app.include_router(router, prefix=f"/agents/{agent_name}", tags=[agent_name])
        _registered_agents.append(agent_name)

    return app


app = create_app()
