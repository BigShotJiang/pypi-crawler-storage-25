"""
Subnet IP Metrics Fetcher.

VPC Subnet IP 사용량 모니터링.
"""

import ipaddress
import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDrift,
    SubnetIPUsage,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class SubnetIPMetricsFetcher:
    """VPC Subnet IP 사용량 조회기.

    Severity 결정 로직:
    - utilization > 90%: CRITICAL
    - utilization > 80%: HIGH
    - utilization > 70%: MEDIUM
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        subnet_ids: Optional[List[str]] = None,
        vpc_ids: Optional[List[str]] = None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._client = client
        self.subnet_ids = subnet_ids
        self.vpc_ids = vpc_ids

        # Configurable thresholds (환경변수로 오버라이드 가능)
        self.critical_threshold = float(os.getenv("SUBNET_IP_THRESHOLD_CRITICAL", "90"))
        self.high_threshold = float(os.getenv("SUBNET_IP_THRESHOLD_HIGH", "80"))
        if self.critical_threshold != 90 or self.high_threshold != 80:
            logger.info(
                f"Subnet IP thresholds overridden: HIGH={self.high_threshold}, CRITICAL={self.critical_threshold}"
            )

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._client = get_boto3_client("ec2", config=config)
        return self._client

    def fetch_subnet_usage(
        self,
        subnet_id: Optional[str] = None,
    ) -> List[SubnetIPUsage]:
        """Subnet IP 사용량 조회.

        Args:
            subnet_id: 특정 서브넷 ID (없으면 모든 대상 서브넷 조회)

        Returns:
            SubnetIPUsage 목록
        """
        if self.use_mock:
            return self._mock_subnet_usage(subnet_id)

        results = []

        try:
            # 서브넷 정보 조회
            filters = []
            if subnet_id:
                subnet_ids = [subnet_id]
            elif self.subnet_ids:
                subnet_ids = self.subnet_ids
            else:
                subnet_ids = None

            if self.vpc_ids:
                filters.append({
                    "Name": "vpc-id",
                    "Values": self.vpc_ids,
                })

            if subnet_ids:
                response = self.client.describe_subnets(SubnetIds=subnet_ids)
            elif filters:
                response = self.client.describe_subnets(Filters=filters)
            else:
                response = self.client.describe_subnets()

            for subnet in response.get("Subnets", []):
                subnet_id = subnet.get("SubnetId")
                cidr_block = subnet.get("CidrBlock")
                available_ips = subnet.get("AvailableIpAddressCount", 0)

                # CIDR에서 총 IP 수 계산 (AWS reserved 5개 제외)
                try:
                    network = ipaddress.ip_network(cidr_block, strict=False)
                    total_ips = network.num_addresses - 5  # AWS reserved
                except ValueError:
                    total_ips = 0

                used_ips = total_ips - available_ips
                utilization_percent = (used_ips / total_ips * 100) if total_ips > 0 else 0

                # 서브넷 이름 추출
                subnet_name = None
                for tag in subnet.get("Tags", []):
                    if tag["Key"] == "Name":
                        subnet_name = tag["Value"]
                        break

                results.append(SubnetIPUsage(
                    subnet_id=subnet_id,
                    subnet_name=subnet_name,
                    vpc_id=subnet.get("VpcId"),
                    cidr_block=cidr_block,
                    total_ips=total_ips,
                    available_ips=available_ips,
                    used_ips=used_ips,
                    utilization_percent=utilization_percent,
                    availability_zone=subnet.get("AvailabilityZone"),
                ))

        except Exception as e:
            logger.error(f"Failed to fetch subnet usage: {e}")

        return results

    def detect_drift(
        self,
        subnet_id: Optional[str] = None,
        critical_threshold: Optional[float] = None,
        high_threshold: Optional[float] = None,
    ) -> List[MetricDrift]:
        """Subnet IP 고갈 drift 감지.

        Args:
            subnet_id: 특정 서브넷 ID (없으면 모든 대상 서브넷)
            critical_threshold: CRITICAL 임계값 (미지정 시 환경변수 또는 기본 90%)
            high_threshold: HIGH 임계값 (미지정 시 환경변수 또는 기본 80%)

        Returns:
            감지된 drift 목록
        """
        critical_threshold = critical_threshold if critical_threshold is not None else self.critical_threshold
        high_threshold = high_threshold if high_threshold is not None else self.high_threshold

        usages = self.fetch_subnet_usage(subnet_id)
        drifts = []
        now = datetime.now(KST)

        for usage in usages:
            severity = None
            if usage.utilization_percent >= critical_threshold:
                severity = DriftSeverity.CRITICAL
                threshold = critical_threshold
            elif usage.utilization_percent >= high_threshold:
                severity = DriftSeverity.HIGH
                threshold = high_threshold
            else:
                continue

            display_name = usage.subnet_name or usage.subnet_id
            drifts.append(MetricDrift(
                metric_type="subnet-ip",
                resource_id=usage.subnet_id,
                resource_name=usage.subnet_name,
                metric_name="ip_utilization",
                current_value=usage.utilization_percent,
                baseline_avg=0,  # Not applicable
                baseline_stddev=0,  # Not applicable
                z_score=0,  # Not applicable
                severity=severity,
                threshold_type="percentage",
                threshold_value=threshold,
                description=(
                    f"서브넷 {display_name} IP 고갈 경고: "
                    f"{usage.used_ips}/{usage.total_ips} ({usage.utilization_percent:.1f}%) 사용 중"
                ),
                recommendation=self._get_recommendation(usage),
                detected_at=now,
            ))

        return drifts

    def _get_recommendation(self, usage: SubnetIPUsage) -> str:
        """사용량 기반 권장 조치."""
        if usage.utilization_percent >= 90:
            return (
                f"즉시 조치 필요: 가용 IP {usage.available_ips}개 남음. "
                "새 서브넷 추가 또는 미사용 ENI 정리 필요."
            )
        elif usage.utilization_percent >= 80:
            return (
                f"서브넷 확장 검토 필요: 가용 IP {usage.available_ips}개 남음. "
                "향후 워크로드 증가에 대비한 계획 수립 권장."
            )
        return "IP 사용량을 지속 모니터링하세요."

    def list_subnets(self) -> List[str]:
        """대상 서브넷 목록 반환."""
        if self.use_mock:
            return ["subnet-mock-11111111", "subnet-mock-22222222"]

        subnets = []
        try:
            filters = []
            if self.vpc_ids:
                filters.append({
                    "Name": "vpc-id",
                    "Values": self.vpc_ids,
                })

            paginator = self.client.get_paginator("describe_subnets")
            paginate_kwargs = {}
            if filters:
                paginate_kwargs["Filters"] = filters

            for page in paginator.paginate(**paginate_kwargs):
                for subnet in page.get("Subnets", []):
                    subnets.append(subnet.get("SubnetId"))

        except Exception as e:
            logger.error(f"Failed to list subnets: {e}")

        return subnets

    def _mock_subnet_usage(self, subnet_id: Optional[str]) -> List[SubnetIPUsage]:
        """Mock 서브넷 사용량 데이터."""
        mock_data = [
            SubnetIPUsage(
                subnet_id="subnet-mock-11111111",
                subnet_name="private-subnet-1a",
                vpc_id="vpc-mock-12345678",
                cidr_block="10.0.1.0/24",
                total_ips=251,
                available_ips=100,
                used_ips=151,
                utilization_percent=60.2,
                availability_zone="ap-northeast-2a",
            ),
            SubnetIPUsage(
                subnet_id="subnet-mock-22222222",
                subnet_name="private-subnet-1b",
                vpc_id="vpc-mock-12345678",
                cidr_block="10.0.2.0/24",
                total_ips=251,
                available_ips=20,
                used_ips=231,
                utilization_percent=92.0,  # CRITICAL
                availability_zone="ap-northeast-2b",
            ),
            SubnetIPUsage(
                subnet_id="subnet-mock-33333333",
                subnet_name="emr-subnet",
                vpc_id="vpc-mock-12345678",
                cidr_block="10.0.10.0/23",
                total_ips=507,
                available_ips=100,
                used_ips=407,
                utilization_percent=80.3,  # HIGH
                availability_zone="ap-northeast-2c",
            ),
        ]

        if subnet_id:
            return [s for s in mock_data if s.subnet_id == subnet_id]
        return mock_data
