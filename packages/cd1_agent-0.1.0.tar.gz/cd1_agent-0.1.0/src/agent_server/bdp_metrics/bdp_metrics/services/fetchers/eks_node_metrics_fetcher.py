"""
EKS Node/NodeGroup Metrics Fetcher.

CloudWatch Container Insights 기반 EKS Node 메트릭 조회 및 drift 감지.
EKS API 기반 NodeGroup 상태 조회 및 이상 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    EKS_NODE_METRICS,
    MetricDataPoint,
    MetricDrift,
    MetricResult,
    NodeGroupStatus,
    NodeSummary,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class EKSNodeMetricsFetcher:
    """EKS Node/NodeGroup 메트릭 조회기.

    - 노드: CloudWatch Container Insights 기반 CPU/Memory/Disk/Pod수
    - 노드그룹: EKS API describe_nodegroup 기반 상태/스케일링/헬스
    """

    def __init__(
        self,
        cluster_name: str,
        use_mock: bool = False,
        cloudwatch_client=None,
        eks_client=None,
        ec2_client=None,
        metric_cache=None,
    ):
        self.cluster_name = cluster_name
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._eks_client = eks_client
        self._ec2_client = ec2_client
        self._metric_cache = metric_cache

        # 노드 레벨 임계값 (환경변수 오버라이드)
        self._threshold_overrides = {
            "node_cpu_utilization": {
                "HIGH": float(os.getenv("EKS_NODE_CPU_THRESHOLD_HIGH", "80")),
                "CRITICAL": float(os.getenv("EKS_NODE_CPU_THRESHOLD_CRITICAL", "90")),
            },
            "node_memory_utilization": {
                "HIGH": float(os.getenv("EKS_NODE_MEMORY_THRESHOLD_HIGH", "80")),
                "CRITICAL": float(os.getenv("EKS_NODE_MEMORY_THRESHOLD_CRITICAL", "90")),
            },
            "node_filesystem_utilization": {
                "HIGH": float(os.getenv("EKS_NODE_DISK_THRESHOLD_HIGH", "85")),
                "CRITICAL": float(os.getenv("EKS_NODE_DISK_THRESHOLD_CRITICAL", "95")),
            },
        }

        # 노드그룹 레벨 임계값
        self._ng_capacity_threshold = {
            "HIGH": float(os.getenv("EKS_NG_CAPACITY_THRESHOLD_HIGH", "80")),
            "CRITICAL": float(os.getenv("EKS_NG_CAPACITY_THRESHOLD_CRITICAL", "95")),
        }
        self._ng_avg_cpu_threshold = {
            "HIGH": float(os.getenv("EKS_NG_AVG_CPU_THRESHOLD_HIGH", "70")),
            "CRITICAL": float(os.getenv("EKS_NG_AVG_CPU_THRESHOLD_CRITICAL", "85")),
        }
        self._ng_avg_memory_threshold = {
            "HIGH": float(os.getenv("EKS_NG_AVG_MEMORY_THRESHOLD_HIGH", "70")),
            "CRITICAL": float(os.getenv("EKS_NG_AVG_MEMORY_THRESHOLD_CRITICAL", "85")),
        }

        # 오버라이드 로깅
        for name, th in self._threshold_overrides.items():
            default = EKS_NODE_METRICS[name]["severity_threshold"]
            if default and (th["HIGH"] != default["HIGH"] or th["CRITICAL"] != default["CRITICAL"]):
                logger.info(f"Threshold overridden for {name}: HIGH={th['HIGH']}, CRITICAL={th['CRITICAL']}")

    # --- Lazy clients ---

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def eks_client(self):
        if self._eks_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._eks_client = get_boto3_client("eks", config=config)
        return self._eks_client

    @property
    def ec2_client(self):
        if self._ec2_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._ec2_client = get_boto3_client("ec2", config=config)
        return self._ec2_client

    # =========================================================================
    # 노드 메트릭
    # =========================================================================

    def discover_nodes(self) -> List[Dict[str, str]]:
        """CloudWatch list_metrics로 노드 발견.

        Returns:
            [{"NodeName": ..., "InstanceId": ...}, ...]
        """
        nodes = []
        seen = set()

        try:
            paginator = self.cloudwatch_client.get_paginator("list_metrics")
            for page in paginator.paginate(
                Namespace="ContainerInsights",
                MetricName="node_cpu_utilization",
                Dimensions=[
                    {"Name": "ClusterName", "Value": self.cluster_name},
                ],
            ):
                for metric in page.get("Metrics", []):
                    dims = {d["Name"]: d["Value"] for d in metric.get("Dimensions", [])}
                    node_name = dims.get("NodeName")
                    instance_id = dims.get("InstanceId", "")

                    if not node_name or node_name in seen:
                        continue
                    seen.add(node_name)

                    nodes.append({"NodeName": node_name, "InstanceId": instance_id})

        except Exception as e:
            logger.error(f"Failed to discover nodes for cluster {self.cluster_name}: {e}")

        return nodes

    def list_nodes(self) -> List[Dict[str, str]]:
        """노드 목록 조회. mock이면 mock 데이터 반환."""
        if self.use_mock:
            return self._mock_nodes()
        return self.discover_nodes()

    def fetch_metrics(
        self,
        node_name: str,
        instance_id: str = "",
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """개별 노드의 4종 메트릭 조회 (CW Container Insights).

        Args:
            node_name: 노드 이름
            instance_id: EC2 인스턴스 ID (Container Insights dimension 매칭에 필요)
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(node_name)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in EKS_NODE_METRICS.items():
            try:
                dimensions = [
                    {"Name": "ClusterName", "Value": self.cluster_name},
                    {"Name": "NodeName", "Value": node_name},
                ]
                if instance_id:
                    dimensions.append({"Name": "InstanceId", "Value": instance_id})

                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="ContainerInsights",
                    MetricName=metric_config["cw_metric_name"],
                    Dimensions=dimensions,
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                data_points.sort(key=lambda x: x.timestamp)

                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="eks-node",
                    resource_id=node_name,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(
                    f"Failed to fetch EKS Node metric {metric_name} "
                    f"for {node_name}: {e}"
                )

        return results

    def detect_drift(
        self,
        node_name: str,
        instance_id: str = "",
        node_group_name: Optional[str] = None,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """노드 메트릭 drift 감지.

        절대 임계값 (CPU/Memory/Disk) + Z-score (baseline 있을 때).

        Args:
            node_name: 노드 이름
            instance_id: EC2 인스턴스 ID
            node_group_name: 노드그룹 이름
            baseline_avg: 메트릭별 baseline 평균
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(node_name, instance_id=instance_id)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = EKS_NODE_METRICS.get(metric_name, {})

            # 절대 임계값 기반 체크
            thresholds = self._threshold_overrides.get(metric_name) or metric_config.get("severity_threshold")
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="eks-node",
                        resource_id=node_name,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_node_recommendation(metric_name, severity),
                        detected_at=now,
                        node_name=node_name,
                        node_group_name=node_group_name,
                        data_points=result.data_points,
                    ))

            # ECOD 앙상블 탐지 (임계값 없는 메트릭)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="eks-node",
                    resource_id=node_name,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_node_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                    node_name=node_name,
                    node_group_name=node_group_name,
                )
                if drift:
                    drift.data_points = result.data_points
                    drifts.append(drift)

        return drifts

    def get_node_summaries(self) -> Dict[str, NodeSummary]:
        """전체 노드의 현재 메트릭 요약 (HTML 리포트 헤더용).

        Returns:
            노드명을 키로 하는 NodeSummary 딕셔너리
        """
        node_to_ng = self.get_node_to_nodegroup_map()
        summaries = {}

        for node_info in self.list_nodes():
            node_name = node_info["NodeName"]
            instance_id = node_info.get("InstanceId", "")
            metrics = self.fetch_metrics(node_name, instance_id=instance_id)

            cpu = metrics.get("node_cpu_utilization")
            mem = metrics.get("node_memory_utilization")
            disk = metrics.get("node_filesystem_utilization")
            pods = metrics.get("node_number_of_running_pods")

            summaries[node_name] = NodeSummary(
                node_name=node_name,
                instance_id=instance_id,
                node_group_name=node_to_ng.get(node_name),
                cpu_percent=cpu.statistics.get("latest") if cpu and cpu.statistics else None,
                memory_percent=mem.statistics.get("latest") if mem and mem.statistics else None,
                disk_percent=disk.statistics.get("latest") if disk and disk.statistics else None,
                pod_count=int(pods.statistics.get("latest")) if pods and pods.statistics else None,
                max_pods=110,  # EKS 기본 max pods (ENI 기반, 인스턴스 타입별 다름)
            )

        return summaries

    # =========================================================================
    # 노드그룹
    # =========================================================================

    def list_node_groups(self) -> List[str]:
        """EKS API: list_nodegroups."""
        if self.use_mock:
            return ["ng-worker", "ng-compute"]

        try:
            response = self.eks_client.list_nodegroups(clusterName=self.cluster_name)
            return response.get("nodegroups", [])
        except Exception as e:
            logger.error(f"Failed to list nodegroups for cluster {self.cluster_name}: {e}")
            return []

    def get_node_group_statuses(self) -> List[NodeGroupStatus]:
        """전체 노드그룹 상태 조회."""
        if self.use_mock:
            return self._mock_node_group_statuses()

        statuses = []
        for ng_name in self.list_node_groups():
            try:
                response = self.eks_client.describe_nodegroup(
                    clusterName=self.cluster_name,
                    nodegroupName=ng_name,
                )
                ng = response.get("nodegroup", {})
                scaling = ng.get("scalingConfig", {})
                health = ng.get("health", {})
                health_issues = [
                    f"{issue.get('code', 'Unknown')}: {issue.get('message', '')}"
                    for issue in health.get("issues", [])
                ]

                statuses.append(NodeGroupStatus(
                    nodegroup_name=ng_name,
                    cluster_name=self.cluster_name,
                    status=ng.get("status", "UNKNOWN"),
                    instance_types=ng.get("instanceTypes", []),
                    desired_size=scaling.get("desiredSize", 0),
                    current_size=scaling.get("desiredSize", 0),  # EKS API는 current를 직접 제공하지 않음
                    min_size=scaling.get("minSize", 0),
                    max_size=scaling.get("maxSize", 0),
                    health_issues=health_issues,
                ))
            except Exception as e:
                logger.error(f"Failed to describe nodegroup {ng_name}: {e}")

        return statuses

    def detect_node_group_issues(
        self,
        node_summaries: Optional[Dict[str, NodeSummary]] = None,
    ) -> List[MetricDrift]:
        """노드그룹 이상 감지.

        판별 항목:
        1. 스케일링 실패: desired != current
        2. 용량 포화: current/max >= threshold
        3. 그룹 평균 CPU
        4. 그룹 평균 Memory
        5. Health Issues

        Args:
            node_summaries: 노드 요약 (None이면 자동 조회)

        Returns:
            감지된 drift 목록
        """
        statuses = self.get_node_group_statuses()
        if node_summaries is None:
            node_summaries = self.get_node_summaries()

        drifts = []
        now = datetime.now(KST)

        for ng_status in statuses:
            ng_name = ng_status.nodegroup_name

            # 1. 스케일링 실패
            if ng_status.has_scaling_issue:
                drifts.append(MetricDrift(
                    metric_type="eks-nodegroup",
                    resource_id=ng_name,
                    metric_name="scaling_status",
                    current_value=float(ng_status.current_size),
                    baseline_avg=float(ng_status.desired_size),
                    baseline_stddev=0,
                    z_score=0,
                    severity=DriftSeverity.HIGH,
                    threshold_type="absolute",
                    threshold_value=0,
                    description=(
                        f"노드그룹 스케일링 불일치: desired={ng_status.desired_size}, "
                        f"current={ng_status.current_size}"
                    ),
                    recommendation="노드그룹 스케일링 상태를 확인하세요. ASG 이벤트 및 인스턴스 시작 실패 여부를 점검하세요.",
                    detected_at=now,
                    node_group_name=ng_name,
                ))

            # 2. 용량 포화
            if ng_status.max_size > 0:
                capacity_pct = (ng_status.current_size / ng_status.max_size) * 100
                severity = None
                if capacity_pct >= self._ng_capacity_threshold["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif capacity_pct >= self._ng_capacity_threshold["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="eks-nodegroup",
                        resource_id=ng_name,
                        metric_name="capacity_utilization",
                        current_value=capacity_pct,
                        baseline_avg=0,
                        baseline_stddev=0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=self._ng_capacity_threshold[severity.value.upper()],
                        description=(
                            f"노드그룹 용량 포화: {ng_status.current_size}/{ng_status.max_size} "
                            f"({capacity_pct:.0f}%)"
                        ),
                        recommendation="노드그룹 max_size 증가 또는 워크로드 분산을 검토하세요.",
                        detected_at=now,
                        node_group_name=ng_name,
                    ))

            # 3 & 4. 그룹 평균 CPU / Memory
            ng_nodes = [
                ns for ns in node_summaries.values()
                if ns.node_group_name == ng_name
            ]

            if ng_nodes:
                # 그룹 평균 CPU
                cpu_values = [n.cpu_percent for n in ng_nodes if n.cpu_percent is not None]
                if cpu_values:
                    avg_cpu = sum(cpu_values) / len(cpu_values)
                    severity = None
                    if avg_cpu >= self._ng_avg_cpu_threshold["CRITICAL"]:
                        severity = DriftSeverity.CRITICAL
                    elif avg_cpu >= self._ng_avg_cpu_threshold["HIGH"]:
                        severity = DriftSeverity.HIGH

                    if severity:
                        drifts.append(MetricDrift(
                            metric_type="eks-nodegroup",
                            resource_id=ng_name,
                            metric_name="avg_cpu_utilization",
                            current_value=avg_cpu,
                            baseline_avg=0,
                            baseline_stddev=0,
                            z_score=0,
                            severity=severity,
                            threshold_type="absolute",
                            threshold_value=self._ng_avg_cpu_threshold[severity.value.upper()],
                            description=f"노드그룹 평균 CPU: {avg_cpu:.1f}% ({len(cpu_values)}개 노드)",
                            recommendation="노드그룹 스케일아웃 또는 워크로드 재분배를 검토하세요.",
                            detected_at=now,
                            node_group_name=ng_name,
                        ))

                # 그룹 평균 Memory
                mem_values = [n.memory_percent for n in ng_nodes if n.memory_percent is not None]
                if mem_values:
                    avg_mem = sum(mem_values) / len(mem_values)
                    severity = None
                    if avg_mem >= self._ng_avg_memory_threshold["CRITICAL"]:
                        severity = DriftSeverity.CRITICAL
                    elif avg_mem >= self._ng_avg_memory_threshold["HIGH"]:
                        severity = DriftSeverity.HIGH

                    if severity:
                        drifts.append(MetricDrift(
                            metric_type="eks-nodegroup",
                            resource_id=ng_name,
                            metric_name="avg_memory_utilization",
                            current_value=avg_mem,
                            baseline_avg=0,
                            baseline_stddev=0,
                            z_score=0,
                            severity=severity,
                            threshold_type="absolute",
                            threshold_value=self._ng_avg_memory_threshold[severity.value.upper()],
                            description=f"노드그룹 평균 Memory: {avg_mem:.1f}% ({len(mem_values)}개 노드)",
                            recommendation="메모리 사용량이 높습니다. 노드 스케일아웃 또는 Pod 리소스 조정을 검토하세요.",
                            detected_at=now,
                            node_group_name=ng_name,
                        ))

            # 5. Health Issues
            if ng_status.health_issues:
                drifts.append(MetricDrift(
                    metric_type="eks-nodegroup",
                    resource_id=ng_name,
                    metric_name="health_issues",
                    current_value=float(len(ng_status.health_issues)),
                    baseline_avg=0,
                    baseline_stddev=0,
                    z_score=0,
                    severity=DriftSeverity.HIGH,
                    threshold_type="absolute",
                    threshold_value=0,
                    description=f"노드그룹 헬스 이슈: {'; '.join(ng_status.health_issues)}",
                    recommendation="EKS 콘솔에서 노드그룹 헬스 이슈를 확인하고 조치하세요.",
                    detected_at=now,
                    node_group_name=ng_name,
                ))

        return drifts

    # =========================================================================
    # 노드 → 노드그룹 매핑
    # =========================================================================

    def get_node_to_nodegroup_map(self) -> Dict[str, str]:
        """EC2 describe_instances로 노드 → 노드그룹 매핑 조회.

        CloudWatch list_metrics에는 종료된 노드도 남아있을 수 있으므로,
        InstanceIds 직접 지정 대신 Filter로 조회하여 존재하지 않는 인스턴스를 자동 무시한다.

        Returns:
            {node_name: nodegroup_name, ...}
        """
        if self.use_mock:
            return self._mock_node_to_nodegroup_map()

        mapping = {}
        nodes = self.list_nodes()
        instance_ids = [n["InstanceId"] for n in nodes if n.get("InstanceId")]
        node_by_instance = {n["InstanceId"]: n["NodeName"] for n in nodes if n.get("InstanceId")}

        if not instance_ids:
            return mapping

        try:
            # Filter 기반 조회: 존재하지 않는(종료된) 인스턴스는 자동으로 제외됨
            paginator = self.ec2_client.get_paginator("describe_instances")
            for page in paginator.paginate(
                Filters=[
                    {"Name": "instance-id", "Values": instance_ids},
                ],
            ):
                for reservation in page.get("Reservations", []):
                    for instance in reservation.get("Instances", []):
                        inst_id = instance.get("InstanceId")
                        tags = {t["Key"]: t["Value"] for t in instance.get("Tags", [])}
                        ng_name = tags.get("eks:nodegroup-name")
                        node_name = node_by_instance.get(inst_id)

                        if node_name and ng_name:
                            mapping[node_name] = ng_name

            unmapped = set(node_by_instance.values()) - set(mapping.keys())
            if unmapped:
                logger.info(f"Nodes without nodegroup mapping (possibly terminated): {unmapped}")

        except Exception as e:
            logger.error(f"Failed to get node-to-nodegroup mapping: {e}")

        return mapping

    # =========================================================================
    # 권장사항
    # =========================================================================

    def _get_node_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """노드 메트릭별 권장 조치 반환."""
        recommendations = {
            "node_cpu_utilization": "노드 CPU 사용률이 높습니다. Pod 스케줄링 분산 또는 노드 스케일아웃을 검토하세요.",
            "node_memory_utilization": "노드 메모리 사용률이 높습니다. 메모리 집약 Pod 재배치 또는 노드 스케일아웃을 검토하세요.",
            "node_filesystem_utilization": "노드 디스크 사용률이 높습니다. 불필요한 이미지/로그 정리 또는 볼륨 확장을 검토하세요.",
            "node_number_of_running_pods": "노드 Pod 수가 이상 변동되었습니다. 스케줄링 패턴을 확인하세요.",
        }
        return recommendations.get(metric_name, "EKS 노드 메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    # =========================================================================
    # Mock 데이터
    # =========================================================================

    def _mock_nodes(self) -> List[Dict[str, str]]:
        """Mock 노드 목록."""
        return [
            {"NodeName": "ip-10-0-1-100.compute.internal", "InstanceId": "i-mock-node-1"},
            {"NodeName": "ip-10-0-1-200.compute.internal", "InstanceId": "i-mock-node-2"},
            {"NodeName": "ip-10-0-2-100.compute.internal", "InstanceId": "i-mock-node-3"},
        ]

    def _mock_metrics(self, node_name: str) -> Dict[str, MetricResult]:
        """Mock 노드 메트릭. node-2는 CPU HIGH."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        # 노드별 차별화된 mock 데이터
        mock_profiles = {
            "ip-10-0-1-100.compute.internal": {
                "node_cpu_utilization": {"avg": 42.0, "min": 30.0, "max": 55.0, "latest": 45.0},
                "node_memory_utilization": {"avg": 58.0, "min": 50.0, "max": 65.0, "latest": 60.0},
                "node_filesystem_utilization": {"avg": 35.0, "min": 30.0, "max": 40.0, "latest": 38.0},
                "node_number_of_running_pods": {"avg": 12.0, "min": 10.0, "max": 15.0, "latest": 12.0},
            },
            "ip-10-0-1-200.compute.internal": {  # HIGH CPU node
                "node_cpu_utilization": {"avg": 82.0, "min": 70.0, "max": 92.0, "latest": 85.0},
                "node_memory_utilization": {"avg": 75.0, "min": 65.0, "max": 82.0, "latest": 78.0},
                "node_filesystem_utilization": {"avg": 38.0, "min": 30.0, "max": 45.0, "latest": 40.0},
                "node_number_of_running_pods": {"avg": 43.0, "min": 38.0, "max": 48.0, "latest": 45.0},
            },
            "ip-10-0-2-100.compute.internal": {
                "node_cpu_utilization": {"avg": 30.0, "min": 20.0, "max": 45.0, "latest": 35.0},
                "node_memory_utilization": {"avg": 45.0, "min": 35.0, "max": 55.0, "latest": 48.0},
                "node_filesystem_utilization": {"avg": 25.0, "min": 20.0, "max": 30.0, "latest": 28.0},
                "node_number_of_running_pods": {"avg": 8.0, "min": 5.0, "max": 12.0, "latest": 8.0},
            },
        }

        # 해당 노드 프로파일이 없으면 기본값 사용
        profile = mock_profiles.get(node_name, {
            "node_cpu_utilization": {"avg": 40.0, "min": 30.0, "max": 50.0, "latest": 40.0},
            "node_memory_utilization": {"avg": 50.0, "min": 40.0, "max": 60.0, "latest": 50.0},
            "node_filesystem_utilization": {"avg": 30.0, "min": 25.0, "max": 35.0, "latest": 30.0},
            "node_number_of_running_pods": {"avg": 10.0, "min": 8.0, "max": 12.0, "latest": 10.0},
        })

        results = {}
        for metric_name, stats in profile.items():
            metric_config = EKS_NODE_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="eks-node",
                resource_id=node_name,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results

    def _mock_node_group_statuses(self) -> List[NodeGroupStatus]:
        """Mock 노드그룹 상태."""
        return [
            NodeGroupStatus(
                nodegroup_name="ng-worker",
                cluster_name=self.cluster_name,
                status="ACTIVE",
                instance_types=["m5.2xlarge"],
                desired_size=2,
                current_size=2,
                min_size=2,
                max_size=10,
                health_issues=[],
            ),
            NodeGroupStatus(
                nodegroup_name="ng-compute",
                cluster_name=self.cluster_name,
                status="ACTIVE",
                instance_types=["c5.4xlarge"],
                desired_size=1,
                current_size=1,
                min_size=1,
                max_size=5,
                health_issues=[],
            ),
        ]

    def _mock_node_to_nodegroup_map(self) -> Dict[str, str]:
        """Mock 노드 → 노드그룹 매핑."""
        return {
            "ip-10-0-1-100.compute.internal": "ng-worker",
            "ip-10-0-1-200.compute.internal": "ng-worker",
            "ip-10-0-2-100.compute.internal": "ng-compute",
        }
