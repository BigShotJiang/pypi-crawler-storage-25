"""
MetricAnomalyDetector - ECOD 앙상블 탐지 어댑터.

bdp_common의 EnsembleDetector를 bdp_metrics에 맞게 래핑.
z-score 기반 메트릭에 앙상블 탐지를 적용하고 MetricDrift로 변환.
"""

import logging
from datetime import datetime
from typing import List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_common.anomaly import (
    AnomalyResult,
    AnomalySeverity,
    EnsembleDetector,
    TimeSeriesData,
)
from src.agent_server.bdp_common.anomaly.patterns import create_default_pattern_chain
from .models import DriftSeverity, MetricDrift

logger = logging.getLogger(__name__)

# 스파이크성 변동이 정상인 메트릭 (False Positive 감소)
SPIKE_NORMAL_METRICS = [
    "RunningJobCount",
    "QueuedTasks",
    "DagProcessingFilePathQueueSize",
]

# AnomalySeverity → DriftSeverity 매핑
_SEVERITY_MAP = {
    AnomalySeverity.CRITICAL: DriftSeverity.CRITICAL,
    AnomalySeverity.HIGH: DriftSeverity.HIGH,
    AnomalySeverity.MEDIUM: DriftSeverity.MEDIUM,
    AnomalySeverity.LOW: DriftSeverity.LOW,
}


class MetricAnomalyDetector:
    """ECOD 앙상블 기반 메트릭 이상 탐지기.

    EnsembleDetector를 래핑하여 metrics 도메인에 맞는 인터페이스 제공.
    """

    def __init__(
        self,
        sensitivity: float = 0.7,
        spike_normal_metrics: Optional[List[str]] = None,
    ):
        pattern_chain = create_default_pattern_chain(
            spike_normal_names=spike_normal_metrics or SPIKE_NORMAL_METRICS,
        )
        self.detector = EnsembleDetector(
            sensitivity=sensitivity,
            pattern_chain=pattern_chain,
        )

    def detect(
        self,
        metric_name: str,
        resource_id: str,
        metric_type: str,
        current_value: float,
        historical_values: List[float],
        historical_timestamps: List[str],
    ) -> Optional[AnomalyResult]:
        """앙상블 이상 탐지 수행.

        Returns:
            AnomalyResult 또는 None (데이터 부족 시)
        """
        data = TimeSeriesData(
            name=f"{metric_type}/{metric_name}",
            resource_id=resource_id,
            current_value=current_value,
            historical_values=historical_values + [current_value],
            timestamps=historical_timestamps + [get_kst_now().isoformat()],
        )

        result = self.detector.analyze(data)

        if result.detection_method == "insufficient_data":
            return None

        return result

    def detect_and_build_drift(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        current_value: float,
        baseline_avg: float,
        baseline_stddev: float,
        historical_values: List[float],
        historical_timestamps: List[str],
        description_prefix: str,
        recommendation: str,
        detected_at: datetime,
        node_name: Optional[str] = None,
        node_group_name: Optional[str] = None,
    ) -> Optional[MetricDrift]:
        """앙상블 탐지 후 MetricDrift로 변환.

        Returns:
            MetricDrift (이상 탐지 시) 또는 None
        """
        result = self.detect(
            metric_name=metric_name,
            resource_id=resource_id,
            metric_type=metric_type,
            current_value=current_value,
            historical_values=historical_values,
            historical_timestamps=historical_timestamps,
        )

        if result is None or not result.is_anomaly:
            return None

        severity = _SEVERITY_MAP.get(result.severity, DriftSeverity.HIGH)

        # Z-score 계산 (역호환)
        z_score = 0.0
        if baseline_stddev > 0:
            z_score = (current_value - baseline_avg) / baseline_stddev

        return MetricDrift(
            metric_type=metric_type,
            resource_id=resource_id,
            metric_name=metric_name,
            current_value=current_value,
            baseline_avg=baseline_avg,
            baseline_stddev=baseline_stddev,
            z_score=z_score,
            severity=severity,
            threshold_type="ensemble",
            threshold_value=result.confidence_score,
            description=(
                f"{description_prefix}: "
                f"confidence={result.confidence_score:.2f}, "
                f"change={result.change_percent:+.1f}%"
            ),
            recommendation=recommendation,
            detected_at=detected_at,
            node_name=node_name,
            node_group_name=node_group_name,
            confidence_score=result.confidence_score,
            detection_method_detail=result.detection_method,
            pattern_contexts=result.pattern_contexts or None,
        )
