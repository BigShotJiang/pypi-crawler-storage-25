"""
BDP Metrics Agent - E2E Runner Service.

E2E 시나리오 테스트를 실행하고 리포트를 생성하는 서비스 클래스.
scripts/run_metrics_e2e.py의 핵심 로직을 캡슐화.
"""

import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from .e2e_report_generator import (
    MetricsE2EGroupResult,
    MetricsE2EReportData,
    MetricsE2EReportGenerator,
    MetricsE2ETestResult,
)


@dataclass
class E2ERunResult:
    """E2E 실행 결과."""

    pass_rate: float
    passed: int
    failed: int
    total: int
    e2e_report_path: str
    scenarios: List[Dict[str, Any]]


# ── Severity helpers ──

SEVERITY_ORDER = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
}

SEVERITY_EMOJI = {
    "critical": "🔴",
    "high": "🟠",
    "medium": "🟡",
    "low": "🟢",
}

TYPE_KO = {
    "msk": "MSK", "eks-pod": "EKS Pod", "eks-node": "EKS Node",
    "rds": "RDS", "mwaa": "MWAA", "sagemaker-endpoint": "SageMaker",
    "emr-cluster": "EMR Cluster", "emr-serverless": "EMR Serverless",
    "subnet-ip": "Subnet IP", "service-quota": "Service Quota",
}


def _get_highest_severity(drifts) -> str:
    if not drifts:
        return "low"
    best = "low"
    for d in drifts:
        sev = d.severity if hasattr(d, "severity") else d.get("severity", "low")
        if SEVERITY_ORDER.get(sev, 99) < SEVERITY_ORDER.get(best, 99):
            best = sev
    return best


def _severity_distance(expected: str, actual: str) -> int:
    return abs(SEVERITY_ORDER.get(expected, 99) - SEVERITY_ORDER.get(actual, 99))


class MetricsE2ERunner:
    """E2E 시나리오 테스트 실행기 (Mock 전용)."""

    def run_all(self, output_dir: str = "reports/") -> E2ERunResult:
        """전체 E2E 시나리오 실행 및 리포트 생성."""
        from tests.agents.bdp_metrics.scenarios.scenario_factory import ScenarioFactory

        # 1. 시나리오 로드
        all_groups = ScenarioFactory.get_all_groups()
        groups_map = {
            g.id: {"name": g.name, "name_ko": g.name_ko, "emoji": g.emoji}
            for g in all_groups
        }
        scenarios = ScenarioFactory.get_all_scenarios()

        # 2. 시나리오 실행
        results: List[MetricsE2ETestResult] = []
        for scenario in scenarios:
            result = self._run_scenario(scenario)
            results.append(result)

        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        pass_rate = (passed / len(results) * 100) if results else 0

        # 3. 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        report_data = self._build_report_data(results, groups_map)
        e2e_path = str(output_path / "metrics_e2e_report.html")
        MetricsE2EReportGenerator().generate_report(report_data, e2e_path)

        return E2ERunResult(
            pass_rate=pass_rate,
            passed=passed,
            failed=failed,
            total=len(results),
            e2e_report_path=e2e_path,
            scenarios=[
                {
                    "scenario_id": r.scenario_id,
                    "scenario_name_ko": r.scenario_name_ko,
                    "passed": r.passed,
                    "expected_severity": r.expected_severity,
                    "actual_severity": r.actual_severity,
                }
                for r in results
            ],
        )

    def _run_scenario(self, scenario) -> MetricsE2ETestResult:
        """단일 시나리오 실행."""
        start = time.perf_counter()

        drifts = scenario.drifts
        actual_drift_count = len(drifts)
        actual_has_drift = actual_drift_count > 0
        actual_severity = _get_highest_severity(drifts)

        elapsed_ms = (time.perf_counter() - start) * 1000

        # Serialize drifts
        drift_data = []
        for d in drifts:
            drift_data.append({
                "metric_type": d.metric_type,
                "resource_id": d.resource_id,
                "metric_name": d.metric_name,
                "current_value": d.current_value,
                "baseline_avg": d.baseline_avg,
                "baseline_stddev": d.baseline_stddev,
                "z_score": d.z_score,
                "severity": d.severity,
                "threshold_type": d.threshold_type,
                "threshold_value": d.threshold_value,
                "description": d.description,
                "resource_name": d.resource_name,
                "node_name": d.node_name,
                "node_group_name": d.node_group_name,
            })

        # Pass/fail evaluation
        passed = True
        reasons = []

        if scenario.expected_has_drift != actual_has_drift:
            passed = False
            reasons.append(
                f"드리프트 존재 불일치: 예상={'있음' if scenario.expected_has_drift else '없음'}, "
                f"실제={'있음' if actual_has_drift else '없음'}"
            )
        else:
            reasons.append(f"드리프트 존재 일치: {'있음' if actual_has_drift else '없음'}")

        if actual_has_drift and scenario.expected_has_drift:
            dist = _severity_distance(scenario.expected_severity, actual_severity)
            if dist == 0:
                reasons.append(f"심각도 정확 일치: {actual_severity}")
            elif dist <= 1:
                reasons.append(
                    f"심각도 허용 범위: 예상={scenario.expected_severity}, 실제={actual_severity}"
                )
            else:
                passed = False
                reasons.append(
                    f"심각도 불일치: 예상={scenario.expected_severity}, "
                    f"실제={actual_severity} (거리={dist})"
                )

            if actual_drift_count < scenario.expected_drift_count:
                passed = False
                reasons.append(
                    f"드리프트 수 부족: 예상≥{scenario.expected_drift_count}, "
                    f"실제={actual_drift_count}"
                )

        # Kakao preview & summary
        kakao_preview = {}
        summary_text = ""
        if actual_has_drift and drift_data:
            SEVERITY_KO = {"critical": "심각", "high": "높음", "medium": "보통", "low": "낮음"}
            sev_emoji = SEVERITY_EMOJI.get(actual_severity, "⚪")
            sev_counts = defaultdict(int)
            for d in drift_data:
                sev_counts[d["severity"]] += 1

            kakao_title = f"{sev_emoji} 메트릭 Drift: {scenario.name_ko}"

            kakao_lines = []
            if actual_drift_count == 1:
                d = drift_data[0]
                type_label = TYPE_KO.get(d["metric_type"], d["metric_type"])
                kakao_lines.append(
                    f"{type_label}({d['resource_id']}) {d['metric_name']}이(가) "
                    f"기준값 {d['baseline_avg']:.1f}인데 현재 {d['current_value']:.1f}로 "
                    f"Z-score {d['z_score']:.2f} 탐지되었습니다."
                )
                if d.get("description"):
                    kakao_lines.append("")
                    kakao_lines.append(d["description"])
            else:
                kakao_lines.append(f"총 {actual_drift_count}건의 메트릭 Drift가 탐지되었습니다.")
                kakao_lines.append("")
                for d in drift_data:
                    type_label = TYPE_KO.get(d["metric_type"], d["metric_type"])
                    kakao_lines.append(
                        f"  {SEVERITY_EMOJI.get(d['severity'], '⚪')} {type_label}({d['resource_id']}): "
                        f"{d['metric_name']} {d['current_value']:.1f} "
                        f"(기준 {d['baseline_avg']:.1f}, Z-score {d['z_score']:.2f})"
                    )

            kakao_lines.append("")
            sev_parts = []
            for sev in ["critical", "high", "medium", "low"]:
                cnt = sev_counts.get(sev, 0)
                if cnt > 0:
                    sev_parts.append(f"{SEVERITY_KO[sev]}: {cnt}건")
            kakao_lines.append(f"[심각도: {' | '.join(sev_parts)}]")

            kakao_preview = {"title": kakao_title, "message": "\n".join(kakao_lines)}

            summary_lines = [
                f"{sev_emoji} 메트릭 Drift 탐지: {actual_drift_count}건",
                "━━━━━━━━━━━━━━━━━━━━━━━━━",
                f"총 {actual_drift_count}건의 메트릭 Drift가 탐지되었습니다.",
                "",
                "【심각도 분포】",
            ]
            sev_info = []
            for sev in ["critical", "high", "medium", "low"]:
                cnt = sev_counts.get(sev, 0)
                sev_info.append(f"{SEVERITY_EMOJI[sev]} {sev.upper()}: {cnt}건")
            summary_lines.append("  " + " / ".join(sev_info))
            summary_lines.append("")
            summary_lines.append("【드리프트 상세】")
            for d in drift_data:
                type_label = TYPE_KO.get(d["metric_type"], d["metric_type"])
                summary_lines.append(
                    f"  {type_label} - {d['resource_id']}: {d['metric_name']}"
                    f" (현재: {d['current_value']:.1f}, 기준: {d['baseline_avg']:.1f})"
                )
            summary_text = "\n".join(summary_lines)

        return MetricsE2ETestResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            scenario_name_ko=scenario.name_ko,
            description_ko=scenario.description_ko,
            group_id=scenario.group_id,
            group_name=scenario.group_name,
            expected_severity=scenario.expected_severity,
            expected_has_drift=scenario.expected_has_drift,
            expected_drift_count=scenario.expected_drift_count,
            actual_severity=actual_severity,
            actual_has_drift=actual_has_drift,
            actual_drift_count=actual_drift_count,
            actual_drifts=drift_data,
            passed=passed,
            pass_reason=" | ".join(reasons),
            execution_time_ms=elapsed_ms,
            kakao_preview=kakao_preview,
            summary_text=summary_text,
        )

    @staticmethod
    def _build_report_data(results, groups_map) -> MetricsE2EReportData:
        """리포트 데이터 빌드."""
        grouped = defaultdict(list)
        for r in results:
            grouped[r.group_id].append(r)

        group_results = []
        for gid in sorted(grouped.keys()):
            g_results = grouped[gid]
            g_passed = sum(1 for r in g_results if r.passed)
            g_total = len(g_results)
            g_info = groups_map.get(gid, {})
            group_results.append(
                MetricsE2EGroupResult(
                    group_id=gid,
                    group_name=g_info.get("name", f"Group {gid}"),
                    group_name_ko=g_info.get("name_ko", ""),
                    emoji=g_info.get("emoji", ""),
                    total=g_total,
                    passed=g_passed,
                    failed=g_total - g_passed,
                    pass_rate=(g_passed / g_total * 100) if g_total else 0,
                    results=g_results,
                )
            )

        total = len(results)
        passed = sum(1 for r in results if r.passed)
        all_latencies = [r.execution_time_ms for r in results]

        return MetricsE2EReportData(
            total=total,
            passed=passed,
            failed=total - passed,
            pass_rate=(passed / total * 100) if total else 0,
            avg_latency_ms=sum(all_latencies) / len(all_latencies) if all_latencies else 0,
            groups=group_results,
            all_results=results,
        )
