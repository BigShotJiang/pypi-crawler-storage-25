"""
EMR Cluster Metrics Fetcher.

CloudWatch 기반 EMR 클러스터 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
    Z_SCORE_THRESHOLDS,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# EMR Cluster CloudWatch 메트릭 정의
EMR_CLUSTER_METRICS = {
    "IsIdle": {
        "description": "클러스터 유휴 상태 여부",
        "unit": "None",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 0.8},
        "detection_type": "flag",  # avg > 0.8 이면 유휴 상태 (비용 낭비)
    },
    "HDFSUtilization": {
        "description": "HDFS 사용률",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "YARNMemoryAvailablePercentage": {
        "description": "YARN 가용 메모리 비율",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 30, "CRITICAL": 15},
        "inverted": True,  # 낮을수록 위험
    },
}


class EMRClusterMetricsFetcher:
    """EMR Cluster CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - IsIdle: flag 방식 (avg > 0.8 → HIGH, 유휴 상태로 비용 낭비)
    - HDFSUtilization: 절대 임계값 기반
    - YARNMemoryAvailablePercentage: inverted 임계값 (낮을수록 위험)
    """

    def __init__(
        self,
        cloudwatch_client=None,
        emr_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._emr_client = emr_client
        self._metric_cache = metric_cache

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def emr_client(self):
        if self._emr_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._emr_client = get_boto3_client("emr", config=config)
        return self._emr_client

    def list_clusters(self) -> List[str]:
        """EMR 클러스터 목록 조회 (RUNNING, WAITING 상태)."""
        if self.use_mock:
            return ["j-MOCK001", "j-MOCK002"]

        clusters = []
        try:
            paginator = self.emr_client.get_paginator("list_clusters")
            for page in paginator.paginate(ClusterStates=["RUNNING", "WAITING"]):
                for cluster in page.get("Clusters", []):
                    clusters.append(cluster.get("Id"))
        except Exception as e:
            logger.error(f"Failed to list EMR clusters: {e}")

        return clusters

    def fetch_metrics(
        self,
        cluster_id: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """EMR 클러스터의 모든 주요 메트릭 조회.

        Args:
            cluster_id: EMR 클러스터 ID (e.g. j-XXXXX)
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(cluster_id)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in EMR_CLUSTER_METRICS.items():
            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="AWS/ElasticMapReduce",
                    MetricName=metric_name,
                    Dimensions=[
                        {"Name": "JobFlowId", "Value": cluster_id},
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="emr-cluster",
                    resource_id=cluster_id,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch EMR metric {metric_name} for {cluster_id}: {e}")

        return results

    def detect_drift(
        self,
        cluster_id: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            cluster_id: EMR 클러스터 ID
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(cluster_id)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = EMR_CLUSTER_METRICS.get(metric_name, {})
            thresholds = metric_config.get("severity_threshold")

            # flag 방식 (IsIdle)
            if metric_config.get("detection_type") == "flag":
                if thresholds and current_value > thresholds["HIGH"]:
                    drifts.append(MetricDrift(
                        metric_type="emr-cluster",
                        resource_id=cluster_id,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=DriftSeverity.HIGH,
                        threshold_type="flag",
                        threshold_value=thresholds["HIGH"],
                        description="클러스터가 유휴 상태입니다 (비용 낭비)",
                        recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                        detected_at=now,
                    ))
                continue

            # inverted 방식 (YARNMemoryAvailablePercentage: 낮을수록 위험)
            if metric_config.get("inverted") and thresholds:
                severity = None
                if current_value < thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif current_value < thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="emr-cluster",
                        resource_id=cluster_id,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}%",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                    ))
                continue

            # 절대 임계값 기반 체크 (HDFSUtilization)
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="emr-cluster",
                        resource_id=cluster_id,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                    ))

            # Z-score 기반 체크 (baseline이 있는 경우, 임계값 없는 메트릭)
            elif baseline_avg and baseline_stddev:
                avg = baseline_avg.get(metric_name)
                stddev = baseline_stddev.get(metric_name)

                if avg is not None and stddev is not None and stddev > 0:
                    z_score = (current_value - avg) / stddev

                    severity = None
                    if abs(z_score) > Z_SCORE_THRESHOLDS["CRITICAL"]:
                        severity = DriftSeverity.CRITICAL
                    elif abs(z_score) > Z_SCORE_THRESHOLDS["HIGH"]:
                        severity = DriftSeverity.HIGH

                    if severity:
                        drifts.append(MetricDrift(
                            metric_type="emr-cluster",
                            resource_id=cluster_id,
                            metric_name=metric_name,
                            current_value=current_value,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            z_score=z_score,
                            severity=severity,
                            threshold_type="z_score",
                            threshold_value=Z_SCORE_THRESHOLDS[severity.value.upper()],
                            description=f"{metric_config.get('description', metric_name)}: Z-score {z_score:.2f}",
                            recommendation=self._get_recommendation(metric_name, severity),
                            detected_at=now,
                        ))

        return drifts

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "IsIdle": "클러스터가 유휴 상태입니다. 비용 절감을 위해 종료 또는 자동 종료 설정을 검토하세요.",
            "HDFSUtilization": "HDFS 사용률이 높습니다. 데이터 정리 또는 클러스터 확장을 검토하세요.",
            "YARNMemoryAvailablePercentage": "YARN 가용 메모리가 부족합니다. 클러스터 확장 또는 작업 최적화를 검토하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def _mock_metrics(self, cluster_id: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        mock_data = {
            "IsIdle": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            "HDFSUtilization": {"avg": 45.0, "min": 35.0, "max": 55.0, "latest": 48.0},
            "YARNMemoryAvailablePercentage": {"avg": 65.0, "min": 55.0, "max": 75.0, "latest": 62.0},
        }

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = EMR_CLUSTER_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="emr-cluster",
                resource_id=cluster_id,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
