"""
EKS Pod Metrics Fetcher.

CloudWatch Container Insights 기반 EKS Pod 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# 시스템 Namespace (기본 제외 대상)
SYSTEM_NAMESPACES = {"kube-system", "kube-public", "kube-node-lease"}

# EKS Pod CloudWatch Container Insights 메트릭 정의
EKS_POD_METRICS = {
    "pod_cpu_utilization": {
        "description": "Pod CPU 사용률",
        "cw_metric_name": "pod_cpu_utilization",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "pod_memory_utilization": {
        "description": "Pod 메모리 사용률",
        "cw_metric_name": "pod_memory_utilization",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "pod_network_rx_bytes": {
        "description": "Pod 네트워크 수신 바이트",
        "cw_metric_name": "pod_network_rx_bytes",
        "unit": "Bytes/Second",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
    "pod_network_tx_bytes": {
        "description": "Pod 네트워크 송신 바이트",
        "cw_metric_name": "pod_network_tx_bytes",
        "unit": "Bytes/Second",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
    "pod_container_restart_count": {
        "description": "컨테이너 재시작 횟수",
        "cw_metric_name": "pod_number_of_container_restarts",
        "unit": "Count",
        "statistic": "Maximum",
        "severity_threshold": {"HIGH": 3, "CRITICAL": 10},
    },
}


class EKSPodMetricsFetcher:
    """EKS Pod CloudWatch Container Insights 메트릭 조회기.

    Severity 결정 로직:
    - CPU, Memory, Restarts: 절대 임계값 기반
    - Network RX/TX: Z-score 기반 (|z| > 2.5 → HIGH, |z| > 3.0 → CRITICAL)
    """

    def __init__(
        self,
        cluster_name: str,
        namespaces: Optional[List[str]] = None,
        cloudwatch_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.cluster_name = cluster_name
        self.namespaces = namespaces  # None이면 discover_pods에서 시스템 NS 제외 전체
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._metric_cache = metric_cache

        # Configurable thresholds (환경변수로 오버라이드 가능)
        self._threshold_overrides = {
            "pod_cpu_utilization": {
                "HIGH": float(os.getenv("EKS_POD_CPU_THRESHOLD_HIGH", "80")),
                "CRITICAL": float(os.getenv("EKS_POD_CPU_THRESHOLD_CRITICAL", "90")),
            },
            "pod_memory_utilization": {
                "HIGH": float(os.getenv("EKS_POD_MEMORY_THRESHOLD_HIGH", "80")),
                "CRITICAL": float(os.getenv("EKS_POD_MEMORY_THRESHOLD_CRITICAL", "90")),
            },
        }
        # 오버라이드 로깅
        for name, th in self._threshold_overrides.items():
            default = EKS_POD_METRICS[name]["severity_threshold"]
            if th["HIGH"] != default["HIGH"] or th["CRITICAL"] != default["CRITICAL"]:
                logger.info(f"Threshold overridden for {name}: HIGH={th['HIGH']}, CRITICAL={th['CRITICAL']}")

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    def discover_pods(self) -> List[Dict[str, str]]:
        """CloudWatch list_metrics로 Pod 목록 조회.

        Returns:
            [{"PodName": "xxx", "Namespace": "yyy"}, ...]
        """
        pods = []
        seen = set()

        try:
            paginator = self.cloudwatch_client.get_paginator("list_metrics")
            for page in paginator.paginate(
                Namespace="ContainerInsights",
                MetricName="pod_cpu_utilization",
                Dimensions=[
                    {"Name": "ClusterName", "Value": self.cluster_name},
                ],
            ):
                for metric in page.get("Metrics", []):
                    dims = {d["Name"]: d["Value"] for d in metric.get("Dimensions", [])}
                    pod_name = dims.get("PodName")
                    namespace = dims.get("Namespace")

                    if not pod_name or not namespace:
                        continue

                    key = f"{namespace}/{pod_name}"
                    if key in seen:
                        continue
                    seen.add(key)

                    # Namespace 필터링
                    if self.namespaces:
                        if namespace not in self.namespaces:
                            continue
                    else:
                        if namespace in SYSTEM_NAMESPACES:
                            continue

                    pod_info = {"PodName": pod_name, "Namespace": namespace}
                    node_name = dims.get("NodeName")
                    if node_name:
                        pod_info["NodeName"] = node_name
                    pods.append(pod_info)

        except Exception as e:
            logger.error(f"Failed to discover pods for cluster {self.cluster_name}: {e}")

        return pods

    def list_pods(self) -> List[Dict[str, str]]:
        """Pod 목록 조회. mock이면 mock 데이터 반환."""
        if self.use_mock:
            return [
                {"PodName": "mock-app-pod-1", "Namespace": "default", "NodeName": "ip-10-0-1-100.compute.internal"},
                {"PodName": "mock-app-pod-2", "Namespace": "default", "NodeName": "ip-10-0-1-200.compute.internal"},
                {"PodName": "mock-worker-pod-1", "Namespace": "processing", "NodeName": "ip-10-0-2-100.compute.internal"},
            ]
        return self.discover_pods()

    def fetch_metrics(
        self,
        pod_name: str,
        namespace: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """개별 Pod의 5종 메트릭 조회.

        Args:
            pod_name: Pod 이름
            namespace: Kubernetes namespace
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        resource_id = f"{namespace}/{pod_name}"

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        if self.use_mock:
            return self._mock_metrics(pod_name, namespace)

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in EKS_POD_METRICS.items():
            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="ContainerInsights",
                    MetricName=metric_config["cw_metric_name"],
                    Dimensions=[
                        {"Name": "ClusterName", "Value": self.cluster_name},
                        {"Name": "Namespace", "Value": namespace},
                        {"Name": "PodName", "Value": pod_name},
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="eks-pod",
                    resource_id=resource_id,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(
                    f"Failed to fetch EKS Pod metric {metric_name} "
                    f"for {resource_id}: {e}"
                )

        return results

    def detect_drift(
        self,
        pod_name: str,
        namespace: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        절대 임계값 (CPU/Memory/Restarts) + Z-score (Network RX/TX).

        Args:
            pod_name: Pod 이름
            namespace: Kubernetes namespace
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        resource_id = f"{namespace}/{pod_name}"
        metrics = self.fetch_metrics(pod_name, namespace)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = EKS_POD_METRICS.get(metric_name, {})

            # 절대 임계값 기반 체크 (인스턴스 오버라이드 우선)
            thresholds = self._threshold_overrides.get(metric_name) or metric_config.get("severity_threshold")
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="eks-pod",
                        resource_id=resource_id,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                        data_points=result.data_points,
                    ))

            # ECOD 앙상블 탐지 (임계값 없는 메트릭)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="eks-pod",
                    resource_id=resource_id,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drift.data_points = result.data_points
                    drifts.append(drift)

        return drifts

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "pod_cpu_utilization": "Pod CPU 사용률이 높습니다. 리소스 request/limit 조정 또는 HPA 설정을 검토하세요.",
            "pod_memory_utilization": "Pod 메모리 사용률이 높습니다. 메모리 limit 증가 또는 메모리 누수를 점검하세요.",
            "pod_network_rx_bytes": "Pod 네트워크 수신량에 이상 변동이 있습니다. 트래픽 패턴을 확인하세요.",
            "pod_network_tx_bytes": "Pod 네트워크 송신량에 이상 변동이 있습니다. 트래픽 패턴을 확인하세요.",
            "pod_container_restart_count": "컨테이너 재시작이 감지되었습니다. Pod 로그 및 이벤트를 확인하세요.",
        }
        return recommendations.get(metric_name, "EKS Pod 메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def _mock_metrics(self, pod_name: str, namespace: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환.

        mock-app-pod-2: CPU HIGH (노드 과부하 시나리오)
        mock-worker-pod-1: Memory HIGH (Pod 단독 이상 시나리오)
        """
        now = datetime.now(KST)
        start = now - timedelta(hours=1)
        resource_id = f"{namespace}/{pod_name}"

        # Pod별 차별화된 mock 데이터
        mock_profiles = {
            "mock-app-pod-1": {
                "pod_cpu_utilization": {"avg": 35.0, "min": 20.0, "max": 55.0, "latest": 40.0},
                "pod_memory_utilization": {"avg": 50.0, "min": 40.0, "max": 65.0, "latest": 52.0},
                "pod_network_rx_bytes": {"avg": 50000.0, "min": 30000.0, "max": 80000.0, "latest": 55000.0},
                "pod_network_tx_bytes": {"avg": 30000.0, "min": 15000.0, "max": 50000.0, "latest": 32000.0},
                "pod_container_restart_count": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            },
            "mock-app-pod-2": {  # CPU HIGH - on node-2 which is also HIGH
                "pod_cpu_utilization": {"avg": 88.0, "min": 75.0, "max": 95.0, "latest": 92.0},
                "pod_memory_utilization": {"avg": 60.0, "min": 50.0, "max": 70.0, "latest": 65.0},
                "pod_network_rx_bytes": {"avg": 60000.0, "min": 40000.0, "max": 90000.0, "latest": 65000.0},
                "pod_network_tx_bytes": {"avg": 35000.0, "min": 20000.0, "max": 55000.0, "latest": 38000.0},
                "pod_container_restart_count": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            },
            "mock-worker-pod-1": {  # Memory HIGH - on normal node-3
                "pod_cpu_utilization": {"avg": 30.0, "min": 20.0, "max": 45.0, "latest": 35.0},
                "pod_memory_utilization": {"avg": 82.0, "min": 70.0, "max": 92.0, "latest": 88.0},
                "pod_network_rx_bytes": {"avg": 40000.0, "min": 25000.0, "max": 60000.0, "latest": 42000.0},
                "pod_network_tx_bytes": {"avg": 25000.0, "min": 10000.0, "max": 40000.0, "latest": 28000.0},
                "pod_container_restart_count": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            },
        }

        mock_data = mock_profiles.get(pod_name, {
            "pod_cpu_utilization": {"avg": 35.0, "min": 20.0, "max": 55.0, "latest": 40.0},
            "pod_memory_utilization": {"avg": 50.0, "min": 40.0, "max": 65.0, "latest": 52.0},
            "pod_network_rx_bytes": {"avg": 50000.0, "min": 30000.0, "max": 80000.0, "latest": 55000.0},
            "pod_network_tx_bytes": {"avg": 30000.0, "min": 15000.0, "max": 50000.0, "latest": 32000.0},
            "pod_container_restart_count": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
        })

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = EKS_POD_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="eks-pod",
                resource_id=resource_id,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
