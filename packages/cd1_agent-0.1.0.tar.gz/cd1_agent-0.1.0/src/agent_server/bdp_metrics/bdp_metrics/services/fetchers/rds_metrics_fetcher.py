"""
RDS Metrics Fetcher.

CloudWatch 기반 RDS 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# RDS CloudWatch 메트릭 정의
RDS_METRICS = {
    "CPUUtilization": {
        "description": "RDS 인스턴스 CPU 사용률",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 70, "CRITICAL": 85},
    },
    "FreeStorageSpace": {
        "description": "사용 가능한 스토리지 공간",
        "unit": "Bytes",
        "statistic": "Average",
        "inverted": True,
        "severity_threshold": {"HIGH": 20, "CRITICAL": 10},
    },
    "FreeableMemory": {
        "description": "사용 가능한 메모리",
        "unit": "Bytes",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
    "DatabaseConnections": {
        "description": "현재 데이터베이스 연결 수",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
}


class RDSMetricsFetcher:
    """RDS CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - CPUUtilization: 절대 임계값 기반 (70% HIGH, 85% CRITICAL)
    - FreeStorageSpace: 반전 임계값 기반 (잔여 비율 < 20% HIGH, < 10% CRITICAL)
    - FreeableMemory: Z-score 기반 (|z| > 2.5 → HIGH, |z| > 3.0 → CRITICAL)
    - DatabaseConnections: Z-score 기반 (|z| > 2.5 → HIGH, |z| > 3.0 → CRITICAL)
    """

    def __init__(
        self,
        cloudwatch_client=None,
        rds_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._rds_client = rds_client
        self._metric_cache = metric_cache

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def rds_client(self):
        if self._rds_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._rds_client = get_boto3_client("rds", config=config)
        return self._rds_client

    def fetch_metrics(
        self,
        db_instance_id: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """RDS 인스턴스의 모든 주요 메트릭 조회.

        Args:
            db_instance_id: RDS DB 인스턴스 식별자
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(db_instance_id)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in RDS_METRICS.items():
            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="AWS/RDS",
                    MetricName=metric_name,
                    Dimensions=[
                        {"Name": "DBInstanceIdentifier", "Value": db_instance_id},
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }

                    # FreeStorageSpace: 잔여 비율(%) 계산하여 statistics에 추가
                    if metric_name == "FreeStorageSpace":
                        allocated_gb = self._get_allocated_storage(db_instance_id)
                        if allocated_gb:
                            allocated_bytes = allocated_gb * (1024 ** 3)
                            statistics["free_pct"] = (statistics["latest"] / allocated_bytes) * 100
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="rds",
                    resource_id=db_instance_id,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch RDS metric {metric_name} for {db_instance_id}: {e}")

        return results

    def detect_drift(
        self,
        db_instance_id: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            db_instance_id: RDS DB 인스턴스 식별자
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(db_instance_id)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = RDS_METRICS.get(metric_name, {})

            thresholds = metric_config.get("severity_threshold")
            is_inverted = metric_config.get("inverted", False)

            # 반전 임계값 기반 체크 (FreeStorageSpace)
            if thresholds and is_inverted:
                # FreeStorageSpace: AllocatedStorage 대비 잔여 비율로 판단
                free_pct = result.statistics.get("free_pct")
                if free_pct is None:
                    allocated_gb = self._get_allocated_storage(db_instance_id)
                    if allocated_gb:
                        allocated_bytes = allocated_gb * (1024 ** 3)
                        free_pct = (current_value / allocated_bytes) * 100

                if free_pct is not None:
                    severity = None
                    if free_pct < thresholds["CRITICAL"]:
                        severity = DriftSeverity.CRITICAL
                    elif free_pct < thresholds["HIGH"]:
                        severity = DriftSeverity.HIGH

                    if severity:
                        drifts.append(MetricDrift(
                            metric_type="rds",
                            resource_id=db_instance_id,
                            metric_name=metric_name,
                            current_value=current_value,
                            baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                            baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                            z_score=0,
                            severity=severity,
                            threshold_type="inverted_percentage",
                            threshold_value=thresholds[severity.value.upper()],
                            description=f"{metric_config.get('description', metric_name)}: 잔여 {free_pct:.1f}%",
                            recommendation=self._get_recommendation(metric_name, severity),
                            detected_at=now,
                        ))

            # 절대 임계값 기반 체크 (CPUUtilization)
            elif thresholds and not is_inverted:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="rds",
                        resource_id=db_instance_id,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                    ))

            # ECOD 앙상블 탐지 (FreeableMemory, DatabaseConnections)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="rds",
                    resource_id=db_instance_id,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drifts.append(drift)

        return drifts

    def _get_allocated_storage(self, db_instance_id: str) -> Optional[int]:
        """AllocatedStorage (GB) 조회.

        Args:
            db_instance_id: RDS DB 인스턴스 식별자

        Returns:
            할당된 스토리지 크기 (GB), 조회 실패 시 None
        """
        if self.use_mock:
            return 100

        try:
            response = self.rds_client.describe_db_instances(
                DBInstanceIdentifier=db_instance_id
            )
            instances = response.get("DBInstances", [])
            if instances:
                return instances[0].get("AllocatedStorage")
        except Exception as e:
            logger.error(f"Failed to get AllocatedStorage for {db_instance_id}: {e}")
        return None

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "CPUUtilization": "CPU 사용률이 높습니다. 인스턴스 클래스 스케일업 또는 쿼리 최적화를 검토하세요.",
            "FreeStorageSpace": "스토리지 잔여 공간이 부족합니다. 볼륨 확장 또는 불필요한 데이터 정리를 검토하세요.",
            "FreeableMemory": "가용 메모리에 이상 변동이 있습니다. 인스턴스 클래스 스케일업 또는 메모리 사용 패턴을 확인하세요.",
            "DatabaseConnections": "데이터베이스 연결 수에 이상 변동이 있습니다. 커넥션 풀 설정 및 애플리케이션 상태를 확인하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def list_instances(self) -> List[str]:
        """RDS DB 인스턴스 목록 조회."""
        if self.use_mock:
            return ["mock-rds-instance-1", "mock-rds-instance-2"]

        instances = []
        try:
            paginator = self.rds_client.get_paginator("describe_db_instances")
            for page in paginator.paginate():
                for inst in page.get("DBInstances", []):
                    instances.append(inst["DBInstanceIdentifier"])
        except Exception as e:
            logger.error(f"Failed to list RDS instances: {e}")

        return instances

    def _mock_metrics(self, db_instance_id: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        # AllocatedStorage 100GB 기준 mock 데이터
        allocated_bytes = 100 * (1024 ** 3)  # 100 GB

        mock_data = {
            "CPUUtilization": {"avg": 35.0, "min": 20.0, "max": 55.0, "latest": 38.0},
            "FreeStorageSpace": {
                "avg": allocated_bytes * 0.55,
                "min": allocated_bytes * 0.50,
                "max": allocated_bytes * 0.60,
                "latest": allocated_bytes * 0.52,
                "free_pct": 52.0,
            },
            "FreeableMemory": {
                "avg": 4.0 * (1024 ** 3),
                "min": 3.5 * (1024 ** 3),
                "max": 4.5 * (1024 ** 3),
                "latest": 3.8 * (1024 ** 3),
            },
            "DatabaseConnections": {"avg": 45.0, "min": 20.0, "max": 80.0, "latest": 50.0},
        }

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = RDS_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="rds",
                resource_id=db_instance_id,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
