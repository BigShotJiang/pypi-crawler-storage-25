"""
Metrics Report Store - DB storage layer for metric reports.

메트릭 리포트 저장소.
Provider 패턴으로 MySQL/SQLite/Mock 지원.
"""

import json
import logging
import os
import sqlite3
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_common.stores.base import KST, get_kst_now, BaseMySqlProvider, BaseSQLiteProvider

from .models import MetricsReport

logger = logging.getLogger(__name__)


class MetricsReportStoreProvider(ABC):
    """메트릭 리포트 저장소 추상 프로바이더."""

    @abstractmethod
    def ensure_tables(self) -> None:
        """테이블 생성 확인."""
        pass

    @abstractmethod
    def save_report(self, report: MetricsReport) -> MetricsReport:
        """리포트 저장."""
        pass

    @abstractmethod
    def get_report(self, report_id: str) -> Optional[MetricsReport]:
        """리포트 조회."""
        pass

    @abstractmethod
    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[MetricsReport]:
        """리포트 목록 조회."""
        pass

    @abstractmethod
    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        """리포트 수 조회."""
        pass


class SQLiteProvider(BaseSQLiteProvider, MetricsReportStoreProvider):
    """SQLite 프로바이더 (유닛 테스트용)."""

    def ensure_tables(self) -> None:
        """테이블 생성."""
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_reports (
                id TEXT PRIMARY KEY,
                run_timestamp TEXT NOT NULL,
                resource_types TEXT NOT NULL,
                total_drifts INTEGER NOT NULL,
                by_severity TEXT NOT NULL,
                html_report TEXT NOT NULL,
                raw_drifts_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'completed',
                created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            )
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_reports_timestamp
            ON metrics_reports (run_timestamp)
        """)

        self.conn.commit()

    def save_report(self, report: MetricsReport) -> MetricsReport:
        """리포트 저장."""
        cursor = self.conn.cursor()
        now = get_kst_now().isoformat() + "Z"

        cursor.execute(
            """
            INSERT INTO metrics_reports
            (id, run_timestamp, resource_types, total_drifts, by_severity,
             html_report, raw_drifts_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                report.id,
                report.run_timestamp.isoformat() if isinstance(report.run_timestamp, datetime) else report.run_timestamp,
                json.dumps(report.resource_types, ensure_ascii=False),
                report.total_drifts,
                json.dumps(report.by_severity, ensure_ascii=False),
                report.html_report,
                report.raw_drifts_json,
                report.status,
                now,
            ),
        )

        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[MetricsReport]:
        """리포트 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM metrics_reports WHERE id = ?",
            (report_id,),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[MetricsReport]:
        """리포트 목록 조회."""
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)

        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        if resource_type:
            conditions.append('resource_types LIKE ?')
            params.append(f'%"{resource_type}"%')

        if severity:
            # SQLite: JSON에서 해당 severity 키의 값이 0보다 큰지 확인
            conditions.append(f"json_extract(by_severity, '$.{severity}') > 0")

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM metrics_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])

        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        """리포트 수 조회."""
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)

        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM metrics_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: sqlite3.Row) -> MetricsReport:
        """Row를 MetricsReport로 변환."""
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))

        return MetricsReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            resource_types=json.loads(row["resource_types"]),
            total_drifts=row["total_drifts"],
            by_severity=json.loads(row["by_severity"]),
            html_report=row["html_report"],
            raw_drifts_json=row["raw_drifts_json"],
            status=row["status"],
        )


class MySqlProvider(BaseMySqlProvider, MetricsReportStoreProvider):
    """MySQL 메트릭 리포트 저장소 (Secrets Manager 연동)."""

    def ensure_tables(self) -> None:
        """테이블 생성."""
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_reports (
                id VARCHAR(36) PRIMARY KEY,
                run_timestamp DATETIME NOT NULL,
                resource_types JSON NOT NULL,
                total_drifts INT NOT NULL,
                by_severity JSON NOT NULL,
                html_report LONGTEXT NOT NULL,
                raw_drifts_json LONGTEXT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'completed',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_reports_timestamp (run_timestamp)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)

        self.conn.commit()
        logger.info("MySQL metrics_reports table ensured")

    def save_report(self, report: MetricsReport) -> MetricsReport:
        """리포트 저장."""
        cursor = self.conn.cursor()
        now = get_kst_now()

        cursor.execute(
            """
            INSERT INTO metrics_reports
            (id, run_timestamp, resource_types, total_drifts, by_severity,
             html_report, raw_drifts_json, status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                report.id,
                report.run_timestamp if isinstance(report.run_timestamp, datetime) else datetime.fromisoformat(report.run_timestamp),
                json.dumps(report.resource_types, ensure_ascii=False),
                report.total_drifts,
                json.dumps(report.by_severity, ensure_ascii=False),
                report.html_report,
                report.raw_drifts_json,
                report.status,
                now,
            ),
        )

        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[MetricsReport]:
        """리포트 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM metrics_reports WHERE id = %s",
            (report_id,),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[MetricsReport]:
        """리포트 목록 조회."""
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)

        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        if resource_type:
            conditions.append("JSON_CONTAINS(resource_types, %s)")
            params.append(json.dumps(resource_type))

        if severity:
            # MySQL: JSON에서 해당 severity 키의 값이 0보다 큰지 확인
            conditions.append(f"JSON_EXTRACT(by_severity, '$.{severity}') > 0")

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM metrics_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT %s OFFSET %s
        """
        params.extend([limit, offset])

        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        """리포트 수 조회."""
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)

        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM metrics_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: Dict[str, Any]) -> MetricsReport:
        """Row (dict)를 MetricsReport로 변환."""
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))

        resource_types = row["resource_types"]
        if isinstance(resource_types, str):
            resource_types = json.loads(resource_types)

        by_severity = row["by_severity"]
        if isinstance(by_severity, str):
            by_severity = json.loads(by_severity)

        return MetricsReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            resource_types=resource_types,
            total_drifts=row["total_drifts"],
            by_severity=by_severity,
            html_report=row["html_report"],
            raw_drifts_json=row["raw_drifts_json"],
            status=row["status"],
        )


class MockProvider(MetricsReportStoreProvider):
    """Mock 프로바이더 (개발/테스트용)."""

    def __init__(self):
        """Mock 프로바이더 초기화."""
        self._reports: Dict[str, MetricsReport] = {}
        logger.info("Mock report provider initialized")

    def ensure_tables(self) -> None:
        """테이블 생성 (Mock은 no-op)."""
        pass

    def save_report(self, report: MetricsReport) -> MetricsReport:
        """리포트 저장."""
        self._reports[report.id] = report
        return report

    def get_report(self, report_id: str) -> Optional[MetricsReport]:
        """리포트 조회."""
        return self._reports.get(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[MetricsReport]:
        """리포트 목록 조회."""
        reports = list(self._reports.values())

        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [
                r for r in reports
                if r.run_timestamp >= start_dt
            ]

        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [
                r for r in reports
                if r.run_timestamp <= end_dt
            ]

        if resource_type:
            reports = [
                r for r in reports
                if resource_type in r.resource_types
            ]

        if severity:
            reports = [
                r for r in reports
                if r.by_severity.get(severity, 0) > 0
            ]

        # run_timestamp DESC 정렬
        reports.sort(key=lambda r: r.run_timestamp, reverse=True)

        return reports[offset:offset + limit]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        """리포트 수 조회."""
        reports = list(self._reports.values())

        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]

        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]

        return len(reports)


class MetricsReportStore:
    """
    메트릭 리포트 저장소 (Facade).

    Provider 패턴으로 MySQL/SQLite/Mock 지원.

    Usage:
        store = MetricsReportStore(provider="sqlite")
        store.ensure_tables()
        report = store.save_report(...)
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
    ):
        """MetricsReportStore 초기화.

        Args:
            provider: 프로바이더 타입 ("mysql", "sqlite", "mock")
            secret_id: MySQL 사용 시 Secrets Manager Secret ID
            db: MySQL 사용 시 데이터베이스 이름
        """
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)
        logger.info(f"MetricsReportStore initialized with {provider} provider")

    def _create_provider(
        self, provider: str, secret_id: Optional[str] = None, db: Optional[str] = None
    ) -> MetricsReportStoreProvider:
        """프로바이더 생성."""
        if provider == "sqlite":
            db_path = os.getenv("REPORT_SQLITE_PATH", ":memory:")
            return SQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                raise ValueError("secret_id is required for MySQL provider")
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return MySqlProvider(secret_id=secret_id, db=db or "", region=region)
        else:
            return MockProvider()

    def ensure_tables(self) -> None:
        """테이블 생성 확인."""
        self._provider.ensure_tables()

    def save_report(self, report: MetricsReport) -> MetricsReport:
        """리포트 저장."""
        return self._provider.save_report(report)

    def get_report(self, report_id: str) -> Optional[MetricsReport]:
        """리포트 조회."""
        return self._provider.get_report(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        resource_type: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[MetricsReport]:
        """리포트 목록 조회."""
        return self._provider.list_reports(
            start_date=start_date,
            end_date=end_date,
            resource_type=resource_type,
            severity=severity,
            limit=limit,
            offset=offset,
        )

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        """리포트 수 조회."""
        return self._provider.get_report_count(
            start_date=start_date,
            end_date=end_date,
        )
