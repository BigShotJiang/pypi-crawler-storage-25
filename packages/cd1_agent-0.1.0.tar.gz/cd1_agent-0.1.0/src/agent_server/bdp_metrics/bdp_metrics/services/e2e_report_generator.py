"""
E2E Report Generator for BDP Metrics Agent.

서버 사이드 렌더링 단일 HTML 리포트 생성.
메트릭 드리프트 시나리오 테스트 결과를 시각화합니다.
"""

import html as html_mod
import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from src.common.timezone import KST

logger = logging.getLogger(__name__)


# ─── Data Models ─────────────────────────────────────────────────────────────


@dataclass
class MetricsE2ETestResult:
    """개별 시나리오 테스트 결과."""

    scenario_id: int
    scenario_name: str
    scenario_name_ko: str
    description_ko: str
    group_id: str
    group_name: str
    expected_severity: str
    expected_has_drift: bool
    expected_drift_count: int
    actual_severity: str
    actual_has_drift: bool
    actual_drift_count: int
    actual_drifts: list[dict[str, Any]] = field(default_factory=list)
    passed: bool = True
    pass_reason: str = ""
    execution_time_ms: float = 0
    kakao_preview: dict[str, str] = field(default_factory=dict)
    summary_text: str = ""


@dataclass
class MetricsE2EGroupResult:
    """그룹별 테스트 결과."""

    group_id: str
    group_name: str
    group_name_ko: str
    emoji: str
    total: int
    passed: int
    failed: int
    pass_rate: float
    results: list[MetricsE2ETestResult] = field(default_factory=list)


@dataclass
class MetricsE2EReportData:
    """전체 E2E 리포트 데이터."""

    total: int
    passed: int
    failed: int
    pass_rate: float
    avg_latency_ms: float
    groups: list[MetricsE2EGroupResult] = field(default_factory=list)
    all_results: list[MetricsE2ETestResult] = field(default_factory=list)


# ─── Report Generator ────────────────────────────────────────────────────────


class MetricsE2EReportGenerator:
    """메트릭 E2E 리포트 생성기."""

    TITLE = "BDP Metrics Agent - E2E 시나리오 테스트 리포트"

    def generate_report(self, data: MetricsE2EReportData, output_path: str) -> str:
        """HTML 리포트 파일 생성."""
        from datetime import datetime
        from pathlib import Path

        content = self._generate_content(data)
        timestamp = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{self.TITLE}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>{self._get_css()}</style>
</head>
<body>
<div class="header"><div class="container">
<h1><span class="ms ms-lg" style="color:#fff">monitoring</span> {self.TITLE}</h1>
<p class="subtitle">보고서 생성: {timestamp}</p>
</div></div>
<div class="container">{content}</div>
<script>{self._get_js()}</script>
</body></html>"""

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        return output_path

    # ── Content ──────────────────────────────────────────────────

    def _generate_content(self, data: MetricsE2EReportData) -> str:
        parts = [
            self._render_summary(data),
            self._render_severity_dist(data),
            self._render_metric_type_dist(data),
            self._render_group_breakdown(data),
            self._render_filter_bar(data),
            self._render_test_cards(data),
        ]
        return "\n".join(parts)

    def _render_summary(self, data: MetricsE2EReportData) -> str:
        pc = (
            "#388E3C"
            if data.pass_rate >= 85
            else ("#F57C00" if data.pass_rate >= 70 else "#D32F2F")
        )
        total_drifts = sum(r.actual_drift_count for r in data.all_results)
        stats = [
            ("전체 시나리오", str(data.total), "#1976D2"),
            ("통과", str(data.passed), "#388E3C"),
            ("실패", str(data.failed), "#D32F2F"),
            ("통과율", f"{data.pass_rate:.0f}%", pc),
            ("총 드리프트", str(total_drifts), "#FF6F00"),
        ]
        cards = "".join(
            f'<div class="card stat-card"><div class="stat-value" style="color:{c}">{v}</div>'
            f'<div class="stat-label">{l}</div></div>'
            for l, v, c in stats
        )
        return f'<div class="grid grid-5">{cards}</div>'

    def _render_severity_dist(self, data: MetricsE2EReportData) -> str:
        dist = Counter(r.expected_severity for r in data.all_results)
        cfg = {
            "critical": ("#D32F2F", "#FFEBEE", "#B71C1C"),
            "high": ("#F57C00", "#FFF3E0", "#E65100"),
            "medium": ("#1976D2", "#E3F2FD", "#1565C0"),
            "low": ("#BDBDBD", "#F5F5F5", "#757575"),
        }
        cards = ""
        for sev in ["critical", "high", "medium", "low"]:
            color, bg, text = cfg[sev]
            n = dist.get(sev, 0)
            cards += (
                f'<div class="sev-card" style="background:{bg};border-left-color:{color}">'
                f'<div class="val" style="color:{color}">{n}</div>'
                f'<div class="lbl" style="color:{text}">{sev.upper()}</div></div>'
            )
        return self._card(
            '<span class="ms ms-sm ms-inline">bar_chart</span> 기대 심각도 분포',
            f'<div class="sev-grid">{cards}</div>',
        )

    def _render_metric_type_dist(self, data: MetricsE2EReportData) -> str:
        """메트릭 타입 분포."""
        type_counts = Counter()
        for r in data.all_results:
            for d in r.actual_drifts:
                type_counts[d.get("metric_type", "unknown")] += 1
        if not type_counts:
            return ""
        TYPE_KO = {
            "msk": "MSK",
            "eks-pod": "EKS Pod",
            "eks-node": "EKS Node",
            "rds": "RDS",
            "mwaa": "MWAA",
            "sagemaker-endpoint": "SageMaker",
            "emr-cluster": "EMR Cluster",
            "emr-serverless": "EMR Serverless",
            "subnet-ip": "Subnet IP",
            "service-quota": "Service Quota",
        }
        tags = "".join(
            f'<span class="pat-tag">{TYPE_KO.get(mt, mt)}: {n}</span>'
            for mt, n in type_counts.most_common()
        )
        return self._card(
            '<span class="ms ms-sm ms-inline">category</span> 메트릭 타입 분포',
            f'<div class="pat-dist">{tags}</div>',
        )

    def _render_group_breakdown(self, data: MetricsE2EReportData) -> str:
        if not data.groups:
            return ""
        rows = ""
        for g in data.groups:
            pct = g.pass_rate
            bar_color = "#388E3C" if pct >= 85 else ("#F57C00" if pct >= 70 else "#D32F2F")
            rows += f"""<div class="gb-row">
            <div class="gb-label">{g.emoji} {html_mod.escape(g.group_name_ko)}</div>
            <div class="gb-bar-wrap">
                <div class="gb-bar" style="width:{pct:.0f}%;background:{bar_color}"></div>
            </div>
            <div class="gb-stat">{g.passed}/{g.total} ({pct:.0f}%)</div></div>"""
        return self._card(
            '<span class="ms ms-sm ms-inline">stacked_bar_chart</span> 그룹별 통과율',
            rows,
        )

    def _render_filter_bar(self, data: MetricsE2EReportData) -> str:
        return f"""<div class="fbar">
        <button class="fbtn active" data-filter="all">
            <span class="ms ms-xs ms-inline">list</span> 전체 ({data.total})</button>
        <button class="fbtn" data-filter="pass">
            <span class="ms ms-xs ms-inline">check_circle</span> 통과 ({data.passed})</button>
        <button class="fbtn" data-filter="fail">
            <span class="ms ms-xs ms-inline">error</span> 실패 ({data.failed})</button>
        <span class="actions"><a onclick="toggleAll(true)">모두 펼치기</a> | <a onclick="toggleAll(false)">모두 접기</a></span>
        </div>"""

    def _render_test_cards(self, data: MetricsE2EReportData) -> str:
        return "\n".join(self._render_one_card(r) for r in data.all_results)

    def _render_one_card(self, r: MetricsE2ETestResult) -> str:
        cls = "pass" if r.passed else "fail"
        icon = "check_circle" if r.passed else "error"
        color = "#388E3C" if r.passed else "#D32F2F"
        sev_badge = self._severity_badge(r.expected_severity)

        # Drift detail rows
        drift_rows = ""
        for d in r.actual_drifts:
            drift_rows += f"""<div class="drift-item" style="border-left:3px solid {self._sev_color(d.get("severity", "low"))};padding:8px 12px;margin:4px 0;background:#FAFAFA;border-radius:4px">
            <div style="display:flex;justify-content:space-between;align-items:center">
                <strong>{html_mod.escape(d.get("metric_name", ""))}</strong>
                {self._severity_badge(d.get("severity", "low"))}
            </div>
            <div style="font-size:12px;color:#757575;margin-top:4px">
                {html_mod.escape(d.get("metric_type", ""))} / {html_mod.escape(d.get("resource_id", ""))}
            </div>
            <div style="font-size:12px;margin-top:4px">
                현재: <strong>{d.get("current_value", 0):.1f}</strong>
                | 기준: {d.get("baseline_avg", 0):.1f} ± {d.get("baseline_stddev", 0):.1f}
                | Z-score: <strong>{d.get("z_score", 0):.2f}</strong>
                | 임계: {d.get("threshold_type", "")} {d.get("threshold_value", 0):.1f}
            </div>
            <div style="font-size:12px;color:#424242;margin-top:2px">{html_mod.escape(d.get("description", ""))}</div>
            </div>"""

        return f"""<div class="tc {cls}">
        <div class="tc-hdr">
            <div class="tc-status"><span class="ms ms-sm ms-filled" style="color:{color}">{icon}</span></div>
            <div class="tc-id">#{r.scenario_id}</div>
            <div class="tc-name">{html_mod.escape(r.scenario_name_ko)}</div>
            <div class="tc-meta">{sev_badge}
                <span class="tc-chev"><span class="ms ms-sm">expand_more</span></span>
            </div>
        </div>
        <div class="tc-body">
            <div class="dgrid">
                <div class="dsec">
                    <h4 class="dsec-title"><span class="ms ms-xs ms-inline">target</span>기대값</h4>
                    <div class="drow"><span class="dlbl">심각도</span><span class="dval">{sev_badge}</span></div>
                    <div class="drow"><span class="dlbl">드리프트</span><span class="dval">{"있음" if r.expected_has_drift else "없음"}</span></div>
                    <div class="drow"><span class="dlbl">드리프트 수</span><span class="dval">≥ {r.expected_drift_count}</span></div>
                    <div class="drow"><span class="dlbl">설명</span><span class="dval" style="max-width:250px;text-align:right">{html_mod.escape(r.description_ko)}</span></div>
                </div>
                <div class="dsec">
                    <h4 class="dsec-title"><span class="ms ms-xs ms-inline">analytics</span>실제 결과</h4>
                    <div class="drow"><span class="dlbl">심각도</span><span class="dval">{self._severity_badge(r.actual_severity)}</span></div>
                    <div class="drow"><span class="dlbl">드리프트</span><span class="dval">{"있음" if r.actual_has_drift else "없음"}</span></div>
                    <div class="drow"><span class="dlbl">드리프트 수</span><span class="dval">{r.actual_drift_count}</span></div>
                    <div class="drow"><span class="dlbl">실행시간</span><span class="dval">{r.execution_time_ms:.1f}ms</span></div>
                    <div class="drow"><span class="dlbl">판정</span><span class="dval" style="font-size:12px">{html_mod.escape(r.pass_reason)}</span></div>
                </div>
            </div>
            {f'<div style="margin-top:12px"><h4 class="dsec-title"><span class="ms ms-xs ms-inline">show_chart</span>드리프트 상세</h4>{drift_rows}</div>' if drift_rows else ""}
            {self._render_kakao_preview(r)}
        </div></div>"""

    # ── Preview Renderers ────────────────────────────────────────

    def _render_kakao_preview(self, r: MetricsE2ETestResult) -> str:
        """카카오톡 알림 미리보기 (bdp_cost 포맷)."""
        kp = r.kakao_preview
        if not kp:
            return ""

        title = html_mod.escape(kp.get("title", ""))
        message = html_mod.escape(kp.get("message", ""))
        msg_html = message.replace("\n", "<br>")

        return f"""
        <div class="kakao-section">
            <h4><span class="ms ms-xs ms-inline">chat</span> 카카오톡 알림 미리보기</h4>
            <div class="kakao-preview">
                <div class="kakao-bubble">
                    <div class="kakao-title">{title}</div>
                    <div class="kakao-divider"></div>
                    <div class="kakao-content">{msg_html}</div>
                </div>
            </div>
        </div>"""

    # ── Helpers ───────────────────────────────────────────────────

    def _card(self, title: str, content: str) -> str:
        return f'<div class="card"><div class="card-header"><span class="card-title">{title}</span></div>{content}</div>'

    def _severity_badge(self, sev: str) -> str:
        icons = {"critical": "error", "high": "warning", "medium": "info", "low": "check_circle"}
        fill = " ms-filled" if sev in ("critical", "high") else ""
        return (
            f'<span class="badge badge-{sev}">'
            f'<span class="ms ms-sm{fill}">{icons.get(sev, "info")}</span> '
            f"{sev.upper()}</span>"
        )

    def _sev_color(self, sev: str) -> str:
        return {
            "critical": "#D32F2F",
            "high": "#F57C00",
            "medium": "#1976D2",
            "low": "#BDBDBD",
        }.get(sev, "#757575")

    # ── CSS ───────────────────────────────────────────────────────

    def _get_css(self) -> str:
        return """
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Pretendard',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F5F5F5;color:#212121;line-height:1.6}
.container{max-width:1200px;margin:0 auto;padding:20px}
.ms{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-feature-settings:'liga';-webkit-font-smoothing:antialiased;vertical-align:middle}
.ms-xs{font-size:14px}.ms-sm{font-size:18px}.ms-md{font-size:24px}.ms-lg{font-size:32px}
.ms-filled{font-variation-settings:'FILL' 1}
.ms-inline{vertical-align:-0.125em;margin-right:4px}
.header{background:linear-gradient(135deg,#1B5E20 0%,#2E7D32 50%,#388E3C 100%);color:#fff;padding:32px 0}
.header .container{display:flex;flex-direction:column;align-items:center}
.header h1{font-size:28px;color:#fff;display:flex;align-items:center;gap:8px}
.header .subtitle{color:rgba(255,255,255,.8);margin-top:4px;font-size:14px}
.card{background:#FFF;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;padding:20px}
.card-header{border-bottom:1px solid #E0E0E0;padding-bottom:12px;margin-bottom:16px}
.card-title{font-size:18px;font-weight:600}
.grid{display:grid;gap:20px}.grid-5{grid-template-columns:repeat(5,1fr)}
.stat-card{text-align:center;padding:20px}
.stat-value{font-size:32px;font-weight:700}
.stat-label{font-size:14px;color:#757575;margin-top:4px}
.badge{display:inline-flex;align-items:center;gap:2px;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:500}
.badge-critical{background:#FFEBEE;color:#B71C1C;border:1px solid #D32F2F}
.badge-high{background:#FFF3E0;color:#E65100;border:1px solid #F57C00}
.badge-medium{background:#E3F2FD;color:#1565C0;border:1px solid #1976D2}
.badge-low{background:#F5F5F5;color:#757575;border:1px solid #BDBDBD}
.sev-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px}
.sev-card{text-align:center;padding:16px;border-radius:8px;border-left:4px solid}
.sev-card .val{font-size:28px;font-weight:700}
.sev-card .lbl{font-size:12px;margin-top:4px;font-weight:500}
.pat-dist{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.pat-tag{padding:4px 12px;border-radius:16px;font-size:12px;font-weight:500;background:#E8F5E9;color:#1B5E20}
.gb-row{display:flex;align-items:center;gap:12px;padding:8px 0}
.gb-label{min-width:200px;font-size:14px;font-weight:500}
.gb-bar-wrap{flex:1;height:20px;background:#F5F5F5;border-radius:10px;overflow:hidden}
.gb-bar{height:100%;border-radius:10px;transition:width .3s}
.gb-stat{min-width:100px;text-align:right;font-size:13px;color:#757575}
.fbar{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center}
.fbtn{padding:6px 16px;border:1px solid #BDBDBD;border-radius:20px;background:#FFF;cursor:pointer;font-size:13px;transition:all .2s;display:inline-flex;align-items:center;gap:4px}
.fbtn:hover{background:#F5F5F5}
.fbtn.active{background:#2E7D32;color:#fff;border-color:#2E7D32}
.fbar .actions{margin-left:auto;font-size:13px;color:#757575}
.fbar .actions a{cursor:pointer;text-decoration:underline;color:#757575}
.tc{background:#FFF;border:1px solid #E0E0E0;border-radius:8px;margin-bottom:8px;overflow:hidden;transition:box-shadow .2s}
.tc:hover{box-shadow:0 2px 8px rgba(0,0,0,.1)}
.tc.pass{border-left:4px solid #388E3C}
.tc.fail{border-left:4px solid #D32F2F}
.tc-hdr{display:flex;align-items:center;padding:12px 16px;cursor:pointer;user-select:none;gap:12px}
.tc-hdr:hover{background:#F5F5F5}
.tc-status{flex-shrink:0}.tc-id{font-weight:600;font-size:13px;color:#757575;min-width:40px}
.tc-name{flex:1;font-weight:500;font-size:14px}
.tc-meta{display:flex;gap:8px;align-items:center;flex-shrink:0}
.tc-chev{transition:transform .2s;color:#757575}
.tc.expanded .tc-chev{transform:rotate(180deg)}
.tc-body{display:none;padding:0 16px 16px;border-top:1px solid #E0E0E0}
.tc.expanded .tc-body{display:block}
.dgrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px}
.dsec{background:#F5F5F5;border-radius:8px;padding:12px}
.dsec-title{font-size:13px;color:#757575;margin-bottom:8px;letter-spacing:.3px;display:flex;align-items:center;gap:4px}
.drow{display:flex;justify-content:space-between;padding:4px 0;font-size:13px}
.dlbl{color:#757575}.dval{font-weight:500}
/* Kakao Talk Preview (cost 포맷) */
.kakao-section{padding:16px;background:#F5F5F5;border-top:1px solid #E0E0E0;margin-top:12px;border-radius:0 0 8px 8px}
.kakao-section h4{font-size:13px;color:#757575;margin-bottom:12px}
.kakao-preview{display:flex;justify-content:center}
.kakao-bubble{background:#FEE500;border-radius:15px;padding:15px;max-width:350px;width:100%;box-shadow:0 2px 8px rgba(0,0,0,0.12)}
.kakao-title{font-weight:bold;font-size:14px;color:#3c1e1e;margin-bottom:8px}
.kakao-divider{height:1px;background:rgba(60,30,30,0.2);margin:8px 0}
.kakao-content{font-size:13px;color:#3c1e1e;line-height:1.5;white-space:pre-wrap}
@media(max-width:768px){.grid-5{grid-template-columns:repeat(2,1fr)}.sev-grid{grid-template-columns:repeat(2,1fr)}.dgrid{grid-template-columns:1fr}}
"""

    def _get_js(self) -> str:
        return """
document.addEventListener('click',function(e){
  var hdr=e.target.closest('.tc-hdr');
  if(hdr){hdr.closest('.tc').classList.toggle('expanded');return;}
  var btn=e.target.closest('.fbtn');
  if(btn){
    btn.closest('.fbar').querySelectorAll('.fbtn').forEach(function(b){b.classList.remove('active')});
    btn.classList.add('active');
    var f=btn.dataset.filter;
    document.querySelectorAll('.tc').forEach(function(c){
      c.style.display=f==='all'?'':(f==='pass'?(c.classList.contains('pass')?'':'none'):(c.classList.contains('fail')?'':'none'));
    });
  }
});
function toggleAll(expand){
  document.querySelectorAll('.tc').forEach(function(c){if(expand)c.classList.add('expanded');else c.classList.remove('expanded');});
}
"""
