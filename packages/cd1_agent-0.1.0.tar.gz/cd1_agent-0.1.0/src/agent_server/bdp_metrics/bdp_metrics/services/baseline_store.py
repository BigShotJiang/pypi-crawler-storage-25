"""
Metrics Baseline Store - DB storage layer for metric baselines.

메트릭 베이스라인 저장소.
Provider 패턴으로 MySQL/SQLite/Mock 지원.
모든 변경 사항은 자동으로 history 테이블에 기록됨.
"""

import json
import logging
import os
import sqlite3
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_common.stores.base import KST, get_kst_now, BaseMySqlProvider, BaseSQLiteProvider

from .models import (
    MetricBaseline,
    MetricBaselineHistory,
    ChangeType,
)

logger = logging.getLogger(__name__)


from typing import Tuple


class MetricsBaselineStoreProvider(ABC):
    """메트릭 베이스라인 저장소 추상 프로바이더."""

    @abstractmethod
    def ensure_tables(self) -> None:
        """테이블 생성 확인."""
        pass

    @abstractmethod
    def get_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> Optional[MetricBaseline]:
        """베이스라인 조회."""
        pass

    @abstractmethod
    def save_baseline(
        self,
        baseline: MetricBaseline,
        saved_by: str = "system",
        reason: Optional[str] = None,
    ) -> MetricBaseline:
        """베이스라인 저장 (생성 또는 업데이트)."""
        pass

    @abstractmethod
    def delete_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> bool:
        """베이스라인 삭제."""
        pass

    @abstractmethod
    def list_baselines(
        self,
        metric_type: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> List[MetricBaseline]:
        """베이스라인 목록 조회."""
        pass

    @abstractmethod
    def get_baseline_history(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> List[MetricBaselineHistory]:
        """베이스라인 변경 이력 조회."""
        pass

    @abstractmethod
    def save_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        values: List[float],
        timestamps: List[str],
    ) -> bool:
        """ECOD 앙상블 탐지용 raw historical data 저장."""
        pass

    @abstractmethod
    def get_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
    ) -> Optional[Tuple[List[float], List[str]]]:
        """ECOD 앙상블 탐지용 raw historical data 조회."""
        pass


class SQLiteProvider(BaseSQLiteProvider, MetricsBaselineStoreProvider):
    """SQLite 프로바이더 (유닛 테스트용)."""

    def ensure_tables(self) -> None:
        """테이블 생성."""
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_baselines (
                metric_type TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                baseline_avg REAL NOT NULL,
                baseline_stddev REAL NOT NULL,
                baseline_min REAL,
                baseline_max REAL,
                sample_count INTEGER NOT NULL,
                period_hours INTEGER DEFAULT 168,
                version INTEGER DEFAULT 1,
                created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                updated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                PRIMARY KEY (metric_type, resource_id, metric_name)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_baseline_history (
                id TEXT PRIMARY KEY,
                metric_type TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                version INTEGER NOT NULL,
                change_type TEXT NOT NULL,
                previous_baseline TEXT,
                current_baseline TEXT NOT NULL,
                change_reason TEXT,
                changed_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                changed_by TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_historical_data (
                metric_type TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                values_json TEXT NOT NULL,
                timestamps_json TEXT NOT NULL,
                updated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                PRIMARY KEY (metric_type, resource_id, metric_name)
            )
        """)

        # 인덱스 생성
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_history_resource
            ON metrics_baseline_history (metric_type, resource_id, metric_name)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_history_changed_at
            ON metrics_baseline_history (changed_at)
        """)

        self.conn.commit()

    def get_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> Optional[MetricBaseline]:
        """베이스라인 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM metrics_baselines
            WHERE metric_type = ? AND resource_id = ? AND metric_name = ?
            """,
            (metric_type, resource_id, metric_name),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        return self._row_to_baseline(row)

    def save_baseline(
        self,
        baseline: MetricBaseline,
        saved_by: str = "system",
        reason: Optional[str] = None,
    ) -> MetricBaseline:
        """베이스라인 저장 (생성 또는 업데이트)."""
        existing = self.get_baseline(
            baseline.metric_type, baseline.resource_id, baseline.metric_name
        )
        now = get_kst_now().isoformat() + "Z"
        cursor = self.conn.cursor()

        if existing is None:
            # 신규 생성
            baseline.version = 1
            baseline.created_at = datetime.fromisoformat(now.rstrip("Z"))
            baseline.updated_at = baseline.created_at

            cursor.execute(
                """
                INSERT INTO metrics_baselines
                (metric_type, resource_id, metric_name, baseline_avg, baseline_stddev,
                 baseline_min, baseline_max, sample_count, period_hours, version,
                 created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    baseline.baseline_avg,
                    baseline.baseline_stddev,
                    baseline.baseline_min,
                    baseline.baseline_max,
                    baseline.sample_count,
                    baseline.period_hours,
                    baseline.version,
                    now,
                    now,
                ),
            )

            # 히스토리 기록
            history_id = str(uuid.uuid4())
            cursor.execute(
                """
                INSERT INTO metrics_baseline_history
                (id, metric_type, resource_id, metric_name, version, change_type,
                 previous_baseline, current_baseline, change_reason, changed_by, changed_at)
                VALUES (?, ?, ?, ?, 1, 'CREATE', NULL, ?, ?, ?, ?)
                """,
                (
                    history_id,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    json.dumps(baseline.to_dict(), ensure_ascii=False),
                    reason or "Initial baseline creation",
                    saved_by,
                    now,
                ),
            )
        else:
            # 업데이트
            new_version = existing.version + 1
            baseline.version = new_version
            baseline.created_at = existing.created_at
            baseline.updated_at = datetime.fromisoformat(now.rstrip("Z"))

            cursor.execute(
                """
                UPDATE metrics_baselines
                SET baseline_avg = ?, baseline_stddev = ?, baseline_min = ?,
                    baseline_max = ?, sample_count = ?, period_hours = ?,
                    version = ?, updated_at = ?
                WHERE metric_type = ? AND resource_id = ? AND metric_name = ?
                """,
                (
                    baseline.baseline_avg,
                    baseline.baseline_stddev,
                    baseline.baseline_min,
                    baseline.baseline_max,
                    baseline.sample_count,
                    baseline.period_hours,
                    new_version,
                    now,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                ),
            )

            # 히스토리 기록
            history_id = str(uuid.uuid4())
            cursor.execute(
                """
                INSERT INTO metrics_baseline_history
                (id, metric_type, resource_id, metric_name, version, change_type,
                 previous_baseline, current_baseline, change_reason, changed_by, changed_at)
                VALUES (?, ?, ?, ?, ?, 'UPDATE', ?, ?, ?, ?, ?)
                """,
                (
                    history_id,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    new_version,
                    json.dumps(existing.to_dict(), ensure_ascii=False),
                    json.dumps(baseline.to_dict(), ensure_ascii=False),
                    reason,
                    saved_by,
                    now,
                ),
            )

        self.conn.commit()
        return baseline

    def delete_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> bool:
        """베이스라인 삭제."""
        current = self.get_baseline(metric_type, resource_id, metric_name)
        if current is None:
            return False

        cursor = self.conn.cursor()
        now = get_kst_now().isoformat() + "Z"

        # 히스토리 기록
        history_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO metrics_baseline_history
            (id, metric_type, resource_id, metric_name, version, change_type,
             previous_baseline, current_baseline, changed_by, changed_at)
            VALUES (?, ?, ?, ?, ?, 'DELETE', ?, '{"_deleted": true}', 'system', ?)
            """,
            (
                history_id,
                metric_type,
                resource_id,
                metric_name,
                current.version + 1,
                json.dumps(current.to_dict(), ensure_ascii=False),
                now,
            ),
        )

        # 베이스라인 삭제
        cursor.execute(
            """
            DELETE FROM metrics_baselines
            WHERE metric_type = ? AND resource_id = ? AND metric_name = ?
            """,
            (metric_type, resource_id, metric_name),
        )

        self.conn.commit()
        return True

    def list_baselines(
        self,
        metric_type: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> List[MetricBaseline]:
        """베이스라인 목록 조회."""
        cursor = self.conn.cursor()

        if metric_type and resource_id:
            cursor.execute(
                """
                SELECT * FROM metrics_baselines
                WHERE metric_type = ? AND resource_id = ?
                ORDER BY metric_name
                """,
                (metric_type, resource_id),
            )
        elif metric_type:
            cursor.execute(
                """
                SELECT * FROM metrics_baselines
                WHERE metric_type = ?
                ORDER BY resource_id, metric_name
                """,
                (metric_type,),
            )
        else:
            cursor.execute(
                "SELECT * FROM metrics_baselines ORDER BY metric_type, resource_id, metric_name"
            )

        return [self._row_to_baseline(row) for row in cursor.fetchall()]

    def get_baseline_history(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> List[MetricBaselineHistory]:
        """베이스라인 변경 이력 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM metrics_baseline_history
            WHERE metric_type = ? AND resource_id = ? AND metric_name = ?
            ORDER BY version DESC
            """,
            (metric_type, resource_id, metric_name),
        )

        return [self._row_to_history(row) for row in cursor.fetchall()]

    def save_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        values: List[float],
        timestamps: List[str],
    ) -> bool:
        """ECOD 앙상블 탐지용 raw historical data 저장."""
        try:
            cursor = self.conn.cursor()
            now = get_kst_now().isoformat() + "Z"
            cursor.execute(
                """
                INSERT OR REPLACE INTO metrics_historical_data
                (metric_type, resource_id, metric_name, values_json, timestamps_json, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    metric_type,
                    resource_id,
                    metric_name,
                    json.dumps(values),
                    json.dumps(timestamps),
                    now,
                ),
            )
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to save historical data: {e}")
            return False

    def get_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
    ) -> Optional[Tuple[List[float], List[str]]]:
        """ECOD 앙상블 탐지용 raw historical data 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT values_json, timestamps_json FROM metrics_historical_data
            WHERE metric_type = ? AND resource_id = ? AND metric_name = ?
            """,
            (metric_type, resource_id, metric_name),
        )
        row = cursor.fetchone()
        if row is None:
            return None
        return json.loads(row["values_json"]), json.loads(row["timestamps_json"])

    def _row_to_baseline(self, row: sqlite3.Row) -> MetricBaseline:
        """Row를 MetricBaseline으로 변환."""
        created_at = None
        if row["created_at"]:
            created_at = datetime.fromisoformat(row["created_at"].rstrip("Z"))

        updated_at = None
        if row["updated_at"]:
            updated_at = datetime.fromisoformat(row["updated_at"].rstrip("Z"))

        return MetricBaseline(
            metric_type=row["metric_type"],
            resource_id=row["resource_id"],
            metric_name=row["metric_name"],
            baseline_avg=row["baseline_avg"],
            baseline_stddev=row["baseline_stddev"],
            baseline_min=row["baseline_min"],
            baseline_max=row["baseline_max"],
            sample_count=row["sample_count"],
            period_hours=row["period_hours"],
            version=row["version"],
            created_at=created_at,
            updated_at=updated_at,
        )

    def _row_to_history(self, row: sqlite3.Row) -> MetricBaselineHistory:
        """Row를 MetricBaselineHistory로 변환."""
        changed_at = None
        if row["changed_at"]:
            changed_at = datetime.fromisoformat(row["changed_at"].rstrip("Z"))

        previous_baseline = None
        if row["previous_baseline"]:
            previous_baseline = json.loads(row["previous_baseline"])

        return MetricBaselineHistory(
            id=row["id"],
            metric_type=row["metric_type"],
            resource_id=row["resource_id"],
            metric_name=row["metric_name"],
            version=row["version"],
            change_type=row["change_type"],
            previous_baseline=previous_baseline,
            current_baseline=json.loads(row["current_baseline"]),
            change_reason=row["change_reason"],
            changed_at=changed_at,
            changed_by=row["changed_by"],
        )


class MySqlProvider(BaseMySqlProvider, MetricsBaselineStoreProvider):
    """MySQL 메트릭 베이스라인 저장소 (Secrets Manager 연동)."""

    def ensure_tables(self) -> None:
        """테이블 생성."""
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_baselines (
                metric_type VARCHAR(50) NOT NULL,
                resource_id VARCHAR(200) NOT NULL,
                metric_name VARCHAR(100) NOT NULL,
                baseline_avg DOUBLE NOT NULL,
                baseline_stddev DOUBLE NOT NULL,
                baseline_min DOUBLE,
                baseline_max DOUBLE,
                sample_count INT NOT NULL,
                period_hours INT DEFAULT 168,
                version INT DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (metric_type, resource_id, metric_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_baseline_history (
                id VARCHAR(36) PRIMARY KEY,
                metric_type VARCHAR(50) NOT NULL,
                resource_id VARCHAR(200) NOT NULL,
                metric_name VARCHAR(100) NOT NULL,
                version INT NOT NULL,
                change_type VARCHAR(20) NOT NULL,
                previous_baseline JSON,
                current_baseline JSON NOT NULL,
                change_reason TEXT,
                changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                changed_by VARCHAR(100) NOT NULL,
                INDEX idx_resource (metric_type, resource_id, metric_name),
                INDEX idx_changed_at (changed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics_historical_data (
                metric_type VARCHAR(50) NOT NULL,
                resource_id VARCHAR(200) NOT NULL,
                metric_name VARCHAR(100) NOT NULL,
                values_json JSON NOT NULL,
                timestamps_json JSON NOT NULL,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (metric_type, resource_id, metric_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)

        self.conn.commit()
        logger.info("MySQL tables ensured")

    def get_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> Optional[MetricBaseline]:
        """베이스라인 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM metrics_baselines
            WHERE metric_type = %s AND resource_id = %s AND metric_name = %s
            """,
            (metric_type, resource_id, metric_name),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        return self._row_to_baseline(row)

    def save_baseline(
        self,
        baseline: MetricBaseline,
        saved_by: str = "system",
        reason: Optional[str] = None,
    ) -> MetricBaseline:
        """베이스라인 저장 (생성 또는 업데이트)."""
        existing = self.get_baseline(
            baseline.metric_type, baseline.resource_id, baseline.metric_name
        )
        now = get_kst_now()
        cursor = self.conn.cursor()

        if existing is None:
            # 신규 생성
            baseline.version = 1
            baseline.created_at = now
            baseline.updated_at = now

            cursor.execute(
                """
                INSERT INTO metrics_baselines
                (metric_type, resource_id, metric_name, baseline_avg, baseline_stddev,
                 baseline_min, baseline_max, sample_count, period_hours, version,
                 created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    baseline.baseline_avg,
                    baseline.baseline_stddev,
                    baseline.baseline_min,
                    baseline.baseline_max,
                    baseline.sample_count,
                    baseline.period_hours,
                    baseline.version,
                    now,
                    now,
                ),
            )

            # 히스토리 기록
            history_id = str(uuid.uuid4())
            cursor.execute(
                """
                INSERT INTO metrics_baseline_history
                (id, metric_type, resource_id, metric_name, version, change_type,
                 previous_baseline, current_baseline, change_reason, changed_by, changed_at)
                VALUES (%s, %s, %s, %s, 1, 'CREATE', NULL, %s, %s, %s, %s)
                """,
                (
                    history_id,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    json.dumps(baseline.to_dict(), ensure_ascii=False),
                    reason or "Initial baseline creation",
                    saved_by,
                    now,
                ),
            )
        else:
            # 업데이트
            new_version = existing.version + 1
            baseline.version = new_version
            baseline.created_at = existing.created_at
            baseline.updated_at = now

            cursor.execute(
                """
                UPDATE metrics_baselines
                SET baseline_avg = %s, baseline_stddev = %s, baseline_min = %s,
                    baseline_max = %s, sample_count = %s, period_hours = %s,
                    version = %s, updated_at = %s
                WHERE metric_type = %s AND resource_id = %s AND metric_name = %s
                """,
                (
                    baseline.baseline_avg,
                    baseline.baseline_stddev,
                    baseline.baseline_min,
                    baseline.baseline_max,
                    baseline.sample_count,
                    baseline.period_hours,
                    new_version,
                    now,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                ),
            )

            # 히스토리 기록
            history_id = str(uuid.uuid4())
            cursor.execute(
                """
                INSERT INTO metrics_baseline_history
                (id, metric_type, resource_id, metric_name, version, change_type,
                 previous_baseline, current_baseline, change_reason, changed_by, changed_at)
                VALUES (%s, %s, %s, %s, %s, 'UPDATE', %s, %s, %s, %s, %s)
                """,
                (
                    history_id,
                    baseline.metric_type,
                    baseline.resource_id,
                    baseline.metric_name,
                    new_version,
                    json.dumps(existing.to_dict(), ensure_ascii=False),
                    json.dumps(baseline.to_dict(), ensure_ascii=False),
                    reason,
                    saved_by,
                    now,
                ),
            )

        self.conn.commit()
        return baseline

    def delete_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> bool:
        """베이스라인 삭제."""
        current = self.get_baseline(metric_type, resource_id, metric_name)
        if current is None:
            return False

        cursor = self.conn.cursor()
        now = get_kst_now()

        # 히스토리 기록
        history_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO metrics_baseline_history
            (id, metric_type, resource_id, metric_name, version, change_type,
             previous_baseline, current_baseline, changed_by, changed_at)
            VALUES (%s, %s, %s, %s, %s, 'DELETE', %s, '{"_deleted": true}', 'system', %s)
            """,
            (
                history_id,
                metric_type,
                resource_id,
                metric_name,
                current.version + 1,
                json.dumps(current.to_dict(), ensure_ascii=False),
                now,
            ),
        )

        # 베이스라인 삭제
        cursor.execute(
            """
            DELETE FROM metrics_baselines
            WHERE metric_type = %s AND resource_id = %s AND metric_name = %s
            """,
            (metric_type, resource_id, metric_name),
        )

        self.conn.commit()
        return True

    def list_baselines(
        self,
        metric_type: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> List[MetricBaseline]:
        """베이스라인 목록 조회."""
        cursor = self.conn.cursor()

        if metric_type and resource_id:
            cursor.execute(
                """
                SELECT * FROM metrics_baselines
                WHERE metric_type = %s AND resource_id = %s
                ORDER BY metric_name
                """,
                (metric_type, resource_id),
            )
        elif metric_type:
            cursor.execute(
                """
                SELECT * FROM metrics_baselines
                WHERE metric_type = %s
                ORDER BY resource_id, metric_name
                """,
                (metric_type,),
            )
        else:
            cursor.execute(
                "SELECT * FROM metrics_baselines ORDER BY metric_type, resource_id, metric_name"
            )

        return [self._row_to_baseline(row) for row in cursor.fetchall()]

    def get_baseline_history(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> List[MetricBaselineHistory]:
        """베이스라인 변경 이력 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM metrics_baseline_history
            WHERE metric_type = %s AND resource_id = %s AND metric_name = %s
            ORDER BY version DESC
            """,
            (metric_type, resource_id, metric_name),
        )

        return [self._row_to_history(row) for row in cursor.fetchall()]

    def save_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        values: List[float],
        timestamps: List[str],
    ) -> bool:
        """ECOD 앙상블 탐지용 raw historical data 저장."""
        try:
            cursor = self.conn.cursor()
            now = get_kst_now()
            cursor.execute(
                """
                INSERT INTO metrics_historical_data
                (metric_type, resource_id, metric_name, values_json, timestamps_json, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    values_json = VALUES(values_json),
                    timestamps_json = VALUES(timestamps_json),
                    updated_at = VALUES(updated_at)
                """,
                (
                    metric_type,
                    resource_id,
                    metric_name,
                    json.dumps(values),
                    json.dumps(timestamps),
                    now,
                ),
            )
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to save historical data: {e}")
            return False

    def get_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
    ) -> Optional[Tuple[List[float], List[str]]]:
        """ECOD 앙상블 탐지용 raw historical data 조회."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT values_json, timestamps_json FROM metrics_historical_data
            WHERE metric_type = %s AND resource_id = %s AND metric_name = %s
            """,
            (metric_type, resource_id, metric_name),
        )
        row = cursor.fetchone()
        if row is None:
            return None

        values_json = row["values_json"]
        timestamps_json = row["timestamps_json"]

        if isinstance(values_json, str):
            values_json = json.loads(values_json)
        if isinstance(timestamps_json, str):
            timestamps_json = json.loads(timestamps_json)

        return values_json, timestamps_json

    def _row_to_baseline(self, row: Dict[str, Any]) -> MetricBaseline:
        """Row (dict)를 MetricBaseline으로 변환."""
        created_at = row["created_at"]
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at.rstrip("Z"))

        updated_at = row["updated_at"]
        if isinstance(updated_at, str):
            updated_at = datetime.fromisoformat(updated_at.rstrip("Z"))

        return MetricBaseline(
            metric_type=row["metric_type"],
            resource_id=row["resource_id"],
            metric_name=row["metric_name"],
            baseline_avg=row["baseline_avg"],
            baseline_stddev=row["baseline_stddev"],
            baseline_min=row["baseline_min"],
            baseline_max=row["baseline_max"],
            sample_count=row["sample_count"],
            period_hours=row["period_hours"],
            version=row["version"],
            created_at=created_at,
            updated_at=updated_at,
        )

    def _row_to_history(self, row: Dict[str, Any]) -> MetricBaselineHistory:
        """Row (dict)를 MetricBaselineHistory로 변환."""
        changed_at = row["changed_at"]
        if isinstance(changed_at, str):
            changed_at = datetime.fromisoformat(changed_at.rstrip("Z"))

        previous_baseline = row["previous_baseline"]
        if previous_baseline and isinstance(previous_baseline, str):
            previous_baseline = json.loads(previous_baseline)

        current_baseline = row["current_baseline"]
        if isinstance(current_baseline, str):
            current_baseline = json.loads(current_baseline)

        return MetricBaselineHistory(
            id=row["id"],
            metric_type=row["metric_type"],
            resource_id=row["resource_id"],
            metric_name=row["metric_name"],
            version=row["version"],
            change_type=row["change_type"],
            previous_baseline=previous_baseline,
            current_baseline=current_baseline,
            change_reason=row["change_reason"],
            changed_at=changed_at,
            changed_by=row["changed_by"],
        )


class MockProvider(MetricsBaselineStoreProvider):
    """Mock 프로바이더 (개발/테스트용)."""

    def __init__(self):
        """Mock 프로바이더 초기화."""
        self._baselines: Dict[str, MetricBaseline] = {}
        self._history: List[MetricBaselineHistory] = []
        self._historical_data: Dict[str, Tuple[List[float], List[str]]] = {}
        logger.info("Mock provider initialized")

    def _key(self, metric_type: str, resource_id: str, metric_name: str) -> str:
        """복합 키 생성."""
        return f"{metric_type}:{resource_id}:{metric_name}"

    def ensure_tables(self) -> None:
        """테이블 생성 (Mock은 no-op)."""
        pass

    def get_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> Optional[MetricBaseline]:
        """베이스라인 조회."""
        return self._baselines.get(self._key(metric_type, resource_id, metric_name))

    def save_baseline(
        self,
        baseline: MetricBaseline,
        saved_by: str = "system",
        reason: Optional[str] = None,
    ) -> MetricBaseline:
        """베이스라인 저장 (생성 또는 업데이트)."""
        key = self._key(baseline.metric_type, baseline.resource_id, baseline.metric_name)
        existing = self._baselines.get(key)
        now = get_kst_now()

        if existing is None:
            # 신규 생성
            baseline.version = 1
            baseline.created_at = now
            baseline.updated_at = now

            self._history.append(
                MetricBaselineHistory(
                    id=str(uuid.uuid4()),
                    metric_type=baseline.metric_type,
                    resource_id=baseline.resource_id,
                    metric_name=baseline.metric_name,
                    version=1,
                    change_type=ChangeType.CREATE.value,
                    previous_baseline=None,
                    current_baseline=baseline.to_dict(),
                    change_reason=reason or "Initial baseline creation",
                    changed_at=now,
                    changed_by=saved_by,
                )
            )
        else:
            # 업데이트
            new_version = existing.version + 1
            baseline.version = new_version
            baseline.created_at = existing.created_at
            baseline.updated_at = now

            self._history.append(
                MetricBaselineHistory(
                    id=str(uuid.uuid4()),
                    metric_type=baseline.metric_type,
                    resource_id=baseline.resource_id,
                    metric_name=baseline.metric_name,
                    version=new_version,
                    change_type=ChangeType.UPDATE.value,
                    previous_baseline=existing.to_dict(),
                    current_baseline=baseline.to_dict(),
                    change_reason=reason,
                    changed_at=now,
                    changed_by=saved_by,
                )
            )

        self._baselines[key] = baseline
        return baseline

    def delete_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> bool:
        """베이스라인 삭제."""
        key = self._key(metric_type, resource_id, metric_name)
        if key not in self._baselines:
            return False

        current = self._baselines[key]
        now = get_kst_now()

        self._history.append(
            MetricBaselineHistory(
                id=str(uuid.uuid4()),
                metric_type=metric_type,
                resource_id=resource_id,
                metric_name=metric_name,
                version=current.version + 1,
                change_type=ChangeType.DELETE.value,
                previous_baseline=current.to_dict(),
                current_baseline={"_deleted": True},
                changed_at=now,
                changed_by="system",
            )
        )

        del self._baselines[key]
        return True

    def save_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        values: List[float],
        timestamps: List[str],
    ) -> bool:
        """ECOD 앙상블 탐지용 raw historical data 저장."""
        key = self._key(metric_type, resource_id, metric_name)
        self._historical_data[key] = (values, timestamps)
        return True

    def get_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
    ) -> Optional[Tuple[List[float], List[str]]]:
        """ECOD 앙상블 탐지용 raw historical data 조회."""
        key = self._key(metric_type, resource_id, metric_name)
        return self._historical_data.get(key)

    def list_baselines(
        self,
        metric_type: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> List[MetricBaseline]:
        """베이스라인 목록 조회."""
        baselines = list(self._baselines.values())
        if metric_type:
            baselines = [b for b in baselines if b.metric_type == metric_type]
        if resource_id:
            baselines = [b for b in baselines if b.resource_id == resource_id]
        return sorted(
            baselines,
            key=lambda b: (b.metric_type, b.resource_id, b.metric_name),
        )

    def get_baseline_history(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> List[MetricBaselineHistory]:
        """베이스라인 변경 이력 조회."""
        history = [
            h
            for h in self._history
            if h.metric_type == metric_type
            and h.resource_id == resource_id
            and h.metric_name == metric_name
        ]
        return sorted(history, key=lambda h: h.version, reverse=True)


class MetricsBaselineStore:
    """
    메트릭 베이스라인 저장소 (Facade).

    Provider 패턴으로 MySQL/SQLite/Mock 지원.

    Usage:
        store = MetricsBaselineStore(provider="sqlite")
        store.ensure_tables()
        baseline = store.save_baseline(...)
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
    ):
        """MetricsBaselineStore 초기화.

        Args:
            provider: 프로바이더 타입 ("mysql", "sqlite", "mock")
            secret_id: MySQL 사용 시 Secrets Manager Secret ID
            db: MySQL 사용 시 데이터베이스 이름
        """
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)
        logger.info(f"MetricsBaselineStore initialized with {provider} provider")

    def _create_provider(
        self, provider: str, secret_id: Optional[str] = None, db: Optional[str] = None
    ) -> MetricsBaselineStoreProvider:
        """프로바이더 생성."""
        if provider == "sqlite":
            db_path = os.getenv("BASELINE_SQLITE_PATH", ":memory:")
            return SQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                raise ValueError("secret_id is required for MySQL provider")
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return MySqlProvider(secret_id=secret_id, db=db or "", region=region)
        else:
            return MockProvider()

    def ensure_tables(self) -> None:
        """테이블 생성 확인."""
        self._provider.ensure_tables()

    def get_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> Optional[MetricBaseline]:
        """베이스라인 조회."""
        return self._provider.get_baseline(metric_type, resource_id, metric_name)

    def save_baseline(
        self,
        baseline: MetricBaseline,
        saved_by: str = "system",
        reason: Optional[str] = None,
    ) -> MetricBaseline:
        """베이스라인 저장 (생성 또는 업데이트)."""
        return self._provider.save_baseline(baseline, saved_by, reason)

    def delete_baseline(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> bool:
        """베이스라인 삭제."""
        return self._provider.delete_baseline(metric_type, resource_id, metric_name)

    def list_baselines(
        self,
        metric_type: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> List[MetricBaseline]:
        """베이스라인 목록 조회."""
        return self._provider.list_baselines(metric_type, resource_id)

    def get_baseline_history(
        self, metric_type: str, resource_id: str, metric_name: str
    ) -> List[MetricBaselineHistory]:
        """베이스라인 변경 이력 조회."""
        return self._provider.get_baseline_history(metric_type, resource_id, metric_name)

    def save_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        values: List[float],
        timestamps: List[str],
    ) -> bool:
        """ECOD 앙상블 탐지용 raw historical data 저장."""
        return self._provider.save_historical_data(
            metric_type, resource_id, metric_name, values, timestamps
        )

    def get_historical_data(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
    ) -> Optional[Tuple[List[float], List[str]]]:
        """ECOD 앙상블 탐지용 raw historical data 조회."""
        return self._provider.get_historical_data(metric_type, resource_id, metric_name)

    def get_baseline_at_version(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        version: int,
    ) -> Optional[MetricBaseline]:
        """특정 버전의 베이스라인 조회."""
        history = self.get_baseline_history(metric_type, resource_id, metric_name)
        for h in history:
            if h.version == version:
                data = h.current_baseline
                return MetricBaseline(
                    metric_type=data.get("metric_type", metric_type),
                    resource_id=data.get("resource_id", resource_id),
                    metric_name=data.get("metric_name", metric_name),
                    baseline_avg=data.get("baseline_avg", 0.0),
                    baseline_stddev=data.get("baseline_stddev", 0.0),
                    baseline_min=data.get("baseline_min"),
                    baseline_max=data.get("baseline_max"),
                    sample_count=data.get("sample_count", 0),
                    period_hours=data.get("period_hours", 168),
                    version=h.version,
                    updated_at=h.changed_at,
                )
        return None

    def rollback_to_version(
        self,
        metric_type: str,
        resource_id: str,
        metric_name: str,
        version: int,
        rolled_back_by: str,
    ) -> Optional[MetricBaseline]:
        """특정 버전으로 롤백."""
        target = self.get_baseline_at_version(
            metric_type, resource_id, metric_name, version
        )
        if target is None:
            return None

        return self.save_baseline(
            target,
            saved_by=rolled_back_by,
            reason=f"Rollback to version {version}",
        )
