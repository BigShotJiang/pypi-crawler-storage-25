"""
MWAA Metrics Fetcher.

CloudWatch 기반 MWAA 메트릭 조회 및 drift 감지.
2개 네임스페이스(AWS/MWAA, AmazonMWAA)에서 9개 메트릭 수집.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
    MWAA_METRICS,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class MWAAMetricsFetcher:
    """MWAA CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - CPU 계열 (Worker/Scheduler/WebServer/Database): 절대 임계값 기반
    - DatabaseConnections, QueuedTasks, DagProcessing: Z-score 기반 (baseline 필요)
    """

    def __init__(
        self,
        environment_name: str,
        use_mock: bool = False,
        cloudwatch_client=None,
        metric_cache=None,
    ):
        self.environment_name = environment_name
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._metric_cache = metric_cache
        self._dimension_cache: Optional[Dict[str, List[Dict[str, str]]]] = None

        # 환경변수 임계값 오버라이드
        self._threshold_overrides: Dict[str, Dict[str, float]] = {}
        self._load_threshold_overrides()

    @property
    def cloudwatch_client(self):
        """Lazy boto3 client."""
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    def _load_threshold_overrides(self):
        """환경변수에서 임계값 오버라이드 로드."""
        env_mappings = {
            "BaseWorkerCPU": "MWAA_BASE_WORKER_CPU",
            "AdditionalWorkerCPU": "MWAA_ADDITIONAL_WORKER_CPU",
            "SchedulerCPU": "MWAA_SCHEDULER_CPU",
            "WebServerCPU": "MWAA_WEBSERVER_CPU",
            "DatabaseCPU": "MWAA_DB_CPU",
        }
        for metric_key, env_prefix in env_mappings.items():
            high = os.getenv(f"{env_prefix}_THRESHOLD_HIGH")
            critical = os.getenv(f"{env_prefix}_THRESHOLD_CRITICAL")
            if high or critical:
                override = {}
                if high:
                    override["HIGH"] = float(high)
                if critical:
                    override["CRITICAL"] = float(critical)
                self._threshold_overrides[metric_key] = override

    def _get_threshold(self, metric_key: str) -> Optional[Dict[str, float]]:
        """메트릭별 임계값 반환 (오버라이드 우선)."""
        if metric_key in self._threshold_overrides:
            base = dict(MWAA_METRICS[metric_key].get("severity_threshold") or {})
            base.update(self._threshold_overrides[metric_key])
            return base
        return MWAA_METRICS[metric_key].get("severity_threshold")

    def _discover_dimensions(self) -> Dict[str, List[Dict[str, str]]]:
        """list_metrics로 MWAA 관련 dimension 자동 발견.

        모든 MWAA 메트릭은 Environment dimension을 기준으로 환경을 식별.
        추가 dimension (Cluster, DatabaseRole 등)은 메트릭별로 다름.

        Returns:
            {metric_key: [{Name, Value}, ...]} dimension 리스트 맵
        """
        if self._dimension_cache is not None:
            return self._dimension_cache

        cache: Dict[str, List[Dict[str, str]]] = {}

        for metric_key, mc in MWAA_METRICS.items():
            extra_dim_name = mc.get("extra_dimension_name")
            extra_dim_fixed = mc.get("extra_dimension_value")

            # AmazonMWAA: 고정 dimension value
            if extra_dim_fixed:
                dims = [{"Name": "Environment", "Value": self.environment_name}]
                if extra_dim_name:
                    dims.append({"Name": extra_dim_name, "Value": extra_dim_fixed})
                cache[metric_key] = dims
                continue

            # extra_dimension 없는 메트릭 (QueuedTasks 등): Environment만
            if not extra_dim_name:
                cache[metric_key] = [
                    {"Name": "Environment", "Value": self.environment_name},
                ]
                continue

            # list_metrics로 extra_dimension value 발견
            try:
                paginator = self.cloudwatch_client.get_paginator("list_metrics")
                found = False
                for page in paginator.paginate(
                    Namespace=mc["namespace"],
                    MetricName=mc["cw_metric_name"],
                ):
                    for metric in page.get("Metrics", []):
                        dims = {
                            d["Name"]: d["Value"]
                            for d in metric.get("Dimensions", [])
                        }
                        # Environment가 일치하는 메트릭만 대상
                        if dims.get("Environment") != self.environment_name:
                            continue
                        extra_val = dims.get(extra_dim_name)
                        if not extra_val:
                            continue
                        # component_keyword 매칭
                        keyword = mc.get("component_keyword")
                        if keyword and keyword not in extra_val:
                            continue
                        # 매칭 성공
                        cache[metric_key] = [
                            {"Name": "Environment", "Value": self.environment_name},
                            {"Name": extra_dim_name, "Value": extra_val},
                        ]
                        found = True
                        break
                    if found:
                        break

                if not found:
                    logger.warning(
                        f"[MWAA Dimension] No match for {metric_key}: "
                        f"env={self.environment_name}, "
                        f"extra_dim={extra_dim_name}, "
                        f"keyword={mc.get('component_keyword')}"
                    )
            except Exception as e:
                logger.error(f"Failed to discover dimensions for {metric_key}: {e}")

        self._dimension_cache = cache
        logger.info(f"MWAA dimensions discovered: {list(cache.keys())}")
        return cache

    def fetch_metrics(
        self,
        environment_name: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """MWAA 환경의 모든 주요 메트릭 조회.

        Args:
            environment_name: MWAA 환경 이름
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(environment_name)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results: Dict[str, MetricResult] = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        # Dimension 발견
        dim_map = self._discover_dimensions()

        for metric_key, mc in MWAA_METRICS.items():
            dimensions = dim_map.get(metric_key)
            if not dimensions:
                logger.warning(f"Dimension not found for MWAA metric {metric_key}, skipping")
                continue

            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace=mc["namespace"],
                    MetricName=mc["cw_metric_name"],
                    Dimensions=dimensions,
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[mc["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[mc["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_key] = MetricResult(
                    metric_type="mwaa",
                    resource_id=environment_name,
                    metric_name=metric_key,
                    data_points=data_points,
                    statistics=statistics,
                    unit=mc["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch MWAA metric {metric_key} for {environment_name}: {e}")

        return results

    def detect_drift(
        self,
        environment_name: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            environment_name: MWAA 환경 이름
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(environment_name)
        drifts: List[MetricDrift] = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = MWAA_METRICS.get(metric_name, {})

            # 절대 임계값 기반 체크
            thresholds = self._get_threshold(metric_name)
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="mwaa",
                        resource_id=environment_name,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                        data_points=result.data_points,
                    ))

            # ECOD 앙상블 탐지 (임계값 없는 메트릭)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="mwaa",
                    resource_id=environment_name,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drift.data_points = result.data_points
                    drifts.append(drift)

        return drifts

    def list_environments(self) -> List[str]:
        """MWAA 환경 목록 반환."""
        if self.use_mock:
            return ["mock-mwaa-env"]
        return [self.environment_name] if self.environment_name else []

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "BaseWorkerCPU": "BaseWorker CPU가 높습니다. Worker 수 증가 또는 태스크 부하 분산을 검토하세요.",
            "AdditionalWorkerCPU": "AdditionalWorker CPU가 높습니다. Auto-scaling 설정을 확인하세요.",
            "SchedulerCPU": "Scheduler CPU가 높습니다. DAG 복잡도 또는 파싱 주기를 조정하세요.",
            "WebServerCPU": "WebServer CPU가 높습니다. 동시 접속자 수를 확인하세요.",
            "DatabaseCPU": "Database CPU가 높습니다. 쿼리 최적화 또는 환경 스케일업을 검토하세요.",
            "DatabaseConnections": "Database 연결 수에 이상 변동이 있습니다. 연결 풀 설정을 확인하세요.",
            "QueuedTasks": "대기 태스크가 많습니다. Worker 수 또는 태스크 동시 실행 수를 조정하세요.",
            "DagProcessingFilePathQueueSize": "DAG 파싱 대기 파일이 많습니다. DAG 수 또는 파싱 주기를 조정하세요.",
            "DagProcessingTotalParseTime": "DAG 파싱 시간에 이상 변동이 있습니다. DAG 복잡도를 확인하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def _mock_metrics(self, environment_name: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        mock_data = {
            "BaseWorkerCPU":       {"avg": 55.0, "min": 40.0, "max": 70.0, "latest": 58.0},
            "AdditionalWorkerCPU": {"avg": 45.0, "min": 30.0, "max": 60.0, "latest": 48.0},
            "SchedulerCPU":        {"avg": 35.0, "min": 25.0, "max": 50.0, "latest": 38.0},
            "WebServerCPU":        {"avg": 25.0, "min": 15.0, "max": 40.0, "latest": 28.0},
            "DatabaseCPU":         {"avg": 30.0, "min": 20.0, "max": 45.0, "latest": 32.0},
            "DatabaseConnections": {"avg": 15.0, "min": 10.0, "max": 25.0, "latest": 18.0},
            "QueuedTasks":         {"avg": 5.0,  "min": 0.0,  "max": 15.0, "latest": 3.0},
            "DagProcessingFilePathQueueSize": {"avg": 2.0, "min": 0.0, "max": 8.0, "latest": 1.0},
            "DagProcessingTotalParseTime":    {"avg": 12.0, "min": 8.0, "max": 20.0, "latest": 14.0},
        }

        results: Dict[str, MetricResult] = {}
        for metric_name, stats in mock_data.items():
            mc = MWAA_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="mwaa",
                resource_id=environment_name,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=mc.get("unit")),
                ],
                statistics=stats,
                unit=mc.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
