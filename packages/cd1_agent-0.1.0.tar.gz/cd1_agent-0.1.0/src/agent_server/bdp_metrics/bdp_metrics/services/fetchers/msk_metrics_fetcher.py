"""
MSK Metrics Fetcher.

CloudWatch 기반 MSK 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# MSK CloudWatch 메트릭 정의
MSK_METRICS = {
    "CpuUser": {
        "description": "브로커 CPU 사용률 (User)",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 70, "CRITICAL": 85},
    },
    "CpuSystem": {
        "description": "브로커 CPU 사용률 (System)",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 30, "CRITICAL": 50},
    },
    "KafkaDataLogsDiskUsed": {
        "description": "Kafka 데이터 디스크 사용량",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 70, "CRITICAL": 80},
    },
    "MemoryUsed": {
        "description": "브로커 메모리 사용량",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 75, "CRITICAL": 85},
    },
    "OfflinePartitionsCount": {
        "description": "오프라인 파티션 수",
        "unit": "Count",
        "statistic": "Maximum",
        "severity_threshold": {"HIGH": 0, "CRITICAL": 0},  # 0보다 크면 위험
    },
    "UnderReplicatedPartitions": {
        "description": "복제 부족 파티션 수",
        "unit": "Count",
        "statistic": "Maximum",
        "severity_threshold": {"HIGH": 0, "CRITICAL": 5},
    },
    "GlobalPartitionCount": {
        "description": "전체 파티션 수",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,  # 임계값 없음, Z-score 기반
    },
    "MessagesInPerSec": {
        "description": "초당 메시지 인입 수",
        "unit": "Count/Second",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
}


class MSKMetricsFetcher:
    """MSK CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - CPU, Disk, Memory: 절대 임계값 기반
    - OfflinePartitions: > 0 이면 CRITICAL
    - MessagesInPerSec: Z-score 기반 (|z| > 2.5 → HIGH, |z| > 3.0 → CRITICAL)
    """

    def __init__(
        self,
        cloudwatch_client=None,
        kafka_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._kafka_client = kafka_client
        self._metric_cache = metric_cache

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def kafka_client(self):
        if self._kafka_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._kafka_client = get_boto3_client("kafka", config=config)
        return self._kafka_client

    def fetch_metrics(
        self,
        cluster_name: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """MSK 클러스터의 모든 주요 메트릭 조회.

        Args:
            cluster_name: MSK 클러스터 이름
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(cluster_name)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        # 클러스터 ARN 조회
        cluster_arn = self._get_cluster_arn(cluster_name)
        if not cluster_arn:
            logger.warning(f"MSK cluster not found: {cluster_name}")
            return results

        for metric_name, metric_config in MSK_METRICS.items():
            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="AWS/Kafka",
                    MetricName=metric_name,
                    Dimensions=[
                        {"Name": "Cluster Name", "Value": cluster_name},
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="msk",
                    resource_id=cluster_name,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch MSK metric {metric_name} for {cluster_name}: {e}")

        return results

    def detect_drift(
        self,
        cluster_name: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            cluster_name: MSK 클러스터 이름
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(cluster_name)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = MSK_METRICS.get(metric_name, {})

            # 절대 임계값 기반 체크
            thresholds = metric_config.get("severity_threshold")
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="msk",
                        resource_id=cluster_name,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                        data_points=result.data_points,
                    ))

            # ECOD 앙상블 탐지 (임계값 없는 메트릭)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="msk",
                    resource_id=cluster_name,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drift.data_points = result.data_points
                    drifts.append(drift)

        return drifts

    def _get_cluster_arn(self, cluster_name: str) -> Optional[str]:
        """클러스터 이름으로 ARN 조회."""
        try:
            response = self.kafka_client.list_clusters_v2()
            for cluster in response.get("ClusterInfoList", []):
                if cluster.get("ClusterName") == cluster_name:
                    return cluster.get("ClusterArn")
        except Exception as e:
            logger.error(f"Failed to get cluster ARN for {cluster_name}: {e}")
        return None

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "CpuUser": "CPU 사용률이 높습니다. 브로커 스케일업 또는 파티션 재분배를 검토하세요.",
            "CpuSystem": "System CPU가 높습니다. 디스크 I/O 또는 네트워크 문제를 확인하세요.",
            "KafkaDataLogsDiskUsed": "디스크 사용량이 높습니다. 데이터 보존 정책 조정 또는 볼륨 확장을 검토하세요.",
            "MemoryUsed": "메모리 사용량이 높습니다. 브로커 스케일업을 검토하세요.",
            "OfflinePartitionsCount": "오프라인 파티션이 있습니다. 즉시 브로커 상태를 확인하세요.",
            "UnderReplicatedPartitions": "복제 부족 파티션이 있습니다. 브로커 간 동기화 상태를 확인하세요.",
            "MessagesInPerSec": "메시지 처리량에 이상 변동이 있습니다. Producer/Consumer 상태를 확인하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def list_clusters(self) -> List[str]:
        """MSK 클러스터 목록 조회."""
        if self.use_mock:
            return ["mock-msk-cluster-1", "mock-msk-cluster-2"]

        clusters = []
        try:
            paginator = self.kafka_client.get_paginator("list_clusters_v2")
            for page in paginator.paginate():
                for cluster in page.get("ClusterInfoList", []):
                    clusters.append(cluster.get("ClusterName"))
        except Exception as e:
            logger.error(f"Failed to list MSK clusters: {e}")

        return clusters

    def _mock_metrics(self, cluster_name: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        mock_data = {
            "CpuUser": {"avg": 45.0, "min": 30.0, "max": 60.0, "latest": 48.0},
            "KafkaDataLogsDiskUsed": {"avg": 55.0, "min": 50.0, "max": 60.0, "latest": 58.0},
            "MemoryUsed": {"avg": 65.0, "min": 60.0, "max": 70.0, "latest": 67.0},
            "OfflinePartitionsCount": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            "UnderReplicatedPartitions": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            "MessagesInPerSec": {"avg": 1500.0, "min": 1000.0, "max": 2000.0, "latest": 1600.0},
        }

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = MSK_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="msk",
                resource_id=cluster_name,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
