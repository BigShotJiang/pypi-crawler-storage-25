"""
Daily Report Generator for BDP Metrics Agent.

일일 메트릭 드리프트 리포트를 단일 HTML 파일로 생성합니다.
QuickChart.io 차트 포함, Material Design 스타일.
"""

import html as html_mod
import json
import logging
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

from src.common.timezone import KST

logger = logging.getLogger(__name__)

SEVERITY_EMOJI = {
    "critical": "🔴",
    "high": "🟠",
    "medium": "🟡",
    "low": "🟢",
}

TYPE_KO = {
    "msk": "MSK",
    "eks-pod": "EKS Pod",
    "eks-node": "EKS Node",
    "rds": "RDS",
    "mwaa": "MWAA",
    "sagemaker-endpoint": "SageMaker",
    "emr-cluster": "EMR Cluster",
    "emr-serverless": "EMR Serverless",
    "subnet-ip": "Subnet IP",
    "service-quota": "Service Quota",
}

SEVERITY_COLORS = {
    "critical": "#D32F2F",
    "high": "#F57C00",
    "medium": "#1976D2",
    "low": "#BDBDBD",
}


# ─── Data Models ─────────────────────────────────────────────────────────────


@dataclass
class ServiceMetricSeries:
    """하나의 메트릭에 대한 24시간 시계열 데이터."""

    metric_name: str
    resource_id: str
    data_points: list[float]  # 24 hourly values
    baseline_avg: float
    baseline_stddev: float
    unit: str = ""
    has_drift: bool = False
    drift_severity: str = ""


@dataclass
class ServiceCategoryData:
    """AWS 서비스 카테고리별 메트릭 시계열 그룹."""

    service_key: str
    service_name: str
    service_icon: str  # Material Symbol name
    metrics: list[ServiceMetricSeries] = field(default_factory=list)
    resource_count: int = 0
    drift_count: int = 0


@dataclass
class DailyDriftItem:
    """일일 리포트 개별 드리프트 항목."""

    metric_type: str
    resource_id: str
    metric_name: str
    current_value: float
    baseline_avg: float
    baseline_stddev: float
    z_score: float
    severity: str
    threshold_type: str
    threshold_value: float
    description: str = ""
    resource_name: str | None = None


@dataclass
class MetricsDailyReportData:
    """일일 메트릭 리포트 데이터."""

    report_date: str
    account_name: str
    total_drifts: int
    severity_counts: dict[str, int] = field(default_factory=dict)
    type_counts: dict[str, int] = field(default_factory=dict)
    drifts: list[DailyDriftItem] = field(default_factory=list)
    service_categories: list[ServiceCategoryData] = field(default_factory=list)
    time_labels: list[str] = field(default_factory=list)


# ─── Report Generator ────────────────────────────────────────────────────────


class MetricsDailyReportGenerator:
    """메트릭 일일 리포트 생성기."""

    TITLE = "BDP Metrics Agent - 일일 메트릭 리포트"
    QUICKCHART_BASE = "https://quickchart.io/chart"

    def generate_report(self, data: MetricsDailyReportData, output_path: str) -> str:
        """HTML 리포트 파일 생성."""
        from datetime import datetime
        from pathlib import Path

        content = self._generate_content(data)
        timestamp = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{self.TITLE} - {data.report_date}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>{self._get_css()}</style>
</head>
<body>
<div class="header"><div class="container">
<h1><span class="ms ms-lg" style="color:#fff">monitoring</span> {self.TITLE}</h1>
<p class="subtitle">{data.account_name} | {data.report_date} | 보고서 생성: {timestamp}</p>
</div></div>
<div class="container">{content}</div>
</body></html>"""

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        return output_path

    # ── Content ──────────────────────────────────────────────────

    def _generate_content(self, data: MetricsDailyReportData) -> str:
        parts = [
            self._render_summary(data),
            self._render_service_timeseries(data),
            self._render_drift_alerts_header(),
            self._render_drift_table(data),
        ]
        return "\n".join(parts)

    def _render_summary(self, data: MetricsDailyReportData) -> str:
        highest = "low"
        sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        for sev, cnt in data.severity_counts.items():
            if cnt > 0 and sev_order.get(sev, 99) < sev_order.get(highest, 99):
                highest = sev
        hc = SEVERITY_COLORS.get(highest, "#757575")

        stats = [
            ("총 드리프트", str(data.total_drifts), hc),
            ("CRITICAL", str(data.severity_counts.get("critical", 0)), "#D32F2F"),
            ("HIGH", str(data.severity_counts.get("high", 0)), "#F57C00"),
            ("MEDIUM", str(data.severity_counts.get("medium", 0)), "#1976D2"),
            ("LOW", str(data.severity_counts.get("low", 0)), "#BDBDBD"),
        ]
        cards = "".join(
            f'<div class="card stat-card"><div class="stat-value" style="color:{c}">{v}</div>'
            f'<div class="stat-label">{l}</div></div>'
            for l, v, c in stats
        )
        return f'<div class="grid grid-5">{cards}</div>'

    def _render_service_timeseries(self, data: MetricsDailyReportData) -> str:
        """서비스 카테고리별 시계열 차트 섹션."""
        if not data.service_categories:
            return ""
        sections = []
        for cat in data.service_categories:
            sections.append(self._render_service_section(cat, data.time_labels))
        return "\n".join(sections)

    def _render_service_section(
        self,
        category: ServiceCategoryData,
        time_labels: list[str],
    ) -> str:
        """개별 서비스 카테고리 섹션: 헤더 + 라인 차트 + 메트릭 통계."""
        # Drift badge
        drift_badge = ""
        if category.drift_count > 0:
            drift_badge = (
                f'<span class="badge badge-critical" style="margin-left:8px">'
                f"⚠ {category.drift_count} drift</span>"
            )

        header = (
            f'<div class="service-header">'
            f'<div class="service-title">'
            f'<span class="ms ms-md ms-inline">{category.service_icon}</span> '
            f"{html_mod.escape(category.service_name)}"
            f"</div>"
            f'<div class="service-meta">'
            f"{category.resource_count} 리소스 · {len(category.metrics)} 메트릭"
            f"{drift_badge}"
            f"</div></div>"
        )

        # Build line chart
        chart_url = self._build_service_line_chart(category, time_labels)
        chart_html = (
            f'<div class="chart-container">'
            f'<img src="{chart_url}" alt="{category.service_name} 메트릭 추이" class="chart-img">'
            f"</div>"
        )

        # Metric stats row
        stats_rows = ""
        for m in category.metrics:
            drift_label = ""
            if m.has_drift:
                sev = m.drift_severity or "high"
                drift_label = f' <span class="badge badge-{sev}" style="font-size:11px;padding:2px 6px">DRIFT</span>'
            stats_rows += (
                f'<div class="metric-stat-row">'
                f'<span class="metric-stat-name">{html_mod.escape(m.metric_name)}{drift_label}</span>'
                f'<span class="metric-stat-value">avg {m.baseline_avg:.1f} ± {m.baseline_stddev:.1f}'
                f"{' ' + m.unit if m.unit else ''}</span>"
                f"</div>"
            )

        stats_html = f'<div class="metric-stats">{stats_rows}</div>'

        return f'<div class="card service-section">{header}{chart_html}{stats_html}</div>'

    def _build_service_line_chart(
        self,
        category: ServiceCategoryData,
        time_labels: list[str],
    ) -> str:
        """서비스 카테고리용 QuickChart 라인 차트 URL 생성."""
        # Line colors palette
        line_colors = [
            "rgb(211,47,47)",  # red
            "rgb(245,124,0)",  # orange
            "rgb(25,118,210)",  # blue
            "rgb(56,142,60)",  # green
            "rgb(123,31,162)",  # purple
            "rgb(0,151,167)",  # teal
            "rgb(255,179,0)",  # amber
            "rgb(121,85,72)",  # brown
        ]

        datasets = []
        for i, m in enumerate(category.metrics):
            color = line_colors[i % len(line_colors)]
            label = f"⚠ {m.metric_name}" if m.has_drift else m.metric_name
            datasets.append(
                {
                    "label": label,
                    "data": m.data_points,
                    "borderColor": color,
                    "backgroundColor": "transparent",
                    "borderWidth": 3 if m.has_drift else 1.5,
                    "pointRadius": 0,
                    "tension": 0.3,
                }
            )

        config = {
            "type": "line",
            "data": {
                "labels": time_labels,
                "datasets": datasets,
            },
            "options": {
                "responsive": False,
                "plugins": {
                    "legend": {
                        "position": "bottom",
                        "labels": {"font": {"size": 11}, "boxWidth": 12, "padding": 12},
                    },
                },
                "scales": {
                    "xAxes": [
                        {
                            "ticks": {"maxTicksLimit": 12, "font": {"size": 10}},
                            "gridLines": {"color": "rgba(0,0,0,0.05)"},
                        }
                    ],
                    "yAxes": [
                        {
                            "ticks": {"font": {"size": 10}},
                            "gridLines": {"color": "rgba(0,0,0,0.08)"},
                        }
                    ],
                },
            },
        }
        return self._quickchart_url(config, 800, 300)

    def _render_drift_alerts_header(self) -> str:
        """드리프트 알림 섹션 구분선."""
        return (
            '<div class="section-divider">'
            '<span class="ms ms-md ms-inline">notifications_active</span> '
            "드리프트 알림"
            "</div>"
        )

    def _render_drift_table(self, data: MetricsDailyReportData) -> str:
        """드리프트 상세 테이블 (심각도 순 정렬)."""
        if not data.drifts:
            return self._card(
                '<span class="ms ms-sm ms-inline">check_circle</span> 드리프트 상세',
                '<div style="text-align:center;padding:40px;color:#757575">탐지된 드리프트가 없습니다.</div>',
            )

        sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sorted_drifts = sorted(data.drifts, key=lambda d: sev_order.get(d.severity, 99))

        rows = ""
        for d in sorted_drifts:
            sev_color = SEVERITY_COLORS.get(d.severity, "#757575")
            emoji = SEVERITY_EMOJI.get(d.severity, "⚪")
            type_label = TYPE_KO.get(d.metric_type, d.metric_type)
            rows += f"""<tr>
                <td><span class="badge badge-{d.severity}">{emoji} {d.severity.upper()}</span></td>
                <td>{html_mod.escape(type_label)}</td>
                <td>{html_mod.escape(d.resource_id)}</td>
                <td>{html_mod.escape(d.metric_name)}</td>
                <td class="num"><strong>{d.current_value:.1f}</strong></td>
                <td class="num">{d.baseline_avg:.1f} ± {d.baseline_stddev:.1f}</td>
                <td class="num"><strong style="color:{sev_color}">{d.z_score:.2f}</strong></td>
                <td style="font-size:12px;max-width:200px">{html_mod.escape(d.description)}</td>
            </tr>"""

        table = f"""<div class="tbl-wrap"><table class="dtbl">
        <thead><tr>
            <th>심각도</th><th>서비스</th><th>리소스</th><th>메트릭</th>
            <th>현재값</th><th>기준값</th><th>Z-Score</th><th>설명</th>
        </tr></thead>
        <tbody>{rows}</tbody></table></div>"""

        return self._card(
            '<span class="ms ms-sm ms-inline">table_chart</span> 드리프트 상세',
            table,
        )

    # ── Chart Helpers ─────────────────────────────────────────────

    def _quickchart_url(self, config: dict[str, Any], w: int, h: int) -> str:
        chart_json = json.dumps(config, ensure_ascii=False)
        encoded = quote(chart_json)
        return f"{self.QUICKCHART_BASE}?c={encoded}&w={w}&h={h}&bkg=white"

    # ── Helpers ───────────────────────────────────────────────────

    def _card(self, title: str, content: str) -> str:
        return f'<div class="card"><div class="card-header"><span class="card-title">{title}</span></div>{content}</div>'

    # ── CSS ───────────────────────────────────────────────────────

    def _get_css(self) -> str:
        return """
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Pretendard',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F5F5F5;color:#212121;line-height:1.6}
.container{max-width:1200px;margin:0 auto;padding:20px}
.ms{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-feature-settings:'liga';-webkit-font-smoothing:antialiased;vertical-align:middle}
.ms-xs{font-size:14px}.ms-sm{font-size:18px}.ms-md{font-size:24px}.ms-lg{font-size:32px}
.ms-filled{font-variation-settings:'FILL' 1}
.ms-inline{vertical-align:-0.125em;margin-right:4px}
.header{background:linear-gradient(135deg,#1B5E20 0%,#2E7D32 50%,#388E3C 100%);color:#fff;padding:32px 0}
.header .container{display:flex;flex-direction:column;align-items:center}
.header h1{font-size:28px;color:#fff;display:flex;align-items:center;gap:8px}
.header .subtitle{color:rgba(255,255,255,.8);margin-top:4px;font-size:14px}
.card{background:#FFF;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;padding:20px}
.card-header{border-bottom:1px solid #E0E0E0;padding-bottom:12px;margin-bottom:16px}
.card-title{font-size:18px;font-weight:600}
.grid{display:grid;gap:20px}.grid-5{grid-template-columns:repeat(5,1fr)}
.stat-card{text-align:center;padding:20px}
.stat-value{font-size:32px;font-weight:700}
.stat-label{font-size:14px;color:#757575;margin-top:4px}
.badge{display:inline-flex;align-items:center;gap:2px;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:500}
.badge-critical{background:#FFEBEE;color:#B71C1C;border:1px solid #D32F2F}
.badge-high{background:#FFF3E0;color:#E65100;border:1px solid #F57C00}
.badge-medium{background:#E3F2FD;color:#1565C0;border:1px solid #1976D2}
.badge-low{background:#F5F5F5;color:#757575;border:1px solid #BDBDBD}
/* Service Sections */
.service-section{padding:24px}
.service-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #E0E0E0}
.service-title{font-size:20px;font-weight:600;display:flex;align-items:center;gap:6px}
.service-meta{font-size:13px;color:#757575;display:flex;align-items:center;gap:4px}
.chart-container{text-align:center;margin-bottom:16px}
.chart-img{max-width:100%;height:auto;border-radius:4px}
.metric-stats{display:flex;flex-wrap:wrap;gap:8px 24px;padding:12px 16px;background:#FAFAFA;border-radius:6px}
.metric-stat-row{display:flex;align-items:center;gap:8px;font-size:13px}
.metric-stat-name{font-weight:500;color:#424242}
.metric-stat-value{color:#757575;font-variant-numeric:tabular-nums}
/* Section Divider */
.section-divider{display:flex;align-items:center;gap:8px;font-size:20px;font-weight:600;color:#D32F2F;padding:24px 0 12px;border-top:2px solid #FFCDD2;margin-top:8px}
/* Drift Table */
.tbl-wrap{overflow-x:auto;margin-top:8px}
.dtbl{width:100%;border-collapse:collapse}
.dtbl th,.dtbl td{padding:10px 12px;text-align:left;border:1px solid #E0E0E0;font-size:13px}
.dtbl th{background:#F5F5F5;font-weight:600;white-space:nowrap}
.dtbl tr:hover{background:#FAFAFA}
.dtbl .num{text-align:right;font-variant-numeric:tabular-nums}
@media(max-width:768px){.grid-5{grid-template-columns:repeat(2,1fr)}.service-header{flex-direction:column;align-items:flex-start;gap:8px}.metric-stats{flex-direction:column}}
"""

    # ── DB 기반 HTML 재생성 ──────────────────────────────────────

    def generate_from_db(self, report) -> str:
        """DB에서 읽은 MetricsReport 객체의 raw_drifts_json으로 HTML 재생성.

        Args:
            report: MetricsReport (report_store.py의 dataclass)

        Returns:
            HTML 문자열
        """
        data = self.data_from_json(report)
        import os
        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w") as f:
            tmp_path = f.name
        try:
            self.generate_report(data, tmp_path)
            with open(tmp_path, encoding="utf-8") as f:
                return f.read()
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    @staticmethod
    def data_from_json(report) -> "MetricsDailyReportData":
        """MetricsReport의 raw_drifts_json → MetricsDailyReportData 복원."""
        if not report.raw_drifts_json:
            by_severity = report.by_severity
            if isinstance(by_severity, str):
                by_severity = json.loads(by_severity)
            return MetricsDailyReportData(
                report_date="",
                account_name="",
                total_drifts=report.total_drifts,
                severity_counts=by_severity,
            )

        raw = json.loads(report.raw_drifts_json)
        drifts = [
            DailyDriftItem(
                metric_type=d["metric_type"],
                resource_id=d["resource_id"],
                metric_name=d["metric_name"],
                current_value=d["current_value"],
                baseline_avg=d["baseline_avg"],
                baseline_stddev=d["baseline_stddev"],
                z_score=d["z_score"],
                severity=d["severity"],
                threshold_type=d.get("threshold_type", "z_score"),
                threshold_value=d.get("threshold_value", 0),
                description=d.get("description", ""),
                resource_name=d.get("resource_name"),
            )
            for d in raw.get("drifts", [])
        ]

        service_categories = []
        for cat_data in raw.get("service_categories", []):
            metrics = [
                ServiceMetricSeries(
                    metric_name=m["metric_name"],
                    resource_id=m["resource_id"],
                    data_points=m["data_points"],
                    baseline_avg=m["baseline_avg"],
                    baseline_stddev=m["baseline_stddev"],
                    unit=m.get("unit", ""),
                    has_drift=m.get("has_drift", False),
                    drift_severity=m.get("drift_severity", ""),
                )
                for m in cat_data.get("metrics", [])
            ]
            service_categories.append(
                ServiceCategoryData(
                    service_key=cat_data["service_key"],
                    service_name=cat_data["service_name"],
                    service_icon=cat_data.get("service_icon", "cloud"),
                    metrics=metrics,
                    resource_count=cat_data.get("resource_count", 0),
                    drift_count=cat_data.get("drift_count", 0),
                )
            )

        return MetricsDailyReportData(
            report_date=raw.get("report_date", ""),
            account_name=raw.get("account_name", ""),
            total_drifts=raw.get("total_drifts", len(drifts)),
            severity_counts=raw.get("severity_counts", {}),
            type_counts=raw.get("type_counts", {}),
            drifts=drifts,
            service_categories=service_categories,
            time_labels=raw.get("time_labels", []),
        )
