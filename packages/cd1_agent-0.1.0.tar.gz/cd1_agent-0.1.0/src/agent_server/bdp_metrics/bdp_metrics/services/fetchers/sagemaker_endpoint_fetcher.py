"""
SageMaker Endpoint Metrics Fetcher.

CloudWatch 기반 SageMaker Endpoint 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# SageMaker Endpoint CloudWatch 메트릭 정의
SAGEMAKER_ENDPOINT_METRICS = {
    "Invocations4XXErrors": {
        "description": "Endpoint 4XX 에러 수",
        "namespace": "AWS/SageMaker",
        "unit": "Count",
        "statistic": "Sum",
        "severity_threshold": {"HIGH": 1, "CRITICAL": 10},
    },
    "Invocations5XXErrors": {
        "description": "Endpoint 5XX 에러 수",
        "namespace": "AWS/SageMaker",
        "unit": "Count",
        "statistic": "Sum",
        "severity_threshold": {"HIGH": 1, "CRITICAL": 5},
    },
    "ModelLatency": {
        "description": "모델 추론 지연 시간",
        "namespace": "AWS/SageMaker",
        "unit": "Microseconds",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
    "CPUUtilization": {
        "description": "Endpoint CPU 사용률",
        "namespace": "/aws/sagemaker/Endpoints",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "MemoryUtilization": {
        "description": "Endpoint 메모리 사용률",
        "namespace": "/aws/sagemaker/Endpoints",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "GPUUtilization": {
        "description": "Endpoint GPU 사용률",
        "namespace": "/aws/sagemaker/Endpoints",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
}


class SageMakerEndpointFetcher:
    """SageMaker Endpoint CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - Invocations4XXErrors, Invocations5XXErrors: 절대 임계값 기반
    - ModelLatency: Z-score 기반 (|z| > 2.5 -> HIGH, |z| > 3.0 -> CRITICAL)
    - CPUUtilization, MemoryUtilization, GPUUtilization: 절대 임계값 기반
    """

    def __init__(
        self,
        cloudwatch_client=None,
        sagemaker_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._sagemaker_client = sagemaker_client
        self._metric_cache = metric_cache

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def sagemaker_client(self):
        if self._sagemaker_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._sagemaker_client = get_boto3_client("sagemaker", config=config)
        return self._sagemaker_client

    def list_endpoints(self) -> List[str]:
        """SageMaker Endpoint 목록 조회 (InService 상태만)."""
        if self.use_mock:
            return ["mock-endpoint-1", "mock-endpoint-2"]

        endpoints = []
        try:
            paginator = self.sagemaker_client.get_paginator("list_endpoints")
            for page in paginator.paginate(StatusEquals="InService"):
                for ep in page.get("Endpoints", []):
                    endpoints.append(ep.get("EndpointName"))
        except Exception as e:
            logger.error(f"Failed to list SageMaker endpoints: {e}")

        return endpoints

    def fetch_metrics(
        self,
        endpoint_name: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """SageMaker Endpoint의 모든 주요 메트릭 조회.

        Args:
            endpoint_name: SageMaker Endpoint 이름
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(endpoint_name)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in SAGEMAKER_ENDPOINT_METRICS.items():
            try:
                namespace = metric_config["namespace"]

                # 네임스페이스별 Dimension 구성
                if namespace == "AWS/SageMaker":
                    dimensions = [
                        {"Name": "EndpointName", "Value": endpoint_name},
                        {"Name": "VariantName", "Value": "AllTraffic"},
                    ]
                else:
                    # /aws/sagemaker/Endpoints 네임스페이스
                    dimensions = [
                        {"Name": "EndpointName", "Value": endpoint_name},
                    ]

                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace=namespace,
                    MetricName=metric_name,
                    Dimensions=dimensions,
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="sagemaker-endpoint",
                    resource_id=endpoint_name,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch SageMaker metric {metric_name} for {endpoint_name}: {e}")

        return results

    def detect_drift(
        self,
        endpoint_name: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            endpoint_name: SageMaker Endpoint 이름
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(endpoint_name)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = SAGEMAKER_ENDPOINT_METRICS.get(metric_name, {})

            # 절대 임계값 기반 체크
            thresholds = metric_config.get("severity_threshold")
            if thresholds:
                severity = None
                if thresholds.get("CRITICAL") is not None and current_value > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif thresholds.get("HIGH") is not None and current_value > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="sagemaker-endpoint",
                        resource_id=endpoint_name,
                        metric_name=metric_name,
                        current_value=current_value,
                        baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="absolute",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"{metric_config.get('description', metric_name)}: {current_value:.2f}",
                        recommendation=self._get_recommendation(metric_name, severity),
                        detected_at=now,
                    ))

            # ECOD 앙상블 탐지 (임계값 없는 메트릭)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="sagemaker-endpoint",
                    resource_id=endpoint_name,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drifts.append(drift)

        return drifts

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "Invocations4XXErrors": "4XX 에러가 발생하고 있습니다. 요청 페이로드 및 모델 입력 형식을 확인하세요.",
            "Invocations5XXErrors": "5XX 에러가 발생하고 있습니다. 모델 컨테이너 로그를 확인하고 인스턴스 상태를 점검하세요.",
            "ModelLatency": "모델 추론 지연 시간에 이상 변동이 있습니다. 모델 최적화 또는 인스턴스 스케일업을 검토하세요.",
            "CPUUtilization": "CPU 사용률이 높습니다. 인스턴스 스케일아웃 또는 스케일업을 검토하세요.",
            "MemoryUtilization": "메모리 사용률이 높습니다. 인스턴스 스케일업 또는 모델 메모리 최적화를 검토하세요.",
            "GPUUtilization": "GPU 사용률이 높습니다. GPU 인스턴스 스케일아웃 또는 모델 최적화를 검토하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def _mock_metrics(self, endpoint_name: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        mock_data = {
            "Invocations4XXErrors": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            "Invocations5XXErrors": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
            "ModelLatency": {"avg": 150000.0, "min": 120000.0, "max": 200000.0, "latest": 155000.0},
            "CPUUtilization": {"avg": 45.0, "min": 30.0, "max": 60.0, "latest": 48.0},
            "MemoryUtilization": {"avg": 55.0, "min": 45.0, "max": 65.0, "latest": 58.0},
            "GPUUtilization": {"avg": 0.0, "min": 0.0, "max": 0.0, "latest": 0.0},
        }

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = SAGEMAKER_ENDPOINT_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="sagemaker-endpoint",
                resource_id=endpoint_name,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
