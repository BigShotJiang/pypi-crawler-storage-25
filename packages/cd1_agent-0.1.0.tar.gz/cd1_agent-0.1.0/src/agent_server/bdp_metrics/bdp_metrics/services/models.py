"""
BDP Metrics Agent Models.

메트릭 기반 drift 탐지를 위한 데이터 모델.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class MetricType(str, Enum):
    """메트릭 타입."""

    MSK = "msk"                     # MSK CloudWatch 메트릭
    SUBNET_IP = "subnet-ip"         # VPC Subnet IP 사용량
    SERVICE_QUOTA = "service-quota" # AWS Service Quota
    EKS_POD = "eks-pod"             # EKS Pod Container Insights
    EKS_NODE = "eks-node"           # EKS Node Container Insights
    EKS_NODEGROUP = "eks-nodegroup" # EKS NodeGroup 상태
    MWAA = "mwaa"                   # MWAA CloudWatch 메트릭
    RDS = "rds"                     # RDS CloudWatch 메트릭
    SAGEMAKER_ENDPOINT = "sagemaker-endpoint"  # SageMaker Endpoint 메트릭
    EMR_CLUSTER = "emr-cluster"     # EMR Cluster 메트릭
    EMR_SERVERLESS = "emr-serverless"  # EMR Serverless 메트릭


class DriftSeverity(str, Enum):
    """드리프트 심각도."""

    CRITICAL = "critical"   # 즉시 조치 필요
    HIGH = "high"           # 빠른 확인 필요
    MEDIUM = "medium"       # 모니터링 필요
    LOW = "low"             # 참고용


@dataclass
class MetricDataPoint:
    """메트릭 데이터 포인트."""

    timestamp: datetime
    value: float
    unit: Optional[str] = None


@dataclass
class MetricResult:
    """메트릭 조회 결과."""

    metric_type: str
    resource_id: str
    metric_name: str
    data_points: List[MetricDataPoint] = field(default_factory=list)
    statistics: Optional[Dict[str, float]] = None  # avg, min, max, sum
    unit: Optional[str] = None
    period_seconds: int = 300
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


class ChangeType(str, Enum):
    """변경 타입."""

    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"


@dataclass
class MetricBaseline:
    """메트릭 베이스라인."""

    metric_type: str
    resource_id: str
    metric_name: str
    baseline_avg: float
    baseline_stddev: float
    baseline_min: float
    baseline_max: float
    sample_count: int
    period_hours: int = 24 * 7  # 기본 7일
    version: int = 1
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환."""
        return {
            "metric_type": self.metric_type,
            "resource_id": self.resource_id,
            "metric_name": self.metric_name,
            "baseline_avg": self.baseline_avg,
            "baseline_stddev": self.baseline_stddev,
            "baseline_min": self.baseline_min,
            "baseline_max": self.baseline_max,
            "sample_count": self.sample_count,
            "period_hours": self.period_hours,
            "version": self.version,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


@dataclass
class MetricBaselineHistory:
    """메트릭 베이스라인 변경 이력."""

    id: str
    metric_type: str
    resource_id: str
    metric_name: str
    version: int
    change_type: str
    previous_baseline: Optional[Dict[str, Any]]
    current_baseline: Dict[str, Any]
    change_reason: Optional[str] = None
    changed_at: Optional[datetime] = None
    changed_by: Optional[str] = None


@dataclass
class MetricDrift:
    """메트릭 드리프트 결과."""

    metric_type: str
    resource_id: str
    metric_name: str
    current_value: float
    baseline_avg: float
    baseline_stddev: float
    z_score: float
    severity: DriftSeverity
    threshold_type: str  # "z_score", "absolute", "percentage"
    threshold_value: float
    description: Optional[str] = None
    recommendation: Optional[str] = None
    resource_name: Optional[str] = None
    detected_at: Optional[datetime] = None
    node_name: Optional[str] = None           # Pod/Node가 속한 노드명
    node_group_name: Optional[str] = None     # 노드가 속한 노드그룹명
    # ECOD 앙상블 탐지 추가 필드
    confidence_score: Optional[float] = None  # 앙상블 신뢰도 (0.0~1.0)
    detection_method_detail: Optional[str] = None  # 탐지 방법 상세 (ensemble, ecod, ecod_lite 등)
    pattern_contexts: Optional[List[str]] = None    # 인식된 패턴 설명 목록
    data_points: List[MetricDataPoint] = field(default_factory=list)  # 차트용 시계열 데이터

    @property
    def display_name(self) -> str:
        """리소스 표시 이름. resource_name이 있으면 'name(id)' 형식."""
        if self.resource_name:
            return f"{self.resource_name}({self.resource_id})"
        return self.resource_id

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환."""
        return {
            "metric_type": self.metric_type,
            "resource_id": self.resource_id,
            "resource_name": self.resource_name,
            "metric_name": self.metric_name,
            "current_value": self.current_value,
            "baseline_avg": self.baseline_avg,
            "baseline_stddev": self.baseline_stddev,
            "z_score": self.z_score,
            "severity": self.severity.value,
            "threshold_type": self.threshold_type,
            "threshold_value": self.threshold_value,
            "description": self.description,
            "recommendation": self.recommendation,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "node_name": self.node_name,
            "node_group_name": self.node_group_name,
            "confidence_score": self.confidence_score,
            "detection_method_detail": self.detection_method_detail,
            "pattern_contexts": self.pattern_contexts,
        }


@dataclass
class QuotaUsage:
    """Service Quota 사용량."""

    service_code: str
    quota_name: str
    quota_code: str
    current_value: float
    limit_value: float
    usage_percent: float
    is_adjustable: bool
    unit: Optional[str] = None

    @property
    def severity(self) -> DriftSeverity:
        """사용률 기반 심각도."""
        if self.usage_percent >= 90:
            return DriftSeverity.CRITICAL
        elif self.usage_percent >= 80:
            return DriftSeverity.HIGH
        elif self.usage_percent >= 70:
            return DriftSeverity.MEDIUM
        return DriftSeverity.LOW


@dataclass
class SubnetIPUsage:
    """Subnet IP 사용량."""

    subnet_id: str
    subnet_name: Optional[str]
    vpc_id: str
    cidr_block: str
    total_ips: int
    available_ips: int
    used_ips: int
    utilization_percent: float
    availability_zone: Optional[str] = None

    @property
    def severity(self) -> DriftSeverity:
        """사용률 기반 심각도."""
        if self.utilization_percent >= 90:
            return DriftSeverity.CRITICAL
        elif self.utilization_percent >= 80:
            return DriftSeverity.HIGH
        elif self.utilization_percent >= 70:
            return DriftSeverity.MEDIUM
        return DriftSeverity.LOW


# Z-score 임계값 설정
Z_SCORE_THRESHOLDS = {
    "HIGH": 2.5,
    "CRITICAL": 3.0,
}

@dataclass
class NodeGroupStatus:
    """EKS 노드그룹 상태."""

    nodegroup_name: str
    cluster_name: str
    status: str                    # ACTIVE, DEGRADED, CREATE_FAILED 등
    instance_types: List[str]
    desired_size: int
    current_size: int
    min_size: int
    max_size: int
    health_issues: List[str] = field(default_factory=list)

    @property
    def has_scaling_issue(self) -> bool:
        return self.desired_size != self.current_size

    @property
    def is_at_max(self) -> bool:
        return self.current_size >= self.max_size

    @property
    def scale_headroom(self) -> int:
        return self.max_size - self.current_size


@dataclass
class NodeSummary:
    """노드 메트릭 요약 (HTML 리포트용)."""

    node_name: str
    instance_id: str
    node_group_name: Optional[str] = None
    cpu_percent: Optional[float] = None
    memory_percent: Optional[float] = None
    disk_percent: Optional[float] = None
    pod_count: Optional[int] = None
    max_pods: Optional[int] = None


# EKS Node CloudWatch Container Insights 메트릭 정의
EKS_NODE_METRICS = {
    "node_cpu_utilization": {
        "description": "Node CPU 사용률",
        "cw_metric_name": "node_cpu_utilization",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "node_memory_utilization": {
        "description": "Node 메모리 사용률",
        "cw_metric_name": "node_memory_utilization",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "node_filesystem_utilization": {
        "description": "Node 디스크 사용률",
        "cw_metric_name": "node_filesystem_utilization",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 85, "CRITICAL": 95},
    },
    "node_number_of_running_pods": {
        "description": "Node Pod 수",
        "cw_metric_name": "node_number_of_running_pods",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,  # allocatable 대비 비율로 별도 처리
    },
}


# Service Quota 모니터링 대상
MONITORED_SERVICES = [
    "emr",           # EMR Cluster 수, Instance 수
    "sagemaker",     # Endpoints, Training jobs
    "athena",        # Workgroup 수, Query 동시 실행
    "glue",          # Crawlers, Jobs, Connections
    "secretsmanager", # Secrets 수
    "s3",            # Buckets 수
    "airflow",       # MWAA Environments
]


# MWAA CloudWatch 메트릭 정의 (2개 네임스페이스)
# AWS/MWAA: Environment dimension 필수 + 추가 dimension (Cluster, DatabaseRole 등)
# AmazonMWAA: Environment + Function dimension (고정값)
MWAA_METRICS = {
    # === AWS/MWAA 네임스페이스 — Container 메트릭 (Environment + Cluster) ===
    "BaseWorkerCPU": {
        "description": "BaseWorker CPU 사용률",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "CPUUtilization",
        "extra_dimension_name": "Cluster",
        "component_keyword": "BaseWorker",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "AdditionalWorkerCPU": {
        "description": "AdditionalWorker CPU 사용률",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "CPUUtilization",
        "extra_dimension_name": "Cluster",
        "component_keyword": "AdditionalWorker",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "SchedulerCPU": {
        "description": "Scheduler CPU 사용률",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "CPUUtilization",
        "extra_dimension_name": "Cluster",
        "component_keyword": "Scheduler",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "WebServerCPU": {
        "description": "WebServer CPU 사용률",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "CPUUtilization",
        "extra_dimension_name": "Cluster",
        "component_keyword": "WebServer",
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    # === AWS/MWAA 네임스페이스 — Database 메트릭 (Environment + DatabaseRole) ===
    "DatabaseCPU": {
        "description": "Database CPU 사용률",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "CPUUtilization",
        "extra_dimension_name": "DatabaseRole",
        "component_keyword": None,
        "unit": "Percent",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 80, "CRITICAL": 90},
    },
    "DatabaseConnections": {
        "description": "Database 연결 수",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "DatabaseConnections",
        "extra_dimension_name": "DatabaseRole",
        "component_keyword": None,
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,
    },
    # === AWS/MWAA 네임스페이스 — Queue 메트릭 (Environment only) ===
    "QueuedTasks": {
        "description": "대기 중인 태스크 수",
        "namespace": "AWS/MWAA",
        "cw_metric_name": "QueuedTasks",
        "extra_dimension_name": None,
        "component_keyword": None,
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,
    },
    # === AmazonMWAA 네임스페이스 — Airflow 메트릭 (Environment + Function) ===
    "DagProcessingFilePathQueueSize": {
        "description": "DAG 파싱 대기 파일 수",
        "namespace": "AmazonMWAA",
        "cw_metric_name": "FilePathQueueSize",
        "extra_dimension_name": "Function",
        "extra_dimension_value": "DagProcessing",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,
    },
    "DagProcessingTotalParseTime": {
        "description": "DAG 전체 파싱 소요 시간",
        "namespace": "AmazonMWAA",
        "cw_metric_name": "TotalParseTime",
        "extra_dimension_name": "Function",
        "extra_dimension_value": "DagProcessing",
        "unit": "Seconds",
        "statistic": "Average",
        "severity_threshold": None,
    },
}


@dataclass
class MetricsReport:
    """메트릭 탐지 리포트."""

    id: str                        # UUID
    run_timestamp: datetime
    resource_types: List[str]
    total_drifts: int
    by_severity: Dict[str, int]
    html_report: str               # HTML 리포트 본문
    raw_drifts_json: str           # MetricDrift 목록 JSON
    status: str = "completed"
