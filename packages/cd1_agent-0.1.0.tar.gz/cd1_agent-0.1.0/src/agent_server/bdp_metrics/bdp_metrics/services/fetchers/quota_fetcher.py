"""
Service Quota Fetcher.

AWS Service Quota 사용량 모니터링.
"""

import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDrift,
    QuotaUsage,
    MONITORED_SERVICES,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# 주요 모니터링 대상 Quota
MONITORED_QUOTAS = {
    "emr": [
        {"code": "L-D5E8C8A4", "name": "Active clusters"},
        {"code": "L-C5F84E39", "name": "Active instances"},
    ],
    "sagemaker": [
        {"code": "L-D8E8A4A4", "name": "Endpoints per account"},
        {"code": "L-DB9E8A9A", "name": "Training jobs running simultaneously"},
        {"code": "L-E6D8D8A4", "name": "Processing jobs running simultaneously"},
    ],
    "athena": [
        {"code": "L-8B2DEDA4", "name": "Active DDL queries"},
        {"code": "L-E5E8D8A4", "name": "Active DML queries"},
    ],
    "glue": [
        {"code": "L-8D8E8A4A", "name": "Concurrent job runs per account"},
        {"code": "L-4E4E8A4A", "name": "Number of crawlers per account"},
    ],
    "secretsmanager": [
        {"code": "L-2B6D8D8A", "name": "Secrets per region"},
    ],
    "s3": [
        {"code": "L-DC2B2D3D", "name": "Buckets per account"},
    ],
    "airflow": [
        {"code": "L-8E8D8A4A", "name": "Environments per region"},
    ],
}


class ServiceQuotaFetcher:
    """AWS Service Quota 사용량 조회기.

    Severity 결정 로직:
    - usage > 90%: CRITICAL
    - usage > 80%: HIGH
    - usage > 70%: MEDIUM
    """

    def __init__(
        self,
        quota_client=None,
        use_mock: bool = False,
        services: Optional[List[str]] = None,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._quota_client = quota_client
        self.services = services or MONITORED_SERVICES
        self._metric_cache = metric_cache
        self._cloudwatch_client = None

    @property
    def quota_client(self):
        if self._quota_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._quota_client = get_boto3_client("service-quotas", config=config)
        return self._quota_client

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    def fetch_quotas(
        self,
        service_code: Optional[str] = None,
    ) -> List[QuotaUsage]:
        """Service Quota 사용량 조회.

        Args:
            service_code: 특정 서비스 코드 (없으면 모든 모니터링 대상)

        Returns:
            QuotaUsage 목록
        """
        if self.use_mock:
            return self._mock_quotas(service_code)

        results = []
        services_to_check = [service_code] if service_code else self.services

        for svc in services_to_check:
            quotas_config = MONITORED_QUOTAS.get(svc, [])

            for quota_config in quotas_config:
                try:
                    # Quota 정보 조회
                    response = self.quota_client.get_service_quota(
                        ServiceCode=svc,
                        QuotaCode=quota_config["code"],
                    )
                    quota = response.get("Quota", {})

                    limit_value = quota.get("Value", 0)
                    usage_value = quota.get("UsageMetric", {}).get("MetricStatisticRecommendation")

                    # Usage가 없으면 CloudWatch에서 조회 시도
                    if usage_value is None:
                        usage_value = self._get_quota_usage_from_cloudwatch(svc, quota_config["code"])

                    if usage_value is None:
                        usage_value = 0

                    usage_percent = (usage_value / limit_value * 100) if limit_value > 0 else 0

                    results.append(QuotaUsage(
                        service_code=svc,
                        quota_name=quota.get("QuotaName", quota_config["name"]),
                        quota_code=quota_config["code"],
                        current_value=usage_value,
                        limit_value=limit_value,
                        usage_percent=usage_percent,
                        is_adjustable=quota.get("Adjustable", False),
                        unit=quota.get("Unit"),
                    ))

                except self.quota_client.exceptions.NoSuchResourceException:
                    logger.debug(f"Quota not found: {svc}/{quota_config['code']}")
                except Exception as e:
                    logger.error(f"Failed to fetch quota {svc}/{quota_config['code']}: {e}")

        return results

    def _get_quota_usage_from_cloudwatch(
        self,
        service_code: str,
        quota_code: str,
    ) -> Optional[float]:
        """CloudWatch에서 Quota 사용량 조회.

        일부 서비스는 Service Quotas API에서 사용량을 제공하지 않아
        CloudWatch 메트릭을 통해 조회해야 함.
        """
        try:
            response = self.cloudwatch_client.get_metric_statistics(
                Namespace="AWS/Usage",
                MetricName="ResourceCount",
                Dimensions=[
                    {"Name": "Service", "Value": service_code.upper()},
                    {"Name": "Resource", "Value": quota_code},
                    {"Name": "Type", "Value": "Resource"},
                    {"Name": "Class", "Value": "None"},
                ],
                StartTime=datetime.now(KST).replace(hour=0, minute=0, second=0),
                EndTime=datetime.now(KST),
                Period=3600,
                Statistics=["Maximum"],
            )

            datapoints = response.get("Datapoints", [])
            if datapoints:
                return max(dp["Maximum"] for dp in datapoints)

        except Exception as e:
            logger.debug(f"CloudWatch quota usage not available: {e}")

        return None

    def detect_drift(
        self,
        service_code: Optional[str] = None,
        critical_threshold: float = 90.0,
        high_threshold: float = 80.0,
        medium_threshold: float = 70.0,
    ) -> List[MetricDrift]:
        """Quota 사용량 기반 drift 감지.

        Args:
            service_code: 특정 서비스 코드 (없으면 모든 모니터링 대상)
            critical_threshold: CRITICAL 임계값 (기본 90%)
            high_threshold: HIGH 임계값 (기본 80%)
            medium_threshold: MEDIUM 임계값 (기본 70%)

        Returns:
            감지된 drift 목록
        """
        quotas = self.fetch_quotas(service_code)
        drifts = []
        now = datetime.now(KST)

        for quota in quotas:
            severity = None
            threshold = 0

            if quota.usage_percent >= critical_threshold:
                severity = DriftSeverity.CRITICAL
                threshold = critical_threshold
            elif quota.usage_percent >= high_threshold:
                severity = DriftSeverity.HIGH
                threshold = high_threshold
            elif quota.usage_percent >= medium_threshold:
                severity = DriftSeverity.MEDIUM
                threshold = medium_threshold
            else:
                continue

            drifts.append(MetricDrift(
                metric_type="service-quota",
                resource_id=f"{quota.service_code}/{quota.quota_code}",
                metric_name=quota.quota_name,
                current_value=quota.usage_percent,
                baseline_avg=0,  # Not applicable
                baseline_stddev=0,  # Not applicable
                z_score=0,  # Not applicable
                severity=severity,
                threshold_type="percentage",
                threshold_value=threshold,
                description=(
                    f"{quota.service_code.upper()} {quota.quota_name}: "
                    f"{quota.current_value:.0f}/{quota.limit_value:.0f} ({quota.usage_percent:.1f}%)"
                ),
                recommendation=self._get_recommendation(quota),
                detected_at=now,
            ))

        return drifts

    def _get_recommendation(self, quota: QuotaUsage) -> str:
        """사용량 기반 권장 조치."""
        adjustable_msg = ""
        if quota.is_adjustable:
            adjustable_msg = " Quota 증가 요청이 가능합니다."

        if quota.usage_percent >= 90:
            return f"즉시 조치 필요: {quota.quota_name} 한도 임박.{adjustable_msg}"
        elif quota.usage_percent >= 80:
            return f"Quota 증가를 검토하세요: {quota.quota_name}.{adjustable_msg}"
        return f"{quota.quota_name} 사용량을 모니터링하세요."

    def list_services(self) -> List[str]:
        """모니터링 대상 서비스 목록."""
        return self.services

    def _mock_quotas(self, service_code: Optional[str]) -> List[QuotaUsage]:
        """Mock Quota 데이터."""
        mock_data = [
            QuotaUsage(
                service_code="emr",
                quota_name="Active clusters",
                quota_code="L-D5E8C8A4",
                current_value=8,
                limit_value=10,
                usage_percent=80.0,
                is_adjustable=True,
            ),
            QuotaUsage(
                service_code="sagemaker",
                quota_name="Endpoints per account",
                quota_code="L-D8E8A4A4",
                current_value=45,
                limit_value=50,
                usage_percent=90.0,
                is_adjustable=True,
            ),
            QuotaUsage(
                service_code="athena",
                quota_name="Active DDL queries",
                quota_code="L-8B2DEDA4",
                current_value=15,
                limit_value=20,
                usage_percent=75.0,
                is_adjustable=False,
            ),
            QuotaUsage(
                service_code="glue",
                quota_name="Concurrent job runs per account",
                quota_code="L-8D8E8A4A",
                current_value=180,
                limit_value=200,
                usage_percent=90.0,
                is_adjustable=True,
            ),
            QuotaUsage(
                service_code="s3",
                quota_name="Buckets per account",
                quota_code="L-DC2B2D3D",
                current_value=70,
                limit_value=100,
                usage_percent=70.0,
                is_adjustable=False,
            ),
        ]

        if service_code:
            return [q for q in mock_data if q.service_code == service_code]
        return mock_data
