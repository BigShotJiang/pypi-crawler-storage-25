"""
EMR Serverless Metrics Fetcher.

CloudWatch 기반 EMR Serverless 메트릭 조회 및 drift 감지.
"""

import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from src.common.timezone import KST

from botocore.config import Config

from ..models import (
    DriftSeverity,
    MetricDataPoint,
    MetricResult,
    MetricDrift,
)

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)

# EMR Serverless CloudWatch 메트릭 정의
EMR_SERVERLESS_METRICS = {
    "RunningJobCount": {
        "description": "실행 중인 Job 수",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,  # Z-score 기반
    },
    "CPUAllocated": {
        "description": "할당된 CPU (vCPU)",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 85, "CRITICAL": 95},  # ratio 기반
    },
    "MemoryAllocated": {
        "description": "할당된 메모리 (MB)",
        "unit": "Megabytes",
        "statistic": "Average",
        "severity_threshold": {"HIGH": 85, "CRITICAL": 95},  # ratio 기반
    },
    "CPUUsed": {
        "description": "사용 중인 CPU (vCPU)",
        "unit": "Count",
        "statistic": "Average",
        "severity_threshold": None,
        "ratio_pair": True,  # ratio 계산에만 사용
    },
    "MemoryUsed": {
        "description": "사용 중인 메모리 (MB)",
        "unit": "Megabytes",
        "statistic": "Average",
        "severity_threshold": None,
        "ratio_pair": True,  # ratio 계산에만 사용
    },
}


class EMRServerlessFetcher:
    """EMR Serverless CloudWatch 메트릭 조회기.

    Severity 결정 로직:
    - RunningJobCount: Z-score 기반 (|z| > 2.5 → HIGH, |z| > 3.0 → CRITICAL)
    - CPUAllocated/CPUUsed: ratio 기반 (used/allocated > 85% → HIGH, > 95% → CRITICAL)
    - MemoryAllocated/MemoryUsed: ratio 기반 (used/allocated > 85% → HIGH, > 95% → CRITICAL)
    - FailedJobs: API 기반 감지 (실패 Job 존재 시 HIGH)
    """

    def __init__(
        self,
        cloudwatch_client=None,
        emr_serverless_client=None,
        use_mock: bool = False,
        metric_cache=None,
    ):
        self.use_mock = use_mock or os.getenv("METRICS_PROVIDER", "").lower() == "mock"
        self._cloudwatch_client = cloudwatch_client
        self._emr_serverless_client = emr_serverless_client
        self._metric_cache = metric_cache

    @property
    def cloudwatch_client(self):
        if self._cloudwatch_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            raw_client = get_boto3_client("cloudwatch", config=config)
            if self._metric_cache:
                from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient
                self._cloudwatch_client = CachedCloudWatchClient(raw_client, self._metric_cache)
            else:
                self._cloudwatch_client = raw_client
        return self._cloudwatch_client

    @property
    def emr_serverless_client(self):
        if self._emr_serverless_client is None and not self.use_mock:
            from bdp_common.aws_session import get_boto3_client
            self._emr_serverless_client = get_boto3_client("emr-serverless", config=config)
        return self._emr_serverless_client

    def list_applications(self) -> List[str]:
        """EMR Serverless 애플리케이션 목록 조회."""
        if self.use_mock:
            return ["mock-app-001", "mock-app-002"]

        applications = []
        try:
            response = self.emr_serverless_client.list_applications(
                states=["STARTED", "CREATED"],
            )
            for app in response.get("applications", []):
                applications.append(app["id"])
        except Exception as e:
            logger.error(f"Failed to list EMR Serverless applications: {e}")

        return applications

    def fetch_metrics(
        self,
        application_id: str,
        period_seconds: int = 300,
        duration_hours: int = 1,
    ) -> Dict[str, MetricResult]:
        """EMR Serverless 애플리케이션의 모든 주요 메트릭 조회.

        Args:
            application_id: EMR Serverless 애플리케이션 ID
            period_seconds: 메트릭 수집 주기 (초)
            duration_hours: 조회 기간 (시간)

        Returns:
            메트릭명을 키로 하는 MetricResult 딕셔너리
        """
        if self.use_mock:
            return self._mock_metrics(application_id)

        # CloudWatch 1440 datapoints 제한 대응
        max_datapoints = 1440
        min_period = (duration_hours * 3600) // max_datapoints
        if min_period > period_seconds:
            period_seconds = ((min_period // 60) + 1) * 60  # 분 단위 올림

        results = {}
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(hours=duration_hours)

        for metric_name, metric_config in EMR_SERVERLESS_METRICS.items():
            try:
                response = self.cloudwatch_client.get_metric_statistics(
                    Namespace="AWS/EMRServerless",
                    MetricName=metric_name,
                    Dimensions=[
                        {"Name": "ApplicationId", "Value": application_id},
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=period_seconds,
                    Statistics=[metric_config["statistic"]],
                )

                data_points = []
                for dp in response.get("Datapoints", []):
                    data_points.append(MetricDataPoint(
                        timestamp=dp["Timestamp"],
                        value=dp[metric_config["statistic"]],
                        unit=dp.get("Unit"),
                    ))

                # 시간순 정렬
                data_points.sort(key=lambda x: x.timestamp)

                # 통계 계산
                if data_points:
                    values = [dp.value for dp in data_points]
                    statistics = {
                        "avg": sum(values) / len(values),
                        "min": min(values),
                        "max": max(values),
                        "latest": values[-1],
                    }
                else:
                    statistics = None

                results[metric_name] = MetricResult(
                    metric_type="emr-serverless",
                    resource_id=application_id,
                    metric_name=metric_name,
                    data_points=data_points,
                    statistics=statistics,
                    unit=metric_config["unit"],
                    period_seconds=period_seconds,
                    start_time=start_time,
                    end_time=end_time,
                )

            except Exception as e:
                logger.error(f"Failed to fetch EMR Serverless metric {metric_name} for {application_id}: {e}")

        return results

    def detect_drift(
        self,
        application_id: str,
        baseline_avg: Optional[Dict[str, float]] = None,
        baseline_stddev: Optional[Dict[str, float]] = None,
        historical_data: Optional[Dict[str, Any]] = None,
        anomaly_detector: Optional[Any] = None,
    ) -> List[MetricDrift]:
        """메트릭 기반 drift 감지.

        Args:
            application_id: EMR Serverless 애플리케이션 ID
            baseline_avg: 메트릭별 baseline 평균 (없으면 절대 임계값만 사용)
            baseline_stddev: 메트릭별 baseline 표준편차

        Returns:
            감지된 drift 목록
        """
        metrics = self.fetch_metrics(application_id)
        drifts = []
        now = datetime.now(KST)

        for metric_name, result in metrics.items():
            if not result.statistics:
                continue

            current_value = result.statistics.get("latest", result.statistics.get("avg"))
            metric_config = EMR_SERVERLESS_METRICS.get(metric_name, {})

            # ratio_pair 메트릭은 개별 drift 감지 건너뛰기
            if metric_config.get("ratio_pair"):
                continue

            # 절대 임계값 기반 체크 (ratio 메트릭은 별도 처리)
            thresholds = metric_config.get("severity_threshold")
            if thresholds:
                # CPUAllocated/MemoryAllocated는 ratio로 처리하므로 여기서 건너뜀
                pass

            # ECOD 앙상블 탐지 (RunningJobCount)
            elif anomaly_detector and historical_data and metric_name in historical_data:
                hist_values, hist_timestamps = historical_data[metric_name]
                drift = anomaly_detector.detect_and_build_drift(
                    metric_type="emr-serverless",
                    resource_id=application_id,
                    metric_name=metric_name,
                    current_value=current_value,
                    baseline_avg=baseline_avg.get(metric_name, 0) if baseline_avg else 0,
                    baseline_stddev=baseline_stddev.get(metric_name, 0) if baseline_stddev else 0,
                    historical_values=hist_values,
                    historical_timestamps=hist_timestamps,
                    description_prefix=metric_config.get("description", metric_name),
                    recommendation=self._get_recommendation(metric_name, DriftSeverity.HIGH),
                    detected_at=now,
                )
                if drift:
                    drifts.append(drift)

        # CPU ratio 감지
        cpu_allocated = metrics.get("CPUAllocated")
        cpu_used = metrics.get("CPUUsed")
        if (cpu_allocated and cpu_allocated.statistics
                and cpu_used and cpu_used.statistics):
            alloc_val = cpu_allocated.statistics.get("latest", cpu_allocated.statistics.get("avg"))
            used_val = cpu_used.statistics.get("latest", cpu_used.statistics.get("avg"))

            if alloc_val and alloc_val > 0:
                cpu_ratio = (used_val / alloc_val) * 100
                thresholds = EMR_SERVERLESS_METRICS["CPUAllocated"]["severity_threshold"]

                severity = None
                if cpu_ratio > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif cpu_ratio > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="emr-serverless",
                        resource_id=application_id,
                        metric_name="CPUUtilizationRatio",
                        current_value=cpu_ratio,
                        baseline_avg=baseline_avg.get("CPUAllocated", 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get("CPUAllocated", 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="ratio",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"CPU 사용률(Used/Allocated): {cpu_ratio:.1f}%",
                        recommendation=self._get_recommendation("CPUUtilizationRatio", severity),
                        detected_at=now,
                    ))

        # Memory ratio 감지
        mem_allocated = metrics.get("MemoryAllocated")
        mem_used = metrics.get("MemoryUsed")
        if (mem_allocated and mem_allocated.statistics
                and mem_used and mem_used.statistics):
            alloc_val = mem_allocated.statistics.get("latest", mem_allocated.statistics.get("avg"))
            used_val = mem_used.statistics.get("latest", mem_used.statistics.get("avg"))

            if alloc_val and alloc_val > 0:
                mem_ratio = (used_val / alloc_val) * 100
                thresholds = EMR_SERVERLESS_METRICS["MemoryAllocated"]["severity_threshold"]

                severity = None
                if mem_ratio > thresholds["CRITICAL"]:
                    severity = DriftSeverity.CRITICAL
                elif mem_ratio > thresholds["HIGH"]:
                    severity = DriftSeverity.HIGH

                if severity:
                    drifts.append(MetricDrift(
                        metric_type="emr-serverless",
                        resource_id=application_id,
                        metric_name="MemoryUtilizationRatio",
                        current_value=mem_ratio,
                        baseline_avg=baseline_avg.get("MemoryAllocated", 0) if baseline_avg else 0,
                        baseline_stddev=baseline_stddev.get("MemoryAllocated", 0) if baseline_stddev else 0,
                        z_score=0,
                        severity=severity,
                        threshold_type="ratio",
                        threshold_value=thresholds[severity.value.upper()],
                        description=f"메모리 사용률(Used/Allocated): {mem_ratio:.1f}%",
                        recommendation=self._get_recommendation("MemoryUtilizationRatio", severity),
                        detected_at=now,
                    ))

        # Failed jobs 감지
        failed_job_drifts = self._check_failed_jobs(application_id)
        drifts.extend(failed_job_drifts)

        return drifts

    def _check_failed_jobs(self, application_id: str) -> List[MetricDrift]:
        """최근 1시간 내 실패한 Job 감지.

        Args:
            application_id: EMR Serverless 애플리케이션 ID

        Returns:
            실패 Job drift 목록
        """
        if self.use_mock:
            return []

        now = datetime.now(KST)
        one_hour_ago = now - timedelta(hours=1)

        try:
            response = self.emr_serverless_client.list_job_runs(
                applicationId=application_id,
                states=["FAILED"],
            )

            failed_jobs = []
            for job in response.get("jobRuns", []):
                created_at = job.get("createdAt")
                if created_at and created_at >= one_hour_ago:
                    failed_jobs.append(job)

            if failed_jobs:
                return [MetricDrift(
                    metric_type="emr-serverless",
                    resource_id=application_id,
                    metric_name="FailedJobs",
                    current_value=len(failed_jobs),
                    baseline_avg=0,
                    baseline_stddev=0,
                    z_score=0,
                    severity=DriftSeverity.HIGH,
                    threshold_type="absolute",
                    threshold_value=0,
                    description=f"최근 1시간 내 실패한 Job {len(failed_jobs)}건 감지",
                    recommendation=self._get_recommendation("FailedJobs", DriftSeverity.HIGH),
                    detected_at=now,
                )]

        except Exception as e:
            logger.error(f"Failed to check failed jobs for {application_id}: {e}")

        return []

    def _get_recommendation(self, metric_name: str, severity: DriftSeverity) -> str:
        """메트릭별 권장 조치 반환."""
        recommendations = {
            "RunningJobCount": "실행 중인 Job 수에 이상 변동이 있습니다. Job 스케줄 및 리소스 상태를 확인하세요.",
            "CPUUtilizationRatio": "CPU 사용률이 높습니다. 애플리케이션 리소스 설정 증가 또는 Job 최적화를 검토하세요.",
            "MemoryUtilizationRatio": "메모리 사용률이 높습니다. 메모리 할당 증가 또는 데이터 처리 최적화를 검토하세요.",
            "FailedJobs": "실패한 Job이 감지되었습니다. Job 로그를 확인하고 실패 원인을 분석하세요.",
        }
        return recommendations.get(metric_name, "메트릭 이상이 감지되었습니다. 상세 모니터링이 필요합니다.")

    def _mock_metrics(self, application_id: str) -> Dict[str, MetricResult]:
        """Mock 메트릭 데이터 반환."""
        now = datetime.now(KST)
        start = now - timedelta(hours=1)

        mock_data = {
            "RunningJobCount": {"avg": 3.0, "min": 1.0, "max": 5.0, "latest": 3.0},
            "CPUAllocated": {"avg": 16.0, "min": 8.0, "max": 24.0, "latest": 16.0},
            "CPUUsed": {"avg": 8.0, "min": 4.0, "max": 12.0, "latest": 8.0},
            "MemoryAllocated": {"avg": 65536.0, "min": 32768.0, "max": 98304.0, "latest": 65536.0},
            "MemoryUsed": {"avg": 32768.0, "min": 16384.0, "max": 49152.0, "latest": 32768.0},
        }

        results = {}
        for metric_name, stats in mock_data.items():
            metric_config = EMR_SERVERLESS_METRICS.get(metric_name, {})
            results[metric_name] = MetricResult(
                metric_type="emr-serverless",
                resource_id=application_id,
                metric_name=metric_name,
                data_points=[
                    MetricDataPoint(timestamp=now, value=stats["latest"], unit=metric_config.get("unit")),
                ],
                statistics=stats,
                unit=metric_config.get("unit"),
                period_seconds=300,
                start_time=start,
                end_time=now,
            )

        return results
