"""
BDP Metrics Agent - Lambda Handler.

CloudWatch 메트릭 기반 drift 탐지.
실행 주기: 5분~1시간

Supported Metrics:
- MSK: CpuUser, DiskUsed, OfflinePartitions
- MWAA: Worker/Scheduler/WebServer/Database CPU, DatabaseConnections, QueuedTasks, DagProcessing
- Subnet IP: IP utilization
- Service Quota: EMR, SageMaker, Athena, Glue 등
- EKS Pod: CPU, Memory, Network RX/TX, Container Restarts
- EKS Node: CPU, Memory, Disk, Pod Count
- EKS NodeGroup: Scaling status, Capacity, Health
- RDS: CPUUtilization, FreeStorageSpace, FreeableMemory, DatabaseConnections
- SageMaker Endpoint: Invocations Errors, ModelLatency, CPU/Memory/GPU Utilization
- EMR Cluster: IsIdle, HDFSUtilization, YARNMemoryAvailablePercentage
- EMR Serverless: RunningJobCount, CPU/Memory Utilization Ratio

resource_types 지원 타입:
- msk, mwaa, subnet-ip, service-quota
- eks       → 노드그룹 + 노드 + Pod 전체
- eks-node  → 노드그룹 + 노드만
- eks-pod   → Pod만 (기존 동작 유지)
- rds, sagemaker-endpoint, emr-cluster, emr-serverless
"""

import json as json_module
import logging
import os
import uuid
from collections import defaultdict
from datetime import datetime
from typing import Any

from bdp_common.charts.svg_chart import ChartDataPoint, SVGChartGenerator, ThresholdLine
from bdp_common.deep_agent import DeepAgentExecutor, DetectionInput, DetectionItem
from bdp_common.eventbridge.publisher import (
    AlertEvent,
    EmailChannel,
    EventPublisher,
    KakaoChannel,
    ProductionAlertDetail,
    get_environment_account_name,
)

from src.agent_server.bdp_common.stores.metric_cache import MetricCacheStore
from src.agent_server.bdp_common.stores.metric_config_reader import MetricConfigReader
from src.common.timezone import KST

from .services.baseline_store import MetricsBaselineStore
from .services.fetchers.eks_node_metrics_fetcher import EKSNodeMetricsFetcher
from .services.fetchers.eks_pod_metrics_fetcher import EKSPodMetricsFetcher
from .services.fetchers.emr_cluster_metrics_fetcher import EMRClusterMetricsFetcher
from .services.fetchers.emr_serverless_fetcher import EMRServerlessFetcher
from .services.fetchers.msk_metrics_fetcher import MSKMetricsFetcher
from .services.fetchers.mwaa_metrics_fetcher import MWAAMetricsFetcher
from .services.fetchers.quota_fetcher import ServiceQuotaFetcher
from .services.fetchers.rds_metrics_fetcher import RDSMetricsFetcher
from .services.fetchers.sagemaker_endpoint_fetcher import SageMakerEndpointFetcher
from .services.fetchers.subnet_metrics_fetcher import SubnetIPMetricsFetcher
from .services.metric_anomaly_detector import MetricAnomalyDetector
from .services.models import (
    DriftSeverity,
    MetricDrift,
    MetricsReport,
    NodeGroupStatus,
    NodeSummary,
)
from .services.report_store import MetricsReportStore

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class BDPMetricsHandler:
    """BDP Metrics Agent Handler.

    CloudWatch 메트릭 및 서비스 quota 기반 drift 탐지.
    """

    def __init__(
        self,
        provider: str | None = None,
        baseline_provider: str | None = None,
        secret_id: str | None = None,
        db: str | None = None,
        eks_cluster_name: str | None = None,
        eks_namespaces: list[str] | None = None,
        mwaa_environment_name: str | None = None,
    ):
        """핸들러 초기화.

        Args:
            provider: Metrics provider ("mock" or "aws")
            baseline_provider: Baseline storage provider ("mock", "sqlite", "mysql")
            secret_id: AWS Secrets Manager secret ID for DB credentials
            db: Database name for baseline storage
            eks_cluster_name: EKS 클러스터 이름
            eks_namespaces: EKS 대상 namespace 목록 (None이면 시스템 NS 제외 전체)
            mwaa_environment_name: MWAA 환경 이름
        """
        self.provider = provider or os.getenv("METRICS_PROVIDER", "mock")
        self._use_mock = self.provider == "mock"

        # Baseline 저장소
        self.baseline_secret_id = secret_id or os.getenv("BASELINE_SECRET_ID")
        self.baseline_db = db or os.getenv("BASELINE_DB_NAME")
        self.baseline_store = MetricsBaselineStore(
            provider=baseline_provider or os.getenv("BASELINE_DB_PROVIDER", "mock"),
            secret_id=self.baseline_secret_id,
            db=self.baseline_db,
        )
        self.baseline_store.ensure_tables()

        # Report 저장소
        self.report_store = MetricsReportStore(
            provider=baseline_provider or os.getenv("BASELINE_DB_PROVIDER", "mock"),
            secret_id=self.baseline_secret_id,
            db=self.baseline_db,
        )
        self.report_store.ensure_tables()

        # Metric cache (Victoria Metrics)
        cache_provider = self._resolve_cache_provider()
        self.metric_cache = MetricCacheStore(provider=cache_provider)

        # Metric config reader (read enabled metrics from portal DB)
        self.metric_config_reader = MetricConfigReader(
            provider=baseline_provider or os.getenv("BASELINE_DB_PROVIDER", "mock"),
            secret_id=self.baseline_secret_id,
            db=self.baseline_db,
        )

        # ECOD 앙상블 이상 탐지기
        self.anomaly_detector = MetricAnomalyDetector()

        # Fetchers (lazy init)
        self._msk_fetcher = None
        self._subnet_fetcher = None
        self._quota_fetcher = None
        self._eks_pod_fetcher = None
        self._eks_node_fetcher = None
        self._mwaa_fetcher = None
        self._rds_fetcher = None
        self._sagemaker_endpoint_fetcher = None
        self._emr_cluster_fetcher = None
        self._emr_serverless_fetcher = None

        # MWAA 설정
        self.mwaa_environment_name = mwaa_environment_name or os.getenv("MWAA_ENVIRONMENT_NAME")

        # EKS 설정
        self.eks_cluster_name = eks_cluster_name or os.getenv("EKS_CLUSTER_NAME")
        self.eks_namespaces = eks_namespaces
        if self.eks_namespaces is None:
            ns_str = os.getenv("EKS_NAMESPACES", "")
            self.eks_namespaces = [n.strip() for n in ns_str.split(",") if n.strip()] or None

        # 알림 설정
        self.event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.event_publisher = EventPublisher(
            source="cd1-agent.bdp-metrics",
            event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
            use_mock=(self.event_provider == "mock"),
        )

        # Production 알림 설정
        email_to_str = os.getenv("DEFAULT_EMAIL_TO", "")
        email_cc_str = os.getenv("DEFAULT_EMAIL_CC", "")
        self.default_email_to = [e.strip() for e in email_to_str.split(",") if e.strip()]
        self.default_email_cc = [e.strip() for e in email_cc_str.split(",") if e.strip()]

        logger.info(
            f"BDPMetricsHandler initialized: "
            f"provider={self.provider}, "
            f"baseline_provider={self.baseline_store.provider_type}, "
            f"cache_provider={self.metric_cache.provider_type}, "
            f"event_provider={self.event_provider}"
        )

    def _resolve_cache_provider(self) -> str | None:
        """admin_settings에서 에이전트별 캐시 설정 읽기. 실패 시 None (env fallback)."""
        try:
            from src.agent_server.bdp_common.stores.admin_settings_reader import AdminSettingsReader

            reader = AdminSettingsReader(
                provider=os.getenv("BASELINE_DB_PROVIDER", "mock"),
                secret_id=self.baseline_secret_id,
                db=self.baseline_db,
            )
            setting = reader.get_setting("cw_cache_bdp_metrics")
            if setting:
                resolved = {"direct": "noop", "cache": "victoria_metrics"}.get(setting, setting)
                logger.info(f"CW cache setting from admin_settings: {setting} -> {resolved}")
                return resolved
        except Exception as e:
            logger.warning(f"Failed to read cache setting, using env default: {e}")
        return None

    @property
    def msk_fetcher(self):
        if self._msk_fetcher is None:
            self._msk_fetcher = MSKMetricsFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._msk_fetcher

    @property
    def subnet_fetcher(self):
        if self._subnet_fetcher is None:
            self._subnet_fetcher = SubnetIPMetricsFetcher(use_mock=self._use_mock)
        return self._subnet_fetcher

    @property
    def quota_fetcher(self):
        if self._quota_fetcher is None:
            self._quota_fetcher = ServiceQuotaFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._quota_fetcher

    @property
    def eks_pod_fetcher(self):
        if self._eks_pod_fetcher is None:
            self._eks_pod_fetcher = EKSPodMetricsFetcher(
                cluster_name=self.eks_cluster_name or "",
                namespaces=self.eks_namespaces,
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._eks_pod_fetcher

    @property
    def eks_node_fetcher(self):
        if self._eks_node_fetcher is None:
            self._eks_node_fetcher = EKSNodeMetricsFetcher(
                cluster_name=self.eks_cluster_name or "",
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._eks_node_fetcher

    @property
    def mwaa_fetcher(self):
        if self._mwaa_fetcher is None:
            self._mwaa_fetcher = MWAAMetricsFetcher(
                environment_name=self.mwaa_environment_name or "",
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._mwaa_fetcher

    @property
    def rds_fetcher(self):
        if self._rds_fetcher is None:
            self._rds_fetcher = RDSMetricsFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._rds_fetcher

    @property
    def sagemaker_endpoint_fetcher(self):
        if self._sagemaker_endpoint_fetcher is None:
            self._sagemaker_endpoint_fetcher = SageMakerEndpointFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._sagemaker_endpoint_fetcher

    @property
    def emr_cluster_fetcher(self):
        if self._emr_cluster_fetcher is None:
            self._emr_cluster_fetcher = EMRClusterMetricsFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._emr_cluster_fetcher

    @property
    def emr_serverless_fetcher(self):
        if self._emr_serverless_fetcher is None:
            self._emr_serverless_fetcher = EMRServerlessFetcher(
                use_mock=self._use_mock,
                metric_cache=self.metric_cache,
            )
        return self._emr_serverless_fetcher

    def process(self, event: dict[str, Any]) -> dict[str, Any]:
        """이벤트 처리.

        Args:
            event: 이벤트 페이로드
                - action: "detect" (기본값) 또는 "update_baselines"
                - resource_types: 대상 리소스 타입 목록 (선택)
                    지원 타입: msk, mwaa, subnet-ip, service-quota, eks, eks-node, eks-pod
                - resource_ids: 특정 리소스 ID 목록 (선택)

        Returns:
            처리 결과
        """
        action = event.get("action", "detect")

        if action == "update_baselines":
            return self._update_baselines(event)
        elif action == "daily_report":
            return self._generate_daily_report(event)
        elif action == "e2e":
            return self._run_e2e(event)
        else:
            return self._detect_drift(event)

    def _detect_drift(self, event: dict[str, Any]) -> dict[str, Any]:
        """메트릭 기반 drift 탐지.

        Args:
            event: 이벤트 페이로드
                - resource_types: 대상 리소스 타입 목록 (선택)
                - resource_ids: 특정 리소스 ID 목록 (선택)
                - publish_alerts: EventBridge 발행 여부 (기본 True)
                - send_kakao: 카카오톡 알림 발송 여부 (기본 False)
                - email_to: 이메일 수신자 목록
                - email_cc: 이메일 참조 목록

        Returns:
            탐지 결과
        """
        resource_types = event.get("resource_types", ["subnet-ip"])
        resource_ids = event.get("resource_ids")
        publish_alerts = event.get("publish_alerts", True)
        send_kakao = event.get("send_kakao", False)
        email_to = event.get("email_to") or self.default_email_to
        email_cc = event.get("email_cc") or self.default_email_cc
        enabled_metrics = event.get("enabled_metrics")  # Optional: {resource_type: [metric_names]}
        if enabled_metrics is None:
            enabled_metrics = self.metric_config_reader.get_enabled_by_service() or None

        all_drifts: list[MetricDrift] = []

        # MSK 메트릭 drift 탐지
        if "msk" in resource_types:
            clusters = resource_ids or self.msk_fetcher.list_clusters()
            for cluster_name in clusters:
                # Baseline 조회
                baselines = self.baseline_store.list_baselines(
                    metric_type="msk",
                    resource_id=cluster_name,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "msk", cluster_name, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.msk_fetcher.detect_drift(
                    cluster_name=cluster_name,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        # MWAA 메트릭 drift 탐지
        if "mwaa" in resource_types:
            env_name = event.get("mwaa_environment_name") or self.mwaa_environment_name
            if not env_name:
                logger.warning("MWAA environment name not set, skipping MWAA metrics")
            else:
                baselines = self.baseline_store.list_baselines(
                    metric_type="mwaa",
                    resource_id=env_name,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data("mwaa", env_name, b.metric_name)
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.mwaa_fetcher.detect_drift(
                    environment_name=env_name,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        # Subnet IP drift 탐지
        if "subnet-ip" in resource_types:
            drifts = self.subnet_fetcher.detect_drift()
            all_drifts.extend(drifts)

        # Service Quota drift 탐지
        if "service-quota" in resource_types:
            drifts = self.quota_fetcher.detect_drift()
            all_drifts.extend(drifts)

        # EKS 라우팅
        run_eks_node = "eks" in resource_types or "eks-node" in resource_types
        run_eks_pod = "eks" in resource_types or "eks-pod" in resource_types

        node_group_statuses = []
        node_summaries = {}
        node_to_ng = {}

        if run_eks_node:
            # 노드그룹 상태 조회
            node_group_statuses = self.eks_node_fetcher.get_node_group_statuses()

            # 노드 → 노드그룹 매핑
            node_to_ng = self.eks_node_fetcher.get_node_to_nodegroup_map()

            # 노드 요약 (HTML 헤더용)
            node_summaries = self.eks_node_fetcher.get_node_summaries()

            # 노드그룹 이상 감지 (스케일링 실패, 용량 포화, 그룹 평균 등)
            ng_drifts = self.eks_node_fetcher.detect_node_group_issues(
                node_summaries=node_summaries,
            )
            all_drifts.extend(ng_drifts)

            # 노드 메트릭 drift 감지
            nodes = self.eks_node_fetcher.list_nodes()
            for node_info in nodes:
                node_name = node_info["NodeName"]
                instance_id = node_info.get("InstanceId", "")
                ng_name = node_to_ng.get(node_name)
                baselines = self.baseline_store.list_baselines(
                    metric_type="eks-node",
                    resource_id=node_name,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "eks-node", node_name, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.eks_node_fetcher.detect_drift(
                    node_name=node_name,
                    instance_id=instance_id,
                    node_group_name=ng_name,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        if run_eks_pod:
            pods = self.eks_pod_fetcher.list_pods()
            for pod_info in pods:
                pod_name = pod_info["PodName"]
                namespace = pod_info["Namespace"]
                pod_node_name = pod_info.get("NodeName")
                resource_id = f"{namespace}/{pod_name}"

                baselines = self.baseline_store.list_baselines(
                    metric_type="eks-pod",
                    resource_id=resource_id,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "eks-pod", resource_id, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.eks_pod_fetcher.detect_drift(
                    pod_name=pod_name,
                    namespace=namespace,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                # Pod drift에 노드 컨텍스트 추가
                for d in drifts:
                    d.node_name = pod_node_name
                    d.node_group_name = node_to_ng.get(pod_node_name) if pod_node_name else None
                all_drifts.extend(drifts)

        # RDS 메트릭 drift 탐지
        if "rds" in resource_types:
            instances = resource_ids or self.rds_fetcher.list_instances()
            for db_instance_id in instances:
                baselines = self.baseline_store.list_baselines(
                    metric_type="rds",
                    resource_id=db_instance_id,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "rds", db_instance_id, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.rds_fetcher.detect_drift(
                    db_instance_id=db_instance_id,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        # SageMaker Endpoint 메트릭 drift 탐지
        if "sagemaker-endpoint" in resource_types:
            endpoints = resource_ids or self.sagemaker_endpoint_fetcher.list_endpoints()
            for endpoint_name in endpoints:
                baselines = self.baseline_store.list_baselines(
                    metric_type="sagemaker-endpoint",
                    resource_id=endpoint_name,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "sagemaker-endpoint", endpoint_name, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.sagemaker_endpoint_fetcher.detect_drift(
                    endpoint_name=endpoint_name,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        # EMR Cluster 메트릭 drift 탐지
        if "emr-cluster" in resource_types:
            clusters = resource_ids or self.emr_cluster_fetcher.list_clusters()
            for cluster_id in clusters:
                baselines = self.baseline_store.list_baselines(
                    metric_type="emr-cluster",
                    resource_id=cluster_id,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                drifts = self.emr_cluster_fetcher.detect_drift(
                    cluster_id=cluster_id,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                )
                all_drifts.extend(drifts)

        # EMR Serverless 메트릭 drift 탐지
        if "emr-serverless" in resource_types:
            applications = resource_ids or self.emr_serverless_fetcher.list_applications()
            for application_id in applications:
                baselines = self.baseline_store.list_baselines(
                    metric_type="emr-serverless",
                    resource_id=application_id,
                )
                baseline_avg = {b.metric_name: b.baseline_avg for b in baselines}
                baseline_stddev = {b.metric_name: b.baseline_stddev for b in baselines}

                # 앙상블 탐지용 historical data
                historical_data = {}
                for b in baselines:
                    hist = self.baseline_store.get_historical_data(
                        "emr-serverless", application_id, b.metric_name
                    )
                    if hist:
                        historical_data[b.metric_name] = hist

                drifts = self.emr_serverless_fetcher.detect_drift(
                    application_id=application_id,
                    baseline_avg=baseline_avg if baselines else None,
                    baseline_stddev=baseline_stddev if baselines else None,
                    historical_data=historical_data or None,
                    anomaly_detector=self.anomaly_detector,
                )
                all_drifts.extend(drifts)

        # enabled_metrics 필터 적용 (역호환: 없으면 전체 유지)
        if enabled_metrics:
            filtered = []
            for d in all_drifts:
                if d.metric_type in enabled_metrics:
                    if d.metric_name in enabled_metrics[d.metric_type]:
                        filtered.append(d)
                else:
                    # resource_type이 enabled_metrics에 없으면 그대로 통과
                    filtered.append(d)
            logger.info(f"enabled_metrics filter: {len(all_drifts)} -> {len(filtered)} drifts")
            all_drifts = filtered

        logger.info(f"Drift detection complete: {len(all_drifts)} drifts found")

        # 알림 발행
        if all_drifts and publish_alerts:
            self._publish_events(
                all_drifts,
                email_to,
                email_cc,
                send_kakao,
                node_group_statuses=node_group_statuses,
                node_summaries=node_summaries,
            )

        # 리포트 저장
        try:
            severity_counts = {
                "critical": sum(1 for d in all_drifts if d.severity == DriftSeverity.CRITICAL),
                "high": sum(1 for d in all_drifts if d.severity == DriftSeverity.HIGH),
                "medium": sum(1 for d in all_drifts if d.severity == DriftSeverity.MEDIUM),
                "low": sum(1 for d in all_drifts if d.severity == DriftSeverity.LOW),
            }

            if all_drifts:
                html_report = self._generate_html_message(
                    all_drifts,
                    f"메트릭 Drift 탐지: {len(all_drifts)}건",
                    severity_counts,
                    node_group_statuses=node_group_statuses,
                    node_summaries=node_summaries,
                )
            else:
                html_report = "<p>Drift 미탐지</p>"

            report = MetricsReport(
                id=str(uuid.uuid4()),
                run_timestamp=datetime.now(KST),
                resource_types=resource_types,
                total_drifts=len(all_drifts),
                by_severity=severity_counts,
                html_report=html_report,
                raw_drifts_json=json_module.dumps(
                    [d.to_dict() for d in all_drifts],
                    default=str,
                    ensure_ascii=False,
                ),
                status="completed",
            )
            self.report_store.save_report(report)
            logger.info(f"Report saved: {report.id}")
        except Exception as e:
            logger.error(f"Failed to save report: {e}")

        response = self._build_response(all_drifts)
        return self._run_deep_analysis(response)

    def _run_deep_analysis(self, detect_result: dict[str, Any]) -> dict[str, Any]:
        """심각도 높을 때 deep analysis 실행."""
        severity = detect_result.get("summary", {}).get("by_severity", {})
        if severity.get("critical", 0) > 0 or severity.get("high", 0) > 0:
            try:
                items = self._normalize_detection_items(detect_result)
                detection_input = DetectionInput(
                    agent_type="bdp_metrics",
                    detection_type="metrics_drift",
                    severity="critical" if severity.get("critical", 0) > 0 else "high",
                    summary=f"메트릭 드리프트 {detect_result.get('summary', {}).get('total_drifts', 0)}건 탐지",
                    total_anomalies=detect_result.get("summary", {}).get("total_drifts", 0),
                    severity_breakdown=severity,
                    items=items,
                )
                executor = DeepAgentExecutor(tools=create_investigation_tools("bdp_metrics"))
                result = executor.run(detection_input)
                detect_result["deep_analysis"] = result.model_dump()
            except Exception as e:
                logger.error(f"Deep analysis 실패: {e}")
        return detect_result

    def _normalize_detection_items(self, detect_result: dict[str, Any]) -> list[DetectionItem]:
        """메트릭 드리프트 결과를 DetectionItem 형식으로 변환."""
        items = []
        for d in detect_result.get("drifts", []):
            items.append(
                DetectionItem(
                    item_type="drift",
                    resource_id=d.get("resource_id", "unknown"),
                    severity=d.get("severity", "medium"),
                    title=f"{d.get('metric_type', '')} - {d.get('metric_name', '')}",
                    description=d.get("description", ""),
                    raw_data={
                        "metric_type": d.get("metric_type", ""),
                        "metric_name": d.get("metric_name", ""),
                        "current_value": d.get("current_value", 0),
                        "baseline_avg": d.get("baseline_avg", 0),
                    },
                )
            )
        return items

    def _get_highest_severity(self, drifts: list[MetricDrift]) -> DriftSeverity:
        """가장 높은 심각도 반환."""
        for severity in [DriftSeverity.CRITICAL, DriftSeverity.HIGH, DriftSeverity.MEDIUM]:
            if any(d.severity == severity for d in drifts):
                return severity
        return DriftSeverity.LOW

    def _get_severity_emoji(self, severity: DriftSeverity) -> str:
        """심각도에 따른 이모지 반환."""
        emoji_map = {
            DriftSeverity.CRITICAL: "🔴",
            DriftSeverity.HIGH: "🟠",
            DriftSeverity.MEDIUM: "🟡",
            DriftSeverity.LOW: "🟢",
        }
        return emoji_map.get(severity, "⚪")

    def _publish_events(
        self,
        drifts: list[MetricDrift],
        email_to: list[str],
        email_cc: list[str],
        send_kakao: bool = False,
        node_group_statuses: list[NodeGroupStatus] | None = None,
        node_summaries: dict[str, NodeSummary] | None = None,
    ) -> None:
        """EventBridge에 이벤트 발행.

        Mock 모드에서는 기존 AlertEvent 형식 사용.
        Production 모드에서는 내부 알림 시스템 형식 사용.

        Args:
            drifts: MetricDrift 목록
            email_to: 이메일 수신자 목록
            email_cc: 이메일 참조 목록
            send_kakao: 카카오톡 알림 발송 여부
            node_group_statuses: 노드그룹 상태 목록
            node_summaries: 노드 요약 딕셔너리
        """
        try:
            highest_severity = self._get_highest_severity(drifts)
            severity_emoji = self._get_severity_emoji(highest_severity)

            # 요약 메시지 생성
            severity_counts = {
                "critical": sum(1 for d in drifts if d.severity == DriftSeverity.CRITICAL),
                "high": sum(1 for d in drifts if d.severity == DriftSeverity.HIGH),
                "medium": sum(1 for d in drifts if d.severity == DriftSeverity.MEDIUM),
                "low": sum(1 for d in drifts if d.severity == DriftSeverity.LOW),
            }
            title = f"메트릭 Drift 탐지: {len(drifts)}건"

            # 메트릭 타입별 그룹핑
            TYPE_LABELS = {
                "eks-pod": "EKS Pod",
                "eks-node": "EKS Node",
                "eks-nodegroup": "EKS NodeGroup",
                "msk": "MSK",
                "mwaa": "MWAA",
                "subnet-ip": "Subnet-IP",
                "service-quota": "Service Quota",
            }
            type_groups: dict[str, list[MetricDrift]] = defaultdict(list)
            for d in drifts:
                type_groups[d.metric_type].append(d)

            type_lines = []
            for mtype, group in type_groups.items():
                label = TYPE_LABELS.get(mtype, mtype.upper())
                items = []
                for d in group[:5]:
                    items.append(
                        f"  • {d.display_name}: {d.metric_name} {d.current_value:.1f} ({d.severity.value.upper()})"
                    )
                section = f"[{label}] {len(group)}건\n" + "\n".join(items)
                if len(group) > 5:
                    section += f"\n  ... 외 {len(group) - 5}건"
                type_lines.append(section)

            message = (
                f"[CRITICAL: {severity_counts['critical']}, HIGH: {severity_counts['high']}, "
                f"MEDIUM: {severity_counts['medium']}, LOW: {severity_counts['low']}]\n\n"
                + "\n\n".join(type_lines)
            )

            if self.event_publisher.use_mock:
                # Mock 모드: AlertEvent 형식
                event = AlertEvent(
                    alert_type="metrics_drift_batch",
                    severity=severity_emoji,
                    severity_level=highest_severity.value,
                    title=title,
                    message=message,
                    affected_resources=[
                        {
                            "metric_type": d.metric_type,
                            "resource_id": d.resource_id,
                            "metric_name": d.metric_name,
                            "current_value": d.current_value,
                            "baseline_avg": d.baseline_avg,
                            "z_score": d.z_score,
                            "severity": d.severity.value,
                        }
                        for d in drifts
                    ],
                    action_required=highest_severity
                    in (DriftSeverity.CRITICAL, DriftSeverity.HIGH),
                    metadata={
                        "total_drifts": len(drifts),
                        "by_severity": severity_counts,
                    },
                )
                self.event_publisher.publish_event(event, "Metrics Drift Detected")
                logger.info("EventBridge event published (Mock mode)")
            else:
                # Production 모드: 내부 알림 시스템 형식
                kakao_channel = None
                if send_kakao:
                    kakao_channel = KakaoChannel(
                        severity="MAJOR",
                        category1=get_environment_account_name().upper(),
                        message=f"{title}\n{message}",
                    )

                # HTML 리포트 생성
                html_message = self._generate_html_message(
                    drifts,
                    title,
                    severity_counts,
                    node_group_statuses=node_group_statuses or [],
                    node_summaries=node_summaries or {},
                )

                env_label = self._get_environment_label()
                env_prefix = f"[{env_label}] " if env_label else ""

                detail = ProductionAlertDetail(
                    subject=f"{severity_emoji} {env_prefix}{title}",
                    account_id=get_environment_account_name(),
                    email=EmailChannel(
                        to=email_to,
                        cc=email_cc,
                        from_email="alert-metrics@hcs.com",
                        message=html_message,
                    ),
                    kakao=kakao_channel,
                )
                self.event_publisher.publish_production_event(detail, "Metrics Drift Detected")
                logger.info("EventBridge event published (Production mode)")

        except Exception as e:
            logger.error(f"Failed to publish EventBridge event: {e}")

    def _get_environment_label(self) -> str:
        """ENVIRONMENT 환경변수 기반 환경명 반환."""
        env = os.getenv("ENVIRONMENT", "").lower()
        env_labels = {
            "test": "로컬테스트",
            "dev": "개발계",
            "prd": "운영계",
            "prod": "운영계",
        }
        return env_labels.get(env, env.upper() if env else "")

    def _generate_html_message(
        self,
        drifts: list[MetricDrift],
        title: str,
        severity_counts: dict[str, int],
        node_group_statuses: list[NodeGroupStatus] | None = None,
        node_summaries: dict[str, NodeSummary] | None = None,
    ) -> str:
        """HTML 형식의 이메일 메시지 생성 (계층형 EKS 뷰 포함).

        Args:
            drifts: MetricDrift 목록
            title: 알림 제목
            severity_counts: 심각도별 카운트
            node_group_statuses: 노드그룹 상태 목록
            node_summaries: 노드 요약 딕셔너리

        Returns:
            HTML 문자열
        """
        node_group_statuses = node_group_statuses or []
        node_summaries = node_summaries or {}

        # ── 스타일 상수 (폰트 계층: h2=20, h3=16, body=13, table=12, sub=10) ──
        SEVERITY_COLORS = {
            "critical": "#dc3545",
            "high": "#fd7e14",
            "medium": "#ffc107",
            "low": "#28a745",
        }
        S_CELL = "padding: 6px 8px; border: 1px solid #dee2e6; font-size: 12px;"
        S_HEADER = "padding: 8px; border: 1px solid #dee2e6; text-align: left; font-size: 12px; font-weight: bold;"

        # ── 환경명: 제목(subject)에 이미 포함되므로 헤더에는 표시하지 않음 ──
        env_badge = ""

        # ── EKS / 비-EKS drift 분리 ──
        eks_types = {"eks-pod", "eks-node", "eks-nodegroup"}
        eks_drifts = [d for d in drifts if d.metric_type in eks_types]
        other_drifts = [d for d in drifts if d.metric_type not in eks_types]

        # ── 영역 × 심각도 크로스 테이블 ──
        AREA_LABELS = [
            ("eks-nodegroup", "NodeGroup"),
            ("eks-node", "Node"),
            ("eks-pod", "Pod"),
            ("mwaa", "MWAA"),
            ("msk", "MSK"),
            ("subnet-ip", "Subnet-IP"),
            ("service-quota", "Service Quota"),
        ]
        SEVERITIES = ["critical", "high", "medium", "low"]
        SEV_HEADERS = {"critical": "CRITICAL", "high": "HIGH", "medium": "MEDIUM", "low": "LOW"}

        cross: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        for d in drifts:
            cross[d.metric_type][d.severity.value] += 1
        active_areas = [(mtype, label) for mtype, label in AREA_LABELS if cross.get(mtype)]

        sections = []

        # ① 요약 헤더
        sections.append(f"""
        <h2 style="font-size: 20px; color: #333; margin: 0 0 8px;">{title}{env_badge}</h2>
        <p style="font-size: 13px; color: #444; margin: 0 0 4px;">
            총 <strong>{len(drifts)}건</strong>의 메트릭 Drift가 탐지되었습니다.
        </p>
        <p style="font-size: 13px; margin: 0 0 8px;">
            <strong style="color: #dc3545;">CRITICAL {severity_counts["critical"]}</strong> &middot;
            <strong style="color: #fd7e14;">HIGH {severity_counts["high"]}</strong> &middot;
            <strong style="color: #ffc107;">MEDIUM {severity_counts["medium"]}</strong> &middot;
            <strong style="color: #28a745;">LOW {severity_counts["low"]}</strong>
        </p>
        """)

        # 크로스 테이블 (영역 × 심각도)
        if active_areas:
            ct_header = "".join(
                f'<th style="{S_CELL} background-color: #f5f5f5; text-align: center; '
                f'color: {SEVERITY_COLORS[s]}; font-weight: bold; font-size: 11px;">'
                f"{SEV_HEADERS[s]}</th>"
                for s in SEVERITIES
            )

            ct_rows = ""
            col_totals: dict[str, int] = defaultdict(int)
            for mtype, label in active_areas:
                row_total = sum(cross[mtype][s] for s in SEVERITIES)
                cells = ""
                for s in SEVERITIES:
                    cnt = cross[mtype][s]
                    col_totals[s] += cnt
                    if cnt > 0:
                        cell_style = (
                            f"text-align: center; color: {SEVERITY_COLORS[s]}; font-weight: bold;"
                        )
                    else:
                        cell_style = "text-align: center; color: #cccccc;"
                    cells += f'<td style="{S_CELL} {cell_style}">{cnt}</td>'
                ct_rows += (
                    f"<tr>"
                    f'<td style="{S_CELL} font-weight: bold;">{label}</td>'
                    f"{cells}"
                    f'<td style="{S_CELL} text-align: center; font-weight: bold;">{row_total}</td>'
                    f"</tr>"
                )

            grand_total = sum(col_totals[s] for s in SEVERITIES)
            total_cells = "".join(
                f'<td style="{S_CELL} text-align: center; font-weight: bold; '
                f'background-color: #f5f5f5;">{col_totals[s]}</td>'
                for s in SEVERITIES
            )
            ct_rows += (
                f"<tr>"
                f'<td style="{S_CELL} font-weight: bold; background-color: #f5f5f5;">합계</td>'
                f"{total_cells}"
                f'<td style="{S_CELL} text-align: center; font-weight: bold; '
                f'background-color: #f5f5f5;">{grand_total}</td>'
                f"</tr>"
            )

            sections.append(f"""
            <table style="border-collapse: collapse; width: 100%; margin: 4px 0 12px;">
                <thead><tr style="background-color: #f5f5f5;">
                    <th style="{S_CELL} font-weight: bold; font-size: 11px;">영역</th>
                    {ct_header}
                    <th style="{S_CELL} background-color: #f5f5f5; text-align: center;
                        font-weight: bold; font-size: 11px;">합계</th>
                </tr></thead>
                <tbody>{ct_rows}</tbody>
            </table>
            """)

        # ② 노드그룹 이상
        ng_drifts = [d for d in eks_drifts if d.metric_type == "eks-nodegroup"]
        if ng_drifts:
            ng_rows = ""
            for d in ng_drifts:
                sev_color = SEVERITY_COLORS.get(d.severity.value, "#6c757d")
                ng_rows += f"""
                <tr>
                    <td style="{S_CELL}">{d.resource_id}</td>
                    <td style="{S_CELL}">{d.metric_name}</td>
                    <td style="{S_CELL}">{d.description or ""}</td>
                    <td style="{S_CELL} color: {sev_color}; font-weight: bold;">
                        {self._get_severity_emoji(d.severity)} {d.severity.value.upper()}
                    </td>
                </tr>
                """
            sections.append(f"""
            <h3 style="font-size: 16px; color: #333; margin: 20px 0 8px;">NodeGroup Issues</h3>
            <table style="border-collapse: collapse; width: 100%;">
                <thead><tr style="background-color: #fff3cd;">
                    <th style="{S_HEADER}">NodeGroup</th>
                    <th style="{S_HEADER}">Item</th>
                    <th style="{S_HEADER}">Description</th>
                    <th style="{S_HEADER}">Severity</th>
                </tr></thead>
                <tbody>{ng_rows}</tbody>
            </table>
            """)

        # ③ EKS 계층 뷰
        node_pod_drifts = [d for d in eks_drifts if d.metric_type in ("eks-node", "eks-pod")]
        if node_pod_drifts:
            by_ng = defaultdict(lambda: defaultdict(list))
            for d in node_pod_drifts:
                ng = d.node_group_name or "미분류"
                node = d.node_name or ("" if d.metric_type == "eks-nodegroup" else "미분류")
                by_ng[ng][node].append(d)

            ng_status_map = {s.nodegroup_name: s for s in node_group_statuses}
            nodes_with_drift = set()
            for d in node_pod_drifts:
                if d.metric_type == "eks-node" and d.node_name:
                    nodes_with_drift.add(d.node_name)

            hierarchy_html = (
                '<h3 style="font-size: 16px; color: #333; margin: 20px 0 8px;">EKS 계층 뷰</h3>'
            )

            for ng_name in sorted(by_ng.keys()):
                nodes_map = by_ng[ng_name]
                ng_status = ng_status_map.get(ng_name)

                if ng_status:
                    instance_types = (
                        ", ".join(ng_status.instance_types) if ng_status.instance_types else "?"
                    )
                    ng_header_info = (
                        f"{instance_types} | "
                        f"{ng_status.current_size}/{ng_status.desired_size} Ready | "
                        f"스케일 {ng_status.min_size}→{ng_status.max_size}"
                    )
                    ng_nodes_summaries = [
                        ns for ns in node_summaries.values() if ns.node_group_name == ng_name
                    ]
                    avg_parts = []
                    cpu_vals = [
                        n.cpu_percent for n in ng_nodes_summaries if n.cpu_percent is not None
                    ]
                    mem_vals = [
                        n.memory_percent for n in ng_nodes_summaries if n.memory_percent is not None
                    ]
                    disk_vals = [
                        n.disk_percent for n in ng_nodes_summaries if n.disk_percent is not None
                    ]
                    if cpu_vals:
                        avg_parts.append(f"CPU {sum(cpu_vals) / len(cpu_vals):.0f}%")
                    if mem_vals:
                        avg_parts.append(f"Mem {sum(mem_vals) / len(mem_vals):.0f}%")
                    if disk_vals:
                        avg_parts.append(f"Disk {sum(disk_vals) / len(disk_vals):.0f}%")
                    avg_line = f" &middot; 평균 {' | '.join(avg_parts)}" if avg_parts else ""
                else:
                    ng_header_info = ""
                    avg_line = ""

                hierarchy_html += f"""
                <div style="margin: 12px 0; padding: 10px; background: #e9ecef; border-radius: 6px;">
                    <strong style="font-size: 14px;">━━ {ng_name}</strong>
                    <span style="font-size: 11px; color: #555;"> ({ng_header_info}{avg_line})</span>
                </div>
                """

                for node_name in sorted(nodes_map.keys()):
                    node_drifts = nodes_map[node_name]
                    ns = node_summaries.get(node_name)

                    if ns:
                        cpu_str = (
                            f"CPU {ns.cpu_percent:.0f}%" if ns.cpu_percent is not None else "CPU ?"
                        )
                        mem_str = (
                            f"Mem {ns.memory_percent:.0f}%"
                            if ns.memory_percent is not None
                            else "Mem ?"
                        )
                        pod_str = (
                            f"Pods {ns.pod_count}/{ns.max_pods}" if ns.pod_count is not None else ""
                        )
                        node_has_drift = node_name in nodes_with_drift
                        status_icon = "&#9888;&#65039;" if node_has_drift else "&#10003;"
                        node_header = f"{cpu_str} {status_icon} | {mem_str} | {pod_str}"
                    else:
                        node_header = ""

                    hierarchy_html += f"""
                    <div style="margin: 6px 0 6px 20px; padding: 8px; background: #f8f9fa; border-left: 3px solid #007bff; border-radius: 4px;">
                        <strong style="font-size: 13px;">&#128205; {node_name}</strong>
                        <span style="font-size: 11px; color: #555;"> ({node_header})</span>
                    """

                    drift_rows = ""
                    for d in node_drifts:
                        sev_color = SEVERITY_COLORS.get(d.severity.value, "#6c757d")
                        resource_label = (
                            d.resource_id if d.metric_type == "eks-pod" else "(Node itself)"
                        )
                        drift_rows += f"""
                        <tr>
                            <td style="{S_CELL}">{d.metric_type}</td>
                            <td style="{S_CELL}">{resource_label}</td>
                            <td style="{S_CELL}">{d.metric_name}</td>
                            <td style="{S_CELL}">{d.current_value:.2f}</td>
                            <td style="{S_CELL}">{f"{d.baseline_avg:.2f}" if d.baseline_avg else "-"}</td>
                            <td style="{S_CELL} color: {sev_color}; font-weight: bold;">
                                {self._get_severity_emoji(d.severity)} {d.severity.value.upper()}
                            </td>
                        </tr>
                        """

                    eks_charts_html = ""
                    for d in node_drifts:
                        chart = self._generate_drift_chart(d)
                        if chart:
                            eks_charts_html += chart

                    hierarchy_html += f"""
                        <table style="border-collapse: collapse; width: 100%; margin-top: 6px;">
                            <thead><tr style="background-color: #e9ecef;">
                                <th style="{S_HEADER}">Type</th>
                                <th style="{S_HEADER}">Resource</th>
                                <th style="{S_HEADER}">Metric</th>
                                <th style="{S_HEADER}">Current</th>
                                <th style="{S_HEADER}">Baseline</th>
                                <th style="{S_HEADER}">Severity</th>
                            </tr></thead>
                            <tbody>{drift_rows}</tbody>
                        </table>
                        {eks_charts_html}
                    """

                    pod_drifts_here = [d for d in node_drifts if d.metric_type == "eks-pod"]
                    if pod_drifts_here and node_name in nodes_with_drift:
                        hierarchy_html += """
                        <p style="color: #dc3545; font-size: 11px; margin: 4px 0 0;">
                            &#128161; Node CPU/Mem also high → <strong>Node overload likely</strong> (consider scale-out)
                        </p>
                        """
                    elif pod_drifts_here:
                        hierarchy_html += """
                        <p style="color: #007bff; font-size: 11px; margin: 4px 0 0;">
                            &#128161; Node normal → <strong>Pod-only anomaly</strong> (check app-level)
                        </p>
                        """

                    hierarchy_html += "</div>"

            sections.append(hierarchy_html)

        # ④ 비-EKS 메트릭 (metric_type별 분리 테이블)
        INFRA_SECTION_META = {
            "msk": {"title": "MSK 클러스터 메트릭", "icon": "📊", "bg": "#e8f5e9"},
            "mwaa": {"title": "MWAA 환경 메트릭", "icon": "🌀", "bg": "#e3f2fd"},
            "subnet-ip": {"title": "서브넷 IP 사용률", "icon": "🌐", "bg": "#fff3e0"},
            "service-quota": {"title": "서비스 쿼터", "icon": "📋", "bg": "#f3e5f5"},
        }

        if other_drifts:
            infra_groups: dict[str, list[MetricDrift]] = defaultdict(list)
            for d in other_drifts:
                infra_groups[d.metric_type].append(d)

            for mtype, meta in INFRA_SECTION_META.items():
                group = infra_groups.get(mtype)
                if not group:
                    continue

                group_rows = ""
                for d in group:
                    sev_color = SEVERITY_COLORS.get(d.severity.value, "#6c757d")
                    group_rows += f"""
                    <tr>
                        <td style="{S_CELL}">{d.display_name}</td>
                        <td style="{S_CELL}">{d.metric_name}</td>
                        <td style="{S_CELL}">{d.current_value:.2f}</td>
                        <td style="{S_CELL}">{f"{d.baseline_avg:.2f}" if d.baseline_avg else "-"}</td>
                        <td style="{S_CELL}">{f"{d.z_score:.2f}" if d.threshold_type == "z_score" else "-"}</td>
                        <td style="{S_CELL} color: {sev_color}; font-weight: bold;">
                            {self._get_severity_emoji(d.severity)} {d.severity.value.upper()}
                        </td>
                    </tr>
                    """

                charts_html = ""
                for d in group:
                    chart = self._generate_drift_chart(d)
                    if chart:
                        charts_html += chart

                sections.append(f"""
                <h3 style="font-size: 16px; color: #333; margin: 20px 0 8px;">{meta["icon"]} {meta["title"]}</h3>
                <table style="border-collapse: collapse; width: 100%; margin-top: 6px;">
                    <thead><tr style="background-color: {meta["bg"]};">
                        <th style="{S_HEADER}">Resource</th>
                        <th style="{S_HEADER}">Metric</th>
                        <th style="{S_HEADER}">Current</th>
                        <th style="{S_HEADER}">Baseline</th>
                        <th style="{S_HEADER}">Z-Score</th>
                        <th style="{S_HEADER}">Severity</th>
                    </tr></thead>
                    <tbody>{group_rows}</tbody>
                </table>
                {charts_html}
                """)

        # 타임스탬프
        sections.append(f"""
        <p style="margin-top: 16px; color: #999; font-size: 10px;">
            탐지 시간: {datetime.now(KST).isoformat()}
        </p>
        """)

        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; font-size: 13px; color: #333333; margin: 0; padding: 20px; max-width: 800px; background-color: #ffffff;">
            {"".join(sections)}
        </body>
        </html>
        """

    def _generate_drift_chart(self, drift: MetricDrift) -> str:
        """drift 메트릭의 SVG 차트 생성.

        시계열 data_points가 있는 메트릭만 라인 차트 생성.
        subnet-ip 등 스냅샷 메트릭은 인라인 바 차트.

        Returns:
            HTML 문자열 (SVG 포함) 또는 빈 문자열
        """
        chart_gen = SVGChartGenerator()

        # subnet-ip: 바 차트
        if drift.metric_type == "subnet-ip":
            sev_colors = {
                "critical": "#dc3545",
                "high": "#fd7e14",
                "medium": "#ffc107",
                "low": "#28a745",
            }
            return chart_gen.generate_bar_inline(
                label=drift.display_name,
                value=drift.current_value,
                severity_color=sev_colors.get(drift.severity.value, "#ffc107"),
            )

        # 시계열 데이터가 있는 경우 라인 차트
        if not drift.data_points or len(drift.data_points) < 2:
            return ""

        chart_points = [
            ChartDataPoint(timestamp=dp.timestamp, value=dp.value) for dp in drift.data_points
        ]

        # 임계값 라인 구성
        thresholds = []
        if drift.threshold_type == "absolute" and drift.threshold_value:
            thresholds.append(
                ThresholdLine(
                    value=drift.threshold_value,
                    label=f"{drift.severity.value.upper()}",
                    color="#dc3545" if drift.severity == DriftSeverity.CRITICAL else "#fd7e14",
                )
            )

        title = f"{drift.display_name} - {drift.metric_name}"
        unit = ""
        if drift.metric_type in ("mwaa", "msk", "eks-node", "eks-pod"):
            unit = "%"

        svg = chart_gen.generate_line_chart(
            data_points=chart_points,
            title=title,
            unit=unit,
            thresholds=thresholds,
            show_average=True,
        )
        if svg:
            return f'<div style="margin: 8px 0;">{svg}</div>'
        return ""

    def _generate_daily_report(self, event: dict[str, Any]) -> dict[str, Any]:
        """메트릭 일간 리포트 생성.

        현재 탐지 결과를 기반으로 HTML 리포트를 생성합니다.
        """
        from pathlib import Path

        from .services.daily_report_generator import (
            DailyDriftItem,
            MetricsDailyReportData,
            MetricsDailyReportGenerator,
        )

        output_dir = event.get("output_dir", "reports/")
        resource_types = event.get("resource_types", ["subnet-ip"])

        # 탐지 실행
        detect_event = {**event, "publish_alerts": False}
        detect_result = self._detect_drift(detect_event)

        drifts = detect_result.get("drifts", [])
        severity_counts = detect_result.get("summary", {}).get("by_severity", {})

        # DailyDriftItem 변환
        drift_items = []
        type_counts = defaultdict(int)
        for d in drifts:
            type_counts[d.get("metric_type", "")] += 1
            drift_items.append(
                DailyDriftItem(
                    metric_type=d.get("metric_type", ""),
                    resource_id=d.get("resource_id", ""),
                    metric_name=d.get("metric_name", ""),
                    current_value=d.get("current_value", 0),
                    baseline_avg=d.get("baseline_avg", 0),
                    baseline_stddev=d.get("baseline_stddev", 0),
                    z_score=d.get("z_score", 0),
                    severity=d.get("severity", "low"),
                )
            )

        report_data = MetricsDailyReportData(
            report_date=datetime.now(KST).strftime("%Y-%m-%d"),
            account_name=os.getenv("ENVIRONMENT", "test"),
            total_drifts=len(drifts),
            severity_counts=severity_counts,
            type_counts=dict(type_counts),
            drifts=drift_items,
        )

        # 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        report_path = str(output_path / "metrics_daily_report.html")

        generator = MetricsDailyReportGenerator()
        generator.generate_report(report_data, report_path)

        return {
            "status": "success",
            "action": "daily_report",
            "report_path": report_path,
            "summary": {
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
        }

    def _run_e2e(self, event: dict[str, Any]) -> dict[str, Any]:
        """E2E 시나리오 테스트 실행."""
        from .services.e2e_runner import MetricsE2ERunner

        output_dir = event.get("output_dir", "reports/")

        runner = MetricsE2ERunner()
        result = runner.run_all(output_dir=output_dir)

        return {
            "status": "success",
            "action": "e2e",
            "pass_rate": result.pass_rate,
            "passed": result.passed,
            "failed": result.failed,
            "total": result.total,
            "report_path": result.e2e_report_path,
        }

    def _update_baselines(self, event: dict[str, Any]) -> dict[str, Any]:
        """메트릭 baseline 업데이트.

        Args:
            event: 이벤트 페이로드
                - resource_types: 대상 리소스 타입
                - resource_ids: 대상 리소스 ID
                - duration_hours: baseline 계산 기간 (기본 168 = 7일)

        Returns:
            업데이트 결과
        """
        resource_types = event.get("resource_types", ["subnet-ip"])
        resource_ids = event.get("resource_ids")
        duration_hours = event.get("duration_hours", 168)  # 7일

        updated_count = 0
        failed_count = 0

        if "msk" in resource_types:
            clusters = resource_ids or self.msk_fetcher.list_clusters()

            for cluster_name in clusters:
                try:
                    # 지정된 기간 동안의 메트릭 조회
                    metrics = self.msk_fetcher.fetch_metrics(
                        cluster_name=cluster_name,
                        duration_hours=duration_hours,
                    )

                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue

                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="msk",
                            resource_id=cluster_name,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )

                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "msk", cluster_name, metric_name, values, timestamps
                        )

                except Exception as e:
                    logger.error(f"Failed to update baseline for {cluster_name}: {e}")
                    failed_count += 1

        # MWAA baseline 업데이트
        if "mwaa" in resource_types:
            env_name = event.get("mwaa_environment_name") or self.mwaa_environment_name
            if env_name:
                try:
                    metrics = self.mwaa_fetcher.fetch_metrics(
                        environment_name=env_name,
                        duration_hours=duration_hours,
                    )

                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue

                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="mwaa",
                            resource_id=env_name,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )

                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "mwaa", env_name, metric_name, values, timestamps
                        )

                except Exception as e:
                    logger.error(f"Failed to update baseline for MWAA {env_name}: {e}")
                    failed_count += 1
            else:
                logger.warning("MWAA environment name not set, skipping MWAA baselines")

        # Subnet-IP baseline 업데이트
        if "subnet-ip" in resource_types:
            try:
                usages = self.subnet_fetcher.fetch_subnet_usage()
                for usage in usages:
                    from .services.models import MetricBaseline

                    baseline = MetricBaseline(
                        metric_type="subnet-ip",
                        resource_id=usage.subnet_id,
                        metric_name="ip_utilization",
                        baseline_avg=usage.utilization_percent,
                        baseline_stddev=0,  # 시점 스냅샷이므로 stddev 불가
                        baseline_min=usage.utilization_percent,
                        baseline_max=usage.utilization_percent,
                        sample_count=1,
                        period_hours=0,
                        created_at=datetime.now(KST),
                    )

                    if self.baseline_store.save_baseline(baseline):
                        updated_count += 1
                    else:
                        failed_count += 1

            except Exception as e:
                logger.error(f"Failed to update subnet-ip baselines: {e}")
                failed_count += 1

        # EKS 라우팅
        run_eks_node = "eks" in resource_types or "eks-node" in resource_types
        run_eks_pod = "eks" in resource_types or "eks-pod" in resource_types

        if run_eks_node:
            nodes = self.eks_node_fetcher.list_nodes()

            for node_info in nodes:
                node_name = node_info["NodeName"]
                instance_id = node_info.get("InstanceId", "")
                try:
                    metrics = self.eks_node_fetcher.fetch_metrics(
                        node_name=node_name,
                        instance_id=instance_id,
                        duration_hours=duration_hours,
                    )

                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue

                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="eks-node",
                            resource_id=node_name,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )

                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "eks-node", node_name, metric_name, values, timestamps
                        )

                except Exception as e:
                    logger.error(f"Failed to update baseline for node {node_name}: {e}")
                    failed_count += 1

        if run_eks_pod:
            pods = self.eks_pod_fetcher.list_pods()

            for pod_info in pods:
                pod_name = pod_info["PodName"]
                namespace = pod_info["Namespace"]
                resource_id = f"{namespace}/{pod_name}"
                try:
                    metrics = self.eks_pod_fetcher.fetch_metrics(
                        pod_name=pod_name,
                        namespace=namespace,
                        duration_hours=duration_hours,
                    )

                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue

                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="eks-pod",
                            resource_id=resource_id,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )

                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "eks-pod", resource_id, metric_name, values, timestamps
                        )

                except Exception as e:
                    logger.error(f"Failed to update baseline for {resource_id}: {e}")
                    failed_count += 1

        # RDS baseline 업데이트
        if "rds" in resource_types:
            instances = resource_ids or self.rds_fetcher.list_instances()
            for db_instance_id in instances:
                try:
                    metrics = self.rds_fetcher.fetch_metrics(
                        db_instance_id=db_instance_id,
                        duration_hours=duration_hours,
                    )
                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue
                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="rds",
                            resource_id=db_instance_id,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )
                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "rds", db_instance_id, metric_name, values, timestamps
                        )
                except Exception as e:
                    logger.error(f"Failed to update baseline for RDS {db_instance_id}: {e}")
                    failed_count += 1

        # SageMaker Endpoint baseline 업데이트
        if "sagemaker-endpoint" in resource_types:
            endpoints = resource_ids or self.sagemaker_endpoint_fetcher.list_endpoints()
            for endpoint_name in endpoints:
                try:
                    metrics = self.sagemaker_endpoint_fetcher.fetch_metrics(
                        endpoint_name=endpoint_name,
                        duration_hours=duration_hours,
                    )
                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue
                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="sagemaker-endpoint",
                            resource_id=endpoint_name,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )
                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "sagemaker-endpoint", endpoint_name, metric_name, values, timestamps
                        )
                except Exception as e:
                    logger.error(f"Failed to update baseline for SageMaker {endpoint_name}: {e}")
                    failed_count += 1

        # EMR Cluster baseline 업데이트
        if "emr-cluster" in resource_types:
            clusters = resource_ids or self.emr_cluster_fetcher.list_clusters()
            for cluster_id in clusters:
                try:
                    metrics = self.emr_cluster_fetcher.fetch_metrics(
                        cluster_id=cluster_id,
                        duration_hours=duration_hours,
                    )
                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue
                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="emr-cluster",
                            resource_id=cluster_id,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )
                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "emr-cluster", cluster_id, metric_name, values, timestamps
                        )
                except Exception as e:
                    logger.error(f"Failed to update baseline for EMR cluster {cluster_id}: {e}")
                    failed_count += 1

        # EMR Serverless baseline 업데이트
        if "emr-serverless" in resource_types:
            applications = resource_ids or self.emr_serverless_fetcher.list_applications()
            for application_id in applications:
                try:
                    metrics = self.emr_serverless_fetcher.fetch_metrics(
                        application_id=application_id,
                        duration_hours=duration_hours,
                    )
                    for metric_name, result in metrics.items():
                        if not result.data_points:
                            continue
                        values = [dp.value for dp in result.data_points]
                        timestamps = [
                            dp.timestamp.isoformat()
                            if hasattr(dp.timestamp, "isoformat")
                            else str(dp.timestamp)
                            for dp in result.data_points
                        ]
                        avg = sum(values) / len(values)
                        variance = sum((v - avg) ** 2 for v in values) / len(values)
                        stddev = variance**0.5

                        from .services.models import MetricBaseline

                        baseline = MetricBaseline(
                            metric_type="emr-serverless",
                            resource_id=application_id,
                            metric_name=metric_name,
                            baseline_avg=avg,
                            baseline_stddev=stddev,
                            baseline_min=min(values),
                            baseline_max=max(values),
                            sample_count=len(values),
                            period_hours=duration_hours,
                            created_at=datetime.now(KST),
                        )
                        if self.baseline_store.save_baseline(baseline):
                            updated_count += 1
                        else:
                            failed_count += 1

                        # ECOD 앙상블 탐지용 historical data 저장
                        self.baseline_store.save_historical_data(
                            "emr-serverless", application_id, metric_name, values, timestamps
                        )
                except Exception as e:
                    logger.error(
                        f"Failed to update baseline for EMR Serverless {application_id}: {e}"
                    )
                    failed_count += 1

        return {
            "status": "success" if failed_count == 0 else "partial",
            "timestamp": datetime.now(KST).isoformat(),
            "action": "update_baselines",
            "summary": {
                "updated": updated_count,
                "failed": failed_count,
            },
        }

    def _build_response(self, drifts: list[MetricDrift]) -> dict[str, Any]:
        """응답 생성."""
        severity_counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        for drift in drifts:
            severity_counts[drift.severity.value] += 1

        return {
            "status": "success",
            "timestamp": datetime.now(KST).isoformat(),
            "summary": {
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
            "drifts": [d.to_dict() for d in drifts],
        }


# Lambda 핸들러
_handler_instance: BDPMetricsHandler | None = None


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda 핸들러 함수.

    Args:
        event: Lambda 이벤트
        context: Lambda 컨텍스트

    Returns:
        탐지 결과
    """
    global _handler_instance

    if _handler_instance is None:
        _handler_instance = BDPMetricsHandler()

    return _handler_instance.process(event)


if __name__ == "__main__":
    # 로컬 테스트
    import json

    result = handler(
        {
            "action": "detect",
            "resource_types": [
                "msk",
                "mwaa",
                "subnet-ip",
                "service-quota",
                "eks",
                "rds",
                "sagemaker-endpoint",
                "emr-cluster",
                "emr-serverless",
            ],
        },
        None,
    )
    print(json.dumps(result, indent=2, default=str))
