"""
BDP Airflow Agent - Airflow(MWAA) Failure Pattern Detection.

Airflow DAG/Task 실패 패턴 탐지, 전조증상 분석, Cross-DAG 상관관계 분석
및 EventBridge → KakaoTalk 알림 발송 에이전트.
"""

from src.agent_server.bdp_airflow.handler import BDPAirflowHandler, handler

__all__ = ["BDPAirflowHandler", "handler"]
