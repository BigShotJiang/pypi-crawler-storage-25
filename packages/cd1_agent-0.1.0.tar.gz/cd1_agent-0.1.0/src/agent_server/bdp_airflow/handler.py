"""
BDP Airflow Handler for Failure Pattern Detection.

Lambda/FastAPI 핸들러 - Airflow(MWAA) DAG/Task 실패 패턴 탐지
및 KakaoTalk 알람 발송.
"""

import os
from typing import Any

from src.agent_server.bdp_airflow.services.airflow_failure_store import (
    AirflowFailureStore,
    AirflowFailureStoreProvider,
)
from src.agent_server.bdp_airflow.services.cross_dag_analyzer import CrossDagAnalyzer
from src.agent_server.bdp_airflow.services.event_publisher import AirflowEventPublisher
from src.agent_server.bdp_airflow.services.failure_detector import AirflowFailureDetector
from src.agent_server.bdp_airflow.services.log_analyzer import AirflowLogAnalyzer
from src.agent_server.bdp_airflow.services.models import (
    AirflowAnalysisResult,
    AirflowFailureRecord,
    FailurePattern,
)
from src.agent_server.bdp_airflow.services.op_kwargs_analyzer import OpKwargsAnalyzer
from src.agent_server.bdp_airflow.services.precursor_analyzer import PrecursorAnalyzer
from src.agent_server.bdp_airflow.services.summary_generator import AirflowSummaryGenerator
from src.agent_server.bdp_common.deep_agent import (
    DeepAgentExecutor,
    DetectionInput,
    DetectionItem,
)
from src.agent_server.bdp_common.deep_agent.tools import create_investigation_tools
from src.common.handlers.base_handler import BaseHandler
from src.common.timezone import get_kst_now


class BDPAirflowHandler(BaseHandler):
    """
    BDP Airflow 실패 패턴 탐지 핸들러.

    Airflow(MWAA) DAG/Task 실패 데이터를 분석하여 패턴을 탐지하고,
    EventBridge를 통해 KakaoTalk 알람을 발송합니다.

    Features:
    - RDS(MySQL) 기반 실패 데이터 조회
    - 빈도/시간/캐스케이딩/Duration 이상 탐지
    - 전조증상 분석
    - op_kwargs 기반 공통 실패 특징 추출
    - Cross-DAG 상관관계 분석
    - 한글 Rich Summary 생성
    - EventBridge → KakaoTalk 알람
    """

    def __init__(self):
        super().__init__("BDPAirflowHandler")
        self._init_services()

    def _init_services(self) -> None:
        """서비스 컴포넌트 초기화."""
        # Provider 설정
        provider_type = os.getenv("BDP_PROVIDER", "mock")
        self.provider: AirflowFailureStoreProvider = AirflowFailureStore.create_provider(
            provider_type=provider_type,
            secret_id=os.getenv("MWAA_SECRET_ID", ""),
            db=os.getenv("MWAA_DB_NAME", ""),
        )

        # rcpt_tp 필터 값
        rcpt_types = os.getenv("MWAA_RCPT_TYPES", "dlk,wfl")
        self.rcpt_types = [t.strip() for t in rcpt_types.split(",") if t.strip()]

        # Detector 설정
        self.failure_detector = AirflowFailureDetector()
        self.precursor_analyzer = PrecursorAnalyzer()
        self.op_kwargs_analyzer = OpKwargsAnalyzer()
        self.cross_dag_analyzer = CrossDagAnalyzer()

        # Log Analyzer 설정
        log_provider = os.getenv("LOG_PROVIDER", "mock")
        self.log_analyzer = AirflowLogAnalyzer(use_mock=log_provider == "mock")

        # Summary Generator
        self.summary_generator = AirflowSummaryGenerator()

        # Remediation Engine
        from src.agent_server.bdp_airflow.services.remediation_engine import RemediationEngine

        self.remediation_engine = RemediationEngine(
            auto_execute_low_risk=os.getenv("AIRFLOW_AUTO_REMEDIATION", "true").lower() == "true",
            mwaa_environment=os.getenv("MWAA_ENVIRONMENT_NAME", ""),
        )

        # Event Publisher 설정
        event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.event_publisher = AirflowEventPublisher(
            event_bus=os.getenv("EVENT_BUS", "cd1-agent-events"),
            use_mock=event_provider == "mock",
        )

        # HITL Store 설정
        rds_provider = os.getenv("RDS_PROVIDER", "mock")
        self.hitl_store = HITLStore(provider=rds_provider)
        self.hitl_on_critical = os.getenv("AIRFLOW_HITL_ON_CRITICAL", "true").lower() == "true"

        self.logger.info(
            f"BDPAirflowHandler initialized: provider={provider_type}, rcpt_types={self.rcpt_types}"
        )

    def _validate_input(self, event: dict[str, Any]) -> str | None:
        """입력 검증."""
        return None

    def process(self, event: dict[str, Any], context: Any) -> dict[str, Any]:
        """실패 패턴 탐지/분석 실행.

        Args:
            event: Lambda 이벤트 또는 API 요청
            context: Lambda context

        Returns:
            탐지/분석 결과
        """
        body = self._parse_body(event)

        # action 라우팅
        action = body.get("action", event.get("action", "detect"))

        if action == "detect":
            return self._process_detect(body, event)
        elif action == "dag_detail":
            return self._process_dag_detail(body, event)
        elif action == "precursor_scan":
            return self._process_precursor_scan(body, event)
        elif action == "daily_report":
            return self._generate_daily_report(body, event)
        elif action == "e2e":
            return self._run_e2e(body, event)
        else:
            return {
                "status": "error",
                "message": (
                    f"Unknown action: {action}. "
                    "Valid actions: detect, dag_detail, precursor_scan, daily_report, e2e"
                ),
            }

    def _process_detect(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """전체 분석 파이프라인.

        1. Store에서 failures 조회 (both envs)
        2. failure_detector.analyze()
        3. precursor_analyzer.analyze()
        4. op_kwargs_analyzer.analyze()
        5. cross_dag_analyzer.analyze()
        6. summary_generator로 한글 요약 생성
        7. EventBridge 알림 발행
        """
        hours = int(body.get("hours", event.get("hours", 24)))
        publish_alerts = body.get("publish_alerts", event.get("publish_alerts", True))

        self.logger.info(f"실패 패턴 탐지 시작: hours={hours}, envs={self.rcpt_types}")

        # 1. 모든 환경에서 실패 데이터 조회
        all_failures: list[AirflowFailureRecord] = []
        for rcpt_tp in self.rcpt_types:
            failures = self.provider.get_failures(rcpt_tp=rcpt_tp, hours=hours)
            all_failures.extend(failures)
            self.logger.info(f"[{rcpt_tp}] {len(failures)}건 조회")

        # 히스토리 조회 (장기 추세용)
        all_history: list[AirflowFailureRecord] = []
        dag_ids = list({r.dag_id for r in all_failures})
        for dag_id in dag_ids[:50]:  # 상위 50개 DAG만
            history = self.provider.get_failure_history(dag_id=dag_id, days=7)
            all_history.extend(history)

        total_failures = sum(1 for r in all_failures if r.is_failed)
        self.logger.info(f"전체 {len(all_failures)}건 조회 (실패: {total_failures}건)")

        # 2. 실패 패턴 탐지
        patterns = self.failure_detector.analyze(all_failures, all_history)
        self.logger.info(f"패턴 탐지: {len(patterns)}건")

        # 3. 전조증상 분석
        precursors = self.precursor_analyzer.analyze(all_history)
        self.logger.info(f"전조증상: {len(precursors)}건")

        # 4. op_kwargs 클러스터링
        clusters = self.op_kwargs_analyzer.analyze(all_failures)
        self.logger.info(f"op_kwargs 클러스터: {len(clusters)}건")

        # 5. Cross-DAG 상관분석
        correlations = self.cross_dag_analyzer.analyze(all_failures)
        self.logger.info(f"Cross-DAG 상관관계: {len(correlations)}건")

        # 5.5 SLA 위반 예측
        sla_predictions = self.precursor_analyzer.predict_sla_violations(all_history)
        self.logger.info(f"SLA 위반 예측: {len(sla_predictions)}건")

        # 분석 결과 조합
        result = AirflowAnalysisResult(
            patterns=patterns,
            precursors=precursors,
            clusters=clusters,
            correlations=correlations,
            total_failures=total_failures,
            environments_analyzed=self.rcpt_types,
            analysis_window_hours=hours,
        )

        # 6. 한글 요약 생성
        summary = self.summary_generator.generate(result)
        result.summary = summary.message

        # 7. EventBridge 알림 발행
        if patterns and publish_alerts:
            self.logger.info("알림 발행 중...")
            self.event_publisher.publish_analysis_alert(result, summary)

        # 8. 자동 복구 분석 및 실행
        remediation_actions = self.remediation_engine.analyze_patterns(patterns)
        remediation_results = []
        if remediation_actions:
            remediation_results = self.remediation_engine.execute_low_risk(remediation_actions)
            self.logger.info(
                f"자동 복구: {len(remediation_results)}건 실행, "
                f"HITL 대기: {len(self.remediation_engine.get_hitl_actions(remediation_actions))}건"
            )

        # 9. 결과 반환
        detect_result = {
            "detection_type": "airflow_failure",
            "analysis_window_hours": hours,
            "environments_analyzed": self.rcpt_types,
            "total_records": len(all_failures),
            "total_failures": total_failures,
            "patterns_detected": len(patterns),
            "precursors_detected": len(precursors),
            "clusters_detected": len(clusters),
            "correlations_detected": len(correlations),
            "severity_breakdown": result.severity_counts,
            "summary": summary.message,
            "patterns": [self._pattern_to_dict(p) for p in patterns[:20]],
            "precursors": [self._precursor_to_dict(s) for s in precursors[:10]],
            "correlations": [self._correlation_to_dict(c) for c in correlations[:10]],
            "sla_predictions": sla_predictions[:10],
            "remediation": {
                "auto_executed": [
                    {
                        "action": r.action_type.value,
                        "dag_id": r.dag_id,
                        "success": r.success,
                        "message": r.message,
                    }
                    for r in remediation_results
                ],
                "pending_hitl": [
                    {
                        "action": a.action_type.value,
                        "dag_id": a.dag_id,
                        "risk_level": a.risk_level.value,
                        "description": a.description,
                    }
                    for a in self.remediation_engine.get_hitl_actions(remediation_actions)
                ],
            },
            "detection_timestamp": get_kst_now().isoformat(),
        }

        # 10. Deep Analysis (심각도 높을 때)
        return self._run_deep_analysis(detect_result)

    def _process_dag_detail(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """특정 DAG 상세 분석."""
        dag_id = body.get("dag_id", event.get("dag_id"))
        if not dag_id:
            return {"status": "error", "message": "dag_id is required"}

        days = int(body.get("days", event.get("days", 7)))

        self.logger.info(f"DAG 상세 분석: {dag_id}, days={days}")

        # 히스토리 조회
        history = self.provider.get_failure_history(dag_id=dag_id, days=days)

        # 패턴 탐지
        patterns = self.failure_detector.analyze(history, history)
        dag_patterns = [p for p in patterns if dag_id in p.affected_dags]

        # 전조증상
        precursors = self.precursor_analyzer.analyze(history)
        dag_precursors = [s for s in precursors if s.dag_id == dag_id]

        # DAG 요약
        summary = self.summary_generator.generate_dag_summary(dag_id, dag_patterns, dag_precursors)

        return {
            "dag_id": dag_id,
            "analysis_days": days,
            "total_records": len(history),
            "total_failures": sum(1 for r in history if r.is_failed),
            "patterns": [self._pattern_to_dict(p) for p in dag_patterns],
            "precursors": [self._precursor_to_dict(s) for s in dag_precursors],
            "summary": summary,
            "detection_timestamp": get_kst_now().isoformat(),
        }

    def _process_precursor_scan(
        self,
        body: dict[str, Any],
        event: dict[str, Any],
    ) -> dict[str, Any]:
        """전조증상 전용 스캔."""
        days = int(body.get("days", event.get("days", 7)))

        self.logger.info(f"전조증상 스캔: days={days}")

        # 전 환경 히스토리 조회
        all_history: list[AirflowFailureRecord] = []
        for rcpt_tp in self.rcpt_types:
            failures = self.provider.get_failures(rcpt_tp=rcpt_tp, hours=days * 24)
            all_history.extend(failures)

        # 전조증상 분석
        precursors = self.precursor_analyzer.analyze(all_history)

        return {
            "scan_type": "precursor",
            "analysis_days": days,
            "total_records": len(all_history),
            "precursors_detected": len(precursors),
            "precursors": [self._precursor_to_dict(s) for s in precursors],
            "detection_timestamp": get_kst_now().isoformat(),
        }

    def _generate_daily_report(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """Airflow 실패 패턴 일간 리포트 생성.

        포함 항목:
        - 당일 탐지 결과 요약
        - 전일 대비 추세 비교
        - 환경별(dlk/wfl) 건강도 점수
        - 반복 실패 Top-5 DAG
        - 전조증상 DAG 목록
        """
        hours = int(body.get("hours", event.get("hours", 24)))

        # 당일 탐지 실행
        detect_result = self._process_detect(body, event)

        # 전일 데이터 조회 (비교용)
        prev_body = {**body, "hours": hours}
        prev_failures_by_env: dict[str, list] = {}
        today_failures_by_env: dict[str, list] = {}

        for rcpt_tp in self.rcpt_types:
            today_records = self.provider.get_failures(rcpt_tp=rcpt_tp, hours=hours)
            prev_records = self.provider.get_failures(rcpt_tp=rcpt_tp, hours=hours * 2)
            # 전일 = 전체(48h) - 당일(24h)
            today_ids = {(r.dag_id, r.task_id, r.start_date) for r in today_records}
            prev_only = [
                r for r in prev_records if (r.dag_id, r.task_id, r.start_date) not in today_ids
            ]
            today_failures_by_env[rcpt_tp] = today_records
            prev_failures_by_env[rcpt_tp] = prev_only

        # 환경별 건강도 점수 (성공률 기반)
        env_health = {}
        for rcpt_tp in self.rcpt_types:
            today_recs = today_failures_by_env.get(rcpt_tp, [])
            total = len(today_recs)
            failed = sum(1 for r in today_recs if r.is_failed)
            success_rate = round((1 - failed / total) * 100, 1) if total > 0 else 100.0
            env_health[rcpt_tp] = {
                "total_records": total,
                "failed_count": failed,
                "success_rate": success_rate,
                "health_grade": (
                    "A"
                    if success_rate >= 95
                    else "B"
                    if success_rate >= 85
                    else "C"
                    if success_rate >= 70
                    else "D"
                    if success_rate >= 50
                    else "F"
                ),
            }

        # 전일 대비 추세
        today_total_failures = sum(h["failed_count"] for h in env_health.values())
        prev_total_failures = sum(
            sum(1 for r in recs if r.is_failed) for recs in prev_failures_by_env.values()
        )
        trend = {
            "today_failures": today_total_failures,
            "previous_failures": prev_total_failures,
            "change": today_total_failures - prev_total_failures,
            "direction": (
                "improved"
                if today_total_failures < prev_total_failures
                else "worsened"
                if today_total_failures > prev_total_failures
                else "stable"
            ),
        }

        # 반복 실패 Top-5 DAG
        dag_failure_counts: dict[str, int] = {}
        for recs in today_failures_by_env.values():
            for r in recs:
                if r.is_failed:
                    dag_failure_counts[r.dag_id] = dag_failure_counts.get(r.dag_id, 0) + 1
        top_failing_dags = sorted(dag_failure_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        # 전조증상 DAG 목록
        precursors = detect_result.get("precursors", [])
        precursor_dags = list({p.get("dag_id", "") for p in precursors if p.get("dag_id")})

        return {
            "status": "success",
            "action": "daily_report",
            "report_date": get_kst_now().strftime("%Y-%m-%d"),
            "summary": {
                "total_records": detect_result.get("total_records", 0),
                "total_failures": detect_result.get("total_failures", 0),
                "patterns_detected": detect_result.get("patterns_detected", 0),
                "severity_breakdown": detect_result.get("severity_breakdown", {}),
            },
            "trend_vs_previous": trend,
            "environment_health": env_health,
            "top_failing_dags": [
                {"dag_id": dag_id, "failure_count": count} for dag_id, count in top_failing_dags
            ],
            "precursor_warning_dags": precursor_dags,
            "detection_timestamp": get_kst_now().isoformat(),
        }

    def _run_e2e(self, body: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
        """E2E 시나리오 테스트 실행."""
        from src.agent_server.bdp_airflow.services.e2e_runner import AirflowE2ERunner

        output_dir = body.get("output_dir", event.get("output_dir", "reports/"))

        runner = AirflowE2ERunner()
        result = runner.run_all(output_dir=output_dir)

        return {
            "status": "success",
            "action": "e2e",
            "pass_rate": result.pass_rate,
            "passed": result.passed,
            "failed": result.failed,
            "total": result.total,
            "report_path": result.e2e_report_path,
            "daily_report_path": result.daily_report_path,
        }

    def _run_deep_analysis(self, detect_result: dict[str, Any]) -> dict[str, Any]:
        """심각도 높을 때 deep analysis 실행 + HITL 요청 생성."""
        severity = detect_result.get("severity_breakdown", {})
        if severity.get("critical", 0) > 0 or severity.get("high", 0) > 0:
            try:
                items = self._normalize_detection_items(detect_result)
                detection_input = DetectionInput(
                    agent_type="bdp_airflow",
                    detection_type=detect_result.get("detection_type", "airflow_failure"),
                    severity="critical" if severity.get("critical", 0) > 0 else "high",
                    summary=detect_result.get("summary", ""),
                    total_anomalies=detect_result.get("patterns_detected", 0),
                    severity_breakdown=severity,
                    items=items,
                )
                executor = DeepAgentExecutor(tools=create_investigation_tools("bdp_airflow"))
                result = executor.run(detection_input)
                detect_result["deep_analysis"] = result.model_dump()

                # HITL 요청 생성 (Deep Agent가 HITL 필요 판단 또는 critical 패턴)
                if result.requires_hitl or (
                    self.hitl_on_critical and severity.get("critical", 0) > 0
                ):
                    hitl_id = self._create_hitl_request(detect_result, result)
                    if hitl_id:
                        detect_result["hitl_request_id"] = hitl_id
                        detect_result["deep_analysis"]["hitl_request_id"] = hitl_id

            except Exception as e:
                self.logger.error(f"Deep analysis 실패: {e}")
        return detect_result

    def _create_hitl_request(
        self,
        detect_result: dict[str, Any],
        deep_result: Any,
    ) -> str | None:
        """Airflow HITL 요청 생성."""
        try:
            severity = detect_result.get("severity_breakdown", {})
            patterns = detect_result.get("patterns", [])

            # critical 패턴만 추출
            critical_patterns = [p for p in patterns if p.get("severity") in ("critical", "high")]

            request = HITLRequestCreate(
                agent_type=HITLAgentType.AIRFLOW,
                request_type=HITLRequestType.ACTION_APPROVAL,
                title=f"Airflow 실패 패턴 검토 요청 ({severity.get('critical', 0)}건 critical)",
                description=(
                    f"{detect_result.get('summary', '')}\n\n"
                    f"근본 원인 분석:\n"
                    + "\n".join(f"- {rc}" for rc in (deep_result.root_causes or []))
                    + "\n\n권장 조치:\n"
                    + "\n".join(f"- {rec}" for rec in (deep_result.recommendations or []))
                ),
                payload={
                    "detection_type": "airflow_failure",
                    "severity_breakdown": severity,
                    "patterns_count": len(patterns),
                    "critical_patterns": critical_patterns[:5],
                    "root_causes": deep_result.root_causes or [],
                    "recommendations": deep_result.recommendations or [],
                    "confidence_score": deep_result.confidence_score,
                    "environments": detect_result.get("environments_analyzed", []),
                    "options": [
                        {"action": "investigate", "label": "조사 필요"},
                        {"action": "retry_failed", "label": "실패 Task 재시도"},
                        {"action": "pause_dags", "label": "영향받는 DAG 일시 중지"},
                        {"action": "acknowledge", "label": "확인 (조치 불필요)"},
                    ],
                },
                expires_in_minutes=240,  # 4시간
                created_by="bdp-airflow-agent",
            )

            created = self.hitl_store.create(request)
            self.logger.info(f"Airflow HITL request created: {created.id}")
            return created.id

        except Exception as e:
            self.logger.error(f"Failed to create Airflow HITL request: {e}")
            return None

    def _normalize_detection_items(self, detect_result: dict[str, Any]) -> list[DetectionItem]:
        """패턴 결과를 DetectionItem 형식으로 변환."""
        items = []
        for p in detect_result.get("patterns", []):
            dags = p.get("affected_dags", [])
            items.append(
                DetectionItem(
                    item_type="pattern",
                    resource_id=dags[0] if dags else "unknown",
                    severity=p.get("severity", "medium"),
                    title=p.get("title", ""),
                    description=p.get("description", ""),
                    confidence=p.get("confidence", 0.0),
                    raw_data={"pattern_type": p.get("pattern_type", ""), "affected_dags": dags},
                )
            )
        return items

    @staticmethod
    def _pattern_to_dict(pattern: FailurePattern) -> dict[str, Any]:
        """FailurePattern → dict 변환."""
        return {
            "pattern_type": pattern.pattern_type.value,
            "severity": pattern.severity.value,
            "confidence": pattern.confidence,
            "title": pattern.title,
            "description": pattern.description,
            "affected_dags": pattern.affected_dags,
            "affected_tasks": pattern.affected_tasks,
            "evidence": pattern.evidence,
            "environment": pattern.environment,
            "failure_count": pattern.failure_count,
        }

    @staticmethod
    def _precursor_to_dict(signal) -> dict[str, Any]:
        """PrecursorSignal → dict 변환."""
        return {
            "signal_type": signal.signal_type,
            "dag_id": signal.dag_id,
            "task_id": signal.task_id,
            "severity": signal.severity.value,
            "confidence": signal.confidence,
            "lead_time_minutes": signal.lead_time_minutes,
            "description": signal.description,
            "evidence": signal.evidence,
        }

    @staticmethod
    def _correlation_to_dict(corr) -> dict[str, Any]:
        """CrossDagCorrelation → dict 변환."""
        return {
            "dag_ids": corr.dag_ids,
            "correlation_strength": corr.correlation_strength,
            "co_occurrence_count": corr.co_occurrence_count,
            "root_cause_candidate": corr.root_cause_candidate,
            "failure_chain": corr.failure_chain,
            "description": corr.description,
        }


# Lambda entry point
handler_instance = BDPAirflowHandler()


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda function entry point."""
    return handler_instance.handle(event, context)
