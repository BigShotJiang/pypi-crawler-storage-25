"""
E2E SSR (Server-Side Rendered) Report Generator for BDP Airflow Agent.

HTMLReportBase 기반 단일 HTML 파일 리포트 생성.
브라우저에서 직접 열 수 있는 셀프 컨테인드 리포트.
"""

import html as html_mod
import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from src.common.timezone import KST

logger = logging.getLogger(__name__)


# ─── Data Models ─────────────────────────────────────────────────────────────


@dataclass
class AirflowE2ETestResult:
    """개별 시나리오 테스트 결과."""

    scenario_id: int
    scenario_name: str
    scenario_name_ko: str
    description_ko: str
    environment: str
    expected_pattern: str
    expected_severity: str
    passed: bool
    matched: bool
    total_signals: int
    pattern_count: int = 0
    precursor_count: int = 0
    cluster_count: int = 0
    correlation_count: int = 0
    detected_patterns: list[dict[str, Any]] = field(default_factory=list)
    summary_text: str = ""
    kakao_preview: dict[str, str] = field(default_factory=dict)
    execution_time_ms: float = 0
    root_cause: str = ""
    investigated_logs: list[str] = field(default_factory=list)
    recommended_actions: list[str] = field(default_factory=list)
    ai_confidence: float = 0.0


@dataclass
class AirflowE2EGroupResult:
    """그룹별 테스트 결과."""

    group_id: str
    group_name: str
    total: int
    passed: int
    failed: int
    pass_rate: float
    results: list[AirflowE2ETestResult] = field(default_factory=list)


@dataclass
class AirflowE2EReportData:
    """전체 E2E 리포트 데이터."""

    total: int
    passed: int
    failed: int
    pass_rate: float
    avg_latency_ms: float
    groups: list[AirflowE2EGroupResult] = field(default_factory=list)
    all_results: list[AirflowE2ETestResult] = field(default_factory=list)


# ─── Korean Labels ───────────────────────────────────────────────────────────

PATTERN_KO = {
    "single_task": "단일 태스크",
    "cascading": "캐스케이딩",
    "recurring": "반복 실패",
    "cross_dag": "Cross-DAG",
    "duration_anomaly": "Duration 이상",
    "precursor": "전조증상",
    "op_kwargs_cluster": "op_kwargs 패턴",
    "time_based": "시간대별",
    "environment_specific": "환경 특이",
    "silent_warning": "사일런트 워닝",
    "sagemaker_pipeline": "SageMaker 파이프라인",
    "emr_cluster": "EMR 클러스터",
    "sftp_transfer": "SFTP 전송",
    "scheduler_overload": "스케줄러 과부하",
    "worker_resource": "워커 리소스",
    "external_api": "외부 API",
    "data_pipeline_copy": "COPY 파이프라인",
    "concurrency_limit": "동시성 제한",
    "deployment_regression": "배포 회귀",
    "infra_compound": "인프라 복합",
}

ENV_KO = {
    "dlk": "입수 파이프라인",
    "wfl": "사용자 워크플로우",
    "dlk+wfl": "입수 + 워크플로우",
}

SEVERITY_KO = {
    "critical": "심각",
    "high": "높음",
    "medium": "보통",
    "low": "낮음",
}


# ─── Report Generator ────────────────────────────────────────────────────────


class AirflowE2ESSRReportGenerator:
    """서버 사이드 렌더링 E2E 리포트 생성기.

    HTMLReportBase 대신 셀프 컨테인드 HTML을 직접 생성합니다.
    (bdp_common.reports.base 임포트 없이 독립 동작)
    """

    TITLE = "BDP Airflow Agent - E2E 시나리오 테스트 리포트"

    def generate_report(self, data: AirflowE2EReportData, output_path: str) -> str:
        """HTML 리포트 파일 생성."""
        from datetime import datetime
        from pathlib import Path

        content = self._generate_content(data)
        timestamp = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S")

        html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{self.TITLE}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>{self._get_css()}</style>
</head>
<body>
<div class="header"><div class="container">
<h1><span class="ms ms-lg" style="color:#fff">air</span> {self.TITLE}</h1>
<p class="subtitle">보고서 생성: {timestamp}</p>
</div></div>
<div class="container">{content}</div>
<script>{self._get_js()}</script>
</body></html>"""

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        return output_path

    # ── Content ──────────────────────────────────────────────────

    def _generate_content(self, data: AirflowE2EReportData) -> str:
        parts = [
            self._render_summary(data),
            self._render_severity_dist(data),
            self._render_pattern_dist(data),
            self._render_group_breakdown(data),
            self._render_filter_bar(data),
            self._render_test_cards(data),
        ]
        return "\n".join(parts)

    def _render_summary(self, data: AirflowE2EReportData) -> str:
        pc = (
            "#388E3C"
            if data.pass_rate >= 85
            else ("#F57C00" if data.pass_rate >= 70 else "#D32F2F")
        )
        total_signals = sum(r.total_signals for r in data.all_results)
        stats = [
            ("전체 시나리오", str(data.total), "#1976D2"),
            ("통과", str(data.passed), "#388E3C"),
            ("실패", str(data.failed), "#D32F2F"),
            ("통과율", f"{data.pass_rate:.0f}%", pc),
            ("총 신호 수", str(total_signals), "#757575"),
        ]
        cards = "".join(
            f'<div class="card stat-card"><div class="stat-value" style="color:{c}">{v}</div>'
            f'<div class="stat-label">{l}</div></div>'
            for l, v, c in stats
        )
        return f'<div class="grid grid-5">{cards}</div>'

    def _render_severity_dist(self, data: AirflowE2EReportData) -> str:
        dist = Counter(r.expected_severity for r in data.all_results)
        cfg = {
            "critical": ("#D32F2F", "#FFEBEE", "#B71C1C"),
            "high": ("#F57C00", "#FFF3E0", "#E65100"),
            "medium": ("#1976D2", "#E3F2FD", "#1565C0"),
            "low": ("#BDBDBD", "#F5F5F5", "#757575"),
        }
        cards = ""
        for sev in ["critical", "high", "medium", "low"]:
            color, bg, text = cfg[sev]
            n = dist.get(sev, 0)
            cards += (
                f'<div class="sev-card" style="background:{bg};border-left-color:{color}">'
                f'<div class="val" style="color:{color}">{n}</div>'
                f'<div class="lbl" style="color:{text}">{SEVERITY_KO.get(sev, sev)}</div></div>'
            )
        return self._card(
            '<span class="ms ms-sm ms-inline">bar_chart</span> 기대 심각도 분포',
            f'<div class="sev-grid">{cards}</div>',
        )

    def _render_pattern_dist(self, data: AirflowE2EReportData) -> str:
        dist = Counter(r.expected_pattern for r in data.all_results)
        tags = "".join(
            f'<span class="pat-tag">{PATTERN_KO.get(pt, pt)}: {n}</span>'
            for pt, n in dist.most_common()
        )
        return self._card(
            '<span class="ms ms-sm ms-inline">category</span> 기대 패턴 유형 분포',
            f'<div class="pat-dist">{tags}</div>',
        )

    def _render_group_breakdown(self, data: AirflowE2EReportData) -> str:
        if not data.groups:
            return ""
        rows = ""
        for g in data.groups:
            pct = g.pass_rate
            bar_color = "#388E3C" if pct >= 85 else ("#F57C00" if pct >= 70 else "#D32F2F")
            rows += f"""<div class="gb-row">
            <div class="gb-label">{html_mod.escape(g.group_name)}</div>
            <div class="gb-bar-wrap">
                <div class="gb-bar" style="width:{pct:.0f}%;background:{bar_color}"></div>
            </div>
            <div class="gb-stat">{g.passed}/{g.total} ({pct:.0f}%)</div></div>"""
        return self._card(
            '<span class="ms ms-sm ms-inline">stacked_bar_chart</span> 그룹별 통과율',
            rows,
        )

    def _render_filter_bar(self, data: AirflowE2EReportData) -> str:
        return f"""<div class="fbar">
        <button class="fbtn active" data-filter="all">
            <span class="ms ms-xs ms-inline">list</span> 전체 ({data.total})</button>
        <button class="fbtn" data-filter="pass">
            <span class="ms ms-xs ms-inline">check_circle</span> 통과 ({data.passed})</button>
        <button class="fbtn" data-filter="fail">
            <span class="ms ms-xs ms-inline">error</span> 실패 ({data.failed})</button>
        <span class="actions"><a onclick="toggleAll(true)">모두 펼치기</a> | <a onclick="toggleAll(false)">모두 접기</a></span>
        </div>"""

    def _render_test_cards(self, data: AirflowE2EReportData) -> str:
        return "\n".join(self._render_one_card(r) for r in data.all_results)

    def _render_one_card(self, r: AirflowE2ETestResult) -> str:
        cls = "pass" if r.passed else "fail"
        icon = "check_circle" if r.passed else "error"
        color = "#388E3C" if r.passed else "#D32F2F"
        sev_badge = self._severity_badge(r.expected_severity)
        pat_ko = PATTERN_KO.get(r.expected_pattern, r.expected_pattern)
        env_ko = ENV_KO.get(r.environment, r.environment)

        # Detected pattern tags
        det_tags = ""
        for p in r.detected_patterns[:5]:
            ptype = p.get("pattern_type", "")
            psev = p.get("severity", "")
            det_tags += f'<span class="stag pat">{PATTERN_KO.get(ptype, ptype)} [{psev}]</span>'
        if r.precursor_count:
            det_tags += f'<span class="stag prec">전조증상 {r.precursor_count}건</span>'
        if r.cluster_count:
            det_tags += f'<span class="stag clus">클러스터 {r.cluster_count}건</span>'
        if r.correlation_count:
            det_tags += f'<span class="stag corr">상관관계 {r.correlation_count}건</span>'

        # Pattern detail table
        pat_detail = ""
        if r.detected_patterns:
            p_rows = ""
            for p in r.detected_patterns[:8]:
                p_rows += (
                    f"<tr><td>{PATTERN_KO.get(p.get('pattern_type', ''), p.get('pattern_type', ''))}</td>"
                    f"<td>{self._severity_badge(p.get('severity', 'low'))}</td>"
                    f"<td>{p.get('confidence', 0) * 100:.0f}%</td>"
                    f"<td>{html_mod.escape(p.get('title', ''))}</td>"
                    f'<td style="font-size:12px">{html_mod.escape((p.get("description", ""))[:80])}</td></tr>'
                )
            pat_detail = f"""<div style="margin-top:12px">
            <h4 class="dsec-title"><span class="ms ms-xs ms-inline">pattern</span>탐지된 패턴 상세</h4>
            <table class="dm"><thead><tr><th>유형</th><th>심각도</th><th>신뢰도</th><th>제목</th><th>설명</th></tr></thead>
            <tbody>{p_rows}</tbody></table></div>"""

        # Kakao preview (cost_drift style)
        kakao_html = self._render_kakao_preview(r)

        return f"""<div class="tc {cls}">
        <div class="tc-hdr">
            <div class="tc-status"><span class="ms ms-sm ms-filled" style="color:{color}">{icon}</span></div>
            <div class="tc-id">#{r.scenario_id}</div>
            <div class="tc-name">{html_mod.escape(r.scenario_name_ko)}</div>
            <div class="tc-meta">{sev_badge}
                <span class="tc-chev"><span class="ms ms-sm">expand_more</span></span>
            </div>
        </div>
        <div class="tc-body">
            <div class="dgrid">
                <div class="dsec">
                    <h4 class="dsec-title"><span class="ms ms-xs ms-inline">target</span>기대값</h4>
                    <div class="drow"><span class="dlbl">패턴 유형</span><span class="dval">{pat_ko}</span></div>
                    <div class="drow"><span class="dlbl">심각도</span><span class="dval">{sev_badge}</span></div>
                    <div class="drow"><span class="dlbl">환경</span><span class="dval">{env_ko}</span></div>
                    <div class="drow"><span class="dlbl">설명</span><span class="dval" style="max-width:200px;text-align:right">{html_mod.escape(r.description_ko)}</span></div>
                    <div class="drow"><span class="dlbl">실행시간</span><span class="dval">{r.execution_time_ms:.1f}ms</span></div>
                </div>
                <div class="dsec">
                    <h4 class="dsec-title"><span class="ms ms-xs ms-inline">analytics</span>탐지 결과</h4>
                    <div class="drow"><span class="dlbl">패턴</span><span class="dval">{r.pattern_count}건</span></div>
                    <div class="drow"><span class="dlbl">전조증상</span><span class="dval">{r.precursor_count}건</span></div>
                    <div class="drow"><span class="dlbl">클러스터</span><span class="dval">{r.cluster_count}건</span></div>
                    <div class="drow"><span class="dlbl">상관관계</span><span class="dval">{r.correlation_count}건</span></div>
                    <div class="drow"><span class="dlbl">총 신호</span><span class="dval"><strong>{r.total_signals}건</strong></span></div>
                    <div style="margin-top:8px">{det_tags if det_tags else '<span style="font-size:12px;color:#757575">탐지 없음</span>'}</div>
                </div>
            </div>
            {pat_detail}
            {self._render_ai_section(r)}
            {kakao_html}
        </div></div>"""

    # ── AI Analysis Section ─────────────────────────────────────

    def _render_ai_section(self, r: AirflowE2ETestResult) -> str:
        """AI 원인분석 섹션 렌더링 (3-column grid)."""
        if not r.root_cause:
            return ""

        # 조회 로그
        logs_html = "".join(f"<li>{html_mod.escape(log)}</li>" for log in r.investigated_logs)
        logs_col = f"""<div class="ai-col">
            <h5 class="ai-col-title"><span class="ms ms-xs ms-inline">description</span>조회 로그</h5>
            <ul class="ai-list">{logs_html}</ul>
        </div>"""

        # 원인 분석 + 신뢰도 배지
        conf_pct = int(r.ai_confidence * 100)
        conf_color = "#388E3C" if conf_pct >= 85 else ("#F57C00" if conf_pct >= 70 else "#D32F2F")
        cause_col = f"""<div class="ai-col">
            <h5 class="ai-col-title"><span class="ms ms-xs ms-inline">psychology</span>원인 분석</h5>
            <p class="ai-cause">{html_mod.escape(r.root_cause)}</p>
            <span class="ai-conf" style="color:{conf_color};border-color:{conf_color}">
                <span class="ms ms-xs ms-inline">speed</span>신뢰도 {conf_pct}%</span>
        </div>"""

        # 권장 조치
        actions_html = "".join(
            f"<li>{html_mod.escape(action)}</li>" for action in r.recommended_actions
        )
        actions_col = f"""<div class="ai-col">
            <h5 class="ai-col-title"><span class="ms ms-xs ms-inline">build</span>권장 조치</h5>
            <ol class="ai-actions">{actions_html}</ol>
        </div>"""

        return f"""<div class="ai-section">
            <h4 class="ai-title"><span class="ms ms-sm ms-inline">smart_toy</span>AI 원인분석 (Deep Agent)</h4>
            <div class="ai-grid">{logs_col}{cause_col}{actions_col}</div>
        </div>"""

    # ── Preview Renderers ────────────────────────────────────────

    def _render_kakao_preview(self, r: AirflowE2ETestResult) -> str:
        """카카오톡 알림 미리보기 (cost_drift 양식 + AI 원인분석)."""
        kp = r.kakao_preview
        if not kp:
            return '<div class="kakao-section"><h4><span class="ms ms-xs ms-inline">chat</span> 카카오톡 알림 미리보기</h4><div class="kakao-preview"><div class="kakao-bubble"><div class="kakao-title">Airflow 정상</div><div class="kakao-divider"></div><div class="kakao-content">분석 기간 내 유의미한 실패 패턴이 탐지되지 않았습니다.</div></div></div></div>'

        title = html_mod.escape(kp.get("title", ""))
        message = html_mod.escape(kp.get("message", ""))

        # AI 원인분석 요약 추가
        if r.root_cause:
            cause_short = r.root_cause[:120]
            message += f"\n\n[원인분석] {html_mod.escape(cause_short)}"
            if r.recommended_actions:
                message += "\n[권장조치]"
                for i, action in enumerate(r.recommended_actions[:3], 1):
                    message += f"\n{i}. {html_mod.escape(action)}"

        msg_html = message.replace("\n", "<br>")

        return f"""<div class="kakao-section">
            <h4><span class="ms ms-xs ms-inline">chat</span> 카카오톡 알림 미리보기</h4>
            <div class="kakao-preview">
                <div class="kakao-bubble">
                    <div class="kakao-title">{title}</div>
                    <div class="kakao-divider"></div>
                    <div class="kakao-content">{msg_html}</div>
                </div>
            </div>
        </div>"""

    # ── Helpers ───────────────────────────────────────────────────

    def _card(self, title: str, content: str) -> str:
        return f'<div class="card"><div class="card-header"><span class="card-title">{title}</span></div>{content}</div>'

    def _severity_badge(self, sev: str) -> str:
        icons = {"critical": "error", "high": "warning", "medium": "info", "low": "check_circle"}
        fill = " ms-filled" if sev in ("critical", "high") else ""
        return (
            f'<span class="badge badge-{sev}">'
            f'<span class="ms ms-sm{fill}">{icons.get(sev, "info")}</span> '
            f"{SEVERITY_KO.get(sev, sev)}</span>"
        )

    # ── CSS ───────────────────────────────────────────────────────

    def _get_css(self) -> str:
        return """
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Pretendard',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F5F5F5;color:#212121;line-height:1.6}
.container{max-width:1200px;margin:0 auto;padding:20px}
.ms{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-feature-settings:'liga';-webkit-font-smoothing:antialiased;vertical-align:middle}
.ms-xs{font-size:14px}.ms-sm{font-size:18px}.ms-md{font-size:24px}.ms-lg{font-size:32px}
.ms-filled{font-variation-settings:'FILL' 1}
.ms-inline{vertical-align:-0.125em;margin-right:4px}
.header{background:linear-gradient(135deg,#0D47A1 0%,#1565C0 50%,#1976D2 100%);color:#fff;padding:32px 0}
.header .container{display:flex;flex-direction:column;align-items:center}
.header h1{font-size:28px;color:#fff;display:flex;align-items:center;gap:8px}
.header .subtitle{color:rgba(255,255,255,.8);margin-top:4px;font-size:14px}
.card{background:#FFF;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;padding:20px}
.card-header{border-bottom:1px solid #E0E0E0;padding-bottom:12px;margin-bottom:16px}
.card-title{font-size:18px;font-weight:600}
.grid{display:grid;gap:20px}.grid-5{grid-template-columns:repeat(5,1fr)}
.stat-card{text-align:center;padding:20px}
.stat-value{font-size:32px;font-weight:700}
.stat-label{font-size:14px;color:#757575;margin-top:4px}
.badge{display:inline-flex;align-items:center;gap:2px;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:500}
.badge-critical{background:#FFEBEE;color:#B71C1C;border:1px solid #D32F2F}
.badge-high{background:#FFF3E0;color:#E65100;border:1px solid #F57C00}
.badge-medium{background:#E3F2FD;color:#1565C0;border:1px solid #1976D2}
.badge-low{background:#F5F5F5;color:#757575;border:1px solid #BDBDBD}
.sev-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px}
.sev-card{text-align:center;padding:16px;border-radius:8px;border-left:4px solid}
.sev-card .val{font-size:28px;font-weight:700}
.sev-card .lbl{font-size:12px;margin-top:4px;font-weight:500}
.pat-dist{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.pat-tag{padding:4px 12px;border-radius:16px;font-size:12px;font-weight:500;background:#E3F2FD;color:#1565C0}
.gb-row{display:flex;align-items:center;gap:12px;padding:8px 0}
.gb-label{min-width:200px;font-size:14px;font-weight:500}
.gb-bar-wrap{flex:1;height:20px;background:#F5F5F5;border-radius:10px;overflow:hidden}
.gb-bar{height:100%;border-radius:10px;transition:width .3s}
.gb-stat{min-width:100px;text-align:right;font-size:13px;color:#757575}
.fbar{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center}
.fbtn{padding:6px 16px;border:1px solid #BDBDBD;border-radius:20px;background:#FFF;cursor:pointer;font-size:13px;transition:all .2s;display:inline-flex;align-items:center;gap:4px}
.fbtn:hover{background:#F5F5F5}
.fbtn.active{background:#1976D2;color:#fff;border-color:#1976D2}
.fbar .actions{margin-left:auto;font-size:13px;color:#757575}
.fbar .actions a{cursor:pointer;text-decoration:underline;color:#757575}
.tc{background:#FFF;border:1px solid #E0E0E0;border-radius:8px;margin-bottom:8px;overflow:hidden;transition:box-shadow .2s}
.tc:hover{box-shadow:0 2px 8px rgba(0,0,0,.1)}
.tc.pass{border-left:4px solid #388E3C}
.tc.fail{border-left:4px solid #D32F2F}
.tc-hdr{display:flex;align-items:center;padding:12px 16px;cursor:pointer;user-select:none;gap:12px}
.tc-hdr:hover{background:#F5F5F5}
.tc-status{flex-shrink:0}.tc-id{font-weight:600;font-size:13px;color:#757575;min-width:40px}
.tc-name{flex:1;font-weight:500;font-size:14px}
.tc-meta{display:flex;gap:8px;align-items:center;flex-shrink:0}
.tc-chev{transition:transform .2s;color:#757575}
.tc.expanded .tc-chev{transform:rotate(180deg)}
.tc-body{display:none;padding:0 16px 16px;border-top:1px solid #E0E0E0}
.tc.expanded .tc-body{display:block}
.dgrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px}
.dsec{background:#F5F5F5;border-radius:8px;padding:12px}
.dsec-title{font-size:13px;color:#757575;margin-bottom:8px;letter-spacing:.3px;display:flex;align-items:center;gap:4px}
.drow{display:flex;justify-content:space-between;padding:4px 0;font-size:13px}
.dlbl{color:#757575}.dval{font-weight:500}
.stag{display:inline-block;padding:3px 10px;border-radius:14px;font-size:12px;font-weight:500;margin:2px 4px 2px 0}
.stag.pat{background:#E3F2FD;color:#1565C0}
.stag.prec{background:#FFF3E0;color:#E65100}
.stag.clus{background:#F3E5F5;color:#4A148C}
.stag.corr{background:#E0F2F1;color:#004D40}
.dm{width:100%;border-collapse:collapse;margin:12px 0}
.dm th,.dm td{padding:8px 12px;text-align:center;border:1px solid #E0E0E0;font-size:13px}
.dm th{background:#F5F5F5;font-weight:600}
.dm td:first-child{text-align:left;font-weight:500}
/* AI Analysis Section */
.ai-section{background:#EDE7F6;border-left:4px solid #7E57C2;border-radius:8px;padding:16px;margin-top:12px}
.ai-title{font-size:14px;font-weight:600;color:#4A148C;margin-bottom:12px;display:flex;align-items:center;gap:4px}
.ai-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
.ai-col{background:#FFF;border-radius:6px;padding:12px}
.ai-col-title{font-size:12px;font-weight:600;color:#5E35B1;margin-bottom:8px;display:flex;align-items:center;gap:4px}
.ai-list{list-style:none;padding:0;margin:0}.ai-list li{font-size:12px;color:#424242;padding:3px 0;padding-left:12px;position:relative}
.ai-list li::before{content:"";position:absolute;left:0;top:9px;width:5px;height:5px;border-radius:50%;background:#7E57C2}
.ai-cause{font-size:13px;color:#212121;line-height:1.6;margin-bottom:8px}
.ai-conf{display:inline-flex;align-items:center;gap:2px;font-size:11px;font-weight:600;border:1px solid;border-radius:12px;padding:2px 8px}
.ai-actions{padding-left:18px;margin:0}.ai-actions li{font-size:12px;color:#424242;padding:3px 0}
@media(max-width:768px){.ai-grid{grid-template-columns:1fr}}
/* Kakao Talk Preview (cost_drift style) */
.kakao-section{padding:16px;background:#F5F5F5;border-top:1px solid #E0E0E0;margin-top:12px}
.kakao-section h4{font-size:13px;color:#757575;margin-bottom:12px}
.kakao-preview{display:flex;justify-content:center}
.kakao-bubble{background:#FEE500;border-radius:15px;padding:15px;max-width:400px;width:100%;box-shadow:0 2px 8px rgba(0,0,0,.12)}
.kakao-title{font-weight:bold;font-size:14px;color:#3c1e1e;margin-bottom:8px}
.kakao-divider{height:1px;background:rgba(60,30,30,.2);margin:8px 0}
.kakao-content{font-size:13px;color:#3c1e1e;line-height:1.6;white-space:pre-wrap}
@media(max-width:768px){.grid-5{grid-template-columns:repeat(2,1fr)}.sev-grid{grid-template-columns:repeat(2,1fr)}.dgrid{grid-template-columns:1fr}}
"""

    def _get_js(self) -> str:
        return """
document.addEventListener('click',function(e){
  var hdr=e.target.closest('.tc-hdr');
  if(hdr){hdr.closest('.tc').classList.toggle('expanded');return;}
  var btn=e.target.closest('.fbtn');
  if(btn){
    btn.closest('.fbar').querySelectorAll('.fbtn').forEach(function(b){b.classList.remove('active')});
    btn.classList.add('active');
    var f=btn.dataset.filter;
    document.querySelectorAll('.tc').forEach(function(c){
      c.style.display=f==='all'?'':(f==='pass'?(c.classList.contains('pass')?'':'none'):(c.classList.contains('fail')?'':'none'));
    });
  }
});
function toggleAll(expand){
  document.querySelectorAll('.tc').forEach(function(c){if(expand)c.classList.add('expanded');else c.classList.remove('expanded');});
}
"""
