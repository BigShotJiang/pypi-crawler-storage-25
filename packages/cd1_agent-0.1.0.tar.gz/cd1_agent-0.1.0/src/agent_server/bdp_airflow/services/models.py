"""
Data Models for Airflow Failure Analysis.

Airflow DAG/Task 실패 분석을 위한 데이터 모델.
RDS 레코드 매핑, 탐지 패턴, 전조증상, 분석 결과 등.
"""

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class AirflowEnvironment(str, Enum):
    """Airflow 환경 구분 (rcpt_tp 칼럼값)."""

    DLK = "dlk"  # 입수 파이프라인
    WFL = "wfl"  # 사용자 워크플로우

    @property
    def label(self) -> str:
        """환경 한글 라벨."""
        labels = {
            AirflowEnvironment.DLK: "입수 파이프라인",
            AirflowEnvironment.WFL: "사용자 워크플로우",
        }
        return labels.get(self, self.value)


class FailureSeverity(str, Enum):
    """실패 심각도."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class TaskState(str, Enum):
    """Airflow Task 상태."""

    FAILED = "failed"
    SUCCESS = "success"
    UPSTREAM_FAILED = "upstream_failed"


class FailurePatternType(str, Enum):
    """실패 패턴 유형."""

    SINGLE_TASK = "single_task"
    CASCADING = "cascading"
    RECURRING = "recurring"
    CROSS_DAG = "cross_dag"
    DURATION_ANOMALY = "duration_anomaly"
    PRECURSOR = "precursor"
    OP_KWARGS_CLUSTER = "op_kwargs_cluster"
    TIME_BASED = "time_based"
    ENVIRONMENT_SPECIFIC = "environment_specific"
    SILENT_WARNING = "silent_warning"
    # 확장 패턴 (외부 시스템 연동, 인프라)
    SAGEMAKER_PIPELINE = "sagemaker_pipeline"
    EMR_CLUSTER = "emr_cluster"
    SFTP_TRANSFER = "sftp_transfer"
    SCHEDULER_OVERLOAD = "scheduler_overload"
    WORKER_RESOURCE = "worker_resource"
    EXTERNAL_API = "external_api"
    DATA_PIPELINE_COPY = "data_pipeline_copy"
    CONCURRENCY_LIMIT = "concurrency_limit"
    DEPLOYMENT_REGRESSION = "deployment_regression"
    INFRA_COMPOUND = "infra_compound"


@dataclass
class AirflowFailureRecord:
    """RDS 1행 매핑 - Airflow 태스크 실패 레코드.

    rcpt_tp로 환경(dlk/wfl) 구분.
    """

    start_date: str
    rcpt_tp: str  # dlk or wfl
    dag_id: str
    task_id: str
    state: str  # failed, success, upstream_failed
    python_callable: str = ""
    duration: str = ""
    err_msg: str = ""
    op_kwargs: str = ""
    run_id: str = ""

    @property
    def environment(self) -> AirflowEnvironment:
        """rcpt_tp → AirflowEnvironment 변환."""
        try:
            return AirflowEnvironment(self.rcpt_tp)
        except ValueError:
            return AirflowEnvironment.DLK

    @property
    def task_state(self) -> TaskState:
        """state → TaskState 변환."""
        try:
            return TaskState(self.state)
        except ValueError:
            return TaskState.FAILED

    @property
    def is_failed(self) -> bool:
        """실패 상태 여부."""
        return self.state in (TaskState.FAILED.value, TaskState.UPSTREAM_FAILED.value)

    @property
    def duration_seconds(self) -> float | None:
        """duration 문자열을 초 단위로 변환."""
        if not self.duration:
            return None
        try:
            return float(self.duration)
        except (ValueError, TypeError):
            return None

    @property
    def parsed_op_kwargs(self) -> dict[str, Any]:
        """op_kwargs JSON 파싱."""
        if not self.op_kwargs:
            return {}
        try:
            return json.loads(self.op_kwargs)
        except (json.JSONDecodeError, TypeError):
            return {}


@dataclass
class FailurePattern:
    """탐지된 실패 패턴."""

    pattern_type: FailurePatternType
    severity: FailureSeverity
    confidence: float  # 0.0 ~ 1.0
    title: str
    description: str
    affected_dags: list[str] = field(default_factory=list)
    affected_tasks: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    environment: str | None = None  # dlk, wfl, or None (both)
    failure_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PrecursorSignal:
    """전조증상 신호."""

    signal_type: str  # duration_increase, warning_keyword, retry_escalation
    dag_id: str
    task_id: str
    severity: FailureSeverity
    confidence: float
    lead_time_minutes: float  # 전조 → 실패까지 평균 시간
    description: str
    evidence: list[str] = field(default_factory=list)
    environment: str | None = None


@dataclass
class OpKwargsCluster:
    """op_kwargs 공통 패턴 클러스터."""

    cluster_id: str
    common_keys: dict[str, str]  # 공통 key-value 쌍
    failure_count: int
    affected_dags: list[str] = field(default_factory=list)
    affected_tasks: list[str] = field(default_factory=list)
    common_errors: list[str] = field(default_factory=list)
    description: str = ""


@dataclass
class CrossDagCorrelation:
    """DAG간 상관관계."""

    dag_ids: list[str]
    correlation_strength: float  # 0.0 ~ 1.0
    co_occurrence_count: int
    time_window_minutes: int
    root_cause_candidate: str | None = None  # 최초 실패 DAG
    failure_chain: list[str] = field(default_factory=list)  # 시간순 실패 체인
    common_error: str | None = None
    description: str = ""


@dataclass
class DagAnalysisResult:
    """DAG별 분석 결과."""

    dag_id: str
    environment: str
    total_runs: int
    failure_count: int
    failure_rate: float
    most_failed_tasks: list[dict[str, Any]] = field(default_factory=list)
    avg_duration_seconds: float | None = None
    duration_trend: str = "stable"  # increasing, decreasing, stable
    recent_errors: list[str] = field(default_factory=list)


@dataclass
class AirflowAnalysisResult:
    """전체 Airflow 분석 결과."""

    patterns: list[FailurePattern] = field(default_factory=list)
    precursors: list[PrecursorSignal] = field(default_factory=list)
    clusters: list[OpKwargsCluster] = field(default_factory=list)
    correlations: list[CrossDagCorrelation] = field(default_factory=list)
    dag_analyses: list[DagAnalysisResult] = field(default_factory=list)
    summary: str = ""
    total_failures: int = 0
    environments_analyzed: list[str] = field(default_factory=list)
    analysis_window_hours: int = 24

    @property
    def highest_severity(self) -> FailureSeverity:
        """가장 높은 심각도 반환."""
        for sev in [
            FailureSeverity.CRITICAL,
            FailureSeverity.HIGH,
            FailureSeverity.MEDIUM,
            FailureSeverity.LOW,
        ]:
            if any(p.severity == sev for p in self.patterns):
                return sev
        return FailureSeverity.LOW

    @property
    def severity_counts(self) -> dict[str, int]:
        """심각도별 패턴 수."""
        return {
            sev.value: sum(1 for p in self.patterns if p.severity == sev) for sev in FailureSeverity
        }


# ── RCA 분류 체계 ──────────────────────────────────────


class RCACategoryType(str, Enum):
    """근본 원인 분류 카테고리."""

    INFRASTRUCTURE = "infrastructure"  # Worker OOM, Scheduler overload, 네트워크
    CODE = "code"  # DAG 코드 버그, 배포 회귀, 라이브러리 호환성
    DATA = "data"  # 데이터 볼륨 급증, 스키마 변경, 입력 데이터 품질
    EXTERNAL_SYSTEM = "external_system"  # S3/SageMaker/EMR/SFTP 장애, API 오류
    SCHEDULING = "scheduling"  # 동시성 제한, SLA 위반, 스케줄 충돌
    UNKNOWN = "unknown"


@dataclass
class RootCauseClassification:
    """구조화된 근본 원인 분류."""

    category: RCACategoryType
    cause: str  # 근본 원인 설명
    confidence: float = 0.0  # 0.0 ~ 1.0
    affected_dags: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)


# ── Remediation 모델 ────────────────────────────────────


class RemediationRiskLevel(str, Enum):
    """자동 복구 리스크 수준."""

    LOW = "low"  # 완전 자동 (retry, 로그 수집)
    MEDIUM = "medium"  # HITL 승인 필요 (DAG pause, backfill)
    HIGH = "high"  # 반드시 HITL (환경 변경, 스케줄 변경)


class RemediationActionType(str, Enum):
    """자동 복구 액션 타입."""

    TASK_RETRY = "task_retry"
    CLEAR_STUCK_DAG = "clear_stuck_dag"
    COLLECT_LOGS = "collect_logs"
    PAUSE_DOWNSTREAM = "pause_downstream"
    TRIGGER_BACKFILL = "trigger_backfill"
    SCALE_ENVIRONMENT = "scale_environment"
    MODIFY_SCHEDULE = "modify_schedule"


@dataclass
class RemediationAction:
    """자동 복구 액션."""

    action_type: RemediationActionType
    risk_level: RemediationRiskLevel
    dag_id: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    requires_hitl: bool = False
    hitl_expires_minutes: int = 60  # HITL 승인 대기 시간


@dataclass
class RemediationResult:
    """자동 복구 실행 결과."""

    action_type: RemediationActionType
    dag_id: str
    success: bool
    message: str
    executed_at: str = ""
    hitl_request_id: str | None = None
