"""
Airflow Event Publisher - EventBridge 발행 래퍼.

bdp_common.eventbridge.publisher.EventPublisher를 래핑하여
Airflow 실패 탐지 이벤트를 EventBridge에 발행합니다.
"""

import logging
import os
from pathlib import Path
from typing import Optional

from src.agent_server.bdp_common.eventbridge.publisher import (
    AlertEvent,
    EmailChannel,
    EventPublisher,
    KakaoChannel,
    ProductionAlertDetail,
    get_environment_account_name,
)
from src.agent_server.bdp_airflow.services.models import (
    AirflowAnalysisResult,
    FailureSeverity,
)
from src.agent_server.bdp_airflow.services.summary_generator import AirflowAlertSummary

logger = logging.getLogger(__name__)

# EventBridge config 경로
_CONFIG_PATH = str(Path(__file__).parent.parent / "conf" / "eventbridge_config.json")


class AirflowEventPublisher:
    """Airflow 실패 탐지 EventBridge 발행기.

    source="cd1-agent.bdp-airflow",
    DetailType="Airflow Failure Detected"
    """

    SEVERITY_EMOJI = {
        FailureSeverity.CRITICAL: "🚨",
        FailureSeverity.HIGH: "⚠️",
        FailureSeverity.MEDIUM: "📊",
        FailureSeverity.LOW: "ℹ️",
    }

    def __init__(
        self,
        event_bus: Optional[str] = None,
        use_mock: bool = False,
    ):
        self._publisher = EventPublisher(
            event_bus=event_bus or os.getenv("EVENT_BUS", "cd1-agent-events"),
            source="cd1-agent.bdp-airflow",
            detail_type="Airflow Failure Detected",
            use_mock=use_mock,
            config_path=_CONFIG_PATH,
        )

    def publish_analysis_alert(
        self,
        result: AirflowAnalysisResult,
        summary: AirflowAlertSummary,
    ) -> bool:
        """분석 결과를 EventBridge에 발행.

        Args:
            result: 분석 결과
            summary: 알림 요약

        Returns:
            발행 성공 여부
        """
        severity = result.highest_severity
        emoji = self.SEVERITY_EMOJI.get(severity, "📊")

        # 영향 DAG 목록
        affected_dags = set()
        for p in result.patterns:
            affected_dags.update(p.affected_dags)

        event = AlertEvent(
            alert_type="airflow_failure",
            severity=emoji,
            severity_level=severity.value,
            title=summary.title,
            message=summary.message,
            affected_resources=[
                {"dag_id": dag, "type": "airflow_dag"}
                for dag in list(affected_dags)[:20]
            ],
            action_required=severity in (FailureSeverity.CRITICAL, FailureSeverity.HIGH),
            metadata={
                "total_patterns": len(result.patterns),
                "total_failures": result.total_failures,
                "environments": result.environments_analyzed,
                "severity_counts": result.severity_counts,
            },
        )

        return self._publisher.publish_event(event)

    def publish_production_alert(
        self,
        summary: AirflowAlertSummary,
        send_email: bool = False,
        send_kakao: bool = True,
        email_to: Optional[list] = None,
    ) -> bool:
        """Production 형식 알림 발행 (Email + KakaoTalk).

        Args:
            summary: 알림 요약
            send_email: 이메일 발송 여부
            send_kakao: 카카오톡 발송 여부
            email_to: 이메일 수신자 목록

        Returns:
            발행 성공 여부
        """
        email_channel = None
        if send_email and email_to:
            email_channel = EmailChannel(
                to=email_to,
                cc=[],
                from_email="alert-airflow@bdp.agent",
                from_name="BDP Airflow Alert",
                message=summary.message,
            )

        kakao_channel = None
        if send_kakao:
            kakao_channel = KakaoChannel(
                severity="MAJOR" if "🚨" in summary.severity_emoji else "MINOR",
                category1=get_environment_account_name().upper(),
                category2="BDPADMIN",
                category3="Airflow",
                message=summary.message[:500],
            )

        detail = ProductionAlertDetail(
            subject=summary.title,
            account_id=get_environment_account_name(),
            component="BDPA",
            email=email_channel,
            kakao=kakao_channel,
        )

        return self._publisher.publish_production_event(
            detail=detail,
            detail_type="Airflow Failure Detected",
        )
