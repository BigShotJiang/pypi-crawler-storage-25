"""
E2E Scenario Test Report Generator for BDP Airflow Agent.

JSON + JavaScript 기반 클라이언트 사이드 렌더링 리포트.
개별 시나리오별 JSON 파일 생성 + 정적 HTML 쉘 생성.

구조:
    docs/bdp_airflow/
    ├── scenario_report.html       ← 정적 HTML (JS로 렌더링)
    └── data/
        ├── summary.json           ← 전체 요약 + 라벨 매핑
        ├── scenario_01_single_task_failure.json
        ├── scenario_02_cascading_failure.json
        └── ...
"""

import json
import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_airflow.services.models import (
    AirflowAnalysisResult,
    CrossDagCorrelation,
    FailurePattern,
    FailurePatternType,
    FailureSeverity,
    OpKwargsCluster,
    PrecursorSignal,
)

logger = logging.getLogger(__name__)

# ─── Korean Label Mappings ───────────────────────────────────────────────────

SEVERITY_KO = {
    FailureSeverity.CRITICAL: "심각",
    FailureSeverity.HIGH: "높음",
    FailureSeverity.MEDIUM: "보통",
    FailureSeverity.LOW: "낮음",
}

PATTERN_KO = {
    FailurePatternType.SINGLE_TASK: "단일 태스크",
    FailurePatternType.CASCADING: "캐스케이딩",
    FailurePatternType.RECURRING: "반복 실패",
    FailurePatternType.CROSS_DAG: "Cross-DAG",
    FailurePatternType.DURATION_ANOMALY: "Duration 이상",
    FailurePatternType.PRECURSOR: "전조증상",
    FailurePatternType.OP_KWARGS_CLUSTER: "op_kwargs 패턴",
    FailurePatternType.TIME_BASED: "시간대별",
    FailurePatternType.ENVIRONMENT_SPECIFIC: "환경 특이",
    FailurePatternType.SILENT_WARNING: "사일런트 워닝",
    FailurePatternType.SAGEMAKER_PIPELINE: "SageMaker 파이프라인",
    FailurePatternType.EMR_CLUSTER: "EMR 클러스터",
    FailurePatternType.SFTP_TRANSFER: "SFTP 전송",
    FailurePatternType.SCHEDULER_OVERLOAD: "스케줄러 과부하",
    FailurePatternType.WORKER_RESOURCE: "워커 리소스",
    FailurePatternType.EXTERNAL_API: "외부 API",
    FailurePatternType.DATA_PIPELINE_COPY: "COPY 파이프라인",
    FailurePatternType.CONCURRENCY_LIMIT: "동시성 제한",
    FailurePatternType.DEPLOYMENT_REGRESSION: "배포 회귀",
    FailurePatternType.INFRA_COMPOUND: "인프라 복합",
}

PATTERN_ICON = {
    FailurePatternType.SINGLE_TASK: "task_alt",
    FailurePatternType.CASCADING: "waterfall_chart",
    FailurePatternType.RECURRING: "repeat",
    FailurePatternType.CROSS_DAG: "hub",
    FailurePatternType.DURATION_ANOMALY: "timer",
    FailurePatternType.PRECURSOR: "trending_up",
    FailurePatternType.OP_KWARGS_CLUSTER: "inventory_2",
    FailurePatternType.TIME_BASED: "schedule",
    FailurePatternType.ENVIRONMENT_SPECIFIC: "dns",
    FailurePatternType.SILENT_WARNING: "notifications_paused",
    FailurePatternType.SAGEMAKER_PIPELINE: "model_training",
    FailurePatternType.EMR_CLUSTER: "cloud_circle",
    FailurePatternType.SFTP_TRANSFER: "swap_horiz",
    FailurePatternType.SCHEDULER_OVERLOAD: "event_busy",
    FailurePatternType.WORKER_RESOURCE: "memory",
    FailurePatternType.EXTERNAL_API: "api",
    FailurePatternType.DATA_PIPELINE_COPY: "content_copy",
    FailurePatternType.CONCURRENCY_LIMIT: "queue",
    FailurePatternType.DEPLOYMENT_REGRESSION: "published_with_changes",
    FailurePatternType.INFRA_COMPOUND: "warning",
}

ENV_KO = {
    "dlk": "입수 파이프라인",
    "wfl": "사용자 워크플로우",
    "dlk+wfl": "입수 + 워크플로우",
}

SEVERITY_EMOJI = {
    "critical": "\U0001f6a8",
    "high": "\u26a0\ufe0f",
    "medium": "\U0001f4ca",
    "low": "\u2139\ufe0f",
}


# ─── Data Models ─────────────────────────────────────────────────────────────


@dataclass
class ScenarioReportItem:
    """개별 시나리오 테스트 결과."""

    scenario_id: int
    scenario_name: str
    scenario_name_ko: str
    description_ko: str
    environment: str
    expected_pattern: FailurePatternType
    expected_severity: FailureSeverity
    result: AirflowAnalysisResult
    passed: bool
    matched: bool
    total_signals: int
    summary_text: str = ""


@dataclass
class AirflowE2EReportData:
    """전체 E2E 리포트 데이터."""

    total: int
    passed: int
    failed: int
    pass_rate: float
    items: List[ScenarioReportItem]
    combined_result: Optional[AirflowAnalysisResult] = None
    generated_at: str = ""


# ─── Serialization ───────────────────────────────────────────────────────────


def _serialize_pattern(p: FailurePattern) -> dict:
    return {
        "pattern_type": p.pattern_type.value,
        "severity": p.severity.value,
        "confidence": p.confidence,
        "title": p.title,
        "description": p.description,
        "affected_dags": p.affected_dags,
        "affected_tasks": p.affected_tasks,
        "evidence": p.evidence,
        "environment": p.environment,
        "failure_count": p.failure_count,
    }


def _serialize_precursor(s: PrecursorSignal) -> dict:
    return {
        "signal_type": s.signal_type,
        "dag_id": s.dag_id,
        "task_id": s.task_id,
        "severity": s.severity.value,
        "confidence": s.confidence,
        "lead_time_minutes": s.lead_time_minutes,
        "description": s.description,
        "evidence": s.evidence,
    }


def _serialize_cluster(c: OpKwargsCluster) -> dict:
    return {
        "cluster_id": c.cluster_id,
        "common_keys": c.common_keys,
        "failure_count": c.failure_count,
        "affected_dags": c.affected_dags,
        "common_errors": c.common_errors,
        "description": c.description,
    }


def _serialize_correlation(cor: CrossDagCorrelation) -> dict:
    return {
        "dag_ids": cor.dag_ids,
        "correlation_strength": cor.correlation_strength,
        "co_occurrence_count": cor.co_occurrence_count,
        "time_window_minutes": cor.time_window_minutes,
        "root_cause_candidate": cor.root_cause_candidate,
        "failure_chain": cor.failure_chain,
        "common_error": cor.common_error,
        "description": cor.description,
    }


def _serialize_result(r: AirflowAnalysisResult) -> dict:
    return {
        "total_failures": r.total_failures,
        "environments_analyzed": r.environments_analyzed,
        "highest_severity": r.highest_severity.value,
        "severity_counts": r.severity_counts,
        "patterns": [_serialize_pattern(p) for p in r.patterns],
        "precursors": [_serialize_precursor(s) for s in r.precursors],
        "clusters": [_serialize_cluster(c) for c in r.clusters],
        "correlations": [_serialize_correlation(cor) for cor in r.correlations],
    }


def _build_kakao_preview(item: ScenarioReportItem) -> Optional[dict]:
    """카카오톡 알림 미리보기 데이터."""
    r = item.result
    if not r.patterns:
        return None

    severity = r.highest_severity
    emoji = SEVERITY_EMOJI.get(severity.value, "\U0001f4ca")
    env_ko = ENV_KO.get(item.environment, item.environment)

    sev_lines = []
    for sev in FailureSeverity:
        count = r.severity_counts.get(sev.value, 0)
        if count > 0:
            s_emoji = SEVERITY_EMOJI.get(sev.value, "")
            s_ko = SEVERITY_KO.get(sev, sev.value)
            sev_lines.append(f"  {s_emoji} {s_ko}: {count}건")

    pattern_lines = []
    for p in r.patterns[:3]:
        p_emoji = SEVERITY_EMOJI.get(p.severity.value, "")
        p_ko = PATTERN_KO.get(p.pattern_type, p.pattern_type.value)
        pattern_lines.append(f"  {p_emoji} [{p_ko}] {p.title}")
        if p.description:
            desc = p.description[:80] + ("..." if len(p.description) > 80 else "")
            pattern_lines.append(f"     {desc}")

    precursor_lines = []
    if r.precursors:
        precursor_lines.append(f"\n\u26a1 전조증상: {len(r.precursors)}건 감지")
        for sig in r.precursors[:2]:
            precursor_lines.append(f"  {sig.dag_id}/{sig.task_id}")

    corr_lines = []
    if r.correlations:
        corr_lines.append(f"\n\U0001f517 Cross-DAG: {len(r.correlations)}건")
        for corr in r.correlations[:2]:
            arrow = " \u2194 "
            dag_str = arrow.join(corr.dag_ids)
            corr_lines.append(
                f"  {dag_str}: {corr.correlation_strength:.0%}"
            )

    cluster_lines = []
    if r.clusters:
        cluster_lines.append(f"\n\U0001f4e6 op_kwargs 패턴: {len(r.clusters)}건")
        for c in r.clusters[:2]:
            keys = ", ".join(f"{k}={v}" for k, v in c.common_keys.items())
            cluster_lines.append(f"  {keys}: {c.failure_count}건")

    title = f"{emoji} Airflow 실패 패턴 탐지: {len(r.patterns)}건"

    msg_parts = [
        f"\U0001f4cb 총 {len(r.patterns)}건의 실패 패턴 탐지",
        f"\U0001f30d 환경: {env_ko}",
        "",
        "\u3010심각도 분포\u3011",
        *sev_lines,
        "",
        "\u3010주요 패턴\u3011",
        *pattern_lines,
    ]
    if precursor_lines:
        msg_parts.extend(precursor_lines)
    if corr_lines:
        msg_parts.extend(corr_lines)
    if cluster_lines:
        msg_parts.extend(cluster_lines)

    return {"title": title, "message": "\n".join(msg_parts)}


def _build_email_preview(item: ScenarioReportItem) -> Optional[dict]:
    """이메일 알림 미리보기 데이터."""
    r = item.result
    if not r.patterns:
        return None

    severity = r.highest_severity
    emoji = SEVERITY_EMOJI.get(severity.value, "\U0001f4ca")
    sev_ko = SEVERITY_KO.get(severity, severity.value)
    env_ko = ENV_KO.get(item.environment, item.environment)

    subject = f"[{severity.value.upper()}] Airflow 실패 패턴 탐지 - {env_ko}"

    body_lines = [
        "BDP Airflow 실패 패턴 탐지 알림",
        "",
        "\u2501" * 30,
        f"환경: {env_ko}",
        f"심각도: {emoji} {sev_ko}",
        f"탐지 패턴: {len(r.patterns)}건",
        f"총 실패: {r.total_failures}건",
        "\u2501" * 30,
        "",
        "\u25a0 탐지된 패턴",
    ]
    for i, p in enumerate(r.patterns[:5], 1):
        p_ko = PATTERN_KO.get(p.pattern_type, p.pattern_type.value)
        p_sev_ko = SEVERITY_KO.get(p.severity, p.severity.value)
        body_lines.append(f"  {i}. [{p_sev_ko}] {p_ko}: {p.title}")
        if p.description:
            desc = p.description[:100] + ("..." if len(p.description) > 100 else "")
            body_lines.append(f"     {desc}")

    if r.precursors:
        body_lines.extend(["", f"\u25a0 전조증상: {len(r.precursors)}건"])
        for sig in r.precursors[:3]:
            body_lines.append(
                f"  - {sig.dag_id}/{sig.task_id}: {sig.description[:80]}"
            )

    if r.correlations:
        body_lines.extend(["", f"\u25a0 Cross-DAG 상관관계: {len(r.correlations)}건"])
        for corr in r.correlations[:3]:
            arrow = " \u2192 "
            body_lines.append(f"  - {arrow.join(corr.dag_ids)}")

    body_lines.extend([
        "",
        "\u2501" * 30,
        "이 알림은 BDP Airflow Agent에서 자동 생성되었습니다.",
        "Airflow Console에서 상세 내용을 확인하세요.",
    ])

    return {
        "subject": subject,
        "from_name": "BDP Airflow Alert",
        "from_email": "alert-airflow@bdp.agent",
        "to": ["ops-team@bdp.example.com"],
        "body": "\n".join(body_lines),
    }


def serialize_scenario(item: ScenarioReportItem) -> dict:
    """시나리오를 JSON 직렬화."""
    return {
        "scenario_id": item.scenario_id,
        "scenario_name": item.scenario_name,
        "scenario_name_ko": item.scenario_name_ko,
        "description_ko": item.description_ko,
        "environment": item.environment,
        "expected_pattern": item.expected_pattern.value,
        "expected_severity": item.expected_severity.value,
        "passed": item.passed,
        "matched": item.matched,
        "total_signals": item.total_signals,
        "summary_text": item.summary_text,
        "result": _serialize_result(item.result),
        "kakao_preview": _build_kakao_preview(item),
        "email_preview": _build_email_preview(item),
    }


def serialize_summary(data: AirflowE2EReportData) -> dict:
    """요약 데이터를 JSON 직렬화."""
    severity_dist = Counter(it.expected_severity.value for it in data.items)
    pattern_dist = Counter(it.expected_pattern.value for it in data.items)

    combined = None
    if data.combined_result:
        cr = data.combined_result
        detected_types = sorted({p.pattern_type.value for p in cr.patterns})
        combined = {
            "total_failures": cr.total_failures,
            "patterns_count": len(cr.patterns),
            "pattern_types_count": len(detected_types),
            "pattern_types": detected_types,
            "severity_counts": cr.severity_counts,
            "precursors_count": len(cr.precursors),
            "clusters_count": len(cr.clusters),
            "correlations_count": len(cr.correlations),
        }

    labels = {
        "pattern_ko": {pt.value: ko for pt, ko in PATTERN_KO.items()},
        "pattern_icon": {pt.value: icon for pt, icon in PATTERN_ICON.items()},
        "severity_ko": {sev.value: ko for sev, ko in SEVERITY_KO.items()},
        "severity_emoji": SEVERITY_EMOJI,
        "env_ko": ENV_KO,
    }

    return {
        "generated_at": get_kst_now().strftime("%Y-%m-%d %H:%M:%S KST"),
        "total": data.total,
        "passed": data.passed,
        "failed": data.failed,
        "pass_rate": data.pass_rate,
        "scenarios": [],
        "severity_distribution": dict(severity_dist),
        "pattern_distribution": dict(pattern_dist),
        "combined_result": combined,
        "labels": labels,
    }


# ─── Report Generator ────────────────────────────────────────────────────────


class AirflowE2EReportGenerator:
    """JSON + HTML 리포트 생성기."""

    def generate_report(
        self,
        data: AirflowE2EReportData,
        output_dir: str,
    ) -> str:
        """JSON 파일들과 HTML 쉘 생성.

        Args:
            data: 리포트 데이터
            output_dir: 출력 디렉토리 (e.g., docs/bdp_airflow)

        Returns:
            HTML 파일 경로
        """
        out = Path(output_dir)
        data_dir = out / "data"
        data_dir.mkdir(parents=True, exist_ok=True)

        scenario_files = self._write_json_files(data, data_dir)

        html_path = out / "scenario_report.html"
        self._write_html(html_path)

        logger.info(
            "Report generated: %s (%d JSON files)",
            html_path,
            len(scenario_files) + 1,
        )
        return str(html_path)

    def _write_json_files(
        self,
        data: AirflowE2EReportData,
        data_dir: Path,
    ) -> List[str]:
        """시나리오별 JSON + summary.json 생성."""
        scenario_files = []
        for item in data.items:
            filename = f"scenario_{item.scenario_id:02d}_{item.scenario_name}.json"
            filepath = data_dir / filename
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(serialize_scenario(item), f, ensure_ascii=False, indent=2)
            scenario_files.append(filename)

        summary = serialize_summary(data)
        summary["scenarios"] = scenario_files
        with open(data_dir / "summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        return scenario_files

    def _write_html(self, path: Path) -> None:
        """정적 HTML 쉘 생성."""
        with open(path, "w", encoding="utf-8") as f:
            f.write(_HTML_TEMPLATE)


# ─── HTML Template ───────────────────────────────────────────────────────────

_HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BDP Airflow Agent - E2E 시나리오 테스트 리포트</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
/* ── Reset & Base ──────────────────────────────────────────────── */
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Pretendard',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F5F5F5;color:#212121;line-height:1.6}
.container{max-width:1200px;margin:0 auto;padding:20px}
/* ── Material Symbols ──────────────────────────────────────────── */
.ms{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;-webkit-font-feature-settings:'liga';-webkit-font-smoothing:antialiased;vertical-align:middle}
.ms-xs{font-size:14px}.ms-sm{font-size:18px}.ms-md{font-size:24px}.ms-lg{font-size:32px}
.ms-filled{font-variation-settings:'FILL' 1}
.ms-inline{vertical-align:-0.125em;margin-right:4px}
/* ── Header ────────────────────────────────────────────────────── */
.header{background:linear-gradient(135deg,#0D47A1 0%,#1565C0 50%,#1976D2 100%);color:#fff;padding:32px 0}
.header .container{display:flex;flex-direction:column;align-items:center}
.header h1{font-size:28px;color:#fff;display:flex;align-items:center;gap:8px}
.header .subtitle{color:rgba(255,255,255,.8);margin-top:4px;font-size:14px}
/* ── Cards ─────────────────────────────────────────────────────── */
.card{background:#FFF;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;padding:20px}
.card-header{border-bottom:1px solid #E0E0E0;padding-bottom:12px;margin-bottom:16px}
.card-title{font-size:18px;font-weight:600}
/* ── Stat Cards ────────────────────────────────────────────────── */
.grid{display:grid;gap:20px}.grid-5{grid-template-columns:repeat(5,1fr)}
.stat-card{text-align:center;padding:20px}
.stat-value{font-size:32px;font-weight:700}
.stat-label{font-size:14px;color:#757575;margin-top:4px}
/* ── Badges ────────────────────────────────────────────────────── */
.badge{display:inline-flex;align-items:center;gap:2px;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:500}
.badge-critical{background:#FFEBEE;color:#B71C1C;border:1px solid #D32F2F}
.badge-high{background:#FFF3E0;color:#E65100;border:1px solid #F57C00}
.badge-medium{background:#E3F2FD;color:#1565C0;border:1px solid #1976D2}
.badge-low{background:#F5F5F5;color:#757575;border:1px solid #BDBDBD}
/* ── Severity Distribution ─────────────────────────────────────── */
.sev-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px}
.sev-card{text-align:center;padding:16px;border-radius:8px;border-left:4px solid}
.sev-card .val{font-size:28px;font-weight:700}
.sev-card .lbl{font-size:12px;margin-top:4px;font-weight:500}
/* ── Pattern Distribution ──────────────────────────────────────── */
.pat-dist{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.pat-tag{padding:4px 12px;border-radius:16px;font-size:12px;font-weight:500;background:#E3F2FD;color:#1565C0;display:inline-flex;align-items:center;gap:4px}
/* ── Detection Matrix ──────────────────────────────────────────── */
.dm{width:100%;border-collapse:collapse;margin:12px 0}
.dm th,.dm td{padding:10px 14px;text-align:center;border:1px solid #E0E0E0;font-size:13px}
.dm th{background:#F5F5F5;font-weight:600;color:#212121}
.dm td:first-child{text-align:left;font-weight:500}
.dm .cy{background:#E8F5E9;color:#1B5E20;font-weight:bold}
.dm .cn{background:#F5F5F5;color:#757575}
.dm .cp{background:#388E3C;color:#fff;font-weight:bold}
.dm .cf{background:#D32F2F;color:#fff;font-weight:bold}
/* ── Filter Bar ────────────────────────────────────────────────── */
.fbar{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center}
.fbtn{padding:6px 16px;border:1px solid #BDBDBD;border-radius:20px;background:#FFF;cursor:pointer;font-size:13px;transition:all .2s;display:inline-flex;align-items:center;gap:4px}
.fbtn:hover{background:#F5F5F5}
.fbtn.active{background:#1976D2;color:#fff;border-color:#1976D2}
.fbar .actions{margin-left:auto;font-size:13px;color:#757575}
.fbar .actions a{cursor:pointer;text-decoration:underline;color:#757575}
/* ── Test Cards ────────────────────────────────────────────────── */
.tc{background:#FFF;border:1px solid #E0E0E0;border-radius:8px;margin-bottom:8px;overflow:hidden;transition:box-shadow .2s}
.tc:hover{box-shadow:0 2px 8px rgba(0,0,0,.1)}
.tc.pass{border-left:4px solid #388E3C}
.tc.fail{border-left:4px solid #D32F2F}
.tc-hdr{display:flex;align-items:center;padding:12px 16px;cursor:pointer;user-select:none;gap:12px}
.tc-hdr:hover{background:#F5F5F5}
.tc-status{flex-shrink:0}
.tc-id{font-weight:600;font-size:13px;color:#757575;min-width:40px}
.tc-name{flex:1;font-weight:500;font-size:14px}
.tc-meta{display:flex;gap:8px;align-items:center;flex-shrink:0}
.tc-chev{transition:transform .2s;color:#757575}
.tc.expanded .tc-chev{transform:rotate(180deg)}
.tc-body{display:none;padding:0 16px 16px;border-top:1px solid #E0E0E0}
.tc.expanded .tc-body{display:block}
/* ── Detail Grid ───────────────────────────────────────────────── */
.dgrid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px}
.dsec{background:#F5F5F5;border-radius:8px;padding:12px}
.dsec h4{font-size:13px;color:#757575;margin-bottom:8px;letter-spacing:.3px;display:flex;align-items:center;gap:4px}
.drow{display:flex;justify-content:space-between;padding:4px 0;font-size:13px}
.dlbl{color:#757575}.dval{font-weight:500}
/* ── Signal Tags ───────────────────────────────────────────────── */
.stag{display:inline-block;padding:3px 10px;border-radius:14px;font-size:12px;font-weight:500;margin:2px 4px 2px 0}
.stag.pattern{background:#E3F2FD;color:#1565C0}
.stag.precursor{background:#FFF3E0;color:#E65100}
.stag.cluster{background:#F3E5F5;color:#4A148C}
.stag.correlation{background:#E0F2F1;color:#004D40}
/* ── Summary Preview ───────────────────────────────────────────── */
.sprev{background:#F5F5F5;border-radius:8px;padding:16px;margin-top:12px;font-size:13px;line-height:1.6;white-space:pre-wrap;border-left:3px solid #1976D2}
/* ── Kakao Preview ─────────────────────────────────────────────── */
.kakao-sec{padding:16px;background:#F5F5F5;border-top:1px solid #E0E0E0;margin-top:12px;border-radius:0 0 8px 8px}
.kakao-sec h4{font-size:13px;color:#757575;margin-bottom:12px;display:flex;align-items:center;gap:4px}
.kakao-wrap{display:flex;justify-content:center}
.kakao-bubble{background:#FEE500;border-radius:15px;padding:15px;max-width:380px;width:100%;box-shadow:0 2px 8px rgba(0,0,0,.12)}
.kakao-title{font-weight:bold;font-size:14px;color:#3c1e1e;margin-bottom:8px}
.kakao-div{height:1px;background:rgba(60,30,30,.2);margin:8px 0}
.kakao-content{font-size:13px;color:#3c1e1e;line-height:1.6;white-space:pre-wrap}
/* ── Email Preview ─────────────────────────────────────────────── */
.email-sec{padding:16px;background:#F5F5F5;border-top:1px solid #E0E0E0;margin-top:12px;border-radius:0 0 8px 8px}
.email-sec h4{font-size:13px;color:#757575;margin-bottom:12px;display:flex;align-items:center;gap:4px}
.email-wrap{display:flex;justify-content:center}
.email-card{background:#FFF;border-radius:8px;max-width:500px;width:100%;box-shadow:0 2px 8px rgba(0,0,0,.12);overflow:hidden}
.email-hdr{background:#F5F5F5;padding:12px 16px;border-bottom:1px solid #E0E0E0;font-size:12px;color:#757575}
.email-hdr .field{display:flex;gap:8px;padding:2px 0}
.email-hdr .field .k{font-weight:600;min-width:40px;color:#424242}
.email-hdr .field .v{color:#212121}
.email-subj{padding:12px 16px;font-weight:600;font-size:14px;border-bottom:1px solid #E0E0E0;color:#212121}
.email-body{padding:16px;font-size:13px;line-height:1.6;white-space:pre-wrap;color:#424242;max-height:300px;overflow-y:auto}
/* ── Combined Pipeline ─────────────────────────────────────────── */
.comb{background:linear-gradient(135deg,#E3F2FD 0%,#FFF 100%);border:1px solid #1976D2;border-radius:12px;padding:24px;margin-top:32px}
.comb h3{color:#1565C0;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.comb-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px}
.comb-stat{text-align:center;padding:12px;background:rgba(255,255,255,.8);border-radius:8px}
.comb-stat .val{font-size:24px;font-weight:700;color:#1976D2}
.comb-stat .lbl{font-size:12px;color:#757575}
/* ── Loading & Error ───────────────────────────────────────────── */
.loading{text-align:center;padding:80px 20px;color:#757575}
.loading .spinner{width:48px;height:48px;border:4px solid #E0E0E0;border-top:4px solid #1976D2;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 16px}
@keyframes spin{to{transform:rotate(360deg)}}
.err-msg{text-align:center;padding:60px 20px;color:#D32F2F}
.err-msg code{display:block;margin-top:12px;padding:12px;background:#F5F5F5;border-radius:8px;color:#212121;font-size:13px}
/* ── Responsive ────────────────────────────────────────────────── */
@media(max-width:768px){
  .grid-5{grid-template-columns:repeat(2,1fr)}
  .sev-grid{grid-template-columns:repeat(2,1fr)}
  .dgrid{grid-template-columns:1fr}
  .comb-stats{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="header"><div class="container">
  <h1><span class="ms ms-lg ms-inline" style="color:#fff">air</span>BDP Airflow Agent - E2E 시나리오 테스트 리포트</h1>
  <p class="subtitle" id="gen-time"></p>
</div></div>
<div class="container" id="app">
  <div class="loading"><div class="spinner"></div>데이터 로딩 중...</div>
</div>
<script>
/* ═══════════════════════════════════════════════════════════════════
   BDP Airflow E2E Report — Client-side Rendering Engine
   ═══════════════════════════════════════════════════════════════════ */
const App = {
  summary: null,
  scenarios: [],
  L: {},

  /* ── Init ─────────────────────────────────────────────────────── */
  async init() {
    try {
      const sResp = await fetch('./data/summary.json');
      if (!sResp.ok) throw new Error('summary.json 로드 실패: ' + sResp.status);
      this.summary = await sResp.json();
      this.L = this.summary.labels || {};
      document.getElementById('gen-time').textContent = '생성 시각: ' + this.summary.generated_at;

      const promises = this.summary.scenarios.map(f =>
        fetch('./data/' + f).then(r => { if (!r.ok) throw new Error(f); return r.json(); })
      );
      this.scenarios = await Promise.all(promises);
      this.scenarios.sort((a, b) => a.scenario_id - b.scenario_id);
      this.render();
    } catch (e) {
      document.getElementById('app').innerHTML =
        '<div class="err-msg"><h2>데이터 로드 실패</h2>' +
        '<p>JSON 파일을 로드할 수 없습니다. HTTP 서버를 통해 접근해 주세요.</p>' +
        '<code>cd docs/bdp_airflow && python -m http.server 8080</code>' +
        '<p style="margin-top:12px;font-size:13px">오류: ' + this.esc(e.message) + '</p></div>';
    }
  },

  /* ── Render ───────────────────────────────────────────────────── */
  render() {
    const s = this.summary;
    const html = [
      '<p style="text-align:center;color:#757575;margin-bottom:24px">' + s.total + '개 시나리오 E2E 테스트 리포트</p>',
      this.renderSummaryCards(),
      this.renderSeverityDist(),
      this.renderPatternDist(),
      this.renderDetectionMatrix(),
      this.renderFilterBar(),
      this.renderScenarioCards(),
      this.renderCombinedPipeline(),
    ].join('\n');
    document.getElementById('app').innerHTML = html;
    this.bindEvents();
  },

  /* ── Events ──────────────────────────────────────────────────── */
  bindEvents() {
    document.addEventListener('click', e => {
      const hdr = e.target.closest('.tc-hdr');
      if (hdr) { hdr.closest('.tc').classList.toggle('expanded'); return; }
      const btn = e.target.closest('.fbtn');
      if (btn) {
        btn.closest('.fbar').querySelectorAll('.fbtn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const f = btn.dataset.filter;
        document.querySelectorAll('.tc').forEach(c => {
          c.style.display = f === 'all' ? '' : (f === 'pass' ? (c.classList.contains('pass') ? '' : 'none') : (c.classList.contains('fail') ? '' : 'none'));
        });
      }
    });
    window.toggleAll = expand => {
      document.querySelectorAll('.tc').forEach(c => { if (expand) c.classList.add('expanded'); else c.classList.remove('expanded'); });
    };
  },

  /* ── Utilities ───────────────────────────────────────────────── */
  esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; },
  icon(name, cls) { return '<span class="ms ' + (cls || 'ms-sm ms-inline') + '">' + name + '</span>'; },
  badge(sev) {
    const icons = {critical:'error',high:'warning',medium:'info',low:'check_circle'};
    const fill = (sev === 'critical' || sev === 'high') ? ' ms-filled' : '';
    return '<span class="badge badge-' + sev + '"><span class="ms ms-sm' + fill + '">' + (icons[sev]||'info') + '</span> ' + sev.toUpperCase() + '</span>';
  },
  pko(pt) { return (this.L.pattern_ko || {})[pt] || pt; },
  picon(pt) { return (this.L.pattern_icon || {})[pt] || 'category'; },
  sko(sev) { return (this.L.severity_ko || {})[sev] || sev; },
  eko(env) { return (this.L.env_ko || {})[env] || env; },

  /* ── Summary Cards ───────────────────────────────────────────── */
  renderSummaryCards() {
    const s = this.summary;
    const pc = s.pass_rate >= 85 ? '#388E3C' : (s.pass_rate >= 70 ? '#F57C00' : '#D32F2F');
    const tp = this.scenarios.reduce((a, sc) => a + sc.result.patterns.length, 0);
    const stats = [
      {l:'전체 시나리오',v:s.total,c:'#1976D2'},{l:'통과',v:s.passed,c:'#388E3C'},
      {l:'실패',v:s.failed,c:'#D32F2F'},{l:'통과율',v:s.pass_rate.toFixed(0)+'%',c:pc},
      {l:'탐지 패턴',v:tp,c:'#757575'},
    ];
    return '<div class="grid grid-5">' + stats.map(st =>
      '<div class="card stat-card"><div class="stat-value" style="color:' + st.c + '">' + st.v + '</div><div class="stat-label">' + st.l + '</div></div>'
    ).join('') + '</div>';
  },

  /* ── Severity Distribution ───────────────────────────────────── */
  renderSeverityDist() {
    const d = this.summary.severity_distribution;
    const cfg = {
      critical:{color:'#D32F2F',bg:'#FFEBEE',text:'#B71C1C'},
      high:{color:'#F57C00',bg:'#FFF3E0',text:'#E65100'},
      medium:{color:'#1976D2',bg:'#E3F2FD',text:'#1565C0'},
      low:{color:'#BDBDBD',bg:'#F5F5F5',text:'#757575'},
    };
    let cards = '';
    for (const sev of ['critical','high','medium','low']) {
      const c = cfg[sev]; const n = d[sev] || 0;
      cards += '<div class="sev-card" style="background:' + c.bg + ';border-left-color:' + c.color + '">' +
        '<div class="val" style="color:' + c.color + '">' + n + '</div>' +
        '<div class="lbl" style="color:' + c.text + '">' + sev.toUpperCase() + '</div></div>';
    }
    return this.card(this.icon('bar_chart') + ' 기대 심각도 분포', '<div class="sev-grid">' + cards + '</div>');
  },

  /* ── Pattern Distribution ────────────────────────────────────── */
  renderPatternDist() {
    const d = this.summary.pattern_distribution;
    const sorted = Object.entries(d).sort((a, b) => b[1] - a[1]);
    const tags = sorted.map(([pt, n]) =>
      '<span class="pat-tag">' + this.icon(this.picon(pt), 'ms ms-xs ms-inline') + ' ' + this.pko(pt) + ': ' + n + '</span>'
    ).join('');
    return this.card(this.icon('category') + ' 기대 패턴 유형 분포', '<div class="pat-dist">' + tags + '</div>');
  },

  /* ── Detection Matrix ────────────────────────────────────────── */
  renderDetectionMatrix() {
    const ths = ['#','시나리오','기대 패턴','심각도','패턴','전조증상','클러스터','상관관계','결과'];
    let rows = '';
    for (const sc of this.scenarios) {
      const r = sc.result;
      const pc = r.patterns.length, pr = r.precursors.length, cl = r.clusters.length, co = r.correlations.length;
      rows += '<tr>' +
        '<td>' + sc.scenario_id + '</td>' +
        '<td>' + this.esc(sc.scenario_name_ko) + '</td>' +
        '<td>' + this.pko(sc.expected_pattern) + '</td>' +
        '<td>' + this.badge(sc.expected_severity) + '</td>' +
        '<td class="' + (pc > 0 ? 'cy' : 'cn') + '">' + pc + '</td>' +
        '<td class="' + (pr > 0 ? 'cy' : 'cn') + '">' + pr + '</td>' +
        '<td class="' + (cl > 0 ? 'cy' : 'cn') + '">' + cl + '</td>' +
        '<td class="' + (co > 0 ? 'cy' : 'cn') + '">' + co + '</td>' +
        '<td class="' + (sc.passed ? 'cp' : 'cf') + '">' + (sc.passed ? 'PASS' : 'FAIL') + '</td></tr>';
    }
    const tbl = '<table class="dm"><thead><tr>' + ths.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>' + rows + '</tbody></table>';
    return this.card(this.icon('grid_on') + ' 탐지 결과 매트릭스', tbl);
  },

  /* ── Filter Bar ──────────────────────────────────────────────── */
  renderFilterBar() {
    const s = this.summary;
    return '<div class="fbar">' +
      '<button class="fbtn active" data-filter="all">' + this.icon('list','ms ms-xs ms-inline') + ' 전체 (' + s.total + ')</button>' +
      '<button class="fbtn" data-filter="pass">' + this.icon('check_circle','ms ms-xs ms-inline') + ' 통과 (' + s.passed + ')</button>' +
      '<button class="fbtn" data-filter="fail">' + this.icon('error','ms ms-xs ms-inline') + ' 실패 (' + s.failed + ')</button>' +
      '<span class="actions"><a onclick="toggleAll(true)">모두 펼치기</a> | <a onclick="toggleAll(false)">모두 접기</a></span></div>';
  },

  /* ── Scenario Cards ──────────────────────────────────────────── */
  renderScenarioCards() {
    return this.scenarios.map(sc => this.renderCard(sc)).join('\n');
  },

  renderCard(sc) {
    const cls = sc.passed ? 'pass' : 'fail';
    const sIcon = sc.passed ? 'check_circle' : 'error';
    const sClr = sc.passed ? ' style="color:#388E3C"' : ' style="color:#D32F2F"';
    const r = sc.result;

    // Header
    const hdr = '<div class="tc-hdr">' +
      '<div class="tc-status"><span class="ms ms-sm ms-filled"' + sClr + '>' + sIcon + '</span></div>' +
      '<div class="tc-id">#' + sc.scenario_id + '</div>' +
      '<div class="tc-name">' + this.esc(sc.scenario_name_ko) + '</div>' +
      '<div class="tc-meta">' + this.badge(sc.expected_severity) +
      '<span class="tc-chev"><span class="ms ms-sm">expand_more</span></span></div></div>';

    // Left: Expected
    const left = '<div class="dsec"><h4>' + this.icon('target','ms ms-xs ms-inline') + '기대값</h4>' +
      this.drow('패턴 유형', this.pko(sc.expected_pattern)) +
      this.drow('심각도', this.badge(sc.expected_severity)) +
      this.drow('환경', this.eko(sc.environment)) +
      this.drow('설명', '<span style="max-width:200px;text-align:right;display:inline-block">' + this.esc(sc.description_ko) + '</span>') +
      '</div>';

    // Signal tags
    let tags = '';
    r.patterns.slice(0, 5).forEach(p => { tags += '<span class="stag pattern">' + this.pko(p.pattern_type) + '</span>'; });
    r.precursors.slice(0, 3).forEach(s => { tags += '<span class="stag precursor">' + this.esc(s.signal_type) + '</span>'; });
    r.clusters.slice(0, 3).forEach(c => {
      const ks = Object.entries(c.common_keys).map(([k,v]) => k + '=' + v).join(', ');
      tags += '<span class="stag cluster">' + this.esc(ks) + '</span>';
    });
    r.correlations.slice(0, 3).forEach(c => { tags += '<span class="stag correlation">' + c.dag_ids.slice(0, 3).join(' / ') + '</span>'; });

    // Right: Detection
    const right = '<div class="dsec"><h4>' + this.icon('analytics','ms ms-xs ms-inline') + '탐지 결과</h4>' +
      this.drow('패턴', r.patterns.length + '건') +
      this.drow('전조증상', r.precursors.length + '건') +
      this.drow('클러스터', r.clusters.length + '건') +
      this.drow('상관관계', r.correlations.length + '건') +
      this.drow('총 신호', '<strong>' + sc.total_signals + '건</strong>') +
      '<div style="margin-top:8px">' + (tags || '<span style="font-size:12px;color:#757575">탐지 없음</span>') + '</div></div>';

    // Pattern detail table
    let patDetail = '';
    if (r.patterns.length > 0) {
      let prows = '';
      r.patterns.slice(0, 8).forEach(p => {
        const desc = p.description.length > 80 ? p.description.substring(0, 80) + '...' : p.description;
        prows += '<tr><td>' + this.pko(p.pattern_type) + '</td><td>' + this.badge(p.severity) + '</td>' +
          '<td>' + (p.confidence * 100).toFixed(0) + '%</td><td>' + this.esc(p.title) + '</td>' +
          '<td style="font-size:12px">' + this.esc(desc) + '</td></tr>';
      });
      patDetail = '<div style="margin-top:12px"><h4 style="font-size:13px;color:#757575;margin-bottom:8px;display:flex;align-items:center;gap:4px">' +
        this.icon('pattern','ms ms-xs ms-inline') + '탐지된 패턴 상세</h4>' +
        '<table class="dm" style="font-size:12px"><thead><tr><th>유형</th><th>심각도</th><th>신뢰도</th><th>제목</th><th>설명</th></tr></thead>' +
        '<tbody>' + prows + '</tbody></table></div>';
    }

    // Summary
    let summSec = '';
    if (sc.summary_text) {
      summSec = '<div style="margin-top:12px"><h4 style="font-size:13px;color:#757575;margin-bottom:8px;display:flex;align-items:center;gap:4px">' +
        this.icon('summarize','ms ms-xs ms-inline') + '한글 요약</h4><div class="sprev">' + this.esc(sc.summary_text) + '</div></div>';
    }

    // Kakao preview
    const kakaoSec = this.renderKakaoPreview(sc);

    // Email preview
    const emailSec = this.renderEmailPreview(sc);

    const body = '<div class="tc-body"><div class="dgrid">' + left + right + '</div>' + patDetail + summSec + kakaoSec + emailSec + '</div>';

    return '<div class="tc ' + cls + '" data-scenario="' + sc.scenario_id + '">' + hdr + body + '</div>';
  },

  /* ── Kakao Preview ───────────────────────────────────────────── */
  renderKakaoPreview(sc) {
    const kp = sc.kakao_preview;
    if (!kp) return '';
    return '<div class="kakao-sec"><h4>' + this.icon('chat','ms ms-xs ms-inline') + '카카오톡 알림 미리보기</h4>' +
      '<div class="kakao-wrap"><div class="kakao-bubble">' +
      '<div class="kakao-title">' + this.esc(kp.title) + '</div><div class="kakao-div"></div>' +
      '<div class="kakao-content">' + this.esc(kp.message) + '</div></div></div></div>';
  },

  /* ── Email Preview ───────────────────────────────────────────── */
  renderEmailPreview(sc) {
    const ep = sc.email_preview;
    if (!ep) return '';
    return '<div class="email-sec"><h4>' + this.icon('mail','ms ms-xs ms-inline') + '이메일 알림 미리보기</h4>' +
      '<div class="email-wrap"><div class="email-card">' +
      '<div class="email-hdr">' +
      '<div class="field"><span class="k">From:</span><span class="v">' + this.esc(ep.from_name) + ' &lt;' + this.esc(ep.from_email) + '&gt;</span></div>' +
      '<div class="field"><span class="k">To:</span><span class="v">' + this.esc(ep.to.join(', ')) + '</span></div></div>' +
      '<div class="email-subj">' + this.esc(ep.subject) + '</div>' +
      '<div class="email-body">' + this.esc(ep.body) + '</div></div></div></div>';
  },

  /* ── Combined Pipeline ───────────────────────────────────────── */
  renderCombinedPipeline() {
    const cr = this.summary.combined_result;
    if (!cr) return '';
    const typeTags = cr.pattern_types.map(pt =>
      '<span class="pat-tag">' + this.pko(pt) + ': ' +
      cr.severity_counts[pt] + '건</span>'
    );
    // Count patterns per type from scenario data
    const ptCounts = {};
    this.scenarios.forEach(sc => sc.result.patterns.forEach(p => {
      ptCounts[p.pattern_type] = (ptCounts[p.pattern_type] || 0) + 1;
    }));
    const typeTags2 = cr.pattern_types.map(pt =>
      '<span class="pat-tag">' + this.pko(pt) + '</span>'
    ).join('');

    let sevItems = '';
    for (const sev of ['critical','high','medium','low']) {
      const n = cr.severity_counts[sev] || 0;
      if (n > 0) sevItems += '<span>' + this.badge(sev) + ' ' + n + '건</span>';
    }

    return '<div class="comb"><h3>' + this.icon('merge','ms ms-md ms-inline') +
      '전체 통합 파이프라인 (' + this.summary.total + '개 시나리오 합산)</h3>' +
      '<div class="comb-stats">' +
      '<div class="comb-stat"><div class="val">' + cr.total_failures + '</div><div class="lbl">총 실패 건수</div></div>' +
      '<div class="comb-stat"><div class="val">' + cr.patterns_count + '</div><div class="lbl">탐지 패턴</div></div>' +
      '<div class="comb-stat"><div class="val">' + cr.pattern_types_count + '</div><div class="lbl">패턴 유형</div></div></div>' +
      '<div style="margin-bottom:12px"><strong>탐지된 패턴 유형:</strong><div class="pat-dist" style="margin-top:8px">' + typeTags2 + '</div></div>' +
      '<div style="margin-bottom:12px"><strong>심각도 분포:</strong><div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:8px">' + sevItems + '</div></div>' +
      '<div><strong>추가 신호:</strong><span style="margin-left:12px">' +
      '전조증상 ' + cr.precursors_count + '건 &nbsp;|&nbsp; ' +
      '클러스터 ' + cr.clusters_count + '건 &nbsp;|&nbsp; ' +
      '상관관계 ' + cr.correlations_count + '건</span></div></div>';
  },

  /* ── Helper: Card wrapper ────────────────────────────────────── */
  card(title, content) {
    return '<div class="card"><div class="card-header"><span class="card-title">' + title + '</span></div>' + content + '</div>';
  },

  /* ── Helper: Detail row ──────────────────────────────────────── */
  drow(label, value) {
    return '<div class="drow"><span class="dlbl">' + label + '</span><span class="dval">' + value + '</span></div>';
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
</script>
</body>
</html>
"""
