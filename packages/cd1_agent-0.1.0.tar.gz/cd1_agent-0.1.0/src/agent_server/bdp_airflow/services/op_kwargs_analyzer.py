"""
Op Kwargs Analyzer - op_kwargs 클러스터링.

op_kwargs JSON 파싱 → key_fields 추출 → 공통 key-value 조합별 그룹핑
→ min_cluster_size 이상 클러스터 식별 → err_msg 패턴과 교차 분석.
"""

import json
import logging
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

from src.agent_server.bdp_airflow.services.models import (
    AirflowFailureRecord,
    OpKwargsCluster,
)

logger = logging.getLogger(__name__)


class OpKwargsAnalyzer:
    """op_kwargs 기반 공통 실패 패턴 분석기.

    실패 레코드의 op_kwargs를 분석하여 공통 파라미터 패턴을 식별.
    예: 특정 table, database, bucket 등이 실패와 관련되는지 탐지.
    """

    def __init__(
        self,
        min_cluster_size: int = 3,
        key_fields: Optional[List[str]] = None,
    ):
        self.min_cluster_size = min_cluster_size
        self.key_fields = key_fields or [
            "table", "database", "query", "bucket", "path", "partition",
        ]

    def analyze(
        self,
        failures: List[AirflowFailureRecord],
    ) -> List[OpKwargsCluster]:
        """실패 레코드의 op_kwargs 분석.

        Args:
            failures: 실패 레코드 목록

        Returns:
            OpKwargsCluster 목록
        """
        if not failures:
            return []

        # 1. op_kwargs 파싱 및 key_fields 추출
        parsed_records: List[Tuple[AirflowFailureRecord, Dict[str, str]]] = []
        for r in failures:
            if not r.is_failed:
                continue
            kwargs = r.parsed_op_kwargs
            if not kwargs:
                continue

            # key_fields에 해당하는 값만 추출
            extracted = {}
            for key in self.key_fields:
                if key in kwargs:
                    extracted[key] = str(kwargs[key])
            if extracted:
                parsed_records.append((r, extracted))

        if not parsed_records:
            return []

        # 2. 각 key-value 쌍별 등장 빈도 계산
        kv_records: Dict[Tuple[str, str], List[AirflowFailureRecord]] = defaultdict(list)
        for record, extracted in parsed_records:
            for key, value in extracted.items():
                kv_records[(key, value)].append(record)

        # 3. min_cluster_size 이상인 key-value 쌍 필터
        clusters: List[OpKwargsCluster] = []
        seen_keys: Set[Tuple[str, str]] = set()

        for (key, value), records in sorted(
            kv_records.items(), key=lambda x: -len(x[1])
        ):
            if len(records) < self.min_cluster_size:
                continue

            if (key, value) in seen_keys:
                continue
            seen_keys.add((key, value))

            affected_dags = list({r.dag_id for r in records})
            affected_tasks = list({r.task_id for r in records})
            common_errors = list({r.err_msg for r in records if r.err_msg})[:5]

            cluster = OpKwargsCluster(
                cluster_id=f"{key}={value}",
                common_keys={key: value},
                failure_count=len(records),
                affected_dags=affected_dags,
                affected_tasks=affected_tasks,
                common_errors=common_errors,
                description=(
                    f"op_kwargs에서 {key}={value}를 공통으로 갖는 "
                    f"{len(records)}건의 실패가 발견되었습니다. "
                    f"영향 DAG: {', '.join(affected_dags[:3])}"
                ),
            )
            clusters.append(cluster)

        # 4. 복합 key 클러스터 탐지 (2개 이상 key가 동일한 경우)
        clusters.extend(self._detect_multi_key_clusters(parsed_records))

        return clusters

    def _detect_multi_key_clusters(
        self,
        parsed_records: List[Tuple[AirflowFailureRecord, Dict[str, str]]],
    ) -> List[OpKwargsCluster]:
        """복합 key 클러스터 탐지 (2개 이상 공통 key-value)."""
        clusters = []

        # key 조합별 그룹핑
        combo_records: Dict[str, List[AirflowFailureRecord]] = defaultdict(list)
        combo_keys: Dict[str, Dict[str, str]] = {}

        for record, extracted in parsed_records:
            if len(extracted) < 2:
                continue
            # 정렬된 key-value 문자열로 시그니처 생성
            sig = "|".join(f"{k}={v}" for k, v in sorted(extracted.items()))
            combo_records[sig].append(record)
            combo_keys[sig] = extracted

        for sig, records in combo_records.items():
            if len(records) < self.min_cluster_size:
                continue

            keys = combo_keys[sig]
            affected_dags = list({r.dag_id for r in records})
            affected_tasks = list({r.task_id for r in records})
            common_errors = list({r.err_msg for r in records if r.err_msg})[:5]

            keys_str = ", ".join(f"{k}={v}" for k, v in keys.items())
            cluster = OpKwargsCluster(
                cluster_id=sig,
                common_keys=keys,
                failure_count=len(records),
                affected_dags=affected_dags,
                affected_tasks=affected_tasks,
                common_errors=common_errors,
                description=(
                    f"op_kwargs에서 [{keys_str}]를 공통으로 갖는 "
                    f"{len(records)}건의 실패가 발견되었습니다."
                ),
            )
            clusters.append(cluster)

        return clusters
