"""
Airflow Summary Generator - 한글 Rich Summary 생성.

패턴별 설명 생성, DAG별/환경별 요약, severity emoji 포함.
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_airflow.services.models import (
    AirflowAnalysisResult,
    AirflowEnvironment,
    CrossDagCorrelation,
    FailurePattern,
    FailurePatternType,
    FailureSeverity,
    OpKwargsCluster,
    PrecursorSignal,
)

logger = logging.getLogger(__name__)


@dataclass
class AirflowAlertSummary:
    """Airflow 알림 요약."""

    title: str
    message: str
    severity_emoji: str
    total_patterns: int
    total_failures: int
    timestamp: str


class AirflowSummaryGenerator:
    """Airflow 분석 결과를 한글 Rich Summary로 변환.

    severity emoji, DAG별/환경별 요약, 패턴별 설명을 생성합니다.
    """

    SEVERITY_EMOJI = {
        FailureSeverity.CRITICAL: "🚨",
        FailureSeverity.HIGH: "⚠️",
        FailureSeverity.MEDIUM: "📊",
        FailureSeverity.LOW: "ℹ️",
    }

    SEVERITY_KOREAN = {
        FailureSeverity.CRITICAL: "심각",
        FailureSeverity.HIGH: "높음",
        FailureSeverity.MEDIUM: "보통",
        FailureSeverity.LOW: "낮음",
    }

    PATTERN_KOREAN = {
        FailurePatternType.SINGLE_TASK: "단일 태스크 실패",
        FailurePatternType.CASCADING: "캐스케이딩 실패",
        FailurePatternType.RECURRING: "반복 실패",
        FailurePatternType.CROSS_DAG: "Cross-DAG 상관 실패",
        FailurePatternType.DURATION_ANOMALY: "Duration 이상",
        FailurePatternType.PRECURSOR: "전조증상",
        FailurePatternType.OP_KWARGS_CLUSTER: "op_kwargs 패턴",
        FailurePatternType.TIME_BASED: "시간대별 패턴",
        FailurePatternType.ENVIRONMENT_SPECIFIC: "환경 특이 패턴",
        FailurePatternType.SILENT_WARNING: "사일런트 워닝",
        FailurePatternType.SAGEMAKER_PIPELINE: "SageMaker 파이프라인 실패",
        FailurePatternType.EMR_CLUSTER: "EMR 클러스터 실패",
        FailurePatternType.SFTP_TRANSFER: "SFTP 전송 실패",
        FailurePatternType.SCHEDULER_OVERLOAD: "스케줄러 과부하",
        FailurePatternType.WORKER_RESOURCE: "워커 리소스 부족",
        FailurePatternType.EXTERNAL_API: "외부 API 호출 실패",
        FailurePatternType.DATA_PIPELINE_COPY: "데이터 파이프라인 COPY 실패",
        FailurePatternType.CONCURRENCY_LIMIT: "동시성 제한 초과",
        FailurePatternType.DEPLOYMENT_REGRESSION: "배포 후 회귀 실패",
        FailurePatternType.INFRA_COMPOUND: "인프라 복합 장애",
    }

    def generate(self, result: AirflowAnalysisResult) -> AirflowAlertSummary:
        """분석 결과 → 한글 요약 생성.

        Args:
            result: 전체 분석 결과

        Returns:
            AirflowAlertSummary 객체
        """
        if not result.patterns:
            return AirflowAlertSummary(
                title="✅ Airflow 정상",
                message="분석 기간 내 유의미한 실패 패턴이 탐지되지 않았습니다.",
                severity_emoji="✅",
                total_patterns=0,
                total_failures=result.total_failures,
                timestamp=get_kst_now().isoformat(),
            )

        severity = result.highest_severity
        emoji = self.SEVERITY_EMOJI.get(severity, "📊")
        severity_counts = result.severity_counts

        # 제목
        title = f"{emoji} Airflow 실패 패턴 탐지: {len(result.patterns)}건"

        # 메시지 본문 구성
        lines = [
            f"총 {len(result.patterns)}건의 실패 패턴이 탐지되었습니다.",
            "",
        ]

        # 심각도별 카운트
        lines.append("【심각도 분포】")
        for sev in FailureSeverity:
            count = severity_counts.get(sev.value, 0)
            if count > 0:
                sev_emoji = self.SEVERITY_EMOJI.get(sev, "")
                sev_ko = self.SEVERITY_KOREAN.get(sev, sev.value)
                lines.append(f"  {sev_emoji} {sev_ko}: {count}건")
        lines.append("")

        # 환경별 요약
        envs = result.environments_analyzed
        if envs:
            env_labels = [AirflowEnvironment(e).label for e in envs if e in ("dlk", "wfl")]
            lines.append(f"【분석 환경】 {', '.join(env_labels)}")
            lines.append("")

        # 주요 패턴 상세
        lines.append("【주요 패턴】")
        for pattern in result.patterns[:5]:
            p_emoji = self.SEVERITY_EMOJI.get(pattern.severity, "")
            p_type = self.PATTERN_KOREAN.get(pattern.pattern_type, pattern.pattern_type.value)
            lines.append(f"  {p_emoji} [{p_type}] {pattern.title}")
            if pattern.description:
                lines.append(f"     {pattern.description[:150]}")

        if len(result.patterns) > 5:
            lines.append(f"  ... 외 {len(result.patterns) - 5}건")
        lines.append("")

        # 전조증상 요약
        if result.precursors:
            lines.append(f"【전조증상】 {len(result.precursors)}건 감지")
            for signal in result.precursors[:3]:
                lines.append(
                    f"  ⚡ {signal.dag_id}/{signal.task_id}: {signal.description[:100]}"
                )
            lines.append("")

        # Cross-DAG 상관관계 요약
        if result.correlations:
            lines.append(f"【Cross-DAG 상관관계】 {len(result.correlations)}건")
            for corr in result.correlations[:3]:
                lines.append(
                    f"  🔗 {' ↔ '.join(corr.dag_ids)}: "
                    f"상관 강도 {corr.correlation_strength:.0%}"
                )
            lines.append("")

        # op_kwargs 클러스터 요약
        if result.clusters:
            lines.append(f"【op_kwargs 공통 패턴】 {len(result.clusters)}건")
            for cluster in result.clusters[:3]:
                keys_str = ", ".join(f"{k}={v}" for k, v in cluster.common_keys.items())
                lines.append(f"  📦 {keys_str}: {cluster.failure_count}건 실패")
            lines.append("")

        message = "\n".join(lines)

        return AirflowAlertSummary(
            title=title,
            message=message,
            severity_emoji=emoji,
            total_patterns=len(result.patterns),
            total_failures=result.total_failures,
            timestamp=get_kst_now().isoformat(),
        )

    def generate_dag_summary(
        self,
        dag_id: str,
        patterns: List[FailurePattern],
        precursors: List[PrecursorSignal],
    ) -> str:
        """특정 DAG에 대한 상세 요약 생성.

        Args:
            dag_id: DAG ID
            patterns: 해당 DAG 관련 패턴
            precursors: 해당 DAG 관련 전조증상

        Returns:
            한글 요약 문자열
        """
        lines = [f"【{dag_id} 상세 분석】", ""]

        if patterns:
            lines.append(f"탐지된 패턴: {len(patterns)}건")
            for p in patterns:
                emoji = self.SEVERITY_EMOJI.get(p.severity, "")
                p_type = self.PATTERN_KOREAN.get(p.pattern_type, p.pattern_type.value)
                lines.append(f"  {emoji} [{p_type}] {p.description}")
            lines.append("")

        if precursors:
            lines.append(f"전조증상: {len(precursors)}건")
            for s in precursors:
                lines.append(f"  ⚡ {s.description}")
            lines.append("")

        if not patterns and not precursors:
            lines.append("특별한 이상 패턴이 발견되지 않았습니다.")

        return "\n".join(lines)
