"""
Cross-DAG Analyzer - DAG간 상관관계 분석.

시간 윈도우 내 동시 발생 DAG 실패를 그룹핑하고,
공동 발생 빈도 기반 상관 강도를 계산합니다.
"""

import logging
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from itertools import combinations
from typing import Any, Dict, List, Optional, Set, Tuple

from src.agent_server.bdp_airflow.services.models import (
    AirflowFailureRecord,
    CrossDagCorrelation,
)

logger = logging.getLogger(__name__)


class CrossDagAnalyzer:
    """Cross-DAG 상관관계 분석기.

    시간 윈도우 내 동시 발생 DAG 실패를 분석하여
    상관관계, root cause 후보, 의존성 체인을 도출합니다.
    """

    def __init__(
        self,
        time_window_minutes: int = 30,
        min_correlated_failures: int = 2,
    ):
        self.time_window_minutes = time_window_minutes
        self.min_correlated_failures = min_correlated_failures

    def analyze(
        self,
        failures: List[AirflowFailureRecord],
    ) -> List[CrossDagCorrelation]:
        """실패 레코드 분석 → Cross-DAG 상관관계 목록 반환.

        Args:
            failures: 실패 레코드 목록

        Returns:
            CrossDagCorrelation 목록
        """
        if not failures:
            return []

        # 실패 건만 필터
        failed = [r for r in failures if r.is_failed]
        if len(failed) < 2:
            return []

        # 1. 시간 윈도우 내 동시 발생 그룹핑
        time_groups = self._group_by_time_window(failed)

        # 2. DAG 쌍별 공동 발생 빈도 계산
        pair_counts: Counter = Counter()
        pair_groups: Dict[Tuple[str, str], List[List[AirflowFailureRecord]]] = defaultdict(list)

        for group in time_groups:
            dag_ids = list({r.dag_id for r in group})
            if len(dag_ids) < 2:
                continue

            for pair in combinations(sorted(dag_ids), 2):
                pair_counts[pair] += 1
                pair_groups[pair].append(group)

        # 3. 상관관계 생성
        correlations: List[CrossDagCorrelation] = []

        for pair, count in pair_counts.most_common():
            if count < self.min_correlated_failures:
                continue

            dag_a, dag_b = pair
            groups = pair_groups[pair]

            # Root cause 후보 (시간순 최초 실패 DAG)
            root_cause = self._find_root_cause(groups, dag_a, dag_b)

            # 실패 체인 도출
            failure_chain = self._build_failure_chain(groups)

            # 공통 에러 메시지 찾기
            common_error = self._find_common_error(groups)

            # 상관 강도 계산 (공동 발생 비율)
            total_failures_a = sum(1 for r in failed if r.dag_id == dag_a)
            total_failures_b = sum(1 for r in failed if r.dag_id == dag_b)
            max_possible = min(total_failures_a, total_failures_b)
            strength = count / max_possible if max_possible > 0 else 0

            correlations.append(CrossDagCorrelation(
                dag_ids=[dag_a, dag_b],
                correlation_strength=round(strength, 3),
                co_occurrence_count=count,
                time_window_minutes=self.time_window_minutes,
                root_cause_candidate=root_cause,
                failure_chain=failure_chain,
                common_error=common_error,
                description=(
                    f"{dag_a}와 {dag_b}가 {self.time_window_minutes}분 윈도우 내 "
                    f"{count}회 동시 실패했습니다 (상관 강도: {strength:.0%})."
                    + (f" Root cause 후보: {root_cause}" if root_cause else "")
                ),
            ))

        # 상관 강도 내림차순 정렬
        correlations.sort(key=lambda c: -c.correlation_strength)

        return correlations

    def _group_by_time_window(
        self,
        records: List[AirflowFailureRecord],
    ) -> List[List[AirflowFailureRecord]]:
        """시간 윈도우 내 동시 발생 레코드 그룹핑."""
        if not records:
            return []

        # 시간순 정렬
        sorted_recs = sorted(records, key=lambda r: r.start_date)

        groups: List[List[AirflowFailureRecord]] = []
        current_group: List[AirflowFailureRecord] = [sorted_recs[0]]

        for i in range(1, len(sorted_recs)):
            try:
                t_prev = datetime.strptime(
                    current_group[0].start_date[:19], "%Y-%m-%d %H:%M:%S"
                )
                t_curr = datetime.strptime(
                    sorted_recs[i].start_date[:19], "%Y-%m-%d %H:%M:%S"
                )

                if (t_curr - t_prev).total_seconds() <= self.time_window_minutes * 60:
                    current_group.append(sorted_recs[i])
                else:
                    if len(current_group) >= 2:
                        groups.append(current_group)
                    current_group = [sorted_recs[i]]
            except (ValueError, TypeError):
                continue

        # 마지막 그룹 처리
        if len(current_group) >= 2:
            groups.append(current_group)

        return groups

    def _find_root_cause(
        self,
        groups: List[List[AirflowFailureRecord]],
        dag_a: str,
        dag_b: str,
    ) -> Optional[str]:
        """시간순 최초 실패 DAG을 root cause 후보로 식별."""
        first_counts: Counter = Counter()

        for group in groups:
            sorted_group = sorted(group, key=lambda r: r.start_date)
            relevant = [r for r in sorted_group if r.dag_id in (dag_a, dag_b)]
            if relevant:
                first_counts[relevant[0].dag_id] += 1

        if first_counts:
            return first_counts.most_common(1)[0][0]
        return None

    def _build_failure_chain(
        self,
        groups: List[List[AirflowFailureRecord]],
    ) -> List[str]:
        """가장 대표적인 실패 체인 도출."""
        if not groups:
            return []

        # 가장 큰 그룹 기준
        largest = max(groups, key=len)
        sorted_group = sorted(largest, key=lambda r: r.start_date)

        seen: Set[str] = set()
        chain: List[str] = []
        for r in sorted_group:
            if r.dag_id not in seen:
                chain.append(r.dag_id)
                seen.add(r.dag_id)

        return chain

    def _find_common_error(
        self,
        groups: List[List[AirflowFailureRecord]],
    ) -> Optional[str]:
        """그룹 간 공통 에러 메시지 찾기."""
        all_errors: Counter = Counter()
        for group in groups:
            for r in group:
                if r.err_msg:
                    # 에러 메시지의 핵심 부분만 추출
                    err_key = r.err_msg[:100]
                    all_errors[err_key] += 1

        if all_errors:
            most_common, count = all_errors.most_common(1)[0]
            if count >= self.min_correlated_failures:
                return most_common
        return None
