"""
BDP Airflow Agent - E2E Runner Service.

E2E 시나리오 테스트를 실행하고 리포트를 생성하는 서비스 클래스.
scripts/run_airflow_e2e.py의 핵심 로직을 캡슐화.
"""

import html as html_mod
import json
import time
import urllib.parse
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from src.agent_server.bdp_airflow.services.cross_dag_analyzer import CrossDagAnalyzer
from src.agent_server.bdp_airflow.services.e2e_ssr_report_generator import (
    AirflowE2EGroupResult,
    AirflowE2EReportData,
    AirflowE2ESSRReportGenerator,
    AirflowE2ETestResult,
    PATTERN_KO,
)
from src.agent_server.bdp_airflow.services.failure_detector import AirflowFailureDetector
from src.agent_server.bdp_airflow.services.models import (
    AirflowAnalysisResult,
    FailurePatternType,
    FailureSeverity,
)
from src.agent_server.bdp_airflow.services.op_kwargs_analyzer import OpKwargsAnalyzer
from src.agent_server.bdp_airflow.services.precursor_analyzer import PrecursorAnalyzer
from src.agent_server.bdp_airflow.services.summary_generator import AirflowSummaryGenerator


@dataclass
class E2ERunResult:
    """E2E 실행 결과."""

    pass_rate: float
    passed: int
    failed: int
    total: int
    e2e_report_path: str
    daily_report_path: str
    scenarios: List[Dict[str, Any]]


# ── Constants ──

SEVERITY_GROUPS = {
    "critical": ("1", "심각 시나리오"),
    "high": ("2", "높음 시나리오"),
    "medium": ("3", "보통 시나리오"),
    "low": ("4", "낮음 시나리오"),
}

SEVERITY_EMOJI = {
    "critical": "🚨", "high": "⚠️", "medium": "📊", "low": "ℹ️",
}

SEVERITY_KO = {
    "critical": "심각", "high": "높음", "medium": "보통", "low": "낮음",
}

ENV_KO = {
    "dlk": "입수 파이프라인", "wfl": "사용자 워크플로우", "dlk+wfl": "입수 + 워크플로우",
}


class AirflowE2ERunner:
    """E2E 시나리오 테스트 실행기 (Mock 전용)."""

    def __init__(self):
        self._summary_generator = AirflowSummaryGenerator()

    def run_all(self, output_dir: str = "reports/") -> E2ERunResult:
        """전체 E2E 시나리오 실행 및 리포트 생성."""
        from tests.agents.bdp_airflow.scenarios.scenario_factory import ScenarioFactory

        # 1. 시나리오 로드
        scenarios = ScenarioFactory.get_all_scenarios()
        all_records = ScenarioFactory.generate_all_records()

        # 2. 시나리오 실행
        results: List[AirflowE2ETestResult] = []
        for scenario in scenarios:
            result = self._run_scenario(scenario, all_records)
            results.append(result)

        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        pass_rate = (passed / len(results) * 100) if results else 0

        # 3. E2E 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        report_data = self._build_report_data(results)
        e2e_path = str(output_path / "airflow_e2e_report.html")
        AirflowE2ESSRReportGenerator().generate_report(report_data, e2e_path)

        # 4. Daily Report 생성
        daily_path = str(output_path / "airflow_daily_report.html")
        _generate_daily_report(results, daily_path)

        return E2ERunResult(
            pass_rate=pass_rate,
            passed=passed,
            failed=failed,
            total=len(results),
            e2e_report_path=e2e_path,
            daily_report_path=daily_path,
            scenarios=[
                {
                    "scenario_id": r.scenario_id,
                    "scenario_name_ko": r.scenario_name_ko,
                    "passed": r.passed,
                    "expected_severity": r.expected_severity,
                    "expected_pattern": r.expected_pattern,
                }
                for r in results
            ],
        )

    def _run_scenario(self, scenario, all_records) -> AirflowE2ETestResult:
        """단일 시나리오 실행."""
        records = all_records[scenario.id]
        cross_dag_min = 1 if scenario.id == 3 else 2

        start = time.perf_counter()
        result = _run_pipeline(records, cross_dag_min=cross_dag_min)
        elapsed_ms = (time.perf_counter() - start) * 1000

        total_signals = (
            len(result.patterns)
            + len(result.precursors)
            + len(result.clusters)
            + len(result.correlations)
        )

        expected_type = scenario.pattern_type
        matched = False

        if expected_type == FailurePatternType.PRECURSOR:
            matched = len(result.precursors) >= 1
        elif expected_type == FailurePatternType.OP_KWARGS_CLUSTER:
            matched = len(result.clusters) >= 1
        elif expected_type == FailurePatternType.CROSS_DAG:
            matched = (
                any(p.pattern_type == FailurePatternType.CROSS_DAG for p in result.patterns)
                or len(result.correlations) >= 1
            )
        else:
            matched = any(p.pattern_type == expected_type for p in result.patterns)

        passed = matched and total_signals >= 1

        detected_patterns = []
        for p in result.patterns:
            detected_patterns.append({
                "pattern_type": p.pattern_type.value,
                "severity": p.severity.value,
                "confidence": p.confidence,
                "title": p.title,
                "description": p.description,
            })

        alert_summary = self._summary_generator.generate(result)
        summary_text = f"{alert_summary.title}\n\n{alert_summary.message}"

        kakao_preview = _build_kakao_preview(result, scenario.environment, scenario=scenario)

        return AirflowE2ETestResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            scenario_name_ko=scenario.name_ko,
            description_ko=scenario.description_ko,
            environment=scenario.environment,
            expected_pattern=scenario.pattern_type.value,
            expected_severity=scenario.expected_severity.value,
            passed=passed,
            matched=matched,
            total_signals=total_signals,
            pattern_count=len(result.patterns),
            precursor_count=len(result.precursors),
            cluster_count=len(result.clusters),
            correlation_count=len(result.correlations),
            detected_patterns=detected_patterns,
            summary_text=summary_text,
            kakao_preview=kakao_preview,
            execution_time_ms=elapsed_ms,
            root_cause=scenario.root_cause,
            investigated_logs=scenario.investigated_logs,
            recommended_actions=scenario.recommended_actions,
            ai_confidence=scenario.ai_confidence,
        )

    @staticmethod
    def _build_report_data(results) -> AirflowE2EReportData:
        """리포트 데이터 빌드."""
        grouped = defaultdict(list)
        for r in results:
            gid, gname = SEVERITY_GROUPS.get(r.expected_severity, ("9", "기타"))
            grouped[gid].append((gname, r))

        group_results = []
        for gid in sorted(grouped.keys()):
            items = grouped[gid]
            g_name = items[0][0]
            g_results = [item[1] for item in items]
            g_passed = sum(1 for r in g_results if r.passed)
            g_total = len(g_results)
            group_results.append(
                AirflowE2EGroupResult(
                    group_id=gid,
                    group_name=g_name,
                    total=g_total,
                    passed=g_passed,
                    failed=g_total - g_passed,
                    pass_rate=(g_passed / g_total * 100) if g_total else 0,
                    results=g_results,
                )
            )

        total = len(results)
        passed = sum(1 for r in results if r.passed)
        all_latencies = [r.execution_time_ms for r in results]

        return AirflowE2EReportData(
            total=total,
            passed=passed,
            failed=total - passed,
            pass_rate=(passed / total * 100) if total else 0,
            avg_latency_ms=sum(all_latencies) / len(all_latencies) if all_latencies else 0,
            groups=group_results,
            all_results=results,
        )


# ── Pipeline helpers ──


def _run_pipeline(records, cross_dag_min=2):
    """전체 분석 파이프라인 실행."""
    detector = AirflowFailureDetector()
    precursor = PrecursorAnalyzer()
    opkwargs = OpKwargsAnalyzer()
    crossdag = CrossDagAnalyzer(min_correlated_failures=cross_dag_min)

    patterns = detector.analyze(records, records)
    precursors = precursor.analyze(records)
    clusters = opkwargs.analyze(records)
    correlations = crossdag.analyze(records)

    total_failures = sum(1 for r in records if r.is_failed)
    envs = list({r.rcpt_tp for r in records})

    return AirflowAnalysisResult(
        patterns=patterns,
        precursors=precursors,
        clusters=clusters,
        correlations=correlations,
        total_failures=total_failures,
        environments_analyzed=envs,
        analysis_window_hours=24,
    )


def _build_natural_description(result, environment: str, scenario=None) -> str:
    """분석 결과를 자연어 설명으로 변환."""
    env_ko = ENV_KO.get(environment, environment)
    sev_ko = SEVERITY_KO.get(result.highest_severity.value, "보통")

    affected_dags = set()
    for p in result.patterns:
        affected_dags.update(p.affected_dags)
    dag_str = ", ".join(sorted(affected_dags)[:3])
    if len(affected_dags) > 3:
        dag_str += f" 외 {len(affected_dags) - 3}개"

    primary = result.patterns[0]
    p_ko = PATTERN_KO.get(primary.pattern_type.value, primary.pattern_type.value)

    lines = []
    lines.append(f"{env_ko}에서 {p_ko} 패턴이 탐지되었습니다.")

    if primary.description:
        lines.append(primary.description[:150])

    if dag_str:
        lines.append("")
        lines.append(f"영향 DAG: {dag_str}")

    extras = []
    if len(result.patterns) > 1:
        extras.append(f"추가 패턴 {len(result.patterns) - 1}건")
    if result.precursors:
        extras.append(f"전조증상 {len(result.precursors)}건")
    if result.correlations:
        extras.append(f"Cross-DAG 상관관계 {len(result.correlations)}건")
    if result.clusters:
        extras.append(f"op_kwargs 공통 패턴 {len(result.clusters)}건")
    if extras:
        lines.append("함께 탐지: " + ", ".join(extras))

    if scenario and scenario.root_cause:
        cause_short = scenario.root_cause[:120]
        lines.append("")
        lines.append(f"[원인분석] {cause_short}")
        if scenario.recommended_actions:
            lines.append("[권장조치]")
            for i, action in enumerate(scenario.recommended_actions[:3], 1):
                lines.append(f"{i}. {action}")

    if result.highest_severity.value in ("critical", "high"):
        lines.append("")
        lines.append("즉각적인 확인이 필요합니다.")

    conf_str = ""
    if scenario and scenario.ai_confidence > 0:
        conf_str = f" | 신뢰도: {int(scenario.ai_confidence * 100)}%"
    lines.append("")
    lines.append(f"[환경: {env_ko} | 심각도: {sev_ko} | 총 실패: {result.total_failures}건{conf_str}]")

    return "\n".join(lines)


def _build_kakao_preview(result, environment: str, scenario=None) -> dict:
    """카카오톡 알림 미리보기 생성."""
    if not result.patterns:
        return {}

    severity = result.highest_severity
    emoji = SEVERITY_EMOJI.get(severity.value, "")

    primary = result.patterns[0]
    p_ko = PATTERN_KO.get(primary.pattern_type.value, primary.pattern_type.value)
    env_ko = ENV_KO.get(environment, environment)

    title = f"{emoji} Airflow {p_ko}: {env_ko}".strip()
    message = _build_natural_description(result, environment, scenario=scenario)

    return {"title": title, "message": message}


# ── Daily Report Generator ──


def _build_quickchart_url(chart_config: dict) -> str:
    base = "https://quickchart.io/chart"
    encoded = urllib.parse.quote(json.dumps(chart_config))
    return f"{base}?c={encoded}&w=480&h=300&bkg=white"


def _generate_daily_report(results: list, output_path: str):
    """전체 시나리오의 Daily Report를 별도 HTML로 생성 (Material Design)."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    total = len(results)
    passed = sum(1 for r in results if r.passed)
    failed = total - passed
    with_patterns = sum(1 for r in results if r.pattern_count > 0)

    sev_dist = Counter(r.expected_severity for r in results)
    pat_dist = Counter(r.expected_pattern for r in results)

    # ── Summary Stats Cards ──
    stats_html = f"""<div class="stats-grid">
        <div class="stat-card"><div class="stat-icon"><span class="ms ms-md">assignment</span></div>
            <div class="stat-value" style="color:#1976D2">{total}</div><div class="stat-label">전체 시나리오</div></div>
        <div class="stat-card"><div class="stat-icon"><span class="ms ms-md">check_circle</span></div>
            <div class="stat-value" style="color:#388E3C">{passed}</div><div class="stat-label">통과</div></div>
        <div class="stat-card"><div class="stat-icon"><span class="ms ms-md">error</span></div>
            <div class="stat-value" style="color:#D32F2F">{failed}</div><div class="stat-label">실패</div></div>
        <div class="stat-card"><div class="stat-icon"><span class="ms ms-md">pattern</span></div>
            <div class="stat-value" style="color:#7B1FA2">{with_patterns}</div><div class="stat-label">패턴 탐지</div></div>
    </div>"""

    # ── Table ──
    sev_icons = {
        "critical": '<span class="ms ms-xs" style="color:#D32F2F">error</span>',
        "high": '<span class="ms ms-xs" style="color:#F57C00">warning</span>',
        "medium": '<span class="ms ms-xs" style="color:#1976D2">info</span>',
        "low": '<span class="ms ms-xs" style="color:#9E9E9E">check_circle</span>',
    }
    table_rows = ""
    for r in results:
        sev = r.expected_severity
        sev_icon = sev_icons.get(sev, "")
        pat_ko = PATTERN_KO.get(r.expected_pattern, r.expected_pattern)
        env_ko = ENV_KO.get(r.environment, r.environment)
        pass_text = '<span style="color:#388E3C;font-weight:600">통과</span>' if r.passed else '<span style="color:#D32F2F;font-weight:600">실패</span>'
        table_rows += f"""<tr>
            <td style="text-align:center">{r.scenario_id}</td>
            <td>{html_mod.escape(r.scenario_name_ko)}</td>
            <td>{env_ko}</td>
            <td>{pat_ko}</td>
            <td>{sev_icon} {SEVERITY_KO.get(sev, sev)}</td>
            <td style="text-align:center">{r.total_signals}</td>
            <td style="text-align:center">{pass_text}</td>
        </tr>"""

    table_html = f"""<div class="card">
        <div class="card-header"><span class="ms ms-sm ms-inline">table_chart</span> DAG/Task 실패 통계</div>
        <div class="table-wrap"><table class="md-table">
            <thead><tr><th>#</th><th>시나리오</th><th>환경</th><th>패턴</th><th>심각도</th><th>신호수</th><th>통과</th></tr></thead>
            <tbody>{table_rows}</tbody>
        </table></div>
    </div>"""

    # ── Charts ──
    sev_chart_config = {
        "type": "doughnut",
        "data": {
            "labels": ["심각", "높음", "보통", "낮음"],
            "datasets": [{
                "data": [sev_dist.get("critical", 0), sev_dist.get("high", 0),
                         sev_dist.get("medium", 0), sev_dist.get("low", 0)],
                "backgroundColor": ["#D32F2F", "#F57C00", "#1976D2", "#9E9E9E"],
            }],
        },
        "options": {
            "plugins": {"title": {"display": True, "text": "심각도 분포", "font": {"size": 14}},
                        "datalabels": {"display": True, "color": "#fff", "font": {"weight": "bold"}}},
        },
    }
    sev_chart_url = _build_quickchart_url(sev_chart_config)

    pat_labels = []
    pat_values = []
    for pt, n in pat_dist.most_common():
        pat_labels.append(PATTERN_KO.get(pt, pt))
        pat_values.append(n)
    pat_chart_config = {
        "type": "horizontalBar",
        "data": {
            "labels": pat_labels,
            "datasets": [{"label": "건수", "data": pat_values, "backgroundColor": "#5C6BC0"}],
        },
        "options": {
            "plugins": {"title": {"display": True, "text": "패턴 유형 분포", "font": {"size": 14}}},
            "scales": {"xAxes": [{"ticks": {"beginAtZero": True, "stepSize": 1}}]},
        },
    }
    pat_chart_url = _build_quickchart_url(pat_chart_config)

    charts_html = f"""<div class="charts-grid">
        <div class="card chart-card">
            <div class="card-header"><span class="ms ms-sm ms-inline">donut_large</span> 심각도 분포</div>
            <div class="chart-wrap"><img src="{sev_chart_url}" alt="심각도 분포" loading="lazy"></div>
        </div>
        <div class="card chart-card">
            <div class="card-header"><span class="ms ms-sm ms-inline">bar_chart</span> 패턴 유형 분포</div>
            <div class="chart-wrap"><img src="{pat_chart_url}" alt="패턴 유형 분포" loading="lazy"></div>
        </div>
    </div>"""

    # ── Detail Cards ──
    detail_cards = ""
    for r in results:
        if not r.summary_text:
            continue
        sev = r.expected_severity
        pat_ko = PATTERN_KO.get(r.expected_pattern, r.expected_pattern)
        env_ko = ENV_KO.get(r.environment, r.environment)
        sev_icon = sev_icons.get(sev, "")

        summary_escaped = r.summary_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")

        ai_html = ""
        if r.root_cause:
            conf_pct = int(r.ai_confidence * 100)
            conf_color = "#388E3C" if conf_pct >= 85 else ("#F57C00" if conf_pct >= 70 else "#D32F2F")
            actions_li = "".join(f"<li>{html_mod.escape(a)}</li>" for a in r.recommended_actions[:3])
            ai_html = f"""<div class="ai-box">
                <div class="ai-box-title"><span class="ms ms-xs ms-inline">psychology</span> AI 원인분석
                    <span class="ai-badge" style="color:{conf_color};border-color:{conf_color}">신뢰도 {conf_pct}%</span></div>
                <p class="ai-cause-text">{html_mod.escape(r.root_cause)}</p>
                <div class="ai-box-title" style="margin-top:8px"><span class="ms ms-xs ms-inline">build</span> 권장 조치</div>
                <ol class="ai-action-list">{actions_li}</ol>
            </div>"""

        sev_colors = {"critical": "#D32F2F", "high": "#F57C00", "medium": "#1976D2", "low": "#9E9E9E"}
        border_color = sev_colors.get(sev, "#9E9E9E")
        pass_icon = "check_circle" if r.passed else "error"
        pass_color = "#388E3C" if r.passed else "#D32F2F"

        detail_cards += f"""<div class="detail-card" style="border-left-color:{border_color}">
            <div class="detail-hdr">
                <span class="ms ms-sm" style="color:{pass_color}">{pass_icon}</span>
                <span class="detail-id">#{r.scenario_id}</span>
                <span class="detail-name">{html_mod.escape(r.scenario_name_ko)}</span>
                <span class="detail-meta">{sev_icon} {SEVERITY_KO.get(sev, sev)} | {pat_ko} | {env_ko}</span>
                <span class="detail-chev"><span class="ms ms-sm">expand_more</span></span>
            </div>
            <div class="detail-body">
                <div class="summary-box">{summary_escaped}</div>
                {ai_html}
            </div>
        </div>"""

    detail_section = f"""<div class="card">
        <div class="card-header"><span class="ms ms-sm ms-inline">analytics</span> 세부 실패 분석</div>
        {detail_cards}
    </div>"""

    # ── Full HTML ──
    html = f'''<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BDP Airflow - Daily Report</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Pretendard',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F5F5F5;color:#212121;line-height:1.6}}
.container{{max-width:1100px;margin:0 auto;padding:20px}}
.ms{{font-family:'Material Symbols Outlined';font-weight:normal;font-style:normal;font-size:24px;line-height:1;display:inline-block;vertical-align:middle;-webkit-font-smoothing:antialiased}}
.ms-xs{{font-size:14px}}.ms-sm{{font-size:18px}}.ms-md{{font-size:24px}}.ms-lg{{font-size:32px}}.ms-inline{{vertical-align:-0.125em;margin-right:4px}}
.header{{background:linear-gradient(135deg,#1A237E 0%,#283593 50%,#3949AB 100%);color:#fff;padding:32px 0;text-align:center}}
.header h1{{font-size:26px;display:flex;align-items:center;justify-content:center;gap:8px;color:#fff}}
.header .subtitle{{color:rgba(255,255,255,.75);margin-top:4px;font-size:14px}}
.card{{background:#FFF;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;overflow:hidden}}
.card-header{{padding:16px 20px;font-size:16px;font-weight:600;border-bottom:1px solid #E0E0E0;display:flex;align-items:center;gap:4px}}
.stats-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px}}
.stat-card{{background:#FFF;border-radius:8px;padding:20px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
.stat-icon{{margin-bottom:4px;color:#757575}}
.stat-value{{font-size:32px;font-weight:700}}.stat-label{{font-size:13px;color:#757575;margin-top:2px}}
.table-wrap{{overflow-x:auto}}
.md-table{{width:100%;border-collapse:collapse}}
.md-table th,.md-table td{{padding:10px 14px;text-align:left;font-size:13px;border-bottom:1px solid #E0E0E0}}
.md-table th{{background:#F5F5F5;font-weight:600;color:#424242}}
.md-table tr:nth-child(even){{background:#FAFAFA}}
.md-table tr:hover{{background:#E3F2FD}}
.charts-grid{{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px}}
.chart-card{{margin-bottom:0}}
.chart-wrap{{padding:16px;text-align:center}}
.chart-wrap img{{max-width:100%;height:auto;border-radius:4px}}
.detail-card{{border-left:4px solid;margin:0;overflow:hidden;transition:box-shadow .2s}}
.detail-card+.detail-card{{border-top:1px solid #E0E0E0}}
.detail-hdr{{display:flex;align-items:center;padding:12px 18px;cursor:pointer;user-select:none;gap:10px}}
.detail-hdr:hover{{background:#F5F5F5}}
.detail-id{{font-weight:600;font-size:13px;color:#757575;min-width:36px}}
.detail-name{{flex:1;font-weight:500;font-size:14px}}
.detail-meta{{font-size:12px;color:#9E9E9E;display:flex;align-items:center;gap:4px}}
.detail-chev{{color:#757575;transition:transform .2s}}
.detail-card.expanded .detail-chev{{transform:rotate(180deg)}}
.detail-body{{display:none;padding:0 18px 16px}}
.detail-card.expanded .detail-body{{display:block}}
.summary-box{{font-size:13px;color:#424242;line-height:1.7;white-space:pre-wrap;background:#FAFAFA;border-radius:6px;padding:14px;border:1px solid #E8E8E8;margin-top:8px}}
.ai-box{{background:#EDE7F6;border-left:3px solid #7E57C2;border-radius:6px;padding:12px;margin-top:10px}}
.ai-box-title{{font-size:12px;font-weight:600;color:#4A148C;display:flex;align-items:center;gap:4px;margin-bottom:6px}}
.ai-badge{{font-size:11px;font-weight:600;border:1px solid;border-radius:12px;padding:1px 8px;margin-left:8px}}
.ai-cause-text{{font-size:13px;color:#212121;line-height:1.5}}
.ai-action-list{{padding-left:18px;margin:4px 0 0 0}}.ai-action-list li{{font-size:12px;color:#424242;padding:2px 0}}
@media(max-width:768px){{.stats-grid{{grid-template-columns:repeat(2,1fr)}}.charts-grid{{grid-template-columns:1fr}}}}
</style>
</head>
<body>
<div class="header"><div class="container">
<h1><span class="ms ms-lg" style="color:#fff">summarize</span> BDP Airflow - Daily Report</h1>
<p class="subtitle">DAG/Task 실패 분석 요약 | {timestamp}</p>
</div></div>
<div class="container">
{stats_html}
{table_html}
{charts_html}
{detail_section}
</div>
<script>
document.addEventListener('click',function(e){{
  var hdr=e.target.closest('.detail-hdr');
  if(hdr)hdr.closest('.detail-card').classList.toggle('expanded');
}});
</script>
</body></html>'''

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
