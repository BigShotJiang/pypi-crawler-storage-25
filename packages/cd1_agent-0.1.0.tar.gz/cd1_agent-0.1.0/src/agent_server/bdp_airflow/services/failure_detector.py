"""
Airflow Failure Detector - Core Pattern Detection Engine.

빈도 분석, 시간 패턴, 캐스케이딩, Duration 이상, 환경별 패턴 탐지.
"""

import json
import logging
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.agent_server.bdp_airflow.services.models import (
    AirflowFailureRecord,
    FailurePattern,
    FailurePatternType,
    FailureSeverity,
    TaskState,
)

logger = logging.getLogger(__name__)


def _load_detection_config() -> Dict[str, Any]:
    """탐지 설정 로드."""
    config_path = Path(__file__).parent.parent / "conf" / "detection_config.json"
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            return json.load(f)
    return {}


class AirflowFailureDetector:
    """Airflow 실패 패턴 탐지 엔진.

    빈도 분석, 시간 패턴, 캐스케이딩, Duration 이상, 환경별 패턴 등
    다양한 실패 패턴을 탐지합니다.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or _load_detection_config()
        fd = self.config.get("failure_detection", {})
        self.lookback_hours = fd.get("lookback_hours", 24)
        self.min_failures = fd.get("min_failures_for_pattern", 3)
        self.recurring_threshold = fd.get("recurring_threshold_count", 5)

        sev = self.config.get("severity", {})
        self.critical_keywords = sev.get("critical_keywords", [
            "OOM", "FATAL", "OutOfMemory", "PermissionDenied", "SIGKILL",
        ])
        self.cascading_threshold = sev.get("cascading_failure_threshold", 3)

        cd = self.config.get("cross_dag", {})
        self.time_window_minutes = cd.get("time_correlation_window_minutes", 30)

        # 외부 시스템 설정
        ext = self.config.get("external_systems", {})
        self.sagemaker_callables = ext.get("sagemaker_callables", [])
        self.emr_callables = ext.get("emr_callables", [])
        self.sftp_callables = ext.get("sftp_callables", [])
        self.copy_callables = ext.get("copy_callables", [])
        self.external_api_callables = ext.get("external_api_callables", [])
        self.sagemaker_error_keywords = ext.get("sagemaker_error_keywords", [])
        self.emr_error_keywords = ext.get("emr_error_keywords", [])
        self.sftp_error_keywords = ext.get("sftp_error_keywords", [])

        # 인프라 설정
        infra = self.config.get("infrastructure", {})
        self.scheduler_overload_indicators = infra.get("scheduler_overload_indicators", [])
        self.worker_resource_indicators = infra.get("worker_resource_indicators", [])
        self.concurrency_keywords = infra.get("concurrency_keywords", [])
        self.worker_oom_threshold = infra.get("worker_oom_threshold_count", 2)

        # 배포 설정
        deploy = self.config.get("deployment_detection", {})
        self.regression_window_hours = deploy.get("regression_window_hours", 6)
        self.min_failures_after_deploy = deploy.get("min_failures_after_deploy", 3)
        self.dag_version_patterns = deploy.get("dag_version_patterns", [])

    def analyze(
        self,
        failures: List[AirflowFailureRecord],
        history: Optional[List[AirflowFailureRecord]] = None,
    ) -> List[FailurePattern]:
        """실패 레코드 분석 → 패턴 목록 반환.

        Args:
            failures: 현재 실패 레코드 (lookback 윈도우 내)
            history: 히스토리 레코드 (장기 추세 분석용)

        Returns:
            탐지된 FailurePattern 목록
        """
        if not failures:
            return []

        patterns: List[FailurePattern] = []

        # 실패 건만 필터
        failed = [r for r in failures if r.is_failed]

        if not failed:
            # 성공 건에서도 사일런트 워닝 탐지
            patterns.extend(self._detect_silent_warnings(failures))
            return patterns

        # 1. 빈도 분석 (반복 실패)
        patterns.extend(self._detect_recurring(failed))

        # 2. 시간대별 패턴
        patterns.extend(self._detect_time_based(failed))

        # 3. 캐스케이딩 실패
        patterns.extend(self._detect_cascading(failures))

        # 4. Duration 이상
        if history:
            patterns.extend(self._detect_duration_anomaly(failures, history))

        # 5. 환경별 패턴
        patterns.extend(self._detect_environment_specific(failures))

        # 6. 사일런트 워닝
        patterns.extend(self._detect_silent_warnings(failures))

        # 7. 외부 시스템 실패 (SageMaker, EMR, SFTP, API, COPY)
        patterns.extend(self._detect_external_system_failures(failed))

        # 8. 인프라 이슈 (스케줄러 과부하, 워커 리소스)
        patterns.extend(self._detect_infrastructure_issues(failed))

        # 9. 동시성 제한
        patterns.extend(self._detect_concurrency_issues(failed))

        # 10. 배포 회귀
        if history:
            patterns.extend(self._detect_deployment_regression(failed, history))

        # 11. 인프라 복합 장애
        patterns.extend(self._detect_infra_compound(failed))

        # 12. 단일 태스크 실패 (다른 패턴에 포함되지 않은 것들)
        detected_dags = set()
        for p in patterns:
            detected_dags.update(p.affected_dags)
        patterns.extend(self._detect_single_task(failed, detected_dags))

        # 심각도 내림차순 정렬
        severity_order = {
            FailureSeverity.CRITICAL: 0,
            FailureSeverity.HIGH: 1,
            FailureSeverity.MEDIUM: 2,
            FailureSeverity.LOW: 3,
        }
        patterns.sort(key=lambda p: (severity_order.get(p.severity, 99), -p.confidence))

        return patterns

    def _detect_recurring(self, failed: List[AirflowFailureRecord]) -> List[FailurePattern]:
        """반복 실패 패턴 탐지.

        (dag_id, task_id)별 실패 횟수가 recurring_threshold 초과 시 flag.
        """
        patterns = []
        counter: Counter = Counter()
        errors_by_key: Dict[Tuple[str, str], List[str]] = defaultdict(list)

        for r in failed:
            key = (r.dag_id, r.task_id)
            counter[key] += 1
            if r.err_msg:
                errors_by_key[key].append(r.err_msg)

        for (dag_id, task_id), count in counter.items():
            if count >= self.recurring_threshold:
                severity = self._classify_severity_by_count_and_errors(
                    count, errors_by_key.get((dag_id, task_id), [])
                )
                confidence = min(1.0, count / (self.recurring_threshold * 2))
                common_err = self._most_common(errors_by_key.get((dag_id, task_id), []))

                patterns.append(FailurePattern(
                    pattern_type=FailurePatternType.RECURRING,
                    severity=severity,
                    confidence=confidence,
                    title=f"반복 실패: {dag_id}/{task_id}",
                    description=(
                        f"{dag_id}/{task_id}가 {count}회 반복 실패했습니다."
                        + (f" 주요 에러: {common_err}" if common_err else "")
                    ),
                    affected_dags=[dag_id],
                    affected_tasks=[task_id],
                    evidence=[f"실패 횟수: {count}회 (임계값: {self.recurring_threshold})"],
                    failure_count=count,
                ))

        return patterns

    def _detect_time_based(self, failed: List[AirflowFailureRecord]) -> List[FailurePattern]:
        """시간대별 실패 패턴 탐지.

        hour-of-day별 실패 빈도 집계, 특정 시간대 집중 탐지.
        """
        patterns = []
        hour_counts: Counter = Counter()
        hour_dags: Dict[int, set] = defaultdict(set)

        for r in failed:
            try:
                dt = datetime.strptime(r.start_date[:19], "%Y-%m-%d %H:%M:%S")
                hour = dt.hour
                hour_counts[hour] += 1
                hour_dags[hour].add(r.dag_id)
            except (ValueError, TypeError):
                continue

        if not hour_counts:
            return patterns

        total = sum(hour_counts.values())
        avg_per_hour = total / 24.0

        for hour, count in hour_counts.most_common(3):
            if count >= self.min_failures and count >= avg_per_hour * 3:
                dags = list(hour_dags[hour])
                confidence = min(1.0, count / (avg_per_hour * 5))

                patterns.append(FailurePattern(
                    pattern_type=FailurePatternType.TIME_BASED,
                    severity=FailureSeverity.MEDIUM,
                    confidence=confidence,
                    title=f"시간대별 패턴: {hour:02d}:00-{hour:02d}:59",
                    description=(
                        f"{hour:02d}시에 {count}건의 실패가 집중 발생했습니다. "
                        f"(평균 {avg_per_hour:.1f}건/시간 대비 {count/avg_per_hour:.1f}배) "
                        f"영향 DAG: {', '.join(dags[:5])}"
                    ),
                    affected_dags=dags,
                    evidence=[
                        f"{hour:02d}시 실패: {count}건",
                        f"시간당 평균: {avg_per_hour:.1f}건",
                    ],
                    failure_count=count,
                    metadata={"peak_hour": hour},
                ))

        return patterns

    def _detect_cascading(self, records: List[AirflowFailureRecord]) -> List[FailurePattern]:
        """캐스케이딩 실패 탐지.

        upstream_failed 활용 + DAG 내 task들의 시간순 연쇄 실패 탐지.
        """
        patterns = []

        # DAG별로 그룹핑
        dag_records: Dict[str, List[AirflowFailureRecord]] = defaultdict(list)
        for r in records:
            if r.is_failed:
                dag_records[r.dag_id].append(r)

        for dag_id, recs in dag_records.items():
            if len(recs) < 2:
                continue

            # upstream_failed 있는지 확인
            upstream_failed = [r for r in recs if r.state == TaskState.UPSTREAM_FAILED.value]

            # 시간순 정렬
            sorted_recs = sorted(recs, key=lambda r: r.start_date)

            # 30분 이내 연쇄 실패 체크
            chain: List[AirflowFailureRecord] = [sorted_recs[0]]
            for i in range(1, len(sorted_recs)):
                try:
                    t1 = datetime.strptime(sorted_recs[i - 1].start_date[:19], "%Y-%m-%d %H:%M:%S")
                    t2 = datetime.strptime(sorted_recs[i].start_date[:19], "%Y-%m-%d %H:%M:%S")
                    if (t2 - t1).total_seconds() <= self.time_window_minutes * 60:
                        chain.append(sorted_recs[i])
                    else:
                        if len(chain) >= self.cascading_threshold or upstream_failed:
                            patterns.append(self._build_cascading_pattern(dag_id, chain))
                        chain = [sorted_recs[i]]
                except (ValueError, TypeError):
                    continue

            # 마지막 체인 처리
            if len(chain) >= self.cascading_threshold or (len(chain) >= 2 and upstream_failed):
                patterns.append(self._build_cascading_pattern(dag_id, chain))

        return patterns

    def _build_cascading_pattern(
        self,
        dag_id: str,
        chain: List[AirflowFailureRecord],
    ) -> FailurePattern:
        """캐스케이딩 패턴 빌드."""
        tasks = [r.task_id for r in chain]
        errors = list({r.err_msg for r in chain if r.err_msg})

        return FailurePattern(
            pattern_type=FailurePatternType.CASCADING,
            severity=FailureSeverity.CRITICAL,
            confidence=min(1.0, len(chain) / 5),
            title=f"캐스케이딩 실패: {dag_id}",
            description=(
                f"{dag_id} 내 {len(chain)}개 태스크가 연쇄 실패했습니다. "
                f"실패 체인: {' → '.join(tasks)}"
            ),
            affected_dags=[dag_id],
            affected_tasks=tasks,
            evidence=[
                f"연쇄 실패 태스크: {len(chain)}개",
                f"실패 체인: {' → '.join(tasks)}",
            ] + ([f"에러: {errors[0]}"] if errors else []),
            failure_count=len(chain),
            metadata={"failure_chain": tasks},
        )

    def _detect_duration_anomaly(
        self,
        failures: List[AirflowFailureRecord],
        history: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """Duration 이상치 탐지.

        히스토리 mean ± z_score * stddev 기반.
        """
        patterns = []

        # 히스토리에서 task별 정상 duration 수집
        duration_history: Dict[Tuple[str, str], List[float]] = defaultdict(list)
        for r in history:
            dur = r.duration_seconds
            if dur is not None and dur > 0 and r.state == TaskState.SUCCESS.value:
                duration_history[(r.dag_id, r.task_id)].append(dur)

        # 현재 실패 건의 duration과 비교
        for r in failures:
            dur = r.duration_seconds
            if dur is None or dur <= 0:
                continue

            key = (r.dag_id, r.task_id)
            hist = duration_history.get(key, [])
            if len(hist) < 3:
                continue

            import statistics
            mean = statistics.mean(hist)
            stdev = statistics.stdev(hist) if len(hist) > 1 else 0

            if stdev == 0:
                continue

            z_config = self.config.get("precursor_detection", {}).get("duration_anomaly_z_score", 2.0)
            z_score = (dur - mean) / stdev

            if abs(z_score) >= z_config:
                ratio = dur / mean
                patterns.append(FailurePattern(
                    pattern_type=FailurePatternType.DURATION_ANOMALY,
                    severity=FailureSeverity.MEDIUM if ratio < 5 else FailureSeverity.HIGH,
                    confidence=min(1.0, abs(z_score) / 4.0),
                    title=f"Duration 이상: {r.dag_id}/{r.task_id}",
                    description=(
                        f"{r.dag_id}/{r.task_id}의 실행 시간이 "
                        f"평소 {mean:.0f}초에서 {dur:.0f}초로 {ratio:.1f}배 증가했습니다."
                    ),
                    affected_dags=[r.dag_id],
                    affected_tasks=[r.task_id],
                    evidence=[
                        f"현재 Duration: {dur:.0f}초",
                        f"평균 Duration: {mean:.0f}초",
                        f"Z-Score: {z_score:.2f}",
                    ],
                    failure_count=1,
                    metadata={"z_score": z_score, "ratio": ratio},
                ))

        return patterns

    def _detect_environment_specific(
        self, records: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """환경 특이 패턴 탐지.

        dlk/wfl 동일 DAG의 실패율 비교.
        """
        patterns = []

        # 환경별 DAG 실패 카운트
        env_dag_failures: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        env_dag_total: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

        for r in records:
            env_dag_total[r.rcpt_tp][r.dag_id] += 1
            if r.is_failed:
                env_dag_failures[r.rcpt_tp][r.dag_id] += 1

        # 양 환경에 있는 DAG만 비교
        envs = list(env_dag_total.keys())
        if len(envs) < 2:
            return patterns

        common_dags = set(env_dag_total[envs[0]].keys()) & set(env_dag_total[envs[1]].keys())

        for dag_id in common_dags:
            rates = {}
            for env in envs:
                total = env_dag_total[env][dag_id]
                failed = env_dag_failures[env].get(dag_id, 0)
                rates[env] = failed / total if total > 0 else 0

            # 한 환경에서만 실패하는 경우
            env_with_failures = [e for e, r in rates.items() if r > 0]
            env_without_failures = [e for e, r in rates.items() if r == 0]

            if len(env_with_failures) == 1 and len(env_without_failures) >= 1:
                fail_env = env_with_failures[0]
                fail_count = env_dag_failures[fail_env][dag_id]

                if fail_count >= self.min_failures:
                    patterns.append(FailurePattern(
                        pattern_type=FailurePatternType.ENVIRONMENT_SPECIFIC,
                        severity=FailureSeverity.HIGH,
                        confidence=min(1.0, fail_count / 5),
                        title=f"환경 특이 패턴: {dag_id} ({fail_env}에서만 실패)",
                        description=(
                            f"{dag_id}가 {fail_env} 환경에서만 {fail_count}회 실패하고 "
                            f"다른 환경에서는 정상입니다. 인프라 차이를 확인하세요."
                        ),
                        affected_dags=[dag_id],
                        environment=fail_env,
                        evidence=[
                            f"{fail_env} 실패율: {rates[fail_env]:.0%}",
                        ] + [f"{e} 실패율: {rates[e]:.0%}" for e in env_without_failures],
                        failure_count=fail_count,
                    ))

        return patterns

    def _detect_silent_warnings(
        self, records: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """사일런트 워닝 탐지.

        성공 건이지만 err_msg에 warning 키워드가 포함된 경우.
        """
        patterns = []
        warning_keywords = self.config.get("precursor_detection", {}).get(
            "warning_keywords", ["WARNING", "WARN", "deprecated"]
        )

        warnings_by_dag: Dict[str, List[AirflowFailureRecord]] = defaultdict(list)

        for r in records:
            if r.state == TaskState.SUCCESS.value and r.err_msg:
                for kw in warning_keywords:
                    if kw.lower() in r.err_msg.lower():
                        warnings_by_dag[r.dag_id].append(r)
                        break

        for dag_id, warning_records in warnings_by_dag.items():
            if len(warning_records) >= 1:
                sample_msgs = list({r.err_msg for r in warning_records[:3]})
                patterns.append(FailurePattern(
                    pattern_type=FailurePatternType.SILENT_WARNING,
                    severity=FailureSeverity.LOW,
                    confidence=min(1.0, len(warning_records) / 5),
                    title=f"사일런트 워닝: {dag_id}",
                    description=(
                        f"{dag_id}에서 성공했지만 {len(warning_records)}건의 "
                        f"워닝 메시지가 감지되었습니다."
                    ),
                    affected_dags=[dag_id],
                    affected_tasks=list({r.task_id for r in warning_records}),
                    evidence=sample_msgs[:3],
                    failure_count=len(warning_records),
                ))

        return patterns

    def _detect_single_task(
        self,
        failed: List[AirflowFailureRecord],
        already_detected_dags: set,
    ) -> List[FailurePattern]:
        """단일 태스크 실패 (다른 패턴에 포함되지 않은 것)."""
        patterns = []

        for r in failed:
            if r.dag_id in already_detected_dags:
                continue
            already_detected_dags.add(r.dag_id)

            severity = self._classify_severity_by_errors([r.err_msg] if r.err_msg else [])
            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.SINGLE_TASK,
                severity=severity,
                confidence=0.5,
                title=f"태스크 실패: {r.dag_id}/{r.task_id}",
                description=(
                    f"{r.dag_id}/{r.task_id}가 실패했습니다."
                    + (f" 에러: {r.err_msg}" if r.err_msg else "")
                ),
                affected_dags=[r.dag_id],
                affected_tasks=[r.task_id],
                evidence=[f"상태: {r.state}"] + ([f"에러: {r.err_msg}"] if r.err_msg else []),
                failure_count=1,
                environment=r.rcpt_tp,
            ))

        return patterns

    # =========================================================================
    # 외부 시스템 / 인프라 / 배포 탐지
    # =========================================================================

    def _detect_external_system_failures(
        self, failed: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """외부 시스템 연동 실패 탐지.

        SageMaker Pipeline, EMR Cluster, SFTP Transfer,
        External API, Data Pipeline COPY 패턴.
        """
        patterns: List[FailurePattern] = []

        # callable → (pattern_type, callables, error_keywords, label)
        system_map = [
            (
                FailurePatternType.SAGEMAKER_PIPELINE,
                self.sagemaker_callables,
                self.sagemaker_error_keywords,
                "SageMaker 파이프라인",
            ),
            (
                FailurePatternType.EMR_CLUSTER,
                self.emr_callables,
                self.emr_error_keywords,
                "EMR 클러스터",
            ),
            (
                FailurePatternType.SFTP_TRANSFER,
                self.sftp_callables,
                self.sftp_error_keywords,
                "SFTP 전송",
            ),
            (
                FailurePatternType.DATA_PIPELINE_COPY,
                self.copy_callables,
                [],
                "데이터 파이프라인 COPY",
            ),
            (
                FailurePatternType.EXTERNAL_API,
                self.external_api_callables,
                [],
                "외부 API 호출",
            ),
        ]

        for ptype, callables, error_kws, label in system_map:
            matched: List[AirflowFailureRecord] = []

            for r in failed:
                # python_callable 매칭
                callable_match = any(
                    c.lower() in r.python_callable.lower()
                    for c in callables
                ) if r.python_callable and callables else False

                # err_msg 키워드 매칭
                err_match = False
                if r.err_msg and error_kws:
                    err_match = any(
                        kw.lower() in r.err_msg.lower() for kw in error_kws
                    )

                if callable_match or err_match:
                    matched.append(r)

            if not matched:
                continue

            dags = list({r.dag_id for r in matched})
            tasks = list({r.task_id for r in matched})
            errors = list({r.err_msg for r in matched if r.err_msg})[:3]

            severity = (
                FailureSeverity.HIGH
                if len(matched) >= 3
                else FailureSeverity.MEDIUM
            )
            confidence = min(1.0, len(matched) / 5.0)

            patterns.append(FailurePattern(
                pattern_type=ptype,
                severity=severity,
                confidence=confidence,
                title=f"{label} 실패: {len(matched)}건",
                description=(
                    f"{label} 연동 태스크에서 {len(matched)}건의 실패가 발생했습니다. "
                    f"영향 DAG: {', '.join(dags[:5])}"
                    + (f" 에러: {errors[0][:100]}" if errors else "")
                ),
                affected_dags=dags,
                affected_tasks=tasks,
                evidence=[
                    f"{label} 실패 건수: {len(matched)}",
                ] + [f"에러: {e[:100]}" for e in errors],
                failure_count=len(matched),
                metadata={"system_type": ptype.value},
            ))

        return patterns

    def _detect_infrastructure_issues(
        self, failed: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """인프라 이슈 탐지 (스케줄러 과부하, 워커 리소스 부족).

        err_msg에 스케줄러/워커 관련 키워드가 포함된 실패를 탐지합니다.
        """
        patterns: List[FailurePattern] = []

        scheduler_matched: List[AirflowFailureRecord] = []
        worker_matched: List[AirflowFailureRecord] = []

        for r in failed:
            if not r.err_msg:
                continue
            err_lower = r.err_msg.lower()

            for kw in self.scheduler_overload_indicators:
                if kw.lower() in err_lower:
                    scheduler_matched.append(r)
                    break

            for kw in self.worker_resource_indicators:
                if kw.lower() in err_lower:
                    worker_matched.append(r)
                    break

        # 스케줄러 과부하
        if len(scheduler_matched) >= 2:
            dags = list({r.dag_id for r in scheduler_matched})
            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.SCHEDULER_OVERLOAD,
                severity=FailureSeverity.HIGH,
                confidence=min(1.0, len(scheduler_matched) / 5.0),
                title=f"MWAA 스케줄러 과부하: {len(scheduler_matched)}건 영향",
                description=(
                    f"스케줄러 과부하로 인한 실패가 {len(scheduler_matched)}건 감지되었습니다. "
                    f"영향 DAG: {', '.join(dags[:5])}"
                ),
                affected_dags=dags,
                affected_tasks=list({r.task_id for r in scheduler_matched}),
                evidence=[r.err_msg[:100] for r in scheduler_matched[:3]],
                failure_count=len(scheduler_matched),
            ))

        # 워커 리소스 부족
        if len(worker_matched) >= self.worker_oom_threshold:
            dags = list({r.dag_id for r in worker_matched})
            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.WORKER_RESOURCE,
                severity=FailureSeverity.CRITICAL,
                confidence=min(1.0, len(worker_matched) / 4.0),
                title=f"MWAA 워커 리소스 부족: {len(worker_matched)}건",
                description=(
                    f"워커 리소스 부족(OOM/SIGKILL 등)으로 인한 실패가 "
                    f"{len(worker_matched)}건 감지되었습니다. "
                    f"영향 DAG: {', '.join(dags[:5])}"
                ),
                affected_dags=dags,
                affected_tasks=list({r.task_id for r in worker_matched}),
                evidence=[r.err_msg[:100] for r in worker_matched[:3]],
                failure_count=len(worker_matched),
            ))

        return patterns

    def _detect_concurrency_issues(
        self, failed: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """동시성 제한 실패 탐지.

        err_msg에 pool, slot, queued, concurrency 키워드.
        """
        patterns: List[FailurePattern] = []
        matched: List[AirflowFailureRecord] = []

        for r in failed:
            if not r.err_msg:
                continue
            err_lower = r.err_msg.lower()
            if any(kw.lower() in err_lower for kw in self.concurrency_keywords):
                matched.append(r)

        if len(matched) >= 2:
            dags = list({r.dag_id for r in matched})
            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.CONCURRENCY_LIMIT,
                severity=FailureSeverity.MEDIUM,
                confidence=min(1.0, len(matched) / 5.0),
                title=f"동시성 제한 초과: {len(matched)}건",
                description=(
                    f"동시성 제한(pool/slot/concurrency)으로 인한 실패가 "
                    f"{len(matched)}건 감지되었습니다. "
                    f"영향 DAG: {', '.join(dags[:5])}"
                ),
                affected_dags=dags,
                affected_tasks=list({r.task_id for r in matched}),
                evidence=[r.err_msg[:100] for r in matched[:3]],
                failure_count=len(matched),
            ))

        return patterns

    def _detect_deployment_regression(
        self,
        failed: List[AirflowFailureRecord],
        history: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """배포 후 회귀 실패 탐지.

        히스토리에서 이전 성공 → 최근 연속 실패 전환을 탐지합니다.
        """
        import re
        patterns: List[FailurePattern] = []

        # (dag_id, task_id)별로 시간순 정렬
        task_history: Dict[Tuple[str, str], List[AirflowFailureRecord]] = defaultdict(list)
        for r in history:
            task_history[(r.dag_id, r.task_id)].append(r)

        for r in failed:
            task_history[(r.dag_id, r.task_id)].append(r)

        for (dag_id, task_id), records in task_history.items():
            sorted_recs = sorted(records, key=lambda x: x.start_date)
            if len(sorted_recs) < 4:
                continue

            # 이전 성공 건이 있었는지
            success_count = sum(
                1 for r in sorted_recs[:-self.min_failures_after_deploy]
                if r.state == "success"
            )
            if success_count < 2:
                continue

            # 최근 N건이 모두 실패인지
            recent = sorted_recs[-self.min_failures_after_deploy:]
            all_failed = all(r.is_failed for r in recent)
            if not all_failed:
                continue

            # DAG 이름에 버전 패턴이 있는지 확인
            version_match = any(
                re.search(pat, dag_id) for pat in self.dag_version_patterns
            ) if self.dag_version_patterns else False

            confidence = 0.7 if version_match else 0.5
            errors = list({r.err_msg for r in recent if r.err_msg})[:2]

            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.DEPLOYMENT_REGRESSION,
                severity=FailureSeverity.HIGH,
                confidence=confidence,
                title=f"배포 회귀 의심: {dag_id}/{task_id}",
                description=(
                    f"{dag_id}/{task_id}가 이전 성공에서 최근 "
                    f"{self.min_failures_after_deploy}회 연속 실패로 전환되었습니다. "
                    f"배포 후 회귀를 확인하세요."
                    + (f" 에러: {errors[0][:80]}" if errors else "")
                ),
                affected_dags=[dag_id],
                affected_tasks=[task_id],
                evidence=[
                    f"이전 성공: {success_count}회",
                    f"최근 연속 실패: {self.min_failures_after_deploy}회",
                ] + ([f"에러: {errors[0][:100]}"] if errors else []),
                failure_count=self.min_failures_after_deploy,
                metadata={"version_pattern_detected": version_match},
            ))

        return patterns

    def _detect_infra_compound(
        self, failed: List[AirflowFailureRecord],
    ) -> List[FailurePattern]:
        """인프라 복합 장애 탐지.

        다수 DAG에서 동시에 인프라 관련 에러가 발생하는 경우.
        """
        patterns: List[FailurePattern] = []

        all_infra_keywords = (
            self.scheduler_overload_indicators
            + self.worker_resource_indicators
            + self.concurrency_keywords
        )
        if not all_infra_keywords:
            return patterns

        infra_failed: List[AirflowFailureRecord] = []
        for r in failed:
            if not r.err_msg:
                continue
            err_lower = r.err_msg.lower()
            if any(kw.lower() in err_lower for kw in all_infra_keywords):
                infra_failed.append(r)

        unique_dags = {r.dag_id for r in infra_failed}
        if len(unique_dags) >= 3:
            dags = list(unique_dags)
            errors = list({r.err_msg for r in infra_failed if r.err_msg})[:3]
            patterns.append(FailurePattern(
                pattern_type=FailurePatternType.INFRA_COMPOUND,
                severity=FailureSeverity.CRITICAL,
                confidence=min(1.0, len(unique_dags) / 5.0),
                title=f"인프라 복합 장애: {len(unique_dags)}개 DAG 영향",
                description=(
                    f"인프라 관련 실패가 {len(unique_dags)}개 DAG에서 동시 발생했습니다. "
                    f"MWAA 환경 전반의 인프라 점검이 필요합니다. "
                    f"영향 DAG: {', '.join(dags[:5])}"
                ),
                affected_dags=dags,
                affected_tasks=list({r.task_id for r in infra_failed}),
                evidence=errors,
                failure_count=len(infra_failed),
            ))

        return patterns

    def _classify_severity_by_count_and_errors(
        self, count: int, errors: List[str],
    ) -> FailureSeverity:
        """횟수와 에러 메시지로 심각도 분류."""
        # Critical 키워드 체크
        for err in errors:
            for kw in self.critical_keywords:
                if kw.lower() in err.lower():
                    return FailureSeverity.CRITICAL

        if count >= self.recurring_threshold * 2:
            return FailureSeverity.HIGH
        elif count >= self.recurring_threshold:
            return FailureSeverity.MEDIUM
        return FailureSeverity.LOW

    def _classify_severity_by_errors(self, errors: List[str]) -> FailureSeverity:
        """에러 메시지로 심각도 분류."""
        for err in errors:
            for kw in self.critical_keywords:
                if kw.lower() in err.lower():
                    return FailureSeverity.CRITICAL
        return FailureSeverity.LOW

    @staticmethod
    def _most_common(items: List[str]) -> Optional[str]:
        """가장 빈번한 항목 반환."""
        if not items:
            return None
        return Counter(items).most_common(1)[0][0]
