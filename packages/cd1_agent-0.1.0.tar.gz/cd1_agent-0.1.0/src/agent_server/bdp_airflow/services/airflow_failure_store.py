"""
Airflow Failure Store - Data Access Layer.

SQLite/MySQL/Mock 프로바이더를 통한 Airflow 실패 데이터 접근.
BaseSQLiteProvider, BaseMySqlProvider (bdp_common) 상속.
"""

import json
import logging
import os
import sqlite3
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_airflow.services.models import AirflowFailureRecord
from src.agent_server.bdp_common.stores.base import BaseMySqlProvider, BaseSQLiteProvider

logger = logging.getLogger(__name__)


class AirflowFailureStoreProvider(ABC):
    """Airflow 실패 데이터 저장소 ABC."""

    @abstractmethod
    def get_failures(
        self,
        rcpt_tp: Optional[str] = None,
        hours: int = 24,
        state: Optional[str] = None,
    ) -> List[AirflowFailureRecord]:
        """실패 레코드 조회.

        Args:
            rcpt_tp: 환경 필터 (dlk, wfl, None=전체)
            hours: 조회 범위 (시간)
            state: 상태 필터 (failed, success, upstream_failed, None=전체)

        Returns:
            AirflowFailureRecord 목록
        """

    @abstractmethod
    def get_failure_history(
        self,
        dag_id: str,
        task_id: Optional[str] = None,
        days: int = 7,
    ) -> List[AirflowFailureRecord]:
        """특정 DAG/Task의 히스토리 조회.

        Args:
            dag_id: DAG ID
            task_id: Task ID (None이면 DAG 전체)
            days: 조회 범위 (일)

        Returns:
            AirflowFailureRecord 목록
        """

    @abstractmethod
    def get_task_durations(
        self,
        dag_id: str,
        task_id: str,
        days: int = 7,
    ) -> List[Dict[str, Any]]:
        """특정 Task의 실행 시간 히스토리 조회.

        Args:
            dag_id: DAG ID
            task_id: Task ID
            days: 조회 범위 (일)

        Returns:
            [{"start_date": str, "duration": str, "state": str}, ...]
        """

    @abstractmethod
    def save_snapshot(self, records: List[AirflowFailureRecord]) -> int:
        """스냅샷 데이터 저장.

        Args:
            records: 저장할 레코드 목록

        Returns:
            저장된 레코드 수
        """


class SQLiteAirflowFailureProvider(AirflowFailureStoreProvider, BaseSQLiteProvider):
    """SQLite 기반 Airflow 실패 데이터 프로바이더 (테스트용)."""

    def __init__(self, db_path: str = ":memory:"):
        BaseSQLiteProvider.__init__(self, db_path)
        self._init_table()

    def _init_table(self) -> None:
        """테이블 생성."""
        ddl_path = Path(__file__).parent.parent / "conf" / "schema" / "airflow_failures.sql"
        if ddl_path.exists():
            with open(ddl_path, encoding="utf-8") as f:
                self.conn.executescript(f.read())
        else:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS wfl_awf_hst (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    start_date TEXT NOT NULL,
                    rcpt_tp TEXT NOT NULL,
                    dag_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    python_callable TEXT,
                    duration TEXT,
                    state TEXT NOT NULL,
                    err_msg TEXT,
                    op_kwargs TEXT,
                    run_id TEXT,
                    bdp_load_dttm TEXT DEFAULT (datetime('now'))
                );
            """)
        self.conn.commit()

    def _row_to_record(self, row: sqlite3.Row) -> AirflowFailureRecord:
        """SQLite Row → AirflowFailureRecord 변환."""
        return AirflowFailureRecord(
            start_date=row["start_date"],
            rcpt_tp=row["rcpt_tp"],
            dag_id=row["dag_id"],
            task_id=row["task_id"],
            state=row["state"],
            python_callable=row["python_callable"] or "",
            duration=row["duration"] or "",
            err_msg=row["err_msg"] or "",
            op_kwargs=row["op_kwargs"] or "",
            run_id=row["run_id"] or "",
        )

    def get_failures(
        self,
        rcpt_tp: Optional[str] = None,
        hours: int = 24,
        state: Optional[str] = None,
    ) -> List[AirflowFailureRecord]:
        cutoff = (get_kst_now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        query = "SELECT * FROM wfl_awf_hst WHERE start_date >= ?"
        params: List[Any] = [cutoff]

        if rcpt_tp:
            query += " AND rcpt_tp = ?"
            params.append(rcpt_tp)
        if state:
            query += " AND state = ?"
            params.append(state)

        query += " ORDER BY start_date DESC"

        cursor = self.conn.execute(query, params)
        return [self._row_to_record(row) for row in cursor.fetchall()]

    def get_failure_history(
        self,
        dag_id: str,
        task_id: Optional[str] = None,
        days: int = 7,
    ) -> List[AirflowFailureRecord]:
        cutoff = (get_kst_now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        query = "SELECT * FROM wfl_awf_hst WHERE dag_id = ? AND start_date >= ?"
        params: List[Any] = [dag_id, cutoff]

        if task_id:
            query += " AND task_id = ?"
            params.append(task_id)

        query += " ORDER BY start_date ASC"

        cursor = self.conn.execute(query, params)
        return [self._row_to_record(row) for row in cursor.fetchall()]

    def get_task_durations(
        self,
        dag_id: str,
        task_id: str,
        days: int = 7,
    ) -> List[Dict[str, Any]]:
        cutoff = (get_kst_now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        query = """
            SELECT start_date, duration, state
            FROM wfl_awf_hst
            WHERE dag_id = ? AND task_id = ? AND start_date >= ?
            ORDER BY start_date ASC
        """
        cursor = self.conn.execute(query, [dag_id, task_id, cutoff])
        return [dict(row) for row in cursor.fetchall()]

    def save_snapshot(self, records: List[AirflowFailureRecord]) -> int:
        count = 0
        for r in records:
            self.conn.execute(
                """INSERT INTO wfl_awf_hst
                   (start_date, rcpt_tp, dag_id, task_id, python_callable,
                    duration, state, err_msg, op_kwargs, run_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    r.start_date, r.rcpt_tp, r.dag_id, r.task_id,
                    r.python_callable, r.duration, r.state,
                    r.err_msg, r.op_kwargs, r.run_id,
                ),
            )
            count += 1
        self.conn.commit()
        return count


class MySqlAirflowFailureProvider(AirflowFailureStoreProvider, BaseMySqlProvider):
    """MySQL(RDS) 기반 Airflow 실패 데이터 프로바이더 (읽기 전용)."""

    def __init__(
        self,
        secret_id: str,
        db: str,
        table_name: str = "wfl_awf_hst",
        region: str = "ap-northeast-2",
    ):
        BaseMySqlProvider.__init__(self, secret_id=secret_id, db=db, region=region)
        self.table_name = table_name

    def _row_to_record(self, row: Dict[str, Any]) -> AirflowFailureRecord:
        """MySQL dict row → AirflowFailureRecord 변환."""
        return AirflowFailureRecord(
            start_date=str(row.get("start_date", "")),
            rcpt_tp=str(row.get("rcpt_tp", "")),
            dag_id=str(row.get("dag_id", "")),
            task_id=str(row.get("task_id", "")),
            state=str(row.get("state", "")),
            python_callable=str(row.get("python_callable", "") or ""),
            duration=str(row.get("duration", "") or ""),
            err_msg=str(row.get("err_msg", "") or ""),
            op_kwargs=str(row.get("op_kwargs", "") or ""),
            run_id=str(row.get("run_id", "") or ""),
        )

    def get_failures(
        self,
        rcpt_tp: Optional[str] = None,
        hours: int = 24,
        state: Optional[str] = None,
    ) -> List[AirflowFailureRecord]:
        cutoff = (get_kst_now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        query = f"SELECT * FROM {self.table_name} WHERE start_date >= %s"
        params: List[Any] = [cutoff]

        if rcpt_tp:
            query += " AND rcpt_tp = %s"
            params.append(rcpt_tp)
        if state:
            query += " AND state = %s"
            params.append(state)

        query += " ORDER BY start_date DESC"

        with self.conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()

        return [self._row_to_record(row) for row in rows]

    def get_failure_history(
        self,
        dag_id: str,
        task_id: Optional[str] = None,
        days: int = 7,
    ) -> List[AirflowFailureRecord]:
        cutoff = (get_kst_now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        query = f"SELECT * FROM {self.table_name} WHERE dag_id = %s AND start_date >= %s"
        params: List[Any] = [dag_id, cutoff]

        if task_id:
            query += " AND task_id = %s"
            params.append(task_id)

        query += " ORDER BY start_date ASC"

        with self.conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()

        return [self._row_to_record(row) for row in rows]

    def get_task_durations(
        self,
        dag_id: str,
        task_id: str,
        days: int = 7,
    ) -> List[Dict[str, Any]]:
        cutoff = (get_kst_now() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        query = f"""
            SELECT start_date, duration, state
            FROM {self.table_name}
            WHERE dag_id = %s AND task_id = %s AND start_date >= %s
            ORDER BY start_date ASC
        """
        with self.conn.cursor() as cursor:
            cursor.execute(query, [dag_id, task_id, cutoff])
            return cursor.fetchall()

    def save_snapshot(self, records: List[AirflowFailureRecord]) -> int:
        raise NotImplementedError("MySQL provider is read-only")


class MockAirflowFailureProvider(AirflowFailureStoreProvider):
    """인메모리 Mock 프로바이더 (테스트용)."""

    def __init__(self, records: Optional[List[AirflowFailureRecord]] = None):
        self.records: List[AirflowFailureRecord] = records or []

    def get_failures(
        self,
        rcpt_tp: Optional[str] = None,
        hours: int = 24,
        state: Optional[str] = None,
    ) -> List[AirflowFailureRecord]:
        result = self.records[:]
        if rcpt_tp:
            result = [r for r in result if r.rcpt_tp == rcpt_tp]
        if state:
            result = [r for r in result if r.state == state]
        return result

    def get_failure_history(
        self,
        dag_id: str,
        task_id: Optional[str] = None,
        days: int = 7,
    ) -> List[AirflowFailureRecord]:
        result = [r for r in self.records if r.dag_id == dag_id]
        if task_id:
            result = [r for r in result if r.task_id == task_id]
        return result

    def get_task_durations(
        self,
        dag_id: str,
        task_id: str,
        days: int = 7,
    ) -> List[Dict[str, Any]]:
        return [
            {"start_date": r.start_date, "duration": r.duration, "state": r.state}
            for r in self.records
            if r.dag_id == dag_id and r.task_id == task_id
        ]

    def save_snapshot(self, records: List[AirflowFailureRecord]) -> int:
        self.records.extend(records)
        return len(records)


class AirflowFailureStore:
    """Airflow Failure Store Facade.

    create_provider() 팩토리를 통해 환경에 맞는 프로바이더 생성.
    """

    def __init__(self, provider: AirflowFailureStoreProvider):
        self.provider = provider

    @staticmethod
    def create_provider(
        provider_type: str = "mock",
        **kwargs: Any,
    ) -> AirflowFailureStoreProvider:
        """환경에 맞는 프로바이더 생성.

        Args:
            provider_type: "mock", "sqlite", "mysql"
            **kwargs: 프로바이더별 추가 인자

        Returns:
            AirflowFailureStoreProvider 인스턴스
        """
        if provider_type == "sqlite":
            return SQLiteAirflowFailureProvider(
                db_path=kwargs.get("db_path", ":memory:"),
            )
        elif provider_type == "mysql":
            return MySqlAirflowFailureProvider(
                secret_id=kwargs.get("secret_id", os.getenv("MWAA_SECRET_ID", "")),
                db=kwargs.get("db", os.getenv("MWAA_DB_NAME", "")),
                table_name=kwargs.get("table_name", "wfl_awf_hst"),
            )
        else:
            return MockAirflowFailureProvider(
                records=kwargs.get("records"),
            )
