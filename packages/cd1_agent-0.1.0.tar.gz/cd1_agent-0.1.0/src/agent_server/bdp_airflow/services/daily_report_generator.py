"""
Daily Report Generator for BDP Airflow Agent.

Airflow 일일 운영 리포트를 단일 HTML 파일로 생성합니다.
Material Design 스타일, 통계 그리드, 시나리오 테이블, 상세 카드 포함.
"""

import json
import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from html import escape as html_escape
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)


SEVERITY_KO = {
    "critical": "심각",
    "high": "높음",
    "medium": "보통",
    "low": "낮음",
}

ENV_KO = {
    "dlk": "입수 파이프라인",
    "wfl": "사용자 워크플로우",
}


@dataclass
class AirflowDailyScenario:
    """일일 리포트 개별 시나리오."""

    name: str
    environment: str
    severity: str
    passed: bool
    signal_count: int = 0
    description: str = ""
    root_cause: str = ""
    recommended_actions: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "environment": self.environment,
            "severity": self.severity,
            "passed": self.passed,
            "signal_count": self.signal_count,
            "description": self.description,
            "root_cause": self.root_cause,
            "recommended_actions": self.recommended_actions,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "AirflowDailyScenario":
        return AirflowDailyScenario(
            name=d["name"],
            environment=d["environment"],
            severity=d["severity"],
            passed=d["passed"],
            signal_count=d.get("signal_count", 0),
            description=d.get("description", ""),
            root_cause=d.get("root_cause", ""),
            recommended_actions=d.get("recommended_actions", []),
        )


@dataclass
class AirflowDailyReportData:
    """일일 리포트 데이터."""

    total_scenarios: int
    passed: int
    failed: int
    by_severity: Dict[str, int]
    scenarios: List[AirflowDailyScenario] = field(default_factory=list)
    report_date: Optional[str] = None


class AirflowDailyReportGenerator(HTMLReportBase):
    """Airflow 일일 운영 리포트 생성기."""

    def __init__(self):
        super().__init__(title="Airflow 일일 운영 리포트")

    def generate_content(self, data: AirflowDailyReportData) -> str:
        """리포트 콘텐츠 생성."""
        sections = []

        # 통계 그리드
        sections.append(self._build_stats_section(data))

        # 심각도 분포
        if data.by_severity:
            sections.append(self._build_severity_section(data.by_severity))

        # 시나리오 요약 테이블
        if data.scenarios:
            sections.append(self._build_scenario_table(data.scenarios))

        # 실패 시나리오 상세 카드
        failed = [s for s in data.scenarios if not s.passed]
        if failed:
            sections.append(self._build_failed_details(failed))

        return "\n".join(sections)

    def _build_stats_section(self, data: AirflowDailyReportData) -> str:
        """통계 카드 그리드."""
        pass_rate = (data.passed / data.total_scenarios * 100) if data.total_scenarios > 0 else 0
        stats = [
            {"label": "전체 시나리오", "value": str(data.total_scenarios), "color": MD3_COLORS["primary"]},
            {"label": "통과", "value": str(data.passed), "color": MD3_COLORS["success"]},
            {"label": "실패", "value": str(data.failed), "color": MD3_COLORS["error"]},
            {"label": "통과율", "value": f"{pass_rate:.1f}%", "color": MD3_COLORS["primary"]},
        ]
        return self.render_stat_cards(stats, columns=4)

    def _build_severity_section(self, by_severity: Dict[str, int]) -> str:
        """심각도 분포 카드."""
        badges = []
        for sev in ["critical", "high", "medium", "low"]:
            count = by_severity.get(sev, 0)
            if count > 0:
                badges.append(f"{self.render_severity_badge(sev)} {count}건")
        if not badges:
            badges.append("이슈 없음")
        content = f'<div style="display: flex; gap: 16px; flex-wrap: wrap; padding: 16px;">{"&nbsp;&nbsp;".join(badges)}</div>'
        return self.render_card("심각도 분포", content)

    def _build_scenario_table(self, scenarios: List[AirflowDailyScenario]) -> str:
        """시나리오 요약 테이블."""
        headers = ["시나리오", "환경", "심각도", "신호 수", "결과"]
        rows = []
        for s in scenarios:
            env_label = ENV_KO.get(s.environment, s.environment)
            result_icon = f'<span style="color: {MD3_COLORS["success"]};">PASS</span>' if s.passed else f'<span style="color: {MD3_COLORS["error"]};">FAIL</span>'
            rows.append([
                html_escape(s.name),
                html_escape(env_label),
                self.render_severity_badge(s.severity),
                str(s.signal_count),
                result_icon,
            ])
        table = self.render_table(headers, rows)
        return self.render_card(
            f"시나리오 결과 ({len(scenarios)}건)",
            table,
        )

    def _build_failed_details(self, failed: List[AirflowDailyScenario]) -> str:
        """실패 시나리오 상세 카드."""
        cards = []
        for s in failed:
            env_label = ENV_KO.get(s.environment, s.environment)
            detail_parts = [
                f'<div style="margin-bottom: 8px;">'
                f'<strong>환경:</strong> {html_escape(env_label)} &nbsp; '
                f'<strong>심각도:</strong> {self.render_severity_badge(s.severity)}'
                f'</div>',
            ]
            if s.description:
                detail_parts.append(f'<div style="margin-bottom: 8px;"><strong>설명:</strong> {html_escape(s.description)}</div>')
            if s.root_cause:
                detail_parts.append(f'<div style="margin-bottom: 8px;"><strong>근본 원인:</strong> {html_escape(s.root_cause)}</div>')
            if s.recommended_actions:
                actions_html = "".join(f"<li>{html_escape(a)}</li>" for a in s.recommended_actions)
                detail_parts.append(f'<div><strong>권장 조치:</strong><ul style="margin-top: 4px;">{actions_html}</ul></div>')

            content = f'<div style="padding: 16px;">{"".join(detail_parts)}</div>'
            badge = self.render_severity_badge(s.severity)
            cards.append(self.render_card(
                f"{self._icon('error', size='sm', color='error', inline=True)} {html_escape(s.name)}",
                content,
                header_extra=badge,
            ))
        return f'<h2 style="margin-top: 32px;">실패 시나리오 상세</h2>{"".join(cards)}'

    # ── DB 기반 HTML 재생성 ──────────────────────────────────────

    def generate_from_db(self, report) -> str:
        """DB에서 읽은 AirflowReport 객체의 scenarios_json으로 HTML 재생성.

        Args:
            report: AirflowReport (report_store.py의 dataclass)

        Returns:
            HTML 문자열
        """
        data = self.data_from_json(report)
        return self.generate_report(data)

    @staticmethod
    def data_to_json(data: AirflowDailyReportData) -> str:
        """AirflowDailyReportData → scenarios JSON 문자열."""
        return json.dumps(
            [s.to_dict() for s in data.scenarios],
            ensure_ascii=False,
        )

    @staticmethod
    def data_from_json(report) -> AirflowDailyReportData:
        """AirflowReport의 scenarios_json → AirflowDailyReportData 복원."""
        scenarios = []
        if report.scenarios_json:
            raw = json.loads(report.scenarios_json)
            scenarios = [AirflowDailyScenario.from_dict(s) for s in raw]

        by_severity = report.by_severity
        if isinstance(by_severity, str):
            by_severity = json.loads(by_severity)

        return AirflowDailyReportData(
            total_scenarios=report.total_scenarios,
            passed=report.passed,
            failed=report.failed,
            by_severity=by_severity,
            scenarios=scenarios,
        )
