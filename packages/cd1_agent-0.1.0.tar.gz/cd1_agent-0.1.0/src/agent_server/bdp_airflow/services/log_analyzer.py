"""
Airflow Log Analyzer - CloudWatch Logs 기반 MWAA 태스크/인프라 로그 조회.

CloudWatch Logs filter_log_events() 기반 MWAA 태스크 로그 조회.
MWAA 스케줄러, 워커, DAG Processing 인프라 로그 모니터링 포함.
Mock 모드에서는 샘플 로그를 반환합니다.
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


def _load_infra_config() -> dict[str, Any]:
    """인프라 설정 로드."""
    config_path = Path(__file__).parent.parent / "conf" / "detection_config.json"
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            return json.load(f).get("infrastructure", {})
    return {}


class AirflowLogAnalyzer:
    """CloudWatch 기반 MWAA 태스크 로그 분석기.

    MWAA 환경의 CloudWatch Logs에서 태스크 로그를 조회하고
    에러 컨텍스트를 검색합니다.
    Victoria Logs를 캐시로 사용하여 동일 시간대 로그 재조회 시 성능을 향상합니다.
    """

    def __init__(
        self,
        use_mock: bool = True,
        region: str = "ap-northeast-2",
        log_cache=None,
    ):
        self.use_mock = use_mock
        self.region = region
        self._client = None
        self._log_cache = log_cache  # Optional[LogCacheStore]
        self._infra_config = _load_infra_config()

    @property
    def client(self):
        """Lazy boto3 CloudWatch Logs 클라이언트."""
        if self._client is None and not self.use_mock:
            from src.common.services.aws_session import get_boto3_client

            self._client = get_boto3_client("logs", region=self.region)
        return self._client

    def get_task_logs(
        self,
        log_group: str,
        dag_id: str,
        task_id: str,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """태스크 로그 조회.

        Args:
            log_group: CloudWatch Log Group 이름
            dag_id: DAG ID
            task_id: Task ID
            start_time: 조회 시작 시간
            end_time: 조회 종료 시간
            limit: 최대 로그 수

        Returns:
            로그 이벤트 목록
        """
        if self.use_mock:
            return self._mock_task_logs(dag_id, task_id)

        if not start_time:
            start_time = get_kst_now() - timedelta(hours=24)
        if not end_time:
            end_time = get_kst_now()

        try:
            response = self.client.filter_log_events(
                logGroupName=log_group,
                filterPattern=f'"{dag_id}" "{task_id}"',
                startTime=int(start_time.timestamp() * 1000),
                endTime=int(end_time.timestamp() * 1000),
                limit=limit,
            )
            return response.get("events", [])

        except Exception as e:
            logger.error(f"Failed to get logs for {dag_id}/{task_id}: {e}")
            return []

    def search_error_context(
        self,
        log_group: str,
        error_pattern: str,
        hours: int = 24,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """에러 컨텍스트 검색.

        Args:
            log_group: CloudWatch Log Group 이름
            error_pattern: 검색할 에러 패턴
            hours: 조회 범위 (시간)
            limit: 최대 결과 수

        Returns:
            매칭 로그 이벤트 목록
        """
        if self.use_mock:
            return self._mock_error_search(error_pattern)

        start_time = get_kst_now() - timedelta(hours=hours)

        try:
            response = self.client.filter_log_events(
                logGroupName=log_group,
                filterPattern=f'"{error_pattern}"',
                startTime=int(start_time.timestamp() * 1000),
                endTime=int(get_kst_now().timestamp() * 1000),
                limit=limit,
            )
            return response.get("events", [])

        except Exception as e:
            logger.error(f"Failed to search error pattern '{error_pattern}': {e}")
            return []

    def _mock_task_logs(self, dag_id: str, task_id: str) -> list[dict[str, Any]]:
        """Mock 태스크 로그."""
        now_ms = int(get_kst_now().timestamp() * 1000)
        return [
            {
                "timestamp": now_ms - 60000,
                "message": f"[{dag_id}.{task_id}] Starting task execution",
                "logStreamName": f"scheduler/{dag_id}/{task_id}",
            },
            {
                "timestamp": now_ms - 30000,
                "message": f"[{dag_id}.{task_id}] Processing data...",
                "logStreamName": f"scheduler/{dag_id}/{task_id}",
            },
            {
                "timestamp": now_ms,
                "message": f"[{dag_id}.{task_id}] Task completed",
                "logStreamName": f"scheduler/{dag_id}/{task_id}",
            },
        ]

    def _mock_error_search(self, error_pattern: str) -> list[dict[str, Any]]:
        """Mock 에러 검색 결과."""
        now_ms = int(get_kst_now().timestamp() * 1000)
        return [
            {
                "timestamp": now_ms - 120000,
                "message": f"ERROR: {error_pattern} - Connection refused",
                "logStreamName": "scheduler/mock_dag/mock_task",
            },
        ]

    # =========================================================================
    # MWAA Infrastructure Monitoring
    # =========================================================================

    def get_scheduler_logs(
        self,
        env_name: str,
        hours: int = 6,
        filter_pattern: str | None = None,
    ) -> list[dict[str, Any]]:
        """MWAA 스케줄러 로그 조회.

        Args:
            env_name: MWAA 환경 이름
            hours: 조회 범위 (시간)
            filter_pattern: 추가 필터 패턴

        Returns:
            스케줄러 로그 이벤트 목록
        """
        log_group_tpl = self._infra_config.get(
            "mwaa_log_groups",
            {},
        ).get("scheduler", "/aws/mwaa/{env_name}/scheduler")
        log_group = log_group_tpl.replace("{env_name}", env_name)

        if self.use_mock:
            return self._mock_scheduler_logs(env_name)

        pattern = filter_pattern or "ERROR"
        return self._fetch_logs(log_group, pattern, hours)

    def get_worker_logs(
        self,
        env_name: str,
        hours: int = 6,
        filter_pattern: str | None = None,
    ) -> list[dict[str, Any]]:
        """MWAA 워커 로그 조회.

        Args:
            env_name: MWAA 환경 이름
            hours: 조회 범위 (시간)
            filter_pattern: 추가 필터 패턴

        Returns:
            워커 로그 이벤트 목록
        """
        log_group_tpl = self._infra_config.get(
            "mwaa_log_groups",
            {},
        ).get("worker", "/aws/mwaa/{env_name}/worker")
        log_group = log_group_tpl.replace("{env_name}", env_name)

        if self.use_mock:
            return self._mock_worker_logs(env_name)

        pattern = filter_pattern or "ERROR"
        return self._fetch_logs(log_group, pattern, hours)

    def get_dag_processing_logs(
        self,
        env_name: str,
        hours: int = 6,
    ) -> list[dict[str, Any]]:
        """MWAA DAG Processing 로그 조회.

        Args:
            env_name: MWAA 환경 이름
            hours: 조회 범위 (시간)

        Returns:
            DAG Processing 로그 이벤트 목록
        """
        log_group_tpl = self._infra_config.get(
            "mwaa_log_groups",
            {},
        ).get("dag_processing", "/aws/mwaa/{env_name}/dag_processing")
        log_group = log_group_tpl.replace("{env_name}", env_name)

        if self.use_mock:
            return self._mock_dag_processing_logs(env_name)

        return self._fetch_logs(log_group, "ERROR", hours)

    def check_scheduler_health(
        self,
        env_name: str,
        hours: int = 6,
    ) -> dict[str, Any]:
        """스케줄러 헬스 체크.

        스케줄러 과부하 지표를 분석합니다.

        Returns:
            {"healthy": bool, "issues": [...], "log_count": int}
        """
        logs = self.get_scheduler_logs(env_name, hours)
        indicators = self._infra_config.get("scheduler_overload_indicators", [])

        issues = []
        for log_event in logs:
            msg = log_event.get("message", "")
            for indicator in indicators:
                if indicator.lower() in msg.lower():
                    issues.append(
                        {
                            "indicator": indicator,
                            "message": msg[:200],
                            "timestamp": log_event.get("timestamp"),
                        }
                    )

        return {
            "healthy": len(issues) == 0,
            "issues": issues,
            "log_count": len(logs),
        }

    def check_worker_health(
        self,
        env_name: str,
        hours: int = 6,
    ) -> dict[str, Any]:
        """워커 헬스 체크.

        워커 리소스 부족 지표를 분석합니다.

        Returns:
            {"healthy": bool, "issues": [...], "oom_count": int}
        """
        logs = self.get_worker_logs(env_name, hours)
        indicators = self._infra_config.get("worker_resource_indicators", [])

        issues = []
        oom_count = 0
        for log_event in logs:
            msg = log_event.get("message", "")
            for indicator in indicators:
                if indicator.lower() in msg.lower():
                    issues.append(
                        {
                            "indicator": indicator,
                            "message": msg[:200],
                            "timestamp": log_event.get("timestamp"),
                        }
                    )
                    if indicator in ("SIGKILL", "OOMKilled"):
                        oom_count += 1

        return {
            "healthy": len(issues) == 0,
            "issues": issues,
            "oom_count": oom_count,
            "log_count": len(logs),
        }

    def _fetch_logs(
        self,
        log_group: str,
        filter_pattern: str,
        hours: int,
    ) -> list[dict[str, Any]]:
        """CloudWatch 로그 공통 조회 (Victoria Logs 캐시 적용)."""
        start_time = get_kst_now() - timedelta(hours=hours)
        end_time = get_kst_now()

        # 1. Victoria Logs 캐시 조회
        if self._log_cache:
            try:
                cached = self._log_cache.get_logs(
                    log_group=log_group,
                    start_time=start_time,
                    end_time=end_time,
                    filter_pattern=f'"{filter_pattern}"',
                    limit=100,
                )
                if cached is not None:
                    logger.debug(f"Log cache HIT: {log_group} ({len(cached)} events)")
                    return cached
            except Exception as e:
                logger.warning(f"Log cache read failed: {e}")

        # 2. Cache miss → CloudWatch API 호출
        try:
            response = self.client.filter_log_events(
                logGroupName=log_group,
                filterPattern=f'"{filter_pattern}"',
                startTime=int(start_time.timestamp() * 1000),
                endTime=int(end_time.timestamp() * 1000),
                limit=100,
            )
            events = response.get("events", [])

            # 3. 캐시에 저장
            if events and self._log_cache:
                try:
                    self._log_cache.put_logs(log_group=log_group, events=events)
                except Exception as e:
                    logger.warning(f"Log cache write failed: {e}")

            return events
        except Exception as e:
            logger.error(f"Failed to fetch logs from {log_group}: {e}")
            return []

    def _mock_scheduler_logs(self, env_name: str) -> list[dict[str, Any]]:
        """Mock 스케줄러 로그."""
        now_ms = int(get_kst_now().timestamp() * 1000)
        return [
            {
                "timestamp": now_ms - 300000,
                "message": f"[{env_name}] scheduler_heartbeat_check OK",
                "logStreamName": f"scheduler/{env_name}",
            },
            {
                "timestamp": now_ms - 60000,
                "message": f"[{env_name}] DagFileProcessor stats: 150 dags processed",
                "logStreamName": f"scheduler/{env_name}",
            },
        ]

    def _mock_worker_logs(self, env_name: str) -> list[dict[str, Any]]:
        """Mock 워커 로그."""
        now_ms = int(get_kst_now().timestamp() * 1000)
        return [
            {
                "timestamp": now_ms - 120000,
                "message": f"[{env_name}] celery worker processing tasks",
                "logStreamName": f"worker/{env_name}",
            },
        ]

    def _mock_dag_processing_logs(self, env_name: str) -> list[dict[str, Any]]:
        """Mock DAG Processing 로그."""
        now_ms = int(get_kst_now().timestamp() * 1000)
        return [
            {
                "timestamp": now_ms - 60000,
                "message": f"[{env_name}] DAG processing completed in 2.3s",
                "logStreamName": f"dag_processing/{env_name}",
            },
        ]
