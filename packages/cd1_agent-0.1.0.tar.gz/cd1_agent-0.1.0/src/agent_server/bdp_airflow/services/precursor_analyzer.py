"""
Precursor Analyzer - 전조증상 탐지.

Duration 점진적 증가, warning 키워드, retry 에스컬레이션 등
실패 전조증상을 분석합니다.
"""

import logging
import statistics
from collections import defaultdict
from datetime import datetime
from typing import Any

from src.agent_server.bdp_airflow.services.models import (
    AirflowFailureRecord,
    FailureSeverity,
    PrecursorSignal,
    TaskState,
)

logger = logging.getLogger(__name__)


class PrecursorAnalyzer:
    """전조증상 분석기.

    성공 건 포함한 히스토리에서 실패 전조증상을 탐지:
    - Duration 점진적 증가 추세
    - err_msg 내 warning 키워드 (성공 건에서도)
    - Retry 패턴 에스컬레이션
    - Lead time 계산 (전조 → 실패까지 평균 시간)
    """

    def __init__(
        self,
        z_score_threshold: float = 2.0,
        warning_keywords: list[str] | None = None,
        precursor_window_hours: int = 6,
    ):
        self.z_score_threshold = z_score_threshold
        self.warning_keywords = warning_keywords or [
            "WARNING",
            "WARN",
            "deprecated",
            "retry",
            "timeout",
            "slow",
        ]
        self.precursor_window_hours = precursor_window_hours

    def analyze(
        self,
        history: list[AirflowFailureRecord],
    ) -> list[PrecursorSignal]:
        """히스토리 분석 → 전조증상 목록 반환.

        Args:
            history: 장기 히스토리 레코드 (성공 + 실패 포함)

        Returns:
            PrecursorSignal 목록
        """
        if not history:
            return []

        signals: list[PrecursorSignal] = []

        # 1. Duration 점진적 증가 추세
        signals.extend(self._detect_duration_increase(history))

        # 2. Warning 키워드 에스컬레이션
        signals.extend(self._detect_warning_escalation(history))

        # 3. Retry 패턴 에스컬레이션
        signals.extend(self._detect_retry_escalation(history))

        # 심각도 순 정렬
        severity_order = {
            FailureSeverity.CRITICAL: 0,
            FailureSeverity.HIGH: 1,
            FailureSeverity.MEDIUM: 2,
            FailureSeverity.LOW: 3,
        }
        signals.sort(key=lambda s: (severity_order.get(s.severity, 99), -s.confidence))

        return signals

    def _detect_duration_increase(
        self,
        history: list[AirflowFailureRecord],
    ) -> list[PrecursorSignal]:
        """Duration 점진적 증가 추세 탐지.

        성공 건의 실행 시간이 점진적으로 증가하다가 최종 실패하는 패턴.
        """
        signals = []

        # task별 시간순 정렬된 레코드 그룹핑
        task_records: dict[tuple[str, str], list[AirflowFailureRecord]] = defaultdict(list)
        for r in history:
            task_records[(r.dag_id, r.task_id)].append(r)

        for (dag_id, task_id), records in task_records.items():
            # 시간순 정렬
            sorted_recs = sorted(records, key=lambda r: r.start_date)

            # 성공 건의 duration 추출
            success_durations: list[tuple[str, float]] = []
            has_final_failure = False

            for r in sorted_recs:
                dur = r.duration_seconds
                if dur is not None and dur > 0:
                    if r.state == TaskState.SUCCESS.value:
                        success_durations.append((r.start_date, dur))
                    elif r.is_failed:
                        has_final_failure = True

            if len(success_durations) < 3 or not has_final_failure:
                continue

            # 점진적 증가 검사: 최근 3개의 duration이 단조 증가
            recent = [d[1] for d in success_durations[-3:]]
            if recent[0] < recent[1] < recent[2]:
                ratio = recent[-1] / recent[0]
                if ratio >= 1.5:  # 50% 이상 증가
                    lead_time = self._calc_lead_time(
                        success_durations[-1][0], sorted_recs[-1].start_date
                    )
                    severity = FailureSeverity.HIGH if ratio >= 3.0 else FailureSeverity.MEDIUM

                    signals.append(
                        PrecursorSignal(
                            signal_type="duration_increase",
                            dag_id=dag_id,
                            task_id=task_id,
                            severity=severity,
                            confidence=min(1.0, ratio / 5.0),
                            lead_time_minutes=lead_time,
                            description=(
                                f"{dag_id}/{task_id}의 실행 시간이 "
                                f"{recent[0]:.0f}초 → {recent[1]:.0f}초 → {recent[2]:.0f}초로 "
                                f"점진적으로 증가한 후 실패했습니다 ({ratio:.1f}배 증가)."
                            ),
                            evidence=[
                                f"Duration 추이: {' → '.join(f'{d:.0f}초' for d in recent)}",
                                f"증가율: {ratio:.1f}배",
                                f"Lead time: {lead_time:.0f}분",
                            ],
                        )
                    )

        return signals

    def _detect_warning_escalation(
        self,
        history: list[AirflowFailureRecord],
    ) -> list[PrecursorSignal]:
        """Warning 키워드 에스컬레이션 탐지.

        성공 건에서 warning 키워드가 증가하다가 실패하는 패턴.
        """
        signals = []

        task_records: dict[tuple[str, str], list[AirflowFailureRecord]] = defaultdict(list)
        for r in history:
            task_records[(r.dag_id, r.task_id)].append(r)

        for (dag_id, task_id), records in task_records.items():
            sorted_recs = sorted(records, key=lambda r: r.start_date)

            # 성공 건 중 warning 있는 것 찾기
            warnings_before_failure: list[AirflowFailureRecord] = []
            final_failure: AirflowFailureRecord | None = None

            for r in sorted_recs:
                if r.state == TaskState.SUCCESS.value and r.err_msg:
                    for kw in self.warning_keywords:
                        if kw.lower() in r.err_msg.lower():
                            warnings_before_failure.append(r)
                            break
                elif r.is_failed:
                    final_failure = r

            if warnings_before_failure and final_failure:
                lead_time = self._calc_lead_time(
                    warnings_before_failure[-1].start_date, final_failure.start_date
                )
                sample_warnings = list({r.err_msg for r in warnings_before_failure[:3]})

                signals.append(
                    PrecursorSignal(
                        signal_type="warning_keyword",
                        dag_id=dag_id,
                        task_id=task_id,
                        severity=FailureSeverity.MEDIUM,
                        confidence=min(1.0, len(warnings_before_failure) / 5),
                        lead_time_minutes=lead_time,
                        description=(
                            f"{dag_id}/{task_id}에서 성공 건 {len(warnings_before_failure)}개에 "
                            f"워닝 메시지가 감지된 후 실패가 발생했습니다."
                        ),
                        evidence=sample_warnings,
                    )
                )

        return signals

    def _detect_retry_escalation(
        self,
        history: list[AirflowFailureRecord],
    ) -> list[PrecursorSignal]:
        """Retry 패턴 에스컬레이션 탐지.

        같은 run_id에서 실패 → 재시도 → 실패가 반복되는 패턴.
        """
        signals = []

        # run_id별 레코드 그룹핑
        run_records: dict[str, list[AirflowFailureRecord]] = defaultdict(list)
        for r in history:
            if r.run_id:
                run_records[r.run_id].append(r)

        for run_id, records in run_records.items():
            # 같은 task의 실패 횟수
            task_failures: dict[str, int] = defaultdict(int)
            for r in records:
                if r.is_failed:
                    task_failures[r.task_id] += 1

            for task_id, count in task_failures.items():
                if count >= 3:  # 3회 이상 재시도 실패
                    dag_id = records[0].dag_id
                    signals.append(
                        PrecursorSignal(
                            signal_type="retry_escalation",
                            dag_id=dag_id,
                            task_id=task_id,
                            severity=FailureSeverity.MEDIUM,
                            confidence=min(1.0, count / 5),
                            lead_time_minutes=0,
                            description=(
                                f"{dag_id}/{task_id}가 run_id={run_id}에서 "
                                f"{count}회 재시도 후에도 실패했습니다."
                            ),
                            evidence=[
                                f"재시도 횟수: {count}회",
                                f"run_id: {run_id}",
                            ],
                        )
                    )

        return signals

    def predict_sla_violations(
        self,
        history: list[AirflowFailureRecord],
        sla_configs: dict[str, float] | None = None,
    ) -> list[dict[str, Any]]:
        """DAG별 SLA 위반 예측.

        최근 실행 시간 추세를 분석하여 SLA 초과 가능성을 예측합니다.

        Args:
            history: 장기 히스토리 레코드
            sla_configs: DAG별 SLA 기준 (초). 예: {"etl_daily": 3600}
                        None이면 평균 duration * 2를 기본 SLA로 사용.

        Returns:
            SLA 위반 예측 목록 [{dag_id, predicted_duration, sla_limit, violation_probability, ...}]
        """
        if not history:
            return []

        sla_configs = sla_configs or {}
        predictions: list[dict[str, Any]] = []

        # DAG별 성공 건의 duration 그룹핑
        dag_durations: dict[str, list[tuple[str, float]]] = defaultdict(list)
        for r in history:
            dur = r.duration_seconds
            if dur and dur > 0 and r.state == TaskState.SUCCESS.value:
                dag_durations[r.dag_id].append((r.start_date, dur))

        for dag_id, durations in dag_durations.items():
            if len(durations) < 3:
                continue

            # 시간순 정렬
            sorted_durs = sorted(durations, key=lambda x: x[0])
            values = [d[1] for d in sorted_durs]

            # SLA 기준 결정
            sla_limit = sla_configs.get(dag_id)
            if sla_limit is None:
                avg = statistics.mean(values)
                sla_limit = avg * 2  # 기본: 평균의 2배

            # 최근 3~5건의 추세 분석
            recent = values[-min(5, len(values)) :]
            recent_avg = statistics.mean(recent)

            # 선형 추세 추정 (단순 기울기)
            if len(recent) >= 3:
                slopes = [recent[i + 1] - recent[i] for i in range(len(recent) - 1)]
                avg_slope = statistics.mean(slopes)
                predicted_next = recent[-1] + avg_slope
            else:
                avg_slope = 0
                predicted_next = recent_avg

            # SLA 위반 확률 계산
            if predicted_next <= 0 or sla_limit <= 0:
                continue

            ratio = predicted_next / sla_limit
            if ratio >= 1.0:
                probability = min(0.99, 0.5 + (ratio - 1.0) * 2)
            elif ratio >= 0.8:
                probability = (ratio - 0.8) / 0.2 * 0.5
            else:
                probability = 0.0

            if probability < 0.3:
                continue

            predictions.append(
                {
                    "dag_id": dag_id,
                    "sla_limit_seconds": round(sla_limit, 1),
                    "recent_durations": [round(d, 1) for d in recent],
                    "predicted_next_duration": round(max(0, predicted_next), 1),
                    "trend_slope_per_run": round(avg_slope, 2),
                    "violation_probability": round(probability, 2),
                    "severity": (
                        "critical"
                        if probability >= 0.8
                        else "high"
                        if probability >= 0.6
                        else "medium"
                    ),
                    "message": (
                        f"{dag_id}의 실행 시간이 "
                        f"{recent[-1]:.0f}초 → 예측 {max(0, predicted_next):.0f}초 "
                        f"(SLA {sla_limit:.0f}초 대비 {ratio:.0%}). "
                        f"위반 확률: {probability:.0%}"
                    ),
                }
            )

        # 확률 높은 순 정렬
        predictions.sort(key=lambda x: x["violation_probability"], reverse=True)
        return predictions

    @staticmethod
    def _calc_lead_time(from_date: str, to_date: str) -> float:
        """두 날짜 사이의 시간 차이 (분)."""
        try:
            t1 = datetime.strptime(from_date[:19], "%Y-%m-%d %H:%M:%S")
            t2 = datetime.strptime(to_date[:19], "%Y-%m-%d %H:%M:%S")
            return max(0, (t2 - t1).total_seconds() / 60)
        except (ValueError, TypeError):
            return 0.0
