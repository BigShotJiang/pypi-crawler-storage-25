"""
BDP Airflow Agent Services.

Service modules for Airflow failure pattern detection and analysis.
"""
