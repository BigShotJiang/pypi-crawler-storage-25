"""
Airflow 자동 복구 엔진.

리스크 수준별 자동 복구 액션을 관리하고 실행합니다.
- Low: 완전 자동 (task retry, stuck DAG clear, 로그 수집)
- Medium: HITL 승인 필요 (downstream pause, backfill)
- High: 반드시 HITL (환경 변경, 스케줄 변경)
"""

import logging
import os
from typing import Any

from src.agent_server.bdp_airflow.services.models import (
    FailurePattern,
    FailurePatternType,
    FailureSeverity,
    RemediationAction,
    RemediationActionType,
    RemediationResult,
    RemediationRiskLevel,
)
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


class RemediationEngine:
    """Airflow 자동 복구 엔진.

    탐지된 패턴을 분석하여 적절한 복구 액션을 생성하고 실행합니다.
    Low risk 액션은 자동 실행, Medium/High risk는 HITL 요청 생성.
    """

    def __init__(
        self,
        auto_execute_low_risk: bool = True,
        mwaa_environment: str | None = None,
    ):
        self.auto_execute_low_risk = auto_execute_low_risk
        self.mwaa_environment = mwaa_environment or os.getenv("MWAA_ENVIRONMENT_NAME", "")
        self._audit_log: list[dict[str, Any]] = []

    def analyze_patterns(
        self,
        patterns: list[FailurePattern],
    ) -> list[RemediationAction]:
        """탐지된 패턴에서 복구 액션 목록 생성."""
        actions: list[RemediationAction] = []

        for pattern in patterns:
            pattern_actions = self._generate_actions_for_pattern(pattern)
            actions.extend(pattern_actions)

        # 중복 제거 (같은 DAG + 같은 액션 타입)
        seen: set[str] = set()
        unique_actions: list[RemediationAction] = []
        for action in actions:
            key = f"{action.dag_id}:{action.action_type.value}"
            if key not in seen:
                seen.add(key)
                unique_actions.append(action)

        return unique_actions

    def execute_low_risk(
        self,
        actions: list[RemediationAction],
    ) -> list[RemediationResult]:
        """Low risk 액션만 자동 실행."""
        results: list[RemediationResult] = []

        low_risk_actions = [a for a in actions if a.risk_level == RemediationRiskLevel.LOW]

        for action in low_risk_actions:
            result = self._execute_action(action)
            results.append(result)
            self._audit_log.append(
                {
                    "timestamp": get_kst_now().isoformat(),
                    "action": action.action_type.value,
                    "dag_id": action.dag_id,
                    "risk_level": action.risk_level.value,
                    "success": result.success,
                    "message": result.message,
                }
            )

        return results

    def get_hitl_actions(
        self,
        actions: list[RemediationAction],
    ) -> list[RemediationAction]:
        """HITL 승인이 필요한 Medium/High risk 액션 반환."""
        return [
            a
            for a in actions
            if a.risk_level in (RemediationRiskLevel.MEDIUM, RemediationRiskLevel.HIGH)
        ]

    @property
    def audit_log(self) -> list[dict[str, Any]]:
        """감사 로그 반환."""
        return list(self._audit_log)

    def _generate_actions_for_pattern(
        self,
        pattern: FailurePattern,
    ) -> list[RemediationAction]:
        """패턴 타입별 복구 액션 생성."""
        actions: list[RemediationAction] = []

        # 단일 Task 실패 -> retry
        if pattern.pattern_type == FailurePatternType.SINGLE_TASK:
            for dag_id in pattern.affected_dags:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.TASK_RETRY,
                        risk_level=RemediationRiskLevel.LOW,
                        dag_id=dag_id,
                        description=f"{dag_id} 실패 Task 재시도",
                        parameters={
                            "tasks": pattern.affected_tasks,
                            "max_retries": 1,
                        },
                    )
                )

        # 캐스케이딩 실패 -> downstream pause (HITL)
        elif pattern.pattern_type == FailurePatternType.CASCADING:
            root_dag = pattern.affected_dags[0] if pattern.affected_dags else "unknown"
            downstream_dags = pattern.affected_dags[1:] if len(pattern.affected_dags) > 1 else []

            # 로그 수집 (Low)
            actions.append(
                RemediationAction(
                    action_type=RemediationActionType.COLLECT_LOGS,
                    risk_level=RemediationRiskLevel.LOW,
                    dag_id=root_dag,
                    description=f"{root_dag} 캐스케이딩 실패 로그 수집",
                    parameters={"hours_back": 6},
                )
            )

            # downstream pause (Medium)
            if downstream_dags:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.PAUSE_DOWNSTREAM,
                        risk_level=RemediationRiskLevel.MEDIUM,
                        dag_id=root_dag,
                        description=(
                            f"{root_dag} 실패로 인한 downstream DAG 일시 중지 "
                            f"({len(downstream_dags)}개)"
                        ),
                        parameters={"downstream_dags": downstream_dags},
                        requires_hitl=True,
                        hitl_expires_minutes=30,
                    )
                )

        # 반복 실패 -> retry + 로그 수집
        elif pattern.pattern_type == FailurePatternType.RECURRING:
            for dag_id in pattern.affected_dags:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.COLLECT_LOGS,
                        risk_level=RemediationRiskLevel.LOW,
                        dag_id=dag_id,
                        description=f"{dag_id} 반복 실패 로그 수집",
                        parameters={"hours_back": 24},
                    )
                )

        # 인프라 관련 (worker OOM 등) -> retry + 환경 스케일 (HITL)
        elif pattern.pattern_type in (
            FailurePatternType.WORKER_RESOURCE,
            FailurePatternType.INFRA_COMPOUND,
            FailurePatternType.SCHEDULER_OVERLOAD,
        ):
            for dag_id in pattern.affected_dags[:3]:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.TASK_RETRY,
                        risk_level=RemediationRiskLevel.LOW,
                        dag_id=dag_id,
                        description=f"{dag_id} 인프라 장애 후 재시도",
                        parameters={"tasks": pattern.affected_tasks, "max_retries": 1},
                    )
                )

            if pattern.severity in (FailureSeverity.CRITICAL, FailureSeverity.HIGH):
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.SCALE_ENVIRONMENT,
                        risk_level=RemediationRiskLevel.HIGH,
                        dag_id=pattern.affected_dags[0] if pattern.affected_dags else "mwaa",
                        description="MWAA 환경 워커 사양 상향 제안",
                        parameters={
                            "environment": self.mwaa_environment,
                            "suggestion": "worker 인스턴스 타입 상향",
                        },
                        requires_hitl=True,
                        hitl_expires_minutes=240,
                    )
                )

        # Duration 이상 -> 로그 수집
        elif pattern.pattern_type == FailurePatternType.DURATION_ANOMALY:
            for dag_id in pattern.affected_dags:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.COLLECT_LOGS,
                        risk_level=RemediationRiskLevel.LOW,
                        dag_id=dag_id,
                        description=f"{dag_id} duration 이상 로그 수집",
                        parameters={"hours_back": 12},
                    )
                )

        # 외부 시스템 실패 -> 로그 수집
        elif pattern.pattern_type in (
            FailurePatternType.SAGEMAKER_PIPELINE,
            FailurePatternType.EMR_CLUSTER,
            FailurePatternType.SFTP_TRANSFER,
            FailurePatternType.EXTERNAL_API,
        ):
            for dag_id in pattern.affected_dags:
                actions.append(
                    RemediationAction(
                        action_type=RemediationActionType.COLLECT_LOGS,
                        risk_level=RemediationRiskLevel.LOW,
                        dag_id=dag_id,
                        description=f"{dag_id} 외부 시스템 실패 로그 수집",
                        parameters={"hours_back": 6},
                    )
                )

        return actions

    def _execute_action(self, action: RemediationAction) -> RemediationResult:
        """액션 실행 (현재 MWAA API 미연동 시 시뮬레이션)."""
        now = get_kst_now().isoformat()

        if action.action_type == RemediationActionType.TASK_RETRY:
            return self._execute_task_retry(action, now)
        elif action.action_type == RemediationActionType.COLLECT_LOGS:
            return self._execute_collect_logs(action, now)
        elif action.action_type == RemediationActionType.CLEAR_STUCK_DAG:
            return self._execute_clear_stuck(action, now)

        return RemediationResult(
            action_type=action.action_type,
            dag_id=action.dag_id,
            success=False,
            message=f"미지원 액션: {action.action_type.value}",
            executed_at=now,
        )

    def _execute_task_retry(self, action: RemediationAction, now: str) -> RemediationResult:
        """Task retry 실행."""
        try:
            if not self.mwaa_environment:
                logger.info(
                    f"[DRY-RUN] Task retry: {action.dag_id} "
                    f"tasks={action.parameters.get('tasks', [])}"
                )
                return RemediationResult(
                    action_type=action.action_type,
                    dag_id=action.dag_id,
                    success=True,
                    message=f"[DRY-RUN] Task retry 예약됨: {action.dag_id}",
                    executed_at=now,
                )

            # MWAA CLI Token으로 실행
            import boto3

            mwaa_client = boto3.client(
                "mwaa", region_name=os.getenv("AWS_REGION", "ap-northeast-2")
            )
            tasks = action.parameters.get("tasks", [])
            cli_command = f"tasks clear {action.dag_id} -t {','.join(tasks)} -y"

            response = mwaa_client.create_cli_token(Name=self.mwaa_environment)
            # CLI 실행은 HTTP 요청으로 수행
            import requests

            cli_url = f"https://{response['WebServerHostname']}/aws_mwaa/cli"
            headers = {
                "Authorization": f"Bearer {response['CliToken']}",
                "Content-Type": "text/plain",
            }
            result = requests.post(cli_url, headers=headers, data=cli_command, timeout=30)

            success = result.status_code == 200
            return RemediationResult(
                action_type=action.action_type,
                dag_id=action.dag_id,
                success=success,
                message=f"Task retry {'성공' if success else '실패'}: {action.dag_id}",
                executed_at=now,
            )
        except Exception as e:
            logger.error(f"Task retry 실행 실패: {e}")
            return RemediationResult(
                action_type=action.action_type,
                dag_id=action.dag_id,
                success=False,
                message=f"Task retry 실패: {e}",
                executed_at=now,
            )

    def _execute_collect_logs(self, action: RemediationAction, now: str) -> RemediationResult:
        """로그 수집 실행."""
        try:
            from src.agent_server.bdp_airflow.services.log_analyzer import AirflowLogAnalyzer

            log_provider = os.getenv("LOG_PROVIDER", "mock")
            analyzer = AirflowLogAnalyzer(use_mock=log_provider == "mock")

            hours_back = action.parameters.get("hours_back", 6)
            results = analyzer.search_error_context(
                dag_id=action.dag_id,
                hours=hours_back,
                keywords=["ERROR", "CRITICAL", "Exception", "Traceback"],
            )

            return RemediationResult(
                action_type=action.action_type,
                dag_id=action.dag_id,
                success=True,
                message=f"로그 수집 완료: {action.dag_id} ({len(results)}건)",
                executed_at=now,
            )
        except Exception as e:
            logger.error(f"로그 수집 실패: {e}")
            return RemediationResult(
                action_type=action.action_type,
                dag_id=action.dag_id,
                success=False,
                message=f"로그 수집 실패: {e}",
                executed_at=now,
            )

    def _execute_clear_stuck(self, action: RemediationAction, now: str) -> RemediationResult:
        """Stuck DAG clear 실행."""
        logger.info(f"[DRY-RUN] Clear stuck DAG: {action.dag_id}")
        return RemediationResult(
            action_type=action.action_type,
            dag_id=action.dag_id,
            success=True,
            message=f"[DRY-RUN] Stuck DAG clear 예약됨: {action.dag_id}",
            executed_at=now,
        )
