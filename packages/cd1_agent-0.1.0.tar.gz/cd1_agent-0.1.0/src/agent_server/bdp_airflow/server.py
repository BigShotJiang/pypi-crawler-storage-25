"""
BDP Airflow Agent HTTP Server.

FastAPI server for BDP Airflow Agent - Failure Pattern Detection
(port 8007).
"""

import logging
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional

from src.common.timezone import get_kst_now

from fastapi import APIRouter, FastAPI, HTTPException
from pydantic import BaseModel, Field

from src.agent_server.bdp_airflow.handler import BDPAirflowHandler
from src.common.server.adapter import create_handler_endpoint
from src.common.server.base_app import create_app
from src.common.server.config import get_settings

logger = logging.getLogger(__name__)

# Global state for tracking
_agent_state = {
    "start_time": None,
    "last_detection": None,
    "detection_count": 0,
    "error_count": 0,
    "total_patterns_found": 0,
}


# ============================================================================
# Request/Response Schemas
# ============================================================================


class AirflowDetectionRequest(BaseModel):
    """Airflow 실패 패턴 탐지 요청."""

    hours: int = Field(default=24, ge=1, le=168, description="분석 기간 (시간)")
    publish_alerts: bool = Field(default=True, description="EventBridge 알람 발송 여부")


class DagDetailRequest(BaseModel):
    """DAG 상세 분석 요청."""

    dag_id: str = Field(description="분석할 DAG ID")
    days: int = Field(default=7, ge=1, le=30, description="분석 기간 (일)")


class PrecursorScanRequest(BaseModel):
    """전조증상 스캔 요청."""

    days: int = Field(default=7, ge=1, le=30, description="분석 기간 (일)")


class AgentStatusResponse(BaseModel):
    """에이전트 상태 응답."""

    agent: str
    status: str
    environment: str
    version: str
    uptime_seconds: float
    last_detection: Optional[str]
    detection_count: int
    error_count: int
    total_patterns_found: int
    config: Dict[str, Any]
    timestamp: str


# ============================================================================
# Application Setup
# ============================================================================


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan manager for BDP Airflow agent."""
    settings = get_settings()
    logger.info("BDP Airflow Agent 서버 시작...")
    logger.info(f"Environment: {settings.environment}")
    logger.info(f"AWS Provider: {settings.aws_provider}")

    _agent_state["start_time"] = get_kst_now()

    yield

    logger.info("BDP Airflow Agent 서버 종료...")


def create_detection_router() -> APIRouter:
    """BDP Airflow detection router 생성."""
    router = APIRouter()

    # Handler endpoint 생성
    _detect_endpoint = create_handler_endpoint(BDPAirflowHandler)

    @router.post(
        "/detect",
        summary="Airflow 실패 패턴 탐지 실행",
        description="""
        Airflow(MWAA) DAG/Task 실패 데이터를 분석하여 패턴을 탐지합니다.

        **탐지 방법:**
        - 빈도 분석 (반복 실패)
        - 시간대별 패턴
        - 캐스케이딩 실패
        - Duration 이상
        - 환경별 패턴
        - 전조증상 분석
        - op_kwargs 클러스터링
        - Cross-DAG 상관분석

        **출력:**
        - 한글 Rich Summary
        - 심각도별 분류 (critical, high, medium, low)
        """,
    )
    async def detect(request: AirflowDetectionRequest) -> Dict[str, Any]:
        """Airflow 실패 패턴 탐지 실행."""
        try:
            result = await _detect_endpoint(request.model_dump())
            _agent_state["last_detection"] = get_kst_now().isoformat()
            _agent_state["detection_count"] += 1

            if result.get("success") and "data" in result:
                data = result["data"]
                _agent_state["total_patterns_found"] += data.get("patterns_detected", 0)
                return data
            elif result.get("success") is False:
                _agent_state["error_count"] += 1
                raise HTTPException(
                    status_code=500,
                    detail=result.get("error", "탐지 실패"),
                )

            return result

        except HTTPException:
            raise
        except Exception as e:
            _agent_state["error_count"] += 1
            logger.error(f"탐지 오류: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post(
        "/dag-detail",
        summary="DAG 상세 분석",
        description="특정 DAG의 실패 패턴과 전조증상을 상세 분석합니다.",
    )
    async def dag_detail(request: DagDetailRequest) -> Dict[str, Any]:
        """DAG 상세 분석."""
        try:
            payload = {"action": "dag_detail", **request.model_dump()}
            result = await _detect_endpoint(payload)

            if result.get("success") and "data" in result:
                return result["data"]
            return result

        except Exception as e:
            logger.error(f"DAG 분석 오류: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post(
        "/precursor-scan",
        summary="전조증상 스캔",
        description="전체 환경의 전조증상을 전용으로 스캔합니다.",
    )
    async def precursor_scan(request: PrecursorScanRequest) -> Dict[str, Any]:
        """전조증상 전용 스캔."""
        try:
            payload = {"action": "precursor_scan", **request.model_dump()}
            result = await _detect_endpoint(payload)

            if result.get("success") and "data" in result:
                return result["data"]
            return result

        except Exception as e:
            logger.error(f"전조증상 스캔 오류: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get(
        "/status",
        response_model=AgentStatusResponse,
        summary="에이전트 상태 조회",
        description="BDP Airflow 에이전트의 현재 상태 및 통계를 조회합니다.",
    )
    async def status() -> Dict[str, Any]:
        """에이전트 상태 조회."""
        settings = get_settings()
        uptime = 0.0
        if _agent_state["start_time"]:
            uptime = (get_kst_now() - _agent_state["start_time"]).total_seconds()

        return {
            "agent": "bdp-airflow",
            "status": "healthy",
            "environment": settings.environment,
            "version": "1.0.0",
            "uptime_seconds": uptime,
            "last_detection": _agent_state["last_detection"],
            "detection_count": _agent_state["detection_count"],
            "error_count": _agent_state["error_count"],
            "total_patterns_found": _agent_state["total_patterns_found"],
            "config": {
                "aws_provider": settings.aws_provider,
                "bdp_provider": settings.bdp_provider,
                "event_bus": settings.event_bus,
            },
            "timestamp": get_kst_now().isoformat(),
        }

    return router


def create_bdp_airflow_app() -> FastAPI:
    """BDP Airflow agent FastAPI application 생성."""
    app = create_app(
        agent_name="bdp-airflow",
        title="CD1 BDP Airflow Agent",
        description="Airflow(MWAA) 실패 패턴 탐지 서비스",
        lifespan=lifespan,
    )

    # Detection router 추가
    detection_router = create_detection_router()
    app.include_router(
        detection_router,
        prefix="/api/v1",
        tags=["detection"],
    )

    return app


# Application instance
app = create_bdp_airflow_app()


if __name__ == "__main__":
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "src.agent_server.bdp_airflow.server:app",
        host=settings.host,
        port=8007,  # BDP Airflow는 port 8007 사용
        reload=settings.debug,
        workers=settings.workers if not settings.debug else 1,
    )
