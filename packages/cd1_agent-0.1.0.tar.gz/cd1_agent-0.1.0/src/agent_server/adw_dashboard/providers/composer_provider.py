"""Cloud Composer Provider - DAG 통계, 환경 상태, 태스크 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseComposerProvider(ABC):
    @abstractmethod
    def get_dag_run_stats(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_environment_health(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_task_metrics(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_overview_health(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_dag_statistics(self, days: int = 31) -> dict[str, Any]: ...


class MockComposerProvider(BaseComposerProvider):
    """Mock 데이터 기반 Cloud Composer Provider."""

    def get_dag_run_stats(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        dags: dict[str, list] = {}
        for dag_name, weekday_runs, fail_rate in [
            ("etl_daily_pipeline", 24, 0.03),
            ("ml_feature_pipeline", 12, 0.05),
            ("report_generation", 8, 0.02),
            ("data_quality_check", 48, 0.04),
            ("gcs_cleanup", 4, 0.01),
        ]:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                total = weekday_runs if not is_weekend else max(1, weekday_runs // 3)
                total += random.randint(-2, 2)
                total = max(0, total)
                failed = int(total * fail_rate) + (1 if random.random() < fail_rate * 3 else 0)
                data.append(
                    {
                        "date": d,
                        "success": total - failed,
                        "failed": failed,
                    }
                )
            dags[dag_name] = data
        return {"dags": dags}

    def get_environment_health(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "scheduler_heartbeat": random.choice(
                        ["healthy", "healthy", "healthy", "degraded"]
                    ),
                    "worker_count": random.randint(3, 6),
                    "worker_healthy": random.randint(3, 6),
                    "dag_bag_size": random.randint(45, 55),
                    "scheduler_cpu_pct": round(random.uniform(15, 65), 1),
                    "scheduler_memory_pct": round(random.uniform(30, 70), 1),
                    "db_connections": random.randint(10, 40),
                }
            )
        return {
            "environment_name": "adw-composer-prod",
            "airflow_version": "2.7.3",
            "python_version": "3.11",
            "daily": daily,
        }

    def get_task_metrics(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_tasks = 50 if is_weekend else random.randint(150, 350)
            daily.append(
                {
                    "date": d,
                    "total_tasks": base_tasks,
                    "success_tasks": int(base_tasks * random.uniform(0.92, 0.99)),
                    "failed_tasks": random.randint(0, max(1, int(base_tasks * 0.05))),
                    "avg_duration_sec": round(random.uniform(30, 180), 1),
                    "queued_tasks": random.randint(0, 10),
                }
            )
        return {"daily": daily}

    def get_overview_health(self, days: int = 31) -> dict[str, Any]:
        """환경/Scheduler/WebServer/DB health 통합 Overview."""
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "environment_health": random.choice(["healthy"] * 9 + ["degraded"]),
                    "scheduler_health": random.choice(["healthy"] * 9 + ["degraded"]),
                    "webserver_health": "healthy",
                    "database_health": "healthy",
                }
            )
        return {
            "environment_name": "gdp-adw-af-v3-adw-etl",
            "image_version": "composer-3-airflow-2.10.5-build.9",
            "location": "asia-northeast3",
            "environment_size": "Large",
            "resilience_mode": "Standard",
            "daily": daily,
        }

    def get_dag_statistics(self, days: int = 31) -> dict[str, Any]:
        """DAG 실행 통계 (6시간 기준)."""
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_runs = 800 if is_weekend else 2800
            failed_ratio = random.uniform(0.03, 0.05)
            successful = int(base_runs * (1 - failed_ratio)) + random.randint(-50, 50)
            failed = int(base_runs * failed_ratio) + random.randint(-10, 20)
            daily.append(
                {
                    "date": d,
                    "successful_dag_runs": max(0, successful),
                    "failed_dag_runs": max(0, failed),
                    "failed_tasks": max(0, failed + random.randint(-5, 15)),
                    "median_dag_run_duration_min": round(random.uniform(1.0, 3.5), 1),
                }
            )
        return {"daily": daily}


class RealComposerProvider(BaseComposerProvider):
    """GCP Cloud Composer API 연동 Provider."""

    def __init__(self, environment_name: str | None = None, project_id: str | None = None):
        self.environment_name = environment_name
        self.project_id = project_id

    def get_dag_run_stats(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Composer provider not yet implemented")

    def get_environment_health(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Composer provider not yet implemented")

    def get_task_metrics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Composer provider not yet implemented")

    def get_overview_health(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Composer provider not yet implemented")

    def get_dag_statistics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Composer provider not yet implemented")
