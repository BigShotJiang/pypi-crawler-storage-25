"""Composer Scheduler Provider - Scheduler Pod 리소스 및 Heartbeat 상태."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseSchedulerProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_heartbeat_status(self, days: int = 31) -> dict[str, Any]: ...


class MockSchedulerProvider(BaseSchedulerProvider):
    """Mock 데이터 기반 Scheduler Provider."""

    INSTANCES = 2
    VCPU = 1
    MEMORY_GB = 4

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_cpu = 10 if is_weekend else 15
            base_mem = 9 if is_weekend else 12
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(base_cpu + random.uniform(-3, 8), 1),
                    "memory_pct": round(base_mem + random.uniform(-2, 5), 1),
                    "disk_pct": round(random.uniform(0, 2), 1),
                    "container_restarts": 0,
                    "pod_evictions": 0,
                }
            )
        return {
            "instances": self.INSTANCES,
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "daily": daily,
        }

    def get_heartbeat_status(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            errors = random.randint(80, 130)
            daily.append(
                {
                    "date": d,
                    "heartbeat": random.choice(
                        ["healthy", "healthy", "healthy", "healthy", "degraded"]
                    ),
                    "errors_6h": errors,
                    "parse_errors": random.randint(0, 5),
                }
            )
        return {"daily": daily}


class RealSchedulerProvider(BaseSchedulerProvider):
    """GCP Composer Scheduler API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Scheduler provider not yet implemented")

    def get_heartbeat_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Scheduler provider not yet implemented")
