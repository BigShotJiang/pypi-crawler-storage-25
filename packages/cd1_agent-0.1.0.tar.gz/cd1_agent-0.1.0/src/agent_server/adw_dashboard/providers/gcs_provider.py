"""GCS Provider - 버킷 저장소, 접근 패턴, 스토리지 클래스."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseGcsProvider(ABC):
    @abstractmethod
    def get_bucket_storage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_access_patterns(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_storage_class_distribution(self, days: int = 31) -> dict[str, Any]: ...


class MockGcsProvider(BaseGcsProvider):
    """Mock 데이터 기반 GCS Provider."""

    def get_bucket_storage(self, days: int = 31) -> dict[str, Any]:
        buckets: dict[str, list] = {}
        dates = _daily_dates(days)
        for bucket_name, base_tb, obj_count in [
            ("adw-raw-data", 8.5, 1_250_000),
            ("adw-processed", 5.2, 850_000),
            ("adw-ml-artifacts", 2.1, 320_000),
            ("adw-backups", 12.0, 450_000),
            ("adw-logs", 1.8, 2_100_000),
        ]:
            data = []
            for i, d in enumerate(dates):
                growth = i * 0.02
                data.append(
                    {
                        "date": d,
                        "size_tb": round(base_tb + growth + random.uniform(-0.1, 0.1), 2),
                        "object_count": obj_count + i * random.randint(500, 2000),
                    }
                )
            buckets[bucket_name] = data
        return {"buckets": buckets}

    def get_access_patterns(self, days: int = 31) -> dict[str, Any]:
        buckets: dict[str, list] = {}
        dates = _daily_dates(days)
        for bucket_name, read_base, write_base in [
            ("adw-raw-data", 5000, 3000),
            ("adw-processed", 8000, 1500),
            ("adw-ml-artifacts", 2000, 500),
            ("adw-backups", 200, 100),
            ("adw-logs", 1000, 5000),
        ]:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                factor = 0.3 if is_weekend else 1.0
                data.append(
                    {
                        "date": d,
                        "read_ops": int(read_base * factor + random.randint(-500, 500)),
                        "write_ops": int(write_base * factor + random.randint(-300, 300)),
                    }
                )
            buckets[bucket_name] = data
        return {"buckets": buckets}

    def get_storage_class_distribution(self, days: int = 31) -> dict[str, Any]:
        return {
            "classes": {
                "STANDARD": round(15.2 + random.uniform(-0.5, 0.5), 2),
                "NEARLINE": round(8.7 + random.uniform(-0.3, 0.3), 2),
                "COLDLINE": round(3.4 + random.uniform(-0.2, 0.2), 2),
                "ARCHIVE": round(2.3 + random.uniform(-0.1, 0.1), 2),
            }
        }


class RealGcsProvider(BaseGcsProvider):
    """GCP Cloud Storage API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_bucket_storage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real GCS provider not yet implemented")

    def get_access_patterns(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real GCS provider not yet implemented")

    def get_storage_class_distribution(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real GCS provider not yet implemented")
