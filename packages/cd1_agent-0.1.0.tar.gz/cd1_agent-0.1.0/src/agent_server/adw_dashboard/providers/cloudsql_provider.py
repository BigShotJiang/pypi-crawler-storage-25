"""Composer Cloud SQL Provider - Cloud SQL 리소스 및 DB Health."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseCloudSqlProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_db_health(self, days: int = 31) -> dict[str, Any]: ...


class MockCloudSqlProvider(BaseCloudSqlProvider):
    """Mock 데이터 기반 Cloud SQL Provider."""

    VCPU = 8
    MEMORY_GB = 29
    DISK_GB = 100

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(random.uniform(2, 8), 1),
                    "memory_pct": round(random.uniform(35, 44), 1),
                    "disk_pct": round(random.uniform(6, 11), 1),
                }
            )
        return {
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "disk_gb": self.DISK_GB,
            "daily": daily,
        }

    def get_db_health(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        base_size = 320
        for d in dates:
            base_size += random.uniform(0.05, 0.3)
            daily.append(
                {
                    "date": d,
                    "db_size_mb": round(base_size, 1),
                    "active_connections": random.randint(10, 30),
                    "max_connections": 1800,
                    "slow_queries": random.randint(0, 5),
                    "health_status": "healthy",
                    "metadata_db_size_mb": round(base_size, 1),
                }
            )
        return {"daily": daily}


class RealCloudSqlProvider(BaseCloudSqlProvider):
    """GCP Cloud SQL API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Cloud SQL provider not yet implemented")

    def get_db_health(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Cloud SQL provider not yet implemented")
