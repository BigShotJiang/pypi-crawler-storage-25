"""Composer Triggerer Provider - Triggerer Pod 리소스 및 트리거 통계."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseTriggererProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_trigger_stats(self, days: int = 31) -> dict[str, Any]: ...


class MockTriggererProvider(BaseTriggererProvider):
    """Mock 데이터 기반 Triggerer Provider."""

    VCPU = 0.5
    MEMORY_GB = 1

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(random.uniform(3, 10), 1),
                    "memory_pct": round(random.uniform(20, 32), 1),
                    "disk_pct": round(random.uniform(0, 2), 1),
                    "container_restarts": 0,
                }
            )
        return {
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "daily": daily,
        }

    def get_trigger_stats(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "active_triggers": random.randint(5, 25),
                    "completed_triggers": random.randint(50, 200),
                    "failed_triggers": random.randint(0, 3),
                    "deferred_tasks": random.choice([0, 0, 0, 0, 1]),
                    "running_triggers": random.randint(0, 2),
                    "blocking_triggers": random.choice([0, 0, 0, 1]),
                }
            )
        return {"daily": daily}


class RealTriggererProvider(BaseTriggererProvider):
    """GCP Composer Triggerer API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Triggerer provider not yet implemented")

    def get_trigger_stats(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Triggerer provider not yet implemented")
