"""Composer GCS Infrastructure Provider - DAG/Backup 버킷 용량."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseGcsInfraProvider(ABC):
    @abstractmethod
    def get_dag_bucket_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_backup_bucket_usage(self, days: int = 31) -> dict[str, Any]: ...


class MockGcsInfraProvider(BaseGcsInfraProvider):
    """Mock 데이터 기반 GCS Infra Provider."""

    def get_dag_bucket_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        base_size = 2.5
        for d in dates:
            base_size += random.uniform(-0.01, 0.03)
            daily.append(
                {
                    "date": d,
                    "size_gb": round(base_size, 2),
                    "object_count": random.randint(1200, 1400),
                    "dag_file_count": random.randint(480, 520),
                }
            )
        return {
            "bucket_name": "adw-composer-dags",
            "daily": daily,
        }

    def get_backup_bucket_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        base_size = 15.0
        for d in dates:
            base_size += random.uniform(0.05, 0.15)
            daily.append(
                {
                    "date": d,
                    "size_gb": round(base_size, 2),
                    "backup_count": random.randint(28, 35),
                    "last_backup_hour": 4,
                }
            )
        return {
            "bucket_name": "adw-composer-backups",
            "daily": daily,
        }


class RealGcsInfraProvider(BaseGcsInfraProvider):
    """GCP GCS API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_dag_bucket_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real GCS Infra provider not yet implemented")

    def get_backup_bucket_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real GCS Infra provider not yet implemented")
