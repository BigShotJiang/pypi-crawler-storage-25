"""Composer Worker Pool Provider - Worker 오토스케일링, 리소스, 태스크 실행."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseWorkerProvider(ABC):
    @abstractmethod
    def get_pool_status(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_task_execution(self, days: int = 31) -> dict[str, Any]: ...


class MockWorkerProvider(BaseWorkerProvider):
    """Mock 데이터 기반 Worker Provider."""

    MIN_WORKERS = 2
    MAX_WORKERS = 32
    VCPU = 4
    MEMORY_GB = 16
    CONCURRENCY = 4

    def get_pool_status(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            active = random.randint(2, 8) if is_weekend else random.randint(4, 20)
            daily.append(
                {
                    "date": d,
                    "active_workers": active,
                    "pending_workers": random.randint(0, 2),
                    "scale_up_events": 0 if is_weekend else random.randint(0, 3),
                    "scale_down_events": 0 if is_weekend else random.randint(0, 2),
                }
            )
        # K8s Executor Pod 메트릭 (KubernetesExecutor 사용 DAG)
        k8s_daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            running = random.randint(0, 3) if is_weekend else random.randint(2, 12)
            completed = random.randint(5, 20) if is_weekend else random.randint(30, 80)
            k8s_daily.append(
                {
                    "date": d,
                    "running_pods": running,
                    "pending_pods": random.randint(0, 2),
                    "failed_pods": 0 if random.random() > 0.1 else random.randint(1, 3),
                    "completed_pods": completed,
                    "cpu_requests_mc": running * 500,
                    "memory_requests_mb": running * 1024,
                }
            )

        return {
            "min_workers": self.MIN_WORKERS,
            "max_workers": self.MAX_WORKERS,
            "daily": daily,
            "k8s_executor": {
                "namespace": "composer-workers",
                "daily": k8s_daily,
            },
        }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_cpu = 20 if is_weekend else 45
            base_mem = 30 if is_weekend else 55
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(base_cpu + random.uniform(-10, 15), 1),
                    "memory_pct": round(base_mem + random.uniform(-10, 15), 1),
                    "disk_pct": round(random.uniform(1, 8), 1),
                    "container_restarts": 0,
                    "pod_evictions": 0,
                }
            )
        return {
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "concurrency": self.CONCURRENCY,
            "daily": daily,
        }

    def get_task_execution(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            concurrent = random.randint(5, 15) if is_weekend else random.randint(30, 60)
            daily.append(
                {
                    "date": d,
                    "concurrent_tasks": concurrent,
                    "queued_tasks": random.randint(0, 10),
                    "avg_task_duration_sec": round(random.uniform(30, 120), 1),
                }
            )
        return {"daily": daily}


class RealWorkerProvider(BaseWorkerProvider):
    """GCP Composer Worker API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_pool_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Worker provider not yet implemented")

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Worker provider not yet implemented")

    def get_task_execution(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Worker provider not yet implemented")
