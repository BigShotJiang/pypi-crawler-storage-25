"""Composer DAG Processor Provider - DAG 파싱 리소스 및 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseDagProcessorProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]: ...


class MockDagProcessorProvider(BaseDagProcessorProvider):
    """Mock 데이터 기반 DAG Processor Provider."""

    VCPU = 2
    MEMORY_GB = 7.5

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_cpu = 15 if is_weekend else 22
            base_mem = 5 if is_weekend else 7
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(base_cpu + random.uniform(-5, 10), 1),
                    "memory_pct": round(base_mem + random.uniform(-2, 4), 1),
                    "disk_pct": round(random.uniform(0, 3), 1),
                }
            )
        return {
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "daily": daily,
        }

    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "parse_time_sec": round(random.uniform(0.5, 1.5), 2),
                    "total_dags": random.randint(480, 520),
                    "parse_errors": random.randint(0, 3),
                }
            )
        return {"daily": daily}


class RealDagProcessorProvider(BaseDagProcessorProvider):
    """GCP Composer DAG Processor API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real DAG Processor provider not yet implemented")

    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real DAG Processor provider not yet implemented")
