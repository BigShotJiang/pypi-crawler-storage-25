"""Composer WebServer Provider - WebServer Pod 리소스 및 요청 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseWebServerProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_request_metrics(self, days: int = 31) -> dict[str, Any]: ...


class MockWebServerProvider(BaseWebServerProvider):
    """Mock 데이터 기반 WebServer Provider."""

    VCPU = 2
    MEMORY_GB = 7.5

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(random.uniform(8, 22), 1),
                    "memory_pct": round(random.uniform(25, 38), 1),
                    "disk_pct": round(random.uniform(0, 3), 1),
                    "health_status": "healthy",
                }
            )
        return {
            "vcpu": self.VCPU,
            "memory_gb": self.MEMORY_GB,
            "daily": daily,
        }

    def get_request_metrics(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_requests = 200 if is_weekend else 800
            daily.append(
                {
                    "date": d,
                    "total_requests": base_requests + random.randint(-100, 200),
                    "avg_response_ms": round(random.uniform(80, 250), 1),
                    "error_count": random.randint(0, 5),
                }
            )
        return {"daily": daily}


class RealWebServerProvider(BaseWebServerProvider):
    """GCP Composer WebServer API 연동 Provider."""

    def __init__(self, project_id: str | None = None):
        self.project_id = project_id

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real WebServer provider not yet implemented")

    def get_request_metrics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real WebServer provider not yet implemented")
