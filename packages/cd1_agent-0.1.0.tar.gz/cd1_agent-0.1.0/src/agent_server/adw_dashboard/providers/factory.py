"""ADW Provider Factory - Provider 번들 생성."""

import logging
import os
from dataclasses import dataclass
from typing import Any

from .bastion_provider import BaseBastionProvider, MockBastionProvider, RealBastionProvider
from .bigquery_provider import BaseBigQueryProvider, RealBigQueryProvider
from .cloudsql_provider import BaseCloudSqlProvider, MockCloudSqlProvider, RealCloudSqlProvider
from .composer_provider import BaseComposerProvider, MockComposerProvider, RealComposerProvider
from .dag_processor_provider import (
    BaseDagProcessorProvider,
    MockDagProcessorProvider,
    RealDagProcessorProvider,
)
from .gcs_infra_provider import BaseGcsInfraProvider, MockGcsInfraProvider, RealGcsInfraProvider
from .gcs_provider import BaseGcsProvider, MockGcsProvider, RealGcsProvider
from .scheduler_provider import BaseSchedulerProvider, MockSchedulerProvider, RealSchedulerProvider
from .triggerer_provider import BaseTriggererProvider, MockTriggererProvider, RealTriggererProvider
from .webserver_provider import BaseWebServerProvider, MockWebServerProvider, RealWebServerProvider
from .worker_provider import BaseWorkerProvider, MockWorkerProvider, RealWorkerProvider

logger = logging.getLogger(__name__)


@dataclass
class AdwProviderBundle:
    """모든 ADW Provider를 묶는 번들."""

    bigquery: BaseBigQueryProvider
    composer: BaseComposerProvider
    gcs: BaseGcsProvider
    bastion: BaseBastionProvider
    # Composer 인프라 providers
    scheduler: BaseSchedulerProvider
    dag_processor: BaseDagProcessorProvider
    worker: BaseWorkerProvider
    triggerer: BaseTriggererProvider
    webserver: BaseWebServerProvider
    cloudsql: BaseCloudSqlProvider
    gcs_infra: BaseGcsInfraProvider


def create_adw_providers(
    provider_type: str | None = None,
    **kwargs: Any,
) -> AdwProviderBundle:
    """Factory function to create ADW provider bundle.

    BigQuery는 항상 Real provider + Cache 래핑.
    - GCP 인증 실패 시 Real provider는 빈 데이터 반환
    - 캐시에 pre-seeded 데이터가 있으면 캐시에서 서빙 (로컬 개발)
    - 캐시 미스 + GCP 인증 OK → BigQuery API 호출 후 캐시 저장

    나머지 provider는 ADW_PROVIDER 환경변수로 mock/real 선택.

    Args:
        provider_type: Provider type for non-BQ providers ("mock" or "real").
        **kwargs: Provider-specific settings (project_id, environment_name, etc.)
    """
    from src.agent_server.bdp_common.clients.cached_bigquery import CachedBigQueryProvider
    from src.agent_server.bdp_common.stores.bigquery_cache import BqCacheStore

    provider_type = provider_type or os.getenv("ADW_PROVIDER", "mock")
    logger.info(f"Creating ADW providers: type={provider_type}")

    project_id = kwargs.get("project_id")
    bq_location = kwargs.get("bq_location")

    # BigQuery: 항상 Real + Cache
    real_bq = RealBigQueryProvider(project_id=project_id, location=bq_location)
    bq_cache = BqCacheStore()
    cached_bq = CachedBigQueryProvider(real=real_bq, cache=bq_cache)

    if provider_type == "real":
        return AdwProviderBundle(
            bigquery=cached_bq,
            composer=RealComposerProvider(
                environment_name=kwargs.get("environment_name"),
                project_id=project_id,
            ),
            gcs=RealGcsProvider(project_id=project_id),
            bastion=RealBastionProvider(bastion_host=kwargs.get("bastion_host")),
            scheduler=RealSchedulerProvider(project_id=project_id),
            dag_processor=RealDagProcessorProvider(project_id=project_id),
            worker=RealWorkerProvider(project_id=project_id),
            triggerer=RealTriggererProvider(project_id=project_id),
            webserver=RealWebServerProvider(project_id=project_id),
            cloudsql=RealCloudSqlProvider(project_id=project_id),
            gcs_infra=RealGcsInfraProvider(project_id=project_id),
        )
    else:
        return AdwProviderBundle(
            bigquery=cached_bq,
            composer=MockComposerProvider(),
            gcs=MockGcsProvider(),
            bastion=MockBastionProvider(),
            scheduler=MockSchedulerProvider(),
            dag_processor=MockDagProcessorProvider(),
            worker=MockWorkerProvider(),
            triggerer=MockTriggererProvider(),
            webserver=MockWebServerProvider(),
            cloudsql=MockCloudSqlProvider(),
            gcs_infra=MockGcsInfraProvider(),
        )
