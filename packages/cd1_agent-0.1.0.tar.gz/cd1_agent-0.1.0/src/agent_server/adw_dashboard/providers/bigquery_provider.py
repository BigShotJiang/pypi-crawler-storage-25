"""BigQuery Provider - 슬롯/쿼리/잡/저장소/비용/예약 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseBigQueryProvider(ABC):
    @abstractmethod
    def get_slot_utilization(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_query_performance(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_job_history(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_dataset_storage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_cost_analysis(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_reservation_utilization(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_slot_timeline(self, hours: int = 24) -> dict[str, Any]: ...


class MockBigQueryProvider(BaseBigQueryProvider):
    """Mock 데이터 기반 BigQuery Provider (900슬롯 기준)."""

    TOTAL_SLOTS = 900

    def get_slot_utilization(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            if is_weekend:
                current = random.randint(80, 250)
                peak = random.randint(current, min(current + 200, 600))
            else:
                current = random.randint(350, 700)
                peak = random.randint(current, min(current + 250, 900))
            avg = int((current + peak) * 0.45)
            daily.append(
                {
                    "date": d,
                    "current_slots": current,
                    "peak_slots": peak,
                    "avg_slots": avg,
                }
            )
        return {"total_slots": self.TOTAL_SLOTS, "daily": daily}

    def get_query_performance(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            base_concurrent = 5 if is_weekend else random.randint(15, 40)
            daily.append(
                {
                    "date": d,
                    "concurrent_queries": base_concurrent + random.randint(-3, 5),
                    "avg_execution_sec": round(random.uniform(8.0, 45.0), 1),
                    "bytes_scanned_tb": round(
                        random.uniform(0.5, 8.0) if not is_weekend else random.uniform(0.1, 2.0), 2
                    ),
                }
            )
        return {"daily": daily}

    def get_job_history(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            completed = random.randint(30, 80) if is_weekend else random.randint(200, 500)
            failed = random.randint(0, 3) if is_weekend else random.randint(2, 15)
            running = random.randint(0, 2) if is_weekend else random.randint(3, 20)
            daily.append(
                {
                    "date": d,
                    "completed": completed,
                    "failed": failed,
                    "running": running,
                }
            )
        return {"daily": daily}

    def get_dataset_storage(self, days: int = 31) -> dict[str, Any]:
        datasets = {}
        for name, base_tb, table_count in [
            ("raw_data", 12.5, 245),
            ("analytics", 8.3, 182),
            ("ml_features", 5.7, 98),
            ("reporting", 3.2, 156),
            ("staging", 1.8, 67),
        ]:
            datasets[name] = {
                "size_tb": round(base_tb + random.uniform(-0.5, 0.5), 2),
                "table_count": table_count + random.randint(-5, 10),
            }
        return {"datasets": datasets}

    def get_cost_analysis(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            # 고정 슬롯 비용 (월 ~$20k → 일 ~$667)
            fixed_cost = round(667.0 + random.uniform(-10, 10), 2)
            # 온디맨드 초과 비용
            ondemand_cost = round(
                random.uniform(0, 50) if is_weekend else random.uniform(50, 300), 2
            )
            daily.append(
                {
                    "date": d,
                    "fixed_slot_cost": fixed_cost,
                    "ondemand_cost": ondemand_cost,
                }
            )
        return {"daily": daily}

    def get_slot_timeline(self, hours: int = 24) -> dict[str, Any]:
        now = datetime.now()
        start = now - timedelta(hours=hours)

        # 현실적인 Job 템플릿 (이름, 타입, 슬롯범위, 지속시간범위(분))
        templates = [
            ("etl_raw_ingest", "LOAD", (150, 350), (30, 120)),
            ("etl_transform", "QUERY", (100, 280), (20, 90)),
            ("ml_training_pipeline", "QUERY", (200, 450), (60, 180)),
            ("ml_feature_build", "QUERY", (80, 200), (15, 60)),
            ("daily_report_gen", "QUERY", (50, 150), (10, 40)),
            ("weekly_aggregation", "QUERY", (100, 300), (30, 90)),
            ("data_export_gcs", "EXTRACT", (30, 100), (10, 30)),
            ("staging_copy", "COPY", (20, 80), (5, 20)),
            ("adhoc_analyst_query", "QUERY", (30, 120), (5, 30)),
            ("dashboard_refresh", "QUERY", (40, 100), (5, 15)),
            ("log_archive_load", "LOAD", (60, 200), (20, 60)),
            ("realtime_sync", "LOAD", (50, 150), (10, 45)),
        ]

        jobs = []
        num_jobs = random.randint(18, 28)
        for i in range(num_jobs):
            tmpl = random.choice(templates)
            name, job_type, (slot_min, slot_max), (dur_min, dur_max) = tmpl

            # 랜덤 시작 시간 (hours 범위 내)
            offset_min = random.randint(0, hours * 60 - dur_min)
            job_start = start + timedelta(minutes=offset_min)
            duration = random.randint(dur_min, dur_max)
            job_end = job_start + timedelta(minutes=duration)

            # 아직 진행중인 Job
            if job_end > now:
                state = "RUNNING"
                job_end = now
            else:
                state = "DONE"

            jobs.append(
                {
                    "job_id": f"{name}_{i:03d}",
                    "project": random.choice(
                        ["analytics-prod", "data-eng", "ml-platform", "bi-reports"]
                    ),
                    "start_time": job_start.strftime("%Y-%m-%dT%H:%M:%S+09:00"),
                    "end_time": job_end.strftime("%Y-%m-%dT%H:%M:%S+09:00"),
                    "slot_usage": random.randint(slot_min, slot_max),
                    "state": state,
                    "job_type": job_type,
                }
            )

        # start_time 순 정렬
        jobs.sort(key=lambda j: j["start_time"])
        return {"total_slots": self.TOTAL_SLOTS, "hours": hours, "jobs": jobs}

    def get_reservation_utilization(self, days: int = 31) -> dict[str, Any]:
        teams: dict[str, list] = {}
        dates = _daily_dates(days)
        for team_name, reserved_slots in [
            ("팀1", 300),
            ("팀2", 250),
            ("팀3", 200),
            ("팀4", 150),
        ]:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                usage_pct = random.uniform(10, 40) if is_weekend else random.uniform(50, 95)
                used = int(reserved_slots * usage_pct / 100)
                data.append(
                    {
                        "date": d,
                        "reserved_slots": reserved_slots,
                        "used_slots": used,
                        "utilization_pct": round(usage_pct, 1),
                    }
                )
            teams[team_name] = data
        return {"teams": teams}


class RealBigQueryProvider(BaseBigQueryProvider):
    """GCP BigQuery INFORMATION_SCHEMA 기반 Real Provider."""

    TOTAL_SLOTS = 900  # 예약 슬롯 (설정으로 분리 가능)

    def __init__(self, project_id: str | None = None, location: str | None = None):
        import logging
        import os

        self.logger = logging.getLogger(__name__)
        self.project_id = project_id or os.getenv("GCP_PROJECT_ID")
        self.location = location or os.getenv("BQ_LOCATION", "US")
        self._client = None

        try:
            from google.cloud import bigquery

            self._client = bigquery.Client(project=self.project_id)
            self.logger.info(
                f"BigQuery client initialized: project={self.project_id}, location={self.location}"
            )
        except Exception as e:
            self.logger.error(f"BigQuery client init failed: {e}")

    def _query(self, sql: str) -> list[dict]:
        """BQ 쿼리 실행 후 dict 리스트 반환."""
        if not self._client:
            return []
        rows = self._client.query(sql).result()
        return [dict(row) for row in rows]

    @property
    def _region_prefix(self) -> str:
        return f"`region-{self.location}`"

    def get_slot_utilization(self, days: int = 31) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              DATE(creation_time) AS date,
              CAST(SUM(total_slot_ms) / (24*3600*1000) AS INT64) AS avg_slots,
              CAST(MAX(total_slot_ms / GREATEST(TIMESTAMP_DIFF(end_time, start_time, MILLISECOND), 1)) AS INT64) AS peak_slots,
              CAST(SUM(total_slot_ms) / SUM(GREATEST(TIMESTAMP_DIFF(end_time, start_time, MILLISECOND), 1)) AS INT64) AS current_slots
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              AND state = 'DONE'
              AND job_type IS NOT NULL
            GROUP BY date
            ORDER BY date
            """
            rows = self._query(sql)
            daily = [
                {
                    "date": str(r["date"]),
                    "current_slots": r.get("current_slots", 0),
                    "peak_slots": r.get("peak_slots", 0),
                    "avg_slots": r.get("avg_slots", 0),
                }
                for r in rows
            ]
            return {"total_slots": self.TOTAL_SLOTS, "daily": daily}
        except Exception as e:
            self.logger.error(f"get_slot_utilization failed: {e}")
            return {"total_slots": self.TOTAL_SLOTS, "daily": []}

    def get_query_performance(self, days: int = 31) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              DATE(creation_time) AS date,
              COUNT(*) AS concurrent_queries,
              ROUND(AVG(TIMESTAMP_DIFF(end_time, start_time, SECOND)), 1) AS avg_execution_sec,
              ROUND(SUM(total_bytes_processed) / POW(1024, 4), 2) AS bytes_scanned_tb
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              AND job_type = 'QUERY'
              AND state = 'DONE'
            GROUP BY date
            ORDER BY date
            """
            rows = self._query(sql)
            daily = [
                {
                    "date": str(r["date"]),
                    "concurrent_queries": r.get("concurrent_queries", 0),
                    "avg_execution_sec": float(r.get("avg_execution_sec", 0)),
                    "bytes_scanned_tb": float(r.get("bytes_scanned_tb", 0)),
                }
                for r in rows
            ]
            return {"daily": daily}
        except Exception as e:
            self.logger.error(f"get_query_performance failed: {e}")
            return {"daily": []}

    def get_job_history(self, days: int = 31) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              DATE(creation_time) AS date,
              COUNTIF(state = 'DONE' AND error_result IS NULL) AS completed,
              COUNTIF(state = 'DONE' AND error_result IS NOT NULL) AS failed,
              COUNTIF(state = 'RUNNING') AS running
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              AND job_type IS NOT NULL
            GROUP BY date
            ORDER BY date
            """
            rows = self._query(sql)
            daily = [
                {
                    "date": str(r["date"]),
                    "completed": r.get("completed", 0),
                    "failed": r.get("failed", 0),
                    "running": r.get("running", 0),
                }
                for r in rows
            ]
            return {"daily": daily}
        except Exception as e:
            self.logger.error(f"get_job_history failed: {e}")
            return {"daily": []}

    def get_dataset_storage(self, days: int = 31) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              table_schema AS dataset_name,
              ROUND(SUM(total_logical_bytes) / POW(1024, 4), 2) AS size_tb,
              COUNT(DISTINCT table_name) AS table_count
            FROM {self._region_prefix}.INFORMATION_SCHEMA.TABLE_STORAGE
            GROUP BY dataset_name
            ORDER BY size_tb DESC
            LIMIT 20
            """
            rows = self._query(sql)
            datasets = {}
            for r in rows:
                datasets[r["dataset_name"]] = {
                    "size_tb": float(r.get("size_tb", 0)),
                    "table_count": r.get("table_count", 0),
                }
            return {"datasets": datasets}
        except Exception as e:
            self.logger.error(f"get_dataset_storage failed: {e}")
            return {"datasets": {}}

    def get_cost_analysis(self, days: int = 31) -> dict[str, Any]:
        try:
            # 슬롯 비용: slot_ms → 시간 → $0.04/slot-hour (enterprise 기준)
            sql = f"""
            SELECT
              DATE(creation_time) AS date,
              ROUND(SUM(total_slot_ms) / 3600000.0 * 0.04, 2) AS fixed_slot_cost,
              ROUND(SUM(CASE WHEN reservation_id IS NULL THEN total_bytes_billed ELSE 0 END) / POW(1024, 4) * 6.25, 2) AS ondemand_cost
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              AND state = 'DONE'
              AND job_type IS NOT NULL
            GROUP BY date
            ORDER BY date
            """
            rows = self._query(sql)
            daily = [
                {
                    "date": str(r["date"]),
                    "fixed_slot_cost": float(r.get("fixed_slot_cost", 0)),
                    "ondemand_cost": float(r.get("ondemand_cost", 0)),
                }
                for r in rows
            ]
            return {"daily": daily}
        except Exception as e:
            self.logger.error(f"get_cost_analysis failed: {e}")
            return {"daily": []}

    def get_reservation_utilization(self, days: int = 31) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              COALESCE(reservation_id, 'default') AS team,
              DATE(creation_time) AS date,
              CAST(SUM(total_slot_ms) / (24*3600*1000) AS INT64) AS used_slots
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              AND state = 'DONE'
            GROUP BY team, date
            ORDER BY team, date
            """
            rows = self._query(sql)
            teams: dict[str, list] = {}
            for r in rows:
                team = r.get("team", "default")
                if team not in teams:
                    teams[team] = []
                used = r.get("used_slots", 0)
                reserved = self.TOTAL_SLOTS // max(len(set(rr.get("team") for rr in rows)), 1)
                teams[team].append(
                    {
                        "date": str(r["date"]),
                        "reserved_slots": reserved,
                        "used_slots": used,
                        "utilization_pct": round(used / max(reserved, 1) * 100, 1),
                    }
                )
            return {"teams": teams}
        except Exception as e:
            self.logger.error(f"get_reservation_utilization failed: {e}")
            return {"teams": {}}

    def get_slot_timeline(self, hours: int = 24) -> dict[str, Any]:
        try:
            sql = f"""
            SELECT
              job_id,
              project_id,
              creation_time,
              COALESCE(end_time, CURRENT_TIMESTAMP()) AS end_time,
              CAST(total_slot_ms / GREATEST(TIMESTAMP_DIFF(COALESCE(end_time, CURRENT_TIMESTAMP()), creation_time, MILLISECOND), 1) AS INT64) AS slot_usage,
              state,
              job_type
            FROM {self._region_prefix}.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {hours} HOUR)
              AND job_type IS NOT NULL
              AND total_slot_ms > 0
            ORDER BY creation_time
            LIMIT 200
            """
            rows = self._query(sql)
            jobs = []
            for r in rows:
                state_raw = r.get("state", "DONE")
                state = "RUNNING" if state_raw == "RUNNING" else "DONE"
                ct = r.get("creation_time")
                et = r.get("end_time")
                jobs.append(
                    {
                        "job_id": r.get("job_id", ""),
                        "project": r.get("project_id", ""),
                        "start_time": ct.isoformat() if hasattr(ct, "isoformat") else str(ct),
                        "end_time": et.isoformat() if hasattr(et, "isoformat") else str(et),
                        "slot_usage": max(int(r.get("slot_usage", 0)), 1),
                        "state": state,
                        "job_type": r.get("job_type", "QUERY"),
                    }
                )
            return {"total_slots": self.TOTAL_SLOTS, "hours": hours, "jobs": jobs}
        except Exception as e:
            self.logger.error(f"get_slot_timeline failed: {e}")
            return {"total_slots": self.TOTAL_SLOTS, "hours": hours, "jobs": []}
