"""Bastion Host Provider - 접속 상태, 세션, 리소스 사용량."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseBastionProvider(ABC):
    @abstractmethod
    def get_connection_status(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_session_metrics(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_resource_utilization(self, days: int = 31) -> dict[str, Any]: ...


class MockBastionProvider(BaseBastionProvider):
    """Mock 데이터 기반 Bastion Host Provider."""

    def get_connection_status(self, days: int = 31) -> dict[str, Any]:
        return {
            "host": "adw-bastion-01",
            "status": random.choice(["online", "online", "online", "degraded"]),
            "uptime_hours": random.randint(720, 2160),
            "active_sessions": random.randint(2, 15),
            "max_sessions": 50,
        }

    def get_session_metrics(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            sessions = random.randint(1, 5) if is_weekend else random.randint(8, 30)
            daily.append(
                {
                    "date": d,
                    "total_sessions": sessions,
                    "unique_users": max(1, sessions - random.randint(0, 5)),
                    "avg_duration_min": round(random.uniform(15, 120), 1),
                }
            )
        return {"daily": daily}

    def get_resource_utilization(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            cpu_base = 10 if is_weekend else random.randint(20, 50)
            mem_base = 25 if is_weekend else random.randint(30, 60)
            daily.append(
                {
                    "date": d,
                    "cpu_pct": round(cpu_base + random.uniform(-5, 10), 1),
                    "memory_pct": round(mem_base + random.uniform(-5, 10), 1),
                    "disk_pct": round(random.uniform(20, 45), 1),
                    "network_in_mb": round(
                        random.uniform(50, 500) if not is_weekend else random.uniform(10, 100), 1
                    ),
                    "network_out_mb": round(
                        random.uniform(100, 800) if not is_weekend else random.uniform(20, 150), 1
                    ),
                }
            )
        return {"daily": daily}


class RealBastionProvider(BaseBastionProvider):
    """GCP Bastion Host 연동 Provider."""

    def __init__(self, bastion_host: str | None = None):
        self.bastion_host = bastion_host

    def get_connection_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Bastion provider not yet implemented")

    def get_session_metrics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Bastion provider not yet implemented")

    def get_resource_utilization(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Bastion provider not yet implemented")
