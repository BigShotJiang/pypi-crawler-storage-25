"""ADW Dashboard Report Data Models."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AdwInfraReportData:
    """ADW 인프라 현황 리포트 데이터 (15개 메트릭)."""

    # BigQuery (6개)
    bq_slot_utilization: dict[str, Any] = field(default_factory=dict)
    bq_query_performance: dict[str, Any] = field(default_factory=dict)
    bq_job_history: dict[str, Any] = field(default_factory=dict)
    bq_dataset_storage: dict[str, Any] = field(default_factory=dict)
    bq_cost_analysis: dict[str, Any] = field(default_factory=dict)
    bq_reservation_utilization: dict[str, Any] = field(default_factory=dict)

    # Composer (3개)
    composer_dag_stats: dict[str, Any] = field(default_factory=dict)
    composer_environment: dict[str, Any] = field(default_factory=dict)
    composer_task_metrics: dict[str, Any] = field(default_factory=dict)

    # GCS (3개)
    gcs_bucket_storage: dict[str, Any] = field(default_factory=dict)
    gcs_access_patterns: dict[str, Any] = field(default_factory=dict)
    gcs_storage_classes: dict[str, Any] = field(default_factory=dict)

    # Bastion (3개)
    bastion_status: dict[str, Any] = field(default_factory=dict)
    bastion_sessions: dict[str, Any] = field(default_factory=dict)
    bastion_resources: dict[str, Any] = field(default_factory=dict)


@dataclass
class AdwServiceReportData:
    """ADW 서비스 현황 리포트 데이터 (6개 메트릭)."""

    # BigQuery (3개 - 슬롯, 비용, 예약)
    bq_slot_utilization: dict[str, Any] = field(default_factory=dict)
    bq_cost_analysis: dict[str, Any] = field(default_factory=dict)
    bq_reservation_utilization: dict[str, Any] = field(default_factory=dict)

    # Composer (1개 - DAG)
    composer_dag_stats: dict[str, Any] = field(default_factory=dict)

    # GCS (1개 - 접근 패턴)
    gcs_access_patterns: dict[str, Any] = field(default_factory=dict)

    # Bastion (1개 - 세션)
    bastion_sessions: dict[str, Any] = field(default_factory=dict)
