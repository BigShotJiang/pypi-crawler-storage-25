"""
ADW Service Report Generator.

ADW 서비스 메트릭(BigQuery 슬롯/비용/예약, Composer DAG, GCS 접근, Bastion 세션)을
SVG 라인 차트로 렌더링하는 HTML 리포트 생성기.
"""

import logging
from html import escape as html_escape
from typing import Any

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.charts import (
    CHART_COLORS,
    _svg_bar_line_chart,
    _svg_line_chart,
    _svg_simple_bar_chart,
)
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

from .report_data import AdwServiceReportData

logger = logging.getLogger(__name__)


# 섹션 정의
_SECTIONS = [
    {
        "key": "bq_slot_utilization",
        "category": "bigquery",
        "icon": "analytics",
        "title": "BigQuery 슬롯 사용량",
        "type": "slot",
    },
    {
        "key": "bq_cost_analysis",
        "category": "bigquery",
        "icon": "payments",
        "title": "BigQuery 비용 분석",
        "type": "cost",
    },
    {
        "key": "bq_reservation_utilization",
        "category": "bigquery",
        "icon": "group",
        "title": "BigQuery 팀별 예약 사용률",
        "type": "reservation",
    },
    {
        "key": "composer_dag_stats",
        "category": "composer",
        "icon": "air",
        "title": "Composer DAG 실행 통계",
        "type": "dag",
    },
    {
        "key": "gcs_access_patterns",
        "category": "gcs",
        "icon": "cloud",
        "title": "GCS 버킷별 접근 패턴",
        "type": "access",
    },
    {
        "key": "bastion_sessions",
        "category": "bastion",
        "icon": "security",
        "title": "Bastion 일별 세션",
        "type": "session",
    },
]

_CATEGORY_LABELS: dict[str, str] = {
    "bigquery": "BigQuery",
    "composer": "Composer",
    "gcs": "GCS",
    "bastion": "Bastion",
}


class AdwServiceReportGenerator(HTMLReportBase):
    """ADW 서비스 현황 리포트 생성기."""

    def __init__(self, category: str | None = None):
        styles = ReportStyles(primary_color=MD3_COLORS["tertiary"])
        cat_label = _CATEGORY_LABELS.get(category, category) if category else None
        title = "ADW 서비스 현황 리포트"
        if cat_label:
            title = f"{title} - {cat_label}"
        super().__init__(title=title, styles=styles)
        self._category = category

    def generate_content(self, data: AdwServiceReportData) -> str:
        sections: list[str] = []

        for sec in _SECTIONS:
            if self._category and sec["category"] != self._category:
                continue
            chart_html = self._build_section_chart(data, sec)
            if chart_html:
                sections.append(self._build_card(sec["icon"], sec["title"], chart_html))

        return "\n".join(sections)

    def _build_section_chart(
        self,
        data: AdwServiceReportData,
        sec: dict[str, Any],
    ) -> str:
        raw = getattr(data, sec["key"], {})
        if not raw:
            return ""

        sec_type = sec["type"]

        # ── LineChart + ReferenceLine (프론트엔드: LineChart)
        if sec_type == "slot":
            daily = raw.get("daily", [])
            if not daily:
                return ""
            total_slots = raw.get("total_slots", 900)
            series: dict[str, list[tuple[str, float]]] = {
                "현재": [(p["date"], p.get("current_slots", 0)) for p in daily],
                "피크": [(p["date"], p.get("peak_slots", 0)) for p in daily],
                "평균": [(p["date"], p.get("avg_slots", 0)) for p in daily],
            }
            return _svg_line_chart(
                series,
                ["#2563eb", "#dc2626", "#16a34a"],
                title="슬롯 사용률 추이",
                subtitle=f"총 {total_slots}슬롯 대비 현재/피크/평균",
                y_suffix="슬롯",
                reference_lines=[
                    {"value": total_slots, "label": f"예약 {total_slots}", "color": "#ef4444"},
                ],
            )

        # ── AreaChart (프론트엔드: AreaChart with fillOpacity=0.3)
        if sec_type == "cost":
            daily = raw.get("daily", [])
            if not daily:
                return ""
            series = {
                "고정 슬롯": [(p["date"], p.get("fixed_slot_cost", 0)) for p in daily],
                "온디맨드": [(p["date"], p.get("ondemand_cost", 0)) for p in daily],
            }
            return _svg_line_chart(
                series,
                ["#2563eb", "#dc2626"],
                title="비용 추이",
                subtitle="고정 슬롯 vs 온디맨드 ($)",
                y_suffix="$",
                fill_opacity=0.3,
            )

        # ── LineChart (프론트엔드: LineChart)
        if sec_type == "reservation":
            teams = raw.get("teams", {})
            if not teams:
                return ""
            series = {}
            for team, points in teams.items():
                if isinstance(points, list) and points:
                    series[team] = [(p["date"], p.get("utilization_pct", 0)) for p in points]
            if not series:
                return ""
            return _svg_line_chart(
                series,
                CHART_COLORS,
                title="팀별 예약 슬롯 사용률",
                subtitle="팀별 예약 슬롯 사용률 (%)",
                y_suffix="%",
                y_domain=(0, 100),
            )

        # ── BarChart (프론트엔드: BarChart with DAG별 성공률 막대)
        if sec_type == "dag":
            dags = raw.get("dags", {})
            if not dags:
                return ""
            # 최신 날짜 기준 DAG별 성공률 계산 (프론트엔드와 동일)
            dag_rates: list[tuple[str, float]] = []
            for dag_name, points in dags.items():
                if not isinstance(points, list) or not points:
                    continue
                latest = points[-1]
                s = latest.get("success", 0)
                f = latest.get("failed", 0)
                total = s + f
                rate = round((s / total) * 100) if total > 0 else 0
                dag_rates.append((dag_name, rate))
            if not dag_rates:
                return ""
            return _svg_simple_bar_chart(
                dag_rates,
                CHART_COLORS,
                title="DAG별 성공률",
                subtitle="DAG별 성공/실패율",
                y_suffix="%",
                y_domain=(0, 100),
            )

        # ── LineChart (프론트엔드: LineChart)
        if sec_type == "access":
            buckets = raw.get("buckets", {})
            if not buckets:
                return ""
            # 상위 3개 버킷만 (프론트엔드와 동일)
            bucket_names = list(buckets.keys())[:3]
            series = {}
            for name in bucket_names:
                points = buckets[name]
                if isinstance(points, list) and points:
                    series[f"{name} (R)"] = [(p["date"], p.get("read_ops", 0)) for p in points]
            if not series:
                return ""
            return _svg_line_chart(
                series,
                CHART_COLORS,
                title="버킷별 접근 패턴 (상위 3개)",
                subtitle="버킷별 읽기 ops",
                y_suffix="건",
                y_integer=True,
            )

        # ── ComposedChart: Bar + Line (프론트엔드: ComposedChart)
        if sec_type == "session":
            daily = raw.get("daily", [])
            if not daily:
                return ""
            bar_data = {
                "세션": [(p["date"], p.get("total_sessions", 0)) for p in daily],
            }
            line_data = {
                "사용자": [(p["date"], p.get("unique_users", 0)) for p in daily],
            }
            return _svg_bar_line_chart(
                bar_data,
                line_data,
                bar_colors=["#2563eb"],
                line_colors=["#dc2626"],
                title="일별 세션 추이",
                subtitle="Bastion 세션 수 / 사용자 수",
                y_suffix="건",
                y_integer=True,
            )

        return ""

    def _build_card(self, icon_name: str, title: str, chart_content: str) -> str:
        icon_html = self._icon(icon_name, size="sm", inline=True)
        return f"""
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:8px;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                {icon_html}
                <span style="font-size:14px;font-weight:600;">{html_escape(title)}</span>
            </div>
            <div style="padding:16px 20px;">
                {chart_content}
            </div>
        </div>
        """
