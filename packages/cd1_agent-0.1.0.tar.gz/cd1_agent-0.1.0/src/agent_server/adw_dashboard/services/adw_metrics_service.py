"""ADW Metrics Service - ADW 서비스 시계열 메트릭 조회."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from src.agent_server.adw_dashboard.providers import AdwProviderBundle

logger = logging.getLogger(__name__)


class AdwMetricsService:
    """ADW 서비스 시계열 메트릭을 조회하는 서비스.

    Provider 번들을 통해 mock/real 데이터 소스를 전환한다.
    """

    def __init__(self, providers: AdwProviderBundle):
        self.providers = providers

    # ── BigQuery ─────────────────────────────────────

    def get_bq_slot_utilization(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_slot_utilization(days)

    def get_bq_query_performance(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_query_performance(days)

    def get_bq_job_history(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_job_history(days)

    def get_bq_dataset_storage(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_dataset_storage(days)

    def get_bq_cost_analysis(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_cost_analysis(days)

    def get_bq_slot_timeline(self, hours: int = 24) -> dict[str, Any]:
        return self.providers.bigquery.get_slot_timeline(hours)

    def get_bq_reservation_utilization(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bigquery.get_reservation_utilization(days)

    # ── Composer ─────────────────────────────────────

    def get_composer_dag_stats(self, days: int = 31) -> dict[str, Any]:
        return self.providers.composer.get_dag_run_stats(days)

    def get_composer_environment(self, days: int = 31) -> dict[str, Any]:
        return self.providers.composer.get_environment_health(days)

    def get_composer_task_metrics(self, days: int = 31) -> dict[str, Any]:
        return self.providers.composer.get_task_metrics(days)

    # ── GCS ──────────────────────────────────────────

    def get_gcs_bucket_storage(self, days: int = 31) -> dict[str, Any]:
        return self.providers.gcs.get_bucket_storage(days)

    def get_gcs_access_patterns(self, days: int = 31) -> dict[str, Any]:
        return self.providers.gcs.get_access_patterns(days)

    def get_gcs_storage_classes(self, days: int = 31) -> dict[str, Any]:
        return self.providers.gcs.get_storage_class_distribution(days)

    # ── Bastion ──────────────────────────────────────

    def get_bastion_status(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bastion.get_connection_status(days)

    def get_bastion_sessions(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bastion.get_session_metrics(days)

    def get_bastion_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.bastion.get_resource_utilization(days)

    # ── Composer Infra: Scheduler ────────────────────

    def get_scheduler_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.scheduler.get_resource_usage(days)

    def get_scheduler_heartbeat(self, days: int = 31) -> dict[str, Any]:
        return self.providers.scheduler.get_heartbeat_status(days)

    # ── Composer Infra: DAG Processor ────────────────

    def get_dagprocessor_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.dag_processor.get_resource_usage(days)

    def get_dagprocessor_parsing(self, days: int = 31) -> dict[str, Any]:
        return self.providers.dag_processor.get_parsing_metrics(days)

    # ── Composer Infra: Worker Pool ──────────────────

    def get_worker_pool_status(self, days: int = 31) -> dict[str, Any]:
        return self.providers.worker.get_pool_status(days)

    def get_worker_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.worker.get_resource_usage(days)

    def get_worker_task_execution(self, days: int = 31) -> dict[str, Any]:
        return self.providers.worker.get_task_execution(days)

    # ── Composer Infra: Triggerer ────────────────────

    def get_triggerer_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.triggerer.get_resource_usage(days)

    def get_triggerer_stats(self, days: int = 31) -> dict[str, Any]:
        return self.providers.triggerer.get_trigger_stats(days)

    # ── Composer Infra: WebServer ────────────────────

    def get_webserver_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.webserver.get_resource_usage(days)

    def get_webserver_requests(self, days: int = 31) -> dict[str, Any]:
        return self.providers.webserver.get_request_metrics(days)

    # ── Composer Infra: Cloud SQL ────────────────────

    def get_cloudsql_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.cloudsql.get_resource_usage(days)

    def get_cloudsql_health(self, days: int = 31) -> dict[str, Any]:
        return self.providers.cloudsql.get_db_health(days)

    # ── Composer Infra: GCS ──────────────────────────

    def get_gcs_dag_bucket(self, days: int = 31) -> dict[str, Any]:
        return self.providers.gcs_infra.get_dag_bucket_usage(days)

    def get_gcs_backup_bucket(self, days: int = 31) -> dict[str, Any]:
        return self.providers.gcs_infra.get_backup_bucket_usage(days)

    # ── Composer: Overview & DAG Statistics ────────────

    def get_composer_overview_health(self, days: int = 31) -> dict[str, Any]:
        return self.providers.composer.get_overview_health(days)

    def get_composer_dag_statistics(self, days: int = 31) -> dict[str, Any]:
        return self.providers.composer.get_dag_statistics(days)
