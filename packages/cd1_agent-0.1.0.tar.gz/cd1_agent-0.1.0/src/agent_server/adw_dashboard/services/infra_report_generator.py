"""
ADW Infra Report Generator.

ADW 인프라 현황(BigQuery, Composer, GCS, Bastion)을
SVG 차트와 Summary 카드로 렌더링하는 HTML 리포트 생성기.
"""

import logging
from html import escape as html_escape

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.charts import (
    CHART_COLORS,
    _svg_bar_line_chart,
    _svg_line_chart,
    _svg_stacked_bar_chart,
)
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

from .report_data import AdwInfraReportData

logger = logging.getLogger(__name__)


class AdwInfraReportGenerator(HTMLReportBase):
    """ADW 인프라 현황 리포트 생성기."""

    def __init__(self):
        styles = ReportStyles(primary_color=MD3_COLORS["primary"])
        super().__init__(title="ADW 인프라 현황 리포트", styles=styles)

    def generate_content(self, data: AdwInfraReportData) -> str:
        sections: list[str] = []

        # 1. Summary 카드 (4열)
        sections.append(self._build_summary(data))

        # 2. BigQuery (★ 핵심)
        bq_html = self._build_bigquery_section(data)
        if bq_html:
            sections.append(bq_html)

        # 3. Cloud Composer
        composer_html = self._build_composer_section(data)
        if composer_html:
            sections.append(composer_html)

        # 4. GCS
        gcs_html = self._build_gcs_section(data)
        if gcs_html:
            sections.append(gcs_html)

        # 5. Bastion
        bastion_html = self._build_bastion_section(data)
        if bastion_html:
            sections.append(bastion_html)

        return "\n".join(sections)

    # ── Summary ──────────────────────────────────────

    def _build_summary(self, data: AdwInfraReportData) -> str:
        # 슬롯 사용률
        slot_data = data.bq_slot_utilization
        total_slots = slot_data.get("total_slots", 900)
        latest_slot = (slot_data.get("daily") or [{}])[-1] if slot_data.get("daily") else {}
        current_slots = latest_slot.get("current_slots", 0)
        slot_pct = round(current_slots / total_slots * 100) if total_slots else 0

        # 활성 쿼리
        perf_data = data.bq_query_performance
        latest_perf = (perf_data.get("daily") or [{}])[-1] if perf_data.get("daily") else {}
        active_queries = latest_perf.get("concurrent_queries", 0)

        # Composer 상태
        env_data = data.composer_environment
        latest_env = (env_data.get("daily") or [{}])[-1] if env_data.get("daily") else {}
        composer_healthy = latest_env.get("scheduler_heartbeat") == "healthy"

        # Bastion 상태
        bastion_data = data.bastion_status
        bastion_online = bastion_data.get("status") == "online"

        stats = [
            {
                "label": f"슬롯 사용률 ({current_slots}/{total_slots})",
                "value": f"{slot_pct}%",
                "color": "#388E3C" if slot_pct < 80 else "#F57C00" if slot_pct < 95 else "#D32F2F",
            },
            {
                "label": "활성 쿼리",
                "value": str(active_queries),
                "color": "#1976D2",
            },
            {
                "label": "Composer 상태",
                "value": "정상" if composer_healthy else "점검 필요",
                "color": "#388E3C" if composer_healthy else "#F57C00",
            },
            {
                "label": "Bastion 상태",
                "value": "Online" if bastion_online else "Offline",
                "color": "#388E3C" if bastion_online else "#D32F2F",
            },
        ]
        return self.render_stat_cards(stats, columns=4)

    # ── BigQuery ─────────────────────────────────────

    def _build_bigquery_section(self, data: AdwInfraReportData) -> str:
        parts: list[str] = []

        # 쿼리 성능 — ComposedChart: Bar + Line (프론트엔드: ComposedChart)
        perf_data = data.bq_query_performance
        perf_daily = perf_data.get("daily", [])
        if perf_daily:
            bar_data = {
                "동시 쿼리": [(p["date"], p.get("concurrent_queries", 0)) for p in perf_daily],
            }
            line_data = {
                "실행시간(초)": [(p["date"], p.get("avg_execution_sec", 0)) for p in perf_daily],
            }
            parts.append(
                _svg_bar_line_chart(
                    bar_data,
                    line_data,
                    bar_colors=["#2563eb"],
                    line_colors=["#dc2626"],
                    title="쿼리 성능",
                    subtitle="동시 쿼리 수 / 평균 실행시간",
                    height=220,
                )
            )

        # 잡 이력 — Stacked BarChart (프론트엔드: stacked BarChart)
        job_data = data.bq_job_history
        job_daily = job_data.get("daily", [])
        if job_daily:
            job_series: dict[str, list[tuple[str, float]]] = {
                "완료": [(p["date"], p.get("completed", 0)) for p in job_daily],
                "실패": [(p["date"], p.get("failed", 0)) for p in job_daily],
            }
            parts.append(
                _svg_stacked_bar_chart(
                    job_series,
                    ["#16a34a", "#dc2626"],
                    title="BigQuery Job 이력",
                    subtitle="일별 완료/실패 건수",
                    y_suffix="건",
                    y_integer=True,
                    height=200,
                )
            )

        # 데이터셋 저장소 — Table (프론트엔드: horizontal BarChart → 테이블로 대체)
        ds_data = data.bq_dataset_storage
        datasets = ds_data.get("datasets", {})
        if datasets:
            ds_rows = sorted(
                [
                    (ds_name, ds_info.get("size_tb", 0), ds_info.get("table_count", 0))
                    for ds_name, ds_info in datasets.items()
                    if isinstance(ds_info, dict)
                ],
                key=lambda r: r[1],
                reverse=True,
            )
            if ds_rows:
                parts.append(
                    self._build_simple_table(
                        "데이터셋 저장소",
                        ["데이터셋", "용량 (TB)", "테이블 수"],
                        [[name, f"{size:.2f}", str(cnt)] for name, size, cnt in ds_rows],
                    )
                )

        if not parts:
            return ""
        icon_html = self._icon("analytics", size="sm", inline=True)
        return self._section_card(icon_html, "BigQuery ★", "\n".join(parts))

    # ── Composer ─────────────────────────────────────

    def _build_composer_section(self, data: AdwInfraReportData) -> str:
        parts: list[str] = []

        # 환경 상태 카드
        env_data = data.composer_environment
        if env_data:
            env_name = env_data.get("environment_name", "")
            airflow_ver = env_data.get("airflow_version", "")
            latest_env = (env_data.get("daily") or [{}])[-1] if env_data.get("daily") else {}
            worker_healthy = latest_env.get("worker_healthy", 0)
            worker_count = latest_env.get("worker_count", 0)
            sched_cpu = latest_env.get("scheduler_cpu_pct", 0)
            dag_count = latest_env.get("dag_bag_size", 0)

            parts.append(f"""
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:12px;">
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">환경</div>
                    <div style="font-size:13px;font-weight:600;">{html_escape(str(env_name))}</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">Airflow 버전</div>
                    <div style="font-size:13px;font-weight:600;">{html_escape(str(airflow_ver))}</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">워커</div>
                    <div style="font-size:13px;font-weight:600;">{worker_healthy}/{worker_count} healthy</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">Scheduler CPU / DAGs</div>
                    <div style="font-size:13px;font-weight:600;">{sched_cpu}% / {dag_count}개</div>
                </div>
            </div>
            """)

        # 태스크 메트릭 — Stacked BarChart (프론트엔드: stacked BarChart)
        task_data = data.composer_task_metrics
        task_daily = task_data.get("daily", [])
        if task_daily:
            task_series: dict[str, list[tuple[str, float]]] = {
                "성공": [(p["date"], p.get("success_tasks", 0)) for p in task_daily],
                "실패": [(p["date"], p.get("failed_tasks", 0)) for p in task_daily],
            }
            parts.append(
                _svg_stacked_bar_chart(
                    task_series,
                    ["#16a34a", "#dc2626"],
                    title="태스크 메트릭",
                    subtitle="일별 성공/실패 태스크 수",
                    y_suffix="건",
                    y_integer=True,
                    height=200,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("air", size="sm", inline=True)
        return self._section_card(icon_html, "Cloud Composer", "\n".join(parts))

    # ── GCS ──────────────────────────────────────────

    def _build_gcs_section(self, data: AdwInfraReportData) -> str:
        parts: list[str] = []

        # 버킷 용량 — LineChart (프론트엔드: LineChart)
        bucket_data = data.gcs_bucket_storage
        buckets = bucket_data.get("buckets", {})
        if buckets:
            bucket_series: dict[str, list[tuple[str, float]]] = {}
            for name, points in buckets.items():
                if isinstance(points, list) and points:
                    bucket_series[name] = [(p["date"], p.get("size_tb", 0)) for p in points]
            if bucket_series:
                parts.append(
                    _svg_line_chart(
                        bucket_series,
                        CHART_COLORS,
                        title="GCS 버킷 용량 추이",
                        subtitle="버킷별 저장소 용량 (TB)",
                        y_suffix="TB",
                    )
                )

        # 스토리지 클래스 — Table (프론트엔드: PieChart → 테이블로 대체)
        class_data = data.gcs_storage_classes
        classes = class_data.get("classes", {})
        if classes:
            cls_rows = sorted(
                [
                    (cls_name, size)
                    for cls_name, size in classes.items()
                    if isinstance(size, (int, float))
                ],
                key=lambda r: r[1],
                reverse=True,
            )
            if cls_rows:
                parts.append(
                    self._build_simple_table(
                        "스토리지 클래스 분포",
                        ["클래스", "용량 (TB)"],
                        [[name, f"{size:.2f}"] for name, size in cls_rows],
                    )
                )

        if not parts:
            return ""
        icon_html = self._icon("cloud", size="sm", inline=True)
        return self._section_card(icon_html, "Google Cloud Storage", "\n".join(parts))

    # ── Bastion ──────────────────────────────────────

    def _build_bastion_section(self, data: AdwInfraReportData) -> str:
        parts: list[str] = []

        # 상태 카드
        status_data = data.bastion_status
        if status_data:
            host = status_data.get("host", "")
            status = status_data.get("status", "unknown")
            uptime_hrs = status_data.get("uptime_hours", 0)
            active = status_data.get("active_sessions", 0)
            max_sess = status_data.get("max_sessions", 50)
            online = status == "online"
            status_color = "#16a34a" if online else "#dc2626"

            parts.append(f"""
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:12px;">
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">호스트</div>
                    <div style="font-size:13px;font-weight:600;">{html_escape(str(host))}</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">상태</div>
                    <div style="font-size:13px;font-weight:600;color:{status_color};">{html_escape(str(status))}</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">Uptime</div>
                    <div style="font-size:13px;font-weight:600;">{uptime_hrs // 24}일</div>
                </div>
                <div style="padding:8px 12px;background:#f8fafc;border-radius:6px;">
                    <div style="font-size:11px;color:#6b7280;">활성 세션</div>
                    <div style="font-size:13px;font-weight:600;">{active} / {max_sess}</div>
                </div>
            </div>
            """)

        # 리소스 — LineChart (프론트엔드: LineChart)
        resource_data = data.bastion_resources
        resource_daily = resource_data.get("daily", [])
        if resource_daily:
            res_series: dict[str, list[tuple[str, float]]] = {
                "CPU(%)": [(p["date"], p.get("cpu_pct", 0)) for p in resource_daily],
                "Memory(%)": [(p["date"], p.get("memory_pct", 0)) for p in resource_daily],
            }
            parts.append(
                _svg_line_chart(
                    res_series,
                    ["#2563eb", "#d97706"],
                    title="Bastion 리소스 사용률",
                    subtitle="CPU / Memory 사용률 (%)",
                    y_suffix="%",
                    y_domain=(0, 100),
                    height=200,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("security", size="sm", inline=True)
        return self._section_card(icon_html, "Bastion Host", "\n".join(parts))

    # ── Table Helper ──────────────────────────────────

    @staticmethod
    def _build_simple_table(title: str, headers: list[str], rows: list[list[str]]) -> str:
        th_style = "padding:6px 12px;font-size:11px;font-weight:600;text-align:left;border-bottom:1px solid #e5e7eb;"
        td_style = "padding:6px 12px;font-size:12px;border-bottom:1px solid #f3f4f6;"
        header_html = "".join(f'<th style="{th_style}">{html_escape(h)}</th>' for h in headers)
        rows_html = "".join(
            "<tr>" + "".join(f'<td style="{td_style}">{html_escape(c)}</td>' for c in row) + "</tr>"
            for row in rows
        )
        return f"""
        <div style="margin-bottom:12px;">
            <div style="font-size:12px;font-weight:600;margin-bottom:6px;">{html_escape(title)}</div>
            <table style="width:100%;border-collapse:collapse;">
                <thead><tr>{header_html}</tr></thead>
                <tbody>{rows_html}</tbody>
            </table>
        </div>
        """

    # ── Section Card Helper ──────────────────────────

    def _section_card(self, icon_html: str, title: str, content: str) -> str:
        return f"""
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:8px;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                {icon_html}
                <span style="font-size:14px;font-weight:600;">{html_escape(title)}</span>
            </div>
            <div style="padding:16px 20px;">
                {content}
            </div>
        </div>
        """
