"""Unified Agent Server Configuration."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ServerConfig(BaseSettings):
    """Unified server configuration loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="",
        case_sensitive=False,
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Server
    environment: str = Field(default="test", description="Deployment environment")
    debug: bool = Field(default=False, description="Enable debug mode")
    port: int = Field(default=8000, description="Server port")
    host: str = Field(default="0.0.0.0", description="Server host")
    workers: int = Field(default=2, description="Number of uvicorn workers")
    log_level: str = Field(default="INFO", description="Logging level")

    # Auth
    api_key: str = Field(
        default="a0e33580e47109dab7a4055bca401319a498ef09a1e8a7c4e1fdba5bb001ed05",
        description="API key (sha256 of cd1_agent)",
    )

    @property
    def is_production(self) -> bool:
        return self.environment.lower() in ("prd", "prod")


@lru_cache
def get_server_config() -> ServerConfig:
    return ServerConfig()
