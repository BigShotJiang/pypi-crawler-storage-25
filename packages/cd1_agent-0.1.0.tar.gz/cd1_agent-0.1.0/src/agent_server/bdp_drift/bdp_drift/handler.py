"""
BDP Drift Agent - Lambda Handler (Standalone).

데이터레이크 어플리케이션 레이어의 설정 drift 탐지.
Lambda Layer에서 독립적으로 실행되는 버전.

Supported Resources:
- Primary: Glue, Athena, EMR, SageMaker
- Secondary: S3, MWAA, MSK, Lambda
"""

import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from .services.baseline_store import BaselineStore
from .services.config_fetcher import ConfigFetcher
from .services.drift_detector import DriftDetector
from .services.summary_generator import (
    DriftSummaryGenerator,
    DriftAlertSummary,
)
from .services.models import DriftResult, DriftSeverity

from src.agent_server.bdp_common.eventbridge.publisher import (
    EventPublisher,
    AlertEvent,
    ProductionAlertDetail,
    EmailChannel,
    KakaoChannel,
    get_environment_account_name,
)
from src.agent_server.bdp_common.kakao.notifier import KakaoNotifier
from .services.html_report_generator import DriftHTMLReportGenerator

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class BDPDriftHandler:
    """
    BDP Drift Agent Handler (Lambda Standalone).

    베이스라인과 현재 설정을 비교하여 드리프트 탐지.
    Lambda 환경에서 독립적으로 실행.
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
        sg_prefix_filter: Optional[str] = None,
        model_package_group_name: Optional[str] = None,
    ):
        """핸들러 초기화.

        Args:
            provider: Baseline DB provider ("mock" or "aws")
            secret_id: AWS Secrets Manager secret ID for DB credentials
            db: Database name for baseline storage
            sg_prefix_filter: VPC Security Group 이름 필터 (e.g., "bdp-*")
            model_package_group_name: SageMaker Model Package Group 이름 필터
        """
        # 환경 변수 (파라미터 우선)
        self.provider = provider or os.getenv("DRIFT_PROVIDER", "mock")
        self.baseline_provider = provider or os.getenv("BASELINE_DB_PROVIDER", "mock")
        self.baseline_secret_id = secret_id or os.getenv("BASELINE_SECRET_ID")
        self.baseline_db = db or os.getenv("BASELINE_DB_NAME")
        self.event_provider = os.getenv("EVENT_PROVIDER", "mock")

        # Fetcher 필터 설정
        self.sg_prefix_filter = sg_prefix_filter or os.getenv("SG_PREFIX_FILTER")
        self.model_package_group_name = model_package_group_name or os.getenv("MODEL_PACKAGE_GROUP_NAME")

        # 서비스 초기화
        self.baseline_store = BaselineStore(
            provider=self.baseline_provider,
            secret_id=self.baseline_secret_id,
            db=self.baseline_db,
        )
        self.baseline_store.ensure_tables()

        self.config_fetcher = ConfigFetcher(
            use_mock=(self.provider == "mock"),
            sg_prefix_filter=self.sg_prefix_filter,
            model_package_group_name=self.model_package_group_name,
        )

        self.detector = DriftDetector(
            baseline_store=self.baseline_store,
            config_fetcher=self.config_fetcher,
        )

        self.summary_generator = DriftSummaryGenerator()

        self.event_publisher = EventPublisher(
            source="cd1-agent.bdp-drift",
            use_mock=(self.event_provider == "mock"),
        )

        # Production 알림 설정
        # 이메일 리스트 초기화 (환경변수에서 쉼표 구분 문자열 파싱)
        email_to_str = os.getenv("DEFAULT_EMAIL_TO", "")
        email_cc_str = os.getenv("DEFAULT_EMAIL_CC", "")
        self.default_email_to = [
            e.strip() for e in email_to_str.split(",") if e.strip()
        ]
        self.default_email_cc = [
            e.strip() for e in email_cc_str.split(",") if e.strip()
        ]

        # HTML 리포트 생성기
        self.html_generator = DriftHTMLReportGenerator()

        # 카카오 알림 (선택) - Mock 모드에서만 직접 호출
        self.kakao_notifier: Optional[KakaoNotifier] = None
        if self.event_provider == "mock" and os.getenv("KAKAO_REST_API_KEY"):
            self.kakao_notifier = KakaoNotifier()
            self.kakao_notifier.load_tokens()

        logger.info(
            f"BDPDriftHandler initialized: "
            f"provider={self.provider}, "
            f"baseline_db={self.baseline_provider}, "
            f"event_provider={self.event_provider}"
        )

    def _parse_email_list(self, value: str) -> List[str]:
        """쉼표로 구분된 이메일 문자열을 리스트로 변환.

        Args:
            value: 쉼표로 구분된 이메일 문자열

        Returns:
            이메일 리스트
        """
        if not value:
            return []
        return [e.strip() for e in value.split(",") if e.strip()]

    def process(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """이벤트 처리.

        Args:
            event: 이벤트 페이로드
                - action: "detect" (기본값) 또는 "sync_baselines"

                detect 액션:
                - resource_types: 대상 리소스 타입 목록 (선택)
                    지원 타입: glue, athena, s3, lambda, msk, vpc-sg, eks,
                              sagemaker-pipeline, sagemaker-endpoint, sagemaker-model
                - resource_ids: 특정 리소스 ID 목록 (선택)
                - publish_alerts: EventBridge 발행 여부 (기본 True)
                - send_kakao: 카카오톡 발송 여부 (기본 False)

                sync_baselines 액션:
                - resource_types: 대상 리소스 타입 목록 (선택)
                - created_by: 생성자 (기본 "scheduled-sync")
                - update_existing: 기존 baseline 업데이트 여부 (기본 True)

        Returns:
            처리 결과
        """
        action = event.get("action", "detect")

        if action == "sync_baselines":
            return self._sync_baselines(event)
        else:
            return self._detect_drift(event)

    def _detect_drift(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """드리프트 탐지 실행.

        Args:
            event: 이벤트 페이로드

        Returns:
            탐지 결과
        """
        resource_types = event.get("resource_types")
        resource_ids = event.get("resource_ids")
        publish_alerts = event.get("publish_alerts", True)
        send_kakao = event.get("send_kakao", False)

        # 이메일 수신자 설정 (1순위: Lambda event input, 2순위: 환경변수)
        email_to = event.get("email_to") or self.default_email_to
        email_cc = event.get("email_cc") or self.default_email_cc

        logger.info(
            f"Starting drift detection: "
            f"types={resource_types}, ids={resource_ids}"
        )

        # 드리프트 탐지
        if resource_ids:
            # 특정 리소스만 탐지
            results = []
            for resource_id in resource_ids:
                # resource_id format: type/id
                parts = resource_id.split("/", 1)
                if len(parts) == 2:
                    result = self.detector.detect(parts[0], parts[1])
                    if result:
                        results.append(result)
        else:
            # 전체 탐지
            results = self.detector.detect_all(resource_types=resource_types)

        # 드리프트 필터링
        drifts = [r for r in results if r.has_drift]

        logger.info(
            f"Detection complete: {len(results)} checked, "
            f"{len(drifts)} drifts found"
        )

        # 결과가 없으면 조기 반환
        if not drifts:
            return self._build_response(results, [], None)

        # 요약 생성
        summary = self.summary_generator.generate_batch_summary(drifts)

        # EventBridge 발행
        if publish_alerts:
            self._publish_events(drifts, summary, email_to, email_cc, send_kakao)

        # 카카오톡 발송 (Mock 모드에서만 직접 호출)
        # Production에서는 EventBridge를 통해 Kakao 알림 발송
        if send_kakao and self.kakao_notifier and self.event_publisher.use_mock:
            self._send_kakao_alert(drifts, summary)

        return self._build_response(results, drifts, None)

    def _sync_baselines(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """현재 리소스 상태를 baseline으로 동기화.

        Args:
            event: 이벤트 페이로드
                - resource_types: 대상 리소스 타입 목록 (선택, 없으면 전체)
                - created_by: 생성자 (기본 "scheduled-sync")
                - update_existing: 기존 baseline 업데이트 여부 (기본 True)

        Returns:
            동기화 결과
        """
        resource_types = event.get("resource_types")
        created_by = event.get("created_by", "scheduled-sync")
        update_existing = event.get("update_existing", True)

        # 대상 리소스 타입 결정
        if not resource_types:
            resource_types = self.config_fetcher.supported_resource_types

        logger.info(
            f"Starting baseline sync: "
            f"types={resource_types}, created_by={created_by}, "
            f"update_existing={update_existing}"
        )

        created_count = 0
        updated_count = 0
        skipped_count = 0
        failed_count = 0
        errors: List[Dict[str, Any]] = []

        for resource_type in resource_types:
            try:
                # 해당 타입의 모든 리소스 조회
                resources = self.config_fetcher.list_resources(resource_type)

                for resource_id in resources:
                    try:
                        # 기존 baseline 확인
                        existing = self.baseline_store.get_baseline(
                            resource_type, resource_id
                        )

                        if existing:
                            if update_existing:
                                # 기존 baseline 업데이트
                                result = self.detector.update_baseline_from_current(
                                    resource_type=resource_type,
                                    resource_id=resource_id,
                                    updated_by=created_by,
                                    reason="Scheduled baseline sync",
                                )
                                if result:
                                    updated_count += 1
                                    logger.debug(
                                        f"Updated baseline: {resource_type}/{resource_id}"
                                    )
                                else:
                                    failed_count += 1
                                    errors.append({
                                        "resource_type": resource_type,
                                        "resource_id": resource_id,
                                        "error": "Failed to update baseline",
                                    })
                            else:
                                skipped_count += 1
                                logger.debug(
                                    f"Skipped existing baseline: {resource_type}/{resource_id}"
                                )
                        else:
                            # 새 baseline 생성
                            result = self.detector.create_baseline_from_current(
                                resource_type=resource_type,
                                resource_id=resource_id,
                                created_by=created_by,
                                description="Created by scheduled baseline sync",
                            )
                            if result:
                                created_count += 1
                                logger.debug(
                                    f"Created baseline: {resource_type}/{resource_id}"
                                )
                            else:
                                failed_count += 1
                                errors.append({
                                    "resource_type": resource_type,
                                    "resource_id": resource_id,
                                    "error": "Failed to create baseline",
                                })

                    except Exception as e:
                        failed_count += 1
                        errors.append({
                            "resource_type": resource_type,
                            "resource_id": resource_id,
                            "error": str(e),
                        })
                        logger.error(
                            f"Error syncing baseline {resource_type}/{resource_id}: {e}"
                        )

            except Exception as e:
                logger.error(f"Error listing resources for {resource_type}: {e}")
                errors.append({
                    "resource_type": resource_type,
                    "resource_id": None,
                    "error": f"Failed to list resources: {e}",
                })

        logger.info(
            f"Baseline sync complete: "
            f"created={created_count}, updated={updated_count}, "
            f"skipped={skipped_count}, failed={failed_count}"
        )

        return {
            "status": "success" if failed_count == 0 else "partial",
            "timestamp": get_kst_now().isoformat(),
            "action": "sync_baselines",
            "summary": {
                "created": created_count,
                "updated": updated_count,
                "skipped": skipped_count,
                "failed": failed_count,
            },
            "errors": errors if errors else None,
        }

    def _has_critical(self, results: List[DriftResult]) -> bool:
        """CRITICAL 드리프트 존재 여부."""
        return any(r.severity == DriftSeverity.CRITICAL for r in results)

    def _publish_events(
        self,
        results: List[DriftResult],
        summary: DriftAlertSummary,
        email_to: List[str],
        email_cc: List[str],
        send_kakao: bool = False,
    ) -> None:
        """EventBridge에 이벤트 발행.

        Mock 모드에서는 기존 AlertEvent 형식 사용.
        Production 모드에서는 내부 알림 시스템 형식(ProductionAlertDetail) 사용.

        Args:
            results: DriftResult 목록
            summary: 드리프트 요약 정보
            email_to: 이메일 수신자 목록
            email_cc: 이메일 참조 목록
            send_kakao: 카카오톡 알림 발송 여부
        """
        try:
            if self.event_publisher.use_mock:
                # Mock 모드: 기존 AlertEvent 형식
                event = AlertEvent(
                    alert_type="config_drift_batch",
                    severity=summary.severity_emoji,
                    severity_level=self._get_highest_severity(results).value,
                    title=summary.title,
                    message=summary.message,
                    affected_resources=[
                        {
                            "resource_type": r.resource_type,
                            "resource_id": r.resource_id,
                            "severity": r.severity.value,
                            "drift_count": r.drift_count,
                        }
                        for r in results
                    ],
                    action_required=self._has_critical(results) or any(
                        r.severity == DriftSeverity.HIGH for r in results
                    ),
                    metadata={
                        "total_drifts": summary.drift_count,
                        "critical_count": summary.critical_count,
                        "high_count": summary.high_count,
                    },
                )
                self.event_publisher.publish_event(event, "Config Drift Detected")
                logger.info("EventBridge event published (Mock mode)")
            else:
                # Production 모드: 내부 알림 시스템 형식
                kakao_channel = None
                if send_kakao:
                    kakao_channel = KakaoChannel(
                        severity='MAJOR',
                        category1=get_environment_account_name().upper(),
                        message=self._generate_kakao_message(summary),
                    )

                detail = ProductionAlertDetail(
                    subject=f"{summary.severity_emoji} {summary.title}",
                    account_id=get_environment_account_name(),
                    email=EmailChannel(
                        to=email_to,
                        cc=email_cc,
                        from_email="alert-drift@hcs.com",
                        message=self._generate_html_message(results, summary),
                    ),
                    kakao=kakao_channel,
                )
                self.event_publisher.publish_production_event(
                    detail, "Config Drift Detected"
                )
                logger.info("EventBridge event published (Production mode)")

        except Exception as e:
            logger.error(f"Failed to publish EventBridge event: {e}")

    def _generate_html_message(
        self,
        results: List[DriftResult],
        summary: DriftAlertSummary,
    ) -> str:
        """HTML 형식의 이메일 메시지 생성.

        기존 HtmlReportGenerator를 활용하여 스타일 일관성 유지.

        Args:
            results: DriftResult 목록
            summary: 드리프트 요약 정보

        Returns:
            HTML 문자열
        """
        return self.html_generator.generate_email_report(results, summary)

    def _generate_kakao_message(self, summary: DriftAlertSummary) -> str:
        """간결한 Kakao 메시지 생성.

        Args:
            summary: 드리프트 요약 정보

        Returns:
            Kakao 메시지 문자열
        """
        return f"{summary.title}\n{summary.message}"

    def _send_kakao_alert(
        self,
        results: List[DriftResult],
        summary: DriftAlertSummary,
    ) -> None:
        """카카오톡 알림 발송."""
        if not self.kakao_notifier:
            return

        try:
            self.kakao_notifier.send_text_message(
                f"{summary.title}\n\n{summary.message}"
            )
            logger.info("KakaoTalk alert sent")

        except Exception as e:
            logger.error(f"Failed to send KakaoTalk alert: {e}")

    def _get_highest_severity(self, results: List[DriftResult]) -> DriftSeverity:
        """가장 높은 심각도 반환."""
        for severity in [DriftSeverity.CRITICAL, DriftSeverity.HIGH, DriftSeverity.MEDIUM]:
            if any(r.severity == severity for r in results):
                return severity
        return DriftSeverity.LOW

    def _count_by_severity(
        self, results: List[DriftResult]
    ) -> Dict[str, int]:
        """심각도별 카운트."""
        counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        for r in results:
            counts[r.severity.value] += 1
        return counts

    def _build_response(
        self,
        all_results: List[DriftResult],
        drifts: List[DriftResult],
        hitl_request_id: Optional[str],
    ) -> Dict[str, Any]:
        """응답 생성."""
        severity_counts = self._count_by_severity(drifts)

        return {
            "status": "success",
            "timestamp": get_kst_now().isoformat(),
            "summary": {
                "total_checked": len(all_results),
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
            "drifts": [r.to_dict() for r in drifts],
            "hitl_request_id": hitl_request_id,
        }


# Lambda 핸들러
_handler_instance: Optional[BDPDriftHandler] = None


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda 핸들러 함수.

    Args:
        event: Lambda 이벤트
        context: Lambda 컨텍스트

    Returns:
        탐지 결과
    """
    global _handler_instance

    if _handler_instance is None:
        _handler_instance = BDPDriftHandler()

    return _handler_instance.process(event)


if __name__ == "__main__":
    # 로컬 테스트
    result = handler(
        {
            "resource_types": ["glue", "athena", "s3", "lambda"],
            "publish_alerts": False,
        },
        None,
    )
    print(result)
