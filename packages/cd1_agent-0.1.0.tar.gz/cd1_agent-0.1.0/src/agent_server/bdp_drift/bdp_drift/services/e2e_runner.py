"""
BDP Drift Agent - E2E Runner Service.

E2E 시나리오 테스트를 실행하고 리포트를 생성하는 서비스 클래스.
scripts/run_drift_e2e.py의 핵심 로직을 캡슐화.
"""

import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from .baseline_store import BaselineStore
from .config_fetcher import ConfigFetcher, ResourceConfig
from .daily_report_generator import DriftDailyReportGenerator
from .drift_detector import DriftDetector
from .e2e_report_generator import (
    DriftE2EGroupResult,
    DriftE2EReportData,
    DriftE2EReportGenerator,
    DriftE2ETestResult,
)
from .models import Baseline, DriftResult, DriftSeverity
from .summary_generator import DriftSummaryGenerator


@dataclass
class E2ERunResult:
    """E2E 실행 결과."""

    pass_rate: float
    passed: int
    failed: int
    total: int
    e2e_report_path: str
    daily_report_path: str
    scenarios: List[Dict[str, Any]]


# ── Severity helpers ──

SEVERITY_ORDER = {
    DriftSeverity.CRITICAL: 0,
    DriftSeverity.HIGH: 1,
    DriftSeverity.MEDIUM: 2,
    DriftSeverity.LOW: 3,
}


def _severity_distance(expected: DriftSeverity, actual: DriftSeverity) -> int:
    return abs(SEVERITY_ORDER[expected] - SEVERITY_ORDER[actual])


# ── Mock Infrastructure ──


class MockConfigFetcher:
    """시나리오 기반 Mock ConfigFetcher."""

    def __init__(self):
        self._configs = {}

    def set_config(self, resource_type: str, resource_id: str, config: ResourceConfig):
        self._configs[(resource_type, resource_id)] = config

    def fetch_config(self, resource_type: str, resource_id: str):
        return self._configs.get((resource_type, resource_id))


class MockBaselineStore:
    """시나리오 기반 Mock BaselineStore."""

    def __init__(self):
        self._baselines = {}

    def set_baseline(self, resource_type: str, resource_id: str, baseline: Baseline):
        self._baselines[(resource_type, resource_id)] = baseline

    def get_baseline(self, resource_type: str, resource_id: str):
        return self._baselines.get((resource_type, resource_id))

    def list_baselines(self, resource_type=None):
        if resource_type:
            return [b for (rt, _), b in self._baselines.items() if rt == resource_type]
        return list(self._baselines.values())

    def ensure_tables(self):
        pass


class DriftE2ERunner:
    """E2E 시나리오 테스트 실행기 (Mock 전용)."""

    def __init__(self):
        self._summary_gen = DriftSummaryGenerator()

    def run_all(self, output_dir: str = "reports/") -> E2ERunResult:
        """전체 E2E 시나리오 실행 및 리포트 생성."""
        from tests.agents.bdp_drift.scenarios.scenario_factory import ScenarioFactory

        # 1. 시나리오 로드
        all_groups = ScenarioFactory.get_all_groups()
        groups_map = {
            g.id: {"name": g.name, "name_ko": g.name_ko, "emoji": g.emoji}
            for g in all_groups
        }
        scenarios = ScenarioFactory.get_all_scenarios()

        # 2. 시나리오 실행
        results: List[DriftE2ETestResult] = []
        drift_results: List[DriftResult] = []
        base_time = datetime.now().replace(second=0, microsecond=0)

        for i, scenario in enumerate(scenarios, 1):
            result, raw_drift = self._run_scenario(scenario)

            # Synthetic timestamp 부여
            synthetic_ts = base_time + timedelta(minutes=i * 3)
            if raw_drift is not None and raw_drift.has_drift:
                raw_drift.detection_timestamp = synthetic_ts
                result = DriftE2ETestResult(
                    **{
                        **result.__dict__,
                        "detection_timestamp": synthetic_ts.strftime("%Y-%m-%d %H:%M:%S"),
                    }
                )

            results.append(result)
            if raw_drift is not None:
                drift_results.append(raw_drift)

        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        pass_rate = (passed / len(results) * 100) if results else 0

        # 3. E2E 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        report_data = self._build_report_data(results, groups_map)
        e2e_path = str(output_path / "drift_e2e_report.html")
        DriftE2EReportGenerator().generate_report(report_data, e2e_path)

        # 4. 일간 리포트 생성
        daily_path = str(output_path / "drift_daily_report.html")
        DriftDailyReportGenerator().generate_report(drift_results, daily_path)

        return E2ERunResult(
            pass_rate=pass_rate,
            passed=passed,
            failed=failed,
            total=len(results),
            e2e_report_path=e2e_path,
            daily_report_path=daily_path,
            scenarios=[
                {
                    "scenario_id": r.scenario_id,
                    "scenario_name_ko": r.scenario_name_ko,
                    "passed": r.passed,
                    "expected_severity": r.expected_severity,
                    "actual_severity": r.actual_severity,
                }
                for r in results
            ],
        )

    def _run_scenario(self, scenario) -> tuple:
        """단일 시나리오 실행."""
        mock_store = MockBaselineStore()
        mock_store.set_baseline(
            scenario.resource_type,
            scenario.resource_id,
            Baseline(
                resource_type=scenario.resource_type,
                resource_id=scenario.resource_id,
                version=1,
                config=scenario.baseline_config,
                config_hash=Baseline.compute_hash(scenario.baseline_config),
                resource_arn=scenario.resource_arn,
            ),
        )

        mock_fetcher = MockConfigFetcher()
        mock_fetcher.set_config(
            scenario.resource_type,
            scenario.resource_id,
            ResourceConfig(
                resource_type=scenario.resource_type,
                resource_id=scenario.resource_id,
                resource_arn=scenario.resource_arn,
                config=scenario.current_config,
            ),
        )

        detector = DriftDetector(
            baseline_store=mock_store,
            config_fetcher=mock_fetcher,
        )

        start = time.perf_counter()
        result: DriftResult = detector.detect(scenario.resource_type, scenario.resource_id)
        elapsed_ms = (time.perf_counter() - start) * 1000

        if result is None:
            return DriftE2ETestResult(
                scenario_id=scenario.id,
                scenario_name=scenario.name,
                scenario_name_ko=scenario.name_ko,
                description_ko=scenario.description_ko,
                group_id=scenario.group_id,
                group_name=scenario.group_name,
                resource_type=scenario.resource_type,
                resource_id=scenario.resource_id,
                expected_severity=scenario.expected_severity.value,
                expected_has_drift=scenario.expected_has_drift,
                expected_drift_count=scenario.expected_drift_count,
                actual_severity="low",
                actual_has_drift=False,
                actual_drift_count=0,
                passed=not scenario.expected_has_drift,
                pass_reason="결과 없음 (None)" if scenario.expected_has_drift else "정상: 드리프트 없음",
                execution_time_ms=elapsed_ms,
                baseline_config=scenario.baseline_config,
                current_config=scenario.current_config,
            ), None

        actual_has_drift = result.has_drift
        actual_severity = result.severity.value
        actual_drift_count = result.drift_count

        passed = True
        reasons = []

        if scenario.expected_has_drift != actual_has_drift:
            passed = False
            reasons.append(
                f"드리프트 존재 불일치: 예상={'있음' if scenario.expected_has_drift else '없음'}, "
                f"실제={'있음' if actual_has_drift else '없음'}"
            )
        else:
            reasons.append(f"드리프트 존재 일치: {'있음' if actual_has_drift else '없음'}")

        if actual_has_drift and scenario.expected_has_drift:
            dist = _severity_distance(scenario.expected_severity, result.severity)
            if dist == 0:
                reasons.append(f"심각도 정확 일치: {actual_severity}")
            elif dist <= 1:
                reasons.append(
                    f"심각도 허용 범위: 예상={scenario.expected_severity.value}, 실제={actual_severity}"
                )
            else:
                passed = False
                reasons.append(
                    f"심각도 불일치: 예상={scenario.expected_severity.value}, "
                    f"실제={actual_severity} (거리={dist})"
                )

            if actual_drift_count < scenario.expected_drift_count:
                passed = False
                reasons.append(
                    f"드리프트 필드 부족: 예상≥{scenario.expected_drift_count}, 실제={actual_drift_count}"
                )

        drift_fields_data = []
        for f in result.drift_fields:
            drift_fields_data.append({
                "field_name": f.field_name,
                "baseline_value": f.baseline_value,
                "current_value": f.current_value,
                "severity": f.severity.value,
                "category": f.category.value,
                "description": f.description or "",
            })

        alert_title = ""
        alert_message = ""
        if result.has_drift:
            try:
                alert_summary = self._summary_gen.generate(result)
                alert_title = alert_summary.title
                alert_message = alert_summary.message
            except Exception:
                pass

        det_ts = None
        if result.detection_timestamp:
            det_ts = result.detection_timestamp.strftime("%Y-%m-%d %H:%M:%S")

        return DriftE2ETestResult(
            scenario_id=scenario.id,
            scenario_name=scenario.name,
            scenario_name_ko=scenario.name_ko,
            description_ko=scenario.description_ko,
            group_id=scenario.group_id,
            group_name=scenario.group_name,
            resource_type=scenario.resource_type,
            resource_id=scenario.resource_id,
            expected_severity=scenario.expected_severity.value,
            expected_has_drift=scenario.expected_has_drift,
            expected_drift_count=scenario.expected_drift_count,
            actual_severity=actual_severity,
            actual_has_drift=actual_has_drift,
            actual_drift_count=actual_drift_count,
            actual_drift_fields=drift_fields_data,
            passed=passed,
            pass_reason=" | ".join(reasons),
            execution_time_ms=elapsed_ms,
            baseline_config=scenario.baseline_config,
            current_config=scenario.current_config,
            alert_title=alert_title,
            alert_message=alert_message,
            detection_timestamp=det_ts,
        ), result

    @staticmethod
    def _build_report_data(results, groups_map) -> DriftE2EReportData:
        """리포트 데이터 빌드."""
        grouped = defaultdict(list)
        for r in results:
            grouped[r.group_id].append(r)

        group_results = []
        for gid in sorted(grouped.keys()):
            g_results = grouped[gid]
            g_passed = sum(1 for r in g_results if r.passed)
            g_total = len(g_results)
            g_info = groups_map.get(gid, {})
            group_results.append(
                DriftE2EGroupResult(
                    group_id=gid,
                    group_name=g_info.get("name", f"Group {gid}"),
                    group_name_ko=g_info.get("name_ko", ""),
                    emoji=g_info.get("emoji", ""),
                    total=g_total,
                    passed=g_passed,
                    failed=g_total - g_passed,
                    pass_rate=(g_passed / g_total * 100) if g_total else 0,
                    results=g_results,
                )
            )

        total = len(results)
        passed = sum(1 for r in results if r.passed)
        all_latencies = [r.execution_time_ms for r in results]

        return DriftE2EReportData(
            total=total,
            passed=passed,
            failed=total - passed,
            pass_rate=(passed / total * 100) if total else 0,
            avg_latency_ms=sum(all_latencies) / len(all_latencies) if all_latencies else 0,
            groups=group_results,
            all_results=results,
        )
