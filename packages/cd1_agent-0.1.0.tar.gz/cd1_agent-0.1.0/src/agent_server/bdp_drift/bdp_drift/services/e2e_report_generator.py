"""
E2E Scenario Test Report Generator for BDP Drift Agent.

Material Design 기반 HTML 리포트 생성.
베이스라인 vs 현재설정 비교, 드리프트 필드 상세, 심각도 분포 포함.
카카오톡 알림 미리보기, 데일리 리포트 미리보기, 설정 트리 뷰 포함.
"""

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from html import escape as html_escape
from typing import Any, Dict, List, Optional

from src.common.timezone import get_kst_now

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)


def _format_value(field_name: str, value: Any) -> str:
    """드리프트 값을 사람이 읽기 쉽게 정제."""
    if value is None:
        return "미설정"
    if isinstance(value, bool):
        return "활성화" if value else "비활성화"
    if isinstance(value, (int, float)):
        fn = field_name.lower()
        if "memory" in fn or "volume_size" in fn or "ebs_volume" in fn:
            return f"{value:,} MB"
        if "timeout" in fn:
            return f"{value}초"
        if any(k in fn for k in ["count", "capacity", "workers", "brokers", "nodes"]):
            return f"{value}개"
        return f"{value:,}" if isinstance(value, int) and value >= 1000 else str(value)
    if isinstance(value, str):
        if value.startswith("arn:aws:"):
            if "/" in value:
                return value.rsplit("/", 1)[-1]
            # arn:aws:lambda:region:acct:layer:name:ver → layer:name:ver
            segments = value.split(":")
            if len(segments) >= 7:
                return ":".join(segments[5:])
            return segments[-1]
        return value
    if isinstance(value, dict):
        if not value:
            return "빈 설정"
        lines = []
        for k, v in value.items():
            if isinstance(v, bool):
                v_str = "활성화" if v else "비활성화"
            elif v is None:
                v_str = "미설정"
            else:
                v_str = str(v)
                if len(v_str) > 50:
                    v_str = v_str[:47] + "..."
            lines.append(f"  {k}: {v_str}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return "빈 목록"
        n = len(value)
        if all(isinstance(item, str) for item in value):
            def _short_arn(s):
                if not s.startswith("arn:aws:"):
                    return s
                return _format_value("", s)
            if n <= 3 and all(len(s) < 60 for s in value):
                return ", ".join(_short_arn(s) for s in value)
            short = [_short_arn(s) for s in value[:2]]
            return f"{', '.join(short)} 외 {n - 2}건" if n > 2 else ", ".join(short)
        if all(isinstance(item, dict) for item in value):
            lines = [f"{n}건:"]
            for i, item in enumerate(value[:3]):
                parts = [f"{k}={v}" for k, v in list(item.items())[:3]]
                lines.append(f"  [{i+1}] {', '.join(parts)}")
            if n > 3:
                lines.append(f"  ... 외 {n - 3}건")
            return "\n".join(lines)
        return f"{n}개 항목"
    return str(value)


@dataclass
class DriftE2ETestResult:
    """개별 E2E 테스트 결과."""

    scenario_id: str
    scenario_name: str
    scenario_name_ko: str
    description_ko: str
    group_id: str
    group_name: str
    resource_type: str
    resource_id: str
    # Expected
    expected_severity: str
    expected_has_drift: bool
    expected_drift_count: int
    # Actual
    actual_severity: str
    actual_has_drift: bool
    actual_drift_count: int
    actual_drift_fields: List[Dict[str, Any]] = field(default_factory=list)
    # Pass/Fail
    passed: bool = False
    pass_reason: str = ""
    execution_time_ms: float = 0.0
    # Full configs for tree view
    baseline_config: Dict[str, Any] = field(default_factory=dict)
    current_config: Dict[str, Any] = field(default_factory=dict)
    # Kakao alert preview
    alert_title: str = ""
    alert_message: str = ""
    # Detection timestamp
    detection_timestamp: Optional[str] = None  # "2026-02-20 14:30:45"


@dataclass
class DriftE2EGroupResult:
    """그룹별 결과 요약."""

    group_id: str
    group_name: str
    group_name_ko: str
    emoji: str
    total: int
    passed: int
    failed: int
    pass_rate: float
    results: List[DriftE2ETestResult] = field(default_factory=list)


@dataclass
class DriftE2EReportData:
    """전체 E2E 리포트 데이터."""

    total: int
    passed: int
    failed: int
    pass_rate: float
    avg_latency_ms: float
    groups: List[DriftE2EGroupResult] = field(default_factory=list)
    all_results: List[DriftE2ETestResult] = field(default_factory=list)


class DriftE2EReportGenerator(HTMLReportBase):
    """BDP Drift Agent E2E 시나리오 테스트 리포트 생성기."""

    def __init__(self):
        super().__init__(
            title="BDP 드리프트 에이전트 - E2E 시나리오 테스트 리포트",
            styles=ReportStyles(),
        )

    def _wrap_html(self, content: str) -> str:
        timestamp = get_kst_now().strftime("%Y-%m-%d %H:%M:%S KST")
        return f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title}</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        {self.styles.get_base_css()}
        {self._get_icon_css()}
        {self._get_drift_css()}
    </style>
</head>
<body>
    <div class="header drift-header">
        <div class="container">
            <h1 class="header-title">
                {self._icon('shield', size='lg', color='on-surface', inline=True)}
                {self.title}
            </h1>
            <p class="header-subtitle">생성 시각: {timestamp}</p>
        </div>
    </div>
    <div class="container">
        {content}
    </div>
    {self._get_drift_js()}
</body>
</html>"""

    def _get_drift_css(self) -> str:
        return f"""
        .drift-header {{
            background: linear-gradient(135deg, #B71C1C 0%, #880E4F 100%);
            color: white; padding: 32px 0;
        }}
        .drift-header .header-title {{ color: white; font-size: 28px; }}
        .drift-header .header-subtitle {{ color: rgba(255,255,255,0.8); }}
        .grid-5 {{ grid-template-columns: repeat(5, 1fr); }}
        @media (max-width: 768px) {{ .grid-5 {{ grid-template-columns: repeat(2, 1fr); }} }}

        .group-bar {{ margin-bottom: 12px; }}
        .group-bar-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; font-size: 14px; }}
        .group-bar-track {{ background: {MD3_COLORS['outline_variant']}; border-radius: 4px; height: 24px; overflow: hidden; }}
        .group-bar-fill {{ height: 100%; border-radius: 4px; display: flex; align-items: center; padding-left: 8px; font-size: 12px; font-weight: 600; color: white; transition: width 0.5s ease; }}

        .test-card {{ background: {MD3_COLORS['surface']}; border: 1px solid {MD3_COLORS['outline_variant']}; border-radius: 8px; margin-bottom: 8px; overflow: hidden; transition: box-shadow 0.2s; }}
        .test-card:hover {{ box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        .test-card.pass {{ border-left: 4px solid {MD3_COLORS['success']}; }}
        .test-card.fail {{ border-left: 4px solid {MD3_COLORS['error']}; }}

        .test-card-header {{ display: flex; align-items: center; padding: 12px 16px; cursor: pointer; user-select: none; gap: 12px; }}
        .test-card-header:hover {{ background: {MD3_COLORS['surface_variant']}; }}
        .test-card-id {{ font-weight: 600; font-size: 13px; color: {MD3_COLORS['on_surface_variant']}; min-width: 40px; }}
        .test-card-name {{ flex: 1; font-weight: 500; font-size: 14px; }}
        .test-card-meta {{ display: flex; gap: 8px; align-items: center; flex-shrink: 0; }}
        .test-card-time {{ font-size: 12px; color: {MD3_COLORS['on_surface_variant']}; }}
        .test-card-chevron {{ transition: transform 0.2s; color: {MD3_COLORS['on_surface_variant']}; }}
        .test-card.expanded .test-card-chevron {{ transform: rotate(180deg); }}

        .test-card-body {{ display: none; padding: 0 16px 16px; border-top: 1px solid {MD3_COLORS['outline_variant']}; }}
        .test-card.expanded .test-card-body {{ display: block; }}

        .detail-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 12px; }}
        .detail-section {{ background: {MD3_COLORS['surface_variant']}; border-radius: 8px; padding: 12px; }}
        .detail-section h4 {{ font-size: 13px; color: {MD3_COLORS['on_surface_variant']}; margin-bottom: 8px; }}
        .detail-row {{ display: flex; justify-content: space-between; padding: 4px 0; font-size: 13px; }}
        .detail-label {{ color: {MD3_COLORS['on_surface_variant']}; }}
        .detail-value {{ font-weight: 500; }}
        .group-badge {{ display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 500; background: {MD3_COLORS['primary_container']}; color: {MD3_COLORS['on_primary_container']}; }}

        .drift-field {{ padding: 8px; margin: 4px 0; border-radius: 6px; font-size: 13px; border-left: 3px solid; }}
        .drift-field.critical {{ border-color: {MD3_COLORS['error']}; background: {MD3_COLORS['error_container']}; }}
        .drift-field.high {{ border-color: {MD3_COLORS['warning']}; background: {MD3_COLORS['warning_container']}; }}
        .drift-field.medium {{ border-color: {MD3_COLORS['primary']}; background: {MD3_COLORS['primary_container']}; }}
        .drift-field.low {{ border-color: {MD3_COLORS['outline']}; background: {MD3_COLORS['surface_variant']}; }}

        .filter-bar {{ display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }}
        .filter-btn {{ padding: 6px 16px; border: 1px solid {MD3_COLORS['outline']}; border-radius: 20px; background: {MD3_COLORS['surface']}; cursor: pointer; font-size: 13px; transition: all 0.2s; }}
        .filter-btn:hover {{ background: {MD3_COLORS['surface_variant']}; }}
        .filter-btn.active {{ background: {MD3_COLORS['primary']}; color: white; border-color: {MD3_COLORS['primary']}; }}

        /* Config Tree View */
        .config-tree {{
            font-family: 'Monaco', 'Menlo', 'Consolas', monospace;
            font-size: 12px;
            line-height: 1.8;
            padding: 12px 16px;
            background: {MD3_COLORS['surface']};
            border: 1px solid {MD3_COLORS['outline_variant']};
            border-radius: 8px;
            overflow-x: auto;
        }}
        .tree-node {{
            padding-left: 24px;
        }}
        .tree-line {{
            display: block;
            white-space: nowrap;
        }}
        .tree-prefix {{
            color: {MD3_COLORS['outline']};
            user-select: none;
        }}
        .tree-key {{
            color: {MD3_COLORS['on_surface_variant']};
            font-weight: 500;
        }}
        .tree-value {{
            color: {MD3_COLORS['on_surface']};
        }}
        .tree-value-null {{
            color: {MD3_COLORS['error']};
            font-style: italic;
        }}
        .tree-value-bool {{
            font-weight: 600;
        }}
        .tree-value-num {{
            color: {MD3_COLORS['primary']};
        }}
        .tree-value-str {{
            color: #2E7D32;
        }}
        .tree-drift {{
            background: #FFF3E0;
            border-left: 3px solid #F57C00;
            padding: 2px 8px;
            border-radius: 4px;
            margin: 1px 0;
            display: block;
        }}
        .tree-drift .tree-key {{
            color: #E65100;
            font-weight: 700;
        }}
        .tree-drift-arrow {{
            color: #F57C00;
            font-weight: 600;
        }}
        .tree-drift-old {{
            color: #BF360C;
            text-decoration: line-through;
            opacity: 0.7;
        }}
        .tree-drift-new {{
            color: #E65100;
            font-weight: 600;
        }}
        .tree-section-title {{
            font-size: 13px;
            font-weight: 600;
            color: {MD3_COLORS['on_surface_variant']};
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }}

        /* Kakao Talk Preview */
        .kakao-section {{
            padding: 16px;
            background: {MD3_COLORS['surface_variant']};
            border-top: 1px solid {MD3_COLORS['outline_variant']};
            margin-top: 12px;
            border-radius: 0 0 8px 8px;
        }}
        .kakao-section h4 {{
            font-size: 13px;
            color: {MD3_COLORS['on_surface_variant']};
            margin-bottom: 12px;
        }}
        .kakao-preview {{
            display: flex;
            justify-content: center;
        }}
        .kakao-bubble {{
            background: #FEE500;
            border-radius: 15px;
            padding: 15px;
            max-width: 350px;
            width: 100%;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }}
        .kakao-title {{
            font-weight: bold;
            font-size: 14px;
            color: #3c1e1e;
            margin-bottom: 8px;
        }}
        .kakao-divider {{
            height: 1px;
            background: rgba(60, 30, 30, 0.2);
            margin: 8px 0;
        }}
        .kakao-content {{
            font-size: 13px;
            color: #3c1e1e;
            line-height: 1.5;
            white-space: pre-wrap;
        }}

        """

    def _get_drift_js(self) -> str:
        return """
<script>
document.addEventListener('click', function(e) {
    const header = e.target.closest('.test-card-header');
    if (!header) return;
    header.closest('.test-card').classList.toggle('expanded');
});
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    const filterGroup = btn.closest('.filter-bar');
    filterGroup.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const filter = btn.dataset.filter;
    document.querySelectorAll('.test-card').forEach(card => {
        if (filter === 'all') card.style.display = '';
        else if (filter === 'pass') card.style.display = card.classList.contains('pass') ? '' : 'none';
        else if (filter === 'fail') card.style.display = card.classList.contains('fail') ? '' : 'none';
    });
});
function toggleAll(expand) {
    document.querySelectorAll('.test-card').forEach(card => {
        if (expand) card.classList.add('expanded');
        else card.classList.remove('expanded');
    });
}
</script>"""

    # ── Content Generation ────────────────────────────────────────────

    def generate_content(self, data: DriftE2EReportData) -> str:
        sections = []
        sections.append(self._generate_summary_cards(data))
        sections.append(self._generate_severity_distribution(data))
        sections.append(self._generate_group_breakdown(data))
        sections.append(self._generate_filter_bar(data))
        sections.append(self._generate_test_items(data))
        return "\n".join(sections)

    def _generate_summary_cards(self, data: DriftE2EReportData) -> str:
        pass_color = MD3_COLORS["success"] if data.pass_rate >= 85 else MD3_COLORS["warning"]
        if data.pass_rate < 70:
            pass_color = MD3_COLORS["error"]
        stats = [
            {"label": "전체", "value": str(data.total), "color": MD3_COLORS["primary"]},
            {"label": "통과", "value": str(data.passed), "color": MD3_COLORS["success"]},
            {"label": "실패", "value": str(data.failed), "color": MD3_COLORS["error"]},
            {"label": "통과율", "value": f"{data.pass_rate:.1f}%", "color": pass_color},
            {"label": "평균 지연", "value": f"{data.avg_latency_ms:.0f}ms", "color": MD3_COLORS["on_surface_variant"]},
        ]
        return self.render_stat_cards(stats, columns=5)

    def _generate_severity_distribution(self, data: DriftE2EReportData) -> str:
        severity_counts = Counter(r.actual_severity.lower() for r in data.all_results if r.actual_has_drift)
        no_drift = sum(1 for r in data.all_results if not r.actual_has_drift)
        severity_config = {
            "critical": {"color": MD3_COLORS["error"], "bg": MD3_COLORS["error_container"]},
            "high": {"color": MD3_COLORS["warning"], "bg": MD3_COLORS["warning_container"]},
            "medium": {"color": MD3_COLORS["primary"], "bg": MD3_COLORS["primary_container"]},
            "low": {"color": MD3_COLORS["outline"], "bg": MD3_COLORS["surface_variant"]},
        }
        cards = []
        for sev in ["critical", "high", "medium", "low"]:
            count = severity_counts.get(sev, 0)
            cfg = severity_config[sev]
            cards.append(
                f'<div style="text-align:center; padding:16px; border-radius:8px; '
                f'background:{cfg["bg"]}; border-left:4px solid {cfg["color"]};">'
                f'<div style="font-size:28px; font-weight:700; color:{cfg["color"]};">{count}</div>'
                f'<div style="font-size:12px; margin-top:4px; font-weight:500;">{sev.upper()}</div></div>'
            )
        cards.append(
            f'<div style="text-align:center; padding:16px; border-radius:8px; '
            f'background:{MD3_COLORS["success_container"]}; border-left:4px solid {MD3_COLORS["success"]};">'
            f'<div style="font-size:28px; font-weight:700; color:{MD3_COLORS["success"]};">{no_drift}</div>'
            f'<div style="font-size:12px; margin-top:4px; font-weight:500;">NO DRIFT</div></div>'
        )
        return self.render_card(
            f"{self._icon('bar_chart', size='sm', inline=True)} 드리프트 심각도 분포",
            f'<div class="grid grid-{len(cards)}">{"".join(cards)}</div>',
        )

    def _generate_group_breakdown(self, data: DriftE2EReportData) -> str:
        bars = []
        for g in data.groups:
            rate = g.pass_rate
            color = MD3_COLORS["success"] if rate >= 90 else (MD3_COLORS["warning"] if rate >= 70 else MD3_COLORS["error"])
            width = max(rate, 5)
            bars.append(f"""
            <div class="group-bar">
                <div class="group-bar-header">
                    <span>{g.emoji} 그룹 {g.group_id}: {g.group_name_ko}</span>
                    <span><strong>{g.passed}/{g.total}</strong> ({rate:.0f}%)</span>
                </div>
                <div class="group-bar-track">
                    <div class="group-bar-fill" style="width:{width}%; background:{color};">{g.passed}/{g.total}</div>
                </div>
            </div>""")
        return self.render_card(
            f"{self._icon('bar_chart', size='sm', inline=True)} 그룹별 결과",
            "\n".join(bars),
        )

    def _generate_filter_bar(self, data: DriftE2EReportData) -> str:
        buttons = [
            '<button class="filter-btn active" data-filter="all">전체</button>',
            f'<button class="filter-btn" data-filter="pass">{self._icon("check_circle", size="xs", color="success", inline=True)} 통과</button>',
            f'<button class="filter-btn" data-filter="fail">{self._icon("error", size="xs", color="error", inline=True)} 실패</button>',
        ]
        expand_controls = (
            '<span style="margin-left:auto;">'
            '<button class="filter-btn" onclick="toggleAll(true)">모두 펼치기</button>'
            '<button class="filter-btn" onclick="toggleAll(false)">모두 접기</button>'
            '</span>'
        )
        return f'<div class="filter-bar">{"".join(buttons)}{expand_controls}</div>'

    def _generate_test_items(self, data: DriftE2EReportData) -> str:
        cards = []
        for r in data.all_results:
            cards.append(self._generate_test_card(r))
        return "\n".join(cards)

    # ── Test Card ─────────────────────────────────────────────────────

    def _generate_test_card(self, r: DriftE2ETestResult) -> str:
        status_class = "pass" if r.passed else "fail"
        status_icon = (
            self._icon("check_circle", size="sm", filled=True, color="success")
            if r.passed
            else self._icon("error", size="sm", filled=True, color="error")
        )
        severity_badge = self.render_severity_badge(r.actual_severity) if r.actual_has_drift else '<span style="color:green; font-weight:500;">NO DRIFT</span>'
        expected_badge = self.render_severity_badge(r.expected_severity) if r.expected_has_drift else '<span style="color:green; font-weight:500;">NO DRIFT</span>'

        # Tree view (replaces old JSON drift-field list)
        tree_html = self._render_config_tree(r)

        # Kakao preview
        kakao_html = self._render_kakao_preview(r)

        return f"""
        <div class="test-card {status_class}" data-group="{r.group_id}">
            <div class="test-card-header">
                <span>{status_icon}</span>
                <span class="test-card-id">#{r.scenario_id}</span>
                <span class="test-card-name">{r.scenario_name_ko}</span>
                <span class="test-card-meta">
                    <span class="group-badge">{r.group_name}</span>
                    {severity_badge}
                    {f'<span class="test-card-time">{r.detection_timestamp}</span>' if r.detection_timestamp else ''}
                    <span class="test-card-time">{r.execution_time_ms:.0f}ms</span>
                </span>
                <span class="test-card-chevron">{self._icon('expand_more', size='sm')}</span>
            </div>
            <div class="test-card-body">
                <p style="margin:12px 0 0; color:{MD3_COLORS['on_surface_variant']}; font-size:13px;">{r.description_ko}</p>
                <div class="detail-grid">
                    <div class="detail-section">
                        <h4>{self._icon('target', size='xs', inline=True)} 예상 결과</h4>
                        <div class="detail-row"><span class="detail-label">심각도</span><span class="detail-value">{expected_badge}</span></div>
                        <div class="detail-row"><span class="detail-label">드리프트</span><span class="detail-value">{'있음' if r.expected_has_drift else '없음'}</span></div>
                        <div class="detail-row"><span class="detail-label">변경 필드 수</span><span class="detail-value">{r.expected_drift_count}</span></div>
                        <div class="detail-row"><span class="detail-label">리소스</span><span class="detail-value">{r.resource_type}/{r.resource_id}</span></div>
                    </div>
                    <div class="detail-section">
                        <h4>{self._icon('analytics', size='xs', inline=True)} 실제 결과</h4>
                        <div class="detail-row"><span class="detail-label">심각도</span><span class="detail-value">{severity_badge}</span></div>
                        <div class="detail-row"><span class="detail-label">드리프트</span><span class="detail-value">{'있음' if r.actual_has_drift else '없음'}</span></div>
                        <div class="detail-row"><span class="detail-label">변경 필드 수</span><span class="detail-value">{r.actual_drift_count}</span></div>
                    </div>
                </div>
                {self._render_pass_reason(r)}
                {tree_html}
                {kakao_html}
            </div>
        </div>"""

    def _render_pass_reason(self, r: DriftE2ETestResult) -> str:
        if r.passed:
            return (
                f'<div style="margin-top:12px; padding:8px 12px; background:{MD3_COLORS["success_container"]};'
                f' border-radius:6px; font-size:13px; color:{MD3_COLORS["on_success_container"]};">'
                f'{self._icon("check", size="xs", inline=True)} {r.pass_reason}</div>'
            )
        return (
            f'<div style="margin-top:12px; padding:8px 12px; background:{MD3_COLORS["error_container"]};'
            f' border-radius:6px; font-size:13px; color:{MD3_COLORS["on_error_container"]};">'
            f'{self._icon("close", size="xs", inline=True)} {r.pass_reason}</div>'
        )

    # ── Config Tree View ──────────────────────────────────────────────

    def _render_config_tree(self, r: DriftE2ETestResult) -> str:
        """설정 트리 뷰 렌더링 (드리프트 필드 주황색 하이라이트)."""
        if not r.current_config:
            return ""

        # drift field lookup: field_name -> {baseline, current, severity}
        drift_map = {}
        for df in r.actual_drift_fields:
            drift_map[df["field_name"]] = {
                "baseline": df.get("baseline_value", "N/A"),
                "current": df.get("current_value", "N/A"),
                "severity": df.get("severity", "medium"),
            }

        tree_lines = self._build_tree_lines(r.current_config, drift_map, prefix="", is_last=True)
        tree_html = "\n".join(tree_lines)

        return f"""
        <div style="margin-top:12px;">
            <div class="tree-section-title">
                {self._icon('account_tree', size='xs', inline=True)} 현재 설정 트리
                <span style="font-weight:400; font-size:11px; color:{MD3_COLORS['outline']};">
                    (주황색 = 드리프트 필드)
                </span>
            </div>
            <div class="config-tree">{tree_html}</div>
        </div>
        """

    def _build_tree_lines(
        self,
        config: Any,
        drift_map: Dict[str, Dict],
        prefix: str = "",
        is_last: bool = True,
    ) -> List[str]:
        """재귀적으로 설정 트리 HTML 라인 생성."""
        lines: List[str] = []

        if not isinstance(config, dict):
            return lines

        keys = list(config.keys())
        for i, key in enumerate(keys):
            value = config[key]
            is_last_key = i == len(keys) - 1
            connector = "└── " if is_last_key else "├── "
            child_prefix = prefix + ("    " if is_last_key else "│   ")

            is_drifted = key in drift_map

            if isinstance(value, dict) and not is_drifted:
                # Non-drifted nested dict: expand as subtree
                lines.append(
                    f'<span class="tree-line">'
                    f'<span class="tree-prefix">{html_escape(prefix)}{html_escape(connector)}</span>'
                    f'<span class="tree-key">{html_escape(str(key))}</span>:'
                    f'</span>'
                )
                lines.extend(self._build_tree_lines(value, drift_map, child_prefix))

            elif isinstance(value, list) and not is_drifted:
                # Non-drifted list: show count and expand items
                lines.append(
                    f'<span class="tree-line">'
                    f'<span class="tree-prefix">{html_escape(prefix)}{html_escape(connector)}</span>'
                    f'<span class="tree-key">{html_escape(str(key))}</span>: '
                    f'<span class="tree-value">[{len(value)} items]</span>'
                    f'</span>'
                )
                for j, item in enumerate(value):
                    item_is_last = j == len(value) - 1
                    item_connector = "└── " if item_is_last else "├── "
                    if isinstance(item, dict):
                        item_child_prefix = child_prefix + ("    " if item_is_last else "│   ")
                        lines.append(
                            f'<span class="tree-line">'
                            f'<span class="tree-prefix">{html_escape(child_prefix)}{html_escape(item_connector)}</span>'
                            f'<span class="tree-key">[{j}]</span>:'
                            f'</span>'
                        )
                        lines.extend(self._build_tree_lines(item, {}, item_child_prefix))
                    else:
                        lines.append(
                            f'<span class="tree-line">'
                            f'<span class="tree-prefix">{html_escape(child_prefix)}{html_escape(item_connector)}</span>'
                            f'{self._format_tree_value(item)}'
                            f'</span>'
                        )

            elif is_drifted:
                # Drifted field: orange highlight with before → after
                drift_info = drift_map[key]
                baseline_str = self._format_tree_value_short(drift_info["baseline"], field_name=str(key))
                current_str = self._format_tree_value_short(drift_info["current"], field_name=str(key))
                lines.append(
                    f'<span class="tree-line tree-drift">'
                    f'<span class="tree-prefix">{html_escape(prefix)}{html_escape(connector)}</span>'
                    f'<span class="tree-key">{html_escape(str(key))}</span>: '
                    f'<span class="tree-drift-old">{baseline_str}</span>'
                    f' <span class="tree-drift-arrow">→</span> '
                    f'<span class="tree-drift-new">{current_str}</span>'
                    f'</span>'
                )

            else:
                # Simple leaf value
                lines.append(
                    f'<span class="tree-line">'
                    f'<span class="tree-prefix">{html_escape(prefix)}{html_escape(connector)}</span>'
                    f'<span class="tree-key">{html_escape(str(key))}</span>: '
                    f'{self._format_tree_value(value)}'
                    f'</span>'
                )

        return lines

    def _format_tree_value(self, value: Any) -> str:
        """트리 리프 값 포맷."""
        if value is None:
            return '<span class="tree-value-null">null</span>'
        if isinstance(value, bool):
            color = MD3_COLORS["success"] if value else MD3_COLORS["error"]
            return f'<span class="tree-value-bool" style="color:{color};">{str(value).lower()}</span>'
        if isinstance(value, (int, float)):
            return f'<span class="tree-value-num">{value}</span>'
        if isinstance(value, str):
            return f'<span class="tree-value-str">"{html_escape(value)}"</span>'
        if isinstance(value, list):
            return f'<span class="tree-value">[{len(value)} items]</span>'
        if isinstance(value, dict):
            return f'<span class="tree-value">{{{len(value)} keys}}</span>'
        return f'<span class="tree-value">{html_escape(str(value))}</span>'

    def _format_tree_value_short(self, value: Any, field_name: str = "") -> str:
        """드리프트 변경 값의 짧은 포맷 (before→after 표시용)."""
        formatted = _format_value(field_name, value)
        # 트리에서는 한 줄로 표시 (줄바꿈 → 공백)
        formatted = formatted.replace("\n", " ").strip()
        if len(formatted) > 80:
            formatted = formatted[:77] + "..."
        return html_escape(formatted)

    # ── Kakao Talk Preview ────────────────────────────────────────────

    def _render_kakao_preview(self, r: DriftE2ETestResult) -> str:
        """카카오톡 알림 미리보기 (as-was / as-is 포함)."""
        if not r.actual_has_drift:
            return ""

        title = f"⚠️ 설정 드리프트: {r.resource_type}/{r.resource_id}"

        # Build body: intro + as-was/as-is per field
        lines = [
            f"{r.actual_drift_count}건의 설정 변경이 탐지되었습니다.",
            "",
        ]
        for df in r.actual_drift_fields:
            field_name = df.get("field_name", "")
            baseline_fmt = _format_value(field_name, df.get("baseline_value"))
            current_fmt = _format_value(field_name, df.get("current_value"))
            lines.append(f"⚠️ {field_name}")
            lines.append(f"  AS-WAS: {baseline_fmt}")
            lines.append(f"  AS-IS : {current_fmt}")
            lines.append("")

        sev_korean = {"critical": "심각", "high": "높음", "medium": "보통", "low": "낮음"}.get(
            r.actual_severity.lower(), r.actual_severity
        )
        ts_text = f" | 탐지: {r.detection_timestamp}" if r.detection_timestamp else ""
        lines.append(f"[심각도: {sev_korean}{ts_text}]")

        kakao_body = "\n".join(lines)

        return f"""
        <div class="kakao-section">
            <h4>{self._icon('chat', size='xs', inline=True)} 카카오톡 알림 미리보기</h4>
            <div class="kakao-preview">
                <div class="kakao-bubble">
                    <div class="kakao-title">{html_escape(title)}</div>
                    <div class="kakao-divider"></div>
                    <div class="kakao-content">{html_escape(kakao_body).replace(chr(10), '<br>')}</div>
                </div>
            </div>
        </div>
        """

