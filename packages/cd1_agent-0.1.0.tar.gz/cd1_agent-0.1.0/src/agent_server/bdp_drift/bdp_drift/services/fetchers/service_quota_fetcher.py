"""
Service Quota Config Fetcher.

AWS Service Quotas API를 사용하여 서비스별 할당량 한도를 조회합니다.
서비스별 개별 리소스 타입(quota-emr, quota-sagemaker 등)으로 분리되어 동작합니다.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from botocore.config import Config

from ..config_fetcher import BaseConfigFetcher, ResourceConfig, STSCredentials

logger = logging.getLogger(__name__)
config = Config(
    connect_timeout=5,
    read_timeout=30,
    retries={"max_attempts": 3, "mode": "adaptive"},
)

# 서비스별 quota 설정: resource_type → {check_item_key: (service_code, quota_code)}
SERVICE_QUOTA_CONFIGS: Dict[str, Dict[str, tuple]] = {
    "quota-emr": {
        "active_clusters": ("elasticmapreduce", "L-1EE7982C"),
        "active_instances_per_group": ("elasticmapreduce", "L-77B909B1"),
    },
    "quota-sagemaker": {
        "endpoints": ("sagemaker", "L-7A3DF611"),
        "training_jobs": ("sagemaker", "L-05296BBE"),
        "processing_jobs": ("sagemaker", "L-C50F9B9A"),
        "notebook_instances": ("sagemaker", "L-04153568"),
        "models": ("sagemaker", "L-4169PA60"),
    },
    "quota-glue": {
        "concurrent_job_runs": ("glue", "L-5E3AF21B"),
        "crawlers_per_account": ("glue", "L-FFA07E67"),
        "jobs_per_account": ("glue", "L-A245EDAB"),
        "triggers_per_account": ("glue", "L-D1E55B7C"),
        "dpus_per_account": ("glue", "L-2A2191FC"),
        "concurrent_crawlers": ("glue", "L-1F5A463E"),
    },
    "quota-athena": {
        "active_ddl_queries": ("athena", "L-FC5F8B07"),
        "active_dml_queries": ("athena", "L-E1E97568"),
        "query_timeout": ("athena", "L-3CE0BBA0"),
    },
    "quota-lambda": {
        "concurrent_executions": ("lambda", "L-B99A9384"),
        "function_storage": ("lambda", "L-2ACBD22F"),
        "elastic_network_interfaces": ("lambda", "L-9FEE3D26"),
    },
    "quota-s3": {
        "buckets_per_account": ("s3", "L-DC2B2D3D"),
        "access_points": ("s3", "L-FAABEEBA"),
        "multi_region_access_points": ("s3", "L-4D8917B2"),
    },
    "quota-msk": {
        "clusters_per_account": ("kafka", "L-4B412FFD"),
        "brokers_per_cluster": ("kafka", "L-CFCADFE2"),
        "configurations": ("kafka", "L-E08AFFAC"),
    },
    "quota-mwaa": {
        "environments_per_account": ("airflow", "L-F072B520"),
        "workers_per_environment": ("airflow", "L-297E5649"),
    },
    "quota-eks": {
        "clusters_per_region": ("eks", "L-1194D53C"),
        "managed_node_groups": ("eks", "L-6B80B8FA"),
        "fargate_profiles": ("eks", "L-33415B72"),
        "nodes_per_managed_group": ("eks", "L-BD136A63"),
    },
}

# 서비스별 mock 값
_MOCK_VALUES: Dict[str, Dict[str, Any]] = {
    "quota-emr": {
        "active_clusters": 500,
        "active_instances_per_group": 2000,
    },
    "quota-sagemaker": {
        "endpoints": 4,
        "training_jobs": 100,
        "processing_jobs": 100,
        "notebook_instances": 100,
        "models": 5000,
    },
    "quota-glue": {
        "concurrent_job_runs": 200,
        "crawlers_per_account": 1000,
        "jobs_per_account": 1000,
        "triggers_per_account": 500,
        "dpus_per_account": 1000,
        "concurrent_crawlers": 30,
    },
    "quota-athena": {
        "active_ddl_queries": 20,
        "active_dml_queries": 100,
        "query_timeout": 30,
    },
    "quota-lambda": {
        "concurrent_executions": 1000,
        "function_storage": 75,
        "elastic_network_interfaces": 250,
    },
    "quota-s3": {
        "buckets_per_account": 100,
        "access_points": 10000,
        "multi_region_access_points": 100,
    },
    "quota-msk": {
        "clusters_per_account": 100,
        "brokers_per_cluster": 30,
        "configurations": 100,
    },
    "quota-mwaa": {
        "environments_per_account": 10,
        "workers_per_environment": 25,
    },
    "quota-eks": {
        "clusters_per_region": 100,
        "managed_node_groups": 30,
        "fargate_profiles": 10,
        "nodes_per_managed_group": 450,
    },
}


class ServiceQuotaConfigFetcher(BaseConfigFetcher):
    """AWS Service Quotas 설정 조회기.

    서비스별 개별 리소스 타입(quota-emr 등)에 대해 할당량 한도를 조회합니다.
    """

    def __init__(
        self,
        resource_type: str,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
    ):
        self.resource_type = resource_type
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3

            if self.credentials:
                self._client = boto3.client(
                    "service-quotas", config=config, **self.credentials.to_boto3_kwargs()
                )
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("service-quotas")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """해당 서비스의 quota 한도값 조회.

        Args:
            resource_id: 계정 식별자 (통상 "default")
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        quota_mapping = SERVICE_QUOTA_CONFIGS.get(self.resource_type, {})
        if not quota_mapping:
            logger.warning(f"No quota config for resource type: {self.resource_type}")
            return None

        try:
            quota_config: Dict[str, Any] = {}

            for key, (service_code, quota_code) in quota_mapping.items():
                try:
                    response = self.client.get_service_quota(
                        ServiceCode=service_code,
                        QuotaCode=quota_code,
                    )
                    quota = response.get("Quota", {})
                    quota_config[key] = quota.get("Value")
                except Exception as e:
                    logger.warning(f"Failed to fetch quota {key} ({service_code}/{quota_code}): {e}")
                    quota_config[key] = None

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=None,
                config=quota_config,
            )
        except Exception as e:
            logger.error(f"Failed to fetch Service Quota config for {self.resource_type}/{resource_id}: {e}")
            return None

    def list_resources(self) -> List[str]:
        """계정 수준 quota이므로 "default" 반환."""
        return ["default"]

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 quota 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            result = self.fetch_config(resource_id)
            if result:
                configs.append(result)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        mock_values = _MOCK_VALUES.get(self.resource_type, {})

        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=None,
            config=mock_values,
        )
