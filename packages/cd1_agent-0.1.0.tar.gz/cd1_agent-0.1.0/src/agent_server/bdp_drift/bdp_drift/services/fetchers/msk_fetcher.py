"""
MSK Config Fetcher.

MSK(Managed Streaming for Apache Kafka) 클러스터 설정 조회기.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from botocore.config import Config

from ..config_fetcher import BaseConfigFetcher, ResourceConfig, STSCredentials
from ..models import ResourceType

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class MSKConfigFetcher(BaseConfigFetcher):
    """MSK 클러스터 설정 조회기.

    Severity Mapping:
    - kafka_version: HIGH
    - number_of_brokers: MEDIUM
    - instance_type: HIGH
    - ebs_volume_size: MEDIUM
    - encryption_in_transit: CRITICAL
    - encryption_at_rest: CRITICAL
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.MSK.value

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("kafka", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("kafka")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """MSK 클러스터 설정 조회.

        Args:
            resource_id: 클러스터 ARN 또는 이름

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            # resource_id가 ARN인지 이름인지 확인
            if resource_id.startswith("arn:"):
                cluster_arn = resource_id
            else:
                # 이름으로 클러스터 찾기
                clusters = self.client.list_clusters_v2()
                cluster_arn = None
                for cluster in clusters.get("ClusterInfoList", []):
                    if cluster.get("ClusterName") == resource_id:
                        cluster_arn = cluster.get("ClusterArn")
                        break
                if not cluster_arn:
                    logger.warning(f"MSK cluster not found: {resource_id}")
                    return None

            # 클러스터 상세 정보 조회
            response = self.client.describe_cluster_v2(ClusterArn=cluster_arn)
            cluster_info = response.get("ClusterInfo", {})

            # Provisioned vs Serverless 분기
            provisioned = cluster_info.get("Provisioned", {})
            serverless = cluster_info.get("Serverless", {})

            if provisioned:
                config_data = self._extract_provisioned_config(cluster_info, provisioned)
            else:
                config_data = self._extract_serverless_config(cluster_info, serverless)

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=cluster_arn,
                config=config_data,
            )

        except Exception as e:
            logger.error(f"Failed to fetch MSK config for {resource_id}: {e}")
            return None

    def _extract_provisioned_config(
        self,
        cluster_info: Dict[str, Any],
        provisioned: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Provisioned 클러스터 설정 추출."""
        broker_info = provisioned.get("BrokerNodeGroupInfo", {})
        encryption = provisioned.get("EncryptionInfo", {})
        encryption_in_transit = encryption.get("EncryptionInTransit", {})
        encryption_at_rest = encryption.get("EncryptionAtRest", {})

        return {
            "cluster_name": cluster_info.get("ClusterName"),
            "cluster_type": cluster_info.get("ClusterType", "PROVISIONED"),
            "state": cluster_info.get("State"),
            "kafka_version": provisioned.get("CurrentBrokerSoftwareInfo", {}).get("KafkaVersion"),
            "number_of_brokers": provisioned.get("NumberOfBrokerNodes"),
            "instance_type": broker_info.get("InstanceType"),
            "ebs_volume_size": broker_info.get("StorageInfo", {}).get("EbsStorageInfo", {}).get("VolumeSize"),
            "security_groups": broker_info.get("SecurityGroups", []),
            "client_subnets": broker_info.get("ClientSubnets", []),
            "encryption_in_transit": {
                "client_broker": encryption_in_transit.get("ClientBroker"),
                "in_cluster": encryption_in_transit.get("InCluster"),
            },
            "encryption_at_rest": {
                "kms_key_arn": encryption_at_rest.get("DataVolumeKMSKeyId"),
            },
            "enhanced_monitoring": provisioned.get("EnhancedMonitoring"),
            "open_monitoring": provisioned.get("OpenMonitoring", {}).get("Prometheus", {}),
            "logging_info": provisioned.get("LoggingInfo", {}),
        }

    def _extract_serverless_config(
        self,
        cluster_info: Dict[str, Any],
        serverless: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Serverless 클러스터 설정 추출."""
        vpc_configs = serverless.get("VpcConfigs", [])

        return {
            "cluster_name": cluster_info.get("ClusterName"),
            "cluster_type": cluster_info.get("ClusterType", "SERVERLESS"),
            "state": cluster_info.get("State"),
            "vpc_configs": [
                {
                    "subnet_ids": vc.get("SubnetIds", []),
                    "security_group_ids": vc.get("SecurityGroupIds", []),
                }
                for vc in vpc_configs
            ],
            "client_authentication": serverless.get("ClientAuthentication", {}),
        }

    def list_resources(self) -> List[str]:
        """MSK 클러스터 목록 조회."""
        if self.use_mock:
            return ["mock-msk-cluster-1", "mock-msk-cluster-2"]

        resources = []
        try:
            paginator = self.client.get_paginator("list_clusters_v2")
            for page in paginator.paginate():
                for cluster in page.get("ClusterInfoList", []):
                    resources.append(cluster.get("ClusterName"))
        except Exception as e:
            logger.error(f"Failed to list MSK clusters: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 MSK 클러스터 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=f"arn:aws:kafka:ap-northeast-2:123456789012:cluster/{resource_id}/mock-uuid",
            config={
                "cluster_name": resource_id,
                "cluster_type": "PROVISIONED",
                "state": "ACTIVE",
                "kafka_version": "2.8.1",
                "number_of_brokers": 3,
                "instance_type": "kafka.m5.large",
                "ebs_volume_size": 100,
                "security_groups": ["sg-12345678"],
                "client_subnets": ["subnet-11111111", "subnet-22222222", "subnet-33333333"],
                "encryption_in_transit": {
                    "client_broker": "TLS",
                    "in_cluster": True,
                },
                "encryption_at_rest": {
                    "kms_key_arn": "arn:aws:kms:ap-northeast-2:123456789012:key/mock-key",
                },
                "enhanced_monitoring": "PER_BROKER",
                "open_monitoring": {},
                "logging_info": {},
            },
        )
