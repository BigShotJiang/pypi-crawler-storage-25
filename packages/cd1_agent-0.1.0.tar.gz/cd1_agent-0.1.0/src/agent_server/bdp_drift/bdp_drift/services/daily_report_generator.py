"""
Daily Report Generator for BDP Drift Agent.

드리프트 일일 리포트를 단일 HTML 파일로 생성합니다.
모노톤 Material Design 스타일, 심각도 분포, 리소스 타입별 현황,
드리프트 상세 포함.
"""

import json
import logging
from collections import Counter, defaultdict
from datetime import datetime
from html import escape as html_escape
from typing import Any, Dict, List

from src.common.timezone import get_kst_now

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)


def _format_value(field_name: str, value: Any) -> str:
    """드리프트 값을 사람이 읽기 쉽게 정제."""
    if value is None:
        return "미설정"
    if isinstance(value, bool):
        return "활성화" if value else "비활성화"
    if isinstance(value, (int, float)):
        fn = field_name.lower()
        if "memory" in fn or "volume_size" in fn or "ebs_volume" in fn:
            return f"{value:,} MB"
        if "timeout" in fn:
            return f"{value}초"
        if any(k in fn for k in ["count", "capacity", "workers", "brokers", "nodes"]):
            return f"{value}개"
        return f"{value:,}" if isinstance(value, int) and value >= 1000 else str(value)
    if isinstance(value, str):
        if value.startswith("arn:aws:"):
            if "/" in value:
                return value.rsplit("/", 1)[-1]
            # arn:aws:lambda:region:acct:layer:name:ver → layer:name:ver
            segments = value.split(":")
            if len(segments) >= 7:
                return ":".join(segments[5:])
            return segments[-1]
        return value
    if isinstance(value, dict):
        if not value:
            return "빈 설정"
        lines = []
        for k, v in value.items():
            if isinstance(v, bool):
                v_str = "활성화" if v else "비활성화"
            elif v is None:
                v_str = "미설정"
            else:
                v_str = str(v)
                if len(v_str) > 50:
                    v_str = v_str[:47] + "..."
            lines.append(f"  {k}: {v_str}")
        return "\n".join(lines)
    if isinstance(value, list):
        if not value:
            return "빈 목록"
        n = len(value)
        if all(isinstance(item, str) for item in value):
            def _short_arn(s):
                if not s.startswith("arn:aws:"):
                    return s
                return _format_value("", s)
            if n <= 3 and all(len(s) < 60 for s in value):
                return ", ".join(_short_arn(s) for s in value)
            short = [_short_arn(s) for s in value[:2]]
            return f"{', '.join(short)} 외 {n - 2}건" if n > 2 else ", ".join(short)
        if all(isinstance(item, dict) for item in value):
            lines = [f"{n}건:"]
            for i, item in enumerate(value[:3]):
                parts = [f"{k}={v}" for k, v in list(item.items())[:3]]
                lines.append(f"  [{i+1}] {', '.join(parts)}")
            if n > 3:
                lines.append(f"  ... 외 {n - 3}건")
            return "\n".join(lines)
        return f"{n}개 항목"
    return str(value)

# 리소스 타입 한글 매핑
RESOURCE_TYPE_KOREAN = {
    "glue": "Glue 카탈로그",
    "athena": "Athena 워크그룹",
    "emr": "EMR 클러스터",
    "sagemaker": "SageMaker",
    "sagemaker-pipeline": "SageMaker 파이프라인",
    "sagemaker-endpoint": "SageMaker 엔드포인트",
    "sagemaker-model": "SageMaker 모델",
    "s3": "S3 버킷",
    "mwaa": "MWAA 환경",
    "msk": "MSK 클러스터",
    "lambda": "Lambda 함수",
    "vpc-sg": "VPC 보안그룹",
    "eks": "EKS 노드그룹",
}

RESOURCE_ICON = {
    "glue": "folder_data",
    "athena": "query_stats",
    "emr": "bolt",
    "sagemaker": "smart_toy",
    "sagemaker-pipeline": "smart_toy",
    "sagemaker-endpoint": "smart_toy",
    "sagemaker-model": "smart_toy",
    "s3": "inventory_2",
    "mwaa": "air",
    "msk": "stream",
    "lambda": "function",
    "vpc-sg": "shield",
    "eks": "cloud",
}

SEVERITY_KOREAN = {
    "critical": "심각",
    "high": "높음",
    "medium": "보통",
    "low": "낮음",
}

# 모노톤 베이스 + 최소 구분 컬러
MONO = {
    "header_start": "#37474F",
    "header_end": "#546E7A",
    "critical": "#C62828",
    "critical_bg": "#FFEBEE",
    "high": "#E65100",
    "high_bg": "#FFF3E0",
    "medium": "#546E7A",
    "medium_bg": "#ECEFF1",
    "low": "#90A4AE",
    "low_bg": "#F5F5F5",
    "text": "#263238",
    "text_secondary": "#78909C",
    "border": "#CFD8DC",
    "surface": "#FFFFFF",
    "bg": "#ECEFF1",
    "accent": "#455A64",
    "success": "#2E7D32",
    "danger": "#C62828",
}


class DriftDailyReportGenerator(HTMLReportBase):
    """BDP 드리프트 에이전트 일일 리포트 생성기 (모노톤)."""

    def __init__(self):
        super().__init__(
            title="BDP 드리프트 일일 리포트",
            styles=ReportStyles(),
        )

    # ── HTML Wrapper ──────────────────────────────────────────────

    def _wrap_html(self, content: str) -> str:
        timestamp = get_kst_now().strftime("%Y-%m-%d %H:%M:%S KST")
        report_date = get_kst_now().strftime("%Y-%m-%d")
        return f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title} - {report_date}</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        {self.styles.get_base_css()}
        {self._get_icon_css()}
        {self._get_daily_css()}
    </style>
</head>
<body>
    <div class="header daily-header">
        <div class="container">
            <h1 class="header-title">
                {self._icon('shield', size='lg', color='on-surface', inline=True)}
                {self.title}
            </h1>
            <p class="header-subtitle">{report_date} | {timestamp}</p>
        </div>
    </div>
    <div class="container">
        {content}
    </div>
</body>
</html>"""

    def _get_daily_css(self) -> str:
        return f"""
        .daily-header {{
            background: linear-gradient(135deg, {MONO['header_start']} 0%, {MONO['header_end']} 100%);
            color: white; padding: 32px 0;
        }}
        .daily-header .header-title {{ color: white; font-size: 28px; }}
        .daily-header .header-subtitle {{ color: rgba(255,255,255,0.6); }}
        .grid-5 {{ grid-template-columns: repeat(5, 1fr); }}
        @media (max-width: 768px) {{ .grid-5 {{ grid-template-columns: repeat(2, 1fr); }} }}

        /* Severity Distribution Bars */
        .sev-bar-row {{ display: flex; align-items: center; gap: 12px; padding: 10px 0; }}
        .sev-bar-label {{ min-width: 80px; font-size: 14px; font-weight: 600; }}
        .sev-bar-track {{ flex: 1; height: 28px; background: {MONO['bg']}; border-radius: 6px; overflow: hidden; border: 1px solid {MONO['border']}; }}
        .sev-bar-fill {{ height: 100%; border-radius: 5px; display: flex; align-items: center; padding-left: 10px; font-size: 12px; font-weight: 600; color: white; transition: width 0.5s ease; min-width: 0; }}
        .sev-bar-stat {{ min-width: 100px; text-align: right; font-size: 13px; color: {MONO['text_secondary']}; }}

        /* Resource Type Table */
        .rtbl {{ width: 100%; border-collapse: collapse; }}
        .rtbl th, .rtbl td {{ padding: 12px 16px; text-align: left; border-bottom: 1px solid {MONO['border']}; font-size: 14px; }}
        .rtbl th {{ background: {MONO['bg']}; font-weight: 600; font-size: 13px; color: {MONO['text_secondary']}; text-transform: uppercase; letter-spacing: 0.5px; }}
        .rtbl tr:hover {{ background: {MONO['bg']}; }}
        .rtbl .num {{ text-align: center; font-variant-numeric: tabular-nums; }}
        .res-icon {{ display: inline-flex; align-items: center; gap: 6px; }}

        /* Severity Badges (mono) */
        .mono-badge {{
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.3px;
            text-transform: uppercase;
        }}
        .mono-badge-critical {{ background: {MONO['critical']}; color: #fff; }}
        .mono-badge-high {{ background: {MONO['high']}; color: #fff; }}
        .mono-badge-medium {{ background: {MONO['medium']}; color: #fff; }}
        .mono-badge-low {{ background: {MONO['low']}; color: #fff; }}

        /* Drift Detail Cards */
        .drift-card {{ background: {MONO['surface']}; border: 1px solid {MONO['border']}; border-radius: 8px; margin-bottom: 16px; overflow: hidden; }}
        .drift-card.severity-critical {{ border-left: 5px solid {MONO['critical']}; }}
        .drift-card.severity-high {{ border-left: 5px solid {MONO['high']}; }}
        .drift-card.severity-medium {{ border-left: 5px solid {MONO['medium']}; }}
        .drift-card.severity-low {{ border-left: 5px solid {MONO['low']}; }}
        .drift-card-header {{ padding: 16px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid {MONO['border']}; }}
        .drift-card-title {{ flex: 1; }}
        .drift-card-title h3 {{ font-size: 15px; font-weight: 600; margin-bottom: 2px; color: {MONO['text']}; }}
        .drift-card-title .resource-info {{ font-size: 12px; color: {MONO['text_secondary']}; }}
        .drift-card-body {{ padding: 12px 16px 16px; }}

        .field-item {{ padding: 10px 12px; margin: 6px 0; border-radius: 6px; font-size: 13px; border-left: 3px solid; }}
        .field-item.critical {{ border-color: {MONO['critical']}; background: {MONO['critical_bg']}; }}
        .field-item.high {{ border-color: {MONO['high']}; background: {MONO['high_bg']}; }}
        .field-item.medium {{ border-color: {MONO['medium']}; background: {MONO['medium_bg']}; }}
        .field-item.low {{ border-color: {MONO['low']}; background: {MONO['low_bg']}; }}
        .field-name {{ font-weight: 600; margin-bottom: 4px; color: {MONO['text']}; }}
        .field-values {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px; margin-top: 6px; }}
        .field-val-label {{ color: {MONO['text_secondary']}; font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.3px; margin-right: 6px; }}
        .field-val-label::after {{ content: ": "; }}
        .field-val {{ word-break: break-all; color: {MONO['text']}; }}
        .field-val-was {{ word-break: break-all; color: {MONO['text_secondary']}; text-decoration: line-through; opacity: 0.75; }}
        .field-val-is {{ word-break: break-all; font-weight: 600; color: {MONO['high']}; }}
        .field-impact {{ font-size: 12px; color: {MONO['text_secondary']}; margin-top: 6px; padding-top: 6px; border-top: 1px dashed {MONO['border']}; }}

        /* No Drift Banner */
        .no-drift-banner {{ text-align: center; padding: 40px; color: {MONO['text_secondary']}; }}
        .no-drift-banner .banner-icon {{ font-size: 48px; }}
        .no-drift-banner .banner-text {{ font-size: 18px; font-weight: 600; margin-top: 12px; }}
        """

    # ── Content Generation ────────────────────────────────────────

    def generate_content(self, data: List) -> str:
        """리포트 콘텐츠 생성.

        Args:
            data: List[DriftResult] 드리프트 탐지 결과 목록
        """
        results = data
        drifted = [r for r in results if r.has_drift]

        sections = []
        sections.append(self._generate_summary_dashboard(results, drifted))
        sections.append(self._generate_severity_distribution(drifted))
        sections.append(self._generate_resource_type_table(results, drifted))

        if drifted:
            sections.append(self._generate_drift_details(drifted))
        else:
            sections.append(self._generate_no_drift_banner())

        return "\n".join(sections)

    # ── Summary Dashboard ─────────────────────────────────────────

    def _generate_summary_dashboard(self, results: List, drifted: List) -> str:
        total = len(results)
        drift_count = len(drifted)
        normal_count = total - drift_count
        critical_high = sum(
            1 for r in drifted if r.severity.value in ("critical", "high")
        )
        avg_fields = (
            sum(r.drift_count for r in drifted) / drift_count if drift_count else 0
        )

        stats = [
            {"label": "전체 리소스", "value": str(total), "color": MONO["text"]},
            {"label": "드리프트 탐지", "value": str(drift_count), "color": MONO["danger"] if drift_count else MONO["success"]},
            {"label": "정상", "value": str(normal_count), "color": MONO["success"]},
            {"label": "심각/높음", "value": str(critical_high), "color": MONO["danger"] if critical_high else MONO["text_secondary"]},
            {"label": "평균 필드 변경", "value": f"{avg_fields:.1f}", "color": MONO["text_secondary"]},
        ]
        return self.render_stat_cards(stats, columns=5)

    # ── Severity Distribution ─────────────────────────────────────

    def _generate_severity_distribution(self, drifted: List) -> str:
        severity_counts = Counter(r.severity.value for r in drifted)
        total = len(drifted) if drifted else 1

        severity_config = {
            "critical": {"color": MONO["critical"], "label": "CRITICAL"},
            "high": {"color": MONO["high"], "label": "HIGH"},
            "medium": {"color": MONO["medium"], "label": "MEDIUM"},
            "low": {"color": MONO["low"], "label": "LOW"},
        }

        bars = []
        for sev in ["critical", "high", "medium", "low"]:
            count = severity_counts.get(sev, 0)
            cfg = severity_config[sev]
            pct = (count / total * 100) if total > 0 else 0
            width = max(pct, 2) if count > 0 else 0
            bars.append(f"""
            <div class="sev-bar-row">
                <div class="sev-bar-label" style="color:{cfg['color']}">{cfg['label']}</div>
                <div class="sev-bar-track">
                    <div class="sev-bar-fill" style="width:{width}%; background:{cfg['color']};">{count if count else ''}</div>
                </div>
                <div class="sev-bar-stat">{count}건 ({pct:.0f}%)</div>
            </div>""")

        return self.render_card(
            f"{self._icon('bar_chart', size='sm', inline=True)} 심각도 분포",
            "\n".join(bars),
        )

    # ── Resource Type Table ───────────────────────────────────────

    def _generate_resource_type_table(self, results: List, drifted: List) -> str:
        by_type_all: Dict[str, List] = defaultdict(list)
        by_type_drift: Dict[str, List] = defaultdict(list)
        for r in results:
            by_type_all[r.resource_type].append(r)
        for r in drifted:
            by_type_drift[r.resource_type].append(r)

        rows = []
        for rtype in sorted(by_type_all.keys()):
            type_results = by_type_all[rtype]
            type_drifts = by_type_drift.get(rtype, [])
            icon_name = RESOURCE_ICON.get(rtype, "cloud")
            type_korean = RESOURCE_TYPE_KOREAN.get(rtype, rtype)
            total_scanned = len(type_results)
            drifted_count = len(type_drifts)

            # Max severity
            if type_drifts:
                sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
                max_sev = min(type_drifts, key=lambda r: sev_order.get(r.severity.value, 99))
                max_sev_badge = self._mono_badge(max_sev.severity.value)
            else:
                max_sev_badge = f'<span style="color:{MONO["success"]}; font-weight:500;">정상</span>'

            # Top changed fields
            field_counter: Counter = Counter()
            for r in type_drifts:
                for f in r.drift_fields:
                    field_counter[f.field_name] += 1
            top_fields = ", ".join(f[0] for f in field_counter.most_common(3)) or "-"

            rows.append(f"""<tr>
                <td><span class="res-icon">{self._icon(icon_name, size='sm', inline=True)} {html_escape(type_korean)}</span></td>
                <td class="num">{total_scanned}</td>
                <td class="num" style="font-weight:600; color:{MONO['danger'] if drifted_count else MONO['success']};">{drifted_count}</td>
                <td>{max_sev_badge}</td>
                <td style="font-size:12px; color:{MONO['text_secondary']};">{html_escape(top_fields)}</td>
            </tr>""")

        table_html = f"""<div style="overflow-x:auto;">
        <table class="rtbl">
            <thead><tr>
                <th>리소스 타입</th>
                <th style="text-align:center;">스캔</th>
                <th style="text-align:center;">드리프트</th>
                <th>최대 심각도</th>
                <th>주요 변경 필드</th>
            </tr></thead>
            <tbody>{''.join(rows)}</tbody>
        </table></div>"""

        return self.render_card(
            f"{self._icon('category', size='sm', inline=True)} 리소스 타입별 현황",
            table_html,
        )

    # ── Drift Detail Cards ────────────────────────────────────────

    def _generate_drift_details(self, drifted: List) -> str:
        sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sorted_drifts = sorted(drifted, key=lambda r: sev_order.get(r.severity.value, 99))

        cards = []
        for r in sorted_drifts:
            sev = r.severity.value
            type_korean = RESOURCE_TYPE_KOREAN.get(r.resource_type, r.resource_type)
            icon_name = RESOURCE_ICON.get(r.resource_type, "cloud")
            sev_badge = self._mono_badge(sev)

            field_items = []
            for f in r.drift_fields:
                f_sev = f.severity.value
                baseline_str = _format_value(f.field_name, f.baseline_value)
                current_str = _format_value(f.field_name, f.current_value)

                impact_html = ""
                if f.impact or f.recommendation:
                    parts = []
                    if f.impact:
                        parts.append(f"{self._icon('priority_high', size='xs', inline=True)} {html_escape(f.impact)}")
                    if f.recommendation:
                        parts.append(f"{self._icon('lightbulb', size='xs', inline=True)} {html_escape(f.recommendation)}")
                    impact_html = f'<div class="field-impact">{"<br>".join(parts)}</div>'

                baseline_html = html_escape(baseline_str).replace("\n", "<br>")
                current_html = html_escape(current_str).replace("\n", "<br>")
                field_items.append(f"""
                <div class="field-item {f_sev}">
                    <div class="field-name">{html_escape(f.field_name)} {self._mono_badge(f_sev)}</div>
                    <div class="field-values">
                        <div><span class="field-val-label">AS-WAS</span><span class="field-val-was">{baseline_html}</span></div>
                        <div><span class="field-val-label">AS-IS</span><span class="field-val-is">{current_html}</span></div>
                    </div>
                    {impact_html}
                </div>""")

            cards.append(f"""
            <div class="drift-card severity-{sev}">
                <div class="drift-card-header">
                    {self._icon(icon_name, size='md', inline=True)}
                    <div class="drift-card-title">
                        <h3>{html_escape(type_korean)} / {html_escape(r.resource_id)}</h3>
                        <div class="resource-info">{f'탐지: {r.detection_timestamp.strftime("%Y-%m-%d %H:%M:%S")} | ' if r.detection_timestamp else ''}{r.drift_count}건 드리프트 탐지 | ARN: {html_escape(r.resource_arn or 'N/A')}</div>
                    </div>
                    {sev_badge}
                </div>
                <div class="drift-card-body">
                    {''.join(field_items)}
                </div>
            </div>""")

        return self.render_card(
            f"{self._icon('search', size='sm', inline=True)} 주요 드리프트 상세 ({len(drifted)}건)",
            "\n".join(cards),
        )

    def _generate_no_drift_banner(self) -> str:
        return self.render_card(
            f"{self._icon('check_circle', size='sm', inline=True)} 드리프트 상세",
            f"""<div class="no-drift-banner">
                <div class="banner-icon">{self._icon('check_circle', size='xl', filled=True, color='muted')}</div>
                <div class="banner-text">모든 리소스 설정이 베이스라인과 일치합니다</div>
            </div>""",
        )

    # ── Helpers ───────────────────────────────────────────────────

    def _mono_badge(self, severity: str) -> str:
        """모노톤 심각도 배지."""
        label = severity.upper()
        return f'<span class="mono-badge mono-badge-{severity}">{label}</span>'

    # ── DB 기반 HTML 재생성 ──────────────────────────────────────

    def generate_from_db(self, report) -> str:
        """DB에서 읽은 DriftReport 객체의 raw_drifts_json으로 HTML 재생성.

        Args:
            report: DriftReport (report_store.py의 dataclass)

        Returns:
            HTML 문자열
        """
        results = self.results_from_json(report.raw_drifts_json)
        return self.generate_report(results)

    @staticmethod
    def results_to_json(results: List) -> str:
        """List[DriftResult] → JSON 문자열."""
        return json.dumps(
            [r.to_dict() for r in results],
            ensure_ascii=False,
        )

    @staticmethod
    def results_from_json(json_str: str) -> List:
        """JSON 문자열 → List[DriftResult] 복원."""
        from .models import DriftResult

        if not json_str:
            return []
        data = json.loads(json_str)
        return [DriftResult.from_dict(d) for d in data]

