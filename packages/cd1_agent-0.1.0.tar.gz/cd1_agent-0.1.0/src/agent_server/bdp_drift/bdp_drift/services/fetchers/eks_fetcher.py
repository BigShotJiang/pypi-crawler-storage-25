"""
EKS NodeGroup Fetcher.

EKS 클러스터 및 NodeGroup 설정 조회기.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from botocore.config import Config

from ..config_fetcher import BaseConfigFetcher, ResourceConfig, STSCredentials
from ..models import ResourceType

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class EKSNodeGroupFetcher(BaseConfigFetcher):
    """EKS NodeGroup 설정 조회기.

    Severity Mapping:
    - kubernetes_version: HIGH
    - instance_types: HIGH
    - ami_type: MEDIUM
    - scaling_config: MEDIUM

    Note: K8s API (Pod/Deployment 수준)는 향후 별도 Layer로 구현 예정
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.EKS.value

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("eks", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("eks")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """EKS 클러스터 및 NodeGroup 설정 조회.

        Args:
            resource_id: 클러스터 이름 또는 "cluster_name/nodegroup_name" 형식

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            parts = resource_id.split("/")

            if len(parts) == 1:
                # 클러스터 레벨 조회
                return self._fetch_cluster_config(parts[0])
            else:
                # NodeGroup 레벨 조회
                return self._fetch_nodegroup_config(parts[0], parts[1])

        except Exception as e:
            logger.error(f"Failed to fetch EKS config for {resource_id}: {e}")
            return None

    def _fetch_cluster_config(self, cluster_name: str) -> Optional[ResourceConfig]:
        """EKS 클러스터 설정 조회."""
        response = self.client.describe_cluster(name=cluster_name)
        cluster = response.get("cluster", {})

        # 클러스터의 모든 NodeGroup 조회
        nodegroups_response = self.client.list_nodegroups(clusterName=cluster_name)
        nodegroup_names = nodegroups_response.get("nodegroups", [])

        nodegroups = []
        for ng_name in nodegroup_names:
            ng_response = self.client.describe_nodegroup(
                clusterName=cluster_name,
                nodegroupName=ng_name,
            )
            ng = ng_response.get("nodegroup", {})
            nodegroups.append(self._extract_nodegroup_config(ng))

        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=cluster_name,
            resource_arn=cluster.get("arn"),
            config={
                "cluster_name": cluster.get("name"),
                "kubernetes_version": cluster.get("version"),
                "platform_version": cluster.get("platformVersion"),
                "status": cluster.get("status"),
                "endpoint": cluster.get("endpoint"),
                "role_arn": cluster.get("roleArn"),
                "vpc_config": {
                    "subnet_ids": cluster.get("resourcesVpcConfig", {}).get("subnetIds", []),
                    "security_group_ids": cluster.get("resourcesVpcConfig", {}).get("securityGroupIds", []),
                    "cluster_security_group_id": cluster.get("resourcesVpcConfig", {}).get("clusterSecurityGroupId"),
                    "endpoint_public_access": cluster.get("resourcesVpcConfig", {}).get("endpointPublicAccess"),
                    "endpoint_private_access": cluster.get("resourcesVpcConfig", {}).get("endpointPrivateAccess"),
                    "public_access_cidrs": cluster.get("resourcesVpcConfig", {}).get("publicAccessCidrs", []),
                },
                "logging": cluster.get("logging", {}),
                "encryption_config": cluster.get("encryptionConfig", []),
                "nodegroups": nodegroups,
                "tags": cluster.get("tags", {}),
            },
        )

    def _fetch_nodegroup_config(
        self,
        cluster_name: str,
        nodegroup_name: str,
    ) -> Optional[ResourceConfig]:
        """EKS NodeGroup 설정 조회."""
        response = self.client.describe_nodegroup(
            clusterName=cluster_name,
            nodegroupName=nodegroup_name,
        )
        ng = response.get("nodegroup", {})

        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=f"{cluster_name}/{nodegroup_name}",
            resource_arn=ng.get("nodegroupArn"),
            config=self._extract_nodegroup_config(ng),
        )

    def _extract_nodegroup_config(self, ng: Dict[str, Any]) -> Dict[str, Any]:
        """NodeGroup 설정 추출."""
        scaling_config = ng.get("scalingConfig", {})

        return {
            "nodegroup_name": ng.get("nodegroupName"),
            "cluster_name": ng.get("clusterName"),
            "status": ng.get("status"),
            "kubernetes_version": ng.get("version"),
            "release_version": ng.get("releaseVersion"),
            "instance_types": ng.get("instanceTypes", []),
            "ami_type": ng.get("amiType"),
            "node_role": ng.get("nodeRole"),
            "scaling_config": {
                "min_size": scaling_config.get("minSize"),
                "max_size": scaling_config.get("maxSize"),
                "desired_size": scaling_config.get("desiredSize"),
            },
            "disk_size": ng.get("diskSize"),
            "subnets": ng.get("subnets", []),
            "remote_access": ng.get("remoteAccess", {}),
            "labels": ng.get("labels", {}),
            "taints": ng.get("taints", []),
            "launch_template": ng.get("launchTemplate", {}),
            "capacity_type": ng.get("capacityType"),
            "update_config": ng.get("updateConfig", {}),
            "tags": ng.get("tags", {}),
        }

    def list_resources(self) -> List[str]:
        """EKS 클러스터 목록 조회.

        클러스터 이름만 반환. NodeGroup은 클러스터 조회 시 포함됨.
        """
        if self.use_mock:
            return ["mock-eks-cluster-1", "mock-eks-cluster-2"]

        resources = []
        try:
            paginator = self.client.get_paginator("list_clusters")
            for page in paginator.paginate():
                resources.extend(page.get("clusters", []))
        except Exception as e:
            logger.error(f"Failed to list EKS clusters: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 EKS 클러스터 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        parts = resource_id.split("/")
        cluster_name = parts[0]

        if len(parts) == 1:
            # 클러스터 레벨 Mock
            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=f"arn:aws:eks:ap-northeast-2:123456789012:cluster/{cluster_name}",
                config={
                    "cluster_name": cluster_name,
                    "kubernetes_version": "1.28",
                    "platform_version": "eks.5",
                    "status": "ACTIVE",
                    "endpoint": f"https://{cluster_name}.eks.ap-northeast-2.amazonaws.com",
                    "role_arn": "arn:aws:iam::123456789012:role/eks-cluster-role",
                    "vpc_config": {
                        "subnet_ids": ["subnet-11111111", "subnet-22222222"],
                        "security_group_ids": ["sg-12345678"],
                        "cluster_security_group_id": "sg-cluster-12345",
                        "endpoint_public_access": False,
                        "endpoint_private_access": True,
                        "public_access_cidrs": [],
                    },
                    "logging": {
                        "clusterLogging": [
                            {"types": ["api", "audit"], "enabled": True}
                        ]
                    },
                    "encryption_config": [],
                    "nodegroups": [
                        {
                            "nodegroup_name": "default-nodegroup",
                            "cluster_name": cluster_name,
                            "status": "ACTIVE",
                            "kubernetes_version": "1.28",
                            "instance_types": ["m5.large"],
                            "ami_type": "AL2_x86_64",
                            "scaling_config": {
                                "min_size": 2,
                                "max_size": 10,
                                "desired_size": 3,
                            },
                        }
                    ],
                    "tags": {"Environment": "test"},
                },
            )
        else:
            # NodeGroup 레벨 Mock
            nodegroup_name = parts[1]
            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=f"arn:aws:eks:ap-northeast-2:123456789012:nodegroup/{cluster_name}/{nodegroup_name}/mock-uuid",
                config={
                    "nodegroup_name": nodegroup_name,
                    "cluster_name": cluster_name,
                    "status": "ACTIVE",
                    "kubernetes_version": "1.28",
                    "release_version": "1.28.1-20231106",
                    "instance_types": ["m5.large"],
                    "ami_type": "AL2_x86_64",
                    "node_role": "arn:aws:iam::123456789012:role/eks-node-role",
                    "scaling_config": {
                        "min_size": 2,
                        "max_size": 10,
                        "desired_size": 3,
                    },
                    "disk_size": 100,
                    "subnets": ["subnet-11111111", "subnet-22222222"],
                    "remote_access": {},
                    "labels": {"workload": "general"},
                    "taints": [],
                    "launch_template": {},
                    "capacity_type": "ON_DEMAND",
                    "update_config": {"maxUnavailable": 1},
                    "tags": {"Environment": "test"},
                },
            )
