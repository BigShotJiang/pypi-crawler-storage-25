"""
Drift Report Store - DB storage layer for drift reports.

드리프트 리포트 저장소.
Provider 패턴으로 MySQL/SQLite/Mock 지원.
"""

import json
import logging
import os
import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from src.agent_server.bdp_common.stores.base import KST, get_kst_now, BaseMySqlProvider, BaseSQLiteProvider

logger = logging.getLogger(__name__)


@dataclass
class DriftReport:
    """드리프트 탐지 리포트."""

    id: str
    run_timestamp: datetime
    total_resources: int
    total_drifts: int
    by_severity: Dict[str, int]
    html_report: str
    raw_drifts_json: str = ""
    status: str = "completed"


class DriftReportStoreProvider(ABC):
    """드리프트 리포트 저장소 추상 프로바이더."""

    @abstractmethod
    def ensure_tables(self) -> None:
        pass

    @abstractmethod
    def save_report(self, report: DriftReport) -> DriftReport:
        pass

    @abstractmethod
    def get_report(self, report_id: str) -> Optional[DriftReport]:
        pass

    @abstractmethod
    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[DriftReport]:
        pass

    @abstractmethod
    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        pass


class SQLiteProvider(BaseSQLiteProvider, DriftReportStoreProvider):
    """SQLite 프로바이더 (유닛 테스트용)."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS drift_reports (
                id TEXT PRIMARY KEY,
                run_timestamp TEXT NOT NULL,
                total_resources INTEGER NOT NULL,
                total_drifts INTEGER NOT NULL,
                by_severity TEXT NOT NULL,
                html_report TEXT NOT NULL,
                raw_drifts_json TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'completed',
                created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_drift_reports_timestamp
            ON drift_reports (run_timestamp)
        """)
        self.conn.commit()

    def save_report(self, report: DriftReport) -> DriftReport:
        cursor = self.conn.cursor()
        now = get_kst_now().isoformat() + "Z"
        cursor.execute(
            """
            INSERT INTO drift_reports
            (id, run_timestamp, total_resources, total_drifts, by_severity,
             html_report, raw_drifts_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                report.id,
                report.run_timestamp.isoformat() if isinstance(report.run_timestamp, datetime) else report.run_timestamp,
                report.total_resources,
                report.total_drifts,
                json.dumps(report.by_severity, ensure_ascii=False),
                report.html_report,
                report.raw_drifts_json,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[DriftReport]:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM drift_reports WHERE id = ?", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[DriftReport]:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)
        if severity:
            conditions.append(f"json_extract(by_severity, '$.{severity}') > 0")

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM drift_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM drift_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: sqlite3.Row) -> DriftReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))
        return DriftReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            total_resources=row["total_resources"],
            total_drifts=row["total_drifts"],
            by_severity=json.loads(row["by_severity"]),
            html_report=row["html_report"],
            raw_drifts_json=row["raw_drifts_json"] if "raw_drifts_json" in row.keys() else "",
            status=row["status"],
        )


class MySqlProvider(BaseMySqlProvider, DriftReportStoreProvider):
    """MySQL 드리프트 리포트 저장소."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS drift_reports (
                id VARCHAR(36) PRIMARY KEY,
                run_timestamp DATETIME NOT NULL,
                total_resources INT NOT NULL,
                total_drifts INT NOT NULL,
                by_severity JSON NOT NULL,
                html_report LONGTEXT NOT NULL,
                raw_drifts_json LONGTEXT NOT NULL DEFAULT '',
                status VARCHAR(20) NOT NULL DEFAULT 'completed',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_drift_reports_timestamp (run_timestamp)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        self.conn.commit()
        logger.info("MySQL drift_reports table ensured")

    def save_report(self, report: DriftReport) -> DriftReport:
        cursor = self.conn.cursor()
        now = get_kst_now()
        cursor.execute(
            """
            INSERT INTO drift_reports
            (id, run_timestamp, total_resources, total_drifts, by_severity,
             html_report, raw_drifts_json, status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                report.id,
                report.run_timestamp if isinstance(report.run_timestamp, datetime) else datetime.fromisoformat(report.run_timestamp),
                report.total_resources,
                report.total_drifts,
                json.dumps(report.by_severity, ensure_ascii=False),
                report.html_report,
                report.raw_drifts_json,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> Optional[DriftReport]:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM drift_reports WHERE id = %s", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[DriftReport]:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)
        if severity:
            conditions.append(f"JSON_EXTRACT(by_severity, '$.{severity}') > 0")

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM drift_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT %s OFFSET %s
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: List[str] = []
        params: List[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM drift_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: Dict[str, Any]) -> DriftReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))

        by_severity = row["by_severity"]
        if isinstance(by_severity, str):
            by_severity = json.loads(by_severity)

        return DriftReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            total_resources=row["total_resources"],
            total_drifts=row["total_drifts"],
            by_severity=by_severity,
            html_report=row["html_report"],
            raw_drifts_json=row.get("raw_drifts_json", ""),
            status=row["status"],
        )


class MockProvider(DriftReportStoreProvider):
    """Mock 프로바이더 (개발/테스트용)."""

    def __init__(self):
        self._reports: Dict[str, DriftReport] = {}
        logger.info("Mock drift report provider initialized")

    def ensure_tables(self) -> None:
        pass

    def save_report(self, report: DriftReport) -> DriftReport:
        self._reports[report.id] = report
        return report

    def get_report(self, report_id: str) -> Optional[DriftReport]:
        return self._reports.get(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[DriftReport]:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        if severity:
            reports = [r for r in reports if r.by_severity.get(severity, 0) > 0]
        reports.sort(key=lambda r: r.run_timestamp, reverse=True)
        return reports[offset:offset + limit]

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        return len(reports)


class DriftReportStore:
    """드리프트 리포트 저장소 (Facade).

    Provider 패턴으로 MySQL/SQLite/Mock 지원.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: Optional[str] = None,
        db: Optional[str] = None,
    ):
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)
        logger.info(f"DriftReportStore initialized with {provider} provider")

    def _create_provider(
        self, provider: str, secret_id: Optional[str] = None, db: Optional[str] = None
    ) -> DriftReportStoreProvider:
        if provider == "sqlite":
            db_path = os.getenv("REPORT_SQLITE_PATH", ":memory:")
            return SQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                raise ValueError("secret_id is required for MySQL provider")
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return MySqlProvider(secret_id=secret_id, db=db or "", region=region)
        else:
            return MockProvider()

    def ensure_tables(self) -> None:
        self._provider.ensure_tables()

    def save_report(self, report: DriftReport) -> DriftReport:
        return self._provider.save_report(report)

    def get_report(self, report_id: str) -> Optional[DriftReport]:
        return self._provider.get_report(report_id)

    def list_reports(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[DriftReport]:
        return self._provider.list_reports(
            start_date=start_date,
            end_date=end_date,
            severity=severity,
            limit=limit,
            offset=offset,
        )

    def get_report_count(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> int:
        return self._provider.get_report_count(
            start_date=start_date,
            end_date=end_date,
        )
