"""
SageMaker Fetchers.

SageMaker Pipeline, Endpoint, Model Registry 설정 조회기.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional

from botocore.config import Config

from ..config_fetcher import BaseConfigFetcher, ResourceConfig, STSCredentials
from ..models import ResourceType

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class SageMakerPipelineFetcher(BaseConfigFetcher):
    """SageMaker Pipeline 설정 조회기.

    Severity Mapping:
    - pipeline_definition: CRITICAL (DAG/Steps 변경)
    - role_arn: CRITICAL (권한 변경)
    - pipeline_status: HIGH (Active→Inactive)
    - max_parallel_steps: MEDIUM (병렬 실행 제한)
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.SAGEMAKER_PIPELINE.value

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("sagemaker", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("sagemaker")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """SageMaker Pipeline 설정 조회.

        Args:
            resource_id: Pipeline 이름

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            response = self.client.describe_pipeline(PipelineName=resource_id)

            # Pipeline Definition 조회 (JSON)
            pipeline_definition = None
            if response.get("PipelineDefinition"):
                try:
                    pipeline_definition = json.loads(response.get("PipelineDefinition", "{}"))
                except json.JSONDecodeError:
                    pipeline_definition = response.get("PipelineDefinition")

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=response.get("PipelineArn"),
                config={
                    "pipeline_name": response.get("PipelineName"),
                    "pipeline_display_name": response.get("PipelineDisplayName"),
                    "pipeline_status": response.get("PipelineStatus"),
                    "pipeline_definition": pipeline_definition,
                    "role_arn": response.get("RoleArn"),
                    "parallelism_configuration": response.get("ParallelismConfiguration", {}),
                    "creation_time": response.get("CreationTime").isoformat() if response.get("CreationTime") else None,
                    "last_modified_time": response.get("LastModifiedTime").isoformat() if response.get("LastModifiedTime") else None,
                    "created_by": response.get("CreatedBy", {}),
                    "last_modified_by": response.get("LastModifiedBy", {}),
                },
            )

        except Exception as e:
            logger.error(f"Failed to fetch SageMaker Pipeline config for {resource_id}: {e}")
            return None

    def list_resources(self) -> List[str]:
        """SageMaker Pipeline 목록 조회."""
        if self.use_mock:
            return ["mock-pipeline-1", "mock-pipeline-2"]

        resources = []
        try:
            paginator = self.client.get_paginator("list_pipelines")
            for page in paginator.paginate():
                for pipeline in page.get("PipelineSummaries", []):
                    resources.append(pipeline.get("PipelineName"))
        except Exception as e:
            logger.error(f"Failed to list SageMaker Pipelines: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 SageMaker Pipeline 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=f"arn:aws:sagemaker:ap-northeast-2:123456789012:pipeline/{resource_id}",
            config={
                "pipeline_name": resource_id,
                "pipeline_display_name": f"Mock Pipeline {resource_id}",
                "pipeline_status": "Active",
                "pipeline_definition": {
                    "Version": "2020-12-01",
                    "Steps": [
                        {
                            "Name": "ProcessingStep",
                            "Type": "Processing",
                        },
                        {
                            "Name": "TrainingStep",
                            "Type": "Training",
                        },
                    ],
                },
                "role_arn": "arn:aws:iam::123456789012:role/SageMakerExecutionRole",
                "parallelism_configuration": {"MaxParallelExecutionSteps": 10},
                "creation_time": "2024-01-01T00:00:00Z",
                "last_modified_time": "2024-01-15T12:00:00Z",
                "created_by": {},
                "last_modified_by": {},
            },
        )


class SageMakerEndpointFetcher(BaseConfigFetcher):
    """SageMaker Endpoint 설정 조회기.

    Severity Mapping:
    - production_variants.model_name: CRITICAL (배포 모델 변경)
    - production_variants.instance_type: HIGH (성능 변경)
    - endpoint_status: HIGH (InService→Failed)
    - data_capture_enabled: MEDIUM (모니터링 설정)
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.SAGEMAKER_ENDPOINT.value

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("sagemaker", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("sagemaker")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """SageMaker Endpoint 설정 조회.

        Args:
            resource_id: Endpoint 이름

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            # Endpoint 정보 조회
            endpoint_response = self.client.describe_endpoint(EndpointName=resource_id)

            # Endpoint Config 정보 조회
            endpoint_config_name = endpoint_response.get("EndpointConfigName")
            config_response = self.client.describe_endpoint_config(
                EndpointConfigName=endpoint_config_name
            )

            production_variants = []
            for pv in config_response.get("ProductionVariants", []):
                production_variants.append({
                    "variant_name": pv.get("VariantName"),
                    "model_name": pv.get("ModelName"),
                    "instance_type": pv.get("InstanceType"),
                    "initial_instance_count": pv.get("InitialInstanceCount"),
                    "initial_variant_weight": pv.get("InitialVariantWeight"),
                    "accelerator_type": pv.get("AcceleratorType"),
                    "serverless_config": pv.get("ServerlessConfig", {}),
                })

            # 현재 트래픽 분배 정보
            current_variants = []
            for pv in endpoint_response.get("ProductionVariants", []):
                current_variants.append({
                    "variant_name": pv.get("VariantName"),
                    "current_weight": pv.get("CurrentWeight"),
                    "desired_weight": pv.get("DesiredWeight"),
                    "current_instance_count": pv.get("CurrentInstanceCount"),
                    "desired_instance_count": pv.get("DesiredInstanceCount"),
                })

            # Data Capture Config
            data_capture_config = config_response.get("DataCaptureConfig", {})

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=endpoint_response.get("EndpointArn"),
                config={
                    "endpoint_name": endpoint_response.get("EndpointName"),
                    "endpoint_config_name": endpoint_config_name,
                    "endpoint_status": endpoint_response.get("EndpointStatus"),
                    "production_variants": production_variants,
                    "current_variants": current_variants,
                    "data_capture_enabled": data_capture_config.get("EnableCapture", False),
                    "data_capture_config": {
                        "capture_status": data_capture_config.get("CaptureStatus"),
                        "capture_percentage": data_capture_config.get("CurrentSamplingPercentage"),
                        "destination_s3_uri": data_capture_config.get("DestinationS3Uri"),
                    } if data_capture_config else None,
                    "creation_time": endpoint_response.get("CreationTime").isoformat() if endpoint_response.get("CreationTime") else None,
                    "last_modified_time": endpoint_response.get("LastModifiedTime").isoformat() if endpoint_response.get("LastModifiedTime") else None,
                    "kms_key_id": config_response.get("KmsKeyId"),
                },
            )

        except Exception as e:
            logger.error(f"Failed to fetch SageMaker Endpoint config for {resource_id}: {e}")
            return None

    def list_resources(self) -> List[str]:
        """SageMaker Endpoint 목록 조회."""
        if self.use_mock:
            return ["mock-endpoint-1", "mock-endpoint-2"]

        resources = []
        try:
            paginator = self.client.get_paginator("list_endpoints")
            for page in paginator.paginate():
                for endpoint in page.get("Endpoints", []):
                    resources.append(endpoint.get("EndpointName"))
        except Exception as e:
            logger.error(f"Failed to list SageMaker Endpoints: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 SageMaker Endpoint 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=f"arn:aws:sagemaker:ap-northeast-2:123456789012:endpoint/{resource_id}",
            config={
                "endpoint_name": resource_id,
                "endpoint_config_name": f"{resource_id}-config",
                "endpoint_status": "InService",
                "production_variants": [
                    {
                        "variant_name": "AllTraffic",
                        "model_name": f"{resource_id}-model",
                        "instance_type": "ml.m5.large",
                        "initial_instance_count": 1,
                        "initial_variant_weight": 1.0,
                        "accelerator_type": None,
                        "serverless_config": {},
                    }
                ],
                "current_variants": [
                    {
                        "variant_name": "AllTraffic",
                        "current_weight": 1.0,
                        "desired_weight": 1.0,
                        "current_instance_count": 1,
                        "desired_instance_count": 1,
                    }
                ],
                "data_capture_enabled": True,
                "data_capture_config": {
                    "capture_status": "Started",
                    "capture_percentage": 10,
                    "destination_s3_uri": f"s3://mock-bucket/{resource_id}/data-capture/",
                },
                "creation_time": "2024-01-01T00:00:00Z",
                "last_modified_time": "2024-01-15T12:00:00Z",
                "kms_key_id": None,
            },
        )


class SageMakerModelRegistryFetcher(BaseConfigFetcher):
    """SageMaker Model Registry 설정 조회기.

    Severity Mapping:
    - model_approval_status: CRITICAL (승인 상태 변경)
    - inference_containers.image: CRITICAL (컨테이너 이미지 변경)
    - security_kms_key: CRITICAL (암호화 키 변경)
    - model_metrics: HIGH (모델 품질 지표 변화)
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
        model_package_group_name: Optional[str] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.SAGEMAKER_MODEL.value
        self.model_package_group_name = model_package_group_name

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("sagemaker", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("sagemaker")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """SageMaker Model Package 설정 조회.

        Args:
            resource_id: Model Package ARN 또는 "group_name/version" 형식

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            # resource_id가 ARN인지 확인
            if resource_id.startswith("arn:"):
                model_package_arn = resource_id
            else:
                # group_name/version 형식 처리
                parts = resource_id.split("/")
                if len(parts) == 2:
                    group_name, version = parts
                    # 버전으로 Model Package 찾기
                    response = self.client.list_model_packages(
                        ModelPackageGroupName=group_name,
                        MaxResults=100,
                    )
                    model_package_arn = None
                    for pkg in response.get("ModelPackageSummaryList", []):
                        if str(pkg.get("ModelPackageVersion")) == version:
                            model_package_arn = pkg.get("ModelPackageArn")
                            break
                    if not model_package_arn:
                        logger.warning(f"Model package not found: {resource_id}")
                        return None
                else:
                    # group_name만 있는 경우 최신 버전 조회
                    response = self.client.list_model_packages(
                        ModelPackageGroupName=resource_id,
                        SortBy="CreationTime",
                        SortOrder="Descending",
                        MaxResults=1,
                    )
                    packages = response.get("ModelPackageSummaryList", [])
                    if not packages:
                        logger.warning(f"No model packages found for group: {resource_id}")
                        return None
                    model_package_arn = packages[0].get("ModelPackageArn")

            # Model Package 상세 정보 조회
            response = self.client.describe_model_package(ModelPackageName=model_package_arn)

            # Inference Containers 추출
            inference_containers = []
            for container in response.get("InferenceSpecification", {}).get("Containers", []):
                inference_containers.append({
                    "image": container.get("Image"),
                    "image_digest": container.get("ImageDigest"),
                    "model_data_url": container.get("ModelDataUrl"),
                    "framework": container.get("Framework"),
                    "framework_version": container.get("FrameworkVersion"),
                    "environment": container.get("Environment", {}),
                })

            # Model Metrics 추출
            model_metrics = response.get("ModelMetrics", {})

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=model_package_arn,
                config={
                    "model_package_name": response.get("ModelPackageName"),
                    "model_package_group_name": response.get("ModelPackageGroupName"),
                    "model_package_version": response.get("ModelPackageVersion"),
                    "model_approval_status": response.get("ModelApprovalStatus"),
                    "model_package_status": response.get("ModelPackageStatus"),
                    "inference_containers": inference_containers,
                    "model_metrics": {
                        "model_quality": model_metrics.get("ModelQuality", {}),
                        "model_data_quality": model_metrics.get("ModelDataQuality", {}),
                        "bias": model_metrics.get("Bias", {}),
                        "explainability": model_metrics.get("Explainability", {}),
                    } if model_metrics else None,
                    "source_algorithm": response.get("SourceAlgorithmSpecification", {}),
                    "security_kms_key": response.get("CustomerMetadataProperties", {}).get("KmsKeyId"),
                    "creation_time": response.get("CreationTime").isoformat() if response.get("CreationTime") else None,
                    "created_by": response.get("CreatedBy", {}),
                    "approval_description": response.get("ApprovalDescription"),
                    "sample_payload_url": response.get("SamplePayloadUrl"),
                    "task": response.get("Task"),
                    "domain": response.get("Domain"),
                },
            )

        except Exception as e:
            logger.error(f"Failed to fetch SageMaker Model Package config for {resource_id}: {e}")
            return None

    def list_resources(self) -> List[str]:
        """SageMaker Model Package 목록 조회.

        model_package_group_name이 설정된 경우 해당 그룹의 패키지만 반환.
        """
        if self.use_mock:
            return ["mock-model-group/1", "mock-model-group/2"]

        resources = []
        try:
            if self.model_package_group_name:
                # 특정 그룹의 패키지만 조회
                paginator = self.client.get_paginator("list_model_packages")
                for page in paginator.paginate(ModelPackageGroupName=self.model_package_group_name):
                    for pkg in page.get("ModelPackageSummaryList", []):
                        group_name = pkg.get("ModelPackageGroupName", "")
                        version = pkg.get("ModelPackageVersion", "")
                        resources.append(f"{group_name}/{version}")
            else:
                # 모든 Model Package Group 조회
                group_paginator = self.client.get_paginator("list_model_package_groups")
                for group_page in group_paginator.paginate():
                    for group in group_page.get("ModelPackageGroupSummaryList", []):
                        group_name = group.get("ModelPackageGroupName")
                        # 각 그룹의 최신 패키지만 조회
                        pkg_response = self.client.list_model_packages(
                            ModelPackageGroupName=group_name,
                            SortBy="CreationTime",
                            SortOrder="Descending",
                            MaxResults=1,
                        )
                        for pkg in pkg_response.get("ModelPackageSummaryList", []):
                            version = pkg.get("ModelPackageVersion", "")
                            resources.append(f"{group_name}/{version}")

        except Exception as e:
            logger.error(f"Failed to list SageMaker Model Packages: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 SageMaker Model Package 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        parts = resource_id.split("/")
        group_name = parts[0] if parts else "mock-model-group"
        version = parts[1] if len(parts) > 1 else "1"

        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=f"arn:aws:sagemaker:ap-northeast-2:123456789012:model-package/{group_name}/{version}",
            config={
                "model_package_name": f"{group_name}/{version}",
                "model_package_group_name": group_name,
                "model_package_version": int(version),
                "model_approval_status": "Approved",
                "model_package_status": "Completed",
                "inference_containers": [
                    {
                        "image": "123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/mock-model:latest",
                        "image_digest": "sha256:mock-digest",
                        "model_data_url": f"s3://mock-bucket/{group_name}/model.tar.gz",
                        "framework": "PYTORCH",
                        "framework_version": "2.0",
                        "environment": {"SAGEMAKER_PROGRAM": "inference.py"},
                    }
                ],
                "model_metrics": {
                    "model_quality": {"Statistics": {"ContentType": "application/json"}},
                    "model_data_quality": {},
                    "bias": {},
                    "explainability": {},
                },
                "source_algorithm": {},
                "security_kms_key": None,
                "creation_time": "2024-01-01T00:00:00Z",
                "created_by": {},
                "approval_description": "Mock approved model",
                "sample_payload_url": None,
                "task": "TEXT_CLASSIFICATION",
                "domain": "NATURAL_LANGUAGE_PROCESSING",
            },
        )
