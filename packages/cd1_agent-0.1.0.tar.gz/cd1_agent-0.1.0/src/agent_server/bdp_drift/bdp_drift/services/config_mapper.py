"""
Config Check Item Mapper.

AWS raw config → check_items 형식 매핑.
ConfigFetcher로 조회한 raw config를 portal의 check_items 키에 맞게 변환합니다.
"""

import logging
import os
from typing import Any, Dict, Optional

from .config_fetcher import ConfigFetcher

logger = logging.getLogger(__name__)


# 리소스 타입별 raw config → check_item key 매핑
# raw config의 키를 check_items의 키로 변환
_RESOURCE_TYPE_MAPPINGS: Dict[str, Dict[str, str]] = {
    "s3": {
        "versioning": "versioning",
        "encryption": "encryption",
        "public_access_block": "public_access_block",
    },
    "lambda": {
        "runtime": "runtime",
        "memory_size": "memory",
        "timeout": "timeout",
        "role": "iam_role",
        "layers": "layers",
        "vpc_config": "vpc_config",
        "environment": "env_vars",
    },
    "glue": {
        "columns": "table_schema",
        "partition_keys": "partition_keys",
        "storage_descriptor": "storage_descriptor",
        "parameters": "table_properties",
    },
    "athena": {
        "result_configuration": "result_location",
        "engine_version": "engine_version",
        "enforce_work_group_configuration": "workgroup_config",
        "bytes_scanned_cutoff_per_query": "query_limit",
    },
    "msk": {
        "broker_config": "broker_config",
        "encryption_in_transit": "encryption",
        "authentication": "authentication",
        "monitoring_level": "monitoring",
        "ebs_volume_size": "storage",
        "networking": "networking",
    },
    # quota-* 타입은 map_to_check_items()에서 동적 처리
}


def _extract_value(raw_config: Dict[str, Any], raw_key: str, resource_type: str) -> Any:
    """raw config에서 check_item에 적합한 값을 추출.

    단순 값은 그대로, 복잡한 객체는 적절히 변환합니다.
    """
    value = raw_config.get(raw_key)
    if value is None:
        return None

    # S3 encryption: SSEAlgorithm 추출
    if resource_type == "s3" and raw_key == "encryption":
        if isinstance(value, dict):
            return value.get("SSEAlgorithm")
        return value

    # S3 public_access_block: 전체 차단 여부 판단
    if resource_type == "s3" and raw_key == "public_access_block":
        if isinstance(value, dict):
            all_blocked = all(value.values())
            return "전체 차단" if all_blocked else "일부 허용"
        return value

    # Lambda layers: 개수 반환
    if resource_type == "lambda" and raw_key == "layers":
        if isinstance(value, list):
            return len(value)
        return value

    # Lambda vpc_config: VPC 연결 여부
    if resource_type == "lambda" and raw_key == "vpc_config":
        if isinstance(value, dict):
            subnets = value.get("SubnetIds", [])
            return "VPC 연결" if subnets else "VPC 미연결"
        return value

    # Glue columns: 컬럼 수 반환
    if resource_type == "glue" and raw_key == "columns":
        if isinstance(value, list):
            return len(value)
        return value

    # Glue partition_keys: 파티션 키 수 반환
    if resource_type == "glue" and raw_key == "partition_keys":
        if isinstance(value, list):
            return len(value)
        return value

    # Athena result_configuration: OutputLocation 추출
    if resource_type == "athena" and raw_key == "result_configuration":
        if isinstance(value, dict):
            return value.get("OutputLocation")
        return value

    # Athena engine_version: SelectedEngineVersion 추출
    if resource_type == "athena" and raw_key == "engine_version":
        if isinstance(value, dict):
            return value.get("SelectedEngineVersion")
        return value

    # Athena workgroup_config: enforce 여부
    if resource_type == "athena" and raw_key == "enforce_work_group_configuration":
        return "워크그룹 설정 강제" if value else "클라이언트 설정 허용"

    return value


def map_to_check_items(resource_type: str, raw_config: Dict[str, Any]) -> Dict[str, Any]:
    """AWS raw config를 check_items 형식으로 매핑.

    Args:
        resource_type: 리소스 타입 (s3, lambda, glue 등)
        raw_config: ConfigFetcher에서 반환된 raw config dict

    Returns:
        {check_item_key: value} 형식의 딕셔너리.
        매핑에 없는 항목(monitor 타입)은 None 값으로 반환됩니다.
    """
    # quota-* 타입: 키가 동일하므로 pass-through
    if resource_type.startswith("quota-"):
        return dict(raw_config)

    mapping = _RESOURCE_TYPE_MAPPINGS.get(resource_type, {})
    if not mapping:
        logger.warning(f"No mapping defined for resource type: {resource_type}")
        return {}

    result: Dict[str, Any] = {}
    for raw_key, check_key in mapping.items():
        value = _extract_value(raw_config, raw_key, resource_type)
        if value is not None:
            result[check_key] = value

    return result


class ConfigCheckItemMapper:
    """ConfigFetcher로 조회 + check_items 매핑 통합 서비스.

    Usage:
        mapper = ConfigCheckItemMapper(use_mock=True)
        check_items = mapper.fetch_and_map("s3", "my-bucket")
    """

    def __init__(self, use_mock: bool = False, **fetcher_kwargs):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self._fetcher = ConfigFetcher(use_mock=self.use_mock, **fetcher_kwargs)

    def fetch_and_map(self, resource_type: str, resource_id: str) -> Dict[str, Any]:
        """AWS에서 현재 설정을 조회하고 check_items 형식으로 변환.

        Args:
            resource_type: 리소스 타입
            resource_id: 리소스 ID

        Returns:
            {check_item_key: value} 딕셔너리. 조회 실패 시 빈 dict.
        """
        fetcher = self._fetcher.get_fetcher(resource_type)
        if fetcher is None:
            logger.warning(f"No fetcher available for resource type: {resource_type}")
            return {}

        resource_config = fetcher.fetch_config(resource_id)
        if resource_config is None:
            logger.warning(f"Failed to fetch config for {resource_type}/{resource_id}")
            return {}

        return map_to_check_items(resource_type, resource_config.config)
