"""
VPC Security Group Fetcher.

VPC Security Group 설정 조회기.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from botocore.config import Config

from ..config_fetcher import BaseConfigFetcher, ResourceConfig, STSCredentials
from ..models import ResourceType

logger = logging.getLogger(__name__)

config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)


class SecurityGroupFetcher(BaseConfigFetcher):
    """VPC Security Group 설정 조회기.

    Severity Mapping:
    - ingress_rules: CRITICAL
    - egress_rules: CRITICAL
    - open_to_world (0.0.0.0/0): CRITICAL (특별 경고)

    Args:
        sg_prefix_filter: Security Group 이름 필터링 prefix (e.g., "bdp-*")
    """

    def __init__(
        self,
        client=None,
        use_mock: bool = False,
        credentials: Optional[STSCredentials] = None,
        sg_prefix_filter: Optional[str] = None,
    ):
        self.use_mock = use_mock or os.getenv("DRIFT_PROVIDER", "").lower() == "mock"
        self.credentials = credentials
        self._client = client
        self.resource_type = ResourceType.VPC_SG.value
        self.sg_prefix_filter = sg_prefix_filter

    @property
    def client(self):
        if self._client is None and not self.use_mock:
            import boto3
            if self.credentials:
                self._client = boto3.client("ec2", config=config, **self.credentials.to_boto3_kwargs())
            else:
                from bdp_common.aws_session import get_boto3_client
                self._client = get_boto3_client("ec2")
        return self._client

    def fetch_config(self, resource_id: str) -> Optional[ResourceConfig]:
        """Security Group 설정 조회.

        Args:
            resource_id: Security Group ID (e.g., sg-12345678)

        Returns:
            ResourceConfig 또는 None
        """
        if self.use_mock:
            return self._mock_config(resource_id)

        try:
            response = self.client.describe_security_groups(GroupIds=[resource_id])
            security_groups = response.get("SecurityGroups", [])

            if not security_groups:
                logger.warning(f"Security Group not found: {resource_id}")
                return None

            sg = security_groups[0]

            # Ingress/Egress 룰 분석
            ingress_rules = self._parse_rules(sg.get("IpPermissions", []))
            egress_rules = self._parse_rules(sg.get("IpPermissionsEgress", []))

            # 0.0.0.0/0 오픈 여부 확인
            open_to_world = self._check_open_to_world(ingress_rules)

            return ResourceConfig(
                resource_type=self.resource_type,
                resource_id=resource_id,
                resource_arn=f"arn:aws:ec2:{self._get_region()}:{sg.get('OwnerId')}:security-group/{resource_id}",
                config={
                    "group_name": sg.get("GroupName"),
                    "description": sg.get("Description"),
                    "vpc_id": sg.get("VpcId"),
                    "owner_id": sg.get("OwnerId"),
                    "ingress_rules": ingress_rules,
                    "egress_rules": egress_rules,
                    "open_to_world": open_to_world,
                    "tags": {tag["Key"]: tag["Value"] for tag in sg.get("Tags", [])},
                },
            )

        except Exception as e:
            logger.error(f"Failed to fetch Security Group config for {resource_id}: {e}")
            return None

    def _parse_rules(self, permissions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """IP Permission을 파싱하여 간결한 형식으로 변환."""
        rules = []
        for perm in permissions:
            rule = {
                "protocol": perm.get("IpProtocol"),
                "from_port": perm.get("FromPort"),
                "to_port": perm.get("ToPort"),
                "ip_ranges": [
                    {
                        "cidr": ip.get("CidrIp"),
                        "description": ip.get("Description"),
                    }
                    for ip in perm.get("IpRanges", [])
                ],
                "ipv6_ranges": [
                    {
                        "cidr": ip.get("CidrIpv6"),
                        "description": ip.get("Description"),
                    }
                    for ip in perm.get("Ipv6Ranges", [])
                ],
                "security_groups": [
                    {
                        "group_id": sg.get("GroupId"),
                        "group_name": sg.get("GroupName"),
                        "description": sg.get("Description"),
                    }
                    for sg in perm.get("UserIdGroupPairs", [])
                ],
                "prefix_lists": [
                    pl.get("PrefixListId")
                    for pl in perm.get("PrefixListIds", [])
                ],
            }
            rules.append(rule)
        return rules

    def _check_open_to_world(self, ingress_rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """0.0.0.0/0 또는 ::/0으로 오픈된 규칙 확인."""
        open_rules = []
        for rule in ingress_rules:
            for ip_range in rule.get("ip_ranges", []):
                if ip_range.get("cidr") == "0.0.0.0/0":
                    open_rules.append({
                        "protocol": rule.get("protocol"),
                        "from_port": rule.get("from_port"),
                        "to_port": rule.get("to_port"),
                        "cidr": "0.0.0.0/0",
                    })
            for ipv6_range in rule.get("ipv6_ranges", []):
                if ipv6_range.get("cidr") == "::/0":
                    open_rules.append({
                        "protocol": rule.get("protocol"),
                        "from_port": rule.get("from_port"),
                        "to_port": rule.get("to_port"),
                        "cidr": "::/0",
                    })

        return {
            "is_open": len(open_rules) > 0,
            "open_rules": open_rules,
        }

    def _get_region(self) -> str:
        """현재 리전 반환."""
        if self._client:
            return self._client.meta.region_name
        return os.getenv("AWS_REGION", "ap-northeast-2")

    def list_resources(self) -> List[str]:
        """Security Group 목록 조회."""
        if self.use_mock:
            return ["sg-mock-12345678", "sg-mock-87654321"]

        resources = []
        try:
            filters = []
            if self.sg_prefix_filter:
                # 이름 prefix 필터 적용
                filters.append({
                    "Name": "group-name",
                    "Values": [self.sg_prefix_filter],
                })

            paginator = self.client.get_paginator("describe_security_groups")
            paginate_kwargs = {}
            if filters:
                paginate_kwargs["Filters"] = filters

            for page in paginator.paginate(**paginate_kwargs):
                for sg in page.get("SecurityGroups", []):
                    resources.append(sg.get("GroupId"))

        except Exception as e:
            logger.error(f"Failed to list Security Groups: {e}")

        return resources

    def fetch_all_configs(self) -> List[ResourceConfig]:
        """모든 Security Group 설정 조회."""
        configs = []
        for resource_id in self.list_resources():
            config = self.fetch_config(resource_id)
            if config:
                configs.append(config)
        return configs

    def _mock_config(self, resource_id: str) -> ResourceConfig:
        """Mock 설정 반환."""
        return ResourceConfig(
            resource_type=self.resource_type,
            resource_id=resource_id,
            resource_arn=f"arn:aws:ec2:ap-northeast-2:123456789012:security-group/{resource_id}",
            config={
                "group_name": f"mock-sg-{resource_id}",
                "description": "Mock security group for testing",
                "vpc_id": "vpc-12345678",
                "owner_id": "123456789012",
                "ingress_rules": [
                    {
                        "protocol": "tcp",
                        "from_port": 443,
                        "to_port": 443,
                        "ip_ranges": [
                            {"cidr": "10.0.0.0/8", "description": "Internal network"}
                        ],
                        "ipv6_ranges": [],
                        "security_groups": [],
                        "prefix_lists": [],
                    },
                    {
                        "protocol": "tcp",
                        "from_port": 22,
                        "to_port": 22,
                        "ip_ranges": [
                            {"cidr": "192.168.1.0/24", "description": "Office network"}
                        ],
                        "ipv6_ranges": [],
                        "security_groups": [],
                        "prefix_lists": [],
                    },
                ],
                "egress_rules": [
                    {
                        "protocol": "-1",
                        "from_port": None,
                        "to_port": None,
                        "ip_ranges": [
                            {"cidr": "0.0.0.0/0", "description": "All traffic"}
                        ],
                        "ipv6_ranges": [],
                        "security_groups": [],
                        "prefix_lists": [],
                    },
                ],
                "open_to_world": {
                    "is_open": False,
                    "open_rules": [],
                },
                "tags": {
                    "Name": f"mock-sg-{resource_id}",
                    "Environment": "test",
                },
            },
        )
