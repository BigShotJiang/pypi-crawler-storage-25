"""
BDP Drift Agent - Lambda Handler.

데이터레이크 어플리케이션 레이어의 설정 drift 탐지.

Supported Resources:
- Primary: Glue, Athena, EMR, SageMaker
- Secondary: S3, MWAA, MSK, Lambda
"""

import logging
import os
from typing import Any

from src.agent_server.bdp_common.deep_agent import (
    DeepAgentExecutor,
    DetectionInput,
    DetectionItem,
)
from src.agent_server.bdp_common.eventbridge.publisher import AlertEvent, EventPublisher
from src.agent_server.bdp_common.kakao.notifier import KakaoNotifier
from src.agent_server.bdp_drift.bdp_drift.services.baseline_store import BaselineStore
from src.agent_server.bdp_drift.bdp_drift.services.config_fetcher import ConfigFetcher
from src.agent_server.bdp_drift.bdp_drift.services.drift_detector import DriftDetector
from src.agent_server.bdp_drift.bdp_drift.services.models import DriftResult, DriftSeverity
from src.agent_server.bdp_drift.bdp_drift.services.summary_generator import (
    DriftAlertSummary,
    DriftSummaryGenerator,
)
from src.common.handlers import BaseHandler
from src.common.hitl.schemas import HITLAgentType, HITLRequest
from src.common.hitl.store import HITLStore
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class BDPDriftHandler(BaseHandler):
    """
    BDP Drift Agent Handler.

    베이스라인과 현재 설정을 비교하여 드리프트 탐지.
    CRITICAL 드리프트 발생 시 HITL 요청 생성.
    """

    def __init__(self):
        """핸들러 초기화."""
        super().__init__()

        # 환경 변수
        self.provider = os.getenv("DRIFT_PROVIDER", "mock")
        self.baseline_provider = os.getenv("BASELINE_DB_PROVIDER", "mock")
        self.baseline_secret_id = os.getenv("BASELINE_SECRET_ID")
        self.baseline_db = os.getenv("BASELINE_DB_NAME")
        self.hitl_on_critical = os.getenv("DRIFT_HITL_ON_CRITICAL", "true").lower() == "true"
        self.event_provider = os.getenv("EVENT_PROVIDER", "mock")
        self.rds_provider = os.getenv("RDS_PROVIDER", "mock")

        # 서비스 초기화
        self.baseline_store = BaselineStore(
            provider=self.baseline_provider,
            secret_id=self.baseline_secret_id,
            db=self.baseline_db,
        )
        self.baseline_store.ensure_tables()

        self.config_fetcher = ConfigFetcher(use_mock=(self.provider == "mock"))

        self.detector = DriftDetector(
            baseline_store=self.baseline_store,
            config_fetcher=self.config_fetcher,
        )

        self.summary_generator = DriftSummaryGenerator()

        self.event_publisher = EventPublisher(
            source="cd1-agent.bdp-drift",
            use_mock=(self.event_provider == "mock"),
        )

        self.hitl_store = HITLStore(provider=self.rds_provider)

        # 카카오 알림 (선택)
        self.kakao_notifier: KakaoNotifier | None = None
        if os.getenv("KAKAO_REST_API_KEY"):
            self.kakao_notifier = KakaoNotifier()
            self.kakao_notifier.load_tokens()

        logger.info(
            f"BDPDriftHandler initialized: "
            f"provider={self.provider}, "
            f"baseline_db={self.baseline_provider}, "
            f"hitl_on_critical={self.hitl_on_critical}"
        )

    def process(self, event: dict[str, Any]) -> dict[str, Any]:
        """이벤트 처리.

        Args:
            event: 이벤트 페이로드
                - action: "detect" | "sync_baselines" | "daily_report" | "e2e"
                - output_dir: 리포트 저장 경로 (기본: reports/)

        Returns:
            처리 결과
        """
        action = event.get("action", "detect")

        if action == "sync_baselines":
            return self._sync_baselines(event)
        elif action == "daily_report":
            return self._generate_daily_report(event)
        elif action == "e2e":
            return self._run_e2e(event)
        else:
            return self._detect_drift(event)

    def _generate_daily_report(self, event: dict[str, Any]) -> dict[str, Any]:
        """일간 리포트 생성.

        현재 드리프트 탐지를 실행하여 리포트를 생성합니다.
        """
        from pathlib import Path

        from src.agent_server.bdp_drift.bdp_drift.services.daily_report_generator import (
            DriftDailyReportGenerator,
        )

        output_dir = event.get("output_dir", "reports/")
        resource_types = event.get("resource_types")

        # 탐지 실행
        results = self.detector.detect_all(resource_types=resource_types)
        drifts = [r for r in results if r.has_drift]

        # 리포트 생성
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        report_path = str(output_path / "drift_daily_report.html")

        generator = DriftDailyReportGenerator()
        generator.generate_report(results, report_path)

        severity_counts = self._count_by_severity(drifts)

        return {
            "status": "success",
            "action": "daily_report",
            "report_path": report_path,
            "summary": {
                "total_checked": len(results),
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
        }

    def _run_e2e(self, event: dict[str, Any]) -> dict[str, Any]:
        """E2E 시나리오 테스트 실행."""
        from src.agent_server.bdp_drift.bdp_drift.services.e2e_runner import DriftE2ERunner

        output_dir = event.get("output_dir", "reports/")

        runner = DriftE2ERunner()
        result = runner.run_all(output_dir=output_dir)

        return {
            "status": "success",
            "action": "e2e",
            "pass_rate": result.pass_rate,
            "passed": result.passed,
            "failed": result.failed,
            "total": result.total,
            "report_path": result.e2e_report_path,
            "daily_report_path": result.daily_report_path,
        }

    def _detect_drift(self, event: dict[str, Any]) -> dict[str, Any]:
        """드리프트 탐지 실행.

        Args:
            event: 이벤트 페이로드

        Returns:
            탐지 결과
        """
        resource_types = event.get("resource_types")
        resource_ids = event.get("resource_ids")
        publish_alerts = event.get("publish_alerts", True)
        send_kakao = event.get("send_kakao", False)

        logger.info(f"Starting drift detection: types={resource_types}, ids={resource_ids}")

        # 드리프트 탐지
        if resource_ids:
            # 특정 리소스만 탐지
            results = []
            for resource_id in resource_ids:
                # resource_id format: type/id
                parts = resource_id.split("/", 1)
                if len(parts) == 2:
                    result = self.detector.detect(parts[0], parts[1])
                    if result:
                        results.append(result)
        else:
            # 전체 탐지
            results = self.detector.detect_all(resource_types=resource_types)

        # 드리프트 필터링
        drifts = [r for r in results if r.has_drift]

        logger.info(f"Detection complete: {len(results)} checked, {len(drifts)} drifts found")

        # 결과가 없으면 조기 반환
        if not drifts:
            return self._build_response(results, [], None)

        # 요약 생성
        summary = self.summary_generator.generate_batch_summary(drifts)

        # HITL 요청 (CRITICAL인 경우)
        hitl_request_id = None
        if self.hitl_on_critical and self._has_critical(drifts):
            hitl_request_id = self._create_hitl_request(drifts, summary)

        # EventBridge 발행
        if publish_alerts:
            self._publish_events(drifts, summary, hitl_request_id)

        # 카카오톡 발송
        if send_kakao and self.kakao_notifier:
            self._send_kakao_alert(drifts, summary)

        response = self._build_response(results, drifts, hitl_request_id)
        return self._run_deep_analysis(response)

    def _sync_baselines(self, event: dict[str, Any]) -> dict[str, Any]:
        """현재 리소스 상태를 baseline으로 동기화.

        Args:
            event: 이벤트 페이로드
                - resource_types: 대상 리소스 타입 목록 (선택, 없으면 전체)
                - created_by: 생성자 (기본 "scheduled-sync")
                - update_existing: 기존 baseline 업데이트 여부 (기본 True)

        Returns:
            동기화 결과
        """
        resource_types = event.get("resource_types")
        created_by = event.get("created_by", "scheduled-sync")
        update_existing = event.get("update_existing", True)

        # 대상 리소스 타입 결정
        if not resource_types:
            resource_types = self.config_fetcher.supported_resource_types

        logger.info(
            f"Starting baseline sync: "
            f"types={resource_types}, created_by={created_by}, "
            f"update_existing={update_existing}"
        )

        created_count = 0
        updated_count = 0
        skipped_count = 0
        failed_count = 0
        errors: list[dict[str, Any]] = []

        for resource_type in resource_types:
            try:
                # 해당 타입의 모든 리소스 조회
                resources = self.config_fetcher.list_resources(resource_type)

                for resource_id in resources:
                    try:
                        # 기존 baseline 확인
                        existing = self.baseline_store.get_baseline(resource_type, resource_id)

                        if existing:
                            if update_existing:
                                # 기존 baseline 업데이트
                                result = self.detector.update_baseline_from_current(
                                    resource_type=resource_type,
                                    resource_id=resource_id,
                                    updated_by=created_by,
                                    reason="Scheduled baseline sync",
                                )
                                if result:
                                    updated_count += 1
                                    logger.debug(f"Updated baseline: {resource_type}/{resource_id}")
                                else:
                                    failed_count += 1
                                    errors.append(
                                        {
                                            "resource_type": resource_type,
                                            "resource_id": resource_id,
                                            "error": "Failed to update baseline",
                                        }
                                    )
                            else:
                                skipped_count += 1
                                logger.debug(
                                    f"Skipped existing baseline: {resource_type}/{resource_id}"
                                )
                        else:
                            # 새 baseline 생성
                            result = self.detector.create_baseline_from_current(
                                resource_type=resource_type,
                                resource_id=resource_id,
                                created_by=created_by,
                                description="Created by scheduled baseline sync",
                            )
                            if result:
                                created_count += 1
                                logger.debug(f"Created baseline: {resource_type}/{resource_id}")
                            else:
                                failed_count += 1
                                errors.append(
                                    {
                                        "resource_type": resource_type,
                                        "resource_id": resource_id,
                                        "error": "Failed to create baseline",
                                    }
                                )

                    except Exception as e:
                        failed_count += 1
                        errors.append(
                            {
                                "resource_type": resource_type,
                                "resource_id": resource_id,
                                "error": str(e),
                            }
                        )
                        logger.error(f"Error syncing baseline {resource_type}/{resource_id}: {e}")

            except Exception as e:
                logger.error(f"Error listing resources for {resource_type}: {e}")
                errors.append(
                    {
                        "resource_type": resource_type,
                        "resource_id": None,
                        "error": f"Failed to list resources: {e}",
                    }
                )

        logger.info(
            f"Baseline sync complete: "
            f"created={created_count}, updated={updated_count}, "
            f"skipped={skipped_count}, failed={failed_count}"
        )

        return {
            "status": "success" if failed_count == 0 else "partial",
            "timestamp": get_kst_now().isoformat(),
            "action": "sync_baselines",
            "summary": {
                "created": created_count,
                "updated": updated_count,
                "skipped": skipped_count,
                "failed": failed_count,
            },
            "errors": errors if errors else None,
        }

    def _run_deep_analysis(self, detect_result: dict[str, Any]) -> dict[str, Any]:
        """심각도 높을 때 deep analysis 실행."""
        severity = detect_result.get("summary", {}).get("by_severity", {})
        if severity.get("critical", 0) > 0 or severity.get("high", 0) > 0:
            try:
                items = self._normalize_detection_items(detect_result)
                detection_input = DetectionInput(
                    agent_type="bdp_drift",
                    detection_type="config_drift",
                    severity="critical" if severity.get("critical", 0) > 0 else "high",
                    summary=f"드리프트 {detect_result.get('summary', {}).get('total_drifts', 0)}건 탐지",
                    total_anomalies=detect_result.get("summary", {}).get("total_drifts", 0),
                    severity_breakdown=severity,
                    items=items,
                )
                executor = DeepAgentExecutor(tools=create_investigation_tools("bdp_drift"))
                result = executor.run(detection_input)
                detect_result["deep_analysis"] = result.model_dump()
            except Exception as e:
                logger.error(f"Deep analysis 실패: {e}")
        return detect_result

    def _normalize_detection_items(self, detect_result: dict[str, Any]) -> list[DetectionItem]:
        """드리프트 결과를 DetectionItem 형식으로 변환."""
        items = []
        for d in detect_result.get("drifts", []):
            r_type = d.get("resource_type", "")
            r_id = d.get("resource_id", "")
            items.append(
                DetectionItem(
                    item_type="drift",
                    resource_id=f"{r_type}/{r_id}" if r_type else r_id,
                    severity=d.get("severity", "medium"),
                    title=f"{r_type}/{r_id} 설정 드리프트",
                    description=d.get("description", ""),
                    raw_data=d,
                )
            )
        return items

    def _has_critical(self, results: list[DriftResult]) -> bool:
        """CRITICAL 드리프트 존재 여부."""
        return any(r.severity == DriftSeverity.CRITICAL for r in results)

    def _create_hitl_request(
        self,
        results: list[DriftResult],
        summary: DriftAlertSummary,
    ) -> str | None:
        """HITL 요청 생성."""
        try:
            critical_results = [r for r in results if r.severity == DriftSeverity.CRITICAL]

            request = HITLRequest(
                agent_type=HITLAgentType.DRIFT,
                request_type="drift_review",
                title=summary.title,
                description=summary.message,
                payload={
                    "drift_count": summary.drift_count,
                    "critical_count": summary.critical_count,
                    "high_count": summary.high_count,
                    "affected_resources": [
                        {
                            "resource_type": r.resource_type,
                            "resource_id": r.resource_id,
                            "severity": r.severity.value,
                            "drift_fields": [f.field_name for f in r.drift_fields],
                        }
                        for r in critical_results
                    ],
                    "options": [
                        {
                            "action": "accept_changes",
                            "label": "의도적 변경으로 베이스라인 업데이트",
                        },
                        {"action": "investigate", "label": "조사 필요"},
                        {"action": "rollback", "label": "즉시 롤백"},
                    ],
                },
                created_by="bdp-drift-agent",
            )

            created = self.hitl_store.create_request(request)
            logger.info(f"HITL request created: {created.id}")
            return created.id

        except Exception as e:
            logger.error(f"Failed to create HITL request: {e}")
            return None

    def _publish_events(
        self,
        results: list[DriftResult],
        summary: DriftAlertSummary,
        hitl_request_id: str | None,
    ) -> None:
        """EventBridge에 이벤트 발행."""
        try:
            event = AlertEvent(
                alert_type="config_drift_batch",
                severity=summary.severity_emoji,
                severity_level=self._get_highest_severity(results).value,
                title=summary.title,
                message=summary.message,
                affected_resources=[
                    {
                        "resource_type": r.resource_type,
                        "resource_id": r.resource_id,
                        "severity": r.severity.value,
                        "drift_count": r.drift_count,
                    }
                    for r in results
                ],
                action_required=self._has_critical(results)
                or any(r.severity == DriftSeverity.HIGH for r in results),
                hitl_request_id=hitl_request_id,
                metadata={
                    "total_drifts": summary.drift_count,
                    "critical_count": summary.critical_count,
                    "high_count": summary.high_count,
                },
            )

            self.event_publisher.publish_event(event, "Config Drift Detected")
            logger.info("EventBridge event published")

        except Exception as e:
            logger.error(f"Failed to publish EventBridge event: {e}")

    def _send_kakao_alert(
        self,
        results: list[DriftResult],
        summary: DriftAlertSummary,
    ) -> None:
        """카카오톡 알림 발송."""
        if not self.kakao_notifier:
            return

        try:
            self.kakao_notifier.send_text_message(f"{summary.title}\n\n{summary.message}")
            logger.info("KakaoTalk alert sent")

        except Exception as e:
            logger.error(f"Failed to send KakaoTalk alert: {e}")

    def _get_highest_severity(self, results: list[DriftResult]) -> DriftSeverity:
        """가장 높은 심각도 반환."""
        for severity in [DriftSeverity.CRITICAL, DriftSeverity.HIGH, DriftSeverity.MEDIUM]:
            if any(r.severity == severity for r in results):
                return severity
        return DriftSeverity.LOW

    def _count_by_severity(self, results: list[DriftResult]) -> dict[str, int]:
        """심각도별 카운트."""
        counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        for r in results:
            counts[r.severity.value] += 1
        return counts

    def _build_response(
        self,
        all_results: list[DriftResult],
        drifts: list[DriftResult],
        hitl_request_id: str | None,
    ) -> dict[str, Any]:
        """응답 생성."""
        severity_counts = self._count_by_severity(drifts)

        return {
            "status": "success",
            "timestamp": get_kst_now().isoformat(),
            "summary": {
                "total_checked": len(all_results),
                "total_drifts": len(drifts),
                "by_severity": severity_counts,
            },
            "drifts": [r.to_dict() for r in drifts],
            "hitl_request_id": hitl_request_id,
        }


# Lambda 핸들러
_handler_instance: BDPDriftHandler | None = None


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda 핸들러 함수.

    Args:
        event: Lambda 이벤트
        context: Lambda 컨텍스트

    Returns:
        탐지 결과
    """
    global _handler_instance

    if _handler_instance is None:
        _handler_instance = BDPDriftHandler()

    return _handler_instance.process(event)


if __name__ == "__main__":
    # 로컬 테스트
    result = handler(
        {
            "resource_types": ["glue", "athena", "s3", "lambda"],
            "publish_alerts": False,
        },
        None,
    )
    print(result)
