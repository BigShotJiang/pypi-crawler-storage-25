"""HDSP Metrics Service - HDSP 서비스 시계열 메트릭 조회."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import (
    _daily_dates,
    _parse_cpu_mc,
    _parse_memory_mb,
)

if TYPE_CHECKING:
    from src.agent_server.hdsp_dashboard.providers import HdspProviderBundle

logger = logging.getLogger(__name__)

# Re-export utils for backward compatibility (providers import from here)
__all__ = ["HdspMetricsService", "_daily_dates", "_parse_cpu_mc", "_parse_memory_mb"]


class HdspMetricsService:
    """HDSP 서비스 시계열 메트릭을 조회하는 서비스.

    Provider 번들을 통해 mock/real 데이터 소스를 전환한다.
    """

    def __init__(self, providers: HdspProviderBundle):
        self.providers = providers

    # ── Jupyter ───────────────────────────────────────

    def get_jupyter_access(self, days: int = 31) -> dict[str, Any]:
        return self.providers.jupyter.get_jupyter_access(days)

    def get_jupyter_cluster_status(self, days: int = 31) -> dict[str, Any]:
        return self.providers.jupyter.get_jupyter_cluster_status(days)

    # ── MinIO ─────────────────────────────────────────

    def get_minio_usage(self, days: int = 31) -> dict[str, Any]:
        return self.providers.minio.get_minio_usage(days)

    def get_minio_access(self, days: int = 31) -> dict[str, Any]:
        return self.providers.minio.get_minio_access(days)

    def get_minio_admin(self, days: int = 31) -> dict[str, Any]:
        return self.providers.minio.get_minio_admin(days)

    def get_minio_prefixes(self, bucket_name: str, prefix: str = "") -> list[dict[str, Any]]:
        return self.providers.minio.get_minio_prefixes(bucket_name, prefix)

    # ── Spark ─────────────────────────────────────────

    def get_spark_failures(self, days: int = 31) -> dict[str, Any]:
        return self.providers.spark.get_spark_failures(days)

    def get_spark_cluster_status(self, days: int = 31) -> dict[str, Any]:
        return self.providers.spark.get_spark_cluster_status(days)

    def get_spark_jobs(self, cluster: str | None = None) -> dict[str, Any]:
        return self.providers.spark.get_spark_jobs(cluster)

    def get_spark_job_logs(
        self, app_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        return self.providers.spark.get_spark_job_logs(app_id, level=level, limit=limit)

    def get_spark_node_logs(
        self, node_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        return self.providers.spark.get_spark_node_logs(node_id, level=level, limit=limit)

    # ── NFS / NAS ─────────────────────────────────────

    def get_nfs_usage(self, days: int = 31) -> dict[str, Any]:
        return self.providers.nfs.get_nfs_usage(days)

    def get_nfs_iops(self, days: int = 31) -> dict[str, Any]:
        return self.providers.nfs.get_nfs_iops(days)

    def get_nfs_directories(self, mount_path: str, path: str = "") -> list[dict[str, Any]]:
        return self.providers.nfs.get_nfs_directories(mount_path, path)

    # ── EKS / K8s ─────────────────────────────────────

    def get_eks_pod_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.k8s.get_eks_pod_resources(days)

    def get_eks_node_resources(self, days: int = 31) -> dict[str, Any]:
        return self.providers.k8s.get_eks_node_resources(days)

    def get_eks_event_trends(self, days: int = 31) -> dict[str, Any]:
        return self.providers.k8s.get_eks_event_trends(days)

    # ── Backup ────────────────────────────────────────

    def get_log_backup_status(self, days: int = 31) -> dict[str, Any]:
        return self.providers.backup.get_log_backup_status(days)

    def get_backup_success_rate(self, days: int = 31) -> dict[str, Any]:
        return self.providers.backup.get_backup_success_rate(days)

    # ── HDSP API ──────────────────────────────────────

    def get_hdsp_api_errors(self, days: int = 31) -> dict[str, Any]:
        return self.providers.api.get_hdsp_api_errors(days)

    def get_hdsp_api_latency(self, days: int = 31) -> dict[str, Any]:
        return self.providers.api.get_hdsp_api_latency(days)

    # ── HAProxy ───────────────────────────────────────

    def get_haproxy_stats(self, days: int = 31) -> dict[str, Any]:
        return self.providers.haproxy.get_haproxy_stats(days)

    # ── Docker Registry ───────────────────────────────

    def get_docker_registry_stats(self, days: int = 31) -> dict[str, Any]:
        return self.providers.registry.get_docker_registry_stats(days)

    # ── Cost ──────────────────────────────────────────

    def get_cost_explorer_savings(self) -> dict[str, Any]:
        return self.providers.cost.get_cost_explorer_savings()

    def get_usage_conversion_savings(self) -> dict[str, Any]:
        return self.providers.cost.get_usage_conversion_savings()

    def get_gcp_monthly_cost(self, year: int, env: str | None = None) -> dict[str, Any]:
        return self.providers.cost.get_gcp_monthly_cost(year, env)

    def get_gcp_daily_cost(self, year: int, month: int, env: str | None = None) -> dict[str, Any]:
        return self.providers.cost.get_gcp_daily_cost(year, month, env)

    # ── Pipeline ──────────────────────────────────────

    def get_universe_failures(self, days: int = 31) -> dict[str, Any]:
        return self.providers.pipeline.get_universe_failures(days)

    def get_sobicare_workflows(self, days: int = 31) -> dict[str, Any]:
        return self.providers.pipeline.get_sobicare_workflows(days)
