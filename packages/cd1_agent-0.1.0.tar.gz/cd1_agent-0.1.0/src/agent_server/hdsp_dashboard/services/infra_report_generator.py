"""
HDSP K8s Infra Report Generator.

K8s 인프라 현황(노드, Pod, Deployment, 이벤트)을
테이블과 Summary 카드로 렌더링하는 HTML 리포트 생성기.
"""

import logging
from dataclasses import dataclass, field
from html import escape as html_escape
from typing import Any

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)

STATUS_COLORS = {
    "ok": "#16a34a",
    "warning": "#d97706",
    "critical": "#dc2626",
    "neutral": "#6b7280",
}

STATUS_LABELS = {
    "ok": "정상",
    "warning": "주의",
    "critical": "장애",
    "neutral": "확인 필요",
}


@dataclass
class HdspInfraReportData:
    """HDSP K8s 인프라 리포트 데이터."""

    summary: dict[str, int] = field(default_factory=dict)
    nodes: list[dict[str, Any]] = field(default_factory=list)
    pods: list[dict[str, Any]] = field(default_factory=list)
    deployments: list[dict[str, Any]] = field(default_factory=list)
    namespaces: dict[str, dict[str, int]] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)
    cluster_name: str = ""
    node_resources: dict[str, Any] = field(default_factory=dict)
    event_trends: dict[str, Any] = field(default_factory=dict)

    # Spark 클러스터 현황 ({clusters: {name: {daily: [{date, cpu, memory, jobs}]}}})
    spark_cluster_status: dict[str, Any] = field(default_factory=dict)

    # MinIO 관리자 현황 ({buckets: [...], disk: [...], api: [...]})
    minio_admin: dict[str, Any] = field(default_factory=dict)

    # NFS IOPS ({mounts: {mount: [{date, read_iops, write_iops, latency_ms}]}})
    nfs_iops: dict[str, Any] = field(default_factory=dict)

    # HDSP API 응답시간 ({daily: [{date, p50, p95, p99, rpm}]})
    hdsp_api_latency: dict[str, Any] = field(default_factory=dict)

    # 로그백업 현황 ({storages: {name: [{date, count}]}})
    log_backup_status: dict[str, Any] = field(default_factory=dict)

    # 백업 성공/실패율 ({storages: {name: [{date, success_rate}]}})
    backup_success_rate: dict[str, Any] = field(default_factory=dict)

    # HAProxy 통계 ({frontends: {name: [{date, connections, response_time}]}})
    haproxy_stats: dict[str, Any] = field(default_factory=dict)

    # Docker Registry 통계 ({daily: [{date, pulls, pushes, storage_gb}]})
    docker_registry_stats: dict[str, Any] = field(default_factory=dict)


class HdspInfraReportGenerator(HTMLReportBase):
    """HDSP K8s 인프라 현황 리포트 생성기."""

    def __init__(self):
        styles = ReportStyles(primary_color=MD3_COLORS["primary"])
        super().__init__(title="HDSP K8s 인프라 현황 리포트", styles=styles)

    def generate_content(self, data: HdspInfraReportData) -> str:
        sections: list[str] = []

        # 1. Summary 카드 (4열)
        sections.append(self._build_summary(data))

        # 2. Nodes 테이블
        if data.nodes:
            sections.append(self._build_nodes_section(data.nodes))

        # 3. Pods by Namespace
        if data.pods:
            sections.append(self._build_pods_section(data.pods))

        # 4. Node Resource Charts (CPU/Memory 추이)
        if data.node_resources:
            sections.append(self._build_node_resource_charts(data.node_resources))

        # 5. Event Trend Charts (Warning 이벤트 추이)
        if data.event_trends:
            sections.append(self._build_event_trend_charts(data.event_trends))

        # 5a. Spark 클러스터
        if data.spark_cluster_status:
            spark_html = self._build_spark_section(data)
            if spark_html:
                sections.append(spark_html)

        # 5b. MinIO 관리
        if data.minio_admin:
            minio_html = self._build_minio_admin_section(data)
            if minio_html:
                sections.append(minio_html)

        # 5c. NAS IOPS
        if data.nfs_iops:
            nfs_html = self._build_nfs_iops_section(data)
            if nfs_html:
                sections.append(nfs_html)

        # 5d. HDSP API Latency
        if data.hdsp_api_latency:
            api_html = self._build_hdsp_api_latency_section(data)
            if api_html:
                sections.append(api_html)

        # 5e. 백업
        if data.log_backup_status or data.backup_success_rate:
            backup_html = self._build_backup_section(data)
            if backup_html:
                sections.append(backup_html)

        # 5f. HAProxy
        if data.haproxy_stats:
            haproxy_html = self._build_haproxy_section(data)
            if haproxy_html:
                sections.append(haproxy_html)

        # 5g. Docker Registry
        if data.docker_registry_stats:
            docker_html = self._build_docker_registry_section(data)
            if docker_html:
                sections.append(docker_html)

        # 6. Deployments 테이블
        if data.deployments:
            sections.append(self._build_deployments_section(data.deployments))

        # 7. Warning Events (있을 때만)
        warning_events = [e for e in data.events if e.get("type") == "Warning"]
        if warning_events:
            sections.append(self._build_events_section(warning_events))

        return "\n".join(sections)

    # ── Summary ──────────────────────────────────────

    def _build_summary(self, data: HdspInfraReportData) -> str:
        s = data.summary
        stats = [
            {"label": "전체 노드", "value": str(s.get("total_nodes", 0)), "color": "#1976D2"},
            {
                "label": "Ready 노드",
                "value": str(s.get("ready_nodes", 0)),
                "color": "#388E3C"
                if s.get("ready_nodes", 0) == s.get("total_nodes", 0)
                else "#F57C00",
            },
            {"label": "전체 Pod", "value": str(s.get("total_pods", 0)), "color": "#1976D2"},
            {
                "label": "Running Pod",
                "value": str(s.get("running_pods", 0)),
                "color": "#388E3C" if s.get("failed_pods", 0) == 0 else "#F57C00",
            },
        ]
        return self.render_stat_cards(stats, columns=4)

    # ── Nodes ────────────────────────────────────────

    def _build_nodes_section(self, nodes: list[dict[str, Any]]) -> str:
        headers = ["Name", "Status", "Roles", "CPU", "Memory", "Pod 수", "Instance Type"]
        rows = []
        for n in nodes:
            rows.append(
                [
                    html_escape(n.get("name", "")),
                    _status_badge(n.get("display_status", "neutral")),
                    ", ".join(n.get("roles", [])),
                    html_escape(str(n.get("cpu_capacity", ""))),
                    html_escape(str(n.get("memory_capacity", ""))),
                    str(n.get("pod_count", 0)),
                    html_escape(n.get("instance_type", "")),
                ]
            )

        icon_html = self._icon("dns", size="sm", inline=True)
        table_html = self.render_table(headers, rows)
        return self._section_card(icon_html, "Nodes", table_html)

    # ── Pods ─────────────────────────────────────────

    def _build_pods_section(self, pods: list[dict[str, Any]]) -> str:
        # 네임스페이스별 그룹핑
        ns_pods: dict[str, list[dict]] = {}
        for p in pods:
            ns = p.get("namespace", "default")
            ns_pods.setdefault(ns, []).append(p)

        parts: list[str] = []
        for ns in sorted(ns_pods.keys()):
            ns_list = ns_pods[ns]
            headers = ["Name", "Status", "Node", "Image", "Restarts"]
            rows = []
            for p in ns_list:
                rows.append(
                    [
                        html_escape(p.get("name", "")),
                        _status_badge(p.get("display_status", "neutral")),
                        html_escape(p.get("node_name", "")),
                        html_escape(p.get("image", "")),
                        str(p.get("restart_count", 0)),
                    ]
                )
            table_html = self.render_table(headers, rows)
            parts.append(f"""
            <div style="margin-bottom:12px;">
                <h4 style="font-size:13px;font-weight:600;margin:0 0 8px;color:#374151;">
                    {html_escape(ns)} ({len(ns_list)} pods)
                </h4>
                {table_html}
            </div>
            """)

        icon_html = self._icon("view_in_ar", size="sm", inline=True)
        return self._section_card(icon_html, "Pods by Namespace", "\n".join(parts))

    # ── Deployments ──────────────────────────────────

    def _build_deployments_section(self, deployments: list[dict[str, Any]]) -> str:
        headers = ["Name", "Namespace", "Replicas", "Available", "Status"]
        rows = []
        for d in deployments:
            rows.append(
                [
                    html_escape(d.get("name", "")),
                    html_escape(d.get("namespace", "")),
                    str(d.get("replicas", 0)),
                    str(d.get("available", 0)),
                    _status_badge(d.get("display_status", "neutral")),
                ]
            )

        icon_html = self._icon("rocket_launch", size="sm", inline=True)
        table_html = self.render_table(headers, rows)
        return self._section_card(icon_html, "Deployments", table_html)

    # ── Node Resource Charts ────────────────────────────

    def _build_node_resource_charts(self, node_resources: dict[str, Any]) -> str:
        """노드 그룹별 → 노드별 CPU/Memory 일별 추이 라인 차트."""
        from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart

        node_groups = node_resources.get("node_groups", {})
        if not node_groups:
            return ""

        parts: list[str] = []
        for ng_name, ng_data in sorted(node_groups.items()):
            nodes = ng_data.get("nodes", {})
            if not nodes:
                continue

            node_charts: list[str] = []
            for node_name, node_info in sorted(nodes.items()):
                daily = node_info.get("daily", [])
                if not daily:
                    continue

                cpu_capacity = node_info.get("cpu_capacity_mc", 0)
                mem_capacity_mb = node_info.get("memory_capacity_mb", 0)
                instance_type = node_info.get("instance_type", "")

                # CPU 차트
                cpu_series = {"CPU 사용량": [(pt["date"], pt["cpu_mc"]) for pt in daily]}
                cpu_ref = []
                if cpu_capacity:
                    cpu_ref = [
                        {
                            "value": cpu_capacity,
                            "label": f"capacity {cpu_capacity}m",
                            "color": "#dc2626",
                        }
                    ]
                cpu_chart = _svg_line_chart(
                    series=cpu_series,
                    colors=CHART_COLORS,
                    title=f"{node_name} — CPU",
                    subtitle=f"{instance_type} · Capacity {cpu_capacity}m" if instance_type else "",
                    y_suffix="m",
                    reference_lines=cpu_ref,
                )

                # Memory 차트
                if mem_capacity_mb >= 1024:
                    mem_suffix = "GB"
                    mem_divisor = 1024.0
                    cap_label = f"capacity {mem_capacity_mb / 1024:.1f}GB"
                    cap_sub = f"{mem_capacity_mb / 1024:.1f}GB"
                else:
                    mem_suffix = "MB"
                    mem_divisor = 1.0
                    cap_label = f"capacity {mem_capacity_mb}MB"
                    cap_sub = f"{mem_capacity_mb}MB"

                mem_series = {
                    "Memory 사용량": [(pt["date"], pt["memory_mb"] / mem_divisor) for pt in daily]
                }
                mem_ref = []
                if mem_capacity_mb:
                    mem_ref = [
                        {
                            "value": mem_capacity_mb / mem_divisor,
                            "label": cap_label,
                            "color": "#dc2626",
                        }
                    ]
                mem_chart = _svg_line_chart(
                    series=mem_series,
                    colors=CHART_COLORS,
                    title=f"{node_name} — Memory",
                    subtitle=f"{instance_type} · Capacity {cap_sub}" if instance_type else "",
                    y_suffix=mem_suffix,
                    reference_lines=mem_ref,
                )

                # 2열 그리드 (CPU | Memory)
                node_charts.append(f"""
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:8px;">
                    <div>{cpu_chart}</div>
                    <div>{mem_chart}</div>
                </div>
                """)

            if node_charts:
                ng_header = f"""
                <h4 style="font-size:13px;font-weight:600;margin:0 0 8px;color:#374151;">
                    {html_escape(ng_name)}
                </h4>
                """
                parts.append(ng_header + "\n".join(node_charts))

        if not parts:
            return ""

        icon_html = self._icon("monitoring", size="sm", inline=True)
        return self._section_card(icon_html, "Node Resource 추이", "\n".join(parts))

    # ── Event Trend Charts ───────────────────────────

    EVENT_REASON_COLORS: dict[str, str] = {
        "OOMKilling": "#dc2626",
        "BackOff": "#d97706",
        "FailedScheduling": "#7c3aed",
        "Error": "#2563eb",
    }

    def _build_event_trend_charts(self, event_trends: dict[str, Any]) -> str:
        """노드 그룹별 Warning 이벤트 reason별 일별 추이 라인 차트."""
        from src.agent_server.bdp_common.reports.charts import _svg_line_chart

        node_groups = event_trends.get("node_groups", {})
        if not node_groups:
            return ""

        parts: list[str] = []
        for ng_name, ng_data in sorted(node_groups.items()):
            reasons = ng_data.get("reasons", {})
            if not reasons:
                continue

            # series: {reason: [(date, count), ...]}
            series: dict[str, list[tuple[str, float]]] = {}
            colors: list[str] = []
            for reason, daily_list in reasons.items():
                series[reason] = [(pt["date"], pt["count"]) for pt in daily_list]
                colors.append(self.EVENT_REASON_COLORS.get(reason, "#6b7280"))

            chart = _svg_line_chart(
                series=series,
                colors=colors,
                title=f"{ng_name} — Warning 이벤트",
                subtitle="노드/Pod 레벨 Warning 이벤트 일별 발생 건수",
                y_suffix="건",
                y_integer=True,
            )
            parts.append(chart)

        if not parts:
            return ""

        icon_html = self._icon("warning", size="sm", color="warning", inline=True)
        return self._section_card(icon_html, "Warning 이벤트 추이", "\n".join(parts))

    # ── Spark Cluster ─────────────────────────────────

    def _build_spark_section(self, data: HdspInfraReportData) -> str:
        """Spark 클러스터별 CPU/Memory 리소스 + Job 추이."""
        from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart

        clusters = data.spark_cluster_status.get("clusters", {})
        if not clusters:
            return ""

        parts: list[str] = []
        for cluster_name, cluster_data in sorted(clusters.items()):
            daily = cluster_data.get("daily", [])
            if not daily:
                continue

            # CPU/Memory 차트 (2열)
            cpu_series = {"CPU": [(p["date"], p.get("cpu_cores", 0)) for p in daily]}
            mem_series = {"Memory": [(p["date"], p.get("memory_gb", 0)) for p in daily]}

            cpu_chart = _svg_line_chart(
                cpu_series,
                CHART_COLORS,
                title=f"{cluster_name} — CPU",
                subtitle="일별 CPU 사용량",
                y_suffix="cores",
                height=200,
            )
            mem_chart = _svg_line_chart(
                mem_series,
                CHART_COLORS,
                title=f"{cluster_name} — Memory",
                subtitle="일별 Memory 사용량",
                y_suffix="GB",
                height=200,
            )
            parts.append(f"""
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:8px;">
                <div>{cpu_chart}</div>
                <div>{mem_chart}</div>
            </div>
            """)

            # Job 추이
            job_series = {"Jobs": [(p["date"], p.get("jobs_submitted", 0)) for p in daily]}
            parts.append(
                _svg_line_chart(
                    job_series,
                    CHART_COLORS,
                    title=f"{cluster_name} — Job 추이",
                    subtitle="일별 실행 Job 수",
                    y_suffix="건",
                    y_integer=True,
                    height=200,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("bolt", size="sm", inline=True)
        return self._section_card(icon_html, "Spark 클러스터", "\n".join(parts))

    # ── MinIO Admin ──────────────────────────────────

    def _build_minio_admin_section(self, data: HdspInfraReportData) -> str:
        """MinIO 버킷 용량 + 디스크 사용 + API 처리량."""
        from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart

        admin = data.minio_admin
        if not admin:
            return ""

        parts: list[str] = []

        # 버킷 용량 (buckets: {bucket_name: {daily: [...]}})
        buckets = admin.get("buckets", {})
        if buckets:
            bucket_series: dict[str, list[tuple[str, float]]] = {}
            for name, bucket_data in buckets.items():
                daily = bucket_data.get("daily", []) if isinstance(bucket_data, dict) else []
                if daily:
                    bucket_series[name] = [(p["date"], p.get("size_gb", 0)) for p in daily]
            if bucket_series:
                parts.append(
                    _svg_line_chart(
                        bucket_series,
                        CHART_COLORS,
                        title="MinIO 버킷 용량",
                        subtitle="버킷별 저장 용량 (GB)",
                        y_suffix="GB",
                    )
                )

        # 디스크 사용 (server: {daily: [{date, disk_used_gb, disk_total_gb}]})
        server_daily = admin.get("server", {}).get("daily", [])
        if server_daily:
            disk_series: dict[str, list[tuple[str, float]]] = {
                "사용량": [(p["date"], p.get("disk_used_gb", 0)) for p in server_daily],
            }
            parts.append(
                _svg_line_chart(
                    disk_series,
                    ["#dc2626"],
                    title="MinIO 디스크 사용량",
                    subtitle="전체 디스크 사용량 (GB)",
                    y_suffix="GB",
                )
            )

        # API 처리량 (api_throughput: {daily: [{date, get_ops, put_ops, delete_ops}]})
        api_daily = admin.get("api_throughput", {}).get("daily", [])
        if api_daily:
            api_series: dict[str, list[tuple[str, float]]] = {
                "GET": [(p["date"], p.get("get_ops", 0)) for p in api_daily],
                "PUT": [(p["date"], p.get("put_ops", 0)) for p in api_daily],
            }
            parts.append(
                _svg_line_chart(
                    api_series,
                    CHART_COLORS,
                    title="MinIO API 처리량",
                    subtitle="일별 API 요청 수",
                    y_suffix="건",
                    y_integer=True,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("inventory_2", size="sm", inline=True)
        return self._section_card(icon_html, "MinIO 관리", "\n".join(parts))

    # ── NAS IOPS ─────────────────────────────────────

    def _build_nfs_iops_section(self, data: HdspInfraReportData) -> str:
        """NAS IOPS + 지연시간."""
        from src.agent_server.bdp_common.reports.charts import _svg_line_chart

        mounts = data.nfs_iops.get("mounts", {})
        if not mounts:
            return ""

        parts: list[str] = []
        for mount_name, mount_data in sorted(mounts.items()):
            daily = mount_data.get("daily", []) if isinstance(mount_data, dict) else []
            if not daily:
                continue
            # IOPS
            iops_series: dict[str, list[tuple[str, float]]] = {
                "Read": [(p["date"], p.get("read_iops", 0)) for p in daily],
                "Write": [(p["date"], p.get("write_iops", 0)) for p in daily],
            }
            parts.append(
                _svg_line_chart(
                    iops_series,
                    ["#2563eb", "#dc2626"],
                    title=f"NAS IOPS — {mount_name}",
                    subtitle="Read / Write IOPS 추이",
                    y_suffix="IOPS",
                    height=200,
                )
            )

            # 지연시간
            lat_series: dict[str, list[tuple[str, float]]] = {
                "Latency": [(p["date"], p.get("latency_ms", 0)) for p in daily],
            }
            parts.append(
                _svg_line_chart(
                    lat_series,
                    ["#d97706"],
                    title=f"NAS Latency — {mount_name}",
                    subtitle="평균 지연시간 (ms)",
                    y_suffix="ms",
                    height=200,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("hard_drive", size="sm", inline=True)
        return self._section_card(icon_html, "NAS IOPS", "\n".join(parts))

    # ── HDSP API Latency ─────────────────────────────

    def _build_hdsp_api_latency_section(self, data: HdspInfraReportData) -> str:
        """HDSP API 응답시간(p50/p95/p99) + 요청수(RPM)."""
        from src.agent_server.bdp_common.reports.charts import _svg_line_chart

        daily = data.hdsp_api_latency.get("daily", [])
        if not daily:
            return ""

        parts: list[str] = []

        # 응답시간
        lat_series: dict[str, list[tuple[str, float]]] = {
            "P50": [(p["date"], p.get("p50_ms", 0)) for p in daily],
            "P95": [(p["date"], p.get("p95_ms", 0)) for p in daily],
            "P99": [(p["date"], p.get("p99_ms", 0)) for p in daily],
        }
        parts.append(
            _svg_line_chart(
                lat_series,
                ["#2563eb", "#d97706", "#dc2626"],
                title="HDSP API 응답시간",
                subtitle="P50 / P95 / P99 Latency (ms)",
                y_suffix="ms",
            )
        )

        # RPM
        rpm_series: dict[str, list[tuple[str, float]]] = {
            "RPM": [(p["date"], p.get("requests_per_min", 0)) for p in daily],
        }
        parts.append(
            _svg_line_chart(
                rpm_series,
                ["#16a34a"],
                title="HDSP API 요청수",
                subtitle="분당 요청수 (RPM)",
                y_suffix="req/min",
            )
        )

        icon_html = self._icon("api", size="sm", inline=True)
        return self._section_card(icon_html, "HDSP API", "\n".join(parts))

    # ── Backup ───────────────────────────────────────

    def _build_backup_section(self, data: HdspInfraReportData) -> str:
        """로그백업 현황 + 성공/실패율."""
        from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart

        parts: list[str] = []

        # 로그백업 현황 (destinations: {dest: {source: [{date, file_count, size_mb}]}})
        destinations = data.log_backup_status.get("destinations", {})
        if destinations:
            backup_series: dict[str, list[tuple[str, float]]] = {}
            for dest_name, sources in destinations.items():
                if not isinstance(sources, dict):
                    continue
                for src_name, pts in sources.items():
                    label = f"{dest_name}/{src_name}"
                    if isinstance(pts, list) and pts:
                        backup_series[label] = [(p["date"], p.get("file_count", 0)) for p in pts]
            if backup_series:
                parts.append(
                    _svg_line_chart(
                        backup_series,
                        CHART_COLORS,
                        title="로그백업 현황",
                        subtitle="저장소별 일별 백업 건수",
                        y_suffix="건",
                        y_integer=True,
                    )
                )

        # 성공/실패율 (destinations: {dest: {daily: [{date, success, failure}]}})
        rate_dests = data.backup_success_rate.get("destinations", {})
        if rate_dests:
            rate_series: dict[str, list[tuple[str, float]]] = {}
            for dest_name, dest_data in rate_dests.items():
                daily = dest_data.get("daily", []) if isinstance(dest_data, dict) else []
                if daily:
                    rate_series[dest_name] = [
                        (
                            p["date"],
                            round(
                                p.get("success", 0)
                                / max(p.get("success", 0) + p.get("failure", 0), 1)
                                * 100,
                                1,
                            ),
                        )
                        for p in daily
                    ]
            if rate_series:
                parts.append(
                    _svg_line_chart(
                        rate_series,
                        CHART_COLORS,
                        title="백업 성공률",
                        subtitle="저장소별 일별 성공률 (%)",
                        y_suffix="%",
                        y_domain=(0, 100),
                    )
                )

        if not parts:
            return ""
        icon_html = self._icon("backup", size="sm", inline=True)
        return self._section_card(icon_html, "백업", "\n".join(parts))

    # ── HAProxy ──────────────────────────────────────

    def _build_haproxy_section(self, data: HdspInfraReportData) -> str:
        """HAProxy 연결수 + 응답시간."""
        from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart

        frontends = data.haproxy_stats.get("frontends", {})
        if not frontends:
            return ""

        parts: list[str] = []
        for fe_name, fe_data in sorted(frontends.items()):
            daily = fe_data.get("daily", []) if isinstance(fe_data, dict) else []
            if not daily:
                continue
            conn_series: dict[str, list[tuple[str, float]]] = {
                "연결수": [(p["date"], p.get("connections", 0)) for p in daily],
            }
            parts.append(
                _svg_line_chart(
                    conn_series,
                    CHART_COLORS,
                    title=f"HAProxy 연결수 — {fe_name}",
                    subtitle="일별 연결 수",
                    y_suffix="건",
                    y_integer=True,
                    height=200,
                )
            )

        # Backend 응답시간
        backends = data.haproxy_stats.get("backends", {})
        for be_name, be_data in sorted(backends.items()):
            daily = be_data.get("daily", []) if isinstance(be_data, dict) else []
            if not daily:
                continue
            resp_series: dict[str, list[tuple[str, float]]] = {
                "응답시간": [(p["date"], p.get("response_time_ms", 0)) for p in daily],
            }
            parts.append(
                _svg_line_chart(
                    resp_series,
                    ["#d97706"],
                    title=f"HAProxy 응답시간 — {be_name}",
                    subtitle="평균 응답시간 (ms)",
                    y_suffix="ms",
                    height=200,
                )
            )

        if not parts:
            return ""
        icon_html = self._icon("lan", size="sm", inline=True)
        return self._section_card(icon_html, "HAProxy", "\n".join(parts))

    # ── Docker Registry ──────────────────────────────

    def _build_docker_registry_section(self, data: HdspInfraReportData) -> str:
        """Docker Registry Pulls/Pushes/Storage."""
        from src.agent_server.bdp_common.reports.charts import _svg_line_chart

        daily = data.docker_registry_stats.get("daily", [])
        if not daily:
            return ""

        parts: list[str] = []

        pp_series: dict[str, list[tuple[str, float]]] = {
            "Pulls": [(p["date"], p.get("pulls", 0)) for p in daily],
            "Pushes": [(p["date"], p.get("pushes", 0)) for p in daily],
        }
        parts.append(
            _svg_line_chart(
                pp_series,
                ["#2563eb", "#16a34a"],
                title="Docker Registry 활동",
                subtitle="일별 Pull / Push 건수",
                y_suffix="건",
                y_integer=True,
            )
        )

        storage_series: dict[str, list[tuple[str, float]]] = {
            "Storage": [(p["date"], p.get("storage_gb", 0)) for p in daily],
        }
        parts.append(
            _svg_line_chart(
                storage_series,
                ["#7c3aed"],
                title="Docker Registry 스토리지",
                subtitle="일별 스토리지 사용량 (GB)",
                y_suffix="GB",
            )
        )

        icon_html = self._icon("deployed_code", size="sm", inline=True)
        return self._section_card(icon_html, "Docker Registry", "\n".join(parts))

    # ── Warning Events ───────────────────────────────

    def _build_events_section(self, events: list[dict[str, Any]]) -> str:
        headers = ["Reason", "Object", "Message", "Count", "Last Seen"]
        rows = []
        for e in events:
            rows.append(
                [
                    html_escape(e.get("reason", "")),
                    html_escape(e.get("involved_object", "")),
                    html_escape(e.get("message", "")[:120]),
                    str(e.get("count", 1)),
                    html_escape(e.get("last_timestamp", "")),
                ]
            )

        icon_html = self._icon("warning", size="sm", color="warning", inline=True)
        table_html = self.render_table(headers, rows)
        return self._section_card(icon_html, "Warning Events", table_html)

    # ── Section Card Helper ──────────────────────────

    def _section_card(self, icon_html: str, title: str, content: str) -> str:
        return f"""
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:8px;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                {icon_html}
                <span style="font-size:14px;font-weight:600;">{html_escape(title)}</span>
            </div>
            <div style="padding:16px 20px;">
                {content}
            </div>
        </div>
        """


# ── Helpers ──────────────────────────────────────────


def _status_badge(display_status: str) -> str:
    """상태 배지 HTML."""
    color = STATUS_COLORS.get(display_status, "#6b7280")
    label = STATUS_LABELS.get(display_status, display_status)
    return (
        f'<span style="display:inline-block;padding:2px 8px;border-radius:9999px;'
        f"font-size:11px;font-weight:500;background:{color}15;"
        f'color:{color};border:1px solid {color}40;">'
        f"{html_escape(label)}</span>"
    )
