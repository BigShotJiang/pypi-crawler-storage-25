"""
HDSP Dashboard Report Store - DB storage layer for HDSP dashboard reports.

HDSP 대시보드 리포트 저장소.
Provider 패턴으로 MySQL/SQLite/Mock 지원.
"""

from __future__ import annotations

import logging
import os
import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from src.agent_server.bdp_common.stores.base import (
    BaseMySqlProvider,
    BaseSQLiteProvider,
    get_kst_now,
)

logger = logging.getLogger(__name__)


@dataclass
class HdspDashboardReport:
    """HDSP 대시보드 일일 리포트."""

    id: str
    run_timestamp: datetime
    total_services: int
    healthy: int
    warning: int
    critical: int
    summary_json: str
    html_report: str
    status: str = "completed"


class HdspDashboardReportStoreProvider(ABC):
    """HDSP 대시보드 리포트 저장소 추상 프로바이더."""

    @abstractmethod
    def ensure_tables(self) -> None:
        pass

    @abstractmethod
    def save_report(self, report: HdspDashboardReport) -> HdspDashboardReport:
        pass

    @abstractmethod
    def get_report(self, report_id: str) -> HdspDashboardReport | None:
        pass

    @abstractmethod
    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[HdspDashboardReport]:
        pass

    @abstractmethod
    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        pass


class SQLiteProvider(BaseSQLiteProvider, HdspDashboardReportStoreProvider):
    """SQLite 프로바이더 (유닛 테스트용)."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS hdsp_dashboard_reports (
                id TEXT PRIMARY KEY,
                run_timestamp TEXT NOT NULL,
                total_services INTEGER NOT NULL,
                healthy INTEGER NOT NULL,
                warning INTEGER NOT NULL,
                critical INTEGER NOT NULL,
                summary_json TEXT NOT NULL DEFAULT '',
                html_report TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'completed',
                created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_hdsp_dashboard_reports_timestamp
            ON hdsp_dashboard_reports (run_timestamp)
        """)
        self.conn.commit()

    def save_report(self, report: HdspDashboardReport) -> HdspDashboardReport:
        cursor = self.conn.cursor()
        now = get_kst_now().isoformat() + "Z"
        cursor.execute(
            """
            INSERT INTO hdsp_dashboard_reports
            (id, run_timestamp, total_services, healthy, warning, critical,
             summary_json, html_report, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                report.id,
                report.run_timestamp.isoformat()
                if isinstance(report.run_timestamp, datetime)
                else report.run_timestamp,
                report.total_services,
                report.healthy,
                report.warning,
                report.critical,
                report.summary_json,
                report.html_report,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> HdspDashboardReport | None:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM hdsp_dashboard_reports WHERE id = ?", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[HdspDashboardReport]:
        cursor = self.conn.cursor()
        conditions: list[str] = []
        params: list[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM hdsp_dashboard_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: list[str] = []
        params: list[Any] = []

        if start_date:
            conditions.append("run_timestamp >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= ?")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM hdsp_dashboard_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: sqlite3.Row) -> HdspDashboardReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))
        return HdspDashboardReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            total_services=row["total_services"],
            healthy=row["healthy"],
            warning=row["warning"],
            critical=row["critical"],
            summary_json=row["summary_json"] if "summary_json" in row.keys() else "",
            html_report=row["html_report"],
            status=row["status"],
        )


class MySqlProvider(BaseMySqlProvider, HdspDashboardReportStoreProvider):
    """MySQL HDSP 대시보드 리포트 저장소."""

    def ensure_tables(self) -> None:
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS hdsp_dashboard_reports (
                id VARCHAR(36) PRIMARY KEY,
                run_timestamp DATETIME NOT NULL,
                total_services INT NOT NULL,
                healthy INT NOT NULL,
                warning INT NOT NULL,
                critical INT NOT NULL,
                summary_json LONGTEXT NOT NULL DEFAULT '',
                html_report LONGTEXT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'completed',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_hdsp_dashboard_reports_timestamp (run_timestamp)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """)
        self.conn.commit()
        logger.info("MySQL hdsp_dashboard_reports table ensured")

    def save_report(self, report: HdspDashboardReport) -> HdspDashboardReport:
        cursor = self.conn.cursor()
        now = get_kst_now()
        cursor.execute(
            """
            INSERT INTO hdsp_dashboard_reports
            (id, run_timestamp, total_services, healthy, warning, critical,
             summary_json, html_report, status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                report.id,
                report.run_timestamp
                if isinstance(report.run_timestamp, datetime)
                else datetime.fromisoformat(report.run_timestamp),
                report.total_services,
                report.healthy,
                report.warning,
                report.critical,
                report.summary_json,
                report.html_report,
                report.status,
                now,
            ),
        )
        self.conn.commit()
        return report

    def get_report(self, report_id: str) -> HdspDashboardReport | None:
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM hdsp_dashboard_reports WHERE id = %s", (report_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_report(row)

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[HdspDashboardReport]:
        cursor = self.conn.cursor()
        conditions: list[str] = []
        params: list[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM hdsp_dashboard_reports
            {where_clause}
            ORDER BY run_timestamp DESC
            LIMIT %s OFFSET %s
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        cursor = self.conn.cursor()
        conditions: list[str] = []
        params: list[Any] = []

        if start_date:
            conditions.append("run_timestamp >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("run_timestamp <= %s")
            params.append(end_date)

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM hdsp_dashboard_reports {where_clause}",
            tuple(params),
        )
        row = cursor.fetchone()
        return row["cnt"]

    def _row_to_report(self, row: dict[str, Any]) -> HdspDashboardReport:
        run_timestamp = row["run_timestamp"]
        if isinstance(run_timestamp, str):
            run_timestamp = datetime.fromisoformat(run_timestamp.rstrip("Z"))

        return HdspDashboardReport(
            id=row["id"],
            run_timestamp=run_timestamp,
            total_services=row["total_services"],
            healthy=row["healthy"],
            warning=row["warning"],
            critical=row["critical"],
            summary_json=row.get("summary_json", ""),
            html_report=row["html_report"],
            status=row["status"],
        )


class MockProvider(HdspDashboardReportStoreProvider):
    """Mock 프로바이더 (개발/테스트용)."""

    def __init__(self):
        self._reports: dict[str, HdspDashboardReport] = {}
        logger.info("Mock HDSP dashboard report provider initialized")

    def ensure_tables(self) -> None:
        pass

    def save_report(self, report: HdspDashboardReport) -> HdspDashboardReport:
        self._reports[report.id] = report
        return report

    def get_report(self, report_id: str) -> HdspDashboardReport | None:
        return self._reports.get(report_id)

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[HdspDashboardReport]:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        reports.sort(key=lambda r: r.run_timestamp, reverse=True)
        return reports[offset : offset + limit]

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        reports = list(self._reports.values())
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            reports = [r for r in reports if r.run_timestamp >= start_dt]
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            reports = [r for r in reports if r.run_timestamp <= end_dt]
        return len(reports)


class HdspDashboardReportStore:
    """HDSP 대시보드 리포트 저장소 (Facade).

    Provider 패턴으로 MySQL/SQLite/Mock 지원.
    """

    def __init__(
        self,
        provider: str = "mock",
        secret_id: str | None = None,
        db: str | None = None,
    ):
        self.provider_type = provider
        self._provider = self._create_provider(provider, secret_id, db)
        logger.info(f"HdspDashboardReportStore initialized with {provider} provider")

    def _create_provider(
        self, provider: str, secret_id: str | None = None, db: str | None = None
    ) -> HdspDashboardReportStoreProvider:
        if provider == "sqlite":
            db_path = os.getenv("REPORT_SQLITE_PATH", ":memory:")
            return SQLiteProvider(db_path)
        elif provider == "mysql":
            if not secret_id:
                raise ValueError("secret_id is required for MySQL provider")
            region = os.getenv("AWS_REGION", "ap-northeast-2")
            return MySqlProvider(secret_id=secret_id, db=db or "", region=region)
        else:
            return MockProvider()

    def ensure_tables(self) -> None:
        self._provider.ensure_tables()

    def save_report(self, report: HdspDashboardReport) -> HdspDashboardReport:
        return self._provider.save_report(report)

    def get_report(self, report_id: str) -> HdspDashboardReport | None:
        return self._provider.get_report(report_id)

    def list_reports(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[HdspDashboardReport]:
        return self._provider.list_reports(
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            offset=offset,
        )

    def get_report_count(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> int:
        return self._provider.get_report_count(
            start_date=start_date,
            end_date=end_date,
        )
