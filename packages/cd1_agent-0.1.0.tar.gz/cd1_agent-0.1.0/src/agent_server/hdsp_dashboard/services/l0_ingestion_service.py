"""L0 Ingestion 현황 데이터 서비스.

HDSP 서비스 대시보드의 L0 입수 현황 차트 데이터를 제공.
프론트엔드에서 하드코딩되어 있던 mock 데이터를 Agent Server에서 제공.
추후 실제 데이터 소스 연동으로 교체 예정.
"""

from __future__ import annotations

import logging
import random
from datetime import datetime

logger = logging.getLogger(__name__)

L0_SOURCES = [
    {"name": "BCV", "color": "#2563eb", "avg": 50},
    {"name": "DW", "color": "#16a34a", "avg": 30},
    {"name": "EAI", "color": "#d97706", "avg": 25},
    {"name": "CDC", "color": "#dc2626", "avg": 40},
    {"name": "FTP", "color": "#7c3aed", "avg": 15},
    {"name": "API", "color": "#0891b2", "avg": 35},
    {"name": "S3", "color": "#db2777", "avg": 20},
    {"name": "Kafka", "color": "#65a30d", "avg": 45},
    {"name": "SFTP", "color": "#ea580c", "avg": 12},
    {"name": "MQ", "color": "#6366f1", "avg": 18},
]


class L0IngestionService:
    """L0 입수 현황 데이터."""

    def get_l0_data(self) -> dict:
        daily = self._generate_daily_data()
        monthly = self._generate_monthly_data()

        return {
            "sources": L0_SOURCES,
            "daily": daily,
            "monthly": monthly,
        }

    def _generate_daily_data(self) -> dict:
        now = datetime.now()
        start = datetime(now.year, now.month, 1)
        end = datetime(now.year, now.month, now.day)

        success_rows: list[dict] = []
        failure_rows: list[dict] = []

        d = start
        while d <= end:
            date_str = d.strftime("%Y-%m-%d")
            s_row: dict = {"date": date_str}
            f_row: dict = {"date": date_str}

            for src in L0_SOURCES:
                avg = src["avg"]
                total = avg + int((random.random() - 0.5) * avg * 0.4)
                fail_rate = 0.02 + random.random() * 0.08
                fail = max(0, round(total * fail_rate))
                s_row[src["name"]] = max(0, total - fail)
                f_row[src["name"]] = fail

            success_rows.append(s_row)
            failure_rows.append(f_row)
            d = datetime(d.year, d.month, d.day + 1) if d.day < 28 else self._next_day(d)

        return {"successRows": success_rows, "failureRows": failure_rows}

    def _generate_monthly_data(self) -> dict:
        today = datetime.now()
        current_month = f"{today.year}-{today.month:02d}"

        # 최근 6개월
        months: list[str] = []
        for i in range(5, -1, -1):
            y = today.year
            m = today.month - i
            while m <= 0:
                m += 12
                y -= 1
            months.append(f"{y}-{m:02d}")

        success_rows: list[dict] = []
        failure_rows: list[dict] = []

        for month in months:
            s_row: dict = {"month": month}
            f_row: dict = {"month": month}
            days_in_month = today.day if month == current_month else 30

            for src in L0_SOURCES:
                avg = src["avg"]
                total_month = avg * days_in_month + int(
                    (random.random() - 0.5) * avg * days_in_month * 0.2
                )
                fail_rate = 0.03 + random.random() * 0.05
                fail = max(0, round(total_month * fail_rate))
                s_row[src["name"]] = max(0, total_month - fail)
                f_row[src["name"]] = fail

            success_rows.append(s_row)
            failure_rows.append(f_row)

        return {"successRows": success_rows, "failureRows": failure_rows}

    @staticmethod
    def _next_day(d: datetime) -> datetime:
        """다음 날짜 계산 (월말 처리 포함)."""
        import calendar

        last_day = calendar.monthrange(d.year, d.month)[1]
        if d.day >= last_day:
            if d.month == 12:
                return datetime(d.year + 1, 1, 1)
            return datetime(d.year, d.month + 1, 1)
        return datetime(d.year, d.month, d.day + 1)
