"""HDSP Metrics 공통 유틸리티."""

from datetime import datetime, timedelta

from src.common.timezone import KST


def _parse_cpu_mc(s: str) -> int:
    """K8s CPU 문자열을 millicores로 변환. '250m'→250, '1'→1000, '2'→2000."""
    s = s.strip()
    if not s:
        return 0
    if s.endswith("m"):
        return int(s[:-1])
    return int(float(s) * 1000)


def _parse_memory_mb(s: str) -> int:
    """K8s 메모리 문자열을 MB로 변환. '256Mi'→256, '1Gi'→1024."""
    s = s.strip()
    if not s:
        return 0
    if s.endswith("Gi"):
        return int(float(s[:-2]) * 1024)
    if s.endswith("Mi"):
        return int(float(s[:-2]))
    if s.endswith("Ki"):
        return int(float(s[:-2]) / 1024)
    return int(float(s))


def _daily_dates(days: int = 31) -> list[str]:
    """최근 N일간 날짜 목록 생성 (오래된 순, KST 기준)."""
    today = datetime.now(KST).date()
    return [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
