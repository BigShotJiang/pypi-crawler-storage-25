"""K8s Infra Service - Kubernetes 인프라 리소스 현황 대시보드."""

import logging
import random
import time
from datetime import datetime, timedelta

from src.common.timezone import KST
from typing import Any

from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)

# 5분 TTL 캐시
_CACHE_TTL = 300

# K8s 상태 → 대시보드 표시 상태 매핑
_NODE_DISPLAY_STATUS: dict[str, str] = {
    "Ready": "ok",
    "NotReady": "critical",
    "Unknown": "warning",
}

_POD_DISPLAY_STATUS: dict[str, str] = {
    "Running": "ok",
    "Succeeded": "ok",
    "Pending": "warning",
    "Failed": "critical",
    "Unknown": "warning",
}

_DEPLOY_DISPLAY_STATUS: dict[str, str] = {
    "ok": "ok",
    "degraded": "warning",
    "unavailable": "critical",
}


# ── Dev Mock 헬퍼 ──────────────────────────────────


def _conditions_ok(t: str) -> list[dict[str, str]]:
    return [
        {"type": "PodScheduled", "status": "True", "last_transition": t},
        {"type": "Initialized", "status": "True", "last_transition": t},
        {"type": "ContainersReady", "status": "True", "last_transition": t},
        {"type": "Ready", "status": "True", "last_transition": t},
    ]


def _conditions_fail(t: str, reason: str) -> list[dict[str, str]]:
    return [
        {"type": "PodScheduled", "status": "True", "last_transition": t},
        {"type": "Initialized", "status": "True", "last_transition": t},
        {"type": "ContainersReady", "status": "False", "reason": reason, "last_transition": t},
        {"type": "Ready", "status": "False", "reason": reason, "last_transition": t},
    ]


def _conditions_pending(t: str, reason: str) -> list[dict[str, str]]:
    return [
        {"type": "PodScheduled", "status": "False", "reason": reason, "last_transition": t},
    ]


# ── Dev Mock 데이터 ──────────────────────────────────


def _mock_nodes() -> list[dict[str, Any]]:
    return [
        {
            "name": "master-node-1",
            "status": "Ready",
            "display_status": "ok",
            "roles": ["control-plane", "master"],
            "cpu_capacity": "16",
            "memory_capacity": "64Gi",
            "pod_count": 32,
            "node_group": "",
            "instance_type": "m5.4xlarge",
        },
        {
            "name": "worker-node-1",
            "status": "Ready",
            "display_status": "ok",
            "roles": ["worker"],
            "cpu_capacity": "8",
            "memory_capacity": "32Gi",
            "pod_count": 25,
            "node_group": "general-workers",
            "instance_type": "m5.2xlarge",
        },
        {
            "name": "worker-node-2",
            "status": "Ready",
            "display_status": "ok",
            "roles": ["worker"],
            "cpu_capacity": "8",
            "memory_capacity": "32Gi",
            "pod_count": 28,
            "node_group": "general-workers",
            "instance_type": "m5.2xlarge",
        },
        {
            "name": "worker-node-3",
            "status": "Ready",
            "display_status": "ok",
            "roles": ["worker"],
            "cpu_capacity": "16",
            "memory_capacity": "64Gi",
            "pod_count": 22,
            "node_group": "compute-optimized",
            "instance_type": "c5.4xlarge",
        },
        {
            "name": "worker-node-4",
            "status": "NotReady",
            "display_status": "critical",
            "roles": ["worker"],
            "cpu_capacity": "8",
            "memory_capacity": "32Gi",
            "pod_count": 0,
            "node_group": "compute-optimized",
            "instance_type": "c5.2xlarge",
        },
    ]


def _mock_pods() -> list[dict[str, Any]]:
    _p = {  # 공통 필드 축약용
        "ok": "ok",
        "crit": "critical",
        "warn": "warning",
    }
    return [
        # ── default ──
        {
            "name": "app-backend-0",
            "namespace": "default",
            "node_name": "worker-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "app-backend:1.4.2",
            "cpu_request": "250m",
            "cpu_limit": "500m",
            "memory_request": "256Mi",
            "memory_limit": "512Mi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-22T03:10:00Z",
            "conditions": _conditions_ok("2026-02-22T03:10:00Z"),
        },
        {
            "name": "app-backend-1",
            "namespace": "default",
            "node_name": "worker-node-2",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "app-backend:1.4.2",
            "cpu_request": "250m",
            "cpu_limit": "500m",
            "memory_request": "256Mi",
            "memory_limit": "512Mi",
            "restart_count": 1,
            "container_state": "running",
            "started_at": "2026-02-22T03:10:05Z",
            "conditions": _conditions_ok("2026-02-22T03:10:05Z"),
        },
        {
            "name": "app-backend-failed",
            "namespace": "default",
            "node_name": "worker-node-1",
            "phase": "Failed",
            "display_status": _p["crit"],
            "image": "app-backend:1.4.2",
            "cpu_request": "250m",
            "cpu_limit": "500m",
            "memory_request": "256Mi",
            "memory_limit": "512Mi",
            "restart_count": 5,
            "container_state": "terminated",
            "container_state_reason": "OOMKilled",
            "started_at": "2026-02-22T01:00:00Z",
            "conditions": _conditions_fail("2026-02-22T01:05:00Z", "ContainersNotReady"),
        },
        # ── hdsp ──
        {
            "name": "hdsp-api-server-0",
            "namespace": "hdsp",
            "node_name": "worker-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "hdsp-api:2.1.0",
            "cpu_request": "500m",
            "cpu_limit": "1",
            "memory_request": "512Mi",
            "memory_limit": "1Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-21T12:00:00Z",
            "conditions": _conditions_ok("2026-02-21T12:00:00Z"),
        },
        {
            "name": "hdsp-worker-0",
            "namespace": "hdsp",
            "node_name": "worker-node-2",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "hdsp-worker:2.1.0",
            "cpu_request": "1",
            "cpu_limit": "2",
            "memory_request": "1Gi",
            "memory_limit": "2Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-21T12:00:10Z",
            "conditions": _conditions_ok("2026-02-21T12:00:10Z"),
        },
        {
            "name": "hdsp-worker-1",
            "namespace": "hdsp",
            "node_name": "worker-node-3",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "hdsp-worker:2.1.0",
            "cpu_request": "1",
            "cpu_limit": "2",
            "memory_request": "1Gi",
            "memory_limit": "2Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-21T12:00:15Z",
            "conditions": _conditions_ok("2026-02-21T12:00:15Z"),
        },
        # ── spark ──
        {
            "name": "spark-driver-0",
            "namespace": "spark",
            "node_name": "worker-node-3",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "spark:3.5.1",
            "cpu_request": "1",
            "cpu_limit": "2",
            "memory_request": "2Gi",
            "memory_limit": "4Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-22T06:00:00Z",
            "conditions": _conditions_ok("2026-02-22T06:00:00Z"),
        },
        {
            "name": "spark-exec-0",
            "namespace": "spark",
            "node_name": "worker-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "spark:3.5.1",
            "cpu_request": "2",
            "cpu_limit": "4",
            "memory_request": "4Gi",
            "memory_limit": "8Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-22T06:00:05Z",
            "conditions": _conditions_ok("2026-02-22T06:00:05Z"),
        },
        {
            "name": "spark-exec-1",
            "namespace": "spark",
            "node_name": "worker-node-2",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "spark:3.5.1",
            "cpu_request": "2",
            "cpu_limit": "4",
            "memory_request": "4Gi",
            "memory_limit": "8Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-22T06:00:10Z",
            "conditions": _conditions_ok("2026-02-22T06:00:10Z"),
        },
        {
            "name": "spark-exec-failed",
            "namespace": "spark",
            "node_name": "worker-node-3",
            "phase": "Failed",
            "display_status": _p["crit"],
            "image": "spark:3.5.1",
            "cpu_request": "2",
            "cpu_limit": "4",
            "memory_request": "4Gi",
            "memory_limit": "8Gi",
            "restart_count": 3,
            "container_state": "terminated",
            "container_state_reason": "Error",
            "started_at": "2026-02-22T05:30:00Z",
            "conditions": _conditions_fail("2026-02-22T05:35:00Z", "ContainersNotReady"),
        },
        {
            "name": "spark-driver-pending",
            "namespace": "spark",
            "node_name": "",
            "phase": "Pending",
            "display_status": _p["warn"],
            "image": "spark:3.5.1",
            "cpu_request": "1",
            "cpu_limit": "2",
            "memory_request": "2Gi",
            "memory_limit": "4Gi",
            "restart_count": 0,
            "container_state": "waiting",
            "container_state_reason": "Unschedulable",
            "started_at": "",
            "conditions": _conditions_pending("2026-02-22T07:00:00Z", "Unschedulable"),
        },
        # ── monitoring ──
        {
            "name": "prometheus-0",
            "namespace": "monitoring",
            "node_name": "worker-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "prom/prometheus:v2.51.0",
            "cpu_request": "500m",
            "cpu_limit": "1",
            "memory_request": "1Gi",
            "memory_limit": "2Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-20T00:00:00Z",
            "conditions": _conditions_ok("2026-02-20T00:00:00Z"),
        },
        {
            "name": "grafana-0",
            "namespace": "monitoring",
            "node_name": "worker-node-2",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "grafana/grafana:10.4.1",
            "cpu_request": "200m",
            "cpu_limit": "500m",
            "memory_request": "256Mi",
            "memory_limit": "512Mi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-20T00:01:00Z",
            "conditions": _conditions_ok("2026-02-20T00:01:00Z"),
        },
        # ── kube-system ──
        {
            "name": "coredns-0",
            "namespace": "kube-system",
            "node_name": "master-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "coredns/coredns:1.11.1",
            "cpu_request": "100m",
            "cpu_limit": "200m",
            "memory_request": "70Mi",
            "memory_limit": "170Mi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-15T00:00:00Z",
            "conditions": _conditions_ok("2026-02-15T00:00:00Z"),
        },
        {
            "name": "kube-proxy-0",
            "namespace": "kube-system",
            "node_name": "master-node-1",
            "phase": "Running",
            "display_status": _p["ok"],
            "image": "kube-proxy:v1.29.2",
            "cpu_request": "100m",
            "cpu_limit": "",
            "memory_request": "64Mi",
            "memory_limit": "",
            "restart_count": 0,
            "container_state": "running",
            "started_at": "2026-02-15T00:00:00Z",
            "conditions": _conditions_ok("2026-02-15T00:00:00Z"),
        },
    ]


def _mock_deployments() -> list[dict[str, Any]]:
    return [
        {
            "name": "hdsp-api-server",
            "namespace": "hdsp",
            "replicas": 3,
            "available": 3,
            "unavailable": 0,
            "display_status": "ok",
        },
        {
            "name": "hdsp-worker",
            "namespace": "hdsp",
            "replicas": 5,
            "available": 5,
            "unavailable": 0,
            "display_status": "ok",
        },
        {
            "name": "spark-operator",
            "namespace": "spark",
            "replicas": 2,
            "available": 2,
            "unavailable": 0,
            "display_status": "ok",
        },
        {
            "name": "prometheus-server",
            "namespace": "monitoring",
            "replicas": 1,
            "available": 1,
            "unavailable": 0,
            "display_status": "ok",
        },
        {
            "name": "app-backend",
            "namespace": "default",
            "replicas": 3,
            "available": 2,
            "unavailable": 1,
            "display_status": "warning",
        },
    ]


def _mock_events() -> list[dict[str, Any]]:
    return [
        {
            "type": "Normal",
            "reason": "Scheduled",
            "message": "Successfully assigned default/app-backend-0 to worker-node-1",
            "involved_object": "app-backend-0",
            "involved_kind": "Pod",
            "namespace": "default",
            "count": 1,
            "source": "default-scheduler",
            "last_timestamp": "2026-02-22T03:09:55Z",
        },
        {
            "type": "Normal",
            "reason": "Pulled",
            "message": 'Container image "app-backend:1.4.2" already present on machine',
            "involved_object": "app-backend-0",
            "involved_kind": "Pod",
            "namespace": "default",
            "count": 1,
            "source": "kubelet",
            "last_timestamp": "2026-02-22T03:09:58Z",
        },
        {
            "type": "Normal",
            "reason": "Started",
            "message": "Started container app-backend",
            "involved_object": "app-backend-0",
            "involved_kind": "Pod",
            "namespace": "default",
            "count": 1,
            "source": "kubelet",
            "last_timestamp": "2026-02-22T03:10:00Z",
        },
        {
            "type": "Warning",
            "reason": "OOMKilling",
            "message": "Memory cgroup out of memory: Killed process 1234 (app-backend)",
            "involved_object": "app-backend-failed",
            "involved_kind": "Pod",
            "namespace": "default",
            "count": 5,
            "source": "kubelet",
            "last_timestamp": "2026-02-22T01:05:00Z",
        },
        {
            "type": "Warning",
            "reason": "BackOff",
            "message": "Back-off restarting failed container app-backend",
            "involved_object": "app-backend-failed",
            "involved_kind": "Pod",
            "namespace": "default",
            "count": 5,
            "source": "kubelet",
            "last_timestamp": "2026-02-22T01:10:00Z",
        },
        {
            "type": "Warning",
            "reason": "FailedScheduling",
            "message": "0/4 nodes are available: insufficient cpu",
            "involved_object": "spark-driver-pending",
            "involved_kind": "Pod",
            "namespace": "spark",
            "count": 12,
            "source": "default-scheduler",
            "last_timestamp": "2026-02-22T07:05:00Z",
        },
        {
            "type": "Warning",
            "reason": "Error",
            "message": "Container spark-executor exited with code 137",
            "involved_object": "spark-exec-failed",
            "involved_kind": "Pod",
            "namespace": "spark",
            "count": 3,
            "source": "kubelet",
            "last_timestamp": "2026-02-22T05:35:00Z",
        },
    ]


def _mock_services() -> list[dict[str, Any]]:
    return [
        {
            "name": "app-backend-svc",
            "namespace": "default",
            "type": "ClusterIP",
            "cluster_ip": "10.100.1.10",
            "ports": [{"port": 80, "target_port": 8080, "protocol": "TCP"}],
            "selector": "app=app-backend",
        },
        {
            "name": "hdsp-api-svc",
            "namespace": "hdsp",
            "type": "ClusterIP",
            "cluster_ip": "10.100.2.10",
            "ports": [{"port": 443, "target_port": 8443, "protocol": "TCP"}],
            "selector": "app=hdsp-api",
        },
        {
            "name": "hdsp-worker-svc",
            "namespace": "hdsp",
            "type": "ClusterIP",
            "cluster_ip": "10.100.2.20",
            "ports": [{"port": 8080, "target_port": 8080, "protocol": "TCP"}],
            "selector": "app=hdsp-worker",
        },
        {
            "name": "prometheus-svc",
            "namespace": "monitoring",
            "type": "ClusterIP",
            "cluster_ip": "10.100.3.10",
            "ports": [{"port": 9090, "target_port": 9090, "protocol": "TCP"}],
            "selector": "app=prometheus",
        },
        {
            "name": "spark-driver-svc",
            "namespace": "spark",
            "type": "ClusterIP",
            "cluster_ip": "10.100.4.10",
            "ports": [{"port": 4040, "target_port": 4040, "protocol": "TCP"}],
            "selector": "app=spark-driver",
        },
    ]


def _mock_ingresses() -> list[dict[str, Any]]:
    return [
        {
            "name": "app-ingress",
            "namespace": "default",
            "class": "nginx",
            "rules": [
                {
                    "host": "app.example.com",
                    "paths": [{"path": "/", "service": "app-backend-svc", "port": 80}],
                }
            ],
        },
        {
            "name": "monitoring-ingress",
            "namespace": "monitoring",
            "class": "nginx",
            "rules": [
                {
                    "host": "prometheus.example.com",
                    "paths": [{"path": "/", "service": "prometheus-svc", "port": 9090}],
                },
            ],
        },
        {
            "name": "hdsp-ingress",
            "namespace": "hdsp",
            "class": "nginx",
            "rules": [
                {
                    "host": "hdsp-api.example.com",
                    "paths": [{"path": "/api", "service": "hdsp-api-svc", "port": 443}],
                }
            ],
        },
    ]


def _mock_summary() -> dict[str, int]:
    return {
        "total_nodes": 5,
        "ready_nodes": 4,
        "total_pods": 16,
        "running_pods": 13,
        "failed_pods": 2,
        "pending_pods": 1,
    }


class K8sInfraService:
    """Kubernetes 인프라 리소스 현황을 조회하는 서비스."""

    def __init__(self, settings: PortalSettings):
        self.settings = settings
        self._cache: dict[str, Any] | None = None
        self._cache_time: float = 0

    def _get_k8s_clients(self):
        """CoreV1Api, AppsV1Api 클라이언트 반환."""
        from kubernetes import client, config

        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()

        return client.CoreV1Api(), client.AppsV1Api()

    def get_dashboard_data(self) -> dict[str, Any]:
        """대시보드 데이터 조회 (5분 캐시)."""
        now = time.time()
        if self._cache and (now - self._cache_time) < _CACHE_TTL:
            return self._cache

        is_dev = self.settings.environment == "test"

        try:
            core_v1, apps_v1 = self._get_k8s_clients()
            pods = self._fetch_pods(core_v1)
            node_pod_counts: dict[str, int] = {}
            for pod in pods:
                nn = pod.get("node_name", "")
                if nn:
                    node_pod_counts[nn] = node_pod_counts.get(nn, 0) + 1
            nodes = self._fetch_nodes(core_v1, node_pod_counts)
            deployments = self._fetch_deployments(apps_v1)
            services = self._fetch_services(core_v1)
            ingresses = self._fetch_ingresses()
            events = self._fetch_events(core_v1)
            namespaces = self._aggregate_namespaces(pods)
            summary = self._build_summary(nodes, namespaces)
            cluster_name = self._get_cluster_name()
        except Exception as e:
            logger.warning(f"K8s API 조회 실패: {e}")
            if is_dev:
                logger.info("dev 모드 mock 데이터 사용")
                nodes = _mock_nodes()
                pods = _mock_pods()
                deployments = _mock_deployments()
                services = _mock_services()
                ingresses = _mock_ingresses()
                events = _mock_events()
                namespaces = self._aggregate_namespaces(pods)
                summary = _mock_summary()
                cluster_name = "on-prem-k8s (mock)"
            else:
                raise

        result = {
            "summary": summary,
            "nodes": nodes,
            "pods": pods,
            "namespaces": namespaces,
            "deployments": deployments,
            "services": services,
            "ingresses": ingresses,
            "events": events,
            "cluster_name": cluster_name,
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

        self._cache = result
        self._cache_time = now
        return result

    def _get_cluster_name(self) -> str:
        """클러스터 이름 추출 (kube config context)."""
        try:
            from kubernetes import config

            _, context = config.list_kube_config_contexts()
            return context.get("context", {}).get("cluster", "on-prem-k8s")
        except Exception:
            return "on-prem-k8s"

    def _fetch_nodes(self, core_v1, pod_counts: dict[str, int] | None = None) -> list[dict[str, Any]]:
        """노드 목록 조회."""
        node_list = core_v1.list_node()
        results = []
        for node in node_list.items:
            # 노드 상태 추출
            status = "Unknown"
            for condition in node.status.conditions or []:
                if condition.type == "Ready":
                    status = "Ready" if condition.status == "True" else "NotReady"
                    break

            # 역할 추출
            roles = []
            for label_key in node.metadata.labels or {}:
                if label_key.startswith("node-role.kubernetes.io/"):
                    roles.append(label_key.split("/")[-1])
            if not roles:
                roles = ["worker"]

            # 노드그룹 및 인스턴스 타입 추출
            labels = node.metadata.labels or {}
            node_group = labels.get("eks.amazonaws.com/nodegroup", "")
            instance_type = labels.get("node.kubernetes.io/instance-type", "")

            # capacity 추출
            capacity = node.status.capacity or {}
            allocatable = node.status.allocatable or {}

            # 해당 노드의 파드 수 (사전 집계된 데이터 사용)
            pod_count = (pod_counts or {}).get(node.metadata.name, 0)

            results.append(
                {
                    "name": node.metadata.name,
                    "status": status,
                    "display_status": _NODE_DISPLAY_STATUS.get(status, "warning"),
                    "roles": roles,
                    "cpu_capacity": capacity.get("cpu", "0"),
                    "memory_capacity": allocatable.get("memory", "0"),
                    "pod_count": pod_count,
                    "node_group": node_group,
                    "instance_type": instance_type,
                }
            )
        return results

    def _fetch_pods(self, core_v1) -> list[dict[str, Any]]:
        """전체 파드 목록 조회 (개별 파드 데이터)."""
        pod_list = core_v1.list_pod_for_all_namespaces()
        results = []
        for pod in pod_list.items:
            phase = pod.status.phase or "Unknown"
            if phase == "Succeeded":
                continue  # 완료된 Job 파드 제외

            # 첫 번째 컨테이너에서 리소스/상태 추출
            container = pod.spec.containers[0] if pod.spec.containers else None
            resources = container.resources if container else None
            requests = resources.requests or {} if resources else {}
            limits = resources.limits or {} if resources else {}

            # 컨테이너 상태 추출
            container_state = "waiting"
            container_state_reason = ""
            started_at = ""
            restart_count = 0
            if pod.status.container_statuses:
                cs = pod.status.container_statuses[0]
                restart_count = cs.restart_count or 0
                if cs.state:
                    if cs.state.running:
                        container_state = "running"
                        started_at = (
                            cs.state.running.started_at.strftime("%Y-%m-%dT%H:%M:%SZ")
                            if cs.state.running.started_at
                            else ""
                        )
                    elif cs.state.terminated:
                        container_state = "terminated"
                        container_state_reason = cs.state.terminated.reason or ""
                    elif cs.state.waiting:
                        container_state = "waiting"
                        container_state_reason = cs.state.waiting.reason or ""

            # Conditions 추출
            conditions = []
            if pod.status.conditions:
                for cond in pod.status.conditions:
                    c: dict[str, str] = {
                        "type": cond.type,
                        "status": cond.status,
                        "last_transition": (
                            cond.last_transition_time.strftime("%Y-%m-%dT%H:%M:%SZ")
                            if cond.last_transition_time
                            else ""
                        ),
                    }
                    if cond.reason:
                        c["reason"] = cond.reason
                    conditions.append(c)

            entry: dict[str, Any] = {
                "name": pod.metadata.name,
                "namespace": pod.metadata.namespace,
                "node_name": pod.spec.node_name or "",
                "phase": phase,
                "display_status": _POD_DISPLAY_STATUS.get(phase, "warning"),
                "image": container.image if container else "",
                "cpu_request": requests.get("cpu", ""),
                "cpu_limit": limits.get("cpu", ""),
                "memory_request": requests.get("memory", ""),
                "memory_limit": limits.get("memory", ""),
                "restart_count": restart_count,
                "container_state": container_state,
                "started_at": started_at,
                "conditions": conditions,
            }
            if container_state_reason:
                entry["container_state_reason"] = container_state_reason

            results.append(entry)
        return results

    @staticmethod
    def _aggregate_namespaces(pods: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
        """파드 목록에서 네임스페이스별 상태 집계."""
        ns_stats: dict[str, dict[str, int]] = {}
        for pod in pods:
            ns = pod["namespace"]
            phase = pod["phase"]
            if ns not in ns_stats:
                ns_stats[ns] = {"running": 0, "pending": 0, "failed": 0}
            if phase == "Running":
                ns_stats[ns]["running"] += 1
            elif phase == "Pending":
                ns_stats[ns]["pending"] += 1
            elif phase == "Failed":
                ns_stats[ns]["failed"] += 1
        return ns_stats

    def _fetch_deployments(self, apps_v1) -> list[dict[str, Any]]:
        """디플로이먼트 목록 조회."""
        deploy_list = apps_v1.list_deployment_for_all_namespaces()
        results = []
        for deploy in deploy_list.items:
            replicas = deploy.spec.replicas or 0
            status = deploy.status
            available = status.available_replicas or 0
            unavailable = status.unavailable_replicas or 0

            if unavailable > 0:
                display = "warning" if available > 0 else "critical"
            else:
                display = "ok"

            results.append(
                {
                    "name": deploy.metadata.name,
                    "namespace": deploy.metadata.namespace,
                    "replicas": replicas,
                    "available": available,
                    "unavailable": unavailable,
                    "display_status": display,
                }
            )
        return results

    def _build_summary(
        self,
        nodes: list[dict[str, Any]],
        namespaces: dict[str, dict[str, int]],
    ) -> dict[str, int]:
        """요약 카드 데이터 생성."""
        total_nodes = len(nodes)
        ready_nodes = sum(1 for n in nodes if n["status"] == "Ready")

        total_pods = 0
        running_pods = 0
        failed_pods = 0
        pending_pods = 0

        for ns_stats in namespaces.values():
            running_pods += ns_stats.get("running", 0)
            pending_pods += ns_stats.get("pending", 0)
            failed_pods += ns_stats.get("failed", 0)

        total_pods = running_pods + pending_pods + failed_pods

        return {
            "total_nodes": total_nodes,
            "ready_nodes": ready_nodes,
            "total_pods": total_pods,
            "running_pods": running_pods,
            "failed_pods": failed_pods,
            "pending_pods": pending_pods,
        }

    def _fetch_services(self, core_v1) -> list[dict[str, Any]]:
        """서비스 목록 조회."""
        svc_list = core_v1.list_service_for_all_namespaces()
        results = []
        for svc in svc_list.items:
            selector = svc.spec.selector or {}
            selector_str = ",".join(f"{k}={v}" for k, v in selector.items())
            ports = []
            for p in svc.spec.ports or []:
                ports.append(
                    {
                        "port": p.port,
                        "target_port": p.target_port,
                        "protocol": p.protocol or "TCP",
                    }
                )
            results.append(
                {
                    "name": svc.metadata.name,
                    "namespace": svc.metadata.namespace,
                    "type": svc.spec.type or "ClusterIP",
                    "cluster_ip": svc.spec.cluster_ip or "",
                    "ports": ports,
                    "selector": selector_str,
                }
            )
        return results

    def _fetch_ingresses(self) -> list[dict[str, Any]]:
        """인그레스 목록 조회."""
        from kubernetes import client

        networking_v1 = client.NetworkingV1Api()
        ing_list = networking_v1.list_ingress_for_all_namespaces()
        results = []
        for ing in ing_list.items:
            ing_class = ing.spec.ingress_class_name or (ing.metadata.annotations or {}).get(
                "kubernetes.io/ingress.class", ""
            )
            rules = []
            for rule in ing.spec.rules or []:
                paths = []
                for path in rule.http.paths if rule.http else []:
                    paths.append(
                        {
                            "path": path.path or "/",
                            "service": path.backend.service.name
                            if path.backend and path.backend.service
                            else "",
                            "port": (
                                path.backend.service.port.number
                                if path.backend
                                and path.backend.service
                                and path.backend.service.port
                                else 0
                            ),
                        }
                    )
                rules.append({"host": rule.host or "*", "paths": paths})
            results.append(
                {
                    "name": ing.metadata.name,
                    "namespace": ing.metadata.namespace,
                    "class": ing_class,
                    "rules": rules,
                }
            )
        return results

    def _fetch_events(self, core_v1) -> list[dict[str, Any]]:
        """클러스터 이벤트 조회."""
        event_list = core_v1.list_event_for_all_namespaces()
        results = []
        for event in event_list.items:
            results.append(
                {
                    "type": event.type or "Normal",
                    "reason": event.reason or "",
                    "message": event.message or "",
                    "involved_object": event.involved_object.name if event.involved_object else "",
                    "involved_kind": event.involved_object.kind if event.involved_object else "",
                    "namespace": event.metadata.namespace or "",
                    "count": event.count or 1,
                    "source": event.source.component if event.source else "",
                    "last_timestamp": (
                        event.last_timestamp.strftime("%Y-%m-%dT%H:%M:%SZ")
                        if event.last_timestamp
                        else ""
                    ),
                }
            )
        return results

    def get_pod_logs(
        self,
        pod_name: str,
        namespace: str,
        container: str | None = None,
        tail_lines: int = 200,
        since_seconds: int = 3600,
    ) -> dict[str, Any]:
        """K8s 파드 로그 조회.

        Args:
            pod_name: 파드 이름
            namespace: 네임스페이스
            container: 컨테이너 이름 (None이면 첫 번째 컨테이너)
            tail_lines: 조회할 최근 로그 줄 수
            since_seconds: 이 시간(초) 이내의 로그만 조회
        """
        is_dev = self.settings.environment == "test"

        try:
            core_v1, _ = self._get_k8s_clients()
            kwargs: dict[str, Any] = {
                "name": pod_name,
                "namespace": namespace,
                "tail_lines": tail_lines,
                "since_seconds": since_seconds,
                "timestamps": True,
            }
            if container:
                kwargs["container"] = container

            raw_log = core_v1.read_namespaced_pod_log(**kwargs)
            logs = self._parse_pod_log_lines(raw_log)
        except Exception as e:
            logger.warning(f"K8s pod log 조회 실패: {namespace}/{pod_name}: {e}")
            if is_dev:
                logs = self._mock_pod_logs(pod_name, namespace, tail_lines, since_seconds)
            else:
                raise

        truncated = len(logs) >= tail_lines
        return {
            "pod_name": pod_name,
            "namespace": namespace,
            "logs": logs,
            "count": len(logs),
            "truncated": truncated,
            "success": True,
        }

    @staticmethod
    def _parse_pod_log_lines(raw_log: str) -> list[dict[str, Any]]:
        """타임스탬프 포함 로그 문자열을 파싱."""
        lines = raw_log.strip().split("\n") if raw_log else []
        results = []
        for line in lines:
            if not line.strip():
                continue
            # 타임스탬프 형식: 2026-02-25T10:00:00.000000000Z <message>
            parts = line.split(" ", 1)
            ts = parts[0] if len(parts) > 0 else ""
            msg = parts[1] if len(parts) > 1 else line

            level = "INFO"
            upper = msg[:100].upper()
            if "ERROR" in upper or "CRITICAL" in upper or "FATAL" in upper:
                level = "ERROR"
            elif "WARN" in upper:
                level = "WARN"
            elif "DEBUG" in upper:
                level = "DEBUG"

            results.append({
                "timestamp": ts,
                "message": msg,
                "level": level,
            })
        return results

    @staticmethod
    def _mock_pod_logs(
        pod_name: str,
        namespace: str,
        tail_lines: int,
        since_seconds: int,
    ) -> list[dict[str, Any]]:
        """dev 환경용 mock 파드 로그."""
        templates = [
            "[INFO] Server started on port 8080",
            "[INFO] Health check passed (uptime: {uptime}s)",
            "[INFO] Processing request: GET /api/v1/status (latency: {latency}ms)",
            "[INFO] Connected to database successfully",
            "[WARNING] Slow query detected: {latency}ms (threshold: 500ms)",
            "[WARNING] Memory usage approaching limit: {mem}%",
            "[ERROR] Connection refused to upstream service",
            "[ERROR] Request timeout after 30s: POST /api/v1/data",
            "[INFO] Graceful shutdown initiated",
            "[INFO] Background job completed: processed {records} records",
            "[INFO] Cache hit ratio: {ratio}% (last 5 min)",
            "[WARNING] Retry attempt 2/3 for external API call",
            "[INFO] Configuration reloaded successfully",
            "[ERROR] Unhandled exception: NullPointerException at line 142",
            "[INFO] Incoming connection from 10.0.1.{ip}:{port}",
        ]

        now = datetime.now(KST)
        start = now - timedelta(seconds=since_seconds)
        count = min(tail_lines, random.randint(30, 80))
        logs = []

        for _ in range(count):
            offset = random.randint(0, since_seconds)
            ts = start + timedelta(seconds=offset)
            tmpl = random.choice(templates)
            msg = tmpl.format(
                uptime=random.randint(100, 86400),
                latency=random.randint(1, 3000),
                mem=random.randint(50, 95),
                records=random.randint(100, 10000),
                ratio=random.randint(60, 99),
                ip=random.randint(1, 254),
                port=random.randint(30000, 65535),
            )

            level = "INFO"
            if "[ERROR]" in msg:
                level = "ERROR"
            elif "[WARNING]" in msg:
                level = "WARN"

            logs.append({
                "timestamp": ts.isoformat(),
                "message": msg,
                "level": level,
            })

        logs.sort(key=lambda x: x["timestamp"])
        return logs

    def get_node_logs(
        self,
        node_name: str,
        log_path: str = "messages",
        tail_lines: int = 200,
        since_seconds: int = 3600,
    ) -> dict[str, Any]:
        """K8s 노드 로그 조회 (kubelet proxy API).

        Args:
            node_name: 노드 이름
            log_path: 로그 파일 경로 (messages, syslog, kubelet 등)
            tail_lines: 조회할 최근 로그 줄 수
            since_seconds: 이 시간(초) 이내의 로그만 조회
        """
        is_dev = self.settings.environment == "test"

        try:
            core_v1, _ = self._get_k8s_clients()
            # /api/v1/nodes/{name}/proxy/logs/{log_path}
            raw_log = core_v1.connect_get_node_proxy_with_path(
                name=node_name,
                path=f"logs/{log_path}",
            )
            logs = self._parse_node_log_lines(raw_log, tail_lines)
        except Exception as e:
            logger.warning(f"K8s node log 조회 실패: {node_name}: {e}")
            if is_dev:
                logs = self._mock_node_logs(node_name, tail_lines, since_seconds)
            else:
                raise

        truncated = len(logs) >= tail_lines
        return {
            "node_name": node_name,
            "log_path": log_path,
            "logs": logs,
            "count": len(logs),
            "truncated": truncated,
            "success": True,
        }

    @staticmethod
    def _parse_node_log_lines(raw_log: str, tail_lines: int) -> list[dict[str, Any]]:
        """노드 로그 파싱 (syslog / journald 형식)."""
        lines = raw_log.strip().split("\n") if raw_log else []
        # tail: 마지막 N줄만
        lines = lines[-tail_lines:]
        results = []
        for line in lines:
            if not line.strip():
                continue
            level = "INFO"
            upper = line[:150].upper()
            if "ERROR" in upper or "CRITICAL" in upper or "FATAL" in upper:
                level = "ERROR"
            elif "WARN" in upper:
                level = "WARN"
            elif "DEBUG" in upper:
                level = "DEBUG"

            # syslog 형식: "Feb 25 10:00:00 hostname process[pid]: message"
            # 또는 journald: "-- Logs begin at ..."
            # 타임스탬프 추출 시도
            ts = ""
            parts = line.split(" ", 3)
            if len(parts) >= 3:
                ts = " ".join(parts[:3])

            results.append({
                "timestamp": ts,
                "message": line,
                "level": level,
            })
        return results

    @staticmethod
    def _mock_node_logs(
        node_name: str,
        tail_lines: int,
        since_seconds: int,
    ) -> list[dict[str, Any]]:
        """dev 환경용 mock 노드 로그."""
        templates = [
            "kubelet[{pid}]: Node {node} status is now: NodeReady",
            "kubelet[{pid}]: Container runtime (containerd) version: 1.7.11",
            "kubelet[{pid}]: Pod default/app-backend-0 is now Running",
            "kubelet[{pid}]: Successfully pulled image app-backend:1.4.2 in 2.3s",
            "kubelet[{pid}]: PLEG: relisting (elapsed: {latency}ms)",
            "kubelet[{pid}]: Volume pvc-data-0 mounted successfully",
            "kubelet[{pid}]: CPU utilization: {cpu}% ({cores} cores), Memory: {mem_used}Gi/{mem_total}Gi ({mem_pct}%)",
            "kubelet[{pid}]: Evicting pod spark/spark-exec-failed due to memory pressure",
            "kubelet[{pid}]: Container gc: removed {gc_count} dead containers",
            "kubelet[{pid}]: Image gc: removed {gc_count} unused images, freed {freed}MB",
            "systemd[1]: Started containerd container runtime",
            "systemd[1]: Starting Kubernetes Kubelet...",
            "kernel: [NFConntrack] table full, dropping packet (net.netfilter.nf_conntrack_max = 131072)",
            "kernel: [TCP] {node}: possible SYN flooding on port 443. Sending cookies",
            "kernel: Out of memory: Killed process {pid} (java) total-vm:{vm}kB, anon-rss:{rss}kB",
            "containerd[{pid}]: pulling image docker.io/library/nginx:latest",
            "containerd[{pid}]: snapshot prepare error: disk quota exceeded",
            "kubelet[{pid}]: Failed to create pod sandbox: rpc error: code = Unknown desc = failed to create containerd shim",
            "kubelet[{pid}]: Disk pressure detected on /var/lib/kubelet: usage {disk_pct}%",
            "kubelet[{pid}]: CNI plugin returned error: failed to allocate IP from subnet 10.0.0.0/16",
            "kubelet[{pid}]: Node memory pressure: available {mem_avail}Mi, threshold 1024Mi",
            "kubelet[{pid}]: certificate rotation: new certificate issued (expiry: 365d)",
            "kube-proxy[{pid}]: Syncing iptables rules ({svc_count} services, {ep_count} endpoints)",
            "kube-proxy[{pid}]: Stale endpoint 10.0.1.{ip}:8080 detected, removing",
        ]

        now = datetime.now(KST)
        start = now - timedelta(seconds=since_seconds)
        count = min(tail_lines, random.randint(30, 80))
        logs = []

        for _ in range(count):
            offset = random.randint(0, since_seconds)
            ts = start + timedelta(seconds=offset)
            tmpl = random.choice(templates)
            msg = tmpl.format(
                node=node_name,
                pid=random.randint(1000, 9999),
                latency=random.randint(50, 5000),
                cpu=random.randint(10, 95),
                cores=random.choice([4, 8, 16]),
                mem_used=random.randint(8, 58),
                mem_total=random.choice([32, 64]),
                mem_pct=random.randint(40, 95),
                mem_avail=random.randint(200, 4000),
                gc_count=random.randint(1, 50),
                freed=random.randint(100, 5000),
                vm=random.randint(1000000, 9000000),
                rss=random.randint(500000, 4000000),
                disk_pct=random.randint(70, 98),
                ip=random.randint(1, 254),
                svc_count=random.randint(50, 300),
                ep_count=random.randint(200, 2000),
            )

            ts_str = ts.strftime("%b %d %H:%M:%S")
            full_msg = f"{ts_str} {node_name} {msg}"

            level = "INFO"
            upper = msg[:150].upper()
            if "ERROR" in upper or "KILLED" in upper or "FATAL" in upper or "FAILED" in upper or "DROPPING" in upper:
                level = "ERROR"
            elif "WARN" in upper or "PRESSURE" in upper or "FLOODING" in upper or "QUOTA" in upper:
                level = "WARN"

            logs.append({
                "timestamp": ts.isoformat(),
                "message": full_msg,
                "level": level,
            })

        logs.sort(key=lambda x: x["timestamp"])
        return logs
