"""
HDSP Service Report Generator.

HDSP 서비스 메트릭(Jupyter, MinIO, Spark, API 에러, NAS) 현황을
SVG 라인 차트로 렌더링하는 HTML 리포트 생성기.
"""

import logging
from dataclasses import dataclass, field
from html import escape as html_escape
from typing import Any

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.charts import CHART_COLORS, _svg_line_chart
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)


@dataclass
class HdspServiceReportData:
    """HDSP 서비스 메트릭 리포트 데이터."""

    # Jupyter 접속 (team → [{date, access_count}])
    jupyter_access: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # MinIO 사용량 (team → [{date, usage_gb}])
    minio_usage: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # Spark 실패 (team → [{date, failures}])
    spark_failures: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # HDSP API 에러 ([{date, 4xx, 5xx}])
    hdsp_api_errors: list[dict[str, Any]] = field(default_factory=list)

    # NAS 사용량 (team → [{date, usage_gb}])
    nas_usage: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # MinIO 접속자 수 (team → [{date, access_count}])
    minio_access: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # Cost Explorer 절감액 ({categories: [...], total_savings: ...})
    cost_explorer_savings: dict[str, Any] = field(default_factory=dict)

    # 사용량 전환 절감액 ({categories: [...], total_savings: ...})
    usage_conversion_savings: dict[str, Any] = field(default_factory=dict)


# 섹션 정의
_SECTIONS = [
    {
        "key": "jupyter_access",
        "icon": "deployed_code",
        "title": "Jupyter 접속 현황",
        "subtitle": "팀별 일일 접속자 수 (월누적)",
        "value_field": "access_count",
        "y_suffix": "명",
        "is_team": True,
    },
    {
        "key": "minio_usage",
        "icon": "inventory_2",
        "title": "MinIO 저장소 사용량",
        "subtitle": "팀별 일일 저장소 사용량 (월누적)",
        "value_field": "usage_gb",
        "y_suffix": "GB",
        "is_team": True,
    },
    {
        "key": "spark_failures",
        "icon": "bolt",
        "title": "Spark Job 실패 현황",
        "subtitle": "팀별 일일 실패 건수 (월누적)",
        "value_field": "failures",
        "y_suffix": "건",
        "y_integer": True,
        "is_team": True,
    },
    {
        "key": "hdsp_api_errors",
        "icon": "warning",
        "title": "HDSP API 에러 현황",
        "subtitle": "일별 4xx / 5xx 에러 추이 (월누적)",
        "y_suffix": "건",
        "y_integer": True,
        "is_team": False,
    },
    {
        "key": "nas_usage",
        "icon": "hard_drive",
        "title": "NAS 사용량",
        "subtitle": "팀별 일일 NAS 사용량 (월누적)",
        "value_field": "usage_gb",
        "y_suffix": "GB",
        "is_team": True,
    },
    {
        "key": "minio_access",
        "icon": "group",
        "title": "MinIO 접속 현황",
        "subtitle": "팀별 일일 접속자 수 (월누적)",
        "value_field": "access_count",
        "y_suffix": "명",
        "is_team": True,
    },
]


_CATEGORY_LABELS: dict[str, str] = {
    "jupyter": "Jupyter",
    "minio": "MinIO",
    "minio-access": "MinIO 접속",
    "spark": "Spark",
    "api-errors": "API 에러",
    "nas": "NAS",
    "cost-savings": "비용 절감",
}


class HdspServiceReportGenerator(HTMLReportBase):
    """HDSP 서비스 현황 리포트 생성기."""

    def __init__(self, category: str | None = None):
        styles = ReportStyles(primary_color=MD3_COLORS["tertiary"])
        cat_label = _CATEGORY_LABELS.get(category, category) if category else None
        title = "HDSP 서비스 현황 리포트"
        if cat_label:
            title = f"{title} - {cat_label}"
        super().__init__(title=title, styles=styles)
        self._category = category

    # category → section key 매핑
    _CATEGORY_SECTION_KEYS: dict[str, str] = {
        "jupyter": "jupyter_access",
        "minio": "minio_usage",
        "minio-access": "minio_access",
        "spark": "spark_failures",
        "api-errors": "hdsp_api_errors",
        "nas": "nas_usage",
        "cost-savings": "cost_savings",
    }

    def generate_content(self, data: HdspServiceReportData) -> str:
        sections: list[str] = []
        allowed_key = self._CATEGORY_SECTION_KEYS.get(self._category) if self._category else None

        for sec in _SECTIONS:
            if allowed_key and sec["key"] != allowed_key:
                continue
            chart_html = self._build_section_chart(data, sec)
            if chart_html:
                sections.append(
                    self._build_card(
                        sec["icon"],
                        sec["title"],
                        chart_html,
                    )
                )

        # 비용 절감 섹션 (별도 데이터 구조)
        if not allowed_key or allowed_key == "cost_savings":
            savings_html = self._build_cost_savings_chart(data)
            if savings_html:
                sections.append(self._build_card("savings", "비용 절감 현황", savings_html))

        return "\n".join(sections)

    def _build_section_chart(
        self,
        data: HdspServiceReportData,
        sec: dict[str, Any],
    ) -> str:
        key = sec["key"]

        if sec.get("is_team"):
            # team → [{date, value_field}] 구조
            raw: dict[str, list[dict]] = getattr(data, key, {})
            if not raw:
                return ""
            value_field = sec["value_field"]
            series: dict[str, list[tuple[str, float]]] = {}
            for team, pts in raw.items():
                series[team] = [(p["date"], p[value_field]) for p in pts]
            return _svg_line_chart(
                series,
                CHART_COLORS,
                title=sec["title"],
                subtitle=sec["subtitle"],
                y_suffix=sec["y_suffix"],
                y_integer=sec.get("y_integer", False),
            )
        else:
            # API 에러: [{date, 4xx, 5xx}]
            raw_list: list[dict] = getattr(data, key, [])
            if not raw_list:
                return ""
            series = {
                "4xx": [(p["date"], p["4xx"]) for p in raw_list],
                "5xx": [(p["date"], p["5xx"]) for p in raw_list],
            }
            return _svg_line_chart(
                series,
                ["#d97706", "#dc2626"],
                title=sec["title"],
                subtitle=sec["subtitle"],
                y_suffix=sec["y_suffix"],
                y_integer=sec.get("y_integer", False),
            )

    def _build_cost_savings_chart(self, data: HdspServiceReportData) -> str:
        """Cost Explorer 절감액 + 사용량 전환 절감액 차트."""
        parts: list[str] = []

        # Cost Explorer 절감 (items: [{month, monthlySaving, cumulative, ...}])
        ce = data.cost_explorer_savings
        if ce:
            items = ce.get("items", [])
            if items:
                series: dict[str, list[tuple[str, float]]] = {
                    "월별 절감액": [(p.get("month", ""), p.get("monthlySaving", 0)) for p in items],
                    "누적 절감액": [(p.get("month", ""), p.get("cumulative", 0)) for p in items],
                }
                parts.append(
                    _svg_line_chart(
                        series,
                        CHART_COLORS,
                        title="Cost Explorer 절감액",
                        subtitle="월별 / 누적 절감액 ($)",
                        y_suffix="$",
                    )
                )

        # 사용량 전환 절감 (items: [{month, monthlySaving, cumulative, ...}])
        uc = data.usage_conversion_savings
        if uc:
            items = uc.get("items", [])
            if items:
                series2: dict[str, list[tuple[str, float]]] = {
                    "월별 절감액": [(p.get("month", ""), p.get("monthlySaving", 0)) for p in items],
                    "누적 절감액": [(p.get("month", ""), p.get("cumulative", 0)) for p in items],
                }
                parts.append(
                    _svg_line_chart(
                        series2,
                        CHART_COLORS,
                        title="사용량 전환 절감액",
                        subtitle="월별 / 누적 절감액 ($)",
                        y_suffix="$",
                    )
                )

        return "\n".join(parts) if parts else ""

    def _build_card(self, icon_name: str, title: str, chart_content: str) -> str:
        icon_html = self._icon(icon_name, size="sm", inline=True)
        return f"""
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:8px;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                {icon_html}
                <span style="font-size:14px;font-weight:600;">{html_escape(title)}</span>
            </div>
            <div style="padding:16px 20px;">
                {chart_content}
            </div>
        </div>
        """
