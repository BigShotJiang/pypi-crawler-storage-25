"""MinIO Provider - MinIO 사용량/접속/관리 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseMinioProvider(ABC):
    @abstractmethod
    def get_minio_usage(self, days: int = 31) -> dict[str, Any]: ...

    @abstractmethod
    def get_minio_access(self, days: int = 31) -> dict[str, Any]: ...

    @abstractmethod
    def get_minio_admin(self, days: int = 31) -> dict[str, Any]: ...

    @abstractmethod
    def get_minio_prefixes(self, bucket_name: str, prefix: str = "") -> list[dict[str, Any]]: ...


# ── Mock prefix data ────────────────────────────────────

_MOCK_MINIO_PREFIXES: dict[str, dict[str, list[dict[str, Any]]]] = {
    "hdsp-data": {
        "": [
            {"prefix": "raw/", "size_gb": 380, "object_count": 450_000},
            {"prefix": "processed/", "size_gb": 280, "object_count": 320_000},
            {"prefix": "archive/", "size_gb": 190, "object_count": 180_000},
        ],
        "raw/": [
            {"prefix": "sensor-data/", "size_gb": 180, "object_count": 220_000},
            {"prefix": "log-data/", "size_gb": 120, "object_count": 150_000},
            {"prefix": "batch-input/", "size_gb": 80, "object_count": 80_000},
        ],
        "raw/sensor-data/": [
            {"prefix": "2026/", "size_gb": 95, "object_count": 120_000},
            {"prefix": "2025/", "size_gb": 85, "object_count": 100_000},
        ],
        "processed/": [
            {"prefix": "parquet/", "size_gb": 150, "object_count": 180_000},
            {"prefix": "csv/", "size_gb": 80, "object_count": 90_000},
            {"prefix": "json/", "size_gb": 50, "object_count": 50_000},
        ],
        "archive/": [
            {"prefix": "2025-Q1/", "size_gb": 60, "object_count": 50_000},
            {"prefix": "2025-Q2/", "size_gb": 65, "object_count": 55_000},
            {"prefix": "2024/", "size_gb": 65, "object_count": 75_000},
        ],
    },
    "spark-warehouse": {
        "": [
            {"prefix": "tables/", "size_gb": 220, "object_count": 280_000},
            {"prefix": "temp/", "size_gb": 120, "object_count": 150_000},
            {"prefix": "checkpoints/", "size_gb": 80, "object_count": 60_000},
        ],
        "tables/": [
            {"prefix": "user_activity/", "size_gb": 90, "object_count": 110_000},
            {"prefix": "aggregations/", "size_gb": 75, "object_count": 95_000},
            {"prefix": "ml_features/", "size_gb": 55, "object_count": 75_000},
        ],
        "temp/": [
            {"prefix": "shuffle/", "size_gb": 70, "object_count": 90_000},
            {"prefix": "staging/", "size_gb": 50, "object_count": 60_000},
        ],
    },
    "jupyter-notebooks": {
        "": [
            {"prefix": "team1/", "size_gb": 25, "object_count": 350},
            {"prefix": "team2/", "size_gb": 20, "object_count": 280},
            {"prefix": "shared/", "size_gb": 20, "object_count": 170},
        ],
        "team1/": [
            {"prefix": "analysis/", "size_gb": 12, "object_count": 180},
            {"prefix": "experiments/", "size_gb": 8, "object_count": 120},
            {"prefix": "models/", "size_gb": 5, "object_count": 50},
        ],
        "team2/": [
            {"prefix": "research/", "size_gb": 10, "object_count": 150},
            {"prefix": "pipelines/", "size_gb": 10, "object_count": 130},
        ],
    },
}


class MockMinioProvider(BaseMinioProvider):
    def get_minio_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        teams: dict[str, list] = {}
        for team_name, base_gb, daily_growth in [
            ("분석1팀", 850, 3),
            ("분석2팀", 420, 2),
            ("분석3팀", 280, 1.5),
        ]:
            data = []
            val = base_gb
            for d in dates:
                val += random.uniform(0, daily_growth)
                data.append({"date": d, "usage_gb": round(val, 1)})
            teams[team_name] = data
        return {"teams": teams}

    def get_minio_access(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        teams: dict[str, list] = {}
        for team_name, weekday_base, weekend_base in [
            ("분석1팀", 25, 5),
            ("분석2팀", 18, 3),
            ("분석3팀", 30, 7),
        ]:
            data = []
            random.seed(hash(f"minio_access_{team_name}") & 0xFFFFFFFF)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                base = weekend_base if is_weekend else weekday_base
                count = max(0, base + random.randint(-5, 8))
                data.append({"date": d, "access_count": count})
            teams[team_name] = data
        return {"teams": teams}

    def get_minio_admin(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        buckets: dict[str, Any] = {}
        for bname, base_gb, obj_base, growth in [
            ("hdsp-data", 850, 12000, 3.0),
            ("spark-warehouse", 420, 5000, 2.0),
            ("jupyter-notebooks", 65, 800, 0.5),
        ]:
            daily = []
            val = base_gb
            obj = obj_base
            random.seed(hash(f"minio_bucket_{bname}") & 0xFFFFFFFF)
            for d in dates:
                val += random.uniform(0, growth)
                obj += random.randint(0, 20)
                daily.append({"date": d, "size_gb": round(val, 1), "object_count": obj})
            buckets[bname] = {"daily": daily}

        server_daily = []
        random.seed(hash("minio_server") & 0xFFFFFFFF)
        disk_used = 1400.0
        for d in dates:
            disk_used += random.uniform(1, 6)
            server_daily.append(
                {
                    "date": d,
                    "disk_used_gb": round(disk_used, 1),
                    "disk_total_gb": 4000,
                }
            )

        api_daily = []
        random.seed(hash("minio_api") & 0xFFFFFFFF)
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            factor = 0.3 if is_weekend else 1.0
            api_daily.append(
                {
                    "date": d,
                    "get_ops": max(0, round(2500 * factor + random.randint(-300, 500))),
                    "put_ops": max(0, round(800 * factor + random.randint(-100, 200))),
                    "delete_ops": max(0, round(120 * factor + random.randint(-30, 50))),
                }
            )

        # ── Operator + Nodes (13 nodes, single tenant) ──
        nodes: dict[str, Any] = {}
        random.seed(hash("minio_nodes") & 0xFFFFFFFF)
        for hostname, dtotal, drives, status in [
            ("minio-0", 500, 4, "Online"),
            ("minio-1", 500, 4, "Online"),
            ("minio-2", 500, 4, "Online"),
            ("minio-3", 500, 4, "Online"),
            ("minio-4", 500, 4, "Online"),
            ("minio-5", 500, 4, "Online"),
            ("minio-6", 500, 4, "Online"),
            ("minio-7", 500, 4, "Offline"),
            ("minio-8", 500, 4, "Online"),
            ("minio-9", 500, 4, "Online"),
            ("minio-10", 500, 4, "Online"),
            ("minio-11", 500, 4, "Online"),
            ("minio-12", 500, 4, "Online"),
        ]:
            d_online = 0 if status == "Offline" else drives
            nodes[hostname] = {
                "hostname": hostname,
                "status": status,
                "disk_used_gb": round(random.uniform(120, 250), 1),
                "disk_total_gb": dtotal,
                "drives": drives,
                "drives_online": d_online,
                "cpu_usage_pct": round(random.uniform(10, 65), 1) if status != "Offline" else 0,
                "memory_usage_pct": round(random.uniform(30, 80), 1) if status != "Offline" else 0,
                "uptime_hours": random.randint(200, 2000) if status != "Offline" else 0,
            }

        return {
            "buckets": buckets,
            "server": {"daily": server_daily},
            "api_throughput": {"daily": api_daily},
            "operator": {
                "name": "minio-operator",
                "version": "v5.0.15",
                "status": "Running",
                "tenant": "hdsp-minio",
            },
            "nodes": nodes,
        }

    def get_minio_prefixes(self, bucket_name: str, prefix: str = "") -> list[dict[str, Any]]:
        return _MOCK_MINIO_PREFIXES.get(bucket_name, {}).get(prefix, [])


class RealMinioProvider(BaseMinioProvider):
    def __init__(
        self,
        endpoint: str | None = None,
        access_key: str | None = None,
        secret_key: str | None = None,
    ) -> None:
        self._endpoint = endpoint
        self._access_key = access_key
        self._secret_key = secret_key

    def get_minio_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError

    def get_minio_access(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError

    def get_minio_admin(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError

    def get_minio_prefixes(self, bucket_name: str, prefix: str = "") -> list[dict[str, Any]]:
        raise NotImplementedError
