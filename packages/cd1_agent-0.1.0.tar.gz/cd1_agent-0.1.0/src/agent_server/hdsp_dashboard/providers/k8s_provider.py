"""K8s EKS Provider - EKS Pod/Node 리소스 및 이벤트 추이."""

import logging
import random
from abc import ABC, abstractmethod
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import (
    _daily_dates,
    _parse_cpu_mc,
    _parse_memory_mb,
)
from src.agent_server.hdsp_metrics.services.prometheus_client import PrometheusClient

logger = logging.getLogger(__name__)

KST = timezone(timedelta(hours=9))


class BaseK8sProvider(ABC):
    @abstractmethod
    def get_eks_pod_resources(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_eks_node_resources(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_eks_event_trends(self, days: int = 31) -> dict[str, Any]: ...


class MockK8sProvider(BaseK8sProvider):
    """Mock 데이터 기반 K8s Provider."""

    # k8s_infra_service.py의 mock과 동일한 pod->node->node_group 매핑
    _PODS_SPEC = [
        # (pod_name, namespace, node_name, cpu_req, cpu_lim, mem_req, mem_lim)
        ("app-backend-0", "default", "worker-node-1", "250m", "500m", "256Mi", "512Mi"),
        ("app-backend-1", "default", "worker-node-2", "250m", "500m", "256Mi", "512Mi"),
        ("app-backend-failed", "default", "worker-node-1", "250m", "500m", "256Mi", "512Mi"),
        ("hdsp-api-server-0", "hdsp", "worker-node-1", "500m", "1", "512Mi", "1Gi"),
        ("hdsp-worker-0", "hdsp", "worker-node-2", "1", "2", "1Gi", "2Gi"),
        ("hdsp-worker-1", "hdsp", "worker-node-3", "1", "2", "1Gi", "2Gi"),
        ("spark-driver-0", "spark", "worker-node-3", "1", "2", "2Gi", "4Gi"),
        ("spark-exec-0", "spark", "worker-node-1", "2", "4", "4Gi", "8Gi"),
        ("spark-exec-1", "spark", "worker-node-2", "2", "4", "4Gi", "8Gi"),
        ("spark-exec-failed", "spark", "worker-node-3", "2", "4", "4Gi", "8Gi"),
        # spark-driver-pending: node_name="" -> 제외 (Pending)
        ("prometheus-0", "monitoring", "worker-node-1", "500m", "1", "1Gi", "2Gi"),
        ("grafana-0", "monitoring", "worker-node-2", "200m", "500m", "256Mi", "512Mi"),
        ("coredns-0", "kube-system", "master-node-1", "100m", "200m", "70Mi", "170Mi"),
        ("kube-proxy-0", "kube-system", "master-node-1", "100m", "", "64Mi", ""),
    ]

    _NODE_TO_NG = {
        "worker-node-1": "general-workers",
        "worker-node-2": "general-workers",
        "worker-node-3": "compute-optimized",
        "worker-node-4": "compute-optimized",
        "master-node-1": "control-plane",
    }

    def _generate_all_pod_daily(
        self,
        days: int,
    ) -> dict[str, list[dict[str, Any]]]:
        """Pod별 일별 사용량을 생성. node/pod 양쪽에서 동일 값 재사용."""
        dates = _daily_dates(days)
        result: dict[str, list[dict[str, Any]]] = {}
        for pod_name, _ns, _node, cpu_req, cpu_lim, mem_req, mem_lim in self._PODS_SPEC:
            cpu_req_mc = _parse_cpu_mc(cpu_req)
            cpu_lim_mc = _parse_cpu_mc(cpu_lim)
            mem_req_mb = _parse_memory_mb(mem_req)
            mem_lim_mb = _parse_memory_mb(mem_lim)

            daily = []
            random.seed(hash(pod_name) & 0xFFFFFFFF)
            for d in dates:
                cpu_base = cpu_req_mc * 0.6
                cpu_noise = cpu_base * random.uniform(-0.2, 0.2)
                cpu_val = cpu_base + cpu_noise
                if random.random() < 0.05 and cpu_lim_mc > 0:
                    cpu_val = cpu_lim_mc * random.uniform(0.8, 0.95)
                cpu_val = max(0, min(cpu_val, cpu_lim_mc if cpu_lim_mc > 0 else cpu_val))

                mem_base = mem_req_mb * 0.7
                mem_noise = mem_base * random.uniform(-0.1, 0.1)
                mem_val = mem_base + mem_noise
                mem_val = max(0, min(mem_val, mem_lim_mb if mem_lim_mb > 0 else mem_val))

                daily.append(
                    {
                        "date": d,
                        "cpu_mc": round(cpu_val),
                        "memory_mb": round(mem_val),
                    }
                )
            result[pod_name] = daily
        return result

    def get_eks_pod_resources(self, days: int = 31) -> dict[str, Any]:
        all_pod_daily = self._generate_all_pod_daily(days)

        result: dict[str, Any] = {}
        for pod_name, ns, node_name, cpu_req, cpu_lim, mem_req, mem_lim in self._PODS_SPEC:
            ng = self._NODE_TO_NG.get(node_name, "(ungrouped)")

            ng_dict = result.setdefault(ng, {"namespaces": {}})
            ns_dict = ng_dict["namespaces"].setdefault(ns, {"pods": {}})
            ns_dict["pods"][pod_name] = {
                "cpu_request_mc": _parse_cpu_mc(cpu_req),
                "cpu_limit_mc": _parse_cpu_mc(cpu_lim),
                "memory_request_mb": _parse_memory_mb(mem_req),
                "memory_limit_mb": _parse_memory_mb(mem_lim),
                "daily": all_pod_daily[pod_name],
            }

        return {"node_groups": result}

    # 노드 스펙: k8s_infra_service._mock_nodes()와 동일 (5개 노드)
    _NODES_SPEC = [
        # (node_name, node_group, cpu_capacity_mc, memory_capacity_mb, status, instance_type)
        ("worker-node-1", "general-workers", 8000, 32768, "Ready", "m5.2xlarge"),
        ("worker-node-2", "general-workers", 8000, 32768, "Ready", "m5.2xlarge"),
        ("worker-node-3", "compute-optimized", 16000, 32768, "Ready", "c5.4xlarge"),
        ("worker-node-4", "compute-optimized", 16000, 32768, "NotReady", "c5.4xlarge"),
        ("master-node-1", "control-plane", 4000, 16384, "Ready", "m5.xlarge"),
    ]

    def get_eks_node_resources(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        all_pod_daily = self._generate_all_pod_daily(days)

        # 노드별 pod 매핑
        node_pods: dict[str, list[str]] = {}
        for pod_name, _ns, node_name, *_ in self._PODS_SPEC:
            node_pods.setdefault(node_name, []).append(pod_name)

        result: dict[str, Any] = {}
        for node_name, ng, cpu_cap, mem_cap, status, itype in self._NODES_SPEC:
            ng_dict = result.setdefault(ng, {"nodes": {}})
            pod_names = node_pods.get(node_name, [])

            if status == "NotReady" or not pod_names:
                # NotReady 노드 또는 pod 없는 노드: 사용량 0
                daily = [{"date": d, "cpu_mc": 0, "memory_mb": 0} for d in dates]
            else:
                daily = []
                random.seed(hash(f"node_{node_name}") & 0xFFFFFFFF)
                for i, d in enumerate(dates):
                    cpu_sum = sum(all_pod_daily[p][i]["cpu_mc"] for p in pod_names)
                    mem_sum = sum(all_pod_daily[p][i]["memory_mb"] for p in pod_names)
                    # 시스템 오버헤드 5~12%
                    overhead_pct = random.uniform(0.05, 0.12)
                    cpu_total = min(round(cpu_sum + cpu_cap * overhead_pct), cpu_cap)
                    mem_total = min(round(mem_sum + mem_cap * overhead_pct), mem_cap)
                    daily.append({"date": d, "cpu_mc": cpu_total, "memory_mb": mem_total})

            ng_dict["nodes"][node_name] = {
                "cpu_capacity_mc": cpu_cap,
                "memory_capacity_mb": mem_cap,
                "status": status,
                "instance_type": itype,
                "pod_names": pod_names,
                "daily": daily,
            }

        return {"node_groups": result}

    def get_eks_event_trends(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        node_groups: dict[str, dict] = {}
        for ng_name in dict.fromkeys(self._NODE_TO_NG.values()):
            reasons: dict[str, list] = {}
            for reason in ["OOMKilling", "BackOff", "FailedScheduling", "Error"]:
                data = []
                random.seed(hash(f"eks_event_{ng_name}_{reason}") & 0xFFFFFFFF)
                for d in dates:
                    count = 0
                    r = random.random()
                    if r < 0.25:
                        count = random.randint(1, 2)
                    elif r < 0.28:
                        count = random.randint(2, 8)
                    data.append({"date": d, "count": count})
                reasons[reason] = data
            node_groups[ng_name] = {"reasons": reasons}
        return {"node_groups": node_groups}


class RealK8sProvider(BaseK8sProvider):
    """Kubernetes API + Prometheus 연동 Provider."""

    def __init__(
        self,
        k8s_api_url: str | None = None,
        prometheus_url: str | None = None,
    ):
        self.k8s_api_url = k8s_api_url
        self._prom = PrometheusClient(base_url=prometheus_url)

    # ── 내부 헬퍼 ──────────────────────────────────────

    @staticmethod
    def _get_k8s_clients():
        """CoreV1Api, AppsV1Api 클라이언트 반환."""
        from kubernetes import client, config

        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()
        return client.CoreV1Api(), client.AppsV1Api()

    @staticmethod
    def _get_node_group(labels: dict[str, str]) -> str:
        return labels.get("eks.amazonaws.com/nodegroup", "(ungrouped)")

    def _query_range_daily(
        self,
        query: str,
        days: int,
        group_keys: list[str],
    ) -> dict[tuple[str, ...], list[dict[str, Any]]]:
        """Prometheus query_range(step=1d) 결과를 날짜별 dict 리스트로 변환.

        Returns:
            {(label_val, ...): [{"date": "YYYY-MM-DD", "value": float}, ...]}
        """
        end = datetime.now(KST)
        start = end - timedelta(days=days - 1)
        # 시작점을 해당 일 00:00 KST로 정렬
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)

        results = self._prom.query_range(query, start, end, step="1d")

        daily_map: dict[tuple[str, ...], dict[str, float]] = defaultdict(dict)
        for r in results:
            key = tuple(r.labels.get(k, "") for k in group_keys)
            for ts, val in r.values:
                dt = datetime.fromtimestamp(float(ts), tz=KST)
                date_str = dt.date().isoformat()
                daily_map[key][date_str] = float(val)

        # _daily_dates 기준으로 정렬하고 빈 날짜는 0으로 채움
        dates = _daily_dates(days)
        out: dict[tuple[str, ...], list[dict[str, Any]]] = {}
        for key, date_vals in daily_map.items():
            out[key] = [
                {"date": d, "value": round(date_vals.get(d, 0))}
                for d in dates
            ]
        return out

    # ── 공개 메서드 ──────────────────────────────────────

    def get_eks_pod_resources(self, days: int = 31) -> dict[str, Any]:
        # 1) K8s API: Pod/Node 목록 조회
        try:
            core_v1, _ = self._get_k8s_clients()
            node_list = core_v1.list_node()
            pod_list = core_v1.list_pod_for_all_namespaces()
        except Exception as e:
            logger.warning(f"K8s API 조회 실패 (pod_resources): {e}")
            return {"node_groups": {}}

        # node -> node_group 매핑
        node_to_ng: dict[str, str] = {}
        for node in node_list.items:
            labels = node.metadata.labels or {}
            node_to_ng[node.metadata.name] = self._get_node_group(labels)

        # 2) Prometheus: Pod별 일별 CPU/Memory 사용량
        cpu_query = (
            'sum by (namespace, pod) ('
            'rate(container_cpu_usage_seconds_total'
            '{container!="POD", container!=""}[1h])'
            ') * 1000'
        )
        mem_query = (
            'sum by (namespace, pod) ('
            'container_memory_working_set_bytes'
            '{container!="POD", container!=""}'
            ') / 1048576'
        )

        cpu_daily: dict[tuple[str, ...], list[dict]] = {}
        mem_daily: dict[tuple[str, ...], list[dict]] = {}
        try:
            cpu_daily = self._query_range_daily(cpu_query, days, ["namespace", "pod"])
            mem_daily = self._query_range_daily(mem_query, days, ["namespace", "pod"])
        except Exception as e:
            logger.warning(f"Prometheus 조회 실패 (pod_resources): {e}")

        # 3) 결과 조립
        dates = _daily_dates(days)
        result: dict[str, Any] = {}

        for pod in pod_list.items:
            phase = pod.status.phase or "Unknown"
            if phase == "Succeeded":
                continue

            pod_name = pod.metadata.name
            ns = pod.metadata.namespace
            node_name = pod.spec.node_name or ""
            if not node_name:
                continue  # Pending pod (노드 미배정) 제외

            ng = node_to_ng.get(node_name, "(ungrouped)")

            # 리소스 request/limit 파싱
            container = pod.spec.containers[0] if pod.spec.containers else None
            resources = container.resources if container else None
            requests = (resources.requests or {}) if resources else {}
            limits = (resources.limits or {}) if resources else {}

            # Prometheus 결과에서 daily 매핑
            prom_key = (ns, pod_name)
            cpu_vals = cpu_daily.get(prom_key, [])
            mem_vals = mem_daily.get(prom_key, [])

            # CPU/Memory 일별 데이터 병합
            daily: list[dict[str, Any]] = []
            if cpu_vals and mem_vals:
                for cv, mv in zip(cpu_vals, mem_vals):
                    daily.append({
                        "date": cv["date"],
                        "cpu_mc": cv["value"],
                        "memory_mb": mv["value"],
                    })
            elif cpu_vals:
                daily = [{"date": v["date"], "cpu_mc": v["value"], "memory_mb": 0} for v in cpu_vals]
            elif mem_vals:
                daily = [{"date": v["date"], "cpu_mc": 0, "memory_mb": v["value"]} for v in mem_vals]
            else:
                daily = [{"date": d, "cpu_mc": 0, "memory_mb": 0} for d in dates]

            ng_dict = result.setdefault(ng, {"namespaces": {}})
            ns_dict = ng_dict["namespaces"].setdefault(ns, {"pods": {}})
            ns_dict["pods"][pod_name] = {
                "cpu_request_mc": _parse_cpu_mc(requests.get("cpu", "")),
                "cpu_limit_mc": _parse_cpu_mc(limits.get("cpu", "")),
                "memory_request_mb": _parse_memory_mb(requests.get("memory", "")),
                "memory_limit_mb": _parse_memory_mb(limits.get("memory", "")),
                "daily": daily,
            }

        return {"node_groups": result}

    def get_eks_node_resources(self, days: int = 31) -> dict[str, Any]:
        # 1) K8s API
        try:
            core_v1, _ = self._get_k8s_clients()
            node_list = core_v1.list_node()
            pod_list = core_v1.list_pod_for_all_namespaces()
        except Exception as e:
            logger.warning(f"K8s API 조회 실패 (node_resources): {e}")
            return {"node_groups": {}}

        # node별 pod 매핑
        node_pods: dict[str, list[str]] = defaultdict(list)
        for pod in pod_list.items:
            nn = pod.spec.node_name
            if nn:
                node_pods[nn].append(pod.metadata.name)

        # 2) Prometheus: Node별 일별 CPU/Memory
        cpu_query = (
            'sum by (node) ('
            'rate(container_cpu_usage_seconds_total'
            '{container!="POD", container!=""}[1h])'
            ') * 1000'
        )
        mem_query = (
            'sum by (node) ('
            'container_memory_working_set_bytes'
            '{container!="POD", container!=""}'
            ') / 1048576'
        )

        cpu_daily: dict[tuple[str, ...], list[dict]] = {}
        mem_daily: dict[tuple[str, ...], list[dict]] = {}
        try:
            cpu_daily = self._query_range_daily(cpu_query, days, ["node"])
            mem_daily = self._query_range_daily(mem_query, days, ["node"])
        except Exception as e:
            logger.warning(f"Prometheus 조회 실패 (node_resources): {e}")

        # 3) 결과 조립
        dates = _daily_dates(days)
        result: dict[str, Any] = {}

        for node in node_list.items:
            node_name = node.metadata.name
            labels = node.metadata.labels or {}
            ng = self._get_node_group(labels)

            # 노드 상태
            status = "Unknown"
            for condition in node.status.conditions or []:
                if condition.type == "Ready":
                    status = "Ready" if condition.status == "True" else "NotReady"
                    break

            # capacity
            capacity = node.status.capacity or {}
            allocatable = node.status.allocatable or {}
            cpu_cap_mc = _parse_cpu_mc(capacity.get("cpu", "0"))
            mem_cap_mb = _parse_memory_mb(allocatable.get("memory", "0"))

            instance_type = labels.get("node.kubernetes.io/instance-type", "")
            pod_names = node_pods.get(node_name, [])

            # Prometheus daily
            prom_key = (node_name,)
            cpu_vals = cpu_daily.get(prom_key, [])
            mem_vals = mem_daily.get(prom_key, [])

            if status == "NotReady" or (not cpu_vals and not mem_vals):
                daily = [{"date": d, "cpu_mc": 0, "memory_mb": 0} for d in dates]
            elif cpu_vals and mem_vals:
                daily = [
                    {"date": cv["date"], "cpu_mc": cv["value"], "memory_mb": mv["value"]}
                    for cv, mv in zip(cpu_vals, mem_vals)
                ]
            elif cpu_vals:
                daily = [{"date": v["date"], "cpu_mc": v["value"], "memory_mb": 0} for v in cpu_vals]
            else:
                daily = [{"date": v["date"], "cpu_mc": 0, "memory_mb": v["value"]} for v in mem_vals]

            ng_dict = result.setdefault(ng, {"nodes": {}})
            ng_dict["nodes"][node_name] = {
                "cpu_capacity_mc": cpu_cap_mc,
                "memory_capacity_mb": mem_cap_mb,
                "status": status,
                "instance_type": instance_type,
                "pod_names": pod_names,
                "daily": daily,
            }

        return {"node_groups": result}

    def get_eks_event_trends(self, days: int = 31) -> dict[str, Any]:
        # 1) K8s API: node -> node_group 매핑
        try:
            core_v1, _ = self._get_k8s_clients()
            node_list = core_v1.list_node()
        except Exception as e:
            logger.warning(f"K8s API 조회 실패 (event_trends): {e}")
            return {"node_groups": {}}

        node_to_ng: dict[str, str] = {}
        ng_names: list[str] = []
        for node in node_list.items:
            labels = node.metadata.labels or {}
            ng = self._get_node_group(labels)
            node_to_ng[node.metadata.name] = ng
            if ng not in ng_names:
                ng_names.append(ng)

        # 2) Prometheus: reason별 이벤트 추이
        reason_queries = {
            "OOMKilling": (
                'sum by (node) ('
                'increase(kube_pod_container_status_last_terminated_reason'
                '{reason="OOMKilled"}[1d]))'
            ),
            "BackOff": (
                'sum by (node) ('
                'increase(kube_pod_container_status_waiting_reason'
                '{reason="CrashLoopBackOff"}[1d]))'
            ),
            "FailedScheduling": (
                'count by (node) ('
                'kube_pod_status_unschedulable == 1) or vector(0)'
            ),
            "Error": (
                'sum by (node) ('
                'increase(kube_pod_container_status_restarts_total[1d]))'
            ),
        }

        dates = _daily_dates(days)

        # node_group별 reason별 초기화 (전부 0)
        ng_reasons: dict[str, dict[str, list[dict[str, Any]]]] = {}
        for ng_name in ng_names:
            ng_reasons[ng_name] = {
                reason: [{"date": d, "count": 0} for d in dates]
                for reason in reason_queries
            }

        # 3) Prometheus 조회 및 node -> node_group 집계
        for reason, query in reason_queries.items():
            try:
                daily_by_node = self._query_range_daily(query, days, ["node"])
            except Exception as e:
                logger.warning(f"Prometheus 조회 실패 (event_trends/{reason}): {e}")
                continue

            for (node_name,), daily_vals in daily_by_node.items():
                ng = node_to_ng.get(node_name)
                if ng is None or ng not in ng_reasons:
                    continue
                # 해당 node_group의 reason에 값 합산
                for i, dv in enumerate(daily_vals):
                    if i < len(ng_reasons[ng][reason]):
                        ng_reasons[ng][reason][i]["count"] += int(dv["value"])

        return {
            "node_groups": {
                ng: {"reasons": reasons}
                for ng, reasons in ng_reasons.items()
            },
        }
