"""Backup Provider - 로그백업 및 백업 성공률 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseBackupProvider(ABC):
    @abstractmethod
    def get_log_backup_status(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_backup_success_rate(self, days: int = 31) -> dict[str, Any]: ...


class MockBackupProvider(BaseBackupProvider):
    """Mock 데이터 기반 Backup Provider."""

    _LOG_SOURCES = ["spark-logs", "jupyter-logs", "api-logs"]
    _DESTINATIONS = ["s3", "minio"]

    def get_log_backup_status(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        source_profiles: dict[str, tuple[int, float]] = {
            "spark-logs": (12, 340.0),
            "jupyter-logs": (5, 28.0),
            "api-logs": (8, 156.0),
        }
        destinations: dict[str, dict[str, list]] = {}
        for dest in self._DESTINATIONS:
            dest_data: dict[str, list] = {}
            for source, (base_count, base_size) in source_profiles.items():
                data = []
                random.seed(hash(f"logbackup_{dest}_{source}") & 0xFFFFFFFF)
                for d in dates:
                    dt = datetime.fromisoformat(d)
                    is_weekend = dt.weekday() >= 5
                    factor = 0.3 if is_weekend else 1.0
                    count = max(0, round(base_count * factor + random.randint(-2, 3)))
                    size = max(0.0, round(base_size * factor + random.uniform(-20, 30), 1))
                    data.append({"date": d, "file_count": count, "size_mb": size})
                dest_data[source] = data
            destinations[dest] = dest_data
        return {"destinations": destinations}

    def get_backup_success_rate(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        destinations: dict[str, Any] = {}
        for dest, success_base in [("s3", 12), ("minio", 8)]:
            daily = []
            random.seed(hash(f"backup_rate_{dest}") & 0xFFFFFFFF)
            for d in dates:
                success = max(0, success_base + random.randint(-2, 3))
                failure = 1 if random.random() < 0.08 else 0
                daily.append({"date": d, "success": success, "failure": failure})
            destinations[dest] = {"daily": daily}
        return {"destinations": destinations}


class RealBackupProvider(BaseBackupProvider):
    """실제 백업 시스템 연동 Provider."""

    def get_log_backup_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Backup provider not yet implemented")

    def get_backup_success_rate(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Backup provider not yet implemented")
