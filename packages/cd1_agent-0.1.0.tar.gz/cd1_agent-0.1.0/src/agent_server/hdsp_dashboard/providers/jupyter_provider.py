"""Jupyter Provider - Jupyter 접속 및 클러스터 현황."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseJupyterProvider(ABC):
    @abstractmethod
    def get_jupyter_access(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_jupyter_cluster_status(self, days: int = 31) -> dict[str, Any]: ...


class MockJupyterProvider(BaseJupyterProvider):
    """Mock 데이터 기반 Jupyter Provider."""

    def get_jupyter_access(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        teams: dict[str, list] = {}
        for team_name, weekday_base, weekend_base in [
            ("분석1팀", 12, 3),
            ("분석2팀", 8, 2),
            ("분석3팀", 15, 4),
        ]:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                base = weekend_base if is_weekend else weekday_base
                count = max(0, base + random.randint(-3, 5))
                data.append({"date": d, "access_count": count})
            teams[team_name] = data
        return {"teams": teams}

    def get_jupyter_cluster_status(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        today = dates[-1]

        def _cond_ok(t: str) -> list[dict[str, str]]:
            return [
                {"type": "PodScheduled", "status": "True", "last_transition": t},
                {"type": "Initialized", "status": "True", "last_transition": t},
                {"type": "ContainersReady", "status": "True", "last_transition": t},
                {"type": "Ready", "status": "True", "last_transition": t},
            ]

        # Hub pods
        hub_pods = []
        for i, node in enumerate(["worker-node-1", "worker-node-2"]):
            hub_pods.append(
                {
                    "name": f"jupyterhub-{i}",
                    "namespace": "jupyter",
                    "node_name": node,
                    "phase": "Running",
                    "display_status": "ok",
                    "image": "jupyterhub/jupyterhub:4.0.2",
                    "cpu_request": "500m",
                    "cpu_limit": "1",
                    "memory_request": "2Gi",
                    "memory_limit": "4Gi",
                    "restart_count": 0,
                    "container_state": "running",
                    "started_at": f"{today}T00:00:00Z",
                    "conditions": _cond_ok(f"{today}T00:00:00Z"),
                }
            )

        db_pod = {
            "name": "postgresql-jupyterhub-0",
            "namespace": "jupyter",
            "node_name": "worker-node-1",
            "phase": "Running",
            "display_status": "ok",
            "image": "bitnami/postgresql:15.4",
            "cpu_request": "250m",
            "cpu_limit": "500m",
            "memory_request": "1Gi",
            "memory_limit": "2Gi",
            "restart_count": 0,
            "container_state": "running",
            "started_at": f"{today}T00:00:00Z",
            "conditions": _cond_ok(f"{today}T00:00:00Z"),
            "db_version": "15.4",
            "connections": 25,
            "storage_gb": 100,
        }

        hub = {"pods": hub_pods, "db_pod": db_pod, "version": "4.0.2"}

        # On-Prem CPU cluster
        cpu_lab_specs = [
            ("prj1", "a453180", "/data/team1", "team-a", "500m", "1", "2Gi", "4Gi", "09:15:00"),
            ("prj1", "a312045", "/data/team1", "team-a", "1", "2", "4Gi", "8Gi", "08:30:00"),
            ("prj2", "a278910", "/data/team2", "team-b", "500m", "1", "2Gi", "4Gi", "10:05:00"),
            ("prj3", "a501322", "/data/shared", "team-c", "2", "4", "8Gi", "16Gi", "07:45:00"),
            ("prj3", "a189473", "/data/shared", "team-c", "1", "2", "4Gi", "8Gi", "11:20:00"),
        ]
        cpu_pods = []
        for prj, eid, mnt, team, cpu_req, cpu_lim, mem_req, mem_lim, t in cpu_lab_specs:
            started = f"{today}T{t}Z"
            cpu_pods.append(
                {
                    "name": f"jupyter-{eid}",
                    "namespace": "jupyter",
                    "node_name": "worker-node-2",
                    "phase": "Running",
                    "display_status": "ok",
                    "image": "jupyter/scipy-notebook:lab-4.0.7",
                    "cpu_request": cpu_req,
                    "cpu_limit": cpu_lim,
                    "memory_request": mem_req,
                    "memory_limit": mem_lim,
                    "restart_count": 0,
                    "container_state": "running",
                    "started_at": started,
                    "conditions": _cond_ok(started),
                    "project": prj,
                    "employee_id": eid,
                    "mount": mnt,
                    "team": team,
                }
            )

        # On-Prem GPU cluster
        gpu_lab_specs = [
            (
                "prj4",
                "a601234",
                "/data/gpu-team1",
                "team-d",
                "2",
                "4",
                "8Gi",
                "16Gi",
                "08:00:00",
                "NVIDIA A100",
                1,
            ),
            (
                "prj4",
                "a602345",
                "/data/gpu-team1",
                "team-d",
                "2",
                "4",
                "8Gi",
                "16Gi",
                "08:10:00",
                "NVIDIA A100",
                1,
            ),
            (
                "prj5",
                "a603456",
                "/data/gpu-team2",
                "team-a",
                "4",
                "8",
                "16Gi",
                "32Gi",
                "09:00:00",
                "NVIDIA A100",
                2,
            ),
        ]
        gpu_pods = []
        for (
            prj,
            eid,
            mnt,
            team,
            cpu_req,
            cpu_lim,
            mem_req,
            mem_lim,
            t,
            gpu_type,
            gpu_cnt,
        ) in gpu_lab_specs:
            started = f"{today}T{t}Z"
            gpu_pods.append(
                {
                    "name": f"jupyter-{eid}",
                    "namespace": "jupyter-gpu",
                    "node_name": "gpu-node-1",
                    "phase": "Running",
                    "display_status": "ok",
                    "image": "jupyter/pytorch-notebook:cuda12",
                    "cpu_request": cpu_req,
                    "cpu_limit": cpu_lim,
                    "memory_request": mem_req,
                    "memory_limit": mem_lim,
                    "restart_count": 0,
                    "container_state": "running",
                    "started_at": started,
                    "conditions": _cond_ok(started),
                    "project": prj,
                    "employee_id": eid,
                    "mount": mnt,
                    "team": team,
                    "gpu_type": gpu_type,
                    "gpu_count": gpu_cnt,
                }
            )

        # GCP GPU cluster
        gcp_lab_specs = [
            (
                "prj6",
                "a701111",
                "/data/gcp-llm",
                "team-e",
                "4",
                "8",
                "16Gi",
                "32Gi",
                "07:30:00",
                "NVIDIA T4",
                4,
            ),
            (
                "prj6",
                "a702222",
                "/data/gcp-llm",
                "team-e",
                "2",
                "4",
                "8Gi",
                "16Gi",
                "07:45:00",
                "NVIDIA T4",
                2,
            ),
        ]
        gcp_pods = []
        for (
            prj,
            eid,
            mnt,
            team,
            cpu_req,
            cpu_lim,
            mem_req,
            mem_lim,
            t,
            gpu_type,
            gpu_cnt,
        ) in gcp_lab_specs:
            started = f"{today}T{t}Z"
            gcp_pods.append(
                {
                    "name": f"jupyter-{eid}",
                    "namespace": "jupyter-gcp",
                    "node_name": "gke-gpu-pool-1",
                    "phase": "Running",
                    "display_status": "ok",
                    "image": "jupyter/tensorflow-notebook:cuda11",
                    "cpu_request": cpu_req,
                    "cpu_limit": cpu_lim,
                    "memory_request": mem_req,
                    "memory_limit": mem_lim,
                    "restart_count": 0,
                    "container_state": "running",
                    "started_at": started,
                    "conditions": _cond_ok(started),
                    "project": prj,
                    "employee_id": eid,
                    "mount": mnt,
                    "team": team,
                    "gpu_type": gpu_type,
                    "gpu_count": gpu_cnt,
                }
            )

        clusters = [
            {
                "id": "onprem-cpu",
                "label": "On-Prem CPU",
                "lab": {"pods": cpu_pods, "active_users": len(cpu_pods)},
            },
            {
                "id": "onprem-gpu",
                "label": "On-Prem GPU",
                "lab": {"pods": gpu_pods, "active_users": len(gpu_pods)},
            },
            {
                "id": "gcp-gpu",
                "label": "GCP GPU",
                "lab": {"pods": gcp_pods, "active_users": len(gcp_pods)},
            },
        ]

        events = [
            {
                "type": "Normal",
                "reason": "Scheduled",
                "message": "Successfully assigned jupyter/jupyterhub-0 to worker-node-1",
                "involved_object": "jupyterhub-0",
                "involved_kind": "Pod",
                "namespace": "jupyter",
                "count": 1,
                "source": "default-scheduler",
                "last_timestamp": f"{today}T00:00:00Z",
            },
            {
                "type": "Normal",
                "reason": "Started",
                "message": "Started container jupyterhub",
                "involved_object": "jupyterhub-0",
                "involved_kind": "Pod",
                "namespace": "jupyter",
                "count": 1,
                "source": "kubelet",
                "last_timestamp": f"{today}T00:00:02Z",
            },
            {
                "type": "Normal",
                "reason": "Started",
                "message": "Started container jupyterhub",
                "involved_object": "jupyterhub-1",
                "involved_kind": "Pod",
                "namespace": "jupyter",
                "count": 1,
                "source": "kubelet",
                "last_timestamp": f"{today}T00:00:03Z",
            },
            {
                "type": "Normal",
                "reason": "Started",
                "message": "Started container notebook",
                "involved_object": "jupyter-a453180",
                "involved_kind": "Pod",
                "namespace": "jupyter",
                "count": 1,
                "source": "kubelet",
                "last_timestamp": f"{today}T09:15:00Z",
            },
            {
                "type": "Warning",
                "reason": "FailedMount",
                "message": 'MountVolume.SetUp failed for volume "nfs-data-team2"',
                "involved_object": "jupyter-a278910",
                "involved_kind": "Pod",
                "namespace": "jupyter",
                "count": 2,
                "source": "kubelet",
                "last_timestamp": f"{today}T10:04:30Z",
            },
            {
                "type": "Normal",
                "reason": "Started",
                "message": "Started container notebook (GPU: NVIDIA A100)",
                "involved_object": "jupyter-a601234",
                "involved_kind": "Pod",
                "namespace": "jupyter-gpu",
                "count": 1,
                "source": "kubelet",
                "last_timestamp": f"{today}T08:00:05Z",
            },
            {
                "type": "Normal",
                "reason": "Started",
                "message": "Started container notebook (GPU: NVIDIA T4 x4)",
                "involved_object": "jupyter-a701111",
                "involved_kind": "Pod",
                "namespace": "jupyter-gcp",
                "count": 1,
                "source": "kubelet",
                "last_timestamp": f"{today}T07:30:05Z",
            },
        ]

        return {"hub": hub, "clusters": clusters, "events": events}


class RealJupyterProvider(BaseJupyterProvider):
    """JupyterHub API 연동 Provider."""

    def __init__(self, jupyterhub_url: str | None = None, jupyterhub_token: str | None = None):
        self.jupyterhub_url = jupyterhub_url
        self.jupyterhub_token = jupyterhub_token

    def get_jupyter_access(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Jupyter provider not yet implemented")

    def get_jupyter_cluster_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Jupyter provider not yet implemented")
