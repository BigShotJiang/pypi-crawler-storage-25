"""HDSP Provider Factory - Provider 번들 생성."""

import logging
import os
from dataclasses import dataclass
from typing import Any

from .api_provider import BaseApiProvider, MockApiProvider, RealApiProvider
from .backup_provider import BaseBackupProvider, MockBackupProvider, RealBackupProvider
from .cost_provider import BaseCostProvider, MockCostProvider, RealCostProvider
from .haproxy_provider import BaseHaproxyProvider, MockHaproxyProvider, RealHaproxyProvider
from .jupyter_provider import BaseJupyterProvider, MockJupyterProvider, RealJupyterProvider
from .k8s_provider import BaseK8sProvider, MockK8sProvider, RealK8sProvider
from .minio_provider import BaseMinioProvider, MockMinioProvider, RealMinioProvider
from .nfs_provider import BaseNfsProvider, MockNfsProvider, RealNfsProvider
from .pipeline_provider import BasePipelineProvider, MockPipelineProvider, RealPipelineProvider
from .registry_provider import BaseRegistryProvider, MockRegistryProvider, RealRegistryProvider
from .spark_provider import BaseSparkProvider, MockSparkProvider, RealSparkProvider

logger = logging.getLogger(__name__)


@dataclass
class HdspProviderBundle:
    """모든 HDSP Provider를 묶는 번들."""

    k8s: BaseK8sProvider
    spark: BaseSparkProvider
    minio: BaseMinioProvider
    nfs: BaseNfsProvider
    jupyter: BaseJupyterProvider
    haproxy: BaseHaproxyProvider
    registry: BaseRegistryProvider
    api: BaseApiProvider
    backup: BaseBackupProvider
    cost: BaseCostProvider
    pipeline: BasePipelineProvider


def create_hdsp_providers(
    provider_type: str | None = None,
    **kwargs: Any,
) -> HdspProviderBundle:
    """Factory function to create HDSP provider bundle.

    Args:
        provider_type: Provider type ("mock" or "real"). Defaults to HDSP_PROVIDER env var or "mock".
        **kwargs: Provider-specific settings (k8s_api_url, spark_history_url, etc.)

    Returns:
        HdspProviderBundle with all providers configured.
    """
    provider_type = provider_type or os.getenv("HDSP_PROVIDER", "mock")
    logger.info(f"Creating HDSP providers: type={provider_type}")

    if provider_type == "real":
        return HdspProviderBundle(
            k8s=RealK8sProvider(
                k8s_api_url=kwargs.get("k8s_api_url"),
                prometheus_url=kwargs.get("prometheus_url"),
            ),
            spark=RealSparkProvider(spark_history_url=kwargs.get("spark_history_url")),
            minio=RealMinioProvider(
                endpoint=kwargs.get("minio_endpoint"),
                access_key=kwargs.get("minio_access_key"),
                secret_key=kwargs.get("minio_secret_key"),
            ),
            nfs=RealNfsProvider(nfs_base_path=kwargs.get("nfs_base_path")),
            jupyter=RealJupyterProvider(
                jupyterhub_url=kwargs.get("jupyterhub_url"),
                jupyterhub_token=kwargs.get("jupyterhub_token"),
            ),
            haproxy=RealHaproxyProvider(haproxy_stats_url=kwargs.get("haproxy_stats_url")),
            registry=RealRegistryProvider(registry_url=kwargs.get("registry_url")),
            api=RealApiProvider(api_metrics_url=kwargs.get("api_metrics_url")),
            backup=RealBackupProvider(),
            cost=RealCostProvider(),
            pipeline=RealPipelineProvider(),
        )
    else:
        return HdspProviderBundle(
            k8s=MockK8sProvider(),
            spark=MockSparkProvider(),
            minio=MockMinioProvider(),
            nfs=MockNfsProvider(),
            jupyter=MockJupyterProvider(),
            haproxy=MockHaproxyProvider(),
            registry=MockRegistryProvider(),
            api=MockApiProvider(),
            backup=MockBackupProvider(),
            cost=MockCostProvider(),
            pipeline=MockPipelineProvider(),
        )
