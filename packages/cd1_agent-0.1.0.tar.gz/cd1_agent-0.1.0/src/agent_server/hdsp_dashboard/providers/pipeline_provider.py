"""Pipeline Provider - Universe/Sobicare 파이프라인 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime, timedelta

from src.common.timezone import KST
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BasePipelineProvider(ABC):
    @abstractmethod
    def get_universe_failures(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_sobicare_workflows(self, days: int = 31) -> dict[str, Any]: ...


class MockPipelineProvider(BasePipelineProvider):
    def get_universe_failures(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for i, d in enumerate(dates):
            ingest = random.randint(0, 4) + (8 if i % 7 == 0 else 0)
            transfer = random.randint(0, 2) + (6 if i % 10 == 0 else 0)
            daily.append({"date": d, "ingest": ingest, "transfer": transfer})
        return {"daily": daily, "is_mock": True}

    def get_sobicare_workflows(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for i, d in enumerate(dates):
            success = random.randint(20, 40) + (5 if i % 5 == 0 else 0)
            failure = random.randint(0, 3) + (6 if i % 7 == 0 else 0)
            daily.append({"date": d, "success": success, "failure": failure})

        now = datetime.now(KST)
        monthly = []
        for i in range(11, -1, -1):
            m_date = now - timedelta(days=i * 30)
            label = f"{m_date.year}-{m_date.month:02d}"
            success = random.randint(500, 780) + (80 if i % 3 == 0 else 0)
            failure = random.randint(10, 40) + (25 if i % 4 == 0 else 0)
            monthly.append({"month": label, "success": success, "failure": failure})

        return {"daily": daily, "monthly": monthly, "is_mock": True}


class RealPipelineProvider(BasePipelineProvider):
    """파이프라인 모니터링 API 연동 Provider."""

    def get_universe_failures(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Pipeline provider not yet implemented")

    def get_sobicare_workflows(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Pipeline provider not yet implemented")
