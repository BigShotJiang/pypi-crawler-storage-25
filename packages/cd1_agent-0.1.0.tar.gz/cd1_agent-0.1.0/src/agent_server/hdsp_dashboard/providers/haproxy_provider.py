"""HAProxy Provider - HAProxy 프론트엔드/백엔드 통계."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseHaproxyProvider(ABC):
    @abstractmethod
    def get_haproxy_stats(self, days: int = 31) -> dict[str, Any]: ...


class MockHaproxyProvider(BaseHaproxyProvider):
    def get_haproxy_stats(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        frontends: dict[str, Any] = {}
        for fname in ["hdsp-web"]:
            daily = []
            random.seed(hash(f"haproxy_fe_{fname}") & 0xFFFFFFFF)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                factor = 0.4 if is_weekend else 1.0
                daily.append(
                    {
                        "date": d,
                        "connections": max(0, round(1500 * factor + random.randint(-200, 400))),
                        "bytes_in_mb": round(max(0, 250 * factor + random.uniform(-40, 60)), 1),
                        "bytes_out_mb": round(max(0, 800 * factor + random.uniform(-100, 200)), 1),
                    }
                )
            frontends[fname] = {"daily": daily}

        backends: dict[str, Any] = {}
        for bname, active, rt_base in [("hdsp-api", 3, 45), ("spark-connect", 2, 80)]:
            daily = []
            random.seed(hash(f"haproxy_be_{bname}") & 0xFFFFFFFF)
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "response_time_ms": round(max(5, rt_base + random.uniform(-15, 25)), 1),
                        "error_rate_pct": round(max(0, random.uniform(0, 1.5)), 2),
                    }
                )
            backends[bname] = {"status": "UP", "active_servers": active, "daily": daily}

        return {"frontends": frontends, "backends": backends}


class RealHaproxyProvider(BaseHaproxyProvider):
    """HAProxy Stats API 연동 Provider."""

    def __init__(self, haproxy_stats_url: str | None = None):
        self.haproxy_stats_url = haproxy_stats_url

    def get_haproxy_stats(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real HAProxy provider not yet implemented")
