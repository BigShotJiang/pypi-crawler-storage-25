"""API Provider - HDSP API 에러/지연시간 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseApiProvider(ABC):
    @abstractmethod
    def get_hdsp_api_errors(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_hdsp_api_latency(self, days: int = 31) -> dict[str, Any]: ...


class MockApiProvider(BaseApiProvider):
    """Mock 데이터 기반 API Provider."""

    def get_hdsp_api_errors(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        for d in dates:
            err_4xx = random.randint(5, 30)
            err_5xx = random.randint(0, 5)
            if random.random() < 0.06:
                err_4xx += random.randint(20, 80)
            if random.random() < 0.04:
                err_5xx += random.randint(10, 40)
            daily.append({"date": d, "4xx": err_4xx, "5xx": err_5xx})
        return {"daily": daily}

    def get_hdsp_api_latency(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        random.seed(hash("hdsp_api_latency") & 0xFFFFFFFF)
        for d in dates:
            dt = datetime.fromisoformat(d)
            is_weekend = dt.weekday() >= 5
            factor = 0.6 if is_weekend else 1.0
            p50 = round(max(10, 45 * factor + random.uniform(-10, 15)), 1)
            p95 = round(max(p50 + 20, 120 * factor + random.uniform(-20, 40)), 1)
            p99 = round(max(p95 + 30, 250 * factor + random.uniform(-30, 80)), 1)
            rpm = max(0, round(320 * factor + random.randint(-60, 80)))
            daily.append(
                {"date": d, "p50_ms": p50, "p95_ms": p95, "p99_ms": p99, "requests_per_min": rpm}
            )
        return {"daily": daily}


class RealApiProvider(BaseApiProvider):
    """API 메트릭 수집 연동 Provider."""

    def __init__(self, api_metrics_url: str | None = None):
        self.api_metrics_url = api_metrics_url

    def get_hdsp_api_errors(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real API provider not yet implemented")

    def get_hdsp_api_latency(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real API provider not yet implemented")
