"""Cost Provider - 비용 절감 메트릭."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class BaseCostProvider(ABC):
    @abstractmethod
    def get_cost_explorer_savings(self) -> dict[str, Any]: ...
    @abstractmethod
    def get_usage_conversion_savings(self) -> dict[str, Any]: ...
    @abstractmethod
    def get_gcp_monthly_cost(self, year: int, env: Optional[str] = None) -> dict[str, Any]: ...
    @abstractmethod
    def get_gcp_daily_cost(self, year: int, month: int, env: Optional[str] = None) -> dict[str, Any]: ...


class MockCostProvider(BaseCostProvider):
    def get_cost_explorer_savings(self) -> dict[str, Any]:
        baseline = 55_000_000
        target = 350_000_000
        actuals = [
            ("2025-12", 42_000_000, False),
            ("2026-01", 40_000_000, False),
            ("2026-02", 38_000_000, False),
            ("2026-03", 36_000_000, True),
            ("2026-04", 34_000_000, True),
            ("2026-05", 33_000_000, True),
            ("2026-06", 31_000_000, True),
            ("2026-07", 30_000_000, True),
            ("2026-08", 28_000_000, True),
            ("2026-09", 26_000_000, True),
            ("2026-10", 25_000_000, True),
            ("2026-11", 24_000_000, True),
        ]
        cumulative = 0
        items = []
        for month, actual, projected in actuals:
            saving = baseline - actual
            cumulative += saving
            items.append(
                {
                    "month": month,
                    "baselineCost": baseline,
                    "actualCost": actual,
                    "monthlySaving": saving,
                    "cumulative": cumulative,
                    "isProjected": projected,
                }
            )
        return {"target": target, "baselineCost": baseline, "items": items}

    def get_usage_conversion_savings(self) -> dict[str, Any]:
        rows = [
            ("2025-12", 42_000_000, 14_000_000, False),
            ("2026-01", 45_000_000, 15_000_000, False),
            ("2026-02", 48_000_000, 15_500_000, False),
            ("2026-03", 46_000_000, 14_800_000, True),
            ("2026-04", 47_000_000, 14_500_000, True),
            ("2026-05", 49_000_000, 14_200_000, True),
            ("2026-06", 50_000_000, 14_000_000, True),
            ("2026-07", 51_000_000, 13_800_000, True),
            ("2026-08", 52_000_000, 13_500_000, True),
            ("2026-09", 53_000_000, 13_200_000, True),
            ("2026-10", 50_000_000, 12_800_000, True),
            ("2026-11", 48_000_000, 12_500_000, True),
        ]
        cumulative = 0
        items = []
        for month, aws, hdsp, projected in rows:
            saving = aws - hdsp
            cumulative += saving
            items.append(
                {
                    "month": month,
                    "awsEquivalentCost": aws,
                    "hdspActualCost": hdsp,
                    "monthlySaving": saving,
                    "cumulative": cumulative,
                    "isProjected": projected,
                }
            )
        return {"items": items}


    def get_gcp_monthly_cost(self, year: int, env: Optional[str] = None) -> dict[str, Any]:
        """GCP 월별 비용 (개발계/운영계 구분)."""
        import calendar
        from datetime import datetime

        now = datetime.now()
        current_ym = f"{now.year}{now.month:02d}"

        # 서비스별 월 기본 비용 (원)
        base_costs = {
            "dev": {"GCE-A100": 18_000_000, "GCE-L4": 8_000_000, "Cloud Storage": 3_000_000, "기타": 1_500_000},
            "prod": {"GCE-A100": 45_000_000, "GCE-L4": 22_000_000, "Cloud Storage": 8_000_000, "기타": 4_000_000},
        }

        budget = {
            "monthly_target": 110_000_000,
            "annual_total": 1_320_000_000,
        }

        def _build_months(env_key: str) -> list[dict[str, Any]]:
            costs = base_costs[env_key]
            months = []
            for m in range(1, 13):
                period = f"{year}{m:02d}"
                # 월별 변동 (0.88 ~ 1.15)
                import hashlib
                seed = int(hashlib.md5(f"{env_key}-{period}".encode()).hexdigest()[:8], 16)
                factor = 0.88 + (seed % 28) / 100
                services = {k: round(v * factor) for k, v in costs.items()}
                total = sum(services.values())
                months.append({"month": period, "services": services, "total": total, "is_projected": False})
            return months

        dev_months = _build_months("dev")
        prod_months = _build_months("prod")

        # 전체 = dev + prod 합산
        all_months: list[dict[str, Any]] = []
        for dm, pm in zip(dev_months, prod_months):
            merged_services: dict[str, int] = {}
            for k in {*dm["services"], *pm["services"]}:
                merged_services[k] = dm["services"].get(k, 0) + pm["services"].get(k, 0)
            all_months.append({
                "month": dm["month"],
                "services": merged_services,
                "total": dm["total"] + pm["total"],
                "is_projected": False,
            })

        # 미래 기간 예상치 설정
        for month_list in [dev_months, prod_months, all_months]:
            actual = [m for m in month_list if m["month"] <= current_ym and m["total"] > 0]
            recent = actual[-3:] if len(actual) >= 3 else actual
            avg_total = round(sum(m["total"] for m in recent) / len(recent)) if recent else 0
            for m in month_list:
                if m["month"] > current_ym:
                    m["is_projected"] = True
                    m["services"] = {}
                    m["total"] = avg_total

        # env 필터
        if env == "dev":
            target_months = dev_months
        elif env == "prod":
            target_months = prod_months
        else:
            target_months = all_months

        return {
            "year": year,
            "budget": budget,
            "months": target_months,
            "projection_method": "3개월 이동평균",
            "envs": {
                "dev": {"months": dev_months},
                "prod": {"months": prod_months},
            },
        }

    def get_gcp_daily_cost(self, year: int, month: int, env: Optional[str] = None) -> dict[str, Any]:
        """GCP 일별 비용."""
        import calendar
        import hashlib
        from datetime import datetime

        now = datetime.now()
        current_ymd = f"{now.year}{now.month:02d}{now.day:02d}"
        days_in_month = calendar.monthrange(year, month)[1]

        base_daily = {
            "dev": {"GCE-A100": 600_000, "GCE-L4": 270_000, "Cloud Storage": 100_000, "기타": 50_000},
            "prod": {"GCE-A100": 1_500_000, "GCE-L4": 730_000, "Cloud Storage": 270_000, "기타": 130_000},
        }

        budget_monthly = 110_000_000
        daily_target = round(budget_monthly / days_in_month)

        def _build_days(env_key: str) -> list[dict[str, Any]]:
            costs = base_daily[env_key]
            days = []
            for d in range(1, days_in_month + 1):
                period = f"{year}{month:02d}{d:02d}"
                seed = int(hashlib.md5(f"{env_key}-{period}".encode()).hexdigest()[:8], 16)
                factor = 0.85 + (seed % 30) / 100
                services = {k: round(v * factor) for k, v in costs.items()}
                total = sum(services.values())
                days.append({"day": period, "services": services, "total": total, "is_projected": False})
            return days

        dev_days = _build_days("dev")
        prod_days = _build_days("prod")

        all_days: list[dict[str, Any]] = []
        for dd, pd in zip(dev_days, prod_days):
            merged_services: dict[str, int] = {}
            for k in {*dd["services"], *pd["services"]}:
                merged_services[k] = dd["services"].get(k, 0) + pd["services"].get(k, 0)
            all_days.append({
                "day": dd["day"],
                "services": merged_services,
                "total": dd["total"] + pd["total"],
                "is_projected": False,
            })

        # 미래 일자 예상치
        for day_list in [dev_days, prod_days, all_days]:
            actual = [d for d in day_list if d["day"] <= current_ymd and d["total"] > 0]
            avg_total = round(sum(d["total"] for d in actual) / len(actual)) if actual else 0
            for d in day_list:
                if d["day"] > current_ymd:
                    d["is_projected"] = True
                    d["services"] = {}
                    d["total"] = avg_total

        if env == "dev":
            target_days = dev_days
        elif env == "prod":
            target_days = prod_days
        else:
            target_days = all_days

        return {
            "year": year,
            "month": month,
            "daily_target": daily_target,
            "days": target_days,
            "projection_method": "당월 일평균",
        }


class RealCostProvider(BaseCostProvider):
    """AWS Cost Explorer 연동 Provider."""

    def get_cost_explorer_savings(self) -> dict[str, Any]:
        raise NotImplementedError("Real Cost provider not yet implemented")

    def get_usage_conversion_savings(self) -> dict[str, Any]:
        raise NotImplementedError("Real Cost provider not yet implemented")

    def get_gcp_monthly_cost(self, year: int, env: Optional[str] = None) -> dict[str, Any]:
        raise NotImplementedError("Real GCP cost provider not yet implemented")

    def get_gcp_daily_cost(self, year: int, month: int, env: Optional[str] = None) -> dict[str, Any]:
        raise NotImplementedError("Real GCP cost provider not yet implemented")
