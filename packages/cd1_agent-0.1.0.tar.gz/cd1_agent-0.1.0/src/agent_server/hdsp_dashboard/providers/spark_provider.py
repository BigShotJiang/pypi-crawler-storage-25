"""Spark Provider - Spark 클러스터 및 Job 관련 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime, timedelta

from src.common.timezone import KST
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import (
    _daily_dates,
)


class BaseSparkProvider(ABC):
    @abstractmethod
    def get_spark_failures(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_spark_cluster_status(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_spark_jobs(self, cluster: str | None = None) -> dict[str, Any]: ...
    @abstractmethod
    def get_spark_job_logs(
        self, app_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]: ...
    @abstractmethod
    def get_spark_node_logs(
        self, node_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]: ...


class MockSparkProvider(BaseSparkProvider):
    """Mock 데이터 기반 Spark Provider."""

    def get_spark_failures(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        teams: dict[str, list] = {}
        for team_name in ["분석1팀", "분석2팀", "분석3팀"]:
            data = []
            for d in dates:
                failures = random.randint(0, 3)
                if random.random() < 0.07:
                    failures += random.randint(5, 15)
                data.append({"date": d, "failures": failures})
            teams[team_name] = data
        return {"teams": teams}

    def get_spark_cluster_status(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        clusters: dict[str, Any] = {}
        for name, status, exec_base in [
            ("spark-connect", "RUNNING", 21),
            ("spark-operator", "RUNNING", 17),
        ]:
            daily = []
            random.seed(hash(f"spark_cluster_{name}") & 0xFFFFFFFF)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                factor = 0.4 if is_weekend else 1.0
                executors = max(exec_base - 1, round(exec_base * factor + random.randint(-1, 2)))
                cpu_cores = executors * random.randint(2, 4)
                memory_gb = executors * random.randint(4, 8)
                submitted = max(0, round(15 * factor + random.randint(-5, 10)))
                completed = max(0, submitted - random.randint(0, 2))
                failed = max(0, random.randint(0, 2) if random.random() < 0.15 else 0)
                daily.append(
                    {
                        "date": d,
                        "cpu_cores": cpu_cores,
                        "memory_gb": memory_gb,
                        "jobs_submitted": submitted,
                        "jobs_completed": completed,
                        "jobs_failed": failed,
                    }
                )

            # 노드 목록 생성 (1 driver + N executor)
            prefix = "spark-conn" if name == "spark-connect" else "spark-op"
            nodes: dict[str, Any] = {}
            random.seed(hash(f"spark_nodes_{name}") & 0xFFFFFFFF)
            # driver node
            nodes[f"{prefix}-driver-0"] = {
                "hostname": f"{prefix}-driver-0.spark.svc.cluster.local",
                "role": "driver",
                "status": "Running",
                "cpu_usage_pct": round(random.uniform(20, 60), 1),
                "memory_usage_pct": round(random.uniform(30, 70), 1),
                "cpu_cores": 4,
                "memory_gb": 8,
                "uptime_hours": random.randint(100, 2000),
            }
            # executor nodes
            for i in range(exec_base):
                statuses = ["Running"] * 18 + ["Pending"] + ["Failed"]
                st = random.choice(statuses)
                nodes[f"{prefix}-exec-{i}"] = {
                    "hostname": f"{prefix}-exec-{i}.spark.svc.cluster.local",
                    "role": "executor",
                    "status": st,
                    "cpu_usage_pct": round(random.uniform(10, 95), 1),
                    "memory_usage_pct": round(random.uniform(20, 90), 1),
                    "cpu_cores": random.choice([2, 4]),
                    "memory_gb": random.choice([4, 8, 16]),
                    "uptime_hours": random.randint(1, 2000),
                }

            running_nodes = sum(1 for n in nodes.values() if n["status"] == "Running")
            pending_nodes = sum(1 for n in nodes.values() if n["status"] == "Pending")
            clusters[name] = {
                "status": status,
                "executors": {
                    "running": running_nodes,
                    "pending": pending_nodes,
                    "total": len(nodes),
                },
                "daily": daily,
                "nodes": nodes,
            }
        return {
            "operator": {
                "name": "spark-operator",
                "version": "v1beta2-1.4.6",
                "status": "Running",
            },
            "clusters": clusters,
        }

    def get_spark_jobs(self, cluster: str | None = None) -> dict[str, Any]:
        """현재 실행 중인 Spark Job 목록 (mock)."""
        now = datetime.now(KST)
        all_jobs = [
            # spark-connect jobs
            {
                "app_id": "app-20260226-001",
                "name": "ETL_daily_batch",
                "cluster": "spark-connect",
                "status": "RUNNING",
                "started_at": (now - timedelta(hours=2, minutes=15)).isoformat(),
                "duration_sec": 8100,
                "executor_count": 4,
                "driver_node": "spark-conn-driver-0",
            },
            {
                "app_id": "app-20260226-002",
                "name": "feature_store_sync",
                "cluster": "spark-connect",
                "status": "RUNNING",
                "started_at": (now - timedelta(hours=1, minutes=30)).isoformat(),
                "duration_sec": 5400,
                "executor_count": 6,
                "driver_node": "spark-conn-driver-0",
            },
            {
                "app_id": "app-20260226-003",
                "name": "user_event_agg",
                "cluster": "spark-connect",
                "status": "RUNNING",
                "started_at": (now - timedelta(minutes=45)).isoformat(),
                "duration_sec": 2700,
                "executor_count": 3,
                "driver_node": "spark-conn-driver-0",
            },
            {
                "app_id": "app-20260226-004",
                "name": "data_quality_check",
                "cluster": "spark-connect",
                "status": "SUCCEEDED",
                "started_at": (now - timedelta(hours=3)).isoformat(),
                "duration_sec": 1800,
                "executor_count": 2,
                "driver_node": "spark-conn-driver-0",
            },
            {
                "app_id": "app-20260226-005",
                "name": "clickstream_ingest",
                "cluster": "spark-connect",
                "status": "RUNNING",
                "started_at": (now - timedelta(minutes=12)).isoformat(),
                "duration_sec": 720,
                "executor_count": 5,
                "driver_node": "spark-conn-driver-0",
            },
            # spark-operator jobs
            {
                "app_id": "app-20260226-006",
                "name": "model_training_v2",
                "cluster": "spark-operator",
                "status": "RUNNING",
                "started_at": (now - timedelta(hours=4)).isoformat(),
                "duration_sec": 14400,
                "executor_count": 8,
                "driver_node": "spark-op-driver-0",
            },
            {
                "app_id": "app-20260226-007",
                "name": "log_analysis_daily",
                "cluster": "spark-operator",
                "status": "RUNNING",
                "started_at": (now - timedelta(hours=1)).isoformat(),
                "duration_sec": 3600,
                "executor_count": 3,
                "driver_node": "spark-op-driver-0",
            },
            {
                "app_id": "app-20260226-008",
                "name": "report_generator",
                "cluster": "spark-operator",
                "status": "FAILED",
                "started_at": (now - timedelta(hours=2, minutes=30)).isoformat(),
                "duration_sec": 4500,
                "executor_count": 2,
                "driver_node": "spark-op-driver-0",
            },
            {
                "app_id": "app-20260226-009",
                "name": "dimension_table_build",
                "cluster": "spark-operator",
                "status": "RUNNING",
                "started_at": (now - timedelta(minutes=20)).isoformat(),
                "duration_sec": 1200,
                "executor_count": 4,
                "driver_node": "spark-op-driver-0",
            },
        ]
        if cluster:
            all_jobs = [j for j in all_jobs if j["cluster"] == cluster]
        return {"jobs": all_jobs}

    def get_spark_job_logs(
        self, app_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        """Spark Job 로그 (mock)."""
        now = datetime.now(KST)

        # 앱별 이름 매핑
        app_names = {
            "app-20260226-001": "ETL_daily_batch",
            "app-20260226-002": "feature_store_sync",
            "app-20260226-003": "user_event_agg",
            "app-20260226-004": "data_quality_check",
            "app-20260226-005": "clickstream_ingest",
            "app-20260226-006": "model_training_v2",
            "app-20260226-007": "log_analysis_daily",
            "app-20260226-008": "report_generator",
            "app-20260226-009": "dimension_table_build",
        }
        job_name = app_names.get(app_id, "unknown_job")

        # 실감나는 Spark 로그 템플릿
        log_templates = [
            ("INFO", f"SparkContext initialized for {job_name}"),
            ("INFO", "Spark configuration: spark.executor.memory=8g, spark.executor.cores=4"),
            ("INFO", "Registered BlockManager with driver"),
            ("INFO", "Starting job 0: collect at SparkPlan.scala:234"),
            ("INFO", "Stage 0 (collect): Submitted 4 tasks"),
            ("INFO", "Stage 0 completed in 2.3s (4/4 tasks)"),
            ("INFO", "Starting job 1: save at DataFrameWriter.scala:421"),
            ("INFO", "Stage 1 (save): Submitted 16 tasks"),
            (
                "INFO",
                "Executor 1: Finished task 0.0 in stage 1.0 (TID 4) in 1542ms on spark-conn-exec-0",
            ),
            (
                "INFO",
                "Executor 2: Finished task 1.0 in stage 1.0 (TID 5) in 1823ms on spark-conn-exec-1",
            ),
            ("WARN", "Lost task 2.0 in stage 1.0 (TID 6) on executor 3: FetchFailedException"),
            ("INFO", "Retrying task 2.0 in stage 1.0 (TID 6) on executor 4"),
            ("INFO", "Stage 1 completed in 12.8s (16/16 tasks)"),
            ("INFO", "Shuffle read: 256.3 MB / Shuffle write: 128.7 MB"),
            ("INFO", "Starting job 2: save at DataFrameWriter.scala:421"),
            ("INFO", "Stage 2 (save): Submitted 32 tasks"),
            ("WARN", "Executor 5: GC pause 1.2s (ConcurrentMarkSweep)"),
            ("INFO", "Executor 5 recovered after GC, resuming tasks"),
            ("INFO", "Stage 2 progress: 16/32 tasks completed"),
            ("INFO", "Stage 2 progress: 28/32 tasks completed"),
            ("INFO", "Stage 2 completed in 45.2s (32/32 tasks)"),
            ("INFO", "Total shuffle read: 1.2 GB / Total shuffle write: 512 MB"),
            ("INFO", "Starting job 3: count at SparkPlan.scala:567"),
            ("INFO", "Stage 3 (count): Submitted 8 tasks"),
            ("WARN", "Executor 2: High memory usage 89% (7.1 GB / 8.0 GB)"),
            ("INFO", "Stage 3 completed in 5.1s (8/8 tasks)"),
            ("INFO", "Broadcast variable 0 stored as values in memory (estimated size 24.5 MB)"),
            ("INFO", "Starting job 4: insertInto at SparkPlan.scala:891"),
            ("INFO", "Stage 4 (insertInto): Submitted 64 tasks"),
            ("WARN", "Speculation: Task 12.0 in stage 4.0 is slow, launching speculative copy"),
            ("INFO", "Stage 4 progress: 32/64 tasks completed"),
            (
                "ERROR",
                "Task 45.0 in stage 4.0 failed: java.lang.OutOfMemoryError: GC overhead limit exceeded",
            ),
            (
                "WARN",
                "Lost executor 7 on spark-conn-exec-6: Container killed by YARN for exceeding memory limits",
            ),
            ("INFO", "Executor 7 replaced by executor 8 on spark-conn-exec-7"),
            ("INFO", "Retrying task 45.0 in stage 4.0 on executor 8"),
            ("INFO", "Stage 4 progress: 56/64 tasks completed"),
            ("INFO", "Stage 4 completed in 128.3s (64/64 tasks)"),
            ("INFO", "Data written: 2.1 GB to s3a://data-lake/output/"),
            ("INFO", "Total shuffle read: 4.8 GB / Total shuffle write: 2.1 GB"),
            ("INFO", "Peak execution memory per executor: 6.2 GB"),
            ("INFO", f"Job {job_name} completed successfully"),
            ("INFO", "SparkContext stopped"),
            ("INFO", "Spark session closed"),
            ("WARN", "Some executors had high GC overhead (>10%): [exec-2, exec-5]"),
            ("INFO", "Driver memory: 2.1 GB / 4.0 GB used"),
            ("INFO", "Total elapsed time: 3m 45s"),
            ("INFO", "Output records: 12,847,293"),
            ("INFO", "Partition statistics: min=1.2MB, max=48.3MB, avg=32.8MB"),
            ("WARN", "Skewed partitions detected: partition 7 (48.3MB) is 1.5x average"),
            ("INFO", "Checkpointing state to s3a://spark-checkpoints/"),
            ("INFO", "Checkpoint completed in 2.1s"),
            ("ERROR", "Metrics reporter failed to send to Prometheus: Connection refused"),
            ("INFO", "Falling back to local metrics storage"),
            ("INFO", "Cleanup: Removed 24 shuffle blocks (1.8 GB)"),
            ("INFO", "Executor allocation: requested=4, active=4, pending=0"),
            ("INFO", "DAG scheduler: All stages completed for job"),
        ]

        logs = []
        base_time = now - timedelta(hours=2)
        for i, (lvl, msg) in enumerate(log_templates):
            ts = base_time + timedelta(seconds=i * random.randint(1, 30))
            logs.append({"timestamp": ts.isoformat(), "level": lvl, "message": msg})

        if level:
            logs = [entry for entry in logs if entry["level"] == level.upper()]
        logs = logs[:limit]

        return {"app_id": app_id, "logs": logs}

    def get_spark_node_logs(
        self, node_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        """Spark 노드(driver/executor) 로그 (mock)."""
        now = datetime.now(KST)
        is_driver = "driver" in node_id

        if is_driver:
            templates = [
                ("INFO", "SparkContext: Starting Spark driver"),
                ("INFO", "SecurityManager: Authentication disabled"),
                ("INFO", "Utils: Successfully started service 'sparkDriver' on port 7078"),
                ("INFO", "SparkEnv: Registering MapOutputTracker"),
                ("INFO", "SparkEnv: Registering BlockManagerMaster"),
                ("INFO", "BlockManagerMasterEndpoint: Registering block manager"),
                ("INFO", "SparkContext: Added JAR /opt/spark/jars/spark-sql_2.12-3.5.0.jar"),
                (
                    "INFO",
                    "SchedulerBackend: Connected to Spark cluster with app ID app-20260226-001",
                ),
                ("INFO", "DAGScheduler: Starting event processing thread"),
                ("INFO", "HeartbeatReceiver: Registered executor 0"),
                ("INFO", "HeartbeatReceiver: Registered executor 1"),
                ("INFO", "HeartbeatReceiver: Registered executor 2"),
                (
                    "WARN",
                    "HeartbeatReceiver: Removing executor 3 with no recent heartbeats: 120016 ms exceeds timeout",
                ),
                ("INFO", "DAGScheduler: Executor 3 lost, re-queuing 2 tasks"),
                ("INFO", "HeartbeatReceiver: Registered executor 4 (replacement)"),
                ("INFO", "BlockManagerMasterEndpoint: Registered executor 4 with 4.5 GB RAM"),
                ("INFO", "TaskSchedulerImpl: Launching task 12 on executor 1 (spark-conn-exec-1)"),
                ("INFO", "TaskSchedulerImpl: Launching task 13 on executor 2 (spark-conn-exec-2)"),
                (
                    "INFO",
                    "DAGScheduler: Stage 3 (save at DataFrameWriter.scala:421) finished in 12.4s",
                ),
                ("INFO", "ContextCleaner: Cleaned shuffle 5"),
                (
                    "INFO",
                    "BlockManagerInfo: Removed broadcast_4 on spark-conn-exec-0:44781 in memory",
                ),
                (
                    "WARN",
                    "TaskSetManager: Lost task 7.0 in stage 4 (TID 31) on executor 2: FetchFailedException",
                ),
                ("INFO", "TaskSetManager: Starting task 7.1 (retry) on executor 1"),
                ("INFO", "MemoryStore: Total memory used: 2.8 GB / 4.0 GB"),
                ("INFO", "DAGScheduler: All stages completed for job 5"),
                ("INFO", "SparkUI: Enabled SSL on port 4040"),
                ("INFO", "SchedulerBackend: Executor allocation: 4 active, 0 pending"),
                ("WARN", "NettyRpcEnv: Slow RPC call to executor 2: 3200ms"),
                ("INFO", "DAGScheduler: Job 6 submitted (count at SparkPlan.scala:234)"),
                (
                    "ERROR",
                    "LiveListenerBus: SparkListenerJobEnd listener threw exception: NullPointerException",
                ),
                ("INFO", "LiveListenerBus: Event queue recovered after error"),
            ]
        else:
            exec_id = node_id.split("-")[-1]
            templates = [
                ("INFO", f"CoarseGrainedExecutorBackend: Executor {exec_id} starting"),
                (
                    "INFO",
                    "CoarseGrainedExecutorBackend: Connected to driver at spark-conn-driver-0:7078",
                ),
                (
                    "INFO",
                    f"Executor: Starting executor ID {exec_id} on host {node_id}.spark.svc.cluster.local",
                ),
                ("INFO", "MemoryManager: Allocated 4.0 GB for execution, 2.0 GB for storage"),
                ("INFO", "BlockManager: Initialized BlockManager with 6.0 GB max memory"),
                ("INFO", "TransportClientFactory: Successfully created connection to driver"),
                ("INFO", "Executor: Running task 0.0 in stage 0.0 (TID 1)"),
                (
                    "INFO",
                    "ShuffleBlockFetcherIterator: Getting 8 non-empty blocks from 4 addresses",
                ),
                ("INFO", "ShuffleBlockFetcherIterator: Started 4 remote fetches in 45ms"),
                (
                    "INFO",
                    "Executor: Finished task 0.0 in stage 0.0 (TID 1). 2485 bytes result sent to driver",
                ),
                ("INFO", "Executor: Running task 3.0 in stage 1.0 (TID 7)"),
                (
                    "WARN",
                    "MemoryStore: Not enough space to cache rdd_4_3 in memory (requested 256.0 MB, available 128.5 MB)",
                ),
                ("INFO", "BlockManager: Dropping block rdd_3_1 from memory (evicted)"),
                (
                    "INFO",
                    "Executor: Finished task 3.0 in stage 1.0 (TID 7). 1842 bytes result sent to driver",
                ),
                ("INFO", "Executor: Running task 8.0 in stage 2.0 (TID 15)"),
                ("INFO", "TorrentBroadcast: Reading broadcast variable 2 from driver"),
                ("INFO", "TorrentBroadcast: Read 4.2 MB broadcast in 120ms"),
                ("WARN", "GarbageCollectionMetrics: Major GC pause 850ms (ConcurrentMarkSweep)"),
                ("INFO", "MemoryStore: Total memory used: 3.2 GB / 4.0 GB (80%)"),
                (
                    "INFO",
                    "Executor: Finished task 8.0 in stage 2.0 (TID 15). 3012 bytes result sent to driver",
                ),
                ("INFO", "Executor: Running task 14.0 in stage 3.0 (TID 22)"),
                (
                    "INFO",
                    "ShuffleBlockFetcherIterator: Getting 16 non-empty blocks from 8 addresses",
                ),
                (
                    "ERROR",
                    "ShuffleBlockFetcherIterator: Failed to fetch block shuffle_2_7_0 from executor 5: Connection refused",
                ),
                (
                    "WARN",
                    "RetryingBlockFetcher: Retrying fetch of shuffle_2_7_0 from executor 5 (attempt 1/3)",
                ),
                ("INFO", "RetryingBlockFetcher: Successfully fetched shuffle_2_7_0 on retry"),
                (
                    "INFO",
                    "Executor: Finished task 14.0 in stage 3.0 (TID 22). 4521 bytes result sent to driver",
                ),
                ("INFO", "DiskBlockManager: Disk space used: 1.8 GB for shuffle files"),
                ("INFO", "BlockManager: Cleanup: removed 12 shuffle blocks (890 MB)"),
                ("INFO", "Executor: Running task 21.0 in stage 4.0 (TID 35)"),
                ("WARN", "MemoryStore: Memory usage approaching limit: 3.8 GB / 4.0 GB (95%)"),
                ("INFO", "MemoryManager: Spilling 512 MB to disk"),
            ]

        logs = []
        base_time = now - timedelta(hours=1)
        random.seed(hash(f"node_logs_{node_id}") & 0xFFFFFFFF)
        for i, (lvl, msg) in enumerate(templates):
            ts = base_time + timedelta(seconds=i * random.randint(2, 45))
            logs.append({"timestamp": ts.isoformat(), "level": lvl, "message": msg})

        if level:
            logs = [entry for entry in logs if entry["level"] == level.upper()]
        logs = logs[:limit]

        return {"node_id": node_id, "logs": logs}


class RealSparkProvider(BaseSparkProvider):
    """Spark History Server 연동 Provider."""

    def __init__(self, spark_history_url: str | None = None):
        self.spark_history_url = spark_history_url

    def get_spark_failures(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Spark provider not yet implemented")

    def get_spark_cluster_status(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Spark provider not yet implemented")

    def get_spark_jobs(self, cluster: str | None = None) -> dict[str, Any]:
        raise NotImplementedError("Real Spark provider not yet implemented")

    def get_spark_job_logs(
        self, app_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        raise NotImplementedError("Real Spark provider not yet implemented")

    def get_spark_node_logs(
        self, node_id: str, level: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        raise NotImplementedError("Real Spark provider not yet implemented")
