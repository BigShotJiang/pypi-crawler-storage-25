"""Docker Registry Provider - Docker Registry 통계."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseRegistryProvider(ABC):
    @abstractmethod
    def get_docker_registry_stats(self, days: int = 31) -> dict[str, Any]: ...


class MockRegistryProvider(BaseRegistryProvider):
    def get_docker_registry_stats(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        daily = []
        images = 120
        tags = 450
        storage = 85.0
        random.seed(hash("docker_registry") & 0xFFFFFFFF)
        for d in dates:
            images += random.randint(0, 2)
            tags += random.randint(0, 5)
            storage += random.uniform(0, 0.8)
            pulls = max(0, 200 + random.randint(-40, 60))
            pushes = max(0, 15 + random.randint(-5, 10))
            daily.append(
                {
                    "date": d,
                    "total_images": images,
                    "total_tags": tags,
                    "pulls": pulls,
                    "pushes": pushes,
                    "storage_gb": round(storage, 1),
                }
            )
        return {"daily": daily}


class RealRegistryProvider(BaseRegistryProvider):
    """Docker Registry V2 HTTP API 연동 Provider."""

    def __init__(self, registry_url: str | None = None):
        self.registry_url = registry_url

    def get_docker_registry_stats(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real Registry provider not yet implemented")
