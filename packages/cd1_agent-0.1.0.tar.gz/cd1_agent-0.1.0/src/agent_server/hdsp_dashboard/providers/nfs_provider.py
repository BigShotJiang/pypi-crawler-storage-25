"""NFS Provider - NAS 사용량/IOPS/디렉토리 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_metrics_service import _daily_dates


class BaseNfsProvider(ABC):
    @abstractmethod
    def get_nfs_usage(self, days: int = 31) -> dict[str, Any]: ...

    @abstractmethod
    def get_nfs_iops(self, days: int = 31) -> dict[str, Any]: ...

    @abstractmethod
    def get_nfs_directories(self, mount_path: str, path: str = "") -> list[dict[str, Any]]: ...


# ── Mock NFS directory data ─────────────────────────────

_MOCK_NFS_DIRECTORIES: dict[str, dict[str, list[dict[str, Any]]]] = {
    "/data/team1": {
        "": [
            {"name": "projects/", "size_gb": 450, "file_count": 12_000},
            {"name": "datasets/", "size_gb": 380, "file_count": 8_500},
            {"name": "models/", "size_gb": 220, "file_count": 3_200},
            {"name": "notebooks/", "size_gb": 150, "file_count": 2_800},
        ],
        "projects/": [
            {"name": "anomaly-detection/", "size_gb": 180, "file_count": 4_500},
            {"name": "forecasting/", "size_gb": 150, "file_count": 3_800},
            {"name": "data-pipeline/", "size_gb": 120, "file_count": 3_700},
        ],
        "datasets/": [
            {"name": "raw/", "size_gb": 200, "file_count": 4_200},
            {"name": "processed/", "size_gb": 120, "file_count": 2_800},
            {"name": "features/", "size_gb": 60, "file_count": 1_500},
        ],
    },
    "/data/team2": {
        "": [
            {"name": "research/", "size_gb": 320, "file_count": 7_500},
            {"name": "experiments/", "size_gb": 180, "file_count": 4_200},
            {"name": "outputs/", "size_gb": 150, "file_count": 3_800},
        ],
        "research/": [
            {"name": "nlp/", "size_gb": 140, "file_count": 3_200},
            {"name": "vision/", "size_gb": 110, "file_count": 2_500},
            {"name": "tabular/", "size_gb": 70, "file_count": 1_800},
        ],
        "experiments/": [
            {"name": "2026-02/", "size_gb": 45, "file_count": 1_200},
            {"name": "2026-01/", "size_gb": 55, "file_count": 1_500},
            {"name": "2025/", "size_gb": 80, "file_count": 1_500},
        ],
    },
    "/data/shared": {
        "": [
            {"name": "common-datasets/", "size_gb": 520, "file_count": 15_000},
            {"name": "pretrained-models/", "size_gb": 280, "file_count": 1_200},
            {"name": "tools/", "size_gb": 45, "file_count": 800},
        ],
        "common-datasets/": [
            {"name": "public/", "size_gb": 280, "file_count": 8_000},
            {"name": "internal/", "size_gb": 180, "file_count": 5_000},
            {"name": "external/", "size_gb": 60, "file_count": 2_000},
        ],
        "pretrained-models/": [
            {"name": "bert/", "size_gb": 120, "file_count": 400},
            {"name": "resnet/", "size_gb": 80, "file_count": 350},
            {"name": "custom/", "size_gb": 80, "file_count": 450},
        ],
    },
}


class MockNfsProvider(BaseNfsProvider):
    def get_nfs_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        teams: dict[str, list] = {}
        for team_name, base_gb, daily_growth in [
            ("분석1팀", 1200, 4),
            ("분석2팀", 680, 2.5),
            ("분석3팀", 350, 1),
        ]:
            data = []
            val = base_gb
            for d in dates:
                val += random.uniform(0, daily_growth)
                data.append({"date": d, "usage_gb": round(val, 1)})
            teams[team_name] = data
        return {"teams": teams}

    def get_nfs_iops(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        mounts: dict[str, Any] = {}

        # 사용자 직접 마운트 경로
        for path, read_base, write_base, lat_base in [
            ("/data/team1", 1200, 400, 2.5),
            ("/data/team2", 800, 300, 3.0),
            ("/data/shared", 2000, 600, 1.8),
        ]:
            daily = []
            random.seed(hash(f"nas_{path}") & 0xFFFFFFFF)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                factor = 0.3 if is_weekend else 1.0
                daily.append(
                    {
                        "date": d,
                        "read_iops": max(0, round(read_base * factor + random.randint(-200, 300))),
                        "write_iops": max(0, round(write_base * factor + random.randint(-80, 120))),
                        "latency_ms": round(max(0.5, lat_base + random.uniform(-0.8, 1.2)), 1),
                    }
                )
            mounts[path] = {"daily": daily, "source": "user"}

        # Velero 백업 경로
        for path, read_base, write_base, lat_base in [
            ("/backup/velero/etcd", 300, 800, 4.2),
            ("/backup/velero/pv-snapshots", 150, 1200, 5.5),
        ]:
            daily = []
            random.seed(hash(f"nas_{path}") & 0xFFFFFFFF)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                # Velero 백업은 새벽 시간대 활동 → 주중/주말 차이 적음
                factor = 0.7 if is_weekend else 1.0
                daily.append(
                    {
                        "date": d,
                        "read_iops": max(0, round(read_base * factor + random.randint(-50, 100))),
                        "write_iops": max(
                            0, round(write_base * factor + random.randint(-100, 200))
                        ),
                        "latency_ms": round(max(1.0, lat_base + random.uniform(-1.0, 2.0)), 1),
                    }
                )
            mounts[path] = {"daily": daily, "source": "velero"}

        # 현재 실행 중인 Jupyter Lab Pod 목록 (NAS 마운트 연결)
        jupyter_pods = [
            {
                "name": "jupyter-lab-a453180",
                "namespace": "jupyter",
                "status": "Running",
                "project": "CD1-Agent",
                "employee_id": "a453180",
                "mount": "/data/team1",
                "cpu": "500m",
                "memory": "2Gi",
                "start_time": dates[-1] + "T09:15:00",
            },
            {
                "name": "jupyter-lab-a312045",
                "namespace": "jupyter",
                "status": "Running",
                "project": "이상탐지-PoC",
                "employee_id": "a312045",
                "mount": "/data/team1",
                "cpu": "1",
                "memory": "4Gi",
                "start_time": dates[-1] + "T08:30:00",
            },
            {
                "name": "jupyter-lab-a278910",
                "namespace": "jupyter",
                "status": "Running",
                "project": "로그분석-v2",
                "employee_id": "a278910",
                "mount": "/data/team2",
                "cpu": "500m",
                "memory": "2Gi",
                "start_time": dates[-1] + "T10:05:00",
            },
            {
                "name": "jupyter-lab-a501322",
                "namespace": "jupyter",
                "status": "Running",
                "project": "MLOps-파이프라인",
                "employee_id": "a501322",
                "mount": "/data/shared",
                "cpu": "2",
                "memory": "8Gi",
                "start_time": dates[-1] + "T07:45:00",
            },
            {
                "name": "jupyter-lab-a189473",
                "namespace": "jupyter",
                "status": "Running",
                "project": "추천모델-학습",
                "employee_id": "a189473",
                "mount": "/data/team2",
                "cpu": "1",
                "memory": "4Gi",
                "start_time": dates[-1] + "T11:20:00",
            },
        ]

        # Velero 백업 Pod 목록
        velero_pods = [
            {
                "name": "velero-server-0",
                "namespace": "velero",
                "status": "Running",
                "schedule": "0 2 * * *",
                "target": "/backup/velero/etcd",
                "last_backup": dates[-1] + "T02:15:00",
            },
            {
                "name": "velero-server-1",
                "namespace": "velero",
                "status": "Running",
                "schedule": "0 3 * * *",
                "target": "/backup/velero/pv-snapshots",
                "last_backup": dates[-1] + "T03:22:00",
            },
        ]

        return {
            "mounts": mounts,
            "jupyter_pods": jupyter_pods,
            "velero_pods": velero_pods,
        }

    def get_nfs_directories(self, mount_path: str, path: str = "") -> list[dict[str, Any]]:
        return _MOCK_NFS_DIRECTORIES.get(mount_path, {}).get(path, [])


class RealNfsProvider(BaseNfsProvider):
    def __init__(self, nfs_base_path: str | None = None) -> None:
        self._nfs_base_path = nfs_base_path

    def get_nfs_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError

    def get_nfs_iops(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError

    def get_nfs_directories(self, mount_path: str, path: str = "") -> list[dict[str, Any]]:
        raise NotImplementedError
