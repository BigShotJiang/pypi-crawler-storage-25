"""
Supervisor Agent Graph.

LangGraph StateGraph 정의: collect → correlate → deduplicate → assess → 조건분기.
"""

from typing import Literal

from langgraph.graph import END, StateGraph

from src.agent_server.supervisor.nodes import (
    collect_node,
    correlate_node,
    create_assess_node,
    create_deduplicate_node,
    create_publish_node,
    hitl_checkpoint_node,
)
from src.agent_server.supervisor.services.incident_store import IncidentStoreProvider
from src.agent_server.supervisor.state import SupervisorState


def _after_assess(state: SupervisorState) -> Literal["publish", "hitl_checkpoint", "end"]:
    """assess 이후 분기 결정."""
    incidents = state.get("incidents", [])
    if not incidents:
        return "end"
    if state.get("requires_hitl", False):
        return "hitl_checkpoint"
    return "publish"


def create_supervisor_graph(
    llm_client=None,
    incident_store: IncidentStoreProvider | None = None,
    event_publisher=None,
) -> StateGraph:
    """Supervisor 에이전트 StateGraph 생성.

    Args:
        llm_client: LLMClient 인스턴스 (None이면 fallback 규칙 사용)
        incident_store: 인시던트 저장소 Provider
        event_publisher: EventBridge 발행기

    Returns:
        컴파일 전 StateGraph

    그래프 흐름:
        collect → correlate → deduplicate → assess → 조건분기
        (수집 → 상관관계 → 중복제거 → LLM 통합분석)
    """
    # incident_store 기본값
    if incident_store is None:
        from src.agent_server.supervisor.services.incident_store import (
            MockIncidentStore,
        )

        incident_store = MockIncidentStore()

    workflow = StateGraph(SupervisorState)

    # 노드 등록
    workflow.add_node("collect", collect_node)
    workflow.add_node("correlate", correlate_node)
    workflow.add_node("deduplicate", create_deduplicate_node(incident_store))
    workflow.add_node("assess", create_assess_node(llm_client))
    workflow.add_node("publish", create_publish_node(event_publisher))
    workflow.add_node("hitl_checkpoint", hitl_checkpoint_node)

    # 엔트리 포인트
    workflow.set_entry_point("collect")

    # 엣지: collect → correlate → deduplicate → assess
    workflow.add_edge("collect", "correlate")
    workflow.add_edge("correlate", "deduplicate")
    workflow.add_edge("deduplicate", "assess")

    # assess 이후 조건분기
    workflow.add_conditional_edges(
        "assess",
        _after_assess,
        {
            "publish": "publish",
            "hitl_checkpoint": "hitl_checkpoint",
            "end": END,
        },
    )

    # 종료 엣지
    workflow.add_edge("publish", END)
    workflow.add_edge("hitl_checkpoint", END)

    return workflow


def compile_supervisor(
    llm_client=None,
    incident_store: IncidentStoreProvider | None = None,
    event_publisher=None,
    checkpointer=None,
):
    """Supervisor 그래프를 컴파일.

    Args:
        llm_client: LLMClient 인스턴스
        incident_store: 인시던트 저장소 Provider
        event_publisher: EventBridge 발행기
        checkpointer: 상태 체크포인터

    Returns:
        컴파일된 그래프
    """
    graph = create_supervisor_graph(llm_client, incident_store, event_publisher)
    if checkpointer:
        return graph.compile(checkpointer=checkpointer)
    return graph.compile()
