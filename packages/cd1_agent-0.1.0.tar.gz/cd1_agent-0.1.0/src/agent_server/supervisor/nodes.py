"""
Supervisor Agent Nodes.

LangGraph 노드 함수: collect, correlate, deduplicate, assess, publish, hitl_checkpoint.
"""

import json
import logging
from typing import Any

from langchain_core.messages import AIMessage

from src.agent_server.supervisor.schemas import (
    AgentResult,
    CorrelatedEventGroup,
    Incident,
)
from src.agent_server.supervisor.services.correlator import EventCorrelator
from src.agent_server.supervisor.services.dedup import AlertDeduplicator
from src.agent_server.supervisor.services.event_collector import (
    PayloadEventCollector,
)
from src.agent_server.supervisor.services.incident_store import IncidentStoreProvider
from src.agent_server.supervisor.state import SupervisorState

logger = logging.getLogger(__name__)

SUPERVISOR_SYSTEM_PROMPT = (
    "당신은 멀티 에이전트 AIOps 시스템의 Supervisor입니다.\n"
    "4개 에이전트(Airflow 실패, 비용 이상, 설정 드리프트, K8s 알림)의 결과를 종합 분석합니다.\n\n"
    "핵심 역할:\n"
    "1. 개별 에이전트가 놓친 크로스 도메인 패턴을 식별\n"
    "2. 관련 이벤트의 공통 근본 원인을 추론\n"
    "3. 통합 심각도와 우선순위를 결정\n"
    "4. 구체적인 통합 대응 방안을 제시\n\n"
    "JSON 형식으로 응답하세요:\n"
    '{"unified_summary": "...", "root_cause_hypothesis": "...", '
    '"recommendations": ["..."], "requires_hitl": false}'
)


# ---------------------------------------------------------------------------
# collect 노드
# ---------------------------------------------------------------------------


def collect_node(state: SupervisorState) -> dict[str, Any]:
    """에이전트 결과를 수집하고 AgentResult로 정규화."""
    raw_results = state.get("agent_results", [])

    collector = PayloadEventCollector(raw_results)
    normalized = collector.collect()

    logger.info(f"[collect] {len(raw_results)}개 원본 결과 → {len(normalized)}개 이상 탐지 결과")

    return {
        "agent_results": [r.model_dump(mode="json") for r in normalized],
        "messages": [AIMessage(content=f"수집 완료: {len(normalized)}개 에이전트에서 이상 탐지됨")],
    }


# ---------------------------------------------------------------------------
# correlate 노드
# ---------------------------------------------------------------------------


def correlate_node(state: SupervisorState) -> dict[str, Any]:
    """3축 상관관계 분석 실행."""
    agent_results_raw = state.get("agent_results", [])
    agent_results = [AgentResult(**r) for r in agent_results_raw]

    if not agent_results:
        return {
            "correlated_groups": [],
            "messages": [AIMessage(content="이상 탐지 결과 없음. 상관관계 분석 건너뜀.")],
        }

    correlator = EventCorrelator()
    groups = correlator.correlate(agent_results)

    logger.info(f"[correlate] {len(agent_results)}개 결과 → {len(groups)}개 상관 그룹")

    return {
        "correlated_groups": [g.model_dump(mode="json") for g in groups],
        "messages": [AIMessage(content=f"상관관계 분석 완료: {len(groups)}개 그룹 발견")],
    }


# ---------------------------------------------------------------------------
# deduplicate 노드 (incident_store 주입)
# ---------------------------------------------------------------------------


def create_deduplicate_node(incident_store: IncidentStoreProvider):
    """incident_store를 클로저로 주입한 deduplicate 노드 생성."""

    def deduplicate_node(state: SupervisorState) -> dict[str, Any]:
        """중복 제거 및 인시던트 생성/업데이트."""
        groups_raw = state.get("correlated_groups", [])

        if not groups_raw:
            return {
                "incidents": [],
                "unified_severity": "low",
                "messages": [AIMessage(content="상관 그룹 없음. 인시던트 생성 건너뜀.")],
            }

        groups = [CorrelatedEventGroup(**g) for g in groups_raw]
        deduplicator = AlertDeduplicator(incident_store)
        result = deduplicator.deduplicate(groups)

        logger.info(
            f"[deduplicate] 생성={result.incidents_created}, "
            f"업데이트={result.incidents_updated}, 억제={result.alerts_suppressed}"
        )

        return {
            "incidents": [inc.model_dump(mode="json") for inc in result.incidents],
            "unified_severity": result.unified_severity,
            "messages": [
                AIMessage(
                    content=(
                        f"인시던트 처리 완료: 생성={result.incidents_created}, "
                        f"업데이트={result.incidents_updated}, 억제={result.alerts_suppressed}"
                    )
                )
            ],
        }

    return deduplicate_node


# ---------------------------------------------------------------------------
# assess 노드 (LLM 통합 분석)
# ---------------------------------------------------------------------------


def create_assess_node(llm_client=None):
    """llm_client를 클로저로 주입한 assess 노드 생성."""

    def assess_node(state: SupervisorState) -> dict[str, Any]:
        """LLM으로 크로스 에이전트 통합 분석."""
        incidents_raw = state.get("incidents", [])

        if not incidents_raw:
            return {
                "unified_summary": "이상 탐지 없음",
                "requires_hitl": False,
                "hitl_request_id": None,
                "messages": [AIMessage(content="인시던트 없음. 분석 건너뜀.")],
            }

        incidents = [Incident(**inc) for inc in incidents_raw]

        # LLM 분석 수행
        if llm_client:
            unified_summary, requires_hitl = _llm_assess(llm_client, incidents)
        else:
            unified_summary, requires_hitl = _fallback_assess(incidents)

        return {
            "unified_summary": unified_summary,
            "requires_hitl": requires_hitl,
            "hitl_request_id": None,
            "incidents": [inc.model_dump(mode="json") for inc in incidents],
            "messages": [AIMessage(content=f"통합 분석 완료: {unified_summary[:200]}")],
        }

    return assess_node


def _llm_assess(llm_client, incidents: list[Incident]) -> tuple[str, bool]:
    """LLM 기반 통합 분석."""
    incidents_summary = json.dumps(
        [
            {
                "id": inc.id,
                "severity": inc.severity,
                "title": inc.title,
                "source_agents": inc.source_agents,
                "affected_resources": inc.affected_resources,
                "evidences": [
                    {"type": e.correlation_type, "description": e.description}
                    for e in inc.evidences
                ],
            }
            for inc in incidents
        ],
        ensure_ascii=False,
        default=str,
    )

    user_prompt = (
        f"## 인시던트 통합 분석 요청\n\n"
        f"**인시던트 수**: {len(incidents)}\n\n"
        f"### 인시던트 목록\n```json\n{incidents_summary}\n```\n\n"
        f"위 인시던트들을 종합 분석하여 크로스 도메인 패턴, "
        f"공통 근본 원인, 통합 대응 방안을 제시하세요."
    )

    try:
        response = llm_client.generate(
            system_prompt=SUPERVISOR_SYSTEM_PROMPT,
            user_prompt=user_prompt,
        )
        content = response if isinstance(response, str) else str(response)

        # JSON 파싱 시도
        try:
            parsed = json.loads(content)
            summary = parsed.get("unified_summary", content)
            requires_hitl = parsed.get("requires_hitl", False)

            # 인시던트에 LLM 분석 결과 반영
            hypothesis = parsed.get("root_cause_hypothesis", "")
            recommendations = parsed.get("recommendations", [])
            for inc in incidents:
                if hypothesis:
                    inc.root_cause_hypothesis = hypothesis
                if recommendations:
                    inc.recommendations = recommendations

            return summary, requires_hitl
        except json.JSONDecodeError:
            return content, False

    except Exception as e:
        logger.warning(f"LLM assess 실패, fallback 사용: {e}")
        return _fallback_assess(incidents)


def _fallback_assess(incidents: list[Incident]) -> tuple[str, bool]:
    """LLM 없이 규칙 기반 요약."""
    total = len(incidents)
    agents = sorted({a for inc in incidents for a in inc.source_agents})
    has_critical = any(inc.severity == "critical" for inc in incidents)

    summary = f"총 {total}개 인시던트 탐지. 관련 에이전트: {', '.join(agents)}. "
    if has_critical:
        summary += "CRITICAL 인시던트 포함 - 즉시 대응 필요."

    # critical이면 HITL 요청
    return summary, has_critical


# ---------------------------------------------------------------------------
# publish 노드
# ---------------------------------------------------------------------------


def create_publish_node(event_publisher=None):
    """EventBridge 통합 알림 발행 노드."""

    def publish_node(state: SupervisorState) -> dict[str, Any]:
        """인시던트를 EventBridge로 발행."""
        incidents_raw = state.get("incidents", [])
        unified_summary = state.get("unified_summary", "")

        if not incidents_raw:
            return {
                "messages": [AIMessage(content="발행할 인시던트 없음.")],
            }

        if event_publisher:
            from src.agent_server.bdp_common.eventbridge.publisher import AlertEvent

            for inc_raw in incidents_raw:
                inc = Incident(**inc_raw)
                alert = AlertEvent(
                    alert_type="supervisor_incident",
                    severity="🔴" if inc.severity == "critical" else "🟡",
                    severity_level=inc.severity,
                    title=inc.title,
                    message=unified_summary,
                    affected_resources=[{"resource": r} for r in inc.affected_resources],
                    action_required=inc.severity in ("critical", "high"),
                    hitl_request_id=inc.hitl_request_id,
                    metadata={
                        "incident_id": inc.id,
                        "source_agents": inc.source_agents,
                        "suppressed_alerts": inc.suppressed_alert_count,
                    },
                )
                event_publisher.publish_event(alert, detail_type="Supervisor Incident")

        logger.info(f"[publish] {len(incidents_raw)}개 인시던트 발행 완료")

        return {
            "messages": [
                AIMessage(content=f"{len(incidents_raw)}개 인시던트 EventBridge 발행 완료")
            ],
        }

    return publish_node


# ---------------------------------------------------------------------------
# hitl_checkpoint 노드
# ---------------------------------------------------------------------------


def hitl_checkpoint_node(state: SupervisorState) -> dict[str, Any]:
    """HITL 검토 요청 생성 후 종료."""
    logger.info("[hitl_checkpoint] HITL 검토 요청 생성")

    return {
        "hitl_request_id": "pending",
        "messages": [AIMessage(content="HITL 검토가 필요합니다. 요청을 생성합니다.")],
    }
