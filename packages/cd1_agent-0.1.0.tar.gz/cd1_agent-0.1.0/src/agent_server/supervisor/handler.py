"""
Supervisor Handler for Multi-Agent Correlation.

멀티 에이전트 결과를 수집, 상관관계 분석, 인시던트 관리하는 핸들러.
Lambda/FastAPI 양쪽에서 동작.
"""

import logging
import os
from typing import Any

from src.agent_server.supervisor.graph import compile_supervisor
from src.agent_server.supervisor.services.incident_store import IncidentStore
from src.common.handlers.base_handler import BaseHandler
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


class SupervisorHandler(BaseHandler):
    """Supervisor 에이전트 핸들러.

    4개 서브 에이전트 결과를 수집하여 상관관계 분석,
    중복 제거, 통합 인시던트 관리를 수행합니다.
    """

    def __init__(self):
        super().__init__("SupervisorHandler")
        self._init_services()

    def _init_services(self) -> None:
        """서비스 컴포넌트 초기화."""
        # Incident Store
        store_provider = os.getenv("SUPERVISOR_STORE_PROVIDER", "mock")
        self.incident_store = IncidentStore.create_provider(store_provider)

        # LLM Client (선택적)
        self.llm_client = None
        llm_provider = self.config.get("llm_provider", "mock")
        if llm_provider != "mock":
            try:
                from src.common.services.llm_client import LLMClient, LLMProvider

                self.llm_client = LLMClient(provider=LLMProvider(llm_provider))
            except Exception as e:
                logger.warning(f"LLM 클라이언트 초기화 실패, fallback 사용: {e}")

        # EventBridge Publisher (선택적)
        self.event_publisher = None
        event_provider = os.getenv("EVENT_PROVIDER", "mock")
        if event_provider != "mock":
            try:
                from src.agent_server.bdp_common.eventbridge.publisher import (
                    EventPublisher,
                )

                self.event_publisher = EventPublisher(source="cd1-agent.supervisor")
            except Exception as e:
                logger.warning(f"EventPublisher 초기화 실패: {e}")

        # LangGraph 컴파일
        self.graph = compile_supervisor(
            llm_client=self.llm_client,
            incident_store=self.incident_store,
            event_publisher=self.event_publisher,
        )

    def _validate_input(self, event: dict[str, Any]) -> str | None:
        """입력 검증."""
        action = event.get("action", "correlate")
        if action not in ("correlate", "status"):
            return f"지원하지 않는 action: {action}"
        return None

    def process(self, event: dict[str, Any], context: Any) -> dict[str, Any]:
        """Supervisor 에이전트 실행.

        Args:
            event: {
                "action": "correlate",
                "agent_results": [
                    {"agent_type": "bdp_airflow", "total_anomalies": 3, ...},
                    {"agent_type": "bdp_cost", "total_anomalies": 1, ...},
                    ...
                ]
            }
            context: Lambda 컨텍스트

        Returns:
            인시던트 분석 결과
        """
        action = event.get("action", "correlate")

        if action == "status":
            return self._get_status()

        return self._correlate(event)

    def _correlate(self, event: dict[str, Any]) -> dict[str, Any]:
        """에이전트 결과 상관관계 분석 실행."""
        agent_results = event.get("agent_results", [])

        self.logger.info(f"Supervisor 실행: {len(agent_results)}개 에이전트 결과 수신")

        if not agent_results:
            return {
                "success": True,
                "message": "에이전트 결과 없음",
                "incidents_created": 0,
                "incidents_updated": 0,
                "alerts_suppressed": 0,
                "timestamp": get_kst_now().isoformat(),
            }

        # LangGraph 실행
        initial_state = {
            "messages": [],
            "agent_results": agent_results,
            "correlated_groups": [],
            "incidents": [],
            "unified_severity": "low",
            "unified_summary": "",
            "requires_hitl": False,
            "hitl_request_id": None,
        }

        final_state = self.graph.invoke(initial_state)

        incidents = final_state.get("incidents", [])
        unified_summary = final_state.get("unified_summary", "")

        return {
            "success": True,
            "timestamp": get_kst_now().isoformat(),
            "unified_severity": final_state.get("unified_severity", "low"),
            "unified_summary": unified_summary,
            "incidents_count": len(incidents),
            "incidents": incidents,
            "requires_hitl": final_state.get("requires_hitl", False),
        }

    def _get_status(self) -> dict[str, Any]:
        """최근 인시던트 상태 조회."""
        recent = self.incident_store.get_recent(hours=24)
        return {
            "success": True,
            "timestamp": get_kst_now().isoformat(),
            "recent_incidents": [inc.model_dump(mode="json") for inc in recent],
            "total_count": len(recent),
        }


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda 엔트리 포인트."""
    h = SupervisorHandler()
    return h.handle(event, context)
