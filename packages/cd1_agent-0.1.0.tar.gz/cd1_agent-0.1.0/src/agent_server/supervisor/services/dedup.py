"""
Alert Deduplicator - 중복 제거 및 인시던트 생성/업데이트.

상관관계 분석으로 묶인 그룹을 인시던트로 변환하며,
기존 열린 인시던트와 매칭하여 중복 알림을 억제.
"""

import logging

from src.agent_server.supervisor.schemas import (
    CorrelatedEventGroup,
    Incident,
    SupervisorAnalysisResult,
)
from src.agent_server.supervisor.services.incident_store import IncidentStoreProvider

logger = logging.getLogger(__name__)


class AlertDeduplicator:
    """알림 중복 제거 및 인시던트 관리."""

    def __init__(
        self,
        incident_store: IncidentStoreProvider,
        match_window_minutes: int = 30,
    ):
        self.incident_store = incident_store
        self.match_window_minutes = match_window_minutes

    def deduplicate(
        self,
        correlated_groups: list[CorrelatedEventGroup],
    ) -> SupervisorAnalysisResult:
        """상관 그룹을 인시던트로 변환, 중복 제거.

        Args:
            correlated_groups: 상관관계 분석 결과 그룹들

        Returns:
            인시던트 생성/업데이트/억제 통계
        """
        created = 0
        updated = 0
        suppressed = 0
        incidents: list[Incident] = []

        for group in correlated_groups:
            # 기존 열린 인시던트와 매칭 시도
            existing = self.incident_store.find_matching(
                group, window_minutes=self.match_window_minutes
            )

            if existing:
                # 기존 인시던트에 새 이벤트 추가 (중복 억제)
                existing.add_events(group.events)
                existing.update_severity(group.max_severity)
                # 새 evidence 추가
                existing.evidences.extend(group.evidences)
                self.incident_store.update(existing)
                updated += 1
                suppressed += len(group.events)
                incidents.append(existing)
            else:
                # 새 인시던트 생성
                incident = Incident.from_group(group)
                self.incident_store.create(incident)
                created += 1
                incidents.append(incident)

        # 통합 심각도 결정
        unified_severity = "low"
        for inc in incidents:
            from src.agent_server.supervisor.schemas import SEVERITY_ORDER

            if SEVERITY_ORDER.get(inc.severity, 3) < SEVERITY_ORDER.get(unified_severity, 3):
                unified_severity = inc.severity

        logger.info(f"중복 제거 완료: 생성={created}, 업데이트={updated}, 억제={suppressed}")

        return SupervisorAnalysisResult(
            incidents_created=created,
            incidents_updated=updated,
            alerts_suppressed=suppressed,
            total_correlations_found=len(correlated_groups),
            unified_severity=unified_severity,
            incidents=incidents,
        )
