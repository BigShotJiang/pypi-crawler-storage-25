"""
Event Correlator - 3축 상관관계 분석 엔진.

시간/리소스/인과관계 기반으로 에이전트 결과를 그루핑.
"""

import logging
from datetime import timedelta
from itertools import combinations

from src.agent_server.supervisor.schemas import (
    SEVERITY_ORDER,
    AgentResult,
    CausalPattern,
    CorrelatedEventGroup,
    CorrelationEvidence,
    CorrelationType,
)

logger = logging.getLogger(__name__)

# 사전 정의된 인과관계 패턴
CAUSAL_PATTERNS = [
    CausalPattern(
        name="drift_causes_failure",
        cause_agent="bdp_drift",
        effect_agent="bdp_airflow",
        confidence=0.8,
        description="설정 드리프트로 인한 Airflow DAG 실패",
    ),
    CausalPattern(
        name="retry_causes_cost_spike",
        cause_agent="bdp_airflow",
        effect_agent="bdp_cost",
        confidence=0.7,
        description="반복 실패/재시도로 인한 비용 급증",
    ),
    CausalPattern(
        name="eks_drift_causes_k8s_alerts",
        cause_agent="bdp_drift",
        effect_agent="hdsp_alertmanager",
        confidence=0.75,
        description="EKS 설정 변경으로 인한 K8s 알림",
    ),
    CausalPattern(
        name="k8s_issue_causes_airflow_failure",
        cause_agent="hdsp_alertmanager",
        effect_agent="bdp_airflow",
        confidence=0.65,
        description="K8s 인프라 이슈로 인한 Airflow 실패",
    ),
    CausalPattern(
        name="cost_spike_with_drift",
        cause_agent="bdp_drift",
        effect_agent="bdp_cost",
        confidence=0.6,
        description="설정 변경으로 인한 비용 급증",
    ),
]

# 시간 윈도우 상관관계 임계값
TEMPORAL_WINDOW_MINUTES = 10


class EventCorrelator:
    """크로스 에이전트 이벤트 상관관계 분석."""

    def __init__(
        self,
        causal_patterns: list[CausalPattern] | None = None,
        temporal_window_minutes: int = TEMPORAL_WINDOW_MINUTES,
    ):
        self.causal_patterns = causal_patterns or CAUSAL_PATTERNS
        self.temporal_window = timedelta(minutes=temporal_window_minutes)

    def correlate(self, agent_results: list[AgentResult]) -> list[CorrelatedEventGroup]:
        """3축 상관관계 분석 실행.

        Args:
            agent_results: 이상이 탐지된 에이전트 결과 목록

        Returns:
            상관관계로 묶인 이벤트 그룹 목록
        """
        if len(agent_results) <= 1:
            # 단일 결과면 그대로 1개 그룹으로 반환
            if agent_results:
                return [self._single_event_group(agent_results[0])]
            return []

        groups: list[CorrelatedEventGroup] = []

        # 축 1: 시간 윈도우 상관관계
        temporal_groups = self._temporal_correlation(agent_results)
        groups.extend(temporal_groups)

        # 축 2: 리소스 기반 상관관계
        resource_groups = self._resource_correlation(agent_results)
        groups.extend(resource_groups)

        # 축 3: 인과관계 패턴 매칭
        causal_groups = self._causal_pattern_matching(agent_results)
        groups.extend(causal_groups)

        # 중복 그룹 병합
        merged = self._merge_groups(groups)

        logger.info(
            f"상관관계 분석 완료: {len(agent_results)}개 결과 → "
            f"{len(merged)}개 그룹 (시간:{len(temporal_groups)}, "
            f"리소스:{len(resource_groups)}, 인과:{len(causal_groups)})"
        )
        return merged

    def _single_event_group(self, result: AgentResult) -> CorrelatedEventGroup:
        """단일 이벤트를 그룹으로 래핑."""
        max_sev = self._get_max_severity_from_result(result)
        group = CorrelatedEventGroup(
            events=[result],
            max_severity=max_sev,
            combined_confidence=0.5,
        )
        group.correlation_key = group.compute_correlation_key()
        return group

    def _temporal_correlation(self, results: list[AgentResult]) -> list[CorrelatedEventGroup]:
        """축 1: 시간 윈도우 기반 상관관계.

        동일 시간 윈도우 내 발생한 서로 다른 에이전트의 이상을 그루핑.
        """
        groups: list[CorrelatedEventGroup] = []
        used_indices: set[int] = set()

        sorted_results = sorted(results, key=lambda r: r.timestamp)

        for i, base in enumerate(sorted_results):
            if i in used_indices:
                continue

            cluster = [base]
            cluster_indices = {i}

            for j, other in enumerate(sorted_results):
                if j <= i or j in used_indices:
                    continue
                if other.agent_type == base.agent_type:
                    continue  # 같은 에이전트는 건너뜀

                time_diff = abs((other.timestamp - base.timestamp).total_seconds())
                if time_diff <= self.temporal_window.total_seconds():
                    cluster.append(other)
                    cluster_indices.add(j)

            if len(cluster) > 1:
                used_indices.update(cluster_indices)
                agents = [r.agent_type for r in cluster]
                max_sev = self._get_max_severity(cluster)
                group = CorrelatedEventGroup(
                    events=cluster,
                    evidences=[
                        CorrelationEvidence(
                            correlation_type=CorrelationType.TEMPORAL,
                            description=f"{len(cluster)}개 에이전트에서 {self.temporal_window.seconds // 60}분 이내 동시 이상 탐지",
                            confidence=min(0.6 + 0.1 * len(cluster), 0.9),
                            source_agents=agents,
                        )
                    ],
                    max_severity=max_sev,
                    combined_confidence=min(0.6 + 0.1 * len(cluster), 0.9),
                )
                group.correlation_key = group.compute_correlation_key()
                groups.append(group)

        return groups

    def _resource_correlation(self, results: list[AgentResult]) -> list[CorrelatedEventGroup]:
        """축 2: 리소스 기반 상관관계.

        서로 다른 에이전트가 동일/유사 리소스를 참조하는 경우.
        """
        groups: list[CorrelatedEventGroup] = []

        for a, b in combinations(results, 2):
            if a.agent_type == b.agent_type:
                continue

            shared = self._find_shared_resources(a, b)
            if shared:
                max_sev = self._get_max_severity([a, b])
                group = CorrelatedEventGroup(
                    events=[a, b],
                    evidences=[
                        CorrelationEvidence(
                            correlation_type=CorrelationType.RESOURCE,
                            description=f"공유 리소스: {', '.join(shared)}",
                            confidence=0.75,
                            source_agents=[a.agent_type, b.agent_type],
                        )
                    ],
                    max_severity=max_sev,
                    combined_confidence=0.75,
                )
                group.correlation_key = group.compute_correlation_key()
                groups.append(group)

        return groups

    def _causal_pattern_matching(self, results: list[AgentResult]) -> list[CorrelatedEventGroup]:
        """축 3: 인과관계 패턴 매칭.

        사전 정의된 cause→effect 규칙에 매칭되는 결과 쌍을 탐지.
        """
        groups: list[CorrelatedEventGroup] = []
        result_map: dict[str, list[AgentResult]] = {}
        for r in results:
            result_map.setdefault(r.agent_type, []).append(r)

        for pattern in self.causal_patterns:
            causes = result_map.get(pattern.cause_agent, [])
            effects = result_map.get(pattern.effect_agent, [])

            if causes and effects:
                # cause → effect 쌍 생성
                for cause in causes:
                    for effect in effects:
                        max_sev = self._get_max_severity([cause, effect])
                        group = CorrelatedEventGroup(
                            events=[cause, effect],
                            evidences=[
                                CorrelationEvidence(
                                    correlation_type=CorrelationType.CAUSAL,
                                    description=f"[{pattern.name}] {pattern.description}",
                                    confidence=pattern.confidence,
                                    source_agents=[
                                        pattern.cause_agent,
                                        pattern.effect_agent,
                                    ],
                                )
                            ],
                            max_severity=max_sev,
                            combined_confidence=pattern.confidence,
                        )
                        group.correlation_key = group.compute_correlation_key()
                        groups.append(group)

        return groups

    def _merge_groups(self, groups: list[CorrelatedEventGroup]) -> list[CorrelatedEventGroup]:
        """중복 그룹을 병합.

        동일 에이전트 조합을 가진 그룹들을 하나로 합침.
        """
        if not groups:
            return []

        merged: dict[str, CorrelatedEventGroup] = {}

        for group in groups:
            key = group.correlation_key
            if key in merged:
                existing = merged[key]
                # evidence 합침
                existing.evidences.extend(group.evidences)
                # confidence는 최댓값
                existing.combined_confidence = max(
                    existing.combined_confidence, group.combined_confidence
                )
                # severity는 가장 높은 것
                if SEVERITY_ORDER.get(group.max_severity, 3) < SEVERITY_ORDER.get(
                    existing.max_severity, 3
                ):
                    existing.max_severity = group.max_severity
                # 새 이벤트 추가 (중복 에이전트 제외)
                existing_agents = {e.agent_type for e in existing.events}
                for event in group.events:
                    if event.agent_type not in existing_agents:
                        existing.events.append(event)
                        existing_agents.add(event.agent_type)
            else:
                merged[key] = group

        return list(merged.values())

    def _find_shared_resources(self, a: AgentResult, b: AgentResult) -> list[str]:
        """두 에이전트 결과 간 공유 리소스 탐색.

        정규화된 리소스 이름으로 비교.
        """
        resources_a = self._normalize_resources(a)
        resources_b = self._normalize_resources(b)
        return list(resources_a & resources_b)

    def _normalize_resources(self, result: AgentResult) -> set[str]:
        """에이전트별 리소스를 정규화된 키워드 세트로 변환."""
        normalized: set[str] = set()
        for resource in result.affected_resources:
            # 소문자 + 콜론/하이픈/슬래시 기준 토큰 분리
            resource_lower = resource.lower()
            normalized.add(resource_lower)
            # 리소스 타입:이름 형식인 경우 이름만 추가
            if ":" in resource_lower:
                parts = resource_lower.split(":")
                normalized.update(parts)
        return normalized

    def _get_max_severity(self, results: list[AgentResult]) -> str:
        """여러 결과에서 가장 높은 심각도 추출."""
        best = "low"
        for r in results:
            sev = self._get_max_severity_from_result(r)
            if SEVERITY_ORDER.get(sev, 3) < SEVERITY_ORDER.get(best, 3):
                best = sev
        return best

    def _get_max_severity_from_result(self, result: AgentResult) -> str:
        """단일 결과에서 최고 심각도 추출."""
        if not result.severity_breakdown:
            return "medium"
        for sev in ("critical", "high", "medium", "low"):
            if result.severity_breakdown.get(sev, 0) > 0:
                return sev
        return "medium"
