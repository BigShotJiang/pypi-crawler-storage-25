"""
Event Collector - 에이전트 결과 수집 및 정규화.

각 서브 에이전트의 detect 결과를 AgentResult로 변환.
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.supervisor.schemas import AgentResult
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)

# 에이전트별 결과 → AgentResult 변환 키 매핑
AGENT_TYPE_MAP = {
    "bdp_airflow": "airflow_failure",
    "bdp_cost": "cost_anomaly",
    "bdp_drift": "config_drift",
    "hdsp_alertmanager": "k8s_alert",
}


class EventCollectorProvider(ABC):
    """에이전트 결과 수집 프로바이더 추상 클래스."""

    @abstractmethod
    def collect(self, time_window_minutes: int = 10) -> list[AgentResult]:
        """시간 윈도우 내 에이전트 결과 수집."""


class PayloadEventCollector(EventCollectorProvider):
    """Event payload에서 에이전트 결과 수집.

    MWAA DAG에서 XCom/payload로 전달된 결과를 파싱.
    """

    def __init__(self, raw_results: list[dict[str, Any]] | None = None):
        self._raw_results = raw_results or []

    def collect(self, time_window_minutes: int = 10) -> list[AgentResult]:
        """전달된 payload에서 AgentResult로 변환."""
        results = []
        for raw in self._raw_results:
            try:
                result = self._normalize(raw)
                if result and result.total_anomalies > 0:
                    results.append(result)
            except Exception as e:
                logger.warning(f"에이전트 결과 정규화 실패: {e}")
        return results

    def _normalize(self, raw: dict[str, Any]) -> AgentResult | None:
        """에이전트 원본 결과를 AgentResult로 정규화."""
        agent_type = raw.get("agent_type", "")
        if not agent_type:
            return None

        detection_type = AGENT_TYPE_MAP.get(agent_type, agent_type)

        # 공통 필드 추출 (에이전트마다 약간의 차이 허용)
        severity_breakdown = raw.get("severity_breakdown", {})
        total_anomalies = raw.get("total_anomalies", 0)

        # total_anomalies가 0이면 severity_breakdown에서 합산
        if total_anomalies == 0 and severity_breakdown:
            total_anomalies = sum(severity_breakdown.values())

        # affected_resources 추출 (에이전트별 다른 키 허용)
        affected_resources = raw.get("affected_resources", [])
        if not affected_resources:
            affected_resources = self._extract_resources(agent_type, raw)

        timestamp_str = raw.get("timestamp")
        timestamp = datetime.fromisoformat(timestamp_str) if timestamp_str else get_kst_now()

        return AgentResult(
            agent_type=agent_type,
            detection_type=detection_type,
            timestamp=timestamp,
            severity_breakdown=severity_breakdown,
            total_anomalies=total_anomalies,
            summary=raw.get("summary", ""),
            affected_resources=affected_resources,
            raw_result=raw,
            deep_analysis=raw.get("deep_analysis"),
            hitl_request_id=raw.get("hitl_request_id"),
        )

    def _extract_resources(self, agent_type: str, raw: dict[str, Any]) -> list[str]:
        """에이전트별 affected_resources 추출."""
        if agent_type == "bdp_airflow":
            # DAG ID 목록
            patterns = raw.get("patterns", [])
            return list({p.get("dag_id", "") for p in patterns if p.get("dag_id")})

        if agent_type == "bdp_cost":
            # 서비스명 목록
            results = raw.get("results", [])
            return list({r.get("service_name", "") for r in results if r.get("service_name")})

        if agent_type == "bdp_drift":
            # 리소스 타입 + 이름
            drifts = raw.get("drifts", [])
            return list(
                {
                    f"{d.get('resource_type', '')}:{d.get('resource_name', '')}"
                    for d in drifts
                    if d.get("resource_type")
                }
            )

        if agent_type == "hdsp_alertmanager":
            # 네임스페이스/서비스
            alerts = raw.get("alerts", [])
            return list(
                {
                    a.get("labels", {}).get("namespace", "")
                    for a in alerts
                    if a.get("labels", {}).get("namespace")
                }
            )

        return []


class MockEventCollector(EventCollectorProvider):
    """테스트용 Mock Event Collector."""

    def __init__(self, mock_results: list[AgentResult] | None = None):
        self._results = mock_results or []

    def collect(self, time_window_minutes: int = 10) -> list[AgentResult]:
        return self._results
