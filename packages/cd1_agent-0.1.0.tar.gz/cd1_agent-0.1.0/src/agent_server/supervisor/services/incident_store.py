"""
Incident Store - 인시던트 CRUD.

Provider 패턴: Mock(테스트) / SQLite(로컬) / DynamoDB(프로덕션).
"""

import logging
from abc import ABC, abstractmethod
from datetime import timedelta

from src.agent_server.supervisor.schemas import (
    CorrelatedEventGroup,
    Incident,
    IncidentStatus,
)
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


class IncidentStoreProvider(ABC):
    """인시던트 저장소 추상 클래스."""

    @abstractmethod
    def create(self, incident: Incident) -> str:
        """인시던트 생성. ID 반환."""

    @abstractmethod
    def get(self, incident_id: str) -> Incident | None:
        """인시던트 조회."""

    @abstractmethod
    def update(self, incident: Incident) -> None:
        """인시던트 업데이트."""

    @abstractmethod
    def find_matching(
        self,
        group: CorrelatedEventGroup,
        window_minutes: int = 30,
    ) -> Incident | None:
        """correlation_key 기반으로 매칭되는 열린 인시던트 검색."""

    @abstractmethod
    def get_recent(self, hours: int = 24) -> list[Incident]:
        """최근 인시던트 목록 조회."""


class MockIncidentStore(IncidentStoreProvider):
    """테스트/개발용 인메모리 인시던트 저장소."""

    def __init__(self):
        self._incidents: dict[str, Incident] = {}

    def create(self, incident: Incident) -> str:
        self._incidents[incident.id] = incident
        logger.info(f"인시던트 생성: {incident.id} [{incident.severity}] {incident.title}")
        return incident.id

    def get(self, incident_id: str) -> Incident | None:
        return self._incidents.get(incident_id)

    def update(self, incident: Incident) -> None:
        self._incidents[incident.id] = incident
        logger.info(
            f"인시던트 업데이트: {incident.id} (억제 알림: {incident.suppressed_alert_count})"
        )

    def find_matching(
        self,
        group: CorrelatedEventGroup,
        window_minutes: int = 30,
    ) -> Incident | None:
        """correlation_key로 최근 열린 인시던트 매칭."""
        key = group.correlation_key or group.compute_correlation_key()
        cutoff = get_kst_now() - timedelta(minutes=window_minutes)

        for incident in self._incidents.values():
            if (
                incident.status in (IncidentStatus.OPEN, IncidentStatus.INVESTIGATING)
                and incident.correlation_key == key
                and incident.created_at >= cutoff
            ):
                return incident
        return None

    def get_recent(self, hours: int = 24) -> list[Incident]:
        cutoff = get_kst_now() - timedelta(hours=hours)
        return [inc for inc in self._incidents.values() if inc.created_at >= cutoff]

    def clear(self) -> None:
        """테스트용: 전체 초기화."""
        self._incidents.clear()


class IncidentStore:
    """인시던트 저장소 팩토리."""

    @staticmethod
    def create_provider(provider_type: str = "mock") -> IncidentStoreProvider:
        if provider_type == "mock":
            return MockIncidentStore()
        raise ValueError(f"지원하지 않는 provider: {provider_type}")
