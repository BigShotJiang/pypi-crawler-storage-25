"""
Supervisor Agent State.

LangGraph Supervisor 에이전트의 상태 정의.
"""

import operator
from collections.abc import Sequence
from typing import Annotated, Any

from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict


class SupervisorState(TypedDict):
    """Supervisor LangGraph 상태.

    Attributes:
        messages: LangChain 메시지 시퀀스
        agent_results: 수집된 에이전트 결과 (정규화)
        correlated_groups: 상관관계 분석으로 묶인 이벤트 그룹
        incidents: 생성/업데이트된 인시던트
        unified_severity: 통합 심각도
        unified_summary: LLM 통합 요약
        requires_hitl: HITL 검토 필요 여부
        hitl_request_id: HITL 요청 ID
    """

    messages: Annotated[Sequence[BaseMessage], operator.add]
    agent_results: list[dict[str, Any]]
    correlated_groups: list[dict[str, Any]]
    incidents: list[dict[str, Any]]
    unified_severity: str
    unified_summary: str
    requires_hitl: bool
    hitl_request_id: str | None
