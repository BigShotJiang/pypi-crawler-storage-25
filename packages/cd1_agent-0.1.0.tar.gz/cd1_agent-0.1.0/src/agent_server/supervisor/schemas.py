"""
Supervisor Agent Schemas.

멀티 에이전트 결과 통합, 상관관계 분석, 인시던트 관리용 데이터 모델.
"""

import hashlib
import uuid
from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from src.common.timezone import get_kst_now

# ---------------------------------------------------------------------------
# Agent Result (에이전트 실행 결과 정규화)
# ---------------------------------------------------------------------------


class AgentResult(BaseModel):
    """에이전트 실행 결과 (정규화).

    각 서브 에이전트(bdp_airflow, bdp_cost, bdp_drift, hdsp_alertmanager)의
    detect 결과를 통일된 형식으로 변환.
    """

    agent_type: str = Field(description="에이전트 타입")
    detection_type: str = Field(description="탐지 타입")
    timestamp: datetime = Field(default_factory=get_kst_now)
    severity_breakdown: dict[str, int] = Field(default_factory=dict, description="심각도별 카운트")
    total_anomalies: int = Field(default=0, description="총 이상 탐지 수")
    summary: str = Field(default="", description="탐지 요약")
    affected_resources: list[str] = Field(default_factory=list, description="영향받는 리소스 목록")
    raw_result: dict[str, Any] = Field(default_factory=dict, description="원본 에이전트 결과")
    deep_analysis: dict[str, Any] | None = Field(default=None, description="Deep Agent 분석 결과")
    hitl_request_id: str | None = Field(default=None, description="HITL 요청 ID")


# ---------------------------------------------------------------------------
# Correlation (상관관계 분석)
# ---------------------------------------------------------------------------


class CorrelationType(str, Enum):
    """상관관계 유형."""

    TEMPORAL = "temporal"
    RESOURCE = "resource"
    CAUSAL = "causal"


class CorrelationEvidence(BaseModel):
    """상관관계 근거."""

    correlation_type: CorrelationType
    description: str = Field(default="", description="상관관계 설명")
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    source_agents: list[str] = Field(default_factory=list)


class CausalPattern(BaseModel):
    """인과관계 패턴 규칙."""

    name: str = Field(description="패턴 이름")
    cause_agent: str = Field(description="원인 에이전트")
    effect_agent: str = Field(description="결과 에이전트")
    confidence: float = Field(default=0.7, ge=0.0, le=1.0)
    description: str = Field(default="", description="패턴 설명")


class CorrelatedEventGroup(BaseModel):
    """상관관계로 묶인 이벤트 그룹."""

    group_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    events: list[AgentResult] = Field(default_factory=list)
    evidences: list[CorrelationEvidence] = Field(default_factory=list)
    max_severity: str = Field(default="low")
    combined_confidence: float = Field(default=0.0)
    correlation_key: str = Field(default="", description="중복 제거용 fingerprint")

    def compute_correlation_key(self) -> str:
        """이벤트 그룹의 fingerprint 해시 생성."""
        agents = sorted({e.agent_type for e in self.events})
        resources = sorted({r for e in self.events for r in e.affected_resources})
        key_str = f"{','.join(agents)}|{','.join(resources)}|{self.max_severity}"
        return hashlib.md5(key_str.encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Incident (통합 인시던트)
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


class IncidentStatus(str, Enum):
    """인시던트 상태."""

    OPEN = "open"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"


class Incident(BaseModel):
    """통합 인시던트.

    다수의 에이전트 알림을 하나의 인시던트로 그루핑.
    """

    id: str = Field(default_factory=lambda: f"INC-{uuid.uuid4().hex[:8]}")
    status: IncidentStatus = Field(default=IncidentStatus.OPEN)
    severity: str = Field(default="medium")
    title: str = Field(default="")
    summary: str = Field(default="")
    root_cause_hypothesis: str = Field(default="")
    source_agents: list[str] = Field(default_factory=list)
    affected_resources: list[str] = Field(default_factory=list)
    correlated_events: list[AgentResult] = Field(default_factory=list)
    evidences: list[CorrelationEvidence] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=get_kst_now)
    updated_at: datetime = Field(default_factory=get_kst_now)
    resolved_at: datetime | None = None
    hitl_request_id: str | None = None
    suppressed_alert_count: int = Field(default=0, description="중복 제거된 알림 수")
    correlation_key: str = Field(default="", description="매칭용 fingerprint")

    @classmethod
    def from_group(cls, group: CorrelatedEventGroup) -> "Incident":
        """CorrelatedEventGroup으로부터 인시던트 생성."""
        agents = sorted({e.agent_type for e in group.events})
        resources = sorted({r for e in group.events for r in e.affected_resources})
        summaries = [e.summary for e in group.events if e.summary]

        return cls(
            severity=group.max_severity,
            title=f"[{group.max_severity.upper()}] {', '.join(agents)} 연관 이상 탐지",
            summary=" | ".join(summaries) if summaries else "상관관계 분석으로 그루핑된 인시던트",
            source_agents=agents,
            affected_resources=resources,
            correlated_events=group.events,
            evidences=group.evidences,
            correlation_key=group.correlation_key or group.compute_correlation_key(),
        )

    def add_events(self, events: list[AgentResult]) -> None:
        """기존 인시던트에 새 이벤트 추가."""
        self.correlated_events.extend(events)
        self.suppressed_alert_count += len(events)
        self.updated_at = get_kst_now()
        # 소스 에이전트 목록 갱신
        for e in events:
            if e.agent_type not in self.source_agents:
                self.source_agents.append(e.agent_type)

    def update_severity(self, new_severity: str) -> None:
        """더 높은 심각도로 업데이트."""
        if SEVERITY_ORDER.get(new_severity, 3) < SEVERITY_ORDER.get(self.severity, 3):
            self.severity = new_severity
            self.updated_at = get_kst_now()


# ---------------------------------------------------------------------------
# Supervisor 분석 결과
# ---------------------------------------------------------------------------


class SupervisorAnalysisResult(BaseModel):
    """Supervisor 최종 분석 결과."""

    incidents_created: int = 0
    incidents_updated: int = 0
    alerts_suppressed: int = 0
    total_correlations_found: int = 0
    unified_severity: str = Field(default="low")
    unified_summary: str = Field(default="")
    incidents: list[Incident] = Field(default_factory=list)
