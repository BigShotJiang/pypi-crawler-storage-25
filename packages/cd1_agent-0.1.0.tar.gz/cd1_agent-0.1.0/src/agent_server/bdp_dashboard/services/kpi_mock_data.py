"""KPI mock 데이터 — 프론트엔드 하드코딩에서 이관.

실제 데이터 소스가 연동되면 이 파일을 서비스 로직으로 대체합니다.
"""

from __future__ import annotations

# ── WFL DAG 월별 성공률 ────────────────────────────────

WFL_MONTHLY_DATA: list[dict] = [
    {"month": "25/12", "totalRuns": 744, "successRuns": 671, "rate": 90.2},
    {"month": "26/01", "totalRuns": 744, "successRuns": 638, "rate": 85.8},
    {"month": "26/02", "totalRuns": 672, "successRuns": 571, "rate": 85.0},
    {"month": "26/03", "totalRuns": 279, "successRuns": 243, "rate": 87.1},
]

# ── 팀별 월 DAG 성공률 ─────────────────────────────────
# 구조: [{team, months: {month_label: {rate, ok, total} | None}}]

TEAM_MONTHLY_SUCCESS_DATA: list[dict] = [
    {
        "team": "분석1팀",
        "months": {
            "25/12": {"rate": 91.2, "ok": 114, "total": 125},
            "26/01": {"rate": 88.3, "ok": 113, "total": 128},
            "26/02": {"rate": 86.5, "ok": 109, "total": 126},
            "26/03": {"rate": 89.1, "ok": 49, "total": 55},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석2팀",
        "months": {
            "25/12": {"rate": 89.5, "ok": 111, "total": 124},
            "26/01": {"rate": 90.1, "ok": 118, "total": 131},
            "26/02": {"rate": 87.2, "ok": 109, "total": 125},
            "26/03": {"rate": 88.7, "ok": 47, "total": 53},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석3팀",
        "months": {
            "25/12": {"rate": 93.4, "ok": 113, "total": 121},
            "26/01": {"rate": 91.7, "ok": 110, "total": 120},
            "26/02": {"rate": 90.3, "ok": 103, "total": 114},
            "26/03": {"rate": 92.0, "ok": 46, "total": 50},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석4팀",
        "months": {
            "25/12": {"rate": 87.8, "ok": 108, "total": 123},
            "26/01": {"rate": 85.6, "ok": 107, "total": 125},
            "26/02": {"rate": 83.9, "ok": 99, "total": 118},
            "26/03": {"rate": 86.2, "ok": 50, "total": 58},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석5팀",
        "months": {
            "25/12": {"rate": 90.1, "ok": 109, "total": 121},
            "26/01": {"rate": 89.4, "ok": 110, "total": 123},
            "26/02": {"rate": 88.0, "ok": 103, "total": 117},
            "26/03": {"rate": 90.5, "ok": 48, "total": 53},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석6팀",
        "months": {
            "25/12": {"rate": 88.3, "ok": 106, "total": 120},
            "26/01": {"rate": 86.9, "ok": 106, "total": 122},
            "26/02": {"rate": 84.7, "ok": 100, "total": 118},
            "26/03": {"rate": 87.3, "ok": 48, "total": 55},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석7팀",
        "months": {
            "25/12": {"rate": 92.0, "ok": 115, "total": 125},
            "26/01": {"rate": 90.8, "ok": 109, "total": 120},
            "26/02": {"rate": 89.5, "ok": 102, "total": 114},
            "26/03": {"rate": 91.2, "ok": 52, "total": 57},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
    {
        "team": "분석8팀",
        "months": {
            "25/12": {"rate": 86.7, "ok": 104, "total": 120},
            "26/01": {"rate": 84.2, "ok": 101, "total": 120},
            "26/02": {"rate": 82.1, "ok": 96, "total": 117},
            "26/03": {"rate": 85.8, "ok": 48, "total": 56},
            "26/04": None,
            "26/05": None,
            "26/06": None,
            "26/07": None,
            "26/08": None,
            "26/09": None,
            "26/10": None,
        },
    },
]

# ── 팀별 Task 성공/실패 현황 ───────────────────────────
# 구조: {team → {task_type → {month → {rate, ok, total} | None}}}

TASK_TYPES = [
    {"key": "query", "label": "Query Task"},
    {"key": "spark", "label": "Spark Task"},
    {"key": "sink", "label": "Data Sink Task"},
    {"key": "branch", "label": "Branch Task"},
]

TEAM_TASK_MONTHLY_DATA: dict[str, dict[str, dict[str, dict | None]]] = {
    "분석1팀": {
        "query": {
            "25/12": {"rate": 95.2, "ok": 120, "total": 126},
            "26/01": {"rate": 94.8, "ok": 119, "total": 126},
            "26/02": {"rate": 93.5, "ok": 115, "total": 123},
            "26/03": {"rate": 96.0, "ok": 48, "total": 50},
        },
        "spark": {
            "25/12": {"rate": 82.1, "ok": 101, "total": 123},
            "26/01": {"rate": 83.5, "ok": 104, "total": 125},
            "26/02": {"rate": 80.2, "ok": 97, "total": 121},
            "26/03": {"rate": 84.0, "ok": 42, "total": 50},
        },
        "sink": {
            "25/12": {"rate": 98.0, "ok": 124, "total": 126},
            "26/01": {"rate": 97.6, "ok": 123, "total": 126},
            "26/02": {"rate": 96.8, "ok": 121, "total": 125},
            "26/03": {"rate": 98.0, "ok": 49, "total": 50},
        },
        "branch": {
            "25/12": {"rate": 76.3, "ok": 90, "total": 118},
            "26/01": {"rate": 74.8, "ok": 89, "total": 119},
            "26/02": {"rate": 72.5, "ok": 87, "total": 120},
            "26/03": {"rate": 78.0, "ok": 39, "total": 50},
        },
    },
    "분석2팀": {
        "query": {
            "25/12": {"rate": 92.7, "ok": 115, "total": 124},
            "26/01": {"rate": 93.1, "ok": 118, "total": 127},
            "26/02": {"rate": 91.5, "ok": 108, "total": 118},
            "26/03": {"rate": 93.8, "ok": 45, "total": 48},
        },
        "spark": {
            "25/12": {"rate": 85.4, "ok": 105, "total": 123},
            "26/01": {"rate": 86.2, "ok": 106, "total": 123},
            "26/02": {"rate": 83.7, "ok": 98, "total": 117},
            "26/03": {"rate": 85.1, "ok": 40, "total": 47},
        },
        "sink": {
            "25/12": {"rate": 96.8, "ok": 121, "total": 125},
            "26/01": {"rate": 97.2, "ok": 124, "total": 128},
            "26/02": {"rate": 95.6, "ok": 109, "total": 114},
            "26/03": {"rate": 97.9, "ok": 47, "total": 48},
        },
        "branch": {
            "25/12": {"rate": 80.2, "ok": 97, "total": 121},
            "26/01": {"rate": 78.9, "ok": 97, "total": 123},
            "26/02": {"rate": 77.4, "ok": 89, "total": 115},
            "26/03": {"rate": 81.3, "ok": 39, "total": 48},
        },
    },
    "분석3팀": {
        "query": {
            "25/12": {"rate": 97.1, "ok": 118, "total": 121},
            "26/01": {"rate": 96.5, "ok": 112, "total": 116},
            "26/02": {"rate": 95.8, "ok": 114, "total": 119},
            "26/03": {"rate": 97.8, "ok": 45, "total": 46},
        },
        "spark": {
            "25/12": {"rate": 88.3, "ok": 106, "total": 120},
            "26/01": {"rate": 87.9, "ok": 102, "total": 116},
            "26/02": {"rate": 86.4, "ok": 102, "total": 118},
            "26/03": {"rate": 89.1, "ok": 41, "total": 46},
        },
        "sink": {
            "25/12": {"rate": 99.1, "ok": 113, "total": 114},
            "26/01": {"rate": 98.3, "ok": 114, "total": 116},
            "26/02": {"rate": 97.5, "ok": 116, "total": 119},
            "26/03": {"rate": 99.0, "ok": 46, "total": 46},
        },
        "branch": {
            "25/12": {"rate": 83.5, "ok": 96, "total": 115},
            "26/01": {"rate": 82.8, "ok": 96, "total": 116},
            "26/02": {"rate": 81.4, "ok": 96, "total": 118},
            "26/03": {"rate": 84.8, "ok": 39, "total": 46},
        },
    },
    "분석4팀": {
        "query": {
            "25/12": {"rate": 90.3, "ok": 112, "total": 124},
            "26/01": {"rate": 89.6, "ok": 112, "total": 125},
            "26/02": {"rate": 88.1, "ok": 104, "total": 118},
            "26/03": {"rate": 91.4, "ok": 53, "total": 58},
        },
        "spark": {
            "25/12": {"rate": 78.9, "ok": 97, "total": 123},
            "26/01": {"rate": 77.6, "ok": 97, "total": 125},
            "26/02": {"rate": 75.4, "ok": 89, "total": 118},
            "26/03": {"rate": 79.3, "ok": 46, "total": 58},
        },
        "sink": {
            "25/12": {"rate": 95.2, "ok": 119, "total": 125},
            "26/01": {"rate": 94.4, "ok": 118, "total": 125},
            "26/02": {"rate": 93.2, "ok": 110, "total": 118},
            "26/03": {"rate": 96.6, "ok": 56, "total": 58},
        },
        "branch": {
            "25/12": {"rate": 72.4, "ok": 84, "total": 116},
            "26/01": {"rate": 71.2, "ok": 89, "total": 125},
            "26/02": {"rate": 69.5, "ok": 82, "total": 118},
            "26/03": {"rate": 74.1, "ok": 43, "total": 58},
        },
    },
    "분석5팀": {
        "query": {
            "25/12": {"rate": 94.5, "ok": 117, "total": 124},
            "26/01": {"rate": 93.9, "ok": 115, "total": 123},
            "26/02": {"rate": 92.3, "ok": 108, "total": 117},
            "26/03": {"rate": 94.3, "ok": 50, "total": 53},
        },
        "spark": {
            "25/12": {"rate": 84.6, "ok": 104, "total": 123},
            "26/01": {"rate": 83.7, "ok": 103, "total": 123},
            "26/02": {"rate": 82.1, "ok": 96, "total": 117},
            "26/03": {"rate": 86.8, "ok": 46, "total": 53},
        },
        "sink": {
            "25/12": {"rate": 97.5, "ok": 118, "total": 121},
            "26/01": {"rate": 96.7, "ok": 119, "total": 123},
            "26/02": {"rate": 95.7, "ok": 112, "total": 117},
            "26/03": {"rate": 98.1, "ok": 52, "total": 53},
        },
        "branch": {
            "25/12": {"rate": 79.8, "ok": 95, "total": 119},
            "26/01": {"rate": 78.0, "ok": 96, "total": 123},
            "26/02": {"rate": 76.9, "ok": 90, "total": 117},
            "26/03": {"rate": 81.1, "ok": 43, "total": 53},
        },
    },
    "분석6팀": {
        "query": {
            "25/12": {"rate": 91.8, "ok": 112, "total": 122},
            "26/01": {"rate": 90.6, "ok": 111, "total": 122},
            "26/02": {"rate": 89.0, "ok": 105, "total": 118},
            "26/03": {"rate": 92.7, "ok": 51, "total": 55},
        },
        "spark": {
            "25/12": {"rate": 80.5, "ok": 99, "total": 123},
            "26/01": {"rate": 79.5, "ok": 97, "total": 122},
            "26/02": {"rate": 77.1, "ok": 91, "total": 118},
            "26/03": {"rate": 81.8, "ok": 45, "total": 55},
        },
        "sink": {
            "25/12": {"rate": 96.1, "ok": 122, "total": 127},
            "26/01": {"rate": 95.9, "ok": 117, "total": 122},
            "26/02": {"rate": 94.1, "ok": 111, "total": 118},
            "26/03": {"rate": 96.4, "ok": 53, "total": 55},
        },
        "branch": {
            "25/12": {"rate": 74.6, "ok": 88, "total": 118},
            "26/01": {"rate": 73.0, "ok": 89, "total": 122},
            "26/02": {"rate": 71.2, "ok": 84, "total": 118},
            "26/03": {"rate": 76.4, "ok": 42, "total": 55},
        },
    },
    "분석7팀": {
        "query": {
            "25/12": {"rate": 96.3, "ok": 118, "total": 122},
            "26/01": {"rate": 95.8, "ok": 115, "total": 120},
            "26/02": {"rate": 94.7, "ok": 108, "total": 114},
            "26/03": {"rate": 96.5, "ok": 55, "total": 57},
        },
        "spark": {
            "25/12": {"rate": 87.2, "ok": 102, "total": 117},
            "26/01": {"rate": 86.7, "ok": 104, "total": 120},
            "26/02": {"rate": 85.1, "ok": 97, "total": 114},
            "26/03": {"rate": 87.7, "ok": 50, "total": 57},
        },
        "sink": {
            "25/12": {"rate": 98.4, "ok": 120, "total": 122},
            "26/01": {"rate": 97.5, "ok": 117, "total": 120},
            "26/02": {"rate": 96.5, "ok": 110, "total": 114},
            "26/03": {"rate": 98.2, "ok": 56, "total": 57},
        },
        "branch": {
            "25/12": {"rate": 82.1, "ok": 96, "total": 117},
            "26/01": {"rate": 81.7, "ok": 98, "total": 120},
            "26/02": {"rate": 80.7, "ok": 92, "total": 114},
            "26/03": {"rate": 84.2, "ok": 48, "total": 57},
        },
    },
    "분석8팀": {
        "query": {
            "25/12": {"rate": 89.7, "ok": 105, "total": 117},
            "26/01": {"rate": 88.3, "ok": 106, "total": 120},
            "26/02": {"rate": 86.3, "ok": 101, "total": 117},
            "26/03": {"rate": 91.1, "ok": 51, "total": 56},
        },
        "spark": {
            "25/12": {"rate": 76.8, "ok": 93, "total": 121},
            "26/01": {"rate": 75.0, "ok": 90, "total": 120},
            "26/02": {"rate": 73.5, "ok": 86, "total": 117},
            "26/03": {"rate": 78.6, "ok": 44, "total": 56},
        },
        "sink": {
            "25/12": {"rate": 94.3, "ok": 116, "total": 123},
            "26/01": {"rate": 93.3, "ok": 112, "total": 120},
            "26/02": {"rate": 91.5, "ok": 107, "total": 117},
            "26/03": {"rate": 94.6, "ok": 53, "total": 56},
        },
        "branch": {
            "25/12": {"rate": 70.9, "ok": 83, "total": 117},
            "26/01": {"rate": 69.2, "ok": 83, "total": 120},
            "26/02": {"rate": 67.5, "ok": 79, "total": 117},
            "26/03": {"rate": 73.2, "ok": 41, "total": 56},
        },
    },
}


def get_wfl_monthly_rates() -> list[dict]:
    """WFL DAG 월별 성공률 반환."""
    return WFL_MONTHLY_DATA


def get_team_success_rates() -> list[dict]:
    """팀별 월 DAG 성공률 반환 (PDF 생성용 포맷)."""
    return TEAM_MONTHLY_SUCCESS_DATA


def get_team_task_rates() -> dict:
    """팀별 Task 성공/실패 현황 반환."""
    return {
        "task_types": TASK_TYPES,
        "teams": TEAM_TASK_MONTHLY_DATA,
    }
