"""Infra Service - AWS 인프라 리소스 현황 대시보드."""

import logging
import time
from datetime import datetime, timedelta
from typing import Any

from src.common.timezone import KST
from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)

# 5분 TTL 캐시
_CACHE_TTL = 300

# AWS 상태 → 정규화 상태 매핑
_STATUS_MAP: dict[str, str] = {
    # MWAA
    "available": "running",
    "creating": "pending",
    "creating_snapshot": "pending",
    "deleting": "stopping",
    "updating": "pending",
    "unavailable": "error",
    # RDS
    "backing-up": "running",
    "configuring-enhanced-monitoring": "running",
    "configuring-log-exports": "running",
    "maintenance": "warning",
    "modifying": "pending",
    "rebooting": "pending",
    "renaming": "pending",
    "resetting-master-credentials": "pending",
    "starting": "pending",
    "stopped": "stopped",
    "stopping": "stopping",
    "storage-optimization": "running",
    # EMR
    "bootstrapping": "pending",
    "running": "running",
    "waiting": "running",
    "terminating": "stopping",
    "terminated": "stopped",
    "terminated_with_errors": "error",
    # EMR Serverless
    "created": "running",
    "started": "running",
    "starting": "pending",
    "stopped": "stopped",
    "stopping": "stopping",
    "terminated": "stopped",
    # MSK
    "active": "running",
    "creation_in_progress": "pending",
    "deleting": "stopping",
    "failed": "error",
    "healing": "warning",
    "maintenance": "warning",
    "rebooting_broker": "pending",
    "updating": "pending",
    # Lambda
    "inactive": "stopped",
    # Athena
    "enabled": "running",
    "disabled": "stopped",
    # NAT Gateway
    "available": "running",
    "pending": "pending",
    "failed": "error",
    "deleting": "stopping",
    "deleted": "stopped",
    # SageMaker
    "inservice": "running",
    "in_service": "running",
    "creating": "pending",
    "updating": "pending",
    "systemupdating": "pending",
    "rollingback": "warning",
    "outofservice": "stopped",
    "deleting": "stopping",
    "failed": "error",
}

# 정규화 상태 → 대시보드 표시 상태
_DISPLAY_STATUS_MAP: dict[str, str] = {
    "running": "ok",
    "pending": "warning",
    "stopped": "critical",
    "stopping": "warning",
    "error": "critical",
    "warning": "warning",
    "unknown": "neutral",
}


def _normalize_status(raw: str) -> str:
    """AWS 원본 상태를 정규화 상태로 변환."""
    return _STATUS_MAP.get(raw.lower().replace("-", "_"), "unknown")


def _display_status(normalized: str) -> str:
    """정규화 상태를 대시보드 표시 상태(ok/warning/critical/neutral)로 변환."""
    return _DISPLAY_STATUS_MAP.get(normalized, "neutral")


# ── Dev Mock 데이터 ──────────────────────────────────


def _mock_mwaa() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-airflow-dlk",
            "raw_status": "AVAILABLE",
            "normalized_status": "running",
            "display_status": "ok",
            "airflow_version": "2.8.1",
            "environment_class": "mw1.medium",
            "min_workers": 2,
            "max_workers": 10,
            "dag_s3_bucket": "bdp-airflow-dlk-dags",
            "dag_s3_path": "dags",
        },
        {
            "name": "bdp-airflow-wfl",
            "raw_status": "AVAILABLE",
            "normalized_status": "running",
            "display_status": "ok",
            "airflow_version": "2.8.1",
            "environment_class": "mw1.small",
            "min_workers": 1,
            "max_workers": 5,
            "dag_s3_bucket": "bdp-airflow-wfl-dags",
            "dag_s3_path": "dags",
        },
    ]


def _mock_rds() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-main-db",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "engine": "mysql 8.0.35",
            "instance_class": "db.r6g.xlarge",
            "storage_gb": 500,
            "storage_type": "gp3",
            "multi_az": "Yes",
        },
        {
            "name": "bdp-analytics-db",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "engine": "mysql 8.0.35",
            "instance_class": "db.r6g.2xlarge",
            "storage_gb": 1000,
            "storage_type": "io1",
            "multi_az": "Yes",
        },
        {
            "name": "bdp-airflow-meta",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "engine": "postgres 15.4",
            "instance_class": "db.r6g.large",
            "storage_gb": 200,
            "storage_type": "gp3",
            "multi_az": "No",
        },
        {
            "name": "bdp-hive-metastore",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "engine": "mysql 8.0.35",
            "instance_class": "db.r6g.large",
            "storage_gb": 100,
            "storage_type": "gp2",
            "multi_az": "No",
        },
    ]


def _mock_emr_cluster() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-spark-etl",
            "raw_status": "RUNNING",
            "normalized_status": "running",
            "display_status": "ok",
            "release": "emr-7.0.0",
            "core_instance_type": "m5.2xlarge",
            "core_count": 3,
            "task_instance_type": "m5.4xlarge",
            "task_count": 2,
            "s3_buckets": ["bdp-raw-data", "bdp-processed-data", "bdp-logs"],
        },
        {
            "name": "bdp-hive-adhoc",
            "raw_status": "WAITING",
            "normalized_status": "running",
            "display_status": "ok",
            "release": "emr-6.15.0",
            "core_instance_type": "r5.xlarge",
            "core_count": 3,
            "task_instance_type": "-",
            "task_count": 0,
            "s3_buckets": ["bdp-raw-data", "bdp-processed-data"],
        },
    ]


def _mock_emr_serverless() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-spark-serverless",
            "raw_status": "STARTED",
            "normalized_status": "running",
            "display_status": "ok",
            "type": "SPARK",
            "release": "emr-7.0.0",
        },
        {
            "name": "bdp-hive-serverless",
            "raw_status": "STARTED",
            "normalized_status": "running",
            "display_status": "ok",
            "type": "HIVE",
            "release": "emr-6.15.0",
        },
    ]


def _mock_msk() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-kafka-main",
            "raw_status": "ACTIVE",
            "normalized_status": "running",
            "display_status": "ok",
            "kafka_version": "3.6.0",
            "broker_count": 3,
            "instance_type": "kafka.m5.large",
            "cluster_default_rf": 3,
            "cluster_default_min_isr": 2,
            "topics": [
                {
                    "name": "고객행동로그",
                    "partitions": 12,
                    "replication_factor": 3,
                    "min_insync_replicas": 2,
                    "retention_ms": 604800000,
                },
                {
                    "name": "주문이벤트",
                    "partitions": 6,
                    "replication_factor": 3,
                    "min_insync_replicas": 2,
                    "retention_ms": 259200000,
                },
                {
                    "name": "실시간알림",
                    "partitions": 4,
                    "replication_factor": 2,
                    "min_insync_replicas": 1,
                    "retention_ms": 86400000,
                },
                {
                    "name": "테스트로그",
                    "partitions": 1,
                    "replication_factor": 1,
                    "min_insync_replicas": 1,
                    "retention_ms": 3600000,
                },
            ],
            "consumer_groups": [
                {
                    "name": "c2p consumer",
                    "state": "Stable",
                    "members": 3,
                    "subscribed_topics": ["고객행동로그", "주문이벤트"],
                    "total_lag": 120,
                },
                {
                    "name": "parquet consumer",
                    "state": "Stable",
                    "members": 2,
                    "subscribed_topics": ["고객행동로그", "실시간알림"],
                    "total_lag": 45,
                },
                {
                    "name": "test consumer",
                    "state": "Empty",
                    "members": 0,
                    "subscribed_topics": ["테스트로그"],
                    "total_lag": 0,
                },
            ],
        },
    ]


def _mock_sagemaker() -> list[dict[str, Any]]:
    return [
        {
            "name": "hcb",
            "raw_status": "InService",
            "normalized_status": "running",
            "display_status": "ok",
            "instance_type": "ml.m5.xlarge",
            "instance_count": 2,
        },
        {
            "name": "hpi",
            "raw_status": "InService",
            "normalized_status": "running",
            "display_status": "ok",
            "instance_type": "ml.g4dn.xlarge",
            "instance_count": 1,
        },
    ]


def _mock_sagemaker_studio() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-ml-workspace",
            "raw_status": "InService",
            "normalized_status": "running",
            "display_status": "ok",
            "domain_id": "d-abcdefghij",
            "auth_mode": "IAM",
            "vpc_id": "vpc-0a1b2c3d4e5f67890",
            "subnet_ids": [
                "subnet-0aa1b2c3d4e5f6789",
                "subnet-0bb1c2d3e4f5a6789",
            ],
            "user_profiles": [
                {
                    "name": "analyst-kim",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.t3.medium",
                    "team": "데이터분석팀",
                },
                {
                    "name": "engineer-lee",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.m5.large",
                    "team": "ML엔지니어링팀",
                },
                {
                    "name": "scientist-park",
                    "status": "InService",
                    "app_type": "CodeEditor",
                    "instance_type": "ml.t3.large",
                    "team": "AI연구팀",
                },
                {
                    "name": "intern-choi",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.t3.medium",
                    "team": "데이터분석팀",
                },
                {
                    "name": "lead-jung",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.m5.xlarge",
                    "team": "ML엔지니어링팀",
                },
            ],
            "lifecycle_configs": [
                {
                    "name": "auto-shutdown-60min",
                    "type": "JupyterServer",
                    "script": "idle-timeout 60m",
                },
                {
                    "name": "auto-shutdown-120min",
                    "type": "KernelGateway",
                    "script": "idle-timeout 120m",
                },
                {"name": "install-deps", "type": "JupyterServer", "script": "pip install ..."},
            ],
            "custom_images": [
                {"name": "bdp-pytorch-gpu", "version": "2.1.0", "status": "CREATED"},
                {"name": "bdp-tensorflow-cpu", "version": "2.15.0", "status": "CREATED"},
                {"name": "bdp-xgboost-custom", "version": "1.7.6", "status": "CREATED"},
                {"name": "bdp-nlp-transformers", "version": "4.36.0", "status": "CREATED"},
            ],
            "spaces": [
                {"name": "shared-experiment", "status": "InService", "space_type": "shared"},
                {"name": "team-notebooks", "status": "InService", "space_type": "shared"},
            ],
            "notebook_instances": [
                {
                    "name": "ml-experiment-nb-01",
                    "status": "InService",
                    "instance_type": "ml.t3.medium",
                    "volume_size_gb": 20,
                    "created_by": "analyst-kim",
                    "team": "데이터분석팀",
                    "last_accessed": "2026-03-01T09:15:00Z",
                },
                {
                    "name": "feature-dev-nb-02",
                    "status": "InService",
                    "instance_type": "ml.m5.large",
                    "volume_size_gb": 50,
                    "created_by": "engineer-lee",
                    "team": "ML엔지니어링팀",
                    "last_accessed": "2026-03-01T10:30:00Z",
                },
                {
                    "name": "data-cleaning-nb-03",
                    "status": "Stopped",
                    "instance_type": "ml.t3.medium",
                    "volume_size_gb": 20,
                    "created_by": "intern-choi",
                    "team": "데이터분석팀",
                    "last_accessed": "2026-02-27T14:00:00Z",
                },
                {
                    "name": "model-eval-nb-04",
                    "status": "InService",
                    "instance_type": "ml.m5.xlarge",
                    "volume_size_gb": 100,
                    "created_by": "lead-jung",
                    "team": "ML엔지니어링팀",
                    "last_accessed": "2026-03-01T11:00:00Z",
                },
                {
                    "name": "research-nb-05",
                    "status": "InService",
                    "instance_type": "ml.t3.large",
                    "volume_size_gb": 30,
                    "created_by": "scientist-park",
                    "team": "AI연구팀",
                    "last_accessed": "2026-03-01T10:00:00Z",
                },
            ],
            "pipeline_executions": [
                {
                    "pipeline_name": "feature-engineering-pipeline",
                    "execution_id": "exec-feat0301",
                    "status": "Succeeded",
                    "start_time": "2026-03-01T08:00:00Z",
                    "end_time": "2026-03-01T08:43:00Z",
                    "steps_total": 5,
                    "steps_completed": 5,
                },
                {
                    "pipeline_name": "feature-engineering-pipeline",
                    "execution_id": "exec-feat0228",
                    "status": "Succeeded",
                    "start_time": "2026-02-28T08:00:00Z",
                    "end_time": "2026-02-28T08:41:00Z",
                    "steps_total": 5,
                    "steps_completed": 5,
                },
                {
                    "pipeline_name": "feature-engineering-pipeline",
                    "execution_id": "exec-abc123",
                    "status": "Succeeded",
                    "start_time": "2026-02-27T08:00:00Z",
                    "end_time": "2026-02-27T08:45:00Z",
                    "steps_total": 5,
                    "steps_completed": 5,
                },
                {
                    "pipeline_name": "model-training-pipeline",
                    "execution_id": "exec-trn0301",
                    "status": "Executing",
                    "start_time": "2026-03-01T09:30:00Z",
                    "end_time": None,
                    "steps_total": 8,
                    "steps_completed": 5,
                },
                {
                    "pipeline_name": "model-training-pipeline",
                    "execution_id": "exec-trn0228",
                    "status": "Succeeded",
                    "start_time": "2026-02-28T10:00:00Z",
                    "end_time": "2026-02-28T11:18:00Z",
                    "steps_total": 8,
                    "steps_completed": 8,
                },
                {
                    "pipeline_name": "model-training-pipeline",
                    "execution_id": "exec-old111",
                    "status": "Succeeded",
                    "start_time": "2026-02-25T10:00:00Z",
                    "end_time": "2026-02-25T11:20:00Z",
                    "steps_total": 8,
                    "steps_completed": 8,
                },
                {
                    "pipeline_name": "batch-inference-pipeline",
                    "execution_id": "exec-inf0301",
                    "status": "Succeeded",
                    "start_time": "2026-03-01T07:00:00Z",
                    "end_time": "2026-03-01T07:28:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
                {
                    "pipeline_name": "batch-inference-pipeline",
                    "execution_id": "exec-ghi789",
                    "status": "Failed",
                    "start_time": "2026-02-27T07:00:00Z",
                    "end_time": "2026-02-27T07:12:00Z",
                    "steps_total": 4,
                    "steps_completed": 2,
                },
                {
                    "pipeline_name": "batch-inference-pipeline",
                    "execution_id": "exec-inf02",
                    "status": "Succeeded",
                    "start_time": "2026-02-26T07:00:00Z",
                    "end_time": "2026-02-26T07:30:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
                {
                    "pipeline_name": "data-quality-check",
                    "execution_id": "exec-dqc0228",
                    "status": "Succeeded",
                    "start_time": "2026-02-28T23:00:00Z",
                    "end_time": "2026-02-28T23:23:00Z",
                    "steps_total": 3,
                    "steps_completed": 3,
                },
                {
                    "pipeline_name": "data-quality-check",
                    "execution_id": "exec-jkl012",
                    "status": "Succeeded",
                    "start_time": "2026-02-26T23:00:00Z",
                    "end_time": "2026-02-26T23:25:00Z",
                    "steps_total": 3,
                    "steps_completed": 3,
                },
                {
                    "pipeline_name": "data-quality-check",
                    "execution_id": "exec-dqc03",
                    "status": "Failed",
                    "start_time": "2026-02-24T23:00:00Z",
                    "end_time": "2026-02-24T23:08:00Z",
                    "steps_total": 3,
                    "steps_completed": 1,
                },
                {
                    "pipeline_name": "hyperparameter-tuning",
                    "execution_id": "exec-hpt0301",
                    "status": "Executing",
                    "start_time": "2026-03-01T10:00:00Z",
                    "end_time": None,
                    "steps_total": 6,
                    "steps_completed": 3,
                },
                {
                    "pipeline_name": "hyperparameter-tuning",
                    "execution_id": "exec-hpt02",
                    "status": "Succeeded",
                    "start_time": "2026-02-26T10:00:00Z",
                    "end_time": "2026-02-26T11:30:00Z",
                    "steps_total": 6,
                    "steps_completed": 6,
                },
                {
                    "pipeline_name": "model-monitoring-pipeline",
                    "execution_id": "exec-mon0301",
                    "status": "Succeeded",
                    "start_time": "2026-03-01T06:00:00Z",
                    "end_time": "2026-03-01T06:17:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
                {
                    "pipeline_name": "model-monitoring-pipeline",
                    "execution_id": "exec-mon01",
                    "status": "Succeeded",
                    "start_time": "2026-02-27T06:00:00Z",
                    "end_time": "2026-02-27T06:18:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
                {
                    "pipeline_name": "data-preprocessing-pipeline",
                    "execution_id": "exec-pre0301",
                    "status": "Succeeded",
                    "start_time": "2026-03-01T05:00:00Z",
                    "end_time": "2026-03-01T05:33:00Z",
                    "steps_total": 5,
                    "steps_completed": 5,
                },
                {
                    "pipeline_name": "data-preprocessing-pipeline",
                    "execution_id": "exec-pre01",
                    "status": "Succeeded",
                    "start_time": "2026-02-27T05:00:00Z",
                    "end_time": "2026-02-27T05:35:00Z",
                    "steps_total": 5,
                    "steps_completed": 5,
                },
            ],
            "default_instance_type": "ml.t3.medium",
            "efs_storage_gb": 250,
        },
        {
            "name": "bdp-data-science",
            "raw_status": "InService",
            "normalized_status": "running",
            "display_status": "ok",
            "domain_id": "d-klmnopqrst",
            "auth_mode": "SSO",
            "vpc_id": "vpc-0f1e2d3c4b5a69870",
            "subnet_ids": [
                "subnet-0cc1d2e3f4a5b6789",
            ],
            "user_profiles": [
                {
                    "name": "ds-kim",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.m5.large",
                    "team": "데이터사이언스팀",
                },
                {
                    "name": "ds-lee",
                    "status": "InService",
                    "app_type": "JupyterLab",
                    "instance_type": "ml.m5.large",
                    "team": "데이터사이언스팀",
                },
                {
                    "name": "ds-song",
                    "status": "InService",
                    "app_type": "CodeEditor",
                    "instance_type": "ml.m5.xlarge",
                    "team": "MLOps팀",
                },
            ],
            "lifecycle_configs": [
                {
                    "name": "auto-shutdown-90min",
                    "type": "JupyterServer",
                    "script": "idle-timeout 90m",
                },
            ],
            "custom_images": [
                {"name": "ds-spark-env", "version": "3.5.0", "status": "CREATED"},
                {"name": "ds-ray-cluster", "version": "2.9.0", "status": "CREATED"},
            ],
            "spaces": [],
            "notebook_instances": [
                {
                    "name": "ds-exploration-nb-01",
                    "status": "InService",
                    "instance_type": "ml.m5.large",
                    "volume_size_gb": 100,
                    "created_by": "ds-kim",
                    "team": "데이터사이언스팀",
                    "last_accessed": "2026-03-01T11:00:00Z",
                },
                {
                    "name": "ds-prototype-nb-02",
                    "status": "InService",
                    "instance_type": "ml.m5.xlarge",
                    "volume_size_gb": 100,
                    "created_by": "ds-song",
                    "team": "MLOps팀",
                    "last_accessed": "2026-03-01T10:45:00Z",
                },
                {
                    "name": "ds-analysis-nb-03",
                    "status": "Stopped",
                    "instance_type": "ml.m5.large",
                    "volume_size_gb": 50,
                    "created_by": "ds-lee",
                    "team": "데이터사이언스팀",
                    "last_accessed": "2026-02-28T15:00:00Z",
                },
            ],
            "pipeline_executions": [
                {
                    "pipeline_name": "daily-etl-pipeline",
                    "execution_id": "exec-etl0301",
                    "status": "Succeeded",
                    "start_time": "2026-03-01T06:00:00Z",
                    "end_time": "2026-03-01T06:33:00Z",
                    "steps_total": 6,
                    "steps_completed": 6,
                },
                {
                    "pipeline_name": "daily-etl-pipeline",
                    "execution_id": "exec-etl0228",
                    "status": "Succeeded",
                    "start_time": "2026-02-28T06:00:00Z",
                    "end_time": "2026-02-28T06:31:00Z",
                    "steps_total": 6,
                    "steps_completed": 6,
                },
                {
                    "pipeline_name": "daily-etl-pipeline",
                    "execution_id": "exec-mno345",
                    "status": "Succeeded",
                    "start_time": "2026-02-27T06:00:00Z",
                    "end_time": "2026-02-27T06:35:00Z",
                    "steps_total": 6,
                    "steps_completed": 6,
                },
                {
                    "pipeline_name": "daily-etl-pipeline",
                    "execution_id": "exec-etl03",
                    "status": "Failed",
                    "start_time": "2026-02-25T06:00:00Z",
                    "end_time": "2026-02-25T06:10:00Z",
                    "steps_total": 6,
                    "steps_completed": 2,
                },
                {
                    "pipeline_name": "model-retraining-weekly",
                    "execution_id": "exec-rtw0301",
                    "status": "Executing",
                    "start_time": "2026-03-01T10:00:00Z",
                    "end_time": None,
                    "steps_total": 10,
                    "steps_completed": 7,
                },
                {
                    "pipeline_name": "model-retraining-weekly",
                    "execution_id": "exec-pqr678",
                    "status": "Succeeded",
                    "start_time": "2026-02-27T10:00:00Z",
                    "end_time": "2026-02-27T12:25:00Z",
                    "steps_total": 10,
                    "steps_completed": 10,
                },
                {
                    "pipeline_name": "model-retraining-weekly",
                    "execution_id": "exec-rtw02",
                    "status": "Succeeded",
                    "start_time": "2026-02-20T10:00:00Z",
                    "end_time": "2026-02-20T12:30:00Z",
                    "steps_total": 10,
                    "steps_completed": 10,
                },
                {
                    "pipeline_name": "ab-test-evaluation",
                    "execution_id": "exec-abt0228",
                    "status": "Succeeded",
                    "start_time": "2026-02-28T18:00:00Z",
                    "end_time": "2026-02-28T18:19:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
                {
                    "pipeline_name": "ab-test-evaluation",
                    "execution_id": "exec-stu901",
                    "status": "Succeeded",
                    "start_time": "2026-02-26T18:00:00Z",
                    "end_time": "2026-02-26T18:20:00Z",
                    "steps_total": 4,
                    "steps_completed": 4,
                },
            ],
            "default_instance_type": "ml.m5.large",
            "efs_storage_gb": 180,
        },
    ]


def _mock_s3() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-raw-data",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "bucket_size_gb": 2500,
            "object_count": 15_000_000,
            "versioning": "Enabled",
            "encryption": "aws:kms",
            "prefixes": [
                {"prefix": "clickstream/", "size_gb": 980, "object_count": 6_200_000},
                {"prefix": "app-logs/", "size_gb": 620, "object_count": 4_100_000},
                {"prefix": "api-access/", "size_gb": 450, "object_count": 2_800_000},
                {"prefix": "user-activity/", "size_gb": 310, "object_count": 1_500_000},
                {"prefix": "payments/", "size_gb": 85, "object_count": 280_000},
                {"prefix": "product-catalog/", "size_gb": 55, "object_count": 120_000},
            ],
        },
        {
            "name": "bdp-processed-data",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "bucket_size_gb": 800,
            "object_count": 5_000_000,
            "versioning": "Enabled",
            "encryption": "aws:kms",
            "prefixes": [
                {"prefix": "parquet/", "size_gb": 420, "object_count": 2_300_000},
                {"prefix": "aggregated/", "size_gb": 210, "object_count": 1_800_000},
                {"prefix": "delta-lake/", "size_gb": 130, "object_count": 750_000},
                {"prefix": "tmp/", "size_gb": 40, "object_count": 150_000},
            ],
        },
        {
            "name": "bdp-ml-artifacts",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "bucket_size_gb": 150,
            "object_count": 50_000,
            "versioning": "Enabled",
            "encryption": "aws:kms",
            "prefixes": [
                {"prefix": "models/", "size_gb": 72, "object_count": 1_200},
                {"prefix": "features/", "size_gb": 45, "object_count": 38_000},
                {"prefix": "training/", "size_gb": 28, "object_count": 9_500},
                {"prefix": "checkpoints/", "size_gb": 5, "object_count": 1_300},
            ],
        },
        {
            "name": "bdp-logs",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "bucket_size_gb": 3000,
            "object_count": 50_000_000,
            "versioning": "Suspended",
            "encryption": "AES256",
            "prefixes": [
                {"prefix": "emr/", "size_gb": 1200, "object_count": 18_000_000},
                {"prefix": "mwaa/", "size_gb": 680, "object_count": 12_000_000},
                {"prefix": "lambda/", "size_gb": 520, "object_count": 9_500_000},
                {"prefix": "glue/", "size_gb": 340, "object_count": 6_200_000},
                {"prefix": "athena-results/", "size_gb": 260, "object_count": 4_300_000},
            ],
        },
    ]


def _mock_glue() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-data-catalog",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "database_count": 12,
            "table_count": 62,
            "databases": [
                {"name": "raw_zone", "table_count": 7, "size_bytes": 1_288_490_188_800},
                {"name": "staging", "table_count": 5, "size_bytes": 429_496_729_600},
                {"name": "curated", "table_count": 5, "size_bytes": 858_993_459_200},
                {"name": "analytics", "table_count": 5, "size_bytes": 214_748_364_800},
                {"name": "data_lake", "table_count": 5, "size_bytes": 2_576_980_377_600},
                {"name": "etl_temp", "table_count": 5, "size_bytes": 53_687_091_200},
                {"name": "reports", "table_count": 5, "size_bytes": 107_374_182_400},
                {"name": "metrics", "table_count": 5, "size_bytes": 322_122_547_200},
                {"name": "logs", "table_count": 5, "size_bytes": 4_294_967_296_000},
                {"name": "events", "table_count": 5, "size_bytes": 1_717_986_918_400},
                {"name": "reference", "table_count": 5, "size_bytes": 5_368_709_120},
                {"name": "archive", "table_count": 5, "size_bytes": 3_221_225_472_000},
            ],
        },
        {
            "name": "bdp-ml-catalog",
            "raw_status": "active",
            "normalized_status": "running",
            "display_status": "ok",
            "database_count": 3,
            "table_count": 11,
            "databases": [
                {"name": "feature_store", "table_count": 3, "size_bytes": 644_245_094_400},
                {"name": "training", "table_count": 3, "size_bytes": 2_147_483_648_000},
                {"name": "inference", "table_count": 5, "size_bytes": 107_374_182_400},
            ],
        },
    ]


def _mock_lambda() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-event-processor",
            "raw_status": "Active",
            "normalized_status": "running",
            "display_status": "ok",
            "runtime": "python3.12",
            "memory_mb": 512,
            "timeout_sec": 300,
            "reserved_concurrency": 100,
        },
        {
            "name": "bdp-alert-handler",
            "raw_status": "Active",
            "normalized_status": "running",
            "display_status": "ok",
            "runtime": "python3.12",
            "memory_mb": 256,
            "timeout_sec": 60,
            "reserved_concurrency": 50,
        },
        {
            "name": "bdp-etl-trigger",
            "raw_status": "Active",
            "normalized_status": "running",
            "display_status": "ok",
            "runtime": "python3.11",
            "memory_mb": 128,
            "timeout_sec": 30,
            "reserved_concurrency": None,
        },
        {
            "name": "bdp-api-gateway",
            "raw_status": "Active",
            "normalized_status": "running",
            "display_status": "ok",
            "runtime": "nodejs20.x",
            "memory_mb": 1024,
            "timeout_sec": 30,
            "reserved_concurrency": 200,
        },
    ]


def _mock_athena() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-analytics-wg",
            "raw_status": "ENABLED",
            "normalized_status": "running",
            "display_status": "ok",
            "engine_version": "Athena engine version 3",
            "result_location": "s3://bdp-athena-results/",
            "bytes_scanned_limit": 10_737_418_240,
            "iceberg_version": "1.4.2",
            "additional_configuration": {},
            "running_queries": 3,
            "queued_queries": 1,
            "recent_success_rate": 96.0,
            "recent_scanned_gb": 42.5,
        },
        {
            "name": "bdp-adhoc-wg",
            "raw_status": "ENABLED",
            "normalized_status": "running",
            "display_status": "ok",
            "engine_version": "Athena engine version 3",
            "result_location": "s3://bdp-athena-results/adhoc/",
            "bytes_scanned_limit": 5_368_709_120,
            "iceberg_version": "1.4.2",
            "additional_configuration": {},
            "running_queries": 0,
            "queued_queries": 0,
            "recent_success_rate": 100.0,
            "recent_scanned_gb": 5.2,
        },
    ]


def _mock_eks() -> list[dict[str, Any]]:
    return [
        {
            "name": "bdp-ml-cluster",
            "raw_status": "ACTIVE",
            "normalized_status": "running",
            "display_status": "ok",
            "kubernetes_version": "1.29",
            "node_group_count": 3,
            "total_nodes": 12,
            "platform_version": "eks.8",
        },
        {
            "name": "bdp-service-cluster",
            "raw_status": "ACTIVE",
            "normalized_status": "running",
            "display_status": "ok",
            "kubernetes_version": "1.28",
            "node_group_count": 2,
            "total_nodes": 6,
            "platform_version": "eks.12",
        },
    ]


def _mock_natgw() -> list[dict[str, Any]]:
    return [
        {
            "name": "nat-0a1b2c3d4e5f6g7h8",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "subnet_id": "subnet-0abc1234def56789a",
            "vpc_id": "vpc-0abc1234def56789b",
            "public_ip": "52.78.123.45",
            "private_ip": "10.0.1.100",
            "connectivity_type": "public",
            "az": "ap-northeast-2a",
            "tag_name": "bdp-nat-az1",
        },
        {
            "name": "nat-1b2c3d4e5f6g7h8i",
            "raw_status": "available",
            "normalized_status": "running",
            "display_status": "ok",
            "subnet_id": "subnet-0abc1234def56789c",
            "vpc_id": "vpc-0abc1234def56789b",
            "public_ip": "52.78.123.46",
            "private_ip": "10.0.2.100",
            "connectivity_type": "public",
            "az": "ap-northeast-2c",
            "tag_name": "bdp-nat-az2",
        },
    ]


def _mock_pod_restart_daily(namespaces: list[str], seed_prefix: str) -> dict[str, Any]:
    """dev 환경용 네임스페이스별 일별 Pod 리스타트 mock 시계열."""
    from src.agent_server.bdp_dashboard.services.infra_metrics_service import (
        _daily_dates,
        _seeded_rng,
    )

    dates = _daily_dates(31)
    ns_data: dict[str, list[dict[str, Any]]] = {}
    for ns in namespaces:
        rng = _seeded_rng(f"pod_restart_{seed_prefix}_{ns}")
        series: list[dict[str, Any]] = []
        for d in dates:
            # 대부분 0~2, 간헐적 스파이크
            val = max(0, int(rng.gauss(1, 1.5)))
            if rng.random() < 0.05:
                val = rng.randint(5, 15)
            series.append({"date": d, "count": val})
        ns_data[ns] = series
    return {"namespaces": ns_data}


def _mock_eks_resource_metrics(
    detail_data: dict[str, Any], cluster_name: str
) -> tuple[dict, dict, dict]:
    """dev 환경용 EKS 리소스 메트릭 mock 생성. (pod_resources, node_resources, event_trends) 반환."""
    from src.agent_server.bdp_dashboard.services.infra_metrics_service import (
        _daily_dates,
        _seeded_rng,
    )

    dates = _daily_dates(31)
    nodes = detail_data.get("nodes", [])
    pods = detail_data.get("pods", {}).get("items", [])

    # ── node_resources ──
    node_groups_nr: dict[str, Any] = {}
    for node in nodes:
        ng = node.get("node_group", "default")
        if ng not in node_groups_nr:
            node_groups_nr[ng] = {"nodes": {}}
        cpu_cap = int(node.get("cpu_capacity", "4")) * 1000
        mem_cap_str = node.get("memory_capacity", "16Gi")
        mem_cap = int(mem_cap_str.replace("Gi", "")) * 1024 if "Gi" in str(mem_cap_str) else 16384
        rng = _seeded_rng(f"node_res_{cluster_name}_{node['name']}")
        daily = []
        for d in dates:
            cpu = int(cpu_cap * rng.uniform(0.3, 0.75))
            mem = int(mem_cap * rng.uniform(0.4, 0.8))
            daily.append({"date": d, "cpu_mc": cpu, "memory_mb": mem})
        pod_names = [p["name"] for p in pods if p.get("node_name") == node["name"]]
        node_groups_nr[ng]["nodes"][node["name"]] = {
            "cpu_capacity_mc": cpu_cap,
            "memory_capacity_mb": mem_cap,
            "status": node.get("status", "Ready"),
            "instance_type": node.get("instance_type", ""),
            "pod_names": pod_names,
            "daily": daily,
        }

    # ── pod_resources ──
    node_groups_pr: dict[str, Any] = {}
    for pod in pods:
        node_name = pod.get("node_name", "")
        ng = "default"
        for n in nodes:
            if n["name"] == node_name:
                ng = n.get("node_group", "default")
                break
        ns = pod.get("namespace", "default")
        if ng not in node_groups_pr:
            node_groups_pr[ng] = {"namespaces": {}}
        if ns not in node_groups_pr[ng]["namespaces"]:
            node_groups_pr[ng]["namespaces"][ns] = {"pods": {}}

        cpu_req_str = pod.get("cpu_request", "100m")
        cpu_lim_str = pod.get("cpu_limit", "500m")
        mem_req_str = pod.get("memory_request", "128Mi")
        mem_lim_str = pod.get("memory_limit", "512Mi")

        def _parse_cpu(s: str) -> int:
            s = str(s)
            if s.endswith("m"):
                return int(s[:-1])
            return int(float(s) * 1000) if s else 100

        def _parse_mem(s: str) -> int:
            s = str(s)
            if s.endswith("Gi"):
                return int(float(s[:-2]) * 1024)
            if s.endswith("Mi"):
                return int(s[:-2])
            return 128

        cpu_req = _parse_cpu(cpu_req_str)
        cpu_lim = _parse_cpu(cpu_lim_str)
        mem_req = _parse_mem(mem_req_str)
        mem_lim = _parse_mem(mem_lim_str)

        rng = _seeded_rng(f"pod_res_{cluster_name}_{pod['name']}")
        daily = []
        for d in dates:
            cpu = int(cpu_req * rng.uniform(0.3, 1.2))
            mem = int(mem_req * rng.uniform(0.5, 1.1))
            daily.append({"date": d, "cpu_mc": cpu, "memory_mb": mem})
        node_groups_pr[ng]["namespaces"][ns]["pods"][pod["name"]] = {
            "cpu_request_mc": cpu_req,
            "cpu_limit_mc": cpu_lim,
            "memory_request_mb": mem_req,
            "memory_limit_mb": mem_lim,
            "daily": daily,
        }

    # ── event_trends ──
    reasons = ["OOMKilling", "BackOff", "FailedScheduling", "Unhealthy"]
    node_groups_et: dict[str, Any] = {}
    for ng in set(n.get("node_group", "default") for n in nodes):
        reason_data: dict[str, list] = {}
        for reason in reasons:
            rng = _seeded_rng(f"event_{cluster_name}_{ng}_{reason}")
            series = []
            for d in dates:
                count = 0 if rng.random() > 0.15 else rng.randint(1, 5)
                series.append({"date": d, "count": count})
            reason_data[reason] = series
        node_groups_et[ng] = {"reasons": reason_data}

    return (
        {"node_groups": node_groups_pr},
        {"node_groups": node_groups_nr},
        {"node_groups": node_groups_et},
    )


def _mock_eks_detail(cluster_name: str) -> dict[str, Any]:
    """dev 환경용 EKS 클러스터 상세 mock 데이터."""
    _clusters = {
        "bdp-ml-cluster": {
            "nodegroups": [
                {
                    "name": "ml-gpu-ng",
                    "status": "ACTIVE",
                    "instance_types": ["g5.2xlarge"],
                    "ami_type": "AL2_x86_64_GPU",
                    "disk_size": 100,
                    "min_size": 2,
                    "max_size": 8,
                    "desired_size": 4,
                    "labels": {"workload": "ml-training"},
                },
                {
                    "name": "ml-cpu-ng",
                    "status": "ACTIVE",
                    "instance_types": ["m5.2xlarge"],
                    "ami_type": "AL2_x86_64",
                    "disk_size": 50,
                    "min_size": 2,
                    "max_size": 6,
                    "desired_size": 3,
                    "labels": {"workload": "ml-serving"},
                },
                {
                    "name": "system-ng",
                    "status": "ACTIVE",
                    "instance_types": ["m5.xlarge"],
                    "ami_type": "AL2_x86_64",
                    "disk_size": 50,
                    "min_size": 2,
                    "max_size": 4,
                    "desired_size": 2,
                    "labels": {"workload": "system"},
                },
            ],
            "nodes": [
                {
                    "name": "ip-10-0-1-101.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "8",
                    "memory_capacity": "32Gi",
                    "pod_count": 12,
                    "node_group": "ml-gpu-ng",
                    "instance_type": "g5.2xlarge",
                },
                {
                    "name": "ip-10-0-1-102.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "8",
                    "memory_capacity": "32Gi",
                    "pod_count": 8,
                    "node_group": "ml-gpu-ng",
                    "instance_type": "g5.2xlarge",
                },
                {
                    "name": "ip-10-0-2-101.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "8",
                    "memory_capacity": "32Gi",
                    "pod_count": 15,
                    "node_group": "ml-cpu-ng",
                    "instance_type": "m5.2xlarge",
                },
                {
                    "name": "ip-10-0-3-101.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "4",
                    "memory_capacity": "16Gi",
                    "pod_count": 22,
                    "node_group": "system-ng",
                    "instance_type": "m5.xlarge",
                },
            ],
            "pods": {
                "namespace_summary": [
                    {"namespace": "default", "total": 5, "running": 5, "pending": 0, "failed": 0},
                    {
                        "namespace": "kube-system",
                        "total": 12,
                        "running": 12,
                        "pending": 0,
                        "failed": 0,
                    },
                    {
                        "namespace": "ml-training",
                        "total": 18,
                        "running": 16,
                        "pending": 2,
                        "failed": 0,
                    },
                    {
                        "namespace": "ml-serving",
                        "total": 8,
                        "running": 8,
                        "pending": 0,
                        "failed": 0,
                    },
                    {
                        "namespace": "monitoring",
                        "total": 6,
                        "running": 6,
                        "pending": 0,
                        "failed": 0,
                    },
                ],
                "node_pod_counts": {
                    "ip-10-0-1-101.ap-northeast-2.compute.internal": 12,
                    "ip-10-0-1-102.ap-northeast-2.compute.internal": 8,
                    "ip-10-0-2-101.ap-northeast-2.compute.internal": 15,
                    "ip-10-0-3-101.ap-northeast-2.compute.internal": 22,
                },
                "abnormal_pods": [
                    {
                        "name": "training-job-7f8d9-worker-3",
                        "namespace": "ml-training",
                        "node_name": "ip-10-0-1-102.ap-northeast-2.compute.internal",
                        "phase": "Pending",
                        "display_status": "warning",
                        "restart_count": 0,
                    },
                    {
                        "name": "training-job-7f8d9-worker-4",
                        "namespace": "ml-training",
                        "node_name": "",
                        "phase": "Pending",
                        "display_status": "warning",
                        "restart_count": 0,
                    },
                ],
                "total_count": 49,
                "items": [
                    {
                        "name": "ml-api-server-6f7b8c-abc12",
                        "namespace": "ml-serving",
                        "node_name": "ip-10-0-2-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "ml-api:v2.3.1",
                        "cpu_request": "500m",
                        "cpu_limit": "2000m",
                        "memory_request": "1Gi",
                        "memory_limit": "4Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-20T09:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-20T09:00:05+09:00",
                            }
                        ],
                    },
                    {
                        "name": "ml-api-server-6f7b8c-def34",
                        "namespace": "ml-serving",
                        "node_name": "ip-10-0-2-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "ml-api:v2.3.1",
                        "cpu_request": "500m",
                        "cpu_limit": "2000m",
                        "memory_request": "1Gi",
                        "memory_limit": "4Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-20T09:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-20T09:00:05+09:00",
                            }
                        ],
                    },
                    {
                        "name": "feature-store-5d6e7f-ghi56",
                        "namespace": "ml-serving",
                        "node_name": "ip-10-0-2-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "feature-store:v1.8.0",
                        "cpu_request": "250m",
                        "cpu_limit": "1000m",
                        "memory_request": "512Mi",
                        "memory_limit": "2Gi",
                        "restart_count": 1,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-19T14:30:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-19T14:30:10+09:00",
                            }
                        ],
                    },
                    {
                        "name": "prometheus-0",
                        "namespace": "monitoring",
                        "node_name": "ip-10-0-3-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "prom/prometheus:v2.51.0",
                        "cpu_request": "200m",
                        "cpu_limit": "500m",
                        "memory_request": "512Mi",
                        "memory_limit": "2Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-15T10:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-15T10:00:15+09:00",
                            }
                        ],
                    },
                    {
                        "name": "grafana-7a8b9c-jkl78",
                        "namespace": "monitoring",
                        "node_name": "ip-10-0-3-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "grafana/grafana:10.3.1",
                        "cpu_request": "100m",
                        "cpu_limit": "500m",
                        "memory_request": "256Mi",
                        "memory_limit": "1Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-15T10:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-15T10:00:08+09:00",
                            }
                        ],
                    },
                    {
                        "name": "coredns-5c6d7e-mno90",
                        "namespace": "kube-system",
                        "node_name": "ip-10-0-3-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "602401143452.dkr.ecr.ap-northeast-2.amazonaws.com/eks/coredns:v1.11.1",
                        "cpu_request": "100m",
                        "cpu_limit": "100m",
                        "memory_request": "70Mi",
                        "memory_limit": "170Mi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-10T08:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-10T08:00:05+09:00",
                            }
                        ],
                    },
                    {
                        "name": "training-job-7f8d9-worker-3",
                        "namespace": "ml-training",
                        "node_name": "ip-10-0-1-102.ap-northeast-2.compute.internal",
                        "phase": "Pending",
                        "display_status": "warning",
                        "image": "ml-training:v3.1.0",
                        "cpu_request": "4000m",
                        "cpu_limit": "8000m",
                        "memory_request": "16Gi",
                        "memory_limit": "32Gi",
                        "restart_count": 0,
                        "container_state": "waiting",
                        "container_state_reason": "Unschedulable",
                        "started_at": "",
                        "conditions": [
                            {
                                "type": "PodScheduled",
                                "status": "False",
                                "reason": "Unschedulable",
                                "last_transition": "2026-03-25T15:00:00+09:00",
                            }
                        ],
                    },
                    {
                        "name": "training-job-7f8d9-worker-4",
                        "namespace": "ml-training",
                        "node_name": "",
                        "phase": "Pending",
                        "display_status": "warning",
                        "image": "ml-training:v3.1.0",
                        "cpu_request": "4000m",
                        "cpu_limit": "8000m",
                        "memory_request": "16Gi",
                        "memory_limit": "32Gi",
                        "restart_count": 0,
                        "container_state": "waiting",
                        "container_state_reason": "Unschedulable",
                        "started_at": "",
                        "conditions": [
                            {
                                "type": "PodScheduled",
                                "status": "False",
                                "reason": "Unschedulable",
                                "last_transition": "2026-03-25T15:00:00+09:00",
                            }
                        ],
                    },
                ],
            },
            "deployments": [
                {
                    "name": "ml-api-server",
                    "namespace": "ml-serving",
                    "replicas": 3,
                    "available": 3,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "feature-store",
                    "namespace": "ml-serving",
                    "replicas": 2,
                    "available": 2,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "model-registry",
                    "namespace": "ml-serving",
                    "replicas": 2,
                    "available": 2,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "prometheus",
                    "namespace": "monitoring",
                    "replicas": 1,
                    "available": 1,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "grafana",
                    "namespace": "monitoring",
                    "replicas": 1,
                    "available": 1,
                    "unavailable": 0,
                    "display_status": "ok",
                },
            ],
            "events": [
                {
                    "type": "Warning",
                    "reason": "FailedScheduling",
                    "message": "0/12 nodes are available: insufficient gpu",
                    "involved_object": "training-job-7f8d9-worker-3",
                    "involved_kind": "Pod",
                    "namespace": "ml-training",
                    "count": 3,
                    "source": "default-scheduler",
                    "last_timestamp": "2026-03-25T15:00:00+09:00",
                },
                {
                    "type": "Warning",
                    "reason": "FailedScheduling",
                    "message": "0/12 nodes are available: insufficient gpu",
                    "involved_object": "training-job-7f8d9-worker-4",
                    "involved_kind": "Pod",
                    "namespace": "ml-training",
                    "count": 3,
                    "source": "default-scheduler",
                    "last_timestamp": "2026-03-25T15:00:00+09:00",
                },
                {
                    "type": "Normal",
                    "reason": "Scheduled",
                    "message": "Successfully assigned ml-serving/ml-api-server-6f7b8c-abc12",
                    "involved_object": "ml-api-server-6f7b8c-abc12",
                    "involved_kind": "Pod",
                    "namespace": "ml-serving",
                    "count": 1,
                    "source": "default-scheduler",
                    "last_timestamp": "2026-03-20T09:00:00+09:00",
                },
                {
                    "type": "Warning",
                    "reason": "Unhealthy",
                    "message": "Readiness probe failed: connection refused",
                    "involved_object": "feature-store-5d6e7f-ghi56",
                    "involved_kind": "Pod",
                    "namespace": "ml-serving",
                    "count": 2,
                    "source": "kubelet",
                    "last_timestamp": "2026-03-19T14:30:00+09:00",
                },
            ],
            "services": [
                {
                    "name": "ml-api-server",
                    "namespace": "ml-serving",
                    "type": "LoadBalancer",
                    "cluster_ip": "172.20.10.50",
                    "ports": [{"port": 80, "target_port": 8080, "protocol": "TCP"}],
                    "selector": "app=ml-api-server",
                },
                {
                    "name": "feature-store",
                    "namespace": "ml-serving",
                    "type": "ClusterIP",
                    "cluster_ip": "172.20.10.51",
                    "ports": [{"port": 6379, "target_port": 6379, "protocol": "TCP"}],
                    "selector": "app=feature-store",
                },
                {
                    "name": "prometheus",
                    "namespace": "monitoring",
                    "type": "ClusterIP",
                    "cluster_ip": "172.20.10.60",
                    "ports": [{"port": 9090, "target_port": 9090, "protocol": "TCP"}],
                    "selector": "app=prometheus",
                },
                {
                    "name": "grafana",
                    "namespace": "monitoring",
                    "type": "NodePort",
                    "cluster_ip": "172.20.10.61",
                    "ports": [{"port": 3000, "target_port": 3000, "protocol": "TCP"}],
                    "selector": "app=grafana",
                },
                {
                    "name": "kubernetes",
                    "namespace": "default",
                    "type": "ClusterIP",
                    "cluster_ip": "172.20.0.1",
                    "ports": [{"port": 443, "target_port": 443, "protocol": "TCP"}],
                    "selector": "",
                },
            ],
        },
        "bdp-service-cluster": {
            "nodegroups": [
                {
                    "name": "app-ng",
                    "status": "ACTIVE",
                    "instance_types": ["m5.xlarge"],
                    "ami_type": "AL2_x86_64",
                    "disk_size": 50,
                    "min_size": 2,
                    "max_size": 6,
                    "desired_size": 3,
                    "labels": {"workload": "application"},
                },
                {
                    "name": "system-ng",
                    "status": "ACTIVE",
                    "instance_types": ["t3.large"],
                    "ami_type": "AL2_x86_64",
                    "disk_size": 30,
                    "min_size": 1,
                    "max_size": 3,
                    "desired_size": 2,
                    "labels": {"workload": "system"},
                },
            ],
            "nodes": [
                {
                    "name": "ip-10-1-1-101.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "4",
                    "memory_capacity": "16Gi",
                    "pod_count": 18,
                    "node_group": "app-ng",
                    "instance_type": "m5.xlarge",
                },
                {
                    "name": "ip-10-1-1-102.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "4",
                    "memory_capacity": "16Gi",
                    "pod_count": 14,
                    "node_group": "app-ng",
                    "instance_type": "m5.xlarge",
                },
                {
                    "name": "ip-10-1-2-101.ap-northeast-2.compute.internal",
                    "status": "Ready",
                    "display_status": "ok",
                    "cpu_capacity": "2",
                    "memory_capacity": "8Gi",
                    "pod_count": 10,
                    "node_group": "system-ng",
                    "instance_type": "t3.large",
                },
            ],
            "pods": {
                "namespace_summary": [
                    {"namespace": "default", "total": 3, "running": 3, "pending": 0, "failed": 0},
                    {
                        "namespace": "kube-system",
                        "total": 10,
                        "running": 10,
                        "pending": 0,
                        "failed": 0,
                    },
                    {"namespace": "bdp-api", "total": 12, "running": 12, "pending": 0, "failed": 0},
                    {
                        "namespace": "monitoring",
                        "total": 4,
                        "running": 4,
                        "pending": 0,
                        "failed": 0,
                    },
                ],
                "node_pod_counts": {
                    "ip-10-1-1-101.ap-northeast-2.compute.internal": 18,
                    "ip-10-1-1-102.ap-northeast-2.compute.internal": 14,
                    "ip-10-1-2-101.ap-northeast-2.compute.internal": 10,
                },
                "abnormal_pods": [],
                "total_count": 29,
                "items": [
                    {
                        "name": "bdp-api-5a6b7c-pqr12",
                        "namespace": "bdp-api",
                        "node_name": "ip-10-1-1-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "bdp-api:v4.2.0",
                        "cpu_request": "500m",
                        "cpu_limit": "2000m",
                        "memory_request": "1Gi",
                        "memory_limit": "4Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-18T08:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-18T08:00:10+09:00",
                            }
                        ],
                    },
                    {
                        "name": "bdp-api-5a6b7c-stu34",
                        "namespace": "bdp-api",
                        "node_name": "ip-10-1-1-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "bdp-api:v4.2.0",
                        "cpu_request": "500m",
                        "cpu_limit": "2000m",
                        "memory_request": "1Gi",
                        "memory_limit": "4Gi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-18T08:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-18T08:00:10+09:00",
                            }
                        ],
                    },
                    {
                        "name": "bdp-worker-3d4e5f-vwx56",
                        "namespace": "bdp-api",
                        "node_name": "ip-10-1-1-102.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "bdp-worker:v4.2.0",
                        "cpu_request": "250m",
                        "cpu_limit": "1000m",
                        "memory_request": "512Mi",
                        "memory_limit": "2Gi",
                        "restart_count": 2,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-18T08:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-18T08:00:12+09:00",
                            }
                        ],
                    },
                    {
                        "name": "nginx-ingress-1a2b3c-yza78",
                        "namespace": "kube-system",
                        "node_name": "ip-10-1-2-101.ap-northeast-2.compute.internal",
                        "phase": "Running",
                        "display_status": "ok",
                        "image": "nginx/nginx-ingress:3.4.0",
                        "cpu_request": "100m",
                        "cpu_limit": "500m",
                        "memory_request": "128Mi",
                        "memory_limit": "512Mi",
                        "restart_count": 0,
                        "container_state": "running",
                        "container_state_reason": "",
                        "started_at": "2026-03-10T06:00:00+09:00",
                        "conditions": [
                            {
                                "type": "Ready",
                                "status": "True",
                                "reason": "",
                                "last_transition": "2026-03-10T06:00:08+09:00",
                            }
                        ],
                    },
                ],
            },
            "deployments": [
                {
                    "name": "bdp-api",
                    "namespace": "bdp-api",
                    "replicas": 3,
                    "available": 3,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "bdp-worker",
                    "namespace": "bdp-api",
                    "replicas": 2,
                    "available": 2,
                    "unavailable": 0,
                    "display_status": "ok",
                },
                {
                    "name": "nginx-ingress",
                    "namespace": "kube-system",
                    "replicas": 2,
                    "available": 2,
                    "unavailable": 0,
                    "display_status": "ok",
                },
            ],
            "events": [
                {
                    "type": "Normal",
                    "reason": "Scheduled",
                    "message": "Successfully assigned bdp-api/bdp-api-5a6b7c-pqr12",
                    "involved_object": "bdp-api-5a6b7c-pqr12",
                    "involved_kind": "Pod",
                    "namespace": "bdp-api",
                    "count": 1,
                    "source": "default-scheduler",
                    "last_timestamp": "2026-03-18T08:00:00+09:00",
                },
            ],
            "services": [
                {
                    "name": "bdp-api",
                    "namespace": "bdp-api",
                    "type": "LoadBalancer",
                    "cluster_ip": "172.20.20.10",
                    "ports": [{"port": 80, "target_port": 8080, "protocol": "TCP"}],
                    "selector": "app=bdp-api",
                },
                {
                    "name": "nginx-ingress",
                    "namespace": "kube-system",
                    "type": "NodePort",
                    "cluster_ip": "172.20.20.20",
                    "ports": [
                        {"port": 80, "target_port": 80, "protocol": "TCP"},
                        {"port": 443, "target_port": 443, "protocol": "TCP"},
                    ],
                    "selector": "app=nginx-ingress",
                },
                {
                    "name": "kubernetes",
                    "namespace": "default",
                    "type": "ClusterIP",
                    "cluster_ip": "172.20.0.1",
                    "ports": [{"port": 443, "target_port": 443, "protocol": "TCP"}],
                    "selector": "",
                },
            ],
        },
    }
    data = _clusters.get(cluster_name, _clusters["bdp-ml-cluster"])
    # pod_restart_daily 생성: namespace_summary의 네임스페이스 목록 기반
    ns_names = [ns["namespace"] for ns in data.get("pods", {}).get("namespace_summary", [])]
    data["pod_restart_daily"] = _mock_pod_restart_daily(ns_names, cluster_name)
    return {
        "cluster_name": cluster_name,
        **data,
    }


_MOCK_FETCHERS: dict[str, Any] = {
    "mwaa": _mock_mwaa,
    "rds": _mock_rds,
    "emr(cluster)": _mock_emr_cluster,
    "emr(serverless)": _mock_emr_serverless,
    "msk": _mock_msk,
    "sagemaker endpoint": _mock_sagemaker,
    "sagemaker studio": _mock_sagemaker_studio,
    "s3": _mock_s3,
    "glue": _mock_glue,
    "lambda": _mock_lambda,
    "athena": _mock_athena,
    "eks": _mock_eks,
    "natgw": _mock_natgw,
}


class InfraService:
    """AWS 인프라 리소스 현황을 조회하는 서비스."""

    def __init__(self, settings: PortalSettings):
        self.settings = settings
        self._cache: dict[str, Any] | None = None
        self._cache_time: float = 0
        self._s3_size_cache: dict[str, tuple[float, int]] = {}  # s3_uri -> (cache_time, size_bytes)
        self._boto3_clients: dict[str, Any] = {}

    def _get_client(self, service_name: str):
        if service_name in self._boto3_clients:
            return self._boto3_clients[service_name]

        from botocore.config import Config

        from src.common.services.aws_session import get_boto3_client

        boto_config = Config(
            connect_timeout=5,
            read_timeout=10,
            retries={"max_attempts": 1},
        )

        if self.settings.environment == "test":
            import boto3

            client = boto3.client(
                service_name,
                endpoint_url="http://localhost:4566",
                region_name="ap-northeast-2",
                aws_access_key_id="test",
                aws_secret_access_key="test",
                config=boto_config,
            )
        else:
            client = get_boto3_client(
                service_name,
                region="ap-northeast-2",
                config=boto_config,
            )
        self._boto3_clients[service_name] = client
        return client

    def _get_s3_prefix_size(self, s3_location: str) -> int:
        """S3 Location 경로의 실제 크기를 list_objects_v2로 계산 (캐시 적용)."""
        if not s3_location or not s3_location.startswith("s3://"):
            return 0

        now = time.time()
        cached = self._s3_size_cache.get(s3_location)
        if cached and (now - cached[0]) < _CACHE_TTL:
            return cached[1]

        try:
            # s3://bucket/prefix 파싱
            path = s3_location[5:]  # remove "s3://"
            slash_idx = path.find("/")
            if slash_idx < 0:
                bucket = path
                prefix = ""
            else:
                bucket = path[:slash_idx]
                prefix = path[slash_idx + 1 :]

            s3_client = self._get_client("s3")
            total_size = 0
            paginator = s3_client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    total_size += obj.get("Size", 0)

            self._s3_size_cache[s3_location] = (now, total_size)
            return total_size
        except Exception as e:
            logger.debug(f"Failed to get S3 size for {s3_location}: {e}")
            return 0

    def get_dashboard_data(self) -> dict[str, Any]:
        """대시보드 데이터 조회 (5분 캐시)."""
        now = time.time()
        if self._cache and (now - self._cache_time) < _CACHE_TTL:
            return self._cache

        services: dict[str, list[dict[str, Any]]] = {}
        errors: list[str] = []

        fetchers = [
            ("mwaa", self._fetch_mwaa),
            ("rds", self._fetch_rds),
            ("emr(cluster)", self._fetch_emr_cluster),
            ("emr(serverless)", self._fetch_emr_serverless),
            ("msk", self._fetch_msk),
            ("sagemaker endpoint", self._fetch_sagemaker),
            ("sagemaker studio", self._fetch_sagemaker_studio),
            ("s3", self._fetch_s3),
            ("glue", self._fetch_glue),
            ("lambda", self._fetch_lambda),
            ("athena", self._fetch_athena),
            ("eks", self._fetch_eks),
            ("natgw", self._fetch_natgw),
        ]

        is_dev = self.settings.environment not in ("prd", "prod")

        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _run_fetcher(svc_type: str, fetcher):
            try:
                return svc_type, fetcher(), None
            except Exception as e:
                return svc_type, None, e

        with ThreadPoolExecutor(max_workers=6) as executor:
            future_map = {executor.submit(_run_fetcher, st, fn): st for st, fn in fetchers}
            try:
                for future in as_completed(future_map, timeout=30):
                    svc_type, data, err = future.result()
                    if err is None:
                        services[svc_type] = data
                    else:
                        logger.warning(f"Failed to fetch {svc_type}: {err}")
                        if is_dev and svc_type in _MOCK_FETCHERS:
                            services[svc_type] = _MOCK_FETCHERS[svc_type]()
                            logger.info(f"Using mock data for {svc_type} (dev fallback)")
                        else:
                            services[svc_type] = []
                            errors.append(f"{svc_type}: {err}")
            except TimeoutError:
                # 타임아웃된 future를 식별하여 빈 데이터로 채움
                for fut, st in future_map.items():
                    if not fut.done():
                        logger.warning(f"Timeout fetching {st} (30s exceeded)")
                        if is_dev and st in _MOCK_FETCHERS:
                            services.setdefault(st, _MOCK_FETCHERS[st]())
                        else:
                            services.setdefault(st, [])
                            errors.append(f"{st}: timeout")

        summary = self._build_summary(services)

        result = {
            "summary": summary,
            "services": services,
            "errors": errors,
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
        }

        self._cache = result
        self._cache_time = now
        return result

    def _build_summary(self, services: dict[str, list[dict[str, Any]]]) -> dict[str, int]:
        """요약 카드 데이터 생성."""
        total = 0
        running = 0
        stopped = 0
        warning = 0
        error = 0

        for resources in services.values():
            for r in resources:
                total += 1
                norm = r.get("normalized_status", "unknown")
                if norm == "running":
                    running += 1
                elif norm in ("stopped", "stopping"):
                    stopped += 1
                elif norm in ("pending", "warning"):
                    warning += 1
                elif norm == "error":
                    error += 1

        return {
            "total": total,
            "running": running,
            "stopped": stopped,
            "warning": warning,
            "error": error,
        }

    # ── MWAA ──────────────────────────────────────────

    def _fetch_mwaa(self) -> list[dict[str, Any]]:
        client = self._get_client("mwaa")
        envs = client.list_environments().get("Environments", [])
        results = []
        for name in envs:
            try:
                detail = client.get_environment(Name=name).get("Environment", {})
                raw_status = detail.get("Status", "UNKNOWN")
                norm = _normalize_status(raw_status)
                # S3 DAGs 버킷 추출
                source_bucket_arn = detail.get("SourceBucketArn", "")
                dag_s3_bucket = source_bucket_arn.split(":")[-1] if source_bucket_arn else ""
                dag_s3_path = detail.get("DagS3Path", "")
                results.append(
                    {
                        "name": name,
                        "raw_status": raw_status,
                        "normalized_status": norm,
                        "display_status": _display_status(norm),
                        "airflow_version": detail.get("AirflowVersion", "-"),
                        "environment_class": detail.get("EnvironmentClass", "-"),
                        "min_workers": detail.get("MinWorkers", "-"),
                        "max_workers": detail.get("MaxWorkers", "-"),
                        "dag_s3_bucket": dag_s3_bucket,
                        "dag_s3_path": dag_s3_path,
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to get MWAA environment {name}: {e}")
        return results

    # ── RDS ──────────────────────────────────────────

    def _fetch_rds(self) -> list[dict[str, Any]]:
        client = self._get_client("rds")
        paginator = client.get_paginator("describe_db_instances")
        results = []
        for page in paginator.paginate():
            for db in page.get("DBInstances", []):
                raw_status = db.get("DBInstanceStatus", "unknown")
                norm = _normalize_status(raw_status)
                storage = db.get("AllocatedStorage", 0)
                results.append(
                    {
                        "name": db.get("DBInstanceIdentifier", "-"),
                        "raw_status": raw_status,
                        "normalized_status": norm,
                        "display_status": _display_status(norm),
                        "engine": f"{db.get('Engine', '-')} {db.get('EngineVersion', '')}".strip(),
                        "instance_class": db.get("DBInstanceClass", "-"),
                        "storage_gb": storage,
                        "storage_type": db.get("StorageType", "gp3"),
                        "multi_az": "Yes" if db.get("MultiAZ") else "No",
                    }
                )
        return results

    # ── EMR Cluster ──────────────────────────────────

    @staticmethod
    def _extract_s3_buckets(detail: dict[str, Any]) -> list[str]:
        """EMR 클러스터 설정에서 관련 S3 버킷명을 추출한다."""
        import re

        bucket_pattern = re.compile(r"s3[an]?://([^/\s]+)")
        buckets: set[str] = set()

        # LogUri
        log_uri = detail.get("LogUri", "")
        if log_uri:
            m = bucket_pattern.search(log_uri)
            if m:
                buckets.add(m.group(1))

        # Configurations (재귀 탐색)
        def _scan_configs(configs: list) -> None:
            for cfg in configs:
                for v in cfg.get("Properties", {}).values():
                    for m in bucket_pattern.finditer(str(v)):
                        buckets.add(m.group(1))
                _scan_configs(cfg.get("Configurations", []))

        _scan_configs(detail.get("Configurations", []))

        return sorted(buckets)

    def _fetch_emr_cluster(self) -> list[dict[str, Any]]:
        client = self._get_client("emr")
        resp = client.list_clusters(
            ClusterStates=["STARTING", "BOOTSTRAPPING", "RUNNING", "WAITING", "TERMINATING"]
        )
        results = []
        for cluster_summary in resp.get("Clusters", []):
            cluster_id = cluster_summary.get("Id")
            try:
                detail = client.describe_cluster(ClusterId=cluster_id).get("Cluster", {})
                raw_status = detail.get("Status", {}).get("State", "UNKNOWN")
                norm = _normalize_status(raw_status)

                # 인스턴스 그룹 정보 (Core / Task 분리)
                core_type = "-"
                core_count = 0
                task_type = "-"
                task_count = 0
                try:
                    ig_resp = client.list_instance_groups(ClusterId=cluster_id)
                    groups = ig_resp.get("InstanceGroups", [])
                    for g in groups:
                        gtype = g.get("InstanceGroupType")
                        if gtype == "CORE":
                            core_type = g.get("InstanceType", "-")
                            core_count = g.get("RunningInstanceCount", 0)
                        elif gtype == "TASK":
                            task_type = g.get("InstanceType", "-")
                            task_count = g.get("RunningInstanceCount", 0)
                except Exception:
                    pass

                # 관련 S3 버킷 추출
                s3_buckets = self._extract_s3_buckets(detail)

                results.append(
                    {
                        "name": detail.get("Name", cluster_id),
                        "raw_status": raw_status,
                        "normalized_status": norm,
                        "display_status": _display_status(norm),
                        "release": detail.get("ReleaseLabel", "-"),
                        "core_instance_type": core_type,
                        "core_count": core_count,
                        "task_instance_type": task_type,
                        "task_count": task_count,
                        "s3_buckets": s3_buckets,
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to describe EMR cluster {cluster_id}: {e}")
        return results

    # ── EMR Serverless ───────────────────────────────

    def _fetch_emr_serverless(self) -> list[dict[str, Any]]:
        client = self._get_client("emr-serverless")
        resp = client.list_applications()
        results = []
        for app in resp.get("applications", []):
            raw_status = app.get("state", "UNKNOWN")
            norm = _normalize_status(raw_status)
            results.append(
                {
                    "name": app.get("name", app.get("id", "-")),
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "type": app.get("type", "-"),
                    "release": app.get("releaseLabel", "-"),
                }
            )
        return results

    # ── MSK ──────────────────────────────────────────

    def _fetch_msk(self) -> list[dict[str, Any]]:
        client = self._get_client("kafka")
        resp = client.list_clusters_v2()
        results = []
        for cluster in resp.get("ClusterInfoList", []):
            raw_status = cluster.get("State", "UNKNOWN")
            norm = _normalize_status(raw_status)

            # Provisioned 클러스터 정보
            provisioned = cluster.get("Provisioned", {})
            broker_info = provisioned.get("BrokerNodeGroupInfo", {})
            broker_count = provisioned.get("NumberOfBrokerNodes", "-")
            instance_type = broker_info.get("InstanceType", "-")

            # Kafka 버전
            kafka_version = cluster.get("CurrentVersion", "-")
            if provisioned:
                kafka_version = provisioned.get("CurrentBrokerSoftwareInfo", {}).get(
                    "KafkaVersion", kafka_version
                )

            # 클러스터 설정에서 default.replication.factor, min.insync.replicas 조회
            default_rf = None
            default_min_isr = None
            try:
                config_arn = provisioned.get("ConfigurationInfo", {}).get("Arn")
                if config_arn:
                    config_resp = client.describe_configuration(Arn=config_arn)
                    revision = config_resp.get("LatestRevision", {}).get("Revision")
                    if revision:
                        rev_resp = client.describe_configuration_revision(
                            Arn=config_arn, Revision=revision
                        )
                        props = rev_resp.get("ServerProperties", b"")
                        if isinstance(props, bytes):
                            props = props.decode("utf-8")
                        for line in props.splitlines():
                            line = line.strip()
                            if "=" not in line or line.startswith("#"):
                                continue
                            key, _, val = line.partition("=")
                            key, val = key.strip(), val.strip()
                            if key == "default.replication.factor":
                                default_rf = int(val)
                            elif key == "min.insync.replicas":
                                default_min_isr = int(val)
            except Exception as e:
                logger.warning(f"MSK config 조회 실패 ({cluster.get('ClusterName')}): {e}")

            results.append(
                {
                    "name": cluster.get("ClusterName", "-"),
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "kafka_version": kafka_version,
                    "broker_count": broker_count,
                    "instance_type": instance_type,
                    "cluster_default_rf": default_rf,
                    "cluster_default_min_isr": default_min_isr,
                }
            )
        return results

    # ── SageMaker Endpoints ──────────────────────────

    def _fetch_sagemaker(self) -> list[dict[str, Any]]:
        client = self._get_client("sagemaker")
        resp = client.list_endpoints()
        results = []
        for ep_summary in resp.get("Endpoints", []):
            ep_name = ep_summary.get("EndpointName")
            raw_status = ep_summary.get("EndpointStatus", "UNKNOWN")
            norm = _normalize_status(raw_status)

            # Endpoint 상세 정보
            instance_type = "-"
            instance_count = 0
            try:
                detail = client.describe_endpoint(EndpointName=ep_name)
                variants = detail.get("ProductionVariants", [])
                if variants:
                    v = variants[0]
                    instance_type = v.get("InstanceType", "-")
                    instance_count = v.get("CurrentInstanceCount", v.get("DesiredInstanceCount", 0))
            except Exception:
                pass

            results.append(
                {
                    "name": ep_name or "-",
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "instance_type": instance_type,
                    "instance_count": instance_count,
                }
            )
        return results

    # ── SageMaker Studio ─────────────────────────────

    def _fetch_sagemaker_studio(self) -> list[dict[str, Any]]:
        client = self._get_client("sagemaker")
        resp = client.list_domains()
        results = []
        for domain in resp.get("Domains", []):
            domain_name = domain.get("DomainName", "-")
            raw_status = domain.get("Status", "UNKNOWN")
            norm = _normalize_status(raw_status)
            results.append(
                {
                    "name": domain_name,
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "domain_id": domain.get("DomainId", "-"),
                    "app_type": "Studio",
                    "instance_type": "-",
                }
            )
        return results

    # ── S3 ────────────────────────────────────────────

    def _fetch_s3(self) -> list[dict[str, Any]]:
        # dev 환경: LocalStack은 S3 size/prefix 정보를 제공하지 않으므로 mock 사용
        if self.settings.environment == "test":
            return _mock_s3()

        client = self._get_client("s3")
        cw_client = self._get_client("cloudwatch")
        resp = client.list_buckets()
        results = []
        all_buckets = resp.get("Buckets", [])
        bdp_buckets = [b for b in all_buckets if "bdp" in b.get("Name", "").lower()]
        bucket_metrics = self._fetch_s3_bucket_metrics(cw_client, bdp_buckets)

        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _fetch_bucket_detail(bucket):
            name = bucket.get("Name", "-")
            try:
                ver_resp = client.get_bucket_versioning(Bucket=name)
                versioning = ver_resp.get("Status", "Disabled") or "Disabled"
                try:
                    enc_resp = client.get_bucket_encryption(Bucket=name)
                    rules = enc_resp.get("ServerSideEncryptionConfiguration", {}).get("Rules", [])
                    encryption = (
                        rules[0]
                        .get("ApplyServerSideEncryptionByDefault", {})
                        .get("SSEAlgorithm", "None")
                        if rules
                        else "None"
                    )
                except Exception:
                    encryption = "None"
                metrics = bucket_metrics.get(name, {})
                return {
                    "name": name,
                    "raw_status": "active",
                    "normalized_status": "running",
                    "display_status": "ok",
                    "bucket_size_gb": metrics.get("size_gb", 0),
                    "object_count": metrics.get("object_count", 0),
                    "versioning": versioning,
                    "encryption": encryption,
                }
            except Exception as e:
                logger.warning(f"Failed to get S3 bucket details {name}: {e}")
                return None

        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = [pool.submit(_fetch_bucket_detail, b) for b in bdp_buckets]
            for fut in as_completed(futures):
                result = fut.result()
                if result:
                    results.append(result)
        return results

    def _fetch_s3_bucket_metrics(self, cw_client, buckets: list) -> dict[str, dict]:
        """CloudWatch에서 S3 버킷별 BucketSizeBytes/NumberOfObjects 병렬 조회."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        now = datetime.now(KST)
        start_time = now - timedelta(days=2)
        result: dict[str, dict] = {}
        names = [b.get("Name", "") for b in buckets if b.get("Name")]

        def _query_one(name: str) -> tuple[str, dict]:
            try:
                size_resp = cw_client.get_metric_statistics(
                    Namespace="AWS/S3",
                    MetricName="BucketSizeBytes",
                    Dimensions=[
                        {"Name": "BucketName", "Value": name},
                        {"Name": "StorageType", "Value": "StandardStorage"},
                    ],
                    StartTime=start_time,
                    EndTime=now,
                    Period=86400,
                    Statistics=["Average"],
                )
                size_bytes = 0.0
                datapoints = size_resp.get("Datapoints", [])
                if datapoints:
                    latest = max(datapoints, key=lambda d: d["Timestamp"])
                    size_bytes = latest.get("Average", 0.0)

                count_resp = cw_client.get_metric_statistics(
                    Namespace="AWS/S3",
                    MetricName="NumberOfObjects",
                    Dimensions=[
                        {"Name": "BucketName", "Value": name},
                        {"Name": "StorageType", "Value": "AllStorageTypes"},
                    ],
                    StartTime=start_time,
                    EndTime=now,
                    Period=86400,
                    Statistics=["Average"],
                )
                obj_count = 0
                datapoints = count_resp.get("Datapoints", [])
                if datapoints:
                    latest = max(datapoints, key=lambda d: d["Timestamp"])
                    obj_count = int(latest.get("Average", 0))

                return name, {
                    "size_gb": round(size_bytes / (1024**3), 2),
                    "object_count": obj_count,
                }
            except Exception as e:
                logger.debug(f"Failed to get CloudWatch metrics for S3 bucket {name}: {e}")
                return name, {"size_gb": 0, "object_count": 0}

        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(_query_one, n): n for n in names}
            for future in as_completed(futures, timeout=15):
                try:
                    name, metrics = future.result()
                    result[name] = metrics
                except Exception:
                    result[futures[future]] = {"size_gb": 0, "object_count": 0}

        return result

    # ── Glue Catalogue ────────────────────────────────

    def _fetch_glue(self) -> list[dict[str, Any]]:
        client = self._get_client("glue")
        dbs = client.get_databases().get("DatabaseList", [])
        db_count = len(dbs)
        total_table_count = 0
        databases: list[dict[str, Any]] = []
        for db in dbs:
            db_name = db["Name"]
            db_table_count = 0
            db_size_bytes = 0
            try:
                tables = client.get_tables(DatabaseName=db_name).get("TableList", [])
                db_table_count = len(tables)
                total_table_count += db_table_count
                for tbl in tables:
                    params = tbl.get("Parameters", {})
                    db_size_bytes += int(params.get("rawDataSize", 0) or params.get("totalSize", 0))
            except Exception:
                pass
            databases.append(
                {
                    "name": db_name,
                    "table_count": db_table_count,
                    "size_bytes": db_size_bytes,
                }
            )
        return [
            {
                "name": "data-catalog",
                "raw_status": "active",
                "normalized_status": "running",
                "display_status": "ok",
                "database_count": db_count,
                "table_count": total_table_count,
                "databases": databases,
            }
        ]

    # ── Lambda ────────────────────────────────────────

    def _fetch_lambda(self) -> list[dict[str, Any]]:
        client = self._get_client("lambda")
        paginator = client.get_paginator("list_functions")
        results = []
        for page in paginator.paginate():
            for fn in page.get("Functions", []):
                raw_status = fn.get("State", "Active")
                norm = _normalize_status(raw_status)
                concurrency = None
                try:
                    cc = client.get_function_concurrency(FunctionName=fn["FunctionName"])
                    concurrency = cc.get("ReservedConcurrentExecutions")
                except Exception:
                    pass
                results.append(
                    {
                        "name": fn.get("FunctionName", "-"),
                        "raw_status": raw_status,
                        "normalized_status": norm,
                        "display_status": _display_status(norm),
                        "runtime": fn.get("Runtime", "-"),
                        "memory_mb": fn.get("MemorySize", 0),
                        "timeout_sec": fn.get("Timeout", 0),
                        "reserved_concurrency": concurrency,
                    }
                )
        return results

    # ── Athena ────────────────────────────────────────

    def _fetch_athena(self) -> list[dict[str, Any]]:
        client = self._get_client("athena")
        resp = client.list_work_groups()
        results = []
        for wg_summary in resp.get("WorkGroups", []):
            wg_name = wg_summary.get("Name", "-")
            raw_status = wg_summary.get("State", "UNKNOWN")
            norm = _normalize_status(raw_status)
            engine_version = "-"
            result_location = "-"
            bytes_limit = None
            additional_cfg: dict[str, Any] = {}
            try:
                detail = client.get_work_group(WorkGroup=wg_name).get("WorkGroup", {})
                cfg = detail.get("Configuration", {})
                engine_version = cfg.get("EngineVersion", {}).get("EffectiveEngineVersion", "-")
                result_cfg = cfg.get("ResultConfiguration", {})
                result_location = result_cfg.get("OutputLocation", "-")
                bytes_limit = cfg.get("BytesScannedCutoffPerQuery")
                raw_additional = cfg.get("AdditionalConfiguration", "")
                if raw_additional:
                    import json

                    try:
                        additional_cfg = json.loads(raw_additional)
                    except (json.JSONDecodeError, TypeError):
                        pass
            except Exception:
                pass
            # Athena engine version → 번들된 Apache Iceberg 라이브러리 버전 매핑
            # https://docs.aws.amazon.com/athena/latest/ug/querying-iceberg.html
            iceberg_version = None
            if "3" in engine_version:
                iceberg_version = "1.4.2"

            # 워크그룹별 런타임 쿼리 메트릭
            running_queries = 0
            queued_queries = 0
            recent_success_rate: float | None = None
            recent_scanned_gb: float | None = None
            try:
                query_ids: list[str] = []
                exec_resp = client.list_query_executions(
                    WorkGroup=wg_name,
                    MaxResults=50,
                )
                query_ids = exec_resp.get("QueryExecutionIds", [])

                if query_ids:
                    batch_resp = client.batch_get_query_execution(
                        QueryExecutionIds=query_ids,
                    )
                    executions = batch_resp.get("QueryExecutions", [])
                    one_hour_ago = datetime.now(KST).timestamp() - 3600

                    succeeded = 0
                    completed_total = 0
                    scanned_bytes = 0

                    for exe in executions:
                        state = exe.get("Status", {}).get("State", "")
                        if state == "RUNNING":
                            running_queries += 1
                        elif state == "QUEUED":
                            queued_queries += 1

                        # 최근 1시간 완료 쿼리 통계
                        completion_dt = exe.get("Status", {}).get("CompletionDateTime")
                        if completion_dt and state in ("SUCCEEDED", "FAILED", "CANCELLED"):
                            ts = (
                                completion_dt.timestamp()
                                if hasattr(completion_dt, "timestamp")
                                else 0
                            )
                            if ts >= one_hour_ago:
                                completed_total += 1
                                if state == "SUCCEEDED":
                                    succeeded += 1
                                stats = exe.get("Statistics", {})
                                scanned_bytes += stats.get("DataScannedInBytes", 0)

                    if completed_total > 0:
                        recent_success_rate = round(succeeded / completed_total * 100, 1)
                        recent_scanned_gb = round(scanned_bytes / (1024**3), 1)
            except Exception as e:
                logger.debug(f"Failed to fetch query metrics for {wg_name}: {e}")

            results.append(
                {
                    "name": wg_name,
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "engine_version": engine_version,
                    "result_location": result_location,
                    "bytes_scanned_limit": bytes_limit,
                    "iceberg_version": iceberg_version,
                    "additional_configuration": additional_cfg,
                    "running_queries": running_queries,
                    "queued_queries": queued_queries,
                    "recent_success_rate": recent_success_rate,
                    "recent_scanned_gb": recent_scanned_gb,
                }
            )
        return results

    # ── EKS ───────────────────────────────────────────

    def _fetch_eks(self) -> list[dict[str, Any]]:
        client = self._get_client("eks")
        clusters = client.list_clusters().get("clusters", [])
        results = []
        for cluster_name in clusters:
            try:
                detail = client.describe_cluster(name=cluster_name).get("cluster", {})
                raw_status = detail.get("status", "UNKNOWN")
                norm = _normalize_status(raw_status)
                node_group_count = 0
                total_nodes = 0
                try:
                    ng_resp = client.list_nodegroups(clusterName=cluster_name)
                    ng_names = ng_resp.get("nodegroups", [])
                    node_group_count = len(ng_names)
                    for ng_name in ng_names:
                        ng_detail = client.describe_nodegroup(
                            clusterName=cluster_name, nodegroupName=ng_name
                        ).get("nodegroup", {})
                        scaling = ng_detail.get("scalingConfig", {})
                        total_nodes += scaling.get("desiredSize", 0)
                except Exception:
                    pass
                results.append(
                    {
                        "name": cluster_name,
                        "raw_status": raw_status,
                        "normalized_status": norm,
                        "display_status": _display_status(norm),
                        "kubernetes_version": detail.get("version", "-"),
                        "node_group_count": node_group_count,
                        "total_nodes": total_nodes,
                        "platform_version": detail.get("platformVersion", "-"),
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to describe EKS cluster {cluster_name}: {e}")
        return results

    # ── EKS Detail ─────────────────────────────────────

    def _get_eks_bearer_token(self, cluster_name: str) -> str:
        """EKS 클러스터 인증용 bearer token 생성 (STS presigned URL 방식)."""
        import base64

        from botocore.signers import RequestSigner

        from src.common.services.aws_session import get_botocore_session

        region = "ap-northeast-2"
        session = get_botocore_session(region=region)
        sts_client = session.create_client("sts", region_name=region)
        service_id = sts_client.meta.service_model.service_id

        signer = RequestSigner(
            service_id,
            region,
            "sts",
            "v4",
            session.get_credentials(),
            session.get_component("event_emitter"),
        )

        params = {
            "method": "GET",
            "url": f"https://sts.{region}.amazonaws.com/?Action=GetCallerIdentity&Version=2011-06-15",
            "body": {},
            "headers": {"x-k8s-aws-id": cluster_name},
            "context": {},
        }

        signed_url = signer.generate_presigned_url(
            params, region_name=region, expires_in=60, operation_name=""
        )

        return "k8s-aws-v1." + base64.urlsafe_b64encode(signed_url.encode("utf-8")).rstrip(
            b"="
        ).decode("utf-8")

    def _get_eks_k8s_clients(self, cluster_name: str):
        """EKS 클러스터에 연결된 K8s API 클라이언트(CoreV1Api, AppsV1Api) 반환."""
        import base64
        import tempfile

        from kubernetes import client as k8s_client

        eks_client = self._get_client("eks")
        cluster_info = eks_client.describe_cluster(name=cluster_name).get("cluster", {})
        endpoint = cluster_info.get("endpoint")
        ca_data = cluster_info.get("certificateAuthority", {}).get("data", "")

        ca_file = tempfile.NamedTemporaryFile(delete=False, suffix=".crt")
        ca_file.write(base64.b64decode(ca_data))
        ca_file.close()

        token = self._get_eks_bearer_token(cluster_name)

        configuration = k8s_client.Configuration()
        configuration.host = endpoint
        configuration.ssl_ca_cert = ca_file.name
        configuration.api_key = {"authorization": f"Bearer {token}"}

        api_client = k8s_client.ApiClient(configuration)
        return k8s_client.CoreV1Api(api_client), k8s_client.AppsV1Api(api_client)

    def get_eks_detail(self, cluster_name: str) -> dict[str, Any]:
        """EKS 클러스터의 상세 리소스 조회 (nodegroup + K8s node/pod/deployment)."""
        is_dev = self.settings.environment not in ("prd", "prod")
        result: dict[str, Any] = {
            "cluster_name": cluster_name,
            "nodegroups": [],
            "nodes": [],
            "pods": {
                "namespace_summary": [],
                "node_pod_counts": {},
                "abnormal_pods": [],
                "total_count": 0,
                "items": [],
            },
            "deployments": [],
            "events": [],
            "services": [],
            "pod_restart_daily": {"namespaces": {}},
            "pod_resources": {"node_groups": {}},
            "node_resources": {"node_groups": {}},
            "event_trends": {"node_groups": {}},
        }
        try:
            result["nodegroups"] = self._fetch_eks_nodegroups(cluster_name)
        except Exception as e:
            logger.warning("EKS nodegroup 조회 실패: %s", e)
        if is_dev and not result["nodegroups"]:
            mock = _mock_eks_detail(cluster_name)
            result["nodegroups"] = mock["nodegroups"]
            logger.info("Using mock nodegroups for %s (dev fallback)", cluster_name)
        try:
            if self.settings.environment == "test":
                from kubernetes import client, config

                try:
                    config.load_incluster_config()
                except Exception:
                    config.load_kube_config()
                core_v1 = client.CoreV1Api()
                apps_v1 = client.AppsV1Api()
            else:
                core_v1, apps_v1 = self._get_eks_k8s_clients(cluster_name)
            result["nodes"] = self._fetch_k8s_nodes(core_v1)
            result["pods"] = self._fetch_k8s_pods(core_v1)
            result["deployments"] = self._fetch_k8s_deployments(apps_v1)
            result["events"] = self._fetch_k8s_events(core_v1)
            result["services"] = self._fetch_k8s_services(core_v1)
        except Exception as e:
            logger.warning("K8s API 조회 실패: %s", e)
            if is_dev:
                mock = _mock_eks_detail(cluster_name)
                result["nodes"] = mock["nodes"]
                result["pods"] = mock["pods"]
                result["deployments"] = mock["deployments"]
                result["events"] = mock.get("events", [])
                result["services"] = mock.get("services", [])
                logger.info("Using mock K8s data for %s (dev fallback)", cluster_name)
        # Pod restart 일별 추이 (CloudWatch Container Insights)
        try:
            result["pod_restart_daily"] = self._fetch_pod_restart_daily(cluster_name)
        except Exception as e:
            logger.warning("Pod restart daily 조회 실패: %s", e)
            if is_dev:
                ns_names = [ns["namespace"] for ns in result["pods"].get("namespace_summary", [])]
                result["pod_restart_daily"] = _mock_pod_restart_daily(ns_names, cluster_name)
                logger.info("Using mock pod_restart_daily for %s (dev fallback)", cluster_name)
        # 리소스 사용 추이 (CloudWatch Container Insights)
        if is_dev:
            pr, nr, et = _mock_eks_resource_metrics(result, cluster_name)
            result["pod_resources"] = pr
            result["node_resources"] = nr
            result["event_trends"] = et
        return result

    def get_eks_pod_logs(
        self, cluster_name: str, namespace: str, pod_name: str, tail_lines: int = 200
    ) -> dict[str, Any]:
        """EKS 클러스터 Pod 로그 조회."""
        is_dev = self.settings.environment not in ("prd", "prod")
        try:
            if self.settings.environment == "test":
                from kubernetes import client, config

                try:
                    config.load_incluster_config()
                except Exception:
                    config.load_kube_config()
                core_v1 = client.CoreV1Api()
            else:
                core_v1, _ = self._get_eks_k8s_clients(cluster_name)
            logs = core_v1.read_namespaced_pod_log(
                name=pod_name,
                namespace=namespace,
                tail_lines=tail_lines,
            )
            return {"pod_name": pod_name, "namespace": namespace, "logs": logs}
        except Exception as e:
            logger.warning("Pod 로그 조회 실패 (%s/%s): %s", namespace, pod_name, e)
            if is_dev:
                return {
                    "pod_name": pod_name,
                    "namespace": namespace,
                    "logs": f"[mock] {pod_name} 로그 (dev fallback)\n2026-03-25T10:00:00Z INFO  Starting application...\n2026-03-25T10:00:01Z INFO  Listening on :8080\n2026-03-25T10:00:05Z INFO  Health check passed\n",
                }
            raise

    def _fetch_pod_restart_daily(self, cluster_name: str, days: int = 31) -> dict[str, Any]:
        """CloudWatch Container Insights에서 네임스페이스별 일별 Pod 리스타트 횟수 조회."""
        from collections import defaultdict

        cw = self._get_client("cloudwatch")
        end_time = datetime.now(KST)
        start_time = end_time - timedelta(days=days)

        # 네임스페이스별 일별 리스타트 합계 조회
        response = cw.get_metric_data(
            MetricDataQueries=[
                {
                    "Id": "restarts",
                    "MetricStat": {
                        "Metric": {
                            "Namespace": "ContainerInsights",
                            "MetricName": "pod_number_of_container_restarts",
                            "Dimensions": [
                                {"Name": "ClusterName", "Value": cluster_name},
                            ],
                        },
                        "Period": 86400,  # 1일
                        "Stat": "Sum",
                    },
                }
            ],
            StartTime=start_time,
            EndTime=end_time,
        )

        # 날짜별 집계
        ns_data: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for result_item in response.get("MetricDataResults", []):
            timestamps = result_item.get("Timestamps", [])
            values = result_item.get("Values", [])
            for ts, val in zip(timestamps, values):
                date_str = ts.strftime("%Y-%m-%d") if hasattr(ts, "strftime") else str(ts)[:10]
                ns_data["cluster_total"].append({"date": date_str, "count": int(val)})

        # 날짜순 정렬
        for ns in ns_data:
            ns_data[ns].sort(key=lambda x: x["date"])

        return {"namespaces": dict(ns_data)}

    def _fetch_eks_nodegroups(self, cluster_name: str) -> list[dict[str, Any]]:
        """EKS 노드그룹 상세 정보 조회."""
        client = self._get_client("eks")
        results = []
        try:
            ng_names = client.list_nodegroups(clusterName=cluster_name).get("nodegroups", [])
            for ng_name in ng_names:
                ng = client.describe_nodegroup(clusterName=cluster_name, nodegroupName=ng_name).get(
                    "nodegroup", {}
                )
                scaling = ng.get("scalingConfig", {})
                results.append(
                    {
                        "name": ng_name,
                        "status": ng.get("status", "UNKNOWN"),
                        "instance_types": ng.get("instanceTypes", []),
                        "ami_type": ng.get("amiType", "-"),
                        "disk_size": ng.get("diskSize", 0),
                        "min_size": scaling.get("minSize", 0),
                        "max_size": scaling.get("maxSize", 0),
                        "desired_size": scaling.get("desiredSize", 0),
                        "labels": ng.get("labels", {}),
                    }
                )
        except Exception as e:
            logger.warning("EKS nodegroup 조회 실패 (%s): %s", cluster_name, e)
        return results

    def _fetch_k8s_nodes(self, core_v1) -> list[dict[str, Any]]:
        """K8s 노드 목록 조회. 파드 수는 별도 API 없이 pods 결과에서 집계."""
        node_list = core_v1.list_node()
        results = []
        for node in node_list.items:
            status = "Unknown"
            for condition in node.status.conditions or []:
                if condition.type == "Ready":
                    status = "Ready" if condition.status == "True" else "NotReady"
                    break

            labels = node.metadata.labels or {}
            node_group = labels.get("eks.amazonaws.com/nodegroup", "")
            instance_type = labels.get("node.kubernetes.io/instance-type", "")
            capacity = node.status.capacity or {}
            allocatable = node.status.allocatable or {}

            results.append(
                {
                    "name": node.metadata.name,
                    "status": status,
                    "display_status": "ok" if status == "Ready" else "warning",
                    "cpu_capacity": capacity.get("cpu", "0"),
                    "memory_capacity": allocatable.get("memory", "0"),
                    "pod_count": 0,  # 프론트에서 pods 데이터로 집계
                    "node_group": node_group,
                    "instance_type": instance_type,
                }
            )
        return results

    def _fetch_k8s_pods(self, core_v1) -> dict[str, Any]:
        """K8s 파드 요약 + 개별 상세 조회."""
        pod_list = core_v1.list_pod_for_all_namespaces()

        ns_summary: dict[str, dict[str, int]] = {}
        node_pod_counts: dict[str, int] = {}
        abnormal_pods: list[dict[str, Any]] = []
        items: list[dict[str, Any]] = []

        for pod in pod_list.items:
            phase = pod.status.phase or "Unknown"
            if phase == "Succeeded":
                continue

            ns = pod.metadata.namespace
            if ns not in ns_summary:
                ns_summary[ns] = {"total": 0, "running": 0, "pending": 0, "failed": 0}
            ns_summary[ns]["total"] += 1

            node_name = pod.spec.node_name or ""
            if node_name:
                node_pod_counts[node_name] = node_pod_counts.get(node_name, 0) + 1

            restart_count = 0
            container_state = "unknown"
            container_state_reason = ""
            image = ""
            if pod.status.container_statuses:
                cs = pod.status.container_statuses[0]
                restart_count = cs.restart_count or 0
                image = cs.image or ""
                if cs.state:
                    if cs.state.running:
                        container_state = "running"
                    elif cs.state.waiting:
                        container_state = "waiting"
                        container_state_reason = cs.state.waiting.reason or ""
                    elif cs.state.terminated:
                        container_state = "terminated"
                        container_state_reason = cs.state.terminated.reason or ""
            elif pod.spec.containers:
                image = pod.spec.containers[0].image or ""

            # 리소스 request/limit
            cpu_request = cpu_limit = memory_request = memory_limit = ""
            if pod.spec.containers:
                c = pod.spec.containers[0]
                res = c.resources or type("R", (), {"requests": None, "limits": None})()
                if res.requests:
                    cpu_request = res.requests.get("cpu", "")
                    memory_request = res.requests.get("memory", "")
                if res.limits:
                    cpu_limit = res.limits.get("cpu", "")
                    memory_limit = res.limits.get("memory", "")

            # conditions
            conditions = []
            for cond in pod.status.conditions or []:
                conditions.append(
                    {
                        "type": cond.type,
                        "status": cond.status,
                        "reason": cond.reason or "",
                        "last_transition": cond.last_transition_time.isoformat()
                        if cond.last_transition_time
                        else "",
                    }
                )

            display_status = "ok"
            if phase == "Running":
                ns_summary[ns]["running"] += 1
                if restart_count >= 5:
                    display_status = "warning"
            elif phase == "Pending":
                ns_summary[ns]["pending"] += 1
                display_status = "warning"
            elif phase in ("Failed", "Unknown"):
                ns_summary[ns]["failed"] += 1
                display_status = "critical"

            pod_item = {
                "name": pod.metadata.name,
                "namespace": ns,
                "node_name": node_name,
                "phase": phase,
                "display_status": display_status,
                "image": image,
                "cpu_request": cpu_request,
                "cpu_limit": cpu_limit,
                "memory_request": memory_request,
                "memory_limit": memory_limit,
                "restart_count": restart_count,
                "container_state": container_state,
                "container_state_reason": container_state_reason,
                "started_at": pod.status.start_time.isoformat() if pod.status.start_time else "",
                "conditions": conditions,
            }
            items.append(pod_item)

            if display_status != "ok":
                abnormal_pods.append(
                    {
                        "name": pod.metadata.name,
                        "namespace": ns,
                        "node_name": node_name,
                        "phase": phase,
                        "display_status": display_status,
                        "restart_count": restart_count,
                    }
                )

        return {
            "namespace_summary": [
                {"namespace": ns, **counts} for ns, counts in sorted(ns_summary.items())
            ],
            "node_pod_counts": node_pod_counts,
            "abnormal_pods": abnormal_pods,
            "total_count": sum(c["total"] for c in ns_summary.values()),
            "items": items,
        }

    def _fetch_k8s_events(self, core_v1) -> list[dict[str, Any]]:
        """K8s 이벤트 목록 조회 (Warning 타입 중심)."""
        event_list = core_v1.list_event_for_all_namespaces()
        results = []
        for ev in event_list.items:
            results.append(
                {
                    "type": ev.type or "Normal",
                    "reason": ev.reason or "",
                    "message": ev.message or "",
                    "involved_object": ev.involved_object.name if ev.involved_object else "",
                    "involved_kind": ev.involved_object.kind if ev.involved_object else "",
                    "namespace": ev.metadata.namespace or "",
                    "count": ev.count or 1,
                    "source": ev.source.component if ev.source else "",
                    "last_timestamp": ev.last_timestamp.isoformat() if ev.last_timestamp else "",
                }
            )
        return results

    def _fetch_k8s_services(self, core_v1) -> list[dict[str, Any]]:
        """K8s 서비스 목록 조회."""
        svc_list = core_v1.list_service_for_all_namespaces()
        results = []
        for svc in svc_list.items:
            ports = []
            for p in svc.spec.ports or []:
                ports.append(
                    {
                        "port": p.port,
                        "target_port": p.target_port if isinstance(p.target_port, int) else 0,
                        "protocol": p.protocol or "TCP",
                    }
                )
            selector_parts = []
            for k, v in (svc.spec.selector or {}).items():
                selector_parts.append(f"{k}={v}")
            results.append(
                {
                    "name": svc.metadata.name,
                    "namespace": svc.metadata.namespace or "",
                    "type": svc.spec.type or "ClusterIP",
                    "cluster_ip": svc.spec.cluster_ip or "",
                    "ports": ports,
                    "selector": ",".join(selector_parts),
                }
            )
        return results

    def _fetch_k8s_deployments(self, apps_v1) -> list[dict[str, Any]]:
        """K8s 디플로이먼트 목록 조회."""
        deploy_list = apps_v1.list_deployment_for_all_namespaces()
        results = []
        for deploy in deploy_list.items:
            replicas = deploy.spec.replicas or 0
            available = deploy.status.available_replicas or 0
            unavailable = deploy.status.unavailable_replicas or 0

            if unavailable > 0:
                display = "warning" if available > 0 else "critical"
            else:
                display = "ok"

            results.append(
                {
                    "name": deploy.metadata.name,
                    "namespace": deploy.metadata.namespace,
                    "replicas": replicas,
                    "available": available,
                    "unavailable": unavailable,
                    "display_status": display,
                }
            )
        return results

    # ── NAT Gateway ─────────────────────────────────────

    def _fetch_natgw(self) -> list[dict[str, Any]]:
        client = self._get_client("ec2")
        resp = client.describe_nat_gateways(
            Filter=[{"Name": "state", "Values": ["pending", "available", "failed", "deleting"]}],
        )
        results = []
        for ngw in resp.get("NatGateways", []):
            raw_status = ngw.get("State", "unknown")
            norm = _normalize_status(raw_status)
            public_ip = ""
            private_ip = ""
            for addr in ngw.get("NatGatewayAddresses", []):
                public_ip = public_ip or addr.get("PublicIp", "")
                private_ip = private_ip or addr.get("PrivateIp", "")
            tag_name = ""
            for tag in ngw.get("Tags", []):
                if tag.get("Key") == "Name":
                    tag_name = tag.get("Value", "")
                    break
            results.append(
                {
                    "name": ngw.get("NatGatewayId", "-"),
                    "raw_status": raw_status,
                    "normalized_status": norm,
                    "display_status": _display_status(norm),
                    "subnet_id": ngw.get("SubnetId", "-"),
                    "vpc_id": ngw.get("VpcId", "-"),
                    "public_ip": public_ip,
                    "private_ip": private_ip,
                    "connectivity_type": ngw.get("ConnectivityType", "public"),
                    "az": ngw.get("SubnetId", "-"),  # AZ는 subnet에서 유추
                    "tag_name": tag_name,
                }
            )
        return results

    # ── SageMaker Pipeline Executions ─────────────────

    def get_sagemaker_pipeline_executions(
        self,
        domain_name: str | None = None,
        status: str | None = None,
        search: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> dict[str, Any]:
        """파이프라인 실행 이력 검색 (페이지네이션 + 필터)."""
        data = self.get_dashboard_data()
        studios = data.get("services", {}).get("sagemaker studio", [])

        if domain_name:
            domain = next((s for s in studios if s.get("name") == domain_name), None)
            domains = [domain] if domain else []
        else:
            domains = studios

        executions: list[dict[str, Any]] = []
        for d in domains:
            for e in d.get("pipeline_executions", []):
                entry = {**e, "domain_name": d.get("name", "")}
                executions.append(entry)

        # status 필터
        if status:
            executions = [e for e in executions if e.get("status") == status]

        # search 필터 (pipeline_name 부분 일치)
        if search:
            q = search.lower()
            executions = [e for e in executions if q in e.get("pipeline_name", "").lower()]

        total = len(executions)
        start = (page - 1) * limit
        end = start + limit
        items = executions[start:end]

        return {"items": items, "total": total, "page": page, "limit": limit}

    # ── RDS Tables / Schema ────────────────────────────

    def get_rds_tables(self, instance_name: str) -> list[dict[str, Any]]:
        """RDS 인스턴스의 테이블 목록 조회."""
        is_dev = self.settings.environment not in ("prd", "prod")
        if is_dev:
            return _mock_rds_tables(instance_name)
        # prod: RDS Data API 또는 직접 연결이 필요하므로 mock 우선
        return _mock_rds_tables(instance_name)

    def get_rds_table_schema(
        self,
        instance_name: str,
        table_name: str,
    ) -> dict[str, Any]:
        """RDS 테이블 스키마(컬럼/인덱스 정의) 조회."""
        is_dev = self.settings.environment not in ("prd", "prod")
        if is_dev:
            return _mock_rds_table_schema(instance_name, table_name)
        return _mock_rds_table_schema(instance_name, table_name)

    # ── Glue Tables / Schema ───────────────────────────

    def get_glue_tables(self, catalog_name: str, database_name: str) -> list[dict[str, Any]]:
        """Glue 카탈로그의 특정 DB 테이블 목록 조회."""
        is_dev = self.settings.environment not in ("prd", "prod")
        try:
            client = self._get_client("glue")
            kwargs: dict[str, str] = {"DatabaseName": database_name}
            if catalog_name and catalog_name != "data-catalog":
                kwargs["CatalogId"] = catalog_name
            tables = client.get_tables(**kwargs).get("TableList", [])
            results = []
            s3_targets: list[tuple[int, str]] = []  # (index, location)
            for tbl in tables:
                params = tbl.get("Parameters", {})
                size_bytes = int(params.get("rawDataSize", 0) or params.get("totalSize", 0))
                location = tbl.get("StorageDescriptor", {}).get("Location", "")
                row_count = int(params.get("recordCount", 0) or 0)
                is_iceberg = params.get("table_type", "").upper() == "ICEBERG"
                entry: dict[str, Any] = {
                    "name": tbl["Name"],
                    "table_type": tbl.get("TableType", "EXTERNAL_TABLE"),
                    "is_iceberg": is_iceberg,
                    "size_bytes": size_bytes,
                    "row_count": row_count,
                    "columns": len(tbl.get("StorageDescriptor", {}).get("Columns", [])),
                    "partition_keys": len(tbl.get("PartitionKeys", [])),
                    "location": location,
                    "input_format": tbl.get("StorageDescriptor", {}).get("InputFormat", ""),
                    "updated_at": tbl.get("UpdateTime", ""),
                }
                if is_iceberg:
                    entry["iceberg_format"] = params.get("format-version", "")
                results.append(entry)
                if size_bytes == 0 and location:
                    s3_targets.append((len(results) - 1, location))

            # S3 size 병렬 조회 (타임아웃 시 완료분만 반영)
            if s3_targets:
                from concurrent.futures import ThreadPoolExecutor, as_completed

                with ThreadPoolExecutor(max_workers=8) as pool:
                    futures = {
                        pool.submit(self._get_s3_prefix_size, loc): idx for idx, loc in s3_targets
                    }
                    try:
                        for fut in as_completed(futures, timeout=20):
                            try:
                                results[futures[fut]]["size_bytes"] = fut.result()
                            except Exception:
                                pass
                    except TimeoutError:
                        logger.warning(
                            "S3 size 조회 타임아웃: %d/%d 완료",
                            len(s3_targets) - len([f for f in futures if not f.done()]),
                            len(s3_targets),
                        )

            return results
        except Exception as e:
            logger.warning(f"Failed to get Glue tables {catalog_name}/{database_name}: {e}")
            if is_dev:
                return _mock_glue_tables(catalog_name, database_name)
            return []

    def get_glue_table_schema(
        self,
        catalog_name: str,
        database_name: str,
        table_name: str,
    ) -> dict[str, Any]:
        """Glue 테이블 스키마(컬럼 정의) 조회."""
        is_dev = self.settings.environment not in ("prd", "prod")
        try:
            client = self._get_client("glue")
            tbl = client.get_table(DatabaseName=database_name, Name=table_name).get("Table", {})
            sd = tbl.get("StorageDescriptor", {})
            columns = [
                {"name": c["Name"], "type": c["Type"], "comment": c.get("Comment", "")}
                for c in sd.get("Columns", [])
            ]
            partition_keys = [
                {"name": p["Name"], "type": p["Type"], "comment": p.get("Comment", "")}
                for p in tbl.get("PartitionKeys", [])
            ]
            params = tbl.get("Parameters", {})
            is_iceberg = params.get("table_type", "").upper() == "ICEBERG"
            result: dict[str, Any] = {
                "name": table_name,
                "database": database_name,
                "table_type": tbl.get("TableType", ""),
                "is_iceberg": is_iceberg,
                "columns": columns,
                "partition_keys": partition_keys,
                "location": sd.get("Location", ""),
                "input_format": sd.get("InputFormat", ""),
                "output_format": sd.get("OutputFormat", ""),
                "serde": sd.get("SerdeInfo", {}).get("SerializationLibrary", ""),
                "size_bytes": int(params.get("rawDataSize", 0) or params.get("totalSize", 0))
                or self._get_s3_prefix_size(sd.get("Location", "")),
                "row_count": int(params.get("recordCount", 0) or 0),
                "created_at": str(tbl.get("CreateTime", "")),
                "updated_at": str(tbl.get("UpdateTime", "")),
            }
            if is_iceberg:
                snap_ts = params.get("current-snapshot-timestamp-ms", "")
                result["iceberg"] = {
                    "format_version": params.get("format-version", ""),
                    "table_uuid": params.get("uuid", ""),
                    "metadata_location": params.get("metadata_location", ""),
                    "current_snapshot_id": params.get("current-snapshot-id", ""),
                    "current_snapshot_ts": (
                        datetime.fromtimestamp(int(snap_ts) / 1000).isoformat() if snap_ts else ""
                    ),
                    "snapshot_operation": params.get("current-snapshot-summary.operation", ""),
                    "num_files": int(params.get("numFiles", 0) or 0),
                    "total_size": int(params.get("totalSize", 0) or 0),
                    "write_format": params.get("write.format.default", ""),
                    "compression": params.get("write.parquet.compression-codec", ""),
                }
            return result
        except Exception as e:
            logger.warning(f"Failed to get Glue table schema {database_name}/{table_name}: {e}")
            if is_dev:
                return _mock_glue_table_schema(catalog_name, database_name, table_name)
            return {}

    # ── S3 Prefix listing ─────────────────────────────

    def get_s3_prefixes(
        self,
        bucket_name: str,
        prefix: str = "",
    ) -> list[dict[str, Any]]:
        """S3 버킷의 특정 prefix 하위 디렉토리 목록 조회."""
        # prod: S3 ListObjectsV2 연동이 필요하므로 mock 우선
        return _mock_s3_prefixes(bucket_name, prefix)


# ── S3 prefix detail mock data ─────────────────────────

_MOCK_S3_PREFIXES: dict[str, dict[str, list[dict[str, Any]]]] = {
    "bdp-raw-data": {
        "clickstream/": [
            {"prefix": "2025/", "size_gb": 340, "object_count": 2_100_000},
            {"prefix": "2024/", "size_gb": 520, "object_count": 3_500_000},
            {"prefix": "2023/", "size_gb": 120, "object_count": 600_000},
        ],
        "clickstream/2025/": [
            {"prefix": "01/", "size_gb": 55, "object_count": 350_000},
            {"prefix": "02/", "size_gb": 62, "object_count": 380_000},
            {"prefix": "03/", "size_gb": 58, "object_count": 360_000},
        ],
        "clickstream/2024/": [
            {"prefix": "Q1/", "size_gb": 120, "object_count": 800_000},
            {"prefix": "Q2/", "size_gb": 130, "object_count": 870_000},
            {"prefix": "Q3/", "size_gb": 135, "object_count": 900_000},
            {"prefix": "Q4/", "size_gb": 135, "object_count": 930_000},
        ],
        "app-logs/": [
            {"prefix": "production/", "size_gb": 380, "object_count": 2_500_000},
            {"prefix": "staging/", "size_gb": 150, "object_count": 1_000_000},
            {"prefix": "development/", "size_gb": 90, "object_count": 600_000},
        ],
        "api-access/": [
            {"prefix": "v2/", "size_gb": 280, "object_count": 1_800_000},
            {"prefix": "v1/", "size_gb": 170, "object_count": 1_000_000},
        ],
    },
    "bdp-processed-data": {
        "parquet/": [
            {"prefix": "clickstream/", "size_gb": 200, "object_count": 1_100_000},
            {"prefix": "user-activity/", "size_gb": 120, "object_count": 700_000},
            {"prefix": "payments/", "size_gb": 100, "object_count": 500_000},
        ],
        "parquet/clickstream/": [
            {"prefix": "daily/", "size_gb": 140, "object_count": 800_000},
            {"prefix": "hourly/", "size_gb": 60, "object_count": 300_000},
        ],
        "aggregated/": [
            {"prefix": "daily/", "size_gb": 130, "object_count": 1_100_000},
            {"prefix": "weekly/", "size_gb": 50, "object_count": 450_000},
            {"prefix": "monthly/", "size_gb": 30, "object_count": 250_000},
        ],
    },
    "bdp-ml-artifacts": {
        "models/": [
            {"prefix": "anomaly-detector/", "size_gb": 30, "object_count": 400},
            {"prefix": "forecast-engine/", "size_gb": 25, "object_count": 350},
            {"prefix": "embedding-v2/", "size_gb": 17, "object_count": 450},
        ],
    },
    "bdp-logs": {
        "emr/": [
            {"prefix": "stderr/", "size_gb": 500, "object_count": 7_500_000},
            {"prefix": "stdout/", "size_gb": 450, "object_count": 6_800_000},
            {"prefix": "steps/", "size_gb": 250, "object_count": 3_700_000},
        ],
        "mwaa/": [
            {"prefix": "scheduler/", "size_gb": 320, "object_count": 5_600_000},
            {"prefix": "worker/", "size_gb": 280, "object_count": 5_000_000},
            {"prefix": "webserver/", "size_gb": 80, "object_count": 1_400_000},
        ],
    },
}


def _mock_s3_prefixes(bucket_name: str, prefix: str) -> list[dict[str, Any]]:
    # 정적 mock 데이터가 있으면 그대로 사용
    static = _MOCK_S3_PREFIXES.get(bucket_name, {}).get(prefix)
    if static is not None:
        return static

    # prefix 깊이 계산 (최대 depth 제한으로 무한 재귀 방지)
    depth = prefix.rstrip("/").count("/") + 1 if prefix else 0
    if depth >= 6:
        return []

    # 동적 mock: prefix 패턴에 따라 하위 폴더 생성
    return _generate_mock_children(prefix, depth)


def _generate_mock_children(prefix: str, depth: int) -> list[dict[str, Any]]:
    """prefix 경로에 따라 결정론적으로 mock 하위 폴더 생성."""
    seed = int(hashlib.md5(prefix.encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)

    child_count = rng.randint(2, max(2, 5 - depth))
    parent_size = 100 / (depth + 1)

    parts = prefix.rstrip("/").split("/") if prefix else []
    children = []

    for i in range(child_count):
        name = _mock_child_name(parts, depth, i, rng)
        size = round(parent_size * rng.uniform(0.3, 1.2), 1)
        count = rng.randint(1000, 500_000)
        children.append(
            {
                "prefix": f"{name}/",
                "size_gb": size,
                "object_count": count,
            }
        )

    return children


def _mock_child_name(parts: list[str], depth: int, index: int, rng: random.Random) -> str:
    """깊이와 컨텍스트에 따라 적절한 폴더명 생성."""
    last = parts[-1] if parts else ""
    if last.startswith("20") and len(last) == 4:
        return f"{(index + 1):02d}"
    if len(last) == 2 and last.isdigit() and 1 <= int(last) <= 12:
        return f"{(index + 1):02d}"
    if last.startswith("Q") and len(last) == 2:
        return f"{(index + 1):02d}"

    folder_names = [
        "data",
        "output",
        "tmp",
        "archive",
        "backup",
        "raw",
        "processed",
        "staging",
        "production",
        "v1",
        "v2",
        "latest",
        "snapshot",
        "partition_0",
        "partition_1",
        "partition_2",
    ]
    return folder_names[rng.randint(0, len(folder_names) - 1)]


# ── Glue detail mock data ──────────────────────────────

_MOCK_GLUE_TABLES: dict[str, list[dict[str, Any]]] = {
    "raw_zone": [
        {
            "name": "clickstream_events",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 536_870_912_000,
            "row_count": 1_200_000_000,
            "columns": 18,
            "partition_keys": 2,
            "location": "s3://bdp-raw/clickstream/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T03:00:00",
        },
        {
            "name": "app_logs",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 322_122_547_200,
            "row_count": 800_000_000,
            "columns": 12,
            "partition_keys": 3,
            "location": "s3://bdp-raw/app-logs/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T03:00:00",
        },
        {
            "name": "api_access_log",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 214_748_364_800,
            "row_count": 500_000_000,
            "columns": 15,
            "partition_keys": 2,
            "location": "s3://bdp-raw/api-access/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-20T06:00:00",
        },
        {
            "name": "user_activity",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 107_374_182_400,
            "row_count": 300_000_000,
            "columns": 22,
            "partition_keys": 2,
            "location": "s3://bdp-raw/user-activity/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T01:00:00",
        },
        {
            "name": "payment_transactions",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 53_687_091_200,
            "row_count": 50_000_000,
            "columns": 25,
            "partition_keys": 1,
            "location": "s3://bdp-raw/payments/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T02:00:00",
        },
        {
            "name": "product_catalog_raw",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 21_474_836_480,
            "row_count": 2_000_000,
            "columns": 30,
            "partition_keys": 0,
            "location": "s3://bdp-raw/product-catalog/",
            "input_format": "org.apache.hadoop.mapred.TextInputFormat",
            "updated_at": "2026-02-19T12:00:00",
        },
        {
            "name": "order_events",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 32_212_254_720,
            "row_count": 80_000_000,
            "columns": 16,
            "partition_keys": 2,
            "location": "s3://bdp-raw/orders/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T03:00:00",
        },
    ],
    "feature_store": [
        {
            "name": "user_features_v2",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 214_748_364_800,
            "row_count": 50_000_000,
            "columns": 48,
            "partition_keys": 1,
            "location": "s3://bdp-ml/features/user/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T06:00:00",
        },
        {
            "name": "item_embeddings",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 322_122_547_200,
            "row_count": 10_000_000,
            "columns": 5,
            "partition_keys": 0,
            "location": "s3://bdp-ml/features/item-emb/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-20T18:00:00",
        },
        {
            "name": "session_features",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 107_374_182_400,
            "row_count": 200_000_000,
            "columns": 32,
            "partition_keys": 2,
            "location": "s3://bdp-ml/features/session/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T06:00:00",
        },
    ],
    "training": [
        {
            "name": "recommendation_train",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 1_073_741_824_000,
            "row_count": 500_000_000,
            "columns": 12,
            "partition_keys": 1,
            "location": "s3://bdp-ml/training/reco/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-20T00:00:00",
        },
        {
            "name": "fraud_detection_train",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 536_870_912_000,
            "row_count": 100_000_000,
            "columns": 35,
            "partition_keys": 1,
            "location": "s3://bdp-ml/training/fraud/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-18T00:00:00",
        },
        {
            "name": "search_ranking_train",
            "table_type": "EXTERNAL_TABLE",
            "size_bytes": 536_870_912_000,
            "row_count": 300_000_000,
            "columns": 20,
            "partition_keys": 1,
            "location": "s3://bdp-ml/training/search/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-19T00:00:00",
        },
    ],
}

_MOCK_GLUE_SCHEMAS: dict[str, dict[str, Any]] = {
    "clickstream_events": {
        "columns": [
            {"name": "event_id", "type": "string", "comment": "이벤트 고유 ID"},
            {"name": "user_id", "type": "bigint", "comment": "사용자 ID"},
            {"name": "session_id", "type": "string", "comment": "세션 ID"},
            {
                "name": "event_type",
                "type": "string",
                "comment": "이벤트 유형 (click, view, scroll)",
            },
            {"name": "page_url", "type": "string", "comment": "페이지 URL"},
            {"name": "referrer", "type": "string", "comment": "리퍼러 URL"},
            {"name": "device_type", "type": "string", "comment": "디바이스 유형"},
            {"name": "browser", "type": "string", "comment": "브라우저"},
            {"name": "os", "type": "string", "comment": "운영체제"},
            {"name": "country", "type": "string", "comment": "국가 코드"},
            {"name": "region", "type": "string", "comment": "지역"},
            {"name": "ip_address", "type": "string", "comment": "IP 주소"},
            {"name": "user_agent", "type": "string", "comment": "User-Agent"},
            {"name": "event_properties", "type": "map<string,string>", "comment": "이벤트 속성"},
            {"name": "timestamp", "type": "timestamp", "comment": "이벤트 시각"},
            {"name": "processed_at", "type": "timestamp", "comment": "처리 시각"},
        ],
        "partition_keys": [
            {"name": "dt", "type": "string", "comment": "날짜 파티션 (yyyy-MM-dd)"},
            {"name": "hour", "type": "string", "comment": "시간 파티션 (HH)"},
        ],
        "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
    },
    "user_features_v2": {
        "columns": [
            {"name": "user_id", "type": "bigint", "comment": "사용자 ID"},
            {"name": "age_bucket", "type": "string", "comment": "연령대"},
            {"name": "gender", "type": "string", "comment": "성별"},
            {"name": "signup_days", "type": "int", "comment": "가입 후 경과일"},
            {"name": "total_orders", "type": "int", "comment": "총 주문 수"},
            {"name": "total_spent", "type": "double", "comment": "총 결제 금액"},
            {"name": "avg_order_value", "type": "double", "comment": "평균 주문 금액"},
            {"name": "last_order_days", "type": "int", "comment": "마지막 주문 경과일"},
            {"name": "favorite_category", "type": "string", "comment": "선호 카테고리"},
            {"name": "click_rate_7d", "type": "double", "comment": "7일 클릭률"},
            {"name": "purchase_rate_30d", "type": "double", "comment": "30일 구매율"},
            {"name": "embedding_vector", "type": "array<double>", "comment": "유저 임베딩 (128d)"},
            {"name": "updated_at", "type": "timestamp", "comment": "갱신 시각"},
        ],
        "partition_keys": [
            {"name": "dt", "type": "string", "comment": "날짜 파티션"},
        ],
        "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
    },
}


def _mock_glue_tables(catalog_name: str, database_name: str) -> list[dict[str, Any]]:
    preset = _MOCK_GLUE_TABLES.get(database_name)
    if preset:
        # 기존 mock 테이블에 is_iceberg 플래그 추가
        for tbl in preset:
            tbl.setdefault("is_iceberg", True)
            tbl.setdefault("iceberg_format", "2")
        return preset
    return [
        {
            "name": f"{database_name}_table_{i + 1}",
            "table_type": "EXTERNAL_TABLE",
            "is_iceberg": True,
            "iceberg_format": "2",
            "size_bytes": (i + 1) * 10_737_418_240,
            "row_count": (i + 1) * 1_000_000,
            "columns": 10 + i * 2,
            "partition_keys": 1,
            "location": f"s3://bdp-data/{database_name}/t{i + 1}/",
            "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
            "updated_at": "2026-02-21T00:00:00",
        }
        for i in range(5)
    ]


def _mock_glue_table_schema(
    catalog_name: str, database_name: str, table_name: str
) -> dict[str, Any]:
    if table_name in _MOCK_GLUE_SCHEMAS:
        schema = _MOCK_GLUE_SCHEMAS[table_name]
    else:
        schema = {
            "columns": [
                {"name": "id", "type": "bigint", "comment": "Primary Key"},
                {"name": "name", "type": "string", "comment": "이름"},
                {"name": "value", "type": "double", "comment": "값"},
                {"name": "created_at", "type": "timestamp", "comment": "생성 시각"},
                {"name": "updated_at", "type": "timestamp", "comment": "수정 시각"},
            ],
            "partition_keys": [{"name": "dt", "type": "string", "comment": "날짜 파티션"}],
            "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
        }
    return {
        "name": table_name,
        "database": database_name,
        "table_type": "EXTERNAL_TABLE",
        "is_iceberg": True,
        **schema,
        "location": f"s3://bdp-data/{database_name}/{table_name}/",
        "input_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat",
        "output_format": "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat",
        "size_bytes": 10_737_418_240,
        "row_count": 1_000_000,
        "created_at": "2025-06-15T00:00:00",
        "updated_at": "2026-02-21T00:00:00",
        "iceberg": {
            "format_version": "2",
            "table_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            "metadata_location": f"s3://bdp-data/{database_name}/{table_name}/metadata/00005-abc12345.metadata.json",
            "current_snapshot_id": "3897246038754192845",
            "current_snapshot_ts": "2026-02-21T09:30:00",
            "snapshot_operation": "append",
            "num_files": 142,
            "total_size": 10_737_418_240,
            "write_format": "parquet",
            "compression": "zstd",
        },
    }


# ── RDS detail mock data ─────────────────────────────

_MOCK_RDS_TABLES: dict[str, list[dict[str, Any]]] = {
    "bdp-main-db": [
        {
            "name": "users",
            "table_type": "BASE TABLE",
            "row_count": 2_500_000,
            "data_bytes": 1_073_741_824,
            "columns": 15,
            "engine": "InnoDB",
            "database": "bdp_main",
        },
        {
            "name": "orders",
            "table_type": "BASE TABLE",
            "row_count": 18_000_000,
            "data_bytes": 8_589_934_592,
            "columns": 22,
            "engine": "InnoDB",
            "database": "bdp_main",
        },
        {
            "name": "products",
            "table_type": "BASE TABLE",
            "row_count": 500_000,
            "data_bytes": 268_435_456,
            "columns": 28,
            "engine": "InnoDB",
            "database": "bdp_main",
        },
        {
            "name": "payments",
            "table_type": "BASE TABLE",
            "row_count": 15_000_000,
            "data_bytes": 4_294_967_296,
            "columns": 18,
            "engine": "InnoDB",
            "database": "bdp_main",
        },
        {
            "name": "sessions",
            "table_type": "BASE TABLE",
            "row_count": 8_000_000,
            "data_bytes": 2_147_483_648,
            "columns": 10,
            "engine": "InnoDB",
            "database": "bdp_main",
        },
    ],
    "bdp-analytics-db": [
        {
            "name": "daily_metrics",
            "table_type": "BASE TABLE",
            "row_count": 3_650_000,
            "data_bytes": 1_610_612_736,
            "columns": 25,
            "engine": "InnoDB",
            "database": "bdp_analytics",
        },
        {
            "name": "user_segments",
            "table_type": "BASE TABLE",
            "row_count": 2_500_000,
            "data_bytes": 536_870_912,
            "columns": 12,
            "engine": "InnoDB",
            "database": "bdp_analytics",
        },
        {
            "name": "funnel_events",
            "table_type": "BASE TABLE",
            "row_count": 50_000_000,
            "data_bytes": 10_737_418_240,
            "columns": 16,
            "engine": "InnoDB",
            "database": "bdp_analytics",
        },
        {
            "name": "ab_test_results",
            "table_type": "BASE TABLE",
            "row_count": 800_000,
            "data_bytes": 214_748_364,
            "columns": 20,
            "engine": "InnoDB",
            "database": "bdp_analytics",
        },
    ],
    "bdp-airflow-meta": [
        {
            "name": "dag",
            "table_type": "BASE TABLE",
            "row_count": 150,
            "data_bytes": 524_288,
            "columns": 18,
            "engine": "InnoDB",
            "database": "airflow",
        },
        {
            "name": "dag_run",
            "table_type": "BASE TABLE",
            "row_count": 500_000,
            "data_bytes": 268_435_456,
            "columns": 15,
            "engine": "InnoDB",
            "database": "airflow",
        },
        {
            "name": "task_instance",
            "table_type": "BASE TABLE",
            "row_count": 5_000_000,
            "data_bytes": 2_147_483_648,
            "columns": 28,
            "engine": "InnoDB",
            "database": "airflow",
        },
        {
            "name": "log",
            "table_type": "BASE TABLE",
            "row_count": 20_000_000,
            "data_bytes": 8_589_934_592,
            "columns": 8,
            "engine": "InnoDB",
            "database": "airflow",
        },
        {
            "name": "xcom",
            "table_type": "BASE TABLE",
            "row_count": 2_000_000,
            "data_bytes": 1_073_741_824,
            "columns": 7,
            "engine": "InnoDB",
            "database": "airflow",
        },
    ],
    "bdp-hive-metastore": [
        {
            "name": "DBS",
            "table_type": "BASE TABLE",
            "row_count": 15,
            "data_bytes": 32_768,
            "columns": 8,
            "engine": "InnoDB",
            "database": "hive_metastore",
        },
        {
            "name": "TBLS",
            "table_type": "BASE TABLE",
            "row_count": 73,
            "data_bytes": 65_536,
            "columns": 12,
            "engine": "InnoDB",
            "database": "hive_metastore",
        },
        {
            "name": "COLUMNS_V2",
            "table_type": "BASE TABLE",
            "row_count": 1_200,
            "data_bytes": 262_144,
            "columns": 5,
            "engine": "InnoDB",
            "database": "hive_metastore",
        },
        {
            "name": "PARTITIONS",
            "table_type": "BASE TABLE",
            "row_count": 50_000,
            "data_bytes": 16_777_216,
            "columns": 8,
            "engine": "InnoDB",
            "database": "hive_metastore",
        },
        {
            "name": "SDS",
            "table_type": "BASE TABLE",
            "row_count": 73,
            "data_bytes": 49_152,
            "columns": 10,
            "engine": "InnoDB",
            "database": "hive_metastore",
        },
    ],
}

_MOCK_RDS_SCHEMAS: dict[str, dict[str, Any]] = {
    "users": {
        "database": "bdp_main",
        "engine": "mysql 8.0.35",
        "table_type": "BASE TABLE",
        "columns": [
            {
                "name": "id",
                "type": "BIGINT",
                "nullable": False,
                "key": "PRI",
                "comment": "사용자 고유 ID",
            },
            {
                "name": "email",
                "type": "VARCHAR(255)",
                "nullable": False,
                "key": "UNI",
                "comment": "이메일 주소",
            },
            {
                "name": "username",
                "type": "VARCHAR(100)",
                "nullable": False,
                "key": "UNI",
                "comment": "사용자명",
            },
            {
                "name": "password_hash",
                "type": "VARCHAR(255)",
                "nullable": False,
                "key": "",
                "comment": "비밀번호 해시",
            },
            {
                "name": "full_name",
                "type": "VARCHAR(200)",
                "nullable": True,
                "key": "",
                "comment": "전체 이름",
            },
            {
                "name": "phone",
                "type": "VARCHAR(20)",
                "nullable": True,
                "key": "",
                "comment": "전화번호",
            },
            {
                "name": "status",
                "type": "ENUM('active','inactive','suspended')",
                "nullable": False,
                "key": "",
                "comment": "계정 상태",
            },
            {
                "name": "role",
                "type": "VARCHAR(50)",
                "nullable": False,
                "key": "",
                "comment": "사용자 역할",
            },
            {
                "name": "last_login_at",
                "type": "DATETIME",
                "nullable": True,
                "key": "",
                "comment": "마지막 로그인",
            },
            {
                "name": "login_count",
                "type": "INT",
                "nullable": False,
                "key": "",
                "comment": "로그인 횟수",
            },
            {
                "name": "email_verified",
                "type": "TINYINT(1)",
                "nullable": False,
                "key": "",
                "comment": "이메일 인증 여부",
            },
            {
                "name": "metadata",
                "type": "JSON",
                "nullable": True,
                "key": "",
                "comment": "추가 메타데이터",
            },
            {
                "name": "created_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "생성 시각",
            },
            {
                "name": "updated_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "수정 시각",
            },
            {
                "name": "deleted_at",
                "type": "DATETIME",
                "nullable": True,
                "key": "",
                "comment": "삭제 시각 (soft delete)",
            },
        ],
        "indexes": [
            {"name": "PRIMARY", "columns": ["id"], "unique": True},
            {"name": "idx_users_email", "columns": ["email"], "unique": True},
            {"name": "idx_users_username", "columns": ["username"], "unique": True},
            {"name": "idx_users_status", "columns": ["status"], "unique": False},
            {"name": "idx_users_created_at", "columns": ["created_at"], "unique": False},
        ],
        "row_count": 2_500_000,
        "data_bytes": 1_073_741_824,
        "created_at": "2024-01-15T00:00:00",
    },
    "orders": {
        "database": "bdp_main",
        "engine": "mysql 8.0.35",
        "table_type": "BASE TABLE",
        "columns": [
            {"name": "id", "type": "BIGINT", "nullable": False, "key": "PRI", "comment": "주문 ID"},
            {
                "name": "user_id",
                "type": "BIGINT",
                "nullable": False,
                "key": "MUL",
                "comment": "사용자 ID",
            },
            {
                "name": "order_number",
                "type": "VARCHAR(50)",
                "nullable": False,
                "key": "UNI",
                "comment": "주문 번호",
            },
            {
                "name": "status",
                "type": "ENUM('pending','paid','shipped','delivered','cancelled','refunded')",
                "nullable": False,
                "key": "MUL",
                "comment": "주문 상태",
            },
            {
                "name": "total_amount",
                "type": "DECIMAL(12,2)",
                "nullable": False,
                "key": "",
                "comment": "총 금액",
            },
            {
                "name": "discount_amount",
                "type": "DECIMAL(12,2)",
                "nullable": False,
                "key": "",
                "comment": "할인 금액",
            },
            {
                "name": "shipping_fee",
                "type": "DECIMAL(8,2)",
                "nullable": False,
                "key": "",
                "comment": "배송비",
            },
            {
                "name": "payment_method",
                "type": "VARCHAR(50)",
                "nullable": True,
                "key": "",
                "comment": "결제 수단",
            },
            {
                "name": "shipping_address",
                "type": "JSON",
                "nullable": True,
                "key": "",
                "comment": "배송 주소",
            },
            {
                "name": "ordered_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "MUL",
                "comment": "주문 시각",
            },
            {
                "name": "paid_at",
                "type": "DATETIME",
                "nullable": True,
                "key": "",
                "comment": "결제 시각",
            },
            {
                "name": "shipped_at",
                "type": "DATETIME",
                "nullable": True,
                "key": "",
                "comment": "배송 시각",
            },
            {
                "name": "delivered_at",
                "type": "DATETIME",
                "nullable": True,
                "key": "",
                "comment": "배송 완료",
            },
            {
                "name": "created_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "생성 시각",
            },
            {
                "name": "updated_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "수정 시각",
            },
        ],
        "indexes": [
            {"name": "PRIMARY", "columns": ["id"], "unique": True},
            {"name": "idx_orders_user_id", "columns": ["user_id"], "unique": False},
            {"name": "idx_orders_order_number", "columns": ["order_number"], "unique": True},
            {"name": "idx_orders_status", "columns": ["status"], "unique": False},
            {"name": "idx_orders_ordered_at", "columns": ["ordered_at"], "unique": False},
            {"name": "idx_orders_user_status", "columns": ["user_id", "status"], "unique": False},
        ],
        "row_count": 18_000_000,
        "data_bytes": 8_589_934_592,
        "created_at": "2024-01-15T00:00:00",
    },
    "dag": {
        "database": "airflow",
        "engine": "postgres 15.4",
        "table_type": "BASE TABLE",
        "columns": [
            {
                "name": "dag_id",
                "type": "VARCHAR(250)",
                "nullable": False,
                "key": "PRI",
                "comment": "DAG 식별자",
            },
            {
                "name": "root_dag_id",
                "type": "VARCHAR(250)",
                "nullable": True,
                "key": "",
                "comment": "루트 DAG ID",
            },
            {
                "name": "is_paused",
                "type": "BOOLEAN",
                "nullable": True,
                "key": "",
                "comment": "일시정지 여부",
            },
            {
                "name": "is_subdag",
                "type": "BOOLEAN",
                "nullable": True,
                "key": "",
                "comment": "SubDAG 여부",
            },
            {
                "name": "is_active",
                "type": "BOOLEAN",
                "nullable": True,
                "key": "",
                "comment": "활성 여부",
            },
            {
                "name": "fileloc",
                "type": "VARCHAR(2000)",
                "nullable": True,
                "key": "",
                "comment": "파일 위치",
            },
            {
                "name": "schedule_interval",
                "type": "TEXT",
                "nullable": True,
                "key": "",
                "comment": "스케줄 주기",
            },
            {
                "name": "owners",
                "type": "VARCHAR(2000)",
                "nullable": True,
                "key": "",
                "comment": "소유자",
            },
            {"name": "description", "type": "TEXT", "nullable": True, "key": "", "comment": "설명"},
            {
                "name": "max_active_tasks",
                "type": "INTEGER",
                "nullable": False,
                "key": "",
                "comment": "최대 병렬 태스크",
            },
            {
                "name": "max_active_runs",
                "type": "INTEGER",
                "nullable": False,
                "key": "",
                "comment": "최대 병렬 실행",
            },
            {
                "name": "has_task_concurrency_limits",
                "type": "BOOLEAN",
                "nullable": True,
                "key": "",
                "comment": "태스크 동시성 제한",
            },
        ],
        "indexes": [
            {"name": "dag_pkey", "columns": ["dag_id"], "unique": True},
            {"name": "idx_root_dag_id", "columns": ["root_dag_id"], "unique": False},
        ],
        "row_count": 150,
        "data_bytes": 524_288,
        "created_at": "2024-03-01T00:00:00",
    },
    "DBS": {
        "database": "hive_metastore",
        "engine": "mysql 8.0.35",
        "table_type": "BASE TABLE",
        "columns": [
            {
                "name": "DB_ID",
                "type": "BIGINT",
                "nullable": False,
                "key": "PRI",
                "comment": "데이터베이스 ID",
            },
            {
                "name": "DESC",
                "type": "VARCHAR(4000)",
                "nullable": True,
                "key": "",
                "comment": "설명",
            },
            {
                "name": "DB_LOCATION_URI",
                "type": "VARCHAR(4000)",
                "nullable": False,
                "key": "",
                "comment": "위치 URI",
            },
            {
                "name": "NAME",
                "type": "VARCHAR(128)",
                "nullable": True,
                "key": "UNI",
                "comment": "데이터베이스 이름",
            },
            {
                "name": "OWNER_NAME",
                "type": "VARCHAR(128)",
                "nullable": True,
                "key": "",
                "comment": "소유자",
            },
            {
                "name": "OWNER_TYPE",
                "type": "VARCHAR(10)",
                "nullable": True,
                "key": "",
                "comment": "소유자 유형",
            },
        ],
        "indexes": [
            {"name": "PRIMARY", "columns": ["DB_ID"], "unique": True},
            {"name": "UNIQUE_DATABASE", "columns": ["NAME"], "unique": True},
        ],
        "row_count": 15,
        "data_bytes": 32_768,
        "created_at": "2024-06-01T00:00:00",
    },
}


def _mock_rds_tables(instance_name: str) -> list[dict[str, Any]]:
    return _MOCK_RDS_TABLES.get(
        instance_name,
        [
            {
                "name": f"table_{i + 1}",
                "table_type": "BASE TABLE",
                "row_count": (i + 1) * 10_000,
                "data_bytes": (i + 1) * 10_485_760,
                "columns": 8 + i * 2,
                "engine": "InnoDB",
                "database": "default",
            }
            for i in range(3)
        ],
    )


def _mock_rds_table_schema(instance_name: str, table_name: str) -> dict[str, Any]:
    if table_name in _MOCK_RDS_SCHEMAS:
        schema = _MOCK_RDS_SCHEMAS[table_name]
        return {"name": table_name, **schema}

    # 인스턴스별 기본 엔진/DB 추론
    instance_tables = _MOCK_RDS_TABLES.get(instance_name, [])
    matched = next((t for t in instance_tables if t["name"] == table_name), None)
    engine = matched["engine"] if matched else "InnoDB"
    database = matched["database"] if matched else "default"
    row_count = matched["row_count"] if matched else 10_000
    data_bytes = matched["data_bytes"] if matched else 10_485_760

    # RDS 인스턴스 목록에서 엔진 버전 추론
    rds_list = _mock_rds()
    rds_inst = next((r for r in rds_list if r["name"] == instance_name), None)
    engine_version = rds_inst["engine"] if rds_inst else "mysql 8.0.35"

    return {
        "name": table_name,
        "database": database,
        "engine": engine_version,
        "table_type": "BASE TABLE",
        "columns": [
            {
                "name": "id",
                "type": "BIGINT",
                "nullable": False,
                "key": "PRI",
                "comment": "Primary Key",
            },
            {
                "name": "name",
                "type": "VARCHAR(255)",
                "nullable": True,
                "key": "",
                "comment": "이름",
            },
            {"name": "value", "type": "TEXT", "nullable": True, "key": "", "comment": "값"},
            {
                "name": "created_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "생성 시각",
            },
            {
                "name": "updated_at",
                "type": "DATETIME",
                "nullable": False,
                "key": "",
                "comment": "수정 시각",
            },
        ],
        "indexes": [
            {"name": "PRIMARY", "columns": ["id"], "unique": True},
        ],
        "row_count": row_count,
        "data_bytes": data_bytes,
        "created_at": "2024-06-01T00:00:00",
    }
