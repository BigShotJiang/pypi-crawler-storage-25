"""Infra Metrics Service - 인프라 시계열 메트릭 조회."""

import json
import logging
import os
import random
import tempfile
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from typing import Any

from src.common.timezone import KST, get_kst_now
from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)

# ── 파일 기반 공유 캐시 (멀티 워커 간 공유) ──────────────

_FILE_CACHE_DIR = os.path.join(tempfile.gettempdir(), "cd1_infra_metrics_cache")
os.makedirs(_FILE_CACHE_DIR, exist_ok=True)


def _save_file_cache(metric_type: str, data: dict) -> None:
    """메트릭 데이터를 JSON 파일로 원자적 저장."""
    path = os.path.join(_FILE_CACHE_DIR, f"{metric_type}.json")
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def _load_file_cache(metric_type: str, ttl: int) -> dict | None:
    """파일 캐시 로드. TTL 초과 또는 파일 없으면 None."""
    path = os.path.join(_FILE_CACHE_DIR, f"{metric_type}.json")
    try:
        if time.time() - os.path.getmtime(path) > ttl:
            return None
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _daily_dates(days: int = 31) -> list[str]:
    """최근 N일간 날짜 목록 생성 (오래된 순, KST 기준)."""
    today = datetime.now(KST).date()
    return [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]


def _seeded_rng(key: str) -> random.Random:
    """키 기반 결정적 랜덤 생성기를 반환. 같은 키 → 같은 시퀀스."""
    seed = hash(key) & 0xFFFFFFFF
    return random.Random(seed)


def _rand_series(
    dates: list[str],
    base: float,
    jitter: float,
    spike_prob: float = 0.05,
    spike_mult: float = 3.0,
    seed_key: str = "",
) -> list[dict[str, Any]]:
    """랜덤 시계열 생성 (정상 범위 + 간헐적 스파이크)."""
    rng = _seeded_rng(f"rand_series_{seed_key}") if seed_key else _seeded_rng("rand_series_default")
    result = []
    val = base
    for d in dates:
        drift = rng.uniform(-jitter, jitter)
        val = max(0, val + drift)
        if rng.random() < spike_prob:
            val = base * spike_mult
        result.append({"date": d, "value": round(val, 1)})
        # 스파이크 후 복귀
        if val > base * 2:
            val = base + rng.uniform(-jitter, jitter)
    return result


class InfraMetricsService:
    """인프라 시계열 메트릭을 CloudWatch에서 조회하는 서비스.

    dev 환경에서는 mock 데이터를 자동 생성한다.
    """

    _GLUE_CACHE_TTL = 3600  # 1시간
    _EMR_CACHE_TTL = 300   # 5분

    def __init__(self, settings: PortalSettings, metric_cache: Any | None = None):
        self.settings = settings
        self._metric_cache = metric_cache
        self._boto3_clients: dict[str, Any] = {}
        self._known_sources: list[str] | None = None  # lazy load
        self._glue_cache: dict[str, Any] | None = None
        self._glue_cache_time: float = 0
        self._emr_cache: dict[str, Any] | None = None
        self._emr_cache_time: float = 0

    def _resolve(self, mock_fn, real_fn, *args) -> dict[str, Any]:
        """공통 dispatch: real 먼저 시도, 실패/빈 결과 시 mock fallback."""
        fn_name = getattr(real_fn, "__name__", "unknown")
        # 파일 캐시 확인 (worker 간 공유, TTL 5분)
        cached = _load_file_cache(fn_name, ttl=300)
        if cached is not None:
            return cached
        try:
            result = real_fn(*args)
            if "is_mock" not in result:
                result["is_mock"] = False
            # 빈 결과여도 real 성공이면 그대로 반환 (mock fallback 안 함)
            # → 프론트엔드에서 "데이터가 없습니다" 표시 (mock과 구분)
            if not self._is_empty_result(result):
                _save_file_cache(fn_name, result)
            return result
        except Exception:
            logger.warning("[%s] real fetch 실패 → mock fallback", fn_name, exc_info=True)
            result = mock_fn(*args)
            result["is_mock"] = True
            return result

    def _is_empty_result(self, result: dict[str, Any]) -> bool:
        """결과 dict 내 모든 collection(list/dict)이 비어있으면 True.

        is_mock 등 메타 필드는 제외하고 실제 데이터 필드만 검사.
        real 함수가 is_mock=False를 명시 반환하면 빈 결과여도 mock fallback하지 않음.
        """
        if result.get("is_mock") is False:
            return False
        collections = [
            v for k, v in result.items() if k != "is_mock" and isinstance(v, (list, dict))
        ]
        return bool(collections) and all(len(v) == 0 for v in collections)

    def _mock_fallback(self, mock_fn, *args) -> dict[str, Any]:
        """_cw_* 내부에서 mock fallback 시 is_mock 플래그를 자동 부착."""
        result = mock_fn(*args)
        result["is_mock"] = True
        return result

    # ── 공통 헬퍼 ─────────────────────────────────────

    def _get_client(self, service_name: str):
        if service_name in self._boto3_clients:
            return self._boto3_clients[service_name]

        from botocore.config import Config

        from src.common.services.aws_session import get_boto3_client

        boto_config = Config(
            connect_timeout=5,
            read_timeout=10,
            retries={"max_attempts": 3, "mode": "adaptive"},
            max_pool_connections=50,
        )

        client = get_boto3_client(
            service_name,
            region="ap-northeast-2",
            config=boto_config,
        )

        # CloudWatch 클라이언트에 VM 캐시 래핑
        if service_name == "cloudwatch" and self._metric_cache:
            from src.agent_server.bdp_common.clients.cached_cloudwatch import CachedCloudWatchClient

            client = CachedCloudWatchClient(client, self._metric_cache)

        self._boto3_clients[service_name] = client
        return client

    def _get_db_connection(self):
        """wfl_awf_hst 조회용 MySQL 연결. Secrets Manager 기반."""
        import pymysql
        import pymysql.cursors

        secret_id = self.settings.baseline_secret_id
        db_name = self.settings.rds_database
        if not secret_id:
            return None
        sm = self._get_client("secretsmanager")
        secret = json.loads(sm.get_secret_value(SecretId=secret_id)["SecretString"])
        return pymysql.connect(
            host=secret["host"],
            port=int(secret.get("port", 3306)),
            user=secret["username"],
            password=secret["password"],
            database=db_name,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            connect_timeout=5,
            read_timeout=15,
        )

    def _query_wfl_awf_hst(self, query: str, params: tuple) -> list[dict]:
        """wfl_awf_hst 테이블 조회 헬퍼."""
        conn = self._get_db_connection()
        if conn is None:
            return []
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                return cursor.fetchall()
        except Exception:
            logger.exception("wfl_awf_hst query failed")
            return []
        finally:
            conn.close()

    def _load_known_sources(self) -> list[str]:
        """src_db_tbl에서 소스 시스템 목록 로드 (lazy, 1회)."""
        if self._known_sources is not None:
            return self._known_sources
        rows = self._query_wfl_awf_hst("SELECT DISTINCT src_db_nm FROM src_db_tbl", ())
        names = [r["src_db_nm"].lower() for r in rows if r.get("src_db_nm")]
        # 긴 이름부터 매칭 (e.g. "my-src" before "my")
        names.sort(key=len, reverse=True)
        self._known_sources = names
        logger.info("Loaded %d known sources from src_db_tbl", len(names))
        return self._known_sources

    def _query_cw_daily(
        self,
        cw_client,
        namespace: str,
        metric_name: str,
        dimensions: list[dict],
        days: int,
        statistic: str = "Average",
    ) -> dict[str, float]:
        """CloudWatch 일별 메트릭 조회 (get_metric_data). 반환: {date_str: value}."""
        now = datetime.now(KST)
        start = now - timedelta(days=days)
        metric_stat = {
            "Metric": {
                "Namespace": namespace,
                "MetricName": metric_name,
                "Dimensions": dimensions,
            },
            "Period": 86400,
            "Stat": statistic,
        }
        resp = cw_client.get_metric_data(
            MetricDataQueries=[
                {
                    "Id": "m1",
                    "MetricStat": metric_stat,
                    "ReturnData": True,
                }
            ],
            StartTime=start,
            EndTime=now,
        )
        result: dict[str, float] = {}
        values = resp.get("MetricDataResults", [])
        if values and values[0].get("Values"):
            timestamps = values[0]["Timestamps"]
            vals = values[0]["Values"]
            for ts, val in zip(timestamps, vals):
                kst_date = ts.astimezone(KST).date().isoformat()
                result[kst_date] = val

        # 오늘자 데이터가 없으면 Period=3600으로 보충 조회
        today_str = datetime.now(KST).date().isoformat()
        if today_str not in result:
            today_utc_midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
            if now > today_utc_midnight:
                resp2 = cw_client.get_metric_data(
                    MetricDataQueries=[
                        {
                            "Id": "m1",
                            "MetricStat": {
                                "Metric": {
                                    "Namespace": namespace,
                                    "MetricName": metric_name,
                                    "Dimensions": dimensions,
                                },
                                "Period": 3600,
                                "Stat": statistic,
                            },
                            "ReturnData": True,
                        }
                    ],
                    StartTime=today_utc_midnight,
                    EndTime=now,
                )
                vals2 = resp2.get("MetricDataResults", [])
                if vals2 and vals2[0].get("Values"):
                    hourly = vals2[0]["Values"]
                    if statistic in ("Average", "Minimum"):
                        result[today_str] = sum(hourly) / len(hourly)
                    elif statistic == "Maximum":
                        result[today_str] = max(hourly)
                    else:  # Sum, SampleCount
                        result[today_str] = sum(hourly)

        return result

    def _query_cw_daily_extended(
        self,
        cw_client,
        namespace: str,
        metric_name: str,
        dimensions: list[dict],
        days: int,
        percentiles: list[str] | None = None,
    ) -> dict[str, dict[str, float]]:
        """CloudWatch ExtendedStatistics 일별 조회. 반환: {date_str: {p50: val, ...}}."""
        if percentiles is None:
            percentiles = ["p50", "p95", "p99"]
        now = datetime.now(KST)
        resp = cw_client.get_metric_statistics(
            Namespace=namespace,
            MetricName=metric_name,
            Dimensions=dimensions,
            StartTime=now - timedelta(days=days),
            EndTime=now,
            Period=86400,
            ExtendedStatistics=percentiles,
        )
        result: dict[str, dict[str, float]] = {}
        for dp in resp.get("Datapoints", []):
            kst_date = dp["Timestamp"].astimezone(KST).date().isoformat()
            ext = dp.get("ExtendedStatistics", {})
            result[kst_date] = {p: ext.get(p, 0.0) for p in percentiles}
        return result

    def _list_rds_instances(self) -> list[str]:
        """RDS DB 인스턴스 식별자 목록 조회."""
        try:
            rds = self._get_client("rds")
            paginator = rds.get_paginator("describe_db_instances")
            ids = []
            for page in paginator.paginate():
                for db in page["DBInstances"]:
                    ids.append(db["DBInstanceIdentifier"])
            return ids
        except Exception:
            logger.warning("Failed to list RDS instances", exc_info=True)
            return []

    def _list_sagemaker_endpoints(self) -> list[str]:
        """SageMaker InService 엔드포인트 이름 목록 조회."""
        try:
            sm = self._get_client("sagemaker")
            paginator = sm.get_paginator("list_endpoints")
            names = []
            for page in paginator.paginate(StatusEquals="InService"):
                for ep in page["Endpoints"]:
                    names.append(ep["EndpointName"])
            return names
        except Exception:
            logger.warning("Failed to list SageMaker endpoints", exc_info=True)
            return []

    def _list_sagemaker_domains(self) -> list[dict]:
        """SageMaker Studio 도메인 목록 조회."""
        try:
            sm = self._get_client("sagemaker")
            return sm.list_domains().get("Domains", [])
        except Exception:
            logger.warning("Failed to list SageMaker domains", exc_info=True)
            return []

    def _list_lambda_functions(self) -> list[str]:
        """Lambda 함수 이름 목록 조회."""
        try:
            lam = self._get_client("lambda")
            paginator = lam.get_paginator("list_functions")
            names = []
            for page in paginator.paginate():
                for fn in page["Functions"]:
                    names.append(fn["FunctionName"])
            return names
        except Exception:
            logger.warning("Failed to list Lambda functions", exc_info=True)
            return []

    def _list_mwaa_environments(self) -> list[str]:
        """MWAA 환경 이름 목록 조회."""
        try:
            mwaa = self._get_client("mwaa")
            paginator = mwaa.get_paginator("list_environments")
            names = []
            for page in paginator.paginate():
                names.extend(page.get("Environments", []))
            return names
        except Exception:
            logger.warning("Failed to list MWAA environments", exc_info=True)
            return []

    # ── MSK Consumer Lag ──────────────────────────────

    def get_msk_lag(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_msk_lag, self._cw_msk_lag, days)

    def _mock_msk_lag(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_msk_lag")
        dates = _daily_dates(days)
        return {
            "clusters": {
                "bdp-kafka-main": [
                    {
                        "date": d,
                        "lag": round(
                            rng.uniform(50, 500)
                            + (rng.uniform(0, 2000) if rng.random() < 0.08 else 0)
                        ),
                    }
                    for d in dates
                ],
                "bdp-kafka-log": [
                    {
                        "date": d,
                        "lag": round(
                            rng.uniform(100, 800)
                            + (rng.uniform(0, 3000) if rng.random() < 0.06 else 0)
                        ),
                    }
                    for d in dates
                ],
            },
        }

    def _cw_msk_lag(self, days: int) -> dict[str, Any]:
        # SKIP: Kafka VPC Endpoint 홀딩 — mock fallback 유지
        return self._mock_fallback(self._mock_msk_lag, days)

    # ── MSK Broker Health ─────────────────────────────

    def get_msk_broker_health(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_msk_broker_health, self._cw_msk_broker_health, days)

    def _mock_msk_broker_health(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_msk_broker_health")
        dates = _daily_dates(days)
        brokers: dict[str, list] = {}
        configs = [
            ("broker-1", 35, 50, 500_000, 55),
            ("broker-2", 40, 55, 600_000, 60),
            ("broker-3", 30, 45, 450_000, 50),
        ]
        total_brokers = len(configs)
        # 날짜별 health_ok 상태를 추적하여 summary 생성
        date_health_counts: dict[str, int] = dict.fromkeys(dates, 0)

        for name, cpu_base, disk_base, net_base, mem_base in configs:
            data = []
            cpu_val = float(cpu_base)
            disk_val = float(disk_base)
            net_val = float(net_base)
            mem_val = float(mem_base)
            for d in dates:
                # CPU: 20~70% 범위, 가끔 스파이크
                cpu_val = max(20, min(70, cpu_val + rng.uniform(-5, 5)))
                if rng.random() < 0.06:
                    cpu_val = min(70, cpu_base * 1.8)
                # Memory: 40~85% 범위
                mem_val = max(40, min(85, mem_val + rng.uniform(-3, 3)))
                if rng.random() < 0.05:
                    mem_val = min(85, mem_base * 1.4)
                # Disk: 40~80% 범위, 점진적 증가 경향
                disk_val = max(40, min(80, disk_val + rng.uniform(-1, 2)))
                # Network: 정상 범위 + 간헐적 스파이크
                net_val = max(100_000, net_val + rng.uniform(-50_000, 50_000))
                if rng.random() < 0.07:
                    net_val = net_base * 3
                # Health: 95% 확률 OK
                health_ok = rng.random() < 0.95
                if health_ok:
                    date_health_counts[d] += 1
                data.append(
                    {
                        "date": d,
                        "cpu_percent": round(cpu_val, 1),
                        "memory_percent": round(mem_val, 1),
                        "disk_used_percent": round(disk_val, 1),
                        "network_in_bytes": round(net_val),
                        "health_ok": health_ok,
                    }
                )
                # 스파이크 후 복귀
                if cpu_val > cpu_base * 1.5:
                    cpu_val = cpu_base + rng.uniform(-3, 3)
                if net_val > net_base * 2:
                    net_val = net_base + rng.uniform(-50_000, 50_000)
                if mem_val > mem_base * 1.3:
                    mem_val = mem_base + rng.uniform(-3, 3)
            brokers[name] = data

        summary = [
            {"date": d, "total": total_brokers, "healthy": date_health_counts[d]} for d in dates
        ]
        return {"summary": summary, "brokers": brokers}

    def _cw_msk_broker_health(self, days: int) -> dict[str, Any]:
        """CloudWatch에서 MSK 브로커별 CPU/Disk/Network 메트릭 조회."""
        try:
            from botocore.config import Config

            from src.common.services.aws_session import get_boto3_client

            cw = get_boto3_client(
                "cloudwatch",
                config=Config(retries={"max_attempts": 2}, connect_timeout=5, read_timeout=10),
            )
            kafka = get_boto3_client(
                "kafka",
                config=Config(retries={"max_attempts": 2}, connect_timeout=5, read_timeout=10),
            )

            # 클러스터 ARN 조회
            clusters_resp = kafka.list_clusters_v2(MaxResults=10)
            cluster_infos = clusters_resp.get("ClusterInfoList", [])
            if not cluster_infos:
                return self._mock_fallback(self._mock_msk_broker_health, days)

            cluster_arn = cluster_infos[0]["ClusterArn"]
            cluster_name = cluster_infos[0]["ClusterName"]

            # 브로커 노드 정보 조회
            nodes_resp = kafka.list_nodes(ClusterArn=cluster_arn)
            broker_ids = sorted(
                [
                    n["BrokerNodeInfo"]["BrokerId"]
                    for n in nodes_resp.get("NodeInfoList", [])
                    if "BrokerNodeInfo" in n
                ]
            )
            if not broker_ids:
                broker_ids = [1, 2, 3]

            end_time = datetime.now(KST)
            start_time = end_time - timedelta(days=days)

            metric_configs = [
                ("CpuUser", "AWS/Kafka", "Average", "cpu_percent"),
                ("MemoryUsed", "AWS/Kafka", "Average", "memory_percent"),
                ("KafkaDataLogsDiskUsed", "AWS/Kafka", "Average", "disk_used_percent"),
                ("BytesInPerSec", "AWS/Kafka", "Sum", "network_in_bytes"),
            ]

            total_brokers = len(broker_ids)
            brokers: dict[str, list] = {}
            date_health_counts: dict[str, int] = {}

            for broker_id in broker_ids:
                broker_name = f"broker-{broker_id}"
                date_map: dict[str, dict[str, Any]] = {}

                for metric_name, namespace, stat, field in metric_configs:
                    resp = cw.get_metric_statistics(
                        Namespace=namespace,
                        MetricName=metric_name,
                        Dimensions=[
                            {"Name": "Cluster Name", "Value": cluster_name},
                            {"Name": "Broker ID", "Value": str(broker_id)},
                        ],
                        StartTime=start_time,
                        EndTime=end_time,
                        Period=86400,
                        Statistics=[stat],
                    )
                    for dp in resp.get("Datapoints", []):
                        d = dp["Timestamp"].astimezone(KST).date().isoformat()
                        if d not in date_map:
                            date_map[d] = {
                                "date": d,
                                "cpu_percent": 0,
                                "memory_percent": 0,
                                "disk_used_percent": 0,
                                "network_in_bytes": 0,
                                "health_ok": True,
                            }
                        date_map[d][field] = round(dp[stat], 1)

                sorted_data = sorted(date_map.values(), key=lambda x: x["date"])
                for pt in sorted_data:
                    if pt.get("health_ok", True):
                        date_health_counts[pt["date"]] = date_health_counts.get(pt["date"], 0) + 1
                brokers[broker_name] = sorted_data

            if not any(brokers.values()):
                return self._mock_fallback(self._mock_msk_broker_health, days)

            all_dates = sorted({pt["date"] for series in brokers.values() for pt in series})
            summary = [
                {"date": d, "total": total_brokers, "healthy": date_health_counts.get(d, 0)}
                for d in all_dates
            ]
            return {"summary": summary, "brokers": brokers}
        except Exception:
            logger.warning("MSK broker health CloudWatch 조회 실패, mock 데이터 사용")
            return self._mock_fallback(self._mock_msk_broker_health, days)

    # ── S3 Bucket Size ────────────────────────────────

    def get_s3_size(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_s3_size, self._cw_s3_size, days)

    def _mock_s3_size(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_s3_size")
        dates = _daily_dates(days)
        buckets: dict[str, list] = {}
        configs = [
            ("bdp-raw-data", 2400, 5),
            ("bdp-processed-data", 780, 3),
            ("bdp-ml-artifacts", 140, 1),
            ("bdp-logs", 2900, 8),
        ]
        for name, base, growth in configs:
            data = []
            val = base
            for d in dates:
                val += rng.uniform(0, growth)
                data.append({"date": d, "size_gb": round(val, 1)})
            buckets[name] = data
        return {"buckets": buckets}

    def _cw_s3_size(self, days: int) -> dict[str, Any]:
        """S3 버킷별 BucketSizeBytes를 CloudWatch에서 조회."""
        try:
            s3 = self._get_client("s3")
            cw = self._get_client("cloudwatch")
            all_buckets = s3.list_buckets().get("Buckets", [])
            bdp_buckets = [b["Name"] for b in all_buckets if "bdp" in b["Name"].lower()]
            if not bdp_buckets:
                return self._mock_fallback(self._mock_s3_size, days)

            dates = _daily_dates(days)
            buckets: dict[str, list] = {}

            def _fetch_bucket(name: str) -> tuple[str, list]:
                raw = self._query_cw_daily(
                    cw,
                    namespace="AWS/S3",
                    metric_name="BucketSizeBytes",
                    dimensions=[
                        {"Name": "BucketName", "Value": name},
                        {"Name": "StorageType", "Value": "StandardStorage"},
                    ],
                    days=days,
                    statistic="Average",
                )
                series = []
                for d in dates:
                    size_bytes = raw.get(d, 0)
                    series.append({"date": d, "size_gb": round(size_bytes / 1_073_741_824, 1)})
                return name, series

            with ThreadPoolExecutor(max_workers=6) as pool:
                futures = {pool.submit(_fetch_bucket, n): n for n in bdp_buckets}
                for fut in as_completed(futures):
                    name, series = fut.result()
                    buckets[name] = series

            return {"buckets": buckets}
        except Exception:
            logger.exception("S3 BucketSizeBytes 조회 실패 — mock fallback")
            return self._mock_fallback(self._mock_s3_size, days)

    # ── SageMaker Studio Users ────────────────────────

    def get_sagemaker_users(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_sagemaker_users, self._cw_sagemaker_users, days)

    def _mock_sagemaker_users(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_users")
        names = ["alice", "bob", "charlie", "diana", "eve", "frank", "grace", "heidi"]
        profiles = []
        for name in names:
            active = rng.random() < 0.6
            apps = ["KernelGateway"] if active else []
            profiles.append({"user": name, "domain": "d-mock", "status": "active" if active else "inactive", "apps": apps})
        total = len(profiles)
        active = sum(1 for p in profiles if p["status"] == "active")
        return {"profiles": profiles, "summary": {"total": total, "active": active}}

    def _cw_sagemaker_users(self, days: int) -> dict[str, Any]:
        """SageMaker Studio 사용자 프로필 + 활성 상태 조회."""
        import time as _time

        sm = self._get_client("sagemaker")
        domains = self._list_sagemaker_domains()
        if not domains:
            return {"profiles": [], "summary": {"total": 0, "active": 0}}

        profiles: list[dict] = []
        for domain in domains:
            domain_id = domain["DomainId"]
            domain_name = domain.get("DomainName", domain_id)
            # 사용자 프로필 목록
            try:
                paginator = sm.get_paginator("list_user_profiles")
                for page in paginator.paginate(DomainIdEquals=domain_id):
                    for up in page.get("UserProfiles", []):
                        user_name = up["UserProfileName"]
                        # 활성 앱 조회
                        active_apps: list[str] = []
                        try:
                            app_resp = sm.list_apps(
                                DomainIdEquals=domain_id,
                                UserProfileNameEquals=user_name,
                            )
                            for app in app_resp.get("Apps", []):
                                if app.get("Status") == "InService":
                                    active_apps.append(app.get("AppType", "Unknown"))
                        except Exception:
                            logger.debug("list_apps failed for %s/%s", domain_id, user_name)
                        status = "active" if active_apps else "inactive"
                        profiles.append({
                            "user": user_name,
                            "domain": domain_name,
                            "status": status,
                            "apps": active_apps,
                        })
                        _time.sleep(0.2)  # throttling 방지
            except Exception:
                logger.warning("list_user_profiles failed for domain %s", domain_id, exc_info=True)

        total = len(profiles)
        active = sum(1 for p in profiles if p["status"] == "active")
        return {"profiles": profiles, "summary": {"total": total, "active": active}}

    # ── SageMaker Endpoint Errors ─────────────────────

    def get_sagemaker_endpoint_errors(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_endpoint_errors, self._cw_sagemaker_endpoint_errors, days
        )

    def _mock_sagemaker_endpoint_errors(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_endpoint_errors")
        dates = _daily_dates(days)
        endpoints: dict[str, list] = {}
        for name in ["hcb", "hpi"]:
            data = []
            for d in dates:
                err_4xx = rng.randint(0, 15)
                err_5xx = rng.randint(0, 5)
                # 간헐적 에러 스파이크
                if rng.random() < 0.07:
                    err_4xx += rng.randint(20, 80)
                if rng.random() < 0.04:
                    err_5xx += rng.randint(10, 40)
                data.append({"date": d, "4xx": err_4xx, "5xx": err_5xx})
            endpoints[name] = data
        return {"endpoints": endpoints}

    def _cw_sagemaker_endpoint_errors(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            ep_names = self._list_sagemaker_endpoints()
            if not ep_names:
                return {"endpoints": {}}
            dates = _daily_dates(days)
            endpoints: dict[str, list] = {}

            def _fetch(name: str):
                dims = [
                    {"Name": "EndpointName", "Value": name},
                    {"Name": "VariantName", "Value": "AllTraffic"},
                ]
                err4 = self._query_cw_daily(
                    cw, "AWS/SageMaker", "Invocations4XXErrors", dims, days, "Sum"
                )
                err5 = self._query_cw_daily(
                    cw, "AWS/SageMaker", "Invocations5XXErrors", dims, days, "Sum"
                )
                return name, err4, err5

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in ep_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        name, err4_data, err5_data = f.result()
                        endpoints[name] = [
                            {
                                "date": d,
                                "4xx": int(err4_data.get(d, 0)),
                                "5xx": int(err5_data.get(d, 0)),
                            }
                            for d in dates
                        ]
                    except Exception:
                        logger.warning(
                            "CW query failed for SageMaker endpoint errors", exc_info=True
                        )
            return {"endpoints": endpoints}
        except Exception:
            logger.exception("_cw_sagemaker_endpoint_errors failed")
            return {"endpoints": {}}

    # ── SageMaker Pipeline Failures ─────────────────────

    def get_sagemaker_pipeline_failures(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_pipeline_failures, self._cw_sagemaker_pipeline_failures, days
        )

    def _mock_sagemaker_pipeline_failures(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_pipeline_failures")
        dates = _daily_dates(days)
        # 프로젝트코드 -> 파이프라인 원본 이름 매핑
        mock_groups = {
            "prj001": [
                "prd-pl-training-p100prj001-daily",
                "prd-pl-inference-p100prj001-batch",
            ],
            "prj002": [
                "prd-pl-training-p200prj002-hourly",
                "prd-pl-etl-p200prj002-nightly",
                "prd-pl-scoring-p200prj002-weekly",
            ],
        }
        groups: dict[str, Any] = {}
        for code, pipeline_names in mock_groups.items():
            pipelines_data: dict[str, list] = {}
            total_failures: dict[str, int] = defaultdict(int)
            for name in pipeline_names:
                data = []
                for d in dates:
                    f = rng.randint(0, 2)
                    if rng.random() < 0.06:
                        f += rng.randint(3, 12)
                    data.append({"date": d, "failures": f})
                    total_failures[d] += f
                pipelines_data[name] = data
            groups[code] = {
                "total": [{"date": d, "failures": total_failures[d]} for d in dates],
                "pipelines": pipelines_data,
            }
        return {"groups": groups}

    @staticmethod
    def _parse_pipeline_name(name: str) -> tuple[str, str] | None:
        """파이프라인 네이밍 규칙 파싱.

        규칙: {env}-pl-{종류}-p{3자리권한코드}{6자리프로젝트코드}*
        반환: (프로젝트코드, 종류) 또는 None (규칙 불일치)
        """
        import re

        m = re.match(r"(?:prd|dev)-pl-(.+?)-p\d{3}(\w{6})", name)
        if not m:
            return None
        pipeline_type = m.group(1)
        project_code = m.group(2).lower()
        return project_code, pipeline_type

    def _cw_sagemaker_pipeline_failures(self, days: int) -> dict[str, Any]:
        """SageMaker Pipeline 실행 실패 조회 (SageMaker API).

        프로젝트코드별 그룹 + 개별 파이프라인 2레벨 구조로 반환.
        ThrottlingException 방지를 위해 순차 조회 + backoff.
        """
        import time

        try:
            sm = self._get_client("sagemaker")
            now = datetime.now(KST)
            start = now - timedelta(days=days)
            dates = _daily_dates(days)

            # 1) 파이프라인 목록 조회 + 프로젝트코드별 그룹핑
            pipeline_names: list[str] = []
            paginator = sm.get_paginator("list_pipelines")
            for page in paginator.paginate():
                for p in page.get("PipelineSummaries", []):
                    pipeline_names.append(p["PipelineName"])
            if not pipeline_names:
                return {"groups": {}}

            # 프로젝트코드별로 파이프라인 원본 이름 수집
            code_pipelines: dict[str, list[str]] = defaultdict(list)
            for name in pipeline_names:
                parsed = self._parse_pipeline_name(name)
                if parsed:
                    project_code, _pipeline_type = parsed
                    code_pipelines[project_code].append(name)
                # 규칙 불일치 파이프라인은 무시 (dev 용 등)

            if not code_pipelines:
                return {"groups": {}}

            # 2) 파이프라인별 실행 이력 순차 조회 (throttling 방지)
            # 개별 파이프라인별 failures 기록
            per_pipeline: dict[str, dict[str, int]] = {}

            for _code, names in code_pipelines.items():
                for name in names:
                    failures: dict[str, int] = defaultdict(int)
                    retries = 0
                    while retries < 3:
                        try:
                            exec_paginator = sm.get_paginator("list_pipeline_executions")
                            for page in exec_paginator.paginate(
                                PipelineName=name,
                                CreatedAfter=start,
                                CreatedBefore=now,
                                SortBy="CreationTime",
                                SortOrder="Descending",
                            ):
                                for exe in page.get("PipelineExecutionSummaries", []):
                                    if exe.get("PipelineExecutionStatus") == "Failed":
                                        d = exe["StartTime"].astimezone(KST).date().isoformat()
                                        failures[d] += 1
                            break  # 성공 시 루프 탈출
                        except Exception as e:
                            if "ThrottlingException" in str(e) and retries < 2:
                                retries += 1
                                time.sleep(1.0 * retries)
                                continue
                            logger.warning("Pipeline execution 조회 실패: %s", name, exc_info=True)
                            break
                    time.sleep(0.2)  # 파이프라인 간 간격
                    per_pipeline[name] = failures

            # 3) groups 구조 조립
            groups: dict[str, Any] = {}
            for code, names in code_pipelines.items():
                total_failures: dict[str, int] = defaultdict(int)
                pipelines_data: dict[str, list] = {}
                for name in names:
                    pf = per_pipeline.get(name, {})
                    pipelines_data[name] = [{"date": d, "failures": pf.get(d, 0)} for d in dates]
                    for d in dates:
                        total_failures[d] += pf.get(d, 0)
                groups[code] = {
                    "total": [{"date": d, "failures": total_failures[d]} for d in dates],
                    "pipelines": pipelines_data,
                }

            return {"groups": groups}
        except Exception:
            logger.exception("_cw_sagemaker_pipeline_failures failed")
            return {"groups": {}}

    # ── SageMaker Notebook Instance Types ─────────────

    def get_sagemaker_notebook_instance_types(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_notebook_instance_types,
            self._cw_sagemaker_notebook_instance_types,
            days,
        )

    def _mock_sagemaker_notebook_instance_types(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_notebook_instance_types")
        dates = _daily_dates(days)
        instance_types: dict[str, list] = {}
        configs = [
            ("ml.t3.medium", 8, 15),
            ("ml.t3.large", 3, 8),
            ("ml.g4dn.xlarge", 1, 4),
            ("ml.m5.xlarge", 2, 6),
        ]
        for inst_type, wkend_base, wkday_base in configs:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                count = rng.randint(0, wkend_base) if is_weekend else rng.randint(1, wkday_base)
                data.append({"date": d, "count": count})
            instance_types[inst_type] = data
        return {"instance_types": instance_types}

    def _cw_sagemaker_notebook_instance_types(self, days: int) -> dict[str, Any]:
        """Studio KernelGateway 앱의 인스턴스 타입별 일별 사용 현황."""
        sm = self._get_client("sagemaker")
        domains = self._list_sagemaker_domains()
        if not domains:
            return {"instance_types": {}}

        now = datetime.now(KST)
        start = (now - timedelta(days=days)).date()
        dates = _daily_dates(days)

        # 도메인별 KernelGateway 앱 수집
        apps: list[dict] = []
        for domain in domains:
            try:
                resp = sm.list_apps(DomainIdEquals=domain["DomainId"])
                for app in resp.get("Apps", []):
                    if app.get("AppType") == "KernelGateway" and app.get("Status") in ("InService", "Deleted"):
                        apps.append(app)
            except Exception:
                logger.warning("list_apps failed for domain %s", domain["DomainId"])

        if not apps:
            return {"instance_types": {}}

        # 앱별 활성 기간을 일별로 집계
        type_daily: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        for app in apps:
            inst_type = app.get("InstanceType") or app.get("ResourceSpec", {}).get("InstanceType")
            if not inst_type:
                continue
            created = app.get("CreationTime")
            if not created:
                continue
            app_start = created.astimezone(KST).date()
            # 활성 종료: Deleted 앱은 수정 시점, InService는 오늘
            if app.get("Status") == "Deleted":
                last_activity = app.get("LastModifiedTime") or app.get("CreationTime")
                app_end = last_activity.astimezone(KST).date()
            else:
                app_end = now.date()
            for d in dates:
                d_date = datetime.fromisoformat(d).date()
                if app_start <= d_date <= app_end:
                    type_daily[inst_type][d] += 1

        instance_types: dict[str, list] = {}
        for inst_type, daily in sorted(type_daily.items()):
            instance_types[inst_type] = [{"date": d, "count": daily.get(d, 0)} for d in dates]
        return {"instance_types": instance_types}

    # ── SageMaker Pipeline Instance Types ─────────────

    def get_sagemaker_pipeline_instance_types(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_pipeline_instance_types,
            self._cw_sagemaker_pipeline_instance_types,
            days,
        )

    def _mock_sagemaker_pipeline_instance_types(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_pipeline_instance_types")
        dates = _daily_dates(days)
        instance_types: dict[str, list] = {}
        configs = [
            ("ml.m5.large", 5, 15),
            ("ml.m5.xlarge", 3, 10),
            ("ml.g4dn.xlarge", 1, 6),
            ("ml.p3.2xlarge", 0, 3),
        ]
        for inst_type, base_lo, base_hi in configs:
            data = []
            for d in dates:
                count = rng.randint(base_lo, base_hi)
                if rng.random() < 0.06:
                    count += rng.randint(5, 20)
                data.append({"date": d, "count": count})
            instance_types[inst_type] = data
        return {"instance_types": instance_types}

    def _cw_sagemaker_pipeline_instance_types(self, days: int) -> dict[str, Any]:
        """Processing/Training Job의 인스턴스 타입별 일별 사용 현황."""
        sm = self._get_client("sagemaker")
        now = datetime.now(KST)
        start = now - timedelta(days=days)
        dates = _daily_dates(days)

        type_daily: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

        # Processing Jobs
        try:
            paginator = sm.get_paginator("list_processing_jobs")
            for page in paginator.paginate(
                CreationTimeAfter=start,
                CreationTimeBefore=now,
                SortBy="CreationTime",
                SortOrder="Descending",
            ):
                for job in page.get("ProcessingJobSummaries", []):
                    inst_type = job.get("ProcessingResources", {}).get(
                        "ClusterConfig", {}
                    ).get("InstanceType")
                    if not inst_type:
                        # list_processing_jobs 요약에 InstanceType이 없으면 describe 필요
                        try:
                            detail = sm.describe_processing_job(ProcessingJobName=job["ProcessingJobName"])
                            inst_type = detail.get("ProcessingResources", {}).get(
                                "ClusterConfig", {}
                            ).get("InstanceType")
                        except Exception:
                            continue
                    if inst_type:
                        d = job["CreationTime"].astimezone(KST).date().isoformat()
                        type_daily[inst_type][d] += 1
        except Exception:
            logger.warning("list_processing_jobs failed", exc_info=True)

        # Training Jobs
        try:
            paginator = sm.get_paginator("list_training_jobs")
            for page in paginator.paginate(
                CreationTimeAfter=start,
                CreationTimeBefore=now,
                SortBy="CreationTime",
                SortOrder="Descending",
            ):
                for job in page.get("TrainingJobSummaries", []):
                    # list에는 InstanceType 없음 → describe 필요
                    try:
                        detail = sm.describe_training_job(TrainingJobName=job["TrainingJobName"])
                        inst_type = detail.get("ResourceConfig", {}).get("InstanceType")
                    except Exception:
                        continue
                    if inst_type:
                        d = job["CreationTime"].astimezone(KST).date().isoformat()
                        type_daily[inst_type][d] += 1
        except Exception:
            logger.warning("list_training_jobs failed", exc_info=True)

        if not type_daily:
            return {"instance_types": {}}

        instance_types: dict[str, list] = {}
        for inst_type, daily in sorted(type_daily.items()):
            instance_types[inst_type] = [{"date": d, "count": daily.get(d, 0)} for d in dates]
        return {"instance_types": instance_types}

    # ── EMR Cluster Failures ──────────────────────────

    def get_emr_cluster_failures(self, days: int = 31) -> dict[str, Any]:
        now = time.monotonic()
        if self._emr_cache and (now - self._emr_cache_time) < self._EMR_CACHE_TTL:
            return self._emr_cache
        # 파일 캐시 확인 (다른 워커가 저장한 것)
        file_data = _load_file_cache("emr-cluster-failures", self._EMR_CACHE_TTL)
        if file_data:
            self._emr_cache = file_data
            self._emr_cache_time = now
            return file_data
        result = self._resolve(self._mock_emr_cluster_failures, self._cw_emr_cluster_failures, days)
        self._emr_cache = result
        self._emr_cache_time = now
        _save_file_cache("emr-cluster-failures", result)
        return result

    def _mock_emr_cluster_failures(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_emr_cluster_failures")
        dates = _daily_dates(days)
        clusters: dict[str, list] = {}
        for name in ["bdp-spark-etl", "bdp-hive-adhoc"]:
            data = []
            for d in dates:
                failures = rng.randint(0, 3)
                if rng.random() < 0.08:
                    failures += rng.randint(5, 15)
                data.append({"date": d, "failures": failures})
            clusters[name] = data
        return {"clusters": clusters}

    def _cw_emr_cluster_failures(self, days: int) -> dict[str, Any]:
        """EMR 클러스터 Step 장애 조회 (EMR API).

        모든 상태의 클러스터에서 FAILED Step 건수를 집계합니다.
        - TERMINATED / TERMINATED_WITH_ERRORS: 종료된 클러스터의 실패 Step
        - RUNNING / WAITING: 실행 중인 클러스터의 실패 Step
        """
        try:
            emr = self._get_client("emr")
            now = datetime.now(KST)
            start = now - timedelta(days=days)
            dates = _daily_dates(days)

            # 1) 클러스터 목록 수집
            cluster_list: list[tuple[str, str]] = []  # (id, name)
            paginator = emr.get_paginator("list_clusters")
            for states in [
                ["TERMINATED", "TERMINATED_WITH_ERRORS"],
                ["RUNNING", "WAITING"],
            ]:
                for page in paginator.paginate(
                    CreatedAfter=start,
                    ClusterStates=states,
                ):
                    for cluster in page.get("Clusters", []):
                        cluster_list.append((cluster["Id"], cluster.get("Name", "unknown")))

            if not cluster_list:
                logger.info("EMR: 조회 기간 내 클러스터 없음 (정상)")
                return {"clusters": {}, "is_mock": False}

            # 2) 클러스터별 FAILED Step 조회 (병렬, concurrency 제한으로 throttle 방지)
            import threading

            lock = threading.Lock()
            date_failures: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

            def _fetch_failed_steps(cluster_id: str, cluster_name: str) -> None:
                step_paginator = emr.get_paginator("list_steps")
                for attempt in range(3):
                    try:
                        for step_page in step_paginator.paginate(
                            ClusterId=cluster_id,
                            StepStates=["FAILED"],
                        ):
                            for step in step_page.get("Steps", []):
                                ended = (
                                    step.get("Status", {}).get("Timeline", {}).get("EndDateTime")
                                )
                                if not ended or ended < start:
                                    continue
                                d = ended.astimezone(KST).date().isoformat()
                                with lock:
                                    date_failures[cluster_name][d] += 1
                        return
                    except Exception as e:
                        if "Rate exceeded" in str(e) or "Throttling" in str(e):
                            time.sleep(2**attempt)
                        else:
                            raise

            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = [
                    executor.submit(_fetch_failed_steps, cid, cname) for cid, cname in cluster_list
                ]
                try:
                    for f in as_completed(futures, timeout=25):
                        try:
                            f.result()
                        except Exception:
                            continue
                except TimeoutError:
                    logger.warning(
                        "EMR cluster failures 조회 타임아웃: %d/%d 클러스터 완료",
                        sum(1 for f in futures if f.done()), len(futures),
                    )

            # 완료된 클러스터 결과만 반환 (부분 결과라도 is_mock=False)
            clusters: dict[str, list] = {}
            for name, failures_by_date in date_failures.items():
                clusters[name] = [
                    {"date": d, "failures": failures_by_date.get(d, 0)} for d in dates
                ]

            return {"clusters": clusters, "is_mock": False}
        except Exception:
            logger.exception("_cw_emr_cluster_failures failed")
            return {"clusters": {}}

    # ── EMR Serverless Failures ───────────────────────

    def get_emr_serverless_failures(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_emr_serverless_failures, self._cw_emr_serverless_failures, days
        )

    def _mock_emr_serverless_failures(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_emr_serverless_failures")
        dates = _daily_dates(days)
        applications: dict[str, list] = {}
        for name in ["bdp-spark-serverless", "bdp-hive-serverless"]:
            data = []
            for d in dates:
                failures = rng.randint(0, 2)
                if rng.random() < 0.06:
                    failures += rng.randint(3, 10)
                data.append({"date": d, "failures": failures})
            applications[name] = data
        return {"applications": applications}

    def _cw_emr_serverless_failures(self, days: int) -> dict[str, Any]:
        """EMR Serverless job run 장애 조회 (EMR Serverless API)."""
        try:
            emr_s = self._get_client("emr-serverless")
            now = datetime.now(KST)
            start = now - timedelta(days=days)
            dates = _daily_dates(days)

            # 1) Application 목록 조회
            apps: list[dict] = []
            resp = emr_s.list_applications()
            for app in resp.get("applications", []):
                apps.append({"id": app["id"], "name": app.get("name", app["id"])})
            if not apps:
                return {"applications": {}}

            # 2) Application별 job run 장애 병렬 조회
            applications: dict[str, list] = {}

            def _fetch(app_id: str, app_name: str):
                date_failures: dict[str, int] = defaultdict(int)
                try:
                    paginator = emr_s.get_paginator("list_job_runs")
                    for page in paginator.paginate(
                        applicationId=app_id,
                        createdAtAfter=start,
                        createdAtBefore=now,
                    ):
                        for job in page.get("jobRuns", []):
                            state = job.get("state", "")
                            if state in ("FAILED", "CANCELLED"):
                                d = job["createdAt"].astimezone(KST).date().isoformat()
                                date_failures[d] += 1
                except Exception:
                    logger.warning("EMR Serverless job runs 조회 실패: %s", app_name, exc_info=True)
                return app_name, date_failures

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, a["id"], a["name"]) for a in apps]
                for f in as_completed(futures, timeout=30):
                    try:
                        app_name, date_failures = f.result()
                        applications[app_name] = [
                            {"date": d, "failures": date_failures.get(d, 0)} for d in dates
                        ]
                    except Exception:
                        logger.warning("EMR Serverless future 처리 실패", exc_info=True)

            return {"applications": applications}
        except Exception:
            logger.exception("_cw_emr_serverless_failures failed")
            return {"applications": {}}

    # ── SageMaker Endpoint Latency ──────────────────────

    def get_sagemaker_endpoint_latency(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_endpoint_latency, self._cw_sagemaker_endpoint_latency, days
        )

    def _mock_sagemaker_endpoint_latency(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_endpoint_latency")
        dates = _daily_dates(days)
        endpoints: dict[str, list] = {}
        configs = [
            ("hcb", 45, 120, 250),
            ("hpi", 80, 200, 450),
        ]
        for name, p50_base, p95_base, p99_base in configs:
            data = []
            for d in dates:
                p50 = p50_base + rng.uniform(-10, 10)
                p95 = p95_base + rng.uniform(-20, 30)
                p99 = p99_base + rng.uniform(-30, 60)
                if rng.random() < 0.05:
                    p50 *= 2
                    p95 *= 2.5
                    p99 *= 3
                data.append(
                    {"date": d, "p50": round(p50, 1), "p95": round(p95, 1), "p99": round(p99, 1)}
                )
            endpoints[name] = data
        return {"endpoints": endpoints}

    def _cw_sagemaker_endpoint_latency(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            ep_names = self._list_sagemaker_endpoints()
            if not ep_names:
                return {"endpoints": {}}
            dates = _daily_dates(days)
            endpoints: dict[str, list] = {}

            def _fetch(name: str):
                dims = [
                    {"Name": "EndpointName", "Value": name},
                    {"Name": "VariantName", "Value": "AllTraffic"},
                ]
                return name, self._query_cw_daily_extended(
                    cw, "AWS/SageMaker", "ModelLatency", dims, days
                )

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in ep_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        name, cw_data = f.result()
                        endpoints[name] = [
                            {
                                "date": d,
                                # ModelLatency는 μs 단위 → ms 변환
                                "p50": round(cw_data.get(d, {}).get("p50", 0) / 1000, 1),
                                "p95": round(cw_data.get(d, {}).get("p95", 0) / 1000, 1),
                                "p99": round(cw_data.get(d, {}).get("p99", 0) / 1000, 1),
                            }
                            for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for SageMaker latency", exc_info=True)
            return {"endpoints": endpoints}
        except Exception:
            logger.exception("_cw_sagemaker_endpoint_latency failed")
            return {"endpoints": {}}

    # ── SageMaker Endpoint Availability ─────────────────

    def get_sagemaker_endpoint_availability(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_endpoint_availability,
            self._cw_sagemaker_endpoint_availability,
            days,
        )

    def _mock_sagemaker_endpoint_availability(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_endpoint_availability")
        dates = _daily_dates(days)
        endpoints: dict[str, list] = {}
        for name in ["hcb", "hpi"]:
            data = []
            for d in dates:
                invocations = rng.randint(8000, 20000)
                errors_5xx = rng.randint(0, 3)
                if rng.random() < 0.05:
                    errors_5xx += rng.randint(10, 50)
                availability = round((1 - errors_5xx / invocations) * 100, 2)
                data.append(
                    {
                        "date": d,
                        "availability": availability,
                        "invocations": invocations,
                        "errors_5xx": errors_5xx,
                    }
                )
            endpoints[name] = data
        return {"endpoints": endpoints}

    def _cw_sagemaker_endpoint_availability(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            ep_names = self._list_sagemaker_endpoints()
            if not ep_names:
                return {"endpoints": {}}
            dates = _daily_dates(days)
            endpoints: dict[str, list] = {}

            def _fetch(name: str):
                dims = [
                    {"Name": "EndpointName", "Value": name},
                    {"Name": "VariantName", "Value": "AllTraffic"},
                ]
                inv = self._query_cw_daily(cw, "AWS/SageMaker", "Invocations", dims, days, "Sum")
                err5 = self._query_cw_daily(
                    cw, "AWS/SageMaker", "Invocations5XXErrors", dims, days, "Sum"
                )
                return name, inv, err5

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in ep_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        name, inv_data, err5_data = f.result()
                        data = []
                        for d in dates:
                            invocations = int(inv_data.get(d, 0))
                            errors_5xx = int(err5_data.get(d, 0))
                            availability = (
                                round((1 - errors_5xx / invocations) * 100, 2)
                                if invocations > 0
                                else 100.0
                            )
                            data.append(
                                {
                                    "date": d,
                                    "availability": availability,
                                    "invocations": invocations,
                                    "errors_5xx": errors_5xx,
                                }
                            )
                        endpoints[name] = data
                    except Exception:
                        logger.warning("CW query failed for SageMaker availability", exc_info=True)
            return {"endpoints": endpoints}
        except Exception:
            logger.exception("_cw_sagemaker_endpoint_availability failed")
            return {"endpoints": {}}

    # ── SageMaker Endpoint Invocations ──────────────────

    def get_sagemaker_endpoint_invocations(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_sagemaker_endpoint_invocations, self._cw_sagemaker_endpoint_invocations, days
        )

    def _mock_sagemaker_endpoint_invocations(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_sagemaker_endpoint_invocations")
        dates = _daily_dates(days)
        endpoints: dict[str, list] = {}
        configs = [
            ("hcb", 12000),
            ("hpi", 8000),
        ]
        for name, base in configs:
            data = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                mult = 0.3 if is_weekend else 1.0
                invocations = max(100, int(base * mult + rng.uniform(-2000, 2000)))
                data.append({"date": d, "invocations": invocations})
            endpoints[name] = data
        return {"endpoints": endpoints}

    def _cw_sagemaker_endpoint_invocations(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            ep_names = self._list_sagemaker_endpoints()
            if not ep_names:
                return {"endpoints": {}}
            dates = _daily_dates(days)
            endpoints: dict[str, list] = {}

            def _fetch(name: str):
                dims = [
                    {"Name": "EndpointName", "Value": name},
                    {"Name": "VariantName", "Value": "AllTraffic"},
                ]
                return name, self._query_cw_daily(
                    cw, "AWS/SageMaker", "Invocations", dims, days, "Sum"
                )

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in ep_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        name, cw_data = f.result()
                        endpoints[name] = [
                            {"date": d, "invocations": int(cw_data.get(d, 0))} for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for SageMaker invocations", exc_info=True)
            return {"endpoints": endpoints}
        except Exception:
            logger.exception("_cw_sagemaker_endpoint_invocations failed")
            return {"endpoints": {}}

    # ── MWAA Node Counts ─────────────────────────────────

    def get_mwaa_node_counts(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_mwaa_node_counts, self._cw_mwaa_node_counts, days)

    def _mock_mwaa_node_counts(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_node_counts")
        dates = _daily_dates(days)
        environments: dict[str, list] = {}
        configs = [
            ("bdp-airflow-dlk", 2, 2, 10),  # schedulers=2, min_workers=2, max_workers=10
            ("bdp-airflow-wfl", 1, 1, 5),  # schedulers=1, min_workers=1, max_workers=5
        ]
        for env_name, schedulers, min_w, max_w in configs:
            data = []
            worker_val = float(min_w)
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                # 주말에는 워커 수 감소, 평일에는 부하에 따라 스케일
                if is_weekend:
                    target = min_w + rng.uniform(0, 1)
                else:
                    target = min_w + rng.uniform(0.5, (max_w - min_w) * 0.6)
                # smooth 변화
                worker_val = worker_val * 0.7 + target * 0.3
                worker_val = max(min_w, min(max_w, worker_val))
                # 간헐적 스파이크 (배치 작업 등)
                peak_workers = worker_val
                if not is_weekend and rng.random() < 0.1:
                    peak_workers = min(max_w, worker_val + rng.uniform(2, max_w * 0.4))
                data.append(
                    {
                        "date": d,
                        "scheduler_max": schedulers,
                        "worker_max": int(round(peak_workers)),
                    }
                )
            environments[env_name] = data
        return {"environments": environments}

    def _cw_mwaa_node_counts(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            mwaa = self._get_client("mwaa")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, list] = {}

            def _fetch(env_name: str):
                # Scheduler 수는 MWAA API에서 설정값 조회
                try:
                    env_detail = mwaa.get_environment(Name=env_name)
                    scheduler_count = env_detail["Environment"].get("Schedulers", 2)
                except Exception:
                    scheduler_count = 2
                # Worker 수는 CPUUtilization SampleCount로 추정
                dims_base = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "BaseWorker"},
                ]
                dims_add = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "AdditionalWorker"},
                ]
                base = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims_base, days, "SampleCount"
                )
                add = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims_add, days, "SampleCount"
                )
                return env_name, scheduler_count, base, add

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, sched, base_data, add_data = f.result()  # type: ignore[misc]
                        environments[env_name] = [
                            {
                                "date": d,
                                "scheduler_max": sched,
                                "worker_max": max(
                                    1,
                                    round((base_data.get(d, 0) + add_data.get(d, 0)) / 1440),
                                ),
                            }
                            for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for MWAA node counts", exc_info=True)
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_node_counts failed")
            return {"environments": {}}

    # ── MWAA Env Updates ───────────────────────────────

    def get_mwaa_env_updates(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_mwaa_env_updates, self._ct_mwaa_env_updates, days)

    def _mock_mwaa_env_updates(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_env_updates")
        dates = _daily_dates(days)
        environments: dict[str, list] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            # 월 2~5회 정도 업데이트 이벤트 발생
            k = min(rng.randint(2, 5), len(dates))
            update_days = set(rng.sample(range(len(dates)), k=k)) if dates else set()
            data = []
            cumulative = 0
            for i, d in enumerate(dates):
                updates = 1 if i in update_days else 0
                cumulative += updates
                data.append({"date": d, "updates": updates, "cumulative": cumulative})
            environments[env_name] = data
        return {"environments": environments}

    def _ct_mwaa_env_updates(self, days: int) -> dict[str, Any]:
        # SKIP: CloudTrail VPC Endpoint 준비 후 활성화
        return self._mock_fallback(self._mock_mwaa_env_updates, days)

    # ── MWAA DAG Import Errors ─────────────────────────

    def get_mwaa_dag_import_errors(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_dag_import_errors, self._cw_mwaa_dag_import_errors, days
        )

    def _mock_mwaa_dag_import_errors(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_dag_import_errors")
        dates = _daily_dates(days)
        environments: dict[str, list] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            data = []
            cumulative = 0
            for d in dates:
                import_errors = rng.choice([0, 0, 0, 0, 1, 1, 2, 3])
                cumulative += import_errors
                data.append({"date": d, "import_errors": import_errors, "cumulative": cumulative})
            environments[env_name] = data
        return {"environments": environments}

    def _cw_mwaa_dag_import_errors(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, list] = {}

            def _fetch(env_name: str):
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Function", "Value": "DAG Processing"},
                ]
                data = self._query_cw_daily(cw, "AmazonMWAA", "ImportErrors", dims, days, "Sum")
                return env_name, data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, err_data = f.result()
                        cumulative = 0
                        daily = []
                        for d in dates:
                            import_errors = int(err_data.get(d, 0))
                            cumulative += import_errors
                            daily.append(
                                {
                                    "date": d,
                                    "import_errors": import_errors,
                                    "cumulative": cumulative,
                                }
                            )
                        environments[env_name] = daily
                    except Exception:
                        logger.warning("CW query failed for MWAA dag import errors", exc_info=True)
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_dag_import_errors failed")
            return self._mock_fallback(self._mock_mwaa_dag_import_errors, days)

    # ── MWAA Scheduler Resources ──────────────────────────

    def get_mwaa_scheduler_resources(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_scheduler_resources, self._cw_mwaa_scheduler_resources, days
        )

    def _mock_mwaa_scheduler_resources(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_scheduler_resources")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", 2),  # 2 schedulers
            ("bdp-airflow-wfl", 1),  # 1 scheduler
        ]
        for env_name, scheduler_count in configs:
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                base_cpu = 12 if is_weekend else 28
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(base_cpu + rng.uniform(-5, 12), 1),
                        "heartbeat": rng.choice(["healthy"] * 9 + ["degraded"]),
                    }
                )
            environments[env_name] = {
                "schedulers": scheduler_count,
                "daily": daily,
            }
        return {"environments": environments}

    def _cw_mwaa_scheduler_resources(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            mwaa = self._get_client("mwaa")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                try:
                    env_detail = mwaa.get_environment(Name=env_name)
                    scheduler_count = env_detail["Environment"].get("Schedulers", 2)
                except Exception:
                    scheduler_count = 2
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "Scheduler"},
                ]
                cpu_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims, days, "Average"
                )
                return env_name, scheduler_count, cpu_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, sched_count, cpu_data = f.result()
                        daily = []
                        for d in dates:
                            cpu_pct = round(cpu_data.get(d, 0), 1)
                            heartbeat = "healthy" if cpu_pct > 0 else "unknown"
                            daily.append({"date": d, "cpu_pct": cpu_pct, "heartbeat": heartbeat})
                        environments[env_name] = {"schedulers": sched_count, "daily": daily}
                    except Exception:
                        logger.warning(
                            "CW query failed for MWAA scheduler resources", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_scheduler_resources failed")
            return self._mock_fallback(self._mock_mwaa_scheduler_resources, days)

    # ── MWAA DAG Processor Parsing ────────────────────────

    def get_mwaa_dagprocessor_parsing(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_dagprocessor_parsing, self._cw_mwaa_dagprocessor_parsing, days
        )

    def _mock_mwaa_dagprocessor_parsing(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_dagprocessor_parsing")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", 220, 250),  # DAG count range
            ("bdp-airflow-wfl", 80, 120),
        ]
        for env_name, min_dags, max_dags in configs:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "parse_time_sec": round(rng.uniform(0.5, 3.0), 2),
                        "total_dags": rng.randint(min_dags, max_dags),
                        "import_errors": rng.choice([0, 0, 0, 0, 1, 1, 2]),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_dagprocessor_parsing(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Function", "Value": "DAG Processing"},
                ]
                parse_data = self._query_cw_daily(
                    cw, "AmazonMWAA", "TotalParseTime", dims, days, "Average"
                )
                err_data = self._query_cw_daily(cw, "AmazonMWAA", "ImportErrors", dims, days, "Sum")
                return env_name, parse_data, err_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, parse_data, err_data = f.result()
                        rng = _seeded_rng(f"mock_mwaa_dagprocessor_parsing_{env_name}")
                        daily = []
                        for d in dates:
                            parse_ms = parse_data.get(d, 0)
                            daily.append(
                                {
                                    "date": d,
                                    "parse_time_sec": round(parse_ms / 1000.0, 2),
                                    "total_dags": rng.randint(100, 300),
                                    "import_errors": int(err_data.get(d, 0)),
                                }
                            )
                        environments[env_name] = {"daily": daily}
                    except Exception:
                        logger.warning(
                            "CW query failed for MWAA dagprocessor parsing", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_dagprocessor_parsing failed")
            return self._mock_fallback(self._mock_mwaa_dagprocessor_parsing, days)

    # ── MWAA Worker Resources ─────────────────────────────

    def get_mwaa_worker_resources(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_mwaa_worker_resources, self._cw_mwaa_worker_resources, days)

    def _mock_mwaa_worker_resources(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_worker_resources")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", 2, 10),
            ("bdp-airflow-wfl", 1, 5),
        ]
        for env_name, min_w, max_w in configs:
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                active = (
                    rng.randint(min_w, min_w + 1)
                    if is_weekend
                    else rng.randint(min_w + 1, min(max_w, min_w + 6))
                )
                base_cpu = 18 if is_weekend else 38
                daily.append(
                    {
                        "date": d,
                        "active_workers": active,
                        "cpu_pct": round(base_cpu + rng.uniform(-8, 15), 1),
                    }
                )
            environments[env_name] = {
                "min_workers": min_w,
                "max_workers": max_w,
                "daily": daily,
            }
        return {"environments": environments}

    def _cw_mwaa_worker_resources(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            mwaa = self._get_client("mwaa")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                try:
                    env_detail = mwaa.get_environment(Name=env_name)
                    env_cfg = env_detail["Environment"]
                    min_w = env_cfg.get("MinWorkers", 1)
                    max_w = env_cfg.get("MaxWorkers", 10)
                except Exception:
                    min_w, max_w = 1, 10
                dims_base = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "BaseWorker"},
                ]
                dims_add = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "AdditionalWorker"},
                ]
                base_sc = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims_base, days, "SampleCount"
                )
                add_sc = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims_add, days, "SampleCount"
                )
                cpu_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims_base, days, "Average"
                )
                return env_name, min_w, max_w, base_sc, add_sc, cpu_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, min_w, max_w, base_sc, add_sc, cpu_data = f.result()  # type: ignore[misc]
                        daily = []
                        for d in dates:
                            active = max(
                                1,
                                round((base_sc.get(d, 0) + add_sc.get(d, 0)) / 1440),
                            )
                            daily.append(
                                {
                                    "date": d,
                                    "active_workers": active,
                                    "cpu_pct": round(cpu_data.get(d, 0), 1),
                                }
                            )
                        environments[env_name] = {
                            "min_workers": min_w,
                            "max_workers": max_w,
                            "daily": daily,
                        }
                    except Exception:
                        logger.warning("CW query failed for MWAA worker resources", exc_info=True)
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_worker_resources failed")
            return self._mock_fallback(self._mock_mwaa_worker_resources, days)

    # ── MWAA Worker Task Execution ────────────────────────

    def get_mwaa_worker_task_execution(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_worker_task_execution, self._cw_mwaa_worker_task_execution, days
        )

    def _mock_mwaa_worker_task_execution(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_worker_task_execution")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", 15, 45, 0, 8),
            ("bdp-airflow-wfl", 5, 18, 0, 3),
        ]
        for env_name, min_conc, max_conc, min_q, max_q in configs:
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                concurrent = (
                    rng.randint(min_conc // 3, min_conc)
                    if is_weekend
                    else rng.randint(min_conc, max_conc)
                )
                daily.append(
                    {
                        "date": d,
                        "concurrent_tasks": concurrent,
                        "queued_tasks": rng.randint(min_q, max_q),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_worker_task_execution(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                dims = [{"Name": "Environment", "Value": env_name}]
                queued_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "QueuedTasks", dims, days, "Average"
                )
                return env_name, queued_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, queued_data = f.result()
                        rng = _seeded_rng(f"mock_mwaa_worker_task_execution_{env_name}")
                        daily = []
                        for d in dates:
                            daily.append(
                                {
                                    "date": d,
                                    "concurrent_tasks": rng.randint(5, 40),
                                    "queued_tasks": int(round(queued_data.get(d, 0))),
                                }
                            )
                        environments[env_name] = {"daily": daily}
                    except Exception:
                        logger.warning(
                            "CW query failed for MWAA worker task execution", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_worker_task_execution failed")
            return self._mock_fallback(self._mock_mwaa_worker_task_execution, days)

    # ── MWAA Triggerer Resources ──────────────────────────

    def get_mwaa_triggerer_resources(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_triggerer_resources, self._cw_mwaa_triggerer_resources, days
        )

    def _mock_mwaa_triggerer_resources(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_triggerer_resources")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(rng.uniform(3, 15), 1),
                        "active_triggers": rng.randint(0, 3),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_triggerer_resources(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Function", "Value": "Trigger"},
                ]
                trigger_data = self._query_cw_daily(
                    cw, "AmazonMWAA", "TriggersRunning", dims, days, "Maximum"
                )
                return env_name, trigger_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, trigger_data = f.result()
                        rng = _seeded_rng(f"mock_mwaa_triggerer_resources_{env_name}")
                        daily = []
                        for d in dates:
                            daily.append(
                                {
                                    "date": d,
                                    "cpu_pct": round(rng.uniform(3, 15), 1),
                                    "active_triggers": int(trigger_data.get(d, 0)),
                                }
                            )
                        environments[env_name] = {"daily": daily}
                    except Exception:
                        logger.warning(
                            "CW query failed for MWAA triggerer resources", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_triggerer_resources failed")
            return self._mock_fallback(self._mock_mwaa_triggerer_resources, days)

    # ── MWAA WebServer Resources ──────────────────────────

    def get_mwaa_webserver_resources(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_webserver_resources, self._cw_mwaa_webserver_resources, days
        )

    def _mock_mwaa_webserver_resources(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_webserver_resources")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                base_cpu = 8 if is_weekend else 22
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(base_cpu + rng.uniform(-4, 10), 1),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_webserver_resources(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "Cluster", "Value": "WebServer"},
                ]
                cpu_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims, days, "Average"
                )
                return env_name, cpu_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, cpu_data = f.result()
                        daily = []
                        for d in dates:
                            daily.append(
                                {
                                    "date": d,
                                    "cpu_pct": round(cpu_data.get(d, 0), 1),
                                }
                            )
                        environments[env_name] = {"daily": daily}
                    except Exception:
                        logger.warning(
                            "CW query failed for MWAA webserver resources", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_webserver_resources failed")
            return self._mock_fallback(self._mock_mwaa_webserver_resources, days)

    # ── MWAA Database Resources ───────────────────────────

    def get_mwaa_database_resources(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_database_resources, self._cw_mwaa_database_resources, days
        )

    def _mock_mwaa_database_resources(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_database_resources")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(rng.uniform(3, 18), 1),
                        "connections": rng.randint(10, 50),
                        "max_connections": 200,
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_database_resources(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                dims = [
                    {"Name": "Environment", "Value": env_name},
                    {"Name": "DatabaseRole", "Value": "WRITER"},
                ]
                cpu_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "CPUUtilization", dims, days, "Average"
                )
                conn_data = self._query_cw_daily(
                    cw, "AWS/MWAA", "DatabaseConnections", dims, days, "Maximum"
                )
                return env_name, cpu_data, conn_data

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, cpu_data, conn_data = f.result()
                        daily = []
                        for d in dates:
                            daily.append(
                                {
                                    "date": d,
                                    "cpu_pct": round(cpu_data.get(d, 0), 1),
                                    "connections": int(conn_data.get(d, 0)),
                                    "max_connections": 200,
                                }
                            )
                        environments[env_name] = {"daily": daily}
                    except Exception:
                        logger.warning("CW query failed for MWAA database resources", exc_info=True)
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_database_resources failed")
            return self._mock_fallback(self._mock_mwaa_database_resources, days)

    # ── MWAA Database Health ──────────────────────────────

    def get_mwaa_database_health(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_mwaa_database_health, self._cw_mwaa_database_health, days)

    def _mock_mwaa_database_health(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_database_health")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in ["bdp-airflow-dlk", "bdp-airflow-wfl"]:
            daily = []
            base_size = 550 if "dlk" in env_name else 350
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "db_size_mb": base_size + rng.randint(-10, 20),
                        "health": "healthy",
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}

    def _cw_mwaa_database_health(self, days: int) -> dict[str, Any]:
        return self._mock_fallback(self._mock_mwaa_database_health, days)

    # ── MWAA Storage DAG Bucket ───────────────────────────

    def get_mwaa_storage_dag_bucket(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_storage_dag_bucket, self._cw_mwaa_storage_dag_bucket, days
        )

    def _mock_mwaa_storage_dag_bucket(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_mwaa_storage_dag_bucket")
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", "bdp-airflow-dlk-dags", 120, 180),
            ("bdp-airflow-wfl", "bdp-airflow-wfl-dags", 50, 90),
        ]
        for env_name, bucket_name, min_mb, max_mb in configs:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "size_mb": rng.randint(min_mb, max_mb),
                        "object_count": rng.randint(200, 500),
                    }
                )
            environments[env_name] = {
                "bucket_name": bucket_name,
                "daily": daily,
            }
        return {"environments": environments}

    def _cw_mwaa_storage_dag_bucket(self, days: int) -> dict[str, Any]:
        try:
            mwaa = self._get_client("mwaa")
            s3 = self._get_client("s3")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                env_detail = mwaa.get_environment(Name=env_name)
                env_cfg = env_detail["Environment"]
                source_arn = env_cfg.get("SourceBucketArn", "")
                dag_path = env_cfg.get("DagS3Path", "dags")
                bucket_name = source_arn.split(":::")[-1] if ":::" in source_arn else source_arn
                total_size = 0
                obj_count = 0
                paginator = s3.get_paginator("list_objects_v2")
                for page in paginator.paginate(Bucket=bucket_name, Prefix=dag_path):
                    for obj in page.get("Contents", []):
                        obj_count += 1
                        total_size += obj.get("Size", 0)
                size_mb = round(total_size / (1024 * 1024), 1)
                return env_name, bucket_name, size_mb, obj_count

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=30):
                    try:
                        env_name, bucket_name, size_mb, obj_count = f.result()
                        daily = [
                            {"date": d, "size_mb": size_mb, "object_count": obj_count}
                            for d in dates
                        ]
                        environments[env_name] = {"bucket_name": bucket_name, "daily": daily}
                    except Exception:
                        logger.warning("S3 query failed for MWAA storage dag bucket", exc_info=True)
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_storage_dag_bucket failed")
            return self._mock_fallback(self._mock_mwaa_storage_dag_bucket, days)

    # ── MWAA Environment Overview ─────────────────────────

    def get_mwaa_environment_overview(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(
            self._mock_mwaa_environment_overview, self._cw_mwaa_environment_overview, days
        )

    def _mock_mwaa_environment_overview(self, days: int = 31) -> dict[str, Any]:
        environments: dict[str, Any] = {}
        configs = [
            ("bdp-airflow-dlk", "2.8.1", "mw1.xlarge", "AVAILABLE"),
            ("bdp-airflow-wfl", "2.8.1", "mw1.medium", "AVAILABLE"),
        ]
        for env_name, version, env_class, status in configs:
            environments[env_name] = {
                "airflow_version": version,
                "environment_class": env_class,
                "status": status,
                "last_update": _daily_dates(1)[0],
            }
        return {"environments": environments}

    def _cw_mwaa_environment_overview(self, days: int = 31) -> dict[str, Any]:
        try:
            mwaa = self._get_client("mwaa")
            env_names = self._list_mwaa_environments()
            if not env_names:
                return {"environments": {}}
            environments: dict[str, Any] = {}

            def _fetch(env_name: str):
                env_detail = mwaa.get_environment(Name=env_name)
                env_cfg = env_detail["Environment"]
                last_update = env_cfg.get("LastUpdate", {})
                last_update_str = ""
                if isinstance(last_update, dict):
                    updated_at = last_update.get("CreatedAt")
                    if updated_at and hasattr(updated_at, "astimezone"):
                        last_update_str = updated_at.astimezone(KST).date().isoformat()
                elif hasattr(last_update, "astimezone"):
                    last_update_str = last_update.astimezone(KST).date().isoformat()
                if not last_update_str:
                    last_update_str = _daily_dates(1)[0]
                return env_name, {
                    "airflow_version": env_cfg.get("AirflowVersion", "unknown"),
                    "environment_class": env_cfg.get("EnvironmentClass", "unknown"),
                    "status": env_cfg.get("Status", "UNKNOWN"),
                    "last_update": last_update_str,
                }

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in env_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        env_name, info = f.result()
                        environments[env_name] = info
                    except Exception:
                        logger.warning(
                            "MWAA API query failed for environment overview", exc_info=True
                        )
            return {"environments": environments}
        except Exception:
            logger.exception("_cw_mwaa_environment_overview failed")
            return self._mock_fallback(self._mock_mwaa_environment_overview, days)

    # ── DAG SLA Status ──────────────────────────────────

    def get_dag_sla_status(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_dag_sla_status, self._fetch_dag_sla_status, days)

    def _mock_dag_sla_status(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_dag_sla_status")
        env_configs: dict[str, dict] = {
            "dlk": {
                "sla_target_min": 60,
                "dags": [
                    ("Top01", 55),
                    ("Top02", 48),
                    ("Top03", 44),
                    ("Top04", 42),
                    ("Top05", 40),
                    ("Top06", 38),
                    ("Top07", 35),
                    ("Top08", 30),
                    ("Top09", 28),
                    ("Top10", 25),
                ],
            },
            "wfl": {
                "sla_target_min": 45,
                "dags": [
                    ("Top01", 40),
                    ("Top02", 35),
                    ("Top03", 32),
                    ("Top04", 28),
                    ("Top05", 24),
                    ("Top06", 22),
                    ("Top07", 20),
                    ("Top08", 18),
                    ("Top09", 15),
                    ("Top10", 12),
                ],
            },
        }
        environments: dict[str, Any] = {}
        for env_name, cfg in env_configs.items():
            sla_target = cfg["sla_target_min"]
            dags: dict[str, list] = {}
            for dag_id, base_min in cfg["dags"]:
                series = []
                for d in _daily_dates(days):
                    dur = round(base_min + rng.uniform(-8, 15), 1)
                    if rng.random() < 0.08:
                        dur = round(base_min * 1.6 + rng.uniform(0, 12), 1)
                    series.append({"date": d, "duration_min": dur})
                dags[dag_id] = series
            environments[env_name] = {"sla_target_min": sla_target, "dags": dags}
        return {"environments": environments}

    def _fetch_dag_sla_status(self, days: int) -> dict[str, Any]:
        """DAG SLA 현황 조회 (wfl_awf_hst + athena_meta_tbl)."""
        try:
            now = datetime.now(KST)
            start = (now - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")

            # Phase A: DAG별 SLA 목표 조회
            sla_rows = self._query_wfl_awf_hst(
                "SELECT dag_id, wrk_sla_mn FROM athena_meta_tbl "
                "WHERE dag_id LIKE 'bdp-awf-dlk-%%' AND wrk_sla_mn IS NOT NULL",
                (),
            )
            sla_map: dict[str, float] = {}
            for row in sla_rows:
                sla_map[row["dag_id"]] = float(row["wrk_sla_mn"])

            # Phase B: DAG별 일별 실행 시간 조회
            rows = self._query_wfl_awf_hst(
                "SELECT rcpt_tp, dag_id, DATE(start_date) AS run_date, "
                "AVG(duration) AS avg_duration_sec "
                "FROM wfl_awf_hst "
                "WHERE state = 'success' AND start_date >= %s "
                "GROUP BY rcpt_tp, dag_id, DATE(start_date) "
                "ORDER BY rcpt_tp, dag_id, run_date",
                (start,),
            )
            if not rows:
                return {"environments": {}}

            # rcpt_tp → 환경명 매핑
            env_map = {"batch": "dlk", "wfl": "wfl"}

            # 환경별 DAG별 일별 duration 집계
            env_dag_data: dict[str, dict[str, dict[str, float]]] = defaultdict(
                lambda: defaultdict(dict)
            )
            for row in rows:
                env_name = env_map.get(row["rcpt_tp"])
                if not env_name:
                    continue
                dag_id = row["dag_id"]
                d = (
                    row["run_date"].isoformat()
                    if hasattr(row["run_date"], "isoformat")
                    else str(row["run_date"])
                )
                duration_min = float(row["avg_duration_sec"]) / 60.0
                env_dag_data[env_name][dag_id][d] = round(duration_min, 1)

            # 환경별 Top 10 DAG 선택 (평균 duration 기준)
            dates = _daily_dates(days)
            environments: dict[str, Any] = {}

            for env_name, dag_dict in env_dag_data.items():
                # DAG별 전체 기간 평균 duration 계산
                dag_avg = {}
                for dag_id, date_dur in dag_dict.items():
                    vals = list(date_dur.values())
                    dag_avg[dag_id] = sum(vals) / len(vals) if vals else 0

                # 상위 Top 10
                top_dags = sorted(dag_avg, key=lambda x: dag_avg[x], reverse=True)[:10]

                dags: dict[str, Any] = {}
                max_sla = 0.0
                for dag_id in top_dags:
                    dag_sla = sla_map.get(dag_id)
                    if dag_sla and dag_sla > max_sla:
                        max_sla = dag_sla
                    series = [
                        {"date": d, "duration_min": dag_dict[dag_id].get(d, 0.0)} for d in dates
                    ]
                    dags[dag_id] = series

                environments[env_name] = {
                    "sla_target_min": max_sla if max_sla > 0 else 60,
                    "dags": dags,
                }

            return {"environments": environments}
        except Exception:
            logger.exception("_fetch_dag_sla_status failed")
            return {"environments": {}}

    # ── DAG Interface Rates ─────────────────────────────

    def get_dag_interface_rates(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_dag_interface_rates, self._fetch_dag_interface_rates, days)

    def _mock_dag_interface_rates(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_dag_interface_rates")
        dates = _daily_dates(days)
        categories: dict[str, dict] = {}

        configs = [
            ("on-prem 파일전송", 12, 0.92, 0.06),  # 일 평균 12건, 기본 92% 성공, 6% 확률 bad day
            ("univ 데이터전송", 8, 0.95, 0.05),  # 일 평균 8건, 기본 95% 성공, 5% 확률 bad day
        ]
        for cat_name, base_total, base_rate, bad_prob in configs:
            daily_rates = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                total = max(1, base_total + rng.randint(-3, 3))
                if is_weekend:
                    total = max(1, total // 2)

                is_bad = rng.random() < bad_prob
                if is_bad:
                    success = int(total * rng.uniform(0.65, 0.85))
                else:
                    success = int(total * rng.uniform(base_rate, 1.0))
                success = min(success, total)

                rate = round((success / total) * 100, 1) if total > 0 else 0.0
                daily_rates.append(
                    {
                        "date": d,
                        "success_rate": rate,
                        "total": total,
                        "success": success,
                    }
                )
            categories[cat_name] = {"daily_rates": daily_rates}

        return {"categories": categories}

    def _fetch_dag_interface_rates(self, days: int) -> dict[str, Any]:
        # SKIP: 카테고리 분류 규칙 별도 논의 필요 — mock fallback 유지
        return self._mock_fallback(self._mock_dag_interface_rates, days)

    # ── RDS Connections ──────────────────────────────

    def get_rds_connections(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_rds_connections, self._cw_rds_connections, days)

    def _mock_rds_connections(self, days: int) -> dict[str, Any]:
        dates = _daily_dates(days)
        instances: dict[str, list] = {}
        configs = [
            ("bdp-main-db", 80, 15),
            ("bdp-analytics-db", 120, 25),
            ("bdp-airflow-meta", 30, 8),
            ("bdp-hive-metastore", 20, 5),
        ]
        for name, base, jitter in configs:
            instances[name] = _rand_series(dates, base, jitter, seed_key=f"rds_conn_{name}")
        return {"instances": instances}

    def _cw_rds_connections(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            db_ids = self._list_rds_instances()
            if not db_ids:
                return {"instances": {}}
            dates = _daily_dates(days)
            instances: dict[str, list] = {}

            def _fetch(db_id: str):
                dims = [{"Name": "DBInstanceIdentifier", "Value": db_id}]
                return db_id, self._query_cw_daily(cw, "AWS/RDS", "DatabaseConnections", dims, days)

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, db_id) for db_id in db_ids]
                for f in as_completed(futures, timeout=20):
                    try:
                        db_id, cw_data = f.result()
                        instances[db_id] = [
                            {"date": d, "value": round(cw_data.get(d, 0), 1)} for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for RDS connections", exc_info=True)
            return {"instances": instances}
        except Exception:
            logger.exception("_cw_rds_connections failed")
            return {"instances": {}}

    # ── RDS CPU ──────────────────────────────────────

    def get_rds_cpu(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_rds_cpu, self._cw_rds_cpu, days)

    def _mock_rds_cpu(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_rds_cpu")
        dates = _daily_dates(days)
        instances: dict[str, list] = {}
        configs = [
            ("bdp-main-db", 35, 10),
            ("bdp-analytics-db", 55, 15),
            ("bdp-airflow-meta", 20, 8),
            ("bdp-hive-metastore", 15, 5),
        ]
        for name, base, jitter in configs:
            data = []
            val = base
            for d in dates:
                drift = rng.uniform(-jitter, jitter)
                val = max(0, min(100, val + drift))
                if rng.random() < 0.05:
                    val = min(100, base * 2.5)
                data.append({"date": d, "value": round(val, 1)})
                if val > base * 2:
                    val = base + rng.uniform(-jitter, jitter)
            instances[name] = data
        return {"instances": instances}

    def _cw_rds_cpu(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            db_ids = self._list_rds_instances()
            if not db_ids:
                return {"instances": {}}
            dates = _daily_dates(days)
            instances: dict[str, list] = {}

            def _fetch(db_id: str):
                dims = [{"Name": "DBInstanceIdentifier", "Value": db_id}]
                return db_id, self._query_cw_daily(cw, "AWS/RDS", "CPUUtilization", dims, days)

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, db_id) for db_id in db_ids]
                for f in as_completed(futures, timeout=20):
                    try:
                        db_id, cw_data = f.result()
                        instances[db_id] = [
                            {"date": d, "value": round(cw_data.get(d, 0), 1)} for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for RDS CPU", exc_info=True)
            return {"instances": instances}
        except Exception:
            logger.exception("_cw_rds_cpu failed")
            return {"instances": {}}

    # ── RDS Memory ───────────────────────────────────

    def get_rds_memory(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_rds_memory, self._cw_rds_memory, days)

    def _mock_rds_memory(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_rds_memory")
        dates = _daily_dates(days)
        instances: dict[str, list] = {}
        configs = [
            ("bdp-main-db", 12.0, 1.5, 50, 15),
            ("bdp-analytics-db", 20.0, 3.0, 80, 20),
            ("bdp-airflow-meta", 6.0, 0.8, 30, 10),
            ("bdp-hive-metastore", 5.0, 0.6, 20, 8),
        ]
        for name, free_base, free_jitter, swap_base, swap_jitter in configs:
            data = []
            free_val = free_base
            swap_val = float(swap_base)
            for d in dates:
                free_val = max(0.5, free_val + rng.uniform(-free_jitter, free_jitter))
                swap_val = max(0, swap_val + rng.uniform(-swap_jitter, swap_jitter))
                data.append(
                    {
                        "date": d,
                        "freeable_gb": round(free_val, 2),
                        "swap_mb": round(swap_val, 1),
                    }
                )
            instances[name] = data
        return {"instances": instances}

    def _cw_rds_memory(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            db_ids = self._list_rds_instances()
            if not db_ids:
                return {"instances": {}}
            dates = _daily_dates(days)
            instances: dict[str, list] = {}

            def _fetch(db_id: str):
                dims = [{"Name": "DBInstanceIdentifier", "Value": db_id}]
                free = self._query_cw_daily(cw, "AWS/RDS", "FreeableMemory", dims, days)
                swap = self._query_cw_daily(cw, "AWS/RDS", "SwapUsage", dims, days)
                return db_id, free, swap

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, db_id) for db_id in db_ids]
                for f in as_completed(futures, timeout=20):
                    try:
                        db_id, free_data, swap_data = f.result()
                        instances[db_id] = [
                            {
                                "date": d,
                                "freeable_gb": round(free_data.get(d, 0) / (1024**3), 2),
                                "swap_mb": round(swap_data.get(d, 0) / (1024**2), 1),
                            }
                            for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for RDS memory", exc_info=True)
            return {"instances": instances}
        except Exception:
            logger.exception("_cw_rds_memory failed")
            return {"instances": {}}

    # ── RDS IOPS ─────────────────────────────────────

    def get_rds_iops(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_rds_iops, self._cw_rds_iops, days)

    def _mock_rds_iops(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_rds_iops")
        dates = _daily_dates(days)
        instances: dict[str, list] = {}
        configs = [
            ("bdp-main-db", 800, 200, 400, 100),
            ("bdp-analytics-db", 1500, 400, 300, 80),
            ("bdp-airflow-meta", 200, 60, 150, 40),
            ("bdp-hive-metastore", 150, 40, 100, 30),
        ]
        for name, read_base, read_jitter, write_base, write_jitter in configs:
            data = []
            read_val = float(read_base)
            write_val = float(write_base)
            for d in dates:
                read_val = max(0, read_val + rng.uniform(-read_jitter, read_jitter))
                write_val = max(0, write_val + rng.uniform(-write_jitter, write_jitter))
                if rng.random() < 0.05:
                    read_val = read_base * 3
                    write_val = write_base * 2.5
                data.append(
                    {
                        "date": d,
                        "read_iops": round(read_val),
                        "write_iops": round(write_val),
                    }
                )
                if read_val > read_base * 2:
                    read_val = read_base + rng.uniform(-read_jitter, read_jitter)
                if write_val > write_base * 2:
                    write_val = write_base + rng.uniform(-write_jitter, write_jitter)
            instances[name] = data
        return {"instances": instances}

    def _cw_rds_iops(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            db_ids = self._list_rds_instances()
            if not db_ids:
                return {"instances": {}}
            dates = _daily_dates(days)
            instances: dict[str, list] = {}

            def _fetch(db_id: str):
                dims = [{"Name": "DBInstanceIdentifier", "Value": db_id}]
                read = self._query_cw_daily(cw, "AWS/RDS", "ReadIOPS", dims, days)
                write = self._query_cw_daily(cw, "AWS/RDS", "WriteIOPS", dims, days)
                return db_id, read, write

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, db_id) for db_id in db_ids]
                for f in as_completed(futures, timeout=20):
                    try:
                        db_id, read_data, write_data = f.result()
                        instances[db_id] = [
                            {
                                "date": d,
                                "read_iops": round(read_data.get(d, 0)),
                                "write_iops": round(write_data.get(d, 0)),
                            }
                            for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for RDS IOPS", exc_info=True)
            return {"instances": instances}
        except Exception:
            logger.exception("_cw_rds_iops failed")
            return {"instances": {}}

    # ── RDS Storage Free ─────────────────────────────

    def get_rds_storage_free(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_rds_storage_free, self._cw_rds_storage_free, days)

    def _mock_rds_storage_free(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_rds_storage_free")
        dates = _daily_dates(days)
        instances: dict[str, list] = {}
        configs = [
            ("bdp-main-db", 280, 3),
            ("bdp-analytics-db", 450, 5),
            ("bdp-airflow-meta", 150, 1),
            ("bdp-hive-metastore", 75, 0.5),
        ]
        for name, base, daily_decrease in configs:
            data = []
            val = base
            for d in dates:
                val = max(5, val - rng.uniform(0, daily_decrease * 2))
                data.append({"date": d, "value": round(val, 1)})
            instances[name] = data
        return {"instances": instances}

    def _cw_rds_storage_free(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            db_ids = self._list_rds_instances()
            if not db_ids:
                return {"instances": {}}
            dates = _daily_dates(days)
            instances: dict[str, list] = {}

            def _fetch(db_id: str):
                dims = [{"Name": "DBInstanceIdentifier", "Value": db_id}]
                return db_id, self._query_cw_daily(cw, "AWS/RDS", "FreeStorageSpace", dims, days)

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, db_id) for db_id in db_ids]
                for f in as_completed(futures, timeout=20):
                    try:
                        db_id, cw_data = f.result()
                        instances[db_id] = [
                            {"date": d, "value": round(cw_data.get(d, 0) / (1024**3), 1)}
                            for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for RDS storage", exc_info=True)
            return {"instances": instances}
        except Exception:
            logger.exception("_cw_rds_storage_free failed")
            return {"instances": {}}

    # ── Ingestion Rates ──────────────────────────────────

    def get_ingestion_rates(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_ingestion_rates, self._fetch_ingestion_rates, days)

    # L0 소스 시스템 (프론트엔드 L0_SOURCES와 동일)
    _L0_SOURCE_SYSTEMS = [
        {"name": "BCV", "avg": 50},
        {"name": "DW", "avg": 30},
        {"name": "EAI", "avg": 25},
        {"name": "CDC", "avg": 40},
        {"name": "FTP", "avg": 15},
        {"name": "API", "avg": 35},
        {"name": "S3", "avg": 20},
        {"name": "Kafka", "avg": 45},
        {"name": "SFTP", "avg": 12},
        {"name": "MQ", "avg": 18},
    ]

    def _mock_ingestion_rates(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_ingestion_rates")
        dates = _daily_dates(days)
        sources = self._L0_SOURCE_SYSTEMS

        def _gen_layer(scale: float) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
            daily_success: list[dict] = []
            daily_failure: list[dict] = []
            for d in dates:
                s_row: dict[str, Any] = {"date": d}
                f_row: dict[str, Any] = {"date": d}
                for src in sources:
                    total = int(
                        (src["avg"] * scale) + (rng.random() - 0.5) * src["avg"] * scale * 0.4
                    )
                    fail_rate = 0.02 + rng.random() * 0.08
                    fail = max(0, round(total * fail_rate))
                    s_row[src["name"]] = max(0, total - fail)
                    f_row[src["name"]] = fail
                daily_success.append(s_row)
                daily_failure.append(f_row)

            today = datetime.now(KST).date()
            months: list[str] = []
            for i in range(5, -1, -1):
                dt = today.replace(day=1) - timedelta(days=i * 28)
                months.append(dt.strftime("%Y-%m"))
            months = sorted(set(months))[-6:]
            current_month = today.strftime("%Y-%m")

            monthly_success: list[dict] = []
            monthly_failure: list[dict] = []
            for month in months:
                s_row: dict[str, Any] = {"month": month}
                f_row: dict[str, Any] = {"month": month}
                days_in_month = today.day if month == current_month else 30
                for src in sources:
                    total_month = int(
                        src["avg"] * scale * days_in_month
                        + (rng.random() - 0.5) * src["avg"] * scale * days_in_month * 0.2
                    )
                    fail_rate = 0.03 + rng.random() * 0.05
                    fail = max(0, round(total_month * fail_rate))
                    s_row[src["name"]] = max(0, total_month - fail)
                    f_row[src["name"]] = fail
                monthly_success.append(s_row)
                monthly_failure.append(f_row)

            return daily_success, daily_failure, monthly_success, monthly_failure

        l0_ds, l0_df, l0_ms, l0_mf = _gen_layer(1.0)
        l1_ds, l1_df, l1_ms, l1_mf = _gen_layer(0.6)

        return {
            "l0_daily_success": l0_ds,
            "l0_daily_failure": l0_df,
            "l0_monthly_success": l0_ms,
            "l0_monthly_failure": l0_mf,
            "l1_daily_success": l1_ds,
            "l1_daily_failure": l1_df,
            "l1_monthly_success": l1_ms,
            "l1_monthly_failure": l1_mf,
        }

    def _fetch_ingestion_rates(self, days: int) -> dict[str, Any]:
        """Ingestion Rates 조회 (wfl_awf_hst + athena_meta_tbl, L0+L1)."""
        empty = {
            "l0_daily_success": [],
            "l0_daily_failure": [],
            "l0_monthly_success": [],
            "l0_monthly_failure": [],
            "l1_daily_success": [],
            "l1_daily_failure": [],
            "l1_monthly_success": [],
            "l1_monthly_failure": [],
        }
        try:
            now = datetime.now(KST)
            start = (now - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")

            # 소스 시스템 목록 로드 (longest-match용)
            known_sources = self._load_known_sources()
            logger.debug("known_sources: %s", known_sources)

            # Phase A: ETL DAG 목록 확보
            meta_rows = self._query_wfl_awf_hst(
                "SELECT DISTINCT dag_id FROM athena_meta_tbl WHERE dag_id LIKE 'bdp-awf-dlk-%%'",
                (),
            )
            if not meta_rows:
                return empty
            etl_dag_ids = {row["dag_id"] for row in meta_rows}
            logger.info("Phase A: %d ETL DAGs from athena_meta_tbl", len(etl_dag_ids))

            # Phase B: DAG 실행 현황 집계
            rows = self._query_wfl_awf_hst(
                "SELECT dag_id, task_id, DATE(start_date) AS run_date, state "
                "FROM wfl_awf_hst "
                "WHERE rcpt_tp = 'batch' "
                "AND task_id LIKE 'emr\\_group.%%' "
                "AND start_date >= %s "
                "ORDER BY run_date, dag_id",
                (start,),
            )
            if not rows:
                return empty
            logger.info("Phase B: %d rows from wfl_awf_hst", len(rows))

            # 레이어 판별: emr_group. 뒤 부분을 _ 토큰으로 분리하여 l0/l1 확인
            def _detect_layer(task_id: str) -> str | None:
                suffix = task_id.split(".", 1)[1] if "." in task_id else task_id
                tokens = suffix.lower().split("_")
                if "l0" in tokens:
                    return "l0"
                if "l1" in tokens:
                    return "l1"
                return None

            # (dag_id, run_date, layer) 별 성공/실패 판정
            dag_date_states: dict[tuple[str, str, str], bool] = {}
            for row in rows:
                dag_id = row["dag_id"]
                if dag_id not in etl_dag_ids:
                    continue
                layer = _detect_layer(row.get("task_id", ""))
                if layer is None:
                    continue
                d = (
                    row["run_date"].isoformat()
                    if hasattr(row["run_date"], "isoformat")
                    else str(row["run_date"])
                )
                key = (dag_id, d, layer)
                is_success = row["state"] == "success"
                if key not in dag_date_states:
                    dag_date_states[key] = is_success
                elif not is_success:
                    dag_date_states[key] = False

            unique_dags = {dag_id for dag_id, _, _ in dag_date_states}
            logger.info(
                "dag_date_states: %d entries, %d unique DAGs",
                len(dag_date_states),
                len(unique_dags),
            )

            # 소스시스템 추출: bdp-awf-dlk-{소스}-{테이블명}
            # known_sources 기반 longest-match
            def _extract_source(dag_id: str) -> str | None:
                suffix = dag_id.removeprefix("bdp-awf-dlk-").lower()
                for src in known_sources:
                    if suffix == src or suffix.startswith(src + "-"):
                        return src.upper()
                return None  # 매칭 실패 → 스킵

            # 레이어별 소스시스템별 일별 rollup
            layer_daily_success: dict[str, dict[str, dict[str, int]]] = {
                "l0": defaultdict(lambda: defaultdict(int)),
                "l1": defaultdict(lambda: defaultdict(int)),
            }
            layer_daily_failure: dict[str, dict[str, dict[str, int]]] = {
                "l0": defaultdict(lambda: defaultdict(int)),
                "l1": defaultdict(lambda: defaultdict(int)),
            }
            matched_sources: set[str] = set()
            unmatched_dags: set[str] = set()
            for (dag_id, d, layer), success in dag_date_states.items():
                src = _extract_source(dag_id)
                if src is None:
                    unmatched_dags.add(dag_id)
                    continue
                matched_sources.add(src)
                if success:
                    layer_daily_success[layer][d][src] += 1
                else:
                    layer_daily_failure[layer][d][src] += 1

            logger.info("Matched sources: %s", sorted(matched_sources))
            if unmatched_dags:
                logger.warning(
                    "Unmatched DAGs (%d): %s", len(unmatched_dags), sorted(unmatched_dags)[:10]
                )

            dates = _daily_dates(days)
            result: dict[str, Any] = {}

            for layer in ("l0", "l1"):
                ds = layer_daily_success[layer]
                df = layer_daily_failure[layer]

                all_sources = sorted(
                    {src for by_src in [*ds.values(), *df.values()] for src in by_src}
                )

                daily_success: list[dict] = []
                daily_failure: list[dict] = []
                for d in dates:
                    s_row: dict[str, Any] = {"date": d}
                    f_row: dict[str, Any] = {"date": d}
                    for src in all_sources:
                        s_row[src] = ds.get(d, {}).get(src, 0)
                        f_row[src] = df.get(d, {}).get(src, 0)
                    daily_success.append(s_row)
                    daily_failure.append(f_row)

                # 월별 rollup
                monthly_success: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
                monthly_failure: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
                for d in dates:
                    month = d[:7]
                    for src in all_sources:
                        monthly_success[month][src] += ds.get(d, {}).get(src, 0)
                        monthly_failure[month][src] += df.get(d, {}).get(src, 0)

                months = sorted(monthly_success.keys())
                m_success: list[dict] = []
                m_failure: list[dict] = []
                for month in months:
                    s_row = {"month": month}
                    f_row = {"month": month}
                    for src in all_sources:
                        s_row[src] = monthly_success[month].get(src, 0)
                        f_row[src] = monthly_failure[month].get(src, 0)
                    m_success.append(s_row)
                    m_failure.append(f_row)

                result[f"{layer}_daily_success"] = daily_success
                result[f"{layer}_daily_failure"] = daily_failure
                result[f"{layer}_monthly_success"] = m_success
                result[f"{layer}_monthly_failure"] = m_failure

            return result
        except Exception:
            logger.exception("_fetch_ingestion_rates failed")
            return empty

    # ── Lambda Errors ─────────────────────────────────

    def get_lambda_errors(self, days: int = 31) -> dict[str, Any]:
        return self._resolve(self._mock_lambda_errors, self._cw_lambda_errors, days)

    def _mock_lambda_errors(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_lambda_errors")
        dates = _daily_dates(days)
        functions: dict[str, list] = {}
        configs = [
            ("bdp-event-processor", 2, 0.10),
            ("bdp-data-transformer", 1, 0.08),
            ("bdp-notification-sender", 0, 0.06),
            ("bdp-log-aggregator", 1, 0.12),
        ]
        for name, base, spike_prob in configs:
            data = []
            for d in dates:
                errors = rng.randint(0, base + 2)
                if rng.random() < spike_prob:
                    errors += rng.randint(5, 25)
                data.append({"date": d, "errors": errors})
            functions[name] = data
        return {"functions": functions}

    def _cw_lambda_errors(self, days: int) -> dict[str, Any]:
        try:
            cw = self._get_client("cloudwatch")
            fn_names = self._list_lambda_functions()
            if not fn_names:
                return {"functions": {}}
            dates = _daily_dates(days)
            all_functions: dict[str, list] = {}

            def _fetch(fn_name: str):
                dims = [{"Name": "FunctionName", "Value": fn_name}]
                return fn_name, self._query_cw_daily(cw, "AWS/Lambda", "Errors", dims, days, "Sum")

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = [executor.submit(_fetch, n) for n in fn_names]
                for f in as_completed(futures, timeout=20):
                    try:
                        fn_name, cw_data = f.result()
                        all_functions[fn_name] = [
                            {"date": d, "errors": int(cw_data.get(d, 0))} for d in dates
                        ]
                    except Exception:
                        logger.warning("CW query failed for Lambda errors", exc_info=True)

            # Top 10 + etc 롤업 (에러 합계 기준)
            if len(all_functions) <= 10:
                return {"functions": all_functions}

            sorted_names = sorted(
                all_functions.keys(),
                key=lambda n: sum(pt["errors"] for pt in all_functions[n]),
                reverse=True,
            )
            top_names = sorted_names[:10]
            etc_names = sorted_names[10:]

            functions: dict[str, list] = {}
            for name in top_names:
                functions[name] = all_functions[name]

            if etc_names:
                etc_data = []
                for i, d in enumerate(dates):
                    total_errors = sum(all_functions[n][i]["errors"] for n in etc_names)
                    etc_data.append({"date": d, "errors": total_errors})
                functions["etc"] = etc_data

            return {"functions": functions}
        except Exception:
            logger.exception("_cw_lambda_errors failed")
            return {"functions": {}}

    # ── Glue Table Versions ────────────────────────────

    def get_glue_table_versions(self, days: int = 31) -> dict[str, Any]:
        now = time.monotonic()
        if self._glue_cache and (now - self._glue_cache_time) < self._GLUE_CACHE_TTL:
            return self._glue_cache
        # 파일 캐시 확인 (다른 워커가 저장한 것)
        file_data = _load_file_cache("glue-table-versions", self._GLUE_CACHE_TTL)
        if file_data:
            self._glue_cache = file_data
            self._glue_cache_time = now
            return file_data
        result = self._resolve(self._mock_glue_table_versions, self._cw_glue_table_versions, days)
        self._glue_cache = result
        self._glue_cache_time = now
        _save_file_cache("glue-table-versions", result)
        return result

    def _mock_glue_table_versions(self, days: int) -> dict[str, Any]:
        rng = _seeded_rng("mock_glue_table_versions")
        dates = _daily_dates(days)
        # 15개 테이블 설정 (top 10 + 나머지 5개는 etc로 합산)
        table_configs = [
            ("bdp_raw.user_events", 5, 0.18),
            ("bdp_raw.click_logs", 4, 0.15),
            ("bdp_raw.page_views", 3, 0.12),
            ("bdp_processed.user_sessions", 3, 0.14),
            ("bdp_processed.funnel_metrics", 2, 0.10),
            ("bdp_raw.api_logs", 2, 0.12),
            ("bdp_curated.daily_kpi", 2, 0.08),
            ("bdp_processed.event_agg", 2, 0.10),
            ("bdp_ml_features.user_vectors", 1, 0.08),
            ("bdp_curated.weekly_report", 1, 0.06),
            # 나머지 5개 → etc로 합산
            ("bdp_raw.error_logs", 1, 0.05),
            ("bdp_processed.ab_results", 1, 0.04),
            ("bdp_ml_features.item_vectors", 1, 0.05),
            ("bdp_curated.monthly_summary", 0, 0.03),
            ("bdp_raw.system_metrics", 1, 0.04),
        ]
        all_tables: dict[str, list] = {}
        for name, base, spike_prob in table_configs:
            data = []
            cumulative = rng.randint(10, 50)
            for d in dates:
                changes = rng.randint(0, base)
                if rng.random() < spike_prob:
                    changes += rng.randint(3, 10)
                cumulative += changes
                data.append({"date": d, "version_changes": changes, "cumulative": cumulative})
            all_tables[name] = data

        # 누적 최종값 기준 top 10 선정
        sorted_names = sorted(
            all_tables.keys(),
            key=lambda n: all_tables[n][-1]["cumulative"],
            reverse=True,
        )
        top_names = sorted_names[:10]
        etc_names = sorted_names[10:]

        tables: dict[str, list] = {}
        for name in top_names:
            tables[name] = all_tables[name]

        # etc 합산
        if etc_names:
            etc_data = []
            for i, d in enumerate(dates):
                changes = sum(all_tables[n][i]["version_changes"] for n in etc_names)
                cumulative = sum(all_tables[n][i]["cumulative"] for n in etc_names)
                etc_data.append({"date": d, "version_changes": changes, "cumulative": cumulative})
            tables["etc"] = etc_data

        # 전체 합계
        total_series: list[dict[str, Any]] = []
        total_cumulative = rng.randint(60, 100)
        for i, d in enumerate(dates):
            day_total = sum(all_tables[n][i]["version_changes"] for n in all_tables)
            total_cumulative += day_total
            total_series.append(
                {"date": d, "version_changes": day_total, "cumulative": total_cumulative}
            )

        return {"tables": tables, "total": total_series, "quota_limit": 1_000_000}

    def _cw_glue_table_versions(self, days: int) -> dict[str, Any]:
        """Glue 테이블 버전 히스토리를 API로 조회."""
        try:
            glue = self._get_client("glue")
            dates = _daily_dates(days)
            date_set = set(dates)
            db_prefix = f"{self.settings.resource_prefix}_"

            # 환경별 접두사 DB 수집
            db_names: list[str] = []
            paginator = glue.get_paginator("get_databases")
            for page in paginator.paginate():
                for db in page.get("DatabaseList", []):
                    if db["Name"].startswith(db_prefix):
                        db_names.append(db["Name"])

            if not db_names:
                all_db_names: list[str] = []
                paginator2 = glue.get_paginator("get_databases")
                for page in paginator2.paginate():
                    for db in page.get("DatabaseList", []):
                        all_db_names.append(db["Name"])
                logger.warning(
                    "Glue: '%s' 접두사 DB 없음 (전체 DB: %s) — mock fallback",
                    db_prefix,
                    all_db_names[:20],
                )
                return self._mock_fallback(self._mock_glue_table_versions, days)

            # DB별 테이블 목록 수집
            table_keys: list[tuple[str, str]] = []
            for db_name in db_names:
                tbl_paginator = glue.get_paginator("get_tables")
                for page in tbl_paginator.paginate(DatabaseName=db_name):
                    for tbl in page.get("TableList", []):
                        table_keys.append((db_name, tbl["Name"]))

            if not table_keys:
                logger.warning("Glue: %s DB에 테이블 없음 — mock fallback", db_prefix)
                return self._mock_fallback(self._mock_glue_table_versions, days)

            # 테이블별 버전 변경 히스토리 수집 (병렬)
            all_tables: dict[str, list] = {}

            cutoff = dates[0]  # 조회기간 시작일 (최신순 반환이므로 이전이면 중단)

            def _fetch_versions(db_name: str, tbl_name: str) -> tuple[str, dict[str, int]]:
                daily_counts: dict[str, int] = defaultdict(int)
                ver_paginator = glue.get_paginator("get_table_versions")
                done = False
                for page in ver_paginator.paginate(DatabaseName=db_name, TableName=tbl_name):
                    if done:
                        break
                    for ver in page.get("TableVersions", []):
                        tbl_info = ver.get("Table", {})
                        update_time = tbl_info.get("UpdateTime")
                        if update_time:
                            d = update_time.astimezone(KST).date().isoformat()
                            if d < cutoff:
                                done = True
                                break
                            if d in date_set:
                                daily_counts[d] += 1
                return f"{db_name}.{tbl_name}", daily_counts

            with ThreadPoolExecutor(max_workers=10) as pool:
                futures = [pool.submit(_fetch_versions, db, tbl) for db, tbl in table_keys]
                try:
                    for fut in as_completed(futures, timeout=25):
                        try:
                            full_name, daily_counts = fut.result()
                            cumulative = 0
                            series = []
                            for d in dates:
                                changes = daily_counts.get(d, 0)
                                cumulative += changes
                                series.append(
                                    {
                                        "date": d,
                                        "version_changes": changes,
                                        "cumulative": cumulative,
                                    }
                                )
                            all_tables[full_name] = series
                        except Exception:
                            continue
                except TimeoutError:
                    logger.warning(
                        "Glue table versions 조회 타임아웃: %d/%d 완료",
                        len(all_tables),
                        len(table_keys),
                    )

            if not all_tables:
                logger.warning("Glue: 기간 내 테이블 버전 데이터 없음 — mock fallback")
                return self._mock_fallback(self._mock_glue_table_versions, days)

            # 누적 최종값 기준 top 10 선정
            sorted_names = sorted(
                all_tables.keys(),
                key=lambda n: all_tables[n][-1]["cumulative"],
                reverse=True,
            )
            top_names = sorted_names[:10]
            etc_names = sorted_names[10:]

            tables: dict[str, list] = {}
            for name in top_names:
                tables[name] = all_tables[name]

            if etc_names:
                etc_data = []
                for i, d in enumerate(dates):
                    changes = sum(all_tables[n][i]["version_changes"] for n in etc_names)
                    cumulative = sum(all_tables[n][i]["cumulative"] for n in etc_names)
                    etc_data.append(
                        {"date": d, "version_changes": changes, "cumulative": cumulative}
                    )
                tables["etc"] = etc_data

            total_series: list[dict[str, Any]] = []
            total_cumulative = 0
            for i, d in enumerate(dates):
                day_total = sum(all_tables[n][i]["version_changes"] for n in all_tables)
                total_cumulative += day_total
                total_series.append(
                    {"date": d, "version_changes": day_total, "cumulative": total_cumulative}
                )

            quota_limit = self._get_glue_table_version_quota()
            return {"tables": tables, "total": total_series, "quota_limit": quota_limit}
        except Exception:
            logger.exception("Glue table versions 조회 실패 — mock fallback")
            return self._mock_fallback(self._mock_glue_table_versions, days)

    def _get_glue_table_version_quota(self) -> int:
        """Glue 'Number of versions per table' 쿼타를 Service Quotas API로 조회."""
        try:
            from botocore.config import Config

            from src.common.services.aws_session import get_boto3_client

            client = get_boto3_client(
                "service-quotas",
                config=Config(retries={"max_attempts": 2}, connect_timeout=5, read_timeout=5),
            )
            response = client.get_service_quota(
                ServiceCode="glue",
                QuotaCode="L-97F92E79",  # Number of versions per table
            )
            return int(response.get("Quota", {}).get("Value", 1_000_000))
        except Exception:
            return 1_000_000  # 기본 쿼타 값

    # ── Athena Top Queries ─────────────────────────────

    def _list_athena_workgroups(self) -> list[str]:
        """Athena 워크그룹 목록 조회 (경량 — 단일 API 호출)."""
        try:
            from botocore.config import Config

            from src.common.services.aws_session import get_boto3_client

            athena = get_boto3_client(
                "athena",
                region="ap-northeast-2",
                config=Config(
                    retries={"max_attempts": 3, "mode": "adaptive"},
                    connect_timeout=5,
                    read_timeout=10,
                ),
            )
            workgroups: list[str] = []
            resp = athena.list_work_groups(MaxResults=50)
            for wg in resp.get("WorkGroups", []):
                workgroups.append(wg["Name"])
            while resp.get("NextToken"):
                resp = athena.list_work_groups(MaxResults=50, NextToken=resp["NextToken"])
                for wg in resp.get("WorkGroups", []):
                    workgroups.append(wg["Name"])
            return workgroups or ["primary"]
        except Exception:
            logger.warning("Athena ListWorkGroups 실패 — primary fallback")
            return ["primary"]

    def get_athena_top_queries(
        self, days: int = 31, workgroup: str | None = None
    ) -> dict[str, Any]:
        return self._resolve(
            self._mock_athena_top_queries, self._fetch_athena_top_queries, days, workgroup
        )

    def _mock_athena_top_queries(self, days: int, workgroup: str | None = None) -> dict[str, Any]:
        rng = _seeded_rng("mock_athena_top_queries")
        dates = _daily_dates(days)
        mock_sqls = [
            "SELECT * FROM bdp_lake.user_events WHERE dt = '2026-03-01' AND event_type IN ('click','view','purchase') ORDER BY event_ts DESC LIMIT 10000",
            "SELECT customer_id, SUM(amount) FROM bdp_dw.transactions WHERE tx_date >= '2026-02-01' AND status = 'completed' GROUP BY 1 ORDER BY 2 DESC",
            "SELECT DISTINCT session_id FROM bdp_lake.clickstream WHERE dt BETWEEN '2026-02-01' AND '2026-02-28' AND platform = 'mobile'",
            "INSERT INTO bdp_mart.daily_summary SELECT dt, COUNT(*) AS order_cnt, SUM(amount) AS total_amount FROM bdp_dw.orders WHERE dt = '2026-03-08' GROUP BY dt",
            "SELECT a.*, b.name FROM bdp_lake.logs a JOIN bdp_dw.services b ON a.service_id = b.id WHERE a.log_date >= '2026-03-01' AND a.level = 'ERROR'",
            "CREATE TABLE bdp_mart.monthly_agg AS SELECT DATE_TRUNC('month', dt) AS month, category, SUM(revenue) AS total_revenue FROM bdp_dw.facts GROUP BY 1, 2",
            "SELECT COUNT(*) FROM bdp_lake.raw_data WHERE partition_date = '2026-03-08' AND source = 'kafka' AND schema_version = 'v2'",
            "SELECT product_id, AVG(price) AS avg_price, COUNT(*) AS sale_cnt FROM bdp_dw.products WHERE category = 'electronics' GROUP BY 1 HAVING COUNT(*) > 100",
            "SELECT region, SUM(bytes) AS total_bytes, COUNT(DISTINCT bucket) AS bucket_cnt FROM bdp_lake.s3_access_logs WHERE dt >= '2026-03-01' GROUP BY 1",
            "UNLOAD (SELECT * FROM bdp_dw.export_view WHERE export_date = '2026-03-08') TO 's3://bdp-export/daily/2026-03-08/' WITH (format = 'PARQUET')",
        ]
        # 쿼리별 현실적 스캔량 범위 (상위 쿼리일수록 큰 범위)
        scan_ranges = [
            (15.0, 30.0),
            (12.0, 25.0),
            (10.0, 22.0),
            (8.0, 18.0),
            (6.0, 15.0),
            (4.0, 12.0),
            (3.0, 10.0),
            (2.0, 8.0),
            (1.0, 5.0),
            (0.5, 3.0),
        ]
        queries = []
        for idx, sql in enumerate(mock_sqls):
            lo, hi = scan_ranges[idx]
            daily = []
            for d in dates:
                scan_gb = round(rng.uniform(lo, hi), 2)
                daily.append({"date": d, "scan_gb": scan_gb})
            total = round(sum(pt["scan_gb"] for pt in daily), 2)
            queries.append({"query_label": sql, "daily": daily, "total_scan_gb": total})
        queries.sort(key=lambda q: q["total_scan_gb"], reverse=True)
        return {"queries": queries[:10]}

    def _fetch_athena_top_queries(self, days: int, workgroup: str | None = None) -> dict[str, Any]:
        """Athena 스캔량 Top 10 쿼리를 실제 API로 조회."""
        all_workgroups = self._list_athena_workgroups()

        # 워크그룹 미선택 → 목록만 반환
        if not workgroup:
            return {"queries": [], "workgroups": all_workgroups}

        try:
            from botocore.config import Config

            from src.common.services.aws_session import get_boto3_client

            athena = get_boto3_client(
                "athena",
                region="ap-northeast-2",
                config=Config(
                    retries={"max_attempts": 5, "mode": "adaptive"},
                    connect_timeout=5,
                    read_timeout=10,
                ),
            )
            dates = _daily_dates(days)
            date_set = set(dates)
            cutoff = datetime.now(KST) - timedelta(days=days)

            # 선택된 워크그룹의 query execution ID 수집
            all_exec_ids: list[str] = []
            try:
                pg = athena.get_paginator("list_query_executions")
                for page in pg.paginate(
                    WorkGroup=workgroup,
                    PaginationConfig={"MaxItems": 500},
                ):
                    all_exec_ids.extend(page.get("QueryExecutionIds", []))
            except Exception:
                logger.warning("Athena ListQueryExecutions 실패: wg=%s", workgroup)

            if not all_exec_ids:
                return {"queries": [], "workgroups": all_workgroups}

            # batch_get_query_execution (50개씩 배치, 동시 2개)
            executions: list[dict] = []

            def _batch_get(batch: list[str]) -> list[dict]:
                try:
                    resp = athena.batch_get_query_execution(QueryExecutionIds=batch)
                    return resp.get("QueryExecutions", [])
                except Exception:
                    return []

            batches = [all_exec_ids[i : i + 50] for i in range(0, len(all_exec_ids), 50)]
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(_batch_get, b) for b in batches]
                for fut in as_completed(futures):
                    executions.extend(fut.result())

            # SUCCEEDED 필터 + 기간 필터 + SQL 기준 그룹핑
            query_daily: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
            for ex in executions:
                status = ex.get("Status", {}).get("State")
                if status != "SUCCEEDED":
                    continue
                comp_time = ex.get("Status", {}).get("CompletionDateTime")
                if not comp_time:
                    continue
                kst_dt = comp_time.astimezone(KST)
                if kst_dt < cutoff:
                    continue
                d = kst_dt.date().isoformat()
                if d not in date_set:
                    continue
                sql = ex.get("Query", "")
                scanned = ex.get("Statistics", {}).get("DataScannedInBytes", 0)
                query_daily[sql][d] += scanned

            if not query_daily:
                return {"queries": [], "workgroups": all_workgroups}

            # 전체 스캔량 기준 Top 10 선정
            query_totals = {sql: sum(daily.values()) for sql, daily in query_daily.items()}
            top_sqls = sorted(query_totals, key=query_totals.get, reverse=True)[:10]

            queries = []
            for sql in top_sqls:
                daily = []
                for d in dates:
                    scan_gb = round(query_daily[sql].get(d, 0) / 1_073_741_824, 2)
                    daily.append({"date": d, "scan_gb": scan_gb})
                total_scan_gb = round(query_totals[sql] / 1_073_741_824, 2)
                queries.append({"query_label": sql, "daily": daily, "total_scan_gb": total_scan_gb})

            queries.sort(key=lambda q: q["total_scan_gb"], reverse=True)
            return {"queries": queries[:10], "workgroups": all_workgroups}
        except Exception:
            logger.exception("Athena top queries 조회 실패 — mock fallback")
            return self._mock_fallback(self._mock_athena_top_queries, days, workgroup)

    # ── Athena Query History ───────────────────────────

    def get_athena_query_history(
        self,
        page: int = 1,
        limit: int = 20,
        search: str | None = None,
        workgroup: str | None = None,
        status: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._resolve(
            self._mock_athena_query_history,
            self._fetch_athena_query_history,
            page,
            limit,
            search,
            workgroup,
            status,
            start_date,
            end_date,
        )

    def _mock_athena_query_history(
        self,
        page: int,
        limit: int,
        search: str | None,
        workgroup: str | None,
        status: str | None,
        start_date: str | None,
        end_date: str | None,
    ) -> dict[str, Any]:
        import uuid

        rng = _seeded_rng("mock_athena_query_history")
        workgroups = ["bdp-prod-psvcprj", "bdp-prod-analytics", "bdp-dev-sandbox"]
        statuses = ["SUCCEEDED", "SUCCEEDED", "SUCCEEDED", "SUCCEEDED", "FAILED", "CANCELLED"]
        sample_queries = [
            "SELECT * FROM bdp_lake.user_events WHERE dt = '2026-03-01'",
            "SELECT customer_id, SUM(amount) FROM bdp_dw.transactions GROUP BY 1",
            "SELECT DISTINCT session_id FROM bdp_lake.clickstream",
            "INSERT INTO bdp_mart.daily_summary SELECT * FROM bdp_dw.orders",
            "SELECT a.*, b.name FROM bdp_lake.logs a JOIN bdp_dw.services b ON a.id = b.id",
            "CREATE TABLE bdp_mart.monthly_agg AS SELECT month, SUM(revenue) FROM bdp_dw.facts GROUP BY 1",
            "SELECT COUNT(*) FROM bdp_lake.raw_data WHERE partition_date >= '2026-02-01'",
            "SELECT product_id, AVG(price) FROM bdp_dw.products GROUP BY 1",
            "SELECT region, SUM(bytes) FROM bdp_lake.s3_access_logs GROUP BY 1",
            "UNLOAD (SELECT * FROM bdp_dw.export_view) TO 's3://bdp-export/'",
            "SELECT date_trunc('hour', event_time), COUNT(*) FROM bdp_lake.api_logs GROUP BY 1 ORDER BY 1",
            "SELECT user_id, MAX(login_time) FROM bdp_dw.user_sessions GROUP BY 1",
            "SELECT category, COUNT(DISTINCT product_id) FROM bdp_dw.catalog GROUP BY 1",
            "WITH daily AS (SELECT dt, SUM(revenue) r FROM bdp_dw.sales GROUP BY 1) SELECT * FROM daily",
            "SELECT partition_date, COUNT(*) FROM bdp_lake.raw_events GROUP BY 1 ORDER BY 1 DESC LIMIT 30",
            "SELECT error_code, COUNT(*) cnt FROM bdp_lake.error_logs GROUP BY 1 ORDER BY cnt DESC",
            "SELECT t.team_name, COUNT(q.id) FROM bdp_dw.queries q JOIN bdp_dw.teams t ON q.team_id = t.id GROUP BY 1",
            "MERGE INTO bdp_mart.dim_customer USING bdp_dw.stg_customer ON id = stg_id WHEN MATCHED THEN UPDATE SET name = stg_name",
            "SELECT bucket, SUM(size_bytes)/1024/1024/1024 AS gb FROM bdp_lake.s3_inventory GROUP BY 1",
            "SELECT database_name, table_name, row_count FROM information_schema.tables ORDER BY row_count DESC LIMIT 50",
            "SELECT workgroup, DATE(submission_time), COUNT(*) FROM bdp_lake.athena_history GROUP BY 1,2",
            "SELECT APPROX_DISTINCT(user_id) FROM bdp_lake.page_views WHERE dt >= DATE_ADD('day', -7, CURRENT_DATE)",
        ]

        # Generate 200 mock items with seeded rng
        uuid_rng = random.Random(hash("athena_history_uuid") & 0xFFFFFFFF)
        all_items = []
        now = datetime.now(KST)
        for i in range(200):
            sub_time = now - timedelta(hours=rng.randint(0, 720))
            dur = round(rng.uniform(1.0, 120.0), 1)
            comp_time = sub_time + timedelta(seconds=dur)
            scanned = rng.randint(1024, 10 * 1024**3)  # 1KB ~ 10GB
            s = rng.choice(statuses)
            wg = rng.choice(workgroups)
            q = rng.choice(sample_queries)
            q_short = (q[:120] + "...") if len(q) > 120 else q

            if scanned >= 1024**3:
                display = f"{scanned / 1024**3:.2f} GB"
            elif scanned >= 1024**2:
                display = f"{scanned / 1024**2:.2f} MB"
            elif scanned >= 1024:
                display = f"{scanned / 1024:.2f} KB"
            else:
                display = f"{scanned} B"

            all_items.append(
                {
                    "query_execution_id": str(uuid.UUID(int=uuid_rng.getrandbits(128), version=4)),
                    "query": q,
                    "query_short": q_short,
                    "workgroup": wg,
                    "status": s,
                    "submission_time": sub_time.isoformat(),
                    "completion_time": comp_time.isoformat(),
                    "duration_seconds": dur,
                    "data_scanned_bytes": scanned,
                    "data_scanned_display": display,
                    "output_location": f"s3://bdp-athena-results/{wg}/{sub_time.strftime('%Y/%m/%d')}/",
                }
            )

        # Sort by submission_time desc
        all_items.sort(key=lambda x: x["submission_time"], reverse=True)

        # Apply filters
        filtered = all_items
        if search:
            search_lower = search.lower()
            filtered = [it for it in filtered if search_lower in it["query"].lower()]
        if workgroup:
            filtered = [it for it in filtered if it["workgroup"] == workgroup]
        if status:
            filtered = [it for it in filtered if it["status"] == status]
        if start_date:
            filtered = [it for it in filtered if it["submission_time"][:10] >= start_date]
        if end_date:
            filtered = [it for it in filtered if it["submission_time"][:10] <= end_date]

        total = len(filtered)
        start_idx = (page - 1) * limit
        items = filtered[start_idx : start_idx + limit]

        return {
            "items": items,
            "total": total,
            "page": page,
            "page_size": limit,
            "workgroups": workgroups,
        }

    def _fetch_athena_query_history(
        self,
        page: int,
        limit: int,
        search: str | None,
        workgroup: str | None,
        status: str | None,
        start_date: str | None,
        end_date: str | None,
    ) -> dict[str, Any]:
        """Athena 쿼리 실행 이력을 실제 API로 조회."""
        all_workgroups = self._list_athena_workgroups()

        # 워크그룹 미선택 → 목록만 반환
        if not workgroup:
            return {
                "items": [],
                "total": 0,
                "page": page,
                "page_size": limit,
                "workgroups": all_workgroups,
            }

        try:
            from botocore.config import Config

            from src.common.services.aws_session import get_boto3_client

            athena = get_boto3_client(
                "athena",
                region="ap-northeast-2",
                config=Config(
                    retries={"max_attempts": 5, "mode": "adaptive"},
                    connect_timeout=5,
                    read_timeout=10,
                ),
            )

            # 선택된 워크그룹의 query execution ID 수집
            all_exec_ids: list[str] = []
            try:
                pg = athena.get_paginator("list_query_executions")
                for page_ in pg.paginate(
                    WorkGroup=workgroup,
                    PaginationConfig={"MaxItems": 500},
                ):
                    all_exec_ids.extend(page_.get("QueryExecutionIds", []))
            except Exception:
                logger.warning("Athena ListQueryExecutions 실패: wg=%s", workgroup)

            if not all_exec_ids:
                return {
                    "items": [],
                    "total": 0,
                    "page": page,
                    "page_size": limit,
                    "workgroups": all_workgroups,
                }

            # batch_get_query_execution (50개씩 배치, 동시 2개)
            executions: list[dict] = []

            def _batch_get(batch: list[str]) -> list[dict]:
                try:
                    resp = athena.batch_get_query_execution(QueryExecutionIds=batch)
                    return resp.get("QueryExecutions", [])
                except Exception:
                    return []

            batches = [all_exec_ids[i : i + 50] for i in range(0, len(all_exec_ids), 50)]
            with ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(_batch_get, b) for b in batches]
                for fut in as_completed(futures):
                    executions.extend(fut.result())

            # 아이템 변환
            def _format_scanned(b: int) -> str:
                if b >= 1024**3:
                    return f"{b / 1024**3:.2f} GB"
                if b >= 1024**2:
                    return f"{b / 1024**2:.2f} MB"
                if b >= 1024:
                    return f"{b / 1024:.2f} KB"
                return f"{b} B"

            all_items: list[dict[str, Any]] = []
            for ex in executions:
                ex_status = ex.get("Status", {})
                query_str = ex.get("Query", "")
                q_short = (query_str[:120] + "...") if len(query_str) > 120 else query_str
                wg_name = ex.get("WorkGroup", "")
                state = ex_status.get("State", "UNKNOWN")

                sub_dt = ex_status.get("SubmissionDateTime")
                comp_dt = ex_status.get("CompletionDateTime")
                sub_kst = sub_dt.astimezone(KST) if sub_dt else None
                comp_kst = comp_dt.astimezone(KST) if comp_dt else None

                stats = ex.get("Statistics", {})
                engine_ms = stats.get("EngineExecutionTimeInMillis", 0)
                scanned = stats.get("DataScannedInBytes", 0)
                output_loc = ex.get("ResultConfiguration", {}).get("OutputLocation", "")

                all_items.append(
                    {
                        "query_execution_id": ex.get("QueryExecutionId", ""),
                        "query": query_str,
                        "query_short": q_short,
                        "workgroup": wg_name,
                        "status": state,
                        "submission_time": sub_kst.isoformat() if sub_kst else "",
                        "completion_time": comp_kst.isoformat() if comp_kst else "",
                        "duration_seconds": round(engine_ms / 1000, 1),
                        "data_scanned_bytes": scanned,
                        "data_scanned_display": _format_scanned(scanned),
                        "output_location": output_loc,
                    }
                )

            # submission_time 내림차순 정렬
            all_items.sort(key=lambda x: x["submission_time"], reverse=True)

            # 필터 적용
            filtered = all_items
            if search:
                search_lower = search.lower()
                filtered = [it for it in filtered if search_lower in it["query"].lower()]
            if status:
                filtered = [it for it in filtered if it["status"] == status]
            if start_date:
                filtered = [it for it in filtered if it["submission_time"][:10] >= start_date]
            if end_date:
                filtered = [it for it in filtered if it["submission_time"][:10] <= end_date]

            total = len(filtered)
            start_idx = (page - 1) * limit
            items = filtered[start_idx : start_idx + limit]

            return {
                "items": items,
                "total": total,
                "page": page,
                "page_size": limit,
                "workgroups": all_workgroups,
            }
        except Exception:
            logger.exception("Athena query history 조회 실패 — mock fallback")
            return self._mock_fallback(
                self._mock_athena_query_history,
                page,
                limit,
                search,
                workgroup,
                status,
                start_date,
                end_date,
            )

    # ── Lambda Invocation History ─────────────────────

    def get_lambda_invocations(self, function_name: str, hours: int = 1) -> dict[str, Any]:
        return self._resolve(
            lambda: self._mock_lambda_invocations(function_name, hours),
            lambda: self._cw_lambda_invocations(function_name, hours),
        )

    # 함수 이름별 mock 특성
    _LAMBDA_MOCK_PROFILES: dict[str, dict[str, Any]] = {
        "bdp-event-processor": {
            "error_rate": 0.20,
            "memory_size": 512,
            "avg_duration": 800,
            "cold_start_rate": 0.15,
            "invocations_per_hour": 20,
        },
        "bdp-alert-handler": {
            "error_rate": 0.05,
            "memory_size": 256,
            "avg_duration": 200,
            "cold_start_rate": 0.30,
            "invocations_per_hour": 8,
        },
        "bdp-etl-trigger": {
            "error_rate": 0.10,
            "memory_size": 1024,
            "avg_duration": 2500,
            "cold_start_rate": 0.10,
            "invocations_per_hour": 4,
        },
        "bdp-api-gateway": {
            "error_rate": 0.08,
            "memory_size": 256,
            "avg_duration": 120,
            "cold_start_rate": 0.25,
            "invocations_per_hour": 30,
        },
    }
    _DEFAULT_PROFILE: dict[str, Any] = {
        "error_rate": 0.12,
        "memory_size": 256,
        "avg_duration": 500,
        "cold_start_rate": 0.20,
        "invocations_per_hour": 15,
    }

    _ERROR_MESSAGES = [
        "KeyError: 'missing_field'",
        "ConnectionError: Connection refused",
        "TimeoutError: Task timed out after 30s",
        "Runtime.ImportModuleError: Unable to import module 'handler'",
        "MemoryError: Container killed due to memory limit",
        "botocore.exceptions.ClientError: AccessDenied",
        "json.decoder.JSONDecodeError: Expecting value: line 1 column 1",
        "TypeError: 'NoneType' object is not subscriptable",
        "OSError: [Errno 28] No space left on device",
        "RecursionError: maximum recursion depth exceeded",
    ]

    def _mock_lambda_invocations(self, function_name: str, hours: int) -> dict[str, Any]:
        import uuid

        profile = self._LAMBDA_MOCK_PROFILES.get(function_name, self._DEFAULT_PROFILE)
        rng = _seeded_rng(f"mock_lambda_inv_{function_name}_{hours}")
        now = get_kst_now()
        count = max(10, int(profile["invocations_per_hour"] * hours))
        memory_size = profile["memory_size"]
        avg_dur = profile["avg_duration"]
        invocations: list[dict[str, Any]] = []

        for _ in range(count):
            offset_sec = rng.randint(0, hours * 3600)
            ts = now - timedelta(seconds=offset_sec)
            is_error = rng.random() < profile["error_rate"]
            # 에러 시 duration이 더 길거나 짧을 수 있음
            if is_error and rng.random() < 0.3:
                duration = round(rng.uniform(avg_dur * 2, 30000), 2)  # timeout
            else:
                duration = round(rng.gauss(avg_dur, avg_dur * 0.3), 2)
                duration = max(10, duration)
            max_memory = rng.randint(int(memory_size * 0.3), memory_size)
            # OOM 에러 시 memory가 limit에 가까움
            if is_error and rng.random() < 0.2:
                max_memory = rng.randint(int(memory_size * 0.9), memory_size)
            cold_start = (
                round(rng.uniform(100, 1200), 2)
                if rng.random() < profile["cold_start_rate"]
                else None
            )

            invocations.append(
                {
                    "request_id": str(uuid.UUID(int=rng.getrandbits(128))),
                    "timestamp": ts.isoformat(),
                    "status": "error" if is_error else "success",
                    "duration_ms": round(duration, 2),
                    "billed_duration_ms": int(duration) + 1,
                    "memory_size_mb": memory_size,
                    "max_memory_used_mb": max_memory,
                    "init_duration_ms": cold_start,
                    "error_message": rng.choice(self._ERROR_MESSAGES) if is_error else None,
                }
            )

        invocations.sort(key=lambda x: x["timestamp"], reverse=True)
        return {"function_name": function_name, "invocations": invocations}

    def _cw_lambda_invocations(self, function_name: str, hours: int) -> dict[str, Any]:
        try:
            logs_client = self._get_client("logs")
            log_group = f"/aws/lambda/{function_name}"
            now = get_kst_now()
            start = now - timedelta(hours=hours)

            # REPORT 라인에서 invocation 메타데이터 추출
            query = (
                "fields @timestamp, @requestId, @duration, @billedDuration, "
                "@memorySize, @maxMemoryUsed, @initDuration\n"
                '| filter @type = "REPORT"\n'
                "| sort @timestamp desc\n"
                "| limit 50"
            )

            resp = logs_client.start_query(
                logGroupName=log_group,
                startTime=int(start.timestamp()),
                endTime=int(now.timestamp()),
                queryString=query,
                limit=50,
            )
            query_id = resp["queryId"]

            import time as _time

            for _ in range(60):
                result = logs_client.get_query_results(queryId=query_id)
                if result["status"] in ("Complete", "Failed", "Cancelled"):
                    break
                _time.sleep(0.5)

            if result["status"] != "Complete":
                logger.warning("Lambda invocation query did not complete: %s", result["status"])
                return {"function_name": function_name, "invocations": [], "is_mock": False}

            # 에러가 있는 request_id 집합 조회
            error_query = (
                "fields @requestId\n"
                "| filter @message like /ERROR|Exception|Traceback|Task timed out/\n"
                "| stats count() as err_count by @requestId"
            )
            err_resp = logs_client.start_query(
                logGroupName=log_group,
                startTime=int(start.timestamp()),
                endTime=int(now.timestamp()),
                queryString=error_query,
                limit=200,
            )
            err_query_id = err_resp["queryId"]
            for _ in range(60):
                err_result = logs_client.get_query_results(queryId=err_query_id)
                if err_result["status"] in ("Complete", "Failed", "Cancelled"):
                    break
                _time.sleep(0.5)

            error_request_ids: set[str] = set()
            if err_result["status"] == "Complete":
                for row in err_result.get("results", []):
                    row_dict = {f["field"]: f["value"] for f in row}
                    rid = row_dict.get("@requestId", "")
                    if rid:
                        error_request_ids.add(rid)

            # 결과 변환
            invocations: list[dict[str, Any]] = []
            for row in result.get("results", []):
                row_dict = {f["field"]: f["value"] for f in row}
                request_id = row_dict.get("@requestId", "")
                init_dur = row_dict.get("@initDuration")

                invocations.append(
                    {
                        "request_id": request_id,
                        "timestamp": row_dict.get("@timestamp", ""),
                        "status": "error" if request_id in error_request_ids else "success",
                        "duration_ms": _safe_float(row_dict.get("@duration")),
                        "billed_duration_ms": int(
                            _safe_float(row_dict.get("@billedDuration", "0"))
                        ),
                        "memory_size_mb": int(_safe_float(row_dict.get("@memorySize", "0"))),
                        "max_memory_used_mb": int(_safe_float(row_dict.get("@maxMemoryUsed", "0"))),
                        "init_duration_ms": _safe_float(init_dur) if init_dur else None,
                    }
                )

            return {"function_name": function_name, "invocations": invocations}
        except Exception:
            logger.exception("Lambda invocation history 조회 실패 — mock fallback")
            result = self._mock_lambda_invocations(function_name, hours)
            result["is_mock"] = True
            return result


def _safe_float(val: Any) -> float:
    """안전하게 float 변환. 실패 시 0.0 반환."""
    try:
        return round(float(val), 2)
    except (TypeError, ValueError):
        return 0.0
