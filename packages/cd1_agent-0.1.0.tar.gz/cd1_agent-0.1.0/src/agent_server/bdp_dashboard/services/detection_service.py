"""BDP Dashboard Detection Service - 대시보드 메트릭 이상 탐지 + 심층 분석."""

import logging
from typing import Any

from src.agent_server.bdp_common.anomaly import AnomalyResult, EnsembleDetector, TimeSeriesData
from src.agent_server.bdp_common.deep_agent.executor import DeepAgentExecutor
from src.agent_server.bdp_common.deep_agent.schemas import DetectionInput, DetectionItem
from src.agent_server.bdp_common.deep_agent.tools import create_investigation_tools

logger = logging.getLogger(__name__)


class BdpDashboardDetectionService:
    """BDP 대시보드 메트릭에 대한 이상 탐지 및 심층 분석 서비스.

    InfraMetricsService에서 시계열 데이터를 조회하고,
    EnsembleDetector로 이상 탐지를 수행한 뒤,
    DeepAgentExecutor로 심층 분석을 실행합니다.
    """

    def __init__(self, infra_metrics_service, alert_config_reader=None):
        self.metrics_service = infra_metrics_service
        self.alert_config_reader = alert_config_reader
        self._default_sensitivity = 0.7
        self.detector = EnsembleDetector(sensitivity=self._default_sensitivity)

    def _get_detector_for_metric(self, source_name: str) -> EnsembleDetector:
        """메트릭별 설정을 읽어 적절한 detector 반환."""
        if not self.alert_config_reader:
            return self.detector
        sensitivity = self.alert_config_reader.get_sensitivity(
            source_name, source_name, self._default_sensitivity
        )
        if abs(sensitivity - self._default_sensitivity) < 0.01:
            return self.detector
        return EnsembleDetector(sensitivity=sensitivity)

    def detect(self, days: int = 31) -> dict[str, Any]:
        """인프라 메트릭 이상 탐지 수행.

        Args:
            days: 분석 기간 (일)

        Returns:
            탐지 결과 dict (anomalies, severity_breakdown, summary 포함)
        """
        anomalies: list[dict[str, Any]] = []

        # 메트릭 수집 함수 목록 (이름, 호출, 데이터 키, 값 키)
        metric_sources = self._collect_metric_sources(days)

        for source_name, series_dict, value_key in metric_sources:
            for resource_id, data_points in series_dict.items():
                if not data_points or len(data_points) < 7:
                    continue

                values = [float(p.get(value_key, 0)) for p in data_points]
                timestamps = [p.get("date", "") for p in data_points]

                ts_data = TimeSeriesData(
                    name=source_name,
                    resource_id=resource_id,
                    current_value=values[-1] if values else 0,
                    historical_values=values,
                    timestamps=timestamps,
                )

                detector = self._get_detector_for_metric(source_name)
                result = detector.analyze(ts_data)
                if result.is_anomaly:
                    anomalies.append(
                        self._anomaly_to_dict(source_name, resource_id, result, ts_data)
                    )

        severity_breakdown = self._count_severity(anomalies)

        return {
            "detection_type": "bdp_dashboard_metrics",
            "total_anomalies": len(anomalies),
            "severity_breakdown": severity_breakdown,
            "summary": (
                f"BDP 대시보드 메트릭 이상 탐지 {len(anomalies)}건 "
                f"[critical: {severity_breakdown.get('critical', 0)}, "
                f"high: {severity_breakdown.get('high', 0)}, "
                f"medium: {severity_breakdown.get('medium', 0)}]"
            ),
            "anomalies": anomalies[:20],
        }

    def analyze(self, detect_result: dict[str, Any]) -> dict[str, Any]:
        """탐지 결과에 대한 심층 분석 수행.

        Args:
            detect_result: detect() 반환값 또는 동일 구조의 dict

        Returns:
            deep_analysis 결과가 포함된 dict
        """
        severity = detect_result.get("severity_breakdown", {})
        if severity.get("critical", 0) == 0 and severity.get("high", 0) == 0:
            detect_result["deep_analysis"] = None
            return detect_result

        try:
            items = self._normalize_detection_items(detect_result)
            detection_input = DetectionInput(
                agent_type="bdp_dashboard",
                detection_type=detect_result.get("detection_type", "bdp_dashboard_metrics"),
                severity="critical" if severity.get("critical", 0) > 0 else "high",
                summary=detect_result.get("summary", ""),
                total_anomalies=detect_result.get("total_anomalies", 0),
                severity_breakdown=severity,
                items=items,
            )
            executor = DeepAgentExecutor(tools=create_investigation_tools("bdp_dashboard"))
            result = executor.run(detection_input)
            detect_result["deep_analysis"] = result.model_dump()
        except Exception as e:
            logger.error(f"BDP Dashboard deep analysis 실패: {e}")
            detect_result["deep_analysis"] = None

        return detect_result

    def _collect_metric_sources(self, days: int) -> list[tuple[str, dict[str, list], str]]:
        """메트릭 소스를 수집하여 (이름, {리소스: 데이터포인트}, 값키) 튜플 목록 반환."""
        sources: list[tuple[str, dict[str, list], str]] = []

        # MSK Lag
        try:
            msk = self.metrics_service.get_msk_lag(days=days)
            sources.append(("msk_lag", msk.get("clusters", {}), "lag"))
        except Exception as e:
            logger.warning(f"MSK lag 수집 실패: {e}")

        # RDS CPU
        try:
            rds_cpu = self.metrics_service.get_rds_cpu(days=days)
            sources.append(("rds_cpu", rds_cpu.get("instances", {}), "value"))
        except Exception as e:
            logger.warning(f"RDS CPU 수집 실패: {e}")

        # RDS Connections
        try:
            rds_conn = self.metrics_service.get_rds_connections(days=days)
            sources.append(("rds_connections", rds_conn.get("instances", {}), "value"))
        except Exception as e:
            logger.warning(f"RDS connections 수집 실패: {e}")

        # SageMaker Endpoint Errors
        try:
            sm_errors = self.metrics_service.get_sagemaker_endpoint_errors(days=days)
            sources.append(("sagemaker_endpoint_errors", sm_errors.get("endpoints", {}), "value"))
        except Exception as e:
            logger.warning(f"SageMaker endpoint errors 수집 실패: {e}")

        # Lambda Errors
        try:
            lambda_err = self.metrics_service.get_lambda_errors(days=days)
            sources.append(("lambda_errors", lambda_err.get("functions", {}), "value"))
        except Exception as e:
            logger.warning(f"Lambda errors 수집 실패: {e}")

        return sources

    @staticmethod
    def _anomaly_to_dict(
        source_name: str,
        resource_id: str,
        result: AnomalyResult,
        ts_data: TimeSeriesData,
    ) -> dict[str, Any]:
        return {
            "metric_source": source_name,
            "resource_id": resource_id,
            "severity": result.severity.value,
            "confidence": result.confidence_score,
            "change_percent": result.change_percent,
            "detection_method": result.detection_method,
            "trend_direction": result.trend_direction,
            "current_value": ts_data.current_value,
            "pattern_contexts": result.pattern_contexts,
        }

    @staticmethod
    def _count_severity(anomalies: list[dict]) -> dict[str, int]:
        return {
            "critical": sum(1 for a in anomalies if a.get("severity") == "critical"),
            "high": sum(1 for a in anomalies if a.get("severity") == "high"),
            "medium": sum(1 for a in anomalies if a.get("severity") == "medium"),
            "low": sum(1 for a in anomalies if a.get("severity") == "low"),
        }

    @staticmethod
    def _normalize_detection_items(detect_result: dict[str, Any]) -> list[DetectionItem]:
        items = []
        for a in detect_result.get("anomalies", []):
            items.append(
                DetectionItem(
                    item_type="metric_anomaly",
                    resource_id=a.get("resource_id", "unknown"),
                    severity=a.get("severity", "medium"),
                    title=f"{a.get('metric_source', '')} - {a.get('resource_id', '')}",
                    description=f"변화율 {a.get('change_percent', 0):.1f}%, 현재값 {a.get('current_value', 0)}",
                    confidence=a.get("confidence", 0.0),
                    raw_data={
                        "metric_source": a.get("metric_source", ""),
                        "change_percent": a.get("change_percent", 0),
                        "detection_method": a.get("detection_method", ""),
                        "trend_direction": a.get("trend_direction", ""),
                    },
                )
            )
        return items
