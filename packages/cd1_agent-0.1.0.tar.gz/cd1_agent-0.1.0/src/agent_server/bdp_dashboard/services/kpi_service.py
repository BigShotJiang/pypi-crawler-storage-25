"""KPI 실제 데이터 서비스 — wfl_awf_hst + 팀 매핑 테이블 기반."""

import json
import logging
from collections import defaultdict
from typing import Any

from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)

TASK_TYPE_MAP = {
    "run_query_with_role": {"key": "query", "label": "Query Task"},
    "run_spark_script": {"key": "spark", "label": "Spark Task"},
    "call_datasink": {"key": "sink", "label": "Data Sink Task"},
    "branch_task": {"key": "branch", "label": "Branch Task"},
}

TASK_TYPES = [v for v in TASK_TYPE_MAP.values()]

class KpiService:
    """WFL DAG 월별 성공률 + 팀별 DAG/Task 성공률 조회."""

    def __init__(self, settings: PortalSettings):
        self.settings = settings

    def _get_db_connection(self):
        """MySQL 연결 (Secrets Manager 기반)."""
        import pymysql
        import pymysql.cursors

        secret_id = self.settings.baseline_secret_id
        db_name = self.settings.rds_database
        if not secret_id:
            return None
        from src.common.services.aws_session import get_boto3_client

        sm = get_boto3_client("secretsmanager", region="ap-northeast-2")
        secret = json.loads(sm.get_secret_value(SecretId=secret_id)["SecretString"])
        return pymysql.connect(
            host=secret["host"],
            port=int(secret.get("port", 3306)),
            user=secret["username"],
            password=secret["password"],
            database=db_name,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            connect_timeout=5,
            read_timeout=15,
        )

    def _query(self, sql: str, params: tuple = ()) -> list[dict]:
        conn = self._get_db_connection()
        if conn is None:
            return []
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                return cursor.fetchall()
        except Exception:
            logger.exception("KPI query failed")
            return []
        finally:
            conn.close()

    # ── 팀 매핑 ──────────────────────────────────────

    def _get_team_mapping(self) -> dict[str, str]:
        """prjt_cd → dept_nm(팀명) 매핑."""
        rows = self._query(
            "SELECT a.prjt_cd, c.dept_nm "
            "FROM prjt_mst_tbl a "
            "LEFT JOIN user_bsis b ON a.prjt_hodp_id = b.user_id "
            "LEFT JOIN dept_bsis c ON b.dcd = c.dcd "
            "WHERE b.dcd IS NOT NULL"
        )
        return {r["prjt_cd"]: r["dept_nm"] for r in rows}

    def _resolve_team(self, prjt_cd: str, team_map: dict[str, str]) -> str:
        """prjt_cd → 팀명. 매핑 없으면 prjt_cd 그대로 반환."""
        return team_map.get(prjt_cd, prjt_cd)

    # ── WFL 월별 성공률 ──────────────────────────────

    def get_wfl_monthly_rates(self) -> list[dict]:
        rows = self._query(
            "SELECT DATE_FORMAT(start_date, '%%y/%%m') AS month, "
            "COUNT(*) AS totalRuns, "
            "SUM(CASE WHEN state='success' THEN 1 ELSE 0 END) AS successRuns "
            "FROM wfl_awf_hst "
            "WHERE rcpt_tp = 'wfl' AND start_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) "
            "GROUP BY DATE_FORMAT(start_date, '%%y/%%m') "
            "ORDER BY month"
        )
        result = []
        for r in rows:
            total = int(r["totalRuns"])
            success = int(r["successRuns"])
            rate = round(success / total * 100, 1) if total > 0 else 0
            result.append({"month": r["month"], "totalRuns": total, "successRuns": success, "rate": rate})
        return result

    # ── 팀별 DAG 성공률 ─────────────────────────────

    def get_team_success_rates(self) -> list[dict]:
        team_map = self._get_team_mapping()
        rows = self._query(
            "SELECT SUBSTRING_INDEX(dag_id, '-', 1) AS prjt_cd, "
            "DATE_FORMAT(start_date, '%%y/%%m') AS month, "
            "COUNT(*) AS total, "
            "SUM(CASE WHEN state='success' THEN 1 ELSE 0 END) AS ok "
            "FROM wfl_awf_hst "
            "WHERE rcpt_tp = 'wfl' "
            "AND CHAR_LENGTH(SUBSTRING_INDEX(dag_id, '-', 1)) = 6 "
            "AND start_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) "
            "GROUP BY prjt_cd, month "
            "ORDER BY prjt_cd, month"
        )
        if not rows:
            return []

        # 전체 월 목록 (정렬용)
        all_months = sorted({r["month"] for r in rows})

        # 팀별 집계
        team_data: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
        for r in rows:
            team = self._resolve_team(r["prjt_cd"], team_map)
            total = int(r["total"])
            ok = int(r["ok"])
            month = r["month"]
            # 같은 팀에 여러 prjt_cd가 매핑될 수 있으므로 누적
            if month in team_data[team]:
                team_data[team][month]["ok"] += ok
                team_data[team][month]["total"] += total
            else:
                team_data[team][month] = {"ok": ok, "total": total}

        # 응답 구조 생성
        result = []
        for team in sorted(team_data.keys()):
            months: dict[str, dict | None] = {}
            for m in all_months:
                if m in team_data[team]:
                    d = team_data[team][m]
                    rate = round(d["ok"] / d["total"] * 100, 1) if d["total"] > 0 else 0
                    months[m] = {"rate": rate, "ok": d["ok"], "total": d["total"]}
                else:
                    months[m] = None
            result.append({"team": team, "months": months})
        return result

    # ── 팀별 Task 성공률 ────────────────────────────

    def get_team_task_rates(self) -> dict:
        team_map = self._get_team_mapping()
        rows = self._query(
            "SELECT SUBSTRING_INDEX(dag_id, '-', 1) AS prjt_cd, "
            "python_callable, "
            "DATE_FORMAT(start_date, '%%y/%%m') AS month, "
            "COUNT(*) AS total, "
            "SUM(CASE WHEN state='success' THEN 1 ELSE 0 END) AS ok "
            "FROM wfl_awf_hst "
            "WHERE rcpt_tp = 'wfl' "
            "AND CHAR_LENGTH(SUBSTRING_INDEX(dag_id, '-', 1)) = 6 "
            "AND python_callable IN ('run_query_with_role','run_spark_script','call_datasink','branch_task') "
            "AND start_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) "
            "GROUP BY prjt_cd, python_callable, month "
            "ORDER BY prjt_cd, python_callable, month"
        )
        if not rows:
            return {"task_types": TASK_TYPES, "teams": {}}

        all_months = sorted({r["month"] for r in rows})

        # 팀 → task_key → month → {ok, total}
        teams: dict[str, dict[str, dict[str, dict[str, int]]]] = defaultdict(
            lambda: defaultdict(dict)
        )
        for r in rows:
            team = self._resolve_team(r["prjt_cd"], team_map)
            callable_name = r["python_callable"]
            task_info = TASK_TYPE_MAP.get(callable_name)
            if not task_info:
                continue
            task_key = task_info["key"]
            month = r["month"]
            total = int(r["total"])
            ok = int(r["ok"])
            # 누적
            if month in teams[team][task_key]:
                teams[team][task_key][month]["ok"] += ok
                teams[team][task_key][month]["total"] += total
            else:
                teams[team][task_key][month] = {"ok": ok, "total": total}

        # 응답 구조 생성
        result_teams: dict[str, dict[str, dict[str, dict | None]]] = {}
        for team in sorted(teams.keys()):
            result_teams[team] = {}
            for task_info in TASK_TYPES:
                task_key = task_info["key"]
                month_data: dict[str, dict | None] = {}
                for m in all_months:
                    if task_key in teams[team] and m in teams[team][task_key]:
                        d = teams[team][task_key][m]
                        rate = round(d["ok"] / d["total"] * 100, 1) if d["total"] > 0 else 0
                        month_data[m] = {"rate": rate, "ok": d["ok"], "total": d["total"]}
                    else:
                        month_data[m] = None
                result_teams[team][task_key] = month_data

        return {"task_types": TASK_TYPES, "teams": result_teams}
