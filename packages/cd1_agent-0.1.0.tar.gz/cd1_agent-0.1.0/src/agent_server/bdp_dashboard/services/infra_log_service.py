"""Infra Log Service - CloudWatch 로그 조회."""

import logging
import random
from datetime import datetime, timedelta

from src.common.timezone import KST
from typing import Any

from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)

# 서비스별 로그 그룹 패턴 (service → log_type → pattern)
LOG_GROUP_MAP: dict[str, dict[str, str]] = {
    "mwaa": {
        "scheduler": "/aws/mwaa/{resource_name}/scheduler",
        "worker": "/aws/mwaa/{resource_name}/worker",
        "webserver": "/aws/mwaa/{resource_name}/webserver",
        "dag_processing": "/aws/mwaa/{resource_name}/dag_processing",
    },
    "lambda": {
        "default": "/aws/lambda/{resource_name}",
    },
    "eks": {
        "cluster": "/aws/eks/{resource_name}/cluster",
        "application": "/aws/containerinsights/{resource_name}/application",
        "host": "/aws/containerinsights/{resource_name}/host",
        "dataplane": "/aws/containerinsights/{resource_name}/dataplane",
    },
    "rds": {
        "error": "/aws/rds/instance/{resource_name}/error",
        "slowquery": "/aws/rds/instance/{resource_name}/slowquery",
    },
    "sagemaker endpoint": {
        "endpoint": "/aws/sagemaker/Endpoints/{resource_name}",
        "model": "/aws/sagemaker/Endpoints/{resource_name}/model",
        "instance": "/aws/sagemaker/Endpoints/{resource_name}/instance",
    },
    "sagemaker studio": {
        "default": "/aws/sagemaker/studio/{resource_name}",
        "notebook": "/aws/sagemaker/NotebookInstances/{resource_name}",
        "pipeline": "/aws/sagemaker/Pipelines/execution/{resource_name}",
    },
    "emr(cluster)": {
        "step": "/aws/emr/{resource_name}/steps",
        "hadoop": "/aws/emr/{resource_name}/hadoop",
        "spark": "/aws/emr/{resource_name}/spark",
    },
    "emr(serverless)": {
        "application": "/aws/emr-serverless/applications/{resource_name}",
        "spark": "/aws/emr-serverless/applications/{resource_name}/spark",
        "hive": "/aws/emr-serverless/applications/{resource_name}/hive",
    },
    "msk": {
        "broker": "/aws/msk/{resource_name}/broker",
        "zookeeper": "/aws/msk/{resource_name}/zookeeper",
        "consumer": "/aws/msk/{resource_name}/consumer",
    },
}


class InfraLogService:
    """CloudWatch 로그를 조회하는 서비스.

    dev 환경에서는 mock 로그를 반환한다.
    Victoria Logs를 캐시로 사용하여 동일 시간대 로그 재조회 시 성능을 향상한다.
    """

    def __init__(self, settings: PortalSettings, log_cache=None):
        self.settings = settings
        self._log_cache = log_cache  # Optional[LogCacheStore]
        self._logs_client = None

    @property
    def _is_dev(self) -> bool:
        return self.settings.environment == "test"

    def get_logs(
        self,
        service: str,
        resource_name: str,
        hours: int = 1,
        filter_pattern: str | None = None,
        log_type: str | None = None,
        limit: int = 200,
        log_group: str | None = None,
    ) -> dict[str, Any]:
        """서비스 로그 조회.

        Args:
            log_group: 커스텀 로그 그룹 경로. 전달되면 LOG_GROUP_MAP 대신 직접 사용.
        """
        if service not in LOG_GROUP_MAP:
            return {
                "service": service,
                "resource_name": resource_name,
                "logs": [],
                "count": 0,
                "truncated": False,
                "available_log_types": [],
                "success": False,
                "error": f"로그 미지원 서비스: {service}",
            }

        type_map = LOG_GROUP_MAP[service]
        available_log_types = list(type_map.keys())
        resolved_type = log_type if log_type and log_type in type_map else available_log_types[0]

        if log_group:
            resolved_log_group = log_group
        else:
            resolved_log_group = type_map[resolved_type].format(resource_name=resource_name)

        now = datetime.now(KST)
        start_time = now - timedelta(hours=hours)

        if self._is_dev:
            logs = self._mock_logs(
                service, resource_name, start_time, now, filter_pattern, limit, resolved_type
            )
        else:
            logs = self._cw_logs(resolved_log_group, start_time, now, filter_pattern, limit)

        truncated = len(logs) >= limit

        return {
            "service": service,
            "resource_name": resource_name,
            "log_group": resolved_log_group,
            "time_range": {
                "start": start_time.isoformat(),
                "end": now.isoformat(),
            },
            "logs": logs,
            "count": len(logs),
            "truncated": truncated,
            "available_log_types": available_log_types,
            "success": True,
        }

    def _cw_logs(
        self,
        log_group: str,
        start_time: datetime,
        end_time: datetime,
        filter_pattern: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        """CloudWatch filter_log_events 호출 (Victoria Logs 캐시 적용)."""
        # 1. Victoria Logs 캐시 조회
        if self._log_cache:
            try:
                cached = self._log_cache.get_logs(
                    log_group=log_group,
                    start_time=start_time,
                    end_time=end_time,
                    filter_pattern=filter_pattern,
                    limit=limit,
                )
                if cached is not None:
                    logger.debug(f"Log cache HIT: {log_group} ({len(cached)} events)")
                    return [
                        {
                            "timestamp": e.get("timestamp", ""),
                            "message": e.get("message", ""),
                            "log_stream": e.get("logStreamName", ""),
                            "level": self._parse_log_level(e.get("message", "")),
                        }
                        for e in cached
                    ]
            except Exception as e:
                logger.warning(f"Log cache read failed: {e}")

        # 2. Cache miss → CloudWatch API 호출
        try:
            if self._logs_client is None:
                from src.common.services.aws_session import get_boto3_client

                self._logs_client = get_boto3_client("logs")
            client = self._logs_client
            params: dict[str, Any] = {
                "logGroupName": log_group,
                "startTime": int(start_time.timestamp() * 1000),
                "endTime": int(end_time.timestamp() * 1000),
                "limit": limit,
                "interleaved": True,
            }
            if filter_pattern:
                params["filterPattern"] = filter_pattern

            resp = client.filter_log_events(**params)
            events = resp.get("events", [])

            # 3. 캐시에 저장
            if events and self._log_cache:
                try:
                    self._log_cache.put_logs(log_group=log_group, events=events)
                except Exception as cache_err:
                    logger.warning(f"Log cache write failed: {cache_err}")

            return [
                {
                    "timestamp": datetime.fromtimestamp(e["timestamp"] / 1000, tz=KST).isoformat(),
                    "message": e.get("message", "").rstrip("\n"),
                    "log_stream": e.get("logStreamName", ""),
                    "level": self._parse_log_level(e.get("message", "")),
                }
                for e in events
            ]
        except Exception as e:
            logger.exception(f"CloudWatch log query failed: {log_group}")
            raise RuntimeError(f"로그 조회 실패: {e}") from e

    @staticmethod
    def _parse_log_level(message: str) -> str:
        """로그 메시지에서 레벨 추출."""
        upper = message[:100].upper()
        if "ERROR" in upper or "CRITICAL" in upper or "FATAL" in upper:
            return "ERROR"
        if "WARN" in upper:
            return "WARN"
        if "DEBUG" in upper:
            return "DEBUG"
        return "INFO"

    def _mock_logs(
        self,
        service: str,
        resource_name: str,
        start_time: datetime,
        end_time: datetime,
        filter_pattern: str | None,
        limit: int,
        log_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """서비스별 현실적 mock 로그 생성."""
        # log_type 특화 템플릿 우선 조회 (예: "sagemaker endpoint:model")
        template_key = f"{service}:{log_type}" if log_type else service
        templates = _MOCK_TEMPLATES.get(
            template_key, _MOCK_TEMPLATES.get(service, _MOCK_TEMPLATES["_default"])
        )
        duration_sec = int((end_time - start_time).total_seconds())
        count = min(limit, random.randint(20, 80))
        logs: list[dict[str, Any]] = []

        for _ in range(count):
            offset = random.randint(0, duration_sec)
            ts = start_time + timedelta(seconds=offset)
            msg_template = random.choice(templates)
            message = msg_template.format(resource_name=resource_name)
            level = self._parse_log_level(message)

            if filter_pattern and filter_pattern.upper() not in message.upper():
                continue

            logs.append(
                {
                    "timestamp": ts.isoformat(),
                    "message": message,
                    "log_stream": f"{resource_name}/mock-stream-{random.randint(1, 5)}",
                    "level": level,
                }
            )

        logs.sort(key=lambda x: x["timestamp"])
        return logs[:limit]


_MOCK_TEMPLATES: dict[str, list[str]] = {
    "mwaa": [
        "[INFO] Scheduler heartbeat (pid=12345)",
        "[INFO] DAG bag processing complete, 47 dags loaded",
        "[INFO] Running <TaskInstance: etl_daily.extract_data scheduled__2026-03-01T00:00:00+00:00 [queued]>",
        "[WARNING] Task instance etl_daily.transform has been up for 3600s, exceeding SLA",
        "[ERROR] Task failed with exception: ConnectionError('Connection refused')",
        "[INFO] Setting the following 23 tasks to queued state",
        "[INFO] Executor reports execution of {resource_name}.sync_task execution_date=2026-03-01",
        "[WARNING] Scheduler is handling 15 tasks, close to concurrency limit (16)",
        "[ERROR] Received SIGTERM, task exited with return code 1",
        "[INFO] Successfully completed DAG run for etl_hourly",
    ],
    "lambda": [
        "START RequestId: a1b2c3d4-e5f6-7890-abcd-ef1234567890 Version: $LATEST",
        "END RequestId: a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "REPORT RequestId: a1b2c3d4 Duration: 245.67 ms Billed Duration: 246 ms Memory Size: 256 MB Max Memory Used: 128 MB",
        "[INFO] Processing event from S3 bucket bdp-raw-data",
        "[INFO] Successfully transformed 1,234 records",
        "[WARNING] Approaching memory limit: 230/256 MB used",
        "[ERROR] Failed to write to DynamoDB: ProvisionedThroughputExceededException",
        "[INFO] Cold start initialization completed in 1.2s",
        "[INFO] Function {resource_name} invoked with 5 records",
        "[ERROR] Unhandled exception: KeyError 'missing_field'",
    ],
    "eks": [
        'I0301 10:00:00.000000  1 controller.go:234] "Reconciling resource" resource="deployment/api-server"',
        'I0301 10:00:01.000000  1 controller.go:256] "Successfully synced" resource="service/frontend"',
        "W0301 10:00:02.000000  1 reflector.go:347] Watch error: context deadline exceeded",
        'E0301 10:00:03.000000  1 controller.go:300] "Reconcile error" err="pod not found"',
        "I0301 10:00:04.000000  1 node_controller.go:100] Node ip-10-0-1-25 condition Ready is True",
        'W0301 10:00:05.000000  1 scheduler.go:456] "Unable to schedule pod" pod="default/worker-7"',
        "I0301 10:00:06.000000  1 auth.go:200] Successfully authenticated service account default:api-sa",
        'E0301 10:00:07.000000  1 controller.go:310] "OOMKilled" pod="analytics/spark-worker-3"',
        "I0301 10:00:08.000000  1 scaler.go:150] HPA scaled deployment/api-server from 3 to 5 replicas",
        "I0301 10:00:09.000000  1 audit.go:100] PersistentVolumeClaim pvc-data bound to pv-0012",
    ],
    "eks:application": [
        '[INFO] {"log":"10.0.1.25 - - [01/Mar/2026:10:00:00 +0000] \\"GET /healthz\\" 200 2\\n","stream":"stdout","kubernetes":{"pod_name":"api-server-0","namespace_name":"default"}}',
        '[INFO] {"log":"Processing request for /api/v1/users (latency: 45ms)\\n","stream":"stdout","kubernetes":{"pod_name":"app-backend-0","namespace_name":"default"}}',
        '[WARNING] {"log":"High memory usage detected: 85% in container app-backend\\n","stream":"stderr","kubernetes":{"pod_name":"app-backend-1","namespace_name":"default"}}',
        '[ERROR] {"log":"Connection refused to database endpoint rds-main.cluster-abc123.ap-northeast-2.rds.amazonaws.com:3306\\n","stream":"stderr","kubernetes":{"pod_name":"app-backend-failed","namespace_name":"default"}}',
        '[INFO] {"log":"Spark executor started successfully on port 7078\\n","stream":"stdout","kubernetes":{"pod_name":"spark-exec-0","namespace_name":"spark"}}',
        '[WARNING] {"log":"OOMKilled: container spark-executor exceeded memory limit 8Gi\\n","stream":"stderr","kubernetes":{"pod_name":"spark-exec-failed","namespace_name":"spark"}}',
        '[INFO] {"log":"HDSP API server listening on port 8443\\n","stream":"stdout","kubernetes":{"pod_name":"hdsp-api-server-0","namespace_name":"hdsp"}}',
        '[ERROR] {"log":"CrashLoopBackOff: back-off 5m0s restarting failed container\\n","stream":"stderr","kubernetes":{"pod_name":"app-backend-failed","namespace_name":"default"}}',
        '[INFO] {"log":"Successfully synced ConfigMap default/app-config\\n","stream":"stdout","kubernetes":{"pod_name":"coredns-0","namespace_name":"kube-system"}}',
        '[INFO] {"log":"Worker processing batch job #1234 (records: 5000)\\n","stream":"stdout","kubernetes":{"pod_name":"hdsp-worker-0","namespace_name":"hdsp"}}',
    ],
    "eks:host": [
        "[INFO] kubelet[1234]: Node ip-10-0-1-25 status is now: NodeReady",
        "[INFO] kubelet[1234]: Container runtime (containerd) version: 1.7.11",
        "[WARNING] kubelet[1234]: Disk pressure detected on /var/lib/kubelet: usage 87%",
        "[INFO] kubelet[1234]: Pod default/app-backend-0 is now Running",
        "[INFO] kubelet[1234]: Successfully pulled image app-backend:1.4.2 in 2.3s",
        "[ERROR] kubelet[1234]: Failed to create pod sandbox: rpc error: code = Unknown",
        "[WARNING] kubelet[1234]: Node memory pressure: available 1.2Gi, threshold 1.0Gi",
        "[INFO] kubelet[1234]: PLEG: relisting (elapsed: 1.2s)",
        "[INFO] kubelet[1234]: Volume pvc-data-0 mounted to /var/lib/kubelet/pods/abc123/volumes",
        "[ERROR] kubelet[1234]: Eviction manager: attempting to evict pod default/app-backend-failed (memory)",
        "[INFO] kubelet[1234]: CPU utilization: 45% (8 cores), Memory: 24.5Gi/32Gi (76%)",
        "[WARNING] kubelet[1234]: CNI plugin returned error: failed to allocate IP from subnet",
    ],
    "eks:dataplane": [
        "[INFO] kube-proxy[5678]: Using iptables proxy",
        "[INFO] kube-proxy[5678]: Syncing iptables rules (221 services, 1045 endpoints)",
        "[WARNING] kube-proxy[5678]: Stale endpoint 10.0.1.30:8080 detected, removing",
        "[INFO] vpc-cni[9012]: ENI eni-0a1b2c3d attached to instance i-0abc123def",
        "[INFO] vpc-cni[9012]: IP address 10.0.1.50 assigned to pod default/app-backend-0",
        "[WARNING] vpc-cni[9012]: IP address pool exhausted on ENI eni-0a1b2c3d, attaching new ENI",
        "[INFO] aws-node[3456]: Warm IP target: 3, current warm IPs: 5",
        "[ERROR] kube-proxy[5678]: Failed to sync endpoints: connection reset by peer",
        "[INFO] ebs-csi-driver[7890]: Volume vol-0abc123 attached to node ip-10-0-1-25",
        "[INFO] kube-proxy[5678]: Service default/app-backend-svc updated: 3 endpoints active",
    ],
    "rds": [
        "2026-03-01T10:00:00.000000Z [Note] [MY-000000] InnoDB: Buffer pool(s) load completed",
        "2026-03-01T10:00:01.000000Z [Warning] Aborted connection 12345 to db: 'bdp_main' user: 'app_user'",
        "2026-03-01T10:00:02.000000Z [ERROR] [MY-000001] Deadlock found when trying to get lock; try restarting transaction",
        "2026-03-01T10:00:03.000000Z [Note] Slow query: SELECT * FROM large_table WHERE created_at > '2026-02-24' (Query time: 12.345s)",
        "2026-03-01T10:00:04.000000Z [Note] [MY-010747] Plugin group_replication reported: 'Member state changed to ONLINE'",
        "2026-03-01T10:00:05.000000Z [Warning] [MY-013360] Plugin group_replication: member has network partitioning",
        "2026-03-01T10:00:06.000000Z [Note] Access denied for user 'readonly'@'10.0.1.25' (using password: YES)",
        "2026-03-01T10:00:07.000000Z [ERROR] [MY-012960] InnoDB: Cannot allocate memory for the buffer pool",
        "2026-03-01T10:00:08.000000Z [Note] Binlog rotation: mysql-bin.000042 -> mysql-bin.000043",
        "2026-03-01T10:00:09.000000Z [Note] [MY-000000] {resource_name}: Checkpoint completed",
    ],
    "sagemaker endpoint": [
        "[INFO] Invocation request received for model {resource_name}",
        "[INFO] Model loaded successfully, latency: 245ms",
        "[WARNING] Invocation latency exceeded threshold: 2.1s",
        "[ERROR] ModelError: OutOfMemoryError during inference",
        "[INFO] Endpoint scaling from 1 to 2 instances",
        "[INFO] Health check passed for variant AllTraffic",
        "[WARNING] High GPU utilization: 92%",
        "[ERROR] InvocationError: Model returned HTTP 500",
        "[INFO] Batch transform job completed: 5,000 records processed",
        "[INFO] Auto-scaling policy triggered: target tracking at 70% CPU",
    ],
    "sagemaker endpoint:endpoint": [
        "[INFO] POST /invocations → 200 OK (latency: 127ms)",
        "[INFO] GET /ping → 200 OK (latency: 2ms)",
        "[INFO] POST /invocations → 200 OK (latency: 89ms)",
        "[WARNING] POST /invocations → 200 OK (latency: 2134ms, threshold exceeded)",
        "[ERROR] POST /invocations → 503 ServiceUnavailable: model container not ready",
        "[INFO] Endpoint {resource_name} variant AllTraffic: DesiredInstanceCount=2, CurrentInstanceCount=2",
        "[INFO] Auto-scaling policy evaluation: CPUUtilization=62%, target=70%",
        "[INFO] POST /invocations → 200 OK (latency: 156ms, payload: 4.2KB)",
        "[WARNING] Invocation throttled: TPS=52, MaxTPS=50 for {resource_name}",
        "[ERROR] POST /invocations → 408 RequestTimeout after 60s",
        "[INFO] Endpoint config updated: {resource_name}-config-v3 → {resource_name}-config-v4",
        "[INFO] Traffic shifting: AllTraffic 100% on variant-1",
    ],
    "sagemaker endpoint:model": [
        "[INFO] Loading model artifact from s3://sagemaker-ap-northeast-2/models/{resource_name}/model.tar.gz",
        "[INFO] Model artifact download complete (size: 1.2 GB, elapsed: 34s)",
        "[INFO] Model deserialization started (framework: PyTorch 2.1)",
        "[INFO] Model loaded to GPU memory: 3.8 GB / 16 GB (cuda:0)",
        "[WARNING] Model warm-up inference latency: 890ms (expected <500ms)",
        "[INFO] Model serving ready: {resource_name}/AllTraffic (PyTorch 2.1, CUDA 12.1)",
        "[ERROR] Model loading failed: CUDA out of memory (requested 8.2 GB, available 4.1 GB)",
        "[INFO] Model inference: input_shape=[1,3,224,224], output_shape=[1,1000], latency=45ms",
        "[WARNING] Model prediction confidence below threshold: max_prob=0.32 (threshold=0.5)",
        "[INFO] Model container health check: /ping → 200 (model: {resource_name}, version: v3.2)",
        "[ERROR] Model inference error: RuntimeError('Expected Float but got Half')",
        "[INFO] Model metrics: avg_latency=67ms, p99_latency=245ms, throughput=142 req/s",
    ],
    "sagemaker endpoint:instance": [
        "[INFO] Instance ml.g4dn.xlarge launched (id: i-0a1b2c3d4e5f67890)",
        "[INFO] GPU utilization: 45% (NVIDIA T4, 16 GB VRAM)",
        "[INFO] CPU utilization: 32% (4 vCPUs)",
        "[INFO] Memory usage: 8.2 / 16.0 GB (51%)",
        "[WARNING] GPU memory usage: 14.8 / 16.0 GB (92%)",
        "[WARNING] Disk usage: /opt/ml/model 18.5 / 20.0 GB (92%)",
        "[ERROR] Instance health check failed: container exited with code 137 (OOMKilled)",
        "[INFO] Container started: serving-container (image: 763104351884.dkr.ecr.ap-northeast-2.amazonaws.com/pytorch-inference:2.1-gpu)",
        "[INFO] Network I/O: rx=124 MB/s, tx=89 MB/s",
        "[INFO] GPU temperature: 72C (throttle threshold: 85C)",
        "[WARNING] Instance restart triggered: consecutive health check failures (3/3)",
        "[INFO] Instance scaling event: InService → Pending (scale-in cooldown: 300s)",
    ],
    "sagemaker studio": [
        "[INFO] JupyterServer app started for user profile {resource_name}",
        "[INFO] KernelGateway app created: ml.t3.medium",
        "[WARNING] Kernel idle timeout approaching: 55/60 min",
        "[ERROR] Failed to start kernel: InsufficientCapacity",
        "[INFO] User profile session started successfully",
        "[INFO] EFS storage usage: 12.3 GB / 50 GB",
        "[WARNING] KernelGateway app memory usage: 85%",
        "[ERROR] Notebook execution failed: CellTimeoutError",
        "[INFO] Git repository synced successfully",
        "[INFO] Lifecycle configuration script completed in 8.2s",
    ],
    "sagemaker studio:notebook": [
        "[INFO] Notebook instance {resource_name} starting (ml.t3.medium)",
        "[INFO] Notebook instance {resource_name} is now InService",
        "[INFO] Jupyter server listening on port 8443",
        "[INFO] Kernel started: python3 (pid=4521)",
        "[WARNING] Notebook instance idle for 45 minutes, approaching auto-stop threshold",
        "[INFO] Package installation: pip install pandas==2.1.0 (success)",
        "[ERROR] Kernel died: MemoryError - exceeded 4 GB limit",
        "[INFO] EBS volume /dev/xvdf mounted (20 GB, gp3)",
        "[INFO] Git clone completed: https://codecommit.ap-northeast-2.amazonaws.com/v1/repos/ml-experiments",
        "[WARNING] Disk usage: 17.2 / 20.0 GB (86%)",
        "[INFO] Lifecycle config on-start script completed in 12.4s",
        "[ERROR] Failed to connect to S3: AccessDenied for bucket bdp-training-data",
    ],
    "sagemaker studio:pipeline": [
        "[INFO] Pipeline execution {resource_name} started",
        "[INFO] Step 1/5 (DataProcessing) state changed to Executing",
        "[INFO] Step 1/5 (DataProcessing) completed successfully (duration: 4m 32s)",
        "[INFO] Step 2/5 (FeatureEngineering) state changed to Executing",
        "[WARNING] Step 2/5 (FeatureEngineering) retry attempt 1/3: SpotInterruption",
        "[INFO] Step 2/5 (FeatureEngineering) completed (duration: 8m 15s)",
        "[INFO] Step 3/5 (ModelTraining) state changed to Executing",
        "[ERROR] Step 3/5 (ModelTraining) failed: ResourceLimitExceeded (ml.p3.2xlarge unavailable)",
        "[INFO] Pipeline parameter override: learning_rate=0.001, epochs=50",
        "[INFO] Step 4/5 (ModelEvaluation) completed: accuracy=0.934, f1=0.921",
        "[INFO] Pipeline execution {resource_name} completed (total duration: 45m 12s)",
        "[WARNING] Pipeline cost estimate: $12.45 (3x ml.m5.xlarge for 45 min)",
    ],
    "emr(cluster)": [
        "[INFO] Step s-1A2B3C4D5E6F7 (Spark ETL Job) submitted",
        "[INFO] Step s-1A2B3C4D5E6F7 state changed to RUNNING",
        "[INFO] Spark application application_1708900000000_0001 launched on YARN",
        "[INFO] YARN ResourceManager: Allocated container_1708900000000_0001_01 on host ip-10-0-1-25",
        "[WARNING] Container memory usage 85%: container_1708900000000_0001_03 (3.4 GB / 4 GB)",
        "[INFO] HDFS: Wrote 2.3 GB to /tmp/spark-output/part-00000",
        "[ERROR] Spark executor lost: ExecutorLostFailure (executor 3 exited caused by OOM)",
        "[INFO] Step s-1A2B3C4D5E6F7 state changed to COMPLETED (duration: 12m 34s)",
        "[WARNING] YARN: Node ip-10-0-1-30 reported unhealthy (disk usage 92%)",
        "[ERROR] Step s-2B3C4D5E6F7G failed: java.lang.OutOfMemoryError: Java heap space",
        "[INFO] Hadoop MapReduce job_1708900000000_0002 completed: map 100%, reduce 100%",
        "[INFO] Spark SQL query completed in 4.2s, scanned 1.2M rows from {resource_name}_raw_data",
        "[WARNING] GC pause detected: 1.8s on executor 2 (ip-10-0-1-28)",
        "[INFO] Bootstrap action completed successfully on master node",
        "[INFO] Cluster {resource_name} auto-scaling: core group resized from 3 to 5 instances",
    ],
    "emr(serverless)": [
        "[INFO] Application {resource_name} state changed to STARTED",
        "[INFO] Spark driver started on ip-10-0-1-25 (port 4040)",
        "[INFO] SparkContext initialized with 4 executors (auto-scale enabled)",
        "[INFO] Job submitted: data processing pipeline for {resource_name}",
        "[INFO] Stage 1/3 submitted: 100 tasks (shuffle read: 2.4 GB)",
        "[INFO] Executor executor-1 completed: processed 50K records in 12.3s",
        "[WARNING] Executor memory pressure detected: 85% utilization on executor-2",
        "[ERROR] Executor executor-3 failed: OutOfMemoryError in shuffle stage",
        "[INFO] Stage 1/3 completed: 98/100 tasks successful (duration: 2m 34s)",
        "[INFO] Stage 2/3 submitted: 50 tasks (aggregate + join)",
        "[WARNING] Speculative execution triggered for slow task (executor-4, attempt 2)",
        "[INFO] Stage 3/3 completed: final output written to s3://bdp-output/ (1.8 GB)",
        "[INFO] Job run jr-1A2B3C4D5E6F completed successfully (duration: 8m 12s)",
        "[ERROR] Job run jr-2B3C4D5E failed: MaxCapacityReached (requested 20 vCPU, limit 16)",
        "[INFO] Application {resource_name} released resources: 8 vCPU, 32 GB memory",
    ],
    "msk": [
        "[INFO] Kafka broker {resource_name} started (broker.id=1)",
        "[INFO] [Controller id=1] Processing automatic preferred replica leader election",
        "[INFO] [GroupCoordinator 1]: Group consumer-group-1 generation 5 is now stable",
        "[WARNING] [ReplicaManager broker=1] Partition __consumer_offsets-12 ISR shrunk from 3 to 2",
        "[ERROR] [ReplicaFetcher replicaId=1] Error in fetch to broker 2: RequestTimedOut",
        "[INFO] [Log partition=events-0] Flushed log segment at offset 1234567 in 45ms",
        "[WARNING] [RequestChannel] Request queue time exceeded 500ms for Produce request",
        "[ERROR] [Controller id=1] Error completing reassignment for partition events-3: ReplicaNotAvailable",
        "[INFO] [TransactionCoordinator id=1] Initialized transactionalId txn-producer-1 with producerId 5001",
        "[INFO] [SocketServer] Created data-plane acceptor and processors for endpoint: PLAINTEXT://broker-1:9092",
        "[WARNING] [ProducerStateManager partition=orders-2] Duplicate sequence detected: producerId=3001, seq=42",
        "[INFO] [GroupCoordinator 1]: Preparing to rebalance group consumer-group-2 in state PreparingRebalance",
    ],
    "msk:broker": [
        "[INFO] [KafkaServer id=1] started (kafka.server.KafkaServer)",
        "[INFO] [Log partition=events-0] Loading producer state till offset 1234567",
        "[INFO] [ReplicaManager broker=1] Handling LeaderAndIsr request for partition events-0 (leader=1, isr=[1,2,3])",
        "[WARNING] [ReplicaManager broker=1] Leader epoch 5 is behind the current leader epoch 6 for partition events-2",
        "[ERROR] [ReplicaFetcher replicaId=1] Fetch session 12345 expired for broker 2",
        "[INFO] [GroupCoordinator 1]: Member consumer-1 in group app-consumers has left",
        "[INFO] [Log partition=orders-0] Rolled new log segment at offset 567890 (size: 1.0 GB)",
        "[WARNING] Detected low disk space: /kafka-logs usage 87% (threshold: 85%)",
        "[INFO] [Controller id=1] New leader for partition events-0: broker 2 (ISR: [2,1,3])",
        "[ERROR] [Acceptor] Too many open connections (current: 1024, max: 1024)",
        "[INFO] [RequestPurgatory] Delayed produce requests: 12, delayed fetch requests: 45",
        "[INFO] [Log partition=metrics-0] Deleted log segment from offset 0 to 100000 (retention: 168h)",
    ],
    "msk:consumer": [
        "[INFO] Consumer group {resource_name} rebalance completed, assigned 6 partitions",
        "[INFO] Fetched 1,234 records from 고객행동로그 (partition 0-5, lag: 45)",
        "[INFO] Committed offsets for group {resource_name}: 고객행동로그-0=125678, 고객행동로그-1=98432",
        "[WARNING] Consumer lag increasing: 고객행동로그-3 lag=2,340 (threshold: 1,000)",
        "[ERROR] Consumer heartbeat failed: group {resource_name} member-1 (session timeout: 10000ms)",
        "[INFO] Consumer {resource_name} joined group (generation=12, protocol=range)",
        "[INFO] Polled 856 records in 245ms from 고객행동로그 (avg record size: 1.2KB)",
        "[WARNING] Slow consumer detected: processing time 4,500ms exceeds max.poll.interval.ms (5,000ms)",
        "[INFO] Consumer group {resource_name} coordinator changed to broker 2",
        "[ERROR] Deserialization error at 고객행동로그-2 offset 567890: malformed JSON payload",
        "[INFO] Auto-committed offsets for group {resource_name} (interval: 5000ms)",
        "[INFO] Consumer {resource_name} member-2 revoked partitions [고객행동로그-4, 고객행동로그-5]",
    ],
    "msk:zookeeper": [
        "[INFO] ZooKeeper server started, listening on port 2181",
        "[INFO] Established session 0x18f5a3c2d010001 with negotiated timeout 6000",
        "[INFO] Processed session termination for sessionid: 0x18f5a3c2d010002",
        "[WARNING] fsync-ing the write ahead log in SyncThread:0 took 1234ms (threshold: 1000ms)",
        "[ERROR] Connection request from /10.0.1.25:54321 rejected: too many connections (max: 60)",
        "[INFO] Handling multi-request from session 0x18f5a3c2d010003",
        "[INFO] Got user-level KeeperException: /brokers/ids/1 NodeExists for /brokers/ids/1",
        "[WARNING] Client session 0x18f5a3c2d010004 is expired (timeout: 6000ms)",
        '[INFO] Created ephemeral znode /brokers/ids/3 with data: {"host":"broker-3","port":9092}',
        "[INFO] Leader election completed: /controller → broker 1",
        "[ERROR] Unexpected exception causing shutdown: QuorumPeer.run failed",
        "[INFO] ZooKeeper ensemble health check: 3/3 nodes healthy, leader=node-1",
    ],
    "_default": [
        "[INFO] Service running normally",
        "[INFO] Health check passed",
        "[WARNING] High resource utilization detected",
        "[ERROR] Operation failed: timeout after 30s",
        "[INFO] Request processed successfully",
    ],
}
