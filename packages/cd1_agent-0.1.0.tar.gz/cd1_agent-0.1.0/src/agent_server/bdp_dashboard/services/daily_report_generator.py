"""
Daily Report Generator for BDP Dashboard.

포털의 서비스 현황(service-dashboard) 페이지와 동일한 구조의
HTML 리포트를 생성합니다.

섹션 구성:
- Summary 카드: 비즈니스 도메인, 전체 리소스, 정상 운영, 주의 필요
- MWAA: DAG/Task 성공률 라인 차트 + DAG Top 10 실행시간 누적 막대 차트 (환경별)
- MSK: Consumer LAG 라인 차트 (클러스터별)
- SageMaker Studio: Pipeline 실패 차트
- SageMaker Endpoint: 에러 차트
- EMR: Cluster + Serverless 실패 차트
"""

import json
import logging
from dataclasses import dataclass, field
from html import escape as html_escape
from typing import Any

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.charts import (  # noqa: F401
    CHART_COLORS,
    COST_COLORS,
    DAG_STACK_COLORS,
    _html_data_table,
    _svg_line_chart,
    _svg_stacked_bar_chart,
)
from src.agent_server.bdp_common.reports.email_charts import (
    _html_line_chart,
    _html_stacked_bar_chart,
    _render_stat_card_body,
)
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)

STATUS_COLORS = {
    "ok": "#16a34a",
    "warning": "#d97706",
    "critical": "#dc2626",
    "neutral": "#6b7280",
}

STATUS_LABELS = {
    "ok": "정상",
    "warning": "주의",
    "critical": "장애",
    "neutral": "확인 필요",
}

# ── Data Classes ───────────────────────────────────────


@dataclass
class DashboardDailyReportData:
    """대시보드 일일 리포트 데이터 (포털 서비스 현황과 동일 구조)."""

    # Summary
    total_domains: int = 0
    total_resources: int = 0
    running: int = 0
    attention: int = 0

    # 서비스 리소스 (service_key → [resource dicts])
    services: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # MWAA DAG/Task 성공률 (env → [{date, dag_success_rate, task_success_rate}])
    airflow_rates: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # MSK Consumer LAG (cluster → [{date, lag}])
    msk_lag: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # S3 버킷 용량 (bucket → [{date, size_gb}])
    s3_size: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker 사용자 ([{date, users}])
    sagemaker_users: list[dict[str, Any]] = field(default_factory=list)

    # SageMaker Endpoint 에러 (endpoint → [{date, 4xx, 5xx}])
    sagemaker_endpoint_errors: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker Pipeline 실패 (pipeline → [{date, failures}])
    sagemaker_pipeline_failures: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # EMR Cluster 실패 (cluster → [{date, failures}])
    emr_cluster_failures: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # EMR Serverless 실패 (app → [{date, failures}])
    emr_serverless_failures: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # DAG SLA 현황 (env → {sla_target_min, dags: {dag_id → [{date, duration_min}]}})
    dag_sla_status: dict[str, Any] = field(default_factory=dict)

    # SageMaker Notebook 인스턴스 타입 (type → [{date, count}])
    sagemaker_notebook_instance_types: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker Pipeline 인스턴스 타입 (type → [{date, count}])
    sagemaker_pipeline_instance_types: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker Endpoint Latency (endpoint → [{date, p50, p95, p99}])
    sagemaker_endpoint_latency: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker Endpoint Availability (endpoint → [{date, availability}])
    sagemaker_endpoint_availability: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # SageMaker Endpoint Invocations (endpoint → [{date, invocations}])
    sagemaker_endpoint_invocations: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # RDS CPU (instance → [{date, value}])
    rds_cpu: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # RDS Connections (instance → [{date, value}])
    rds_connections: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # RDS Memory (instance → [{date, freeable_gb, swap_mb}])
    rds_memory: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # RDS IOPS (instance → [{date, read_iops, write_iops}])
    rds_iops: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # RDS Storage Free (instance → [{date, value}])
    rds_storage_free: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # L0 소스 시스템별 입수 성공/실패 (l0_daily_success 등 → [{date, BCV, DW, ...}])
    ingestion_rates: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # Universe 파이프라인 일별 실패 ([{date, failures, ...}])
    universe_failures: list[dict[str, Any]] = field(default_factory=list)

    # 소비케어 Workflow 현황 ({daily: [...], monthly: [...]})
    sobicare_workflows: dict[str, Any] = field(default_factory=dict)

    # WFL DAG 월별 성공률 ([{month, success_rate}])
    wfl_monthly_rates: list[dict[str, Any]] = field(default_factory=list)

    # 월별 AWS 비용 ([{month, cost}])
    cost_monthly: list[dict[str, Any]] = field(default_factory=list)

    # 일별 AWS 비용 ([{date, cost}])
    cost_daily: list[dict[str, Any]] = field(default_factory=list)

    # 비용 예산 정보 ({monthly_target, annual_total})
    cost_budget: dict[str, Any] = field(default_factory=dict)

    # 타시스템 연계 DAG 성공률 (category → [{date, success_rate}])
    dag_interface_rates: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # 팀별 월 DAG 성공률 ([{team, months: {month_label: rate}}])
    team_success_rates: list[dict[str, Any]] = field(default_factory=list)

    # 팀별 Task 성공/실패 현황 ({task_types: [...], teams: {team → {task → {month → cell}}}})
    team_task_rates: dict[str, Any] = field(default_factory=dict)

    report_date: str | None = None

    # 개별 데이터 소스의 mock 여부 (차트 단위 MOCK 배지 표시용)
    msk_lag_is_mock: bool = False
    sagemaker_pipeline_is_mock: bool = False
    sagemaker_endpoint_is_mock: bool = False
    emr_cluster_is_mock: bool = False
    emr_serverless_is_mock: bool = False
    universe_is_mock: bool = False
    sobicare_is_mock: bool = False
    kpi_is_mock: bool = False
    cost_is_mock: bool = False
    ingestion_is_mock: bool = False
    airflow_is_mock: bool = False
    dag_sla_is_mock: bool = False
    dag_interface_is_mock: bool = False
    team_success_is_mock: bool = False
    team_task_is_mock: bool = False

    # 운영계에서 mock 차트 생략
    skip_mock: bool = False


# ── backward-compat aliases (portal_service 호출용) ────
DashboardServiceStatus = None  # 더 이상 사용하지 않음


# ── Generator ──────────────────────────────────────────


def _fmt_korean_unit(val: float) -> str:
    """숫자를 한국식 단위(억/만)로 변환."""
    if abs(val) >= 1e8:
        return f"{val / 1e8:.1f}억"
    if abs(val) >= 1e4:
        return f"{val / 1e4:.0f}만"
    return f"{val:,.0f}"


_INFRA_CATEGORY_LABELS: dict[str, str] = {
    "mwaa": "MWAA",
    "msk": "MSK",
    "sagemaker": "SageMaker Studio",
    "sagemaker-endpoint": "SageMaker Endpoint",
    "emr": "EMR",
    "ingestion": "입수",
    "universe": "Universe",
    "sobicare": "소비케어",
    "kpi": "KPI",
    "cost": "비용 현황",
}


class DashboardDailyReportGenerator(HTMLReportBase):
    """대시보드 일일 운영 리포트 생성기.

    포털의 서비스 현황(service-dashboard.tsx) 페이지와 동일한
    섹션 구성으로 HTML 리포트를 생성합니다.
    """

    def __init__(
        self,
        category: str | None = None,
        include_tables: bool = False,
        use_html_charts: bool = False,
        email_mode: bool = False,
    ):
        styles = ReportStyles(primary_color=MD3_COLORS["tertiary"])
        cat_label = _INFRA_CATEGORY_LABELS.get(category, category) if category else None
        title = "BDP 서비스 현황 일일 리포트"
        if cat_label:
            title = f"{title} - {cat_label}"
        super().__init__(title=title, styles=styles, email_mode=email_mode)
        self._category = category
        self._include_tables = include_tables
        # HTML 차트: PDF/메일 등 WeasyPrint 렌더링 시 SVG 대신 경량 HTML 차트 사용
        if use_html_charts:
            self._line_chart = _html_line_chart
            self._stacked_bar_chart = _html_stacked_bar_chart
        else:
            self._line_chart = _svg_line_chart
            self._stacked_bar_chart = _svg_stacked_bar_chart

    def _with_mock_badge(self, chart_html: str | None, is_mock: bool) -> str | None:
        """차트 HTML의 첫 번째 제목 옆에 MOCK 배지 삽입 (is_mock=True인 경우)."""
        if not chart_html:
            return chart_html
        if is_mock and self._skip_mock:
            return None  # 운영계: mock 차트 생략
        if not is_mock:
            return chart_html
        badge = self._mock_badge()
        return chart_html.replace("</h4>", f"{badge}</h4>")

    def _should_include(self, domain_id: str) -> bool:
        """카테고리 필터에 따라 해당 도메인 섹션을 포함할지 결정."""
        return not self._category or self._category == domain_id

    def _extract_latest_stat_card_body(
        self,
        series: dict[str, list[tuple[str, float]]],
        y_suffix: str = "",
        colors: list[str] | None = None,
    ) -> str:
        """시리즈의 마지막 날짜 값을 stat card body로 렌더링 (wrapper 없이)."""
        items: list[tuple[str, str, str]] = []
        c = colors or CHART_COLORS
        for si, (sname, pts) in enumerate(series.items()):
            color = c[si % len(c)]
            if pts:
                val = pts[-1][1]
                val_str = f"{int(val)}{y_suffix}" if val == int(val) else f"{val:.1f}{y_suffix}"
            else:
                val_str = "-"
            items.append((sname, val_str, color))
        return _render_stat_card_body(items)

    def _append_chart(
        self,
        parts: list[str],
        chart_html: str,
        series: dict[str, list[tuple[str, float]]] | None = None,
        stat_title: str = "",
        stat_y_suffix: str = "",
        stat_colors: list[str] | None = None,
    ) -> None:
        """include_tables 비활성 시에만 차트 추가. email_mode 시 stat card를 차트 wrapper 내부에 통합."""
        if self._include_tables:
            return
        # email_mode: 월누적일별 데이터(n_dates > 2)인 경우 stat card를 차트 내부에 삽입
        if self._email_mode and series:
            all_dates: set[str] = set()
            for pts in series.values():
                for d, _ in pts:
                    all_dates.add(d)
            if len(all_dates) > 2:
                stat_body = self._extract_latest_stat_card_body(
                    series, stat_y_suffix, stat_colors,
                )
                # chart_html의 wrapper 내부, 차트 body 앞에 stat card body 삽입
                marker = '<div style="margin-top:8px;border-left:3px solid'
                if marker in chart_html:
                    chart_html = chart_html.replace(
                        marker,
                        f'<div style="margin-top:8px;margin-bottom:8px;">{stat_body}</div>{marker}',
                        1,
                    )
        parts.append(chart_html)

    def _append_table(
        self,
        parts: list[str],
        series: dict[str, list[tuple[str, float]]],
        title: str = "",
        y_suffix: str = "",
    ) -> None:
        """include_tables 활성 시 데이터 테이블 추가."""
        if self._include_tables and series:
            parts.append(_html_data_table(series, title, y_suffix))

    def generate_content(self, data: DashboardDailyReportData) -> str:
        """리포트 콘텐츠 생성."""
        self._skip_mock = data.skip_mock
        sections: list[str] = []

        # 1. Summary 카드 (카테고리 필터 시 부분 데이터이므로 생략)
        if not self._category:
            sections.append(self._build_summary_section(data))

        # 2. MWAA 섹션 (차트별 개별 mock 배지 적용 — _build_mwaa_section 내부에서 처리)
        if self._should_include("mwaa"):
            mwaa_chart = self._build_mwaa_section(data)
            if mwaa_chart:
                sections.append(
                    self._build_domain_card(
                        "MWAA",
                        "cloud",
                        data.services.get("mwaa", []),
                        mwaa_chart,
                    )
                )

        # 3. 입수 현황 섹션
        if self._should_include("ingestion"):
            ing_chart = self._with_mock_badge(
                self._build_ingestion_section(data), data.ingestion_is_mock,
            )
            if ing_chart:
                sections.append(self._build_domain_card(
                    "입수", "download", [], ing_chart,
                ))

        # 4. MSK 섹션
        if self._should_include("msk"):
            msk_chart = self._with_mock_badge(
                self._build_msk_section(data), data.msk_lag_is_mock,
            )
            if msk_chart:
                sections.append(
                    self._build_domain_card(
                        "MSK",
                        "hub",
                        data.services.get("msk", []),
                        msk_chart,
                    )
                )

        # 5. SageMaker Studio 섹션
        if self._should_include("sagemaker"):
            sm_chart = self._with_mock_badge(
                self._build_sagemaker_section(data), data.sagemaker_pipeline_is_mock,
            )
            if sm_chart:
                sections.append(
                    self._build_domain_card(
                        "SageMaker Studio",
                        "model_training",
                        [],
                        sm_chart,
                    )
                )

        # 6. SageMaker Endpoint 섹션
        if self._should_include("sagemaker-endpoint"):
            sme_chart = self._with_mock_badge(
                self._build_sagemaker_endpoint_section(data), data.sagemaker_endpoint_is_mock,
            )
            if sme_chart:
                sections.append(
                    self._build_domain_card(
                        "SageMaker Endpoint",
                        "psychology",
                        data.services.get("sagemaker endpoint", []),
                        sme_chart,
                    )
                )

        # 7. EMR 섹션
        if self._should_include("emr"):
            emr_chart = self._build_emr_section(data)
            if emr_chart:
                emr_resources = data.services.get("emr(cluster)", []) + data.services.get(
                    "emr(serverless)", []
                )
                sections.append(
                    self._build_domain_card(
                        "EMR",
                        "memory",
                        emr_resources,
                        emr_chart,
                    )
                )

        # 8. Universe 섹션
        if self._should_include("universe"):
            uni_chart = self._with_mock_badge(
                self._build_universe_section(data), data.universe_is_mock,
            )
            if uni_chart:
                sections.append(self._build_domain_card(
                    "Universe", "schema", [], uni_chart,
                ))

        # 9. 소비케어 섹션
        if self._should_include("sobicare"):
            sobi_chart = self._with_mock_badge(
                self._build_sobicare_section(data), data.sobicare_is_mock,
            )
            if sobi_chart:
                sections.append(self._build_domain_card(
                    "소비케어", "work", [], sobi_chart,
                ))

        # 10. KPI 섹션 (차트별 개별 mock 배지 — _build_kpi_section 내부에서 처리)
        if self._should_include("kpi"):
            kpi_chart = self._build_kpi_section(data)
            if kpi_chart:
                sections.append(self._build_domain_card(
                    "KPI", "bar_chart", [], kpi_chart,
                ))

        # 11. 비용 현황 섹션
        if self._should_include("cost"):
            cost_chart = self._with_mock_badge(
                self._build_cost_section(data), data.cost_is_mock,
            )
            if cost_chart:
                sections.append(self._build_domain_card(
                    "비용 현황", "payments", [], cost_chart,
                ))

        return "\n".join(sections)

    # ── Summary ────────────────────────────────────────

    def _build_summary_section(self, data: DashboardDailyReportData) -> str:
        stats = [
            {"label": "비즈니스 도메인", "value": str(data.total_domains), "color": "#1976D2"},
            {"label": "전체 리소스", "value": str(data.total_resources), "color": "#1976D2"},
            {"label": "정상 운영", "value": str(data.running), "color": "#388E3C"},
            {
                "label": "주의 필요",
                "value": str(data.attention),
                "color": "#F57C00" if data.attention > 0 else "#388E3C",
            },
        ]
        return self.render_stat_cards(stats, columns=4)

    # ── Domain Card ────────────────────────────────────

    def _build_domain_card(
        self,
        domain_name: str,
        icon_name: str,
        resources: list[dict[str, Any]],
        chart_content: str,
    ) -> str:
        # 전체 상태 계산
        total = len(resources)
        running = sum(1 for r in resources if r.get("display_status") != "critical")
        overall = _overall_status(resources)
        status_label = STATUS_LABELS.get(overall, overall)
        status_color = STATUS_COLORS.get(overall, "#6b7280")

        # 헤더
        resource_info = ""
        if total > 0:
            resource_info = (
                f'<span style="font-size:12px;color:#6b7280;margin-left:auto;">'
                f"{running}/{total} 운영 중</span>"
                f'<span style="display:inline-block;padding:2px 8px;border-radius:9999px;'
                f"font-size:11px;font-weight:500;background:{status_color}15;"
                f'color:{status_color};border:1px solid {status_color}40;margin-left:8px;">'
                f"{status_label}</span>"
            )

        icon_html = self._icon(icon_name, size="sm", inline=True)

        return f"""
        <div class="card" style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;gap:8px;padding:16px 20px;border-bottom:1px solid #e5e7eb;">
                <span style="color:{status_color};">{icon_html}</span>
                <span style="font-size:16px;font-weight:700;">{html_escape(domain_name)}</span>
                {resource_info}
            </div>
            <div style="padding:16px 20px;">
                {chart_content}
            </div>
        </div>
        """

    # ── MWAA ───────────────────────────────────────────

    def _build_mwaa_section(self, data: DashboardDailyReportData) -> str | None:
        rates = data.airflow_rates
        if not rates:
            return None

        parts: list[str] = []
        envs = sorted(rates.keys())

        # DAG 성공률 차트 (mock: airflow_is_mock)
        dag_series: dict[str, list[tuple[str, float]]] = {}
        for env in envs:
            dag_series[f"{env}_dag"] = [(r["date"], r["dag_success_rate"]) for r in rates[env]]
        dag_chart = self._line_chart(
            dag_series,
            CHART_COLORS,
            title="DAG 성공률 (월누적 일별)",
            subtitle="환경별 일일 DAG 실행 성공률 (%)",
            y_suffix="%",
            y_domain=(0, 100),
        )
        self._append_chart(
            parts,
            self._with_mock_badge(dag_chart, data.airflow_is_mock) or dag_chart,
            series=dag_series, stat_title="DAG 성공률", stat_y_suffix="%",
        )
        self._append_table(parts, dag_series, "DAG 성공률", "%")

        # Task 성공률 차트 (mock: airflow_is_mock)
        task_series: dict[str, list[tuple[str, float]]] = {}
        for env in envs:
            task_series[f"{env}_task"] = [(r["date"], r["task_success_rate"]) for r in rates[env]]
        task_chart = self._line_chart(
            task_series,
            CHART_COLORS,
            title="Task 성공률 (월누적 일별)",
            subtitle="환경별 일일 Task 실행 성공률 (%)",
            y_suffix="%",
            y_domain=(0, 100),
        )
        self._append_chart(
            parts,
            self._with_mock_badge(task_chart, data.airflow_is_mock) or task_chart,
            series=task_series, stat_title="Task 성공률", stat_y_suffix="%",
        )
        self._append_table(parts, task_series, "Task 성공률", "%")

        # DAG Top 10 실행시간 차트 (mock: dag_sla_is_mock)
        sla = data.dag_sla_status
        if sla:
            for env_name in sorted(sla.keys()):
                env_data = sla[env_name]
                dags = env_data.get("dags", {}) if isinstance(env_data, dict) else {}
                if not dags:
                    continue
                dag_avg_series: dict[str, list[tuple[str, float]]] = {}
                for dag_id, series in dags.items():
                    dag_avg_series[dag_id] = [(r["date"], r["duration_min"]) for r in series]
                bar_title = f"Top 10 DAG 실행시간 추이 — {env_name.upper()}"
                bar_chart = self._stacked_bar_chart(
                    dag_avg_series,
                    DAG_STACK_COLORS,
                    title=bar_title,
                    subtitle=f"일별 DAG별 실행시간 누적 (분) | SLA {env_data.get('sla_target_min', '-')}분",
                    y_suffix="분",
                )
                self._append_chart(
                    parts,
                    self._with_mock_badge(bar_chart, data.dag_sla_is_mock) or bar_chart,
                    series=dag_avg_series, stat_title=bar_title, stat_y_suffix="분",
                    stat_colors=DAG_STACK_COLORS,
                )
                self._append_table(parts, dag_avg_series, bar_title, "분")

        # 타 시스템 연계 DAG 성공률 (mock: dag_interface_is_mock)
        if data.dag_interface_rates:
            iface_series: dict[str, list[tuple[str, float]]] = {}
            for cat_name, pts in data.dag_interface_rates.items():
                iface_series[cat_name] = [(r["date"], r["success_rate"]) for r in pts]
            iface_chart = self._line_chart(
                iface_series,
                CHART_COLORS,
                title="타 시스템 연계 DAG 성공률 (월누적 일별)",
                subtitle="카테고리별 일일 DAG 실행 성공률 (%)",
                y_suffix="%",
                y_domain=(0, 100),
                reference_lines=[{"value": 95, "label": "95%", "color": "#ef4444"}],
            )
            self._append_chart(
                parts,
                self._with_mock_badge(iface_chart, data.dag_interface_is_mock) or iface_chart,
                series=iface_series, stat_title="타 시스템 연계 DAG 성공률", stat_y_suffix="%",
            )
            self._append_table(parts, iface_series, "타 시스템 연계 DAG 성공률", "%")

        return "\n".join(parts)

    # ── MSK ────────────────────────────────────────────

    def _build_msk_section(self, data: DashboardDailyReportData) -> str | None:
        clusters = data.msk_lag
        if not clusters:
            return None

        series: dict[str, list[tuple[str, float]]] = {}
        for name, pts in clusters.items():
            series[name] = [(p["date"], p["lag"]) for p in pts]

        if self._include_tables:
            return _html_data_table(series, "Consumer LAG", "건")
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Consumer LAG (월누적 일별)",
                subtitle="클러스터별 일일 Consumer LAG 지수 (건)",
            ),
            series=series, stat_title="Consumer LAG", stat_y_suffix="건",
        )
        return "\n".join(parts) if parts else None

    # ── SageMaker ──────────────────────────────────────

    def _build_sagemaker_section(self, data: DashboardDailyReportData) -> str | None:
        parts: list[str] = []

        # Pipeline 실패 차트
        if data.sagemaker_pipeline_failures:
            pipe_series: dict[str, list[tuple[str, float]]] = {}
            for name, pts in data.sagemaker_pipeline_failures.items():
                pipe_series[name] = [(p["date"], p["failures"]) for p in pts]
            self._append_chart(
                parts,
                self._line_chart(
                    pipe_series,
                    CHART_COLORS,
                    title="Pipeline 실패 현황 (월누적 일별)",
                    subtitle="파이프라인별 일일 실패 건수",
                    y_suffix="건",
                    y_integer=True,
                ),
                series=pipe_series, stat_title="Pipeline 실패", stat_y_suffix="건",
            )
            self._append_table(parts, pipe_series, "Pipeline 실패", "건")

        return "\n".join(parts) if parts else None

    # ── SageMaker Endpoint ─────────────────────────────

    def _build_sagemaker_endpoint_section(self, data: DashboardDailyReportData) -> str | None:
        parts: list[str] = []

        # Endpoint 에러 차트
        if data.sagemaker_endpoint_errors:
            for ep_name, pts in data.sagemaker_endpoint_errors.items():
                ep_series: dict[str, list[tuple[str, float]]] = {
                    "4xx": [(p["date"], p["4xx"]) for p in pts],
                    "5xx": [(p["date"], p["5xx"]) for p in pts],
                }
                self._append_chart(
                    parts,
                    self._line_chart(
                        ep_series,
                        ["#d97706", "#dc2626"],
                        title=f"{ep_name}",
                        subtitle="4xx / 5xx 에러 추이 (월누적 일별)",
                        y_suffix="건",
                        y_integer=True,
                        height=200,
                    ),
                    series=ep_series, stat_title=f"{ep_name} 에러", stat_y_suffix="건",
                    stat_colors=["#d97706", "#dc2626"],
                )
                self._append_table(parts, ep_series, f"{ep_name} 에러", "건")

        return "\n".join(parts) if parts else None

    # ── EMR ────────────────────────────────────────────

    def _build_emr_section(self, data: DashboardDailyReportData) -> str | None:
        parts: list[str] = []

        # Cluster 실패
        if data.emr_cluster_failures:
            cluster_series: dict[str, list[tuple[str, float]]] = {}
            for name, pts in data.emr_cluster_failures.items():
                cluster_series[name] = [(p["date"], p["failures"]) for p in pts]
            chart = self._line_chart(
                cluster_series,
                CHART_COLORS,
                title="일별 Job 실패 현황 (월누적)",
                subtitle="클러스터별 일일 실패 건수",
                y_suffix="건",
                y_integer=True,
            )
            self._append_chart(
                parts, self._with_mock_badge(chart, data.emr_cluster_is_mock) or chart,
                series=cluster_series, stat_title="EMR Cluster 실패", stat_y_suffix="건",
            )
            self._append_table(parts, cluster_series, "EMR Cluster 실패", "건")

        # Serverless 실패
        if data.emr_serverless_failures:
            sls_series: dict[str, list[tuple[str, float]]] = {}
            for name, pts in data.emr_serverless_failures.items():
                sls_series[name] = [(p["date"], p["failures"]) for p in pts]
            chart = self._line_chart(
                sls_series,
                CHART_COLORS,
                title="일별 Job 실패 현황 (월누적)",
                subtitle="애플리케이션별 일일 실패 건수",
                y_suffix="건",
                y_integer=True,
            )
            self._append_chart(
                parts, self._with_mock_badge(chart, data.emr_serverless_is_mock) or chart,
                series=sls_series, stat_title="EMR Serverless 실패", stat_y_suffix="건",
            )
            self._append_table(parts, sls_series, "EMR Serverless 실패", "건")

        return "\n".join(parts) if parts else None

    # ── Ingestion ─────────────────────────────────────

    # L0 소스 시스템 이름 및 색상 (프론트엔드 L0_SOURCES와 동일)
    _L0_SOURCE_NAMES = ["BCV", "DW", "EAI", "CDC", "FTP", "API", "S3", "Kafka", "SFTP", "MQ"]
    _L0_SOURCE_COLORS = [
        "#2563eb",
        "#16a34a",
        "#d97706",
        "#dc2626",
        "#7c3aed",
        "#0891b2",
        "#db2777",
        "#65a30d",
        "#ea580c",
        "#6366f1",
    ]

    def _build_ingestion_section(self, data: DashboardDailyReportData) -> str | None:
        ing = data.ingestion_rates
        if not ing:
            return None

        # L0 소스 이름: 데이터 첫 행에서 동적 추출 (프론트엔드와 동일 패턴)
        l0_first_row = (ing.get("l0_daily_success") or [None])[0]
        if l0_first_row and isinstance(l0_first_row, dict):
            l0_source_names = [k for k in l0_first_row if k not in ("date", "month")]
        else:
            l0_source_names = self._L0_SOURCE_NAMES  # fallback to hardcoded
        l0_source_colors = CHART_COLORS[:len(l0_source_names)] if l0_first_row else self._L0_SOURCE_COLORS

        # L1 소스 이름: 데이터 첫 행에서 동적 추출 (프론트엔드와 동일 패턴)
        l1_first_row = (ing.get("l1_daily_success") or [None])[0]
        l1_source_names: list[str] = []
        if l1_first_row and isinstance(l1_first_row, dict):
            l1_source_names = [k for k in l1_first_row if k not in ("date", "month")]
        l1_source_colors = CHART_COLORS

        # 차트 설정: (key, title, subtitle, source_names, source_colors)
        chart_groups: list[tuple[list[tuple[str, str, str]], list[str], list[str]]] = [
            (
                [
                    ("l0_daily_success", "L0 일배치 성공 건수", "시스템별 일일 성공 건수 (Stacked)"),
                    ("l0_daily_failure", "L0 일배치 실패 건수", "시스템별 일일 실패 건수 (Stacked)"),
                    ("l0_monthly_success", "L0 월별 성공 건수", "시스템별 월간 성공 건수 (Stacked)"),
                    ("l0_monthly_failure", "L0 월별 실패 건수", "시스템별 월간 실패 건수 (Stacked)"),
                ],
                l0_source_names, l0_source_colors,
            ),
            (
                [
                    ("l1_daily_success", "L1 가공 성공 건수", "시스템별 일일 성공 건수 (Stacked)"),
                    ("l1_daily_failure", "L1 가공 실패 건수", "시스템별 일일 실패 건수 (Stacked)"),
                    ("l1_monthly_success", "L1 월별 성공 건수", "시스템별 월간 성공 건수 (Stacked)"),
                    ("l1_monthly_failure", "L1 월별 실패 건수", "시스템별 월간 실패 건수 (Stacked)"),
                ],
                l1_source_names, l1_source_colors,
            ),
        ]

        chart_cells: list[str] = []
        table_parts: list[str] = []
        daily_keys = {
            "l0_daily_success", "l0_daily_failure",
            "l1_daily_success", "l1_daily_failure",
        }
        for chart_configs, source_names, source_colors in chart_groups:
            if not source_names:
                continue
            for key, title, subtitle in chart_configs:
                pts = ing.get(key)
                if not pts:
                    continue
                series: dict[str, list[tuple[str, float]]] = {
                    name: [(p.get("date") or p.get("month", ""), p.get(name, 0)) for p in pts] for name in source_names
                }
                if not self._include_tables:
                    chart_html = self._stacked_bar_chart(
                        series,
                        source_colors,
                        title=title,
                        subtitle=subtitle,
                        y_suffix="건",
                        y_integer=True,
                        height=200,
                    )
                    # email_mode + 일배치 데이터 → stat card를 차트 내부에 통합
                    if self._email_mode and key in daily_keys:
                        all_dates: set[str] = set()
                        for s_pts in series.values():
                            for d, _ in s_pts:
                                all_dates.add(d)
                        if len(all_dates) > 2:
                            stat_body = self._extract_latest_stat_card_body(
                                series, "건", source_colors,
                            )
                            marker = '<div style="margin-top:8px;border-left:3px solid'
                            if marker in chart_html:
                                chart_html = chart_html.replace(
                                    marker,
                                    f'<div style="margin-top:8px;margin-bottom:8px;">{stat_body}</div>{marker}',
                                    1,
                                )
                    chart_cells.append(chart_html)
                self._append_table(table_parts, series, title, "건")

        parts: list[str] = []
        if chart_cells:
            # 2열 테이블 레이아웃 (WeasyPrint 호환)
            parts.append('<table style="width:100%;border-collapse:separate;border-spacing:8px;">')
            for i in range(0, len(chart_cells), 2):
                parts.append("<tr>")
                parts.append(f'<td style="width:50%;vertical-align:top;">{chart_cells[i]}</td>')
                if i + 1 < len(chart_cells):
                    parts.append(f'<td style="width:50%;vertical-align:top;">{chart_cells[i + 1]}</td>')
                else:
                    parts.append('<td style="width:50%;"></td>')
                parts.append("</tr>")
            parts.append("</table>")
        parts.extend(table_parts)
        return "\n".join(parts) if parts else None

    # ── Universe ──────────────────────────────────────

    def _build_universe_section(self, data: DashboardDailyReportData) -> str | None:
        failures = data.universe_failures
        if not failures:
            return None

        series: dict[str, list[tuple[str, float]]] = {
            "입수 실패": [(p["date"], p.get("ingest", 0)) for p in failures],
            "전송 실패": [(p["date"], p.get("transfer", 0)) for p in failures],
        }
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                ["#dc2626", "#d97706"],
                title="일별 실패 건수 (월누적)",
                subtitle="Universe 파이프라인 입수 · 전송 실패 건수",
                y_suffix="건",
                y_integer=True,
            ),
            series=series, stat_title="Universe 파이프라인 실패", stat_y_suffix="건",
            stat_colors=["#dc2626", "#d97706"],
        )
        self._append_table(parts, series, "Universe 파이프라인 실패", "건")
        return "\n".join(parts) if parts else None

    # ── Sobicare ──────────────────────────────────────

    def _build_sobicare_section(self, data: DashboardDailyReportData) -> str | None:
        wf = data.sobicare_workflows
        if not wf:
            return None

        parts: list[str] = []

        # 일별 현황
        daily = wf.get("daily", [])
        if daily:
            daily_series: dict[str, list[tuple[str, float]]] = {
                "성공": [(p["date"], p.get("success", 0)) for p in daily],
                "실패": [(p["date"], p.get("failure", 0)) for p in daily],
            }
            self._append_chart(
                parts,
                self._line_chart(
                    daily_series,
                    ["#22c55e", "#ef4444"],
                    title="일배치 Workflow 성공/실패 (월누적)",
                    subtitle="소비케어 일배치 Workflow 일별 실행 현황",
                    y_suffix="건",
                    y_integer=True,
                ),
                series=daily_series, stat_title="소비케어 일배치", stat_y_suffix="건",
                stat_colors=["#22c55e", "#ef4444"],
            )
            self._append_table(parts, daily_series, "소비케어 Workflow 일별", "건")

        # 월별 현황
        monthly = wf.get("monthly", [])
        if monthly:
            monthly_series: dict[str, list[tuple[str, float]]] = {
                "성공": [(p["month"], p.get("success", 0)) for p in monthly],
                "실패": [(p["month"], p.get("failure", 0)) for p in monthly],
            }
            self._append_chart(
                parts,
                self._line_chart(
                    monthly_series,
                    ["#22c55e", "#ef4444"],
                    title="월배치 Workflow 성공/실패 (월누적)",
                    subtitle="소비케어 월배치 Workflow 월별 실행 현황",
                    y_suffix="건",
                    y_integer=True,
                ),
                series=monthly_series, stat_title="소비케어 월배치", stat_y_suffix="건",
                stat_colors=["#22c55e", "#ef4444"],
            )
            self._append_table(parts, monthly_series, "소비케어 Workflow 월별", "건")

        return "\n".join(parts) if parts else None

    # ── KPI ────────────────────────────────────────────

    def _build_kpi_section(self, data: DashboardDailyReportData) -> str | None:
        rates = data.wfl_monthly_rates
        if not rates and not data.team_success_rates and not data.team_task_rates:
            return None

        parts: list[str] = []

        if rates:
            series: dict[str, list[tuple[str, float]]] = {
                "성공률": [(p["month"], p.get("rate", 0)) for p in rates],
            }
            wfl_chart = self._line_chart(
                series,
                CHART_COLORS,
                title="WFL DAG 월별 성공률",
                subtitle="월별 전체 DAG 실행 대비 성공 비율 (%)",
                y_suffix="%",
                y_domain=(0, 100),
                reference_lines=[{"value": 90, "label": "목표 90%", "color": "#dc2626"}],
            )
            if data.kpi_is_mock:
                wfl_chart = self._with_mock_badge(wfl_chart, data.kpi_is_mock) or wfl_chart
            self._append_chart(parts, wfl_chart)
            self._append_table(parts, series, "WFL DAG 월별 성공률", "%")

        # 팀별 월 DAG 성공률 테이블
        if data.team_success_rates:
            if data.team_success_is_mock and self._skip_mock:
                pass  # 운영계: mock 차트 생략
            else:
                team_html = self._build_team_success_rate_table(data.team_success_rates)
                if data.team_success_is_mock:
                    team_html = team_html.replace("</h4>", f"{self._mock_badge()}</h4>", 1)
                parts.append(team_html)

        # 팀별 Task 성공/실패 현황 테이블
        if data.team_task_rates:
            if data.team_task_is_mock and self._skip_mock:
                pass  # 운영계: mock 차트 생략
            else:
                task_html = self._build_team_task_table(data.team_task_rates)
                if data.team_task_is_mock:
                    task_html = task_html.replace("</h4>", f"{self._mock_badge()}</h4>", 1)
                parts.append(task_html)

        return "\n".join(parts) if parts else None

    def _build_team_success_rate_table(self, team_rates: list[dict[str, Any]]) -> str:
        """팀별 월 DAG 성공률 HTML 테이블 생성.

        90% 미만 셀은 빨간색 텍스트 + 연한 빨간 배경으로 강조.
        """
        if not team_rates:
            return ""

        # 월 컬럼 수집 (첫 번째 팀의 months 키 순서 사용)
        month_labels: list[str] = []
        for row in team_rates:
            months = row.get("months", {})
            for ml in months:
                if ml not in month_labels:
                    month_labels.append(ml)

        # 헤더
        header_cells = [
            '<th style="padding:6px 10px;font-size:12px;font-weight:600;'
            'text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;">팀</th>'
        ]
        for ml in month_labels:
            header_cells.append(
                f'<th style="padding:6px 10px;font-size:12px;font-weight:600;'
                f'text-align:center;border-bottom:2px solid #e5e7eb;white-space:nowrap;">{html_escape(ml)}</th>'
            )

        # 행
        rows: list[str] = []
        for row in team_rates:
            team_name = row.get("team", "")
            months = row.get("months", {})
            cells = [
                f'<td style="padding:5px 10px;font-size:12px;font-weight:500;'
                f'border-bottom:1px solid #f3f4f6;white-space:nowrap;">{html_escape(team_name)}</td>'
            ]
            for ml in month_labels:
                val = months.get(ml)
                if val is None:
                    cells.append(
                        '<td style="padding:5px 10px;font-size:12px;text-align:center;'
                        'border-bottom:1px solid #f3f4f6;color:#9ca3af;">-</td>'
                    )
                else:
                    rate = val.get("rate", 0) if isinstance(val, dict) else val
                    ok = val.get("ok", 0) if isinstance(val, dict) else None
                    total = val.get("total", 0) if isinstance(val, dict) else None
                    if rate < 90:
                        style = (
                            "padding:5px 10px;font-size:12px;text-align:center;"
                            "border-bottom:1px solid #f3f4f6;"
                            "color:#dc2626;background:#fef2f2;font-weight:600;"
                        )
                    else:
                        style = (
                            "padding:5px 10px;font-size:12px;text-align:center;"
                            "border-bottom:1px solid #f3f4f6;"
                        )
                    if ok is not None and total is not None:
                        cells.append(
                            f'<td style="{style}">{rate:.1f}%'
                            f'<br><span style="font-size:10px;color:#9ca3af;font-weight:400;">'
                            f"{ok}/{total}</span></td>"
                        )
                    else:
                        cells.append(f'<td style="{style}">{rate:.1f}</td>')
            rows.append(f"<tr>{''.join(cells)}</tr>")

        return (
            '<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;'
            'border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
            '<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">팀별 월 DAG 성공률 (%)</h4>'
            '<p style="font-size:12px;color:#6b7280;margin:0;">목표 : 8월부터 90% 이상 유지</p>'
            '<div style="overflow:auto;margin-top:8px;border:1px solid #e5e7eb;border-radius:6px;">'
            '<table style="width:100%;border-collapse:collapse;">'
            f"<thead><tr>{''.join(header_cells)}</tr></thead>"
            f"<tbody>{''.join(rows)}</tbody>"
            "</table></div></div>"
        )

    def _build_team_task_table(self, team_task_rates: dict[str, Any]) -> str:
        """팀별 Task 성공/실패 현황 HTML 테이블 생성.

        월별로 분리된 섹션을 생성하며, 90% 미만 셀은 빨간색으로 강조.
        """
        task_types: list[dict] = team_task_rates.get("task_types", [])
        teams: dict = team_task_rates.get("teams", {})
        if not task_types or not teams:
            return ""

        # 월 목록 수집 (첫 번째 팀의 첫 번째 task의 키 순서 사용)
        month_labels: list[str] = []
        for _team, tasks in teams.items():
            for _task_key, month_data in tasks.items():
                for ml in month_data:
                    if ml not in month_labels:
                        month_labels.append(ml)
                break
            break

        sections: list[str] = []
        for month in month_labels:
            # 헤더
            header_cells = [
                '<th style="padding:6px 10px;font-size:12px;font-weight:600;'
                'text-align:left;border-bottom:2px solid #e5e7eb;white-space:nowrap;">팀</th>'
            ]
            for tt in task_types:
                header_cells.append(
                    f'<th style="padding:6px 10px;font-size:12px;font-weight:600;'
                    f'text-align:center;border-bottom:2px solid #e5e7eb;white-space:nowrap;">'
                    f"{html_escape(tt['label'])}</th>"
                )

            # 행
            rows: list[str] = []
            for team_name, tasks in teams.items():
                cells = [
                    f'<td style="padding:5px 10px;font-size:12px;font-weight:500;'
                    f'border-bottom:1px solid #f3f4f6;white-space:nowrap;">{html_escape(team_name)}</td>'
                ]
                for tt in task_types:
                    cell = tasks.get(tt["key"], {}).get(month)
                    if cell is None:
                        cells.append(
                            '<td style="padding:5px 10px;font-size:12px;text-align:center;'
                            'border-bottom:1px solid #f3f4f6;color:#9ca3af;">-</td>'
                        )
                    else:
                        rate = cell.get("rate", 0)
                        ok = cell.get("ok", 0)
                        total = cell.get("total", 0)
                        if rate < 90:
                            style = (
                                "padding:5px 10px;font-size:12px;text-align:center;"
                                "border-bottom:1px solid #f3f4f6;"
                                "color:#dc2626;background:#fef2f2;font-weight:600;"
                            )
                        else:
                            style = (
                                "padding:5px 10px;font-size:12px;text-align:center;"
                                "border-bottom:1px solid #f3f4f6;"
                            )
                        cells.append(
                            f'<td style="{style}">{rate:.1f}%'
                            f'<br><span style="font-size:10px;color:#9ca3af;font-weight:400;">'
                            f"{ok}/{total}</span></td>"
                        )
                rows.append(f"<tr>{''.join(cells)}</tr>")

            sections.append(
                f'<div style="margin-bottom:8px;">'
                f'<h5 style="font-size:13px;font-weight:600;color:#6b7280;margin:0 0 4px;">{html_escape(month)}</h5>'
                f'<div style="overflow:auto;border:1px solid #e5e7eb;border-radius:6px;">'
                f'<table style="width:100%;border-collapse:collapse;">'
                f"<thead><tr>{''.join(header_cells)}</tr></thead>"
                f"<tbody>{''.join(rows)}</tbody>"
                f"</table></div></div>"
            )

        return (
            '<div class="chart-wrapper" style="background:#fff;border:1px solid #e5e7eb;'
            'border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
            '<h4 style="font-size:14px;font-weight:600;margin:0 0 2px;">팀별 Task 성공/실패 현황</h4>'
            '<p style="font-size:12px;color:#6b7280;margin:0 0 8px;">팀별 집중 공략 Task 파악용 · 90% 미만 하이라이트</p>'
            + "\n".join(sections)
            + "</div>"
        )

    # ── Cost ───────────────────────────────────────────

    def _build_cost_section(self, data: DashboardDailyReportData) -> str | None:
        if not data.cost_monthly and not data.cost_daily:
            return None

        parts: list[str] = []

        # Budget Summary 카드 (Frontend BudgetSummaryCards와 동일)
        if data.cost_budget and data.cost_monthly:
            from datetime import datetime as _dt_budget

            annual_total = data.cost_budget.get("annual_total", 0)
            current_ym = _dt_budget.now().strftime("%Y%m")
            actual_months = [m for m in data.cost_monthly if m.get("month", "") <= current_ym]
            ytd_used = sum(m.get("total", 0) for m in actual_months)
            annual_remaining = annual_total - ytd_used
            months_passed = len([m for m in actual_months if m.get("total", 0) > 0]) or 1
            months_left = 12 - months_passed
            monthly_remaining = annual_remaining / months_left if months_left > 0 else 0

            def _fmt_krw(v: float) -> str:
                if abs(v) >= 1e8:
                    return f"{v / 1e8:,.1f}억"
                if abs(v) >= 1e4:
                    return f"{v / 1e4:,.0f}만"
                return f"{v:,.0f}"

            budget_stats = [
                {"label": "연간 예산", "value": _fmt_krw(annual_total), "color": "#1976D2"},
                {"label": "YTD 사용액", "value": _fmt_krw(ytd_used), "color": "#1976D2"},
                {"label": "연간 잔여", "value": _fmt_krw(annual_remaining), "color": "#388E3C"},
                {"label": "월평균 잔여", "value": _fmt_krw(monthly_remaining), "color": "#388E3C"},
            ]
            parts.append(self.render_stat_cards(budget_stats, columns=4))

        budget_target = data.cost_budget.get("monthly_target", 0) if data.cost_budget else 0
        ref_lines = (
            [{"value": budget_target, "label": f"목표 {budget_target:,.0f}", "color": "#dc2626"}]
            if budget_target
            else None
        )

        # 일별 비용 (웹 원본과 동일하게 일별→월별 순서)
        if data.cost_daily:
            svc_names_d: set[str] = set()
            projected_days: set[str] = set()
            for d in data.cost_daily:
                if d.get("is_projected"):
                    projected_days.add(d.get("day", ""))
                svc_names_d.update(d.get("services", {}).keys())
            svc_list_d = sorted(svc_names_d)

            # 일별 목표선 = 월 목표 / 해당월 일수
            import calendar
            from datetime import datetime as _dt

            _now = _dt.now()
            _days_in_month = calendar.monthrange(_now.year, _now.month)[1]
            daily_target = budget_target / _days_in_month if budget_target else 0
            daily_ref_lines = (
                [
                    {
                        "value": daily_target,
                        "label": f"일 목표 {daily_target:,.0f}",
                        "color": "#dc2626",
                    }
                ]
                if daily_target
                else None
            )

            if svc_list_d:
                daily_series: dict[str, list[tuple[str, float]]] = {}
                for svc in svc_list_d:
                    daily_series[svc] = []
                for d in data.cost_daily:
                    day_label = d.get("day", "")
                    services = d.get("services", {})
                    for svc in svc_list_d:
                        daily_series[svc].append((day_label, services.get(svc, 0)))
                self._append_chart(
                    parts,
                    self._stacked_bar_chart(
                        daily_series,
                        COST_COLORS,
                        title=f"{_now.month}월 일별 AWS 서비스 비용",
                        subtitle="서비스별 스택 막대 차트",
                        y_suffix="",
                        reference_lines=daily_ref_lines,
                        x_formatter=lambda s: f"{int(s[-2:])}일" if len(s) >= 8 else s,
                        y_formatter=_fmt_korean_unit,
                        projected_labels=projected_days or None,
                    ),
                )
            else:
                daily_series_total: dict[str, list[tuple[str, float]]] = {
                    "비용": [(d.get("day", ""), d.get("total", 0)) for d in data.cost_daily],
                }
                self._append_chart(
                    parts,
                    self._stacked_bar_chart(
                        daily_series_total,
                        COST_COLORS,
                        title=f"{_now.month}월 일별 AWS 비용",
                        subtitle="일별 비용 추이",
                        y_suffix="",
                        reference_lines=daily_ref_lines,
                        x_formatter=lambda s: f"{int(s[-2:])}일" if len(s) >= 8 else s,
                        y_formatter=_fmt_korean_unit,
                        projected_labels=projected_days or None,
                    ),
                )

        # 월별 비용
        if data.cost_monthly:
            # 서비스별 분리
            svc_names: set[str] = set()
            projected_months: set[str] = set()
            for m in data.cost_monthly:
                if m.get("is_projected"):
                    projected_months.add(m.get("month", ""))
                svc_names.update(m.get("services", {}).keys())
            svc_list = sorted(svc_names)

            if svc_list:
                monthly_series: dict[str, list[tuple[str, float]]] = {}
                for svc in svc_list:
                    monthly_series[svc] = []
                for m in data.cost_monthly:
                    month_label = m.get("month", "")
                    services = m.get("services", {})
                    for svc in svc_list:
                        monthly_series[svc].append((month_label, services.get(svc, 0)))
                self._append_chart(
                    parts,
                    self._stacked_bar_chart(
                        monthly_series,
                        COST_COLORS,
                        title="월별 AWS 서비스 비용",
                        subtitle=f"월 목표 {budget_target:,.0f} · 서비스별 스택 막대 차트",
                        y_suffix="",
                        reference_lines=ref_lines,
                        x_formatter=lambda s: f"{s[-2:]}월" if len(s) >= 6 else s,
                        y_formatter=_fmt_korean_unit,
                        projected_labels=projected_months or None,
                    ),
                )
            else:
                monthly_series_total: dict[str, list[tuple[str, float]]] = {
                    "비용": [(m.get("month", ""), m.get("total", 0)) for m in data.cost_monthly],
                }
                self._append_chart(
                    parts,
                    self._stacked_bar_chart(
                        monthly_series_total,
                        COST_COLORS,
                        title="월별 AWS 비용",
                        subtitle="월별 비용 추이",
                        y_suffix="",
                        reference_lines=ref_lines,
                        x_formatter=lambda s: f"{s[-2:]}월" if len(s) >= 6 else s,
                        y_formatter=_fmt_korean_unit,
                        projected_labels=projected_months or None,
                    ),
                )

        return "\n".join(parts) if parts else None

    # ── DB 연동 ────────────────────────────────────────

    def generate_from_db(self, report) -> str:
        """DB에서 읽은 DashboardReport 객체의 summary_json으로 HTML 재생성."""
        data = self.data_from_json(report)
        return self.generate_report(data)

    @staticmethod
    def data_to_json(data: DashboardDailyReportData) -> str:
        """DashboardDailyReportData → summary JSON 문자열."""
        return json.dumps(
            {
                "services": data.services,
                "airflow_rates": data.airflow_rates,
                "msk_lag": data.msk_lag,
                "s3_size": data.s3_size,
                "sagemaker_users": data.sagemaker_users,
                "sagemaker_endpoint_errors": data.sagemaker_endpoint_errors,
                "sagemaker_pipeline_failures": data.sagemaker_pipeline_failures,
                "emr_cluster_failures": data.emr_cluster_failures,
                "emr_serverless_failures": data.emr_serverless_failures,
                "dag_sla_status": data.dag_sla_status,
                "rds_cpu": data.rds_cpu,
                "rds_connections": data.rds_connections,
                "rds_memory": data.rds_memory,
                "rds_iops": data.rds_iops,
                "rds_storage_free": data.rds_storage_free,
                "ingestion_rates": data.ingestion_rates,
                "universe_failures": data.universe_failures,
                "sobicare_workflows": data.sobicare_workflows,
                "wfl_monthly_rates": data.wfl_monthly_rates,
                "cost_monthly": data.cost_monthly,
                "cost_daily": data.cost_daily,
                "cost_budget": data.cost_budget,
                "dag_interface_rates": data.dag_interface_rates,
                "team_success_rates": data.team_success_rates,
                "dag_sla_is_mock": data.dag_sla_is_mock,
                "dag_interface_is_mock": data.dag_interface_is_mock,
            },
            ensure_ascii=False,
        )

    @staticmethod
    def data_from_json(report) -> DashboardDailyReportData:
        """DashboardReport의 summary_json → DashboardDailyReportData 복원."""
        raw: dict[str, Any] = {}
        if report.summary_json:
            raw = json.loads(report.summary_json)

        return DashboardDailyReportData(
            total_domains=0,  # summary에서 재계산
            total_resources=report.total_services,
            running=report.healthy,
            attention=report.critical,
            services=raw.get("services", {}),
            airflow_rates=raw.get("airflow_rates", {}),
            msk_lag=raw.get("msk_lag", {}),
            s3_size=raw.get("s3_size", {}),
            sagemaker_users=raw.get("sagemaker_users", []),
            sagemaker_endpoint_errors=raw.get("sagemaker_endpoint_errors", {}),
            sagemaker_pipeline_failures=raw.get("sagemaker_pipeline_failures", {}),
            emr_cluster_failures=raw.get("emr_cluster_failures", {}),
            emr_serverless_failures=raw.get("emr_serverless_failures", {}),
            dag_sla_status=raw.get("dag_sla_status", {}),
            rds_cpu=raw.get("rds_cpu", {}),
            rds_connections=raw.get("rds_connections", {}),
            rds_memory=raw.get("rds_memory", {}),
            rds_iops=raw.get("rds_iops", {}),
            rds_storage_free=raw.get("rds_storage_free", {}),
            ingestion_rates=raw.get("ingestion_rates", {}),
            universe_failures=raw.get("universe_failures", []),
            sobicare_workflows=raw.get("sobicare_workflows", {}),
            wfl_monthly_rates=raw.get("wfl_monthly_rates", []),
            cost_monthly=raw.get("cost_monthly", []),
            cost_daily=raw.get("cost_daily", []),
            cost_budget=raw.get("cost_budget", {}),
            dag_interface_rates=raw.get("dag_interface_rates", {}),
            team_success_rates=raw.get("team_success_rates", []),
            dag_sla_is_mock=bool(raw.get("dag_sla_is_mock")),
            dag_interface_is_mock=bool(raw.get("dag_interface_is_mock")),
        )


# ── Helpers ────────────────────────────────────────────


def _overall_status(resources: list[dict[str, Any]]) -> str:
    """리소스 목록에서 전체 상태 계산."""
    statuses = [r.get("display_status", "neutral") for r in resources]
    if "critical" in statuses:
        return "critical"
    if "warning" in statuses:
        return "warning"
    if all(s == "ok" for s in statuses):
        return "ok"
    return "neutral"
