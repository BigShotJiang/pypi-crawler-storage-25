"""Airflow Stats Service - MWAA 환경별 일별 DAG/Task 성공률."""

import logging
import random
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from src.common.timezone import KST
from src.portal.config import PortalSettings

logger = logging.getLogger(__name__)


class AirflowStatsService:
    """MWAA 환경별 일별 DAG/Task 성공률 서비스."""

    def __init__(self, settings: PortalSettings):
        self._settings = settings
        self._provider: Any = None
        self._initialized = False

    @property
    def _is_dev(self) -> bool:
        return self._settings.environment == "test"

    def _ensure_provider(self):
        """prod 환경에서만 AirflowFailureStore provider를 초기화."""
        if self._initialized or self._is_dev:
            return
        self._initialized = True

        try:
            from src.agent_server.bdp_airflow.services.airflow_failure_store import (
                AirflowFailureStore,
            )

            provider_type = self._settings.rds_provider
            if provider_type == "sqlite":
                self._provider = AirflowFailureStore.create_provider(
                    "sqlite",
                    db_path=self._settings.sqlite_path,
                )
            elif provider_type == "mysql":
                self._provider = AirflowFailureStore.create_provider(
                    "mysql",
                    secret_id=self._settings.baseline_secret_id,
                    db=self._settings.rds_database,
                )
            else:
                self._provider = AirflowFailureStore.create_provider("mock")
            logger.info("AirflowStatsService: provider=%s", type(self._provider).__name__)
        except Exception as e:
            logger.warning("Failed to create airflow stats provider: %s", e)

    def get_daily_rates(self, days: int = 31) -> dict[str, Any]:
        """환경별 일별 DAG/Task 성공률 조회."""
        if self._is_dev:
            return self._read_sqlite(days)

        self._ensure_provider()
        if not self._provider:
            return self._empty_response()

        try:
            records = self._provider.get_failures(hours=days * 24)
        except Exception as e:
            logger.error("Failed to fetch airflow records: %s", e)
            return self._empty_response(error=str(e))

        return self._aggregate(records)

    # ── Dev: SQLite 직접 조회 ─────────────────────────

    def _read_sqlite(self, days: int) -> dict[str, Any]:
        """dev 환경에서 SQLite 직접 조회."""
        db_path = Path(self._settings.sqlite_path)
        if not db_path.exists():
            logger.warning("SQLite DB not found: %s — using dynamic mock", db_path)
            return self._mock_daily_rates(days)

        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cutoff = (datetime.now(KST).date() - timedelta(days=days - 1)).isoformat() + " 00:00:00"
            rows = conn.execute(
                "SELECT start_date, rcpt_tp, dag_id, task_id, state, run_id "
                "FROM wfl_awf_hst WHERE start_date >= ? ORDER BY start_date DESC",
                (cutoff,),
            ).fetchall()
            conn.close()
        except Exception as e:
            logger.warning("SQLite read failed: %s", e)
            return self._empty_response(error=str(e))

        if not rows:
            return self._mock_daily_rates(days)

        @dataclass
        class _Record:
            start_date: str
            rcpt_tp: str
            dag_id: str
            task_id: str
            state: str
            run_id: str

        records = [_Record(**dict(r)) for r in rows]
        logger.info("SQLite: %d records loaded", len(records))
        return self._aggregate(records)

    # ── Dev: 동적 mock 데이터 ──────────────────────────

    def _mock_daily_rates(self, days: int) -> dict[str, Any]:
        """SQLite에 유효 데이터가 없을 때 동적 mock 데이터 생성."""
        today = datetime.now(KST).date()
        dates = [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]

        environments: dict[str, Any] = {}
        for env in ("dlk", "wfl"):
            daily_rates: list[dict[str, Any]] = []
            for d in dates:
                # 일반적으로 높은 성공률, 간헐적 실패 스파이크
                is_bad_day = random.random() < 0.08
                dag_total = random.randint(8, 20)
                task_total = dag_total * random.randint(3, 5)

                if is_bad_day:
                    dag_ok = int(dag_total * random.uniform(0.70, 0.88))
                    task_ok = int(task_total * random.uniform(0.75, 0.90))
                else:
                    dag_ok = int(dag_total * random.uniform(0.92, 1.0))
                    task_ok = int(task_total * random.uniform(0.94, 1.0))

                dag_rate = round((dag_ok / dag_total) * 100, 1) if dag_total > 0 else 0.0
                task_rate = round((task_ok / task_total) * 100, 1) if task_total > 0 else 0.0

                daily_rates.append(
                    {
                        "date": d,
                        "dag_success_rate": dag_rate,
                        "task_success_rate": task_rate,
                        "dag_total": dag_total,
                        "dag_ok": dag_ok,
                        "task_total": task_total,
                        "task_ok": task_ok,
                    }
                )
            environments[env] = {"daily_rates": daily_rates}

        return {
            "environments": environments,
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
            "is_mock": True,
        }

    # ── 집계 ──────────────────────────────────────────

    def _aggregate(self, records: list) -> dict[str, Any]:
        """레코드를 환경별 일별 성공률로 집계."""
        env_day: dict[str, dict[str, dict[str, Any]]] = defaultdict(
            lambda: defaultdict(
                lambda: {"dag_runs": defaultdict(list), "task_total": 0, "task_ok": 0}
            )
        )

        for r in records:
            try:
                dt = r.start_date[:10]  # "YYYY-MM-DD"
            except Exception:
                continue

            bucket = env_day[r.rcpt_tp][dt]
            bucket["task_total"] += 1
            if r.state == "success":
                bucket["task_ok"] += 1

            run_key = r.run_id if r.run_id else f"{r.dag_id}_{dt}"
            bucket["dag_runs"][run_key].append(r.state)

        environments: dict[str, Any] = {}
        for env, days_data in sorted(env_day.items()):
            daily_rates: list[dict[str, Any]] = []
            for date_str in sorted(days_data.keys()):
                bucket = days_data[date_str]
                task_total = bucket["task_total"]
                task_ok = bucket["task_ok"]
                task_rate = round((task_ok / task_total) * 100, 1) if task_total > 0 else 0.0

                dag_runs = bucket["dag_runs"]
                dag_total = len(dag_runs)
                dag_ok = sum(
                    1 for states in dag_runs.values() if all(s == "success" for s in states)
                )
                dag_rate = round((dag_ok / dag_total) * 100, 1) if dag_total > 0 else 0.0

                daily_rates.append(
                    {
                        "date": date_str,
                        "dag_success_rate": dag_rate,
                        "task_success_rate": task_rate,
                        "dag_total": dag_total,
                        "dag_ok": dag_ok,
                        "task_total": task_total,
                        "task_ok": task_ok,
                    }
                )

            environments[env] = {"daily_rates": daily_rates}

        return {
            "environments": environments,
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
        }

    def _empty_response(self, error: str | None = None) -> dict[str, Any]:
        result: dict[str, Any] = {
            "environments": {},
            "fetched_at": datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST"),
        }
        if error:
            result["error"] = error
        return result
