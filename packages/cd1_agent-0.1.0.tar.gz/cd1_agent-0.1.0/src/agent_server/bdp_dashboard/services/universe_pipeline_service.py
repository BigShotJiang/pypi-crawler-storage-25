"""Universe Pipeline 현황 데이터 서비스.

프론트엔드에서 하드코딩되어 있던 파이프라인/Athena/S3 mock 데이터를
Agent Server에서 제공하기 위한 서비스. 추후 실제 AWS 연동으로 교체 예정.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


def _generate_dates(count: int, end_date: str) -> list[str]:
    end = datetime.strptime(end_date, "%Y-%m-%d")
    return [(end - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(count - 1, -1, -1)]


def _today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")


class UniversePipelineService:
    """Universe 입수/전송 파이프라인 현황 데이터."""

    def get_pipeline_data(self) -> dict:
        today = _today_str()
        recent_dates = _generate_dates(7, today)

        pipeline_status = {
            "dmzS3": {
                "status": "ok",
                "todayFiles": 142,
                "todaySizeGb": 3.2,
                "lastUpdate": f"{today}T08:30:00",
            },
            "wfl": {
                "status": "ok",
                "dagId": "universe_dlk",
                "runState": "success",
                "duration": "00:12:34",
                "lastRun": f"{today}T09:00:00",
            },
            "bdpS3": {
                "status": "ok",
                "copiedFiles": 142,
                "copiedSizeGb": 3.2,
                "lastUpdate": f"{today}T09:05:00",
            },
        }

        athena_tables = [
            {
                "name": "브루노 마트 테이블",
                "id": "bruno_mart",
                "latestPartition": today,
                "recordCount": 820_000,
            },
            {
                "name": "메타테이블",
                "id": "meta_table",
                "latestPartition": today,
                "recordCount": 215_000,
            },
            {
                "name": "통합메타테이블",
                "id": "unified_meta",
                "latestPartition": today,
                "recordCount": 215_000,
            },
        ]

        athena_schemas = {
            "bruno_mart": {
                "tableType": "EXTERNAL_TABLE",
                "location": "s3://bdp-universe-prod/bruno_mart/",
                "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
                "recordCount": 820_000,
                "latestPartition": today,
                "columns": [
                    {"name": "user_id", "type": "string", "comment": "사용자 고유 ID"},
                    {"name": "product_id", "type": "string", "comment": "상품 ID"},
                    {"name": "category", "type": "string", "comment": "상품 카테고리"},
                    {"name": "amount", "type": "bigint", "comment": "거래 금액"},
                    {"name": "quantity", "type": "int", "comment": "수량"},
                    {"name": "event_time", "type": "timestamp", "comment": "이벤트 발생 시각"},
                    {"name": "channel", "type": "string", "comment": "유입 채널"},
                ],
                "partitionKeys": [
                    {"name": "dt", "type": "string", "comment": "일자 파티션 (YYYY-MM-DD)"},
                ],
            },
            "meta_table": {
                "tableType": "EXTERNAL_TABLE",
                "location": "s3://bdp-universe-prod/meta_table/",
                "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
                "recordCount": 215_000,
                "latestPartition": today,
                "columns": [
                    {"name": "table_name", "type": "string", "comment": "테이블명"},
                    {"name": "column_name", "type": "string", "comment": "컬럼명"},
                    {"name": "data_type", "type": "string", "comment": "데이터 타입"},
                    {"name": "description", "type": "string", "comment": "컬럼 설명"},
                    {"name": "owner", "type": "string", "comment": "소유자"},
                    {"name": "updated_at", "type": "timestamp", "comment": "최종 수정일"},
                ],
                "partitionKeys": [
                    {"name": "dt", "type": "string", "comment": "일자 파티션 (YYYY-MM-DD)"},
                ],
            },
            "unified_meta": {
                "tableType": "EXTERNAL_TABLE",
                "location": "s3://bdp-universe-prod/unified_meta/",
                "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
                "recordCount": 215_000,
                "latestPartition": today,
                "columns": [
                    {"name": "source_system", "type": "string", "comment": "출처 시스템"},
                    {"name": "table_name", "type": "string", "comment": "테이블명"},
                    {"name": "column_name", "type": "string", "comment": "컬럼명"},
                    {"name": "data_type", "type": "string", "comment": "데이터 타입"},
                    {"name": "lineage", "type": "string", "comment": "데이터 리니지"},
                    {"name": "quality_score", "type": "double", "comment": "품질 점수"},
                    {"name": "updated_at", "type": "timestamp", "comment": "최종 수정일"},
                ],
                "partitionKeys": [
                    {"name": "dt", "type": "string", "comment": "일자 파티션 (YYYY-MM-DD)"},
                ],
            },
        }

        def _s3_dates(base_files: int, base_gb: float) -> list[dict]:
            return [
                {
                    "date": d,
                    "files": base_files + (i % 3),
                    "sizeGb": round(base_gb + i * 0.05, 2),
                }
                for i, d in enumerate(recent_dates)
            ]

        dmz_s3_tables = {
            "user_activity": {"dates": _s3_dates(48, 1.2)},
            "transaction_log": {
                "dates": [
                    {"date": d, "files": 36 + (i % 4), "sizeGb": round(0.8 + i * 0.03, 2)}
                    for i, d in enumerate(recent_dates)
                ]
            },
            "product_catalog": {
                "dates": [
                    {"date": d, "files": 12 + (i % 2), "sizeGb": round(0.3 + i * 0.01, 2)}
                    for i, d in enumerate(recent_dates)
                ]
            },
            "session_events": {
                "dates": [
                    {"date": d, "files": 58 + (i % 5), "sizeGb": round(1.5 + i * 0.04, 2)}
                    for i, d in enumerate(recent_dates)
                ]
            },
        }

        bdp_s3_tables = {
            "bruno_mart": {"dates": _s3_dates(48, 1.2)},
            "meta_table": {
                "dates": [
                    {"date": d, "files": 24 + (i % 3), "sizeGb": round(0.5 + i * 0.02, 2)}
                    for i, d in enumerate(recent_dates)
                ]
            },
            "unified_meta": {
                "dates": [
                    {"date": d, "files": 24 + (i % 2), "sizeGb": round(0.5 + i * 0.02, 2)}
                    for i, d in enumerate(recent_dates)
                ]
            },
        }

        # 전송 파이프라인
        transfer_athena_tables = [
            {
                "name": "GV 거래 테이블",
                "id": "gv_transaction",
                "latestPartition": today,
                "recordCount": 1_230_000,
            },
            {
                "name": "GV 정산 테이블",
                "id": "gv_settlement",
                "latestPartition": today,
                "recordCount": 540_000,
            },
        ]

        transfer_athena_schemas = {
            "gv_transaction": {
                "tableType": "EXTERNAL_TABLE",
                "location": "s3://bdp-universe-prod/gv_transaction/",
                "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
                "recordCount": 1_230_000,
                "latestPartition": today,
                "columns": [
                    {"name": "tx_id", "type": "string", "comment": "거래 고유 ID"},
                    {"name": "account_id", "type": "string", "comment": "계정 ID"},
                    {"name": "amount", "type": "bigint", "comment": "거래 금액"},
                    {"name": "currency", "type": "string", "comment": "통화 코드"},
                    {"name": "status", "type": "string", "comment": "거래 상태"},
                    {"name": "created_at", "type": "timestamp", "comment": "거래 생성 시각"},
                ],
                "partitionKeys": [
                    {"name": "dt", "type": "string", "comment": "일자 파티션 (YYYY-MM-DD)"},
                ],
            },
            "gv_settlement": {
                "tableType": "EXTERNAL_TABLE",
                "location": "s3://bdp-universe-prod/gv_settlement/",
                "serde": "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe",
                "recordCount": 540_000,
                "latestPartition": today,
                "columns": [
                    {"name": "settlement_id", "type": "string", "comment": "정산 고유 ID"},
                    {"name": "merchant_id", "type": "string", "comment": "가맹점 ID"},
                    {"name": "total_amount", "type": "bigint", "comment": "정산 총액"},
                    {"name": "fee", "type": "bigint", "comment": "수수료"},
                    {"name": "net_amount", "type": "bigint", "comment": "순 정산액"},
                    {"name": "settled_at", "type": "timestamp", "comment": "정산 완료 시각"},
                ],
                "partitionKeys": [
                    {"name": "dt", "type": "string", "comment": "일자 파티션 (YYYY-MM-DD)"},
                ],
            },
        }

        transfer_status = {
            "bdpAthena": {
                "status": "ok",
                "tables": len(transfer_athena_tables),
                "latestPartition": today,
            },
            "bdpWfl": {
                "status": "ok",
                "dagId": "universe_transfer",
                "runState": "success",
                "lastRun": f"{today}T10:00:00",
            },
            "gvApiPod": {
                "status": "ok",
                "podName": "gv-external-api",
                "namespace": "universe",
                "replicas": "2/2",
            },
        }

        return {
            "pipeline_status": pipeline_status,
            "athena_tables": athena_tables,
            "athena_schemas": athena_schemas,
            "dmz_s3_tables": dmz_s3_tables,
            "bdp_s3_tables": bdp_s3_tables,
            "transfer_athena_tables": transfer_athena_tables,
            "transfer_athena_schemas": transfer_athena_schemas,
            "transfer_status": transfer_status,
            "is_mock": True,
        }
