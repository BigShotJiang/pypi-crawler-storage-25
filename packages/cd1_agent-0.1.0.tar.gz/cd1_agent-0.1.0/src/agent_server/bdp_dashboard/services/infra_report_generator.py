"""
Infra Report Generator for BDP Dashboard.

포털의 인프라 현황(dashboard) 페이지와 동일한 구조의
HTML 리포트를 생성합니다. 토폴로지 + 카테고리별 (리소스 카드 + 차트) 구조.

섹션 구성:
- Summary 카드: 전체/실행중/주의/중지/오류 (5열)
- 에러 배너 (있으면)
- 토폴로지 다이어그램: 4-tier 서비스 구조 (SVG)
- 카테고리별 반복:
  - MWAA: 리소스 카드 → 노드 수 / 환경 업데이트 / DAG Import Errors
  - S3: 리소스 카드 → 버킷 용량
  - RDS: 리소스 카드 → CPU / Connections / Memory / IOPS / Storage
  - SageMaker Studio: 사용자 수 / Instance Types / Pipeline 실행 이력
  - SageMaker Endpoint: Latency / Availability / Invocations
  - MSK: Broker Health Summary + CPU / Memory / Disk / Network
  - Glue: Table Versions
  - Athena: Top Queries + Query History
  - Universe: 입수/전송 파이프라인 상태
"""

import logging
from dataclasses import dataclass, field
from html import escape as html_escape
from typing import Any

from src.agent_server.bdp_common.reports.base import HTMLReportBase
from src.agent_server.bdp_common.reports.charts import (  # noqa: F401
    CHART_COLORS,
    _html_data_table,
    _no_data_placeholder,
    _svg_line_chart,
    _svg_stacked_bar_chart,
)
from src.agent_server.bdp_common.reports.email_charts import (
    _html_bar_chart,
    _html_line_chart,
    _html_stacked_bar_chart,
    _render_stat_card_body,
)
from src.agent_server.bdp_common.reports.styles import MD3_COLORS, ReportStyles

logger = logging.getLogger(__name__)

STATUS_COLORS = {
    "ok": "#16a34a",
    "warning": "#d97706",
    "critical": "#dc2626",
    "neutral": "#6b7280",
}

STATUS_LABELS = {
    "ok": "정상",
    "warning": "주의",
    "critical": "장애",
    "neutral": "확인 필요",
}

# ── 토폴로지 구조 (frontend topology-map.tsx 미러링) ──────

_TOPO_TIERS = [
    ("Orchestration", ["mwaa"]),
    (
        "Compute",
        ["sagemaker studio", "sagemaker endpoint", "emr(cluster)", "emr(serverless)", "eks"],
    ),
    ("Analytics", ["glue", "athena"]),
    ("Storage", ["msk", "lambda", "s3", "rds"]),
]

_TOPO_CONNECTIONS = [
    ("mwaa", "emr(cluster)"),
    ("mwaa", "emr(serverless)"),
    ("mwaa", "sagemaker endpoint"),
    ("mwaa", "lambda"),
    ("mwaa", "glue"),
    ("lambda", "s3"),
    ("lambda", "sagemaker endpoint"),
    ("emr(cluster)", "rds"),
    ("emr(cluster)", "s3"),
    ("emr(serverless)", "s3"),
    ("sagemaker endpoint", "s3"),
    ("sagemaker studio", "s3"),
    ("eks", "rds"),
    ("eks", "s3"),
    ("emr(cluster)", "msk"),
    ("emr(serverless)", "msk"),
    ("glue", "s3"),
    ("glue", "athena"),
    ("athena", "s3"),
    ("rds", "msk"),
]

_TOPO_SVC_LABELS: dict[str, str] = {
    "mwaa": "MWAA",
    "sagemaker studio": "SageMaker Studio",
    "sagemaker endpoint": "SageMaker Endpoint",
    "emr(cluster)": "EMR Cluster",
    "emr(serverless)": "EMR Serverless",
    "eks": "EKS",
    "glue": "Glue",
    "athena": "Athena",
    "msk": "MSK",
    "lambda": "Lambda",
    "s3": "S3",
    "rds": "RDS",
}

_TOPO_TIER_LABELS: dict[str, str] = {
    "Orchestration": "오케스트레이션",
    "Compute": "컴퓨팅",
    "Analytics": "분석",
    "Storage": "스토리지",
}

_TOPO_SVC_SUBLABELS: dict[str, str] = {
    "mwaa": "Apache Airflow",
    "sagemaker studio": "ML IDE",
    "sagemaker endpoint": "ML Inference",
    "emr(cluster)": "Spark / Hadoop",
    "emr(serverless)": "Serverless Spark",
    "eks": "Kubernetes",
    "glue": "Data Catalog",
    "athena": "SQL Query",
    "msk": "Kafka",
    "lambda": "Serverless",
    "s3": "Object Storage",
    "rds": "Relational DB",
}

# ── 카테고리별 리소스 카드 렌더링 순서 ─────────────────
# 프론트엔드 FILTER_CHIPS 순서와 동일
_SERVICE_CATEGORIES: list[tuple[str, str]] = [
    ("mwaa", "MWAA"),
    ("sagemaker studio", "SageMaker Studio"),
    ("sagemaker endpoint", "SageMaker Endpoint"),
    ("athena", "Athena"),
    ("msk", "MSK"),
    ("lambda", "Lambda"),
    ("s3", "S3"),
    ("rds", "RDS"),
    ("glue", "Glue"),
]

# ── Data Class ────────────────────────────────────────


@dataclass
class InfraReportData:
    """인프라 현황 리포트 데이터."""

    # Summary (5개 지표)
    total: int = 0
    running: int = 0
    warning: int = 0
    stopped: int = 0
    error: int = 0

    # 서비스별 리소스 (service_key → [resource dicts])
    services: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    # 수집 시 에러 목록
    errors: list[str] = field(default_factory=list)

    # RDS/S3 메트릭 (각각 {"instances": {name: [{date, value/...}]}} 형태)
    rds_cpu: dict[str, Any] = field(default_factory=dict)
    rds_connections: dict[str, Any] = field(default_factory=dict)
    rds_memory: dict[str, Any] = field(default_factory=dict)
    rds_iops: dict[str, Any] = field(default_factory=dict)
    rds_storage_free: dict[str, Any] = field(default_factory=dict)
    s3_size: dict[str, Any] = field(default_factory=dict)

    # MWAA 노드 수 ({"environments": {env: [{date, scheduler_max, worker_max}]}})
    mwaa_node_counts: dict[str, Any] = field(default_factory=dict)

    # MWAA 환경 업데이트 이력 ({"environments": {env: [{date, updates}]}})
    mwaa_env_updates: dict[str, Any] = field(default_factory=dict)

    # Lambda 에러 현황 ({"functions": {func: [{date, errors}]}})
    lambda_errors: dict[str, Any] = field(default_factory=dict)

    # MWAA DAG Import Errors ({"environments": {env: [{date, import_errors}]}})
    mwaa_dag_import_errors: dict[str, Any] = field(default_factory=dict)

    # MWAA 상세 메트릭 (포탈 패리티)
    mwaa_environment_overview: dict[str, Any] = field(default_factory=dict)
    mwaa_scheduler_resources: dict[str, Any] = field(default_factory=dict)
    mwaa_dagprocessor_parsing: dict[str, Any] = field(default_factory=dict)
    mwaa_worker_resources: dict[str, Any] = field(default_factory=dict)
    mwaa_worker_task_execution: dict[str, Any] = field(default_factory=dict)
    mwaa_triggerer_resources: dict[str, Any] = field(default_factory=dict)
    mwaa_webserver_resources: dict[str, Any] = field(default_factory=dict)
    mwaa_database_resources: dict[str, Any] = field(default_factory=dict)
    mwaa_database_health: dict[str, Any] = field(default_factory=dict)
    mwaa_storage_dag_bucket: dict[str, Any] = field(default_factory=dict)

    # SageMaker Studio ({"studios": [{date, users}]})
    sagemaker_users: dict[str, Any] = field(default_factory=dict)
    # ({"instance_types": {type: [{date, count}]}})
    sagemaker_notebook_instance_types: dict[str, Any] = field(default_factory=dict)
    sagemaker_pipeline_instance_types: dict[str, Any] = field(default_factory=dict)

    # SageMaker Endpoint
    sagemaker_endpoint_latency: dict[str, Any] = field(default_factory=dict)
    sagemaker_endpoint_availability: dict[str, Any] = field(default_factory=dict)
    sagemaker_endpoint_invocations: dict[str, Any] = field(default_factory=dict)

    # MSK ({"brokers": {broker: [{date, cpu_percent, ...}]}})
    msk_broker_health: dict[str, Any] = field(default_factory=dict)

    # Glue ({"tables": {table: [{date, version_changes}]}, "quota_limit": int})
    glue_table_versions: dict[str, Any] = field(default_factory=dict)

    # Athena ({"queries": [{query_label, daily: [{date, scan_gb}], total_scan_gb}]})
    athena_top_queries: dict[str, Any] = field(default_factory=dict)

    # Athena Query History ({"items": [{query_execution_id, query_short, status, ...}]})
    athena_query_history: dict[str, Any] = field(default_factory=dict)

    # SageMaker Pipeline Executions ({"items": [{pipeline_name, status, ...}]})
    sagemaker_pipeline_executions: dict[str, Any] = field(default_factory=dict)

    # Universe Pipeline ({"pipeline_status": {...}, "transfer_status": {...}, ...})
    universe_pipeline: dict[str, Any] = field(default_factory=dict)

    # 운영계에서 mock 차트 생략
    skip_mock: bool = False


# ── Generator ─────────────────────────────────────────


class InfraReportGenerator(HTMLReportBase):
    """인프라 현황 리포트 생성기.

    포털의 인프라 현황(dashboard.tsx) 페이지와 동일한
    토폴로지 + 차트 구조로 HTML 리포트를 생성합니다.
    """

    def __init__(
        self, include_tables: bool = False, use_html_charts: bool = False,
        email_mode: bool = False,
    ):
        styles = ReportStyles(primary_color=MD3_COLORS["primary"])
        super().__init__(title="BDP 인프라 현황 리포트", styles=styles, email_mode=email_mode)
        self._include_tables = include_tables
        # HTML 차트: PDF/메일 등 WeasyPrint 렌더링 시 SVG 대신 경량 HTML 차트 사용
        if use_html_charts:
            self._line_chart = _html_line_chart
            self._bar_chart = _html_bar_chart
            self._stacked_bar_chart = _html_stacked_bar_chart
        else:
            self._line_chart = _svg_line_chart
            self._bar_chart = _html_bar_chart  # SVG bar_chart 없으므로 HTML 사용
            self._stacked_bar_chart = _svg_stacked_bar_chart

    def _extract_latest_stat_card_body(
        self,
        series: dict[str, list[tuple[str, float]]],
        y_suffix: str = "",
        colors: list[str] | None = None,
    ) -> str:
        """시리즈의 마지막 날짜 값을 stat card body로 렌더링 (wrapper 없이)."""
        items: list[tuple[str, str, str]] = []
        c = colors or CHART_COLORS
        for si, (sname, pts) in enumerate(series.items()):
            color = c[si % len(c)]
            if pts:
                val = pts[-1][1]
                val_str = f"{int(val)}{y_suffix}" if val == int(val) else f"{val:.1f}{y_suffix}"
            else:
                val_str = "-"
            items.append((sname, val_str, color))
        return _render_stat_card_body(items)

    def _append_chart(
        self,
        parts: list[str],
        chart_html: str,
        series: dict[str, list[tuple[str, float]]] | None = None,
        stat_title: str = "",
        stat_y_suffix: str = "",
        stat_colors: list[str] | None = None,
    ) -> None:
        """include_tables 비활성 시에만 차트 추가. email_mode 시 stat card를 차트 wrapper 내부에 통합."""
        if self._include_tables:
            return
        if self._email_mode and series:
            all_dates: set[str] = set()
            for pts in series.values():
                for d, _ in pts:
                    all_dates.add(d)
            if len(all_dates) > 2:
                stat_body = self._extract_latest_stat_card_body(
                    series, stat_y_suffix, stat_colors,
                )
                marker = '<div style="margin-top:8px;border-left:3px solid'
                if marker in chart_html:
                    chart_html = chart_html.replace(
                        marker,
                        f'<div style="margin-top:8px;margin-bottom:8px;">{stat_body}</div>{marker}',
                        1,
                    )
        parts.append(chart_html)

    def _append_table(
        self,
        parts: list[str],
        series: dict[str, list[tuple]],
        title: str = "",
        y_suffix: str = "",
    ) -> None:
        """include_tables 활성 시 데이터 테이블 추가."""
        if self._include_tables and series:
            parts.append(_html_data_table(series, title, y_suffix))

    def generate_content(self, data: InfraReportData) -> str:
        """리포트 콘텐츠 생성.

        레이아웃: Summary → 에러 → 토폴로지 → 카테고리별(리소스 카드 + 차트) 반복
        """
        self._skip_mock = data.skip_mock
        sections: list[str] = []
        section_hdr = (
            '<h3 style="font-size:16px;font-weight:600;margin:24px 0 12px;'
            'padding-bottom:8px;border-bottom:2px solid #e5e7eb;">{}</h3>'
        )

        # 1. Summary 카드 (5열)
        sections.append(self._build_summary_section(data))

        # 2. 에러 배너
        if data.errors:
            error_list = "".join(f"<li>{html_escape(err)}</li>" for err in data.errors)
            sections.append(
                self.render_alert(
                    f"<strong>일부 서비스 조회에 실패했습니다</strong>"
                    f"<ul style='margin:8px 0 0;padding-left:20px;'>{error_list}</ul>",
                    alert_type="warning",
                )
            )

        # 3. 토폴로지 다이어그램 (PDF에서는 .topo-wrapper로 숨김)
        topo_html = self._build_topology_svg(data)
        sections.append(f'<div class="topo-wrapper">{topo_html}</div>')

        # 4. 카테고리별: 리소스 카드 → 관련 차트
        for svc_key, svc_label in _SERVICE_CATEGORIES:
            resources = data.services.get(svc_key, [])
            charts_html = self._build_category_charts(svc_key, data)

            if not charts_html:
                continue

            sections.append(section_hdr.format(svc_label))

            if resources:
                sections.append(
                    f'<p style="font-size:12px;color:#6b7280;margin:0 0 8px;">'
                    f"{len(resources)}개 리소스</p>"
                )
                sections.append(self._build_resource_cards(svc_key, resources))

            if charts_html:
                sections.append(charts_html)

        return "\n".join(sections)

    def _with_mock_badge(self, chart_html: str, data_dict: dict) -> str:
        """차트 HTML의 첫 번째 제목 옆에 MOCK 배지 삽입 (is_mock=True인 경우)."""
        if not chart_html:
            return chart_html
        if data_dict.get("is_mock") and self._skip_mock:
            return ""  # 운영계: mock 차트 생략
        if not data_dict.get("is_mock"):
            return chart_html
        badge = self._mock_badge()
        return chart_html.replace("</h4>", f"{badge}</h4>")

    # ── Summary ───────────────────────────────────────

    def _build_summary_section(self, data: InfraReportData) -> str:
        stats = [
            {"label": "전체 리소스", "value": str(data.total), "color": "#1976D2"},
            {"label": "실행 중", "value": str(data.running), "color": "#388E3C"},
            {
                "label": "주의",
                "value": str(data.warning),
                "color": "#F57C00" if data.warning > 0 else "#388E3C",
            },
            {"label": "중지됨", "value": str(data.stopped), "color": "#1976D2"},
            {
                "label": "오류",
                "value": str(data.error),
                "color": "#D32F2F" if data.error > 0 else "#388E3C",
            },
        ]
        return self.render_stat_cards(stats, columns=5)

    # ── 카테고리별 리소스 상세 카드 ─────────────────────

    def _build_resource_cards(self, svc_key: str, resources: list[dict[str, Any]]) -> str:
        """카테고리별 리소스 카드를 HTML로 렌더링.

        프론트엔드 topology-map.tsx의 DrilldownView + ResourceTopology를 미러링.
        이메일 호환을 위해 HTML table 기반 2열 레이아웃 사용.
        """
        compact_services = {"lambda", "s3"}
        compact = svc_key in compact_services
        cards: list[str] = []
        for res in resources:
            name = str(res.get("name", "-"))
            status = str(res.get("display_status", "neutral"))
            raw_status = str(res.get("raw_status", status))
            status_color = STATUS_COLORS.get(status, "#6b7280")

            if compact:
                # 컴팩트 카드: dot + 이름(ellipsis)만
                cards.append(
                    f'<div style="border:1px solid {status_color};border-radius:6px;'
                    f'padding:6px 8px;background:#fff;">'
                    f'<div style="display:flex;align-items:center;gap:4px;">'
                    f'<span style="width:6px;height:6px;border-radius:50%;'
                    f'background:{status_color};flex-shrink:0;display:inline-block;"></span>'
                    f'<span style="font-size:11px;overflow:hidden;text-overflow:ellipsis;'
                    f'white-space:nowrap;" title="{html_escape(name)}">'
                    f'{html_escape(name)}</span>'
                    f'</div></div>'
                )
            else:
                details = _extract_resource_details(svc_key, res)

                detail_rows = "".join(
                    f'<tr><td style="padding:2px 12px 2px 0;font-size:12px;color:#6b7280;'
                    f'white-space:nowrap;">{html_escape(k)}</td>'
                    f'<td style="padding:2px 0;font-size:12px;color:#1f2937;">'
                    f"{html_escape(str(v))}</td></tr>"
                    for k, v in details
                )

                # Glue DB 상세 그리드 (DB 목록을 3열로 표시)
                glue_db_grid = ""
                if svc_key == "glue":
                    databases = res.get("databases") or []
                    if databases:
                        glue_db_grid = self._build_glue_db_grid(databases)

                cards.append(
                    f'<div style="border:2px solid {status_color};border-radius:8px;'
                    f'padding:12px;background:#fff;min-width:220px;">'
                    # 헤더 — 이름 + 상태 뱃지
                    f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">'
                    f'<span style="width:8px;height:8px;border-radius:50%;'
                    f'background:{status_color};display:inline-block;"></span>'
                    f'<span style="font-size:13px;font-weight:600;">{html_escape(name)}</span>'
                    f'<span style="margin-left:auto;font-size:11px;color:{status_color};'
                    f'border:1px solid {status_color};border-radius:4px;padding:1px 6px;">'
                    f"{html_escape(raw_status)}</span>"
                    f"</div>"
                    # 상세 테이블
                    f'<table style="border-collapse:collapse;">{detail_rows}</table>'
                    f"{glue_db_grid}"
                    f"</div>"
                )

        # 서비스별 열 수
        if svc_key == "lambda":
            cols = 3
        elif svc_key == "s3":
            cols = 4
        else:
            cols = 2
        spacing = "3px" if compact else "6px"
        rows_html: list[str] = []
        for i in range(0, len(cards), cols):
            row_cells = "".join(
                f'<td style="width:{100 // cols}%;vertical-align:top;padding:6px;">{c}</td>'
                for c in cards[i:i + cols]
            )
            missing = cols - len(cards[i:i + cols])
            if missing:
                row_cells += f'<td style="width:{100 // cols}%;"></td>' * missing
            rows_html.append(f"<tr>{row_cells}</tr>")
        return (
            f'<table style="width:100%;border-collapse:separate;border-spacing:{spacing};">'
            f'{"".join(rows_html)}</table>'
        )

    def _build_glue_db_grid(self, databases: list) -> str:
        """Glue DB 목록을 3열 테이블로 렌더링 (이메일 호환)."""
        cols = 3
        cells: list[str] = []
        for db in databases:
            db_name = db.get("name", "-") if isinstance(db, dict) else str(db)
            tbl_cnt = db.get("table_count", 0) if isinstance(db, dict) else 0
            cells.append(
                f'<td style="padding:3px 6px;font-size:11px;border-bottom:1px solid #f3f4f6;">'
                f'{html_escape(str(db_name))} <span style="color:#9ca3af;">({tbl_cnt})</span></td>'
            )
        while len(cells) % cols:
            cells.append('<td style="padding:3px 6px;"></td>')
        rows: list[str] = []
        for i in range(0, len(cells), cols):
            rows.append(f'<tr>{"".join(cells[i:i + cols])}</tr>')
        return (
            f'<table style="width:100%;border-collapse:collapse;margin-top:6px;">'
            f'{"".join(rows)}</table>'
        )

    # ── Topology SVG ─────────────────────────────────

    def _build_topology_svg(self, data: InfraReportData) -> str:
        """4-tier 토폴로지 다이어그램을 인라인 SVG로 생성.

        프론트엔드 topology-map.tsx의 ServiceNode 구조를 미러링:
        - 한국어 tier 레이블 + 배경 밴드
        - 노드: 서비스명 + sublabel + 구분선 + 리소스 수 + 요약
        - 상태 점(status dot)
        - 연결선 화살표 marker
        """
        node_w, node_h = 140, 80
        tier_gap = 110
        node_gap = 20
        pad_x, pad_top, pad_bottom = 60, 60, 20

        # 각 tier의 노드 수로 전체 폭 계산
        max_nodes = max(len(svcs) for _, svcs in _TOPO_TIERS)
        svg_w = max(900, pad_x * 2 + max_nodes * node_w + (max_nodes - 1) * node_gap)
        svg_h = pad_top + len(_TOPO_TIERS) * (node_h + tier_gap) - tier_gap + pad_bottom

        # 노드 위치 계산 {svc_key: (cx, cy)}
        positions: dict[str, tuple] = {}
        for tier_idx, (tier_label, svcs) in enumerate(_TOPO_TIERS):
            tier_y = pad_top + tier_idx * (node_h + tier_gap) + node_h // 2
            tier_total_w = len(svcs) * node_w + (len(svcs) - 1) * node_gap
            start_x = (svg_w - tier_total_w) / 2 + node_w / 2
            for si, svc_key in enumerate(svcs):
                cx = start_x + si * (node_w + node_gap)
                positions[svc_key] = (cx, tier_y)

        tier_colors = {
            "Orchestration": "#7c3aed",
            "Compute": "#2563eb",
            "Analytics": "#d97706",
            "Storage": "#16a34a",
        }
        tier_bg_colors = {
            "Orchestration": "#f5f3ff",
            "Compute": "#eff6ff",
            "Analytics": "#fffbeb",
            "Storage": "#f0fdf4",
        }

        parts: list[str] = []
        parts.append(
            f'<svg viewBox="0 0 {svg_w} {svg_h}" '
            f'xmlns="http://www.w3.org/2000/svg" '
            f"style=\"width:100%;max-width:{svg_w}px;height:auto;font-family:'Noto Sans CJK KR', 'Noto Sans KR', sans-serif;\">"
        )
        parts.append(f'<rect width="{svg_w}" height="{svg_h}" fill="white"/>')

        # 화살표 marker 정의
        parts.append(
            "<defs>"
            '<marker id="arrowhead" markerWidth="8" markerHeight="6" '
            'refX="8" refY="3" orient="auto">'
            '<polygon points="0 0, 8 3, 0 6" fill="#d1d5db"/>'
            "</marker>"
            "</defs>"
        )

        # Tier 배경 밴드
        band_pad = 8
        for tier_idx, (tier_label, svcs) in enumerate(_TOPO_TIERS):
            tier_y = pad_top + tier_idx * (node_h + tier_gap) + node_h // 2
            band_y = tier_y - node_h // 2 - band_pad
            band_h = node_h + band_pad * 2
            bg = tier_bg_colors.get(tier_label, "#f9fafb")
            parts.append(
                f'<rect x="0" y="{band_y:.0f}" width="{svg_w}" height="{band_h}" '
                f'fill="{bg}" rx="0"/>'
            )

        # 연결선 (화살표 포함)
        for src, dst in _TOPO_CONNECTIONS:
            if src in positions and dst in positions:
                x1, y1 = positions[src]
                x2, y2 = positions[dst]
                parts.append(
                    f'<line x1="{x1:.0f}" y1="{y1 + node_h // 2:.0f}" '
                    f'x2="{x2:.0f}" y2="{y2 - node_h // 2:.0f}" '
                    f'stroke="#d1d5db" stroke-width="1.2" stroke-dasharray="4 3" '
                    f'marker-end="url(#arrowhead)"/>'
                )

        # Tier 레이블 + 노드
        for tier_idx, (tier_label, svcs) in enumerate(_TOPO_TIERS):
            tier_y = pad_top + tier_idx * (node_h + tier_gap) + node_h // 2
            tier_color = tier_colors.get(tier_label, "#6b7280")
            kr_label = _TOPO_TIER_LABELS.get(tier_label, tier_label)

            # Tier 한국어 레이블 (밴드 왼쪽 상단, 수평 — cairosvg rotate 호환)
            band_label_y = tier_y - node_h // 2 - band_pad + 14
            parts.append(
                f'<text x="8" y="{band_label_y:.0f}" font-size="10" '
                f'font-weight="600" fill="{tier_color}">'
                f"{html_escape(kr_label)}</text>"
            )

            for svc_key in svcs:
                if svc_key not in positions:
                    continue
                cx, cy = positions[svc_key]
                rx = cx - node_w / 2
                ry = cy - node_h / 2

                resources = data.services.get(svc_key, [])
                count = len(resources)
                overall = _overall_status(resources) if resources else "neutral"
                status_color = STATUS_COLORS.get(overall, "#6b7280")
                label = _TOPO_SVC_LABELS.get(svc_key, svc_key)
                sublabel = _TOPO_SVC_SUBLABELS.get(svc_key, "")
                summary = _get_summary(svc_key, resources)

                # 노드 배경
                parts.append(
                    f'<rect x="{rx:.0f}" y="{ry:.0f}" width="{node_w}" height="{node_h}" '
                    f'rx="8" ry="8" fill="white" stroke="{status_color}" stroke-width="1.5"/>'
                )

                # 상태 점 (status dot) - 우상단
                dot_x = rx + node_w - 10
                dot_y = ry + 10
                parts.append(
                    f'<circle cx="{dot_x:.0f}" cy="{dot_y:.0f}" r="4" fill="{status_color}"/>'
                )

                # 서비스명
                parts.append(
                    f'<text x="{cx:.0f}" y="{cy - 22:.0f}" text-anchor="middle" '
                    f'font-size="11" font-weight="600" fill="#1f2937">'
                    f"{html_escape(label)}</text>"
                )

                # sublabel
                if sublabel:
                    parts.append(
                        f'<text x="{cx:.0f}" y="{cy - 10:.0f}" text-anchor="middle" '
                        f'font-size="8" fill="#9ca3af">'
                        f"{html_escape(sublabel)}</text>"
                    )

                # 구분선
                line_y = cy - 4
                parts.append(
                    f'<line x1="{rx + 8:.0f}" y1="{line_y:.0f}" '
                    f'x2="{rx + node_w - 8:.0f}" y2="{line_y:.0f}" '
                    f'stroke="#e5e7eb" stroke-width="0.5"/>'
                )

                # 리소스 수
                parts.append(
                    f'<text x="{cx:.0f}" y="{cy + 10:.0f}" text-anchor="middle" '
                    f'font-size="9" fill="{status_color}">'
                    f"{count}개 리소스</text>"
                )

                # 요약 텍스트
                if summary:
                    # 긴 텍스트 잘라내기
                    display_summary = summary if len(summary) <= 20 else summary[:18] + "…"
                    parts.append(
                        f'<text x="{cx:.0f}" y="{cy + 22:.0f}" text-anchor="middle" '
                        f'font-size="8" fill="#6b7280">'
                        f"{html_escape(display_summary)}</text>"
                    )

        parts.append("</svg>")

        return (
            '<div class="topo-wrapper" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;'
            'padding:16px;margin-bottom:16px;">'
            '<h4 style="font-size:14px;font-weight:600;margin:0 0 8px;">인프라 토폴로지</h4>'
            '<p style="font-size:12px;color:#6b7280;margin:0 0 12px;">'
            "4-Tier 서비스 구조 (오케스트레이션 → 컴퓨팅 → 분석 → 스토리지)</p>"
            f"{''.join(parts)}"
            "</div>"
        )

    # ── RDS 메트릭 차트 ──────────────────────────────

    def _build_rds_cpu_charts(self, data: InfraReportData) -> str:
        instances = data.rds_cpu.get("instances", {})
        if not instances:
            return _no_data_placeholder("RDS CPU 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for inst_name, pts in instances.items():
            series[inst_name] = [(p["date"], max(0, p["value"])) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="CPU 사용률 (월누적 일별)",
                subtitle="인스턴스별 일일 CPU 사용률 (%)",
                y_suffix="%",
                y_domain=(0, 100),
            ),
            series=series, stat_title="RDS CPU 사용률", stat_y_suffix="%",
        )
        self._append_table(parts, series, "CPU 사용률", "%")
        return "\n".join(parts)

    def _build_rds_connections_charts(self, data: InfraReportData) -> str:
        instances = data.rds_connections.get("instances", {})
        if not instances:
            return _no_data_placeholder("RDS 커넥션 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for inst_name, pts in instances.items():
            series[inst_name] = [(p["date"], max(0, p["value"])) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="DB 커넥션 수 (월누적 일별)",
                subtitle="인스턴스별 일일 DB 커넥션 수 (건)",
                y_suffix="건",
                y_integer=True,
            ),
            series=series, stat_title="DB 커넥션 수", stat_y_suffix="건",
        )
        self._append_table(parts, series, "DB 커넥션 수", "건")
        return "\n".join(parts)

    def _build_rds_memory_charts(self, data: InfraReportData) -> str:
        instances = data.rds_memory.get("instances", {})
        if not instances:
            return _no_data_placeholder("RDS 메모리 데이터가 없습니다.")
        parts: list[str] = []
        for inst_name, pts in instances.items():
            left_series: dict[str, list[tuple]] = {
                "Freeable": [(p["date"], max(0, p["freeable_gb"])) for p in pts],
            }
            right_series: dict[str, list[tuple]] = {
                "Swap": [(p["date"], max(0, p["swap_mb"])) for p in pts],
            }
            self._append_chart(
                parts,
                self._line_chart(
                    left_series,
                    ["#2563eb"],
                    title=inst_name,
                    subtitle="Freeable Memory (GB) / Swap Usage (MB)",
                    y_suffix="GB",
                    height=200,
                    right_series=right_series,
                    right_y_suffix="MB",
                    right_colors=["#d97706"],
                ),
                series=left_series, stat_title=f"{inst_name} Memory", stat_y_suffix="GB",
            )
            self._append_table(parts, {**left_series, **right_series}, f"{inst_name} Memory", "")
        return "\n".join(parts)

    def _build_rds_iops_charts(self, data: InfraReportData) -> str:
        instances = data.rds_iops.get("instances", {})
        if not instances:
            return _no_data_placeholder("RDS IOPS 데이터가 없습니다.")
        parts: list[str] = []
        for inst_name, pts in instances.items():
            inst_series: dict[str, list[tuple]] = {
                "Read": [(p["date"], max(0, p["read_iops"])) for p in pts],
                "Write": [(p["date"], max(0, p["write_iops"])) for p in pts],
            }
            self._append_chart(
                parts,
                self._line_chart(
                    inst_series,
                    ["#2563eb", "#dc2626"],
                    title=f"IOPS - {inst_name}",
                    subtitle="Read / Write IOPS 추이",
                    y_suffix="IOPS",
                    height=200,
                ),
                series=inst_series, stat_title=f"IOPS - {inst_name}", stat_y_suffix="IOPS",
                stat_colors=["#2563eb", "#dc2626"],
            )
            self._append_table(parts, inst_series, f"IOPS - {inst_name}", "IOPS")
        return "\n".join(parts)

    def _build_rds_storage_charts(self, data: InfraReportData) -> str:
        instances = data.rds_storage_free.get("instances", {})
        if not instances:
            return _no_data_placeholder("RDS 스토리지 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for inst_name, pts in instances.items():
            series[inst_name] = [(p["date"], max(0, p["value"])) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="여유 스토리지 (월누적 일별)",
                subtitle="인스턴스별 여유 스토리지 (GB)",
                y_suffix="GB",
            ),
            series=series, stat_title="여유 스토리지", stat_y_suffix="GB",
        )
        self._append_table(parts, series, "여유 스토리지", "GB")
        return "\n".join(parts)

    def _build_s3_size_charts(self, data: InfraReportData) -> str:
        buckets = data.s3_size.get("buckets", {})
        if not buckets:
            return _no_data_placeholder("S3 버킷 용량 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for bucket_name, pts in buckets.items():
            series[bucket_name] = [(p["date"], p["size_gb"]) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="버킷 용량 추이 (월누적 일별)",
                subtitle="버킷별 저장 용량 (GB)",
                y_suffix="GB",
            ),
            series=series, stat_title="S3 버킷 용량", stat_y_suffix="GB",
        )
        self._append_table(parts, series, "버킷 용량", "GB")
        return "\n".join(parts)

    # ── MWAA 메트릭 차트 ─────────────────────────────

    def _build_mwaa_node_charts(self, data: InfraReportData) -> str:
        """MWAA 노드 수 차트 — 환경 통합, Scheduler/Worker 구분 (C-1 포탈 동일)."""
        environments = data.mwaa_node_counts.get("environments", {})
        if not environments:
            return _no_data_placeholder("MWAA 노드 수 데이터가 없습니다.")
        # 환경 통합: {env}_Scheduler, {env}_Worker 시리즈
        series: dict[str, list[tuple]] = {}
        for env_name, pts in environments.items():
            series[f"{env_name} Scheduler"] = [(p["date"], p.get("scheduler_max", 0)) for p in pts]
            series[f"{env_name} Worker"] = [(p["date"], p.get("worker_max", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="노드 수 (일 최대)",
                subtitle="환경별 Scheduler / Worker 노드 수 추이",
                y_suffix="개",
                y_integer=True,
            ),
            series=series, stat_title="MWAA 노드 수", stat_y_suffix="개",
        )
        self._append_table(parts, series, "MWAA 노드 수", "개")
        return "\n".join(parts)

    # ── MWAA 환경 업데이트 이력 ────────────────────────

    def _build_mwaa_env_updates_charts(self, data: InfraReportData) -> str:
        """MWAA Env Updates — 환경 통합 Bar Chart 1개 (C-1 포탈 동일)."""
        environments = data.mwaa_env_updates.get("environments", {})
        if not environments:
            return _no_data_placeholder("MWAA 환경 업데이트 데이터가 없습니다.")
        # 환경 통합: 각 환경을 하나의 시리즈로
        series: dict[str, list[tuple]] = {}
        for env_name, pts in environments.items():
            series[env_name] = [(p["date"], p.get("updates", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._stacked_bar_chart(
                series,
                CHART_COLORS,
                title="Env 업데이트",
                subtitle="환경별 업데이트(재시작) 발생 일별 건수",
                y_suffix="건",
                y_integer=True,
            ),
            series=series, stat_title="MWAA 환경 업데이트", stat_y_suffix="건",
        )
        self._append_table(parts, series, "MWAA 환경 업데이트", "건")
        return "\n".join(parts)

    # ── Lambda 에러 ──────────────────────────────────

    def _build_lambda_errors_charts(self, data: InfraReportData) -> str:
        """Lambda 함수별 일일 에러 건수 차트."""
        functions = data.lambda_errors.get("functions", {})
        if not functions:
            return _no_data_placeholder("Lambda 에러 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for func_name, pts in functions.items():
            series[func_name] = [(p["date"], p.get("errors", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Lambda 실패 건수 (월누적 일별)",
                subtitle="함수별 일일 에러 건수",
                y_suffix="건",
                y_integer=True,
            ),
            series=series, stat_title="Lambda 에러", stat_y_suffix="건",
        )
        self._append_table(parts, series, "Lambda 에러", "건")
        return "\n".join(parts)

    # ── 카테고리별 차트 디스패치 ────────────────────────

    def _build_category_charts(self, svc_key: str, data: InfraReportData) -> str:
        """카테고리에 해당하는 차트 HTML을 반환. 데이터 없으면 빈 문자열.

        프론트엔드 dashboard.tsx와 동일한 차트만 포함합니다.
        서비스별 상세 차트(DAG 성공률, MSK LAG, SageMaker, EMR 등)는
        서비스 현황 리포트(daily_report_generator.py)에서 관리합니다.
        """
        _mb = self._with_mock_badge
        if svc_key == "mwaa":
            parts = [
                self._build_mwaa_environment_overview_section(data),
                _mb(self._build_mwaa_scheduler_resources_charts(data), data.mwaa_scheduler_resources),
                _mb(self._build_mwaa_dagprocessor_parsing_charts(data), data.mwaa_dagprocessor_parsing),
                _mb(self._build_mwaa_dag_import_errors_charts(data), data.mwaa_dag_import_errors),
                # Worker Pool: 2열 테이블 레이아웃
                '<table style="width:100%;border-collapse:separate;border-spacing:8px 0;"><tr>'
                '<td style="width:50%;vertical-align:top;">'
                + (_mb(self._build_mwaa_worker_resources_charts(data), data.mwaa_worker_resources) or "")
                + '</td><td style="width:50%;vertical-align:top;">'
                + (_mb(self._build_mwaa_worker_task_execution_charts(data), data.mwaa_worker_task_execution) or "")
                + '</td></tr></table>',
                _mb(self._build_mwaa_node_charts(data), data.mwaa_node_counts),
                _mb(self._build_mwaa_triggerer_resources_charts(data), data.mwaa_triggerer_resources),
                _mb(self._build_mwaa_webserver_resources_charts(data), data.mwaa_webserver_resources),
                # Database: 2열 테이블 레이아웃
                '<table style="width:100%;border-collapse:separate;border-spacing:8px 0;"><tr>'
                '<td style="width:50%;vertical-align:top;">'
                + (_mb(self._build_mwaa_database_resources_charts(data), data.mwaa_database_resources) or "")
                + '</td><td style="width:50%;vertical-align:top;">'
                + (_mb(self._build_mwaa_database_health_charts(data), data.mwaa_database_health) or "")
                + '</td></tr></table>',
                _mb(self._build_mwaa_storage_dag_bucket_charts(data), data.mwaa_storage_dag_bucket),
                _mb(self._build_mwaa_env_updates_charts(data), data.mwaa_env_updates),
            ]
        elif svc_key == "s3":
            parts = [_mb(self._build_s3_size_charts(data), data.s3_size)]
        elif svc_key == "rds":
            parts = [
                _mb(self._build_rds_cpu_charts(data), data.rds_cpu),
                _mb(self._build_rds_connections_charts(data), data.rds_connections),
                _mb(self._build_rds_memory_charts(data), data.rds_memory),
                _mb(self._build_rds_iops_charts(data), data.rds_iops),
                _mb(self._build_rds_storage_charts(data), data.rds_storage_free),
            ]
        elif svc_key == "lambda":
            parts = [_mb(self._build_lambda_errors_charts(data), data.lambda_errors)]
        elif svc_key == "sagemaker studio":
            parts = [
                self._build_sagemaker_pipeline_table(data),
                _mb(self._build_sagemaker_users_charts(data), data.sagemaker_users),
                _mb(self._build_sagemaker_notebook_instance_types_charts(data), data.sagemaker_notebook_instance_types),
                _mb(self._build_sagemaker_pipeline_instance_types_charts(data), data.sagemaker_pipeline_instance_types),
            ]
        elif svc_key == "sagemaker endpoint":
            parts = [
                _mb(self._build_sagemaker_endpoint_latency_charts(data), data.sagemaker_endpoint_latency),
                _mb(self._build_sagemaker_endpoint_availability_charts(data), data.sagemaker_endpoint_availability),
                _mb(self._build_sagemaker_endpoint_invocations_charts(data), data.sagemaker_endpoint_invocations),
            ]
        elif svc_key == "msk":
            parts = [
                _mb(self._build_msk_broker_health_summary_chart(data), data.msk_broker_health),
                _mb(self._build_msk_broker_health_charts(data), data.msk_broker_health),
            ]
        elif svc_key == "glue":
            parts = [_mb(self._build_glue_table_versions_charts(data), data.glue_table_versions)]
        elif svc_key == "athena":
            parts = [
                _mb(self._build_athena_top_queries_charts(data), data.athena_top_queries),
                self._build_athena_query_history_table(data),
            ]
        elif svc_key == "universe":
            parts = [_mb(self._build_universe_pipeline_section(data), data.universe_pipeline)]
        else:
            return ""
        return "\n".join(p for p in parts if p)

    # ── 추가 차트 빌더 (누락 메트릭) ──────────────────────

    def _build_mwaa_dag_import_errors_charts(self, data: InfraReportData) -> str:
        environments = data.mwaa_dag_import_errors.get("environments", {})
        if not environments:
            return _no_data_placeholder("DAG Import Errors 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for env_name, pts in environments.items():
            series[env_name] = [(p["date"], p.get("import_errors", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="DAG Import Errors",
                subtitle="환경별 일별 Import Error 건수",
                y_suffix="건", y_integer=True,
            ),
            series=series, stat_title="DAG Import Errors", stat_y_suffix="건",
        )
        self._append_table(parts, series, "DAG Import Errors", "건")
        return "\n".join(parts)

    # ── MWAA 상세 메트릭 차트 (포탈 패리티) ─────────────

    def _build_mwaa_environment_overview_section(self, data: InfraReportData) -> str:
        """MWAA 환경 개요 (버전, 클래스, 상태) — 테이블 형태."""
        environments = data.mwaa_environment_overview.get("environments", {})
        if not environments:
            return ""
        rows = []
        for env_name, info in environments.items():
            rows.append(
                f'<tr><td style="padding:4px 8px;">{html_escape(env_name)}</td>'
                f'<td style="padding:4px 8px;">{html_escape(str(info.get("airflow_version", "")))}</td>'
                f'<td style="padding:4px 8px;">{html_escape(str(info.get("environment_class", "")))}</td>'
                f'<td style="padding:4px 8px;">{html_escape(str(info.get("status", "")))}</td>'
                f'<td style="padding:4px 8px;">{html_escape(str(info.get("last_update", "")))}</td></tr>'
            )
        return (
            '<div style="margin:12px 0;">'
            '<h4 style="font-size:14px;font-weight:600;margin-bottom:8px;">환경 Overview</h4>'
            '<table style="width:100%;border-collapse:collapse;font-size:13px;">'
            '<thead><tr style="background:#f3f4f6;">'
            '<th style="padding:6px 8px;text-align:left;">환경</th>'
            '<th style="padding:6px 8px;text-align:left;">Airflow 버전</th>'
            '<th style="padding:6px 8px;text-align:left;">환경 클래스</th>'
            '<th style="padding:6px 8px;text-align:left;">상태</th>'
            '<th style="padding:6px 8px;text-align:left;">최종 업데이트</th>'
            '</tr></thead><tbody>'
            + "\n".join(rows)
            + '</tbody></table></div>'
        )

    def _build_mwaa_scheduler_resources_charts(self, data: InfraReportData) -> str:
        """MWAA Scheduler CPU%, Heartbeat 차트."""
        environments = data.mwaa_scheduler_resources.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[f"{env_name} CPU"] = [(p["date"], p.get("cpu_pct", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="Scheduler CPU 사용률",
                subtitle="환경별 Scheduler CPU 사용률",
                y_suffix="%",
            ),
            series=series, stat_title="MWAA Scheduler CPU", stat_y_suffix="%",
        )
        return "\n".join(parts)

    def _build_mwaa_dagprocessor_parsing_charts(self, data: InfraReportData) -> str:
        """MWAA DAG Processor 파싱 시간 / DAG 수 차트."""
        environments = data.mwaa_dagprocessor_parsing.get("environments", {})
        if not environments:
            return ""
        left_series: dict[str, list[tuple]] = {}
        right_series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            left_series[f"{env_name} 파싱시간"] = [(p["date"], p.get("parse_time_sec", 0)) for p in daily]
            right_series[f"{env_name} DAG수"] = [(p["date"], p.get("total_dags", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                left_series, CHART_COLORS[:len(left_series)],
                title="DAG Processor 파싱",
                subtitle="환경별 파싱시간(초, 좌축) / DAG 수(개, 우축)",
                y_suffix="초",
                right_series=right_series,
                right_y_suffix="개",
            ),
            series=left_series, stat_title="DAG Processor 파싱", stat_y_suffix="초",
        )
        return "\n".join(parts)

    def _build_mwaa_worker_resources_charts(self, data: InfraReportData) -> str:
        """MWAA Active Workers 차트."""
        environments = data.mwaa_worker_resources.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[f"{env_name} Workers"] = [(p["date"], p.get("active_workers", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="Active Workers",
                subtitle="환경별 활성 Worker 수 (오토스케일)",
            ),
            series=series, stat_title="Active Workers", stat_y_suffix="개",
        )
        return "\n".join(parts)

    def _build_mwaa_worker_task_execution_charts(self, data: InfraReportData) -> str:
        """MWAA Worker 동시 실행/대기 태스크 차트."""
        environments = data.mwaa_worker_task_execution.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[f"{env_name} 실행"] = [(p["date"], p.get("concurrent_tasks", 0)) for p in daily]
            series[f"{env_name} 대기"] = [(p["date"], p.get("queued_tasks", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="Task 실행/대기",
                subtitle="환경별 동시 실행(실선) / 대기(점선) 태스크",
                y_suffix="개", y_integer=True,
            ),
            series=series, stat_title="Task 실행/대기", stat_y_suffix="개",
        )
        return "\n".join(parts)

    def _build_mwaa_triggerer_resources_charts(self, data: InfraReportData) -> str:
        """MWAA Triggerer CPU%, Active Triggers 차트."""
        environments = data.mwaa_triggerer_resources.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[f"{env_name} CPU"] = [(p["date"], p.get("cpu_pct", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="Triggerer CPU 사용률",
                subtitle="환경별 Triggerer CPU 사용률",
                y_suffix="%",
            ),
            series=series, stat_title="Triggerer CPU", stat_y_suffix="%",
        )
        return "\n".join(parts)

    def _build_mwaa_webserver_resources_charts(self, data: InfraReportData) -> str:
        """MWAA WebServer CPU 차트."""
        environments = data.mwaa_webserver_resources.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[f"{env_name} CPU"] = [(p["date"], p.get("cpu_pct", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="WebServer CPU 사용률",
                subtitle="환경별 WebServer CPU 사용률",
                y_suffix="%",
            ),
            series=series, stat_title="WebServer CPU", stat_y_suffix="%",
        )
        return "\n".join(parts)

    def _build_mwaa_database_resources_charts(self, data: InfraReportData) -> str:
        """MWAA Database CPU%, Connections 차트."""
        environments = data.mwaa_database_resources.get("environments", {})
        if not environments:
            return ""
        left_series: dict[str, list[tuple]] = {}
        right_series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            left_series[f"{env_name} CPU"] = [(p["date"], p.get("cpu_pct", 0)) for p in daily]
            right_series[f"{env_name} Conn"] = [(p["date"], p.get("connections", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                left_series, CHART_COLORS[:len(left_series)],
                title="Database CPU / Connections",
                subtitle="환경별 DB CPU%(좌축) / Connections(우축)",
                y_suffix="%",
                y_domain=(0, 100),
                right_series=right_series,
                right_y_suffix="건",
            ),
            series=left_series, stat_title="Database CPU / Connections", stat_y_suffix="%",
        )
        return "\n".join(parts)

    def _build_mwaa_database_health_charts(self, data: InfraReportData) -> str:
        """MWAA Database 크기 차트."""
        environments = data.mwaa_database_health.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[env_name] = [(p["date"], p.get("db_size_mb", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="Database 크기",
                subtitle="환경별 Database 크기",
                y_suffix="MB",
            ),
            series=series, stat_title="Database 크기", stat_y_suffix="MB",
        )
        return "\n".join(parts)

    def _build_mwaa_storage_dag_bucket_charts(self, data: InfraReportData) -> str:
        """MWAA S3 DAG 버킷 용량 차트."""
        environments = data.mwaa_storage_dag_bucket.get("environments", {})
        if not environments:
            return ""
        series: dict[str, list[tuple]] = {}
        for env_name, env_data in environments.items():
            daily = env_data.get("daily", [])
            series[env_name] = [(p["date"], p.get("size_mb", 0)) for p in daily]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series, CHART_COLORS,
                title="S3 DAG 버킷",
                subtitle="환경별 S3 DAG 버킷 크기",
                y_suffix="MB",
            ),
            series=series, stat_title="DAG 버킷 용량", stat_y_suffix="MB",
        )
        return "\n".join(parts)

    def _build_sagemaker_users_charts(self, data: InfraReportData) -> str:
        """SageMaker Studio 사용자 수 차트."""
        studios = data.sagemaker_users.get("studios", [])
        if not studios:
            return _no_data_placeholder("SageMaker Studio 사용자 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {
            "사용자": [(p["date"], p.get("users", 0)) for p in studios],
        }
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="일별 사용자 접속 현황 (월누적)",
                subtitle="일별 접속 사용자 수",
                y_suffix="명",
                y_integer=True,
            ),
            series=series, stat_title="SageMaker Studio 사용자", stat_y_suffix="명",
        )
        self._append_table(parts, series, "SageMaker Studio 사용자", "명")
        return "\n".join(parts)

    def _build_sagemaker_notebook_instance_types_charts(self, data: InfraReportData) -> str:
        """SageMaker Notebook Instance Types 차트."""
        instance_types = data.sagemaker_notebook_instance_types.get("instance_types", {})
        if not instance_types:
            return _no_data_placeholder("Notebook Instance Types 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for inst_type, pts in instance_types.items():
            series[inst_type] = [(p["date"], p.get("count", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Notebook 인스턴스 타입별 사용 현황 (월누적 일별)",
                subtitle="인스턴스 타입별 사용 수",
                y_suffix="개",
                y_integer=True,
            ),
            series=series, stat_title="Notebook 인스턴스 타입별 사용 현황 (월누적 일별)", stat_y_suffix="개",
        )
        self._append_table(parts, series, "Notebook Instance Types", "개")
        return "\n".join(parts)

    def _build_sagemaker_pipeline_instance_types_charts(self, data: InfraReportData) -> str:
        """SageMaker Pipeline Instance Types 차트."""
        instance_types = data.sagemaker_pipeline_instance_types.get("instance_types", {})
        if not instance_types:
            return _no_data_placeholder("Pipeline Instance Types 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for inst_type, pts in instance_types.items():
            series[inst_type] = [(p["date"], p.get("count", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Pipeline Job 인스턴스 타입별 사용 현황 (월누적 일별)",
                subtitle="인스턴스 타입별 사용 수",
                y_suffix="개",
                y_integer=True,
            ),
            series=series, stat_title="Pipeline Job 인스턴스 타입별 사용 현황 (월누적 일별)", stat_y_suffix="개",
        )
        self._append_table(parts, series, "Pipeline Instance Types", "개")
        return "\n".join(parts)

    def _build_sagemaker_endpoint_latency_charts(self, data: InfraReportData) -> str:
        """SageMaker Endpoint Latency (p50/p95/p99) — per-endpoint 차트."""
        endpoints = data.sagemaker_endpoint_latency.get("endpoints", {})
        if not endpoints:
            return _no_data_placeholder("Endpoint Latency 데이터가 없습니다.")
        parts: list[str] = []
        for ep_name, pts in endpoints.items():
            ep_series: dict[str, list[tuple]] = {
                "p50": [(p["date"], p.get("p50", 0)) for p in pts],
                "p95": [(p["date"], p.get("p95", 0)) for p in pts],
                "p99": [(p["date"], p.get("p99", 0)) for p in pts],
            }
            self._append_chart(
                parts,
                self._line_chart(
                    ep_series,
                    ["#2563eb", "#d97706", "#dc2626"],
                    title=ep_name,
                    subtitle="P50 / P95 / P99 Latency 추이 (ms)",
                    y_suffix="ms",
                    height=200,
                ),
                series=ep_series, stat_title=f"{ep_name} Latency", stat_y_suffix="ms",
                stat_colors=["#2563eb", "#d97706", "#dc2626"],
            )
            self._append_table(parts, ep_series, f"{ep_name} Latency", "ms")
        return "\n".join(parts)

    def _build_sagemaker_endpoint_availability_charts(self, data: InfraReportData) -> str:
        """SageMaker Endpoint Availability 차트."""
        endpoints = data.sagemaker_endpoint_availability.get("endpoints", {})
        if not endpoints:
            return _no_data_placeholder("Endpoint 가용률 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for ep_name, pts in endpoints.items():
            series[ep_name] = [(p["date"], p.get("availability", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Endpoint 가용률 (월누적 일별)",
                subtitle="엔드포인트별 가용성",
                y_suffix="%",
                reference_lines=[{"value": 99.9, "label": "SLA 99.9%", "color": "#dc2626"}],
            ),
            series=series, stat_title="Endpoint 가용률", stat_y_suffix="%",
        )
        self._append_table(parts, series, "Endpoint Availability", "%")
        return "\n".join(parts)

    def _build_sagemaker_endpoint_invocations_charts(self, data: InfraReportData) -> str:
        """SageMaker Endpoint Invocations 차트."""
        endpoints = data.sagemaker_endpoint_invocations.get("endpoints", {})
        if not endpoints:
            return _no_data_placeholder("Endpoint 호출 건수 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {}
        for ep_name, pts in endpoints.items():
            series[ep_name] = [(p["date"], p.get("invocations", 0)) for p in pts]
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                CHART_COLORS,
                title="Endpoint 호출 건수 (월누적 일별)",
                subtitle="엔드포인트별 호출 건수",
                y_suffix="건",
                y_integer=True,
            ),
            series=series, stat_title="Endpoint 호출 건수", stat_y_suffix="건",
        )
        self._append_table(parts, series, "Endpoint Invocations", "건")
        return "\n".join(parts)

    def _build_msk_broker_health_charts(self, data: InfraReportData) -> str:
        """MSK Broker Health (CPU/Memory/Disk/Network) 차트."""
        if data.msk_broker_health.get("is_mock"):
            return _no_data_placeholder("MSK Broker Health 데이터가 없습니다.")
        brokers = data.msk_broker_health.get("brokers", {})
        if not brokers:
            return _no_data_placeholder("MSK Broker Health 데이터가 없습니다.")
        parts: list[str] = []

        # CPU
        cpu_series: dict[str, list[tuple]] = {}
        for broker, pts in brokers.items():
            cpu_series[broker] = [(p["date"], p.get("cpu_percent", 0)) for p in pts]
        self._append_chart(
            parts,
            self._line_chart(
                cpu_series, CHART_COLORS,
                title="Broker CPU 사용률", subtitle="브로커별 CPU 사용률", y_suffix="%",
            ),
            series=cpu_series, stat_title="Broker CPU 사용률", stat_y_suffix="%",
        )
        self._append_table(parts, cpu_series, "Broker CPU 사용률", "%")

        # Memory
        mem_series: dict[str, list[tuple]] = {}
        for broker, pts in brokers.items():
            mem_series[broker] = [(p["date"], p.get("memory_percent", 0)) for p in pts]
        self._append_chart(
            parts,
            self._line_chart(
                mem_series, CHART_COLORS,
                title="Broker Memory 사용률", subtitle="브로커별 메모리 사용률", y_suffix="%",
            ),
            series=mem_series, stat_title="Broker Memory 사용률", stat_y_suffix="%",
        )
        self._append_table(parts, mem_series, "Broker Memory 사용률", "%")

        # Disk
        disk_series: dict[str, list[tuple]] = {}
        for broker, pts in brokers.items():
            disk_series[broker] = [(p["date"], p.get("disk_used_percent", 0)) for p in pts]
        self._append_chart(
            parts,
            self._line_chart(
                disk_series, CHART_COLORS,
                title="Broker Disk 사용률", subtitle="브로커별 디스크 사용률", y_suffix="%",
            ),
            series=disk_series, stat_title="Broker Disk 사용률", stat_y_suffix="%",
        )
        self._append_table(parts, disk_series, "Broker Disk 사용률", "%")

        # Network (bytes → MB)
        net_series: dict[str, list[tuple]] = {}
        for broker, pts in brokers.items():
            net_series[broker] = [
                (p["date"], round(p.get("network_in_bytes", 0) / 1_048_576, 1)) for p in pts
            ]
        self._append_chart(
            parts,
            self._line_chart(
                net_series, CHART_COLORS,
                title="Broker Network In", subtitle="브로커별 수신 트래픽", y_suffix="MB",
            ),
            series=net_series, stat_title="Broker Network In", stat_y_suffix="MB",
        )
        self._append_table(parts, net_series, "Broker Network In", "MB")

        return "\n".join(parts)

    def _build_glue_table_versions_charts(self, data: InfraReportData) -> str:
        """Glue Table Versions — Stacked Bar 2개 (C-1 포탈 동일).

        1. 테이블별 일일 버전 변경 건수 (Stacked Bar)
        2. Glue 쿼타 대비 누적 버전 (Stacked Bar) — 누적 데이터가 있는 경우
        """
        tables = data.glue_table_versions.get("tables", {})
        if not tables:
            return _no_data_placeholder("Glue Table Versions 데이터가 없습니다.")

        # 1. 일일 버전 변경 건수 → Stacked Bar
        change_series: dict[str, list[tuple]] = {}
        for table_name, pts in tables.items():
            change_series[table_name] = [(p["date"], p.get("version_changes", 0)) for p in pts]

        parts: list[str] = []
        self._append_chart(
            parts,
            self._stacked_bar_chart(
                change_series,
                CHART_COLORS,
                title="테이블별 일일 버전 변경 건수",
                subtitle="Glue 테이블 버전 변경 추이 (Stacked)",
                y_suffix="건",
                y_integer=True,
            ),
            series=change_series, stat_title="Glue 테이블 버전 변경", stat_y_suffix="건",
        )
        self._append_table(parts, change_series, "테이블별 버전 변경 건수", "건")

        # 2. 쿼타 대비 누적 버전 (tables 내 각 항목의 cumulative 필드에서 추출)
        has_cumulative = any(
            p.get("cumulative") is not None
            for pts in tables.values()
            for p in pts
        )
        if has_cumulative:
            cum_series: dict[str, list[tuple]] = {}
            for table_name, pts in tables.items():
                cum_series[table_name] = [(p["date"], p.get("cumulative", 0)) for p in pts]
            quota = data.glue_table_versions.get("quota_limit")
            ref_lines = []
            if quota:
                ref_lines.append({"value": quota, "label": f"Quota {quota:,}", "color": "#dc2626"})
            self._append_chart(
                parts,
                self._stacked_bar_chart(
                    cum_series,
                    CHART_COLORS,
                    title="테이블별 누적 버전 수 (쿼타 대비)",
                    subtitle="테이블별 누적 버전 수 vs Quota",
                    y_suffix="건",
                    y_integer=True,
                    reference_lines=ref_lines or None,
                ),
            )
            self._append_table(parts, cum_series, "쿼타 대비 누적 버전", "건")

        return "\n".join(parts)

    def _build_athena_top_queries_charts(self, data: InfraReportData) -> str:
        """Athena Top Queries by Data Scanned (테이블 기반)."""
        queries = data.athena_top_queries.get("queries", [])
        if not queries:
            return ""
        # 쿼리별 일별 스캔량 → 시리즈 (label 길이 제한)
        series: dict[str, list[tuple]] = {}
        for idx, q in enumerate(queries[:10]):
            label = q.get("query_label", "")
            short = label[:60] + "..." if len(label) > 60 else label
            key = f"Q{idx + 1}: {short}"
            daily = q.get("daily", [])
            series[key] = [(p["date"], p.get("scan_gb", 0)) for p in daily]
        parts: list[str] = []
        # 정적 리포트에는 테이블만 제공 (차트 생략)
        self._append_table(parts, series, "Athena 쿼리 스캔량 Top 10 (일별)", "GB")
        # include_tables가 꺼져있으면 차트라도 출력
        if not self._include_tables:
            self._append_chart(
                parts,
                self._line_chart(
                    series,
                    CHART_COLORS,
                    title="Athena 쿼리 스캔량 Top 10 (일별)",
                    subtitle="쿼리별 일별 데이터 스캔량",
                    y_suffix="GB",
                ),
                series=series, stat_title="Athena Top Queries", stat_y_suffix="GB",
            )
        return "\n".join(parts)

    # ── MSK Broker Health Summary ─────────────────────

    def _build_msk_broker_health_summary_chart(self, data: InfraReportData) -> str:
        """MSK Broker Health Status 요약 차트 (정상 브로커 수 추이)."""
        if data.msk_broker_health.get("is_mock"):
            return _no_data_placeholder("MSK Broker Health 데이터가 없습니다.")
        summary = data.msk_broker_health.get("summary", [])
        if not summary:
            return _no_data_placeholder("MSK Broker 헬스체크 데이터가 없습니다.")
        series: dict[str, list[tuple]] = {
            "정상 브로커": [(p["date"], p.get("healthy", 0)) for p in summary],
        }
        ref_lines = []
        if summary:
            total = summary[0].get("total", 0)
            if total > 0:
                ref_lines.append({"value": total, "label": f"전체 {total}대", "color": "#6b7280"})
        parts: list[str] = []
        self._append_chart(
            parts,
            self._line_chart(
                series,
                ["#16a34a"],
                title="Broker 헬스체크 상태",
                subtitle="정상 브로커 수 추이",
                y_suffix="대",
                y_integer=True,
                reference_lines=ref_lines or None,
            ),
            series=series, stat_title="Broker 헬스체크", stat_y_suffix="대",
            stat_colors=["#16a34a"],
        )
        self._append_table(parts, series, "Broker 헬스체크", "대")
        return "\n".join(parts)

    # ── SageMaker Pipeline Executions Table ───────────

    def _build_sagemaker_pipeline_table(self, data: InfraReportData) -> str:
        """SageMaker Studio Pipeline 실행 이력 테이블."""
        items = data.sagemaker_pipeline_executions.get("items", [])
        if not items:
            return ""

        status_colors = {
            "Succeeded": "#16a34a",
            "Failed": "#dc2626",
            "Executing": "#2563eb",
            "Stopping": "#d97706",
            "Stopped": "#6b7280",
        }

        rows = ""
        for item in items[:20]:
            name = html_escape(str(item.get("pipeline_name", "-")))
            status = str(item.get("status", "-"))
            s_color = status_colors.get(status, "#6b7280")
            start = str(item.get("start_time", "-"))[:19]  # ISO → YYYY-MM-DD HH:MM:SS
            duration = item.get("duration_display", "-")

            status_badge = (
                f'<span style="display:inline-block;padding:1px 8px;border-radius:9999px;'
                f'font-size:11px;background:{s_color}18;color:{s_color};'
                f'border:1px solid {s_color}40;">{html_escape(status)}</span>'
            )
            rows += (
                f"<tr>"
                f'<td style="padding:6px 12px;font-size:12px;">{name}</td>'
                f'<td style="padding:6px 12px;font-size:12px;">{status_badge}</td>'
                f'<td style="padding:6px 12px;font-size:12px;">{html_escape(start)}</td>'
                f'<td style="padding:6px 12px;font-size:12px;">{html_escape(str(duration))}</td>'
                f"</tr>"
            )

        return (
            '<div style="margin-top:12px;">'
            '<h4 style="font-size:14px;font-weight:600;margin:0 0 8px;">Pipeline 실행 이력</h4>'
            '<table style="width:100%;border-collapse:collapse;border:1px solid #e5e7eb;'
            'font-size:12px;">'
            '<thead><tr style="background:#f9fafb;">'
            '<th style="padding:8px 12px;text-align:left;border-bottom:1px solid #e5e7eb;">파이프라인</th>'
            '<th style="padding:8px 12px;text-align:left;border-bottom:1px solid #e5e7eb;">상태</th>'
            '<th style="padding:8px 12px;text-align:left;border-bottom:1px solid #e5e7eb;">시작시간</th>'
            '<th style="padding:8px 12px;text-align:left;border-bottom:1px solid #e5e7eb;">소요시간</th>'
            "</tr></thead>"
            f"<tbody>{rows}</tbody>"
            "</table></div>"
        )

    # ── Athena Query History Table ────────────────────

    def _build_athena_query_history_table(self, data: InfraReportData) -> str:
        """Athena Query History 테이블."""
        items = data.athena_query_history.get("items", [])
        if not items:
            return ""

        status_colors = {
            "SUCCEEDED": "#16a34a",
            "FAILED": "#dc2626",
            "CANCELLED": "#d97706",
            "RUNNING": "#2563eb",
            "QUEUED": "#6b7280",
        }

        rows = ""
        for item in items[:20]:
            time_str = str(item.get("submission_time", "-"))[:19]
            status = str(item.get("status", "-"))
            s_color = status_colors.get(status, "#6b7280")
            wg = html_escape(str(item.get("workgroup", "-")))
            query = html_escape(str(item.get("query_short", "-")))
            scan = html_escape(str(item.get("data_scanned_display", "-")))
            dur = item.get("duration_seconds", 0)
            dur_str = f"{dur:.1f}s" if dur else "-"

            status_badge = (
                f'<span style="display:inline-block;padding:1px 8px;border-radius:9999px;'
                f'font-size:11px;background:{s_color}18;color:{s_color};'
                f'border:1px solid {s_color}40;">{html_escape(status)}</span>'
            )
            rows += (
                f"<tr>"
                f'<td style="padding:6px 8px;font-size:11px;">{html_escape(time_str)}</td>'
                f'<td style="padding:6px 8px;font-size:11px;">{status_badge}</td>'
                f'<td style="padding:6px 8px;font-size:11px;">{wg}</td>'
                f'<td style="padding:6px 8px;font-size:11px;max-width:300px;'
                f'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{query}</td>'
                f'<td style="padding:6px 8px;font-size:11px;text-align:right;">{scan}</td>'
                f'<td style="padding:6px 8px;font-size:11px;text-align:right;">{dur_str}</td>'
                f"</tr>"
            )

        return (
            '<div style="margin-top:12px;">'
            '<h4 style="font-size:14px;font-weight:600;margin:0 0 8px;">Athena Query History</h4>'
            '<table style="width:100%;border-collapse:collapse;border:1px solid #e5e7eb;'
            'font-size:12px;">'
            '<thead><tr style="background:#f9fafb;">'
            '<th style="padding:8px;text-align:left;border-bottom:1px solid #e5e7eb;">실행시간</th>'
            '<th style="padding:8px;text-align:left;border-bottom:1px solid #e5e7eb;">상태</th>'
            '<th style="padding:8px;text-align:left;border-bottom:1px solid #e5e7eb;">워크그룹</th>'
            '<th style="padding:8px;text-align:left;border-bottom:1px solid #e5e7eb;">쿼리</th>'
            '<th style="padding:8px;text-align:right;border-bottom:1px solid #e5e7eb;">스캔량</th>'
            '<th style="padding:8px;text-align:right;border-bottom:1px solid #e5e7eb;">소요시간</th>'
            "</tr></thead>"
            f"<tbody>{rows}</tbody>"
            "</table></div>"
        )

    # ── Universe Pipeline Section ─────────────────────

    def _build_universe_pipeline_section(self, data: InfraReportData) -> str:
        """Universe 파이프라인 상태 요약."""
        pipeline = data.universe_pipeline
        if not pipeline:
            return ""

        parts: list[str] = []

        # 입수 파이프라인 상태
        p_status = pipeline.get("pipeline_status", {})
        if p_status:
            parts.append(self._build_pipeline_status_cards("입수 파이프라인", p_status))

        # 전송 파이프라인 상태
        t_status = pipeline.get("transfer_status", {})
        if t_status:
            parts.append(self._build_pipeline_status_cards("전송 파이프라인", t_status))

        return "\n".join(parts) if parts else ""

    def _build_pipeline_status_cards(self, title: str, status_data: dict) -> str:
        """파이프라인 노드 상태를 카드 형태로 렌더링."""
        node_labels = {
            "dmzS3": "DMZ S3",
            "bdpS3": "BDP S3",
            "wfl": "WFL (Airflow)",
            "bdpAthena": "BDP Athena",
            "bdpWfl": "BDP WFL",
            "gvApiPod": "GV API Pod",
        }

        cards: list[str] = []
        for node_key, node_data in status_data.items():
            if not isinstance(node_data, dict):
                continue
            label = node_labels.get(node_key, node_key)
            status = node_data.get("status", "neutral")
            s_color = STATUS_COLORS.get(status, "#6b7280")

            details: list[str] = []
            for k, v in node_data.items():
                if k == "status":
                    continue
                details.append(
                    f'<div style="font-size:11px;color:#6b7280;">'
                    f'<span style="font-weight:500;">{html_escape(str(k))}:</span> '
                    f'{html_escape(str(v))}</div>'
                )

            cards.append(
                f'<div style="border:1px solid {s_color};border-radius:8px;padding:12px;'
                f'background:#fff;min-width:160px;flex:1;">'
                f'<div style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">'
                f'<span style="width:8px;height:8px;border-radius:50%;background:{s_color};'
                f'display:inline-block;"></span>'
                f'<span style="font-size:13px;font-weight:600;">{html_escape(label)}</span>'
                f"</div>"
                f'{"".join(details)}'
                f"</div>"
            )

        arrow = (
            '<div style="display:flex;align-items:center;padding:0 4px;">'
            '<span style="font-size:18px;color:#9ca3af;">→</span></div>'
        )
        joined = arrow.join(cards) if cards else ""

        return (
            f'<div style="margin-top:12px;">'
            f'<h4 style="font-size:14px;font-weight:600;margin:0 0 8px;">{html_escape(title)}</h4>'
            f'<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:stretch;">'
            f'{joined}</div></div>'
        )


# ── Helpers ───────────────────────────────────────────


def _overall_status(resources: list[dict[str, Any]]) -> str:
    """리소스 목록에서 전체 상태 계산."""
    statuses = [r.get("display_status", "neutral") for r in resources]
    if "critical" in statuses:
        return "critical"
    if "warning" in statuses:
        return "warning"
    if all(s == "ok" for s in statuses):
        return "ok"
    return "neutral"


def _get_summary(svc_key: str, resources: list[dict[str, Any]]) -> str:
    """서비스 요약 문자열 (frontend getSummary() 미러링)."""
    if not resources:
        return "리소스 없음"

    if svc_key == "mwaa":
        versions = sorted(
            {str(r["airflow_version"]) for r in resources if r.get("airflow_version")}
        )
        return ", ".join(f"v{v}" for v in versions) if versions else ""

    if svc_key == "rds":
        engines = sorted({str(r["engine"]) for r in resources if r.get("engine")})
        return ", ".join(engines)

    if svc_key == "emr(cluster)":
        releases = sorted({str(r["release"]) for r in resources if r.get("release")})
        return ", ".join(releases)

    if svc_key == "emr(serverless)":
        types = sorted({str(r["type"]) for r in resources if r.get("type")})
        return ", ".join(types)

    if svc_key == "msk":
        versions = sorted({str(r["kafka_version"]) for r in resources if r.get("kafka_version")})
        return ", ".join(f"v{v}" for v in versions) if versions else ""

    if svc_key == "sagemaker endpoint":
        types = sorted({str(r["instance_type"]) for r in resources if r.get("instance_type")})
        return ", ".join(types)

    if svc_key == "sagemaker studio":
        total_users = sum(len(r.get("user_profiles") or []) for r in resources)
        total_images = sum(len(r.get("custom_images") or []) for r in resources)
        return f"{total_users}명 \u00b7 {total_images} images"

    if svc_key == "s3":
        total_gb = sum(float(r.get("bucket_size_gb") or 0) for r in resources)
        if total_gb > 1000:
            return f"{total_gb / 1000:.1f} TB"
        return f"{total_gb:.0f} GB"

    if svc_key == "glue":
        dbs = sum(int(r.get("database_count") or 0) for r in resources)
        tables = sum(int(r.get("table_count") or 0) for r in resources)
        return f"{dbs} DBs \u00b7 {tables} tables"

    if svc_key == "lambda":
        runtimes = sorted({str(r["runtime"]) for r in resources if r.get("runtime")})
        return ", ".join(runtimes)

    if svc_key == "athena":
        engines = sorted({str(r["engine_version"]) for r in resources if r.get("engine_version")})
        return ", ".join(engines)

    if svc_key == "eks":
        versions = sorted(
            {str(r["kubernetes_version"]) for r in resources if r.get("kubernetes_version")}
        )
        return f"k8s {', '.join(versions)}" if versions else ""

    return ""


def _extract_resource_details(svc_key: str, res: dict[str, Any]) -> list[tuple[str, str]]:
    """서비스 키에 따라 리소스 상세 정보를 (label, value) 쌍으로 추출.

    프론트엔드 topology-map.tsx의 buildInternals() 로직을 미러링.
    """
    details: list[tuple[str, str]] = []

    if svc_key == "mwaa":
        details.append(("Airflow", f"v{res.get('airflow_version', '-')}"))
        details.append(("환경 클래스", str(res.get("environment_class", "-"))))
        details.append(("Worker 수", str(res.get("min_workers", "-"))))
        dag_bucket = res.get("dag_s3_bucket")
        if dag_bucket:
            path = res.get("dag_s3_path", "")
            loc = f"s3://{dag_bucket}/{path}" if path else f"s3://{dag_bucket}"
            details.append(("DAG 경로", loc))

    elif svc_key == "sagemaker studio":
        details.append(("인증", str(res.get("auth_mode", "-"))))
        profiles = res.get("user_profiles") or []
        details.append(("사용자", f"{len(profiles)}명"))
        images = res.get("custom_images") or []
        details.append(("이미지", f"{len(images)}개"))
        lc = res.get("lifecycle_configs") or []
        details.append(("LC", f"{len(lc)}개"))
        efs = res.get("efs_storage_gb")
        if efs:
            details.append(("EFS", f"{efs} GB"))

    elif svc_key == "sagemaker endpoint":
        details.append(("인스턴스 타입", str(res.get("instance_type", "-"))))
        details.append(("인스턴스 수", str(res.get("instance_count", "-"))))

    elif svc_key == "emr(cluster)":
        details.append(("릴리즈", str(res.get("release", "-"))))
        details.append(("Core 타입", str(res.get("core_instance_type", "-"))))
        details.append(("Core 수", str(res.get("core_count", "-"))))
        task_count = res.get("task_count", 0)
        if task_count:
            details.append(("Task 타입", str(res.get("task_instance_type", "-"))))
            details.append(("Task 수", str(task_count)))
        buckets = res.get("s3_buckets") or []
        if buckets:
            details.append(("S3", ", ".join(str(b) for b in buckets)))

    elif svc_key == "emr(serverless)":
        details.append(("타입", str(res.get("type", "-"))))
        details.append(("릴리즈", str(res.get("release", "-"))))

    elif svc_key == "msk":
        details.append(("Kafka", f"v{res.get('kafka_version', '-')}"))
        details.append(("Broker 수", str(res.get("broker_count", "-"))))
        details.append(("인스턴스 타입", str(res.get("instance_type", "-"))))
        topics = res.get("topics") or []
        if topics:
            details.append(("Topics", f"{len(topics)}개"))

    elif svc_key == "glue":
        databases = res.get("databases") or []
        if databases:
            details.append(("데이터베이스", f"{len(databases)}개"))
        else:
            details.append(("DB 수", str(res.get("database_count", "-"))))
            details.append(("테이블 수", str(res.get("table_count", "-"))))

    elif svc_key == "lambda":
        details.append(("런타임", str(res.get("runtime", "-"))))

    elif svc_key == "athena":
        details.append(("엔진", str(res.get("engine_version", "-"))))
        loc = res.get("result_location")
        if loc:
            details.append(("결과 경로", str(loc)))

    elif svc_key == "eks":
        details.append(("K8s", f"v{res.get('kubernetes_version', '-')}"))

    elif svc_key == "s3":
        size = res.get("bucket_size_gb")
        if size is not None:
            details.append(("용량", f"{size} GB"))
        obj_count = res.get("object_count")
        if obj_count is not None:
            details.append(("객체 수", f"{int(obj_count):,}"))
        details.append(("버전관리", str(res.get("versioning", "Disabled"))))
        details.append(("암호화", str(res.get("encryption", "None"))))

    elif svc_key == "rds":
        details.append(("엔진", str(res.get("engine", "-"))))
        details.append(("클래스", str(res.get("instance_class", "-"))))
        st = res.get("storage_type", "")
        sg = res.get("storage_gb", "")
        storage_parts = [str(st).upper(), f"{sg} GB"] if sg else [str(st).upper()]
        details.append(("스토리지", " · ".join(p for p in storage_parts if p)))
        if res.get("multi_az") in (True, "true"):
            details.append(("Multi-AZ", "활성"))

    return details
