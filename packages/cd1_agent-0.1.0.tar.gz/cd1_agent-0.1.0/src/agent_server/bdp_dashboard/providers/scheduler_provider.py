"""MWAA Scheduler Provider - Scheduler 리소스 및 Heartbeat 상태."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaSchedulerProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaSchedulerProvider(BaseMwaaSchedulerProvider):
    """Mock 데이터 기반 MWAA Scheduler Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {"schedulers": 2},
        "bdp-airflow-wfl": {"schedulers": 1},
    }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                base_cpu = 10 + random.uniform(0, 10) if is_weekend else 20 + random.uniform(0, 25)
                heartbeat = random.choice(
                    ["healthy", "healthy", "healthy", "healthy", "healthy", "healthy", "degraded"]
                )
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(base_cpu, 1),
                        "heartbeat": heartbeat,
                    }
                )
            environments[env_name] = {
                "schedulers": cfg["schedulers"],
                "daily": daily,
            }
        return {"environments": environments}


class RealMwaaSchedulerProvider(BaseMwaaSchedulerProvider):
    """AWS MWAA Scheduler CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Scheduler provider not yet implemented")
