"""MWAA Storage Provider - S3 DAG Bucket 상태."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaStorageProvider(ABC):
    @abstractmethod
    def get_dag_bucket(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaStorageProvider(BaseMwaaStorageProvider):
    """Mock 데이터 기반 MWAA Storage Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {"bucket": "bdp-airflow-dlk-dags"},
        "bdp-airflow-wfl": {"bucket": "bdp-airflow-wfl-dags"},
    }

    def get_dag_bucket(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "size_mb": round(random.uniform(50, 200), 1),
                        "object_count": random.randint(200, 500),
                    }
                )
            environments[env_name] = {
                "bucket_name": cfg["bucket"],
                "daily": daily,
            }
        return {"environments": environments}


class RealMwaaStorageProvider(BaseMwaaStorageProvider):
    """AWS MWAA S3 DAG Bucket 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_dag_bucket(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Storage provider not yet implemented")
