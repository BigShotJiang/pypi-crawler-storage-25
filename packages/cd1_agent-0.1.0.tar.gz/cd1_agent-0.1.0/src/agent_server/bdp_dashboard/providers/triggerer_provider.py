"""MWAA Triggerer Provider - Triggerer 리소스 (제한된 CloudWatch 지원)."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaTriggererProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaTriggererProvider(BaseMwaaTriggererProvider):
    """Mock 데이터 기반 MWAA Triggerer Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {"triggerers": 1},
        "bdp-airflow-wfl": {"triggerers": 1},
    }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(random.uniform(5, 15), 1),
                        "memory_pct": round(random.uniform(20, 30), 1),
                    }
                )
            environments[env_name] = {
                "triggerers": cfg["triggerers"],
                "daily": daily,
            }
        return {"environments": environments}


class RealMwaaTriggererProvider(BaseMwaaTriggererProvider):
    """AWS MWAA Triggerer CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Triggerer provider not yet implemented")
