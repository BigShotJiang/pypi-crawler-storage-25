"""MWAA DAG Processor Provider - DAG 파싱 메트릭 및 Import 에러."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaDagProcessorProvider(ABC):
    @abstractmethod
    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaDagProcessorProvider(BaseMwaaDagProcessorProvider):
    """Mock 데이터 기반 MWAA DAG Processor Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {"dag_range": (200, 250)},
        "bdp-airflow-wfl": {"dag_range": (80, 120)},
    }

    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            dag_min, dag_max = cfg["dag_range"]
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "parse_time_sec": round(random.uniform(0.5, 3.0), 2),
                        "total_dags": random.randint(dag_min, dag_max),
                        "import_errors": random.randint(0, 5),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}


class RealMwaaDagProcessorProvider(BaseMwaaDagProcessorProvider):
    """AWS MWAA DAG Processor CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_parsing_metrics(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA DAG Processor provider not yet implemented")
