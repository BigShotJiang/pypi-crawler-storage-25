"""MWAA Environment Provider - MWAA 환경 개요 및 상태."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaEnvironmentProvider(ABC):
    @abstractmethod
    def get_overview(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaEnvironmentProvider(BaseMwaaEnvironmentProvider):
    """Mock 데이터 기반 MWAA Environment Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {
            "airflow_version": "2.8.1",
            "environment_class": "mw1.xlarge",
        },
        "bdp-airflow-wfl": {
            "airflow_version": "2.8.1",
            "environment_class": "mw1.medium",
        },
    }

    def get_overview(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "status": random.choice(
                            ["AVAILABLE", "AVAILABLE", "AVAILABLE", "AVAILABLE", "UPDATING"]
                        ),
                    }
                )
            environments[env_name] = {
                "airflow_version": cfg["airflow_version"],
                "environment_class": cfg["environment_class"],
                "last_update": dates[-1],
                "daily": daily,
            }
        return {"environments": environments}


class RealMwaaEnvironmentProvider(BaseMwaaEnvironmentProvider):
    """AWS MWAA Environment API 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_overview(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Environment provider not yet implemented")
