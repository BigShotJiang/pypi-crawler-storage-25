"""MWAA Database Provider - Aurora PostgreSQL 리소스 및 헬스 상태."""

import random
from abc import ABC, abstractmethod
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaDatabaseProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_health(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaDatabaseProvider(BaseMwaaDatabaseProvider):
    """Mock 데이터 기반 MWAA Database Provider."""

    MAX_CONNECTIONS = 200

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {},
        "bdp-airflow-wfl": {},
    }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in self.ENVIRONMENTS:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(random.uniform(5, 20), 1),
                        "connections": random.randint(10, 50),
                    }
                )
            environments[env_name] = {
                "max_connections": self.MAX_CONNECTIONS,
                "daily": daily,
            }
        return {"environments": environments}

    def get_health(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in self.ENVIRONMENTS:
            daily = []
            for d in dates:
                daily.append(
                    {
                        "date": d,
                        "db_size_mb": round(random.uniform(500, 800), 1),
                        "health": "healthy",
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}


class RealMwaaDatabaseProvider(BaseMwaaDatabaseProvider):
    """AWS MWAA Database (Aurora PostgreSQL) CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Database provider not yet implemented")

    def get_health(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Database provider not yet implemented")
