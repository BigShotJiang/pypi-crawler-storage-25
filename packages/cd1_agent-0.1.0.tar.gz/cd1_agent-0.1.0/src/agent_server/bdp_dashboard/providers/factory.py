"""MWAA Provider Factory - Provider 번들 생성."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

from .dag_processor_provider import (
    BaseMwaaDagProcessorProvider,
    MockMwaaDagProcessorProvider,
    RealMwaaDagProcessorProvider,
)
from .database_provider import (
    BaseMwaaDatabaseProvider,
    MockMwaaDatabaseProvider,
    RealMwaaDatabaseProvider,
)
from .environment_provider import (
    BaseMwaaEnvironmentProvider,
    MockMwaaEnvironmentProvider,
    RealMwaaEnvironmentProvider,
)
from .scheduler_provider import (
    BaseMwaaSchedulerProvider,
    MockMwaaSchedulerProvider,
    RealMwaaSchedulerProvider,
)
from .storage_provider import (
    BaseMwaaStorageProvider,
    MockMwaaStorageProvider,
    RealMwaaStorageProvider,
)
from .triggerer_provider import (
    BaseMwaaTriggererProvider,
    MockMwaaTriggererProvider,
    RealMwaaTriggererProvider,
)
from .webserver_provider import (
    BaseMwaaWebServerProvider,
    MockMwaaWebServerProvider,
    RealMwaaWebServerProvider,
)
from .worker_provider import BaseMwaaWorkerProvider, MockMwaaWorkerProvider, RealMwaaWorkerProvider

logger = logging.getLogger(__name__)


@dataclass
class MwaaProviderBundle:
    """모든 MWAA Provider를 묶는 번들."""

    scheduler: BaseMwaaSchedulerProvider
    dag_processor: BaseMwaaDagProcessorProvider
    worker: BaseMwaaWorkerProvider
    triggerer: BaseMwaaTriggererProvider
    webserver: BaseMwaaWebServerProvider
    database: BaseMwaaDatabaseProvider
    storage: BaseMwaaStorageProvider
    environment: BaseMwaaEnvironmentProvider


def create_mwaa_providers(
    provider_type: str | None = None,
    **kwargs: Any,
) -> MwaaProviderBundle:
    """Factory function to create MWAA provider bundle.

    Args:
        provider_type: Provider type ("mock" or "real"). Defaults to MWAA_PROVIDER env var or "mock".
        **kwargs: Provider-specific settings.

    Returns:
        MwaaProviderBundle with all providers configured.
    """
    provider_type = provider_type or os.getenv("MWAA_PROVIDER", "mock")
    logger.info(f"Creating MWAA providers: type={provider_type}")

    settings = kwargs.get("settings")

    if provider_type == "real":
        return MwaaProviderBundle(
            scheduler=RealMwaaSchedulerProvider(settings=settings),
            dag_processor=RealMwaaDagProcessorProvider(settings=settings),
            worker=RealMwaaWorkerProvider(settings=settings),
            triggerer=RealMwaaTriggererProvider(settings=settings),
            webserver=RealMwaaWebServerProvider(settings=settings),
            database=RealMwaaDatabaseProvider(settings=settings),
            storage=RealMwaaStorageProvider(settings=settings),
            environment=RealMwaaEnvironmentProvider(settings=settings),
        )
    else:
        return MwaaProviderBundle(
            scheduler=MockMwaaSchedulerProvider(),
            dag_processor=MockMwaaDagProcessorProvider(),
            worker=MockMwaaWorkerProvider(),
            triggerer=MockMwaaTriggererProvider(),
            webserver=MockMwaaWebServerProvider(),
            database=MockMwaaDatabaseProvider(),
            storage=MockMwaaStorageProvider(),
            environment=MockMwaaEnvironmentProvider(),
        )
