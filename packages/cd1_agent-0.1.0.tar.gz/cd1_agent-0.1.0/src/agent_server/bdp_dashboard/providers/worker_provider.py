"""MWAA Worker Pool Provider - Worker 오토스케일링, 리소스, 태스크 실행."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaWorkerProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...
    @abstractmethod
    def get_task_execution(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaWorkerProvider(BaseMwaaWorkerProvider):
    """Mock 데이터 기반 MWAA Worker Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {
            "min_workers": 2,
            "max_workers": 10,
            "weekday_active": (3, 8),
            "weekend_active": (2, 3),
            "concurrent_range": (10, 40),
            "queued_range": (0, 8),
        },
        "bdp-airflow-wfl": {
            "min_workers": 1,
            "max_workers": 5,
            "weekday_active": (2, 4),
            "weekend_active": (1, 2),
            "concurrent_range": (5, 15),
            "queued_range": (0, 3),
        },
    }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                if is_weekend:
                    active = random.randint(*cfg["weekend_active"])
                    base_cpu = 15 + random.uniform(0, 10)
                else:
                    active = random.randint(*cfg["weekday_active"])
                    base_cpu = 30 + random.uniform(0, 25)
                daily.append(
                    {
                        "date": d,
                        "active_workers": active,
                        "cpu_pct": round(base_cpu, 1),
                    }
                )
            environments[env_name] = {
                "min_workers": cfg["min_workers"],
                "max_workers": cfg["max_workers"],
                "daily": daily,
            }
        return {"environments": environments}

    def get_task_execution(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name, cfg in self.ENVIRONMENTS.items():
            daily = []
            for d in dates:
                c_min, c_max = cfg["concurrent_range"]
                q_min, q_max = cfg["queued_range"]
                daily.append(
                    {
                        "date": d,
                        "concurrent_tasks": random.randint(c_min, c_max),
                        "queued_tasks": random.randint(q_min, q_max),
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}


class RealMwaaWorkerProvider(BaseMwaaWorkerProvider):
    """AWS MWAA Worker CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Worker provider not yet implemented")

    def get_task_execution(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA Worker provider not yet implemented")
