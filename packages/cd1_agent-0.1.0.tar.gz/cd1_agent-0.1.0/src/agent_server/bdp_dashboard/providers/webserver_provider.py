"""MWAA WebServer Provider - WebServer 리소스 및 요청 메트릭."""

import random
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from src.agent_server.hdsp_dashboard.services.hdsp_utils import _daily_dates


class BaseMwaaWebServerProvider(ABC):
    @abstractmethod
    def get_resource_usage(self, days: int = 31) -> dict[str, Any]: ...


class MockMwaaWebServerProvider(BaseMwaaWebServerProvider):
    """Mock 데이터 기반 MWAA WebServer Provider."""

    ENVIRONMENTS = {
        "bdp-airflow-dlk": {},
        "bdp-airflow-wfl": {},
    }

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        dates = _daily_dates(days)
        environments: dict[str, Any] = {}
        for env_name in self.ENVIRONMENTS:
            daily = []
            for d in dates:
                dt = datetime.fromisoformat(d)
                is_weekend = dt.weekday() >= 5
                if is_weekend:
                    base_cpu = 5 + random.uniform(0, 10)
                    base_requests = random.randint(200, 400)
                else:
                    base_cpu = 10 + random.uniform(0, 25)
                    base_requests = random.randint(400, 800)
                daily.append(
                    {
                        "date": d,
                        "cpu_pct": round(base_cpu, 1),
                        "request_count": base_requests,
                    }
                )
            environments[env_name] = {"daily": daily}
        return {"environments": environments}


class RealMwaaWebServerProvider(BaseMwaaWebServerProvider):
    """AWS MWAA WebServer CloudWatch 연동 Provider."""

    def __init__(self, settings: Any = None):
        self.settings = settings

    def get_resource_usage(self, days: int = 31) -> dict[str, Any]:
        raise NotImplementedError("Real MWAA WebServer provider not yet implemented")
