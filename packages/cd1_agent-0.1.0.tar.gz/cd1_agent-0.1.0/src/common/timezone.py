"""KST 타임존 유틸리티.

프로젝트 전체에서 일관된 KST(한국 표준시) 타임존 사용을 위한 중앙 모듈.
"""

from datetime import datetime, timedelta, timezone

KST = timezone(timedelta(hours=9))


def get_kst_now() -> datetime:
    """현재 KST 시간 반환."""
    return datetime.now(KST)
