"""
Airflow Tools - DAG/Task 실행이력 조회 및 로그 검색 Tool.

Chat 에이전트에서 자연어로 Airflow 실행이력을 조회하고
실패 원인을 요약받을 수 있도록 지원합니다.
"""

import logging
import os
from collections import defaultdict
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


def get_dag_history(
    dag_id: str = "",
    days: int = 7,
    environment: str = "all",
) -> dict[str, Any]:
    """DAG 실행 이력 조회.

    특정 DAG의 최근 실행 이력, 성공률, 실패 추이를 조회합니다.

    Args:
        dag_id: DAG ID (필수)
        days: 조회 기간 (일)
        environment: 환경 필터 (dlk, wfl, all)

    Returns:
        DAG 실행 이력 및 통계
    """
    if not dag_id:
        return {"error": "dag_id를 지정해주세요.", "success": False}

    try:
        from src.agent_server.bdp_airflow.services.airflow_failure_store import (
            AirflowFailureStore,
        )

        provider = AirflowFailureStore.create_provider(
            provider_type=os.getenv("BDP_PROVIDER", "mock"),
            secret_id=os.getenv("MWAA_SECRET_ID", ""),
            db=os.getenv("MWAA_DB_NAME", ""),
        )

        # 이력 조회
        history = provider.get_failure_history(dag_id=dag_id, days=days)

        # 환경 필터
        if environment != "all":
            history = [r for r in history if r.rcpt_tp == environment]

        if not history:
            return {
                "dag_id": dag_id,
                "message": f"{dag_id}의 최근 {days}일 이력이 없습니다.",
                "total_runs": 0,
                "success": True,
            }

        # 통계 계산
        total = len(history)
        failed = sum(1 for r in history if r.is_failed)
        success_rate = round((1 - failed / total) * 100, 1) if total > 0 else 100.0

        # 최근 실행 목록 (최신 10건)
        sorted_history = sorted(history, key=lambda r: r.start_date, reverse=True)
        recent_runs = [
            {
                "start_date": r.start_date,
                "task_id": r.task_id,
                "state": r.state,
                "duration": r.duration,
                "err_msg": (r.err_msg[:150] + "...")
                if r.err_msg and len(r.err_msg) > 150
                else r.err_msg,
                "environment": r.rcpt_tp,
            }
            for r in sorted_history[:10]
        ]

        # Task별 실패 통계
        task_failures: dict[str, int] = defaultdict(int)
        for r in history:
            if r.is_failed:
                task_failures[r.task_id] += 1
        top_failing_tasks = sorted(task_failures.items(), key=lambda x: x[1], reverse=True)[:5]

        # 최근 에러 메시지 (고유한 것만)
        recent_errors = list(
            {r.err_msg[:200] for r in sorted_history if r.is_failed and r.err_msg}
        )[:5]

        return {
            "dag_id": dag_id,
            "period_days": days,
            "environment": environment,
            "total_runs": total,
            "failed_count": failed,
            "success_rate": success_rate,
            "recent_runs": recent_runs,
            "top_failing_tasks": [{"task_id": t, "failure_count": c} for t, c in top_failing_tasks],
            "recent_errors": recent_errors,
            "success": True,
        }

    except Exception as e:
        logger.error(f"DAG 이력 조회 실패: {e}")
        return {"dag_id": dag_id, "error": str(e), "success": False}


def get_task_history(
    dag_id: str = "",
    task_id: str = "",
    days: int = 7,
) -> dict[str, Any]:
    """특정 Task의 실행 이력 조회.

    Args:
        dag_id: DAG ID (필수)
        task_id: Task ID (필수)
        days: 조회 기간 (일)

    Returns:
        Task 실행 이력 및 통계
    """
    if not dag_id or not task_id:
        return {"error": "dag_id와 task_id를 모두 지정해주세요.", "success": False}

    try:
        from src.agent_server.bdp_airflow.services.airflow_failure_store import (
            AirflowFailureStore,
        )

        provider = AirflowFailureStore.create_provider(
            provider_type=os.getenv("BDP_PROVIDER", "mock"),
            secret_id=os.getenv("MWAA_SECRET_ID", ""),
            db=os.getenv("MWAA_DB_NAME", ""),
        )

        history = provider.get_failure_history(dag_id=dag_id, days=days)
        task_history = [r for r in history if r.task_id == task_id]

        if not task_history:
            return {
                "dag_id": dag_id,
                "task_id": task_id,
                "message": f"{dag_id}/{task_id}의 최근 {days}일 이력이 없습니다.",
                "total_runs": 0,
                "success": True,
            }

        sorted_history = sorted(task_history, key=lambda r: r.start_date, reverse=True)
        total = len(task_history)
        failed = sum(1 for r in task_history if r.is_failed)
        success_rate = round((1 - failed / total) * 100, 1) if total > 0 else 100.0

        # Duration 추이
        durations = [r.duration_seconds for r in sorted_history if r.duration_seconds is not None]
        avg_duration = round(sum(durations) / len(durations), 1) if durations else 0

        # 실행 이력
        runs = [
            {
                "start_date": r.start_date,
                "state": r.state,
                "duration_sec": r.duration_seconds,
                "err_msg": (r.err_msg[:200] + "...")
                if r.err_msg and len(r.err_msg) > 200
                else r.err_msg,
                "environment": r.rcpt_tp,
            }
            for r in sorted_history[:15]
        ]

        # 에러 패턴
        error_patterns: dict[str, int] = defaultdict(int)
        for r in task_history:
            if r.is_failed and r.err_msg:
                # 에러 메시지의 첫 줄을 패턴으로 사용
                first_line = r.err_msg.split("\n")[0][:100]
                error_patterns[first_line] += 1
        top_errors = sorted(error_patterns.items(), key=lambda x: x[1], reverse=True)[:3]

        return {
            "dag_id": dag_id,
            "task_id": task_id,
            "period_days": days,
            "total_runs": total,
            "failed_count": failed,
            "success_rate": success_rate,
            "avg_duration_sec": avg_duration,
            "duration_trend": durations[:5] if durations else [],
            "runs": runs,
            "error_patterns": [{"pattern": p, "count": c} for p, c in top_errors],
            "success": True,
        }

    except Exception as e:
        logger.error(f"Task 이력 조회 실패: {e}")
        return {"dag_id": dag_id, "task_id": task_id, "error": str(e), "success": False}


def search_airflow_logs(
    dag_id: str = "",
    task_id: str | None = None,
    keywords: str = "ERROR",
    hours: int = 24,
) -> dict[str, Any]:
    """Airflow 로그 검색.

    DAG/Task 관련 CloudWatch 로그를 키워드로 검색합니다.

    Args:
        dag_id: DAG ID (필수)
        task_id: Task ID (선택)
        keywords: 검색 키워드 (쉼표 구분. 예: "ERROR,timeout,OOM")
        hours: 조회 기간 (시간)

    Returns:
        매칭된 로그 엔트리
    """
    if not dag_id:
        return {"error": "dag_id를 지정해주세요.", "success": False}

    try:
        from src.agent_server.bdp_airflow.services.log_analyzer import AirflowLogAnalyzer

        log_provider = os.getenv("LOG_PROVIDER", "mock")
        analyzer = AirflowLogAnalyzer(use_mock=log_provider == "mock")

        keyword_list = [k.strip() for k in keywords.split(",") if k.strip()]
        results = analyzer.search_error_context(
            dag_id=dag_id,
            task_id=task_id,
            hours=hours,
            keywords=keyword_list,
        )

        return {
            "dag_id": dag_id,
            "task_id": task_id,
            "search_keywords": keyword_list,
            "search_hours": hours,
            "total_matches": len(results),
            "log_entries": results[:30],
            "is_mock": log_provider == "mock",
            "success": True,
        }

    except Exception as e:
        logger.error(f"Airflow 로그 검색 실패: {e}")
        return {"dag_id": dag_id, "error": str(e), "success": False}


def get_airflow_failure_summary(
    hours: int = 24,
    environment: str = "all",
) -> dict[str, Any]:
    """Airflow 실패 현황 요약.

    최근 N시간의 전체 실패 현황을 요약합니다.

    Args:
        hours: 조회 기간 (시간)
        environment: 환경 필터 (dlk, wfl, all)

    Returns:
        실패 현황 요약
    """
    try:
        from src.agent_server.bdp_airflow.services.airflow_failure_store import (
            AirflowFailureStore,
        )

        provider = AirflowFailureStore.create_provider(
            provider_type=os.getenv("BDP_PROVIDER", "mock"),
            secret_id=os.getenv("MWAA_SECRET_ID", ""),
            db=os.getenv("MWAA_DB_NAME", ""),
        )

        rcpt_types = [t.strip() for t in os.getenv("MWAA_RCPT_TYPES", "dlk,wfl").split(",")]
        if environment != "all":
            rcpt_types = [environment]

        all_records = []
        for rcpt_tp in rcpt_types:
            records = provider.get_failures(rcpt_tp=rcpt_tp, hours=hours)
            all_records.extend(records)

        total = len(all_records)
        failed = sum(1 for r in all_records if r.is_failed)
        success_rate = round((1 - failed / total) * 100, 1) if total > 0 else 100.0

        # 환경별 통계
        env_stats: dict[str, dict] = {}
        for rcpt_tp in rcpt_types:
            env_recs = [r for r in all_records if r.rcpt_tp == rcpt_tp]
            env_failed = sum(1 for r in env_recs if r.is_failed)
            env_stats[rcpt_tp] = {
                "total": len(env_recs),
                "failed": env_failed,
                "success_rate": round((1 - env_failed / len(env_recs)) * 100, 1)
                if env_recs
                else 100.0,
            }

        # DAG별 실패 Top-5
        dag_failures: dict[str, int] = defaultdict(int)
        for r in all_records:
            if r.is_failed:
                dag_failures[r.dag_id] += 1
        top_failing = sorted(dag_failures.items(), key=lambda x: x[1], reverse=True)[:5]

        # 최근 에러 요약
        recent_errors = list(
            {
                r.err_msg[:150]
                for r in sorted(all_records, key=lambda x: x.start_date, reverse=True)
                if r.is_failed and r.err_msg
            }
        )[:5]

        return {
            "period_hours": hours,
            "environment": environment,
            "total_records": total,
            "failed_count": failed,
            "success_rate": success_rate,
            "environment_stats": env_stats,
            "top_failing_dags": [{"dag_id": d, "failure_count": c} for d, c in top_failing],
            "recent_error_samples": recent_errors,
            "success": True,
        }

    except Exception as e:
        logger.error(f"Airflow 실패 현황 요약 실패: {e}")
        return {"error": str(e), "success": False}


def create_airflow_tools() -> dict[str, Callable]:
    """Airflow Chat Tool 세트 생성.

    Returns:
        Tool 딕셔너리
    """
    return {
        "get_dag_history": get_dag_history,
        "get_task_history": get_task_history,
        "search_airflow_logs": search_airflow_logs,
        "get_airflow_failure_summary": get_airflow_failure_summary,
    }
