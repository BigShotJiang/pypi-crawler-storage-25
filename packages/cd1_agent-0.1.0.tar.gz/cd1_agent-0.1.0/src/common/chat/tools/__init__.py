"""
Chat Tools - 대화형 에이전트용 Tool 래퍼.
"""

from collections.abc import Callable
from typing import Dict, Optional

from src.common.chat.tools.airflow import (
    create_airflow_tools,
    get_airflow_failure_summary,
    get_dag_history,
    get_task_history,
    search_airflow_logs,
)
from src.common.chat.tools.cloudwatch import (
    create_cloudwatch_tools,
    get_cloudwatch_metrics,
    query_cloudwatch_logs,
)
from src.common.chat.tools.prometheus import (
    create_prometheus_tools,
    get_pod_status,
    get_prometheus_metrics,
)
from src.common.chat.tools.rds import (
    create_rds_tools,
    query_anomalies,
    query_metrics,
)
from src.common.chat.tools.service_health import (
    check_recent_deployments,
    create_service_health_tools,
    get_service_health,
)
from src.common.services.aws_client import AWSClient
from src.common.services.llm_client import LLMClient
from src.common.services.rds_client import RDSClient

try:
    from src.common.chat.tools.drift import (
        analyze_config_drift,
        approve_remediation,
        check_drift_status,
        create_drift_tools,
        get_remediation_plan,
    )
except ImportError:
    create_drift_tools = None
    analyze_config_drift = None
    check_drift_status = None
    get_remediation_plan = None
    approve_remediation = None


def create_chat_tools(
    aws_client: AWSClient,
    rds_client: RDSClient | None = None,
    llm_client: LLMClient | None = None,
) -> dict[str, Callable]:
    """
    Chat 에이전트용 전체 Tool 세트 생성.

    Args:
        aws_client: AWS 클라이언트
        rds_client: RDS 클라이언트 (선택, 없으면 Mock 사용)
        llm_client: LLM 클라이언트 (선택, Drift 분석용)

    Returns:
        Tool 딕셔너리
    """
    tools = {}

    # CloudWatch Tools
    tools.update(create_cloudwatch_tools(aws_client))

    # Service Health Tools
    tools.update(create_service_health_tools(aws_client))

    # Prometheus Tools (Mock)
    tools.update(create_prometheus_tools())

    # RDS Tools
    tools.update(create_rds_tools(rds_client))

    # Airflow Tools (DAG/Task 이력 조회, 로그 검색)
    tools.update(create_airflow_tools())

    # Drift Analysis Tools (LLM 기반 원인 분석 + HITL)
    if create_drift_tools is not None:
        tools.update(create_drift_tools(llm_client))

    return tools


__all__ = [
    "create_chat_tools",
    "create_rds_tools",
    "create_airflow_tools",
    "get_cloudwatch_metrics",
    "query_cloudwatch_logs",
    "get_service_health",
    "check_recent_deployments",
    "get_prometheus_metrics",
    "get_pod_status",
    "query_anomalies",
    "query_metrics",
    "get_dag_history",
    "get_task_history",
    "search_airflow_logs",
    "get_airflow_failure_summary",
]

if create_drift_tools is not None:
    __all__ += [
        "create_drift_tools",
        "analyze_config_drift",
        "check_drift_status",
        "get_remediation_plan",
        "approve_remediation",
    ]
