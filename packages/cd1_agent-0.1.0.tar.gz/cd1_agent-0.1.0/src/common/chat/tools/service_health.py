"""
Service Health Tools - 서비스 상태 관련 Tool.
"""

import logging
from collections.abc import Callable
from datetime import timedelta
from typing import Any

from src.common.services.aws_client import AWSClient
from src.common.timezone import get_kst_now

logger = logging.getLogger(__name__)


def get_service_health(
    aws_client: AWSClient,
    service_name: str = "default",
) -> dict[str, Any]:
    """서비스 전체 상태 조회. 서비스 타입에 따라 적절한 AWS API 호출.

    Args:
        aws_client: AWS 클라이언트
        service_name: 서비스 이름 또는 타입 (rds, msk, eks, mwaa, lambda, all)

    Returns:
        서비스 상태 정보
    """
    logger.info(f"서비스 상태 조회: {service_name}")
    svc_lower = service_name.lower()

    try:
        if "rds" in svc_lower:
            return _rds_health(aws_client, service_name)
        elif "msk" in svc_lower:
            return _msk_health(aws_client, service_name)
        elif "eks" in svc_lower:
            return _eks_health(aws_client, service_name)
        elif "mwaa" in svc_lower:
            return _mwaa_health(aws_client, service_name)
        elif svc_lower == "all":
            return _all_services_health(aws_client)
        else:
            return _lambda_health(aws_client, service_name)
    except Exception as e:
        logger.error(f"서비스 상태 조회 실패: {e}")
        return {
            "service_name": service_name,
            "health_status": "unknown",
            "error": str(e),
            "success": False,
        }


def _lambda_health(aws_client: AWSClient, service_name: str) -> dict[str, Any]:
    """Lambda 서비스 건강 상태."""
    end_time = get_kst_now()
    start_time = end_time - timedelta(hours=1)

    error_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/Lambda",
        metric_name="Errors",
        dimensions=[{"Name": "FunctionName", "Value": service_name}],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Sum",
    )
    invocation_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/Lambda",
        metric_name="Invocations",
        dimensions=[{"Name": "FunctionName", "Value": service_name}],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Sum",
    )

    total_invocations = sum(invocation_metrics.get("values", [0]))
    total_errors = sum(error_metrics.get("values", [0]))
    error_rate = (total_errors / total_invocations * 100) if total_invocations > 0 else 0

    health_status = "critical" if error_rate > 10 else ("warning" if error_rate > 5 else "healthy")

    return {
        "service_name": service_name,
        "service_type": "lambda",
        "health_status": health_status,
        "metrics": {
            "total_invocations": total_invocations,
            "total_errors": total_errors,
            "error_rate": f"{error_rate:.2f}%",
        },
        "success": True,
    }


def _rds_health(aws_client: AWSClient, service_name: str) -> dict[str, Any]:
    """RDS 서비스 건강 상태."""
    end_time = get_kst_now()
    start_time = end_time - timedelta(hours=1)

    cpu_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/RDS",
        metric_name="CPUUtilization",
        dimensions=[],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Average",
    )
    conn_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/RDS",
        metric_name="DatabaseConnections",
        dimensions=[],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Average",
    )

    avg_cpu = cpu_metrics.get("average", 0)
    health_status = "critical" if avg_cpu > 90 else ("warning" if avg_cpu > 70 else "healthy")

    return {
        "service_name": service_name,
        "service_type": "rds",
        "health_status": health_status,
        "metrics": {
            "avg_cpu": avg_cpu,
            "avg_connections": conn_metrics.get("average", 0),
        },
        "success": True,
    }


def _msk_health(aws_client: AWSClient, service_name: str) -> dict[str, Any]:
    """MSK 서비스 건강 상태."""
    end_time = get_kst_now()
    start_time = end_time - timedelta(hours=1)

    cpu_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/Kafka",
        metric_name="CpuUser",
        dimensions=[],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Average",
    )

    avg_cpu = cpu_metrics.get("average", 0)
    health_status = "critical" if avg_cpu > 80 else ("warning" if avg_cpu > 60 else "healthy")

    return {
        "service_name": service_name,
        "service_type": "msk",
        "health_status": health_status,
        "metrics": {"avg_broker_cpu": avg_cpu},
        "success": True,
    }


def _eks_health(aws_client: AWSClient, service_name: str) -> dict[str, Any]:
    """EKS 서비스 건강 상태."""
    end_time = get_kst_now()
    start_time = end_time - timedelta(hours=1)

    cpu_metrics = aws_client.get_cloudwatch_metrics(
        namespace="ContainerInsights",
        metric_name="node_cpu_utilization",
        dimensions=[],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Average",
    )

    avg_cpu = cpu_metrics.get("average", 0)
    health_status = "critical" if avg_cpu > 85 else ("warning" if avg_cpu > 70 else "healthy")

    return {
        "service_name": service_name,
        "service_type": "eks",
        "health_status": health_status,
        "metrics": {"avg_node_cpu": avg_cpu},
        "success": True,
    }


def _mwaa_health(aws_client: AWSClient, service_name: str) -> dict[str, Any]:
    """MWAA 서비스 건강 상태."""
    end_time = get_kst_now()
    start_time = end_time - timedelta(hours=1)

    cpu_metrics = aws_client.get_cloudwatch_metrics(
        namespace="AWS/MWAA",
        metric_name="CPUUtilization",
        dimensions=[],
        start_time=start_time,
        end_time=end_time,
        period=300,
        statistic="Average",
    )

    avg_cpu = cpu_metrics.get("average", 0)
    health_status = "critical" if avg_cpu > 90 else ("warning" if avg_cpu > 75 else "healthy")

    return {
        "service_name": service_name,
        "service_type": "mwaa",
        "health_status": health_status,
        "metrics": {"avg_cpu": avg_cpu},
        "success": True,
    }


def _all_services_health(aws_client: AWSClient) -> dict[str, Any]:
    """전체 서비스 헬스 요약."""
    services = {}
    for svc_name, fn in [
        ("rds", _rds_health),
        ("msk", _msk_health),
        ("eks", _eks_health),
        ("mwaa", _mwaa_health),
    ]:
        try:
            services[svc_name] = fn(aws_client, svc_name)
        except Exception as e:
            services[svc_name] = {"health_status": "unknown", "error": str(e), "success": False}

    statuses = [s.get("health_status", "unknown") for s in services.values()]
    if "critical" in statuses:
        overall = "critical"
    elif "warning" in statuses:
        overall = "warning"
    else:
        overall = "healthy"

    return {
        "service_name": "all",
        "health_status": overall,
        "services": services,
        "success": True,
    }


def check_recent_deployments(
    aws_client: AWSClient,
    service_name: str = "default",
    hours: int = 24,
) -> dict[str, Any]:
    """
    최근 배포 이력 조회.

    Args:
        aws_client: AWS 클라이언트
        service_name: 서비스 이름
        hours: 조회 기간 (시간)

    Returns:
        배포 이력
    """
    logger.info(f"배포 이력 조회: {service_name}")

    try:
        end_time = get_kst_now()
        start_time = end_time - timedelta(hours=hours)

        # CloudTrail에서 최근 변경 이벤트 조회
        events = aws_client.lookup_cloudtrail_events(
            start_time=start_time,
            end_time=end_time,
            event_names=[
                "UpdateFunctionCode",
                "UpdateService",
                "CreateDeployment",
                "UpdateEnvironment",
                "ModifyDBInstance",
                "UpdateCluster",
            ],
            max_results=20,
        )

        deployments = []
        for evt in events:
            deployments.append(
                {
                    "event_name": evt.get("EventName", ""),
                    "timestamp": evt.get("EventTime", ""),
                    "username": evt.get("Username", ""),
                    "resources": evt.get("Resources", []),
                }
            )

        return {
            "service_name": service_name,
            "deployments": deployments,
            "time_range": f"최근 {hours}시간",
            "success": True,
        }
    except Exception as e:
        logger.warning(f"CloudTrail 조회 실패, mock fallback: {e}")
        return {
            "service_name": service_name,
            "deployments": [
                {
                    "event_name": "unknown",
                    "timestamp": (get_kst_now() - timedelta(hours=2)).isoformat(),
                    "username": "unknown",
                    "resources": [],
                }
            ],
            "time_range": f"최근 {hours}시간",
            "success": True,
            "is_mock": True,
        }


def create_service_health_tools(aws_client: AWSClient) -> dict[str, Callable]:
    """Service Health Tool 세트 생성."""

    def _get_health(**kwargs) -> dict[str, Any]:
        return get_service_health(aws_client, **kwargs)

    def _check_deployments(**kwargs) -> dict[str, Any]:
        return check_recent_deployments(aws_client, **kwargs)

    return {
        "get_service_health": _get_health,
        "check_recent_deployments": _check_deployments,
    }
