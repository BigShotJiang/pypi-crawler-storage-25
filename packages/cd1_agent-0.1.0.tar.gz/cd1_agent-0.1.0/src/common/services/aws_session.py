"""AssumeRole 기반 boto3 세션 팩토리.

CD1_AGENT_ROLE 환경변수가 설정되면 AssumeRole로 임시 자격증명을 획득하여 사용.
Role 이름만 넣으면 STS GetCallerIdentity로 Account ID를 조회하여 ARN을 자동 조립.
전체 ARN을 넣어도 그대로 사용.
미설정 시 기본 boto3 credential chain (환경변수 등) 사용.
botocore.RefreshableCredentials로 1시간 만료 전 자동 갱신.
"""

import logging
import os

import boto3
import botocore.session
from boto3 import Session
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

logger = logging.getLogger(__name__)

_ROLE_ARN: str | None = None  # lazy init
_REGION = "ap-northeast-2"
_SESSION_DURATION = 3600


def _get_role_arn() -> str:
    global _ROLE_ARN
    if _ROLE_ARN is None:
        role = os.getenv("CD1_AGENT_ROLE", "")
        logger.info("CD1_AGENT_ROLE 환경변수: '%s'", role)
        if role and not role.startswith("arn:"):
            try:
                account_id = boto3.client("sts", region_name=_REGION).get_caller_identity()["Account"]
                role = f"arn:aws:iam::{account_id}:role/{role}"
            except Exception as e:
                logger.error("STS GetCallerIdentity 실패 — ARN 조립 불가: %s", e)
                raise
        _ROLE_ARN = role
        if _ROLE_ARN:
            logger.info("AssumeRole 활성화: %s", _ROLE_ARN)
        else:
            logger.warning("CD1_AGENT_ROLE 미설정 — 기본 자격증명 사용")
    return _ROLE_ARN


def _refresh_credentials() -> dict:
    """STS AssumeRole 호출 → RefreshableCredentials가 만료 전 자동 호출."""
    sts = boto3.client("sts", region_name=_REGION)
    resp = sts.assume_role(
        RoleArn=_get_role_arn(),
        RoleSessionName="cd1-agent-session",
        DurationSeconds=_SESSION_DURATION,
    )
    creds = resp["Credentials"]
    logger.debug("AssumeRole 자격증명 갱신 완료")
    return {
        "access_key": creds["AccessKeyId"],
        "secret_key": creds["SecretAccessKey"],
        "token": creds["SessionToken"],
        "expiry_time": creds["Expiration"].isoformat(),
    }


def get_boto3_session(region: str = _REGION) -> Session:
    """AssumeRole 적용된 boto3.Session 반환."""
    if not _get_role_arn():
        return boto3.Session(region_name=region)

    bc_session = get_session()
    creds = RefreshableCredentials.create_from_metadata(
        metadata=_refresh_credentials(),
        refresh_using=_refresh_credentials,
        method="sts-assume-role",
    )
    bc_session._credentials = creds
    return Session(botocore_session=bc_session, region_name=region)


def get_boto3_client(service: str, region: str = _REGION, **kwargs):
    """AssumeRole 적용된 boto3 client 반환."""
    session = get_boto3_session(region)
    return session.client(service, **kwargs)


def get_botocore_session(region: str = _REGION) -> botocore.session.Session:
    """AssumeRole 적용된 botocore session 반환 (EKS bearer token용)."""
    if not _get_role_arn():
        return botocore.session.get_session()

    bc_session = get_session()
    creds = RefreshableCredentials.create_from_metadata(
        metadata=_refresh_credentials(),
        refresh_using=_refresh_credentials,
        method="sts-assume-role",
    )
    bc_session._credentials = creds
    return bc_session
