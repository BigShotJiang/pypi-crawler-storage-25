# Installation

## Requirements

- **Python 3.11+**

## Core library

```bash
pip install pystator
```

Includes **PyYAML** and **simpleeval** (for optional inline `expr:` guards when used from YAML). The core is fully **stateless**: `StateMachine`, `EntitySession`, guards, actions, and the orchestration pattern.

## Optional extras

| Extra | Purpose |
|-------|---------|
| `pystator[api]` | FastAPI REST API, SQLAlchemy + Alembic, DB drivers, JWT, **MkDocs** stack for `pystator docs serve` / `build` |
| `pystator[ui]` | Serve or develop the Next.js UI (FastAPI/uvicorn stack) |
| `pystator[worker]` | Background worker, Redis/Celery, queue processing |
| `pystator[collab]` | Socket.IO relay for real-time collaboration |
| `pystator[docs]` | MkDocs + Material + mkdocstrings + **mike** (also pulled in via `[api]` and `[dev]`) |
| `pystator[all]` | `api` + `worker` + `ui` + `collab` |
| `pystator[dev]` | Full runtime extras plus pytest, Ruff, mypy, pre-commit, Jupyter, build/twine |

```bash
pip install "pystator[api,ui]"   # API + UI
pip install "pystator[dev]"      # contributors
```

## Default local ports

Defined in `pystator.config.ports` (overridable via env / `pystator.cfg`):

| Service | Default port |
|---------|----------------|
| `pystator api` | **8004** |
| `pystator ui dev` / `serve` | **3004** |
| `pystator docs serve` | **5004** |

## Database (API / worker)

With `[api]` or `[worker]`, configure **`PYSTATOR_DATABASE_URL`** or `pystator.cfg` (see repo **`pystator.cfg.example`**). Initialize migrations:

```bash
pystator db upgrade
```

## Documentation CLI

With **`[docs]`** or **`[dev]`** (or **`[api]`**):

```bash
pystator docs serve    # http://127.0.0.1:5004 by default
pystator docs build    # static site in site/
```

## Next steps

- [Quick start](quickstart.md) — first FSM and `process()`
- [Concepts](../guides/concepts.md) — states, transitions, orchestrator
- [Configuration](../guides/configuration.md) — config file and environment
