# PyStator

<p align="center">
  <strong>Configuration-driven, stateless finite state machines for Python — YAML/JSON definitions, guards, actions, optional API, worker, and UI</strong>
</p>

<p align="center">
  <a href="https://pypi.org/project/pystator/"><img src="https://img.shields.io/pypi/v/pystator.svg" alt="PyPI version"></a>
  <a href="https://pypi.org/project/pystator/"><img src="https://img.shields.io/pypi/pyversions/pystator.svg" alt="Python versions"></a>
  <a href="https://github.com/optophi/pystator/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="License"></a>
  <a href="https://github.com/optophi/pystator/actions/workflows/test.yml"><img src="https://github.com/optophi/pystator/workflows/CI/badge.svg" alt="CI"></a>
</p>

---

**PyStator** is a library for defining **finite state machines** in declarative config (YAML or JSON), computing transitions from **current state + event + context**, and running **guards** and **actions**. The same model powers an optional **REST API**, **worker queue**, and **UI** when you install the corresponding extras.

## At a glance

| Area | What it is |
|------|------------|
| **Core** | Stateless `StateMachine` / builder, `process()`, hierarchical and parallel states |
| **EntitySession** | Per-entity wrapper: `send()`, snapshots, generated helpers |
| **Persistence** | Pluggable **state stores** (memory, Postgres, Redis, MongoDB, custom) |
| **Runtime** | **Schedulers** (asyncio, Redis, Celery), **worker** + `submit_event`, deployment guides |
| **Discovery** | Inferred FSM **candidates**, shadow-mode comparison, classification APIs |
| **Quality** | **Lint**, hooks, metrics, visualization (Mermaid, DOT, SCXML) |

See [Concepts](guides/concepts.md), [Architecture](guides/architecture.md), and the [API Reference](api/index.md).

## Key features

<div class="grid cards" markdown>

-   :material-chart-timeline:{ .lg .middle } **Declarative FSMs**

    ---

    Define states, transitions, guards, and actions in YAML or JSON. `StateMachineBuilder` and declarative `check:` / effects keep configs readable.

    [:octicons-arrow-right-24: Declarative features](guides/declarative-features.md)

-   :material-layers-triple:{ .lg .middle } **Hierarchical & parallel**

    ---

    Compound states, regions, and parallel execution patterns for real workflows.

    [:octicons-arrow-right-24: Concepts](guides/concepts.md)

-   :material-database:{ .lg .middle } **State stores**

    ---

    In-memory, PostgreSQL, Redis, MongoDB, or bring your own `StateStore` adapter.

    [:octicons-arrow-right-24: State stores](guides/state-stores.md)

-   :material-robot:{ .lg .middle } **Worker & schedulers**

    ---

    Queue-backed processing with `pystator worker`, delayed transitions, and scaling notes.

    [:octicons-arrow-right-24: Worker](guides/worker.md) · [Schedulers](guides/schedulers.md)

-   :material-api:{ .lg .middle } **REST API & UI**

    ---

    Optional HTTP API and UI on configurable ports; same FSM definitions end to end.

    [:octicons-arrow-right-24: Tutorial: API and UI](tutorials/api-and-ui.md)

-   :material-lightbulb-on:{ .lg .middle } **Discovery**

    ---

    Infer candidate machines from observations, compare in shadow mode, and classify state from data.

    [:octicons-arrow-right-24: Discovery guide](guides/discovery-inference.md)

</div>

## Quick example

### Load a machine and process an event

```python
from pathlib import Path
from pystator import StateMachineBuilder

machine = StateMachineBuilder.from_yaml(Path("order_fsm.yaml")).build()
ctx = machine.create_context(entity_id="ord-1")
result = machine.process(ctx, "submit")
print(result.new_state, result.effects)
```

### Installation

=== "Core"

    ```bash
    pip install pystator
    ```

=== "API, DB, migrations, docs CLI"

    ```bash
    pip install pystator[api]
    ```

=== "Worker + queue"

    ```bash
    pip install pystator[worker]
    ```

=== "Full stack (API + worker + UI)"

    ```bash
    pip install pystator[all]
    ```

Default local ports (see `pystator.config.ports`): API **8004**, UI **3004**, `pystator docs serve` **5004**. Details: [Installation](getting-started/installation.md).

## Architecture overview

```mermaid
flowchart LR
  subgraph Config["Config"]
    Y[YAML / JSON FSM]
  end
  subgraph Core["PyStator core"]
    SM[StateMachine]
    G[Guards & actions]
  end
  subgraph Optional["Optional extras"]
    API[REST API]
    W[Worker]
    UI[UI]
    ST[(State stores)]
  end
  Y --> SM
  SM --> G
  SM --> ST
  API --> SM
  W --> SM
  UI --> API
```

## Next steps

<div class="grid cards" markdown>

-   :material-rocket-launch:{ .lg .middle } **Get started**

    ---

    Install, first FSM, `process()`, EntitySession, and pointers to the API.

    [:octicons-arrow-right-24: Getting started](getting-started/quickstart.md)

-   :material-wrench:{ .lg .middle } **How-to guides**

    ---

    Architecture, persistence, workers, discovery, linting, and observability.

    [:octicons-arrow-right-24: How-To Guides](guides/index.md)

-   :material-school:{ .lg .middle } **Tutorials**

    ---

    Order workflow and API/UI walkthroughs.

    [:octicons-arrow-right-24: Tutorials](tutorials/index.md)

-   :material-api:{ .lg .middle } **API reference**

    ---

    Docstring-generated pages for public Python APIs.

    [:octicons-arrow-right-24: API Reference](api/index.md)

-   :material-github:{ .lg .middle } **Contribute**

    ---

    Contributing, publishing, and release workflow.

    [:octicons-arrow-right-24: Contributing](contributing.md)

</div>
