# Example notebooks

PyStator’s hands-on material is primarily **Python scripts plus YAML FSM definitions** in the repository [`examples/`](https://github.com/optophi/pystator/tree/main/examples) tree, documented on the [Examples & Notebooks](../examples-and-notebooks.md) overview page.

Jupyter notebooks are not bundled in this documentation site. For narrative walkthroughs, use the [Tutorials](../tutorials/index.md) (for example [Order workflow](../tutorials/order-workflow.md) and [API and UI](../tutorials/api-and-ui.md)).
