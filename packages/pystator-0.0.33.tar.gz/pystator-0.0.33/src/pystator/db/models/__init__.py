"""
SQLAlchemy models for PyStator FSM persistence.

Mirrors PyCharter's data model pattern: versioned, audited records.
- MachineModel: FSM definition (meta, states, transitions, error_policy) stored as config_json
  for full round-trip; name + version unique.
- EntityStateModel: Runtime state for each entity (entity_id -> current_state, context).
- TransitionHistoryModel: Audit log of all transition attempts.
- WorkerEventModel: Durable event queue for the worker service.
- EventLogModel: Append-only event log for replay and event sourcing.
- WebhookModel: Webhook subscriptions for alert notifications.
"""

from __future__ import annotations

from pystator.db.models.annotation import WorkspaceAnnotationModel
from pystator.db.models.entity_state import EntityStateModel
from pystator.db.models.event_log import EventLogModel
from pystator.db.models.machine import MachineModel
from pystator.db.models.transition_annotation import WorkspaceTransitionAnnotationModel
from pystator.db.models.transition_history import TransitionHistoryModel
from pystator.db.models.webhook import WebhookModel
from pystator.db.models.worker_apply_data_event import WorkerApplyDataEventModel
from pystator.db.models.worker_event import WorkerEventModel
from pystator.db.models.workspace_layout import WorkspaceLayoutModel

__all__ = [
    "EntityStateModel",
    "EventLogModel",
    "WorkspaceAnnotationModel",
    "WorkspaceLayoutModel",
    "WorkspaceTransitionAnnotationModel",
    "MachineModel",
    "TransitionHistoryModel",
    "WebhookModel",
    "WorkerApplyDataEventModel",
    "WorkerEventModel",
]
