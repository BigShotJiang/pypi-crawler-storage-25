"""Response models for PyStator API.

Centralizes all response body models used across API routes.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class LoginResponse(BaseModel):
    """Response from successful login."""

    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field("bearer", description="Token type")
    expires_in: int = Field(3600, description="Token lifetime in seconds")


class UserResponse(BaseModel):
    """Response for current user query."""

    username: str = Field(..., description="Username")
    role: str = Field("User", description="User role (Admin or User)")
    auth_disabled: bool = Field(False, description="Whether auth is disabled")


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


class DatabaseConfigResponse(BaseModel):
    """Response for database configuration info."""

    configured_url: str | None = Field(None, description="Configured DB URL (masked)")
    actual_url: str = Field(..., description="Actual DB URL in use")
    database_type: str = Field(..., description="Database type (SQLite, PostgreSQL)")
    is_default: bool = Field(..., description="Whether using default SQLite")
    machine_count: int = Field(..., description="Number of stored machines")
    message: str = Field(..., description="Human-readable status message")


class DatabaseTestResponse(BaseModel):
    """Response for database connection test."""

    success: bool = Field(..., description="Whether connection succeeded")
    message: str = Field(..., description="Result message")


class DiscoveryConfigResponse(BaseModel):
    """Response for discovery configuration info."""

    backend: str = Field(..., description="Configured discovery backend")
    database_url: str | None = Field(
        None, description="Configured discovery DB URL (masked)"
    )
    shadow_enabled: bool = Field(..., description="Whether shadow mode is enabled")
    min_edge_count: int = Field(..., description="Minimum edge count threshold")
    min_confidence: float = Field(..., description="Minimum confidence threshold")
    drift_alert_threshold: float = Field(
        ...,
        description="Candidate drift alert threshold (0-1)",
    )
    drift_severe_threshold: float = Field(
        ...,
        description="Candidate drift severe threshold (0-1)",
    )
    drift_min_sample: int = Field(
        ...,
        description="Minimum shadow sample count before drift tags are considered",
    )
    low_sample_threshold: int = Field(
        ...,
        description="Sample count below which candidate is tagged as low-sample",
    )


class DiscoveryDatabaseTestResponse(BaseModel):
    """Response for discovery backend connectivity test."""

    success: bool = Field(..., description="Whether backend connection succeeded")
    message: str = Field(..., description="Result message")


class DlqTestResponse(BaseModel):
    """Response for DLQ connection test."""

    success: bool = Field(..., description="Whether DLQ connection succeeded")
    message: str = Field(..., description="Result message")


class DlqStatsResponse(BaseModel):
    """Response for DLQ statistics."""

    total_messages: int = Field(..., description="Total rows in DLQ table")
    by_reason: dict[str, int | None] = Field(default_factory=dict)
    by_stage: dict[str, int | None] = Field(default_factory=dict)
    by_status: dict[str, int | None] = Field(default_factory=dict)


class WorkerDlqConfigResponse(BaseModel):
    """Worker DLQ settings as read from env / pystator.cfg (masked URL)."""

    dlq_enabled: bool = Field(..., description="Whether worker DLQ is enabled")
    dlq_database_url: str | None = Field(
        None, description="Configured DLQ database URL (masked) or None"
    )
    dlq_table_name: str = Field(..., description="DLQ table name")
    persistence: str = Field(
        ...,
        description="disabled, in_memory, or database",
    )


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


class EntityStateResponse(BaseModel):
    """Response for entity state queries."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Current state name")
    machine_name: str | None = Field(None, description="Machine name")
    machine_version: str | None = Field(None, description="Machine version")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")
    status: str = Field("active", description="Entity lifecycle status")
    workflow_status: str = Field(
        "active",
        description="FSM workflow outcome: active, complete, or failed",
    )
    is_terminal: bool | None = Field(
        None,
        description="Whether current_state is a terminal FSM state",
    )
    labels: dict[str, str] = Field(default_factory=dict, description="Entity labels")
    updated_at: datetime | None = Field(None, description="Last updated")
    created_at: datetime | None = Field(None, description="Created timestamp")
    archived_at: datetime | None = Field(None, description="Archived timestamp")
    deleted_at: datetime | None = Field(None, description="Deleted timestamp")


class CreateEntityResponse(BaseModel):
    """Response after creating an entity at initial state."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Initial state name")
    machine_name: str | None = Field(None, description="Machine name")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")
    updated_at: datetime | None = Field(None, description="Last updated")
    created_at: datetime | None = Field(None, description="Created timestamp")
    transition_id: str = Field(
        ...,
        description="Transition history record ID (bootstrap row; trigger __entity_created__)",
    )


class ProcessEntityEventResponse(BaseModel):
    """Response for processing an entity event."""

    success: bool = Field(..., description="Whether transition succeeded")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    actions: list[str] = Field(default_factory=list, description="Actions to execute")
    error_detail: FsmOutcomeError | None = Field(
        None,
        description="Structured error when success is False",
    )
    error: str | None = Field(
        None,
        description="Deprecated: human-readable message; use error_detail.message",
    )
    shadow_diff: dict[str, Any] | None = Field(
        None, description="Optional shadow comparison output"
    )
    transition_id: str | None = Field(None, description="Transition history record ID")


class TransitionHistoryResponse(BaseModel):
    """Response for transition history queries."""

    id: str = Field(..., description="History record ID")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    success: bool = Field(..., description="Whether transition succeeded")
    error_message: str | None = Field(None, description="Error message if failed")
    actions_executed: list[str] | None = Field(None, description="Executed actions")
    created_at: datetime = Field(..., description="Transition timestamp")
    duration_ms: int | None = Field(None, description="Processing duration in ms")


class EntityListResponse(BaseModel):
    """Response for listing entities."""

    entities: list[EntityStateResponse] = Field(
        default_factory=list, description="Entity records"
    )
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")
    next_cursor: str | None = Field(None, description="Cursor for next page")


class EntityLabelsResponse(BaseModel):
    """Response for entity label queries."""

    entity_id: str = Field(..., description="Entity identifier")
    labels: dict[str, str] = Field(default_factory=dict, description="Entity labels")


class TriggerInfo(BaseModel):
    """Information about an available trigger from a state."""

    trigger: str = Field(..., description="Trigger name")
    target_state: str = Field(..., description="Target state name")
    has_guard: bool = Field(False, description="Whether transition has guards")
    guard_description: str | None = Field(
        None, description="Guard description if available"
    )


class AvailableTriggersResponse(BaseModel):
    """Response for available triggers query."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Current state name")
    triggers: list[TriggerInfo] = Field(
        default_factory=list, description="Available triggers"
    )


class DryRunResponse(BaseModel):
    """Response for dry-run transition evaluation."""

    would_succeed: bool = Field(..., description="Whether the transition would succeed")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="Current state")
    target_state: str | None = Field(
        None, description="Target state if transition would succeed"
    )
    trigger: str = Field(..., description="Trigger evaluated")
    actions_that_would_execute: list[str] = Field(
        default_factory=list, description="Actions that would run"
    )
    error_detail: str | None = Field(
        None, description="Error message if transition would fail"
    )


class ApplyDataEnqueueResponse(BaseModel):
    """Response after enqueueing an apply-data update for worker processing."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str = Field(..., description="Machine name routed to")
    event_id: str = Field(..., description="Worker apply-data event ID")


class BulkCreateEntityResult(BaseModel):
    """Result for one entity in a bulk create."""

    entity_id: str = Field(..., description="Entity identifier")
    success: bool = Field(..., description="Whether creation succeeded")
    current_state: str | None = Field(None, description="Initial state if success")
    error: str | None = Field(None, description="Error message if failed")


class BulkCreateEntitiesResponse(BaseModel):
    """Response for bulk entity creation."""

    results: list[BulkCreateEntityResult] = Field(default_factory=list)
    total: int = Field(..., description="Total items processed")
    succeeded: int = Field(..., description="Items that succeeded")
    failed: int = Field(..., description="Items that failed")


class BulkProcessEventResult(BaseModel):
    """Result for one entity in bulk event processing."""

    entity_id: str = Field(..., description="Entity identifier")
    success: bool = Field(..., description="Whether transition succeeded")
    source_state: str | None = Field(None, description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    error: str | None = Field(None, description="Error message if failed")


class BulkProcessEventsResponse(BaseModel):
    """Response for bulk event processing."""

    trigger: str = Field(..., description="Trigger name processed")
    results: list[BulkProcessEventResult] = Field(default_factory=list)
    total: int = Field(..., description="Total items processed")
    succeeded: int = Field(..., description="Items that succeeded")
    failed: int = Field(..., description="Items that failed")


class HistoryStatsResponse(BaseModel):
    """Response for entity history statistics."""

    entity_id: str = Field(..., description="Entity identifier")
    total_transitions: int = Field(..., description="Total transition count")
    first_at: datetime | None = Field(None, description="Earliest transition timestamp")
    last_at: datetime | None = Field(None, description="Latest transition timestamp")
    success_count: int = Field(..., description="Successful transitions")
    failure_count: int = Field(..., description="Failed transitions")


class HistoryPurgeResponse(BaseModel):
    """Response for history purge operation."""

    entity_id: str = Field(..., description="Entity identifier")
    deleted_count: int = Field(..., description="Records deleted")
    remaining_count: int = Field(..., description="Records remaining")


class TransitionHistorySnapshotItem(BaseModel):
    """Single history record in a snapshot."""

    source_state: str = Field(..., description="State before")
    target_state: str | None = Field(None, description="State after")
    trigger: str = Field(..., description="Trigger")
    success: bool = Field(..., description="Whether succeeded")
    error_message: str | None = Field(None, description="Error if failed")
    actions_executed: list[str] | None = Field(None, description="Actions")
    created_at: datetime = Field(..., description="Timestamp")
    duration_ms: int | None = Field(None, description="Duration")


class EntitySnapshotResponse(BaseModel):
    """Full entity snapshot for export."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current state")
    context: dict[str, Any] = Field(default_factory=dict, description="Context")
    status: str = Field("active", description="Lifecycle status")
    labels: dict[str, str] = Field(default_factory=dict, description="Labels")
    history: list[TransitionHistorySnapshotItem] = Field(
        default_factory=list, description="Full history"
    )
    exported_at: datetime = Field(..., description="Export timestamp")


class ImportEntityResponse(BaseModel):
    """Response after importing an entity from snapshot."""

    entity_id: str = Field(..., description="Entity identifier")
    history_count: int = Field(..., description="History records imported")
    success: bool = Field(True, description="Whether import succeeded")


class TransitionHistoryListResponse(BaseModel):
    """Response for paginated history list."""

    items: list[TransitionHistoryResponse] = Field(default_factory=list)
    total: int = Field(..., description="Total count")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")
    next_cursor: str | None = Field(None, description="Cursor for next page")


# ---------------------------------------------------------------------------
# Observability
# ---------------------------------------------------------------------------


class ObservabilitySummaryResponse(BaseModel):
    """High-level operational summary for observability dashboard."""

    window_start: datetime = Field(..., description="Start of summary time window")
    window_end: datetime = Field(..., description="End of summary time window")
    active_entities: int = Field(
        ..., description="Count of active entity state records"
    )
    transitions_total: int = Field(
        ..., description="Total transition attempts in window"
    )
    transitions_failed: int = Field(
        ..., description="Failed transition attempts in window"
    )
    transition_failure_rate: float = Field(
        ..., description="Failed transitions / total transitions in window"
    )
    p95_transition_duration_ms: int | None = Field(
        None, description="P95 transition processing duration in milliseconds"
    )
    worker_pending: int = Field(..., description="Current pending worker events")
    worker_claimed: int = Field(..., description="Current claimed worker events")
    worker_failed: int = Field(..., description="Current failed worker events")
    worker_dead_letter: int = Field(
        ..., description="Current dead-letter worker events"
    )


class ObservabilityTransitionItem(BaseModel):
    """Single transition row for observability transition feed."""

    id: str = Field(..., description="Transition history record ID")
    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    success: bool = Field(..., description="Whether transition succeeded")
    error_message: str | None = Field(None, description="Error message if failed")
    actions_executed: list[str] | None = Field(None, description="Executed actions")
    duration_ms: int | None = Field(None, description="Processing duration in ms")
    created_at: datetime = Field(..., description="Transition timestamp")


class ObservabilityTransitionsResponse(BaseModel):
    """Paginated transition feed for observability."""

    items: list[ObservabilityTransitionItem] = Field(default_factory=list)
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")


class ObservabilityWorkerEventItem(BaseModel):
    """Single worker-event row for observability queue feed."""

    id: str = Field(..., description="Worker event ID")
    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Entity identifier")
    trigger: str = Field(..., description="Event trigger")
    status: str = Field(..., description="Worker event status")
    attempt: int = Field(..., description="Current attempt number")
    max_attempts: int = Field(..., description="Maximum attempts allowed")
    error_message: str | None = Field(None, description="Failure message")
    fires_at: datetime = Field(..., description="Scheduled fire time")
    claimed_by: str | None = Field(None, description="Worker identifier")
    claimed_at: datetime | None = Field(None, description="Claim timestamp")
    created_at: datetime | None = Field(None, description="Created timestamp")
    completed_at: datetime | None = Field(None, description="Completed timestamp")
    result_json: dict[str, Any] | None = Field(
        None, description="Optional processing result payload"
    )
    transition_history_id: str | None = Field(
        None, description="Correlated transition_history record ID when available"
    )


class ObservabilityWorkerEventsResponse(BaseModel):
    """Paginated worker-event feed for observability."""

    items: list[ObservabilityWorkerEventItem] = Field(default_factory=list)
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")


class StateOpsErrorTopItem(BaseModel):
    """Top failure reason for a state within a window."""

    error_type: str | None = Field(None, description="Error type (if available)")
    error_message: str | None = Field(None, description="Error message (if available)")
    count: int = Field(..., description="Occurrences for this error signature")


class StateOpsAgeBuckets(BaseModel):
    """Age bucket counts for entities in a state (seconds since last transition)."""

    le_5m: int = Field(0, description="Entities with age <= 5 minutes")
    le_30m: int = Field(0, description="Entities with age <= 30 minutes (and > 5m)")
    gt_30m: int = Field(0, description="Entities with age > 30 minutes")


class StateOpsMetricsItem(BaseModel):
    """Operational metrics for a single state in a machine."""

    state_name: str = Field(..., description="State name")
    entity_count: int = Field(..., description="Current entity count in this state")
    age_p95_seconds: int | None = Field(
        None, description="P95 age in seconds since last transition"
    )
    age_oldest_seconds: int | None = Field(
        None, description="Oldest entity age in seconds since last transition"
    )
    age_buckets: StateOpsAgeBuckets = Field(
        default_factory=StateOpsAgeBuckets,
        description="Bucketized entity ages for quick stuckness triage",
    )
    failed_transition_count: int = Field(
        0,
        description=(
            "Failed transitions in the window where source_state OR target_state matches this state"
        ),
    )
    top_error: StateOpsErrorTopItem | None = Field(
        None, description="Most common failure signature for this state (windowed)"
    )


class ObservabilityStateMetricsResponse(BaseModel):
    """Per-state operational metrics for a machine over a trailing window."""

    machine_name: str = Field(..., description="Machine name")
    window_start: datetime = Field(..., description="Start of metrics window (UTC)")
    window_end: datetime = Field(..., description="End of metrics window (UTC)")
    items: list[StateOpsMetricsItem] = Field(
        default_factory=list, description="Metrics by state"
    )


# ---------------------------------------------------------------------------
# Machines
# ---------------------------------------------------------------------------


class MachineResponse(BaseModel):
    """Response for a single stored FSM machine."""

    id: str = Field(..., description="Machine UUID")
    name: str = Field(..., description="Machine name from meta")
    version: str = Field(..., description="Machine version")
    description: str | None = Field(None, description="Machine description")
    strict_mode: bool = Field(True, description="Strict mode from meta")
    config: dict[str, Any] = Field(
        ...,
        description=("Full FSM config (meta, states, transitions, error_policy)"),
    )
    revision: int = Field(1, description="Optimistic concurrency revision")
    created_at: datetime | None = Field(None, description="Created timestamp")
    updated_at: datetime | None = Field(None, description="Updated timestamp")


class MachineListItem(BaseModel):
    """Summary item for machine list."""

    id: str = Field(..., description="Machine UUID")
    name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Machine version")
    namespace: str | None = Field(
        None, description="Optional namespace path from meta (slash-separated)"
    )
    description: str | None = Field(None, description="Machine description")
    created_at: datetime | None = Field(None, description="Created timestamp")
    updated_at: datetime | None = Field(None, description="Updated timestamp")


class MachineListResponse(BaseModel):
    """Response for list machines."""

    machines: list[MachineListItem] = Field(default_factory=list)
    count: int = Field(0, description="Total count")


class ActionRef(BaseModel):
    """Action reference with optional params."""

    name: str = Field(..., description="Action name")
    params: dict[str, Any] = Field(
        default_factory=dict, description="Optional parameters"
    )


class FsmOutcomeError(BaseModel):
    """Structured error when a transition does not succeed (HTTP / JSON)."""

    code: str = Field(
        ...,
        description="Machine-readable code (see ErrorCode in pystator.errors)",
    )
    type: str = Field(..., description="Exception class name")
    message: str = Field(..., description="Human-readable message")
    details: dict[str, Any] | None = Field(
        None,
        description="Engine metadata (e.g. guards) and optional error_context",
    )


class ProcessResponse(BaseModel):
    """Response for process endpoint."""

    success: bool = Field(..., description="Whether the transition succeeded")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(
        None, description="State after transition (if success)"
    )
    trigger: str = Field(..., description="Event trigger")
    actions_to_execute: list[ActionRef] = Field(
        default_factory=list,
        description="Transition actions to run after persistence",
    )
    on_exit_actions: list[ActionRef] = Field(
        default_factory=list,
        description="Source state exit actions",
    )
    on_enter_actions: list[ActionRef] = Field(
        default_factory=list,
        description="Target state entry actions",
    )
    error: FsmOutcomeError | None = Field(
        None,
        description="Structured error when success is False",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )


class DiscoveryObserveResponse(BaseModel):
    """Response for a recorded discovery observation."""

    accepted: bool = Field(..., description="Whether the observation was recorded")


class InferredEdgeResponse(BaseModel):
    """Inferred transition edge."""

    source_state: str = Field(..., description="Source state")
    destination_state: str = Field(..., description="Destination state")
    count: int = Field(..., description="Observed transition count")
    unique_entities: int = Field(..., description="Distinct entities seen on this edge")
    unique_sources: int = Field(..., description="Distinct observation sources")
    confidence: float = Field(..., description="Confidence in inferred edge")


class DiscoveryBuiltCandidateResponse(BaseModel):
    """Response for a built (persisted) inferred machine candidate."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Candidate version")
    candidate_sequence: int = Field(
        ...,
        ge=0,
        description=(
            "Per-machine monotonic display index (1, 2, 3, …); version remains canonical"
        ),
    )
    status: str = Field(..., description="Candidate status")
    config: dict[str, Any] = Field(..., description="Inferred machine config")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Metadata")
    edges: list[InferredEdgeResponse] = Field(
        default_factory=list, description="Inferred edge diagnostics"
    )


class DiscoveryPreviewResponse(BaseModel):
    """Response for discovery preview inference."""

    machine_name: str = Field(..., description="Machine name")
    mode: str = Field(..., description="Preview mode")
    entity_ids_used: list[str] = Field(
        default_factory=list, description="Entity IDs included in preview scope"
    )
    observation_count: int = Field(
        ..., description="Observation count in preview scope"
    )
    edges: list[InferredEdgeResponse] = Field(
        default_factory=list,
        description="Inferred edge diagnostics for preview scope",
    )
    selected_edges: list[InferredEdgeResponse] = Field(
        default_factory=list,
        description="Edges selected by threshold defaults for preview scope",
    )


class DiscoveryEntityListResponse(BaseModel):
    """Distinct entity IDs observed for a machine."""

    machine_name: str = Field(..., description="Machine name")
    entity_ids: list[str] = Field(
        default_factory=list, description="Distinct observed entity identifiers"
    )


class DiscoveryEntityDeleteResponse(BaseModel):
    """Delete all discovery observations for one entity in a machine."""

    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Entity id removed")
    deleted_count: int = Field(..., ge=0, description="Number of observations deleted")


class DiscoveryDraftResponse(BaseModel):
    """Discovery draft: entity scope and settings before build."""

    id: str = Field(..., description="Draft id")
    machine_name: str = Field(..., description="Discovery machine name")
    title: str | None = Field(None, description="Optional label")
    selected_entity_ids: list[str] = Field(
        default_factory=list,
        description="Entity IDs whose observations are used for preview/build",
    )
    mode: str = Field("inference", description="inference or manual")
    min_edge_count: int = Field(2, ge=1)
    min_confidence: float = Field(0.5, ge=0.0, le=1.0)
    manual_edge_selection: list[dict[str, str]] = Field(
        default_factory=list,
        description="For manual mode: source_state/destination_state pairs",
    )
    created_at: datetime = Field(..., description="Created time")
    updated_at: datetime = Field(..., description="Last update time")
    last_built_version: str | None = Field(
        None, description="Version string of last build from this draft, if any"
    )


class DiscoveryDraftMachineCreateResponse(BaseModel):
    """Response for creating a new draft discovery machine namespace."""

    machine_name: str = Field(..., description="Generated draft machine name")
    draft: DiscoveryDraftResponse = Field(
        ..., description="Initial draft scope record for this draft machine"
    )


class DiscoveryBuiltCandidateSummaryItem(BaseModel):
    """One summary row for a built (persisted) candidate version."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Candidate version")
    candidate_sequence: int = Field(
        ...,
        ge=0,
        description="Per-machine monotonic display index (1, 2, 3, …)",
    )
    status: str = Field(..., description="Candidate status")
    created_at: datetime = Field(..., description="When the candidate was saved")
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Inference metadata (counts, thresholds, …)"
    )
    observation_count_at_build: int = Field(
        0,
        description=(
            "Observation count snapshot used when this candidate was built "
            "(from candidate metadata)"
        ),
    )
    shadow_diff_count_recent: int = Field(
        0,
        description=(
            "Count of recent shadow diff rows for this candidate version "
            "(candidate-version scoped)"
        ),
    )
    drift_rate_recent: float = Field(
        0.0,
        description=(
            "Fraction of recent shadow rows for this version where differs=true "
            "(0.0 when shadow_diff_count_recent is 0)"
        ),
    )
    build_mode: str | None = Field(
        None, description="Build mode from candidate metadata (e.g., inference/manual)"
    )


class DiscoveryMachineDraftsResponse(BaseModel):
    """Drafts and built candidates for one discovery machine."""

    machine_name: str = Field(..., description="Machine name")
    drafts: list[DiscoveryDraftResponse] = Field(
        default_factory=list,
        description="Drafts (newest updated_at first)",
    )
    built_candidates: list[DiscoveryBuiltCandidateSummaryItem] = Field(
        default_factory=list, description="Built candidates newest-first"
    )


class DiscoveryFleetMachineItem(BaseModel):
    """One machine row in the discovery fleet index."""

    machine_name: str = Field(..., description="Machine name")
    last_observation_at: datetime | None = Field(
        None, description="Latest observation timestamp for this machine, if any"
    )
    observation_count: int = Field(
        0, description="Total rows in discovery_observations for this machine"
    )
    candidate_count: int = Field(
        0, description="Number of stored candidate versions for this machine"
    )
    latest_candidate_version: str | None = Field(
        None, description="Version string of the newest candidate by created_at"
    )
    latest_candidate_created_at: datetime | None = Field(
        None, description="created_at of the newest candidate"
    )
    shadow_diff_count_recent: int = Field(
        ...,
        description=(
            "Count of shadow diffs in the recent window: the latest 200 rows "
            "per machine by recorded_at (newest first)"
        ),
    )
    drift_rate_recent: float = Field(
        ...,
        description=(
            "Fraction of rows in that same window where differs=true "
            "(0.0 when shadow_diff_count_recent is 0)"
        ),
    )


class DiscoveryFleetListResponse(BaseModel):
    """Paginated discovery fleet index."""

    items: list[DiscoveryFleetMachineItem] = Field(default_factory=list)
    total: int = Field(..., description="Total rows matching query before pagination")
    limit: int = Field(..., description="Requested page size")
    offset: int = Field(..., description="Requested offset")


class DiscoveryShadowDiffResponse(BaseModel):
    """Response item for shadow comparison diagnostics."""

    machine_name: str = Field(..., description="Machine name")
    source_state: str = Field(..., description="Source state")
    trigger: str = Field(..., description="Trigger used")
    active_success: bool = Field(..., description="Active machine success result")
    active_target_state: str | None = Field(None, description="Active target state")
    candidate_success: bool = Field(..., description="Candidate machine success result")
    candidate_target_state: str | None = Field(
        None, description="Candidate target state"
    )
    differs: bool = Field(..., description="Whether active vs candidate differ")
    reason: str | None = Field(None, description="Difference reason")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Extra metadata")

    model_config = {
        "json_schema_extra": {
            "example": {
                "success": True,
                "source_state": "OPEN",
                "target_state": "FILLED",
                "trigger": "fill",
                "actions_to_execute": [{"name": "update_positions"}],
                "on_exit_actions": [],
                "on_enter_actions": [],
                "error": None,
                "metadata": {},
            }
        }
    }


# ---------------------------------------------------------------------------
# Workspace annotations
# ---------------------------------------------------------------------------


class WorkspaceAnnotationItem(BaseModel):
    state_name: str = Field(..., description="Anchored state name")
    body_markdown: str = Field("", description="Annotation body (markdown)")
    updated_at: datetime | None = Field(None, description="Last update timestamp")


class WorkspaceAnnotationsListResponse(BaseModel):
    machine_name: str = Field(..., description="Machine name")
    machine_version: str = Field(..., description="Machine version")
    items: list[WorkspaceAnnotationItem] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Workspace layouts
# ---------------------------------------------------------------------------


class WorkspaceLayoutPosition(BaseModel):
    """Single state position in the workspace diagram."""

    x: float = Field(..., description="X coordinate")
    y: float = Field(..., description="Y coordinate")


class WorkspaceLayoutsListResponse(BaseModel):
    """All positions for a given machine version."""

    machine_name: str = Field(..., description="Machine name")
    machine_version: str = Field(..., description="Machine version")
    positions: dict[str, WorkspaceLayoutPosition] = Field(
        default_factory=dict,
        description="Map of state_name to {x, y}",
    )


class MachineInfo(BaseModel):
    """Machine metadata from validated config."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Machine version")
    state_names: list[str] = Field(..., description="State names")
    trigger_names: list[str] = Field(..., description="Trigger names")
    terminal_states: list[str] = Field(..., description="Terminal state names")


class ValidateResponse(BaseModel):
    """Response for validate endpoint."""

    valid: bool = Field(..., description="Whether the config is valid")
    errors: list[str] = Field(
        default_factory=list, description="Validation errors if invalid"
    )
    info: MachineInfo | None = Field(
        None,
        description="Machine info if valid",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "valid": True,
                "errors": [],
                "info": {
                    "machine_name": "order",
                    "version": "1.0",
                    "state_names": ["OPEN", "FILLED"],
                    "trigger_names": ["fill"],
                    "terminal_states": ["FILLED"],
                },
            }
        }
    }


# ---------------------------------------------------------------------------
# Analytics
# ---------------------------------------------------------------------------


class StateDistributionItem(BaseModel):
    """Single state distribution entry."""

    state: str = Field(..., description="State name")
    count: int = Field(..., description="Entity count in this state")
    percentage: float = Field(..., description="Percentage of total entities")


class StatusDistribution(BaseModel):
    """Entity status breakdown."""

    active: int = Field(0, description="Active entities")
    archived: int = Field(0, description="Archived entities")
    deleted: int = Field(0, description="Deleted entities")


class MachineDistributionItem(BaseModel):
    """Single machine distribution entry."""

    machine_name: str = Field(..., description="Machine name")
    count: int = Field(..., description="Entity count for this machine")


class FailingEntityItem(BaseModel):
    """Top failing entity entry."""

    entity_id: str = Field(..., description="Entity identifier")
    failure_count: int = Field(..., description="Failed transitions in window")
    last_failure_at: str = Field(..., description="Timestamp of last failure")


class EntityHealthResponse(BaseModel):
    """Entity-centric health analytics."""

    state_distribution: list[StateDistributionItem] = Field(default_factory=list)
    status_distribution: StatusDistribution = Field(default_factory=StatusDistribution)
    machine_distribution: list[MachineDistributionItem] = Field(default_factory=list)
    top_failing_entities: list[FailingEntityItem] = Field(default_factory=list)
    terminal_rate: float = Field(0.0, description="Percentage of terminal entities")
    total_entities: int = Field(0, description="Total entity count")


class TimeBucketItem(BaseModel):
    """Single time bucket for transition analytics."""

    bucket_start: str = Field(..., description="Bucket start ISO timestamp")
    bucket_end: str = Field(..., description="Bucket end ISO timestamp")
    total: int = Field(0, description="Total transitions in bucket")
    failed: int = Field(0, description="Failed transitions in bucket")
    failure_rate: float = Field(0.0, description="Failure rate in bucket")


class DurationPercentiles(BaseModel):
    """Transition duration percentiles."""

    p50: int | None = Field(None, description="50th percentile in ms")
    p75: int | None = Field(None, description="75th percentile in ms")
    p95: int | None = Field(None, description="95th percentile in ms")
    p99: int | None = Field(None, description="99th percentile in ms")


class FailingTriggerItem(BaseModel):
    """Top failing trigger entry."""

    trigger: str = Field(..., description="Trigger name")
    total: int = Field(0, description="Total transitions with this trigger")
    failed: int = Field(0, description="Failed transitions with this trigger")
    failure_rate: float = Field(0.0, description="Failure rate for this trigger")


class FailingStateItem(BaseModel):
    """Top failing source state entry."""

    state: str = Field(..., description="Source state name")
    total: int = Field(0, description="Total transitions from this state")
    failed: int = Field(0, description="Failed transitions from this state")
    failure_rate: float = Field(0.0, description="Failure rate from this state")


class VolumeTrendItem(BaseModel):
    """Single volume trend bucket."""

    bucket_start: str = Field(..., description="Bucket start ISO timestamp")
    count: int = Field(0, description="Transition count in bucket")


class TransitionAnalyticsResponse(BaseModel):
    """Transition analytics for observability dashboard."""

    time_buckets: list[TimeBucketItem] = Field(default_factory=list)
    duration_percentiles: DurationPercentiles = Field(
        default_factory=DurationPercentiles
    )
    top_failing_triggers: list[FailingTriggerItem] = Field(default_factory=list)
    top_failing_states: list[FailingStateItem] = Field(default_factory=list)
    volume_trend: list[VolumeTrendItem] = Field(default_factory=list)


class TimelineStep(BaseModel):
    """Single step in an entity journey timeline."""

    state: str = Field(..., description="State entered")
    entered_at: str = Field(..., description="When entity entered this state")
    exited_at: str | None = Field(
        None, description="When entity left (null if current)"
    )
    dwell_ms: int | None = Field(None, description="Milliseconds in this state")
    trigger_in: str | None = Field(None, description="Trigger that caused entry")
    trigger_out: str | None = Field(None, description="Trigger that caused exit")
    success: bool = Field(True, description="Whether entry transition succeeded")


class EntityTimelineResponse(BaseModel):
    """Entity journey timeline."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current entity state")
    steps: list[TimelineStep] = Field(default_factory=list)
    total_dwell_ms: int = Field(0, description="Total dwell time across all states")
    states_visited: int = Field(0, description="Count of unique states visited")


# ---------------------------------------------------------------------------
# Per-Entity Metrics
# ---------------------------------------------------------------------------


class ErrorPatternItem(BaseModel):
    """Single error pattern entry for entity error breakdown."""

    error_type: str | None = Field(None, description="Error type classification")
    trigger: str = Field(..., description="Trigger that caused the failure")
    source_state: str = Field(..., description="State when failure occurred")
    count: int = Field(..., description="Number of occurrences")
    last_occurred: str = Field(..., description="ISO timestamp of most recent")


class DwellByStateItem(BaseModel):
    """Dwell time statistics for a single state."""

    state: str = Field(..., description="State name")
    avg_ms: int = Field(..., description="Average dwell time in ms")
    min_ms: int = Field(..., description="Minimum dwell time in ms")
    max_ms: int = Field(..., description="Maximum dwell time in ms")
    visit_count: int = Field(..., description="Number of times state was visited")


class FleetComparison(BaseModel):
    """Entity vs fleet performance comparison."""

    entity_failure_rate: float = Field(..., description="This entity's failure rate")
    fleet_failure_rate: float = Field(..., description="Fleet-wide failure rate")
    entity_avg_latency_ms: int | None = Field(
        None, description="This entity's avg latency"
    )
    fleet_avg_latency_ms: int | None = Field(None, description="Fleet-wide avg latency")
    latency_percentile_rank: float | None = Field(
        None, description="Percentile rank 0-100, higher=faster"
    )


class VelocityPoint(BaseModel):
    """Single point in the velocity sparkline."""

    timestamp: str = Field(..., description="ISO timestamp of transition")
    duration_ms: int = Field(..., description="Transition duration in ms")


class EntityMetricsResponse(BaseModel):
    """Comprehensive per-entity metrics."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")

    # P0 — Health
    health_score: int = Field(..., description="Composite health score 0-100")
    health_status: str = Field(
        ..., description="healthy (>=80), warning (>=50), critical (<50)"
    )
    staleness_seconds: int | None = Field(
        None, description="Seconds since last transition"
    )
    staleness_label: str = Field(..., description="Human-readable staleness")

    # P0 — Error breakdown
    error_patterns: list[ErrorPatternItem] = Field(default_factory=list)
    recent_failure_rate: float = Field(
        0.0, description="Failure rate of last 20 transitions"
    )

    # P1 — Performance
    latency_percentiles: DurationPercentiles = Field(
        default_factory=DurationPercentiles
    )
    dwell_by_state: list[DwellByStateItem] = Field(default_factory=list)

    # P1 — Stuck detection
    is_potentially_stuck: bool = Field(False, description="Entity appears stuck")
    stuck_state: str | None = Field(None, description="State entity may be stuck in")
    stuck_current_dwell_ms: int | None = Field(
        None, description="Current dwell in stuck state"
    )
    stuck_avg_dwell_ms: int | None = Field(
        None, description="Average dwell for stuck state"
    )

    # P2 — Behavioral
    state_revisits: dict[str, int] = Field(
        default_factory=dict, description="States visited >1 time"
    )
    has_cycles: bool = Field(False, description="Whether entity revisited any state")
    fleet_comparison: FleetComparison | None = Field(
        None, description="Fleet comparison metrics"
    )

    # P3 — Trend
    velocity_points: list[VelocityPoint] = Field(default_factory=list)
