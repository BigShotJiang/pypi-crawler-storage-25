"""
PyStator API — FastAPI application.

REST API for FSM operations using PyStator.

Usage:
    # Development server
    uvicorn pystator.api.main:app --reload

    # Production server
    uvicorn pystator.api.main:app --host 0.0.0.0 --port 8004 --workers 4
"""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pystator import __version__ as pystator_version
from pystator.api.dependencies.auth import get_current_user
from pystator.api.routes.v1 import (
    auth,
    catalog,
    discovery,
    docs,
    entities,
    entities_bulk,
    events,
    machines,
    observability,
    process,
    settings,
    templates,
    webhooks,
    workspace_annotations,
    workspace_layouts,
    workspace_transition_annotations,
)
from pystator.config.ports import API_PORT, UI_PORT
from pystator.events import ChangeBus

logger = logging.getLogger(__name__)

API_VERSION = "v1"
API_PREFIX = f"/api/{API_VERSION}"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager for FastAPI application."""
    app.state.change_bus = ChangeBus()
    yield


def create_application() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title="PyStator API",
        description="REST API for PyStator FSM operations",
        version=pystator_version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # CORS
    cors_origins_env = os.getenv("CORS_ORIGINS", "").strip()
    cors_origins = (
        [o.strip() for o in cors_origins_env.split(",") if o.strip()]
        if cors_origins_env
        else []
    )
    is_production = os.getenv("ENVIRONMENT") == "production"
    if not cors_origins and not is_production:
        cors_origins = [
            "http://localhost:3000",
            "http://localhost:3001",
            f"http://localhost:{UI_PORT}",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:3001",
            f"http://127.0.0.1:{UI_PORT}",
        ]
    use_credentials = bool(cors_origins and "*" not in cors_origins)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins if cors_origins else ["*"],
        allow_credentials=use_credentials,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=["*"],
    )

    # Auth router (login/logout/me public; /auth/me uses Depends in route)
    app.include_router(auth.router, prefix=API_PREFIX, tags=["Auth"])

    # Protected routers: require valid Bearer when auth enabled
    auth_dep = [Depends(get_current_user)]
    app.include_router(
        workspace_annotations.router,
        prefix=API_PREFIX,
        tags=["Annotations"],
        dependencies=auth_dep,
    )
    app.include_router(
        workspace_transition_annotations.router,
        prefix=API_PREFIX,
        tags=["Annotations"],
        dependencies=auth_dep,
    )
    app.include_router(
        workspace_layouts.router,
        prefix=API_PREFIX,
        tags=["Layouts"],
        dependencies=auth_dep,
    )
    app.include_router(
        discovery.router,
        prefix=API_PREFIX,
        tags=["Discovery"],
        dependencies=auth_dep,
    )
    app.include_router(
        process.router,
        prefix=API_PREFIX,
        tags=["Process"],
        dependencies=auth_dep,
    )
    app.include_router(
        machines.router,
        prefix=API_PREFIX,
        tags=["Machines"],
        dependencies=auth_dep,
    )
    app.include_router(
        settings.public_router,
        prefix=API_PREFIX,
        tags=["Settings"],
    )
    app.include_router(
        settings.router,
        prefix=API_PREFIX,
        tags=["Settings"],
        dependencies=auth_dep,
    )
    app.include_router(
        templates.router,
        prefix=API_PREFIX,
        tags=["Templates"],
        dependencies=auth_dep,
    )
    # Bulk entity routes MUST be registered before entities router
    # to avoid /{entity_id}/create matching "bulk" as entity_id.
    app.include_router(
        entities_bulk.router,
        prefix=API_PREFIX,
        tags=["Entities"],
        dependencies=auth_dep,
    )
    app.include_router(
        entities.router,
        prefix=API_PREFIX,
        tags=["Entities"],
        dependencies=auth_dep,
    )
    app.include_router(
        observability.router,
        prefix=API_PREFIX,
        tags=["Observability"],
        dependencies=auth_dep,
    )
    app.include_router(
        webhooks.router,
        prefix=API_PREFIX,
        tags=["Webhooks"],
        dependencies=auth_dep,
    )
    # Catalog: no auth so UI can load built-in info without token
    app.include_router(
        catalog.router,
        prefix=API_PREFIX,
        tags=["Catalog"],
    )
    # Events SSE stream: no auth so UI can subscribe without token
    app.include_router(
        events.router,
        prefix=API_PREFIX,
        tags=["Events"],
    )
    # Docs (playground-routes): no auth so UI can load route list without token
    app.include_router(docs.router, prefix=API_PREFIX)

    # Root
    @app.get("/", summary="API Information", tags=["General"])
    async def root() -> dict:
        return {
            "name": "PyStator API",
            "version": pystator_version,
            "api_version": API_VERSION,
            "docs": "/docs",
            "redoc": "/redoc",
        }

    # Health
    @app.get("/health", summary="Health Check", tags=["General"])
    async def health_check() -> dict:
        return {"status": "healthy", "version": pystator_version}

    # Validation error handler
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        def serialize_error(error: dict) -> dict:
            serialized = {}
            for key, value in error.items():
                if isinstance(value, Exception):
                    serialized[key] = str(value)
                elif isinstance(value, dict):
                    serialized[key] = serialize_error(value)
                elif isinstance(value, (list, tuple)):
                    serialized[key] = [
                        (
                            serialize_error(item)
                            if isinstance(item, dict)
                            else (str(item) if isinstance(item, Exception) else item)
                        )
                        for item in value
                    ]
                else:
                    serialized[key] = value
            return serialized

        errors = [serialize_error(err) for err in exc.errors()]
        return JSONResponse(
            status_code=422,
            content={"error": "Validation error", "details": errors},
        )

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        import logging

        logger = logging.getLogger(__name__)
        logger.error("Unhandled exception: %s", exc, exc_info=True)
        is_development = os.getenv("ENVIRONMENT") == "development"
        error_detail: dict = {"error": "Internal server error"}
        if is_development:
            error_detail["message"] = str(exc)
            error_detail["type"] = type(exc).__name__
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=error_detail,
        )

    # OpenAPI schema error handling (Pydantic v2 unhashable workaround)
    original_openapi = app.openapi

    def openapi_with_error_handling():
        try:
            return original_openapi()
        except TypeError as e:
            if "unhashable type" in str(e):
                import logging

                logging.getLogger(__name__).warning(
                    "OpenAPI schema generation issue: %s. Returning minimal schema.", e
                )
                return {
                    "openapi": "3.1.0",
                    "info": {
                        "title": app.title,
                        "version": app.version,
                        "description": app.description,
                    },
                    "paths": {},
                    "components": {"schemas": {}},
                }
            raise

    app.openapi = openapi_with_error_handling

    # Optional: mount collaboration relay if installed
    try:
        from pystator.collab import create_collab_app

        collab_app = create_collab_app()
        app.mount("/collab", collab_app)
        logger.info("Collaboration module mounted at /collab")
    except ImportError:
        logger.debug(
            "Collaboration module not installed (pip install pystator[collab])"
        )

    return app


app = create_application()


def main() -> None:
    """Entry point for running the API server."""
    from pathlib import Path

    import uvicorn

    pkg_root = Path(__file__).resolve().parent.parent
    reload_dirs = [
        str(d)
        for d in sorted(pkg_root.iterdir())
        if d.is_dir()
        and d.name != "ui"
        and not d.name.startswith("__")
        and not d.name.startswith(".")
    ]

    uvicorn.run(
        "pystator.api.main:app",
        host="0.0.0.0",
        port=API_PORT,
        reload=True,
        reload_dirs=reload_dirs,
    )


if __name__ == "__main__":
    main()
