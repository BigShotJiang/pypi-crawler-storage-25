'use client'

import { useCallback, useEffect } from 'react'
import { CollabSocket, getRoomFromUrl, buildRoomLink } from '@/lib/collab'
import type { CollabMessage, Collaborator, RoomInfo } from '@/lib/collab/types'
import { getApiBaseUrl, getSettings } from '@/lib/settings'
import { useCollabStore } from '@/stores/collab'
import { useWorkspaceStore } from '@/stores/workspace'
import { useToastStore } from '@/stores/toast'
import type { FSMConfig } from '@/lib/types/fsm'

/** Singleton collab socket shared across hook instances. */
let globalSocket: CollabSocket | null = null

/**
 * Tracks the configRevision produced by the most recent remote update.
 * Module-level so ALL useCollab() instances share the same guard,
 * preventing the broadcast-echo loop when multiple hook instances exist.
 */
let _remoteRevision = 0

/**
 * Module-level handler for note-related collab messages.
 * Set from the workspace page so incoming note changes update the local note state.
 */
let _noteMessageHandler: ((msg: CollabMessage) => void) | null = null

export function setCollabNoteHandler(handler: ((msg: CollabMessage) => void) | null) {
  _noteMessageHandler = handler
}

/**
 * Module-level handler for layout position updates from collaborators.
 * Set from the workspace page so incoming position changes update the diagram.
 */
let _layoutPositionHandler: ((positions: Record<string, { x: number; y: number }>) => void) | null = null

export function setCollabLayoutHandler(handler: ((positions: Record<string, { x: number; y: number }>) => void) | null) {
  _layoutPositionHandler = handler
}

/** Broadcast a message to peers without needing the hook. */
export function collabBroadcast(msg: CollabMessage) {
  if (globalSocket?.connected) {
    void globalSocket.broadcast(msg)
  }
}

/**
 * Connects the CollabSocket to the workspace and collab stores.
 *
 * Provides actions to start, join, and disconnect from a collaboration
 * session, plus a helper to broadcast config changes to peers.
 */
export function useCollab() {

  const setActive = useCollabStore((s) => s.setActive)
  const setRoomInfo = useCollabStore((s) => s.setRoomInfo)
  const setCollaborators = useCollabStore((s) => s.setCollaborators)
  const setConnectionStatus = useCollabStore((s) => s.setConnectionStatus)
  const reset = useCollabStore((s) => s.reset)

  const configRevision = useWorkspaceStore((s) => s.configRevision)
  const setConfig = useWorkspaceStore((s) => s.setConfig)

  const toastSuccess = useToastStore((s) => s.success)
  const toastError = useToastStore((s) => s.error)

  /** Derive the collab server URL.
   *
   * Socket.IO must connect directly to the API server (it cannot
   * go through the Next.js rewrite proxy). Use the same API URL
   * that fetchApi uses — but when the proxy returns empty string,
   * fall back to the settings URL which has the actual host:port.
   */
  const getServerUrl = useCallback(() => {
    if (typeof window === 'undefined') return ''
    const base = getApiBaseUrl()
    if (base) return base
    // Proxy mode (getApiBaseUrl returns ''). Socket.IO needs the
    // real server URL, so read it from user settings.
    const settings = getSettings()
    return settings.apiServer.url || window.location.origin
  }, [])

  /** Handle an incoming decrypted collaboration message. */
  const handleMessage = useCallback(
    (message: CollabMessage) => {
      console.log('[collab] received message:', message.type, message.payload ? '(has payload)' : '(no payload)')
      if (message.type === 'CONFIG_INIT' || message.type === 'CONFIG_UPDATE') {
        const raw = message.payload as (FSMConfig & { _layoutPositions?: Record<string, { x: number; y: number }> }) | null
        if (raw) {
          // Extract layout positions before applying config
          const layoutPositions = raw._layoutPositions
          console.log('[collab] _layoutPositions in payload:', layoutPositions ?? 'none')
          console.log('[collab] _layoutPositionHandler set:', !!_layoutPositionHandler)
          if (layoutPositions && _layoutPositionHandler) {
            _layoutPositionHandler(layoutPositions)
          }
          // Strip _layoutPositions from config before storing
          const { _layoutPositions: _, ...remoteConfig } = raw
          setConfig(remoteConfig as FSMConfig, { replaceHistory: true })
          _remoteRevision = useWorkspaceStore.getState().configRevision
        }
      }

      if (message.type.startsWith('NOTE_') && _noteMessageHandler) {
        _noteMessageHandler(message)
      }

      if (message.type === 'CURSOR_LOCATION' || message.type === 'IDLE_STATUS') {
        const payload = message.payload as Partial<Collaborator> & {
          socketId?: string
        }
        if (globalSocket?.presence && payload.socketId) {
          globalSocket.presence.update(payload.socketId, payload)
          setCollaborators(globalSocket.presence.getAll())
        }
      }
    },
    [setConfig, setCollaborators],
  )

  /** Sync the collaborator list from the presence manager. */
  const syncCollaborators = useCallback(() => {
    if (globalSocket?.presence) {
      setCollaborators(globalSocket.presence.getAll())
    }
  }, [setCollaborators])

  /** Start a new collaboration session and update the URL hash. */
  const startSession = useCallback(async () => {
    if (globalSocket) {
      return
    }

    const serverUrl = getServerUrl()

    const socket = new CollabSocket()
    globalSocket = socket

    setConnectionStatus('connecting')

    try {
      const roomInfo = await socket.startSession(serverUrl, {
        onMessage: handleMessage,
        onCollaboratorsChange: () => syncCollaborators(),
        onFirstInRoom: () => {
          const currentConfig = useWorkspaceStore.getState().config
          void socket.broadcast({ type: 'CONFIG_INIT', payload: currentConfig })
        },
        onNewUser: () => {
          const currentConfig = useWorkspaceStore.getState().config
          void socket.broadcast({ type: 'CONFIG_INIT', payload: currentConfig })
        },
      })

      window.location.hash = buildRoomLink(roomInfo.roomId, roomInfo.roomKey)

      setRoomInfo(roomInfo)
      setActive(true)
      setConnectionStatus('connected')
      toastSuccess('Collaboration session started')
    } catch (err: unknown) {
      setConnectionStatus('disconnected')
      toastError('Failed to start collaboration session')
    }
  }, [
    getServerUrl,
    handleMessage,
    syncCollaborators,
    setRoomInfo,
    setActive,
    setConnectionStatus,
    toastSuccess,
    toastError,
  ])

  /** Join an existing session using room info (typically parsed from URL). */
  const joinSession = useCallback(
    (roomInfo: RoomInfo) => {
      if (globalSocket) {
        return
      }

      const serverUrl = getServerUrl()

      const socket = new CollabSocket()
      globalSocket = socket

      setConnectionStatus('connecting')

      try {
        socket.joinSession(serverUrl, roomInfo, {
          onMessage: handleMessage,
          onCollaboratorsChange: () => syncCollaborators(),
          onFirstInRoom: () => {
            const currentConfig = useWorkspaceStore.getState().config
            void socket.broadcast({ type: 'CONFIG_INIT', payload: currentConfig })
          },
          onNewUser: () => {
            const currentConfig = useWorkspaceStore.getState().config
            void socket.broadcast({ type: 'CONFIG_INIT', payload: currentConfig })
          },
        })

        setRoomInfo(roomInfo)
        setActive(true)
        setConnectionStatus('connected')
      } catch (err: unknown) {
        globalSocket = null
        setConnectionStatus('disconnected')
        toastError('Failed to join collaboration session')
      }
    },
    [
      getServerUrl,
      handleMessage,
      syncCollaborators,
      setRoomInfo,
      setActive,
      setConnectionStatus,
      toastError,
    ],
  )

  /** Disconnect from the current session and clean up URL hash. */
  const disconnect = useCallback(() => {
    globalSocket?.disconnect()
    globalSocket = null
    _remoteRevision = 0

    if (typeof window !== 'undefined') {
      history.replaceState(
        null,
        '',
        window.location.pathname + window.location.search,
      )
    }

    reset()
    toastSuccess('Left collaboration session')
  }, [reset, toastSuccess])

  /** Broadcast a config update to all connected peers. */
  const broadcastConfig = useCallback((cfg: FSMConfig) => {
    if (globalSocket?.connected) {
      void globalSocket.broadcast({ type: 'CONFIG_UPDATE', payload: cfg })
    }
  }, [])

  // Broadcast local config changes to peers.
  useEffect(() => {
    if (!globalSocket?.connected) return
    if (configRevision === 0) return
    if (configRevision === _remoteRevision) return
    const currentConfig = useWorkspaceStore.getState().config
    void globalSocket.broadcast({ type: 'CONFIG_UPDATE', payload: currentConfig })
  }, [configRevision])

  // Auto-join if the URL already contains a room link on first mount.
  useEffect(() => {
    const roomInfo = getRoomFromUrl()
    if (roomInfo && !globalSocket) {
      joinSession(roomInfo)
    }
    // Only run on mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return {
    startSession,
    joinSession,
    disconnect,
    broadcastConfig,
    socket: globalSocket,
  }
}
