'use client'

import { memo, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import type { EdgeProps } from '@xyflow/react'
import { getSmoothStepPath, EdgeLabelRenderer, BaseEdge, useStore } from '@xyflow/react'
import type { EdgeLabelData } from '@/lib/fsmToReactFlow'
import { parallelEdgeLabelDelta } from '@/lib/edgeLabelFan'
import { computeEdgeLabelZIndex } from '@/lib/edgeLabelStacking'
import { EDGE_LABEL_COLORS, EDGE_LABEL_COLORS_DEFAULT } from '@/lib/diagramColors'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'
import { useToastStore } from '@/stores/toast'
import { Copy, StickyNote, BarChart3 } from 'lucide-react'
import { TransitionInfoPopover } from './TransitionInfoPopover'
import { StateAnnotationPopover } from '@/components/annotations/StateAnnotationPopover'
import { AugmentationRail } from './AugmentationRail'
import { cn } from '@/lib/utils'

// Self-loop geometry is derived from node size + a margin so it stays robust as the UI evolves.
// Tunables: keep these conservative but clearly outside the node.
const SELF_LOOP_MARGIN_PX = 72
const SELF_LOOP_MIN_BULGE_Y_PX = 64
/** Nudge label anchor toward the node so the box overlaps the stroke slightly (left-anchored labels). */
const SELF_LOOP_LABEL_OVERLAP_PX = 10

function cubicAt(t: number, p0: number, p1: number, p2: number, p3: number): number {
  const u = 1 - t
  return (u ** 3) * p0 + 3 * (u ** 2) * t * p1 + 3 * u * (t ** 2) * p2 + (t ** 3) * p3
}

/** Matches state-node attached sidebar icon buttons */
const ATTACHED_RAIL_BTN =
  'grid h-6 w-6 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1'

/**
 * Build SVG path and label position for a self-loop (source === target).
 * Loop bulges to the right and is guaranteed to clear the node bounds; label sits on the loop apex.
 */
function getSelfLoopPath(params: {
  sourceX: number
  sourceY: number
  targetX: number
  targetY: number
  nodeWidth: number
  nodeHeight: number
}): [path: string, labelX: number, labelY: number] {
  const { sourceX, sourceY, targetX, targetY, nodeWidth, nodeHeight } = params
  const nodeCenterX = (sourceX + targetX) / 2
  const nodeHalfW = Math.max(1, nodeWidth / 2)
  const outsideX = nodeCenterX + nodeHalfW + SELF_LOOP_MARGIN_PX

  const bulgeY = Math.max(SELF_LOOP_MIN_BULGE_Y_PX, Math.round(nodeHeight * 1.15))

  // Curve from bottom handle to top handle via an outside control line.
  const c1x = outsideX
  const c1y = sourceY + bulgeY
  const c2x = outsideX
  const c2y = targetY - bulgeY
  const path = `M ${sourceX} ${sourceY} C ${c1x} ${c1y} ${c2x} ${c2y} ${targetX} ${targetY}`

  // Anchor the label to a point ON the curve so the box truly touches the edge.
  // t=0.5 is a stable visual apex for this symmetric control-point setup.
  const t = 0.5
  let labelX = cubicAt(t, sourceX, c1x, c2x, targetX)
  const labelY = cubicAt(t, sourceY, c1y, c2y, targetY)
  labelX -= SELF_LOOP_LABEL_OVERLAP_PX
  return [path, labelX, labelY]
}

function clamp2(text: string): CSSProperties {
  return {
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical',
    overflow: 'hidden',
    wordBreak: 'break-word',
  }
}

function Chip({
  kind,
  label,
  text,
}: {
  kind: keyof typeof EDGE_LABEL_COLORS
  label: string
  text: string
}) {
  const c = EDGE_LABEL_COLORS[kind]
  // Pill chip with subtle tint + dot.
  return (
    <div
      className="inline-flex max-w-[260px] items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] leading-4 shadow-[0_1px_0_rgba(0,0,0,0.04)]"
      style={{
        background: c.bg,
        borderColor: c.border,
        color: c.text,
      }}
      title={text}
    >
      <span
        className="h-1.5 w-1.5 shrink-0 rounded-full"
        style={{ background: c.border }}
        aria-hidden
      />
      <span className="font-semibold shrink-0">{label}</span>
      <span style={clamp2(text)}>{text}</span>
    </div>
  )
}

function GroupRow({
  item,
  onOpen,
  onPick,
}: {
  item: NonNullable<EdgeLabelData['groupedTransitions']>[number]
  onOpen?: (transitionIndex: number) => void
  onPick?: (transitionIndex: number) => void
}) {
  const trigger = item.trigger && item.trigger !== '' ? item.trigger : 'transition'
  const open = (e?: { stopPropagation?: () => void }) => {
    e?.stopPropagation?.()
    onOpen?.(item.transitionIndex)
  }
  return (
    <div
      className="flex flex-col gap-1 rounded-md px-2 py-1.5 hover:bg-muted/60 focus:bg-muted/60 focus:outline-none focus:ring-2 focus:ring-primary/30"
      role="menuitem"
      tabIndex={0}
      onClick={(e) => {
        e.stopPropagation()
        onPick?.(item.transitionIndex)
      }}
      onDoubleClick={(e) => {
        open(e)
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') open(e)
      }}
      title={item.label}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          className="inline-flex max-w-full min-w-0 items-center rounded-md px-2.5 py-1.5 text-sm font-bold leading-snug tracking-tight shadow-sm"
          style={{
            background: EDGE_LABEL_COLORS.trigger.bg,
            border: `1px solid ${EDGE_LABEL_COLORS.trigger.border}`,
            color: EDGE_LABEL_COLORS.trigger.text,
          }}
        >
          <span className="truncate">{trigger}</span>
        </span>
      </div>
      <div className="flex flex-wrap items-start gap-1.5">
        {item.guardsText ? <Chip kind="guards" label="G" text={item.guardsText} /> : null}
        {item.actionsText ? <Chip kind="actions" label="A" text={item.actionsText} /> : null}
        {item.delayText ? (
          <div
            className="flex items-center gap-1 rounded-md border px-1.5 py-1 text-[10px] leading-3"
            style={{
              background: EDGE_LABEL_COLORS.delay.bg,
              borderColor: EDGE_LABEL_COLORS.delay.border,
              color: EDGE_LABEL_COLORS.delay.text,
            }}
            title={item.delayText}
          >
            <span className="font-semibold shrink-0">⏱</span>
            <span style={clamp2(item.delayText)}>{item.delayText}</span>
          </div>
        ) : null}
        {item.regionText ? (
          <div
            className="flex items-center gap-1 rounded-md border px-1.5 py-1 text-[10px] leading-3"
            style={{
              background: EDGE_LABEL_COLORS.region.bg,
              borderColor: EDGE_LABEL_COLORS.region.border,
              color: EDGE_LABEL_COLORS.region.text,
            }}
            title={item.regionText}
          >
            <span className="font-semibold shrink-0">@</span>
            <span style={clamp2(item.regionText)}>{item.regionText}</span>
          </div>
        ) : null}
        {item.timeoutLabel ? (
          <div
            className="flex items-center gap-1 rounded-md border px-1.5 py-1 text-[10px] leading-3"
            style={{
              background: EDGE_LABEL_COLORS.timeout.bg,
              borderColor: EDGE_LABEL_COLORS.timeout.border,
              color: EDGE_LABEL_COLORS.timeout.text,
            }}
            title={item.timeoutLabel}
          >
            <span className="font-semibold shrink-0">timeout</span>
            <span style={clamp2(item.timeoutLabel)}>{item.timeoutLabel}</span>
          </div>
        ) : null}
      </div>
    </div>
  )
}

export const EdgeWithLabel = memo(function EdgeWithLabel({
  id,
  source,
  target,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  style,
  markerEnd,
}: EdgeProps) {
  const { focusedEdgeId, focusedNodeId, requestFocusEdgeLabel } = useFsmDiagramFocus()
  const toastSuccess = useToastStore((s) => s.success)
  const toastError = useToastStore((s) => s.error)
  const edgeData = (data ?? {}) as EdgeLabelData
  const plainMode = edgeData.plainMode === true
  const isSelfLoop = edgeData.isSelfLoop === true

  // Use measured node size when available so self-loop geometry stays correct as node UI changes.
  const sourceNode = useStore((s) => s.nodeLookup.get(source))
  const sourceIsParallel = (sourceNode?.data as any)?.isParallel === true
  const fallbackW = sourceIsParallel ? 180 * 2 : 180
  const fallbackH = sourceIsParallel ? 44 * 2 : 44
  const nodeWidth = (sourceNode as any)?.measured?.width ?? (sourceNode as any)?.width ?? fallbackW
  const nodeHeight = (sourceNode as any)?.measured?.height ?? (sourceNode as any)?.height ?? fallbackH

  const [edgePath, labelX, labelY] = isSelfLoop
    ? getSelfLoopPath({ sourceX, sourceY, targetX, targetY, nodeWidth, nodeHeight })
    : getSmoothStepPath({
        sourceX,
        sourceY,
        targetX,
        targetY,
        sourcePosition,
        targetPosition,
      })

  const [hovered, setHovered] = useState(false)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [detailsMounted, setDetailsMounted] = useState(false)
  const [detailsPos, setDetailsPos] = useState<{ left: number; top: number } | null>(null)
  const detailsBtnRef = useRef<HTMLButtonElement | null>(null)
  const detailsRef = useRef<HTMLDivElement | null>(null)
  const noteBtnRef = useRef<HTMLButtonElement | null>(null)
  const noteRef = useRef<HTMLDivElement | null>(null)
  const [noteOpenMounted, setNoteOpenMounted] = useState(false)
  const [notePos, setNotePos] = useState<{ left: number; top: number } | null>(null)
  const [noteBody, setNoteBody] = useState('')
  const isSynthetic = edgeData.isSynthetic === true
  const showHover = hovered && !isSynthetic
  const hasStructured = edgeData.trigger != null ||
    edgeData.guardsText != null ||
    edgeData.actionsText != null ||
    edgeData.delayText != null ||
    edgeData.regionText != null ||
    edgeData.isTimeout ||
    (edgeData.timeoutLabel != null && edgeData.timeoutLabel !== '')
  const grouped = edgeData.groupedTransitions
  const isGrouped =
    Array.isArray(grouped) &&
    grouped.length >= 2 &&
    (typeof edgeData.onOpenTransition === 'function' ||
      typeof edgeData.onPickTransition === 'function')

  useEffect(() => {
    setDetailsMounted(true)
    setNoteOpenMounted(true)
  }, [])

  useEffect(() => {
    if (plainMode) setDetailsOpen(false)
  }, [plainMode])

  useEffect(() => {
    if (!detailsOpen) return
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setDetailsOpen(false)
    }
    function onPointerDown(e: PointerEvent) {
      const t = e.target as HTMLElement
      if (detailsRef.current && detailsRef.current.contains(t)) return
      if (detailsBtnRef.current && detailsBtnRef.current.contains(t)) return
      setDetailsOpen(false)
    }
    document.addEventListener('keydown', onKeyDown)
    // Capture makes this robust against diagram layers stopping propagation.
    document.addEventListener('pointerdown', onPointerDown, { capture: true })
    return () => {
      document.removeEventListener('keydown', onKeyDown)
      document.removeEventListener('pointerdown', onPointerDown, { capture: true } as any)
    }
  }, [detailsOpen])

  const noteEnabled = edgeData.transitionNoteEnabled === true && !!edgeData.transitionNoteKey
  const noteOpen = edgeData.transitionNoteOpen === true

  useEffect(() => {
    if (!noteOpen) return
    setNoteBody(edgeData.transitionNoteBody ?? '')
  }, [noteOpen, edgeData.transitionNoteBody])

  useEffect(() => {
    if (!noteOpen) {
      setNotePos(null)
      return
    }
    let raf = 0
    const tick = () => {
      const btn = noteBtnRef.current
      if (btn) {
        const r = btn.getBoundingClientRect()
        const left = Math.min(window.innerWidth - 16, Math.max(8, r.right + 8))
        const top = Math.min(window.innerHeight - 16, Math.max(8, r.top))
        setNotePos({ left, top })
      }
      raf = window.requestAnimationFrame(tick)
    }
    raf = window.requestAnimationFrame(tick)
    return () => window.cancelAnimationFrame(raf)
  }, [noteOpen])

  useEffect(() => {
    if (!noteOpen) return
    function onPointerDown(e: PointerEvent) {
      const t = e.target as HTMLElement
      if (noteRef.current && noteRef.current.contains(t)) return
      if (noteBtnRef.current && noteBtnRef.current.contains(t)) return
      edgeData.onCloseTransitionNote?.()
    }
    document.addEventListener('pointerdown', onPointerDown, { capture: true })
    return () =>
      document.removeEventListener('pointerdown', onPointerDown, { capture: true } as any)
  }, [noteOpen, edgeData])

  useEffect(() => {
    if (!detailsOpen) {
      setDetailsPos(null)
      return
    }
    let raf = 0
    const tick = () => {
      const btn = detailsBtnRef.current
      if (btn) {
        const r = btn.getBoundingClientRect()
        const left = Math.min(window.innerWidth - 16, Math.max(8, r.right + 8))
        const top = Math.min(window.innerHeight - 16, Math.max(8, r.top))
        setDetailsPos((prev) => {
          if (prev && Math.abs(prev.left - left) < 0.5 && Math.abs(prev.top - top) < 0.5) return prev
          return { left, top }
        })
      }
      raf = window.requestAnimationFrame(tick)
    }
    raf = window.requestAnimationFrame(tick)
    return () => window.cancelAnimationFrame(raf)
  }, [detailsOpen])

  const handleCopy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toastSuccess(`Copied ${label}`)
    } catch {
      toastError('Copy failed')
    }
  }

  const hasChips =
    (edgeData.guardsText != null && edgeData.guardsText !== '') ||
    (edgeData.actionsText != null && edgeData.actionsText !== '') ||
    (edgeData.delayText != null && edgeData.delayText !== '') ||
    (edgeData.regionText != null && edgeData.regionText !== '') ||
    (edgeData.timeoutLabel != null && edgeData.timeoutLabel !== '')
  const isTriggerOnly =
    !edgeData.isTimeout &&
    !hasChips &&
    edgeData.trigger != null &&
    edgeData.trigger !== ''

  const transitionDetailsPortal =
    !plainMode &&
    (isGrouped || hasStructured) &&
    detailsOpen &&
    detailsMounted &&
    typeof document !== 'undefined' &&
    detailsPos
      ? createPortal(
          <div
            ref={detailsRef}
            className="fixed"
            style={{ left: detailsPos.left, top: detailsPos.top, zIndex: 999999 }}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
          >
            <TransitionInfoPopover
              title="Transition"
              subtitle={
                edgeData.sourceName && edgeData.destName
                  ? `${edgeData.sourceName} → ${edgeData.destName}`
                  : id
              }
              trigger={edgeData.trigger ?? null}
              guards={edgeData.guardsText ?? null}
              actions={edgeData.actionsText ?? null}
              delay={edgeData.delayText ?? null}
              region={edgeData.regionText ?? null}
              timeout={edgeData.timeoutLabel ?? null}
              onClose={() => setDetailsOpen(false)}
              onCopy={handleCopy}
            />
          </div>,
          document.body
        )
      : null

  const transitionNotePortal =
    !plainMode &&
    (isGrouped || hasStructured) &&
    noteOpen &&
    noteOpenMounted &&
    typeof document !== 'undefined' &&
    notePos
      ? createPortal(
          <div
            ref={noteRef}
            className="fixed"
            style={{ left: notePos.left, top: notePos.top, zIndex: 999999 }}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
          >
            <StateAnnotationPopover
              heading="Transition note"
              machineName={edgeData.transitionNoteMachineName ?? ''}
              machineVersion={edgeData.transitionNoteMachineVersion ?? ''}
              stateName={edgeData.transitionNoteKey ?? ''}
              body={noteBody}
              initialBody={edgeData.transitionNoteInitialBody ?? ''}
              saving={edgeData.transitionNoteSaving === true}
              deleting={edgeData.transitionNoteDeleting === true}
              onBodyChange={setNoteBody}
              onClose={() => edgeData.onCloseTransitionNote?.()}
              onSave={() => edgeData.onSaveTransitionNote?.(noteBody)}
              onDelete={() => edgeData.onDeleteTransitionNote?.()}
            />
          </div>,
          document.body
        )
      : null

  const labelContent = isGrouped ? (
    <>
    <div
      className={cn(
        'group relative flex min-w-[180px] max-w-[300px] overflow-hidden rounded-lg border bg-background text-[11px] text-foreground',
        plainMode ? 'shadow-sm' : 'shadow-md',
        showHover
          ? plainMode
            ? 'border-muted-foreground/30'
            : 'border-muted-foreground/40 shadow-md'
          : 'border-border',
      )}
      role="menu"
      aria-label="Transitions"
    >
      <div className="flex min-h-0 min-w-0 flex-1 flex-col justify-start self-stretch px-2 py-1.5">
        <div className="pb-1.5">
          <div className="text-[11px] font-semibold text-muted-foreground">{grouped.length} transitions</div>
        </div>
        <div className="h-px w-full bg-border" />
        <div className="mt-1 max-h-[220px] overflow-auto">
          {grouped
            .slice()
            .sort((a, b) => a.transitionIndex - b.transitionIndex)
            .map((item) => (
              <GroupRow
                key={item.transitionIndex}
                item={item}
                onOpen={edgeData.onOpenTransition}
                onPick={edgeData.onPickTransition}
              />
            ))}
        </div>
      </div>
      {!isSynthetic && !plainMode ? (
        <AugmentationRail
          variant="attached"
          hasNote={edgeData.hasTransitionNote === true && noteEnabled}
          noteButton={
            <button
              ref={noteBtnRef}
              type="button"
              disabled={!noteEnabled}
              className={cn(
                ATTACHED_RAIL_BTN,
                !noteEnabled && 'cursor-not-allowed opacity-40',
                noteEnabled &&
                  (edgeData.hasTransitionNote
                    ? 'text-amber-700 hover:bg-amber-100/80 dark:text-amber-300 dark:hover:bg-amber-950/40'
                    : undefined)
              )}
              title={
                !noteEnabled
                  ? 'Unavailable on merged transitions (notes are per transition)'
                  : edgeData.hasTransitionNote
                    ? 'View or edit note'
                    : 'Add note'
              }
              aria-label={
                !noteEnabled
                  ? 'Notes unavailable'
                  : edgeData.hasTransitionNote
                    ? 'View or edit note'
                    : 'Add note'
              }
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation()
                const key = edgeData.transitionNoteKey
                if (!noteEnabled || !key) return
                edgeData.onOpenTransitionNote?.(key)
              }}
            >
              <StickyNote className="h-3.5 w-3.5" />
            </button>
          }
        >
          <button
            ref={detailsBtnRef}
            type="button"
            className={ATTACHED_RAIL_BTN}
            title="Transition metrics"
            aria-label="Transition metrics"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              setDetailsOpen((v) => !v)
            }}
          >
            <BarChart3 className="h-3.5 w-3.5" />
          </button>
        </AugmentationRail>
      ) : null}
    </div>
    {transitionDetailsPortal}
    {transitionNotePortal}
    </>
  ) : hasStructured ? (
    <>
    <div
      className={cn(
        'group relative flex max-w-[240px] min-w-[88px] overflow-hidden rounded-lg border bg-background text-[11px] text-foreground',
        plainMode ? 'shadow-sm' : 'shadow-md',
        showHover
          ? plainMode
            ? 'border-muted-foreground/30'
            : 'border-muted-foreground/40 shadow-md'
          : 'border-border',
      )}
    >
      <div className="flex min-h-0 min-w-0 flex-1 flex-col justify-center self-stretch px-2 py-1.5">
        {edgeData.isTimeout ? (
          <div className="min-w-0 text-xs font-bold leading-snug tracking-tight">
            <span
              className="inline-block max-w-full rounded-md px-2 py-1 shadow-sm"
              style={{
                background: EDGE_LABEL_COLORS.timeout.bg,
                border: `1px solid ${EDGE_LABEL_COLORS.timeout.border}`,
                color: EDGE_LABEL_COLORS.timeout.text,
              }}
            >
              <span className="truncate">{edgeData.label ?? 'timeout'}</span>
            </span>
          </div>
        ) : (
          <div className="space-y-1.5">
            <div
              className={[
                'min-w-0',
                isTriggerOnly ? 'flex items-center justify-center' : '',
              ].join(' ')}
            >
              {edgeData.trigger != null && edgeData.trigger !== '' ? (
                <div className="min-w-0 text-xs font-bold leading-snug tracking-tight">
                  <span
                    className={
                      isTriggerOnly
                        ? 'inline-flex min-w-0 max-w-full items-center justify-center rounded-full px-2.5 py-1 text-center shadow-sm'
                        : 'inline-block max-w-full rounded-md px-2 py-1 shadow-sm'
                    }
                    style={{
                      background: EDGE_LABEL_COLORS.trigger.bg,
                      border: `1px solid ${EDGE_LABEL_COLORS.trigger.border}`,
                      color: EDGE_LABEL_COLORS.trigger.text,
                    }}
                  >
                    <span className={isTriggerOnly ? 'min-w-0 max-w-full truncate' : 'truncate'}>
                      {edgeData.trigger}
                    </span>
                  </span>
                </div>
              ) : (
                <div className="text-xs font-bold leading-snug tracking-tight text-muted-foreground">
                  transition
                </div>
              )}
            </div>

          {hasChips ? (
            <div className="flex flex-wrap items-start gap-1.5">
            {edgeData.guardsText != null && edgeData.guardsText !== '' ? (
              <Chip kind="guards" label="G" text={edgeData.guardsText} />
            ) : null}
            {edgeData.actionsText != null && edgeData.actionsText !== '' ? (
              <Chip kind="actions" label="A" text={edgeData.actionsText} />
            ) : null}
            {edgeData.delayText != null && edgeData.delayText !== '' ? (
              <Chip kind="delay" label="⏱" text={edgeData.delayText} />
            ) : null}
            {edgeData.regionText != null && edgeData.regionText !== '' ? (
              <Chip kind="region" label="@" text={edgeData.regionText} />
            ) : null}
            </div>
          ) : null}

          {edgeData.timeoutLabel != null && edgeData.timeoutLabel !== '' ? (
            <div className="pt-1.5">
              <div className="h-px w-full bg-border" />
              <div className="mt-1">
                <Chip kind="timeout" label="timeout" text={edgeData.timeoutLabel} />
              </div>
            </div>
          ) : null}
        </div>
        )}
      </div>
      {!isSynthetic && !plainMode ? (
        <AugmentationRail
          variant="attached"
          hasNote={edgeData.hasTransitionNote === true && noteEnabled}
          noteButton={
            <button
              ref={noteBtnRef}
              type="button"
              disabled={!noteEnabled}
              className={cn(
                ATTACHED_RAIL_BTN,
                !noteEnabled && 'cursor-not-allowed opacity-40',
                noteEnabled &&
                  (edgeData.hasTransitionNote
                    ? 'text-amber-700 hover:bg-amber-100/80 dark:text-amber-300 dark:hover:bg-amber-950/40'
                    : undefined)
              )}
              title={
                !noteEnabled
                  ? 'Notes unavailable in this view'
                  : edgeData.hasTransitionNote
                    ? 'View or edit note'
                    : 'Add note'
              }
              aria-label={
                !noteEnabled
                  ? 'Notes unavailable'
                  : edgeData.hasTransitionNote
                    ? 'View or edit note'
                    : 'Add note'
              }
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation()
                const key = edgeData.transitionNoteKey
                if (!noteEnabled || !key) return
                edgeData.onOpenTransitionNote?.(key)
              }}
            >
              <StickyNote className="h-3.5 w-3.5" />
            </button>
          }
        >
          <button
            ref={detailsBtnRef}
            type="button"
            className={ATTACHED_RAIL_BTN}
            title="Transition metrics"
            aria-label="Transition metrics"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              setDetailsOpen((v) => !v)
            }}
          >
            <BarChart3 className="h-3.5 w-3.5" />
          </button>
        </AugmentationRail>
      ) : null}
    </div>
    {transitionDetailsPortal}
    {transitionNotePortal}
    </>
  ) : edgeData.label ? (
    <div
      style={{
        ...(showHover ? { boxShadow: '0 2px 8px rgba(0,0,0,0.15)' } : {}),
        background:
          edgeData.label === 'initial'
            ? EDGE_LABEL_COLORS.initial.bg
            : EDGE_LABEL_COLORS_DEFAULT.bg,
        borderColor:
          edgeData.label === 'initial'
            ? EDGE_LABEL_COLORS.initial.border
            : EDGE_LABEL_COLORS_DEFAULT.border,
        color:
          edgeData.label === 'initial'
            ? EDGE_LABEL_COLORS.initial.text
            : EDGE_LABEL_COLORS_DEFAULT.text,
      }}
      className="rounded-md border px-2.5 py-2 text-xs shadow-sm max-w-[260px] min-w-[96px] text-center"
    >
      {edgeData.label}
    </div>
  ) : null

  const labelZIndex = computeEdgeLabelZIndex({
    edgeId: id,
    edgeSourceId: source,
    edgeTargetId: target,
    focusedEdgeId,
    focusedNodeId,
    isTimeout: edgeData.isTimeout === true,
  })

  const isFocusedEdge = focusedEdgeId === id
  const isIncidentToFocusedNode =
    focusedNodeId != null && (source === focusedNodeId || target === focusedNodeId)
  const hasFocus = focusedEdgeId != null || focusedNodeId != null
  const shouldDim = hasFocus && !isFocusedEdge && !isIncidentToFocusedNode
  const edgeOpacity = shouldDim ? 0.2 : isFocusedEdge ? 1 : isIncidentToFocusedNode ? 0.92 : 1
  const effectiveStrokeWidth = isFocusedEdge
    ? Math.max(2, Number(style?.strokeWidth ?? 1) + 1)
    : Number(style?.strokeWidth ?? 1)
  const edgeStyle: CSSProperties = {
    ...(style as CSSProperties | undefined),
    opacity: edgeOpacity,
    strokeWidth: effectiveStrokeWidth,
  }
  const labelOpacity = shouldDim ? 0.3 : 1

  const parallelIndex = edgeData.labelParallelIndex ?? 0
  const parallelCount = edgeData.labelParallelCount ?? 1
  const { dx: labelDx, dy: labelDy } = parallelEdgeLabelDelta({
    isSelfLoop,
    sourceX,
    sourceY,
    targetX,
    targetY,
    index: parallelIndex,
    count: parallelCount,
  })
  const showAnchorCue = !isSelfLoop && (isFocusedEdge || showHover) && (Math.abs(labelDx) + Math.abs(labelDy) > 2)
  const cueLength = Math.hypot(labelDx, labelDy)
  const cueAngleDeg = Math.atan2(labelDy, labelDx) * (180 / Math.PI)

  return (
    <>
      <BaseEdge id={id} path={edgePath} style={edgeStyle} markerEnd={markerEnd} />
      {labelContent ? (
        <EdgeLabelRenderer>
          {showAnchorCue ? (
            <div
              style={{
                position: 'absolute',
                transform: `translate(${labelX}px,${labelY}px) rotate(${cueAngleDeg}deg)`,
                width: cueLength,
                height: 1,
                background: '#64748b',
                opacity: shouldDim ? 0.25 : 0.55,
                transformOrigin: '0 50%',
                pointerEvents: 'none',
                zIndex: Math.max(1, labelZIndex - 1),
              }}
            />
          ) : null}
          {(!isSelfLoop && (isFocusedEdge || showHover)) ? (
            <div
              style={{
                position: 'absolute',
                transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
                width: 6,
                height: 6,
                borderRadius: 9999,
                background: '#475569',
                opacity: shouldDim ? 0.3 : 0.75,
                pointerEvents: 'none',
                zIndex: Math.max(1, labelZIndex - 1),
              }}
            />
          ) : null}
          <div
            style={{
              position: 'absolute',
              // Self-loop: anchor the *left edge* of the box at the loop apex so the whole label stays outside the node.
              transform: isSelfLoop
                ? `translate(0, -50%) translate(${labelX + labelDx}px,${labelY + labelDy}px)`
                : `translate(-50%, -50%) translate(${labelX + labelDx}px,${labelY + labelDy}px)`,
              pointerEvents: 'all',
              zIndex: labelZIndex,
              cursor: isSynthetic ? 'default' : 'pointer',
              opacity: labelOpacity,
            }}
            className="nodrag nopan"
            onClick={(e) => {
              e.stopPropagation()
              requestFocusEdgeLabel(id, { sourceId: source, targetId: target })
              if (isSynthetic || isGrouped) return
              const idx = edgeData.transitionIndex
              if (idx != null && edgeData.onPickTransition) {
                edgeData.onPickTransition(idx)
              }
            }}
            onDoubleClick={(e) => {
              e.stopPropagation()
              if (isSynthetic || isGrouped) return
              const idx = edgeData.transitionIndex
              if (idx != null && edgeData.onOpenTransition) {
                edgeData.onOpenTransition(idx)
              }
            }}
            onMouseEnter={() => !isSynthetic && setHovered(true)}
            onMouseLeave={() => setHovered(false)}
          >
            {labelContent}
          </div>
        </EdgeLabelRenderer>
      ) : null}
    </>
  )
})
