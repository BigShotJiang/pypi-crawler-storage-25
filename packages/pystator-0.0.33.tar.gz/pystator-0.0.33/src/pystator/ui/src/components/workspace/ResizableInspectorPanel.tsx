'use client'

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { X } from 'lucide-react'

const DEFAULT_WIDTH_PX = 320
const MIN_WIDTH = 280
const MAX_WIDTH_PERCENT = 0.8

/** Survives component unmount so re-opening the panel restores the last user-chosen width. */
let persistedWidth = DEFAULT_WIDTH_PX

export interface ResizableInspectorPanelProps {
  open: boolean
  title: string
  onClose: () => void
  children: ReactNode
  /** Defaults to `title` */
  ariaLabel?: string
  /** CSS selector for sibling containers whose clicks should NOT trigger close (e.g. ".react-flow") */
  excludeOutsideClickSelector?: string
}

export function ResizableInspectorPanel({
  open,
  title,
  onClose,
  children,
  ariaLabel,
  excludeOutsideClickSelector,
}: ResizableInspectorPanelProps) {
  const drawerRef = useRef<HTMLDivElement>(null)
  const [width, setWidth] = useState(persistedWidth)
  const [isResizing, setIsResizing] = useState(false)

  const maxWidthPx =
    typeof window !== 'undefined'
      ? Math.floor(window.innerWidth * MAX_WIDTH_PERCENT)
      : 900
  const clampedWidth = Math.min(Math.max(width, MIN_WIDTH), maxWidthPx)

  const handleResizeMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    setIsResizing(true)
  }, [])

  useEffect(() => {
    if (!isResizing) return
    const handleMouseMove = (e: MouseEvent) => {
      const clamped = Math.min(
        Math.max(window.innerWidth - e.clientX, MIN_WIDTH),
        window.innerWidth * MAX_WIDTH_PERCENT,
      )
      setWidth(clamped)
      persistedWidth = clamped
    }
    const handleMouseUp = () => setIsResizing(false)
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    document.body.style.cursor = 'ew-resize'
    document.body.style.userSelect = 'none'
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
  }, [isResizing])

  useEffect(() => {
    if (!open) return
    const handleMouseDown = (e: MouseEvent) => {
      const target = e.target as Node | null
      if (!target) return
      if (drawerRef.current?.contains(target)) return
      if (
        excludeOutsideClickSelector &&
        (target as Element).closest?.(excludeOutsideClickSelector)
      ) {
        return
      }
      const hasOpenDropdown = drawerRef.current?.querySelector(
        '[data-state="open"][role="combobox"]',
      )
      if (!hasOpenDropdown) {
        onClose()
      }
    }
    document.addEventListener('mousedown', handleMouseDown)
    return () => document.removeEventListener('mousedown', handleMouseDown)
  }, [open, onClose, excludeOutsideClickSelector])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onClose()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  const label = ariaLabel ?? title

  return (
    <div
      ref={drawerRef}
      role="complementary"
      aria-label={label}
      style={{
        position: 'absolute',
        top: 0,
        right: 0,
        bottom: 0,
        width: clampedWidth,
        minWidth: MIN_WIDTH,
        maxWidth: maxWidthPx,
        display: 'flex',
        flexDirection: 'column',
        background: 'hsl(var(--background))',
        borderLeft: '1px solid hsl(var(--border))',
        boxShadow: '-4px 0 12px hsl(var(--foreground) / 0.06)',
        zIndex: 20,
        animation: 'inspectorPanelSlideIn 0.2s ease-out',
      }}
    >
      <style>{`
        @keyframes inspectorPanelSlideIn {
          from { transform: translateX(100%); opacity: 0.9; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>

      <div
        role="separator"
        aria-orientation="vertical"
        aria-label="Resize panel"
        onMouseDown={handleResizeMouseDown}
        className="absolute left-0 top-0 bottom-0 w-2 cursor-ew-resize touch-none z-10 -ml-px hover:bg-primary/20 active:bg-primary/30"
        style={{ cursor: isResizing ? 'ew-resize' : undefined }}
      />

      <header className="flex items-center justify-between gap-2 shrink-0 border-b border-border px-3 py-2">
        <h2 className="text-xs font-semibold truncate">{title}</h2>
        <button
          type="button"
          onClick={onClose}
          className="rounded p-1 text-muted-foreground hover:text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/50"
          aria-label="Close panel"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </header>

      {/* text-xs matches pycharter inspector density; children handle scroll (e.g. sticky form footer). */}
      <div className="min-h-0 flex-1 flex flex-col overflow-hidden text-xs antialiased">
        {children}
      </div>
    </div>
  )
}
