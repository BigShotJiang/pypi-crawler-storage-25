'use client'

import { useRef } from 'react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Save,
  Download,
  Upload,
  Loader2,
  Undo2,
  Redo2,
  RotateCcw,
  LayoutGrid,
  Ellipsis,
  ChevronDown,
  Check,
  Workflow,
  Table2,
} from 'lucide-react'
import { ShareButton } from '@/components/collab'
import {
  TABLE_VIEW_TOOLBAR_OVERLAP_RATIO,
  useToolbarCompression,
} from '@/hooks'
import type { MachineListItem } from '@/lib/api'
import type { ViewMode } from '@/stores/workspace'

export interface WorkspaceToolbarProps {
  viewMode: ViewMode
  setViewMode: (mode: ViewMode) => void
  versionsForSelectedName: MachineListItem[]
  loadedMachineId: string | null
  loadingMachine: boolean
  machinesLoading: boolean
  selectedMachineName: string | null
  configVersion: string
  machineLoadError: string | null
  pastLength: number
  futureLength: number
  undo: () => void
  redo: () => void
  clearConfig: () => void
  downloadCurrentConfig: () => void
  openImportFilePicker: () => void
  importingConfig: boolean
  handleSaveClick: () => void
  saveLoading: boolean
  isDirty: boolean
  loadMachine: (machineId: string) => void
  resetLayout?: () => void
}

export function WorkspaceToolbar({
  viewMode,
  setViewMode,
  versionsForSelectedName,
  loadedMachineId,
  loadingMachine,
  machinesLoading,
  selectedMachineName,
  configVersion,
  machineLoadError,
  pastLength,
  futureLength,
  undo,
  redo,
  clearConfig,
  downloadCurrentConfig,
  openImportFilePicker,
  importingConfig,
  handleSaveClick,
  saveLoading,
  isDirty,
  loadMachine,
  resetLayout,
}: WorkspaceToolbarProps) {
  const toolbarRef = useRef<HTMLDivElement>(null)
  const isToolbarCollapsed = useToolbarCompression(
    toolbarRef,
    viewMode === 'table' ? TABLE_VIEW_TOOLBAR_OVERLAP_RATIO : undefined,
  )

  return (
    <div
      ref={toolbarRef}
      className="absolute top-3 right-3 z-10 flex flex-row items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm"
    >
      {!isToolbarCollapsed ? (
        <>
          <div
            className="flex rounded-lg border border-border/70 bg-background/50 p-0.5"
            role="tablist"
            aria-label="Diagram or Table"
          >
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === 'diagram'}
              onClick={() => setViewMode('diagram')}
              className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                viewMode === 'diagram'
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              title="Diagram view (Ctrl+E)"
              aria-label="Diagram view"
            >
              <Workflow className="h-3.5 w-3.5" />
              Diagram
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === 'table'}
              onClick={() => setViewMode('table')}
              className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                viewMode === 'table'
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              title="Table view (Ctrl+E)"
              aria-label="Table view"
            >
              <Table2 className="h-3.5 w-3.5" />
              Table
            </button>
          </div>
          <div className="h-5 border-l border-border" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                disabled={
                  machinesLoading ||
                  loadingMachine ||
                  !selectedMachineName ||
                  versionsForSelectedName.length === 0
                }
                className="h-7 gap-1 px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                aria-label="Machine version"
              >
                {loadingMachine ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <>
                    v
                    {versionsForSelectedName.find((m) => m.id === loadedMachineId)?.version ??
                      configVersion ??
                      '—'}
                    {versionsForSelectedName.length > 1 && (
                      <ChevronDown className="h-3 w-3 opacity-60" />
                    )}
                  </>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              <DropdownMenuLabel className="text-xs">
                Versions
                {versionsForSelectedName.length === 0
                  ? ''
                  : ` (${versionsForSelectedName.length})`}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              {versionsForSelectedName.length === 0 ? (
                <DropdownMenuItem disabled className="text-muted-foreground">
                  Select a machine in Browse
                </DropdownMenuItem>
              ) : (
                versionsForSelectedName.map((m) => {
                  const isActive = m.id === loadedMachineId
                  return (
                    <DropdownMenuItem
                      key={m.id}
                      onClick={() => loadMachine(m.id)}
                      className="justify-between"
                    >
                      <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                      {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                    </DropdownMenuItem>
                  )
                })
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          {machineLoadError ? (
            <span className="text-xs text-destructive" title={machineLoadError}>
              {machineLoadError.length > 20
                ? machineLoadError.slice(0, 20) + '...'
                : machineLoadError}
            </span>
          ) : null}
          <div className="h-5 border-l border-border" />
          <Button
            variant="ghost"
            size="sm"
            onClick={undo}
            disabled={pastLength === 0}
            className="shrink-0 p-2"
            title="Undo (Ctrl+Z)"
            aria-label="Undo"
          >
            <Undo2 className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={redo}
            disabled={futureLength === 0}
            className="shrink-0 p-2"
            title="Redo (Ctrl+Shift+Z)"
            aria-label="Redo"
          >
            <Redo2 className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearConfig}
            className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground shrink-0"
            title="Clear diagram"
            aria-label="Clear"
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
            Clear
          </Button>
          {resetLayout && (
            <Button
              variant="ghost"
              size="sm"
              onClick={resetLayout}
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground shrink-0"
              title="Reset to auto-layout"
              aria-label="Reset Layout"
            >
              <LayoutGrid className="mr-1.5 h-3.5 w-3.5" />
              Reset Layout
            </Button>
          )}
          <div className="h-5 border-l border-border" />
          <Button
            variant="outline"
            size="sm"
            onClick={downloadCurrentConfig}
            className="shrink-0 p-2"
            title="Download as YAML"
            aria-label="Download as YAML"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={openImportFilePicker}
            disabled={importingConfig}
            className="shrink-0 p-2"
            title="Import from YAML/JSON"
            aria-label="Import from YAML/JSON"
          >
            {importingConfig ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Upload className="h-4 w-4" />
            )}
          </Button>
          <div className="relative inline-flex items-center">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSaveClick}
              disabled={saveLoading}
              className="shrink-0 p-2"
              title="Save"
              aria-label={saveLoading ? 'Saving...' : 'Save'}
            >
              {saveLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
            </Button>
            {isDirty && (
              <span
                className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500"
                title="Unsaved changes"
                aria-hidden
              />
            )}
          </div>
          <div className="h-5 border-l border-border" />
          <ShareButton />
        </>
      ) : (
        <>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="shrink-0 p-2"
                aria-label="More options"
              >
                <Ellipsis className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="text-xs">View</DropdownMenuLabel>
              <DropdownMenuRadioGroup
                value={viewMode}
                onValueChange={(v) => setViewMode(v as ViewMode)}
              >
                <DropdownMenuRadioItem value="diagram" className="text-xs">
                  <Workflow className="mr-2 h-4 w-4" />
                  Diagram
                </DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="table" className="text-xs">
                  <Table2 className="mr-2 h-4 w-4" />
                  Table
                </DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs">Version</DropdownMenuLabel>
              {versionsForSelectedName.length === 0 ? (
                <DropdownMenuItem disabled className="text-muted-foreground text-xs">
                  Select a machine in Browse
                </DropdownMenuItem>
              ) : (
                versionsForSelectedName.map((m) => {
                  const isActive = m.id === loadedMachineId
                  return (
                    <DropdownMenuItem
                      key={m.id}
                      onClick={() => loadMachine(m.id)}
                      className="justify-between text-xs"
                    >
                      <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                      {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                    </DropdownMenuItem>
                  )
                })
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={undo} disabled={pastLength === 0}>
                <Undo2 className="mr-2 h-4 w-4" />
                Undo
                <span className="ml-auto text-xs text-muted-foreground">Ctrl+Z</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={redo} disabled={futureLength === 0}>
                <Redo2 className="mr-2 h-4 w-4" />
                Redo
                <span className="ml-auto text-xs text-muted-foreground">Ctrl+Shift+Z</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={clearConfig}>
                <RotateCcw className="mr-2 h-4 w-4" />
                Clear
              </DropdownMenuItem>
              {resetLayout && (
                <DropdownMenuItem onClick={resetLayout}>
                  <LayoutGrid className="mr-2 h-3.5 w-3.5" />
                  Reset Layout
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={downloadCurrentConfig}>
                <Download className="mr-2 h-4 w-4" />
                Download YAML
              </DropdownMenuItem>
              <DropdownMenuItem onClick={openImportFilePicker} disabled={importingConfig}>
                {importingConfig ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Upload className="mr-2 h-4 w-4" />
                )}
                Import file
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleSaveClick} disabled={saveLoading}>
                {saveLoading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {isDirty ? (
            <span className="flex items-center gap-1.5" title="Unsaved changes" role="status">
              <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" aria-hidden />
              <span className="text-xs text-amber-600 dark:text-amber-400">Unsaved</span>
            </span>
          ) : null}
          <ShareButton />
        </>
      )}
    </div>
  )
}
