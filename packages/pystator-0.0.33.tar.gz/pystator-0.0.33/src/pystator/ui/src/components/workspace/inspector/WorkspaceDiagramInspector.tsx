'use client'

import { useMemo } from 'react'
import { ResizableInspectorPanel } from '@/components/workspace/ResizableInspectorPanel'
import { StateInspectorForm } from '@/components/workspace/inspector/StateInspectorForm'
import { TransitionInspectorForm } from '@/components/workspace/inspector/TransitionInspectorForm'
import type { FSMState, FSMTransition, FSMConfig } from '@/lib/types/fsm'
import { collectAllRegionNames } from '@/lib/fsm/regionUtils'
import { cn } from '@/lib/utils'
import { inspectorSectionTitleClass } from '@/components/workspace/inspector/inspectorPanelStyles'

export type DiagramInspectorModel =
  | { kind: 'none' }
  | {
      kind: 'state'
      mode: 'add' | 'edit'
      /** For edit: current name in config. For add: unused (draft only). */
      stateName: string
      draft: FSMState
      focusName?: boolean
      resetKey: string | number
    }
  | {
      kind: 'transition'
      mode: 'add' | 'edit'
      activeIndex: number
      groupedIndices?: number[]
      draft: FSMTransition
      resetKey: string | number
    }

export interface WorkspaceDiagramInspectorProps {
  model: DiagramInspectorModel
  config: FSMConfig
  onClose: () => void
  onStateSubmit: (state: FSMState, ctx: { mode: 'add' | 'edit'; originalName: string }) => void
  onTransitionSubmit: (
    transition: FSMTransition,
    ctx: { mode: 'add' | 'edit'; editingIndex: number | null },
  ) => void
  onActiveTransitionIndexChange: (index: number) => void
  machineStateVariableKeys?: string[]
}

function transitionSummary(t: FSMTransition | undefined): string {
  if (!t) return '—'
  const trig = t.trigger ?? '(delay)'
  const src = Array.isArray(t.source) ? t.source.join(', ') : String(t.source ?? '')
  return `${trig} · ${src} → ${t.dest}`
}

export function WorkspaceDiagramInspector({
  model,
  config,
  onClose,
  onStateSubmit,
  onTransitionSubmit,
  onActiveTransitionIndexChange,
  machineStateVariableKeys,
}: WorkspaceDiagramInspectorProps) {
  const stateNames = useMemo(
    () => (config.states ?? []).map((s) => s.name),
    [config.states],
  )
  const regionNames = useMemo(
    () => collectAllRegionNames(config.states ?? []),
    [config.states],
  )

  if (model.kind === 'none') {
    return null
  }

  if (model.kind === 'state') {
    const title = model.mode === 'add' ? 'Add state' : `Edit state: ${model.stateName}`
    return (
      <ResizableInspectorPanel open title={title} onClose={onClose} ariaLabel={title} excludeOutsideClickSelector=".react-flow">
        <StateInspectorForm
          state={model.draft}
          resetKey={model.resetKey}
          existingStateNames={stateNames}
          allStates={config.states ?? []}
          machineStateVariableKeys={machineStateVariableKeys}
          formId="diagram-state-inspector-form"
          submitLabel={model.mode === 'add' ? 'Add' : 'Save'}
          autoFocusName={!!model.focusName}
          onCancel={onClose}
          onSubmit={(next) =>
            onStateSubmit(next, {
              mode: model.mode,
              originalName: model.mode === 'edit' ? model.stateName : '',
            })
          }
        />
      </ResizableInspectorPanel>
    )
  }

  const transitions = config.transitions ?? []
  const grouped =
    model.groupedIndices && model.groupedIndices.length > 1 ? model.groupedIndices : null

  const title =
    model.mode === 'add' ? 'Add transition' : `Edit transition #${model.activeIndex + 1}`

  return (
    <ResizableInspectorPanel open title={title} onClose={onClose} ariaLabel={title} excludeOutsideClickSelector=".react-flow">
      {grouped ? (
        <div className="shrink-0 border-b border-border px-3 py-2 space-y-1 max-h-40 overflow-y-auto">
          <h3 className={cn(inspectorSectionTitleClass, 'px-0')}>
            Transitions on this edge
          </h3>
          <ul className="space-y-0.5">
            {grouped.map((idx) => {
              const t = transitions[idx]
              const active = idx === model.activeIndex
              return (
                <li key={idx}>
                  <button
                    type="button"
                    onClick={() => onActiveTransitionIndexChange(idx)}
                    className={cn(
                      'w-full text-left rounded px-2 py-1.5 text-[11px] transition-colors',
                      active
                        ? 'bg-primary/15 text-foreground ring-1 ring-primary/30'
                        : 'hover:bg-muted text-muted-foreground hover:text-foreground',
                    )}
                  >
                    <span className="font-mono block truncate">{transitionSummary(t)}</span>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      ) : null}
      <TransitionInspectorForm
        transition={model.draft}
        resetKey={model.resetKey}
        stateNames={stateNames}
        regionNames={regionNames}
        configStates={config.states ?? []}
        formId="diagram-transition-inspector-form"
        submitLabel={model.mode === 'add' ? 'Add' : 'Save'}
        onCancel={onClose}
        onSubmit={(next) =>
          onTransitionSubmit(next, {
            mode: model.mode,
            editingIndex: model.mode === 'edit' ? model.activeIndex : null,
          })
        }
      />
    </ResizableInspectorPanel>
  )
}
