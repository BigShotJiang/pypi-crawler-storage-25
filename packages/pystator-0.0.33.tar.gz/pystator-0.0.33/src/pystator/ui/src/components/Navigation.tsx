'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { cn } from '@/lib/utils'
import { ROUTES } from '@/lib/constants'
import { User, Settings, ChevronDown, LogIn, LogOut, Code2 } from 'lucide-react'
import { useAuthStore, selectIsAuthenticated, selectAuthDisabled, selectLogout } from '@/stores/auth'
import { useAppConfigStore, selectAppName } from '@/stores/app-config'

const navItems = [
  { name: 'Workspace', href: ROUTES.WORKSPACE },
  { name: 'Builder', href: ROUTES.BUILDER },
  { name: 'Machines', href: ROUTES.MACHINES },
  { name: 'Entities', href: ROUTES.ENTITIES },
  { name: 'Discovery', href: ROUTES.DISCOVERY },
]

function isNavActive(pathname: string, href: string): boolean {
  if (href === ROUTES.ENTITIES) {
    return pathname.startsWith('/entities')
  }
  return pathname === href
}

export default function Navigation() {
  const pathname = usePathname()
  const router = useRouter()
  const appName = useAppConfigStore(selectAppName)
  const isAuthenticated = useAuthStore(selectIsAuthenticated)
  const authDisabled = useAuthStore(selectAuthDisabled)
  const logout = useAuthStore(selectLogout)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [accountMenuOpen, setAccountMenuOpen] = useState(false)
  const accountMenuRef = useRef<HTMLDivElement>(null)
  const showAccountMenu = isAuthenticated || authDisabled

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (accountMenuRef.current && !accountMenuRef.current.contains(e.target as Node))
        setAccountMenuOpen(false)
    }
    if (accountMenuOpen) document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [accountMenuOpen])

  return (
    <nav className="border-b bg-background sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href={ROUTES.HOME} className="flex items-center">
              <span className="text-xl font-bold text-primary">{appName}</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              {navItems.map((item) => {
                const isActive = isNavActive(pathname, item.href)
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors',
                      isActive
                        ? 'border-primary text-foreground'
                        : 'border-transparent text-muted-foreground hover:border-gray-300 hover:text-foreground'
                    )}
                  >
                    {item.name}
                  </Link>
                )
              })}
            </div>
          </div>
          {/* Single user icon with dropdown (Settings + Login or Logout), mirroring pycharter */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:block relative" ref={accountMenuRef}>
              <button
                type="button"
                onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                className="inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary transition-colors"
                aria-expanded={accountMenuOpen}
                aria-haspopup="true"
              >
                <User className="h-5 w-5" />
                <ChevronDown
                  className={cn('h-4 w-4 transition-transform', accountMenuOpen && 'rotate-180')}
                />
              </button>
              {accountMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-background border border-border ring-1 ring-black ring-opacity-5 z-50">
                  <div className="py-1" role="menu" aria-orientation="vertical">
                    <Link
                      href={ROUTES.DOCUMENTATION}
                      onClick={() => setAccountMenuOpen(false)}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                      role="menuitem"
                    >
                      <Code2 className="h-4 w-4" />
                      API Playground
                    </Link>
                    <Link
                      href={ROUTES.SETTINGS}
                      onClick={() => setAccountMenuOpen(false)}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                      role="menuitem"
                    >
                      <Settings className="h-4 w-4" />
                      Settings
                    </Link>
                    {isAuthenticated ? (
                      <button
                        type="button"
                        onClick={() => {
                          setAccountMenuOpen(false)
                          logout()
                          router.push(ROUTES.LOGIN)
                        }}
                        className="flex w-full items-center gap-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                        role="menuitem"
                      >
                        <LogOut className="h-4 w-4" />
                        Log out
                      </button>
                    ) : (
                      <Link
                        href={ROUTES.LOGIN}
                        onClick={() => setAccountMenuOpen(false)}
                        className="flex items-center gap-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                        role="menuitem"
                      >
                        <LogIn className="h-4 w-4" />
                        Log in
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="flex sm:hidden">
              <button
                type="button"
                onClick={() => setMobileOpen(!mobileOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
                aria-controls="mobile-menu"
                aria-expanded={mobileOpen}
              >
                <span className="sr-only">Open main menu</span>
                {mobileOpen ? (
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
      {mobileOpen && (
        <div className="sm:hidden" id="mobile-menu">
          <div className="pt-2 pb-3 space-y-1 px-4 border-t">
            {navItems.map((item) => {
              const isActive = isNavActive(pathname, item.href)
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    'block px-3 py-2 rounded-md text-base font-medium transition-colors',
                    isActive
                      ? 'bg-primary/10 text-primary border-l-4 border-primary'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  {item.name}
                </Link>
              )
            })}
            <div className="border-t border-border mt-2 pt-2">
              <Link
                href={ROUTES.DOCUMENTATION}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
              >
                <Code2 className="h-5 w-5" />
                API Playground
              </Link>
              <Link
                href={ROUTES.SETTINGS}
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
              >
                <Settings className="h-5 w-5" />
                Settings
              </Link>
              {isAuthenticated ? (
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false)
                    logout()
                    router.push(ROUTES.LOGIN)
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                  Log out
                </button>
              ) : (
                <Link
                  href={ROUTES.LOGIN}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                >
                  <LogIn className="h-5 w-5" />
                  Log in
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
