'use client'

import { useMemo, useEffect, useState, useCallback, type CSSProperties } from 'react'
import {
  ReactFlow,
  Controls,
  Background,
  BackgroundVariant,
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  useReactFlow,
  type Node,
  type Edge,
} from '@xyflow/react'
import '@xyflow/react/dist/base.css'
import '@xyflow/react/dist/style.css'
import {
  fsmConfigToReactFlow,
  type FsmFlowOptions,
  type NodeData,
  type EdgeLabelData,
} from '@/lib/fsmToReactFlow'
import type { FSMConfig } from '@/lib/types/fsm'
import { CompoundStateNode } from './CompoundStateNode'
import { FsmDiagramFocusProvider } from './FsmDiagramFocusContext'
import { EdgeWithLabel } from './EdgeWithLabel'
import { StateNode } from './StateNode'
import type { PaletteDragPayload } from '@/components/workspace/paletteDnd'
import { useDiagramInteraction, type FsmDiagramSelection } from './useDiagramInteraction'
import { TransitionTriggerPopover } from './TransitionTriggerPopover'

const edgeTypes = { smoothstep: EdgeWithLabel }
const nodeTypes = { state: StateNode, compound: CompoundStateNode }

export type { FsmDiagramSelection }

/**
 * Merge layout nodes with current node positions so that:
 * - Data and style (e.g. highlight) come from the latest layout.
 * - Positions are preserved from current nodes when present (user may have dragged).
 * This prevents the diagram from jumping back to default layout after processing an event.
 */
function mergeNodesWithCurrentPositions(
  layoutNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes'],
  currentNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
): ReturnType<typeof fsmConfigToReactFlow>['nodes'] {
  const currentById = new Map(currentNodes.map((n) => [n.id, n]))
  return layoutNodes.map((layoutNode) => {
    const current = currentById.get(layoutNode.id)
    if (current) {
      // If the layout node has an explicit saved position (from the
      // layout API or a collab update), prefer it over the current
      // canvas position.  Otherwise keep the user's drag position.
      const savedPos = (layoutNode.data as { diagramPosition?: { x: number; y: number } }).diagramPosition
      const useLayoutPos = savedPos && (
        Math.abs(savedPos.x - current.position.x) > 1 ||
        Math.abs(savedPos.y - current.position.y) > 1
      )
      return {
        ...layoutNode,
        position: useLayoutPos ? layoutNode.position : (current.position ?? layoutNode.position),
        selected: current.selected,
      }
    }
    return layoutNode
  })
}

export interface FsmFlowDiagramProps {
  config: FSMConfig
  /** Minimum height of the diagram container */
  minHeight?: number | string
  /** Show guards on edge labels (default true) */
  showGuards?: boolean
  /** Show actions on edge labels (default false) */
  showActions?: boolean
  /** Show hierarchy indicators (parent/child, parallel regions) (default true) */
  showHierarchy?: boolean
  /** Externally stored diagram positions (from layout API). Overrides metadata positions. */
  savedPositions?: Record<string, { x: number; y: number }>
  /** Minimal state nodes: title only (default false) */
  plainNodes?: boolean
  /** Highlight this transition (e.g. last transition) */
  highlightTransition?: { source: string; target: string; trigger: string } | null
  /** Highlight this state as current (entity instance "you are here") */
  highlightState?: string | null
  /** Optional class name for the wrapper */
  className?: string
  /** Enable editing mode: double-click, drag-to-connect, delete */
  editable?: boolean
  /** Called when user double-clicks canvas (for adding a state). Receives flow position {x, y}. */
  onPaneDoubleClick?: (position: { x: number; y: number }) => void
  /** Called when user double-clicks a state node. Receives the original state name. */
  onNodeDoubleClick?: (stateName: string) => void
  /**
   * Called when user double-clicks a transition edge (stroke) or label. Second arg lists all
   * transition indices merged on that edge when applicable.
   */
  onEdgeDoubleClick?: (transitionIndex: number, groupedIndices?: number[]) => void
  /**
   * Single-click on a transition label: parent should update the inspector only if already open
   * (see workspace `handleEdgeTransitionPick`).
   */
  onEdgeTransitionPick?: (transitionIndex: number, groupedIndices?: number[]) => void
  /**
   * Called when user finishes connecting two states. Third argument is the normalized trigger from
   * the inline popover; omit the third argument if the parent should open the transition inspector instead.
   */
  onConnect?: (sourceName: string, destName: string, initialTrigger?: string) => void
  /** Called when user presses Delete on selected state nodes. Receives array of state names. */
  onNodesDelete?: (stateNames: string[]) => void
  /** Called when user presses Delete on selected edges. Receives array of transition indices. */
  onEdgesDelete?: (transitionIndices: number[]) => void
  /** Called when user finishes dragging one or more nodes. Receives a map of stateName → position. */
  onNodeDragStop?: (positions: Map<string, { x: number; y: number }>) => void
  /** Drop from Components palette onto the canvas (same semantics as clicking a palette row). */
  onPaletteDrop?: (
    payload: PaletteDragPayload,
    flowPosition: { x: number; y: number } | null
  ) => void
  /** Selection changes from the diagram canvas (single node, single edge, or cleared). */
  onDiagramSelectionChange?: (selection: FsmDiagramSelection) => void
  /**
   * Programmatically select a node by id (state name). Bump `token` for each new request.
   * Parent should clear or advance after `onDiagramSelectRequestHandled`.
   */
  diagramSelectRequest?: { nodeId: string; token: number } | null
  onDiagramSelectRequestHandled?: () => void
  /** Increment to clear all node/edge selection (e.g. inspector closed from outside the canvas). */
  clearDiagramSelectionNonce?: number
  /** Optional workspace annotations (state-anchored). */
  annotations?: {
    enabled: boolean
    statesWithNotes: Set<string>
    openStateName?: string
    getBody: (stateName: string) => string
    saving: boolean
    deleting: boolean
    machineName: string
    machineVersion: string
    onOpen: (stateName: string) => void
    onClose: () => void
    onSave: (stateName: string, body: string) => void
    onDelete: (stateName: string) => void
  }
  /** Optional ops badges (counts/age/errors) for state nodes. */
  opsMetrics?: {
    enabled: boolean
    /** Keyed by state name. */
    metricsByState: Record<
      string,
      {
        entity_count: number
        age_p95_seconds: number | null
        failed_transition_count: number
        age_buckets?: { le_5m: number; le_30m: number; gt_30m: number }
        top_error?: { error_type: string | null; error_message: string | null; count: number } | null
      }
    >
  }
  /** Optional transition notes (trigger/source/dest-anchored). */
  transitionNotes?: {
    enabled: boolean
    openKey?: string
    getBody: (transitionKey: string) => string
    saving: boolean
    deleting: boolean
    machineName: string
    machineVersion: string
    onOpen: (transitionKey: string) => void
    onClose: () => void
    onSave: (transitionKey: string, body: string) => void
    onDelete: (transitionKey: string) => void
    keysWithNotes: Set<string>
  }
}

export type { PaletteDragPayload }

type FsmFlowDiagramInnerProps = FsmFlowDiagramProps & {
  initialNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
  initialEdges: ReturnType<typeof fsmConfigToReactFlow>['edges']
}

function FsmFlowDiagramInner({
  initialNodes,
  initialEdges,
  config,
  minHeight = 480,
  className = '',
  editable = false,
  onPaneDoubleClick,
  onNodeDoubleClick,
  onEdgeDoubleClick,
  onConnect,
  onNodesDelete,
  onEdgesDelete,
  onNodeDragStop,
  onPaletteDrop,
  onDiagramSelectionChange,
  diagramSelectRequest,
  onDiagramSelectRequestHandled,
  clearDiagramSelectionNonce = 0,
}: FsmFlowDiagramInnerProps) {
  const reactFlow = useReactFlow<Node<NodeData>, Edge<EdgeLabelData>>()
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const [pendingTriggerConnect, setPendingTriggerConnect] = useState<{
    sourceName: string
    destName: string
    screenPos: { x: number; y: number }
  } | null>(null)

  useEffect(() => {
    setNodes((current) => mergeNodesWithCurrentPositions(initialNodes, current))
    setEdges((currentEdges) => {
      const currentById = new Map(currentEdges.map((e) => [e.id, e]))
      return initialEdges.map((e) => {
        const cur = currentById.get(e.id)
        if (cur?.selected) return { ...e, selected: cur.selected }
        return e
      })
    })
  }, [initialNodes, initialEdges, setNodes, setEdges])

  const onConnectIntercept = useCallback(
    (ctx: {
      sourceName: string
      destName: string
      sourceNode: Node<NodeData>
      targetNode: Node<NodeData>
    }) => {
      const { sourceName, destName, targetNode } = ctx
      const screenPos = reactFlow.flowToScreenPosition({
        x: targetNode.position.x,
        y: targetNode.position.y,
      })
      setPendingTriggerConnect({ sourceName, destName, screenPos })
      return true
    },
    [reactFlow],
  )

  const handleTriggerPopoverConfirm = useCallback(
    (initialTrigger: string) => {
      if (!pendingTriggerConnect || !onConnect) return
      const { sourceName, destName } = pendingTriggerConnect
      setPendingTriggerConnect(null)
      onConnect(sourceName, destName, initialTrigger)
    },
    [pendingTriggerConnect, onConnect],
  )

  const handleTriggerPopoverCancel = useCallback(() => {
    setPendingTriggerConnect(null)
  }, [])

  const handleNodeDragStop = useCallback(
    (_event: React.MouseEvent, _node: Node<NodeData>, draggedNodes: Node<NodeData>[]) => {
      if (!onNodeDragStop || draggedNodes.length === 0) return
      const positions = new Map<string, { x: number; y: number }>()
      for (const n of draggedNodes) {
        const name = (n.data as NodeData).stateName ?? n.id
        positions.set(name, { x: n.position.x, y: n.position.y })
      }
      onNodeDragStop(positions)
    },
    [onNodeDragStop],
  )

  const interaction = useDiagramInteraction({
    config,
    editable,
    nodes,
    setNodes,
    setEdges,
    onPaneDoubleClick,
    onNodeDoubleClick,
    onEdgeDoubleClick,
    onConnect,
    onConnectIntercept: editable && onConnect ? onConnectIntercept : undefined,
    onNodesDelete,
    onEdgesDelete,
    onPaletteDrop,
    onDiagramSelectionChange,
    diagramSelectRequest,
    onDiagramSelectRequestHandled,
    clearDiagramSelectionNonce,
  })

  const isPercent = typeof minHeight === 'string' && minHeight.endsWith('%')
  const heightValue: number | string =
    typeof minHeight === 'number'
      ? minHeight
      : typeof minHeight === 'string' && minHeight.endsWith('px')
        ? parseInt(minHeight, 10) || 480
        : isPercent
          ? minHeight
          : 480
  const containerStyle: CSSProperties = {
    width: '100%',
    height: heightValue,
    minHeight: heightValue,
    position: 'relative',
  }

  const emptyDiagram = !config.states?.length
  const showEmptyFlow =
    emptyDiagram && editable && onPaletteDrop
  const heightPx =
    typeof heightValue === 'number' ? heightValue : parseInt(String(heightValue), 10) || 480

  if (emptyDiagram && !showEmptyFlow) {
    return (
      <div
        className={`flex items-center justify-center rounded border bg-muted/30 ${className}`}
        style={containerStyle}
      >
        <p className="text-muted-foreground text-sm">
          Add at least one state to see the diagram.
        </p>
      </div>
    )
  }

  return (
    <div className={`relative rounded border bg-muted/30 ${className}`} style={containerStyle}>
      {showEmptyFlow && (
        <p className="pointer-events-none absolute left-1/2 top-1/2 z-[1] max-w-[min(100%,20rem)] -translate-x-1/2 -translate-y-1/2 text-center text-muted-foreground text-sm">
          Double-click to add a state, drag components from the sidebar, or use the Components tab.
        </p>
      )}
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        defaultEdgeOptions={{ type: 'smoothstep' }}
        height={heightPx}
        fitView={!emptyDiagram}
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.2}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
        nodesDraggable
        nodesConnectable={editable}
        elementsSelectable
        panOnDrag
        zoomOnScroll
        zoomOnPinch
        onPaneClick={interaction.clearFocus}
        onNodeClick={interaction.handleNodeClick}
        onEdgeClick={interaction.handleEdgeClick}
        onDoubleClick={editable ? interaction.handlePaneDoubleClick : undefined}
        onNodeDoubleClick={editable ? interaction.handleNodeDoubleClick : undefined}
        onEdgeDoubleClick={editable ? interaction.handleEdgeDoubleClick : undefined}
        onConnect={editable ? interaction.handleConnect : undefined}
        onNodesDelete={editable ? interaction.handleNodesDeleteCb : undefined}
        onEdgesDelete={editable ? interaction.handleEdgesDeleteCb : undefined}
        onNodeDragStop={onNodeDragStop ? handleNodeDragStop : undefined}
        onBeforeDelete={editable ? interaction.handleBeforeDelete : undefined}
        deleteKeyCode={editable ? ['Backspace', 'Delete'] : []}
        onDragOver={editable && onPaletteDrop ? interaction.handlePaletteDragOver : undefined}
        onDrop={editable && onPaletteDrop ? interaction.handlePaletteDrop : undefined}
        onSelectionChange={
          editable && onDiagramSelectionChange ? interaction.handleSelectionChange : undefined
        }
      >
        <Controls showInteractive={false} />
        <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
      </ReactFlow>
      {pendingTriggerConnect ? (
        <TransitionTriggerPopover
          open
          position={{
            x: pendingTriggerConnect.screenPos.x + 8,
            y: pendingTriggerConnect.screenPos.y + 8,
          }}
          sourceState={pendingTriggerConnect.sourceName}
          destState={pendingTriggerConnect.destName}
          onConfirm={handleTriggerPopoverConfirm}
          onCancel={handleTriggerPopoverCancel}
        />
      ) : null}
    </div>
  )
}

export default function FsmFlowDiagram(props: FsmFlowDiagramProps) {
  const {
    config,
    showGuards = true,
    showActions = false,
    showHierarchy = true,
    plainNodes = false,
    highlightTransition = null,
    highlightState = null,
    savedPositions,
    annotations,
    opsMetrics,
    transitionNotes,
  } = props

  const options: FsmFlowOptions = {
    showGuards,
    showActions,
    showHierarchy,
    plainNodes,
    highlightTransition,
    highlightState,
    positions: savedPositions,
  }

  const { nodes: initialNodes, edges: initialEdges } = useMemo(
    () => {
      const onEdgeDbl = props.onEdgeDoubleClick
      const onEdgePick = props.onEdgeTransitionPick
      const base = fsmConfigToReactFlow(config, options)
      const buildTransitionKey = (idx: number): string | null => {
        const t = (config.transitions ?? [])[idx]
        if (!t) return null
        const src = Array.isArray(t.source) ? t.source : [t.source]
        const srcKey = src.map((s) => String(s)).sort().join('|')
        const trigger = String(t.trigger ?? '')
        const dest = String(t.dest ?? '')
        return `${srcKey}::${trigger}::${dest}`
      }

      const edges = base.edges.map((e) => {
        const data = (e.data ?? {}) as EdgeLabelData
        const idx = data.transitionIndex
        const key = idx != null ? buildTransitionKey(idx) : null
        const grouped = data.groupedTransitions
        const groupedIndices =
          grouped && grouped.length >= 2
            ? [...grouped].map((r) => r.transitionIndex).sort((a, b) => a - b)
            : undefined
        const nextData: EdgeLabelData = {
          ...data,
          onOpenTransition:
            onEdgeDbl != null ? (tIdx: number) => onEdgeDbl(tIdx, groupedIndices) : undefined,
          onPickTransition:
            onEdgePick != null ? (tIdx: number) => onEdgePick(tIdx, groupedIndices) : undefined,
          ...(props.plainNodes ? { plainMode: true as const } : {}),
        }
        if (transitionNotes?.enabled && key) {
          const body = transitionNotes.getBody(key)
          nextData.transitionNoteEnabled = true
          nextData.transitionNoteKey = key
          nextData.hasTransitionNote = transitionNotes.keysWithNotes.has(key)
          nextData.transitionNoteOpen = transitionNotes.openKey === key
          nextData.transitionNoteBody = body
          nextData.transitionNoteInitialBody = body
          nextData.transitionNoteSaving = transitionNotes.saving
          nextData.transitionNoteDeleting = transitionNotes.deleting
          nextData.transitionNoteMachineName = transitionNotes.machineName
          nextData.transitionNoteMachineVersion = transitionNotes.machineVersion
          nextData.onOpenTransitionNote = transitionNotes.onOpen
          nextData.onCloseTransitionNote = transitionNotes.onClose
          nextData.onSaveTransitionNote = (b: string) => transitionNotes.onSave(key, b)
          nextData.onDeleteTransitionNote = () => transitionNotes.onDelete(key)
        }
        return { ...e, data: nextData }
      })
      const nodes = base.nodes.map((n) => {
        const baseData = (n.data ?? {}) as NodeData
        const stateName = baseData.stateName
        const nextData: NodeData = { ...baseData }

        if (annotations?.enabled) {
          const set = annotations.statesWithNotes
          const has = !!(stateName && set.has(stateName))
          const isOpen = !!(stateName && annotations.openStateName && stateName === annotations.openStateName)
          const body = stateName ? annotations.getBody(stateName) : ''
          nextData.annotationEnabled = true
          nextData.hasAnnotation = has
          nextData.annotationOpen = isOpen
          nextData.annotationBody = body
          nextData.annotationInitialBody = body
          nextData.annotationSaving = annotations.saving
          nextData.annotationDeleting = annotations.deleting
          nextData.annotationMachineName = annotations.machineName
          nextData.annotationMachineVersion = annotations.machineVersion
          nextData.onOpenAnnotation = annotations.onOpen
          nextData.onCloseAnnotation = annotations.onClose
          nextData.onSaveAnnotation = (b: string) => {
            if (!stateName) return
            annotations.onSave(stateName, b)
          }
          nextData.onDeleteAnnotation = () => {
            if (!stateName) return
            annotations.onDelete(stateName)
          }
        }

        if (!props.plainNodes && opsMetrics?.enabled && stateName) {
          const m = opsMetrics.metricsByState[stateName]
          if (m) {
            nextData.opsBadges = {
              entityCount: m.entity_count,
              ageP95Seconds: m.age_p95_seconds,
              failedTransitionCount: m.failed_transition_count,
              ageBuckets: m.age_buckets,
              topError: m.top_error,
            }
          }
        }

        return { ...n, data: nextData }
      })
      return { ...base, nodes, edges }
    },
    [
      config,
      savedPositions,
      showGuards,
      showActions,
      showHierarchy,
      plainNodes,
      highlightTransition,
      highlightState,
      props.onEdgeDoubleClick,
      props.onEdgeTransitionPick,
      annotations?.enabled,
      annotations?.onOpen,
      annotations?.onClose,
      annotations?.onSave,
      annotations?.onDelete,
      annotations?.openStateName,
      annotations?.getBody,
      annotations?.saving,
      annotations?.deleting,
      annotations?.machineName,
      annotations?.machineVersion,
      annotations?.statesWithNotes,
      opsMetrics?.enabled,
      opsMetrics?.metricsByState,
      transitionNotes?.enabled,
      transitionNotes?.openKey,
      transitionNotes?.getBody,
      transitionNotes?.saving,
      transitionNotes?.deleting,
      transitionNotes?.machineName,
      transitionNotes?.machineVersion,
      transitionNotes?.onOpen,
      transitionNotes?.onClose,
      transitionNotes?.onSave,
      transitionNotes?.onDelete,
      transitionNotes?.keysWithNotes,
      props.editable,
    ]
  )

  return (
    <ReactFlowProvider>
      <FsmDiagramFocusProvider resetSignal={initialEdges}>
        <FsmFlowDiagramInner {...props} initialNodes={initialNodes} initialEdges={initialEdges} />
      </FsmDiagramFocusProvider>
    </ReactFlowProvider>
  )
}
