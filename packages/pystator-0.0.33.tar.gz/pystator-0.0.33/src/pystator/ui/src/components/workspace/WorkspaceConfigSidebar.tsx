'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import {
  ChevronDown,
  ChevronUp,
  Plus,
  Settings2,
  GitBranch,
  ArrowRightLeft,
  AlertCircle,
  FileCode2,
  Play,
  FolderOpen,
  LayoutGrid,
  Braces,
} from 'lucide-react'
import {
  SidebarHeaderWithToggle,
  type SidebarDisplayMode,
  type SidebarLayoutApi,
} from '@/components/layout'
import {
  useWorkspaceStore,
  selectConfig,
  selectSetConfig,
  selectValidationResult,
  selectSetValidationResult,
  selectDiagramShowGuards,
  selectSetDiagramShowGuards,
  selectDiagramShowActions,
  selectSetDiagramShowActions,
  selectDiagramShowOpsBadges,
  selectSetDiagramShowOpsBadges,
  selectDiagramPlainNodes,
  selectSetDiagramPlainNodes,
  selectDiagramHighlightState,
  selectDiagramHighlightTransition,
  selectSetDiagramHighlightState,
  selectSetDiagramHighlightTransition,
} from '@/stores/workspace'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import ErrorDisplay from '@/components/ErrorDisplay'
import TestSidebarContent from './TestSidebarContent'
import { MachineBrowseContent } from './MachineBrowseContent'
import PalettePanel from './PalettePanel'
import ConfigRawSidebarContent from './ConfigRawSidebarContent'
import { validateConfig, ApiError, type MachineListItem } from '@/lib/api'
import type { FSMConfig, FSMState, FSMTransition } from '@/lib/types/fsm'
import { parseSource } from './ConfigHelpers'
import { collectAllRegionNames } from '@/lib/fsm/regionUtils'
import { stableConfigFingerprint } from '@/lib/fsm/stableConfigFingerprint'
import { StateModal, TransitionModal, ErrorPolicyModal } from '@/components/modals'
import {
  ConfigMetaSection,
  ConfigStatesSection,
  ConfigTransitionsSection,
  ConfigErrorPolicySection,
} from './sections'
import type {
  StatePaletteBlockId,
  TemplatePaletteId,
  TransitionPaletteBlockId,
} from '@/components/workspace/paletteDefs'

const SECTION_IDS = ['meta', 'states', 'transitions', 'error_policy'] as const

const VALIDATE_DEBOUNCE_MS = 2000

type SidebarMode = 'browse' | 'components' | 'form' | 'config' | 'test'

export interface WorkspaceConfigSidebarProps extends SidebarLayoutApi {
  /** Full machine list from API (optional; browse uses `machines`). */
  machineList?: MachineListItem[]
  machinesLoading?: boolean
  machineLoadError?: string | null
  machines?: { name: string; namespace?: string | null }[]
  selectedMachineName?: string | null
  onMachineNameSelect?: (name: string) => void
  onCreateMachineFromScratch?: () => void
  onSelectStateBlock?: (id: StatePaletteBlockId) => void
  onSelectTransitionBlock?: (id: TransitionPaletteBlockId) => void
  onApplyTemplate?: (id: TemplatePaletteId) => void
}

export default function WorkspaceConfigSidebar({
  isPanelCollapsed: isPanelCollapsedProp,
  sidebarDisplayMode = 'expanded',
  onCollapseRequested,
  onExpandRequested,
  machineList: _machineList,
  machinesLoading = false,
  machineLoadError = null,
  machines = [],
  selectedMachineName = null,
  onMachineNameSelect,
  onCreateMachineFromScratch,
  onSelectStateBlock,
  onSelectTransitionBlock,
  onApplyTemplate,
}: WorkspaceConfigSidebarProps) {
  void _machineList
  const isCompact = sidebarDisplayMode === 'compact'
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const validationResult = useWorkspaceStore(selectValidationResult)
  const setValidationResult = useWorkspaceStore(selectSetValidationResult)
  const setDiagramShowGuards = useWorkspaceStore(selectSetDiagramShowGuards)
  const setDiagramShowActions = useWorkspaceStore(selectSetDiagramShowActions)
  const diagramShowGuards = useWorkspaceStore(selectDiagramShowGuards)
  const diagramShowActions = useWorkspaceStore(selectDiagramShowActions)
  const diagramShowOpsBadges = useWorkspaceStore(selectDiagramShowOpsBadges)
  const setDiagramShowOpsBadges = useWorkspaceStore(selectSetDiagramShowOpsBadges)
  const diagramPlainNodes = useWorkspaceStore(selectDiagramPlainNodes)
  const setDiagramPlainNodes = useWorkspaceStore(selectSetDiagramPlainNodes)
  const diagramHighlightState = useWorkspaceStore(selectDiagramHighlightState)
  const diagramHighlightTransition = useWorkspaceStore(selectDiagramHighlightTransition)
  const setDiagramHighlightState = useWorkspaceStore(selectSetDiagramHighlightState)
  const setDiagramHighlightTransition = useWorkspaceStore(selectSetDiagramHighlightTransition)

  const [isCollapsedInternal, setIsCollapsedInternal] = useState(false)
  const isCollapsed = isPanelCollapsedProp !== undefined ? isPanelCollapsedProp : isCollapsedInternal
  const [sidebarMode, setSidebarMode] = useState<SidebarMode>('config')
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(SECTION_IDS))
  const [error, setError] = useState<Error | ApiError | null>(null)
  const [validating, setValidating] = useState(false)
  const [stateModalOpen, setStateModalOpen] = useState(false)
  const [stateModalIndex, setStateModalIndex] = useState<number | null>(null)
  const [transitionModalOpen, setTransitionModalOpen] = useState(false)
  const [transitionModalIndex, setTransitionModalIndex] = useState<number | null>(null)
  const [errorPolicyModalOpen, setErrorPolicyModalOpen] = useState(false)
  const validateTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  /** Server rules can change without config change; user can force re-validate via button. */
  const lastValidatedFingerprintRef = useRef<string | null>(null)
  const lastValidationSnapshotRef = useRef<{ valid: boolean; errors: string[] } | null>(null)
  const validateGenerationRef = useRef(0)

  const states: FSMState[] = config.states ?? []
  const transitions = config.transitions ?? []
  const stateNames = states.map((s) => s.name)
  const regionNames = collectAllRegionNames(states)

  const updateConfig = useCallback(
    (updater: (c: FSMConfig) => FSMConfig) => {
      setConfig((prev) => updater({ ...prev }))
      setValidationResult(null)
    },
    [setConfig, setValidationResult]
  )

  const setMeta = useCallback(
    (field: 'machine_name' | 'version', value: string) => {
      updateConfig((c) => ({ ...c, meta: { ...c.meta, [field]: value } }))
    },
    [updateConfig]
  )

  const runValidate = useCallback(
    async (options?: { force?: boolean }) => {
      const fingerprint = stableConfigFingerprint(config)
      if (
        !options?.force &&
        lastValidatedFingerprintRef.current === fingerprint &&
        lastValidationSnapshotRef.current
      ) {
        setError(null)
        setValidationResult(lastValidationSnapshotRef.current)
        return
      }

      validateGenerationRef.current += 1
      const gen = validateGenerationRef.current
      setError(null)
      setValidating(true)
      try {
        const res = await validateConfig(config)
        if (gen !== validateGenerationRef.current) return
        const snapshot = { valid: res.valid, errors: res.errors ?? [] }
        setValidationResult(snapshot)
        lastValidatedFingerprintRef.current = stableConfigFingerprint(config)
        lastValidationSnapshotRef.current = snapshot
      } catch (e) {
        if (gen !== validateGenerationRef.current) return
        setError(e instanceof ApiError ? e : new Error(String(e)))
      } finally {
        if (gen === validateGenerationRef.current) {
          setValidating(false)
        }
      }
    },
    [config, setValidationResult],
  )

  useEffect(() => {
    if (validateTimeoutRef.current) clearTimeout(validateTimeoutRef.current)
    validateTimeoutRef.current = setTimeout(() => {
      void runValidate()
    }, VALIDATE_DEBOUNCE_MS)
    return () => {
      if (validateTimeoutRef.current) clearTimeout(validateTimeoutRef.current)
    }
  }, [config, runValidate])

  const addState = useCallback(
    (state: FSMState) => {
      updateConfig((c) => ({ ...c, states: [...(c.states ?? []), state] }))
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const updateState = useCallback(
    (index: number, state: FSMState) => {
      updateConfig((c) => {
        const st = [...(c.states ?? [])]
        st[index] = state
        return { ...c, states: st }
      })
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const removeState = useCallback(
    (index: number) => {
      updateConfig((c) => ({
        ...c,
        states: (c.states ?? []).filter((_, i) => i !== index),
        transitions: (c.transitions ?? []).filter((t) => {
          const src = parseSource(t.source)
          const dest = t.dest
          const name = (c.states ?? [])[index]?.name
          return name && !src.includes(name) && dest !== name
        }),
      }))
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const addTransition = useCallback(
    (t: FSMTransition) => {
      const source = parseSource(t.source)
      const normalized: FSMTransition = { ...t, source: source.length === 1 ? source[0] : source }
      updateConfig((c) => ({ ...c, transitions: [...(c.transitions ?? []), normalized] }))
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const updateTransition = useCallback(
    (index: number, t: FSMTransition) => {
      const source = parseSource(t.source)
      const normalized: FSMTransition = { ...t, source: source.length === 1 ? source[0] : source }
      updateConfig((c) => {
        const tr = [...(c.transitions ?? [])]
        tr[index] = normalized
        return { ...c, transitions: tr }
      })
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const removeTransition = useCallback(
    (index: number) => {
      updateConfig((c) => ({ ...c, transitions: (c.transitions ?? []).filter((_, i) => i !== index) }))
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev)
      if (next.has(sectionId)) next.delete(sectionId)
      else next.add(sectionId)
      return next
    })
  }

  const stateModalState: FSMState =
    stateModalIndex !== null && states[stateModalIndex] ? states[stateModalIndex] : { name: '', type: 'stable' }
  const transitionModalTransition: FSMTransition =
    transitionModalIndex !== null && transitions[transitionModalIndex]
      ? transitions[transitionModalIndex]
      : { trigger: '', source: '', dest: stateNames[0] ?? '' }

  const sections: { id: string; title: string; icon: typeof Settings2 }[] = [
    { id: 'meta', title: 'Meta', icon: Settings2 },
    { id: 'states', title: 'States', icon: GitBranch },
    { id: 'transitions', title: 'Transitions', icon: ArrowRightLeft },
    { id: 'error_policy', title: 'Error policy', icon: AlertCircle },
  ]

  const modeTabs: { id: SidebarMode; label: string; icon: typeof Settings2 }[] = [
    { id: 'browse', label: 'Browse', icon: FolderOpen },
    { id: 'components', label: 'Components', icon: LayoutGrid },
    { id: 'form', label: 'Form', icon: Braces },
    { id: 'config', label: 'Config', icon: FileCode2 },
    { id: 'test', label: 'Test', icon: Play },
  ]

  const headerDisplayMode: SidebarDisplayMode = isCollapsed ? 'collapsed' : sidebarDisplayMode

  return (
    <>
      <div
        className="flex flex-col bg-background border-r border-border/50 shadow-sm transition-all duration-300 w-full min-w-0"
        style={{ height: '100%', overflow: 'hidden' }}
      >
        <SidebarHeaderWithToggle
          isCollapsed={isCollapsed}
          displayMode={headerDisplayMode}
          onToggle={() => {
            if (isCollapsed) {
              onExpandRequested?.()
              if (isPanelCollapsedProp === undefined) setIsCollapsedInternal(false)
            } else {
              onCollapseRequested?.()
              if (isPanelCollapsedProp === undefined) setIsCollapsedInternal(true)
            }
          }}
        >
          <div className="min-w-0 flex-1 overflow-x-auto">
            <div
              className="flex w-max rounded-lg border border-border/70 bg-background/50 p-0.5"
              role="tablist"
              aria-label="Sidebar mode"
            >
              {modeTabs.map((tab) => {
                const disabled =
                  (tab.id === 'browse' && !onMachineNameSelect) ||
                  (tab.id === 'components' &&
                    (!onSelectStateBlock || !onSelectTransitionBlock || !onApplyTemplate))
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-label={tab.label}
                    aria-selected={sidebarMode === tab.id}
                    disabled={disabled}
                    onClick={() => setSidebarMode(tab.id)}
                    title={disabled ? `${tab.label} unavailable` : tab.label}
                    className={cn(
                      'inline-flex h-7 shrink-0 items-center rounded-md text-xs font-medium transition-colors',
                      isCompact ? 'justify-center px-2 w-7' : 'gap-1.5 px-2.5 py-1.5',
                      sidebarMode === tab.id
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground',
                      disabled && 'opacity-40 pointer-events-none'
                    )}
                  >
                    <tab.icon className="h-3.5 w-3.5" />
                    {!isCompact && <span className="whitespace-nowrap">{tab.label}</span>}
                  </button>
                )
              })}
            </div>
          </div>
        </SidebarHeaderWithToggle>

        <div
          className={cn(
            'flex-1 min-h-0 flex flex-col',
            isCollapsed || sidebarMode === 'config' ? 'overflow-y-auto overflow-x-hidden' : 'overflow-hidden'
          )}
        >
          {!isCollapsed && sidebarMode === 'test' ? (
            <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-2 py-3">
              <TestSidebarContent />
            </div>
          ) : null}
          {!isCollapsed && sidebarMode === 'browse' && onMachineNameSelect ? (
            <div className="flex-1 min-h-0 flex flex-col overflow-hidden px-2 py-3">
              <MachineBrowseContent
                machines={machines}
                selectedMachineName={selectedMachineName}
                onMachineNameSelect={onMachineNameSelect}
                onCreateMachineFromScratch={onCreateMachineFromScratch}
                loading={machinesLoading}
                error={machineLoadError}
              />
            </div>
          ) : null}
          {!isCollapsed && sidebarMode === 'browse' && !onMachineNameSelect ? (
            <div className="px-2 py-3 text-xs text-muted-foreground">Machine browser is unavailable.</div>
          ) : null}
          {!isCollapsed &&
          sidebarMode === 'components' &&
          onSelectStateBlock &&
          onSelectTransitionBlock &&
          onApplyTemplate ? (
            <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-2 py-3">
              <PalettePanel
                onSelectStateBlock={onSelectStateBlock}
                onSelectTransitionBlock={onSelectTransitionBlock}
                onApplyTemplate={onApplyTemplate}
                className="w-full max-w-none border-border/60 bg-background/80 p-2 shadow-none backdrop-blur-none"
              />
            </div>
          ) : null}
          {!isCollapsed &&
          sidebarMode === 'components' &&
          (!onSelectStateBlock || !onSelectTransitionBlock || !onApplyTemplate) ? (
            <div className="px-2 py-3 text-xs text-muted-foreground">Components palette is unavailable.</div>
          ) : null}
          {!isCollapsed && sidebarMode === 'form' ? (
            <div className="flex-1 min-h-0 flex flex-col px-2 py-3">
              <ConfigRawSidebarContent isActive={sidebarMode === 'form'} />
            </div>
          ) : null}
          {(isCollapsed || sidebarMode === 'config') ? (
          <>
          <div className="space-y-1 px-2 py-3">
            {sections.map((section) => {
              const isExpanded = expandedSections.has(section.id)
              const showAddButton =
                !isCollapsed &&
                (section.id === 'states' || section.id === 'transitions' || section.id === 'error_policy')
              const addDisabled = section.id === 'transitions' && stateNames.length === 0
              const handleAdd = (e: React.MouseEvent) => {
                e.stopPropagation()
                if (section.id === 'states') {
                  setStateModalIndex(null)
                  setStateModalOpen(true)
                } else if (section.id === 'transitions') {
                  setTransitionModalIndex(null)
                  setTransitionModalOpen(true)
                } else if (section.id === 'error_policy') {
                  setErrorPolicyModalOpen(true)
                }
              }
              return (
                <div key={section.id} className="mb-1">
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => toggleSection(section.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        toggleSection(section.id)
                      }
                    }}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 hover:bg-muted/50 cursor-pointer"
                    title={isCollapsed ? section.title : undefined}
                  >
                    {isCollapsed ? (
                      <section.icon className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <>
                        <div className="flex items-center gap-2.5">
                          <section.icon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">{section.title}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          {showAddButton && (
                            <button
                              type="button"
                              onClick={handleAdd}
                              disabled={addDisabled}
                              className="p-1 rounded hover:bg-muted transition-colors disabled:opacity-50 disabled:pointer-events-none"
                              aria-label={
                                section.id === 'states'
                                  ? 'Add state'
                                  : section.id === 'transitions'
                                    ? 'Add transition'
                                    : 'Add error policy'
                              }
                              title={
                                section.id === 'states'
                                  ? 'Add state'
                                  : section.id === 'transitions'
                                    ? 'Add transition'
                                    : 'Add error policy'
                              }
                            >
                              <Plus className="h-4 w-4 text-muted-foreground" />
                            </button>
                          )}
                          {isExpanded ? (
                            <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                          )}
                        </div>
                      </>
                    )}
                  </div>
                  {!isCollapsed && isExpanded && (
                    <div className="ml-1 mt-1 pl-2 border-l-2 border-muted">
                      {section.id === 'meta' && (
                        <ConfigMetaSection
                          config={config}
                          validationResult={validationResult}
                          setMeta={setMeta}
                          updateConfig={updateConfig}
                        />
                      )}
                      {section.id === 'states' && (
                        <ConfigStatesSection
                          states={states}
                          onAddState={() => {
                            setStateModalIndex(null)
                            setStateModalOpen(true)
                          }}
                          onEditState={(i) => {
                            setStateModalIndex(i)
                            setStateModalOpen(true)
                          }}
                          onRemoveState={removeState}
                          onStateClick={(name) => {
                            setDiagramHighlightState(diagramHighlightState === name ? null : name)
                            setDiagramHighlightTransition(null)
                          }}
                          highlightedStateName={diagramHighlightState}
                        />
                      )}
                      {section.id === 'transitions' && (
                        <ConfigTransitionsSection
                          transitions={transitions}
                          stateNames={stateNames}
                          onAddTransition={() => {
                            setTransitionModalIndex(null)
                            setTransitionModalOpen(true)
                          }}
                          onEditTransition={(i) => {
                            setTransitionModalIndex(i)
                            setTransitionModalOpen(true)
                          }}
                          onRemoveTransition={removeTransition}
                          onTransitionClick={(t) => {
                            const already =
                              diagramHighlightTransition &&
                              diagramHighlightTransition.source === t.source &&
                              diagramHighlightTransition.target === t.target &&
                              diagramHighlightTransition.trigger === t.trigger
                            setDiagramHighlightTransition(already ? null : t)
                            setDiagramHighlightState(null)
                          }}
                          highlightedTransition={diagramHighlightTransition}
                        />
                      )}
                      {section.id === 'error_policy' && (
                        <ConfigErrorPolicySection
                          config={config}
                          onOpenModal={() => setErrorPolicyModalOpen(true)}
                          onRemove={() =>
                            updateConfig((c) => {
                              const { error_policy: _, ...rest } = c
                              return rest
                            })
                          }
                        />
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
          {!isCollapsed && (
            <div className="mt-4 space-y-3 border-t border-border/50 px-2 pb-3 pt-3">
              <span className="block px-2 text-xs font-medium text-muted-foreground">Diagram</span>
              {error && <ErrorDisplay error={error} className="px-2" />}
              <div className="px-2">
                <Button
                  size="sm"
                  className="w-full"
                  onClick={() => void runValidate({ force: true })}
                  disabled={validating}
                >
                  {validating ? 'Validating...' : 'Validate machine'}
                </Button>
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
                <span className="text-sm text-foreground">Guards</span>
                <Switch
                  checked={diagramShowGuards}
                  onCheckedChange={setDiagramShowGuards}
                  aria-label="Guards: show or hide guard labels on transition edges"
                  title="Show or hide guard labels on transition edges"
                />
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
                <span className="text-sm text-foreground">Actions</span>
                <Switch
                  checked={diagramShowActions}
                  onCheckedChange={setDiagramShowActions}
                  aria-label="Actions: show or hide action labels on transition edges"
                  title="Show or hide action labels on transition edges"
                />
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
                <span className="text-sm text-foreground">Ops monitor</span>
                <Switch
                  checked={diagramShowOpsBadges}
                  onCheckedChange={setDiagramShowOpsBadges}
                  aria-label="Ops monitor: show or hide ops metrics on state nodes"
                  title={
                    (config.meta?.machine_name ?? '').trim().length === 0
                      ? 'Set machine name in Meta to load live ops metrics on states'
                      : 'Show or hide ops metrics on state nodes'
                  }
                />
              </div>
              <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
                <span className="text-sm text-foreground">Plain</span>
                <Switch
                  checked={diagramPlainNodes}
                  onCheckedChange={setDiagramPlainNodes}
                  aria-label="Plain: show only state names on diagram nodes"
                  title="Show only state titles; hide chips, actions, notes, and metrics on nodes"
                />
              </div>
            </div>
          )}
          </>
          ) : null}
        </div>
      </div>

      <StateModal
        open={stateModalOpen}
        onOpenChange={setStateModalOpen}
        state={stateModalState}
        existingStateNames={stateNames}
        allStates={states}
        onSave={(next) => (stateModalIndex !== null ? updateState(stateModalIndex, next) : addState(next))}
        title={stateModalIndex !== null ? 'Edit state' : 'Add state'}
        description={
          stateModalIndex !== null
            ? 'Update state name, type, hierarchy, and optional hooks.'
            : 'Add a new state. Name and type are required.'
        }
      />
      <TransitionModal
        open={transitionModalOpen}
        onOpenChange={setTransitionModalOpen}
        transition={transitionModalTransition}
        stateNames={stateNames}
        regionNames={regionNames}
        configStates={states}
        onSave={(next) =>
          transitionModalIndex !== null ? updateTransition(transitionModalIndex, next) : addTransition(next)
        }
        title={transitionModalIndex !== null ? 'Edit transition' : 'Add transition'}
        description={
          transitionModalIndex !== null
            ? 'Update trigger, source, destination, guards, actions, delay, and region.'
            : 'Add a new transition. Trigger, source and destination are required.'
        }
      />
      <ErrorPolicyModal
        open={errorPolicyModalOpen}
        onOpenChange={setErrorPolicyModalOpen}
        value={config.error_policy ?? null}
        onSave={(value) =>
          updateConfig((c) => {
            if (value === null) {
              const { error_policy: _, ...rest } = c
              return rest
            }
            return { ...c, error_policy: value }
          })
        }
        title="Error policy"
        description="Optional fallback state and retry attempts on error."
        allowRemove={!!config.error_policy}
      />
    </>
  )
}
