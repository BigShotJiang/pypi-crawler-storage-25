'use client'

import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import type { FSMConfig } from '@/lib/types/fsm'
import type { ValidationResult } from '@/stores/workspace'
import { CheckCircle2, XCircle } from 'lucide-react'

export interface ConfigMetaSectionProps {
  config: FSMConfig
  validationResult: ValidationResult | null
  setMeta: (field: 'machine_name' | 'version', value: string) => void
  updateConfig: (updater: (c: FSMConfig) => FSMConfig) => void
}

export function ConfigMetaSection({
  config,
  validationResult,
  setMeta,
  updateConfig,
}: ConfigMetaSectionProps) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-2">
        <div className="space-y-1">
          <div className="flex flex-row items-center justify-between gap-2">
            <Label className="text-xs">Machine name</Label>
            {validationResult && (
              <span
                className={`inline-flex items-center gap-1 shrink-0 text-xs font-medium ${
                  validationResult.valid ? 'text-emerald-600' : 'text-destructive'
                }`}
                title={validationResult.valid ? 'Config is valid' : validationResult.errors.join('; ')}
              >
                {validationResult.valid ? (
                  <><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" /> Valid</>
                ) : (
                  <><XCircle className="h-3 w-3" /> Invalid</>
                )}
              </span>
            )}
          </div>
          <Input
            className="h-8 text-sm"
            value={config.meta?.machine_name ?? ''}
            onChange={(e) => setMeta('machine_name', e.target.value)}
            placeholder="my_fsm"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Version</Label>
          <Input
            className="h-8 text-sm"
            value={config.meta?.version ?? ''}
            onChange={(e) => setMeta('version', e.target.value)}
            placeholder="1.0.0"
          />
        </div>
        <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
          <span className="text-sm text-foreground">Strict mode</span>
          <Switch
            checked={config.meta?.strict_mode ?? false}
            onCheckedChange={(checked) =>
              updateConfig((c) => ({
                ...c,
                meta: { ...c.meta, strict_mode: checked },
              }))
            }
            aria-label="Strict mode: error policy and guard registry strictness"
            title="When enabled, uses strict error policy and stricter guard registry behavior"
          />
        </div>
        <div className="flex items-center justify-between gap-3 rounded-md px-2 py-1.5 hover:bg-muted/40">
          <span className="text-sm text-foreground">Validate context</span>
          <Switch
            checked={config.meta?.validate_context ?? false}
            onCheckedChange={(checked) =>
              updateConfig((c) => ({
                ...c,
                meta: { ...c.meta, validate_context: checked },
              }))
            }
            aria-label="Validate context: check context against state_variables before each transition"
            title="When enabled, context is validated against state_variables (required keys, types) before each transition."
          />
        </div>
      </div>
      {validationResult && !validationResult.valid && validationResult.errors.length > 0 && (
        <ul className="list-disc list-inside text-xs text-destructive mt-1 space-y-0.5">
          {validationResult.errors.map((err, i) => (
            <li key={i}>{err}</li>
          ))}
        </ul>
      )}
    </div>
  )
}
