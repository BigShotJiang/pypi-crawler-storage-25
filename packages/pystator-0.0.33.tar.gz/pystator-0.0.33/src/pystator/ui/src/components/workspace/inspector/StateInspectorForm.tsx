'use client'

import { useState, useEffect, useMemo, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMState, FSMRegion } from '@/lib/types/fsm'
import ActionEditor, { type FSMAction } from '@/components/editors/ActionEditor'
import ParallelRegionsEditor from '@/components/editors/ParallelRegionsEditor'
import { validateParallelRegionsInput } from '@/lib/fsm/regionUtils'
import { normalizeName, validateName } from '@/lib/utils'
import {
  inspectorInputComponentClass,
  inspectorLabelClass,
  inspectorSectionTitleClass,
  inspectorSelectRowClass,
} from '@/components/workspace/inspector/inspectorPanelStyles'

const STATE_TYPES: FSMState['type'][] = ['initial', 'stable', 'terminal', 'error', 'parallel']

const BLANK_REGION_ROW: FSMRegion = { name: '', initial: '' }

function getContextKeys(metadata: Record<string, unknown> | undefined): string[] {
  const raw = metadata?.context_keys
  if (!Array.isArray(raw)) return []
  return raw.filter((x): x is string => typeof x === 'string')
}

function contextKeysToString(keys: string[]): string {
  return keys.join(', ')
}

function parseContextKeys(input: string): string[] {
  if (!input.trim()) return []
  return input.split(',').map((s) => s.trim()).filter(Boolean)
}

export interface StateInspectorFormProps {
  state: FSMState
  /** When this value changes, form fields reset from `state`. */
  resetKey: string | number
  existingStateNames: string[]
  allStates: FSMState[]
  onSubmit: (state: FSMState) => void
  onCancel?: () => void
  machineStateVariableKeys?: string[]
  /** When false, render only fields + hidden submit target; parent supplies Dialog footer with submit button using `formId`. */
  showFooter?: boolean
  formId?: string
  submitLabel?: string
  autoFocusName?: boolean
  /** Fired when overall save validity changes (for external submit buttons). */
  onCanSaveChange?: (canSave: boolean) => void
}

export function StateInspectorForm({
  state,
  resetKey,
  existingStateNames,
  allStates,
  onSubmit,
  onCancel,
  machineStateVariableKeys,
  showFooter = true,
  formId = 'state-inspector-form',
  submitLabel = 'Save',
  autoFocusName = false,
  onCanSaveChange,
}: StateInspectorFormProps) {
  const nameInputRef = useRef<HTMLInputElement>(null)

  const [name, setName] = useState(state.name)
  const [type, setType] = useState<FSMState['type']>(state.type ?? 'stable')
  const [descriptionVal, setDescriptionVal] = useState(state.description ?? '')
  const [parent, setParent] = useState(state.parent ?? '')
  const [initialChild, setInitialChild] = useState(state.initial_child ?? '')
  const [regionsList, setRegionsList] = useState<FSMRegion[]>(() =>
    state.regions?.length ? state.regions.map((r) => ({ ...r })) : [BLANK_REGION_ROW],
  )
  const [onEnter, setOnEnter] = useState<FSMAction[]>(
    Array.isArray(state.on_enter) ? state.on_enter : (state.on_enter ? [state.on_enter] : []),
  )
  const [onExit, setOnExit] = useState<FSMAction[]>(
    Array.isArray(state.on_exit) ? state.on_exit : (state.on_exit ? [state.on_exit] : []),
  )
  const [timeoutSec, setTimeoutSec] = useState(state.timeout?.seconds?.toString() ?? '')
  const [timeoutDest, setTimeoutDest] = useState(state.timeout?.destination ?? '')
  const [contextKeysInput, setContextKeysInput] = useState(
    contextKeysToString(getContextKeys(state.metadata)),
  )

  useEffect(() => {
    setName(state.name)
    setType(state.type ?? 'stable')
    setDescriptionVal(state.description ?? '')
    setParent(state.parent ?? '')
    setInitialChild(state.initial_child ?? '')
    setRegionsList(
      state.regions?.length ? state.regions.map((r) => ({ ...r })) : [BLANK_REGION_ROW],
    )
    setOnEnter(Array.isArray(state.on_enter) ? state.on_enter : (state.on_enter ? [state.on_enter] : []))
    setOnExit(Array.isArray(state.on_exit) ? state.on_exit : (state.on_exit ? [state.on_exit] : []))
    setTimeoutSec(state.timeout?.seconds?.toString() ?? '')
    setTimeoutDest(state.timeout?.destination ?? '')
    setContextKeysInput(contextKeysToString(getContextKeys(state.metadata)))
  }, [resetKey, state])

  useEffect(() => {
    if (!autoFocusName) return
    const id = requestAnimationFrame(() => {
      nameInputRef.current?.focus()
      nameInputRef.current?.select()
    })
    return () => cancelAnimationFrame(id)
  }, [autoFocusName, resetKey])

  const normalizedName = useMemo(() => normalizeName(name), [name])
  const nameValidation = useMemo(() => {
    if (!name.trim()) return { valid: false, error: '' }
    if (!normalizedName) return { valid: false, error: 'Name produces no valid characters' }
    try {
      validateName(normalizedName)
      return { valid: true, error: '' }
    } catch (e) {
      return { valid: false, error: e instanceof Error ? e.message : 'Invalid name' }
    }
  }, [name, normalizedName])
  const showNameHint = name.trim() !== '' && normalizedName !== '' && normalizedName !== name.trim().toLowerCase()

  const isParallel = type === 'parallel'
  const availableParents = existingStateNames.filter((n) => n !== name)

  const parallelRegionsValidation = useMemo(() => {
    if (!isParallel) {
      return {
        ok: true as const,
        errors: [] as string[],
        warnings: [] as string[],
        regions: undefined as FSMRegion[] | undefined,
      }
    }
    if (!nameValidation.valid || !normalizedName) {
      return {
        ok: false as const,
        errors: ['Enter a valid state name before saving parallel regions.'],
        warnings: [] as string[],
        regions: undefined as FSMRegion[] | undefined,
      }
    }
    return validateParallelRegionsInput({
      parallelStateName: normalizedName,
      regionsDraft: regionsList,
      allStates,
    })
  }, [isParallel, nameValidation.valid, normalizedName, regionsList, allStates])

  const canSave =
    nameValidation.valid && (!isParallel || parallelRegionsValidation.ok)

  useEffect(() => {
    onCanSaveChange?.(canSave)
  }, [canSave, onCanSaveChange])

  const buildNextState = (): FSMState | null => {
    if (!nameValidation.valid) return null
    if (isParallel && !parallelRegionsValidation.ok) return null
    const parsedKeys = parseContextKeys(contextKeysInput)
    const metadata: Record<string, unknown> = { ...(state.metadata ?? {}) }
    if (parsedKeys.length > 0) {
      metadata.context_keys = parsedKeys
    } else {
      delete metadata.context_keys
    }
    return {
      name: normalizedName,
      type,
      description: descriptionVal.trim() || undefined,
      parent: parent.trim() || undefined,
      initial_child: initialChild.trim() || undefined,
      regions: isParallel ? parallelRegionsValidation.regions : undefined,
      on_enter: onEnter.length > 0 ? onEnter : undefined,
      on_exit: onExit.length > 0 ? onExit : undefined,
      timeout:
        timeoutSec && timeoutDest
          ? { seconds: parseFloat(timeoutSec), destination: timeoutDest.trim() }
          : undefined,
      metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const next = buildNextState()
    if (next) onSubmit(next)
  }

  const fields = (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1.5">
          <Label htmlFor="state-name" className={inspectorLabelClass}>
            Name
          </Label>
          <Input
            ref={nameInputRef}
            id="state-name"
            className={inspectorInputComponentClass}
            placeholder="e.g. open"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          {showNameHint && (
            <p className="text-xs text-muted-foreground">
              Will be saved as:{' '}
              <span className="font-mono font-medium text-foreground">{normalizedName}</span>
            </p>
          )}
          {nameValidation.error && (
            <p className="text-xs text-destructive">{nameValidation.error}</p>
          )}
          <p className="text-xs text-muted-foreground">
            Only lowercase letters, numbers, and underscores allowed.
          </p>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="state-type" className={inspectorLabelClass}>
            Type
          </Label>
          <select
            id="state-type"
            className={inspectorSelectRowClass}
            value={type}
            onChange={(e) => {
              const v = e.target.value as FSMState['type']
              setType(v)
              if (v === 'parallel') {
                setRegionsList((prev) => (prev.length > 0 ? prev : [BLANK_REGION_ROW]))
              }
            }}
          >
            {STATE_TYPES.map((t) => (
              <option key={t} value={t}>
                {t} {t === 'parallel' && '⊞'}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="state-desc" className={inspectorLabelClass}>
          Description (optional)
        </Label>
        <Input
          id="state-desc"
          className={inspectorInputComponentClass}
          placeholder="Short description"
          value={descriptionVal}
          onChange={(e) => setDescriptionVal(e.target.value)}
        />
      </div>

      <div className="border-t border-border pt-3">
        <h3 className={inspectorSectionTitleClass}>Hierarchy (Statecharts)</h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label htmlFor="state-parent" className={inspectorLabelClass}>
              Parent State
            </Label>
            <select
              id="state-parent"
              className={inspectorSelectRowClass}
              value={parent}
              onChange={(e) => setParent(e.target.value)}
            >
              <option value="">None (top-level)</option>
              {availableParents.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="state-initial-child" className={inspectorLabelClass}>
              Initial Child
            </Label>
            <select
              id="state-initial-child"
              className={inspectorSelectRowClass}
              value={initialChild}
              onChange={(e) => setInitialChild(e.target.value)}
            >
              <option value="">None</option>
              {existingStateNames
                .filter((n) => n !== name)
                .map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
            </select>
            <p className="text-xs text-muted-foreground">
              Default child when entering this compound state
            </p>
          </div>
        </div>
      </div>

      {isParallel && (
        <div className="border-t border-border pt-3 space-y-2">
          <ParallelRegionsEditor
            parallelStateName={normalizedName}
            regions={regionsList}
            onChange={setRegionsList}
            allStates={allStates}
          />
          {parallelRegionsValidation.errors.length > 0 ? (
            <ul className="text-xs text-destructive list-disc pl-4 space-y-0.5">
              {parallelRegionsValidation.errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          ) : null}
          {parallelRegionsValidation.warnings.length > 0 ? (
            <ul className="text-xs text-amber-700 dark:text-amber-300/90 list-disc pl-4 space-y-0.5">
              {parallelRegionsValidation.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          ) : null}
        </div>
      )}

      <div className="border-t border-border pt-3">
        <h3 className={inspectorSectionTitleClass}>Actions</h3>
        <div className="space-y-1.5">
          <Label className={inspectorLabelClass}>on_enter</Label>
          <ActionEditor actions={onEnter} onChange={setOnEnter} />
        </div>
        <div className="space-y-1.5 mt-2">
          <Label className={inspectorLabelClass}>on_exit</Label>
          <ActionEditor actions={onExit} onChange={setOnExit} />
        </div>
      </div>

      <div className="border-t border-border pt-3">
        <h3 className={inspectorSectionTitleClass}>Timeout</h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label htmlFor="state-timeout-sec" className={inspectorLabelClass}>
              Timeout (seconds)
            </Label>
            <Input
              id="state-timeout-sec"
              className={inspectorInputComponentClass}
              type="number"
              step="0.1"
              placeholder="0"
              value={timeoutSec}
              onChange={(e) => setTimeoutSec(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="state-timeout-dest" className={inspectorLabelClass}>
              Timeout → state
            </Label>
            <Input
              id="state-timeout-dest"
              className={inspectorInputComponentClass}
              placeholder="State name"
              value={timeoutDest}
              onChange={(e) => setTimeoutDest(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="border-t border-border pt-3">
        <h3 className={inspectorSectionTitleClass}>State variables (context keys)</h3>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <Label
              htmlFor="state-context-keys"
              className={`${inspectorLabelClass} shrink-0`}
            >
              Context keys (comma-separated, reference only)
            </Label>
            {machineStateVariableKeys && machineStateVariableKeys.length > 0 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 text-xs"
                onClick={() => setContextKeysInput(machineStateVariableKeys.join(', '))}
              >
                Suggest from state variables
              </Button>
            )}
          </div>
          <Input
            id="state-context-keys"
            className={inspectorInputComponentClass}
            placeholder="e.g. flight_id, departure_time, origin"
            value={contextKeysInput}
            onChange={(e) => setContextKeysInput(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">
            Optional. Documents which context variables apply to this state. Not used by the engine.
          </p>
        </div>
      </div>
    </div>
  )

  return (
    <form id={formId} onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pt-1 pb-2">{fields}</div>
      {showFooter ? (
        <div className="shrink-0 border-t border-border bg-background px-3 py-2 flex justify-end gap-2">
          {onCancel && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-8 text-xs"
              onClick={onCancel}
            >
              Cancel
            </Button>
          )}
          <Button type="submit" size="sm" className="h-8 text-xs" disabled={!canSave}>
            {submitLabel}
          </Button>
        </div>
      ) : null}
    </form>
  )
}
