/**
 * Typography and control sizing aligned with pycharter unified editor
 * InspectorPanel / SchemaNodeInspector (compact sidebar density).
 */

export const inspectorInputClass =
  'w-full rounded border border-input bg-background px-2 py-1 text-xs'

export const inspectorSelectClass =
  'w-full rounded border border-input bg-background px-2 py-1 text-xs appearance-none'

export const inspectorSectionTitleClass =
  'text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5'

export const inspectorLabelClass =
  'text-[11px] font-normal text-muted-foreground leading-snug'

/** Shadcn Input: row height matching pycharter inspector fields. */
export const inspectorInputComponentClass = 'h-8 text-xs px-2'

/** Single-line native select rows in the inspector. */
export const inspectorSelectRowClass =
  'flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs'

/** Multi-select source list. */
export const inspectorMultiselectClass =
  'flex min-h-[72px] w-full rounded-md border border-input bg-background px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-ring'
