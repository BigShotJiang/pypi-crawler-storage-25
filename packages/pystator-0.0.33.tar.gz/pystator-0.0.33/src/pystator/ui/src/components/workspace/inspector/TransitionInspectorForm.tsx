'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMState, FSMTransition } from '@/lib/types/fsm'
import { buildStateToRegionNameMap } from '@/lib/fsm/regionUtils'
import GuardEditor, { type FSMGuard } from '@/components/editors/GuardEditor'
import ActionEditor, { type FSMAction } from '@/components/editors/ActionEditor'
import BuiltinBrowserPanel from '@/components/editors/BuiltinBrowserPanel'
import { normalizeName, validateName } from '@/lib/utils'
import {
  inspectorInputComponentClass,
  inspectorLabelClass,
  inspectorMultiselectClass,
  inspectorSelectRowClass,
} from '@/components/workspace/inspector/inspectorPanelStyles'

function sourceToArray(source: string | string[]): string[] {
  if (Array.isArray(source)) return source
  const s = (source ?? '').trim()
  return s ? [s] : []
}

function normalizeGuards(raw: unknown): FSMGuard[] {
  if (!raw) return []
  if (Array.isArray(raw)) return raw as FSMGuard[]
  return [raw as FSMGuard]
}

function normalizeActions(raw: unknown): FSMAction[] {
  if (!raw) return []
  if (Array.isArray(raw)) return raw as FSMAction[]
  return [raw as FSMAction]
}

function delayToString(after: number | string | undefined): string {
  if (after === undefined || after === null) return ''
  return String(after)
}

function parseDelay(input: string): number | string | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  if (/^[0-9]+[smh]$/.test(trimmed)) return trimmed
  const num = parseInt(trimmed, 10)
  if (!isNaN(num)) return num
  return trimmed
}

export interface TransitionInspectorFormProps {
  transition: FSMTransition
  resetKey: string | number
  stateNames: string[]
  regionNames?: string[]
  configStates?: FSMState[]
  onSubmit: (transition: FSMTransition) => void
  onCancel?: () => void
  showFooter?: boolean
  formId?: string
  submitLabel?: string
  onCanSaveChange?: (canSave: boolean) => void
}

export function TransitionInspectorForm({
  transition,
  resetKey,
  stateNames,
  regionNames = [],
  configStates,
  onSubmit,
  onCancel,
  showFooter = true,
  formId = 'transition-inspector-form',
  submitLabel = 'Save',
  onCanSaveChange,
}: TransitionInspectorFormProps) {
  const [trigger, setTrigger] = useState(transition.trigger ?? '')
  const [source, setSource] = useState<string[]>(() => sourceToArray(transition.source))
  const [dest, setDest] = useState(transition.dest)
  const [guards, setGuards] = useState<FSMGuard[]>(() => normalizeGuards(transition.guards))
  const [actions, setActions] = useState<FSMAction[]>(() => normalizeActions(transition.actions))
  const [delay, setDelay] = useState(delayToString(transition.after))
  const [region, setRegion] = useState(transition.region ?? '')

  useEffect(() => {
    setTrigger(transition.trigger ?? '')
    setSource(sourceToArray(transition.source))
    setDest(transition.dest)
    setGuards(normalizeGuards(transition.guards))
    setActions(normalizeActions(transition.actions))
    setDelay(delayToString(transition.after))
    setRegion(transition.region ?? '')
  }, [resetKey, transition])

  const normalizedTrigger = useMemo(() => normalizeName(trigger), [trigger])
  const triggerValidation = useMemo(() => {
    const trimmed = trigger.trim()
    if (!trimmed) return { valid: true, error: '' }
    if (!normalizedTrigger) return { valid: false, error: 'Trigger produces no valid characters' }
    try {
      validateName(normalizedTrigger)
      return { valid: true, error: '' }
    } catch (e) {
      return { valid: false, error: e instanceof Error ? e.message : 'Invalid trigger' }
    }
  }, [trigger, normalizedTrigger])
  const showTriggerHint =
    trigger.trim() !== '' && normalizedTrigger !== '' && normalizedTrigger !== trigger.trim().toLowerCase()

  const uniqueStateNames = useMemo(() => [...new Set(stateNames)], [stateNames])
  const uniqueRegionNames = useMemo(() => [...new Set(regionNames)], [regionNames])

  const stateToRegion = useMemo(() => {
    if (!configStates?.length) return null
    return buildStateToRegionNameMap(configStates)
  }, [configStates])

  const inferredRegionsForSources = useMemo(() => {
    if (!stateToRegion || source.length === 0) return []
    const names = new Set<string>()
    for (const s of source) {
      const r = stateToRegion.get(s)
      if (r) names.add(r)
    }
    return [...names]
  }, [stateToRegion, source])

  const suggestedRegion =
    inferredRegionsForSources.length === 1 ? inferredRegionsForSources[0] : null

  const handleInsertGuard = useCallback((name: string) => setGuards((prev) => [...prev, name]), [])
  const handleInsertAction = useCallback((name: string) => setActions((prev) => [...prev, name]), [])

  const hasTrigger = !!trigger?.trim()
  const hasDelay = !!delay?.trim()
  const canSave =
    source.length > 0 &&
    !!dest &&
    triggerValidation.valid &&
    (hasTrigger || hasDelay)

  useEffect(() => {
    onCanSaveChange?.(canSave)
  }, [canSave, onCanSaveChange])

  const buildNextTransition = (): FSMTransition | null => {
    if (!canSave) return null
    return {
      trigger: normalizedTrigger || undefined,
      source: source.length === 1 ? source[0] : source,
      dest,
      guards: guards.length > 0 ? guards : undefined,
      actions: actions.length > 0 ? actions : undefined,
      after: parseDelay(delay),
      region: region.trim() || undefined,
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const next = buildNextTransition()
    if (next) onSubmit(next)
  }

  const fields = (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1.5">
          <Label htmlFor="trans-trigger" className={inspectorLabelClass}>
            Trigger
          </Label>
          <Input
            id="trans-trigger"
            className={inspectorInputComponentClass}
            placeholder="e.g. submit"
            value={trigger ?? ''}
            onChange={(e) => setTrigger(e.target.value)}
          />
          {showTriggerHint && (
            <p className="text-xs text-muted-foreground">
              Will be saved as:{' '}
              <span className="font-mono font-medium text-foreground">{normalizedTrigger}</span>
            </p>
          )}
          {triggerValidation.error && (
            <p className="text-xs text-destructive">{triggerValidation.error}</p>
          )}
          <p className="text-xs text-muted-foreground">
            Only lowercase letters, numbers, and underscores allowed.
          </p>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="trans-source" className={inspectorLabelClass}>
            Source (hold Ctrl/Cmd to select multiple)
          </Label>
          <select
            id="trans-source"
            multiple
            className={inspectorMultiselectClass}
            value={source}
            onChange={(e) => setSource([...e.target.selectedOptions].map((o) => o.value))}
            disabled={uniqueStateNames.length === 0}
          >
            {uniqueStateNames.length === 0 ? (
              <option value="" disabled>
                Add a state first
              </option>
            ) : (
              uniqueStateNames.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))
            )}
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1.5">
          <Label htmlFor="trans-dest" className={inspectorLabelClass}>
            Destination
          </Label>
          <select
            id="trans-dest"
            className={inspectorSelectRowClass}
            value={dest}
            onChange={(e) => setDest(e.target.value)}
            disabled={uniqueStateNames.length === 0}
          >
            {uniqueStateNames.length === 0 ? (
              <option value="">Add a state first</option>
            ) : (
              uniqueStateNames.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))
            )}
          </select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="trans-region" className={inspectorLabelClass}>
            Region (for parallel states)
          </Label>
          <select
            id="trans-region"
            className={inspectorSelectRowClass}
            value={region}
            onChange={(e) => setRegion(e.target.value)}
          >
            <option value="">None</option>
            {uniqueRegionNames.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
          {configStates && uniqueRegionNames.length > 0 && inferredRegionsForSources.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Selected sources are not listed in any parallel region&apos;s{' '}
              <span className="font-mono">states</span> list. Leave Region empty unless you are scoping
              manually.
            </p>
          ) : null}
          {configStates && suggestedRegion && !region.trim() ? (
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-xs text-muted-foreground">
                Sources map to region <span className="font-mono font-medium">{suggestedRegion}</span>.
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs"
                onClick={() => setRegion(suggestedRegion)}
              >
                Use {suggestedRegion}
              </Button>
            </div>
          ) : null}
          {configStates && inferredRegionsForSources.length >= 2 ? (
            <p className="text-xs text-amber-700 dark:text-amber-300/90">
              Sources span multiple regions ({inferredRegionsForSources.join(', ')}). Pick one region or
              narrow the source list.
            </p>
          ) : null}
        </div>
      </div>
      <div className="space-y-1.5">
        <Label className={inspectorLabelClass}>Guards</Label>
        <GuardEditor guards={guards} onChange={setGuards} />
      </div>
      <div className="space-y-1.5">
        <Label className={inspectorLabelClass}>Actions</Label>
        <ActionEditor actions={actions} onChange={setActions} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="trans-delay" className={inspectorLabelClass}>
          Delay (after) - ms or &quot;5s&quot;/&quot;5m&quot;/&quot;1h&quot;
        </Label>
        <Input
          id="trans-delay"
          className={inspectorInputComponentClass}
          placeholder="e.g. 5000 or 5s"
          value={delay}
          onChange={(e) => setDelay(e.target.value)}
        />
        <p className="text-xs text-muted-foreground">
          Delayed transitions fire automatically after the specified time
        </p>
      </div>
      <BuiltinBrowserPanel onInsertGuard={handleInsertGuard} onInsertAction={handleInsertAction} />
    </div>
  )

  return (
    <form id={formId} onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pt-1 pb-2">{fields}</div>
      {showFooter ? (
        <div className="shrink-0 border-t border-border bg-background px-3 py-2 flex justify-end gap-2">
          {onCancel && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-8 text-xs"
              onClick={onCancel}
            >
              Cancel
            </Button>
          )}
          <Button type="submit" size="sm" className="h-8 text-xs" disabled={!canSave}>
            {submitLabel}
          </Button>
        </div>
      ) : null}
    </form>
  )
}
