"""Keyring-backed storage for the API key and model preference."""

# stdlib
# (none)

# third-party
import keyring

SERVICE_NAME = "pyfixer"
USERNAME = "anthropic_api_key"
MODEL_USERNAME = "selected_model"

# Available models per provider — update as providers release new versions
MODEL_OPTIONS: dict[str, list[tuple[str, str]]] = {
    "anthropic": [
        ("claude-opus-4-6",          "Claude Opus 4.6      — most capable"),
        ("claude-sonnet-4-6",        "Claude Sonnet 4.6    — balanced (recommended)"),
        ("claude-haiku-4-5-20251001","Claude Haiku 4.5     — fastest / cheapest"),
    ],
    "gemini": [
        ("gemini-2.5-pro",   "Gemini 2.5 Pro   — most capable"),
        ("gemini-2.5-flash", "Gemini 2.5 Flash — balanced (recommended)"),
        ("gemini-1.5-flash", "Gemini 1.5 Flash — fastest / cheapest"),
    ],
}

DEFAULT_MODEL: dict[str, str] = {
    "anthropic": "claude-sonnet-4-6",
    "gemini":    "gemini-2.5-flash",
}


def get_api_key() -> str | None:
    """Return the stored API key, or None if not set."""
    return keyring.get_password(SERVICE_NAME, USERNAME)


def set_api_key(key: str) -> None:
    """Persist the API key in the system keyring."""
    keyring.set_password(SERVICE_NAME, USERNAME, key)


def delete_api_key() -> None:
    """Remove the API key from the system keyring."""
    keyring.delete_password(SERVICE_NAME, USERNAME)


def get_model() -> str | None:
    """Return the stored model ID, or None if not set."""
    return keyring.get_password(SERVICE_NAME, MODEL_USERNAME)


def set_model(model: str) -> None:
    """Persist the chosen model ID in the system keyring."""
    keyring.set_password(SERVICE_NAME, MODEL_USERNAME, model)


def delete_model() -> None:
    """Remove the stored model preference from the system keyring."""
    try:
        keyring.delete_password(SERVICE_NAME, MODEL_USERNAME)
    except Exception:
        pass
