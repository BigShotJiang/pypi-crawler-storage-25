# pyfixer

`pyfixer` is a drop-in replacement for `python` that runs your scripts normally but, when an error occurs, prints the real traceback and then uses AI to give you a plain-language explanation of what went wrong, why it happened, and how to fix it — all directly in your terminal.

Supports **Anthropic Claude** and **Google Gemini**. The provider is detected automatically from your API key.

## Installation

```bash
pip install pyfixer
```

For development:

```bash
pip install -e ".[dev]"
```

## Usage

### Store your API key (once)

```bash
pyfixer login
```

Paste your Anthropic (`sk-ant-...`) or Gemini (`AIza...`) API key when prompted. The key is stored securely in your system keyring — never on disk or in any file.

### Run a script

```bash
pyfixer run script.py
pyfixer run script.py arg1 arg2     # extra args are forwarded to the script
pyfixer run script.py --no-explain  # show traceback only, skip AI
```

When an error occurs, pyfixer:
1. Prints the full traceback
2. Explains the error in plain English
3. Suggests a fix and opens a **VS Code diff** showing exactly what changed (green = added, red = removed)
4. Asks if you want to apply the fix directly to your file

### Change model

```bash
pyfixer set-model
```

### Remove your stored API key

```bash
pyfixer logout
```

## Supported providers

| Provider | Key prefix | Models |
|---|---|---|
| Anthropic Claude | `sk-ant-...` | Opus 4, Sonnet 4, Haiku 4 |
| Google Gemini | `AIza...` | Gemini 2.5 Pro, 2.5 Flash, 1.5 Flash |

## Roadmap

- **Phase 1 ✅** Run scripts, catch errors, explain them with AI.
- **Phase 2 ✅** Suggested fixes shown as a VS Code diff with a confirm prompt to apply.
- **Phase 3 (planned):** SQLite-backed error journal to track recurring errors over time.
