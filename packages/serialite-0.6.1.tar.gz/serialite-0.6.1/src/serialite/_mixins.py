__all__ = ["AbstractSerializableMixin", "SerializableMixin"]

from typing import Any, ClassVar, Self

from ._base import Serializable, SerializerToRef
from ._errors import Errors
from ._fields_serializer import FieldsSerializer
from ._openapi import is_openapi_component
from ._result import Failure, Result, Success


class SerializableMixin(Serializable):
    """A mixin to make simple classes serializable.

    This mixin inspects an abstract `__fields_serializer__` to provide an
    implementation for `Serializable`.
    """

    __fields_serializer__: ClassVar[FieldsSerializer]

    @classmethod
    def from_data(cls, data: Any) -> Result[Self]:
        match cls.__fields_serializer__.from_data(data):
            case Failure(error):
                return Failure(error)
            case Success(value):
                return Success(cls(**value))

    def to_data(self) -> dict[str, Any]:
        return self.__fields_serializer__.to_data(self, source="object")

    is_openapi_component: bool = True

    @classmethod
    def child_components(cls) -> dict[str, type[Serializable]]:
        """Return all child component classes in __fields_serializer__."""
        return cls.__fields_serializer__.child_components()

    @classmethod
    def to_openapi_schema(cls, serializer_to_ref: SerializerToRef, *, force: bool = False) -> Any:
        if force:
            schema = cls.__fields_serializer__.to_openapi_schema(serializer_to_ref)

            if hasattr(cls, "__subclass_serializers__"):
                # It is not possible in OpenAPI to have the discriminator field
                # only in places where the base class is expected (that is,
                # where it is needed), so we have to say that it is accepted for
                # the subclass, even though it is not. This works as long as no
                # place in the API accepts just a concrete class.

                discriminator_field = {"_type": {"type": "string", "enum": [cls.__name__]}}
                schema = schema | {"properties": discriminator_field | schema["properties"]}

            return schema
        else:
            return serializer_to_ref(cls)


class AbstractSerializableMixin(Serializable):
    """Provides Serializable for abstract base classes.

    This mixin inspects an abstract `__subclass_serializers__` to provide an
    implementation for `Serializable`.

    This provides a standard way to serialize instances of an abstract base
    class. The concrete classes must be `Serializable`; that is, they have
    their own implementation of `from_data` and `to_data` for serializing and
    deserializing instances of themselves. The concrete classes must also
    deserialize from and serialize to a dictionary. This is important because
    `to_data` of this mixin will add the key "_type" to the dictionary
    containing the name of the subclass. Likewise, `from_data` of this mixin
    will look for the key "_type" to determine which subclass to dispatch the
    remainder of the dictionary to.
    """

    __subclass_serializers__: ClassVar[dict[str, Serializable]]

    @classmethod
    def from_data(cls, data):
        try:
            type_name = data["_type"]
        except KeyError:
            from ._field_errors import RequiredTypeFieldError

            return Failure(Errors.one(RequiredTypeFieldError(), location=["_type"]))
        except TypeError:
            # Import locally to avoid circular import at module import time
            from ._type_errors import ExpectedDictionaryError

            return Failure(Errors.one(ExpectedDictionaryError(data)))

        # The rest of data
        subclass_data = {key: value for key, value in data.items() if key != "_type"}

        subclass = cls.__subclass_serializers__.get(type_name)
        if subclass is None:
            from ._field_errors import UnknownClassError

            return Failure(
                Errors.one(
                    UnknownClassError(type_name, list(cls.__subclass_serializers__.keys())),
                    location=["_type"],
                )
            )
        else:
            return subclass.from_data(subclass_data)

    @classmethod
    def to_data(cls, value):
        if not isinstance(value, cls):
            raise TypeError(f"Expected instance of {cls}, but got {value}")

        if value.to_data == cls.to_data:
            raise TypeError(
                "Recursion in AbstractSerializableMixin.to_data detected while processing"
                f" {value}.This likely do to a failure to implement to_data on {type(value)}"
            )

        return {"_type": value.__class__.__name__} | value.to_data()

    is_openapi_component: bool = True

    @classmethod
    def child_components(cls) -> dict[str, type[Serializable]]:
        """Return all child component classes in __subclass_serializers__."""

        # Return all subclass types that are OpenAPI components
        components = {}
        for name, subclass in cls.__subclass_serializers__.items():
            if is_openapi_component(subclass):
                components[name] = subclass

        return components

    @classmethod
    def to_openapi_schema(cls, serializer_to_ref: SerializerToRef, *, force: bool = False) -> Any:
        if force:
            return {
                "type": "object",
                "discriminator": {"propertyName": "_type"},
                "oneOf": [
                    subclass.to_openapi_schema(serializer_to_ref)
                    for subclass in cls.__subclass_serializers__.values()
                ],
            }
        else:
            return serializer_to_ref(cls)
