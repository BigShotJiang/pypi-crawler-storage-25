#!/usr/bin/env python
from __future__ import print_function

import os
import shutil
import tempfile
import unittest

from MediCafe import MediLink_ConfigLoader as cfg_loader


class ConfigLoaderRunLogNamingTests(unittest.TestCase):

    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath

    def test_extract_daily_run_index(self):
        token = '03302026'
        self.assertEqual(cfg_loader._extract_daily_run_index('Log_03302026_run001.log', token), 1)
        self.assertEqual(cfg_loader._extract_daily_run_index('Log_03302026_run023_extra.log', token), 23)
        self.assertIsNone(cfg_loader._extract_daily_run_index('Log_03302026.log', token))
        self.assertIsNone(cfg_loader._extract_daily_run_index('Log_03312026_run001.log', token))

    def test_resolve_run_log_filepath_assigns_next_daily_index(self):
        tmp = tempfile.mkdtemp(prefix='mc_run_log_')
        try:
            token = cfg_loader.datetime.now().strftime('%m%d%Y')
            open(os.path.join(tmp, 'Log_{0}_run001.log'.format(token)), 'a').close()
            open(os.path.join(tmp, 'Log_{0}_run002.log'.format(token)), 'a').close()
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
            path = cfg_loader._resolve_run_log_filepath(tmp)
            self.assertTrue(path.endswith('Log_{0}_run003.log'.format(token)))
            self.assertEqual(os.environ.get('MEDICAFE_RUN_LOG_ID'), '3')
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
