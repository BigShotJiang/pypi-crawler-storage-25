#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import time
import unittest
from io import StringIO

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class LauncherNextStepOrchestrationTests(unittest.TestCase):

    def _make_orchestrator(self, non_interactive=False):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        session.non_interactive = non_interactive
        orch = MediCafeOrchestrator(session)
        orch._next_step_assistant_enabled = True
        return orch

    def test_assistant_disallowed_for_non_interactive(self):
        orch = self._make_orchestrator(non_interactive=True)
        self.assertFalse(orch._assistant_interaction_allowed())

    def test_signal_provider_submission_attempts_counts_retry_candidates(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': temp_root}}, handle)
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'a', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 1},
                {'claim_key': 'b', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 2},
                {'claim_key': 'c', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_submission_attempts_uses_latest_claim_attempt(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': temp_root}}, handle)
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'x', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1},
                {'claim_key': 'x', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 2},
                {'claim_key': 'y', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_submission_attempts_respects_local_claims_path(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            claims_root = os.path.join(temp_root, 'claims')
            storage_root = os.path.join(temp_root, 'storage')
            os.makedirs(claims_root)
            os.makedirs(storage_root)
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': claims_root}}, handle)

            attempts_path = os.path.join(claims_root, 'submission_attempts.jsonl')
            with open(attempts_path, 'w') as handle:
                handle.write(json.dumps({'claim_key': 'z', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1}) + '\n')

            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage_root
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_remittance_ledger_requires_recent_entries(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            ledger_path = os.path.join(temp_root, 'remittance_file_ledger.jsonl')
            old_ts = 1000000000
            with open(ledger_path, 'w') as handle:
                handle.write(json.dumps({'mtime': old_ts}) + '\n')
            payload = orch._signal_provider_remittance_ledger()
            self.assertFalse(payload.get('zdat_pending', False))

            recent_ts = 2000000000
            with patch('MediCafe.launcher.time.time', return_value=recent_ts + 5):
                with open(ledger_path, 'a') as handle:
                    handle.write(json.dumps({'mtime': recent_ts}) + '\n')
                payload2 = orch._signal_provider_remittance_ledger()
            self.assertTrue(payload2.get('zdat_pending'))
            self.assertGreaterEqual(payload2.get('intake_artifacts_new_count', 0), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_collect_startup_signals_uses_canonical_providers(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_signal_providers') as provider_builder:
            provider_builder.return_value = [
                lambda: {'zdat_pending': True},
                lambda: {'retry_queue_pending_count': 3},
            ]
            signals = orch._collect_startup_assistant_signals()
            self.assertTrue(signals.get('zdat_pending'))
            self.assertEqual(signals.get('retry_queue_pending_count'), 3)

    def test_maybe_offer_next_step_skips_when_non_interactive(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=True)
        with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
            orch._maybe_offer_next_step_assistant('medibot', 0)
            prompt_mock.assert_not_called()

    def test_run_update_flow_launches_updater_window_without_maximize_flag(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.environment['upgrade_medicafe'] = os.path.join(
            tempfile.gettempdir(), 'update_medicafe.py'
        )
        with open(orch.environment['upgrade_medicafe'], 'w') as handle:
            handle.write('print("noop")\n')

        with patch.object(orch, '_build_update_runner', return_value=r'C:\Temp\runner.cmd'):
            with patch('MediCafe.launcher.subprocess.Popen') as popen_mock:
                with patch.object(orch, '_exit_after_payer_list_join') as exit_mock:
                    orch.run_update_flow()

        popen_mock.assert_called_once()
        cmd_string = popen_mock.call_args[0][0]
        self.assertIn('start "MediCafe Updater" cmd /c', cmd_string)
        self.assertNotIn('/MAX cmd /c', cmd_string)
        exit_mock.assert_called_once()

    def test_build_update_runner_relaunches_medibot_maximized(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_update_runner_')
        script_path = os.path.join(temp_root, 'update_medicafe.py')
        try:
            with open(script_path, 'w') as handle:
                handle.write('print("noop")\n')
            with patch.dict(os.environ, {'TEMP': temp_root}, clear=False):
                runner_path = orch._build_update_runner(script_path)
            self.assertTrue(runner_path and os.path.exists(runner_path))
            with open(runner_path, 'r') as handle:
                runner_text = handle.read()
            self.assertIn('start "MediBot" /MAX !MEDIBOT_PATH!', runner_text)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_handle_fatal_error_can_offer_update_recovery(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_collect_error_bundle', return_value=None):
            with patch.object(orch, '_prompt', return_value='2'):
                with patch.object(orch, '_launch_update_runner_and_exit', return_value=True) as launch_mock:
                    orch.handle_fatal_error(RuntimeError('boom'))
        launch_mock.assert_called_once()


    def test_maybe_offer_next_step_skips_when_child_marked_user_exit(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
            with patch.object(orch, '_execute_assistant_action') as exec_mock:
                orch._maybe_offer_next_step_assistant(
                    'medilink',
                    0,
                    extra_signals={'user_exit_requested': True},
                )
        prompt_mock.assert_not_called()
        exec_mock.assert_not_called()

    def test_run_medicafe_command_records_child_user_exit_signal(self):
        from MediCafe.action_intent import ACTION_EXIT_SENTINEL_ENV
        orch = self._make_orchestrator(non_interactive=False)

        def _fake_call(_args, cwd=None, env=None):
            if env is None:
                raise AssertionError('expected subprocess env')
            sentinel = env.get(ACTION_EXIT_SENTINEL_ENV, '')
            self.assertTrue(sentinel)
            with open(sentinel, 'w') as handle:
                handle.write('reason=user_exit\n')
            return 0

        with patch.object(orch, '_run_preflight_if_needed', return_value=True):
            with patch('MediCafe.launcher.subprocess.call', side_effect=_fake_call):
                rc = orch.run_medicafe_command('medilink')

        self.assertEqual(rc, 0)
        self.assertEqual(
            orch._consume_last_command_assistant_signals('medilink'),
            {'child_exit_reason': 'user_exit', 'user_exit_requested': True},
        )
        self.assertEqual(orch._consume_last_command_assistant_signals('medilink'), {})

    def test_startup_assistant_skips_without_actionable_signals(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._startup_assistant_presented = False
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_collect_startup_assistant_signals', return_value={}):
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                    result = orch._maybe_offer_startup_assistant()
                    self.assertFalse(result)
                    prompt_mock.assert_not_called()




    def test_assistant_mode_env_auto_contextual_enables_without_legacy_flag(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        with patch.dict(os.environ, {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'auto_contextual'}, clear=False):
            orch = MediCafeOrchestrator(session)
        self.assertEqual(orch._assistant_mode_or_default(), 'auto_contextual')
        self.assertTrue(orch._next_step_assistant_enabled)

    def test_auto_contextual_skips_prompt_for_safe_high_confidence_recommendation(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._assistant_mode = 'auto_contextual'
        orch._next_step_assistant_enabled = True
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={'retry_queue_pending_count': 1}):
                with patch.object(orch, '_execute_assistant_action', return_value=0) as exec_mock:
                    with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                        orch._maybe_offer_next_step_assistant('claims_status', 0)
        prompt_mock.assert_not_called()
        exec_mock.assert_called()

    def test_transition_path_refreshes_signals_each_time(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={}) as refresh_mock:
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation', return_value={'action_id': 'main_menu'}):
                    orch._maybe_offer_next_step_assistant('medibot', 0)
        refresh_mock.assert_called_once()

    def test_main_menu_loop_startup_assistant_checked_when_header_skipped(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_print_welcome_block'):
            with patch.object(orch, '_print_main_menu_options'):
                with patch.object(orch, '_maybe_offer_startup_assistant', side_effect=[False, False]) as startup_mock:
                    with patch.object(orch, '_get_menu_choice', return_value='0'):
                        with patch.object(orch, '_mark_clean_exit'):
                            with patch.object(orch, '_join_payer_list_thread'):
                                orch.main_menu_loop(show_header_on_first=False)
        startup_mock.assert_called()


    def test_run_startup_tasks_skips_passive_gmail_queue_resolution(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_run_download_migration'):
            with patch.object(orch, '_launch_startup_csv'):
                with patch('MediCafe.launcher.cloud_readiness', None):
                    with patch.object(error_reporter, 'maybe_auto_resolve_queued_bundles_passive') as auto_mock:
                        orch._run_startup_tasks()
        auto_mock.assert_not_called()

    def test_download_emails_runs_legacy_queue_followup_before_csv(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, 'run_medicafe_command', return_value=0):
            with patch.object(orch, '_maybe_resolve_queued_reports_after_legacy_gmail_download') as follow_mock:
                with patch.object(orch, 'process_csvs', return_value=0):
                    rc = orch.download_emails()
        self.assertEqual(rc, 0)
        follow_mock.assert_called_once_with(0)

    def test_legacy_queue_followup_records_notice_when_attempted(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(
            error_reporter,
            'maybe_resolve_queued_bundles_opportunistically',
            return_value={'attempted': True, 'sent': 2, 'failed': 1},
        ) as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(0)
        auto_mock.assert_called_once_with(source='legacy_gmail_download')
        self.assertTrue(any('after legacy Gmail download' in message for _level, message in orch.startup_notices))

    def test_legacy_queue_followup_skips_failed_download(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(error_reporter, 'maybe_resolve_queued_bundles_opportunistically') as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(1)
        auto_mock.assert_not_called()

    def test_default_assistant_mode_auto_contextual_without_env_or_prefs(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {}, clear=False):
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', None)
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT', None)
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'auto_contextual')
            self.assertTrue(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_assistant_preference_file_off(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig, _LAUNCHER_PREFERENCES_FILENAME
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            pref_path = os.path.join(tmp, _LAUNCHER_PREFERENCES_FILENAME)
            with open(pref_path, 'w') as handle:
                json.dump({'next_step_assistant_mode': 'off'}, handle)
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {}, clear=False):
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', None)
                os.environ.pop('MEDICAFE_NEXT_STEP_ASSISTANT', None)
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'off')
            self.assertFalse(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_assistant_env_overrides_preference_file(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig, _LAUNCHER_PREFERENCES_FILENAME
        import MediCafe.launcher as launcher_mod
        if launcher_mod.next_step_assistant is None:
            self.skipTest('launcher_next_step_assistant not available')
        tmp = tempfile.mkdtemp(prefix='mc_asst_')
        try:
            cfg = os.path.join(tmp, 'config.json')
            with open(cfg, 'w') as handle:
                handle.write('{}')
            pref_path = os.path.join(tmp, _LAUNCHER_PREFERENCES_FILENAME)
            with open(pref_path, 'w') as handle:
                json.dump({'next_step_assistant_mode': 'auto_contextual'}, handle)
            args = MagicMock()
            args.skip_csv = False
            args.direct_action = None
            args.debug_mode = False
            args.auto_choice = None
            session = SessionConfig(args)
            with patch.dict(os.environ, {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'off'}, clear=False):
                orch = MediCafeOrchestrator(session)
                orch.environment['config_file'] = cfg
                orch._assistant_mode = orch._resolve_assistant_mode()
                orch._next_step_assistant_enabled = (
                    bool(launcher_mod.next_step_assistant) and orch._assistant_mode != 'off'
                )
            self.assertEqual(orch._assistant_mode_or_default(), 'off')
            self.assertFalse(orch._next_step_assistant_enabled)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


    def test_visible_fallback_menu_order_matches_v1(self):
        orch = self._make_orchestrator(non_interactive=False)
        buffer = StringIO()
        with patch('sys.stdout', buffer):
            orch._print_main_menu_options()
        lines = [line.strip() for line in buffer.getvalue().splitlines() if line.strip()]
        self.assertEqual(lines, [
            'Please select an option:',
            '1. Update MediCafe',
            '2. Download Email de Carol',
            '3. MediLink Claims',
            '4. Run MediBot',
            '5. Troubleshooting',
            '0. Exit',
        ])

    def test_interactive_menu_numbers_use_new_visible_order(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_prompt', return_value='4'):
            self.assertEqual(orch._get_menu_choice(), 'medibot')
        with patch.object(orch, '_prompt', return_value='5'):
            self.assertEqual(orch._get_menu_choice(), 'troubleshooting')

    def test_auto_choice_legacy_numeric_values_still_resolve_hidden_actions(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.session.auto_menu_choice = '4'
        orch.session.auto_menu_source = 'CLI'
        self.assertEqual(orch._get_menu_choice(), 'claims_status')

        orch.session.auto_menu_choice = '5'
        orch.session.auto_menu_source = 'ENV'
        self.assertEqual(orch._get_menu_choice(), 'deductible')

    def test_auto_choice_accepts_stable_action_ids(self):
        orch = self._make_orchestrator(non_interactive=False)
        orch.session.auto_menu_choice = 'medilink'
        orch.session.auto_menu_source = 'CLI'
        self.assertEqual(orch._get_menu_choice(), 'medilink')

    def test_startup_assistant_runs_before_menu_render(self):
        orch = self._make_orchestrator(non_interactive=False)
        call_order = []
        with patch.object(orch, '_clear_console', side_effect=lambda: call_order.append('clear')):
            with patch.object(orch, '_print_version_details', side_effect=lambda: call_order.append('version')):
                with patch.object(orch, '_print_welcome_block', side_effect=lambda: call_order.append('welcome')):
                    with patch.object(orch, '_maybe_offer_startup_assistant', side_effect=lambda: call_order.append('assistant') or False):
                        with patch.object(orch, '_print_main_menu_options', side_effect=lambda: call_order.append('menu')):
                            with patch.object(orch, '_get_menu_choice', return_value='exit'):
                                with patch.object(orch, '_dispatch_launcher_action', return_value='exit'):
                                    with patch.object(orch, '_mark_clean_exit'):
                                        with patch.object(orch, '_join_payer_list_thread'):
                                            orch.main_menu_loop(show_header_on_first=True)
        self.assertLess(call_order.index('assistant'), call_order.index('menu'))

    def test_signal_provider_queued_error_reports_counts_zip_files(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_queue_')
        try:
            queue_dir = os.path.join(temp_root, 'reports_queue')
            os.makedirs(queue_dir)
            with open(os.path.join(queue_dir, 'a.zip'), 'w') as handle:
                handle.write('x')
            with open(os.path.join(queue_dir, 'b.zip'), 'w') as handle:
                handle.write('x')
            with open(os.path.join(queue_dir, 'ignore.txt'), 'w') as handle:
                handle.write('x')
            orch.environment['local_storage_path'] = temp_root
            payload = orch._signal_provider_queued_error_reports()
            self.assertEqual(payload.get('queued_error_reports_pending_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_docx_index_attention_when_index_missing(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_docx_')
        try:
            with open(os.path.join(temp_root, 'schedule.docx'), 'w') as handle:
                handle.write('placeholder')
            orch.environment['local_storage_path'] = temp_root
            payload = orch._signal_provider_docx_index_attention()
            self.assertTrue(payload.get('docx_index_attention_needed'))
            self.assertEqual(payload.get('docx_index_reason'), 'missing')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_monthly_export_due_near_boundary_without_recent_export(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_export_')
        try:
            export_root = os.path.join(temp_root, 'claims')
            os.makedirs(export_root)
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': export_root}}, handle)
            orch.environment['config_file'] = config_path
            with patch('MediCafe.launcher.time.localtime', return_value=time.struct_time((2026, 4, 1, 12, 0, 0, 2, 92, -1))):
                with patch('MediCafe.launcher.time.time', return_value=1775044800):
                    payload = orch._signal_provider_monthly_humana_aetna_export_due()
            self.assertTrue(payload.get('monthly_humana_aetna_export_due'))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

if __name__ == '__main__':
    unittest.main()
