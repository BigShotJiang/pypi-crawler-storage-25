# -*- coding: utf-8 -*-
"""
Single source of truth for Phase D QA milestone exit predicates (shadow payload / evidence).
XP-compatible: Python 3.4+, stdlib only.
"""
from __future__ import print_function

import os

# Keys aligned with scripts/unified_model/phase_f_common.py shadow report flattening.
MILESTONE_DAT_COUNT_KEYS = (
    "phase_d_dat_selected_count",
    "phase_d_dat_qa_pass_count",
    "phase_d_dat_canonical_record_count",
)

EVIDENCE_PREFIXES = (
    ("shadow_run_report_", (".json",)),
    ("shadow_evidence_index_", (".json",)),
    ("qa_reject_samples_", (".jsonl",)),
)

REASON_SHADOW_REPORT_MISSING = "shadow_report_missing"

VERDICT_MILESTONE_READY = "Milestone-ready evidence"
VERDICT_PARTIALLY_ADVANCED = "Partially advanced"
VERDICT_NOT_ADVANCED = "Not advanced"


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def flatten_dat_telemetry_for_gate(dat_telemetry):
    """
    Build shadow-report-shaped counters from Phase D summary dat_telemetry dict.
    """
    dt = dat_telemetry if isinstance(dat_telemetry, dict) else {}
    return {
        "phase_d_dat_selected_count": _safe_int(dt.get("dat_selected_count"), 0),
        "phase_d_dat_qa_pass_count": _safe_int(dt.get("dat_qa_pass_count"), 0),
        "phase_d_dat_qa_reject_count": _safe_int(dt.get("dat_qa_reject_count"), 0),
        "phase_d_dat_canonical_record_count": _safe_int(dt.get("dat_canonical_record_count"), 0),
        "phase_d_dat_v2_inserted_total": _safe_int(dt.get("phase_d_dat_v2_inserted_total"), 0),
        "phase_d_dat_v2_payload_attempted_total": _safe_int(dt.get("phase_d_dat_v2_payload_attempted_total"), 0),
        "post_medisoft_blocked_stage": str(dt.get("post_medisoft_blocked_stage", "") or "").strip().lower(),
        "phase_d_entity_scope": str(dt.get("phase_d_entity_scope", "") or "v1").strip() or "v1",
    }


def telemetry_indicates_dat_qa_full_block(dat_telemetry):
    """Same predicate as health runbook dat_qa_full_block focus (selected>0, pass==0, reject>0)."""
    dt = dat_telemetry if isinstance(dat_telemetry, dict) else {}
    selected = _safe_int(dt.get("dat_selected_count"), 0)
    qa_pass = _safe_int(dt.get("dat_qa_pass_count"), 0)
    qa_reject = _safe_int(dt.get("dat_qa_reject_count"), 0)
    return selected > 0 and qa_pass == 0 and qa_reject > 0


def merge_shadow_alias_telemetry(sp):
    """
    Phase F flattening publishes phase_d_dat_field_presence_by_alias; v2 depth checks use dat_field_presence_by_alias.
    Merge so milestone evaluation sees DOS/payer signal from packaged shadow JSON.
    """
    sp = sp if isinstance(sp, dict) else {}
    a = sp.get("dat_field_presence_by_alias") if isinstance(sp.get("dat_field_presence_by_alias"), dict) else {}
    b = sp.get("phase_d_dat_field_presence_by_alias") if isinstance(sp.get("phase_d_dat_field_presence_by_alias"), dict) else {}
    out = {}
    out.update(b)
    out.update(a)
    return out


def _shadow_payload_to_dat_telemetry(shadow_payload):
    """Accept shadow-run flat keys or dat_telemetry-shaped keys."""
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}
    if _safe_int(sp.get("dat_selected_count"), 0) or _safe_int(sp.get("dat_qa_pass_count"), 0):
        sp = dict(sp)
        if not isinstance(sp.get("dat_field_presence_by_alias"), dict) or not sp.get("dat_field_presence_by_alias"):
            merged = merge_shadow_alias_telemetry(sp)
            if merged:
                sp["dat_field_presence_by_alias"] = merged
        return sp
    return {
        "dat_selected_count": _safe_int(sp.get("phase_d_dat_selected_count"), 0),
        "dat_qa_pass_count": _safe_int(sp.get("phase_d_dat_qa_pass_count"), 0),
        "dat_qa_reject_count": _safe_int(sp.get("phase_d_dat_qa_reject_count"), 0),
        "dat_canonical_record_count": _safe_int(sp.get("phase_d_dat_canonical_record_count"), 0),
        "post_medisoft_blocked_stage": sp.get("post_medisoft_blocked_stage", ""),
        "phase_d_entity_scope": sp.get("phase_d_entity_scope", "v1"),
        "phase_d_dat_v2_inserted_total": _safe_int(sp.get("phase_d_dat_v2_inserted_total"), 0),
        "phase_d_dat_v2_payload_attempted_total": _safe_int(sp.get("phase_d_dat_v2_payload_attempted_total"), 0),
        "dat_field_presence_by_alias": merge_shadow_alias_telemetry(sp),
    }


def v2_milestone_applies(entity_scope, dat_telemetry):
    """
    When True, milestone exit may require phase_d_dat_v2_inserted_total > 0 if anchors exist.
    v1-only runs: returns False (v2 insert not required for QA milestone).
    """
    scope = str(entity_scope or "v1").strip().lower() or "v1"
    if scope != "v2":
        return False
    dt = dat_telemetry if isinstance(dat_telemetry, dict) else {}
    if _safe_int(dt.get("dat_selected_count"), 0) <= 0:
        return False
    # Enough payer/DOS signal: presence of join keys or non-zero v2 attempts implies depth was exercised.
    if _safe_int(dt.get("phase_d_dat_v2_payload_attempted_total"), 0) > 0:
        return True
    if _safe_int(dt.get("dat_qa_pass_count"), 0) <= 0:
        return False
    alias = dt.get("dat_field_presence_by_alias") if isinstance(dt.get("dat_field_presence_by_alias"), dict) else {}
    dos_ok = _safe_int(alias.get("DOS"), 0) + _safe_int(alias.get("DATE1"), 0) + _safe_int(alias.get("date_of_service"), 0)
    payer_ok = _safe_int(alias.get("PAYERID"), 0) + _safe_int(alias.get("INSID"), 0) + _safe_int(alias.get("payer_id"), 0)
    return dos_ok > 0 and payer_ok > 0


def v2_insert_required_but_missing(entity_scope, dat_telemetry):
    """Returns (required: bool, missing: bool)."""
    if not v2_milestone_applies(entity_scope, dat_telemetry):
        return False, False
    dt = dat_telemetry if isinstance(dat_telemetry, dict) else {}
    ins = _safe_int(dt.get("phase_d_dat_v2_inserted_total"), 0)
    return True, ins <= 0


def evaluate_phase_d_qa_milestone_exit(shadow_payload, evidence_paths=None, lab_root=None, run_id=None):
    """
    Returns dict:
      ok (bool): milestone criteria met for DAT lane
      reasons (list str): human-readable failures
      na (bool): DAT lane not exercised — milestone N/A, not a hard fail
    """
    reasons = []
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}

    selected = _safe_int(sp.get("phase_d_dat_selected_count"), 0)
    qa_pass = _safe_int(sp.get("phase_d_dat_qa_pass_count"), 0)
    canonical = _safe_int(sp.get("phase_d_dat_canonical_record_count"), 0)
    post_blocked = str(sp.get("post_medisoft_blocked_stage", "") or "").strip().lower()

    if selected <= 0:
        return {"ok": True, "reasons": [], "na": True, "detail": "dat_lane_not_exercised"}

    na = False
    dt_equiv = _shadow_payload_to_dat_telemetry(sp)
    if telemetry_indicates_dat_qa_full_block(dt_equiv):
        reasons.append("dat_qa_full_block: selected>0 but qa_pass==0 and qa_reject>0")

    if qa_pass <= 0:
        reasons.append("phase_d_dat_qa_pass_count_not_positive")
    if canonical <= 0:
        reasons.append("phase_d_dat_canonical_record_count_not_positive")

    entity_scope = str(sp.get("phase_d_entity_scope", "") or "v1").strip() or "v1"
    v2_req, v2_miss = v2_insert_required_but_missing(entity_scope, dt_equiv)
    if v2_req and v2_miss:
        reasons.append("phase_d_dat_v2_inserted_total_required_when_v2_depth_exercised")

    pipeline_ok = sp.get("pipeline_ok")
    if pipeline_ok is not True:
        reasons.append("pipeline_not_ok_for_milestone")

    ok = not reasons and pipeline_ok is True

    # dat_to_canonical_transition: pass>0 but canonical 0 — hard fail for exit
    if qa_pass > 0 and canonical <= 0:
        reasons.append("dat_to_canonical_transition_blocked")
        ok = False

    ev_ok, ev_detail = evidence_coherence(lab_root, run_id, evidence_paths)
    if not ev_ok:
        reasons.append(ev_detail or "evidence_incomplete")
        ok = False

    return {
        "ok": bool(ok),
        "reasons": reasons,
        "na": na,
        "detail": "; ".join(reasons) if reasons else "pass",
    }


def strict_gate_for_missing_shadow_report():
    """
    When the anchored shadow_run_report JSON is absent, do not evaluate the milestone gate
    from a Phase D summary alone.
    """
    return {
        "evaluated": False,
        "ok": False,
        "na": True,
        "reasons": [REASON_SHADOW_REPORT_MISSING],
        "detail": "anchored shadow_run_report json not found; milestone gate not evaluated",
    }


def strict_gate_from_shadow_payload(shadow_payload, lab_root=None, run_id=None):
    """
    Run evaluate_phase_d_qa_milestone_exit and map the result into strict_gate with evaluated=True.
    shadow_payload must include flattened phase_d_* keys and pipeline_ok from the shadow report.
    """
    result = evaluate_phase_d_qa_milestone_exit(
        shadow_payload, evidence_paths=None, lab_root=lab_root, run_id=run_id
    )
    return {
        "evaluated": True,
        "ok": bool(result.get("ok")),
        "na": bool(result.get("na")),
        "reasons": list(result.get("reasons") or []),
        "detail": str(result.get("detail") or ""),
    }


def dat_movement_from_phase_d_summary(d_summary):
    """
    Real DAT movement counters from anchored Phase D summary (dat_telemetry first).
    Returns (dat_selected_count, dat_qa_pass_count, dat_canonical_record_count).
    """
    s = d_summary if isinstance(d_summary, dict) else {}
    dt = s.get("dat_telemetry") if isinstance(s.get("dat_telemetry"), dict) else {}
    sel = _safe_int(dt.get("dat_selected_count"), 0)
    qp = _safe_int(dt.get("dat_qa_pass_count"), 0)
    can = _safe_int(dt.get("dat_canonical_record_count"), 0)
    return sel, qp, can


def derive_strict_milestone_verdict(strict_gate, d_summary):
    """
    Operator-facing verdict string from strict_gate + anchored Phase D summary movement.
    - Milestone-ready evidence: evaluated and ok and not na
    - Partially advanced: not milestone-ready but DAT movement in D summary
    - Not advanced: otherwise
    """
    sg = strict_gate if isinstance(strict_gate, dict) else {}
    evaluated = bool(sg.get("evaluated"))
    ok = bool(sg.get("ok"))
    na = bool(sg.get("na"))
    milestone_ready = evaluated and ok and (not na)
    if milestone_ready:
        return VERDICT_MILESTONE_READY
    sel, qp, can = dat_movement_from_phase_d_summary(d_summary)
    if sel > 0 or qp > 0 or can > 0:
        return VERDICT_PARTIALLY_ADVANCED
    return VERDICT_NOT_ADVANCED


def evaluate_phase_d_dat_lane_remediation_gate(shadow_payload):
    """
    Phase D completion only: DAT funnel + v2 constraints for resolver status.
    Does not require pipeline_ok, shadow evidence files, or Phase F — use for sync after Phase D.
    """
    reasons = []
    sp = shadow_payload if isinstance(shadow_payload, dict) else {}

    selected = _safe_int(sp.get("phase_d_dat_selected_count"), 0)
    qa_pass = _safe_int(sp.get("phase_d_dat_qa_pass_count"), 0)
    canonical = _safe_int(sp.get("phase_d_dat_canonical_record_count"), 0)

    if selected <= 0:
        return {"ok": True, "reasons": [], "na": True, "detail": "dat_lane_not_exercised"}

    na = False
    dt_equiv = _shadow_payload_to_dat_telemetry(sp)
    if telemetry_indicates_dat_qa_full_block(dt_equiv):
        reasons.append("dat_qa_full_block: selected>0 but qa_pass==0 and qa_reject>0")

    if qa_pass <= 0:
        reasons.append("phase_d_dat_qa_pass_count_not_positive")
    if canonical <= 0:
        reasons.append("phase_d_dat_canonical_record_count_not_positive")

    entity_scope = str(sp.get("phase_d_entity_scope", "") or "v1").strip() or "v1"
    v2_req, v2_miss = v2_insert_required_but_missing(entity_scope, dt_equiv)
    if v2_req and v2_miss:
        reasons.append("phase_d_dat_v2_inserted_total_required_when_v2_depth_exercised")

    ok = not reasons

    if qa_pass > 0 and canonical <= 0:
        reasons.append("dat_to_canonical_transition_blocked")
        ok = False

    return {
        "ok": bool(ok),
        "reasons": reasons,
        "na": na,
        "detail": "; ".join(reasons) if reasons else "pass",
    }


def evidence_coherence(lab_root, run_id, evidence_paths=None):
    """
    If lab_root and run_id provided, require core evidence files to exist.
    evidence_paths: optional list of full paths (skips default naming).
    """
    if not lab_root or not run_id:
        return True, ""
    rid = str(run_id).strip()
    if not rid:
        return True, ""
    reports = os.path.join(str(lab_root), "reports")
    if evidence_paths:
        missing = [p for p in evidence_paths if p and not os.path.isfile(p)]
        if missing:
            return False, "evidence_missing:{0}".format(len(missing))
        return True, ""
    missing = []
    for prefix, suffixes in EVIDENCE_PREFIXES:
        found = False
        for suf in suffixes:
            p = os.path.join(reports, "{0}{1}{2}".format(prefix, rid, suf))
            if os.path.isfile(p):
                found = True
                break
        if not found:
            missing.append(prefix)
    if missing:
        return False, "evidence_missing:{0}".format(",".join(missing))
    return True, ""


def build_shadow_payload_from_phase_d_summary(summary, include_pipeline_ok=False):
    """
    Map qa_canonical summary + dat_telemetry to flattened gate input.
    include_pipeline_ok: when True, set pipeline_ok from summary (for full milestone); else omit (Phase D sync).
    """
    summary = summary if isinstance(summary, dict) else {}
    dt = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    flat = flatten_dat_telemetry_for_gate(dt)
    flat["phase_d_entity_scope"] = str(summary.get("phase_d_entity_scope", "") or flat.get("phase_d_entity_scope") or "v1")
    if include_pipeline_ok:
        ok = summary.get("ok")
        flat["pipeline_ok"] = True if ok is None else bool(ok)
    flat["phase_d_dat_qa_reject_count"] = flat.get("phase_d_dat_qa_reject_count", _safe_int(dt.get("dat_qa_reject_count"), 0))
    # v2 keys may live on dat_telemetry root from compact flat merge
    for k in (
        "phase_d_dat_v2_inserted_total",
        "phase_d_dat_v2_payload_attempted_total",
    ):
        if k in dt:
            flat[k] = _safe_int(dt.get(k), 0)
    return flat
