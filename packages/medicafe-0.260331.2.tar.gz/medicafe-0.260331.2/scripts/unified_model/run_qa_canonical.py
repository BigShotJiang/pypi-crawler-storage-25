﻿#!/usr/bin/env python
"""
Phase D QA and canonicalization orchestrator.
Deterministic QA on ingest_artifact, replay routing for rejects, canonical extraction for passes.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import sqlite3
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import refresh_run_cursor_updated_at
from phase_d_common import (
    CANONICALIZATION_VERSION,
    QA_STAGE_PHASE_D,
    QA_POLICY_VERSION,
    PHASE_D_DB_WRITE_ERROR,
    PHASE_D_LOCK_FAIL,
    PHASE_D_REPLAY_QUEUE_ERROR,
    PHASE_D_STATE_WRITE_ERROR,
    QA_ARTIFACT_CLASS_REQUIRED_FIELDS,
    QA_PARSE_ERROR,
    compute_qa_deterministic_key,
    iso_utc_now,
    run_id,
)
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root
from parse_providers import parse_artifact
from parse_providers import get_last_parse_diag
from dat_contract import build_dat_decision_context, resolve_dat_fields
from qa_evaluator import evaluate_qa
from canonical_extractor import annotate_csv_docx_join, extract_canonical_records, build_domain_upserts
from failure_contract import build_failure_context
from join_contract import (
    EVENT_CSV_DOCX_JOIN_NEGOTIATION,
    EVENT_DAT_CSV_JOIN_NEGOTIATION,
    KEY_NEGOTIATION_LOG_REF,
    annotate_dat_csv_alignment,
    csv_docx_needs_negotiation_log,
    dat_csv_needs_negotiation_log,
    extend_summary_txt_lines,
    format_negotiation_log_ref,
)
import patient_field_mapper as patient_field_mapper_module
from patient_field_mapper import is_valid_external_patient_id_5_digit
from phase_d_v2_metrics import (
    CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED,
    CONSTRAINT_CLAIM_PARENT_UNRESOLVED,
    CONSTRAINT_COVERAGE_PARENT_UNRESOLVED,
    CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED,
    CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID,
    CONSTRAINT_PLAN_PAYER_UNRESOLVED,
    build_phase_d_dat_v2_compact_flat,
    build_phase_d_v2_domain_metrics,
    empty_executor_v2_stats,
    empty_extractor_v2_stats,
    merge_extractor_v2_stats,
    v2_inc_constraint,
    v2_inc_exec,
    v2_lane_from_row,
)


SUPPORTED_PHASE_D_ARTIFACT_CLASSES = ("csv", "jsonl", "837", "dat", "docx", "receipt", "xml")
PATIENT_CANONICAL_TYPES = ("patient_csv_row", "x12_member")

PHASE_D_SELECTION_SCOPE = "new_artifacts_current_qa_only"


def _sync_phase_d_remediation_safe(lab_root, rid, summary):
    try:
        from phase_d_remediation import sync_phase_d_remediation_after_phase_d
        sync_phase_d_remediation_after_phase_d(lab_root, rid, summary)
    except Exception:
        pass


def _phase_d_entity_scope_from_env():
    """Internal scope: v1 (default) or v2; set by run_shadow_pipeline via unified_rollout_policy."""
    try:
        from scripts.unified_model.unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
    except Exception:
        try:
            from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
        except Exception:
            INTERNAL_PHASE_D_ENTITY_SCOPE_ENV = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
    v = str(os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV, "") or "").strip().lower()
    if v == "v2":
        return "v2"
    return "v1"


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _normalize_artifact_class_filter(raw):
    """
    Parse artifact-class filter input.
    Accepts comma-separated string or iterable. Unknown classes are ignored.
    """
    if raw is None:
        return []
    values = []
    if isinstance(raw, str):
        values = [v.strip().lower() for v in raw.split(",")]
    elif isinstance(raw, (list, tuple, set)):
        values = [str(v).strip().lower() for v in raw]
    filtered = []
    seen = set()
    for value in values:
        if not value or value in seen:
            continue
        if value in SUPPORTED_PHASE_D_ARTIFACT_CLASSES:
            filtered.append(value)
            seen.add(value)
    return filtered


def _artifact_class_from_payload_json(payload_json):
    """Best-effort artifact_class read from ingest payload JSON."""
    try:
        payload = json.loads(payload_json) if payload_json else {}
    except (ValueError, TypeError):
        return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("artifact_class") or "").strip().lower()


def _filter_rows_by_artifact_classes(rows, artifact_classes):
    """Filter eligible ingest rows by artifact class when filter is provided."""
    if not artifact_classes:
        return list(rows or [])
    allowed = set(artifact_classes)
    out = []
    for row in rows or []:
        payload_json = row[-1] if isinstance(row, (list, tuple)) and len(row) > 0 else ""
        artifact_class = _artifact_class_from_payload_json(payload_json)
        if artifact_class in allowed:
            out.append(row)
    return out


def _phase_run_ids_hint_from_env():
    raw = str(os.environ.get("MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON", "") or "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    out = {}
    for phase in ("B", "C", "D", "E"):
        rid = str(data.get(phase, "") or "").strip()
        if rid:
            out[phase] = rid
    return out


def _resolve_phase_c_summary_for_zero_selection(lab_root):
    """
    Coherence-first: pipeline hint C id, then diagnostics phase map C id, else run_cursor.last_phase_c_run_id.
    Returns (run_id_used, path_used, phase_c_summary_dict_or_none, mismatch_warning_str,
             resolution_source_str, expected_phase_c_run_id_str).
    """
    reports_dir = os.path.join(lab_root, "reports")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state = {}
    cursor = {}
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    if not isinstance(state, dict):
        state = {}
    if os.path.isfile(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    if not isinstance(cursor, dict):
        cursor = {}
    run_id_used = ""
    path_used = ""
    resolution_source = ""
    hint = _phase_run_ids_hint_from_env()
    expected_phase_c_run_id = str(hint.get("C", "") or "").strip()
    if expected_phase_c_run_id:
        p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(expected_phase_c_run_id))
        if os.path.isfile(p):
            path_used = p
            run_id_used = expected_phase_c_run_id
            resolution_source = "pipeline_phase_hint"
    if not path_used:
        pr = state.get("last_shadow_pipeline_phase_run_ids")
        rid_c = ""
        if isinstance(pr, dict):
            rid_c = str(pr.get("C", "") or "").strip()
        if rid_c:
            p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid_c))
            if os.path.isfile(p):
                path_used = p
                run_id_used = rid_c
                resolution_source = "diagnostics_state_phase_map"
    if not path_used:
        cr = str(cursor.get("last_phase_c_run_id", "") or "").strip()
        if cr:
            p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(cr))
            if os.path.isfile(p):
                path_used = p
                run_id_used = cr
                resolution_source = "run_cursor"
    if not resolution_source:
        resolution_source = "missing"
    mismatch_parts = []
    cursor_c = str(cursor.get("last_phase_c_run_id", "") or "").strip()
    if expected_phase_c_run_id and run_id_used and expected_phase_c_run_id != run_id_used:
        mismatch_parts.append(
            "pipeline_hint.C={0} vs resolved_phase_c={1}".format(expected_phase_c_run_id, run_id_used)
        )
    if run_id_used and cursor_c and run_id_used != cursor_c:
        mismatch_parts.append(
            "run_cursor.last_phase_c_run_id={0} vs resolved_phase_c={1}".format(cursor_c, run_id_used)
        )
    mismatch = "; ".join(mismatch_parts)
    phase_c_data = None
    if path_used:
        try:
            with open(path_used, "r", encoding="utf-8") as f:
                phase_c_data = json.load(f)
        except Exception:
            phase_c_data = None
    if phase_c_data is not None and not isinstance(phase_c_data, dict):
        phase_c_data = None
    return run_id_used, path_used, phase_c_data, mismatch, resolution_source, expected_phase_c_run_id


def _apply_zero_selection_enrichment(lab_root, summary, n_eligible_before_filter, n_after_filter, artifact_class_filter):
    """Populate zero-selection lineage fields when rows_selected == 0. Mutates summary."""
    rid_used, path_used, pc, mismatch, resolution_source, expected_phase_c_run_id = _resolve_phase_c_summary_for_zero_selection(lab_root)
    summary["phase_c_summary_run_id_used_for_zero_selection"] = rid_used or ""
    summary["phase_c_summary_path_used_for_zero_selection"] = path_used or ""
    summary["phase_c_context_mismatch_warning"] = mismatch or ""
    summary["phase_c_summary_resolution_source"] = resolution_source or ""
    summary["phase_c_expected_run_id_for_zero_selection"] = expected_phase_c_run_id or ""
    summary["phase_c_lineage_coherent"] = (not expected_phase_c_run_id) or (rid_used == expected_phase_c_run_id)
    dup_dom = False
    if isinstance(pc, dict):
        dup_dom = bool(pc.get("phase_c_duplicate_dominant"))
        try:
            ri = int(pc.get("rows_inserted") or 0)
            sk = int(pc.get("rows_skipped_duplicate") or 0)
        except (TypeError, ValueError):
            ri, sk = 0, 0
        if not dup_dom and sk >= max(1, ri):
            dup_dom = True
    snapshot = {}
    try:
        from phase_d_historical_reprocess import collect_phase_d_reject_snapshot
        snapshot = collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None)
    except Exception:
        snapshot = {}
    if not isinstance(snapshot, dict):
        snapshot = {}
    h_by_class = snapshot.get("historical_reject_counts_by_class") if isinstance(snapshot.get("historical_reject_counts_by_class"), dict) else {}
    h_by_ver = snapshot.get("historical_reject_counts_by_version") if isinstance(snapshot.get("historical_reject_counts_by_version"), dict) else {}
    summary["historical_reject_counts_by_class"] = dict(h_by_class)
    summary["historical_reject_counts_by_version"] = dict(h_by_ver)
    tgt = snapshot.get("targeted_artifact_classes") or []
    summary["historical_reprocess_targeted_artifact_classes"] = list(tgt) if isinstance(tgt, list) else []
    hist_exist = False
    if bool(snapshot.get("ok")):
        try:
            tot = sum(int(v or 0) for v in h_by_class.values())
        except Exception:
            tot = 0
        try:
            tac = int(snapshot.get("targeted_artifact_count") or 0)
        except (TypeError, ValueError):
            tac = 0
        hist_exist = tot > 0 or tac > 0
    summary["historical_reprocess_candidate"] = bool(dup_dom) and hist_exist
    reasons = []
    if dup_dom:
        reasons.append("phase_c_duplicate_dominant")
    if n_eligible_before_filter == 0:
        reasons.append("no_unevaluated_artifacts_current_qa")
    if hist_exist:
        reasons.append("historical_rejects_exist")
    acf = list(artifact_class_filter or [])
    if n_eligible_before_filter > 0 and n_after_filter == 0 and len(acf) > 0:
        reasons.append("artifact_class_filter_excluded_all")
    summary["zero_selection_reason_codes"] = reasons
    return summary


def _sort_phase_d_eligible_rows(rows):
    """
    Stable sort: non-dat artifact classes before dat (upstream_first_insert_or_ignore).
    Tie-break by artifact_id ascending.
    """
    rows = list(rows or [])

    def _sort_key(row):
        payload_json = row[-1] if isinstance(row, (list, tuple)) and len(row) > 0 else ""
        artifact_class = _artifact_class_from_payload_json(payload_json)
        tier = 1 if artifact_class == "dat" else 0
        aid = 0
        if isinstance(row, (list, tuple)) and len(row) > 0:
            try:
                aid = int(row[0])
            except (TypeError, ValueError):
                aid = 0
        return (tier, aid)

    return sorted(rows, key=_sort_key)


_DAT_EVIDENCE_KEYS = (
    "source_ref",
    "record_index",
    "attachment_sha256",
    "resolved_patient_id",
    "resolved_date_of_service",
    "resolved_payer_id",
    "resolved_chart_number",
    "resolved_insurance_name",
    "resolved_member_id",
    "resolved_patient_name",
)


def _merge_dat_context(context, row):
    merged = dict(context or {})
    if not isinstance(row, dict):
        return merged
    for key in _DAT_EVIDENCE_KEYS:
        if key not in row:
            continue
        value = row.get(key)
        if value is None:
            continue
        if isinstance(value, str):
            value = value.strip()
            if not value:
                continue
        merged[key] = value
    return merged


def _log_extractor_skip_events(conn, skip_events):
    for event in skip_events or []:
        if not isinstance(event, dict):
            continue
        conn.execute(
            "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
            (
                event.get("artifact_id") or 0,
                "extractor_skip",
                json.dumps(event, separators=(",", ":"), ensure_ascii=True),
            ),
        )


def _log_constraint_fail(conn, artifact_id, row, reason_code, reason, v2_exec_stats=None):
    """Persist deterministic constraint-fail evidence to rule_decision_log."""
    context = _merge_dat_context({
        "entity": "patient",
        "constraint_name": "external_patient_id_5_digit",
        "reason_code": reason_code,
        "reason": reason,
        "patient_key": row.get("patient_key") or "",
        "external_patient_id": row.get("external_patient_id") or "",
        "canonical_type": row.get("canonical_type") or "",
        "canonical_key": row.get("canonical_key") or "",
        "source_system": row.get("source_system") or "xp_local",
    }, row)
    conn.execute(
        "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
        (
            artifact_id,
            "constraint_fail",
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    if v2_exec_stats is not None:
        lane = v2_lane_from_row(context)
        if lane and reason_code:
            v2_inc_constraint(v2_exec_stats, lane, str(reason_code), 1)

def _build_planning_telemetry(canonical_records, reject_counts_by_code, reject_counts_by_artifact_code,
                             constraint_skip_counts):
    """Build telemetry snapshot used to evaluate deferred workstream need."""
    canonical_counts = {}
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        if not ctype:
            continue
        canonical_counts[ctype] = canonical_counts.get(ctype, 0) + 1

    identity_total = int((reject_counts_by_code or {}).get("QA_IDENTITY_INCOMPLETE", 0))
    identity_837 = int((reject_counts_by_artifact_code or {}).get("837|QA_IDENTITY_INCOMPLETE", 0))
    remittance_rows = int(canonical_counts.get("remittance_row", 0))
    non_patient_total = 0
    for ctype, count in canonical_counts.items():
        if ctype not in PATIENT_CANONICAL_TYPES:
            non_patient_total += int(count or 0)

    invalid_external_id = int((constraint_skip_counts or {}).get("patient_invalid_external_id", 0))
    return {
        "workstream_b": {
            "qa_identity_incomplete_rejects_total": identity_total,
            "qa_identity_incomplete_rejects_837": identity_837,
            "activation_recommended": bool(identity_837 > 0),
            "activation_rule": "activate_if_identity_incomplete_837_gt_0",
        },
        "workstream_c": {
            "invalid_external_patient_id_count": invalid_external_id,
            "activation_recommended": bool(invalid_external_id > 0),
            "activation_rule": "activate_if_invalid_external_id_gt_0",
        },
        "workstream_d": {
            "canonical_count_remittance_row": remittance_rows,
            "canonical_count_non_patient_total": non_patient_total,
            "activation_recommended": bool(remittance_rows > 0),
            "activation_rule": "activate_if_remittance_row_gt_0",
        },
    }


def _build_dat_telemetry(dat_selected_count, dat_qa_pass_count, dat_qa_reject_count,
                         dat_reject_counts_by_reason, canonical_records, entity_upsert_counts,
                         entity_scope, dat_v2_compact_flat=None, dat_field_presence=None,
                         dat_parse_diagnostics=None, dat_file_prefix_counts=None,
                         dat_reject_file_prefix_counts=None):
    """Build DAT-specific funnel telemetry for Phase D summaries."""
    dat_canonical_record_count = 0
    for rec in canonical_records or []:
        if rec.get("canonical_type") == "dat_record":
            dat_canonical_record_count += 1
    post_medisoft_exercised = bool(
        dat_selected_count > 0 and (dat_qa_pass_count > 0 or dat_canonical_record_count > 0)
    )
    if post_medisoft_exercised:
        blocked_stage = ""
    elif dat_qa_reject_count > 0:
        blocked_stage = "qa"
    elif dat_selected_count > 0:
        blocked_stage = "canonicalization"
    else:
        blocked_stage = "not_exercised"
    telem = {
        "dat_selected_count": int(dat_selected_count or 0),
        "dat_qa_pass_count": int(dat_qa_pass_count or 0),
        "dat_qa_reject_count": int(dat_qa_reject_count or 0),
        "dat_qa_reject_counts_by_reason": dat_reject_counts_by_reason or {},
        "dat_field_presence_by_alias": dat_field_presence or {},
        "dat_parse_diagnostics": dat_parse_diagnostics or {},
        "dat_file_prefix_counts": dat_file_prefix_counts or {},
        "dat_reject_file_prefix_counts": dat_reject_file_prefix_counts or {},
        "dat_canonical_record_count": dat_canonical_record_count,
        "phase_d_entity_scope": str(entity_scope or "v1"),
        "dat_entity_upsert_counts": entity_upsert_counts or {},
        "post_medisoft_exercised": post_medisoft_exercised,
        "post_medisoft_blocked_stage": blocked_stage,
    }
    if isinstance(dat_v2_compact_flat, dict):
        for k, v in dat_v2_compact_flat.items():
            telem[k] = v
    return telem


def _dat_alias_presence_counts_from_envelope(envelope):
    """
    Record-level alias presence counters for DAT parser mismatch triage.
    """
    counters = {
        "records_seen": 0,
        "PATID": 0,
        "patient_id": 0,
        "DOS": 0,
        "DATE1": 0,
        "date_of_service": 0,
        "PAYERID": 0,
        "INSID": 0,
        "payer_id": 0,
    }
    records = envelope.get("records") if isinstance(envelope, dict) else None
    if not isinstance(records, list):
        return counters
    for rec in records:
        if not isinstance(rec, dict):
            continue
        counters["records_seen"] += 1
        for key in ("PATID", "patient_id", "DOS", "DATE1", "date_of_service", "PAYERID", "INSID", "payer_id"):
            value = rec.get(key)
            if value is None:
                continue
            if str(value).strip():
                counters[key] += 1
    return counters


def _merge_counter_dict(base, add):
    """In-place sum merge for integer-like telemetry dicts."""
    if not isinstance(base, dict) or not isinstance(add, dict):
        return base
    for key, value in add.items():
        try:
            inc = int(value or 0)
        except Exception:
            continue
        base[key] = int(base.get(key, 0) or 0) + inc
    return base


def _append_limited_sample(samples, value, limit=3):
    if not isinstance(samples, list):
        return
    text_value = str(value or '').strip()
    if not text_value or text_value in samples:
        return
    if len(samples) < int(limit or 0):
        samples.append(text_value)


def _file_prefix_from_locator(locator):
    name = os.path.basename(str(locator or '').strip())
    if not name:
        return 'unknown'
    stem = name.split('.')[0]
    prefix = stem.split('_')[0].strip().upper()
    return prefix or 'unknown'


def _merge_dat_parse_diagnostics(base, envelope):
    diag = envelope.get('parser_diagnostics', {}) if isinstance(envelope, dict) else {}
    if not isinstance(base, dict) or not isinstance(diag, dict):
        return base
    base['tuple_parse_failure_count'] = int(base.get('tuple_parse_failure_count', 0) or 0) + int(diag.get('tuple_parse_failure_count', 0) or 0)
    if not str(base.get('first_failure_class', '') or '').strip() and str(diag.get('first_failure_class', '') or '').strip():
        base['first_failure_class'] = str(diag.get('first_failure_class', '') or '').strip()
    if not str(base.get('first_failure_detail', '') or '').strip() and str(diag.get('first_failure_detail', '') or '').strip():
        base['first_failure_detail'] = str(diag.get('first_failure_detail', '') or '').strip()
    _merge_counter_dict(base.get('record_shape_counts', {}), diag.get('record_shape_counts', {}))
    for item in diag.get('raw_key_sets_sample', []) if isinstance(diag.get('raw_key_sets_sample', []), list) else []:
        _append_limited_sample(base.get('raw_key_sets_sample', []), item, limit=3)
    return base


def _select_dat_sample_record(records):
    first_dict = (None, None)
    for idx, rec in enumerate(records or []):
        if not isinstance(rec, dict):
            continue
        if first_dict[0] is None:
            first_dict = (rec, idx)
        resolved = resolve_dat_fields(rec)
        if any(str(resolved.get(key, '') or '').strip() for key in ('patient_id', 'chart_number', 'date_of_service', 'payer_id', 'patient_name', 'first_name', 'last_name')):
            return (rec, idx)
    return first_dict


def _build_dat_reject_sample(artifact_id, reject_code, reject_reason, envelope, locator, source_ref, attachment_sha256, parse_diag=None):
    sample = {
        "artifact_id": artifact_id,
        "reject_code": reject_code,
        "reason": reject_reason,
        "locator": str(locator or '')[:80],
        "locator_full": str(locator or ''),
        "artifact_name": os.path.basename(str(locator or '')),
        "dat_file_prefix": _file_prefix_from_locator(locator),
        "source_ref": str(source_ref or ''),
        "attachment_sha256": str(attachment_sha256 or ''),
    }
    if isinstance(parse_diag, dict) and parse_diag:
        sample["parse_diag"] = parse_diag
    if not isinstance(envelope, dict):
        return sample
    sample["record_count"] = int(envelope.get("record_count", 0) or 0)
    parser_diag = envelope.get("parser_diagnostics", {}) if isinstance(envelope.get("parser_diagnostics", {}), dict) else {}
    if parser_diag.get("raw_key_sets_sample"):
        sample["raw_key_sets_sample"] = list(parser_diag.get("raw_key_sets_sample", []))[:3]
    rec, record_index = _select_dat_sample_record(envelope.get("records") if isinstance(envelope.get("records"), list) else [])
    if isinstance(rec, dict):
        context = build_dat_decision_context(rec, provenance={
            "source_ref": source_ref,
            "record_index": record_index,
            "attachment_sha256": attachment_sha256,
        })
        sample.update(context)
        raw_keys = sorted([str(key) for key in rec.keys() if str(key or '').strip()])
        if raw_keys:
            sample["raw_keys"] = raw_keys[:12]
    return sample


def _ensure_rule_decision_log_supports_extractor_skip(conn):
    """Upgrade legacy rule_decision_log CHECK constraint to allow extractor_skip."""
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='rule_decision_log'"
    ).fetchone()
    create_sql = (
        "CREATE TABLE IF NOT EXISTS rule_decision_log ("
        "decision_id INTEGER PRIMARY KEY,"
        "artifact_id INTEGER,"
        "mapping_rule_id INTEGER,"
        "constraint_rule_id INTEGER,"
        "decision_type TEXT NOT NULL CHECK (decision_type IN ('mapping_applied','constraint_pass','constraint_fail','manual_override','extractor_skip')),"
        "decision_context_json TEXT,"
        "created_at TEXT NOT NULL DEFAULT (datetime('now')),"
        "FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE SET NULL,"
        "FOREIGN KEY (mapping_rule_id) REFERENCES mapping_rule(mapping_rule_id) ON DELETE SET NULL,"
        "FOREIGN KEY (constraint_rule_id) REFERENCES constraint_rule(constraint_rule_id) ON DELETE SET NULL"
        ")"
    )
    if not row or not row[0]:
        conn.execute(create_sql)
        return
    existing_sql = str(row[0] or "")
    if "extractor_skip" in existing_sql:
        return
    conn.execute("ALTER TABLE rule_decision_log RENAME TO rule_decision_log_legacy")
    conn.execute(create_sql)
    conn.execute(
        "INSERT INTO rule_decision_log (decision_id, artifact_id, mapping_rule_id, constraint_rule_id, decision_type, decision_context_json, created_at) "
        "SELECT decision_id, artifact_id, mapping_rule_id, constraint_rule_id, decision_type, decision_context_json, created_at "
        "FROM rule_decision_log_legacy"
    )
    conn.execute("DROP TABLE rule_decision_log_legacy")


def _ensure_planning_telemetry_table(conn):
    """Create planning telemetry table when missing for backward-compatible lab DBs."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS qa_planning_telemetry_log ("
        "telemetry_id INTEGER PRIMARY KEY,"
        "qa_stage TEXT NOT NULL,"
        "qa_version TEXT NOT NULL,"
        "canonicalization_version TEXT NOT NULL,"
        "telemetry_json TEXT NOT NULL,"
        "created_at TEXT NOT NULL DEFAULT (datetime('now'))"
        ")"
    )

def _log_planning_telemetry(conn, telemetry):
    """Persist planning telemetry snapshot to dedicated planning telemetry log."""
    _ensure_planning_telemetry_table(conn)
    context = {
        "event": "planning_telemetry_snapshot",
        "qa_stage": QA_STAGE_PHASE_D,
        "qa_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "telemetry": telemetry,
    }
    conn.execute(
        "INSERT INTO qa_planning_telemetry_log (qa_stage, qa_version, canonicalization_version, telemetry_json) "
        "VALUES (?, ?, ?, ?)",
        (
            QA_STAGE_PHASE_D,
            QA_POLICY_VERSION,
            CANONICALIZATION_VERSION,
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )


def _log_join_negotiation(conn, event_name, telemetry, run_id_param):
    """Persist join-negotiation evidence (csv_docx or dat_csv); returns telemetry_id or None."""
    telemetry = telemetry or {}
    if event_name == EVENT_CSV_DOCX_JOIN_NEGOTIATION:
        if not csv_docx_needs_negotiation_log(telemetry):
            return None
    elif event_name == EVENT_DAT_CSV_JOIN_NEGOTIATION:
        if not dat_csv_needs_negotiation_log(telemetry):
            return None
    else:
        return None
    _ensure_planning_telemetry_table(conn)
    context = {
        "event": event_name,
        "run_id": str(run_id_param or ""),
        "qa_stage": QA_STAGE_PHASE_D,
        "qa_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "telemetry": telemetry,
    }
    cur = conn.execute(
        "INSERT INTO qa_planning_telemetry_log (qa_stage, qa_version, canonicalization_version, telemetry_json) "
        "VALUES (?, ?, ?, ?)",
        (
            QA_STAGE_PHASE_D,
            QA_POLICY_VERSION,
            CANONICALIZATION_VERSION,
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    return cur.lastrowid


def _log_constraint_fail_spec(conn, artifact_id, context, row=None, v2_exec_stats=None):
    """rule_decision_log row with arbitrary JSON context (Phase D v2 spec-aligned fields)."""
    context = _merge_dat_context(context, row)
    conn.execute(
        "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
        (
            artifact_id,
            "constraint_fail",
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    if v2_exec_stats is not None and isinstance(context, dict):
        lane = v2_lane_from_row(context)
        rc = context.get("reason_code") or ""
        if lane and rc:
            v2_inc_constraint(v2_exec_stats, lane, str(rc), 1)

def _scalar_id(conn, sql, args):
    cur = conn.execute(sql, args)
    row = cur.fetchone()
    return row[0] if row else None


def _execute_domain_upserts_v2_chain(conn, domain_upsert_rows, counts, v2_exec_stats=None):
    """After patients: payer -> insurance_plan -> coverage -> encounter -> claim -> claim_line."""
    seen_payer = set()
    for row in domain_upsert_rows.get("payer") or []:
        pay_key = row.get("payer_key")
        if not pay_key or pay_key in seen_payer:
            continue
        seen_payer.add(pay_key)
        lane = v2_lane_from_row(row)
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "payer", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO payer (payer_key, payer_external_id, payer_name, endpoint_name) "
            "VALUES (?, ?, ?, ?)",
            (
                pay_key,
                row.get("payer_external_id"),
                row.get("payer_name"),
                row.get("endpoint_name") or "xp_local",
            ),
        )
        if cur.rowcount > 0:
            counts["payer"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "payer", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "payer", "ignored_duplicate", 1)

    seen_plan = set()
    for row in domain_upsert_rows.get("insurance_plan") or []:
        plan_key = row.get("plan_key")
        if not plan_key or plan_key in seen_plan:
            continue
        seen_plan.add(plan_key)
        pay_key = row.get("payer_key")
        lane = v2_lane_from_row(row)
        payer_id = _scalar_id(conn, "SELECT payer_id FROM payer WHERE payer_key=?", (pay_key,))
        if payer_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "insurance_plan",
                    "constraint_name": "payer_fk",
                    "reason_code": CONSTRAINT_PLAN_PAYER_UNRESOLVED,
                    "reason": "payer row missing for plan_key",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "plan_key": plan_key or "",
                    "payer_key": pay_key or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO insurance_plan (plan_key, payer_id, medisoft_insurance_ids_json) "
            "VALUES (?, ?, ?)",
            (plan_key, payer_id, row.get("medisoft_insurance_ids_json") or "[]"),
        )
        if cur.rowcount > 0:
            counts["insurance_plan"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "ignored_duplicate", 1)

    seen_cov = set()
    for row in domain_upsert_rows.get("coverage") or []:
        ckey = row.get("coverage_key")
        if not ckey or ckey in seen_cov:
            continue
        seen_cov.add(ckey)
        lane = v2_lane_from_row(row)
        patient_id = _scalar_id(conn, "SELECT patient_id FROM patient WHERE patient_key=?", (row.get("patient_key"),))
        plan_id = _scalar_id(conn, "SELECT plan_id FROM insurance_plan WHERE plan_key=?", (row.get("plan_key"),))
        if patient_id is None or plan_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "coverage",
                    "constraint_name": "coverage_parent_fk",
                    "reason_code": CONSTRAINT_COVERAGE_PARENT_UNRESOLVED,
                    "reason": "patient or plan missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "patient_key": row.get("patient_key") or "",
                    "plan_key": row.get("plan_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "coverage", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO coverage (coverage_key, patient_id, plan_id, effective_start, effective_end, active_flag) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                ckey,
                patient_id,
                plan_id,
                row.get("effective_start"),
                row.get("effective_end"),
                int(row.get("active_flag") or 1),
            ),
        )
        if cur.rowcount > 0:
            counts["coverage"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "coverage", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "coverage", "ignored_duplicate", 1)

    seen_enc = set()
    for row in domain_upsert_rows.get("encounter") or []:
        ekey = row.get("encounter_key")
        if not ekey or ekey in seen_enc:
            continue
        seen_enc.add(ekey)
        lane = v2_lane_from_row(row)
        patient_id = _scalar_id(conn, "SELECT patient_id FROM patient WHERE patient_key=?", (row.get("patient_key"),))
        if patient_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "encounter",
                    "constraint_name": "encounter_patient_fk",
                    "reason_code": CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED,
                    "reason": "patient missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "patient_key": row.get("patient_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "encounter", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO encounter (encounter_key, patient_id, date_of_service, source_artifact_id, diagnosis_code, eye_side) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                ekey,
                patient_id,
                row.get("date_of_service"),
                row.get("source_artifact_id"),
                row.get("diagnosis_code"),
                row.get("eye_side"),
            ),
        )
        if cur.rowcount > 0:
            counts["encounter"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "encounter", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "encounter", "ignored_duplicate", 1)

    seen_claim = set()
    for row in domain_upsert_rows.get("claim") or []:
        ck = row.get("claim_key")
        if not ck or ck in seen_claim:
            continue
        seen_claim.add(ck)
        lane = v2_lane_from_row(row)
        encounter_id = _scalar_id(
            conn, "SELECT encounter_id FROM encounter WHERE encounter_key=?", (row.get("encounter_key"),)
        )
        payer_id = _scalar_id(conn, "SELECT payer_id FROM payer WHERE payer_key=?", (row.get("payer_key"),))
        if encounter_id is None or payer_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "claim",
                    "constraint_name": "claim_parent_fk",
                    "reason_code": CONSTRAINT_CLAIM_PARENT_UNRESOLVED,
                    "reason": "encounter or payer missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "encounter_key": row.get("encounter_key") or "",
                    "payer_key": row.get("payer_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO claim (claim_key, encounter_id, payer_id, claim_number, status, "
            "charged_amount, allowed_amount, paid_amount, patient_resp_amount, source_artifact_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                ck,
                encounter_id,
                payer_id,
                row.get("claim_number"),
                row.get("status"),
                row.get("charged_amount"),
                row.get("allowed_amount"),
                row.get("paid_amount"),
                row.get("patient_resp_amount"),
                row.get("source_artifact_id"),
            ),
        )
        if cur.rowcount > 0:
            counts["claim"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "claim", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim", "ignored_duplicate", 1)

    seen_line = set()
    for row in domain_upsert_rows.get("claim_line") or []:
        lk = row.get("claim_line_key")
        if not lk or lk in seen_line:
            continue
        seen_line.add(lk)
        lane = v2_lane_from_row(row)
        claim_id = _scalar_id(conn, "SELECT claim_id FROM claim WHERE claim_key=?", (row.get("claim_key"),))
        if claim_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "claim_line",
                    "constraint_name": "claim_line_parent_fk",
                    "reason_code": CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED,
                    "reason": "claim missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "claim_key": row.get("claim_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim_line", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO claim_line (claim_line_key, claim_id, line_number, cpt_code, diagnosis_pointer, charged_amount, paid_amount) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                lk,
                claim_id,
                int(row.get("line_number") or 1),
                row.get("cpt_code"),
                row.get("diagnosis_pointer"),
                row.get("charged_amount"),
                row.get("paid_amount"),
            ),
        )
        if cur.rowcount > 0:
            counts["claim_line"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "claim_line", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim_line", "ignored_duplicate", 1)


def _execute_domain_upserts(conn, domain_upsert_rows, entity_scope="v1", v2_exec_stats=None):
    """
    Write domain entity upserts to DB. v1: patient only; v2: full chain per PHASE_D_V2_ENTITY_UPSERT_SPEC subset.
    Returns (entity_counts, constraint_skip_counts).
    """
    entity_scope = str(entity_scope or "v1").strip().lower()
    if entity_scope not in ("v1", "v2"):
        entity_scope = "v1"
    counts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    constraint_skip_counts = {"patient_invalid_external_id": 0}
    for row in domain_upsert_rows.get("patient") or []:
        external_patient_id = row.get("external_patient_id")
        artifact_id = row.get("artifact_id")
        lane = v2_lane_from_row(row)
        if not is_valid_external_patient_id_5_digit(external_patient_id):
            constraint_skip_counts["patient_invalid_external_id"] += 1
            _log_constraint_fail(
                conn,
                artifact_id,
                row,
                CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID,
                "external_patient_id must match ^[0-9]{5}$",
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "patient", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO patient (patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                row.get("patient_key"),
                external_patient_id,
                row.get("full_name"),
                row.get("birth_date"),
                row.get("source_system") or "xp_local",
            ),
        )
        if cur.rowcount > 0:
            counts["patient"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "patient", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "patient", "ignored_duplicate", 1)
    if entity_scope == "v2":
        _execute_domain_upserts_v2_chain(conn, domain_upsert_rows, counts, v2_exec_stats=v2_exec_stats)
    return counts, constraint_skip_counts


def _compute_phase_d_v2_metrics_bundle(entity_scope, v2_extractor_accum, v2_exec_stats):
    """Full phase_d_v2_domain_metrics and DAT-lane compact flat dict; empty for v1."""
    if str(entity_scope or "v1").strip().lower() != "v2":
        return {}, {}
    ext = v2_extractor_accum
    if ext is None:
        ext = empty_extractor_v2_stats()
    exe = v2_exec_stats
    if exe is None:
        exe = empty_executor_v2_stats()
    full = build_phase_d_v2_domain_metrics(ext, exe)
    return full, build_phase_d_dat_v2_compact_flat(full)


def select_eligible_artifacts(conn, qa_version):
    """Select ingest_artifact rows not yet evaluated for (phase_d, qa_version)."""
    cur = conn.execute(
        "SELECT artifact_id, ingest_key, source_system, source_type, source_ref, attachment_sha256, payload_json "
        "FROM ingest_artifact WHERE artifact_id NOT IN "
        "(SELECT artifact_id FROM qa_result WHERE qa_stage=? AND qa_version=?)",
        (QA_STAGE_PHASE_D, qa_version),
    )
    return cur.fetchall()


def run_qa_canonical(lab_root, artifact_classes=None):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    entity_scope = _phase_d_entity_scope_from_env()
    artifact_class_filter = _normalize_artifact_class_filter(artifact_classes)
    reports_dir = os.path.join(lab_root, "reports")
    summary_json_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(rid))
    summary_txt_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.txt".format(rid))
    reject_samples_path = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")

    if not os.path.exists(db_path):
        # Do not run zero-selection enrichment: eligibility was never computed.
        summary_fail = _build_summary(
            rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR, entity_scope=entity_scope,
            dat_csv_join_telemetry={},
            artifact_class_filter=artifact_class_filter,
            zero_selection_analysis_available=False,
        )
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, summary_fail.get("error_code")

    qa_results = []
    replay_entries = []
    canonical_records = []
    domain_upsert_rows = {"patient": [], "payer": [], "insurance_plan": [], "coverage": [], "encounter": [], "claim": [], "claim_line": []}
    entity_upserts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    constraint_skip_counts = {"patient_invalid_external_id": 0}
    reject_samples = []
    reject_counts_by_code = {}
    reject_counts_by_artifact_code = {}
    dat_selected_count = 0
    dat_qa_pass_count = 0
    dat_qa_reject_count = 0
    dat_reject_counts_by_reason = {}
    dat_field_presence = {
        "records_seen": 0,
        "PATID": 0,
        "patient_id": 0,
        "DOS": 0,
        "DATE1": 0,
        "date_of_service": 0,
        "PAYERID": 0,
        "INSID": 0,
        "payer_id": 0,
    }
    dat_parse_diagnostics = {
        "tuple_parse_failure_count": 0,
        "first_failure_class": "",
        "first_failure_detail": "",
        "record_shape_counts": {},
        "raw_key_sets_sample": [],
    }
    dat_file_prefix_counts = {}
    dat_reject_file_prefix_counts = {}
    csv_docx_join_telemetry = {}
    dat_csv_join_telemetry = {}
    v2_extractor_accum = empty_extractor_v2_stats() if entity_scope == "v2" else None

    try:
        conn = sqlite3.connect(db_path)
        rows_all = select_eligible_artifacts(conn, QA_POLICY_VERSION)
        n_eligible_before_filter = len(rows_all)
        rows = _filter_rows_by_artifact_classes(rows_all, artifact_class_filter)
        n_after_filter = len(rows)
        rows = _sort_phase_d_eligible_rows(rows)
        conn.close()
    except Exception as e:
        # Do not run zero-selection enrichment: eligibility query failed before counts are valid.
        summary_fail = _build_summary(
            rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR,
            error_detail=str(e)[:200], source_exception_class=e.__class__.__name__,
            entity_scope=entity_scope,
            dat_csv_join_telemetry={},
            artifact_class_filter=artifact_class_filter,
            zero_selection_analysis_available=False,
        )
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, PHASE_D_DB_WRITE_ERROR

    if not rows:
        full_v2, flat_v2 = _compute_phase_d_v2_metrics_bundle(entity_scope, v2_extractor_accum, None)
        dat_telemetry = _build_dat_telemetry(
            0, 0, 0, {}, [], entity_upserts, entity_scope,
            dat_v2_compact_flat=flat_v2,
            dat_parse_diagnostics={},
            dat_file_prefix_counts={},
            dat_reject_file_prefix_counts={},
        )
        summary_ok = _build_summary(rid, ok=True, rows_selected=0, qa_pass_count=0, qa_reject_count=0,
                                    replay_enqueued_count=0, canonical_record_count=0,
                                    reject_counts_by_code={}, entity_upsert_counts=entity_upserts,
                                    constraint_skip_counts=constraint_skip_counts,
                                    artifact_class_filter=artifact_class_filter,
                                    entity_scope=entity_scope,
                                    dat_telemetry=dat_telemetry,
                                    dat_csv_join_telemetry={},
                                    phase_d_v2_domain_metrics=full_v2)
        summary_ok = _apply_zero_selection_enrichment(
            lab_root, summary_ok, n_eligible_before_filter, n_after_filter, artifact_class_filter)
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_ok, summary_json_path)
                _write_summary_txt(summary_ok, summary_txt_path)
                persist_phase_d_state(
                    lab_root,
                    rid,
                    True,
                    None,
                    0,
                    0,
                    0,
                    0,
                    entity_upserts,
                    constraint_skip_counts=constraint_skip_counts,
                    dat_telemetry=dat_telemetry,
                    dat_csv_join_telemetry={},
                    selection_scope=summary_ok.get("selection_scope"),
                    zero_selection_reason_codes=summary_ok.get("zero_selection_reason_codes"),
                    phase_c_summary_run_id_used_for_zero_selection=summary_ok.get(
                        "phase_c_summary_run_id_used_for_zero_selection"),
                    phase_c_summary_path_used_for_zero_selection=summary_ok.get(
                        "phase_c_summary_path_used_for_zero_selection"),
                )
                _sync_phase_d_remediation_safe(lab_root, rid, summary_ok)
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
        except SystemExit:
            return False, rid, None, PHASE_D_LOCK_FAIL
        return True, rid, summary_ok, None

    for row in rows:
        artifact_id, ingest_key, source_system, source_type, source_ref, attachment_sha256, payload_json = row
        payload = {}
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except (ValueError, TypeError):
            pass
        locator = payload.get("locator") or ""
        artifact_class = payload.get("artifact_class") or ""
        telemetry_locator = locator or payload.get("normalized_path") or payload.get("attachment_name") or ""
        dat_file_prefix = _file_prefix_from_locator(telemetry_locator) if artifact_class == "dat" else ""
        if artifact_class == "dat":
            dat_selected_count += 1
            _merge_counter_dict(dat_file_prefix_counts, {dat_file_prefix: 1})

        ok, envelope, parse_code = parse_artifact(locator, artifact_class, payload)
        if not ok:
            reject_code = parse_code or QA_PARSE_ERROR
            if artifact_class == "dat":
                dat_qa_reject_count += 1
                dat_reject_counts_by_reason[reject_code] = dat_reject_counts_by_reason.get(reject_code, 0) + 1
                _merge_counter_dict(dat_reject_file_prefix_counts, {dat_file_prefix: 1})
            parse_diag = get_last_parse_diag()
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            reject_reason = "Parse failed [{0}]".format(
                parse_diag.get("source_exception_class") or "unknown"
            ) if isinstance(parse_diag, dict) else "Parse failed"
            qa_results.append((artifact_id, "reject", reject_code, reject_reason))
            replay_entries.append((artifact_id, reject_code))
            if artifact_class == "dat":
                reject_samples.append(
                    _build_dat_reject_sample(
                        artifact_id,
                        reject_code,
                        reject_reason,
                        None,
                        telemetry_locator,
                        source_ref,
                        attachment_sha256,
                        parse_diag=parse_diag if isinstance(parse_diag, dict) else {},
                    )
                )
            else:
                reject_samples.append({
                    "artifact_id": artifact_id,
                    "reject_code": reject_code,
                    "locator": locator[:80],
                    "locator_full": locator,
                    "parse_diag": parse_diag if isinstance(parse_diag, dict) else {},
                })
            continue
        if artifact_class == "dat":
            _merge_counter_dict(dat_field_presence, _dat_alias_presence_counts_from_envelope(envelope))
            _merge_dat_parse_diagnostics(dat_parse_diagnostics, envelope)

        pass_qa, reject_code, reject_reason = evaluate_qa(artifact_class, envelope)
        if not pass_qa:
            reject_code = reject_code or QA_ARTIFACT_CLASS_REQUIRED_FIELDS
            if artifact_class == "dat":
                dat_qa_reject_count += 1
                dat_reject_counts_by_reason[reject_code] = dat_reject_counts_by_reason.get(reject_code, 0) + 1
                _merge_counter_dict(dat_reject_file_prefix_counts, {dat_file_prefix: 1})
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            reject_key = "{0}|{1}".format(artifact_class or "unknown", reject_code)
            reject_counts_by_artifact_code[reject_key] = reject_counts_by_artifact_code.get(reject_key, 0) + 1
            qa_results.append((artifact_id, "reject", reject_code, reject_reason or ""))
            replay_entries.append((artifact_id, reject_code))
            if artifact_class == "dat":
                reject_samples.append(
                    _build_dat_reject_sample(
                        artifact_id,
                        reject_code,
                        reject_reason or "",
                        envelope,
                        telemetry_locator,
                        source_ref,
                        attachment_sha256,
                    )
                )
            else:
                reject_samples.append({"artifact_id": artifact_id, "reject_code": reject_code, "reason": reject_reason})
            continue

        qa_results.append((artifact_id, "pass", None, None))
        if artifact_class == "dat":
            dat_qa_pass_count += 1
        recs = extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref, attachment_sha256)
        for rec in recs:
            rec["artifact_id"] = artifact_id
            canonical_records.append(rec)
        upserts, v2_ext_part = build_domain_upserts(recs, artifact_id, source_system, entity_scope=entity_scope)
        if v2_extractor_accum is not None:
            merge_extractor_v2_stats(v2_extractor_accum, v2_ext_part)
        for k, v in upserts.items():
            if isinstance(v, list):
                domain_upsert_rows[k].extend(v)
                entity_upserts[k] += len(v)

    qa_pass_count = sum(1 for r in qa_results if r[1] == "pass")
    qa_reject_count = len(qa_results) - qa_pass_count
    replay_enqueued_count = len(replay_entries)

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, PHASE_D_LOCK_FAIL

    actual_entity_counts = dict(entity_upserts)
    actual_constraint_counts = dict(constraint_skip_counts)
    csv_docx_join_telemetry = annotate_csv_docx_join(canonical_records)
    dat_csv_join_telemetry = annotate_dat_csv_alignment(canonical_records, patient_field_mapper_module)
    planning_telemetry = _build_planning_telemetry(
        canonical_records,
        reject_counts_by_code,
        reject_counts_by_artifact_code,
        actual_constraint_counts,
    )
    _, pre_flat_v2 = _compute_phase_d_v2_metrics_bundle(
        entity_scope, v2_extractor_accum, empty_executor_v2_stats()
    )
    dat_telemetry = _build_dat_telemetry(
        dat_selected_count,
        dat_qa_pass_count,
        dat_qa_reject_count,
        dat_reject_counts_by_reason,
        canonical_records,
        actual_entity_counts,
        entity_scope,
        dat_v2_compact_flat=pre_flat_v2,
        dat_field_presence=dat_field_presence,
        dat_parse_diagnostics=dat_parse_diagnostics,
        dat_file_prefix_counts=dat_file_prefix_counts,
        dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
    )
    v2_exec_stats = empty_executor_v2_stats() if entity_scope == "v2" else None
    phase_d_v2_full = {}
    dat_v2_compact_flat = {}
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("BEGIN")
        try:
            _ensure_rule_decision_log_supports_extractor_skip(conn)
            for artifact_id, status, reject_code, reject_reason in qa_results:
                det_key = compute_qa_deterministic_key(artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code)
                conn.execute(
                    "INSERT OR REPLACE INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code, reject_reason, det_key),
                )
            try:
                for artifact_id, reason_code in replay_entries:
                    conn.execute(
                        "INSERT OR REPLACE INTO replay_queue (artifact_id, reason_code, status, attempt_count) "
                        "VALUES (?, ?, 'pending', 0)",
                        (artifact_id, reason_code),
                    )
            except Exception as replay_err:
                raise RuntimeError((PHASE_D_REPLAY_QUEUE_ERROR, str(replay_err)))
            for rec in canonical_records:
                conn.execute(
                    "INSERT OR IGNORE INTO extracted_canonical_record "
                    "(artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (rec["artifact_id"], rec["canonical_type"], rec["canonical_key"], CANONICALIZATION_VERSION,
                     rec["canonical_json"], rec["provenance_json"]),
                )
            _log_extractor_skip_events(conn, (v2_extractor_accum or {}).get("skip_events"))
            actual_entity_counts, actual_constraint_counts = _execute_domain_upserts(
                conn, domain_upsert_rows, entity_scope, v2_exec_stats=v2_exec_stats
            )
            planning_telemetry = _build_planning_telemetry(
                canonical_records,
                reject_counts_by_code,
                reject_counts_by_artifact_code,
                actual_constraint_counts,
            )
            phase_d_v2_full, dat_v2_compact_flat = _compute_phase_d_v2_metrics_bundle(
                entity_scope, v2_extractor_accum, v2_exec_stats
            )
            dat_telemetry = _build_dat_telemetry(
                dat_selected_count,
                dat_qa_pass_count,
                dat_qa_reject_count,
                dat_reject_counts_by_reason,
                canonical_records,
                actual_entity_counts,
                entity_scope,
                dat_v2_compact_flat=dat_v2_compact_flat,
                dat_field_presence=dat_field_presence,
                dat_parse_diagnostics=dat_parse_diagnostics,
                dat_file_prefix_counts=dat_file_prefix_counts,
                dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
            )
            _log_planning_telemetry(conn, planning_telemetry)
            csv_docx_join_negotiation_id = _log_join_negotiation(
                conn, EVENT_CSV_DOCX_JOIN_NEGOTIATION, csv_docx_join_telemetry, rid
            )
            dat_csv_join_negotiation_id = _log_join_negotiation(
                conn, EVENT_DAT_CSV_JOIN_NEGOTIATION, dat_csv_join_telemetry, rid
            )
            conn.commit()
            if csv_docx_join_negotiation_id is not None:
                csv_docx_join_telemetry = dict(csv_docx_join_telemetry)
                csv_docx_join_telemetry["negotiation_run_id"] = rid
                csv_docx_join_telemetry["negotiation_telemetry_id"] = csv_docx_join_negotiation_id
                csv_docx_join_telemetry[KEY_NEGOTIATION_LOG_REF] = format_negotiation_log_ref(
                    csv_docx_join_negotiation_id,
                    rid,
                    EVENT_CSV_DOCX_JOIN_NEGOTIATION,
                )
            if dat_csv_join_negotiation_id is not None:
                dat_csv_join_telemetry = dict(dat_csv_join_telemetry)
                dat_csv_join_telemetry["negotiation_run_id"] = rid
                dat_csv_join_telemetry["negotiation_telemetry_id"] = dat_csv_join_negotiation_id
                dat_csv_join_telemetry[KEY_NEGOTIATION_LOG_REF] = format_negotiation_log_ref(
                    dat_csv_join_negotiation_id,
                    rid,
                    EVENT_DAT_CSV_JOIN_NEGOTIATION,
                )
        except Exception as e:
            conn.rollback()
            actual_entity_counts = {k: 0 for k in actual_entity_counts}
            actual_constraint_counts = {"patient_invalid_external_id": 0}
            planning_telemetry = _build_planning_telemetry(
                canonical_records,
                reject_counts_by_code,
                reject_counts_by_artifact_code,
                actual_constraint_counts,
            )
            phase_d_v2_fail, flat_fail = _compute_phase_d_v2_metrics_bundle(
                entity_scope, v2_extractor_accum, empty_executor_v2_stats()
            )
            dat_telemetry = _build_dat_telemetry(
                dat_selected_count,
                dat_qa_pass_count,
                dat_qa_reject_count,
                dat_reject_counts_by_reason,
                canonical_records,
                actual_entity_counts,
                entity_scope,
                dat_v2_compact_flat=flat_fail,
                dat_field_presence=dat_field_presence,
                dat_parse_diagnostics=dat_parse_diagnostics,
                dat_file_prefix_counts=dat_file_prefix_counts,
                dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
            )
            error_code = PHASE_D_DB_WRITE_ERROR
            error_detail = str(e)[:200]
            if isinstance(e, RuntimeError) and e.args and e.args[0][0] == PHASE_D_REPLAY_QUEUE_ERROR:
                error_code = PHASE_D_REPLAY_QUEUE_ERROR
                error_detail = str(e.args[0][1])[:200] if len(e.args[0]) > 1 else str(e)[:200]
            summary_fail = _build_summary(rid, ok=False, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                          qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                          replay_enqueued_count=replay_enqueued_count,
                                          canonical_record_count=len(canonical_records),
                                          entity_upsert_counts=actual_entity_counts, error_code=error_code,
                                          error_detail=error_detail, source_exception_class=e.__class__.__name__,
                                          constraint_skip_counts=actual_constraint_counts,
                                          planning_telemetry=planning_telemetry,
                                          artifact_class_filter=artifact_class_filter,
                                          entity_scope=entity_scope,
                                          dat_telemetry=dat_telemetry,
                                          csv_docx_join_telemetry=csv_docx_join_telemetry,
                                          dat_csv_join_telemetry=dat_csv_join_telemetry,
                                          phase_d_v2_domain_metrics=phase_d_v2_fail)
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            try:
                persist_phase_d_state(lab_root, rid, False, error_code, qa_pass_count, qa_reject_count,
                                      replay_enqueued_count, len(canonical_records), actual_entity_counts,
                                      constraint_skip_counts=actual_constraint_counts,
                                      dat_telemetry=dat_telemetry,
                                      csv_docx_join_telemetry=csv_docx_join_telemetry,
                                      dat_csv_join_telemetry=dat_csv_join_telemetry,
                                      selection_scope=summary_fail.get("selection_scope"),
                                      zero_selection_reason_codes=summary_fail.get("zero_selection_reason_codes"),
                                      phase_c_summary_run_id_used_for_zero_selection=summary_fail.get(
                                          "phase_c_summary_run_id_used_for_zero_selection"),
                                      phase_c_summary_path_used_for_zero_selection=summary_fail.get(
                                          "phase_c_summary_path_used_for_zero_selection"))
                _sync_phase_d_remediation_safe(lab_root, rid, summary_fail)
            except Exception:
                pass
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": error_code, "run_id": rid,
                                                         "first_failed": error_detail[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary_fail})
            except Exception:
                pass
            return False, rid, summary_fail, error_code
        finally:
            conn.close()

        summary = _build_summary(rid, ok=True, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                replay_enqueued_count=replay_enqueued_count,
                                canonical_record_count=len(canonical_records),
                                entity_upsert_counts=actual_entity_counts,
                                constraint_skip_counts=actual_constraint_counts,
                                planning_telemetry=planning_telemetry,
                                artifact_class_filter=artifact_class_filter,
                                entity_scope=entity_scope,
                                dat_telemetry=dat_telemetry,
                                csv_docx_join_telemetry=csv_docx_join_telemetry,
                                dat_csv_join_telemetry=dat_csv_join_telemetry,
                                phase_d_v2_domain_metrics=phase_d_v2_full)
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        _write_summary_json(summary, summary_json_path)
        _write_summary_txt(summary, summary_txt_path)
        with open(reject_samples_path, "w", encoding="utf-8") as f:
            for s in reject_samples[:50]:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
        try:
            persist_phase_d_state(lab_root, rid, True, None, qa_pass_count, qa_reject_count,
                                  replay_enqueued_count, len(canonical_records), actual_entity_counts,
                                  constraint_skip_counts=actual_constraint_counts,
                                  dat_telemetry=dat_telemetry,
                                  csv_docx_join_telemetry=csv_docx_join_telemetry,
                                  dat_csv_join_telemetry=dat_csv_join_telemetry,
                                  selection_scope=summary.get("selection_scope"),
                                  zero_selection_reason_codes=summary.get("zero_selection_reason_codes"),
                                  phase_c_summary_run_id_used_for_zero_selection=summary.get(
                                      "phase_c_summary_run_id_used_for_zero_selection"),
                                  phase_c_summary_path_used_for_zero_selection=summary.get(
                                      "phase_c_summary_path_used_for_zero_selection"))
            _sync_phase_d_remediation_safe(lab_root, rid, summary)
        except Exception as persist_err:
            summary["ok"] = False
            summary["error_code"] = PHASE_D_STATE_WRITE_ERROR
            summary["error_detail"] = str(persist_err)[:200]
            summary["source_exception_class"] = persist_err.__class__.__name__
            summary["recoverability"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            ).get("recoverability", "")
            summary["failure_contract"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            )
            _write_summary_json(summary, summary_json_path)
            _write_summary_txt(summary, summary_txt_path)
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": PHASE_D_STATE_WRITE_ERROR, "run_id": rid,
                                                         "first_failed": str(persist_err)[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary})
            except Exception:
                pass
            return False, rid, summary, PHASE_D_STATE_WRITE_ERROR
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    return True, rid, summary, None


def _build_summary(rid, ok, rows_selected, qa_pass_count=0, qa_reject_count=0, reject_counts_by_code=None,
                    replay_enqueued_count=0, canonical_record_count=0, entity_upsert_counts=None,
                    error_code=None, error_detail="", source_exception_class="", recoverability="",
                    constraint_skip_counts=None, artifact_class_filter=None, planning_telemetry=None,
                    entity_scope="v1", dat_telemetry=None, csv_docx_join_telemetry=None,
                    dat_csv_join_telemetry=None, phase_d_v2_domain_metrics=None,
                    selection_scope=None,
                    zero_selection_reason_codes=None,
                    phase_c_summary_run_id_used_for_zero_selection=None,
                    phase_c_summary_path_used_for_zero_selection=None,
                    phase_c_context_mismatch_warning=None,
                    historical_reject_counts_by_class=None,
                    historical_reject_counts_by_version=None,
                    historical_reprocess_candidate=None,
                    historical_reprocess_targeted_artifact_classes=None,
                    zero_selection_analysis_available=True):
    failure = build_failure_context("D", error_code, error_detail, source_exception_class) if error_code else {}
    recoverability_value = recoverability or (failure.get("recoverability", "") if failure else "")
    if selection_scope is None:
        selection_scope = PHASE_D_SELECTION_SCOPE
    if zero_selection_reason_codes is None:
        zero_selection_reason_codes = []
    if phase_c_summary_run_id_used_for_zero_selection is None:
        phase_c_summary_run_id_used_for_zero_selection = ""
    if phase_c_summary_path_used_for_zero_selection is None:
        phase_c_summary_path_used_for_zero_selection = ""
    if phase_c_context_mismatch_warning is None:
        phase_c_context_mismatch_warning = ""
    if historical_reject_counts_by_class is None:
        historical_reject_counts_by_class = {}
    if historical_reject_counts_by_version is None:
        historical_reject_counts_by_version = {}
    if historical_reprocess_candidate is None:
        historical_reprocess_candidate = False
    if historical_reprocess_targeted_artifact_classes is None:
        historical_reprocess_targeted_artifact_classes = []
    return {
        "phase": "D",
        "ok": ok,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "qa_policy_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "selection_scope": selection_scope,
        "rows_selected": rows_selected,
        "qa_pass_count": qa_pass_count,
        "qa_reject_count": qa_reject_count,
        "reject_counts_by_code": reject_counts_by_code or {},
        "replay_enqueued_count": replay_enqueued_count,
        "canonical_record_count": canonical_record_count,
        "entity_upsert_counts": entity_upsert_counts or {},
        "constraint_skip_counts": constraint_skip_counts or {},
        "planning_telemetry": planning_telemetry or {},
        "dat_telemetry": dat_telemetry or {},
        "csv_docx_join_telemetry": csv_docx_join_telemetry or {},
        "dat_csv_join_telemetry": dat_csv_join_telemetry or {},
        "artifact_class_filter": list(artifact_class_filter or []),
        "phase_d_entity_scope": str(entity_scope or "v1"),
        "zero_selection_reason_codes": list(zero_selection_reason_codes),
        "phase_c_summary_run_id_used_for_zero_selection": str(phase_c_summary_run_id_used_for_zero_selection or ""),
        "phase_c_summary_path_used_for_zero_selection": str(phase_c_summary_path_used_for_zero_selection or ""),
        "phase_c_context_mismatch_warning": str(phase_c_context_mismatch_warning or ""),
        "historical_reject_counts_by_class": dict(historical_reject_counts_by_class),
        "historical_reject_counts_by_version": dict(historical_reject_counts_by_version),
        "historical_reprocess_candidate": bool(historical_reprocess_candidate),
        "historical_reprocess_targeted_artifact_classes": list(historical_reprocess_targeted_artifact_classes),
        "zero_selection_analysis_available": bool(zero_selection_analysis_available),
        "error_code": error_code,
        "error_detail": error_detail or "",
        "recoverability": recoverability_value,
        "source_exception_class": source_exception_class or "",
        "failure_contract": failure,
        "phase_d_v2_domain_metrics": phase_d_v2_domain_metrics if isinstance(phase_d_v2_domain_metrics, dict) else {},
    }


def _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir):
    try:
        acquire_lock(lab_root)
        try:
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            persist_phase_d_state(
                lab_root, rid, False, summary_fail.get("error_code"), 0, 0, 0, 0, {},
                dat_telemetry=summary_fail.get("dat_telemetry") or {},
                csv_docx_join_telemetry=summary_fail.get("csv_docx_join_telemetry") or {},
                dat_csv_join_telemetry=summary_fail.get("dat_csv_join_telemetry") or {},
                selection_scope=summary_fail.get("selection_scope"),
                zero_selection_reason_codes=summary_fail.get("zero_selection_reason_codes"),
                phase_c_summary_run_id_used_for_zero_selection=summary_fail.get(
                    "phase_c_summary_run_id_used_for_zero_selection"),
                phase_c_summary_path_used_for_zero_selection=summary_fail.get(
                    "phase_c_summary_path_used_for_zero_selection"),
            )
            _sync_phase_d_remediation_safe(lab_root, rid, summary_fail)
        finally:
            release_lock(lab_root, owner_pid=os.getpid())
        try:
            from phase_d_auto_report import submit_phase_d_failure_report
            submit_phase_d_failure_report(lab_root, {"error_code": summary_fail.get("error_code"),
                                                     "run_id": rid, "first_failed": "prelock",
                                                     "lab_root": lab_root, "report_json_path": summary_json_path,
                                                     "report_txt_path": summary_txt_path, "summary": summary_fail})
        except Exception:
            pass
    except SystemExit:
        pass


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    dat_telemetry = summary.get("dat_telemetry") or {}
    csv_docx_join = summary.get("csv_docx_join_telemetry") or {}
    dat_csv_join = summary.get("dat_csv_join_telemetry") or {}
    lines = [
        "Phase D QA and Canonicalization Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "selection_scope: {0}".format(summary.get("selection_scope", PHASE_D_SELECTION_SCOPE)),
        "rows_selected: {0}".format(summary.get("rows_selected", 0)),
        "zero_selection_analysis_available: {0}".format(summary.get("zero_selection_analysis_available", True)),
        "zero_selection_reason_codes: {0}".format(json.dumps(summary.get("zero_selection_reason_codes") or [], ensure_ascii=False)),
        "phase_c_summary_run_id_used_for_zero_selection: {0}".format(summary.get("phase_c_summary_run_id_used_for_zero_selection", "")),
        "phase_c_summary_path_used_for_zero_selection: {0}".format(summary.get("phase_c_summary_path_used_for_zero_selection", "")),
        "phase_c_context_mismatch_warning: {0}".format(summary.get("phase_c_context_mismatch_warning", "")),
        "phase_c_summary_resolution_source: {0}".format(summary.get("phase_c_summary_resolution_source", "")),
        "phase_c_expected_run_id_for_zero_selection: {0}".format(summary.get("phase_c_expected_run_id_for_zero_selection", "")),
        "phase_c_lineage_coherent: {0}".format(summary.get("phase_c_lineage_coherent", True)),
        "historical_reject_counts_by_class: {0}".format(json.dumps(summary.get("historical_reject_counts_by_class") or {}, sort_keys=True)),
        "historical_reject_counts_by_version: {0}".format(json.dumps(summary.get("historical_reject_counts_by_version") or {}, sort_keys=True)),
        "historical_reprocess_candidate: {0}".format(summary.get("historical_reprocess_candidate", False)),
        "historical_reprocess_targeted_artifact_classes: {0}".format(",".join(summary.get("historical_reprocess_targeted_artifact_classes") or [])),
        "qa_pass_count: {0}".format(summary.get("qa_pass_count", 0)),
        "qa_reject_count: {0}".format(summary.get("qa_reject_count", 0)),
        "replay_enqueued_count: {0}".format(summary.get("replay_enqueued_count", 0)),
        "canonical_record_count: {0}".format(summary.get("canonical_record_count", 0)),
        "patient_invalid_external_id_skipped: {0}".format(
            (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id", 0)
        ),
        "workstream_b_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_b") or {}).get("activation_recommended", False)
        ),
        "workstream_c_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_c") or {}).get("activation_recommended", False)
        ),
        "workstream_d_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_d") or {}).get("activation_recommended", False)
        ),
        "dat_selected_count: {0}".format(dat_telemetry.get("dat_selected_count", 0)),
        "dat_qa_pass_count: {0}".format(dat_telemetry.get("dat_qa_pass_count", 0)),
        "dat_qa_reject_count: {0}".format(dat_telemetry.get("dat_qa_reject_count", 0)),
        "dat_canonical_record_count: {0}".format(dat_telemetry.get("dat_canonical_record_count", 0)),
        "dat_parse_failure_count: {0}".format(((dat_telemetry.get("dat_parse_diagnostics") or {}).get("tuple_parse_failure_count", 0))),
        "dat_file_prefix_mix: {0}".format(json.dumps(dat_telemetry.get("dat_file_prefix_counts") or {}, sort_keys=True)),
        "post_medisoft_exercised: {0}".format(dat_telemetry.get("post_medisoft_exercised", False)),
        "post_medisoft_blocked_stage: {0}".format(dat_telemetry.get("post_medisoft_blocked_stage", "")),
        "csv_docx_join_key: {0}".format(csv_docx_join.get("join_key", "")),
        "csv_docx_join_csv_candidate_count: {0}".format(csv_docx_join.get("csv_candidate_count", 0)),
        "csv_docx_join_csv_join_key_count: {0}".format(csv_docx_join.get("csv_join_key_count", 0)),
        "csv_docx_join_docx_candidate_count: {0}".format(csv_docx_join.get("docx_candidate_count", 0)),
        "csv_docx_join_docx_join_key_count: {0}".format(csv_docx_join.get("docx_join_key_count", 0)),
        "csv_docx_join_matched_count: {0}".format(csv_docx_join.get("matched_count", 0)),
        "csv_docx_join_csv_only_count: {0}".format(csv_docx_join.get("csv_only_count", 0)),
        "csv_docx_join_docx_only_count: {0}".format(csv_docx_join.get("docx_only_count", 0)),
        "csv_docx_join_ambiguous_count: {0}".format(csv_docx_join.get("ambiguous_count", 0)),
        "dat_csv_join_matched_count: {0}".format(dat_csv_join.get("matched_count", 0)),
        "dat_csv_join_csv_only_count: {0}".format(dat_csv_join.get("csv_only_count", 0)),
        "dat_csv_join_dat_only_count: {0}".format(dat_csv_join.get("dat_only_count", 0)),
        "dat_csv_join_ambiguous_multi_dat_count: {0}".format(dat_csv_join.get("ambiguous_multi_dat_count", 0)),
        "dat_csv_join_payer_mismatch_count: {0}".format(dat_csv_join.get("payer_mismatch_count", 0)),
        "dat_csv_join_dos_mismatch_count: {0}".format(dat_csv_join.get("dos_mismatch_count", 0)),
        "dat_csv_join_invalid_external_id_csv_count: {0}".format(dat_csv_join.get("invalid_external_id_csv_count", 0)),
        "artifact_class_filter: {0}".format(",".join(summary.get("artifact_class_filter") or [])),
        "phase_d_entity_scope: {0}".format(summary.get("phase_d_entity_scope", "v1")),
        "error_code: {0}".format(summary.get("error_code", "")),
        "recoverability: {0}".format(summary.get("recoverability", "")),
        "source_exception_class: {0}".format(summary.get("source_exception_class", "")),
    ]
    extend_summary_txt_lines(lines, csv_docx_join, dat_csv_join)
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_d_state(lab_root, rid, ok, error_code, pass_count, reject_count, replay_pending, canonical_count,
                         entity_upserts, constraint_skip_counts=None, dat_telemetry=None,
                         csv_docx_join_telemetry=None, dat_csv_join_telemetry=None,
                         selection_scope=None, zero_selection_reason_codes=None,
                         phase_c_summary_run_id_used_for_zero_selection=None,
                         phase_c_summary_path_used_for_zero_selection=None):
    """Update run_cursor.json and diagnostics_state.json with Phase D outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    dat_telemetry = dat_telemetry or {}
    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_d_run_id"] = rid
    cursor["last_phase_d_ok"] = ok
    cursor["last_qa_policy_version"] = QA_POLICY_VERSION
    cursor["last_canonicalization_version"] = CANONICALIZATION_VERSION
    cursor["last_phase_d_pass_count"] = pass_count
    cursor["last_phase_d_reject_count"] = reject_count
    cursor["last_phase_d_replay_pending"] = replay_pending
    cursor["last_phase_d_constraint_skip_counts"] = constraint_skip_counts or {}
    cursor["last_phase_d_dat_telemetry"] = dat_telemetry
    cursor["last_phase_d_csv_docx_join_telemetry"] = csv_docx_join_telemetry
    cursor["last_phase_d_dat_csv_join_telemetry"] = dat_csv_join_telemetry
    cursor["last_phase_d_error_code"] = error_code
    cursor["last_phase_d_at_utc"] = now
    if selection_scope is not None:
        cursor["last_phase_d_selection_scope"] = selection_scope
    if zero_selection_reason_codes is not None:
        cursor["last_phase_d_zero_selection_reason_codes"] = list(zero_selection_reason_codes)
    if phase_c_summary_run_id_used_for_zero_selection is not None:
        cursor["last_phase_d_phase_c_summary_run_id_used_for_zero_selection"] = str(
            phase_c_summary_run_id_used_for_zero_selection or "")
    if phase_c_summary_path_used_for_zero_selection is not None:
        cursor["last_phase_d_phase_c_summary_path_used_for_zero_selection"] = str(
            phase_c_summary_path_used_for_zero_selection or "")
    refresh_run_cursor_updated_at(cursor)
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_d_run_id"] = rid
    state["last_phase_d_ok"] = ok
    state["last_qa_policy_version"] = QA_POLICY_VERSION
    state["last_canonicalization_version"] = CANONICALIZATION_VERSION
    state["last_phase_d_pass_count"] = pass_count
    state["last_phase_d_reject_count"] = reject_count
    state["last_phase_d_replay_pending"] = replay_pending
    state["last_phase_d_constraint_skip_counts"] = constraint_skip_counts or {}
    state["last_phase_d_dat_telemetry"] = dat_telemetry
    state["last_phase_d_csv_docx_join_telemetry"] = csv_docx_join_telemetry
    state["last_phase_d_dat_csv_join_telemetry"] = dat_csv_join_telemetry
    state["last_phase_d_error_code"] = error_code
    state["last_phase_d_at_utc"] = now
    if selection_scope is not None:
        state["last_phase_d_selection_scope"] = selection_scope
    if zero_selection_reason_codes is not None:
        state["last_phase_d_zero_selection_reason_codes"] = list(zero_selection_reason_codes)
    if phase_c_summary_run_id_used_for_zero_selection is not None:
        state["last_phase_d_phase_c_summary_run_id_used_for_zero_selection"] = str(
            phase_c_summary_run_id_used_for_zero_selection or "")
    if phase_c_summary_path_used_for_zero_selection is not None:
        state["last_phase_d_phase_c_summary_path_used_for_zero_selection"] = str(
            phase_c_summary_path_used_for_zero_selection or "")
    replace_safe_write(state_path, state)


def main():
    parser = argparse.ArgumentParser(description="Phase D QA and canonicalization")
    parser.add_argument("--lab-dir", help="Override lab root")
    parser.add_argument(
        "--artifact-classes",
        dest="artifact_classes",
        default=None,
        help="Comma-separated artifact classes to include (default: all eligible classes)",
    )
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    env_filter = os.environ.get("MEDICAFE_PHASE_D_ARTIFACT_CLASSES", "")
    raw_filter = args.artifact_classes if args.artifact_classes is not None else env_filter
    artifact_filter = _normalize_artifact_class_filter(raw_filter)
    ok, rid, summary, error_code = run_qa_canonical(lab_root, artifact_classes=artifact_filter)
    if not ok:
        print("Phase D failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase D ok: {0} pass, {1} reject, {2} canonical".format(
        summary.get("qa_pass_count", 0), summary.get("qa_reject_count", 0),
        summary.get("canonical_record_count", 0)))


if __name__ == "__main__":
    main()

