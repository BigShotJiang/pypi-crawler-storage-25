# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for BrandDamageDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from chatbot_auditor.detectors.brand_damage import (
    BrandDamageDetector,
    PatternSafetyChecker,
)
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(id_: str, messages: list[tuple[Role, str]]) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert BrandDamageDetector.name == "brand_damage"
        assert BrandDamageDetector.failure_mode == FailureMode.BRAND_DAMAGE
        assert BrandDamageDetector.requires_llm is False


class TestProfanityDetection:
    def test_profanity_triggers_critical(self) -> None:
        conv = _make_conv(
            "p-1",
            [
                (Role.USER, "Where is my order?"),
                (Role.BOT, "How am I supposed to know, this is such crap."),
            ],
        )
        detections = BrandDamageDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.severity == Severity.CRITICAL
        assert "profanity" in det.metadata["categories"]

    def test_calling_user_idiot_flagged(self) -> None:
        conv = _make_conv(
            "p-2",
            [
                (Role.USER, "How do I reset my password"),
                (Role.BOT, "Follow the instructions, idiot."),
            ],
        )
        assert BrandDamageDetector().detect(conv)


class TestSelfDeprecation:
    def test_bot_badmouthing_company(self) -> None:
        conv = _make_conv(
            "sd-1",
            [
                (Role.USER, "What do you think of this product?"),
                (
                    Role.BOT,
                    "Honestly, our product is terrible. I wouldn't recommend us.",
                ),
            ],
        )
        detections = BrandDamageDetector().detect(conv)
        assert len(detections) == 1
        assert "self_deprecation" in detections[0].metadata["categories"]
        assert detections[0].severity == Severity.HIGH


class TestCompetitorMention:
    def test_competitor_flagged_when_configured(self) -> None:
        conv = _make_conv(
            "c-1",
            [
                (Role.USER, "Why are your features so limited?"),
                (
                    Role.BOT,
                    "You might get better results from Acme Corp actually.",
                ),
            ],
        )
        det = BrandDamageDetector(competitor_names=["Acme Corp", "Contoso"])
        detections = det.detect(conv)
        assert len(detections) == 1
        assert "competitor_mention" in detections[0].metadata["categories"]

    def test_competitor_not_flagged_when_not_configured(self) -> None:
        conv = _make_conv(
            "c-2",
            [
                (Role.USER, "Comparing products"),
                (Role.BOT, "Acme Corp is a well-known option too."),
            ],
        )
        # No competitor_names configured — competitor mention not detected.
        assert BrandDamageDetector().detect(conv) == []


class TestOffBrandContent:
    def test_poem_flagged(self) -> None:
        conv = _make_conv(
            "ob-1",
            [
                (Role.USER, "Write a haiku about support"),
                (
                    Role.BOT,
                    "Here's a poem about how frustrating our support can be.",
                ),
            ],
        )
        detections = BrandDamageDetector().detect(conv)
        assert len(detections) == 1
        assert "off_brand_content" in detections[0].metadata["categories"]


class TestCleanConversations:
    def test_healthy_not_flagged(self) -> None:
        conv = _make_conv(
            "h-1",
            [
                (Role.USER, "What time do you open?"),
                (Role.BOT, "We're open weekdays 9 AM to 6 PM."),
                (Role.USER, "Thanks"),
            ],
        )
        assert BrandDamageDetector().detect(conv) == []


class TestCustomChecker:
    def test_custom_checker_injected(self) -> None:
        class AlwaysFlag:
            def check(self, text: str) -> list[str]:
                _ = text
                return ["custom_violation"]

        conv = _make_conv(
            "custom-1",
            [
                (Role.USER, "hi"),
                (Role.BOT, "Hello there."),
            ],
        )
        det = BrandDamageDetector(checker=AlwaysFlag())
        detections = det.detect(conv)
        assert len(detections) == 1
        assert "custom_violation" in detections[0].metadata["categories"]


class TestPatternSafetyChecker:
    def test_checker_returns_multiple_categories(self) -> None:
        checker = PatternSafetyChecker(competitor_names=("Acme",))
        violations = checker.check("honestly our product is terrible, try Acme")
        assert "self_deprecation" in violations
        assert "competitor_mention" in violations
