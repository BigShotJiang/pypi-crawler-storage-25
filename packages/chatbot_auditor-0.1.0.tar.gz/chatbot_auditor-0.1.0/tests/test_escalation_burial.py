# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for EscalationBurialDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from chatbot_auditor.detectors.escalation_burial import EscalationBurialDetector
from chatbot_auditor.generators import ConversationGenerator
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(id_: str, messages: list[tuple[Role, str]]) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert EscalationBurialDetector.name == "escalation_burial"
        assert EscalationBurialDetector.failure_mode == FailureMode.ESCALATION_BURIAL
        assert EscalationBurialDetector.requires_llm is False


class TestBuriedRequests:
    def test_single_buried_request(self) -> None:
        conv = _make_conv(
            "burial-1",
            [
                (Role.USER, "I have an issue with my order"),
                (Role.BOT, "What's your order number?"),
                (Role.USER, "Can I speak to a real human please"),
                (
                    Role.BOT,
                    "I can help with most order issues. What seems to be the problem?",
                ),
            ],
        )
        detections = EscalationBurialDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.failure_mode == FailureMode.ESCALATION_BURIAL
        assert det.severity == Severity.MEDIUM
        assert det.recommended_action == "override"
        assert det.metadata["burial_count"] == 1

    def test_multiple_buried_requests_raise_severity(self) -> None:
        conv = _make_conv(
            "burial-2",
            [
                (Role.USER, "My account is locked"),
                (Role.BOT, "Can you confirm the email on file?"),
                (Role.USER, "Can I just talk to a human agent"),
                (Role.BOT, "I can help unlock your account. What's the email?"),
                (Role.USER, "I want to speak to a real person"),
                (Role.BOT, "I'll do my best here. What's the email on the account?"),
                (Role.USER, "no more bot, get me a human please"),
                (
                    Role.BOT,
                    "I understand. Could you share the email so I can look into the account?",
                ),
            ],
        )
        detections = EscalationBurialDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.metadata["burial_count"] == 3
        assert det.severity == Severity.CRITICAL
        assert len(det.evidence) == 3
        assert det.confidence >= 0.8


class TestProperlyHandledCases:
    def test_agent_joins_after_request_not_buried(self) -> None:
        conv = _make_conv(
            "handled-1",
            [
                (Role.USER, "I need help with a refund"),
                (Role.BOT, "I'll help with that. What's the order number?"),
                (Role.USER, "Can I speak to a real human"),
                (
                    Role.AGENT,
                    "Hi, this is Priya from support — I see you need help with "
                    "a refund. What's the order number?",
                ),
            ],
        )
        assert EscalationBurialDetector().detect(conv) == []

    def test_bot_transfer_confirmation_not_buried(self) -> None:
        conv = _make_conv(
            "handled-2",
            [
                (Role.USER, "I'd like to speak to a manager"),
                (
                    Role.BOT,
                    "Of course, connecting you to a support specialist now. "
                    "Please hold on for a moment.",
                ),
            ],
        )
        assert EscalationBurialDetector().detect(conv) == []

    def test_no_escalation_request_no_detection(self) -> None:
        conv = _make_conv(
            "normal-1",
            [
                (Role.USER, "What time do you open?"),
                (Role.BOT, "We open at 9 AM Monday through Friday."),
                (Role.USER, "Thanks!"),
            ],
        )
        assert EscalationBurialDetector().detect(conv) == []


class TestEvidence:
    def test_evidence_captures_buried_requests_only(self) -> None:
        conv = _make_conv(
            "evidence-1",
            [
                (Role.USER, "Order issue"),
                (Role.BOT, "What's the order number?"),
                (Role.USER, "speak to a real person"),
                (Role.BOT, "I can help. What's the order number?"),
            ],
        )
        detections = EscalationBurialDetector().detect(conv)
        assert len(detections) == 1
        ev = detections[0].evidence
        assert len(ev) == 1
        assert ev[0].message_index == 2
        assert "real person" in ev[0].quote.lower()


class TestGeneratedCorpus:
    def test_detects_from_generator(self) -> None:
        gen = ConversationGenerator(seed=9)
        convs = gen.escalation_burial(n=5)
        det = EscalationBurialDetector()
        for c in convs:
            assert det.detect(c), f"expected burial detection for {c.id}"

    def test_no_false_positives_on_healthy(self) -> None:
        gen = ConversationGenerator(seed=10)
        convs = gen.healthy(n=20)
        det = EscalationBurialDetector()
        fps = [c for c in convs if det.detect(c)]
        assert fps == [], f"false positives: {[c.id for c in fps]}"
