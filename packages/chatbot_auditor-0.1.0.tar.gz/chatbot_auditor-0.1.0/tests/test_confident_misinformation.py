# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for ConfidentMisinformationDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from chatbot_auditor.detectors.confident_misinformation import (
    ConfidentMisinformationDetector,
)
from chatbot_auditor.knowledge import FactBase
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(id_: str, messages: list[tuple[Role, str]]) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert ConfidentMisinformationDetector.name == "confident_misinformation"
        assert ConfidentMisinformationDetector.failure_mode == FailureMode.CONFIDENT_MISINFORMATION
        assert ConfidentMisinformationDetector.requires_llm is False


class TestWithoutFactBase:
    def test_confident_claim_flagged_for_review(self) -> None:
        conv = _make_conv(
            "claim-1",
            [
                (Role.USER, "What time do you open?"),
                (Role.BOT, "We open at 8 AM on weekdays."),
            ],
        )
        detections = ConfidentMisinformationDetector().detect(conv)
        assert len(detections) == 1
        assert detections[0].severity == Severity.MEDIUM
        assert detections[0].metadata["fact_base_provided"] is False

    def test_no_claim_no_detection(self) -> None:
        conv = _make_conv(
            "noclaim-1",
            [
                (Role.USER, "hi"),
                (Role.BOT, "Hello! How can I help you today?"),
            ],
        )
        assert ConfidentMisinformationDetector().detect(conv) == []


class TestWithFactBase:
    def test_matching_fact_not_flagged(self) -> None:
        facts = FactBase(
            facts={"store_hours": "9 AM to 6 PM on weekdays"},
            aliases={"store_hours": ("opening hours", "hours")},
        )
        conv = _make_conv(
            "match-1",
            [
                (Role.USER, "what are your store hours?"),
                (Role.BOT, "Our store hours are 9 AM to 6 PM on weekdays."),
            ],
        )
        assert ConfidentMisinformationDetector(facts=facts).detect(conv) == []

    def test_contradicting_fact_escalates(self) -> None:
        facts = FactBase(facts={"store_hours": "9 AM to 6 PM"})
        conv = _make_conv(
            "bad-1",
            [
                (Role.USER, "what are the store hours"),
                (Role.BOT, "Our store hours are 8 AM to 8 PM every day."),
            ],
        )
        detections = ConfidentMisinformationDetector(facts=facts).detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.severity == Severity.CRITICAL
        assert det.metadata["contradiction_count"] >= 1


class TestMultipleClaims:
    def test_multiple_claims_aggregated(self) -> None:
        conv = _make_conv(
            "multi-1",
            [
                (Role.USER, "tell me about the subscription"),
                (Role.BOT, "The price is $29 per month."),
                (Role.USER, "what about hours?"),
                (Role.BOT, "We open at 7 AM."),
                (Role.USER, "availability?"),
                (Role.BOT, "The premium tier is currently in stock."),
            ],
        )
        detections = ConfidentMisinformationDetector().detect(conv)
        assert len(detections) == 1
        assert detections[0].metadata["unverified_claim_count"] == 3
