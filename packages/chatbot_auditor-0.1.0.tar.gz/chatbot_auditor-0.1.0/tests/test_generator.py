# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the synthetic conversation generator."""

from __future__ import annotations

import pytest

from chatbot_auditor.generators import ConversationGenerator
from chatbot_auditor.schema import Role


class TestHealthy:
    def test_returns_requested_count(self) -> None:
        gen = ConversationGenerator(seed=1)
        convs = gen.healthy(n=10)
        assert len(convs) == 10

    def test_marked_as_healthy(self) -> None:
        gen = ConversationGenerator(seed=1)
        for c in gen.healthy(n=5):
            assert c.metadata["synthetic_label"] == "healthy"

    def test_has_user_and_bot_messages(self) -> None:
        gen = ConversationGenerator(seed=1)
        for c in gen.healthy(n=5):
            assert any(m.role == Role.USER for m in c.messages)
            assert any(m.role == Role.BOT for m in c.messages)

    def test_ids_are_unique(self) -> None:
        gen = ConversationGenerator(seed=1)
        convs = gen.healthy(n=20)
        ids = {c.id for c in convs}
        assert len(ids) == 20


class TestDeathLoop:
    def test_generates_requested_repeats(self) -> None:
        gen = ConversationGenerator(seed=2)
        for c in gen.death_loop(n=3, repeats=4):
            bot_msgs = [m for m in c.messages if m.role == Role.BOT]
            assert len(bot_msgs) == 4

    def test_rejects_invalid_repeats(self) -> None:
        with pytest.raises(ValueError, match="repeats"):
            ConversationGenerator(seed=3).death_loop(n=1, repeats=1)

    def test_metadata_labels_are_present(self) -> None:
        gen = ConversationGenerator(seed=4)
        for c in gen.death_loop(n=3, paraphrase="low", repeats=3):
            assert c.metadata["synthetic_label"] == "death_loop"
            assert c.metadata["paraphrase_level"] == "low"
            assert c.metadata["repeats"] == 3

    def test_exact_paraphrase_repeats_verbatim(self) -> None:
        gen = ConversationGenerator(seed=5)
        for c in gen.death_loop(n=3, paraphrase="exact", repeats=4):
            bot_contents = [m.content for m in c.messages if m.role == Role.BOT]
            # all bot responses are identical in "exact" mode
            assert len(set(bot_contents)) == 1

    def test_high_paraphrase_uses_multiple_variants(self) -> None:
        gen = ConversationGenerator(seed=6)
        seen_variants: set[str] = set()
        for c in gen.death_loop(n=1, paraphrase="high", repeats=4):
            for m in c.messages:
                if m.role == Role.BOT:
                    seen_variants.add(m.content)
        assert len(seen_variants) > 1


class TestReproducibility:
    def test_same_seed_same_output(self) -> None:
        a = ConversationGenerator(seed=42).death_loop(n=5, repeats=3)
        b = ConversationGenerator(seed=42).death_loop(n=5, repeats=3)
        assert [c.model_dump() for c in a] == [c.model_dump() for c in b]

    def test_different_seeds_diverge(self) -> None:
        a = ConversationGenerator(seed=1).death_loop(n=5, repeats=3)
        b = ConversationGenerator(seed=2).death_loop(n=5, repeats=3)
        # unlikely but not impossible for some fields to match; assert topic diversity
        topics_a = [c.metadata["template_topic"] for c in a]
        topics_b = [c.metadata["template_topic"] for c in b]
        assert topics_a != topics_b or any(
            ma.content != mb.content for ma, mb in zip(a[0].messages, b[0].messages, strict=False)
        )
