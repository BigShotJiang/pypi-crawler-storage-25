# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for ConfidentLiesDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from chatbot_auditor.detectors.confident_lies import ConfidentLiesDetector
from chatbot_auditor.knowledge import PolicyBase
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(id_: str, messages: list[tuple[Role, str]]) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert ConfidentLiesDetector.name == "confident_lies"
        assert ConfidentLiesDetector.failure_mode == FailureMode.CONFIDENT_LIES
        assert ConfidentLiesDetector.requires_llm is False


class TestWithoutPolicy:
    def test_commitment_flagged_for_review(self) -> None:
        conv = _make_conv(
            "lie-1",
            [
                (Role.USER, "I want a refund for my order"),
                (Role.BOT, "I'll process your refund within 3 business days."),
            ],
        )
        detections = ConfidentLiesDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.failure_mode == FailureMode.CONFIDENT_LIES
        assert det.severity == Severity.MEDIUM
        assert det.metadata["policy_provided"] is False
        assert det.metadata["unverified"] == 1

    def test_no_commitment_no_detection(self) -> None:
        conv = _make_conv(
            "lie-2",
            [
                (Role.USER, "What's your return policy?"),
                (Role.BOT, "Our standard return window is listed on example.com/returns."),
            ],
        )
        assert ConfidentLiesDetector().detect(conv) == []


class TestWithPolicy:
    def test_allowed_commitment_not_flagged(self) -> None:
        policy = PolicyBase.from_iterables(
            allowed=["within 30 days", "full refund for damaged goods"],
        )
        conv = _make_conv(
            "allow-1",
            [
                (Role.USER, "my item was damaged"),
                (
                    Role.BOT,
                    "We offer a full refund for damaged goods within 30 days of delivery.",
                ),
            ],
        )
        assert ConfidentLiesDetector(policy=policy).detect(conv) == []

    def test_disallowed_topic_raises_severity(self) -> None:
        policy = PolicyBase.from_iterables(
            disallowed=["lifetime warranty", "price match"],
        )
        conv = _make_conv(
            "dis-1",
            [
                (Role.USER, "Do you offer price match?"),
                (Role.BOT, "Yes, we guarantee a lifetime warranty on all products."),
            ],
        )
        detections = ConfidentLiesDetector(policy=policy).detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.severity == Severity.CRITICAL
        assert det.metadata["violated_disallowed"] >= 1

    def test_unverified_commitment_flagged_at_high(self) -> None:
        policy = PolicyBase.from_iterables(allowed=["30-day returns"])
        conv = _make_conv(
            "unv-1",
            [
                (Role.USER, "can i get a refund"),
                (Role.BOT, "I'll process a refund for you within 2 business days."),
            ],
        )
        detections = ConfidentLiesDetector(policy=policy).detect(conv)
        assert len(detections) == 1
        assert detections[0].severity == Severity.HIGH


class TestMultipleHits:
    def test_multiple_commitments_aggregated(self) -> None:
        conv = _make_conv(
            "multi-1",
            [
                (Role.USER, "please help"),
                (Role.BOT, "I'll process your refund immediately."),
                (Role.USER, "and the cancellation?"),
                (Role.BOT, "You will receive a confirmation email within 10 minutes."),
                (Role.USER, "and the extra fee?"),
                (Role.BOT, "That will be credited back free of charge."),
            ],
        )
        detections = ConfidentLiesDetector().detect(conv)
        assert len(detections) == 1
        assert detections[0].metadata["hit_count"] == 3
        assert len(detections[0].evidence) == 3
