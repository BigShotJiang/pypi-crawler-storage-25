# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for ZendeskAdapter — uses a mocked httpx transport."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from chatbot_auditor.adapters.zendesk import ZendeskAdapter
from chatbot_auditor.schema import Role


def _ticket(
    ticket_id: int = 1001,
    *,
    requester_id: int = 99,
    status: str = "solved",
    subject: str = "Help please",
) -> dict[str, Any]:
    return {
        "id": ticket_id,
        "requester_id": requester_id,
        "status": status,
        "subject": subject,
        "created_at": "2026-04-17T12:00:00Z",
        "updated_at": "2026-04-17T12:05:00Z",
    }


def _comment(
    author_id: int,
    body: str,
    *,
    public: bool = True,
    created_at: str = "2026-04-17T12:01:00Z",
) -> dict[str, Any]:
    return {
        "author_id": author_id,
        "body": body,
        "plain_body": body,
        "public": public,
        "created_at": created_at,
    }


def _build_transport(
    tickets_payload: dict[str, Any],
    comments_by_ticket: dict[int, dict[str, Any]],
) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path.startswith("/api/v2/tickets.json"):
            return httpx.Response(200, json=tickets_payload)
        # /api/v2/tickets/{id}/comments.json
        parts = path.split("/")
        ticket_id = int(parts[4])
        return httpx.Response(200, json=comments_by_ticket[ticket_id])

    return httpx.MockTransport(handler)


def _client(transport: httpx.MockTransport) -> httpx.Client:
    return httpx.Client(
        base_url="https://example.zendesk.com",
        transport=transport,
        headers={"Accept": "application/json"},
    )


class TestFetch:
    def test_parses_one_ticket(self) -> None:
        tickets = {
            "tickets": [_ticket(1001, requester_id=99)],
            "next_page": None,
        }
        comments = {
            1001: {
                "comments": [
                    _comment(99, "I need help with my order"),
                    _comment(7, "Hi, I can help! What's the order number?"),
                    _comment(99, "12345"),
                    _comment(7, "Got it, let me look."),
                ]
            }
        }
        transport = _build_transport(tickets, comments)
        adapter = ZendeskAdapter(
            subdomain="example",
            oauth_token="tok",
            client=_client(transport),
        )
        convs = adapter.collect()
        assert len(convs) == 1
        conv = convs[0]
        assert conv.id == "1001"
        assert conv.platform == "zendesk"
        assert conv.reported_resolved is True
        assert [m.role for m in conv.messages] == [
            Role.USER,
            Role.AGENT,
            Role.USER,
            Role.AGENT,
        ]

    def test_bot_user_mapped_to_bot_role(self) -> None:
        tickets = {"tickets": [_ticket(42, requester_id=100)], "next_page": None}
        comments = {
            42: {
                "comments": [
                    _comment(100, "help"),
                    _comment(555, "Hello, I'm the bot."),
                    _comment(7, "Real agent joining."),
                ]
            }
        }
        transport = _build_transport(tickets, comments)
        adapter = ZendeskAdapter(
            subdomain="example",
            oauth_token="tok",
            client=_client(transport),
            bot_user_ids=[555],
        )
        conv = adapter.collect()[0]
        assert [m.role for m in conv.messages] == [Role.USER, Role.BOT, Role.AGENT]

    def test_private_comment_maps_to_system(self) -> None:
        tickets = {"tickets": [_ticket(5, requester_id=1)], "next_page": None}
        comments = {
            5: {
                "comments": [
                    _comment(1, "help"),
                    _comment(7, "Internal note", public=False),
                    _comment(7, "Public reply"),
                ]
            }
        }
        transport = _build_transport(tickets, comments)
        adapter = ZendeskAdapter(
            subdomain="example",
            oauth_token="tok",
            client=_client(transport),
        )
        conv = adapter.collect()[0]
        assert [m.role for m in conv.messages] == [Role.USER, Role.SYSTEM, Role.AGENT]

    def test_status_open_not_resolved(self) -> None:
        tickets = {
            "tickets": [_ticket(1, requester_id=1, status="open")],
            "next_page": None,
        }
        comments = {1: {"comments": [_comment(1, "hi")]}}
        transport = _build_transport(tickets, comments)
        adapter = ZendeskAdapter(
            subdomain="example",
            oauth_token="tok",
            client=_client(transport),
        )
        conv = adapter.collect()[0]
        assert conv.reported_resolved is False


class TestAuth:
    def test_missing_subdomain_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("ZENDESK_SUBDOMAIN", raising=False)
        with pytest.raises(ValueError, match="subdomain"):
            ZendeskAdapter()

    def test_missing_credentials_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ZENDESK_SUBDOMAIN", "example")
        monkeypatch.delenv("ZENDESK_EMAIL", raising=False)
        monkeypatch.delenv("ZENDESK_API_TOKEN", raising=False)
        monkeypatch.delenv("ZENDESK_OAUTH_TOKEN", raising=False)
        with pytest.raises(ValueError, match="authentication"):
            ZendeskAdapter()
