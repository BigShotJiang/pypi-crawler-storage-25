# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for JSONAdapter."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from chatbot_auditor.adapters.json_adapter import JSONAdapter
from chatbot_auditor.schema import Role


def _sample_conv(id_: str = "c-1") -> dict[str, object]:
    return {
        "id": id_,
        "messages": [
            {"role": "user", "content": "hi"},
            {"role": "bot", "content": "Hello, how can I help?"},
        ],
    }


class TestSingle:
    def test_reads_single_conversation(self, tmp_path: Path) -> None:
        path = tmp_path / "one.json"
        path.write_text(json.dumps(_sample_conv("a")))
        convs = JSONAdapter(path).collect()
        assert len(convs) == 1
        assert convs[0].id == "a"
        assert convs[0].messages[0].role == Role.USER


class TestList:
    def test_reads_list_of_conversations(self, tmp_path: Path) -> None:
        path = tmp_path / "many.json"
        path.write_text(json.dumps([_sample_conv("a"), _sample_conv("b")]))
        convs = JSONAdapter(path).collect()
        assert [c.id for c in convs] == ["a", "b"]

    def test_list_with_non_list_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "bad.json"
        path.write_text(json.dumps({"not": "a list"}))
        with pytest.raises(ValidationError):
            JSONAdapter(path, format="single").collect()


class TestJSONL:
    def test_reads_jsonl(self, tmp_path: Path) -> None:
        path = tmp_path / "stream.jsonl"
        path.write_text(
            json.dumps(_sample_conv("a")) + "\n" + json.dumps(_sample_conv("b")) + "\n",
            encoding="utf-8",
        )
        convs = JSONAdapter(path).collect()
        assert [c.id for c in convs] == ["a", "b"]

    def test_auto_detects_jsonl(self, tmp_path: Path) -> None:
        path = tmp_path / "stream.json"
        path.write_text(
            json.dumps(_sample_conv("a")) + "\n" + json.dumps(_sample_conv("b")),
            encoding="utf-8",
        )
        # Auto-detection should identify as jsonl because of `}\n{`
        convs = JSONAdapter(path).collect()
        assert len(convs) == 2

    def test_ignores_blank_lines(self, tmp_path: Path) -> None:
        path = tmp_path / "jagged.jsonl"
        path.write_text(
            "\n" + json.dumps(_sample_conv("a")) + "\n\n" + json.dumps(_sample_conv("b")) + "\n",
            encoding="utf-8",
        )
        convs = JSONAdapter(path, format="jsonl").collect()
        assert len(convs) == 2


class TestErrors:
    def test_empty_file_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "empty.json"
        path.write_text("")
        with pytest.raises(ValueError, match="empty"):
            JSONAdapter(path).collect()

    def test_garbage_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "garbage.json"
        path.write_text("this is not JSON")
        with pytest.raises(ValueError, match="unrecognized JSON"):
            JSONAdapter(path).collect()
