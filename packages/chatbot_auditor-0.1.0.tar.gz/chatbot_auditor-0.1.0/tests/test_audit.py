# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the high-level audit() entry point."""

from __future__ import annotations

from chatbot_auditor import audit, default_registry
from chatbot_auditor.detectors import DetectorRegistry
from chatbot_auditor.generators import ConversationGenerator


def test_default_registry_contains_all_three_detectors() -> None:
    reg = default_registry()
    assert "death_loop" in reg
    assert "silent_churn" in reg
    assert "escalation_burial" in reg


def test_audit_death_loop_fires_at_least_on_each_conversation() -> None:
    gen = ConversationGenerator(seed=100)
    convs = gen.death_loop(n=5, paraphrase="exact", repeats=3)
    detections = audit(convs)
    death_loop_dets = [d for d in detections if d.detector == "death_loop"]
    assert len(death_loop_dets) == 5, "every death-loop conv should have a death_loop detection"
    # Additional detectors (silent_churn) may also fire on these — that is
    # correct behavior: a death loop often co-occurs with silent churn.


def test_audit_healthy_conversations_produces_no_detections() -> None:
    gen = ConversationGenerator(seed=101)
    convs = gen.healthy(n=10)
    detections = audit(convs)
    assert detections == [], f"false positives: {[d.detector for d in detections]}"


def test_audit_accepts_custom_registry() -> None:
    gen = ConversationGenerator(seed=102)
    convs = gen.death_loop(n=3, paraphrase="exact", repeats=3)
    empty_registry = DetectorRegistry()
    detections = audit(convs, detectors=empty_registry)
    assert detections == []


def test_audit_silent_churn_corpus() -> None:
    gen = ConversationGenerator(seed=103)
    convs = gen.silent_churn(n=5)
    detections = audit(convs)
    silent_dets = [d for d in detections if d.detector == "silent_churn"]
    assert len(silent_dets) == 5


def test_audit_escalation_burial_corpus() -> None:
    gen = ConversationGenerator(seed=104)
    convs = gen.escalation_burial(n=5)
    detections = audit(convs)
    burial_dets = [d for d in detections if d.detector == "escalation_burial"]
    assert len(burial_dets) == 5
