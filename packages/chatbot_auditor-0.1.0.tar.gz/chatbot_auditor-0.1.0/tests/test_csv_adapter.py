# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for CSVAdapter."""

from __future__ import annotations

from pathlib import Path

import pytest

from chatbot_auditor.adapters.csv_adapter import CSVAdapter
from chatbot_auditor.schema import Role


def _write_csv(path: Path, rows: list[str]) -> None:
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


class TestBasic:
    def test_groups_rows_by_conversation(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(
            path,
            [
                "conversation_id,role,content",
                "c1,user,hi",
                "c1,bot,hello how can I help?",
                "c2,user,different conv",
                "c2,bot,sure",
            ],
        )
        convs = CSVAdapter(path).collect()
        assert [c.id for c in convs] == ["c1", "c2"]
        assert len(convs[0].messages) == 2
        assert convs[0].messages[0].role == Role.USER
        assert convs[0].messages[1].role == Role.BOT

    def test_reads_timestamps_iso(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(
            path,
            [
                "conversation_id,role,content,timestamp",
                "c1,user,hi,2026-04-17T12:00:00Z",
                "c1,bot,hello,2026-04-17T12:00:05Z",
            ],
        )
        convs = CSVAdapter(path).collect()
        m = convs[0].messages
        assert m[0].timestamp is not None
        assert m[1].timestamp is not None
        assert m[0].timestamp < m[1].timestamp

    def test_reads_timestamps_unix(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(
            path,
            [
                "conversation_id,role,content,timestamp",
                "c1,user,hi,1713355200",
                "c1,bot,hello,1713355205",
            ],
        )
        convs = CSVAdapter(path).collect()
        m = convs[0].messages
        assert m[0].timestamp is not None


class TestColumnAliases:
    def test_accepts_author_column(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(
            path,
            [
                "conv_id,author,message",
                "c1,customer,hello",
                "c1,chatbot,hi there",
            ],
        )
        convs = CSVAdapter(path).collect()
        assert convs[0].messages[0].role == Role.USER
        assert convs[0].messages[1].role == Role.BOT

    def test_accepts_thread_id(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(
            path,
            [
                "thread_id,role,body",
                "t1,visitor,hi",
                "t1,agent,hello",
            ],
        )
        convs = CSVAdapter(path).collect()
        assert convs[0].id == "t1"
        assert convs[0].messages[1].role == Role.AGENT


class TestRoleResolution:
    def test_unknown_role_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(path, ["conversation_id,role,content", "c1,robot,hi"])
        with pytest.raises(ValueError, match="unknown role"):
            CSVAdapter(path).collect()

    def test_custom_role_mapping(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(path, ["conversation_id,role,content", "c1,robot,hi"])
        convs = CSVAdapter(path, role_mapping={"robot": Role.BOT}).collect()
        assert convs[0].messages[0].role == Role.BOT


class TestErrors:
    def test_missing_conversation_id_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(path, ["role,content", "user,hi"])
        with pytest.raises(ValueError, match="conversation id"):
            CSVAdapter(path).collect()

    def test_missing_role_raises(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        _write_csv(path, ["conversation_id,content", "c1,hi"])
        with pytest.raises(ValueError, match="role"):
            CSVAdapter(path).collect()

    def test_empty_file_no_output(self, tmp_path: Path) -> None:
        path = tmp_path / "empty.csv"
        path.write_text("")
        assert CSVAdapter(path).collect() == []

    def test_semicolon_delimiter(self, tmp_path: Path) -> None:
        path = tmp_path / "data.csv"
        path.write_text(
            "conversation_id;role;content\nc1;user;hi\nc1;bot;hello\n",
            encoding="utf-8",
        )
        convs = CSVAdapter(path, delimiter=";").collect()
        assert len(convs[0].messages) == 2
