# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the core Pydantic schema."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)


class TestMessage:
    def test_minimal_message(self) -> None:
        msg = Message(role=Role.USER, content="Hello")
        assert msg.role == Role.USER
        assert msg.content == "Hello"
        assert msg.timestamp is None
        assert msg.metadata == {}

    def test_message_is_frozen(self) -> None:
        msg = Message(role=Role.USER, content="Hello")
        with pytest.raises(ValidationError):
            msg.content = "Modified"

    def test_extra_fields_rejected(self) -> None:
        with pytest.raises(ValidationError):
            Message(role=Role.USER, content="Hi", unknown_field="bad")  # type: ignore[call-arg]

    def test_empty_content_allowed(self) -> None:
        msg = Message(role=Role.BOT, content="")
        assert msg.content == ""


class TestConversation:
    def test_requires_at_least_one_message(self) -> None:
        with pytest.raises(ValidationError):
            Conversation(id="c-1", messages=[])

    def test_requires_non_empty_id(self) -> None:
        with pytest.raises(ValidationError):
            Conversation(id="", messages=[Message(role=Role.USER, content="hi")])

    def test_message_count_property(self, healthy_conversation: Conversation) -> None:
        assert healthy_conversation.message_count == 3

    def test_role_filters(self, healthy_conversation: Conversation) -> None:
        assert len(healthy_conversation.user_messages) == 2
        assert len(healthy_conversation.bot_messages) == 1
        assert len(healthy_conversation.agent_messages) == 0

    def test_duration_from_explicit_timestamps(self) -> None:
        start = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
        end = start + timedelta(minutes=5)
        conv = Conversation(
            id="c-1",
            messages=[Message(role=Role.USER, content="hi")],
            started_at=start,
            ended_at=end,
        )
        assert conv.duration == timedelta(minutes=5)

    def test_duration_from_message_timestamps(self) -> None:
        t0 = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
        conv = Conversation(
            id="c-2",
            messages=[
                Message(role=Role.USER, content="hi", timestamp=t0),
                Message(role=Role.BOT, content="hello", timestamp=t0 + timedelta(seconds=10)),
            ],
        )
        assert conv.duration == timedelta(seconds=10)

    def test_duration_none_when_no_timestamps(self) -> None:
        conv = Conversation(
            id="c-3",
            messages=[Message(role=Role.USER, content="hi")],
        )
        assert conv.duration is None


class TestDetection:
    def test_confidence_bounds(self) -> None:
        with pytest.raises(ValidationError):
            Detection(
                conversation_id="c-1",
                detector="test",
                failure_mode=FailureMode.DEATH_LOOP,
                severity=Severity.HIGH,
                confidence=1.5,
                explanation="bad",
            )
        with pytest.raises(ValidationError):
            Detection(
                conversation_id="c-1",
                detector="test",
                failure_mode=FailureMode.DEATH_LOOP,
                severity=Severity.HIGH,
                confidence=-0.1,
                explanation="bad",
            )

    def test_detection_with_evidence(self) -> None:
        detection = Detection(
            conversation_id="c-1",
            detector="death_loop",
            failure_mode=FailureMode.DEATH_LOOP,
            severity=Severity.HIGH,
            confidence=0.92,
            explanation="Bot repeated the same FAQ link 3 times.",
            evidence=[
                Evidence(message_index=1, quote="Please check our FAQ"),
                Evidence(message_index=3, quote="Please check our FAQ"),
                Evidence(message_index=5, quote="Please check our FAQ"),
            ],
            recommended_action="escalate",
        )
        assert detection.failure_mode == FailureMode.DEATH_LOOP
        assert len(detection.evidence) == 3
        assert detection.recommended_action == "escalate"


def test_failure_mode_has_seven_modes() -> None:
    """There are exactly 7 failure modes — the core framework of the library."""
    assert len(FailureMode) == 7
