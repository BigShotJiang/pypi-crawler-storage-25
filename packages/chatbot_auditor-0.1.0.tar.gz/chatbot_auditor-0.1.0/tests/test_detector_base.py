# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the Detector base class and DetectorRegistry."""

from __future__ import annotations

import pytest

from chatbot_auditor.detectors import Detector, DetectorRegistry
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    FailureMode,
    Severity,
)


class _FakeDetector(Detector):
    """A minimal detector used only in tests."""

    name = "fake"
    description = "Fake detector for tests."
    failure_mode = FailureMode.DEATH_LOOP
    requires_llm = False

    def detect(self, conversation: Conversation) -> list[Detection]:
        if len(conversation.messages) >= 2:
            return [
                Detection(
                    conversation_id=conversation.id,
                    detector=self.name,
                    failure_mode=self.failure_mode,
                    severity=Severity.LOW,
                    confidence=0.5,
                    explanation="fake detection",
                )
            ]
        return []


class _OtherFakeDetector(Detector):
    name = "other_fake"
    description = "Another fake detector."
    failure_mode = FailureMode.SILENT_CHURN
    requires_llm = False

    def detect(self, conversation: Conversation) -> list[Detection]:
        return []


class TestDetectorSubclassing:
    def test_missing_class_attrs_raises(self) -> None:
        with pytest.raises(TypeError, match="must define class attribute"):

            class Broken(Detector):
                def detect(self, conversation: Conversation) -> list[Detection]:
                    return []

    def test_cannot_instantiate_abstract(self) -> None:
        with pytest.raises(TypeError):
            Detector()  # type: ignore[abstract]


class TestDetectorRegistry:
    def test_empty_registry(self) -> None:
        reg = DetectorRegistry()
        assert len(reg) == 0
        assert reg.all() == []

    def test_register_and_get(self) -> None:
        reg = DetectorRegistry()
        det = _FakeDetector()
        reg.register(det)
        assert len(reg) == 1
        assert reg.get("fake") is det
        assert "fake" in reg

    def test_duplicate_register_raises(self) -> None:
        reg = DetectorRegistry()
        reg.register(_FakeDetector())
        with pytest.raises(ValueError, match="already registered"):
            reg.register(_FakeDetector())

    def test_unregister(self) -> None:
        reg = DetectorRegistry([_FakeDetector()])
        reg.unregister("fake")
        assert len(reg) == 0
        reg.unregister("not_there")  # no-op

    def test_contains_rejects_non_string(self) -> None:
        reg = DetectorRegistry([_FakeDetector()])
        assert 42 not in reg

    def test_run_collects_from_all_detectors(self, healthy_conversation: Conversation) -> None:
        reg = DetectorRegistry([_FakeDetector(), _OtherFakeDetector()])
        detections = reg.run(healthy_conversation)
        assert len(detections) == 1
        assert detections[0].detector == "fake"

    def test_run_on_death_loop_fixture(self, death_loop_conversation: Conversation) -> None:
        reg = DetectorRegistry([_FakeDetector()])
        detections = reg.run(death_loop_conversation)
        assert len(detections) == 1
        assert detections[0].conversation_id == "conv-deathloop-1"
