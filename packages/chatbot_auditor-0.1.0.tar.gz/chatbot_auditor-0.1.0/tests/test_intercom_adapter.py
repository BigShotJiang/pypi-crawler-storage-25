# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for IntercomAdapter — uses a mocked httpx transport."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from chatbot_auditor.adapters.intercom import IntercomAdapter
from chatbot_auditor.schema import Role


def _raw_conversation(
    conv_id: str = "1",
    *,
    source_body: str = "<p>Hi, I need help with my order</p>",
    source_author_type: str = "user",
    parts: list[dict[str, Any]] | None = None,
    state: str = "closed",
) -> dict[str, Any]:
    return {
        "type": "conversation",
        "id": conv_id,
        "created_at": 1713355200,
        "updated_at": 1713355260,
        "state": state,
        "source": {
            "type": "conversation",
            "body": source_body,
            "author": {"type": source_author_type, "id": "u-1"},
        },
        "conversation_parts": {
            "conversation_parts": parts
            if parts is not None
            else [
                {
                    "part_type": "comment",
                    "body": "<p>How can I help?</p>",
                    "author": {"type": "bot", "id": "bot-1"},
                    "created_at": 1713355210,
                },
                {
                    "part_type": "comment",
                    "body": "<p>I ordered item <b>#12345</b> and it&#39;s broken</p>",
                    "author": {"type": "user", "id": "u-1"},
                    "created_at": 1713355230,
                },
                {
                    "part_type": "comment",
                    "body": "<p>Sorry to hear that, I'll help.</p>",
                    "author": {"type": "admin", "id": "admin-7"},
                    "created_at": 1713355250,
                },
            ],
        },
    }


def _mock_transport(pages: list[dict[str, Any]]) -> httpx.MockTransport:
    """Build a transport that returns each page in order, ending when exhausted."""
    call_count = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        idx = call_count["n"]
        call_count["n"] += 1
        if idx >= len(pages):
            return httpx.Response(200, json={"conversations": [], "pages": {}})
        return httpx.Response(200, json=pages[idx])

    return httpx.MockTransport(handler)


def _client(transport: httpx.MockTransport) -> httpx.Client:
    return httpx.Client(
        base_url=IntercomAdapter.BASE_URL,
        transport=transport,
        headers={"Authorization": "Bearer test-token"},
    )


class TestFetch:
    def test_parses_single_page(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation("1"), _raw_conversation("2")],
                    "pages": {},
                }
            ]
        )
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        convs = adapter.collect()
        assert [c.id for c in convs] == ["1", "2"]
        assert convs[0].platform == "intercom"
        assert convs[0].reported_resolved is True

    def test_paginates(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation("1")],
                    "pages": {"next": {"starting_after": "cursor-2"}},
                },
                {
                    "conversations": [_raw_conversation("2")],
                    "pages": {},
                },
            ]
        )
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        convs = adapter.collect()
        assert [c.id for c in convs] == ["1", "2"]

    def test_max_conversations_caps(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation(str(i)) for i in range(1, 6)],
                    "pages": {},
                }
            ]
        )
        adapter = IntercomAdapter(
            access_token="test",
            client=_client(transport),
            max_conversations=3,
        )
        assert len(adapter.collect()) == 3


class TestParsing:
    def test_html_is_stripped(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation("1")],
                    "pages": {},
                }
            ]
        )
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        conv = adapter.collect()[0]
        # Source message + 3 parts = 4 messages
        assert len(conv.messages) == 4
        assert "<" not in conv.messages[0].content
        assert "&#39;" not in conv.messages[2].content
        assert "it's broken" in conv.messages[2].content

    def test_role_mapping(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation("1")],
                    "pages": {},
                }
            ]
        )
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        conv = adapter.collect()[0]
        roles = [m.role for m in conv.messages]
        assert roles == [Role.USER, Role.BOT, Role.USER, Role.AGENT]

    def test_state_maps_to_resolved(self) -> None:
        transport = _mock_transport(
            [
                {
                    "conversations": [_raw_conversation("1", state="open")],
                    "pages": {},
                }
            ]
        )
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        conv = adapter.collect()[0]
        assert conv.reported_resolved is False


class TestAuth:
    def test_missing_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("INTERCOM_ACCESS_TOKEN", raising=False)
        with pytest.raises(ValueError, match="access token"):
            IntercomAdapter()

    def test_env_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("INTERCOM_ACCESS_TOKEN", "env-token")
        transport = _mock_transport([{"conversations": [], "pages": {}}])
        adapter = IntercomAdapter(client=_client(transport))
        assert adapter.access_token == "env-token"
        assert adapter.collect() == []


class TestRateLimit:
    def test_retries_on_429(self) -> None:
        attempts = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            attempts["n"] += 1
            if attempts["n"] == 1:
                return httpx.Response(429, headers={"Retry-After": "0"}, json={})
            return httpx.Response(
                200,
                json={"conversations": [_raw_conversation("r")], "pages": {}},
            )

        transport = httpx.MockTransport(handler)
        adapter = IntercomAdapter(access_token="test", client=_client(transport))
        convs = adapter.collect()
        assert len(convs) == 1
        assert attempts["n"] == 2
