# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Shared pytest fixtures."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from chatbot_auditor.schema import Conversation, Message, Role


@pytest.fixture
def base_time() -> datetime:
    return datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)


@pytest.fixture
def healthy_conversation(base_time: datetime) -> Conversation:
    """A normal, successful chatbot conversation."""
    return Conversation(
        id="conv-healthy-1",
        platform="intercom",
        messages=[
            Message(role=Role.USER, content="Hi, what time do you open?", timestamp=base_time),
            Message(
                role=Role.BOT,
                content="We open at 9 AM Monday through Friday.",
                timestamp=base_time + timedelta(seconds=5),
            ),
            Message(
                role=Role.USER,
                content="Great, thanks!",
                timestamp=base_time + timedelta(seconds=20),
            ),
        ],
        started_at=base_time,
        ended_at=base_time + timedelta(seconds=20),
        reported_resolved=True,
    )


@pytest.fixture
def death_loop_conversation(base_time: datetime) -> Conversation:
    """A conversation where the bot repeats itself and the user gives up."""
    repeated_response = (
        "I understand you'd like help with your refund. "
        "Please check our FAQ at example.com/faq for more information."
    )
    return Conversation(
        id="conv-deathloop-1",
        platform="intercom",
        messages=[
            Message(
                role=Role.USER,
                content="I need to get a refund for order #12345",
                timestamp=base_time,
            ),
            Message(
                role=Role.BOT,
                content=repeated_response,
                timestamp=base_time + timedelta(seconds=5),
            ),
            Message(
                role=Role.USER,
                content="I already read the FAQ, I need someone to process the refund",
                timestamp=base_time + timedelta(seconds=30),
            ),
            Message(
                role=Role.BOT,
                content=repeated_response,
                timestamp=base_time + timedelta(seconds=35),
            ),
            Message(
                role=Role.USER,
                content="this is useless",
                timestamp=base_time + timedelta(seconds=60),
            ),
            Message(
                role=Role.BOT,
                content=repeated_response,
                timestamp=base_time + timedelta(seconds=65),
            ),
        ],
        started_at=base_time,
        ended_at=base_time + timedelta(seconds=65),
        reported_resolved=True,
    )
