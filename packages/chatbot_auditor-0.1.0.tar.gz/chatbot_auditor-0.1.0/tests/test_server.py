# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the FastAPI server."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest
from fastapi.testclient import TestClient

from chatbot_auditor.server import app


@pytest.fixture
def client() -> Iterator[TestClient]:
    # Context-manage TestClient so FastAPI runs the lifespan hook and
    # populates `app.state.registry`.
    with TestClient(app) as c:
        yield c


def _sample_payload() -> dict[str, Any]:
    return {
        "conversations": [
            {
                "id": "c1",
                "platform": "test",
                "reported_resolved": True,
                "messages": [
                    {"role": "user", "content": "I need a refund"},
                    {
                        "role": "bot",
                        "content": "Please check our FAQ at example.com/faq for details.",
                    },
                    {"role": "user", "content": "Already did. Can someone process it?"},
                    {
                        "role": "bot",
                        "content": "Please check our FAQ at example.com/faq for details.",
                    },
                    {"role": "user", "content": "This is useless"},
                    {
                        "role": "bot",
                        "content": "Please check our FAQ at example.com/faq for details.",
                    },
                ],
            }
        ]
    }


class TestHealthAndMetadata:
    def test_healthz(self, client: TestClient) -> None:
        r = client.get("/healthz")
        assert r.status_code == 200
        assert r.json() == {"status": "ok"}

    def test_readyz(self, client: TestClient) -> None:
        r = client.get("/readyz")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ready"
        assert body["detector_count"] >= 5

    def test_version(self, client: TestClient) -> None:
        r = client.get("/version")
        assert r.status_code == 200
        body = r.json()
        assert body["author"] == "BK"
        assert body["license"] == "Apache-2.0"
        assert body["version"]

    def test_list_detectors(self, client: TestClient) -> None:
        r = client.get("/detectors")
        assert r.status_code == 200
        body = r.json()
        names = [d["name"] for d in body["detectors"]]
        assert "death_loop" in names
        assert "silent_churn" in names


class TestAnalyze:
    def test_analyze_happy_path(self, client: TestClient) -> None:
        r = client.post("/analyze", json=_sample_payload())
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["total_conversations"] == 1
        assert body["total_detections"] >= 1
        assert any(d["detector"] == "death_loop" for d in body["detections"])

    def test_analyze_requires_at_least_one_conversation(self, client: TestClient) -> None:
        r = client.post("/analyze", json={"conversations": []})
        assert r.status_code == 422

    def test_analyze_detector_filter(self, client: TestClient) -> None:
        payload = _sample_payload()
        payload["detector_names"] = ["death_loop"]
        r = client.post("/analyze", json=payload)
        assert r.status_code == 200
        detectors = {d["detector"] for d in r.json()["detections"]}
        assert detectors == {"death_loop"}

    def test_analyze_unknown_detector_rejected(self, client: TestClient) -> None:
        payload = _sample_payload()
        payload["detector_names"] = ["not_a_real_detector"]
        r = client.post("/analyze", json=payload)
        assert r.status_code == 400
        assert "not_a_real_detector" in r.text

    def test_oversized_payload_rejected(
        self, client: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CHATBOT_AUDITOR_MAX_CONVERSATIONS_PER_REQUEST", "1")
        import importlib  # noqa: PLC0415

        import chatbot_auditor.server as server_module  # noqa: PLC0415

        importlib.reload(server_module)
        try:
            with TestClient(server_module.app) as new_client:
                payload = _sample_payload()
                payload["conversations"] = payload["conversations"] * 2
                r = new_client.post("/analyze", json=payload)
                assert r.status_code == 413
        finally:
            monkeypatch.delenv("CHATBOT_AUDITOR_MAX_CONVERSATIONS_PER_REQUEST", raising=False)
            importlib.reload(server_module)


class TestAuth:
    def test_no_keys_configured_means_no_auth(self, client: TestClient) -> None:
        # No env var set; request should succeed without auth header.
        r = client.post("/analyze", json=_sample_payload())
        assert r.status_code == 200

    def test_missing_token_rejected_when_keys_configured(
        self, client: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CHATBOT_AUDITOR_API_KEYS", "secret-123")
        r = client.post("/analyze", json=_sample_payload())
        assert r.status_code == 401

    def test_wrong_token_rejected(
        self, client: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CHATBOT_AUDITOR_API_KEYS", "secret-123")
        r = client.post(
            "/analyze",
            json=_sample_payload(),
            headers={"Authorization": "Bearer wrong"},
        )
        assert r.status_code == 401

    def test_correct_token_accepted(
        self, client: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CHATBOT_AUDITOR_API_KEYS", "secret-123,other-key")
        r = client.post(
            "/analyze",
            json=_sample_payload(),
            headers={"Authorization": "Bearer secret-123"},
        )
        assert r.status_code == 200

    def test_healthz_unaffected_by_auth(
        self, client: TestClient, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CHATBOT_AUDITOR_API_KEYS", "secret-123")
        r = client.get("/healthz")
        assert r.status_code == 200
