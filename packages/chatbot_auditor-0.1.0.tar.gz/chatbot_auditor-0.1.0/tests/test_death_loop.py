# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for DeathLoopDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from chatbot_auditor.detectors.death_loop import DeathLoopDetector
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(
    id_: str, messages: list[tuple[Role, str]], *, at: datetime | None = None
) -> Conversation:
    base = at or datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 10))
            for i, (role, content) in enumerate(messages)
        ],
    )


_FAQ = "Please check our FAQ at example.com/faq for more information on refunds."


class TestConfiguration:
    def test_rejects_bad_threshold(self) -> None:
        with pytest.raises(ValueError, match="similarity_threshold"):
            DeathLoopDetector(similarity_threshold=1.5)
        with pytest.raises(ValueError, match="similarity_threshold"):
            DeathLoopDetector(similarity_threshold=-0.1)

    def test_rejects_bad_min_repeats(self) -> None:
        with pytest.raises(ValueError, match="min_repeats"):
            DeathLoopDetector(min_repeats=1)

    def test_rejects_bad_min_content_length(self) -> None:
        with pytest.raises(ValueError, match="min_content_length"):
            DeathLoopDetector(min_content_length=-1)

    def test_declares_metadata(self) -> None:
        assert DeathLoopDetector.name == "death_loop"
        assert DeathLoopDetector.failure_mode == FailureMode.DEATH_LOOP
        assert DeathLoopDetector.requires_llm is False


class TestExactRepetition:
    def test_detects_three_exact_repetitions(self) -> None:
        conv = _make_conv(
            "c-1",
            [
                (Role.USER, "I want a refund"),
                (Role.BOT, _FAQ),
                (Role.USER, "Please, can you just process it"),
                (Role.BOT, _FAQ),
                (Role.USER, "come on"),
                (Role.BOT, _FAQ),
            ],
        )
        detections = DeathLoopDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.failure_mode == FailureMode.DEATH_LOOP
        assert det.detector == "death_loop"
        assert det.confidence >= 0.6
        assert det.recommended_action == "escalate"
        assert det.metadata["repeat_count"] == 3
        assert len(det.evidence) == 3

    def test_does_not_fire_on_two_repetitions(self) -> None:
        conv = _make_conv(
            "c-2",
            [
                (Role.USER, "I want a refund"),
                (Role.BOT, _FAQ),
                (Role.USER, "please"),
                (Role.BOT, _FAQ),
            ],
        )
        assert DeathLoopDetector().detect(conv) == []

    def test_custom_min_repeats(self) -> None:
        conv = _make_conv(
            "c-3",
            [
                (Role.USER, "refund?"),
                (Role.BOT, _FAQ),
                (Role.USER, "hello?"),
                (Role.BOT, _FAQ),
            ],
        )
        assert DeathLoopDetector(min_repeats=2).detect(conv)


class TestNonLoops:
    def test_healthy_conversation_no_detection(self, healthy_conversation: Conversation) -> None:
        assert DeathLoopDetector().detect(healthy_conversation) == []

    def test_different_bot_replies_no_detection(self) -> None:
        conv = _make_conv(
            "c-diff",
            [
                (Role.USER, "hi"),
                (Role.BOT, "Hello! How can I help you today?"),
                (Role.USER, "I have a question about shipping"),
                (Role.BOT, "Sure — what would you like to know about shipping?"),
                (Role.USER, "How long to Canada?"),
                (Role.BOT, "Canada shipping is 5–7 business days for standard delivery."),
            ],
        )
        assert DeathLoopDetector().detect(conv) == []

    def test_single_message(self) -> None:
        conv = _make_conv("c-single", [(Role.USER, "hi")])
        assert DeathLoopDetector().detect(conv) == []

    def test_short_bot_messages_ignored(self) -> None:
        conv = _make_conv(
            "c-short",
            [
                (Role.USER, "hi"),
                (Role.BOT, "OK"),
                (Role.USER, "there?"),
                (Role.BOT, "OK"),
                (Role.USER, "hello?"),
                (Role.BOT, "OK"),
            ],
        )
        assert DeathLoopDetector().detect(conv) == []


class TestParaphraseRobustness:
    def test_detects_light_paraphrase(self, death_loop_conversation: Conversation) -> None:
        detections = DeathLoopDetector().detect(death_loop_conversation)
        assert len(detections) == 1

    def test_high_threshold_misses_distinct_wording(self) -> None:
        conv = _make_conv(
            "c-distinct",
            [
                (Role.USER, "I want a refund"),
                (Role.BOT, "Please visit our returns page at example.com/returns."),
                (Role.USER, "ok"),
                (Role.BOT, "For refund information see our policy at example.com/policy."),
                (Role.USER, "ok"),
                (Role.BOT, "Refunds are processed via our help center at example.com/help."),
            ],
        )
        assert DeathLoopDetector(similarity_threshold=0.95).detect(conv) == []


class TestSeverityAndConfidence:
    def test_severity_scales_with_repeats(self) -> None:
        responses = [(Role.USER, "?"), (Role.BOT, _FAQ)] * 6
        conv = _make_conv("c-many", responses)
        detections = DeathLoopDetector().detect(conv)
        assert len(detections) == 1
        assert detections[0].severity == Severity.CRITICAL
        assert detections[0].metadata["repeat_count"] >= 5

    def test_frustration_boosts_confidence(self) -> None:
        base_msgs = [
            (Role.USER, "I need a refund"),
            (Role.BOT, _FAQ),
            (Role.USER, "please help"),
            (Role.BOT, _FAQ),
            (Role.USER, "hello?"),
            (Role.BOT, _FAQ),
        ]
        frustrated_msgs = [
            (Role.USER, "I need a refund"),
            (Role.BOT, _FAQ),
            (Role.USER, "this is useless"),
            (Role.BOT, _FAQ),
            (Role.USER, "what a waste of time"),
            (Role.BOT, _FAQ),
        ]
        calm = DeathLoopDetector().detect(_make_conv("c-calm", base_msgs))
        angry = DeathLoopDetector().detect(_make_conv("c-angry", frustrated_msgs))
        assert len(calm) == 1
        assert len(angry) == 1
        assert angry[0].confidence > calm[0].confidence
        assert angry[0].metadata["frustration_detected"] is True


class TestPropertyBased:
    @settings(max_examples=50, deadline=None)
    @given(
        st.integers(min_value=3, max_value=10),
        # Alphanumeric + space only: punctuation-only strings normalize to
        # empty, which legitimately produces 0.0 similarity.
        st.text(
            alphabet=st.characters(
                whitelist_categories=("Ll", "Lu", "Nd"), whitelist_characters=" "
            ),
            min_size=20,
            max_size=100,
        ).filter(lambda s: s.strip()),
    )
    def test_identical_bot_messages_always_detected(self, repeats: int, response: str) -> None:
        """Property: any conversation with N>=3 identical bot messages must be detected."""
        msgs: list[tuple[Role, str]] = []
        for _ in range(repeats):
            msgs.extend([(Role.USER, "asking again"), (Role.BOT, response)])
        conv = _make_conv("prop", msgs)
        detections = DeathLoopDetector().detect(conv)
        assert len(detections) == 1, f"Expected detection for {repeats} identical bot messages"
        assert detections[0].metadata["repeat_count"] == repeats

    @settings(max_examples=50, deadline=None)
    @given(st.integers(min_value=3, max_value=6))
    def test_diverse_bot_messages_never_detected(self, count: int) -> None:
        """Property: conversations with genuinely different bot responses never trigger.

        Note: messages that differ only by a small number (e.g. "Answer 0", "Answer 1")
        are correctly identified as loops — the bot is scripted. This test uses
        templates that are semantically and lexically distinct.
        """
        templates = [
            "Our weekend hours are Saturday 10 AM to 6 PM Eastern time.",
            "Yes, we ship to all Canadian provinces via standard mail service.",
            "You can cancel from your account page under Billing settings.",
            "Electronics have a 30-day return window from the date of delivery.",
            "Verified students get 15% off through our student discount program.",
            "Our customer service line runs 9 AM to 5 PM EST on weekdays only.",
        ]
        msgs: list[tuple[Role, str]] = []
        for i in range(count):
            msgs.append((Role.USER, f"Question number {i}"))
            msgs.append((Role.BOT, templates[i]))
        conv = _make_conv("prop-diverse", msgs)
        assert DeathLoopDetector().detect(conv) == []

    @settings(max_examples=30, deadline=None)
    @given(st.integers(min_value=3, max_value=8))
    def test_idempotent(self, repeats: int) -> None:
        """Running the detector twice yields identical detections."""
        msgs: list[tuple[Role, str]] = []
        for _ in range(repeats):
            msgs.extend([(Role.USER, "asking"), (Role.BOT, _FAQ)])
        conv = _make_conv("idempotent", msgs)
        detector = DeathLoopDetector()
        run_a = detector.detect(conv)
        run_b = detector.detect(conv)
        assert [d.model_dump() for d in run_a] == [d.model_dump() for d in run_b]
