# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the reporting module."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from chatbot_auditor.reporting import (
    HTMLReporter,
    MarkdownReporter,
    build_summary,
    render_html,
    render_markdown,
)
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _conv(id_: str, n_messages: int = 4) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        reported_resolved=True,
        messages=[
            Message(
                role=Role.USER if i % 2 == 0 else Role.BOT,
                content=f"Message {i} on {id_}",
                timestamp=base + timedelta(seconds=i * 10),
            )
            for i in range(n_messages)
        ],
    )


def _detection(
    conv_id: str,
    *,
    detector: str = "death_loop",
    failure_mode: FailureMode = FailureMode.DEATH_LOOP,
    severity: Severity = Severity.HIGH,
    confidence: float = 0.8,
    explanation: str = "Test detection.",
    evidence_count: int = 2,
) -> Detection:
    return Detection(
        conversation_id=conv_id,
        detector=detector,
        failure_mode=failure_mode,
        severity=severity,
        confidence=confidence,
        explanation=explanation,
        evidence=[Evidence(message_index=i, quote=f"quote {i}") for i in range(evidence_count)],
    )


class TestBuildSummary:
    def test_empty(self) -> None:
        summary = build_summary([], [])
        assert summary.total_conversations == 0
        assert summary.detections_total == 0
        assert summary.pass_rate == 1.0

    def test_counts(self) -> None:
        convs = [_conv("a"), _conv("b"), _conv("c")]
        dets = [
            _detection("a", severity=Severity.HIGH),
            _detection("a", detector="silent_churn", severity=Severity.MEDIUM),
            _detection("b", severity=Severity.CRITICAL),
        ]
        summary = build_summary(convs, dets)
        assert summary.total_conversations == 3
        assert summary.detections_total == 3
        assert summary.conversations_with_detections == 2
        assert summary.detections_by_severity == {"high": 1, "medium": 1, "critical": 1}
        assert summary.detections_by_detector == {"death_loop": 2, "silent_churn": 1}
        assert summary.pass_rate == 1 / 3


class TestMarkdownReporter:
    def test_empty_renders_clean(self) -> None:
        md = render_markdown([], [])
        assert "chatbot-auditor audit report" in md
        assert "Conversations analyzed:** 0" in md
        assert "Pass rate:** 100.0%" in md

    def test_with_detections_has_sections(self) -> None:
        convs = [_conv("a"), _conv("b")]
        dets = [
            _detection("a", severity=Severity.CRITICAL),
            _detection("a", detector="silent_churn", severity=Severity.HIGH),
            _detection("b", severity=Severity.MEDIUM),
        ]
        md = render_markdown(convs, dets)
        assert "## Detections by severity" in md
        assert "## Detections by detector" in md
        assert "## Flagged conversations" in md
        assert "Critical" in md
        assert "silent_churn" in md
        assert "`a`" in md
        assert "`b`" in md

    def test_top_n_limits_conversation_cards(self) -> None:
        convs = [_conv(f"c{i}") for i in range(10)]
        dets = [_detection(f"c{i}") for i in range(10)]
        md = render_markdown(convs, dets, top_n=3)
        assert "top 3 of 10" in md

    def test_orders_worst_first(self) -> None:
        convs = [_conv("mild"), _conv("nuclear")]
        dets = [
            _detection("mild", severity=Severity.LOW, confidence=0.5),
            _detection("nuclear", severity=Severity.CRITICAL, confidence=0.95),
        ]
        md = render_markdown(convs, dets)
        assert md.index("`nuclear`") < md.index("`mild`")

    def test_evidence_rendered_as_quotes(self) -> None:
        convs = [_conv("a")]
        dets = [_detection("a", evidence_count=2)]
        md = render_markdown(convs, dets)
        assert "> quote 0" in md
        assert "> quote 1" in md

    def test_evidence_truncates_after_three(self) -> None:
        convs = [_conv("a")]
        dets = [_detection("a", evidence_count=5)]
        md = render_markdown(convs, dets)
        assert "> quote 2" in md
        assert "+2 more" in md


class TestHTMLReporter:
    def test_renders_html5_document(self) -> None:
        html_doc = render_html([], [])
        assert html_doc.startswith("<!DOCTYPE html>")
        assert "<title>chatbot-auditor audit report</title>" in html_doc
        assert "</html>" in html_doc

    def test_stat_cards_present(self) -> None:
        convs = [_conv("a"), _conv("b")]
        dets = [_detection("a")]
        html_doc = render_html(convs, dets)
        assert 'class="stat-value"' in html_doc
        assert "Pass rate" in html_doc
        assert "50.0%" in html_doc

    def test_severity_badges(self) -> None:
        convs = [_conv("a")]
        dets = [_detection("a", severity=Severity.CRITICAL)]
        html_doc = render_html(convs, dets)
        assert "sev-critical" in html_doc

    def test_escapes_user_content(self) -> None:
        convs = [_conv("a")]
        bad_quote_evidence = Evidence(message_index=0, quote="<script>alert('xss')</script>")
        det = Detection(
            conversation_id="a",
            detector="test",
            failure_mode=FailureMode.DEATH_LOOP,
            severity=Severity.HIGH,
            confidence=0.8,
            explanation="<img src=x onerror=alert(1)>",
            evidence=[bad_quote_evidence],
        )
        html_doc = render_html(convs, [det])
        assert "<script>" not in html_doc
        assert "&lt;script&gt;" in html_doc
        assert "<img src=x" not in html_doc
        assert "&lt;img" in html_doc

    def test_custom_title(self) -> None:
        html_doc = render_html([], [], title="Weekly CX Audit")
        assert "<title>Weekly CX Audit</title>" in html_doc
        assert "<h1>Weekly CX Audit</h1>" in html_doc


class TestReporterNames:
    def test_names_declared(self) -> None:
        assert MarkdownReporter.name == "markdown"
        assert HTMLReporter.name == "html"
