# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for similarity functions."""

from __future__ import annotations

import pytest
from hypothesis import given
from hypothesis import strategies as st

from chatbot_auditor.similarity import (
    lexical_similarity,
    normalize,
    token_jaccard,
)


class TestNormalize:
    def test_lowercases(self) -> None:
        assert normalize("HELLO World") == "hello world"

    def test_strips_punctuation(self) -> None:
        assert normalize("hello, world!") == "hello world"

    def test_collapses_whitespace(self) -> None:
        assert normalize("hello     world\n\n\tthere") == "hello world there"

    def test_empty(self) -> None:
        assert normalize("") == ""
        assert normalize("   ") == ""
        assert normalize("!!!") == ""


class TestLexicalSimilarity:
    def test_identical_strings_are_1(self) -> None:
        assert lexical_similarity("hello world", "hello world") == 1.0

    def test_ignores_casing_and_punctuation(self) -> None:
        assert lexical_similarity("Hello, world!", "HELLO WORLD") == 1.0

    def test_totally_different_strings_are_low(self) -> None:
        sim = lexical_similarity("refund my order", "what time is it")
        assert sim < 0.3

    def test_near_paraphrase_scores_high(self) -> None:
        a = "Please check our FAQ at example.com/faq for details"
        b = "Please check our FAQ at example.com/faq for more details"
        assert lexical_similarity(a, b) > 0.9

    def test_empty_strings(self) -> None:
        assert lexical_similarity("", "") == 0.0
        assert lexical_similarity("", "anything") == 0.0
        assert lexical_similarity("anything", "") == 0.0

    def test_range(self) -> None:
        sim = lexical_similarity("partial overlap here", "partial something else")
        assert 0.0 <= sim <= 1.0

    @given(st.text(min_size=1, max_size=200))
    def test_self_similarity_is_1(self, s: str) -> None:
        assume_nonempty = normalize(s)
        if not assume_nonempty:
            return
        assert lexical_similarity(s, s) == 1.0

    @given(st.text(max_size=100), st.text(max_size=100))
    def test_always_in_range(self, a: str, b: str) -> None:
        assert 0.0 <= lexical_similarity(a, b) <= 1.0

    @given(st.text(min_size=1, max_size=100), st.text(min_size=1, max_size=100))
    def test_symmetric(self, a: str, b: str) -> None:
        assert lexical_similarity(a, b) == lexical_similarity(b, a)


class TestTokenJaccard:
    def test_identical(self) -> None:
        assert token_jaccard("hello world", "hello world") == 1.0

    def test_disjoint(self) -> None:
        assert token_jaccard("one two", "three four") == 0.0

    def test_half_overlap(self) -> None:
        # tokens {"a","b"} and {"b","c"} -> intersection 1, union 3 -> 1/3
        assert token_jaccard("a b", "b c") == pytest.approx(1 / 3)

    def test_empty(self) -> None:
        assert token_jaccard("", "anything") == 0.0
