# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for the embeddings similarity backend.

Uses a fake encoder for unit tests — loading a real sentence-transformers
model is slow (~5 seconds for 90 MB) and unnecessary for verifying behavior.
"""

from __future__ import annotations

import numpy as np
import pytest

from chatbot_auditor.backends.embeddings import EmbeddingsSimilarity


class _FakeEncoder:
    """Deterministic fake encoder keyed on exact text.

    Each distinct string gets a unique unit-length random vector. Repeated
    calls with the same text return the same vector, so cosine similarity
    is meaningful: identical strings score 1.0, distinct strings score near 0.
    """

    def __init__(self, dim: int = 16) -> None:
        self._dim = dim
        self._vectors: dict[str, np.ndarray] = {}
        self._rng = np.random.default_rng(seed=42)

    def encode(self, sentences: list[str], **kwargs: object) -> np.ndarray:
        out = np.zeros((len(sentences), self._dim), dtype=np.float32)
        for i, s in enumerate(sentences):
            if s not in self._vectors:
                v = self._rng.standard_normal(self._dim).astype(np.float32)
                v /= np.linalg.norm(v)
                self._vectors[s] = v
            out[i] = self._vectors[s]
        return out


class _ParaphraseEncoder(_FakeEncoder):
    """Fake encoder that gives high similarity to registered paraphrase pairs."""

    def __init__(self, dim: int = 16) -> None:
        super().__init__(dim)
        self._paraphrases: dict[frozenset[str], np.ndarray] = {}

    def register_paraphrase(self, a: str, b: str) -> None:
        v = self._rng.standard_normal(self._dim).astype(np.float32)
        v /= np.linalg.norm(v)
        self._vectors[a] = v
        self._vectors[b] = v  # identical embedding


def _backend_with(encoder: _FakeEncoder, **kwargs: object) -> EmbeddingsSimilarity:
    return EmbeddingsSimilarity(model=encoder, **kwargs)  # type: ignore[arg-type]


class TestBasic:
    def test_identical_strings_score_1(self) -> None:
        backend = _backend_with(_FakeEncoder())
        assert backend("hello world", "hello world") == 1.0

    def test_empty_strings_score_0(self) -> None:
        backend = _backend_with(_FakeEncoder())
        assert backend("", "hello") == 0.0
        assert backend("hello", "") == 0.0
        assert backend("", "") == 0.0

    def test_score_in_valid_range(self) -> None:
        backend = _backend_with(_FakeEncoder())
        score = backend("alpha", "beta")
        assert -1.0 <= score <= 1.0


class TestParaphraseDetection:
    def test_registered_paraphrases_score_near_1(self) -> None:
        encoder = _ParaphraseEncoder()
        encoder.register_paraphrase(
            "I'll process your refund within 3 days",
            "Your refund will be issued in 3 days",
        )
        backend = _backend_with(encoder)
        score = backend(
            "I'll process your refund within 3 days",
            "Your refund will be issued in 3 days",
        )
        assert score == pytest.approx(1.0)

    def test_unrelated_strings_score_well_below_threshold(self) -> None:
        backend = _backend_with(_FakeEncoder())
        scores = [
            backend("refund my order", "what time do you open"),
            backend("password reset help", "where is my shipment"),
        ]
        assert all(s < 0.85 for s in scores)


class TestCache:
    def test_cache_avoids_re_encoding(self) -> None:
        encoder = _FakeEncoder()
        call_count = {"n": 0}
        original_encode = encoder.encode

        def counting_encode(sentences: list[str], **kwargs: object) -> np.ndarray:
            call_count["n"] += 1
            return original_encode(sentences, **kwargs)

        encoder.encode = counting_encode  # type: ignore[method-assign]
        backend = _backend_with(encoder)

        backend("hello", "world")
        first = call_count["n"]
        backend("hello", "world")
        second = call_count["n"]
        assert second == first, "expected cache hits on second call"

    def test_cache_size_zero_disables_cache(self) -> None:
        encoder = _FakeEncoder()
        call_count = {"n": 0}
        original_encode = encoder.encode

        def counting_encode(sentences: list[str], **kwargs: object) -> np.ndarray:
            call_count["n"] += 1
            return original_encode(sentences, **kwargs)

        encoder.encode = counting_encode  # type: ignore[method-assign]
        backend = _backend_with(encoder, cache_size=0)

        backend("hello", "world")
        backend("hello", "world")
        assert call_count["n"] == 4  # two encodes per call, no cache

    def test_negative_cache_size_rejected(self) -> None:
        with pytest.raises(ValueError, match="cache_size"):
            _backend_with(_FakeEncoder(), cache_size=-1)

    def test_cache_enforces_size_limit(self) -> None:
        encoder = _FakeEncoder()
        backend = _backend_with(encoder, cache_size=2)
        backend("a", "b")
        backend("c", "d")
        backend("e", "f")
        # Cache should have evicted the oldest entries ("a" / "b")
        assert "a" not in backend._cache
        assert "e" in backend._cache


class TestIntegrationWithDeathLoop:
    def test_plugs_into_death_loop_detector(self) -> None:
        from datetime import UTC, datetime, timedelta  # noqa: PLC0415

        from chatbot_auditor import DeathLoopDetector  # noqa: PLC0415
        from chatbot_auditor.schema import Conversation, Message, Role  # noqa: PLC0415

        encoder = _ParaphraseEncoder()
        # Three distinct surface forms mapped to the same embedding
        paraphrase_set = [
            "I'll process your refund within 3 days.",
            "Your refund will be issued in 3 days.",
            "We'll get that refund to you in 3 days.",
        ]
        base_vec = encoder._rng.standard_normal(encoder._dim).astype(np.float32)
        base_vec /= np.linalg.norm(base_vec)
        for phrase in paraphrase_set:
            encoder._vectors[phrase] = base_vec

        backend = _backend_with(encoder)
        detector = DeathLoopDetector(similarity_fn=backend, similarity_threshold=0.9)

        base = datetime(2026, 4, 17, tzinfo=UTC)
        messages = []
        for i, phrase in enumerate(paraphrase_set):
            messages.append(
                Message(
                    role=Role.USER,
                    content=f"I need a refund, can you help please (attempt {i})?",
                    timestamp=base + timedelta(seconds=i * 20),
                )
            )
            messages.append(
                Message(
                    role=Role.BOT,
                    content=phrase,
                    timestamp=base + timedelta(seconds=i * 20 + 5),
                )
            )

        conv = Conversation(id="semantic-loop", platform="test", messages=messages)
        detections = detector.detect(conv)
        assert len(detections) == 1, (
            "embeddings backend should unify paraphrased responses into one loop"
        )
