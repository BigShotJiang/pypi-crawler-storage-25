# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for SentimentCollapseDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from chatbot_auditor.detectors.sentiment_collapse import (
    KeywordSentimentScorer,
    SentimentCollapseDetector,
)
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(id_: str, messages: list[tuple[Role, str]]) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert SentimentCollapseDetector.name == "sentiment_collapse"
        assert SentimentCollapseDetector.failure_mode == FailureMode.SENTIMENT_COLLAPSE
        assert SentimentCollapseDetector.requires_llm is False

    def test_rejects_bad_min_user_messages(self) -> None:
        with pytest.raises(ValueError, match="min_user_messages"):
            SentimentCollapseDetector(min_user_messages=2)

    def test_rejects_bad_min_drop(self) -> None:
        with pytest.raises(ValueError, match="min_drop"):
            SentimentCollapseDetector(min_drop=-0.1)

    def test_rejects_bad_end_threshold(self) -> None:
        with pytest.raises(ValueError, match="end_threshold"):
            SentimentCollapseDetector(end_threshold=1.5)


class TestKeywordSentimentScorer:
    def test_all_positive(self) -> None:
        assert KeywordSentimentScorer().score("thanks this is great and helpful") > 0.5

    def test_all_negative(self) -> None:
        assert KeywordSentimentScorer().score("useless, terrible, frustrating") < -0.5

    def test_neutral(self) -> None:
        assert KeywordSentimentScorer().score("the store is on main street") == 0.0

    def test_mixed(self) -> None:
        # 1 positive (thanks), 2 negative (useless, frustrating): normalized
        score = KeywordSentimentScorer().score("thanks but this is useless and frustrating")
        assert score < 0


class TestPositiveCases:
    def test_classic_collapse_detected(self) -> None:
        conv = _make_conv(
            "collapse-1",
            [
                (Role.USER, "Hi! I hope you can help me with a billing question."),
                (Role.BOT, "Of course, what's your question?"),
                (Role.USER, "Great, thanks for the quick reply!"),
                (Role.BOT, "Happy to help. What's the issue?"),
                (Role.USER, "My invoice is wrong, I was charged twice for last month"),
                (Role.BOT, "Please log into your account at example.com/billing."),
                (Role.USER, "This is ridiculous, I've already tried that"),
                (Role.BOT, "You can also contact support via email."),
                (Role.USER, "This is useless, absolutely frustrating, terrible"),
            ],
        )
        detections = SentimentCollapseDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.failure_mode == FailureMode.SENTIMENT_COLLAPSE
        assert det.severity in {Severity.MEDIUM, Severity.HIGH}
        assert det.metadata["drop"] > 0.4
        assert det.metadata["late_avg"] < -0.2


class TestNegativeCases:
    def test_healthy_conversation_not_flagged(self) -> None:
        conv = _make_conv(
            "healthy-1",
            [
                (Role.USER, "Hi, quick question"),
                (Role.BOT, "Sure, what can I help with?"),
                (Role.USER, "What time do you open?"),
                (Role.BOT, "We open at 9 AM on weekdays."),
                (Role.USER, "Perfect, thanks!"),
            ],
        )
        assert SentimentCollapseDetector().detect(conv) == []

    def test_short_conversation_not_flagged(self) -> None:
        conv = _make_conv(
            "short-1",
            [
                (Role.USER, "I'm frustrated about something"),
                (Role.BOT, "Sorry to hear that."),
            ],
        )
        assert SentimentCollapseDetector().detect(conv) == []

    def test_constant_negative_not_flagged(self) -> None:
        """Constant negative sentiment is not a collapse — there was no drop."""
        conv = _make_conv(
            "cnst-neg",
            [
                (Role.USER, "I hate this product, useless from the start"),
                (Role.BOT, "I'm sorry you feel that way. How can I help?"),
                (Role.USER, "This whole thing is terrible and broken"),
                (Role.BOT, "Let me try to assist."),
                (Role.USER, "Worst company ever, total waste"),
            ],
        )
        assert SentimentCollapseDetector().detect(conv) == []
