# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Tests for SilentChurnDetector."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from chatbot_auditor.detectors.silent_churn import SilentChurnDetector
from chatbot_auditor.generators import ConversationGenerator
from chatbot_auditor.schema import (
    Conversation,
    FailureMode,
    Message,
    Role,
    Severity,
)


def _make_conv(
    id_: str,
    messages: list[tuple[Role, str]],
    *,
    reported_resolved: bool | None = True,
) -> Conversation:
    base = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    return Conversation(
        id=id_,
        platform="test",
        messages=[
            Message(role=role, content=content, timestamp=base + timedelta(seconds=i * 30))
            for i, (role, content) in enumerate(messages)
        ],
        reported_resolved=reported_resolved,
    )


class TestConfiguration:
    def test_declares_metadata(self) -> None:
        assert SilentChurnDetector.name == "silent_churn"
        assert SilentChurnDetector.failure_mode == FailureMode.SILENT_CHURN
        assert SilentChurnDetector.requires_llm is False

    def test_rejects_bad_min_counts(self) -> None:
        with pytest.raises(ValueError, match="min_user_messages"):
            SilentChurnDetector(min_user_messages=0)
        with pytest.raises(ValueError, match="min_bot_messages"):
            SilentChurnDetector(min_bot_messages=0)


class TestPositiveCases:
    def test_ends_with_bot_no_confirmation_flags_churn(self) -> None:
        conv = _make_conv(
            "churn-1",
            [
                (Role.USER, "How do I cancel my subscription?"),
                (Role.BOT, "You can cancel from the Billing page of your account."),
                (Role.USER, "The button on that page isn't working for me"),
                (
                    Role.BOT,
                    "Please try clearing your browser cache and cookies, then "
                    "attempt the cancellation again.",
                ),
            ],
        )
        detections = SilentChurnDetector().detect(conv)
        assert len(detections) == 1
        det = detections[0]
        assert det.failure_mode == FailureMode.SILENT_CHURN
        assert det.severity == Severity.HIGH  # reported_resolved=True -> HIGH
        assert det.recommended_action == "follow_up"
        assert det.metadata["reported_resolved"] is True
        assert det.confidence >= 0.6

    def test_reported_resolved_boosts_severity(self) -> None:
        convo_template = [
            (Role.USER, "I have a billing question about last month"),
            (Role.BOT, "Please check your billing history at example.com/billing."),
            (Role.USER, "I see the charges but don't understand the second one"),
            (
                Role.BOT,
                "All charges are processed automatically by our system. "
                "For disputes, submit a refund request through the portal.",
            ),
        ]
        resolved = _make_conv("churn-res", convo_template, reported_resolved=True)
        unresolved = _make_conv("churn-unres", convo_template, reported_resolved=False)

        r_det = SilentChurnDetector().detect(resolved)
        u_det = SilentChurnDetector().detect(unresolved)
        assert len(r_det) == 1
        assert len(u_det) == 1
        assert r_det[0].severity == Severity.HIGH
        assert u_det[0].severity == Severity.MEDIUM
        assert r_det[0].confidence > u_det[0].confidence


class TestNegativeCases:
    def test_healthy_conversation_not_flagged(self) -> None:
        conv = _make_conv(
            "healthy-1",
            [
                (Role.USER, "What time do you open on weekends?"),
                (Role.BOT, "We're open Saturday 10 AM to 6 PM and Sunday 11 AM to 5 PM."),
                (Role.USER, "Perfect, thanks!"),
            ],
        )
        assert SilentChurnDetector().detect(conv) == []

    def test_confirmation_anywhere_skips_detection(self) -> None:
        conv = _make_conv(
            "healthy-2",
            [
                (Role.USER, "Thanks for the help earlier"),
                (Role.BOT, "You're welcome! Is there anything else I can help with?"),
                (Role.USER, "No, that's all"),
                (Role.BOT, "Great, have a good day!"),
            ],
        )
        assert SilentChurnDetector().detect(conv) == []

    def test_too_short_conversation_not_flagged(self) -> None:
        conv = _make_conv(
            "short-1",
            [
                (Role.USER, "Quick question about shipping"),
                (Role.BOT, "Sure, what would you like to know?"),
            ],
        )
        assert SilentChurnDetector().detect(conv) == []

    def test_user_ended_with_substantive_message_not_flagged_by_default(self) -> None:
        """If the customer sent the last message and it wasn't trailing-off,
        we can't say they churned — they might still be typing."""
        conv = _make_conv(
            "live-1",
            [
                (Role.USER, "I need to change my shipping address"),
                (
                    Role.BOT,
                    "You can update your shipping address in Account Settings "
                    "under Addresses. Would you like me to walk you through it?",
                ),
                (Role.USER, "Yes please walk me through it step by step"),
            ],
        )
        assert SilentChurnDetector().detect(conv) == []


class TestTrailingOff:
    def test_trailing_off_user_still_flagged(self) -> None:
        conv = _make_conv(
            "trail-1",
            [
                (Role.USER, "How do I cancel my plan?"),
                (Role.BOT, "Go to Billing in your account and click Cancel."),
                (Role.USER, "The button doesn't work"),
                (
                    Role.BOT,
                    "Please try clearing your browser cache and cookies first, "
                    "then refresh the page and try again.",
                ),
                (Role.USER, "nvm"),
            ],
        )
        detections = SilentChurnDetector().detect(conv)
        assert len(detections) == 1


class TestConfidenceSignals:
    def test_question_at_end_boosts_confidence(self) -> None:
        with_q = _make_conv(
            "q-1",
            [
                (Role.USER, "What's the best plan for my business?"),
                (Role.BOT, "It depends on your usage. How many users do you have?"),
                (Role.USER, "About 20 users, how does the pricing scale?"),
                (
                    Role.BOT,
                    "Our business plan supports up to 50 users and includes "
                    "advanced analytics and priority support.",
                ),
            ],
        )
        without_q = _make_conv(
            "q-2",
            [
                (Role.USER, "Looking for info on business plans"),
                (Role.BOT, "Sure, how many users on your team?"),
                (Role.USER, "About 20 users"),
                (
                    Role.BOT,
                    "Our business plan supports up to 50 users and includes "
                    "advanced analytics and priority support.",
                ),
            ],
        )
        d_q = SilentChurnDetector().detect(with_q)
        d_no_q = SilentChurnDetector().detect(without_q)
        assert len(d_q) == 1
        assert len(d_no_q) == 1
        assert d_q[0].confidence > d_no_q[0].confidence


class TestGeneratedCorpus:
    def test_detects_silent_churn_from_generator(self) -> None:
        gen = ConversationGenerator(seed=7)
        convs = gen.silent_churn(n=5)
        det = SilentChurnDetector()
        for c in convs:
            assert det.detect(c), f"expected silent churn detection for {c.id}"

    def test_does_not_fire_on_healthy_corpus(self) -> None:
        gen = ConversationGenerator(seed=8)
        convs = gen.healthy(n=20)
        det = SilentChurnDetector()
        fps = [c for c in convs if det.detect(c)]
        assert fps == [], f"false positives on healthy conversations: {[c.id for c in fps]}"
