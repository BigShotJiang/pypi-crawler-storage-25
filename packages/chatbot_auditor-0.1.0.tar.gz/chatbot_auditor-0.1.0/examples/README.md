# Examples

Self-contained, runnable scripts covering the most common use cases. Each
script prints what it's doing and what the output means, so you can run it
once to see how the library works and then adapt it to your own data.

## Running the examples

From the project root:

```bash
uv sync --all-extras

# Each example is a plain Python script
uv run python examples/01_audit_json_file.py
uv run python examples/02_audit_csv_file.py
uv run python examples/03_custom_detector.py
uv run python examples/04_knowledge_bases.py
uv run python examples/05_embeddings_backend.py
```

If you installed via `pip install chatbot-auditor`:

```bash
python examples/01_audit_json_file.py
# ... etc
```

## What each example shows

| Script | Concept | Runtime |
|--------|---------|---------|
| [01_audit_json_file.py](01_audit_json_file.py) | End-to-end audit with the JSON adapter | <1 s |
| [02_audit_csv_file.py](02_audit_csv_file.py) | CSV adapter with flexible headers and custom role mapping | <1 s |
| [03_custom_detector.py](03_custom_detector.py) | Build and register a new `Detector` | <1 s |
| [04_knowledge_bases.py](04_knowledge_bases.py) | Wire `PolicyBase` and `FactBase` into fact-checking detectors | <1 s |
| [05_embeddings_backend.py](05_embeddings_backend.py) | Semantic similarity for paraphrased death loops | 5–10 s (model load) |

## Need more?

Longer walkthroughs are in the [tutorials section of the docs](https://HemantBK.github.io/chatbot-auditor/tutorials/audit-intercom/).
