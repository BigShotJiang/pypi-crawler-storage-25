# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Escalation Burial detector.

Escalation Burial is when a customer explicitly asks for a human agent and the
bot deflects them back into the automated flow rather than transferring. This
is often an intentional product choice by chatbot vendors — it suppresses
contact volume while destroying customer trust.

Detection strategy:
- Scan user messages for explicit escalation requests ("speak to a human",
  "real person", "human agent", "manager", etc.).
- For each request, look at the next bot/agent message:
    - If an agent joins the conversation → handled correctly.
    - If the bot acknowledges the transfer ("connecting you", "an agent will
      be with you shortly") → handled correctly.
    - Otherwise → burial.
- Multiple burials in the same conversation are combined into one detection
  with evidence for each.

This detector does not require an LLM or network access.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import ClassVar

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)

_DEFAULT_ESCALATION_KEYWORDS: tuple[str, ...] = (
    "speak to a person",
    "speak to someone",
    "speak to a human",
    "speak to a real",
    "talk to a person",
    "talk to someone",
    "talk to a human",
    "talk to a real",
    "real person",
    "real human",
    "real agent",
    "human agent",
    "live agent",
    "human representative",
    "connect me to a",
    "connect me with a",
    "transfer me to",
    "get me a human",
    "need a human",
    "want a human",
    "want to speak with an agent",
    "can i get an agent",
    "can i get a human",
    "human please",
    "agent please",
    "i want to talk to a manager",
    "speak to a manager",
    "speak with a supervisor",
    "supervisor please",
    "no more bot",
    "stop the bot",
    "just give me a human",
)

_DEFAULT_TRANSFER_CONFIRMATION_KEYWORDS: tuple[str, ...] = (
    "connecting you",
    "transferring you",
    "let me transfer",
    "i'll transfer",
    "i will transfer",
    "routing you",
    "one of our agents",
    "an agent will be with you",
    "an agent will assist",
    "a team member will",
    "a representative will",
    "a specialist will",
    "hang on while i connect",
    "please hold while i",
    "transferring to",
    "handing you off",
    "i'll get an agent",
    "i'll bring in",
    "escalating to",
    "passing you to",
)


class EscalationBurialDetector(Detector):
    """Detect when the customer asks for a human and the bot refuses to transfer."""

    name: ClassVar[str] = "escalation_burial"
    description: ClassVar[str] = (
        "Flags conversations where the customer explicitly requested a human agent "
        "but the bot deflected, continued the automated flow, or otherwise failed to "
        "transfer to a human."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.ESCALATION_BURIAL
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        escalation_keywords: Sequence[str] | None = None,
        transfer_confirmation_keywords: Sequence[str] | None = None,
    ) -> None:
        """Configure the detector.

        Args:
            escalation_keywords: Lowercase substrings indicating an explicit
                human-agent request in a user message.
            transfer_confirmation_keywords: Lowercase substrings indicating the
                bot acknowledged the transfer (i.e. did NOT bury the request).
        """
        self._escalation_keywords: tuple[str, ...] = tuple(
            kw.lower() for kw in (escalation_keywords or _DEFAULT_ESCALATION_KEYWORDS)
        )
        self._transfer_keywords: tuple[str, ...] = tuple(
            kw.lower()
            for kw in (transfer_confirmation_keywords or _DEFAULT_TRANSFER_CONFIRMATION_KEYWORDS)
        )

    def detect(self, conversation: Conversation) -> list[Detection]:
        buried_indices: list[int] = []
        matched_keywords: list[str] = []

        for i, msg in enumerate(conversation.messages):
            if msg.role != Role.USER:
                continue
            hit = self._escalation_match(msg.content)
            if hit is None:
                continue
            if not self._was_handled(conversation.messages, i):
                buried_indices.append(i)
                matched_keywords.append(hit)

        if not buried_indices:
            return []

        return [self._build_detection(conversation, buried_indices, matched_keywords)]

    def _escalation_match(self, content: str) -> str | None:
        lower = content.lower()
        for kw in self._escalation_keywords:
            if kw in lower:
                return kw
        return None

    def _was_handled(self, messages: Sequence[Message], request_idx: int) -> bool:
        """Return True if the escalation at `request_idx` was properly handled.

        Handled = the next BOT or AGENT message is either an agent joining
        the conversation, or a bot acknowledging the transfer.
        """
        for m in messages[request_idx + 1 :]:
            if m.role == Role.AGENT:
                return True
            if m.role == Role.BOT:
                lower = m.content.lower()
                return any(kw in lower for kw in self._transfer_keywords)
        return False

    def _build_detection(
        self,
        conversation: Conversation,
        buried_indices: Sequence[int],
        matched_keywords: Sequence[str],
    ) -> Detection:
        count = len(buried_indices)
        confidence = min(0.7 + 0.1 * (count - 1), 0.95)

        severity = (
            Severity.CRITICAL if count >= 3 else (Severity.HIGH if count >= 2 else Severity.MEDIUM)
        )

        evidence = [
            Evidence(
                message_index=idx,
                quote=_truncate(conversation.messages[idx].content, 120),
                note=f'Escalation request (matched: "{kw}")',
            )
            for idx, kw in zip(buried_indices, matched_keywords, strict=True)
        ]

        explanation = (
            f"Customer requested a human agent {count} time(s) but the bot did not "
            "acknowledge or perform a transfer."
        )

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="override",
            metadata={
                "burial_count": count,
                "first_request_index": buried_indices[0],
                "matched_keywords": list(matched_keywords),
            },
        )


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
