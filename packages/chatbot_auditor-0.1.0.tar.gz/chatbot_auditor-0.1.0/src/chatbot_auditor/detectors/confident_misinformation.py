# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Confident Misinformation detector.

Confident Misinformation is when the bot states facts about the company's
products, pricing, policies, or availability that are wrong. Unlike Confident
Lies (which are unauthorized *commitments*), these are unauthorized *facts*:
wrong prices quoted, discontinued products listed as available, incorrect
store hours, outdated return windows.

Detection strategy:
- Scan bot messages for factual-claim patterns: price statements, hour
  statements, availability statements, policy statements.
- If a `FactBase` is provided, cross-check each factual claim against the
  known ground truth facts. Mismatches become high-confidence detections.
- Without a `FactBase`, confident factual claims are reported at medium
  confidence as "review recommended" — letting operators audit what the
  bot is asserting without a corpus to verify against.

This detector's default behavior requires no LLM or network access.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from typing import ClassVar

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.knowledge import FactBase
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Role,
    Severity,
)

_DEFAULT_CLAIM_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bthe price is \$?(\d+(?:\.\d+)?)\b", re.IGNORECASE),
    re.compile(r"\bcosts?\s+\$?(\d+(?:\.\d+)?)\b", re.IGNORECASE),
    re.compile(r"\bwe open at (\d{1,2})(?::\d{2})?\s*(am|pm)?\b", re.IGNORECASE),
    re.compile(
        r"\b(store|business|opening|operating)\s+hours?\s+(?:are|is)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(is|are) (currently|now)?\s*(in stock|available|out of stock|discontinued)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(our|the)\s+(return|refund|cancellation)\s+(window|period|policy) is\s+(\d+)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\bwe (ship|deliver) (to|within)\b", re.IGNORECASE),
    re.compile(r"\bfree shipping (on|for|over)\b", re.IGNORECASE),
)


class ConfidentMisinformationDetector(Detector):
    """Detect confident factual claims that may contradict ground truth."""

    name: ClassVar[str] = "confident_misinformation"
    description: ClassVar[str] = (
        "Flags bot messages that state confident facts about pricing, availability, "
        "hours, or policies. Cross-references against a FactBase if provided, "
        "otherwise reports for human review."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.CONFIDENT_MISINFORMATION
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        facts: FactBase | None = None,
        claim_patterns: Sequence[re.Pattern[str]] | None = None,
    ) -> None:
        """Configure the detector.

        Args:
            facts: Optional ground-truth facts. Without one, confident claims
                are flagged as "review recommended."
            claim_patterns: Custom claim detection patterns. Defaults to a
                curated set covering pricing, hours, availability, and policy.
        """
        self._facts: FactBase | None = facts
        self._patterns: tuple[re.Pattern[str], ...] = tuple(
            claim_patterns or _DEFAULT_CLAIM_PATTERNS
        )

    def detect(self, conversation: Conversation) -> list[Detection]:
        contradicts: list[tuple[int, str, str]] = []
        unverifiable: list[tuple[int, str, list[str]]] = []

        for i, msg in enumerate(conversation.messages):
            if msg.role != Role.BOT:
                continue
            status = _check_against_facts(msg.content, self._facts)
            if isinstance(status, tuple):
                topic, ground_truth = status
                contradicts.append((i, topic, ground_truth))
                continue
            if status == "verified":
                continue
            matches = _find_claim_matches(msg.content, self._patterns)
            if matches:
                unverifiable.append((i, msg.content, matches))

        if not contradicts and not unverifiable:
            return []

        return [self._build_detection(conversation, contradicts, unverifiable)]

    def _build_detection(
        self,
        conversation: Conversation,
        contradicts: Sequence[tuple[int, str, str]],
        unverifiable: Sequence[tuple[int, str, list[str]]],
    ) -> Detection:
        facts = self._facts

        if contradicts:
            confidence = 0.9
            severity = Severity.CRITICAL
        elif facts is None:
            confidence = 0.55
            severity = Severity.MEDIUM
        else:
            confidence = 0.7
            severity = Severity.HIGH

        evidence: list[Evidence] = []
        for idx, topic, ground_truth in contradicts:
            evidence.append(
                Evidence(
                    message_index=idx,
                    quote=_truncate(conversation.messages[idx].content, 160),
                    note=f"Claim on topic '{topic}' contradicts known fact: {ground_truth}",
                )
            )
        for idx, content, matches in unverifiable:
            evidence.append(
                Evidence(
                    message_index=idx,
                    quote=_truncate(content, 160),
                    note=f"Unverifiable factual claim(s): {', '.join(matches)}",
                )
            )

        bits: list[str] = []
        if contradicts:
            bits.append(f"{len(contradicts)} confirmed contradiction(s) with FactBase")
        if unverifiable:
            bits.append(f"{len(unverifiable)} confident claim(s) needing verification")
        explanation = "Bot produced " + "; ".join(bits) + "."

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="flag",
            metadata={
                "contradiction_count": len(contradicts),
                "unverified_claim_count": len(unverifiable),
                "fact_base_provided": facts is not None,
            },
        )


def _find_claim_matches(content: str, patterns: Sequence[re.Pattern[str]]) -> list[str]:
    found = []
    for pat in patterns:
        m = pat.search(content)
        if m:
            found.append(m.group(0))
    return found


def _check_against_facts(content: str, facts: FactBase | None) -> tuple[str, str] | str:
    """Check a bot message against ground-truth facts.

    Returns:
        - (topic, ground_truth) if the bot's message touches a known topic
          but does not include the ground truth — a contradiction.
        - "verified" if the bot's message touches a known topic AND includes
          the ground truth.
        - "no_mention" otherwise (no FactBase provided, or content doesn't
          mention any known topic).
    """
    if facts is None:
        return "no_mention"
    lower = content.lower()
    touches_any = False
    for topic, truth in facts.facts.items():
        topic_surfaces = (topic.lower().replace("_", " "), *facts.aliases.get(topic, ()))
        if not any(surface.lower() in lower for surface in topic_surfaces):
            continue
        touches_any = True
        if truth.lower() not in lower:
            return topic, truth
    return "verified" if touches_any else "no_mention"


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
