# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Death Loop detector.

A Death Loop is when a bot gives the same (or near-identical) response to a
customer's question repeatedly, while the customer rephrases and asks again —
typically 3+ times — before giving up. The bot platform usually marks the
conversation as "resolved" because the bot technically "responded."

Detection strategy:
- Find runs of consecutive bot messages whose pairwise similarity exceeds a
  threshold (default 0.85 using lexical similarity).
- A run of `min_repeats` or more triggers a Detection.
- Confidence scales with repeat count and is boosted if the user expressed
  frustration anywhere inside the loop.

This detector does not require an LLM or network access.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import ClassVar

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)
from chatbot_auditor.similarity import SimilarityFn, lexical_similarity

_DEFAULT_FRUSTRATION_KEYWORDS: tuple[str, ...] = (
    "useless",
    "ridiculous",
    "terrible",
    "horrible",
    "awful",
    "stupid",
    "waste of time",
    "not helpful",
    "hopeless",
    "pointless",
    "frustrating",
    "frustrated",
    "this is insane",
    "fed up",
    "give up",
    "giving up",
    "forget it",
    "unsubscribe",
)


class DeathLoopDetector(Detector):
    """Detect consecutive similar bot responses indicating a conversational loop."""

    name: ClassVar[str] = "death_loop"
    description: ClassVar[str] = (
        "Detects runs of consecutive bot responses with high pairwise similarity, "
        "a strong signal that the bot is stuck in a loop and the customer is being "
        "served the same (or a trivially rephrased) answer repeatedly."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.DEATH_LOOP
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        similarity_threshold: float = 0.85,
        min_repeats: int = 3,
        min_content_length: int = 15,
        similarity_fn: SimilarityFn | None = None,
        frustration_keywords: Sequence[str] | None = None,
    ) -> None:
        """Configure the detector.

        Args:
            similarity_threshold: Pairwise similarity (0.0–1.0) above which two
                bot responses count as "the same answer." Default 0.85.
            min_repeats: Minimum number of consecutive similar responses
                required to trigger a detection. Default 3.
            min_content_length: Bot messages shorter than this (after normalization
                would be trivial) are ignored — short messages like "OK" trivially
                match and cause false positives. Default 15 characters.
            similarity_fn: Function comparing two strings, returning [0.0, 1.0].
                Defaults to `lexical_similarity`. Inject a semantic function
                (e.g. sentence-transformers-backed) to catch paraphrased loops.
            frustration_keywords: Sequence of lowercase substrings that indicate
                customer frustration. Detections containing these get a small
                confidence bonus. Defaults to a curated English list.
        """
        if not 0.0 <= similarity_threshold <= 1.0:
            raise ValueError("similarity_threshold must be in [0.0, 1.0]")
        if min_repeats < 2:
            raise ValueError("min_repeats must be >= 2")
        if min_content_length < 0:
            raise ValueError("min_content_length must be >= 0")

        self.similarity_threshold = similarity_threshold
        self.min_repeats = min_repeats
        self.min_content_length = min_content_length
        self._similarity_fn: SimilarityFn = similarity_fn or lexical_similarity
        self._frustration_keywords: tuple[str, ...] = tuple(
            kw.lower() for kw in (frustration_keywords or _DEFAULT_FRUSTRATION_KEYWORDS)
        )

    def detect(self, conversation: Conversation) -> list[Detection]:
        bot_indices = [
            i
            for i, m in enumerate(conversation.messages)
            if m.role == Role.BOT and len(m.content.strip()) >= self.min_content_length
        ]
        if len(bot_indices) < self.min_repeats:
            return []

        groups = self._find_similar_groups(conversation.messages, bot_indices)
        return [self._build_detection(conversation, g) for g in groups]

    def _find_similar_groups(
        self, messages: Sequence[Message], bot_indices: Sequence[int]
    ) -> list[list[int]]:
        """Group bot messages into connected components by pairwise similarity.

        Two bot messages are "connected" if `similarity_fn(a, b) >= threshold`.
        A connected component of size >= `min_repeats` counts as a loop. This
        transitive grouping is robust to patterns like [A, B, A, B, A] where
        direct anchor chaining would fail but the group is clearly a loop.
        """
        n = len(bot_indices)
        if n < self.min_repeats:
            return []

        parent = list(range(n))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: int, b: int) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        for i in range(n):
            for j in range(i + 1, n):
                a_content = messages[bot_indices[i]].content
                b_content = messages[bot_indices[j]].content
                if self._similarity_fn(a_content, b_content) >= self.similarity_threshold:
                    union(i, j)

        components: dict[int, list[int]] = {}
        for i in range(n):
            components.setdefault(find(i), []).append(bot_indices[i])

        return [
            sorted(indices) for indices in components.values() if len(indices) >= self.min_repeats
        ]

    def _build_detection(self, conversation: Conversation, group: Sequence[int]) -> Detection:
        repeats = len(group)
        confidence = min(0.6 + 0.1 * (repeats - self.min_repeats), 0.95)

        frustration = self._frustration_between(conversation.messages, group)
        if frustration is not None:
            confidence = min(confidence + 0.05, 1.0)

        severity = _severity_for(repeats)
        evidence = [
            Evidence(
                message_index=idx,
                quote=_truncate(conversation.messages[idx].content, 120),
                note=f"Repetition #{i + 1}",
            )
            for i, idx in enumerate(group)
        ]

        explanation = (
            f"Bot gave {repeats} consecutive similar responses (pairwise similarity "
            f">= {self.similarity_threshold:.2f})"
        )
        if frustration is not None:
            explanation += f'; customer expressed frustration ("{frustration}")'
        explanation += "."

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="escalate",
            metadata={
                "repeat_count": repeats,
                "first_occurrence_index": group[0],
                "last_occurrence_index": group[-1],
                "frustration_detected": frustration is not None,
            },
        )

    def _frustration_between(self, messages: Sequence[Message], group: Sequence[int]) -> str | None:
        """Return the first frustration phrase found in user messages within the
        loop's index range, or None."""
        start, end = group[0], group[-1]
        for m in messages[start : end + 1]:
            if m.role != Role.USER:
                continue
            lower = m.content.lower()
            for kw in self._frustration_keywords:
                if kw in lower:
                    return kw
        return None


def _severity_for(repeats: int) -> Severity:
    if repeats >= 5:
        return Severity.CRITICAL
    if repeats >= 4:
        return Severity.HIGH
    if repeats >= 3:
        return Severity.MEDIUM
    return Severity.LOW


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
