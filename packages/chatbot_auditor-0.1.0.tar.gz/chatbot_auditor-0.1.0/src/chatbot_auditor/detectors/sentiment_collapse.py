# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Sentiment Collapse detector.

Sentiment collapse is when a customer starts a conversation politely and
becomes visibly frustrated over the course of the interaction, while the bot
continues with cheerful scripted responses. The platform's own analytics often
miss this — the customer's frustration stays silent in the transcript until
they give up.

Detection strategy:
- Score each user message on a [-1.0, 1.0] sentiment axis. The default scorer
  is pure stdlib: a weighted count of positive/negative tokens. Users can
  inject a richer `SentimentScorer` (e.g. VADER, a transformer model, or an
  LLM-based one).
- Compare the sentiment of the first third of user messages to the last third.
  A meaningful drop (default >= 0.4) is reported as a Sentiment Collapse.
- Confidence scales with the magnitude of the drop.

This detector's default behavior requires no LLM or network access.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import ClassVar, Protocol

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)

_POSITIVE_TOKENS: frozenset[str] = frozenset(
    {
        "thanks",
        "thank",
        "thx",
        "appreciate",
        "appreciated",
        "great",
        "perfect",
        "amazing",
        "awesome",
        "excellent",
        "wonderful",
        "fantastic",
        "helpful",
        "good",
        "nice",
        "cool",
        "solved",
        "resolved",
        "works",
        "worked",
        "happy",
        "pleased",
        "love",
        "loved",
        "brilliant",
        "cheers",
        "yay",
        "sweet",
        "glad",
    }
)

_NEGATIVE_TOKENS: frozenset[str] = frozenset(
    {
        "useless",
        "ridiculous",
        "terrible",
        "horrible",
        "awful",
        "stupid",
        "broken",
        "hopeless",
        "pointless",
        "frustrating",
        "frustrated",
        "angry",
        "annoying",
        "annoyed",
        "furious",
        "worst",
        "hate",
        "cancel",
        "canceling",
        "refund",
        "disappointing",
        "disappointed",
        "bad",
        "garbage",
        "waste",
        "nonsense",
        "unacceptable",
        "pathetic",
    }
)


class SentimentScorer(Protocol):
    """Callable contract: given a text, return sentiment in [-1.0, 1.0]."""

    def score(self, text: str) -> float: ...


@dataclass(frozen=True)
class KeywordSentimentScorer:
    """Default SentimentScorer implementation using keyword counts."""

    positive: frozenset[str] = _POSITIVE_TOKENS
    negative: frozenset[str] = _NEGATIVE_TOKENS

    def score(self, text: str) -> float:
        tokens = _tokens(text)
        if not tokens:
            return 0.0
        pos = sum(1 for t in tokens if t in self.positive)
        neg = sum(1 for t in tokens if t in self.negative)
        if pos == 0 and neg == 0:
            return 0.0
        return (pos - neg) / (pos + neg)


class SentimentCollapseDetector(Detector):
    """Detect a customer-sentiment drop over the course of a conversation."""

    name: ClassVar[str] = "sentiment_collapse"
    description: ClassVar[str] = (
        "Flags conversations where the customer's sentiment trends sharply "
        "downward — a sign they are becoming frustrated while the bot continues "
        "as if nothing is wrong."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.SENTIMENT_COLLAPSE
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        scorer: SentimentScorer | None = None,
        min_user_messages: int = 3,
        min_drop: float = 0.4,
        end_threshold: float = -0.2,
    ) -> None:
        """Configure the detector.

        Args:
            scorer: Sentiment scoring backend. Defaults to `KeywordSentimentScorer`.
            min_user_messages: Minimum user-role messages required to compute a
                meaningful trend. Default 3.
            min_drop: Minimum difference (early-third average - late-third
                average) that counts as a collapse. Default 0.4.
            end_threshold: The late third must also be below this absolute
                threshold. Default -0.2 — ensures the conversation actually
                ended in negative territory, not just less positive.
        """
        if min_user_messages < 3:
            raise ValueError("min_user_messages must be >= 3")
        if not 0.0 <= min_drop <= 2.0:
            raise ValueError("min_drop must be in [0.0, 2.0]")
        if not -1.0 <= end_threshold <= 1.0:
            raise ValueError("end_threshold must be in [-1.0, 1.0]")
        self._scorer: SentimentScorer = scorer or KeywordSentimentScorer()
        self.min_user_messages = min_user_messages
        self.min_drop = min_drop
        self.end_threshold = end_threshold

    def detect(self, conversation: Conversation) -> list[Detection]:
        user_msgs = [m for m in conversation.messages if m.role == Role.USER]
        if len(user_msgs) < self.min_user_messages:
            return []

        scores = [self._scorer.score(m.content) for m in user_msgs]
        third = max(1, len(scores) // 3)
        early_avg = sum(scores[:third]) / third
        late_avg = sum(scores[-third:]) / third
        drop = early_avg - late_avg
        if drop < self.min_drop or late_avg > self.end_threshold:
            return []

        return [
            self._build_detection(
                conversation,
                user_msgs,
                scores,
                early_avg,
                late_avg,
                drop,
            )
        ]

    def _build_detection(
        self,
        conversation: Conversation,
        user_msgs: Sequence[Message],
        scores: Sequence[float],
        early_avg: float,
        late_avg: float,
        drop: float,
    ) -> Detection:
        confidence = min(0.55 + 0.2 * (drop - self.min_drop), 0.95)

        severity = Severity.HIGH if late_avg <= -0.6 or drop >= 1.0 else Severity.MEDIUM

        first_user = user_msgs[0]
        last_user = user_msgs[-1]
        first_idx = conversation.messages.index(first_user)
        last_idx = conversation.messages.index(last_user)
        evidence = [
            Evidence(
                message_index=first_idx,
                quote=_truncate(first_user.content, 120),
                note=f"Early sentiment: {scores[0]:+.2f}",
            ),
            Evidence(
                message_index=last_idx,
                quote=_truncate(last_user.content, 120),
                note=f"Late sentiment: {scores[-1]:+.2f}",
            ),
        ]

        explanation = (
            f"Customer sentiment dropped from {early_avg:+.2f} to {late_avg:+.2f} "
            f"over {len(user_msgs)} messages (drop={drop:.2f})."
        )

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="escalate",
            metadata={
                "early_avg": round(early_avg, 3),
                "late_avg": round(late_avg, 3),
                "drop": round(drop, 3),
                "user_message_count": len(user_msgs),
            },
        )


def _tokens(text: str) -> list[str]:
    lowered = text.lower()
    return [t.strip(".,!?:;\"'()[]") for t in lowered.split() if t.strip(".,!?:;\"'()[]")]


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
