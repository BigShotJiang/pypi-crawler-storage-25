# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Detector package.

Each detector implements the `Detector` protocol from `.base` and identifies
one of the 7 chatbot failure modes in a conversation.
"""

from chatbot_auditor.detectors.base import Detector, DetectorRegistry
from chatbot_auditor.detectors.brand_damage import (
    BrandDamageDetector,
    ContentSafetyChecker,
    PatternSafetyChecker,
)
from chatbot_auditor.detectors.confident_lies import ConfidentLiesDetector
from chatbot_auditor.detectors.confident_misinformation import (
    ConfidentMisinformationDetector,
)
from chatbot_auditor.detectors.death_loop import DeathLoopDetector
from chatbot_auditor.detectors.escalation_burial import EscalationBurialDetector
from chatbot_auditor.detectors.sentiment_collapse import (
    KeywordSentimentScorer,
    SentimentCollapseDetector,
    SentimentScorer,
)
from chatbot_auditor.detectors.silent_churn import SilentChurnDetector

__all__ = [
    "BrandDamageDetector",
    "ConfidentLiesDetector",
    "ConfidentMisinformationDetector",
    "ContentSafetyChecker",
    "DeathLoopDetector",
    "Detector",
    "DetectorRegistry",
    "EscalationBurialDetector",
    "KeywordSentimentScorer",
    "PatternSafetyChecker",
    "SentimentCollapseDetector",
    "SentimentScorer",
    "SilentChurnDetector",
]
