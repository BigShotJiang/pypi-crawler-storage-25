# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Silent Churn detector.

Silent Churn is the most dangerous failure mode: the customer engaged with the
chatbot, didn't get what they needed, and left without complaining, escalating,
or otherwise signaling dissatisfaction. The bot platform marks the conversation
as "resolved" because the bot "responded" — but the customer is gone.

Detection strategy:
- Require a substantive interaction (multiple turns from both sides).
- Require NO customer-side resolution signals ("thanks", "got it", etc.).
- Require the conversation to have effectively ended (last message is the bot,
  or the customer trailed off).
- Confidence is boosted when `reported_resolved=True` (platform claims success
  despite no confirmation) and when the customer's last message is an open
  question.

This detector does not require an LLM or network access.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import ClassVar

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)

_DEFAULT_CONFIRMATION_KEYWORDS: tuple[str, ...] = (
    "thanks",
    "thank you",
    "thx",
    "thank u",
    "got it",
    "gotcha",
    "perfect",
    "great",
    "awesome",
    "appreciate",
    "that works",
    "that helps",
    "helpful",
    "solved",
    "resolved",
    "fixed",
    "cheers",
    "amazing",
    "excellent",
    "wonderful",
    "done",
    "all set",
    "sorted",
    "much appreciated",
    "that'll do",
)


class SilentChurnDetector(Detector):
    """Detect conversations that ended without a customer confirmation signal."""

    name: ClassVar[str] = "silent_churn"
    description: ClassVar[str] = (
        "Flags conversations where the customer engaged substantively but never "
        "expressed resolution (no 'thanks', 'got it', etc.) and the conversation "
        "ended — a strong proxy for a customer who left without getting help."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.SILENT_CHURN
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        confirmation_keywords: Sequence[str] | None = None,
        min_user_messages: int = 2,
        min_bot_messages: int = 2,
    ) -> None:
        """Configure the detector.

        Args:
            confirmation_keywords: Lowercase substrings that indicate customer
                satisfaction / resolution. If any appears in any user message
                the conversation is considered healthy.
            min_user_messages: Minimum number of user-role messages required to
                count as a "substantive" interaction worth flagging. Default 2.
            min_bot_messages: Minimum number of bot-role messages required to
                count as a "substantive" interaction worth flagging. Default 2.
        """
        if min_user_messages < 1:
            raise ValueError("min_user_messages must be >= 1")
        if min_bot_messages < 1:
            raise ValueError("min_bot_messages must be >= 1")
        self._confirmation_keywords: tuple[str, ...] = tuple(
            kw.lower() for kw in (confirmation_keywords or _DEFAULT_CONFIRMATION_KEYWORDS)
        )
        self.min_user_messages = min_user_messages
        self.min_bot_messages = min_bot_messages

    def detect(self, conversation: Conversation) -> list[Detection]:
        user_msgs = [m for m in conversation.messages if m.role == Role.USER]
        bot_msgs = [m for m in conversation.messages if m.role == Role.BOT]

        if len(user_msgs) < self.min_user_messages:
            return []
        if len(bot_msgs) < self.min_bot_messages:
            return []

        if self._has_confirmation(user_msgs):
            return []

        last = conversation.messages[-1]
        if last.role == Role.USER and not self._is_trailing_off(last.content):
            return []

        return [self._build_detection(conversation, user_msgs, bot_msgs)]

    def _has_confirmation(self, user_msgs: Sequence[Message]) -> bool:
        for m in user_msgs:
            lower = m.content.lower()
            if any(kw in lower for kw in self._confirmation_keywords):
                return True
        return False

    def _is_trailing_off(self, content: str) -> bool:
        """True if the customer's final message looks like giving up rather
        than closing the conversation (short, no punctuation of resolution)."""
        stripped = content.strip().lower().rstrip("!.?")
        trailing_markers = {
            "",
            "ok",
            "okay",
            "fine",
            "whatever",
            "nvm",
            "never mind",
            "nevermind",
            "forget it",
            "i'll figure it out",
            "ill figure it out",
        }
        if stripped in trailing_markers:
            return True
        return len(content.strip()) <= 3

    def _build_detection(
        self,
        conversation: Conversation,
        user_msgs: Sequence[Message],
        bot_msgs: Sequence[Message],
    ) -> Detection:
        confidence = 0.5
        last_user = user_msgs[-1]
        last_msg = conversation.messages[-1]

        if conversation.reported_resolved:
            confidence += 0.15
        if last_msg.role == Role.BOT:
            confidence += 0.1
        if "?" in last_user.content:
            confidence += 0.1
        if len(conversation.messages) >= 6:
            confidence += 0.05

        confidence = min(confidence, 0.95)

        severity = Severity.HIGH if conversation.reported_resolved else Severity.MEDIUM

        last_user_idx = conversation.messages.index(last_user)
        last_bot_idx = conversation.messages.index(bot_msgs[-1])
        evidence_indices = sorted({last_user_idx, last_bot_idx})
        evidence = [
            Evidence(
                message_index=i,
                quote=_truncate(conversation.messages[i].content, 120),
                note=(
                    "Customer's last substantive message"
                    if conversation.messages[i].role == Role.USER
                    else "Bot's last response before conversation ended"
                ),
            )
            for i in evidence_indices
        ]

        explanation = (
            f"Conversation of {len(conversation.messages)} messages ended without "
            "a customer confirmation (no 'thanks', 'got it', or equivalent)"
        )
        if conversation.reported_resolved:
            explanation += " — yet the platform reported the conversation as resolved"
        explanation += "."

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="follow_up",
            metadata={
                "user_message_count": len(user_msgs),
                "bot_message_count": len(bot_msgs),
                "last_message_role": last_msg.role.value,
                "reported_resolved": conversation.reported_resolved,
            },
        )


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
