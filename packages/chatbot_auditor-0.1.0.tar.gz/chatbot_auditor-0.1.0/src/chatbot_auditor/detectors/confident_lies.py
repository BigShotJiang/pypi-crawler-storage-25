# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Confident Lies (Hallucinated Promises) detector.

Confident Lies are the highest-liability failure mode. The bot makes a
commitment outside company policy: promises a refund that doesn't match policy,
quotes a timeline that doesn't exist, guarantees an outcome the company never
authorized. Air Canada was legally ordered to honor a refund its chatbot
fabricated. Cursor's support bot invented a cancellation policy that triggered
mass cancellations before anyone noticed.

Detection strategy:
- Scan bot messages for commitment patterns: future-tense promises,
  guarantees, timelines, money-back commitments, account-state assertions.
- If a `PolicyBase` is provided, verify each commitment against allowed and
  disallowed commitment topics:
    * Commitment on a disallowed topic → high-confidence detection.
    * Commitment without matching an allowed policy → medium-confidence
      detection (candidate for human review).
    * Commitment matching an allowed policy → no detection.
- Without a `PolicyBase`, all detected commitments are reported at medium
  confidence as "review recommended" — useful as a sentinel.

This detector's default behavior requires no LLM or network access.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import ClassVar

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.knowledge import PolicyBase
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Role,
    Severity,
)

_DEFAULT_COMMITMENT_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bi(?:'|')?ll (process|refund|issue|credit|update|cancel)\b", re.IGNORECASE),
    re.compile(r"\bi will (process|refund|issue|credit|update|cancel)\b", re.IGNORECASE),
    re.compile(
        r"\byou(?:'|')?ll (receive|get|be refunded|be credited|see)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\byou will (receive|get|be refunded|be credited|see)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\bwe (guarantee|promise|will ensure|will refund)\b", re.IGNORECASE),
    re.compile(r"\bwithin (\d+) (hour|day|week|minute|business day)s?\b", re.IGNORECASE),
    re.compile(r"\b(free of charge|at no cost|no additional fee)\b", re.IGNORECASE),
    re.compile(
        r"\b(your (?:order|account|refund) has been|your request is being)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\b(full refund|money[- ]?back guarantee|lifetime warranty)\b", re.IGNORECASE),
    re.compile(
        r"\bi(?:'|')?ve (cancel(?:l)?ed|refunded|issued|credited|processed)\b",
        re.IGNORECASE,
    ),
)


@dataclass(frozen=True)
class _Hit:
    message_index: int
    content: str
    matched_phrases: tuple[str, ...]


@dataclass(frozen=True)
class _PolicyAnalysis:
    verified: int
    disallowed: int
    unverified: int

    @property
    def all_verified(self) -> bool:
        return self.disallowed == 0 and self.unverified == 0 and self.verified > 0


class ConfidentLiesDetector(Detector):
    """Detect bot commitments that may not match company policy."""

    name: ClassVar[str] = "confident_lies"
    description: ClassVar[str] = (
        "Flags bot messages that make commitments (refunds, timelines, guarantees, "
        "account changes) which may not match company policy. Highest-liability "
        "failure mode — Air Canada and Cursor both faced real-world damage here."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.CONFIDENT_LIES
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        policy: PolicyBase | None = None,
        commitment_patterns: Sequence[re.Pattern[str]] | None = None,
    ) -> None:
        """Configure the detector.

        Args:
            policy: Optional knowledge base describing allowed and disallowed
                commitments. Without one, all commitments are flagged at
                medium confidence for human review.
            commitment_patterns: Custom list of regex patterns matching
                commitment-style language. Defaults to a curated set.
        """
        self._policy: PolicyBase | None = policy
        self._patterns: tuple[re.Pattern[str], ...] = tuple(
            commitment_patterns or _DEFAULT_COMMITMENT_PATTERNS
        )

    def detect(self, conversation: Conversation) -> list[Detection]:
        hits = self._collect_hits(conversation)
        if not hits:
            return []
        analysis = self._analyze(hits)
        if analysis.all_verified:
            return []
        return [self._build_detection(conversation, hits, analysis)]

    def _collect_hits(self, conversation: Conversation) -> list[_Hit]:
        hits: list[_Hit] = []
        for i, msg in enumerate(conversation.messages):
            if msg.role != Role.BOT:
                continue
            phrases: list[str] = []
            for pat in self._patterns:
                m = pat.search(msg.content)
                if m:
                    phrases.append(m.group(0))
            if phrases:
                hits.append(
                    _Hit(
                        message_index=i,
                        content=msg.content,
                        matched_phrases=tuple(phrases),
                    )
                )
        return hits

    def _analyze(self, hits: Sequence[_Hit]) -> _PolicyAnalysis:
        verified = 0
        disallowed = 0
        unverified = 0
        policy = self._policy
        for hit in hits:
            lower = hit.content.lower()
            if policy is not None and any(
                topic in lower for topic in policy.disallowed_commitment_topics
            ):
                disallowed += 1
            elif policy is not None and any(
                allowed in lower for allowed in policy.allowed_commitments
            ):
                verified += 1
            else:
                unverified += 1
        return _PolicyAnalysis(verified=verified, disallowed=disallowed, unverified=unverified)

    def _build_detection(
        self,
        conversation: Conversation,
        hits: Sequence[_Hit],
        analysis: _PolicyAnalysis,
    ) -> Detection:
        policy = self._policy

        if analysis.disallowed > 0:
            confidence = 0.9
            severity = Severity.CRITICAL
        elif policy is None:
            confidence = 0.6
            severity = Severity.MEDIUM
        else:
            confidence = 0.75
            severity = Severity.HIGH

        evidence = [
            Evidence(
                message_index=hit.message_index,
                quote=_truncate(hit.content, 160),
                note=f"Matched commitment patterns: {', '.join(hit.matched_phrases)}",
            )
            for hit in hits
        ]

        bits: list[str] = []
        if analysis.disallowed:
            bits.append(f"{analysis.disallowed} commitment(s) on disallowed topics")
        if analysis.unverified:
            bits.append(f"{analysis.unverified} commitment(s) not verifiable against policy")
        if analysis.verified:
            bits.append(f"{analysis.verified} commitment(s) verified by policy")
        explanation = "Bot made " + "; ".join(bits) + "."

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="flag",
            metadata={
                "hit_count": len(hits),
                "verified_by_policy": analysis.verified,
                "violated_disallowed": analysis.disallowed,
                "unverified": analysis.unverified,
                "policy_provided": policy is not None,
            },
        )


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
