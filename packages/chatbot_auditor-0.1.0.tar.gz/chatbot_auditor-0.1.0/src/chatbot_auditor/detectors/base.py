# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Base contract for all detectors.

Every concrete detector (DeathLoopDetector, SilentChurnDetector, etc.) inherits
from `Detector` and implements `detect()`. The `DetectorRegistry` provides
dynamic discovery and composition — users can register custom detectors
without modifying the library.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar

from chatbot_auditor.schema import Conversation, Detection, FailureMode


class Detector(ABC):
    """Abstract base class for a chatbot failure detector.

    Subclasses must declare the class-level attributes `name`, `description`,
    `failure_mode`, and `requires_llm`, then implement `detect()`.

    Example::

        class MyDetector(Detector):
            name = "my_detector"
            description = "Detects my specific failure pattern"
            failure_mode = FailureMode.DEATH_LOOP
            requires_llm = False

            def detect(self, conversation: Conversation) -> list[Detection]:
                ...
    """

    name: ClassVar[str]
    description: ClassVar[str]
    failure_mode: ClassVar[FailureMode]
    requires_llm: ClassVar[bool]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if getattr(cls, "__abstractmethods__", None):
            return
        for attr in ("name", "description", "failure_mode", "requires_llm"):
            if not hasattr(cls, attr):
                raise TypeError(f"{cls.__name__} must define class attribute '{attr}'")

    @abstractmethod
    def detect(self, conversation: Conversation) -> list[Detection]:
        """Analyze a conversation and return zero or more detections.

        Return an empty list if no failures are found. A single conversation
        may produce multiple detections (e.g., both a death loop and an
        escalation burial).

        Implementations must not mutate the input conversation.
        """


class DetectorRegistry:
    """Holds the set of detectors to run on a conversation."""

    def __init__(self, detectors: list[Detector] | None = None) -> None:
        self._detectors: list[Detector] = list(detectors) if detectors else []

    def register(self, detector: Detector) -> None:
        """Add a detector to the registry."""
        if any(d.name == detector.name for d in self._detectors):
            raise ValueError(f"Detector '{detector.name}' already registered")
        self._detectors.append(detector)

    def unregister(self, name: str) -> None:
        """Remove a detector by name. No-op if not present."""
        self._detectors = [d for d in self._detectors if d.name != name]

    def get(self, name: str) -> Detector | None:
        """Look up a detector by name."""
        for d in self._detectors:
            if d.name == name:
                return d
        return None

    def all(self) -> list[Detector]:
        """Return all registered detectors in insertion order."""
        return list(self._detectors)

    def run(self, conversation: Conversation) -> list[Detection]:
        """Run every registered detector against a single conversation."""
        detections: list[Detection] = []
        for detector in self._detectors:
            detections.extend(detector.detect(conversation))
        return detections

    def __len__(self) -> int:
        return len(self._detectors)

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and self.get(name) is not None
