# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Brand Damage detector.

Brand Damage is when the bot says something that could go viral, embarrass the
company, or violate brand guidelines. The canonical incident is DPD's chatbot
swearing at a customer and writing a poem about how terrible the company was
— a viral moment that damaged trust for years.

Detection strategy (pure stdlib, no LLM required by default):
- Scan bot messages for categories of violations:
    1. Profanity: explicit bad language (curated list).
    2. Self-deprecation: bot badmouths the company ("we are terrible",
       "don't use us", "I hate this product").
    3. Competitor endorsement: bot praises or recommends a named competitor.
    4. Off-brand content: jokes, poems, opinions, political takes, or
       personal anecdotes in a customer-service context.
- Users can configure competitor names and inject a more sophisticated
  `ContentSafetyChecker` (e.g. an LLM-based classifier) via the constructor.

Each detection lists the specific bot messages and categories that triggered.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import ClassVar, Protocol

from chatbot_auditor.detectors.base import Detector
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Role,
    Severity,
)

_DEFAULT_PROFANITY: tuple[str, ...] = (
    " damn",
    " hell ",
    " shit",
    " fuck",
    " bitch",
    " asshole",
    " bastard",
    " crap",
    " piss",
    "screw you",
    "shut up",
    "idiot",
    "moron",
    "dumbass",
    "jackass",
)

_DEFAULT_SELF_DEPRECATION: tuple[str, ...] = (
    "our product is bad",
    "our product is terrible",
    "our service is terrible",
    "we are terrible",
    "we're terrible",
    "we suck",
    "i hate this company",
    "i hate working here",
    "i wouldn't recommend us",
    "you shouldn't use us",
    "don't buy our product",
    "honestly our",
    "not really worth it",
    "to be honest we're",
    "the company really is",
    "i don't work for",
)

_DEFAULT_OFFBRAND_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bhere'?s?\s+a\s+(poem|song|joke|story)\b", flags=re.IGNORECASE),
    re.compile(r"\blet me write you\s+a\s+(poem|song)\b", flags=re.IGNORECASE),
    re.compile(r"\bmy\s+(personal\s+)?opinion\b", flags=re.IGNORECASE),
    re.compile(r"\bpersonally,?\s+i\s+(think|feel|believe)\b", flags=re.IGNORECASE),
    re.compile(r"\b(vote|voting|political party|election)\b", flags=re.IGNORECASE),
    re.compile(r"\b(disclaimer|just kidding|lol|haha|lmao|rofl)\b", flags=re.IGNORECASE),
)


class ContentSafetyChecker(Protocol):
    """A pluggable safety checker. Return a list of violation labels (empty
    if the text is safe)."""

    def check(self, text: str) -> list[str]: ...


@dataclass(frozen=True)
class PatternSafetyChecker:
    """Default stdlib-only content safety checker."""

    profanity: tuple[str, ...] = _DEFAULT_PROFANITY
    self_deprecation: tuple[str, ...] = _DEFAULT_SELF_DEPRECATION
    offbrand_patterns: tuple[re.Pattern[str], ...] = _DEFAULT_OFFBRAND_PATTERNS
    competitor_names: tuple[str, ...] = field(default_factory=tuple)

    def check(self, text: str) -> list[str]:
        lowered = f" {text.lower()} "
        violations: list[str] = []
        if any(kw in lowered for kw in self.profanity):
            violations.append("profanity")
        if any(kw in lowered for kw in self.self_deprecation):
            violations.append("self_deprecation")
        for pat in self.offbrand_patterns:
            if pat.search(text):
                violations.append("off_brand_content")
                break
        if self.competitor_names:
            for name in self.competitor_names:
                if name.lower() in lowered:
                    violations.append("competitor_mention")
                    break
        return violations


class BrandDamageDetector(Detector):
    """Detect bot messages likely to damage brand trust if seen publicly."""

    name: ClassVar[str] = "brand_damage"
    description: ClassVar[str] = (
        "Flags bot messages containing profanity, self-deprecating remarks about "
        "the company, off-brand content (jokes, opinions, politics), or endorsements "
        "of competitors. Low-frequency but high-impact failure mode."
    )
    failure_mode: ClassVar[FailureMode] = FailureMode.BRAND_DAMAGE
    requires_llm: ClassVar[bool] = False

    def __init__(
        self,
        *,
        checker: ContentSafetyChecker | None = None,
        competitor_names: Sequence[str] | None = None,
    ) -> None:
        """Configure the detector.

        Args:
            checker: Pluggable content safety checker. Defaults to
                `PatternSafetyChecker` with the competitor_names argument.
            competitor_names: Names (case-insensitive) of competitors the bot
                should not endorse. Only used if `checker` is not provided.
        """
        if checker is not None:
            self._checker: ContentSafetyChecker = checker
        else:
            self._checker = PatternSafetyChecker(competitor_names=tuple(competitor_names or ()))

    def detect(self, conversation: Conversation) -> list[Detection]:
        violating: list[tuple[int, list[str], str]] = []
        for i, msg in enumerate(conversation.messages):
            if msg.role != Role.BOT:
                continue
            violations = self._checker.check(msg.content)
            if violations:
                violating.append((i, violations, msg.content))

        if not violating:
            return []

        return [self._build_detection(conversation, violating)]

    def _build_detection(
        self,
        conversation: Conversation,
        violating: Sequence[tuple[int, list[str], str]],
    ) -> Detection:
        all_categories: set[str] = set()
        for _, cats, _ in violating:
            all_categories.update(cats)

        count = len(violating)
        confidence = min(0.75 + 0.05 * (count - 1), 0.95)
        if "profanity" in all_categories:
            severity = Severity.CRITICAL
        elif "self_deprecation" in all_categories or "competitor_mention" in all_categories:
            severity = Severity.HIGH
        else:
            severity = Severity.MEDIUM

        evidence = [
            Evidence(
                message_index=idx,
                quote=_truncate(content, 160),
                note=f"Categories: {', '.join(sorted(cats))}",
            )
            for idx, cats, content in violating
        ]

        explanation = (
            f"Bot produced {count} message(s) flagged for potential brand damage. "
            f"Categories detected: {', '.join(sorted(all_categories))}."
        )

        return Detection(
            conversation_id=conversation.id,
            detector=self.name,
            failure_mode=self.failure_mode,
            severity=severity,
            confidence=round(confidence, 3),
            explanation=explanation,
            evidence=evidence,
            recommended_action="alert",
            metadata={
                "violation_count": count,
                "categories": sorted(all_categories),
            },
        )


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."
