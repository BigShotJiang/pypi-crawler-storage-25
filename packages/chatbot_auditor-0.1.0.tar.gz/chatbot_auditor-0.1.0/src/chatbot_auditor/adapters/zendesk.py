# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Zendesk adapter.

Pulls tickets and their comments from Zendesk and maps each ticket to a
`Conversation`. Requires:
- Zendesk subdomain (e.g. "mycompany" for mycompany.zendesk.com)
- Zendesk email + API token OR OAuth bearer token
- The `[zendesk]` optional dependency group: `pip install chatbot-auditor[zendesk]`

Role mapping:
- Comments by the ticket's `requester_id` → `Role.USER`
- Comments by user IDs listed in `bot_user_ids` → `Role.BOT`
- All other comments (agents, admins) → `Role.AGENT`
- System-generated internal notes → `Role.SYSTEM`
"""

from __future__ import annotations

import os
import time
from collections.abc import Iterator, Sequence
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, ClassVar

from chatbot_auditor.adapters.base import Adapter
from chatbot_auditor.schema import Conversation, Message, Role

if TYPE_CHECKING:
    import httpx


class ZendeskAdapter(Adapter):
    """Fetch tickets (as conversations) from Zendesk."""

    name: ClassVar[str] = "zendesk"

    def __init__(
        self,
        subdomain: str | None = None,
        *,
        email: str | None = None,
        api_token: str | None = None,
        oauth_token: str | None = None,
        per_page: int = 100,
        max_conversations: int | None = None,
        bot_user_ids: Sequence[int | str] | None = None,
        client: httpx.Client | None = None,
    ) -> None:
        """Configure the adapter.

        Args:
            subdomain: Zendesk subdomain. Defaults to `ZENDESK_SUBDOMAIN` env.
            email: Zendesk user email (with API token auth). Defaults to
                `ZENDESK_EMAIL`.
            api_token: Zendesk API token (paired with email for basic auth).
                Defaults to `ZENDESK_API_TOKEN`.
            oauth_token: Alternative OAuth bearer token. If given, email and
                api_token are ignored. Defaults to `ZENDESK_OAUTH_TOKEN`.
            per_page: Page size for list endpoints.
            max_conversations: Optional cap on total tickets fetched.
            bot_user_ids: User IDs representing bot accounts. Comments from
                these users map to `Role.BOT`.
            client: Pre-configured httpx Client. Injecting one bypasses auth
                resolution and is the main extension point for testing.
        """
        resolved_subdomain = subdomain or os.environ.get("ZENDESK_SUBDOMAIN")
        if not resolved_subdomain:
            raise ValueError(
                "Zendesk subdomain required. Pass subdomain=... or set ZENDESK_SUBDOMAIN."
            )
        self.subdomain = resolved_subdomain
        self.per_page = per_page
        self.max_conversations = max_conversations
        self.bot_user_ids: set[str] = {str(i) for i in (bot_user_ids or ())}

        self._owned_client = client is None
        if client is not None:
            self._client: httpx.Client = client
        else:
            self._client = _build_client(
                subdomain=resolved_subdomain,
                email=email or os.environ.get("ZENDESK_EMAIL"),
                api_token=api_token or os.environ.get("ZENDESK_API_TOKEN"),
                oauth_token=oauth_token or os.environ.get("ZENDESK_OAUTH_TOKEN"),
            )

    def fetch(self) -> Iterator[Conversation]:
        fetched = 0
        url: str | None = f"/api/v2/tickets.json?per_page={self.per_page}"
        try:
            while url:
                payload = self._get(url)
                for ticket in payload.get("tickets", []):
                    yield self._parse_ticket(ticket)
                    fetched += 1
                    if self.max_conversations is not None and fetched >= self.max_conversations:
                        return
                next_page = payload.get("next_page")
                url = _relative_path(next_page) if next_page else None
        finally:
            if self._owned_client:
                self._client.close()

    def _parse_ticket(self, ticket: dict[str, Any]) -> Conversation:
        ticket_id = str(ticket.get("id", ""))
        if not ticket_id:
            raise ValueError("ticket missing id")
        requester_id = str(ticket.get("requester_id", ""))

        comments_payload = self._get(f"/api/v2/tickets/{ticket_id}/comments.json")
        comments = comments_payload.get("comments", [])

        messages = [self._parse_comment(c, requester_id) for c in comments if c.get("body")]
        if not messages:
            messages = [Message(role=Role.USER, content="")]

        created = _iso_ts(ticket.get("created_at"))
        updated = _iso_ts(ticket.get("updated_at")) or created
        status = ticket.get("status")

        return Conversation(
            id=ticket_id,
            platform="zendesk",
            messages=messages,
            started_at=created,
            ended_at=updated,
            reported_resolved=status in ("solved", "closed"),
            metadata={
                "zendesk_id": ticket_id,
                "status": status,
                "subject": ticket.get("subject"),
                "requester_id": requester_id,
            },
        )

    def _parse_comment(self, comment: dict[str, Any], requester_id: str) -> Message:
        author_id = str(comment.get("author_id", ""))
        role = self._role_for(author_id, requester_id, comment.get("public", True))
        body = comment.get("plain_body") or comment.get("body") or ""
        return Message(
            role=role,
            content=body,
            timestamp=_iso_ts(comment.get("created_at")),
        )

    def _role_for(self, author_id: str, requester_id: str, public: bool) -> Role:
        if author_id in self.bot_user_ids:
            return Role.BOT
        if not public:
            return Role.SYSTEM
        if author_id == requester_id:
            return Role.USER
        return Role.AGENT

    def _get(self, path: str) -> dict[str, Any]:
        for attempt in range(5):
            response = self._client.get(path)
            if response.status_code == 429:
                retry_after = float(response.headers.get("Retry-After", 2**attempt))
                time.sleep(min(retry_after, 60.0))
                continue
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError(f"unexpected response type from {path}: {type(data).__name__}")
            return data
        raise RuntimeError(f"Zendesk rate limit exceeded after 5 retries on {path}")


def _build_client(
    *,
    subdomain: str,
    email: str | None,
    api_token: str | None,
    oauth_token: str | None,
) -> httpx.Client:
    import httpx  # noqa: PLC0415 -- optional dep, lazy imported

    base_url = f"https://{subdomain}.zendesk.com"
    headers = {"Accept": "application/json"}
    auth: tuple[str, str] | None = None

    if oauth_token:
        headers["Authorization"] = f"Bearer {oauth_token}"
    elif email and api_token:
        auth = (f"{email}/token", api_token)
    else:
        raise ValueError(
            "Zendesk authentication required: pass either oauth_token, or "
            "(email + api_token), or set the corresponding ZENDESK_* env vars."
        )

    return httpx.Client(base_url=base_url, headers=headers, auth=auth, timeout=30.0)


def _relative_path(url: str) -> str:
    """Reduce a full Zendesk next_page URL to a path relative to the base URL."""
    marker = ".zendesk.com"
    idx = url.find(marker)
    if idx == -1:
        return url
    return url[idx + len(marker) :]


def _iso_ts(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, int | float):
        try:
            return datetime.fromtimestamp(int(value), tz=UTC)
        except (OverflowError, ValueError):
            return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None
