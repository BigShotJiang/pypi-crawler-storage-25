# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Intercom adapter.

Pulls conversations from Intercom's REST API and maps them to the
`Conversation` schema. Requires:
- Intercom access token (env `INTERCOM_ACCESS_TOKEN` by default, or passed
  directly to the constructor).
- The `[intercom]` optional dependency group: `pip install chatbot-auditor[intercom]`

Known limitations:
- Uses the list endpoint (`GET /conversations`), which returns conversations
  with inlined parts. Very long conversations may have their parts truncated;
  to fetch full transcripts, call the per-conversation endpoint yourself.
- HTML bodies are stripped to plain text using a stdlib regex. For rich
  formatting, use your own renderer.
"""

from __future__ import annotations

import html as html_module
import os
import re
import time
from collections.abc import Iterator
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, ClassVar

from chatbot_auditor.adapters.base import Adapter
from chatbot_auditor.schema import Conversation, Message, Role

if TYPE_CHECKING:
    import httpx

_HTML_TAG_RE = re.compile(r"<[^>]+>")
_WHITESPACE_RE = re.compile(r"\s+")

_AUTHOR_ROLE_MAP: dict[str, Role] = {
    "user": Role.USER,
    "lead": Role.USER,
    "contact": Role.USER,
    "bot": Role.BOT,
    "admin": Role.AGENT,
    "team": Role.AGENT,
    "operator": Role.AGENT,
}


class IntercomAdapter(Adapter):
    """Fetch conversations from Intercom."""

    name: ClassVar[str] = "intercom"
    BASE_URL: ClassVar[str] = "https://api.intercom.io"
    API_VERSION: ClassVar[str] = "2.11"

    def __init__(
        self,
        access_token: str | None = None,
        *,
        per_page: int = 50,
        max_conversations: int | None = None,
        client: httpx.Client | None = None,
    ) -> None:
        """Configure the adapter.

        Args:
            access_token: Intercom access token. Defaults to the
                `INTERCOM_ACCESS_TOKEN` environment variable.
            per_page: Page size for the list endpoint. Max 150.
            max_conversations: Optional cap on total conversations fetched.
            client: Pre-configured httpx Client. If None, one is created with
                the access token and a 30-second timeout. Injecting a client
                is the main extension point for testing and custom networking.
        """
        token = (
            access_token if access_token is not None else os.environ.get("INTERCOM_ACCESS_TOKEN")
        )
        if not token:
            raise ValueError(
                "Intercom access token required. Pass access_token=... or set "
                "the INTERCOM_ACCESS_TOKEN environment variable."
            )
        self.access_token: str = token
        self.per_page = max(1, min(per_page, 150))
        self.max_conversations = max_conversations
        self._owned_client = client is None
        self._client: httpx.Client = client if client is not None else _build_client(token)

    def fetch(self) -> Iterator[Conversation]:
        fetched = 0
        starting_after: str | None = None
        try:
            while True:
                params: dict[str, Any] = {"per_page": self.per_page}
                if starting_after:
                    params["starting_after"] = starting_after
                payload = self._get("/conversations", params=params)
                conversations = payload.get("conversations", [])
                for raw in conversations:
                    yield _parse_conversation(raw)
                    fetched += 1
                    if self.max_conversations is not None and fetched >= self.max_conversations:
                        return
                pages = payload.get("pages", {}) or {}
                next_page = pages.get("next")
                starting_after = (
                    next_page.get("starting_after") if isinstance(next_page, dict) else None
                )
                if not starting_after:
                    return
        finally:
            if self._owned_client:
                self._client.close()

    def _get(self, path: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        for attempt in range(5):
            response = self._client.get(path, params=params)
            if response.status_code == 429:
                # Rate limited — honour Retry-After if given, else exponential backoff.
                retry_after = float(response.headers.get("Retry-After", 2**attempt))
                time.sleep(min(retry_after, 30.0))
                continue
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError(f"unexpected response type from {path}: {type(data).__name__}")
            return data
        raise RuntimeError(f"Intercom rate limit exceeded after 5 retries on {path}")


def _build_client(access_token: str) -> httpx.Client:
    import httpx  # noqa: PLC0415 -- optional dep, lazy imported

    return httpx.Client(
        base_url=IntercomAdapter.BASE_URL,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Intercom-Version": IntercomAdapter.API_VERSION,
        },
        timeout=30.0,
    )


def _parse_conversation(raw: dict[str, Any]) -> Conversation:
    conv_id = str(raw.get("id", ""))
    if not conv_id:
        raise ValueError("conversation missing id")
    created = _ts(raw.get("created_at"))
    updated = _ts(raw.get("updated_at")) or created

    messages: list[Message] = []

    source = raw.get("source") or {}
    source_body = source.get("body")
    if source_body:
        messages.append(
            Message(
                role=_role_from_author(source.get("author") or {}),
                content=_clean_html(source_body),
                timestamp=created,
            )
        )

    parts_wrap = raw.get("conversation_parts") or {}
    parts = parts_wrap.get("conversation_parts") or []
    for part in parts:
        body = part.get("body")
        if not body:
            continue
        if part.get("part_type") not in (None, "comment", "note"):
            continue
        messages.append(
            Message(
                role=_role_from_author(part.get("author") or {}),
                content=_clean_html(body),
                timestamp=_ts(part.get("created_at")),
            )
        )

    state = raw.get("state")
    return Conversation(
        id=conv_id,
        platform="intercom",
        messages=messages or [Message(role=Role.USER, content="")],
        started_at=created,
        ended_at=updated,
        reported_resolved=state in ("closed", "snoozed"),
        metadata={
            "intercom_id": conv_id,
            "state": state,
        },
    )


def _role_from_author(author: dict[str, Any]) -> Role:
    author_type = (author.get("type") or "").lower()
    return _AUTHOR_ROLE_MAP.get(author_type, Role.USER)


def _ts(value: Any) -> datetime | None:
    if value is None:
        return None
    try:
        return datetime.fromtimestamp(int(value), tz=UTC)
    except (TypeError, ValueError, OverflowError):
        return None


def _clean_html(body: str) -> str:
    text = _HTML_TAG_RE.sub(" ", body)
    text = html_module.unescape(text)
    return _WHITESPACE_RE.sub(" ", text).strip()
