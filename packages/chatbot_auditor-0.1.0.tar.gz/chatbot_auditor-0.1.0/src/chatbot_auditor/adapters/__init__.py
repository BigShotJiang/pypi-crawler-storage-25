# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Conversation source adapters.

Each adapter implements the `Adapter` protocol: `fetch()` yields
`Conversation` objects from a file, API, or custom source. Detectors are
source-agnostic — you can point any adapter at the same audit pipeline.
"""

from chatbot_auditor.adapters.base import Adapter
from chatbot_auditor.adapters.csv_adapter import CSVAdapter
from chatbot_auditor.adapters.json_adapter import JSONAdapter

__all__ = [
    "Adapter",
    "CSVAdapter",
    "JSONAdapter",
]
