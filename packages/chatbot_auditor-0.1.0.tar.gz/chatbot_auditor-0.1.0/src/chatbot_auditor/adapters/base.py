# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Base contract for adapters.

An `Adapter` is any source that can yield `Conversation` objects: a local file
(JSON, CSV), a third-party API (Intercom, Zendesk, Drift), a database query,
or a custom enterprise system. Detectors are data-source-agnostic — they only
care about the `Conversation` schema — so new adapters can be added without
touching any detector code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import ClassVar

from chatbot_auditor.schema import Conversation


class Adapter(ABC):
    """Abstract base class for a conversation data source."""

    name: ClassVar[str]

    @abstractmethod
    def fetch(self) -> Iterator[Conversation]:
        """Yield conversations from the source.

        Implementations should be lazy — yielding one conversation at a time —
        so users can stream large datasets without loading everything into
        memory. Wrap with `collect()` if a list is needed.
        """

    def collect(self) -> list[Conversation]:
        """Materialize all conversations from `fetch()` into a list."""
        return list(self.fetch())

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if getattr(cls, "__abstractmethods__", None):
            return
        if not hasattr(cls, "name"):
            raise TypeError(f"{cls.__name__} must define class attribute 'name'")
