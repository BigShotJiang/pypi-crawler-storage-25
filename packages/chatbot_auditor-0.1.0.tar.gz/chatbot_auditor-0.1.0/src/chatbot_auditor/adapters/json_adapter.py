# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""JSON file adapter.

Supports three input shapes:
- A single JSON object representing one `Conversation`
- A JSON array of `Conversation` objects
- JSON Lines (one `Conversation` per line, useful for large exports)

The shape is auto-detected by default; pass `format` explicitly to override.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import ClassVar, Literal

from chatbot_auditor.adapters.base import Adapter
from chatbot_auditor.schema import Conversation

JsonFormat = Literal["auto", "single", "list", "jsonl"]


class JSONAdapter(Adapter):
    """Read conversations from a JSON or JSONL file."""

    name: ClassVar[str] = "json"

    def __init__(
        self,
        path: Path | str,
        *,
        format: JsonFormat = "auto",  # noqa: A002
    ) -> None:
        self.path: Path = Path(path)
        self.format: JsonFormat = format

    def fetch(self) -> Iterator[Conversation]:
        content = self.path.read_text(encoding="utf-8")
        fmt = self._resolve_format(content) if self.format == "auto" else self.format

        if fmt == "jsonl":
            for line in content.splitlines():
                stripped = line.strip()
                if stripped:
                    yield Conversation.model_validate_json(stripped)
        elif fmt == "list":
            raw = json.loads(content)
            if not isinstance(raw, list):
                raise ValueError(f"{self.path}: expected JSON array but found {type(raw).__name__}")
            for item in raw:
                yield Conversation.model_validate(item)
        else:  # single
            yield Conversation.model_validate_json(content)

    @staticmethod
    def _resolve_format(content: str) -> JsonFormat:
        stripped = content.lstrip()
        if not stripped:
            raise ValueError("empty JSON input")
        first_char = stripped[0]
        if first_char == "[":
            return "list"
        if first_char == "{":
            # Heuristic: JSONL files have newline-separated top-level objects.
            # Look for `}\n{` (ignoring whitespace) in the first 10 KB.
            sample = stripped[:10_000]
            if "}\n{" in sample or "}\r\n{" in sample:
                return "jsonl"
            return "single"
        raise ValueError(f"unrecognized JSON input starting with {first_char!r}")
