# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""CSV file adapter.

Reads conversations from a CSV where each row is one message. Rows are grouped
into conversations by a shared `conversation_id`. Column names are
case-insensitive and flexible — `role`/`author`, `content`/`message`/`body`,
`timestamp`/`time`/`created_at`, and `conversation_id`/`conv_id`/`thread_id`
are all recognized.

Role values are mapped with sensible defaults — "customer" and "user" both
become `Role.USER`, "bot" and "chatbot" both become `Role.BOT`, etc. Custom
mappings can be supplied via the constructor.
"""

from __future__ import annotations

import csv
from collections.abc import Iterator, Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import ClassVar

from chatbot_auditor.adapters.base import Adapter
from chatbot_auditor.schema import Conversation, Message, Role

_ID_COLUMNS: tuple[str, ...] = ("conversation_id", "conv_id", "thread_id", "id")
_ROLE_COLUMNS: tuple[str, ...] = ("role", "author", "sender", "from")
_CONTENT_COLUMNS: tuple[str, ...] = ("content", "message", "body", "text")
_TIMESTAMP_COLUMNS: tuple[str, ...] = ("timestamp", "time", "created_at", "date")

_DEFAULT_ROLE_MAPPING: Mapping[str, Role] = {
    "user": Role.USER,
    "customer": Role.USER,
    "client": Role.USER,
    "end_user": Role.USER,
    "end-user": Role.USER,
    "visitor": Role.USER,
    "bot": Role.BOT,
    "chatbot": Role.BOT,
    "ai": Role.BOT,
    "assistant": Role.BOT,
    "fin": Role.BOT,
    "agent": Role.AGENT,
    "support": Role.AGENT,
    "human": Role.AGENT,
    "admin": Role.AGENT,
    "representative": Role.AGENT,
    "rep": Role.AGENT,
    "system": Role.SYSTEM,
}


class CSVAdapter(Adapter):
    """Read conversations from a CSV file (one row per message)."""

    name: ClassVar[str] = "csv"

    def __init__(
        self,
        path: Path | str,
        *,
        delimiter: str = ",",
        role_mapping: Mapping[str, Role] | None = None,
    ) -> None:
        self.path: Path = Path(path)
        self.delimiter = delimiter
        self.role_mapping: Mapping[str, Role] = (
            {k.lower(): v for k, v in role_mapping.items()}
            if role_mapping is not None
            else _DEFAULT_ROLE_MAPPING
        )

    def fetch(self) -> Iterator[Conversation]:
        grouped: dict[str, list[Message]] = {}
        order: list[str] = []

        with self.path.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh, delimiter=self.delimiter)
            if reader.fieldnames is None:
                return
            field_map = _normalize_headers(reader.fieldnames)

            for row_num, row in enumerate(reader, start=2):
                normalized = {k.strip().lower(): (v or "") for k, v in row.items() if k}
                conv_id = _first_match(normalized, _ID_COLUMNS)
                if not conv_id:
                    raise ValueError(
                        f"row {row_num}: missing conversation id column (any of {_ID_COLUMNS})"
                    )
                role_raw = _first_match(normalized, _ROLE_COLUMNS)
                if not role_raw:
                    raise ValueError(f"row {row_num}: missing role column (any of {_ROLE_COLUMNS})")
                content = _first_match(normalized, _CONTENT_COLUMNS) or ""
                timestamp_raw = _first_match(normalized, _TIMESTAMP_COLUMNS)

                role = self._resolve_role(role_raw, row_num)
                timestamp = _parse_timestamp(timestamp_raw) if timestamp_raw else None

                message = Message(role=role, content=content, timestamp=timestamp)
                if conv_id not in grouped:
                    grouped[conv_id] = []
                    order.append(conv_id)
                grouped[conv_id].append(message)

            # Touch to silence unused-variable warnings in minimal setups
            _ = field_map

        for conv_id in order:
            messages = grouped[conv_id]
            timestamps = [m.timestamp for m in messages if m.timestamp is not None]
            yield Conversation(
                id=conv_id,
                platform="csv",
                messages=messages,
                started_at=min(timestamps) if timestamps else None,
                ended_at=max(timestamps) if timestamps else None,
            )

    def _resolve_role(self, raw: str, row_num: int) -> Role:
        key = raw.strip().lower()
        role = self.role_mapping.get(key)
        if role is None:
            raise ValueError(
                f"row {row_num}: unknown role '{raw}'. Extend `role_mapping` in "
                f"the CSVAdapter constructor."
            )
        return role


def _normalize_headers(fields: Sequence[str]) -> dict[str, str]:
    return {f.strip().lower(): f for f in fields if f}


def _first_match(row: Mapping[str, str], candidates: tuple[str, ...]) -> str | None:
    for c in candidates:
        if c in row and row[c] != "":
            return row[c]
    return None


def _parse_timestamp(value: str) -> datetime | None:
    value = value.strip()
    if not value:
        return None
    try:
        if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
            return datetime.fromtimestamp(int(value), tz=UTC)
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, OverflowError):
        return None
