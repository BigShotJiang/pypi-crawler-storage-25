# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Command-line interface for chatbot-auditor."""

from __future__ import annotations

import json
import sys
from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer

from chatbot_auditor import __author__, __license__, __version__
from chatbot_auditor.adapters import Adapter, CSVAdapter, JSONAdapter
from chatbot_auditor.audit import audit
from chatbot_auditor.reporting import render_html, render_markdown
from chatbot_auditor.schema import Conversation, Detection

app = typer.Typer(
    name="chatbot-audit",
    help="Detect the 7 ways AI chatbots silently fail customers.",
    no_args_is_help=True,
    add_completion=False,
)


class OutputFormat(StrEnum):
    """Output formats supported by the CLI."""

    text = "text"
    json = "json"
    markdown = "markdown"
    html = "html"


@app.command()
def version() -> None:
    """Print version and attribution information."""
    typer.echo(f"chatbot-auditor {__version__}")
    typer.echo(f"Copyright 2026 {__author__}")
    typer.echo(f"License: {__license__}")


@app.command()
def analyze(
    path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
            help="JSON, JSONL, CSV, or TSV file of conversations.",
        ),
    ],
    output_format: Annotated[
        OutputFormat,
        typer.Option("--format", "-f", help="Output format."),
    ] = OutputFormat.text,
    output_path: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to a file instead of stdout."),
    ] = None,
) -> None:
    """Analyze conversations from a local file and produce an audit report.

    File type is auto-detected from the extension — `.json` / `.jsonl` uses
    JSONAdapter, `.csv` / `.tsv` uses CSVAdapter.
    """
    adapter = _build_file_adapter(path)
    _run_audit(adapter, output_format, output_path)


@app.command("analyze-intercom")
def analyze_intercom(
    access_token: Annotated[
        str | None,
        typer.Option(
            "--token",
            help="Intercom access token. Defaults to INTERCOM_ACCESS_TOKEN env.",
        ),
    ] = None,
    max_conversations: Annotated[
        int | None,
        typer.Option("--limit", help="Cap total conversations fetched."),
    ] = None,
    output_format: Annotated[
        OutputFormat,
        typer.Option("--format", "-f", help="Output format."),
    ] = OutputFormat.text,
    output_path: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to a file instead of stdout."),
    ] = None,
) -> None:
    """Audit conversations pulled directly from Intercom's API."""
    try:
        from chatbot_auditor.adapters.intercom import (  # noqa: PLC0415
            IntercomAdapter,
        )
    except ImportError as exc:  # pragma: no cover
        typer.echo(
            "error: httpx is required for Intercom integration. "
            "Install with `pip install chatbot-auditor[intercom]`.",
            err=True,
        )
        raise typer.Exit(code=2) from exc
    adapter = IntercomAdapter(
        access_token=access_token,
        max_conversations=max_conversations,
    )
    _run_audit(adapter, output_format, output_path)


@app.command("analyze-zendesk")
def analyze_zendesk(
    subdomain: Annotated[
        str | None,
        typer.Option("--subdomain", help="Zendesk subdomain. Defaults to ZENDESK_SUBDOMAIN."),
    ] = None,
    max_conversations: Annotated[
        int | None,
        typer.Option("--limit", help="Cap total tickets fetched."),
    ] = None,
    bot_user_ids: Annotated[
        str | None,
        typer.Option(
            "--bot-ids",
            help="Comma-separated Zendesk user IDs to treat as bots.",
        ),
    ] = None,
    output_format: Annotated[
        OutputFormat,
        typer.Option("--format", "-f", help="Output format."),
    ] = OutputFormat.text,
    output_path: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to a file instead of stdout."),
    ] = None,
) -> None:
    """Audit tickets pulled from Zendesk's API."""
    try:
        from chatbot_auditor.adapters.zendesk import (  # noqa: PLC0415
            ZendeskAdapter,
        )
    except ImportError as exc:  # pragma: no cover
        typer.echo(
            "error: httpx is required for Zendesk integration. "
            "Install with `pip install chatbot-auditor[zendesk]`.",
            err=True,
        )
        raise typer.Exit(code=2) from exc
    ids = [i.strip() for i in bot_user_ids.split(",")] if bot_user_ids else []
    adapter = ZendeskAdapter(
        subdomain=subdomain,
        max_conversations=max_conversations,
        bot_user_ids=ids,
    )
    _run_audit(adapter, output_format, output_path)


def _build_file_adapter(path: Path) -> Adapter:
    suffix = path.suffix.lower()
    if suffix in (".json", ".jsonl"):
        return JSONAdapter(path)
    if suffix in (".csv", ".tsv"):
        delim = "\t" if suffix == ".tsv" else ","
        return CSVAdapter(path, delimiter=delim)
    typer.echo(
        f"error: unsupported file type '{suffix}'. Expected .json, .jsonl, .csv, or .tsv.",
        err=True,
    )
    raise typer.Exit(code=2)


def _run_audit(
    adapter: Adapter,
    output_format: OutputFormat,
    output_path: Path | None,
) -> None:
    conversations: list[Conversation] = list(adapter.fetch())
    detections = audit(conversations)
    rendered = _render(output_format, conversations, detections)
    if output_path is not None:
        output_path.write_text(rendered, encoding="utf-8")
        typer.echo(
            f"Wrote {output_format.value} report to {output_path} ({len(detections)} detection(s))",
            err=True,
        )
    else:
        typer.echo(rendered)
    if detections:
        sys.exit(1)


def _render(
    output_format: OutputFormat,
    conversations: list[Conversation],
    detections: list[Detection],
) -> str:
    if output_format == OutputFormat.json:
        return json.dumps(
            [d.model_dump(mode="json") for d in detections],
            indent=2,
            default=str,
        )
    if output_format == OutputFormat.markdown:
        return render_markdown(conversations, detections)
    if output_format == OutputFormat.html:
        return render_html(conversations, detections)
    return _format_text(conversations, detections)


def _format_text(conversations: list[Conversation], detections: list[Detection]) -> str:
    lines: list[str] = [
        f"Analyzed {len(conversations)} conversation(s).",
        f"Detected {len(detections)} failure(s).",
    ]
    for d in detections:
        lines.append(
            f"  [{d.severity.value.upper():<8}] {d.detector:<24} "
            f"conv={d.conversation_id} conf={d.confidence:.2f}"
        )
        lines.append(f"      {d.explanation}")
    return "\n".join(lines)


if __name__ == "__main__":
    app()
