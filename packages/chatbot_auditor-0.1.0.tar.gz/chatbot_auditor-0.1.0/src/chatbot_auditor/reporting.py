# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Report generators for audit results.

Given a set of conversations and their detections, produces human-readable
summaries in Markdown or HTML. Designed for:

- CLI output (`chatbot-audit analyze --format markdown`)
- CI artifacts (e.g. an `audit.md` committed alongside code)
- Email-friendly HTML reports (self-contained, inline styles)

Reports include: overall summary metrics, breakdown by severity and by
detector, and detailed cards for the top-N worst conversations. No external
dependencies beyond the stdlib.
"""

from __future__ import annotations

import html
import textwrap
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import ClassVar

from chatbot_auditor.schema import Conversation, Detection, Severity

_SEVERITY_WEIGHT: dict[Severity, int] = {
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}


# ---------------------------------------------------------------------------
# Summary model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReportSummary:
    """Top-level metrics for an audit run."""

    generated_at: datetime
    total_conversations: int
    conversations_with_detections: int
    detections_total: int
    detections_by_severity: dict[str, int]
    detections_by_detector: dict[str, int]

    @property
    def pass_rate(self) -> float:
        """Fraction of conversations with zero detections (0.0–1.0)."""
        if self.total_conversations == 0:
            return 1.0
        clean = self.total_conversations - self.conversations_with_detections
        return clean / self.total_conversations


def build_summary(
    conversations: Sequence[Conversation], detections: Sequence[Detection]
) -> ReportSummary:
    """Compute a `ReportSummary` from already-materialized lists."""
    return ReportSummary(
        generated_at=datetime.now(UTC),
        total_conversations=len(conversations),
        conversations_with_detections=len({d.conversation_id for d in detections}),
        detections_total=len(detections),
        detections_by_severity=dict(Counter(d.severity.value for d in detections)),
        detections_by_detector=dict(Counter(d.detector for d in detections)),
    )


# ---------------------------------------------------------------------------
# Reporter base + concrete implementations
# ---------------------------------------------------------------------------


class Reporter(ABC):
    """Abstract base for audit report formatters."""

    name: ClassVar[str]

    @abstractmethod
    def render(
        self,
        conversations: Iterable[Conversation],
        detections: Iterable[Detection],
        *,
        title: str = "chatbot-auditor audit report",
        top_n: int = 20,
    ) -> str:
        """Return the rendered report as a string."""


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------


class MarkdownReporter(Reporter):
    """Render an audit report as GitHub-flavored Markdown."""

    name: ClassVar[str] = "markdown"

    def render(
        self,
        conversations: Iterable[Conversation],
        detections: Iterable[Detection],
        *,
        title: str = "chatbot-auditor audit report",
        top_n: int = 20,
    ) -> str:
        conv_list = list(conversations)
        det_list = list(detections)
        summary = build_summary(conv_list, det_list)
        det_by_conv = _group_by_conversation(det_list)
        ranked = _rank_conversations(conv_list, det_by_conv)

        lines: list[str] = []
        lines.append(f"# {title}")
        lines.append("")
        lines.append(f"_Generated: {summary.generated_at.isoformat(timespec='seconds')}_")
        lines.append("")
        lines.append(f"- **Conversations analyzed:** {summary.total_conversations}")
        lines.append(
            f"- **Conversations with detections:** {summary.conversations_with_detections}"
        )
        lines.append(f"- **Total detections:** {summary.detections_total}")
        lines.append(f"- **Pass rate:** {summary.pass_rate:.1%}")
        lines.append("")

        if summary.detections_by_severity:
            lines.append("## Detections by severity")
            lines.append("")
            lines.append("| Severity | Count |")
            lines.append("|----------|------:|")
            for sev in ("critical", "high", "medium", "low"):
                count = summary.detections_by_severity.get(sev, 0)
                if count:
                    lines.append(f"| {sev.capitalize()} | {count} |")
            lines.append("")

        if summary.detections_by_detector:
            lines.append("## Detections by detector")
            lines.append("")
            lines.append("| Detector | Count |")
            lines.append("|----------|------:|")
            for name, count in sorted(summary.detections_by_detector.items(), key=lambda x: -x[1]):
                lines.append(f"| `{name}` | {count} |")
            lines.append("")

        if ranked:
            shown = ranked[:top_n]
            suffix = f" (top {len(shown)} of {len(ranked)} flagged)" if len(ranked) > top_n else ""
            lines.append(f"## Flagged conversations{suffix}")
            lines.append("")
            for conv, conv_dets in shown:
                lines.extend(self._render_conversation_md(conv, conv_dets))
                lines.append("")

        lines.append("---")
        lines.append("")
        lines.append(
            "_Report generated by [chatbot-auditor]"
            "(https://github.com/HemantBK/chatbot-auditor). Copyright 2026 BK — "
            "Apache 2.0._"
        )
        return "\n".join(lines)

    def _render_conversation_md(self, conv: Conversation, dets: Sequence[Detection]) -> list[str]:
        lines: list[str] = []
        platform = conv.platform or "unknown"
        lines.append(f"### `{conv.id}` (platform: {platform})")
        lines.append("")
        duration = conv.duration
        duration_s = _format_duration(duration)
        reported = (
            "Yes"
            if conv.reported_resolved is True
            else ("No" if conv.reported_resolved is False else "Unknown")
        )
        lines.append(
            f"- **Messages:** {conv.message_count} · **Duration:** {duration_s} · "
            f"**Reported resolved:** {reported}"
        )
        lines.append(f"- **Detections:** {len(dets)} ({_severity_breakdown_inline(dets)})")
        lines.append("")
        for det in sorted(dets, key=_detection_sort_key, reverse=True):
            sev = det.severity.value.upper()
            lines.append(
                f"**[{sev}]** `{det.detector}` — {det.explanation} "
                f"_(confidence: {det.confidence:.2f})_"
            )
            for ev in det.evidence[:3]:
                quote = ev.quote.replace("\n", " ")
                lines.append(f"> {quote}")
            if len(det.evidence) > 3:
                lines.append(f"> _(+{len(det.evidence) - 3} more)_")
            lines.append("")
        return lines


def render_markdown(
    conversations: Iterable[Conversation],
    detections: Iterable[Detection],
    *,
    title: str = "chatbot-auditor audit report",
    top_n: int = 20,
) -> str:
    """Convenience wrapper around `MarkdownReporter.render`."""
    return MarkdownReporter().render(conversations, detections, title=title, top_n=top_n)


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------


_HTML_CSS = textwrap.dedent(
    """\
    :root {
      --fg: #1a202c; --fg-muted: #4a5568; --fg-subtle: #718096;
      --bg-soft: #f7fafc; --border: #e2e8f0;
      --accent: #4f46e5;
    }
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.55; max-width: 900px; margin: 2rem auto;
      padding: 0 1.25rem; color: var(--fg); background: white;
    }
    h1 {
      font-size: 1.85rem; margin-bottom: 0.4rem;
      border-bottom: 2px solid var(--accent); padding-bottom: 0.4rem;
    }
    h2 { font-size: 1.25rem; margin-top: 2.25rem; }
    h3 {
      font-size: 1.05rem; margin-top: 1.5rem;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
    p { margin: 0.5rem 0; }
    table { border-collapse: collapse; width: 100%; margin: 0.5rem 0; font-size: 0.95rem; }
    th, td { border: 1px solid var(--border); padding: 0.45rem 0.75rem; text-align: left; }
    th { background: var(--bg-soft); font-weight: 600; }
    td.num { text-align: right; font-variant-numeric: tabular-nums; }
    .summary-grid {
      display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 0.75rem; margin: 1.25rem 0;
    }
    .stat {
      background: var(--bg-soft); padding: 0.85rem 1rem; border-radius: 0.5rem;
      border-left: 3px solid var(--accent);
    }
    .stat-value { font-size: 1.5rem; font-weight: 700; font-variant-numeric: tabular-nums; }
    .stat-label {
      font-size: 0.75rem; color: var(--fg-subtle); text-transform: uppercase;
      letter-spacing: 0.06em; margin-top: 0.2rem;
    }
    .conv {
      border: 1px solid var(--border); border-radius: 0.5rem;
      padding: 1rem 1.15rem; margin: 1rem 0;
    }
    .conv-meta { color: var(--fg-muted); font-size: 0.88rem; margin-bottom: 0.6rem; }
    .sev {
      display: inline-block; padding: 2px 8px; border-radius: 4px;
      font-size: 0.72rem; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.06em; margin-right: 0.25rem;
    }
    .sev-critical { background: #fed7d7; color: #822727; }
    .sev-high     { background: #feebc8; color: #7b341e; }
    .sev-medium   { background: #fefcbf; color: #744210; }
    .sev-low      { background: #c6f6d5; color: #22543d; }
    .detector {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.85rem;
      background: var(--bg-soft); padding: 1px 6px; border-radius: 3px;
    }
    .quote {
      border-left: 3px solid var(--border); background: var(--bg-soft);
      padding: 0.45rem 0.75rem; margin: 0.4rem 0; font-size: 0.9rem;
      white-space: pre-wrap; color: var(--fg-muted);
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
    footer {
      margin-top: 2.5rem; padding-top: 1rem; border-top: 1px solid var(--border);
      color: var(--fg-subtle); font-size: 0.85rem; text-align: center;
    }
    a { color: var(--accent); }
    """
)


class HTMLReporter(Reporter):
    """Render an audit report as a self-contained HTML document."""

    name: ClassVar[str] = "html"

    def render(
        self,
        conversations: Iterable[Conversation],
        detections: Iterable[Detection],
        *,
        title: str = "chatbot-auditor audit report",
        top_n: int = 20,
    ) -> str:
        conv_list = list(conversations)
        det_list = list(detections)
        summary = build_summary(conv_list, det_list)
        det_by_conv = _group_by_conversation(det_list)
        ranked = _rank_conversations(conv_list, det_by_conv)

        parts: list[str] = []
        parts.append("<!DOCTYPE html>")
        parts.append('<html lang="en">')
        parts.append("<head>")
        parts.append('<meta charset="UTF-8">')
        parts.append('<meta name="viewport" content="width=device-width, initial-scale=1">')
        parts.append(f"<title>{html.escape(title)}</title>")
        parts.append(f"<style>{_HTML_CSS}</style>")
        parts.append("</head>")
        parts.append("<body>")
        parts.append(f"<h1>{html.escape(title)}</h1>")
        parts.append(
            f'<p class="conv-meta">Generated '
            f"{html.escape(summary.generated_at.isoformat(timespec='seconds'))}"
            "</p>"
        )

        # Summary stat cards
        parts.append('<section class="summary-grid">')
        parts.append(_stat_html("Conversations", summary.total_conversations))
        parts.append(_stat_html("Flagged", summary.conversations_with_detections))
        parts.append(_stat_html("Detections", summary.detections_total))
        parts.append(_stat_html("Pass rate", f"{summary.pass_rate:.1%}"))
        parts.append("</section>")

        if summary.detections_by_severity:
            parts.append("<h2>Detections by severity</h2>")
            parts.append("<table>")
            parts.append("<tr><th>Severity</th><th>Count</th></tr>")
            for sev in ("critical", "high", "medium", "low"):
                count = summary.detections_by_severity.get(sev, 0)
                if count:
                    parts.append(
                        f'<tr><td><span class="sev sev-{sev}">{sev}</span></td>'
                        f'<td class="num">{count}</td></tr>'
                    )
            parts.append("</table>")

        if summary.detections_by_detector:
            parts.append("<h2>Detections by detector</h2>")
            parts.append("<table>")
            parts.append("<tr><th>Detector</th><th>Count</th></tr>")
            for name, count in sorted(summary.detections_by_detector.items(), key=lambda x: -x[1]):
                parts.append(
                    f'<tr><td><span class="detector">{html.escape(name)}</span></td>'
                    f'<td class="num">{count}</td></tr>'
                )
            parts.append("</table>")

        if ranked:
            shown = ranked[:top_n]
            suffix = f" (top {len(shown)} of {len(ranked)} flagged)" if len(ranked) > top_n else ""
            parts.append(f"<h2>Flagged conversations{html.escape(suffix)}</h2>")
            for conv, conv_dets in shown:
                parts.append(self._render_conversation_html(conv, conv_dets))

        parts.append("<footer>")
        parts.append(
            'Generated by <a href="https://github.com/HemantBK/chatbot-auditor">chatbot-auditor</a>.'
            " Copyright 2026 BK &mdash; Apache 2.0."
        )
        parts.append("</footer>")
        parts.append("</body></html>")
        return "\n".join(parts)

    def _render_conversation_html(self, conv: Conversation, dets: Sequence[Detection]) -> str:
        platform = conv.platform or "unknown"
        duration_s = _format_duration(conv.duration)
        reported = (
            "yes"
            if conv.reported_resolved is True
            else ("no" if conv.reported_resolved is False else "unknown")
        )
        inner: list[str] = []
        inner.append('<article class="conv">')
        inner.append(
            f"<h3>{html.escape(conv.id)} "
            f'<span class="conv-meta">(platform: {html.escape(platform)})</span></h3>'
        )
        inner.append(
            f'<p class="conv-meta">Messages: {conv.message_count} · '
            f"Duration: {html.escape(duration_s)} · "
            f"Reported resolved: {reported} · "
            f"Detections: {len(dets)} "
            f"({_severity_breakdown_inline(dets)})</p>"
        )
        for det in sorted(dets, key=_detection_sort_key, reverse=True):
            sev = det.severity.value
            inner.append(
                "<p>"
                f'<span class="sev sev-{sev}">{sev}</span>'
                f'<span class="detector">{html.escape(det.detector)}</span>'
                f" — {html.escape(det.explanation)} "
                f"<em>(confidence: {det.confidence:.2f})</em>"
                "</p>"
            )
            for ev in det.evidence[:3]:
                inner.append(f'<div class="quote">{html.escape(ev.quote)}</div>')
            if len(det.evidence) > 3:
                inner.append(f'<p class="conv-meta">(+{len(det.evidence) - 3} more)</p>')
        inner.append("</article>")
        return "\n".join(inner)


def render_html(
    conversations: Iterable[Conversation],
    detections: Iterable[Detection],
    *,
    title: str = "chatbot-auditor audit report",
    top_n: int = 20,
) -> str:
    """Convenience wrapper around `HTMLReporter.render`."""
    return HTMLReporter().render(conversations, detections, title=title, top_n=top_n)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _group_by_conversation(
    detections: Sequence[Detection],
) -> dict[str, list[Detection]]:
    grouped: dict[str, list[Detection]] = defaultdict(list)
    for d in detections:
        grouped[d.conversation_id].append(d)
    return grouped


def _rank_conversations(
    conversations: Sequence[Conversation],
    det_by_conv: dict[str, list[Detection]],
) -> list[tuple[Conversation, list[Detection]]]:
    """Return (conversation, detections) pairs sorted by worst first.

    Only conversations with at least one detection are included.
    """
    ranked: list[tuple[Conversation, list[Detection], float]] = []
    for conv in conversations:
        dets = det_by_conv.get(conv.id)
        if not dets:
            continue
        score = sum(_SEVERITY_WEIGHT.get(d.severity, 0) * d.confidence for d in dets)
        ranked.append((conv, dets, score))
    ranked.sort(key=lambda x: x[2], reverse=True)
    return [(c, d) for c, d, _ in ranked]


def _detection_sort_key(d: Detection) -> tuple[int, float]:
    return (_SEVERITY_WEIGHT.get(d.severity, 0), d.confidence)


def _severity_breakdown_inline(dets: Sequence[Detection]) -> str:
    counts = Counter(d.severity.value for d in dets)
    order = ("critical", "high", "medium", "low")
    bits = [f"{counts[s]} {s}" for s in order if counts.get(s)]
    return ", ".join(bits)


def _format_duration(duration: object) -> str:
    if duration is None:
        return "unknown"
    total_seconds = int(getattr(duration, "total_seconds", lambda: 0)())
    if total_seconds <= 0:
        return "0s"
    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"


def _stat_html(label: str, value: object) -> str:
    return (
        '<div class="stat">'
        f'<div class="stat-value">{html.escape(str(value))}</div>'
        f'<div class="stat-label">{html.escape(label)}</div>'
        "</div>"
    )
