# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Optional ML / LLM backends for the pluggable detector interfaces.

Each backend lives in its own module and is imported lazily. Most require
extra dependencies installed via optional extras (`[llm]`, `[openai]`, …).
Users who only need the stdlib defaults never pay the import cost of
torch, transformers, or API SDKs.

Available backends:

- [`EmbeddingsSimilarity`][chatbot_auditor.backends.embeddings.EmbeddingsSimilarity]
  — semantic similarity backend for `DeathLoopDetector`, powered by
  sentence-transformers.
"""

__all__: list[str] = []
