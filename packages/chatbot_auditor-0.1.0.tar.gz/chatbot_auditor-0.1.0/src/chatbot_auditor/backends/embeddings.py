# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Semantic similarity backend using sentence-transformers.

Drop-in replacement for the lexical default used by `DeathLoopDetector`.
Catches paraphrased death loops — where the bot says the same thing in
different words — that the SequenceMatcher-based default cannot.

Installation:
    pip install "chatbot-auditor[llm]"

Usage:

```python
from chatbot_auditor import DeathLoopDetector
from chatbot_auditor.backends.embeddings import EmbeddingsSimilarity

similarity = EmbeddingsSimilarity()
detector = DeathLoopDetector(
    similarity_fn=similarity,
    similarity_threshold=0.75,  # cosine similarity — lower than lexical default
)
```

The default model (`all-MiniLM-L6-v2`) is ~90 MB and runs on CPU at
~1000 sentences/second on a modern laptop. Swap in any sentence-transformers
model for different accuracy/latency tradeoffs.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import numpy as np


class _Encoder(Protocol):
    """Minimal interface we need from a sentence-transformer-like encoder."""

    def encode(self, sentences: list[str], **kwargs: object) -> np.ndarray: ...


class EmbeddingsSimilarity:
    """Cosine-similarity backend using sentence-transformer embeddings.

    This class is callable — instances conform to the `SimilarityFn` protocol
    and can be passed directly to `DeathLoopDetector(similarity_fn=...)`.

    Embeddings are cached by text so repeated comparisons against the same
    response don't re-run the model.
    """

    DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

    def __init__(
        self,
        *,
        model_name: str | None = None,
        device: str | None = None,
        cache_size: int = 10_000,
        model: _Encoder | None = None,
    ) -> None:
        """Initialize the backend.

        Args:
            model_name: Any Hugging Face sentence-transformers model id.
                Defaults to `all-MiniLM-L6-v2` (90 MB, CPU-friendly).
            device: `"cpu"`, `"cuda"`, `"mps"`, etc. Passed to the model.
            cache_size: Maximum distinct texts to keep embeddings for. LRU.
            model: Pre-built encoder instance. If provided, `model_name` and
                `device` are ignored. Useful for tests and for reusing a
                single model across multiple detectors.
        """
        if cache_size < 0:
            raise ValueError("cache_size must be >= 0")
        self._encoder: _Encoder
        if model is not None:
            self._encoder = model
        else:
            from sentence_transformers import SentenceTransformer  # noqa: PLC0415

            self._encoder = SentenceTransformer(model_name or self.DEFAULT_MODEL, device=device)
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()
        self._cache_size = cache_size

    def __call__(self, a: str, b: str) -> float:
        """Return cosine similarity in [-1.0, 1.0] between two strings."""
        if not a or not b:
            return 0.0
        if a == b:
            return 1.0
        emb_a = self._embed(a)
        emb_b = self._embed(b)
        return _cosine(emb_a, emb_b)

    def _embed(self, text: str) -> np.ndarray:
        cached = self._cache.get(text)
        if cached is not None:
            self._cache.move_to_end(text)
            return cached
        emb: np.ndarray = self._encoder.encode([text], convert_to_numpy=True)[0]
        if self._cache_size > 0:
            self._cache[text] = emb
            if len(self._cache) > self._cache_size:
                self._cache.popitem(last=False)
        return emb


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    import numpy as np  # noqa: PLC0415

    norm_a = float(np.linalg.norm(a))
    norm_b = float(np.linalg.norm(b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))
