# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Similarity functions used by detectors.

The default `lexical_similarity` uses only the Python standard library — no
external dependencies — and is sufficient to catch most death-loop cases where
the bot repeats near-identical responses. Users who need semantic matching
can plug in a custom `SimilarityFn` (e.g., one backed by sentence-transformers)
via detector constructors.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from difflib import SequenceMatcher

SimilarityFn = Callable[[str, str], float]
"""A function taking two strings and returning similarity in [0.0, 1.0]."""

_WHITESPACE_RE = re.compile(r"\s+")
_NON_WORD_RE = re.compile(r"[^\w\s]", flags=re.UNICODE)


def normalize(text: str) -> str:
    """Normalize text for comparison: lowercase, strip punctuation, collapse whitespace."""
    text = text.lower()
    text = _NON_WORD_RE.sub(" ", text)
    return _WHITESPACE_RE.sub(" ", text).strip()


def lexical_similarity(a: str, b: str) -> float:
    """Return a lexical similarity score in [0.0, 1.0] between two strings.

    Uses `difflib.SequenceMatcher` over normalized text. Robust to casing,
    punctuation, and whitespace differences but not semantic equivalence.

    - `lexical_similarity("Hello!", "HELLO")` == 1.0
    - `lexical_similarity("Please check the FAQ", "Please check our FAQ")` ≈ 0.92
    - `lexical_similarity("refund request", "order status")` ≈ 0.24
    - `lexical_similarity("", "anything")` == 0.0
    """
    a_norm = normalize(a)
    b_norm = normalize(b)
    if not a_norm or not b_norm:
        return 0.0
    if a_norm == b_norm:
        return 1.0
    # SequenceMatcher's ratio is only *approximately* symmetric — its matching
    # algorithm uses the first argument as the anchor, so (a, b) and (b, a) can
    # produce slightly different results. We take the max of both directions so
    # `lexical_similarity(a, b) == lexical_similarity(b, a)` holds strictly.
    forward = SequenceMatcher(None, a_norm, b_norm, autojunk=False).ratio()
    backward = SequenceMatcher(None, b_norm, a_norm, autojunk=False).ratio()
    return max(forward, backward)


def token_jaccard(a: str, b: str) -> float:
    """Jaccard similarity over normalized tokens."""
    a_tokens = set(normalize(a).split())
    b_tokens = set(normalize(b).split())
    if not a_tokens or not b_tokens:
        return 0.0
    return len(a_tokens & b_tokens) / len(a_tokens | b_tokens)
