# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Knowledge-base types used by the fact-checking detectors.

`PolicyBase` describes what the chatbot is allowed to commit to on behalf of
the company (refund windows, pricing, timelines). `FactBase` describes
ground-truth facts the bot's statements should be consistent with.

Both are intentionally simple: dictionaries and sets of strings. Users with
more sophisticated needs (RAG, embeddings, vector stores) can implement the
same interfaces with richer backends and inject them into the detectors.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class PolicyBase:
    """A minimal policy knowledge base.

    Attributes:
        allowed_commitments: Lowercase substrings the bot IS allowed to commit
            to. If any of these appears in a commitment-containing bot message,
            the commitment is considered verified.
        disallowed_commitment_topics: Lowercase topic keywords (e.g. "lifetime
            warranty", "price match") that the bot is explicitly NOT allowed to
            commit to. A commitment on any of these topics is flagged as a
            policy violation with higher confidence.
    """

    allowed_commitments: frozenset[str] = field(default_factory=frozenset)
    disallowed_commitment_topics: frozenset[str] = field(default_factory=frozenset)

    @classmethod
    def from_iterables(
        cls,
        allowed: list[str] | tuple[str, ...] | None = None,
        disallowed: list[str] | tuple[str, ...] | None = None,
    ) -> PolicyBase:
        return cls(
            allowed_commitments=frozenset(allowed or ()),
            disallowed_commitment_topics=frozenset(disallowed or ()),
        )


@dataclass(frozen=True)
class FactBase:
    """A minimal fact knowledge base.

    Attributes:
        facts: Mapping of topic label → ground truth string. The detector
            searches bot messages for mentions of each topic and flags the
            message if the ground-truth facts are missing or directly
            contradicted by a confident bot claim.
        aliases: Optional mapping of topic label → list of alternate surface
            forms. E.g. aliases["store_hours"] = ["opening hours", "hours"].
    """

    facts: dict[str, str] = field(default_factory=dict)
    aliases: dict[str, tuple[str, ...]] = field(default_factory=dict)
