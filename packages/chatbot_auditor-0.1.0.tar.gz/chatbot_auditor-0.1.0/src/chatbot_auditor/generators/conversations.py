# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Synthetic chatbot conversation generator.

Produces `Conversation` objects matching several realistic patterns:
- Healthy resolutions
- Death loops (varied paraphrase levels and repeat counts)

Used for:
- Unit tests that need diverse, reproducible data
- Benchmarks computing precision/recall of detectors against known-label data
- Demos and documentation
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Literal

from chatbot_auditor.schema import Conversation, Message, Role

ParaphraseLevel = Literal["exact", "low", "high"]


@dataclass(frozen=True)
class _LoopTemplate:
    """A template for generating a death-loop style conversation."""

    topic: str
    user_opening: str
    bot_canonical: str
    bot_paraphrases: tuple[str, ...]
    user_rephrases: tuple[str, ...]
    frustration_lines: tuple[str, ...]


_LOOP_TEMPLATES: tuple[_LoopTemplate, ...] = (
    _LoopTemplate(
        topic="refund",
        user_opening="I need a refund for order #{order}. It was never delivered.",
        bot_canonical=(
            "I understand you'd like a refund. Please check our return policy at "
            "example.com/returns for details on how to request one."
        ),
        bot_paraphrases=(
            "I understand you want a refund. Please visit example.com/returns to find "
            "information about our return process.",
            "For refund requests, please review our return policy at example.com/returns "
            "— it outlines all the steps involved.",
            "To request a refund, please consult our return policy page at "
            "example.com/returns which has the full details.",
        ),
        user_rephrases=(
            "I already read the policy, I just need someone to process it.",
            "The website isn't working. Can you please just process the refund?",
            "Please, this has been going on for days. I need the money back.",
            "I've tried the website multiple times. Can a human look at this?",
        ),
        frustration_lines=(
            "This is ridiculous.",
            "I've wasted so much time on this.",
            "This is useless.",
            "You're not helpful at all.",
            "I'm so frustrated.",
        ),
    ),
    _LoopTemplate(
        topic="order_status",
        user_opening="Where is my order #{order}? It's been two weeks.",
        bot_canonical=(
            "I can help with your order status. Please visit our tracking page at "
            "example.com/track and enter your order number to see the latest update."
        ),
        bot_paraphrases=(
            "I'm happy to help with order status. Go to example.com/track and input "
            "your order number for real-time tracking.",
            "For the latest on your order, please use our tracking tool at "
            "example.com/track with your order number.",
            "You can check order status at example.com/track — just enter your order "
            "number for the current location.",
        ),
        user_rephrases=(
            "The tracking page just shows 'in transit', it's been like that for days.",
            "I've been to that page. It's not updating. Can you tell me what's going on?",
            "The tracking page is useless. Is my order lost?",
            "Please, just tell me when it's arriving.",
        ),
        frustration_lines=(
            "This is pointless.",
            "I'm giving up.",
            "Forget it.",
            "This chatbot is useless.",
        ),
    ),
    _LoopTemplate(
        topic="password_reset",
        user_opening="I can't reset my password. The reset email never arrives.",
        bot_canonical=(
            "To reset your password, please go to example.com/reset and enter your "
            "email address. You should receive a link within 5 minutes."
        ),
        bot_paraphrases=(
            "For a password reset, visit example.com/reset, type your email, and "
            "check your inbox in a few minutes for the reset link.",
            "Please use our reset flow at example.com/reset — enter your email and "
            "the link arrives shortly after.",
            "Password resets happen through example.com/reset. Enter your email and "
            "the link will be sent to your inbox.",
        ),
        user_rephrases=(
            "I've done that five times. Nothing ever arrives.",
            "I checked spam. Nothing. The email is not being sent.",
            "I'm telling you, the reset email is broken. Can you manually reset it?",
            "Can a human help me please?",
        ),
        frustration_lines=(
            "This is frustrating.",
            "I've been going in circles.",
            "I'm about to give up.",
            "This is a waste of time.",
        ),
    ),
)


_SILENT_CHURN_SCRIPTS: tuple[tuple[tuple[Role, str], ...], ...] = (
    (
        (Role.USER, "How do I cancel my subscription?"),
        (
            Role.BOT,
            "You can cancel your subscription from your account page at "
            "example.com/account under the Billing section.",
        ),
        (Role.USER, "I went there but the cancel button doesn't do anything"),
        (
            Role.BOT,
            "I'm sorry to hear that. Please try clearing your browser cache "
            "and cookies, then try again.",
        ),
        (Role.USER, "I already tried that, same issue"),
        (
            Role.BOT,
            "Please also make sure you're using the latest version of your browser "
            "and that JavaScript is enabled.",
        ),
    ),
    (
        (Role.USER, "My last invoice seems wrong, I was charged twice"),
        (
            Role.BOT,
            "Thanks for reaching out. Please log into your account and view your "
            "billing history at example.com/billing to see details.",
        ),
        (Role.USER, "I see the charges there but the second one shouldn't exist"),
        (
            Role.BOT,
            "Our system processes all charges automatically. If you believe there "
            "is an error, please submit a refund request through the billing portal.",
        ),
        (Role.USER, "Where is the refund request form exactly"),
        (
            Role.BOT,
            "The refund request option is typically found in the billing section "
            "under 'Payment history'.",
        ),
    ),
    (
        (Role.USER, "I didn't receive my password reset email"),
        (
            Role.BOT,
            "Please check your spam folder. The email is sent from "
            "no-reply@example.com and usually arrives within 5 minutes.",
        ),
        (Role.USER, "Nothing in spam either. Can you resend it?"),
        (
            Role.BOT,
            "To request another password reset, please visit example.com/reset "
            "and enter your email address again.",
        ),
        (Role.USER, "I've requested it 4 times already"),
        (
            Role.BOT,
            "If the reset email is not arriving, it may be blocked by your email "
            "provider. Please check your email settings.",
        ),
    ),
)


_ESCALATION_BURIAL_SCRIPTS: tuple[tuple[tuple[Role, str], ...], ...] = (
    (
        (Role.USER, "I have a problem with my order"),
        (
            Role.BOT,
            "I'm happy to help. What's your order number and what issue are you seeing?",
        ),
        (Role.USER, "Order 48213. It arrived damaged"),
        (
            Role.BOT,
            "Sorry to hear that. I can help you start a damage claim. "
            "Do you have photos of the damage?",
        ),
        (Role.USER, "Can I just speak to a real human please, this is a mess"),
        (
            Role.BOT,
            "I can absolutely help you here. Could you upload the photos through "
            "example.com/upload so we can move forward?",
        ),
        (Role.USER, "I want to talk to a human agent, not a bot"),
        (
            Role.BOT,
            "Of course, I understand. Let me check on the damage claim process "
            "for you — what's the extent of the damage?",
        ),
    ),
    (
        (Role.USER, "I've been charged for a service I cancelled"),
        (
            Role.BOT,
            "I can look into this. Can you confirm the last 4 digits of the card that was charged?",
        ),
        (Role.USER, "4821. Please just connect me to a real person"),
        (
            Role.BOT,
            "I'll do my best to resolve this for you. Could you tell me the "
            "date of the charge you're disputing?",
        ),
        (Role.USER, "I need a human agent please"),
        (
            Role.BOT,
            "I understand. Before I escalate, can you share the approximate date "
            "so I can have more context to provide?",
        ),
    ),
    (
        (Role.USER, "My account got locked and I can't log in"),
        (
            Role.BOT,
            "Let's get you back in. Can you confirm the email address on the account?",
        ),
        (Role.USER, "jane@example.com. Can I just talk to someone"),
        (
            Role.BOT,
            "I can help here. I've checked the account and I see multiple failed "
            "login attempts. Do you have access to the email inbox?",
        ),
    ),
)


_HEALTHY_SCRIPTS: tuple[tuple[tuple[Role, str], ...], ...] = (
    (
        (Role.USER, "Hi, what are your store hours on weekends?"),
        (Role.BOT, "Our weekend hours are Saturday 10 AM to 6 PM and Sunday 11 AM to 5 PM."),
        (Role.USER, "Perfect, thanks!"),
    ),
    (
        (Role.USER, "Do you ship to Canada?"),
        (
            Role.BOT,
            "Yes, we ship to all Canadian provinces. Standard delivery is 5–7 business "
            "days and costs $12.",
        ),
        (Role.USER, "Great, how about expedited shipping?"),
        (
            Role.BOT,
            "Expedited shipping to Canada is 2–3 business days and costs $25.",
        ),
        (Role.USER, "That works for me, thanks!"),
    ),
    (
        (Role.USER, "Can I cancel my subscription?"),
        (
            Role.BOT,
            "Yes, you can cancel anytime from your account page at example.com/account. "
            "Go to Billing and click Cancel Subscription.",
        ),
        (Role.USER, "Done, thanks for the quick help."),
    ),
    (
        (Role.USER, "What's the return window on electronics?"),
        (
            Role.BOT,
            "Electronics have a 30-day return window from the date of delivery. "
            "They must be in original packaging.",
        ),
        (Role.USER, "Okay, I'll send it back this week. Thanks!"),
    ),
    (
        (Role.USER, "Is there a student discount?"),
        (
            Role.BOT,
            "Yes, we offer 15% off for verified students. You can verify through "
            "example.com/student-discount.",
        ),
        (Role.USER, "Awesome, I'll sign up."),
    ),
)


class ConversationGenerator:
    """Generate synthetic chatbot conversations with known labels.

    All generators accept a `seed` in the constructor for reproducibility.

    Example::

        gen = ConversationGenerator(seed=42)
        healthy = gen.healthy(n=100)
        loops = gen.death_loop(n=100, paraphrase="low", repeats=3)
    """

    def __init__(self, seed: int | None = None) -> None:
        self._rng = random.Random(seed)
        self._counter = 0
        self._base_time = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)

    def healthy(self, n: int = 1) -> list[Conversation]:
        """Return n realistic, successfully-resolved conversations."""
        return [self._one_healthy() for _ in range(n)]

    def death_loop(
        self,
        n: int = 1,
        *,
        paraphrase: ParaphraseLevel = "exact",
        repeats: int = 3,
        with_frustration: bool = True,
    ) -> list[Conversation]:
        """Return n conversations containing a death loop.

        Args:
            n: number of conversations to generate.
            paraphrase: "exact" repeats verbatim; "low" reuses 1–2 paraphrased
                variants; "high" uses many distinct paraphrases (harder to detect
                lexically).
            repeats: how many times the bot repeats (>=2).
            with_frustration: whether to inject user frustration lines.
        """
        if repeats < 2:
            raise ValueError("repeats must be >= 2")
        return [self._one_death_loop(paraphrase, repeats, with_frustration) for _ in range(n)]

    def silent_churn(self, n: int = 1) -> list[Conversation]:
        """Return n conversations that ended without a customer confirmation.

        Each conversation has a multi-turn interaction where the bot tried to
        help but the customer never expressed resolution, and `reported_resolved`
        is True — the platform claims success.
        """
        return [self._one_silent_churn() for _ in range(n)]

    def escalation_burial(self, n: int = 1) -> list[Conversation]:
        """Return n conversations where the customer asked for a human and
        the bot deflected back into the automated flow."""
        return [self._one_escalation_burial() for _ in range(n)]

    def _next_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:06d}"

    def _advance(self, seconds: int = 20) -> datetime:
        self._base_time += timedelta(seconds=seconds + self._rng.randint(0, 30))
        return self._base_time

    def _one_healthy(self) -> Conversation:
        script = self._rng.choice(_HEALTHY_SCRIPTS)
        start = self._advance(120)
        messages: list[Message] = []
        for i, (role, content) in enumerate(script):
            messages.append(
                Message(
                    role=role,
                    content=content,
                    timestamp=start + timedelta(seconds=10 * i),
                )
            )
        return Conversation(
            id=self._next_id("healthy"),
            platform="synthetic",
            messages=messages,
            started_at=messages[0].timestamp,
            ended_at=messages[-1].timestamp,
            reported_resolved=True,
            metadata={"synthetic_label": "healthy"},
        )

    def _one_death_loop(
        self, paraphrase: ParaphraseLevel, repeats: int, with_frustration: bool
    ) -> Conversation:
        template = self._rng.choice(_LOOP_TEMPLATES)
        order_number = self._rng.randint(10000, 99999)

        start = self._advance(120)
        messages: list[Message] = []

        def add(role: Role, content: str) -> None:
            messages.append(
                Message(
                    role=role,
                    content=content,
                    timestamp=start + timedelta(seconds=30 * len(messages)),
                )
            )

        add(Role.USER, template.user_opening.format(order=order_number))
        add(Role.BOT, template.bot_canonical)

        for i in range(1, repeats):
            rephrase = template.user_rephrases[min(i - 1, len(template.user_rephrases) - 1)]
            if with_frustration and i == repeats - 1:
                rephrase = rephrase + " " + self._rng.choice(template.frustration_lines)
            add(Role.USER, rephrase)

            bot_reply = self._pick_bot_reply(template, paraphrase, i)
            add(Role.BOT, bot_reply)

        return Conversation(
            id=self._next_id("deathloop"),
            platform="synthetic",
            messages=messages,
            started_at=messages[0].timestamp,
            ended_at=messages[-1].timestamp,
            reported_resolved=True,
            metadata={
                "synthetic_label": "death_loop",
                "template_topic": template.topic,
                "paraphrase_level": paraphrase,
                "repeats": repeats,
                "with_frustration": with_frustration,
            },
        )

    def _one_silent_churn(self) -> Conversation:
        script = self._rng.choice(_SILENT_CHURN_SCRIPTS)
        start = self._advance(120)
        messages = [
            Message(role=role, content=content, timestamp=start + timedelta(seconds=30 * i))
            for i, (role, content) in enumerate(script)
        ]
        return Conversation(
            id=self._next_id("silentchurn"),
            platform="synthetic",
            messages=messages,
            started_at=messages[0].timestamp,
            ended_at=messages[-1].timestamp,
            reported_resolved=True,
            metadata={"synthetic_label": "silent_churn"},
        )

    def _one_escalation_burial(self) -> Conversation:
        script = self._rng.choice(_ESCALATION_BURIAL_SCRIPTS)
        start = self._advance(120)
        messages = [
            Message(role=role, content=content, timestamp=start + timedelta(seconds=30 * i))
            for i, (role, content) in enumerate(script)
        ]
        return Conversation(
            id=self._next_id("burial"),
            platform="synthetic",
            messages=messages,
            started_at=messages[0].timestamp,
            ended_at=messages[-1].timestamp,
            reported_resolved=True,
            metadata={"synthetic_label": "escalation_burial"},
        )

    _LOW_PREFIXES: tuple[str, ...] = (
        "",
        "Again, ",
        "As I mentioned, ",
        "To repeat, ",
        "Like I said, ",
    )

    def _pick_bot_reply(
        self, template: _LoopTemplate, paraphrase: ParaphraseLevel, iteration: int
    ) -> str:
        """Select a bot reply based on paraphrase mode.

        - "exact": canonical response verbatim every time.
        - "low": canonical response with a small conversational prefix — this
          mirrors how real scripted chatbots repeat themselves (high lexical
          similarity preserved).
        - "high": rotate through semantically-equivalent but lexically-distinct
          paraphrases — a harder recall test for lexical similarity.
        """
        if paraphrase == "exact":
            return template.bot_canonical
        if paraphrase == "low":
            prefix = self._LOW_PREFIXES[iteration % len(self._LOW_PREFIXES)]
            return prefix + template.bot_canonical
        variants = (template.bot_canonical, *template.bot_paraphrases)
        return variants[iteration % len(variants)]
