# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""chatbot-auditor: Detect the 7 ways AI chatbots silently fail customers.

Original author: BK.
Preserve the NOTICE file and these source headers when redistributing.
"""

from chatbot_auditor.adapters import Adapter, CSVAdapter, JSONAdapter
from chatbot_auditor.audit import audit, default_registry
from chatbot_auditor.detectors import (
    BrandDamageDetector,
    ConfidentLiesDetector,
    ConfidentMisinformationDetector,
    ContentSafetyChecker,
    DeathLoopDetector,
    Detector,
    DetectorRegistry,
    EscalationBurialDetector,
    KeywordSentimentScorer,
    PatternSafetyChecker,
    SentimentCollapseDetector,
    SentimentScorer,
    SilentChurnDetector,
)
from chatbot_auditor.knowledge import FactBase, PolicyBase
from chatbot_auditor.schema import (
    Conversation,
    Detection,
    Evidence,
    FailureMode,
    Message,
    Role,
    Severity,
)

__version__ = "0.1.0"
__author__ = "BK"
__license__ = "Apache-2.0"

__all__ = [
    "Adapter",
    "BrandDamageDetector",
    "CSVAdapter",
    "ConfidentLiesDetector",
    "ConfidentMisinformationDetector",
    "ContentSafetyChecker",
    "Conversation",
    "DeathLoopDetector",
    "Detection",
    "Detector",
    "DetectorRegistry",
    "EscalationBurialDetector",
    "Evidence",
    "FactBase",
    "FailureMode",
    "JSONAdapter",
    "KeywordSentimentScorer",
    "Message",
    "PatternSafetyChecker",
    "PolicyBase",
    "Role",
    "SentimentCollapseDetector",
    "SentimentScorer",
    "Severity",
    "SilentChurnDetector",
    "__author__",
    "__license__",
    "__version__",
    "audit",
    "default_registry",
]
