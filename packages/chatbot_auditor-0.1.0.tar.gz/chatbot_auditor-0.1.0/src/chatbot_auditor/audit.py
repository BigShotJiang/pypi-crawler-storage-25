# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""High-level audit entry point.

`audit()` is the one-call API: feed it conversations, get back detections.
`default_registry()` returns the set of production-ready detectors enabled
by default in the current version.
"""

from __future__ import annotations

from collections.abc import Iterable

from chatbot_auditor.detectors import (
    BrandDamageDetector,
    DeathLoopDetector,
    DetectorRegistry,
    EscalationBurialDetector,
    SentimentCollapseDetector,
    SilentChurnDetector,
)
from chatbot_auditor.schema import Conversation, Detection


def default_registry() -> DetectorRegistry:
    """Return a `DetectorRegistry` with all production-ready detectors enabled.

    This includes every detector that works out-of-the-box without
    configuration: death-loop, silent-churn, escalation-burial,
    sentiment-collapse, and brand-damage.

    `ConfidentLiesDetector` and `ConfidentMisinformationDetector` require a
    `PolicyBase` or `FactBase` to be genuinely useful and are NOT included
    in the default registry. Add them manually with your own knowledge base:

        from chatbot_auditor import default_registry, ConfidentLiesDetector
        from chatbot_auditor.knowledge import PolicyBase

        registry = default_registry()
        registry.register(ConfidentLiesDetector(policy=PolicyBase(...)))
    """
    return DetectorRegistry(
        [
            DeathLoopDetector(),
            SilentChurnDetector(),
            EscalationBurialDetector(),
            SentimentCollapseDetector(),
            BrandDamageDetector(),
        ]
    )


def audit(
    conversations: Iterable[Conversation],
    detectors: DetectorRegistry | None = None,
) -> list[Detection]:
    """Run all registered detectors against a batch of conversations.

    Args:
        conversations: Any iterable of `Conversation` objects.
        detectors: Optional custom registry. If None, uses `default_registry()`.

    Returns:
        A flat list of `Detection` objects across all conversations.
    """
    registry = detectors if detectors is not None else default_registry()
    results: list[Detection] = []
    for conv in conversations:
        results.extend(registry.run(conv))
    return results
