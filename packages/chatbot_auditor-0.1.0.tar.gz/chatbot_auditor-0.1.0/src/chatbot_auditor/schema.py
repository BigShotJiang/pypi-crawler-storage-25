# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""Core data model for chatbot-auditor.

Every detector consumes `Conversation` objects and emits `Detection` objects.
This schema is the contract between adapters (data sources) and detectors.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, computed_field, field_validator


class Role(StrEnum):
    """Who sent a given message."""

    USER = "user"
    BOT = "bot"
    AGENT = "agent"
    SYSTEM = "system"


class FailureMode(StrEnum):
    """The 7 chatbot failure modes this library detects."""

    DEATH_LOOP = "death_loop"
    SILENT_CHURN = "silent_churn"
    ESCALATION_BURIAL = "escalation_burial"
    SENTIMENT_COLLAPSE = "sentiment_collapse"
    CONFIDENT_LIES = "confident_lies"
    BRAND_DAMAGE = "brand_damage"
    CONFIDENT_MISINFORMATION = "confident_misinformation"


class Severity(StrEnum):
    """How bad is the detected failure."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Message(BaseModel):
    """A single message in a conversation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    role: Role
    content: str = Field(..., min_length=0)
    timestamp: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("content")
    @classmethod
    def _content_must_be_str(cls, v: str) -> str:
        if not isinstance(v, str):
            raise TypeError("content must be a string")
        return v


class Conversation(BaseModel):
    """A full chatbot conversation with one or more messages."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., min_length=1)
    messages: list[Message] = Field(..., min_length=1)
    started_at: datetime | None = None
    ended_at: datetime | None = None
    reported_resolved: bool | None = Field(
        default=None,
        description="What the chatbot platform reported — the thing we verify.",
    )
    platform: str | None = Field(
        default=None,
        description="Source platform: intercom, zendesk, drift, freshdesk, custom.",
    )
    metadata: dict[str, Any] = Field(default_factory=dict)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def duration(self) -> timedelta | None:
        """Time from first to last message, if timestamps are available."""
        if self.started_at and self.ended_at:
            return self.ended_at - self.started_at
        timestamps = [m.timestamp for m in self.messages if m.timestamp is not None]
        if len(timestamps) < 2:
            return None
        return max(timestamps) - min(timestamps)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def message_count(self) -> int:
        """Total number of messages."""
        return len(self.messages)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def user_messages(self) -> list[Message]:
        """Messages from the end user."""
        return [m for m in self.messages if m.role == Role.USER]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def bot_messages(self) -> list[Message]:
        """Messages from the chatbot."""
        return [m for m in self.messages if m.role == Role.BOT]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def agent_messages(self) -> list[Message]:
        """Messages from a human agent."""
        return [m for m in self.messages if m.role == Role.AGENT]


class Evidence(BaseModel):
    """A specific piece of evidence supporting a detection."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    message_index: int = Field(..., ge=0)
    quote: str = Field(..., min_length=1)
    note: str | None = None


class Detection(BaseModel):
    """A single detected failure in a conversation."""

    model_config = ConfigDict(extra="forbid")

    conversation_id: str = Field(..., min_length=1)
    detector: str = Field(
        ...,
        min_length=1,
        description="Name of the detector that produced this (e.g. 'death_loop').",
    )
    failure_mode: FailureMode
    severity: Severity
    confidence: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="0.0–1.0 confidence this is a real failure, not a false positive.",
    )
    explanation: str = Field(
        ...,
        min_length=1,
        description="Human-readable summary suitable for a dashboard or report.",
    )
    evidence: list[Evidence] = Field(default_factory=list)
    recommended_action: (
        Literal["escalate", "flag", "alert", "override", "follow_up", "prevent"] | None
    ) = None
    metadata: dict[str, Any] = Field(default_factory=dict)
