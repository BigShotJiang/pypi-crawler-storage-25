# Copyright 2026 BK
# SPDX-License-Identifier: Apache-2.0
"""FastAPI server exposing chatbot-auditor as an HTTP service.

Endpoints:

- `GET  /healthz`    — liveness probe
- `GET  /readyz`     — readiness probe (detectors initialized)
- `GET  /version`    — version + attribution
- `GET  /detectors`  — enumerate the active detector registry
- `POST /analyze`    — accept conversations, return detections

Auth: optional bearer token. Set `CHATBOT_AUDITOR_API_KEYS` to a
comma-separated list of valid keys to enable auth on `/analyze`. When unset,
the endpoint accepts unauthenticated requests (useful for local / internal
deployments behind another gateway).

Requires the `[server]` optional dependency group:
    pip install "chatbot-auditor[server]"
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field

from chatbot_auditor import (
    __author__,
    __license__,
    __version__,
    audit,
    default_registry,
)
from chatbot_auditor.detectors import DetectorRegistry
from chatbot_auditor.schema import Conversation, Detection

_MAX_CONVERSATIONS = int(os.environ.get("CHATBOT_AUDITOR_MAX_CONVERSATIONS_PER_REQUEST", "1000"))


class AnalyzeRequest(BaseModel):
    """Request body for `POST /analyze`."""

    conversations: list[Conversation] = Field(..., min_length=1)
    detector_names: list[str] | None = Field(
        default=None,
        description=(
            "Optional subset of detectors to run by name. If omitted, the full "
            "default registry runs."
        ),
    )


class AnalyzeResponse(BaseModel):
    """Response body for `POST /analyze`."""

    total_conversations: int
    total_detections: int
    detections: list[Detection]


class DetectorInfo(BaseModel):
    """Metadata about a registered detector."""

    name: str
    description: str
    failure_mode: str
    requires_llm: bool


class DetectorListResponse(BaseModel):
    detectors: list[DetectorInfo]


class VersionResponse(BaseModel):
    version: str
    author: str
    license: str


class HealthResponse(BaseModel):
    status: str


class ReadyResponse(BaseModel):
    status: str
    detector_count: int


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Build the detector registry once at startup, reuse across requests."""
    app.state.registry = default_registry()
    yield


def _require_api_key(
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    """Authorize the request if `CHATBOT_AUDITOR_API_KEYS` is set."""
    configured = os.environ.get("CHATBOT_AUDITOR_API_KEYS", "").strip()
    if not configured:
        return
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing bearer token")
    presented = authorization.removeprefix("Bearer ").strip()
    valid = {k.strip() for k in configured.split(",") if k.strip()}
    if presented not in valid:
        raise HTTPException(status_code=401, detail="invalid api key")


app = FastAPI(
    title="chatbot-auditor",
    description="Detect the 7 ways AI chatbots silently fail customers.",
    version=__version__,
    lifespan=lifespan,
)


@app.get("/healthz", response_model=HealthResponse)
async def healthz() -> HealthResponse:
    """Liveness probe — always returns 200 if the process is running."""
    return HealthResponse(status="ok")


@app.get("/readyz", response_model=ReadyResponse)
async def readyz(request: Request) -> ReadyResponse:
    """Readiness probe — verifies the detector registry is initialized."""
    registry: DetectorRegistry = request.app.state.registry
    return ReadyResponse(status="ready", detector_count=len(registry))


@app.get("/version", response_model=VersionResponse)
async def version() -> VersionResponse:
    return VersionResponse(version=__version__, author=__author__, license=__license__)


@app.get("/detectors", response_model=DetectorListResponse)
async def list_detectors(request: Request) -> DetectorListResponse:
    registry: DetectorRegistry = request.app.state.registry
    return DetectorListResponse(
        detectors=[
            DetectorInfo(
                name=d.name,
                description=d.description,
                failure_mode=d.failure_mode.value,
                requires_llm=d.requires_llm,
            )
            for d in registry.all()
        ]
    )


@app.post(
    "/analyze",
    response_model=AnalyzeResponse,
    dependencies=[Depends(_require_api_key)],
)
async def analyze(payload: AnalyzeRequest, request: Request) -> AnalyzeResponse:
    """Audit a batch of conversations, return the detections."""
    if len(payload.conversations) > _MAX_CONVERSATIONS:
        raise HTTPException(
            status_code=413,
            detail=(
                f"too many conversations: {len(payload.conversations)} > "
                f"{_MAX_CONVERSATIONS}. Raise "
                "CHATBOT_AUDITOR_MAX_CONVERSATIONS_PER_REQUEST to increase."
            ),
        )
    registry: DetectorRegistry = request.app.state.registry
    if payload.detector_names:
        filtered = [d for d in registry.all() if d.name in payload.detector_names]
        unknown = set(payload.detector_names) - {d.name for d in filtered}
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"unknown detector(s): {sorted(unknown)}",
            )
        registry = DetectorRegistry(filtered)

    detections = audit(payload.conversations, detectors=registry)
    return AnalyzeResponse(
        total_conversations=len(payload.conversations),
        total_detections=len(detections),
        detections=detections,
    )
