"""Tests for the config system (config helpers + build_* functions)."""

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from dsm.cli import (
    CONFIG_FILE,
    build_docker_run_cmd,
    build_env_vars,
    build_port_mappings,
    build_volume_mounts,
    create_git_worktree,
    create_worktree_in_container,
    discover_repos,
    ensure_container,
    expand_env_vars,
    get_container_state,
    get_default_branch,
    get_default_config,
    get_named_config,
    list_worktrees,
    load_config,
    slugify,
)


# ── get_default_config ─────────────────────────────────────────────────────


def test_default_config_structure():
    cfg = get_default_config()
    assert cfg["version"] == "1.0"
    assert cfg["default_config"] == "none"
    assert "none" in cfg["configs"]


# ── load_config ────────────────────────────────────────────────────────────


def test_load_config_missing_file(tmp_path, monkeypatch):
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", tmp_path / "nonexistent.json")
    cfg = load_config()
    assert cfg == get_default_config()


def test_load_config_valid_file(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "dev",
        "configs": {"dev": {"image": "myimage:latest"}},
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    cfg = load_config()
    assert cfg["default_config"] == "dev"
    assert cfg["configs"]["dev"]["image"] == "myimage:latest"


def test_load_config_invalid_json(tmp_path, monkeypatch, capsys):
    config_file = tmp_path / "config.json"
    config_file.write_text("{ not valid json")
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    cfg = load_config()
    assert cfg == get_default_config()
    assert "Warning" in capsys.readouterr().err


# ── get_named_config ──────────────────────────────────────────────────────


def test_get_named_config_explicit(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "none",
        "configs": {
            "none": {},
            "dev": {"image": "dev:latest"},
        },
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    result = get_named_config("dev")
    assert result["image"] == "dev:latest"


def test_get_named_config_uses_default(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "dev",
        "configs": {
            "dev": {"image": "dev:latest"},
        },
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    result = get_named_config(None)
    assert result["image"] == "dev:latest"


def test_get_named_config_missing_exits(tmp_path, monkeypatch):
    config_data = {
        "version": "1.0",
        "default_config": "none",
        "configs": {"none": {}},
    }
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps(config_data))
    monkeypatch.setattr("dsm.cli.CONFIG_FILE", config_file)

    with pytest.raises(SystemExit):
        get_named_config("nonexistent")


# ── expand_env_vars ───────────────────────────────────────────────────────


def test_expand_env_vars_simple(monkeypatch):
    monkeypatch.setenv("MY_TOKEN", "secret123")
    result = expand_env_vars({"TOKEN": "${MY_TOKEN}"})
    assert result["TOKEN"] == "secret123"


def test_expand_env_vars_multiple_in_one_value(monkeypatch):
    monkeypatch.setenv("HOST", "localhost")
    monkeypatch.setenv("PORT", "5432")
    result = expand_env_vars({"DB_URL": "postgres://${HOST}:${PORT}/db"})
    assert result["DB_URL"] == "postgres://localhost:5432/db"


def test_expand_env_vars_no_expansion():
    result = expand_env_vars({"STATIC": "plain_value"})
    assert result["STATIC"] == "plain_value"


def test_expand_env_vars_missing_var_exits(monkeypatch):
    monkeypatch.delenv("DEFINITELY_NOT_SET", raising=False)
    with pytest.raises(SystemExit):
        expand_env_vars({"KEY": "${DEFINITELY_NOT_SET}"})


def test_expand_env_vars_non_string_value(monkeypatch):
    monkeypatch.setenv("X", "yes")
    result = expand_env_vars({"NUM": 42, "REF": "${X}"})
    assert result["NUM"] == "42"
    assert result["REF"] == "yes"


# ── discover_repos ────────────────────────────────────────────────────────


def test_discover_repos_finds_git_dirs(tmp_path):
    # Create fake repos
    (tmp_path / "repo-a" / ".git").mkdir(parents=True)
    (tmp_path / "repo-b" / ".git").mkdir(parents=True)
    (tmp_path / "not-a-repo").mkdir()

    repos = discover_repos(str(tmp_path))
    repo_names = {r["name"] for r in repos}
    assert repo_names == {"repo-a", "repo-b"}
    # Check dict structure
    for r in repos:
        assert r["repo_type"] == "standard"
        assert "default_branch" in r
        assert r["path"] == str(tmp_path / r["name"])


def test_discover_repos_finds_bare_repos(tmp_path):
    (tmp_path / "bare-repo" / ".bare").mkdir(parents=True)

    repos = discover_repos(str(tmp_path))
    repo_names = {r["name"] for r in repos}
    assert "bare-repo" in repo_names
    bare = [r for r in repos if r["name"] == "bare-repo"][0]
    assert bare["repo_type"] == "bare-worktree"


def test_discover_repos_excludes_paths(tmp_path):
    (tmp_path / "repo-a" / ".git").mkdir(parents=True)
    (tmp_path / "repo-b" / ".git").mkdir(parents=True)

    exclude = [str(tmp_path / "repo-a")]
    repos = discover_repos(str(tmp_path), exclude)
    repo_names = {r["name"] for r in repos}
    assert repo_names == {"repo-b"}


def test_discover_repos_nonexistent_dir(capsys):
    repos = discover_repos("/tmp/definitely_not_a_real_dir_12345")
    assert repos == []
    assert "Warning" in capsys.readouterr().err


def test_discover_repos_scan_depth(tmp_path):
    # depth 1: repos at top level only
    (tmp_path / "top-repo" / ".git").mkdir(parents=True)
    (tmp_path / "subdir").mkdir()
    (tmp_path / "subdir" / "nested-repo" / ".git").mkdir(parents=True)

    # depth=1 should only find top-level
    repos = discover_repos(str(tmp_path), scan_depth=1)
    assert {r["name"] for r in repos} == {"top-repo"}

    # depth=2 should find both
    repos = discover_repos(str(tmp_path), scan_depth=2)
    assert {r["name"] for r in repos} == {"nested-repo", "top-repo"}


def test_discover_repos_sorted_by_name(tmp_path):
    for name in ("zeta", "alpha", "middle"):
        (tmp_path / name / ".git").mkdir(parents=True)

    repos = discover_repos(str(tmp_path))
    names = [r["name"] for r in repos]
    assert names == ["alpha", "middle", "zeta"]


# ── build_volume_mounts ──────────────────────────────────────────────────


def test_build_volume_mounts_ssh_keys(tmp_path):
    ssh_key = tmp_path / ".ssh" / "authorized_keys"
    ssh_key.parent.mkdir()
    ssh_key.write_text("ssh-rsa AAAA...")

    config = {
        "ssh": {
            "enabled": True,
            "authorized_keys": str(ssh_key),
        }
    }
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert any("/home/ubuntu/.ssh/authorized_keys:ro" in v for v in volumes)


def test_build_volume_mounts_repos_dir(tmp_path):
    repos_dir = tmp_path / "repos"
    (repos_dir / "proj-a" / ".git").mkdir(parents=True)
    (repos_dir / "proj-b" / ".git").mkdir(parents=True)

    config = {"repos_dir": str(repos_dir)}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    mount_targets = {v.split(":")[-2] for v in volumes}
    assert "/mnt/proj-a" in mount_targets
    assert "/mnt/proj-b" in mount_targets


def test_build_volume_mounts_access_mode(tmp_path):
    repos_dir = tmp_path / "repos"
    (repos_dir / "proj" / ".git").mkdir(parents=True)

    config = {"repos_dir": str(repos_dir)}
    volumes = build_volume_mounts(config, tmp_path, None, [], "rw")
    assert all(v.endswith(":rw") for v in volumes)


def test_build_volume_mounts_extra_mounts(tmp_path):
    extra = tmp_path / "extra-dir"
    extra.mkdir()

    config = {}
    volumes = build_volume_mounts(config, tmp_path, None, [str(extra)], "ro")
    assert len(volumes) == 1
    assert "/mnt/extra-dir:ro" in volumes[0]


def test_build_volume_mounts_explicit_repos(tmp_path):
    repo = tmp_path / "my-lib"
    (repo / ".git").mkdir(parents=True)

    config = {"repos": [str(repo)]}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert any("/mnt/my-lib:ro" in v for v in volumes)


def test_build_volume_mounts_missing_repo_warns(tmp_path, capsys):
    config = {"repos": ["/tmp/no_such_repo_xyz"]}
    volumes = build_volume_mounts(config, tmp_path, None, [], "ro")
    assert volumes == []
    assert "Warning" in capsys.readouterr().err


# ── build_port_mappings ──────────────────────────────────────────────────


def test_build_port_mappings_ssh_enabled():
    config = {"ssh": {"enabled": True, "port": 3333}}
    ports = build_port_mappings(config)
    assert ports == ["3333:22"]


def test_build_port_mappings_ssh_default_port():
    config = {"ssh": {"enabled": True}}
    ports = build_port_mappings(config)
    assert ports == ["2222:22"]


def test_build_port_mappings_ssh_disabled():
    config = {"ssh": {"enabled": False}}
    assert build_port_mappings(config) == []


def test_build_port_mappings_no_ssh_key():
    assert build_port_mappings({}) == []


# ── build_env_vars ───────────────────────────────────────────────────────


def test_build_env_vars_from_config(monkeypatch):
    monkeypatch.setenv("GH_TOKEN", "ghp_abc")
    config = {"env": {"GITHUB_TOKEN": "${GH_TOKEN}", "DEBUG": "1"}}
    result = build_env_vars(config, [])
    assert "-e" in result
    assert "GITHUB_TOKEN=ghp_abc" in result
    assert "DEBUG=1" in result


def test_build_env_vars_extra_cli():
    config = {}
    result = build_env_vars(config, ["FOO=bar", "BAZ=qux"])
    assert result == ["-e", "FOO=bar", "-e", "BAZ=qux"]


def test_build_env_vars_invalid_extra_warns(capsys):
    config = {}
    result = build_env_vars(config, ["BADFORMAT"])
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_build_env_vars_combined(monkeypatch):
    monkeypatch.setenv("SECRET", "s3cret")
    config = {"env": {"TOKEN": "${SECRET}"}}
    result = build_env_vars(config, ["EXTRA=val"])
    # Config env comes first, then CLI extras
    assert result == ["-e", "TOKEN=s3cret", "-e", "EXTRA=val"]


# ── build_docker_run_cmd ─────────────────────────────────────────────────


def test_build_docker_run_cmd_basic():
    repo = Path("/tmp/myrepo")

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo",
        repo_path=repo,
        image="myimage:latest",
        ports=["8080:80"],
        volumes=["/host/path:/container/path:ro"],
        env_vars=["-e", "FOO=bar"],
        branch=None,
    )

    assert cmd[:4] == ["docker", "run", "-d", "--name"]
    assert "dsm_myrepo" in cmd
    assert "-v" in cmd
    assert f"{repo}:/workspace:ro" in cmd  # no branch = repo root = read-only
    assert "-p" in cmd
    assert "8080:80" in cmd
    assert "/host/path:/container/path:ro" in cmd
    assert "FOO=bar" in cmd
    assert "ANTHROPIC_API_KEY" not in " ".join(cmd)
    assert cmd[-3:] == ["myimage:latest", "sleep", "infinity"]
    # DSM env vars injected
    cmd_str = " ".join(cmd)
    assert "DSM_CONTAINER=1" in cmd_str
    assert "DSM_CONTAINER_NAME=dsm_myrepo" in cmd_str
    assert "DSM_HOST_IP=" in cmd_str
    assert "DSM_PORT_FORWARDING=auto" in cmd_str


def test_build_docker_run_cmd_with_branch():
    repo = Path("/tmp/myrepo")

    cmd = build_docker_run_cmd(
        container_name="dsm_myrepo_feat",
        repo_path=repo,
        image="img:latest",
        ports=[],
        volumes=[],
        env_vars=[],
        branch="feat",
    )

    # With branch, mounts worktree as workspace (rw for agent writes)
    assert f"{repo}/feat:/workspace:rw" in cmd


# ── get_container_state ──────────────────────────────────────────────────


def test_get_container_state_running(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="running\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") == "running"


def test_get_container_state_exited(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=0, stdout="exited\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") == "exited"


def test_get_container_state_not_found(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=1, stdout="")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    assert get_container_state("test_container") is None


# ── ensure_container ─────────────────────────────────────────────────────


def _mock_daemon_client(monkeypatch):
    """Set up a mock DsmClient for ensure_container tests."""
    from unittest.mock import MagicMock
    mock_client = MagicMock()
    mock_client.send.return_value = {}
    monkeypatch.setattr("dsm.cli._daemon_client_required", lambda: mock_client)
    return mock_client


def test_ensure_container_already_running(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "running")
    result = ensure_container("test", Path("/tmp/repo"), "img:latest")
    assert result == "already_running"
    mock_client.send.assert_called_once_with("start_container", container="test")


def test_ensure_container_starts_stopped(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "exited")
    result = ensure_container("test", Path("/tmp/repo"), "img:latest")
    assert result == "started"
    mock_client.send.assert_called_once_with("start_container", container="test")


def test_ensure_container_start_fails(monkeypatch):
    from unittest.mock import MagicMock
    mock_client = _mock_daemon_client(monkeypatch)
    mock_client.send.side_effect = RuntimeError("Daemon error: cannot start")
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: "exited")
    with pytest.raises(RuntimeError, match="cannot start"):
        ensure_container("test", Path("/tmp/repo"), "img:latest")


def test_ensure_container_creates_new(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": ""})())
    result = ensure_container("test", Path("/tmp/repo"), "img:latest")
    assert result == "created"
    mock_client.send.assert_called_once()
    call_args = mock_client.send.call_args
    assert call_args[0][0] == "create_container"


def test_ensure_container_create_fails(monkeypatch):
    mock_client = _mock_daemon_client(monkeypatch)
    mock_client.send.side_effect = RuntimeError("Daemon error: image not found")
    monkeypatch.setattr("dsm.cli.get_container_state", lambda name: None)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": ""})())
    with pytest.raises(RuntimeError, match="image not found"):
        ensure_container("test", Path("/tmp/repo"), "img:latest")


# ── create_worktree_in_container ─────────────────────────────────────────


def test_create_worktree_tier1_success(monkeypatch):
    from unittest.mock import MagicMock, call
    calls = []

    def mock_run(cmd, **kw):
        calls.append(cmd)
        return MagicMock(returncode=0, stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_worktree_in_container("ctr", "feat")
    assert result == "/worktrees/feat"
    # First call is rev-parse HEAD, second is tier 1 strategy
    assert len(calls) == 2
    assert "rev-parse" in calls[0]
    assert "--track" in calls[1]


def test_create_worktree_falls_through_to_tier3(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(cmd, **kw):
        call_count[0] += 1
        # rev-parse succeeds, tier 1 and 2 fail, tier 3 succeeds
        if call_count[0] == 1:  # rev-parse
            return MagicMock(returncode=0, stderr="")
        if call_count[0] <= 3:  # tier 1, tier 2
            return MagicMock(returncode=1, stderr="fatal: branch exists")
        return MagicMock(returncode=0, stderr="")  # tier 3

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_worktree_in_container("ctr", "new-branch")
    assert result == "/worktrees/new-branch"
    assert call_count[0] == 4


def test_create_worktree_no_commits(monkeypatch):
    from unittest.mock import MagicMock
    mock_result = MagicMock(returncode=1, stderr="fatal: bad revision")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)
    with pytest.raises(RuntimeError, match="no commits"):
        create_worktree_in_container("ctr", "feat")


def test_create_worktree_all_strategies_fail(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(cmd, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # rev-parse succeeds
            return MagicMock(returncode=0, stderr="")
        return MagicMock(returncode=1, stderr="fatal: something broke")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    with pytest.raises(RuntimeError, match="Failed to create worktree"):
        create_worktree_in_container("ctr", "bad-branch")


# ── slugify ─────────────────────────────────────────────────────────────────


def test_slugify_basic():
    assert slugify("Hello World") == "hello-world"


def test_slugify_max_length():
    assert slugify("a-very-long-branch-name-that-goes-on", max_length=10) == "a-very-lon"


def test_slugify_max_length_strips_trailing_hyphen():
    assert slugify("hello world foo", max_length=11) == "hello-world"


def test_slugify_no_max_length():
    long = "a" * 200
    assert len(slugify(long)) == 200


# ── list_worktrees ──────────────────────────────────────────────────────────


def test_list_worktrees_parses_porcelain(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo\n"
        "branch refs/heads/main\n"
        "\n"
        "worktree /home/user/repo/feature\n"
        "branch refs/heads/feature\n"
        "\n"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 2
    assert result[0] == {"branch": "main", "path": "/home/user/repo", "is_bare": False}
    assert result[1] == {"branch": "feature", "path": "/home/user/repo/feature", "is_bare": False}


def test_list_worktrees_bare_entry(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo/.bare\n"
        "bare\n"
        "\n"
        "worktree /home/user/repo/main\n"
        "branch refs/heads/main\n"
        "\n"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 2
    assert result[0]["is_bare"] is True
    assert result[1]["is_bare"] is False


def test_list_worktrees_git_failure(monkeypatch):
    from unittest.mock import MagicMock

    mock_result = MagicMock(returncode=1, stdout="")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    assert list_worktrees("/nonexistent") == []


def test_list_worktrees_no_trailing_newline(monkeypatch):
    from unittest.mock import MagicMock

    porcelain_output = (
        "worktree /home/user/repo\n"
        "branch refs/heads/main"
    )
    mock_result = MagicMock(returncode=0, stdout=porcelain_output)
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    result = list_worktrees("/home/user/repo")
    assert len(result) == 1
    assert result[0]["branch"] == "main"


# ── get_default_branch ──────────────────────────────────────────────────────


def test_get_default_branch_from_origin_head(monkeypatch):
    from unittest.mock import MagicMock

    mock_result = MagicMock(returncode=0, stdout="refs/remotes/origin/main\n")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    assert get_default_branch("/some/repo") == "main"


def test_get_default_branch_fallback_to_main(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(*args, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # symbolic-ref fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 2:  # rev-parse main succeeds
            return MagicMock(returncode=0, stdout="abc123\n")
        return MagicMock(returncode=1, stdout="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    assert get_default_branch("/some/repo") == "main"


def test_get_default_branch_fallback_to_master(monkeypatch):
    from unittest.mock import MagicMock
    call_count = [0]

    def mock_run(*args, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # symbolic-ref fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 2:  # rev-parse main fails
            return MagicMock(returncode=1, stdout="")
        if call_count[0] == 3:  # rev-parse master succeeds
            return MagicMock(returncode=0, stdout="abc123\n")
        return MagicMock(returncode=1, stdout="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    assert get_default_branch("/some/repo") == "master"


# ── create_git_worktree ────────────────────────────────────────────────────


def test_create_git_worktree_returns_path_standard(tmp_path, monkeypatch):
    """Standard repo (.git): worktree goes in sibling -worktrees dir."""
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    call_count = [0]
    def mock_run(cmd, **kw):
        call_count[0] += 1
        return MagicMock(returncode=0, stdout="abc123\n", stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_git_worktree(repo, "feature")

    assert result == tmp_path / "myrepo-worktrees" / "feature"
    assert isinstance(result, Path)


def test_create_git_worktree_returns_path_bare(tmp_path, monkeypatch):
    """Bare-worktree repo (.bare): worktree is sibling inside repo dir."""
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".bare").mkdir(parents=True)

    def mock_run(cmd, **kw):
        return MagicMock(returncode=0, stdout="abc123\n", stderr="")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)
    result = create_git_worktree(repo, "feature")

    assert result == repo / "feature"


def test_create_git_worktree_no_commits_raises(tmp_path, monkeypatch):
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    mock_result = MagicMock(returncode=1, stdout="", stderr="fatal: bad revision")
    monkeypatch.setattr("dsm.cli.subprocess.run", lambda *a, **kw: mock_result)

    with pytest.raises(RuntimeError, match="no commits"):
        create_git_worktree(repo, "feature")


def test_create_git_worktree_all_tiers_fail_raises(tmp_path, monkeypatch):
    from unittest.mock import MagicMock

    repo = tmp_path / "myrepo"
    (repo / ".git").mkdir(parents=True)

    call_count = [0]
    def mock_run(cmd, **kw):
        call_count[0] += 1
        if call_count[0] == 1:  # rev-parse HEAD
            return MagicMock(returncode=0, stdout="abc123\n", stderr="")
        return MagicMock(returncode=1, stdout="", stderr="fatal: error")

    monkeypatch.setattr("dsm.cli.subprocess.run", mock_run)

    with pytest.raises(RuntimeError, match="Failed to create worktree"):
        create_git_worktree(repo, "feature")
