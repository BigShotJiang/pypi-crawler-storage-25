# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com).

## [Unreleased]

## [0.5.1] - 2026-04-14

### Changed
- All container Docker operations (create, start, stop, remove) now route through the daemon as single gateway
- CLI no longer calls `docker run/start/stop/rm` directly for container sessions
- `remove_container` daemon command now handles Docker stop/rm atomically with registry cleanup

### Added
- `create_container`, `start_container`, `stop_container` daemon commands
- `docker_cmd` field on registry entries for faithful container recreation
- Configurable timeout on `DsmClient.send()` for long-running operations
- `force` param on `remove_container` for cleaning unknown containers

### Removed
- Direct Docker mutation calls from CLI (`_register_container_with_daemon`, `_try_register_container`, `_deregister_container`)

## [0.5.0] - 2026-04-14

### Added
- Background daemon (`dsm daemon start|stop|status`) with Unix socket server and NDJSON protocol
- Container registry with atomic JSON persistence (`~/.dsm/registry/`)
- CLI operates as thin daemon client with lazy daemon start
- `dsm ports`, `dsm forward`, `dsm unforward` — port detection and forwarding via socat
- `dsm ports --watch` — background watcher that auto-forwards ports as services start/stop
- `PortWatcher` with 2s polling, state diffing, and container restart detection
- Port detection via `/proc/$PID/net/tcp` (zero-overhead, no docker exec)
- Agent context injection: generate and mount `CLAUDE.md` into containers
- DSM environment variables injected into container sessions
- `workspace_access` parameter for container mount control
- `remove_container` daemon command for deregistering containers
- 90 new tests (151 total)

### Fixed
- Duplicate port forwards piling up on container restart or PortWatcher restart
- Stale forward entries now pruned on daemon startup (dead socat PIDs removed)
- Workspace mount set to read-write so git operations work inside containers
- Daemon logging and robust error handling in PortWatcher
- PortWatcher seeded with existing containers on daemon startup
- `discover_repos` scanner skips git worktrees

### Changed
- PortWatcher migrated from threading to asyncio

## [0.4.0] - 2026-04-09

### Added
- `list_worktrees(repo_path)` — parse `git worktree list --porcelain` into structured dicts
- `get_default_branch(repo_path)` — detect default branch via origin/HEAD with main/master fallback
- `discover_repos` now returns rich dicts (`name`, `path`, `repo_type`, `default_branch`) instead of bare Paths
- `discover_repos` `scan_depth` parameter for recursive directory scanning (default 1)
- `slugify` `max_length` parameter for branch name truncation
- 17 new unit tests (61 total)

### Changed
- `create_git_worktree` returns `Path` and raises `RuntimeError` instead of calling `sys.exit()`
- `create_git_worktree` places worktrees in sibling `{repo}-worktrees/` dir for standard repos (bare-worktree repos unchanged)
- `build_volume_mounts` updated for new `discover_repos` dict return type

## [0.3.0] - 2026-04-08

### Added
- Config system for container sessions (`~/.dsm/config.json`) with named configs, SSH key mounting, repo auto-discovery, and environment variable expansion
- Container reuse: `dsm con` reuses existing containers instead of failing on conflict
- `--new` flag to force-recreate a container
- `--config`, `--mount`, `--access`, `-e`/`--env` CLI flags for container sessions
- Library API for ui_coder: `ensure_container()`, `create_worktree_in_container()`, `get_container_state()`
- Unit test suite (44 tests covering config, container, and build functions)
- `.gitignore`

### Changed
- `build_docker_run_cmd` `env_vars` parameter is now optional for backward compatibility
- Container name is always `dsm_{repo}` regardless of branch (one container per repo)
- Session metadata is saved when reusing containers with new worktrees

### Removed
- Automatic Anthropic API key injection into containers

## [0.2.0] - 2026-04-07

### Added
- Local sessions with dtach (`dsm local`)
- SSH sessions with keepalive (`dsm ssh`)
- Docker container sessions with repo mounting (`dsm container`)
- Git worktree initialization (`dsm init-worktree`)
- Session management: list, resume, tail, remove, clean
- SSH host aliases
- Auto-injection of Anthropic API key into containers
- Output capture via `script` for local/ssh sessions

### Changed
- Renamed `create` subcommand to `local` (alias `l`)

[Unreleased]: https://github.com/pjsulin/dsm/compare/v0.5.1...HEAD
[0.5.1]: https://github.com/pjsulin/dsm/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/pjsulin/dsm/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/pjsulin/dsm/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/pjsulin/dsm/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/pjsulin/dsm/releases/tag/v0.2.0
