"""Daemon process for dsm — manages container registry and port forwards.

Listens on a Unix domain socket, speaks NDJSON (one JSON object per line),
and dispatches commands to the container registry.  Event subscriptions let
clients receive real-time notifications about port and container changes.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Any

from dsm.ports import (
    ForwardHandle,
    PortChange,
    PortWatcher,
    list_forwards,
    scan_container_ports,
    start_forward,
    stop_forward,
)
from dsm.registry import ContainerRegistry, ForwardInfo, PortInfo

log = logging.getLogger(__name__)

DEFAULT_SOCKET_PATH = Path("~/.dsm/dsm.sock").expanduser()
DEFAULT_REGISTRY_DIR = Path("~/.dsm/registry").expanduser()


def _pid_alive(pid: int) -> bool:
    """Check if a process with *pid* is still running."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # process exists but we can't signal it


# ---------------------------------------------------------------------------
# Subscriber tracking
# ---------------------------------------------------------------------------

class _Subscriber:
    """A client connection that has issued a ``watch`` command."""

    __slots__ = ("writer", "container_filter", "subscription_id")

    def __init__(
        self,
        writer: asyncio.StreamWriter,
        container_filter: str | None,
        subscription_id: str,
    ) -> None:
        self.writer = writer
        self.container_filter = container_filter
        self.subscription_id = subscription_id


# ---------------------------------------------------------------------------
# DsmDaemon
# ---------------------------------------------------------------------------

class DsmDaemon:
    """Main daemon class — owns the socket server, registry, and subscribers."""

    def __init__(
        self,
        socket_path: Path = DEFAULT_SOCKET_PATH,
        registry_dir: Path = DEFAULT_REGISTRY_DIR,
    ) -> None:
        self.socket_path = socket_path
        self.registry_dir = registry_dir
        self.registry = ContainerRegistry(registry_dir)

        self._server: asyncio.Server | None = None
        self._start_time: float = 0.0
        self._stop_event: asyncio.Event | None = None
        self._subscribers: list[_Subscriber] = []
        self._port_watcher: PortWatcher | None = None

    # -- lifecycle ----------------------------------------------------------

    async def start(self) -> None:
        """Create the Unix socket server and load the registry."""
        self._start_time = time.monotonic()
        self._stop_event = asyncio.Event()

        # Ensure parent directory exists
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)

        # Remove stale socket file if present
        if self.socket_path.exists():
            self.socket_path.unlink()

        self.registry.load()
        self._cleanup_stale_forwards()

        # Start port watcher with on_change wired to broadcast_event
        # Seed with all containers already in the registry
        existing_containers = [e.container_name for e in self.registry.list()]
        self._port_watcher = PortWatcher(
            containers=existing_containers,
            on_change=self._on_port_change,
            registry=self.registry,
        )
        await self._port_watcher.start()

        self._server = await asyncio.start_unix_server(
            self._handle_client,
            path=str(self.socket_path),
        )
        log.info("daemon listening on %s", self.socket_path)

    async def stop(self) -> None:
        """Shut down the server, persist state, and clean up the socket file."""
        log.info("daemon stopping")

        # Stop port watcher
        if self._port_watcher is not None:
            await self._port_watcher.stop()
            self._port_watcher = None

        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None

        # Close all subscriber writers
        for sub in self._subscribers:
            try:
                sub.writer.close()
                await sub.writer.wait_closed()
            except Exception:
                pass
        self._subscribers.clear()

        self.registry.persist_all()

        if self.socket_path.exists():
            self.socket_path.unlink()

        if self._stop_event is not None:
            self._stop_event.set()

        log.info("daemon stopped")

    async def _main(self) -> None:
        """Top-level coroutine: start, install signal handlers, wait for stop."""
        await self.start()

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, self._signal_handler)

        assert self._stop_event is not None
        await self._stop_event.wait()

    def _signal_handler(self) -> None:
        """Schedule ``stop()`` from a signal callback."""
        log.info("received signal, scheduling shutdown")
        asyncio.ensure_future(self.stop())

    def run(self) -> None:
        """Synchronous entry point — suitable as a subprocess target."""
        asyncio.run(self._main())

    # -- startup cleanup ----------------------------------------------------

    def _cleanup_stale_forwards(self) -> None:
        """Remove stale ForwardInfo entries from the registry on startup.

        After a daemon restart, persisted ForwardInfo entries refer to socat
        PIDs from the previous run.  Those processes are almost certainly dead.
        Check each PID and prune entries that are no longer alive.
        """
        for entry in self.registry.list():
            if not entry.forwards:
                continue

            alive_forwards: list[ForwardInfo] = []
            for fwd in entry.forwards:
                if _pid_alive(fwd.socat_pid):
                    alive_forwards.append(fwd)
                else:
                    log.info(
                        "Pruning stale forward %s:%d -> host:%d (pid %d dead)",
                        entry.container_name, fwd.container_port,
                        fwd.host_port, fwd.socat_pid,
                    )

            if len(alive_forwards) != len(entry.forwards):
                entry.forwards = alive_forwards
                try:
                    self.registry.persist(entry.container_name)
                except (KeyError, OSError):
                    pass

    # -- docker helpers ----------------------------------------------------

    async def _run_docker(
        self, cmd: list[str], check: bool = True
    ) -> subprocess.CompletedProcess:
        """Run a blocking Docker command in the executor."""
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, lambda: subprocess.run(cmd, capture_output=True, text=True)
        )
        if check and result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or f"docker command failed: {cmd}")
        return result

    async def _inspect_container(self, name: str) -> tuple[str, str]:
        """Return (container_id, container_ip) via docker inspect."""
        id_result = await self._run_docker(
            ["docker", "inspect", "-f", "{{.Id}}", name]
        )
        ip_result = await self._run_docker(
            ["docker", "inspect", "-f",
             "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}", name]
        )
        return id_result.stdout.strip(), ip_result.stdout.strip()

    # -- port change callback (Task 3.5) ------------------------------------

    def _on_port_change(self, changes: list[PortChange]) -> None:
        """Translate PortChange objects to events and broadcast.

        Called from the executor thread, so we schedule the async broadcast
        on the event loop.
        """
        loop = asyncio.get_event_loop()
        for change in changes:
            forward_data = None
            if change.forward is not None:
                forward_data = {
                    "container_port": change.forward.container_port,
                    "host_port": change.forward.host_port,
                    "socat_pid": change.forward.process.pid if change.forward.process else None,
                    "alive": change.forward.alive,
                }

            if change.action == "added":
                event_type = "port_added"
                data = {
                    "container": change.container_name,
                    "port": change.port.port,
                    "bind": change.port.bind_address,
                    "protocol": change.port.protocol,
                    "forward": forward_data,
                }
            else:
                event_type = "port_removed"
                data = {
                    "container": change.container_name,
                    "port": change.port.port,
                    "forward": forward_data,
                }

            asyncio.run_coroutine_threadsafe(
                self.broadcast_event(event_type, data, container=change.container_name),
                loop,
            )

    # -- client handling ----------------------------------------------------

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Read NDJSON requests, dispatch, and write NDJSON responses."""
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break  # client disconnected

                response = await self._dispatch(line, writer)
                if response is not None:
                    writer.write(json.dumps(response).encode() + b"\n")
                    await writer.drain()
        except asyncio.CancelledError:
            pass
        except ConnectionResetError:
            pass
        except Exception:
            log.exception("unexpected error in client handler")
        finally:
            # Remove this writer from subscribers if present
            self._subscribers = [
                s for s in self._subscribers if s.writer is not writer
            ]
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _dispatch(
        self,
        raw_line: bytes,
        writer: asyncio.StreamWriter,
    ) -> dict[str, Any] | None:
        """Parse a request line and route to the appropriate handler.

        Returns the response dict to send, or ``None`` if the command
        switches the connection to event mode (watch).
        """
        try:
            request = json.loads(raw_line)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            return {"id": None, "result": None, "error": str(exc)}

        if not isinstance(request, dict):
            return {"id": None, "result": None, "error": "request must be a JSON object"}

        req_id = request.get("id")
        cmd = request.get("cmd")

        if not cmd:
            return {"id": req_id, "result": None, "error": "missing 'cmd' field"}

        handler = self._commands.get(cmd)
        if handler is None:
            return {"id": req_id, "result": None, "error": f"unknown command: {cmd}"}

        try:
            result = await handler(self, request, writer)
            # watch/unwatch return their own response
            if cmd in ("watch", "unwatch"):
                return result
            return {"id": req_id, "result": result, "error": None}
        except Exception as exc:
            return {"id": req_id, "result": None, "error": str(exc)}

    # -- command implementations --------------------------------------------

    async def _cmd_list_containers(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        return [entry.to_dict() for entry in self.registry.list()]

    async def _cmd_get_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        name = request.get("container")
        if not name:
            raise ValueError("missing 'container' param")
        entry = self.registry.get(name)
        if entry is None:
            raise KeyError(f"container not found: {name}")
        return entry.to_dict()

    async def _cmd_register_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        name = request.get("container")
        container_id = request.get("container_id")
        ip = request.get("ip")
        if not name or not container_id or not ip:
            raise ValueError("missing required params: container, container_id, ip")
        entry = self.registry.register(name, container_id, ip)
        self.registry.persist(name)

        # Add container to port watcher
        if self._port_watcher is not None:
            self._port_watcher.add_container(name)

        return entry.to_dict()

    async def _cmd_status(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        uptime = time.monotonic() - self._start_time
        entries = self.registry.list()
        forward_count = sum(len(e.forwards) for e in entries)
        return {
            "pid": os.getpid(),
            "uptime": round(uptime, 2),
            "containers": len(entries),
            "forwards": forward_count,
        }

    async def _cmd_shutdown(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        # Schedule stop so the response can be sent first
        asyncio.get_running_loop().call_soon(
            lambda: asyncio.ensure_future(self.stop())
        )
        return None

    async def _cmd_watch(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> dict[str, Any]:
        container_filter = request.get("container")
        sub_id = request.get("id") or f"watch-{id(writer)}"
        sub = _Subscriber(writer, container_filter, sub_id)
        self._subscribers.append(sub)
        return {"id": request.get("id"), "result": {"subscribed": True}, "error": None}

    async def _cmd_unwatch(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> dict[str, Any]:
        self._subscribers = [
            s for s in self._subscribers if s.writer is not writer
        ]
        return {"id": request.get("id"), "result": {"subscribed": False}, "error": None}

    # -- port/forward command implementations (Task 3.4) --------------------

    async def _cmd_list_ports(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """List detected ports for a container (or all containers)."""
        container = request.get("container")
        if container:
            entry = self.registry.get(container)
            if entry is None:
                raise KeyError(f"container not found: {container}")
            return [p.to_dict() for p in entry.ports]
        else:
            result = []
            for entry in self.registry.list():
                for p in entry.ports:
                    d = p.to_dict()
                    d["container"] = entry.container_name
                    result.append(d)
            return result

    async def _cmd_list_forwards(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """List active forwards for a container (or all containers)."""
        container = request.get("container")
        if container:
            entry = self.registry.get(container)
            if entry is None:
                raise KeyError(f"container not found: {container}")
            return [f.to_dict() for f in entry.forwards]
        else:
            result = []
            for entry in self.registry.list():
                for f in entry.forwards:
                    d = f.to_dict()
                    d["container"] = entry.container_name
                    result.append(d)
            return result

    async def _cmd_start_forward(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Start a port forward for a container."""
        container = request.get("container")
        port = request.get("port")
        host_port = request.get("host_port")
        if not container or port is None:
            raise ValueError("missing required params: container, port")

        entry = self.registry.get(container)
        if entry is None:
            raise KeyError(f"container not found: {container}")

        # Run blocking start_forward in executor
        loop = asyncio.get_running_loop()
        handle: ForwardHandle = await loop.run_in_executor(
            None, lambda: start_forward(container, port, host_port, registry=self.registry)
        )

        # Return the ForwardInfo that was persisted
        for fi in entry.forwards:
            if fi.container_port == handle.container_port:
                return fi.to_dict()

        # Fallback if not found in registry (shouldn't happen)
        return {
            "container_port": handle.container_port,
            "host_port": handle.host_port,
            "socat_pid": handle.process.pid if handle.process else 0,
            "alive": handle.alive,
        }

    # -- container lifecycle commands -----------------------------------------

    async def _cmd_create_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Create a Docker container, register it, and start watching."""
        name = request.get("container_name")
        docker_cmd = request.get("docker_cmd")
        if not name or not docker_cmd:
            raise ValueError("missing required params: container_name, docker_cmd")

        await self._run_docker(docker_cmd)
        container_id, container_ip = await self._inspect_container(name)

        entry = self.registry.register(name, container_id, container_ip)
        entry.docker_cmd = docker_cmd
        self.registry.persist(name)

        if self._port_watcher is not None:
            self._port_watcher.add_container(name)

        log.info("created container %s (%s)", name, container_id[:12])
        return entry.to_dict()

    async def _cmd_start_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Start a stopped container and re-register."""
        name = request.get("container")
        if not name:
            raise ValueError("missing 'container' param")

        await self._run_docker(["docker", "start", name])
        container_id, container_ip = await self._inspect_container(name)

        entry = self.registry.get(name)
        if entry is not None:
            self.registry.update(name, status="running", container_ip=container_ip)
        else:
            entry = self.registry.register(name, container_id, container_ip)
        self.registry.persist(name)

        if self._port_watcher is not None:
            self._port_watcher.add_container(name)

        log.info("started container %s", name)
        return self.registry.get(name).to_dict()

    async def _cmd_stop_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Stop a running container."""
        name = request.get("container")
        if not name:
            raise ValueError("missing 'container' param")

        # Stop watching and forwards first
        if self._port_watcher is not None:
            self._port_watcher.remove_container(name)

        await self._run_docker(["docker", "stop", name])

        entry = self.registry.get(name)
        if entry is not None:
            self.registry.update(name, status="stopped")
            self.registry.persist(name)

        log.info("stopped container %s", name)
        return {"stopped": name}

    async def _cmd_remove_container(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Stop, remove a Docker container, and deregister it."""
        name = request.get("container")
        force = request.get("force", False)
        if not name:
            raise ValueError("missing 'container' param")

        entry = self.registry.get(name)
        if entry is None and not force:
            raise KeyError(f"container not found: {name}")

        # Stop watching and forwards first
        if self._port_watcher is not None:
            self._port_watcher.remove_container(name)

        # Remove from registry BEFORE docker ops to prevent concurrent
        # PortWatcher polls from re-persisting the entry during docker stop
        if entry is not None:
            self.registry.remove(name)

        # Docker stop + rm (ignore errors — container may already be gone)
        await self._run_docker(["docker", "stop", name], check=False)
        await self._run_docker(["docker", "rm", name], check=False)

        log.info("removed container %s", name)
        return {"removed": name}

    async def _cmd_stop_forward(
        self, request: dict, writer: asyncio.StreamWriter,
    ) -> Any:
        """Stop a port forward for a container."""
        container = request.get("container")
        port = request.get("port")
        if not container or port is None:
            raise ValueError("missing required params: container, port")

        entry = self.registry.get(container)
        if entry is None:
            raise KeyError(f"container not found: {container}")

        # Find the live handle
        forwards = list_forwards(container)
        handle = None
        for h in forwards:
            if h.container_port == port:
                handle = h
                break

        if handle is None:
            raise KeyError(f"no active forward for port {port} on {container}")

        stop_forward(handle, registry=self.registry)
        self.registry.persist(container)

        return None

    # command dispatch table
    _commands: dict[str, Any] = {
        "list_containers": _cmd_list_containers,
        "get_container": _cmd_get_container,
        "register_container": _cmd_register_container,
        "create_container": _cmd_create_container,
        "start_container": _cmd_start_container,
        "stop_container": _cmd_stop_container,
        "remove_container": _cmd_remove_container,
        "status": _cmd_status,
        "shutdown": _cmd_shutdown,
        "watch": _cmd_watch,
        "unwatch": _cmd_unwatch,
        "list_ports": _cmd_list_ports,
        "list_forwards": _cmd_list_forwards,
        "start_forward": _cmd_start_forward,
        "stop_forward": _cmd_stop_forward,
    }

    # -- event broadcasting -------------------------------------------------

    async def broadcast_event(
        self,
        event_type: str,
        data: dict[str, Any],
        container: str | None = None,
    ) -> None:
        """Send an event to all matching subscribers.

        If *container* is given, only subscribers watching that container
        (or watching all containers) receive the event.  Disconnected
        subscribers are silently removed.
        """
        dead: list[_Subscriber] = []

        for sub in self._subscribers:
            # Apply container filter
            if sub.container_filter and container and sub.container_filter != container:
                continue

            event_line = json.dumps({
                "id": sub.subscription_id,
                "event": event_type,
                "data": data,
            }).encode() + b"\n"

            try:
                sub.writer.write(event_line)
                await sub.writer.drain()
            except Exception:
                dead.append(sub)

        # Remove disconnected subscribers
        if dead:
            dead_set = set(id(s) for s in dead)
            self._subscribers = [
                s for s in self._subscribers if id(s) not in dead_set
            ]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    import argparse

    parser = argparse.ArgumentParser(description="dsm daemon")
    parser.add_argument(
        "--socket",
        type=Path,
        default=DEFAULT_SOCKET_PATH,
        help="Unix socket path (default: %(default)s)",
    )
    parser.add_argument(
        "--registry-dir",
        type=Path,
        default=DEFAULT_REGISTRY_DIR,
        help="Registry directory (default: %(default)s)",
    )
    args = parser.parse_args()

    daemon = DsmDaemon(socket_path=args.socket, registry_dir=args.registry_dir)
    daemon.run()
