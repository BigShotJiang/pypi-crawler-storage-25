#!/usr/bin/env python3
"""One-time migration: collapse 742 freeform relationship types -> 15 canonical RelationType edges.

Key difference from label migration: Neo4j relationship types are immutable.
Must CREATE new edge, copy properties, DELETE old edge.

Usage:
    python scripts/migrate_edges.py --dry-run   # preview changes
    python scripts/migrate_edges.py              # execute migration

Reads NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE from env vars.
"""

import argparse
import os
import re
import sys
from collections import defaultdict

from dotenv import load_dotenv
from neo4j import GraphDatabase

# Load .env file from project root (or cwd)
load_dotenv()


# -- Target taxonomy (15 edge types) -----------------------------------------

VALID_RELATION_TYPES = {
    "SEQUENCE", "EVOLUTION",
    "DISCOVERY", "RECOGNITION",
    "VALIDATION", "CHALLENGE",
    "ENABLING", "REQUIRING",
    "ENCOMPASSING", "COMPOSING",
    "INFORMING", "CAUSING",
    "EXTENDING", "OPENING",
    "NEXT_DAY",
}


# -- Explicit overrides -------------------------------------------------------
# These take priority over keyword rules. Add entries here for types that
# the keyword classifier gets wrong or that are genuinely ambiguous.

EXPLICIT_MAP: dict[str, str] = {
    # Already correct
    "NEXT_DAY": "NEXT_DAY",
    "SEQUENCE": "SEQUENCE",
    "EVOLUTION": "EVOLUTION",
    "DISCOVERY": "DISCOVERY",
    "RECOGNITION": "RECOGNITION",
    "VALIDATION": "VALIDATION",
    "CHALLENGE": "CHALLENGE",
    "ENABLING": "ENABLING",
    "REQUIRING": "REQUIRING",
    "ENCOMPASSING": "ENCOMPASSING",
    "COMPOSING": "COMPOSING",
    "INFORMING": "INFORMING",
    "CAUSING": "CAUSING",
    "EXTENDING": "EXTENDING",
    "OPENING": "OPENING",

    # Temporal / sequence-like
    "FOLLOWS": "SEQUENCE",
    "FOLLOWED_BY": "SEQUENCE",
    "PRECEDES": "SEQUENCE",
    "PRECEDED_BY": "SEQUENCE",
    "LEADS_TO": "SEQUENCE",
    "LED_TO": "SEQUENCE",
    "THEN": "SEQUENCE",
    "NEXT_STEP": "SEQUENCE",
    "NEXT": "SEQUENCE",
    "BEFORE": "SEQUENCE",
    "AFTER": "SEQUENCE",
    "STEPS_TO": "SEQUENCE",
    "PROGRESSES_TO": "SEQUENCE",
    "TRANSITIONS_TO": "SEQUENCE",
    "FLOWS_TO": "SEQUENCE",
    "PROCEEDS_TO": "SEQUENCE",
    "CHAINS_TO": "SEQUENCE",

    # Evolution / transformation
    "EVOLVED_FROM": "EVOLUTION",
    "EVOLVED_INTO": "EVOLUTION",
    "EVOLVES_INTO": "EVOLUTION",
    "TRANSFORMS_INTO": "EVOLUTION",
    "TRANSFORMED_INTO": "EVOLUTION",
    "TRANSFORMS": "EVOLUTION",
    "BECAME": "EVOLUTION",
    "BECOMES": "EVOLUTION",
    "GREW_INTO": "EVOLUTION",
    "DEVELOPS_INTO": "EVOLUTION",
    "DEVELOPED_INTO": "EVOLUTION",
    "MATURES_INTO": "EVOLUTION",
    "REFINED_INTO": "EVOLUTION",
    "REFINES": "EVOLUTION",
    "DEEPENED_INTO": "EVOLUTION",
    "DEEPENS": "EVOLUTION",
    "EMERGED_FROM": "EVOLUTION",
    "EMERGES_FROM": "EVOLUTION",

    # Discovery
    "DISCOVERED": "DISCOVERY",
    "DISCOVERS": "DISCOVERY",
    "REVEALED": "DISCOVERY",
    "REVEALS": "DISCOVERY",
    "UNCOVERED": "DISCOVERY",
    "FOUND": "DISCOVERY",
    "SURFACED": "DISCOVERY",
    "IDENTIFIED": "DISCOVERY",
    "BREAKTHROUGH_IN": "DISCOVERY",
    "REALIZED": "DISCOVERY",

    # Recognition / pattern matching
    "RECOGNIZED": "RECOGNITION",
    "RECOGNIZES": "RECOGNITION",
    "PARALLELS": "RECOGNITION",
    "MIRRORS": "RECOGNITION",
    "ECHOES": "RECOGNITION",
    "RESEMBLES": "RECOGNITION",
    "SIMILAR_TO": "RECOGNITION",
    "ANALOGOUS_TO": "RECOGNITION",
    "MAPS_TO": "RECOGNITION",
    "CORRESPONDS_TO": "RECOGNITION",
    "RECURS_IN": "RECOGNITION",
    "RESONATES_WITH": "RECOGNITION",
    "REFLECTS": "RECOGNITION",

    # Validation / confirmation
    "VALIDATES": "VALIDATION",
    "VALIDATED": "VALIDATION",
    "VALIDATED_BY": "VALIDATION",
    "CONFIRMS": "VALIDATION",
    "CONFIRMED": "VALIDATION",
    "CONFIRMED_BY": "VALIDATION",
    "SUPPORTS": "VALIDATION",
    "SUPPORTED_BY": "VALIDATION",
    "EVIDENCES": "VALIDATION",
    "EVIDENCED_BY": "VALIDATION",
    "DEMONSTRATES": "VALIDATION",
    "DEMONSTRATED_BY": "VALIDATION",
    "PROVES": "VALIDATION",
    "PROVEN_BY": "VALIDATION",
    "VERIFIES": "VALIDATION",
    "VERIFIED_BY": "VALIDATION",
    "SUBSTANTIATES": "VALIDATION",

    # Challenge / tension
    "CHALLENGES": "CHALLENGE",
    "CHALLENGED_BY": "CHALLENGE",
    "CONTRADICTS": "CHALLENGE",
    "CONTRADICTED_BY": "CHALLENGE",
    "CONFLICTS_WITH": "CHALLENGE",
    "TENSIONS_WITH": "CHALLENGE",
    "OPPOSES": "CHALLENGE",
    "OPPOSED_BY": "CHALLENGE",
    "DISRUPTS": "CHALLENGE",
    "DISRUPTED_BY": "CHALLENGE",
    "BLOCKS": "CHALLENGE",
    "BLOCKED_BY": "CHALLENGE",
    "COMPLICATES": "CHALLENGE",
    "PROBLEMATIZES": "CHALLENGE",
    "UNDERMINES": "CHALLENGE",
    "LIMITS": "CHALLENGE",
    "RESISTS": "CHALLENGE",

    # Enabling / prerequisite
    "ENABLES": "ENABLING",
    "ENABLED_BY": "ENABLING",
    "FACILITATES": "ENABLING",
    "FACILITATED_BY": "ENABLING",
    "EMPOWERS": "ENABLING",
    "UNLOCKS": "ENABLING",
    "UNLOCKED_BY": "ENABLING",
    "ALLOWS": "ENABLING",
    "MAKES_POSSIBLE": "ENABLING",
    "OPENS_DOOR_TO": "ENABLING",
    "PROVIDES_BASIS_FOR": "ENABLING",
    "GROUNDS": "ENABLING",
    "PREPARES_FOR": "ENABLING",

    # Requiring / dependency
    "REQUIRES": "REQUIRING",
    "REQUIRED_BY": "REQUIRING",
    "DEPENDS_ON": "REQUIRING",
    "DEPENDENT_ON": "REQUIRING",
    "NEEDS": "REQUIRING",
    "NEEDED_BY": "REQUIRING",
    "PREREQUISITE_FOR": "REQUIRING",
    "PREREQUISITE_OF": "REQUIRING",
    "CONSTRAINED_BY": "REQUIRING",
    "DEMANDS": "REQUIRING",

    # Encompassing / containment
    "ENCOMPASSES": "ENCOMPASSING",
    "ENCOMPASSES_ALL": "ENCOMPASSING",
    "CONTAINS": "ENCOMPASSING",
    "CONTAINED_BY": "ENCOMPASSING",
    "INCLUDES": "ENCOMPASSING",
    "INCLUDED_IN": "ENCOMPASSING",
    "SUBSUMES": "ENCOMPASSING",
    "SUBSUMED_BY": "ENCOMPASSING",
    "WRAPS": "ENCOMPASSING",
    "COVERS": "ENCOMPASSING",
    "HOUSES": "ENCOMPASSING",
    "EMBEDS": "ENCOMPASSING",
    "EMBEDDED_IN": "ENCOMPASSING",
    "PART_OF": "ENCOMPASSING",
    "HAS_PART": "ENCOMPASSING",
    "BELONGS_TO": "ENCOMPASSING",
    "MEMBER_OF": "ENCOMPASSING",
    "HAS_MEMBER": "ENCOMPASSING",
    "CATEGORY_OF": "ENCOMPASSING",
    "CATEGORIZED_BY": "ENCOMPASSING",

    # Composing / synthesis
    "COMPOSES": "COMPOSING",
    "COMPOSED_OF": "COMPOSING",
    "SYNTHESIZES": "COMPOSING",
    "SYNTHESIZED_FROM": "COMPOSING",
    "INTEGRATES": "COMPOSING",
    "INTEGRATED_WITH": "COMPOSING",
    "COMBINES": "COMPOSING",
    "COMBINED_WITH": "COMPOSING",
    "MERGES": "COMPOSING",
    "MERGED_WITH": "COMPOSING",
    "UNIFIES": "COMPOSING",
    "UNIFIED_WITH": "COMPOSING",
    "CONVERGES_WITH": "COMPOSING",
    "BRIDGES": "COMPOSING",
    "BRIDGES_TO": "COMPOSING",
    "CONNECTS": "COMPOSING",
    "CONNECTS_TO": "COMPOSING",
    "LINKS": "COMPOSING",
    "LINKS_TO": "COMPOSING",
    "WORKS_WITH": "COMPOSING",
    "COLLABORATES_WITH": "COMPOSING",
    "PAIRS_WITH": "COMPOSING",

    # Informing / knowledge flow
    "INFORMS": "INFORMING",
    "INFORMED_BY": "INFORMING",
    "SHAPES": "INFORMING",
    "SHAPED_BY": "INFORMING",
    "INFLUENCES": "INFORMING",
    "INFLUENCED_BY": "INFORMING",
    "GUIDES": "INFORMING",
    "GUIDED_BY": "INFORMING",
    "TEACHES": "INFORMING",
    "TAUGHT_BY": "INFORMING",
    "INSPIRES": "INFORMING",
    "INSPIRED_BY": "INFORMING",
    "MODELS": "INFORMING",
    "MODELED_BY": "INFORMING",
    "CONTEXTUALIZES": "INFORMING",
    "CONTEXTUALIZED_BY": "INFORMING",
    "REFERENCES": "INFORMING",
    "REFERENCED_BY": "INFORMING",
    "DRAWS_FROM": "INFORMING",
    "DERIVED_FROM": "INFORMING",
    "DERIVES_FROM": "INFORMING",
    "RELATES_TO": "INFORMING",
    "RELATED_TO": "INFORMING",
    "ASSOCIATED_WITH": "INFORMING",
    "RELEVANT_TO": "INFORMING",
    "PERTAINS_TO": "INFORMING",
    "KNOWS": "INFORMING",

    # Causing / direct production
    "CAUSES": "CAUSING",
    "CAUSED_BY": "CAUSING",
    "PRODUCES": "CAUSING",
    "PRODUCED_BY": "CAUSING",
    "GENERATES": "CAUSING",
    "GENERATED_BY": "CAUSING",
    "CREATES": "CAUSING",
    "CREATED_BY": "CAUSING",
    "TRIGGERS": "CAUSING",
    "TRIGGERED_BY": "CAUSING",
    "RESULTS_IN": "CAUSING",
    "RESULTED_FROM": "CAUSING",
    "IMPLEMENTS": "CAUSING",
    "IMPLEMENTED_BY": "CAUSING",
    "BUILDS": "CAUSING",
    "BUILT_BY": "CAUSING",
    "SOLVES": "CAUSING",
    "SOLVED_BY": "CAUSING",
    "FIXES": "CAUSING",
    "FIXED_BY": "CAUSING",
    "RESOLVES": "CAUSING",
    "RESOLVED_BY": "CAUSING",
    "APPLIES": "CAUSING",
    "APPLIED_TO": "CAUSING",
    "EXECUTES": "CAUSING",

    # Extending / continuation
    "EXTENDS": "EXTENDING",
    "EXTENDED_BY": "EXTENDING",
    "CONTINUES": "EXTENDING",
    "CONTINUED_BY": "EXTENDING",
    "EXPANDS": "EXTENDING",
    "EXPANDED_BY": "EXTENDING",
    "ELABORATES": "EXTENDING",
    "ELABORATED_BY": "EXTENDING",
    "AUGMENTS": "EXTENDING",
    "AUGMENTED_BY": "EXTENDING",
    "SUPPLEMENTS": "EXTENDING",
    "SUPPLEMENTED_BY": "EXTENDING",
    "COMPLEMENTS": "EXTENDING",
    "COMPLEMENTED_BY": "EXTENDING",
    "REINFORCES": "EXTENDING",
    "REINFORCED_BY": "EXTENDING",
    "BUILDS_ON": "EXTENDING",
    "BUILT_ON": "EXTENDING",
    "ADDS_TO": "EXTENDING",

    # Opening / new trajectories
    "OPENS": "OPENING",
    "OPENED_BY": "OPENING",
    "INTRODUCES": "OPENING",
    "INTRODUCED_BY": "OPENING",
    "PIONEERS": "OPENING",
    "PIONEERED_BY": "OPENING",
    "INITIATES": "OPENING",
    "INITIATED_BY": "OPENING",
    "SPAWNS": "OPENING",
    "SPAWNED_BY": "OPENING",
    "LAUNCHES": "OPENING",
    "LAUNCHED_BY": "OPENING",
    "BEGINS": "OPENING",
    "STARTED_BY": "OPENING",
    "ORIGINATES": "OPENING",
    "ORIGINATES_FROM": "OPENING",
    "DIVERGES_FROM": "OPENING",
    "BRANCHES_FROM": "OPENING",
    "FORKS_FROM": "OPENING",

    # Common social/organizational edges -> INFORMING (default knowledge flow)
    "WORKS_AT": "INFORMING",
    "WORKS_FOR": "INFORMING",
    "EMPLOYED_BY": "INFORMING",
    "LIVES_IN": "INFORMING",
    "LOCATED_IN": "INFORMING",
    "LOCATED_AT": "INFORMING",
    "MANAGES": "INFORMING",
    "MANAGED_BY": "INFORMING",
    "REPORTS_TO": "INFORMING",
    "OWNS": "INFORMING",
    "OWNED_BY": "INFORMING",
    "USES": "INFORMING",
    "USED_BY": "INFORMING",
}


# -- Keyword-based fallback classifier ----------------------------------------
# Order matters: first match wins. More specific patterns come first.

KEYWORD_RULES: list[tuple[str, str]] = [
    # Temporal / backbone
    (r"(?i)NEXT_DAY", "NEXT_DAY"),

    # Nouns — specific causal events
    (r"(?i)(SEQUENCE|FOLLOW|PRECEDE|LEAD|STEP|FLOW|PROCEED|CHAIN|PROGRESS|TRANSITION)", "SEQUENCE"),
    (r"(?i)(EVOLV|TRANSFORM|BECAME|BECOME|GREW|DEVELOP|MATURE|REFIN|DEEPEN|EMERG)", "EVOLUTION"),
    (r"(?i)(DISCOVER|REVEAL|UNCOVER|FOUND|SURFACE|IDENTIF|BREAKTHROUGH|REALIZ)", "DISCOVERY"),
    (r"(?i)(RECOGNI|PARALLEL|MIRROR|ECHO|RESEMBL|SIMILAR|ANALOGOUS|MAP|CORRESPOND|RECUR|RESONAT|REFLECT)", "RECOGNITION"),
    (r"(?i)(VALIDAT|CONFIRM|SUPPORT|EVIDENCE|DEMONSTRAT|PROV[EI]|VERIF|SUBSTANTIAT)", "VALIDATION"),
    (r"(?i)(CHALLENG|CONTRADICT|CONFLICT|TENSION|OPPOS|DISRUPT|BLOCK|COMPLICAT|PROBLEMATIZ|UNDERMIN|LIMIT|RESIST)", "CHALLENGE"),

    # Gerunds — ongoing processes
    (r"(?i)(ENABL|FACILITAT|EMPOWER|UNLOCK|ALLOW|POSSIBLE|GROUND|PREPAR)", "ENABLING"),
    (r"(?i)(REQUIR|DEPEND|NEED|PREREQUISIT|CONSTRAIN|DEMAND)", "REQUIRING"),
    (r"(?i)(ENCOMPASS|CONTAIN|INCLUD|SUBSUM|WRAP|COVER|HOUS|EMBED|PART_OF|HAS_PART|BELONG|MEMBER|CATEGOR)", "ENCOMPASSING"),
    (r"(?i)(COMPOS|SYNTHESI|INTEGRAT|COMBIN|MERG|UNIF|CONVERG|BRIDG|CONNECT|LINK|WORK.*WITH|COLLABORAT|PAIR)", "COMPOSING"),
    (r"(?i)(INFORM|SHAP[EI]|INFLUENC|GUID|TEACH|INSPIR|MODEL|CONTEXTUALI|REFERENC|DRAW.*FROM|DERIV|RELAT|ASSOCIAT|RELEVANT|PERTAIN|KNOW)", "INFORMING"),
    (r"(?i)(CAUS[EI]|PRODUC|GENERAT|CREAT|TRIGGER|RESULT|IMPLEMENT|BUILD[^_]|SOLV|FIX|RESOLV|APPL|EXECUT)", "CAUSING"),
    (r"(?i)(EXTEND|CONTINU|EXPAND|ELABORAT|AUGMENT|SUPPLEMENT|COMPLEMENT|REINFORC|BUILD.*ON|ADD.*TO)", "EXTENDING"),
    (r"(?i)(OPEN|INTRODUC|PIONEER|INITIAT|SPAWN|LAUNCH|BEGIN|START|ORIGINAT|DIVERG|BRANCH|FORK)", "OPENING"),
]


def classify_relation_type(old_type: str) -> str:
    """Map an old freeform relationType string to one of the 15 canonical edge types."""
    # 1. Check explicit map first
    if old_type in EXPLICIT_MAP:
        return EXPLICIT_MAP[old_type]

    # 2. Already a valid type?
    if old_type in VALID_RELATION_TYPES:
        return old_type

    # 3. Keyword rules
    for regex, new_type in KEYWORD_RULES:
        if re.search(regex, old_type):
            return new_type

    # 4. Fallback — INFORMING is the most general "knowledge flow" edge
    return "INFORMING"


def get_all_relation_types(driver, database: str) -> list[dict]:
    """Query all distinct relationship types with their counts."""
    with driver.session(database=database) as session:
        result = session.run(
            """
            MATCH ()-[r]->()
            RETURN type(r) AS relationType, count(r) AS count
            ORDER BY count DESC
            """
        )
        return [{"relationType": record["relationType"], "count": record["count"]} for record in result]


def migrate_edge(driver, database: str, old_type: str, new_type: str, dry_run: bool) -> int:
    """Migrate edges from old_type to new_type.

    Neo4j relationship types are immutable — must create new edge, copy properties, delete old.
    Returns count of migrated edges.
    """
    if dry_run:
        with driver.session(database=database) as session:
            result = session.run(
                f"MATCH ()-[r:`{old_type}`]->() RETURN count(r) AS count"
            )
            return result.single()["count"]

    if old_type == new_type:
        # Already correct, nothing to migrate
        with driver.session(database=database) as session:
            result = session.run(
                f"MATCH ()-[r:`{old_type}`]->() RETURN count(r) AS count"
            )
            return result.single()["count"]

    # Full migration: create new edge with copied properties, delete old
    with driver.session(database=database) as session:
        result = session.run(
            f"""
            MATCH (a)-[old:`{old_type}`]->(b)
            CREATE (a)-[new:`{new_type}`]->(b)
            SET new = properties(old)
            DELETE old
            RETURN count(old) AS migrated
            """
        )
        return result.single()["migrated"]


def dedup_edges(driver, database: str, dry_run: bool) -> int:
    """Remove duplicate edges between the same (source, target) with the same type.

    When multiple old types collapse to the same canonical type, parallel duplicates
    appear. This keeps one edge per (source, target, type) triple and deletes the rest.

    Returns count of excess edges removed.
    """
    if dry_run:
        with driver.session(database=database) as session:
            result = session.run(
                """
                MATCH (a)-[r]->(b)
                WITH a, b, type(r) AS relType, collect(r) AS rels
                WHERE size(rels) > 1
                RETURN sum(size(rels) - 1) AS excess
                """
            )
            record = result.single()
            return record["excess"] if record["excess"] is not None else 0

    with driver.session(database=database) as session:
        result = session.run(
            """
            MATCH (a)-[r]->(b)
            WITH a, b, type(r) AS relType, collect(r) AS rels
            WHERE size(rels) > 1
            WITH rels[1..] AS duplicates
            UNWIND duplicates AS dup
            DELETE dup
            RETURN count(dup) AS removed
            """
        )
        return result.single()["removed"]


def main():
    parser = argparse.ArgumentParser(
        description="Migrate knowledge graph relationship types to 15 canonical edge types"
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview migration without making changes")
    parser.add_argument("--dedup-only", action="store_true", help="Only deduplicate edges (skip migration)")
    parser.add_argument("--uri", default=None, help="Neo4j URI (or NEO4J_URI env var)")
    parser.add_argument("--username", default=None, help="Neo4j username (or NEO4J_USERNAME env var)")
    parser.add_argument("--password", default=None, help="Neo4j password (or NEO4J_PASSWORD env var)")
    parser.add_argument("--database", default=None, help="Neo4j database (or NEO4J_DATABASE env var)")
    args = parser.parse_args()

    uri = args.uri or os.environ.get("NEO4J_URI") or os.environ.get("NEO4J_URL", "bolt://localhost:7687")
    username = args.username or os.environ.get("NEO4J_USERNAME", "neo4j")
    password = args.password or os.environ.get("NEO4J_PASSWORD", "password")
    database = args.database or os.environ.get("NEO4J_DATABASE", "neo4j")

    print(f"{'DRY RUN -- ' if args.dry_run else ''}{'Dedup only -- ' if args.dedup_only else ''}Edge migration in {uri} / {database}")
    print(f"Target taxonomy: {len(VALID_RELATION_TYPES)} edge types\n")

    driver = GraphDatabase.driver(uri, auth=(username, password))

    try:
        driver.verify_connectivity()
    except Exception as e:
        print(f"ERROR: Cannot connect to Neo4j: {e}", file=sys.stderr)
        sys.exit(1)

    # -- Dedup-only mode --
    if args.dedup_only:
        excess = dedup_edges(driver, database, dry_run=args.dry_run)
        if args.dry_run:
            print(f"Would remove {excess} duplicate edges.")
        else:
            print(f"Removed {excess} duplicate edges.")

        # Show final state
        post_types = get_all_relation_types(driver, database)
        total = sum(t["count"] for t in post_types)
        print(f"\nPost-dedup: {len(post_types)} types, {total} edges")
        for entry in post_types:
            marker = " ok" if entry["relationType"] in VALID_RELATION_TYPES else " UNEXPECTED"
            print(f"  {entry['relationType']:<20} {entry['count']:>4}{marker}")

        driver.close()
        return

    # -- Full migration mode --

    # Get all current relationship types
    all_types = get_all_relation_types(driver, database)
    total_edges = sum(t["count"] for t in all_types)
    print(f"Found {len(all_types)} distinct relationship types across {total_edges} edges\n")

    # Build migration plan
    summary: dict[str, int] = defaultdict(int)
    migrations: list[tuple[str, str, int]] = []

    for entry in all_types:
        old_type = entry["relationType"]
        new_type = classify_relation_type(old_type)
        count = entry["count"]

        if new_type not in VALID_RELATION_TYPES:
            print(f"  BUG: classify_relation_type('{old_type}') returned '{new_type}' which is not valid!", file=sys.stderr)
            sys.exit(1)

        migrations.append((old_type, new_type, count))
        summary[new_type] += count

    # Print migration plan
    print("-" * 80)
    print(f"{'Old Type':<55} -> {'New Type':<15} Count")
    print("-" * 80)

    for old_type, new_type, count in migrations:
        marker = "  " if old_type == new_type else "-> "
        print(f"  {old_type:<53} {marker}{new_type:<15} {count:>4}")

    print("-" * 80)
    print(f"\nSummary by new edge type:")
    for label in sorted(summary.keys()):
        print(f"  {label:<20} {summary[label]:>4} edges")
    print(f"  {'TOTAL':<20} {sum(summary.values()):>4} edges")
    print()

    if args.dry_run:
        # Also preview dedup
        excess = dedup_edges(driver, database, dry_run=True)
        if excess > 0:
            print(f"Post-migration dedup would remove ~{excess} duplicate edges.")
        print("\nDRY RUN complete -- no changes made.")
        driver.close()
        return

    # Execute migration
    print("Executing migration...")
    total_migrated = 0

    for old_type, new_type, expected_count in migrations:
        migrated = migrate_edge(driver, database, old_type, new_type, dry_run=False)
        total_migrated += migrated
        marker = "(unchanged)" if old_type == new_type else f"-> {new_type}"
        print(f"  {old_type} {marker}: {migrated} edges")

    print(f"\nMigration complete: {total_migrated} edges processed.")

    # Dedup pass — collapse parallel edges created by many-to-one type mapping
    print("\nDeduplicating parallel edges...")
    removed = dedup_edges(driver, database, dry_run=False)
    print(f"Removed {removed} duplicate edges.")

    # Verify
    post_types = get_all_relation_types(driver, database)
    total = sum(t["count"] for t in post_types)
    print(f"\nPost-migration: {len(post_types)} types, {total} edges")
    for entry in post_types:
        marker = " ok" if entry["relationType"] in VALID_RELATION_TYPES else " UNEXPECTED"
        print(f"  {entry['relationType']:<20} {entry['count']:>4}{marker}")

    driver.close()


if __name__ == "__main__":
    main()
