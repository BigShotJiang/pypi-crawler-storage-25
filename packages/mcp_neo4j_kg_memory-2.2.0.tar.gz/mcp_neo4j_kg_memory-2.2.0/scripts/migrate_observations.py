#!/usr/bin/env python3
"""One-time migration: move observations from string[] property to Observation sub-nodes.

Existing Memory nodes have `observations: string[]` property.
This script converts each string into an individual (:Observation {text: "..."})
node connected via [:HAS_OBSERVATION] relationship, then removes the array property.

Also recreates the fulltext index to span Memory|Observation.

Usage:
    python scripts/migrate_observations.py --dry-run   # preview changes
    python scripts/migrate_observations.py              # execute migration

Reads NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE from env vars.
"""

import argparse
import os
import sys

from dotenv import load_dotenv
from neo4j import GraphDatabase

# Load .env file from project root (or cwd)
load_dotenv()


# -- Analysis ------------------------------------------------------------------

def count_observations(driver, database: str) -> dict:
    """Count Memory nodes with observations and total observation strings."""
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (e:Memory)
            WHERE e.observations IS NOT NULL AND size(e.observations) > 0
            RETURN count(e) AS node_count, sum(size(e.observations)) AS total_obs
        """)
        record = result.single()
        return {
            "nodes_with_observations": record["node_count"],
            "total_observation_strings": record["total_obs"],
        }


def count_existing_subnodes(driver, database: str) -> dict:
    """Count existing Observation sub-nodes (from prior partial migration)."""
    with driver.session(database=database) as session:
        result = session.run("""
            MATCH (o:Observation)
            RETURN count(o) AS count
        """)
        obs_count = result.single()["count"]

        result2 = session.run("""
            MATCH (o:Observation)
            WHERE NOT (o)<-[:HAS_OBSERVATION]-(:Memory)
            RETURN count(o) AS orphans
        """)
        orphans = result2.single()["orphans"]

        return {
            "existing_observation_nodes": obs_count,
            "orphaned_observations": orphans,
        }


# -- Migration ----------------------------------------------------------------

def migrate_observations(driver, database: str, batch_size: int = 500) -> dict:
    """Migrate observations from array property to sub-nodes.

    For each Memory node with a non-empty observations array:
    1. UNWIND the array into individual strings
    2. MERGE Observation sub-nodes (idempotent for partial re-runs)
    3. REMOVE the observations property from the Memory node

    Processes in batches to handle large graphs.
    """
    total_nodes = 0
    total_obs = 0

    while True:
        with driver.session(database=database) as session:
            result = session.run(f"""
                MATCH (e:Memory)
                WHERE e.observations IS NOT NULL AND size(e.observations) > 0
                WITH e LIMIT {batch_size}
                WITH e, e.observations AS obs_list
                UNWIND obs_list AS obs_text
                MERGE (e)-[:HAS_OBSERVATION]->(o:Observation {{text: obs_text}})
                WITH e, count(o) AS obs_created
                REMOVE e.observations
                RETURN count(DISTINCT e) AS nodes_processed, sum(obs_created) AS obs_created
            """)
            record = result.single()
            nodes = record["nodes_processed"]
            obs = record["obs_created"]

            if nodes == 0:
                break

            total_nodes += nodes
            total_obs += obs
            print(f"  Batch: {nodes} nodes, {obs} observations migrated")

    return {"nodes_migrated": total_nodes, "observations_created": total_obs}


# -- Fulltext Index ------------------------------------------------------------

def migrate_fulltext_index(driver, database: str) -> None:
    """Drop old fulltext index and recreate spanning Memory|Observation."""
    with driver.session(database=database) as session:
        # Drop existing index
        try:
            session.run("DROP INDEX search IF EXISTS")
            print("  Dropped old fulltext index")
        except Exception as e:
            print(f"  Note: Could not drop old index: {e}")

        # Create new multi-label index
        session.run("""
            CREATE FULLTEXT INDEX search IF NOT EXISTS
            FOR (n:Memory|Observation)
            ON EACH [n.name, n.type, n.text]
        """)
        print("  Created new fulltext index (Memory|Observation)")


# -- Verification --------------------------------------------------------------

def verify_migration(driver, database: str) -> dict:
    """Verify migration completed correctly."""
    with driver.session(database=database) as session:
        # No Memory nodes should have observations property
        result = session.run("""
            MATCH (e:Memory) WHERE e.observations IS NOT NULL
            RETURN count(e) AS remaining
        """)
        remaining = result.single()["remaining"]

        # Count Observation nodes
        result2 = session.run("MATCH (o:Observation) RETURN count(o) AS count")
        obs_count = result2.single()["count"]

        # Verify all Observation nodes have a parent
        result3 = session.run("""
            MATCH (o:Observation)
            WHERE NOT (o)<-[:HAS_OBSERVATION]-(:Memory)
            RETURN count(o) AS orphans
        """)
        orphans = result3.single()["orphans"]

        # Count Memory nodes with at least one observation sub-node
        result4 = session.run("""
            MATCH (e:Memory)-[:HAS_OBSERVATION]->(o:Observation)
            RETURN count(DISTINCT e) AS nodes_with_obs
        """)
        nodes_with_obs = result4.single()["nodes_with_obs"]

        return {
            "memories_with_old_property": remaining,
            "total_observation_nodes": obs_count,
            "orphaned_observations": orphans,
            "memories_with_sub_nodes": nodes_with_obs,
        }


# -- Main ----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Migrate observations from array property to Observation sub-nodes"
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview migration without making changes")
    parser.add_argument("--uri", default=None, help="Neo4j URI (or NEO4J_URI env var)")
    parser.add_argument("--username", default=None, help="Neo4j username (or NEO4J_USERNAME env var)")
    parser.add_argument("--password", default=None, help="Neo4j password (or NEO4J_PASSWORD env var)")
    parser.add_argument("--database", default=None, help="Neo4j database (or NEO4J_DATABASE env var)")
    parser.add_argument("--batch-size", type=int, default=500, help="Batch size for migration (default 500)")
    args = parser.parse_args()

    uri = args.uri or os.environ.get("NEO4J_URI") or os.environ.get("NEO4J_URL", "bolt://localhost:7687")
    username = args.username or os.environ.get("NEO4J_USERNAME", "neo4j")
    password = args.password or os.environ.get("NEO4J_PASSWORD", "password")
    database = args.database or os.environ.get("NEO4J_DATABASE", "neo4j")

    print(f"{'DRY RUN -- ' if args.dry_run else ''}Observation sub-node migration in {uri} / {database}")

    driver = GraphDatabase.driver(uri, auth=(username, password))

    try:
        driver.verify_connectivity()
    except Exception as e:
        print(f"ERROR: Cannot connect to Neo4j: {e}", file=sys.stderr)
        sys.exit(1)

    # -- Analysis --
    print("\n--- Pre-migration analysis ---")
    counts = count_observations(driver, database)
    print(f"  Memory nodes with observations: {counts['nodes_with_observations']}")
    print(f"  Total observation strings: {counts['total_observation_strings']}")

    existing = count_existing_subnodes(driver, database)
    print(f"  Existing Observation sub-nodes: {existing['existing_observation_nodes']}")
    if existing["orphaned_observations"] > 0:
        print(f"  WARNING: {existing['orphaned_observations']} orphaned Observation nodes found")

    if counts["nodes_with_observations"] == 0:
        print("\nNothing to migrate — all observations are already sub-nodes (or no observations exist).")
        driver.close()
        return

    if args.dry_run:
        print(f"\nDRY RUN: Would migrate {counts['total_observation_strings']} observations "
              f"from {counts['nodes_with_observations']} Memory nodes to Observation sub-nodes.")
        print("DRY RUN complete -- no changes made.")
        driver.close()
        return

    # -- Migration --
    print("\n--- Migrating observations to sub-nodes ---")
    result = migrate_observations(driver, database, batch_size=args.batch_size)
    print(f"\nMigration complete: {result['nodes_migrated']} nodes, "
          f"{result['observations_created']} observation sub-nodes created.")

    # -- Fulltext index --
    print("\n--- Rebuilding fulltext index ---")
    migrate_fulltext_index(driver, database)

    # -- Verification --
    print("\n--- Post-migration verification ---")
    verification = verify_migration(driver, database)
    print(f"  Memories with old property: {verification['memories_with_old_property']}")
    print(f"  Total Observation nodes: {verification['total_observation_nodes']}")
    print(f"  Orphaned Observations: {verification['orphaned_observations']}")
    print(f"  Memories with sub-nodes: {verification['memories_with_sub_nodes']}")

    if verification["memories_with_old_property"] > 0:
        print(f"\n  WARNING: {verification['memories_with_old_property']} Memory nodes still have observations property!")
    if verification["orphaned_observations"] > 0:
        print(f"\n  WARNING: {verification['orphaned_observations']} orphaned Observation nodes!")

    if verification["memories_with_old_property"] == 0 and verification["orphaned_observations"] == 0:
        print("\n  Migration verified successfully.")

    driver.close()


if __name__ == "__main__":
    main()
