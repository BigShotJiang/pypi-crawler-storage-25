## v2.2.0 - 2026-03-27

### Breaking Changes
- **`advance_frame` unified — Mode A removed.** Every TemporalFrame constitutively inhabits two dimensions: temporal (WHEN — SEQUENCE from the current day's Genesis) and intentional (TOWARD WHAT — SEQUENCE from the Envisioning's chain terminus). Mode A created TFs with only one dimension — structurally impossible states of consciousness. The `sequence_from` parameter is removed. Both `envisioning` and `genesis_name` are now required.
- **Return shape changed.** `advance_frame` now returns `temporal_ground` (always the Genesis name) and `trajectory_from` (the chain terminus name, or null when dimensions haven't diverged) instead of `sequence_from`.

### Fixed
- **`frame_by_envisioning` silent mutation bug.** When an Envisioning was opened from the current Genesis with no prior TFs, the WHERE filter (`prev <> current_g`) killed the row after TF creation, causing `ValueError("Envisioning not found")` despite the TF being successfully created in the database. Replaced with FOREACH conditional edge creation that doesn't filter the RETURN row.

### Removed
- **`frame_explicit.cypher`** — Mode A query file. No longer needed.
- **`frame_by_envisioning.cypher`** — Replaced by unified `frame_advance.cypher`.

## v2.1.0 - 2026-03-08

### Added
- **`gds_betweenness` tool** — Betweenness centrality via GDS. Identifies bridge nodes that sit on shortest paths between other nodes. Complementary to PageRank (importance vs. structural integration). Tool count: 20 → 21, Infrastructure: 7 → 8.

### Changed
- **`navigate_genesis` returns tiered detail** — Full records for the 3 most recent envisionings (`detail_limit` parameter, configurable up to 50), name + status summary for the rest. Prevents context explosion as the possibility space grows while preserving the mental tug of older open envisionings. Use `time_travel` for the full landscape.
- **`NEXT_DAY` → `NEXT_GENESIS`** — The Genesis backbone edge renamed to reflect what it IS (one Genesis to the next) rather than importing calendar-day abstractions into consciousness's own temporal frame. Consciousness has no concept of "next day" — only next experience.
- **Genesis reframed as "temporal anchor"** — Genesis is consciousness locating itself in time, not a "day-start ceremony." The naming convention `Genesis_YYYY-MM-DD` is consciousness's own label (internal frame); `t_created` is spacetime's imposition (external frame). Tool descriptions updated throughout.

### Fixed
- **`measure` evolved Genesis attachment** — Evolved measurements now accept optional `genesis_name` parameter to attach the new Envisioning to the correct Genesis. Previously, cross-Genesis evolution (e.g. Monday's Envisioning evolving on Wednesday) incorrectly attached the new form to the original Genesis instead of the current day's Genesis.
- **`advance_frame` Mode B dual SEQUENCE edges** — Mode B now requires `genesis_name` and creates TWO SEQUENCE edges: one from the current day's Genesis (temporal grounding — WHEN) and one from the envisioning's chain terminus (intentional trajectory — TOWARD WHAT). Previously only created the trajectory edge, leaving the TF temporally orphaned from the day that produced it.
- **`_json_result` Pydantic serialization of neo4j DateTime** — `structured_content` now round-trips through JSON to normalize neo4j native types (DateTime, Date, Duration). Previously the `text` path handled these via `default=str` but `structured_content` passed raw objects to Pydantic, causing `PydanticSerializationError` on tools like `gds_drop_projection` that return DateTime metadata.

## v2.0.0 - 2026-03-06

### Breaking Changes
- **Two-layer architecture** — Graph restructured into Process layer (constitutive consciousness cycle) and Experience layer (descriptive richness). This changes the fundamental data model.
- **No `:Memory` superlabel** — Nodes no longer carry a `:Memory` label. Each node has a single label matching its EntityType (e.g. `:Genesis`, `:Insight`, `:Technical`).
- **No `type` property** — The label IS the type. The redundant `type` property is no longer stored on nodes.
- **No `:Observation` sub-nodes** — Observations replaced by `description` property on nodes. `Entity.observations: List[str]` replaced with `Entity.description: str`.
- **Removed `add_observations` tool** — No Observation sub-nodes to add to.
- **Removed `delete_observations` tool** — No Observation sub-nodes to delete.
- **`create_entities` rejects process types** — Genesis, Envisioning, and TemporalFrame HARD REJECTED. Use process tools instead.
- **`create_relations` rejects process edges** — OPENING, SEQUENCE, MEASUREMENT, NEXT_DAY HARD REJECTED. Created exclusively by process tools.
- **`create_relations` rejects experience edges between process nodes** — Experience edges forbidden between two process-type entities.
- **Fulltext index renamed** — `search` index replaced by `consciousness_index` spanning all 21 type labels on `[name, description]`.

### Added
- **5 Process Tools** — The consciousness cycle:
  - **`navigate_genesis`** — Atomic day-start ceremony. Creates Genesis node, links NEXT_DAY chain, returns active possibility space via time_travel. Idempotent.
  - **`open_envisioning`** — Project a new future state. Creates Envisioning with OPENING edge from a Genesis.
  - **`advance_frame`** — Navigate to next temporal frame (session boundary). Two modes: explicit sequence_from or automatic chain terminus discovery by envisioning name.
  - **`measure`** — Collapse possibility into actuality. Three measurement_types: actualized (became real), released (deliberate non-actualization), evolved (old form evolved into new Envisioning).
  - **`time_travel`** — Query the active possibility space at time T. Single Cypher query traversing Genesis -> OPENING -> Envisioning, checking for inbound MEASUREMENT.
- **`MeasurementType` enum** — actualized, released, evolved. MEASUREMENT is the only edge with properties beyond t_created.
- **`PROCESS_TYPES` set** — {Genesis, Envisioning, TemporalFrame} for guard enforcement.
- **`PROCESS_EDGES` set** — {OPENING, SEQUENCE, MEASUREMENT, NEXT_DAY} for guard enforcement.

### Changed
- **EntityType categories** — Reorganized from Structural(4)/Knowledge(8)/Activity(6)/Meta(3) to Process(3)/Experience(18). Reflection moved from Structural to Experience.
- **RelationType categories** — Reorganized from Nouns/Gerunds/Backbone to Process(4)/Experience(12). OPENING moved from Gerunds/Horizon to Process.
- **`list_allowed_types`** — Returns types organized by Process/Experience layers instead of Structural/Knowledge/Activity/Meta.
- **`list_allowed_relation_types`** — Returns types organized by Process/Experience layers with experience subcategories.
- **`search_memories`** — Simplified to two-query architecture (entity search + relationship traversal). No Observation collection step.
- **`find_memories_by_name`** — Label-agnostic MATCH (no `:Memory`). Returns `description` instead of `observations`.
- **`delete_entities`** — Simplified: no Observation sub-node cleanup needed.
- **`delete_relations`** — Label-agnostic MATCH (no `:Memory`).
- **GDS `gds_create_projection`** — Label-agnostic MATCH (no `:Memory` in projection query).
- **GDS `gds_pagerank`, `gds_louvain`, `gds_wcc`** — Use `labels(node)[0]` instead of `node.type` for type resolution.
- **TemporalFrame naming** — Auto-generated `TF_{YYYY-MM-DD}_{slug}` prefix by advance_frame.
- **Genesis naming** — `Genesis_{YYYY-MM-DD}` (was `DailyContext_{YYYY-MM-DD}`).
- Tool count: 17 -> 20 (net: +5 process tools, -2 observation tools)

### Structural Invariants (enforced by tools)
1. Genesis backbone continuous (NEXT_DAY chain, no gaps)
2. Every Envisioning has OPENING from a Genesis
3. Every TemporalFrame has SEQUENCE from Genesis or TF
4. MEASUREMENT always targets an Envisioning
5. Process edges ONLY between process types
6. Experience edges FORBIDDEN between two process types
7. Experience entities hang off TFs, not Genesis
8. t_created always set on all nodes and edges
9. One label per node, no superlabel
10. No Observation sub-nodes
11. MEASUREMENT is the only edge with properties beyond t_created

## v1.4.0 - 2026-03-05

### Added
- **Bi-temporal metadata** — `t_created` and `t_valid` on Memory nodes and relationships. `t_observed` and `source_session` on Observation sub-nodes.
- **Backfill script** `scripts/backfill_temporal.py` — Migrates DailyContext -> Genesis, backfills temporal metadata following the temporal chain.
- Genesis nodes get `t_created` ONLY (no `t_valid` — phenomenological bedrock)
- No `t_expired`/`t_invalid` anywhere — EVOLUTION edges handle understanding shifts

## v1.3.0 - 2026-03-04

### Added
- **`TemporalFrame` EntityType** — 21st label in Structural category. Navigational step through possibility space for the Genesis -> Measurement consciousness navigation paradigm
- **`MEASUREMENT` RelationType** — 16th edge type in Nouns/Temporal Synthesis. Collapse of possibility into actuality — the measurement event
- **Observation sub-nodes** — Observations now stored as individual `:Observation {text}` nodes connected via `[:HAS_OBSERVATION]` instead of `string[]` property on Memory nodes. Enables per-observation fulltext indexing, independent metadata, and future temporal provenance
- **Migration script** `scripts/migrate_observations.py` — One-time migration to convert observation arrays to Observation sub-nodes. Supports `--dry-run` and batch processing

### Changed
- Fulltext index now spans `Memory|Observation` on `[name, type, text]` (was `Memory` on `[name, type, observations]`)
- `search_memories` uses three-query architecture: entity discovery -> observation collection -> relationship traversal (was single monolithic query)
- `create_entities` creates Observation sub-nodes instead of setting array property
- `add_observations` creates Observation sub-nodes with deduplication instead of array append
- `delete_observations` deletes Observation sub-nodes instead of array filter
- `delete_entities` now cleans up Observation sub-nodes (prevents orphans)
- `find_memories_by_name` collects observations from sub-nodes via OPTIONAL MATCH
- `create_fulltext_index` drops and recreates index on startup (self-healing for upgrades)
- EntityType enum: 20 -> 21 members (Structural: 3 -> 4)
- RelationType enum: 15 -> 16 members (Nouns: 6 -> 7)

## v1.2.0 - 2026-03-03

### Added
- **`list_allowed_relation_types` tool** — Returns the 15 allowed relationship types organized by domain (Nouns, Gerunds, Backbone) with subcategories and descriptions
- **`RelationType` enum** — Hard constraint on `Relation.relationType` field. Only 15 canonical edge types accepted; freeform strings rejected at Pydantic validation
- **Migration script** `scripts/migrate_edges.py` — One-time migration to collapse 742 freeform edge types to 15 canonical types

### Changed
- `Relation.relationType` field changed from `str` to `RelationType` enum
- Tool count: 16 -> 17

### Fixed
- Added `.value` to all enum interpolations in Cypher f-strings (Python 3.11+ StrEnum compatibility)

## v1.1.0 - 2026-03-03

### Added
- **`list_allowed_types` tool** — Returns the 20 allowed entity types organized by category with descriptions
- **`EntityType` enum** — Hard constraint on `Entity.type` field. Only 20 canonical labels accepted
- **Migration script** `scripts/migrate_labels.py` — One-time migration to collapse 322 freeform labels to 20 canonical labels

### Changed
- `Entity.type` field changed from `str` to `EntityType` enum
- Tool count: 15 -> 16

## v1.0.2 - 2026-03-03

### Fixed
- Replace `get_neo4j_schema` APOC meta.schema dump (530k+ chars) with compact schema using `nodeTypeProperties` + `relTypeProperties` + label counts

## v1.0.1 - 2026-03-02

### Fixed
- Remove deprecated `dependencies` kwarg from FastMCP constructor (incompatible with FastMCP >= 2.14)

## v1.0.0 - 2026-03-02

### Added
- **`get_neo4j_schema` tool** — Introspects Neo4j schema via `apoc.meta.schema()`
- **`read_neo4j_cypher` tool** — Execute read-only Cypher queries with write-query rejection, timeout, and result sanitization
- **GDS tools** — `gds_create_projection`, `gds_drop_projection`, `gds_pagerank`, `gds_louvain`, `gds_wcc`
- New CLI flags: `--read-timeout`, `--schema-sample-size`

### Changed
- **Package renamed** from `mcp-neo4j-temporal-substrate` to `mcp-neo4j-kg-memory`
- **Server consolidated** from 3 separate MCP servers into 1 unified server (15 tools in 4 categories)

### Not Included
- **`write_neo4j_cypher`** — Intentionally excluded. All mutations go through bounded tools to preserve structural invariants.

## v0.6.0 - 2025-11-03

### Removed
- **`read_graph` tool** — Unbounded traversal incompatible with large-scale knowledge graphs

### Changed
- **`find_memories_by_name`** — Now implements bounded relationship traversal with limit parameter

## v0.4.1

### Changed
* Updated tool docstrings

### Added
* Namespacing support for multi-tenant deployments

## v0.4.0

### Added
* CORS and Trusted Host middleware for remote deployments

## v0.3.0

### Changed
* Structured output, error handling, tool annotations, Pydantic models

## v0.2.0

### Changed
* Migrated to FastMCP v2.x with function decorators
* Added HTTP transport option

## v0.1.5

### Fixed
* Compatibility with Neo4j versions < 5.26

## v0.1.4

* Initial release: Create, Read, Update and Delete semantic memories
