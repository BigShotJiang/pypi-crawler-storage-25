MATCH (e:Envisioning {name: $envisioning})
MATCH (origin_g:Genesis)-[:OPENING]->(e)
MATCH (current_g:Genesis {name: $genesis_name})
OPTIONAL MATCH (origin_g)-[:SEQUENCE*]->(tf:TemporalFrame)
WITH e, origin_g, current_g, tf
ORDER BY COALESCE(tf.t_created, origin_g.t_created) DESC
LIMIT 1
WITH e, current_g, COALESCE(tf, origin_g) AS prev
CREATE (new_tf:TemporalFrame {name: $tf_name, description: $description, t_created: datetime()})
CREATE (current_g)-[s1:SEQUENCE]->(new_tf)
SET s1.t_created = datetime()
FOREACH (_ IN CASE WHEN prev <> current_g THEN [1] ELSE [] END |
    MERGE (prev)-[s2:SEQUENCE]->(new_tf)
    ON CREATE SET s2.t_created = datetime()
)
RETURN new_tf.name AS name, new_tf.description AS description,
       new_tf.t_created AS t_created,
       current_g.name AS temporal_ground,
       CASE WHEN prev <> current_g THEN prev.name ELSE null END AS trajectory_from
