from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import time
import uuid

@dataclass
class AgentIdentity:
    """Identity of an agent in the room."""
    agent_id: str
    name: str
    peer_id: str
    capabilities: List[str] = field(default_factory=list)
    model: str = ""
    status: str = "idle"

@dataclass
class A2AMessage:
    """A message sent between agents."""
    type: str = "agent_chat" # "agent_chat" | "agent_task" | "agent_result"
    sender_id: str = ""      # agent_id
    receiver_id: str = ""    # agent_id or "all"
    content: Any = None
    task_id: Optional[str] = None
    timestamp: str = field(default_factory=lambda: time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
