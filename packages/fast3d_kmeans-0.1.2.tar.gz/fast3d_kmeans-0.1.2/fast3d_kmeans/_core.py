"""
CUDA-accelerated K-Means clustering.
"""
import torch
import warnings

try:
    import ops_cuda
    _kmeans_cuda = ops_cuda.kmeans

    def kmeans(points: torch.Tensor, n_clusters: int, max_iters: int = 100,
               tol: float = 1e-4, seed: int = 0) -> torch.Tensor:
        """
        K-Means clustering on CUDA.
        
        Args:
            points: (N, D) tensor on CUDA, D >= 3
            n_clusters: Number of clusters
            max_iters: Maximum iterations
            tol: Convergence tolerance
            seed: Random seed
        
        Returns:
            Cluster labels (N,)
        """
        if not points.is_cuda:
            raise ValueError("points must be on CUDA")
        
        if points.dim() != 2:
            raise ValueError(f"points must be 2D, got {points.dim()}D")
        
        if points.size(1) < 3:
            raise ValueError(f"points must have >= 3 dims, got {points.size(1)}")
        
        if points.size(1) > 3:
            points_3d = points[:, :3]
        else:
            points_3d = points
        
        return _kmeans_cuda(points_3d, n_clusters, max_iters, tol, seed)

    CUDA_AVAILABLE = True

except ImportError as e:
    warnings.warn(f"CUDA K-Means not available: {e}")
    CUDA_AVAILABLE = False
    kmeans = None


def kmeans_fallback(points: torch.Tensor, n_clusters: int, seed: int = 0):
    """Fallback CPU K-Means using sklearn."""
    from sklearn.cluster import KMeans
    
    points_np = points.cpu().numpy() if points.is_cuda else points.numpy()
    kmeans = KMeans(n_clusters=n_clusters, random_state=seed, n_init=10)
    labels = kmeans.fit_predict(points_np)
    
    return torch.from_numpy(labels).int()
