#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include <torch/extension.h>

#include <vector>
#include <random>
#include <algorithm>
#include <cmath>

#include "kmeans/kmeans_cuda.h"


namespace py = pybind11;


torch::Tensor kmeans_cuda(torch::Tensor points, int n_clusters, int max_iters = 100, float tol = 1e-4, unsigned int seed = 0) {
    // Input validation
    TORCH_CHECK(points.dim() == 2, "points must be a 2D tensor (N, 3)");
    TORCH_CHECK(points.size(1) == 3, "points must have 3 dimensions");
    TORCH_CHECK(points.is_cuda(), "points must be on CUDA device");

    int N = points.size(0);
    int K = n_clusters;

    // Initialize random engine
    std::mt19937 rng(seed);
    std::vector<int> indices(N);
    std::iota(indices.begin(), indices.end(), 0);
    std::shuffle(indices.begin(), indices.end(), rng);

    // Select initial centroids (random selection, K-Means++ can be added later)
    std::vector<float> centroids(K * 3);
    for (int k = 0; k < K; k++) {
        int idx = indices[k % N];  // Ensure we don't go out of bounds
        centroids[k * 3 + 0] = points[idx][0].item<float>();
        centroids[k * 3 + 1] = points[idx][1].item<float>();
        centroids[k * 3 + 2] = points[idx][2].item<float>();
    }

    // Allocate GPU memory
    torch::Tensor points_tensor = points.contiguous();
    
    // Create centroids tensor with proper memory management
    torch::Tensor centroids_cpu = torch::from_blob(centroids.data(), {K, 3}, torch::kFloat);
    torch::Tensor centroids_tensor = centroids_cpu.clone().cuda();  // Clone to own memory
    
    torch::Tensor labels_tensor = torch::zeros({N}, torch::dtype(torch::kInt32).device(torch::kCUDA));
    torch::Tensor counts_tensor = torch::zeros({K}, torch::dtype(torch::kInt32).device(torch::kCUDA));

    const float* points_ptr = points_tensor.data_ptr<float>();
    float* centroids_ptr = centroids_tensor.data_ptr<float>();
    int* labels_ptr = labels_tensor.data_ptr<int>();
    int* counts_ptr = counts_tensor.data_ptr<int>();

    // K-Means iterations
    std::vector<float> prev_centroids(K * 3);
    for (int iter = 0; iter < max_iters; iter++) {
        // Assignment step
        kmeans_assign_cuda(N, K, points_ptr, centroids_ptr, labels_ptr);

        // Store previous centroids for convergence check
        std::copy(centroids.begin(), centroids.end(), prev_centroids.begin());

        // Update step
        kmeans_update_cuda(N, K, points_ptr, labels_ptr, centroids_ptr, counts_ptr);

        // Copy updated centroids back to host for convergence check
        torch::Tensor centroids_cpu_copy = centroids_tensor.cpu();
        std::copy(centroids_cpu_copy.data_ptr<float>(), 
                  centroids_cpu_copy.data_ptr<float>() + K * 3, 
                  centroids.begin());

        // Check convergence
        float max_shift = 0.0f;
        for (int k = 0; k < K * 3; k++) {
            float shift = std::abs(centroids[k] - prev_centroids[k]);
            max_shift = std::max(max_shift, shift);
        }
        
        if (max_shift < tol) {
            break;
        }
    }

    return labels_tensor;
}


// Python module definition
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.doc() = "CUDA-accelerated K-Means clustering for point clouds";

    m.def("kmeans", &kmeans_cuda, 
          py::arg("points"), 
          py::arg("n_clusters"), 
          py::arg("max_iters") = 100, 
          py::arg("tol") = 1e-4,
          py::arg("seed") = 0,
          R"pbdoc(
    Perform K-Means clustering on CUDA tensors.
    
    Args:
        points (torch.Tensor): Input points of shape (N, 3)
        n_clusters (int): Number of clusters
        max_iters (int): Maximum number of iterations
        tol (float): Convergence tolerance
        seed (int): Random seed for initialization
    
    Returns:
        torch.Tensor: Cluster labels of shape (N,) with dtype int32
    )pbdoc");
}
