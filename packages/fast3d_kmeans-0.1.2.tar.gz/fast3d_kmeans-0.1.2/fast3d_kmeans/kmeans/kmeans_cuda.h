#ifndef KMEANS_CUDA_KERNEL_H
#define KMEANS_CUDA_KERNEL_H

#include <cuda_runtime.h>

// Forward declarations
void kmeans_assign_cuda(int n, int k, const float *points, const float *centroids, int *labels);
void kmeans_update_cuda(int n, int k, const float *points, const int *labels, float *centroids, int *counts);

#endif
