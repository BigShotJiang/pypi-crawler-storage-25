#include "../cuda_utils.h"
#include "kmeans_cuda.h"
#include <math.h>
#include <stdio.h>

#define THREADS_PER_BLOCK 256

__device__ __constant__ int MAX_K_CONST;

// Assignment: find nearest centroid for each point
__global__ void kmeans_assign_kernel(int n, int k, const float *points, const float *centroids, int *labels) {
    int pid = blockIdx.x * blockDim.x + threadIdx.x;
    if (pid >= n) return;

    const float *point = points + pid * 3;
    float min_dist = 1e10f;
    int best_k = 0;

    for (int ck = 0; ck < k; ck++) {
        const float *centroid = centroids + ck * 3;
        float dx = point[0] - centroid[0];
        float dy = point[1] - centroid[1];
        float dz = point[2] - centroid[2];
        float dist = dx * dx + dy * dy + dz * dz;

        if (dist < min_dist) {
            min_dist = dist;
            best_k = ck;
        }
    }

    labels[pid] = best_k;
}

// Update: compute new centroids using shared memory reduction
__global__ void kmeans_update_kernel(int n, int k, const float *points, const int *labels, float *centroids, int *counts) {
    int ck = blockIdx.x;
    
    // Each block handles one cluster, and within each block, 256 threads collaborate to process all the points.
    __shared__ float sum_x[THREADS_PER_BLOCK];
    __shared__ float sum_y[THREADS_PER_BLOCK];
    __shared__ float sum_z[THREADS_PER_BLOCK];
    __shared__ int cnt[THREADS_PER_BLOCK];

    int tid = threadIdx.x;

    sum_x[tid] = 0.0f;
    sum_y[tid] = 0.0f;
    sum_z[tid] = 0.0f;
    cnt[tid] = 0;

    __syncthreads();

    // Accumulation: With a step size of 256, to ensure no duplicate processing
    int stride = blockDim.x;
    for (int pid = tid; pid < n; pid += stride) {
        if (labels[pid] == ck) {
            atomicAdd(&sum_x[tid], points[pid * 3]);
            atomicAdd(&sum_y[tid], points[pid * 3 + 1]);
            atomicAdd(&sum_z[tid], points[pid * 3 + 2]);
            atomicAdd(&cnt[tid], 1);
        }
    }

    __syncthreads();

    // Parallel reduction: 256 -> 1
    if (tid < 128) {
        sum_x[tid] += sum_x[tid + 128];
        sum_y[tid] += sum_y[tid + 128];
        sum_z[tid] += sum_z[tid + 128];
        cnt[tid] += cnt[tid + 128];
    }
    __syncthreads();

    if (tid < 64) {
        sum_x[tid] += sum_x[tid + 64];
        sum_y[tid] += sum_y[tid + 64];
        sum_z[tid] += sum_z[tid + 64];
        cnt[tid] += cnt[tid + 64];
    }
    __syncthreads();

    if (tid < 32) {
        sum_x[tid] += sum_x[tid + 32];
        sum_y[tid] += sum_y[tid + 32];
        sum_z[tid] += sum_z[tid + 32];
        cnt[tid] += cnt[tid + 32];
    }
    __syncthreads();

    if (tid < 16) {
        sum_x[tid] += sum_x[tid + 16];
        sum_y[tid] += sum_y[tid + 16];
        sum_z[tid] += sum_z[tid + 16];
        cnt[tid] += cnt[tid + 16];
    }
    __syncthreads();

    if (tid < 8) {
        sum_x[tid] += sum_x[tid + 8];
        sum_y[tid] += sum_y[tid + 8];
        sum_z[tid] += sum_z[tid + 8];
        cnt[tid] += cnt[tid + 8];
    }
    __syncthreads();

    if (tid < 4) {
        sum_x[tid] += sum_x[tid + 4];
        sum_y[tid] += sum_y[tid + 4];
        sum_z[tid] += sum_z[tid + 4];
        cnt[tid] += cnt[tid + 4];
    }
    __syncthreads();

    if (tid < 2) {
        sum_x[tid] += sum_x[tid + 2];
        sum_y[tid] += sum_y[tid + 2];
        sum_z[tid] += sum_z[tid + 2];
        cnt[tid] += cnt[tid + 2];
    }
    __syncthreads();

    if (tid < 1) {
        sum_x[tid] += sum_x[tid + 1];
        sum_y[tid] += sum_y[tid + 1];
        sum_z[tid] += sum_z[tid + 1];
        cnt[tid] += cnt[tid + 1];
    }
    __syncthreads();

    // Update centroid
    if (tid == 0) {
        int total_cnt = cnt[0];
        if (total_cnt > 0) {
            centroids[ck * 3] = sum_x[0] / total_cnt;
            centroids[ck * 3 + 1] = sum_y[0] / total_cnt;
            centroids[ck * 3 + 2] = sum_z[0] / total_cnt;
        }
        counts[ck] = total_cnt;
    }
}

void kmeans_assign_cuda(int n, int k, const float *points, const float *centroids, int *labels) {
    dim3 blocks(DIVUP(n, THREADS_PER_BLOCK));
    dim3 threads(THREADS_PER_BLOCK);
    kmeans_assign_kernel<<<blocks, threads>>>(n, k, points, centroids, labels);
    cudaDeviceSynchronize();
}

void kmeans_update_cuda(int n, int k, const float *points, const int *labels, float *centroids, int *counts) {
    dim3 blocks(k);
    dim3 threads(THREADS_PER_BLOCK);
    kmeans_update_kernel<<<blocks, threads>>>(n, k, points, labels, centroids, counts);
    cudaDeviceSynchronize();
}
