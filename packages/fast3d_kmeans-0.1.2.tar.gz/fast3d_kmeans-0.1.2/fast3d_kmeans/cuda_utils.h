#ifndef CUDA_UTILS_H
#define CUDA_UTILS_H

#include <cuda_runtime.h>
#include <stdio.h>

#define THREADS_PER_BLOCK 256

inline int DIVUP(int x, int y) {
    return (x + y - 1) / y;
}

// CUDA error checking
#define CUDA_CHECK(call)                                                         \
    do {                                                                         \
        cudaError_t err = call;                                                  \
        if (err != cudaSuccess) {                                                 \
            fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__,      \
                    cudaGetErrorString(err));                                      \
            exit(EXIT_FAILURE);                                                   \
        }                                                                         \
    } while (0)

#endif
