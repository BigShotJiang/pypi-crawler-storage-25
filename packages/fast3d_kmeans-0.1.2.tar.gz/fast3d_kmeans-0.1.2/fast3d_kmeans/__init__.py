import sys
import torch


def _ensure_cuda_extension():
    if 'ops_cuda' not in sys.modules:
        if torch.cuda.is_available():
            from torch.utils.cpp_extension import load
            import os

            cuda_arch = [f"-arch=sm_{torch.cuda.get_device_capability()[0]}{torch.cuda.get_device_capability()[1]}"]
            print("[fast3d_kmeans] Building CUDA extension (this may take a minute)...")
            ops_cuda = load(
                name='ops_cuda',
                sources=[
                    os.path.join(os.path.dirname(__file__), 'kmeans_binding.cpp'),
                    os.path.join(os.path.dirname(__file__), 'kmeans', 'kmeans_cuda.cu'),
                ],
                extra_cflags=['-std=c++17'],
                extra_cuda_cflags=['-O3', '--use_fast_math', '-std=c++17'] + cuda_arch,
                verbose=False,
            )
            sys.modules['ops_cuda'] = ops_cuda
            print("[fast3d_kmeans] CUDA extension built successfully!")


if torch.cuda.is_available():
    _ensure_cuda_extension()

from ._core import kmeans, kmeans_fallback, CUDA_AVAILABLE

__all__ = ['kmeans', 'kmeans_fallback', 'CUDA_AVAILABLE']
