from setuptools import setup, find_packages

setup(
    name="Fast3D-KMeans",
    version="0.1.2",
    description="CUDA-accelerated K-Means clustering for 3D point clouds",
    author="Mingzhe Sui",
    author_email="suimingzhe0331@163.com",
    url="https://github.com/Sailkiki/Fast3D-KMeans",
    packages=find_packages(),
    package_data={
        'fast3d_kmeans': ['*.cpp', '*.h', '*.cu', '*.py'],
        'fast3d_kmeans.kmeans': ['*.cu', '*.h', '*.py'],
    },
    install_requires=[
        'torch>=1.9.0',
        'numpy',
    ],
    python_requires='>=3.8',
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: C++',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Scientific/Engineering :: Visualization',
        'Topic :: Multimedia :: Graphics :: 3D Modeling',
        'Topic :: Multimedia :: Graphics :: 3D Rendering',
    ],
    keywords='kmeans clustering point-cloud 3d-vision cuda gpu-acceleration',
)
