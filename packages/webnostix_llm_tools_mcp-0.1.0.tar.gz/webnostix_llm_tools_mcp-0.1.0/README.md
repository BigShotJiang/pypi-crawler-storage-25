# webnostix-llm-tools-mcp

MCP server that exposes Claude (Anthropic) as callable MCP tools so workflows can perform LLM operations — summarisation, extraction, transformation, etc.

## Installation

```bash
pip install webnostix-llm-tools-mcp
```

## Usage

```bash
ANTHROPIC_API_KEY=sk-... webnostix-llm-tools-mcp
```

## Tools

- `llm_call` — Call a Claude model with a prompt
- `llm_extract` — Extract structured data from text as JSON

## MCP Aggregator config

```json
{
  "command": "webnostix-llm-tools-mcp",
  "env": { "ANTHROPIC_API_KEY": "sk-..." }
}
```