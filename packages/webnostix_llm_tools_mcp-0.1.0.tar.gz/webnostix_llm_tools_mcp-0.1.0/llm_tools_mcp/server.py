"""
llm-tools MCP Server
Exposes Claude (Anthropic) as callable MCP tools so workflows can perform
LLM operations — summarisation, extraction, transformation, etc. — as a
first-class step alongside any other MCP tool.

Usage:
    ANTHROPIC_API_KEY=sk-... python server.py

Registration in MCP Aggregator:
    Command : python
    Args    : ["/path/to/mcp-servers/llm-tools/server.py"]
    Env     : { "ANTHROPIC_API_KEY": "sk-..." }
"""

from fastmcp import FastMCP
import anthropic
import os
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("llm-tools")

# ---------------------------------------------------------------------------
# Server + client
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="llm-tools",
    instructions=(
        "Provides tools for calling Claude LLMs directly. "
        "Use these steps in workflows to summarise, transform, extract, "
        "or generate text using a language model."
    ),
)

_client: anthropic.Anthropic | None = None


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY environment variable is not set. "
                "Add it to the server's environment in MCP Aggregator settings."
            )
        _client = anthropic.Anthropic(api_key=api_key)
    return _client


# ---------------------------------------------------------------------------
# Available Claude models (for documentation / dropdown hints)
# ---------------------------------------------------------------------------

MODELS = [
    "claude-opus-4-5-20250514",
    "claude-sonnet-4-5-20250514",
    "claude-haiku-4-5-20250514",
    "claude-3-5-sonnet-20241022",
    "claude-3-5-haiku-20241022",
]


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def llm_call(
    prompt: str,
    system: str = "",
    model: str = "claude-opus-4-5-20250514",
    max_tokens: int = 1024,
    temperature: float = 1.0,
) -> str:
    """
    Call a Claude model with a prompt and return its response as plain text.

    Args:
        prompt      : The user message / main prompt. Supports {{variable}} and
                      {{stepN.content[0].text}} bindings from previous workflow steps.
        system      : Optional system prompt. Use this to give the model a persona
                      or behavioural constraint, e.g. "You are a concise assistant
                      that always responds in bullet points."
        model       : Claude model to use. Options: claude-opus-4-5,
                      claude-sonnet-4-5, claude-haiku-4-5,
                      claude-3-5-sonnet-20241022, claude-3-5-haiku-20241022,
                      claude-3-opus-20240229. Defaults to claude-opus-4-5.
        max_tokens  : Maximum number of tokens in the response. Default 1024.
                      Increase for longer outputs (e.g. full email drafts).
        temperature : Sampling temperature between 0.0 and 1.0. Use 0.0 for
                      deterministic/factual tasks, higher values for creative
                      output. Defaults to 1.0 (Claude default).

    Returns:
        The model's response as a plain text string.
    """
    client = get_client()

    kwargs: dict = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }

    if temperature != 1.0:
        kwargs["temperature"] = temperature

    if system:
        kwargs["system"] = system

    try:
        message = client.messages.create(**kwargs)
        return message.content[0].text
    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        raise RuntimeError(f"LLM call failed: {e}") from e


@mcp.tool()
def llm_extract(
    text: str,
    fields: str,
    model: str = "claude-haiku-4-5",
    max_tokens: int = 512,
) -> str:
    """
    Extract structured information from text and return it as JSON.

    Useful for pulling out names, dates, action items, key facts, etc.
    from raw tool outputs before passing them to another step.

    Args:
        text   : The source text to extract from. Typically bound from a
                 previous step via {{stepN.content[0].text}}.
        fields : Comma-separated list of fields to extract, e.g.
                 "name, email, due_date, action_items".
        model  : Claude model to use. Defaults to claude-haiku-4-5 (fast + cheap).
        max_tokens : Max tokens for the response. Default 512.

    Returns:
        A JSON string with the extracted fields as keys.
    """
    client = get_client()

    system = (
        "You are a precise data extraction assistant. "
        "Extract the requested fields from the provided text and return "
        "ONLY a valid JSON object with those fields as keys. "
        "If a field is not found, use null as its value. "
        "Do not include any explanation or markdown — raw JSON only."
    )

    prompt = f"Extract the following fields: {fields}\n\nText:\n{text}"

    try:
        message = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
        )
        return message.content[0].text
    except Exception as e:
        logger.error(f"LLM extract failed: {e}")
        raise RuntimeError(f"LLM extract failed: {e}") from e


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    mcp.run()


if __name__ == "__main__":
    main()
