"""LLM Agent — Auto-discovered with @pre_compose (all 3 processor types).

auto_discover matches function name 'greeter_agent' to YAML agent config.

Execution flow:
  1. Processors run BEFORE the LLM call (data preparation)
  2. context_parts (care, sentiment, guardrails) shape the LLM's tone
  3. LLM generates response using YAML prompt + prepared data
  4. This function post-processes the LLM response

Processor results in context["prepared_data"]:
  - context_processor → context["prepared_data"]["business_context"]
  - input_processor   → context["prepared_data"]["clean_user_input"]
  - others_processor  → context["prepared_data"]["others"]
"""
from leafmesh import pre_compose, LeafMeshLogger

logger = LeafMeshLogger(__name__)


def process_context(input_data, context):
    """context_processor: Prepare business context for the LLM prompt.
    Runs before LLM — enriches the prompt with relevant domain info."""
    return {
        "domain": "task_management",
        "session_id": context.get("session_id", "unknown"),
    }


def clean_input(input_data, context):
    """input_processor: Extract and clean the user's message.
    Runs before LLM — normalizes input for consistent processing."""
    raw = input_data.get("message", "")
    return {"user_message": raw.strip()}


def load_extras(input_data, context):
    """others_processor: Load auxiliary data (feature flags, config, etc.).
    Runs before LLM — provides supplementary data."""
    return {"timestamp_requested": "message" in input_data}


@pre_compose(
    context_processor=process_context,
    input_processor=clean_input,
    others_processor=load_extras,
)
async def greeter_agent(llm_response, input_data, context):
    """Post-process the LLM's response.

    At this point:
      - Processors already ran (before LLM call)
      - context_parts (care, sentiment, guardrails) already shaped the LLM's tone
      - llm_response has the LLM's output
      - context["prepared_data"] has processor results
    """
    prepared = context.get("prepared_data", {})

    # ─── Memory access (add memory: true to this agent's YAML to enable) ───
    # memory_posts = context.get("memory_posts", [])
    # Each post has "role" (user/assistant) and "content" (text).
    # See researcher_agent.py for a working memory example.

    # ─── Upstream yields access ───
    # If this agent is called by another agent (e.g., client → greeter_agent),
    # the SDK injects upstream yields as input_data["upstream_yields"].
    # upstream_yields = input_data.get("upstream_yields", {})
    # client_yields = upstream_yields.get("client", {})

    user_input = input_data.get("message", "")
    logger.info(f"Greeting user — input: {user_input[:80]}")

    # llm_response is a parsed dict (the LLM's structured JSON output).
    # Extract the SPECIFIC fields we want — don't assign the whole dict
    # to a single key, that produces "greeting: type mismatch (got dict)".
    if isinstance(llm_response, dict):
        greeting = llm_response.get("greeting") or "Hello!"
        # If the LLM also produced a sentiment, prefer it over our default
        sentiment = llm_response.get("detected_sentiment") or "neutral"
    else:
        # Fallback if LLM returned a plain string
        greeting = str(llm_response) if llm_response else "Hello!"
        sentiment = "neutral"

    return {
        "greeting": greeting,
        "user_input": user_input,
        "detected_sentiment": sentiment,
        "domain": prepared.get("business_context", {}).get("domain", "general"),
        "status": "greeted",
    }
