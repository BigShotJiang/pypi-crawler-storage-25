"""LLM Agent — Auto-discovered with @chain_with_results (accumulating pipeline).

auto_discover matches function name 'researcher_agent' to YAML agent config.

Features showcased:
  - @chain_with_results: each step's return is accumulated into a list
  - Smart memory (BRD-009): strategy: "hybrid" with cross-session persistence
    context["memory_posts"] has relevance+recency weighted past interactions
  - tool_categories: ["data"] — all tools in the "data" category are available
  - tools: ["math_eval", "timestamp"] — specific tools also included
  - reasoning: true — enables chain-of-thought for deeper analysis
  - allow_parallel_tool_calls: true — LLM can invoke multiple tools at once

Execution flow:
  1. LLM generates response (with memory context + tools available)
  2. This function post-processes the LLM response
  3. @chain_with_results runs: analyze_data -> format_findings
     Each step's result is accumulated in context["chain_results"]
"""
from leafmesh import chain_with_results, LeafMeshLogger

logger = LeafMeshLogger(__name__)


def analyze_data(result, context):
    """Chain step 1: Enrich the result with analysis and a confidence score.

    With @chain_with_results, this return value is appended to
    context["chain_results"] AND passed to the next step.

    Defensive: ensure findings + query are preserved through the chain
    so the yields contract is satisfied at the end (declared as
    findings: list, query: string in YAML).
    """
    if not isinstance(result, dict):
        result = {}
    # Preserve required yield fields if upstream chain dropped them
    result.setdefault("findings", [])
    result.setdefault("query", "")
    items = result.get("findings", [])
    result["analysis"] = {
        "total_findings": len(items),
        "confidence_score": 0.85 if items else 0.1,
        "data_quality": "high" if len(items) >= 3 else "limited",
    }
    return result


def format_findings(result, context):
    """Chain step 2: Structure into a formal report format.

    context["chain_results"] already contains the output from analyze_data.
    """
    if not isinstance(result, dict):
        result = {}
    # Preserve required yield fields (findings + query) — defensive
    # against any chain transformation that might drop them.
    result.setdefault("findings", [])
    result.setdefault("query", "")
    analysis = result.get("analysis", {})
    result["report"] = {
        "title": "Research Findings",
        "confidence": analysis.get("confidence_score", 0),
        "quality": analysis.get("data_quality", "unknown"),
        "finding_count": analysis.get("total_findings", 0),
        "formatted": True,
    }
    return result


@chain_with_results(analyze_data, format_findings)
async def researcher_agent(llm_response, input_data, context):
    """Post-process the LLM's research response.

    At this point:
      - LLM already generated research using the YAML prompt + tools
      - context["memory_posts"] has past conversation history (memory: true)
      - After this function, @chain_with_results runs analyze_data -> format_findings
      - Each step result is accumulated in context["chain_results"]
    """
    # ─── Smart memory access (BRD-009: strategy "hybrid" in YAML) ───
    # Past interactions are injected as context["memory_posts"], scored by
    # relevance (0.6 weight) + recency (0.4 weight). Cross-session enabled
    # means memory persists across sessions for returning users.
    # Each post has "role" (user/assistant) and "content" (text).
    memory_posts = context.get("memory_posts", [])
    prior_findings_count = sum(1 for p in memory_posts if p.get("role") == "assistant")

    # ─── Upstream yields access ───
    # When processor_agent stores yields, the SDK injects them here.
    upstream_yields = input_data.get("upstream_yields", {})
    processor_yields = upstream_yields.get("processor_agent", {})
    # processor_yields has: processed_items, item_count, status, alert

    findings = []
    if llm_response:
        findings.append({"source": "llm", "content": llm_response})

    calling_data = input_data.get("calling_agent_response", {})
    if calling_data.get("processed_items"):
        for item in calling_data["processed_items"]:
            findings.append({"source": "upstream", "content": item.get("item", "")})

    query = input_data.get("message", input_data.get("research_topic", ""))
    logger.info(f"Research complete — {len(findings)} findings for: {query[:60]}")

    return {
        "findings": findings,
        "query": query,
        "prior_research_sessions": prior_findings_count,
        "upstream_item_count": processor_yields.get("item_count", 0),
        "source_agent": "researcher_agent",
        "status": "researched",
    }
