"""Programmatic Agent — Pure Python, no LLM, @conditional_chain branching.

auto_discover matches function name 'processor_agent' to YAML agent config.
parallel: true is set in config.yaml — enables concurrent execution.

All agent functions use the 3-param signature: (llm_response, input_data, context)
For programmatic agents, llm_response is always None (no LLM is called).

Data flow:
  greeter_agent returns output → SDK evaluates can_call rules →
  SDK passes output as input_data to this agent automatically.

Upstream yields:
  When greeter_agent stores yields (greeting, user_input, detected_sentiment),
  the SDK injects them as input_data["upstream_yields"][calling_agent_name].
  This gives downstream agents typed access to structured data from upstream.
"""
from leafmesh import conditional_chain, LeafMeshLogger

logger = LeafMeshLogger(__name__)


def handle_urgent(result, context):
    """Conditional chain: runs only when urgent items exist."""
    urgent = [i for i in result.get("processed_items", []) if i["category"] == "urgent"]
    result["urgent_items"] = urgent
    result["alert"] = f"{len(urgent)} urgent item(s) flagged"
    return result


def handle_normal(result, context):
    """Conditional chain: runs when no urgent items."""
    result["alert"] = "No urgent items"
    return result


@conditional_chain(
    lambda result, ctx: any(i["category"] == "urgent" for i in result.get("processed_items", [])),
    handle_urgent,
    handle_normal,
)
async def processor_agent(llm_response, input_data, context):
    """Process the greeter's output into structured action items.

    Pure Python processing — no LLM cost.
    llm_response is always None for programmatic agents.
    With parallel: true, multiple invocations run concurrently.

    After this function returns, @conditional_chain runs either
    handle_urgent or handle_normal based on the result.
    Then SDK evaluates can_call rules to chain to the next agent.
    """
    # SDK passes the calling agent's output directly as input_data.
    # "calling_agent_response" is a virtual variable only in YAML condition evaluation.

    # ─── Upstream yields access ───
    # When greeter_agent has yields defined in YAML, the SDK auto-injects them:
    upstream_yields = input_data.get("upstream_yields", {})
    greeter_yields = upstream_yields.get("greeter_agent", {})
    # greeter_yields has: greeting, user_input, detected_sentiment, status
    detected_sentiment = greeter_yields.get("detected_sentiment", "unknown")

    # Robust user_input extraction — covers all 4 invocation paths:
    #   1. CAN_CALL chain from client (HITL): input_data.human_message
    #   2. CAN_CALL chain from greeter: input_data.upstream_yields[greeter_agent].user_input
    #   3. NARRATION ROUTING from greeter (Summarizer-driven): input_data
    #      IS greeter's output dict directly — look at top-level user_input
    #   4. ENTRY POINT direct: input_data.message
    # If ALL are empty, we still produce 1 item so the chain progresses
    # (item_count=0 used to cascade into fan-in-unsatisfiable → loop →
    # escalation, which is worse than processing a placeholder).
    user_input = (
        input_data.get("human_message", "")
        or greeter_yields.get("user_input", "")
        or input_data.get("user_input", "")
        or input_data.get("message", "")
        or input_data.get("greeting", "")
    )
    logger.info(
        f"processor input keys={list(input_data.keys())}; "
        f"resolved user_input={user_input[:80]!r}"
    )

    # Extract items: prefer comma-separated list, fall back to single
    # item from whole utterance, fall back to placeholder.
    raw_items = [item.strip() for item in user_input.split(",") if item.strip()]
    if not raw_items:
        # No commas OR empty input → produce ONE item so item_count >= 1
        # and downstream can_call conditions (item_count > 0) succeed.
        # This unblocks the chain even on conversational / empty input.
        raw_items = [user_input.strip() or "general inquiry"]

    categorized = []
    for item in raw_items:
        categorized.append({
            "item": item,
            "category": "urgent" if any(w in item.lower() for w in ["asap", "urgent", "now"]) else "normal",
        })

    urgent_count = sum(1 for i in categorized if i["category"] == "urgent")
    logger.info(f"Processed {len(categorized)} items ({urgent_count} urgent)")

    # Set alert here as a safe default so the yields contract is always
    # satisfied. handle_urgent / handle_normal (the @conditional_chain
    # branches) override this with a more specific message — but if
    # the chain wrapper doesn't run for any reason (rerun path, error
    # recovery), the field is still present.
    default_alert = (
        f"{urgent_count} urgent item(s) flagged"
        if urgent_count > 0 else "No urgent items"
    )

    return {
        "processed_items": categorized,
        "item_count": len(categorized),
        "alert": default_alert,
        "source_agent": "greeter_agent",
        "upstream_sentiment": detected_sentiment,
        "status": "processed",
    }
