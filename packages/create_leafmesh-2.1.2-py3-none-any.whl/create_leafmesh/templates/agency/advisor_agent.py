"""LLM Agent — Auto-discovered with @chain + @compose (OR fan-in advisor).

auto_discover matches function name 'advisor_agent' to YAML agent config.

Features showcased:
  - @chain: sequential post-processing pipeline (validate_inputs -> score_priorities)
  - @compose: inject helper functions into context (report shaping, alert shaping)
  - wait_for: "processor_agent AND (researcher_agent OR fallback_researcher_agent)"
  - OR fan-in: whichever research agent finishes first satisfies the expression
  - optimization_strategy: "performance" — prioritizes quality over cost

Execution flow:
  1. Fan-in: SDK waits for processor_agent AND (researcher OR fallback_researcher)
  2. fallback_researcher_agent is instant → OR resolves immediately
  3. LLM analyzes combined upstream results
  4. This function post-processes, picking the best research source
  5. @compose injects shape_report and shape_alerts into context
  6. @chain runs: validate_inputs -> score_priorities (sequential pipeline)

Fan-in patterns (all supported by the SDK):
  wait_for: "A AND B"                  — waits for both A and B
  wait_for: "A OR B"                   — waits for either A or B (first wins)
  wait_for: "A AND B?"                 — A required, B optional
  wait_for: "A AND (B OR C)"           — A required + first of B or C (used here)
  wait_for: "A AND (B OR C) AND D?"    — A required + first of B/C + D optional
"""
from leafmesh import chain, compose, LeafMeshLogger

logger = LeafMeshLogger(__name__)


def validate_inputs(result, context):
    """Chain step 1: Validate that upstream data is present and well-formed."""
    if not result.get("recommendations"):
        result["recommendations"] = ["No specific recommendations available"]
    if not result.get("risk_assessment"):
        result["risk_assessment"] = "Unable to assess — insufficient data"
    result["validated"] = True
    return result


def score_priorities(result, context):
    """Chain step 2: Score and rank recommendations by priority."""
    recs = result.get("recommendations", [])
    result["priority_score"] = min(1.0, len(recs) * 0.2) if recs else 0.0
    result["next_steps"] = recs[:3] if recs else ["Gather more data"]
    result["scored"] = True
    return result


def shape_report(data, context):
    """Compose helper: Shape output for report consumption."""
    return {
        "title": "Advisory Report",
        "recommendations": data.get("recommendations", []),
        "risk_assessment": data.get("risk_assessment", ""),
        "priority_score": data.get("priority_score", 0),
        "project": "{{project_name}}",
    }


def shape_alerts(data, context):
    """Compose helper: Shape output for alerting systems."""
    score = data.get("priority_score", 0)
    return {
        "alert_level": "high" if score > 0.7 else "medium" if score > 0.4 else "low",
        "summary": data.get("risk_assessment", ""),
        "action_required": score > 0.5,
    }


@chain(validate_inputs, score_priorities)
@compose(report=shape_report, alerts=shape_alerts)
async def advisor_agent(llm_response, input_data, context):
    """Analyze upstream results and produce actionable recommendations.

    At this point:
      - Fan-in complete: processor_agent AND (researcher OR fallback) finished
      - input_data["upstream_yields"] has yields from all contributing agents
      - context["report"] and context["alerts"] are injected by @compose
      - After this function, @chain runs validate_inputs -> score_priorities
    """
    # ─── Fan-in upstream yields ───
    # For OR fan-in, the SDK includes yields from whichever agents completed.
    # Check both research agents — prefer LLM researcher (higher confidence).
    upstream_yields = input_data.get("upstream_yields", {})
    processor_yields = upstream_yields.get("processor_agent", {})
    researcher_yields = upstream_yields.get("researcher_agent", {})
    fallback_yields = upstream_yields.get("fallback_researcher_agent", {})

    # ─── Pick the best research source ───
    # LLM researcher has confidence 0.85, fallback has 0.6
    skipped_agents = []
    if researcher_yields and researcher_yields.get("status") == "researched":
        research_data = researcher_yields
        research_source = "researcher_agent"
        research_confidence = 0.85
    elif fallback_yields and fallback_yields.get("status") == "researched":
        research_data = fallback_yields
        research_source = "fallback_researcher_agent"
        research_confidence = 0.6
        skipped_agents.append("researcher_agent")
    else:
        research_data = {}
        research_source = "none"
        research_confidence = 0.0
        skipped_agents.extend(["researcher_agent", "fallback_researcher_agent"])

    # ─── Build recommendations from upstream data ───
    processed_items = processor_yields.get("processed_items", [])
    findings = research_data.get("findings", [])

    recommendations = []
    if processed_items:
        urgent = [i for i in processed_items if i.get("category") == "urgent"]
        if urgent:
            recommendations.append(f"Address {len(urgent)} urgent item(s) immediately")
        recommendations.append(f"Review {len(processed_items)} processed items")

    if findings:
        recommendations.append(f"Incorporate {len(findings)} research finding(s)")

    risk = "low"
    if any(i.get("category") == "urgent" for i in processed_items):
        risk = "elevated — urgent items detected"

    logger.info(f"Advisory complete — {len(recommendations)} recommendations, risk={risk}, source={research_source}")

    return {
        "recommendations": recommendations,
        "risk_assessment": risk,
        "research_source": research_source,
        "research_confidence": research_confidence,
        "skipped_agents": skipped_agents,
        "source_data": {
            "processed_count": len(processed_items),
            "finding_count": len(findings),
        },
        "status": "advised",
    }

# ─── Alternative: @chain_with_results ───
# If you want to accumulate results from each chain step:
#
# from leafmesh import chain_with_results
#
# @chain_with_results(validate_inputs, score_priorities)
# async def advisor_agent(llm_response, input_data, context):
#     # After execution, context["chain_results"] has a list of
#     # each step's return value: [validate_result, score_result]
#     ...
