"""Programmatic Agent — Cron-scheduled, chains to advisor for analysis.

auto_discover matches function name 'scheduler_agent' to YAML agent config.

Features showcased:
  - wake_up: "0 9 * * *" — cron expression triggers this agent automatically
  - communication_type: "chain" — output chains to advisor_agent via can_call
  - Entry point: mesh_call("scheduled_report", ...) for on-demand reports
  - No LLM, no external deps — pure Python on a schedule

Use cases for scheduled agents:
  - Daily/weekly report generation → chain to LLM agent for analysis
  - Health checks and alerting → chain to human agent for review
  - Periodic data aggregation → chain to downstream processors

All agent functions use the 3-param signature: (llm_response, input_data, context)
For programmatic agents, llm_response is always None.
input_data will be empty on scheduled runs (no upstream caller).
On-demand runs via mesh_call("scheduled_report", data) will have input_data.
"""
from datetime import datetime, timezone
from leafmesh import LeafMeshLogger

logger = LeafMeshLogger(__name__)


async def scheduler_agent(llm_response, input_data, context):
    """Generate a status report with mesh metrics.

    This runs on the cron schedule defined in config.yaml AND can be
    triggered on-demand via mesh_call("scheduled_report", data).

    communication_type: "chain" means the result is forwarded to
    advisor_agent via can_call for LLM-powered analysis.
    """
    now = datetime.now(timezone.utc)
    trigger = input_data.get("trigger", "scheduled")

    # ─── Gather mesh metrics ───
    # In production, you'd pull real metrics from your data sources.
    # The advisor_agent receives this as input_data and analyzes it.
    checks = {
        "system_status": "healthy",
        "scheduled_run": trigger == "scheduled",
        "on_demand": trigger != "scheduled",
    }

    metrics = {
        "report_time": now.isoformat(),
        "trigger_type": trigger,
        "uptime_hours": 24,
        "total_requests_today": 0,
        "error_rate": 0.0,
    }

    logger.info(f"Report generated ({trigger}) — status={checks['system_status']}")

    return {
        "report": f"Status report ({trigger}) at {now.isoformat()}",
        "generated_at": now.isoformat(),
        "checks": checks,
        "metrics": metrics,
        "processed_items": [
            {"item": f"Daily {trigger} report", "category": "normal"},
        ],
        "status": "report_generated",
    }
