"""Programmatic Agent — Fast template-based research fallback (no LLM).

auto_discover matches function name 'fallback_researcher_agent' to YAML agent config.

Features showcased:
  - Programmatic agent: pure Python, no LLM call, instant response
  - OR fan-in: advisor_agent uses wait_for: "processor_agent AND (researcher_agent OR fallback_researcher_agent)"
  - Race pattern: this agent completes instantly while researcher_agent waits for LLM
  - Mirrors researcher_agent's output schema so advisor_agent can consume either

Execution flow:
  1. processor_agent fans out to researcher_agent AND fallback_researcher_agent
  2. This agent returns immediately with template-based findings
  3. researcher_agent is still waiting for LLM response
  4. advisor_agent's OR expression resolves — it proceeds with fallback data
  5. researcher_agent result arrives later (already resolved, ignored by fan-in)
"""
from leafmesh import chain, LeafMeshLogger

logger = LeafMeshLogger(__name__)


def enrich_findings(result, context):
    """Chain step: Add analysis metadata to template findings."""
    findings = result.get("findings", [])
    result["analysis"] = {
        "total_findings": len(findings),
        "confidence_score": 0.6,
        "data_quality": "template",
        "source_type": "fallback_template",
    }
    result["report"] = {
        "title": "Fallback Research Findings",
        "confidence": 0.6,
        "quality": "template",
        "finding_count": len(findings),
        "formatted": True,
    }
    return result


@chain(enrich_findings)
async def fallback_researcher_agent(llm_response, input_data, context):
    """Instant template-based research — no LLM needed.

    Provides a fast fallback so the advisor_agent can proceed immediately
    via OR fan-in without waiting for the slower LLM-based researcher_agent.
    """
    upstream_yields = input_data.get("upstream_yields", {})
    processor_yields = upstream_yields.get("processor_agent", {})

    calling_data = input_data.get("calling_agent_response", {})
    processed_items = calling_data.get("processed_items", [])

    # Build template-based findings from upstream data
    findings = []
    for item in processed_items:
        findings.append({
            "source": "template",
            "content": item.get("item", ""),
            "recommendation": f"Review and address: {item.get('item', 'unknown')}",
        })

    if not findings:
        findings.append({
            "source": "template",
            "content": "No specific items to research",
            "recommendation": "Gather more information from the user",
        })

    logger.info(f"Fallback research — {len(findings)} template findings")

    return {
        "findings": findings,
        "query": input_data.get("message", input_data.get("research_topic", "")),
        "upstream_item_count": processor_yields.get("item_count", 0),
        "source_agent": "fallback_researcher_agent",
        "source_type": "fallback_template",
        "status": "researched",
    }
