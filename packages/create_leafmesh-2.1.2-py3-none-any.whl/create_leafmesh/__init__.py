"""create-leafmesh — Project scaffolding tool for LeafMesh."""

__version__ = "2.1.2"
