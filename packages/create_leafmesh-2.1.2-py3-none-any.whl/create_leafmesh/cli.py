"""CLI entry point for create-leafmesh."""

import argparse
import re
import sys
import time

from create_leafmesh import __version__
from create_leafmesh.create import create_project

# ---------------------------------------------------------------------------
# ANSI helpers (graceful fallback on terminals that don't support color)
# ---------------------------------------------------------------------------
_CYAN   = "\033[36m"
_GREEN  = "\033[32m"
_WHITE  = "\033[97m"
_DIM    = "\033[2m"
_BOLD   = "\033[1m"
_RESET  = "\033[0m"

def _c(code: str, text: str) -> str:
    """Wrap text in an ANSI code, reset after."""
    return f"{code}{text}{_RESET}"


# ---------------------------------------------------------------------------
# ASCII art — block letters for LEAFMESH
# ---------------------------------------------------------------------------
BANNER = r"""
  ██╗     ███████╗ █████╗ ███████╗███╗   ███╗███████╗███████╗██╗  ██╗
  ██║     ██╔════╝██╔══██╗██╔════╝████╗ ████║██╔════╝██╔════╝██║  ██║
  ██║     █████╗  ███████║█████╗  ██╔████╔██║█████╗  ███████╗███████║
  ██║     ██╔══╝  ██╔══██║██╔══╝  ██║╚██╔╝██║██╔══╝  ╚════██║██╔══██║
  ███████╗███████╗██║  ██║██║     ██║ ╚═╝ ██║███████╗███████║██║  ██║
  ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝     ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝
"""

def print_banner(version: str) -> None:
    print()
    print(_c(_CYAN, BANNER), end="")
    pad = " " * 2
    print(f"{pad}  create-leafmesh {_c(_DIM, 'v' + version)}   "
          f"{_c(_DIM, 'Agent mesh scaffolding tool')}")
    print(f"{pad}  " + "-" * 55)
    print()


# ---------------------------------------------------------------------------
# Step progress printer
# ---------------------------------------------------------------------------
def step(n: int, total: int, label: str, done: bool = False) -> None:
    status = _c(_GREEN, "[ OK ]") if done else _c(_DIM, "[    ]")
    print(f"  {status}  [{n}/{total}]  {label}")


def step_done(n: int, total: int, label: str) -> None:
    print(f"\033[1A\r  {_c(_GREEN, '[ OK ]')}  [{n}/{total}]  {label}")


# ---------------------------------------------------------------------------
# File tree renderer
# ---------------------------------------------------------------------------
FILE_TREE = """\
  {name}/
  |-- agency/
  |   |-- greeter_agent.py
  |   |-- processor_agent.py
  |   |-- researcher_agent.py
  |   |-- advisor_agent.py
  |   |-- fallback_researcher_agent.py
  |   `-- scheduler_agent.py
  |-- configs/
  |   `-- config.yaml
  |-- main.py
  |-- hitl_stub_receiver.py
  |-- requirements.txt
  |-- .env
  |-- Dockerfile
  `-- docker-compose.yml"""


# ---------------------------------------------------------------------------
# Next-steps box
# ---------------------------------------------------------------------------
def print_success_box(project_name: str, missing_keys: list[str]) -> None:
    w = 58

    def row(text: str = "") -> str:
        return f"  |  {text:<{w - 4}}|"

    def div() -> str:
        return "  +" + "-" * (w - 2) + "+"

    def header(text: str) -> str:
        return "  |  " + _c(_GREEN, _c(_BOLD, f"{text:<{w - 4}}")) + "|"

    print()
    print(div())
    print(header(f"Project ready: {project_name}"))
    print(div())
    print(row())
    print(row(f"  cd {project_name}"))
    print(row(f"  pip install -r requirements.txt"))
    if missing_keys:
        print(row())
        print(row(f"  # Add to .env before starting:"))
        for k in missing_keys:
            print(row(f"  #   {k}=<your-key>"))
    print(row())
    print(row(f"  Terminal 1:   python hitl_stub_receiver.py"))
    print(row(f"  Terminal 2:   python main.py"))
    print(row())
    print(row(f"  Open:         http://127.0.0.1:18820/docs"))
    print(row())
    print(div())
    print(row(f"  Docs:         https://leafcraft.ai/docs"))
    print(div())
    print()


# ---------------------------------------------------------------------------
# Validation / prompts
# ---------------------------------------------------------------------------
def validate_project_name(name: str) -> str:
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9_-]*$", name):
        raise argparse.ArgumentTypeError(
            f"Invalid project name '{name}'. "
            "Must start with a letter and contain only alphanumeric characters, "
            "hyphens, or underscores."
        )
    return name


def prompt_project_name() -> str:
    while True:
        name = input("  Project name: ").strip()
        if not name:
            print("  Name cannot be empty.")
            continue
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9_-]*$", name):
            print("  Must start with a letter, letters/numbers/hyphens/underscores only.")
            continue
        return name


def prompt_env_vars() -> dict:
    w = 55
    print()
    print("  " + "-" * w)
    print(f"  {'Environment setup':^{w}}")
    print(f"  {'(press Enter to skip any field)':^{w}}")
    print("  " + "-" * w)
    print()

    env_vars: dict = {}

    fields = [
        ("LEAFMESH_LICENSE_KEY",  "License key    (https://leafcraft.ai): "),
        ("LEAFMESH_ENV_TOKEN",    "Env token      (https://leafcraft.ai): "),
        ("OPENAI_API_KEY",        "OpenAI key     (https://platform.openai.com): "),
        ("ANTHROPIC_API_KEY",     "Anthropic key  (optional): "),
    ]

    for key, label in fields:
        val = input(f"  {label}").strip()
        if val:
            env_vars[key] = val

    print()
    return env_vars


# ---------------------------------------------------------------------------
# Main create flow
# ---------------------------------------------------------------------------
def _run_create(project_name: str | None, output_dir: str, no_git: bool) -> int:
    print_banner(__version__)

    if project_name is None:
        project_name = prompt_project_name()
        print()
    else:
        try:
            project_name = validate_project_name(project_name)
        except argparse.ArgumentTypeError as e:
            print(f"  Error: {e}")
            return 1

    env_vars = prompt_env_vars()

    # Hand off to create_project, passing our step-printer so it can report progress
    print(f"  Creating {_c(_BOLD, project_name + '/')}")
    print()

    result = create_project(
        project_name,
        output_dir,
        init_git=not no_git,
        env_vars=env_vars,
        step_fn=step,
        step_done_fn=step_done,
    )

    if result != 0:
        return result

    # File tree — print line by line with dim so pipe chars aren't swallowed
    print()
    for line in FILE_TREE.format(name=project_name).splitlines():
        print(_c(_DIM, line))

    # Success box
    missing = [k for k in ("LEAFMESH_LICENSE_KEY", "OPENAI_API_KEY") if k not in env_vars]
    print_success_box(project_name, missing)

    return 0


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="create-leafmesh",
        description="Project scaffolding tool for LeafMesh",
        epilog="""
examples:
  create-leafmesh my-project              Create a new project
  create-leafmesh my-project -o /tmp      Create in a specific directory
  create-leafmesh                         Interactive mode
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"create-leafmesh {__version__}")
    parser.add_argument("project_name", nargs="?", default=None, help="Project name")
    parser.add_argument("-o", "--output-dir", default=".", help="Output directory (default: current)")
    parser.add_argument("--no-git", action="store_true", help="Skip git init")

    args = parser.parse_args(argv)
    try:
        return _run_create(args.project_name, args.output_dir, args.no_git)
    except KeyboardInterrupt:
        print("\n\n  Cancelled.\n")
        return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n  Cancelled.\n")
        sys.exit(0)
