"""Project scaffolding logic."""

import re
import shutil
import subprocess
from pathlib import Path
from typing import Callable

TEMPLATES_DIR = Path(__file__).parent / "templates"

RENAME_MAP = {
    "env": ".env",
    "gitignore": ".gitignore",
    "dockerignore": ".dockerignore",
}

SUBSTITUTE_EXTENSIONS = {".py", ".yaml", ".yml", ".txt", ".md", ".env", ""}

ENV_PLACEHOLDERS = {
    "LEAFMESH_LICENSE_KEY": "your-license-key-here",
    "LEAFMESH_ENV_TOKEN":   "your-env-token-here",
    "OPENAI_API_KEY":       "your-key-here",
    "ANTHROPIC_API_KEY":    "your-anthropic-key",
}

# Step labels — order matches execution
_STEPS = [
    "Copying template files",
    "Writing .env",
    "Setting up git repository",
    "Installing Claude Code skill",
]
_TOTAL = len(_STEPS)


def _noop(*args, **kwargs) -> None:
    pass


def create_project(
    project_name: str,
    output_dir: str,
    *,
    init_git: bool = True,
    env_vars: dict | None = None,
    step_fn: Callable = _noop,
    step_done_fn: Callable = _noop,
) -> int:
    target = Path(output_dir).resolve() / project_name

    if target.exists():
        print(f"\n  Error: '{target}' already exists.\n")
        return 1

    # Step 1 — copy template
    step_fn(1, _TOTAL, _STEPS[0])
    shutil.copytree(TEMPLATES_DIR, target)
    for path in target.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix not in SUBSTITUTE_EXTENSIONS:
            continue
        text = path.read_text(encoding="utf-8")
        if "{{project_name}}" in text:
            path.write_text(text.replace("{{project_name}}", project_name), encoding="utf-8")
    step_done_fn(1, _TOTAL, _STEPS[0])

    # Step 2 — .env
    step_fn(2, _TOTAL, _STEPS[1])
    if env_vars:
        env_file = target / "env"
        if env_file.exists():
            text = env_file.read_text(encoding="utf-8")
            for key, value in env_vars.items():
                placeholder = ENV_PLACEHOLDERS.get(key)
                if placeholder and placeholder in text:
                    text = text.replace(placeholder, value)
                    text = text.replace(f"# {key}={value}", f"{key}={value}")
                elif f"# {key}=" in text:
                    text = re.sub(rf"# {re.escape(key)}=.*", f"{key}={value}", text)
            env_file.write_text(text, encoding="utf-8")
    for old_name, new_name in RENAME_MAP.items():
        src = target / old_name
        if src.exists():
            src.rename(target / new_name)
    step_done_fn(2, _TOTAL, _STEPS[1])

    # Step 3 — git
    step_fn(3, _TOTAL, _STEPS[2])
    if init_git:
        try:
            subprocess.run(["git", "init", str(target)], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
    step_done_fn(3, _TOTAL, _STEPS[2])

    # Step 4 — Claude skill
    step_fn(4, _TOTAL, _STEPS[3])
    claude_skills_src = target / "claude_skills"
    if claude_skills_src.exists():
        claude_dir = target / ".claude" / "skills"
        claude_dir.parent.mkdir(parents=True, exist_ok=True)
        claude_skills_src.rename(claude_dir)
    step_done_fn(4, _TOTAL, _STEPS[3])

    return 0
