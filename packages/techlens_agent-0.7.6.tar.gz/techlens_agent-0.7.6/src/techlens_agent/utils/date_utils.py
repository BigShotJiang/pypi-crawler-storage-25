from datetime import date, datetime, timedelta
from typing import Optional, Tuple, Union


def ensure_dates_are_in_bound(
    start: Optional[Union[str, date, datetime]] = None,
    end: Optional[Union[str, date, datetime]] = None,
    max_days: int = 364,
) -> Tuple[date, date]:
    if end:
        # If 'end' is provided, handle different possible input types (str, date, datetime)
        if isinstance(end, str):
            # If string, parse from ISO format
            end_date = date.fromisoformat(end)
        elif isinstance(end, datetime):
            # If datetime object, convert to date (discarding time)
            end_date = end.date()
        elif isinstance(end, date):
            # If already a date object, use it directly
            end_date = end
        else:
            # Raise an error if the type is unrecognized
            raise TypeError(f"End date must be str, date, or datetime, got {type(end)}")
    else:
        # Fallback: use today's date if end date is not set
        end_date = date.today()

    # Calculate the SAFE maximum start date (End Date - max_days)
    # This prevents the total period from exceeding the limit.
    safe_start_date = end_date - timedelta(days=max_days)

    if start:
        # Convert configured start date to a date object for comparison
        if isinstance(start, str):
            config_start_date = date.fromisoformat(start)
        elif isinstance(start, datetime):
            config_start_date = start.date()
        elif isinstance(start, date):
            config_start_date = start
        else:
            raise TypeError(
                f"Start date must be str, date, or datetime, got {type(start)}"
            )

        # Check if the configured start date is too early (i.e., interval > max_days)
        if config_start_date < safe_start_date:
            # Correction: Use the safe start date to enforce the limit
            start_date = safe_start_date
        else:
            # If the configured date is later (a narrower, safe interval), use it
            start_date = config_start_date
    else:
        # If start is not set, use the safe default
        start_date = safe_start_date

    return start_date, end_date
