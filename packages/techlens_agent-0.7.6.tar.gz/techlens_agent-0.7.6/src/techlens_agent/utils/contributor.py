"""Contributor attribution utilities.

Parse commit metadata (author identity, co-author trailers, bot detection)
and aggregate per-developer statistics.
"""

from __future__ import annotations

import re
from collections import defaultdict

# ---------------------------------------------------------------------------
# Identity parsing
# ---------------------------------------------------------------------------

_IDENTITY_RE = re.compile(r"^(.+?)\s*<([^>]+)>$")


def parse_identity(raw: str) -> tuple[str, str]:
    """Parse ``"Name <email>"`` into ``(name, email)``.

    Returns ``(raw.strip(), "")`` when angle-bracket format is not matched.
    """
    raw = raw.strip()
    m = _IDENTITY_RE.match(raw)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return raw, ""


# ---------------------------------------------------------------------------
# Co-author trailer extraction
# ---------------------------------------------------------------------------

_CO_AUTHOR_RE = re.compile(
    r"^co-authored-by:\s*(.+?)\s*<([^>]+)>",
    re.IGNORECASE | re.MULTILINE,
)


def parse_co_authors(message: str) -> list[tuple[str, str]]:
    """Extract ``Co-authored-by:`` trailers from a commit message body.

    Returns a list of ``(name, email)`` tuples.
    """
    return [
        (m.group(1).strip(), m.group(2).strip())
        for m in _CO_AUTHOR_RE.finditer(message)
    ]


# ---------------------------------------------------------------------------
# Bot detection
# ---------------------------------------------------------------------------

_KNOWN_BOTS: frozenset[str] = frozenset(
    {
        "dependabot",
        "renovate",
        "greenkeeper",
        "snyk-bot",
        "github-actions",
        "codecov",
        "mergify",
        "semantic-release-bot",
        "pre-commit-ci",
        "copilot",
    }
)

_BOT_NOREPLY_RE = re.compile(
    r"^\d+\+.+\[bot\]@users\.noreply\.github\.com$", re.IGNORECASE
)


def is_bot_account(name: str, email: str) -> bool:
    """Heuristically detect bot accounts.

    Checks for:
    - ``[bot]`` suffix in name
    - Known bot names (dependabot, renovate, etc.)
    - GitHub noreply addresses with bot-like usernames
    """
    lower_name = name.lower()
    lower_email = email.lower()

    if lower_name.endswith("[bot]"):
        return True

    # Strip trailing [bot] variant in email local part
    local = lower_email.split("@")[0] if "@" in lower_email else ""
    if local.endswith("[bot]"):
        return True

    if lower_name in _KNOWN_BOTS or local in _KNOWN_BOTS:
        return True

    if _BOT_NOREPLY_RE.match(lower_email):
        return True

    return False


# ---------------------------------------------------------------------------
# Contributor summary aggregation
# ---------------------------------------------------------------------------


def build_contributor_summary(commits: list[dict]) -> dict:
    """Aggregate per-developer statistics from enriched commit dicts.

    Each *commit* dict must have:
    ``author_name``, ``author_email``, ``co_authors`` (list of (name, email)),
    ``merge_contributors`` (list of (name, email)), ``is_merge`` (bool),
    ``insertions`` (int), ``deletions`` (int), ``files`` (int), ``date`` (str YYYY-MM-DD or YYYY-MM).

    Returns a summary dict with ``developers``, ``total_developers``,
    ``human_developers``, ``bot_developers``, and ``concentration_pct``.
    """
    devs: dict[str, dict] = {}

    def _ensure(name: str, email: str) -> dict:
        email_lower = email.strip().lower()
        key = email_lower if email_lower else f"name:{name.strip().lower()}"
        if key not in devs:
            devs[key] = {
                "name": name,
                "email": email_lower,
                "authored_commits": 0,
                "co_authored_commits": 0,
                "merge_commits": 0,
                "insertions": 0,
                "deletions": 0,
                "files_touched": 0,
                "is_bot": is_bot_account(name, email),
                "monthly_activity": defaultdict(int),
            }
        return devs[key]

    for c in commits:
        author_name = c.get("author_name", "")
        author_email = c.get("author_email", "")
        co_authors = c.get("co_authors", [])
        merge_contributors = c.get("merge_contributors", [])
        is_merge = c.get("is_merge", False)
        insertions = c.get("insertions", 0)
        deletions = c.get("deletions", 0)
        files = c.get("files", 0)
        date = c.get("date", "")
        month = date[:7] if len(date) >= 7 else date

        # Primary author
        dev = _ensure(author_name, author_email)
        dev["authored_commits"] += 1
        dev["insertions"] += insertions
        dev["deletions"] += deletions
        dev["files_touched"] += files
        if month:
            dev["monthly_activity"][month] += 1
        if is_merge:
            dev["merge_commits"] += 1

        # Co-authors
        for ca_name, ca_email in co_authors:
            ca_dev = _ensure(ca_name, ca_email)
            ca_dev["co_authored_commits"] += 1
            if month:
                ca_dev["monthly_activity"][month] += 1

        # Merge contributors (feature-branch authors)
        for mc_name, mc_email in merge_contributors:
            _ensure(mc_name, mc_email)

    # Convert defaultdicts to plain dicts for serialization
    for d in devs.values():
        d["monthly_activity"] = dict(d["monthly_activity"])

    total = len(devs)
    bots = sum(1 for d in devs.values() if d["is_bot"])
    humans = total - bots

    # Concentration: top-3 developer share of authored commits
    concentration = 0.0
    total_authored = sum(d["authored_commits"] for d in devs.values())
    if total_authored > 0:
        top3 = sorted(
            (d["authored_commits"] for d in devs.values()),
            reverse=True,
        )[:3]
        concentration = round(sum(top3) / total_authored, 4)

    return {
        "developers": devs,
        "total_developers": total,
        "human_developers": humans,
        "bot_developers": bots,
        "concentration_pct": concentration,
    }
