"""Self-contained diff content processing.

Tokenizes file content with Pygments, runs counting logic + formulas.
Returns a 5-tuple for backwards compatibility with git_metrics.py:
(metrics_dict, filename, lexer_name, tokens, internal_store)
"""

from __future__ import annotations

import logging
import sys

logger = logging.getLogger(__name__)

from pygments import lexers

from techlens_agent.analysis.formulas import (
    calc_halstead,
    calc_maintainability_index,
    calc_pylint,
    calc_tiobe,
)
from techlens_agent.analysis.signals.cyclomatic_analyzer import (
    _compute_comment_ratio,
    _compute_cyclomatic,
    _compute_loc,
)
from techlens_agent.analysis.signals.fanout_analyzer import _parse_imports
from techlens_agent.analysis.signals.operand_operator_analyzer import (
    _OPERAND_SET,
    _OPERATOR_SET,
)


def process_diff_content(
    _content: str,
    _file: str,
    _args=None,
    _importer=None,
    ignore_errors: bool = True,
) -> tuple[dict, str, str, list, dict]:
    """Process file content and return metrics.

    Returns a 5-tuple for backwards compatibility with git_metrics.py:
    (metrics_dict, filename, lexer_name, tokens, internal_store)
    """
    res: dict = {}
    store: dict = {}

    try:
        _lexer = lexers.get_lexer_for_filename(_file)
    except Exception as e:
        if ignore_errors or (
            _args is not None and getattr(_args, "ignore_lexer_errors", True)
        ):
            print("Processing unknown file type: " + _file, file=sys.stderr)
            return (res, _file, "unknown", [], store)
        else:
            raise e

    try:
        tokens = list(_lexer.get_tokens(_content))
        lexer_name = _lexer.name

        # --- Metric modules (inline) ---

        # Cyclomatic complexity
        cc = _compute_cyclomatic(tokens)
        res["cyclomatic_complexity"] = cc

        # LOC
        loc_result = _compute_loc(lexer_name, tokens)
        res.update(loc_result)

        # Comment ratio
        res["comment_ratio"] = _compute_comment_ratio(lexer_name, tokens)

        # Fanout
        int_set, ext_set = _parse_imports(lexer_name, tokens)
        res["fanout_internal"] = len(int_set)
        res["fanout_external"] = len(ext_set)

        # Operands & operators
        operands: list[str] = []
        operators: list[str] = []
        for tok_type, tok_val in tokens:
            type_str = str(tok_type)
            if type_str in _OPERAND_SET:
                operands.append(str(tok_val))
            elif type_str in _OPERATOR_SET:
                operators.append(str(tok_val))

        res["operands_sum"] = len(operands)
        res["operands_uniq"] = len(set(operands))
        res["operators_sum"] = len(operators)
        res["operators_uniq"] = len(set(operators))

        # --- Calculation modules ---
        calc_halstead(res)
        calc_maintainability_index(res)
        calc_tiobe(res)
        calc_pylint(res)

    except Exception:
        logger.debug("Error computing metrics for %s", _file, exc_info=True)
        res = {}
        tokens = []

    return (res, _file, _lexer.name, tokens, store)
