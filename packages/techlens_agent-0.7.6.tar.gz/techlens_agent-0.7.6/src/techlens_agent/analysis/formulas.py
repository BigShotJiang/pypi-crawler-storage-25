"""Pure calculation functions for code quality metrics.

These are called by signal analyzers (per-file) AND stats.py._compute_overall()
(global), which is why they live in a shared module.
"""

from __future__ import annotations

import math


def calc_halstead(metrics: dict, bug_method: str = "new") -> dict:
    """Compute Halstead volume, difficulty, effort, time, and bug propensity.

    Input keys: operands_sum, operands_uniq, operators_sum, operators_uniq
    Output keys added to *metrics*: halstead_volume, halstead_difficulty,
    halstead_effort, halstead_timerequired, halstead_bugprop
    """
    N2 = max(float(metrics.get("operands_sum", 0)), 1.0)
    N1 = max(float(metrics.get("operators_sum", 0)), 1.0)
    n2 = max(float(metrics.get("operands_uniq", 0)), 1.0)
    n1 = max(float(metrics.get("operators_uniq", 0)), 1.0)

    vocabulary = max(n1 + n2, 1.0)
    length = N1 + N2
    volume = max(length * math.log2(vocabulary), 1.0)
    difficulty = (n1 / 2.0) * (N2 / n2)
    effort = volume * difficulty
    time_required = effort / 18.0

    if bug_method == "old":
        bug = (effort * (2.0 / 3.0)) / 3000.0
    else:
        bug = volume / 3000.0

    metrics["halstead_volume"] = volume
    metrics["halstead_difficulty"] = difficulty
    metrics["halstead_effort"] = effort
    metrics["halstead_timerequired"] = time_required
    metrics["halstead_bugprop"] = bug
    return metrics


def calc_maintainability_index(metrics: dict, method: str = "classic") -> dict:
    """Compute the SEI Maintainability Index.

    Input keys: halstead_volume, cyclomatic_complexity, loc, comment_ratio
    Output key added to *metrics*: maintainability_index (clamped 0-100)
    """
    hv = max(float(metrics.get("halstead_volume", 1)), 1.0)
    cc = float(metrics.get("cyclomatic_complexity", 0))
    loc = max(float(metrics.get("loc", 1)), 1.0)
    cr = float(metrics.get("comment_ratio", 0))

    try:
        if method == "sei":
            mi = (
                171.0
                - (5.2 * math.log(hv))
                - (0.23 * cc)
                - (16.2 * math.log(loc))
                + (50.0 * math.sin(math.sqrt(2.4 * cr)))
            )
        elif method == "microsoft":
            mi = max(
                0,
                (171.0 - (5.2 * math.log(hv)) - (0.23 * cc) - (16.2 * math.log(loc)))
                * 100.0
                / 171.0,
            )
        else:  # classic
            mi = 171.0 - (5.2 * math.log(hv)) - (0.23 * cc) - (16.2 * math.log(loc))
    except Exception:
        mi = 0.0

    metrics["maintainability_index"] = max(min(mi, 100.0), 0.0)
    return metrics


def _fail_safe(fn):
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return 0

    return wrapper


@_fail_safe
def _tiobe_complexity(cc: float) -> float:
    return 6400.0 / float(math.pow(cc, 3) - math.pow(cc, 2) - cc + 65)


@_fail_safe
def _tiobe_fanout(internal: float, external: float) -> float:
    return float(min(max(120.0 - ((8.0 * internal) + (2.0 * external)), 0.0), 100.0))


@_fail_safe
def _scaled_value(loc: float, value: float) -> float:
    return 100.0 / (value / (loc / 1000.0) + 1.0)


def calc_tiobe(metrics: dict) -> dict:
    """Compute the TIOBE quality index and 8 subscores.

    Input keys: cyclomatic_complexity, fanout_internal, fanout_external, loc
    Output keys added to *metrics*: tiobe, tiobe_complexity, tiobe_fanout,
    tiobe_compiler, tiobe_coverage, tiobe_duplication, tiobe_functional,
    tiobe_security, tiobe_standard

    Importer-based subscores default to 100/0 since agent passes no importers.
    """
    cc = float(metrics.get("cyclomatic_complexity", 0))
    fi = float(metrics.get("fanout_internal", 0))
    fe = float(metrics.get("fanout_external", 0))
    loc = max(float(metrics.get("loc", 1)), 1.0)

    complexity = _tiobe_complexity(cc)
    fanout = _tiobe_fanout(fi, fe)

    # Importer-based — no importers in agent, use defaults
    coverage = min((0.75 * 100.0) + 32.5, 100.0)  # default coverage=100%
    duplication = min(
        -30.0 * math.log10(0.00001) + 70.0, 100.0
    )  # default 0 duplication
    standard = _scaled_value(loc, 0.0)  # default 0 violations
    security = _scaled_value(loc, 0.0)  # default 0 violations

    try:
        compiler_violations = _scaled_value(loc, 0.0)
        compiler = max(
            100.0 - 50.0 * math.log((101 - compiler_violations) or 0.00001), 0.0
        )
    except Exception:
        compiler = 0

    try:
        functional_violations = 0.0
        functional = max(_scaled_value(loc, functional_violations) * 2.0 - 100.0, 0.0)
    except Exception:
        functional = 0

    metrics["tiobe_complexity"] = complexity
    metrics["tiobe_fanout"] = fanout
    metrics["tiobe_coverage"] = coverage
    metrics["tiobe_duplication"] = duplication
    metrics["tiobe_standard"] = standard
    metrics["tiobe_security"] = security
    metrics["tiobe_compiler"] = compiler
    metrics["tiobe_functional"] = functional

    tiobe = (
        (coverage * 0.2)
        + (functional * 0.2)
        + (complexity * 0.15)
        + (compiler * 0.15)
        + (standard * 0.1)
        + (duplication * 0.1)
        + (fanout * 0.05)
        + (security * 0.05)
    )
    metrics["tiobe"] = tiobe
    return metrics


def calc_pylint(metrics: dict) -> dict:
    """Compute Pylint-style quality score.

    Output key added to *metrics*: pylint (defaults to 100 without importers).

    Without importers, errors/warnings/info are all 0, so score is always 100.
    """
    metrics["pylint"] = 100.0
    return metrics
