"""Signal definition models and collection utilities.

Each signal analyzer declares a ``SIGNAL`` or ``SIGNALS`` module-level
constant describing what it computes, how it contributes to composite
scores, and its weight in the AnalysisManager.
"""

from __future__ import annotations

import importlib
import logging
from enum import Enum
from typing import Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class SignalLevel(str, Enum):
    """Granularity at which a signal is computed."""

    PER_FILE = "per_file"
    REPO = "repo"


class CompositeContribution(BaseModel, frozen=True):
    """How a signal feeds into a named composite score."""

    composite: str
    weight: float
    inverted: bool = False
    normalize_divisor: Optional[float] = None


class SignalDefinition(BaseModel, frozen=True):
    """Declarative description of a single analysis signal."""

    name: str
    description: str
    level: SignalLevel
    category: str = "heuristic"
    composites: list[CompositeContribution] = []
    manager_weight: Optional[float] = None
    requires_slm: bool = False
    requires_git: bool = False
    value_range: tuple[float, float] = (0.0, 1.0)
    why_it_matters: Optional[str] = None

    def weight_for(self, composite: str) -> float:
        """Return the weight this signal contributes to *composite*, or 0."""
        for c in self.composites:
            if c.composite == composite:
                return c.weight
        return 0.0

    def contribution_for(self, composite: str) -> Optional[CompositeContribution]:
        """Return the full CompositeContribution for *composite*, or None."""
        for c in self.composites:
            if c.composite == composite:
                return c
        return None


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------

_SIGNAL_MODULES = [
    "techlens_agent.analysis.signals.git_density_filter",
    "techlens_agent.analysis.signals.import_graph_analyzer",
    "techlens_agent.analysis.signals.code_metrics",
    "techlens_agent.analysis.signals.test_coverage_analyzer",
    "techlens_agent.analysis.signals.domain_token_analyzer",
    "techlens_agent.analysis.signals.glue_marker_analyzer",
    "techlens_agent.analysis.signals.external_call_analyzer",
    "techlens_agent.analysis.signals.duplication_analyzer",
    "techlens_agent.analysis.signals.heuristic_post_filter",
    "techlens_agent.analysis.signals.slm_analyzer",
    "techlens_agent.analysis.signals.cyclomatic_analyzer",
    "techlens_agent.analysis.signals.operand_operator_analyzer",
    "techlens_agent.analysis.signals.halstead_analyzer",
    "techlens_agent.analysis.signals.maintainability_analyzer",
    "techlens_agent.analysis.signals.fanout_analyzer",
    "techlens_agent.analysis.signals.tiobe_analyzer",
    "techlens_agent.analysis.signals.api_surface_analyzer",
    "techlens_agent.analysis.signals.realtime_pattern_analyzer",
    "techlens_agent.analysis.signals.data_accumulation_analyzer",
    "techlens_agent.analysis.signals.governance_workflow_analyzer",
    "techlens_agent.analysis.signals.regulatory_token_analyzer",
    "techlens_agent.analysis.signals.file_role_classifier",
    "techlens_agent.analysis.signals.cochange_clusters",
    "techlens_agent.analysis.signals.churn_risk_analyzer",
]


def collect_signals() -> list[SignalDefinition]:
    """Import all signal modules and gather ``SIGNAL`` / ``SIGNALS`` attributes."""
    result: list[SignalDefinition] = []
    loaded = 0
    for mod_path in _SIGNAL_MODULES:
        try:
            mod = importlib.import_module(mod_path)
            loaded += 1
        except ImportError:
            logger.warning("Could not import signal module %s", mod_path)
            continue

        sig = getattr(mod, "SIGNAL", None)
        if isinstance(sig, SignalDefinition):
            result.append(sig)

        sigs = getattr(mod, "SIGNALS", None)
        if isinstance(sigs, list):
            for s in sigs:
                if isinstance(s, SignalDefinition):
                    result.append(s)

    logger.info(
        "Collected %d signals from %d/%d modules",
        len(result),
        loaded,
        len(_SIGNAL_MODULES),
    )
    return result
