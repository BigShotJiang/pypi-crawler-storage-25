"""Central per-file score registry for multi-signal analysis.

Each analyzer contributes weights independently via add_weight().
After all analyzers run, compute_composite_scores() sums and normalizes.
"""

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class FileScore:
    """Per-file composite score with individual analyzer contributions."""

    path: str
    weights: dict[str, float] = field(default_factory=dict)
    composite_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class AnalysisManager:
    """Registry that accumulates per-file weights from multiple analyzers."""

    def __init__(self, file_paths: set[str], repo_path: str = "") -> None:
        self.repo_path = repo_path
        self._scores: dict[str, FileScore] = {p: FileScore(path=p) for p in file_paths}
        self._extra_metadata: dict[str, dict[str, Any]] = {}
        self._shared: dict[str, Any] = {}

    def get_shared(self, key: str, factory: Callable[["AnalysisManager"], Any]) -> Any:
        """Lazy-init shared context. Factory receives the manager itself."""
        if key not in self._shared:
            self._shared[key] = factory(self)
        return self._shared[key]

    def get_metadata(self, path: str, key: str, default: Any = None) -> Any:
        """Read metadata previously stored by another analyzer."""
        if path in self._scores:
            return self._scores[path].metadata.get(key, default)
        if path in self._extra_metadata:
            return self._extra_metadata[path].get(key, default)
        return default

    def add_weight(self, path: str, analyzer: str, weight: float) -> None:
        """Add a weight contribution from an analyzer to a file.

        If the file wasn't in the initial set it is silently ignored.
        """
        if path in self._scores:
            self._scores[path].weights[analyzer] = (
                self._scores[path].weights.get(analyzer, 0.0) + weight
            )

    def add_metadata(self, path: str, key: str, value: Any) -> None:
        """Attach arbitrary metadata to a file.

        Works for files both in and outside the weight-tracked set.
        Files outside ``_scores`` use a separate metadata-only store so
        that token-based metrics can run on all repository files without
        affecting composite scoring.
        """
        if path in self._scores:
            self._scores[path].metadata[key] = value
        else:
            self._extra_metadata.setdefault(path, {})[key] = value

    def get_weight(self, path: str, analyzer: str) -> float:
        """Return the current weight for a file from a specific analyzer."""
        if path in self._scores:
            return self._scores[path].weights.get(analyzer, 0.0)
        return 0.0

    def compute_composite_scores(self, normalize: bool = True) -> None:
        """Sum all weights per file, optionally normalize to 0-1."""
        for fs in self._scores.values():
            fs.composite_score = sum(fs.weights.values())

        if normalize and self._scores:
            max_score = max(fs.composite_score for fs in self._scores.values())
            min_score = min(fs.composite_score for fs in self._scores.values())
            score_range = max_score - min_score

            if score_range > 0:
                for fs in self._scores.values():
                    fs.composite_score = (fs.composite_score - min_score) / score_range
            else:
                for fs in self._scores.values():
                    fs.composite_score = 1.0 if max_score > 0 else 0.0

    def top_files(
        self, n: int | None = None, threshold: float = 0.0
    ) -> list[FileScore]:
        """Return files sorted by composite_score descending.

        Args:
            n: Max number of files to return. None means all.
            threshold: Minimum composite_score to include.
        """
        filtered = [
            fs for fs in self._scores.values() if fs.composite_score >= threshold
        ]
        filtered.sort(key=lambda fs: fs.composite_score, reverse=True)
        if n is not None:
            filtered = filtered[:n]
        return filtered

    @property
    def all_files(self) -> dict[str, FileScore]:
        """Access the internal score registry (read-only intent)."""
        return self._scores
