"""CLI entry point for ``python -m techlens_agent.analysis``."""

import argparse
import json
import logging
import os
import sys
from dataclasses import asdict

from .analyze import analyze
from .pipeline import PipelineContext, run_pipeline
from .signals.slm_analyzer import SLMAgent
from .slm_config import SlmConfig
from .stages import FULL_ANALYSIS, POST_FILTER_ONLY, STATS_PIPELINE
from .stats import extract_stats

logger = logging.getLogger(__name__)


def _run_analyze(args: argparse.Namespace, config: SlmConfig) -> None:
    repo_name = os.path.basename(os.path.abspath(args.path))
    output_path = args.output or f"results/{repo_name}.analysis.json"

    stages = FULL_ANALYSIS if args.model else STATS_PIPELINE
    result = analyze(
        repo_path=args.path,
        output_path=output_path,
        config=config,
        stages=stages,
    )

    print(json.dumps(result.model_dump(), indent=2))

    if result.error:
        sys.exit(1)


def _run_post_filter(args: argparse.Namespace, config: SlmConfig) -> None:
    SLMAgent.configure(config)

    ctx = PipelineContext(
        repo_path=os.path.abspath(args.path),
        config=config,
    )
    run_pipeline(POST_FILTER_ONLY, ctx)

    if ctx.error:
        print(json.dumps({"error": ctx.error}, indent=2))
        sys.exit(1)

    # Build output dict from context
    result: dict = {}
    if ctx.metrics:
        result["gluemarker_ratio"] = ctx.metrics.gluemarker_ratio
        result["domain_token_density"] = ctx.metrics.domain_token_density
        result["domain_match_density"] = ctx.metrics.domain_match_density
        result["domain_profile"] = ctx.metrics.domain_profile
        result["external_call_ratio"] = ctx.metrics.external_call_ratio
        result["control_flow_density"] = ctx.metrics.control_flow_density
        result["definition_density"] = ctx.metrics.definition_density
        result["comment_ratio"] = ctx.metrics.comment_ratio
        result["duplication_ratio"] = ctx.metrics.duplication_ratio
    if ctx.density_result:
        result["highest_git_density_paths"] = [
            asdict(f) for f in ctx.density_result.files
        ]
    if ctx.code_value_assessment:
        result["code_value_assessment"] = ctx.code_value_assessment.model_dump()
    if ctx.slm_glue_assessment:
        result["slm_glue_assessment"] = ctx.slm_glue_assessment.model_dump()

    output_path = args.output
    if output_path:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(result, f, indent=2)
        logger.info("Results written to %s", output_path)

    print(json.dumps(result, indent=2, default=str))


def _run_stats(args: argparse.Namespace, config: SlmConfig) -> None:
    repo_name = os.path.basename(os.path.abspath(args.path))
    output_path = args.output or f"results/{repo_name}.stats.json"

    stats = extract_stats(repo_path=args.path, config=config)
    data = stats.model_dump(exclude_none=True)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)
    logger.info("Stats written to %s", output_path)

    print(json.dumps(data, indent=2))

    if stats.error:
        sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="TechLens Analysis: comprehensive code assessment",
    )
    parser.add_argument(
        "--path",
        required=True,
        help="Path to the repository to analyze",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Output JSON file path (default: results/<repo>.analysis.json)",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Ollama model name. SLM stages are skipped when not set.",
    )
    parser.add_argument(
        "--host",
        default="http://localhost:11434",
        help="Ollama host URL (default: http://localhost:11434)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )
    parser.add_argument(
        "--action",
        choices=["analyze", "post-filter", "stats"],
        default="analyze",
        help="Action to run (default: analyze)",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("chardet").setLevel(logging.WARNING)

    config_kwargs = {"ollama_host": args.host}
    if args.model:
        config_kwargs["model"] = args.model
    config = SlmConfig(**config_kwargs)

    if args.action == "post-filter":
        _run_post_filter(args, config)
    elif args.action == "stats":
        _run_stats(args, config)
    else:
        _run_analyze(args, config)


if __name__ == "__main__":
    main()
