"""Pipeline infrastructure for composable analysis stages.

A pipeline is a list of stage functions executed in order on a shared
PipelineContext.  Adding/removing/reordering stages is a one-line edit.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Optional

if TYPE_CHECKING:
    from .analysis_manager import AnalysisManager, FileScore
    from .signals.code_metrics import CodeMetricsResult
    from .signals.file_filter import FilterResult
    from .signals.git_density_filter import DensityResult
    from .slm_config import SlmConfig

logger = logging.getLogger(__name__)

Stage = Callable[["PipelineContext"], None]

# Skip list for the broad token-metrics walk.  Reuses the curated set from
# file_filter to avoid tokenizing vendored / generated / virtual-env trees
# that inflated file counts and dominated runtime.
from .signals.file_filter import SKIP_DIRECTORIES as _TM_SKIP_DIRS

# Extensions Pygments can meaningfully tokenize.  Matches SOURCE_EXTENSIONS
# from file_filter but intentionally kept separate — the broad walk is less
# selective on *directories* while still filtering by extension so we don't
# waste time attempting to tokenize images, binaries, or data files.
_TM_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".java",
        ".kt",
        ".kts",
        ".go",
        ".rs",
        ".c",
        ".cpp",
        ".cc",
        ".h",
        ".hpp",
        ".cs",
        ".rb",
        ".php",
        ".swift",
        ".scala",
        ".clj",
        ".cljs",
        ".ex",
        ".exs",
        ".erl",
        ".hs",
        ".ml",
        ".mli",
        ".r",
        ".R",
        ".lua",
        ".pl",
        ".pm",
        ".sh",
        ".bash",
        ".zsh",
        ".sql",
        ".tf",
        ".hcl",
        ".yaml",
        ".yml",
        ".toml",
        ".json",
        ".xml",
        ".gradle",
        ".cmake",
        ".makefile",
        ".mk",
        ".vue",
        ".svelte",
        ".dart",
        ".zig",
        ".nim",
        ".v",
        ".proto",
    }
)


def _walk_all_tokenizable(repo_path: str) -> list[str]:
    """Walk *repo_path* filtering out non-tokenizable files.

    Skips directories in ``SKIP_DIRECTORIES`` (from file_filter) plus
    ``.egg-info`` directories.  Filters by source extension so we don't
    attempt to tokenize binaries/images.
    """
    result: list[str] = []
    for dirpath, dirnames, filenames in os.walk(repo_path):
        dirnames[:] = [
            d
            for d in dirnames
            if d not in _TM_SKIP_DIRS and not d.endswith(".egg-info")
        ]
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in _TM_EXTENSIONS and fname.lower() not in (
                "makefile",
                "gnumakefile",
            ):
                continue
            full = os.path.join(dirpath, fname)
            if os.path.islink(full):
                continue
            rel = os.path.relpath(full, repo_path)
            result.append(rel)
    return result


@dataclass
class PipelineContext:
    """Mutable state container threaded through every pipeline stage."""

    # Inputs
    repo_path: str = ""
    config: Any = None  # SlmConfig (Any avoids circular import at runtime)

    # Stage outputs — all Optional so stages can check availability
    filter_result: Optional[Any] = None  # FilterResult
    file_paths: set[str] = field(default_factory=set)
    file_paths_list: list[str] = field(default_factory=list)
    all_file_paths_list: list[str] = field(default_factory=list)  # includes test files
    manager: Optional[Any] = None  # AnalysisManager
    density_result: Optional[Any] = None  # DensityResult
    indegree_map: dict[str, int] = field(default_factory=dict)
    metrics: Optional[Any] = None  # CodeMetricsResult
    test_map: dict[str, str] = field(default_factory=dict)
    top_files: list[Any] = field(default_factory=list)  # list[FileScore]
    code_value_assessment: Any = None
    slm_glue_assessment: Any = None
    lm_code_value: Any = None
    per_file_values: dict[str, dict] = field(default_factory=dict)
    program_synthesis: dict = field(default_factory=dict)

    # Co-change clusters (list of file-path lists)
    cochange_clusters: list[list[str]] = field(default_factory=list)

    # Contributor attribution
    enriched_commits: list[dict] = field(default_factory=list)
    contributor_summary: Optional[dict] = None

    # AI Moats Framework signals
    data_accumulation: Optional[float] = None
    realtime_density: Optional[float] = None
    governance_density: Optional[float] = None
    api_surface: Optional[float] = None
    regulatory_density: Optional[float] = None

    # Lazily populated: all tokenizable files (broad walk, .git + node_modules only)
    _tm_all_files: Optional[list[str]] = field(default=None, repr=False)

    @property
    def tm_all_files(self) -> list[str]:
        """All files eligible for token-based metrics (broad walk)."""
        if self._tm_all_files is None:
            self._tm_all_files = _walk_all_tokenizable(self.repo_path)
        return self._tm_all_files

    # Progress callback — (fraction 0.0-1.0, message)
    on_progress: Optional[Callable[[float, str], None]] = None

    # Set by run_pipeline so stages can report sub-progress
    _progress_base: float = 0.0
    _progress_span: float = 1.0

    # Error sentinel — if set, run_pipeline stops early
    error: Optional[str] = None

    def report_progress(self, sub_fraction: float, message: str) -> None:
        """Report progress. *sub_fraction* is 0.0-1.0 within the current stage."""
        if self.on_progress is not None:
            overall = self._progress_base + self._progress_span * sub_fraction
            self.on_progress(overall, message)


def _default_progress(fraction: float, message: str) -> None:
    """Default progress callback — logs at INFO level."""
    logger.info("[%3.0f%%] %s", fraction * 100, message)


def run_pipeline(stages: list[Stage], ctx: PipelineContext) -> PipelineContext:
    """Execute *stages* in order.  Stop early if ``ctx.error`` is set."""
    if ctx.on_progress is None:
        ctx.on_progress = _default_progress

    total = len(stages)
    stage_names = [s.__name__ for s in stages]
    logger.info("Starting pipeline with %d stages: %s", total, ", ".join(stage_names))

    for i, stage in enumerate(stages):
        if ctx.error:
            logger.warning("Pipeline stopping early due to error: %s", ctx.error)
            break
        ctx._progress_base = i / total if total else 0.0
        ctx._progress_span = 1.0 / total if total else 1.0
        try:
            ctx.report_progress(0.0, f"Stage {i + 1}/{total}: {stage.__name__}")
            stage(ctx)
        except Exception as exc:
            logger.exception("Stage %s failed", stage.__name__)
            ctx.error = str(exc)

    if ctx.error:
        logger.error("Pipeline finished with error: %s", ctx.error)
    elif ctx.on_progress is not None:
        ctx.on_progress(1.0, "Pipeline complete")
        logger.info("Pipeline finished successfully (%d stages)", total)

    return ctx
