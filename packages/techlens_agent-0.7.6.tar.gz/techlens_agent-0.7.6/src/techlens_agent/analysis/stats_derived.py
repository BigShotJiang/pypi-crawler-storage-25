"""Derived composite statistics from raw pipeline data.

Weights and normalization divisors are sourced from the ``SignalDefinition``
constants declared in each signal module.  The ``compute_composite`` helper
provides a generic way to evaluate any named composite; the named functions
(``engineering_score``, ``moat_score``, ``lm_code_value_score``) keep
identical signatures for backwards compatibility.
"""

from __future__ import annotations

import functools
import math

from .signal_definition import SignalDefinition, collect_signals


@functools.lru_cache(maxsize=1)
def _all_signals() -> list[SignalDefinition]:
    return collect_signals()


def compute_composite(
    name: str,
    values: dict[str, float | None],
) -> float:
    """Evaluate a named composite score from raw signal values.

    For each signal that contributes to *name*:
      1. Look up the raw value in *values* (skip if ``None`` or missing).
      2. Apply ``normalize_divisor`` (clamp to 1.0) if set.
      3. Invert (``1.0 - value``) if ``inverted`` is set.
      4. Multiply by the contribution weight.

    The final sum is re-normalized by the total available weight so that
    missing signals (e.g. SLM not available) are handled gracefully.
    """
    signals = _all_signals()
    weighted_sum = 0.0
    total_weight = 0.0

    for sig in signals:
        contrib = sig.contribution_for(name)
        if contrib is None:
            continue

        raw = values.get(sig.name)
        if raw is None:
            continue

        v = float(raw)
        if not math.isfinite(v):
            continue
        if contrib.normalize_divisor is not None and contrib.normalize_divisor != 0:
            v = min(v / contrib.normalize_divisor, 1.0)
        if contrib.inverted:
            v = 1.0 - max(0.0, min(v, 1.0))

        weighted_sum += v * contrib.weight
        total_weight += contrib.weight

    if total_weight == 0.0:
        return 0.0
    return round(weighted_sum / total_weight, 4)


def engineering_score(
    control_flow_density: float,
    definition_density: float,
    comment_ratio: float,
    duplication_ratio: float,
    test_coverage_ratio: float,
) -> float:
    """Single 0-1 score for engineering quality.

    Sub-scores (each 0-1, weighted):
      - control_flow  (0.15) — 20+ statements/100 lines = 1.0
      - definitions    (0.15) — 15+ definitions/100 lines = 1.0
      - comments       (0.15) — 15%+ comment ratio = 1.0
      - low duplication(0.25) — 0% duplication = 1.0
      - test coverage  (0.30) — 100% coverage = 1.0
    """
    return compute_composite(
        "engineering_score",
        {
            "control_flow_density": control_flow_density,
            "definition_density": definition_density,
            "comment_ratio": comment_ratio,
            "duplication_ratio": duplication_ratio,
            "test_coverage_boosted": test_coverage_ratio,
        },
    )


def moat_score(
    domain_match_density: float,
    gluemarker_ratio: float,
    external_call_ratio: float,
    code_value_uniqueness_score: float | None = None,
) -> float:
    """Single 0-1 score for code originality.

    Weighted contributors are loaded from ``SignalDefinition`` at runtime
    (via ``compute_composite``), including domain match, glue/external
    inversions, SLM uniqueness, and architecture moat signals.
    """
    return compute_composite(
        "moat_score",
        {
            "domain_match_density": domain_match_density,
            "gluemarker_ratio": gluemarker_ratio,
            "external_call_ratio": external_call_ratio,
            "code_value_uniqueness": code_value_uniqueness_score,
        },
    )


def lm_code_value_score(
    lm_uniqueness: float,
    lm_complexity: float,
    lm_quality: float,
) -> float:
    """Composite 0-1 score from three LM-assessed dimensions.

    Equal weight (1/3 each) — uniqueness, difficulty, and quality are
    all equally important for estimating code value.
    """
    return compute_composite(
        "lm_code_value_score",
        {
            "lm_uniqueness": lm_uniqueness,
            "lm_complexity": lm_complexity,
            "lm_quality": lm_quality,
        },
    )


def bus_factor_files(author_counts: list[int]) -> int:
    """Count files with only one author (at risk if that person leaves)."""
    return sum(1 for a in author_counts if a == 1)
