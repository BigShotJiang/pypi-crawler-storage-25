"""Main analysis orchestrator.

Runs all analysis stages via a composable pipeline and produces a
combined AnalysisResult.
"""

import json
import logging
import os
from typing import Optional

from pydantic import BaseModel, Field

from .pipeline import PipelineContext, Stage, run_pipeline
from .signals.git_density_filter import FileDensity
from .slm_config import SlmConfig
from .stages import FULL_ANALYSIS, STATS_PIPELINE
from .stats_derived import lm_code_value_score

logger = logging.getLogger(__name__)


class AnalysisResult(BaseModel):
    """Complete analysis result."""

    # Heuristic metrics
    gluemarker_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_token_density: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_match_density: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_profile: str = ""
    external_call_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    control_flow_density: float = Field(default=0.0, ge=0.0)
    definition_density: float = Field(default=0.0, ge=0.0)
    comment_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    duplication_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    # SLM assessments
    code_value_uniqueness_score: float = Field(default=0.0, ge=0.0, le=1.0)
    code_value_rationale: str = ""
    glue_originality_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    glue_rationale: str = ""

    # Git density summary
    high_density_file_count: int = 0
    outlier_file_count: int = 0

    # Composite / multi-signal fields
    top_composite_files: list[dict] = Field(default_factory=list)
    import_graph_nodes: int = 0
    max_indegree: int = 0
    test_covered_file_count: int = 0

    # LM-derived code value
    lm_code_value_score: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_uniqueness: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_complexity: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_quality: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_code_value_rationale: str = ""

    # Program-level synthesis
    program_description: str = ""
    program_value_score: float = Field(default=0.0, ge=0.0, le=1.0)
    program_rationale: str = ""
    program_notes: list[str] = Field(default_factory=list)

    # Co-change clusters
    cochange_clusters: list[list[str]] = Field(default_factory=list)

    # Contributor attribution
    total_contributors: int = 0
    human_contributors: int = 0
    bot_contributors: int = 0
    contributor_concentration: float = Field(default=0.0, ge=0.0, le=1.0)

    # AI Moats Framework signals
    data_accumulation_pattern: Optional[float] = None
    realtime_pattern_density: Optional[float] = None
    governance_workflow_density: Optional[float] = None
    api_surface_ratio: Optional[float] = None
    regulatory_token_density: Optional[float] = None

    # Metadata
    files_analyzed: int = 0
    total_lines: int = 0
    error: Optional[str] = None


def _build_result(ctx: PipelineContext) -> AnalysisResult:
    """Map PipelineContext fields to an AnalysisResult."""
    result = AnalysisResult()

    if ctx.error:
        result.error = ctx.error
        return result

    # Git density summary
    if ctx.density_result:
        high_density_files: list[FileDensity] = [
            f for f in ctx.density_result.files if f.density_score > 0.5
        ]
        result.high_density_file_count = len(high_density_files)

    # Co-change clusters
    result.cochange_clusters = ctx.cochange_clusters

    # Contributor attribution
    if ctx.contributor_summary:
        result.total_contributors = ctx.contributor_summary["total_developers"]
        result.human_contributors = ctx.contributor_summary["human_developers"]
        result.bot_contributors = ctx.contributor_summary["bot_developers"]
        result.contributor_concentration = ctx.contributor_summary["concentration_pct"]

    # AI Moats Framework signals
    result.data_accumulation_pattern = ctx.data_accumulation
    result.realtime_pattern_density = ctx.realtime_density
    result.governance_workflow_density = ctx.governance_density
    result.api_surface_ratio = ctx.api_surface
    result.regulatory_token_density = ctx.regulatory_density

    # Import graph
    result.import_graph_nodes = len(ctx.indegree_map)
    result.max_indegree = max(ctx.indegree_map.values(), default=0)

    # Test coverage
    result.test_covered_file_count = len(ctx.test_map)

    # Code metrics
    if ctx.metrics:
        result.gluemarker_ratio = ctx.metrics.gluemarker_ratio
        result.domain_token_density = ctx.metrics.domain_token_density
        result.domain_match_density = ctx.metrics.domain_match_density
        result.domain_profile = ctx.metrics.domain_profile
        result.external_call_ratio = ctx.metrics.external_call_ratio
        result.control_flow_density = ctx.metrics.control_flow_density
        result.definition_density = ctx.metrics.definition_density
        result.comment_ratio = ctx.metrics.comment_ratio
        result.duplication_ratio = ctx.metrics.duplication_ratio
        result.files_analyzed = ctx.metrics.files_analyzed
        result.total_lines = ctx.metrics.total_lines

    # Top composite files with SLM per-file values merged in
    for fs in ctx.top_files[:20]:
        entry: dict = {
            "path": fs.path,
            "composite_score": round(fs.composite_score, 4),
            "weights": {k: round(v, 4) for k, v in fs.weights.items()},
        }
        slm_data = ctx.per_file_values.get(fs.path)
        if slm_data:
            entry["slm_description"] = slm_data.get("slm_description", "")
            entry["slm_value_score"] = slm_data.get("slm_value_score", 0.0)
            entry["slm_rationale"] = slm_data.get("slm_rationale", "")
        result.top_composite_files.append(entry)

    # SLM assessments
    if ctx.code_value_assessment and ctx.code_value_assessment.error is None:
        result.code_value_uniqueness_score = getattr(
            ctx.code_value_assessment,
            "uniqueness_score",
            0.0,
        )
        result.code_value_rationale = getattr(
            ctx.code_value_assessment,
            "rationale",
            "",
        )

    if ctx.slm_glue_assessment and ctx.slm_glue_assessment.error is None:
        result.glue_originality_ratio = getattr(
            ctx.slm_glue_assessment,
            "originality_ratio",
            0.0,
        )
        result.glue_rationale = getattr(
            ctx.slm_glue_assessment,
            "rationale",
            "",
        )

    # LM code value
    if ctx.lm_code_value is not None and ctx.lm_code_value.error is None:
        result.lm_uniqueness = ctx.lm_code_value.lm_uniqueness
        result.lm_complexity = ctx.lm_code_value.lm_complexity
        result.lm_quality = ctx.lm_code_value.lm_quality
        result.lm_code_value_rationale = ctx.lm_code_value.lm_code_value_rationale
        result.lm_code_value_score = lm_code_value_score(
            lm_uniqueness=result.lm_uniqueness,
            lm_complexity=result.lm_complexity,
            lm_quality=result.lm_quality,
        )

    # Outlier count from density
    if ctx.density_result:
        from .signals.heuristic_post_filter import compute_git_density_outliers

        result.outlier_file_count = len(
            compute_git_density_outliers(ctx.density_result.files)
        )

    # Program-level synthesis
    if ctx.program_synthesis:
        result.program_description = ctx.program_synthesis.get(
            "program_description",
            "",
        )
        result.program_value_score = ctx.program_synthesis.get(
            "program_value_score",
            0.0,
        )
        result.program_rationale = ctx.program_synthesis.get(
            "program_rationale",
            "",
        )
        result.program_notes = ctx.program_synthesis.get(
            "program_notes",
            [],
        )

    logger.info("Analysis complete")
    if ctx.top_files:
        logger.info(
            "  Composite top file: %s (score=%.4f)",
            ctx.top_files[0].path,
            ctx.top_files[0].composite_score,
        )

    return result


def analyze(
    repo_path: str,
    output_path: Optional[str] = None,
    config: Optional[SlmConfig] = None,
    stages: Optional[list[Stage]] = None,
) -> AnalysisResult:
    """Run complete analysis on a repository.

    Args:
        repo_path: Path to the repository root.
        output_path: Optional path to write JSON results.
        config: Optional SLM configuration.
        stages: Pipeline stages to run.  Defaults to FULL_ANALYSIS.

    Returns:
        AnalysisResult with all metrics and assessments.
    """
    if config is None:
        config = SlmConfig()
    if stages is None:
        stages = FULL_ANALYSIS

    logger.info("Starting analysis for %s (model=%s)", repo_path, config.model)

    ctx = PipelineContext(
        repo_path=os.path.abspath(repo_path),
        config=config,
    )

    run_pipeline(stages, ctx)
    result = _build_result(ctx)

    if result.error:
        logger.error("Analysis failed: %s", result.error)
    else:
        logger.info(
            "Analysis result: %d files, %d lines, %d top composite files",
            result.files_analyzed,
            result.total_lines,
            len(result.top_composite_files),
        )

    # Write output if requested
    if output_path:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result.model_dump(), f, indent=2)
        logger.info("Results written to %s", output_path)

    return result
