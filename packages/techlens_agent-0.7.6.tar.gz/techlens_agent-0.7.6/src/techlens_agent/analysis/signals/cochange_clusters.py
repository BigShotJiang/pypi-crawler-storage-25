"""Co-change cluster detection using Louvain community detection.

Builds a weighted graph from co-change pair counts (files changed together
in the same commit) and applies the Louvain algorithm to find clusters of
tightly coupled files.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import networkx as nx

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def compute_cochange_clusters(
    cochange_counts: dict[tuple[str, str], int],
    resolution: float = 1.0,
    seed: int = 42,
) -> list[list[str]]:
    """Detect communities in the co-change graph using Louvain.

    Args:
        cochange_counts: Mapping of (file_a, file_b) -> co-change count,
            as produced by git_density_filter._compute_cochange().
        resolution: Louvain resolution parameter. Higher values produce
            more, smaller clusters.
        seed: Random seed for reproducibility.

    Returns:
        List of clusters, each a sorted list of file paths.
        Clusters are sorted by size descending. Singletons are excluded.
    """
    if not cochange_counts:
        return []

    G = nx.Graph()
    for (a, b), count in cochange_counts.items():
        G.add_edge(a, b, weight=count)

    if G.number_of_edges() == 0:
        return []

    communities = nx.community.louvain_communities(
        G, weight="weight", resolution=resolution, seed=seed
    )

    # Filter singletons and sort
    clusters = [sorted(c) for c in communities if len(c) > 1]
    clusters.sort(key=len, reverse=True)

    logger.info(
        "Found %d co-change clusters from %d files, %d edges",
        len(clusters),
        G.number_of_nodes(),
        G.number_of_edges(),
    )

    return clusters


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="cochange_clusters",
    description="Clusters of files that frequently change together, detected via Louvain community detection",
    level=SignalLevel.REPO,
    category="git",
    requires_git=True,
    why_it_matters="Reveals hidden architectural coupling. Files that always change together may be tightly coupled even if they have no import relationship. This informs modularization effort estimates and highlights integration risk during platform migrations.",
)
