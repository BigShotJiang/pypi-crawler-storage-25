"""Governance/workflow analyzer — detects governance patterns via path conventions
and governance-specific dependencies.

Combines path-based signals (workflow, approval, RBAC directories) with
dependency-based signals (known governance packages) to estimate governance
density.
"""

from __future__ import annotations

import logging
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

from .data.governance_packages import GOVERNANCE_PACKAGES
from .manifest_parser import extract_dependency_names

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

GOVERNANCE_PATH_PARTS: frozenset[str] = frozenset(
    {
        "workflow",
        "workflows",
        "approval",
        "approvals",
        "audit",
        "rbac",
        "acl",
        "permission",
        "permissions",
        "policy",
        "policies",
        "authorization",
        "authz",
    }
)

# A repo where >=5% of files are governance-related scores 1.0 on the path axis.
_PATH_SATURATION = 0.05
# Similarly, >=5% governance deps saturates the dep axis.
_DEP_SATURATION = 0.05


def analyze_governance_workflow(
    file_paths: list[str],
    repo_path: str,
    manager: AnalysisManager | None = None,
) -> float | None:
    """Return governance density, or None if no evidence."""

    # -- Path signal ----------------------------------------------------------
    path_matches = 0
    for path in file_paths:
        p = PurePosixPath(path)
        parts = {part.lower() for part in p.parts}
        parts.add(p.stem.lower())
        if parts & GOVERNANCE_PATH_PARTS:
            path_matches += 1
            if manager is not None:
                manager.add_weight(path, "governance_workflow", 1.0)

    path_ratio = min(path_matches / max(len(file_paths), 1) / _PATH_SATURATION, 1.0)

    # -- Dependency signal ----------------------------------------------------
    deps = extract_dependency_names(repo_path)
    if deps:
        dep_ratio: float | None = min(
            len(deps & GOVERNANCE_PACKAGES) / len(deps) / _DEP_SATURATION, 1.0
        )
    else:
        dep_ratio = None

    # -- Combine --------------------------------------------------------------
    if path_ratio > 0 and dep_ratio is not None:
        score = (path_ratio + dep_ratio) / 2
    elif path_ratio > 0:
        score = path_ratio * 0.7  # discount without dep confirmation
    elif dep_ratio is not None and dep_ratio > 0:
        score = dep_ratio * 0.7
    else:
        return None

    logger.info(
        "Governance workflow: path_matches=%d/%d (ratio=%.3f), dep_ratio=%s, score=%.3f",
        path_matches,
        len(file_paths),
        path_ratio,
        f"{dep_ratio:.3f}" if dep_ratio is not None else "N/A",
        score,
    )
    return score


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="governance_workflow_density",
    description="Density of governance/workflow paths and deps indicating process moat",
    level=SignalLevel.REPO,
    category="architecture",
    manager_weight=1.0,
    composites=[
        CompositeContribution(
            composite="moat_score",
            weight=0.06,
        ),
    ],
    why_it_matters="Detects one of the stickiest moats: governance authority. Products with deep approval workflows, RBAC, and audit trails have switching costs that compound over time. Customers can't easily rip out a system that enforces their compliance processes.",
)
