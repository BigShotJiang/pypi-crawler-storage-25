"""Churn risk analyzer — per-file risk score combining churn with protective factors.

High churn alone is not a risk indicator — it can signal healthy, active
development.  Churn becomes risky when protective factors are absent:
no tests, single author, high complexity.

    churn_risk = density_score * (1 - protective_score)

Where protective_score is a weighted combination of:
  - has_tests        (weight 0.40) — binary, from test_coverage_analyzer
  - multi_author     (weight 0.30) — 1.0 if authors >= 2, else 0.0
  - low_complexity   (weight 0.30) — inverse of normalized cyclomatic complexity

Files with high churn but good tests and multiple authors score LOW risk.
Files with high churn, no tests, single author, high complexity score HIGH risk.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..pipeline import PipelineContext

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

logger = logging.getLogger(__name__)

# Protective factor weights (must sum to 1.0)
_W_HAS_TESTS = 0.40
_W_MULTI_AUTHOR = 0.30
_W_LOW_COMPLEXITY = 0.30


def analyze_churn_risk(ctx: PipelineContext) -> None:
    """Compute churn_risk per file and store as weight + metadata."""
    manager = ctx.manager
    if manager is None or ctx.density_result is None:
        return

    density_by_path: dict[str, float] = {
        f.path: f.density_score for f in ctx.density_result.files
    }

    # Find max cyclomatic complexity for normalization
    cc_values = []
    for path in ctx.file_paths:
        cc = manager.get_metadata(path, "cyclomatic_complexity", 0)
        if cc > 0:
            cc_values.append(cc)
    max_cc = max(cc_values) if cc_values else 1

    risk_scores: list[float] = []

    for path in ctx.file_paths:
        density = density_by_path.get(path, 0.0)
        if density <= 0:
            continue

        # Protective factors
        has_tests = 1.0 if manager.get_metadata(path, "has_tests", False) else 0.0
        authors = manager.get_metadata(path, "authors", 0)
        multi_author = 1.0 if authors >= 2 else 0.0
        cc = manager.get_metadata(path, "cyclomatic_complexity", 0)
        low_complexity = 1.0 - min(cc / max_cc, 1.0) if max_cc > 0 else 1.0

        protective = (
            _W_HAS_TESTS * has_tests
            + _W_MULTI_AUTHOR * multi_author
            + _W_LOW_COMPLEXITY * low_complexity
        )

        risk = density * (1.0 - protective)
        risk_scores.append(risk)

        manager.add_weight(path, "churn_risk", risk)
        manager.add_metadata(path, "churn_risk", round(risk, 4))
        manager.add_metadata(path, "churn_protective_score", round(protective, 4))

    if risk_scores:
        mean_risk = sum(risk_scores) / len(risk_scores)
        high_risk_count = sum(1 for r in risk_scores if r > 0.5)
        logger.info(
            "Churn risk: %d files scored, mean=%.3f, %d high-risk (>0.5)",
            len(risk_scores),
            mean_risk,
            high_risk_count,
        )


SIGNAL = SignalDefinition(
    name="churn_risk",
    description=(
        "Per-file risk score: churn * (1 - protective_factors). "
        "Protective factors: has_tests (0.4), multiple authors (0.3), low complexity (0.3). "
        "High churn with good tests and multiple authors scores low risk. "
        "High churn with no tests, single author, and high complexity scores high risk."
    ),
    level=SignalLevel.PER_FILE,
    category="git",
    requires_git=True,
    value_range=(0.0, 1.0),
    why_it_matters=(
        "Churn alone is ambiguous — active development is healthy. "
        "Churn risk isolates files where high change velocity lacks protective "
        "factors (tests, shared ownership, manageable complexity), surfacing "
        "true maintenance debt and key-person risk."
    ),
)
