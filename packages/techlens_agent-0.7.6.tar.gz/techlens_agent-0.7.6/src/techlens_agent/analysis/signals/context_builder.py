"""Stage 2: Read selected files and build chunked context strings for the SLM.

Partitions the filtered file list into chunks that each fit within
*chunk_token_budget*.  Each chunk is a formatted string of
``--- FILE: path ---`` / ``--- END FILE ---`` blocks.
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ContextChunk:
    """A single chunk of formatted source code ready for the SLM."""

    context_string: str
    file_count: int
    token_count: int


@dataclass
class BuiltContext:
    """Result of the context-building stage."""

    chunks: List[ContextChunk]
    total_tokens: int
    files_included: int
    files_truncated: int
    summary_line: str


def build_context(
    repo_path: str,
    selected_files: List[Tuple[str, int]],
    chunk_token_budget: int = 6000,
    deterministic_output: Optional[Dict] = None,  # scaffolded for v2
) -> BuiltContext:
    """Read *selected_files* and partition them into SLM-sized chunks.

    Parameters
    ----------
    repo_path:
        Absolute path to the repository root.
    selected_files:
        List of ``(relative_path, estimated_tokens)`` from Stage 1.
    chunk_token_budget:
        Maximum estimated tokens per chunk.
    deterministic_output:
        Reserved for v2 — deterministic analysis results to include in
        the prompt context.  Ignored in v1.
    """
    repo_path = os.path.abspath(repo_path)

    logger.debug(
        "Building context: %d files, budget=%d tokens/chunk",
        len(selected_files),
        chunk_token_budget,
    )

    chunks: List[ContextChunk] = []
    current_parts: List[str] = []
    current_tokens = 0
    current_file_count = 0
    total_tokens = 0
    files_included = 0
    files_truncated = 0

    def _flush_chunk() -> None:
        nonlocal current_parts, current_tokens, current_file_count
        if not current_parts:
            return
        chunks.append(
            ContextChunk(
                context_string="\n".join(current_parts),
                file_count=current_file_count,
                token_count=current_tokens,
            )
        )
        current_parts = []
        current_tokens = 0
        current_file_count = 0

    skipped_read = 0
    skipped_binary = 0

    for rel_path, _est_tokens in selected_files:
        full_path = os.path.join(repo_path, rel_path)

        try:
            with open(full_path, "rb") as f:
                raw = f.read()
        except OSError:
            skipped_read += 1
            continue

        # Skip binary files that slipped through
        if b"\x00" in raw:
            skipped_binary += 1
            continue

        try:
            content = raw.decode("utf-8", errors="replace")
        except Exception as exc:
            logger.debug("Skipping file %s: decode error %s", rel_path, exc)
            continue

        actual_tokens = len(content) // 4

        # Delimiter overhead (~10 tokens)
        overhead = 10

        # If this single file won't fit in the current chunk, flush first
        if (
            current_tokens > 0
            and current_tokens + actual_tokens + overhead > chunk_token_budget
        ):
            _flush_chunk()

        # If a single file exceeds the entire budget, truncate it
        if actual_tokens + overhead > chunk_token_budget:
            max_chars = (chunk_token_budget - overhead) * 4
            content = content[:max_chars] + "\n[TRUNCATED]"
            logger.debug(
                "Truncated %s: %d -> %d tokens",
                rel_path,
                actual_tokens,
                chunk_token_budget - overhead,
            )
            actual_tokens = chunk_token_budget - overhead
            files_truncated += 1

        block = f"--- FILE: {rel_path} ---\n{content}\n--- END FILE ---"
        current_parts.append(block)
        current_tokens += actual_tokens + overhead
        current_file_count += 1
        total_tokens += actual_tokens + overhead
        files_included += 1

    _flush_chunk()

    if skipped_read or skipped_binary:
        logger.debug(
            "Context skips: %d unreadable, %d binary", skipped_read, skipped_binary
        )

    summary = (
        f"{files_included} files in {len(chunks)} chunk(s), "
        f"~{total_tokens} tokens, {files_truncated} truncated"
    )
    logger.info("Context built: %s", summary)

    return BuiltContext(
        chunks=chunks,
        total_tokens=total_tokens,
        files_included=files_included,
        files_truncated=files_truncated,
        summary_line=summary,
    )
