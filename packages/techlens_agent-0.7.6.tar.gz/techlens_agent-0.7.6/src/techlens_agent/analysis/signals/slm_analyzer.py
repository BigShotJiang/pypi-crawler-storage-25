"""SLM Agent for code analysis using local language models.

Provides structured queries against source code using Ollama-hosted models.
Single-chunk repos get one SLM call. Multi-chunk repos use a chunk-pass
followed by a merge-pass (N+1 calls total).
"""

import json
import logging
import re
from enum import Enum
from typing import Any, ClassVar, Optional

from pydantic import BaseModel, Field

from ..slm_config import SlmConfig
from .context_builder import ContextChunk
from .slm_prompts import CHUNK_ANALYSIS_PROMPT, MERGE_PROMPT, SYSTEM_PROMPT

try:
    import ollama
except ImportError:
    ollama = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Query types
# ---------------------------------------------------------------------------


class SLMAgentQueries(str, Enum):
    """Available query types for the SLM agent."""

    CHUNK_ANALYSIS = "chunk_analysis"
    MERGE_ASSESSMENT = "merge_assessment"
    GLUE_VS_ORIGINAL = "glue_vs_original"
    CODE_VALUE_ASSESSMENT = "code_value_assessment"
    COMBINED_OUTLIER_ASSESSMENT = "combined_outlier_assessment"
    PER_FILE_VALUE = "per_file_value"
    PROGRAM_VALUE_SYNTHESIS = "program_value_synthesis"
    LM_CODE_VALUE = "lm_code_value"


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class SlmResponse(BaseModel):
    """Base response from an SLM query."""

    raw_response: str = ""
    error: Optional[str] = None


class AssessmentResponse(SlmResponse):
    """Response for code assessment queries."""

    assessment: str = "unknown"
    assessment_score: float = Field(default=0.0, ge=0.0, le=1.0)
    notes: list[str] = Field(default_factory=list)


class GlueCodeResponse(SlmResponse):
    """Response for glue vs original code queries."""

    originality_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    glue_files: list[str] = Field(default_factory=list)
    original_files: list[str] = Field(default_factory=list)
    rationale: str = ""


class CodeValueResponse(SlmResponse):
    """Response for code value/uniqueness assessment queries."""

    uniqueness_score: float = Field(default=0.0, ge=0.0, le=1.0)
    novel_concepts: list[str] = Field(default_factory=list)
    innovative_files: list[str] = Field(default_factory=list)
    rationale: str = ""


class CombinedOutlierResponse(SlmResponse):
    """Combined code-value + glue-vs-original assessment in one call."""

    uniqueness_score: float = Field(default=0.0, ge=0.0, le=1.0)
    novel_concepts: list[str] = Field(default_factory=list)
    innovative_files: list[str] = Field(default_factory=list)
    code_value_rationale: str = ""
    originality_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    glue_files: list[str] = Field(default_factory=list)
    original_files: list[str] = Field(default_factory=list)
    glue_rationale: str = ""


class PerFileValueItem(BaseModel):
    """A single file's value assessment from the SLM."""

    path: str = ""
    description: str = ""
    value_score: float = Field(default=0.0, ge=0.0, le=1.0)
    rationale: str = ""


class PerFileValueResponse(SlmResponse):
    """Response for per-file value assessment queries."""

    files: list[PerFileValueItem] = Field(default_factory=list)


class ProgramValueSynthesisResponse(SlmResponse):
    """Response for program-level value synthesis."""

    program_description: str = ""
    value_score: float = Field(default=0.0, ge=0.0, le=1.0)
    rationale: str = ""
    notes: list[str] = Field(default_factory=list)


class LmCodeValueResponse(SlmResponse):
    """Response for LM-derived code value assessment (uniqueness + difficulty + quality)."""

    lm_uniqueness: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_complexity: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_quality: float = Field(default=0.0, ge=0.0, le=1.0)
    lm_code_value_rationale: str = ""


class SlmAfterFilterResult(BaseModel):
    """Final result of the SLM after-filter analysis."""

    assessment: str = "unknown"
    assessment_score: float = Field(default=0.0, ge=0.0, le=1.0)
    notes: list[str] = Field(default_factory=list)
    chunk_count: int = 0
    raw_responses: list[str] = Field(default_factory=list)
    model: str = ""
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Query -> Response type mapping
# ---------------------------------------------------------------------------

QUERY_RESPONSE_TYPES: dict[SLMAgentQueries, type[SlmResponse]] = {
    SLMAgentQueries.GLUE_VS_ORIGINAL: GlueCodeResponse,
    SLMAgentQueries.CODE_VALUE_ASSESSMENT: CodeValueResponse,
    SLMAgentQueries.COMBINED_OUTLIER_ASSESSMENT: CombinedOutlierResponse,
    SLMAgentQueries.PER_FILE_VALUE: PerFileValueResponse,
    SLMAgentQueries.PROGRAM_VALUE_SYNTHESIS: ProgramValueSynthesisResponse,
    SLMAgentQueries.LM_CODE_VALUE: LmCodeValueResponse,
}


def response_type_for_query(query_type: SLMAgentQueries) -> type[SlmResponse]:
    """Return the response type for a given query type."""
    return QUERY_RESPONSE_TYPES.get(query_type, AssessmentResponse)


# ---------------------------------------------------------------------------
# JSON parsing helpers
# ---------------------------------------------------------------------------


def _extract_fenced_json(text: str) -> Optional[str]:
    """Try to pull JSON from a ```json ... ``` fenced block."""
    m = re.search(r"```(?:json)?\s*\n?(.*?)```", text, re.DOTALL)
    return m.group(1).strip() if m else None


def _extract_braces(text: str) -> Optional[str]:
    """Last-resort: grab the first ``{ ... }`` span."""
    m = re.search(r"\{.*\}", text, re.DOTALL)
    return m.group(0) if m else None


def _parse_response(text: str) -> dict[str, Any]:
    """Attempt to parse an SLM response as JSON with multiple fallbacks."""
    text = text.strip()

    # 1. Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # 2. Fenced code block
    fenced = _extract_fenced_json(text)
    if fenced:
        try:
            return json.loads(fenced)
        except json.JSONDecodeError:
            pass

    # 3. Brace extraction
    braces = _extract_braces(text)
    if braces:
        try:
            return json.loads(braces)
        except json.JSONDecodeError:
            pass

    return {"raw_response": text}


# ---------------------------------------------------------------------------
# SLM Agent
# ---------------------------------------------------------------------------


class SLMAgent:
    """Agent for running SLM queries against source code."""

    Queries = SLMAgentQueries  # Alias for backwards compatibility

    QUERY_PROMPTS: ClassVar[dict[SLMAgentQueries, str]] = {
        SLMAgentQueries.CHUNK_ANALYSIS: CHUNK_ANALYSIS_PROMPT,
        SLMAgentQueries.MERGE_ASSESSMENT: MERGE_PROMPT,
        SLMAgentQueries.GLUE_VS_ORIGINAL: """\
Analyze the following source code files and determine whether they represent \
"glue code" or "original code" specific to this repository.

**Glue code** includes:
- Boilerplate configuration (webpack, eslint, tsconfig, CI/CD)
- Generic adapters, wrappers, or shims around libraries
- Auto-generated code (protobuf stubs, ORM models, API clients)
- Copy-pasted snippets from Stack Overflow or documentation
- Framework scaffolding with minimal customization

**Original code** includes:
- Domain-specific business logic unique to this project
- Custom algorithms or data structures
- Application-specific models and services
- Code with project-specific naming, comments, or patterns
- Non-trivial implementations that solve the project's core problem

Respond with ONLY this JSON (no other text):
{{
  "originality_ratio": <float 0.0 to 1.0>,
  "glue_files": ["<file1>", "<file2>", ...],
  "original_files": ["<file1>", "<file2>", ...],
  "rationale": "<brief explanation>"
}}

Scoring (originality_ratio):
- 0.0-0.2 → Almost all glue code (boilerplate, config, generated)
- 0.2-0.4 → Mostly glue with some original logic
- 0.4-0.6 → Mixed glue and original code
- 0.6-0.8 → Mostly original with standard glue
- 0.8-1.0 → Highly original, project-specific code

Source code:
{context}""",
        SLMAgentQueries.CODE_VALUE_ASSESSMENT: """\
Analyze the following source code files and assess the uniqueness and originality \
of the ideas expressed in the code.

Look for evidence of:
- **Novel algorithms or approaches** — custom solutions not found in standard libraries
- **Innovative architecture** — unique patterns or designs specific to the problem domain
- **Domain expertise** — specialized knowledge encoded in the logic
- **Creative problem-solving** — non-obvious solutions to complex problems
- **Proprietary value** — implementations that would be hard to replicate without this code

Contrast with:
- Standard CRUD operations
- Common design patterns applied without modification
- Thin wrappers around existing libraries
- Tutorial-level implementations

Respond with ONLY this JSON (no other text):
{{
  "uniqueness_score": <float 0.0 to 1.0>,
  "novel_concepts": ["<concept 1>", "<concept 2>", ...],
  "innovative_files": ["<file1>", "<file2>", ...],
  "rationale": "<brief explanation of what makes this code valuable or not>"
}}

Scoring (uniqueness_score):
- 0.0-0.2 → Commodity code (standard patterns, nothing proprietary)
- 0.2-0.4 → Minor customizations on common approaches
- 0.4-0.6 → Some original ideas mixed with standard implementations
- 0.6-0.8 → Significant original thinking, domain-specific solutions
- 0.8-1.0 → Highly innovative, novel algorithms or unique approaches

Source code:
{context}""",
        SLMAgentQueries.COMBINED_OUTLIER_ASSESSMENT: """\
Analyze these source code files and provide TWO assessments in one JSON response:
1. **Code Value**: How unique/original are the ideas?
2. **Glue vs Original**: How much is boilerplate vs original code?

Respond with ONLY this JSON (no other text):
{{
  "uniqueness_score": <float 0.0-1.0>,
  "novel_concepts": ["<concept>", ...],
  "innovative_files": ["<file>", ...],
  "code_value_rationale": "<1 sentence>",
  "originality_ratio": <float 0.0-1.0>,
  "glue_files": ["<file>", ...],
  "original_files": ["<file>", ...],
  "glue_rationale": "<1 sentence>"
}}

uniqueness_score: 0.0=commodity, 0.5=some originality, 1.0=highly novel.
originality_ratio: 0.0=all glue/boilerplate, 0.5=mixed, 1.0=all original.

Source code:
{context}""",
        SLMAgentQueries.PER_FILE_VALUE: """\
For EACH source file below, provide a brief description and value score.
Keep descriptions under 10 words. Keep rationales under 10 words.

Respond with ONLY this JSON (no other text):
{{
  "files": [
    {{
      "path": "<filename>",
      "description": "<max 10 words: what this file does>",
      "value_score": <float 0.0 to 1.0>,
      "rationale": "<max 10 words: why this score>"
    }}
  ]
}}

value_score: 0.0=boilerplate/config, 0.5=mixed, 1.0=novel core IP.

Source code:
{context}""",
        SLMAgentQueries.PROGRAM_VALUE_SYNTHESIS: """\
Given these per-file summaries, describe the overall program and score its value.

Respond with ONLY this JSON (no other text):
{{
  "program_description": "<2-3 sentences: what this software does>",
  "value_score": <float 0.0 to 1.0>,
  "rationale": "<1 sentence: why this score>",
  "notes": ["<observation 1>", "<observation 2>", ...]
}}

value_score: 0.0=commodity clone, 0.5=useful with some originality, 1.0=highly novel core IP.
notes: 2-5 brief observations about architecture, quality, risks, or notable patterns.

Per-file summaries:
{context}""",
        SLMAgentQueries.LM_CODE_VALUE: """\
Evaluate the following source code on three independent dimensions.

**1. Uniqueness** — How novel or proprietary is this code?
- 0.0-0.2: Commodity (boilerplate, tutorials, standard CRUD)
- 0.2-0.4: Minor customizations on common patterns
- 0.4-0.6: Some original ideas mixed with standard code
- 0.6-0.8: Significant original thinking, domain-specific solutions
- 0.8-1.0: Highly innovative, novel algorithms or unique approaches

**2. Difficulty** — How hard would it be to write this from scratch?
- 0.0-0.2: Trivial (simple scripts, config wrappers)
- 0.2-0.4: Straightforward (standard patterns, well-documented APIs)
- 0.4-0.6: Moderate (requires domain knowledge or careful design)
- 0.6-0.8: Hard (complex algorithms, intricate state management)
- 0.8-1.0: Very hard (research-level, advanced math, deep systems work)

**3. Quality** — How well-engineered is the code?
- 0.0-0.2: Poor (no structure, no error handling, unclear intent)
- 0.2-0.4: Below average (some structure but fragile, inconsistent)
- 0.4-0.6: Average (reasonable structure, basic error handling)
- 0.6-0.8: Good (clean abstractions, tested, well-documented)
- 0.8-1.0: Excellent (exemplary design, robust, production-grade)

Respond with ONLY this JSON (no other text):
{{
  "lm_uniqueness": <float 0.0 to 1.0>,
  "lm_complexity": <float 0.0 to 1.0>,
  "lm_quality": <float 0.0 to 1.0>,
  "lm_code_value_rationale": "<1-2 sentences explaining the scores>"
}}

Source code:
{context}""",
    }

    _default_config: ClassVar[SlmConfig] = SlmConfig()

    def __init__(self, config: Optional[SlmConfig] = None) -> None:
        self.config = config or self._default_config

    @classmethod
    def configure(cls, config: SlmConfig) -> None:
        """Set the default configuration for all instances."""
        cls._default_config = config

    @classmethod
    def query(
        cls,
        prompt: SLMAgentQueries,
        files: list[Any],
        config: Optional[SlmConfig] = None,
    ) -> SlmResponse:
        """Run a query against the SLM with the given files.

        Args:
            prompt: The query type to run
            files: List of file objects or paths to analyze
            config: Optional config override

        Returns:
            Appropriate response type based on the query
        """
        agent = cls(config)
        return agent._execute_query(prompt, files)

    def _execute_query(
        self,
        query_type: SLMAgentQueries,
        files: list[Any],
    ) -> SlmResponse:
        """Execute a query and return the parsed response."""
        prompt_template = self.QUERY_PROMPTS.get(query_type)
        if not prompt_template:
            return SlmResponse(error=f"Unknown query type: {query_type}")

        context = self._build_context(files)
        prompt = prompt_template.format(context=context)

        logger.info(
            "=== SLM EXECUTE_QUERY === type=%s | files=%d",
            query_type.value,
            len(files),
        )

        try:
            raw = self._call_slm(prompt)
            parsed = _parse_response(raw)
            parsed["raw_response"] = raw

            response_cls = response_type_for_query(query_type)
            result = response_cls.model_validate(parsed)
            logger.info(
                "=== SLM QUERY RESULT === type=%s | response_cls=%s",
                query_type.value,
                response_cls.__name__,
            )
            return result
        except Exception as exc:
            logger.exception("SLM query failed")
            return SlmResponse(error=str(exc))

    def _build_context(self, files: list[Any]) -> str:
        """Build context string from files."""
        if not files:
            return ""

        parts = []
        for f in files:
            if hasattr(f, "context_string"):
                parts.append(f.context_string)
            elif hasattr(f, "path") and hasattr(f, "content"):
                parts.append(f"--- {f.path} ---\n{f.content}")
            elif isinstance(f, str):
                parts.append(f)
            else:
                parts.append(str(f))
        return "\n\n".join(parts)

    @staticmethod
    def _estimate_num_ctx(prompt: str) -> int:
        """Estimate a tight num_ctx from the actual prompt length.

        Covers system-prompt tokens + user-prompt tokens + 2048 output headroom.
        Minimum 4096 to avoid degenerate contexts.
        """
        system_tokens = len(SYSTEM_PROMPT) // 4
        prompt_tokens = len(prompt) // 4
        return max(4096, system_tokens + prompt_tokens + 2048)

    def _call_slm(self, prompt: str) -> str:
        """Call the Ollama chat API and return the response text."""
        if ollama is None:
            raise RuntimeError(
                "The 'ollama' package is not installed. "
                "Install it with: pip install ollama>=0.4.0"
            )

        num_ctx = self._estimate_num_ctx(prompt)
        logger.info(
            "=== SLM QUERY START === Model: %s | Prompt: %d chars | num_ctx: %d",
            self.config.model,
            len(prompt),
            num_ctx,
        )
        logger.debug("=== SLM PROMPT ===\n%s", prompt)

        client = ollama.Client(
            host=self.config.ollama_host,
            timeout=self.config.request_timeout,
        )
        response = client.chat(
            model=self.config.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            format="json",
            options={
                "temperature": self.config.temperature,
                "num_ctx": num_ctx,
            },
        )
        try:
            text = response["message"]["content"]
        except (KeyError, TypeError) as e:
            raise RuntimeError(f"Unexpected Ollama response format: {response}") from e

        logger.info("=== SLM RESPONSE === %d chars", len(text))
        logger.debug("=== SLM RESPONSE TEXT ===\n%s", text)
        logger.info("=== SLM QUERY END ===")

        return text


# ---------------------------------------------------------------------------
# Signal definitions
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNALS = [
    SignalDefinition(
        name="lm_uniqueness",
        description="LM-assessed code uniqueness/novelty",
        level=SignalLevel.REPO,
        category="slm",
        requires_slm=True,
        composites=[
            CompositeContribution(composite="lm_code_value_score", weight=1 / 3),
        ],
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
    SignalDefinition(
        name="lm_complexity",
        description="LM-assessed implementation difficulty",
        level=SignalLevel.REPO,
        category="slm",
        requires_slm=True,
        composites=[
            CompositeContribution(composite="lm_code_value_score", weight=1 / 3),
        ],
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
    SignalDefinition(
        name="lm_quality",
        description="LM-assessed code quality",
        level=SignalLevel.REPO,
        category="slm",
        requires_slm=True,
        composites=[
            CompositeContribution(composite="lm_code_value_score", weight=1 / 3),
        ],
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
    SignalDefinition(
        name="program_value_score",
        description="SLM-synthesized holistic program value from per-file summaries",
        level=SignalLevel.REPO,
        category="slm",
        requires_slm=True,
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
    SignalDefinition(
        name="slm_value_score",
        description="SLM-assessed value score per individual source file",
        level=SignalLevel.PER_FILE,
        category="slm",
        requires_slm=True,
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
    SignalDefinition(
        name="assessment_score",
        description="Engineered-vs-assembled verdict from chunk+merge SLM pipeline",
        level=SignalLevel.REPO,
        category="slm",
        requires_slm=True,
        why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
    ),
]


# ---------------------------------------------------------------------------
# Legacy API (for backwards compatibility)
# ---------------------------------------------------------------------------


def _call_slm_legacy(prompt: str, config: SlmConfig) -> str:
    """Call the Ollama chat API and return the response text."""
    if ollama is None:
        raise RuntimeError(
            "The 'ollama' package is not installed. "
            "Install it with: pip install ollama>=0.4.0"
        )

    num_ctx = SLMAgent._estimate_num_ctx(prompt)
    logger.info(
        "=== SLM LEGACY QUERY START === Model: %s | Prompt: %d chars | num_ctx: %d",
        config.model,
        len(prompt),
        num_ctx,
    )
    logger.debug("=== SLM LEGACY PROMPT ===\n%s", prompt)

    client = ollama.Client(host=config.ollama_host, timeout=config.request_timeout)
    response = client.chat(
        model=config.model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        format="json",
        options={
            "temperature": config.temperature,
            "num_ctx": num_ctx,
        },
    )
    try:
        text = response["message"]["content"]
    except (KeyError, TypeError) as e:
        raise RuntimeError(f"Unexpected Ollama response format: {response}") from e

    logger.info("=== SLM LEGACY RESPONSE === %d chars", len(text))
    logger.debug("=== SLM LEGACY RESPONSE TEXT ===\n%s", text)
    logger.info("=== SLM LEGACY QUERY END ===")

    return text


def _analyse_chunk(chunk: ContextChunk, config: SlmConfig) -> dict[str, Any]:
    """Run the chunk-analysis prompt against one chunk."""
    logger.info(
        "=== ANALYSE CHUNK === files=%d | tokens=%d",
        chunk.file_count,
        getattr(chunk, "token_count", 0),
    )
    prompt = CHUNK_ANALYSIS_PROMPT.format(context=chunk.context_string)
    raw = _call_slm_legacy(prompt, config)
    parsed = _parse_response(raw)
    parsed["_file_count"] = chunk.file_count
    parsed["_raw"] = raw
    logger.info(
        "=== ANALYSE CHUNK DONE === assessment=%s",
        parsed.get("assessment", "unknown"),
    )
    return parsed


def _merge_assessments(
    chunk_results: list[dict[str, Any]],
    config: SlmConfig,
) -> dict[str, Any]:
    """Run the merge prompt over all chunk-level assessments."""
    logger.info(
        "=== MERGE ASSESSMENTS START === chunks=%d",
        len(chunk_results),
    )
    summaries = []
    for i, cr in enumerate(chunk_results, 1):
        summary = {
            "chunk": i,
            "file_count": cr.get("_file_count", 0),
            "assessment": cr.get("assessment", "unknown"),
            "assessment_score": cr.get("assessment_score", 0.0),
            "notes": cr.get("notes", []),
        }
        summaries.append(json.dumps(summary, indent=2))

    prompt = MERGE_PROMPT.format(
        chunk_count=len(chunk_results),
        chunk_assessments="\n\n".join(summaries),
    )
    raw = _call_slm_legacy(prompt, config)
    parsed = _parse_response(raw)
    parsed["_raw"] = raw
    logger.info(
        "=== MERGE ASSESSMENTS DONE === assessment=%s",
        parsed.get("assessment", "unknown"),
    )
    return parsed


def analyse(
    chunks: list[ContextChunk],
    config: Optional[SlmConfig] = None,
) -> SlmAfterFilterResult:
    """Run the full SLM analysis (chunk pass + optional merge pass).

    This is the legacy entry point. Consider using SLMAgent directly.

    Returns an SlmAfterFilterResult with the consolidated verdict.
    """
    if config is None:
        config = SlmConfig()

    result = SlmAfterFilterResult(model=config.model, chunk_count=len(chunks))

    if not chunks:
        result.error = "No source-code chunks to analyse"
        return result

    try:
        if len(chunks) == 1:
            parsed = _analyse_chunk(chunks[0], config)
            result.raw_responses.append(parsed.pop("_raw", ""))
            parsed.pop("_file_count", None)
            result.assessment = parsed.get("assessment", "unknown")
            result.assessment_score = float(parsed.get("assessment_score", 0.0))
            result.notes = parsed.get("notes", [])
        else:
            chunk_results: list[dict[str, Any]] = []
            for chunk in chunks:
                parsed = _analyse_chunk(chunk, config)
                result.raw_responses.append(parsed.pop("_raw", ""))
                chunk_results.append(parsed)

            merged = _merge_assessments(chunk_results, config)
            result.raw_responses.append(merged.pop("_raw", ""))
            result.assessment = merged.get("assessment", "unknown")
            result.assessment_score = float(merged.get("assessment_score", 0.0))
            result.notes = merged.get("notes", [])

    except Exception as exc:
        logger.exception("SLM analysis failed")
        result.error = str(exc)

    return result
