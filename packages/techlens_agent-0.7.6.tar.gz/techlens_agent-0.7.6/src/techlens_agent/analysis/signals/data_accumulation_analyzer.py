"""Data accumulation analyzer — detect data accumulation moat.

Scores repositories based on the presence of migration/seed files and the
span of git history, both of which indicate long-lived data accumulation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

try:
    import git
except ImportError:
    git = None  # type: ignore[assignment]

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Path patterns
# ---------------------------------------------------------------------------

MIGRATION_PATTERNS: set[str] = {
    "migration",
    "migrations",
    "migrate",
    "db/migrate",
    "alembic",
    "flyway",
    "liquibase",
    "knex/migrations",
    "prisma/migrations",
    "sequelize/migrations",
    "typeorm/migrations",
}

SEED_PATTERNS: set[str] = {
    "seed",
    "seeds",
    "seeders",
    "fixtures",
    "db/seeds",
}

# Split into single-part and multi-part for efficient matching
_SINGLE_PART_PATTERNS: set[str] = {
    p for p in MIGRATION_PATTERNS | SEED_PATTERNS if "/" not in p
}
_MULTI_PART_PATTERNS: set[str] = {
    p for p in MIGRATION_PATTERNS | SEED_PATTERNS if "/" in p
}


def _is_migration_or_seed(path: str) -> bool:
    """Check whether a file path matches migration or seed patterns."""
    parts = path.split("/")
    if _SINGLE_PART_PATTERNS.intersection(parts):
        return True
    for pattern in _MULTI_PART_PATTERNS:
        if pattern in path:
            return True
    return False


def _compute_history_score(repo_path: str) -> float:
    """Return a 0-1 score based on git history span (1+ year = full score)."""
    if git is None:
        return 0.0
    try:
        repo = git.Repo(repo_path)
        commits = list(repo.iter_commits("--all", max_count=1)) + list(
            repo.iter_commits("--all", max_count=1, reverse=True)
        )
        if len(commits) < 2:
            return 0.0
        last_date = commits[0].committed_datetime
        first_date = commits[1].committed_datetime
        span_days = (last_date - first_date).days
        return min(span_days / 365, 1.0)
    except Exception:
        logger.debug("Could not read git history for %s", repo_path, exc_info=True)
        return 0.0


def analyze_data_accumulation(
    file_paths: list[str],
    repo_path: str,
    manager: AnalysisManager | None = None,
) -> float | None:
    """Return data accumulation score, or None if no evidence."""
    git_available = git is not None
    if not file_paths and not git_available:
        return None

    # --- Migration / seed file ratio ---
    migration_seed_count = 0
    for p in file_paths:
        if _is_migration_or_seed(p):
            migration_seed_count += 1
            if manager is not None:
                manager.add_weight(p, "data_accumulation", 1.0)
    total_files = len(file_paths)
    if total_files > 0:
        ratio = migration_seed_count / total_files
        migration_score = min(ratio / 0.05, 1.0)
    else:
        migration_score = 0.0

    # --- Git history span ---
    history_score = _compute_history_score(repo_path)

    if migration_seed_count == 0 and history_score == 0.0:
        return None

    combined = 0.6 * migration_score + 0.4 * history_score

    logger.info(
        "Data accumulation: %d migration/seed files (%.2f), history=%.2f, combined=%.2f",
        migration_seed_count,
        migration_score,
        history_score,
        combined,
    )
    return combined


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="data_accumulation_pattern",
    description="Migration/seed files + git history span indicating data accumulation moat",
    level=SignalLevel.REPO,
    category="architecture",
    manager_weight=1.0,
    requires_git=True,
    composites=[
        CompositeContribution(
            composite="moat_score",
            weight=0.10,
        ),
    ],
    why_it_matters="Detects data flywheel effects. 200+ migration files represent years of schema evolution driven by real-world usage. The accumulated data model and the logic to manage it are often more valuable than the application code itself.",
)
