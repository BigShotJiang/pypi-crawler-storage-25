"""Manifest parser — extract dependency names from package manifests.

Walks a repository for common package manifest files and returns the set of
top-level dependency names (lowercase, no versions).  No network calls, no
transitive resolution, no lock-file parsing.

Unlike ``techlens_agent.dependencies.walk``, this module only reads files and
extracts names — it does not instantiate Walker classes or write output files.
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
from collections.abc import Callable

logger = logging.getLogger(__name__)

# Directories to skip during os.walk
_SKIP_DIRS = frozenset(
    {
        "node_modules",
        "vendor",
        ".git",
        "venv",
        ".venv",
        "__pycache__",
        ".tox",
        ".eggs",
        "dist",
        "build",
    }
)

# ---------------------------------------------------------------------------
# Individual manifest parsers
# ---------------------------------------------------------------------------

_REQ_VERSION_RE = re.compile(r"[><=!~;@\[].*")
_GEM_RE = re.compile(r"""gem\s+['"]([^'"]+)['"]""")
_CSPROJ_RE = re.compile(r'<PackageReference\s+Include="([^"]+)"', re.IGNORECASE)
_POM_ARTIFACT_RE = re.compile(r"<artifactId>\s*([^<]+?)\s*</artifactId>")


def _parse_package_json(path: str) -> set[str]:
    """Extract dependency names from package.json."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    names: set[str] = set()
    for key in ("dependencies", "devDependencies"):
        section = data.get(key)
        if isinstance(section, dict):
            names.update(section.keys())
    return names


def _parse_requirements_txt(path: str) -> set[str]:
    """Extract package names from requirements*.txt."""
    names: set[str] = set()
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Strip inline comments
            line = line.split("#", 1)[0].strip()
            # Strip extras e.g. package[extra]
            name = re.split(r"[\[><=!~;@]", line, maxsplit=1)[0].strip()
            if name:
                names.add(name)
    return names


def _parse_pyproject_toml(path: str) -> set[str]:
    """Extract dependency names from pyproject.toml."""
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            logger.warning("tomli not installed; cannot parse %s", path)
            return set()

    with open(path, "rb") as f:
        data = tomllib.load(f)

    names: set[str] = set()

    # [project.dependencies] — list of PEP 508 strings
    for dep in data.get("project", {}).get("dependencies", []):
        name = re.split(r"[\[><=!~;@\s]", dep, maxsplit=1)[0].strip()
        if name:
            names.add(name)

    # [tool.poetry.dependencies]
    poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
    if isinstance(poetry_deps, dict):
        names.update(k for k in poetry_deps if k.lower() != "python")

    return names


def _parse_go_mod(path: str) -> set[str]:
    """Extract module paths from go.mod require blocks."""
    names: set[str] = set()
    with open(path, encoding="utf-8") as f:
        content = f.read()

    # Match require ( ... ) blocks
    for block in re.finditer(r"require\s*\((.*?)\)", content, re.DOTALL):
        for line in block.group(1).splitlines():
            line = line.strip()
            if line and not line.startswith("//"):
                # First token is the module path
                module = line.split()[0]
                names.add(module)

    # Also handle single-line require directives
    for m in re.finditer(r"^require\s+(\S+)", content, re.MULTILINE):
        names.add(m.group(1))

    return names


def _parse_pom_xml(path: str) -> set[str]:
    """Extract artifactId values from pom.xml via regex."""
    with open(path, encoding="utf-8") as f:
        content = f.read()
    return {m.group(1) for m in _POM_ARTIFACT_RE.finditer(content)}


def _parse_gemfile(path: str) -> set[str]:
    """Extract gem names from Gemfile."""
    with open(path, encoding="utf-8") as f:
        content = f.read()
    return {m.group(1) for m in _GEM_RE.finditer(content)}


def _parse_composer_json(path: str) -> set[str]:
    """Extract package names from composer.json."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    names: set[str] = set()
    for key in ("require", "require-dev"):
        section = data.get(key)
        if isinstance(section, dict):
            names.update(section.keys())
    return names


def _parse_cargo_toml(path: str) -> set[str]:
    """Extract dependency crate names from Cargo.toml."""
    if sys.version_info >= (3, 11):
        import tomllib
    else:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            logger.warning("tomli not installed; cannot parse %s", path)
            return set()

    with open(path, "rb") as f:
        data = tomllib.load(f)

    names: set[str] = set()
    for section in ("dependencies", "dev-dependencies", "build-dependencies"):
        deps = data.get(section)
        if isinstance(deps, dict):
            names.update(deps.keys())
    return names


def _parse_csproj(path: str) -> set[str]:
    """Extract PackageReference names from .csproj files."""
    with open(path, encoding="utf-8") as f:
        content = f.read()
    return {m.group(1) for m in _CSPROJ_RE.finditer(content)}


# Map filename (or pattern) to parser
_EXACT_PARSERS: dict[str, Callable] = {
    "package.json": _parse_package_json,
    "pyproject.toml": _parse_pyproject_toml,
    "go.mod": _parse_go_mod,
    "pom.xml": _parse_pom_xml,
    "Gemfile": _parse_gemfile,
    "composer.json": _parse_composer_json,
    "Cargo.toml": _parse_cargo_toml,
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_dependency_names(repo_path: str) -> set[str]:
    """Walk *repo_path* for package manifests and return dependency names.

    Returns a set of **lowercase** package/module names with no version info.
    Skips common vendor directories and logs warnings on parse errors.
    """
    deps: set[str] = set()

    for dirpath, dirnames, filenames in os.walk(repo_path):
        # Prune vendor dirs in-place so os.walk skips them
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]

        for fname in filenames:
            full = os.path.join(dirpath, fname)
            parsed: set[str] | None = None

            try:
                # Exact-name manifests
                if fname in _EXACT_PARSERS:
                    parsed = _EXACT_PARSERS[fname](full)

                # requirements*.txt (various naming conventions)
                elif fname.startswith("requirements") and fname.endswith(".txt"):
                    parsed = _parse_requirements_txt(full)

                # *.csproj files
                elif fname.endswith(".csproj"):
                    parsed = _parse_csproj(full)

            except Exception:
                logger.warning("Failed to parse manifest %s", full, exc_info=True)
                continue

            if parsed:
                deps.update(parsed)

    result = {name.lower() for name in deps}
    logger.info(
        "Manifest parser: found %d unique dependency names in %s",
        len(result),
        repo_path,
    )
    return result
