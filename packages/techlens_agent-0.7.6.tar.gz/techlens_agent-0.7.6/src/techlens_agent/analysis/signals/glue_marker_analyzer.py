"""Glue marker analyzer - detects patterns indicative of glue/boilerplate code.

Glue code markers include:
- High import density
- Decorators (especially framework decorators)
- Configuration patterns
- Boilerplate patterns
- Framework scaffolding
"""

from .data.glue_patterns import (
    BOILERPLATE_PATTERNS,
    CONFIG_PATTERNS,
    DECORATOR_PATTERNS,
    IMPORT_PATTERNS,
)


def analyze_glue_markers(content: str) -> float:
    """Analyze content for glue code markers.

    Args:
        content: Combined source code content.

    Returns:
        Ratio of glue markers to total lines (0.0-1.0).
        Higher values indicate more glue/boilerplate code.
    """
    if not content.strip():
        return 0.0

    lines = [line for line in content.split("\n") if line.strip()]
    total_lines = len(lines)

    if total_lines == 0:
        return 0.0

    # Count different marker types
    import_count = len(IMPORT_PATTERNS.findall(content))
    decorator_count = len(DECORATOR_PATTERNS.findall(content))
    config_count = len(CONFIG_PATTERNS.findall(content))
    boilerplate_count = len(BOILERPLATE_PATTERNS.findall(content))

    # Weight the markers
    # - Imports are common, lower weight
    # - Decorators indicate framework glue
    # - Config patterns are strong glue indicators
    # - Boilerplate is expected but indicates assembly
    weighted_markers = (
        import_count * 0.5
        + decorator_count * 1.5
        + config_count * 2.0
        + boilerplate_count * 1.0
    )

    # Normalize by total lines
    # A typical file might have ~10% glue markers
    # Heavy glue code might have 30%+
    raw_ratio = weighted_markers / total_lines

    # Normalize to 0-1 scale (assume 0.3 is "fully glue")
    # Clamp to 1.0 max
    normalized_ratio = min(raw_ratio / 0.3, 1.0)

    return normalized_ratio


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="gluemarker_ratio",
    description="Weighted ratio of glue/boilerplate markers to total lines",
    level=SignalLevel.REPO,
    category="heuristic",
    composites=[
        CompositeContribution(composite="moat_score", weight=0.15, inverted=True),
    ],
    why_it_matters="Quantifies how much of the codebase is commodity wiring vs. substantive logic. A product that's 70% glue code has a fundamentally different value proposition than one with deep proprietary processing. Directly answers: 'How much of this is replaceable by off-the-shelf tools or AI?'",
)
