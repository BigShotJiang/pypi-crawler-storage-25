"""Import graph analyzer — compute indegree from source-level imports.

Parses import/require statements from Python and JS/TS files, resolves
them to repo-internal files, and computes indegree per file.
"""

from __future__ import annotations

import logging
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

WEIGHT_IMPORT_INDEGREE: float = 2.0

# ---------------------------------------------------------------------------
# Import patterns
# ---------------------------------------------------------------------------

# Python: import foo.bar  or  from foo.bar import baz
_PY_IMPORT = re.compile(r"^\s*(?:from\s+([\w.]+)|import\s+([\w.]+))", re.MULTILINE)

# JS/TS: import ... from './path'  or  require('./path')
_JS_IMPORT = re.compile(
    r"""(?:import\s+.*?\s+from\s+['"](\.[^'"]+)['"]|require\(\s*['"](\.[^'"]+)['"]\s*\))""",
    re.MULTILINE,
)

# Source extensions we can parse
_PY_EXTENSIONS = {".py"}
_JS_EXTENSIONS = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}


def _build_suffix_map(known_files: set[str]) -> dict[str, str]:
    """Build a map from path suffixes to full repo-relative paths.

    Handles repos where source lives under a prefix like ``src/`` or
    ``lib/``.  For example, ``src/pkg/mod.py`` produces entries for both
    ``src/pkg/mod.py`` and ``pkg/mod.py``, each pointing back to the
    original full path.  On collision the shortest full path wins (most
    specific).
    """
    suffix_map: dict[str, str] = {}
    for fp in known_files:
        parts = fp.split("/")
        for i in range(len(parts)):
            suffix = "/".join(parts[i:])
            existing = suffix_map.get(suffix)
            if existing is None or len(fp) < len(existing):
                suffix_map[suffix] = fp
    return suffix_map


def _resolve_python_import(
    module_path: str,
    repo_root: Path,
    known_files: set[str],
    suffix_map: dict[str, str],
) -> str | None:
    """Resolve a dotted Python import to a repo-relative file path."""
    # Convert dots to path separators
    parts = module_path.replace(".", os.sep)

    # Try as package (directory/__init__.py) or module (.py)
    candidates = [
        f"{parts}{os.sep}__init__.py",
        f"{parts}.py",
    ]
    for candidate in candidates:
        normalized = candidate.replace(os.sep, "/")
        if normalized in known_files:
            return normalized
        # Fall back to suffix match (handles src/ prefix etc.)
        matched = suffix_map.get(normalized)
        if matched is not None:
            return matched
    return None


def _resolve_js_import(
    import_path: str,
    importer_path: str,
    known_files: set[str],
    suffix_map: dict[str, str],
) -> str | None:
    """Resolve a relative JS/TS import to a repo-relative file path."""
    if not import_path.startswith("."):
        return None

    # Resolve relative to the importer's directory
    importer_dir = str(Path(importer_path).parent)
    resolved = os.path.normpath(os.path.join(importer_dir, import_path))
    resolved = resolved.replace(os.sep, "/")

    # Try exact match, then with extensions, then as index
    extensions = [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]
    candidates = [resolved]
    for ext in extensions:
        candidates.append(f"{resolved}{ext}")
        candidates.append(f"{resolved}/index{ext}")

    for candidate in candidates:
        if candidate in known_files:
            return candidate
        matched = suffix_map.get(candidate)
        if matched is not None:
            return matched
    return None


def analyze_import_graph(
    repo_path: str,
    file_paths: list[str],
    manager: AnalysisManager | None = None,
) -> dict[str, int]:
    """Build import graph and compute indegree per file.

    Args:
        repo_path: Path to the repository root.
        file_paths: List of repo-relative file paths to analyze.
        manager: Optional AnalysisManager to contribute indegree weights to.

    Returns:
        Dict mapping file path to its indegree count.
    """
    repo_root = Path(repo_path)
    known_files = set(file_paths)
    suffix_map = _build_suffix_map(known_files)
    # edges: target -> set of importers
    indegree_count: dict[str, int] = defaultdict(int)
    total_edges = 0
    unreadable = 0

    for file_path in file_paths:
        full_path = repo_root / file_path
        if not full_path.is_file():
            unreadable += 1
            continue

        try:
            content = full_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            unreadable += 1
            continue

        suffix = full_path.suffix.lower()
        targets: list[str | None] = []

        if suffix in _PY_EXTENSIONS:
            for m in _PY_IMPORT.finditer(content):
                module = m.group(1) or m.group(2)
                if module:
                    targets.append(
                        _resolve_python_import(
                            module,
                            repo_root,
                            known_files,
                            suffix_map,
                        )
                    )

        elif suffix in _JS_EXTENSIONS:
            for m in _JS_IMPORT.finditer(content):
                import_path = m.group(1) or m.group(2)
                if import_path:
                    targets.append(
                        _resolve_js_import(
                            import_path,
                            file_path,
                            known_files,
                            suffix_map,
                        )
                    )

        for target in targets:
            if target and target != file_path:
                indegree_count[target] += 1
                total_edges += 1

    logger.info(
        "Import graph: %d files, %d edges, max indegree=%d",
        len(file_paths),
        total_edges,
        max(indegree_count.values(), default=0),
    )
    if unreadable:
        logger.debug("Import graph: %d files unreadable/missing", unreadable)

    # Contribute to manager
    if manager is not None and indegree_count:
        max_indegree = max(indegree_count.values())
        if max_indegree > 0:
            for path, count in indegree_count.items():
                normalized = count / max_indegree
                manager.add_weight(
                    path, "import_indegree", normalized * WEIGHT_IMPORT_INDEGREE
                )
                manager.add_metadata(path, "indegree", count)

    return dict(indegree_count)


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="import_indegree",
    description="Normalized count of internal imports pointing to this file",
    level=SignalLevel.PER_FILE,
    category="architecture",
    manager_weight=2.0,
    why_it_matters="Identifies architectural bottlenecks and single points of failure. A file imported by dozens of others is both the most valuable and the most dangerous — any bug there cascades across the entire system, and it cannot be replaced without coordinated refactoring.",
)
