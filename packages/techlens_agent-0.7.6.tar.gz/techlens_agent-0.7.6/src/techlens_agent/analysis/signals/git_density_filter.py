"""Git Density Filter — score files by their change history.

Calculates a density_score for each file in a git repository based on
the cumulative additions, modifications, and deletions throughout its history.
Higher density files have had more activity over time.

Also tracks author diversity and co-change coupling between files.
Scoring weights are configurable via DensityWeights dataclass.
"""

from __future__ import annotations

import logging
import os
from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional

from git import Repo
from git.exc import InvalidGitRepositoryError

from ...utils.contributor import parse_co_authors

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Default weight multipliers for manager contributions
# ---------------------------------------------------------------------------

WEIGHT_GIT_DENSITY: float = 1.0
WEIGHT_AUTHOR_COUNT: float = 1.5
WEIGHT_COCHANGE: float = 0.8


@dataclass
class DensityWeights:
    """Configure how each type of change contributes to density score.

    Set a weight to 0.0 to exclude that metric from scoring.
    Negative weights will subtract from the score.

    Attributes:
        additions: Weight for lines added
        deletions: Weight for lines deleted
        commits: Weight per commit touching the file
        authors: Weight for author count (used in manager contribution)
    """

    additions: float = 1.0
    deletions: float = 0.0
    commits: float = 1.0
    authors: float = 1.5


@dataclass
class FileStats:
    """Raw git statistics for a single file."""

    path: str
    additions: int = 0
    deletions: int = 0
    commits: int = 0
    authors: set[str] = field(default_factory=set)
    author_commits: dict[str, int] = field(default_factory=lambda: defaultdict(int))


@dataclass
class FileDensity:
    """Density score result for a single file."""

    path: str
    density_score: float
    additions: int
    deletions: int
    commits: int
    authors: int = 0
    main_authors_ratio: list[dict] = field(default_factory=list)


@dataclass
class DensityResult:
    """Result of the git density calculation."""

    files: List[FileDensity]
    total_files: int
    max_density: float
    min_density: float
    weights_used: DensityWeights
    cochange_counts: dict[tuple[str, str], int] = field(default_factory=dict)
    enriched_commits: list[dict] = field(default_factory=list)


def calculate_density(
    repo_path: str,
    weights: Optional[DensityWeights] = None,
    normalize: bool = True,
    file_filter: Optional[set] = None,
    manager: Optional[AnalysisManager] = None,
) -> DensityResult:
    """Calculate density scores for all files in a git repository.

    Args:
        repo_path: Path to the git repository root.
        weights: DensityWeights instance configuring score calculation.
                 Defaults to counting only additions.
        normalize: If True, scores are normalized to 0.0-1.0 range.
                   If False, raw weighted sums are returned.
        file_filter: Optional set of file paths (relative) to include.
                     If None, all tracked files are included.
        manager: Optional AnalysisManager to contribute weights to.

    Returns:
        DensityResult containing scored files sorted by density (highest first).

    Raises:
        InvalidGitRepositoryError: If repo_path is not a valid git repository.
    """
    if weights is None:
        weights = DensityWeights()

    repo_path = os.path.abspath(repo_path)
    repo = Repo(repo_path)

    # Gather stats for all files across all commits
    logger.info("Scanning git history for %s", repo_path)

    # Use git log --numstat for accurate line counts + author emails
    file_stats, commit_file_groups, enriched_commits = _gather_numstat(
        repo, file_filter
    )
    all_authors = set()
    for s in file_stats.values():
        all_authors |= s.authors
    logger.info(
        "Git history: %d commits, %d tracked files, %d unique authors",
        len(commit_file_groups),
        len(file_stats),
        len(all_authors),
    )

    # Compute co-change pairs
    cochange_counts = _compute_cochange(commit_file_groups)

    # Calculate density scores
    densities: List[FileDensity] = []
    for path, stats in file_stats.items():
        score = (
            weights.additions * stats.additions
            + weights.deletions * stats.deletions
            + weights.commits * stats.commits
        )
        total = stats.commits
        dominant = [
            {"author": a, "ratio": round(c / total, 4)}
            for a, c in stats.author_commits.items()
            if total > 0 and c / total >= 0.7
        ]
        densities.append(
            FileDensity(
                path=path,
                density_score=score,
                additions=stats.additions,
                deletions=stats.deletions,
                commits=stats.commits,
                authors=len(stats.authors),
                main_authors_ratio=dominant,
            )
        )

    # Normalize if requested
    if normalize and densities:
        max_score = max(d.density_score for d in densities)
        min_score = min(d.density_score for d in densities)
        score_range = max_score - min_score

        if score_range > 0:
            for d in densities:
                d.density_score = (d.density_score - min_score) / score_range
            max_density = 1.0
            min_density = 0.0
        else:
            # All files have the same score
            uniform = 1.0 if max_score > 0 else 0.0
            for d in densities:
                d.density_score = uniform
            max_density = uniform
            min_density = uniform
    else:
        max_density = max((d.density_score for d in densities), default=0.0)
        min_density = min((d.density_score for d in densities), default=0.0)

    # Sort by density score descending
    densities.sort(key=lambda d: d.density_score, reverse=True)

    # Contribute weights to manager if provided
    if manager is not None:
        _contribute_to_manager(
            manager,
            densities,
            file_stats,
            cochange_counts,
        )

    logger.info("Calculated density for %d files", len(densities))

    return DensityResult(
        files=densities,
        total_files=len(densities),
        max_density=max_density,
        min_density=min_density,
        weights_used=weights,
        cochange_counts=cochange_counts,
        enriched_commits=enriched_commits,
    )


def _gather_numstat(
    repo: Repo, file_filter: Optional[set]
) -> tuple[Dict[str, FileStats], list[set[str]], list[dict]]:
    """Use git log --numstat to get accurate addition/deletion counts.

    Returns:
        Tuple of (file_stats dict, list of file sets per commit, enriched commits).
    """
    file_stats: Dict[str, FileStats] = {}
    commit_file_groups: list[set[str]] = []
    enriched_commits: list[dict] = []

    # Format: hash|author_name|author_email|date_iso|parents\nbody\nEND_MSG
    log_output = repo.git.log(
        "--numstat",
        "--format=COMMIT:%H|%an|%ae|%ai|%P%n%B%nEND_MSG",
        "--all",
    )

    current_author_email: str | None = None
    current_commit: dict | None = None
    files_in_commit: set[str] = set()
    in_body = False
    body_lines: list[str] = []
    commit_insertions = 0
    commit_deletions = 0
    commit_files = 0

    def _finalize_commit() -> None:
        """Save the current commit's enriched data and file group."""
        nonlocal commit_insertions, commit_deletions, commit_files
        if files_in_commit:
            commit_file_groups.append(files_in_commit)
        if current_commit is not None:
            body = "\n".join(body_lines)
            current_commit["co_authors"] = parse_co_authors(body)
            current_commit["insertions"] = commit_insertions
            current_commit["deletions"] = commit_deletions
            current_commit["files"] = commit_files

            # Merge-parent traversal for merge commits (supports octopus merges)
            parent_list = current_commit.get("_parents", [])
            merge_contributors: list[tuple[str, str]] = []
            if current_commit["is_merge"] and len(parent_list) >= 2:
                for parent in parent_list[1:]:
                    try:
                        merge_log = repo.git.log(
                            f"{parent_list[0]}..{parent}",
                            "--format=%an|%ae",
                        )
                        for ml in merge_log.strip().split("\n"):
                            if "|" in ml:
                                mn, me = ml.split("|", 1)
                                merge_contributors.append((mn.strip(), me.strip()))
                    except InvalidGitRepositoryError:
                        raise
                    except Exception:
                        logger.debug(
                            "Failed to traverse merge parent %s for %s",
                            parent,
                            current_commit.get("_parents"),
                            exc_info=True,
                        )
            current_commit["merge_contributors"] = merge_contributors
            # Remove internal _parents key
            current_commit.pop("_parents", None)
            enriched_commits.append(current_commit)

    for line in log_output.split("\n"):
        stripped = line.strip()

        if stripped == "END_MSG":
            in_body = False
            continue

        if stripped.startswith("COMMIT:"):
            # Finalize previous commit
            _finalize_commit()

            # Parse: hash|author_name|author_email|date_iso|parents
            parts = stripped[7:].split("|", 4)
            commit_hash = parts[0] if len(parts) > 0 else ""
            author_name = parts[1] if len(parts) > 1 else ""
            author_email = parts[2] if len(parts) > 2 else ""
            date_str = parts[3] if len(parts) > 3 else ""
            parents_str = parts[4] if len(parts) > 4 else ""

            parent_list = parents_str.strip().split() if parents_str.strip() else []

            current_author_email = author_email
            current_commit = {
                "author_name": author_name,
                "author_email": author_email,
                "date": date_str[:10],
                "is_merge": len(parent_list) > 1,
                "_parents": parent_list,
            }
            files_in_commit = set()
            body_lines = []
            in_body = True
            commit_insertions = 0
            commit_deletions = 0
            commit_files = 0
            continue

        # Numstat line: additions<tab>deletions<tab>path
        parts = line.split("\t")
        if len(parts) == 3 and not in_body:
            adds_str, dels_str, path = parts

            # Binary files show as "-" for adds/dels
            if adds_str == "-" or dels_str == "-":
                adds = 0
                dels = 0
            else:
                try:
                    adds = int(adds_str)
                    dels = int(dels_str)
                except ValueError:
                    continue

            commit_insertions += adds
            commit_deletions += dels
            commit_files += 1

            # Apply file filter if provided
            if file_filter is not None and path not in file_filter:
                continue

            if path not in file_stats:
                file_stats[path] = FileStats(path=path)

            stats = file_stats[path]
            stats.additions += adds
            stats.deletions += dels

            # Track author
            if current_author_email:
                stats.authors.add(current_author_email)
                stats.author_commits[current_author_email] += 1

            # Count commit only once per file per commit
            if path not in files_in_commit:
                stats.commits += 1
                files_in_commit.add(path)
        elif in_body:
            body_lines.append(line)

    # Don't forget the last commit
    _finalize_commit()

    return file_stats, commit_file_groups, enriched_commits


def _compute_cochange(
    commit_file_groups: list[set[str]],
    min_cochanges: int = 3,
    max_files_per_commit: int = 100,
) -> dict[tuple[str, str], int]:
    """Count how often pairs of files appear in the same commit.

    Commits touching more than *max_files_per_commit* files are skipped —
    bulk renames, dependency bumps, and initial commits are noise for
    coupling analysis and cause O(n²) pair explosion.

    Returns pairs with count >= min_cochanges.
    """
    pair_counts: dict[tuple[str, str], int] = defaultdict(int)
    skipped = 0

    for files in commit_file_groups:
        if len(files) > max_files_per_commit:
            skipped += 1
            continue
        sorted_files = sorted(files)
        for i, a in enumerate(sorted_files):
            for b in sorted_files[i + 1 :]:
                pair_counts[(a, b)] += 1

    if skipped:
        logger.info(
            "Skipped %d commits with >%d files for co-change",
            skipped,
            max_files_per_commit,
        )

    return {
        pair: count for pair, count in pair_counts.items() if count >= min_cochanges
    }


def _contribute_to_manager(
    manager: AnalysisManager,
    densities: list[FileDensity],
    file_stats: dict[str, FileStats],
    cochange_counts: dict[tuple[str, str], int],
) -> None:
    """Contribute git_density, author_count, and cochange weights to manager."""
    # Contribute normalized density scores
    for fd in densities:
        manager.add_weight(
            fd.path, "git_density", fd.density_score * WEIGHT_GIT_DENSITY
        )
        manager.add_metadata(fd.path, "additions", fd.additions)
        manager.add_metadata(fd.path, "deletions", fd.deletions)
        manager.add_metadata(fd.path, "commits", fd.commits)

    # Contribute author count (normalized) and primary_authors metadata
    max_authors = max((len(s.authors) for s in file_stats.values()), default=0)
    if max_authors > 0:
        for path, stats in file_stats.items():
            normalized_authors = len(stats.authors) / max_authors
            manager.add_weight(
                path, "author_count", normalized_authors * WEIGHT_AUTHOR_COUNT
            )
            manager.add_metadata(path, "authors", len(stats.authors))

    # Emit primary_authors: top 1-3 contributors by commit count per file
    for path, stats in file_stats.items():
        if not stats.author_commits:
            continue
        top = sorted(
            stats.author_commits, key=stats.author_commits.get, reverse=True  # type: ignore[arg-type]
        )[:3]
        manager.add_metadata(path, "primary_authors", top)

    # Contribute co-change (sum of partner co-change counts per file, normalized)
    file_cochange_sum: dict[str, int] = defaultdict(int)
    for (a, b), count in cochange_counts.items():
        file_cochange_sum[a] += count
        file_cochange_sum[b] += count

    max_cochange = max(file_cochange_sum.values(), default=0)
    if max_cochange > 0:
        for path, total in file_cochange_sum.items():
            normalized = total / max_cochange
            manager.add_weight(path, "cochange", normalized * WEIGHT_COCHANGE)


def get_high_density_files(
    repo_path: str,
    threshold: float = 0.5,
    weights: Optional[DensityWeights] = None,
) -> List[str]:
    """Get file paths with density score above threshold.

    Convenience function for filtering files by activity level.

    Args:
        repo_path: Path to the git repository.
        threshold: Minimum normalized density score (0.0-1.0).
        weights: Optional DensityWeights configuration.

    Returns:
        List of file paths with density >= threshold.
    """
    result = calculate_density(repo_path, weights=weights, normalize=True)
    return [f.path for f in result.files if f.density_score >= threshold]


# ---------------------------------------------------------------------------
# Signal definitions
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNALS = [
    SignalDefinition(
        name="git_density",
        description="Normalized change activity score from git history",
        level=SignalLevel.PER_FILE,
        category="git",
        manager_weight=1.0,
        requires_git=True,
        why_it_matters="Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.",
    ),
    SignalDefinition(
        name="author_count",
        description="Normalized count of distinct commit authors per file",
        level=SignalLevel.PER_FILE,
        category="git",
        manager_weight=1.5,
        requires_git=True,
        why_it_matters="Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.",
    ),
    SignalDefinition(
        name="cochange",
        description="Normalized co-change coupling frequency per file",
        level=SignalLevel.PER_FILE,
        category="git",
        manager_weight=0.8,
        requires_git=True,
        why_it_matters="Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.",
    ),
    SignalDefinition(
        name="bus_factor_files",
        description="Count of business-logic files (source, model, service, controller, repository, middleware, util, view) with only one author (bus-factor risk). Excludes vendor, generated, lock, build artifact, fixture, test, migration, config, and infra files.",
        level=SignalLevel.REPO,
        category="git",
        requires_git=True,
        value_range=(0.0, float("inf")),
        why_it_matters="Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.",
    ),
]
