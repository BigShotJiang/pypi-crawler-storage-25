"""Code metrics analyzer for heuristic filtering.

Computes static analysis metrics across source files to help
distinguish engineered code from assembled/glue code.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from pydantic import BaseModel, Field

from .glue_marker_analyzer import analyze_glue_markers
from .domain_token_analyzer import analyze_domain_tokens, analyze_domain_match
from .external_call_analyzer import analyze_external_calls
from .duplication_analyzer import analyze_duplication

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

WEIGHT_COMMENT_DENSITY_HOT: float = 1.0


class CodeMetricsResult(BaseModel):
    """Result of code metrics analysis."""

    # Easy metrics (computed here)
    control_flow_density: float = Field(default=0.0, ge=0.0)
    definition_density: float = Field(default=0.0, ge=0.0)
    comment_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    # Medium complexity metrics (from separate analyzers)
    gluemarker_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_token_density: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_match_density: float = Field(default=0.0, ge=0.0, le=1.0)
    domain_profile: str = Field(default="")
    external_call_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    # Hard metric
    duplication_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    # Metadata
    total_lines: int = 0
    code_lines: int = 0
    files_analyzed: int = 0


# ---------------------------------------------------------------------------
# Control flow patterns by language
# ---------------------------------------------------------------------------

CONTROL_FLOW_PATTERNS = re.compile(
    r"\b("
    r"if|else|elif|switch|case|default|"  # conditionals
    r"for|while|do|loop|foreach|"  # loops
    r"try|catch|except|finally|throw|raise|"  # exceptions
    r"break|continue|return|yield|"  # flow control
    r"goto|"  # jumps
    r"match|when"  # pattern matching
    r")\b",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Definition patterns
# ---------------------------------------------------------------------------

DEFINITION_PATTERNS = re.compile(
    r"\b("
    r"def\s+\w+|"  # Python function
    r"class\s+\w+|"  # Python/JS/Java class
    r"function\s+\w+|"  # JS function
    r"const\s+\w+\s*=\s*(?:async\s*)?\(|"  # JS arrow function
    r"let\s+\w+\s*=\s*(?:async\s*)?\(|"  # JS arrow function
    r"var\s+\w+\s*=\s*function|"  # JS function expression
    r"func\s+\w+|"  # Go function
    r"fn\s+\w+|"  # Rust function
    r"pub\s+fn\s+\w+|"  # Rust public function
    r"impl\s+\w+|"  # Rust impl block
    r"trait\s+\w+|"  # Rust trait
    r"interface\s+\w+|"  # TS/Java interface
    r"type\s+\w+\s*=|"  # TS type alias
    r"enum\s+\w+|"  # enum
    r"struct\s+\w+|"  # struct
    r"module\s+\w+|"  # module
    r"namespace\s+\w+"  # namespace
    r")"
)

# ---------------------------------------------------------------------------
# Comment patterns
# ---------------------------------------------------------------------------

SINGLE_LINE_COMMENT = re.compile(r"^\s*(//|#|--)")
MULTI_LINE_COMMENT_START = re.compile(r"/\*|\"\"\"|'''|<!--")
MULTI_LINE_COMMENT_END = re.compile(r'\*/|"""|\'\'\'|-->')


def _count_comment_lines(content: str) -> tuple[int, int]:
    """Count comment lines and total non-empty lines.

    Returns (comment_lines, total_lines).
    """
    lines = content.split("\n")
    comment_lines = 0
    total_lines = 0
    in_multiline = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        total_lines += 1

        if in_multiline:
            comment_lines += 1
            if MULTI_LINE_COMMENT_END.search(stripped):
                in_multiline = False
            continue

        if SINGLE_LINE_COMMENT.match(stripped):
            comment_lines += 1
            continue

        m = MULTI_LINE_COMMENT_START.search(stripped)
        if m:
            comment_lines += 1
            # Check if it closes on same line (search after the opener)
            if not MULTI_LINE_COMMENT_END.search(stripped[m.end() :]):
                in_multiline = True

    return comment_lines, total_lines


def _analyze_file_metrics(content: str) -> dict:
    """Analyze a single file's metrics."""
    control_flow_count = len(CONTROL_FLOW_PATTERNS.findall(content))
    definition_count = len(DEFINITION_PATTERNS.findall(content))
    comment_lines, total_lines = _count_comment_lines(content)

    return {
        "control_flow_count": control_flow_count,
        "definition_count": definition_count,
        "comment_lines": comment_lines,
        "total_lines": total_lines,
        "code_lines": total_lines - comment_lines,
    }


def analyze_code_metrics(
    repo_path: str,
    file_paths: Optional[list[str]] = None,
    manager: Optional[AnalysisManager] = None,
) -> CodeMetricsResult:
    """Analyze code metrics for a repository or specific files.

    Args:
        repo_path: Path to the repository root.
        file_paths: Optional list of specific file paths to analyze.
                   If None, analyzes all source files.
        manager: Optional AnalysisManager to receive per-file metrics
                 and weight contributions.

    Returns:
        CodeMetricsResult with all computed metrics.
    """
    repo = Path(repo_path)

    # Collect files to analyze
    if file_paths:
        files = [repo / p for p in file_paths]
    else:
        # Use common source extensions
        source_extensions = {
            ".py",
            ".js",
            ".ts",
            ".tsx",
            ".jsx",
            ".java",
            ".kt",
            ".go",
            ".rs",
            ".c",
            ".cpp",
            ".h",
            ".hpp",
            ".cs",
            ".rb",
            ".php",
            ".swift",
            ".scala",
        }
        files = [
            f
            for f in repo.rglob("*")
            if f.suffix in source_extensions
            and not any(
                p in f.parts
                for p in {
                    "node_modules",
                    "vendor",
                    "venv",
                    ".venv",
                    "__pycache__",
                    ".git",
                    "dist",
                    "build",
                    "target",
                }
            )
        ]

    # Aggregate metrics
    total_control_flow = 0
    total_definitions = 0
    total_comment_lines = 0
    total_lines = 0
    total_code_lines = 0
    files_analyzed = 0
    all_contents: list[str] = []
    per_file_comment_ratios: dict[str, float] = {}

    for file_path in files:
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError):
            continue

        # Skip binary files
        if "\x00" in content:
            continue

        metrics = _analyze_file_metrics(content)
        total_control_flow += metrics["control_flow_count"]
        total_definitions += metrics["definition_count"]
        total_comment_lines += metrics["comment_lines"]
        total_lines += metrics["total_lines"]
        total_code_lines += metrics["code_lines"]
        files_analyzed += 1
        all_contents.append(content)

        # Track per-file comment ratio for manager
        if metrics["total_lines"] > 0:
            rel_path = str(file_path.relative_to(repo))
            file_ratio = metrics["comment_lines"] / metrics["total_lines"]
            per_file_comment_ratios[rel_path] = file_ratio

    # Calculate densities (per 100 lines)
    if total_code_lines > 0:
        control_flow_density = (total_control_flow / total_code_lines) * 100
        definition_density = (total_definitions / total_code_lines) * 100
        comment_ratio = total_comment_lines / total_lines if total_lines > 0 else 0.0
    else:
        control_flow_density = 0.0
        definition_density = 0.0
        comment_ratio = 0.0

    # Get metrics from specialized analyzers
    combined_content = "\n".join(all_contents)

    gluemarker_ratio = analyze_glue_markers(combined_content)
    domain_token_density = analyze_domain_tokens(combined_content)
    domain_match_density, domain_profile = analyze_domain_match(combined_content)
    external_call_ratio = analyze_external_calls(combined_content)
    duplication_ratio = analyze_duplication(all_contents)

    # Contribute per-file comment data to manager
    if manager is not None:
        for path, ratio in per_file_comment_ratios.items():
            manager.add_metadata(path, "file_comment_ratio", ratio)
            # Interaction signal: high comments + high churn = documented hot code
            git_density_weight = manager.get_weight(path, "git_density")
            if git_density_weight > 0:
                boost = ratio * git_density_weight * WEIGHT_COMMENT_DENSITY_HOT
                manager.add_weight(path, "comment_density_hot", boost)

    return CodeMetricsResult(
        control_flow_density=control_flow_density,
        definition_density=definition_density,
        comment_ratio=comment_ratio,
        gluemarker_ratio=gluemarker_ratio,
        domain_token_density=domain_token_density,
        domain_match_density=domain_match_density,
        domain_profile=domain_profile,
        external_call_ratio=external_call_ratio,
        duplication_ratio=duplication_ratio,
        total_lines=total_lines,
        code_lines=total_code_lines,
        files_analyzed=files_analyzed,
    )


# ---------------------------------------------------------------------------
# Signal definitions
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNALS = [
    SignalDefinition(
        name="control_flow_density",
        description="Control-flow statements per 100 code lines",
        level=SignalLevel.REPO,
        category="heuristic",
        composites=[
            CompositeContribution(
                composite="engineering_score",
                weight=0.15,
                normalize_divisor=20.0,
            ),
        ],
        why_it_matters="Identifies where business rules concentrate. High control flow density in a few files means proprietary decision logic is packed into complex code, driving up rebuild cost. Low density across the repo may indicate the product is mostly glue with little original logic.",
    ),
    SignalDefinition(
        name="definition_density",
        description="Definitions (functions, classes) per 100 code lines",
        level=SignalLevel.REPO,
        category="heuristic",
        composites=[
            CompositeContribution(
                composite="engineering_score",
                weight=0.15,
                normalize_divisor=15.0,
            ),
        ],
        why_it_matters="Indicates code modularity and reuse patterns. Low definition density suggests monolithic functions doing too much, increasing maintenance cost.",
    ),
    SignalDefinition(
        name="comment_ratio",
        description="Repo-wide ratio of comment lines to total lines",
        level=SignalLevel.REPO,
        category="heuristic",
        composites=[
            CompositeContribution(
                composite="engineering_score",
                weight=0.15,
                normalize_divisor=0.15,
            ),
        ],
        why_it_matters="Documentation culture is a leading indicator of post-close maintenance risk. Near-zero comments + high change frequency = institutional knowledge trapped in developers' heads. Directly affects knowledge transfer timelines and key-person retention priorities.",
    ),
    SignalDefinition(
        name="comment_density_hot",
        description="Per-file interaction signal: comment ratio * git density",
        level=SignalLevel.PER_FILE,
        category="heuristic",
        manager_weight=1.0,
        why_it_matters="Documentation culture is a leading indicator of post-close maintenance risk. Near-zero comments + high change frequency = institutional knowledge trapped in developers' heads. Directly affects knowledge transfer timelines and key-person retention priorities.",
    ),
]
