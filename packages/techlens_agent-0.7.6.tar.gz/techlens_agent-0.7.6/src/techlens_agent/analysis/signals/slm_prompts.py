"""Prompt templates for the SLM after-filter."""

SYSTEM_PROMPT = """\
You are a software due-diligence analyst. Your task is to evaluate source code \
and determine whether a software project is "engineered" (purpose-built with \
intentional architecture) or "assembled" (stitched together from boilerplate, \
generated code, or copy-paste). Respond ONLY with valid JSON — no markdown, \
no explanation outside the JSON object."""

CHUNK_ANALYSIS_PROMPT = """\
Analyze the following source code files and assess the software along these \
five dimensions:

1. **Architecture & Structure** — Is there evidence of intentional design \
   (clear module boundaries, separation of concerns) or is it a flat dump of files?
2. **Code Originality** — Does the code appear hand-written and project-specific, \
   or is it mostly boilerplate / scaffolding / generated code?
3. **Error Handling & Edge Cases** — Are errors handled thoughtfully, or are \
   they ignored / handled with generic catch-alls?
4. **Testing & Quality Signals** — Is there evidence of testing, linting, CI, \
   or type annotations that suggest engineering discipline?
5. **Dependency Hygiene** — Are dependencies pinned, minimal, and intentional, \
   or is the project pulling in a kitchen-sink of transitive dependencies?

Respond with ONLY this JSON (no other text):
{{
  "assessment": "<engineered | assembled | mixed>",
  "assessment_score": <float 0.0 to 1.0>,
  "notes": ["<observation 1>", "<observation 2>", "..."]
}}

Scoring rubric:
- 0.0–0.3  → assembled (boilerplate-heavy, no architecture, copy-paste)
- 0.3–0.5  → leaning assembled
- 0.5–0.7  → mixed (some engineering, some assembly)
- 0.7–0.9  → leaning engineered
- 0.9–1.0  → engineered (strong architecture, original code, thorough quality)

Rules:
- Each note must reference specific files or patterns you observed.
- Do not speculate about code you cannot see.
- Keep notes concise (one sentence each, max 8 notes).

Source code:
{context}"""

MERGE_PROMPT = """\
You previously analyzed a large repository in {chunk_count} separate chunks. \
Below are your partial assessments from each chunk. Produce a single consolidated \
verdict for the entire repository.

Weigh each chunk's score proportionally to the number of files it covered. \
If chunk assessments conflict, explain the conflict in your notes and pick the \
assessment that best represents the overall codebase.

Chunk assessments:
{chunk_assessments}

Respond with ONLY this JSON (no other text):
{{
  "assessment": "<engineered | assembled | mixed>",
  "assessment_score": <float 0.0 to 1.0>,
  "notes": ["<consolidated observation 1>", "<consolidated observation 2>", "..."]
}}"""
