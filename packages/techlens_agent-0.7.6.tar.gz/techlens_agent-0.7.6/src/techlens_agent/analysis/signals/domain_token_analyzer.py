"""Domain token analyzer - measures domain-specific vocabulary in code.

Two complementary signals:
- ``domain_token_density`` — ratio of non-generic words (standalone signal, no composite)
- ``domain_match_density`` — ratio of words that positively match a domain dictionary
  (feeds moat_score at 0.20)

Supports 13 domain dictionaries (adtech, cybersecurity, ecommerce, edtech,
enterprise, fintech, gaming, healthtech, iot, legaltech, logistics, media,
proptech). If no domain is configured, all are evaluated and the best match wins.
"""

from __future__ import annotations

import re
from collections import Counter

from .data.generic_tokens import GENERIC_TOKENS
from .data.stemmer import stem
from .data.domain_adtech import DOMAIN_STEMS as ADTECH_STEMS
from .data.domain_cybersecurity import DOMAIN_STEMS as CYBERSECURITY_STEMS
from .data.domain_ecommerce import DOMAIN_STEMS as ECOMMERCE_STEMS
from .data.domain_edtech import DOMAIN_STEMS as EDTECH_STEMS
from .data.domain_enterprise import DOMAIN_STEMS as ENTERPRISE_STEMS
from .data.domain_fintech import DOMAIN_STEMS as FINTECH_STEMS
from .data.domain_gaming import DOMAIN_STEMS as GAMING_STEMS
from .data.domain_healthtech import DOMAIN_STEMS as HEALTHTECH_STEMS
from .data.domain_iot import DOMAIN_STEMS as IOT_STEMS
from .data.domain_legaltech import DOMAIN_STEMS as LEGALTECH_STEMS
from .data.domain_logistics import DOMAIN_STEMS as LOGISTICS_STEMS
from .data.domain_media import DOMAIN_STEMS as MEDIA_STEMS
from .data.domain_proptech import DOMAIN_STEMS as PROPTECH_STEMS

# Pattern to extract identifiers
IDENTIFIER_PATTERN = re.compile(r"\b([a-zA-Z_][a-zA-Z0-9_]*)\b")

# Pattern to split camelCase and snake_case
WORD_SPLIT_PATTERN = re.compile(r"[_\-]|(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")

_DOMAIN_DICTS: dict[str, frozenset[str]] = {
    "adtech": ADTECH_STEMS,
    "cybersecurity": CYBERSECURITY_STEMS,
    "ecommerce": ECOMMERCE_STEMS,
    "edtech": EDTECH_STEMS,
    "enterprise": ENTERPRISE_STEMS,
    "fintech": FINTECH_STEMS,
    "gaming": GAMING_STEMS,
    "healthtech": HEALTHTECH_STEMS,
    "iot": IOT_STEMS,
    "legaltech": LEGALTECH_STEMS,
    "logistics": LOGISTICS_STEMS,
    "media": MEDIA_STEMS,
    "proptech": PROPTECH_STEMS,
}

_PREFIX_MIN_LEN = 7


def _extract_words(identifier: str) -> list[str]:
    """Extract individual words from an identifier.

    Handles camelCase, PascalCase, and snake_case.
    """
    parts = WORD_SPLIT_PATTERN.split(identifier)
    return [p.lower() for p in parts if p and len(p) > 1]


def _prefix_match(word_stem: str, dictionary: frozenset[str]) -> bool:
    """Check if *word_stem* matches any entry in *dictionary* via prefix."""
    if word_stem in dictionary:
        return True
    if len(word_stem) >= _PREFIX_MIN_LEN:
        return any(
            d.startswith(word_stem[:_PREFIX_MIN_LEN])
            or word_stem.startswith(d[:_PREFIX_MIN_LEN])
            for d in dictionary
        )
    return False


def _count_domain_matches(word_counts: Counter[str], dictionary: frozenset[str]) -> int:
    """Count total word occurrences that match *dictionary* (stemmed + prefix)."""
    total = 0
    for word, count in word_counts.items():
        stemmed = stem(word)
        if _prefix_match(stemmed, dictionary):
            total += count
    return total


def analyze_domain_tokens(content: str) -> float:
    """Analyze content for domain-specific vocabulary (generic density).

    Returns:
        Domain token density (0.0-1.0).
        Higher values indicate more domain-specific (non-generic) vocabulary.
    """
    if not content.strip():
        return 0.0

    identifiers = IDENTIFIER_PATTERN.findall(content)
    if not identifiers:
        return 0.0

    word_counts: Counter[str] = Counter()
    for identifier in identifiers:
        word_counts.update(_extract_words(identifier))

    if not word_counts:
        return 0.0

    total_words = sum(word_counts.values())
    generic_word_count = sum(
        count for word, count in word_counts.items() if word in GENERIC_TOKENS
    )

    domain_word_count = total_words - generic_word_count

    if total_words == 0:
        return 0.0

    domain_ratio = domain_word_count / total_words
    normalized = (domain_ratio - 0.2) / 0.6
    return max(0.0, min(1.0, normalized))


def analyze_domain_match(content: str, domain: str | None = None) -> tuple[float, str]:
    """Analyze content for positive matches against domain dictionaries.

    Args:
        content: Combined source code content.
        domain: Optional domain hint ("fintech", "healthtech", "enterprise").
            If None, all dictionaries are tried and the best match wins.

    Returns:
        (domain_match_density, domain_profile) tuple.
        domain_match_density is 0.0-1.0, domain_profile is the winning dictionary name.
    """
    if not content.strip():
        return 0.0, ""

    identifiers = IDENTIFIER_PATTERN.findall(content)
    if not identifiers:
        return 0.0, ""

    word_counts: Counter[str] = Counter()
    for identifier in identifiers:
        word_counts.update(_extract_words(identifier))

    if not word_counts:
        return 0.0, ""

    total_words = sum(word_counts.values())
    if total_words == 0:
        return 0.0, ""

    if domain and domain in _DOMAIN_DICTS:
        match_count = _count_domain_matches(word_counts, _DOMAIN_DICTS[domain])
        density = match_count / total_words
        return max(0.0, min(1.0, density)), domain

    # Try all dictionaries, pick the best
    best_density = 0.0
    best_domain = ""
    for name, stems in _DOMAIN_DICTS.items():
        match_count = _count_domain_matches(word_counts, stems)
        density = match_count / total_words
        if density > best_density:
            best_density = density
            best_domain = name

    return max(0.0, min(1.0, best_density)), best_domain


# ---------------------------------------------------------------------------
# Signal definitions
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNALS = [
    SignalDefinition(
        name="domain_token_density",
        description="Ratio of domain-specific vocabulary to generic tokens",
        level=SignalLevel.REPO,
        category="heuristic",
        why_it_matters="Unlocks the most strategically important signal. Function names like 'calculate_actuarial_reserve' or 'apply_regulatory_haircut' reveal the depth of proprietary domain knowledge that can't be replicated by hiring generic developers.",
    ),
    SignalDefinition(
        name="domain_match_density",
        description="Ratio of domain-specific vocabulary matches (stemmed + prefix)",
        level=SignalLevel.REPO,
        category="heuristic",
        composites=[
            CompositeContribution(composite="moat_score", weight=0.20),
        ],
        why_it_matters="Measures positive matches against curated domain dictionaries (fintech, healthtech, enterprise). Unlike generic density, this confirms the codebase actually uses specialized vocabulary — a strong indicator of proprietary domain logic.",
    ),
]
