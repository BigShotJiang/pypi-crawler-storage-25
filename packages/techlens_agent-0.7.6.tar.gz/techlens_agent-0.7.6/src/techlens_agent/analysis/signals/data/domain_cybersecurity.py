"""Cybersecurity domain vocabulary.

Terms specific to security tools, threat detection, and vulnerability management.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Threats & vulnerabilities
    "vulnerability",
    "exploit",
    "cve",
    "cvss",
    "zeroday",
    "malware",
    "ransomware",
    "trojan",
    "phishing",
    "spearphishing",
    "botnet",
    "rootkit",
    "backdoor",
    # Detection & response
    "detection",
    "triage",
    "siem",
    "soar",
    "edr",
    "xdr",
    "ioc",
    "signature",
    "heuristic",
    "anomaly",
    "quarantine",
    # Network security
    "firewall",
    "ids",
    "ips",
    "intrusion",
    "packet",
    "pcap",
    "deeppacket",
    "proxy",
    "waf",
    "ddos",
    "mitigation",
    "honeypot",
    "sandbox",
    # Identity & access
    "bruteforce",
    # Cryptography
    "encryption",
    "decryption",
    "cipher",
    "hmac",
    "pki",
    "keystore",
    "entropy",
    # Compliance & audit
    "pentest",
    "scanner",
    "remediation",
    "hardening",
    "compliance",
    "nist",
    "iso27001",
    "soc2",
    "threatmodel",
    "attacksurface",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
