"""Regex patterns for detecting glue/boilerplate code.

Used by glue_marker_analyzer to identify imports, decorators,
configuration, and boilerplate patterns across multiple languages.
"""

import re

# ---------------------------------------------------------------------------
# Import patterns
# ---------------------------------------------------------------------------

IMPORT_PATTERNS = re.compile(
    r"^(?:"
    r"import\s+[\w.]+|"  # Python/JS import
    r"from\s+[\w.]+\s+import|"  # Python from import
    r'require\s*\([\'"]|'  # Node.js require
    r"using\s+[\w.]+;|"  # C# using
    r'#include\s*[<"]|'  # C/C++ include
    r"use\s+[\w:]+;|"  # Rust use
    r"package\s+\w+|"  # Go/Java package
    r"@import\s+|"  # SCSS/Objective-C import
    r"const\s+\{\s*\w+.*\}\s*=\s*require\s*\("  # JS destructured require
    r")",
    re.MULTILINE,
)

# ---------------------------------------------------------------------------
# Decorator patterns (framework glue)
# ---------------------------------------------------------------------------

DECORATOR_PATTERNS = re.compile(
    r"@(?:"
    r"app\.|"  # Flask app decorators
    r"route|"  # Web framework routes
    r"api\.|"  # API decorators
    r"Component|"  # React/Angular
    r"Injectable|"  # Angular DI
    r"Entity|"  # ORM entities
    r"Table|"  # ORM tables
    r"Column|"  # ORM columns
    r"Controller|"  # MVC controllers
    r"Service|"  # Service decorators
    r"Module|"  # Module decorators
    r"Inject|"  # DI decorators
    r"Bean|"  # Spring beans
    r"Autowired|"  # Spring autowiring
    r"RequestMapping|"  # Spring MVC
    r"GetMapping|PostMapping|"  # Spring REST
    r"pytest\.|"  # Pytest markers
    r"fixture|"  # Pytest fixtures
    r"mock\.|"  # Mock decorators
    r"property|"  # Python property
    r"staticmethod|"  # Python static
    r"classmethod|"  # Python classmethod
    r"dataclass|"  # Python dataclass
    r"validator|"  # Pydantic validators
    r"field_validator|"  # Pydantic v2
    r"computed_field"  # Pydantic computed
    r")\b"
)

# ---------------------------------------------------------------------------
# Configuration/boilerplate patterns
# ---------------------------------------------------------------------------

CONFIG_PATTERNS = re.compile(
    r"(?:"
    r'if\s+__name__\s*==\s*[\'"]__main__|'  # Python main guard
    r"module\.exports\s*=|"  # CommonJS export
    r"export\s+default|"  # ES6 default export
    r"export\s+\{|"  # ES6 named exports
    r"exports\.\w+\s*=|"  # CommonJS named exports
    r"\.env\b|"  # Environment files
    r"process\.env\.|"  # Node env access
    r"os\.environ|"  # Python env access
    r"getenv\(|"  # C getenv
    r"ENV\[|"  # Ruby ENV
    r"config\s*=\s*\{|"  # Config object
    r"settings\s*=\s*\{|"  # Settings object
    r"options\s*=\s*\{|"  # Options object
    r"INSTALLED_APPS|"  # Django settings
    r"MIDDLEWARE|"  # Django middleware
    r"DATABASES\s*=|"  # Django databases
    r"SECRET_KEY|"  # Django secret
    r"DEBUG\s*=|"  # Django debug
    r"BASE_DIR|"  # Django base dir
    r"ROOT_URLCONF|"  # Django urls
    r"TEMPLATES\s*=|"  # Django templates
    r"\"scripts\"\s*:|"  # package.json scripts
    r"\"dependencies\"\s*:|"  # package.json deps
    r"\"devDependencies\"\s*:"  # package.json devDeps
    r")",
    re.MULTILINE,
)

# ---------------------------------------------------------------------------
# Boilerplate statement patterns
# ---------------------------------------------------------------------------

BOILERPLATE_PATTERNS = re.compile(
    r"(?:"
    r"#!/usr/bin/env|"  # Shebang
    r"# -\*- coding:|"  # Python encoding
    r"\"use strict\"|"  # JS strict mode
    r"\'use strict\'|"  # JS strict mode
    r"pragma solidity|"  # Solidity pragma
    r"#pragma once|"  # C++ pragma
    r"#ifndef\s+\w+_H|"  # C/C++ header guard
    r"#define\s+\w+_H|"  # C/C++ header guard
    r"package\s+main|"  # Go main package
    r"func\s+main\(\)|"  # Go main function
    r"public\s+static\s+void\s+main|"  # Java main
    r"int\s+main\s*\(|"  # C main
    r"if\s+__name__\s*==\s*['\"]__main__['\"]|"  # Python main
    r"app\.run\(|"  # Flask run
    r"uvicorn\.run\(|"  # Uvicorn run
    r"serve\(|"  # Generic serve
    r"createServer\(|"  # Node HTTP server
    r"listen\(\d+|"  # Server listen
    r"\.listen\(process\.env\.PORT"  # Express listen
    r")"
)
