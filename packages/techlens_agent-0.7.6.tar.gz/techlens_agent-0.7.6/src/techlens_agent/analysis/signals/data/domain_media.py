"""Media & content platform domain vocabulary.

Terms specific to publishing, streaming, and content management platforms.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Content management
    "article",
    "headline",
    "byline",
    "editorial",
    "slug",
    "permalink",
    "taxonomy",
    "cms",
    "wysiwyg",
    # Streaming & video
    "livestream",
    "playlist",
    "episode",
    "bitrate",
    "transcode",
    "hls",
    "dash",
    "drm",
    "watermark",
    "thumbnail",
    "caption",
    "subtitle",
    # Audio & podcast
    "podcast",
    "rss",
    "syndication",
    "waveform",
    "equalizer",
    # Subscription & monetization
    "paywall",
    "freemium",
    "monetization",
    "adsupported",
    "sponsorship",
    # Social & engagement
    "repost",
    "hashtag",
    "trending",
    "viral",
    "moderation",
    # Publishing workflow
    "newsroom",
    "correspondent",
    "stringer",
    "embargo",
    "retraction",
    "factcheck",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
