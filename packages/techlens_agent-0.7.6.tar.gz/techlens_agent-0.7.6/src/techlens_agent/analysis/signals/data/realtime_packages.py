"""Curated realtime/event-driven package names.

Used by realtime_pattern_analyzer to detect realtime architecture
by matching manifest dependencies against this set.
"""

REALTIME_PACKAGES: set[str] = {
    # Python — async & websockets
    "aiohttp",
    "websockets",
    "uvloop",
    # Python — task queues & message brokers
    "celery",
    "dramatiq",
    "kombu",
    "pika",
    "huey",
    "rq",
    # Python — Kafka
    "aiokafka",
    "confluent-kafka",
    "kafka-python",
    # Python — Redis (pub/sub, streams)
    "redis",
    "aioredis",
    # JS/Node — websockets
    "socket.io",
    "ws",
    "sockjs",
    "primus",
    # JS/Node — task queues & message brokers
    "bull",
    "bullmq",
    "bee-queue",
    "amqplib",
    "mqtt",
    # JS/Node — Kafka
    "kafkajs",
    # JS/Node — reactive
    "rxjs",
    # JS/Node — realtime frameworks
    "feathers",
    "meteor",
    # Go
    "gorilla/websocket",
    "nhooyr.io/websocket",
    "nats-io/nats.go",
    "segmentio/kafka-go",
    "confluentinc/confluent-kafka-go",
    # Java/Spring
    "spring-websocket",
    "spring-kafka",
    "spring-integration",
    "reactor-core",
    "reactor-netty",
    "vertx-core",
    # gRPC (cross-language)
    "grpc",
    "grpcio",
    "@grpc/grpc-js",
    "@grpc/proto-loader",
    # Server-Sent Events
    "eventsource",
    "sse-starlette",
}
