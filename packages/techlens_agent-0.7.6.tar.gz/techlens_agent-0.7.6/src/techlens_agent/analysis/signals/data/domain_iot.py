"""IoT & embedded systems domain vocabulary.

Terms specific to connected devices, sensor networks, and embedded firmware.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Devices & hardware
    "actuator",
    "microcontroller",
    "mcu",
    "gpio",
    "adc",
    "dac",
    "pwm",
    "spi",
    "i2c",
    "uart",
    "peripheral",
    "transducer",
    # Firmware & embedded
    "firmware",
    "bootloader",
    "flashmemory",
    "eeprom",
    "interrupt",
    "watchdog",
    "rtos",
    "baremetal",
    "crosscompile",
    "ota",
    "fota",
    # Connectivity
    "mqtt",
    "coap",
    "zigbee",
    "zwave",
    "lora",
    "lorawan",
    "bluetooth",
    "ble",
    "nfc",
    "rfid",
    "wifi",
    "cellular",
    # Telemetry & data
    "telemetry",
    "timeseries",
    "datapoint",
    "sampling",
    "calibration",
    "threshold",
    "heartbeat",
    "keepalive",
    "edgecomputing",
    "fog",
    # Device management
    "provisioning",
    "commissioning",
    "decommission",
    "twinning",
    "digitaltwin",
    "deviceregistry",
    # Industrial IoT
    "scada",
    "plc",
    "modbus",
    "opcua",
    "historian",
    "setpoint",
    "controlloop",
    "pid",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
