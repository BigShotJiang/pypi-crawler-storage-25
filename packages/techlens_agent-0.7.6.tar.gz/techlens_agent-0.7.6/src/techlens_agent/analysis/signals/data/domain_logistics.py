"""Logistics & supply chain domain vocabulary.

Terms specific to shipping, warehousing, fleet management, and supply chain.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Shipping & delivery
    "shipment",
    "consignment",
    "freight",
    "cargo",
    "parcel",
    "carrier",
    "courier",
    "dispatch",
    "delivery",
    "lastmile",
    "waybill",
    "billoflading",
    "manifest",
    "pod",
    # Warehousing
    "warehouse",
    "fulfillment",
    "inventory",
    "stocktake",
    "picking",
    "packing",
    "palletizing",
    "putaway",
    "binlocation",
    "crossdock",
    "coldchain",
    "wms",
    # Fleet & routing
    "fleet",
    "vehicle",
    "route",
    "routing",
    "geofence",
    "telematics",
    "odometer",
    "eta",
    "waypoint",
    "depot",
    "hub",
    "sortation",
    # Supply chain
    "supplychain",
    "procurement",
    "sourcing",
    "vendor",
    "supplier",
    "leadtime",
    "reorder",
    "safetystock",
    "demandplanning",
    "forecasting",
    "backlog",
    # Customs & trade
    "customs",
    "tariff",
    "duties",
    "incoterms",
    "harmonized",
    "clearance",
    "bonded",
    "freetradezone",
    # Returns & reverse logistics
    "rma",
    "reverselogistics",
    "refurbishment",
    "disposition",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
