"""Curated governance/workflow package names.

Used by governance_workflow_analyzer to detect governance patterns
by matching manifest dependencies against this set.
"""

GOVERNANCE_PACKAGES: set[str] = {
    # Workflow engines
    "temporalio",
    "temporal-sdk",
    "camunda-external-task-client-js",
    "zeebe-node",
    "airflow",
    "apache-airflow",
    "prefect",
    "dagster",
    "luigi",
    "argo-workflows",
    "n8n",
    "node-red",
    # Auth / RBAC / IAM
    "keycloak-admin-client",
    "keycloak-js",
    "auth0",
    "@auth0/auth0-react",
    "casbin",
    "pycasbin",
    "passport",
    "passport-jwt",
    "passport-local",
    "spring-security",
    "django-guardian",
    "django-rules",
    "django-role-permissions",
    "flask-principal",
    "flask-security",
    "casl",
    "@casl/ability",
    "oso",
}
