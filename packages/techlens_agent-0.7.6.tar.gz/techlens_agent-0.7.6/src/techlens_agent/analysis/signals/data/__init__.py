"""Static data used by analysis modules.

Separates large data sets (token lists, library catalogs, regex patterns)
from the logic that consumes them.
"""
