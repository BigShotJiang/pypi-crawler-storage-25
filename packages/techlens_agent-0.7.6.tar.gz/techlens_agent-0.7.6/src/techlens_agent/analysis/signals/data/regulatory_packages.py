"""Curated compliance/regulatory package names.

Used by regulatory_token_analyzer to detect regulatory patterns
by matching manifest dependencies against this set.
"""

REGULATORY_PACKAGES: set[str] = {
    # FHIR / healthcare
    "fhirclient",
    "fhir.resources",
    "hapi-fhir",
    "fhir-kit-client",
    "node-fhir-server-core",
    # Cryptography
    "cryptography",
    "pycryptodome",
    "pycryptodomex",
    "bcrypt",
    "argon2-cffi",
    "python-jose",
    "jose",
    "jsonwebtoken",
    "node-forge",
    "tweetnacl",
    "libsodium",
    "sodium-native",
    # KMS / vault / secrets management
    "aws-encryption-sdk",
    "google-cloud-kms",
    "azure-keyvault",
    "azure-keyvault-secrets",
    "hvac",
    "python-dotenv-vault",
    "aws-secrets-manager",
    "@aws-sdk/client-kms",
    "@aws-sdk/client-secrets-manager",
    "@google-cloud/kms",
    # Consent / privacy
    "django-consent",
    "cookieconsent",
    "react-cookie-consent",
    # Audit / compliance frameworks
    "django-auditlog",
    "django-simple-history",
    "auditjs",
    "audit-log",
    # Data masking / anonymization
    "faker",
    "presidio-analyzer",
    "presidio-anonymizer",
    "scrubadub",
}
