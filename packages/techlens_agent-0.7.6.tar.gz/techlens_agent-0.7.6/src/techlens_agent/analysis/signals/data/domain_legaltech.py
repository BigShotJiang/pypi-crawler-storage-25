"""Legal technology domain vocabulary.

Terms specific to legal software, contract management, and compliance platforms.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Contracts
    "contract",
    "clause",
    "amendment",
    "addendum",
    "recital",
    "indemnification",
    "termination",
    "noncompete",
    "nondisclosure",
    "nda",
    "sla",
    "redline",
    "counterpart",
    "execution",
    # Litigation
    "litigation",
    "plaintiff",
    "defendant",
    "deposition",
    "discovery",
    "ediscovery",
    "interrogatory",
    "subpoena",
    "verdict",
    "settlement",
    "arbitration",
    "mediation",
    "jurisdiction",
    "statute",
    "precedent",
    # Court & filings
    "filing",
    "docket",
    "brief",
    "motion",
    "pleading",
    "affidavit",
    "stipulation",
    "injunction",
    "summons",
    "exhibit",
    # Compliance & regulation
    "compliance",
    "regulatory",
    "ordinance",
    "regulation",
    "audit",
    "sanction",
    "enforcement",
    "whistleblower",
    # IP & corporate
    "patent",
    "trademark",
    "copyright",
    "intellectualproperty",
    "licensing",
    "royalty",
    "incorporation",
    "bylaws",
    "fiduciary",
    "shareholder",
    "boardresolution",
    # Practice management
    "billable",
    "retainer",
    "timesheet",
    "matter",
    "casefile",
    "intake",
    "conflict",
    "privileged",
    "workproduct",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
