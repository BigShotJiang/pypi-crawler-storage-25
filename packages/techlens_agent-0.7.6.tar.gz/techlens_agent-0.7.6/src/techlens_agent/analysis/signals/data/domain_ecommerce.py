"""E-commerce domain vocabulary.

Terms specific to online retail, marketplaces, and digital commerce.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Product & catalog
    "sku",
    "catalog",
    "inventory",
    "stockkeeping",
    "variant",
    "assortment",
    "merchandise",
    "clearance",
    "backorder",
    "restock",
    "upc",
    "barcode",
    "planogram",
    # Cart & checkout
    "cart",
    "checkout",
    "subtotal",
    "coupon",
    "voucher",
    "promo",
    "discount",
    "upsell",
    "crosssell",
    "abandonedcart",
    "wishlist",
    # Orders & fulfillment
    "fulfillment",
    "shipment",
    "dispatch",
    "warehouse",
    "dropship",
    "backfill",
    "refund",
    "chargeback",
    "rma",
    # Storefront & marketplace
    "storefront",
    "merchant",
    "seller",
    "buyer",
    "marketplace",
    "listing",
    "buybox",
    "featured",
    "bestseller",
    # Pricing
    "msrp",
    "markup",
    "markdown",
    "pricelist",
    "tieredpricing",
    "bulkdiscount",
    "dynamicpricing",
    # Customer
    "loyalty",
    "rewards",
    "referral",
    "giftcard",
    "subscription",
    "recurring",
    "churn",
    "retention",
    # Payments
    "gateway",
    "acquirer",
    "issuer",
    "tokenization",
    "pci",
    "settlement",
    "payout",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
