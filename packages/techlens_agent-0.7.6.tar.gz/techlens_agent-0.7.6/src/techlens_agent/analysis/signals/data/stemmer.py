"""Minimal English suffix stemmer for domain token matching.

No external dependencies. Strips common English suffixes to enable
fuzzy matching of inflected forms (plurals, verb forms, adjective forms).
"""

from __future__ import annotations

# Suffixes ordered longest-first to avoid partial matches
_SUFFIXES = [
    ("ization", 4),  # amortization → amort (keep 4 chars min)
    ("isation", 4),
    ("iness", 4),  # happiness → happ (min_stem=4; "business" stays unstemmed)
    ("ation", 4),  # securitization → securitiz (via two passes? no — single pass)
    ("ment", 4),  # settlement → settl
    ("ness", 4),  # readiness → readi
    ("able", 4),  # auditable → audit
    ("ible", 4),  # convertible → convert
    ("tion", 4),  # regulation → regula
    ("sion", 4),  # provision → provi
    ("ance", 4),  # compliance → compli
    ("ence", 4),  # convergence → converg
    ("ling", 4),  # handling → hand
    ("ally", 4),  # actuarially → actuari
    ("ity", 3),  # density → dens
    ("ing", 3),  # clearing → clear
    ("ies", 3),  # policies → polic
    ("ous", 3),  # autonomous → autonom
    ("ive", 3),  # derivative → derivat
    ("ful", 3),  # meaningful → meaning (but meaning → mean after -ing)
    ("ant", 3),  # redundant → redund
    ("ent", 3),  # patient → pati
    ("ial", 3),  # actuarial → actuar
    ("al", 3),  # clinical → clinic
    ("ly", 3),  # rarely → rare
    ("ed", 3),  # cleared → clear
    ("er", 3),  # ledger → ledg
    ("or", 3),  # processor → process (but that's "or" at the end)
    ("es", 3),  # processes → process
    ("s", 3),  # settlements → settlement (but we already handled -ies)
]


def stem(word: str) -> str:
    """Return a stemmed form of *word* (lowercased).

    The stemmer is deliberately simple — it only strips common suffixes
    once (no recursive application). This avoids over-stemming while
    catching the vast majority of English inflections.
    """
    w = word.lower()
    for suffix, min_stem in _SUFFIXES:
        if w.endswith(suffix) and len(w) - len(suffix) >= min_stem:
            return w[: -len(suffix)]
    return w


def stem_set(words: set[str]) -> frozenset[str]:
    """Stem every word in *words* and return a frozen set of stems."""
    return frozenset(stem(w) for w in words)
