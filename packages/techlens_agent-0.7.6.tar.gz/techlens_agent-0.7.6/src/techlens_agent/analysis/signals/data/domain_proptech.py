"""Property technology domain vocabulary.

Terms specific to real estate, property management, and mortgage tech.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Property & listings
    "property",
    "listing",
    "realestate",
    "parcel",
    "zoning",
    "plat",
    "cadastral",
    "floorplan",
    "sqft",
    "acreage",
    "amenity",
    "mls",
    "idx",
    # Transactions
    "appraisal",
    "valuation",
    "comps",
    "closingcost",
    "escrow",
    "titleinsurance",
    "earnestmoney",
    "contingency",
    "counteroffer",
    "duedate",
    "settlement",
    # Rental & leasing
    "tenant",
    "landlord",
    "lease",
    "rental",
    "occupancy",
    "vacancy",
    "eviction",
    "sublease",
    "securitydeposit",
    "rentroll",
    "turnover",
    # Mortgage
    "mortgage",
    "refinance",
    "preapproval",
    "prequalification",
    "loantovalue",
    "dti",
    "amortization",
    "fixedrate",
    "adjustablerate",
    "heloc",
    "origination",
    # Property management
    "maintenance",
    "workorder",
    "inspection",
    "hoa",
    "condo",
    "strata",
    "commonarea",
    "propertymgmt",
    # Investment
    "caprate",
    "noi",
    "cashflow",
    "reit",
    "syndication",
    "proforma",
    "appreciation",
    "depreciation",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
