"""Gaming domain vocabulary.

Terms specific to game development, game engines, and interactive entertainment.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Game mechanics
    "npc",
    "quest",
    "mission",
    "spawn",
    "respawn",
    "powerup",
    "loot",
    "cooldown",
    "buff",
    "debuff",
    "hitpoint",
    "mana",
    "stamina",
    "xp",
    "levelup",
    # Rendering & graphics
    "sprite",
    "texture",
    "shader",
    "mesh",
    "polygon",
    "vertex",
    "render",
    "framerate",
    "fps",
    "drawcall",
    "raycasting",
    "raytracing",
    "skybox",
    "lightmap",
    "postprocessing",
    # Physics & collision
    "rigidbody",
    "collider",
    "collision",
    "hitbox",
    "hurtbox",
    "ragdoll",
    "navmesh",
    "pathfinding",
    "astar",
    "tilemap",
    # Game state
    "savegame",
    "checkpoint",
    "leaderboard",
    "achievement",
    "scoreboard",
    "highscore",
    "matchmaking",
    "lobby",
    "replay",
    # Multiplayer
    "netcode",
    "tickrate",
    "latency",
    "rubberbanding",
    "rollback",
    "clientside",
    "serverside",
    "anticheat",
    # Game economy
    "microtransaction",
    "lootbox",
    "battlepass",
    "cosmetic",
    "ingamecurrency",
    "gacha",
    "dailyreward",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
