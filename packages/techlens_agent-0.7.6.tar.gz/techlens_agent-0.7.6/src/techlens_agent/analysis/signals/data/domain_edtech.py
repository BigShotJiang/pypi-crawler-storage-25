"""Education technology domain vocabulary.

Terms specific to e-learning, LMS platforms, and educational software.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Learning management
    "curriculum",
    "syllabus",
    "course",
    "lesson",
    "lecture",
    "homework",
    "coursework",
    "lms",
    "scorm",
    "xapi",
    # People & roles
    "student",
    "instructor",
    "teacher",
    "tutor",
    "learner",
    "faculty",
    "cohort",
    "classmate",
    # Enrollment & progress
    "enrollment",
    "matriculation",
    "prerequisite",
    "corequisite",
    "semester",
    "trimester",
    "academic",
    "transcript",
    "graduation",
    "dropout",
    "retention",
    # Assessment
    "assessment",
    "quiz",
    "exam",
    "grading",
    "rubric",
    "gradebook",
    "proctoring",
    "plagiarism",
    "submission",
    "autograder",
    "percentile",
    "proficiency",
    # Content & delivery
    "classroom",
    "whiteboard",
    "flashcard",
    "textbook",
    "ebook",
    "annotation",
    "discussion",
    "forum",
    "webinar",
    "livestream",
    # Credentials
    "badge",
    "diploma",
    "accreditation",
    "certification",
    "competency",
    "microcredential",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
