"""Advertising & marketing technology domain vocabulary.

Terms specific to ad platforms, programmatic advertising, and marketing automation.
Used by domain_token_analyzer for domain-specific vocabulary matching.
"""

from .stemmer import stem_set

DOMAIN_TOKENS: set[str] = {
    # Advertising core
    "campaign",
    "impression",
    "clickthrough",
    "ctr",
    "cpc",
    "cpm",
    "cpa",
    "roas",
    "adspend",
    "budget",
    "bid",
    "bidding",
    "auction",
    "adserver",
    "adunit",
    "adgroup",
    "banner",
    "interstitial",
    "preroll",
    "midroll",
    # Targeting & audience
    "audience",
    "segment",
    "retargeting",
    "remarketing",
    "lookalike",
    "cohort",
    "persona",
    "demographic",
    "geotargeting",
    "dayparting",
    "frequency",
    "frequencycap",
    # Programmatic
    "dsp",
    "ssp",
    "rtb",
    "openrtb",
    "prebid",
    "headerbidding",
    "waterfall",
    "mediation",
    "adexchange",
    "dealid",
    "programmatic",
    # Attribution & measurement
    "conversion",
    "funnel",
    "touchpoint",
    "multitouch",
    "lastclick",
    "firstclick",
    "viewability",
    "brandlift",
    "incrementality",
    # Marketing automation
    "nurture",
    "drip",
    "autoresponder",
    "leadscoring",
    "pipeline",
    "lifecycle",
    "engagement",
    "deliverability",
    "openrate",
    "bouncerate",
    # Privacy & consent
    "gdpr",
    "ccpa",
    "consent",
    "optout",
    "optin",
    "cookieless",
}

DOMAIN_STEMS: frozenset[str] = stem_set(DOMAIN_TOKENS)
