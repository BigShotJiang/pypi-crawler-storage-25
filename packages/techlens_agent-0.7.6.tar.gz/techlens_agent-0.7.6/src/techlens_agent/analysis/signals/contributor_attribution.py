"""Contributor Attribution signal — repo-level developer diversity metrics.

Consumes enriched commit data already collected by ``_gather_numstat``
in ``git_density_filter.py`` (via ``PipelineContext.enriched_commits``).
No git calls of its own.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ...utils.contributor import build_contributor_summary
from ..signal_definition import SignalDefinition, SignalLevel

if TYPE_CHECKING:
    from ..pipeline import PipelineContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Analyzer
# ---------------------------------------------------------------------------


def analyze_contributor_attribution(ctx: PipelineContext) -> None:
    """Build contributor summary from enriched commits on the pipeline context."""
    if not ctx.enriched_commits:
        ctx.contributor_summary = build_contributor_summary([])
        logger.warning(
            "No enriched commits available — skipping contributor attribution"
        )
        return

    summary = build_contributor_summary(ctx.enriched_commits)
    ctx.contributor_summary = summary

    logger.info(
        "Contributor attribution: %d total (%d human, %d bot), concentration=%.2f",
        summary["total_developers"],
        summary["human_developers"],
        summary["bot_developers"],
        summary["concentration_pct"],
    )


# ---------------------------------------------------------------------------
# Signal definitions
# ---------------------------------------------------------------------------

SIGNALS = [
    SignalDefinition(
        name="total_contributors",
        description="Total unique developers (authors + co-authors + merge-parent authors)",
        level=SignalLevel.REPO,
        category="git",
        requires_git=True,
        value_range=(0.0, float("inf")),
        why_it_matters=(
            "Team size and breadth of contribution reveal how distributed knowledge is "
            "across the engineering organisation — a key input for retention planning "
            "and integration staffing."
        ),
    ),
    SignalDefinition(
        name="human_contributors",
        description="Unique human (non-bot) developers",
        level=SignalLevel.REPO,
        category="git",
        requires_git=True,
        value_range=(0.0, float("inf")),
        why_it_matters=(
            "Separating bots from humans gives a realistic headcount of the people "
            "who actually built and maintained the codebase."
        ),
    ),
    SignalDefinition(
        name="bot_contributors",
        description="Unique bot identities detected in commit history",
        level=SignalLevel.REPO,
        category="git",
        requires_git=True,
        value_range=(0.0, float("inf")),
        why_it_matters=(
            "High bot contribution counts indicate mature CI/CD automation "
            "(dependabot, renovate, semantic-release) — a positive engineering-maturity signal."
        ),
    ),
    SignalDefinition(
        name="contributor_concentration",
        description="Top-3 developer share of total authored commits (0.0-1.0)",
        level=SignalLevel.REPO,
        category="git",
        requires_git=True,
        value_range=(0.0, 1.0),
        why_it_matters=(
            "High concentration means a small group wrote most of the code — "
            "key-person risk that directly affects retention clauses and earnout structures."
        ),
    ),
]
