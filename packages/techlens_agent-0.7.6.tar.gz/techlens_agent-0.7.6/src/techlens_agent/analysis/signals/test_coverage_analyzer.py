"""Test coverage analyzer — detect test file associations by naming convention.

Checks which source files have associated test files (not runtime coverage).
If a file has tests AND is high-churn, its score gets boosted.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

WEIGHT_TEST_COVERAGE: float = 0.5


def _parent_walk(parent: str) -> list[str]:
    """Generate progressively shorter parent paths for test lookup.

    For ``analysis/signals`` returns ``["analysis/signals", "analysis", "."]``.
    This handles cases where the test directory is flatter than the source
    (e.g. ``src/pkg/analysis/signals/foo.py`` → ``tests/analysis/test_foo.py``).
    """
    variants: list[str] = []
    p = PurePosixPath(parent)
    while str(p) != ".":
        variants.append(str(p))
        p = p.parent
    variants.append(".")
    return variants


def _src_prefix_variants(parent: str) -> list[str]:
    """Generate alternative parent paths by stripping ``src/`` prefix patterns.

    Handles the common Python ``src/<package>/...`` and JS/TS ``src/...``
    layouts so that ``src/pkg/analysis/foo.py`` maps to
    ``tests/analysis/test_foo.py``.

    Also walks up the remaining path to handle flatter test directories
    (e.g. ``src/pkg/analysis/signals/foo.py`` → ``tests/analysis/test_foo.py``).
    """
    parts = PurePosixPath(parent).parts
    if not parts or parts[0] != "src":
        return []
    variants: list[str] = []
    # src/foo/bar -> foo/bar
    inner = "/".join(parts[1:]) if len(parts) > 1 else "."
    variants.extend(_parent_walk(inner))
    # src/pkg/foo/bar -> foo/bar  (strip src/<package>/)
    if len(parts) >= 3:
        inner2 = "/".join(parts[2:]) if len(parts) > 2 else "."
        variants.extend(_parent_walk(inner2))
    # Deduplicate while preserving order
    seen: set[str] = set()
    deduped: list[str] = []
    for v in variants:
        if v not in seen:
            seen.add(v)
            deduped.append(v)
    return deduped


def _find_test_file(source_path: str, known_files: set[str]) -> str | None:
    """Check if a source file has an associated test file.

    Conventions checked:
        Python: test_foo.py, foo_test.py
        JS/TS:  foo.test.ts, foo.spec.ts, __tests__/foo.ts (+ .js/.tsx/.jsx)

    Handles ``src/<package>/`` layouts by stripping the prefix before
    looking in ``tests/``.
    """
    p = PurePosixPath(source_path)
    stem = p.stem  # e.g. "foo" from "foo.py"
    parent = str(p.parent)
    suffix = p.suffix

    if suffix == ".py":
        candidates = [
            f"{parent}/test_{stem}.py",
            f"{parent}/{stem}_test.py",
        ]
        # Also check a tests/ sibling directory
        candidates.append(f"tests/test_{stem}.py")
        if parent != ".":
            candidates.append(f"tests/{parent}/test_{stem}.py")
        # Handle src/<package>/... layouts
        for alt in _src_prefix_variants(parent):
            if alt == ".":
                candidates.append(f"tests/test_{stem}.py")
            else:
                candidates.append(f"tests/{alt}/test_{stem}.py")
                candidates.append(f"tests/{alt}/{stem}_test.py")

    elif suffix == ".rb":
        # RSpec: app/models/report.rb → spec/models/report_spec.rb
        # Works with optional top-level dir: code/app/... → code/spec/...
        candidates = [
            f"{parent}/{stem}_spec.rb",
        ]
        parts = PurePosixPath(source_path).parts
        for marker in ("app", "lib"):
            if marker in parts:
                idx = parts.index(marker)
                prefix = "/".join(parts[:idx])
                rest = "/".join(parts[idx + 1 :])
                rest_p = PurePosixPath(rest)
                full_rest = "/".join(parts[idx:])
                full_rest_p = PurePosixPath(full_rest)
                spec_base = f"{prefix}/spec" if prefix else "spec"
                test_base = f"{prefix}/test" if prefix else "test"
                # spec/models/foo_spec.rb (strip app/)
                candidates.append(f"{spec_base}/{rest_p.parent}/{rest_p.stem}_spec.rb")
                candidates.append(f"{test_base}/{rest_p.parent}/{rest_p.stem}_test.rb")
                # spec/app/models/foo_spec.rb (keep app/)
                candidates.append(
                    f"{spec_base}/{full_rest_p.parent}/{full_rest_p.stem}_spec.rb"
                )
                candidates.append(
                    f"{test_base}/{full_rest_p.parent}/{full_rest_p.stem}_test.rb"
                )
        # Fallback: sibling spec/ directory
        candidates.append(f"spec/{parent}/{stem}_spec.rb")

    elif suffix in (".go",):
        # Go: foo.go → foo_test.go (same directory)
        candidates = [f"{parent}/{stem}_test.go"]

    elif suffix in {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}:
        base_ext = suffix
        candidates = [
            f"{parent}/{stem}.test{base_ext}",
            f"{parent}/{stem}.spec{base_ext}",
            f"{parent}/__tests__/{stem}{base_ext}",
        ]
        # Cross-extension: .js ↔ .ts, .jsx ↔ .tsx
        cross_exts: set[str] = set()
        if suffix in {".js", ".jsx"}:
            cross_exts = {".ts" if suffix == ".js" else ".tsx"}
        elif suffix in {".ts", ".tsx"}:
            cross_exts = {".js" if suffix == ".ts" else ".jsx"}
        for cross_ext in cross_exts:
            candidates.extend(
                [
                    f"{parent}/{stem}.test{cross_ext}",
                    f"{parent}/{stem}.spec{cross_ext}",
                    f"{parent}/__tests__/{stem}{cross_ext}",
                ]
            )
        # Handle src/ layouts
        for alt in _src_prefix_variants(parent):
            base = "." if alt == "." else alt
            for ext in {base_ext} | cross_exts:
                if base == ".":
                    candidates.append(f"tests/{stem}.test{ext}")
                    candidates.append(f"tests/{stem}.spec{ext}")
                    candidates.append(f"__tests__/{stem}{ext}")
                else:
                    candidates.append(f"tests/{base}/{stem}.test{ext}")
                    candidates.append(f"tests/{base}/{stem}.spec{ext}")
                    candidates.append(f"__tests__/{base}/{stem}{ext}")
    else:
        # Non-code extensions (yml, json, sh, sql, etc.) — no test conventions
        return None

    # Normalize paths (remove leading ./ )
    for c in candidates:
        normalized = os.path.normpath(c).replace(os.sep, "/")
        if normalized in known_files:
            return normalized

    return None


def analyze_test_coverage(
    repo_path: str,
    file_paths: list[str],
    manager: AnalysisManager | None = None,
) -> dict[str, str]:
    """Detect which source files have associated test files.

    Args:
        repo_path: Path to the repository root.
        file_paths: List of repo-relative file paths.
        manager: Optional AnalysisManager to contribute weights to.

    Returns:
        Dict mapping source file -> test file path for files with tests.
    """
    known_files = set(file_paths)
    test_map: dict[str, str] = {}

    for path in file_paths:
        # Skip files that are themselves test files
        p = PurePosixPath(path)
        if _is_test_file(p):
            continue

        test_file = _find_test_file(path, known_files)
        if test_file:
            test_map[path] = test_file

    logger.info(
        "Test coverage: %d/%d source files have test files",
        len(test_map),
        len(file_paths),
    )

    # Contribute to manager
    if manager is not None:
        for path in test_map:
            # Clean binary: 1.0 if file has a test, used by server for charts
            manager.add_weight(path, "test_coverage", 1.0)
            # Churn-boosted variant for composite scoring
            git_density_weight = manager.get_weight(path, "git_density")
            if git_density_weight > 0:
                boost = WEIGHT_TEST_COVERAGE * git_density_weight
                manager.add_weight(path, "test_coverage_boosted", boost)
            manager.add_metadata(path, "has_tests", True)

    return test_map


_TEST_DIRS: frozenset = frozenset(
    {"test", "tests", "spec", "specs", "__tests__", "__test__"}
)


def _is_test_file(p: PurePosixPath) -> bool:
    """Check if a file path looks like a test file."""
    # Directory-based: any ancestor is a known test directory
    if _TEST_DIRS.intersection(p.parts):
        return True

    name = p.stem.lower()
    return (
        name.startswith("test_")
        or name.endswith("_test")
        or name.endswith("_spec")
        or name.endswith(".test")
        or name.endswith(".spec")
    )


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNALS = [
    SignalDefinition(
        name="test_coverage",
        description="Binary 1.0/0.0 per file indicating presence of an associated test file",
        level=SignalLevel.PER_FILE,
        category="architecture",
        manager_weight=1.0,
        why_it_matters="Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.",
    ),
    SignalDefinition(
        name="test_coverage_boosted",
        description="Churn-weighted boost for tested files (test_coverage * git_density)",
        level=SignalLevel.PER_FILE,
        category="architecture",
        manager_weight=0.5,
        composites=[
            CompositeContribution(composite="engineering_score", weight=0.30),
        ],
        why_it_matters="Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.",
    ),
    SignalDefinition(
        name="test_coverage_ratio",
        description="Ratio of testable files (source, model, service, controller, repository, middleware, util) that have associated test files. Excludes views, vendor, generated, lock, build artifact, fixture, test, migration, config, and infra from the denominator.",
        level=SignalLevel.REPO,
        category="architecture",
        why_it_matters="Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.",
    ),
]
