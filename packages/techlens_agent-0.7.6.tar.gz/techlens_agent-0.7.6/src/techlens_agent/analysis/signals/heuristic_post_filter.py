from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import scipy.stats as stats

from .slm_analyzer import (
    SLMAgent,
    SLMAgentQueries,
    CodeValueResponse,
    CombinedOutlierResponse,
    GlueCodeResponse,
    PerFileValueResponse,
    ProgramValueSynthesisResponse,
)

if TYPE_CHECKING:
    from ..analysis_manager import FileScore

logger = logging.getLogger(__name__)


def compute_git_density_outliers(files: list) -> list:
    """Return files with z-score > 3 (statistical outliers in git density)."""
    if len(files) < 2:
        return list(files)

    scores = [f.density_score for f in files]

    if len(set(scores)) <= 1:
        return []

    z_scores = stats.zscore(scores)
    return [f for i, f in enumerate(files) if z_scores[i] > 3]


def _read_file_contexts(paths: list[str], repo_path: str) -> list[str]:
    """Read source files and return formatted context strings for SLM."""
    repo = Path(repo_path)
    contexts = []
    for p in paths:
        full = repo / p
        try:
            content = full.read_text(encoding="utf-8", errors="replace")
            contexts.append(f"--- FILE: {p} ---\n{content}\n--- END FILE ---")
        except OSError:
            logger.debug("Could not read %s, skipping", p)
    return contexts


class HeuristicPostFilter:
    def __init__(
        self,
        highest_git_density_paths: list,
        gluemarker_ratio: float,
        domain_token_density: float,
        external_call_ratio: float,
        control_flow_density: float,
        definition_density: float,
        comment_ratio: float,
        duplication_ratio: float,
        top_composite_files: list[FileScore] | None = None,
        repo_path: str | None = None,
        auto_run: bool = True,
        skip_per_file: bool = False,
        domain_match_density: float = 0.0,
        domain_profile: str = "",
    ) -> None:
        self.highest_git_density_paths = highest_git_density_paths
        self.top_composite_files = top_composite_files or []
        self.repo_path = repo_path
        self.gluemarker_ratio = gluemarker_ratio
        self.domain_token_density = domain_token_density
        self.domain_match_density = domain_match_density
        self.domain_profile = domain_profile
        self.external_call_ratio = external_call_ratio
        self.control_flow_density = control_flow_density
        self.definition_density = definition_density
        self.comment_ratio = comment_ratio
        self.duplication_ratio = duplication_ratio
        self.skip_per_file = skip_per_file

        # Populated by slm_pre_filter / run()
        self.per_file_values: dict[str, dict] = {}
        self.program_synthesis: dict = {}

        if auto_run:
            self.slm_pre_filter()

    def highest_git_density_outliers(self) -> list:
        """Return files with z-score > 3 (statistical outliers in git density)."""
        return compute_git_density_outliers(self.highest_git_density_paths)

    def _highest_composite_outliers(self) -> list[FileScore]:
        """Return FileScore outliers by composite_score (z-score > 3)."""
        if len(self.top_composite_files) < 2:
            return list(self.top_composite_files)

        scores = [fs.composite_score for fs in self.top_composite_files]
        z_scores = stats.zscore(scores)

        return [fs for i, fs in enumerate(self.top_composite_files) if z_scores[i] > 3]

    def _outlier_paths(self) -> list[str]:
        """Get file paths from the best available outlier source."""
        if self.top_composite_files:
            return [fs.path for fs in self._highest_composite_outliers()]
        return [f.path for f in self.highest_git_density_outliers()]

    def _top_composite_paths(self, n: int = 20) -> list[str]:
        """Get paths of the top N composite files."""
        return [fs.path for fs in self.top_composite_files[:n]]

    def run(self) -> None:
        """Public entry point — alias for slm_pre_filter()."""
        self.slm_pre_filter()

    def slm_pre_filter(self) -> None:
        outlier_paths = self._outlier_paths()
        logger.info(
            "SLM pre-filter: %d outlier files, %d top composite files",
            len(outlier_paths),
            len(self.top_composite_files),
        )

        # Read actual source code if repo_path is available
        if self.repo_path and outlier_paths:
            files = _read_file_contexts(outlier_paths, self.repo_path)
        else:
            files = outlier_paths

        # Single combined call for both code-value and glue assessments
        combined = SLMAgent.query(
            prompt=SLMAgentQueries.COMBINED_OUTLIER_ASSESSMENT,
            files=files,
        )

        if combined.error is None and isinstance(combined, CombinedOutlierResponse):
            self.code_value_assessment = CodeValueResponse(
                uniqueness_score=combined.uniqueness_score,
                novel_concepts=combined.novel_concepts,
                innovative_files=combined.innovative_files,
                rationale=combined.code_value_rationale,
                raw_response=combined.raw_response,
            )
            self.slm_glue_assessment = GlueCodeResponse(
                originality_ratio=combined.originality_ratio,
                glue_files=combined.glue_files,
                original_files=combined.original_files,
                rationale=combined.glue_rationale,
                raw_response=combined.raw_response,
            )
        else:
            self.code_value_assessment = combined
            self.slm_glue_assessment = combined
            if combined.error:
                logger.warning("Combined outlier SLM query failed: %s", combined.error)

        if self.skip_per_file:
            logger.debug("Skipping per-file SLM pass (skip_per_file=True)")
            return

        # === Pass 1: Per-file value + description ===
        top_paths = self._top_composite_paths()
        if self.repo_path and top_paths:
            top_files = _read_file_contexts(top_paths, self.repo_path)
        else:
            top_files = top_paths

        if top_files:
            per_file_response = SLMAgent.query(
                prompt=SLMAgentQueries.PER_FILE_VALUE,
                files=top_files,
            )
            if per_file_response.error is None and isinstance(
                per_file_response, PerFileValueResponse
            ):
                for item in per_file_response.files:
                    self.per_file_values[item.path] = {
                        "slm_description": item.description,
                        "slm_value_score": item.value_score,
                        "slm_rationale": item.rationale,
                    }
                logger.info(
                    "Per-file SLM values: %d files scored",
                    len(self.per_file_values),
                )

                # === Pass 2: Synthesize program-level understanding ===
                self._run_program_synthesis()

    def _run_program_synthesis(self) -> None:
        """Use per-file descriptions to synthesize a program-level value score."""
        if not self.per_file_values:
            return

        # Build a summary string from per-file results
        summaries = []
        for path, data in self.per_file_values.items():
            desc = data.get("slm_description", "")
            score = data.get("slm_value_score", 0.0)
            rationale = data.get("slm_rationale", "")
            summaries.append(
                f"- {path} (value={score:.2f}): {desc}\n  Rationale: {rationale}"
            )

        synthesis_response = SLMAgent.query(
            prompt=SLMAgentQueries.PROGRAM_VALUE_SYNTHESIS,
            files=summaries,
        )

        if synthesis_response.error is None and isinstance(
            synthesis_response, ProgramValueSynthesisResponse
        ):
            self.program_synthesis = {
                "program_description": synthesis_response.program_description,
                "program_value_score": synthesis_response.value_score,
                "program_rationale": synthesis_response.rationale,
            }
            logger.info(
                "Program synthesis: score=%.2f | %s",
                synthesis_response.value_score,
                synthesis_response.program_description[:100],
            )

    def output(self) -> dict:
        return {
            "highest_git_density_paths": self.highest_git_density_paths,
            "gluemarker_ratio": self.gluemarker_ratio,
            "domain_token_density": self.domain_token_density,
            "domain_match_density": self.domain_match_density,
            "domain_profile": self.domain_profile,
            "external_call_ratio": self.external_call_ratio,
            "control_flow_density": self.control_flow_density,
            "definition_density": self.definition_density,
            "comment_ratio": self.comment_ratio,
            "duplication_ratio": self.duplication_ratio,
            "per_file_values": self.per_file_values,
            "program_synthesis": self.program_synthesis,
            "code_value_assessment": getattr(self, "code_value_assessment", None),
            "slm_glue_assessment": getattr(self, "slm_glue_assessment", None),
        }


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

# SIGNALS temporarily commented out to exclude from docs
# from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel
# SIGNALS = [
#     SignalDefinition(
#         name="code_value_uniqueness",
#         description="SLM-assessed uniqueness score from outlier code analysis",
#         level=SignalLevel.REPO,
#         category="slm",
#         requires_slm=True,
#         composites=[
#             CompositeContribution(composite="moat_score", weight=0.13),
#         ],
#         why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
#     ),
#     SignalDefinition(
#         name="glue_originality_ratio",
#         description="SLM-assessed ratio of original code to glue/boilerplate",
#         level=SignalLevel.REPO,
#         category="slm",
#         requires_slm=True,
#         why_it_matters="Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.",
#     ),
# ]
