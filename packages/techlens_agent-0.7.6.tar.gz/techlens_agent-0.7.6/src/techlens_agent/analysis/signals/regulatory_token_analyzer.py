"""Regulatory token analyzer — detects compliance/regulatory patterns.

Scores repositories based on two independent signals:
1. Path parts matching known compliance/regulatory naming conventions.
2. Manifest dependencies matching curated regulatory package names.
"""

from __future__ import annotations

import logging
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

from .data.regulatory_packages import REGULATORY_PACKAGES
from .manifest_parser import extract_dependency_names

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Path patterns
# ---------------------------------------------------------------------------

REGULATORY_PATH_PARTS: frozenset[str] = frozenset(
    {
        "compliance",
        "hipaa",
        "gdpr",
        "pci",
        "sox",
        "fedramp",
        "phi",
        "pii",
        "encryption",
        "encrypt",
        "consent",
        "data-protection",
        "privacy",
    }
)


def analyze_regulatory_tokens(
    file_paths: list[str],
    repo_path: str,
    manager: AnalysisManager | None = None,
) -> float | None:
    """Return regulatory density, or None if no evidence."""

    # --- Path signal ---
    path_matches = 0
    for path in file_paths:
        p = PurePosixPath(path)
        parts = {part.lower() for part in p.parts}
        parts.add(p.stem.lower())
        if parts & REGULATORY_PATH_PARTS:
            path_matches += 1
            if manager is not None:
                manager.add_weight(path, "regulatory_tokens", 1.0)

    path_ratio: float | None = None
    if path_matches > 0:
        path_ratio = min(path_matches / max(len(file_paths), 1) / 0.05, 1.0)

    # --- Dependency signal ---
    deps = extract_dependency_names(repo_path)
    dep_ratio: float | None = None
    if deps:
        matches = deps & REGULATORY_PACKAGES
        if matches:
            dep_ratio = min(len(matches) / len(deps) / 0.05, 1.0)

    # --- Combine ---
    if path_ratio is not None and dep_ratio is not None:
        score = (path_ratio + dep_ratio) / 2
    elif path_ratio is not None:
        score = path_ratio * 0.7
    elif dep_ratio is not None:
        score = dep_ratio * 0.7
    else:
        return None

    logger.info(
        "Regulatory tokens: path_ratio=%s, dep_ratio=%s, score=%.3f",
        path_ratio,
        dep_ratio,
        score,
    )
    return score


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="regulatory_token_density",
    description="Density of compliance/regulatory paths and deps indicating regulatory moat",
    level=SignalLevel.REPO,
    category="architecture",
    manager_weight=1.0,
    composites=[
        CompositeContribution(
            composite="moat_score",
            weight=0.12,
        ),
    ],
    why_it_matters="Regulated industries create natural moats because compliance requirements raise the barrier to entry for competitors and AI. A codebase with deep HIPAA, PCI, or SOX implementations reflects years of regulatory domain knowledge that can't be shortcut.",
)
