"""Realtime pattern analyzer — detects realtime/event-driven architecture.

Matches manifest dependencies against a curated package list to compute
a realtime dependency density score.
"""

from __future__ import annotations

import logging

from .data.realtime_packages import REALTIME_PACKAGES
from .manifest_parser import extract_dependency_names

logger = logging.getLogger(__name__)


def analyze_realtime_patterns(repo_path: str) -> float | None:
    """Return realtime dependency density, or None if no manifests found."""
    deps = extract_dependency_names(repo_path)
    if not deps:
        return None

    matches = deps & REALTIME_PACKAGES
    raw_ratio = len(matches) / len(deps)
    scaled = min(raw_ratio / 0.10, 1.0)

    logger.info(
        "Realtime patterns: %d/%d deps matched (raw=%.3f, scaled=%.3f)",
        len(matches),
        len(deps),
        raw_ratio,
        scaled,
    )
    return scaled


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="realtime_pattern_density",
    description="Ratio of realtime/event-driven dependencies to total dependencies",
    level=SignalLevel.REPO,
    category="architecture",
    composites=[
        CompositeContribution(
            composite="moat_score",
            weight=0.06,
        ),
    ],
    why_it_matters="Detects a resilient AI moat. Low-latency and high-frequency domains (WebSocket, gRPC, streaming) are among the hardest for AI to replicate because they require real-time state management and performance engineering. Presence signals sticky technical complexity.",
)
