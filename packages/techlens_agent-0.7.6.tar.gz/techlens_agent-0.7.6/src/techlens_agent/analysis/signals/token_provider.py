"""Lazy per-file Pygments tokenization cache.

Shared across signal analyzers via ``manager.get_shared("token_provider", TokenProvider)``.
Each file is tokenized at most once; subsequent calls return the cached result.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

import chardet
from pygments import lexers
from pygments.util import ClassNotFound

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)


class TokenProvider:
    """Lazy Pygments tokenization cache for signal analyzers."""

    def __init__(self, manager: AnalysisManager) -> None:
        self._repo_path = manager.repo_path
        self._cache: dict[str, tuple[str, list] | None] = {}

    def get_tokens(self, rel_path: str) -> tuple[str, list] | None:
        """Return (lexer_name, token_list) for a file, cached after first call.

        Returns None when the file cannot be tokenized (binary, missing, or
        no Pygments lexer available).
        """
        if rel_path in self._cache:
            return self._cache[rel_path]

        result = self._tokenize(rel_path)
        self._cache[rel_path] = result
        return result

    def _tokenize(self, rel_path: str) -> tuple[str, list] | None:
        abs_path = os.path.join(self._repo_path, rel_path)
        try:
            with open(abs_path, "rb") as f:
                raw = f.read()
        except OSError:
            logger.debug("Cannot read %s, skipping tokenization", rel_path)
            return None

        # Skip binary files
        if b"\x00" in raw[:8192]:
            logger.debug("Binary file detected: %s", rel_path)
            return None

        try:
            lexer = lexers.get_lexer_for_filename(abs_path)
        except ClassNotFound:
            logger.debug("No lexer for %s", rel_path)
            return None

        enc = chardet.detect(raw[:4096])["encoding"] or "utf-8"
        try:
            text = raw.decode(enc, errors="replace")
        except LookupError:
            text = raw.decode("utf-8", errors="replace")
        tokens = list(lexer.get_tokens(text))
        return (lexer.name, tokens)
