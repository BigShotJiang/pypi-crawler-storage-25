"""Import fanout metrics.

Counts internal vs external imports per file using Pygments tokens.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Iterator

from ..signal_definition import SignalDefinition, SignalLevel
from .token_provider import TokenProvider

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# --- Import detection constants ---

_NEEDLES = {
    "Python": ["Token.Name.Namespace"],
    "C": ["Token.Comment.PreprocFile"],
    "C++": ["Token.Comment.PreprocFile"],
    "Java": ["Token.Name.Namespace"],
    "C#": ["Token.Name.Namespace"],
}

_FUNCTIONS = {"PHP": "_parse_php", "Go": "_parse_go", "Ruby": "_parse_ruby"}

_INTERNAL = {
    "Python": {"start": ".", "end": ""},
    "C": {"start": '"', "end": '"'},
    "C++": {"start": '"', "end": '"'},
    "Ruby": {"start": "__relative__:", "end": ""},
}


# --- Language-specific import parsers ---


_TokenValue = tuple[Any, str]
_IndexedToken = tuple[int, _TokenValue]


def _parse_php(iterator: Iterator[_IndexedToken]) -> list[str]:
    res = []
    _start_token = ["include", "require", "include_once", "require_once"]
    _cont_token = ["Token.Literal.String.Single", "Token.Literal.String.Double"]
    for _i, val in iterator:
        if str(val[0]) in ["Token.Keyword"] and val[1] in _start_token:
            try:
                while str(val[0]) not in _cont_token:
                    _i, val = next(iterator)
                res.append(val[1].strip("'").strip('"'))
            except StopIteration:
                break
    return res


def _parse_ruby(iterator: Iterator[_IndexedToken]) -> list[str]:
    """Parse Ruby require/require_relative. Prefixes require_relative paths with '__relative__:'."""
    tokens = list(iterator)
    _start_token = ["require", "require_relative"]
    _cont_token = ["Token.Literal.String.Single", "Token.Literal.String.Double"]
    res = []
    idx = 0

    while idx < len(tokens):
        _i, val = tokens[idx]
        if str(val[0]) == "Token.Name.Builtin" and val[1] in _start_token:
            is_relative = val[1] == "require_relative"
            idx += 1
            while idx < len(tokens):
                _i, val = tokens[idx]
                t = str(val[0])
                if t in _cont_token:
                    name = val[1].strip("'").strip('"')
                    if is_relative:
                        name = "__relative__:" + name
                    res.append(name)
                    break
                if t == "Token.Text" and val[1] in ["\n", "\r\n"]:
                    break
                idx += 1
        idx += 1

    return res


def _parse_go(iterator: Iterator[_IndexedToken]) -> list[str]:
    res = []
    for _i, val in iterator:
        if str(val[0]) in ["Token.Keyword.Namespace"] and val[1] in ["import"]:
            try:
                _i, val = next(iterator)
                # Skip whitespace
                while str(val[0]).startswith("Token.Text"):
                    _i, val = next(iterator)
                if str(val[0]) == "Token.Punctuation" and val[1] == "(":
                    # Grouped import block — collect until closing paren
                    while True:
                        _i, val = next(iterator)
                        if str(val[0]) in ["Token.Literal.String"]:
                            res.append(val[1].strip("'").strip('"'))
                        if str(val[0]) == "Token.Punctuation" and val[1] == ")":
                            break
                elif str(val[0]) in ["Token.Literal.String"]:
                    # Single import without parens
                    res.append(val[1].strip("'").strip('"'))
            except StopIteration:
                pass
    return res


def _parse_js_ts(iterator: Iterator[_IndexedToken]) -> list[str]:
    """Parse JS/TS import/require statements."""
    res = []
    _string_tokens = {
        "Token.Literal.String.Single",
        "Token.Literal.String.Double",
        "Token.Literal.String.Backtick",
        "Token.Literal.String",
    }
    for _i, val in iterator:
        tok_type = str(val[0])
        tok_val = val[1]
        # import ... from 'path'
        if (
            tok_type in ("Token.Keyword", "Token.Keyword.Declaration")
            and tok_val == "import"
        ):
            try:
                while True:
                    _i, val = next(iterator)
                    t = str(val[0])
                    if t in _string_tokens:
                        res.append(val[1].strip("'").strip('"').strip("`"))
                        break
                    if val[1] in ["\n", "\r\n", ";"]:
                        break
            except StopIteration:
                pass
        # const x = require('path')
        elif tok_type == "Token.Name.Other" and tok_val == "require":
            try:
                while True:
                    _i, val = next(iterator)
                    t = str(val[0])
                    if t in _string_tokens:
                        res.append(val[1].strip("'").strip('"').strip("`"))
                        break
                    if val[1] in ["\n", "\r\n", ";"]:
                        break
            except StopIteration:
                pass
    return res


_PARSER_MAP = {
    "PHP": _parse_php,
    "Go": _parse_go,
    "Ruby": _parse_ruby,
    "JavaScript": _parse_js_ts,
    "TypeScript": _parse_js_ts,
}


def _is_internal_js_ts(value: str) -> bool:
    """JS/TS: relative paths (./  ../) and alias paths (@/) are internal."""
    return value.startswith(".") or value.startswith("@/")


def _is_internal(value: str, internal_mapping: dict) -> bool:
    return value.startswith(internal_mapping["start"]) and value.endswith(
        internal_mapping["end"]
    )


def _parse_imports(lexer_name: str, tokens: list) -> tuple[set, set]:
    """Parse tokens and return (internal_imports, external_imports) sets."""
    internal_mapping = _INTERNAL.get(lexer_name)

    imports = []
    if lexer_name in _NEEDLES:
        needle_types = _NEEDLES[lexer_name]
        # Track preceding keyword to skip package/namespace declarations
        _DECL_KEYWORDS = {"package", "namespace"}
        last_keyword = None
        for tok in tokens:
            tok_type = str(tok[0])
            if tok_type == "Token.Keyword.Namespace":
                last_keyword = tok[1]
            elif tok_type in needle_types:
                if last_keyword not in _DECL_KEYWORDS:
                    imports.append(tok[1])
                last_keyword = None
    elif lexer_name in _PARSER_MAP:
        imports = _PARSER_MAP[lexer_name](enumerate(tokens))

    int_set: set[str] = set()
    ext_set: set[str] = set()
    for x in imports:
        val = str(x)
        if lexer_name in ("JavaScript", "TypeScript"):
            if _is_internal_js_ts(val):
                int_set.add(val)
            else:
                ext_set.add(val)
        elif internal_mapping and _is_internal(val, internal_mapping):
            int_set.add(val)
        else:
            ext_set.add(val)
    return int_set, ext_set


def _infer_base_package(
    file_paths: list[str],
    provider: TokenProvider,
    lexer_name_filter: str,
) -> str | None:
    """Infer the project's base package from the most common two-segment import prefix.

    Used for Java/C# where there's no syntactic marker for internal imports.
    Scans all files of the given language, collects the first two segments of each
    import path (e.g. 'com.mycompany'), and returns the most frequent one if it
    appears in >50% of imports.
    """
    from collections import Counter

    segment_counts: Counter[str] = Counter()
    total = 0
    for path in file_paths:
        result = provider.get_tokens(path)
        if result is None:
            continue
        lexer, tokens = result
        if lexer != lexer_name_filter:
            continue
        needle_types = _NEEDLES.get(lexer, [])
        _DECL_KEYWORDS = {"package", "namespace"}
        last_keyword = None
        for tok in tokens:
            tok_type = str(tok[0])
            if tok_type == "Token.Keyword.Namespace":
                last_keyword = tok[1]
            elif tok_type in needle_types:
                if last_keyword not in _DECL_KEYWORDS:
                    val = str(tok[1])
                    parts = val.split(".")
                    first_seg = ".".join(parts[:2]) if len(parts) >= 2 else parts[0]
                    segment_counts[first_seg] += 1
                    total += 1
                last_keyword = None

    if total == 0:
        return None

    top_seg, top_count = segment_counts.most_common(1)[0]
    if top_count / total > 0.5:
        return top_seg
    return None


def analyze_fanout(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Count internal and external imports per file."""
    provider = manager.get_shared("token_provider", TokenProvider)

    # Infer base packages for Java/C# (frequency heuristic)
    base_packages: dict[str, str | None] = {}
    for lang in ("Java", "C#"):
        base_packages[lang] = _infer_base_package(file_paths, provider, lang)
        if base_packages[lang]:
            logger.debug("Inferred %s base package: %s", lang, base_packages[lang])

    for path in file_paths:
        result = provider.get_tokens(path)
        if result is None:
            continue
        lexer_name, tokens = result

        int_set, ext_set = _parse_imports(lexer_name, tokens)

        # Reclassify Java/C# imports using inferred base package
        if lexer_name in base_packages and base_packages[lexer_name]:
            base = base_packages[lexer_name]
            all_imports = int_set | ext_set
            prefix = f"{base}."
            int_set = {x for x in all_imports if x == base or x.startswith(prefix)}
            ext_set = all_imports - int_set

        manager.add_metadata(path, "fanout_internal", len(int_set))
        manager.add_metadata(path, "fanout_external", len(ext_set))
        manager.add_metadata(path, "fanout_internal_paths", sorted(int_set))
        manager.add_metadata(path, "fanout_external_paths", sorted(ext_set))


SIGNALS = [
    SignalDefinition(
        name="fanout_internal",
        description="Count of unique internal (relative) imports per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Measures internal coupling. Files that import many other project files are integration points — complex to modify and test because changes ripple across the dependency chain.",
    ),
    SignalDefinition(
        name="fanout_external",
        description="Count of unique external imports per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Measures external dependency at the file level. Files pulling in many third-party libraries are vulnerable to vendor changes and are often glue code rather than proprietary logic.",
    ),
]
