"""Signal analyzers sub-package.

All signal computation modules live here.  The parent ``analysis``
package imports what it needs via ``from .signals.<module> import ...``.
"""

from .code_metrics import CodeMetricsResult, analyze_code_metrics
from .context_builder import BuiltContext, ContextChunk, build_context
from .domain_token_analyzer import analyze_domain_tokens, analyze_domain_match
from .duplication_analyzer import analyze_duplication
from .external_call_analyzer import analyze_external_calls
from .file_filter import FilterResult, filter_files
from .git_density_filter import (
    DensityResult,
    DensityWeights,
    FileDensity,
    calculate_density,
    get_high_density_files,
)
from .glue_marker_analyzer import analyze_glue_markers
from .heuristic_post_filter import HeuristicPostFilter
from .import_graph_analyzer import analyze_import_graph
from .slm_analyzer import (
    LmCodeValueResponse,
    PerFileValueResponse,
    ProgramValueSynthesisResponse,
    SLMAgent,
    SLMAgentQueries,
    SlmAfterFilterResult,
    SlmResponse,
    analyse,
)
from .cyclomatic_analyzer import analyze_cyclomatic
from .fanout_analyzer import analyze_fanout
from .halstead_analyzer import analyze_halstead
from .maintainability_analyzer import analyze_maintainability
from .operand_operator_analyzer import analyze_operands_operators
from .test_coverage_analyzer import analyze_test_coverage
from .tiobe_analyzer import analyze_tiobe
from .token_provider import TokenProvider

__all__ = [
    "CodeMetricsResult",
    "analyze_code_metrics",
    "BuiltContext",
    "ContextChunk",
    "build_context",
    "analyze_domain_tokens",
    "analyze_domain_match",
    "analyze_duplication",
    "analyze_external_calls",
    "FilterResult",
    "filter_files",
    "DensityResult",
    "DensityWeights",
    "FileDensity",
    "calculate_density",
    "get_high_density_files",
    "analyze_glue_markers",
    "HeuristicPostFilter",
    "analyze_import_graph",
    "LmCodeValueResponse",
    "PerFileValueResponse",
    "ProgramValueSynthesisResponse",
    "SLMAgent",
    "SLMAgentQueries",
    "SlmAfterFilterResult",
    "SlmResponse",
    "analyse",
    "analyze_cyclomatic",
    "analyze_fanout",
    "analyze_halstead",
    "analyze_maintainability",
    "analyze_operands_operators",
    "analyze_test_coverage",
    "analyze_tiobe",
    "TokenProvider",
]
