"""Cyclomatic complexity and LOC/comment metrics.

Runs on shared Pygments tokens and stores results as per-file metadata.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import pygments.token
from pygount.analysis import (
    white_characters,
    white_code_words,
    _delined_tokens,
    _pythonized_comments,
)

from ..signal_definition import SignalDefinition, SignalLevel
from .token_provider import TokenProvider

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# --- Cyclomatic complexity constants ---

_KEYWORD_CONDITIONS = {"if", "elif", "case", "for", "while", "and", "or"}
_OPERATOR_CONDITIONS = {"&&", "||"}

# --- Comment token types ---

_COMMENT_TOKENS = [
    "Token.Comment",
    "Token.Comment.Hashbang",
    "Token.Comment.Multiline",
    "Token.Comment.Single",
    "Token.Comment.Special",
    "Token.Literal.String.Doc",
]

_COMMENT_SPECIFIC = {"Python": ["Token.Comment.Preproc"]}


# --- LOC helpers ---


def _line_parts(tokens, language_id: str):
    line_marks = set()
    white_text = " \f\n\r\t" + white_characters(language_id)
    white_words = white_code_words(language_id)
    for token_type, token_text in tokens:
        is_actual_comment = token_type in pygments.token.Comment and token_type not in (
            pygments.token.Comment.Preproc,
            pygments.token.Comment.PreprocFile,
        )
        if is_actual_comment:
            line_marks.add("d")
        elif token_type in pygments.token.String:
            line_marks.add("s")
        else:
            is_white_text = (token_text.strip() in white_words) or (
                token_text.rstrip(white_text) == ""
            )
            if not is_white_text:
                line_marks.add("c")

        if token_text.endswith("\n"):
            yield line_marks
            line_marks = set()
    if len(line_marks) >= 1:
        yield line_marks


def _compute_loc(lexer_name: str, tokens: list) -> dict:
    """Classify lines and return LOC metrics dict."""
    delined = _delined_tokens(tokens)
    if lexer_name.lower() == "python":
        delined = _pythonized_comments(delined)

    mark_to_count = {"c": 0, "d": 0, "e": 0, "s": 0}
    for parts in _line_parts(delined, lexer_name.lower()):
        mark = "e"
        for check in ("d", "s", "c"):
            if check in parts:
                mark = check
        mark_to_count[mark] += 1

    # LOC = code + documentation + empty (everything except string-only lines)
    loc = mark_to_count["c"] + mark_to_count["d"] + mark_to_count["e"]

    return {
        "loc": loc,
        "code_loc": mark_to_count["c"],
        "documentation_loc": mark_to_count["d"],
        "empty_loc": mark_to_count["e"],
        "string_loc": mark_to_count["s"],
    }


def _compute_cyclomatic(tokens: list) -> int:
    """Count cyclomatic complexity from token values (decision points + 1)."""
    decision_points = 0
    for tok_type, tok_val in tokens:
        val = str(tok_val)
        if tok_type in pygments.token.Keyword and val in _KEYWORD_CONDITIONS:
            decision_points += 1
        elif tok_type in pygments.token.Operator and val in _OPERATOR_CONDITIONS:
            decision_points += 1
    return decision_points + 1


def _compute_comment_ratio(lexer_name: str, tokens: list) -> float:
    """Compute comment character ratio as a percentage."""
    needles = list(_COMMENT_TOKENS)
    if lexer_name in _COMMENT_SPECIFIC:
        needles += _COMMENT_SPECIFIC[lexer_name]

    overall = 0
    comments = 0
    for tok_type, tok_val in tokens:
        val_str = str(tok_val)
        overall += len(val_str)
        if str(tok_type) in needles:
            comments += len(val_str)

    if overall == 0:
        overall = 1
    return comments * 100.0 / float(overall)


def analyze_cyclomatic(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Compute cyclomatic complexity, LOC, and comment ratio per file."""
    provider = manager.get_shared("token_provider", TokenProvider)

    for path in file_paths:
        result = provider.get_tokens(path)
        if result is None:
            continue
        lexer_name, tokens = result

        cc = _compute_cyclomatic(tokens)
        manager.add_metadata(path, "cyclomatic_complexity", cc)

        manager.add_metadata(path, "lang", [lexer_name])

        loc_result = _compute_loc(lexer_name, tokens)
        manager.add_metadata(path, "tm_loc", loc_result["loc"])
        manager.add_metadata(path, "tm_code_loc", loc_result["code_loc"])
        manager.add_metadata(
            path, "tm_documentation_loc", loc_result["documentation_loc"]
        )
        manager.add_metadata(path, "tm_empty_loc", loc_result["empty_loc"])
        manager.add_metadata(path, "tm_string_loc", loc_result["string_loc"])

        cr = _compute_comment_ratio(lexer_name, tokens)
        manager.add_metadata(path, "tm_comment_ratio", cr)


SIGNAL = SignalDefinition(
    name="cyclomatic_complexity",
    description="McCabe cyclomatic complexity per file",
    level=SignalLevel.PER_FILE,
    category="static_analysis",
    value_range=(0.0, float("inf")),
    why_it_matters="Measures the number of independent execution paths through the code. High cyclomatic complexity means more test cases needed for full coverage and higher probability of latent defects — directly impacting post-close stabilization effort.",
)
