"""Operand and operator counts.

Produces 4 per-file metadata values consumed by the Halstead analyzer.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..signal_definition import SignalDefinition, SignalLevel
from .token_provider import TokenProvider

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# --- Operand token types ---

_OPERAND_TOKENS = [
    "Token.Literal.Date",
    "Token.Literal.String.Double",
    "Token.Literal.String",
    "Token.Literal.Number.Bin",
    "Token.Literal.Number.Float",
    "Token.Literal.Number.Hex",
    "Token.Literal.Number.Integer.Long",
    "Token.Literal.Number.Integer",
    "Token.Literal.Number.Oct",
    "Token.Literal.Number",
    "Token.Name",
    "Token.Name.Attribute",
    "Token.Name.Builtin.Pseudo",
    "Token.Name.Builtin",
    "Token.Name.Constant",
    "Token.Name.Variable.Class",
    "Token.Name.Variable.Global",
    "Token.Name.Variable.Instance",
    "Token.Name.Variable.Magic",
    "Token.Name.Variable",
    "Token.Name.Other",
    "Token.Number.Bin",
    "Token.Number.Float",
    "Token.Number.Hex",
    "Token.Number.Integer.Long",
    "Token.Number.Integer",
    "Token.Number.Oct",
    "Token.Number",
    "Token.String.Char",
    "Token.String.Double",
    "Token.String.Escape",
    "Token.String.Heredoc",
    "Token.String.Interpol",
    "Token.String.Other",
    "Token.String.Regex",
    "Token.String.Single",
    "Token.String.Symbol",
]

# --- Operator token types ---

_OPERATOR_TOKENS = [
    "Token.Name.Class",
    "Token.Name.Decorator",
    "Token.Name.Entity",
    "Token.Name.Exception",
    "Token.Name.Function.Magic",
    "Token.Name.Function",
    "Token.Name.Label",
    "Token.Name.Tag",
    "Token.Operator.Word",
    "Token.Operator",
    "Token.Punctuation",
    "Token.String.Affix",
    "Token.String.Delimiter",
]

_OPERAND_SET = frozenset(_OPERAND_TOKENS)
_OPERATOR_SET = frozenset(_OPERATOR_TOKENS)
_DEFINITION_TOKENS = frozenset({"Token.Name.Function", "Token.Name.Class"})


def analyze_operands_operators(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Count operands and operators per file using Pygments tokens."""
    provider = manager.get_shared("token_provider", TokenProvider)

    for path in file_paths:
        result = provider.get_tokens(path)
        if result is None:
            continue
        _lexer_name, tokens = result

        operands: list[str] = []
        operators: list[str] = []
        definitions: set[str] = set()
        for tok_type, tok_val in tokens:
            type_str = str(tok_type)
            if type_str in _OPERAND_SET:
                operands.append(str(tok_val))
            elif type_str in _OPERATOR_SET:
                operators.append(str(tok_val))
                if type_str in _DEFINITION_TOKENS:
                    definitions.add(str(tok_val))

        manager.add_metadata(path, "operands_sum", len(operands))
        manager.add_metadata(path, "operands_unique", len(set(operands)))
        manager.add_metadata(path, "operators_sum", len(operators))
        manager.add_metadata(path, "operators_unique", len(set(operators)))
        manager.add_metadata(path, "definitions_count", len(definitions))


SIGNALS = [
    SignalDefinition(
        name="operands_sum",
        description="Total operand token count per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Raw input for Halstead metrics. Total operand count reflects data volume flowing through the code — higher counts indicate files doing substantive data transformation rather than simple pass-through.",
    ),
    SignalDefinition(
        name="operands_unique",
        description="Unique operand token count per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Vocabulary breadth of data elements. A file with many unique operands is manipulating a rich data model, suggesting domain-specific logic that is harder to replicate or replace with generic tooling.",
    ),
    SignalDefinition(
        name="operators_sum",
        description="Total operator token count per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Raw input for Halstead metrics. High operator counts relative to operands indicate dense control logic and data manipulation, contributing to implementation effort estimates.",
    ),
    SignalDefinition(
        name="operators_unique",
        description="Unique operator token count per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Indicates the breadth of language features and constructs used. Files leveraging more unique operators tend to implement more sophisticated algorithms that require deeper expertise to maintain.",
    ),
    SignalDefinition(
        name="definitions_count",
        description="Unique function and class definition count per file",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Counts distinct function and class definitions via Pygments tokens. High definition counts indicate files that declare substantial API surface — more definitions mean more contracts to maintain, test, and document.",
    ),
]
