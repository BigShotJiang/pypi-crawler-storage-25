"""Halstead complexity metrics.

Reads operand/operator metadata (set by operand_operator_analyzer) and
computes Halstead volume, difficulty, effort, bug propensity, and time required.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..formulas import calc_halstead
from ..signal_definition import SignalDefinition, SignalLevel

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)


def analyze_halstead(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Compute Halstead metrics per file from operand/operator metadata."""
    for path in file_paths:
        metrics = {
            "operands_sum": manager.get_metadata(path, "operands_sum", 0),
            "operands_uniq": manager.get_metadata(path, "operands_unique", 0),
            "operators_sum": manager.get_metadata(path, "operators_sum", 0),
            "operators_uniq": manager.get_metadata(path, "operators_unique", 0),
        }

        # Skip files with no tokens
        if metrics["operands_sum"] == 0 and metrics["operators_sum"] == 0:
            continue

        result = calc_halstead(metrics)
        manager.add_metadata(path, "halstead_volume", result.get("halstead_volume", 0))
        manager.add_metadata(
            path, "halstead_difficulty", result.get("halstead_difficulty", 0)
        )
        manager.add_metadata(path, "halstead_effort", result.get("halstead_effort", 0))
        manager.add_metadata(
            path, "halstead_bugprop", result.get("halstead_bugprop", 0)
        )
        manager.add_metadata(
            path, "halstead_timerequired", result.get("halstead_timerequired", 0)
        )


SIGNALS = [
    SignalDefinition(
        name="halstead_volume",
        description="Halstead program volume",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Measures the information content of the code in bits. High volume files contain more logic to understand, test, and maintain — directly proportional to the knowledge transfer effort required post-acquisition.",
    ),
    SignalDefinition(
        name="halstead_difficulty",
        description="Halstead program difficulty",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Quantifies how hard the code is to write or understand. High difficulty files are error-prone to modify and require senior engineers — a factor in retention planning and post-close staffing decisions.",
    ),
    SignalDefinition(
        name="halstead_effort",
        description="Halstead implementation effort",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Enables rebuild estimation and t-shirt sizing. The top 10 files account for 60% of total comprehension effort, giving concrete input for post-close staffing and timeline planning.",
    ),
    SignalDefinition(
        name="halstead_bugprop",
        description="Halstead estimated bug propensity",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Predicts the expected number of delivered defects based on code volume. Files with high bug propensity are where post-close quality issues will concentrate — informing QA resource allocation and stabilization timelines.",
    ),
    SignalDefinition(
        name="halstead_timerequired",
        description="Halstead estimated implementation time",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, float("inf")),
        why_it_matters="Estimates implementation time in seconds per file. High values flag modules that will take longest to rewrite or onboard — giving concrete input for rebuild timelines and staffing plans.",
    ),
]
