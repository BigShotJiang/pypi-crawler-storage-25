"""Duplication analyzer - detects identical code blocks.

Finds runs of 4+ consecutive lines that appear verbatim in more than
one location.  Import lines are excluded so that shared import blocks
don't inflate the score.
"""

import hashlib
import re
from collections import Counter

# Minimum block size (in lines) to consider for duplication
MIN_BLOCK_SIZE = 4

# Lines that start with an import keyword are excluded from blocks.
_IMPORT_LINE = re.compile(r"^\s*(?:import\s|from\s)")


def _usable_lines(content: str) -> list[str]:
    """Return non-empty, non-import lines with whitespace stripped."""
    lines: list[str] = []
    for raw in content.split("\n"):
        stripped = raw.strip()
        if not stripped:
            continue
        if _IMPORT_LINE.match(stripped):
            continue
        lines.append(stripped)
    return lines


def _create_fingerprints(
    lines: list[str],
    block_size: int = MIN_BLOCK_SIZE,
) -> list[str]:
    """Create MD5 fingerprints for sliding windows of lines."""
    if len(lines) < block_size:
        return []

    fingerprints: list[str] = []
    for i in range(len(lines) - block_size + 1):
        block = "\n".join(lines[i : i + block_size])
        fp = hashlib.md5(block.encode()).hexdigest()
        fingerprints.append(fp)

    return fingerprints


def analyze_duplication(contents: list[str]) -> float:
    """Analyze code for duplication ratio.

    Args:
        contents: List of file contents to analyze.

    Returns:
        Duplication ratio (0.0-1.0).
        Higher values indicate more duplicated code.
    """
    if not contents:
        return 0.0

    all_fingerprints: list[str] = []

    for content in contents:
        if not content.strip():
            continue

        lines = _usable_lines(content)
        fingerprints = _create_fingerprints(lines)
        all_fingerprints.extend(fingerprints)

    if not all_fingerprints:
        return 0.0

    fp_counts = Counter(all_fingerprints)

    duplicated_blocks = sum(count - 1 for count in fp_counts.values() if count > 1)

    total_blocks = len(all_fingerprints)
    if total_blocks == 0:
        return 0.0

    raw_ratio = duplicated_blocks / total_blocks

    # Scale so 0.3 raw -> 1.0
    normalized = min(raw_ratio / 0.3, 1.0)

    return normalized


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="duplication_ratio",
    description="Ratio of duplicated code blocks across files",
    level=SignalLevel.REPO,
    category="heuristic",
    composites=[
        CompositeContribution(
            composite="engineering_score", weight=0.25, inverted=True
        ),
    ],
    why_it_matters="High duplication is a direct indicator of technical debt and rebuild cost. Copy-pasted code means bugs exist in multiple places, refactoring is more expensive than it appears, and the team's engineering practices are weak.",
)
