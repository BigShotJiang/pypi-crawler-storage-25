"""External call analyzer - measures ratio of external library calls.

Distinguishes between calls to external libraries/stdlib vs internal code.
High external call ratio indicates wrapper/glue code.
Low external call ratio indicates original implementation.
"""

import re

from .data.external_libraries import EXTERNAL_LIBRARIES
from .data.structural_libraries import STRUCTURAL_LIBRARIES

# Pattern for function/method calls
CALL_PATTERN = re.compile(
    r"(?:"
    r"(\w+)\s*\.\s*(\w+)\s*\(|"  # obj.method() or module.func()
    r"(\w+)\s*\("  # direct function call
    r")"
)

# Pattern for imports (to identify what's external)
IMPORT_MODULE_PATTERN = re.compile(
    r"(?:"
    r"import\s+([\w.]+)|"  # Python import x.y
    r"from\s+([\w.]+)\s+import|"  # Python from x.y import
    r'require\s*\([\'"]([^\'"]+)|'  # Node require('x')
    r'import\s+.*?from\s+[\'"]([^\'"]+)'  # ES6 import from 'x'
    r")"
)

# Pattern for named imports: ``from <module> import <name1>, <name2>``
_NAMED_IMPORT_PATTERN = re.compile(r"from\s+([\w.]+)\s+import\s+([^#\n]+)")


def _extract_base_module(module_path: str) -> str:
    """Extract base module name from a dotted path."""
    return module_path.split(".")[0].split("/")[0]


def analyze_external_calls(content: str) -> float:
    """Analyze content for external library call ratio.

    Args:
        content: Source code content to analyze.

    Returns:
        External call ratio (0.0-1.0).
        Higher values indicate more external library usage.
    """
    if not content.strip():
        return 0.0

    # First, identify imported modules
    import_matches = IMPORT_MODULE_PATTERN.findall(content)
    imported_modules = set()

    for match in import_matches:
        # match is a tuple from the groups
        for m in match:
            if m and not m.startswith("."):
                base = _extract_base_module(m)
                imported_modules.add(base.lower())

    # Also capture named symbols from ``from X import A, B as C``
    # Skip structural libraries — their symbols shouldn't count as external.
    for mod, names_str in _NAMED_IMPORT_PATTERN.findall(content):
        if mod.startswith("."):
            continue
        base = _extract_base_module(mod)
        if base.lower() in STRUCTURAL_LIBRARIES:
            continue
        if base.lower() in EXTERNAL_LIBRARIES or base.lower() in imported_modules:
            for token in names_str.split(","):
                token = token.strip()
                if not token:
                    continue
                # Handle ``Name as alias`` - take the alias (or original)
                parts = token.split()
                name = parts[-1] if len(parts) >= 3 and parts[-2] == "as" else parts[0]
                # Strip trailing parens/brackets from edge-case patterns
                name = name.strip("()")
                if name and name.isidentifier():
                    imported_modules.add(name.lower())

    # Find all calls
    call_matches = CALL_PATTERN.findall(content)
    external_calls = 0
    total_calls = 0

    for match in call_matches:
        obj_or_module, _method, direct_func = match

        total_calls += 1

        # Check if this looks like an external call
        caller = (obj_or_module or direct_func or "").lower()

        # Skip structural / stdlib calls — these are language infrastructure
        if caller in STRUCTURAL_LIBRARIES:
            continue

        # Is it a known external library?
        if caller in EXTERNAL_LIBRARIES:
            external_calls += 1
            continue

        # Is it an imported external module?
        if caller in imported_modules and caller not in STRUCTURAL_LIBRARIES:
            external_calls += 1
            continue

        # Common external call patterns
        if any(caller.startswith(prefix) for prefix in ["np", "pd", "tf", "plt", "cv"]):
            external_calls += 1
            continue

    if total_calls == 0:
        return 0.0

    return external_calls / total_calls


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="external_call_ratio",
    description="Ratio of external library calls to total function calls",
    level=SignalLevel.REPO,
    category="heuristic",
    composites=[
        CompositeContribution(composite="moat_score", weight=0.12, inverted=True),
    ],
    why_it_matters="Measures how self-contained the product's value is. High external dependency means vulnerability to vendor pricing changes, API deprecation, or third-party outages. Inverse relationship to defensibility.",
)
