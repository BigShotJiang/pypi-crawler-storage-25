"""TIOBE quality index and Pylint score.

Reads per-file metadata from earlier stages and computes TIOBE subscores
and overall quality index, plus the Pylint-style score.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..formulas import calc_pylint, calc_tiobe
from ..signal_definition import SignalDefinition, SignalLevel

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

# Keys that TIOBE/Pylint calcs need from per-file metadata.
_METRIC_KEYS = {
    "cyclomatic_complexity": 0,
    "fanout_internal": 0,
    "fanout_external": 0,
    "tm_loc": 0,
    "operands_sum": 0,
    "operators_sum": 0,
}


def _build_metrics(manager, path: str) -> dict:
    """Collect prerequisite metrics from manager metadata into a dict."""
    m = {}
    for key, default in _METRIC_KEYS.items():
        m[key] = manager.get_metadata(path, key, default)
    # TIOBE/Pylint expect "loc" not "tm_loc"
    m["loc"] = m.pop("tm_loc")
    return m


def analyze_tiobe(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Compute TIOBE and Pylint scores per file from earlier metadata."""
    for path in file_paths:
        metrics = _build_metrics(manager, path)

        # Skip files with no meaningful data
        if metrics["loc"] == 0 and metrics["operands_sum"] == 0:
            continue

        tiobe_result = calc_tiobe(dict(metrics))
        pylint_result = calc_pylint(dict(metrics))

        manager.add_metadata(path, "tiobe", tiobe_result.get("tiobe", 0))
        manager.add_metadata(
            path, "tiobe_complexity", tiobe_result.get("tiobe_complexity", 0)
        )
        manager.add_metadata(path, "tiobe_fanout", tiobe_result.get("tiobe_fanout", 0))
        manager.add_metadata(
            path, "tiobe_compiler", tiobe_result.get("tiobe_compiler", 100)
        )
        manager.add_metadata(
            path, "tiobe_coverage", tiobe_result.get("tiobe_coverage", 100)
        )
        manager.add_metadata(
            path, "tiobe_duplication", tiobe_result.get("tiobe_duplication", 100)
        )
        manager.add_metadata(
            path, "tiobe_functional", tiobe_result.get("tiobe_functional", 100)
        )
        manager.add_metadata(
            path, "tiobe_security", tiobe_result.get("tiobe_security", 100)
        )
        manager.add_metadata(
            path, "tiobe_standard", tiobe_result.get("tiobe_standard", 100)
        )
        manager.add_metadata(path, "pylint", pylint_result.get("pylint", 100))


SIGNALS = [
    SignalDefinition(
        name="tiobe",
        description="TIOBE quality index (0-100)",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, 100.0),
        why_it_matters="Industry-standard composite quality score combining complexity, code size, and duplication. Enables cross-repo benchmarking: 'This file scores 45/100, below the threshold for maintainable production code.'",
    ),
    SignalDefinition(
        name="pylint",
        description="Pylint-style quality score (0-100)",
        level=SignalLevel.PER_FILE,
        category="static_analysis",
        value_range=(0.0, 100.0),
        why_it_matters="Widely recognized quality score in the Python ecosystem. Provides a familiar benchmark that engineering teams and technical advisors already understand, reducing friction in due-diligence conversations.",
    ),
]
