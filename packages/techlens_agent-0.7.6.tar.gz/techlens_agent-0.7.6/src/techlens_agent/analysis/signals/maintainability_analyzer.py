"""SEI Maintainability Index.

Reads halstead_volume, cyclomatic_complexity, and LOC metadata from
earlier pipeline stages and computes the classic maintainability index.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..formulas import calc_maintainability_index
from ..signal_definition import SignalDefinition, SignalLevel

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)


def analyze_maintainability(
    file_paths: list[str],
    manager: AnalysisManager,
) -> None:
    """Compute maintainability index per file from earlier metadata."""
    for path in file_paths:
        halstead_vol = manager.get_metadata(path, "halstead_volume", 0)
        cc = manager.get_metadata(path, "cyclomatic_complexity", 0)
        loc = manager.get_metadata(path, "tm_loc", 0)

        # Need at least some data to compute MI; halstead_vol==0 causes log(0)
        if loc == 0 or halstead_vol == 0:
            continue

        metrics = {
            "halstead_volume": halstead_vol,
            "cyclomatic_complexity": cc,
            "loc": max(loc, 1),  # avoid log(0)
            "comment_ratio": manager.get_metadata(path, "tm_comment_ratio", 0),
        }

        result = calc_maintainability_index(metrics)
        manager.add_metadata(
            path, "maintainability_index", result.get("maintainability_index", 0)
        )


SIGNAL = SignalDefinition(
    name="maintainability_index",
    description="SEI maintainability index (0-100)",
    level=SignalLevel.PER_FILE,
    category="static_analysis",
    value_range=(0.0, 100.0),
    why_it_matters="Ready-made quality score on a 0-100 scale that's immediately interpretable. 'This repo scores 35 on maintainability, bottom quartile across 200+ codebases we've assessed' is a finding that lands in investment committee presentations.",
)
