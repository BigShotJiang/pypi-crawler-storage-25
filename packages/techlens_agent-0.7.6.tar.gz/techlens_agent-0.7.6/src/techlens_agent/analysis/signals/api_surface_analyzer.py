"""API surface analyzer — ratio of API/controller/handler files to total source files.

Counts files whose path parts match common API-layer naming conventions
and normalizes by total source file count.
"""

from __future__ import annotations

import logging
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..analysis_manager import AnalysisManager

logger = logging.getLogger(__name__)

API_PATH_PARTS: frozenset[str] = frozenset(
    {
        "controller",
        "controllers",
        "route",
        "routes",
        "router",
        "routers",
        "api",
        "apis",
        "endpoint",
        "endpoints",
        "handler",
        "handlers",
        "resolver",
        "resolvers",  # GraphQL
        "view",
        "views",  # Django
        "resource",
        "resources",  # REST
    }
)

# A repo where >=15% of source files are API files scores 1.0.
_SATURATION_THRESHOLD = 0.15


def analyze_api_surface(
    file_paths: list[str],
    manager: AnalysisManager | None = None,
) -> float | None:
    """Return ratio of API files to total source files, or None."""
    if not file_paths:
        return None

    api_count = 0
    for path in file_paths:
        p = PurePosixPath(path)
        parts = {part.lower() for part in p.parts}
        parts.add(p.stem.lower())
        if parts & API_PATH_PARTS:
            api_count += 1
            if manager is not None:
                manager.add_weight(path, "api_surface", 1.0)

    raw_ratio = api_count / len(file_paths)
    score = min(raw_ratio / _SATURATION_THRESHOLD, 1.0)

    logger.info(
        "API surface: %d/%d files (%.1f%%), score=%.3f",
        api_count,
        len(file_paths),
        raw_ratio * 100,
        score,
    )
    return score


# ---------------------------------------------------------------------------
# Signal definition
# ---------------------------------------------------------------------------

from ..signal_definition import CompositeContribution, SignalDefinition, SignalLevel

SIGNAL = SignalDefinition(
    name="api_surface_ratio",
    description="Ratio of API-exposed files (controllers, routes, handlers, views, resolvers, resources). Measures what fraction of source files exposes external endpoints.",
    level=SignalLevel.REPO,
    category="architecture",
    manager_weight=1.0,
    composites=[
        CompositeContribution(
            composite="moat_score",
            weight=0.06,
        ),
    ],
    why_it_matters="Detects interface control. A product with a large API surface that third parties integrate with creates switching costs proportional to the number of external consumers. More endpoints = more ecosystem dependence = stickier product.",
)
