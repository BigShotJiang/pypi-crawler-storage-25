"""File role classification based on path patterns.

Assigns a semantic role to each file purely from its path (no content
inspection). Roles are priority-ordered: earlier rules win over later ones.

Used by the pipeline to tag files for downstream signal weighting and
to replace ad-hoc ``_is_test_file`` / ``_is_infra_file`` helpers.
"""

from __future__ import annotations

import os
import re
from pathlib import PurePosixPath

from ..signal_definition import SignalDefinition, SignalLevel

# --------------------------------------------------------------------------- #
# Role definitions — ordered by priority (first match wins)
# --------------------------------------------------------------------------- #

_GENERATED_PATTERNS = re.compile(
    r"(\.pb\.go$|_pb2\.py$|\.g\.dart$|\.generated\.|__generated__)"
)
_GENERATED_DIRS = frozenset({"generated", "__generated__"})
_GENERATED_PATH_PATTERNS = re.compile(r"(^|/)db/schema\.rb$")

_VENDOR_DIRS = frozenset(
    {
        "vendor",
        "vendors",
        "third_party",
        "extern",
        "external",
        "node_modules",
        "gems",
        "bundler",
        "bower_components",
        ".bundle",
        "pods",
        "carthage",
    }
)

_LOCK_NAMES = frozenset(
    {
        "package-lock.json",
        "yarn.lock",
        "pnpm-lock.yaml",
        "gemfile.lock",
        "pipfile.lock",
        "poetry.lock",
        "composer.lock",
        "cargo.lock",
        "go.sum",
        "bun.lockb",
    }
)

_BUILD_ARTIFACT_DIRS = frozenset(
    {
        "dist",
        "build",
        "out",
        "output",
        "target",
        "__pycache__",
        ".next",
        ".nuxt",
        "coverage",
        ".nyc_output",
        "js_coverage",
        "log",
        "logs",
        "tmp",
    }
)
_BUILD_ARTIFACT_PATTERNS = re.compile(
    r"(\.min\.js|\.min\.css|\.bundle\.js|\.chunk\.js|\.map|\.d\.ts)$"
)

_FIXTURE_DIRS = frozenset(
    {
        "fixtures",
        "fixture",
        "__fixtures__",
        "seeds",
        "factories",
        "mocks",
        "__mocks__",
        "testdata",
        "test_data",
    }
)
_FIXTURE_NAMES = frozenset({"seeds"})

_TEST_PARTIAL_DIRS = re.compile(r"(^|_)tests?(_|$)")

_TEST_DIRS = frozenset(
    {"test", "tests", "spec", "specs", "__tests__", "__test__", "cypress"}
)
_TEST_SUFFIXES = ("_test", "_spec", ".test", ".spec")
_TEST_PREFIXES = ("test_",)
_TEST_NAMES = frozenset({"conftest"})

_MIGRATION_DIRS = frozenset(
    {"migrations", "migrate", "alembic", "flyway", "db_migrations"}
)

_VIEW_EXTENSIONS = frozenset(
    {
        ".html",
        ".hbs",
        ".ejs",
        ".jinja2",
        ".j2",
        ".blade.php",
        ".erb",
        ".mustache",
        ".pug",
        ".jade",
        ".twig",
        ".liquid",
    }
)
_VIEW_DIRS = frozenset({"templates", "pages", "components", "partials", "layouts"})

_CONTROLLER_DIRS = frozenset(
    {
        "controllers",
        "views",
        "routes",
        "handlers",
        "endpoints",
        "api",
        "graphql",
        "channels",
        "resolvers",
    }
)
_CONTROLLER_SUFFIXES = ("_controller", "_handler", "_view", "_route", "_endpoint")

_MODEL_DIRS = frozenset({"models", "entities", "schemas", "domain"})
_MODEL_SUFFIXES = ("_model", "_entity", "_schema")

_SERVICE_DIRS = frozenset(
    {"services", "service", "workers", "jobs", "mailers", "loaders"}
)
_SERVICE_SUFFIXES = ("_service",)

_REPOSITORY_DIRS = frozenset({"repositories", "repos", "repository"})
_REPOSITORY_SUFFIXES = ("_repository", "_repo", "_dao")

_MIDDLEWARE_DIRS = frozenset({"middleware", "middlewares", "policies"})
_MIDDLEWARE_SUFFIXES = ("_middleware",)

_UTIL_DIRS = frozenset(
    {
        "utils",
        "helpers",
        "lib",
        "common",
        "shared",
        "support",
        "scripts",
        "script",
        "hooks",
    }
)
_UTIL_SUFFIXES = ("_util", "_utils", "_helper", "_helpers")

_CONFIG_EXTENSIONS = frozenset(
    {".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".env", ".properties"}
)
_CONFIG_DIRS = frozenset(
    {"config", "configs", "configuration", "settings", ".storybook", ".obsidian"}
)
_CONFIG_NAMES = frozenset({"settings", "config"})
_CONFIG_NAME_PATTERNS = re.compile(
    r"^(tsconfig|jsconfig|\.eslintrc|\.prettierrc|\.stylelintrc|\.babelrc|"
    r"\.browserslistrc|\.editorconfig|\.commitlintrc|\.lintstagedrc)"
    r"|\.config\.(js|ts|mjs|cjs)$"
)

_INFRA_DIRS = frozenset(
    {
        ".github",
        ".gitlab",
        ".circleci",
        "terraform",
        ".terraform",
        "helm",
        "k8s",
        ".devcontainer",
    }
)
_INFRA_NAMES = frozenset({"dockerfile", "docker-compose", "jenkinsfile", "vagrantfile"})
_INFRA_EXTENSIONS = frozenset({".tf", ".hcl", ".gradle", ".cmake", ".makefile", ".mk"})


def classify_file_role(path: str) -> str:
    """Return the semantic role of a file based on its path.

    Roles (priority order): generated, vendor, lock, build_artifact, fixture,
    test, migration, view, controller, model, service, repository, middleware,
    config, infra, util, source.
    """
    p = PurePosixPath(path)
    parts_lower = [x.lower() for x in p.parts]
    name_lower = p.name.lower()
    stem_lower = p.stem.lower()
    suffix_lower = p.suffix.lower()

    # 1. Generated
    if _GENERATED_PATTERNS.search(name_lower):
        return "generated"
    if _GENERATED_DIRS.intersection(parts_lower):
        return "generated"
    if _GENERATED_PATH_PATTERNS.search(path):
        return "generated"

    # 2. Vendor
    if _VENDOR_DIRS.intersection(parts_lower):
        return "vendor"

    # 3. Lock
    if name_lower in _LOCK_NAMES or suffix_lower == ".lock":
        return "lock"

    # 4. Build artifact
    if _BUILD_ARTIFACT_DIRS.intersection(parts_lower):
        return "build_artifact"
    if _BUILD_ARTIFACT_PATTERNS.search(name_lower):
        return "build_artifact"

    # 5. Fixture
    if _FIXTURE_DIRS.intersection(parts_lower):
        return "fixture"
    if stem_lower in _FIXTURE_NAMES:
        return "fixture"

    # 6. Test
    if _TEST_DIRS.intersection(parts_lower):
        return "test"
    if any(stem_lower.startswith(px) for px in _TEST_PREFIXES):
        return "test"
    if any(stem_lower.endswith(sx) for sx in _TEST_SUFFIXES):
        return "test"
    if stem_lower in _TEST_NAMES:
        return "test"
    if any(_TEST_PARTIAL_DIRS.search(part) for part in parts_lower):
        return "test"

    # 7. Migration
    if _MIGRATION_DIRS.intersection(parts_lower):
        return "migration"

    # 8. View / template (extension-based — high confidence)
    if suffix_lower in _VIEW_EXTENSIONS:
        return "view"
    if any(name_lower.endswith(s) for s in (".blade.php",)):
        return "view"
    if _VIEW_DIRS.intersection(parts_lower):
        return "view"

    # 9. Controller
    if _CONTROLLER_DIRS.intersection(parts_lower):
        return "controller"
    if any(stem_lower.endswith(sx) for sx in _CONTROLLER_SUFFIXES):
        return "controller"

    # 10. Model
    if _MODEL_DIRS.intersection(parts_lower):
        return "model"
    if any(stem_lower.endswith(sx) for sx in _MODEL_SUFFIXES):
        return "model"

    # 11. Service
    if _SERVICE_DIRS.intersection(parts_lower):
        return "service"
    if any(stem_lower.endswith(sx) for sx in _SERVICE_SUFFIXES):
        return "service"

    # 12. Repository / DAO
    if _REPOSITORY_DIRS.intersection(parts_lower):
        return "repository"
    if any(stem_lower.endswith(sx) for sx in _REPOSITORY_SUFFIXES):
        return "repository"

    # 13. Middleware
    if _MIDDLEWARE_DIRS.intersection(parts_lower):
        return "middleware"
    if any(stem_lower.endswith(sx) for sx in _MIDDLEWARE_SUFFIXES):
        return "middleware"

    # 14. Infra directories (checked before config so .github/workflows/ci.yml → infra)
    if _INFRA_DIRS.intersection(parts_lower):
        return "infra"

    # 15. Config
    if suffix_lower in _CONFIG_EXTENSIONS:
        return "config"
    if name_lower.startswith(".env"):
        return "config"
    if _CONFIG_DIRS.intersection(parts_lower):
        return "config"
    if stem_lower in _CONFIG_NAMES:
        return "config"
    if _CONFIG_NAME_PATTERNS.search(name_lower):
        return "config"

    # 16. Infra files (after config so standalone .yml files → config)
    if name_lower in _INFRA_NAMES or name_lower.startswith("dockerfile"):
        return "infra"
    if name_lower.startswith("docker-compose"):
        return "infra"
    if suffix_lower in _INFRA_EXTENSIONS:
        return "infra"
    if name_lower in ("makefile", "gnumakefile"):
        return "infra"

    # 17. Util / helper
    if _UTIL_DIRS.intersection(parts_lower):
        return "util"
    if any(stem_lower.endswith(sx) for sx in _UTIL_SUFFIXES):
        return "util"

    # 18. Source (default)
    return "source"


SIGNAL = SignalDefinition(
    name="file_role",
    description="Semantic role classification per file (generated, vendor, lock, build_artifact, fixture, test, migration, view, controller, model, service, repository, middleware, config, infra, util, source)",
    level=SignalLevel.PER_FILE,
    category="static_analysis",
    why_it_matters="Enables targeted analysis by distinguishing code that matters (business logic, controllers, models) from code that doesn't (generated, vendored, config). Downstream signals can weight files differently based on their role.",
)
