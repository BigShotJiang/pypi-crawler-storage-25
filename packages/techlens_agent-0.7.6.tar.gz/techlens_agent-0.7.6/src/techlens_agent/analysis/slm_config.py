"""Configuration for the SLM agent."""

from pydantic import BaseModel, Field


class SlmConfig(BaseModel):
    """Configuration for the SLM agent pipeline."""

    model: str = "gemma3:4b"
    ollama_host: str = "http://localhost:11434"
    chunk_token_budget: int = Field(default=10000, gt=0)
    temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    request_timeout: float = Field(default=6000.0, gt=0)
    version: str = "1.0.0"

    model_config = {"frozen": True}
