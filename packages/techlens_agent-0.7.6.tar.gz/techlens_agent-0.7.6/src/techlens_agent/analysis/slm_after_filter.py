"""SLM After-Filter — "Engineered vs Assembled" analysis.

Orchestrates the three-stage pipeline:
  1. File filtering  (file_filter)
  2. Context building (context_builder)
  3. SLM analysis     (slm_analyzer)

Can be run standalone via ``python -m techlens_agent.analysis.slm_after_filter``.
"""

import argparse
import json
import logging
import os
import sys
from typing import Any, Dict, Optional

from pathlib import PurePosixPath

from .signals.context_builder import build_context
from .signals.file_filter import filter_files
from .signals.slm_analyzer import SlmAfterFilterResult, analyse
from .signals.test_coverage_analyzer import _is_test_file
from .slm_config import SlmConfig

logger = logging.getLogger(__name__)


def run_slm_after_filter(
    repo_path: str,
    output_path: Optional[str] = None,
    config: Optional[SlmConfig] = None,
) -> Dict[str, Any]:
    """Run the full SLM after-filter pipeline on *repo_path*.

    Returns the result dictionary and optionally writes it to *output_path*.
    """
    if config is None:
        config = SlmConfig()

    repo_path = os.path.abspath(repo_path)

    # Stage 1 — file filtering
    logger.info("Stage 1: filtering files in %s", repo_path)
    filter_result = filter_files(repo_path)
    logger.info(
        "  %d files selected, %d skipped, %d total scanned",
        len(filter_result.selected_files),
        filter_result.skipped_count,
        filter_result.total_scanned,
    )

    # Exclude test/spec files from SLM analysis
    source_files = [
        f
        for f in filter_result.selected_files
        if not _is_test_file(PurePosixPath(f[0]))
    ]
    logger.info(
        "  %d source files after test/spec exclusion",
        len(source_files),
    )

    # Stage 2 — context building
    logger.info(
        "Stage 2: building context chunks (budget=%d)", config.chunk_token_budget
    )
    built = build_context(
        repo_path=repo_path,
        selected_files=source_files,
        chunk_token_budget=config.chunk_token_budget,
    )
    logger.info("  %s", built.summary_line)

    # Stage 3 — SLM analysis
    logger.info("Stage 3: running SLM analysis (%s)", config.model)
    result: SlmAfterFilterResult = analyse(built.chunks, config)

    if result.error:
        logger.error("  SLM error: %s", result.error)
    else:
        logger.info(
            "  assessment=%s  score=%.2f",
            result.assessment,
            result.assessment_score,
        )

    # Build output dict
    output: Dict[str, Any] = {
        "engineered_vs_assembled": {
            "assessment": result.assessment,
            "assessment_score": result.assessment_score,
            "delta_score": 0.0,  # v1: no deterministic score to compare
            "notes": result.notes,
        },
        "_metadata": {
            "model": result.model,
            "files_analyzed": built.files_included,
            "files_total": filter_result.total_scanned,
            "chunks": result.chunk_count,
            "token_budget_per_chunk": config.chunk_token_budget,
            "version": config.version,
        },
    }

    if result.error:
        output["_metadata"]["error"] = result.error

    # Write output file
    if output_path:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)
        logger.info("Output written to %s", output_path)

    return output


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def _cli() -> None:
    parser = argparse.ArgumentParser(
        description="SLM After-Filter: Engineered vs Assembled analysis",
    )
    parser.add_argument(
        "--path",
        required=True,
        help="Path to the repository to analyse",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Output JSON file path (default: results/<repo>.slm_review.json)",
    )
    parser.add_argument(
        "--model",
        default="gemma3:4b",
        help="Ollama model name (default: gemma3:4b)",
    )
    parser.add_argument(
        "--token-budget",
        type=int,
        default=6000,
        help="Token budget per chunk (default: 6000)",
    )
    parser.add_argument(
        "--host",
        default="http://localhost:11434",
        help="Ollama host URL (default: http://localhost:11434)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("chardet").setLevel(logging.WARNING)

    config = SlmConfig(
        model=args.model,
        ollama_host=args.host,
        chunk_token_budget=args.token_budget,
    )

    repo_name = os.path.basename(os.path.abspath(args.path))
    output_path = args.output or f"results/{repo_name}.slm_review.json"

    result = run_slm_after_filter(
        repo_path=args.path,
        output_path=output_path,
        config=config,
    )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    _cli()
