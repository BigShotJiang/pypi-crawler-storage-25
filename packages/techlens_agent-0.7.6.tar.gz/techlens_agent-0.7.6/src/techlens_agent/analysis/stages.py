"""Thin stage wrappers around existing analyzers.

Each function reads what it needs from PipelineContext, calls the
underlying analyzer, and writes results back to the context.

Pipeline compositions (FULL_ANALYSIS, POST_FILTER_ONLY) are plain lists
at the bottom of the module.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import PurePosixPath

from .analysis_manager import AnalysisManager
from .pipeline import PipelineContext, Stage
from .signals.code_metrics import analyze_code_metrics
from .signals.context_builder import build_context
from .signals.cyclomatic_analyzer import analyze_cyclomatic
from .signals.fanout_analyzer import analyze_fanout
from .signals.file_filter import filter_files
from .signals.cochange_clusters import compute_cochange_clusters
from .signals.git_density_filter import calculate_density, FileDensity
from .signals.halstead_analyzer import analyze_halstead
from .signals.heuristic_post_filter import HeuristicPostFilter
from .signals.import_graph_analyzer import analyze_import_graph
from .signals.maintainability_analyzer import analyze_maintainability
from .signals.operand_operator_analyzer import analyze_operands_operators
from .signals.tiobe_analyzer import analyze_tiobe
from .signals.slm_analyzer import (
    SLMAgent,
    SLMAgentQueries,
    LmCodeValueResponse,
    PerFileValueResponse,
    ProgramValueSynthesisResponse,
)
from .signals.contributor_attribution import analyze_contributor_attribution
from .signals.churn_risk_analyzer import analyze_churn_risk
from .signals.file_role_classifier import classify_file_role
from .signals.test_coverage_analyzer import analyze_test_coverage, _is_test_file
from .signals.api_surface_analyzer import analyze_api_surface
from .signals.data_accumulation_analyzer import analyze_data_accumulation
from .signals.realtime_pattern_analyzer import analyze_realtime_patterns
from .signals.governance_workflow_analyzer import analyze_governance_workflow
from .signals.regulatory_token_analyzer import analyze_regulatory_tokens

logger = logging.getLogger(__name__)

# Extensions that are config / infra, not code.  These are still counted in
# overview stats but excluded from composite scoring and code-quality metrics
# so that YAML workflows and shell scripts don't distort the rankings.
_INFRA_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".yaml",
        ".yml",
        ".json",
        ".xml",
        ".toml",
        ".sh",
        ".bash",
        ".zsh",
        ".tf",
        ".hcl",
        ".gradle",
        ".cmake",
        ".makefile",
        ".mk",
    }
)


def _is_infra_file(path: PurePosixPath) -> bool:
    name = path.name.lower()
    if name in ("makefile", "gnumakefile", "dockerfile"):
        return True
    return path.suffix.lower() in _INFRA_EXTENSIONS


# ---- Individual stage functions ----


def stage_filter_files(ctx: PipelineContext) -> None:
    """Stage 1: Walk repo and select source files (excluding tests)."""
    ctx.filter_result = filter_files(ctx.repo_path)
    logger.info(
        "  %d files selected, %d skipped",
        len(ctx.filter_result.selected_files),
        ctx.filter_result.skipped_count,
    )

    if not ctx.filter_result.selected_files:
        ctx.error = "No source files found"
        return

    # Keep all paths (incl. tests) for test-coverage stage
    ctx.all_file_paths_list = [f[0] for f in ctx.filter_result.selected_files]

    # Exclude test files and infra/config files from the main analysis paths
    source_only = [
        f[0]
        for f in ctx.filter_result.selected_files
        if not _is_test_file(PurePosixPath(f[0]))
        and not _is_infra_file(PurePosixPath(f[0]))
    ]
    ctx.file_paths = set(source_only)
    ctx.file_paths_list = source_only

    if not source_only:
        ctx.error = "No source files found"
        return

    logger.info(
        "  %d code files, %d test + %d infra excluded",
        len(source_only),
        sum(1 for f in ctx.all_file_paths_list if _is_test_file(PurePosixPath(f))),
        sum(
            1
            for f in ctx.all_file_paths_list
            if not _is_test_file(PurePosixPath(f)) and _is_infra_file(PurePosixPath(f))
        ),
    )


def stage_create_manager(ctx: PipelineContext) -> None:
    """Stage 2: Create AnalysisManager for per-file score accumulation."""
    logger.info("  Creating AnalysisManager for %d files", len(ctx.file_paths))
    ctx.manager = AnalysisManager(ctx.file_paths, repo_path=ctx.repo_path)

    # Classify file roles for all paths (must happen after manager creation)
    for path in ctx.all_file_paths_list:
        role = classify_file_role(path)
        ctx.manager.add_metadata(path, "file_role", role)


def stage_git_density(ctx: PipelineContext) -> None:
    """Stage 3: Git density, author diversity, co-change."""
    ctx.density_result = calculate_density(
        ctx.repo_path,
        file_filter=ctx.file_paths,
        normalize=True,
        manager=ctx.manager,
    )
    ctx.enriched_commits = ctx.density_result.enriched_commits
    logger.info("  %d files with density scores", len(ctx.density_result.files))

    # Compute co-change clusters from the pairwise counts
    ctx.cochange_clusters = compute_cochange_clusters(
        ctx.density_result.cochange_counts
    )
    logger.info("  %d co-change clusters detected", len(ctx.cochange_clusters))


def stage_contributor_attribution(ctx: PipelineContext) -> None:
    """Stage 3b: Contributor attribution enrichment."""
    analyze_contributor_attribution(ctx)


def stage_import_graph(ctx: PipelineContext) -> None:
    """Stage 4: Import graph indegree analysis."""
    ctx.indegree_map = analyze_import_graph(
        ctx.repo_path,
        ctx.file_paths_list,
        ctx.manager,
    )


def stage_code_metrics(ctx: PipelineContext) -> None:
    """Stage 5: Code metrics analysis (+ per-file comment density)."""
    ctx.metrics = analyze_code_metrics(
        ctx.repo_path,
        file_paths=ctx.file_paths_list,
        manager=ctx.manager,
    )
    logger.info(
        "  control_flow=%.2f, definitions=%.2f, comments=%.2f",
        ctx.metrics.control_flow_density,
        ctx.metrics.definition_density,
        ctx.metrics.comment_ratio,
    )


def stage_token_metrics(ctx: PipelineContext) -> None:
    """Stage: Token-based metrics on ALL repo files.

    Uses ``ctx.tm_all_files`` (broad walk with SKIP_DIRECTORIES + .egg-info)
    so that ``overall`` aggregation covers the full repo.
    Non-filtered files store metadata via ``manager._extra_metadata``.
    """
    all_files = ctx.tm_all_files
    logger.info(
        "  Token metrics: %d files (broad walk) vs %d filtered",
        len(all_files),
        len(ctx.file_paths),
    )
    ctx.report_progress(0.0, f"Cyclomatic complexity ({len(all_files)} files)")
    analyze_cyclomatic(all_files, ctx.manager)
    ctx.report_progress(0.33, f"Operands/operators ({len(all_files)} files)")
    analyze_operands_operators(all_files, ctx.manager)
    ctx.report_progress(0.66, f"Fanout analysis ({len(all_files)} files)")
    analyze_fanout(all_files, ctx.manager)


def stage_derived_metrics(ctx: PipelineContext) -> None:
    """Stage: Derived metrics on ALL repo files (halstead, MI, tiobe, pylint)."""
    all_files = ctx.tm_all_files
    logger.info("  Derived metrics: %d files", len(all_files))
    ctx.report_progress(0.0, f"Halstead metrics ({len(all_files)} files)")
    analyze_halstead(all_files, ctx.manager)
    ctx.report_progress(0.33, f"Maintainability index ({len(all_files)} files)")
    analyze_maintainability(all_files, ctx.manager)
    ctx.report_progress(0.66, f"TIOBE scoring ({len(all_files)} files)")
    analyze_tiobe(all_files, ctx.manager)


def stage_test_coverage(ctx: PipelineContext) -> None:
    """Stage 6: Test coverage association (uses all files incl. tests)."""
    ctx.test_map = analyze_test_coverage(
        ctx.repo_path,
        ctx.all_file_paths_list,
        ctx.manager,
    )


def stage_churn_risk(ctx: PipelineContext) -> None:
    """Stage: Churn risk scoring (density * lack of protective factors)."""
    analyze_churn_risk(ctx)


def stage_composite_scores(ctx: PipelineContext) -> None:
    """Stage 7: Compute composite scores from accumulated weights."""
    if ctx.manager is None:
        return
    ctx.manager.compute_composite_scores()
    ctx.top_files = ctx.manager.top_files()


def stage_lm_code_value(ctx: PipelineContext) -> None:
    """Stage: LM-derived code value assessment (uniqueness + difficulty + quality)."""
    if ctx.filter_result is None:
        return

    interest = _interest_paths(ctx)

    source_files = [
        f
        for f in ctx.filter_result.selected_files
        if f[0] in interest and not _is_test_file(PurePosixPath(f[0]))
    ]

    if not source_files:
        return

    chunk_budget = 6000
    if ctx.config is not None:
        chunk_budget = getattr(ctx.config, "chunk_token_budget", 6000)

    built = build_context(
        repo_path=ctx.repo_path,
        selected_files=source_files,
        chunk_token_budget=chunk_budget,
    )

    if not built.chunks:
        return

    # Concatenate all chunks into a single context for one LM call
    combined_context = "\n\n".join(c.context_string for c in built.chunks)

    ctx.report_progress(0.0, "Running LM code value assessment")
    response = SLMAgent.query(
        prompt=SLMAgentQueries.LM_CODE_VALUE,
        files=[combined_context],
        config=ctx.config,
    )

    if response.error is None and isinstance(response, LmCodeValueResponse):
        ctx.lm_code_value = response
        logger.info(
            "  LM code value: uniqueness=%.2f, difficulty=%.2f, quality=%.2f",
            response.lm_uniqueness,
            response.lm_complexity,
            response.lm_quality,
        )


def _interest_paths(ctx: PipelineContext) -> set[str]:
    """Return file paths that exceed the statistical interest threshold.

    Threshold is mean + 0.5*stddev of composite scores.  Falls back to
    all source file paths when composite scores are unavailable.
    """
    if not ctx.top_files:
        return ctx.file_paths

    scores = [fs.composite_score for fs in ctx.top_files]
    n = len(scores)
    mean = sum(scores) / n
    variance = sum((s - mean) ** 2 for s in scores) / n
    stddev = variance**0.5
    threshold = mean + 0.5 * stddev

    qualified = {fs.path for fs in ctx.top_files if fs.composite_score >= threshold}

    logger.info(
        "  Interest gate: threshold=%.4f (mean=%.4f, std=%.4f), " "%d/%d files qualify",
        threshold,
        mean,
        stddev,
        len(qualified),
        n,
    )
    return qualified


def stage_file_descriptions(ctx: PipelineContext) -> None:
    """Stage 8: SLM per-file descriptions for high-interest source files."""
    if ctx.filter_result is None:
        return

    # Only describe files above the statistical interest threshold
    interest = _interest_paths(ctx)

    # Also skip trivial files
    _TRIVIAL_NAMES = {"__init__", "__main__", "conftest", "setup", "py.typed"}
    _MIN_EST_TOKENS = 10  # minimum estimated tokens (file_size // 4)

    source_files = [
        f
        for f in ctx.filter_result.selected_files
        if f[0] in interest
        and not _is_test_file(PurePosixPath(f[0]))
        and PurePosixPath(f[0]).stem not in _TRIVIAL_NAMES
        and f[1] >= _MIN_EST_TOKENS
    ]

    if not source_files:
        return

    chunk_budget = 6000
    if ctx.config is not None:
        chunk_budget = getattr(ctx.config, "chunk_token_budget", 6000)

    built = build_context(
        repo_path=ctx.repo_path,
        selected_files=source_files,
        chunk_token_budget=chunk_budget,
    )

    logger.info(
        "  Built %d chunks (%d files, %d tokens)",
        len(built.chunks),
        built.files_included,
        built.total_tokens,
    )

    if not built.chunks:
        return

    # Query SLM for per-file descriptions on each chunk (parallel)
    _SLM_WORKERS = min(4, len(built.chunks))
    total_chunks = len(built.chunks)

    def _query_chunk(chunk):
        return SLMAgent.query(
            prompt=SLMAgentQueries.PER_FILE_VALUE,
            files=[chunk.context_string],
            config=ctx.config,
        )

    done_count = 0
    with ThreadPoolExecutor(max_workers=_SLM_WORKERS) as pool:
        futures = {pool.submit(_query_chunk, c): c for c in built.chunks}
        for future in as_completed(futures):
            try:
                per_file_response = future.result()
            except Exception as exc:
                logger.warning("  Per-file SLM chunk failed: %s", exc)
                continue
            done_count += 1
            ctx.report_progress(
                done_count / (total_chunks + 1),  # +1 reserves room for synthesis
                f"File descriptions: chunk {done_count}/{total_chunks} complete",
            )
            if per_file_response.error is None and isinstance(
                per_file_response, PerFileValueResponse
            ):
                for item in per_file_response.files:
                    ctx.per_file_values[item.path] = {
                        "slm_description": item.description,
                        "slm_value_score": item.value_score,
                        "slm_rationale": item.rationale,
                    }

    logger.info("  Per-file SLM values: %d files scored", len(ctx.per_file_values))

    # Synthesize program-level understanding from all per-file descriptions
    if ctx.per_file_values:
        summaries = []
        for path, data in ctx.per_file_values.items():
            desc = data.get("slm_description", "")
            score = data.get("slm_value_score", 0.0)
            rationale = data.get("slm_rationale", "")
            summaries.append(
                f"- {path} (value={score:.2f}): {desc}\n  Rationale: {rationale}"
            )

        ctx.report_progress(
            total_chunks / (total_chunks + 1),
            "Synthesizing program-level description",
        )
        synthesis_response = SLMAgent.query(
            prompt=SLMAgentQueries.PROGRAM_VALUE_SYNTHESIS,
            files=summaries,
            config=ctx.config,
        )
        if synthesis_response.error is None and isinstance(
            synthesis_response, ProgramValueSynthesisResponse
        ):
            ctx.program_synthesis = {
                "program_description": synthesis_response.program_description,
                "program_value_score": synthesis_response.value_score,
                "program_rationale": synthesis_response.rationale,
                "program_notes": synthesis_response.notes,
            }
            logger.info(
                "  Program synthesis: score=%.2f | %s",
                synthesis_response.value_score,
                synthesis_response.program_description[:100],
            )


def stage_slm_post_filter(ctx: PipelineContext) -> None:
    """Stage 9: SLM heuristic post-filter (outlier queries only)."""
    if ctx.metrics is None:
        return

    ctx.report_progress(0.0, "Running outlier assessment")
    post_filter = HeuristicPostFilter(
        highest_git_density_paths=(
            ctx.density_result.files if ctx.density_result else []
        ),
        top_composite_files=ctx.top_files,
        gluemarker_ratio=ctx.metrics.gluemarker_ratio,
        domain_token_density=ctx.metrics.domain_token_density,
        domain_match_density=ctx.metrics.domain_match_density,
        domain_profile=ctx.metrics.domain_profile,
        external_call_ratio=ctx.metrics.external_call_ratio,
        control_flow_density=ctx.metrics.control_flow_density,
        definition_density=ctx.metrics.definition_density,
        comment_ratio=ctx.metrics.comment_ratio,
        duplication_ratio=ctx.metrics.duplication_ratio,
        repo_path=ctx.repo_path,
        auto_run=False,
        skip_per_file=True,
    )
    post_filter.run()

    ctx.code_value_assessment = post_filter.code_value_assessment
    ctx.slm_glue_assessment = post_filter.slm_glue_assessment
    # per_file_values and program_synthesis are set by stage_file_descriptions


def stage_moat_signals(ctx: PipelineContext) -> None:
    """AI Moats Framework signals (repo-level + per-file weights)."""
    ctx.api_surface = analyze_api_surface(ctx.file_paths_list, manager=ctx.manager)
    ctx.data_accumulation = analyze_data_accumulation(
        ctx.all_file_paths_list, ctx.repo_path, manager=ctx.manager
    )
    ctx.realtime_density = analyze_realtime_patterns(ctx.repo_path)
    ctx.governance_density = analyze_governance_workflow(
        ctx.all_file_paths_list, ctx.repo_path, manager=ctx.manager
    )
    ctx.regulatory_density = analyze_regulatory_tokens(
        ctx.all_file_paths_list, ctx.repo_path, manager=ctx.manager
    )
    logger.info(
        "  Moat signals: api=%.3f accum=%.3f rt=%.3f gov=%.3f reg=%.3f",
        ctx.api_surface,
        ctx.data_accumulation,
        ctx.realtime_density,
        ctx.governance_density,
        ctx.regulatory_density,
    )


# ---- Pipeline compositions ----

FULL_ANALYSIS: list[Stage] = [
    stage_filter_files,  # 1 — walk repo, exclude tests
    stage_create_manager,  # 2
    stage_git_density,  # 3
    stage_contributor_attribution,  # 3b
    stage_import_graph,  # 4
    stage_code_metrics,  # 5
    stage_token_metrics,  # 6 — cyclomatic, operands, operators, LOC
    stage_test_coverage,  # 7 — uses all_file_paths_list
    stage_derived_metrics,  # 8 — halstead, maintainability index
    stage_moat_signals,  # 9 — AI Moats Framework signals
    stage_churn_risk,  # 10 — churn risk (density * lack of protective factors)
    stage_composite_scores,  # 11
    stage_lm_code_value,  # 12 — LM code value (uniqueness + difficulty + quality)
    stage_file_descriptions,  # 13 — SLM per-file descriptions (all source files)
    stage_slm_post_filter,  # 14 — outlier queries only
]

POST_FILTER_ONLY: list[Stage] = [
    stage_filter_files,
    stage_create_manager,
    stage_git_density,
    stage_contributor_attribution,
    stage_code_metrics,
    stage_token_metrics,
    stage_derived_metrics,
    stage_moat_signals,
    stage_churn_risk,
    stage_composite_scores,
    stage_file_descriptions,
    stage_slm_post_filter,
]

STATS_PIPELINE: list[Stage] = [
    stage_filter_files,  # 1 — walk repo, exclude tests
    stage_create_manager,  # 2
    stage_git_density,  # 3
    stage_contributor_attribution,  # 3b
    stage_import_graph,  # 4
    stage_code_metrics,  # 5
    stage_token_metrics,  # 6 — cyclomatic, operands, operators, LOC
    stage_test_coverage,  # 7 — uses all_file_paths_list
    stage_derived_metrics,  # 8 — halstead, maintainability index
    stage_moat_signals,  # 9 — AI Moats Framework signals
    stage_churn_risk,  # 10 — churn risk (density * lack of protective factors)
    stage_composite_scores,  # 11
]
