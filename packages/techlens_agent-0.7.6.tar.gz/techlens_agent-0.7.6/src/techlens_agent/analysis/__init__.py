"""TechLens code analysis module.

Provides comprehensive analysis of software repositories:
- File filtering and code metrics
- Git density analysis
- SLM-based code value assessment
- Heuristic post-filtering
"""

from .analyze import analyze, AnalysisResult
from .slm_after_filter import run_slm_after_filter

__all__ = ["analyze", "AnalysisResult", "run_slm_after_filter"]
