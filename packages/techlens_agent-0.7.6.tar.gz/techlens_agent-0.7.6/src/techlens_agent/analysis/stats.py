"""Repository statistics extracted from the analysis pipeline.

Runs the deterministic stages and reshapes PipelineContext into a flat,
stats-oriented model suitable for JSON export.

Output structure:
- ``files`` is a dict keyed by relative path
- ``overall`` aggregates per-file metrics (sums / global calc)
- ``stats`` provides mean/median/min/max/sd per metric

SLM fields (e.g. slm_description, program_value_score) are populated when an
SlmConfig is provided; otherwise they default to None and are excluded via
``exclude_none=True``.
"""

from __future__ import annotations

import logging
import math
import os
import statistics
from collections import Counter
from pathlib import PurePosixPath
from typing import Any, Optional

from pydantic import BaseModel, Field

from .pipeline import PipelineContext, run_pipeline
from .signals.test_coverage_analyzer import _is_test_file
from .slm_config import SlmConfig
from .stages import STATS_PIPELINE
from .stats_derived import bus_factor_files, compute_composite, engineering_score

logger = logging.getLogger(__name__)

# Role sets used to scope repo-level stats to meaningful code.
BUSINESS_LOGIC_ROLES = frozenset(
    {
        "source",
        "model",
        "service",
        "controller",
        "repository",
        "middleware",
        "util",
        "view",
    }
)
TESTABLE_ROLES = frozenset(
    {"source", "model", "service", "controller", "repository", "middleware", "util"}
)

_CODE_EXTENSIONS = frozenset(
    {
        ".py",
        ".rb",
        ".js",
        ".jsx",
        ".ts",
        ".tsx",
        ".mjs",
        ".cjs",
        ".go",
        ".java",
        ".kt",
        ".cs",
        ".rs",
        ".swift",
        ".m",
        ".mm",
        ".c",
        ".cpp",
        ".cc",
        ".h",
        ".hpp",
        ".php",
        ".ex",
        ".exs",
        ".scala",
        ".clj",
        ".dart",
        ".lua",
        ".pl",
        ".pm",
        ".r",
    }
)


# ---------------------------------------------------------------------------
# Per-file metric keys
# ---------------------------------------------------------------------------

# Keys that are summed for the ``overall`` dict and included in ``stats``.
_TM_METRIC_KEYS: list[str] = [
    "loc",
    "code_loc",
    "documentation_loc",
    "empty_loc",
    "string_loc",
    "comment_ratio",
    "cyclomatic_complexity",
    "operands_sum",
    "operands_uniq",
    "operators_sum",
    "operators_uniq",
    "halstead_volume",
    "halstead_difficulty",
    "halstead_effort",
    "halstead_timerequired",
    "halstead_bugprop",
    "maintainability_index",
    "fanout_internal",
    "fanout_external",
    "pylint",
    "tiobe",
    "tiobe_complexity",
    "tiobe_fanout",
    "tiobe_compiler",
    "tiobe_coverage",
    "tiobe_duplication",
    "tiobe_functional",
    "tiobe_security",
    "tiobe_standard",
]

# Metadata key → output key mapping (where they differ).
_META_TO_OUTPUT: dict[str, str] = {
    "tm_loc": "loc",
    "tm_code_loc": "code_loc",
    "tm_documentation_loc": "documentation_loc",
    "tm_empty_loc": "empty_loc",
    "tm_string_loc": "string_loc",
    "tm_comment_ratio": "comment_ratio",
    "operands_unique": "operands_uniq",
    "operators_unique": "operators_uniq",
}


def _file_tm_metrics(manager, path: str) -> dict[str, Any]:
    """Extract per-file metrics dict from manager metadata."""
    out: dict[str, Any] = {}
    for meta_key, out_key in _META_TO_OUTPUT.items():
        out[out_key] = manager.get_metadata(path, meta_key, 0)
    # Direct-name keys (meta key == output key)
    direct = [
        "cyclomatic_complexity",
        "operands_sum",
        "operators_sum",
        "halstead_volume",
        "halstead_difficulty",
        "halstead_effort",
        "halstead_timerequired",
        "halstead_bugprop",
        "maintainability_index",
        "fanout_internal",
        "fanout_external",
        "pylint",
        "tiobe",
        "tiobe_complexity",
        "tiobe_fanout",
        "tiobe_compiler",
        "tiobe_coverage",
        "tiobe_duplication",
        "tiobe_functional",
        "tiobe_security",
        "tiobe_standard",
    ]
    for key in direct:
        out[key] = manager.get_metadata(path, key, 0)
    # lang is a list
    out["lang"] = manager.get_metadata(path, "lang", [])
    # file role classification
    out["file_role"] = manager.get_metadata(path, "file_role", "source")
    return out


# ---------------------------------------------------------------------------
# Overall + stats aggregation
# ---------------------------------------------------------------------------


def _compute_overall(per_file_dicts: list[dict[str, Any]]) -> dict[str, Any]:
    """Compute ``overall`` aggregation from per-file dicts.

    Raw metrics are summed across files.  Derived metrics (halstead, tiobe,
    pylint, MI) are then recalculated from the global sums.
    """
    from .formulas import (
        calc_halstead,
        calc_maintainability_index,
        calc_pylint,
        calc_tiobe,
    )

    # 1. Sum raw (token-based) metrics
    _RAW_KEYS = [
        "loc",
        "code_loc",
        "documentation_loc",
        "empty_loc",
        "string_loc",
        "cyclomatic_complexity",
        "operands_sum",
        "operands_uniq",
        "operators_sum",
        "operators_uniq",
        "fanout_internal",
        "fanout_external",
    ]
    overall: dict[str, Any] = {k: 0 for k in _RAW_KEYS}
    total_loc = 0
    weighted_comment_sum = 0.0
    for fd in per_file_dicts:
        for k in _RAW_KEYS:
            overall[k] += fd.get(k, 0)
        fl = fd.get("loc", 0)
        total_loc += fl
        weighted_comment_sum += fd.get("comment_ratio", 0) * fl

    # comment_ratio: LOC-weighted average (matches global character-ratio approach)
    overall["comment_ratio"] = (
        weighted_comment_sum / total_loc if total_loc > 0 else 0.0
    )

    # 2. Run calcs on global sums
    calc_halstead(overall)
    calc_maintainability_index(overall)
    calc_tiobe(overall)
    calc_pylint(overall)

    return overall


def _compute_descriptive_stats(
    per_file_dicts: list[dict[str, Any]],
) -> dict[str, dict[str, float]]:
    """Compute mean/median/min/max/sd for each metric across files."""
    result: dict[str, dict[str, float]] = {
        "mean": {},
        "median": {},
        "min": {},
        "max": {},
        "sd": {},
    }
    if not per_file_dicts:
        return result

    for key in _TM_METRIC_KEYS:
        values = [fd.get(key, 0) for fd in per_file_dicts]
        n = len(values)
        mean_val = sum(values) / n
        result["mean"][key] = mean_val
        result["median"][key] = statistics.median(values)
        result["min"][key] = min(values)
        result["max"][key] = max(values)
        result["sd"][key] = statistics.pstdev(values) if n > 1 else 0.0
    return result


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class RepoStats(BaseModel):
    """Complete repository statistics."""

    # ---- Overview ----
    total_files_scanned: int = 0
    source_files_count: int = 0  # files with file_role in BUSINESS_LOGIC_ROLES
    test_files_count: int = 0
    skipped_files_count: int = 0
    estimated_total_tokens: int = 0
    total_lines: int = 0
    code_lines: int = 0
    languages: dict[str, int] = Field(default_factory=dict)

    # ---- Code quality ----
    control_flow_density: float = 0.0
    definition_density: float = 0.0
    comment_ratio: float = 0.0
    duplication_ratio: float = 0.0

    # ---- Glue signals ----
    gluemarker_ratio: float = 0.0
    domain_token_density: float = 0.0
    domain_match_density: float = 0.0
    domain_profile: str = ""
    external_call_ratio: float = 0.0

    # ---- Git activity ----
    high_density_file_count: int = 0
    outlier_file_count: int = 0

    # ---- Architecture ----
    import_graph_nodes: int = 0
    max_indegree: int = 0
    test_covered_file_count: int = 0  # files in TESTABLE_ROLES that have tests
    test_coverage_ratio: float = 0.0  # test_covered / files in TESTABLE_ROLES

    # ---- Composite ----
    composite_score_mean: float = 0.0
    composite_score_stddev: float = 0.0

    # ---- Static analysis ----
    cyclomatic_complexity_total: int = 0
    maintainability_index_mean: float = 0.0
    halstead_volume_total: float = 0.0
    halstead_bugprop_total: float = 0.0

    # ---- File roles ----
    role_distribution: dict[str, int] = Field(default_factory=dict)

    # ---- Derived ----
    engineering_score: float = 0.0
    moat_score: float = 0.0
    avg_file_size_tokens: float = 0.0
    bus_factor_files: int = 0  # single-author files in BUSINESS_LOGIC_ROLES only

    # ---- Contributor attribution ----
    contributor_summary: Optional[dict] = None

    # ---- Co-change clusters ----
    cochange_clusters: list[list[str]] = Field(default_factory=list)

    # ---- AI Moats Framework signals ----
    data_accumulation_pattern: Optional[float] = None
    realtime_pattern_density: Optional[float] = None
    governance_workflow_density: Optional[float] = None
    api_surface_ratio: Optional[float] = (
        None  # api files in BUSINESS_LOGIC_ROLES / source_files_count
    )
    regulatory_token_density: Optional[float] = None

    # ---- SLM program-level (None when not computed) ----
    program_description: Optional[str] = None
    program_value_score: Optional[float] = None
    program_notes: Optional[list[str]] = None
    code_value_uniqueness_score: Optional[float] = None
    glue_originality_ratio: Optional[float] = None
    lm_code_value_score: Optional[float] = None
    lm_uniqueness: Optional[float] = None
    lm_complexity: Optional[float] = None
    lm_quality: Optional[float] = None

    # ---- Per-file / overall / stats ----
    files: dict[str, dict[str, Any]] = Field(default_factory=dict)
    overall: dict[str, Any] = Field(default_factory=dict)
    stats: dict[str, dict[str, float]] = Field(default_factory=dict)

    # ---- Metadata ----
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------


def _count_languages(selected_files: list[tuple[str, int]]) -> dict[str, int]:
    """Count files per extension."""
    ext_counter: Counter[str] = Counter()
    for path, _ in selected_files:
        ext = PurePosixPath(path).suffix.lower()
        if ext:
            ext_counter[ext] += 1
    return dict(ext_counter.most_common())


def _build_files_dict(ctx: PipelineContext) -> dict[str, dict[str, Any]]:
    """Build the files dict keyed by path.

    Analyzed files get full metrics + pipeline fields.
    Non-analyzed files (tests, infra) get ``skipped: true``.
    """
    # Index git density by path
    density_by_path: dict[str, Any] = {}
    if ctx.density_result:
        for fd in ctx.density_result.files:
            density_by_path[fd.path] = fd

    # Index composite scores by path
    score_by_path: dict[str, Any] = {}
    for fs in ctx.top_files:
        score_by_path[fs.path] = fs

    # Token estimates from filter result
    tokens_by_path: dict[str, int] = {}
    if ctx.filter_result:
        for path, tokens in ctx.filter_result.selected_files:
            tokens_by_path[path] = tokens

    # SLM per-file values
    slm_by_path = ctx.per_file_values

    result: dict[str, dict[str, Any]] = {}

    # All files: union of filter result, scored files, and token-metrics files
    all_paths = set(ctx.all_file_paths_list) if ctx.all_file_paths_list else set()
    all_paths |= ctx.file_paths
    # Include broad-walk files (token metrics ran on these)
    if ctx._tm_all_files:
        all_paths |= set(ctx._tm_all_files)

    for path in sorted(all_paths):
        # Use ./ prefix for backwards compatibility
        key = f"./{path}" if not path.startswith("./") else path

        # --- Per-file metric fields (available for ALL files) ---
        has_tm = False
        if ctx.manager is not None:
            entry = _file_tm_metrics(ctx.manager, path)
            # Check if token metrics actually ran on this file
            has_tm = entry.get("loc", 0) > 0 or entry.get("operands_sum", 0) > 0
        else:
            entry = {}

        if path not in ctx.file_paths and not has_tm:
            # File with no data at all (not filtered in, no token metrics)
            result[key] = {"skipped": True}
            continue

        if path not in ctx.file_paths:
            # Has token metrics but not in the scored set — mark as not scored
            entry["skipped_scoring"] = True

        # --- Pipeline-specific fields (only for scored files) ---
        fd = density_by_path.get(path)
        fs = score_by_path.get(path)
        slm = slm_by_path.get(path)

        entry["estimated_tokens"] = tokens_by_path.get(path, 0)
        entry["composite_score"] = round(fs.composite_score, 4) if fs else 0.0
        entry["weights"] = {k: round(v, 4) for k, v in fs.weights.items()} if fs else {}

        # Git
        entry["additions"] = fd.additions if fd else 0
        entry["deletions"] = fd.deletions if fd else 0
        entry["commits"] = fd.commits if fd else 0
        entry["authors"] = fd.authors if fd else 0
        entry["density_score"] = round(fd.density_score, 4) if fd else 0.0
        entry["main_authors_ratio"] = fd.main_authors_ratio if fd else []

        # Architecture
        entry["indegree"] = ctx.indegree_map.get(path, 0)
        entry["has_tests"] = path in ctx.test_map

        # SLM
        if slm:
            entry["slm_description"] = slm.get("slm_description")
            entry["slm_value_score"] = slm.get("slm_value_score")

        result[key] = entry

    return result


def _compute_composite_stats(
    top_files: list,
) -> tuple[float, float]:
    """Return (mean, stddev) of composite scores."""
    if not top_files:
        return 0.0, 0.0
    scores = [fs.composite_score for fs in top_files]
    n = len(scores)
    mean = sum(scores) / n
    variance = sum((s - mean) ** 2 for s in scores) / n
    return round(mean, 4), round(variance**0.5, 4)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def extract_stats(
    repo_path: str,
    config: Optional[SlmConfig] = None,
) -> RepoStats:
    """Run the deterministic pipeline stages and return structured stats.

    SLM-dependent fields are left as None (and excluded from JSON
    serialisation via ``exclude_none=True``).
    """
    if config is None:
        config = SlmConfig()

    logger.info("Extracting stats for %s", repo_path)

    ctx = PipelineContext(
        repo_path=os.path.abspath(repo_path),
        config=config,
    )
    run_pipeline(STATS_PIPELINE, ctx)

    if ctx.error:
        logger.error("Stats extraction failed: %s", ctx.error)
        return RepoStats(error=ctx.error)

    # ---- Role lookup helper ----
    def _file_role(path: str) -> str:
        if ctx.manager is not None:
            return ctx.manager.get_metadata(path, "file_role", "source")
        return "source"

    # ---- Overview ----
    # source_files_count reflects meaningful code (business logic roles only)
    source_count = sum(
        1 for p in ctx.file_paths if _file_role(p) in BUSINESS_LOGIC_ROLES
    )
    test_count = sum(
        1 for f in ctx.all_file_paths_list if _is_test_file(PurePosixPath(f))
    )
    total_tokens = ctx.filter_result.total_estimated_tokens if ctx.filter_result else 0

    # ---- Git density ----
    high_density = 0
    if ctx.density_result:
        high_density = sum(1 for f in ctx.density_result.files if f.density_score > 0.5)

    # ---- Outlier count ----
    outlier_count = 0
    if ctx.density_result:
        from .signals.heuristic_post_filter import compute_git_density_outliers

        outlier_count = len(compute_git_density_outliers(ctx.density_result.files))

    # ---- Composite stats ----
    comp_mean, comp_std = _compute_composite_stats(ctx.top_files)

    # ---- Test coverage (scoped to TESTABLE_ROLES + code extensions) ----
    testable_paths = {
        p
        for p in ctx.file_paths
        if _file_role(p) in TESTABLE_ROLES
        and PurePosixPath(p).suffix.lower() in _CODE_EXTENSIONS
    }
    test_covered = sum(1 for p in testable_paths if p in ctx.test_map)
    test_ratio = round(test_covered / len(testable_paths), 4) if testable_paths else 0.0

    # ---- API surface ratio (scoped to controllers + services) ----
    if ctx.manager is not None and source_count:
        api_denominator_roles = frozenset({"controller", "service"})
        api_denominator = sum(
            1 for p in ctx.file_paths if _file_role(p) in api_denominator_roles
        )
        api_bl_count = sum(
            1
            for p in ctx.file_paths
            if _file_role(p) in api_denominator_roles
            and ctx.manager.get_weight(p, "api_surface") > 0
        )
        api_surface_ratio: float | None = (
            round(api_bl_count / api_denominator, 4) if api_denominator else 0.0
        )
    else:
        api_surface_ratio = ctx.api_surface

    # ---- Derived ----
    m = ctx.metrics
    eng = 0.0
    orig = 0.0
    if m:
        eng = engineering_score(
            control_flow_density=m.control_flow_density,
            definition_density=m.definition_density,
            comment_ratio=m.comment_ratio,
            duplication_ratio=m.duplication_ratio,
            test_coverage_ratio=test_ratio,
        )
        orig = compute_composite(
            "moat_score",
            {
                "domain_match_density": m.domain_match_density,
                "gluemarker_ratio": m.gluemarker_ratio,
                "external_call_ratio": m.external_call_ratio,
                "data_accumulation_pattern": ctx.data_accumulation,
                "realtime_pattern_density": ctx.realtime_density,
                "governance_workflow_density": ctx.governance_density,
                "api_surface_ratio": api_surface_ratio,
                "regulatory_token_density": ctx.regulatory_density,
            },
        )

    # Bus factor (scoped to models + controllers)
    bus_factor_roles = frozenset({"model", "controller"})
    author_counts: list[int] = []
    if ctx.density_result:
        author_counts = [
            f.authors
            for f in ctx.density_result.files
            if _file_role(f.path) in bus_factor_roles
        ]
    bf = bus_factor_files(author_counts)

    avg_tokens = round(total_tokens / source_count, 1) if source_count else 0.0

    logger.info(
        "Stats summary: %d source files, %d test files, ~%d tokens, "
        "%d high-density, %d outliers, bus_factor=%d",
        source_count,
        test_count,
        total_tokens,
        high_density,
        outlier_count,
        bf,
    )

    # ---- Static analysis aggregates ----
    cc_total = 0
    mi_values: list[float] = []
    hv_total = 0.0
    hb_total = 0.0
    if ctx.manager is not None:
        for path in ctx.file_paths:
            cc_total += ctx.manager.get_metadata(path, "cyclomatic_complexity", 0)
            mi = ctx.manager.get_metadata(path, "maintainability_index", 0)
            if mi > 0:
                mi_values.append(mi)
            hv_total += ctx.manager.get_metadata(path, "halstead_volume", 0)
            hb_total += ctx.manager.get_metadata(path, "halstead_bugprop", 0)
    mi_mean = round(sum(mi_values) / len(mi_values), 2) if mi_values else 0.0

    # ---- Per-file (dict keyed by path) ----
    files_dict = _build_files_dict(ctx)

    # ---- Role distribution ----
    role_counter: Counter[str] = Counter()
    for v in files_dict.values():
        if not v.get("skipped"):
            role_counter[v.get("file_role", "source")] += 1
    role_dist = dict(role_counter.most_common())

    # ---- overall + stats ----
    analyzed_dicts = [v for v in files_dict.values() if not v.get("skipped")]
    overall = _compute_overall(analyzed_dicts)
    desc_stats = _compute_descriptive_stats(analyzed_dicts)

    return RepoStats(
        # Overview
        total_files_scanned=(
            ctx.filter_result.total_scanned if ctx.filter_result else 0
        ),
        source_files_count=source_count,
        test_files_count=test_count,
        skipped_files_count=(
            ctx.filter_result.skipped_count if ctx.filter_result else 0
        ),
        estimated_total_tokens=total_tokens,
        total_lines=m.total_lines if m else 0,
        code_lines=m.code_lines if m else 0,
        languages=(
            _count_languages(
                [
                    (p, t)
                    for p, t in ctx.filter_result.selected_files
                    if p in ctx.file_paths
                ]
            )
            if ctx.filter_result
            else {}
        ),
        # File roles
        role_distribution=role_dist,
        # Code quality
        control_flow_density=round(m.control_flow_density, 4) if m else 0.0,
        definition_density=round(m.definition_density, 4) if m else 0.0,
        comment_ratio=round(m.comment_ratio, 4) if m else 0.0,
        duplication_ratio=round(m.duplication_ratio, 4) if m else 0.0,
        # Glue signals
        gluemarker_ratio=round(m.gluemarker_ratio, 4) if m else 0.0,
        domain_token_density=round(m.domain_token_density, 4) if m else 0.0,
        domain_match_density=round(m.domain_match_density, 4) if m else 0.0,
        domain_profile=m.domain_profile if m else "",
        external_call_ratio=round(m.external_call_ratio, 4) if m else 0.0,
        # Git activity
        high_density_file_count=high_density,
        outlier_file_count=outlier_count,
        # Architecture
        import_graph_nodes=len(ctx.indegree_map),
        max_indegree=max(ctx.indegree_map.values(), default=0),
        test_covered_file_count=test_covered,
        test_coverage_ratio=test_ratio,
        # Composite
        composite_score_mean=comp_mean,
        composite_score_stddev=comp_std,
        # Static analysis
        cyclomatic_complexity_total=cc_total,
        maintainability_index_mean=mi_mean,
        halstead_volume_total=round(hv_total, 2),
        halstead_bugprop_total=round(hb_total, 4),
        # Derived
        engineering_score=eng,
        moat_score=orig,
        avg_file_size_tokens=avg_tokens,
        bus_factor_files=bf,
        # Contributor attribution
        contributor_summary=ctx.contributor_summary,
        # Co-change clusters
        cochange_clusters=ctx.cochange_clusters,
        # AI Moats Framework signals
        data_accumulation_pattern=ctx.data_accumulation,
        realtime_pattern_density=ctx.realtime_density,
        governance_workflow_density=ctx.governance_density,
        api_surface_ratio=api_surface_ratio,
        regulatory_token_density=ctx.regulatory_density,
        # Per-file / overall / stats
        files=files_dict,
        overall=overall,
        stats=desc_stats,
    )
