import defusedxml.ElementTree as ET

from techlens_agent.dependencies.walkers.classes import Walker, Entry


class MavenWalker(Walker):
    # pkg:maven/springframework/spring@1.2.6
    # mvn license:aggregate-add-third-party
    # mvn dependency:analyze
    # mvn dependency-check:check
    # mvn org.sonatype.ossindex.maven:ossindex-maven-plugin:audit -f pom.xml
    # <project>
    # ...
    # <properties>
    # <mavenVersion>3.0</mavenVersion>
    # </properties>

    # <dependencies>
    # <dependency>
    #     <groupId>org.apache.maven</groupId>
    #     <artifactId>maven-artifact</artifactId>
    #     <version>${mavenVersion}</version>
    # </dependency>
    # <dependency>
    #     <groupId>org.apache.maven</groupId>
    #     <artifactId>maven-core</artifactId>
    #     <version>${mavenVersion}</version>
    # </dependency>
    # </dependencies>
    # ...
    # </project>

    def parse(self, file: str, expand=False):
        try:
            tree = ET.parse(file)
        except (ET.ParseError, OSError, UnicodeDecodeError) as e:
            self.log(msg=f"Failed to parse {file}: {e}", tag="Maven", display=True)
            return
        root = tree.getroot()
        ns = ""
        if root.tag.startswith("{"):
            ns = root.tag.split("}")[0] + "}"
        dependencies = tree.findall(f"{ns}dependencies/{ns}dependency")
        for d in dependencies:
            try:
                groupId = d.find(f"{ns}groupId")
                artifact = d.find(f"{ns}artifactId")
                version = d.find(f"{ns}version")
                g = groupId.text if groupId is not None and groupId.text else None
                a = artifact.text if artifact is not None and artifact.text else None
                if not g or not a:
                    self.log(
                        msg=f"Skipping dependency with missing groupId or artifactId in {file}",
                        tag="Maven",
                    )
                    continue
                v = version.text if version is not None and version.text else "unknown"
                n = g + "/" + a
                e = Entry(name=n, source="maven", specifier="==" + v)
                self.entries.append(e)
            except (AttributeError, TypeError) as e:
                self.log(
                    msg=f"Skipping malformed dependency in {file}: {e}", tag="Maven"
                )

    def expand(self, file):
        raise Exception("No expansion for this Walker")
