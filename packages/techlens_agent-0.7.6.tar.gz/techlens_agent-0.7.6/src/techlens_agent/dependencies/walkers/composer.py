import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import List

from techlens_agent.dependencies.walkers.classes import (
    Walker,
    Entry,
    discover_manifests,
)


class ComposerWalker(Walker):
    def initialize(self, root_path: str = "./"):
        root_path = str(Path(root_path).absolute())
        self.dependency_tree: dict = {}
        self.install_points = discover_manifests(Path(root_path), self.manifest_files)
        composer_bin = shutil.which("composer")
        if not composer_bin:
            self.log(tag="ERROR", msg="composer executable not found in PATH")
        for p in self.install_points:
            target_dir = Path(p).parent
            try:
                os.chdir(target_dir)
                if composer_bin:
                    try:
                        result = subprocess.run(
                            [
                                composer_bin,
                                "install",
                                "--no-dev",
                                "--no-progress",
                                "--no-scripts",
                                "--no-plugins",
                                "--no-interaction",
                            ],
                            capture_output=True,
                            text=True,
                            timeout=300,
                            check=False,
                        )
                        if result.returncode != 0:
                            self.log(
                                tag="ERROR",
                                msg=f"Error with composer install: {result.stderr}",
                            )
                        else:
                            self.log(tag="", msg=result.stdout, timestamp=False)
                    except Exception as error:
                        self.log(
                            tag="ERROR",
                            msg=f"Error with composer install: {error}",
                        )
                self.walk("./", skip_dirs=False)
            except OSError as error:
                self.log(tag="ERROR", msg=f"Cannot access {target_dir}: {error}")
            finally:
                try:
                    os.chdir(root_path)
                except OSError:
                    pass

        for dep in self.dependency_tree:
            dependency = self.dependency_tree[dep]
            for v in dependency:
                version = dependency[v]
                self.entries.append(version)

    def parse(self, file: str, expand=False):
        if not hasattr(self, "dependency_tree"):
            self.dependency_tree: dict = {}
        try:
            with open(file) as f:
                cjson = json.load(f)
                if "license" in cjson and self.dependency_tree.get(cjson["name"]):
                    for version in self.dependency_tree[cjson["name"]]:
                        self.dependency_tree[cjson["name"]][version].license = cjson[
                            "license"
                        ]
                        if "description" in cjson:
                            self.dependency_tree[cjson["name"]][version].summary = (
                                cjson["description"]
                            )
                if "require" in cjson:
                    for k, v in cjson["require"].items():
                        if self.dependency_tree.get(k):
                            self.dependency_tree[k] = self.dependency_tree[k]
                        else:
                            self.dependency_tree[k] = {}
                        if self.dependency_tree[k].get(v):
                            self.dependency_tree[k][v] = self.dependency_tree[k][v]
                        else:
                            self.dependency_tree[k][v] = Entry(
                                name=k, source="composer", specifier=v
                            )
                self.log(self.dependency_tree)
        except Exception as error:
            self.log(f"error parsing {file}")
            try:
                self.log(json.load(file)["name"])
                self.log(json.load(file)["require"])
            except Exception as ex:
                raise ex
            self.log(error)
