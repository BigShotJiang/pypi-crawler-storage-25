from techlens_agent.dependencies.walkers.classes import Walker, Entry


class GoWalker(Walker):
    def parse(self, file: str, expand=False):
        try:
            with open(file, "r") as f:
                lines = f.readlines()
        except (OSError, UnicodeDecodeError) as err:
            self.log(msg=f"Failed to read {file}: {err}", tag="Go", display=True)
            return
        for line in lines:
            try:
                parts = line.split()
                if len(parts) < 3:
                    continue
                name, version = parts[0], parts[1]
                if version.endswith("go.mod"):
                    version = version.split("/")[0]
                e = Entry(name=name, specifier=version, source="Go")
                self.entries.append(e)
            except (ValueError, IndexError) as err:
                self.log(msg=f"Skipping malformed line in {file}: {err}", tag="Go")
