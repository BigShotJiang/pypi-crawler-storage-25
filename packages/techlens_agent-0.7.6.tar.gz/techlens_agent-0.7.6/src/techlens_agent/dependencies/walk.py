import json
import traceback
from pathlib import Path
from typing import List

import defusedxml

from techlens_agent.dependencies.walkers.composer import ComposerWalker
from techlens_agent.dependencies.walkers.maven import MavenWalker
from techlens_agent.dependencies.walkers.npm import NodeWalker
from techlens_agent.dependencies.walkers.package_lock import PackageWalker
from techlens_agent.dependencies.walkers.gemwalker import GemWalker
from techlens_agent.dependencies.walkers.nuget import NuGetWalker, c_sharp_matches
from techlens_agent.dependencies.walkers.dockerwalker import DockerWalker
from techlens_agent.dependencies.walkers.python import PyWalker
from techlens_agent.dependencies.walkers.go import GoWalker
from techlens_agent.dependencies.walkers.classes import Entry

defusedxml.defuse_stdlib()

# Manifests we support
# should probably move this to a conf

# TODO: Gemfile parse
# Example: https://github.com/mastodon/mastodon/blob/main/Gemfile
ruby_matches = ["Gemfile"]

# TODO: Parse Cargo.toml
# Example: https://github.com/servo/servo/blob/master/components/style/Cargo.toml
rust_matches = ["Cargo.toml"]


def write_file(output_file: str, entries):
    with open(output_file, "w") as outfile:
        dicts = [entry.to_json() for entry in entries]
        outfile.write(json.dumps(dicts, indent=4))


def _run_walker(name, walker_fn, logger):
    try:
        walker_fn()
        return True
    except Exception as e:
        logger(msg=f"{name} walker failed: {e}", tag="ERROR", display=True)
        logger(msg=traceback.format_exc(), tag="", display=False)
        return False


# Finds all manifests we can process in the repo
# and stores their path in memory
def walk(logger, path: str = "./", output_file="./dependencies.json"):
    mavenWalker = MavenWalker(
        manifest_type="xml", manifest_files=["pom.xml"], logger=logger, root_dir=path
    )

    nodeWalker = NodeWalker(
        manifest_type="json",
        manifest_files=["package.json"],
        logger=logger,
        root_dir=path,
    )

    nugetWalker = NuGetWalker(
        manifest_type="xml",
        manifest_files=c_sharp_matches,
        logger=logger,
        root_dir=path,
    )

    py_walker = PyWalker(
        manifest_files=[
            "requirements.txt",
            "requirements-dev.txt",
            "pyproject.toml",
            "poetry.lock",
        ],
        manifest_type="txt",
        logger=logger,
        root_dir=path,
    )
    gem_walker = GemWalker(
        manifest_files=["gemfile", "Gemfile"],
        manifest_type="ruby",
        logger=logger,
        root_dir=path,
    )
    docker_walker = DockerWalker(
        manifest_files=["Dockerfile", "dockerfile", "docker-compose.yml"],
        manifest_type="Dockerfile",
        logger=logger,
        root_dir=path,
    )
    composer_walker = ComposerWalker(
        manifest_files=["composer.json"],
        manifest_type="json",
        logger=logger,
        root_dir=path,
    )
    go_walker = GoWalker(
        manifest_type="sum", manifest_files=["go.sum"], logger=logger, root_dir=path
    )
    path = str(Path(path).absolute())
    entries: List[Entry] = []

    _run_walker("Composer", lambda: composer_walker.initialize(root_path=path), logger)
    entries += composer_walker.entries

    _run_walker("Maven", lambda: mavenWalker.walk(path=path), logger)
    entries += mavenWalker.entries
    logger(msg="Dependency Scan 10%", display=True)
    write_file(output_file=output_file, entries=entries)

    _run_walker("Node", lambda: nodeWalker.initialize(root_path=path), logger)
    logger(msg="Dependency Scan 25%", display=True)
    if nodeWalker.entries:
        entries += nodeWalker.entries
    else:
        packageWalker = PackageWalker(
            manifest_type="json",
            logger=logger,
            root_dir=path,
            manifest_files=["package-lock.json"],
        )
        _run_walker("PackageLock", lambda: packageWalker.walk(path=path), logger)
        entries += packageWalker.entries
    write_file(output_file=output_file, entries=entries)

    _run_walker(
        "NuGet", lambda: (nugetWalker.initialize(), nugetWalker.walk(path=path)), logger
    )
    entries += nugetWalker.entries
    logger(msg="Dependency Scan 40%", display=True)
    write_file(output_file=output_file, entries=entries)

    _run_walker("Python", lambda: py_walker.walk(path=path), logger)
    entries += py_walker.entries
    logger(msg="Dependency Scan 60%", display=True)
    write_file(output_file=output_file, entries=entries)

    _run_walker("Gem", lambda: gem_walker.walk(path=path), logger)
    entries += gem_walker.entries
    logger(msg="Dependency Scan 80%", display=True)
    write_file(output_file=output_file, entries=entries)

    logger(msg="Dependency Scan 95%", display=True)
    _run_walker("Docker", lambda: docker_walker.walk(path=path, expand=False), logger)
    entries += docker_walker.entries
    write_file(output_file=output_file, entries=entries)

    logger(msg="Dependency Scan 100%", display=True)
    _run_walker("Go", lambda: go_walker.walk(path=path), logger)
    entries += go_walker.entries
    write_file(output_file=output_file, entries=entries)
    return output_file
