#!/bin/sh
set -e

# Start Ollama in the background and wait until it's ready
ollama serve &
OLLAMA_TIMEOUT=60
OLLAMA_ELAPSED=0
until ollama list >/dev/null 2>&1; do
    sleep 0.5
    OLLAMA_ELAPSED=$((OLLAMA_ELAPSED + 1))
    if [ "$OLLAMA_ELAPSED" -ge "$((OLLAMA_TIMEOUT * 2))" ]; then
        echo "ERROR: Ollama failed to start within ${OLLAMA_TIMEOUT}s" >&2
        exit 1
    fi
done
echo "Ollama is ready"

# Start gunicorn (SageMaker expects port 8080)
exec gunicorn techlens_agent.serve:app \
    --bind "0.0.0.0:${SAGEMAKER_BIND_TO_PORT:-8080}" \
    --workers 1 \
    --timeout 1800 \
    --access-logfile - \
    --error-logfile -
