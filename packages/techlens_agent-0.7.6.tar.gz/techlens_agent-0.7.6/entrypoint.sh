#!/bin/sh

set -e
# --- Running as ROOT ---
SRC_ROOT="/techlens"
SRC_SSH="${SRC_ROOT}/.ssh"
SRC_AWS="${SRC_ROOT}/.aws"
SRC_AZURE="${SRC_ROOT}/.azure"
SRC_GCLOUD="${SRC_ROOT}/.config/cloud"

DEST_HOME="/home/techlens"
DEST_SSH="${DEST_HOME}/.ssh"
DEST_AWS="${DEST_HOME}/.aws"
DEST_AZURE="${DEST_HOME}/.azure"
DEST_GCLOUD="${DEST_HOME}/.config/cloud"

RESULT_DIR="${DEST_HOME}/results"
LOCAL_DIR="${DEST_HOME}/local"

mkdir -p $DEST_SSH $DEST_AWS $DEST_AZURE $DEST_GCLOUD

[ -d "$SRC_SSH" ] && cp -a "$SRC_SSH/." "${DEST_SSH}/"
[ -d "$SRC_AWS" ] && cp -a "$SRC_AWS/." "${DEST_AWS}/"
[ -d "$SRC_AZURE" ] && cp -a "$SRC_AZURE/." "${DEST_AZURE}/"
[ -d "$SRC_GCLOUD" ] && cp -a "$SRC_GCLOUD/." "${DEST_GCLOUD}/"

chown -R techlens:techlens "$DEST_SSH" "$DEST_AWS" "$DEST_AZURE" "$DEST_GCLOUD" 2>/dev/null || true

[ -d "$RESULT_DIR" ] && chown -R techlens:techlens "$RESULT_DIR" 2>/dev/null || true

# --- going back to techlens user ---
exec su-exec techlens sh -c '
    set -e

    # Sanitize SSH config to fix issues with macOS specific options like UseKeychain
    USER_SSH_CONFIG="/home/techlens/.ssh/config"

    if [ -f "$USER_SSH_CONFIG" ]; then
        TMP_FILE="${USER_SSH_CONFIG}.tmp"
        grep -vi "usekeychain\|addkeystoagent" "$USER_SSH_CONFIG" > "$TMP_FILE" && mv "$TMP_FILE" "$USER_SSH_CONFIG"
    fi

    exec "$@"
' sh "$@"
