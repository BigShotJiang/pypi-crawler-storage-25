---
name: update-data-packages
description: >
  Update the curated package/token lists in analysis/signals/data/.
  Use when the user wants to refresh, audit, or extend the static
  data modules that drive signal analyzers.
disable-model-invocation: true
allowed-tools: Read, Edit, Write, Grep, Glob, Bash, WebSearch, WebFetch
argument-hint: "[module-name or 'all']"
---

# Update Data Packages

Refresh the curated lists in `src/techlens_agent/analysis/signals/data/`.

## Modules to update

| Module | Purpose | Used by |
|--------|---------|---------|
| `external_libraries.py` | Well-known libs by language (Python, JS, Go, Rust, Java) | `external_call_analyzer` |
| `structural_libraries.py` | Stdlib/infrastructure libs excluded from external-call ratio | `external_call_analyzer` |
| `generic_tokens.py` | Generic programming vocabulary (get, set, data, util...) | `domain_token_analyzer` |
| `glue_patterns.py` | Regex patterns for imports, decorators, config, boilerplate | `glue_marker_analyzer` |
| `realtime_packages.py` | Realtime/event-driven packages (websockets, Kafka, gRPC...) | `realtime_pattern_analyzer` |
| `governance_packages.py` | Governance/workflow packages (Temporal, Casbin, Keycloak...) | `governance_workflow_analyzer` |
| `regulatory_packages.py` | Compliance/crypto packages (FHIR, KMS, encryption libs...) | `regulatory_token_analyzer` |

Not all modules may exist yet. If a module from the plan
hasn't been created, skip it and note that it's pending.

## Procedure

1. Read every `.py` file in `src/techlens_agent/analysis/signals/data/`.
2. For each module, determine what the argument requests:
   - `all` — audit and update every module.
   - A specific name (e.g. `external_libraries`) — only that one.
3. For each targeted module:
   a. **Web search** for the current ecosystem landscape
      relevant to that list (e.g. "most popular Python web
      frameworks 2025", "new Rust async runtimes").
   b. **Identify gaps** — new libraries/packages/tokens that
      are widely adopted but missing from our list.
   c. **Identify removals** — entries that are obsolete,
      renamed, or no longer relevant.
   d. **Edit the file** — add new entries in the correct
      section with a comment if a new category is needed.
      Remove obsolete entries. Keep alphabetical order
      within each section.
4. Run `black src/techlens_agent/analysis/signals/data/`.
5. Run `pytest tests/analysis/ -x -q` to verify nothing broke.
6. Summarize changes per module: what was added, removed,
   and why.

## Rules

- Never remove an entry unless it's genuinely obsolete or
  a duplicate. When in doubt, keep it.
- Keep entries lowercase and stripped of version specifiers.
- For `external_libraries.py`, include both the import name
  and common aliases (e.g. `numpy` and `np`).
- For `glue_patterns.py`, test regex changes against sample
  code snippets before committing.
- Do not add entries that overlap with `generic_tokens.py`
  to `external_libraries.py` (e.g. don't add "list").
- Group new entries under existing language/category
  comments. Add a new section comment only if the language
  or category is entirely new.
