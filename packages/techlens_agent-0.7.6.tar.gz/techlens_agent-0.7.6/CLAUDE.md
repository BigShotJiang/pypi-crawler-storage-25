# TechLens Agent

Software due-diligence analysis tool. Scans repositories to assess code quality, originality, engineering maturity, and cloud infrastructure.

Main source: `src/techlens_agent/` — signals live in `analysis/signals/`, pipeline orchestration in `analysis/`.

## Architecture Constraint

The agent runs on client machines and scans proprietary code.
The server **never** receives source code, identifier names,
or anything derived from code content — only numeric metrics
and metadata (file paths, scores, counts). All analysis that
touches code must happen client-side in the agent or
techlens-metrics. This is a trust/IP boundary — do not
introduce features that transmit code or code-derived strings
to the server.

## Signal Registry

Each signal analyzer in `analysis/signals/` declares `SIGNAL` or `SIGNALS` module-level constants using `SignalDefinition`. These define what the signal computes, its value range, which composite scores it feeds (with weights), and whether it requires SLM or git.

`SignalLevel` (`REPO` vs `PER_FILE`) describes the shape of the signal's **output** — whether it produces one number per repo or a value per file. It does not dictate how the analyzer works internally. A `REPO`-level signal can still accept `manager` and call `add_weight()` to contribute per-file weights for composite ranking.

Use `collect_signals()` from `signal_definition.py` to enumerate all registered signals at runtime. Run `python scripts/generate_signal_docs.py` to regenerate `docs/signals.md`.

### Adding a New Signal

1. Create or edit a file in `analysis/signals/`
2. Add a `SIGNAL` or `SIGNALS` constant using `SignalDefinition`
3. If it feeds a composite, add `CompositeContribution` entries
4. If it contributes per-file weights, call `manager.add_weight()` in the analyzer
5. Run `python scripts/generate_signal_docs.py`

## Key Patterns

### Analysis Pipeline

Pipeline stages are plain functions `(PipelineContext) -> None`. Compose them into ordered lists (`FULL_ANALYSIS`, `STATS_PIPELINE`). Each stage reads from and writes to the shared `PipelineContext` dataclass.

### Composite Scores

`stats_derived.py` uses `compute_composite(name, values)` which reads weights and normalization from `SignalDefinition` constants — no hardcoded weights in the scoring functions.

## Conventions

- Python 3.10–3.13, type hints throughout
- Pydantic for data models, dataclasses for internal state
- Tests in `tests/` mirroring `src/` structure
