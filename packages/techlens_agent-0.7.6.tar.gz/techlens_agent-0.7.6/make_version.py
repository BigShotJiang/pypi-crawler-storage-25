import os
import datetime
import sys


def write_version(version):
    print(f"Writing version: {version}")
    with open("VERSION", "w") as f:
        f.write(version)

    with open("VERSION.py", "w") as f:
        f.write("__version__ = '" + str(version) + "'")


ref = None
# Default to timestamp-based version
version = datetime.datetime.now().strftime("%Y.%m.%d%H%M%S")

if len(sys.argv) > 1:
    # Argument provided, use it as version
    version = sys.argv[1]
elif "GITHUB_REF" in os.environ:
    ref = os.environ["GITHUB_REF"]
    if ref and ref is not None and ref.startswith("refs/tags/"):
        # GitHub Actions tag ref provided, use it as version
        version = ref.replace("refs/tags/", "")

write_version(version)
