# Repository Statistics — Signal Reference

This document explains every signal produced by the `--action stats` pipeline.
Run it with:

```bash
python -m techlens_agent.analysis --action stats --path /path/to/repo
```

The output is a JSON file. SLM-dependent fields are omitted when no language
model is available. All float scores are 0.0-1.0 unless noted otherwise.

---

## Overview Signals

### `total_files_scanned`
Total number of files encountered while walking the repository tree, before
any filtering. Includes binaries, images, lock files — everything.

### `source_files_count`
Files that passed all filters: recognised source extension, not in a skipped
directory (node_modules, .git, vendor, etc.), not machine-generated, and not
a test file. This is the set that all subsequent analysis operates on.

### `test_files_count`
Files that match test naming conventions (`test_*.py`, `*_test.go`,
`*.spec.ts`, etc.). These are excluded from source analysis but still used
by the test-coverage stage to determine which source files have tests.

### `skipped_files_count`
Files filtered out during the walk: binary extensions, vendored directories,
generated files (lock files, `.d.ts`, protobuf stubs, minified JS), and
config/manifest files (package.json, tsconfig.json, Dockerfile, etc.).

### `estimated_total_tokens`
Rough token estimate across all source files, calculated as
`sum(file_size_bytes // 4)`. Useful for sizing LLM context budgets.

### `total_lines`
Total non-empty lines across all source files. Blank lines are excluded.

### `code_lines`
Lines of actual code: `total_lines` minus comment lines. Gives a sense of
raw implementation volume independent of documentation.

### `languages`
File count per extension, sorted by frequency. Example:
`{".py": 42, ".ts": 18, ".yaml": 5}`. Tells you the primary languages and
how polyglot the project is.

---

## Code Quality Signals

### `control_flow_density` (`engineering_score`: 0.15)
Number of control-flow statements (`if`, `else`, `for`, `while`, `try`,
`catch`, `switch`, `match`, `return`, `yield`, `break`, `continue`) per 100
code lines. Measures logical complexity.

- **Low (< 5):** Declarative or data-heavy code. Common in config-driven
  projects, ORMs, or simple CRUD.
- **Moderate (5-15):** Typical application logic with branching and loops.
- **High (> 15):** Algorithm-heavy code, parsers, state machines, or
  deeply nested business rules.

### `definition_density` (`engineering_score`: 0.15)
Function and class definitions (`def`, `class`, `function`, `fn`, `func`,
`pub fn`, etc.) per 100 code lines. Measures how modular the code is.

- **Low (< 3):** Monolithic scripts, god-files, or heavily procedural code.
- **Moderate (3-10):** Well-factored code with clear function boundaries.
- **High (> 10):** Highly granular code — utility libraries, microservices,
  or test suites.

### `comment_ratio` (`engineering_score`: 0.15)
Fraction of non-empty lines that are comments (single-line and multi-line).

- **0.00-0.03:** Essentially uncommented. May be self-documenting or may
  be under-documented.
- **0.03-0.15:** Healthy range for most production code.
- **> 0.15:** Heavily commented. Could indicate good docs, or could be
  commented-out code and TODO spam.

### `duplication_ratio` (`engineering_score`: 0.25)
Fraction of 4-line code blocks that appear more than once across the entire
codebase. Detected via MD5 fingerprinting of normalised lines. Measures
copy-paste coding.

- **0.00-0.05:** Minimal duplication. DRY codebase.
- **0.05-0.15:** Some repeated patterns. Common in test files or generated
  boilerplate.
- **> 0.15:** Significant copy-paste. Refactoring opportunity.

---

## Glue vs Original Code Signals

These three signals work together to answer: "Is this codebase doing
something original, or is it mostly wiring libraries together?"

### `gluemarker_ratio` (`moat_score`: 0.15, inverted)
Density of boilerplate/glue patterns in the combined source content.
Higher values mean more glue; the originality score uses `1 - gluemarker_ratio`.

**Calculation** (see `glue_marker_analyzer.py` + `data/glue_patterns.py`):

1. **Count marker hits** — four compiled regex pattern sets are matched
   against the combined source content:
   | Category | Examples | Weight |
   |----------|----------|--------|
   | `IMPORT_PATTERNS` | `import`, `from … import`, `require()`, `#include`, `use`, `@import` | 0.5 |
   | `DECORATOR_PATTERNS` | `@app.route`, `@Component`, `@Injectable`, `@Entity`, `@dataclass`, `@pytest.fixture` | 1.5 |
   | `CONFIG_PATTERNS` | `if __name__`, `module.exports`, `export default`, `os.environ`, `INSTALLED_APPS`, `SECRET_KEY` | 2.0 |
   | `BOILERPLATE_PATTERNS` | shebangs, `"use strict"`, `#pragma once`, header guards, `public static void main`, `app.run()` | 1.0 |

2. **Weighted sum**:
   ```
   weighted = imports × 0.5 + decorators × 1.5 + config × 2.0 + boilerplate × 1.0
   ```

3. **Divide by total non-blank lines**: `raw_ratio = weighted / total_lines`

4. **Normalise to 0-1**: `min(raw_ratio / 0.3, 1.0)` — a raw ratio of 0.3
   is treated as "fully glue", anything above is clamped to 1.0.

**Interpretation:**

- **0.0-0.2:** Very little boilerplate. Mostly domain logic.
- **0.2-0.5:** Normal mix of glue and logic.
- **0.5-1.0:** Glue-heavy. The project is mostly wiring and config.

### `domain_token_density` (`moat_score`: 0.20)
Measures how much of the vocabulary (identifiers, variable names, function
names) is project-specific vs generic programming words. The analyzer
maintains a 700+ word list of generic tokens (get, set, data, response,
handler, etc.) and computes the ratio of non-generic words.

- **0.0-0.3:** Generic vocabulary. Likely wrapper code or standard patterns.
- **0.3-0.6:** Mix of domain and generic. Typical for applications.
- **0.6-1.0:** Rich domain vocabulary. Indicates deep business logic,
  algorithms, or specialised knowledge.

### `external_call_ratio` (`moat_score`: 0.12, inverted)
Ratio of external library function calls to total function calls. Parsed
from import statements and call sites.

- **0.0-0.2:** Self-contained. Most calls go to internal code.
- **0.2-0.5:** Normal dependency usage.
- **0.5-1.0:** Heavy library consumer. The project's value is in how it
  combines libraries, not in its own algorithms.

---

## Git Activity Signals

Derived from `git log` history. Requires the repository to have commits.

### `high_density_file_count`
Number of files with a normalised git density score above 0.5. Density is
a composite of additions, deletions, commit count, and author count.
High-density files are the "hot" parts of the codebase — frequently changed,
multi-author, high churn.

### `outlier_file_count`
Files whose git density has a z-score above 3 (statistical outliers).
These are files with *exceptionally* high churn compared to the rest of the
repo. Often indicates: active development, bug hotspots, or generated files
that slipped through filters.

---

## Architecture Signals

### `import_graph_nodes`
Number of source files that participate in the import graph (i.e., files
that import or are imported by other files). Files with zero imports and
zero importers are excluded.

### `max_indegree`
The highest import count for any single file. A file with `max_indegree=15`
means 15 other files import it. This is the project's most central
dependency — its "hub".

- **1-3:** Flat architecture, few shared modules.
- **4-10:** Normal. Core utilities or models are shared.
- **> 10:** Strong hub. Changing this file has wide blast radius.

### `test_covered_file_count`
Number of source files that have an associated test file, detected by
naming convention (`foo.py` -> `test_foo.py` or `foo_test.py`).

### `test_coverage_ratio` (`engineering_score`: 0.30)
`test_covered_file_count / source_files_count`. A rough proxy for test
discipline (not line-level coverage, just file-level presence).

- **0.0:** No test files at all.
- **0.1-0.3:** Some key files tested.
- **0.3-0.6:** Reasonable test discipline.
- **> 0.6:** Strong testing culture.

---

## Composite Signals

### `composite_score_mean`
Mean of composite scores across all source files. The composite score
combines git density, author diversity, co-change coupling, import
indegree, comment density, and test coverage into a single per-file number.
A higher mean indicates a codebase where many files score high across
multiple signals.

### `composite_score_stddev`
Standard deviation of composite scores. Low stddev means files are scored
uniformly (flat importance). High stddev means a few files stand out as
significantly more important than the rest.

---

## Derived Signals

These are computed from the raw signals above. They don't add new data —
they synthesise existing signals into actionable summaries.

### `engineering_score`
Single 0-1 score answering "How well-engineered is this codebase?"

Weighted blend of:
- Control-flow density (0.15) — code has logic, not just declarations
- Definition density (0.15) — code is well-factored into functions/classes
- Comment ratio (0.15) — code is documented
- Low duplication (0.25) — DRY, no copy-paste
- Test coverage ratio (0.30) — files have tests

### `moat_score`
Single 0-1 score answering "How large a moat does this code have?"

Weighted blend of:
- Domain token density (0.30) — rich project-specific vocabulary
- Low gluemarker ratio (0.25) — not just boilerplate
- Low external call ratio (0.20) — not just wrapping libraries
- SLM uniqueness score (0.25) — when available, LLM-assessed novelty

### `avg_file_size_tokens`
Average estimated tokens per source file. A proxy for file complexity.

- **< 100:** Very small files. Micro-modules or stubs.
- **100-500:** Typical well-factored files.
- **> 500:** Large files. May need splitting.

### `bus_factor_files`
Count of source files with only one git author. If that person leaves the
project, these files have no institutional knowledge backup.

### `lm_code_value_score`
Independent LM-derived composite score (0-1) capturing the overall "code
value" of the repository. Equal-weight mean of three sub-scores assessed in
a single LM call. Named `lm_*` (not `slm_*`) since the backing model may
be a full LLM.

**Formula:** `(lm_uniqueness + lm_complexity + lm_quality) / 3`

Unlike `code_value_uniqueness_score` (which is folded into `moat_score`
at 0.25 weight), this score stands on its own and is not mixed into any other
composite.

---

## Per-File Detail

Each entry in the `files` dict (keyed by `./`-prefixed relative path) contains:

| Field | Description |
|-------|-------------|
| `path` | Relative path from repo root |
| `estimated_tokens` | File size in estimated tokens |
| `composite_score` | Combined importance score (0-1) |
| `weights` | Individual signal contributions to composite score |
| `additions` | Total lines added across all commits |
| `deletions` | Total lines deleted across all commits |
| `commits` | Number of commits touching this file |
| `authors` | Unique author count |
| `density_score` | Normalised git activity score (0-1) |
| `indegree` | Number of other files that import this file |
| `has_tests` | Whether a test file exists for this source file |
| `comment_ratio` | Per-file comment ratio |
| `slm_description` | LLM-generated description (when SLM enabled) |
| `slm_value_score` | LLM-assessed value score (when SLM enabled) |

---

## SLM Signals (Optional)

These fields appear in the JSON only when a local language model
is available. They are omitted entirely from the output otherwise.

### `program_description`
2-3 sentence description of what the software does, generated by the LLM
after reading per-file summaries.

### `program_value_score`
LLM-assessed intellectual property value of the overall program (0-1).

### `program_notes`
2-5 brief observations about architecture, code quality, risks, or
notable patterns, generated by the LLM.

### `code_value_uniqueness_score` (`moat_score`: 0.25, SLM-only)
LLM-assessed novelty/innovation score (0-1). Measures whether the code
contains novel algorithms, creative problem-solving, or proprietary
approaches vs standard patterns. When absent, the other three originality
sub-scores are re-normalised to fill the full weight.

### `glue_originality_ratio`
LLM-assessed ratio of original code to glue/boilerplate (0-1). Complements
the deterministic `gluemarker_ratio` with semantic understanding.

### `lm_uniqueness`
LM-assessed novelty of the code (0-1). How proprietary or innovative the
ideas are.

- **0.0-0.2:** Commodity code (boilerplate, tutorials, standard CRUD)
- **0.2-0.4:** Minor customizations on common patterns
- **0.4-0.6:** Some original ideas mixed with standard code
- **0.6-0.8:** Significant original thinking, domain-specific solutions
- **0.8-1.0:** Highly innovative, novel algorithms or unique approaches

### `lm_complexity`
LM-assessed implementation difficulty (0-1). How hard it would be to write
this code from scratch. This is meant to establish how large a moat the organization has, not how obscure the code is.

- **0.0-0.2:** Trivial (simple scripts, config wrappers)
- **0.2-0.4:** Straightforward (standard patterns, well-documented APIs)
- **0.4-0.6:** Moderate (requires domain knowledge or careful design)
- **0.6-0.8:** Hard (complex algorithms, intricate state management)
- **0.8-1.0:** Very hard (research-level, advanced math, deep systems work)

### `lm_quality`
LM-assessed engineering quality (0-1). How well-structured, robust, and
maintainable the code is.

- **0.0-0.2:** Poor (no structure, no error handling, unclear intent)
- **0.2-0.4:** Below average (some structure but fragile, inconsistent)
- **0.4-0.6:** Average (reasonable structure, basic error handling)
- **0.6-0.8:** Good (clean abstractions, tested, well-documented)
- **0.8-1.0:** Excellent (exemplary design, robust, production-grade)
