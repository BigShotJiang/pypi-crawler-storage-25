# Analysis Pipeline

The analysis pipeline is a composable sequence of **stages** that runs on a shared `PipelineContext`. Each stage reads what it needs from the context, calls the underlying analyzer, and writes results back.

## Pipeline Context

`PipelineContext` (defined in `pipeline.py`) is a mutable dataclass threaded through every stage. Key fields:

| Field | Type | Description |
|-------|------|-------------|
| `repo_path` | `str` | Absolute path to the repository root |
| `config` | `SlmConfig` | SLM configuration (model, token budget, etc.) |
| `file_paths` | `set[str]` | **Source-only** file paths (test files excluded) |
| `file_paths_list` | `list[str]` | Same as above, ordered |
| `all_file_paths_list` | `list[str]` | All file paths including test files |
| `filter_result` | `FilterResult` | Raw output from `filter_files()` |
| `manager` | `AnalysisManager` | Per-file score accumulator |
| `density_result` | `DensityResult` | Git density scores |
| `indegree_map` | `dict[str, int]` | Import graph indegree counts |
| `metrics` | `CodeMetricsResult` | Code metrics (control flow, definitions, etc.) |
| `test_map` | `dict[str, str]` | Source file -> test file associations |
| `top_files` | `list[FileScore]` | Composite-scored files, sorted descending |
| `per_file_values` | `dict[str, dict]` | SLM per-file descriptions and value scores |
| `program_synthesis` | `dict` | SLM program-level synthesis |
| `code_value_assessment` | `SlmResponse` | SLM code value outlier assessment |
| `slm_glue_assessment` | `SlmResponse` | SLM glue vs. original assessment |
| `error` | `str \| None` | If set, pipeline stops early |

## Stages

### FULL_ANALYSIS (10 stages)

```text
stage_filter_files        (1)   Walk repo, select source files, exclude tests
stage_create_manager      (2)   Create AnalysisManager for per-file score accumulation
stage_git_density         (3)   Git density, author diversity, co-change clustering
stage_import_graph        (4)   Import graph indegree analysis
stage_code_metrics        (5)   Code metrics (control flow, definitions, comments, etc.)
stage_test_coverage       (6)   Test coverage association (uses all_file_paths_list)
stage_composite_scores    (7)   Compute composite scores from accumulated weights
stage_lm_code_value       (8)   LM code value (uniqueness + difficulty + quality)
stage_file_descriptions   (9)   SLM per-file descriptions for ALL source files (chunked)
stage_slm_post_filter     (10)  SLM outlier queries (code value + glue assessment)
```

### POST_FILTER_ONLY (5 stages)

A lighter pipeline for quick re-analysis:

```text
stage_filter_files
stage_git_density
stage_code_metrics
stage_file_descriptions
stage_slm_post_filter
```

## Stage Details

### 1. stage_filter_files

Walks the repository and selects source files via `filter_files()`. Then partitions by test detection:

- **Source files** (non-test) go into `ctx.file_paths` / `ctx.file_paths_list` and are used by all subsequent analysis stages.
- **All files** (including tests) go into `ctx.all_file_paths_list`, used only by the test coverage stage.

Test file detection uses `_is_test_file()` from `test_coverage_analyzer.py`, which matches `test_*.py`, `*_test.py`, `*.test.*`, `*.spec.*`, and `__tests__/` directories.

### 2. stage_create_manager

Creates an `AnalysisManager` that accumulates per-file weighted scores across stages.

### 3. stage_git_density

Runs `calculate_density()` on source files. Produces density scores, author diversity, and co-change cluster information.

### 4. stage_import_graph

Runs `analyze_import_graph()` to compute indegree counts (how many other files import each file).

### 5. stage_code_metrics

Runs `analyze_code_metrics()` for control flow density, definition density, comment ratio, gluemarker ratio, domain token density, external call ratio, and duplication ratio.

### 6. stage_test_coverage

Runs `analyze_test_coverage()` using `all_file_paths_list` (including test files) so that test files are discoverable as coverage candidates.

### 7. stage_composite_scores

Calls `manager.compute_composite_scores()` to combine all accumulated weights into a single composite score per file.

### 8. stage_file_descriptions

Describes **every non-test source file** using the SLM:

1. Filters `selected_files` to only those in `ctx.file_paths` (source-only).
2. Chunks them using `build_context()` with the configured `chunk_token_budget`.
3. For each chunk, queries `SLMAgent` with `PER_FILE_VALUE` to get per-file descriptions, value scores, and rationales.
4. Merges all results into `ctx.per_file_values`.
5. Runs `PROGRAM_VALUE_SYNTHESIS` to produce a program-level description from the per-file summaries.

### 9. stage_slm_post_filter

Runs the `HeuristicPostFilter` with `skip_per_file=True` (since per-file descriptions are already handled by stage 8). Only produces:

- `code_value_assessment` — SLM assessment of outlier files' code value
- `slm_glue_assessment` — SLM assessment of glue vs. original code ratio

## Running the Pipeline

```python
from techlens_agent.analysis.analyze import analyze

result = analyze("/path/to/repo")
```

Or directly:

```python
from techlens_agent.analysis.pipeline import PipelineContext, run_pipeline
from techlens_agent.analysis.stages import FULL_ANALYSIS

ctx = PipelineContext(repo_path="/path/to/repo")
run_pipeline(FULL_ANALYSIS, ctx)
```
