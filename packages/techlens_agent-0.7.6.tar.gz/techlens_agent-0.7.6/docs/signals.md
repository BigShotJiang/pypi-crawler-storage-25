# Signal Registry

Auto-generated catalog of all analysis signals. Run `python scripts/generate_signal_docs.py` to regenerate.

## All Signals

| Signal | Level | Category | Manager Weight | Composites |
|--------|-------|----------|---------------|------------|
| `git_density` | per_file | git | 1.0 | - |
| `author_count` | per_file | git | 1.5 | - |
| `cochange` | per_file | git | 0.8 | - |
| `bus_factor_files` | repo | git | - | - |
| `import_indegree` | per_file | architecture | 2.0 | - |
| `control_flow_density` | repo | heuristic | - | engineering_score(0.15) |
| `definition_density` | repo | heuristic | - | engineering_score(0.15) |
| `comment_ratio` | repo | heuristic | - | engineering_score(0.15) |
| `comment_density_hot` | per_file | heuristic | 1.0 | - |
| `test_coverage` | per_file | architecture | 1.0 | - |
| `test_coverage_boosted` | per_file | architecture | 0.5 | engineering_score(0.30) |
| `test_coverage_ratio` | repo | architecture | - | - |
| `domain_token_density` | repo | heuristic | - | - |
| `domain_match_density` | repo | heuristic | - | moat_score(0.20) |
| `gluemarker_ratio` | repo | heuristic | - | moat_score(0.15inv) |
| `external_call_ratio` | repo | heuristic | - | moat_score(0.12inv) |
| `duplication_ratio` | repo | heuristic | - | engineering_score(0.25inv) |
| `lm_uniqueness` | repo | slm | - | lm_code_value_score(0.33) |
| `lm_complexity` | repo | slm | - | lm_code_value_score(0.33) |
| `lm_quality` | repo | slm | - | lm_code_value_score(0.33) |
| `program_value_score` | repo | slm | - | - |
| `slm_value_score` | per_file | slm | - | - |
| `assessment_score` | repo | slm | - | - |
| `cyclomatic_complexity` | per_file | static_analysis | - | - |
| `operands_sum` | per_file | static_analysis | - | - |
| `operands_unique` | per_file | static_analysis | - | - |
| `operators_sum` | per_file | static_analysis | - | - |
| `operators_unique` | per_file | static_analysis | - | - |
| `definitions_count` | per_file | static_analysis | - | - |
| `halstead_volume` | per_file | static_analysis | - | - |
| `halstead_difficulty` | per_file | static_analysis | - | - |
| `halstead_effort` | per_file | static_analysis | - | - |
| `halstead_bugprop` | per_file | static_analysis | - | - |
| `halstead_timerequired` | per_file | static_analysis | - | - |
| `maintainability_index` | per_file | static_analysis | - | - |
| `fanout_internal` | per_file | static_analysis | - | - |
| `fanout_external` | per_file | static_analysis | - | - |
| `tiobe` | per_file | static_analysis | - | - |
| `pylint` | per_file | static_analysis | - | - |
| `api_surface_ratio` | repo | architecture | 1.0 | moat_score(0.06) |
| `realtime_pattern_density` | repo | architecture | - | moat_score(0.06) |
| `data_accumulation_pattern` | repo | architecture | 1.0 | moat_score(0.10) |
| `governance_workflow_density` | repo | architecture | 1.0 | moat_score(0.06) |
| `regulatory_token_density` | repo | architecture | 1.0 | moat_score(0.12) |
| `file_role` | per_file | static_analysis | - | - |
| `cochange_clusters` | repo | git | - | - |
| `churn_risk` | per_file | git | - | - |

## Composite Score Breakdowns

### `engineering_score`

| Signal | Weight | % of Total | Inverted | SLM? |
|--------|--------|-----------|----------|------|
| `control_flow_density` | 0.1500 | 15.0% | no | no |
| `definition_density` | 0.1500 | 15.0% | no | no |
| `comment_ratio` | 0.1500 | 15.0% | no | no |
| `test_coverage_boosted` | 0.3000 | 30.0% | no | no |
| `duplication_ratio` | 0.2500 | 25.0% | yes | no |

### `lm_code_value_score`

| Signal | Weight | % of Total | Inverted | SLM? |
|--------|--------|-----------|----------|------|
| `lm_uniqueness` | 0.3333 | 33.3% | no | yes |
| `lm_complexity` | 0.3333 | 33.3% | no | yes |
| `lm_quality` | 0.3333 | 33.3% | no | yes |

### `moat_score`

| Signal | Weight | % of Total | Inverted | SLM? |
|--------|--------|-----------|----------|------|
| `domain_match_density` | 0.2000 | 23.0% | no | no |
| `gluemarker_ratio` | 0.1500 | 17.2% | yes | no |
| `external_call_ratio` | 0.1200 | 13.8% | yes | no |
| `api_surface_ratio` | 0.0600 | 6.9% | no | no |
| `realtime_pattern_density` | 0.0600 | 6.9% | no | no |
| `data_accumulation_pattern` | 0.1000 | 11.5% | no | no |
| `governance_workflow_density` | 0.0600 | 6.9% | no | no |
| `regulatory_token_density` | 0.1200 | 13.8% | no | no |

## Signals by Category

### architecture

- **`import_indegree`** — Normalized count of internal imports pointing to this file
  > Identifies architectural bottlenecks and single points of failure. A file imported by dozens of others is both the most valuable and the most dangerous — any bug there cascades across the entire system, and it cannot be replaced without coordinated refactoring.
- **`test_coverage`** — Binary 1.0/0.0 per file indicating presence of an associated test file
  > Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.
- **`test_coverage_boosted`** — Churn-weighted boost for tested files (test_coverage * git_density)
  > Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.
- **`test_coverage_ratio`** — Ratio of testable files (source, model, service, controller, repository, middleware, util) that have associated test files. Excludes views, vendor, generated, lock, build artifact, fixture, test, migration, config, and infra from the denominator.
  > Reveals engineering discipline. Low test coverage tells an investor the team ships without a safety net. The absence of tests is one of the most common findings that changes rebuild estimates and post-close stabilization budgets.
- **`api_surface_ratio`** — Ratio of API-exposed files (controllers, routes, handlers, views, resolvers, resources). Measures what fraction of source files exposes external endpoints.
  > Detects interface control. A product with a large API surface that third parties integrate with creates switching costs proportional to the number of external consumers. More endpoints = more ecosystem dependence = stickier product.
- **`realtime_pattern_density`** — Ratio of realtime/event-driven dependencies to total dependencies
  > Detects a resilient AI moat. Low-latency and high-frequency domains (WebSocket, gRPC, streaming) are among the hardest for AI to replicate because they require real-time state management and performance engineering. Presence signals sticky technical complexity.
- **`data_accumulation_pattern`** — Migration/seed files + git history span indicating data accumulation moat (requires git)
  > Detects data flywheel effects. 200+ migration files represent years of schema evolution driven by real-world usage. The accumulated data model and the logic to manage it are often more valuable than the application code itself.
- **`governance_workflow_density`** — Density of governance/workflow paths and deps indicating process moat
  > Detects one of the stickiest moats: governance authority. Products with deep approval workflows, RBAC, and audit trails have switching costs that compound over time. Customers can't easily rip out a system that enforces their compliance processes.
- **`regulatory_token_density`** — Density of compliance/regulatory paths and deps indicating regulatory moat
  > Regulated industries create natural moats because compliance requirements raise the barrier to entry for competitors and AI. A codebase with deep HIPAA, PCI, or SOX implementations reflects years of regulatory domain knowledge that can't be shortcut.

### git

- **`git_density`** — Normalized change activity score from git history (requires git)
  > Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.
- **`author_count`** — Normalized count of distinct commit authors per file (requires git)
  > Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.
- **`cochange`** — Normalized co-change coupling frequency per file (requires git)
  > Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.
- **`bus_factor_files`** — Count of business-logic files (source, model, service, controller, repository, middleware, util, view) with only one author (bus-factor risk). Excludes vendor, generated, lock, build artifact, fixture, test, migration, config, and infra files. (requires git)
  > Answers the four most common workshop questions at once: Where is active development focused? Who are the critical developers? What happens if they leave? Which components are secretly coupled? These findings directly influence retention clauses, earnout structures, and integration timelines.
- **`cochange_clusters`** — Clusters of files that frequently change together, detected via Louvain community detection (requires git)
  > Reveals hidden architectural coupling. Files that always change together may be tightly coupled even if they have no import relationship. This informs modularization effort estimates and highlights integration risk during platform migrations.
- **`churn_risk`** — Per-file risk score: churn * (1 - protective_factors). Protective factors: has_tests (0.4), multiple authors (0.3), low complexity (0.3). High churn with good tests and multiple authors scores low risk. High churn with no tests, single author, and high complexity scores high risk. (requires git)
  > Churn alone is ambiguous — active development is healthy. Churn risk isolates files where high change velocity lacks protective factors (tests, shared ownership, manageable complexity), surfacing true maintenance debt and key-person risk.

### heuristic

- **`control_flow_density`** — Control-flow statements per 100 code lines
  > Identifies where business rules concentrate. High control flow density in a few files means proprietary decision logic is packed into complex code, driving up rebuild cost. Low density across the repo may indicate the product is mostly glue with little original logic.
- **`definition_density`** — Definitions (functions, classes) per 100 code lines
  > Indicates code modularity and reuse patterns. Low definition density suggests monolithic functions doing too much, increasing maintenance cost.
- **`comment_ratio`** — Repo-wide ratio of comment lines to total lines
  > Documentation culture is a leading indicator of post-close maintenance risk. Near-zero comments + high change frequency = institutional knowledge trapped in developers' heads. Directly affects knowledge transfer timelines and key-person retention priorities.
- **`comment_density_hot`** — Per-file interaction signal: comment ratio * git density
  > Documentation culture is a leading indicator of post-close maintenance risk. Near-zero comments + high change frequency = institutional knowledge trapped in developers' heads. Directly affects knowledge transfer timelines and key-person retention priorities.
- **`domain_token_density`** — Ratio of domain-specific vocabulary to generic tokens
  > Unlocks the most strategically important signal. Function names like 'calculate_actuarial_reserve' or 'apply_regulatory_haircut' reveal the depth of proprietary domain knowledge that can't be replicated by hiring generic developers.
- **`domain_match_density`** — Ratio of domain-specific vocabulary matches (stemmed + prefix)
  > Measures positive matches against curated domain dictionaries (fintech, healthtech, enterprise). Unlike generic density, this confirms the codebase actually uses specialized vocabulary — a strong indicator of proprietary domain logic.
- **`gluemarker_ratio`** — Weighted ratio of glue/boilerplate markers to total lines
  > Quantifies how much of the codebase is commodity wiring vs. substantive logic. A product that's 70% glue code has a fundamentally different value proposition than one with deep proprietary processing. Directly answers: 'How much of this is replaceable by off-the-shelf tools or AI?'
- **`external_call_ratio`** — Ratio of external library calls to total function calls
  > Measures how self-contained the product's value is. High external dependency means vulnerability to vendor pricing changes, API deprecation, or third-party outages. Inverse relationship to defensibility.
- **`duplication_ratio`** — Ratio of duplicated code blocks across files
  > High duplication is a direct indicator of technical debt and rebuild cost. Copy-pasted code means bugs exist in multiple places, refactoring is more expensive than it appears, and the team's engineering practices are weak.

### slm

- **`lm_uniqueness`** — LM-assessed code uniqueness/novelty (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.
- **`lm_complexity`** — LM-assessed implementation difficulty (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.
- **`lm_quality`** — LM-assessed code quality (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.
- **`program_value_score`** — SLM-synthesized holistic program value from per-file summaries (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.
- **`slm_value_score`** — SLM-assessed value score per individual source file (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.
- **`assessment_score`** — Engineered-vs-assembled verdict from chunk+merge SLM pipeline (requires SLM)
  > Enables 'Is this code worth acquiring?' as a scored, benchmarkable answer. Per-file IP identification transforms workshops. Rebuild estimation with AI-assessed complexity.

### static_analysis

- **`cyclomatic_complexity`** — McCabe cyclomatic complexity per file
  > Measures the number of independent execution paths through the code. High cyclomatic complexity means more test cases needed for full coverage and higher probability of latent defects — directly impacting post-close stabilization effort.
- **`operands_sum`** — Total operand token count per file
  > Raw input for Halstead metrics. Total operand count reflects data volume flowing through the code — higher counts indicate files doing substantive data transformation rather than simple pass-through.
- **`operands_unique`** — Unique operand token count per file
  > Vocabulary breadth of data elements. A file with many unique operands is manipulating a rich data model, suggesting domain-specific logic that is harder to replicate or replace with generic tooling.
- **`operators_sum`** — Total operator token count per file
  > Raw input for Halstead metrics. High operator counts relative to operands indicate dense control logic and data manipulation, contributing to implementation effort estimates.
- **`operators_unique`** — Unique operator token count per file
  > Indicates the breadth of language features and constructs used. Files leveraging more unique operators tend to implement more sophisticated algorithms that require deeper expertise to maintain.
- **`definitions_count`** — Unique function and class definition count per file
  > Counts distinct function and class definitions via Pygments tokens. High definition counts indicate files that declare substantial API surface — more definitions mean more contracts to maintain, test, and document.
- **`halstead_volume`** — Halstead program volume
  > Measures the information content of the code in bits. High volume files contain more logic to understand, test, and maintain — directly proportional to the knowledge transfer effort required post-acquisition.
- **`halstead_difficulty`** — Halstead program difficulty
  > Quantifies how hard the code is to write or understand. High difficulty files are error-prone to modify and require senior engineers — a factor in retention planning and post-close staffing decisions.
- **`halstead_effort`** — Halstead implementation effort
  > Enables rebuild estimation and t-shirt sizing. The top 10 files account for 60% of total comprehension effort, giving concrete input for post-close staffing and timeline planning.
- **`halstead_bugprop`** — Halstead estimated bug propensity
  > Predicts the expected number of delivered defects based on code volume. Files with high bug propensity are where post-close quality issues will concentrate — informing QA resource allocation and stabilization timelines.
- **`halstead_timerequired`** — Halstead estimated implementation time
  > Estimates implementation time in seconds per file. High values flag modules that will take longest to rewrite or onboard — giving concrete input for rebuild timelines and staffing plans.
- **`maintainability_index`** — SEI maintainability index (0-100)
  > Ready-made quality score on a 0-100 scale that's immediately interpretable. 'This repo scores 35 on maintainability, bottom quartile across 200+ codebases we've assessed' is a finding that lands in investment committee presentations.
- **`fanout_internal`** — Count of unique internal (relative) imports per file
  > Measures internal coupling. Files that import many other project files are integration points — complex to modify and test because changes ripple across the dependency chain.
- **`fanout_external`** — Count of unique external imports per file
  > Measures external dependency at the file level. Files pulling in many third-party libraries are vulnerable to vendor changes and are often glue code rather than proprietary logic.
- **`tiobe`** — TIOBE quality index (0-100)
  > Industry-standard composite quality score combining complexity, code size, and duplication. Enables cross-repo benchmarking: 'This file scores 45/100, below the threshold for maintainable production code.'
- **`pylint`** — Pylint-style quality score (0-100)
  > Widely recognized quality score in the Python ecosystem. Provides a familiar benchmark that engineering teams and technical advisors already understand, reducing friction in due-diligence conversations.
- **`file_role`** — Semantic role classification per file (generated, vendor, lock, build_artifact, fixture, test, migration, view, controller, model, service, repository, middleware, config, infra, util, source)
  > Enables targeted analysis by distinguishing code that matters (business logic, controllers, models) from code that doesn't (generated, vendored, config). Downstream signals can weight files differently based on their role.
