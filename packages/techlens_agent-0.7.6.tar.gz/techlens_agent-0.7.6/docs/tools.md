# Developer Tools

Project-specific skills and utilities for techlens-agent.

## Claude Code Skills

Skills live in `.claude/skills/` and are invoked as
slash commands during a Claude Code session.

### `/update-data-packages [module|all]`

Audits and refreshes the curated package/token lists in
`src/techlens_agent/analysis/signals/data/`. These static
data modules drive several signal analyzers — keeping them
current ensures new libraries are recognized correctly.

**What it does:**

1. Reads every data module in `signals/data/`
2. Web-searches for ecosystem changes (new frameworks,
   renamed packages, deprecated libraries)
3. Adds missing entries, removes obsolete ones
4. Runs `black` and `pytest` to verify nothing broke
5. Summarizes all changes

**Usage:**

```
/update-data-packages all                  # audit every module
/update-data-packages external_libraries   # only that module
/update-data-packages regulatory_packages  # only that module
```

**Modules covered:**

| Module | What it contains |
|--------|------------------|
| `external_libraries.py` | Well-known libs across Python, JS, Go, Rust, Java |
| `structural_libraries.py` | Stdlib/infra libs excluded from external-call ratio |
| `generic_tokens.py` | Generic programming vocabulary filtered from domain analysis |
| `glue_patterns.py` | Regex patterns for imports, decorators, config boilerplate |
| `realtime_packages.py` | Realtime/event-driven packages (websockets, Kafka, gRPC) |
| `governance_packages.py` | Governance/workflow packages (Temporal, Casbin, Keycloak) |
| `regulatory_packages.py` | Compliance/crypto packages (FHIR, KMS, encryption libs) |

Note: modules from the plan that haven't been created yet
are skipped automatically.
