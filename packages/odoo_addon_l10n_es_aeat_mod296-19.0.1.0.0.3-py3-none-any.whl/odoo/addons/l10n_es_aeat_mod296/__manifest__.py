# Copyright AvanzOSC - Ainara Galdona
# Copyright 2016 - Tecnativa - Antonio Espinosa
# Copyright 2016-2019 - Tecnativa - Pedro M. Baeza
# Copyright 2018 Valentin Vinagre <valentin.vinagre@qubiq.es>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "AEAT modelo 296",
    "version": "19.0.1.0.0",
    "category": "Localisation/Accounting",
    "author": "Tecnativa, AvanzOSC, Qubiq, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/l10n-spain",
    "license": "AGPL-3",
    "depends": ["l10n_es_aeat", "l10n_es_aeat_mod216"],
    "data": [
        "security/ir.model.access.csv",
        "data/l10n.es.aeat.map.tax.csv",
        "data/l10n.es.aeat.map.tax.line.tax.csv",
        "data/l10n.es.aeat.map.tax.line.csv",
        "data/aeat.model.export.config.csv",
        "data/aeat.model.export.config.line.csv",
        "views/mod296_views.xml",
        "security/ir_rule.xml",
    ],
    "installable": True,
}
