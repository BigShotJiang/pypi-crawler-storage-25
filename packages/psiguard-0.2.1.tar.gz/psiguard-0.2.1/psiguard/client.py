"""
psiguard/client.py

The PsiGuard Python SDK client.
Wraps the PsiGuard API so developers can monitor AI responses
in their own applications with a single function call.

Usage:
    from psiguard import PsiGuard

    pg = PsiGuard(api_key="pg_...")

    result = pg.check(
        prompt="What is the capital of France?",
        response="The capital of France is Paris.",
        thread_id="session-abc123",
    )

    if result.should_block:
        print("Blocked:", result.explanation)
    else:
        print("Safe — risk score:", result.risk_score)
        print("Coherence:", result.metrics.coherence)
        print("Drift:",     result.metrics.drift)

    if result.regulation.action != "none":
        print("Suggestion:", result.regulation.suggestions)
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import requests

DEFAULT_BASE_URL = "https://psiguard.net"
DEFAULT_TIMEOUT  = 15  # seconds


# ── Response dataclasses ──────────────────────────────────────────────────────

@dataclass
class Metrics:
    """
    PsiGuard's four cognitive metrics.

    Each is a float between 0.0 and 1.0.

    Attributes:
        coherence   How structurally stable the AI's reasoning is.
                    Higher = more coherent. Drops signal fragmented logic.
        drift       How far the response has moved from the conversation
                    trajectory. Lower = less drift. Spikes signal topic
                    departure or hallucination onset.
        entropy     Behavioral transition stress — how much the AI's
                    internal state is shifting. Lower = calmer output.
                    Spikes signal fabrication or collapse.
        stability   How well the response connects to the conversation
                    history. Higher = better grounded. Drops signal the
                    AI is losing context or inventing information.
    """
    coherence: float = 0.0
    drift:     float = 0.0
    entropy:   float = 0.0
    stability: float = 0.0


@dataclass
class Regulation:
    """
    Actionable regulation advice from PsiGuard.

    Tells you what PsiGuard would do if it controlled generation,
    so you can implement your own steering loop.

    Attributes:
        action           Recommended action:
                           "none"       — output is healthy, no action needed.
                           "monitor"    — minor concern, keep watching.
                           "steer"      — inject a steering prompt and regenerate.
                           "regenerate" — discard and regenerate with tighter params.
        severity         "info", "low", "moderate", or "high".
        suggestions      List of plain-English suggestions for improvement.
        adjustments      Dict of parameter recommendations, e.g.
                         {"temperature": 0.3, "max_tokens": 256}.
        steering_prompt  A ready-to-use system prompt you can inject when
                         regenerating. None if no steering is needed.
        message          Human-readable summary (present during warm-up).
    """
    action:          str            = "none"
    severity:        str            = "info"
    suggestions:     List[str]      = field(default_factory=list)
    adjustments:     Dict[str, any] = field(default_factory=dict)
    steering_prompt: Optional[str]  = None
    message:         Optional[str]  = None


@dataclass
class CheckResult:
    """
    Returned by PsiGuard.check().

    Attributes:
        should_block  True if PsiGuard recommends blocking this response.
        state         One of: WARMING_UP, STABLE, ANALYZING, UNSTABLE,
                      ANOMALY, DRIFT, CRITICAL, BLOCKED.
        risk_score    Integer 0-100. Higher = more risk.
        confidence    Float 0.0-1.0. How confident the engine is in its verdict.
        metrics       The four cognitive metric scores (see Metrics).
        regulation    Actionable advice for improving the response (see Regulation).
        warnings      List of human-readable warning strings.
        explanation   Plain-English explanation of the decision.
        timestamp     Unix timestamp from the server.
    """
    should_block: bool
    state:        str
    risk_score:   int
    confidence:   float
    metrics:      Metrics
    regulation:   Regulation
    warnings:     List[str]
    explanation:  str
    timestamp:    float


@dataclass
class ThreadSummary:
    """
    Returned by PsiGuard.thread_summary().

    Attributes:
        total_steps   Number of checks run in this thread.
        mean_risk     Average risk score across all steps (0-100).
        max_risk      Highest risk score seen in this thread (0-100).
        state_counts  Dict of state label -> count (e.g. {"STABLE": 5, "DRIFT": 2}).
    """
    total_steps:  int
    mean_risk:    float
    max_risk:     int
    state_counts: dict = field(default_factory=dict)


# ── Exceptions ────────────────────────────────────────────────────────────────

class PsiGuardError(Exception):
    """Raised when the PsiGuard API returns an error."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class PsiGuardAuthError(PsiGuardError):
    """Raised when the API key is missing, invalid, or inactive."""
    pass


class PsiGuardRateLimitError(PsiGuardError):
    """Raised when the monthly check limit is reached (Playground plan)."""
    pass


# ── Main client ───────────────────────────────────────────────────────────────

class PsiGuard:
    """
    PsiGuard AI Safety Monitoring client.

    Args:
        api_key   Your pg_... API key. If omitted, reads PSIGUARD_API_KEY
                  from the environment.
        base_url  Override the API endpoint (useful for testing).
        timeout   HTTP request timeout in seconds (default: 15).

    Example:
        pg = PsiGuard(api_key="pg_...")
        result = pg.check(prompt="...", response="...", thread_id="session-1")

        # Access the four cognitive metrics
        print(result.metrics.coherence)  # 0.0 - 1.0
        print(result.metrics.drift)      # 0.0 - 1.0

        # Get regulation advice
        if result.regulation.action == "regenerate":
            print("Steering prompt:", result.regulation.steering_prompt)
    """

    def __init__(
        self,
        api_key:  Optional[str] = None,
        base_url: str           = DEFAULT_BASE_URL,
        timeout:  int           = DEFAULT_TIMEOUT,
    ):
        resolved_key = api_key or os.environ.get("PSIGUARD_API_KEY", "")
        if not resolved_key:
            raise PsiGuardAuthError(
                "No API key provided. Pass api_key='pg_...' or set the "
                "PSIGUARD_API_KEY environment variable."
            )
        if not resolved_key.startswith("pg_"):
            raise PsiGuardAuthError(
                "Invalid API key format. Keys must start with 'pg_'. "
                "Find your key in the PsiGuard dashboard."
            )

        self._api_key  = resolved_key
        self._base_url = base_url.rstrip("/")
        self._timeout  = timeout
        self._session  = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    f"psiguard-python/{__import__('psiguard').__version__}",
        })

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _post(self, path: str, body: dict) -> dict:
        url = f"{self._base_url}{path}"
        try:
            resp = self._session.post(url, json=body, timeout=self._timeout)
        except requests.exceptions.ConnectionError as e:
            raise PsiGuardError(f"Could not connect to PsiGuard API: {e}")
        except requests.exceptions.Timeout:
            raise PsiGuardError(
                f"Request to PsiGuard API timed out after {self._timeout}s."
            )

        if resp.status_code == 401:
            raise PsiGuardAuthError(
                "Invalid or inactive API key. Check your key in the PsiGuard dashboard.",
                status_code=401,
            )
        if resp.status_code == 429:
            data = resp.json() if resp.content else {}
            raise PsiGuardRateLimitError(
                data.get("error", "Monthly limit reached. Upgrade to Pro for unlimited monitoring."),
                status_code=429,
            )
        if resp.status_code == 503:
            raise PsiGuardError(
                "PsiGuard monitoring engine is temporarily unavailable. Try again shortly.",
                status_code=503,
            )
        if not resp.ok:
            try:
                msg = resp.json().get("error", resp.text)
            except Exception:
                msg = resp.text
            raise PsiGuardError(f"API error ({resp.status_code}): {msg}", status_code=resp.status_code)

        return resp.json()

    # ── Public API ────────────────────────────────────────────────────────────

    def check(
        self,
        prompt:         str,
        response:       str,
        thread_id:      str = "default",
        risk_threshold: int = 70,
    ) -> CheckResult:
        """
        Monitor an AI response and get a safety decision.

        Args:
            prompt          The user's input / question sent to the AI.
            response        The AI's response to evaluate.
            thread_id       Identifies the conversation session. Use the same
                            thread_id across turns to enable drift and coherence
                            tracking.
            risk_threshold  0-100. Responses with risk_score above this will
                            have should_block=True. Default: 70.

        Returns:
            CheckResult with metrics (Coherence, Drift, Entropy, Stability)
            and regulation advice.

        Raises:
            PsiGuardAuthError       Bad or missing API key.
            PsiGuardRateLimitError  Monthly limit reached (Playground plan).
            PsiGuardError           Any other API or network error.

        Example:
            result = pg.check(
                prompt="Explain quantum tunneling.",
                response="Quantum tunneling allows particles to...",
                thread_id="chat-session-42",
            )

            if result.should_block:
                raise ValueError("Unsafe AI response detected")

            # Implement your own steering loop
            if result.regulation.action in ("steer", "regenerate"):
                # Re-generate with PsiGuard's suggested parameters
                new_params = result.regulation.adjustments
                steering   = result.regulation.steering_prompt
                # ... regenerate using new_params and steering ...
        """
        if not prompt or not prompt.strip():
            raise ValueError("prompt must be a non-empty string.")
        if not response or not response.strip():
            raise ValueError("response must be a non-empty string.")

        data = self._post("/v1/check", {
            "prompt":         prompt.strip(),
            "response":       response.strip(),
            "thread_id":      thread_id or "default",
            "risk_threshold": int(risk_threshold),
        })

        # Parse metrics
        raw_metrics = data.get("metrics") or {}
        metrics = Metrics(
            coherence = float(raw_metrics.get("coherence", 0.0)),
            drift     = float(raw_metrics.get("drift", 0.0)),
            entropy   = float(raw_metrics.get("entropy", 0.0)),
            stability = float(raw_metrics.get("stability", 0.0)),
        )

        # Parse regulation advice
        raw_reg = data.get("regulation") or {}
        regulation = Regulation(
            action          = str(raw_reg.get("action", "none")),
            severity        = str(raw_reg.get("severity", "info")),
            suggestions     = list(raw_reg.get("suggestions", [])),
            adjustments     = dict(raw_reg.get("adjustments", {})),
            steering_prompt = raw_reg.get("steering_prompt"),
            message         = raw_reg.get("message"),
        )

        return CheckResult(
            should_block = bool(data.get("should_block", False)),
            state        = str(data.get("state", "UNKNOWN")),
            risk_score   = int(data.get("risk_score", 0)),
            confidence   = float(data.get("confidence", 0.0)),
            metrics      = metrics,
            regulation   = regulation,
            warnings     = list(data.get("warnings", [])),
            explanation  = str(data.get("explanation", "")),
            timestamp    = float(data.get("timestamp", 0.0)),
        )

    def thread_reset(self, thread_id: str) -> bool:
        """
        Clear a conversation thread's monitoring history.

        Call this when a new conversation starts so PsiGuard doesn't carry
        over context from a previous session using the same thread_id.

        Args:
            thread_id  Must match a thread_id previously used in check().

        Returns:
            True if the thread was found and reset.

        Raises:
            PsiGuardError  Thread not found or network error.
        """
        if not thread_id or not thread_id.strip():
            raise ValueError("thread_id must be a non-empty string.")
        data = self._post("/v1/thread/reset", {"thread_id": thread_id.strip()})
        return bool(data.get("ok", False))

    def thread_summary(self, thread_id: str) -> ThreadSummary:
        """
        Get aggregated monitoring stats for a conversation thread.

        Args:
            thread_id  The thread to summarise.

        Returns:
            ThreadSummary with total_steps, mean_risk, max_risk, state_counts.

        Raises:
            PsiGuardError  Thread not found or network error.
        """
        if not thread_id or not thread_id.strip():
            raise ValueError("thread_id must be a non-empty string.")
        data = self._post("/v1/thread/summary", {"thread_id": thread_id.strip()})
        return ThreadSummary(
            total_steps  = int(data.get("total_steps", 0)),
            mean_risk    = float(data.get("mean_risk", 0.0)),
            max_risk     = int(data.get("max_risk", 0)),
            state_counts = dict(data.get("state_counts", {})),
        )
