from .client import (
    PsiGuard,
    CheckResult,
    Metrics,
    Regulation,
    ThreadSummary,
    PsiGuardError,
    PsiGuardAuthError,
    PsiGuardRateLimitError,
)

# Alias for the SDK-style name:
PsiGuardClient = PsiGuard

__all__ = [
    "PsiGuard",
    "PsiGuardClient",
    "CheckResult",
    "Metrics",
    "Regulation",
    "ThreadSummary",
    "PsiGuardError",
    "PsiGuardAuthError",
    "PsiGuardRateLimitError",
]

__version__ = "0.2.1"
