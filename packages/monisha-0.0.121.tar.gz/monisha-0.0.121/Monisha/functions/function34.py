import re

class Cleantxts:

    @staticmethod
    def get01(incoming, clean=r"[_\-]+"):
        moonos = re.sub(clean, " ", incoming)
        moonus = re.sub(r"\s+", " ", moonos).strip()
        return moonus
