import time
from .function01 import tzone

sdates = tzone()
stimes = time.time()
