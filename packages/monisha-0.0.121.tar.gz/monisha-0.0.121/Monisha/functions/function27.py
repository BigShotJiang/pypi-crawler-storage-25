import ast
from ..scripts import Scripted
from .collections import SMessage
#==========================================================================

def TxtDirs(incoming: str) -> dict:
    try:
        moones = ast.literal_eval(incoming.strip())
        moonus = moones if isinstance(moones, dict) else None
        errors = None if moonus else Scripted.ERROR02.format(moonus)
        return SMessage(result=moonus, errors=errors)
    except (ValueError, SyntaxError) as errors:
        return SMessage(errors=errors)
    except Exception as errors:
        return SMessage(errors=errors)

#==========================================================================
