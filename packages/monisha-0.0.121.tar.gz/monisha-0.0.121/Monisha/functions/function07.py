import asyncio
from .collections import SMessage
#======================================================================================

async def commandR(command, **kwargs):
    try:
        mainos = await asyncio.create_subprocess_exec(*command,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, **kwargs) 
        moonus = await mainos.communicate()
        resues = moonus[0]
        errose = moonus[1]
        codeos = mainos.returncode
        result = resues.decode("utf-8", errors="ignore").strip()
        errors = errose.decode("utf-8", errors="ignore").strip()
        return SMessage(results=result, taskcode=codeos, errors=errors)
    except Exception as errors:
        return SMessage(errors=errors)

#======================================================================================

"""
import asyncio

async def commandR(command, **kwargs):
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=PIPE,
            stderr=PIPE,
            **kwargs
        )

        # Read stderr line by line for live progress
        async for line in process.stderr:
            decoded = line.decode("utf-8", errors="ignore").strip()
            if decoded:
                print("FFmpeg:", decoded)  # live progress output

        stdout_data, stderr_data = await process.communicate()

        result = stdout_data.decode("utf-8", errors="ignore").strip()
        errors = stderr_data.decode("utf-8", errors="ignore").strip()

        return SMessage(results=result, taskcode=process.returncode, errors=errors)
    except Exception as e:
        return SMessage(errors=str(e))

"""
