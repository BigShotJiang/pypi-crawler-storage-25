class Cancelled(Exception):
    pass
