from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="mkdocs-gitlab-theme",
    version="1.0.0",
    author="GitLab",
    description="A professional GitLab-styled dark mode theme for MkDocs",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/gitlab-org/mkdocs-gitlab-theme",
    packages=find_packages(),
    package_data={
        "mkdocs_gitlab_theme": [
            "*.html",
            "*.yml",
            "css/*.css",
        ],
    },
    include_package_data=True,
    install_requires=[
        "mkdocs>=1.0",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Documentation",
        "Topic :: Software Development :: Documentation",
    ],
    entry_points={
        "mkdocs.themes": [
            "gitlab = mkdocs_gitlab_theme",
        ],
    },
)
