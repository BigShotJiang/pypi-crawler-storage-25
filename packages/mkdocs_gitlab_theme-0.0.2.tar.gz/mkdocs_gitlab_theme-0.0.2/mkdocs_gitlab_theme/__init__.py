"""GitLab-styled MkDocs theme."""

__version__ = "1.0.0"
__author__ = "GitLab"
__license__ = "MIT"
