"""JSONL protocol message types and serialization."""

import base64
import json


def b64_encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def b64_decode(s: str) -> bytes:
    return base64.b64decode(s)


# --- Message construction helpers ---

def make_invoke(command, args, input_=False, version=1):
    msg = {"type": "invoke", "version": version, "command": command, "args": args}
    if input_:
        msg["input"] = True
    return msg


def make_output(record):
    return {"type": "output", "record": record}


def make_done(exit_code, error=None):
    msg = {"type": "done", "exit_code": exit_code}
    if error is not None:
        msg["error"] = error
    return msg


def make_input(data, eof=False):
    msg = {"type": "input", "data": data}
    if eof:
        msg["eof"] = True
    return msg


def make_progress(fraction):
    return {"type": "progress", "fraction": fraction}


def make_capability_req(id_, domain, op, params=None):
    msg = {"type": "capability_req", "id": id_, "domain": domain, "op": op}
    if params is not None:
        msg["params"] = params
    return msg


def make_capability_res_ok(id_, data):
    return {"type": "capability_res", "id": id_, "status": "ok", "data": data}


def make_capability_res_error(id_, kind, message):
    return {
        "type": "capability_res", "id": id_, "status": "error",
        "error": {"kind": kind, "message": message},
    }


# --- Serialization ---

def serialize(msg):
    """Serialize a message dict to a JSON line (with trailing newline)."""
    return json.dumps(msg, separators=(",", ":")) + "\n"


def deserialize(line):
    """Deserialize a JSON line to a message dict."""
    return json.loads(line)


# --- Parsing helpers ---

def parse_invoke(msg):
    """Parse and validate an invoke message. Returns (command, args, has_input, version)."""
    if msg.get("type") != "invoke":
        raise ValueError(f"expected invoke message, got: {msg.get('type')}")
    command = msg["command"]
    args = msg.get("args", {})
    has_input = msg.get("input", False)
    version = msg.get("version", 1)
    return command, args, has_input, version


def parse_capability_res(msg):
    """Parse a capability response. Returns data or raises IOError."""
    status = msg.get("status")
    if status == "ok":
        return msg.get("data")
    elif status == "error":
        err = msg.get("error", {})
        kind = err.get("kind", "other")
        message = err.get("message", "unknown error")
        raise IOError(f"[{kind}] {message}")
    else:
        raise ValueError(f"unexpected capability_res status: {status}")
