"""Context object provided to package handlers."""

import io
from . import _runtime as runtime


class Context:
    def __init__(self, command, args, input_stream):
        self._command = command
        self._args = args
        self._input_stream = input_stream
        self._input_consumed = False

    def command(self):
        """Return the command name from the INVOKE message."""
        return self._command

    def args(self):
        """Return the raw args dict from the INVOKE message."""
        return self._args

    def input(self):
        """Return the input stream, or None if not available or already consumed."""
        if self._input_consumed or self._input_stream is None:
            return None
        self._input_consumed = True
        return io.BufferedReader(self._input_stream)

    def emit(self, record):
        """Emit a single output record dict."""
        runtime.send_output(record)

    def emit_record(self, record):
        """Emit a single output record (same as emit for Python dicts)."""
        runtime.send_output(record)

    def emit_all(self, records):
        """Emit multiple output records."""
        for record in records:
            runtime.send_output(record)
