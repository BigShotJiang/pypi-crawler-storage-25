"""File system operations — local mode + protocol mode."""

import io
import os
from .. import _runtime as runtime
from .._protocol import b64_encode, b64_decode


def _in_protocol():
    return runtime._initialized


def read(path):
    """Read file contents as bytes."""
    if _in_protocol():
        result = runtime.capability_call("fs", "read", {"path": path})
        return b64_decode(result["content"])
    with open(path, "rb") as f:
        return f.read()


def read_string(path):
    """Read file contents as a string."""
    if _in_protocol():
        result = runtime.capability_call("fs", "read_string", {"path": path})
        return result["content"]
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write(path, data):
    """Write data to a file. Accepts bytes or str."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    if _in_protocol():
        runtime.capability_call("fs", "write", {
            "path": path,
            "content": b64_encode(data),
        })
        return
    with open(path, "wb") as f:
        f.write(data)


def stat(path):
    """Return file metadata dict with size and file_type."""
    if _in_protocol():
        return runtime.capability_call("fs", "stat", {"path": path})
    st = os.stat(path)
    if os.path.isfile(path):
        file_type = "file"
    elif os.path.isdir(path):
        file_type = "dir"
    elif os.path.islink(path):
        file_type = "symlink"
    else:
        file_type = "other"
    return {"size": st.st_size, "file_type": file_type}


def read_dir(path):
    """Return list of directory entries with name, size, file_type."""
    if _in_protocol():
        return runtime.capability_call("fs", "read_dir", {"path": path})
    entries = []
    for name in os.listdir(path):
        full = os.path.join(path, name)
        try:
            st = os.stat(full)
            size = st.st_size
        except OSError:
            size = 0
        if os.path.isfile(full):
            ft = "file"
        elif os.path.isdir(full):
            ft = "dir"
        else:
            ft = "other"
        entries.append({"name": name, "size": size, "file_type": ft})
    return entries


def exists(path):
    """Return True if path exists."""
    if _in_protocol():
        result = runtime.capability_call("fs", "exists", {"path": path})
        return result["exists"]
    return os.path.exists(path)


def open_stream(path):
    """Open a file and return a readable file-like object."""
    if _in_protocol():
        data = read(path)
        return io.BytesIO(data)
    return open(path, "rb")
