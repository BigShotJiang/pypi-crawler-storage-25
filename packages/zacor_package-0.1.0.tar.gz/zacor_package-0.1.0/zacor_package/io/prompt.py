"""Prompt operations — protocol mode only."""

from .. import _runtime as runtime


def confirm(message):
    """Ask a yes/no question. Returns bool."""
    result = runtime.capability_call("prompt", "confirm", {"message": message})
    return result["answer"]


def choose(message, options):
    """Present options and return the chosen string."""
    result = runtime.capability_call("prompt", "choose", {
        "message": message,
        "options": options,
    })
    return result["answer"]


def text(message):
    """Ask for free text input. Returns string."""
    result = runtime.capability_call("prompt", "text", {"message": message})
    return result["answer"]
