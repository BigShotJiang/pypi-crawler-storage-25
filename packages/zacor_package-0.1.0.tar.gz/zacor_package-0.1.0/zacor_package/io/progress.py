"""Progress reporting."""

from .. import _runtime as runtime


def report(fraction):
    """Report progress (0.0 to 1.0). No-op in local mode."""
    if not runtime._initialized:
        return
    runtime.send_progress(fraction)
