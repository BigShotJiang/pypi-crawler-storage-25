"""Protocol runtime: stdin/stdout messaging, reader thread, capability calls."""

import io
import sys
import threading
from . import _protocol as proto


# Global runtime state (set during protocol init)
_lock = threading.Lock()
_stdout_lock = threading.Lock()
_cap_id_counter = 0
_cap_waiters = {}  # id -> threading.Event, result holder
_input_chunks = None  # queue.Queue for INPUT data, or None
_initialized = False


def _next_cap_id():
    global _cap_id_counter
    with _lock:
        _cap_id_counter += 1
        return _cap_id_counter


def _send_raw(line):
    """Write a raw line to stdout (thread-safe)."""
    with _stdout_lock:
        sys.stdout.write(line)
        sys.stdout.flush()


def send_message(msg):
    """Serialize and send a message dict to stdout."""
    _send_raw(proto.serialize(msg))


def send_output(record):
    send_message(proto.make_output(record))


def send_done(exit_code, error=None):
    send_message(proto.make_done(exit_code, error))


def send_progress(fraction):
    send_message(proto.make_progress(fraction))


def capability_call(domain, op, params=None):
    """Send a CAPABILITY_REQ and block until the matching RES arrives."""
    cap_id = _next_cap_id()
    event = threading.Event()
    holder = {"result": None, "error": None}

    with _lock:
        _cap_waiters[cap_id] = (event, holder)

    send_message(proto.make_capability_req(cap_id, domain, op, params))
    event.wait()

    with _lock:
        _cap_waiters.pop(cap_id, None)

    if holder["error"] is not None:
        raise holder["error"]
    return holder["result"]


def _reader_thread(stdin_stream):
    """Background thread that reads stdin and routes messages."""
    global _input_chunks
    for raw_line in stdin_stream:
        line = raw_line.strip()
        if not line:
            continue
        try:
            msg = proto.deserialize(line)
        except Exception:
            continue

        msg_type = msg.get("type")

        if msg_type == "capability_res":
            cap_id = msg.get("id")
            with _lock:
                waiter = _cap_waiters.get(cap_id)
            if waiter:
                event, holder = waiter
                try:
                    holder["result"] = proto.parse_capability_res(msg)
                except IOError as e:
                    holder["error"] = e
                event.set()

        elif msg_type == "input":
            if _input_chunks is not None:
                data = msg.get("data", "")
                eof = msg.get("eof", False)
                _input_chunks.put((data, eof))


def init_invoke():
    """Read the INVOKE message from stdin. Returns (command, args, has_input).

    After calling this, call start_reader() to begin processing
    CAPABILITY_RES and INPUT messages.
    """
    global _initialized, _input_chunks, _cap_id_counter
    import queue

    _initialized = True
    _cap_id_counter = 0

    raw = sys.stdin.readline()
    if not raw:
        raise RuntimeError("no input on stdin")

    msg = proto.deserialize(raw)
    command, args, has_input, _version = proto.parse_invoke(msg)

    if has_input:
        _input_chunks = queue.Queue()
    else:
        _input_chunks = None

    return command, args, has_input


def start_reader():
    """Spawn the background reader thread for stdin messages."""
    t = threading.Thread(target=_reader_thread, args=(sys.stdin,), daemon=True)
    t.name = "zr-protocol-reader"
    t.start()


def make_input_stream():
    """Create a file-like object that reads from INPUT messages. Returns None if no input."""
    if _input_chunks is None:
        return None
    return _InputReader(_input_chunks)


class _InputReader(io.RawIOBase):
    """File-like wrapper over the INPUT message queue."""

    def __init__(self, chunk_queue):
        self._queue = chunk_queue
        self._buf = b""
        self._eof = False

    def readable(self):
        return True

    def readinto(self, b):
        if self._eof and not self._buf:
            return 0

        while not self._buf and not self._eof:
            data, eof = self._queue.get()
            if eof:
                self._eof = True
                break
            if data:
                self._buf = data.encode("utf-8")

        if not self._buf:
            return 0

        n = min(len(b), len(self._buf))
        b[:n] = self._buf[:n]
        self._buf = self._buf[n:]
        return n
