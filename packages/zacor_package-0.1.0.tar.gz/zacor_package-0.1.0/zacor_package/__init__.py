"""zacor-package: Python SDK for building zacor packages."""

import sys
from ._context import Context
from . import _runtime as runtime


def protocol(name, handler):
    """Low-level entry point. Init runtime, call handler(ctx), return exit code.

    Does NOT call sys.exit().
    """
    command, args, has_input = runtime.init_invoke()
    runtime.start_reader()

    input_stream = runtime.make_input_stream()
    ctx = Context(command, args, input_stream)

    try:
        exit_code = handler(ctx)
        if exit_code is None:
            exit_code = 0
        runtime.send_done(exit_code)
        return exit_code
    except Exception as e:
        runtime.send_done(1, str(e))
        return 1


def single_command(name, handler):
    """Run a single-command package. Calls handler(ctx) and exits."""
    sys.exit(protocol(name, handler))


def commands(name, mapping):
    """Run a multi-command package. Dispatches by command name.

    Each handler in mapping receives args dict and returns a list of record dicts.
    """
    def handler(ctx):
        cmd = ctx.command()
        fn = mapping.get(cmd)
        if fn is None:
            raise ValueError(f"unknown command: {cmd}")
        records = fn(ctx.args())
        if records:
            ctx.emit_all(records)
        return 0

    sys.exit(protocol(name, handler))
