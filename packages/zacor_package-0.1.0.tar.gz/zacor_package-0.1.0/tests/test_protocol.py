"""Tests for protocol message round-trips."""

from zacor_package._protocol import (
    make_invoke, make_output, make_done, make_input,
    make_progress, make_capability_req, make_capability_res_ok,
    make_capability_res_error, serialize, deserialize,
    parse_invoke, parse_capability_res,
    b64_encode, b64_decode,
)


def _roundtrip(msg):
    """Serialize then deserialize and verify identity."""
    line = serialize(msg)
    assert line.endswith("\n")
    result = deserialize(line)
    assert result == msg
    return result


def test_invoke_roundtrip():
    msg = make_invoke("default", {"name": "test"})
    result = _roundtrip(msg)
    assert result["type"] == "invoke"
    assert result["command"] == "default"
    assert result["args"] == {"name": "test"}
    assert "input" not in result  # input=False is omitted


def test_invoke_with_input():
    msg = make_invoke("pipe", {"x": 1}, input_=True)
    result = _roundtrip(msg)
    assert result["input"] is True


def test_output_roundtrip():
    msg = make_output({"text": "hello"})
    result = _roundtrip(msg)
    assert result["type"] == "output"
    assert result["record"] == {"text": "hello"}


def test_done_success_roundtrip():
    msg = make_done(0)
    result = _roundtrip(msg)
    assert result["type"] == "done"
    assert result["exit_code"] == 0
    assert "error" not in result


def test_done_error_roundtrip():
    msg = make_done(1, "file not found")
    result = _roundtrip(msg)
    assert result["error"] == "file not found"


def test_input_roundtrip():
    msg = make_input("line1\n")
    result = _roundtrip(msg)
    assert result["type"] == "input"
    assert result["data"] == "line1\n"
    assert "eof" not in result  # eof=False is omitted


def test_input_eof_roundtrip():
    msg = make_input("", eof=True)
    result = _roundtrip(msg)
    assert result["eof"] is True


def test_progress_roundtrip():
    msg = make_progress(0.5)
    result = _roundtrip(msg)
    assert result["type"] == "progress"
    assert result["fraction"] == 0.5


def test_capability_req_roundtrip():
    msg = make_capability_req(1, "fs", "read_string", {"path": "config.yaml"})
    result = _roundtrip(msg)
    assert result["type"] == "capability_req"
    assert result["id"] == 1
    assert result["domain"] == "fs"
    assert result["op"] == "read_string"
    assert result["params"] == {"path": "config.yaml"}


def test_capability_res_ok_roundtrip():
    msg = make_capability_res_ok(1, {"content": "hello"})
    result = _roundtrip(msg)
    assert result["status"] == "ok"
    assert result["data"] == {"content": "hello"}


def test_capability_res_error_roundtrip():
    msg = make_capability_res_error(1, "not_found", "file not found")
    result = _roundtrip(msg)
    assert result["status"] == "error"
    assert result["error"]["kind"] == "not_found"


def test_parse_invoke_valid():
    msg = {"type": "invoke", "command": "default", "args": {"name": "test"}}
    command, args, has_input, version = parse_invoke(msg)
    assert command == "default"
    assert args == {"name": "test"}
    assert has_input is False
    assert version == 1


def test_parse_invoke_invalid():
    import pytest
    with pytest.raises(ValueError, match="expected invoke"):
        parse_invoke({"type": "output", "record": {}})


def test_parse_capability_res_ok():
    msg = {"status": "ok", "data": {"content": "hello"}}
    result = parse_capability_res(msg)
    assert result == {"content": "hello"}


def test_parse_capability_res_error():
    import pytest
    msg = {"status": "error", "error": {"kind": "not_found", "message": "file not found"}}
    with pytest.raises(IOError, match="not_found.*file not found"):
        parse_capability_res(msg)


def test_base64_roundtrip():
    data = b"\x00\x01\x02\xff"
    encoded = b64_encode(data)
    assert isinstance(encoded, str)
    assert b64_decode(encoded) == data
