"""Tests for IO fs (local mode reads/writes)."""

import os
import tempfile
from zacor_package.io import fs
import zacor_package._runtime as runtime


def setup_function():
    """Ensure we're in local mode for these tests."""
    runtime._initialized = False


def test_read_string_local(tmp_path):
    p = tmp_path / "test.txt"
    p.write_text("hello", encoding="utf-8")
    assert fs.read_string(str(p)) == "hello"


def test_read_local(tmp_path):
    p = tmp_path / "test.bin"
    p.write_bytes(b"\x00\x01\x02")
    assert fs.read(str(p)) == b"\x00\x01\x02"


def test_write_local(tmp_path):
    p = tmp_path / "out.txt"
    fs.write(str(p), b"hello")
    assert p.read_bytes() == b"hello"


def test_write_str_local(tmp_path):
    p = tmp_path / "out.txt"
    fs.write(str(p), "hello")
    assert p.read_bytes() == b"hello"


def test_stat_local(tmp_path):
    p = tmp_path / "test.txt"
    p.write_text("hello", encoding="utf-8")
    result = fs.stat(str(p))
    assert result["size"] == 5
    assert result["file_type"] == "file"


def test_stat_dir_local(tmp_path):
    result = fs.stat(str(tmp_path))
    assert result["file_type"] == "dir"


def test_read_dir_local(tmp_path):
    (tmp_path / "a.txt").write_text("a", encoding="utf-8")
    (tmp_path / "b.txt").write_text("bb", encoding="utf-8")
    entries = fs.read_dir(str(tmp_path))
    names = sorted(e["name"] for e in entries)
    assert names == ["a.txt", "b.txt"]


def test_exists_local(tmp_path):
    p = tmp_path / "test.txt"
    assert fs.exists(str(p)) is False
    p.write_text("x", encoding="utf-8")
    assert fs.exists(str(p)) is True


def test_open_stream_local(tmp_path):
    p = tmp_path / "test.txt"
    p.write_bytes(b"stream data")
    with fs.open_stream(str(p)) as f:
        assert f.read() == b"stream data"
