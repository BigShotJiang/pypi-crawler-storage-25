"""Tests for entry points (single_command, commands dispatch, unknown command error)."""

import io
import json
import unittest.mock as mock
import zacor_package._runtime as runtime
from zacor_package import protocol


def _setup_stdin(invoke_msg):
    """Mock stdin with an invoke message followed by EOF."""
    lines = [json.dumps(invoke_msg) + "\n"]
    return io.StringIO("".join(lines))


def _reset_runtime():
    """Reset runtime global state between tests."""
    runtime._initialized = False
    runtime._cap_id_counter = 0
    runtime._cap_waiters = {}
    runtime._input_chunks = None


def test_protocol_success():
    _reset_runtime()
    invoke = {"type": "invoke", "command": "default", "args": {"x": 1}}
    captured = []

    with mock.patch("sys.stdin", _setup_stdin(invoke)), \
         mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:

        def handler(ctx):
            assert ctx.command() == "default"
            assert ctx.args() == {"x": 1}
            ctx.emit({"result": "ok"})
            return 0

        code = protocol("test", handler)

    assert code == 0
    lines = mock_stdout.getvalue().strip().split("\n")
    messages = [json.loads(l) for l in lines]
    assert messages[0]["type"] == "output"
    assert messages[0]["record"] == {"result": "ok"}
    assert messages[1]["type"] == "done"
    assert messages[1]["exit_code"] == 0


def test_protocol_handler_exception():
    _reset_runtime()
    invoke = {"type": "invoke", "command": "default", "args": {}}

    with mock.patch("sys.stdin", _setup_stdin(invoke)), \
         mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:

        def handler(ctx):
            raise ValueError("bad input")

        code = protocol("test", handler)

    assert code == 1
    lines = mock_stdout.getvalue().strip().split("\n")
    done = json.loads(lines[-1])
    assert done["type"] == "done"
    assert done["exit_code"] == 1
    assert done["error"] == "bad input"


def test_commands_dispatch():
    _reset_runtime()
    invoke = {"type": "invoke", "command": "add", "args": {"a": 1, "b": 2}}

    with mock.patch("sys.stdin", _setup_stdin(invoke)), \
         mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:

        def cmd_add(args):
            return [{"sum": args["a"] + args["b"]}]

        # commands() calls sys.exit, so we catch it
        with mock.patch("sys.exit") as mock_exit:
            from zacor_package import commands
            commands("calc", {"add": cmd_add})

        mock_exit.assert_called_once_with(0)

    lines = mock_stdout.getvalue().strip().split("\n")
    messages = [json.loads(l) for l in lines]
    output = messages[0]
    assert output["type"] == "output"
    assert output["record"] == {"sum": 3}


def test_commands_unknown():
    _reset_runtime()
    invoke = {"type": "invoke", "command": "multiply", "args": {}}

    with mock.patch("sys.stdin", _setup_stdin(invoke)), \
         mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:

        with mock.patch("sys.exit") as mock_exit:
            from zacor_package import commands
            commands("calc", {"add": lambda a: []})

        mock_exit.assert_called_once_with(1)

    lines = mock_stdout.getvalue().strip().split("\n")
    done = json.loads(lines[-1])
    assert done["type"] == "done"
    assert done["exit_code"] == 1
    assert "unknown command: multiply" in done["error"]
