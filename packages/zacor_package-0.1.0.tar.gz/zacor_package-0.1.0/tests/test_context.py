"""Tests for Context (args access, input stream, emit)."""

import io
import unittest.mock as mock
from zacor_package._context import Context


def test_command():
    ctx = Context("add", {"a": 1}, None)
    assert ctx.command() == "add"


def test_args():
    ctx = Context("add", {"a": 1, "b": 2}, None)
    assert ctx.args() == {"a": 1, "b": 2}


def test_input_none():
    ctx = Context("cmd", {}, None)
    assert ctx.input() is None


def test_input_stream():
    raw = io.BytesIO(b"hello\nworld\n")

    class FakeRaw(io.RawIOBase):
        def readable(self):
            return True
        def readinto(self, b):
            data = raw.read(len(b))
            n = len(data)
            b[:n] = data
            return n

    ctx = Context("cmd", {}, FakeRaw())
    stream = ctx.input()
    assert stream is not None
    content = stream.read()
    assert content == b"hello\nworld\n"


def test_input_consumed_twice():
    class FakeRaw(io.RawIOBase):
        def readable(self):
            return True
        def readinto(self, b):
            return 0

    ctx = Context("cmd", {}, FakeRaw())
    first = ctx.input()
    assert first is not None
    second = ctx.input()
    assert second is None


@mock.patch("zacor_package._runtime.send_output")
def test_emit(mock_send):
    ctx = Context("cmd", {}, None)
    ctx.emit({"key": "value"})
    mock_send.assert_called_once_with({"key": "value"})


@mock.patch("zacor_package._runtime.send_output")
def test_emit_all(mock_send):
    ctx = Context("cmd", {}, None)
    ctx.emit_all([{"a": 1}, {"a": 2}])
    assert mock_send.call_count == 2
    mock_send.assert_any_call({"a": 1})
    mock_send.assert_any_call({"a": 2})
