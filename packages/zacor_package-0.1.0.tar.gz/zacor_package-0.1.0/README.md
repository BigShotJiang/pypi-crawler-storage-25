# zacor-package

Python SDK for building zacor packages.

## Install

```
pip install zacor-package
```

## Usage

```python
from zacor_package import single_command

def handle(ctx):
    name = ctx.args().get("name", "")
    ctx.emit({"greeting": f"hello {name}"})
    return 0

single_command("greet", handle)
```
