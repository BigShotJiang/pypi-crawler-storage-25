"""Async Confluence REST API client (v1) for Server/Data Center using httpx."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import urllib.parse
from pathlib import Path
from typing import Any

import httpx

from .config import (
    AUTH_TYPE,
    HTTP_PROXY,
    HTTPS_PROXY,
    PASSWORD,
    PERSONAL_TOKEN,
    SSL_VERIFY,
    TIMEOUT,
    URL,
    USERNAME,
)

logger = logging.getLogger("www-confluence-mcp")

# Pre-compiled CQL detection regex — avoids re-compilation on every search() call.
_CQL_FIELD_RE = re.compile(
    r"(?:title|text|space|type|label|creator|contributor|lastmodified|created)"
    r"\s*[=~><]",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Client singleton
# ---------------------------------------------------------------------------

_CLIENT: httpx.AsyncClient | None = None
_CLIENT_LOCK = asyncio.Lock()


async def get_client() -> httpx.AsyncClient:
    """Return (or lazily create) the shared async HTTP client."""
    global _CLIENT
    async with _CLIENT_LOCK:
        if _CLIENT is not None and not _CLIENT.is_closed:
            return _CLIENT

        if not URL or not AUTH_TYPE:
            raise RuntimeError(
                "Confluence is not configured. Set CONFLUENCE_URL and "
                "CONFLUENCE_PERSONAL_TOKEN (or CONFLUENCE_USERNAME + CONFLUENCE_PASSWORD) "
                "environment variables."
            )

        base = URL.rstrip("/")

        headers: dict[str, str] = {
            "Accept": "application/json",
        }

        if AUTH_TYPE == "pat":
            headers["Authorization"] = f"Bearer {PERSONAL_TOKEN}"
        else:
            credentials = base64.b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"

        proxy = HTTPS_PROXY or HTTP_PROXY
        _CLIENT = httpx.AsyncClient(
            base_url=base,
            headers=headers,
            timeout=TIMEOUT,
            verify=SSL_VERIFY,
            proxy=proxy,
            follow_redirects=True,
        )
        return _CLIENT


async def close_client() -> None:
    """Close the shared HTTP client."""
    global _CLIENT
    async with _CLIENT_LOCK:
        try:
            if _CLIENT is not None:
                await _CLIENT.aclose()
        finally:
            _CLIENT = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _v1(path: str) -> str:
    """Prepend the v1 (REST) API prefix."""
    return f"/rest/api{path}"


def _safe_path_segment(segment: str) -> str:
    """URL-encode a path segment to prevent path injection via '/' or special chars."""
    return urllib.parse.quote(str(segment), safe="")


def _join_download_url(base: str, relative: str) -> str:
    """Join a base URL with a relative download path, ensuring exactly one '/'."""
    base = base.rstrip("/")
    relative = relative.lstrip("/")
    return f"{base}/{relative}"


async def _request(method: str, url: str, **kwargs: Any) -> Any:
    """Make an API request and return parsed JSON. Raises on HTTP errors."""
    client = await get_client()
    try:
        resp = await client.request(method, url, **kwargs)
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        body = exc.response.text[:500]
        raise RuntimeError(
            f"Confluence API error {exc.response.status_code}: {body}"
        ) from exc
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Confluence request failed: {exc}") from exc

    if resp.status_code == 204 or not resp.content:
        return None
    try:
        return resp.json()
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(
            f"Confluence returned non-JSON response (status {resp.status_code}): {resp.text[:300]}"
        ) from exc


# ---------------------------------------------------------------------------
# Spaces (v1)
# ---------------------------------------------------------------------------


async def get_spaces(
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """List Confluence spaces (v1)."""
    return await _request("GET", _v1("/space"), params={"limit": limit, "start": start})


async def get_space(space_key: str) -> dict[str, Any]:
    """Get a space by its key (v1)."""
    return await _request("GET", _v1(f"/space/{_safe_path_segment(space_key)}"))


# ---------------------------------------------------------------------------
# Pages / Content (v1)
# ---------------------------------------------------------------------------


async def get_page(
    page_id: str,
    body_format: str = "storage",
) -> dict[str, Any]:
    """Get a page by ID (v1 content endpoint)."""
    expand = f"body.{body_format},version,space,ancestors"
    return await _request(
        "GET",
        _v1(f"/content/{_safe_path_segment(page_id)}"),
        params={"expand": expand},
    )


async def get_page_by_title(
    space_key: str,
    title: str,
    body_format: str = "storage",
) -> dict[str, Any]:
    """Look up a page by exact title within a space (v1)."""
    results = await _request(
        "GET",
        _v1("/content"),
        params={
            "spaceKey": space_key,
            "title": title,
            "expand": f"body.{body_format},version,space",
        },
    )
    if results is None:
        raise ValueError(f"Page '{title}' not found in space '{space_key}'")
    pages = results.get("results", [])
    if not pages:
        raise ValueError(f"Page '{title}' not found in space '{space_key}'")
    return pages[0]


async def get_pages_in_space(
    space_key: str,
    title: str | None = None,
    status: str = "current",
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """List pages in a space (v1 content endpoint)."""
    params: dict[str, Any] = {
        "spaceKey": space_key,
        "status": status,
        "limit": limit,
        "start": start,
        "expand": "version,space",
    }
    if title:
        params["title"] = title
    return await _request("GET", _v1("/content"), params=params)


async def get_child_pages(
    page_id: str,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """Get child pages of a page (v1)."""
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version,space"}
    return await _request(
        "GET", _v1(f"/content/{_safe_path_segment(page_id)}/child/page"), params=params
    )


async def get_page_ancestors(page_id: str) -> dict[str, Any]:
    """Get ancestor pages (breadcrumb) by expanding ancestors on the page (v1)."""
    data = await _request(
        "GET",
        _v1(f"/content/{_safe_path_segment(page_id)}"),
        params={"expand": "ancestors"},
    )
    if data is None:
        return {"results": []}
    return {"results": data.get("ancestors", [])}


async def create_page(
    space_key: str,
    title: str,
    body_value: str,
    parent_id: str | None = None,
    body_representation: str = "storage",
    status: str = "current",
) -> dict[str, Any]:
    """Create a new page (v1 content endpoint)."""
    payload: dict[str, Any] = {
        "type": "page",
        "title": title,
        "space": {"key": space_key},
        "body": {body_representation: {"value": body_value, "representation": body_representation}},
        "status": status,
    }
    if parent_id:
        payload["ancestors"] = [{"id": parent_id}]
    return await _request("POST", _v1("/content"), json=payload)


async def update_page(
    page_id: str,
    title: str,
    body_value: str,
    version_number: int,
    body_representation: str = "storage",
    status: str = "current",
) -> dict[str, Any]:
    """Update an existing page (v1 content endpoint)."""
    payload: dict[str, Any] = {
        "type": "page",
        "title": title,
        "version": {"number": version_number, "message": "Updated via MCP"},
        "body": {body_representation: {"value": body_value, "representation": body_representation}},
        "status": status,
    }
    return await _request(
        "PUT", _v1(f"/content/{_safe_path_segment(page_id)}"), json=payload
    )


async def delete_page(page_id: str) -> None:
    """Delete a page (v1 content endpoint)."""
    await _request("DELETE", _v1(f"/content/{_safe_path_segment(page_id)}"))


# ---------------------------------------------------------------------------
# Labels (v1)
# ---------------------------------------------------------------------------


async def get_page_labels(page_id: str) -> dict[str, Any]:
    """Get labels on a page (v1)."""
    return await _request("GET", _v1(f"/content/{_safe_path_segment(page_id)}/label"))


async def add_page_labels(page_id: str, labels: list[str]) -> dict[str, Any]:
    """Add labels to a page (v1)."""
    payload = [{"prefix": "global", "name": lbl} for lbl in labels]
    return await _request(
        "POST", _v1(f"/content/{_safe_path_segment(page_id)}/label"), json=payload
    )


async def delete_page_label(page_id: str, label: str) -> None:
    """Remove a label from a page (v1)."""
    encoded_id = _safe_path_segment(page_id)
    encoded_label = urllib.parse.quote(label, safe="")
    await _request("DELETE", _v1(f"/content/{encoded_id}/label/{encoded_label}"))


# ---------------------------------------------------------------------------
# Comments (v1)
# ---------------------------------------------------------------------------


async def get_footer_comments(
    page_id: str,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """Get footer comments on a page (v1 child endpoint)."""
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version"}
    return await _request(
        "GET", _v1(f"/content/{_safe_path_segment(page_id)}/child/comment"), params=params
    )


async def create_comment(
    page_id: str,
    body_value: str,
) -> dict[str, Any]:
    """Add a comment to a page (v1 content endpoint)."""
    payload: dict[str, Any] = {
        "type": "comment",
        "body": {"storage": {"value": body_value, "representation": "storage"}},
        "container": {"id": page_id, "type": "page"},
    }
    return await _request("POST", _v1("/content"), json=payload)


async def reply_to_comment(
    comment_id: str,
    body_value: str,
) -> dict[str, Any]:
    """Reply to an existing comment (v1 content endpoint)."""
    payload: dict[str, Any] = {
        "type": "comment",
        "body": {"storage": {"value": body_value, "representation": "storage"}},
        "container": {"id": comment_id, "type": "comment"},
    }
    return await _request("POST", _v1("/content"), json=payload)


# ---------------------------------------------------------------------------
# Search (v1 CQL)
# ---------------------------------------------------------------------------


async def search(
    query: str,
    spaces: list[str] | None = None,
    content_types: list[str] | None = None,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """Search Confluence content using CQL via the v1 REST API."""
    cql_parts: list[str] = []

    def _esc(val: str) -> str:
        """Escape backslashes and double-quotes for CQL string literals."""
        return val.replace("\\", "\\\\").replace('"', r'\"')

    # Detect if query is already CQL — require structural patterns to avoid
    # false positives on queries like "price > 100" or "a = b".
    has_cql = bool(_CQL_FIELD_RE.search(query)) or any(
        f" {kw} " in query.upper() for kw in ("AND", "OR", "NOT")
    ) or "ORDER BY " in query.upper()

    if has_cql:
        cql_parts.append(query)
    else:
        cql_parts.append(f'text ~ "{_esc(query)}"')

    if spaces:
        space_clause = " OR ".join(f'space = "{_esc(s)}"' for s in spaces)
        cql_parts.append(f"({space_clause})")
    if content_types:
        type_clause = " OR ".join(f'type = "{_esc(t)}"' for t in content_types)
        cql_parts.append(f"({type_clause})")

    cql = " AND ".join(cql_parts)

    params: dict[str, Any] = {
        "cql": cql,
        "limit": limit,
        "start": start,
        "expand": "space,version,ancestors",
    }
    return await _request("GET", _v1("/content/search"), params=params)


# ---------------------------------------------------------------------------
# Attachments (v1)
# ---------------------------------------------------------------------------


async def get_attachments(
    page_id: str,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """List attachments on a page (v1)."""
    params: dict[str, Any] = {"limit": limit, "start": start, "expand": "version"}
    return await _request(
        "GET", _v1(f"/content/{_safe_path_segment(page_id)}/child/attachment"), params=params
    )


async def upload_attachment(
    page_id: str,
    file_path: str,
    comment: str = "",
) -> dict[str, Any]:
    """Upload a file as an attachment to a Confluence page (v1 multipart)."""
    client = await get_client()
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")

    url = _v1(f"/content/{_safe_path_segment(page_id)}/child/attachment")

    with open(path, "rb") as fobj:
        files = {"file": (path.name, fobj)}
        data: dict[str, str] = {}
        if comment:
            data["comment"] = comment

        headers = {"X-Atlassian-Token": "no-check"}

        try:
            resp = await client.post(url, files=files, data=data, headers=headers)
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(
                f"Failed to upload attachment: {exc.response.status_code} {exc.response.text[:300]}"
            ) from exc
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Failed to upload attachment: {exc}") from exc

    try:
        return resp.json()
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(
            f"Confluence returned non-JSON response after upload (status {resp.status_code}): {resp.text[:300]}"
        ) from exc
    except UnboundLocalError:
        raise RuntimeError("Upload failed: no response received from Confluence")


async def download_attachment(
    attachment_id: str,
    save_path: str,
) -> dict[str, Any]:
    """Download an attachment by its content ID and save to disk (v1)."""
    client = await get_client()

    # Get attachment metadata via v1 content endpoint
    attach_data = await _request(
        "GET", _v1(f"/content/{_safe_path_segment(attachment_id)}"),
        params={"expand": "version"},
    )
    if attach_data is None:
        raise ValueError(f"Attachment {attachment_id} not found")

    download_link = ""
    links = attach_data.get("_links", {})
    dl = links.get("download", "")
    if dl:
        download_link = _join_download_url(str(client.base_url), dl)

    if not download_link:
        raise ValueError(f"Cannot determine download URL for attachment {attachment_id}")

    target = Path(save_path).resolve()
    if target.exists() and target.is_dir():
        raise ValueError(f"save_path must be a file path, not a directory: {save_path}")
    target.parent.mkdir(parents=True, exist_ok=True)

    try:
        total_bytes = 0
        async with client.stream("GET", download_link) as resp:
            resp.raise_for_status()
            with open(target, "wb") as fout:
                async for chunk in resp.aiter_bytes():
                    fout.write(chunk)
                    total_bytes += len(chunk)
    except httpx.HTTPError as exc:
        if target.exists():
            target.unlink(missing_ok=True)
        raise RuntimeError(f"Failed to download attachment: {exc}") from exc
    except OSError as exc:
        if target.exists():
            target.unlink(missing_ok=True)
        raise RuntimeError(f"Failed to save attachment to disk: {exc}") from exc

    return {
        "status": "downloaded",
        "attachment_id": attachment_id,
        "saved_to": str(target),
        "bytes": total_bytes,
    }


async def delete_attachment(attachment_id: str) -> None:
    """Delete an attachment by its content ID (v1)."""
    await _request("DELETE", _v1(f"/content/{_safe_path_segment(attachment_id)}"))


async def _fetch_all_attachments(page_id: str) -> list[dict[str, Any]]:
    """Fetch all attachments for a page, handling v1 pagination."""
    all_attachments: list[dict[str, Any]] = []
    start = 0
    page_size = 100
    max_iterations = 200  # Safety limit
    for _ in range(max_iterations):
        params: dict[str, Any] = {"limit": page_size, "start": start, "expand": "version"}
        data = await _request(
            "GET", _v1(f"/content/{_safe_path_segment(page_id)}/child/attachment"), params=params
        )
        if data is None:
            break
        batch = data.get("results", [])
        all_attachments.extend(batch)
        # v1 pagination: check _links.next
        next_url = data.get("_links", {}).get("next")
        if not batch or not next_url:
            break
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(next_url).query)
        next_start = qs.get("start", [None])[0]
        if next_start is not None:
            try:
                start = int(next_start)
            except (ValueError, TypeError):
                start += len(batch)
        else:
            start += len(batch)
    return all_attachments


async def download_content_attachments(
    content_id: str,
    save_dir: str,
) -> list[dict[str, Any]]:
    """Download all attachments for a content item to a directory."""
    client = await get_client()
    results = await _fetch_all_attachments(content_id)
    if not results:
        return []

    save_path = Path(save_dir)
    save_path.mkdir(parents=True, exist_ok=True)

    downloaded: list[dict[str, Any]] = []
    used_names: set[str] = set()
    for att in results:
        att_id = att.get("id") or "unknown"
        title = att.get("title", "") or f"attachment_{att_id}"

        download_link = ""
        links = att.get("_links", {})
        dl = links.get("download", "")
        if dl:
            download_link = _join_download_url(str(client.base_url), dl)

        if not download_link:
            downloaded.append({"id": att_id, "status": "skipped", "reason": "no download URL"})
            continue

        # Avoid overwriting files with the same name
        safe_name = Path(title).name
        # Guard against path traversal: reject "." and ".." names
        if safe_name in (".", ".."):
            safe_name = f"attachment_{att_id}"
        if safe_name in used_names:
            stem = Path(safe_name).stem
            suffix = Path(safe_name).suffix
            safe_name = f"{stem}_{att_id}{suffix}"
        used_names.add(safe_name)
        target = save_path / safe_name
        try:
            total_bytes = 0
            async with client.stream("GET", download_link) as resp:
                resp.raise_for_status()
                with open(target, "wb") as fout:
                    async for chunk in resp.aiter_bytes():
                        fout.write(chunk)
                        total_bytes += len(chunk)
            downloaded.append({"id": att_id, "title": title, "bytes": total_bytes, "saved_to": str(target), "status": "downloaded"})
        except httpx.HTTPError as exc:
            if target.exists():
                target.unlink(missing_ok=True)
            downloaded.append({"id": att_id, "title": title, "status": "error", "reason": str(exc)})
        except OSError as exc:
            if target.exists():
                target.unlink(missing_ok=True)
            downloaded.append({"id": att_id, "title": title, "status": "error", "reason": f"Disk write error: {exc}"})

    return downloaded


# ---------------------------------------------------------------------------
# Page history (v1)
# ---------------------------------------------------------------------------


async def get_page_history(
    page_id: str,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """Get page version history (v1 — uses content expand=version+history).

    Returns structured metadata about the page's creation and current version.
    """
    data = await _request(
        "GET",
        _v1(f"/content/{_safe_path_segment(page_id)}"),
        params={"expand": "version,history"},
    )
    if data is None:
        return {"page_id": page_id, "version": {}, "history": {}}

    version = data.get("version", {})
    history = data.get("history", {})

    return {
        "page_id": page_id,
        "title": data.get("title", ""),
        "version": {
            "number": version.get("number"),
            "by": version.get("by", {}).get("displayName", ""),
            "when": version.get("when", ""),
            "message": version.get("message", ""),
        },
        "history": {
            "created_by": history.get("createdBy", {}).get("displayName", ""),
            "created_date": history.get("createdDate", ""),
            "last_updated_by": history.get("lastUpdated", {}).get("by", {}).get("displayName", ""),
            "last_updated_date": history.get("lastUpdated", {}).get("when", ""),
        },
    }


# ---------------------------------------------------------------------------
# Move page (v1)
# ---------------------------------------------------------------------------


async def move_page(
    page_id: str,
    space_key: str | None = None,
    parent_id: str | None = None,
) -> dict[str, Any]:
    """Move a page to a different space and/or parent (v1).

    Requires fetching the current page first to send a complete update payload.
    """
    current = await _request(
        "GET", _v1(f"/content/{_safe_path_segment(page_id)}"),
        params={"expand": "body.storage,version,space,ancestors"},
    )
    if not current:
        raise RuntimeError(f"Failed to fetch page {page_id} for move")

    version = current.get("version", {}).get("number") or 0
    body_storage = current.get("body", {}).get("storage", {})

    payload: dict[str, Any] = {
        "type": "page",
        "title": current.get("title", ""),
        "version": {"number": version + 1, "message": "Moved via MCP"},
        "body": {"storage": {"value": body_storage.get("value", ""), "representation": "storage"}},
        "status": current.get("status", "current"),
    }

    # Set space — use new space_key or keep current
    current_space = current.get("space", {}).get("key")
    target_space = space_key or current_space
    if target_space:
        payload["space"] = {"key": target_space}

    # Set parent — only if explicitly provided or keeping current parent
    if parent_id:
        payload["ancestors"] = [{"id": parent_id}]
    elif not space_key:
        # Keep current parent only if not changing space
        ancestors = current.get("ancestors", [])
        if ancestors:
            payload["ancestors"] = [{"id": ancestors[-1].get("id")}]

    return await _request(
        "PUT", _v1(f"/content/{_safe_path_segment(page_id)}"), json=payload
    )


# ---------------------------------------------------------------------------
# Users (v1)
# ---------------------------------------------------------------------------


async def search_user(
    query: str,
    limit: int = 25,
    start: int = 0,
) -> dict[str, Any]:
    """Search for users (v1 CQL search)."""
    def _esc(val: str) -> str:
        """Escape backslashes and double-quotes for CQL string literals."""
        return val.replace("\\", "\\\\").replace('"', r'\"')
    cql = f'type=user AND user.fullname ~ "{_esc(query)}"'
    return await _request(
        "GET", _v1("/search"),
        params={"cql": cql, "limit": limit, "start": start},
    )


# ---------------------------------------------------------------------------
# Batch uploads
# ---------------------------------------------------------------------------


async def upload_attachments(
    page_id: str,
    file_paths: list[str],
    comment: str = "",
) -> list[dict[str, Any]]:
    """Upload multiple files as attachments to a Confluence page."""
    results: list[dict[str, Any]] = []
    for fp in file_paths:
        try:
            data = await upload_attachment(page_id, fp, comment=comment)
            if isinstance(data, dict):
                uploaded = data.get("results", [])
                if not uploaded and data.get("id"):
                    uploaded = [data]
            else:
                uploaded = []
            for att in uploaded:
                results.append({"id": att.get("id"), "title": att.get("title"), "status": "uploaded"})
        except Exception as exc:
            if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                raise
            path = Path(fp)
            results.append({"title": path.name, "status": "error", "reason": str(exc)})
    return results


# ---------------------------------------------------------------------------
# Space page tree (v1)
# ---------------------------------------------------------------------------


async def get_space_page_tree(
    space_key: str,
    limit: int = 500,
) -> dict[str, Any]:
    """Get hierarchical page tree for a space as a flat list (v1)."""
    all_pages: list[dict[str, Any]] = []
    start = 0
    page_size = 200
    next_link: str | None = None
    batch: list[dict[str, Any]] = []
    max_iterations = 500  # Safety limit

    for _ in range(max_iterations):
        if len(all_pages) >= limit:
            break
        fetch_limit = min(page_size, limit - len(all_pages))
        params: dict[str, Any] = {
            "spaceKey": space_key,
            "limit": fetch_limit,
            "start": start,
            "expand": "ancestors",
            "status": "current",
        }
        data = await _request("GET", _v1("/content"), params=params)
        if data is None:
            break
        batch = data.get("results", [])
        all_pages.extend(batch)
        next_link = data.get("_links", {}).get("next")
        if not batch or not next_link:
            break
        qs_next = urllib.parse.parse_qs(urllib.parse.urlparse(next_link).query)
        next_start = qs_next.get("start", [None])[0]
        if next_start is not None:
            try:
                start = int(next_start)
            except (ValueError, TypeError):
                start += len(batch)
        else:
            start += len(batch)

    has_more = bool(batch) and len(all_pages) >= limit and bool(next_link)

    result_pages = []
    for page in all_pages:
        page_id = page.get("id")
        title = page.get("title", "Untitled")
        position = page.get("extensions", {}).get("position")
        ancestors = page.get("ancestors", [])
        if ancestors:
            parent_id = ancestors[-1].get("id")
            depth = len(ancestors)
        else:
            parent_id = None
            depth = 0
        result_pages.append({
            "id": page_id,
            "title": title,
            "parent_id": parent_id,
            "position": position,
            "depth": depth,
        })

    result_pages.sort(key=lambda p: (
        p["depth"],
        p["position"] if p["position"] is not None else 999999,
        p["title"],
    ))

    return {
        "space_key": space_key,
        "total_pages": len(result_pages),
        "has_more": has_more,
        "pages": result_pages,
    }


# ---------------------------------------------------------------------------
# Page images
# ---------------------------------------------------------------------------

_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"}
_IMAGE_MIME_TYPES = {"image/png", "image/jpeg", "image/gif", "image/webp", "image/svg+xml", "image/bmp"}


def _is_image(mime_type: str | None, filename: str | None) -> bool:
    """Check if an attachment is an image by MIME type or filename."""
    if mime_type and mime_type.lower() in _IMAGE_MIME_TYPES:
        return True
    if filename:
        ext = Path(filename).suffix.lower()
        if ext in _IMAGE_EXTENSIONS:
            return True
    return False


_MAX_IMAGE_BYTES = 10 * 1024 * 1024  # 10 MB — skip images larger than this


async def get_page_images(
    page_id: str,
) -> list[dict[str, Any]]:
    """Get all images attached to a page, returning base64-encoded data."""
    client = await get_client()
    results = await _fetch_all_attachments(page_id)
    if not results:
        return []

    images: list[dict[str, Any]] = []
    for att in results:
        media_type = att.get("extensions", {}).get("mediaType", "") or att.get("metadata", {}).get("mediaType", "")
        filename = att.get("title", "")
        if not _is_image(media_type, filename):
            continue

        download_link = ""
        links = att.get("_links", {})
        dl = links.get("download", "")
        if dl:
            download_link = _join_download_url(str(client.base_url), dl)

        if not download_link:
            continue

        try:
            # Check size via Content-Length header before downloading the full body
            resp = await client.head(download_link)
            if resp.status_code == 200:
                content_length = resp.headers.get("content-length")
                if content_length and int(content_length) > _MAX_IMAGE_BYTES:
                    images.append({
                        "id": att.get("id"),
                        "title": filename,
                        "status": "skipped",
                        "reason": f"Image too large ({content_length} bytes, max {_MAX_IMAGE_BYTES})",
                    })
                    continue
            # Fallback: GET the full body and check size
            resp = await client.get(download_link)
            resp.raise_for_status()
            if len(resp.content) > _MAX_IMAGE_BYTES:
                images.append({
                    "id": att.get("id"),
                    "title": filename,
                    "status": "skipped",
                    "reason": f"Image too large ({len(resp.content)} bytes, max {_MAX_IMAGE_BYTES})",
                })
                continue
            encoded = base64.b64encode(resp.content).decode()
            resolved_mime = media_type if media_type and media_type.lower() in _IMAGE_MIME_TYPES else "image/png"
            images.append({
                "id": att.get("id"),
                "title": filename,
                "mime_type": resolved_mime,
                "size": len(resp.content),
                "data": encoded,
            })
        except httpx.HTTPError as exc:
            images.append({
                "id": att.get("id"),
                "title": filename,
                "status": "error",
                "reason": str(exc),
            })

    return images


# ---------------------------------------------------------------------------
# Template distribution
# ---------------------------------------------------------------------------


async def apply_template(
    template_page: str,
    target_page_list: list[str],
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Update existing pages with the body from a template page.

    Reads the template page body (Storage Format), then updates each
    target page with that body — keeping the target's own title, space,
    and location in the page tree.

    Use ``dry_run=True`` to preview what would be updated without
    making any changes.
    """
    # 1. Fetch the template page
    template = await _request(
        "GET",
        _v1(f"/content/{_safe_path_segment(template_page)}"),
        params={"expand": "body.storage,version,space"},
    )
    if not template:
        raise ValueError(f"Template page {template_page} not found or empty response")
    template_title = template.get("title", "")
    template_body = template.get("body", {}).get("storage", {}).get("value", "")

    report: list[dict[str, Any]] = []

    for page_id in target_page_list:
        page_id = page_id.strip()
        if not page_id:
            continue

        entry: dict[str, Any] = {
            "page_id": page_id,
            "action": "skipped",
        }

        try:
            # 2. Fetch current page to get title + version
            current = await _request(
                "GET",
                _v1(f"/content/{_safe_path_segment(page_id)}"),
                params={"expand": "version,space"},
            )

            page_title = current.get("title", "")
            space_key = current.get("space", {}).get("key", "")
            current_version = current.get("version", {}).get("number", 0)

            entry["title"] = page_title
            entry["space"] = space_key
            entry["current_version"] = current_version

            if dry_run:
                entry["action"] = "would_update"
            else:
                await update_page(
                    page_id=page_id,
                    title=page_title,
                    body_value=template_body,
                    version_number=current_version + 1,
                )
                entry["action"] = "updated"
                entry["new_version"] = current_version + 1

        except Exception as exc:
            entry["action"] = "error"
            entry["reason"] = str(exc)

        report.append(entry)

    return {
        "status": "success",
        "template_page": template_page,
        "template_title": template_title,
        "pages_processed": len(report),
        "dry_run": dry_run,
        "results": report,
    }
