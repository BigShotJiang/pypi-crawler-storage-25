"""MCP server for Confluence Server/Data Center integration."""

from __future__ import annotations

import logging
import os

from mcp.server.fastmcp import FastMCP

from .config import READ_ONLY

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.DEBUG if os.getenv("CONFLUENCE_DEBUG") else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("www-confluence-mcp")

# ---------------------------------------------------------------------------
# MCP instance
# ---------------------------------------------------------------------------

_READ_INSTRUCTIONS = (
    "Confluence Server/Data Center integration tools.\n"
    "\nSearch & Navigation:\n"
    "- confluence_search: Search content by text or CQL query.\n"
    "- confluence_get_page: Get page by ID or by title + space_key.\n"
    "- confluence_get_page_children: Get child pages of a page.\n"
    "- confluence_get_page_ancestors: Get ancestor pages (breadcrumb).\n"
    "\nSpaces:\n"
    "- confluence_get_spaces: List Confluence spaces.\n"
    "- confluence_get_space: Get space by key.\n"
    "\nComments:\n"
    "- confluence_get_comments: Get comments on a page.\n"
    "\nLabels:\n"
    "- confluence_get_labels: Get labels on a page.\n"
    "\nAttachments:\n"
    "- confluence_get_attachments: List attachments on a page.\n"
    "- confluence_download_attachment: Download a single attachment.\n"
    "- confluence_download_content_attachments: Download all attachments.\n"
    "\nPages:\n"
    "- confluence_get_pages_in_space: List pages in a space.\n"
    "- confluence_get_page_history: Get page version history.\n"
    "\nUsers:\n"
    "- confluence_search_user: Search for users.\n"
    "\nPage tree & images:\n"
    "- confluence_get_space_page_tree: Get space page hierarchy.\n"
    "- confluence_get_page_images: Get page images as base64.\n"
)

_WRITE_INSTRUCTIONS = (
    "\nComments:\n"
    "- confluence_add_comment: Add a comment to a page.\n"
    "\nLabels:\n"
    "- confluence_add_labels: Add labels to a page.\n"
    "- confluence_delete_label: Remove a label from a page.\n"
    "\nAttachments:\n"
    "- confluence_upload_attachment: Upload a file to a page.\n"
    "- confluence_upload_attachments: Upload multiple files at once.\n"
    "- confluence_delete_attachment: Delete an attachment.\n"
    "\nPage CRUD:\n"
    "- confluence_create_page: Create a new page.\n"
    "- confluence_update_page: Update an existing page (requires version_number).\n"
    "- confluence_delete_page: Delete a page.\n"
    "- confluence_move_page: Move page to another space/parent.\n"
    "- confluence_reply_to_comment: Reply to a comment.\n"
    "\nTemplates:\n"
    "- confluence_apply_template: Apply template body to existing pages (dry_run supported).\n"
    "\nPrompt management:\n"
    "- confluence_generate_prompt: Create custom prompts from JSON definitions.\n"
    "- confluence_list_prompts: List loaded external prompts.\n"
)

mcp = FastMCP(
    name="www-confluence-mcp",
    instructions=_READ_INSTRUCTIONS + (_WRITE_INSTRUCTIONS if not READ_ONLY else ""),
)

# ---------------------------------------------------------------------------
# Load tools
# ---------------------------------------------------------------------------

from . import read_tools  # noqa: F401, E402 — always loaded, registers read tools on mcp
from . import resources  # noqa: F401, E402 — registers MCP resources
from . import prompt_generate  # noqa: F401, E402 — registers prompt generation/listing tools

if not READ_ONLY:
    from . import write_tools  # noqa: F401, E402 — only when writes are enabled

# ---------------------------------------------------------------------------
# Load prompts from bundled defaults + user directory
# ---------------------------------------------------------------------------
from pathlib import Path  # noqa: E402

from .config import PROMPTS_DIR  # noqa: E402
from .prompt_loader import load_prompts_from_dir  # noqa: E402

# Built-in prompts shipped with the package
_builtin_dir = Path(__file__).parent / "prompts.d"
_count = load_prompts_from_dir(_builtin_dir)
if _count:
    logger.info("Loaded %d built-in prompt(s)", _count)

# User-defined prompts (override built-ins if same name)
if PROMPTS_DIR:
    _count = load_prompts_from_dir(Path(PROMPTS_DIR))
    if _count:
        logger.info("Loaded %d user prompt(s) from %s", _count, PROMPTS_DIR)


def main() -> None:
    logger.info("Starting www-confluence-mcp (READ_ONLY=%s)", READ_ONLY)
    mcp.run(transport="stdio")
