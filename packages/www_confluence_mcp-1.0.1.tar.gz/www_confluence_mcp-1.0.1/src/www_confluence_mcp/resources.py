"""MCP Resources — reference data that AI can read on demand."""

from __future__ import annotations

from . import client
from .server import mcp


@mcp.resource("confluence://spaces")
async def spaces_resource() -> str:
    """Available Confluence spaces (key: name)."""
    data = await client.get_spaces(limit=200)
    if not data:
        return "No spaces found."
    lines = []
    for s in data.get("results", []):
        lines.append(f"{s.get('key', '?')}: {s.get('name', '')}")
    return "\n".join(lines) if lines else "No spaces found."


@mcp.resource("confluence://space/{space_key}/pages")
async def space_pages_resource(space_key: str) -> str:
    """Pages in a Confluence space (first 100)."""
    data = await client.get_pages_in_space(space_key, limit=100)
    if not data:
        return f"No pages found in space '{space_key}'."
    lines = []
    for p in data.get("results", []):
        lines.append(f"{p.get('id')}: {p.get('title', '')}")
    return "\n".join(lines) if lines else f"No pages found in space '{space_key}'."
