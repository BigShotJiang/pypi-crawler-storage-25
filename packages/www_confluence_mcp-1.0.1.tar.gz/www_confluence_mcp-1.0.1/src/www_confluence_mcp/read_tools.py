"""Read tools for Confluence MCP server — always loaded (Server/DC v1 API)."""

from __future__ import annotations

import logging
import urllib.parse
from typing import Any
from urllib.parse import parse_qs, urlparse

from . import client as api
from .config import MAX_RESULTS, SPACES_FILTER
from .server import mcp

logger = logging.getLogger("www-confluence-mcp")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validate_id(value: str, name: str = "id") -> str:
    """Strip and validate a required ID/path parameter."""
    value = value.strip()
    if not value:
        raise ValueError(f"{name} must not be empty")
    return value


def _apply_spaces_filter(spaces: list[str] | None) -> list[str] | None:
    """Return caller-provided spaces, or fall back to the global SPACES_FILTER."""
    if spaces:
        return spaces
    if SPACES_FILTER:
        return [s.strip() for s in SPACES_FILTER.split(",") if s.strip()]
    return None


def _parse_confluence_url(url: str) -> dict[str, str]:
    """Extract page_id and/or space_key from a Confluence URL.

    Supported formats:
      Server/DC: /pages/viewpage.action?pageId=123
      Display:   /display/TEAM/Page+Title
    """
    import re

    parsed = urlparse(url)
    result: dict[str, str] = {}

    # /pages/viewpage.action?pageId=123
    qs = parse_qs(parsed.query)
    if "pageId" in qs:
        result["page_id"] = qs["pageId"][0]

    # /spaces/TEAM/pages/123/... (rare on Server/DC but possible)
    m = re.search(r"/spaces/([^/]+)/pages/(\d+)", parsed.path)
    if m:
        result.setdefault("space_key", m.group(1))
        result.setdefault("page_id", m.group(2))

    # /display/TEAM/Page+Title  (may have context path prefix like /confluence)
    m = re.search(r"/display/([^/]+)/([^?]+)", parsed.path)
    if m:
        result.setdefault("space_key", m.group(1))
        result.setdefault("title", urllib.parse.unquote_plus(m.group(2).rstrip("/")))

    return result


def _extract_next_start(links: dict[str, Any]) -> str | None:
    """Extract the next-page start offset from API _links.next (v1 pagination)."""
    next_url = links.get("next")
    if not next_url:
        return None
    qs = parse_qs(urlparse(next_url).query)
    return qs.get("start", [None])[0]


# ===================================================================
# READ TOOLS (15 total)
# ===================================================================

# ---------------------------------------------------------------------------
# Tool: confluence_search
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_search",
    title="Confluence Search",
    description=(
        "Search Confluence content using CQL (Confluence Query Language) or simple text queries. "
        "Use when user asks about Confluence pages, documentation, wiki content, "
        "or any topic that might be documented in Confluence. "
        "CQL examples: 'type=page AND space=DEV', 'title~\"Meeting Notes\"', 'label=documentation'. "
        "For simple queries, wraps in 'text ~ \"query\"' automatically. "
        "Returns title, id, type, excerpt for each result."
    ),
)
async def confluence_search(
    query: str,
    spaces: list[str] | None = None,
    content_types: list[str] | None = None,
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    spaces = _apply_spaces_filter(spaces)
    logger.info("confluence_search: query=%r limit=%d", query, limit)
    start_int = int(start) if start else 0
    data = await api.search(query, spaces=spaces, content_types=content_types, limit=limit, start=start_int)
    if data is None:
        return {"status": "no_results", "query": query, "result_count": 0, "results": []}
    results = data.get("results", [])
    links = data.get("_links", {})
    return {
        "status": "ok" if results else "no_results",
        "query": query,
        "result_count": len(results),
        "results": results,
        "next_start": _extract_next_start(links),
    }


# ---------------------------------------------------------------------------
# Tool: confluence_get_page
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_page",
    title="Get Confluence Page",
    description=(
        "Get a Confluence page by its ID, by title and space_key, or by passing a full Confluence URL. "
        "Supported URL formats: "
        "'https://confluence.example.com/pages/viewpage.action?pageId=123', "
        "'https://confluence.example.com/display/TEAM/Page+Title'."
    ),
)
async def confluence_get_page(
    page_id: str | None = None,
    title: str | None = None,
    space_key: str | None = None,
    body_format: str = "storage",
    url: str | None = None,
) -> dict[str, Any]:
    # Parse URL if provided
    if url:
        parsed = _parse_confluence_url(url)
        page_id = page_id or parsed.get("page_id")
        space_key = space_key or parsed.get("space_key")
        title = title or parsed.get("title")

    if page_id:
        page_id = page_id.strip()
    if space_key:
        space_key = space_key.strip()
    if title:
        title = title.strip()

    if not page_id and not (title and space_key):
        raise ValueError("Provide page_id, url, or both title and space_key")

    if page_id:
        logger.info("confluence_get_page: page_id=%s", page_id)
        return await api.get_page(page_id, body_format=body_format)
    else:
        logger.info("confluence_get_page: title=%r space_key=%r", title, space_key)
        assert title is not None and space_key is not None  # validated above
        return await api.get_page_by_title(space_key, title, body_format=body_format)


# ---------------------------------------------------------------------------
# Tool: confluence_get_page_children
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_page_children",
    title="Get Child Pages",
    description="Get child pages of a Confluence page. Returns a list of child page objects.",
)
async def confluence_get_page_children(
    page_id: str,
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_page_children: page_id=%s", page_id)
    start_int = int(start) if start else 0
    data = await api.get_child_pages(page_id, limit=limit, start=start_int)
    if data is None:
        return {"results": []}
    links = data.pop("_links", None) or {}
    return {"results": data.get("results", []), "next_start": _extract_next_start(links)}


# ---------------------------------------------------------------------------
# Tool: confluence_get_page_ancestors
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_page_ancestors",
    title="Get Page Ancestors",
    description="Get the ancestor pages (breadcrumb path) of a Confluence page.",
)
async def confluence_get_page_ancestors(page_id: str) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_page_ancestors: page_id=%s", page_id)
    data = await api.get_page_ancestors(page_id)
    return data if data is not None else {"results": []}


# ---------------------------------------------------------------------------
# Tool: confluence_get_comments
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_comments",
    title="Get Page Comments",
    description="Get comments on a Confluence page.",
)
async def confluence_get_comments(
    page_id: str,
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_comments: page_id=%s", page_id)
    start_int = int(start) if start else 0
    data = await api.get_footer_comments(page_id, limit=limit, start=start_int)
    if data is None:
        return {"results": []}
    links = data.pop("_links", None) or {}
    return {"results": data.get("results", []), "next_start": _extract_next_start(links)}


# ---------------------------------------------------------------------------
# Tool: confluence_get_labels
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_labels",
    title="Get Page Labels",
    description="Get labels attached to a Confluence page.",
)
async def confluence_get_labels(page_id: str) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_labels: page_id=%s", page_id)
    data = await api.get_page_labels(page_id)
    return data if data is not None else {"results": []}


# ---------------------------------------------------------------------------
# Tool: confluence_get_attachments
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_attachments",
    title="Get Page Attachments",
    description="List attachments on a Confluence page. Returns file name, size, media type for each attachment.",
)
async def confluence_get_attachments(
    page_id: str,
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_attachments: page_id=%s", page_id)
    start_int = int(start) if start else 0
    data = await api.get_attachments(page_id, limit=limit, start=start_int)
    if data is None:
        return {"results": []}
    links = data.pop("_links", None) or {}
    return {"results": data.get("results", []), "next_start": _extract_next_start(links)}


# ---------------------------------------------------------------------------
# Tool: confluence_get_spaces
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_spaces",
    title="List Confluence Spaces",
    description="List Confluence spaces accessible to the authenticated user.",
)
async def confluence_get_spaces(
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    logger.info("confluence_get_spaces: limit=%d", limit)
    start_int = int(start) if start else 0
    data = await api.get_spaces(limit=limit, start=start_int)
    if data is None:
        return {"results": []}
    links = data.pop("_links", None) or {}
    return {"results": data.get("results", []), "next_start": _extract_next_start(links)}


# ---------------------------------------------------------------------------
# Tool: confluence_get_space
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_space",
    title="Get Confluence Space",
    description="Get details of a Confluence space by its key.",
)
async def confluence_get_space(
    space_key: str,
) -> dict[str, Any]:
    space_key = _validate_id(space_key, "space_key")
    logger.info("confluence_get_space: space_key=%s", space_key)
    return await api.get_space(space_key)


# ---------------------------------------------------------------------------
# Tool: confluence_get_pages_in_space
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_pages_in_space",
    title="List Pages in Space",
    description="List pages in a Confluence space, optionally filtered by title.",
)
async def confluence_get_pages_in_space(
    space_key: str,
    title: str | None = None,
    status: str = "current",
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    space_key = _validate_id(space_key, "space_key")
    logger.info("confluence_get_pages_in_space: space_key=%s", space_key)
    start_int = int(start) if start else 0
    data = await api.get_pages_in_space(
        space_key=space_key, title=title, status=status, limit=limit, start=start_int,
    )
    if data is None:
        return {"results": []}
    links = data.pop("_links", None) or {}
    return {"results": data.get("results", []), "next_start": _extract_next_start(links)}


# ---------------------------------------------------------------------------
# Tool: confluence_download_attachment
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_download_attachment",
    title="Download Attachment",
    description="Download an attachment from Confluence by its ID and save it to disk. save_path must be an absolute file path.",
)
async def confluence_download_attachment(
    attachment_id: str,
    save_path: str,
) -> dict[str, Any]:
    attachment_id = _validate_id(attachment_id, "attachment_id")
    save_path = save_path.strip()
    if not save_path:
        raise ValueError("save_path must not be empty")
    logger.info("confluence_download_attachment: attachment=%s", attachment_id)
    return await api.download_attachment(attachment_id, save_path)


# ---------------------------------------------------------------------------
# Tool: confluence_download_content_attachments
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_download_content_attachments",
    title="Download All Attachments",
    description="Download all attachments from a Confluence page to a directory on disk. save_dir must be an absolute directory path.",
)
async def confluence_download_content_attachments(
    page_id: str,
    save_dir: str,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    save_dir = save_dir.strip()
    if not save_dir:
        raise ValueError("save_dir must not be empty")
    logger.info("confluence_download_content_attachments: page_id=%s dir=%s", page_id, save_dir)
    results = await api.download_content_attachments(page_id, save_dir)
    return {
        "status": "ok",
        "page_id": page_id,
        "downloaded": len([r for r in results if r.get("status") == "downloaded"]),
        "results": results,
    }


# ---------------------------------------------------------------------------
# Tool: confluence_get_page_history
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_page_history",
    title="Get Page History",
    description="Get the version history of a Confluence page.",
)
async def confluence_get_page_history(
    page_id: str,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_page_history: page_id=%s", page_id)
    data = await api.get_page_history(page_id)
    return data if data is not None else {"results": []}


# ---------------------------------------------------------------------------
# Tool: confluence_search_user
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_search_user",
    title="Search Confluence Users",
    description="Search for Confluence users by name.",
)
async def confluence_search_user(
    query: str,
    limit: int = MAX_RESULTS,
    start: str | None = None,
) -> dict[str, Any]:
    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    logger.info("confluence_search_user: query=%r", query)
    start_int = int(start) if start else 0
    data = await api.search_user(query, limit=limit, start=start_int)
    if data is None:
        return {"status": "no_results", "query": query, "result_count": 0, "results": []}
    results = data.get("results", [])
    links = data.get("_links", {})
    return {
        "status": "ok" if results else "no_results",
        "query": query,
        "result_count": len(results),
        "results": results,
        "next_start": _extract_next_start(links),
    }


# ---------------------------------------------------------------------------
# Tool: confluence_get_space_page_tree
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_space_page_tree",
    title="Get Space Page Tree",
    description=(
        "Get hierarchical page tree for a Confluence space as a flat list. "
        "Each page includes id, title, parent_id, position, depth. "
        "Root pages have parent_id: null and depth: 0. "
        "Much more token-efficient than rendering full trees."
    ),
)
async def confluence_get_space_page_tree(
    space_key: str,
    limit: int = 500,
) -> dict[str, Any]:
    space_key = _validate_id(space_key, "space_key")
    logger.info("confluence_get_space_page_tree: space_key=%s", space_key)
    return await api.get_space_page_tree(space_key=space_key, limit=limit)


# ---------------------------------------------------------------------------
# Tool: confluence_get_page_images
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_get_page_images",
    title="Get Page Images",
    description=(
        "Get all images attached to a Confluence page as base64-encoded data. "
        "Filters to image files only (PNG, JPEG, GIF, WebP, SVG, BMP). "
        "Returns id, title, mime_type, size, and base64 data for each image."
    ),
)
async def confluence_get_page_images(
    page_id: str,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_get_page_images: page_id=%s", page_id)
    images = await api.get_page_images(page_id)
    errors = [i for i in images if i.get("status") == "error"]
    skipped = [i for i in images if i.get("status") == "skipped"]
    successful = [i for i in images if i.get("status") not in ("error", "skipped")]
    return {
        "status": "ok",
        "page_id": page_id,
        "total_images": len(images),
        "downloaded": len(successful),
        "skipped": skipped,
        "failed": errors,
        "images": successful,
    }
