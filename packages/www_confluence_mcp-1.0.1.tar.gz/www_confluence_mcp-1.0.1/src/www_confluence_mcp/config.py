"""Environment-driven configuration and shared constants (Server/DC only)."""

from __future__ import annotations

import logging
import os

logger = logging.getLogger("www-confluence-mcp")

# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------


def _env_str(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _env_int(name: str, default: int, lo: int | None = None, hi: int | None = None) -> int:
    try:
        val = int(os.getenv(name, str(default)))
    except (ValueError, TypeError):
        logger.warning("Invalid %s, using default %d", name, default)
        val = default
    if lo is not None:
        val = max(lo, val)
    if hi is not None:
        val = min(hi, val)
    return val


def _env_bool(name: str, default: bool = True) -> bool:
    raw = os.getenv(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on"}


# ---------------------------------------------------------------------------
# Auth type detection (Server/Data Center only)
# ---------------------------------------------------------------------------

AuthType = str  # "basic" | "pat"


def _detect_auth() -> tuple[AuthType, str, str, str]:
    """Detect authentication method from environment variables.

    Returns (auth_type, username, password, personal_token).
    Raises ValueError if auth is not configured.
    """
    url = _env_str("CONFLUENCE_URL")
    username = _env_str("CONFLUENCE_USERNAME")
    password = _env_str("CONFLUENCE_PASSWORD") or _env_str("CONFLUENCE_API_TOKEN")
    personal_token = _env_str("CONFLUENCE_PERSONAL_TOKEN")

    if not url:
        raise ValueError(
            "CONFLUENCE_URL is required. "
            "Set it to your Confluence Server/DC base URL, "
            "e.g. https://confluence.example.com"
        )

    # PAT is preferred for Server/DC
    if personal_token:
        return "pat", "", "", personal_token
    if username and password:
        return "basic", username, password, ""
    raise ValueError(
        "Confluence Server/Data Center requires CONFLUENCE_PERSONAL_TOKEN "
        "or both CONFLUENCE_USERNAME and CONFLUENCE_PASSWORD."
    )


# ---------------------------------------------------------------------------
# Resolved settings (read once at import time)
# ---------------------------------------------------------------------------

URL: str = _env_str("CONFLUENCE_URL")
TIMEOUT: int = _env_int("CONFLUENCE_TIMEOUT", 30, lo=1)
MAX_RESULTS: int = _env_int("CONFLUENCE_MAX_RESULTS", 25, lo=1, hi=100)
SSL_VERIFY: bool = _env_bool("CONFLUENCE_SSL_VERIFY", default=True)
READ_ONLY: bool = _env_bool("CONFLUENCE_READ_ONLY", default=True)
SPACES_FILTER: str = _env_str("CONFLUENCE_SPACES_FILTER")
HTTP_PROXY: str | None = _env_str("CONFLUENCE_HTTP_PROXY") or None
HTTPS_PROXY: str | None = _env_str("CONFLUENCE_HTTPS_PROXY") or None
PROMPTS_DIR: str = _env_str("CONFLUENCE_PROMPTS_DIR")

try:
    _auth_type, _username, _password, _personal_token = _detect_auth()
    AUTH_TYPE: AuthType = _auth_type
    USERNAME: str = _username
    PASSWORD: str = _password
    PERSONAL_TOKEN: str = _personal_token
except ValueError:
    # Allow importing the module without configured env vars (e.g. for tests).
    # The client will raise at runtime if auth is missing.
    AUTH_TYPE = ""
    USERNAME = ""
    PASSWORD = ""
    PERSONAL_TOKEN = ""
    logger.debug("Confluence auth not configured — tools will be unavailable until env vars are set.")
