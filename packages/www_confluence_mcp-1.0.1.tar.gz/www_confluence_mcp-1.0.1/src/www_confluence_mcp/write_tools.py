"""Write tools for Confluence MCP server — only loaded when CONFLUENCE_READ_ONLY=false (Server/DC v1 API)."""

from __future__ import annotations

import logging
from typing import Any

from . import client as api
from .server import mcp

logger = logging.getLogger("www-confluence-mcp")


def _validate_id(value: str, name: str = "id") -> str:
    """Strip and validate a required ID parameter."""
    value = value.strip()
    if not value:
        raise ValueError(f"{name} must not be empty")
    return value

# ===================================================================
# WRITE TOOLS (11 total)
# ===================================================================

# ---------------------------------------------------------------------------
# Tool: confluence_create_page
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_create_page",
    title="Create Confluence Page",
    description=(
        "Create a new Confluence page. "
        "body_value should be in Confluence Storage Format (XHTML-like) or plain text. "
        "Example Storage Format: '<p>Hello <strong>World</strong></p>'"
    ),
)
async def confluence_create_page(
    space_key: str,
    title: str,
    body_value: str = "",
    parent_id: str | None = None,
    body_representation: str = "storage",
    status: str = "current",
) -> dict[str, Any]:
    space_key = _validate_id(space_key, "space_key")
    title = title.strip()
    if not title:
        raise ValueError("title must not be empty")
    body_value = body_value.strip()
    if not body_value:
        raise ValueError("body_value must not be empty")
    if status not in ("current", "draft"):
        raise ValueError("status must be 'current' or 'draft'")
    logger.info("confluence_create_page: space=%s title=%r", space_key, title)
    data = await api.create_page(
        space_key=space_key,
        title=title,
        body_value=body_value,
        parent_id=parent_id,
        body_representation=body_representation,
        status=status,
    )
    if data is None:
        return {"status": "created", "page_id": None, "title": title}
    return {"status": "created", "page_id": data.get("id"), "title": data.get("title")}


# ---------------------------------------------------------------------------
# Tool: confluence_update_page
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_update_page",
    title="Update Confluence Page",
    description=(
        "Update an existing Confluence page. "
        "You MUST provide version_number = current_version + 1 (get current version via confluence_get_page)."
    ),
)
async def confluence_update_page(
    page_id: str,
    title: str,
    body_value: str,
    version_number: int,
    body_representation: str = "storage",
    status: str = "current",
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    title = title.strip()
    if not title:
        raise ValueError("title must not be empty")
    body_value = body_value.strip()
    if not body_value:
        raise ValueError("body_value must not be empty")
    if status not in ("current", "draft"):
        raise ValueError("status must be 'current' or 'draft'")
    if version_number < 1:
        raise ValueError("version_number must be >= 1")
    logger.info("confluence_update_page: page_id=%s version=%d", page_id, version_number)
    data = await api.update_page(
        page_id=page_id,
        title=title,
        body_value=body_value,
        version_number=version_number,
        body_representation=body_representation,
        status=status,
    )
    if data is None:
        return {"status": "updated", "page_id": page_id, "version": version_number}
    return {"status": "updated", "page_id": data.get("id"), "version": data.get("version", {}).get("number")}


# ---------------------------------------------------------------------------
# Tool: confluence_delete_page
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_delete_page",
    title="Delete Confluence Page",
    description="Delete a Confluence page by its ID.",
)
async def confluence_delete_page(page_id: str) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    logger.info("confluence_delete_page: page_id=%s", page_id)
    await api.delete_page(page_id)
    return {"status": "deleted", "page_id": page_id}


# ---------------------------------------------------------------------------
# Tool: confluence_add_comment
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_add_comment",
    title="Add Page Comment",
    description="Add a comment to a Confluence page.",
)
async def confluence_add_comment(
    page_id: str,
    body_value: str,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    body_value = body_value.strip()
    if not body_value:
        raise ValueError("body_value must not be empty")
    logger.info("confluence_add_comment: page_id=%s", page_id)
    data = await api.create_comment(page_id, body_value)
    if data is None:
        return {"status": "created", "comment_id": None}
    return {"status": "created", "comment_id": data.get("id")}


# ---------------------------------------------------------------------------
# Tool: confluence_add_labels
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_add_labels",
    title="Add Page Labels",
    description="Add labels to a Confluence page.",
)
async def confluence_add_labels(
    page_id: str,
    labels: list[str],
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    if not labels:
        raise ValueError("labels must not be empty")
    cleaned = [lbl.strip() for lbl in labels if lbl.strip()]
    if not cleaned:
        raise ValueError("labels must contain at least one non-empty label")
    logger.info("confluence_add_labels: page_id=%s labels=%s", page_id, cleaned)
    await api.add_page_labels(page_id, cleaned)
    return {"status": "ok", "page_id": page_id, "labels_added": len(cleaned)}


# ---------------------------------------------------------------------------
# Tool: confluence_delete_label
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_delete_label",
    title="Delete Page Label",
    description="Remove a label from a Confluence page.",
)
async def confluence_delete_label(
    page_id: str,
    label: str,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    label = label.strip()
    if not label:
        raise ValueError("label must not be empty")
    logger.info("confluence_delete_label: page_id=%s label=%s", page_id, label)
    await api.delete_page_label(page_id, label)
    return {"status": "deleted", "page_id": page_id, "label": label}


# ---------------------------------------------------------------------------
# Tool: confluence_upload_attachment
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_upload_attachment",
    title="Upload Attachment",
    description="Upload a file as an attachment to a Confluence page. file_path must be an absolute path to an existing file.",
)
async def confluence_upload_attachment(
    page_id: str,
    file_path: str,
    comment: str = "",
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    file_path = file_path.strip()
    if not file_path:
        raise ValueError("file_path must not be empty")
    logger.info("confluence_upload_attachment: page_id=%s file=%s", page_id, file_path)
    data = await api.upload_attachment(page_id, file_path, comment=comment)
    if data and isinstance(data, dict):
        results = data.get("results", [])
        if not results and data.get("id"):
            results = [data]
    else:
        results = []
    return {
        "status": "uploaded",
        "page_id": page_id,
        "attachments": [
            {"id": att.get("id"), "title": att.get("title")}
            for att in results
        ],
    }


# ---------------------------------------------------------------------------
# Tool: confluence_delete_attachment
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_delete_attachment",
    title="Delete Attachment",
    description="Delete an attachment from Confluence by its ID.",
)
async def confluence_delete_attachment(
    attachment_id: str,
) -> dict[str, Any]:
    attachment_id = _validate_id(attachment_id, "attachment_id")
    logger.info("confluence_delete_attachment: attachment_id=%s", attachment_id)
    await api.delete_attachment(attachment_id)
    return {"status": "deleted", "attachment_id": attachment_id}


# ---------------------------------------------------------------------------
# Tool: confluence_move_page
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_move_page",
    title="Move Confluence Page",
    description="Move a Confluence page to a different space and/or under a different parent page.",
)
async def confluence_move_page(
    page_id: str,
    space_key: str | None = None,
    parent_id: str | None = None,
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    if space_key:
        space_key = space_key.strip()
    if parent_id:
        parent_id = parent_id.strip()
    if not space_key and not parent_id:
        raise ValueError("Provide space_key and/or parent_id to move the page")
    logger.info("confluence_move_page: page_id=%s space=%s parent=%s", page_id, space_key, parent_id)
    data = await api.move_page(page_id, space_key=space_key, parent_id=parent_id)
    if data is None:
        return {"status": "moved", "page_id": page_id}
    return {"status": "moved", "page_id": page_id, "title": data.get("title"), "version": data.get("version", {}).get("number")}


# ---------------------------------------------------------------------------
# Tool: confluence_reply_to_comment
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_reply_to_comment",
    title="Reply to Comment",
    description="Reply to an existing comment on a Confluence page.",
)
async def confluence_reply_to_comment(
    comment_id: str,
    body_value: str,
) -> dict[str, Any]:
    comment_id = _validate_id(comment_id, "comment_id")
    body_value = body_value.strip()
    if not body_value:
        raise ValueError("body_value must not be empty")
    logger.info("confluence_reply_to_comment: comment_id=%s", comment_id)
    data = await api.reply_to_comment(comment_id, body_value)
    if data is None:
        return {"status": "created", "comment_id": None}
    return {"status": "created", "comment_id": data.get("id")}


# ---------------------------------------------------------------------------
# Tool: confluence_upload_attachments
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_upload_attachments",
    title="Upload Multiple Attachments",
    description="Upload multiple files as attachments to a Confluence page. file_paths must be a list of absolute file paths.",
)
async def confluence_upload_attachments(
    page_id: str,
    file_paths: list[str],
    comment: str = "",
) -> dict[str, Any]:
    page_id = _validate_id(page_id, "page_id")
    if not file_paths:
        raise ValueError("file_paths must not be empty")
    logger.info("confluence_upload_attachments: page_id=%s count=%d", page_id, len(file_paths))
    results = await api.upload_attachments(page_id, file_paths, comment=comment)
    return {
        "status": "ok",
        "page_id": page_id,
        "uploaded": len([r for r in results if r.get("status") == "uploaded"]),
        "results": results,
    }


# ---------------------------------------------------------------------------
# Tool: confluence_apply_template
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_apply_template",
    title="Apply Template to Pages",
    description=(
        "Update existing pages with the body from a template page. "
        "The template page content (Storage Format) overwrites each target page's body — "
        "titles, spaces, and page tree positions are preserved. "
        "template_page and target_page_list accept page IDs or Confluence URLs. "
        "Use dry_run=true to preview changes without modifying anything."
    ),
)
async def confluence_apply_template(
    template_page: str,
    target_page_list: list[str],
    dry_run: bool = False,
) -> dict[str, Any]:
    template_page = _validate_id(template_page, "template_page")
    if not target_page_list:
        raise ValueError("target_page_list must not be empty")

    # Resolve URLs to page IDs
    from .read_tools import _parse_confluence_url

    def _resolve(raw: str, label: str) -> str:
        raw = raw.strip()
        if raw.startswith("http://") or raw.startswith("https://"):
            parsed = _parse_confluence_url(raw)
            pid = parsed.get("page_id")
            if not pid:
                raise ValueError(f"Could not extract page_id from URL ({label}): {raw}")
            return pid
        return raw

    template_page = _resolve(template_page, "template_page")

    resolved: list[str] = []
    for raw in target_page_list:
        raw = raw.strip()
        if not raw:
            continue
        resolved.append(_resolve(raw, "target_page_list"))

    if not resolved:
        raise ValueError("target_page_list must contain at least one page ID or URL")

    logger.info(
        "confluence_apply_template: template=%s targets=%s dry_run=%s",
        template_page, resolved, dry_run,
    )
    return await api.apply_template(
        template_page=template_page,
        target_page_list=resolved,
        dry_run=dry_run,
    )
