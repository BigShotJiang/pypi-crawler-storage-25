"""Tests for www_confluence_mcp — config, client, and server tools (Server/DC v1 API)."""

from unittest.mock import AsyncMock

import pytest

from www_confluence_mcp.config import (
    _env_bool,
    _env_int,
    _env_str,
    _detect_auth,
)
from www_confluence_mcp.server import main, mcp
from www_confluence_mcp.read_tools import (
    _parse_confluence_url,
    confluence_download_attachment,
    confluence_download_content_attachments,
    confluence_get_attachments,
    confluence_get_comments,
    confluence_get_labels,
    confluence_get_page,
    confluence_get_page_ancestors,
    confluence_get_page_children,
    confluence_get_page_history,
    confluence_get_page_images,
    confluence_get_pages_in_space,
    confluence_get_space,
    confluence_get_space_page_tree,
    confluence_get_spaces,
    confluence_search,
    confluence_search_user,
)
from www_confluence_mcp.write_tools import (
    confluence_add_comment,
    confluence_add_labels,
    confluence_apply_template,
    confluence_create_page,
    confluence_delete_attachment,
    confluence_delete_label,
    confluence_delete_page,
    confluence_move_page,
    confluence_reply_to_comment,
    confluence_update_page,
    confluence_upload_attachments,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_client(monkeypatch):
    """Reset shared client between tests and disable read-only mode."""
    import www_confluence_mcp.client as c
    c._CLIENT = None
    # Tests need write access enabled
    monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", False)
    yield
    c._CLIENT = None


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------

class TestEnvHelpers:
    def test_env_str(self, monkeypatch):
        monkeypatch.setenv("TEST_STR", "  hello  ")
        assert _env_str("TEST_STR") == "hello"

    def test_env_str_default(self):
        assert _env_str("NONEXISTENT_VAR_XYZ") == ""

    def test_env_int(self, monkeypatch):
        monkeypatch.setenv("TEST_INT", "42")
        assert _env_int("TEST_INT", 10) == 42

    def test_env_int_default(self):
        assert _env_int("NONEXISTENT_VAR_XYZ", 10) == 10

    def test_env_int_clamp(self, monkeypatch):
        monkeypatch.setenv("TEST_CLAMP", "200")
        assert _env_int("TEST_CLAMP", 10, hi=100) == 100

    def test_env_bool_true(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL", "true")
        assert _env_bool("TEST_BOOL") is True

    def test_env_bool_false(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL", "no")
        assert _env_bool("TEST_BOOL") is False  # "no" is not in truthy set

    def test_env_bool_false_correct(self, monkeypatch):
        monkeypatch.setenv("TEST_BOOL2", "false")
        assert _env_bool("TEST_BOOL2", default=True) is False

    def test_env_bool_default(self):
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=True) is True
        assert _env_bool("NONEXISTENT_VAR_XYZ", default=False) is False


class TestAuthDetect:
    def test_dc_pat(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.setenv("CONFLUENCE_PERSONAL_TOKEN", "my-pat-token")
        auth_type, user, token, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat-token"

    def test_dc_basic(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "pass")
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        auth_type, user, password, pat = _detect_auth()
        assert auth_type == "basic"
        assert password == "pass"

    def test_dc_no_auth(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.internal.com")
        monkeypatch.delenv("CONFLUENCE_USERNAME", raising=False)
        monkeypatch.delenv("CONFLUENCE_PASSWORD", raising=False)
        monkeypatch.delenv("CONFLUENCE_API_TOKEN", raising=False)
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        with pytest.raises(ValueError, match="CONFLUENCE_PASSWORD"):
            _detect_auth()

    def test_no_url(self, monkeypatch):
        monkeypatch.delenv("CONFLUENCE_URL", raising=False)
        with pytest.raises(ValueError, match="CONFLUENCE_URL"):
            _detect_auth()

    def test_pat_takes_priority_over_basic(self, monkeypatch):
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_PERSONAL_TOKEN", "my-pat")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "pass")
        auth_type, _, _, pat = _detect_auth()
        assert auth_type == "pat"
        assert pat == "my-pat"

    def test_api_token_backward_compat(self, monkeypatch):
        """CONFLUENCE_API_TOKEN still works as fallback for CONFLUENCE_PASSWORD."""
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_API_TOKEN", "legacy-pass")
        monkeypatch.delenv("CONFLUENCE_PASSWORD", raising=False)
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        auth_type, _, password, _ = _detect_auth()
        assert auth_type == "basic"
        assert password == "legacy-pass"

    def test_password_takes_priority_over_api_token(self, monkeypatch):
        """CONFLUENCE_PASSWORD takes priority over CONFLUENCE_API_TOKEN."""
        monkeypatch.setenv("CONFLUENCE_URL", "https://confluence.example.com")
        monkeypatch.setenv("CONFLUENCE_USERNAME", "admin")
        monkeypatch.setenv("CONFLUENCE_PASSWORD", "new-pass")
        monkeypatch.setenv("CONFLUENCE_API_TOKEN", "old-pass")
        monkeypatch.delenv("CONFLUENCE_PERSONAL_TOKEN", raising=False)
        _, _, password, _ = _detect_auth()
        assert password == "new-pass"


# ---------------------------------------------------------------------------
# Server tool tests (mocked API)
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_confluence(monkeypatch):
    """Patch the API client module to return mock responses."""
    import www_confluence_mcp.client as client_mod

    mock = AsyncMock()
    monkeypatch.setattr(client_mod, "get_client", mock.get_client)

    # Patch all API functions
    for name in [
        "search", "get_page", "get_page_by_title", "get_child_pages",
        "get_page_ancestors", "get_footer_comments", "get_page_labels",
        "add_page_labels", "delete_page_label", "get_spaces", "get_space",
        "create_page", "update_page", "delete_page",
        "create_comment", "get_attachments", "upload_attachment",
        "get_pages_in_space", "download_attachment", "delete_attachment",
        "download_content_attachments", "get_page_history", "move_page",
        "reply_to_comment", "search_user", "upload_attachments",
        "get_space_page_tree", "get_page_images", "apply_template",
    ]:
        monkeypatch.setattr(client_mod, name, getattr(mock, name))

    return mock


class TestReadOnly:
    def test_write_tools_not_registered_in_read_only(self, monkeypatch):
        """When READ_ONLY=true, write tools are not registered on the MCP server."""
        write_tool_names = {
            "confluence_create_page", "confluence_update_page", "confluence_delete_page",
            "confluence_add_comment", "confluence_add_labels", "confluence_delete_label",
            "confluence_upload_attachment", "confluence_upload_attachments",
            "confluence_delete_attachment", "confluence_move_page",
            "confluence_reply_to_comment",
        }
        registered = {t.name for t in mcp._tool_manager._tools.values()}
        assert write_tool_names.issubset(registered), f"Missing: {write_tool_names - registered}"

    async def test_write_allowed_when_not_read_only(self, mock_confluence, monkeypatch):
        monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", False)
        mock_confluence.create_page.return_value = {"id": "new1", "title": "New"}
        result = await confluence_create_page(space_key="DEV", title="New", body_value="x")
        assert result["status"] == "created"

    async def test_read_not_blocked_in_read_only(self, mock_confluence, monkeypatch):
        monkeypatch.setattr("www_confluence_mcp.config.READ_ONLY", True)
        mock_confluence.search.return_value = {"results": [], "_links": {}}
        result = await confluence_search("test")
        assert result["status"] == "no_results"


class TestMain:
    def test_main_is_callable(self):
        assert callable(main)


class TestSearchTool:
    async def test_search_returns_results(self, mock_confluence):
        mock_confluence.search.return_value = {
            "results": [
                {"id": "1", "title": "Test Page", "type": "page"},
            ],
            "_links": {"next": "/rest/api/content/search?cql=test&start=25&limit=25"},
        }
        result = await confluence_search("test query")
        assert result["status"] == "ok"
        assert result["result_count"] == 1
        assert result["next_start"] == "25"

    async def test_search_no_results(self, mock_confluence):
        mock_confluence.search.return_value = {"results": [], "_links": {}}
        result = await confluence_search("nonexistent")
        assert result["status"] == "no_results"
        assert result["next_start"] is None

    async def test_search_empty_query(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_search("   ")


class TestParseConfluenceUrl:
    def test_viewpage_action(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/pages/viewpage.action?pageId=1234567890123"
        )
        assert result["page_id"] == "1234567890123"

    def test_display_url(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/display/DEV/My+Page+Title"
        )
        assert result["space_key"] == "DEV"
        assert result["title"] == "My Page Title"

    def test_viewpage_no_query(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/pages/viewpage.action"
        )
        assert result == {}

    def test_display_with_context_path(self):
        result = _parse_confluence_url(
            "https://confluence.example.com/confluence/display/DEV/My+Page"
        )
        assert result["space_key"] == "DEV"
        assert result["title"] == "My Page"


class TestGetPageTool:
    async def test_get_page_by_id(self, mock_confluence):
        mock_confluence.get_page.return_value = {"id": "123", "title": "My Page"}
        result = await confluence_get_page(page_id="123")
        assert result["id"] == "123"

    async def test_get_page_by_title(self, mock_confluence):
        mock_confluence.get_page_by_title.return_value = {"id": "456", "title": "Found"}
        result = await confluence_get_page(title="Found", space_key="DEV")
        assert result["id"] == "456"

    async def test_get_page_no_args(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_get_page()

    async def test_get_page_by_viewpage_url(self, mock_confluence):
        mock_confluence.get_page.return_value = {"id": "1234567890123", "title": "Server Page"}
        result = await confluence_get_page(
            url="https://confluence.example.com/pages/viewpage.action?pageId=1234567890123"
        )
        assert result["id"] == "1234567890123"
        mock_confluence.get_page.assert_called_once_with("1234567890123", body_format="storage")

    async def test_get_page_by_display_url(self, mock_confluence):
        mock_confluence.get_page_by_title.return_value = {"id": "456", "title": "My Page"}
        result = await confluence_get_page(
            url="https://confluence.example.com/display/DEV/My+Page"
        )
        assert result["id"] == "456"
        mock_confluence.get_page_by_title.assert_called_once_with("DEV", "My Page", body_format="storage")


class TestSpacesTools:
    async def test_get_spaces(self, mock_confluence):
        mock_confluence.get_spaces.return_value = {"results": [{"key": "DEV", "name": "Development"}]}
        result = await confluence_get_spaces()
        assert "results" in result

    async def test_get_space_by_key(self, mock_confluence):
        mock_confluence.get_space.return_value = {"key": "DEV", "name": "Development"}
        result = await confluence_get_space(space_key="DEV")
        assert result["key"] == "DEV"

    async def test_get_space_empty_key(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_get_space(space_key="   ")


class TestPageChildrenTool:
    async def test_get_children(self, mock_confluence):
        mock_confluence.get_child_pages.return_value = {"results": [{"id": "2"}]}
        result = await confluence_get_page_children(page_id="1")
        assert "results" in result


class TestAncestorsTool:
    async def test_get_ancestors(self, mock_confluence):
        mock_confluence.get_page_ancestors.return_value = {"results": [{"id": "0"}]}
        result = await confluence_get_page_ancestors(page_id="1")
        assert "results" in result


class TestCommentsTools:
    async def test_get_comments(self, mock_confluence):
        mock_confluence.get_footer_comments.return_value = {"results": []}
        result = await confluence_get_comments(page_id="1")
        assert "results" in result

    async def test_add_comment(self, mock_confluence):
        mock_confluence.create_comment.return_value = {"id": "c1"}
        result = await confluence_add_comment(page_id="1", body_value="Nice!")
        assert result["status"] == "created"


class TestLabelsTools:
    async def test_get_labels(self, mock_confluence):
        mock_confluence.get_page_labels.return_value = {"results": [{"name": "docs"}]}
        result = await confluence_get_labels(page_id="1")
        assert "results" in result

    async def test_add_labels(self, mock_confluence):
        mock_confluence.add_page_labels.return_value = {"results": []}
        result = await confluence_add_labels(page_id="1", labels=["docs", "api"])
        assert result["labels_added"] == 2

    async def test_add_labels_empty(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_add_labels(page_id="1", labels=[])

    async def test_delete_label(self, mock_confluence):
        mock_confluence.delete_page_label.return_value = None
        result = await confluence_delete_label(page_id="1", label="docs")
        assert result["status"] == "deleted"


class TestAttachmentsTools:
    async def test_get_attachments(self, mock_confluence):
        mock_confluence.get_attachments.return_value = {"results": []}
        result = await confluence_get_attachments(page_id="1")
        assert "results" in result


class TestPageCrudTools:
    async def test_create_page(self, mock_confluence):
        mock_confluence.create_page.return_value = {"id": "new1", "title": "New"}
        result = await confluence_create_page(space_key="DEV", title="New", body_value="<p>Hi</p>")
        assert result["status"] == "created"

    async def test_create_page_empty_title(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_create_page(space_key="DEV", title="  ", body_value="x")

    async def test_update_page(self, mock_confluence):
        mock_confluence.update_page.return_value = {
            "id": "1", "version": {"number": 3},
        }
        result = await confluence_update_page(
            page_id="1", title="Updated", body_value="<p>x</p>", version_number=3,
        )
        assert result["status"] == "updated"

    async def test_delete_page(self, mock_confluence):
        mock_confluence.delete_page.return_value = None
        result = await confluence_delete_page(page_id="1")
        assert result["status"] == "deleted"


class TestPagesInSpaceTool:
    async def test_get_pages_in_space(self, mock_confluence):
        mock_confluence.get_pages_in_space.return_value = {"results": [{"id": "p1"}]}
        result = await confluence_get_pages_in_space(space_key="DEV")
        assert "results" in result


class TestDownloadAttachmentTool:
    async def test_download_attachment(self, mock_confluence):
        mock_confluence.download_attachment.return_value = {
            "status": "downloaded", "bytes": 42, "saved_to": "/tmp/test.txt",
        }
        result = await confluence_download_attachment(
            attachment_id="a1", save_path="/tmp/test.txt",
        )
        assert result["status"] == "downloaded"


class TestDeleteAttachmentTool:
    async def test_delete_attachment(self, mock_confluence):
        mock_confluence.delete_attachment.return_value = None
        result = await confluence_delete_attachment(attachment_id="a1")
        assert result["status"] == "deleted"


class TestDownloadAllAttachmentsTool:
    async def test_download_content_attachments(self, mock_confluence):
        mock_confluence.download_content_attachments.return_value = [
            {"id": "a1", "status": "downloaded", "bytes": 10},
        ]
        result = await confluence_download_content_attachments(
            page_id="1", save_dir="/tmp/atts",
        )
        assert result["downloaded"] == 1


class TestPageHistoryTool:
    async def test_get_page_history(self, mock_confluence):
        mock_confluence.get_page_history.return_value = {
            "results": [{"number": 1}],
            "version": {"number": 1},
        }
        result = await confluence_get_page_history(page_id="1")
        assert "results" in result


class TestMovePageTool:
    async def test_move_page(self, mock_confluence):
        mock_confluence.move_page.return_value = {"id": "1"}
        result = await confluence_move_page(page_id="1", parent_id="2")
        assert result["status"] == "moved"

    async def test_move_page_no_args(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_move_page(page_id="1")


class TestReplyToCommentTool:
    async def test_reply_to_comment(self, mock_confluence):
        mock_confluence.reply_to_comment.return_value = {"id": "r1"}
        result = await confluence_reply_to_comment(comment_id="c1", body_value="Reply!")
        assert result["status"] == "created"


class TestSearchUserTool:
    async def test_search_user(self, mock_confluence):
        mock_confluence.search_user.return_value = {
            "results": [{"user": {"displayName": "John"}}],
            "_links": {},
        }
        result = await confluence_search_user(query="John")
        assert result["status"] == "ok"
        assert result["result_count"] == 1
        assert result["next_start"] is None

    async def test_search_user_empty(self, mock_confluence):
        mock_confluence.search_user.return_value = {"results": [], "_links": {}}
        result = await confluence_search_user(query="Nobody")
        assert result["status"] == "no_results"

    async def test_search_user_empty_query(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_search_user(query="   ")


class TestUploadAttachmentsTool:
    async def test_upload_attachments(self, mock_confluence):
        mock_confluence.upload_attachments.return_value = [
            {"id": "a1", "title": "f1.txt", "status": "uploaded"},
        ]
        result = await confluence_upload_attachments(
            page_id="1", file_paths=["/tmp/f1.txt"],
        )
        assert result["uploaded"] == 1

    async def test_upload_attachments_empty(self, mock_confluence):
        with pytest.raises(ValueError):
            await confluence_upload_attachments(page_id="1", file_paths=[])


class TestSpacePageTreeTool:
    async def test_get_space_page_tree(self, mock_confluence):
        mock_confluence.get_space_page_tree.return_value = {
            "space_key": "DEV",
            "total_pages": 2,
            "has_more": False,
            "pages": [
                {"id": "1", "title": "Root", "parent_id": None, "depth": 0},
                {"id": "2", "title": "Child", "parent_id": "1", "depth": 1},
            ],
        }
        result = await confluence_get_space_page_tree(space_key="DEV")
        assert result["total_pages"] == 2
        assert result["pages"][0]["parent_id"] is None


class TestPageImagesTool:
    async def test_get_page_images(self, mock_confluence):
        mock_confluence.get_page_images.return_value = [
            {"id": "a1", "title": "pic.png", "mime_type": "image/png", "size": 100, "data": "base64..."},
        ]
        result = await confluence_get_page_images(page_id="1")
        assert result["total_images"] == 1
        assert result["downloaded"] == 1

    async def test_get_page_images_empty(self, mock_confluence):
        mock_confluence.get_page_images.return_value = []
        result = await confluence_get_page_images(page_id="1")
        assert result["total_images"] == 0


class TestApplyTemplateTool:
    async def test_apply_template_updates_pages(self, mock_confluence):
        """apply_template should update target pages with template body."""
        mock_confluence.apply_template.return_value = {
            "status": "success",
            "template_page": "999",
            "template_title": "Project Overview",
            "pages_processed": 3,
            "dry_run": False,
            "results": [
                {"page_id": "101", "title": "Alpha Overview", "space": "PROJ1", "action": "updated", "new_version": 4},
                {"page_id": "202", "title": "Beta Overview", "space": "PROJ2", "action": "updated", "new_version": 2},
                {"page_id": "303", "action": "error", "reason": "Page not found"},
            ],
        }
        result = await confluence_apply_template(
            template_page="999",
            target_page_list=["101", "202", "303"],
        )
        assert result["status"] == "success"
        assert result["pages_processed"] == 3
        assert result["results"][0]["action"] == "updated"
        assert result["results"][2]["action"] == "error"

    async def test_apply_template_dry_run(self, mock_confluence):
        mock_confluence.apply_template.return_value = {
            "status": "success",
            "template_page": "999",
            "template_title": "Project Overview",
            "pages_processed": 1,
            "dry_run": True,
            "results": [
                {"page_id": "10", "title": "My Page", "space": "DEV", "action": "would_update"},
            ],
        }
        result = await confluence_apply_template(
            template_page="999",
            target_page_list=["10"],
            dry_run=True,
        )
        assert result["dry_run"] is True
        assert result["results"][0]["action"] == "would_update"

    async def test_apply_template_empty_targets(self, mock_confluence):
        with pytest.raises(ValueError, match="target_page_list"):
            await confluence_apply_template(template_page="999", target_page_list=[])

    async def test_apply_template_url_resolution(self, mock_confluence):
        """URLs in target_page_list should be resolved to page IDs."""
        mock_confluence.apply_template.return_value = {
            "status": "success",
            "template_page": "999",
            "template_title": "Sprint Report",
            "pages_processed": 2,
            "dry_run": False,
            "results": [
                {"page_id": "501", "title": "Sprint Report", "space": "A", "action": "updated", "new_version": 3},
                {"page_id": "502", "title": "Sprint Report", "space": "A", "action": "updated", "new_version": 2},
            ],
        }
        result = await confluence_apply_template(
            template_page="999",
            target_page_list=[
                "501",
                "https://confluence.example.com/pages/viewpage.action?pageId=502",
            ],
        )
        assert result["status"] == "success"
        mock_confluence.apply_template.assert_called_once_with(
            template_page="999",
            target_page_list=["501", "502"],
            dry_run=False,
        )

    async def test_apply_template_template_url(self, mock_confluence):
        """template_page as URL should also be resolved to page ID."""
        mock_confluence.apply_template.return_value = {
            "status": "success",
            "template_page": "777",
            "template_title": "Template",
            "pages_processed": 1,
            "dry_run": False,
            "results": [
                {"page_id": "100", "title": "Target", "space": "X", "action": "updated", "new_version": 2},
            ],
        }
        result = await confluence_apply_template(
            template_page="https://confluence.example.com/pages/viewpage.action?pageId=777",
            target_page_list=["100"],
        )
        assert result["status"] == "success"
        mock_confluence.apply_template.assert_called_once_with(
            template_page="777",
            target_page_list=["100"],
            dry_run=False,
        )

    async def test_apply_template_invalid_url(self, mock_confluence):
        """URLs that don't resolve to a page_id should raise ValueError."""
        with pytest.raises(ValueError, match="Could not extract page_id"):
            await confluence_apply_template(
                template_page="999",
                target_page_list=["https://confluence.example.com/pages/viewpage.action"],
            )
