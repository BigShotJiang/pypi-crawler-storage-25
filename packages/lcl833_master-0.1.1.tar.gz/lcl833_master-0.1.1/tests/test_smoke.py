from lcl833_master.core import main


def test_import_and_main_exists():
    assert callable(main)
