import json
import pytest
from lcl833_master.core import main

def test_cli_selftest(capsys):
    ret = main(["selftest"])
    assert ret == 0
    captured = capsys.readouterr()
    assert "SELFTEST: PASS" in captured.out

def test_cli_knot_json(capsys):
    ret = main(["--json", "knot", "trefoil"])
    assert ret == 0
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "jones" in data
    assert "lcl833" in data
    assert data["jones"]["braid_word"] == [1, 1, 1]

def test_cli_braid_rkh(capsys):
    # Test rkh override via CLI
    ret = main(["--json", "braid", "1", "1", "1", "--rkh", "1.0"])
    assert ret == 0
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    # delta_eff = v_j + gamma * rkh
    # For trefoil, v_j approx 1.543, gamma = 0.05, rkh = 1.0 => delta_eff approx 1.593
    assert data["lcl833"]["r_kh"] == 1.0
    assert data["lcl833"]["delta_eff"] > 1.59

def test_cli_invalid_knot(capsys):
    with pytest.raises(SystemExit) as excinfo:
        main(["knot", "invalid-knot-name"])
    # argparse should catch this and exit with 2 (invalid args)
    assert excinfo.value.code == 2
