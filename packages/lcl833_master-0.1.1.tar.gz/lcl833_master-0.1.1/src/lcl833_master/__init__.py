"""lcl833-master package."""

from .core import main

__all__ = ["main"]
