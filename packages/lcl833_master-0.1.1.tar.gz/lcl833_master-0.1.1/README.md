# lcl833-master

Installable package bundle rebuilt from the production `lcl833_master_onepager.py` source.

## Usage

```bash
python -m lcl833_master selftest
python -m lcl833_master knot trefoil
python -m lcl833_master braid 1 1 1
```
