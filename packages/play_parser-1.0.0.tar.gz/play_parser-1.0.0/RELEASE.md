# Release checklist

Use this checklist when publishing a new public release.

## 1. Prepare the repository

```bash
python -m pip install -e .[dev]
python -m ruff check .
python -m ruff format --check .
python -m unittest discover -s tests
```

Check that the version in `pyproject.toml` and `src/play_parser/__init__.py` has been updated. For the first `1.0.0` release, keep `CHANGELOG.md` simple: list the current release features only, or leave it with no historical entries.

## 2. Build and inspect distributions

```bash
rm -rf dist build src/*.egg-info
python -m build
python -m twine check dist/*
```

Optional local wheel smoke test:

```bash
python -m venv /tmp/play-parser-release-test
/tmp/play-parser-release-test/bin/python -m pip install dist/*.whl
/tmp/play-parser-release-test/bin/play-parser --version
/tmp/play-parser-release-test/bin/play-parser --help
```

## 3. Publish to TestPyPI first

```bash
python -m twine upload --repository testpypi dist/*
```

Install from TestPyPI in a fresh environment and check the CLI:

```bash
python -m venv /tmp/play-parser-testpypi
/tmp/play-parser-testpypi/bin/python -m pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  play-parser
/tmp/play-parser-testpypi/bin/play-parser --version
/tmp/play-parser-testpypi/bin/play-parser --help
```

## 4. Publish to PyPI

```bash
python -m twine upload dist/*
```

## 5. Tag the release

```bash
git tag v1.0.0
git push origin v1.0.0
```
