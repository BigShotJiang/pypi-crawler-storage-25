# Security Policy

## Supported versions

Security fixes are considered for the latest released version of `play-parser`.

## Reporting a vulnerability

Please report security issues privately by email rather than opening a public issue.

Include a clear description, reproduction steps where possible, and the version affected. Please do not disclose the issue publicly until it has been assessed.
