# Changelog

## 1.0.0

Initial public release.

### Features

- Parse raw `.txt` play files into canonical JSON documents.
- Assemble canonical JSON documents back into normalised play text.
- Support explicit format profiles for speaker labels and stage directions.
- Include built-in profiles for common dramatic text layouts.
- Validate canonical play documents with a shared validator and JSON Schema.
- Expose a Python API for ingestion, domain access, validation, assembly, and profiles.
- Provide a `play-parser` CLI for parsing and assembling single files or folders.
- Include a corpus-backed test suite covering parsing, profiles, ingestion, domain objects, and roundtrips.
