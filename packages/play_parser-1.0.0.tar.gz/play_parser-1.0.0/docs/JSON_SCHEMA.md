# JSON Document Shape

This page documents the canonical JSON document shape written by
`play-parser`. A machine-readable JSON Schema is available at
[`play_document.schema.json`](play_document.schema.json).

Each parsed play is written with two top-level keys:

- `metadata`
- `events`

`metadata` is a summary derived from the raw source text and the parsed event stream.

`events` is the ordered event stream itself.

Higher-level Python objects such as `Act`, `Scene`, `Character`,
`Speech`, `Monologue`, and `Dialogue` are derived read-only views over
this document shape. They are not serialized into JSON.

In the Python API, `PlayIngestor` is the ingestion boundary for supported
source files such as `.txt` and canonical `.json`. `Play` is the domain
wrapper over this `PlayDocument` shape.

## Top-level document

```python
PlayMetadata = {
    "title": str | None,
    "author": str | None,
    "characters": list[str],
    "acts": list[{
        "act_number": int,
        "label": str,
    }],
    "scenes": list[{
        "act_number": int | None,
        "scene_number": int | None,
        "label": str,
    }],
    "stats": {
        "stage_directions": int,
        "speeches": int,
        "scenes": int,
        "acts": int,
        "source_words": int,
        "spoken_words": int,
    },
}

PlayDocument = {
    "metadata": PlayMetadata,
    "events": list[PlayEvent],
}
```

## Metadata rules

- `title` comes from a parsed title line in the raw text when present.
- File-based builders and ingestors fall back to the source file stem when no title is parsed.
- Text-only builders leave `title` as `null` unless `play_name` is provided explicitly.
- `author` comes only from parsed source text. If the source does not include an author line, it is `null`.
- `characters` is collected in source order from cast-list entries and speech labels.
- `acts` and `scenes` are summaries of parsed structural events.
- `stats.source_words` is computed from the raw input text.
- `stats.spoken_words` is computed from speech events only.
- `metadata` is written before `events` in the JSON file.

## Event types

Each item in `events` is one of the following shapes.

```python
ActStart = {
    "type": "act_start",
    "act_number": int,
    "label": str,
}

SceneStart = {
    "type": "scene_start",
    "scene_number": int | None,  # optional key
    "label": str,
}

Speech = {
    "type": "speech",
    "speaker": str,
    "text": str,
    "line_count": int,
    "word_count": int,
    "labelled": bool,   # optional key
}

StageDirection = {
    "type": "stage_direction",
    "subtype": str,
    "text": str,
    "attachment": "next",   # optional key
}

Meta = {
    "type": "meta",
    "subtype": str,
    "text": str,
}
```

## Event semantics

- event order matches source order
- `speech.text` preserves internal line breaks
- `line_count` and `word_count` describe the final exported `text`
- `speech.labelled` is an optional key
- `attachment: "next"` means a stage direction should render with the following block
- `stage_direction.attachment` is an optional key
- `labelled: false` means a speech continuation should render without repeating the speaker label
- canonical assembled text renders speech labels in colon form such as `Hamlet: ...`
- `scene_start` events do not carry `act_number`
- act association for scenes is represented in `metadata["scenes"]`
- `metadata["scenes"]` entries include `act_number`, `scene_number`, and `label`

## Example shape

```json
{
  "metadata": {
    "title": "Hamlet",
    "author": "William Shakespeare",
    "characters": ["Bernardo", "Francisco", "Marcellus"],
    "acts": [
      {"act_number": 1, "label": "ACT I"}
    ],
    "scenes": [
      {"act_number": 1, "scene_number": 1, "label": "SCENE I. ELSINORE. A PLATFORM BEFORE THE CASTLE."}
    ],
    "stats": {
      "stage_directions": 1,
      "speeches": 3,
      "scenes": 1,
      "acts": 1,
      "source_words": 42,
      "spoken_words": 12
    }
  },
  "events": [
    {"type": "act_start", "act_number": 1, "label": "ACT I"},
    {"type": "scene_start", "scene_number": 1, "label": "SCENE I. ELSINORE. A PLATFORM BEFORE THE CASTLE."}
  ]
}
```
