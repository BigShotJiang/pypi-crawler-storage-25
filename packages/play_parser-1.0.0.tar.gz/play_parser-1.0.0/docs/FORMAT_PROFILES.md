# Format Profiles

`play-parser` ships a small catalogue of raw-text format profiles. These
profiles describe the visible surface conventions of a play text without
changing the output schema.

They are meant to answer questions like:

- Are speaker labels written as `NAME:` or `NAME.`?
- Does the speech start on the same line or the next line?
- Are stage directions bracketed with `[]`, `()`, or both?
- Can stage directions wrap across multiple lines?
- Should Gutenberg-style underscore italics inside stage directions be stripped?

## Design intent

The profiles are intentionally neutral. They are named after syntax patterns, not after authors or corpora.

Examples:

- `colon_inline` instead of an author name
- `dot_block` instead of a corpus name
- `mixed_parenthetical` instead of a period label

This keeps the profile catalogue reusable across many editions and
publishers.

## Built-in profiles

### `colon_inline`

Speaker labels use a colon and the speech starts on the same line.

Typical examples:

```text
MESSENGER: He is very near by this.
HOOK: Not now.
```

Characteristics:

- speaker pattern: `NAME:`
- speech text position: same line
- stage directions may use `[]` or `()`
- inline stage directions are allowed

### `dot_inline`

Speaker labels end with a period and the speech starts on the same line.

Typical examples:

```text
MRS. MARCHMONT. How very trivial of him!
LADY BASILDON. [Languidly.] And were you interested?
```

Characteristics:

- speaker pattern: `NAME.`
- speech text position: same line
- stage directions may use `[]` or `()`
- multiline stage directions may appear

### `dot_block`

Speaker labels appear alone on a line, and the speech begins on the following nonblank line.

Typical examples:

```text
ALGERNON.
Did you hear what I was playing, Lane?
```

Characteristics:

- speaker pattern: `NAME.`
- speech text position: next nonblank line
- often used in print-style editions with lots of line wrapping

### `mixed_parenthetical`

Speaker labels may include a cue in parentheses or brackets before the speech text.

Typical examples:

```text
SLIGHTLY (with a solemnity that he thinks suits the occasion). No, Tootles, no.
HOOK. Not now. He is only one, and I want to mischief all the seven.
SMEE (wriggling his cutlass pleasantly). That is true.
```

Characteristics:

- supports both `NAME.` and `NAME:`
- supports inline speaker-adjacent cues such as `(softly)` or `[Languidly.]`
- useful for prose-drama editions and children’s plays

### `narrative_stage_heavy`

Long scene descriptions and extended narrative stage business can appear between speeches, including whole paragraphs of action or description.

Typical examples:

```text
(They are like dogs waiting for the master to tell them that the day has begun.)

The pirates appear upon the frozen river dragging a raft, on which reclines among cushions that dark and fearful man, CAPTAIN JAS. HOOK.
```

Characteristics:

- long unbracketed stage paragraphs may appear
- multiline stage directions are common
- often mixed with ordinary speech labels

## Underscore italics

Some public-domain or OCR-derived texts encode italics with underscores:

```text
[_Looking round through her lorgnette_.]
[_They rise and go towards the music-room_.]
```

The parser currently treats those underscores as formatting noise inside stage directions:

- leading and trailing `_` markers are stripped
- interior text is preserved

So this:

```text
[_Languidly_.]
```

becomes:

```text
[Languidly.]
```

This behavior is meant for stage directions only. It is not a general italics model.

## Usage

Format profiles are validated parser configuration. Built-ins can be
loaded by name, custom profile dictionaries can be validated and loaded,
and custom profile files can be loaded from disk:

```python
from play_parser.parsing import (
    get_format_profile,
    list_format_profiles,
    load_format_profile_config,
    load_format_profile_file,
)

names = list_format_profiles()
profile = get_format_profile("dot_block")
custom = load_format_profile_file("my_profile.json")
```

A minimal custom profile file looks like:

```json
{
  "name": "custom_colon_inline",
  "version": 1,
  "description": "Colon labels with same-line speech and bracketed stage directions.",
  "speaker_label_patterns": ["NAME_COLON"],
  "speaker_text_position": "same_line",
  "speaker_name_case": ["upper", "title", "mixed"],
  "stage_direction_delimiters": ["[]", "()"],
  "inline_stage_directions": true,
  "multiline_stage_directions": true,
  "strip_underscore_italics_in_stage_directions": true,
  "examples": [
    "HAMLET: To be, or not to be."
  ]
}
```

Profiles can be passed at the raw text ingestion boundary:

```python
from play_parser import PlayIngestor

ingestor = PlayIngestor("Hamlet.txt", profile="colon_inline")
```

Explicit profiles currently guide speaker-label parsing and stage-direction
parsing, including configured delimiters, inline and multiline stage
directions, underscore italic stripping, and long unbracketed stage paragraphs.
