# API

## Primary API: `PlayIngestor` + `Play`

`PlayIngestor` is the ingestion boundary. It accepts supported source
files, converts them into a `PlayDocument`, exposes that document
via `.data`, and writes canonical JSON with `.write(...)`.

`Play` is the domain boundary. It wraps canonical data only and exposes
derived read-only domain objects over `metadata` and `events`.

```python
from play_parser import Play, PlayIngestor

ingestor = PlayIngestor("Hamlet.txt")
ingestor.write("Hamlet.json")

# Or ingest raw text already loaded in memory.
ingestor_from_text = PlayIngestor.from_text(
    hamlet_text,
    source_name="Hamlet.txt",
    profile="colon_inline",
)

play = Play(ingestor.data)

print(play.title)
print(play.author)
print(len(play.acts))
print(len(play.scenes))
print(len(play.characters))
print(len(play.speeches))

text = play.assemble()
json_text = play.to_json()
play.save_json("Hamlet.json")
play.save_text("Hamlet.txt")
```

Currently supported ingestion source types:
- raw text files: `.txt`
- canonical JSON files: `.json`

Derived entities:
- `Act`
- `Scene`
- `Character`
- `Speech`
- `Monologue`
- `Dialogue`

`PlayIngestor` and `Play` are the primary entry points. All other
entities are read-only views derived from canonical `metadata` and
`events`.

Useful wrapper members:
- `PlayIngestor(path).data`
- `PlayIngestor.from_text(text, source_name="Hamlet.txt", profile="colon_inline").data`
- `PlayIngestor(path, profile="colon_inline").profile`
- `PlayIngestor(path).write(...)`
- `play.acts`
- `play.scenes`
- `play.characters`
- `play.speeches`
- `play.character(name)`
- `play.monologues(...)`
- `play.dialogues(...)`
- `play.assemble()`
- `play.as_dict()`
- `play.to_json()`
- `play.save_json(...)`
- `play.save_text(...)`
- `play.metadata`, `play.events`, `play.title`, `play.author`

`play.as_dict()` returns the canonical `PlayDocument` dictionary.

## Character And Speech Navigation

```python
from play_parser import Play, PlayIngestor

play = Play(PlayIngestor("Hamlet.txt").data)

hamlet = play.character("Hamlet")
if hamlet is not None:
    print(hamlet.name)
    print(hamlet.line_count)
    print(hamlet.word_count)

first_speech = play.speeches[0]
print(first_speech.speaker_name)
print(first_speech.text)
print(first_speech.labelled)

if first_speech.scene is not None:
    print(first_speech.scene.label)
```

## Scene And Act Navigation

```python
from play_parser import Play, PlayIngestor

play = Play(PlayIngestor("Hamlet.txt").data)

first_scene = play.scenes[0]
print(first_scene.label)
for character in first_scene.characters:
    print(character.name)

first_act = play.acts[0]
print(first_act.number)
for scene in first_act.scenes:
    print(scene.label)
```

## Monologues And Dialogues

```python
from play_parser import Play, PlayIngestor

play = Play(PlayIngestor("Hamlet.txt").data)

for monologue in play.monologues(min_lines=8):
    print(monologue.speaker_name, monologue.line_count)

hamlet = play.character("Hamlet")
if hamlet is not None:
    for monologue in hamlet.monologues(min_lines=8):
        print(monologue.text)

first_scene = play.scenes[0]
for dialogue in first_scene.dialogues(min_turns=4):
    print(dialogue.speaker_names, dialogue.turn_count)
```

## Lower-Level Helpers

These helpers are available for scripts, tests, and direct
transformations, but they are secondary to the `PlayIngestor` + `Play`
API:

```python
from play_parser.document import assemble_play_text, build_play_document
from play_parser.parsing import parse_play_file, parse_play_text
```

`assemble_play_text(...)` writes canonical text. Speech labels are normalized
to colon form such as `Hamlet: ...`; it does not preserve source-specific
dot-style or other raw-text label surfaces.

## Format Profiles

The library ships a small profile catalogue describing common raw-text
surface formats. This is secondary to the main ingestion/domain API.
The profile catalogue is described in [FORMAT_PROFILES.md](FORMAT_PROFILES.md).

You can inspect them with:

```python
from play_parser.parsing import get_format_profile, list_format_profiles

names = list_format_profiles()
profile = get_format_profile("dot_block")
```


You can also ingest raw play text already loaded in memory, for example text
extracted from a PDF, loaded from object storage, or received from an API
request body:

```python
from play_parser import PlayIngestor

ingestor = PlayIngestor.from_text(
    text,
    source_name="Hamlet.txt",
    profile="colon_inline",
)

print(ingestor.data["metadata"]["title"])
```

`source_name` is optional. When supplied, its stem is used as the fallback play
name if the text itself does not contain a title.

Profiles can also be provided at the raw text ingestion boundary:

```python
from play_parser import PlayIngestor

ingestor = PlayIngestor("Hamlet.txt", profile="colon_inline")
print(ingestor.profile.name if ingestor.profile else None)
```

`profile` may be a built-in profile name, a validated profile config mapping,
or a `FormatProfile` object. Use `profile_path="my_profile.json"` to load a
custom profile file. Profiles apply only to raw `.txt` ingestion; canonical
`.json` ingestion rejects profile arguments. Explicit profiles guide
speaker-label parsing and stage-direction parsing.

The CLI accepts the same profile choices for `parse`:

```bash
play-parser parse --input-root path/to/raw-texts --recursive --profile colon_inline
play-parser parse Hamlet.txt --input-root path/to/raw-texts --profile-path my_profile.json
```
