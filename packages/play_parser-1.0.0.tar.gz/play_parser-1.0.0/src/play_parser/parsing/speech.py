from __future__ import annotations

import re
from collections.abc import Sequence
from typing import TYPE_CHECKING

from play_parser.document.text import count_words, normalise_whitespace
from play_parser.document.types import PlayEvent, SpeechEvent, StageDirectionEvent
from play_parser.parsing.speakers import (
    clean_speaker,
    is_probable_speaker,
    is_title_like_speaker_name,
    looks_like_speaker_label_text,
)
from play_parser.parsing.stage import (
    classify_stage_direction,
    clean_stage_direction_text,
    consume_multiline_stage_direction,
    is_stage_direction_line,
    split_inline_stage_directions,
)
from play_parser.parsing.structure import is_structural_line

if TYPE_CHECKING:
    from play_parser.parsing.profiles import FormatProfile

COLON_SPEAKER_RE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9'’ .\-&]+?)\s*:\s*(.*)\s*$")
MAX_SPEAKER_LABEL_CHARS = 80
DOT_SPEAKER_RE = re.compile(rf"^\s*([A-Z][A-Z0-9'’ .\-&]{{0,{MAX_SPEAKER_LABEL_CHARS}}})\.\s*(.*)\s*$")
PROFILED_DOT_SPEAKER_RE = re.compile(rf"^\s*([A-Za-z][A-Za-z0-9'’ .\-&]{{0,{MAX_SPEAKER_LABEL_CHARS}}})\.\s*(.*)\s*$")
BARE_SPEAKER_RE = re.compile(rf"^\s*([A-Z][A-Z0-9'’ .\-&]{{0,{MAX_SPEAKER_LABEL_CHARS}}})\s*$")
PROFILED_BARE_SPEAKER_RE = re.compile(rf"^\s*([A-Za-z][A-Za-z0-9'’ .\-&]{{0,{MAX_SPEAKER_LABEL_CHARS}}})\s*$")


def parse_speech_start(
    linestr: str,
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
) -> tuple[str, str, bool] | None:
    if profile is not None:
        return parse_profiled_speech_start(linestr, lines, index, profile=profile)

    match = COLON_SPEAKER_RE.match(linestr)
    if match:
        raw_speaker = normalise_whitespace(match.group(1)).strip()
        speaker = clean_speaker(raw_speaker)
        rest = match.group(2).strip()
        if not looks_like_speaker_label_text(speaker):
            return None
        if is_probable_speaker(speaker):
            return speaker, rest, True

    dot_match = DOT_SPEAKER_RE.match(linestr)
    if dot_match:
        raw_speaker = normalise_whitespace(dot_match.group(1)).strip()
        speaker = clean_speaker(raw_speaker)
        rest = dot_match.group(2).strip()
        if not rest:
            return None
        if is_probable_speaker(speaker):
            return speaker, rest, True

    bare_match = BARE_SPEAKER_RE.match(linestr)
    if not bare_match:
        return None

    speaker = clean_speaker(bare_match.group(1))
    if not is_probable_speaker(speaker):
        return None

    next_index = index + 1
    while next_index < len(lines) and not lines[next_index].strip():
        next_index += 1
    if next_index >= len(lines):
        return None

    next_line = lines[next_index].strip()
    if is_structural_line(next_line) or is_stage_direction_line(next_line):
        return None
    return speaker, "", False


def parse_profiled_speech_start(
    linestr: str,
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile,
) -> tuple[str, str, bool] | None:
    patterns = set(profile.speaker_label_patterns)
    position = profile.speaker_text_position

    if "NAME_COLON" in patterns and position in {"same_line", "mixed"}:
        parsed = parse_profiled_inline_colon_speech(linestr, profile=profile)
        if parsed is not None:
            return parsed

    if "NAME_DOT" in patterns:
        if position in {"same_line", "mixed"}:
            parsed = parse_profiled_inline_dot_speech(linestr, profile=profile)
            if parsed is not None:
                return parsed
        if position in {"next_nonblank_line", "mixed"}:
            parsed = parse_profiled_block_dot_speech(linestr, lines, index, profile=profile)
            if parsed is not None:
                return parsed

    if "BARE_NAME" in patterns and position in {"next_nonblank_line", "mixed"}:
        parsed = parse_profiled_bare_speech(linestr, lines, index, profile=profile)
        if parsed is not None:
            return parsed

    return None


def parse_profiled_inline_colon_speech(
    linestr: str,
    *,
    profile: FormatProfile,
) -> tuple[str, str, bool] | None:
    match = COLON_SPEAKER_RE.match(linestr)
    if match:
        raw_speaker = normalise_whitespace(match.group(1)).strip()
        rest = match.group(2).strip()
    else:
        parsed = split_profiled_colon_label_with_cue(linestr, profile=profile)
        if parsed is None:
            return None
        raw_speaker, rest = parsed
    if not rest:
        return None
    speaker = clean_profiled_speaker(raw_speaker, profile=profile)
    if speaker is None:
        return None
    return speaker, rest, True


def parse_profiled_inline_dot_speech(
    linestr: str,
    *,
    profile: FormatProfile,
) -> tuple[str, str, bool] | None:
    parsed = split_profiled_dot_label(linestr, profile=profile)
    if parsed is None:
        return None
    raw_speaker, rest = parsed
    if not rest:
        return None
    speaker = clean_profiled_speaker(raw_speaker, profile=profile)
    if speaker is None:
        return None
    return speaker, rest, True


def parse_profiled_block_dot_speech(
    linestr: str,
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile,
) -> tuple[str, str, bool] | None:
    parsed = split_profiled_dot_label(linestr, profile=profile)
    if parsed is None:
        return None
    raw_speaker, rest = parsed
    if rest:
        return None
    speaker = clean_profiled_speaker(raw_speaker, profile=profile)
    if speaker is None or not next_nonblank_line_can_start_speech(lines, index, profile=profile):
        return None
    return speaker, "", False


def parse_profiled_bare_speech(
    linestr: str,
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile,
) -> tuple[str, str, bool] | None:
    bare_match = PROFILED_BARE_SPEAKER_RE.match(linestr)
    if not bare_match:
        return None
    speaker = clean_profiled_speaker(bare_match.group(1), profile=profile)
    if speaker is None or not next_nonblank_line_can_start_speech(lines, index, profile=profile):
        return None
    return speaker, "", False


def split_profiled_dot_label(linestr: str, *, profile: FormatProfile) -> tuple[str, str] | None:
    plain_split = split_profiled_plain_dot_label(linestr, profile=profile)
    if plain_split is not None:
        return plain_split

    if not profile_allows_speaker_cues(profile):
        return None

    cue_delimiter_pattern = profile_cue_delimiter_pattern(profile)
    match = re.match(
        rf"^\s*([A-Za-z][A-Za-z0-9'’ .\-&]+?)\s*{cue_delimiter_pattern}\s*\.\s*(.*)\s*$",
        linestr,
    )
    if not match:
        return None
    return normalise_whitespace(match.group(1)).strip(), match.group(2).strip()


def split_profiled_plain_dot_label(linestr: str, *, profile: FormatProfile) -> tuple[str, str] | None:
    stripped = linestr.strip()
    for position in range(len(stripped) - 1, -1, -1):
        if stripped[position] != ".":
            continue
        raw_speaker = normalise_whitespace(stripped[:position]).strip()
        if not raw_speaker or not PROFILED_DOT_SPEAKER_RE.match(f"{raw_speaker}. "):
            continue
        if clean_profiled_speaker(raw_speaker, profile=profile) is None:
            continue
        return raw_speaker, stripped[position + 1 :].strip()
    return None


def split_profiled_colon_label_with_cue(
    linestr: str,
    *,
    profile: FormatProfile,
) -> tuple[str, str] | None:
    if not profile_allows_speaker_cues(profile):
        return None

    cue_delimiter_pattern = profile_cue_delimiter_pattern(profile)
    match = re.match(
        rf"^\s*([A-Za-z][A-Za-z0-9'’ .\-&]+?)\s*{cue_delimiter_pattern}\s*:\s*(.*)\s*$",
        linestr,
    )
    if not match:
        return None
    return normalise_whitespace(match.group(1)).strip(), match.group(2).strip()


def profile_cue_delimiter_pattern(profile: FormatProfile) -> str:
    patterns: list[str] = []
    delimiters = profile.speaker_cue_delimiters
    if "()" in delimiters:
        patterns.append(r"\([^)]+\)")
    if "[]" in delimiters:
        patterns.append(r"\[[^\]]+\]")
    return "(?:" + "|".join(patterns) + ")"


def profile_allows_speaker_cues(profile: FormatProfile) -> bool:
    return bool(profile.speaker_cue_delimiters)


def clean_profiled_speaker(raw_speaker: str, *, profile: FormatProfile) -> str | None:
    if not profile_allows_speaker_case(raw_speaker, profile=profile):
        return None
    speaker = clean_speaker(raw_speaker)
    if not looks_like_speaker_label_text(speaker):
        return None
    if not is_probable_speaker(speaker):
        return None
    return speaker


def profile_allows_speaker_case(raw_speaker: str, *, profile: FormatProfile) -> bool:
    allowed_cases = set(profile.speaker_name_case)
    text = normalise_whitespace(raw_speaker).strip()
    letters = [char for char in text if char.isalpha()]
    if not letters:
        return False
    if "mixed" in allowed_cases:
        return True
    if "upper" in allowed_cases and all(not char.islower() for char in letters):
        return True
    if "title" in allowed_cases and is_title_like_speaker_name(text):
        return True
    return False


def next_nonblank_line_can_start_speech(
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
) -> bool:
    next_index = index + 1
    while next_index < len(lines) and not lines[next_index].strip():
        next_index += 1
    if next_index >= len(lines):
        return False

    next_line = lines[next_index].strip()
    return not is_structural_line(next_line) and not is_stage_direction_line(next_line, profile=profile)


def profile_allows_wrapped_colon_speech(profile: FormatProfile) -> bool:
    return "BARE_NAME" in profile.speaker_label_patterns and profile.speaker_text_position in {
        "next_nonblank_line",
        "mixed",
    }


def parse_wrapped_speech_start(
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
) -> tuple[str, str, int] | None:
    if profile is not None and not profile_allows_wrapped_colon_speech(profile):
        return None

    if index < 0 or index >= len(lines):
        return None
    current = lines[index].strip()
    if is_stage_direction_line(current, profile=profile):
        return None
    bare_match = BARE_SPEAKER_RE.match(current)
    if not bare_match:
        return None

    speaker = clean_speaker(bare_match.group(1))
    if not is_probable_speaker(speaker):
        return None

    next_index = index + 1
    while next_index < len(lines) and not lines[next_index].strip():
        next_index += 1
    if next_index >= len(lines):
        return None

    next_line = lines[next_index].strip()
    match = COLON_SPEAKER_RE.match(next_line)
    if not match:
        return None

    raw_tail = normalise_whitespace(match.group(1)).strip()
    tail = clean_speaker(raw_tail)
    rest = match.group(2).strip()
    combined = clean_speaker(f"{speaker} {tail}")
    if not looks_like_speaker_label_text(combined):
        return None
    if not is_probable_speaker(combined):
        return None
    if profile is not None and clean_profiled_speaker(combined, profile=profile) is None:
        return None
    return combined, rest, next_index


def previous_nonblank_index(lines: Sequence[str], index: int) -> int | None:
    probe = index - 1
    while probe >= 0:
        if lines[probe].strip():
            return probe
        probe -= 1
    return None


def has_speech_boundary_before(
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
) -> bool:
    prev_index = previous_nonblank_index(lines, index)
    if prev_index is None:
        return True
    if prev_index < index - 1:
        return True
    previous = lines[prev_index].strip()
    return is_structural_line(previous) or is_stage_direction_line(previous, profile=profile)


def starts_new_speech_at(
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
    require_boundary: bool = True,
) -> bool:
    wrapped_start = parse_wrapped_speech_start(lines, index, profile=profile)
    if wrapped_start is not None:
        if require_boundary:
            return True
        return is_strong_adjacent_speech_start(lines[index].strip(), wrapped_start, profile=profile)

    speech_start = parse_speech_start(lines[index].strip(), lines, index, profile=profile)
    if speech_start is None:
        return False
    if not require_boundary:
        return is_strong_adjacent_speech_start(lines[index].strip(), speech_start, profile=profile)
    return has_speech_boundary_before(lines, index, profile=profile)


def is_strong_adjacent_speech_start(
    linestr: str,
    speech_start: tuple[str, str, bool],
    *,
    profile: FormatProfile | None = None,
) -> bool:
    raw_speaker = raw_speaker_label_from_line(linestr, profile=profile)
    if raw_speaker is None:
        return False
    if profile is None:
        letters = [char for char in raw_speaker if char.isalpha()]
        return len(letters) > 1 and all(not char.islower() for char in letters)
    return clean_profiled_speaker(raw_speaker, profile=profile) is not None


def raw_speaker_label_from_line(linestr: str, *, profile: FormatProfile | None = None) -> str | None:
    if profile is not None:
        parsed = split_profiled_colon_label_with_cue(linestr, profile=profile)
        if parsed is not None:
            return parsed[0]

        colon_match = COLON_SPEAKER_RE.match(linestr)
        if colon_match:
            return normalise_whitespace(colon_match.group(1)).strip()

        dot_parsed = split_profiled_dot_label(linestr, profile=profile)
        if dot_parsed is not None:
            return dot_parsed[0]

        bare_match = PROFILED_BARE_SPEAKER_RE.match(linestr)
        if bare_match:
            return normalise_whitespace(bare_match.group(1)).strip()
        return None

    colon_match = COLON_SPEAKER_RE.match(linestr)
    if colon_match:
        return normalise_whitespace(colon_match.group(1)).strip()
    dot_match = DOT_SPEAKER_RE.match(linestr)
    if dot_match:
        return normalise_whitespace(dot_match.group(1)).strip()
    bare_match = BARE_SPEAKER_RE.match(linestr)
    if bare_match:
        return normalise_whitespace(bare_match.group(1)).strip()
    return None


class SpeechAccumulator:
    """Accumulates speech text and stage-direction events for one speaker."""

    def __init__(self, *, speaker: str, labelled: bool | None, consumes_start_line: bool) -> None:
        self.speaker = speaker
        self.events: list[PlayEvent] = []
        self.current_parts: list[str] = []
        self.current_line_count = 0
        self.has_speech_text = False
        self.next_speech_is_labelled = consumes_start_line if labelled is None else labelled

    def add_text(self, text: str) -> None:
        cleaned = text.strip()
        if not cleaned:
            return
        self.current_parts.append(cleaned)
        self.current_line_count += 1
        self.has_speech_text = True

    def add_stage_direction(self, text: str, *, profile: FormatProfile | None = None) -> int:
        self.flush()
        self.events.append(
            StageDirectionEvent(
                type="stage_direction",
                subtype=classify_stage_direction(text, profile=profile),
                text=clean_stage_direction_text(text, profile=profile),
            )
        )
        return len(self.events) - 1

    def mark_attached_to_next(self, event_index: int) -> None:
        event = self.events[event_index]
        if event["type"] == "stage_direction":
            event["attachment"] = "next"

    def flush(self) -> None:
        if not self.current_parts:
            self.current_line_count = 0
            return
        text = "\n".join(self.current_parts).strip()
        if text:
            self.events.append(
                SpeechEvent(
                    type="speech",
                    speaker=self.speaker,
                    text=text,
                    line_count=self.current_line_count,
                    word_count=count_words(text),
                    labelled=self.next_speech_is_labelled,
                )
            )
        self.current_parts = []
        self.current_line_count = 0
        self.next_speech_is_labelled = False

    def absorb_dialogue_text(self, dialogue_text: str, *, profile: FormatProfile | None = None) -> None:
        chunks = split_inline_stage_directions(dialogue_text, profile=profile)
        leading_stage_event_indexes: list[int] = []
        seen_speech_text_in_line = False

        for kind, part in chunks:
            cleaned = part.strip()
            if not cleaned:
                continue
            if kind == "speech":
                if not seen_speech_text_in_line:
                    for event_index in leading_stage_event_indexes:
                        self.mark_attached_to_next(event_index)
                seen_speech_text_in_line = True
                self.add_text(cleaned)
                continue

            stage_event_index = self.add_stage_direction(cleaned, profile=profile)
            if not seen_speech_text_in_line:
                leading_stage_event_indexes.append(stage_event_index)


def consume_speech(
    lines: Sequence[str],
    start_index: int,
    speaker: str,
    first_text: str,
    consumes_start_line: bool,
    labelled: bool | None = None,
    profile: FormatProfile | None = None,
) -> tuple[list[PlayEvent], int]:
    accumulator = SpeechAccumulator(
        speaker=speaker,
        labelled=labelled,
        consumes_start_line=consumes_start_line,
    )

    index = start_index
    if consumes_start_line:
        accumulator.absorb_dialogue_text(first_text, profile=profile)
        index += 1
    else:
        index += 1

    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped:
            break
        if is_structural_line(stripped):
            break
        starts_after_stage_direction = (
            bool(accumulator.events)
            and accumulator.events[-1]["type"] == "stage_direction"
            and not accumulator.current_parts
        )
        if accumulator.has_speech_text and starts_new_speech_at(
            lines,
            index,
            profile=profile,
            require_boundary=starts_after_stage_direction,
        ):
            break
        if is_stage_direction_line(stripped, profile=profile):
            accumulator.add_stage_direction(stripped, profile=profile)
            index += 1
            continue
        multiline_stage_direction, next_index = consume_multiline_stage_direction(lines, index, profile=profile)
        if multiline_stage_direction is not None:
            accumulator.flush()
            accumulator.events.append(multiline_stage_direction)
            index = next_index
            continue
        accumulator.absorb_dialogue_text(stripped, profile=profile)
        index += 1

    accumulator.flush()
    return accumulator.events, index


def last_speech_event_index(events: Sequence[PlayEvent]) -> int:
    for event_index in range(len(events) - 1, -1, -1):
        if events[event_index]["type"] == "speech":
            return event_index
    return -1


def should_continue_previous_speech_after_stage_direction(
    lines: Sequence[str],
    index: int,
    events: Sequence[PlayEvent],
    *,
    body_started: bool,
    last_speech_speaker: str | None,
    last_speech_index: int,
    profile: FormatProfile | None = None,
) -> bool:
    """Return whether a speech should continue after an intervening stage direction."""
    if not body_started or not last_speech_speaker or last_speech_index < 0:
        return False

    stripped = lines[index].strip()
    if is_structural_line(stripped) or is_stage_direction_line(stripped, profile=profile):
        return False
    if starts_new_speech_at(lines, index, profile=profile):
        return False
    if last_speech_index >= len(events) - 1:
        return False
    return events[-1]["type"] == "stage_direction"
