"""Speaker-name normalisation and speaker-label heuristics."""

from __future__ import annotations

import re

from play_parser.document.text import normalise_whitespace
from play_parser.parsing.structure import ROMAN_RE

MAX_SPEAKER_LABEL_WORDS = 8
NAME_TOKEN_RE = re.compile(r"^[A-Z][A-Za-z'’\-]*$")
ALLOWED_SPEAKER_PARTICLES = {"de", "du", "la", "le", "of", "the", "and"}
FRONT_MATTER_LABELS = {"time", "place", "setting", "author", "subtitle"}
ORDINAL_SPEAKER_HEADS = {
    "all",
    "both",
    "either",
    "neither",
    "first",
    "second",
    "third",
    "fourth",
    "fifth",
    "sixth",
    "seventh",
    "eighth",
    "ninth",
    "tenth",
}
COLLECTIVE_SPEAKER_WORDS = {
    *ORDINAL_SPEAKER_HEADS,
    "everyone",
    "everybody",
    "lord",
    "lords",
    "citizen",
    "citizens",
    "servant",
    "servants",
    "soldier",
    "soldiers",
    "gentleman",
    "gentlemen",
    "lady",
    "ladies",
    "friend",
    "friends",
    "man",
    "men",
    "woman",
    "women",
}
COLLECTIVE_SPEAKER_HEADS = COLLECTIVE_SPEAKER_WORDS - {"everyone", "everybody"}


def clean_speaker(value: str) -> str:
    text = normalise_whitespace(value).strip(" .:;")
    if text.isupper():
        lowercase_particles = {"of", "de", "du", "la", "le"}
        words = text.split()
        normalized_words: list[str] = []
        for index, word in enumerate(words):
            lowered = word.casefold()
            if ROMAN_RE.fullmatch(word):
                normalized_words.append(word.upper())
                continue
            if lowered in lowercase_particles and index > 0:
                normalized_words.append(lowered)
                continue
            parts = [part.capitalize() for part in word.split("-")]
            normalized_words.append("-".join(parts))
        return " ".join(normalized_words)
    return text


def is_probable_speaker(speaker: str) -> bool:
    if not speaker:
        return False
    if len(speaker.split()) > MAX_SPEAKER_LABEL_WORDS:
        return False
    if speaker.casefold() in FRONT_MATTER_LABELS - {"time"}:
        return False

    words = [word.strip(".").casefold() for word in speaker.split()]
    if not words:
        return False
    if any(words[0].startswith(head) for head in ORDINAL_SPEAKER_HEADS):
        return True
    if any(word in COLLECTIVE_SPEAKER_WORDS for word in words):
        return True
    return any(char.isalpha() for char in speaker)


def looks_like_speaker_label_text(text: str) -> bool:
    tokens = [token for token in re.split(r"\s+", text.strip()) if token]
    if not tokens:
        return False
    if len(tokens) > MAX_SPEAKER_LABEL_WORDS:
        return False

    first_token = tokens[0].strip(".").casefold()
    if first_token in ORDINAL_SPEAKER_HEADS or first_token in COLLECTIVE_SPEAKER_HEADS:
        return True

    for token in tokens:
        cleaned = token.strip(".")
        if not cleaned:
            return False
        if cleaned.isupper():
            continue
        if cleaned.casefold() in ALLOWED_SPEAKER_PARTICLES:
            continue
        if ROMAN_RE.fullmatch(cleaned):
            continue
        if not NAME_TOKEN_RE.fullmatch(cleaned):
            return False
    return True


def is_title_like_speaker_name(text: str) -> bool:
    tokens = [token.strip(".") for token in re.split(r"[\s\-]+", text) if token.strip(".")]
    if not tokens:
        return False
    for token in tokens:
        if token.casefold() in ALLOWED_SPEAKER_PARTICLES:
            continue
        first_alpha = next((char for char in token if char.isalpha()), "")
        if not first_alpha or not first_alpha.isupper():
            return False
    return True
