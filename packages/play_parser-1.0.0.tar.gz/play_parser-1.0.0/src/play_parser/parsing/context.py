from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from play_parser.document.text import normalise_whitespace
from play_parser.document.types import PlayEvent, StageDirectionEvent
from play_parser.parsing.speech import starts_new_speech_at
from play_parser.parsing.stage import is_stage_direction_line
from play_parser.parsing.structure import is_structural_line

if TYPE_CHECKING:
    from play_parser.parsing.profiles import FormatProfile


def consume_scene_opening(
    lines: Sequence[str],
    index: int,
    events: list[PlayEvent],
    *,
    profile: FormatProfile | None = None,
) -> int:
    """Attach an unbracketed scene-opening paragraph as setting text."""
    if not events or events[-1]["type"] != "scene_start":
        return index

    scene_event = events[-1]
    if not isinstance(scene_event, dict):
        return index

    while index < len(lines) and not lines[index].strip():
        index += 1
    if index >= len(lines):
        return index

    stripped = lines[index].strip()
    if (
        is_structural_line(stripped)
        or is_stage_direction_line(stripped, profile=profile)
        or starts_new_speech_at(lines, index, profile=profile)
    ):
        return index

    paragraph_lines: list[str] = []
    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped:
            break
        if (
            is_structural_line(stripped)
            or is_stage_direction_line(stripped, profile=profile)
            or starts_new_speech_at(lines, index, profile=profile)
        ):
            break
        paragraph_lines.append(stripped)
        index += 1

    if not paragraph_lines:
        return index

    paragraph = normalise_whitespace(" ".join(paragraph_lines))
    events.append(StageDirectionEvent(type="stage_direction", subtype="setting", text=paragraph))
    return index


def consume_unbracketed_stage_paragraph(
    lines: Sequence[str],
    index: int,
    events: list[PlayEvent],
    *,
    profile: FormatProfile | None = None,
) -> tuple[StageDirectionEvent | None, int]:
    """Consume a profile-enabled unbracketed stage paragraph after the body starts."""
    paragraph_lines: list[str] = []
    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped:
            break
        if is_structural_line(stripped) or is_stage_direction_line(stripped, profile=profile):
            break
        if starts_new_speech_at(lines, index, profile=profile):
            break
        paragraph_lines.append(stripped)
        index += 1

    if not paragraph_lines:
        return None, index

    return (
        StageDirectionEvent(
            type="stage_direction",
            subtype="setting" if should_treat_as_setting(events) else "action",
            text=normalise_whitespace(" ".join(paragraph_lines)),
        ),
        index,
    )


def should_treat_as_setting(events: Sequence[PlayEvent]) -> bool:
    if not events:
        return False
    last = events[-1]
    return last["type"] == "scene_start"
