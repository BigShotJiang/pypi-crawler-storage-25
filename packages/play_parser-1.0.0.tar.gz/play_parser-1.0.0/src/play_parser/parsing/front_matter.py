from __future__ import annotations

import re

from play_parser.document.text import count_words
from play_parser.document.types import MetaEvent, StageDirectionEvent
from play_parser.parsing.speakers import FRONT_MATTER_LABELS

LABELED_META_RE = re.compile(r"^\s*(TIME|PLACE|SETTING|AUTHOR|SUBTITLE)\s*:\s*(.+)\s*$", re.IGNORECASE)
BYLINE_RE = re.compile(r"^\s*by\s+.+$", re.IGNORECASE)
CAST_HEADING_RE = re.compile(
    r"^\s*(?:dramatis personae|characters|cast(?: of characters)?|"
    r"the persons in the play|persons in the play)\s*:?\s*$",
    re.IGNORECASE,
)
MAX_CAST_CHARACTER_WORDS = 12
MAX_DOTTED_CAST_CHARACTER_WORDS = 8
MIN_AUTHOR_LINE_WORDS = 2
MAX_AUTHOR_LINE_WORDS = 5


def suppress_front_matter_speech_matches(
    wrapped_speech_start: tuple[str, str, int] | None,
    speech_start: tuple[str, str, bool] | None,
) -> tuple[tuple[str, str, int] | None, tuple[str, str, bool] | None]:
    """Discard speech-label matches that are more likely front-matter labels."""
    wrapped_label = wrapped_speech_start[0] if wrapped_speech_start is not None else ""
    speech_label = speech_start[0] if speech_start is not None else ""
    if wrapped_label.casefold() in FRONT_MATTER_LABELS:
        wrapped_speech_start = None
    if speech_label.casefold() in FRONT_MATTER_LABELS:
        speech_start = None
    return wrapped_speech_start, speech_start


def parse_front_matter_line(
    line: str, front_matter_count: int, in_cast_list: bool
) -> MetaEvent | StageDirectionEvent | None:
    labeled_meta = LABELED_META_RE.match(line)
    if labeled_meta:
        subtype = labeled_meta.group(1).strip().lower()
        return MetaEvent(type="meta", subtype=subtype, text=line.strip())

    if BYLINE_RE.match(line):
        return MetaEvent(type="meta", subtype="author", text=line.strip())

    if is_cast_heading(line):
        return StageDirectionEvent(type="stage_direction", subtype="cast_list_heading", text=line.strip())

    if in_cast_list and looks_like_cast_character(line):
        return StageDirectionEvent(type="stage_direction", subtype="character", text=line.strip())

    if front_matter_count == 0:
        return MetaEvent(type="meta", subtype="title", text=line.strip())
    if front_matter_count == 1 and looks_like_author_line(line):
        return MetaEvent(type="meta", subtype="author", text=line.strip())
    if front_matter_count == 1:
        return MetaEvent(type="meta", subtype="subtitle", text=line.strip())
    if front_matter_count == 2 and looks_like_author_line(line):
        return MetaEvent(type="meta", subtype="author", text=line.strip())
    if front_matter_count == 2:
        return MetaEvent(type="meta", subtype="subtitle", text=line.strip())
    return MetaEvent(type="meta", subtype="note", text=line.strip())


def looks_like_author_line(line: str) -> bool:
    if BYLINE_RE.match(line):
        return True
    words = line.split()
    if len(words) < MIN_AUTHOR_LINE_WORDS or len(words) > MAX_AUTHOR_LINE_WORDS:
        return False
    return all(word[:1].isupper() for word in words if word[:1].isalpha())


def looks_like_cast_character(line: str) -> bool:
    if ":" in line:
        return False
    if len(line.split()) > MAX_CAST_CHARACTER_WORDS:
        return False
    if line.endswith(".") and count_words(line) > MAX_DOTTED_CAST_CHARACTER_WORDS:
        return False
    return any(char.isalpha() for char in line)


def is_cast_heading(line: str) -> bool:
    return bool(CAST_HEADING_RE.match(line))
