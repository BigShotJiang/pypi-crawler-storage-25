from __future__ import annotations

REQUIRED_PROFILE_FIELDS = {
    "name",
    "version",
    "description",
    "speaker_label_patterns",
    "speaker_text_position",
    "speaker_name_case",
    "stage_direction_delimiters",
    "inline_stage_directions",
    "multiline_stage_directions",
    "strip_underscore_italics_in_stage_directions",
    "examples",
}
OPTIONAL_PROFILE_FIELDS = {
    "speaker_cue_delimiters",
    "allow_long_unbracketed_stage_paragraphs",
}

ALLOWED_SPEAKER_LABEL_PATTERNS = {
    "NAME_COLON",
    "NAME_DOT",
    "BARE_NAME",
}
ALLOWED_SPEAKER_TEXT_POSITIONS = {
    "same_line",
    "next_nonblank_line",
    "mixed",
}
ALLOWED_SPEAKER_NAME_CASES = {
    "upper",
    "title",
    "mixed",
}
ALLOWED_DELIMITERS = {
    "[]",
    "()",
}


def validate_format_profile_config(config: object) -> dict[str, object]:
    if not isinstance(config, dict):
        raise ValueError(f"Format profile config must be a dict, got {type(config).__name__}")

    missing = REQUIRED_PROFILE_FIELDS - config.keys()
    if missing:
        raise ValueError(f"Format profile is missing required fields: {sorted(missing)}")

    unknown = set(config) - REQUIRED_PROFILE_FIELDS - OPTIONAL_PROFILE_FIELDS
    if unknown:
        raise ValueError(f"Format profile contains unknown fields: {sorted(unknown)}")

    _validate_non_empty_string(config, "name")
    _validate_positive_int(config, "version")
    _validate_non_empty_string(config, "description")
    _validate_string_list(
        config,
        "speaker_label_patterns",
        allowed_values=ALLOWED_SPEAKER_LABEL_PATTERNS,
        non_empty=True,
    )
    _validate_allowed_string(config, "speaker_text_position", ALLOWED_SPEAKER_TEXT_POSITIONS)
    _validate_string_list(
        config,
        "speaker_name_case",
        allowed_values=ALLOWED_SPEAKER_NAME_CASES,
        non_empty=True,
    )
    _validate_string_list(
        config,
        "stage_direction_delimiters",
        allowed_values=ALLOWED_DELIMITERS,
        non_empty=True,
    )
    _validate_bool(config, "inline_stage_directions")
    _validate_bool(config, "multiline_stage_directions")
    _validate_bool(config, "strip_underscore_italics_in_stage_directions")
    _validate_string_list(config, "examples", non_empty=True)

    if "speaker_cue_delimiters" in config:
        _validate_string_list(
            config,
            "speaker_cue_delimiters",
            allowed_values=ALLOWED_DELIMITERS,
            non_empty=True,
        )
    if "allow_long_unbracketed_stage_paragraphs" in config:
        _validate_bool(config, "allow_long_unbracketed_stage_paragraphs")

    return dict(config)


def _validate_non_empty_string(config: dict[str, object], field: str) -> None:
    value = config[field]
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Format profile field {field!r} must be a non-empty string")


def _validate_positive_int(config: dict[str, object], field: str) -> None:
    value = config[field]
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError(f"Format profile field {field!r} must be a positive integer")


def _validate_bool(config: dict[str, object], field: str) -> None:
    value = config[field]
    if not isinstance(value, bool):
        raise ValueError(f"Format profile field {field!r} must be a boolean")


def _validate_allowed_string(config: dict[str, object], field: str, allowed_values: set[str]) -> None:
    value = config[field]
    if not isinstance(value, str) or value not in allowed_values:
        allowed = ", ".join(sorted(allowed_values))
        raise ValueError(f"Format profile field {field!r} must be one of: {allowed}")


def _validate_string_list(
    config: dict[str, object],
    field: str,
    *,
    allowed_values: set[str] | None = None,
    non_empty: bool = False,
) -> None:
    value = config[field]
    if not isinstance(value, list):
        raise ValueError(f"Format profile field {field!r} must be a list of strings")
    if non_empty and not value:
        raise ValueError(f"Format profile field {field!r} must not be empty")
    if not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"Format profile field {field!r} must be a list of non-empty strings")
    if allowed_values is not None:
        invalid = sorted(item for item in value if item not in allowed_values)
        if invalid:
            allowed = ", ".join(sorted(allowed_values))
            raise ValueError(
                f"Format profile field {field!r} contains invalid values {invalid}. Allowed values: {allowed}"
            )
