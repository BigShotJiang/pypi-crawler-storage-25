from __future__ import annotations

import copy
import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from functools import lru_cache
from importlib.resources import files
from pathlib import Path
from types import MappingProxyType
from typing import Any

from play_parser._io import read_json_file

from .schema import validate_format_profile_config

BUILTIN_PROFILE_PACKAGE = "play_parser.parsing.profiles.builtins"
BUILTIN_PROFILE_GLOB = "*.json"
CACHED_FORMAT_PROFILE_SET_COUNT = 1


@dataclass(frozen=True, slots=True)
class FormatProfile:
    name: str
    description: str
    _config: Mapping[str, Any] = field(repr=False)

    @property
    def config(self) -> Mapping[str, Any]:
        """Read-only validated profile configuration.

        Sequence values are exposed as tuples and nested mappings are read-only,
        so callers cannot mutate parser behaviour through a loaded profile.
        Prefer the typed properties below for parser-facing access.
        """
        return self._config

    @property
    def speaker_label_patterns(self) -> tuple[str, ...]:
        return _tuple_config_value(self._config, "speaker_label_patterns")

    @property
    def speaker_text_position(self) -> str:
        return str(self._config["speaker_text_position"])

    @property
    def speaker_name_case(self) -> tuple[str, ...]:
        return _tuple_config_value(self._config, "speaker_name_case")

    @property
    def speaker_cue_delimiters(self) -> tuple[str, ...]:
        return _tuple_config_value(self._config, "speaker_cue_delimiters")

    @property
    def stage_direction_delimiters(self) -> tuple[str, ...]:
        return _tuple_config_value(self._config, "stage_direction_delimiters")

    @property
    def inline_stage_directions(self) -> bool:
        return bool(self._config["inline_stage_directions"])

    @property
    def multiline_stage_directions(self) -> bool:
        return bool(self._config["multiline_stage_directions"])

    @property
    def allow_long_unbracketed_stage_paragraphs(self) -> bool:
        return bool(self._config.get("allow_long_unbracketed_stage_paragraphs", False))

    @property
    def strip_underscore_italics_in_stage_directions(self) -> bool:
        return bool(self._config["strip_underscore_italics_in_stage_directions"])

    @property
    def examples(self) -> tuple[str, ...]:
        return _tuple_config_value(self._config, "examples")


def _tuple_config_value(config: Mapping[str, Any], key: str) -> tuple[str, ...]:
    value = config.get(key, ())
    if isinstance(value, tuple):
        return tuple(str(item) for item in value)
    return tuple(str(item) for item in value)


def _freeze_config(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze_config(item) for key, item in value.items()})
    if isinstance(value, list | tuple):
        return tuple(_freeze_config(item) for item in value)
    return copy.deepcopy(value)


def list_format_profiles() -> list[str]:
    return sorted(_load_builtin_profiles())


def get_format_profile(name: str) -> FormatProfile:
    profiles = _load_builtin_profiles()
    try:
        return profiles[name]
    except KeyError as exc:
        available = ", ".join(sorted(profiles))
        raise KeyError(f"Unknown format profile {name!r}. Available profiles: {available}") from exc


def load_format_profile_file(path: str | Path) -> FormatProfile:
    input_path = Path(path)
    payload = read_json_file(input_path)
    if not isinstance(payload, dict):
        raise ValueError(f"Format profile file must contain a JSON object: {input_path}")
    return load_format_profile_config(payload)


def load_format_profile_config(config: Mapping[str, object], *, name: str | None = None) -> FormatProfile:
    profile_config = copy.deepcopy(dict(config))
    if name is not None:
        existing_name = profile_config.get("name")
        if existing_name is not None and existing_name != name:
            raise ValueError(
                f"Format profile name mismatch: explicit name {name!r} does not match config name {existing_name!r}"
            )
        profile_config["name"] = name

    profile_config = validate_format_profile_config(profile_config)
    return FormatProfile(
        name=str(profile_config["name"]),
        description=str(profile_config["description"]),
        _config=_freeze_config(profile_config),
    )


@lru_cache(maxsize=CACHED_FORMAT_PROFILE_SET_COUNT)
def _load_builtin_profiles() -> dict[str, FormatProfile]:
    profiles: dict[str, FormatProfile] = {}
    for resource in files(BUILTIN_PROFILE_PACKAGE).iterdir():
        if not resource.name.endswith(".json"):
            continue
        payload = json.loads(resource.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError(f"Built-in format profile must contain a JSON object: {resource.name}")
        profile = load_format_profile_config(payload)
        expected_name = resource.name.removesuffix(".json")
        if profile.name != expected_name:
            raise ValueError(
                f"Built-in format profile {resource.name!r} declares name {profile.name!r}; expected {expected_name!r}"
            )
        profiles[profile.name] = profile
    return profiles
