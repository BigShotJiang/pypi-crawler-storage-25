from __future__ import annotations

import re
from collections.abc import Sequence
from typing import TYPE_CHECKING

from play_parser.document.types import StageDirectionEvent

if TYPE_CHECKING:
    from play_parser.parsing.profiles import FormatProfile

INLINE_STAGE_RE = re.compile(r"(\[[^\]]+\]|\([^)]+\))")
STAGE_DIRECTION_ITALIC_RE = re.compile(r"_+")
UNBRACKETED_MOVEMENT_RE = re.compile(r"^\s*(?:enter|re-enter|exit|exeunt)\b", re.IGNORECASE)
UNBRACKETED_CUE_RE = re.compile(
    r"^\s*(?:aside(?:\s+to\b.*)?|within|flourish|sennet|alarum|music|song|drum|drums|"
    r"trumpet|trumpets)\s*[.!;:, -]*\s*$",
    re.IGNORECASE,
)
CAST_LIST_HEADING_PHRASES = ("dramatis personae", "persons in the play")
CAST_LIST_HEADING_EXACT = {"characters"}
ENTER_KEYWORDS = ("enter", "re-enter")
EXIT_KEYWORDS = ("exit", "exeunt", "goes out")
ASIDE_KEYWORDS = ("aside",)
SETTING_KEYWORDS = ("room",)
SOUND_KEYWORDS = ("music", "flourish", "sennet", "alarum", "song")


EMPTY_BRACKET_TOKENS_RE = re.compile(r"[\t ]*(\[[\t ]*\]|\([\t ]*\)|\{[\t ]*\})[\t ]*")


def strip_empty_bracket_tokens(text: str) -> str:
    text = EMPTY_BRACKET_TOKENS_RE.sub(" ", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


def split_inline_stage_directions(
    text: str,
    *,
    profile: FormatProfile | None = None,
) -> list[tuple[str, str]]:
    if profile is not None and not profile.inline_stage_directions:
        return [("speech", text)]

    inline_stage_re = INLINE_STAGE_RE if profile is None else profile_inline_stage_re(profile)
    parts: list[tuple[str, str]] = []
    cursor = 0
    for match in inline_stage_re.finditer(text):
        if match.start() > cursor:
            parts.append(("speech", text[cursor : match.start()]))
        token = match.group(1)
        if token.strip("[]() \t"):
            parts.append(("stage", token))
        cursor = match.end()
    if cursor < len(text):
        parts.append(("speech", text[cursor:]))
    if not parts:
        parts.append(("speech", text))
    return parts


def clean_stage_direction_text(text: str, *, profile: FormatProfile | None = None) -> str:
    if profile is None or profile.strip_underscore_italics_in_stage_directions:
        cleaned = STAGE_DIRECTION_ITALIC_RE.sub("", text)
    else:
        cleaned = text
    return re.sub(r" {2,}", " ", cleaned).strip()


def consume_multiline_stage_direction(
    lines: Sequence[str],
    index: int,
    *,
    profile: FormatProfile | None = None,
) -> tuple[StageDirectionEvent | None, int]:
    if profile is not None and not profile.multiline_stage_directions:
        return None, index

    stripped = lines[index].strip()
    if not stripped:
        return None, index

    if profile_allows_stage_delimiter(profile, "[]") and stripped.startswith("[") and not stripped.endswith("]"):
        closing = "]"
    elif profile_allows_stage_delimiter(profile, "()") and stripped.startswith("(") and not stripped.endswith(")"):
        closing = ")"
    else:
        return None, index

    parts = [stripped]
    next_index = index + 1
    while next_index < len(lines):
        piece = lines[next_index].strip()
        if piece:
            parts.append(piece)
            if piece.endswith(closing):
                text = _normalise_whitespace(" ".join(parts))
                return (
                    StageDirectionEvent(
                        type="stage_direction",
                        subtype=classify_stage_direction(text, profile=profile),
                        text=clean_stage_direction_text(text, profile=profile),
                    ),
                    next_index + 1,
                )
        next_index += 1

    return None, index


def is_stage_direction_line(line: str, *, profile: FormatProfile | None = None) -> bool:
    stripped = line.strip()
    return (
        is_bracketed(stripped, profile=profile)
        or bool(UNBRACKETED_MOVEMENT_RE.match(stripped))
        or bool(UNBRACKETED_CUE_RE.match(stripped))
    )


def is_bracketed(line: str, *, profile: FormatProfile | None = None) -> bool:
    stripped = line.strip()
    return (profile_allows_stage_delimiter(profile, "[]") and stripped.startswith("[") and stripped.endswith("]")) or (
        profile_allows_stage_delimiter(profile, "()") and stripped.startswith("(") and stripped.endswith(")")
    )


def classify_stage_direction(text: str, *, profile: FormatProfile | None = None) -> str | None:
    lowered = text.casefold()
    if classify_stage_direction_by_keywords(lowered, CAST_LIST_HEADING_PHRASES, exact=CAST_LIST_HEADING_EXACT):
        return "cast_list_heading"
    if classify_stage_direction_by_keywords(lowered, ENTER_KEYWORDS):
        return "enter"
    if classify_stage_direction_by_keywords(lowered, EXIT_KEYWORDS):
        return "exit"
    if classify_stage_direction_by_keywords(lowered, ASIDE_KEYWORDS):
        return "aside"
    if classify_stage_direction_by_keywords(lowered, SETTING_KEYWORDS) and not is_bracketed(text, profile=profile):
        return "setting"
    if classify_stage_direction_by_keywords(lowered, SOUND_KEYWORDS):
        return "sound"
    return "action"


def classify_stage_direction_by_keywords(
    lowered_text: str,
    keywords: Sequence[str],
    *,
    exact: set[str] | None = None,
) -> bool:
    if exact is not None and lowered_text in exact:
        return True
    return any(keyword in lowered_text for keyword in keywords)


def profile_allows_stage_delimiter(profile: FormatProfile | None, delimiter: str) -> bool:
    if profile is None:
        return True
    return delimiter in profile.stage_direction_delimiters


def profile_inline_stage_re(profile: FormatProfile) -> re.Pattern[str]:
    patterns: list[str] = []
    if profile_allows_stage_delimiter(profile, "[]"):
        patterns.append(r"\[[^\]]+\]")
    if profile_allows_stage_delimiter(profile, "()"):
        patterns.append(r"\([^)]+\)")
    if not patterns:
        return re.compile(r"a\A")
    return re.compile("(" + "|".join(patterns) + ")")


def profile_allows_long_unbracketed_stage_paragraphs(profile: FormatProfile | None) -> bool:
    return bool(profile is not None and profile.allow_long_unbracketed_stage_paragraphs)


def _normalise_whitespace(text: str) -> str:
    return " ".join(text.split())
