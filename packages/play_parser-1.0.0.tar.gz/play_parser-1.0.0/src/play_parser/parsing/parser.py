from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from play_parser._io import read_text_file
from play_parser.document.text import normalise_whitespace
from play_parser.document.types import (
    ActStartEvent,
    MetaEvent,
    PlayEvent,
    StageDirectionEvent,
)
from play_parser.parsing.context import (
    consume_scene_opening,
    consume_unbracketed_stage_paragraph,
    should_treat_as_setting,
)
from play_parser.parsing.front_matter import (
    is_cast_heading,
    looks_like_cast_character,
    parse_front_matter_line,
    suppress_front_matter_speech_matches,
)
from play_parser.parsing.speech import (
    consume_speech,
    last_speech_event_index,
    parse_speech_start,
    parse_wrapped_speech_start,
    should_continue_previous_speech_after_stage_direction,
)
from play_parser.parsing.stage import (
    classify_stage_direction,
    clean_stage_direction_text,
    consume_multiline_stage_direction,
    is_stage_direction_line,
    profile_allows_long_unbracketed_stage_paragraphs,
    strip_empty_bracket_tokens,
)
from play_parser.parsing.structure import parse_act_number, parse_scene_start

if TYPE_CHECKING:
    from play_parser.parsing.profiles import FormatProfile


@dataclass(slots=True)
class ParserState:
    lines: Sequence[str]
    profile: FormatProfile | None = None
    index: int = 0
    events: list[PlayEvent] = field(default_factory=list)
    body_started: bool = False
    in_cast_list: bool = False
    front_matter_count: int = 0
    last_speech_speaker: str | None = None
    last_speech_index: int = -1

    @property
    def current_line(self) -> str:
        return self.lines[self.index]

    @property
    def stripped(self) -> str:
        return self.current_line.strip()

    def advance(self, count: int = 1) -> None:
        self.index += count

    def mark_body_started(self) -> None:
        self.body_started = True
        self.in_cast_list = False

    def reset_speech_tracking(self) -> None:
        self.last_speech_speaker = None
        self.last_speech_index = -1

    def append_speech_events(self, speaker: str, speech_events: Sequence[PlayEvent], next_index: int) -> None:
        self.events.extend(speech_events)
        self.last_speech_speaker = speaker
        self.last_speech_index = last_speech_event_index(self.events)
        self.index = next_index


def parse_play_text(text: str, *, profile: FormatProfile | None = None) -> list[PlayEvent]:
    state = ParserState(
        lines=[strip_empty_bracket_tokens(line) for line in text.splitlines()],
        profile=profile,
    )

    while state.index < len(state.lines):
        if consume_blank_line(state):
            continue
        if try_consume_structure(state):
            continue
        if try_consume_speech(state):
            continue
        if try_consume_front_matter(state):
            continue
        if try_consume_stage_direction(state):
            continue
        consume_fallback(state)

    return state.events


def consume_blank_line(state: ParserState) -> bool:
    if state.stripped:
        return False
    state.in_cast_list = False
    state.advance()
    return True


def try_consume_structure(state: ParserState) -> bool:
    stripped = state.stripped

    act_number = parse_act_number(stripped)
    if act_number is not None:
        state.mark_body_started()
        state.reset_speech_tracking()
        state.events.append(ActStartEvent(type="act_start", act_number=act_number, label=stripped))
        state.advance()
        return True

    scene_start = parse_scene_start(stripped)
    if scene_start is not None:
        state.mark_body_started()
        state.reset_speech_tracking()
        state.events.append(scene_start)
        state.advance()
        state.index = consume_scene_opening(state.lines, state.index, state.events, profile=state.profile)
        return True

    if is_cast_heading(stripped):
        state.in_cast_list = True
        state.events.append(StageDirectionEvent(type="stage_direction", subtype="cast_list_heading", text=stripped))
        state.advance()
        return True

    return False


def try_consume_speech(state: ParserState) -> bool:
    stripped = state.stripped
    wrapped_speech_start = parse_wrapped_speech_start(state.lines, state.index, profile=state.profile)
    speech_start = parse_speech_start(stripped, state.lines, state.index, profile=state.profile)

    if not state.body_started:
        wrapped_speech_start, speech_start = suppress_front_matter_speech_matches(
            wrapped_speech_start,
            speech_start,
        )

    if wrapped_speech_start is not None:
        state.mark_body_started()
        speaker, first_text, payload_index = wrapped_speech_start
        speech_events, next_index = consume_speech(
            state.lines,
            payload_index,
            speaker,
            first_text,
            True,
            labelled=True,
            profile=state.profile,
        )
        state.append_speech_events(speaker, speech_events, next_index)
        return True

    if speech_start is not None:
        state.mark_body_started()
        speaker, first_text, consumes_line = speech_start
        speech_events, next_index = consume_speech(
            state.lines,
            state.index,
            speaker,
            first_text,
            consumes_line,
            labelled=consumes_line,
            profile=state.profile,
        )
        state.append_speech_events(speaker, speech_events, next_index)
        return True

    if not should_continue_previous_speech_after_stage_direction(
        state.lines,
        state.index,
        state.events,
        body_started=state.body_started,
        last_speech_speaker=state.last_speech_speaker,
        last_speech_index=state.last_speech_index,
        profile=state.profile,
    ):
        return False

    continuation_events, next_index = consume_speech(
        state.lines,
        state.index,
        state.last_speech_speaker,
        stripped,
        True,
        labelled=False,
        profile=state.profile,
    )
    state.events.extend(continuation_events)
    state.last_speech_index = last_speech_event_index(state.events)
    state.index = next_index
    return True


def try_consume_front_matter(state: ParserState) -> bool:
    if state.body_started:
        return False

    stripped = state.stripped
    meta_event = parse_front_matter_line(stripped, state.front_matter_count, state.in_cast_list)
    if meta_event is not None:
        if meta_event["type"] == "meta":
            state.front_matter_count += 1
        elif meta_event.get("subtype") == "cast_list_heading":
            state.in_cast_list = True
        state.events.append(meta_event)
        state.advance()
        return True

    if state.in_cast_list or looks_like_cast_character(stripped):
        state.events.append(StageDirectionEvent(type="stage_direction", subtype="character", text=stripped))
        state.advance()
        return True

    return False


def try_consume_stage_direction(state: ParserState) -> bool:
    stripped = state.stripped
    if is_stage_direction_line(stripped, profile=state.profile):
        state.events.append(
            StageDirectionEvent(
                type="stage_direction",
                subtype=classify_stage_direction(stripped, profile=state.profile),
                text=clean_stage_direction_text(stripped, profile=state.profile),
            )
        )
        state.advance()
        return True

    multiline_stage_direction, next_index = consume_multiline_stage_direction(
        state.lines,
        state.index,
        profile=state.profile,
    )
    if multiline_stage_direction is not None:
        state.events.append(multiline_stage_direction)
        state.index = next_index
        return True

    return False


def consume_fallback(state: ParserState) -> None:
    stripped = state.stripped
    if state.body_started:
        if profile_allows_long_unbracketed_stage_paragraphs(state.profile):
            stage_direction, next_index = consume_unbracketed_stage_paragraph(
                state.lines,
                state.index,
                state.events,
                profile=state.profile,
            )
            if stage_direction is not None:
                state.events.append(stage_direction)
                state.index = next_index
                return

        state.events.append(
            StageDirectionEvent(
                type="stage_direction",
                subtype="setting" if should_treat_as_setting(state.events) else "action",
                text=normalise_whitespace(stripped),
            )
        )
        state.advance()
        return

    state.events.append(MetaEvent(type="meta", subtype="note", text=stripped))
    state.front_matter_count += 1
    state.advance()


def parse_play_file(path: str | Path, *, profile: FormatProfile | None = None) -> list[PlayEvent]:
    return parse_play_text(read_text_file(Path(path)), profile=profile)
