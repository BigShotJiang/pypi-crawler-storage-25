from __future__ import annotations

import re

from play_parser.document.types import SceneStartEvent

ROMAN_RE = re.compile(r"^[IVXLCDM]+$", re.IGNORECASE)
ACT_RE = re.compile(
    r"^\s*(?:ACT\s+([IVXLCDM]+|\d+|FIRST|SECOND|THIRD|FOURTH|FIFTH|SIXTH)|"
    r"(FIRST|SECOND|THIRD|FOURTH|FIFTH|SIXTH)\s+ACT)\s*$",
    re.IGNORECASE,
)
SCENE_RE = re.compile(
    r"^\s*SCENE(?:\s+([IVXLCDM]+|\d+|FIRST|SECOND|THIRD|FOURTH|FIFTH|SIXTH))?"
    r"(?:(?:\s*[\.\-:])\s*(.*))?\s*$",
    re.IGNORECASE,
)
ORDINALS = {
    "first": 1,
    "second": 2,
    "third": 3,
    "fourth": 4,
    "fifth": 5,
    "sixth": 6,
}
ROMAN_VALUES = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000,
}


def parse_act_number(line: str) -> int | None:
    match = ACT_RE.match(line)
    if not match:
        return None
    token = match.group(1) or match.group(2)
    return parse_number_token(token)


def parse_scene_start(line: str) -> SceneStartEvent | None:
    match = SCENE_RE.match(line)
    if not match:
        return None

    number = parse_number_token(match.group(1))
    return SceneStartEvent(
        type="scene_start",
        scene_number=number,
        label=line.strip(),
    )


def parse_number_token(token: str | None) -> int | None:
    if token is None:
        return None
    cleaned = token.strip().strip(".:;")
    if not cleaned:
        return None
    if cleaned.isdigit():
        return int(cleaned)

    lowered = cleaned.casefold()
    if lowered in ORDINALS:
        return ORDINALS[lowered]

    if not ROMAN_RE.fullmatch(cleaned):
        return None

    total = 0
    prev = 0
    for char in reversed(cleaned.upper()):
        value = ROMAN_VALUES[char]
        if value < prev:
            total -= value
        else:
            total += value
            prev = value
    return total or None


def is_structural_line(line: str) -> bool:
    return parse_act_number(line) is not None or parse_scene_start(line) is not None
