from __future__ import annotations

import json
from pathlib import Path
from typing import Any

DEFAULT_MAX_INPUT_BYTES = 10 * 1024 * 1024


def check_file_size(path: str | Path, *, max_bytes: int = DEFAULT_MAX_INPUT_BYTES) -> Path:
    input_path = Path(path)
    try:
        size = input_path.stat().st_size
    except FileNotFoundError as exc:
        raise ValueError(f"File not found: {input_path}") from exc
    except PermissionError as exc:
        raise ValueError(f"Permission denied reading file: {input_path}") from exc

    if size > max_bytes:
        raise ValueError(
            f"Input file is too large: {input_path} is {size} bytes; maximum supported size is {max_bytes} bytes"
        )
    return input_path


def read_text_file(path: str | Path, *, max_bytes: int = DEFAULT_MAX_INPUT_BYTES) -> str:
    input_path = check_file_size(path, max_bytes=max_bytes)
    try:
        return input_path.read_text(encoding="utf-8")
    except PermissionError as exc:
        raise ValueError(f"Permission denied reading file: {input_path}") from exc
    except UnicodeDecodeError as exc:
        raise ValueError(f"File is not valid UTF-8 text: {input_path}") from exc


def read_json_file(path: str | Path, *, max_bytes: int = DEFAULT_MAX_INPUT_BYTES) -> Any:
    input_path = Path(path)
    text = read_text_file(input_path, max_bytes=max_bytes)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON in file {input_path}: {exc.msg} at line {exc.lineno}, column {exc.colno}"
        ) from exc


def parse_json_text(text: str, *, label: str = "JSON text") -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid {label}: {exc.msg} at line {exc.lineno}, column {exc.colno}") from exc
