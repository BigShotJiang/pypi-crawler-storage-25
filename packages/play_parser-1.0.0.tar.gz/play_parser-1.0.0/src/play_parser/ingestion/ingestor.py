from __future__ import annotations

import json
from abc import ABC, abstractmethod
from collections.abc import Mapping
from functools import cached_property
from pathlib import Path

from play_parser._io import read_json_file
from play_parser.document.builder import build_play_document, build_play_document_from_file
from play_parser.document.types import PlayDocument
from play_parser.document.validation import validate_play_document
from play_parser.parsing.profiles import (
    FormatProfile,
    get_format_profile,
    load_format_profile_config,
    load_format_profile_file,
)

DEFAULT_JSON_INDENT = 2
ProfileInput = str | Mapping[str, object] | FormatProfile | None


def resolve_format_profile(
    profile: ProfileInput = None,
    profile_path: str | Path | None = None,
) -> FormatProfile | None:
    if profile is not None and profile_path is not None:
        raise ValueError("profile and profile_path are mutually exclusive")
    if profile_path is not None:
        return load_format_profile_file(profile_path)
    if profile is None:
        return None
    if isinstance(profile, str):
        return get_format_profile(profile)
    if isinstance(profile, FormatProfile):
        return profile
    if isinstance(profile, Mapping):
        return load_format_profile_config(profile)
    raise ValueError(
        "profile must be a built-in profile name, a profile config mapping, "
        f"a FormatProfile, or None; got {type(profile).__name__}"
    )


class _BasePlayIngestor(ABC):
    def __init__(self, src: str | Path):
        self.src = Path(src)

    @cached_property
    def data(self) -> PlayDocument:
        return self._build_data()

    @abstractmethod
    def _build_data(self) -> PlayDocument:
        raise NotImplementedError

    def write(self, dst: str | Path, *, indent: int = DEFAULT_JSON_INDENT) -> None:
        output_path = Path(dst)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=indent) + "\n",
            encoding="utf-8",
        )

    @property
    def profile(self) -> FormatProfile | None:
        return None


class TextPlayIngestor(_BasePlayIngestor):
    def __init__(self, src: str | Path, *, profile: FormatProfile | None = None):
        super().__init__(src)
        self._profile = profile

    @property
    def profile(self) -> FormatProfile | None:
        return self._profile

    def _build_data(self) -> PlayDocument:
        return build_play_document_from_file(self.src, profile=self.profile)


class TextStringPlayIngestor(_BasePlayIngestor):
    def __init__(
        self,
        text: str,
        *,
        source_name: str | None = None,
        profile: FormatProfile | None = None,
    ):
        super().__init__(source_name or "<text>")
        self.text = text
        self._source_name = source_name
        self._profile = profile

    @property
    def profile(self) -> FormatProfile | None:
        return self._profile

    def _build_data(self) -> PlayDocument:
        play_name = Path(self._source_name).stem if self._source_name else None
        return build_play_document(self.text, play_name=play_name, profile=self.profile)


class JsonPlayIngestor(_BasePlayIngestor):
    def _build_data(self) -> PlayDocument:
        payload = read_json_file(self.src)
        return validate_play_document(payload)


class PlayIngestor:
    """Public ingestion entry point for supported play source files.

    Supported source types in this pass:
    - `.txt` raw play text
    - `.json` canonical play documents
    """

    @classmethod
    def from_text(
        cls,
        text: str,
        *,
        source_name: str | None = None,
        profile: ProfileInput = None,
        profile_path: str | Path | None = None,
    ) -> PlayIngestor:
        """Create an ingestor from raw play text already loaded in memory.

        This is useful for API and serverless flows where text has already
        been extracted from an upload, PDF, object store, or request body and
        writing a temporary `.txt` file would add unnecessary I/O.
        """
        resolved_profile = resolve_format_profile(profile=profile, profile_path=profile_path)
        ingestor = cls.__new__(cls)
        ingestor._impl = TextStringPlayIngestor(
            text,
            source_name=source_name,
            profile=resolved_profile,
        )
        return ingestor

    def __init__(
        self,
        src: str | Path,
        *,
        profile: ProfileInput = None,
        profile_path: str | Path | None = None,
    ):
        path = Path(src)
        suffix = path.suffix.lower()
        if suffix == ".txt":
            resolved_profile = resolve_format_profile(profile=profile, profile_path=profile_path)
            self._impl: _BasePlayIngestor = TextPlayIngestor(path, profile=resolved_profile)
        elif suffix == ".json":
            if profile is not None or profile_path is not None:
                raise ValueError("Format profiles apply only to raw '.txt' play text ingestion")
            self._impl = JsonPlayIngestor(path)
        else:
            raise ValueError(
                "Unsupported play source type "
                f"{path.suffix or '<no extension>'!r}. "
                "PlayIngestor currently supports only raw '.txt' play text files "
                "and canonical '.json' play documents."
            )

    @property
    def src(self) -> Path:
        return self._impl.src

    @property
    def data(self) -> PlayDocument:
        return self._impl.data

    @property
    def profile(self) -> FormatProfile | None:
        return self._impl.profile

    def write(self, dst: str | Path, *, indent: int = DEFAULT_JSON_INDENT) -> None:
        self._impl.write(dst, indent=indent)
