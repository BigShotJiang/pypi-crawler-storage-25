from __future__ import annotations

import argparse
import json
from pathlib import Path

from play_parser import __version__
from play_parser.document.assembler import assemble_play_text
from play_parser.ingestion import PlayIngestor

DEFAULT_JSON_INDENT = 2


def build_cli_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Parse raw play text to JSON/canonical text, or assemble canonical text from JSON."
    )
    parser.add_argument("--version", action="version", version=f"play-parser {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)
    add_parse_command(subparsers)
    add_assemble_command(subparsers)
    return parser


def add_parse_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    parse_parser = subparsers.add_parser("parse", help="Parse raw .txt files into JSON and/or canonical text.")
    parse_parser.add_argument(
        "inputs",
        nargs="*",
        type=Path,
        help="Input .txt files or folders. If omitted, all .txt files under --input-root are processed.",
    )
    parse_parser.add_argument(
        "--input-root",
        type=Path,
        default=Path.cwd(),
        help=(
            "Default folder to read raw .txt files from when no explicit inputs are given. "
            "Defaults to the current working directory."
        ),
    )
    parse_parser.add_argument("--recursive", action="store_true", help="Traverse input directories recursively.")
    parse_parser.add_argument("--json-output", type=Path, help="Write JSON for exactly one input file.")
    parse_parser.add_argument("--json-output-root", type=Path, help="Write one .json file per input into this folder.")
    parse_parser.add_argument(
        "--text-output",
        type=Path,
        help="Write canonical assembled .txt for exactly one input file.",
    )
    parse_parser.add_argument(
        "--text-output-root",
        type=Path,
        help="Write one canonical .txt file per input into this folder.",
    )
    parse_parser.add_argument("--profile", help="Built-in format profile name to use while parsing raw text.")
    parse_parser.add_argument("--profile-path", type=Path, help="Path to a custom format profile JSON file.")
    parse_parser.add_argument("--indent", type=int, default=DEFAULT_JSON_INDENT, help="JSON indentation level.")


def add_assemble_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    assemble_parser = subparsers.add_parser("assemble", help="Assemble canonical .txt from JSON files.")
    assemble_parser.add_argument(
        "inputs",
        nargs="*",
        type=Path,
        help="Input .json files or folders. If omitted, all .json files under --input-root are processed.",
    )
    assemble_parser.add_argument(
        "--input-root",
        type=Path,
        default=Path.cwd(),
        help=(
            "Default folder to read .json files from when no explicit inputs are given. "
            "Defaults to the current working directory."
        ),
    )
    assemble_parser.add_argument("--recursive", action="store_true", help="Traverse input directories recursively.")
    assemble_parser.add_argument("--output", type=Path, help="Write canonical text for exactly one input file.")
    assemble_parser.add_argument(
        "--output-root",
        type=Path,
        help="Write one canonical .txt file per input into this folder.",
    )


def resolve_input_files(
    input_paths: list[Path],
    input_root: Path,
    suffix: str,
    *,
    recursive: bool = False,
) -> list[Path]:
    resolved: list[Path] = []

    candidates = input_paths or [input_root]
    for candidate in candidates:
        path = resolve_candidate_path(candidate, input_root)
        if not path.exists():
            raise SystemExit(f"Input path not found: {path}")

        if path.is_dir():
            walker = path.rglob if recursive else path.glob
            resolved.extend(sorted(item.resolve() for item in walker(f"*{suffix}") if item.is_file()))
            continue

        if path.suffix.lower() != suffix:
            raise SystemExit(f"Expected {suffix} input, got: {path}")
        resolved.append(path.resolve())

    unique: list[Path] = []
    seen: set[Path] = set()
    for path in resolved:
        if path not in seen:
            unique.append(path)
            seen.add(path)
    return unique


def resolve_candidate_path(candidate: Path, input_root: Path) -> Path:
    if candidate.is_absolute():
        return candidate
    if candidate.exists():
        return candidate.resolve()
    return (input_root / candidate).resolve()


def ensure_single_input_output(
    single_output: Path | None,
    output_root: Path | None,
    input_files: list[Path],
    flag: str,
) -> None:
    if single_output is not None and len(input_files) != 1:
        raise SystemExit(f"{flag} can only be used when processing exactly one input file")
    if single_output is not None and output_root is not None:
        raise SystemExit(f"Cannot use {flag} together with its corresponding --*-root option")


def json_output_path_for(input_path: Path, args: argparse.Namespace) -> Path | None:
    if args.json_output is not None:
        return args.json_output.resolve()
    if args.json_output_root is not None:
        return args.json_output_root.resolve() / f"{input_path.stem}.json"
    return None


def text_output_path_for(input_path: Path, args: argparse.Namespace, *, from_json: bool) -> Path | None:
    if from_json:
        if args.output is not None:
            return args.output.resolve()
        if args.output_root is not None:
            return args.output_root.resolve() / f"{input_path.stem}.txt"
        return None

    if args.text_output is not None:
        return args.text_output.resolve()
    if args.text_output_root is not None:
        return args.text_output_root.resolve() / f"{input_path.stem}.txt"
    return None


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_json(path: Path, payload: object, *, indent: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=indent) + "\n", encoding="utf-8")


def run_parse(args: argparse.Namespace) -> int:
    input_root = args.input_root.resolve()
    input_files = resolve_input_files(args.inputs, input_root, ".txt", recursive=args.recursive)
    if not input_files:
        raise SystemExit(f"No .txt files found under {input_root}")
    if args.profile is not None and args.profile_path is not None:
        raise SystemExit("Cannot use --profile together with --profile-path")

    ensure_single_input_output(args.json_output, args.json_output_root, input_files, "--json-output")
    ensure_single_input_output(args.text_output, args.text_output_root, input_files, "--text-output")

    for input_path in input_files:
        document = PlayIngestor(input_path, profile=args.profile, profile_path=args.profile_path).data
        json_output = json_output_path_for(input_path, args)
        text_output = text_output_path_for(input_path, args, from_json=False)

        if json_output is not None:
            write_json(json_output, document, indent=args.indent)
        if text_output is not None:
            write_text(text_output, assemble_play_text(document))

        report_outputs("Parsed", input_path, json_output=json_output, text_output=text_output)

    return 0


def run_assemble(args: argparse.Namespace) -> int:
    input_root = args.input_root.resolve()
    input_files = resolve_input_files(args.inputs, input_root, ".json", recursive=args.recursive)
    if not input_files:
        raise SystemExit(f"No .json files found under {input_root}")

    ensure_single_input_output(args.output, args.output_root, input_files, "--output")

    for input_path in input_files:
        text_output = text_output_path_for(input_path, args, from_json=True)
        assembled = assemble_play_text(input_path)
        if text_output is not None:
            write_text(text_output, assembled)
        report_outputs("Assembled", input_path, text_output=text_output)

    return 0


def report_outputs(
    action: str,
    input_path: Path,
    *,
    json_output: Path | None = None,
    text_output: Path | None = None,
) -> None:
    outputs: list[str] = []
    if json_output is not None:
        outputs.append(f"json={json_output}")
    if text_output is not None:
        outputs.append(f"text={text_output}")
    if outputs:
        print(f"{action} {input_path} -> " + ", ".join(outputs))
    else:
        print(f"{action} {input_path} (no files written)")


def main() -> int:
    args = build_cli_parser().parse_args()
    if args.command == "parse":
        return run_parse(args)
    if args.command == "assemble":
        return run_assemble(args)
    raise SystemExit(f"Unsupported command: {args.command}")
