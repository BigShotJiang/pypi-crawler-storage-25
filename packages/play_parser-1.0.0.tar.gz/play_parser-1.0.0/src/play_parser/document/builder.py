from __future__ import annotations

import json
import re
from collections.abc import Sequence
from pathlib import Path

from play_parser._io import read_text_file
from play_parser.document.text import count_words
from play_parser.parsing.parser import parse_play_text
from play_parser.parsing.profiles import FormatProfile

from .types import PlayDocument, PlayEvent
from .validation import validate_events

WHITESPACE_RE = re.compile(r"\s+")
DEFAULT_JSON_INDENT = 2
AUTHOR_BYLINE_PREFIX = "by "


def build_play_events(
    text: str,
    *,
    profile: FormatProfile | None = None,
) -> list[PlayEvent]:
    events = parse_play_text(text, profile=profile)
    validate_events(events)
    return events


def build_play_document(
    text: str,
    *,
    play_name: str | None = None,
    profile: FormatProfile | None = None,
) -> PlayDocument:
    events = build_play_events(text, profile=profile)
    return {
        "metadata": build_play_metadata(events, text, play_name=play_name),
        "events": events,
    }


def build_play_events_from_file(path: str | Path, *, profile: FormatProfile | None = None) -> list[PlayEvent]:
    input_path = Path(path)
    return build_play_events(
        read_text_file(input_path),
        profile=profile,
    )


def build_play_document_from_file(path: str | Path, *, profile: FormatProfile | None = None) -> PlayDocument:
    input_path = Path(path)
    return build_play_document(
        read_text_file(input_path),
        play_name=input_path.stem,
        profile=profile,
    )


def write_json_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    indent: int = DEFAULT_JSON_INDENT,
    profile: FormatProfile | None = None,
) -> PlayDocument:
    document = build_play_document_from_file(input_path, profile=profile)
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(document, ensure_ascii=False, indent=indent) + "\n", encoding="utf-8")
    return document


def build_play_metadata(
    events: Sequence[PlayEvent],
    raw_text: str,
    *,
    play_name: str | None = None,
) -> dict[str, object]:
    title = extract_title(events, play_name=play_name)
    author = extract_author(events)
    acts, scenes = collect_structure(events)

    return {
        "title": title,
        "author": author,
        "characters": collect_characters(events),
        "acts": acts,
        "scenes": scenes,
        "stats": {
            "stage_directions": sum(1 for event in events if event["type"] == "stage_direction"),
            "speeches": sum(1 for event in events if event["type"] == "speech"),
            "scenes": len(scenes),
            "acts": len(acts),
            "source_words": count_words(raw_text),
            "spoken_words": sum(count_words(event["text"]) for event in events if event["type"] == "speech"),
        },
    }


def extract_title(events: Sequence[PlayEvent], *, play_name: str | None) -> str | None:
    for event in events:
        if event["type"] == "meta" and event["subtype"] == "title":
            return event["text"]
    return play_name


def extract_author(events: Sequence[PlayEvent]) -> str | None:
    for event in events:
        if event["type"] == "meta" and event["subtype"] == "author":
            author = event["text"].strip()
            if author.lower().startswith(AUTHOR_BYLINE_PREFIX):
                return author[len(AUTHOR_BYLINE_PREFIX) :].strip() or None
            return author or None
    return None


def collect_characters(events: Sequence[PlayEvent]) -> list[str]:
    characters: list[str] = []
    seen: set[str] = set()

    for event in events:
        if event["type"] == "stage_direction" and event.get("subtype") == "character":
            add_character(characters, seen, event["text"])
        elif event["type"] == "speech":
            add_character(characters, seen, event["speaker"])

    return characters


def add_character(characters: list[str], seen: set[str], value: str) -> None:
    name = value.strip()
    if not name:
        return
    marker = normalize_inline_match_text(name)
    if marker in seen:
        return
    seen.add(marker)
    characters.append(name)


def collect_structure(events: Sequence[PlayEvent]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    acts: list[dict[str, object]] = []
    scenes: list[dict[str, object]] = []
    current_act_number: int | None = None

    for event in events:
        if event["type"] == "act_start":
            current_act_number = event["act_number"]
            acts.append(
                {
                    "act_number": event["act_number"],
                    "label": event["label"],
                }
            )
        elif event["type"] == "scene_start":
            scenes.append(
                {
                    "act_number": current_act_number,
                    "scene_number": event.get("scene_number"),
                    "label": event["label"],
                }
            )

    return acts, scenes


def normalize_inline_match_text(text: str) -> str:
    return WHITESPACE_RE.sub(" ", text).strip().casefold()
