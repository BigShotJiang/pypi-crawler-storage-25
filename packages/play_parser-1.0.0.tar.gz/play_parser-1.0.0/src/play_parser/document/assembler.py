from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

from play_parser._io import parse_json_text, read_json_file

from .types import PlayDocument, PlayEvent, SpeechEvent


def assemble_play_text(events_or_json: Sequence[PlayEvent] | PlayDocument | str | Path) -> str:
    events = _coerce_events(events_or_json)
    return PlayTextAssembler().assemble(events)


class PlayTextAssembler:
    """Formats canonical play events back into plain text."""

    def __init__(self) -> None:
        self.pending_attached_stage_directions: list[str] = []
        self.last_speech_speaker: str | None = None
        self.last_speech_index = -1
        self.scene_boundary_indices: set[int] = set()

    def assemble(self, events: Sequence[PlayEvent]) -> str:
        blocks: list[str] = []
        self.scene_boundary_indices = {
            index for index, event in enumerate(events) if event["type"] in {"act_start", "scene_start"}
        }

        for index, event in enumerate(events):
            if event["type"] == "stage_direction" and event.get("attachment") == "next":
                self.pending_attached_stage_directions.append(event["text"])
                continue

            block = self.format_event(event, events=events, index=index)
            if block:
                blocks.append(block)

        if self.pending_attached_stage_directions:
            blocks.extend(self.pending_attached_stage_directions)
            self.pending_attached_stage_directions = []

        return "\n\n".join(block for block in blocks if block) + "\n"

    def format_event(self, event: PlayEvent, *, events: Sequence[PlayEvent], index: int) -> str:
        if event["type"] == "speech":
            return self.format_speech(event, events=events, index=index)

        block = self.format_non_speech(event)
        self.pending_attached_stage_directions = []
        if event["type"] in {"act_start", "scene_start"}:
            self.last_speech_speaker = None
            self.last_speech_index = -1
        return block

    def format_speech(self, event: SpeechEvent, *, events: Sequence[PlayEvent], index: int) -> str:
        suppress_speaker, bare_speaker_label = self.speaker_label_options(event, events=events, index=index)
        block = _event_to_block(
            event,
            suppress_speaker=suppress_speaker,
            bare_speaker_label=bare_speaker_label,
            attached_stage_directions=self.pending_attached_stage_directions,
        )
        self.pending_attached_stage_directions = []
        self.last_speech_speaker = event["speaker"]
        self.last_speech_index = index
        return block

    def speaker_label_options(
        self,
        event: SpeechEvent,
        *,
        events: Sequence[PlayEvent],
        index: int,
    ) -> tuple[bool, bool]:
        explicit_labelled = event.get("labelled")
        if explicit_labelled is False:
            should_suppress = self.last_speech_speaker == event["speaker"]
            return should_suppress, not should_suppress

        if explicit_labelled is None and self.can_suppress_repeated_speaker(event, events=events, index=index):
            return True, False

        return False, False

    def can_suppress_repeated_speaker(
        self,
        event: SpeechEvent,
        *,
        events: Sequence[PlayEvent],
        index: int,
    ) -> bool:
        if self.last_speech_speaker != event["speaker"]:
            return False
        if index <= 0 or index - 1 in self.scene_boundary_indices or self.last_speech_index < 0:
            return False
        return all(
            other_event["type"] == "stage_direction" for other_event in events[self.last_speech_index + 1 : index]
        )

    def format_non_speech(self, event: PlayEvent) -> str:
        return _event_to_block(
            event,
            attached_stage_directions=self.pending_attached_stage_directions,
        )


def _coerce_events(events_or_json: Sequence[PlayEvent] | PlayDocument | str | Path) -> list[PlayEvent]:
    if isinstance(events_or_json, Path):
        return _extract_events(read_json_file(events_or_json))

    if isinstance(events_or_json, str):
        return _extract_events(parse_json_text(events_or_json))

    return _extract_events(events_or_json)


def _extract_events(payload: Sequence[PlayEvent] | PlayDocument | Any) -> list[PlayEvent]:
    if isinstance(payload, dict) and "events" in payload:
        return list(payload["events"])
    return list(payload)


def _event_to_block(
    event: PlayEvent,
    suppress_speaker: bool = False,
    bare_speaker_label: bool = False,
    attached_stage_directions: list[str] | None = None,
) -> str:
    attached_stage_directions = attached_stage_directions or []
    event_type = event["type"]

    if event_type == "speech":
        lines = event["text"].splitlines() if event["text"] else [""]
        first_line = lines[0] if lines else ""
        remainder = lines[1:]

        prefix = "".join(attached_stage_directions)

        if bare_speaker_label:
            speech_lines = lines if event["text"] else []
            speaker_label = event["speaker"].upper()
            if prefix:
                return "\n".join([speaker_label, prefix, *speech_lines])
            return "\n".join([speaker_label, *speech_lines])

        if suppress_speaker:
            head = f"{prefix} {first_line}".strip() if prefix else first_line
        else:
            if prefix:
                head = f"{event['speaker']}: {prefix} {first_line}".rstrip()
            else:
                head = f"{event['speaker']}: {first_line}".rstrip()

        if not remainder:
            return head
        return "\n".join([head, *remainder])

    if event_type == "scene_start":
        base = event["label"]
        if attached_stage_directions:
            return "\n".join([*attached_stage_directions, base])
        return base

    if event_type == "act_start":
        base = event["label"]
        if attached_stage_directions:
            return "\n".join([*attached_stage_directions, base])
        return base

    if event_type == "stage_direction":
        base = event["text"]
        if attached_stage_directions:
            return "\n".join([*attached_stage_directions, base])
        return base

    if event_type == "meta":
        base = event["text"]
        if attached_stage_directions:
            return "\n".join([*attached_stage_directions, base])
        return base

    return ""
