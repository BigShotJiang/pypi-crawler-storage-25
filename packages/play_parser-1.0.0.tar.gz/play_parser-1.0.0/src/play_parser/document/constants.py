from __future__ import annotations

import re

WORD_RE = re.compile(r"[0-9A-Za-zÀ-ÖØ-öø-ÿ]+(?:['’][0-9A-Za-zÀ-ÖØ-öø-ÿ]+)*")

STAGE_DIRECTION_SUBTYPES = (
    "enter",
    "exit",
    "action",
    "aside",
    "setting",
    "sound",
    "cast_list_heading",
    "character",
)
VALID_STAGE_DIRECTION_SUBTYPES = frozenset(STAGE_DIRECTION_SUBTYPES)
