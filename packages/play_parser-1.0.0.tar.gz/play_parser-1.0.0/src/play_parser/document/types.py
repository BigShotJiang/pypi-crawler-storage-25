from __future__ import annotations

from typing import Literal, TypedDict


class ActStartEvent(TypedDict):
    type: Literal["act_start"]
    act_number: int
    label: str


class SceneStartEvent(TypedDict):
    type: Literal["scene_start"]
    scene_number: int | None
    label: str


class SpeechEventRequired(TypedDict):
    type: Literal["speech"]
    speaker: str
    text: str
    line_count: int
    word_count: int


class SpeechEvent(SpeechEventRequired, total=False):
    labelled: bool


StageDirectionSubtype = Literal[
    "enter",
    "exit",
    "action",
    "aside",
    "setting",
    "sound",
    "cast_list_heading",
    "character",
]


class StageDirectionEventRequired(TypedDict):
    type: Literal["stage_direction"]
    subtype: StageDirectionSubtype
    text: str


class StageDirectionEvent(StageDirectionEventRequired, total=False):
    attachment: Literal["next"]


class MetaEvent(TypedDict):
    type: Literal["meta"]
    subtype: str
    text: str


class ActSummary(TypedDict):
    act_number: int
    label: str


class SceneSummary(TypedDict):
    act_number: int | None
    scene_number: int | None
    label: str


class PlayStats(TypedDict):
    stage_directions: int
    speeches: int
    scenes: int
    acts: int
    source_words: int
    spoken_words: int


class PlayMetadata(TypedDict):
    title: str | None
    author: str | None
    characters: list[str]
    acts: list[ActSummary]
    scenes: list[SceneSummary]
    stats: PlayStats


class PlayDocument(TypedDict):
    metadata: PlayMetadata
    events: list[PlayEvent]


PlayEvent = ActStartEvent | SceneStartEvent | SpeechEvent | StageDirectionEvent | MetaEvent
