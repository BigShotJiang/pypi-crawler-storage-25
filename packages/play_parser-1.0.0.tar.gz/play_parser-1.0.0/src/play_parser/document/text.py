"""Shared text helpers for parser and document validation."""

from __future__ import annotations

from .constants import WORD_RE


def count_words(text: str) -> int:
    """Count words using the canonical parser word-token rule."""
    return len(WORD_RE.findall(text))


def normalise_whitespace(text: str) -> str:
    """Collapse all runs of whitespace in ``text`` to single spaces."""
    return " ".join(text.split())
