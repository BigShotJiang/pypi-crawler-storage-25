from __future__ import annotations

import copy
import json
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TypeVar

from play_parser.document.assembler import assemble_play_text
from play_parser.document.types import PlayDocument, PlayEvent, PlayMetadata
from play_parser.document.validation import validate_play_document

DEFAULT_JSON_INDENT = 2
DEFAULT_MIN_MONOLOGUE_LINES = 1
DEFAULT_MIN_DIALOGUE_TURNS = 2

T = TypeVar("T", "Act", "Scene")


@dataclass(frozen=True, slots=True)
class SpeechSegment:
    speeches: tuple[Speech, ...]
    event_indices: tuple[int, ...]
    participant_names: tuple[str, ...]


@dataclass(slots=True, init=False)
class Play:
    """Primary domain wrapper over a canonical ``PlayDocument``.

    ``Play`` wraps canonical ``metadata`` and ``events`` and exposes
    read-only derived domain views such as acts, scenes, characters,
    speeches, monologues, and dialogues.

    Source ingestion and canonicalisation are handled by ``PlayIngestor``.
    """

    _metadata: PlayMetadata = field(init=False, repr=False, compare=False)
    _events: tuple[PlayEvent, ...] = field(init=False, repr=False, compare=False)
    _acts_cache: list[Act] | None = field(init=False, default=None, repr=False, compare=False)
    _scenes_cache: list[Scene] | None = field(init=False, default=None, repr=False, compare=False)
    _characters_cache: list[Character] | None = field(init=False, default=None, repr=False, compare=False)
    _character_map_cache: dict[str, Character] | None = field(
        init=False,
        default=None,
        repr=False,
        compare=False,
    )
    _speeches_cache: list[Speech] | None = field(init=False, default=None, repr=False, compare=False)
    _speech_map_cache: dict[int, Speech] | None = field(init=False, default=None, repr=False, compare=False)
    _event_to_act_cache: dict[int, Act | None] | None = field(init=False, default=None, repr=False, compare=False)
    _event_to_scene_cache: dict[int, Scene | None] | None = field(init=False, default=None, repr=False, compare=False)
    _monologues_cache: list[Monologue] | None = field(init=False, default=None, repr=False, compare=False)
    _dialogues_cache: list[Dialogue] | None = field(init=False, default=None, repr=False, compare=False)

    def __init__(self, document: PlayDocument):
        validated_document = validate_play_document(document)
        self._metadata = copy.deepcopy(validated_document["metadata"])
        self._events = tuple(copy.deepcopy(validated_document["events"]))
        self._acts_cache = None
        self._scenes_cache = None
        self._characters_cache = None
        self._character_map_cache = None
        self._speeches_cache = None
        self._speech_map_cache = None
        self._event_to_act_cache = None
        self._event_to_scene_cache = None
        self._monologues_cache = None
        self._dialogues_cache = None

    @property
    def metadata(self) -> PlayMetadata:
        """Return a defensive copy of the canonical metadata."""
        return copy.deepcopy(self._metadata)

    @property
    def events(self) -> tuple[PlayEvent, ...]:
        """Return a defensive copy of the canonical event sequence."""
        return tuple(copy.deepcopy(self._events))

    @property
    def title(self) -> str | None:
        return self._metadata.get("title")

    @property
    def author(self) -> str | None:
        return self._metadata.get("author")

    @property
    def acts(self) -> list[Act]:
        if self._acts_cache is None:
            self._acts_cache = self._build_acts()
        return list(self._acts_cache)

    @property
    def scenes(self) -> list[Scene]:
        if self._scenes_cache is None:
            self._scenes_cache = self._build_scenes()
        return list(self._scenes_cache)

    @property
    def characters(self) -> list[Character]:
        if self._characters_cache is None:
            names = list(self._metadata.get("characters", []))
            self._characters_cache = [Character(play=self, name=name) for name in names]
            self._character_map_cache = {character.name: character for character in self._characters_cache}
        return list(self._characters_cache)

    @property
    def speeches(self) -> list[Speech]:
        if self._speeches_cache is None:
            self._speeches_cache = [
                Speech(play=self, event_index=index)
                for index, event in enumerate(self._events)
                if event["type"] == "speech"
            ]
            self._speech_map_cache = {speech.event_index: speech for speech in self._speeches_cache}
        return list(self._speeches_cache)

    def monologues(
        self,
        *,
        min_lines: int = DEFAULT_MIN_MONOLOGUE_LINES,
        min_words: int | None = None,
        min_speeches: int | None = None,
    ) -> list[Monologue]:
        if self._monologues_cache is None:
            self._monologues_cache = self._build_monologues()
        monologues = self._monologues_cache
        return [
            monologue
            for monologue in monologues
            if monologue.line_count >= min_lines
            and (min_words is None or monologue.word_count >= min_words)
            and (min_speeches is None or len(monologue.speeches) >= min_speeches)
        ]

    def dialogues(
        self,
        *,
        min_turns: int = DEFAULT_MIN_DIALOGUE_TURNS,
        min_lines: int | None = None,
        min_words: int | None = None,
    ) -> list[Dialogue]:
        if self._dialogues_cache is None:
            self._dialogues_cache = self._build_dialogues()
        dialogues = self._dialogues_cache
        return [
            dialogue
            for dialogue in dialogues
            if dialogue.turn_count >= min_turns
            and (min_lines is None or dialogue.line_count >= min_lines)
            and (min_words is None or dialogue.word_count >= min_words)
        ]

    def character(self, name: str) -> Character | None:
        if self._character_map_cache is None:
            _ = self.characters
        return self._character_map_cache.get(name) if self._character_map_cache is not None else None

    def assemble(self) -> str:
        return assemble_play_text(self.as_dict())

    def to_json(self, *, indent: int = DEFAULT_JSON_INDENT) -> str:
        return json.dumps(self.as_dict(), ensure_ascii=False, indent=indent) + "\n"

    def save_json(self, path: str | Path, *, indent: int = DEFAULT_JSON_INDENT) -> None:
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(self.to_json(indent=indent), encoding="utf-8")

    def save_text(self, path: str | Path) -> None:
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(self.assemble(), encoding="utf-8")

    def as_dict(self) -> PlayDocument:
        return {
            "metadata": copy.deepcopy(self._metadata),
            "events": list(copy.deepcopy(self._events)),
        }

    def _build_acts(self) -> list[Act]:
        act_indices = [index for index, event in enumerate(self._events) if event["type"] == "act_start"]
        acts: list[Act] = []
        for offset, start_index in enumerate(act_indices):
            event = self._events[start_index]
            end_index = act_indices[offset + 1] if offset + 1 < len(act_indices) else len(self._events)
            acts.append(
                Act(
                    play=self,
                    number=event["act_number"],
                    label=event["label"],
                    events=self._events[start_index:end_index],
                    _start_index=start_index,
                    _end_index=end_index,
                )
            )
        return acts

    def _build_scenes(self) -> list[Scene]:
        scenes: list[Scene] = []
        current_act_number: int | None = None
        scene_starts: list[tuple[int, int | None]] = []
        structural_boundaries: list[int] = []

        for index, event in enumerate(self._events):
            if event["type"] == "act_start":
                current_act_number = event["act_number"]
                structural_boundaries.append(index)
            elif event["type"] == "scene_start":
                structural_boundaries.append(index)
                scene_starts.append((index, current_act_number))

        next_boundary_by_start = {
            start: structural_boundaries[offset + 1] if offset + 1 < len(structural_boundaries) else len(self._events)
            for offset, start in enumerate(structural_boundaries)
        }

        for start_index, act_number in scene_starts:
            event = self._events[start_index]
            end_index = next_boundary_by_start[start_index]
            scenes.append(
                Scene(
                    play=self,
                    act_number=act_number,
                    scene_number=event.get("scene_number"),
                    label=event["label"],
                    events=self._events[start_index:end_index],
                    _start_index=start_index,
                    _end_index=end_index,
                )
            )

        return scenes

    def _act_for_event_index(self, event_index: int) -> Act | None:
        if self._event_to_act_cache is None:
            self._event_to_act_cache = self._build_event_to_act_cache()
        return self._event_to_act_cache.get(event_index)

    def _scene_for_event_index(self, event_index: int) -> Scene | None:
        if self._event_to_scene_cache is None:
            self._event_to_scene_cache = self._build_event_to_scene_cache()
        return self._event_to_scene_cache.get(event_index)

    def _build_event_to_act_cache(self) -> dict[int, Act | None]:
        return self._build_event_interval_cache((act._start_index, act._end_index, act) for act in self.acts)

    def _build_event_to_scene_cache(self) -> dict[int, Scene | None]:
        return self._build_event_interval_cache((scene._start_index, scene._end_index, scene) for scene in self.scenes)

    def _build_event_interval_cache(self, intervals: Iterable[tuple[int, int, T]]) -> dict[int, T | None]:
        cache: dict[int, T | None] = {index: None for index in range(len(self._events))}
        for start_index, end_index, value in intervals:
            for index in range(start_index, end_index):
                cache[index] = value
        return cache

    def _speech_for_event_index(self, event_index: int) -> Speech | None:
        if self._speech_map_cache is None:
            _ = self.speeches
        return self._speech_map_cache.get(event_index) if self._speech_map_cache is not None else None

    def _iter_speech_segments(self, *, max_participants: int) -> list[SpeechSegment]:
        """Return contiguous speech segments for monologue/dialogue views.

        Structural events and metadata flush the current segment. Stage directions
        between speeches are buffered and included only if another speech follows.
        When a speech introduces a new participant beyond ``max_participants``,
        the current segment is flushed and a new segment starts with that speech.
        """
        segments: list[SpeechSegment] = []
        current_speeches: list[Speech] = []
        current_event_indices: list[int] = []
        buffered_stage_indices: list[int] = []
        participant_names: list[str] = []

        def flush() -> None:
            nonlocal current_speeches, current_event_indices, buffered_stage_indices, participant_names
            if current_speeches:
                segments.append(
                    SpeechSegment(
                        speeches=tuple(current_speeches),
                        event_indices=tuple(current_event_indices),
                        participant_names=tuple(participant_names),
                    )
                )
            current_speeches = []
            current_event_indices = []
            buffered_stage_indices = []
            participant_names = []

        for index, event in enumerate(self._events):
            event_type = event["type"]
            if event_type in {"act_start", "scene_start", "meta"}:
                flush()
                continue
            if event_type == "stage_direction":
                if current_speeches:
                    buffered_stage_indices.append(index)
                continue
            if event_type != "speech":
                continue

            speech = self._speech_for_event_index(index)
            if speech is None:
                continue

            speaker_name = speech.speaker_name
            if not current_speeches:
                current_speeches = [speech]
                current_event_indices = [index]
                buffered_stage_indices = []
                participant_names = [speaker_name]
                continue

            if speaker_name not in participant_names:
                if len(participant_names) >= max_participants:
                    flush()
                    current_speeches = [speech]
                    current_event_indices = [index]
                    buffered_stage_indices = []
                    participant_names = [speaker_name]
                    continue
                participant_names.append(speaker_name)

            current_event_indices.extend(buffered_stage_indices)
            current_event_indices.append(index)
            current_speeches.append(speech)
            buffered_stage_indices = []

        flush()
        return segments

    def _build_monologues(self) -> list[Monologue]:
        monologues: list[Monologue] = []
        for segment in self._iter_speech_segments(max_participants=1):
            if not segment.speeches:
                continue
            monologues.append(
                Monologue(
                    play=self,
                    speaker=segment.speeches[0].speaker,
                    speeches=segment.speeches,
                    _event_indices=segment.event_indices,
                )
            )
        return monologues

    def _build_dialogues(self) -> list[Dialogue]:
        dialogues: list[Dialogue] = []
        for segment in self._iter_speech_segments(max_participants=2):
            if len(segment.participant_names) != 2 or len(segment.speeches) < 2:
                continue
            first_name, second_name = segment.participant_names
            first = self.character(first_name) or Character(play=self, name=first_name)
            second = self.character(second_name) or Character(play=self, name=second_name)
            dialogues.append(
                Dialogue(
                    play=self,
                    speakers=(first, second),
                    speeches=segment.speeches,
                    _event_indices=segment.event_indices,
                )
            )
        return dialogues


@dataclass(frozen=True, slots=True)
class Act:
    """Read-only derived view representing one act."""

    play: Play
    number: int
    label: str
    events: tuple[PlayEvent, ...]
    _start_index: int = field(repr=False, compare=False)
    _end_index: int = field(repr=False, compare=False)

    @property
    def scenes(self) -> list[Scene]:
        return [
            scene
            for scene in self.play.scenes
            if scene.act_number == self.number and self._start_index <= scene._start_index < self._end_index
        ]

    @property
    def speeches(self) -> list[Speech]:
        return [speech for speech in self.play.speeches if self._start_index <= speech.event_index < self._end_index]

    @property
    def characters(self) -> list[Character]:
        seen: set[str] = set()
        characters: list[Character] = []
        for speech in self.speeches:
            character = speech.speaker
            if character.name in seen:
                continue
            seen.add(character.name)
            characters.append(character)
        return characters

    def monologues(
        self,
        *,
        min_lines: int = DEFAULT_MIN_MONOLOGUE_LINES,
        min_words: int | None = None,
        min_speeches: int | None = None,
    ) -> list[Monologue]:
        return [
            monologue
            for monologue in self.play.monologues(
                min_lines=min_lines,
                min_words=min_words,
                min_speeches=min_speeches,
            )
            if monologue.act == self
        ]

    def dialogues(
        self,
        *,
        min_turns: int = DEFAULT_MIN_DIALOGUE_TURNS,
        min_lines: int | None = None,
        min_words: int | None = None,
    ) -> list[Dialogue]:
        return [
            dialogue
            for dialogue in self.play.dialogues(
                min_turns=min_turns,
                min_lines=min_lines,
                min_words=min_words,
            )
            if dialogue.act == self
        ]


@dataclass(frozen=True, slots=True)
class Scene:
    """Read-only derived view representing one scene."""

    play: Play
    act_number: int | None
    scene_number: int | None
    label: str
    events: tuple[PlayEvent, ...]
    _start_index: int = field(repr=False, compare=False)
    _end_index: int = field(repr=False, compare=False)

    @property
    def act(self) -> Act | None:
        return self.play._act_for_event_index(self._start_index)

    @property
    def speeches(self) -> list[Speech]:
        return [speech for speech in self.play.speeches if self._start_index <= speech.event_index < self._end_index]

    @property
    def characters(self) -> list[Character]:
        seen: set[str] = set()
        characters: list[Character] = []
        for speech in self.speeches:
            character = speech.speaker
            if character.name in seen:
                continue
            seen.add(character.name)
            characters.append(character)
        return characters

    def monologues(
        self,
        *,
        min_lines: int = DEFAULT_MIN_MONOLOGUE_LINES,
        min_words: int | None = None,
        min_speeches: int | None = None,
    ) -> list[Monologue]:
        return [
            monologue
            for monologue in self.play.monologues(
                min_lines=min_lines,
                min_words=min_words,
                min_speeches=min_speeches,
            )
            if monologue.scene == self
        ]

    def dialogues(
        self,
        *,
        min_turns: int = DEFAULT_MIN_DIALOGUE_TURNS,
        min_lines: int | None = None,
        min_words: int | None = None,
    ) -> list[Dialogue]:
        return [
            dialogue
            for dialogue in self.play.dialogues(
                min_turns=min_turns,
                min_lines=min_lines,
                min_words=min_words,
            )
            if dialogue.scene == self
        ]


@dataclass(frozen=True, slots=True)
class Character:
    """Read-only derived view representing one speaking character."""

    play: Play
    name: str

    @property
    def speeches(self) -> list[Speech]:
        return [speech for speech in self.play.speeches if speech.speaker_name == self.name]

    @property
    def scenes(self) -> list[Scene]:
        seen: set[tuple[int | None, int | None, str]] = set()
        scenes: list[Scene] = []
        for speech in self.speeches:
            scene = speech.scene
            if scene is None:
                continue
            key = (scene.act_number, scene.scene_number, scene.label)
            if key in seen:
                continue
            seen.add(key)
            scenes.append(scene)
        return scenes

    @property
    def acts(self) -> list[Act]:
        seen: set[int] = set()
        acts: list[Act] = []
        for speech in self.speeches:
            act = speech.act
            if act is None or act.number in seen:
                continue
            seen.add(act.number)
            acts.append(act)
        return acts

    @property
    def line_count(self) -> int:
        return sum(speech.line_count for speech in self.speeches)

    @property
    def word_count(self) -> int:
        return sum(speech.word_count for speech in self.speeches)

    def monologues(
        self,
        *,
        min_lines: int = DEFAULT_MIN_MONOLOGUE_LINES,
        min_words: int | None = None,
        min_speeches: int | None = None,
    ) -> list[Monologue]:
        return [
            monologue
            for monologue in self.play.monologues(
                min_lines=min_lines,
                min_words=min_words,
                min_speeches=min_speeches,
            )
            if monologue.speaker_name == self.name
        ]

    def dialogues(
        self,
        *,
        min_turns: int = DEFAULT_MIN_DIALOGUE_TURNS,
        min_lines: int | None = None,
        min_words: int | None = None,
    ) -> list[Dialogue]:
        return [
            dialogue
            for dialogue in self.play.dialogues(
                min_turns=min_turns,
                min_lines=min_lines,
                min_words=min_words,
            )
            if self.name in dialogue.speaker_names
        ]


@dataclass(frozen=True, slots=True)
class Speech:
    """Read-only derived view representing one speech event."""

    play: Play
    event_index: int

    @property
    def event(self) -> PlayEvent:
        return self.play._events[self.event_index]

    @property
    def speaker_name(self) -> str:
        return self.event["speaker"]

    @property
    def speaker(self) -> Character:
        return self.play.character(self.speaker_name) or Character(play=self.play, name=self.speaker_name)

    @property
    def text(self) -> str:
        return self.event["text"]

    @property
    def line_count(self) -> int:
        return self.event["line_count"]

    @property
    def word_count(self) -> int:
        return self.event["word_count"]

    @property
    def labelled(self) -> bool | None:
        return self.event.get("labelled")

    @property
    def act(self) -> Act | None:
        return self.play._act_for_event_index(self.event_index)

    @property
    def scene(self) -> Scene | None:
        return self.play._scene_for_event_index(self.event_index)

    @property
    def attached_stage_directions(self) -> list[str]:
        texts: list[str] = []
        index = self.event_index - 1
        while index >= 0:
            event = self.play._events[index]
            if event["type"] != "stage_direction" or event.get("attachment") != "next":
                break
            texts.append(event["text"])
            index -= 1
        texts.reverse()
        return texts


@dataclass(frozen=True, slots=True)
class Monologue:
    """Read-only derived view representing one speaker's continuous spoken unit."""

    play: Play
    speaker: Character
    speeches: tuple[Speech, ...]
    _event_indices: tuple[int, ...] = field(repr=False, compare=False)

    @property
    def speaker_name(self) -> str:
        return self.speaker.name

    @property
    def text(self) -> str:
        return "\n\n".join(speech.text for speech in self.speeches)

    @property
    def line_count(self) -> int:
        return sum(speech.line_count for speech in self.speeches)

    @property
    def word_count(self) -> int:
        return sum(speech.word_count for speech in self.speeches)

    @property
    def act(self) -> Act | None:
        if not self.speeches:
            return None
        act = self.speeches[0].act
        if all(speech.act == act for speech in self.speeches):
            return act
        return None

    @property
    def scene(self) -> Scene | None:
        if not self.speeches:
            return None
        scene = self.speeches[0].scene
        if all(speech.scene == scene for speech in self.speeches):
            return scene
        return None

    @property
    def events(self) -> tuple[PlayEvent, ...]:
        return tuple(self.play._events[index] for index in self._event_indices)


@dataclass(frozen=True, slots=True)
class Dialogue:
    """Read-only derived view representing an exchange between two characters."""

    play: Play
    speakers: tuple[Character, Character]
    speeches: tuple[Speech, ...]
    _event_indices: tuple[int, ...] = field(repr=False, compare=False)

    @property
    def speaker_names(self) -> tuple[str, str]:
        return (self.speakers[0].name, self.speakers[1].name)

    @property
    def text(self) -> str:
        return "\n\n".join(speech.text for speech in self.speeches)

    @property
    def turn_count(self) -> int:
        return len(self.speeches)

    @property
    def line_count(self) -> int:
        return sum(speech.line_count for speech in self.speeches)

    @property
    def word_count(self) -> int:
        return sum(speech.word_count for speech in self.speeches)

    @property
    def act(self) -> Act | None:
        if not self.speeches:
            return None
        act = self.speeches[0].act
        if all(speech.act == act for speech in self.speeches):
            return act
        return None

    @property
    def scene(self) -> Scene | None:
        if not self.speeches:
            return None
        scene = self.speeches[0].scene
        if all(speech.scene == scene for speech in self.speeches):
            return scene
        return None

    @property
    def events(self) -> tuple[PlayEvent, ...]:
        return tuple(self.play._events[index] for index in self._event_indices)
