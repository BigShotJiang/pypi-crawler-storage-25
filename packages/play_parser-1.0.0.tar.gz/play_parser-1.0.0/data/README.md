# Test corpus data

The files in this directory are used as test fixtures and reference corpus material for parser development.

The raw play texts are public-domain source texts. The canonical JSON files are generated or curated fixtures used to validate parser behaviour.

These files are not required for normal package use.
