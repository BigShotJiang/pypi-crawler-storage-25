This folder contains checked-in JSON fixtures for the corpus tests.

The test suite uses these files as canonical targets for:

- generating JSON from raw `.txt` input
- comparing generated JSON with checked-in canonical JSON
- roundtripping raw `.txt` through JSON generation and text assembly
