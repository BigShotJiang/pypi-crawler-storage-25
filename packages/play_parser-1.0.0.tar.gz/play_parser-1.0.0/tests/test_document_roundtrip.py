from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from play_parser._io import DEFAULT_MAX_INPUT_BYTES
from play_parser.document.assembler import assemble_play_text
from play_parser.document.builder import build_play_document, build_play_document_from_file, write_json_file

SAMPLE_TEXT = """Example Play
by William Shakespeare

ACT I

SCENE I. A room.

HAMLET: To be or not to be.
"""


class DocumentRoundtripTests(unittest.TestCase):
    def test_build_play_document_collects_metadata_and_events(self) -> None:
        document = build_play_document(SAMPLE_TEXT)

        self.assertEqual(document["metadata"]["title"], "Example Play")
        self.assertEqual(document["metadata"]["author"], "William Shakespeare")
        self.assertEqual(document["metadata"]["stats"]["acts"], 1)
        self.assertEqual(document["metadata"]["stats"]["scenes"], 1)
        self.assertEqual(document["metadata"]["stats"]["speeches"], 1)
        self.assertEqual(document["events"][0]["type"], "meta")
        self.assertEqual(document["events"][-1]["type"], "speech")

    def test_json_to_text_to_json_is_idempotent_for_sample(self) -> None:
        document = build_play_document(SAMPLE_TEXT, play_name="Example Play")
        canonical_text = assemble_play_text(document)
        reparsed = build_play_document(canonical_text, play_name="Example Play")

        self.assertEqual(reparsed, document)

    def test_raw_txt_to_json_to_normalised_txt_to_json_is_idempotent_for_corpus(self) -> None:
        raw_root = ROOT / "data" / "text" / "raw"
        raw_files = sorted(path for path in raw_root.glob("*.txt") if path.is_file())
        self.assertGreater(len(raw_files), 0)

        for raw_path in raw_files:
            with self.subTest(play=raw_path.stem):
                first = build_play_document_from_file(raw_path)
                normalised_text = assemble_play_text(first)
                second = build_play_document(normalised_text, play_name=raw_path.stem)
                self.assertEqual(second, first)

    def test_write_json_file_writes_same_document_that_it_returns(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            input_path = tmp / "Example.txt"
            output_path = tmp / "out" / "Example.json"
            input_path.write_text(SAMPLE_TEXT, encoding="utf-8")

            returned = write_json_file(input_path, output_path)
            written = json.loads(output_path.read_text(encoding="utf-8"))

        self.assertEqual(written, returned)

    def test_rejects_oversized_text_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "Large.txt"
            with path.open("wb") as handle:
                handle.truncate(DEFAULT_MAX_INPUT_BYTES + 1)

            with self.assertRaisesRegex(ValueError, "too large"):
                build_play_document_from_file(path)


if __name__ == "__main__":
    unittest.main()
