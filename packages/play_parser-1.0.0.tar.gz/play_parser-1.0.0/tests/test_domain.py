from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from play_parser import Play
from play_parser.document.builder import build_play_document

SAMPLE_TEXT = """Example Play
by William Shakespeare

ACT I

SCENE I. A room.

HAMLET: To be or not to be.

OPHELIA: Good my lord.

HAMLET: I did love you once.
"""


class DomainTests(unittest.TestCase):
    def test_play_exposes_core_domain_views(self) -> None:
        play = Play(build_play_document(SAMPLE_TEXT, play_name="Example Play"))

        self.assertEqual(play.title, "Example Play")
        self.assertEqual(play.author, "William Shakespeare")
        self.assertEqual(len(play.acts), 1)
        self.assertEqual(len(play.scenes), 1)
        self.assertEqual([character.name for character in play.characters], ["Hamlet", "Ophelia"])
        self.assertEqual(len(play.speeches), 3)

    def test_monologues_and_dialogues_are_derived_from_speeches(self) -> None:
        play = Play(build_play_document(SAMPLE_TEXT, play_name="Example Play"))

        self.assertEqual([m.speaker.name for m in play.monologues(min_lines=1)], ["Hamlet", "Ophelia", "Hamlet"])
        self.assertEqual(len(play.dialogues(min_turns=2)), 1)

    def test_play_defensively_copies_source_document(self) -> None:
        document = build_play_document(SAMPLE_TEXT, play_name="Example Play")
        play = Play(document)

        document["metadata"]["title"] = "Mutated source"
        document["events"][2]["label"] = "MUTATED SOURCE"

        self.assertEqual(play.title, "Example Play")
        self.assertEqual(play.events[2]["label"], "ACT I")
        self.assertEqual(play.acts[0].label, "ACT I")

    def test_play_returns_defensive_metadata_and_event_copies(self) -> None:
        play = Play(build_play_document(SAMPLE_TEXT, play_name="Example Play"))

        metadata = play.metadata
        metadata["title"] = "Mutated"
        events = play.events
        events[2]["label"] = "MUTATED"

        self.assertEqual(play.title, "Example Play")
        self.assertEqual(play.events[2]["label"], "ACT I")
        self.assertEqual(play.acts[0].label, "ACT I")

    def test_play_as_dict_returns_defensive_copies(self) -> None:
        play = Play(build_play_document(SAMPLE_TEXT, play_name="Example Play"))

        document = play.as_dict()
        document["metadata"]["title"] = "Mutated again"
        document["events"][2]["label"] = "MUTATED AGAIN"

        self.assertEqual(play.title, "Example Play")
        self.assertEqual(play.events[2]["label"], "ACT I")
        self.assertEqual(play.acts[0].label, "ACT I")

    def test_play_assemble_roundtrips_through_domain_wrapper(self) -> None:
        play = Play(build_play_document(SAMPLE_TEXT, play_name="Example Play"))
        assembled = play.assemble()
        reparsed = Play(build_play_document(assembled, play_name="Example Play"))

        self.assertEqual(reparsed.as_dict(), play.as_dict())


if __name__ == "__main__":
    unittest.main()
