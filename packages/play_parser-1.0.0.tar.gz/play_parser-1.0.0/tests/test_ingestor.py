from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from play_parser import PlayIngestor
from play_parser.document.builder import build_play_document
from play_parser.parsing import get_format_profile

SAMPLE_TEXT = """Example Play
by William Shakespeare

ACT I

SCENE I. A room.

HAMLET: To be or not to be.
"""


class IngestorTests(unittest.TestCase):
    def test_play_ingestor_supports_text_and_json_sources(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            text_path = tmp / "Example.txt"
            json_path = tmp / "Example.json"
            text_path.write_text(SAMPLE_TEXT, encoding="utf-8")

            text_ingestor = PlayIngestor(text_path)
            text_ingestor.write(json_path)
            json_ingestor = PlayIngestor(json_path)
            json_data = json_ingestor.data
            text_data = text_ingestor.data

        self.assertEqual(json_data, text_data)

    def test_play_ingestor_from_text_matches_text_file_ingestion(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "Example.txt"
            path.write_text(SAMPLE_TEXT, encoding="utf-8")

            file_ingestor = PlayIngestor(path, profile="colon_inline")
            text_ingestor = PlayIngestor.from_text(
                SAMPLE_TEXT,
                source_name="Example.txt",
                profile="colon_inline",
            )
            file_data = file_ingestor.data
            text_data = text_ingestor.data

        self.assertEqual(text_data, file_data)
        self.assertIsNotNone(text_ingestor.profile)
        self.assertEqual(text_ingestor.profile.name, "colon_inline")
        self.assertEqual(text_ingestor.src, Path("Example.txt"))

    def test_play_ingestor_from_text_uses_source_name_as_title_fallback(self) -> None:
        text = """ACT I

SCENE I. A room.

HAMLET: To be or not to be.
"""

        ingestor = PlayIngestor.from_text(text, source_name="Fallback Title.txt")

        self.assertEqual(ingestor.data["metadata"]["title"], "Fallback Title")

    def test_play_ingestor_accepts_builtin_profile_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "Example.txt"
            path.write_text(SAMPLE_TEXT, encoding="utf-8")

            ingestor = PlayIngestor(path, profile="colon_inline")

        self.assertIsNotNone(ingestor.profile)
        self.assertEqual(ingestor.profile.name, "colon_inline")

    def test_play_ingestor_accepts_format_profile_instance(self) -> None:
        profile = get_format_profile("colon_inline")
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "Example.txt"
            path.write_text(SAMPLE_TEXT, encoding="utf-8")

            ingestor = PlayIngestor(path, profile=profile)

        self.assertIs(ingestor.profile, profile)

    def test_play_ingestor_rejects_profiles_for_json_sources(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            json_path = Path(tmpdir) / "Example.json"
            json_path.write_text(json.dumps(build_play_document(SAMPLE_TEXT)), encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "only to raw '.txt'"):
                PlayIngestor(json_path, profile="colon_inline")

    def test_play_ingestor_rejects_unsupported_suffixes(self) -> None:
        with self.assertRaises(ValueError):
            PlayIngestor("Hamlet.pdf")


if __name__ == "__main__":
    unittest.main()
