from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from play_parser.document.text import count_words
from play_parser.parsing.parser import parse_play_text


class ParserCoreTests(unittest.TestCase):
    def test_parses_basic_act_scene_speech_and_stage_direction(self) -> None:
        events = parse_play_text(
            """ACT I

            SCENE I. A room.

            HAMLET: To be, or not to be.
            [Exit]
            """
        )

        self.assertEqual(events[0], {"type": "act_start", "act_number": 1, "label": "ACT I"})
        self.assertEqual(
            events[1],
            {"type": "scene_start", "scene_number": 1, "label": "SCENE I. A room."},
        )
        self.assertEqual(events[2]["type"], "speech")
        self.assertEqual(events[2]["speaker"], "Hamlet")
        self.assertEqual(events[2]["text"], "To be, or not to be.")
        self.assertEqual(events[3], {"type": "stage_direction", "subtype": "exit", "text": "[Exit]"})

    def test_unlabelled_continuation_after_stage_direction_keeps_same_speaker(self) -> None:
        events = parse_play_text(
            """ACT I

            HAMLET: First line.
            [Aside]
            Second line.
            """
        )

        speeches = [event for event in events if event["type"] == "speech"]
        self.assertEqual(len(speeches), 2)
        self.assertEqual(speeches[0]["speaker"], "Hamlet")
        self.assertEqual(speeches[0]["labelled"], True)
        self.assertEqual(speeches[1]["speaker"], "Hamlet")
        self.assertEqual(speeches[1]["labelled"], False)

    def test_empty_bracket_markers_are_ignored(self) -> None:
        events = parse_play_text(
            """ACT I

            FIRST SPEAKER: I will begin the matter [ ]
            And then continue without interruption.
            """
        )

        self.assertEqual(
            events[1:],
            [
                {
                    "type": "speech",
                    "speaker": "First Speaker",
                    "text": "I will begin the matter\nAnd then continue without interruption.",
                    "line_count": 2,
                    "word_count": 10,
                    "labelled": True,
                },
            ],
        )

    def test_count_words_handles_shakespearean_contractions(self) -> None:
        self.assertEqual(count_words("I'll go; 'tis done, o'erthrown."), 5)


if __name__ == "__main__":
    unittest.main()
