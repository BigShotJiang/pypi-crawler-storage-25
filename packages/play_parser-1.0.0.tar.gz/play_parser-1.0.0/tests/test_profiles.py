from __future__ import annotations

import json
import sys
import tempfile
import unittest
from importlib.resources import files
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from play_parser.parsing import get_format_profile, list_format_profiles, load_format_profile_config, parse_play_text
from play_parser.parsing.profiles.loader import load_format_profile_file
from play_parser.parsing.profiles.schema import validate_format_profile_config


def valid_profile_config() -> dict[str, object]:
    return {
        "name": "test_profile",
        "version": 1,
        "description": "A valid test profile.",
        "speaker_label_patterns": ["NAME_COLON"],
        "speaker_text_position": "same_line",
        "speaker_name_case": ["upper", "title"],
        "stage_direction_delimiters": ["[]", "()"],
        "inline_stage_directions": True,
        "multiline_stage_directions": False,
        "strip_underscore_italics_in_stage_directions": True,
        "examples": ["PLAYER: A valid example."],
    }


class ProfileTests(unittest.TestCase):
    def test_builtin_profiles_are_listed_and_valid(self) -> None:
        names = set(list_format_profiles())
        self.assertIn("colon_inline", names)
        self.assertIn("dot_inline", names)

        for resource in files("play_parser.parsing.profiles.builtins").iterdir():
            if resource.name.endswith(".json"):
                with self.subTest(profile=resource.name):
                    payload = json.loads(resource.read_text(encoding="utf-8"))
                    self.assertEqual(validate_format_profile_config(payload), payload)

    def test_get_format_profile_loads_named_builtin(self) -> None:
        profile = get_format_profile("colon_inline")

        self.assertEqual(profile.name, "colon_inline")
        self.assertEqual(profile.config["inline_stage_directions"], True)
        self.assertEqual(profile.speaker_text_position, "same_line")
        self.assertIn("NAME_COLON", profile.speaker_label_patterns)

    def test_format_profile_config_is_immutable(self) -> None:
        profile = get_format_profile("colon_inline")

        with self.assertRaises(TypeError):
            profile.config["speaker_label_patterns"] = []  # type: ignore[index]

        with self.assertRaises(TypeError):
            profile.config["speaker_label_patterns"][0] = "BARE_NAME"  # type: ignore[index]

    def test_profile_loader_defensively_copies_config(self) -> None:
        config = valid_profile_config()
        loaded = load_format_profile_config(config)

        config["speaker_label_patterns"] = []

        self.assertEqual(loaded.speaker_label_patterns, ("NAME_COLON",))

    def test_custom_profile_can_be_loaded_from_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "profile.json"
            path.write_text(json.dumps(valid_profile_config()), encoding="utf-8")

            loaded = load_format_profile_file(path)

        self.assertEqual(loaded.name, "test_profile")

    def test_title_case_adjacent_colon_speeches_without_blank_line_are_separate(self) -> None:
        events = parse_play_text(
            """Hamlet: To be.
Ophelia: My lord.
""",
            profile=get_format_profile("colon_inline"),
        )

        speeches = [event for event in events if event["type"] == "speech"]

        self.assertEqual(len(speeches), 2)
        self.assertEqual(speeches[0]["speaker"], "Hamlet")
        self.assertEqual(speeches[0]["text"], "To be.")
        self.assertEqual(speeches[1]["speaker"], "Ophelia")
        self.assertEqual(speeches[1]["text"], "My lord.")

    def test_title_case_dot_block_profile_parses_speech(self) -> None:
        events = parse_play_text(
            """Algernon.
Did you hear?
""",
            profile=get_format_profile("dot_block"),
        )

        speeches = [event for event in events if event["type"] == "speech"]

        self.assertEqual(len(speeches), 1)
        self.assertEqual(speeches[0]["speaker"], "Algernon")
        self.assertEqual(speeches[0]["text"], "Did you hear?")

    def test_title_case_mixed_parenthetical_adjacent_dot_speeches_are_separate(self) -> None:
        events = parse_play_text(
            """Slightly (solemnly). No.
Hook. Not now.
""",
            profile=get_format_profile("mixed_parenthetical"),
        )

        speeches = [event for event in events if event["type"] == "speech"]

        self.assertEqual(len(speeches), 2)
        self.assertEqual(speeches[0]["speaker"], "Slightly")
        self.assertEqual(speeches[0]["text"], "No.")
        self.assertEqual(speeches[1]["speaker"], "Hook")
        self.assertEqual(speeches[1]["text"], "Not now.")

    def test_default_adjacent_uppercase_speeches_without_blank_line_are_separate(self) -> None:
        events = parse_play_text(
            """HAMLET: To be.
OPHELIA: My lord.
"""
        )

        speeches = [event for event in events if event["type"] == "speech"]

        self.assertEqual(len(speeches), 2)
        self.assertEqual(speeches[0]["speaker"], "Hamlet")
        self.assertEqual(speeches[0]["text"], "To be.")
        self.assertEqual(speeches[1]["speaker"], "Ophelia")
        self.assertEqual(speeches[1]["text"], "My lord.")

    def test_profile_validation_rejects_invalid_configs(self) -> None:
        missing = valid_profile_config()
        del missing["speaker_text_position"]
        with self.assertRaisesRegex(ValueError, "missing required fields"):
            validate_format_profile_config(missing)

        unknown = valid_profile_config()
        unknown["surprise"] = True
        with self.assertRaisesRegex(ValueError, "unknown fields"):
            validate_format_profile_config(unknown)

        wrong_type = valid_profile_config()
        wrong_type["inline_stage_directions"] = "true"
        with self.assertRaisesRegex(ValueError, "must be a boolean"):
            validate_format_profile_config(wrong_type)


if __name__ == "__main__":
    unittest.main()
