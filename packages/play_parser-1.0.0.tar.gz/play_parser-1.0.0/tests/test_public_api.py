import unittest

import play_parser
from play_parser import (
    Play,
    PlayIngestor,
    assemble_play_text,
    get_format_profile,
    list_format_profiles,
    validate_play_document,
)


class PublicApiTests(unittest.TestCase):
    def test_version_is_exported(self):
        self.assertEqual(play_parser.__version__, "1.0.0")

    def test_profile_helpers_are_exported(self):
        self.assertIn("colon_inline", list_format_profiles())
        self.assertEqual(get_format_profile("colon_inline").name, "colon_inline")

    def test_readme_style_quick_start(self):
        text = "ACT I\n\nSCENE I.\n\nHAMLET: Who's there?\n"
        ingestor = PlayIngestor.from_text(text, source_name="Hamlet.txt", profile="colon_inline")
        document = validate_play_document(ingestor.data)
        play = Play(document)

        self.assertEqual(play.title, "Hamlet")
        self.assertEqual(len(play.acts), 1)
        self.assertEqual(len(play.scenes), 1)
        self.assertEqual(len(play.speeches), 1)
        self.assertIn("Hamlet: Who's there?", assemble_play_text(document))
