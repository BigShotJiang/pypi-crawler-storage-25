from __future__ import annotations

import contextlib
import io
import time
from functools import wraps
from pathlib import Path
from typing import Callable, Any

from .analysis import basic_analysis
from .config import RUNS_DIR, STATE_DIR
from .registry import get_tracked_files
from .utils import load_json, now_stamp, read_text, save_json, sha256_text, unified_diff, write_text


LAST_MANIFEST_PATH = STATE_DIR / "last_manifest.json"


def _snapshot(files: list[str]) -> dict[str, dict[str, str | int]]:
    snap = {}
    for file in files:
        p = Path(file)
        if p.exists() and p.is_file():
            text = read_text(p)
            snap[str(p)] = {"hash": sha256_text(text), "text": text, "size": len(text)}
    return snap


def run_tracked(main_callable: Callable[[], Any], entry_file: str | None = None, run_name: str | None = None, timeout_note: str | None = None):
    files = get_tracked_files(entry_file)
    before = _snapshot(files)
    previous = load_json(LAST_MANIFEST_PATH, default={}) or {}

    run_id = now_stamp()
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    started = time.perf_counter()
    status = "SUCCESS"
    result = None

    try:
        with contextlib.redirect_stdout(stdout_buffer), contextlib.redirect_stderr(stderr_buffer):
            result = main_callable()
    except Exception as exc:
        status = "FAIL"
        stderr_buffer.write(f"\nEXCEPTION: {type(exc).__name__}: {exc}\n")
        raise
    finally:
        duration = time.perf_counter() - started
        after = _snapshot(files)
        save_json(run_dir / "manifest_before.json", before)
        save_json(run_dir / "manifest_after.json", after)
        save_json(LAST_MANIFEST_PATH, after)

        changed_files: list[str] = []
        diff_chunks: list[str] = []
        for file, meta in after.items():
            prev = previous.get(file, {})
            if prev.get("hash") != meta.get("hash"):
                changed_files.append(file)
                diff_chunks.append(unified_diff(str(prev.get("text", "")), str(meta.get("text", "")), file))
        for file, prev in previous.items():
            if file not in after:
                changed_files.append(file)
                diff_chunks.append(unified_diff(str(prev.get("text", "")), "", file))

        stdout = stdout_buffer.getvalue()
        stderr = stderr_buffer.getvalue()
        write_text(run_dir / "output.txt", stdout)
        write_text(run_dir / "error.txt", stderr)
        write_text(run_dir / "diff.txt", "\n".join(diff_chunks))

        analysis = basic_analysis(status, duration, stdout, stderr, changed_files)
        meta = {
            "run_id": run_id,
            "entry_file": entry_file,
            "tracked_files": files,
            "status": status,
            "duration_sec": round(duration, 3),
            "run_name": run_name or Path(entry_file).name if entry_file else "tracked_run",
            "changed_files": changed_files,
        }
        save_json(run_dir / "meta.json", meta)
        save_json(run_dir / "analysis.json", analysis)

    return result


def tracked_main(run_name: str | None = None):
    def decorator(func: Callable[..., Any]):
        @wraps(func)
        def wrapper(*args, **kwargs):
            entry_file = func.__globals__.get("__file__")
            return run_tracked(lambda: func(*args, **kwargs), entry_file=entry_file, run_name=run_name)
        return wrapper
    return decorator
