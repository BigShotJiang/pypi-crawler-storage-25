from __future__ import annotations

from .utils import load_json


def basic_analysis(status: str, duration_sec: float, stdout: str, stderr: str, changed_files: list[str]) -> dict:
    score = 20
    if status == "SUCCESS":
        score += 45
    if stdout.strip():
        score += 10
    if not stderr.strip():
        score += 15
    if duration_sec < 3:
        score += 10
    elif duration_sec > 20:
        score -= 10
    score = max(0, min(100, score))

    if status == "SUCCESS" and stderr.strip():
        label = "PARTIAL"
    elif status == "SUCCESS":
        label = "SUCCESS"
    elif "timeout" in stderr.lower():
        label = "HANG"
    else:
        label = "FAIL"

    summary = f"Status: {label}. Změněné/sledované soubory: {', '.join(changed_files) if changed_files else 'žádné'}"
    return {
        "summary": summary,
        "status_label": label,
        "score": score,
        "changed_files": changed_files,
        "stderr_preview": stderr[:300],
    }
