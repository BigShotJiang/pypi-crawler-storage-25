from __future__ import annotations

from pathlib import Path

_TRACKED: set[str] = set()


def track_this_file(path: str) -> None:
    _TRACKED.add(str(Path(path).resolve()))


def get_tracked_files(entry_file: str | None = None) -> list[str]:
    files = set(_TRACKED)
    if entry_file:
        files.add(str(Path(entry_file).resolve()))
    return sorted(files)
