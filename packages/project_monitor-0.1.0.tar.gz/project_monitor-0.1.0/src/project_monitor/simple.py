from __future__ import annotations

import atexit
import inspect
import io
import sys
import traceback
from pathlib import Path

from .analysis import basic_analysis
from .config import RUNS_DIR, STATE_DIR
from .registry import track_this_file, get_tracked_files
from .utils import load_json, now_stamp, read_text, save_json, sha256_text, unified_diff, write_text

_LAST_MANIFEST_PATH = STATE_DIR / "last_manifest.json"
_STARTED = False
_FINALIZED = False
_ENTRY_FILE: str | None = None
_STATUS = "SUCCESS"
_EXCEPTION_TEXT = ""
_STDOUT_BUFFER = io.StringIO()
_STDERR_BUFFER = io.StringIO()
_ORIG_STDOUT = sys.stdout
_ORIG_STDERR = sys.stderr


class _Tee:
    def __init__(self, original, buffer):
        self.original = original
        self.buffer = buffer

    def write(self, data):
        self.original.write(data)
        self.buffer.write(data)
        return len(data)

    def flush(self):
        self.original.flush()
        self.buffer.flush()


def _snapshot(files: list[str]) -> dict[str, dict[str, str | int]]:
    snap = {}
    for file in files:
        p = Path(file)
        if p.exists() and p.is_file():
            text = read_text(p)
            snap[str(p)] = {"hash": sha256_text(text), "text": text, "size": len(text)}
    return snap


def _capture_exception(exc_type, exc, tb):
    global _STATUS, _EXCEPTION_TEXT
    _STATUS = "FAIL"
    _EXCEPTION_TEXT = "".join(traceback.format_exception(exc_type, exc, tb))
    _ORIG_STDERR.write(_EXCEPTION_TEXT)


def _finalize():
    global _FINALIZED
    if _FINALIZED:
        return
    _FINALIZED = True

    files = get_tracked_files(_ENTRY_FILE)
    previous = load_json(_LAST_MANIFEST_PATH, default={}) or {}
    after = _snapshot(files)

    run_id = now_stamp()
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    diff_chunks = []
    changed_files = []
    for file, meta in after.items():
        prev = previous.get(file, {})
        if prev.get("hash") != meta.get("hash"):
            changed_files.append(file)
            diff_chunks.append(unified_diff(str(prev.get("text", "")), str(meta.get("text", "")), file))
    for file, prev in previous.items():
        if file not in after:
            changed_files.append(file)
            diff_chunks.append(unified_diff(str(prev.get("text", "")), "", file))

    stdout = _STDOUT_BUFFER.getvalue()
    stderr = _STDERR_BUFFER.getvalue() + (_EXCEPTION_TEXT if _EXCEPTION_TEXT and _EXCEPTION_TEXT not in _STDERR_BUFFER.getvalue() else "")

    write_text(run_dir / "output.txt", stdout)
    write_text(run_dir / "error.txt", stderr)
    write_text(run_dir / "diff.txt", "\n".join(diff_chunks))
    save_json(run_dir / "manifest_after.json", after)
    save_json(_LAST_MANIFEST_PATH, after)

    analysis = basic_analysis(_STATUS, 0.0, stdout, stderr, changed_files)
    meta = {
        "run_id": run_id,
        "entry_file": _ENTRY_FILE,
        "tracked_files": files,
        "status": _STATUS,
        "duration_sec": 0.0,
        "run_name": Path(_ENTRY_FILE).name if _ENTRY_FILE else "monitor_file",
        "changed_files": changed_files,
    }
    save_json(run_dir / "meta.json", meta)
    save_json(run_dir / "analysis.json", analysis)


def monitor_file(path: str | None = None) -> None:
    global _STARTED, _ENTRY_FILE
    inferred = None
    if path:
        inferred = path
    else:
        try:
            inferred = inspect.stack()[1].filename
        except Exception:
            inferred = sys.modules.get('__main__').__dict__.get('__file__')
    real_path = str(Path(inferred).resolve()) if inferred else None
    if real_path:
        track_this_file(real_path)
        if _ENTRY_FILE is None:
            _ENTRY_FILE = real_path

    if _STARTED:
        return
    _STARTED = True
    sys.stdout = _Tee(_ORIG_STDOUT, _STDOUT_BUFFER)
    sys.stderr = _Tee(_ORIG_STDERR, _STDERR_BUFFER)
    sys.excepthook = _capture_exception
    atexit.register(_finalize)
