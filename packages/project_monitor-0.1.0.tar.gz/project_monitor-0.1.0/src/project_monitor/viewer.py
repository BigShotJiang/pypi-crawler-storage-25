from __future__ import annotations

import html
import webbrowser
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from .config import RUNS_DIR
from .utils import load_json, read_text

app = FastAPI(title="llm-dev-tracker")


def _load_runs(limit: int = 100):
    dirs = sorted([p for p in RUNS_DIR.iterdir() if p.is_dir()], key=lambda p: p.name, reverse=True)[:limit]
    runs = []
    for d in dirs:
        meta = load_json(d / "meta.json", default={}) or {}
        analysis = load_json(d / "analysis.json", default={}) or {}
        runs.append({
            **meta,
            **analysis,
            "stdout": read_text(d / "output.txt")[:2000] if (d / "output.txt").exists() else "",
            "stderr": read_text(d / "error.txt")[:1500] if (d / "error.txt").exists() else "",
            "diff": read_text(d / "diff.txt")[:4000] if (d / "diff.txt").exists() else "",
        })
    return runs


@app.get("/", response_class=HTMLResponse)
def index():
    cards = []
    for run in _load_runs(100):
        label = html.escape(run.get("status_label", run.get("status", "UNKNOWN")))
        color = "#56c271" if label == "SUCCESS" else "#e7b64a" if label == "PARTIAL" else "#e06c75"
        files = "<br>".join(html.escape(Path(f).name) for f in run.get("changed_files", [])) or "—"
        cards.append(f"""
        <div class='card'>
          <div class='head'>
            <b>{html.escape(run.get('run_id', ''))}</b>
            <span class='badge' style='background:{color}'>{label}</span>
            <span class='score'>score {run.get('score', 0)}</span>
          </div>
          <div><b>Soubor:</b> {html.escape(str(run.get('entry_file', '')))}</div>
          <div><b>Změněné/sledované soubory:</b><br>{files}</div>
          <div><b>Shrnutí:</b> {html.escape(run.get('summary', ''))}</div>
          <details><summary>Diff</summary><pre>{html.escape(run.get('diff', ''))}</pre></details>
          <details><summary>stderr</summary><pre>{html.escape(run.get('stderr', ''))}</pre></details>
        </div>
        """)

    page = f"""
    <html><head><meta charset='utf-8'>
    <style>
    body {{ font-family: Arial, sans-serif; margin: 20px; background: #111827; color: #f3f4f6; }}
    .card {{ background:#1f2937; padding:12px; margin-bottom:12px; border-radius:10px; }}
    .head {{ display:flex; gap:10px; align-items:center; margin-bottom:8px; flex-wrap:wrap; }}
    .badge {{ color:#111827; padding:2px 8px; border-radius:999px; font-weight:700; }}
    .score {{ background:#374151; padding:2px 8px; border-radius:999px; }}
    pre {{ white-space: pre-wrap; background:#0b1220; padding:10px; border-radius:8px; }}
    </style></head><body>
    <h1>llm-dev-tracker</h1>
    {''.join(cards) or '<p>Zatím žádné běhy.</p>'}
    </body></html>
    """
    return HTMLResponse(page)


def main():
    url = "http://127.0.0.1:8765"
    try:
        webbrowser.open(url)
    except Exception:
        pass
    uvicorn.run(app, host="127.0.0.1", port=8765)
