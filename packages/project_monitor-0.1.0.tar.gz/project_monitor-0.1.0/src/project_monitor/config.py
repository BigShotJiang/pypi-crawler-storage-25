from __future__ import annotations

import os
from pathlib import Path

DATA_ROOT = Path(os.environ.get("LLM_DEV_TRACKER_DATA_ROOT", Path.cwd() / ".llm_dev_tracker")).resolve()
RUNS_DIR = DATA_ROOT / "runs"
STATE_DIR = DATA_ROOT / "state"

for d in (DATA_ROOT, RUNS_DIR, STATE_DIR):
    d.mkdir(parents=True, exist_ok=True)
