"""High-level AI SDK for AgentEnv AI Gateway.

This module provides a user-friendly SDK for interacting with the AI Gateway,
similar to the OpenAI Python SDK.

Example:
    ```python
    from agentenv import AIClient

    client = AIClient(api_key="cr_xxxxx")

    # Chat completion
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.choices[0].message.content)

    # Streaming
    for chunk in client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}],
        stream=True
    ):
        print(chunk.choices[0].delta.content, end="")
    ```
"""

import os
from typing import Any, Iterator

from ..api.client import Client
from ..api.ai_gateway import AIGatewayAPI, ChatCompletionsAPI, EmbeddingsAPI
from ..api.models import (
    Message,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionChunk,
    EmbeddingRequest,
    EmbeddingResponse,
    CreateGatewayApiKeyRequest,
    GatewayUpstream,
    GatewayPool,
    GatewayApiKey,
    GatewayUsageReport,
)


class AIClient:
    """High-level AI Gateway client.

    This client provides access to AI Gateway features including chat completions,
    embeddings, and management APIs.

    Args:
        api_key: Gateway API key (format: cr_xxxx...). If not provided, uses
            AGENTENV_AI_KEY or AGENTENV_GATEWAY_KEY environment variable.
        base_url: Base URL of the API server. Defaults to AGENTENV_API_URL env var
            or https://api.agentenv.cloud.
        timeout: Request timeout in seconds. Defaults to 60.

    Example:
        ```python
        # With explicit key
        client = AIClient(api_key="cr_xxxxx")

        # From environment
        client = AIClient()

        # Custom base URL
        client = AIClient(base_url="http://localhost:3000")
        ```
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 60.0,
    ):
        """Initialize AI client."""
        self.api_key = api_key or os.getenv("AGENTENV_AI_KEY") or os.getenv("AGENTENV_GATEWAY_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Provide it as api_key parameter "
                "or set AGENTENV_AI_KEY environment variable."
            )

        self.base_url = base_url or os.getenv(
            "AGENTENV_API_URL", "https://api.agentenv.cloud"
        )
        self.timeout = timeout

        # Initialize underlying HTTP client
        self._client = Client(
            base_url=self.base_url,
            timeout=timeout,
        )

        # Initialize API gateway with gateway key
        self._api = AIGatewayAPI(self._client, gateway_key=self.api_key)

        # High-level interfaces
        self.chat = ChatAPI(self._api.chat)
        self.embeddings = Embeddings(self._api.embeddings)
        self.management = ManagementAPI(self._api)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, *args):
        """Context manager exit."""
        self._client.close()


class ChatAPI:
    """OpenAI-style chat namespace.

    Exposes `client.chat.completions.create(...)` while preserving the
    older `client.chat.create(...)` convenience path.
    """

    def __init__(self, api: ChatCompletionsAPI):
        self.completions = ChatCompletions(api)

    def create(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> ChatCompletionResponse | Iterator[ChatCompletionChunk]:
        """Alias for `client.chat.completions.create(...)`."""
        return self.completions.create(*args, **kwargs)


class ChatCompletions:
    """Chat completions interface.

    Provides methods for creating chat completions with support for streaming
    and non-streaming responses.

    Example:
        ```python
        # Non-streaming
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}]
        )
        print(response.choices[0].message.content)

        # Streaming
        for chunk in client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}],
            stream=True
        ):
            print(chunk.choices[0].delta.content, end="", flush=True)
        ```
    """

    def __init__(self, api: ChatCompletionsAPI):
        """Initialize chat completions interface.

        Args:
            api: Underlying chat completions API client
        """
        self._api = api

    def create(
        self,
        model: str,
        messages: list[dict[str, str]] | list[Message],
        temperature: float | None = None,
        max_tokens: int | None = None,
        stream: bool = False,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        **kwargs: Any,
    ) -> ChatCompletionResponse | Iterator[ChatCompletionChunk]:
        """Create a chat completion.

        Args:
            model: Model ID to use (e.g., "gpt-4", "claude-3-5-sonnet")
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            top_p: Nucleus sampling parameter
            stop: Stop sequences
            presence_penalty: Presence penalty (-2.0 to 2.0)
            frequency_penalty: Frequency penalty (-2.0 to 2.0)
            **kwargs: Additional provider-specific parameters

        Returns:
            Chat completion response (non-streaming) or iterator of
            chunks (streaming)
        """
        # Convert dict messages to Message objects if needed
        formatted_messages = []
        for msg in messages:
            if isinstance(msg, dict):
                formatted_messages.append(Message(**msg))
            else:
                formatted_messages.append(msg)

        request = ChatCompletionRequest(
            model=model,
            messages=formatted_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            top_p=top_p,
            stop=stop,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            **kwargs,
        )

        return self._api.create(request)


class Embeddings:
    """Embeddings interface.

    Provides methods for creating text embeddings.

    Example:
        ```python
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input="Hello world"
        )
        print(response.data[0].embedding)
        ```
    """

    def __init__(self, api: EmbeddingsAPI):
        """Initialize embeddings interface.

        Args:
            api: Underlying embeddings API client
        """
        self._api = api

    def create(
        self,
        model: str,
        input: str | list[str],
        encoding_format: str = "float",
        **kwargs: Any,
    ) -> EmbeddingResponse:
        """Create embeddings.

        Args:
            model: Model ID to use (e.g., "text-embedding-3-small")
            input: Text or list of texts to embed
            encoding_format: Encoding format ("float" or "base64")
            **kwargs: Additional provider-specific parameters

        Returns:
            Embedding response containing the embeddings
        """
        request = EmbeddingRequest(
            model=model,
            input=input,
            encoding_format=encoding_format,
            **kwargs,
        )

        return self._api.create(request)


class ManagementAPI:
    """Management API interface.

    Provides methods for managing AI Gateway resources like upstreams,
    pools, API keys, and viewing usage.

    Note:
        Management APIs require JWT authentication (via `agv login`).
        Gateway keys (cr_xxx) cannot be used for management.
    """

    def __init__(self, api: AIGatewayAPI):
        """Initialize management API interface.

        Args:
            api: Underlying AI Gateway API client
        """
        self._api = api

    # -------------------------------------------------------------------------
    # Upstreams
    # -------------------------------------------------------------------------

    def list_upstreams(self) -> list[GatewayUpstream]:
        """List all upstream providers.

        Returns:
            List of upstream configurations
        """
        return self._api.list_upstreams()

    def create_upstream(
        self,
        name: str,
        provider: str,
        api_key: str,
        base_url: str | None = None,
        rate_limit_rpm: int | None = None,
        rate_limit_tpm: int | None = None,
        priority: int = 0,
        weight: int = 1,
    ) -> GatewayUpstream:
        """Create a new upstream provider.

        Args:
            name: Display name for the upstream
            provider: Provider type (openai, anthropic, etc.)
            api_key: API key for the provider
            base_url: Custom base URL
            rate_limit_rpm: Rate limit (requests per minute)
            rate_limit_tpm: Rate limit (tokens per minute)
            priority: Priority for selection
            weight: Weight for load balancing

        Returns:
            Created upstream
        """
        return self._api.create_upstream(
            name=name,
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            rate_limit_rpm=rate_limit_rpm,
            rate_limit_tpm=rate_limit_tpm,
            priority=priority,
            weight=weight,
        )

    def delete_upstream(self, upstream_id: str) -> None:
        """Delete an upstream provider.

        Args:
            upstream_id: Upstream ID to delete
        """
        self._api.delete_upstream(upstream_id)

    def test_upstream(self, upstream_id: str) -> dict[str, Any]:
        """Test upstream connectivity.

        Args:
            upstream_id: Upstream ID to test

        Returns:
            Test result with success status and latency
        """
        return self._api.test_upstream(upstream_id)

    # -------------------------------------------------------------------------
    # Pools
    # -------------------------------------------------------------------------

    def list_pools(self) -> list[GatewayPool]:
        """List all pools.

        Returns:
            List of pools
        """
        return self._api.list_pools()

    def create_pool(
        self,
        name: str,
        strategy: str = "round-robin",
        model_mappings: dict[str, str] | None = None,
    ) -> GatewayPool:
        """Create a new pool.

        Args:
            name: Pool name
            strategy: Selection strategy
            model_mappings: Model alias mappings

        Returns:
            Created pool
        """
        return self._api.create_pool(name, strategy, model_mappings)

    def delete_pool(self, pool_id: str) -> None:
        """Delete a pool.

        Args:
            pool_id: Pool ID to delete
        """
        self._api.delete_pool(pool_id)

    def add_pool_member(
        self,
        pool_id: str,
        upstream_id: str | None = None,
        priority: int = 0,
        weight: int = 1,
        *,
        source_type: str = "upstream",
        platform_model_id: str | None = None,
    ) -> dict[str, Any]:
        """Add member to pool.

        Args:
            pool_id: Pool ID
            upstream_id: Upstream ID to add
            priority: Member priority
            weight: Member weight
            source_type: Member source type (`upstream` or `platform`)
            platform_model_id: Platform model ID when `source_type="platform"`

        Returns:
            Updated pool
        """
        return self._api.add_pool_member(
            pool_id,
            upstream_id=upstream_id,
            priority=priority,
            weight=weight,
            source_type=source_type,
            platform_model_id=platform_model_id,
        )

    def remove_pool_member(self, pool_id: str, upstream_id: str) -> dict[str, Any]:
        """Remove an upstream member from a pool."""
        return self._api.remove_pool_member(pool_id, upstream_id)

    def remove_platform_pool_member(self, pool_id: str, platform_model_id: str) -> dict[str, Any]:
        """Remove a platform-model member from a pool."""
        return self._api.remove_platform_pool_member(pool_id, platform_model_id)

    # -------------------------------------------------------------------------
    # API Keys
    # -------------------------------------------------------------------------

    def list_keys(self) -> list[GatewayApiKey]:
        """List all API keys.

        Returns:
            List of API keys
        """
        return self._api.list_keys()

    def create_key(
        self,
        name: str,
        daily_limit: float | None = None,
        monthly_limit: float | None = None,
        total_limit: float | None = None,
        allowed_models: list[str] | None = None,
        blocked_models: list[str] | None = None,
        allowed_providers: list[str] | None = None,
    ) -> GatewayApiKey:
        """Create a new API key.

        Args:
            name: Key name
            daily_limit: Daily spending limit (USD)
            monthly_limit: Monthly spending limit (USD)
            total_limit: Total spending limit (USD)
            allowed_models: List of allowed model IDs
            blocked_models: List of blocked model IDs
            allowed_providers: List of allowed provider types

        Returns:
            Created key (includes actual key string - save it!)
        """
        request = CreateGatewayApiKeyRequest(
            name=name,
            daily_limit=daily_limit,
            monthly_limit=monthly_limit,
            total_limit=total_limit,
            allowed_models=allowed_models,
            blocked_models=blocked_models,
            allowed_providers=allowed_providers,
        )
        return self._api.create_key(request)

    def revoke_key(self, key_id: str) -> None:
        """Revoke an API key.

        Args:
            key_id: Key ID to revoke
        """
        self._api.revoke_key(key_id)

    # -------------------------------------------------------------------------
    # Discovery
    # -------------------------------------------------------------------------

    def list_providers(self) -> dict[str, Any]:
        """List supported gateway providers."""
        return self._api.list_providers()

    def list_platform_models(self) -> dict[str, Any]:
        """List platform models grouped by provider."""
        return self._api.list_platform_models()

    # -------------------------------------------------------------------------
    # Usage
    # -------------------------------------------------------------------------

    def get_usage(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        upstream_id: str | None = None,
        api_key_id: str | None = None,
        provider_type: str | None = None,
        model: str | None = None,
        limit: int | None = None,
    ) -> GatewayUsageReport:
        """Get usage report.

        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            upstream_id: Filter by upstream
            api_key_id: Filter by API key
            provider_type: Filter by provider type
            model: Filter by model ID
            limit: Maximum number of records to return

        Returns:
            Usage report
        """
        return self._api.get_usage(
            start_date=start_date,
            end_date=end_date,
            upstream_id=upstream_id,
            api_key_id=api_key_id,
            provider_type=provider_type,
            model=model,
            limit=limit,
        )
