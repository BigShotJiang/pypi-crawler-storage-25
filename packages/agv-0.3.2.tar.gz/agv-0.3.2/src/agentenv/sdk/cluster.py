"""High-level helpers for Ray/Spark clusters."""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from threading import Lock
from typing import Any, Optional, Callable, TypeVar, Generic

from ..api.client import Client as ApiClient
from ..api.cluster import ClusterAPI
from ..config.settings import get_settings


def _cluster_client(
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> ClusterAPI:
    settings = get_settings()
    base_url = api_url or settings.api_url
    key = api_key or settings.api_key
    token = access_token or settings.access_token
    return ClusterAPI(ApiClient(base_url=base_url, api_key=key, access_token=token))


def create_ray_cluster(
    *,
    shape: str,
    workspace_id: str | None = None,
    name: str | None = None,
    image: str | None = None,
    snapshot_id: str | None = None,
    allow_cidr: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> dict[str, Any]:
    """Create a Ray cluster through the existing cluster API."""
    settings = get_settings()
    resolved_workspace_id = workspace_id or settings.workspace
    if not resolved_workspace_id:
        raise RuntimeError("workspace_id is required (or set default workspace via config)")
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.create_ray_cluster(
        workspace_id=resolved_workspace_id,
        shape=shape,
        name=name,
        image=image,
        snapshot_id=snapshot_id,
        allow_cidr=allow_cidr,
    )


def create_spark_cluster(
    *,
    shape: str,
    workspace_id: str | None = None,
    name: str | None = None,
    image: str | None = None,
    snapshot_id: str | None = None,
    allow_cidr: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> dict[str, Any]:
    """Create a Spark cluster through the existing cluster API."""
    settings = get_settings()
    resolved_workspace_id = workspace_id or settings.workspace
    if not resolved_workspace_id:
        raise RuntimeError("workspace_id is required (or set default workspace via config)")
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.create_spark_cluster(
        workspace_id=resolved_workspace_id,
        shape=shape,
        name=name,
        image=image,
        snapshot_id=snapshot_id,
        allow_cidr=allow_cidr,
    )


def list_clusters(
    *,
    workspace_id: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> list[dict[str, Any]]:
    """List clusters using the existing backend-supported endpoint."""
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.list_clusters(workspace_id=workspace_id)


def get_cluster(
    cluster_id: str,
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> dict[str, Any]:
    """Get a cluster by id."""
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.get_cluster(cluster_id)


def stop_cluster(
    cluster_id: str,
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> dict[str, Any]:
    """Stop a cluster through the existing backend-supported endpoint."""
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.stop_cluster(cluster_id)


def wait_for_cluster(
    cluster_id: str,
    *,
    timeout: int = 600,
    target_status: str | None = None,
    terminal_statuses: set[str] | None = None,
    poll_interval: float = 2.0,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> dict[str, Any]:
    """Wait for a cluster using the existing backend-supported polling endpoint."""
    api = _cluster_client(api_url=api_url, api_key=api_key, access_token=access_token)
    return api.wait_for_cluster(
        cluster_id,
        timeout=timeout,
        target_status=target_status,
        terminal_statuses=terminal_statuses,
        poll_interval=poll_interval,
    )


def _wait_cluster_ready(api: ClusterAPI, cluster_id: str, timeout_s: int) -> dict[str, Any]:
    deadline = time.time() + timeout_s
    last = None
    while time.time() < deadline:
        last = api.get_cluster(cluster_id)
        status = str(last.get("status", "")).lower()
        if status == "running":
            return last
        if status == "failed":
            raise RuntimeError(f"Cluster failed: {last.get('metadata', {}).get('failureReason', 'unknown')}")
        time.sleep(2)
    raise RuntimeError(f"Timed out waiting for cluster to be ready (last status={last.get('status')})")


_UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


def _resolve_cluster_image(image: Any | None) -> tuple[str | None, str | None]:
    if image is None:
        return None, None
    if not isinstance(image, str):
        image = getattr(image, "id", None)
        if not image:
            raise RuntimeError("image must be a string or an object with an id attribute")
    if image.startswith("snapshot://"):
        return None, image.split("snapshot://", 1)[1]
    if image.startswith("snapshot:"):
        return None, image.split("snapshot:", 1)[1]
    if _UUID_RE.match(image):
        return None, image
    return image, None


@dataclass
class RayClusterHandle:
    cluster_id: str
    ray_address: str
    ray_auth_token: Optional[str]
    api: ClusterAPI

    def close(self, stop_cluster: bool = False) -> None:
        if stop_cluster:
            self.api.stop_cluster(self.cluster_id)


@dataclass
class SparkClusterHandle:
    cluster_id: str
    spark_remote: str
    api: ClusterAPI

    def close(self, stop_cluster: bool = False) -> None:
        if stop_cluster:
            self.api.stop_cluster(self.cluster_id)

@dataclass
class RayCluster:
    """A connected Ray Client session backed by an AgentEnv-managed cluster."""

    handle: RayClusterHandle
    ray: Any
    context: Any

    @property
    def address(self) -> str:
        return self.handle.ray_address

    @property
    def cluster_id(self) -> str:
        return self.handle.cluster_id

    def close(self, stop_cluster: bool = False) -> None:
        try:
            # Best-effort; ray may already be shutdown.
            self.ray.shutdown()
        except Exception:
            pass
        self.handle.close(stop_cluster=stop_cluster)

    def __enter__(self) -> "RayCluster":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close(stop_cluster=False)


@dataclass
class SparkCluster:
    """A Spark Connect session backed by an AgentEnv-managed cluster.

    This object forwards attribute access to the underlying SparkSession so it can
    be used like a regular Spark session in user code.
    """

    handle: SparkClusterHandle
    session: Any

    @property
    def remote(self) -> str:
        return self.handle.spark_remote

    @property
    def cluster_id(self) -> str:
        return self.handle.cluster_id

    def close(self, stop_cluster: bool = False) -> None:
        try:
            self.session.stop()
        except Exception:
            pass
        self.handle.close(stop_cluster=stop_cluster)

    def stop(self, stop_cluster: bool = False) -> None:
        """Stop SparkSession and optionally stop the cluster (alias for close)."""
        self.close(stop_cluster=stop_cluster)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.session, name)

    def __enter__(self) -> "SparkCluster":
        return self

    def __exit__(self, *_args: Any) -> None:
        self.close(stop_cluster=False)


def ray_init(
    shape: str,
    workspace_id: Optional[str] = None,
    name: Optional[str] = None,
    image: Optional[str] = None,
    snapshot_id: Optional[str] = None,
    allow_cidr: Optional[str] = None,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    access_token: Optional[str] = None,
    local_port: int = 10001,
    wait_timeout_s: int = 600,
    connect: bool = True,
    **ray_init_kwargs: Any,
) -> RayCluster | RayClusterHandle:
    settings = get_settings()
    base_url = api_url or settings.api_url
    key = api_key or settings.api_key
    token = access_token or settings.access_token
    if not workspace_id:
        if not settings.workspace:
            raise RuntimeError("workspace_id is required (or set default workspace via config)")
        workspace_id = settings.workspace

    # Cluster creation can block while waiting for the head node to become RUNNING.
    # Use a larger HTTP timeout than the generic CLI default to avoid client-side timeouts.
    api_timeout_s = max(240.0, float(wait_timeout_s) + 30.0)
    api_client = ApiClient(base_url=base_url, api_key=key, access_token=token, timeout=api_timeout_s)
    api = ClusterAPI(api_client)

    _ = local_port  # Back-compat: previously used for the local tunnel port.
    resolved_image, inferred_snapshot = _resolve_cluster_image(image)
    if snapshot_id and inferred_snapshot and snapshot_id != inferred_snapshot:
        raise RuntimeError("Provide either image or snapshot_id, not both")
    snapshot_id = snapshot_id or inferred_snapshot

    cluster = api.create_ray_cluster(
        workspace_id=workspace_id,
        shape=shape,
        name=name,
        image=resolved_image,
        snapshot_id=snapshot_id,
        allow_cidr=allow_cidr,
    )
    cluster_id = cluster["id"]

    cluster = _wait_cluster_ready(api, cluster_id, timeout_s=wait_timeout_s)
    meta = cluster.get("metadata") or {}
    ray_address = meta.get("rayAddress")
    ray_auth_token = meta.get("rayAuthToken")
    if not ray_address:
        raise RuntimeError("Cluster is running but missing metadata.rayAddress")

    handle = RayClusterHandle(
        cluster_id=cluster_id,
        ray_address=str(ray_address),
        ray_auth_token=str(ray_auth_token) if ray_auth_token else None,
        api=api,
    )

    if not connect:
        return handle

    try:
        import ray  # type: ignore
    except Exception as e:
        handle.close(stop_cluster=False)
        raise RuntimeError(
            "Ray is not installed (or failed to import). Install it with `pip install ray` "
            "or call `agentenv.ray_init(..., connect=False)` to only create the cluster."
        ) from e

    try:
        if handle.ray_auth_token:
            os.environ.setdefault("RAY_AUTH_MODE", "token")
            os.environ["RAY_AUTH_TOKEN"] = handle.ray_auth_token
        context = ray.init(address=handle.ray_address, **ray_init_kwargs)
    except Exception:
        handle.close(stop_cluster=False)
        raise
    return RayCluster(handle=handle, ray=ray, context=context)


_RAY_REMOTE_CACHE: dict[tuple[str, str | None, str | None, str, str], RayCluster] = {}
_RAY_REMOTE_LOCK = Lock()
T = TypeVar("T")


class LazyRayRemote(Generic[T]):
    """Lazy Ray remote wrapper that starts an AgentEnv Ray cluster on first use."""

    def __init__(
        self,
        target: T,
        shape: str,
        *,
        image: str | None = None,
        workspace_id: str | None = None,
        name: str | None = None,
        api_url: str | None = None,
        api_key: str | None = None,
        access_token: str | None = None,
        reuse: bool = True,
        wait_timeout_s: int = 600,
        local_port: int = 10001,
        ray_init_kwargs: dict[str, Any] | None = None,
        ray_remote_kwargs: dict[str, Any] | None = None,
    ):
        self._target = target
        self._shape = shape
        self._image = image
        self._workspace_id = workspace_id
        self._name = name
        self._api_url = api_url
        self._api_key = api_key
        self._access_token = access_token
        self._reuse = reuse
        self._wait_timeout_s = wait_timeout_s
        self._local_port = local_port
        self._ray_init_kwargs = ray_init_kwargs or {}
        self._ray_remote_kwargs = ray_remote_kwargs or {}
        self._cluster: RayCluster | None = None
        self._remote_obj: Any | None = None
        self._cache_key: tuple[str, str | None, str | None, str, str] | None = None

    def _ensure(self) -> None:
        if self._remote_obj is not None:
            return

        settings = get_settings()
        workspace_id = self._workspace_id or settings.workspace
        if not workspace_id:
            raise RuntimeError("workspace_id is required (or set default workspace via config)")

        image_value = self._image
        if image_value is not None and hasattr(image_value, "finalize"):
            try:
                enable_ray = getattr(image_value, "enable_ray", None)
                if callable(enable_ray):
                    enable_ray()
                image_obj = image_value.finalize()
            except Exception as exc:
                raise RuntimeError(f"Failed to build Ray image: {exc}") from exc
            image_value = getattr(image_obj, "id", image_obj)
            self._image = image_value

        resolved_image, resolved_snapshot = _resolve_cluster_image(image_value)
        api_url = self._api_url or settings.api_url
        key = (self._shape, resolved_image, resolved_snapshot, workspace_id, api_url)
        self._cache_key = key
        cluster: RayCluster | None = None

        if self._reuse:
            with _RAY_REMOTE_LOCK:
                cluster = _RAY_REMOTE_CACHE.get(key)

        if cluster is None:
            cluster = ray_init(
                self._shape,
                workspace_id=workspace_id,
                name=self._name,
                image=resolved_image,
                snapshot_id=resolved_snapshot,
                api_url=api_url,
                api_key=self._api_key,
                access_token=self._access_token,
                local_port=self._local_port,
                wait_timeout_s=self._wait_timeout_s,
                connect=True,
                **self._ray_init_kwargs,
            )
            if self._reuse:
                with _RAY_REMOTE_LOCK:
                    _RAY_REMOTE_CACHE[key] = cluster

        self._cluster = cluster
        self._remote_obj = cluster.ray.remote(**self._ray_remote_kwargs)(self._target)

    @property
    def cluster(self) -> RayCluster:
        self._ensure()
        assert self._cluster is not None
        return self._cluster

    def remote(self, *args: Any, **kwargs: Any) -> Any:
        self._ensure()
        return self._remote_obj.remote(*args, **kwargs)

    def options(self, **options: Any) -> Any:
        self._ensure()
        return self._remote_obj.options(**options)

    def close(self, stop_cluster: bool = False) -> None:
        cluster = self._cluster
        if cluster:
            cluster.close(stop_cluster=stop_cluster)
        if self._reuse and self._cache_key:
            with _RAY_REMOTE_LOCK:
                cached = _RAY_REMOTE_CACHE.get(self._cache_key)
                if cached is cluster:
                    _RAY_REMOTE_CACHE.pop(self._cache_key, None)
        self._cluster = None
        self._remote_obj = None
        self._cache_key = None

    def __getattr__(self, name: str) -> Any:
        self._ensure()
        return getattr(self._remote_obj, name)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self.remote(*args, **kwargs)


def remote(
    shape: str,
    *,
    image: str | None = None,
    workspace_id: str | None = None,
    name: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
    reuse: bool = True,
    wait_timeout_s: int = 600,
    local_port: int = 10001,
    ray_init_kwargs: dict[str, Any] | None = None,
    **ray_remote_kwargs: Any,
) -> Callable[[T], LazyRayRemote[T]]:
    """Syntax sugar for lazily starting a Ray cluster and applying ray.remote.

    Example:
        @agentenv.remote("8x8xH100", image="docker://my-image")
        def f(x):
            return x * 2

    Notes:
        - `image` can be a docker reference, an AgentEnv image snapshot ID, an ImageSnapshot,
          or an ImageBuilder (not finalized). Builders will be finalized after enable_ray().
        - `shape` uses "<workers>x<gpusPerWorker>x<gpuType>" (e.g. 8x8xH100 means 8 worker nodes).
    """

    def decorator(target: T) -> LazyRayRemote[T]:
        return LazyRayRemote(
            target,
            shape,
            image=image,
            workspace_id=workspace_id,
            name=name,
            api_url=api_url,
            api_key=api_key,
            access_token=access_token,
            reuse=reuse,
            wait_timeout_s=wait_timeout_s,
            local_port=local_port,
            ray_init_kwargs=ray_init_kwargs,
            ray_remote_kwargs=ray_remote_kwargs,
        )

    return decorator


def spark_init(
    shape: str,
    workspace_id: Optional[str] = None,
    name: Optional[str] = None,
    image: Optional[str] = None,
    snapshot_id: Optional[str] = None,
    allow_cidr: Optional[str] = None,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    access_token: Optional[str] = None,
    local_port: int = 15002,
    wait_timeout_s: int = 600,
    connect: bool = True,
) -> SparkCluster | SparkClusterHandle:
    settings = get_settings()
    base_url = api_url or settings.api_url
    key = api_key or settings.api_key
    token = access_token or settings.access_token
    if not workspace_id:
        if not settings.workspace:
            raise RuntimeError("workspace_id is required (or set default workspace via config)")
        workspace_id = settings.workspace

    # Cluster creation can block while waiting for the head node to become RUNNING.
    # Use a larger HTTP timeout than the generic CLI default to avoid client-side timeouts.
    api_timeout_s = max(240.0, float(wait_timeout_s) + 30.0)
    api_client = ApiClient(base_url=base_url, api_key=key, access_token=token, timeout=api_timeout_s)
    api = ClusterAPI(api_client)

    _ = local_port  # Back-compat: previously used for the local tunnel port.
    resolved_image, inferred_snapshot = _resolve_cluster_image(image)
    if snapshot_id and inferred_snapshot and snapshot_id != inferred_snapshot:
        raise RuntimeError("Provide either image or snapshot_id, not both")
    snapshot_id = snapshot_id or inferred_snapshot

    cluster = api.create_spark_cluster(
        workspace_id=workspace_id,
        shape=shape,
        name=name,
        image=resolved_image,
        snapshot_id=snapshot_id,
        allow_cidr=allow_cidr,
    )
    cluster_id = cluster["id"]

    cluster = _wait_cluster_ready(api, cluster_id, timeout_s=wait_timeout_s)
    meta = cluster.get("metadata") or {}
    spark_remote = meta.get("sparkRemote")
    if not spark_remote:
        raise RuntimeError("Cluster is running but missing metadata.sparkRemote")

    handle = SparkClusterHandle(
        cluster_id=cluster_id,
        spark_remote=str(spark_remote),
        api=api,
    )

    if not connect:
        return handle

    try:
        from pyspark.sql import SparkSession  # type: ignore
    except Exception as e:
        handle.close(stop_cluster=False)
        raise RuntimeError(
            "PySpark is not installed (or failed to import). Install it with `pip install pyspark` "
            "or call `agentenv.spark_init(..., connect=False)` to only create the cluster."
        ) from e

    builder = SparkSession.builder
    if not hasattr(builder, "remote"):
        handle.close(stop_cluster=False)
        raise RuntimeError(
            "This PySpark version does not support Spark Connect (`SparkSession.builder.remote`). "
            "Upgrade PySpark (Spark 3.4+), or call `agentenv.spark_init(..., connect=False)` and use "
            "a compatible client to connect to the returned `spark_remote`."
        )

    try:
        session = builder.remote(handle.spark_remote).getOrCreate()
    except Exception:
        handle.close(stop_cluster=False)
        raise
    return SparkCluster(handle=handle, session=session)
