"""Billing API client."""

from typing import Any

from .client import Client
from .models import Transaction, BalanceInfo


class BillingAPI:
    """API client for billing resources."""

    def __init__(self, client: Client):
        """Initialize billing API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def get_balance(self, workspace_id: str) -> BalanceInfo:
        """Get the account-first balance for a workspace billing context.

        Args:
            workspace_id: Workspace ID

        Returns:
            Balance information keyed by billing account
        """
        response = self.client.get(f"/v1/workspaces/{workspace_id}/billing/balance")
        return BalanceInfo(**response.json())

    def list_billing_accounts(self) -> list[dict[str, Any]]:
        """List billing accounts owned by the current user."""
        response = self.client.get("/v1/billing-accounts")
        data = response.json()
        return data if isinstance(data, list) else []

    def get_billing_account(self, billing_account_id: str) -> dict[str, Any]:
        """Get one owned billing account."""
        response = self.client.get(f"/v1/billing-accounts/{billing_account_id}")
        return response.json()

    def get_billing_account_balance(self, billing_account_id: str) -> BalanceInfo:
        """Get the balance for one owned billing account."""
        response = self.client.get(f"/v1/billing-accounts/{billing_account_id}/balance")
        return BalanceInfo(**response.json())

    def get_billing_account_transactions(
        self,
        billing_account_id: str,
        *,
        page: int = 1,
        limit: int = 50,
        start_date: str | None = None,
        end_date: str | None = None,
        include_types: list[str] | None = None,
        exclude_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Get paginated transaction history for one owned billing account."""
        params: dict[str, Any] = {"page": page, "limit": limit}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        if include_types:
            params["includeTypes"] = include_types
        if exclude_types:
            params["excludeTypes"] = exclude_types

        response = self.client.get(
            f"/v1/billing-accounts/{billing_account_id}/transactions",
            params=params,
        )
        data = response.json()

        if isinstance(data, dict):
            transactions = data.get("transactions", [])
            return {
                "transactions": [Transaction(**item) for item in transactions],
                "total": data.get("total", len(transactions)),
                "page": data.get("page", page),
                "limit": data.get("limit", limit),
            }

        if isinstance(data, list):
            return {
                "transactions": [Transaction(**item) for item in data],
                "total": len(data),
                "page": page,
                "limit": limit,
            }

        return {"transactions": [], "total": 0, "page": page, "limit": limit}

    def get_transactions(
        self,
        workspace_id: str,
        *,
        page: int = 1,
        limit: int = 50,
        start_date: str | None = None,
        end_date: str | None = None,
        include_types: list[str] | None = None,
        exclude_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Get paginated account-first transaction history for a workspace billing context.

        Args:
            workspace_id: Workspace ID

        Returns:
            Transactions plus pagination metadata
        """
        params: dict[str, Any] = {"page": page, "limit": limit}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        if include_types:
            params["includeTypes"] = include_types
        if exclude_types:
            params["excludeTypes"] = exclude_types

        response = self.client.get(
            f"/v1/workspaces/{workspace_id}/billing/transactions",
            params=params,
        )
        data = response.json()

        if isinstance(data, dict):
            transactions = data.get("transactions", [])
            return {
                "transactions": [Transaction(**item) for item in transactions],
                "total": data.get("total", len(transactions)),
                "page": data.get("page", page),
                "limit": data.get("limit", limit),
            }

        if isinstance(data, list):
            return {
                "transactions": [Transaction(**item) for item in data],
                "total": len(data),
                "page": page,
                "limit": limit,
            }

        return {"transactions": [], "total": 0, "page": page, "limit": limit}
