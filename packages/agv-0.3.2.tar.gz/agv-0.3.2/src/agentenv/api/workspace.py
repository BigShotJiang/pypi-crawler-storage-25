"""Workspace API client."""

from typing import Any

from .client import Client
from .models import Workspace, WorkspaceDetail, WorkspaceMember


class WorkspaceAPI:
    """API client for workspace resources."""

    def __init__(self, client: Client):
        """Initialize workspace API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def create(self, name: str) -> Workspace:
        """Create a new workspace.

        Args:
            name: Workspace name

        Returns:
            Created workspace
        """
        response = self.client.post("/v1/workspaces/", json={"name": name})
        return Workspace(**response.json())

    def list_all(
        self,
        page: int = 1,
        limit: int = 100,
    ) -> list[Workspace]:
        """List workspaces for the current user.

        Args:
            page: Page number (default: 1)
            limit: Items per page (default: 100)

        Returns:
            List of workspaces
        """
        params: dict[str, Any] = {"page": page, "limit": limit}
        response = self.client.get("/v1/workspaces/", params=params)
        data = response.json()

        # Handle paginated response: { workspaces: [...], total, page, limit }
        if isinstance(data, dict) and "workspaces" in data:
            return [Workspace(**item) for item in data["workspaces"]]

        # Handle direct list response (fallback)
        if isinstance(data, list):
            return [Workspace(**item) for item in data]

        return []

    def get(self, workspace_id: str) -> WorkspaceDetail:
        """Get workspace details.

        Args:
            workspace_id: Workspace ID

        Returns:
            Workspace details
        """
        response = self.client.get(f"/v1/workspaces/{workspace_id}")
        return WorkspaceDetail(**response.json())

    def update(self, workspace_id: str, data: dict[str, Any]) -> Workspace:
        """Update workspace.

        Args:
            workspace_id: Workspace ID
            data: Update data

        Returns:
            Updated workspace
        """
        response = self.client.put(f"/v1/workspaces/{workspace_id}", json=data)
        return Workspace(**response.json())

    def delete(self, workspace_id: str) -> None:
        """Delete a workspace.

        Args:
            workspace_id: Workspace ID
        """
        self.client.delete(f"/v1/workspaces/{workspace_id}")

    def invite_member(
        self,
        workspace_id: str,
        identifier: str,
        role: str | None = None,
    ) -> dict[str, Any]:
        """Invite a member to the workspace.

        Args:
            workspace_id: Workspace ID
            identifier: Member email or user ID
            role: Optional workspace role

        Returns:
            Invitation response
        """
        payload: dict[str, Any] = {"identifier": identifier}
        if role is not None:
            payload["role"] = role
        response = self.client.post(
            f"/v1/workspaces/{workspace_id}/members",
            json=payload,
        )
        return response.json()

    def join(self, join_code: str) -> Workspace:
        """Join a workspace via join code.

        Args:
            join_code: Workspace join code

        Returns:
            Joined workspace
        """
        response = self.client.post(
            "/v1/workspaces/join",
            json={"joinCode": join_code},
        )
        return Workspace(**response.json())

    def remove_member(self, workspace_id: str, user_id: str) -> None:
        """Remove a member from the workspace.

        Args:
            workspace_id: Workspace ID
            user_id: User ID to remove
        """
        self.client.delete(f"/v1/workspaces/{workspace_id}/members/{user_id}")

    def get_members(self, workspace_id: str) -> list[WorkspaceMember]:
        """Get workspace members.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of members
        """
        workspace = self.get(workspace_id)
        return workspace.members

    def get_default_billing_account_id(self, workspace_id: str) -> str | None:
        """Get the default billing account ID for a workspace."""
        workspace = self.get(workspace_id)
        return workspace.default_billing_account_id

    # Secret management

    def create_secret(
        self,
        workspace_id: str,
        key: str,
        value: str,
    ) -> dict[str, Any]:
        """Create a workspace secret.

        Args:
            workspace_id: Workspace ID
            key: Secret key
            value: Secret value

        Returns:
            Created secret
        """
        response = self.client.post(
            f"/v1/workspaces/{workspace_id}/secrets/",
            json={"key": key, "value": value},
        )
        return response.json()

    def list_secrets(self, workspace_id: str) -> list[dict[str, Any]]:
        """List workspace secrets (metadata only, no values).

        Args:
            workspace_id: Workspace ID

        Returns:
            List of secret metadata
        """
        response = self.client.get(f"/v1/workspaces/{workspace_id}/secrets/")
        return response.json()

    def delete_secret(self, workspace_id: str, secret_id: str) -> None:
        """Delete a workspace secret.

        Args:
            workspace_id: Workspace ID
            secret_id: Secret ID
        """
        self.client.delete(f"/v1/workspaces/{workspace_id}/secrets/{secret_id}")

    def update_secret(
        self,
        workspace_id: str,
        secret_id: str,
        *,
        key: str | None = None,
        value: str | None = None,
    ) -> dict[str, Any]:
        """Update a workspace secret.

        Args:
            workspace_id: Workspace ID
            secret_id: Secret ID
            key: New secret key
            value: New secret value

        Returns:
            Updated secret
        """
        payload: dict[str, Any] = {}
        if key is not None:
            payload["key"] = key
        if value is not None:
            payload["value"] = value
        response = self.client.patch(
            f"/v1/workspaces/{workspace_id}/secrets/{secret_id}",
            json=payload,
        )
        return response.json()
