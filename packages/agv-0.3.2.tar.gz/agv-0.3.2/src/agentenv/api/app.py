"""App deployment API client."""

from typing import Any

from .client import Client
from .models import App, AppVersion, CreateAppRequest


def extract_app_log_entries(payload: Any) -> list[dict[str, str | None]]:
    """Normalize app log payloads into structured entries."""
    if isinstance(payload, dict):
        raw_entries = payload.get("entries")
        if isinstance(raw_entries, list) and raw_entries:
            entries: list[dict[str, str | None]] = []
            for raw in raw_entries:
                if isinstance(raw, dict):
                    message = raw.get("message")
                    if message is None:
                        continue
                    timestamp = raw.get("timestamp")
                    log_path = raw.get("logPath")
                    entries.append(
                        {
                            "message": str(message),
                            "timestamp": str(timestamp) if timestamp is not None else None,
                            "logPath": str(log_path) if log_path is not None else None,
                        }
                    )
                elif raw is not None:
                    entries.append(
                        {
                            "message": str(raw),
                            "timestamp": None,
                            "logPath": None,
                        }
                    )
            if entries:
                return entries

        raw_logs = payload.get("logs")
        if isinstance(raw_logs, list):
            return [
                {"message": str(log), "timestamp": None, "logPath": None}
                for log in raw_logs
                if log is not None
            ]

        message = payload.get("message")
        if message is not None:
            return [{"message": str(message), "timestamp": None, "logPath": None}]

    if isinstance(payload, list):
        return [
            {"message": str(item), "timestamp": None, "logPath": None}
            for item in payload
            if item is not None
        ]

    if isinstance(payload, str) and payload:
        return [{"message": payload, "timestamp": None, "logPath": None}]

    return []


def format_app_log_entry(entry: dict[str, str | None]) -> str:
    """Render one structured log entry for terminal output."""
    timestamp = entry.get("timestamp")
    message = entry.get("message") or ""
    if timestamp:
        return f"{timestamp} {message}"
    return message


class AppAPI:
    """API client for app deployment resources."""

    def __init__(self, client: Client):
        self.client = client

    def create(self, request: dict[str, Any] | CreateAppRequest) -> App:
        if isinstance(request, CreateAppRequest):
            data = request.model_dump(exclude_none=True, by_alias=True)
        else:
            data = request
        response = self.client.post("/v1/apps", json=data)
        return App(**response.json())

    def list_all(self, workspace_id: str | None = None) -> list[App]:
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        response = self.client.get("/v1/apps", params=params)
        data = response.json()
        if isinstance(data, list):
            return [App(**item) for item in data]
        return []

    def get(self, id_or_slug: str) -> App:
        response = self.client.get(f"/v1/apps/{id_or_slug}")
        return App(**response.json())

    def update(self, id_or_slug: str, **kwargs: Any) -> App:
        response = self.client.patch(f"/v1/apps/{id_or_slug}", json=kwargs)
        return App(**response.json())

    def delete(self, id_or_slug: str) -> dict[str, Any]:
        response = self.client.delete(f"/v1/apps/{id_or_slug}")
        if response.content:
            return response.json()
        return {"success": True}

    def deploy(
        self,
        id_or_slug: str,
        snapshot_id: str,
        env_overrides: dict[str, str] | None = None,
        entrypoint_override: str | None = None,
    ) -> AppVersion:
        payload: dict[str, Any] = {"snapshotId": snapshot_id}
        if env_overrides:
            payload["envOverrides"] = env_overrides
        if entrypoint_override:
            payload["entrypointOverride"] = entrypoint_override
        response = self.client.post(f"/v1/apps/{id_or_slug}/deploy", json=payload)
        return AppVersion(**response.json())

    def get_versions(self, id_or_slug: str) -> list[AppVersion]:
        response = self.client.get(f"/v1/apps/{id_or_slug}/versions")
        data = response.json()
        if isinstance(data, list):
            return [AppVersion(**item) for item in data]
        return []

    def rollback(self, id_or_slug: str, version: str) -> AppVersion:
        response = self.client.post(
            f"/v1/apps/{id_or_slug}/rollback",
            json={"version": version},
        )
        return AppVersion(**response.json())

    def get_instances(self, id_or_slug: str) -> list[dict[str, Any]]:
        response = self.client.get(f"/v1/apps/{id_or_slug}/instances")
        data = response.json()
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        return []

    def delete_version(self, id_or_slug: str, version: str) -> None:
        self.client.delete(f"/v1/apps/{id_or_slug}/versions/{version}")

    def logs(
        self,
        id_or_slug: str,
        query: str | None = None,
        limit: int | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
        sort: str | None = None,
        log_path: str | None = None,
        raw: bool = False,
    ) -> Any:
        """Get app logs."""
        params: dict[str, Any] = {}
        if query:
            params["q"] = query
        if limit is not None:
            params["limit"] = limit
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        if sort:
            params["sort"] = sort
        if log_path:
            params["logPath"] = log_path

        response = self.client.get(f"/v1/apps/{id_or_slug}/logs", params=params)

        try:
            data = response.json()
            if raw:
                return data
            entries = extract_app_log_entries(data)
            if entries:
                return "\n".join(format_app_log_entry(entry) for entry in entries)
        except (ValueError, KeyError, TypeError):
            # Return raw text if JSON parsing fails
            pass

        return response.text
