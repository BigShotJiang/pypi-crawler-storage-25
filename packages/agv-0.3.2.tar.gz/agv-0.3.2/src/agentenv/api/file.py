"""File storage API client."""

from typing import Any

from .client import Client
from .models import FileMetadata


class FileAPI:
    """API client for file storage."""

    def __init__(self, client: Client):
        """Initialize file API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def upload(
        self,
        file_path: str,
        workspace_id: str | None = None,
        remote_path: str | None = None,
    ) -> FileMetadata:
        """Upload a file.

        Args:
            file_path: Local file path
            workspace_id: Optional workspace ID
            remote_path: Optional remote path

        Returns:
            File metadata
        """
        import os

        filename = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)

        with open(file_path, "rb") as f:
            files = {"file": (filename, f, "application/octet-stream")}
            params: dict[str, Any] = {}
            if workspace_id:
                params["workspaceId"] = workspace_id
            if remote_path:
                params["path"] = remote_path

            response = self.client.post(
                "/v1/files/upload",
                files=files,
                params=params,
            )

        return FileMetadata(**response.json())

    def list_all(
        self,
        workspace_id: str | None = None,
        path: str | None = None,
    ) -> list[FileMetadata]:
        """List files.

        Args:
            workspace_id: Optional workspace ID
            path: Optional directory path

        Returns:
            List of file metadata
        """
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if path:
            params["path"] = path

        response = self.client.get("/v1/files/", params=params)
        return [FileMetadata(**item) for item in response.json()]

    def list(
        self,
        workspace_id: str | None = None,
        path: str | None = None,
    ) -> list[FileMetadata]:
        """Backward-compatible alias for listing files."""
        return self.list_all(workspace_id=workspace_id, path=path)

    def get_metadata(
        self,
        workspace_id: str | None = None,
        path: str | None = None,
    ) -> FileMetadata:
        """Get file metadata.

        Args:
            workspace_id: Optional workspace ID
            path: File path

        Returns:
            File metadata
        """
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if path:
            params["path"] = path

        response = self.client.get("/v1/files/metadata", params=params)
        return FileMetadata(**response.json())

    def get_content(
        self,
        workspace_id: str | None = None,
        path: str | None = None,
    ) -> bytes:
        """Get file content.

        Args:
            workspace_id: Optional workspace ID
            path: File path

        Returns:
            File content as bytes
        """
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if path:
            params["path"] = path

        response = self.client.get("/v1/files/content", params=params)
        return response.content

    def download(
        self,
        remote_path: str,
        local_path: str,
        workspace_id: str | None = None,
    ) -> None:
        """Download a file.

        Args:
            remote_path: Remote file path
            local_path: Local file path
            workspace_id: Optional workspace ID
        """
        content = self.get_content(workspace_id, remote_path)

        import os

        local_dir = os.path.dirname(local_path)
        if local_dir:
            os.makedirs(local_dir, exist_ok=True)

        with open(local_path, "wb") as f:
            f.write(content)

    def create_directory(
        self,
        path: str,
        workspace_id: str | None = None,
    ) -> FileMetadata:
        """Create a directory.

        Args:
            path: Directory path
            workspace_id: Optional workspace ID

        Returns:
            Directory metadata
        """
        params: dict[str, Any] = {"path": path}
        if workspace_id:
            params["workspaceId"] = workspace_id

        response = self.client.post("/v1/files/directory", params=params)
        return FileMetadata(**response.json())

    def delete(
        self,
        path: str,
        workspace_id: str | None = None,
    ) -> None:
        """Delete a file.

        Args:
            path: File path
            workspace_id: Optional workspace ID
        """
        params: dict[str, Any] = {"path": path}
        if workspace_id:
            params["workspaceId"] = workspace_id

        self.client.delete("/v1/files/", params=params)

    def update_metadata(
        self,
        path: str,
        metadata: dict[str, Any],
        workspace_id: str | None = None,
    ) -> FileMetadata:
        """Update file metadata.

        Args:
            path: File path
            metadata: Metadata to update
            workspace_id: Optional workspace ID

        Returns:
            Updated file metadata
        """
        params: dict[str, Any] = {"path": path}
        if workspace_id:
            params["workspaceId"] = workspace_id

        response = self.client.patch(
            "/v1/files/metadata",
            params=params,
            json={"customMetadata": metadata},
        )
        return FileMetadata(**response.json())
