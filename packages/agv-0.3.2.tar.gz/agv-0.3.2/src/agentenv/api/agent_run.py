"""Agent run API client for the protected-request machine-payment flow."""

from typing import Any

from .client import Client, APIError


class AgentRunAPI:
    """API client for agent run endpoints with machine-payment support."""

    def __init__(self, client: Client):
        self.client = client

    def preflight(
        self,
        *,
        workspace_id: str,
        billing_account_id: str,
        amount_cents: int,
        prompt: str,
    ) -> dict[str, Any]:
        """Validate a paid run request before invoking the protected route."""
        response = self.client.post(
            "/v1/agent/run/preflight",
            json={
                "workspaceId": workspace_id,
                "billingAccountId": billing_account_id,
                "amountCents": amount_cents,
                "prompt": prompt,
            },
        )
        payload = response.json()
        if isinstance(payload, dict):
            return payload
        return {"eligible": False, "amountCents": amount_cents}

    def run(
        self,
        *,
        workspace_id: str,
        billing_account_id: str,
        amount_cents: int,
        idempotency_key: str,
        prompt: str,
        authorization_header: str | None = None,
    ) -> dict[str, Any]:
        """Execute a paid agent run.

        On success returns the business result. On 402, captures the
        challenge response and returns it with a statusCode field.
        """
        request_kwargs: dict[str, Any] = {
            "json": {
                "workspaceId": workspace_id,
                "billingAccountId": billing_account_id,
                "amountCents": amount_cents,
                "idempotencyKey": idempotency_key,
                "prompt": prompt,
            }
        }
        if authorization_header:
            request_kwargs["headers"] = {
                "Authorization": authorization_header,
            }

        try:
            response = self.client.post("/v1/agent/run", **request_kwargs)
            payload = response.json()
            if response.status_code == 202 and isinstance(payload, dict):
                return self._processing_response(payload)
            return payload
        except APIError as exc:
            if exc.status_code == 402 and isinstance(exc.details, dict):
                return self._payment_required_response(exc.details)
            raise

    def _payment_required_response(
        self, details: dict[str, Any]
    ) -> dict[str, Any]:
        """Normalize a 402 API payload without dropping protocol fields."""
        return {**details, "statusCode": 402}

    def _processing_response(self, details: dict[str, Any]) -> dict[str, Any]:
        """Normalize a 202 API payload without dropping protocol fields."""
        return {**details, "statusCode": 202}
