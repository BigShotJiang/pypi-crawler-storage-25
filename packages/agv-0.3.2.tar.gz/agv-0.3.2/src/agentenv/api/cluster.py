"""API client for Ray/Spark clusters."""

from __future__ import annotations

import time
from typing import Any

from .client import Client


class ClusterAPI:
    """API client for compute clusters."""

    def __init__(self, client: Client):
        self.client = client

    def create_ray_cluster(
        self,
        workspace_id: str,
        shape: str,
        name: str | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        allow_cidr: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workspaceId": workspace_id, "shape": shape}
        if name:
            payload["name"] = name
        if image:
            payload["image"] = image
        if snapshot_id:
            payload["snapshotId"] = snapshot_id
        if allow_cidr:
            payload["allowCidr"] = allow_cidr
        resp = self.client.post("/v1/clusters/ray", json=payload)
        return resp.json()

    def create_spark_cluster(
        self,
        workspace_id: str,
        shape: str,
        name: str | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        allow_cidr: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workspaceId": workspace_id, "shape": shape}
        if name:
            payload["name"] = name
        if image:
            payload["image"] = image
        if snapshot_id:
            payload["snapshotId"] = snapshot_id
        if allow_cidr:
            payload["allowCidr"] = allow_cidr
        resp = self.client.post("/v1/clusters/spark", json=payload)
        return resp.json()

    def list_clusters(self, workspace_id: str | None = None) -> list[dict[str, Any]]:
        params = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        resp = self.client.get("/v1/clusters", params=params or None)
        return resp.json()

    def get_cluster(self, cluster_id: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/clusters/{cluster_id}")
        return resp.json()

    def stop_cluster(self, cluster_id: str) -> dict[str, Any]:
        resp = self.client.put(f"/v1/clusters/{cluster_id}/stop")
        return resp.json()

    def wait_for_cluster(
        self,
        cluster_id: str,
        *,
        timeout: int = 600,
        target_status: str | None = None,
        terminal_statuses: set[str] | None = None,
        poll_interval: float = 2.0,
    ) -> dict[str, Any]:
        """Poll cluster status until it reaches the target or a terminal state."""
        deadline = time.time() + timeout
        latest: dict[str, Any] = {"id": cluster_id, "status": "unknown"}
        target = target_status.lower() if target_status else None
        if terminal_statuses is not None:
            terminal = {status.lower() for status in terminal_statuses}
        elif target is not None:
            terminal = {"failed"}
        else:
            terminal = {"running", "failed", "stopped"}

        while time.time() < deadline:
            latest = self.get_cluster(cluster_id)
            state = str(latest.get("status") or "").lower()
            if target and state == target:
                return latest
            if target is None and state in terminal:
                return latest
            if target is not None and state in terminal:
                return latest
            time.sleep(poll_interval)

        raise TimeoutError(
            f"Timed out waiting for cluster {cluster_id} to reach "
            f"{target or 'a terminal state'}"
        )
