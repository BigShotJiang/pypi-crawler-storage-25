"""Sandbox API client."""

from typing import Any

from .client import Client
from .models import (
    Sandbox,
    CreateSandboxRequest,
    ExposePortRequest,
    PortMapping,
    SandboxExecResult,
)


class SandboxAPI:
    """API client for sandbox resources."""

    def __init__(self, client: Client):
        """Initialize sandbox API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    @staticmethod
    def _normalize_port_mapping_data(data: dict[str, Any]) -> dict[str, Any]:
        """Accept mixed snake_case/camelCase port payloads from sandbox APIs."""
        normalized = dict(data)
        field_aliases = {
            "host_port": "hostPort",
            "container_port": "containerPort",
            "host_ip": "hostIp",
            "public_url": "publicUrl",
            "url": "publicUrl",
            "port_type": "protocol",
        }
        for source, target in field_aliases.items():
            if source in normalized and target not in normalized:
                normalized[target] = normalized[source]
        return normalized

    def create(self, request: dict[str, Any] | CreateSandboxRequest) -> Sandbox:
        """Create a new sandbox.

        Args:
            request: Sandbox creation request

        Returns:
            Created sandbox
        """
        if isinstance(request, CreateSandboxRequest):
            data = request.model_dump(exclude_none=True, by_alias=True)
        else:
            data = request

        response = self.client.post("/v1/sandboxes/", json=data)
        return Sandbox(**response.json())

    def list_all(
        self,
        workspace_id: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> list[Sandbox]:
        """List all sandboxes for the current user.

        Args:
            workspace_id: Optional workspace ID filter
            page: Page number (default: 1)
            limit: Items per page (default: 100)

        Returns:
            List of sandboxes
        """
        params: dict[str, Any] = {"page": page, "limit": limit}
        if workspace_id:
            params["workspaceId"] = workspace_id

        response = self.client.get("/v1/sandboxes/", params=params)
        data = response.json()

        # Handle paginated response: { sandboxes: [...], total, page, limit }
        if isinstance(data, dict) and "sandboxes" in data:
            return [Sandbox(**item) for item in data["sandboxes"]]

        # Handle direct list response (fallback)
        if isinstance(data, list):
            return [Sandbox(**item) for item in data]

        return []

    def get(self, sandbox_id: str) -> Sandbox:
        """Get sandbox details.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            Sandbox details
        """
        response = self.client.get(f"/v1/sandboxes/{sandbox_id}")
        return Sandbox(**response.json())

    def update(self, sandbox_id: str, data: dict[str, Any]) -> Sandbox:
        """Update sandbox.

        Args:
            sandbox_id: Sandbox ID
            data: Update data

        Returns:
            Updated sandbox
        """
        response = self.client.put(f"/v1/sandboxes/{sandbox_id}", json=data)
        return Sandbox(**response.json())

    def start(self, sandbox_id: str) -> Sandbox:
        """Start a stopped sandbox.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            Started sandbox
        """
        response = self.client.post(f"/v1/sandboxes/{sandbox_id}/start")
        return Sandbox(**response.json())

    def stop(self, sandbox_id: str) -> Sandbox:
        """Stop a running sandbox.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            Stopped sandbox
        """
        response = self.client.post(f"/v1/sandboxes/{sandbox_id}/stop")
        return Sandbox(**response.json())

    def delete(self, sandbox_id: str) -> None:
        """Delete a sandbox.

        Args:
            sandbox_id: Sandbox ID
        """
        self.client.delete(f"/v1/sandboxes/{sandbox_id}")

    def logs(
        self,
        sandbox_id: str,
        follow: bool = False,
        tail: int | None = None,
    ) -> str:
        """Get sandbox logs.

        Args:
            sandbox_id: Sandbox ID
            follow: Whether to follow logs (not supported for simple GET)
            tail: Number of lines to tail

        Returns:
            Log output as concatenated string
        """
        params: dict[str, Any] = {}
        if follow:
            params["follow"] = "true"
        if tail is not None:
            params["tail"] = tail

        response = self.client.get(
            f"/v1/sandboxes/{sandbox_id}/logs",
            params=params,
        )

        # API returns JSON: {logs: [...], entries: [...], total, timestamp}
        try:
            data = response.json()
            if isinstance(data, dict):
                # Extract logs array if available
                if "logs" in data and data["logs"]:
                    return "\n".join(data["logs"])
                # Extract entries array if available
                if "entries" in data and data["entries"]:
                    return "\n".join(e.get("message", str(e)) for e in data["entries"])
        except Exception:
            pass

        # Fallback to raw text
        return response.text

    def expose_port(
        self,
        sandbox_id: str,
        port: int,
        port_type: str = "tcp",
    ) -> PortMapping:
        """Expose a port on a sandbox.

        Args:
            sandbox_id: Sandbox ID
            port: Container port to expose
            port_type: Port type (tcp, http, ws)

        Returns:
            Port mapping information (first mapping if multiple)
        """
        response = self.client.post(
            f"/v1/sandboxes/{sandbox_id}/ports",
            json={
                "ports": [
                    {
                        "containerPort": port,
                        "protocol": port_type,
                        "portType": port_type,
                    }
                ]
            },
        )
        data = response.json()

        # Handle {mappings: [...]} response
        if isinstance(data, dict) and "mappings" in data:
            mappings = data["mappings"]
            if mappings:
                return PortMapping(**self._normalize_port_mapping_data(mappings[0]))

        # Handle direct PortMapping response (fallback)
        return PortMapping(**self._normalize_port_mapping_data(data))

    def list_ports(
        self,
        sandbox_id: str,
    ) -> list[PortMapping]:
        """List all exposed ports for a sandbox.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            List of port mappings
        """
        response = self.client.get(f"/v1/sandboxes/{sandbox_id}/ports")
        data = response.json()

        # Handle {mappings: [...]} response
        if isinstance(data, dict) and "mappings" in data:
            return [PortMapping(**self._normalize_port_mapping_data(m)) for m in data["mappings"]]

        return []

    def exec(
        self,
        sandbox_id: str,
        command: str,
    ) -> SandboxExecResult:
        """Execute a command in a running sandbox."""
        response = self.client.post(
            f"/v1/sandboxes/{sandbox_id}/exec",
            json={"command": command},
        )
        return SandboxExecResult(**response.json())

    def upload_file(
        self,
        sandbox_id: str,
        local_path: str,
        remote_path: str,
    ) -> dict[str, Any]:
        """Upload a file into a sandbox."""
        with open(local_path, "rb") as f:
            files = {"file": (local_path.split("/")[-1], f)}
            response = self.client.post(
                f"/v1/sandboxes/{sandbox_id}/files",
                params={"path": remote_path},
                files=files,
            )
        return response.json()

    def create_snapshot(
        self,
        sandbox_id: str,
        name: str | None = None,
        with_memory: bool = False,
    ) -> dict[str, Any]:
        """Create a snapshot from a sandbox.

        Args:
            sandbox_id: Sandbox ID
            name: Optional snapshot name
            with_memory: Whether to include memory in snapshot
        Returns:
            Snapshot creation response
        """
        data: dict[str, Any] = {"withMemory": with_memory}
        if name:
            data["name"] = name

        response = self.client.post(
            f"/v1/sandboxes/{sandbox_id}/snapshots",
            json=data,
        )
        return response.json()

    def wait_for_status(
        self,
        sandbox_id: str,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> Sandbox:
        """Wait for sandbox to reach desired status.

        Args:
            sandbox_id: Sandbox ID
            desired_status: Desired status (default: running)
            timeout: Maximum wait time in seconds
            interval: Poll interval in seconds

        Returns:
            Sandbox when desired status is reached

        Raises:
            TimeoutError: If timeout is reached
        """
        import time

        start = time.time()
        while time.time() - start < timeout:
            sandbox = self.get(sandbox_id)
            if sandbox.status == desired_status:
                return sandbox
            if sandbox.status in ("failed", "terminated"):
                raise RuntimeError(f"Sandbox {sandbox_id} failed with status: {sandbox.status}")
            time.sleep(interval)

        raise TimeoutError(f"Timeout waiting for sandbox {sandbox_id} to reach status {desired_status}")

    def extend_ttl(self, sandbox_id: str, additional_seconds: int) -> Sandbox:
        """Extend the TTL of a running sandbox.

        Args:
            sandbox_id: The sandbox ID
            additional_seconds: Number of seconds to add to the TTL

        Returns:
            Updated sandbox info with new expiration
        """
        response = self.client.post(
            f"/v1/sandboxes/{sandbox_id}/extend-ttl",
            json={"additionalSeconds": additional_seconds},
        )
        return Sandbox(**response.json())
