"""Workflow API client."""

from __future__ import annotations

from typing import Any

from .client import Client
from .models import (
    Workflow,
    WorkflowDefinition,
    WorkflowExecution,
    WorkflowMetrics,
    WorkflowNodeDefinition,
    WorkflowNodeDefinitionLight,
    WorkflowTimeSeriesPoint,
)


class WorkflowAPI:
    """API client for workflow resources."""

    def __init__(self, client: Client) -> None:
        self.client = client

    @staticmethod
    def _unwrap_data(response: Any) -> Any:
        payload = response.json()
        if isinstance(payload, dict) and "data" in payload:
            return payload["data"]
        return payload

    @staticmethod
    def _workspace_headers(workspace_id: str) -> dict[str, str]:
        return {"X-Workspace-ID": workspace_id}

    def list_all(
        self,
        workspace_id: str,
        status: str | None = None,
    ) -> list[Workflow]:
        params: dict[str, Any] = {}
        if status:
            params["status"] = status
        response = self.client.get(
            "/workflows",
            headers=self._workspace_headers(workspace_id),
            params=params or None,
        )
        data = self._unwrap_data(response)
        return [Workflow(**item) for item in data] if isinstance(data, list) else []

    def create(
        self,
        workspace_id: str,
        name: str,
        definition: dict[str, Any] | WorkflowDefinition,
        description: str | None = None,
    ) -> Workflow:
        payload: dict[str, Any] = {
            "name": name,
            "definition": (
                definition.model_dump(by_alias=True, exclude_none=True)
                if isinstance(definition, WorkflowDefinition)
                else definition
            ),
        }
        if description is not None:
            payload["description"] = description
        response = self.client.post(
            "/workflows",
            headers=self._workspace_headers(workspace_id),
            json=payload,
        )
        return Workflow(**self._unwrap_data(response))

    def get(self, workflow_id: str) -> Workflow:
        response = self.client.get(f"/workflows/{workflow_id}")
        return Workflow(**self._unwrap_data(response))

    def update(
        self,
        workflow_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        definition: dict[str, Any] | WorkflowDefinition | None = None,
        status: str | None = None,
    ) -> Workflow:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if definition is not None:
            payload["definition"] = (
                definition.model_dump(by_alias=True, exclude_none=True)
                if isinstance(definition, WorkflowDefinition)
                else definition
            )
        if status is not None:
            payload["status"] = status
        response = self.client.put(f"/workflows/{workflow_id}", json=payload)
        return Workflow(**self._unwrap_data(response))

    def delete(self, workflow_id: str) -> dict[str, Any]:
        response = self.client.delete(f"/workflows/{workflow_id}")
        if response.content:
            payload = self._unwrap_data(response)
            return payload if isinstance(payload, dict) else {"success": True}
        return {"success": True}

    def deploy(self, workflow_id: str) -> Workflow:
        response = self.client.post(f"/workflows/{workflow_id}/deploy")
        return Workflow(**self._unwrap_data(response))

    def undeploy(self, workflow_id: str) -> Workflow:
        response = self.client.post(f"/workflows/{workflow_id}/undeploy")
        return Workflow(**self._unwrap_data(response))

    def execute(
        self,
        workflow_id: str,
        *,
        input_data: Any = None,
        trigger_node_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if input_data is not None:
            payload["input"] = input_data
        if trigger_node_id is not None:
            payload["triggerNodeId"] = trigger_node_id
        response = self.client.post(f"/workflows/{workflow_id}/execute", json=payload)
        data = self._unwrap_data(response)
        return data if isinstance(data, dict) else {"value": data}

    def execute_in_memory(
        self,
        workspace_id: str,
        definition: dict[str, Any] | WorkflowDefinition,
        *,
        input_data: Any = None,
        trigger_node_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "definition": (
                definition.model_dump(by_alias=True, exclude_none=True)
                if isinstance(definition, WorkflowDefinition)
                else definition
            ),
        }
        if input_data is not None:
            payload["input"] = input_data
        if trigger_node_id is not None:
            payload["triggerNodeId"] = trigger_node_id
        response = self.client.post(
            "/workflows/execute-in-memory",
            headers=self._workspace_headers(workspace_id),
            json=payload,
        )
        data = self._unwrap_data(response)
        return data if isinstance(data, dict) else {"value": data}

    def list_executions(
        self,
        workflow_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
        status: str | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> tuple[list[WorkflowExecution], dict[str, Any] | None]:
        params: dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if status:
            params["status"] = status
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        response = self.client.get(
            f"/workflows/{workflow_id}/executions",
            params=params or None,
        )
        payload = response.json()
        data = payload.get("data", []) if isinstance(payload, dict) else []
        pagination = payload.get("pagination") if isinstance(payload, dict) else None
        items = [WorkflowExecution(**item) for item in data] if isinstance(data, list) else []
        return items, pagination

    def get_execution(self, workflow_id: str, execution_id: str) -> WorkflowExecution:
        response = self.client.get(f"/workflows/{workflow_id}/executions/{execution_id}")
        return WorkflowExecution(**self._unwrap_data(response))

    def cancel_execution(self, workflow_id: str, execution_id: str) -> dict[str, Any]:
        response = self.client.post(f"/workflows/{workflow_id}/executions/{execution_id}/cancel")
        if response.content:
            payload = self._unwrap_data(response)
            return payload if isinstance(payload, dict) else {"success": True}
        return {"success": True}

    def list_node_definitions(self) -> list[WorkflowNodeDefinitionLight]:
        response = self.client.get("/workflows/node-definitions")
        data = self._unwrap_data(response)
        return (
            [WorkflowNodeDefinitionLight(**item) for item in data]
            if isinstance(data, list)
            else []
        )

    def get_node_definition(self, node_type: str) -> WorkflowNodeDefinition:
        response = self.client.get(f"/workflows/node-definitions/{node_type}")
        return WorkflowNodeDefinition(**self._unwrap_data(response))

    def list_trusted_plugins(self) -> list[str]:
        response = self.client.get("/workflows/plugins/trusted")
        data = self._unwrap_data(response)
        return [str(item) for item in data] if isinstance(data, list) else []

    def get_metrics(
        self,
        workflow_id: str,
        *,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> WorkflowMetrics:
        params: dict[str, Any] = {}
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        response = self.client.get(
            f"/workflows/{workflow_id}/metrics",
            params=params or None,
        )
        return WorkflowMetrics(**self._unwrap_data(response))

    def get_time_series(
        self,
        workflow_id: str,
        *,
        interval: str | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> list[WorkflowTimeSeriesPoint]:
        params: dict[str, Any] = {}
        if interval:
            params["interval"] = interval
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        response = self.client.get(
            f"/workflows/{workflow_id}/metrics/timeseries",
            params=params or None,
        )
        data = self._unwrap_data(response)
        return (
            [WorkflowTimeSeriesPoint(**item) for item in data]
            if isinstance(data, list)
            else []
        )
