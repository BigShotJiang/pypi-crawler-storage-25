"""Analytics API client."""

from typing import Any
from datetime import datetime

from .client import Client
from .models import (
    AnalyticsInstallation,
    AnalyticsFunnel,
    AnalyticsUserProfile,
    AnalyticsEvent,
    CreateAnalyticsInstallationRequest,
    CreateAnalyticsFunnelRequest,
)


class AnalyticsAPI:
    """API client for analytics resources."""

    def __init__(self, client: Client):
        """Initialize analytics API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def create_installation(
        self,
        name: str,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> AnalyticsInstallation:
        """Create a new analytics installation.

        Args:
            name: Installation name
            allowed_domains: Optional list of allowed domains
            settings: Optional settings dictionary

        Returns:
            Created installation
        """
        data = CreateAnalyticsInstallationRequest(
            name=name,
            allowed_domains=allowed_domains,
            settings=settings,
        ).model_dump(mode="json", by_alias=True, exclude_none=True)

        response = self.client.post("/analytics/installations", json=data)
        return AnalyticsInstallation(**response.json())

    def list_installations(self) -> list[AnalyticsInstallation]:
        """List all analytics installations.

        Returns:
            List of installations
        """
        response = self.client.get("/analytics/installations")
        data = response.json()
        if isinstance(data, list):
            return [AnalyticsInstallation(**item) for item in data]
        return []

    def get_installation(self, installation_id: str) -> AnalyticsInstallation:
        """Get installation details.

        Args:
            installation_id: Installation ID

        Returns:
            Installation details
        """
        response = self.client.get(f"/analytics/installations/{installation_id}")
        return AnalyticsInstallation(**response.json())

    def delete_installation(self, installation_id: str) -> None:
        """Delete an installation.

        Args:
            installation_id: Installation ID
        """
        self.client.delete(f"/analytics/installations/{installation_id}")

    def update_installation(
        self,
        installation_id: str,
        name: str | None = None,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> AnalyticsInstallation:
        """Update an installation.

        Args:
            installation_id: Installation ID
            name: Optional installation name
            allowed_domains: Optional list of allowed domains
            settings: Optional settings dictionary

        Returns:
            Updated installation
        """
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if allowed_domains is not None:
            data["allowedDomains"] = allowed_domains
        if settings is not None:
            data["settings"] = settings

        self.client.post(
            f"/analytics/installations/{installation_id}",
            json=data,
        )
        return self.get_installation(installation_id)

    def hide_installation(self, installation_id: str) -> dict[str, Any]:
        """Hide an example installation.

        Args:
            installation_id: Installation ID

        Returns:
            Success payload
        """
        response = self.client.post(f"/analytics/installations/{installation_id}/hide")
        return response.json()

    def unhide_installation(self, installation_id: str) -> dict[str, Any]:
        """Unhide an example installation.

        Args:
            installation_id: Installation ID

        Returns:
            Success payload
        """
        response = self.client.post(f"/analytics/installations/{installation_id}/unhide")
        return response.json()

    def get_installation_script(self, installation_id: str) -> dict[str, Any]:
        """Get installation script tag.

        Args:
            installation_id: Installation ID

        Returns:
            Script tag and instructions
        """
        response = self.client.get(f"/analytics/installations/{installation_id}/script")
        return response.json()

    def get_stats(self, installation_id: str | None = None) -> dict[str, Any]:
        """Get analytics statistics.

        Args:
            installation_id: Optional installation ID filter

        Returns:
            Statistics data
        """
        params: dict[str, Any] = {}
        if installation_id:
            params["installationId"] = installation_id

        response = self.client.get("/analytics/stats", params=params)
        return response.json()

    def get_realtime_stats(self) -> dict[str, Any]:
        """Get real-time statistics.

        Returns:
            Real-time stats
        """
        response = self.client.get("/analytics/dashboard/realtime")
        return response.json()

    def get_time_series(
        self,
        metric: str = "sessions",
        interval: str = "day",
        days: int = 7,
    ) -> list[dict[str, Any]]:
        """Get time series data.

        Args:
            metric: Metric to track (sessions, pageviews, events)
            interval: Time interval (hour, day, week)
            days: Number of days to look back

        Returns:
            Time series data
        """
        response = self.client.get(
            "/analytics/dashboard/timeseries",
            params={"metric": metric, "interval": interval, "days": days},
        )
        data = response.json()
        if isinstance(data, list):
            return data
        return []

    def query_events(
        self,
        installation_id: str,
        event_name: str | None = None,
        fingerprint: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        limit: int = 100,
    ) -> list[AnalyticsEvent]:
        """Query custom events.

        Args:
            installation_id: Installation ID (required)
            event_name: Optional event name filter
            fingerprint: Optional fingerprint filter
            start_date: Optional start date
            end_date: Optional end date
            limit: Maximum number of results

        Returns:
            List of events
        """
        params: dict[str, Any] = {"installationId": installation_id, "limit": limit}
        if event_name:
            params["eventName"] = event_name
        if fingerprint:
            params["fingerprint"] = fingerprint
        if start_date:
            params["startDate"] = start_date.isoformat()
        if end_date:
            params["endDate"] = end_date.isoformat()

        response = self.client.get("/analytics/events", params=params)
        data = response.json()
        if isinstance(data, list):
            return [AnalyticsEvent(**item) for item in data]
        return []

    def get_trajectory(
        self,
        fingerprint: str,
        installation_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get user trajectory by fingerprint.

        Args:
            fingerprint: User fingerprint
            installation_id: Installation ID (required)
            limit: Maximum number of sessions

        Returns:
            User trajectory data
        """
        response = self.client.get(
            "/analytics/trajectory",
            params={"fingerprint": fingerprint, "installationId": installation_id, "limit": limit},
        )
        data = response.json()
        return data.get("trajectory", [])

    # Funnel operations
    def create_funnel(
        self,
        name: str,
        steps: list[dict[str, Any]],
    ) -> AnalyticsFunnel:
        """Create a new funnel.

        Args:
            name: Funnel name
            steps: List of funnel steps with name and eventName

        Returns:
            Created funnel
        """
        data = CreateAnalyticsFunnelRequest(
            name=name,
            steps=steps,
        ).model_dump(mode="json", by_alias=True)
        response = self.client.post("/analytics/funnels", json=data)
        return AnalyticsFunnel(**response.json())

    def list_funnels(self, installation_id: str | None = None) -> list[AnalyticsFunnel]:
        """List all funnels.

        Args:
            installation_id: Optional installation ID filter

        Returns:
            List of funnels
        """
        params: dict[str, Any] = {}
        if installation_id:
            params["installationId"] = installation_id

        response = self.client.get("/analytics/funnels", params=params)
        data = response.json()
        if isinstance(data, list):
            return [AnalyticsFunnel(**item) for item in data]
        return []

    def get_funnel(self, funnel_id: str) -> AnalyticsFunnel:
        """Get funnel details.

        Args:
            funnel_id: Funnel ID

        Returns:
            Funnel details
        """
        response = self.client.get(f"/analytics/funnels/{funnel_id}")
        return AnalyticsFunnel(**response.json())

    def analyze_funnel(
        self,
        funnel_id: str,
        installation_id: str | None = None,
        days: int | None = None,
    ) -> dict[str, Any]:
        """Analyze funnel conversion.

        Args:
            funnel_id: Funnel ID
            installation_id: Optional installation ID filter
            days: Optional number of days to analyze

        Returns:
            Funnel analysis data
        """
        params: dict[str, Any] = {}
        if installation_id:
            params["installationId"] = installation_id
        if days:
            params["days"] = days

        response = self.client.get(
            f"/analytics/funnels/{funnel_id}/analyze",
            params=params,
        )
        return response.json()

    def update_funnel(
        self,
        funnel_id: str,
        name: str | None = None,
        steps: list[dict[str, Any]] | None = None,
        is_active: bool | None = None,
    ) -> AnalyticsFunnel:
        """Update a funnel.

        Args:
            funnel_id: Funnel ID
            name: Optional new name
            steps: Optional new steps
            is_active: Optional active status

        Returns:
            Updated funnel
        """
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if steps is not None:
            data["steps"] = steps
        if is_active is not None:
            data["isActive"] = is_active

        self.client.post(f"/analytics/funnels/{funnel_id}", json=data)
        return self.get_funnel(funnel_id)

    def delete_funnel(self, funnel_id: str) -> None:
        """Delete a funnel.

        Args:
            funnel_id: Funnel ID
        """
        self.client.delete(f"/analytics/funnels/{funnel_id}")

    # User operations
    def list_users(self, installation_id: str, limit: int = 100) -> list[AnalyticsUserProfile]:
        """List user profiles for an installation.

        Args:
            installation_id: Installation ID (required)
            limit: Maximum number of results

        Returns:
            List of user profiles
        """
        response = self.client.get("/analytics/users", params={"installationId": installation_id, "limit": limit})
        data = response.json()
        if isinstance(data, list):
            return [AnalyticsUserProfile(**item) for item in data]
        return []

    def get_user_profile(self, fingerprint: str) -> AnalyticsUserProfile | None:
        """Get user profile by fingerprint.

        Args:
            fingerprint: User fingerprint

        Returns:
            User profile or None if not found
        """
        response = self.client.get(
            "/analytics/users/profile",
            params={"fingerprint": fingerprint},
        )
        data = response.json()
        if "error" in data:
            return None
        return AnalyticsUserProfile(**data)
