"""Notebook session API client."""

from pathlib import Path
from typing import Any
from uuid import uuid4

from .client import Client
from .models import (
    CellOutput,
    ExecutionResult,
    FileMetadata,
    NotebookCell,
    NotebookCellDetail,
    NotebookCollaborator,
    NotebookDocument,
    NotebookSession,
)


class NotebookAPI:
    """API client for Jupyter notebook sessions."""

    def __init__(self, client: Client):
        """Initialize notebook API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def create(
        self,
        workspace_id: str,
        name: str | None = None,
        type: str = "small",
        cpu: int | None = None,
        memory: int | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        gpu_count: int | None = None,
        gpu_type: str | None = None,
        storage_mode: str | None = None,
        env: dict[str, str] | None = None,
        idle_ttl_seconds: int | None = None,
        persistent: bool | None = None,
        snapshot_favor: str | None = None,
        hard_kill_at: str | None = None,
        hard_kill_after_seconds: int | None = None,
    ) -> NotebookSession:
        """Create a new notebook session.

        Args:
            workspace_id: Workspace ID for the session
            name: Session name (defaults to notebook-<id>)
            type: Preset type (micro, small, medium, large, xl)
            cpu: Custom CPU in millis (overrides type)
            memory: Custom memory in MB (overrides type)
            image: Notebook image reference
            snapshot_id: Snapshot ID to restore from
            gpu_count: GPU count
            gpu_type: GPU type
            storage_mode: Storage mode (ephemeral or persistent)

        Returns:
            Created notebook session
        """
        if cpu is None or memory is None:
            try:
                from ..config.settings import get_settings

                type_config = get_settings().get_type_config(type)
                if type_config:
                    if cpu is None:
                        cpu = type_config.cpu
                    if memory is None:
                        memory = type_config.memory
            except Exception:
                pass

        data: dict[str, Any] = {"name": name or f"notebook-{uuid4().hex[:8]}"}
        if cpu is not None:
            data["cpuMillis"] = cpu
        if memory is not None:
            data["memoryMb"] = memory
        data["workspaceId"] = workspace_id
        if image is not None:
            data["image"] = image
        if snapshot_id is not None:
            data["snapshotId"] = snapshot_id
        if gpu_count is not None:
            data["gpuCount"] = gpu_count
        if gpu_type is not None:
            data["gpuType"] = gpu_type
        if storage_mode:
            data["storageMode"] = storage_mode
        if env:
            data["env"] = env
        if idle_ttl_seconds is not None:
            data["idleTtlSeconds"] = idle_ttl_seconds
        if persistent is not None:
            data["persistent"] = persistent
        if snapshot_favor is not None:
            data["snapshotFavor"] = snapshot_favor
        if hard_kill_at is not None:
            data["hardKillAt"] = hard_kill_at
        if hard_kill_after_seconds is not None:
            data["hardKillAfterSeconds"] = hard_kill_after_seconds

        response = self.client.post("/v1/notebooks/sessions", json=data)
        return NotebookSession(**response.json())

    def list_all(self, workspace_id: str | None = None) -> list[NotebookSession]:
        """List all notebook sessions.

        Returns:
            List of notebook sessions
        """
        params = {"workspaceId": workspace_id} if workspace_id else None
        response = self.client.get("/v1/notebooks/sessions", params=params)
        return [NotebookSession(**item) for item in response.json()]

    def get(self, session_id: str) -> NotebookSession:
        """Get notebook session details.

        Args:
            session_id: Session ID

        Returns:
            Notebook session details
        """
        response = self.client.get(f"/v1/notebooks/sessions/{session_id}")
        return NotebookSession(**response.json())

    def stop(self, session_id: str) -> NotebookSession:
        """Stop a notebook session.

        Args:
            session_id: Session ID

        Returns:
            Stopped session
        """
        response = self.client.put(f"/v1/notebooks/sessions/{session_id}/stop")
        return NotebookSession(**response.json())

    def wake(self, session_id: str) -> NotebookSession:
        """Wake a notebook session from its latest snapshot.

        Args:
            session_id: Session ID

        Returns:
            Updated session
        """
        response = self.client.put(f"/v1/notebooks/sessions/{session_id}/wake")
        return NotebookSession(**response.json())

    def delete(self, session_id: str) -> None:
        """Delete a notebook session.

        Args:
            session_id: Session ID
        """
        self.client.delete(f"/v1/notebooks/sessions/{session_id}")

    def wait_for_status(
        self,
        session_id: str,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> NotebookSession:
        """Wait for notebook session to reach desired status.

        Args:
            session_id: Session ID
            desired_status: Desired status (default: running)
            timeout: Maximum wait time in seconds
            interval: Poll interval in seconds

        Returns:
            Session when desired status is reached

        Raises:
            TimeoutError: If timeout is reached
        """
        import time

        start = time.time()
        while time.time() - start < timeout:
            session = self.get(session_id)
            if session.status == desired_status:
                return session
            if session.status == "stopped":
                raise RuntimeError(f"Notebook session {session_id} stopped")
            time.sleep(interval)

        raise TimeoutError(f"Timeout waiting for notebook session {session_id} to start")

    # =========================================================================
    # Document Management Methods
    # =========================================================================

    def create_document(
        self,
        workspace_id: str,
        name: str,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        image: str | None = None,
        auto_save_enabled: bool | None = None,
        markdown_first_cell: bool = False,
    ) -> NotebookDocument:
        """Create a notebook document."""
        data: dict[str, Any] = {
            "workspaceId": workspace_id,
            "name": name,
            "markdownFirstCell": markdown_first_cell,
        }
        if description is not None:
            data["description"] = description

        metadata: dict[str, Any] = {}
        if kernel is not None:
            metadata["kernel"] = kernel
        if runtime is not None:
            metadata["runtime"] = runtime
        if image is not None:
            metadata["image"] = image
        if auto_save_enabled is not None:
            metadata["autoSaveEnabled"] = auto_save_enabled
        if metadata:
            data["metadata"] = metadata

        response = self.client.post("/v1/notebooks", json=data)
        return NotebookDocument(**response.json())

    def list_documents(self, workspace_id: str) -> list[NotebookDocument]:
        """List notebook documents in a workspace."""
        response = self.client.get(
            "/v1/notebooks",
            params={"workspaceId": workspace_id},
        )
        return [NotebookDocument(**item) for item in response.json()]

    def get_document(self, notebook_id: str) -> NotebookDocument:
        """Get notebook document details."""
        response = self.client.get(f"/v1/notebooks/{notebook_id}")
        return NotebookDocument(**response.json())

    def update_document(
        self,
        notebook_id: str,
        name: str | None = None,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        auto_save_enabled: bool | None = None,
    ) -> NotebookDocument:
        """Update notebook document metadata."""
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description

        metadata: dict[str, Any] = {}
        if kernel is not None:
            metadata["kernel"] = kernel
        if runtime is not None:
            metadata["runtime"] = runtime
        if auto_save_enabled is not None:
            metadata["autoSaveEnabled"] = auto_save_enabled
        if metadata:
            data["metadata"] = metadata

        response = self.client.put(f"/v1/notebooks/{notebook_id}", json=data)
        return NotebookDocument(**response.json())

    def delete_document(self, notebook_id: str) -> None:
        """Delete a notebook document."""
        self.client.delete(f"/v1/notebooks/{notebook_id}")

    def duplicate_document(self, notebook_id: str) -> NotebookDocument:
        """Duplicate a notebook document."""
        response = self.client.post(f"/v1/notebooks/{notebook_id}/duplicate")
        return NotebookDocument(**response.json())

    def import_document(
        self,
        workspace_id: str,
        name: str | None = None,
        url: str | None = None,
        file_path: str | None = None,
        image: str | None = None,
    ) -> NotebookDocument:
        """Import a notebook document from URL or local .ipynb file."""
        if bool(url) == bool(file_path):
            raise ValueError("Provide exactly one of url or file_path")

        data: dict[str, Any] = {"workspaceId": workspace_id}
        if name is not None:
            data["name"] = name
        if url is not None:
            data["url"] = url
        if image is not None:
            data["image"] = image

        if file_path is not None:
            filename = Path(file_path).name
            with open(file_path, "rb") as f:
                response = self.client.post(
                    "/v1/notebooks/import",
                    data=data,
                    files={"file": (filename, f, "application/json")},
                )
            return NotebookDocument(**response.json())

        response = self.client.post("/v1/notebooks/import", json=data)
        return NotebookDocument(**response.json())

    def export_document(
        self,
        notebook_id: str,
        *,
        download: bool = False,
    ) -> dict[str, Any] | str:
        """Export a notebook document as ipynb JSON content."""
        params = {"download": "1"} if download else {}
        response = self.client.get(f"/v1/notebooks/{notebook_id}/export", params=params)

        if download:
            return response.text
        return response.json()

    def save_document(self, notebook_id: str) -> NotebookDocument:
        """Persist notebook document to storage."""
        response = self.client.post(f"/v1/notebooks/{notebook_id}/save")
        return NotebookDocument(**response.json())

    # =========================================================================
    # Cell Management Methods
    # =========================================================================

    def list_cells(
        self,
        notebook_id: str,
        include_outputs: bool = False,
    ) -> list[NotebookCell] | list[NotebookCellDetail]:
        """List all cells in a notebook.

        Args:
            notebook_id: Notebook ID
            include_outputs: If True, include outputs in response

        Returns:
            List of cells (with outputs if requested)
        """
        params = {}
        if include_outputs:
            params["include"] = "outputs"

        response = self.client.get(f"/v1/notebooks/{notebook_id}/cells", params=params)

        if include_outputs:
            return [NotebookCellDetail(**item) for item in response.json()]
        return [NotebookCell(**item) for item in response.json()]

    def get_cell(self, notebook_id: str, cell_id: str) -> NotebookCellDetail:
        """Get cell details with outputs.

        Args:
            notebook_id: Notebook ID
            cell_id: Cell ID

        Returns:
            Cell with outputs
        """
        response = self.client.get(f"/v1/notebooks/{notebook_id}/cells/{cell_id}")
        return NotebookCellDetail(**response.json())

    def get_cell_by_index(
        self,
        notebook_id: str,
        cell_index: int,
    ) -> NotebookCellDetail:
        """Get a cell by index with outputs."""
        response = self.client.get(
            f"/v1/notebooks/{notebook_id}/cells/by-index/{cell_index}"
        )
        return NotebookCellDetail(**response.json())

    def add_cell(
        self,
        notebook_id: str,
        source: str,
        cell_type: str = "code",
        index: int | None = None,
    ) -> NotebookCell:
        """Add a new cell.

        Args:
            notebook_id: Notebook ID
            source: Cell source code
            cell_type: Cell type (code, markdown, raw)
            index: Position to insert at (default: end)

        Returns:
            Created cell
        """
        data: dict[str, Any] = {
            "source": source,
            "cellType": cell_type,
        }
        if index is not None:
            data["cellIndex"] = index

        response = self.client.post(f"/v1/notebooks/{notebook_id}/cells", json=data)
        return NotebookCell(**response.json())

    def update_cell_source(
        self,
        notebook_id: str,
        cell_id: str,
        source: str,
        *,
        expected_version: int,
    ) -> NotebookCell:
        """Update a cell source with optimistic concurrency guard.

        Args:
            notebook_id: Notebook ID
            cell_id: Cell ID
            source: Full source code to persist
            expected_version: Expected source OT version

        Returns:
            Updated cell
        """
        response = self.client.put(
            f"/v1/notebooks/{notebook_id}/cells/{cell_id}/source",
            json={
                "source": source,
                "expectedVersion": expected_version,
            },
        )
        return NotebookCell(**response.json())

    def delete_cell(self, notebook_id: str, cell_id: str) -> None:
        """Delete a cell.

        Args:
            notebook_id: Notebook ID
            cell_id: Cell ID
        """
        self.client.delete(f"/v1/notebooks/{notebook_id}/cells/{cell_id}")

    def execute_cell(
        self,
        notebook_id: str,
        cell_id: str | None = None,
        cell_index: int | None = None,
        source: str | None = None,
    ) -> ExecutionResult:
        """Execute a cell.

        Args:
            notebook_id: Notebook ID
            cell_id: Cell ID
            cell_index: Cell index (zero-based)
            source: Optional source override

        Returns:
            Execution result with execution ID
        """
        if (cell_id is None and cell_index is None) or (
            cell_id is not None and cell_index is not None
        ):
            raise ValueError("Provide exactly one of cell_id or cell_index")

        data: dict[str, Any] = {}
        if cell_id is not None:
            data["cellId"] = cell_id
        if cell_index is not None:
            data["cellIndex"] = cell_index
        if source is not None:
            data["source"] = source

        response = self.client.post(f"/v1/notebooks/{notebook_id}/kernel/execute", json=data)
        resp_data = response.json()
        return ExecutionResult(
            executionId=resp_data.get("executionId", ""),
            status=resp_data.get("status", "started"),
            message=resp_data.get("message"),
        )

    def ensure_kernel(self, notebook_id: str) -> dict[str, Any]:
        """Ensure a notebook kernel session exists and is waking/running."""
        response = self.client.post(f"/v1/notebooks/{notebook_id}/kernel/ensure")
        return response.json()

    def get_kernel_status(self, notebook_id: str) -> dict[str, Any]:
        """Get notebook kernel status."""
        response = self.client.get(f"/v1/notebooks/{notebook_id}/kernel")
        return response.json()

    def interrupt_kernel(self, notebook_id: str) -> dict[str, Any]:
        """Interrupt a notebook kernel."""
        response = self.client.post(f"/v1/notebooks/{notebook_id}/kernel/interrupt")
        return response.json()

    def restart_kernel(self, notebook_id: str) -> dict[str, Any]:
        """Restart a notebook kernel."""
        response = self.client.post(f"/v1/notebooks/{notebook_id}/kernel/restart")
        return response.json()

    def update_kernel_ttl_policy(
        self,
        notebook_id: str,
        *,
        persistent: bool | None = None,
        idle_ttl_seconds: int | None = None,
        snapshot_favor: str | None = None,
        hard_kill_at: str | None = None,
        hard_kill_after_seconds: int | None = None,
    ) -> dict[str, Any]:
        """Update notebook kernel TTL policy."""
        data: dict[str, Any] = {}
        if persistent is not None:
            data["persistent"] = persistent
        if idle_ttl_seconds is not None:
            data["idleTtlSeconds"] = idle_ttl_seconds
        if snapshot_favor is not None:
            data["snapshotFavor"] = snapshot_favor
        if hard_kill_at is not None:
            data["hardKillAt"] = hard_kill_at
        if hard_kill_after_seconds is not None:
            data["hardKillAfterSeconds"] = hard_kill_after_seconds

        response = self.client.put(
            f"/v1/notebooks/{notebook_id}/kernel/ttl-policy",
            json=data,
        )
        return response.json()

    def get_cell_outputs(self, notebook_id: str, cell_id: str) -> list[CellOutput]:
        """Get outputs for a cell.

        Args:
            notebook_id: Notebook ID
            cell_id: Cell ID

        Returns:
            List of outputs
        """
        response = self.client.get(f"/v1/notebooks/{notebook_id}/outputs/{cell_id}")
        return [CellOutput(**o) for o in response.json()]

    def clear_notebook_outputs(self, notebook_id: str) -> dict[str, Any]:
        """Clear outputs for all code cells in a notebook."""
        response = self.client.delete(f"/v1/notebooks/{notebook_id}/outputs")
        return response.json()

    # =========================================================================
    # Notebook File Methods
    # =========================================================================

    def list_files(
        self,
        notebook_id: str,
        path: str | None = None,
    ) -> list[FileMetadata]:
        """List notebook-scoped files."""
        params: dict[str, Any] = {}
        if path:
            params["path"] = path

        response = self.client.get(f"/v1/notebooks/{notebook_id}/files", params=params)
        return [FileMetadata(**item) for item in response.json()]

    def create_directory(self, notebook_id: str, path: str) -> FileMetadata:
        """Create a notebook-scoped directory."""
        response = self.client.post(
            f"/v1/notebooks/{notebook_id}/files/directory",
            json={"path": path},
        )
        return FileMetadata(**response.json())

    def upload_file(
        self,
        notebook_id: str,
        file_path: str,
        remote_path: str | None = None,
        remote_filename: str | None = None,
    ) -> FileMetadata:
        """Upload a notebook-scoped file."""
        filename = Path(file_path).name
        data: dict[str, Any] = {}
        if remote_path:
            data["path"] = remote_path
        if remote_filename:
            data["filename"] = remote_filename

        with open(file_path, "rb") as f:
            files = {"file": (filename, f, "application/octet-stream")}
            response = self.client.post(
                f"/v1/notebooks/{notebook_id}/files/upload",
                files=files,
                data=data,
            )

        return FileMetadata(**response.json())

    def download_file(
        self,
        notebook_id: str,
        remote_path: str,
        local_path: str,
    ) -> None:
        """Download a notebook-scoped file."""
        response = self.client.get(
            f"/v1/notebooks/{notebook_id}/files/content",
            params={"path": remote_path, "download": "1"},
        )
        output_path = Path(local_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(response.content)

    def delete_file(self, notebook_id: str, path: str) -> None:
        """Delete a notebook-scoped file or directory."""
        self.client.post(
            f"/v1/notebooks/{notebook_id}/files/delete",
            json={"path": path},
        )

    def list_collaborators(self, notebook_id: str) -> list[NotebookCollaborator]:
        """List active collaborators for a notebook."""
        response = self.client.get(f"/v1/notebooks/{notebook_id}/collaborators")
        return [NotebookCollaborator(**item) for item in response.json()]
