"""HTTP client for AgentEnv Cloud API."""

from typing import Any

import httpx

from ..config.settings import normalize_api_url
from .models import APIError


class Client:
    """HTTP client for AgentEnv Cloud API."""

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        access_token: str | None = None,
        timeout: float = 60.0,
    ):
        """Initialize API client.

        Args:
            base_url: Base URL of the API server
            api_key: API key for authentication
            access_token: JWT access token for authentication
            timeout: Request timeout in seconds
        """
        self.base_url = normalize_api_url(base_url)
        self.api_key = api_key
        self.access_token = access_token
        self.csrf_token: str | None = None
        self._client = httpx.Client(
            timeout=httpx.Timeout(timeout, connect=10.0),
            follow_redirects=False,
        )

    @staticmethod
    def _normalize_path(path: str) -> str:
        """Normalize request paths to the versioned API surface."""
        if path.startswith(("http://", "https://")):
            return path

        normalized = path if path.startswith("/") else f"/{path}"
        if normalized == "/v1" or normalized.startswith("/v1/"):
            return normalized
        return f"/v1{normalized}"

    def _build_url(self, path: str) -> str:
        normalized_path = self._normalize_path(path)
        if normalized_path.startswith(("http://", "https://")):
            return normalized_path
        return f"{self.base_url}{normalized_path}"

    def _auth_headers(self) -> dict[str, str]:
        """Get authentication headers."""
        if self.api_key:
            return {"X-API-Key": self.api_key}
        if self.access_token:
            headers = {"Authorization": f"Bearer {self.access_token}"}
            if self.csrf_token:
                headers["X-CSRF-Token"] = self.csrf_token
            return headers
        return {}

    def request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make authenticated request to API.

        Args:
            method: HTTP method
            path: API path (will be prefixed with base_url)
            **kwargs: Additional arguments for httpx.request

        Returns:
            httpx.Response

        Raises:
            APIError: If the request fails
        """
        url = self._build_url(path)
        headers = kwargs.pop("headers", {})
        headers.update(self._auth_headers())

        response = self._client.request(method, url, headers=headers, **kwargs)

        # Store CSRF token from GET requests
        if method.upper() == "GET" and "x-csrf-token" in response.headers:
            self.csrf_token = response.headers["x-csrf-token"]

        # Handle errors
        if response.status_code >= 400:
            try:
                error_data = response.json()
                # Handle different error response formats
                if "error" in error_data:
                    # Format: {error: {code, message}}
                    error_obj = error_data["error"]
                    if isinstance(error_obj, dict):
                        message = error_obj.get("message", "")
                        details = error_obj
                    else:
                        message = str(error_obj)
                        details = error_data
                else:
                    # Format: {message, ...}
                    message = error_data.get("message", "")
                    details = error_data
            except Exception:
                message = response.text or "Unknown error"
                details = {}

            raise APIError(
                status_code=response.status_code,
                message=message,
                details=details,
            )

        return response

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make GET request."""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make POST request."""
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make PUT request."""
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make PATCH request."""
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make DELETE request."""
        return self.request("DELETE", path, **kwargs)

    def stream(self, method: str, path: str, **kwargs: Any):
        """Make authenticated streaming request.

        Args:
            method: HTTP method
            path: API path (will be prefixed with base_url)
            **kwargs: Additional arguments for httpx.Client.stream

        Returns:
            Streaming context manager from httpx.Client.stream
        """
        url = self._build_url(path)
        headers = kwargs.pop("headers", {})
        headers.update(self._auth_headers())
        return self._client.stream(method, url, headers=headers, **kwargs)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, *args):
        """Context manager exit."""
        self.close()


class StreamingClient(Client):
    """Client with support for streaming responses."""

    def stream_logs(self, sandbox_id: str, follow: bool = True) -> httpx.Response:
        """Stream logs from a sandbox.

        Args:
            sandbox_id: Sandbox ID
            follow: Whether to follow logs

        Returns:
            Streaming response
        """
        params = {"follow": "true"} if follow else {}
        return self.get(f"/v1/sandboxes/{sandbox_id}/logs", params=params)

    def stream_request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make a streaming request.

        Args:
            method: HTTP method
            path: API path
            **kwargs: Additional arguments

        Returns:
            Streaming response
        """
        return self.stream(method, path, **kwargs)
