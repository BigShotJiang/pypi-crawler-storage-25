#!/usr/bin/env node

/**
 * Official mppx runner — payer-side machine-payment execution.
 *
 * Reads a JSON challenge from stdin and is expected to invoke the official
 * payer flow for non-local environments.
 *
 * Usage: echo '{"providerReference":"pi_123"}' | node run-payment.mjs
 */

import { readFileSync } from "node:fs";

async function main() {
  const stdin = readFileSync(0, "utf-8");
  JSON.parse(stdin);

  throw new Error(
    "Official mppx payer flow is not configured in this workspace. " +
      "Wire the official payer before using this runner."
  );
}

main().catch((err) => {
  process.stderr.write(`mppx runner error: ${err.message}\n`);
  process.exit(1);
});
