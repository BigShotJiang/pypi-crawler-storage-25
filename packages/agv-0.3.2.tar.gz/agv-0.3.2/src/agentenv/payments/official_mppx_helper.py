"""Official MPPX helper wrapper for non-local environments."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


class OfficialMppxHelper:
    """Wrap the JS runner for official payer-side payment execution."""

    def __init__(self) -> None:
        self.runner_script = str(
            Path(__file__).parent / "mppx_runner" / "run-payment.mjs"
        )

    def run_payment(self, challenge: dict[str, Any]) -> str:
        self.ensure_available()

        result = subprocess.run(
            ["node", self.runner_script],
            input=json.dumps(challenge),
            capture_output=True,
            text=True,
            timeout=60,
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"mppx runner failed (exit {result.returncode}): {result.stderr}"
            )

        payload = json.loads(result.stdout)
        authorization_header = self._extract_authorization_header(payload)
        return authorization_header

    def ensure_available(self) -> None:
        """Validate official runner dependencies before invoking Node."""
        if shutil.which("node") is None:
            raise RuntimeError(
                "Official machine-payment runner is not configured: Node.js is unavailable."
            )
        if not Path(self.runner_script).exists():
            raise RuntimeError(
                "Official machine-payment runner is not configured: runner script is missing."
            )

    def _extract_authorization_header(self, payload: dict[str, Any]) -> str:
        authorization_header = payload.get("authorizationHeader")
        if isinstance(authorization_header, str) and authorization_header:
            return authorization_header

        headers = payload.get("headers")
        if isinstance(headers, dict):
            header_value = headers.get("Authorization")
            if isinstance(header_value, str) and header_value:
                return header_value

        raise RuntimeError(
            "Official machine-payment runner did not return an Authorization header."
        )
