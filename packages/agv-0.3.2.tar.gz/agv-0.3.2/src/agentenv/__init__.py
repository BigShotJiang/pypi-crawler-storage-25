"""AgentEnv Cloud CLI - Manage containers, sandboxes, and more."""

from ._version import __version__

# SDK exports
from .sdk import Client, connect, SandboxResource
from .sdk.ai import AIClient
from .sdk.cluster import (
    create_ray_cluster,
    create_spark_cluster,
    get_cluster,
    list_clusters,
    ray_init,
    remote,
    spark_init,
    stop_cluster,
    wait_for_cluster,
)
from .sdk.function import function, RemoteFunctionError
from .sdk.image import ImageBuilder, image, py

__all__ = [
    "Client",
    "connect",
    "SandboxResource",
    "AIClient",
    "ImageBuilder",
    "image",
    "py",
    "function",
    "RemoteFunctionError",
    "ray_init",
    "spark_init",
    "remote",
    "create_ray_cluster",
    "create_spark_cluster",
    "list_clusters",
    "get_cluster",
    "stop_cluster",
    "wait_for_cluster",
    "__version__",
]
