"""Configuration settings for AgentEnv CLI."""

import os
from pathlib import Path

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field

from .storage import CredentialStorage


class PresetType(BaseModel):
    """Preset sandbox type configuration."""

    cpu: int
    memory: int


class DefaultConfig(BaseModel):
    """Default sandbox configuration."""

    type: str = "small"
    image: str = "docker.io/library/python:3.11-slim"
    cpu: int | None = None
    memory: int | None = None
    max_lifetime_seconds: int | None = None
    region: str | None = None


def normalize_api_url(url: str) -> str:
    """Normalize API base URLs to the API root without a version suffix."""
    normalized = url.strip().rstrip("/")
    if normalized.endswith("/v1"):
        return normalized[:-3]
    return normalized


class Settings(BaseModel):
    """Application settings."""

    # API Configuration
    api_url: str = "http://localhost:3000"
    api_key: str | None = None
    gateway_key: str | None = None  # AI Gateway key (cr_xxx)
    access_token: str | None = None
    refresh_token: str | None = None

    # Workspace
    workspace: str | None = None

    # Output options
    debug: bool = False
    json_output: bool = False

    # Sandbox defaults
    defaults: DefaultConfig = Field(default_factory=DefaultConfig)

    # Preset types
    types: dict[str, PresetType] = Field(default_factory=lambda: {
        "micro": PresetType(cpu=500, memory=512),
        "small": PresetType(cpu=2000, memory=4096),
        "medium": PresetType(cpu=4000, memory=8192),
        "large": PresetType(cpu=8000, memory=16384),
        "xl": PresetType(cpu=16000, memory=32768),
    })

    # Common image shortcuts
    images: dict[str, str] = Field(default_factory=lambda: {
        "python": "docker.io/library/python:3.11-slim",
        "python3": "docker.io/library/python:3.11-slim",
        "node": "docker.io/library/node:20-slim",
        "nodejs": "docker.io/library/node:20-slim",
        "bash": "docker.io/library/bash:latest",
        "alpine": "docker.io/library/alpine:latest",
        "golang": "docker.io/library/golang:latest",
        "ubuntu": "docker.io/library/ubuntu:22.04",
    })

    model_config = {"extra": "ignore"}

    @classmethod
    def load(cls) -> "Settings":
        """Load settings from config file and environment."""
        config_dir = Path.home() / ".agentenv"
        config_file = config_dir / "config.yaml"

        settings = cls()

        # Load from .env files
        load_dotenv()

        # Load from environment variables (AGENTENV_ prefix)
        # These take precedence over config file
        env_overrides = {}
        if os.getenv("AGENTENV_API_URL"):
            env_overrides["api_url"] = os.getenv("AGENTENV_API_URL")
        if os.getenv("AGENTENV_API_KEY"):
            env_overrides["api_key"] = os.getenv("AGENTENV_API_KEY")
        if os.getenv("AGENTENV_WORKSPACE"):
            env_overrides["workspace"] = os.getenv("AGENTENV_WORKSPACE")
        if os.getenv("AGENTENV_DEBUG"):
            env_overrides["debug"] = os.getenv("AGENTENV_DEBUG").lower() in ("1", "true", "yes")
        if os.getenv("AGENTENV_JSON"):
            env_overrides["json_output"] = os.getenv("AGENTENV_JSON").lower() in ("1", "true", "yes")
        # Load from config file
        if config_file.exists():
            with open(config_file) as f:
                config_data = yaml.safe_load(f) or {}
            settings = settings.model_validate(config_data)
            settings.api_url = normalize_api_url(settings.api_url)

        # Load credentials from the configured storage backend.
        creds = CredentialStorage().get_all()
        if api_key := creds.get("api_key"):
            settings.api_key = api_key
        if gateway_key := creds.get("gateway_key"):
            settings.gateway_key = gateway_key
        if access_token := creds.get("access_token"):
            settings.access_token = access_token
        if refresh_token := creds.get("refresh_token"):
            settings.refresh_token = refresh_token

        # Apply environment overrides
        if env_overrides:
            # Environment variables must win over config file defaults and stored credentials.
            if "api_url" in env_overrides:
                env_overrides["api_url"] = normalize_api_url(env_overrides["api_url"])
            settings = settings.model_validate(settings.model_dump() | env_overrides)

        # Also check PORT from .env to construct API URL
        if not env_overrides.get("api_url"):
            port = os.getenv("PORT", "3000")
            if settings.api_url == "http://localhost:3000" and port != "3000":
                settings.api_url = f"http://localhost:{port}"

        return settings

    def save(self, include_secrets: bool = False) -> None:
        """Save settings to config file."""
        config_dir = Path.home() / ".agentenv"
        config_dir.mkdir(mode=0o700, exist_ok=True)

        config_file = config_dir / "config.yaml"

        # Don't save credentials to config file
        data = self.model_dump(exclude={"api_key", "gateway_key", "access_token", "refresh_token"})

        with open(config_file, "w") as f:
            yaml.dump(data, f, default_flow_style=False)

    def save_credentials(self) -> None:
        """Save credentials to the configured storage backend."""
        CredentialStorage().sync(
            api_key=self.api_key,
            gateway_key=self.gateway_key,
            access_token=self.access_token,
            refresh_token=self.refresh_token,
        )

    def clear_credentials(self) -> None:
        """Clear stored credentials from the configured backend."""
        CredentialStorage().clear_all()

    def get_type_config(self, type_name: str) -> PresetType | None:
        """Get preset type configuration."""
        return self.types.get(type_name)

    def resolve_image(self, image: str | None) -> str:
        """Resolve image shorthand to full image name."""
        if not image:
            return self.defaults.image

        if image in self.images:
            return self.images[image]
        return image

    def is_authenticated(self) -> bool:
        """Check if user is authenticated."""
        return bool(self.api_key or self.access_token)


# Global settings instance
_settings: Settings | None = None


def get_settings(reload: bool = False) -> Settings:
    """Get or create global settings instance."""
    global _settings
    if _settings is None or reload:
        _settings = Settings.load()
    return _settings


def reset_settings() -> None:
    """Reset global settings instance."""
    global _settings
    _settings = None
