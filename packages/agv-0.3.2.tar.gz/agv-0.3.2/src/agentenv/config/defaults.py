"""Default value management for AgentEnv CLI."""

import json
from pathlib import Path
from typing import Any

from .settings import get_settings


class DefaultsManager:
    """Manage default values for sandbox creation."""

    def __init__(self):
        self._defaults_file = Path.home() / ".agentenv" / "defaults.json"
        self._defaults: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        """Load defaults from file."""
        if self._defaults_file.exists():
            with open(self._defaults_file) as f:
                self._defaults = json.load(f)

    def _save(self) -> None:
        """Save defaults to file."""
        self._defaults_file.parent.mkdir(mode=0o700, exist_ok=True)
        with open(self._defaults_file, "w") as f:
            json.dump(self._defaults, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a default value."""
        return self._defaults.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a default value."""
        self._defaults[key] = value
        self._save()

    def remove(self, key: str) -> None:
        """Remove a default value."""
        if key in self._defaults:
            del self._defaults[key]
            self._save()

    def clear(self) -> None:
        """Clear all defaults."""
        self._defaults = {}
        self._save()

    def get_all(self) -> dict[str, Any]:
        """Get all defaults."""
        return self._defaults.copy()

    def get_sandbox_defaults(self) -> dict[str, Any]:
        """Get defaults relevant to sandbox creation."""
        settings = get_settings()
        result: dict[str, Any] = {}

        # Get type from defaults or settings
        if "type" in self._defaults:
            result["type"] = self._defaults["type"]
        elif settings.defaults.type:
            result["type"] = settings.defaults.type

        # Get preset config for type
        if "type" in result:
            type_config = settings.get_type_config(result["type"])
            if type_config:
                result["cpu"] = type_config.cpu
                result["memory"] = type_config.memory

        # Override with explicit cpu/memory from defaults
        if "cpu" in self._defaults:
            result["cpu"] = self._defaults["cpu"]
        if "memory" in self._defaults:
            result["memory"] = self._defaults["memory"]

        # Get other defaults
        for key in ["image", "gpu", "gpu_type", "region", "max_lifetime_seconds"]:
            if key in self._defaults:
                result[key] = self._defaults[key]
            elif hasattr(settings.defaults, key):
                value = getattr(settings.defaults, key)
                if value is not None:
                    result[key] = value

        return result

    def set_from_dict(self, data: dict[str, Any]) -> None:
        """Set multiple defaults from a dictionary."""
        for key, value in data.items():
            if value is not None:
                self._defaults[key] = value
        self._save()

    def print_current(self) -> None:
        """Print current defaults in a formatted way."""
        from rich.console import Console
        from rich.table import Table

        console = Console()

        table = Table(title="Current Defaults", show_header=True)
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="green")

        if not self._defaults:
            console.print("[dim]No defaults set. Use 'agv set <key> <value>' to set defaults.[/dim]")
            return

        for key, value in sorted(self._defaults.items()):
            table.add_row(key, str(value))

        console.print(table)


# Global defaults manager instance
_defaults_manager: DefaultsManager | None = None


def get_defaults_manager() -> DefaultsManager:
    """Get or create global defaults manager instance."""
    global _defaults_manager
    if _defaults_manager is None:
        _defaults_manager = DefaultsManager()
    return _defaults_manager


def reset_defaults_manager() -> None:
    """Reset the cached defaults manager."""
    global _defaults_manager
    _defaults_manager = None
