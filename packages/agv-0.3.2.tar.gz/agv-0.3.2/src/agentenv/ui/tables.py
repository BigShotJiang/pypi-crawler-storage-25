"""Table rendering with Rich."""

import json
from datetime import datetime
from types import SimpleNamespace
from typing import Any

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from ..api.models import (
    APIKey,
    BalanceInfo,
    BrowserSession,
    CellOutput,
    FileMetadata,
    ImageSnapshot,
    ImageTag,
    NotebookCellDetail,
    NotebookDocument,
    NotebookSession,
    Sandbox,
    Snapshot,
    Transaction,
    Workspace,
)
from ..config.settings import get_settings

console = Console()


def _format_currency_from_cents(amount_cents: int) -> str:
    """Format cents as a dollar-denominated display string."""
    sign = "-" if amount_cents < 0 else ""
    dollars = abs(amount_cents) / 100
    return f"{sign}${dollars:,.2f}"


def json_output_enabled() -> bool:
    """Whether the current CLI invocation requested JSON output."""
    try:
        return getattr(get_settings(), "json_output", False) is True
    except Exception:
        return False


def _to_jsonable(value: Any) -> Any:
    """Recursively convert values into JSON-serializable data."""
    if hasattr(value, "model_dump"):
        return _to_jsonable(value.model_dump(by_alias=True, exclude_none=True))
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, SimpleNamespace):
        return _to_jsonable(vars(value))
    return value


def emit_json(data: Any) -> None:
    """Print a JSON payload."""
    print(json.dumps(_to_jsonable(data), indent=2, default=str))


# =============================================================================
# Sandbox Tables
# =============================================================================

def print_sandbox_table(sandboxes: list[Sandbox]) -> None:
    """Print sandboxes in a table.

    Args:
        sandboxes: List of sandboxes
    """
    if json_output_enabled():
        emit_json(sandboxes)
        return

    if not sandboxes:
        console.print("[dim]No sandboxes found.[/dim]")
        return

    table = Table(title="Sandboxes", box=box.ROUNDED)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Image")
    table.add_column("CPU", justify="right")
    table.add_column("Memory", justify="right")
    table.add_column("IP", style="dim")
    table.add_column("Ports", no_wrap=True)

    for sb in sandboxes:
        status_color = {
            "running": "green",
            "stopped": "yellow",
            "pending": "blue",
            "failed": "red",
            "terminated": "dim",
        }.get(sb.status, "")

        status_text = f"[{status_color}]{sb.status}[/{status_color}]" if status_color else sb.status

        # Shorten ID
        short_id = sb.id[:12] if len(sb.id) > 12 else sb.id

        # Image name
        image = sb.config.image.split("/")[-1]
        if len(image) > 20:
            image = image[:17] + "..."

        # CPU and memory
        cpu = f"{sb.config.cpu_millis}" if sb.config.cpu_millis is not None else "-"
        memory = f"{sb.config.memory_mb}MB" if sb.config.memory_mb is not None else "-"

        # IP address
        ip = sb.metadata.ip_address or "-"

        # Ports
        ports = ", ".join(
            f"{p.container_port}→{p.host_port}"
            for p in sb.metadata.port_mappings[:3]
        )
        if len(sb.metadata.port_mappings) > 3:
            ports += f" +{len(sb.metadata.port_mappings) - 3}"
        ports = ports or "-"

        table.add_row(
            short_id,
            sb.name or "-",
            status_text,
            image,
            cpu,
            memory,
            ip,
            ports,
        )

    console.print(table)


def print_ports_table(ports: list[Any], sandbox_id: str) -> None:
    """Print port mappings in a table.

    Args:
        ports: List of PortMapping objects
        sandbox_id: Sandbox ID for the title
    """
    if json_output_enabled():
        emit_json(ports)
        return

    if not ports:
        console.print(f"[dim]No ports exposed for sandbox {sandbox_id}.[/dim]")
        return

    table = Table(title=f"Exposed Ports for {sandbox_id}", box=box.ROUNDED)
    table.add_column("Container Port", justify="right")
    table.add_column("Host Port", justify="right")
    table.add_column("Protocol")
    table.add_column("URL")

    for port in ports:
        url = port.public_url or f"{port.host_ip}:{port.host_port}" if port.host_ip else f"localhost:{port.host_port}"
        table.add_row(
            str(port.container_port),
            str(port.host_port),
            port.protocol,
            url,
        )

    console.print(table)


def print_sandbox_detail(sandbox: Sandbox) -> None:
    """Print sandbox details.

    Args:
        sandbox: Sandbox details
    """
    if json_output_enabled():
        emit_json(sandbox)
        return

    table = Table(title=f"Sandbox: {sandbox.name or sandbox.id}", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", sandbox.id)
    table.add_row("Name", sandbox.name or "-")
    table.add_row("Status", _colored_status(sandbox.status))
    table.add_row("Container ID", sandbox.container_id or "-")
    table.add_row("Hypervisor ID", sandbox.hypervisor_id or "-")
    table.add_row("Task ID", sandbox.task_id or "-")
    table.add_row("Workspace ID", sandbox.workspace_id)

    table.add_section()

    table.add_row("Image", sandbox.config.image)
    cpu_value = f"{sandbox.config.cpu_millis} millis" if sandbox.config.cpu_millis is not None else "-"
    memory_value = f"{sandbox.config.memory_mb} MB" if sandbox.config.memory_mb is not None else "-"
    table.add_row("CPU", cpu_value)
    table.add_row("Memory", memory_value)
    if sandbox.config.max_lifetime_seconds is not None:
        table.add_row("Max Lifetime", f"{sandbox.config.max_lifetime_seconds} seconds")
    if sandbox.config.gpu_count > 0:
        table.add_row("GPU", f"{sandbox.config.gpu_count}x {sandbox.config.gpu_type or 'default'}")

    if sandbox.config.env:
        env_str = ", ".join(f"{k}={v}" for k, v in list(sandbox.config.env.items())[:5])
        if len(sandbox.config.env) > 5:
            env_str += f" (+{len(sandbox.config.env) - 5} more)"
        table.add_row("Environment", env_str)

    if sandbox.config.args:
        table.add_row("Args", " ".join(sandbox.config.args))

    table.add_section()

    table.add_row("IP Address", sandbox.metadata.ip_address or "-")
    table.add_row("Created", _format_datetime(sandbox.metadata.created_at))
    if sandbox.metadata.started_at:
        table.add_row("Started", _format_datetime(sandbox.metadata.started_at))
    if sandbox.metadata.stopped_at:
        table.add_row("Stopped", _format_datetime(sandbox.metadata.stopped_at))

    if sandbox.metadata.port_mappings:
        ports = "\n".join(
            f"{p.container_port} → {p.host_port} ({p.protocol})"
            for p in sandbox.metadata.port_mappings
        )
        table.add_row("Port Mappings", ports)

    console.print(table)


# =============================================================================
# Snapshot Tables
# =============================================================================

def print_snapshot_table(snapshots: list[Snapshot]) -> None:
    """Print snapshots in a table.

    Args:
        snapshots: List of snapshots
    """
    if json_output_enabled():
        emit_json(snapshots)
        return

    if not snapshots:
        console.print("[dim]No snapshots found.[/dim]")
        return

    table = Table(title="Snapshots", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Sandbox", style="dim")
    table.add_column("Status", no_wrap=True)
    table.add_column("Size", justify="right")
    table.add_column("Memory", no_wrap=True)
    table.add_column("Created")

    for snap in snapshots:
        status_color = {
            "completed": "green",
            "pending": "blue",
            "in_progress": "yellow",
            "failed": "red",
        }.get(snap.status, "")

        status_text = f"[{status_color}]{snap.status}[/{status_color}]" if status_color else snap.status

        size = _format_size(snap.size_bytes)

        table.add_row(
            snap.id[:12],
            snap.name or "-",
            snap.sandbox_id[:12],
            status_text,
            size,
            "Yes"
            if snap.has_memory is True
            else ("No" if snap.has_memory is False else "-"),
            _format_datetime(snap.created_at),
        )

    console.print(table)


# =============================================================================
# Image Tables
# =============================================================================

def print_image_table(images: list[ImageSnapshot]) -> None:
    """Print images in a table."""
    if json_output_enabled():
        emit_json(images)
        return

    if not images:
        console.print("[dim]No images found.[/dim]")
        return

    table = Table(title="Images", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Base")
    table.add_column("Tags")
    table.add_column("Created")

    for img in images:
        status_text = _colored_status(img.status)
        base = img.base_image or img.base_snapshot_id or "-"
        if base and len(base) > 24:
            base = base[:21] + "..."
        tags = ", ".join(img.tags or [])
        if len(tags) > 24:
            tags = tags[:21] + "..."
        table.add_row(
            img.id[:12],
            img.name or "-",
            status_text,
            base,
            tags or "-",
            _format_datetime(img.created_at),
        )

    console.print(table)


def print_image_detail(image: ImageSnapshot) -> None:
    """Print image details."""
    if json_output_enabled():
        emit_json(image)
        return

    table = Table(title=f"Image: {image.name or image.id}", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", image.id)
    table.add_row("Name", image.name or "-")
    table.add_row("Status", _colored_status(image.status))
    table.add_row("Build Hash", image.build_hash)
    table.add_row("Base Image", image.base_image or "-")
    table.add_row("Base Snapshot", image.base_snapshot_id or "-")
    if image.tags:
        table.add_row("Tags", ", ".join(image.tags))
    if image.workdir:
        table.add_row("Workdir", image.workdir)
    if image.env_keys:
        table.add_row("Env Keys", ", ".join(image.env_keys))
    if image.cache_mode:
        table.add_row("Cache Mode", image.cache_mode)
    table.add_row("Created", _format_datetime(image.created_at))
    table.add_row("Updated", _format_datetime(image.updated_at))
    if image.build_started_at:
        table.add_row("Build Started", _format_datetime(image.build_started_at))
    if image.build_completed_at:
        table.add_row("Build Completed", _format_datetime(image.build_completed_at))
    if image.size_bytes:
        table.add_row("Size", _format_size(image.size_bytes))

    console.print(table)

    if image.steps:
        steps_table = Table(title="Build Steps", box=box.ROUNDED)
        steps_table.add_column("#", style="dim", no_wrap=True)
        steps_table.add_column("Type")
        steps_table.add_column("Duration")
        steps_table.add_column("Exit")
        steps_table.add_column("Output Preview")
        for step in image.steps:
            meta = step.meta or {}
            duration = f"{meta.get('durationMs', 0)}ms" if meta else "-"
            exit_code = str(meta.get("exitCode", "")) if meta else "-"
            preview = meta.get("outputPreview") if meta else ""
            if preview and len(preview) > 40:
                preview = preview[:37] + "..."
            steps_table.add_row(
                str(meta.get("index", "")) if meta else "",
                step.type,
                duration,
                exit_code,
                preview or "-",
            )
        console.print(steps_table)


def print_image_tags_table(tags: list[ImageTag]) -> None:
    if json_output_enabled():
        emit_json(tags)
        return

    if not tags:
        console.print("[dim]No image tags found.[/dim]")
        return

    table = Table(title="Image Tags", box=box.ROUNDED)
    table.add_column("Tag")
    table.add_column("Image ID", style="dim")
    table.add_column("Workspace", style="dim")
    table.add_column("Created")

    for tag in tags:
        table.add_row(
            tag.tag,
            tag.image_id[:12],
            tag.workspace_id[:12],
            _format_datetime(tag.created_at) if tag.created_at else "-",
        )

    console.print(table)


# =============================================================================
# Browser Session Tables
# =============================================================================

def print_browser_table(sessions: list[BrowserSession]) -> None:
    """Print browser sessions in a table.

    Args:
        sessions: List of browser sessions
    """
    if json_output_enabled():
        emit_json(sessions)
        return

    if not sessions:
        console.print("[dim]No browser sessions found.[/dim]")
        return

    table = Table(title="Browser Sessions", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("VNC URL")
    table.add_column("CDP URL")
    table.add_column("Created")

    for session in sessions:
        status_color = {
            "running": "green",
            "starting": "yellow",
            "stopped": "dim",
        }.get(session.status, "")

        status_text = f"[{status_color}]{session.status}[/{status_color}]" if status_color else session.status

        table.add_row(
            session.id[:12],
            session.name or "-",
            status_text,
            session.vnc_url or "-",
            session.cdp_url or "-",
            _format_datetime(session.created_at),
        )

    console.print(table)


# =============================================================================
# Notebook Session Tables
# =============================================================================

def print_notebook_table(sessions: list[NotebookSession]) -> None:
    """Print notebook sessions in a table.

    Args:
        sessions: List of notebook sessions
    """
    if json_output_enabled():
        emit_json(sessions)
        return

    if not sessions:
        console.print("[dim]No notebook sessions found.[/dim]")
        return

    table = Table(title="Notebook Sessions", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Status", no_wrap=True)
    table.add_column("Created")

    for session in sessions:
        status_color = {
            "running": "green",
            "starting": "yellow",
            "stopped": "dim",
        }.get(session.status, "")

        status_text = f"[{status_color}]{session.status}[/{status_color}]" if status_color else session.status

        table.add_row(
            session.id[:12],
            status_text,
            _format_datetime(session.created_at),
        )

    console.print(table)


def print_notebook_document_table(documents: list[NotebookDocument]) -> None:
    """Print notebook documents in a table."""
    if json_output_enabled():
        emit_json(documents)
        return

    if not documents:
        console.print("[dim]No notebook documents found.[/dim]")
        return

    table = Table(title="Notebook Documents", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Workspace", style="dim")
    table.add_column("Kernel")
    table.add_column("Runtime")
    table.add_column("Auto Save")
    table.add_column("Updated")

    for doc in documents:
        metadata = doc.metadata
        kernel = metadata.kernel if metadata else "-"
        runtime = metadata.runtime if metadata else "-"
        auto_save = (
            "true"
            if metadata and metadata.auto_save_enabled is True
            else ("false" if metadata and metadata.auto_save_enabled is False else "-")
        )

        table.add_row(
            doc.id[:12],
            doc.name,
            doc.workspace_id[:12],
            kernel or "-",
            runtime or "-",
            auto_save,
            _format_datetime(doc.updated_at),
        )

    console.print(table)


def print_notebook_document_detail(document: NotebookDocument) -> None:
    """Print notebook document details."""
    if json_output_enabled():
        emit_json(document)
        return

    table = Table(
        title=f"Notebook Document: {document.id}",
        box=box.ROUNDED,
        show_header=False,
    )
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    metadata = document.metadata
    table.add_row("ID", document.id)
    table.add_row("Name", document.name)
    table.add_row("Workspace", document.workspace_id)
    table.add_row("Description", document.description or "-")
    table.add_row("File Path", document.file_path)
    table.add_row("Kernel", metadata.kernel if metadata and metadata.kernel else "-")
    table.add_row("Runtime", metadata.runtime if metadata and metadata.runtime else "-")
    table.add_row(
        "Auto Save",
        (
            "true"
            if metadata and metadata.auto_save_enabled is True
            else (
                "false"
                if metadata and metadata.auto_save_enabled is False
                else "-"
            )
        ),
    )
    table.add_row("Created", _format_datetime(document.created_at))
    table.add_row("Updated", _format_datetime(document.updated_at))

    console.print(table)


# =============================================================================
# Notebook Cell Tables
# =============================================================================


def _truncate(text: str, max_len: int = 30) -> str:
    """Truncate text with ellipsis."""
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + "..."


def _format_cell_output_preview(outputs: list[CellOutput]) -> str:
    """Format cell outputs as a short preview."""
    if not outputs:
        return "-"

    for output in outputs:
        if output.output_type == "error":
            return f"[red]{output.ename}: {_truncate(output.evalue or '', 20)}[/red]"
        elif output.output_type == "stream":
            text = (output.text or "").strip()
            return _truncate(text, 30) if text else "-"
        elif output.output_type == "execute_result":
            if output.data:
                if "text/plain" in output.data:
                    return _truncate(str(output.data["text/plain"]), 30)
                return f"[dim]<{list(output.data.keys())[0]}>[/dim]"
        elif output.output_type == "display_data":
            if output.data:
                if "image/png" in output.data or "image/jpeg" in output.data:
                    return "[dim]<image>[/dim]"
                return f"[dim]<{list(output.data.keys())[0]}>[/dim]"

    return "-"


def _colored_cell_status(status: str | None) -> str:
    """Return colored status string."""
    if not status:
        return "-"
    colors = {
        "ok": "green",
        "running": "blue",
        "error": "red",
        "starting": "yellow",
    }
    color = colors.get(status, "")
    return f"[{color}]{status}[/{color}]" if color else status


def print_cell_table(cells: list[NotebookCellDetail], json_output: bool = False) -> None:
    """Print cells in a table.

    Args:
        cells: List of cells with details
        json_output: If True, print as JSON
    """
    if json_output or json_output_enabled():
        data = [
            {
                "id": c.id,
                "index": c.cell_index,
                "type": c.cell_type,
                "source": c.source,
                "status": c.status,
                "executionCount": c.execution_count,
                "lastRunDuration": c.last_run_duration,
                "outputs": [o.model_dump(by_alias=True, exclude_none=True) for o in c.outputs],
            }
            for c in cells
        ]
        print(json.dumps(data, indent=2, default=str))
        return

    if not cells:
        console.print("[dim]No cells found.[/dim]")
        return

    table = Table(box=box.ROUNDED)
    table.add_column("#", style="dim", justify="right")
    table.add_column("ID", no_wrap=True)
    table.add_column("TYPE", no_wrap=True)
    table.add_column("STATUS", no_wrap=True)
    table.add_column("EXEC", justify="right")
    table.add_column("TIME", justify="right")
    table.add_column("SOURCE")
    table.add_column("OUTPUT")

    for cell in sorted(cells, key=lambda c: c.cell_index):
        exec_count = f"[{cell.execution_count}]" if cell.execution_count else "-"
        duration = f"{cell.last_run_duration:.2f}s" if cell.last_run_duration else "-"
        source_preview = _truncate(cell.source.split("\n")[0], 25)
        output_preview = _format_cell_output_preview(cell.outputs)

        type_style = {"code": "cyan", "markdown": "green", "raw": "dim"}.get(cell.cell_type, "")
        cell_type = f"[{type_style}]{cell.cell_type}[/{type_style}]" if type_style else cell.cell_type

        table.add_row(
            str(cell.cell_index),
            cell.id,
            cell_type,
            _colored_cell_status(cell.status),
            exec_count,
            duration,
            source_preview,
            output_preview,
        )

    console.print(table)


def print_cell_detail(cell: NotebookCellDetail, json_output: bool = False) -> None:
    """Print detailed cell information.

    Args:
        cell: Cell with details
        json_output: If True, print as JSON
    """
    if json_output or json_output_enabled():
        data = {
            "id": cell.id,
            "index": cell.cell_index,
            "type": cell.cell_type,
            "source": cell.source,
            "status": cell.status,
            "executionCount": cell.execution_count,
            "lastRunDuration": cell.last_run_duration,
            "outputs": [o.model_dump(by_alias=True, exclude_none=True) for o in cell.outputs],
        }
        print(json.dumps(data, indent=2, default=str))
        return

    # Header
    exec_info = ""
    if cell.execution_count:
        exec_info = f" [{cell.execution_count}]"
        if cell.last_run_duration:
            exec_info += f" ({cell.last_run_duration:.2f}s)"

    console.print(f"[bold]Cell:[/bold] {cell.id} (#{cell.cell_index})")
    console.print(f"[bold]Type:[/bold] {cell.cell_type}")
    if cell.status:
        console.print(f"[bold]Status:[/bold] {_colored_cell_status(cell.status)}{exec_info}")
    console.print()

    # Source
    console.print("[bold]-- Source ----------------------------------[/bold]")
    if cell.cell_type == "code":
        syntax = Syntax(cell.source, "python", theme="monokai", line_numbers=False)
        console.print(syntax)
    else:
        console.print(cell.source)
    console.print()

    # Outputs
    if cell.outputs:
        console.print("[bold]-- Output ----------------------------------[/bold]")
        for output in cell.outputs:
            _print_cell_output(output)


def _print_cell_output(output: CellOutput) -> None:
    """Print a single cell output."""
    if output.output_type == "stream":
        text = output.text or ""
        if output.name == "stderr":
            console.print(f"[red]{text}[/red]", end="")
        else:
            console.print(text, end="")
    elif output.output_type == "execute_result":
        if output.data and "text/plain" in output.data:
            console.print(output.data["text/plain"])
        elif output.data:
            console.print(f"[dim]<{', '.join(output.data.keys())}>[/dim]")
    elif output.output_type == "display_data":
        if output.data:
            if "image/png" in output.data or "image/jpeg" in output.data:
                console.print("[dim]<image data>[/dim]")
            elif "text/plain" in output.data:
                console.print(output.data["text/plain"])
            else:
                console.print(f"[dim]<{', '.join(output.data.keys())}>[/dim]")
    elif output.output_type == "error":
        console.print(f"[bold red]{output.ename}[/bold red]: {output.evalue}")
        if output.traceback:
            import re
            for line in output.traceback:
                # Strip ANSI codes for cleaner output
                clean_line = re.sub(r'\x1b\[[0-9;]*m', '', line)
                console.print(f"[dim]{clean_line}[/dim]")


def print_execution_result(result: dict, waited: bool = False) -> None:
    """Print execution result.

    Args:
        result: Execution result dict
        waited: Whether we waited for completion
    """
    if waited:
        # Show full output
        status = result.get("status", "unknown")
        duration = result.get("lastRunDuration")
        exec_count = result.get("executionCount")

        header = f"Execution [{exec_count}]" if exec_count else "Execution"
        if status == "ok":
            console.print(f"[green]{header} completed[/green]", end="")
        else:
            console.print(f"[red]{header} failed[/red]", end="")

        if duration:
            console.print(f" in {duration:.2f}s")
        else:
            console.print()

        console.print()

        if "outputs" in result:
            console.print("[bold]-- Output ----------------------------------[/bold]")
            for output in result["outputs"]:
                _print_cell_output(CellOutput(**output))
    else:
        # Fire and forget - just show execution ID
        exec_id = result.get("executionId", "unknown")
        console.print(f"Execution started (id: {exec_id})")


# =============================================================================
# Workspace Tables
# =============================================================================

def print_workspace_table(workspaces: list[Workspace]) -> None:
    """Print workspaces in a table.

    Args:
        workspaces: List of workspaces
    """
    if json_output_enabled():
        emit_json(workspaces)
        return

    if not workspaces:
        console.print("[dim]No workspaces found.[/dim]")
        return

    table = Table(title="Workspaces", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Created")

    for ws in workspaces:
        table.add_row(
            ws.id[:12],
            ws.name,
            _format_datetime(ws.created_at),
        )

    console.print(table)


# =============================================================================
# API Key Tables
# =============================================================================

def print_api_key_table(keys: list[APIKey]) -> None:
    """Print API keys in a table.

    Args:
        keys: List of API keys
    """
    if json_output_enabled():
        emit_json(keys)
        return

    if not keys:
        console.print("[dim]No API keys found.[/dim]")
        return

    table = Table(title="API Keys", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Key", style="dim")
    table.add_column("Last Used")
    table.add_column("Created")

    for key in keys:
        key_value = key.key or "sk_****************"
        last_used = _format_datetime(key.last_used) if key.last_used else "Never"

        table.add_row(
            key.id[:12],
            key.name or "-",
            key_value,
            last_used,
            _format_datetime(key.created_at),
        )

    console.print(table)


# =============================================================================
# Transaction Tables
# =============================================================================

def print_transaction_table(transactions: list[Transaction]) -> None:
    """Print transactions in a table.

    Args:
        transactions: List of transactions
    """
    if json_output_enabled():
        emit_json(transactions)
        return

    if not transactions:
        console.print("[dim]No transactions found.[/dim]")
        return

    table = Table(title="Transactions", box=box.ROUNDED)
    table.add_column("ID", style="dim")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Description")
    table.add_column("Amount", justify="right")
    table.add_column("Balance", justify="right")
    table.add_column("Date")

    for txn in transactions:
        amount_color = "green" if txn.amount_cents >= 0 else "red"
        amount = f"[{amount_color}]{_format_currency_from_cents(txn.amount_cents)}[/{amount_color}]"

        table.add_row(
            txn.id[:12],
            txn.type,
            txn.status,
            txn.description,
            amount,
            _format_currency_from_cents(txn.balance_after_cents),
            _format_datetime(txn.created_at),
        )

    console.print(table)


# =============================================================================
# Balance Display
# =============================================================================

def print_balance(balance: BalanceInfo) -> None:
    """Print account balance.

    Args:
        balance: Balance information
    """
    if json_output_enabled():
        emit_json(balance)
        return

    panel = Panel(
        "\n".join(
            [
                f"[bold green]{_format_currency_from_cents(balance.balance_cents)}[/bold green]",
                f"[dim]Billing Account:[/dim] {balance.billing_account_id}",
                f"[dim]Total Charged:[/dim] {_format_currency_from_cents(balance.total_charged_cents)}",
                f"[dim]Billing Enabled:[/dim] {'yes' if balance.billing_enabled else 'no'}",
            ]
        ),
        title="Account Balance",
        border_style="green",
    )
    console.print(panel)


# =============================================================================
# File Tables
# =============================================================================

def print_file_table(files: list[FileMetadata]) -> None:
    """Print files in a table.

    Args:
        files: List of file metadata
    """
    if json_output_enabled():
        emit_json(files)
        return

    if not files:
        console.print("[dim]No files found.[/dim]")
        return

    table = Table(title="Files", box=box.ROUNDED)
    table.add_column("Name")
    table.add_column("Size", justify="right")
    table.add_column("Type", style="dim")
    table.add_column("Modified")

    for file in files:
        name = f"[blue]{file.name}/[/blue]" if file.is_directory else file.name
        size = _format_size(file.size_bytes) if not file.is_directory else "-"

        table.add_row(
            name,
            size,
            file.mime_type or "-",
            _format_datetime(file.modified_at),
        )

    console.print(table)


# =============================================================================
# Config Display
# =============================================================================

def print_config(config: dict[str, Any]) -> None:
    """Print configuration.

    Args:
        config: Configuration dictionary
    """
    if json_output_enabled():
        emit_json(config)
        return

    table = Table(title="Configuration", box=box.ROUNDED, show_header=False)
    table.add_column("Key", style="cyan")
    table.add_column("Value")

    for key, value in sorted(config.items()):
        if value is None:
            value = "[dim]-[/dim]"
        elif isinstance(value, bool):
            value = "[green]true[/green]" if value else "[dim]false[/dim]"
        elif isinstance(value, dict):
            value = f"[dim]{{{len(value)} items}}[/dim]"
        elif isinstance(value, list):
            value = f"[dim][{', '.join(str(v) for v in value[:3])}][/dim]"
        else:
            value = str(value)

        table.add_row(key, value)

    console.print(table)


# =============================================================================
# Helpers
# =============================================================================

def _colored_status(status: str) -> str:
    """Get colored status string."""
    color = {
        "running": "green",
        "stopped": "yellow",
        "pending": "blue",
        "failed": "red",
        "terminated": "dim",
        "completed": "green",
        "in_progress": "yellow",
        "active": "green",
        "deleted": "dim",
    }.get(status, "")
    return f"[{color}]{status}[/{color}]" if color else status


def _format_datetime(dt: datetime | str) -> str:
    """Format datetime for display."""
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt

    now = datetime.now(dt.tzinfo)
    delta = now - dt

    if delta.days > 365:
        return dt.strftime("%Y-%m-%d")
    if delta.days > 7:
        return dt.strftime("%b %d")
    if delta.days > 0:
        return f"{delta.days}d ago"
    if delta.seconds >= 3600:
        hours = delta.seconds // 3600
        return f"{hours}h ago"
    if delta.seconds >= 60:
        minutes = delta.seconds // 60
        return f"{minutes}m ago"
    return "just now"


def _format_size(size_bytes: int | None) -> str:
    """Format size in bytes for display."""
    if size_bytes is None:
        return "-"

    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


# =============================================================================
# Error Display
# =============================================================================

def print_error(message: str, title: str = "Error") -> None:
    """Print error message.

    Args:
        message: Error message
        title: Panel title
    """
    if json_output_enabled():
        emit_json({"error": {"code": "CLI_ERROR", "title": title, "message": message}})
        return

    console.print(Panel(f"[red]{message}[/red]", title=title, border_style="red"))


def print_success(message: str) -> None:
    """Print success message.

    Args:
        message: Success message
    """
    if json_output_enabled():
        emit_json({"status": "success", "message": message})
        return

    console.print(f"[green]✓[/green] {message}")


def print_warning(message: str) -> None:
    """Print warning message.

    Args:
        message: Warning message
    """
    if json_output_enabled():
        emit_json({"status": "warning", "message": message})
        return

    console.print(f"[yellow]⚠[/yellow] {message}")


def print_info(message: str) -> None:
    """Print info message.

    Args:
        message: Info message
    """
    if json_output_enabled():
        emit_json({"status": "info", "message": message})
        return

    console.print(f"[blue]ℹ[/blue] {message}")
