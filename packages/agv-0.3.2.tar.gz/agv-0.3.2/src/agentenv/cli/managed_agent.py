"""Managed-agent CLI commands."""

from __future__ import annotations

import json
import sys
from collections.abc import Iterable

import typer

from ..api.client import APIError, Client
from ..api.managed_agent import ManagedAgentAPI
from ..api.models import (
    ManagedAgent,
    ManagedAgentListResponse,
    ManagedAgentMessage,
    ManagedAgentStreamEvent,
)
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    _colored_status,
    _format_datetime,
    emit_json,
    json_output_enabled,
    print_browser_table,
    print_error,
    print_success,
)

app = typer.Typer(
    help="Managed-agent commands",
    no_args_is_help=True,
)


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _wants_json(json_output: bool = False) -> bool:
    """Whether the current command should emit JSON."""
    return json_output or json_output_enabled()


def _print_managed_agent_table(
    result: ManagedAgentListResponse,
    *,
    json_output: bool = False,
) -> None:
    """Render a managed-agent list."""
    if _wants_json(json_output):
        emit_json(result)
        return

    from rich.console import Console
    from rich.table import Table

    if not result.agents:
        Console().print("[dim]No managed agents found.[/dim]")
        return

    table = Table(title=f"Managed Agents ({result.total})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Workspace", no_wrap=True)
    table.add_column("Model")
    table.add_column("Updated", no_wrap=True)

    for agent in result.agents:
        table.add_row(
            agent.id,
            agent.name,
            _colored_status(agent.status),
            agent.workspace_id,
            agent.config.model,
            _format_datetime(agent.updated_at),
        )

    Console().print(table)


def _print_managed_agent_detail(
    agent: ManagedAgent,
    *,
    json_output: bool = False,
) -> None:
    """Render managed-agent details."""
    if _wants_json(json_output):
        emit_json(agent)
        return

    from rich.console import Console
    from rich.table import Table

    table = Table(title=f"Managed Agent: {agent.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", agent.id)
    table.add_row("Workspace", agent.workspace_id)
    table.add_row("Sandbox", agent.sandbox_id or "-")
    table.add_row("Status", _colored_status(agent.status))
    table.add_row("Upstream", agent.config.upstream_id)
    table.add_row("Model", agent.config.model)
    table.add_row("Instructions", agent.config.instructions or "-")
    table.add_row(
        "CPU / Memory",
        f"{agent.config.cpu_millis or '-'} / {agent.config.memory_mb or '-'}",
    )
    table.add_row("Created", _format_datetime(agent.created_at))
    table.add_row("Updated", _format_datetime(agent.updated_at))

    if agent.metadata:
        table.add_section()
        table.add_row("Thread", agent.metadata.thread_id or "-")
        table.add_row("Runtime WS", agent.metadata.runtime_ws_url or "-")
        table.add_row("Last Error", agent.metadata.last_error or "-")
        table.add_row(
            "Last Activity",
            _format_datetime(agent.metadata.last_activity_at)
            if agent.metadata.last_activity_at
            else "-",
        )

    Console().print(table)


def _print_message_table(
    messages: list[ManagedAgentMessage],
    *,
    json_output: bool = False,
) -> None:
    """Render transcript messages."""
    if _wants_json(json_output):
        emit_json(messages)
        return

    from rich.console import Console
    from rich.table import Table

    if not messages:
        Console().print("[dim]No managed-agent messages found.[/dim]")
        return

    table = Table(title="Managed Agent Messages")
    table.add_column("Created", no_wrap=True)
    table.add_column("Role", no_wrap=True)
    table.add_column("Kind", no_wrap=True)
    table.add_column("Content")

    for message in messages:
        content = (message.content or "").strip() or "-"
        table.add_row(
            _format_datetime(message.created_at),
            message.role,
            message.kind,
            content,
        )

    Console().print(table)


def _parse_prompt(prompt: list[str] | None) -> str:
    """Normalize free-form message content."""
    content = " ".join(prompt).strip() if prompt else ""
    if content:
        return content
    print_error("Message content is required.")
    raise typer.Exit(1)


def _stream_assistant_output(
    events: Iterable[ManagedAgentStreamEvent],
) -> tuple[list[ManagedAgentStreamEvent], bool]:
    """Render assistant output as events arrive while retaining a fallback copy."""
    deltas_seen: set[str] = set()
    completed_messages: list[str] = []
    printed = False
    collected: list[ManagedAgentStreamEvent] = []

    for event in events:
        collected.append(event)
        payload = event.model_dump(exclude_none=True)
        event_type = payload.get("type")
        message_id = str(payload.get("messageId", "message"))

        if event_type == "message.delta":
            delta = payload.get("delta")
            if isinstance(delta, str) and delta:
                sys.stdout.write(delta)
                sys.stdout.flush()
                deltas_seen.add(message_id)
                printed = True
            continue

        if event_type == "message.completed" and payload.get("content"):
            if message_id in deltas_seen:
                continue
            completed_messages.append(str(payload["content"]))

    if printed:
        if completed_messages:
            sys.stdout.write("\n\n" + "\n\n".join(completed_messages))
        sys.stdout.write("\n")
        sys.stdout.flush()
        return collected, True

    if completed_messages:
        print("\n\n".join(completed_messages))
        return collected, True

    return collected, False


def _emit_stream_events(events: Iterable[ManagedAgentStreamEvent]) -> None:
    """Print raw stream events one JSON object per line."""
    for event in events:
        print(json.dumps(event.model_dump(by_alias=True, exclude_none=True), default=str))


def _wake_before_send(
    api: ManagedAgentAPI,
    agent_id: str,
    *,
    timeout: float,
) -> None:
    """Wake a sleeping managed agent before sending a message."""
    agent = api.get(agent_id)
    if agent.status != "sleeping":
        return

    with status(f"Waking managed agent {agent_id}..."):
        try:
            api.wake(agent_id)
        except APIError:
            # The backend may already be waking the agent. Poll the status either way.
            pass
        api.wait_for_status(agent_id, desired_status="running", timeout=timeout)


@app.command("ls")
def list_managed_agents(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    agent_workspace_group_id: str | None = typer.Option(
        None,
        "--agent-workspace-group-id",
        help="Agent workspace group ID",
    ),
    search: str | None = typer.Option(
        None,
        "--search",
        help="Search by agent or workspace group name",
    ),
    page: int | None = typer.Option(None, "--page", min=1, help="Page number"),
    limit: int | None = typer.Option(None, "--limit", min=1, help="Page size"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List managed agents."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        result = api.list_all(
            workspace_id=workspace_id,
            agent_workspace_group_id=agent_workspace_group_id,
            search=search,
            page=page,
            limit=limit,
        )
    except APIError as exc:
        print_error(f"Failed to list managed agents: {exc.message}")
        raise typer.Exit(1)

    _print_managed_agent_table(result, json_output=json_output)


@app.command("list", deprecated=True)
def list_managed_agents_alt() -> None:
    """List managed agents (alias for ls)."""
    list_managed_agents()


@app.command("create")
def create_managed_agent(
    name: str = typer.Option(..., "--name", help="Managed-agent name"),
    workspace_id: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    upstream_id: str = typer.Option(..., "--upstream-id", help="AI gateway upstream ID"),
    model: str | None = typer.Option(None, "--model", help="Model override"),
    instructions: str | None = typer.Option(
        None,
        "--instructions",
        help="Developer instructions",
    ),
    image: str | None = typer.Option(
        None,
        "--image",
        help="Managed-agent image override",
    ),
    workspace_template: str | None = typer.Option(
        None,
        "--workspace-template",
        help="Bundled workspace template name when enabled by the server",
    ),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    agent_workspace_group_id: str | None = typer.Option(
        None,
        "--agent-workspace-group-id",
        help="Agent workspace group ID",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a managed agent using --image or the server default."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Creating managed agent '{name}'..."):
            agent = api.create(
                name=name,
                workspace_id=workspace_id,
                upstream_id=upstream_id,
                model=model,
                instructions=instructions,
                image=image,
                workspace_template=workspace_template,
                cpu_millis=cpu,
                memory_mb=memory,
                agent_workspace_group_id=agent_workspace_group_id,
            )
    except APIError as exc:
        print_error(f"Failed to create managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent {agent.id} created")
    print(f"  Name: {agent.name}")
    print(f"  Status: {agent.status}")

@app.command()
def inspect(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show managed-agent details."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        agent = api.get(agent_id)
    except APIError as exc:
        print_error(f"Failed to get managed agent: {exc.message}")
        raise typer.Exit(1)

    _print_managed_agent_detail(agent, json_output=json_output)


@app.command("messages")
def list_messages(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List transcript messages for a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        messages = api.list_messages(agent_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent messages: {exc.message}")
        raise typer.Exit(1)

    _print_message_table(messages, json_output=json_output)


@app.command("history", deprecated=True)
def list_messages_alt(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List transcript messages (alias for messages)."""
    list_messages(agent_id=agent_id, json_output=json_output)


@app.command("send")
def send_message(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    events: bool = typer.Option(False, "--events", help="Print raw stream events"),
    wake: bool = typer.Option(
        True,
        "--wake/--no-wake",
        help="Wake the managed agent first when it is sleeping",
    ),
    wake_timeout: float = typer.Option(
        120.0,
        "--wake-timeout",
        min=0.0,
        help="Seconds to wait for a sleeping agent to wake before sending",
    ),
    prompt: list[str] = typer.Argument(None, help="Message content"),
) -> None:
    """Send a message to a managed agent."""
    content = _parse_prompt(prompt)
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        if wake:
            _wake_before_send(api, agent_id, timeout=wake_timeout)
        if _wants_json(json_output):
            with status(f"Sending message to managed agent {agent_id}..."):
                stream_events = api.send_message(agent_id, content)
        else:
            event_stream = api.stream_message(agent_id, content)
            if events:
                _emit_stream_events(event_stream)
                return
            stream_events, rendered = _stream_assistant_output(event_stream)
    except APIError as exc:
        print_error(f"Failed to send managed-agent message: {exc.message}")
        raise typer.Exit(1)
    except (RuntimeError, TimeoutError) as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(stream_events)
        return

    if rendered:
        return

    emit_json(stream_events)


@app.command("wake")
def wake_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Wake a sleeping managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Waking managed agent {agent_id}..."):
            agent = api.wake(agent_id)
    except APIError as exc:
        print_error(f"Failed to wake managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent {agent_id} wake requested")


@app.command("fork")
def fork_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Fork a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Forking managed agent {agent_id}..."):
            agent = api.fork(agent_id)
    except APIError as exc:
        print_error(f"Failed to fork managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent fork created: {agent.id}")


@app.command("rm")
def delete_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed agent."""
    if not force:
        typer.confirm(f"Delete managed agent {agent_id}?", abort=True)

    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Deleting managed agent {agent_id}..."):
            result = api.delete(agent_id)
    except APIError as exc:
        print_error(f"Failed to delete managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(result)
        return

    print_success(f"Managed agent {agent_id} deleted")


@app.command("delete", deprecated=True)
def delete_managed_agent_alt(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed agent (alias for rm)."""
    delete_managed_agent(agent_id=agent_id, force=True, json_output=json_output)


@app.command("file-content")
def get_file_content(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    content_hash: str = typer.Argument(..., help="CAS content hash"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read managed-agent file content by CAS hash."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.get_file_content(agent_id, content_hash)
    except APIError as exc:
        print_error(f"Failed to get managed-agent file content: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("file")
def read_file(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    path: str = typer.Option(..., "--path", help="File path"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read current file content from a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.read_file(agent_id, path)
    except APIError as exc:
        print_error(f"Failed to read managed-agent file: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("git-show")
def git_show_file(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    path: str = typer.Option(..., "--path", help="Workspace file path"),
    ref: str = typer.Option("HEAD", "--ref", help="Git ref"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read committed file content from a managed agent via git show."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.git_show(agent_id, path, ref=ref)
    except APIError as exc:
        print_error(f"Failed to read managed-agent git content: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("browser-sessions")
def list_browser_sessions(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List browser sessions for a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        sessions = api.list_browser_sessions(agent_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent browser sessions: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(sessions)
        return

    print_browser_table(sessions)
