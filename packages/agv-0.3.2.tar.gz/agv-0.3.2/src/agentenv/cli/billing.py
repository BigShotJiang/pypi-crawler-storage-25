"""Billing CLI commands."""

from __future__ import annotations

import json
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

import typer
from rich import box
from rich.console import Console
from rich.table import Table

from ..api.auth import AuthAPI
from ..api.billing import BillingAPI
from ..api.client import APIError, Client
from ..api.workspace import WorkspaceAPI
from ..config.settings import get_settings
from ..ui.tables import print_balance, print_error, print_transaction_table

app = typer.Typer(help="Billing and payment commands", no_args_is_help=True)
account_app = typer.Typer(help="Billing account discovery commands", no_args_is_help=True)
app.add_typer(account_app, name="account")

console = Console()


def _print_json(data: object) -> None:
    print(json.dumps(data, indent=2, default=str))


def _transaction_payload(
    transactions: list[Any],
    *,
    total: int | None = None,
    page: int | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "transactions": [txn.model_dump(by_alias=True, exclude_none=True) for txn in transactions]
    }
    if total is not None:
        payload["total"] = total
    if page is not None:
        payload["page"] = page
    if limit is not None:
        payload["limit"] = limit
    return payload


def _fail(
    message: str,
    *,
    json_output: bool,
    code: str,
    details: dict[str, Any] | None = None,
) -> None:
    if json_output:
        payload: dict[str, Any] = {"error": {"code": code, "message": message}}
        if details:
            payload["error"]["details"] = details
        _print_json(payload)
    else:
        print_error(message)
    raise typer.Exit(1)


def _map_api_error_code(error: APIError) -> str:
    if isinstance(error.details, dict) and isinstance(error.details.get("code"), str):
        return error.details["code"]
    if error.status_code == 400:
        if error.message == "Workspace is not linked to the billing account.":
            return "WORKSPACE_ACCOUNT_MISMATCH"
        return "INVALID_ARGUMENT"
    if error.status_code == 402:
        return "PAYMENT_REQUIRED"
    if error.status_code == 401:
        return "AUTH_REQUIRED"
    if error.status_code == 403:
        return "PERMISSION_DENIED"
    if error.status_code == 404:
        return "BILLING_ACCOUNT_REQUIRED"
    if error.status_code == 409:
        return "IDEMPOTENCY_CONFLICT"
    if error.status_code == 422:
        return "INVALID_ARGUMENT"
    return "CLI_ERROR"


def _fail_api(action: str, error: APIError, *, json_output: bool) -> None:
    _fail(
        f"Failed to {action}: {error.message}",
        json_output=json_output,
        code=_map_api_error_code(error),
        details=error.details or None,
    )


def get_client(*, json_output: bool = False) -> Client:
    """Get an authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        _fail(
            "Not authenticated. Run 'av login' first.",
            json_output=json_output,
            code="AUTH_REQUIRED",
        )

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _resolve_workspace_id(
    *,
    configured_workspace_id: str | None,
    selected_workspace_id: str | None,
    json_output: bool,
) -> str:
    workspace_id = configured_workspace_id or selected_workspace_id
    if workspace_id:
        return workspace_id
    _fail(
        "No workspace specified. Use --workspace or set a default with 'av workspace use'.",
        json_output=json_output,
        code="WORKSPACE_REQUIRED",
    )


@app.command("balance")
def show_balance(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Show balance for the current workspace billing context."""
    resolved_workspace_id = _resolve_workspace_id(
        configured_workspace_id=workspace_id,
        selected_workspace_id=get_settings().workspace,
        json_output=json_output,
    )
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        balance = api.get_balance(resolved_workspace_id)
    except APIError as exc:
        _fail_api("get balance", exc, json_output=json_output)

    if json_output:
        _print_json(balance.model_dump(by_alias=True, exclude_none=True))
        return

    print_balance(balance)


@app.command("history")
def show_history(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    page: int = typer.Option(1, min=1, help="Page number"),
    limit: int = typer.Option(50, min=1, max=200, help="Items per page"),
    start_date: str | None = typer.Option(
        None, "--start-date", help="Filter transactions created on/after YYYY-MM-DD"
    ),
    end_date: str | None = typer.Option(
        None, "--end-date", help="Filter transactions created on/before YYYY-MM-DD"
    ),
    include_types: list[str] | None = typer.Option(
        None, "--include-type", help="Include only these transaction types"
    ),
    exclude_types: list[str] | None = typer.Option(
        None, "--exclude-type", help="Exclude these transaction types"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Show transaction history for the current workspace billing context."""
    resolved_workspace_id = _resolve_workspace_id(
        configured_workspace_id=workspace_id,
        selected_workspace_id=get_settings().workspace,
        json_output=json_output,
    )
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        result = api.get_transactions(
            resolved_workspace_id,
            page=page,
            limit=limit,
            start_date=start_date,
            end_date=end_date,
            include_types=include_types,
            exclude_types=exclude_types,
        )
    except APIError as exc:
        _fail_api("get transactions", exc, json_output=json_output)

    transactions = result["transactions"]

    if json_output:
        _print_json(
            _transaction_payload(
                transactions,
                total=result.get("total"),
                page=result.get("page"),
                limit=result.get("limit"),
            )
        )
        return

    print_transaction_table(transactions)
    console.print(
        f"[dim]Showing page {result.get('page', page)} of workspace history "
        f"({len(transactions)} items, total {result.get('total', len(transactions))}).[/dim]"
    )


def _render_account_table(accounts: list[dict[str, Any]]) -> None:
    if not accounts:
        console.print("[dim]No billing accounts found.[/dim]")
        return

    table = Table(title="Billing Accounts", box=box.ROUNDED)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name")
    table.add_column("Balance", justify="right")
    table.add_column("Charged", justify="right")
    table.add_column("Enabled")
    table.add_column("Default")

    for account in accounts:
        table.add_row(
            str(account["id"]),
            str(account.get("name") or "-"),
            _format_currency_from_cents(int(account.get("balanceCents", 0))),
            _format_currency_from_cents(int(account.get("totalChargedCents", 0))),
            "yes" if account.get("billingEnabled") else "no",
            "yes" if account.get("isDefault") else "no",
        )

    console.print(table)


def _render_account_detail(account: dict[str, Any]) -> None:
    table = Table(title=f"Billing Account: {account['id']}", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Name", str(account.get("name") or "-"))
    table.add_row("Owner", str(account.get("ownerId") or "-"))
    table.add_row("Balance", _format_currency_from_cents(int(account.get("balanceCents", 0))))
    table.add_row(
        "Total Charged",
        _format_currency_from_cents(int(account.get("totalChargedCents", 0))),
    )
    table.add_row("Billing Enabled", "yes" if account.get("billingEnabled") else "no")
    table.add_row(
        "Credit Limit",
        _format_currency_from_cents(int(account.get("creditLimitCents", 0))),
    )
    table.add_row("Default", "yes" if account.get("isDefault") else "no")
    console.print(table)


def _format_currency_from_cents(amount_cents: int) -> str:
    sign = "-" if amount_cents < 0 else ""
    dollars = abs(amount_cents) / 100
    return f"{sign}${dollars:,.2f}"


def _require_option(
    value: str | None,
    *,
    message: str,
    code: str,
    json_output: bool,
) -> str:
    if value:
        return value
    _fail(message, json_output=json_output, code=code)


def _parse_amount_to_cents(raw_amount: str, *, json_output: bool) -> int:
    try:
        amount = Decimal(raw_amount)
    except InvalidOperation:
        _fail(
            f"Invalid amount '{raw_amount}'. Use a USD decimal value like 10 or 10.50.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    if amount <= 0:
        _fail(
            "Amount must be greater than zero.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    normalized = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if normalized != amount:
        _fail(
            "Amount must use at most two decimal places.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    return int((normalized * 100).to_integral_value(rounding=ROUND_HALF_UP))


@account_app.command("ls")
def list_billing_accounts(
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """List billing accounts owned by the current user."""
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        accounts = api.list_billing_accounts()
    except APIError as exc:
        _fail_api("list billing accounts", exc, json_output=json_output)

    if json_output:
        _print_json(accounts)
        return

    _render_account_table(accounts)


@account_app.command("get")
def get_billing_account(
    billing_account_id: str = typer.Argument(..., help="Billing account ID"),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Get one billing account owned by the current user."""
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        account = api.get_billing_account(billing_account_id)
    except APIError as exc:
        _fail_api("get billing account", exc, json_output=json_output)

    if json_output:
        _print_json(account)
        return

    _render_account_detail(account)


@account_app.command("balance")
def get_billing_account_balance(
    billing_account_id: str = typer.Argument(..., help="Billing account ID"),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Get balance for one billing account owned by the current user."""
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        balance = api.get_billing_account_balance(billing_account_id)
    except APIError as exc:
        _fail_api("get billing account balance", exc, json_output=json_output)

    if json_output:
        _print_json(balance.model_dump(by_alias=True, exclude_none=True))
        return

    print_balance(balance)


@account_app.command("history")
def get_billing_account_history(
    billing_account_id: str = typer.Argument(..., help="Billing account ID"),
    page: int = typer.Option(1, "--page", min=1, help="Page number"),
    limit: int = typer.Option(50, "--limit", min=1, help="Page size"),
    start_date: str | None = typer.Option(None, "--start-date", help="Start date (YYYY-MM-DD)"),
    end_date: str | None = typer.Option(None, "--end-date", help="End date (YYYY-MM-DD)"),
    include_type: list[str] | None = typer.Option(
        None,
        "--include-type",
        help="Only include these transaction types; repeat to pass multiple values.",
    ),
    exclude_type: list[str] | None = typer.Option(
        None,
        "--exclude-type",
        help="Exclude these transaction types; repeat to pass multiple values.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Show transaction history for one billing account owned by the current user."""
    client = get_client(json_output=json_output)
    api = BillingAPI(client)

    try:
        result = api.get_billing_account_transactions(
            billing_account_id,
            page=page,
            limit=limit,
            start_date=start_date,
            end_date=end_date,
            include_types=include_type,
            exclude_types=exclude_type,
        )
    except APIError as exc:
        _fail_api("get billing account transactions", exc, json_output=json_output)

    transactions = result["transactions"]

    if json_output:
        _print_json(
            _transaction_payload(
                transactions,
                total=result.get("total"),
                page=result.get("page"),
                limit=result.get("limit"),
            )
        )
        return

    print_transaction_table(transactions)
    console.print(
        f"[dim]Showing page {result.get('page', page)} of account history "
        f"({len(transactions)} items, total {result.get('total', len(transactions))}).[/dim]"
    )


@app.command("whoami")
def billing_whoami(
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
) -> None:
    """Aggregate billing identity, workspace, and account context."""
    settings = get_settings()
    client = get_client(json_output=json_output)
    auth_api = AuthAPI(client)
    workspace_api = WorkspaceAPI(client)
    billing_api = BillingAPI(client)

    try:
        profile = auth_api.get_profile()
        workspace_id = _resolve_workspace_id(
            configured_workspace_id=settings.workspace,
            selected_workspace_id=profile.selected_workspace_id,
            json_output=json_output,
        )
        workspace = workspace_api.get(workspace_id)
        accounts = billing_api.list_billing_accounts()
    except APIError as exc:
        _fail_api("load billing identity", exc, json_output=json_output)

    payload = {
        "user": profile.model_dump(by_alias=True, exclude_none=True),
        "workspace": workspace.model_dump(by_alias=True, exclude_none=True),
        "billingAccounts": accounts,
    }

    if json_output:
        _print_json(payload)
        return

    console.print(f"[bold]User:[/bold] {profile.username}")
    console.print(f"[bold]Workspace:[/bold] {workspace.name} ({workspace.id})")
    console.print(
        f"[bold]Default Billing Account:[/bold] {workspace.default_billing_account_id or '-'}"
    )
    _render_account_table(accounts)
