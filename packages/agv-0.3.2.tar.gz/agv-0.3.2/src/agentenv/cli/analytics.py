"""Analytics CLI commands."""

import json
from datetime import datetime
from typing import Any, Optional

import typer

from ..api.client import Client
from ..api.analytics import AnalyticsAPI
from ..config.settings import get_settings
from ..ui.tables import (
    print_error,
    print_success,
    print_warning,
)
from ..ui.progress import status


app = typer.Typer(help="Analytics management commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _to_jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", by_alias=True)
    if isinstance(value, list):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _to_jsonable(item) for key, item in value.items()}
    return value


def _print_json(data: Any) -> None:
    print(json.dumps(_to_jsonable(data), indent=2, default=str))


def _parse_setting_items(items: Optional[list[str]]) -> dict[str, Any] | None:
    if not items:
        return None

    settings: dict[str, Any] = {}
    for item in items:
        if "=" not in item:
            print_error(f"Invalid setting format: {item}. Use key=value")
            raise typer.Exit(1)

        key, raw_value = item.split("=", 1)
        try:
            value = json.loads(raw_value)
        except json.JSONDecodeError:
            value = raw_value
        settings[key] = value

    return settings


def _parse_funnel_steps(steps: list[str]) -> list[dict[str, str]]:
    parsed_steps: list[dict[str, str]] = []
    for step in steps:
        if ":" not in step:
            print_error(f"Invalid step format: {step}. Use 'step_name:event_name'")
            raise typer.Exit(1)
        step_name, event_name = step.split(":", 1)
        parsed_steps.append({"name": step_name, "eventName": event_name})
    return parsed_steps


def _parse_datetime_option(value: str | None, option_name: str) -> datetime | None:
    if value is None:
        return None

    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        print_error(f"Invalid {option_name}: {value}. Use ISO 8601 or YYYY-MM-DD.")
        raise typer.Exit(1)


@app.command("installations")
def list_installations(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List analytics installations."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        installations = api.list_installations()

        if not installations:
            if json_output:
                _print_json([])
            else:
                print_warning("No installations found.")
            return

        if json_output:
            _print_json(installations)
        else:
            print(f"{'ID':<36} {'Name':<30} {'API Key':<40} {'Active'}")
            print("-" * 110)
            for inst in installations:
                print(f"{inst.id:<36} {inst.name:<30} {inst.api_key:<40} {inst.is_active}")
    except Exception as e:
        print_error(f"Failed to list installations: {e}")
        raise typer.Exit(1)


@app.command("create")
def create_installation(
    name: str = typer.Argument(..., help="Installation name"),
    allowed_domains: Optional[list[str]] = typer.Option(None, "--allowed-domain", help="Allowed domain; repeat for multiple"),
    setting: Optional[list[str]] = typer.Option(None, "--setting", help="Installation setting as key=value; repeat for multiple"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Create a new analytics installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        with status(f"Creating installation '{name}'..."):
            installation = api.create_installation(
                name,
                allowed_domains=allowed_domains,
                settings=_parse_setting_items(setting),
            )

        if json_output:
            _print_json(installation)
        else:
            print_success(f"Created installation: {installation.name}")
            print(f"API Key: {installation.api_key}")
            print(f"ID: {installation.id}")
    except Exception as e:
        print_error(f"Failed to create installation: {e}")
        raise typer.Exit(1)


@app.command("installation")
def get_installation(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Get analytics installation details."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        installation = api.get_installation(installation_id)

        if json_output:
            _print_json(installation)
        else:
            print(f"ID: {installation.id}")
            print(f"Name: {installation.name}")
            print(f"API Key: {installation.api_key}")
            print(f"Active: {installation.is_active}")
            print(f"Allowed Domains: {', '.join(installation.allowed_domains) or 'None'}")
            print(f"Created At: {installation.created_at}")
    except Exception as e:
        print_error(f"Failed to get installation: {e}")
        raise typer.Exit(1)


@app.command("update")
def update_installation(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    name: Optional[str] = typer.Option(None, "--name", help="Updated installation name"),
    allowed_domains: Optional[list[str]] = typer.Option(None, "--allowed-domain", help="Allowed domain; repeat for multiple"),
    setting: Optional[list[str]] = typer.Option(None, "--setting", help="Installation setting as key=value; repeat for multiple"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Update an analytics installation."""
    if name is None and allowed_domains is None and setting is None:
        print_error("Provide at least one update field: --name, --allowed-domain, or --setting.")
        raise typer.Exit(1)

    client = get_client()
    api = AnalyticsAPI(client)

    try:
        installation = api.update_installation(
            installation_id,
            name=name,
            allowed_domains=allowed_domains,
            settings=_parse_setting_items(setting),
        )

        if json_output:
            _print_json(installation)
        else:
            print_success(f"Updated installation: {installation.name}")
            print(f"ID: {installation.id}")
    except Exception as e:
        print_error(f"Failed to update installation: {e}")
        raise typer.Exit(1)


@app.command("delete")
def delete_installation(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Delete an analytics installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        api.delete_installation(installation_id)
        if json_output:
            _print_json({"success": True, "installationId": installation_id})
        else:
            print_success(f"Deleted installation: {installation_id}")
    except Exception as e:
        print_error(f"Failed to delete installation: {e}")
        raise typer.Exit(1)


@app.command("hide")
def hide_installation(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Hide an example analytics installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        result = api.hide_installation(installation_id)
        if json_output:
            _print_json(result)
        elif result.get("success"):
            print_success(f"Hidden installation: {installation_id}")
        else:
            print_warning(f"Installation was not hidden: {installation_id}")
    except Exception as e:
        print_error(f"Failed to hide installation: {e}")
        raise typer.Exit(1)


@app.command("unhide")
def unhide_installation(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Unhide an example analytics installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        result = api.unhide_installation(installation_id)
        if json_output:
            _print_json(result)
        elif result.get("success"):
            print_success(f"Unhid installation: {installation_id}")
        else:
            print_warning(f"Installation was not unhidden: {installation_id}")
    except Exception as e:
        print_error(f"Failed to unhide installation: {e}")
        raise typer.Exit(1)


@app.command("script")
def get_script(
    installation_id: str = typer.Argument(..., help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Get installation script tag."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        script_data = api.get_installation_script(installation_id)
        if json_output:
            _print_json(script_data)
        else:
            print(script_data.get("scriptTag", ""))
    except Exception as e:
        print_error(f"Failed to get script: {e}")
        raise typer.Exit(1)


@app.command("stats")
def get_stats(
    installation_id: Optional[str] = typer.Option(None, "--installation", help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Get analytics statistics."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        stats = api.get_stats(installation_id)

        if json_output:
            _print_json(stats)
        else:
            print(f"Total Sessions: {stats.get('totalSessions', 0)}")
            print(f"Total Page Views: {stats.get('totalPageViews', 0)}")
            print(f"Unique Visitors: {stats.get('uniqueVisitors', 0)}")
            print(f"Total Events: {stats.get('totalEvents', 0)}")
            print(f"Total Users: {stats.get('totalUsers', 0)}")
    except Exception as e:
        print_error(f"Failed to get stats: {e}")
        raise typer.Exit(1)


@app.command("events")
def list_events(
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    event_name: Optional[str] = typer.Option(None, "--event-name", help="Filter by event name"),
    fingerprint: Optional[str] = typer.Option(None, "--fingerprint", help="Filter by user fingerprint"),
    start_date: Optional[str] = typer.Option(None, "--start-date", help="Start date (ISO 8601 or YYYY-MM-DD)"),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="End date (ISO 8601 or YYYY-MM-DD)"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of events"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List analytics events for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        events = api.query_events(
            installation_id=installation,
            event_name=event_name,
            fingerprint=fingerprint,
            start_date=_parse_datetime_option(start_date, "--start-date"),
            end_date=_parse_datetime_option(end_date, "--end-date"),
            limit=limit,
        )

        if not events:
            if json_output:
                _print_json([])
            else:
                print_warning("No events found.")
            return

        if json_output:
            _print_json(events)
        else:
            print(f"{'ID':<36} {'Name':<30} {'Fingerprint':<20} {'Timestamp'}")
            print("-" * 100)
            for event in events:
                timestamp = event.timestamp.strftime("%Y-%m-%d %H:%M") if event.timestamp else "N/A"
                print(f"{event.id:<36} {event.event_name:<30} {event.fingerprint[:20]:<20} {timestamp}")
    except Exception as e:
        print_error(f"Failed to list events: {e}")
        raise typer.Exit(1)


@app.command("funnels")
def list_funnels(
    installation: Optional[str] = typer.Option(None, "--installation", help="Installation ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List analytics funnels."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        funnels = api.list_funnels(installation_id=installation)

        if not funnels:
            if json_output:
                _print_json([])
            else:
                print_warning("No funnels found.")
            return

        if json_output:
            _print_json(funnels)
        else:
            print(f"{'ID':<36} {'Name':<30} {'Steps':<10} {'Active'}")
            print("-" * 80)
            for funnel in funnels:
                print(f"{funnel.id:<36} {funnel.name:<30} {len(funnel.steps):<10} {funnel.is_active}")
    except Exception as e:
        print_error(f"Failed to list funnels: {e}")
        raise typer.Exit(1)


@app.command("funnel-create")
def create_funnel(
    name: str = typer.Argument(..., help="Funnel name"),
    steps: list[str] = typer.Option(..., "--step", help="Funnel steps (format: 'step_name:event_name')"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Create a new funnel."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        parsed_steps = _parse_funnel_steps(steps)

        funnel = api.create_funnel(name, parsed_steps)
        if json_output:
            _print_json(funnel)
        else:
            print_success(f"Created funnel: {funnel.name}")
            print(f"ID: {funnel.id}")
            print(f"Steps: {len(funnel.steps)}")
    except Exception as e:
        print_error(f"Failed to create funnel: {e}")
        raise typer.Exit(1)


@app.command("funnel-update")
def update_funnel(
    funnel_id: str = typer.Argument(..., help="Funnel ID"),
    name: Optional[str] = typer.Option(None, "--name", help="Updated funnel name"),
    steps: Optional[list[str]] = typer.Option(None, "--step", help="Funnel steps (format: 'step_name:event_name'); repeat for multiple"),
    is_active: Optional[bool] = typer.Option(None, "--active/--inactive", help="Set funnel active state"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Update an analytics funnel."""
    if name is None and steps is None and is_active is None:
        print_error("Provide at least one update field: --name, --step, or --active/--inactive.")
        raise typer.Exit(1)

    client = get_client()
    api = AnalyticsAPI(client)

    try:
        funnel = api.update_funnel(
            funnel_id,
            name=name,
            steps=_parse_funnel_steps(steps) if steps is not None else None,
            is_active=is_active,
        )

        if json_output:
            _print_json(funnel)
        else:
            print_success(f"Updated funnel: {funnel.name}")
            print(f"ID: {funnel.id}")
            print(f"Steps: {len(funnel.steps)}")
    except Exception as e:
        print_error(f"Failed to update funnel: {e}")
        raise typer.Exit(1)


@app.command("funnel-delete")
def delete_funnel(
    funnel_id: str = typer.Argument(..., help="Funnel ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Delete an analytics funnel."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        api.delete_funnel(funnel_id)
        if json_output:
            _print_json({"success": True, "funnelId": funnel_id})
        else:
            print_success(f"Deleted funnel: {funnel_id}")
    except Exception as e:
        print_error(f"Failed to delete funnel: {e}")
        raise typer.Exit(1)


@app.command("funnel-analyze")
def analyze_funnel(
    funnel_id: str = typer.Argument(..., help="Funnel ID"),
    installation: Optional[str] = typer.Option(None, "--installation", help="Installation ID"),
    days: int = typer.Option(7, "--days", help="Number of days to analyze"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Analyze funnel conversion."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        analysis = api.analyze_funnel(funnel_id, installation_id=installation, days=days)

        if json_output:
            _print_json(analysis)
        else:
            print(f"Funnel: {analysis.get('funnelName', 'Unknown')}")
            print(f"Total Conversion: {analysis.get('totalConversion', 0):.2f}%")
            print()

            steps = analysis.get('steps', [])
            print(f"{'Step':<6} {'Name':<30} {'Users':<10} {'Conversion %':<15} {'Drop-off %'}")
            print("-" * 80)
            for step in steps:
                print(f"{step.get('step', 0):<6} {step.get('name', ''):<30} "
                      f"{step.get('uniqueUsers', 0):<10} {step.get('conversionRate', 0):<15.2f} "
                      f"{step.get('dropOffRate', 0):.2f}")
    except Exception as e:
        print_error(f"Failed to analyze funnel: {e}")
        raise typer.Exit(1)


@app.command("users")
def list_users(
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of users"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List user profiles for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        users = api.list_users(installation_id=installation, limit=limit)

        if not users:
            if json_output:
                _print_json([])
            else:
                print_warning("No users found.")
            return

        if json_output:
            _print_json(users)
        else:
            print(f"{'Fingerprint':<20} {'Email':<30} {'Sessions':<10} {'Last Seen'}")
            print("-" * 80)
            for user in users:
                email = user.email or "N/A"
                last_seen = user.last_seen_at.strftime("%Y-%m-%d") if user.last_seen_at else "N/A"
                print(f"{user.fingerprint[:20]:<20} {email:<30} {user.session_count:<10} {last_seen}")
    except Exception as e:
        print_error(f"Failed to list users: {e}")
        raise typer.Exit(1)


@app.command("user-profile")
def get_user_profile(
    fingerprint: str = typer.Argument(..., help="User fingerprint"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Get an analytics user profile."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        user = api.get_user_profile(fingerprint)
        if user is None:
            if json_output:
                _print_json(None)
            else:
                print_warning("No user profile found.")
            return

        if json_output:
            _print_json(user)
        else:
            print(f"Fingerprint: {user.fingerprint}")
            print(f"Email: {user.email or 'N/A'}")
            print(f"Name: {user.name or 'N/A'}")
            print(f"Sessions: {user.session_count}")
            print(f"First Seen: {user.first_seen_at or 'N/A'}")
            print(f"Last Seen: {user.last_seen_at or 'N/A'}")
    except Exception as e:
        print_error(f"Failed to get user profile: {e}")
        raise typer.Exit(1)


@app.command("trajectory")
def get_trajectory(
    fingerprint: str = typer.Argument(..., help="User fingerprint"),
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Get user trajectory for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        trajectory = api.get_trajectory(fingerprint, installation_id=installation)

        if not trajectory:
            if json_output:
                _print_json([])
            else:
                print_warning("No trajectory found for this fingerprint.")
            return

        if json_output:
            _print_json(trajectory)
        else:
            for session in trajectory:
                print(f"Session: {session.get('sessionId', 'Unknown')}")
                print(f"  Started: {session.get('startedAt', 'N/A')}")
                print(f"  Duration: {session.get('duration', 0)}s")
                print(f"  Pages visited:")
                for page in session.get('pages', []):
                    print(f"    - {page.get('url', 'Unknown')} ({page.get('timestamp', 'N/A')})")
                print()
    except Exception as e:
        print_error(f"Failed to get trajectory: {e}")
        raise typer.Exit(1)
