"""Browser session CLI commands."""

import webbrowser
from typing import Any

import typer

from ..api.browser import BrowserAPI
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_browser_table,
    print_error,
    print_success,
    print_warning,
)

app = typer.Typer(help="Browser session commands")
profile_app = typer.Typer(help="Browser profile commands")
app.add_typer(profile_app, name="profile")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _normalize_profile_mode(profile_mode: str) -> str:
    """Keep backward compatibility with the old incognito alias."""
    return "ephemeral" if profile_mode == "incognito" else profile_mode


def _build_geonode_proxy_payload(
    *,
    enabled: bool,
    mode: str | None,
    domains: list[str],
) -> dict | None:
    """Build geonode proxy payload when the related options are provided."""
    if not enabled and not mode and not domains:
        return None
    if not mode:
        print_error("Geonode proxy requires --geonode-mode")
        raise typer.Exit(1)
    if not domains:
        print_error("Geonode proxy requires at least one --geonode-domain")
        raise typer.Exit(1)
    return {
        "enabled": enabled or bool(mode or domains),
        "mode": mode,
        "domains": domains,
    }


def _open_session_url(url: str | None) -> None:
    """Open the first browser-openable URL we have."""
    if url and url.startswith(("http://", "https://")):
        webbrowser.open(url)


def _add_detail_row(table: Any, label: str, value: Any) -> None:
    """Add a detail row when a value is present."""
    if value is None or value == "":
        return
    table.add_row(label, str(value))


def _print_profile_table(profiles: list[dict[str, Any]]) -> None:
    """Render browser profiles in table or JSON form."""
    if json_output_enabled():
        emit_json(profiles)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    table = Table(title="Browser Profiles")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Workspace")
    table.add_column("Cookies", justify="right")
    table.add_column("Active")
    table.add_column("Created")

    for profile in profiles:
        table.add_row(
            profile.get("id", "-"),
            profile.get("name", "-"),
            profile.get("workspaceId", "-"),
            str(profile.get("cookieCount", 0) if profile.get("cookieCount") is not None else "-"),
            "yes" if profile.get("isActive", False) else "no",
            _format_datetime(profile.get("createdAt")),
        )

    Console().print(table)


def _print_profile_detail(profile: dict[str, Any]) -> None:
    """Render a single browser profile in table or JSON form."""
    if json_output_enabled():
        emit_json(profile)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    table = Table(title=f"Browser Profile: {profile.get('id', '-')}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", profile.get("id", "-"))
    table.add_row("Name", profile.get("name", "-"))
    table.add_row("Workspace", profile.get("workspaceId", "-"))
    table.add_row("Description", profile.get("description") or "-")
    table.add_row("Chrome User Data Dir", profile.get("chromeUserDataDir", "-"))
    table.add_row("Active", "yes" if profile.get("isActive", False) else "no")
    if profile.get("cookieCount") is not None:
        table.add_row("Cookies", str(profile["cookieCount"]))
    table.add_row("Created", _format_datetime(profile.get("createdAt")))
    table.add_row("Updated", _format_datetime(profile.get("updatedAt")))

    Console().print(table)


@app.callback(invoke_without_command=True)
def browser_entrypoint(
    ctx: typer.Context,
    name: str | None = typer.Option(None, "--name", help="Browser session name"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID",
    ),
    screen_width: int = typer.Option(1280, "--screen-width", "--width", help="Screen width"),
    screen_height: int = typer.Option(720, "--screen-height", "--height", help="Screen height"),
    stealth: bool = typer.Option(False, "--stealth", help="Enable stealth mode"),
    adblock: bool = typer.Option(False, "--adblock", help="Enable ad blocking"),
    profile_mode: str = typer.Option(
        "persistent",
        "--profile-mode",
        "--profile",
        help="Profile mode (persistent, ephemeral)",
    ),
    profile_id: str | None = typer.Option(None, "--profile-id", help="Browser profile ID"),
    proxy_url: str | None = typer.Option(None, "--proxy-url", help="Proxy URL"),
    proxy_username: str | None = typer.Option(None, "--proxy-username", help="Proxy username"),
    proxy_password: str | None = typer.Option(None, "--proxy-password", help="Proxy password"),
    proxy_provider: str | None = typer.Option(None, "--proxy-provider", help="Managed proxy provider"),
    proxy_type: str | None = typer.Option(None, "--proxy-type", help="Managed proxy type"),
    captcha_solver: bool = typer.Option(False, "--captcha-solver", help="Enable captcha solver"),
    captcha_provider: str | None = typer.Option(None, "--captcha-provider", help="Captcha solver provider"),
    captcha_api_key: str | None = typer.Option(None, "--captcha-api-key", help="Captcha solver API key"),
    rrweb: bool = typer.Option(False, "--rrweb", help="Enable rrweb recording"),
    logger: bool = typer.Option(False, "--logger", help="Enable logger extension"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds",
    ),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    geonode_proxy: bool = typer.Option(False, "--geonode-proxy", help="Enable Geonode proxy"),
    geonode_mode: str | None = typer.Option(None, "--geonode-mode", help="Geonode mode"),
    geonode_domain: list[str] = typer.Option([], "--geonode-domain", help="Geonode domain pattern"),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open browser URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
) -> None:
    """Create a browser session when invoked without a subcommand."""
    if ctx.invoked_subcommand is None:
        create_browser(
            name=name,
            workspace_id=workspace_id,
            screen_width=screen_width,
            screen_height=screen_height,
            stealth=stealth,
            adblock=adblock,
            profile_mode=profile_mode,
            profile_id=profile_id,
            proxy_url=proxy_url,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            proxy_provider=proxy_provider,
            proxy_type=proxy_type,
            captcha_solver=captcha_solver,
            captcha_provider=captcha_provider,
            captcha_api_key=captcha_api_key,
            rrweb=rrweb,
            logger=logger,
            cpu=cpu,
            memory=memory,
            max_lifetime_seconds=max_lifetime_seconds,
            gpu_type=gpu_type,
            geonode_proxy=geonode_proxy,
            geonode_mode=geonode_mode,
            geonode_domain=geonode_domain,
            open_url=open_url,
            wait=wait,
        )


@app.command("create")
def create_browser(
    name: str | None = typer.Option(None, "--name", help="Browser session name"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    screen_width: int = typer.Option(1280, "--screen-width", "--width", help="Screen width"),
    screen_height: int = typer.Option(720, "--screen-height", "--height", help="Screen height"),
    stealth: bool = typer.Option(False, "--stealth", help="Enable stealth mode"),
    adblock: bool = typer.Option(False, "--adblock", help="Enable ad blocking"),
    profile_mode: str = typer.Option(
        "persistent",
        "--profile-mode",
        "--profile",
        help="Profile mode (persistent, ephemeral)",
    ),
    profile_id: str | None = typer.Option(None, "--profile-id", help="Browser profile ID"),
    proxy_url: str | None = typer.Option(None, "--proxy-url", help="Proxy URL"),
    proxy_username: str | None = typer.Option(None, "--proxy-username", help="Proxy username"),
    proxy_password: str | None = typer.Option(None, "--proxy-password", help="Proxy password"),
    proxy_provider: str | None = typer.Option(None, "--proxy-provider", help="Managed proxy provider"),
    proxy_type: str | None = typer.Option(None, "--proxy-type", help="Managed proxy type"),
    captcha_solver: bool = typer.Option(False, "--captcha-solver", help="Enable captcha solver"),
    captcha_provider: str | None = typer.Option(None, "--captcha-provider", help="Captcha solver provider"),
    captcha_api_key: str | None = typer.Option(None, "--captcha-api-key", help="Captcha solver API key"),
    rrweb: bool = typer.Option(False, "--rrweb", help="Enable rrweb recording"),
    logger: bool = typer.Option(False, "--logger", help="Enable logger extension"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds",
    ),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    geonode_proxy: bool = typer.Option(False, "--geonode-proxy", help="Enable Geonode proxy"),
    geonode_mode: str | None = typer.Option(None, "--geonode-mode", help="Geonode mode"),
    geonode_domain: list[str] = typer.Option([], "--geonode-domain", help="Geonode domain pattern"),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open browser URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
) -> None:
    """Create a browser session.

    Examples:
        agv browser create
        agv browser create --screen-width 1920 --screen-height 1080 --stealth
    """
    client = get_client()
    api = BrowserAPI(client)
    geonode_payload = _build_geonode_proxy_payload(
        enabled=geonode_proxy,
        mode=geonode_mode,
        domains=geonode_domain,
    )

    try:
        with status("Creating browser session..."):
            session = api.create(
                name=name,
                workspace_id=workspace_id,
                screen_width=screen_width,
                screen_height=screen_height,
                enable_stealth=stealth,
                enable_adblock=adblock,
                profile_mode=_normalize_profile_mode(profile_mode),
                profile_id=profile_id,
                proxy_url=proxy_url,
                proxy_username=proxy_username,
                proxy_password=proxy_password,
                proxy_provider=proxy_provider,
                proxy_type=proxy_type,
                enable_captcha_solver=captcha_solver,
                captcha_provider=captcha_provider,
                captcha_api_key=captcha_api_key,
                enable_rrweb=rrweb,
                enable_logger=logger,
                cpu_millis=cpu,
                memory_mb=memory,
                max_lifetime_seconds=max_lifetime_seconds,
                gpu_type=gpu_type,
                geonode_proxy=geonode_payload,
            )
    except APIError as e:
        print_error(f"Failed to create browser session: {e.message}")
        raise typer.Exit(1)

    if wait:
        with status("Waiting for session to start..."):
            try:
                session = api.wait_for_status(session.id, timeout=60)
            except TimeoutError:
                print_error("Browser session failed to start in time")
                raise typer.Exit(1)
            except RuntimeError as e:
                print_error(str(e))
                raise typer.Exit(1)

    if json_output_enabled():
        emit_json(session)
        return

    print_success(f"Browser session {session.id} created")
    if wait:
        print_success(f"Browser session {session.id} is running")

    # Show URLs
    if session.vnc_url:
        print(f"\nVNC URL: {session.vnc_url}")
    if session.cdp_url:
        print(f"CDP URL: {session.cdp_url}")

    if open_url:
        _open_session_url(session.vnc_url)


@app.command("ls")
def list_browsers(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    status_filter: str | None = typer.Option(None, "--status", help="Filter by status"),
) -> None:
    """List browser sessions."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        sessions = api.list_all(workspace_id=workspace_id, status=status_filter)
    except APIError as e:
        print_error(f"Failed to list browser sessions: {e.message}")
        raise typer.Exit(1)

    print_browser_table(sessions)


@app.command("list", deprecated=True)
def list_browsers_alt() -> None:
    """List browser sessions (alias for ls)."""
    list_browsers()


@app.command()
def inspect(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Show browser session details.

    Examples:
        agv browser inspect br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        session = api.get(session_id)
    except APIError as e:
        print_error(f"Failed to get browser session: {e.message}")
        raise typer.Exit(1)

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _colored_status, _format_datetime

    if json_output_enabled():
        emit_json(session)
        return

    console = Console()
    table = Table(title=f"Browser Session: {session.id}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", session.id)
    table.add_row("Name", session.name or "-")
    table.add_row("Status", _colored_status(session.status))
    table.add_row("Workspace", session.workspace_id or "-")
    table.add_row("CDP URL", session.cdp_url or "-")
    table.add_row("VNC URL", session.vnc_url or "-")
    table.add_row("Created", _format_datetime(session.created_at))
    if session.updated_at:
        table.add_row("Updated", _format_datetime(session.updated_at))
    if session.sandbox_id:
        table.add_row("Sandbox", session.sandbox_id)

    if session.config:
        if session.config.screen_width is not None and session.config.screen_height is not None:
            table.add_row("Screen", f"{session.config.screen_width}x{session.config.screen_height}")
        _add_detail_row(table, "Profile Mode", session.config.profile_mode)
        _add_detail_row(table, "Profile ID", session.config.profile_id)
        _add_detail_row(table, "Stealth", "yes" if session.config.enable_stealth else None)
        _add_detail_row(table, "Adblock", "yes" if session.config.enable_adblock else None)
        _add_detail_row(table, "Captcha Solver", "yes" if session.config.enable_captcha_solver else None)
        _add_detail_row(table, "RRWeb", "yes" if session.config.enable_rrweb else None)
        _add_detail_row(table, "Logger", "yes" if session.config.enable_logger else None)
        _add_detail_row(table, "Proxy URL", session.config.proxy_url)
        _add_detail_row(table, "Proxy Provider", session.config.proxy_provider)
        _add_detail_row(table, "Proxy Type", session.config.proxy_type)
        if session.config.geonode_proxy and session.config.geonode_proxy.enabled:
            _add_detail_row(table, "Geonode Mode", session.config.geonode_proxy.mode)
            _add_detail_row(
                table,
                "Geonode Domains",
                ", ".join(session.config.geonode_proxy.domains),
            )

    if session.metadata:
        _add_detail_row(table, "CDP Endpoint", session.metadata.cdp_endpoint)
        _add_detail_row(table, "CDP Port", session.metadata.cdp_port)
        _add_detail_row(table, "CDP Host Port", session.metadata.cdp_host_port)
        _add_detail_row(table, "VNC Endpoint", session.metadata.vnc_endpoint)
        _add_detail_row(table, "VNC Port", session.metadata.vnc_port)
        _add_detail_row(table, "VNC Token", session.metadata.vnc_token)
        _add_detail_row(table, "Runtime Proxy", session.metadata.proxy_url)
        if session.metadata.started_at:
            table.add_row("Started", _format_datetime(session.metadata.started_at))
        if session.metadata.stopped_at:
            table.add_row("Stopped", _format_datetime(session.metadata.stopped_at))
        _add_detail_row(table, "Exit Reason", session.metadata.exit_reason)

    _add_detail_row(table, "Recording Status", session.recording_status)
    _add_detail_row(table, "Recording Events", session.recording_event_count)
    _add_detail_row(table, "Recording S3 Key", session.recording_s3_key)
    if session.recording_started_at:
        table.add_row("Recording Started", _format_datetime(session.recording_started_at))
    if session.recording_ended_at:
        table.add_row("Recording Ended", _format_datetime(session.recording_ended_at))

    console.print(table)


@app.command()
def stop(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Stop a browser session.

    Examples:
        agv browser stop br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        with status(f"Stopping browser session {session_id}..."):
            api.stop(session_id)
    except APIError as e:
        print_error(f"Failed to stop browser session: {e.message}")
        raise typer.Exit(1)

    print_success(f"Browser session {session_id} stopped")


@app.command("rm")
def delete_browser(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a browser session.

    Examples:
        agv browser rm br_abc123
    """
    if not force:
        typer.confirm(f"Delete browser session {session_id}?", abort=True)

    client = get_client()
    api = BrowserAPI(client)

    try:
        with status(f"Deleting browser session {session_id}..."):
            api.delete(session_id)
    except APIError as e:
        print_error(f"Failed to delete browser session: {e.message}")
        raise typer.Exit(1)

    print_success(f"Browser session {session_id} deleted")


@app.command("delete", deprecated=True)
def delete_browser_alt(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a browser session (alias for rm)."""
    # Re-use the same implementation
    import sys

    from typer import Exit
    # Simulate the rm command with same args
    original_argv = sys.argv
    try:
        # Force to bypass confirmation since this might be a script
        delete_browser(session_id, force=True)
    except Exit:
        raise
    finally:
        sys.argv = original_argv


@app.command("cdp")
def get_cdp_url(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Get CDP (Chrome DevTools Protocol) URL for a session.

    Examples:
        agv browser cdp br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        url = api.get_cdp_url(session_id)
    except APIError as e:
        print_error(f"Failed to get CDP URL: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"cdpUrl": url})
        return

    if url:
        print(url)
    else:
        print_warning("CDP URL not available")


@app.command("vnc")
def get_vnc_url(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Get VNC URL for a session.

    Examples:
        agv browser vnc br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        url = api.get_vnc_url(session_id)
    except APIError as e:
        print_error(f"Failed to get VNC URL: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"vncUrl": url})
        return

    if url:
        print(url)
    else:
        print_warning("VNC URL not available")


@app.command("logs")
def browser_logs(
    session_id: str = typer.Argument(..., help="Session ID"),
    query: str | None = typer.Option(None, "--query", "-q", help="Search query"),
    limit: int | None = typer.Option(None, "--limit", "-n", help="Max entries"),
    from_time: str | None = typer.Option(None, "--from", help="Start time (ISO 8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time (ISO 8601)"),
    sort: str | None = typer.Option(None, "--sort", help="Sort order (asc/desc)"),
    log_path: str | None = typer.Option(None, "--log-path", help="Filter by log path"),
) -> None:
    """View browser session logs."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        output = api.logs(
            session_id,
            query=query,
            limit=limit,
            from_time=from_time,
            to_time=to_time,
            sort=sort,
            log_path=log_path,
            raw=json_output_enabled(),
        )
    except APIError as e:
        print_error(f"Failed to get browser session logs: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(output)
        return

    if output:
        print(output)


@profile_app.command("create")
def create_profile(
    name: str = typer.Option(..., "--name", help="Browser profile name"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    description: str | None = typer.Option(None, "--description", help="Browser profile description"),
) -> None:
    """Create a browser profile."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        with status("Creating browser profile..."):
            profile = api.create_profile(
                name=name,
                workspace_id=workspace_id,
                description=description,
            )
    except APIError as e:
        print_error(f"Failed to create browser profile: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(profile)
        return

    print_success(f"Browser profile {profile.get('id', '-')} created")
    _print_profile_detail(profile)


@profile_app.command("ls")
def list_profiles(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List browser profiles."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        profiles = api.list_profiles(workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to list browser profiles: {e.message}")
        raise typer.Exit(1)

    _print_profile_table(profiles)


@profile_app.command("inspect")
def inspect_profile(
    profile_id: str = typer.Argument(..., help="Profile ID"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Show browser profile details."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        profile = api.get_profile(profile_id, workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to get browser profile: {e.message}")
        raise typer.Exit(1)

    _print_profile_detail(profile)


@profile_app.command("rm")
def delete_profile(
    profile_id: str = typer.Argument(..., help="Profile ID"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a browser profile."""
    if not force:
        typer.confirm(f"Delete browser profile {profile_id}?", abort=True)

    client = get_client()
    api = BrowserAPI(client)

    try:
        with status(f"Deleting browser profile {profile_id}..."):
            api.delete_profile(profile_id, workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to delete browser profile: {e.message}")
        raise typer.Exit(1)

    print_success(f"Browser profile {profile_id} deleted")
