"""Authentication CLI commands."""

from urllib.parse import urlparse

import typer
from rich import box
from rich.console import Console
from rich.table import Table

from ..api.auth import AuthAPI
from ..api.client import Client
from ..config.settings import get_settings, reset_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_api_key_table,
    print_config,
    print_error,
    print_success,
)

app = typer.Typer(help="Authentication commands")
console = Console()


def _build_frontend_login_url(api_url: str) -> str:
    """Derive the browser login URL from the configured API URL."""
    frontend_url = api_url.rstrip("/")
    if frontend_url.endswith("/api"):
        frontend_url = frontend_url[:-4]
    elif frontend_url.endswith("/v1"):
        frontend_url = frontend_url[:-3]

    parsed = urlparse(frontend_url)
    scheme = parsed.scheme or "https"
    host = parsed.hostname or "localhost"

    if host in {"localhost", "127.0.0.1"}:
        return f"{scheme}://{host}:5173/login"

    if host.startswith("api."):
        host = host[4:]

    return f"{scheme}://{host}/login"


def _auth_client(settings) -> AuthAPI:
    """Build an authenticated auth API client."""
    client = Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )
    return AuthAPI(client)


def _print_auth_workspaces_table(
    workspaces: list[dict[str, object]],
    selected_workspace_id: str | None,
) -> None:
    """Render authenticated workspace membership in a compact table."""
    if not workspaces:
        console.print("[dim]No workspaces found.[/dim]")
        return

    table = Table(title="Auth Workspaces", box=box.ROUNDED)
    table.add_column("Active", no_wrap=True)
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("TOTP", no_wrap=True)

    for workspace in workspaces:
        workspace_id = str(workspace.get("id", ""))
        name = str(workspace.get("name", "-"))
        totp_required = "Yes" if workspace.get("totpRequired") else "No"
        active = "*" if workspace_id and workspace_id == selected_workspace_id else ""
        table.add_row(active, workspace_id, name, totp_required)

    console.print(table)


@app.command()
def login(
    ctx: typer.Context,
    api_key: str | None = typer.Option(None, "--api-key", help="API key for authentication"),
    username: str | None = typer.Option(None, "--username", "-u", help="Username for login"),
    password: str | None = typer.Option(None, "--password", "-p", help="Password for login"),
    public_host: str | None = typer.Option(
        None,
        "--public-host",
        help="Public host/IP for remote browser login callback (e.g. 177.54.159.23)",
    ),
    callback_port: int = typer.Option(
        50391,
        "--callback-port",
        help="Local callback server port for browser login",
    ),
) -> None:
    """Authenticate with AgentEnv Cloud.

    Opens browser for login. After successful authentication,
    you'll be redirected back to the CLI with a JWT token.

    Examples:
        agv login
        agv login --api-key sk_live_xxxxx
        agv login --username user@example.com --password pass
        agv login --public-host 177.54.159.23
    """
    settings = get_settings()

    if api_key:
        # API key login
        settings.api_key = api_key
        settings.save_credentials()
        if json_output_enabled():
            emit_json({"authenticated": True, "method": "api_key"})
            return
        print_success("Logged in with API key")
        return

    if username and password:
        # Username/password login (dev only)
        with status("Logging in..."):
            client = Client(base_url=settings.api_url)
            api = AuthAPI(client)
            try:
                result = api.login(username, password)
                if result.get("requiresTotp") and result.get("tempToken"):
                    if json_output_enabled():
                        emit_json(
                            {
                                "authenticated": False,
                                "requiresTotp": True,
                                "tempToken": result["tempToken"],
                                "message": result.get("message", "TOTP verification required"),
                            }
                        )
                        return

                    print_success("Password accepted")
                    print("TOTP verification required to complete login.")
                    print(
                        "Run:\n"
                        f"  agv auth complete-totp-login --temp-token {result['tempToken']} --code <6-digit-code>"
                    )
                    return

                settings.access_token = result["accessToken"]
                settings.refresh_token = result["refreshToken"]
                settings.save_credentials()
                if json_output_enabled():
                    emit_json(
                        {
                            "authenticated": True,
                            "method": "password",
                            "username": result["user"]["username"],
                        }
                    )
                    return
                print_success(f"Logged in as {result['user']['username']}")
                return
            except Exception as e:
                print_error(str(e))
                raise typer.Exit(1)

    # Browser-based OAuth flow
    from ..oauth.flow import run_browser_login_flow

    # Hosted environments use the branded root domain, while local dev keeps :5173.
    frontend_url = _build_frontend_login_url(settings.api_url)
    public_host = public_host.strip() if public_host else None

    callback_host = "localhost"
    callback_bind_host = "127.0.0.1"
    if public_host:
        callback_host = public_host
        callback_bind_host = "0.0.0.0"

    # Run browser login flow
    token, error = run_browser_login_flow(
        frontend_url=frontend_url,
        port=callback_port,
        open_browser=True,
        callback_host=callback_host,
        callback_bind_host=callback_bind_host,
    )

    if error:
        print_error(f"Login failed: {error}")
        raise typer.Exit(1)

    if token:
        # Verify token and get user info
        with status("Verifying token..."):
            try:
                client = Client(base_url=settings.api_url, access_token=token)
                api = AuthAPI(client)
                profile = api.get_profile()

                settings.access_token = token
                settings.save_credentials()
                if json_output_enabled():
                    emit_json(
                        {
                            "authenticated": True,
                            "method": "browser",
                            "username": profile.username,
                        }
                    )
                    return
                print_success(f"Logged in as {profile.username}")
                return
            except Exception as e:
                print_error(f"Failed to verify token: {e}")
                raise typer.Exit(1)


@app.command()
def logout() -> None:
    """Logout and clear stored credentials."""
    settings = get_settings()
    use_json = json_output_enabled()
    settings.clear_credentials()
    reset_settings()
    if use_json:
        emit_json({"authenticated": False})
        return
    print_success("Logged out successfully")


@app.command("status")
def auth_status() -> None:
    """Show current authentication status."""
    settings = get_settings()

    authenticated = settings.is_authenticated()
    credentials = {
        "apiKey": bool(settings.api_key),
        "accessToken": bool(settings.access_token),
        "refreshToken": bool(settings.refresh_token),
        "apiUrl": settings.api_url,
        "workspace": settings.workspace,
    }

    if json_output_enabled():
        emit_json({"authenticated": authenticated, "credentials": credentials})
        return

    config = {
        "API Key": "Set" if credentials["apiKey"] else "Not set",
        "Access Token": "Set" if credentials["accessToken"] else "Not set",
        "Refresh Token": "Set" if credentials["refreshToken"] else "Not set",
        "API URL": settings.api_url,
        "Workspace": settings.workspace or "Not set",
    }

    if authenticated:
        print_success("Authenticated")
    else:
        print_error("Not authenticated", title="Status")

    print_config(config)


@app.command("create-key")
def create_api_key(
    name: str = typer.Argument(..., help="Name for the API key"),
) -> None:
    """Create a new API key.

    Examples:
        agv auth create-key "My CLI Key"
    """
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status("Creating API key..."):
        api = _auth_client(settings)

        try:
            key = api.create_api_key(name)
        except Exception as e:
            print_error(f"Failed to create API key: {e}")
            raise typer.Exit(1)

    plaintext_key = key.key
    if not plaintext_key:
        print_error(
            "Failed to create API key: server response did not include plaintext key."
        )
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"id": key.id, "name": key.name, "key": plaintext_key})
        return

    print_success(f"API key '{name}' created")
    print(f"\nKey: [bold green]{plaintext_key}[/bold green]")
    print("\nSave this key now - you won't be able to see it again!")
    print(f"\nTo use it:\n  agv login --api-key {plaintext_key}")


@app.command("list-keys")
def list_api_keys() -> None:
    """List all API keys."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status("Loading API keys..."):
        api = _auth_client(settings)

        try:
            keys = api.list_api_keys()
        except Exception as e:
            print_error(f"Failed to list API keys: {e}")
            raise typer.Exit(1)

    print_api_key_table(keys)


@app.command("revoke-key")
def revoke_api_key(
    key_id: str = typer.Argument(..., help="API key ID to revoke"),
) -> None:
    """Revoke an API key.

    Examples:
        agv auth revoke-key ak_abc123
    """
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status(f"Revoking API key {key_id}..."):
        api = _auth_client(settings)

        try:
            api.delete_api_key(key_id)
        except Exception as e:
            print_error(f"Failed to revoke API key: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"revoked": key_id})
        return

    print_success(f"API key {key_id} revoked")


@app.command("profile")
def get_profile() -> None:
    """Get current user profile."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status("Loading profile..."):
        api = _auth_client(settings)

        try:
            profile = api.get_profile()
        except Exception as e:
            print_error(f"Failed to load profile: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(profile)
        return

    print_config({
        "ID": profile.id,
        "Email": profile.email,
        "Username": profile.username,
    })


@app.command("workspaces")
def list_auth_workspaces() -> None:
    """List workspaces available to the authenticated user."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status("Loading auth workspaces..."):
        api = _auth_client(settings)

        try:
            result = api.get_workspaces()
        except Exception as e:
            print_error(f"Failed to load auth workspaces: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    _print_auth_workspaces_table(
        result.get("workspaces", []),
        result.get("selectedWorkspaceId"),
    )


@app.command("select-workspace")
def select_workspace(
    workspace_id: str = typer.Argument(..., help="Workspace ID to activate"),
) -> None:
    """Set the authenticated user's active workspace."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    with status(f"Selecting workspace {workspace_id}..."):
        api = _auth_client(settings)

        try:
            result = api.set_workspace(workspace_id)
        except Exception as e:
            print_error(f"Failed to select workspace: {e}")
            raise typer.Exit(1)

    selected_workspace_id = result.get("selectedWorkspaceId") or workspace_id
    settings.workspace = selected_workspace_id
    settings.save()

    if json_output_enabled():
        emit_json(result)
        return

    print_success(f"Active workspace set to {selected_workspace_id}")


@app.command("forgot-password")
def forgot_password(
    email: str = typer.Argument(..., help="Email address for the account"),
) -> None:
    """Request a password reset email."""
    settings = get_settings()

    with status("Requesting password reset..."):
        api = AuthAPI(Client(base_url=settings.api_url))

        try:
            result = api.forgot_password(email)
        except Exception as e:
            print_error(f"Failed to request password reset: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(result.get("message", "Password reset requested"))


@app.command("reset-password")
def reset_password(
    token: str = typer.Option(..., "--token", help="Password reset token"),
    new_password: str = typer.Option(
        ...,
        "--new-password",
        help="New password to set",
        prompt=True,
        hide_input=True,
        confirmation_prompt=True,
    ),
) -> None:
    """Reset a password using a reset token."""
    settings = get_settings()

    with status("Resetting password..."):
        api = AuthAPI(Client(base_url=settings.api_url))

        try:
            result = api.reset_password(token, new_password)
        except Exception as e:
            print_error(f"Failed to reset password: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(result.get("message", "Password reset successful"))


@app.command("verify-email")
def verify_email(
    token: str = typer.Option(..., "--token", help="Email verification token"),
) -> None:
    """Verify an email address using a verification token."""
    settings = get_settings()

    with status("Verifying email..."):
        api = AuthAPI(Client(base_url=settings.api_url))

        try:
            result = api.verify_email(token)
        except Exception as e:
            print_error(f"Failed to verify email: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(result.get("message", "Email verified"))


@app.command("resend-verification")
def resend_verification(
    email: str = typer.Argument(..., help="Email address to resend verification to"),
) -> None:
    """Resend an email verification link."""
    settings = get_settings()

    with status("Resending verification email..."):
        api = AuthAPI(Client(base_url=settings.api_url))

        try:
            result = api.resend_verification(email)
        except Exception as e:
            print_error(f"Failed to resend verification email: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(result.get("message", "Verification email sent"))


@app.command("complete-totp-login")
def complete_totp_login(
    temp_token: str = typer.Option(..., "--temp-token", help="Temporary login token from password login"),
    code: str = typer.Option(..., "--code", help="Current 6-digit TOTP code"),
) -> None:
    """Complete a TOTP login challenge and persist the returned tokens."""
    settings = get_settings()

    with status("Completing TOTP login..."):
        api = AuthAPI(Client(base_url=settings.api_url))

        try:
            result = api.verify_totp(code, temp_token)
        except Exception as e:
            print_error(f"Failed to complete TOTP login: {e}")
            raise typer.Exit(1)

    settings.access_token = result["accessToken"]
    settings.refresh_token = result["refreshToken"]
    settings.save_credentials()

    if json_output_enabled():
        emit_json(
            {
                "authenticated": True,
                "method": "totp",
                "username": result["user"]["username"],
            }
        )
        return

    print_success(f"Logged in as {result['user']['username']}")
