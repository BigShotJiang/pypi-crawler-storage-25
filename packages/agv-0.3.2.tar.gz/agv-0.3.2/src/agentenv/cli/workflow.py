"""Workflow CLI commands."""

from __future__ import annotations

import json
from pathlib import Path
import time
from typing import Any

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from ..api.client import APIError, Client
from ..api.workflow import WorkflowAPI
from ..config.settings import get_settings
from ..ui.tables import _colored_status, _format_datetime, print_error, print_success

app = typer.Typer(help="Workflow automation commands", no_args_is_help=True)
console = Console()

WORKFLOW_STATUSES = {"draft", "active", "archived"}
WORKFLOW_EXECUTION_STATUSES = {"pending", "running", "completed", "failed"}
WORKFLOW_ACTIVE_EXECUTION_STATUSES = {"pending", "running", "pending_cancellation"}
WORKFLOW_SUCCESS_EXECUTION_STATUSES = {"completed"}


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _print_json(data: object) -> None:
    print(json.dumps(data, indent=2, default=str))


def _fail(
    message: str,
    *,
    json_output: bool,
    code: str = "CLI_ERROR",
    details: dict[str, Any] | None = None,
) -> None:
    if json_output:
        payload: dict[str, Any] = {"error": {"code": code, "message": message}}
        if details:
            payload["error"]["details"] = details
        _print_json(payload)
    else:
        print_error(message)
    raise typer.Exit(1)


def _fail_api(action: str, error: APIError, *, json_output: bool) -> None:
    _fail(
        f"Failed to {action}: {error.message}",
        json_output=json_output,
        code="API_ERROR",
        details=error.details or None,
    )


def _resolve_workspace_id(
    workspace_id: str | None,
    *,
    json_output: bool,
) -> str:
    resolved = workspace_id or get_settings().workspace
    if resolved:
        return resolved
    _fail(
        "No workspace specified. Use --workspace-id or set a default with 'agv workspace use'.",
        json_output=json_output,
        code="WORKSPACE_REQUIRED",
    )


def _load_structured_file(path: Path) -> Any:
    if not path.exists():
        raise ValueError(f"File does not exist: {path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path}")

    raw = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc.msg}") from exc

    try:
        import yaml
    except ImportError as exc:
        raise ValueError("YAML parsing requires pyyaml to be installed") from exc

    try:
        return yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in {path}: {exc}") from exc


def _parse_inline_json(raw: str, label: str) -> Any:
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON for {label}: {exc.msg}") from exc


def _read_structured_input(
    *,
    inline_value: str | None,
    file_path: Path | None,
    label: str,
    required: bool,
    json_output: bool,
) -> Any:
    if inline_value is not None and file_path is not None:
        _fail(
            f"Provide only one source for {label}.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    if file_path is not None:
        try:
            return _load_structured_file(file_path)
        except ValueError as exc:
            _fail(str(exc), json_output=json_output, code="INVALID_ARGUMENT")

    if inline_value is not None:
        try:
            return _parse_inline_json(inline_value, label)
        except ValueError as exc:
            _fail(str(exc), json_output=json_output, code="INVALID_ARGUMENT")

    if required:
        _fail(
            f"Missing {label}. Use --file or the inline JSON option.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    return None


def _validate_workflow_status(status: str | None, *, json_output: bool) -> None:
    if status is None:
        return
    if status not in WORKFLOW_STATUSES:
        _fail(
            f"Invalid status '{status}'. Expected one of: {', '.join(sorted(WORKFLOW_STATUSES))}.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )


def _require_json_object(
    value: Any,
    *,
    label: str,
    json_output: bool,
) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    _fail(
        f"{label} must be a JSON object.",
        json_output=json_output,
        code="INVALID_ARGUMENT",
    )


def _validate_execution_status_filter(
    status: str | None,
    *,
    json_output: bool,
) -> None:
    if status is None:
        return

    invalid_statuses = sorted(
        {
            item.strip()
            for item in status.split(",")
            if item.strip() and item.strip() not in WORKFLOW_EXECUTION_STATUSES
        }
    )
    if invalid_statuses:
        _fail(
            "Invalid execution status filter(s): "
            f"{', '.join(invalid_statuses)}. Expected comma-separated values from: "
            f"{', '.join(sorted(WORKFLOW_EXECUTION_STATUSES))}.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )


def _render_json_panel(title: str, value: Any) -> None:
    rendered = json.dumps(value, indent=2, default=str)
    console.print(
        Panel(
            Syntax(rendered, "json", theme="monokai", word_wrap=True),
            title=title,
            box=box.ROUNDED,
        )
    )


def _workflow_counts(definition: Any) -> tuple[int, int]:
    nodes = getattr(definition, "nodes", []) or []
    edges = getattr(definition, "edges", []) or []
    return len(nodes), len(edges)


def _print_workflow_table(workflows: list[Any]) -> None:
    if not workflows:
        console.print("[dim]No workflows found.[/dim]")
        return

    table = Table(title="Workflows", box=box.ROUNDED)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Version", justify="right")
    table.add_column("Nodes", justify="right")
    table.add_column("Edges", justify="right")
    table.add_column("Updated", no_wrap=True)

    for workflow in workflows:
        node_count, edge_count = _workflow_counts(workflow.definition)
        table.add_row(
            workflow.id[:12],
            workflow.name,
            _colored_status(workflow.status),
            str(workflow.version),
            str(node_count),
            str(edge_count),
            _format_datetime(workflow.updated_at),
        )

    console.print(table)


def _print_workflow_detail(workflow: Any) -> None:
    table = Table(title=f"Workflow: {workflow.name}", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    node_count, edge_count = _workflow_counts(workflow.definition)
    deployed_nodes, deployed_edges = _workflow_counts(workflow.published_definition)

    table.add_row("ID", workflow.id)
    table.add_row("Workspace", workflow.workspace_id)
    table.add_row("Name", workflow.name)
    table.add_row("Description", workflow.description or "-")
    table.add_row("Status", _colored_status(workflow.status))
    table.add_row("Version", str(workflow.version))
    table.add_row("Draft Nodes", str(node_count))
    table.add_row("Draft Edges", str(edge_count))
    table.add_row("Deployed Nodes", str(deployed_nodes))
    table.add_row("Deployed Edges", str(deployed_edges))
    table.add_row(
        "Deployed At",
        _format_datetime(workflow.published_at) if workflow.published_at else "-",
    )
    table.add_row("Created", _format_datetime(workflow.created_at))
    table.add_row("Updated", _format_datetime(workflow.updated_at))

    console.print(table)

    if workflow.webhook_endpoints:
        webhook_table = Table(title="Webhook Endpoints", box=box.ROUNDED)
        webhook_table.add_column("Node")
        webhook_table.add_column("Type")
        webhook_table.add_column("Methods")
        webhook_table.add_column("URL")
        webhook_table.add_column("Active", no_wrap=True)

        for endpoint in workflow.webhook_endpoints:
            webhook_table.add_row(
                endpoint.node_name or endpoint.node_id,
                endpoint.node_type or "-",
                ", ".join(endpoint.methods) or "-",
                endpoint.relative_url,
                "yes" if endpoint.is_active else "no",
            )

        console.print(webhook_table)


def _print_execution_table(
    executions: list[Any],
    pagination: dict[str, Any] | None,
) -> None:
    if not executions:
        console.print("[dim]No executions found.[/dim]")
        return

    table = Table(title="Workflow Executions", box=box.ROUNDED)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Version", justify="right")
    table.add_column("Started", no_wrap=True)
    table.add_column("Completed", no_wrap=True)
    table.add_column("Created", no_wrap=True)
    table.add_column("Error")

    for execution in executions:
        error = execution.error or "-"
        if len(error) > 40:
            error = error[:37] + "..."
        table.add_row(
            execution.id[:12],
            _colored_status(execution.status),
            str(execution.workflow_version),
            _format_datetime(execution.started_at) if execution.started_at else "-",
            _format_datetime(execution.completed_at) if execution.completed_at else "-",
            _format_datetime(execution.created_at),
            error,
        )

    console.print(table)

    if pagination:
        page = pagination.get("page", "?")
        total_pages = pagination.get("totalPages", "?")
        total = pagination.get("total", "?")
        console.print(f"[dim]Page {page}/{total_pages} • Total {total}[/dim]")


def _print_execution_detail(execution: Any) -> None:
    table = Table(
        title=f"Workflow Execution: {execution.id}",
        box=box.ROUNDED,
        show_header=False,
    )
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", execution.id)
    table.add_row("Workflow ID", execution.workflow_id)
    table.add_row("Workflow Version", str(execution.workflow_version))
    table.add_row("Status", _colored_status(execution.status))
    table.add_row("Created", _format_datetime(execution.created_at))
    table.add_row(
        "Started",
        _format_datetime(execution.started_at) if execution.started_at else "-",
    )
    table.add_row(
        "Completed",
        _format_datetime(execution.completed_at) if execution.completed_at else "-",
    )
    table.add_row("Error", execution.error or "-")

    console.print(table)

    if execution.input is not None:
        _render_json_panel("Input", execution.input)
    if execution.output is not None:
        _render_json_panel("Output", execution.output)
    if execution.node_outputs:
        _render_json_panel("Node Outputs", execution.node_outputs)
    if execution.node_errors:
        _render_json_panel("Node Errors", execution.node_errors)


def _wait_for_execution(
    api: WorkflowAPI,
    workflow_id: str,
    execution_id: str,
    *,
    timeout: int,
    poll_interval: float,
    json_output: bool,
) -> Any:
    start = time.monotonic()

    while True:
        try:
            execution = api.get_execution(workflow_id, execution_id)
        except APIError as exc:
            _fail_api("get workflow execution", exc, json_output=json_output)

        if execution.status not in WORKFLOW_ACTIVE_EXECUTION_STATUSES:
            return execution

        elapsed = time.monotonic() - start
        if elapsed >= timeout:
            _fail(
                f"Workflow execution wait timed out after {timeout}s.",
                json_output=json_output,
                code="TIMEOUT",
            )

        remaining = timeout - elapsed
        time.sleep(min(poll_interval, remaining))


def _print_node_definitions_table(definitions: list[Any]) -> None:
    if not definitions:
        console.print("[dim]No node definitions found.[/dim]")
        return

    table = Table(title="Workflow Node Definitions", box=box.ROUNDED)
    table.add_column("Type", style="cyan")
    table.add_column("Category")
    table.add_column("Name")
    table.add_column("Trusted", no_wrap=True)
    table.add_column("Built-in", no_wrap=True)

    for definition in definitions:
        table.add_row(
            definition.type,
            definition.category,
            definition.name,
            "yes" if definition.trusted else "no",
            "yes" if definition.is_builtin else "no",
        )

    console.print(table)


def _print_node_definition_detail(definition: Any) -> None:
    table = Table(
        title=f"Node Definition: {definition.type}",
        box=box.ROUNDED,
        show_header=False,
    )
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("Type", definition.type)
    table.add_row("Category", definition.category)
    table.add_row("Name", definition.name)
    table.add_row("Description", definition.description or "-")
    table.add_row("Icon", definition.icon or "-")
    table.add_row("Trusted", "true" if definition.trusted else "false")
    table.add_row("Built-in", "true" if definition.is_builtin else "false")
    table.add_row("Handler Type", definition.handler.type)
    table.add_row("Handler Service", definition.handler.service or "-")
    table.add_row("Handler Method", definition.handler.method or "-")
    table.add_row("Handler Plugin", definition.handler.plugin or "-")

    console.print(table)
    _render_json_panel(
        "Schemas",
        definition.schemas.model_dump(by_alias=True, exclude_none=True),
    )
    if definition.secrets:
        _render_json_panel(
            "Secrets",
            definition.secrets.model_dump(by_alias=True, exclude_none=True),
        )


def _print_metrics(metrics: Any) -> None:
    table = Table(title="Workflow Metrics", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    table.add_row("Total", str(metrics.total))
    table.add_row("Pending", str(metrics.pending))
    table.add_row("Running", str(metrics.running))
    table.add_row("Completed", str(metrics.completed))
    table.add_row("Failed", str(metrics.failed))
    table.add_row("Success Rate", f"{metrics.success_rate:.2f}%")
    table.add_row("Avg Duration", f"{metrics.avg_duration_ms} ms")
    console.print(table)


def _print_time_series(points: list[Any]) -> None:
    if not points:
        console.print("[dim]No time-series data found.[/dim]")
        return

    table = Table(title="Workflow Metrics Time Series", box=box.ROUNDED)
    table.add_column("Timestamp", no_wrap=True)
    table.add_column("Count", justify="right")

    for point in points:
        table.add_row(point.timestamp, str(point.count))

    console.print(table)


@app.command("ls")
def list_workflows(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
    status: str | None = typer.Option(None, "--status", help="Filter by status"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List workflows."""
    _validate_workflow_status(status, json_output=json_output)
    resolved_workspace_id = _resolve_workspace_id(workspace_id, json_output=json_output)
    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflows = api.list_all(resolved_workspace_id, status=status)
    except APIError as exc:
        _fail_api("list workflows", exc, json_output=json_output)

    if json_output:
        _print_json([item.model_dump(by_alias=True, exclude_none=True) for item in workflows])
        return

    _print_workflow_table(workflows)


@app.command("list", deprecated=True, hidden=True)
def list_workflows_alt(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
    status: str | None = typer.Option(None, "--status", help="Filter by status"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List workflows (alias for ls)."""
    list_workflows(workspace_id=workspace_id, status=status, json_output=json_output)


@app.command("create")
def create_workflow(
    name: str = typer.Argument(..., help="Workflow name"),
    file: Path | None = typer.Option(None, "--file", "-f", help="Workflow definition file (JSON/YAML)"),
    definition: str | None = typer.Option(None, "--definition", help="Inline workflow definition JSON"),
    description: str | None = typer.Option(None, "--description", help="Workflow description"),
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a workflow."""
    resolved_workspace_id = _resolve_workspace_id(workspace_id, json_output=json_output)
    definition_data = _read_structured_input(
        inline_value=definition,
        file_path=file,
        label="workflow definition",
        required=True,
        json_output=json_output,
    )
    definition_data = _require_json_object(
        definition_data,
        label="workflow definition",
        json_output=json_output,
    )

    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflow = api.create(
            resolved_workspace_id,
            name=name,
            definition=definition_data,
            description=description,
        )
    except APIError as exc:
        _fail_api("create workflow", exc, json_output=json_output)

    if json_output:
        _print_json(workflow.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Workflow created: {workflow.name}")
    console.print(f"ID: {workflow.id}")


@app.command("inspect")
def inspect_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show workflow details."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflow = api.get(workflow_id)
    except APIError as exc:
        _fail_api("get workflow", exc, json_output=json_output)

    if json_output:
        _print_json(workflow.model_dump(by_alias=True, exclude_none=True))
        return

    _print_workflow_detail(workflow)


@app.command("update")
def update_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    name: str | None = typer.Option(None, "--name", help="Updated workflow name"),
    description: str | None = typer.Option(None, "--description", help="Updated workflow description"),
    status: str | None = typer.Option(None, "--status", help="Updated workflow status"),
    file: Path | None = typer.Option(None, "--file", "-f", help="Workflow definition file (JSON/YAML)"),
    definition: str | None = typer.Option(None, "--definition", help="Inline workflow definition JSON"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Update a workflow."""
    _validate_workflow_status(status, json_output=json_output)
    definition_data = _read_structured_input(
        inline_value=definition,
        file_path=file,
        label="workflow definition",
        required=False,
        json_output=json_output,
    )
    definition_data = _require_json_object(
        definition_data,
        label="workflow definition",
        json_output=json_output,
    )

    if name is None and description is None and status is None and definition_data is None:
        _fail(
            "No updates specified.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflow = api.update(
            workflow_id,
            name=name,
            description=description,
            definition=definition_data,
            status=status,
        )
    except APIError as exc:
        _fail_api("update workflow", exc, json_output=json_output)

    if json_output:
        _print_json(workflow.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Workflow updated: {workflow.name}")


@app.command("rm")
def delete_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a workflow."""
    if not force:
        typer.confirm(f"Delete workflow {workflow_id}?", abort=True)

    client = get_client()
    api = WorkflowAPI(client)

    try:
        result = api.delete(workflow_id)
    except APIError as exc:
        _fail_api("delete workflow", exc, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    print_success(f"Workflow {workflow_id} deleted")


@app.command("delete", deprecated=True, hidden=True)
def delete_workflow_alt(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a workflow (alias for rm)."""
    delete_workflow(workflow_id=workflow_id, force=force, json_output=json_output)


@app.command("deploy")
def deploy_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Deploy a workflow."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflow = api.deploy(workflow_id)
    except APIError as exc:
        _fail_api("deploy workflow", exc, json_output=json_output)

    if json_output:
        _print_json(workflow.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Workflow deployed: {workflow.name}")


@app.command("undeploy")
def undeploy_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Undeploy a workflow."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        workflow = api.undeploy(workflow_id)
    except APIError as exc:
        _fail_api("undeploy workflow", exc, json_output=json_output)

    if json_output:
        _print_json(workflow.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Workflow undeployed: {workflow.name}")


@app.command("execute")
def execute_workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    input_json: str | None = typer.Option(None, "--input", help="Inline execution input JSON"),
    input_file: Path | None = typer.Option(None, "--input-file", help="Execution input file (JSON/YAML)"),
    trigger_node_id: str | None = typer.Option(None, "--trigger-node-id", help="Trigger node ID"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for execution to finish"),
    timeout: int = typer.Option(300, "--timeout", help="Wait timeout in seconds"),
    poll_interval: float = typer.Option(2.0, "--poll-interval", help="Polling interval in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Execute a workflow."""
    if timeout < 1:
        _fail("--timeout must be >= 1", json_output=json_output, code="INVALID_ARGUMENT")
    if poll_interval <= 0:
        _fail("--poll-interval must be > 0", json_output=json_output, code="INVALID_ARGUMENT")

    input_data = _read_structured_input(
        inline_value=input_json,
        file_path=input_file,
        label="execution input",
        required=False,
        json_output=json_output,
    )
    input_data = _require_json_object(
        input_data,
        label="execution input",
        json_output=json_output,
    )

    client = get_client()
    api = WorkflowAPI(client)

    try:
        result = api.execute(
            workflow_id,
            input_data=input_data,
            trigger_node_id=trigger_node_id,
        )
    except APIError as exc:
        _fail_api("execute workflow", exc, json_output=json_output)

    if json_output:
        if wait:
            execution_id = result.get("executionId")
            if not execution_id:
                _fail(
                    "Workflow execution response did not include executionId.",
                    json_output=json_output,
                    code="API_ERROR",
                )

            execution = _wait_for_execution(
                api,
                workflow_id,
                execution_id,
                timeout=timeout,
                poll_interval=poll_interval,
                json_output=json_output,
            )
            _print_json(execution.model_dump(by_alias=True, exclude_none=True))
            if execution.status not in WORKFLOW_SUCCESS_EXECUTION_STATUSES:
                raise typer.Exit(1)
            return

        _print_json(result)
        return

    execution_id = result.get("executionId")
    print_success("Workflow execution queued")
    if execution_id:
        console.print(f"Execution ID: {execution_id}")
    if not wait:
        return

    if not execution_id:
        _fail(
            "Workflow execution response did not include executionId.",
            json_output=False,
            code="API_ERROR",
        )

    console.print(f"[dim]Waiting for execution {execution_id}...[/dim]")
    execution = _wait_for_execution(
        api,
        workflow_id,
        execution_id,
        timeout=timeout,
        poll_interval=poll_interval,
        json_output=False,
    )
    _print_execution_detail(execution)
    if execution.status not in WORKFLOW_SUCCESS_EXECUTION_STATUSES:
        print_error(f"Workflow execution finished with status: {execution.status}")
        raise typer.Exit(1)
    print_success(f"Workflow execution completed: {execution.id}")


@app.command("execute-in-memory")
def execute_workflow_in_memory(
    file: Path | None = typer.Option(None, "--file", "-f", help="Workflow definition file (JSON/YAML)"),
    definition: str | None = typer.Option(None, "--definition", help="Inline workflow definition JSON"),
    input_json: str | None = typer.Option(None, "--input", help="Inline execution input JSON"),
    input_file: Path | None = typer.Option(None, "--input-file", help="Execution input file (JSON/YAML)"),
    trigger_node_id: str | None = typer.Option(None, "--trigger-node-id", help="Trigger node ID"),
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Execute a workflow definition in memory."""
    resolved_workspace_id = _resolve_workspace_id(workspace_id, json_output=json_output)
    definition_data = _read_structured_input(
        inline_value=definition,
        file_path=file,
        label="workflow definition",
        required=True,
        json_output=json_output,
    )
    definition_data = _require_json_object(
        definition_data,
        label="workflow definition",
        json_output=json_output,
    )
    input_data = _read_structured_input(
        inline_value=input_json,
        file_path=input_file,
        label="execution input",
        required=False,
        json_output=json_output,
    )
    input_data = _require_json_object(
        input_data,
        label="execution input",
        json_output=json_output,
    )

    client = get_client()
    api = WorkflowAPI(client)

    try:
        result = api.execute_in_memory(
            resolved_workspace_id,
            definition_data,
            input_data=input_data,
            trigger_node_id=trigger_node_id,
        )
    except APIError as exc:
        _fail_api("execute workflow in memory", exc, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    status = result.get("status", "unknown")
    if status == "completed":
        print_success("In-memory workflow execution completed")
    else:
        print_error("In-memory workflow execution failed")

    console.print(f"Status: {status}")
    if "duration" in result:
        console.print(f"Duration: {result['duration']} ms")
    if result.get("output") is not None:
        _render_json_panel("Output", result["output"])
    if result.get("nodeOutputs"):
        _render_json_panel("Node Outputs", result["nodeOutputs"])
    if result.get("nodeLogs"):
        _render_json_panel("Node Logs", result["nodeLogs"])
    if result.get("error"):
        _render_json_panel("Error", result["error"])


@app.command("executions")
def list_workflow_executions(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    page: int = typer.Option(1, "--page", help="Page number"),
    limit: int = typer.Option(20, "--limit", help="Page size"),
    status: str | None = typer.Option(None, "--status", help="Comma-separated execution statuses"),
    from_time: str | None = typer.Option(None, "--from", help="Start time filter (ISO-8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time filter (ISO-8601)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List workflow executions."""
    if page < 1:
        _fail("--page must be >= 1", json_output=json_output, code="INVALID_ARGUMENT")
    if limit < 1:
        _fail("--limit must be >= 1", json_output=json_output, code="INVALID_ARGUMENT")
    _validate_execution_status_filter(status, json_output=json_output)

    client = get_client()
    api = WorkflowAPI(client)

    try:
        executions, pagination = api.list_executions(
            workflow_id,
            page=page,
            limit=limit,
            status=status,
            from_time=from_time,
            to_time=to_time,
        )
    except APIError as exc:
        _fail_api("list workflow executions", exc, json_output=json_output)

    if json_output:
        _print_json(
            {
                "data": [item.model_dump(by_alias=True, exclude_none=True) for item in executions],
                "pagination": pagination,
            }
        )
        return

    _print_execution_table(executions, pagination)


@app.command("execution")
def get_workflow_execution(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    execution_id: str = typer.Argument(..., help="Execution ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show workflow execution details."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        execution = api.get_execution(workflow_id, execution_id)
    except APIError as exc:
        _fail_api("get workflow execution", exc, json_output=json_output)

    if json_output:
        _print_json(execution.model_dump(by_alias=True, exclude_none=True))
        return

    _print_execution_detail(execution)


@app.command("cancel")
def cancel_workflow_execution(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    execution_id: str = typer.Argument(..., help="Execution ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Cancel a workflow execution."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        result = api.cancel_execution(workflow_id, execution_id)
    except APIError as exc:
        _fail_api("cancel workflow execution", exc, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    print_success(f"Workflow execution {execution_id} cancel requested")


@app.command("metrics")
def get_workflow_metrics(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    from_time: str | None = typer.Option(None, "--from", help="Start time filter (ISO-8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time filter (ISO-8601)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show workflow metrics."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        metrics = api.get_metrics(workflow_id, from_time=from_time, to_time=to_time)
    except APIError as exc:
        _fail_api("get workflow metrics", exc, json_output=json_output)

    if json_output:
        _print_json(metrics.model_dump(by_alias=True, exclude_none=True))
        return

    _print_metrics(metrics)


@app.command("metrics-timeseries")
def get_workflow_metrics_timeseries(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    interval: str = typer.Option("day", "--interval", help="Bucket interval: hour or day"),
    from_time: str | None = typer.Option(None, "--from", help="Start time filter (ISO-8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time filter (ISO-8601)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show workflow execution time series."""
    if interval not in {"hour", "day"}:
        _fail(
            f"Invalid interval '{interval}'. Expected one of: day, hour.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    client = get_client()
    api = WorkflowAPI(client)

    try:
        points = api.get_time_series(
            workflow_id,
            interval=interval,
            from_time=from_time,
            to_time=to_time,
        )
    except APIError as exc:
        _fail_api("get workflow metrics time series", exc, json_output=json_output)

    if json_output:
        _print_json([item.model_dump(by_alias=True, exclude_none=True) for item in points])
        return

    _print_time_series(points)


@app.command("node-definitions")
def list_node_definitions(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List current workflow node definitions exposed by the server."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        definitions = api.list_node_definitions()
    except APIError as exc:
        _fail_api("list node definitions", exc, json_output=json_output)

    if json_output:
        _print_json([item.model_dump(by_alias=True, exclude_none=True) for item in definitions])
        return

    _print_node_definitions_table(definitions)


@app.command("node-definition")
def get_node_definition(
    node_type: str = typer.Argument(..., help="Server node definition type"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show current workflow node definition details from the server."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        definition = api.get_node_definition(node_type)
    except APIError as exc:
        _fail_api("get node definition", exc, json_output=json_output)

    if json_output:
        _print_json(definition.model_dump(by_alias=True, exclude_none=True))
        return

    _print_node_definition_detail(definition)


@app.command("plugins")
def list_trusted_plugins(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List trusted workflow plugins."""
    client = get_client()
    api = WorkflowAPI(client)

    try:
        plugins = api.list_trusted_plugins()
    except APIError as exc:
        _fail_api("list trusted plugins", exc, json_output=json_output)

    if json_output:
        _print_json(plugins)
        return

    if not plugins:
        console.print("[dim]No trusted plugins found.[/dim]")
        return

    table = Table(title="Trusted Workflow Plugins", box=box.ROUNDED)
    table.add_column("Plugin", style="cyan")
    for plugin in plugins:
        table.add_row(plugin)
    console.print(table)
