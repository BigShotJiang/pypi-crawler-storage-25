"""Workspace CLI commands."""

from __future__ import annotations

import json
import re

import typer

from ..api.client import APIError, Client
from ..api.workspace import WorkspaceAPI
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_error,
    print_success,
    print_workspace_table,
)

app = typer.Typer(help="Workspace management commands")
_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{12}$"
)


def _resolve_workspace_id(workspace_id: str | None) -> str:
    """Resolve workspace ID from argument or selected workspace."""
    resolved = workspace_id or get_settings().workspace
    if resolved:
        return resolved
    print_error("No workspace specified. Use a workspace ID or set a default with 'agv workspace use'.")
    raise typer.Exit(1)


def _looks_like_workspace_id(value: str) -> bool:
    """Heuristic for catching incomplete explicit workspace forms."""
    return value.startswith(("wk_", "ws_")) or bool(_UUID_RE.match(value))


def _reject_ambiguous_workspace_shorthand(
    value: str,
    *,
    expected_usage: str,
) -> None:
    """Fail fast when a missing positional would be misread as selected-workspace shorthand."""
    if _looks_like_workspace_id(value):
        print_error(
            f"Ambiguous arguments: '{value}' looks like a workspace ID. "
            f"Use `{expected_usage}` for an explicit workspace, or omit the workspace ID to use the selected workspace."
        )
        raise typer.Exit(1)


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("create")
def create_workspace(
    name: str = typer.Argument(..., help="Workspace name"),
) -> None:
    """Create a new workspace.

    Examples:
        agv workspace create "My Workspace"
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Creating workspace '{name}'..."):
            workspace = api.create(name)
    except APIError as e:
        print_error(f"Failed to create workspace: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(workspace)
        return

    print_success(f"Workspace {workspace.id} created")
    print(f"  Name: {workspace.name}")


@app.command("ls")
def list_workspaces(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List workspaces."""
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        workspaces = api.list_all()
    except APIError as e:
        print_error(f"Failed to list workspaces: {e.message}")
        raise typer.Exit(1)

    if json_output or json_output_enabled():
        print(
            json.dumps(
                [ws.model_dump(by_alias=True, exclude_none=True) for ws in workspaces],
                indent=2,
                default=str,
            )
        )
        return

    print_workspace_table(workspaces)


@app.command("list", deprecated=True)
def list_workspaces_alt() -> None:
    """List workspaces (alias for ls)."""
    list_workspaces()


@app.command()
def inspect(
    workspace_id: str | None = typer.Argument(
        None,
        help="Workspace ID (defaults to selected workspace)",
    ),
) -> None:
    """Show workspace details.

    Examples:
        agv workspace inspect wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        workspace = api.get(resolved_workspace_id)
    except APIError as e:
        print_error(f"Failed to get workspace: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(workspace)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    console = Console()
    table = Table(title=f"Workspace: {workspace.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", workspace.id)
    table.add_row("Name", workspace.name)
    table.add_row("Owner", workspace.owner_id)
    table.add_row("Created", _format_datetime(workspace.created_at))

    if workspace.members:
        table.add_section()
        table.add_row("Members", "")
        for member in workspace.members:
            role_color = "green" if member.role == "owner" else "blue"
            table.add_row(
                "",
                f"{member.email} [{role_color}]{member.role}[/{role_color}]",
            )

    console.print(table)


@app.command("use")
def use_workspace(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
) -> None:
    """Set default workspace.

    Examples:
        agv workspace use wk_abc123
    """
    settings = get_settings()
    settings.workspace = workspace_id
    settings.save()

    print_success(f"Default workspace set to {workspace_id}")


@app.command("invite")
def invite_member(
    workspace_or_identifier: str = typer.Argument(..., help="Workspace ID, or member email/user ID"),
    identifier: str | None = typer.Argument(None, help="Member email or user ID"),
    role: str | None = typer.Option(None, "--role", help="Workspace role to grant"),
) -> None:
    """Invite a member to the workspace.

    Examples:
        agv workspace invite wk_abc123 user@example.com
    """
    resolved_workspace_id: str
    resolved_identifier: str
    if identifier is None:
        _reject_ambiguous_workspace_shorthand(
            workspace_or_identifier,
            expected_usage="agv workspace invite <workspace-id> <member-email-or-user-id>",
        )
        resolved_workspace_id = _resolve_workspace_id(None)
        resolved_identifier = workspace_or_identifier
    else:
        resolved_workspace_id = workspace_or_identifier
        resolved_identifier = identifier

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Inviting {resolved_identifier} to workspace..."):
            result = api.invite_member(resolved_workspace_id, resolved_identifier, role=role)
    except APIError as e:
        print_error(f"Failed to invite member: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(f"Invitation sent to {resolved_identifier}")
    if "code" in result:
        print(f"  Invite code: {result['code']}")


@app.command("members")
def list_members(
    workspace_id: str | None = typer.Argument(
        None,
        help="Workspace ID (defaults to selected workspace)",
    ),
) -> None:
    """List workspace members.

    Examples:
        agv workspace members wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        members = api.get_members(resolved_workspace_id)
    except APIError as e:
        print_error(f"Failed to list members: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(members)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    console = Console()
    table = Table(title=f"Members of {resolved_workspace_id}")
    table.add_column("Email")
    table.add_column("Role")
    table.add_column("Joined")

    for member in members:
        role_color = "green" if member.role == "owner" else "blue"
        table.add_row(
            member.email,
            f"[{role_color}]{member.role}[/{role_color}]",
            _format_datetime(member.joined_at),
        )

    console.print(table)


@app.command("remove-member")
def remove_member(
    workspace_or_user_id: str = typer.Argument(..., help="Workspace ID, or user ID to remove"),
    user_id: str | None = typer.Argument(None, help="User ID to remove"),
) -> None:
    """Remove a member from the workspace.

    Examples:
        agv workspace remove-member wk_abc123 user_123
    """
    resolved_workspace_id: str
    resolved_user_id: str
    if user_id is None:
        _reject_ambiguous_workspace_shorthand(
            workspace_or_user_id,
            expected_usage="agv workspace remove-member <workspace-id> <user-id>",
        )
        resolved_workspace_id = _resolve_workspace_id(None)
        resolved_user_id = workspace_or_user_id
    else:
        resolved_workspace_id = workspace_or_user_id
        resolved_user_id = user_id

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Removing member {resolved_user_id}..."):
            api.remove_member(resolved_workspace_id, resolved_user_id)
    except APIError as e:
        print_error(f"Failed to remove member: {e.message}")
        raise typer.Exit(1)

    print_success(f"Member {resolved_user_id} removed")


@app.command("rm")
def delete_workspace(
    workspace_id: str | None = typer.Argument(
        None,
        help="Workspace ID (defaults to selected workspace)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a workspace.

    Examples:
        agv workspace rm wk_abc123
    """
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    if not force:
        typer.confirm(f"Delete workspace {resolved_workspace_id}?", abort=True)

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Deleting workspace {resolved_workspace_id}..."):
            api.delete(resolved_workspace_id)
    except APIError as e:
        print_error(f"Failed to delete workspace: {e.message}")
        raise typer.Exit(1)

    print_success(f"Workspace {resolved_workspace_id} deleted")

    # Clear default workspace if it was the deleted one
    settings = get_settings()
    if settings.workspace == resolved_workspace_id:
        settings.workspace = None
        settings.save()


@app.command("delete", deprecated=True)
def delete_workspace_alt(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a workspace (alias for rm)."""
    delete_workspace(workspace_id, force=force)


# =============================================================================
# Secret management
# =============================================================================

@app.command("join")
def join_workspace(
    join_code: str = typer.Argument(..., help="Workspace join code"),
) -> None:
    """Join a workspace using a join code.

    Examples:
        agv workspace join ABC123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status("Joining workspace..."):
            workspace = api.join(join_code)
    except APIError as e:
        print_error(f"Failed to join workspace: {e.message}")
        raise typer.Exit(1)

    settings = get_settings()
    settings.workspace = workspace.id
    settings.save()

    if json_output_enabled():
        emit_json(workspace)
        return

    print_success(f"Joined workspace {workspace.id}")
    print(f"  Name: {workspace.name}")
    print("  Selected as default workspace")


@app.command("secret-ls")
def list_secrets(
    workspace_id: str | None = typer.Argument(
        None,
        help="Workspace ID (defaults to selected workspace)",
    ),
) -> None:
    """List workspace secrets.

    Examples:
        agv workspace secret-ls wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        secrets = api.list_secrets(resolved_workspace_id)
    except APIError as e:
        print_error(f"Failed to list secrets: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(secrets)
        return

    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(title=f"Secrets in {resolved_workspace_id}")
    table.add_column("ID")
    table.add_column("Key")
    table.add_column("Created")

    for secret in secrets:
        table.add_row(
            secret.get("id", "")[:12],
            secret.get("key", "-"),
            secret.get("createdAt", "-"),
        )

    console.print(table)


@app.command("secret-set")
def set_secret(
    workspace_or_key: str = typer.Argument(..., help="Workspace ID, or secret key"),
    key_or_value: str = typer.Argument(..., help="Secret key, or secret value"),
    value: str | None = typer.Argument(None, help="Secret value"),
) -> None:
    """Set a workspace secret.

    Examples:
        agv workspace secret-set wk_abc123 API_KEY xxxxx
    """
    resolved_workspace_id: str
    resolved_key: str
    resolved_value: str
    if value is None:
        _reject_ambiguous_workspace_shorthand(
            workspace_or_key,
            expected_usage="agv workspace secret-set <workspace-id> <key> <value>",
        )
        resolved_workspace_id = _resolve_workspace_id(None)
        resolved_key = workspace_or_key
        resolved_value = key_or_value
    else:
        resolved_workspace_id = workspace_or_key
        resolved_key = key_or_value
        resolved_value = value

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Setting secret '{resolved_key}'..."):
            api.create_secret(resolved_workspace_id, resolved_key, resolved_value)
    except APIError as e:
        print_error(f"Failed to set secret: {e.message}")
        raise typer.Exit(1)

    print_success(f"Secret '{resolved_key}' set")


@app.command("secret-update")
def update_secret(
    workspace_or_secret_id: str = typer.Argument(..., help="Workspace ID, or secret ID"),
    secret_id: str | None = typer.Argument(None, help="Secret ID"),
    key: str | None = typer.Option(None, "--key", help="New secret key"),
    value: str | None = typer.Option(None, "--value", help="New secret value"),
) -> None:
    """Update a workspace secret key and/or value.

    Examples:
        agv workspace secret-update wk_abc123 secret_123 --key NEW_NAME
        agv workspace secret-update wk_abc123 secret_123 --value xxxxx
    """
    if key is None and value is None:
        print_error("Provide --key and/or --value.")
        raise typer.Exit(1)

    resolved_workspace_id: str
    resolved_secret_id: str
    if secret_id is None:
        _reject_ambiguous_workspace_shorthand(
            workspace_or_secret_id,
            expected_usage="agv workspace secret-update <workspace-id> <secret-id> --key <key> and/or --value <value>",
        )
        resolved_workspace_id = _resolve_workspace_id(None)
        resolved_secret_id = workspace_or_secret_id
    else:
        resolved_workspace_id = workspace_or_secret_id
        resolved_secret_id = secret_id

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Updating secret {resolved_secret_id}..."):
            api.update_secret(resolved_workspace_id, resolved_secret_id, key=key, value=value)
    except APIError as e:
        print_error(f"Failed to update secret: {e.message}")
        raise typer.Exit(1)

    print_success(f"Secret {resolved_secret_id} updated")


@app.command("secret-rm")
def delete_secret(
    workspace_or_secret_id: str = typer.Argument(..., help="Workspace ID, or secret ID"),
    secret_id: str | None = typer.Argument(None, help="Secret ID"),
) -> None:
    """Delete a workspace secret.

    Examples:
        agv workspace secret-rm wk_abc123 secret_123
    """
    resolved_workspace_id: str
    resolved_secret_id: str
    if secret_id is None:
        _reject_ambiguous_workspace_shorthand(
            workspace_or_secret_id,
            expected_usage="agv workspace secret-rm <workspace-id> <secret-id>",
        )
        resolved_workspace_id = _resolve_workspace_id(None)
        resolved_secret_id = workspace_or_secret_id
    else:
        resolved_workspace_id = workspace_or_secret_id
        resolved_secret_id = secret_id

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Deleting secret {resolved_secret_id}..."):
            api.delete_secret(resolved_workspace_id, resolved_secret_id)
    except APIError as e:
        print_error(f"Failed to delete secret: {e.message}")
        raise typer.Exit(1)

    print_success(f"Secret {resolved_secret_id} deleted")
