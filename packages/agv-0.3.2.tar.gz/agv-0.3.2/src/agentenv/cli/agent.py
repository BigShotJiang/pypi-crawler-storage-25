"""Agent run CLI commands."""

from __future__ import annotations

import json
import uuid
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any

import typer

from ..api.agent_run import AgentRunAPI
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..payments.official_mppx_helper import OfficialMppxHelper

app = typer.Typer(help="Agent commands", no_args_is_help=True)


def get_client(*, json_output: bool = False) -> Client:
    """Get an authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        _fail(
            "Not authenticated. Run 'agv login' first.",
            json_output=json_output,
            code="AUTH_REQUIRED",
        )

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _fail(message: str, *, json_output: bool, code: str) -> None:
    if json_output:
        print(json.dumps({"error": {"code": code, "message": message}}))
    else:
        print(f"Error: {message}")
    raise typer.Exit(1)


def _parse_amount_to_cents(amount: str, *, json_output: bool) -> int:
    """Parse a dollar amount string to cents."""
    try:
        dollars = Decimal(str(amount))
    except (InvalidOperation, ValueError, TypeError):
        _fail(
            f"Invalid amount: {amount}. Use a dollar value like '10' or '5.50'.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    if not dollars.is_finite() or dollars <= 0:
        _fail(
            f"Invalid amount: {amount}. Amount must be greater than 0.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    cents = (dollars * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(cents)


def _parse_prompt(prompt: list[str] | None, *, json_output: bool) -> str:
    """Normalize and validate the free-form agent prompt."""
    prompt_text = " ".join(prompt).strip() if prompt else ""
    if not prompt_text:
        _fail(
            "Prompt is required.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )
    return prompt_text


def _validate_preflight_result(
    preflight_result: dict[str, Any], *, json_output: bool
) -> None:
    """Fail fast only when optional preflight explicitly rejects the request."""
    eligible = preflight_result.get("eligible")
    if eligible is False:
        message = preflight_result.get("message")
        if not isinstance(message, str) or not message:
            message = "Request is not eligible to run."
        _fail(
            f"Preflight failed: {message}",
            json_output=json_output,
            code="PREFLIGHT_FAILED",
        )


def _print_run_result(run_result: dict[str, Any], *, json_output: bool) -> None:
    """Render the final API result to stdout."""
    if json_output:
        print(json.dumps(run_result, indent=2, default=str))
        return

    if "result" in run_result:
        print(json.dumps(run_result["result"], indent=2, default=str))
        return

    print(json.dumps(run_result, indent=2, default=str))


def _is_payable_challenge(run_result: dict[str, Any]) -> bool:
    """Return True when a 402 payload contains a real payment challenge."""
    challenge = run_result.get("challenge")
    if run_result.get("statusCode") != 402 or not isinstance(challenge, dict):
        return False

    provider_reference = challenge.get("providerReference")
    return isinstance(provider_reference, str) and bool(provider_reference.strip())


def _terminal_402_message(run_result: dict[str, Any]) -> str:
    """Extract the server-provided terminal 402 error without guessing envelopes."""
    error = run_result.get("error")
    if isinstance(error, str) and error:
        return error

    message = run_result.get("message")
    if isinstance(message, str) and message:
        return message

    return "Payment failed."


def _run_payment_helper(challenge: dict[str, Any], *, json_output: bool) -> str:
    """Execute the official payer helper and normalize payer-side failures."""
    try:
        helper = OfficialMppxHelper()
        authorization_header = helper.run_payment(challenge=challenge)
    except Exception as exc:  # helper failures are payer-side, not CLI programmer errors
        _fail(
            f"Payment failed: {exc}",
            json_output=json_output,
            code="PAYMENT_FAILED",
        )

    if not isinstance(authorization_header, str) or not authorization_header:
        _fail(
            "Payment helper did not return an Authorization header.",
            json_output=json_output,
            code="PAYMENT_FAILED",
        )

    return authorization_header


@app.command("run")
def agent_run(
    workspace: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    billing_account_id: str = typer.Option(
        ..., "--billing-account-id", "-b", help="Billing account ID"
    ),
    amount: str = typer.Option(..., "--amount", "-a", help="Amount in dollars"),
    idempotency_key: str | None = typer.Option(
        None,
        "--idempotency-key",
        help="Stable request key for deterministic retries",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output in JSON format"),
    prompt: list[str] = typer.Argument(None, help="Agent prompt"),
) -> None:
    """Run an agent with machine-payment protection.

    Flow: protected request -> (402? pay -> retry same request) -> result

    Examples:
        agv agent run -w wk_123 -b ba_123 -a 10 -- "run this agent"
    """
    amount_cents = _parse_amount_to_cents(amount, json_output=json_output)
    prompt_text = _parse_prompt(prompt, json_output=json_output)
    idempotency_key = idempotency_key or str(uuid.uuid4())
    client = get_client(json_output=json_output)
    api = AgentRunAPI(client)

    try:
        preflight_result = api.preflight(
            workspace_id=workspace,
            billing_account_id=billing_account_id,
            amount_cents=amount_cents,
            prompt=prompt_text,
        )
        _validate_preflight_result(preflight_result, json_output=json_output)
    except APIError as exc:
        # Preflight is optional compatibility validation; transport/API failures
        # must not block the paid request path.
        preflight_result = {"eligible": None, "error": exc.message}

    # Step 1: Run the protected request (may return 402)
    try:
        run_result = api.run(
            workspace_id=workspace,
            billing_account_id=billing_account_id,
            amount_cents=amount_cents,
            idempotency_key=idempotency_key,
            prompt=prompt_text,
        )
    except APIError as exc:
        _fail(
            f"Run failed: {exc.message}",
            json_output=json_output,
            code="RUN_FAILED",
        )

    if run_result.get("statusCode") == 202:
        _print_run_result(run_result, json_output=json_output)
        return

    # Step 2: If 402, pay via helper and retry the same request
    if run_result.get("statusCode") == 402:
        if not _is_payable_challenge(run_result):
            _fail(
                _terminal_402_message(run_result),
                json_output=json_output,
                code="RUN_FAILED",
            )

        authorization_header = _run_payment_helper(
            run_result.get("challenge", {}),
            json_output=json_output,
        )

        try:
            run_result = api.run(
                workspace_id=workspace,
                billing_account_id=billing_account_id,
                amount_cents=amount_cents,
                idempotency_key=idempotency_key,
                prompt=prompt_text,
                authorization_header=authorization_header,
            )
        except APIError as exc:
            _fail(
                f"Replay failed: {exc.message}",
                json_output=json_output,
                code="PAYMENT_FAILED",
            )

        if run_result.get("statusCode") == 202:
            _print_run_result(run_result, json_output=json_output)
            return

        if run_result.get("statusCode") == 402:
            _fail(
                _terminal_402_message(run_result),
                json_output=json_output,
                code="PAYMENT_FAILED",
            )

    # Step 3: Output result
    _print_run_result(run_result, json_output=json_output)
