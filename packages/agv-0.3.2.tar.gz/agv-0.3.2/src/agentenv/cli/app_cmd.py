"""App deployment CLI commands."""


from datetime import datetime
import time
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from ..api.app import AppAPI, extract_app_log_entries, format_app_log_entry
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..ui.tables import emit_json, json_output_enabled, print_error, print_success

app = typer.Typer(help="App deployment management commands")
console = Console()


def get_client() -> Client:
    settings = get_settings()
    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def parse_env(env_list: list[str]) -> dict[str, str]:
    """Parse KEY=VALUE environment variable list."""
    result: dict[str, str] = {}
    for item in env_list:
        if "=" not in item:
            raise ValueError(f"Invalid --env value '{item}'. Expected KEY=VALUE.")
        key, value = item.split("=", 1)
        if not key:
            raise ValueError(f"Invalid --env value '{item}'. Environment variable name cannot be empty.")
        result[key] = value
    return result


def validate_replica_bounds(
    min_replicas: int | None,
    max_replicas: int | None,
    *,
    current_min: int | None = None,
    current_max: int | None = None,
) -> None:
    """Validate min/max replica bounds using provided or current values."""
    effective_min = min_replicas if min_replicas is not None else current_min
    effective_max = max_replicas if max_replicas is not None else current_max
    if effective_min is None or effective_max is None:
        return
    if effective_min < 0 or effective_max < 0:
        print_error("Replica counts must be >= 0")
        raise typer.Exit(1)
    if effective_max < effective_min:
        print_error("max must be >= min")
        raise typer.Exit(1)


def print_app_instances(app_info: Any, instances: list[dict[str, Any]]) -> None:
    """Render app instance status."""
    if json_output_enabled():
        emit_json({"app": app_info, "instances": instances})
        return

    summary = Table(show_header=False)
    summary.add_column("Field", style="cyan")
    summary.add_column("Value")
    summary.add_row("App", app_info.name)
    summary.add_row("Slug", app_info.slug)
    summary.add_row("Status", app_info.status)
    summary.add_row("Current Version", app_info.current_version or "-")
    summary.add_row("Instances", str(len(instances)))
    console.print(summary)

    if not instances:
        console.print("[dim]No app instances found.[/dim]")
        return

    table = Table(show_header=True)
    table.add_column("ID")
    table.add_column("Version")
    table.add_column("Status")
    table.add_column("Task")
    table.add_column("Endpoint")
    table.add_column("Updated")

    for instance in sorted(
        instances,
        key=lambda item: str(item.get("updatedAt") or item.get("createdAt") or ""),
        reverse=True,
    ):
        host_ip = instance.get("hostIp")
        host_port = instance.get("hostPort")
        endpoint = f"{host_ip}:{host_port}" if host_ip and host_port else "-"
        updated = str(instance.get("updatedAt") or instance.get("createdAt") or "-")
        table.add_row(
            str(instance.get("id") or "-")[:12],
            str(instance.get("version") or "-"),
            str(instance.get("status") or "-"),
            str(instance.get("taskId") or "-")[:12],
            endpoint,
            updated,
        )

    console.print(table)


def parse_timestamp_value(timestamp: str | None) -> float | None:
    """Convert an ISO timestamp to epoch seconds for log cursors."""
    if not timestamp:
        return None

    normalized = timestamp.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized).timestamp()
    except ValueError:
        return None


def print_app_logs(
    api: AppAPI,
    id_or_slug: str,
    *,
    query: str | None = None,
    limit: int | None = None,
    from_time: str | None = None,
    to_time: str | None = None,
    sort: str | None = None,
    log_path: str | None = None,
    follow: bool = False,
) -> None:
    """Print app logs once or poll incrementally in follow mode."""
    if not follow:
        output = api.logs(
            id_or_slug,
            query=query,
            limit=limit,
            from_time=from_time,
            to_time=to_time,
            sort=sort,
            log_path=log_path,
            raw=False,
        )
        if output:
            print(output)
        return

    cursor_timestamp = from_time
    cursor_value = parse_timestamp_value(from_time)
    cursor_emitted_counts: dict[str, int] = {}
    effective_sort = sort or "asc"

    while True:
        payload = api.logs(
            id_or_slug,
            query=query,
            limit=limit,
            from_time=cursor_timestamp,
            to_time=to_time,
            sort=effective_sort,
            log_path=log_path,
            raw=True,
        )
        entries = extract_app_log_entries(payload)
        if entries and any(parse_timestamp_value(entry.get("timestamp")) is None for entry in entries):
            print_error(
                "--follow requires timestamped log entries from the server; "
                "retry without --follow for raw or untimestamped log output."
            )
            raise typer.Exit(1)
        poll_cursor_counts: dict[str, int] = {}

        for entry in entries:
            timestamp = entry.get("timestamp")
            log_path_value = entry.get("logPath") or ""
            message = entry.get("message") or ""
            dedupe_key = f"{log_path_value}|{message}"

            timestamp_value = parse_timestamp_value(timestamp)
            if (
                timestamp is not None
                and timestamp_value is not None
                and (cursor_value is None or timestamp_value > cursor_value)
            ):
                cursor_value = timestamp_value
                cursor_timestamp = timestamp
                cursor_emitted_counts = {}
                poll_cursor_counts = {}

            if (
                timestamp is not None
                and timestamp_value is not None
                and cursor_timestamp is not None
                and timestamp == cursor_timestamp
            ):
                occurrence = poll_cursor_counts.get(dedupe_key, 0) + 1
                poll_cursor_counts[dedupe_key] = occurrence
                if occurrence <= cursor_emitted_counts.get(dedupe_key, 0):
                    continue

            print(format_app_log_entry(entry))

        if poll_cursor_counts:
            cursor_emitted_counts = poll_cursor_counts

        time.sleep(1.0)


@app.command("create")
def create_app(
    name: str = typer.Option(..., "--name", help="App name"),
    port: int = typer.Option(..., "--port", help="Container port to expose"),
    slug: str | None = typer.Option(None, "--slug", help="Custom slug"),
    ready_types: list[str] = typer.Option(
        ["port_accessible"],
        "--ready",
        help="Ready types (port_accessible, http_health)",
    ),
    min_replicas: int = typer.Option(0, "--min", help="Minimum replicas"),
    max_replicas: int = typer.Option(3, "--max", help="Maximum replicas"),
    health_path: str | None = typer.Option(None, "--health-path", help="Health check path"),
    startup_command: str | None = typer.Option(None, "--startup-command", help="Startup command"),
    cpu_millis: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory_mb: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    idle_timeout_ms: int | None = typer.Option(None, "--idle-timeout", help="Idle timeout ms"),
    scale_up_cpu_pct: int | None = typer.Option(None, "--scale-up-cpu-pct", help="Scale up CPU threshold percent"),
    scale_down_cpu_pct: int | None = typer.Option(None, "--scale-down-cpu-pct", help="Scale down CPU threshold percent"),
    scale_up_mem_pct: int | None = typer.Option(None, "--scale-up-mem-pct", help="Scale up memory threshold percent"),
    scale_down_mem_pct: int | None = typer.Option(None, "--scale-down-mem-pct", help="Scale down memory threshold percent"),
    ready_timeout_ms: int | None = typer.Option(None, "--ready-timeout", help="Ready timeout ms"),
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """Create a new app."""
    allowed_ready = {"port_accessible", "http_health"}
    invalid = [v for v in ready_types if v not in allowed_ready]
    if invalid:
        print_error(f"Invalid ready types: {', '.join(invalid)}")
        raise typer.Exit(1)

    validate_replica_bounds(min_replicas, max_replicas)

    if "http_health" in ready_types and not health_path:
        health_path = "/health"

    client = get_client()
    api = AppAPI(client)

    payload: dict[str, object] = {
        "name": name,
        "containerPort": port,
        "readyTypes": ready_types,
        "minReplicas": min_replicas,
        "maxReplicas": max_replicas,
    }
    if slug:
        payload["slug"] = slug
    if health_path:
        payload["healthPath"] = health_path
    if startup_command:
        payload["startupCommand"] = startup_command
    if cpu_millis is not None:
        payload["cpuMillis"] = cpu_millis
    if memory_mb is not None:
        payload["memoryMb"] = memory_mb
    if idle_timeout_ms is not None:
        payload["idleTimeoutMs"] = idle_timeout_ms
    if scale_up_cpu_pct is not None:
        payload["scaleUpCpuPct"] = scale_up_cpu_pct
    if scale_down_cpu_pct is not None:
        payload["scaleDownCpuPct"] = scale_down_cpu_pct
    if scale_up_mem_pct is not None:
        payload["scaleUpMemPct"] = scale_up_mem_pct
    if scale_down_mem_pct is not None:
        payload["scaleDownMemPct"] = scale_down_mem_pct
    if ready_timeout_ms is not None:
        payload["readyTimeoutMs"] = ready_timeout_ms
    if workspace_id:
        payload["workspaceId"] = workspace_id

    try:
        result = api.create(payload)
        if json_output_enabled():
            emit_json(result)
            return
        print_success(f"App created: {result.slug}")
        console.print(f"ID: {result.id}")
    except APIError as e:
        print_error(f"Failed to create app: {e.message}")
        raise typer.Exit(1)


@app.command("deploy")
def deploy_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    snapshot: str = typer.Option(..., "--snapshot", "-s", help="Snapshot ID to deploy"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment overrides (KEY=VALUE)"),
    entrypoint: str | None = typer.Option(None, "--entrypoint", help="Entrypoint override"),
) -> None:
    """Deploy a new version to an app."""
    client = get_client()
    api = AppAPI(client)

    try:
        env_overrides = parse_env(env) if env else None
    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1)

    try:
        version = api.deploy(
            id_or_slug,
            snapshot_id=snapshot,
            env_overrides=env_overrides,
            entrypoint_override=entrypoint,
        )
        if json_output_enabled():
            emit_json(version)
            return
        print_success(f"Deployed version {version.version}")
    except APIError as e:
        print_error(f"Failed to deploy: {e.message}")
        raise typer.Exit(1)


@app.command("ls")
def list_apps(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """List apps."""
    client = get_client()
    api = AppAPI(client)

    try:
        apps = api.list_all(workspace_id=workspace_id)
        if json_output_enabled():
            emit_json(apps)
            return

        if not apps:
            console.print("[dim]No apps found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Name")
        table.add_column("Slug")
        table.add_column("Version")
        table.add_column("Status")
        table.add_column("Replicas")

        for a in apps:
            table.add_row(
                a.name,
                a.slug,
                a.current_version or "-",
                a.status,
                f"{a.config.min_replicas}-{a.config.max_replicas}",
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to list apps: {e.message}")
        raise typer.Exit(1)


@app.command("inspect")
def inspect_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
) -> None:
    """Show app details."""
    client = get_client()
    api = AppAPI(client)

    try:
        a = api.get(id_or_slug)
        if json_output_enabled():
            emit_json(a)
            return

        table = Table(show_header=False)
        table.add_column("Field", style="cyan")
        table.add_column("Value")

        table.add_row("ID", a.id)
        table.add_row("Name", a.name)
        table.add_row("Slug", a.slug)
        table.add_row("Status", a.status)
        table.add_row("Current Version", a.current_version or "-")
        table.add_row("Port", str(a.config.container_port))
        table.add_row("Ready Types", ", ".join(a.config.ready_types))
        table.add_row("Min Replicas", str(a.config.min_replicas))
        table.add_row("Max Replicas", str(a.config.max_replicas))
        if a.config.cpu_millis:
            table.add_row("CPU (millis)", str(a.config.cpu_millis))
        if a.config.memory_mb:
            table.add_row("Memory (MB)", str(a.config.memory_mb))

        console.print(table)
    except APIError as e:
        print_error(f"Failed to get app: {e.message}")
        raise typer.Exit(1)


@app.command("update")
def update_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    name: str | None = typer.Option(None, "--name", help="New name"),
    min_replicas: int | None = typer.Option(None, "--min", help="Min replicas"),
    max_replicas: int | None = typer.Option(None, "--max", help="Max replicas"),
    health_path: str | None = typer.Option(None, "--health-path", help="Health check path"),
    startup_command: str | None = typer.Option(None, "--startup-command", help="Startup command"),
    cpu_millis: int | None = typer.Option(None, "--cpu", help="CPU millis"),
    memory_mb: int | None = typer.Option(None, "--memory", help="Memory MB"),
    idle_timeout_ms: int | None = typer.Option(None, "--idle-timeout", help="Idle timeout ms"),
    scale_up_cpu_pct: int | None = typer.Option(None, "--scale-up-cpu-pct", help="Scale up CPU threshold percent"),
    scale_down_cpu_pct: int | None = typer.Option(None, "--scale-down-cpu-pct", help="Scale down CPU threshold percent"),
    scale_up_mem_pct: int | None = typer.Option(None, "--scale-up-mem-pct", help="Scale up memory threshold percent"),
    scale_down_mem_pct: int | None = typer.Option(None, "--scale-down-mem-pct", help="Scale down memory threshold percent"),
    ready_timeout_ms: int | None = typer.Option(None, "--ready-timeout", help="Ready timeout ms"),
) -> None:
    """Update app config."""
    client = get_client()
    api = AppAPI(client)

    try:
        if min_replicas is not None or max_replicas is not None:
            app_info = api.get(id_or_slug)
            validate_replica_bounds(
                min_replicas,
                max_replicas,
                current_min=app_info.config.min_replicas,
                current_max=app_info.config.max_replicas,
            )

        updates: dict[str, object] = {}
        if name:
            updates["name"] = name
        if min_replicas is not None:
            updates["minReplicas"] = min_replicas
        if max_replicas is not None:
            updates["maxReplicas"] = max_replicas
        if health_path is not None:
            updates["healthPath"] = health_path
        if startup_command is not None:
            updates["startupCommand"] = startup_command
        if cpu_millis is not None:
            updates["cpuMillis"] = cpu_millis
        if memory_mb is not None:
            updates["memoryMb"] = memory_mb
        if idle_timeout_ms is not None:
            updates["idleTimeoutMs"] = idle_timeout_ms
        if scale_up_cpu_pct is not None:
            updates["scaleUpCpuPct"] = scale_up_cpu_pct
        if scale_down_cpu_pct is not None:
            updates["scaleDownCpuPct"] = scale_down_cpu_pct
        if scale_up_mem_pct is not None:
            updates["scaleUpMemPct"] = scale_up_mem_pct
        if scale_down_mem_pct is not None:
            updates["scaleDownMemPct"] = scale_down_mem_pct
        if ready_timeout_ms is not None:
            updates["readyTimeoutMs"] = ready_timeout_ms

        if not updates:
            print_error("No updates specified")
            raise typer.Exit(1)

        result = api.update(id_or_slug, **updates)
        if json_output_enabled():
            emit_json(result)
            return
        print_success(f"App {result.slug} updated")
    except APIError as e:
        print_error(f"Failed to update app: {e.message}")
        raise typer.Exit(1)


@app.command("versions")
def list_versions(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    delete: str | None = typer.Option(None, "--delete", "-d", help="Delete a version"),
) -> None:
    """List or delete app versions."""
    client = get_client()
    api = AppAPI(client)

    if delete:
        try:
            api.delete_version(id_or_slug, delete)
            if json_output_enabled():
                emit_json({"success": True, "deletedVersion": delete})
                return
            print_success(f"Deleted version {delete}")
        except APIError as e:
            print_error(f"Failed to delete version: {e.message}")
            raise typer.Exit(1)
        return

    try:
        app_info = api.get(id_or_slug)
        versions = api.get_versions(id_or_slug)
        if json_output_enabled():
            emit_json(versions)
            return

        if not versions:
            console.print("[dim]No versions found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Version")
        table.add_column("Snapshot")
        table.add_column("Created")
        table.add_column("Current")

        for v in sorted(versions, key=lambda x: x.created_at, reverse=True):
            is_current = "*" if v.version == app_info.current_version else ""
            table.add_row(
                v.version,
                v.snapshot_id[:12],
                v.created_at.strftime("%Y-%m-%d %H:%M"),
                is_current,
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to get versions: {e.message}")
        raise typer.Exit(1)


@app.command("rollback")
def rollback_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    version: str = typer.Argument(..., help="Version to rollback to"),
) -> None:
    """Rollback app to a previous version."""
    client = get_client()
    api = AppAPI(client)

    try:
        app_version = api.rollback(id_or_slug, version)
        if json_output_enabled():
            emit_json(app_version)
            return
        print_success(f"Rolled back to version {version}")
    except APIError as e:
        print_error(f"Failed to rollback: {e.message}")
        raise typer.Exit(1)


@app.command("rm")
def delete_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete an app."""
    if not force:
        typer.confirm(f"Delete app {id_or_slug}?", abort=True)

    client = get_client()
    api = AppAPI(client)

    try:
        api.delete(id_or_slug)
        if json_output_enabled():
            emit_json({"success": True, "idOrSlug": id_or_slug})
            return
        print_success(f"App {id_or_slug} deleted")
    except APIError as e:
        print_error(f"Failed to delete app: {e.message}")
        raise typer.Exit(1)


@app.command("instances")
@app.command("status")
def app_instances(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
) -> None:
    """Show app status and instance details."""
    client = get_client()
    api = AppAPI(client)

    try:
        app_info = api.get(id_or_slug)
        instances = api.get_instances(id_or_slug)
        print_app_instances(app_info, instances)
    except APIError as e:
        print_error(f"Failed to get app status: {e.message}")
        raise typer.Exit(1)


@app.command("logs")
def app_logs(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    query: str | None = typer.Option(None, "--query", "-q", help="Search query"),
    limit: int | None = typer.Option(None, "--limit", "-n", help="Max entries"),
    from_time: str | None = typer.Option(None, "--from", help="Start time (ISO 8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time (ISO 8601)"),
    sort: str | None = typer.Option(None, "--sort", help="Sort order (asc/desc)"),
    log_path: str | None = typer.Option(None, "--log-path", help="Filter by log path"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
) -> None:
    """View app logs."""
    if follow and json_output_enabled():
        print_error("--follow is not supported with --json")
        raise typer.Exit(1)
    if follow and sort == "desc":
        print_error("--follow requires ascending log order; omit --sort or use --sort asc")
        raise typer.Exit(1)

    client = get_client()
    api = AppAPI(client)

    try:
        if json_output_enabled():
            emit_json(
                api.logs(
                    id_or_slug,
                    query=query,
                    limit=limit,
                    from_time=from_time,
                    to_time=to_time,
                    sort=sort,
                    log_path=log_path,
                    raw=True,
                )
            )
            return
        print_app_logs(
            api,
            id_or_slug,
            query=query,
            limit=limit,
            from_time=from_time,
            to_time=to_time,
            sort=sort,
            log_path=log_path,
            follow=follow,
        )
    except APIError as e:
        print_error(f"Failed to get logs: {e.message}")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        pass
