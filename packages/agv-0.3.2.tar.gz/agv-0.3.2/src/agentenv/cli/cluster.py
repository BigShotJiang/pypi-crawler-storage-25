"""Compute cluster CLI commands."""

from __future__ import annotations

import json
from typing import Any

import typer
from rich import box
from rich.console import Console
from rich.table import Table

from ..api.client import APIError, Client
from ..api.cluster import ClusterAPI
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import _colored_status, _format_datetime, emit_json, json_output_enabled, print_error, print_success

app = typer.Typer(help="Ray and Spark cluster commands")
console = Console()
PROVISIONING_STEP_LABELS = {
    "queued": "Waiting in queue",
    "creating_head": "Creating head node",
    "waiting_for_head": "Starting head node",
    "setting_up_network": "Setting up network",
    "creating_workers": "Creating worker nodes",
}


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _emit(data: Any) -> None:
    """Emit output in the selected format."""
    if json_output_enabled():
        emit_json(data)
        return
    print(json.dumps(data, indent=2, default=str))


def _resolve_workspace_id(workspace_id: str | None) -> str:
    """Resolve the target workspace for cluster creation."""
    resolved = workspace_id or get_settings().workspace
    if resolved:
        return resolved

    print_error("No workspace specified. Use --workspace or set a default with 'agv workspace use'.")
    raise typer.Exit(1)


def _cluster_metadata(cluster: dict[str, Any]) -> dict[str, Any]:
    value = cluster.get("metadata")
    return value if isinstance(value, dict) else {}


def _cluster_head_port(cluster: dict[str, Any]) -> Any:
    metadata = _cluster_metadata(cluster)
    if str(cluster.get("type") or "").lower() == "ray":
        return metadata.get("headRayClientHostPort")
    return metadata.get("headSparkConnectHostPort")


def _cluster_status_summary(cluster: dict[str, Any]) -> dict[str, Any]:
    metadata = _cluster_metadata(cluster)
    step = metadata.get("provisioningStep")
    return {
        "id": cluster.get("id"),
        "name": cluster.get("name"),
        "type": cluster.get("type"),
        "status": cluster.get("status"),
        "progress": cluster.get("progress"),
        "provisioningStep": step,
        "provisioningLabel": PROVISIONING_STEP_LABELS.get(str(step), str(step)) if step else None,
        "failureReason": metadata.get("failureReason"),
        "headHost": metadata.get("headHost"),
        "headPort": _cluster_head_port(cluster),
        "workspaceId": cluster.get("workspaceId"),
    }


def _wait_for_expected_cluster_state(
    api: ClusterAPI,
    cluster_id: str,
    *,
    target_status: str,
    timeout: int,
) -> dict[str, Any]:
    """Wait until a cluster reaches the requested state or another terminal state."""
    latest = api.wait_for_cluster(cluster_id, timeout=timeout, target_status=target_status)
    actual = str(latest.get("status") or "").lower()
    if actual == target_status.lower():
        return latest

    details = _cluster_status_summary(latest)
    reason = details.get("failureReason")
    suffix = f": {reason}" if reason else ""
    raise RuntimeError(
        f"Cluster {cluster_id} reached {actual or 'unknown'} instead of {target_status}{suffix}"
    )


def _print_cluster_table(clusters: list[dict[str, Any]]) -> None:
    """Render cluster rows in a table."""
    if not clusters:
        console.print("[dim]No clusters found.[/dim]")
        return

    table = Table(title="Clusters")
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Shape")
    table.add_column("Workspace")
    table.add_column("Created")

    for cluster in clusters:
        config = cluster.get("config") or {}
        table.add_row(
            str(cluster.get("id", ""))[:12],
            str(cluster.get("type", "-")),
            str(cluster.get("status", "-")),
            str(config.get("shape", "-")),
            str(cluster.get("workspaceId", "-")),
            str(cluster.get("createdAt", "-")),
        )

    console.print(table)


def _print_cluster_detail(cluster: dict[str, Any]) -> None:
    """Render a human-readable detail view for a cluster."""
    metadata = _cluster_metadata(cluster)
    config = cluster.get("config") or {}
    table = Table(
        title=f"Cluster: {cluster.get('name') or cluster.get('id')}",
        box=box.ROUNDED,
        show_header=False,
    )
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", str(cluster.get("id") or "-"))
    table.add_row("Status", _colored_status(str(cluster.get("status") or "-")))
    table.add_row("Type", str(cluster.get("type") or "-"))
    table.add_row("Workspace", str(cluster.get("workspaceId") or "-"))
    table.add_row("Shape", str(config.get("shape") or "-"))

    node_count = config.get("nodeCount")
    if node_count is not None:
        table.add_row("Nodes", f"{int(node_count) + 1} total ({node_count} workers)")

    gpu_type = config.get("gpuType")
    gpus_per_node = config.get("gpusPerNode")
    if gpu_type is not None or gpus_per_node is not None:
        table.add_row("GPU per node", f"{gpus_per_node or 0}x{gpu_type or '-'}")

    image = config.get("image")
    if image:
        table.add_row("Image", str(image))

    progress = cluster.get("progress")
    if progress is not None:
        table.add_row("Progress", f"{progress}%")

    provisioning_step = metadata.get("provisioningStep")
    if provisioning_step:
        table.add_row(
            "Provisioning",
            PROVISIONING_STEP_LABELS.get(str(provisioning_step), str(provisioning_step)),
        )

    table.add_section()

    table.add_row("Head Host", str(metadata.get("headHost") or "-"))
    table.add_row("Head Port", str(_cluster_head_port(cluster) or "-"))
    table.add_row("Created", _format_datetime(cluster.get("createdAt") or "-"))

    started_at = metadata.get("startedAt") or metadata.get("startedAtMs")
    stopped_at = metadata.get("stoppedAt") or metadata.get("stoppedAtMs")
    if started_at:
        table.add_row("Started", str(started_at))
    if stopped_at:
        table.add_row("Stopped", str(stopped_at))

    failure_reason = metadata.get("failureReason")
    if failure_reason:
        table.add_row("Failure", str(failure_reason))

    console.print(table)


def _print_cluster_status(cluster: dict[str, Any]) -> None:
    """Render a concise status view for a single cluster."""
    summary = _cluster_status_summary(cluster)
    table = Table(title=f"Cluster Status: {summary.get('name') or summary.get('id')}", box=box.ROUNDED)
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Progress")
    table.add_column("Step")
    table.add_column("Head")

    head = summary.get("headHost") or "-"
    if summary.get("headPort"):
        head = f"{head}:{summary['headPort']}"

    table.add_row(
        str(summary.get("id") or "")[:12],
        str(summary.get("type") or "-"),
        _colored_status(str(summary.get("status") or "-")),
        f"{summary['progress']}%" if summary.get("progress") is not None else "-",
        str(summary.get("provisioningLabel") or "-"),
        str(head),
    )
    console.print(table)

    if summary.get("failureReason"):
        console.print(f"[red]Failure:[/red] {summary['failureReason']}")


@app.command("ray")
def create_ray_cluster(
    shape: str = typer.Argument(..., help="Cluster shape (for example 4x2xH100)"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    name: str | None = typer.Option(None, "--name", help="Cluster name"),
    image: str | None = typer.Option(None, "--image", help="Image override"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID override"),
    allow_cidr: str | None = typer.Option(None, "--allow-cidr", help="Direct-connect allowlist CIDR"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for the cluster to reach running state"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Create a Ray cluster."""
    client = get_client()
    api = ClusterAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        with status("Creating Ray cluster..."):
            cluster = api.create_ray_cluster(
                workspace_id=resolved_workspace_id,
                shape=shape,
                name=name,
                image=image,
                snapshot_id=snapshot_id,
                allow_cidr=allow_cidr,
            )
        if wait:
            with status("Waiting for cluster to become ready..."):
                cluster = _wait_for_expected_cluster_state(
                    api,
                    cluster["id"],
                    target_status="running",
                    timeout=timeout,
                )
    except (RuntimeError, TimeoutError) as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to create Ray cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    print_success(f"Ray cluster {cluster['id']} created")
    _emit(cluster)


@app.command("spark")
def create_spark_cluster(
    shape: str = typer.Argument(..., help="Cluster shape (for example 4x2xH100)"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    name: str | None = typer.Option(None, "--name", help="Cluster name"),
    image: str | None = typer.Option(None, "--image", help="Image override"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID override"),
    allow_cidr: str | None = typer.Option(None, "--allow-cidr", help="Direct-connect allowlist CIDR"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for the cluster to reach running state"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Create a Spark cluster."""
    client = get_client()
    api = ClusterAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        with status("Creating Spark cluster..."):
            cluster = api.create_spark_cluster(
                workspace_id=resolved_workspace_id,
                shape=shape,
                name=name,
                image=image,
                snapshot_id=snapshot_id,
                allow_cidr=allow_cidr,
            )
        if wait:
            with status("Waiting for cluster to become ready..."):
                cluster = _wait_for_expected_cluster_state(
                    api,
                    cluster["id"],
                    target_status="running",
                    timeout=timeout,
                )
    except (RuntimeError, TimeoutError) as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to create Spark cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    print_success(f"Spark cluster {cluster['id']} created")
    _emit(cluster)


@app.command("ls")
def list_clusters(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List clusters."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        clusters = api.list_clusters(workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to list clusters: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(clusters)
        return

    _print_cluster_table(clusters)


@app.command("inspect")
def inspect_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
) -> None:
    """Show cluster details."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        cluster = api.get_cluster(cluster_id)
    except APIError as e:
        print_error(f"Failed to get cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    _print_cluster_detail(cluster)


@app.command("status")
def cluster_status(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
) -> None:
    """Show concise status for a cluster."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        cluster = api.get_cluster(cluster_id)
    except APIError as e:
        print_error(f"Failed to get cluster status: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(_cluster_status_summary(cluster))
        return

    _print_cluster_status(cluster)


@app.command("wait")
def wait_for_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    target_status: str = typer.Option("running", "--for-state", help="Status to wait for"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Wait for a cluster to reach a given status."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        with status(f"Waiting for cluster {cluster_id} to reach {target_status}..."):
            cluster = _wait_for_expected_cluster_state(
                api,
                cluster_id,
                target_status=target_status,
                timeout=timeout,
            )
    except (RuntimeError, TimeoutError) as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to wait for cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(_cluster_status_summary(cluster))
        return

    print_success(f"Cluster {cluster_id} reached {target_status}")
    _print_cluster_status(cluster)


@app.command("stop")
def stop_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for the cluster to stop"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Stop a cluster."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        with status(f"Stopping cluster {cluster_id}..."):
            cluster = api.stop_cluster(cluster_id)
        if wait:
            with status(f"Waiting for cluster {cluster_id} to stop..."):
                cluster = _wait_for_expected_cluster_state(
                    api,
                    cluster_id,
                    target_status="stopped",
                    timeout=timeout,
                )
    except (RuntimeError, TimeoutError) as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to stop cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    if wait:
        print_success(f"Cluster {cluster_id} stopped")
        _print_cluster_status(cluster)
        return

    print_success(f"Cluster {cluster_id} stop requested")
    _emit(cluster)
