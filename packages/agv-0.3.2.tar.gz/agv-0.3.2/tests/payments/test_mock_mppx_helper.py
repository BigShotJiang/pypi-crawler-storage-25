"""Tests ensuring the mock helper is not part of runtime CLI payments."""

import importlib

import pytest


def test_mock_helper_module_is_not_available_at_runtime() -> None:
    """Runtime code should not expose a dedicated mock payment helper module."""
    with pytest.raises(ModuleNotFoundError):
        importlib.import_module("agentenv.payments.mock_mppx_helper")
