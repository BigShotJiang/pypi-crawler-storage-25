"""Tests for official-only payment helper wiring."""

from __future__ import annotations

from importlib.util import find_spec

from agentenv.payments.official_mppx_helper import OfficialMppxHelper


def test_official_helper_can_be_constructed_directly() -> None:
    """The official helper remains the only runtime helper."""
    helper = OfficialMppxHelper()

    assert isinstance(helper, OfficialMppxHelper)


def test_runtime_helper_factory_module_is_removed() -> None:
    """The runtime CLI should no longer route through a helper factory."""
    assert find_spec("agentenv.payments.mppx_helper") is None


def test_runtime_payment_mode_module_is_removed() -> None:
    """The runtime CLI should no longer parse a payment mode."""
    assert find_spec("agentenv.payments.payment_mode") is None
