"""Tests for the official MPPX helper."""

import subprocess
from unittest.mock import patch

import pytest

from agentenv.payments.official_mppx_helper import OfficialMppxHelper


def test_official_helper_raises_clear_error_when_runner_is_unavailable() -> None:
    """Official helper should fail before subprocess execution when unavailable."""
    helper = OfficialMppxHelper()

    with (
        patch("agentenv.payments.official_mppx_helper.shutil.which", return_value=None),
        patch(
            "agentenv.payments.official_mppx_helper.subprocess.run",
            side_effect=AssertionError("runner should not execute"),
        ),
    ):
        with pytest.raises(
            RuntimeError,
            match="Official machine-payment runner is not configured",
        ):
            helper.run_payment({"providerReference": "pi_123"})


def test_run_payment_returns_authorization_header_string() -> None:
    """Official helper should return the Authorization header string directly."""
    helper = OfficialMppxHelper()

    with (
        patch("agentenv.payments.official_mppx_helper.shutil.which", return_value="/usr/bin/node"),
        patch(
            "agentenv.payments.official_mppx_helper.Path.exists",
            return_value=True,
        ),
        patch(
            "agentenv.payments.official_mppx_helper.subprocess.run",
            return_value=subprocess.CompletedProcess(
                args=["node", "run-payment.mjs"],
                returncode=0,
                stdout='{"authorizationHeader":"MACHINE mpp-token"}',
                stderr="",
            ),
        ),
    ):
        assert helper.run_payment({"providerReference": "pi_123"}) == "MACHINE mpp-token"
