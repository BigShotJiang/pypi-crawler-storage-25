"""Tests for credential storage fallback behavior."""

import json
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
from unittest.mock import patch

from typer.testing import CliRunner

from agentenv.api.file import FileAPI
from agentenv.config import storage as storage_module
from agentenv.config.storage import CredentialStorage
from agentenv.cli.app import app


runner = CliRunner()


def _file_metadata_payload(**overrides) -> dict[str, object]:
    payload: dict[str, object] = {
        "name": "report.txt",
        "path": "/docs/report.txt",
        "sizeBytes": 12,
        "mimeType": "text/plain",
        "createdAt": datetime(2026, 4, 1, tzinfo=UTC).isoformat().replace("+00:00", "Z"),
        "modifiedAt": datetime(2026, 4, 1, tzinfo=UTC).isoformat().replace("+00:00", "Z"),
        "isDirectory": False,
    }
    payload.update(overrides)
    return payload


def test_uses_file_storage_when_keyring_module_unavailable(
    monkeypatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", False)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_file")

    assert storage._use_keyring is False
    assert storage.get_api_key() == "sk_test_file"
    assert (tmp_path / ".agentenv" / "credentials.json").exists()


def test_gateway_key_round_trips_through_storage(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", False)

    storage = CredentialStorage()
    storage.set_gateway_key("cr_test_gateway")

    assert storage.get_gateway_key() == "cr_test_gateway"
    assert json.loads((tmp_path / ".agentenv" / "credentials.json").read_text()) == {
        "gateway_key": "cr_test_gateway"
    }


def test_keeps_keyring_backend_when_runtime_is_healthy(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    mock_keyring = Mock()
    mock_keyring.get_password.return_value = "sk_test_keyring"
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_keyring")

    assert storage._use_keyring is True
    assert storage.get_api_key() == "sk_test_keyring"
    assert not (tmp_path / ".agentenv" / "credentials.json").exists()


def test_falls_back_to_file_when_keyring_set_fails(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    mock_keyring = Mock()
    mock_keyring.set_password.side_effect = RuntimeError("backend not available")
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_fallback")

    assert storage._use_keyring is False
    assert storage.get_api_key() == "sk_test_fallback"
    assert (tmp_path / ".agentenv" / "credentials.json").exists()


def test_falls_back_to_file_when_keyring_get_fails(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    creds_file = tmp_path / ".agentenv" / "credentials.json"
    creds_file.parent.mkdir(mode=0o700, exist_ok=True)
    creds_file.write_text(json.dumps({"api_key": "sk_test_from_file"}))

    mock_keyring = Mock()
    mock_keyring.get_password.side_effect = RuntimeError("prompt dismissed")
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    value = storage.get_api_key()

    assert value == "sk_test_from_file"
    assert storage._use_keyring is False


def test_clear_all_clears_file_after_keyring_failure(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    creds_file = tmp_path / ".agentenv" / "credentials.json"
    creds_file.parent.mkdir(mode=0o700, exist_ok=True)
    creds_file.write_text(json.dumps({"api_key": "sk_test_from_file"}))

    mock_keyring = Mock()
    mock_keyring.delete_password.side_effect = RuntimeError("collection unavailable")
    mock_keyring.errors.PasswordDeleteError = ValueError
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.clear_all()

    assert storage._use_keyring is False
    assert not creds_file.exists()


def test_file_api_list_alias_uses_list_all() -> None:
    client = Mock()
    client.get.return_value.json.return_value = [
        {
            "name": "report.txt",
            "path": "/docs/report.txt",
            "sizeBytes": 12,
            "mimeType": "text/plain",
            "createdAt": "2026-04-01T00:00:00Z",
            "modifiedAt": "2026-04-01T00:00:00Z",
            "isDirectory": False,
        }
    ]

    api = FileAPI(client)
    result = api.list(workspace_id="wk_123", path="/docs")

    client.get.assert_called_once_with(
        "/v1/files/",
        params={"workspaceId": "wk_123", "path": "/docs"},
    )
    assert len(result) == 1
    assert result[0].name == "report.txt"
    assert result[0].path == "/docs/report.txt"


def test_file_ls_invokes_list_api_and_renders_output() -> None:
    settings = Mock()
    settings.api_url = "http://test"
    settings.api_key = None
    settings.access_token = "access-token"
    settings.workspace = None
    settings.is_authenticated.return_value = True

    listed_file = SimpleNamespace(
        name="report.txt",
        path="/docs/report.txt",
        size_bytes=12,
        mime_type="text/plain",
        created_at="2026-04-01T00:00:00Z",
        modified_at="2026-04-01T00:00:00Z",
        is_directory=False,
    )

    with (
        patch("agentenv.cli.file.get_settings", return_value=settings),
        patch("agentenv.cli.file.Client"),
        patch("agentenv.cli.file.FileAPI") as mock_api_class,
    ):
        mock_api = Mock()
        mock_api.list.return_value = [listed_file]
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["file", "ls", "/docs"])

    assert result.exit_code == 0
    mock_api.list.assert_called_once_with(None, "/docs")
    assert "report.txt" in result.output


def test_file_api_upload_sends_workspace_and_path_as_query_params(tmp_path: Path) -> None:
    file_path = tmp_path / "report.txt"
    file_path.write_text("hello", encoding="utf-8")

    client = Mock()
    client.post.return_value.json.return_value = _file_metadata_payload()

    api = FileAPI(client)
    result = api.upload(str(file_path), workspace_id="wk_123", remote_path="/docs/report.txt")

    client.post.assert_called_once()
    _, kwargs = client.post.call_args
    assert kwargs["params"] == {"workspaceId": "wk_123", "path": "/docs/report.txt"}
    assert "data" not in kwargs
    assert kwargs["files"]["file"][0] == "report.txt"
    assert result.path == "/docs/report.txt"


def test_file_api_create_directory_sends_query_params() -> None:
    client = Mock()
    client.post.return_value.json.return_value = _file_metadata_payload(
        name="docs",
        path="/docs",
        sizeBytes=0,
        mimeType="inode/directory",
        isDirectory=True,
    )

    api = FileAPI(client)
    result = api.create_directory("/docs", workspace_id="wk_123")

    client.post.assert_called_once_with(
        "/v1/files/directory",
        params={"path": "/docs", "workspaceId": "wk_123"},
    )
    assert result.is_directory is True


def test_file_api_update_metadata_sends_query_params_and_custom_metadata_body() -> None:
    client = Mock()
    client.patch.return_value.json.return_value = _file_metadata_payload()

    api = FileAPI(client)
    result = api.update_metadata(
        "/docs/report.txt",
        {"owner": "alice"},
        workspace_id="wk_123",
    )

    client.patch.assert_called_once_with(
        "/v1/files/metadata",
        params={"path": "/docs/report.txt", "workspaceId": "wk_123"},
        json={"customMetadata": {"owner": "alice"}},
    )
    assert result.name == "report.txt"


def test_file_rm_help_describes_file_only() -> None:
    result = runner.invoke(app, ["file", "rm", "--help"])

    assert result.exit_code == 0
    assert "Delete a file." in result.output
    assert "Delete a file or directory." not in result.output


def test_file_set_metadata_invokes_api_with_parsed_json() -> None:
    settings = Mock()
    settings.api_url = "http://test"
    settings.api_key = None
    settings.access_token = "access-token"
    settings.workspace = None
    settings.is_authenticated.return_value = True

    with (
        patch("agentenv.cli.file.get_settings", return_value=settings),
        patch("agentenv.cli.file.Client"),
        patch("agentenv.cli.file.FileAPI") as mock_api_class,
    ):
        mock_api = Mock()
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "file",
                "set-metadata",
                "/docs/report.txt",
                "--metadata",
                '{"owner":"alice","retentionDays":30}',
            ],
        )

    assert result.exit_code == 0
    mock_api.update_metadata.assert_called_once_with(
        "/docs/report.txt",
        {"owner": "alice", "retentionDays": 30},
        None,
    )
    assert "Metadata updated: /docs/report.txt" in result.output
