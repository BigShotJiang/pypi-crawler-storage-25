"""Tests for agent run API wrappers."""

from inspect import signature
from pathlib import Path
from unittest.mock import Mock

from agentenv.api.agent_run import AgentRunAPI
from agentenv.api.client import APIError

REPO_ROOT = Path(__file__).resolve().parents[3]


def test_preflight_posts_to_preflight_endpoint() -> None:
    """AgentRunAPI.preflight should POST to the optional validation endpoint."""
    mock_client = Mock()
    mock_client.post.return_value.json.return_value = {
        "eligible": True,
        "amountCents": 1000,
    }

    result = AgentRunAPI(mock_client).preflight(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        prompt="run this agent",
    )

    mock_client.post.assert_called_once_with(
        "/v1/agent/run/preflight",
        json={
            "workspaceId": "wk_123",
            "billingAccountId": "ba_123",
            "amountCents": 1000,
            "prompt": "run this agent",
        },
    )
    assert result == {
        "eligible": True,
        "amountCents": 1000,
    }


def test_run_posts_to_run_endpoint() -> None:
    """AgentRunAPI.run should POST to the run endpoint and return response."""
    mock_client = Mock()
    mock_client.post.return_value.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "agent result", "status": "completed"},
    }

    result = AgentRunAPI(mock_client).run(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        idempotency_key="idem_123",
        prompt="run this agent",
    )

    mock_client.post.assert_called_once_with(
        "/v1/agent/run",
        json={
            "workspaceId": "wk_123",
            "billingAccountId": "ba_123",
            "amountCents": 1000,
            "idempotencyKey": "idem_123",
            "prompt": "run this agent",
        },
    )
    assert result["requestId"] == "req_123"


def test_run_attaches_official_authorization_header_on_retry() -> None:
    """AgentRunAPI.run should reuse the same request and attach Authorization."""
    mock_client = Mock()
    mock_client.post.return_value.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "agent result", "status": "completed"},
    }

    AgentRunAPI(mock_client).run(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        idempotency_key="idem_123",
        prompt="run this agent",
        authorization_header="MACHINE mpp-token",
    )

    mock_client.post.assert_called_once_with(
        "/v1/agent/run",
        json={
            "workspaceId": "wk_123",
            "billingAccountId": "ba_123",
            "amountCents": 1000,
            "idempotencyKey": "idem_123",
            "prompt": "run this agent",
        },
        headers={
            "Authorization": "MACHINE mpp-token",
        },
    )


def test_run_captures_402_challenge() -> None:
    """AgentRunAPI.run should capture 402 challenge response."""
    mock_client = Mock()
    mock_client.post.side_effect = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )

    result = AgentRunAPI(mock_client).run(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        idempotency_key="idem_123",
        prompt="run this agent",
    )

    assert result["statusCode"] == 402
    assert result["requestId"] == "req_123"
    assert result["challenge"] is not None
    assert "paymentMode" not in result


def test_run_preserves_terminal_402_without_challenge() -> None:
    """AgentRunAPI.run should preserve terminal 402 payloads without inventing a challenge."""
    mock_client = Mock()
    mock_client.post.side_effect = APIError(
        status_code=402,
        message="Payment failed at provider.",
        details={
            "requestId": "req_123",
            "paid": False,
            "error": "Payment failed at provider.",
        },
    )

    result = AgentRunAPI(mock_client).run(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        idempotency_key="idem_123",
        prompt="run this agent",
    )

    assert result == {
        "requestId": "req_123",
        "paid": False,
        "error": "Payment failed at provider.",
        "statusCode": 402,
    }
    assert "challenge" not in result


def test_run_normalizes_202_processing_response() -> None:
    """AgentRunAPI.run should preserve 202 processing responses."""
    mock_client = Mock()
    mock_client.post.return_value.status_code = 202
    mock_client.post.return_value.json.return_value = {
        "requestId": "req_123",
        "processing": True,
    }

    result = AgentRunAPI(mock_client).run(
        workspace_id="wk_123",
        billing_account_id="ba_123",
        amount_cents=1000,
        idempotency_key="idem_123",
        prompt="run this agent",
        authorization_header="MACHINE mpp-token",
    )

    assert result == {
        "requestId": "req_123",
        "processing": True,
        "statusCode": 202,
    }


def test_agent_run_api_does_not_expose_custom_replay_method() -> None:
    """Retry should reuse run() instead of exposing a separate replay API method."""
    assert not hasattr(AgentRunAPI, "replay_run")


def test_run_signature_no_longer_accepts_quote_id() -> None:
    """The public run() contract should not include quote_id anymore."""
    assert "quote_id" not in signature(AgentRunAPI.run).parameters
    assert "preflight" in dir(AgentRunAPI)


def test_agent_run_docs_match_verified_execution_contract() -> None:
    """Design and protocol docs should reflect the verified execution flow."""
    protocol_contract = (
        REPO_ROOT
        / ".agents/skills/agent-run-payment/references/protocol-contract.md"
    ).read_text()
    design_doc_path = (
        REPO_ROOT
        / "docs/superpowers/specs/2026-04-01-agent-run-official-mpp-review-fixes-design.md"
    )

    assert "VERIFIED -> EXECUTING -> COMPLETED" in protocol_contract
    assert "executionToken" in protocol_contract

    if design_doc_path.exists():
        design_doc = design_doc_path.read_text()
        assert "PENDING_PAYMENT" in design_doc
        assert "CHALLENGED" not in design_doc
        assert "PAID -> execute" not in design_doc
