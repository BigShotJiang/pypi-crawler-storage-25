"""Tests for notebook API client."""

import pytest
from unittest.mock import Mock
from agentenv.api.notebook import NotebookAPI


@pytest.fixture
def mock_client():
    """Create a mock API client."""
    return Mock()


@pytest.fixture
def notebook_api(mock_client):
    """Create NotebookAPI with mock client."""
    return NotebookAPI(mock_client)


def test_create_session_includes_workspace_id(notebook_api, mock_client):
    """Session create should always include workspaceId in request payload."""
    mock_client.post.return_value.json.return_value = {
        "id": "ns-1",
        "status": "starting",
        "notebookUrl": "https://example.com/lab",
        "createdAt": "2024-01-01T00:00:00Z",
    }

    session = notebook_api.create(
        workspace_id="wk-1",
        name="nb-session",
        cpu=1000,
        memory=2048,
    )

    assert session.id == "ns-1"
    assert session.notebook_url == "https://example.com/lab"
    mock_client.post.assert_called_once_with(
        "/v1/notebooks/sessions",
        json={
            "name": "nb-session",
            "workspaceId": "wk-1",
            "cpuMillis": 1000,
            "memoryMb": 2048,
        },
    )


def test_create_session_includes_extended_dto_fields(notebook_api, mock_client):
    """Session create should forward the current notebook session DTO fields."""
    mock_client.post.return_value.json.return_value = {
        "id": "ns-1",
        "status": "starting",
        "notebookUrl": "https://example.com/lab",
        "createdAt": "2024-01-01T00:00:00Z",
    }

    notebook_api.create(
        workspace_id="wk-1",
        name="analysis",
        image="docker://quay.io/jupyter/datascience-notebook:notebook-7.5.5",
        snapshot_id="snap-1",
        gpu_count=1,
        gpu_type="H100",
        storage_mode="persistent",
        env={"PYTHONUNBUFFERED": "1"},
        idle_ttl_seconds=600,
        persistent=False,
        snapshot_favor="disk",
        hard_kill_at="2026-02-06T21:00:00Z",
        hard_kill_after_seconds=3600,
    )

    mock_client.post.assert_called_once_with(
        "/v1/notebooks/sessions",
        json={
            "name": "analysis",
            "workspaceId": "wk-1",
            "cpuMillis": 2000,
            "memoryMb": 4096,
            "image": "docker://quay.io/jupyter/datascience-notebook:notebook-7.5.5",
            "snapshotId": "snap-1",
            "gpuCount": 1,
            "gpuType": "H100",
            "storageMode": "persistent",
            "env": {"PYTHONUNBUFFERED": "1"},
            "idleTtlSeconds": 600,
            "persistent": False,
            "snapshotFavor": "disk",
            "hardKillAt": "2026-02-06T21:00:00Z",
            "hardKillAfterSeconds": 3600,
        },
    )


def test_create_document(notebook_api, mock_client):
    """Test creating a notebook document."""
    mock_client.post.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo",
        "description": "test",
        "filePath": "/mnt/notebook.ipynb",
        "metadata": {
            "kernel": "python3",
            "runtime": "cpu",
            "autoSaveEnabled": True,
            "image": "docker://registry.example/custom:latest",
        },
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.create_document(
        workspace_id="wk-1",
        name="Demo",
        kernel="python3",
        image="docker://registry.example/custom:latest",
    )

    assert document.id == "nb-1"
    assert document.workspace_id == "wk-1"
    mock_client.post.assert_called_once_with(
        "/v1/notebooks",
        json={
            "workspaceId": "wk-1",
            "name": "Demo",
            "markdownFirstCell": False,
            "metadata": {
                "kernel": "python3",
                "image": "docker://registry.example/custom:latest",
            },
        },
    )


def test_list_documents(notebook_api, mock_client):
    """Test listing notebook documents."""
    mock_client.get.return_value.json.return_value = [
        {
            "id": "nb-1",
            "workspaceId": "wk-1",
            "name": "Demo",
            "filePath": "/mnt/notebook.ipynb",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-01T00:00:00Z",
        }
    ]

    documents = notebook_api.list_documents("wk-1")

    assert len(documents) == 1
    assert documents[0].id == "nb-1"
    mock_client.get.assert_called_once_with(
        "/v1/notebooks",
        params={"workspaceId": "wk-1"},
    )


def test_get_document(notebook_api, mock_client):
    """Test getting notebook document details."""
    mock_client.get.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo",
        "filePath": "/mnt/notebook.ipynb",
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.get_document("nb-1")

    assert document.id == "nb-1"
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-1")


def test_get_document_keeps_kernel_session_metadata(notebook_api, mock_client):
    """Document metadata should preserve kernelSessionId and unknown keys."""
    mock_client.get.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo",
        "filePath": "/mnt/notebook.ipynb",
        "metadata": {
            "kernel": "python3",
            "runtime": "cpu",
            "kernelSessionId": "session-123",
            "jupyterSessionId": "jupyter-123",
        },
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.get_document("nb-1")

    assert document.metadata is not None
    assert document.metadata.kernel_session_id == "session-123"
    dumped = document.model_dump(by_alias=True, exclude_none=True)
    assert dumped["metadata"]["kernelSessionId"] == "session-123"
    assert dumped["metadata"]["jupyterSessionId"] == "jupyter-123"
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-1")


def test_update_document(notebook_api, mock_client):
    """Test updating notebook document."""
    mock_client.put.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo v2",
        "filePath": "/mnt/notebook.ipynb",
        "metadata": {"kernel": "python3", "runtime": "cpu"},
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.update_document(
        "nb-1",
        name="Demo v2",
        kernel="python3",
        runtime="cpu",
    )

    assert document.name == "Demo v2"
    mock_client.put.assert_called_once_with(
        "/v1/notebooks/nb-1",
        json={
            "name": "Demo v2",
            "metadata": {"kernel": "python3", "runtime": "cpu"},
        },
    )


def test_update_document_sends_auto_save_in_metadata(notebook_api, mock_client):
    """Document update should keep auto-save inside the metadata payload."""
    mock_client.put.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo",
        "filePath": "/mnt/notebook.ipynb",
        "metadata": {"autoSaveEnabled": False},
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    notebook_api.update_document("nb-1", auto_save_enabled=False)

    mock_client.put.assert_called_once_with(
        "/v1/notebooks/nb-1",
        json={"metadata": {"autoSaveEnabled": False}},
    )


def test_list_sessions_can_filter_by_workspace(notebook_api, mock_client):
    """Session list should forward an optional workspace filter."""
    mock_client.get.return_value.json.return_value = []

    notebook_api.list_all("wk-1")

    mock_client.get.assert_called_once_with(
        "/v1/notebooks/sessions",
        params={"workspaceId": "wk-1"},
    )


def test_delete_document(notebook_api, mock_client):
    """Test deleting notebook document."""
    notebook_api.delete_document("nb-1")

    mock_client.delete.assert_called_once_with("/v1/notebooks/nb-1")


def test_duplicate_document(notebook_api, mock_client):
    """Test duplicating notebook document."""
    mock_client.post.return_value.json.return_value = {
        "id": "nb-copy",
        "workspaceId": "wk-1",
        "name": "Demo (copy)",
        "filePath": "/mnt/notebook.ipynb",
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.duplicate_document("nb-1")

    assert document.id == "nb-copy"
    mock_client.post.assert_called_once_with("/v1/notebooks/nb-1/duplicate")


def test_import_document_from_url(notebook_api, mock_client):
    """Test importing notebook document from URL."""
    mock_client.post.return_value.json.return_value = {
        "id": "nb-2",
        "workspaceId": "wk-1",
        "name": "Imported",
        "filePath": "/mnt/notebook.ipynb",
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.import_document(
        workspace_id="wk-1",
        name="Imported",
        url="https://github.com/test/demo.ipynb",
        image="docker://registry.example/custom:latest",
    )

    assert document.id == "nb-2"
    mock_client.post.assert_called_once_with(
        "/v1/notebooks/import",
        json={
            "workspaceId": "wk-1",
            "name": "Imported",
            "url": "https://github.com/test/demo.ipynb",
            "image": "docker://registry.example/custom:latest",
        },
    )


def test_import_document_from_file(notebook_api, mock_client, tmp_path):
    """Test importing notebook document from local file."""
    file_path = tmp_path / "demo.ipynb"
    file_path.write_text("{}", encoding="utf-8")
    mock_client.post.return_value.json.return_value = {
        "id": "nb-3",
        "workspaceId": "wk-1",
        "name": "Imported from file",
        "filePath": "/mnt/notebook.ipynb",
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.import_document(
        workspace_id="wk-1",
        file_path=str(file_path),
        image="docker://registry.example/custom:latest",
    )

    assert document.id == "nb-3"
    args, kwargs = mock_client.post.call_args
    assert args[0] == "/v1/notebooks/import"
    assert kwargs["data"] == {
        "workspaceId": "wk-1",
        "image": "docker://registry.example/custom:latest",
    }
    assert kwargs["files"]["file"][0] == "demo.ipynb"


def test_upload_file_supports_explicit_remote_filename(notebook_api, mock_client, tmp_path):
    """Upload should send both directory path and explicit filename when provided."""
    local_file = tmp_path / "demo.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_client.post.return_value.json.return_value = {
        "name": "renamed.csv",
        "path": "/data/renamed.csv",
        "sizeBytes": 18,
        "mimeType": "text/csv",
        "createdAt": "2024-01-01T00:00:00Z",
        "modifiedAt": "2024-01-01T00:00:00Z",
        "isDirectory": False,
    }

    notebook_api.upload_file(
        "nb-123",
        str(local_file),
        "data",
        "renamed.csv",
    )

    args, kwargs = mock_client.post.call_args
    assert args[0] == "/v1/notebooks/nb-123/files/upload"
    assert kwargs["data"] == {"path": "data", "filename": "renamed.csv"}
    assert kwargs["files"]["file"][0] == "demo.csv"


def test_import_document_requires_single_source(notebook_api):
    """Import requires exactly one source (url or file)."""
    with pytest.raises(ValueError):
        notebook_api.import_document(workspace_id="wk-1")
    with pytest.raises(ValueError):
        notebook_api.import_document(
            workspace_id="wk-1",
            url="https://example.com/a.ipynb",
            file_path="/tmp/a.ipynb",
        )


def test_export_document_json(notebook_api, mock_client):
    """Test exporting notebook document in JSON mode."""
    mock_client.get.return_value.json.return_value = {"cells": []}

    exported = notebook_api.export_document("nb-1")

    assert exported == {"cells": []}
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-1/export",
        params={},
    )


def test_export_document_download(notebook_api, mock_client):
    """Test exporting notebook document in download mode."""
    mock_client.get.return_value.text = '{"cells":[]}'

    exported = notebook_api.export_document("nb-1", download=True)

    assert exported == '{"cells":[]}'
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-1/export",
        params={"download": "1"},
    )


def test_save_document(notebook_api, mock_client):
    """Test saving notebook document."""
    mock_client.post.return_value.json.return_value = {
        "id": "nb-1",
        "workspaceId": "wk-1",
        "name": "Demo",
        "filePath": "/mnt/notebook.ipynb",
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    document = notebook_api.save_document("nb-1")

    assert document.id == "nb-1"
    mock_client.post.assert_called_once_with("/v1/notebooks/nb-1/save")


def test_list_cells(notebook_api, mock_client):
    """Test listing cells."""
    mock_client.get.return_value.json.return_value = [
        {
            "id": "cell-1",
            "notebookId": "nb-123",
            "cellIndex": 0,
            "cellType": "code",
            "source": "x = 1",
            "sourceOtVersion": 1,
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-01T00:00:00Z",
        }
    ]

    cells = notebook_api.list_cells("nb-123")

    assert len(cells) == 1
    assert cells[0].id == "cell-1"
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-123/cells", params={})


def test_list_cells_with_outputs(notebook_api, mock_client):
    """Test listing cells with outputs included."""
    mock_client.get.return_value.json.return_value = [
        {
            "id": "cell-1",
            "notebookId": "nb-123",
            "cellIndex": 0,
            "cellType": "code",
            "source": "print('hello')",
            "sourceOtVersion": 1,
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-01T00:00:00Z",
            "outputs": [
                {"outputType": "stream", "name": "stdout", "text": "hello\n"}
            ],
            "executionCount": 5,
            "status": "ok",
            "lastRunDuration": 1.23,
        }
    ]

    cells = notebook_api.list_cells("nb-123", include_outputs=True)

    assert len(cells) == 1
    assert cells[0].id == "cell-1"
    assert cells[0].execution_count == 5
    assert cells[0].status == "ok"
    assert len(cells[0].outputs) == 1
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-123/cells",
        params={"include": "outputs"},
    )


def test_get_cell(notebook_api, mock_client):
    """Test getting a cell with outputs."""
    mock_client.get.return_value.json.return_value = {
        "id": "cell-1",
        "notebookId": "nb-123",
        "cellIndex": 0,
        "cellType": "code",
        "source": "print('hi')",
        "sourceOtVersion": 1,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
        "outputs": [{"outputType": "stream", "name": "stdout", "text": "hi\n"}],
        "executionCount": 5,
        "status": "ok",
        "lastRunDuration": 1.5,
    }

    cell = notebook_api.get_cell("nb-123", "cell-1")

    assert cell.id == "cell-1"
    assert cell.execution_count == 5
    assert len(cell.outputs) == 1
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-123/cells/cell-1")


def test_get_cell_by_index(notebook_api, mock_client):
    """Test getting a cell by index."""
    mock_client.get.return_value.json.return_value = {
        "id": "cell-1",
        "notebookId": "nb-123",
        "cellIndex": 0,
        "cellType": "code",
        "source": "print('hi')",
        "sourceOtVersion": 1,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
        "outputs": [],
        "executionCount": 5,
        "status": "ok",
        "lastRunDuration": 1.5,
    }

    cell = notebook_api.get_cell_by_index("nb-123", 0)

    assert cell.id == "cell-1"
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-123/cells/by-index/0"
    )


def test_add_cell(notebook_api, mock_client):
    """Test adding a cell."""
    mock_client.post.return_value.json.return_value = {
        "id": "cell-new",
        "notebookId": "nb-123",
        "cellIndex": 0,
        "cellType": "code",
        "source": "x = 1",
        "sourceOtVersion": 0,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    cell = notebook_api.add_cell("nb-123", "x = 1", cell_type="code", index=0)

    assert cell.id == "cell-new"
    mock_client.post.assert_called_once()


def test_update_cell_source(notebook_api, mock_client):
    """Test updating a cell source with expectedVersion."""
    mock_client.put.return_value.json.return_value = {
        "id": "cell-1",
        "notebookId": "nb-123",
        "cellIndex": 0,
        "cellType": "code",
        "source": "x = 3",
        "sourceOtVersion": 3,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    }

    cell = notebook_api.update_cell_source(
        "nb-123",
        "cell-1",
        "x = 3",
        expected_version=2,
    )

    assert cell.source == "x = 3"
    assert cell.source_ot_version == 3
    mock_client.put.assert_called_once_with(
        "/v1/notebooks/nb-123/cells/cell-1/source",
        json={
            "source": "x = 3",
            "expectedVersion": 2,
        },
    )


def test_delete_cell(notebook_api, mock_client):
    """Test deleting a cell."""
    notebook_api.delete_cell("nb-123", "cell-1")

    mock_client.delete.assert_called_once_with("/v1/notebooks/nb-123/cells/cell-1")


def test_execute_cell(notebook_api, mock_client):
    """Test executing a cell."""
    mock_client.post.return_value.json.return_value = {
        "success": True,
        "executionId": "exec-123",
        "status": "started",
        "message": "Execution started",
    }

    result = notebook_api.execute_cell("nb-123", cell_id="cell-1")

    assert result.execution_id == "exec-123"
    assert result.status == "started"
    mock_client.post.assert_called_once_with(
        "/v1/notebooks/nb-123/kernel/execute",
        json={"cellId": "cell-1"},
    )


def test_execute_cell_by_index(notebook_api, mock_client):
    """Test executing a cell by index."""
    mock_client.post.return_value.json.return_value = {
        "success": True,
        "executionId": "exec-123",
        "status": "started",
    }

    notebook_api.execute_cell("nb-123", cell_index=2)

    mock_client.post.assert_called_once_with(
        "/v1/notebooks/nb-123/kernel/execute",
        json={"cellIndex": 2},
    )


def test_execute_cell_requires_single_selector(notebook_api):
    """Test execute selector validation."""
    with pytest.raises(ValueError):
        notebook_api.execute_cell("nb-123")
    with pytest.raises(ValueError):
        notebook_api.execute_cell("nb-123", cell_id="c1", cell_index=0)


def test_get_cell_outputs(notebook_api, mock_client):
    """Test getting cell outputs."""
    mock_client.get.return_value.json.return_value = [
        {"outputType": "stream", "name": "stdout", "text": "hello\n"},
        {"outputType": "execute_result", "data": {"text/plain": "42"}, "executionCount": 5},
    ]

    outputs = notebook_api.get_cell_outputs("nb-123", "cell-1")

    assert len(outputs) == 2
    assert outputs[0].output_type == "stream"
    assert outputs[1].output_type == "execute_result"
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-123/outputs/cell-1")


def test_clear_notebook_outputs(notebook_api, mock_client):
    """Test clearing outputs for a whole notebook."""
    mock_client.delete.return_value.json.return_value = {"clearedCellCount": 2}

    result = notebook_api.clear_notebook_outputs("nb-123")

    assert result == {"clearedCellCount": 2}
    mock_client.delete.assert_called_once_with("/v1/notebooks/nb-123/outputs")


def test_ensure_kernel(notebook_api, mock_client):
    """Test ensuring kernel session."""
    mock_client.post.return_value.json.return_value = {"status": "starting"}

    result = notebook_api.ensure_kernel("nb-123")

    assert result == {"status": "starting"}
    mock_client.post.assert_called_once_with("/v1/notebooks/nb-123/kernel/ensure")


def test_get_kernel_status(notebook_api, mock_client):
    """Test getting kernel status."""
    mock_client.get.return_value.json.return_value = {"status": "idle"}

    result = notebook_api.get_kernel_status("nb-123")

    assert result == {"status": "idle"}
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-123/kernel")


def test_interrupt_kernel(notebook_api, mock_client):
    """Test interrupting a notebook kernel."""
    mock_client.post.return_value.json.return_value = {"ok": True}

    result = notebook_api.interrupt_kernel("nb-123")

    assert result == {"ok": True}
    mock_client.post.assert_called_once_with("/v1/notebooks/nb-123/kernel/interrupt")


def test_restart_kernel(notebook_api, mock_client):
    """Test restarting a notebook kernel."""
    mock_client.post.return_value.json.return_value = {"ok": True}

    result = notebook_api.restart_kernel("nb-123")

    assert result == {"ok": True}
    mock_client.post.assert_called_once_with("/v1/notebooks/nb-123/kernel/restart")


def test_update_kernel_ttl_policy(notebook_api, mock_client):
    """Test updating notebook kernel TTL policy."""
    mock_client.put.return_value.json.return_value = {
        "success": True,
        "ttlPolicy": {
            "persistent": False,
            "idleTtlSeconds": 60,
            "snapshotFavor": "disk",
        },
    }

    result = notebook_api.update_kernel_ttl_policy(
        "nb-123",
        persistent=False,
        idle_ttl_seconds=60,
        snapshot_favor="disk",
    )

    assert result["success"] is True
    mock_client.put.assert_called_once_with(
        "/v1/notebooks/nb-123/kernel/ttl-policy",
        json={
            "persistent": False,
            "idleTtlSeconds": 60,
            "snapshotFavor": "disk",
        },
    )


def test_list_notebook_files(notebook_api, mock_client):
    """Test listing notebook-scoped files."""
    mock_client.get.return_value.json.return_value = [
        {
            "name": "acceptance-data.csv",
            "path": "/acceptance-data.csv",
            "sizeBytes": 26,
            "mimeType": "text/csv",
            "createdAt": "2024-01-01T00:00:00Z",
            "modifiedAt": "2024-01-01T00:00:00Z",
            "isDirectory": False,
        }
    ]

    files = notebook_api.list_files("nb-123", "data")

    assert len(files) == 1
    assert files[0].name == "acceptance-data.csv"
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-123/files",
        params={"path": "data"},
    )


def test_create_notebook_directory(notebook_api, mock_client):
    """Test creating a notebook-scoped directory."""
    mock_client.post.return_value.json.return_value = {
        "name": "data",
        "path": "/data",
        "sizeBytes": 0,
        "mimeType": "directory",
        "createdAt": "2024-01-01T00:00:00Z",
        "modifiedAt": "2024-01-01T00:00:00Z",
        "isDirectory": True,
    }

    created = notebook_api.create_directory("nb-123", "data")

    assert created.is_directory is True
    mock_client.post.assert_called_once_with(
        "/v1/notebooks/nb-123/files/directory",
        json={"path": "data"},
    )


def test_upload_notebook_file(notebook_api, mock_client, tmp_path):
    """Test uploading a notebook-scoped file."""
    local_file = tmp_path / "acceptance-data.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_client.post.return_value.json.return_value = {
        "name": "acceptance-data.csv",
        "path": "/data/acceptance-data.csv",
        "sizeBytes": 19,
        "mimeType": "text/csv",
        "createdAt": "2024-01-01T00:00:00Z",
        "modifiedAt": "2024-01-01T00:00:00Z",
        "isDirectory": False,
    }

    uploaded = notebook_api.upload_file("nb-123", str(local_file), "data")

    assert uploaded.path == "/data/acceptance-data.csv"
    args, kwargs = mock_client.post.call_args
    assert args[0] == "/v1/notebooks/nb-123/files/upload"
    assert kwargs["data"] == {"path": "data"}
    assert kwargs["files"]["file"][0] == "acceptance-data.csv"


def test_download_notebook_file(notebook_api, mock_client, tmp_path):
    """Test downloading a notebook-scoped file."""
    mock_client.get.return_value.content = b"name,value\nalpha,1\n"
    output_path = tmp_path / "downloaded.csv"

    notebook_api.download_file("nb-123", "data/acceptance-data.csv", str(output_path))

    assert output_path.read_bytes() == b"name,value\nalpha,1\n"
    mock_client.get.assert_called_once_with(
        "/v1/notebooks/nb-123/files/content",
        params={"path": "data/acceptance-data.csv", "download": "1"},
    )


def test_delete_notebook_file(notebook_api, mock_client):
    """Test deleting a notebook-scoped file."""
    notebook_api.delete_file("nb-123", "data/acceptance-data.csv")

    mock_client.post.assert_called_once_with(
        "/v1/notebooks/nb-123/files/delete",
        json={"path": "data/acceptance-data.csv"},
    )


def test_list_notebook_collaborators(notebook_api, mock_client):
    """Test listing notebook collaborators."""
    mock_client.get.return_value.json.return_value = [
        {
            "notebookId": "nb-123",
            "sessionId": "collab-1",
            "userId": "user-1",
            "userData": {"name": "jacob", "color": "#ef4444"},
            "lastHeartbeat": "2024-01-01T00:00:00Z",
        }
    ]

    collaborators = notebook_api.list_collaborators("nb-123")

    assert len(collaborators) == 1
    assert collaborators[0].user_id == "user-1"
    mock_client.get.assert_called_once_with("/v1/notebooks/nb-123/collaborators")
