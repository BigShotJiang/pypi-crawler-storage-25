"""Tests for the shared API client."""

from unittest.mock import Mock

import httpx

from agentenv.api.client import Client


def _make_response(method: str, url: str) -> httpx.Response:
    request = httpx.Request(method, url)
    return httpx.Response(200, request=request, json={"ok": True})


def test_request_prefixes_v1_for_unversioned_paths() -> None:
    client = Client(base_url="https://api.example.com")
    client._client = Mock()
    client._client.request.return_value = _make_response(
        "GET",
        "https://api.example.com/v1/workflows/workflow-123",
    )

    client.get("/workflows/workflow-123")

    client._client.request.assert_called_once_with(
        "GET",
        "https://api.example.com/v1/workflows/workflow-123",
        headers={},
    )


def test_request_preserves_existing_v1_paths() -> None:
    client = Client(base_url="https://api.example.com")
    client._client = Mock()
    client._client.request.return_value = _make_response(
        "GET",
        "https://api.example.com/v1/auth/profile",
    )

    client.get("/v1/auth/profile")

    client._client.request.assert_called_once_with(
        "GET",
        "https://api.example.com/v1/auth/profile",
        headers={},
    )


def test_request_normalizes_versioned_base_urls_without_double_prefixing() -> None:
    client = Client(base_url="https://api.example.com/v1")
    client._client = Mock()
    client._client.request.return_value = _make_response(
        "GET",
        "https://api.example.com/v1/workflows",
    )

    client.get("/workflows")

    client._client.request.assert_called_once_with(
        "GET",
        "https://api.example.com/v1/workflows",
        headers={},
    )
