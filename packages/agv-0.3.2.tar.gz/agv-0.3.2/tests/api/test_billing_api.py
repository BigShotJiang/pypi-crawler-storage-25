"""Tests for billing API wrappers."""

from types import SimpleNamespace
from unittest.mock import Mock, patch

import agentenv.sdk as sdk_module
from agentenv.api.billing import BillingAPI


def test_get_balance_uses_account_first_balance_dto() -> None:
    """Billing API should parse the current account-first balance response."""
    mock_client = Mock()
    mock_client.get.return_value.json.return_value = {
        "billingAccountId": "ba_123",
        "balanceCents": 5000,
        "totalChargedCents": 2000,
        "billingEnabled": True,
    }

    balance = BillingAPI(mock_client).get_balance("wk_123")

    mock_client.get.assert_called_once_with("/v1/workspaces/wk_123/billing/balance")
    assert balance.billing_account_id == "ba_123"
    assert balance.balance_cents == 5000
    assert balance.total_charged_cents == 2000
    assert balance.billing_enabled is True


def test_get_transactions_uses_account_first_transaction_dto() -> None:
    """Billing API should parse paginated account-first transaction payloads."""
    mock_client = Mock()
    mock_client.get.return_value.json.return_value = {
        "transactions": [
            {
                "id": "txn_123",
                "workspaceId": "wk_123",
                "billingAccountId": "ba_123",
                "type": "credit",
                "status": "completed",
                "amountCents": 1000,
                "balanceAfterCents": 5000,
                "description": "mpp top-up",
                "metadata": {"provider": "stripe_mpp"},
                "createdAt": "2026-03-30T12:00:00Z",
            }
        ],
        "total": 1,
        "page": 1,
        "limit": 50,
    }

    result = BillingAPI(mock_client).get_transactions(
        "wk_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )

    mock_client.get.assert_called_once_with(
        "/v1/workspaces/wk_123/billing/transactions",
        params={
            "page": 2,
            "limit": 10,
            "startDate": "2026-03-01",
            "endDate": "2026-03-31",
            "includeTypes": ["credit"],
            "excludeTypes": ["usage"],
        },
    )
    assert result["total"] == 1
    assert result["page"] == 1
    assert result["limit"] == 50
    assert len(result["transactions"]) == 1
    assert result["transactions"][0].billing_account_id == "ba_123"
    assert result["transactions"][0].workspace_id == "wk_123"
    assert result["transactions"][0].amount_cents == 1000
    assert result["transactions"][0].balance_after_cents == 5000


def test_get_billing_account_balance_uses_account_balance_endpoint() -> None:
    """Billing API should parse owned billing-account balance payloads."""
    mock_client = Mock()
    mock_client.get.return_value.json.return_value = {
        "billingAccountId": "ba_123",
        "balanceCents": 5000,
        "totalChargedCents": 2000,
        "billingEnabled": True,
    }

    balance = BillingAPI(mock_client).get_billing_account_balance("ba_123")

    mock_client.get.assert_called_once_with("/v1/billing-accounts/ba_123/balance")
    assert balance.billing_account_id == "ba_123"
    assert balance.balance_cents == 5000
    assert balance.total_charged_cents == 2000
    assert balance.billing_enabled is True


def test_get_billing_account_transactions_preserves_filters_and_metadata() -> None:
    """Billing API should pass account-history filters through and preserve pagination."""
    mock_client = Mock()
    mock_client.get.return_value.json.return_value = {
        "transactions": [
            {
                "id": "txn_123",
                "workspaceId": "wk_123",
                "billingAccountId": "ba_123",
                "type": "credit",
                "status": "completed",
                "amountCents": 1000,
                "balanceAfterCents": 5000,
                "description": "mpp top-up",
                "metadata": {"provider": "stripe_mpp"},
                "createdAt": "2026-03-30T12:00:00Z",
            }
        ],
        "total": 12,
        "page": 2,
        "limit": 10,
    }

    result = BillingAPI(mock_client).get_billing_account_transactions(
        "ba_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )

    mock_client.get.assert_called_once_with(
        "/v1/billing-accounts/ba_123/transactions",
        params={
            "page": 2,
            "limit": 10,
            "startDate": "2026-03-01",
            "endDate": "2026-03-31",
            "includeTypes": ["credit"],
            "excludeTypes": ["usage"],
        },
    )
    assert result["total"] == 12
    assert result["page"] == 2
    assert result["limit"] == 10
    assert len(result["transactions"]) == 1
    assert result["transactions"][0].billing_account_id == "ba_123"


def test_sdk_get_balance_returns_account_first_fields() -> None:
    """SDK wrapper should expose the repaired balance contract."""
    mock_client = Mock()
    wrapper = sdk_module.BillingAPI(mock_client)

    balance = SimpleNamespace(
        billing_account_id="ba_123",
        balance_cents=5000,
        total_charged_cents=2000,
        billing_enabled=True,
    )

    with patch("agentenv.api.billing.BillingAPI") as mock_api_cls:
        mock_api_cls.return_value.get_balance.return_value = balance

        result = wrapper.get_balance("wk_123")

    mock_api_cls.return_value.get_balance.assert_called_once_with("wk_123")
    assert result == {
        "billing_account_id": "ba_123",
        "balance_cents": 5000,
        "total_charged_cents": 2000,
        "billing_enabled": True,
    }


def test_sdk_get_transactions_returns_transaction_payload_with_metadata() -> None:
    """SDK wrapper should expose workspace history plus pagination metadata."""
    mock_client = Mock()
    wrapper = sdk_module.BillingAPI(mock_client)

    transaction = Mock()
    transaction.model_dump.return_value = {
        "id": "txn_123",
        "workspaceId": "wk_123",
        "billingAccountId": "ba_123",
        "type": "credit",
    }

    with patch("agentenv.api.billing.BillingAPI") as mock_api_cls:
        mock_api_cls.return_value.get_transactions.return_value = {
            "transactions": [transaction],
            "total": 12,
            "page": 2,
            "limit": 10,
        }

        result = wrapper.get_transactions(
            "wk_123",
            page=2,
            limit=10,
            start_date="2026-03-01",
            end_date="2026-03-31",
            include_types=["credit"],
            exclude_types=["usage"],
        )

    mock_api_cls.return_value.get_transactions.assert_called_once_with(
        "wk_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )
    assert result == {
        "transactions": [
            {
                "id": "txn_123",
                "workspaceId": "wk_123",
                "billingAccountId": "ba_123",
                "type": "credit",
            }
        ],
        "total": 12,
        "page": 2,
        "limit": 10,
    }


def test_sdk_get_billing_account_balance_returns_account_fields() -> None:
    """SDK wrapper should expose owned billing-account balances."""
    mock_client = Mock()
    wrapper = sdk_module.BillingAPI(mock_client)

    balance = SimpleNamespace(
        billing_account_id="ba_123",
        balance_cents=5000,
        total_charged_cents=2000,
        billing_enabled=True,
    )

    with patch("agentenv.api.billing.BillingAPI") as mock_api_cls:
        mock_api_cls.return_value.get_billing_account_balance.return_value = balance

        result = wrapper.get_billing_account_balance("ba_123")

    mock_api_cls.return_value.get_billing_account_balance.assert_called_once_with("ba_123")
    assert result == {
        "billing_account_id": "ba_123",
        "balance_cents": 5000,
        "total_charged_cents": 2000,
        "billing_enabled": True,
    }


def test_sdk_get_billing_account_transactions_returns_transaction_payload_with_metadata() -> None:
    """SDK wrapper should expose owned account history plus pagination metadata."""
    mock_client = Mock()
    wrapper = sdk_module.BillingAPI(mock_client)

    transaction = Mock()
    transaction.model_dump.return_value = {
        "id": "txn_123",
        "workspaceId": "wk_123",
        "billingAccountId": "ba_123",
        "type": "credit",
    }

    with patch("agentenv.api.billing.BillingAPI") as mock_api_cls:
        mock_api_cls.return_value.get_billing_account_transactions.return_value = {
            "transactions": [transaction],
            "total": 12,
            "page": 2,
            "limit": 10,
        }

        result = wrapper.get_billing_account_transactions(
            "ba_123",
            page=2,
            limit=10,
            start_date="2026-03-01",
            end_date="2026-03-31",
            include_types=["credit"],
            exclude_types=["usage"],
        )

    mock_api_cls.return_value.get_billing_account_transactions.assert_called_once_with(
        "ba_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )
    assert result == {
        "transactions": [
            {
                "id": "txn_123",
                "workspaceId": "wk_123",
                "billingAccountId": "ba_123",
                "type": "credit",
            }
        ],
        "total": 12,
        "page": 2,
        "limit": 10,
    }


def test_sdk_does_not_expose_unimplemented_topup_helpers() -> None:
    """SDK billing wrapper should not advertise unsupported top-up methods."""
    wrapper = sdk_module.BillingAPI(Mock())

    assert not hasattr(wrapper, "preflight_mpp_topup")
    assert not hasattr(wrapper, "topup_mpp")
