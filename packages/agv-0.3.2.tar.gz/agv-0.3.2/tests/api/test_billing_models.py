"""Tests for billing API models."""

from agentenv.api.models import BalanceInfo, Transaction, Workspace, WorkspaceDetail


def test_balance_info_accepts_account_first_server_fields() -> None:
    """BalanceInfo should parse the current account-first balance DTO."""
    balance = BalanceInfo(
        billingAccountId="ba_123",
        balanceCents=5000,
        totalChargedCents=2000,
        billingEnabled=True,
    )

    assert balance.billing_account_id == "ba_123"
    assert balance.balance_cents == 5000
    assert balance.total_charged_cents == 2000
    assert balance.billing_enabled is True


def test_transaction_accepts_account_first_server_fields() -> None:
    """Transaction should parse the current account-first transaction DTO."""
    transaction = Transaction(
        id="txn_123",
        workspaceId="wk_123",
        billingAccountId="ba_123",
        type="credit",
        status="completed",
        amountCents=1000,
        balanceAfterCents=5000,
        description="mpp top-up",
        metadata={"provider": "stripe_mpp"},
        createdAt="2026-03-30T12:00:00Z",
    )

    assert transaction.id == "txn_123"
    assert transaction.workspace_id == "wk_123"
    assert transaction.billing_account_id == "ba_123"
    assert transaction.type == "credit"
    assert transaction.status == "completed"
    assert transaction.amount_cents == 1000
    assert transaction.balance_after_cents == 5000
    assert transaction.description == "mpp top-up"
    assert transaction.metadata == {"provider": "stripe_mpp"}


def test_workspace_exposes_default_billing_account_id() -> None:
    """Workspace should retain the server default billing account mapping."""
    workspace = Workspace(
        id="wk_123",
        name="Billing Workspace",
        ownerId="user_123",
        defaultBillingAccountId="ba_123",
        createdAt="2026-03-30T12:00:00Z",
    )

    assert workspace.default_billing_account_id == "ba_123"


def test_workspace_detail_exposes_default_billing_account_id() -> None:
    """WorkspaceDetail should retain the default billing account mapping."""
    workspace = WorkspaceDetail(
        id="wk_123",
        name="Billing Workspace",
        ownerId="user_123",
        defaultBillingAccountId="ba_123",
        createdAt="2026-03-30T12:00:00Z",
        members=[],
    )

    assert workspace.default_billing_account_id == "ba_123"
