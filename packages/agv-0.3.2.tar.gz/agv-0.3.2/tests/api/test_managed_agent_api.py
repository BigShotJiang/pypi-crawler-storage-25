"""Tests for managed-agent API wrappers."""

from unittest.mock import MagicMock, Mock, patch

from agentenv.api.managed_agent import ManagedAgentAPI


def _mock_response(payload, *, status_code: int = 200):
    response = Mock()
    response.status_code = status_code
    response.json.return_value = payload
    response.content = b"body"
    return response


def test_list_all_uses_paginated_managed_agent_endpoint() -> None:
    """ManagedAgentAPI.list_all should preserve pagination and filters."""
    mock_client = Mock()
    mock_client.get.return_value = _mock_response({
        "agents": [
            {
                "id": "ma_123",
                "workspaceId": "wk_123",
                "sandboxId": "sb_123",
                "name": "Research Agent",
                "status": "running",
                "config": {
                    "upstreamId": "up_123",
                    "model": "gpt-5-codex",
                },
                "metadata": None,
                "createdAt": "2026-04-12T00:00:00Z",
                "updatedAt": "2026-04-12T00:00:00Z",
            }
        ],
        "total": 1,
        "page": 2,
        "limit": 10,
    })

    result = ManagedAgentAPI(mock_client).list_all(
        workspace_id="wk_123",
        agent_workspace_group_id="awg_123",
        search="Research",
        page=2,
        limit=10,
    )

    mock_client.get.assert_called_once_with(
        "/v1/managed-agents",
        params={
            "workspaceId": "wk_123",
            "agentWorkspaceGroupId": "awg_123",
            "search": "Research",
            "page": 2,
            "limit": 10,
        },
    )
    assert result.total == 1
    assert result.page == 2
    assert result.agents[0].config.model == "gpt-5-codex"


def test_create_posts_expected_payload() -> None:
    """ManagedAgentAPI.create should match the backend DTO."""
    mock_client = Mock()
    mock_client.post.return_value = _mock_response({
        "id": "ma_123",
        "workspaceId": "wk_123",
        "sandboxId": None,
        "name": "Builder",
        "status": "starting",
        "config": {
            "upstreamId": "up_123",
            "model": "gpt-5-codex",
            "instructions": "be careful",
            "cpuMillis": 4000,
            "memoryMb": 8192,
        },
        "metadata": None,
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    })

    agent = ManagedAgentAPI(mock_client).create(
        name="Builder",
        workspace_id="wk_123",
        upstream_id="up_123",
        model="gpt-5-codex",
        instructions="be careful",
        image="docker://registry.example/agent:latest",
        workspace_template="solayer-order-agent",
        cpu_millis=4000,
        memory_mb=8192,
    )

    mock_client.post.assert_called_once_with(
        "/v1/managed-agents",
        json={
            "name": "Builder",
            "workspaceId": "wk_123",
            "upstreamId": "up_123",
            "model": "gpt-5-codex",
            "instructions": "be careful",
            "image": "docker://registry.example/agent:latest",
            "workspaceTemplate": "solayer-order-agent",
            "cpuMillis": 4000,
            "memoryMb": 8192,
        },
    )
    assert agent.name == "Builder"
    assert agent.status == "starting"


def test_stream_message_parses_sse_events() -> None:
    """ManagedAgentAPI.stream_message should yield parsed SSE data events."""
    mock_client = Mock()
    response = MagicMock()
    response.status_code = 200
    response.iter_lines.return_value = [
        'data: {"type":"run.started","runId":"run_123","agentId":"ma_123"}',
        "",
        'data: {"type":"message.completed","messageId":"msg_123","content":"Hello"}',
    ]
    stream_context = MagicMock()
    stream_context.__enter__.return_value = response
    stream_context.__exit__.return_value = None
    mock_client.stream.return_value = stream_context

    events = list(ManagedAgentAPI(mock_client).stream_message("ma_123", "hello"))

    mock_client.stream.assert_called_once_with(
        "POST",
        "/v1/managed-agents/ma_123/messages",
        json={"content": "hello"},
        headers={
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
        },
    )
    assert [event.type for event in events] == ["run.started", "message.completed"]
    assert events[1].model_dump()["content"] == "Hello"


def test_stream_message_skips_malformed_sse_chunks() -> None:
    """ManagedAgentAPI.stream_message should ignore malformed SSE payloads."""
    mock_client = Mock()
    response = MagicMock()
    response.status_code = 200
    response.iter_lines.return_value = [
        'data: {"type":"run.started","runId":"run_123","agentId":"ma_123"}',
        "data: not-json",
        'data: {"type":"message.completed","messageId":"msg_123","content":"Hello"}',
    ]
    stream_context = MagicMock()
    stream_context.__enter__.return_value = response
    stream_context.__exit__.return_value = None
    mock_client.stream.return_value = stream_context

    events = list(ManagedAgentAPI(mock_client).stream_message("ma_123", "hello"))

    assert [event.type for event in events] == ["run.started", "message.completed"]


def test_wait_for_status_polls_until_agent_is_running() -> None:
    """ManagedAgentAPI.wait_for_status should stop once the desired state is reached."""
    mock_client = Mock()
    mock_client.get.side_effect = [
        _mock_response({
            "id": "ma_123",
            "workspaceId": "wk_123",
            "sandboxId": None,
            "name": "Builder",
            "status": "starting",
            "config": {"upstreamId": "up_123", "model": "gpt-5-codex"},
            "metadata": None,
            "createdAt": "2026-04-12T00:00:00Z",
            "updatedAt": "2026-04-12T00:00:00Z",
        }),
        _mock_response({
            "id": "ma_123",
            "workspaceId": "wk_123",
            "sandboxId": None,
            "name": "Builder",
            "status": "running",
            "config": {"upstreamId": "up_123", "model": "gpt-5-codex"},
            "metadata": None,
            "createdAt": "2026-04-12T00:00:00Z",
            "updatedAt": "2026-04-12T00:00:00Z",
        }),
    ]

    api = ManagedAgentAPI(mock_client)
    with patch("agentenv.api.managed_agent.time.sleep", return_value=None):
        agent = api.wait_for_status("ma_123", timeout=1, interval=0)

    assert agent.status == "running"
    assert mock_client.get.call_count == 2


def test_wait_for_status_raises_when_agent_fails() -> None:
    """ManagedAgentAPI.wait_for_status should fail fast on terminal error states."""
    mock_client = Mock()
    mock_client.get.return_value = _mock_response({
        "id": "ma_123",
        "workspaceId": "wk_123",
        "sandboxId": None,
        "name": "Builder",
        "status": "failed",
        "config": {"upstreamId": "up_123", "model": "gpt-5-codex"},
        "metadata": None,
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    })

    api = ManagedAgentAPI(mock_client)
    with patch("agentenv.api.managed_agent.time.sleep", return_value=None):
        try:
            api.wait_for_status("ma_123", timeout=1, interval=0)
        except RuntimeError as exc:
            assert "failed with status: failed" in str(exc)
        else:
            raise AssertionError("Expected RuntimeError")


def test_delete_returns_success_payload() -> None:
    """ManagedAgentAPI.delete should preserve the backend success envelope."""
    mock_client = Mock()
    mock_client.delete.return_value = _mock_response({"success": True})

    result = ManagedAgentAPI(mock_client).delete("ma_123")

    mock_client.delete.assert_called_once_with("/v1/managed-agents/ma_123")
    assert result.success is True
