"""Tests for AI Gateway API client."""

import pytest
from datetime import datetime
from unittest.mock import Mock

from agentenv.api.client import Client
from agentenv.api.ai_gateway import AIGatewayAPI
from agentenv.api.models import ChatCompletionRequest


@pytest.fixture
def mock_client():
    """Create mock HTTP client."""
    return Mock(spec=Client)


def test_list_upstreams(mock_client):
    """Test listing upstreams."""
    mock_response = Mock()
    mock_response.json.return_value = [
        {
            "id": "up_123",
            "name": "OpenAI Prod",
            "userId": "user_123",
            "providerType": "openai-api",
            "credentials": {
                "baseUrl": "https://proxy.example/v1",
                "defaultModel": "gpt-5.4",
            },
            "rateLimitStatus": {},
            "isActive": True,
            "createdAt": datetime.now().isoformat(),
            "updatedAt": datetime.now().isoformat(),
        }
    ]
    mock_client.get.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    upstreams = api.list_upstreams()

    assert len(upstreams) == 1
    assert upstreams[0].id == "up_123"
    assert upstreams[0].provider_type == "openai-api"
    assert upstreams[0].base_url == "https://proxy.example/v1"
    mock_client.get.assert_called_once_with("/ai-gateway/upstreams")


def test_create_upstream_posts_current_backend_contract(mock_client):
    """Test creating upstreams against the current nested request contract."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "id": "up_123",
        "name": "OpenAI Prod",
        "userId": "user_123",
        "providerType": "openai-api",
        "credentials": {
            "baseUrl": "https://proxy.example/v1",
            "defaultModel": "gpt-5.4",
        },
        "rateLimitStatus": {},
        "isActive": True,
        "createdAt": datetime.now().isoformat(),
        "updatedAt": datetime.now().isoformat(),
    }
    mock_client.post.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    upstream = api.create_upstream(
        name="OpenAI Prod",
        provider="openai-api",
        api_key="sk_test",
        base_url="https://proxy.example/v1",
        rate_limit_rpm=1000,
        rate_limit_tpm=2000,
        priority=1,
        weight=2,
    )

    assert upstream.provider_type == "openai-api"
    mock_client.post.assert_called_once_with(
        "/ai-gateway/upstreams",
        json={
            "name": "OpenAI Prod",
            "providerType": "openai-api",
            "credentials": {
                "apiKey": "sk_test",
                "baseUrl": "https://proxy.example/v1",
            },
        },
    )


def test_create_chat_completion(mock_client):
    """Test chat completion creation."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "id": "chat_123",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finishReason": "stop",
            }
        ],
        "usage": {"promptTokens": 10, "completionTokens": 5, "totalTokens": 15},
    }
    mock_client.post.return_value = mock_response

    api = AIGatewayAPI(mock_client, gateway_key="cr_test")
    request = ChatCompletionRequest(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )
    response = api.chat.create(request)

    assert response.id == "chat_123"
    assert response.choices[0].message.content == "Hello!"


def test_list_platform_models(mock_client):
    """Test listing platform models."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "providers": [
            {
                "id": "openai",
                "displayName": "OpenAI",
                "models": [
                    {
                        "id": "gpt-4o",
                        "displayName": "GPT-4o",
                        "inputPrice": 5,
                        "outputPrice": 15,
                    }
                ],
            }
        ]
    }
    mock_client.get.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    payload = api.list_platform_models()

    assert payload["providers"][0]["id"] == "openai"
    mock_client.get.assert_called_once_with("/ai-gateway/platform-models")


def test_add_platform_pool_member(mock_client):
    """Test adding a platform model to a pool."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "id": "pool_123",
        "name": "Primary Pool",
        "members": [{"platformModelId": "openai/gpt-4o"}],
    }
    mock_client.post.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    payload = api.add_pool_member(
        "pool_123",
        source_type="platform",
        platform_model_id="openai/gpt-4o",
        priority=2,
        weight=3,
    )

    assert payload["name"] == "Primary Pool"
    mock_client.post.assert_called_once_with(
        "/ai-gateway/pools/pool_123/members",
        json={
            "sourceType": "platform",
            "platformModelId": "openai/gpt-4o",
            "priority": 2,
            "weight": 3,
        },
    )


def test_remove_platform_pool_member_encodes_model_id(mock_client):
    """Test removing a platform model from a pool."""
    mock_response = Mock()
    mock_response.json.return_value = {"success": True}
    mock_client.delete.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    payload = api.remove_platform_pool_member("pool_123", "openai/gpt-4o")

    assert payload["success"] is True
    mock_client.delete.assert_called_once_with(
        "/ai-gateway/pools/pool_123/platform-members/openai%2Fgpt-4o"
    )


def test_get_usage_includes_all_supported_filters(mock_client):
    """Test usage filters are forwarded to the API."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "totalRequests": 1,
        "totalTokens": 42,
        "totalCostUsd": 0.12,
        "records": [],
    }
    mock_client.get.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    report = api.get_usage(
        start_date="2026-04-01",
        end_date="2026-04-07",
        upstream_id="up_123",
        api_key_id="key_123",
        provider_type="openai",
        model="gpt-4o",
        limit=10,
    )

    assert report.total_requests == 1
    mock_client.get.assert_called_once_with(
        "/ai-gateway/usage",
        params={
            "startDate": "2026-04-01",
            "endDate": "2026-04-07",
            "upstreamId": "up_123",
            "apiKeyId": "key_123",
            "providerType": "openai",
            "model": "gpt-4o",
            "limit": 10,
        },
    )
