"""Integration tests for notebook session CLI commands."""

from datetime import datetime, timezone
import json
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from agentenv.cli.app import app


runner = CliRunner()


@pytest.fixture
def mock_api():
    """Mock NotebookAPI."""
    with patch("agentenv.cli.notebook.NotebookAPI") as mock:
        yield mock.return_value


@pytest.fixture
def mock_client():
    """Mock authenticated client."""
    with patch("agentenv.cli.notebook.get_client") as mock:
        mock.return_value = Mock()
        yield mock


def test_session_list(mock_client, mock_api):
    """List notebook sessions through session namespace."""
    mock_api.list_all.return_value = [
        SimpleNamespace(
            id="ns-1",
            status="running",
            notebook_url="https://example.com/lab",
            created_at=datetime.now(timezone.utc),
        )
    ]

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace=None)
        result = runner.invoke(app, ["notebook", "session", "list"])

    assert result.exit_code == 0
    assert "ns-1" in result.output
    mock_api.list_all.assert_called_once_with(None)


def test_session_list_uses_configured_workspace(mock_client, mock_api):
    """Session list should use configured workspace when present."""
    mock_api.list_all.return_value = []

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace="wk-configured")
        result = runner.invoke(app, ["notebook", "session", "list"])

    assert result.exit_code == 0
    mock_api.list_all.assert_called_once_with("wk-configured")


def test_session_list_accepts_workspace_override(mock_client, mock_api):
    """Session list should forward explicit workspace filters."""
    mock_api.list_all.return_value = []

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace="wk-configured")
        result = runner.invoke(app, ["notebook", "session", "list", "--workspace", "wk-1"])

    assert result.exit_code == 0
    mock_api.list_all.assert_called_once_with("wk-1")


def test_session_create(mock_client, mock_api):
    """Create notebook session through session namespace."""
    mock_api.create.return_value = SimpleNamespace(
        id="ns-1",
        status="starting",
        notebook_url="https://example.com/lab",
        created_at=datetime.now(timezone.utc),
    )

    result = runner.invoke(
        app,
        ["notebook", "session", "create", "--workspace", "wk-1", "--no-wait", "--no-open"],
    )

    assert result.exit_code == 0
    assert "created" in result.output.lower()
    mock_api.create.assert_called_once_with(
        name=None,
        workspace_id="wk-1",
        type="small",
        cpu=None,
        memory=None,
        image=None,
        snapshot_id=None,
        gpu_count=None,
        gpu_type=None,
        storage_mode=None,
        env=None,
        idle_ttl_seconds=None,
        persistent=False,
        snapshot_favor="disk_include_memory",
        hard_kill_at=None,
        hard_kill_after_seconds=None,
    )


def test_session_create_uses_configured_workspace(mock_client, mock_api):
    """Create should fall back to configured workspace when --workspace is omitted."""
    mock_api.create.return_value = SimpleNamespace(
        id="ns-1",
        status="starting",
        notebook_url="https://example.com/lab",
        created_at=datetime.now(timezone.utc),
    )

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace="wk-configured")
        result = runner.invoke(
            app,
            ["notebook", "session", "create", "--no-wait", "--no-open"],
        )

    assert result.exit_code == 0
    mock_api.create.assert_called_once_with(
        name=None,
        workspace_id="wk-configured",
        type="small",
        cpu=None,
        memory=None,
        image=None,
        snapshot_id=None,
        gpu_count=None,
        gpu_type=None,
        storage_mode=None,
        env=None,
        idle_ttl_seconds=None,
        persistent=False,
        snapshot_favor="disk_include_memory",
        hard_kill_at=None,
        hard_kill_after_seconds=None,
    )


def test_session_create_forwards_extended_fields(mock_client, mock_api):
    """Create should pass through current session DTO fields."""
    mock_api.create.return_value = SimpleNamespace(
        id="ns-1",
        status="starting",
        notebook_url="https://example.com/lab",
        created_at=datetime.now(timezone.utc),
    )

    result = runner.invoke(
        app,
        [
            "notebook",
            "session",
            "create",
            "--workspace",
            "wk-1",
            "--image",
            "docker://quay.io/jupyter/datascience-notebook:notebook-7.5.5",
            "--snapshot",
            "snap-1",
            "--gpu",
            "1",
            "--gpu-type",
            "H100",
            "--storage-mode",
            "persistent",
            "--env",
            "PYTHONUNBUFFERED=1",
            "--idle-ttl",
            "600",
            "--no-wait",
            "--no-open",
        ],
    )

    assert result.exit_code == 0
    mock_api.create.assert_called_once_with(
        name=None,
        workspace_id="wk-1",
        type="small",
        cpu=None,
        memory=None,
        image="docker://quay.io/jupyter/datascience-notebook:notebook-7.5.5",
        snapshot_id="snap-1",
        gpu_count=1,
        gpu_type="H100",
        storage_mode="persistent",
        env={"PYTHONUNBUFFERED": "1"},
        idle_ttl_seconds=600,
        persistent=False,
        snapshot_favor="disk_include_memory",
        hard_kill_at=None,
        hard_kill_after_seconds=None,
    )


def test_session_create_requires_workspace_in_json_mode(mock_client, mock_api):
    """JSON mode should emit structured error when workspace is missing."""
    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace=None)
        result = runner.invoke(
            app,
            ["notebook", "session", "create", "--no-wait", "--no-open", "--json"],
        )

    assert result.exit_code == 1
    payload = json.loads(result.output)
    assert payload["error"]["code"] == "WORKSPACE_REQUIRED"
    assert "No workspace specified" in payload["error"]["message"]
    mock_api.create.assert_not_called()


def test_session_list_json(mock_client, mock_api):
    """List notebook sessions as JSON."""
    mock_api.list_all.return_value = [
        SimpleNamespace(
            id="ns-1",
            status="running",
            notebook_url="https://example.com/lab",
            created_at=datetime.now(timezone.utc),
            model_dump=lambda by_alias=True, exclude_none=True: {
                "id": "ns-1",
                "status": "running",
                "notebookUrl": "https://example.com/lab",
                "createdAt": datetime.now(timezone.utc).isoformat(),
            },
        )
    ]

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace=None)
        result = runner.invoke(app, ["notebook", "session", "list", "--json"])

    assert result.exit_code == 0
    assert '"id": "ns-1"' in result.output
    assert '"status": "running"' in result.output
    mock_api.list_all.assert_called_once_with(None)


def test_session_list_json_uses_configured_workspace(mock_client, mock_api):
    """JSON list should also scope by configured workspace."""
    mock_api.list_all.return_value = []

    with patch("agentenv.cli.notebook.get_settings") as mock_settings:
        mock_settings.return_value = SimpleNamespace(workspace="wk-configured")
        result = runner.invoke(app, ["notebook", "session", "list", "--json"])

    assert result.exit_code == 0
    assert json.loads(result.output) == []
    mock_api.list_all.assert_called_once_with("wk-configured")


def test_session_get_json(mock_client, mock_api):
    """Get notebook session details as JSON."""
    mock_api.get.return_value = SimpleNamespace(
        id="ns-1",
        status="running",
        notebook_url="https://example.com/lab",
        created_at=datetime.now(timezone.utc),
        model_dump=lambda by_alias=True, exclude_none=True: {
            "id": "ns-1",
            "status": "running",
            "notebookUrl": "https://example.com/lab",
            "createdAt": datetime.now(timezone.utc).isoformat(),
        },
    )

    result = runner.invoke(app, ["notebook", "session", "get", "ns-1", "--json"])

    assert result.exit_code == 0
    assert '"id": "ns-1"' in result.output
    assert '"status": "running"' in result.output
    mock_api.get.assert_called_once_with("ns-1")
