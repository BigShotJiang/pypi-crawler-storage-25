"""Integration tests for workspace CLI commands."""

from datetime import datetime, timezone
import json
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.workspace import WorkspaceAPI
from agentenv.cli.app import app


runner = CliRunner()


def test_workspace_ls_json_shows_full_ids() -> None:
    """workspace ls --json should output full workspace UUIDs."""
    workspace_id = "51699bcc-7308-4715-a0e8-aa375806e264"
    owner_id = "ff80914b-eb24-4d3d-b6d8-8a149dc91a10"

    workspace = SimpleNamespace(
        id=workspace_id,
        name="cli-verify-ws",
        owner_id=owner_id,
        created_at=datetime.now(timezone.utc),
        model_dump=lambda by_alias=True, exclude_none=True: {
            "id": workspace_id,
            "name": "cli-verify-ws",
            "ownerId": owner_id,
            "createdAt": datetime.now(timezone.utc).isoformat(),
        },
    )

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = [workspace]

            result = runner.invoke(app, ["workspace", "ls", "--json"])

    assert result.exit_code == 0
    assert workspace_id in result.output
    assert owner_id in result.output


def test_workspace_invite_uses_identifier_and_role_payload() -> None:
    """workspace invite should forward identifier + role to the API layer."""
    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            mock_api_cls.return_value.invite_member.return_value = {"success": True}

            result = runner.invoke(
                app,
                ["workspace", "invite", "ws_123", "user@example.com", "--role", "owner"],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.invite_member.assert_called_once_with(
        "ws_123",
        "user@example.com",
        role="owner",
    )


def test_workspace_invite_uses_selected_workspace_by_default() -> None:
    """workspace invite should fall back to the selected workspace."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.get_settings", return_value=settings):
            with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                mock_api_cls.return_value.invite_member.return_value = {"success": True}

                result = runner.invoke(app, ["workspace", "invite", "user@example.com"])

    assert result.exit_code == 0
    mock_api_cls.return_value.invite_member.assert_called_once_with(
        "ws_selected",
        "user@example.com",
        role=None,
    )


def test_workspace_invite_rejects_incomplete_explicit_workspace_form() -> None:
    """workspace invite should not reinterpret a missing identifier as shorthand."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_settings", return_value=settings):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            result = runner.invoke(app, ["workspace", "invite", "wk_abc"])

    assert result.exit_code == 1
    assert "looks like a workspace ID" in result.output
    mock_api_cls.return_value.invite_member.assert_not_called()


def test_workspace_join_sets_default_workspace() -> None:
    """workspace join should select the joined workspace locally."""
    settings = SimpleNamespace(workspace=None, save=Mock())
    workspace = SimpleNamespace(id="ws_joined", name="Joined Workspace")

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.get_settings", return_value=settings):
            with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                mock_api_cls.return_value.join.return_value = workspace

                result = runner.invoke(app, ["workspace", "join", "JOINCODE"])

    assert result.exit_code == 0
    assert settings.workspace == "ws_joined"
    settings.save.assert_called_once_with()


def test_workspace_rm_clears_selected_workspace() -> None:
    """workspace rm should clear the selected workspace when deleting it."""
    settings = SimpleNamespace(workspace="ws_123", save=Mock())

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.get_settings", return_value=settings):
            with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                result = runner.invoke(app, ["workspace", "rm", "ws_123", "--force"])

    assert result.exit_code == 0
    mock_api_cls.return_value.delete.assert_called_once_with("ws_123")
    assert settings.workspace is None
    settings.save.assert_called_once_with()


def test_workspace_delete_alias_preserves_confirmation_flag() -> None:
    """workspace delete should respect the provided --force value."""
    with patch("agentenv.cli.workspace.typer.confirm") as mock_confirm:
        with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
            with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                result = runner.invoke(app, ["workspace", "delete", "ws_123"])

    assert result.exit_code == 0
    mock_confirm.assert_called_once_with("Delete workspace ws_123?", abort=True)
    mock_api_cls.return_value.delete.assert_called_once_with("ws_123")


def test_workspace_api_invite_member_posts_identifier_payload() -> None:
    """WorkspaceAPI.invite_member should match the backend contract."""
    client = Mock()
    response = Mock()
    response.json.return_value = {"success": True}
    client.post.return_value = response

    api = WorkspaceAPI(client)
    result = api.invite_member("ws_123", "user@example.com", role="owner")

    assert result == {"success": True}
    client.post.assert_called_once_with(
        "/v1/workspaces/ws_123/members",
        json={"identifier": "user@example.com", "role": "owner"},
    )


def test_workspace_secret_ls_json_uses_selected_workspace() -> None:
    """workspace secret-ls should emit JSON and use the selected workspace."""
    settings = SimpleNamespace(workspace="ws_selected")
    secrets = [{"id": "secret_123", "key": "API_KEY", "createdAt": "2026-04-15T00:00:00Z"}]

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.get_settings", return_value=settings):
            with patch("agentenv.cli.workspace.json_output_enabled", return_value=True):
                with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                    mock_api_cls.return_value.list_secrets.return_value = secrets

                    result = runner.invoke(app, ["workspace", "secret-ls"])

    assert result.exit_code == 0
    assert json.loads(result.output) == secrets
    mock_api_cls.return_value.list_secrets.assert_called_once_with("ws_selected")


def test_workspace_secret_set_uses_selected_workspace_by_default() -> None:
    """workspace secret-set should fall back to the selected workspace."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.get_settings", return_value=settings):
            with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
                result = runner.invoke(app, ["workspace", "secret-set", "API_KEY", "secret-value"])

    assert result.exit_code == 0
    mock_api_cls.return_value.create_secret.assert_called_once_with(
        "ws_selected",
        "API_KEY",
        "secret-value",
    )


def test_workspace_remove_member_rejects_incomplete_explicit_workspace_form() -> None:
    """workspace remove-member should not reinterpret a missing user ID as shorthand."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_settings", return_value=settings):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            result = runner.invoke(app, ["workspace", "remove-member", "wk_abc"])

    assert result.exit_code == 1
    assert "looks like a workspace ID" in result.output
    mock_api_cls.return_value.remove_member.assert_not_called()


def test_workspace_secret_set_rejects_incomplete_explicit_workspace_form() -> None:
    """workspace secret-set should not reinterpret a missing value as shorthand."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_settings", return_value=settings):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            result = runner.invoke(app, ["workspace", "secret-set", "wk_abc", "API_KEY"])

    assert result.exit_code == 1
    assert "looks like a workspace ID" in result.output
    mock_api_cls.return_value.create_secret.assert_not_called()


def test_workspace_secret_update_rejects_incomplete_explicit_workspace_form() -> None:
    """workspace secret-update should not reinterpret a missing secret ID as shorthand."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_settings", return_value=settings):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            result = runner.invoke(app, ["workspace", "secret-update", "wk_abc", "--key", "RENAMED"])

    assert result.exit_code == 1
    assert "looks like a workspace ID" in result.output
    mock_api_cls.return_value.update_secret.assert_not_called()


def test_workspace_secret_rm_rejects_incomplete_explicit_workspace_form() -> None:
    """workspace secret-rm should not reinterpret a missing secret ID as shorthand."""
    settings = SimpleNamespace(workspace="ws_selected")

    with patch("agentenv.cli.workspace.get_settings", return_value=settings):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            result = runner.invoke(app, ["workspace", "secret-rm", "wk_abc"])

    assert result.exit_code == 1
    assert "looks like a workspace ID" in result.output
    mock_api_cls.return_value.delete_secret.assert_not_called()


def test_workspace_api_update_secret_posts_key_and_value_payload() -> None:
    """WorkspaceAPI.update_secret should send any provided secret fields."""
    client = Mock()
    response = Mock()
    response.json.return_value = {"id": "secret_123"}
    client.patch.return_value = response

    api = WorkspaceAPI(client)
    result = api.update_secret(
        "ws_123",
        "secret_123",
        key="RENAMED_KEY",
        value="new-value",
    )

    assert result == {"id": "secret_123"}
    client.patch.assert_called_once_with(
        "/v1/workspaces/ws_123/secrets/secret_123",
        json={"key": "RENAMED_KEY", "value": "new-value"},
    )
