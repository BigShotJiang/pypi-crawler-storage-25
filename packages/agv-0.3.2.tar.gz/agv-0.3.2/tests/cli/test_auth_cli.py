"""Tests for auth CLI commands."""

import json
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.models import APIKey
from agentenv.cli.app import app
from agentenv.cli.auth import _build_frontend_login_url

runner = CliRunner()


def _mock_settings() -> Mock:
    settings = Mock()
    settings.api_url = "http://test"
    settings.api_key = None
    settings.access_token = "access-token"
    settings.refresh_token = None
    settings.workspace = None
    settings.save = Mock()
    settings.is_authenticated.return_value = True
    return settings


def test_create_key_parses_api_key_alias() -> None:
    """create-key should parse apiKey from server response."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            apiKey="sk_live_from_api_key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 0
    assert "sk_live_from_api_key" in result.output
    assert "agv login --api-key sk_live_from_api_key" in result.output


def test_create_key_keeps_legacy_key_compatibility() -> None:
    """create-key should also accept legacy key field for compatibility."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            key="sk_live_legacy_key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 0
    assert "sk_live_legacy_key" in result.output


def test_create_key_fails_if_plaintext_key_is_missing() -> None:
    """create-key must fail if response does not include plaintext key."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 1
    assert "did not include plaintext key" in result.output


def test_list_keys_handles_nullable_name() -> None:
    """list-keys should render keys even if name is null."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.list_api_keys.return_value = [
            APIKey(
                id="ak_1234567890ab",
                name=None,
                createdAt="2026-03-02T00:00:00Z",
            ),
        ]
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "list-keys"])

    assert result.exit_code == 0
    assert "API Keys" in result.output
    assert "Traceback" not in result.output


def test_login_browser_flow_uses_public_host_for_remote_callback() -> None:
    settings = _mock_settings()
    settings.api_key = None
    settings.access_token = None
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch("agentenv.oauth.flow.run_browser_login_flow") as mock_browser_flow,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_browser_flow.return_value = ("access-token-remote", None)
        mock_api = Mock()
        mock_api.get_profile.return_value = SimpleNamespace(username="tester")
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "login",
                "--public-host",
                "177.54.159.23",
                "--callback-port",
                "50392",
            ],
        )

    assert result.exit_code == 0
    mock_browser_flow.assert_called_once_with(
        frontend_url="http://test/login",
        port=50392,
        open_browser=True,
        callback_host="177.54.159.23",
        callback_bind_host="0.0.0.0",
    )


def test_login_browser_flow_defaults_to_localhost_callback() -> None:
    settings = _mock_settings()
    settings.api_key = None
    settings.access_token = None
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch("agentenv.oauth.flow.run_browser_login_flow") as mock_browser_flow,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_browser_flow.return_value = ("access-token-local", None)
        mock_api = Mock()
        mock_api.get_profile.return_value = SimpleNamespace(username="tester")
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["login"])

    assert result.exit_code == 0
    mock_browser_flow.assert_called_once_with(
        frontend_url="http://test/login",
        port=50391,
        open_browser=True,
        callback_host="localhost",
        callback_bind_host="127.0.0.1",
    )


def test_build_frontend_login_url_for_local_api_uses_vite_port() -> None:
    """Local API URLs should still open the local frontend dev server."""
    assert _build_frontend_login_url("http://localhost:3000") == "http://localhost:5173/login"
    assert _build_frontend_login_url("http://127.0.0.1:3000") == "http://127.0.0.1:5173/login"


def test_build_frontend_login_url_for_hosted_api_uses_branded_frontend() -> None:
    """Hosted API URLs should map to the branded frontend domain without api."""
    assert (
        _build_frontend_login_url("https://api.agentenv.cloud")
        == "https://agentenv.cloud/login"
    )
    assert (
        _build_frontend_login_url("https://api.agentenv.cloud/api")
        == "https://agentenv.cloud/login"
    )


def test_auth_status_global_json_outputs_single_payload() -> None:
    """Global --json should make auth status emit one JSON object."""
    settings = _mock_settings()

    with patch("agentenv.cli.auth.get_settings", return_value=settings):
        result = runner.invoke(app, ["--json", "auth", "status"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["authenticated"] is True
    assert payload["credentials"]["apiUrl"] == "http://test"


def test_login_password_handles_totp_challenge_json() -> None:
    settings = _mock_settings()
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.login.return_value = {
            "requiresTotp": True,
            "tempToken": "temp-token-123",
            "message": "TOTP verification required",
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            ["--json", "auth", "login", "--username", "user@example.com", "--password", "secret"],
        )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["authenticated"] is False
    assert payload["requiresTotp"] is True
    assert payload["tempToken"] == "temp-token-123"
    settings.save_credentials.assert_not_called()


def test_auth_workspaces_json_outputs_server_payload() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.get_workspaces.return_value = {
            "workspaces": [
                {
                    "id": "ws_123",
                    "name": "Primary Workspace",
                    "totpRequired": True,
                }
            ],
            "selectedWorkspaceId": "ws_123",
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["--json", "auth", "workspaces"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["selectedWorkspaceId"] == "ws_123"
    assert payload["workspaces"][0]["name"] == "Primary Workspace"


def test_auth_workspaces_requires_authentication() -> None:
    settings = _mock_settings()
    settings.is_authenticated.return_value = False

    with patch("agentenv.cli.auth.get_settings", return_value=settings):
        result = runner.invoke(app, ["auth", "workspaces"])

    assert result.exit_code == 1
    assert "Not authenticated" in result.output


def test_select_workspace_updates_server_and_local_setting() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.set_workspace.return_value = {
            "userId": "user_123",
            "username": "tester",
            "selectedWorkspaceId": "ws_456",
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "select-workspace", "ws_456"])

    assert result.exit_code == 0
    assert settings.workspace == "ws_456"
    settings.save.assert_called_once_with()
    mock_api.set_workspace.assert_called_once_with("ws_456")
    assert "Active workspace set to ws_456" in result.output


def test_select_workspace_json_outputs_server_payload() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.set_workspace.return_value = {
            "userId": "user_123",
            "username": "tester",
            "selectedWorkspaceId": "ws_json",
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["--json", "auth", "select-workspace", "ws_json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["selectedWorkspaceId"] == "ws_json"
    assert settings.workspace == "ws_json"
    settings.save.assert_called_once_with()


def test_select_workspace_requires_authentication() -> None:
    settings = _mock_settings()
    settings.is_authenticated.return_value = False

    with patch("agentenv.cli.auth.get_settings", return_value=settings):
        result = runner.invoke(app, ["auth", "select-workspace", "ws_123"])

    assert result.exit_code == 1
    assert "Not authenticated" in result.output


def test_login_password_handles_totp_challenge_human_output() -> None:
    settings = _mock_settings()
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.login.return_value = {
            "requiresTotp": True,
            "tempToken": "temp-token-123",
            "message": "TOTP verification required",
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            ["auth", "login", "--username", "user@example.com", "--password", "secret"],
        )

    assert result.exit_code == 0
    assert "complete-totp-login" in result.output
    assert "temp-token-123" in result.output
    settings.save_credentials.assert_not_called()


def test_complete_totp_login_saves_tokens_and_supports_json() -> None:
    settings = _mock_settings()
    settings.access_token = None
    settings.refresh_token = None
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.verify_totp.return_value = {
            "accessToken": "new-access",
            "refreshToken": "new-refresh",
            "user": {"username": "tester"},
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "--json",
                "auth",
                "complete-totp-login",
                "--temp-token",
                "temp-token-123",
                "--code",
                "123456",
            ],
        )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["authenticated"] is True
    assert payload["method"] == "totp"
    assert payload["username"] == "tester"
    assert settings.access_token == "new-access"
    assert settings.refresh_token == "new-refresh"
    settings.save_credentials.assert_called_once()


def test_profile_supports_global_json() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.get_profile.return_value = SimpleNamespace(
            id="user_123",
            email="user@example.com",
            username="tester",
            email_verified=True,
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["--json", "auth", "profile"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["id"] == "user_123"
    assert payload["email"] == "user@example.com"
    assert payload["username"] == "tester"


def test_forgot_password_supports_json() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.forgot_password.return_value = {"message": "Reset email sent"}
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["--json", "auth", "forgot-password", "user@example.com"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["message"] == "Reset email sent"


def test_reset_password_uses_token_and_password_options() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.reset_password.return_value = {"message": "Password reset successful"}
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "--json",
                "auth",
                "reset-password",
                "--token",
                "reset-token-123",
                "--new-password",
                "new-secret",
            ],
        )

    assert result.exit_code == 0
    mock_api.reset_password.assert_called_once_with("reset-token-123", "new-secret")
    payload = json.loads(result.output)
    assert payload["message"] == "Password reset successful"


def test_verify_email_supports_json() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.verify_email.return_value = {"message": "Email verified"}
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            ["--json", "auth", "verify-email", "--token", "verify-token-123"],
        )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["message"] == "Email verified"


def test_resend_verification_supports_json() -> None:
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.resend_verification.return_value = {"message": "Verification email sent"}
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            ["--json", "auth", "resend-verification", "user@example.com"],
        )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["message"] == "Verification email sent"
