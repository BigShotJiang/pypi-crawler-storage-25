"""Regression tests for root CLI entrypoints that dispatch to subcommands."""

import json
from contextlib import nullcontext
from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.cli.app import app

runner = CliRunner()


def test_browser_root_invokes_create_flow_without_subcommand() -> None:
    """`agv browser` should create a browser session instead of erroring."""
    session = SimpleNamespace(
        id="br-1",
        status="starting",
        cdp_url="wss://example.com/devtools",
        vnc_url="wss://example.com/vnc",
    )

    with (
        patch("agentenv.cli.browser.get_client", return_value=Mock()),
        patch("agentenv.cli.browser.BrowserAPI") as mock_api_cls,
        patch(
            "agentenv.cli.browser.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
        patch("agentenv.cli.browser.webbrowser.open") as mock_open,
    ):
        mock_api_cls.return_value.create.return_value = session
        result = runner.invoke(app, ["browser", "--no-wait", "--no-open"])

    assert result.exit_code == 0
    assert "Browser session br-1 created" in result.output
    mock_api_cls.return_value.create.assert_called_once_with(
        name=None,
        workspace_id=None,
        screen_width=1280,
        screen_height=720,
        enable_stealth=False,
        enable_adblock=False,
        profile_mode="persistent",
        profile_id=None,
        proxy_url=None,
        proxy_username=None,
        proxy_password=None,
        proxy_provider=None,
        proxy_type=None,
        enable_captcha_solver=False,
        captcha_provider=None,
        captcha_api_key=None,
        enable_rrweb=False,
        enable_logger=False,
        cpu_millis=None,
        memory_mb=None,
        max_lifetime_seconds=None,
        gpu_type=None,
        geonode_proxy=None,
    )
    mock_open.assert_not_called()


def test_notebook_root_invokes_session_create_without_subcommand() -> None:
    """`agv notebook` should create a notebook session instead of erroring."""
    session = SimpleNamespace(
        id="ns-1",
        status="starting",
        notebook_url="https://example.com/lab",
        created_at=datetime.now(UTC),
    )

    with (
        patch("agentenv.cli.notebook.get_client", return_value=Mock()),
        patch("agentenv.cli.notebook.NotebookAPI") as mock_api_cls,
        patch(
            "agentenv.cli.notebook.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
        patch("agentenv.cli.notebook.webbrowser.open") as mock_open,
    ):
        mock_api_cls.return_value.create.return_value = session
        result = runner.invoke(
            app,
            ["notebook", "--workspace", "wk-1", "--no-wait", "--no-open"],
        )

    assert result.exit_code == 0
    assert "Notebook session ns-1 created" in result.output
    mock_api_cls.return_value.create.assert_called_once_with(
        name=None,
        workspace_id="wk-1",
        type="small",
        cpu=None,
        memory=None,
        image=None,
        snapshot_id=None,
        gpu_count=None,
        gpu_type=None,
        storage_mode=None,
        env=None,
        idle_ttl_seconds=None,
        persistent=False,
        snapshot_favor="disk_include_memory",
        hard_kill_at=None,
        hard_kill_after_seconds=None,
    )
    mock_open.assert_not_called()


def test_version_global_json_outputs_single_payload() -> None:
    """Global --json should make version emit a JSON object."""
    result = runner.invoke(app, ["--json", "version"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert "agentenvCli" in payload
    assert "python" in payload
