"""Tests for managed-agent CLI commands."""

import json
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.models import (
    ManagedAgent,
    ManagedAgentListResponse,
    ManagedAgentStreamEvent,
    OperationSuccess,
)
from agentenv.cli.app import app


runner = CliRunner()


def _build_agent(**overrides) -> ManagedAgent:
    payload = {
        "id": "ma_123",
        "workspaceId": "wk_123",
        "sandboxId": "sb_123",
        "name": "Managed Agent",
        "status": "running",
        "config": {
            "upstreamId": "up_123",
            "model": "gpt-5-codex",
        },
        "metadata": None,
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return ManagedAgent(**payload)


def test_managed_agent_ls_forwards_filters_and_renders_json() -> None:
    """managed-agent ls should pass filters to the API and emit JSON."""
    list_response = ManagedAgentListResponse(
        agents=[_build_agent()],
        total=1,
        page=2,
        limit=10,
    )

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = list_response

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "ls",
                    "--workspace",
                    "wk_123",
                    "--agent-workspace-group-id",
                    "awg_123",
                    "--search",
                    "Managed",
                    "--page",
                    "2",
                    "--limit",
                    "10",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert '"total": 1' in result.output
    mock_api_cls.return_value.list_all.assert_called_once_with(
        workspace_id="wk_123",
        agent_workspace_group_id="awg_123",
        search="Managed",
        page=2,
        limit=10,
    )


def test_managed_agent_create_forwards_expected_arguments() -> None:
    """managed-agent create should send the managed-agent DTO fields."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.create.return_value = _build_agent(status="starting")

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "create",
                    "--name",
                    "Builder",
                    "--workspace",
                    "wk_123",
                    "--upstream-id",
                    "up_123",
                    "--model",
                    "gpt-5-codex",
                    "--instructions",
                    "be careful",
                    "--image",
                    "docker://registry.example/agent:latest",
                    "--workspace-template",
                    "solayer-order-agent",
                    "--cpu",
                    "4000",
                    "--memory",
                    "8192",
                    "--agent-workspace-group-id",
                    "awg_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.create.assert_called_once_with(
        name="Builder",
        workspace_id="wk_123",
        upstream_id="up_123",
        model="gpt-5-codex",
        instructions="be careful",
        image="docker://registry.example/agent:latest",
        workspace_template="solayer-order-agent",
        cpu_millis=4000,
        memory_mb=8192,
        agent_workspace_group_id="awg_123",
    )


def test_managed_agent_send_prints_final_assistant_message() -> None:
    """managed-agent send should stream assistant deltas for human output."""
    events = [
        ManagedAgentStreamEvent(type="run.started", runId="run_123", agentId="ma_123"),
        ManagedAgentStreamEvent(
            type="message.delta",
            messageId="msg_123",
            delta="Hello ",
        ),
        ManagedAgentStreamEvent(
            type="message.delta",
            messageId="msg_123",
            delta="from the agent",
        ),
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Hello from the agent",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.get.return_value = _build_agent()
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                ["managed-agent", "send", "ma_123", "--", "hello", "agent"],
            )

    assert result.exit_code == 0
    assert "Hello from the agent" in result.output
    mock_api_cls.return_value.get.assert_called_once_with("ma_123")
    mock_api_cls.return_value.stream_message.assert_called_once_with("ma_123", "hello agent")


def test_managed_agent_send_wakes_sleeping_agent_before_streaming() -> None:
    """managed-agent send should auto-wake sleeping agents before streaming."""
    events = [
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Ready",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.get.return_value = _build_agent(status="sleeping")
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                ["managed-agent", "send", "ma_123", "--", "wake", "up"],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.wake.assert_called_once_with("ma_123")
    mock_api_cls.return_value.wait_for_status.assert_called_once_with(
        "ma_123",
        desired_status="running",
        timeout=120.0,
    )


def test_managed_agent_send_events_streams_ndjson() -> None:
    """managed-agent send --events should emit one JSON event per line."""
    events = [
        ManagedAgentStreamEvent(type="run.started", runId="run_123", agentId="ma_123"),
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Hello from the agent",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "send",
                    "ma_123",
                    "--events",
                    "--no-wake",
                    "--",
                    "hello",
                    "agent",
                ],
            )

    assert result.exit_code == 0
    lines = [json.loads(line) for line in result.output.splitlines() if line.strip()]
    assert [line["type"] for line in lines] == ["run.started", "message.completed"]
    assert lines[1]["content"] == "Hello from the agent"
    mock_api_cls.return_value.stream_message.assert_called_once_with("ma_123", "hello agent")
    mock_api_cls.return_value.send_message.assert_not_called()


def test_managed_agent_rm_deletes_with_force() -> None:
    """managed-agent rm --force should delete without prompting."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.delete.return_value = OperationSuccess(success=True)

            result = runner.invoke(
                app,
                ["managed-agent", "rm", "ma_123", "--force", "--json"],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.delete.assert_called_once_with("ma_123")
