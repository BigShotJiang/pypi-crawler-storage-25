"""Integration tests for cluster CLI commands."""

from collections.abc import Iterator
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.cli.app import app
from agentenv.api.cluster import ClusterAPI

runner = CliRunner()


def test_cluster_ls_uses_workspace_filter() -> None:
    """List clusters should forward the workspace filter."""
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.list_clusters.return_value = []
        result = runner.invoke(app, ["cluster", "ls", "--workspace", "wk-1"])

    assert result.exit_code == 0
    mock_api_cls.return_value.list_clusters.assert_called_once_with(workspace_id="wk-1")


def test_cluster_ray_create_uses_current_payload() -> None:
    """Create Ray cluster should use the current cluster DTO fields."""
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.create_ray_cluster.return_value = {
            "id": "cl-1",
            "status": "pending",
            "type": "ray",
            "config": {"shape": "4x2xH100"},
        }
        result = runner.invoke(
            app,
            [
                "cluster",
                "ray",
                "4x2xH100",
                "--workspace",
                "wk-1",
                "--name",
                "training",
                "--image",
                "docker://rayproject/ray:latest",
                "--snapshot",
                "snap-1",
                "--allow-cidr",
                "1.2.3.4/32",
            ],
        )

    assert result.exit_code == 0
    mock_api_cls.return_value.create_ray_cluster.assert_called_once_with(
        workspace_id="wk-1",
        shape="4x2xH100",
        name="training",
        image="docker://rayproject/ray:latest",
        snapshot_id="snap-1",
        allow_cidr="1.2.3.4/32",
    )


def test_cluster_status_renders_machine_metadata() -> None:
    """Status should show provisioning and head endpoint details."""
    cluster = {
        "id": "cl-1",
        "name": "trainer",
        "type": "ray",
        "status": "starting",
        "progress": 65,
        "workspaceId": "wk-1",
        "metadata": {
            "provisioningStep": "creating_workers",
            "headHost": "10.0.0.5",
            "headRayClientHostPort": 10001,
        },
    }
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_cluster.return_value = cluster
        result = runner.invoke(app, ["cluster", "status", "cl-1"])

    assert result.exit_code == 0
    assert "creating worker nodes" in result.stdout.lower()
    assert "10.0.0.5:10001" in result.stdout


def test_cluster_wait_uses_cluster_api_waiter() -> None:
    """Wait should delegate polling to the cluster API wrapper."""
    cluster = {"id": "cl-1", "type": "ray", "status": "running", "metadata": {}}
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.wait_for_cluster.return_value = cluster
        result = runner.invoke(app, ["cluster", "wait", "cl-1", "--for-state", "running", "--timeout", "9"])

    assert result.exit_code == 0
    mock_api_cls.return_value.wait_for_cluster.assert_called_once_with(
        "cl-1",
        timeout=9,
        target_status="running",
    )


def test_cluster_api_waiter_ignores_non_target_terminal_until_target_reached() -> None:
    """Waiter should keep polling until the requested status is reached."""
    client = Mock()
    api = ClusterAPI(client)
    responses: Iterator[dict[str, str]] = iter(
        [
            {"id": "cl-1", "status": "running"},
            {"id": "cl-1", "status": "stopping"},
            {"id": "cl-1", "status": "stopped"},
        ]
    )

    with patch.object(api, "get_cluster", side_effect=lambda _cluster_id: next(responses)):
        result = api.wait_for_cluster("cl-1", timeout=5, target_status="stopped", poll_interval=0)

    assert result["status"] == "stopped"


def test_cluster_stop_waits_for_stopped_state() -> None:
    """Stop --wait should request stop then wait for a stopped terminal state."""
    cluster = {"id": "cl-1", "type": "ray", "status": "stopped", "metadata": {}}
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.stop_cluster.return_value = {"id": "cl-1", "status": "stopping"}
        mock_api_cls.return_value.wait_for_cluster.return_value = cluster
        result = runner.invoke(app, ["cluster", "stop", "cl-1", "--wait", "--timeout", "15"])

    assert result.exit_code == 0
    mock_api_cls.return_value.stop_cluster.assert_called_once_with("cl-1")
    mock_api_cls.return_value.wait_for_cluster.assert_called_once_with(
        "cl-1",
        timeout=15,
        target_status="stopped",
    )


def test_cluster_inspect_renders_human_detail_view() -> None:
    """Inspect should render a readable detail view outside JSON mode."""
    cluster = {
        "id": "cl-1",
        "name": "trainer",
        "type": "spark",
        "status": "failed",
        "workspaceId": "wk-1",
        "createdAt": "2026-04-07T00:00:00Z",
        "progress": 80,
        "config": {
            "shape": "4x2xH100",
            "nodeCount": 2,
            "gpusPerNode": 2,
            "gpuType": "H100",
            "image": "apache/spark:3.5.8",
        },
        "metadata": {
            "provisioningStep": "waiting_for_head",
            "headHost": "10.0.0.5",
            "headSparkConnectHostPort": 15002,
            "failureReason": "Head node failed health checks",
        },
    }
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_cluster.return_value = cluster
        result = runner.invoke(app, ["cluster", "inspect", "cl-1"])

    assert result.exit_code == 0
    assert "Head Port" in result.stdout
    assert "15002" in result.stdout
    assert "Head node failed health checks" in result.stdout
