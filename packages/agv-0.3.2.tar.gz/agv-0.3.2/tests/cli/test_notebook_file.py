"""Integration tests for notebook file CLI commands."""

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from agentenv.cli.app import app


runner = CliRunner()


def _mock_file(path: str, *, is_directory: bool = False) -> SimpleNamespace:
    return SimpleNamespace(
        name=path.split("/")[-1],
        path=path,
        size_bytes=0 if is_directory else 26,
        mime_type="directory" if is_directory else "text/csv",
        created_at=datetime.now(timezone.utc),
        modified_at=datetime.now(timezone.utc),
        is_directory=is_directory,
    )


@pytest.fixture
def mock_api():
    with patch("agentenv.cli.notebook.NotebookAPI") as mock:
        api = mock.return_value
        api.ensure_kernel.return_value = {"status": "starting"}
        api.get_kernel_status.return_value = {"status": "idle"}
        yield api


@pytest.fixture
def mock_client():
    with patch("agentenv.cli.notebook.get_client") as mock:
        mock.return_value = Mock()
        yield mock


def test_notebook_file_ls(mock_client, mock_api):
    mock_api.list_files.return_value = [_mock_file("/data/acceptance-data.csv")]

    result = runner.invoke(app, ["notebook", "file", "ls", "nb-123", "data"])

    assert result.exit_code == 0
    assert "acceptance-data.csv" in result.output
    mock_api.ensure_kernel.assert_not_called()
    mock_api.list_files.assert_called_once_with("nb-123", "data")


def test_notebook_file_mkdir(mock_client, mock_api):
    mock_api.create_directory.return_value = _mock_file("/data", is_directory=True)

    result = runner.invoke(app, ["notebook", "file", "mkdir", "nb-123", "data"])

    assert result.exit_code == 0
    assert "Directory created" in result.output
    mock_api.ensure_kernel.assert_called_once_with("nb-123")
    mock_api.create_directory.assert_called_once_with("nb-123", "data")


def test_notebook_file_upload(mock_client, mock_api, tmp_path):
    local_file = tmp_path / "acceptance-data.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_api.upload_file.return_value = _mock_file("/data/acceptance-data.csv")

    result = runner.invoke(
        app,
        ["notebook", "file", "upload", "nb-123", str(local_file), "data/"],
    )

    assert result.exit_code == 0
    assert "File uploaded" in result.output
    mock_api.ensure_kernel.assert_called_once_with("nb-123")
    mock_api.upload_file.assert_called_once_with(
        "nb-123",
        str(local_file),
        "data",
        None,
    )


def test_notebook_file_upload_supports_root_extensionless_rename(mock_client, mock_api, tmp_path):
    local_file = tmp_path / "acceptance-data.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_api.upload_file.return_value = _mock_file("/README")

    result = runner.invoke(
        app,
        ["notebook", "file", "upload", "nb-123", str(local_file), "README"],
    )

    assert result.exit_code == 0
    mock_api.upload_file.assert_called_once_with(
        "nb-123",
        str(local_file),
        None,
        "README",
    )


def test_notebook_file_upload_supports_remote_file_path(mock_client, mock_api, tmp_path):
    local_file = tmp_path / "acceptance-data.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_api.upload_file.return_value = _mock_file("/data/renamed.csv")

    result = runner.invoke(
        app,
        ["notebook", "file", "upload", "nb-123", str(local_file), "data/renamed.csv"],
    )

    assert result.exit_code == 0
    mock_api.upload_file.assert_called_once_with(
        "nb-123",
        str(local_file),
        "data",
        "renamed.csv",
    )


def test_notebook_file_upload_ensures_kernel_first(mock_client, mock_api, tmp_path):
    local_file = tmp_path / "acceptance-data.csv"
    local_file.write_text("name,value\nalpha,1\n", encoding="utf-8")
    mock_api.upload_file.return_value = _mock_file("/data/acceptance-data.csv")
    mock_api.ensure_kernel.return_value = {"status": "starting"}
    mock_api.get_kernel_status.side_effect = [
        {"status": "busy", "message": "Kernel starting"},
        {"status": "idle"},
    ]

    result = runner.invoke(
        app,
        ["notebook", "file", "upload", "nb-123", str(local_file), "data/"],
    )

    assert result.exit_code == 0
    mock_api.ensure_kernel.assert_called_once_with("nb-123")
    assert mock_api.get_kernel_status.call_count == 2


def test_notebook_file_download(mock_client, mock_api, tmp_path):
    output_file = tmp_path / "downloaded.csv"

    result = runner.invoke(
        app,
        [
            "notebook",
            "file",
            "download",
            "nb-123",
            "data/acceptance-data.csv",
            str(output_file),
        ],
    )

    assert result.exit_code == 0
    assert "File downloaded" in result.output
    mock_api.ensure_kernel.assert_not_called()
    mock_api.download_file.assert_called_once_with(
        "nb-123",
        "data/acceptance-data.csv",
        str(output_file),
    )


def test_notebook_file_rm(mock_client, mock_api):
    result = runner.invoke(
        app,
        ["notebook", "file", "rm", "nb-123", "data/acceptance-data.csv", "--force"],
    )

    assert result.exit_code == 0
    assert "Deleted" in result.output
    mock_api.ensure_kernel.assert_not_called()
    mock_api.delete_file.assert_called_once_with("nb-123", "data/acceptance-data.csv")
