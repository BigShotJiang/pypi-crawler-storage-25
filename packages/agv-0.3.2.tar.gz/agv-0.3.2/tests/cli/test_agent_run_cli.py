"""Tests for agent run CLI commands."""

import json
import subprocess
from unittest.mock import MagicMock, Mock, patch

import typer
from typer.testing import CliRunner

from agentenv.cli.app import app
from agentenv.cli.agent import (
    _is_payable_challenge,
    _parse_amount_to_cents,
    _validate_preflight_result,
    _run_payment_helper,
)

runner = CliRunner()


def _mock_settings():
    settings = MagicMock()
    settings.is_authenticated.return_value = True
    settings.api_url = "https://api.example.com"
    settings.api_key = "sk_test"
    settings.access_token = None
    settings.workspace = "wk_default"
    return settings


def _mock_client():
    return Mock()


def test_is_payable_challenge_requires_non_empty_provider_reference() -> None:
    """Only 402 payloads with a stable provider reference are payable."""
    assert _is_payable_challenge(
        {"statusCode": 402, "challenge": {"providerReference": "pi_123"}}
    )
    assert not _is_payable_challenge({"statusCode": 402, "challenge": {}})
    assert not _is_payable_challenge(
        {"statusCode": 402, "challenge": {"providerReference": ""}}
    )
    assert not _is_payable_challenge(
        {"statusCode": 402, "challenge": {"providerReference": "   "}}
    )


def test_agent_run_help_uses_agv_in_example() -> None:
    """Help output should document the package-aligned agv entrypoint."""
    result = runner.invoke(app, ["agent", "run", "--help"])

    assert result.exit_code == 0
    assert "agv agent run -w wk_123 -b ba_123 -a 10 -- \"run this agent\"" in result.output
    assert "av agent run" not in result.output


def test_agent_run_auth_error_references_agv_login() -> None:
    """Auth failures should point users at the agv login command."""
    settings = _mock_settings()
    settings.is_authenticated.return_value = False

    with patch("agentenv.cli.agent.get_settings", return_value=settings):
        result = runner.invoke(
            app,
            [
                "agent",
                "run",
                "--workspace",
                "wk_123",
                "--billing-account-id",
                "ba_123",
                "--amount",
                "10",
                "--json",
                "--",
                "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"] == {
        "code": "AUTH_REQUIRED",
        "message": "Not authenticated. Run 'agv login' first.",
    }


def test_agent_run_retries_same_protected_request_after_402() -> None:
    """Full happy-path: protected request -> 402 -> helper pay -> same request retry."""
    mock_client = _mock_client()

    # first run returns 402
    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )

    # replay returns success
    replay_response = Mock()
    replay_response.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "agent result", "status": "completed"},
    }

    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}

    mock_client.post.side_effect = [preflight_response, run_402_response, replay_response]

    mock_helper = MagicMock()
    mock_helper.run_payment.return_value = "MACHINE mpp-token"

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0, f"Exit code {result.exit_code}: {result.output}"
    output = json.loads(result.output)
    assert output["requestId"] == "req_123"
    assert output["result"]["status"] == "completed"
    assert mock_client.post.call_count == 3
    preflight_payload = mock_client.post.call_args_list[0]
    run_payload = mock_client.post.call_args_list[1].kwargs["json"]
    replay_payload = mock_client.post.call_args_list[2].kwargs["json"]
    assert preflight_payload.args[0] == "/v1/agent/run/preflight"
    assert run_payload["idempotencyKey"] == replay_payload["idempotencyKey"]
    assert run_payload == replay_payload
    assert mock_client.post.call_args_list[2].kwargs["headers"] == {
        "Authorization": "MACHINE mpp-token"
    }
    mock_helper.run_payment.assert_called_once_with(
        challenge={"providerReference": "pi_123", "depositAddresses": {}}
    )


def test_agent_run_succeeds_without_payment_when_paid_immediately() -> None:
    """When the first run succeeds without 402, no helper is needed."""
    mock_client = _mock_client()

    run_success_response = Mock()
    run_success_response.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "done", "status": "completed"},
    }

    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}

    mock_client.post.side_effect = [preflight_response, run_success_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0
    output = json.loads(result.output)
    assert output["result"]["status"] == "completed"


def test_agent_run_surfaces_processing_without_starting_payment() -> None:
    """A 202 response should be returned directly without invoking the payer."""
    mock_client = _mock_client()

    processing_response = Mock()
    processing_response.status_code = 202
    processing_response.json.return_value = {
        "requestId": "req_123",
        "processing": True,
    }
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, processing_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper") as helper_cls,
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0
    output = json.loads(result.output)
    assert output == {
        "requestId": "req_123",
        "processing": True,
        "statusCode": 202,
    }
    helper_cls.assert_not_called()


def test_agent_run_does_not_repay_when_replay_is_still_processing() -> None:
    """The CLI should pay once, then surface replay processing without another pay attempt."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )

    replay_processing_response = Mock()
    replay_processing_response.status_code = 202
    replay_processing_response.json.return_value = {
        "requestId": "req_123",
        "processing": True,
    }

    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}

    mock_client.post.side_effect = [
        preflight_response,
        run_402_response,
        replay_processing_response,
    ]

    mock_helper = MagicMock()
    mock_helper.run_payment.return_value = "MACHINE mpp-token"

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0
    output = json.loads(result.output)
    assert output == {
        "requestId": "req_123",
        "processing": True,
        "statusCode": 202,
    }
    assert mock_client.post.call_count == 3
    mock_helper.run_payment.assert_called_once()


def test_agent_run_does_not_invoke_helper_for_malformed_terminal_402() -> None:
    """A malformed terminal 402 must surface the server error without paying or replaying."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment failed at provider.",
        details={
            "requestId": "req_123",
            "paid": False,
            "challenge": {},
            "error": "Payment failed at provider.",
        },
    )
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, run_402_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper") as helper_cls,
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"] == {
        "code": "RUN_FAILED",
        "message": "Payment failed at provider.",
    }
    helper_cls.assert_not_called()
    assert mock_client.post.call_count == 2


def test_run_payment_helper_returns_authorization_header_string() -> None:
    """CLI helper wrapper should pass through the header string contract directly."""
    mock_helper = MagicMock()
    mock_helper.run_payment.return_value = "MACHINE mpp-token"

    with patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper):
        assert (
            _run_payment_helper(
                {"providerReference": "pi_123", "depositAddresses": {}},
                json_output=True,
            )
            == "MACHINE mpp-token"
        )


def test_agent_run_normalizes_helper_construction_failure_to_payment_failed() -> None:
    """Helper construction failures should surface as PAYMENT_FAILED."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, run_402_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch(
            "agentenv.cli.agent.OfficialMppxHelper",
            side_effect=RuntimeError("runner bootstrap failed"),
        ),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"]["code"] == "PAYMENT_FAILED"
    assert "runner bootstrap failed" in output["error"]["message"]
    assert mock_client.post.call_count == 2


def test_agent_run_normalizes_helper_timeout_to_payment_failed() -> None:
    """Helper timeouts should surface as PAYMENT_FAILED."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, run_402_response]

    mock_helper = MagicMock()
    mock_helper.run_payment.side_effect = subprocess.TimeoutExpired(
        cmd=["node", "run-payment.mjs"],
        timeout=60,
    )

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"]["code"] == "PAYMENT_FAILED"
    assert "timed out" in output["error"]["message"]


def test_agent_run_normalizes_unknown_helper_exception_to_payment_failed() -> None:
    """Unexpected helper exceptions should still surface as PAYMENT_FAILED."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, run_402_response]

    mock_helper = MagicMock()
    mock_helper.run_payment.side_effect = ValueError("unexpected helper crash")

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"]["code"] == "PAYMENT_FAILED"
    assert "unexpected helper crash" in output["error"]["message"]
    assert mock_client.post.call_count == 2


def test_agent_run_normalizes_invalid_helper_json_to_payment_failed() -> None:
    """Invalid helper JSON should surface as PAYMENT_FAILED."""
    mock_client = _mock_client()

    from agentenv.api.client import APIError

    run_402_response = APIError(
        status_code=402,
        message="Payment required",
        details={
            "requestId": "req_123",
            "paid": False,
            "providerReference": "pi_123",
            "challenge": {"providerReference": "pi_123", "depositAddresses": {}},
        },
    )
    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    mock_client.post.side_effect = [preflight_response, run_402_response]

    mock_helper = MagicMock()
    mock_helper.run_payment.side_effect = json.JSONDecodeError(
        "Expecting value",
        "",
        0,
    )

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
        patch("agentenv.cli.agent.OfficialMppxHelper", return_value=mock_helper),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"]["code"] == "PAYMENT_FAILED"
    assert "Expecting value" in output["error"]["message"]
    assert mock_client.post.call_count == 2


def test_agent_run_surfaces_preflight_failure() -> None:
    """An explicit preflight rejection should stop before the paid request begins."""
    mock_client = _mock_client()
    preflight_response = Mock()
    preflight_response.json.return_value = {
        "eligible": False,
        "message": "billing account not eligible",
    }
    mock_client.post.side_effect = [preflight_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"] == {
        "code": "PREFLIGHT_FAILED",
        "message": "Preflight failed: billing account not eligible",
    }
    assert mock_client.post.call_count == 1


def test_agent_run_treats_preflight_api_errors_as_optional() -> None:
    """Transport/API failures from optional preflight should not block the paid run path."""
    from agentenv.api.client import APIError

    mock_client = _mock_client()
    run_success_response = Mock()
    run_success_response.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "done", "status": "completed"},
    }
    mock_client.post.side_effect = [
        APIError(
            status_code=404,
            message="not found",
            details={"error": {"code": "NOT_FOUND", "message": "not found"}},
        ),
        run_success_response,
    ]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0
    output = json.loads(result.output)
    assert output["requestId"] == "req_123"
    assert output["result"]["status"] == "completed"
    assert mock_client.post.call_count == 2


def test_agent_run_accepts_explicit_idempotency_key() -> None:
    """Automation callers can supply a stable idempotency key."""
    mock_client = _mock_client()

    preflight_response = Mock()
    preflight_response.json.return_value = {"eligible": True, "amountCents": 1000}
    run_success_response = Mock()
    run_success_response.json.return_value = {
        "requestId": "req_123",
        "result": {"output": "done", "status": "completed"},
    }
    mock_client.post.side_effect = [preflight_response, run_success_response]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_settings", return_value=_mock_settings()),
        patch("agentenv.cli.agent.get_client", return_value=mock_client),
    ):
        result = runner.invoke(
            app,
            [
                "agent", "run",
                "--workspace", "wk_123",
                "--billing-account-id", "ba_123",
                "--amount", "10",
                "--idempotency-key", "idem-fixed",
                "--json",
                "--", "run this agent",
            ],
        )

    assert result.exit_code == 0
    run_payload = mock_client.post.call_args_list[1].kwargs["json"]
    assert run_payload["idempotencyKey"] == "idem-fixed"


def test_agent_run_rejects_empty_prompt() -> None:
    """The CLI should reject missing prompt text before contacting the API."""
    result = runner.invoke(
        app,
        [
            "agent", "run",
            "--workspace", "wk_123",
            "--billing-account-id", "ba_123",
            "--amount", "10",
            "--json",
        ],
    )

    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error"] == {
        "code": "INVALID_ARGUMENT",
        "message": "Prompt is required.",
    }


def test_parse_amount_to_cents_rejects_non_positive_values() -> None:
    """Amounts must be finite and greater than zero."""
    with patch("agentenv.cli.agent._fail", side_effect=typer.Exit(1)) as fail:
        try:
            _parse_amount_to_cents("-1", json_output=True)
        except Exception:
            pass

    fail.assert_called_once_with(
        "Invalid amount: -1. Amount must be greater than 0.",
        json_output=True,
        code="INVALID_ARGUMENT",
    )


def test_validate_preflight_result_rejects_ineligible_payload() -> None:
    """Explicit ineligible preflight payloads should normalize to PREFLIGHT_FAILED."""
    with patch("agentenv.cli.agent._fail", side_effect=typer.Exit(1)) as fail:
        try:
            _validate_preflight_result(
                {"eligible": False, "message": "billing account not eligible"},
                json_output=True,
            )
        except Exception:
            pass

    fail.assert_called_once_with(
        "Preflight failed: billing account not eligible",
        json_output=True,
        code="PREFLIGHT_FAILED",
    )
