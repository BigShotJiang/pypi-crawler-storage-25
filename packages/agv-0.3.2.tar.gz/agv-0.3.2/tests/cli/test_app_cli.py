"""Tests for app CLI commands."""

from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.app import AppAPI
from agentenv.cli.app import app


runner = CliRunner()


def test_app_api_logs_formats_structured_entries() -> None:
    """AppAPI.logs should render structured entries consistently."""
    client = Mock()
    response = Mock()
    response.json.return_value = {
        "entries": [
            {
                "timestamp": "2026-04-01T10:00:00Z",
                "message": "boot complete",
                "logPath": "stdout",
            },
            {
                "message": "ready",
            },
        ]
    }
    client.get.return_value = response

    api = AppAPI(client)
    output = api.logs(
        "app-123",
        query="boot",
        limit=25,
        from_time="2026-04-01T09:59:00Z",
        to_time="2026-04-01T10:01:00Z",
        sort="asc",
        log_path="stdout",
    )

    assert output == "2026-04-01T10:00:00Z boot complete\nready"
    client.get.assert_called_once_with(
        "/v1/apps/app-123/logs",
        params={
            "q": "boot",
            "limit": 25,
            "from": "2026-04-01T09:59:00Z",
            "to": "2026-04-01T10:01:00Z",
            "sort": "asc",
            "logPath": "stdout",
        },
    )


def test_app_logs_follow_polls_incremental_entries(monkeypatch) -> None:
    """app logs --follow should poll incrementally and preserve filters."""
    with patch("agentenv.cli.app_cmd.get_client", return_value=Mock()):
        with patch("agentenv.cli.app_cmd.AppAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            responses = [
                {
                    "entries": [
                        {
                            "timestamp": "2026-04-01T10:00:00Z",
                            "message": "first",
                            "logPath": "stdout",
                        },
                        {
                            "timestamp": "2026-04-01T10:00:01Z",
                            "message": "second",
                            "logPath": "stdout",
                        },
                    ]
                },
                {
                    "entries": [
                        {
                            "timestamp": "2026-04-01T10:00:01Z",
                            "message": "second",
                            "logPath": "stdout",
                        },
                        {
                            "timestamp": "2026-04-01T10:00:02Z",
                            "message": "third",
                            "logPath": "stderr",
                        },
                    ]
                },
                KeyboardInterrupt(),
            ]

            def _fake_logs(*_args, **_kwargs):
                item = responses.pop(0)
                if isinstance(item, BaseException):
                    raise item
                return item

            mock_api.logs.side_effect = _fake_logs
            monkeypatch.setattr("agentenv.cli.app_cmd.time.sleep", lambda _seconds: None)

            result = runner.invoke(
                app,
                [
                    "app",
                    "logs",
                    "my-app",
                    "--follow",
                    "--query",
                    "error",
                    "--limit",
                    "50",
                    "--from",
                    "2026-04-01T09:59:59Z",
                    "--to",
                    "2026-04-01T10:30:00Z",
                    "--sort",
                    "asc",
                    "--log-path",
                    "stdout",
                ],
            )

    assert result.exit_code == 0
    assert result.output.strip().splitlines() == [
        "2026-04-01T10:00:00Z first",
        "2026-04-01T10:00:01Z second",
        "2026-04-01T10:00:02Z third",
    ]
    assert mock_api.logs.call_args_list[0].args == ("my-app",)
    assert mock_api.logs.call_args_list[0].kwargs == {
        "query": "error",
        "limit": 50,
        "from_time": "2026-04-01T09:59:59Z",
        "to_time": "2026-04-01T10:30:00Z",
        "sort": "asc",
        "log_path": "stdout",
        "raw": True,
    }
    assert mock_api.logs.call_args_list[1].kwargs == {
        "query": "error",
        "limit": 50,
        "from_time": "2026-04-01T10:00:01Z",
        "to_time": "2026-04-01T10:30:00Z",
        "sort": "asc",
        "log_path": "stdout",
        "raw": True,
    }


def test_app_logs_follow_rejects_json_output() -> None:
    """app logs --follow should reject incompatible JSON streaming mode."""
    result = runner.invoke(app, ["--json", "app", "logs", "my-app", "--follow"])

    assert result.exit_code == 1
    assert "--follow is not supported with --json" in result.output


def test_app_logs_follow_rejects_untimestamped_entries(monkeypatch) -> None:
    """app logs --follow should fail fast if the server cannot provide a cursor."""
    with patch("agentenv.cli.app_cmd.get_client", return_value=Mock()):
        with patch("agentenv.cli.app_cmd.AppAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.logs.return_value = {
                "entries": [
                    {
                        "message": "raw line without timestamp",
                        "logPath": "stdout",
                    }
                ]
            }
            monkeypatch.setattr("agentenv.cli.app_cmd.time.sleep", lambda _seconds: None)

            result = runner.invoke(app, ["app", "logs", "my-app", "--follow"])

    assert result.exit_code == 1
    assert "--follow requires timestamped log entries" in result.output
