"""Tests for AI Gateway CLI commands."""

import pytest
from typer.testing import CliRunner
from unittest.mock import Mock, patch

from agentenv.cli.app import app
from agentenv.cli.ai import get_api_client
from agentenv.api.models import APIError


runner = CliRunner()


class TestAICommands:
    """Test AI Gateway CLI commands."""

    @patch("agentenv.cli.ai.Client")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    @patch("agentenv.cli.ai.get_settings")
    def test_get_api_client_uses_access_token_when_api_key_missing(
        self,
        mock_get_settings,
        mock_api_class,
        mock_client_class,
    ):
        """AI management commands should authenticate with JWT when only a token is present."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = None
        mock_settings.access_token = "jwt_test"
        mock_get_settings.return_value = mock_settings

        client, api = get_api_client()

        mock_client_class.assert_called_once_with(
            base_url="http://test",
            api_key=None,
            access_token="jwt_test",
        )
        mock_api_class.assert_called_once()
        assert client == mock_client_class.return_value
        assert api == mock_api_class.return_value

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_list_upstreams(self, mock_api_class, mock_get_settings):
        """Test list upstreams command."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_settings.access_token = None
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.list_upstreams.return_value = []
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["ai", "upstreams", "list"])

        assert result.exit_code == 0
        mock_api.list_upstreams.assert_called_once()

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_chat_command(self, mock_api_class, mock_get_settings):
        """Test chat command."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        # Mock streaming response - needs to be iterable
        mock_chunk = Mock()
        mock_chunk.choices = [Mock(delta=Mock(content="Hello!"))]
        mock_api.chat.create.return_value = [mock_chunk]
        mock_api_class.return_value = mock_api

        with patch.dict("os.environ", {"AGENTENV_AI_KEY": "cr_test"}):
            result = runner.invoke(app, ["ai", "chat", "Hello"])

        assert result.exit_code == 0
        assert "Hello!" in result.output

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_test_upstream_uses_backend_message_and_latency(self, mock_api_class, mock_get_settings):
        """Test upstream test output matches backend response fields."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.test_upstream.return_value = {
            "success": True,
            "message": "Connection successful (42ms)",
            "latency": 42,
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["ai", "upstreams", "test", "up_123"])

        assert result.exit_code == 0
        assert "Connection successful (42ms)" in result.output
        assert "Latency: 42ms" in result.output

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_add_platform_pool_member(self, mock_api_class, mock_get_settings):
        """Test adding a platform model to a pool."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.add_pool_member.return_value = {
            "name": "Primary Pool",
            "members": [{"platformModelId": "openai/gpt-4o"}],
        }
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            ["ai", "pools", "add-member", "pool_123", "--platform-model", "openai/gpt-4o"],
        )

        assert result.exit_code == 0
        mock_api.add_pool_member.assert_called_once_with(
            "pool_123",
            upstream_id=None,
            priority=0,
            weight=1,
            source_type="platform",
            platform_model_id="openai/gpt-4o",
        )

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_usage_forwards_extended_filters(self, mock_api_class, mock_get_settings):
        """Test usage command forwards all supported filters."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.get_usage.return_value = Mock(
            total_requests=1,
            total_tokens=42,
            total_cost_usd=0.12,
            records=[],
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "ai",
                "usage",
                "--start-date",
                "2026-04-01",
                "--end-date",
                "2026-04-07",
                "--api-key-id",
                "key_123",
                "--upstream-id",
                "up_123",
                "--provider",
                "openai",
                "--model",
                "gpt-4o",
                "--limit",
                "5",
            ],
        )

        assert result.exit_code == 0
        mock_api.get_usage.assert_called_once_with(
            start_date="2026-04-01",
            end_date="2026-04-07",
            upstream_id="up_123",
            api_key_id="key_123",
            provider_type="openai",
            model="gpt-4o",
            limit=5,
        )

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_models_fallback_only_for_unsupported_endpoint(self, mock_api_class, mock_get_settings):
        """Test models fallback for older servers without the endpoint."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.list_platform_models.side_effect = APIError(404, "Not found")
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["ai", "models", "--provider", "openai"])

        assert result.exit_code == 0
        assert "gpt-4o" in result.output
        assert "falling back to the built-in" in result.output.lower()

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_models_auth_error_exits_instead_of_fallback(self, mock_api_class, mock_get_settings):
        """Test models command does not hide real API failures."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.list_platform_models.side_effect = APIError(401, "Unauthorized")
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["ai", "models"])

        assert result.exit_code == 1
        assert "Failed to list models: Unauthorized" in result.output
