"""Tests for billing CLI commands."""

import json
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.models import UserProfile, WorkspaceDetail
from agentenv.cli.app import app

runner = CliRunner()


def _settings(*, authenticated: bool = True, workspace: str | None = "wk_123") -> Mock:
    settings = Mock()
    settings.api_url = "http://test"
    settings.api_key = None
    settings.access_token = "access-token" if authenticated else None
    settings.refresh_token = None
    settings.workspace = workspace
    settings.json_output = False
    settings.is_authenticated.return_value = authenticated
    return settings


def test_billing_account_ls_json_lists_owned_accounts() -> None:
    """billing account ls --json should print owned billing accounts."""
    settings = _settings()
    accounts = [
        {
            "id": "ba_123",
            "ownerId": "user_123",
            "name": "Primary Billing",
            "balanceCents": 5000,
            "totalChargedCents": 2000,
            "billingEnabled": True,
            "creditLimitCents": 0,
            "isDefault": True,
            "createdAt": "2026-03-30T12:00:00Z",
            "updatedAt": "2026-03-30T12:00:00Z",
        }
    ]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.BillingAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.list_billing_accounts.return_value = accounts

        result = runner.invoke(app, ["billing", "account", "ls", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload[0]["id"] == "ba_123"
    assert payload[0]["balanceCents"] == 5000


def test_billing_account_get_json_returns_single_account() -> None:
    """billing account get --json should print a single owned account."""
    settings = _settings()
    account = {
        "id": "ba_123",
        "ownerId": "user_123",
        "name": "Primary Billing",
        "balanceCents": 5000,
        "totalChargedCents": 2000,
        "billingEnabled": True,
        "creditLimitCents": 0,
        "isDefault": True,
        "createdAt": "2026-03-30T12:00:00Z",
        "updatedAt": "2026-03-30T12:00:00Z",
    }

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.BillingAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_billing_account.return_value = account

        result = runner.invoke(app, ["billing", "account", "get", "ba_123", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["id"] == "ba_123"
    assert payload["billingEnabled"] is True


def test_billing_account_balance_json_returns_balance() -> None:
    """billing account balance --json should print the owned account balance."""
    settings = _settings()

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.BillingAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_billing_account_balance.return_value = Mock(
            model_dump=Mock(
                return_value={
                    "billingAccountId": "ba_123",
                    "balanceCents": 5000,
                    "totalChargedCents": 2000,
                    "billingEnabled": True,
                }
            )
        )

        result = runner.invoke(app, ["billing", "account", "balance", "ba_123", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["billingAccountId"] == "ba_123"
    assert payload["balanceCents"] == 5000


def test_billing_account_history_json_returns_transactions_with_metadata() -> None:
    """billing account history --json should print transactions plus pagination metadata."""
    settings = _settings()
    transaction = Mock()
    transaction.model_dump.return_value = {
        "id": "txn_123",
        "workspaceId": "wk_123",
        "billingAccountId": "ba_123",
        "type": "credit",
        "status": "completed",
        "amountCents": 1000,
        "balanceAfterCents": 5000,
        "description": "mpp top-up",
        "metadata": {"provider": "stripe_mpp"},
        "createdAt": "2026-03-30T12:00:00Z",
    }

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.BillingAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_billing_account_transactions.return_value = {
            "transactions": [transaction],
            "total": 12,
            "page": 2,
            "limit": 10,
        }

        result = runner.invoke(
            app,
            [
                "billing",
                "account",
                "history",
                "ba_123",
                "--page",
                "2",
                "--limit",
                "10",
                "--start-date",
                "2026-03-01",
                "--end-date",
                "2026-03-31",
                "--include-type",
                "credit",
                "--exclude-type",
                "usage",
                "--json",
            ],
        )

    assert result.exit_code == 0
    mock_api_cls.return_value.get_billing_account_transactions.assert_called_once_with(
        "ba_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )
    payload = json.loads(result.output)
    assert payload["total"] == 12
    assert payload["page"] == 2
    assert payload["limit"] == 10
    assert payload["transactions"][0]["billingAccountId"] == "ba_123"


def test_billing_history_json_returns_transactions_with_metadata() -> None:
    """billing history --json should print workspace transactions plus pagination metadata."""
    settings = _settings()
    transaction = Mock()
    transaction.model_dump.return_value = {
        "id": "txn_123",
        "workspaceId": "wk_123",
        "billingAccountId": "ba_123",
        "type": "credit",
        "status": "completed",
        "amountCents": 1000,
        "balanceAfterCents": 5000,
        "description": "mpp top-up",
        "metadata": {"provider": "stripe_mpp"},
        "createdAt": "2026-03-30T12:00:00Z",
    }

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.BillingAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.get_transactions.return_value = {
            "transactions": [transaction],
            "total": 12,
            "page": 2,
            "limit": 10,
        }

        result = runner.invoke(
            app,
            [
                "billing",
                "history",
                "--page",
                "2",
                "--limit",
                "10",
                "--start-date",
                "2026-03-01",
                "--end-date",
                "2026-03-31",
                "--include-type",
                "credit",
                "--exclude-type",
                "usage",
                "--json",
            ],
        )

    assert result.exit_code == 0
    mock_api_cls.return_value.get_transactions.assert_called_once_with(
        "wk_123",
        page=2,
        limit=10,
        start_date="2026-03-01",
        end_date="2026-03-31",
        include_types=["credit"],
        exclude_types=["usage"],
    )
    payload = json.loads(result.output)
    assert payload["total"] == 12
    assert payload["page"] == 2
    assert payload["limit"] == 10
    assert payload["transactions"][0]["billingAccountId"] == "ba_123"


def test_billing_whoami_json_aggregates_profile_workspace_and_accounts() -> None:
    """billing whoami --json should aggregate auth, workspace, and billing account context."""
    settings = _settings()
    profile = UserProfile(
        userId="user_123",
        email="owner@example.com",
        username="owner",
        selectedWorkspaceId="wk_123",
    )
    workspace = WorkspaceDetail(
        id="wk_123",
        name="Billing Workspace",
        ownerId="user_123",
        defaultBillingAccountId="ba_123",
        createdAt="2026-03-30T12:00:00Z",
        members=[],
    )
    accounts = [
        {
            "id": "ba_123",
            "ownerId": "user_123",
            "name": "Primary Billing",
            "balanceCents": 5000,
            "totalChargedCents": 2000,
            "billingEnabled": True,
            "creditLimitCents": 0,
            "isDefault": True,
            "createdAt": "2026-03-30T12:00:00Z",
            "updatedAt": "2026-03-30T12:00:00Z",
        }
    ]

    with (
        patch("agentenv.cli.billing.get_settings", return_value=settings),
        patch("agentenv.cli.billing.get_client", return_value=Mock()),
        patch("agentenv.cli.billing.AuthAPI") as mock_auth_api_cls,
        patch("agentenv.cli.billing.WorkspaceAPI") as mock_workspace_api_cls,
        patch("agentenv.cli.billing.BillingAPI") as mock_billing_api_cls,
    ):
        mock_auth_api_cls.return_value.get_profile.return_value = profile
        mock_workspace_api_cls.return_value.get.return_value = workspace
        mock_billing_api_cls.return_value.list_billing_accounts.return_value = accounts

        result = runner.invoke(app, ["billing", "whoami", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["user"]["userId"] == "user_123"
    assert payload["workspace"]["id"] == "wk_123"
    assert payload["workspace"]["defaultBillingAccountId"] == "ba_123"
    assert payload["billingAccounts"][0]["id"] == "ba_123"


def test_billing_account_ls_json_requires_authentication() -> None:
    """billing account ls --json should emit a structured auth error."""
    settings = _settings(authenticated=False)

    with patch("agentenv.cli.billing.get_settings", return_value=settings):
        result = runner.invoke(app, ["billing", "account", "ls", "--json"])

    assert result.exit_code == 1
    payload = json.loads(result.output)
    assert payload["error"]["code"] == "AUTH_REQUIRED"


def test_legacy_mpp_subcommand_removed() -> None:
    """billing mpp subcommand should no longer exist."""
    settings = _settings()

    with patch("agentenv.cli.billing.get_settings", return_value=settings):
        result = runner.invoke(app, ["billing", "mpp", "--help"])

    assert result.exit_code != 0
