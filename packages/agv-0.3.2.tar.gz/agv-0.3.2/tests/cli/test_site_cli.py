"""Tests for site CLI commands."""

from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.client import APIError
from agentenv.cli.app import app


runner = CliRunner()


def test_site_inspect_reports_resolve_api_errors() -> None:
    """site inspect should turn resolve API errors into a user-facing CLI failure."""
    with patch("agentenv.cli.site.get_client", return_value=Mock()):
        with patch("agentenv.cli.site.SiteAPI") as mock_api_cls:
            mock_api_cls.return_value.resolve.side_effect = APIError(
                status_code=500,
                message="backend unavailable",
            )

            result = runner.invoke(app, ["site", "inspect", "site-123"])

    assert result.exit_code == 1
    assert "Failed to resolve site: backend unavailable" in result.output


def test_site_update_requires_at_least_one_field() -> None:
    """site update should reject empty updates before calling the API."""
    result = runner.invoke(app, ["site", "update", "site-123"])

    assert result.exit_code == 1
    assert "Provide at least one update field" in result.output
