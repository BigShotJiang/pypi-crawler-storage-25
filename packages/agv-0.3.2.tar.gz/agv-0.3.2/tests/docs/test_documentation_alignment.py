"""Regression tests for the canonical internal docs surface."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
RUNNER_SCRIPT = REPO_ROOT / "scripts/agentflow/docs_alignment/run_docs_alignment.py"


def _load_runner_module():
    spec = importlib.util.spec_from_file_location("run_docs_alignment", RUNNER_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


runner = _load_runner_module()
DOCS_SURFACE_FILES = [
    *(REPO_ROOT / path for path in runner.CANONICAL_DOC_FILES),
    *(REPO_ROOT / path for path in runner.PRESERVED_NOTEBOOK_FILES),
]


@pytest.mark.parametrize("path", DOCS_SURFACE_FILES, ids=lambda path: str(path.relative_to(REPO_ROOT)))
def test_canonical_and_preserved_docs_exist(path: Path) -> None:
    assert path.is_file(), f"missing docs surface file: {path.relative_to(REPO_ROOT)}"


def test_verify_docs_surface_passes_for_repo(tmp_path: Path) -> None:
    report = runner.verify_docs_surface(
        monorepo_path=REPO_ROOT,
        reports_dir=tmp_path / "docs-alignment-verify",
    )

    assert report["status"] == "passed"
    assert report["missing_canonical_files"] == []
    assert report["missing_preserved_notebook_files"] == []
    assert report["unexpected_legacy_paths"] == []
    assert report["unexpected_legacy_directories"] == []
    assert report["unexpected_legacy_files"] == []
    assert report["placeholder_hits"] == []


def test_docs_root_references_canonical_modules() -> None:
    text = (REPO_ROOT / "docs/README.md").read_text(encoding="utf-8")

    for snippet in (
        "clients",
        "api-server",
        "control-plane",
        "compute-plane",
        "workflow",
        "operations",
        "notebook",
        "architecture.md",
    ):
        assert snippet in text
