"""Tests for mintlify-alignment deterministic inventory seeding."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
PLAN_SCRIPT = REPO_ROOT / "scripts/agentflow/mintlify_alignment/mintlify_alignment_plan.py"
PIPELINE_SCRIPT = REPO_ROOT / "scripts/agentflow/mintlify_alignment/mintlify_alignment_pipeline.py"
RUNNER_SCRIPT = REPO_ROOT / "scripts/agentflow/mintlify_alignment/run_mintlify_alignment.py"


def _load_plan_module():
    spec = importlib.util.spec_from_file_location("mintlify_alignment_plan", PLAN_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def _load_pipeline_module():
    spec = importlib.util.spec_from_file_location("mintlify_alignment_pipeline", PIPELINE_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def _load_runner_module():
    spec = importlib.util.spec_from_file_location("run_mintlify_alignment", RUNNER_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def test_build_deterministic_plan_exposes_expected_modules() -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    module_ids = [module["id"] for module in deterministic_plan["modules"]]

    assert plan.PLAN_ROOT == Path(".agentflow/mintlify-alignment/plan")
    assert plan.ROUTER_SKILL_DIR == plan.PLAN_ROOT / "runtime-skills" / "repo-skill-router"
    assert plan.ROUTER_SKILL_REF == str(plan.ROUTER_SKILL_DIR)
    assert deterministic_plan["generated_from"] == "."
    assert module_ids == [
        "getting-started-auth",
        "runtime-workloads",
        "workspace-resources",
        "deploy-infrastructure",
        "automation-operations",
        "api-reference",
        "final-surface",
    ]

    modules = {module["id"]: module for module in deterministic_plan["modules"]}
    assert modules["final-surface"]["canonical_targets"] == [
        "mintlify_docs/docs.json",
        "mintlify_docs/llms.txt",
        "mintlify_docs/README.md",
    ]

    api_reference_targets = modules["api-reference"]["canonical_targets"]
    assert "mintlify_docs/api-reference/introduction.mdx" in api_reference_targets
    assert "mintlify_docs/api-reference/openapi.json" in api_reference_targets
    assert "mintlify_docs/api/auth/login.mdx" in api_reference_targets
    assert "mintlify_docs/api/sandboxes/create.mdx" in api_reference_targets

    inventory_entries = deterministic_plan["inventory"]
    maintained_mdx_paths = [
        entry["path"]
        for entry in inventory_entries
        if entry["path"].endswith(".mdx") and entry["maintained"]
    ]
    assert maintained_mdx_paths
    assert len(maintained_mdx_paths) == len(set(maintained_mdx_paths))
    assert all(
        isinstance(entry["module_id"], str) and entry["module_id"]
        for entry in inventory_entries
        if entry["path"] in maintained_mdx_paths
    )


def test_navigation_and_operation_page_extraction() -> None:
    plan = _load_plan_module()

    payload = plan.build_deterministic_plan(REPO_ROOT)
    mintlify_inventory = payload["mintlify_inventory"]

    navigation_pages = mintlify_inventory["navigation_pages"]
    navigation_page_map = mintlify_inventory["navigation_page_map"]
    operation_pages = mintlify_inventory["operation_pages"]

    assert "mintlify_docs/index.mdx" in navigation_pages
    assert "mintlify_docs/authentication.mdx" in navigation_pages
    assert "mintlify_docs/api-reference/introduction.mdx" in navigation_pages
    assert "mintlify_docs/api/sandboxes/overview.mdx" in navigation_pages

    assert navigation_page_map["api/auth/overview"] == "mintlify_docs/api/auth/overview.mdx"
    assert {
        "path": "mintlify_docs/api/browser/create-session.mdx",
        "openapi": "POST /browser/sessions",
    } in operation_pages

    operation_paths = {item["path"] for item in operation_pages}
    assert "mintlify_docs/api/sandboxes/create.mdx" in operation_paths
    assert "mintlify_docs/api/sandboxes/exec.mdx" in operation_paths
    assert "mintlify_docs/api/auth/login.mdx" in operation_paths
    assert "mintlify_docs/api-reference/introduction.mdx" not in operation_paths

    kinds = {entry["kind"] for entry in payload["inventory"]}
    assert {"page", "operation_page", "config", "schema", "index", "asset"} <= kinds

    openapi_path = REPO_ROOT / "mintlify_docs/api-reference/openapi.json"
    expected_hash = hashlib.sha256(openapi_path.read_bytes()).hexdigest()
    assert payload["openapi"] == {
        "path": "mintlify_docs/api-reference/openapi.json",
        "sha256": expected_hash,
        "export_command": "cd api-server && npm run docs:mintlify:openapi",
    }


def test_inventory_assigns_introduction_to_api_reference() -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    inventory = {entry["path"]: entry for entry in deterministic_plan["inventory"]}
    intro = inventory["mintlify_docs/api-reference/introduction.mdx"]

    assert intro["maintained"] is True
    assert intro["module_id"] == "api-reference"


def test_build_deterministic_plan_exposes_api_reference_contract_metadata() -> None:
    plan = _load_plan_module()

    payload = plan.build_deterministic_plan(REPO_ROOT)

    assert payload["api_reference_contract"]["path"] == "mintlify_docs/api-reference/operation-contract.json"
    assert payload["api_reference_contract"]["entries"]
    assert payload["api_reference_alignment"]["coverage_rows"]
    assert payload["public_doc_operations"]
    public_ops = {item["openapi"] for item in payload["public_doc_operations"]}
    assert "POST /auth/login" in public_ops
    assert "POST /sandboxes" in public_ops
    assert "GET /workflows" in public_ops
    sandbox_create = next(
        item
        for item in payload["api_reference_contract"]["entries"]
        if item["page_path"] == "mintlify_docs/api/sandboxes/create.mdx"
    )
    assert sandbox_create["cli"]["command_path"] == ["sandbox", "create"]
    assert sandbox_create["cli"]["mapping_kind"] == "exact"


def test_build_deterministic_plan_exposes_public_operation_audit() -> None:
    plan = _load_plan_module()

    payload = plan.build_deterministic_plan(REPO_ROOT)
    audit = payload["public_operation_audit"]

    assert audit["total_public_operations"] >= 200
    assert audit["total_public_operations"] == len(payload["public_doc_operations"])
    assert "notebooks" in audit["resource_breakdown"]
    assert audit["contract_operation_count"] == len(payload["api_reference_contract"]["entries"])
    assert audit["uncovered_count"] == len(audit["uncovered_public_operations"])
    assert sum(audit["resource_breakdown"].values()) == audit["total_public_operations"]


def test_render_operation_page_includes_api_cli_and_sdk_sections() -> None:
    plan = _load_plan_module()
    entry = {
        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
        "title": "Create Sandbox",
        "icon": "PlusCircle",
        "openapi": "POST /sandboxes",
        "summary": "Create a sandbox.",
        "api": {
            "source": "api-reference/openapi.json",
            "method": "POST",
            "path": "/sandboxes",
            "parameters": [],
            "request_fields": [
                {"name": "image", "type": "string", "required": True},
                {"name": "workspaceId", "type": "string", "required": True},
            ],
            "responses": [
                {"status": "201", "description": "Created"},
            ],
        },
        "cli": {
            "support": "supported",
            "mapping_kind": "exact",
            "command_path": ["sandbox", "create"],
            "commands": ["agv sandbox create --image python:3.11 --cpu 2000 --memory 4096"],
            "example": "agv sandbox create --image python:3.11 --cpu 2000 --memory 4096",
            "notes": ["Use agv run for one-shot sandbox creation."],
        },
        "sdk": {
            "support": "supported",
            "symbols": ["Client.sandbox.create"],
            "example": 'client.sandbox.create(image="python:3.11")',
            "notes": ["Prefer Client.sandbox.create() for provisioning."],
        },
        "notes": [],
    }

    rendered = plan.render_operation_page(entry)

    assert "## API" in rendered
    assert "POST /sandboxes" in rendered
    assert "api-reference/openapi.json" in rendered
    assert "## CLI" in rendered
    assert "## Python SDK" in rendered
    assert "agv sandbox create --image python:3.11 --cpu 2000 --memory 4096" in rendered
    assert 'client.sandbox.create(image="python:3.11")' in rendered


def test_inventory_assigns_api_overview_pages_to_expected_domain_modules() -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    inventory = {entry["path"]: entry for entry in deterministic_plan["inventory"]}

    expected = {
        "mintlify_docs/api/auth/overview.mdx": "getting-started-auth",
        "mintlify_docs/api/sandboxes/overview.mdx": "runtime-workloads",
        "mintlify_docs/api/snapshots/overview.mdx": "runtime-workloads",
        "mintlify_docs/api/browser/overview.mdx": "runtime-workloads",
        "mintlify_docs/api/notebooks/overview.mdx": "runtime-workloads",
        "mintlify_docs/api/workspaces/overview.mdx": "workspace-resources",
        "mintlify_docs/api/billing-accounts/overview.mdx": "workspace-resources",
        "mintlify_docs/api/files/overview.mdx": "workspace-resources",
        "mintlify_docs/api/apps/overview.mdx": "deploy-infrastructure",
        "mintlify_docs/api/sites/overview.mdx": "deploy-infrastructure",
        "mintlify_docs/api/clusters/overview.mdx": "deploy-infrastructure",
        "mintlify_docs/api/images/overview.mdx": "deploy-infrastructure",
        "mintlify_docs/api/ai-gateway/overview.mdx": "automation-operations",
        "mintlify_docs/api/workflows/overview.mdx": "automation-operations",
        "mintlify_docs/api/analytics/overview.mdx": "automation-operations",
        "mintlify_docs/api/browser-profiles/overview.mdx": "automation-operations",
        "mintlify_docs/api/captcha/overview.mdx": "automation-operations",
        "mintlify_docs/api/proxy/overview.mdx": "automation-operations",
        "mintlify_docs/api/managed-agents/overview.mdx": "automation-operations",
        "mintlify_docs/api/webhooks/overview.mdx": "automation-operations",
    }

    for path, module_id in expected.items():
        assert inventory[path]["maintained"] is True
        assert inventory[path]["module_id"] == module_id


def test_inventory_assigns_maintained_non_mdx_paths_to_expected_modules() -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    inventory = {entry["path"]: entry for entry in deterministic_plan["inventory"]}

    expected = {
        "mintlify_docs/docs.json": "final-surface",
        "mintlify_docs/llms.txt": "final-surface",
        "mintlify_docs/README.md": "final-surface",
        "mintlify_docs/api-reference/openapi.json": "api-reference",
    }

    for path, module_id in expected.items():
        assert inventory[path]["maintained"] is True
        assert inventory[path]["module_id"] == module_id


def test_public_operation_page_path_derivation_is_stable() -> None:
    plan = _load_plan_module()

    assert plan.derive_operation_page_path("GET /sandboxes") == "mintlify_docs/api/sandboxes/list-sandboxes.mdx"
    assert plan.derive_operation_page_path("DELETE /apps/{idOrSlug}/versions/{version}") == (
        "mintlify_docs/api/apps/delete-app-version.mdx"
    )
    assert plan.derive_operation_page_path("GET /workflows/{id}/executions/{executionId}") == (
        "mintlify_docs/api/workflows/get-workflow-execution.mdx"
    )


def test_public_operation_title_uses_summary_or_falls_back_to_method_and_resource() -> None:
    plan = _load_plan_module()

    assert plan.derive_operation_title("POST /sandboxes", "Create sandbox") == "Create sandbox"
    assert plan.derive_operation_title("DELETE /workflows/{id}", "") == "Delete Workflow"


def test_extract_public_doc_operation_items_expands_grouped_methods(tmp_path: Path) -> None:
    plan = _load_plan_module()

    (tmp_path / "mintlify_docs/api/workflows").mkdir(parents=True, exist_ok=True)
    (tmp_path / "mintlify_docs/api-reference").mkdir(parents=True, exist_ok=True)
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/workflows": {
                        "get": {
                            "summary": "List workflows",
                            "responses": {"200": {"description": "OK"}},
                        },
                        "post": {
                            "summary": "Create workflow",
                            "responses": {"201": {"description": "Created"}},
                        },
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api/workflows/overview.mdx").write_text(
        (
            "---\n"
            "title: Workflows Overview\n"
            "---\n\n"
            "Use `GET/POST /workflows` to list or create workflows.\n"
        ),
        encoding="utf-8",
    )

    items = plan.extract_public_doc_operation_items(tmp_path)
    operations = {item["openapi"] for item in items}

    assert "GET /workflows" in operations
    assert "POST /workflows" in operations


def test_extract_public_doc_operation_items_expands_grouped_search_methods(tmp_path: Path) -> None:
    plan = _load_plan_module()

    (tmp_path / "mintlify_docs/api/webhooks").mkdir(parents=True, exist_ok=True)
    (tmp_path / "mintlify_docs/api-reference").mkdir(parents=True, exist_ok=True)
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/webhooks/{id}/deliveries": {
                        "get": {
                            "summary": "List webhook deliveries",
                            "responses": {"200": {"description": "OK"}},
                        },
                        "search": {
                            "summary": "Search webhook deliveries",
                            "responses": {"200": {"description": "OK"}},
                        },
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api/webhooks/overview.mdx").write_text(
        (
            "---\n"
            "title: Webhooks Overview\n"
            "---\n\n"
            "Use `GET/SEARCH /webhooks/{id}/deliveries` to inspect or search deliveries.\n"
        ),
        encoding="utf-8",
    )

    items = plan.extract_public_doc_operation_items(tmp_path)
    operations = {item["openapi"] for item in items}

    assert "GET /webhooks/{id}/deliveries" in operations
    assert "SEARCH /webhooks/{id}/deliveries" in operations


def test_build_deterministic_plan_excludes_public_operations_from_uncovered_audit(tmp_path: Path) -> None:
    plan = _load_plan_module()

    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/docs.json").write_text(
        json.dumps(
            {
                "navigation": {
                    "tabs": [
                        {
                            "tab": "API Reference",
                            "groups": [
                                {
                                    "group": "Core",
                                    "pages": [
                                        "api/sandboxes/overview",
                                        "api/sandboxes/create",
                                    ],
                                }
                            ],
                        }
                    ]
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/sandboxes": {
                        "post": {
                            "summary": "Create sandbox",
                            "requestBody": {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/CreateSandboxRequest"}
                                    }
                                },
                            },
                            "responses": {"201": {"description": "Created"}},
                        }
                    },
                    "/sandboxes/{id}": {
                        "get": {
                            "summary": "Get sandbox",
                            "parameters": [
                                {
                                    "name": "id",
                                    "in": "path",
                                    "required": True,
                                    "schema": {"type": "string"},
                                }
                            ],
                            "responses": {"200": {"description": "Sandbox"}},
                        }
                    },
                },
                "components": {
                    "schemas": {
                        "CreateSandboxRequest": {
                            "type": "object",
                            "required": ["image", "workspaceId"],
                            "properties": {
                                "image": {"type": "string"},
                                "workspaceId": {"type": "string"},
                            },
                        }
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": "POST /sandboxes",
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "sdk": {
                            "support": "supported",
                            "symbols": ["Client.sandbox.create"],
                            "example": 'client.sandbox.create(image="python:3.11")',
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ],
                "excluded_public_operations": [
                    {
                        "openapi": "GET /sandboxes/{id}",
                        "reason": "Documented for discovery, intentionally excluded from contract pages.",
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api/sandboxes/overview.mdx").write_text(
        (
            "---\n"
            "title: Sandboxes Overview\n"
            "---\n\n"
            "Use `POST /sandboxes` to create a sandbox.\n\n"
            "Use `GET /sandboxes/{id}` to inspect an existing sandbox.\n"
        ),
        encoding="utf-8",
    )

    payload = plan.build_deterministic_plan(tmp_path)
    audit = payload["public_operation_audit"]

    assert audit["excluded_count"] == 1
    assert audit["excluded_public_operations"] == [
        {
            "openapi": "GET /sandboxes/{id}",
            "reason": "Documented for discovery, intentionally excluded from contract pages.",
        }
    ]
    assert "GET /sandboxes/{id}" not in audit["uncovered_public_operations"]


def test_unknown_api_overview_page_fails_fast() -> None:
    plan = _load_plan_module()

    with pytest.raises(SystemExit, match="missing module assignment"):
        plan._assign_page_module("mintlify_docs/api/new-surface/overview.mdx")


def test_maintained_paths_have_frozen_owner_and_exactly_one_module_write_scope_claim() -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    modules = deterministic_plan["modules"]
    maintained_entries = [
        entry
        for entry in deterministic_plan["inventory"]
        if entry["maintained"]
    ]

    assert maintained_entries
    claim_counts = {entry["path"]: 0 for entry in maintained_entries}
    for module in modules:
        for path in module["write_scope"]:
            if path in claim_counts:
                claim_counts[path] += 1

    assert all(
        isinstance(entry["module_id"], str) and entry["module_id"] in plan.FROZEN_MODULE_IDS
        for entry in maintained_entries
    )
    assert all(count == 1 for count in claim_counts.values())


def test_write_plan_seed_artifacts_materializes_inventory_and_router_skill() -> None:
    plan = _load_plan_module()

    plan_dir = REPO_ROOT / ".agentflow/mintlify-alignment/plan-test-artifacts"
    shutil.rmtree(plan_dir, ignore_errors=True)
    artifacts = plan.write_plan_seed_artifacts(REPO_ROOT, plan_dir=plan_dir)

    inventory_path = artifacts["inventory_path"]
    skill_catalog_path = artifacts["skill_catalog_path"]
    router_skill_path = artifacts["router_skill_path"]

    assert inventory_path == plan_dir / "inventory.json"
    assert skill_catalog_path == plan_dir / "repo_skill_catalog.md"
    assert router_skill_path == plan_dir / "runtime-skills/repo-skill-router/SKILL.md"
    assert inventory_path.exists()
    assert skill_catalog_path.exists()
    assert router_skill_path.exists()

    payload = json.loads(inventory_path.read_text(encoding="utf-8"))
    assert payload["generated_from"] == "."
    module_ids = [module["id"] for module in payload["modules"]]
    assert module_ids == [
        "getting-started-auth",
        "runtime-workloads",
        "workspace-resources",
        "deploy-infrastructure",
        "automation-operations",
        "api-reference",
        "final-surface",
    ]
    assert payload["router_skill_ref"] == ".agentflow/mintlify-alignment/plan-test-artifacts/runtime-skills/repo-skill-router"

    catalog_text = skill_catalog_path.read_text(encoding="utf-8")
    assert catalog_text.startswith("# Repo Skill Catalog")
    router_skill_text = router_skill_path.read_text(encoding="utf-8")
    assert "repo-skill-router" in router_skill_text
    assert "repo_skill_catalog.md" in router_skill_text
    shutil.rmtree(plan_dir, ignore_errors=True)


def test_merge_plan_decisions_preserves_api_reference_write_scope() -> None:
    plan = _load_plan_module()
    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)
    deterministic_modules = {module["id"]: module for module in deterministic_plan["modules"]}
    deterministic_modules["api-reference"]["write_scope"] = [
        "mintlify_docs/api-reference/introduction.mdx",
        "mintlify_docs/api-reference/openapi.json",
        "mintlify_docs/api-reference/openapi.json",
    ]
    expected_write_scope = list(deterministic_modules["api-reference"]["write_scope"])

    frozen_plan = plan.merge_plan_decisions(
        deterministic_plan,
        {
            "module_decisions": [
                {"id": "api-reference", "enabled": True},
                {"id": "final-surface", "enabled": True},
            ]
        },
    )
    modules = {module["id"]: module for module in frozen_plan["modules"]}
    assert modules["api-reference"]["write_scope"] == expected_write_scope


def test_merge_plan_decisions_rejects_unknown_module_decision_ids() -> None:
    plan = _load_plan_module()
    deterministic_plan = plan.build_deterministic_plan(REPO_ROOT)

    with pytest.raises(SystemExit, match="unknown module id"):
        plan.merge_plan_decisions(
            deterministic_plan,
            {
                "module_decisions": [
                    {"id": "api-reference", "enabled": True},
                    {"id": "final-surface", "enabled": True},
                    {"id": "not-a-real-module", "enabled": True},
                ]
            },
        )


def test_build_module_pipeline_json_renders_expected_node_ids(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "router_skill_ref": ".agentflow/mintlify-alignment/plan/runtime-skills/repo-skill-router",
                "modules": [
                    {
                        "id": "api-reference",
                        "enabled": True,
                        "canonical_targets": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api/auth/login.mdx",
                        ],
                        "write_scope": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api/auth/login.mdx",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-api-reference"],
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    rendered = pipeline.build_module_pipeline_json(
        monorepo_path=tmp_path,
        plan_path=plan_path,
        module_id="api-reference",
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )
    payload = json.loads(rendered)
    node_ids = {node["id"] for node in payload["nodes"]}
    assert node_ids == {
        "review_scope",
        "align_module",
        "implementation_review",
        "verify_module",
        "final_summary",
    }
    implementation_review = next(node for node in payload["nodes"] if node["id"] == "implementation_review")
    assert implementation_review["success_criteria"] == [
        {"kind": "output_contains", "value": "MINTLIFY_ALIGNMENT_REVIEW_APPROVED"}
    ]


def test_build_module_pipeline_json_mentions_api_cli_sdk_alignment(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "router_skill_ref": ".agentflow/mintlify-alignment/plan/runtime-skills/repo-skill-router",
                "modules": [
                    {
                        "id": "api-reference",
                        "enabled": True,
                        "canonical_targets": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api-reference/operation-contract.json",
                            "mintlify_docs/api/sandboxes/create.mdx",
                        ],
                        "write_scope": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api-reference/operation-contract.json",
                            "mintlify_docs/api/sandboxes/create.mdx",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-api-reference"],
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    rendered = pipeline.build_module_pipeline_json(
        monorepo_path=tmp_path,
        plan_path=plan_path,
        module_id="api-reference",
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )

    assert "API / CLI / SDK" in rendered
    assert "operation-contract.json" in rendered
    assert "Do not run repo-wide searches" in rendered


def test_build_module_pipeline_json_rejects_duplicate_module_ids(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "router_skill_ref": ".agentflow/mintlify-alignment/plan/runtime-skills/repo-skill-router",
                "modules": [
                    {
                        "id": "api-reference",
                        "enabled": True,
                        "canonical_targets": ["mintlify_docs/api-reference/introduction.mdx"],
                        "write_scope": ["mintlify_docs/api-reference/introduction.mdx"],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-api-reference-a"],
                    },
                    {
                        "id": "api-reference",
                        "enabled": True,
                        "canonical_targets": ["mintlify_docs/api-reference/openapi.json"],
                        "write_scope": ["mintlify_docs/api-reference/openapi.json"],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-api-reference-b"],
                    },
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    with pytest.raises(SystemExit, match="duplicate module id"):
        pipeline.build_module_pipeline_json(
            monorepo_path=tmp_path,
            plan_path=plan_path,
            module_id="api-reference",
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )


def test_module_pipeline_payload_contains_required_five_node_names(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "router_skill_ref": ".agentflow/mintlify-alignment/plan/runtime-skills/repo-skill-router",
                "modules": [
                    {
                        "id": "final-surface",
                        "enabled": True,
                        "canonical_targets": [
                            "mintlify_docs/docs.json",
                            "mintlify_docs/llms.txt",
                            "mintlify_docs/README.md",
                        ],
                        "write_scope": [
                            "mintlify_docs/docs.json",
                            "mintlify_docs/llms.txt",
                            "mintlify_docs/README.md",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-final-surface"],
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    rendered = pipeline.build_module_pipeline_json(
        monorepo_path=tmp_path,
        plan_path=plan_path,
        module_id="final-surface",
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )
    payload = json.loads(rendered)
    node_names = {node["id"] for node in payload["nodes"]}
    assert "review_scope" in node_names
    assert "align_module" in node_names
    assert "implementation_review" in node_names
    assert "verify_module" in node_names
    assert "final_summary" in node_names


def _stub_openapi_export(monkeypatch: pytest.MonkeyPatch, runner, monorepo_path: Path) -> None:
    def _fake_run_command(argv, *, cwd, env, logs_dir, log_name, check=True):
        output_path = Path(argv[-1]).expanduser().resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(monorepo_path / "mintlify_docs/api-reference/openapi.json", output_path)
        logs_dir.mkdir(parents=True, exist_ok=True)
        stdout_log = logs_dir / f"{log_name}.stdout.log"
        stderr_log = logs_dir / f"{log_name}.stderr.log"
        stdout_log.write_text("stubbed export\n", encoding="utf-8")
        stderr_log.write_text("", encoding="utf-8")
        return runner.CommandResult(
            argv=list(argv),
            returncode=0,
            stdout="stubbed export\n",
            stderr="",
            stdout_log=stdout_log,
            stderr_log=stderr_log,
        )

    monkeypatch.setattr(runner, "_run_command", _fake_run_command)


def _write_minimal_mintlify_fixture(monorepo_path: Path, *, openapi_binding: str) -> None:
    normalized_binding = " ".join(openapi_binding.strip().split())
    method, _, path = normalized_binding.partition(" ")
    normalized_binding = f"{method.upper()} {path}".strip()
    (monorepo_path / "api-server/scripts").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "api-server/scripts/export-openapi.ts").write_text(
        "// fixture-only stub\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api/sandboxes").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "mintlify_docs/api-reference").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "mintlify_docs/docs.json").write_text(
        json.dumps(
            {
                "navigation": {
                    "tabs": [
                        {
                            "tab": "API Reference",
                            "groups": [{"group": "Core", "pages": ["api/sandboxes/create"]}],
                        }
                    ]
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/llms.txt").write_text(
        "- [Create Sandbox](https://docs.agentenv.io/api/sandboxes/create)\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/README.md").write_text("# Mintlify\n", encoding="utf-8")
    (monorepo_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/sandboxes": {
                        "post": {
                            "summary": "Create sandbox",
                            "requestBody": {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/CreateSandboxRequest"}
                                    }
                                },
                            },
                            "responses": {
                                "201": {"description": "Created"}
                            },
                        }
                    }
                },
                "components": {
                    "schemas": {
                        "CreateSandboxRequest": {
                            "type": "object",
                            "required": ["image", "workspaceId"],
                            "properties": {
                                "image": {"type": "string"},
                                "workspaceId": {"type": "string"},
                            },
                        }
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api-reference/operation-page-template.md").write_text(
        (
            "---\n"
            "title: {{ title }}\n"
            "openapi: '{{ openapi }}'\n"
            "icon: {{ icon }}\n"
            "---\n\n"
            "{{ summary }}\n\n"
            "## API\n\n"
            "{{ api_block }}\n\n"
            "## CLI\n\n"
            "{{ cli_block }}\n\n"
            "## Python SDK\n\n"
            "{{ sdk_block }}\n"
        ),
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": normalized_binding,
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "sdk": {
                            "support": "supported",
                            "symbols": ["Client.sandbox.create"],
                            "example": 'client.sandbox.create(image="python:3.11")',
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api/sandboxes/create.mdx").write_text(
        (
            "---\n"
            "title: Create Sandbox\n"
            f"openapi: 'api-reference/openapi.json {normalized_binding}'\n"
            "icon: PlusCircle\n"
            "---\n\n"
            "Create a sandbox.\n\n"
            "## API\n\n"
            "**Operation:** `POST /sandboxes`\n\n"
            "**OpenAPI Source:** `api-reference/openapi.json`\n\n"
            "### Request Body\n\n"
            "| Field | Type | Required |\n"
            "| --- | --- | --- |\n"
            "| image | string | yes |\n"
            "| workspaceId | string | yes |\n\n"
            "### Responses\n\n"
            "| Status | Description |\n"
            "| --- | --- |\n"
            "| 201 | Created |\n\n"
            "## CLI\n\n"
            "Supported via CLI.\n\n"
            "```bash\n"
            "agv sandbox create --image python:3.11\n"
            "```\n\n"
            "## Python SDK\n\n"
            "Supported via Python SDK.\n\n"
            "```python\n"
            "client.sandbox.create(image=\"python:3.11\")\n"
            "```\n"
        ),
        encoding="utf-8",
    )


def test_verify_mintlify_surface_flags_missing_operation_binding(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes/{id}")
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "failed"
    assert report["missing_openapi_operations"] == [
        {"path": "mintlify_docs/api/sandboxes/create.mdx", "openapi": "POST /sandboxes/{id}"}
    ]


def test_run_agentflow_json_parses_embedded_json_output(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    logs_dir = tmp_path / "logs"
    stdout_log = logs_dir / "embedded.stdout.log"
    stderr_log = logs_dir / "embedded.stderr.log"

    def _fake_run_command(argv, *, cwd, env, logs_dir, log_name, check=True):
        return runner.CommandResult(
            argv=list(argv),
            returncode=0,
            stdout=(
                "inspect output\n"
                '{"event":"structured-log","node":"inspect-plan"}\n'
                '{"status": "ok", "id": "run-123"}\n'
            ),
            stderr="",
            stdout_log=stdout_log,
            stderr_log=stderr_log,
        )

    monkeypatch.setattr(runner, "_run_command", _fake_run_command)
    payload = runner._run_agentflow_json(
        agentflow_command=["agentflow"],
        subcommand="inspect",
        pipeline_path=tmp_path / "pipeline.json",
        cwd=tmp_path,
        env={},
        runs_dir=tmp_path / "runs",
        logs_dir=logs_dir,
        log_name="embedded",
    )

    assert payload == {"status": "ok", "id": "run-123"}


def test_run_child_module_closes_log_handle_when_popen_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    captured_handles: list[object] = []

    class FakeHandle:
        def __init__(self) -> None:
            self.closed = False

        def close(self) -> None:
            self.closed = True

    def _fake_open(self, *_args, **_kwargs):
        del self
        handle = FakeHandle()
        captured_handles.append(handle)
        return handle

    def _fake_popen(*_args, **_kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(Path, "open", _fake_open, raising=False)
    monkeypatch.setattr(runner.subprocess, "Popen", _fake_popen)

    with pytest.raises(RuntimeError, match="boom"):
        runner._run_child_module(
            source_repo=tmp_path,
            module_id="api-reference",
            plan_file=tmp_path / "modules.json",
            base_ref="HEAD",
            progress="off",
            log_path=tmp_path / "wave.log",
        )

    assert captured_handles
    assert all(getattr(handle, "closed", False) for handle in captured_handles)


def test_command_wave_closes_log_handles_after_child_completion(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    modules_path = tmp_path / "modules.json"
    modules_path.write_text(
        json.dumps({"modules": [{"id": "api-reference", "enabled": True}]}, indent=2) + "\n",
        encoding="utf-8",
    )

    class FakeHandle:
        def __init__(self) -> None:
            self.closed = False

        def write(self, _value: str) -> int:
            return 0

        def flush(self) -> None:
            return None

        def close(self) -> None:
            self.closed = True

    class FakeProcess:
        pid = 12345

        def __init__(self, handle: FakeHandle) -> None:
            self._log_handle = handle

        def poll(self) -> int:
            return 0

    opened_handles: list[FakeHandle] = []

    def _fake_run_child_module(
        *,
        source_repo: Path,
        module_id: str,
        plan_file: Path,
        base_ref: str,
        progress: str,
        log_path: Path,
    ) -> FakeProcess:
        del source_repo, module_id, plan_file, base_ref, progress, log_path
        handle = FakeHandle()
        opened_handles.append(handle)
        return FakeProcess(handle)

    monkeypatch.setattr(runner, "_run_child_module", _fake_run_child_module)
    monkeypatch.setattr(runner.time, "sleep", lambda _seconds: None)

    args = runner.argparse.Namespace(
        source_repo=str(tmp_path),
        plan_file=str(modules_path),
        plan_worktree=None,
        module=["api-reference"],
        all_enabled=False,
        base_ref="HEAD",
        max_parallel=1,
        child_progress="off",
    )
    runner._command_wave(args)

    assert opened_handles
    assert all(handle.closed for handle in opened_handles)


def test_command_plan_does_not_forward_progress_to_agentflow_run(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")

    monkeypatch.setattr(runner, "_resolve_provider", lambda: ("http://example.local", "openai-pinned", "OPENAI_API_KEY", "gpt-5.4"))
    monkeypatch.setattr(runner, "_resolve_agentflow_command", lambda: ["agentflow"])
    monkeypatch.setattr(runner, "_ensure_worktree", lambda source_repo, **kwargs: kwargs["worktree_path"])
    monkeypatch.setattr(runner, "_install_reference_scripts", lambda _worktree: [])
    monkeypatch.setattr(runner, "merge_plan_decisions", lambda base_plan, decision_payload: base_plan)

    calls: list[dict[str, object]] = []

    def _fake_run_agentflow_json(**kwargs):
        calls.append({"subcommand": kwargs["subcommand"], "extra_args": kwargs.get("extra_args")})
        if kwargs["subcommand"] == "inspect":
            return {"status": "ok", "id": "inspect-1"}
        return {
            "status": "ok",
            "id": "run-1",
            "nodes": {
                "plan_module_decisions": {"output": '{"module_decisions": []}'},
                "plan_summary": {"output": "# Summary\n"},
            },
        }

    monkeypatch.setattr(runner, "_run_agentflow_json", _fake_run_agentflow_json)

    args = runner.argparse.Namespace(
        source_repo=str(tmp_path),
        worktree_path=str(tmp_path),
        branch_name="feature/test-plan",
        base_ref="HEAD",
        progress="live",
    )
    runner._command_plan(args)

    run_call = next(call for call in calls if call["subcommand"] == "run")
    assert run_call["extra_args"] in (None, [])


def test_command_module_does_not_forward_progress_to_agentflow_run(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    plan_file = tmp_path / "modules.json"
    plan_file.write_text(
        json.dumps(
            {
                "router_skill_ref": ".agentflow/mintlify-alignment/plan/runtime-skills/repo-skill-router",
                "modules": [
                    {
                        "id": "api-reference",
                        "enabled": True,
                        "canonical_targets": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api-reference/operation-contract.json",
                            "mintlify_docs/api-reference/operation-page-template.md",
                            "mintlify_docs/api/sandboxes/create.mdx",
                        ],
                        "write_scope": [
                            "mintlify_docs/api-reference/introduction.mdx",
                            "mintlify_docs/api-reference/openapi.json",
                            "mintlify_docs/api-reference/operation-contract.json",
                            "mintlify_docs/api-reference/operation-page-template.md",
                            "mintlify_docs/api/sandboxes/create.mdx",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": ["echo verify-api-reference"],
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(runner, "_resolve_provider", lambda: ("http://example.local", "openai-pinned", "OPENAI_API_KEY", "gpt-5.4"))
    monkeypatch.setattr(runner, "_resolve_agentflow_command", lambda: ["agentflow"])
    monkeypatch.setattr(runner, "_ensure_worktree", lambda source_repo, **kwargs: kwargs["worktree_path"])
    monkeypatch.setattr(runner, "_install_reference_scripts", lambda _worktree: [])
    monkeypatch.setattr(runner, "_copy_plan_artifacts", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        runner,
        "build_module_pipeline_json",
        lambda **_kwargs: json.dumps({"name": "test-pipeline", "nodes": []}),
    )

    calls: list[dict[str, object]] = []

    def _fake_run_agentflow_json(**kwargs):
        calls.append({"subcommand": kwargs["subcommand"], "extra_args": kwargs.get("extra_args")})
        if kwargs["subcommand"] == "inspect":
            return {"status": "ok", "id": "inspect-1"}
        return {
            "status": "ok",
            "id": "run-1",
            "nodes": {
                "final_summary": {"output": "# Summary\n"},
            },
        }

    monkeypatch.setattr(runner, "_run_agentflow_json", _fake_run_agentflow_json)

    args = runner.argparse.Namespace(
        source_repo=str(tmp_path),
        module_id="api-reference",
        plan_file=str(plan_file),
        plan_worktree=None,
        worktree_path=str(tmp_path),
        base_ref="HEAD",
        progress="live",
    )
    runner._command_module(args)

    run_call = next(call for call in calls if call["subcommand"] == "run")
    assert run_call["extra_args"] in (None, [])


def test_copy_plan_artifacts_skips_same_directory(tmp_path: Path) -> None:
    runner = _load_runner_module()
    plan_dir = tmp_path / ".agentflow" / "mintlify-alignment" / "plan"
    plan_dir.mkdir(parents=True, exist_ok=True)
    marker = plan_dir / "modules.json"
    marker.write_text('{"modules":[]}\n', encoding="utf-8")

    runner._copy_plan_artifacts(plan_dir, tmp_path)

    assert marker.read_text(encoding="utf-8") == '{"modules":[]}\n'
