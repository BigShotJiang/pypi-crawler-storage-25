"""Regression tests for the canonical Mintlify docs surface."""

from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
RUNNER_SCRIPT = REPO_ROOT / "scripts/agentflow/mintlify_alignment/run_mintlify_alignment.py"
OPENAPI_SCHEMA_PATH = REPO_ROOT / "mintlify_docs/api-reference/openapi.json"


def _load_runner_module():
    spec = importlib.util.spec_from_file_location("run_mintlify_alignment", RUNNER_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def _load_repo_openapi_schema() -> dict[str, object]:
    return json.loads(OPENAPI_SCHEMA_PATH.read_text(encoding="utf-8"))


def _get_operation_parameters(path: str, method: str) -> list[dict[str, object]]:
    schema = _load_repo_openapi_schema()
    return schema["paths"][path][method.lower()]["parameters"]


def _get_parameter_required_flag(path: str, method: str, parameter_name: str) -> bool:
    parameters = _get_operation_parameters(path, method)
    parameter = next(
        parameter
        for parameter in parameters
        if parameter["in"] == "query" and parameter["name"] == parameter_name
    )
    return parameter["required"]


def _stub_openapi_export(monkeypatch: pytest.MonkeyPatch, runner, monorepo_path: Path) -> None:
    def _fake_run_command(argv, *, cwd, env, logs_dir, log_name, check=True):
        output_path = Path(argv[-1]).expanduser().resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(monorepo_path / "mintlify_docs/api-reference/openapi.json", output_path)
        logs_dir.mkdir(parents=True, exist_ok=True)
        stdout_log = logs_dir / f"{log_name}.stdout.log"
        stderr_log = logs_dir / f"{log_name}.stderr.log"
        stdout_log.write_text("stubbed export\n", encoding="utf-8")
        stderr_log.write_text("", encoding="utf-8")
        return runner.CommandResult(
            argv=list(argv),
            returncode=0,
            stdout="stubbed export\n",
            stderr="",
            stdout_log=stdout_log,
            stderr_log=stderr_log,
        )

    monkeypatch.setattr(runner, "_run_command", _fake_run_command)


def _write_minimal_mintlify_fixture(monorepo_path: Path, *, openapi_binding: str) -> None:
    normalized_binding = " ".join(openapi_binding.strip().split())
    method, _, path = normalized_binding.partition(" ")
    normalized_binding = f"{method.upper()} {path}".strip()
    (monorepo_path / "api-server/scripts").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "api-server/scripts/export-openapi.ts").write_text(
        "// fixture-only stub\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api/sandboxes").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "mintlify_docs/api-reference").mkdir(parents=True, exist_ok=True)
    (monorepo_path / "mintlify_docs/docs.json").write_text(
        json.dumps(
            {
                "navigation": {
                    "tabs": [
                        {
                            "tab": "API Reference",
                            "groups": [{"group": "Core", "pages": ["api/sandboxes/create"]}],
                        }
                    ]
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/llms.txt").write_text(
        "- [Create Sandbox](https://docs.agentenv.io/api/sandboxes/create)\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/README.md").write_text("# Mintlify\n", encoding="utf-8")
    (monorepo_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/sandboxes": {
                        "post": {
                            "summary": "Create sandbox",
                            "requestBody": {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/CreateSandboxRequest"}
                                    }
                                },
                            },
                            "responses": {
                                "201": {"description": "Created"}
                            },
                        }
                    }
                },
                "components": {
                    "schemas": {
                        "CreateSandboxRequest": {
                            "type": "object",
                            "required": ["image", "workspaceId"],
                            "properties": {
                                "image": {"type": "string"},
                                "workspaceId": {"type": "string"},
                            },
                        }
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api-reference/operation-page-template.md").write_text(
        (
            "---\n"
            "title: {{ title }}\n"
            "openapi: '{{ openapi }}'\n"
            "icon: {{ icon }}\n"
            "---\n\n"
            "{{ summary }}\n\n"
            "## API\n\n"
            "{{ api_block }}\n\n"
            "## CLI\n\n"
            "{{ cli_block }}\n\n"
            "## Python SDK\n\n"
            "{{ sdk_block }}\n"
        ),
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": normalized_binding,
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "sdk": {
                            "support": "supported",
                            "symbols": ["Client.sandbox.create"],
                            "example": 'client.sandbox.create(image="python:3.11")',
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (monorepo_path / "mintlify_docs/api/sandboxes/create.mdx").write_text(
        (
            "---\n"
            "title: Create Sandbox\n"
            f"openapi: 'api-reference/openapi.json {normalized_binding}'\n"
            "icon: PlusCircle\n"
            "---\n\n"
            "Create a sandbox.\n\n"
            "## API\n\n"
            "**Operation:** `POST /sandboxes`\n\n"
            "**OpenAPI Source:** `api-reference/openapi.json`\n\n"
            "### Request Body\n\n"
            "| Field | Type | Required |\n"
            "| --- | --- | --- |\n"
            "| image | string | yes |\n"
            "| workspaceId | string | yes |\n\n"
            "### Responses\n\n"
            "| Status | Description |\n"
            "| --- | --- |\n"
            "| 201 | Created |\n\n"
            "## CLI\n\n"
            "Supported via CLI.\n\n"
            "```bash\n"
            "agv sandbox create --image python:3.11\n"
            "```\n\n"
            "## Python SDK\n\n"
            "Supported via Python SDK.\n\n"
            "```python\n"
            "client.sandbox.create(image=\"python:3.11\")\n"
            "```\n"
        ),
        encoding="utf-8",
    )


def test_verify_mintlify_surface_passes_for_repo(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    runner = _load_runner_module()
    _stub_openapi_export(monkeypatch, runner, REPO_ROOT)

    report = runner.verify_mintlify_surface(
        monorepo_path=REPO_ROOT,
        reports_dir=tmp_path / "mintlify-alignment-verify",
    )

    assert report["status"] == "passed"
    assert report["docs_json_errors"] == []
    assert report["missing_navigation_pages"] == []
    assert report["missing_openapi_operations"] == []
    assert report["placeholder_hits"] == []
    assert report["llms_internal_link_issues"] == []
    assert report["unfrozen_maintained_pages"] == []
    assert report["openapi_schema_drift"]["matches_checked_in"] is True


def test_verify_mintlify_surface_flags_invalid_docs_json(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    runner = _load_runner_module()

    (tmp_path / "api-server/scripts").mkdir(parents=True, exist_ok=True)
    (tmp_path / "api-server/scripts/export-openapi.ts").write_text("// fixture-only stub\n", encoding="utf-8")
    (tmp_path / "mintlify_docs/api-reference").mkdir(parents=True, exist_ok=True)
    (tmp_path / "mintlify_docs/docs.json").write_text("{not-json", encoding="utf-8")
    (tmp_path / "mintlify_docs/llms.txt").write_text("- [Docs](https://docs.agentenv.io)\n", encoding="utf-8")
    (tmp_path / "mintlify_docs/README.md").write_text("# Mintlify\n", encoding="utf-8")
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps({"openapi": "3.0.0", "paths": {}}, indent=2) + "\n",
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "failed"
    assert report["docs_json_errors"]


@pytest.mark.parametrize(
    ("parameter_name",),
    [
        ("workspaceId",),
        ("agentWorkspaceGroupId",),
        ("search",),
        ("page",),
        ("limit",),
    ],
)
def test_repo_openapi_marks_managed_agents_query_filters_optional(parameter_name: str) -> None:
    assert _get_parameter_required_flag("/managed-agents", "GET", parameter_name) is False


def test_repo_openapi_marks_sites_workspace_filter_optional() -> None:
    assert _get_parameter_required_flag("/sites", "GET", "workspaceId") is False


@pytest.mark.parametrize(
    ("parameter_name",),
    [
        ("workspaceId",),
        ("path",),
    ],
)
def test_repo_openapi_marks_file_upload_query_params_optional(parameter_name: str) -> None:
    assert _get_parameter_required_flag("/files/upload", "POST", parameter_name) is False


def test_verify_mintlify_surface_normalizes_openapi_binding(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="   post    /sandboxes   ")
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "passed"
    assert report["missing_openapi_operations"] == []


def test_verify_mintlify_surface_fails_when_operation_contract_lacks_sdk_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": "POST /sandboxes",
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "failed"
    assert report["api_reference_alignment"]["missing_sdk_support"] == [
        "mintlify_docs/api/sandboxes/create.mdx"
    ]


def test_verify_mintlify_surface_reports_per_page_alignment_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": "POST /sandboxes",
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "sdk": {
                            "support": "supported",
                            "symbols": ["Client.sandbox.create"],
                            "example": 'client.sandbox.create(image="python:3.11")',
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["api_reference_alignment"]["coverage_rows"] == [
        {
            "page_path": "mintlify_docs/api/sandboxes/create.mdx",
            "openapi": "POST /sandboxes",
            "api_section": "present",
            "cli_support": "supported",
            "sdk_support": "supported",
        }
    ]


def test_verify_mintlify_surface_fails_when_public_operation_is_missing_from_contract(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/docs.json").write_text(
        json.dumps(
            {
                "navigation": {
                    "tabs": [
                        {
                            "tab": "API Reference",
                            "groups": [
                                {
                                    "group": "Core",
                                    "pages": [
                                        "api/sandboxes/overview",
                                        "api/sandboxes/create",
                                    ],
                                }
                            ],
                        }
                    ]
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/sandboxes": {
                        "post": {
                            "summary": "Create sandbox",
                            "requestBody": {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/CreateSandboxRequest"}
                                    }
                                },
                            },
                            "responses": {
                                "201": {"description": "Created"}
                            },
                        }
                    },
                    "/sandboxes/{id}": {
                        "get": {
                            "summary": "Get sandbox",
                            "parameters": [
                                {
                                    "name": "id",
                                    "in": "path",
                                    "required": True,
                                    "schema": {"type": "string"},
                                }
                            ],
                            "responses": {
                                "200": {"description": "Sandbox"}
                            },
                        }
                    },
                },
                "components": {
                    "schemas": {
                        "CreateSandboxRequest": {
                            "type": "object",
                            "required": ["image", "workspaceId"],
                            "properties": {
                                "image": {"type": "string"},
                                "workspaceId": {"type": "string"},
                            },
                        }
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api/sandboxes/overview.mdx").write_text(
        (
            "---\n"
            "title: Sandboxes Overview\n"
            "---\n\n"
            "Use `POST /sandboxes` to create a sandbox.\n\n"
            "Use `GET /sandboxes/{id}` to inspect an existing sandbox.\n"
        ),
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "failed"
    assert report["api_reference_alignment"]["uncovered_public_operations"] == ["GET /sandboxes/{id}"]
    assert any(
        "GET /sandboxes/{id}" in error for error in report["api_reference_alignment"]["errors"]
    )


def test_verify_mintlify_surface_allows_excluded_public_operation_from_contract_gate(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/docs.json").write_text(
        json.dumps(
            {
                "navigation": {
                    "tabs": [
                        {
                            "tab": "API Reference",
                            "groups": [
                                {
                                    "group": "Core",
                                    "pages": [
                                        "api/sandboxes/overview",
                                        "api/sandboxes/create",
                                    ],
                                }
                            ],
                        }
                    ]
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api-reference/openapi.json").write_text(
        json.dumps(
            {
                "openapi": "3.0.0",
                "paths": {
                    "/sandboxes": {
                        "post": {
                            "summary": "Create sandbox",
                            "requestBody": {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/CreateSandboxRequest"}
                                    }
                                },
                            },
                            "responses": {
                                "201": {"description": "Created"}
                            },
                        }
                    },
                    "/sandboxes/{id}": {
                        "get": {
                            "summary": "Get sandbox",
                            "parameters": [
                                {
                                    "name": "id",
                                    "in": "path",
                                    "required": True,
                                    "schema": {"type": "string"},
                                }
                            ],
                            "responses": {
                                "200": {"description": "Sandbox"}
                            },
                        }
                    },
                },
                "components": {
                    "schemas": {
                        "CreateSandboxRequest": {
                            "type": "object",
                            "required": ["image", "workspaceId"],
                            "properties": {
                                "image": {"type": "string"},
                                "workspaceId": {"type": "string"},
                            },
                        }
                    }
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api-reference/operation-contract.json").write_text(
        json.dumps(
            {
                "operations": [
                    {
                        "page_path": "mintlify_docs/api/sandboxes/create.mdx",
                        "title": "Create Sandbox",
                        "icon": "PlusCircle",
                        "openapi": "POST /sandboxes",
                        "resource": "sandboxes",
                        "intent": "create",
                        "summary": "Create a sandbox.",
                        "cli": {
                            "support": "supported",
                            "mapping_kind": "exact",
                            "command_path": ["sandbox", "create"],
                            "commands": ["agv sandbox create --image python:3.11"],
                            "example": "agv sandbox create --image python:3.11",
                            "notes": [],
                        },
                        "sdk": {
                            "support": "supported",
                            "symbols": ["Client.sandbox.create"],
                            "example": 'client.sandbox.create(image="python:3.11")',
                            "notes": [],
                        },
                        "notes": [],
                        "owners": ["api-reference"],
                    }
                ],
                "excluded_public_operations": [
                    {
                        "openapi": "GET /sandboxes/{id}",
                        "reason": "Documented for discovery, intentionally excluded from contract pages.",
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "mintlify_docs/api/sandboxes/overview.mdx").write_text(
        (
            "---\n"
            "title: Sandboxes Overview\n"
            "---\n\n"
            "Use `POST /sandboxes` to create a sandbox.\n\n"
            "Use `GET /sandboxes/{id}` to inspect an existing sandbox.\n"
        ),
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "passed"
    assert "GET /sandboxes/{id}" not in report["api_reference_alignment"]["uncovered_public_operations"]


def test_verify_mintlify_surface_fails_when_operation_page_lacks_visible_api_section(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _write_minimal_mintlify_fixture(tmp_path, openapi_binding="POST /sandboxes")
    (tmp_path / "mintlify_docs/api/sandboxes/create.mdx").write_text(
        (
            "---\n"
            "title: Create Sandbox\n"
            "openapi: 'POST /sandboxes'\n"
            "icon: PlusCircle\n"
            "---\n\n"
            "Create a sandbox.\n\n"
            "## CLI\n\n"
            "Supported via CLI.\n\n"
            "```bash\n"
            "agv run -- echo hi\n"
            "```\n\n"
            "## Python SDK\n\n"
            "Supported via Python SDK.\n\n"
            "```python\n"
            "client.sandbox.create(image=\"python:3.11\")\n"
            "```\n"
        ),
        encoding="utf-8",
    )
    _stub_openapi_export(monkeypatch, runner, tmp_path)

    report = runner.verify_mintlify_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "mintlify-alignment" / "verify",
    )

    assert report["status"] == "failed"
    assert report["api_reference_alignment"]["missing_api_sections"] == [
        "mintlify_docs/api/sandboxes/create.mdx"
    ]


def test_verify_mintlify_surface_uses_npm_script_for_openapi_export(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = _load_runner_module()
    _stub_openapi_export(monkeypatch, runner, REPO_ROOT)

    report = runner.verify_mintlify_surface(
        monorepo_path=REPO_ROOT,
        reports_dir=tmp_path / "mintlify-alignment-verify",
    )

    command = report["openapi_schema_drift"]["command"]
    assert command[:4] == ["npm", "run", "docs:mintlify:openapi", "--"]


def test_api_server_openapi_export_command_writes_json(tmp_path: Path) -> None:
    output_path = tmp_path / "openapi-export.json"
    result = subprocess.run(
        ["npm", "run", "docs:mintlify:openapi", "--", str(output_path)],
        cwd=REPO_ROOT / "api-server",
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, (
        "OpenAPI export command failed.\n"
        f"STDOUT:\n{result.stdout}\n"
        f"STDERR:\n{result.stderr}"
    )
    assert output_path.is_file()
    exported = json.loads(output_path.read_text(encoding="utf-8"))
    assert exported["openapi"]
